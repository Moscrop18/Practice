package com.accenture.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="customer_info")
public class CustomerInfo {
	
	
	public CustomerInfo(String customer_Name, String customer_Poc, Date validity_Date, int days) {
		super();
		this.customer_Name = customer_Name;
		this.customer_Poc = customer_Poc;
		this.validity_Date = validity_Date;
		this.days = days;
	}


	public CustomerInfo() {
		
	}


	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID")
	private int id;

	@Column(name="customer_Name")
	private String customer_Name;
	
	@Column(name="customer_Poc")
	private String customer_Poc;
	
	@Column(name="installation_Date")
	private Date installation_Date;
	
	@Column(name="validity_Date")
	private Date validity_Date;
	
	@Column(name="Subscription_Required")
	private String subscriptionRequired;
	
	@Transient
	private int days;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCustomer_Name() {
		return customer_Name;
	}

	public void setCustomer_Name(String customer_Name) {
		this.customer_Name = customer_Name;
	}

	public String getCustomer_Poc() {
		return customer_Poc;
	}

	public void setCustomer_Poc(String customer_Poc) {
		this.customer_Poc = customer_Poc;
	}

	public Date getInstallation_Date() {
		return installation_Date;
	}

	public void setInstallation_Date(Date installation_Date) {
		this.installation_Date = installation_Date;
	}

	public Date getValidity_Date() {
		return validity_Date;
	}

	public void setValidity_Date(Date validity_Date) {
		this.validity_Date = validity_Date;
	}

	public String getSubscriptionRequired() {
		return subscriptionRequired;
	}

	public void setSubscriptionRequired(String subscriptionRequired) {
		this.subscriptionRequired = subscriptionRequired;
	}

	public int getDays() {
		return days;
	}

	public void setDays(int days) {
		this.days = days;
	}
}
