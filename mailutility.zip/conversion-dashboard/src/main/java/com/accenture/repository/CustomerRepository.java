package com.accenture.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.accenture.entity.CustomerInfo;


public interface CustomerRepository extends JpaRepository<CustomerInfo,Integer> {
	
	@Query(value ="SELECT new CustomerInfo(c.customer_Name, c.customer_Poc, c.validity_Date, DATEDIFF(c.validity_Date,NOW()) as DAYS) FROM CustomerInfo c WHERE c.subscriptionRequired = 'Y' and DATEDIFF(c.validity_Date,NOW()) <90")
	public List<CustomerInfo> findCustomersForRenewal();
	
}
