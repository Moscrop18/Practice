package com.accenture.service;


import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.accenture.entity.CustomerInfo;
import com.accenture.repository.CustomerRepository;

@Service
public class CustomerInfoService {

	@Autowired
	CustomerRepository customerRepository;
	

	
	public List<CustomerInfo> getCustomersForRenewal() {
		
		List<CustomerInfo> customerInfoList = customerRepository.findCustomersForRenewal();
		
		
		System.out.println(customerInfoList.size());
		return customerInfoList;
		
	}
	
	public List<CustomerInfo> getAllDeployments(){
		
		List<CustomerInfo> customerInfoList = customerRepository.findAll();
		return customerInfoList;
		
	}
	
}
