package com.accenture.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.accenture.entity.CustomerInfo;

@Service
public class EmailService {
	
	@Autowired
	CustomerInfoService  customerinforService;
	
	@Autowired 
	private JavaMailSender javaMailSender;

	public void sendEmail() {
		
		List<CustomerInfo> customerInfoList = customerinforService.getCustomersForRenewal();
		String sender = "IDC_SAPUpgrade_Sales@accenture.com";
		
		for(CustomerInfo customerInfo : customerInfoList) {
			
			String emailBody = "\n\nDear User,  "+"\n\nYour Intelligent Configurator subscription is about to expire on "
					+ customerInfo.getValidity_Date() + " . Please contact IDC_SAPUpgrade_Sales If you want to renew this subscription.\n\n"
					+ "Regards,\nS/4 HANA ATCI Team ";
			try {
			
            SimpleMailMessage mailMessage
                = new SimpleMailMessage();
 
         
            mailMessage.setFrom(sender);
            mailMessage.setTo(customerInfo.getCustomer_Poc());
            mailMessage.setText(emailBody);
            mailMessage.setSubject("Intelligent Configurator Subscription");
 
            // Sending the mail
            javaMailSender.send(mailMessage);
            System.out.println("Mail Sent Successfully...");
        }
 
      
        catch (Exception e) {
        	System.out.println("Error while Sending Mail");
            
        }
		}
		
      
}
}
