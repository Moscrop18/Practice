package com.accenture.benchMarking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.accenture.master.ProcessedRequestMasterModel;
import com.accenture.reqmaster.service.RequestMasterService;

@RestController
public class BenchMarkingController {
	@Autowired
	private RequestMasterService reqMasterService;
	
	@RequestMapping(value = "BenchMarking/get/processedRequestMaster", method = RequestMethod.GET)
	public List<ProcessedRequestMasterModel> getProcessedRequestMaster() {
		
		return  reqMasterService.getRequestMasterList();
	}


}
