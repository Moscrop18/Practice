package com.accenture.report;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.accenture.constant.Hana_Profiler_Constant;
import com.accenture.controller.AbstractBaseController;
import com.accenture.poc.model.User;
import net.minidev.json.JSONArray;

/**
 * Controller class added for Report generation of Request Health  CR:24
 *
 */

@Controller
@SessionAttributes("User")
public class ReportController extends AbstractBaseController{
	
	private List<Map<String,String>> avgRequestList = new ArrayList<Map<String, String>>();
	private List<Map<String,String>> requestList = new ArrayList<Map<String, String>>();
		
	public List<Map<String,String>> getAvgRequestList() {
		return avgRequestList;
	}

	public void setAvgRequestList(List<Map<String,String>> avgRequestList) {
		this.avgRequestList = avgRequestList;
	}

	public List<Map<String, String>> getRequestList() {
		return requestList;
	}

	public void setRequestList(List<Map<String, String>> requestList) {
		this.requestList = requestList;
	}

	/**
	 * CR24: Generates the list of requests with all the required columns
	 * @param request
	 * @param model
	 * @param igName
	 * @param sourceVersion
	 * @param requestId
	 * @return
	 */
	@RequestMapping(value="/report/checkRequestHealth")
	public String generateHealthReport(HttpServletRequest request, Model model,  @ModelAttribute("igName") String igName,
			@ModelAttribute("sourceVersion") String sourceVersion,  @ModelAttribute("requestId") String requestId, 
			@ModelAttribute("message") String message){
		try
		{
			logger.info("Inside generateHealthReport method");
			
			Map<String, String> modelMap = generateRequestList(igName, sourceVersion, requestId);
			
			ReportDao reportDao = getReportDao();
			//Get the IGList and SourceVersionList from DB for dropDown
			model.addAttribute("igList", reportDao.getIgList());
			model.addAttribute("sourceVersionList", reportDao.getSourceVersionList());

			//For client, only show requests that is created by that client.
			//Get the list of all the requests created by client.
			if(!modelMap.isEmpty())
			{
				model.addAttribute("message", modelMap.get("message"));
			}
			if(!message.isEmpty())
			{
				model.addAttribute("message", message);
			}
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
		}

		if(null != requestList)
		{
			model.addAttribute("totalRequests", requestList.size());
			model.addAttribute("requestList", requestList);
			model.addAttribute("size", avgRequestList.size());
			model.addAttribute("avgRequestList", avgRequestList);
		}
		return "report/checkRequestHealth";
	}
	/**
	 * Post method for filtering result using drop-down.
	 * @param request
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/report/checkRequestHealthPost", method=RequestMethod.POST, produces="application/json")
	public @ResponseBody JSONArray generateHealthReportPost(HttpServletRequest request, Model model){
		try
		{
			logger.info("Inside generateHealthReport Post method");
			String igName = request.getParameter("igName");
			String sourceVersion  = request.getParameter("sourceVersion");
			String requestId  = request.getParameter("requestId");
			generateRequestList(igName, sourceVersion, requestId);
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
		}

		if(null != requestList)
		{
			model.addAttribute("totalRequests", requestList.size());
			model.addAttribute("requestList", requestList);
			model.addAttribute("size", avgRequestList.size());
			model.addAttribute("avgRequestList", avgRequestList);
		}
		
		JSONArray jsonList = new JSONArray();
		jsonList.add(avgRequestList);
		jsonList.add(requestList);		
		
	return jsonList;
		
	}
	
	private Map<String, String> generateRequestList(String igName, String sourceVersion, String requestId)
	{
		Map<String, String> returnMap = new HashMap<String, String>();
		try
		{
			if(!avgRequestList.isEmpty())
			{
				avgRequestList.clear();
			}
			if(!requestList.isEmpty())
			{
				requestList.clear();
			}
			
			User user = (User) getUserdata().getUser(getPrincipal());
			String userName = user.getUserName();
			String userRole = user.getUserRole().iterator().next().getUserRole();
			ReportDao reportDao = getReportDao();
			
			if(userRole.equalsIgnoreCase(Hana_Profiler_Constant.ADMIN_ROLE)
					|| userRole.equalsIgnoreCase(Hana_Profiler_Constant.POC_ROLE))
			{
				List<Map<String,String>> avgValue = reportDao.getAvgRequestList(igName, sourceVersion);
				avgRequestList.add(avgValue.get(0));
				if(null==requestId || requestId.isEmpty())
				{
					//In case of all requests [for Admin], pass 0L as requestId.
					List<Map<String,String>> requestValue = reportDao.getRequestListByRequestId(0L, igName, sourceVersion);
					for (Map<String, String> requestMap : requestValue) {
						requestList.add(requestMap); 
					}
				}
				else
				{
					List<Map<String,String>> temp = reportDao.getRequestListByRequestId(Long.valueOf(requestId), igName, sourceVersion);
					requestList.add(temp.get(0));
				}
			}
			else
			{
				//For client, only show requests that is created by that client.
				//Get the list of all the requests created by client.
				List<Long> requestIdList = getClientRequestInventoryDAO().requestIdListByUser(userName);
				if(null==requestId || requestId.isEmpty())
				{
					if(null == requestIdList || requestIdList.isEmpty())
					{
						//No completed request for this user.
						returnMap.put("message", "No requests for this user");
					}
					else
					{
						List<Map<String,String>> avgValue = reportDao.getAvgRequestList(igName, sourceVersion);
						avgRequestList.add(avgValue.get(0));
						//Get the list of completed request for this user.
						for (Long id : requestIdList) {
							List<Map<String,String>> temp = reportDao.getRequestListByRequestId(id, igName, sourceVersion);
							requestList.add(temp.get(0));
						}
					}
				}
				else
				{
					if(requestIdList.contains(Long.valueOf(requestId)))
					{
						List<Map<String,String>> avgValue = reportDao.getAvgRequestList(igName, sourceVersion);
						avgRequestList.add(avgValue.get(0));
						List<Map<String,String>> temp = reportDao.getRequestListByRequestId(Long.valueOf(requestId), igName, sourceVersion);
						requestList.add(temp.get(0));
					}
					else
					{
						//No completed request for this user.
						returnMap.put("message", "No such requests for this user");
					}
				}
			}
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
		}
		return returnMap;
	}
	
	/**
	 * CR24: Generates the result for specific requestId
	 * @param request
	 * @param redirectAttributes
	 * @return
	 */
	@RequestMapping(value = "/report/searchRequest", method=RequestMethod.POST)
	public String searchRequest(HttpServletRequest request, final RedirectAttributes redirectAttributes)
	{
		String igName = request.getParameter("igName");
		String sourceVersion  = request.getParameter("sourceVersion");
		String requestId  = request.getParameter("requestId");
		
		logger.info("Inside ssearchRequest.");
		try
		{
			ReportDao reportDao = getReportDao();
			List<Map<String,String>> temp = reportDao.getRequestListByRequestId(Long.valueOf(requestId), igName, sourceVersion);
			if(null == temp || temp.isEmpty())
			{
				redirectAttributes.addFlashAttribute("message", "Please enter a valid RequestId");
			}
			else
			{
				redirectAttributes.addFlashAttribute("igName", igName);
				redirectAttributes.addFlashAttribute("sourceVersion", sourceVersion);
				redirectAttributes.addFlashAttribute("requestId", requestId);
			}
			
		}
		catch (Exception e) 
		{
			logger.error(e.getMessage());
		}
		return "redirect:/report/checkRequestHealth";
	}
}
