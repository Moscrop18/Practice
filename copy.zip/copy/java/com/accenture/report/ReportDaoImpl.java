package com.accenture.report;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public class ReportDaoImpl implements ReportDao{
	final Logger logger = LoggerFactory.getLogger(ReportDaoImpl.class);
	SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {

		this.sessionFactory = sessionFactory;
	}
	
	@Override
	public List<Map<String, String>> getRequestListByRequestId(Long requestId, String igName, String sourceVersion) {
		List<Map<String, String>> requestList = new ArrayList<Map<String, String>>();
		try{
			//This code is not used and hence it is not tested
			Session session=sessionFactory.getCurrentSession();
			String hql = "SELECT  requestID, clientName, app_level_category_count, db_level_category_count, "
					+ "mandatory_category_count, used_count, defectCount "
					+ "FROM ProcessedRequestDetail ";
			if(0!=requestId)
			{
				
				if(null != igName && !igName.isEmpty())
				{
					if(null != sourceVersion && !sourceVersion.isEmpty())
					{
						hql +=" WHERE requestID =:requestId AND industryGroup=:igName AND sourceVersion=:sourceVersion";
					}
					else
					{
						hql += " WHERE requestID =:requestId AND industryGroup=:igName";
					}
				}
				else
				{
					if (null != sourceVersion && !sourceVersion.isEmpty())
					{
						hql += " WHERE requestID =:requestId AND sourceVersion=:sourceVersion";
					}
					else
					{
						hql+= " WHERE requestID =:requestId";	
					}
				}
		
			}
			else 
			{
				if(null != igName && !igName.isEmpty())
				{
					if(null != sourceVersion && !sourceVersion.isEmpty())
					{
						//both the parameters need to be clubbed.
						hql +=" WHERE industryGroup=:igName AND sourceVersion=:sourceVersion";
					}
					else
					{
						//Only igName is present.
						hql +=" WHERE industryGroup=:igName";
					}
				}
				else 
				{
					if (null != sourceVersion && !sourceVersion.isEmpty())
					{
						hql +=" WHERE sourceVersion=:sourceVersion";
					}
				}
			}
			Query query = session.createQuery(hql);
			query.setParameter("igName",igName);
			query.setParameter("sourceVersion",sourceVersion);
			query.setParameter("requestId",requestId);



			@SuppressWarnings("unchecked")
			List<Object[]> rList = query.list();
			
			requestList = getModelList(rList, null);
		}
		catch(Exception e){
			logger.error("Error !!! " + e);
		}
		return requestList;
	}

	@Override
	public List<Map<String, String>> getAvgRequestList(String igName, String sourceVersion) {
		List<Map<String, String>> requestList = new ArrayList<Map<String, String>>();
		try{
			//This code is not used and hence it is not tested
			Session session=sessionFactory.getCurrentSession();
			String hql = "SELECT  0L, 0L, AVG(app_level_category_count), AVG(db_level_category_count), "
					+ "AVG(mandatory_category_count), AVG(used_count), AVG(defectCount) "
					+ "FROM ProcessedRequestDetail ";
			if(null != igName && !igName.isEmpty())
			{
				if(null != sourceVersion && !sourceVersion.isEmpty())
				{
					//both the parameters need to be clubbed.
					hql +=" WHERE industryGroup=:igName AND sourceVersion=:sourceVersion";
				}
				else
				{
					//Only igName is present.
					hql +=" WHERE industryGroup=:igName";
				}
			}
			else if (null != sourceVersion && !sourceVersion.isEmpty())
			{
				//Only sourceVersion is present.
				hql +=" WHERE sourceVersion=:sourceVersion";
			}
			Query query = session.createQuery(hql);
			query.setParameter("igName",igName);
			query.setParameter("sourceVersion",sourceVersion);
			@SuppressWarnings("unchecked")
			List<Object[]> rList = query.list();
			List<Long> requestIdList = getRequestIdist(igName, sourceVersion);
			requestList = getModelList(rList, requestIdList);
		}
		catch(Exception e){
			logger.error("Error !!! " + e);
		}
		return requestList;
	}

	private List<Map<String, String>> getModelList(List<Object[]> queryResult, List<Long> requestsIdList)
	{
		List<Map<String, String>> requestList = new ArrayList<Map<String, String>>();
		Long totalInventory = 0L;
		Long usedDefective = 0L;
		int noOfRequests = 1;
		try
		{
			if(!queryResult.isEmpty())
			{
				for (Object[] entry : queryResult) 
				{
					Map<String,String> temp = new HashMap<String, String>();
					Long requestId = ((Long)entry[0]);
					if(0L != requestId)
					{
						temp.put("requestId",requestId.toString());
						//Add total Inventory
						totalInventory = getTotalInventoryCount(requestId);
						//Add used_defective_count
						usedDefective = getTotalUsedDefectiveCount(requestId);
					}
					else
					{
						//This is for the average calculation.
						/*temp.put("requestId","Average Values");*/
						noOfRequests = requestsIdList.size();
						Long totalInventorySum = 0L;
						Long totalUsedDefectiveSum = 0L;
						for (Long request : requestsIdList) {
							totalInventorySum += getTotalInventoryCount(request);
							totalUsedDefectiveSum += getTotalUsedDefectiveCount(request);
						}
						//Average totalInventory
						totalInventory = totalInventorySum/noOfRequests;
						//Average used_defective_count
						usedDefective = totalUsedDefectiveSum/noOfRequests;
					}
					if(null != entry[1])
					{
						if("0".equalsIgnoreCase(entry[1].toString()))
						{
							//For average Client Name would be total number of requests considered.
							temp.put("requestCount", Integer.toString(noOfRequests));
						}
						else
						{
							temp.put("clientName", entry[1].toString());
						}
					}else{
						temp.put("clientName", "N/A");
					}if(null != entry[2]){
						temp.put("App_Level_Category_Count", entry[2].toString());
					}else{
						temp.put("App_Level_Category_Count", "0");
					}if(null != entry[3])
					{
						temp.put("DB_Level_Category_Count", entry[3].toString());
					}else{
						temp.put("DB_Level_Category_Count", "0");
					}
					if(null != entry[4]){
						temp.put("Mandatory_Category_Count", entry[4].toString());
					}else{
						temp.put("Mandatory_Category_Count", "0");
					}if(null != entry[5]){
						temp.put("Used_Category_Count", entry[5].toString());
					}else{
						temp.put("Used_Category_Count", "0");
					}if(null != entry[6]){
						temp.put("Defect_Count", entry[6].toString());
					}else{
						temp.put("Defect_Count", "0");
					}
					temp.put("totalInventory",totalInventory.toString());
					temp.put("usedDefective",usedDefective.toString());
					//Add health : To be done.
					requestList.add(temp);
				}
			}
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
		}
		return requestList;
	}
	
	private Long getTotalInventoryCount(Long requestId)
	{
		Session session=sessionFactory.getCurrentSession();
		String hql2 = "SELECT Count(*) from ST03Tadir WHERE requestID = "+requestId; 
		Long totalInventory = 0L;
		totalInventory = (Long)session.createQuery(hql2).uniqueResult();
		return totalInventory;
	}
	
	private Long getTotalUsedDefectiveCount(Long requestId)
	{
		Session session=sessionFactory.getCurrentSession();
		String hql3 = "SELECT COUNT(DISTINCT Obj_name) from HanaProfile where "
				+ "Category='Mandatory' and "
				+ "Used_Unused = 'Used' and requestID="+requestId;
		Long usedDefective = 0L;
		usedDefective = (Long)session.createQuery(hql3).uniqueResult();
		return usedDefective;

	}

	@Override
	public List<String> getIgList() {
		Session session=sessionFactory.getCurrentSession();
		String hql = "SELECT DISTINCT industryGroup from ProcessedRequestDetail"; 
		@SuppressWarnings("unchecked")
		List<String> igList =  (List<String>)session.createQuery(hql).list();
		return igList;
	}

	@Override
	public List<String> getSourceVersionList() {
		
		Session session=sessionFactory.getCurrentSession();
		String hql = "SELECT DISTINCT sourceVersion from ProcessedRequestDetail"; 
		@SuppressWarnings("unchecked")
		List<String> sourceVersionList =  (List<String>)session.createQuery(hql).list();
		return sourceVersionList;
	}
	
	@Override
	public List<Long> getRequestIdist(String igName, String sourceVersion) {
		
		//This is for the average calculation.
		Session session = sessionFactory.getCurrentSession();
		String hql = "SELECT DISTINCT requestID from ProcessedRequestDetail";
		if(null != igName && !igName.isEmpty())
		{
			if(null != sourceVersion && !sourceVersion.isEmpty())
			{
				//both the parameters need to be clubbed.
				hql +=" WHERE industryGroup=:igName AND sourceVersion=:sourceVersion";
			}
			else
			{
				//Only igName is present.
				hql +=" WHERE industryGroup=:igName";
			}
		}
		else if (null != sourceVersion && !sourceVersion.isEmpty())
		{
			//Only sourceVersion is present.
			hql +=" WHERE sourceVersion=:sourceVersion";
		}
		Query query = session.createQuery(hql);
		query.setParameter("igName",igName);
		query.setParameter("sourceVersion",sourceVersion);

		//Total number of distinct requests in master_table.
		@SuppressWarnings("unchecked")
		List<Long> requestsIdList= query.list();
		return requestsIdList;
	}
}
