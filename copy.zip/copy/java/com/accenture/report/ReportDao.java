package com.accenture.report;

import java.util.List;
import java.util.Map;

public interface ReportDao {
	
	List<Map<String,String>> getRequestListByRequestId(Long requestId, String igName, String sourceVersion);
	List<Map<String,String>> getAvgRequestList(String igName, String sourceVersion);
	List<String> getIgList();
	List<String> getSourceVersionList();
	List<Long> getRequestIdist(String igName, String sourceVersion);
}
