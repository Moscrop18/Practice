package com.accenture.model.DRL;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.springframework.web.context.annotation.RequestScope;

import com.accenture.Aadt.models.ACNIPZVERComp;
import com.accenture.Aadt.models.AuctFinalOutput;
import com.accenture.Aadt.models.ImpactedCloneAnalysis;
import com.accenture.Aadt.models.OSMigrationFinal;
import com.accenture.S4.models.S4CvitAssessment;
import com.accenture.S4.models.S4Detection;
import com.accenture.S4.models.S4InventoryList;
import com.accenture.S4.models.S4cvitr;
import com.accenture.bw.model.RsantProcess;
import com.accenture.bw.model.Rsbohdest;
import com.accenture.bw.model.Rsdcube;
import com.accenture.bw.model.Rsdiobj;
import com.accenture.bw.model.Rsds;
import com.accenture.bw.model.Rsldpio;
import com.accenture.bw.model.Rsohcpr;
import com.accenture.bw.model.Rspcchainattr;
import com.accenture.bw.model.Rsqiset;
import com.accenture.bw.model.Rsrrepdir;
import com.accenture.bw.model.Rsrwbindex;
import com.accenture.bw.model.Rsts;
import com.accenture.bw.model.Rsupdinfo;
import com.accenture.bw.model.Rszwbtmphead;
import com.accenture.bw.model.Rszwtemplate;
import com.accenture.client.model.Lsmw;
import com.accenture.displaygrid.model.HanaProfile;
import com.accenture.fileprocessing.model.HanaProfilerStepOutput;
import com.accenture.fileprocessing.model.UsageAnalysis;
import com.accenture.fiori.models.St03NData;
import com.accenture.smodilog.model.SmodilogFunction;
import com.accenture.fileprocessing.model.ComplexityRules;
import com.accenture.fileprocessing.model.ExtensionRules;
import com.accenture.fileprocessing.model.MetaData;
import com.accenture.fileprocessing.model.UsageAnalysisExt;

@RequestScope
public class CodeAssessmentPayLoad {

	public List<S4Detection> s4DetectionList;

	public List<ImpactedCloneAnalysis> impactedcloneList;

	public List<ImpactedCloneAnalysis> getImpactedcloneList() {
		return impactedcloneList;
	}

	public void setImpactedcloneList(List<ImpactedCloneAnalysis> impactedcloneList) {
		this.impactedcloneList = impactedcloneList;
	}

	public List<S4Detection> getS4DetectionList() {
		return s4DetectionList;
	}

	public void setS4DetectionList(List<S4Detection> s4DetectionList) {
		this.s4DetectionList = s4DetectionList;
	}

	public List<S4cvitr> s4cvitrList;

	public List<S4cvitr> getS4cvitrList() {
		return s4cvitrList;
	}

	public void setS4cvitrList(List<S4cvitr> s4cvitrList) {
		this.s4cvitrList = s4cvitrList;
	}

	private List<Lsmw> lsmwList;

	private Set<String> usageAnalysisObjNameType;
	
	private Set<String> usageAnalysisObjNameTypeReadProg;

	public Set<String> getUsageAnalysisObjNameTypeReadProg() {
		return usageAnalysisObjNameTypeReadProg;
	}

	public void setUsageAnalysisObjNameTypeReadProg(Set<String> usageAnalysisObjNameTypeReadProg) {
		this.usageAnalysisObjNameTypeReadProg = usageAnalysisObjNameTypeReadProg;
	}

	public List<Lsmw> getLsmwList() {
		return lsmwList;
	}

	public void setLsmwList(List<Lsmw> lsmwList) {
		this.lsmwList = lsmwList;
	}

	public List<UsageAnalysis> getUsageAnalysisList() {
		return usageAnalysisList;
	}

	public void setUsageAnalysisList(List<UsageAnalysis> usageAnalysisList) {
		this.usageAnalysisList = usageAnalysisList;
	}

	public List<S4InventoryList> getInventoryList() {
		return inventoryList;
	}

	public void setInventoryList(List<S4InventoryList> inventoryList) {
		this.inventoryList = inventoryList;
	}

	private Map<String, SmodilogFunction> smodilogMapImpMod;

	public Map<String, SmodilogFunction> getSmodilogMapImpMod() {
		return smodilogMapImpMod;
	}

	public void setSmodilogMapImpMod(Map<String, SmodilogFunction> smodilogMapImpMod) {
		this.smodilogMapImpMod = smodilogMapImpMod;
	}

	private List<UsageAnalysis> usageAnalysisList;

	private List<S4InventoryList> inventoryList;

	private List<HanaProfilerStepOutput> hanaProfileStepList;

	public HttpSession session;

	private List<S4CvitAssessment> s4CvitAssessmentList;

	public List<S4CvitAssessment> getS4CvitAssessmentList() {
		return s4CvitAssessmentList;
	}

	public void setS4CvitAssessmentList(List<S4CvitAssessment> s4CvitAssessmentList) {
		this.s4CvitAssessmentList = s4CvitAssessmentList;
	}

	public HttpSession getSession() {
		return session;
	}

	public void setSession(HttpSession session) {
		this.session = session;
	}

	public Map<String, String> resultMap;

	private List<AuctFinalOutput> auctList;

	private List<HanaProfile> listOfHanaProfile;

	private List<OSMigrationFinal> osMigrationList;

	public Map<String, String> resultMapOSMigration;

	public String ruleBase = "CAT";

	private List<String> dsoList;
	private List<String> infocubeList;
	private List<String> webTemplate3List;
	private List<String> webTemplate7List;
	private List<String> workbookIdList;
	private List<String> genuineidList;

	private Map<String, String> dateFormatList = new HashMap<>();

	public Map<String, String> getDateFormatList() {
		return dateFormatList;
	}

	public void setDateFormatList(Map<String, String> dateFormatList) {
		this.dateFormatList = dateFormatList;
	}

	public List<String> getGenuineidList() {
		return genuineidList;
	}

	public void setGenuineidList(List<String> genuineidList) {
		this.genuineidList = genuineidList;
	}

	private List<Rszwtemplate> webTemplate3INAList;

	public List<Rszwtemplate> getWebTemplate3INAList() {
		return webTemplate3INAList;
	}

	public void setWebTemplate3INAList(List<Rszwtemplate> webTemplate3INAList) {
		this.webTemplate3INAList = webTemplate3INAList;
	}

	private List<St03NData> st03nList;

	private List<MetaData> metaDataList;
	
	private Map<String,MetaData> metaDataMap;

	public Map<String, MetaData> getMetaDataMap() {
		return metaDataMap;
	}

	public void setMetaDataMap(Map<String, MetaData> metaDataMap) {
		this.metaDataMap = metaDataMap;
	}
	
	private List<ACNIPZVERComp> acnipList;
	public List<ACNIPZVERComp> getAcnipList() {
		return acnipList;
	}

	public void setAcnipList(List<ACNIPZVERComp> acnipList) {
		this.acnipList = acnipList;
	}

	private List<ComplexityRules> complexityRulesList;

	private List<ExtensionRules> extRulesList;

	private List<UsageAnalysisExt> usageAnalysisExtList;

	private ExtensionRules extensionComments;

	private String meteaDataDescription;

	private List<Rsrwbindex> rsrwbindexList;
	private List<Rsdiobj> rsdiobjList;
	private List<Rsqiset> rsqisetList;
	private List<Rsbohdest> rsbohDestList;
	private List<Rsohcpr> rsohcprList;
	private List<Rsupdinfo> rsupdinfoList;
	private List<Rsts> rstsList;
	private List<Rsds> rsdsList;
	private List<Rsldpio> rsldpioList;
	private List<Rsdcube> rsdcubeInfocubeList;
	private List<Rsdcube> rsdcubeMproList;
	private List<RsantProcess> rsantprocessList;
	private List<Rszwbtmphead> rszwbtmpheadList;
	private List<Rsrrepdir> rsrrepdirINAList;
	private List<Rspcchainattr> rspcchainattrINAList;

	public List<Rspcchainattr> getRspcchainattrINAList() {
		return rspcchainattrINAList;
	}

	public void setRspcchainattrINAList(List<Rspcchainattr> rspcchainattrINAList) {
		this.rspcchainattrINAList = rspcchainattrINAList;
	}

	public List<Rsrrepdir> getRsrrepdirINAList() {
		return rsrrepdirINAList;
	}

	public void setRsrrepdirINAList(List<Rsrrepdir> rsrrepdirINAList) {
		this.rsrrepdirINAList = rsrrepdirINAList;
	}

	public List<Rszwbtmphead> getRszwbtmpheadList() {
		return rszwbtmpheadList;
	}

	public void setRszwbtmpheadList(List<Rszwbtmphead> rszwbtmpheadList) {
		this.rszwbtmpheadList = rszwbtmpheadList;
	}

	public List<RsantProcess> getRsantprocessList() {
		return rsantprocessList;
	}

	public void setRsantprocessList(List<RsantProcess> rsantprocessList) {
		this.rsantprocessList = rsantprocessList;
	}

	public List<Rsdcube> getRsdcubeMproList() {
		return rsdcubeMproList;
	}

	public void setRsdcubeMproList(List<Rsdcube> rsdcubeMproList) {
		this.rsdcubeMproList = rsdcubeMproList;
	}

	public List<Rsdcube> getRsdcubeInfocubeList() {
		return rsdcubeInfocubeList;
	}

	public void setRsdcubeInfocubeList(List<Rsdcube> rsdcubeInfocubeList) {
		this.rsdcubeInfocubeList = rsdcubeInfocubeList;
	}

	public List<Rsldpio> getRsldpioList() {
		return rsldpioList;
	}

	public void setRsldpioList(List<Rsldpio> rsldpioList) {
		this.rsldpioList = rsldpioList;
	}

	public List<Rsds> getRsdsList() {
		return rsdsList;
	}

	public void setRsdsList(List<Rsds> rsdsList) {
		this.rsdsList = rsdsList;
	}

	public List<Rsts> getRstsList() {
		return rstsList;
	}

	public void setRstsList(List<Rsts> rstsList) {
		this.rstsList = rstsList;
	}

	public List<Rsupdinfo> getRsupdinfoList() {
		return rsupdinfoList;
	}

	public void setRsupdinfoList(List<Rsupdinfo> rsupdinfoList) {
		this.rsupdinfoList = rsupdinfoList;
	}

	public List<Rsohcpr> getRsohcprList() {
		return rsohcprList;
	}

	public void setRsohcprList(List<Rsohcpr> rsohcprList) {
		this.rsohcprList = rsohcprList;
	}

	public List<Rsbohdest> getRsbohDestList() {
		return rsbohDestList;
	}

	public void setRsbohDestList(List<Rsbohdest> rsbohDestList) {
		this.rsbohDestList = rsbohDestList;
	}

	public List<Rsqiset> getRsqisetList() {
		return rsqisetList;
	}

	public void setRsqisetList(List<Rsqiset> rsqisetList) {
		this.rsqisetList = rsqisetList;
	}

	public List<Rsdiobj> getRsdiobjList() {
		return rsdiobjList;
	}

	public void setRsdiobjList(List<Rsdiobj> rsdiobjList) {
		this.rsdiobjList = rsdiobjList;
	}

	public List<Rsrwbindex> getRsrwbindexList() {
		return rsrwbindexList;
	}

	public void setRsrwbindexList(List<Rsrwbindex> rsrwbindexList) {
		this.rsrwbindexList = rsrwbindexList;
	}

	public List<String> getWorkbookIdList() {
		return workbookIdList;
	}

	public void setWorkbookIdList(List<String> workbookIdList) {
		this.workbookIdList = workbookIdList;
	}

	public Map<String, String> getResultMap() {
		return resultMap;
	}

	public void setResultMap(Map<String, String> resultMap) {
		this.resultMap = resultMap;
	}

	public String getRuleBase() {
		return ruleBase;
	}

	public void setRuleBase(String ruleBase) {
		this.ruleBase = ruleBase;
	}

	public List<HanaProfile> getListOfHanaProfile() {
		return listOfHanaProfile;
	}

	public void setListOfHanaProfile(List<HanaProfile> listOfHanaProfile) {
		this.listOfHanaProfile = listOfHanaProfile;
	}

	public List<HanaProfilerStepOutput> getHanaProfileStepList() {
		return hanaProfileStepList;
	}

	public void setHanaProfileStepList(List<HanaProfilerStepOutput> hanaProfileStepList) {
		this.hanaProfileStepList = hanaProfileStepList;
	}

	public List<AuctFinalOutput> getAuctList() {
		return auctList;
	}

	public void setAuctList(List<AuctFinalOutput> auctList) {
		this.auctList = auctList;
	}

	public Set<String> getUsageAnalysisObjNameType() {
		return usageAnalysisObjNameType;
	}

	public void setUsageAnalysisObjNameType(Set<String> usageAnalysisObjNameType) {
		this.usageAnalysisObjNameType = usageAnalysisObjNameType;
	}

	public Map<String, String> getResultMapOSMigration() {
		return resultMapOSMigration;
	}

	public void setResultMapOSMigration(Map<String, String> resultMapOSMigration) {
		this.resultMapOSMigration = resultMapOSMigration;
	}

	public List<OSMigrationFinal> getOsMigrationList() {
		return osMigrationList;
	}

	public void setOsMigrationList(List<OSMigrationFinal> osMigrationList) {
		this.osMigrationList = osMigrationList;
	}

	public List<String> getDsoList() {
		return dsoList;
	}

	public void setDsoList(List<String> dsoList) {
		this.dsoList = dsoList;
	}

	public List<String> getInfocubeList() {
		return infocubeList;
	}

	public void setInfocubeList(List<String> infocubeList) {
		this.infocubeList = infocubeList;
	}

	public List<String> getWebTemplate3List() {
		return webTemplate3List;
	}

	public void setWebTemplate3List(List<String> webTemplate3List) {
		this.webTemplate3List = webTemplate3List;
	}

	public List<String> getWebTemplate7List() {
		return webTemplate7List;
	}

	public void setWebTemplate7List(List<String> webTemplate7List) {
		this.webTemplate7List = webTemplate7List;
	}

	public List<St03NData> getSt03nList() {
		return st03nList;
	}

	public void setSt03nList(List<St03NData> st03nList) {
		this.st03nList = st03nList;
	}
	
	public List<MetaData> getMetaDataList() {
		return metaDataList;
	}

	public void setMetaDataList(List<MetaData> metaDataList) {
		this.metaDataList = metaDataList;
	}

	public List<ComplexityRules> getComplexityRulesList() {
		return complexityRulesList;
	}

	public void setComplexityRulesList(List<ComplexityRules> complexityRulesList) {
		this.complexityRulesList = complexityRulesList;
	}

	public List<ExtensionRules> getExtRulesList() {
		return extRulesList;
	}

	public void setExtRulesList(List<ExtensionRules> extRulesList) {
		this.extRulesList = extRulesList;
	}

	public List<UsageAnalysisExt> getUsageAnalysisExtList() {
		return usageAnalysisExtList;
	}

	public void setUsageAnalysisExtList(List<UsageAnalysisExt> usageAnalysisExtList) {
		this.usageAnalysisExtList = usageAnalysisExtList;
	}

	public ExtensionRules getExtensionComments() {
		return extensionComments;
	}

	public void setExtensionComments(ExtensionRules extensionComments) {
		this.extensionComments = extensionComments;
	}

	public String getMeteaDataDescription() {
		return meteaDataDescription;
	}

	public void setMeteaDataDescription(String meteaDataDescription) {
		this.meteaDataDescription = meteaDataDescription;
	}
}