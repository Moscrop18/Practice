package com.accenture.osmigration.dao;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.commons.collections.CollectionUtils;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.accenture.Aadt.models.OSMigrationFinal;
import com.accenture.Aadt.models.OSMigrationFinalFilepath_Download;
import com.accenture.Aadt.models.OSMigrationFinalLogicalCMD_Download;
import com.accenture.Aadt.models.OSMigrationFinal_Download;
import com.accenture.displaygrid.model.DBConfig;

@Repository
public class OSMigrationDAOImpl implements OSMigrationDAO {
	
	final Logger logger = LoggerFactory.getLogger(OSMigrationDAOImpl.class);
	
	private SessionFactory sessionFactory;
	
	private HibernateTemplate hibernateTemplate;
	
	@Autowired
	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
		
	@Override
	public Map<String, String> getOprValuesDBOSMigration() {
		Session session = null;
		final Map<String,String> resultMap = new HashMap<String,String>();
		try {
			session = sessionFactory.openSession();
			String hql = "SELECT ID, Opcode, Remediation_Category, Issue_Category, Issue_Sub_Category, Operation, Solution, Impact, Complexity, "
					+ "Automation_Status  from OS_MIGRATION_DATA";
			Query query = session.createSQLQuery(hql);
			@SuppressWarnings("unchecked")
			List<Object[]> resultList = query.list();
				
			if(CollectionUtils.isNotEmpty(resultList))
			{	
				for(Object[] object : resultList)
				{
					Integer id = (Integer) (object[0]);
					String operationCode = (String) object[1];
					String remCategory = (String) object[2];
					String issueCategory = (String) object[3];
					String issueSubCategory = (String) object[4];
				    String operation = (String) object[5];
					String solution = (String) object[6];
					String impact = (String) object[7];
					String compelxity = (String) object[8];
					String automationStatus = (String) object[9];
					String data = id + "|" + operationCode + "|" + remCategory + "|" + issueCategory +
							"|" + issueSubCategory + "|" + operation + "|" + solution + "|" + impact
							+ "|" + compelxity + "|" + automationStatus;						 
					resultMap.put(operationCode, data);			
				}
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		} finally {
			session.close();
		}
			return resultMap;
	}
	
	@Override
	public String osMigrationBatchInsert(List<OSMigrationFinal> osMigrationList, HttpSession session)
			throws Exception {

		
		final String INSERT_SQL = "INSERT INTO OSMIGRATION_FINAL "
				+ "(REQUEST_ID, OBJ_TYPE, OBJ_NAME, OBJ_TYPE_NAME, SUB_TYPE, READ_PROGRAM, OBJ_PACKAGE, OPERCD, LINE_NO, STATEMENT, INFO,"
				+ "SKIP, SKIP_REASON, SELECT_LINE, REM_CATEGORY, ISSUE_CATEGORY, ISSUE_SUBCATEGORY, HIGH_LVL_DESC, IMPACT, "
				+ "AUTOMATION_STATUS, COMPLEXITY, USED, RICEF_CATEGORY,RICEF_SUB_CATEGORY,EXTERNAL_NAMESPACE) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		final String INSERT_SQL_FinalCMD = "INSERT INTO OSMIGRATION_FINAL_LOGICAL_CMD_INTERMEDIATE "
				+ "(REQUEST_ID, READ_PROGRAM, STATEMENT, INFO, REM_CATEGORY, ISSUE_CATEGORY, ISSUE_SUBCATEGORY, HIGH_LVL_DESC, IMPACT, " 
				+ "AUTOMATION_STATUS, COMPLEXITY) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";


		final String INSERT_SQL_FilePath = "INSERT INTO OSMIGRATION_FINAL_FILE_PATH_INTERMEDIATE "
				+ "(REQUEST_ID, OBJ_NAME, SUB_TYPE, STATEMENT, INFO, SKIP, SKIP_REASON, REM_CATEGORY, HIGH_LVL_DESC, IMPACT)"
				+ " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		java.sql.PreparedStatement stmtCMD = null;
		java.sql.PreparedStatement stmtPath = null;

		
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter1 = 1,counter2 = 1,counter3 = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				stmtCMD = conn.prepareStatement(INSERT_SQL_FinalCMD);
				stmtPath = conn.prepareStatement(INSERT_SQL_FilePath);

				int batch1 = 1, batch2 = 1, batch3 = 1;

				for (OSMigrationFinal osMigration : osMigrationList) {
					String opcode=osMigration.getOperationCode();
					
					if (opcode.equalsIgnoreCase("201") || opcode.equalsIgnoreCase("202") || opcode.equalsIgnoreCase("203")) {
						// Opcode 201,202,203 Impacted due to OS Migration
						stmt.setLong(1, osMigration.getRequestID());
						stmt.setString(2, osMigration.getObjType());
						stmt.setString(3, osMigration.getObjName());
						stmt.setString(4, osMigration.getObjTypeName());
						stmt.setString(5, osMigration.getSubType());
						stmt.setString(6, osMigration.getReadProgram());
						stmt.setString(7, osMigration.getObjPackage());
						stmt.setString(8, osMigration.getOperationCode());
						stmt.setLong(9, osMigration.getLineNo());
						stmt.setString(10, osMigration.getStatement());
						stmt.setString(11, osMigration.getInfo());
						stmt.setString(12, osMigration.getSkip());
						stmt.setString(13, osMigration.getSkipReason());
						stmt.setString(14, osMigration.getSelectLine());
						stmt.setString(15, osMigration.getRemCategory());
						stmt.setString(16, osMigration.getIssueCategory());
						stmt.setString(17, osMigration.getIssueSubcategory());
						stmt.setString(18, osMigration.getHighLvlDesc());
						stmt.setString(19, osMigration.getImpact());
						stmt.setString(20, osMigration.getAutomationStatus());
						stmt.setString(21, osMigration.getComplexity());
						stmt.setString(22, osMigration.getUsed());
						stmt.setString(23, osMigration.getRicefCategory());
						stmt.setString(24, osMigration.getRicefSubCategory());
						stmt.setString(25, osMigration.getExternalNamespace());
						stmt.addBatch();
						counter1++;
						if (counter1 % 10000 == 0) {
							counter1 = 0;
							stmt.executeBatch();
							conn.commit();
							logger.info("Batch " + (batch1++) + " for Set 1 Executed Successfully !!!");
						}
					}else if (opcode.equalsIgnoreCase("205")) {
						// Opcode 205 OS Migration CMD Logic
						stmtCMD.setLong(1, osMigration.getRequestID());
						stmtCMD.setString(2, osMigration.getReadProgram());
						stmtCMD.setString(3, osMigration.getStatement());
						stmtCMD.setString(4, osMigration.getInfo());
						stmtCMD.setString(5, osMigration.getRemCategory());
						stmtCMD.setString(6, osMigration.getIssueCategory());
						stmtCMD.setString(7, osMigration.getIssueSubcategory());
						stmtCMD.setString(8, osMigration.getHighLvlDesc());
						stmtCMD.setString(9, osMigration.getImpact());
						stmtCMD.setString(10, osMigration.getAutomationStatus());
						stmtCMD.setString(11, osMigration.getComplexity());

						stmtCMD.addBatch();
						counter2++;
						if (counter2 % 10000 == 0) {
							counter2 = 0;
							stmtCMD.executeBatch();
							conn.commit();
							logger.info("Batch " + (batch2++) + " for Set 2 Executed Successfully !!!");
						}
					}else if (opcode.equalsIgnoreCase("204")) {
						// Opcode 204 OS Migration File Path
						stmtPath.setLong(1, osMigration.getRequestID());
						stmtPath.setString(2, osMigration.getObjName());
						stmtPath.setString(3, osMigration.getSubType());
						stmtPath.setString(4, osMigration.getStatement());
						stmtPath.setString(5, osMigration.getInfo());
						stmtPath.setString(6, osMigration.getSkip());
						stmtPath.setString(7, osMigration.getSkipReason());
						stmtPath.setString(8, osMigration.getRemCategory());
						stmtPath.setString(9, osMigration.getHighLvlDesc());
						stmtPath.setString(10, osMigration.getImpact());
			
						stmtPath.addBatch();
						counter3++;
						if (counter3 % 10000 == 0) {
							counter3 = 0;
							stmtPath.executeBatch();
							conn.commit();
							logger.info("Batch " + (batch3++) + " for Set 3 Executed Successfully !!!");
						}
					}
				}

				stmt.executeBatch();
				stmtCMD.executeBatch();
				stmtPath.executeBatch();
				conn.commit();
				logger.info("OS Migration Data Inserted Successfully !!!");
			} catch (SQLException e) {
				result = "Failure in Inserting Data into OS Migration DB ...";
				logger.error(result + e);
				throw new Exception(result);
			}
		} catch (Exception e) {
			result = "Failure in Getting Connection";
			logger.error(result + e);
			throw new Exception(result);
		} finally {
			stmt.close();
			stmtCMD.close();
			stmtPath.close();
			conn.close();
		}

		return result;
	}

	@Override
	public List<OSMigrationFinal_Download> getOSMigrationList(long requestId) {	
		logger.info("Getting OS Migration List");
		
		Session session = this.hibernateTemplate.getSessionFactory().openSession();
		Criteria criteria = session.createCriteria(OSMigrationFinal_Download.class);
		
		ProjectionList projectionList=Projections.projectionList();
		
		projectionList.add(Projections.property("objType"),"objType");
		projectionList.add(Projections.property("objName"),"objName");
		projectionList.add(Projections.property("subType"),"subType");
		projectionList.add(Projections.property("readProgram"),"readProgram");
		projectionList.add(Projections.property("objPackage"),"objPackage");
		projectionList.add(Projections.property("operationCode"),"operationCode");
		projectionList.add(Projections.property("lineNo"),"lineNo");
		projectionList.add(Projections.property("statement"),"statement");
		projectionList.add(Projections.property("remCategory"),"remCategory");
		projectionList.add(Projections.property("issueCategory"),"issueCategory");
		projectionList.add(Projections.property("issueSubcategory"),"issueSubcategory");
		projectionList.add(Projections.property("info"),"info");
		projectionList.add(Projections.property("highLvlDesc"),"highLvlDesc");
		projectionList.add(Projections.property("impact"),"impact");
		projectionList.add(Projections.property("automationStatus"),"automationStatus");
		projectionList.add(Projections.property("complexity"),"complexity");
		projectionList.add(Projections.property("used"),"used");
		projectionList.add(Projections.property("skipReason"),"skipReason");
		projectionList.add(Projections.property("skip"),"skip");
		projectionList.add(Projections.property("selectLine"),"selectLine");

		projectionList.add(Projections.property("ricefCategory"),"ricefCategory");
		projectionList.add(Projections.property("ricefSubCategory"),"ricefSubCategory");
		projectionList.add(Projections.property("externalNamespace"),"externalNamespace");

		criteria.add(Restrictions.eq("requestID", requestId));
		criteria.setProjection(projectionList);
		criteria.setResultTransformer(Transformers.aliasToBean(OSMigrationFinal_Download.class));
		@SuppressWarnings("unchecked")
		List<OSMigrationFinal_Download> osMigrationList = criteria.list();
		
		logger.info("List Size " + osMigrationList.size());
		session.close();
		
		return osMigrationList;
	}
	@Override
	public List<OSMigrationFinalLogicalCMD_Download> getOSMigrationLogCMDList(long requestId) {	
		logger.info("Getting OS Migration List");
		
		Session session = this.hibernateTemplate.getSessionFactory().openSession();
		Criteria criteria = session.createCriteria(OSMigrationFinalLogicalCMD_Download.class);
		
		ProjectionList projectionList=Projections.projectionList();

		projectionList.add(Projections.property("readProgram"),"readProgram");
		projectionList.add(Projections.property("statement"),"statement");
		projectionList.add(Projections.property("remCategory"),"remCategory");
		projectionList.add(Projections.property("issueCategory"),"issueCategory");
		projectionList.add(Projections.property("issueSubcategory"),"issueSubcategory");
		projectionList.add(Projections.property("info"),"info");
		projectionList.add(Projections.property("highLvlDesc"),"highLvlDesc");
		projectionList.add(Projections.property("impact"),"impact");
		projectionList.add(Projections.property("automationStatus"),"automationStatus");
		projectionList.add(Projections.property("complexity"),"complexity");

		criteria.add(Restrictions.eq("requestID", requestId));
		criteria.setProjection(projectionList);
		criteria.setResultTransformer(Transformers.aliasToBean(OSMigrationFinalLogicalCMD_Download.class));
		@SuppressWarnings("unchecked")
		List<OSMigrationFinalLogicalCMD_Download> osMigrationList = criteria.list();
		
		logger.info("List Size " + osMigrationList.size());
		session.close();
		
		return osMigrationList;
	}
	@Override
	public List<OSMigrationFinalFilepath_Download> getOSMigrationFilePathList(long requestId) {	
		logger.info("Getting OS Migration List");
		
		Session session = this.hibernateTemplate.getSessionFactory().openSession();
		Criteria criteria = session.createCriteria(OSMigrationFinalFilepath_Download.class);
		
		ProjectionList projectionList=Projections.projectionList();
		
		projectionList.add(Projections.property("objName"),"objName");
		projectionList.add(Projections.property("subType"),"subType");
		projectionList.add(Projections.property("statement"),"statement");
		projectionList.add(Projections.property("remCategory"),"remCategory");
		projectionList.add(Projections.property("info"),"info");
		projectionList.add(Projections.property("highLvlDesc"),"highLvlDesc");
		projectionList.add(Projections.property("impact"),"impact");
		projectionList.add(Projections.property("skipReason"),"skipReason");
		projectionList.add(Projections.property("skip"),"skip");

		criteria.add(Restrictions.eq("requestID", requestId));
		criteria.setProjection(projectionList);
		criteria.setResultTransformer(Transformers.aliasToBean(OSMigrationFinalFilepath_Download.class));
		@SuppressWarnings("unchecked")
		List<OSMigrationFinalFilepath_Download> osMigrationList = criteria.list();
		
		logger.info("List Size " + osMigrationList.size());
		session.close();
		
		return osMigrationList;
	}
}
