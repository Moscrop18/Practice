package com.accenture.osmigration.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.accenture.Aadt.models.OSMigrationFinal;
import com.accenture.Aadt.models.OSMigrationFinalFilepath_Download;
import com.accenture.Aadt.models.OSMigrationFinalLogicalCMD_Download;
import com.accenture.Aadt.models.OSMigrationFinal_Download;
import com.accenture.client.dao.RequestFormDAO;
import com.accenture.client.model.RequestForm;
import com.accenture.constant.Hana_Profiler_Constant;
import com.accenture.exceptions.ST03DataAnalysisException;
import com.accenture.osmigration.dao.OSMigrationDAO;
import com.accenture.reader.xlsx.St03ReaderXlsx;

@Service
public class OSMigrationServiceImpl implements OSMigrationService {

	@Autowired
	private OSMigrationDAO osMigrationDAO;

	@Autowired
	private RequestFormDAO requestDetails;

	final Logger logger = LoggerFactory.getLogger(OSMigrationServiceImpl.class);

	public boolean analyseOSMigrationData(final long requestId, String toolName, HttpSession session) throws Exception {
		boolean st03Status = false;
		try {
			// adding operation data
			St03ReaderXlsx.getHm().setResultMapOSMigration(osMigrationDAO.getOprValuesDBOSMigration());
			// processing OS Migration data
			List<OSMigrationFinal> osMigrationList = processOSMigration(St03ReaderXlsx.getHm().getOsMigrationList(),
					St03ReaderXlsx.getHm().getResultMapOSMigration(), session, requestId);
			osMigrationDAO.osMigrationBatchInsert(osMigrationList, session);
			st03Status = true;
		} catch (ST03DataAnalysisException e) {
			logger.error(e.getMessage());
			throw new Exception(e.getMessage());
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			logger.error("Error in analyseOSMigrationData :: ", e);
			throw new Exception(e.getMessage());
		}

		return st03Status;
	}

	private List<OSMigrationFinal> processOSMigration(List<OSMigrationFinal> osMigrationList,
			Map<String, String> opCodeResultMap, HttpSession session, final Long requestId) throws SQLException {
		for (OSMigrationFinal osMigration : osMigrationList) {

			String opCode = osMigration.getOperationCode();
			String skip = osMigration.getSkip();
			String remCat = "", issueCat = "", issueSubCat = "", highLvlDesc = "", impact = "", complexity = "",
					autoStatus = "", operation = "";

			if (opCode != null && !opCode.equals("")) {
				String oprDataValues = opCodeResultMap.get(opCode);
				if (oprDataValues != null && !oprDataValues.equals("")) {
					String[] oprValuesArr = oprDataValues.split("\\|");

					remCat = oprValuesArr[2];
					issueCat = oprValuesArr[3];
					issueSubCat = oprValuesArr[4];
					operation = oprValuesArr[5];
					highLvlDesc = oprValuesArr[6];
					impact = oprValuesArr[7];
					complexity = oprValuesArr[8];
					autoStatus = oprValuesArr[9];
				}

				osMigration.setIssueCategory(issueCat);
				osMigration.setIssueSubcategory(issueSubCat);
				osMigration.setComplexity(complexity);
				osMigration.setAutomationStatus(autoStatus);
				osMigration.setInfo(operation);

				final RequestForm requestForm = requestDetails.getRequestObj(requestId);
				if (opCode.equalsIgnoreCase("201") || opCode.equalsIgnoreCase("202")
						|| opCode.equalsIgnoreCase("203")) {
					if (MapUtils.isNotEmpty(St03ReaderXlsx.getHm().getMetaDataMap())) {
						if (null != St03ReaderXlsx.getHm().getMetaDataMap().get(osMigration.getObjTypeName())) {
							osMigration.setRicefCategory(St03ReaderXlsx.getHm().getMetaDataMap()
									.get(osMigration.getObjTypeName()).getRicefCategory());
						}

						if (null != St03ReaderXlsx.getHm().getMetaDataMap().get(osMigration.getObjTypeName())
								&& null != St03ReaderXlsx.getHm().getMetaDataMap().get(osMigration.getObjTypeName())
										.getRicefSubCategory()) {
							osMigration.setRicefSubCategory(St03ReaderXlsx.getHm().getMetaDataMap()
									.get(osMigration.getObjTypeName()).getRicefSubCategory());
						}
					}
				}

				if ("Windows".equalsIgnoreCase(requestForm.getTarOSVer()) && "201".equalsIgnoreCase(opCode)) {
					osMigration.setRemCategory("Optional");
				}

				if (StringUtils.isBlank(osMigration.getRicefCategory())
						&& "SSFO".equalsIgnoreCase(osMigration.getObjType())) {
					osMigration.setRicefCategory("FORMS");
					osMigration.setRicefSubCategory("Smartforms");
				}

				if (StringUtils.isBlank(osMigration.getRicefCategory())
						&& "SFPF".equalsIgnoreCase(osMigration.getObjType())) {
					osMigration.setRicefCategory("FORMS");
					osMigration.setRicefSubCategory("Adobe");
				}

				if ("AQQU".equalsIgnoreCase(osMigration.getObjType())) {
					osMigration.setRicefCategory("Others");
					osMigration.setRicefSubCategory("Configurable Report");
				}
				
				if (StringUtils.isBlank(osMigration.getRicefCategory()))
					osMigration.setRicefCategory(Hana_Profiler_Constant.OTHERS);

				if (opCode.equalsIgnoreCase("204")) {
					if (skip.equalsIgnoreCase("X")) {
						osMigration.setRemCategory("Optional");
						osMigration.setHighLvlDesc("Check if existing target path is correct");
						osMigration.setImpact("Low");
						osMigration.setSkipReason(requestForm.getTarOSVer() + " path already exists");
					} else {
						osMigration.setRemCategory("Mandatory");
						osMigration.setHighLvlDesc("Maintain file path for " + requestForm.getTarOSVer());
						osMigration.setImpact("High");
						osMigration.setSkipReason(requestForm.getTarOSVer() + " path doesn't exist");
					}

					osMigration.setSkip(skip);
				} else {
					osMigration.setRemCategory(remCat);
					osMigration.setHighLvlDesc(highLvlDesc);
					osMigration.setImpact(impact);
				}
			}
		}

		return osMigrationList;
	}

	@Override
	public List<OSMigrationFinal_Download> getOSMigrationList(long requestId) {
		List<OSMigrationFinal_Download> osMigrationList = osMigrationDAO.getOSMigrationList(requestId);
		return osMigrationList;
	}

	@Override
	public List<OSMigrationFinalLogicalCMD_Download> getOSMigrationLogCMDList(long requestId) {
		List<OSMigrationFinalLogicalCMD_Download> osMigrationList = osMigrationDAO.getOSMigrationLogCMDList(requestId);
		return osMigrationList;
	}

	@Override
	public List<OSMigrationFinalFilepath_Download> getOSMigrationFilePathList(long requestId) {
		List<OSMigrationFinalFilepath_Download> osMigrationList = osMigrationDAO.getOSMigrationFilePathList(requestId);
		return osMigrationList;
	}

}
