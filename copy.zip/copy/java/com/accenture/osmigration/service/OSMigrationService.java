package com.accenture.osmigration.service;

import java.util.List;

import javax.servlet.http.HttpSession;

import com.accenture.Aadt.models.OSMigrationFinal_Download;
import com.accenture.Aadt.models.OSMigrationFinalFilepath_Download;
import com.accenture.Aadt.models.OSMigrationFinalLogicalCMD_Download;

public interface OSMigrationService {
	
	public boolean analyseOSMigrationData(final long requestId,String toolName,HttpSession session) throws Exception;
	public List<OSMigrationFinal_Download> getOSMigrationList(final long requestId);
	public List<OSMigrationFinalLogicalCMD_Download> getOSMigrationLogCMDList(long requestId);
	public List<OSMigrationFinalFilepath_Download> getOSMigrationFilePathList(long requestId);

}
