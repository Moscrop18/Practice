package com.accenture.aadtPoc;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpSession;

import com.accenture.Aadt.models.ImpactedObjList;
import com.accenture.S4.models.S4AffectCustomField;
import com.accenture.S4.models.S4DetailReportComplexity;
import com.accenture.S4.models.S4DetailReportRemediation;
import com.accenture.S4.models.S4HanaProfiler;
import com.accenture.S4.models.S4InventoryList;
import com.accenture.S4.models.S4OutputMgmt;
import com.accenture.displaygrid.model.HanaProfile;


public interface RequestMasterCalculatorDao {

	public void insertS4InventoryList(List<S4InventoryList> daoinsertinventory_List,HttpSession session,Long requestID) throws SQLException;
	public void insertimpactedObjectList(List<ImpactedObjList> daoimpactedObjectList,HttpSession session,Long requestID) throws SQLException;
	public void insertdrdbchangeList(List<HanaProfile> drdbchangeList,HttpSession session,Long requestID) throws SQLException;
	public void insertdrs4SimplificationOneList(List<S4HanaProfiler> drs4SimplificationOneList,HttpSession session,Long requestID) throws SQLException;
	public void insertoutputManagementList(List<S4OutputMgmt> outputManagementList,HttpSession session,Long requestID) throws SQLException;
	public void insertaffectedbyCustomFieldsList(List<S4AffectCustomField> affectedbyCustomFieldsList,HttpSession session,Long requestID) throws SQLException;
	public void insertdrs4SimplificationTwoList(List<S4DetailReportComplexity> drs4SimplificationTwoList,HttpSession session,Long requestID) throws SQLException;
	public void insertdrs4SimplificationThreeList(List<S4DetailReportRemediation> drs4SimplificationThreeList,HttpSession session,Long requestID) throws SQLException;
}
