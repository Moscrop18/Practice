package com.accenture.aadtPoc;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.poi.ss.usermodel.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.Aadt.models.ImpactedObjList;
import com.accenture.S4.models.S4AffectCustomField;
import com.accenture.S4.models.S4DetailReportComplexity;
import com.accenture.S4.models.S4DetailReportRemediation;
import com.accenture.S4.models.S4HanaProfiler;
import com.accenture.S4.models.S4InventoryList;
import com.accenture.S4.models.S4OutputMgmt;
import com.accenture.constant.Hana_Profiler_Constant;
import com.accenture.controller.AbstractBaseController;
import com.accenture.displaygrid.model.DBConfig;
import com.accenture.displaygrid.model.HanaProfile;
import com.accenture.master.ProcessedRequestDetail;
import com.accenture.testingscope.model.ExtractedDatapojo;
import com.accenture.testingscope.model.Testingscopepojo;
import com.accenture.utility.odatafiori.AppsType;
import com.accenture.utility.odatafiori.DBConfigFiori;
import com.accenture.utility.odatafiori.OdataFiori_Constants;


public class RequestMasterCalculatorDaoImpl implements RequestMasterCalculatorDao {
	
	final Logger logger=LoggerFactory.getLogger(RequestMasterCalculatorDaoImpl.class);

	public void insertS4InventoryList(List<S4InventoryList> daoinsertinventoryList,HttpSession session, Long requestID) throws SQLException{
	
		logger.info("daoinsertinventoryList SIZEE"+daoinsertinventoryList.size());
	    
			final String INSERT_SQL = "INSERT INTO s4_inventory_list "
			+ "(OBJ_TYPE,OBJ_NAME,REQUEST_ID,Used) values ( ?, ?, ?, ?)";
			java.sql.Connection conn = null;
			java.sql.PreparedStatement stmt = null;
			try {
				conn = DBConfig.getJDBCConnection(session);
				int counter = 1;
				conn.setAutoCommit(false);
			
				try {
					stmt = conn.prepareStatement(INSERT_SQL);
					int batch = 1;
				
					for (S4InventoryList s4inventoryList : daoinsertinventoryList) {
						
						stmt.setString(1, s4inventoryList.getObjType());
						stmt.setString(2, s4inventoryList.getObjName());
					    stmt.setLong(3, requestID);
						stmt.setString(4, s4inventoryList.getUsage());
						
						  //Add statement to batch
		                  stmt.addBatch();
		                  counter++;
		                  //Execute batch of 1000 records
		                  if(counter%1000==0){
		                	 counter=0;
		                     stmt.executeBatch();
		                     conn.commit();
		                     logger.info("Batch "+(batch++)+" executed successfully");
		                 }
		               }	        	  
		        	  	  stmt.executeBatch();
		                  conn.commit();
		                  logger.info("Final batch executed successfully");
		                 		                  
				} catch (Exception e) {
					conn.rollback();
		            logger.debug("Transaction rollback...");
					logger.error("FAILURE in insert");
   					logger.error(e.getMessage());
				}
			} catch (Exception e) {
				logger.error("FAILURE in Getting Connection");
                logger.error(e.getMessage());
			} finally {
				stmt.close();
				conn.close();
			}					
		}
	
	public void  insertimpactedObjectList(List<ImpactedObjList> daoimpactedObjectList,HttpSession session, Long requestID) throws SQLException{
		
		final String INSERT_SQL = "INSERT INTO impact_obj_list "

					+ "(OBJ_TYPE,OBJ_NAME,Used,Errors_In_Existing_System,DB_Impact,S4_Simplification,Odata,REQUEST_ID) values (?, ?, ?,?,?,?,?,?)";

			java.sql.Connection conn = null;
			java.sql.PreparedStatement stmt = null;
			try {
				conn = DBConfig.getJDBCConnection(session);
				int counter = 1;
				conn.setAutoCommit(false);
				try {
					stmt = conn.prepareStatement(INSERT_SQL);
					int batch = 1;
					for (ImpactedObjList impactedObjList : daoimpactedObjectList) {
						
						stmt.setString(1, impactedObjList.getOBJ_TYPE());
						stmt.setString(2, impactedObjList.getOBJ_NAME());
					    stmt.setString(3, impactedObjList.getUsed());
						//stmt.setString(4, impactedObjList.getDIALOG_STEPS());
						stmt.setString(4, impactedObjList.getErrors_In_Existing_System());
						stmt.setString(5, impactedObjList.getDB_Impact());
					    stmt.setString(6, impactedObjList.getS4_Simplification());
						stmt.setString(7, impactedObjList.getOdata());
						stmt.setLong(8,requestID);
						// Add statement to batch
						stmt.addBatch();
						counter++;
						// Execute batch of 1000 records
						if (counter % 1000 == 0) {
							counter = 0;
							stmt.executeBatch();
							conn.commit();
				  logger.info("Batch " + (batch++) + " executed successfully");
				}
					}
					stmt.executeBatch();
					conn.commit();
					logger.info("ImpactedObjList Data From Excel INSERTED SUCCESSFULLY");

				} catch (Exception e) {
					  conn.rollback();
		              logger.debug("Transaction rollback...");
					  logger.error("FAILURE in insert");
					  logger.error(e.getMessage());
				}
			} catch (Exception e) {
				logger.error("FAILURE in Getting Connection");
				logger.error(e.getMessage());
			} finally {
				stmt.close();
				conn.close();
			}
		}
	
	public void insertdrdbchangeList(List<HanaProfile> drdbchangeList,HttpSession session, Long requestID) throws SQLException{
		
		logger.info("drdbChange Size"+drdbchangeList.size());
		
		final String INSERT_SQL = "INSERT INTO final_output "
					+ "(Object_Type,Obj_Name,Sub_Type,ReadProgram,OBJ_PACKAGE,Opertaion,Line_Number,code,SEL_LINE,Category,Subcategory,IssueSecondSubCat,Info,high_lvl_desc,Levels,TABLES_COLUMN,Joins,Table_Type,Where_Condition,Join_Type,impact,automation_status,COMPLEXITY,operation_code,Used_Unused,COMMENT_C,Request_ID,SKIP) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {
			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;
				for (HanaProfile drdbchange_List : drdbchangeList) {
					
					stmt.setString(1, drdbchange_List.getObject_Type());
					stmt.setString(2, drdbchange_List.getObj_Name());
				    stmt.setString(3, drdbchange_List.getSub_Type());
					stmt.setString(4, drdbchange_List.getReadProgram());
					stmt.setString(5, drdbchange_List.getOBJ_PACKAGE());
					stmt.setString(6, drdbchange_List.getOpertaion());
				    stmt.setInt(7, drdbchange_List.getLine_Number());
					stmt.setString(8, drdbchange_List.getCode());
					stmt.setString(9, drdbchange_List.getSel_Line());
					stmt.setString(10, drdbchange_List.getCategory());
				    stmt.setString(11, drdbchange_List.getSubcategory());
					stmt.setString(12, drdbchange_List.getIssueSecondSubCat());
					stmt.setString(13, drdbchange_List.getInfo());
					stmt.setString(14, drdbchange_List.getHigh_lvl_desc());
				    stmt.setInt(15, drdbchange_List.getLevels());
					stmt.setString(16, drdbchange_List.getTables());
					stmt.setString(17, drdbchange_List.getJoins());
					stmt.setString(18, drdbchange_List.getTable_Type());
				    stmt.setString(19, drdbchange_List.getWhere_Condition());
					stmt.setString(20, drdbchange_List.getJoin_Type());
					stmt.setString(21, drdbchange_List.getImpact());
					stmt.setString(22, drdbchange_List.getAutomation_status());
				    stmt.setString(23, drdbchange_List.getCOMPLEXITY());
					stmt.setString(24, drdbchange_List.getOperation_code());
					stmt.setString(25, drdbchange_List.getUsed_Unused());
				    stmt.setString(26, drdbchange_List.getSkipReason());
					stmt.setLong(27, requestID);
					stmt.setString(28, drdbchange_List.getSkip());
					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 1000 records
					if (counter % 1000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}					
					}

				stmt.executeBatch();
            	conn.commit();
                logger.info("drdbchangeList Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				 logger.error("FAILURE in insert");
				 conn.rollback();
	             logger.debug("Transaction rollback...");
                 logger.error(e.getMessage());
			}

		} catch (Exception e) {
			logger.error("FAILURE in Getting Connection");
			logger.error(e.getMessage());
		} finally {
			stmt.close();
			conn.close();
		}
	}
	
	public void insertdrs4SimplificationOneList(List<S4HanaProfiler> drs4SimplificationOneList,HttpSession session, Long requestID) throws SQLException{
	 logger.info("IN DAOIMPL insertdrs4SimplificationOneList SIZE"+drs4SimplificationOneList.size());
		
		final String INSERT_SQL = "INSERT INTO s4_final_output "
				+ "(TYPE,OBJ_NAME,METHOD,READ_PROG,PCKG,OPERATIONS,LINE_NO,STMT,SELECT_LINE,IMPACTED_OBJ_TYPE,IMPACT_REASON,DESC_OF_CHANGE,SAP_NOTES,SOLUTION_STEPS,complexity,Impact,ISSUE_CATEGORY,ERROR_CATEGORY,TRIGGER_OBJ,Trigger_Object,Remediation_Category,SAP_SIMP_LIST,APP_COMPONENT,SAP_SIMPL_CATEGORY,ITEM_AREA,USED,REQUEST_ID) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
    	java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {
			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;
				for (S4HanaProfiler drs4SimplificationOne_List : drs4SimplificationOneList) {
					stmt.setString(1,drs4SimplificationOne_List.getType());
					stmt.setString(2,drs4SimplificationOne_List.getObjName());
					stmt.setString(3,drs4SimplificationOne_List.getMethod());
					stmt.setString(4,drs4SimplificationOne_List.getREAD_PROG());
					stmt.setString(5,drs4SimplificationOne_List.getPckg());
					stmt.setString(6,drs4SimplificationOne_List.getOperations());
					stmt.setInt(7,drs4SimplificationOne_List.getLineNo());
					stmt.setString(8,drs4SimplificationOne_List.getStmt());
					stmt.setString(9,drs4SimplificationOne_List.getSELECT_LINE());		
					stmt.setString(10,drs4SimplificationOne_List.getImpactedObjType());
					stmt.setString(11,drs4SimplificationOne_List.getImpactReason());
					stmt.setString(12,drs4SimplificationOne_List.getDescOfChange());
					stmt.setString(13,drs4SimplificationOne_List.getSapNotes());
					stmt.setString(14,drs4SimplificationOne_List.getSolutionSteps());
					stmt.setString(15,drs4SimplificationOne_List.getComplexity());					
					stmt.setString(16,drs4SimplificationOne_List.getImpact());					
					stmt.setString(17,drs4SimplificationOne_List.getIssueCategory());					
					stmt.setString(18,drs4SimplificationOne_List.getErrorCategory());					
					stmt.setString(19,drs4SimplificationOne_List.getTriggerObj());
					stmt.setString(20,drs4SimplificationOne_List.getTrigger_Object());
					stmt.setString(21,drs4SimplificationOne_List.getRemediationCategory());
					stmt.setString(22,drs4SimplificationOne_List.getSapSimpListChapter());
					stmt.setString(23,drs4SimplificationOne_List.getApplicationComponent());
					stmt.setString(24,drs4SimplificationOne_List.getSapSimplCategry());
					stmt.setString(25,drs4SimplificationOne_List.getItemArea());
					stmt.setString(26,drs4SimplificationOne_List.getUsed());
					stmt.setLong(27,requestID);
					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 1000 records
					if (counter % 1000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}					
					}

				stmt.executeBatch();
           		conn.commit();
				logger.info("drs4SimplificationOneList Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				 logger.error("FAILURE in insert");
				 conn.rollback();
	             logger.debug("Transaction rollback...");
  				 logger.error(e.getMessage());
			}
		} catch (Exception e) {
			logger.error("FAILURE in Getting Connection");
			logger.error(e.getMessage());
		} finally {
			stmt.close();
			conn.close();
		}		
	}
	
	public void insertoutputManagementList(List<S4OutputMgmt> outputManagementList,HttpSession session, Long requestID) throws SQLException{
			 
		 final String INSERT_SQL = "INSERT INTO s4_output_management"
				+ "(Type,Obj_Name,REQUEST_ID) values (?,?,?)";
		
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {
			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;
				for (S4OutputMgmt outputManagement_List : outputManagementList) {
					stmt.setString(1, outputManagement_List.getType());
					stmt.setString(2, outputManagement_List.getObjName());
					stmt.setLong(3,requestID);
					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 1000 records
					if (counter % 1000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}					
					}
				stmt.executeBatch();
          		conn.commit();
				logger.info("outputManagementList Data INSERTED SUCCESSFULLY");
			} catch (Exception e) {
				logger.error("FAILURE in insert");
				conn.rollback();
	            logger.debug("Transaction rollback...");
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			logger.error("FAILURE in Getting Connection");
			logger.error(e.getMessage());
		} finally {
			stmt.close();
			conn.close();
		}
	}
	
	public void insertaffectedbyCustomFieldsList(List<S4AffectCustomField> affectedbyCustomFieldsList,HttpSession session, Long requestID) throws SQLException{
		logger.info("affectedbyCustomFieldsList SIZE"+affectedbyCustomFieldsList.size());
		final String INSERT_SQL = "INSERT INTO s4_affect_custom "
			+ "(Type,Obj_Name,Trigger_Obj,REQUEST_ID) values (?,?,?,?)";
			
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {
			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;
				for (S4AffectCustomField affectedbyCustomFields_List : affectedbyCustomFieldsList) {
					
					stmt.setString(1, affectedbyCustomFields_List.getType());
					stmt.setString(2, affectedbyCustomFields_List.getObjName());
					stmt.setString(3, affectedbyCustomFields_List.getTriggerObj());
					stmt.setLong(4,requestID);
					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 1000 records
					if (counter % 1000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}					
				}

				stmt.executeBatch();
            	conn.commit();
				logger.info("AffectedbyCustomFieldsList Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				logger.error("FAILURE in insert");
				conn.rollback();
	            logger.debug("Transaction rollback...");
         		logger.error(e.getMessage());
			}
		} catch (Exception e) {
			logger.error("FAILURE in Getting Connection");
			logger.error(e.getMessage());
		} finally {
			stmt.close();
			conn.close();
    	}
	}
	
	public void insertdrs4SimplificationTwoList(List<S4DetailReportComplexity> drs4SimplificationTwoList,HttpSession session, Long requestID) throws SQLException{
	 logger.info("INSIDE DAOIMPL drs4SimplificationTwoList SIZE"+drs4SimplificationTwoList.size());
		final String INSERT_SQL = "INSERT INTO s4_Detail_Report "
			+ "(OBJ_TYPE,OBJ_NAME,USED,SUB_OBJ,METHOD,PCKG,IMPACTED_OBJ_TYPE,LINE_NO,STMT,OPERATIONS,IMPACT_REASON,AFFECT_OBJ_DESC,DESC_OF_CHANGE,SAP_NOTES,SOLUTION_STEPS,COMPLEXITY,ISSUE_CATEGORY,ERROR_CATEGORY,TRIGGER_OBJ,Remediation_Category,SAP_SIMP_LIST,APP_COMPONENT,SAP_SIMPL_CATEGORY,ITEM_AREA,REQUEST_ID) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {
			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;
				for (S4DetailReportComplexity drs4SimplificationTwo_List : drs4SimplificationTwoList) {
					
					stmt.setString(1,drs4SimplificationTwo_List.getType());
					stmt.setString(2,drs4SimplificationTwo_List.getObjName());
					stmt.setString(3,drs4SimplificationTwo_List.getUsed());
					stmt.setString(4,drs4SimplificationTwo_List.getSubObject());
					stmt.setString(5,drs4SimplificationTwo_List.getMethod());
					stmt.setString(6,drs4SimplificationTwo_List.getPckg());
					stmt.setString(7,drs4SimplificationTwo_List.getImpactedObjType());
					stmt.setInt(8,drs4SimplificationTwo_List.getLineNo());
					stmt.setString(9,drs4SimplificationTwo_List.getStmt());		
					stmt.setString(10,drs4SimplificationTwo_List.getOperations());
					stmt.setString(11,drs4SimplificationTwo_List.getImpactReason());
					stmt.setString(12,drs4SimplificationTwo_List.getAffectObjDesc());
					stmt.setString(13,drs4SimplificationTwo_List.getDescOfChange());
					stmt.setString(14,drs4SimplificationTwo_List.getSapNotes());
					stmt.setString(15,drs4SimplificationTwo_List.getSolutionSteps());
					stmt.setString(16,drs4SimplificationTwo_List.getComplexity());
					stmt.setString(17,drs4SimplificationTwo_List.getIssueCategory());
					stmt.setString(18,drs4SimplificationTwo_List.getErrorCategory());
					stmt.setString(19,drs4SimplificationTwo_List.getTriggerObj());
					stmt.setString(20,drs4SimplificationTwo_List.getRemediationCategory());
					stmt.setString(21,drs4SimplificationTwo_List.getSapSimpListChapter());
					stmt.setString(22,drs4SimplificationTwo_List.getApplicationComponent());
					stmt.setString(23,drs4SimplificationTwo_List.getSapSimplCategry());
					stmt.setString(24,drs4SimplificationTwo_List.getItemArea());
					stmt.setLong(25,requestID);
					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 1000 records
					if (counter % 1000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}					
					}

				stmt.executeBatch();
            	conn.commit();
				logger.info("Drs4SimplificationTwoList Data INSERTED SUCCESSFULLY");
			} catch (Exception e) {
				logger.error("FAILURE in insert");
				conn.rollback();
	            logger.debug("Transaction rollback...");
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
          logger.error("FAILURE in Getting Connection");
    	  logger.error(e.getMessage());
		} finally {
		stmt.close();
		conn.close();
		}
	}
	
	public void insertdrs4SimplificationThreeList(List<S4DetailReportRemediation> drs4SimplificationThreeList,HttpSession session, Long requestID) throws SQLException{
		logger.info("INSIDE DAOIMPL THREELIST SIZE drs4SimplificationThreeList"+drs4SimplificationThreeList.size());
		final String INSERT_SQL = "INSERT INTO s4_Detail_Report_Remedi "
			+ "(OBJ_TYPE,OBJ_NAME,USED,SUB_OBJ,METHOD,PCKG,IMPACTED_OBJ_TYPE,LINE_NO,STMT,OPERATIONS,IMPACT_REASON,AFFECT_OBJ_DESC,DESC_OF_CHANGE,SAP_NOTES,SOLUTION_STEPS,COMPLEXITY,ISSUE_CATEGORY,ERROR_CATEGORY,TRIGGER_OBJ,Remediation_Category,SAP_SIMP_LIST,APP_COMPONENT,SAP_SIMPL_CATEGORY,ITEM_AREA,REQUEST_ID) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {
			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;
				for (S4DetailReportRemediation drs4SimplificationThree_List : drs4SimplificationThreeList) {
										
					stmt.setString(1,drs4SimplificationThree_List.getType());
					stmt.setString(2,drs4SimplificationThree_List.getObjName());
					stmt.setString(3,drs4SimplificationThree_List.getUsed());
					stmt.setString(4,drs4SimplificationThree_List.getSubObject());
					stmt.setString(5,drs4SimplificationThree_List.getMethod());
					stmt.setString(6,drs4SimplificationThree_List.getPckg());
					stmt.setString(7,drs4SimplificationThree_List.getImpactedObjType());
					stmt.setInt(8,drs4SimplificationThree_List.getLineNo());
					stmt.setString(9,drs4SimplificationThree_List.getStmt());
					stmt.setString(10,drs4SimplificationThree_List.getOperations());
					stmt.setString(11,drs4SimplificationThree_List.getImpactReason());
					stmt.setString(12,drs4SimplificationThree_List.getAffectObjDesc());
					stmt.setString(13,drs4SimplificationThree_List.getDescOfChange());
					stmt.setString(14,drs4SimplificationThree_List.getSapNotes());
					stmt.setString(15,drs4SimplificationThree_List.getSolutionSteps());
					stmt.setString(16,drs4SimplificationThree_List.getComplexity());
					stmt.setString(17,drs4SimplificationThree_List.getIssueCategory());
					stmt.setString(18,drs4SimplificationThree_List.getErrorCategory());
					stmt.setString(19,drs4SimplificationThree_List.getTriggerObj());
					stmt.setString(20,drs4SimplificationThree_List.getRemediationCategory());
					stmt.setString(21,drs4SimplificationThree_List.getSapSimpListChapter());
					stmt.setString(22,drs4SimplificationThree_List.getApplicationComponent());
					stmt.setString(23,drs4SimplificationThree_List.getSapSimplCategry());
					stmt.setString(24,drs4SimplificationThree_List.getItemArea());
					stmt.setLong(25,requestID);
					// Add statement to batch
				stmt.addBatch();
					counter++;
					// Execute batch of 1000 records
					if (counter % 1000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}					
					}
				stmt.executeBatch();
            	conn.commit();
				logger.info("Drs4SimplificationThreeList Data INSERTED SUCCESSFULLY");
			} catch (Exception e) {
				logger.error("FAILURE in insert");
				conn.rollback();
	            logger.debug("Transaction rollback...");
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			logger.error("FAILURE in Getting Connection");
            logger.error(e.getMessage());
		} finally {
		stmt.close();
		conn.close();
		}
   }
}
