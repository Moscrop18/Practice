package com.accenture.testingscope.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Stream;

import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.accenture.client.model.RequestForm;
import com.accenture.config.bean.CollectionsBean;
import com.accenture.constant.Hana_Profiler_Constant;
import com.accenture.constant.ST03HanaConstant;
import com.accenture.exceptions.UploadFilesNotValidException;
import com.accenture.fileprocesing.dao.ST03HanaDAOImpl;
import com.accenture.master.IRPATScopeEstimates;
import com.accenture.master.IRPATScopeEstimatesModel;
import com.accenture.master.IRPATScopeRequestMaster;
import com.accenture.testingscope.dao.TestingScopeDAO;
import com.accenture.testingscope.model.TScopeFinalIntermediate;
import com.accenture.testingscope.model.TestingScopeDownload;
import com.accenture.testingscope.model.TestingScopeIntermediate;
import com.accenture.testingscope.model.TestingScopeModel;
import com.accenture.utility.AppGenUtility;
import com.accenture.utility.HANAUtility;
import com.accenture.validator.xlsx.XlsxValidator;
import com.monitorjbl.xlsx.StreamingReader;

@Service
public class TestingScopeServiceImpl implements TestingScopeService {

	private final Logger logger = LoggerFactory.getLogger(TestingScopeServiceImpl.class);

	@Autowired
	private TestingScopeDAO testingScopeDao;

	@Autowired
	private ST03HanaDAOImpl st03Hanadao;

	@Autowired
	private CollectionsBean collectionsBean;

	@Override
	public void processTScope(long requestId, List<TestingScopeModel> tscopeList, HttpSession session,
			RequestForm requestForm) throws Exception {
		logger.info("Processing of IRPA TSCOPE starts ....");

		try {
			String customerNamespaces = "", srcColName = "", tarColName = "";

			Map<String, Set<String>> s4AppCompMap = null;

			// Fetching the application component from business process detail
			// report
			Map<String, Set<String>> busProcessDetAppCompMap = getAppComponentMap(requestId,
					testingScopeDao.getBusinessProcessDetailList(requestId));

			// If scope S4Technical is selected, then fetch the application
			// component
			if (requestForm.getS4Technical())
				s4AppCompMap = getAppComponentMap(requestId, testingScopeDao.getS4AppCompMap(requestId));

			// Getting st03 map of top 20 critical entries
			Map<String[], Boolean> st03Map = new LinkedHashMap<>();
			collectionsBean.getSt03List().stream().forEach(obj -> {
				st03Map.put(obj, ST03HanaConstant.FALSE);
			});

			// Processing the tscope list
			List<TestingScopeIntermediate> testingScopeList = getTscopeProcessList(tscopeList, s4AppCompMap,
					busProcessDetAppCompMap, st03Map, requestForm, requestId);

			if (CollectionUtils.isNotEmpty(testingScopeList)) {
				// Inserting into first intermediate table -
				// TestingScope_Intermediate
				testingScopeDao.testingScopeIntermediateInsert(session, testingScopeList);

				srcColName = AppGenUtility.getTCodeSourceCol(requestForm.getSourceVersion());
				tarColName = AppGenUtility.getTCodeTargetCol(requestForm.getTargetVersion());
				customerNamespaces = "^" + String.join("|^", requestForm.getCustomerNamespace().split(","));

				// IRPA processing logic
				testingScopeDao.tscopeTCodeProcessing(session, requestId, srcColName, tarColName, customerNamespaces);
				testingScopeDao.tscopeAppnComponenetProcessing(session, requestId, customerNamespaces);

				logger.info("Processing of IRPA TSCOPE ends ...");
			}
		} catch (Exception e) {
			logger.error("Error while processing irpa tscope : ", e);
			throw new Exception();
		}
	}

	private List<TestingScopeIntermediate> getTscopeProcessList(List<TestingScopeModel> tscopeList,
			Map<String, Set<String>> s4AppCompMap, Map<String, Set<String>> busProcessDetAppCompMap,
			Map<String[], Boolean> st03Map, RequestForm reqForm, long requestId) throws Exception {
		List<TestingScopeIntermediate> testingScopeList = new ArrayList<>();
		TestingScopeIntermediate testingScopeObj = null;

		String applicationComponent = "", transaction = "", objectType = "", objectName = "", objectNameType = "",
				operCd = "";
		Set<String> appCompSet = null;
		Set<String> transactionsSet = null;

		try {
			for (TestingScopeModel tscopeValue : tscopeList) {
				objectType = tscopeValue.getObjectType().trim();
				objectName = tscopeValue.getObjectName().trim();
				objectNameType = objectType.concat(objectName);
				operCd = tscopeValue.getOperationCode().trim();
				transaction = tscopeValue.getComments().trim();
				applicationComponent = tscopeValue.getInfo().trim();

				// Fetching the application component where application
				// component is blank
				if (MapUtils.isNotEmpty(s4AppCompMap) && StringUtils.isEmpty(applicationComponent)
						&& s4AppCompMap.containsKey(objectNameType)) {
					appCompSet = s4AppCompMap.get(objectNameType);
				} else if (MapUtils.isNotEmpty(busProcessDetAppCompMap) && StringUtils.isEmpty(applicationComponent)
						&& busProcessDetAppCompMap.containsKey(objectNameType)) {
					appCompSet = busProcessDetAppCompMap.get(objectNameType);
				} else {
					appCompSet = new LinkedHashSet<>();
					appCompSet.add(applicationComponent);
				}

				// Splitting the transactions
				if (objectType.equals(ST03HanaConstant.TRAN_OBJ)) {
					transactionsSet = new LinkedHashSet<>();
					transactionsSet.add(objectName); // objectName = transaction
				} else {
					transactionsSet = new LinkedHashSet<>(Arrays
							.asList(Arrays.stream(transaction.split(",")).map(String::trim).toArray(String[]::new)));
				}

				// Preparing the list of testing scope objects
				for (String appComponent : appCompSet) {
					for (String transValue : transactionsSet) {
						testingScopeObj = new TestingScopeIntermediate();
						String operation = "";

						testingScopeObj.setRequestid(requestId);
						testingScopeObj.setObjecttype(objectType);
						testingScopeObj.setObjectname(objectName);
						testingScopeObj.setObjectTypeObjectName(objectNameType);
						testingScopeObj.setTransactions(transValue.trim());
						testingScopeObj.setApplicationComponent(appComponent.trim());

						if (MapUtils.isNotEmpty(st03Map)) {
							for (Entry<String[], Boolean> entry : st03Map.entrySet()) {
								String[] strArr = entry.getKey();

								if (transValue.equals(strArr[0]) && objectType.equals(strArr[1])) {
									if (operCd.startsWith(ST03HanaConstant.CUSTOM_OPCODE))
										operation = ST03HanaConstant.CUST_IMP_MOST_USED;
									else if (operCd.startsWith(ST03HanaConstant.STANDARD_OPCODE))
										operation = ST03HanaConstant.STD_IMP_MOST_USED;

									st03Map.put(entry.getKey(), ST03HanaConstant.TRUE);
								}
							}
						}

						if (StringUtils.isEmpty(operation)) {
							if (operCd.startsWith(ST03HanaConstant.CUSTOM_OPCODE))
								operation = ST03HanaConstant.CUST_IMP;
							else if (operCd.startsWith(ST03HanaConstant.STANDARD_OPCODE))
								operation = ST03HanaConstant.STD_IMP;
						}

						testingScopeObj.setOpercd(operation);

						testingScopeList.add(testingScopeObj);
					}
				}
			}

			// Pushing st03 entries to the testing scope list
			if (MapUtils.isNotEmpty(st03Map)) {
				for (Entry<String[], Boolean> entry : st03Map.entrySet()) {
					testingScopeObj = new TestingScopeIntermediate();

					String[] strArr = entry.getKey();
					String transValue = strArr[0].trim(), objTypeValue = strArr[1].trim(), operation = "";

					testingScopeObj.setRequestid(requestId);
					testingScopeObj.setObjecttype(objTypeValue);
					testingScopeObj.setObjectname(transValue);
					testingScopeObj.setObjectTypeObjectName(objTypeValue.concat(transValue));
					testingScopeObj.setTransactions(transValue);
					testingScopeObj.setApplicationComponent(StringUtils.EMPTY);

					if (entry.getValue().equals(ST03HanaConstant.FALSE)) {
						if (transValue.startsWith("Z") || transValue.startsWith("Y")
								|| Stream.of(reqForm.getCustomerNamespace().split(","))
										.anyMatch(value -> transValue.startsWith(value)))
							operation = ST03HanaConstant.CUST_NONIMP_MOST_USED;
						else
							operation = ST03HanaConstant.STD_NONIMP_MOST_USED;
					} else {
						if (transValue.startsWith("Z") || transValue.startsWith("Y")
								|| Stream.of(reqForm.getCustomerNamespace().split(","))
										.anyMatch(value -> transValue.startsWith(value)))
							operation = ST03HanaConstant.CUST_IMP_MOST_USED;
						else
							operation = ST03HanaConstant.STD_IMP_MOST_USED;
					}

					testingScopeObj.setOpercd(operation);

					testingScopeList.add(testingScopeObj);
				}
			}
		} catch (Exception e) {
			logger.error("Error while processing the testing scope list : ", e);
			throw new Exception();
		}

		return testingScopeList;
	}

	@Override
	public List<TestingScopeDownload> getTScopeList(long requestId) throws Exception {
		return testingScopeDao.getIRPATScope(requestId);
	}

	@Override
	public List<TestingScopeDownload> getDistinctBusinessScenarios(long requestId) throws Exception {
		return testingScopeDao.getDistinctBusinessScenarios(requestId);
	}

	@Override
	public IRPATScopeRequestMaster getIRPATScopeRM(long requestId) throws Exception {
		return testingScopeDao.getIRPATScopeRM(requestId);
	}

	@Override
	public void readFinalReport(HttpSession session, MultipartFile file, long requestId, String clientName)
			throws Exception {
		List<TScopeFinalIntermediate> tscopeList = new ArrayList<>();

		String directoryPath = HANAUtility.getFinalReportFilePath(clientName, requestId);
		String filePath = directoryPath + File.separator + file.getOriginalFilename();

		try {
			// Writing the uploaded file to the server path
			writeIRPATScopeFinalReport(file, directoryPath, filePath);

			try (InputStream fis = new FileInputStream(new File(filePath));
					XSSFWorkbook workbook = new XSSFWorkbook(filePath)) {
				XSSFSheet irpaSheet = workbook.getSheet(ST03HanaConstant.IRPA_TSCOPE_SHEET_NAME);

				if (irpaSheet != null) {
					// Validating the IRPA Final File
					validateIRPATScopeFinalReport(filePath, requestId, workbook, irpaSheet);

					// Reading the IRPA Final File
					@SuppressWarnings("deprecation")
					StreamingReader tscopeReader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024)
							.sheetName(irpaSheet.getSheetName()).read(fis);

					IRPATScopeRequestMaster irpaTScopeRMObj = new IRPATScopeRequestMaster();

					if (tscopeReader != null) {
						tscopeReader.forEach(row -> {
							if (row.getRowNum() >= 1 && row.getRowNum() <= ST03HanaConstant.IRPA_ROWS_START - 2) {
								getIRPATScopeRM(row, irpaTScopeRMObj);
							}

							else if (row.getRowNum() >= ST03HanaConstant.IRPA_ROWS_START) {
								TScopeFinalIntermediate tscopeObj = getIRPATScopeList(row, requestId,
										file.getOriginalFilename());
								if (tscopeObj != null)
									tscopeList.add(tscopeObj);
							}
						});
					}

					if (CollectionUtils.isNotEmpty(tscopeList)) {
						st03Hanadao.truncateTable("TScope_Final_Intermediate", session);
						testingScopeDao.tscopeIntermediateInsert(session, tscopeList);

						List<Object[]> countList = testingScopeDao.getImpactedNonImpactedCounts(requestId);

						if (CollectionUtils.isNotEmpty(countList)) {
							// Setting Impacted Most Used Counts
							irpaTScopeRMObj.setImpactedMostUsedBusinessScenariosCount(
									countList.get(0)[0] == null ? 0 : ((Long) countList.get(0)[0]).intValue());
							irpaTScopeRMObj.setNonImpactedMostUsedBusinessScenariosCount(
									countList.get(0)[1] == null ? 0 : ((Long) countList.get(0)[1]).intValue());

							// Setting Impacted Counts
							irpaTScopeRMObj.setImpactedBusinessScenariosCount(
									countList.get(0)[2] == null ? 0 : ((Long) countList.get(0)[2]).intValue());
							irpaTScopeRMObj.setNonImpactedBusinessScenariosCount(
									irpaTScopeRMObj.getAddBusinessScenariosToTest());
						}
					}

					if (irpaTScopeRMObj != null) {
						irpaTScopeRMObj.setRequestId(requestId);
						testingScopeDao.insertIRPATScopeReqMaster(requestId, irpaTScopeRMObj);
					}
				}
			}
		} catch (UploadFilesNotValidException e) {
			logger.error("File has been modified : ", e);

			// Deleting the file if exception occurs
			new File(filePath).delete();

			throw new UploadFilesNotValidException(
					"Uploading of Testing Scope Report Failed !!! File has been modified !!!");
		} catch (Exception e) {
			logger.error("Error -- Reading IRPA Final File : ", e);

			// Deleting the file if exception occurs
			new File(filePath).delete();

			throw new Exception();
		}
	}

	@Override
	public void updateIRPATScopeRMScenarios(HttpSession session, long requestId) throws Exception {
		// Updating Request Master for Scenarios
		st03Hanadao.deleteFromTableWithReqIdName(requestId, "IRPATScopeRMScenarios", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestId, "IRPATScopeModuleReqMaster", "requestId");

		// Inserting module wise request master table for distinct business scenario level 3
		testingScopeDao.insertIRPATScopeModuleReqMaster(session, requestId);

		// Inserting process wise request master table for distinct business scenario level 3
		testingScopeDao.insertIRPATScopeReqMasterScenarios(session, requestId);
	}

	@Override
	public JSONObject getScenarioReqMasterJSONObject(long requestId) throws Exception {
		logger.info("Getting Scenarios Request Master JSON Object -- Start");

		try {
			JSONObject jsonObj = null;
			Map<String, Integer> moduleMap = testingScopeDao.getModulesCount(requestId);
			Map<String, Map<String, List<Integer>>> processMap = testingScopeDao.getProcessCount(requestId);

			if (MapUtils.isNotEmpty(moduleMap) && MapUtils.isNotEmpty(processMap))
				jsonObj = graphOneModule(moduleMap, processMap);

			return jsonObj;
		} catch (Exception e) {
			logger.error("Error while getting Scenarios Request Master JSON Object : ", e);
			throw new Exception();
		}
	}

	@Override
	public IRPATScopeEstimatesModel getIRPAEstimatesModel(long requestId) throws Exception {
		try {
			IRPATScopeEstimatesModel estimatesModelObj = null;

			IRPATScopeEstimates estimatesObj = testingScopeDao.getIRPAEstimates(requestId);

			if (estimatesObj != null) {
				estimatesModelObj = new IRPATScopeEstimatesModel();

				BeanUtils.copyProperties(estimatesModelObj, estimatesObj);
			}

			return estimatesModelObj;
		} catch (Exception e) {
			throw new Exception();
		}
	}

	@Override
	public IRPATScopeEstimates getIRPAEstimates(long requestId) throws Exception {
		try {
			return testingScopeDao.getIRPAEstimates(requestId);
		} catch (Exception e) {
			throw new Exception();
		}
	}

	@Override
	public void saveIRPAEstimatesDefaults(long requestId) throws Exception {
		logger.info("Getting IRPA Estimate Object -- Start");

		try {
			IRPATScopeRequestMaster irpaTScopeRMObj = testingScopeDao.getIRPATScopeRM(requestId);

			IRPATScopeEstimates estimatesObj = new IRPATScopeEstimates();

			estimatesObj.setImpactedBusinessScenariosCount(irpaTScopeRMObj.getImpactedBusinessScenariosCount());
			estimatesObj.setAddBusinessScenariosToTestCount(irpaTScopeRMObj.getAddBusinessScenariosToTest());
			estimatesObj.setNoTestStepsToTestCount(irpaTScopeRMObj.getNoTestStepsToTest());

			estimatesObj.setManualScriptCreationCount(ST03HanaConstant.IRPA_MANUAL_SCRIPT_CREATION_DEFAULT);
			estimatesObj.setManualScriptModificationCount(ST03HanaConstant.IRPA_MANUAL_SCRIPT_MODIFICATION_DEFAULT);
			estimatesObj.setScriptsForUnitTest(ST03HanaConstant.IRPA_SCRIPTS_UNITTEST_DEFAULT);
			estimatesObj.setScriptsForSITOne(ST03HanaConstant.IRPA_SCRIPTS_SIT1_DEFAULT);
			estimatesObj.setScriptsForSITTwo(ST03HanaConstant.IRPA_SCRIPTS_SIT2_DEFAULT);
			estimatesObj.setScriptsForRegressionTest(ST03HanaConstant.IRPA_SCRIPTS_REGRESSIONTEST_DEFAULT);
			estimatesObj.setScriptsForUAT(ST03HanaConstant.IRPA_SCRIPTS_UAT_DEFAULT);
			estimatesObj.setScriptsForSmokeTest(ST03HanaConstant.IRPA_SCRIPTS_SMOKETEST_DEFAULT);

			estimatesObj.setSimpleCompForTestScriptCount(ST03HanaConstant.IRPA_SIMPLE_DEFAULT);
			estimatesObj.setMediumCompForTestScriptCount(ST03HanaConstant.IRPA_MEDIUM_DEFAULT);
			estimatesObj.setComplexCompForTestScriptCount(ST03HanaConstant.IRPA_COMPLEX_DEFAULT);

			estimatesObj.setRequestId(requestId);

			testingScopeDao.saveIRPAEstimates(estimatesObj);
		} catch (Exception e) {
			logger.error("Error while getting IRPA Estimate Object : ", e);
			throw new Exception();
		}
	}

	@Override
	public void saveIRPAEstimates(IRPATScopeEstimatesModel estimatorModelObj) throws Exception {
		try {
			IRPATScopeEstimates estimatorObj = new IRPATScopeEstimates();

			BeanUtils.copyProperties(estimatorObj, estimatorModelObj);
			testingScopeDao.saveIRPAEstimates(estimatorObj);
		} catch (Exception e) {
			throw new Exception();
		}
	}

	@Override
	public void dataTransferToDownload(long requestId, HttpSession session) throws Exception {
		st03Hanadao.deleteFromTableWithReqIdName(requestId, "TestingScopeDownload", "requestId");
		testingScopeDao.dataTransaferIntToDownload(requestId);
		st03Hanadao.truncateTable("TScope_Final_Intermediate", session);
	}

	@Override
	public void updateIRPAStatus(long requestId) throws Exception {
		try {
			testingScopeDao.updateIRPAStatus(requestId);
		} catch (Exception e) {
			throw new Exception();
		}
	}

	private void writeIRPATScopeFinalReport(MultipartFile file, String directoryPath, String filePath)
			throws Exception {
		try {
			File directory = new File(directoryPath);

			if (directory.exists())
				FileUtils.cleanDirectory(directory);

			Path path = Paths.get(filePath);
			byte[] bytes = file.getBytes();
			Files.write(path, bytes);
			logger.info("IRPA - Testing Scope Final Report File - Wrote in file path");
		} catch (Exception e) {
			logger.error("Writing IRPA - Testing Scope Final Report File Failed -- ", e);
			throw new Exception();
		}
	}

	private void validateIRPATScopeFinalReport(String filePath, long requestId, XSSFWorkbook workbook,
			XSSFSheet irpaSheet) throws IOException, UploadFilesNotValidException {
		// Validating mandatory columns in IRPA Final File
		if (!(new XlsxValidator().validateXlsxFiles(new File(filePath), requestId,
				ST03HanaConstant.IRPA_TSCOPE_SHEET_NAME, workbook.getSheetIndex(irpaSheet)))) {
			logger.info("All columns in IRPA TSCOPE sheet are not present.");
			throw new UploadFilesNotValidException("All columns in IRPA TSCOPE sheet are not present.");
		}

		// Validating number of rows in IRPA Final File
		/*
		 * if ((irpaSheet.getPhysicalNumberOfRows() -
		 * ST03HanaConstant.IRPA_ROWS_START) == 0 ||
		 * (irpaSheet.getPhysicalNumberOfRows() -
		 * ST03HanaConstant.IRPA_ROWS_START) != testingScopeDao
		 * .rowCount(requestId)) {
		 * logger.info("The IRPA TScope File has been modified ..."); throw new
		 * UploadFilesNotValidException("The IRPA TScope File has been modified."
		 * ); }
		 */

	}

	private TScopeFinalIntermediate getIRPATScopeList(Row row, long requestId, String fileName) {
		TScopeFinalIntermediate tscope = new TScopeFinalIntermediate();

		int moduleIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Module"));
		int processIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Process"));
		int appCompIndex = Integer.parseInt(
				Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Application.Component"));
		int appCompDescIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("App.Comp.Desc"));
		int objTypeIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Object.Type"));
		int objNameIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Object.Name"));
		int operIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Operation"));
		int transactionsIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Transactions"));
		int targetTransIndex = Integer.parseInt(
				Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Target.Transactions"));
		int businessScenario1Index = Integer.parseInt(
				Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Business.Scenario.Level1"));
		int businessScenario2Index = Integer.parseInt(
				Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Business.Scenario.Level2"));
		int businessScenario3Index = Integer.parseInt(
				Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Business.Scenario.Level3"));
		int isBusinessScenarioRelIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId)
				.get(fileName).get("Is.Business.Scenario.Relevant"));
		int testScriptAvailIndex = Integer.parseInt(
				Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Test.Script.Available"));
		int countTestScriptsIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId)
				.get(fileName).get("Count.TestScripts.PerScenario"));
		int needsToBeUpdatedIndex = Integer.parseInt(
				Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Needs.To.Be.Updated"));
		int commentsIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Comments"));

		String module = row.getCell(moduleIndex) == null ? "" : row.getCell(moduleIndex).getStringCellValue();
		String process = row.getCell(processIndex) == null ? "" : row.getCell(processIndex).getStringCellValue();
		String appComp = row.getCell(appCompIndex) == null ? "" : row.getCell(appCompIndex).getStringCellValue();
		String appCompDesc = row.getCell(appCompDescIndex) == null ? ""
				: row.getCell(appCompDescIndex).getStringCellValue();
		String objType = row.getCell(objTypeIndex) == null ? "" : row.getCell(objTypeIndex).getStringCellValue();
		String objName = row.getCell(objNameIndex) == null ? "" : row.getCell(objNameIndex).getStringCellValue();
		String operation = row.getCell(operIndex) == null ? "" : row.getCell(operIndex).getStringCellValue();
		String transactions = row.getCell(transactionsIndex) == null ? ""
				: row.getCell(transactionsIndex).getStringCellValue();
		String targetTrans = row.getCell(targetTransIndex) == null ? ""
				: row.getCell(targetTransIndex).getStringCellValue();
		String businessScenarioLevel1 = row.getCell(businessScenario1Index) == null ? ""
				: row.getCell(businessScenario1Index).getStringCellValue();
		String businessScenarioLevel2 = row.getCell(businessScenario2Index) == null ? ""
				: row.getCell(businessScenario2Index).getStringCellValue();
		String businessScenarioLevel3 = row.getCell(businessScenario3Index) == null ? ""
				: row.getCell(businessScenario3Index).getStringCellValue();
		String isBusinessScenarioRelevant = row.getCell(isBusinessScenarioRelIndex) == null ? ""
				: row.getCell(isBusinessScenarioRelIndex).getStringCellValue();
		String testScriptAvail = row.getCell(testScriptAvailIndex) == null ? ""
				: row.getCell(testScriptAvailIndex).getStringCellValue();
		String countTestScripts = row.getCell(countTestScriptsIndex) == null ? ""
				: row.getCell(countTestScriptsIndex).getStringCellValue();
		String needsToBeUpdated = row.getCell(needsToBeUpdatedIndex) == null ? ""
				: row.getCell(needsToBeUpdatedIndex).getStringCellValue().replaceAll("\"", StringUtils.EMPTY);
		String comments = row.getCell(commentsIndex) == null ? "" : row.getCell(commentsIndex).getStringCellValue();

		tscope.setModule(module.trim());
		tscope.setProcess(process.trim());
		tscope.setAppComponent(appComp.trim());
		tscope.setAppCompDesc(appCompDesc.trim());
		tscope.setObjectType(objType.trim());
		tscope.setObjectName(objName.trim());
		tscope.setObjTypeObjName(objType.trim().concat(objName.trim()));
		tscope.setOperCd(operation.toUpperCase().trim());
		tscope.setTransactions(transactions.trim());
		tscope.setTargetTransactions(targetTrans.trim());
		tscope.setBusinessScenarioLevel1(businessScenarioLevel1.trim());
		tscope.setBusinessScenarioLevel2(businessScenarioLevel2.trim());
		tscope.setBusinessScenarioLevel3(businessScenarioLevel3.trim());
		tscope.setIsBusinessScenarioRelevant(isBusinessScenarioRelevant.toUpperCase().trim());
		tscope.setTestScriptAvailable(testScriptAvail.toUpperCase().trim());
		tscope.setCountOfTestScriptsPerScenario(
				countTestScripts.isEmpty() ? 0 : Integer.parseInt(countTestScripts.trim()));
		tscope.setNeedsToBeUpdated(needsToBeUpdated.toUpperCase().trim());
		tscope.setComments(comments.trim());
		tscope.setRequestId(requestId);

		return tscope;
	}

	private void getIRPATScopeRM(Row row, IRPATScopeRequestMaster irpaRMObj) {
		if (row.getRowNum() == 1) {
			int addBusinessScenariosToTest = row.getCell(1).getStringCellValue() == null
					|| row.getCell(1).getStringCellValue().isEmpty() ? 0
							: Integer.parseInt(row.getCell(1).getStringCellValue());
			irpaRMObj.setAddBusinessScenariosToTest(addBusinessScenariosToTest);
		}

		else if (row.getRowNum() == 2) {
			int addStdBusScenariosToTest = row.getCell(1).getStringCellValue() == null
					|| row.getCell(1).getStringCellValue().isEmpty() ? 0
							: Integer.parseInt(row.getCell(1).getStringCellValue());
			irpaRMObj.setAddStandardBusinessScenariosToTest(addStdBusScenariosToTest);
		}

		else if (row.getRowNum() == 3) {
			int addCustBusScenariosToTest = row.getCell(1).getStringCellValue() == null
					|| row.getCell(1).getStringCellValue().isEmpty() ? 0
							: Integer.parseInt(row.getCell(1).getStringCellValue());
			irpaRMObj.setAddCustomBusinessScenariosToTest(addCustBusScenariosToTest);
		}

		else if (row.getRowNum() == 4) {
			int addTestScriptsToTest = row.getCell(1).getStringCellValue() == null
					|| row.getCell(1).getStringCellValue().isEmpty() ? 0
							: Integer.parseInt(row.getCell(1).getStringCellValue());
			irpaRMObj.setAddTestScriptsToTest(addTestScriptsToTest);
		}

		else if (row.getRowNum() == 5) {
			int noTestStepsToTest = row.getCell(1).getStringCellValue() == null
					|| row.getCell(1).getStringCellValue().isEmpty() ? 0
							: Integer.parseInt(row.getCell(1).getStringCellValue());
			irpaRMObj.setNoTestStepsToTest(noTestStepsToTest);
		}
	}

	private JSONObject graphOneModule(Map<String, Integer> moduleMap,
			Map<String, Map<String, List<Integer>>> processMap) {
		JSONObject jsonModuleObj = new JSONObject();
		JSONObject jsonDataObj = new JSONObject();

		JSONObject graphOneModuleObj = new JSONObject();

		JSONArray graphOneModuleColsArray = getColsJSONArray(ST03HanaConstant.MODULE_KEY, ST03HanaConstant.MODULE,
				null);
		JSONArray graphOneModulesRowsArray = getModuleRowsJSONArray(moduleMap);

		graphOneModuleObj.put(ST03HanaConstant.COLS_KEY, graphOneModuleColsArray);
		graphOneModuleObj.put(ST03HanaConstant.ROWS_KEY, graphOneModulesRowsArray);

		jsonDataObj.put(ST03HanaConstant.FRST_KEY, graphOneModuleObj);
		jsonModuleObj.put(ST03HanaConstant.DATA_KEY, jsonDataObj);

		for (Entry<String, Integer> moduleEntry : moduleMap.entrySet()) {
			JSONObject graphs = new JSONObject();
			JSONObject graphsData = new JSONObject();

			String module = moduleEntry.getKey();
			Map<String, List<Integer>> resultMap = processMap.get(module);

			// Graph 1 -- Operation -- Standard, Custom
			JSONObject graphOperation = graphOperationCount(resultMap);

			// Graph 2 -- Test Script Avail - Yes, No
			JSONObject graphTestScript = graphTestScriptCount(resultMap);

			// graph 3 -- To Be Updated - Yes, No
			JSONObject graphToBeUpdated = graphToBeUpdated(resultMap);

			graphs.put(ST03HanaConstant.FRST_KEY, graphOperation);
			graphs.put(ST03HanaConstant.SCND_KEY, graphTestScript);
			graphs.put(ST03HanaConstant.THRD_KEY, graphToBeUpdated);

			graphsData.put(ST03HanaConstant.DATA_KEY, graphs);

			jsonModuleObj.put(module, graphsData);
		}

		return jsonModuleObj;
	}

	private JSONObject graphOperationCount(Map<String, List<Integer>> operationMap) {
		JSONObject graphOperation = new JSONObject();

		JSONArray graphOperationColsArray = getColsJSONArray(ST03HanaConstant.PROCESS_KEY,
				ST03HanaConstant.DISTINCT_BUSINESS_SCENARIOS, null);
		JSONArray graphOperationRowsArray = getRowsJSONArray(operationMap, 0, null);

		graphOperation.put(ST03HanaConstant.COLS_KEY, graphOperationColsArray);
		graphOperation.put(ST03HanaConstant.ROWS_KEY, graphOperationRowsArray);

		return graphOperation;
	}

	private JSONObject graphTestScriptCount(Map<String, List<Integer>> testScriptMap) {
		JSONObject graphTestScript = new JSONObject();

		JSONArray graphTestScriptColsArray = getColsJSONArray(ST03HanaConstant.TEST_SCRIPTS_KEY,
				ST03HanaConstant.TEST_SCRIPTS_AVAIL_YES, ST03HanaConstant.TEST_SCRIPTS_AVAIL_NO);
		JSONArray graphTestScriptRowsArray = getRowsJSONArray(testScriptMap, 1, 2);

		graphTestScript.put(ST03HanaConstant.COLS_KEY, graphTestScriptColsArray);
		graphTestScript.put(ST03HanaConstant.ROWS_KEY, graphTestScriptRowsArray);

		return graphTestScript;
	}

	private JSONObject graphToBeUpdated(Map<String, List<Integer>> toBeUpdatedMap) {
		JSONObject graphToBeUpdated = new JSONObject();

		JSONArray graphToBeUpdatedColsArray = getColsJSONArray(ST03HanaConstant.TO_BE_UPDATED_KEY,
				ST03HanaConstant.TO_BE_UPDATED_YES, ST03HanaConstant.TO_BE_UPDATED_NO);
		JSONArray graphToBeUpdatedRowsArray = getRowsJSONArray(toBeUpdatedMap, 3, 4);

		graphToBeUpdated.put(ST03HanaConstant.COLS_KEY, graphToBeUpdatedColsArray);
		graphToBeUpdated.put(ST03HanaConstant.ROWS_KEY, graphToBeUpdatedRowsArray);

		return graphToBeUpdated;
	}

	private JSONArray getColsJSONArray(String colName, String countName1, String countName2) {
		JSONArray colsJSONArray = new JSONArray();

		JSONObject graphsColsElementOne = new JSONObject();
		graphsColsElementOne.put(ST03HanaConstant.LABEL_KEY, colName);
		graphsColsElementOne.put(ST03HanaConstant.TYPE_KEY, ST03HanaConstant.STRING_VALUE);

		JSONObject graphsColsElementTwo = new JSONObject();
		graphsColsElementTwo.put(ST03HanaConstant.LABEL_KEY, countName1);
		graphsColsElementTwo.put(ST03HanaConstant.TYPE_KEY, ST03HanaConstant.NUMBER_VALUE);

		if (countName2 != null && !countName2.isEmpty()) {
			JSONObject graphsColsElementThree = new JSONObject();
			graphsColsElementThree.put(ST03HanaConstant.ROLE_KEY, ST03HanaConstant.ANNOTATION_VALUE);

			JSONObject graphsColsElementFour = new JSONObject();
			graphsColsElementFour.put(ST03HanaConstant.LABEL_KEY, countName2);
			graphsColsElementFour.put(ST03HanaConstant.TYPE_KEY, ST03HanaConstant.NUMBER_VALUE);

			JSONObject graphsColsElementFive = new JSONObject();
			graphsColsElementFive.put(ST03HanaConstant.ROLE_KEY, ST03HanaConstant.ANNOTATION_VALUE);

			colsJSONArray.put(graphsColsElementOne);
			colsJSONArray.put(graphsColsElementTwo);
			colsJSONArray.put(graphsColsElementThree);
			colsJSONArray.put(graphsColsElementFour);
			colsJSONArray.put(graphsColsElementFive);
		} else {
			JSONObject graphsColsElementThree = new JSONObject();
			graphsColsElementThree.put(ST03HanaConstant.ROLE_KEY, ST03HanaConstant.ANNOTATION_VALUE);

			colsJSONArray.put(graphsColsElementOne);
			colsJSONArray.put(graphsColsElementTwo);
			colsJSONArray.put(graphsColsElementThree);
		}

		return colsJSONArray;
	}

	private JSONArray getModuleRowsJSONArray(Map<String, Integer> countMap) {
		JSONArray rowsJSONArray = new JSONArray();

		for (Entry<String, Integer> entry : countMap.entrySet()) {
			JSONObject graphRowsObj = new JSONObject();
			JSONArray graphRowsElementArray = new JSONArray();
			JSONObject graphRowsValueOne = new JSONObject();
			JSONObject graphRowsValueTwo = new JSONObject();
			JSONObject graphRowsValueThree = new JSONObject();

			graphRowsValueOne.put(ST03HanaConstant.V_VALUE, entry.getKey());
			graphRowsValueTwo.put(ST03HanaConstant.V_VALUE, entry.getValue());
			graphRowsValueThree.put(ST03HanaConstant.V_VALUE, entry.getValue().toString());

			graphRowsElementArray.put(graphRowsValueOne);
			graphRowsElementArray.put(graphRowsValueTwo);
			graphRowsElementArray.put(graphRowsValueThree);

			graphRowsObj.put(ST03HanaConstant.C_VALUE, graphRowsElementArray);

			rowsJSONArray.put(graphRowsObj);
		}

		return rowsJSONArray;
	}

	private JSONArray getRowsJSONArray(Map<String, List<Integer>> countMap, Integer index1, Integer index2) {
		JSONArray rowsJSONArray = new JSONArray();

		for (Entry<String, List<Integer>> entry1 : countMap.entrySet()) {
			JSONObject graphRowsObject = new JSONObject();
			JSONArray graphRowsElementArray = new JSONArray();
			JSONObject graphRowsValueOne = new JSONObject();
			JSONObject graphRowsValueTwo = new JSONObject();
			JSONObject graphRowsValueThree = new JSONObject();
			JSONObject graphRowsValueFour = new JSONObject();
			JSONObject graphRowsValueFive = new JSONObject();

			graphRowsValueOne.put(ST03HanaConstant.V_VALUE, entry1.getKey());
			graphRowsValueTwo.put(ST03HanaConstant.V_VALUE, entry1.getValue().get(index1));
			graphRowsValueThree.put(ST03HanaConstant.V_VALUE, entry1.getValue().get(index1).toString());

			if (index2 != null) {
				graphRowsValueFour.put(ST03HanaConstant.V_VALUE, entry1.getValue().get(index2));
				graphRowsValueFive.put(ST03HanaConstant.V_VALUE, entry1.getValue().get(index2).toString());
			}

			graphRowsElementArray.put(graphRowsValueOne);
			graphRowsElementArray.put(graphRowsValueTwo);
			graphRowsElementArray.put(graphRowsValueThree);
			graphRowsElementArray.put(graphRowsValueFour);
			graphRowsElementArray.put(graphRowsValueFive);

			graphRowsObject.put(ST03HanaConstant.C_VALUE, graphRowsElementArray);

			rowsJSONArray.put(graphRowsObject);
		}

		return rowsJSONArray;
	}

	@Override
	public JSONObject getGraphOneRMJSONObj(long requestId) throws Exception {
		try {
			IRPATScopeRequestMaster irpaTScopeRMObj = testingScopeDao.getIRPATScopeRM(requestId);
			JSONObject jsonObj = null;

			if (irpaTScopeRMObj != null) {
				jsonObj = new JSONObject();
				jsonObj.put(ST03HanaConstant.IMPACTED,
						getIRPAImpactedJsonArray(irpaTScopeRMObj.getImpactedBusinessScenariosCount(),
								irpaTScopeRMObj.getNonImpactedBusinessScenariosCount()));
				jsonObj.put(ST03HanaConstant.IMPACTED_MOST_USED,
						getIRPAImpactedMostUsedJsonArray(irpaTScopeRMObj.getImpactedMostUsedBusinessScenariosCount(),
								irpaTScopeRMObj.getNonImpactedMostUsedBusinessScenariosCount()));

			}

			return jsonObj;
		} catch (Exception e) {
			logger.error("Error while fetching the counts for Graph 1 : ", e);
			throw new Exception();
		}
	}

	private JSONArray getIRPAImpactedJsonArray(Integer impactedCount, Integer nonImpactedCount) {
		JSONArray jsonArr = new JSONArray();

		JSONArray arr1 = new JSONArray();
		arr1.put(ST03HanaConstant.TYPE_KEY);
		arr1.put(ST03HanaConstant.VALUE_KEY);

		JSONArray arr2 = new JSONArray();
		arr2.put(ST03HanaConstant.IMPACTED_KEY);
		arr2.put(impactedCount);

		JSONArray arr3 = new JSONArray();
		arr3.put(ST03HanaConstant.NON_IMPACTED_KEY);
		arr3.put(nonImpactedCount);

		jsonArr.put(arr1);
		jsonArr.put(arr2);
		jsonArr.put(arr3);

		return jsonArr;
	}
	
	private JSONArray getIRPAImpactedMostUsedJsonArray(Integer impactedCount, Integer nonImpactedCount) {
		JSONArray jsonArr = new JSONArray();

		JSONArray arr1 = new JSONArray();
		arr1.put(ST03HanaConstant.TYPE_KEY);
		arr1.put(ST03HanaConstant.VALUE_KEY);

		JSONArray arr2 = new JSONArray();
		arr2.put(ST03HanaConstant.IMPACTED_MOST_USED_KEY);
		arr2.put(impactedCount);

		JSONArray arr3 = new JSONArray();
		arr3.put(ST03HanaConstant.NON_IMPACTED_MOST_USED_KEY);
		arr3.put(nonImpactedCount);

		jsonArr.put(arr1);
		jsonArr.put(arr2);
		jsonArr.put(arr3);

		return jsonArr;
	}

	@Override
	public int irpaTScopeRowCount(long requestId) {
		return testingScopeDao.rowCount(requestId);
	}

	private Map<String, Set<String>> getAppComponentMap(long requestId, List<Object[]> resultList) throws Exception {
		try {
			Map<String, Set<String>> resultMap = new LinkedHashMap<>();
			Set<String> appCompSet = null;
			String objNameType = "", appComponent = "";

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					objNameType = ((String) resultObj[0]).trim();
					appComponent = ((String) resultObj[1]).trim();

					appCompSet = new LinkedHashSet<>(Arrays
							.asList(Arrays.stream(appComponent.split(",")).map(String::trim).toArray(String[]::new)));
					appCompSet.removeIf(StringUtils::isEmpty);

					resultMap.put(objNameType, appCompSet);
				}
			}

			return resultMap;
		} catch (Exception e) {
			logger.error("Error while creating application component map : ", e);
			throw new Exception();
		}
	}
}
