package com.accenture.testingscope.service;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.json.JSONObject;
import org.springframework.web.multipart.MultipartFile;

import com.accenture.client.model.RequestForm;
import com.accenture.master.IRPATScopeEstimates;
import com.accenture.master.IRPATScopeEstimatesModel;
import com.accenture.master.IRPATScopeRequestMaster;
import com.accenture.testingscope.model.TestingScopeDownload;
import com.accenture.testingscope.model.TestingScopeModel;

public interface TestingScopeService {
	public void processTScope(long requestId, List<TestingScopeModel> tscopeList, HttpSession session,
			RequestForm requestForm) throws Exception;

	public List<TestingScopeDownload> getTScopeList(long requestId) throws Exception;
	
	public List<TestingScopeDownload> getDistinctBusinessScenarios(long requestId) throws Exception;

	public void readFinalReport(HttpSession session, MultipartFile file, long requestId, String clientName)
			throws Exception;
	
	public void updateIRPATScopeRMScenarios(HttpSession session, long requestId) throws Exception;
	
	public JSONObject getScenarioReqMasterJSONObject(long requestId) throws Exception;
	
	public JSONObject getGraphOneRMJSONObj(long requestId) throws Exception;
	
	public int irpaTScopeRowCount(long requestId);
	
	public IRPATScopeRequestMaster getIRPATScopeRM(long requestId) throws Exception;
	
	public IRPATScopeEstimatesModel getIRPAEstimatesModel(long requestId) throws Exception;
	
	public IRPATScopeEstimates getIRPAEstimates(long requestId) throws Exception;
	
	public void saveIRPAEstimatesDefaults(long requestId) throws Exception;
	
	public void saveIRPAEstimates(IRPATScopeEstimatesModel estimatorModelObj) throws Exception;
	
	public void dataTransferToDownload(long requestId, HttpSession session) throws Exception;
	
	public void updateIRPAStatus(long requestId) throws Exception;
}
