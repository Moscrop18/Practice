package com.accenture.testingscope.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "AppComponent_SubProcessTestScript")
public class AppComponentSubProcessTestScript {
	private int id;
	private String appComponent;
	private String scenarioLevelOne;
	private String mainProcessLevelTwo;
	private String subProcessLevelThree;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID")
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	@Column(name = "Application_Component")
	public String getAppComponent() {
		return appComponent;
	}
	public void setAppComponent(String appComponent) {
		this.appComponent = appComponent;
	}
	
	@Column(name = "Scenario_Level1", columnDefinition = "TEXT")
	public String getScenarioLevelOne() {
		return scenarioLevelOne;
	}
	public void setScenarioLevelOne(String scenarioLevelOne) {
		this.scenarioLevelOne = scenarioLevelOne;
	}
	
	@Column(name = "Main_Process_Level2", columnDefinition = "TEXT")
	public String getMainProcessLevelTwo() {
		return mainProcessLevelTwo;
	}
	public void setMainProcessLevelTwo(String mainProcessLevelTwo) {
		this.mainProcessLevelTwo = mainProcessLevelTwo;
	}
	
	@Column(name = "Sub_Process_Level3", columnDefinition = "TEXT")
	public String getSubProcessLevelThree() {
		return subProcessLevelThree;
	}
	public void setSubProcessLevelThree(String subProcessLevelThree) {
		this.subProcessLevelThree = subProcessLevelThree;
	}	
}
