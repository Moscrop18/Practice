package com.accenture.testingscope.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TestingScope_Data")
public class TestingScopeData {
	
	private String appComponent;
	private String appComponentDesc;
	private String process;
	private String module;

	@Id
	@Column(name = "Application_Component")
	public String getAppComponent() {
		return appComponent;
	}
	public void setAppComponent(String appComponent) {
		this.appComponent = appComponent;
	}
	
	@Column(name = "App_Component_Desc")
	public String getAppComponentDesc() {
		return appComponentDesc;
	}
	public void setAppComponentDesc(String appComponentDesc) {
		this.appComponentDesc = appComponentDesc;
	}
	
	@Column(name = "Process")
	public String getProcess() {
		return process;
	}
	public void setProcess(String process) {
		this.process = process;
	}
	
	@Column(name = "Module")
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
}
