package com.accenture.testingscope.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "FinalOutputTestingscope")
public class ExtractedDatapojo implements Serializable, Comparable<ExtractedDatapojo> {

	private static final long serialVersionUID = -5294188737237640015L;

	@Id	
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "ID")
	private Integer Id;	

	@Column(name="requestid")
	@Index(name="Index_Request_id")
	private long requestid;

	@Column(name="objecttype")
	private String objecttype;

	@Column(name="objectname")
	private String objectname;

	@Column(name="process")
	private String process;
	
	@Column(name="objectTypeObjectName" , columnDefinition = "LONGTEXT")
	private String objectTypeObjectName;
	
	@Column(name="applicationComponent" , columnDefinition = "LONGTEXT")
	private String applicationComponent;
	
	@Column(name="opercd" , columnDefinition = "LONGTEXT")
	private String opercd;
	
	@Column(name="appCompDesc" , columnDefinition = "LONGTEXT")
	private String appCompDesc;
	
	@Column(name="transactions" , columnDefinition = "LONGTEXT")
	private String transactions;
	
	@Column(name="role" , columnDefinition = "LONGTEXT")
	private String role;
	
	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
	}
	
	public long getRequestid() {
		return requestid;
	}

	public void setRequestid(long requestid) {
		this.requestid = requestid;
	}
	
	public String getObjectname() {
		return objectname;
	}

	public void setObjectname(String objectname) {
		this.objectname = objectname;
	}

	public String getObjectTypeObjectName() {
		return objectTypeObjectName;
	}

	public void setObjectTypeObjectName(String objectTypeObjectName) {
		this.objectTypeObjectName = objectTypeObjectName;
	}
	
	public String getProcess() {
		return process;
	}

	public void setProcess(String process) {
		this.process = process;
	}


	public String getApplicationComponent() {
		return applicationComponent;
	}

	public void setApplicationComponent(String applicationComponent) {
		this.applicationComponent = applicationComponent;
	}
	
	public String getObjecttype() {
		return objecttype;
	}

	public void setObjecttype(String objecttype) {
		this.objecttype = objecttype;
	}

	public String getOpercd() {
		return opercd;
	}

	public void setOpercd(String opercd) {
		this.opercd = opercd;
	}

	public String getAppCompDesc() {
		return appCompDesc;
	}

	public void setAppCompDesc(String appCompDesc) {
		this.appCompDesc = appCompDesc;
	}

	public String getTransactions() {
		return transactions;
	}

	public void setTransactions(String transactions) {
		this.transactions = transactions;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
	
	@Override
    public int compareTo(ExtractedDatapojo extractDataPojo) {
		if(this.process.equalsIgnoreCase(extractDataPojo.getProcess()))
	           return this.getApplicationComponent().compareTo(((ExtractedDatapojo) extractDataPojo).getApplicationComponent());

	       return this.getProcess().compareTo(((ExtractedDatapojo) extractDataPojo).getProcess());
    }
}
