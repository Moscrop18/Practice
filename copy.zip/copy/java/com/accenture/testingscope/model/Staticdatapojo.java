package com.accenture.testingscope.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="testingscope")

public class Staticdatapojo implements Serializable{
	
	   private static final long serialVersionUID = -5294188737237640015L;
	   
		@Id
		@Column(name="componentid", updatable = false, nullable = false, unique=true)
		private String componentid;
		
		
		@Column(name = "applcompdescription", columnDefinition = "LONGTEXT" )
		private String applcompdescription;	
		
		
		@Column(name = "moduleorprocess", columnDefinition = "LONGTEXT" )
		private String moduleorprocess;
		
		
		@Column(name = "standardtcodes", columnDefinition = "LONGTEXT" )
		private String standardtcodes;

		
		
		public String getComponentid() {
			return componentid;
		}
		public void setComponentid(String componentid) {
			this.componentid = componentid;
		}
		public String getApplcompdescription() {
			return applcompdescription;
		}
		public void setApplcompdescription(String applcompdescription) {
			this.applcompdescription = applcompdescription;
		}
		public String getModuleorprocess() {
			return moduleorprocess;
		}
		public void setModuleorprocess(String moduleorprocess) {
			this.moduleorprocess = moduleorprocess;
		}
		public String getStandardtcodes() {
			return standardtcodes;
		}
		public void setStandardtcodes(String standardtcodes) {
			this.standardtcodes = standardtcodes;
		}


}
