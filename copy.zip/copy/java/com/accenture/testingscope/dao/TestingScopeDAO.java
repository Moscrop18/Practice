package com.accenture.testingscope.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.accenture.master.IRPATScopeEstimates;
import com.accenture.master.IRPATScopeRequestMaster;
import com.accenture.testingscope.model.BusinessProcessDetail;
import com.accenture.testingscope.model.TScopeFinalIntermediate;
import com.accenture.testingscope.model.TestingScopeDownload;
import com.accenture.testingscope.model.TestingScopeIntermediate;

public interface TestingScopeDAO {
	public void testingScopeIntermediateInsert(HttpSession session,
			List<TestingScopeIntermediate> finalTestingScopeReportList) throws SQLException, Exception;

	public void tscopeAppnComponenetProcessing(HttpSession session, long requestId, String customerNamespaces)
			throws SQLException, Exception;

	public int rowCount(long requestId);

	public void tscopeTCodeProcessing(HttpSession session, long requestId, String srcColName, String tarColName,
			String customerNamespaces) throws SQLException, Exception;

	public List<TestingScopeDownload> getIRPATScope(long requestId) throws Exception;
	
	public List<TestingScopeDownload> getDistinctBusinessScenarios(long requestId) throws Exception;

	public IRPATScopeRequestMaster getIRPATScopeRM(long requestId) throws Exception;

	public void businessPrcessDetInsert(HttpSession session, List<BusinessProcessDetail> businessProcessDetList)
			throws Exception;

	public void tscopeIntermediateInsert(HttpSession session, List<TScopeFinalIntermediate> tscopeList)
			throws Exception;

	public void insertIRPATScopeReqMasterScenarios(HttpSession session, long requestId) throws Exception;

	public void insertIRPATScopeReqMaster(long requestId, IRPATScopeRequestMaster irpaTScopeRMObj)
			throws Exception;
	
	public void insertIRPATScopeModuleReqMaster(HttpSession session, long requestId) throws Exception;

	public Map<String, Integer> getModulesCount(long requestId) throws Exception;

	public Map<String, Map<String, List<Integer>>> getProcessCount(long requestId) throws Exception;

	public List<Object[]> getImpactedNonImpactedCounts(long requestId) throws Exception;
	
	public IRPATScopeEstimates getIRPAEstimates(long requestId) throws Exception;
	
	public void saveIRPAEstimates(IRPATScopeEstimates estimatorObj) throws Exception;

	public void dataTransaferIntToDownload(long requestId) throws Exception;
	
	public void updateIRPAStatus(long requestId) throws Exception;
	
	public List<Object[]> getS4AppCompMap(long requestId) throws Exception;
	
	public List<Object[]> getBusinessProcessDetailList(long requestId) throws Exception;
}
