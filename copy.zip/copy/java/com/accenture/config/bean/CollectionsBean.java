package com.accenture.config.bean;

import java.util.LinkedList;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.RequestScope;

import com.accenture.testingscope.model.TestingScopeModel;

@Component
@RequestScope
public class CollectionsBean {
	private List<TestingScopeModel> irpaTScopeList = new LinkedList<>();

	private List<String[]> st03List = new LinkedList<>();

	public List<TestingScopeModel> getIrpaTScopeList() {
		return irpaTScopeList;
	}

	public void setIrpaTScopeList(List<TestingScopeModel> irpaTScopeList) {
		this.irpaTScopeList = irpaTScopeList;
	}

	public List<String[]> getSt03List() {
		return st03List;
	}

	public void setSt03List(List<String[]> st03List) {
		this.st03List = st03List;
	}
}
