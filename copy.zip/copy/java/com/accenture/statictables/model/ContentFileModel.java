/**
 * @author rohan.a.mehra
 *
 */
package com.accenture.statictables.model;



import javax.persistence.*;

import org.hibernate.annotations.Type;




public class ContentFileModel implements java.io.Serializable {

	
	private long ID;



	
		public long getID() {
			return ID;
		}

		public void setID(long iD) {
			ID = iD;
		}
		
		
		public String contentFileName;
		
		public byte[] contentFile;
	 
		private long REQUEST_ID;
		
		private String updatedDate;
		
		private Boolean downloaded;


		public String getContentFileName() {
			return contentFileName;
		}

		public void setContentFileName(String contentFileName) {
			this.contentFileName = contentFileName;
		}

		
		@Type(type="org.hibernate.type.MaterializedBlobType")
		public byte[] getContentFile() {
			return contentFile;
		}

		public void setContentFile(byte[] contentFile) {
			this.contentFile = contentFile;
		}
		
		public long getREQUEST_ID() {
			return REQUEST_ID;
		}

		public void setREQUEST_ID(long rEQUEST_ID) {
			REQUEST_ID = rEQUEST_ID;
		}

		public String getUpdatedDate() {
			return updatedDate;
		}

		public void setUpdatedDate(String updatedDate) {
			this.updatedDate = updatedDate;
		}

		public Boolean getDownloaded() {
			return downloaded;
		}

		public void setDownloaded(Boolean downloaded) {
			this.downloaded = downloaded;
		}


		
		
		
		
		
	
}
