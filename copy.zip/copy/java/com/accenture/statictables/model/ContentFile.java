/**
 * @author rohan.a.mehra
 *
 */
package com.accenture.statictables.model;



import javax.persistence.*;

import org.hibernate.annotations.Type;




@Entity
@Table(name="CONTENT_FILE")
public class ContentFile implements java.io.Serializable {

	
	private long ID;



		@Id
		@TableGenerator(name="seq",initialValue=1,allocationSize=0)
		@GeneratedValue(strategy=GenerationType.TABLE, generator="seq")
		@Column(name="ID")
		public long getID() {
			return ID;
		}

		public void setID(long iD) {
			ID = iD;
		}
		
		
		public String contentFileName;
		
		public byte[] contentFile;
	 
		private long REQUEST_ID;
		
		private String updatedDate;
		
		private Boolean downloaded;


		@Column(name="CONTENT_FILE_NAME")
		public String getContentFileName() {
			return contentFileName;
		}

		public void setContentFileName(String contentFileName) {
			this.contentFileName = contentFileName;
		}

		
		@Column(name="CONTENT_FILE")
		@Type(type="org.hibernate.type.MaterializedBlobType")
		public byte[] getContentFile() {
			return contentFile;
		}

		public void setContentFile(byte[] contentFile) {
			this.contentFile = contentFile;
		}
		
		@Column(name="REQUEST_ID")
		public long getREQUEST_ID() {
			return REQUEST_ID;
		}

		public void setREQUEST_ID(long rEQUEST_ID) {
			REQUEST_ID = rEQUEST_ID;
		}

		@Column(name="UPDATED_DATE")
		public String getUpdatedDate() {
			return updatedDate;
		}

		public void setUpdatedDate(String updatedDate) {
			this.updatedDate = updatedDate;
		}

		@Column(name="DOWNLOADED_FILE")
		public Boolean getDownloaded() {
			return downloaded;
		}

		public void setDownloaded(Boolean downloaded) {
			this.downloaded = downloaded;
		}


		
		
		
		
		
	
}
