package com.accenture.statictables.service;

import org.springframework.validation.Errors;

import com.accenture.statictables.model.TransportRequest;

public class TransportRequestValidation {
	public void validate(Object target, Errors errors) {
	    TransportRequest transportRequest = (TransportRequest) target;
	   
	    String targetVersion = transportRequest.getTransportRequestPK().getTargetVersion();
	    String sourceVersion = transportRequest.getTransportRequestPK().getSourceVersion();
	    
	    
	    if (sourceVersion.equals(targetVersion) ) 
	    {
	      errors.rejectValue("transportRequestPK.targetVersion",
	          "",
	          "Source Version and Target Version should not be  equal.");
	    }
	    
	    
	  }
}
