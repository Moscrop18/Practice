package com.accenture.statictables.service;

import java.io.File;

import org.springframework.web.multipart.MultipartFile;

import com.accenture.exceptions.TransportRequestException;
import com.accenture.staticinfo.dao.TransportRequestDAO;
import com.accenture.statictables.model.ContentFile;
import com.accenture.statictables.model.DeletionTransportRequestFile;
import com.accenture.statictables.model.TransportRequest;
import com.accenture.statictables.model.TransportRequestFile;
import com.accenture.validator.TransportFileUploadValidator;
 
public class TransportRequestServiceImpl {
	
	TransportRequestDAO transportRequestdao;
	TransportFileUploadValidator transportFileUploadValidator;

	public void setTransportFileUploadValidator(TransportFileUploadValidator transportFileUploadValidator) {
		this.transportFileUploadValidator = transportFileUploadValidator;
	}

	public void setTransportRequestdao(TransportRequestDAO transportRequestdao) {
		this.transportRequestdao = transportRequestdao;
	}

	private boolean checkTransportRequestExists(String sourceVersion,String targetVersion) {
		final TransportRequest transportRequest = transportRequestdao.getTransportRequest(sourceVersion,targetVersion);
		
		
		return transportRequest != null;
	}
	
	public Integer checkMaxVersionCount() {
		return transportRequestdao.getTransportRequestMaxID();
	}
	
	public Integer checkMaxDelVersionCount() {
		return transportRequestdao.getDeletionTransportRequestMaxID();
	}
	
	public void saveTRData(TransportRequestFile transportRequestFile) throws Exception
	{
		
		transportRequestdao.saveTRFile(transportRequestFile);
		
	}
	public void saveDeletionTRData(DeletionTransportRequestFile transportRequestFile) throws Exception
	{
		
		transportRequestdao.saveDelTRFile(transportRequestFile);
		
	}
	public void saveContentData(ContentFile contentFile) throws Exception
	{
		
		transportRequestdao.saveContentFile(contentFile);
		
	}
	
	public void transportRequestValidation(TransportRequest transportRequest,final File file) throws Exception
	{
		final boolean istransportRequestExists = checkTransportRequestExists(transportRequest.getTransportRequestPK().getSourceVersion(),transportRequest.getTransportRequestPK().getTargetVersion());
		if(istransportRequestExists)
		{
			throw new TransportRequestException(101);
		}
		
		transportFileUploadValidator.validate(file);
		transportRequest.setTrFileName(file.getName());
		
		transportRequestdao.save(transportRequest);
		
	}
	
	public ContentFile getContentData(Long requestId) throws Exception
	{
		
		return transportRequestdao.getContentFile(requestId);
		
	}
}
