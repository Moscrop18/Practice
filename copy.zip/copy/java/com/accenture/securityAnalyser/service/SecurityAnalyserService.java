package com.accenture.securityAnalyser.service;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.ui.Model;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.accenture.client.model.RequestForm;

public interface SecurityAnalyserService {

	public void getSecurityAnalyserReport(HttpSession session, Long requestID) throws Exception;
	public String getSAReportsFromClient(Integer requestID,final String userAccess,final String userRole,Model model, HttpServletResponse response, HttpServletRequest request,
			final RedirectAttributes redirectAttributes, RequestForm requestForm,HttpSession session, String userName, int count);
	public void getSecurityAnalyserGrcReport(HttpSession session, Long requestID) throws Exception;
	public Integer getOutputFileCount(HttpSession session, Long requestID)throws SQLException;
}
