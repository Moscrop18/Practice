package com.accenture.securityAnalyser.service;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.accenture.S4.models.SaFioriReportDownload;
import com.accenture.S4.models.SaGrcReportDownload;
import com.accenture.S4.models.SaObjectReportDownload;
import com.accenture.S4.models.SaUserAndRoleAssignment;
import com.accenture.S4.models.SecurityAnalyserTCDReportDownload;
import com.accenture.client.model.RequestForm;
import com.accenture.client.model.RequestInventory;
import com.accenture.constant.Hana_Profiler_Constant;
import com.accenture.displaygrid.model.DBConfig;
import com.accenture.poc.dao.POCRequestInventoryDAO;
import com.accenture.securityAnalyser.dao.SecurityAnalyserDAOimpl;
import com.accenture.service.FileDownload;
import com.accenture.utility.HANAUtility;

@Service
public class SecurityAnalyserServiceImpl implements SecurityAnalyserService   {

	private SecurityAnalyserDAOimpl secAnalyseDao;
	private FileDownload fileDownload;
	private POCRequestInventoryDAO requestInventorydao;
	public FileDownload getFileDownload() {
		return fileDownload;
	}

	public POCRequestInventoryDAO getRequestInventorydao() {
		return requestInventorydao;
	}

	public void setRequestInventorydao(final POCRequestInventoryDAO requestInventorydao) {
		this.requestInventorydao = requestInventorydao;
	}
	@Autowired
	public void setFileDownload(FileDownload fileDownload) {
		this.fileDownload = fileDownload;
	}

	final static Logger logger = LoggerFactory.getLogger(SecurityAnalyserServiceImpl.class);

	public SecurityAnalyserDAOimpl getSecAnalyseDao() {
		return secAnalyseDao;
	}

	@Autowired
	public void setSecAnalyseDao(SecurityAnalyserDAOimpl secAnalyseDao) {
		this.secAnalyseDao = secAnalyseDao;
	}

	List<SecurityAnalyserTCDReportDownload> secAnalyseReportList = null;

	@Override
	public void getSecurityAnalyserReport(HttpSession session, Long requestID) throws Exception {
		try{
		getSecAnalyseDao().getSecurityAnalyserReportsFromSP(session, requestID);
		}catch (Exception e) {
			logger.error("getSecurityAnalyserReport :: ",e);
			throw e;
		}

	}

	private void writeSaTcdReport(SXSSFWorkbook workbookTemp, Integer requestID, int count) {
		logger.info(":: writeSaTcdReport started ::");
		try{
			int rowIndex = 1;
			List<SecurityAnalyserTCDReportDownload> saTcdReportList = getSecAnalyseDao().getSaTcdReport(requestID, count);
			
			SXSSFSheet saTcdReportSheet = (SXSSFSheet) workbookTemp.getSheetAt(0);
			saTcdReportSheet.setRandomAccessWindowSize(1000000);
			
			Font f1 = workbookTemp.createFont();
			f1.setColor(HSSFColor.DARK_RED.index);
			XSSFCellStyle cs1 = (XSSFCellStyle) workbookTemp.createCellStyle();
			cs1.setFillForegroundColor(new XSSFColor(new java.awt.Color(255, 199, 206)));          
			cs1.setFillPattern(CellStyle.SOLID_FOREGROUND);
			cs1.setFont(f1);
			
			Font f2 = workbookTemp.createFont();
			f2.setColor(HSSFColor.DARK_GREEN.index);
			XSSFCellStyle cs2 = (XSSFCellStyle) workbookTemp.createCellStyle();
			cs2.setFillForegroundColor(new XSSFColor(new java.awt.Color(198, 239, 206)));          
			cs2.setFillPattern(CellStyle.SOLID_FOREGROUND);
			cs2.setFont(f2);
			
			XSSFCellStyle cs3 = (XSSFCellStyle) workbookTemp.createCellStyle();
			cs3.setFillForegroundColor(new XSSFColor(new java.awt.Color(146, 205, 220)));          
			cs3.setFillPattern(CellStyle.SOLID_FOREGROUND);
			
			XSSFCellStyle cs4 = (XSSFCellStyle) workbookTemp.createCellStyle();
			cs4.setFillForegroundColor(new XSSFColor(new java.awt.Color(196, 215, 155)));          
			cs4.setFillPattern(CellStyle.SOLID_FOREGROUND);
			
			Font f5 = workbookTemp.createFont();
			f5.setColor(HSSFColor.BROWN.index);
			XSSFCellStyle cs5 = (XSSFCellStyle) workbookTemp.createCellStyle();
			cs5.setFillForegroundColor(new XSSFColor(new java.awt.Color(255, 235, 156)));         
			cs5.setFillPattern(CellStyle.SOLID_FOREGROUND);
			cs5.setFont(f5);
			
			if (null != saTcdReportList && !saTcdReportList.isEmpty()) {
				Iterator<SecurityAnalyserTCDReportDownload> saTcdReportItr = saTcdReportList.iterator();
				while (saTcdReportItr.hasNext()) {
	
					SecurityAnalyserTCDReportDownload saTcd = saTcdReportItr.next();
					Row saTcdRow = saTcdReportSheet.createRow(rowIndex);
	
					saTcdRow.createCell(0).setCellValue(saTcd.getTargetVersion());
					saTcdRow.createCell(1).setCellValue(saTcd.getFunctionalArea());
					saTcdRow.createCell(2).setCellValue(saTcd.getRoleName());
					saTcdRow.createCell(3).setCellValue(saTcd.getLow());
					saTcdRow.createCell(4).setCellValue(saTcd.getHigh());
					saTcdRow.createCell(5).setCellValue(saTcd.getNewTcode());
					saTcdRow.createCell(6).setCellValue(saTcd.getStatus());
					
					if(saTcd.getStatus().toUpperCase().trim().startsWith("Role Needs Immediate Modification".toUpperCase().trim()))
						saTcdRow.getCell(6).setCellStyle(cs1);
					else if(saTcd.getStatus().toUpperCase().trim().startsWith("No Modification Required".toUpperCase().trim()))
						saTcdRow.getCell(6).setCellStyle(cs2);
					else if(saTcd.getStatus().toUpperCase().trim().startsWith("Tcode is obsolate".toUpperCase().trim()))
						saTcdRow.getCell(6).setCellStyle(cs3);
					else if(saTcd.getStatus().toUpperCase().trim().startsWith("SAP may comeout with a new version".toUpperCase().trim()))
						saTcdRow.getCell(6).setCellStyle(cs4);
					else if(saTcd.getStatus().toUpperCase().trim().startsWith("Role Need Modification".toUpperCase().trim()))
						saTcdRow.getCell(6).setCellStyle(cs5);
					
					rowIndex++;
				}
				
				saTcdReportSheet.setColumnWidth(6, 50000);
			}
		} catch (Exception e) {
			logger.error("writeSaTcdReport :: ",e);
			throw e;
		}
		logger.info("Sucessfully Wrote TCD Report Sheet:::%%%%%%%");
		logger.info(":: writeSaTcdReport Ended ::");
	}
	
	private void writeSaObjectReport(SXSSFWorkbook workbookTemp, Integer requestID, int count) {
		logger.info(":: writeSaObjectReport started ::");
		int saObjReportSheetIndex = 3;
		int rowIndex = 1;
		try {	
			SXSSFSheet saObjReportSheet = (SXSSFSheet) workbookTemp.getSheetAt(saObjReportSheetIndex);
			saObjReportSheet.setRandomAccessWindowSize(1000000);
			List<SaObjectReportDownload> saObjReportList = getSecAnalyseDao().getSaObjReport(requestID, count);
			
			Font f1 = workbookTemp.createFont();
			f1.setColor(HSSFColor.DARK_RED.index);
			XSSFCellStyle csr = (XSSFCellStyle) workbookTemp.createCellStyle();
			csr.setFillForegroundColor(new XSSFColor(new java.awt.Color(255, 199, 206)));          
			csr.setFillPattern(CellStyle.SOLID_FOREGROUND);
			csr.setFont(f1);

			if (null != saObjReportList && !saObjReportList.isEmpty()) {
				Iterator<SaObjectReportDownload> saObjReportItr = saObjReportList.iterator();
				while (saObjReportItr.hasNext()) {
					if(rowIndex == 1000000) {
						workbookTemp.setSheetName(3, "SA_Object_Report_1");
						++saObjReportSheetIndex;
						rowIndex = 1;
						saObjReportSheet = workbookTemp.createSheet("SA_Object_Report_" + (saObjReportSheetIndex-2));
						saObjReportSheet.setRandomAccessWindowSize(1000000);
					
						Row headerRow = saObjReportSheet.createRow(0);
						headerRow.createCell(0).setCellValue("TargetVersion");
						headerRow.createCell(1).setCellValue("functional_area");
						headerRow.createCell(2).setCellValue("Role Name");
						headerRow.createCell(3).setCellValue("OldTcode");
						headerRow.createCell(4).setCellValue("OldObj");
						headerRow.createCell(5).setCellValue("OldField");
						headerRow.createCell(6).setCellValue("OldLow");
						headerRow.createCell(7).setCellValue("OldHigh");
						headerRow.createCell(8).setCellValue("OldObjValues");
						headerRow.createCell(9).setCellValue("NewTcode");
						headerRow.createCell(10).setCellValue("NewObj");
						headerRow.createCell(11).setCellValue("Newfield");
						headerRow.createCell(12).setCellValue("NewLow");
						headerRow.createCell(13).setCellValue("NewHigh");
						headerRow.createCell(14).setCellValue("Proposed(Low/High)");
						
						XSSFCellStyle cs1 = (XSSFCellStyle) workbookTemp.createCellStyle();
						cs1.setFillForegroundColor(new XSSFColor(new java.awt.Color(142,169,219)));          
						cs1.setFillPattern(CellStyle.SOLID_FOREGROUND);
						
						for(int i = 0; i < headerRow.getLastCellNum() ; i++) {
							headerRow.getCell(i).setCellStyle(cs1);
							saObjReportSheet.setColumnWidth(i, 4500);
						}
					}
					
					SaObjectReportDownload saObj = saObjReportItr.next();
					Row saObjRow = saObjReportSheet.createRow(rowIndex);
	
					saObjRow.createCell(0).setCellValue(saObj.getTargetVersion());
					saObjRow.createCell(1).setCellValue(saObj.getFunctionalArea());
					saObjRow.createCell(2).setCellValue(saObj.getAgrName());
					saObjRow.createCell(3).setCellValue(saObj.getOldTcode());
					saObjRow.createCell(4).setCellValue(saObj.getOldObj());
					saObjRow.createCell(5).setCellValue(saObj.getOldField());
					saObjRow.createCell(6).setCellValue(saObj.getOldLow());
					saObjRow.createCell(7).setCellValue(saObj.getOldHigh());
					saObjRow.createCell(8).setCellValue(saObj.getOldObjValues());
					saObjRow.createCell(9).setCellValue(saObj.getNewTcode());
					saObjRow.createCell(10).setCellValue(saObj.getNewObj());
					saObjRow.createCell(11).setCellValue(saObj.getNewField());
					saObjRow.createCell(12).setCellValue(saObj.getNewLow());
					saObjRow.createCell(13).setCellValue(saObj.getNewHigh());
					if (null != saObj.getProposed() && saObj.getProposed().length() > 32767) {
						String proposed = saObj.getProposed().substring(0, Math.min(saObj.getProposed().length(), 10));
						saObjRow.createCell(14).setCellValue(proposed);
						saObjRow.getCell(14).setCellStyle(csr);
					}else{
						saObjRow.createCell(14).setCellValue(saObj.getProposed());
					}
					rowIndex++;
					if(rowIndex == 1000000){
						logger.info("Rows Written :: "+rowIndex);
						}
				}
			}
		} catch (Exception e) {
			logger.error("writeSaObjectReport :: ",e);
			throw e;
		}
		logger.info("Sucessfully Wrote Object Report Sheet:::%%%%%%%");
		logger.info(":: writeSaObjectReport Ended ::");
	}
	
	private void writeUsersAndRoleAssignmentReport(SXSSFSheet saUserAndRoleAssignmentSheet, Integer requestID) {
		logger.info(":: writeUsersAndRoleAssignmentReport started ::");
		try{
		int rowIndex = 1;
		List<SaUserAndRoleAssignment> userAndRoleAssignmentList = getSecAnalyseDao().getSaUserAndRoleReportDownload(requestID);

		if (null != userAndRoleAssignmentList && !userAndRoleAssignmentList.isEmpty()) {
			Iterator<SaUserAndRoleAssignment> userAndRoleAssignmentItr = userAndRoleAssignmentList.iterator();
			while (userAndRoleAssignmentItr.hasNext()) {

				SaUserAndRoleAssignment userRole = userAndRoleAssignmentItr.next();
				Row userRoleRow = saUserAndRoleAssignmentSheet.createRow(rowIndex);

				userRoleRow.createCell(0).setCellValue(userRole.getUserName());
				userRoleRow.createCell(1).setCellValue(userRole.getRoleName());
				rowIndex++;
			}
		}
		}catch (Exception e) {
			logger.error("writeUsersAndRoleAssignmentReport :: ",e);
			throw e;
		}
		logger.info("Sucessfully Wrote User and Role Assignment Report Sheet:::%%%%%%%");
		logger.info(":: writeUsersAndRoleAssignmentReport Ended ::");
	}
	
	private void writeGrcReport(SXSSFSheet saGrcSheet, Integer requestID) {
		logger.info(":: writeGrcReport started ::");
		try{
		int rowIndex = 1;
		List<SaGrcReportDownload> grcList = getSecAnalyseDao().getSaGrcReportDownload(requestID);

		if (null != grcList && !grcList.isEmpty()) {
			Iterator<SaGrcReportDownload> grcItr = grcList.iterator();
			while (grcItr.hasNext()) {

				SaGrcReportDownload grc = grcItr.next();
				Row grcRow = saGrcSheet.createRow(rowIndex);

				grcRow.createCell(0).setCellValue(grc.getCliMandt());
				grcRow.createCell(1).setCellValue(grc.getCliFunctId());
				grcRow.createCell(2).setCellValue(grc.getCliAction());
				grcRow.createCell(3).setCellValue(grc.getCliConnector());
				grcRow.createCell(4).setCellValue(grc.getMastFunctId());
				grcRow.createCell(5).setCellValue(grc.getMastAction());
				grcRow.createCell(6).setCellValue(grc.getMastConnector());
				grcRow.createCell(7).setCellValue(grc.getNewProposedActionsforCF());
				grcRow.createCell(8).setCellValue(grc.getStatus());
				rowIndex++;
			}
		}
		}catch (Exception e) {
			logger.error("writeGrcReport :: ",e);
			throw e;
		}
		logger.info("Sucessfully Wrote Grc Report Sheet:::%%%%%%%");
		logger.info(":: writeGrcReport Ended ::");
	}
	
	private void writeFioriReport(SXSSFSheet saFioriReportSheet, Integer requestID, int count) {
		logger.info(":: writeFioriReport started ::");
		try{
		int rowIndex = 1;
		List<SaFioriReportDownload> fioriReportList = getSecAnalyseDao().getSaFioriReportDownload(requestID, count);

		if (null != fioriReportList && !fioriReportList.isEmpty()) {
			Iterator<SaFioriReportDownload> fioriReportItr = fioriReportList.iterator();
			while (fioriReportItr.hasNext()) {

				SaFioriReportDownload fioriReport = fioriReportItr.next();
				Row fioriRow = saFioriReportSheet.createRow(rowIndex);

				fioriRow.createCell(0).setCellValue(fioriReport.getTargetVersion());
				fioriRow.createCell(1).setCellValue(fioriReport.getFunctionalArea());
				fioriRow.createCell(2).setCellValue(fioriReport.getAgrname());
				fioriRow.createCell(3).setCellValue(fioriReport.getLow());
				fioriRow.createCell(4).setCellValue(fioriReport.getHigh());
				fioriRow.createCell(5).setCellValue(fioriReport.getNewTcode());
				fioriRow.createCell(6).setCellValue(fioriReport.getFioriIdOldTcode());
				fioriRow.createCell(7).setCellValue(fioriReport.getAppNameOldTcode());
				fioriRow.createCell(8).setCellValue(fioriReport.getAppTypeOldTcode());
				fioriRow.createCell(9).setCellValue(fioriReport.getFrntPrdVersionOldTcode());
				fioriRow.createCell(10).setCellValue(fioriReport.getPrdVerNameBckEndOldTcode());
				fioriRow.createCell(11).setCellValue(fioriReport.getFioriIdNewTcode());
				fioriRow.createCell(12).setCellValue(fioriReport.getAppNameNewTcode());
				fioriRow.createCell(13).setCellValue(fioriReport.getAppTypeNewTcode());
				fioriRow.createCell(14).setCellValue(fioriReport.getFrntPrdverNewTcode());
				fioriRow.createCell(15).setCellValue(fioriReport.getPrdVerNameBckEndNewTcode());
				fioriRow.createCell(16).setCellValue(fioriReport.getStatus());
				rowIndex++;
			}
		}
		}catch (Exception e) {
			logger.error("writeFioriReport :: ",e);
			throw e;
		}
		logger.info("Sucessfully Wrote fiori app Report Sheet:::%%%%%%%");
		logger.info(":: writeFioriReport Ended ::");
	}


	@Override
	public String getSAReportsFromClient(Integer requestID, String userAccess, String userRole, Model model,
			HttpServletResponse response, HttpServletRequest request, RedirectAttributes redirectAttributes, RequestForm requestForm, HttpSession session, String userName, int count) {
		String result = "Success";
		// final RequestForm requestForm =
		// getRequestDetails().getRequestObj(requestID);
		try {
			String graphTemplete = "";

			if (Hana_Profiler_Constant.ACCESS_TRUE.equalsIgnoreCase(userAccess)) {
				graphTemplete = request.getSession().getServletContext()
						.getRealPath("/staticResources/GraphTemplate/SA_Reports.xlsx");
			}

			XSSFWorkbook workbook = new XSSFWorkbook(OPCPackage.open(new FileInputStream(graphTemplete)));
			@SuppressWarnings("resource")
			SXSSFWorkbook workbookTemp = new SXSSFWorkbook(workbook);
			workbookTemp.setCompressTempFiles(true);

			// Writing TCD Report
			writeSaTcdReport(workbookTemp, requestID, count);
						
			//Writing Fiori report
			SXSSFSheet saFioriReportSheet = (SXSSFSheet) workbookTemp.getSheetAt(1);
			saFioriReportSheet.setRandomAccessWindowSize(1000000);
			writeFioriReport(saFioriReportSheet, requestID, count);
						
			//Writing User and Roles Assignment report
			SXSSFSheet saUserAndRoleAssignmentSheet = (SXSSFSheet) workbookTemp.getSheetAt(2);
			saUserAndRoleAssignmentSheet.setRandomAccessWindowSize(1000000);
			writeUsersAndRoleAssignmentReport(saUserAndRoleAssignmentSheet, requestID);
			
			if(requestForm.getGrc()) {
			SXSSFSheet saGrcSheet = (SXSSFSheet) workbookTemp.getSheetAt(3);
			saGrcSheet.setRandomAccessWindowSize(1000000);
			writeGrcReport(saGrcSheet, requestID);
			}
						
			//Writing Object report
			writeSaObjectReport(workbookTemp, requestID, count);

			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			workbookTemp.write(bos);
			bos.close();

			byte[] bytes = bos.toByteArray();
			getFileDownload().downloadFile(bytes, response, HANAUtility.join("_", "Security Analyser", requestForm.getClientName(),
					requestForm.getSourceVersion(), requestForm.getTargetVersion(), requestID.toString())
					+ ".xlsx");//do this name correct
			String message = "Security File Downloaded succesfully";
			logger.info(message);
			if (StringUtils.isNotBlank(message) && "POC".equalsIgnoreCase(userRole)) {
				getRequestInventorydao().updateSaFileDownloadStatus(requestID, userName, true);

				
				RequestInventory reqInvObj = getRequestInventorydao().getRequestFromRequestId(new Long(requestID));
				/*if ((requestForm.getFiori() || requestForm.getS4Functional() || requestForm.getS4Technical()
						|| requestForm.getSOH() || requestForm.getUI5() || requestForm.getUPGRADE())
						&& reqInvObj.getFinalFileDnldSts() && reqInvObj.getSaFileDnldSts()) {
					logger.info(":: Inside the scopes and download bits condition :: ");
					getRequestInventorydao().updateSatusPOC(new Long(requestID), "", toolName, POC_Status, POC_Comment,
							Hana_Profiler_Constant.REQ_SS_Estimate_FL_DL_SUCC,
							Hana_Profiler_Constant.POC_DOWN_EST_SUCC);
				}*/
				boolean sia = requestForm.getSia() || requestForm.getGrc();
				boolean mainScp = requestForm.getSOH() || requestForm.getFiori()
						|| requestForm.getS4Functional() || requestForm.getS4Technical() || requestForm.getUI5()
						|| requestForm.getUPGRADE();
				/*if(sia && reqInvObj.getSaFileDnldSts()){
					logger.info(":: Inside the scopes and download bits condition :: ");
					getRequestInventorydao().updatePOCStatusAndSubStatus(Long.valueOf(requestID), userName, "Final_DOWN_DONE_POC", Hana_Profiler_Constant.REQ_SS_PROCESSED_FL_DL_SUCC);
				}
				if(!sia && reqInvObj.getFinalFileDnldSts()){
					logger.info(":: Inside the scopes and download bits condition :: ");
					getRequestInventorydao().updatePOCStatusAndSubStatus(Long.valueOf(requestID), userName, "Final_DOWN_DONE_POC", Hana_Profiler_Constant.REQ_SS_PROCESSED_FL_DL_SUCC);
				}
				if (sia && mainScp) {
					if(reqInvObj.getSaFileDnldSts() && reqInvObj.getFinalFileDnldSts()){
						logger.info(":: Inside the scopes and download bits condition :: ");
						getRequestInventorydao().updatePOCStatusAndSubStatus(Long.valueOf(requestID), userName, "Final_DOWN_DONE_POC", Hana_Profiler_Constant.REQ_SS_PROCESSED_FL_DL_SUCC);
					}
				}*/
				setPocStausAfterFileDownload(requestForm, requestID, userName, reqInvObj);
			}
		} catch (Exception e) {
			logger.error("Error in Downloading the Security Analyser reports :: ", e);
			return null;
		}
		return result;
	}
	
	
	public void setPocStausAfterFileDownload(RequestForm requestForm,Integer requestID,String userName, RequestInventory reqInvObj){
		boolean sia = requestForm.getSia() || requestForm.getGrc();
		boolean bw = requestForm.getBwUsage();
		boolean mainScp = requestForm.getSOH() || requestForm.getFiori()
				|| requestForm.getS4Functional() || requestForm.getS4Technical() || requestForm.getUI5()
				|| requestForm.getUPGRADE();
		if(bw && sia && mainScp){
			if(reqInvObj.getBwFileDnldSts() && reqInvObj.getSaFileDnldSts() && reqInvObj.getFinalFileDnldSts()){
				getRequestInventorydao().updatePOCStatusAndSubStatus(Long.valueOf(requestID), userName, "Final_DOWN_DONE_POC", Hana_Profiler_Constant.REQ_SS_PROCESSED_FL_DL_SUCC);
			}
		}
		else if(sia && bw && !mainScp){
			if(reqInvObj.getSaFileDnldSts() && reqInvObj.getBwFileDnldSts()){
				getRequestInventorydao().updatePOCStatusAndSubStatus(Long.valueOf(requestID), userName, "Final_DOWN_DONE_POC", Hana_Profiler_Constant.REQ_SS_PROCESSED_FL_DL_SUCC);
			}
			}
		else if(bw && mainScp && !sia){
			if(reqInvObj.getBwFileDnldSts() &&  reqInvObj.getFinalFileDnldSts()){
				getRequestInventorydao().updatePOCStatusAndSubStatus(Long.valueOf(requestID), userName, "Final_DOWN_DONE_POC", Hana_Profiler_Constant.REQ_SS_PROCESSED_FL_DL_SUCC);
			}
			
			}
		else if(sia && mainScp && !bw){
			if(reqInvObj.getFinalFileDnldSts() && reqInvObj.getSaFileDnldSts()){
				getRequestInventorydao().updatePOCStatusAndSubStatus(Long.valueOf(requestID), userName, "Final_DOWN_DONE_POC", Hana_Profiler_Constant.REQ_SS_PROCESSED_FL_DL_SUCC);
			}
			}
		else if(sia && !bw && !mainScp){
			if( reqInvObj.getSaFileDnldSts()){
				getRequestInventorydao().updatePOCStatusAndSubStatus(Long.valueOf(requestID), userName, "Final_DOWN_DONE_POC", Hana_Profiler_Constant.REQ_SS_PROCESSED_FL_DL_SUCC);
			}
			}
		else if(bw && !sia && !mainScp){
			if(reqInvObj.getBwFileDnldSts()){
				getRequestInventorydao().updatePOCStatusAndSubStatus(Long.valueOf(requestID), userName, "Final_DOWN_DONE_POC", Hana_Profiler_Constant.REQ_SS_PROCESSED_FL_DL_SUCC);
			}
			}
		else if(mainScp && !sia && !bw){
			if(reqInvObj.getFinalFileDnldSts()){
				getRequestInventorydao().updatePOCStatusAndSubStatus(Long.valueOf(requestID), userName, "Final_DOWN_DONE_POC", Hana_Profiler_Constant.REQ_SS_PROCESSED_FL_DL_SUCC);
			}
			}
	}

	@Override
	public void getSecurityAnalyserGrcReport(HttpSession session, Long requestID) throws Exception {
		try{
			getSecAnalyseDao().getSecurityAnalyserGrcReportFromSP(session, requestID);
			}catch (Exception e) {
				logger.error("getSecurityAnalyserGrcReport :: ",e);
				throw e;
			}
		
	}
	@Override
	public Integer getOutputFileCount(HttpSession session, Long requestID) throws SQLException {
		String query = "select out_File_Cnt from uploadfiles_number where requestId="+requestID;
		java.sql.Connection conn = null;
		Statement stmt = null;
		int count = 0;
		try {

			conn = DBConfig.getJDBCConnection(session);
			stmt =  conn.createStatement();
			try {
				ResultSet rs = stmt.executeQuery(query);
				
				while(rs.next()){
			          count  = rs.getInt("out_file_cnt");
			         
			      }
				rs.close();
			} catch (Exception e) {
				logger.error("Error in getOutputFileCount - ",e);
			}
		} catch (Exception e) {
			logger.error("Error in getOutputFileCount - ",e);

		} finally {
			stmt.close();
			conn.close();
			
		}
		return count;
		
	}
}
