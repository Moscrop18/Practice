package com.accenture.securityAnalyser.dao;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpSession;

import com.accenture.S4.models.GrtGracfuncact;
import com.accenture.S4.models.SaFioriReportDownload;
import com.accenture.S4.models.SaGrcReportDownload;
import com.accenture.S4.models.SaObjectReportDownload;
import com.accenture.S4.models.SaUserAndRoleAssignment;
import com.accenture.S4.models.SecurityAnalyserTCDReportDownload;
import com.accenture.S4.models.SrcAgr1251;
import com.accenture.S4.models.SrcAgrUsers;
import com.accenture.S4.models.SrcUsobtc;

public interface SecurityAnalyserDAO {

	public String securityAnalyserSrcAgrBatchInsertUpdate(List<SrcAgr1251> srcAgr1251List, HttpSession session)
			throws SQLException;
	
	public String securityAnalyserSourceUSOBTCBatchInsertUpdate(List<SrcUsobtc> srcUsobtcList, HttpSession session)
			throws SQLException;
	
	public String securityAnalyserAgrUsersBatchInsertUpdate(List<SrcAgrUsers> srcAgrUsersList, HttpSession session)
			throws SQLException;
	
	public void deleteSiaTableData(HttpSession session, String tableName);
	
	public void getSecurityAnalyserReportsFromSP(HttpSession session, Long requestID) throws Exception;
	public List<SecurityAnalyserTCDReportDownload> getSaTcdReport(Integer requestId, int count);
	public List<SaObjectReportDownload> getSaObjReport(Integer requestId,int count);
	public List<SaUserAndRoleAssignment> getSaUserAndRoleReportDownload(Integer requestId);
	public void transferDataFromTransToTcdDwnldTbl(HttpSession session) throws SQLException;
	public void transferDataFromTransToObjDwnldTbl(HttpSession session) throws SQLException;
	public void transferDataFromTransToFioriDwnldTbl(HttpSession session) throws SQLException;
	public List<SaFioriReportDownload> getSaFioriReportDownload(Integer requestId, int count);
	
	public String securityAnalyserGrcDetailsBatchInsertUpdate(List<GrtGracfuncact> grcList, HttpSession session)
			throws SQLException;
	public void getSecurityAnalyserGrcReportFromSP(HttpSession session, Long requestID) throws Exception;
	public void transferDataFromTransToGrcDwnldTbl(HttpSession session, Long requestId) throws SQLException;
	public List<SaGrcReportDownload> getSaGrcReportDownload(Integer requestId);
}
