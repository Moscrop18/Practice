package com.accenture.fileprocesing.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;

import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.accenture.displaygrid.model.DBConfig;
import com.accenture.fiori.models.FioriFinalOutputList;
import com.accenture.fiori.models.InventoryStandardFioriIntermediate;
import com.accenture.fiori.models.OdataFioriApps;
import com.accenture.fiori.models.OdataFioriMasterData;
import com.accenture.master.FioriRequestMaster;

@Transactional
@Repository
public class FioriProcessingDAOImpl implements FioriProcessingDAO {
	protected final static Logger logger = LoggerFactory.getLogger(FioriProcessingDAOImpl.class);
	SessionFactory sessionFactory;

	static FioriFinalOutputList fioriFinalOutputList;

	public static FioriFinalOutputList getFioriFinalOutputList() {
		return fioriFinalOutputList;
	}

	public static void setFioriFinalOutputList(FioriFinalOutputList fioriFinalOutputList) {
		OdataFioriProcessDaoImpl.fioriFinalOutputList = fioriFinalOutputList;
	}

	private String hql;
	static FioriRequestMaster fioriRequestMaster = new FioriRequestMaster();

	public static FioriRequestMaster getFioriRequestMaster() {
		return fioriRequestMaster;
	}

	public static void setFioriRequestMaster(FioriRequestMaster fioriRequestMaster) {
		OdataFioriProcessDaoImpl.fioriRequestMaster = fioriRequestMaster;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public String processFioriApps(final long requestID, List<OdataFioriApps> odataFioriAppsList, String sourceVersion, String targetVersion,
			HttpSession session) throws Exception {
		try {
			logger.info("Inside processFioriApps method ..");
			fioriFinalOutputList = new FioriFinalOutputList();
			List<OdataFioriMasterData> fioriMasterDataList = getFioriFromMasterData(session);
			buildFioriFinalOutput(requestID, odataFioriAppsList, fioriMasterDataList, sourceVersion, targetVersion, session);// comment
			updateAvailabilityAndVersion(requestID, session, targetVersion);
		} catch (Exception e) {
			logger.error("Catching exception stack trace.............. ..", e);
			throw new Exception("Exception in processing Fiori files");
		}
		return "success";
	}

	protected void buildFioriFinalOutput(final long requestID, List<OdataFioriApps> odataFioriAppsList,
			List<OdataFioriMasterData> fioriMasterDataList, String sourceVersion, String targetVersion, HttpSession session)
			throws SQLException {
		List<InventoryStandardFioriIntermediate> invtryStntdFioriListIWSV = new ArrayList<InventoryStandardFioriIntermediate>();
		List<InventoryStandardFioriIntermediate> invtryStntdFioriListOUI5 = new ArrayList<InventoryStandardFioriIntermediate>();
		List<InventoryStandardFioriIntermediate> invtryStntdFioriList = new ArrayList<InventoryStandardFioriIntermediate>();
		for (OdataFioriApps odataFioriApps : odataFioriAppsList) {
			if (odataFioriApps.getObject().equalsIgnoreCase("IWSV")) {
				if (odataFioriApps.getReadProg() != null && !odataFioriApps.getReadProg().equalsIgnoreCase("")) {
					// usecase1
					List<InventoryStandardFioriIntermediate> invtryStntdFiori = compareOdataServices(requestID,
							fioriMasterDataList, odataFioriApps, sourceVersion, targetVersion);
					if (invtryStntdFiori != null && !invtryStntdFiori.isEmpty()) {
						invtryStntdFioriListIWSV.addAll(invtryStntdFiori);
					}
				}

			}
			if (odataFioriApps.getObject().equalsIgnoreCase("OUI5")) {
				// usecase1
				if (odataFioriApps.getObjName() != null && !odataFioriApps.getObjName().equalsIgnoreCase("")) {
					List<InventoryStandardFioriIntermediate> invntryStndUI5Services = compareUI5Services(requestID,
							fioriMasterDataList, odataFioriApps, sourceVersion, targetVersion);
					if (invntryStndUI5Services != null && !invntryStndUI5Services.isEmpty()) {
						invtryStntdFioriListOUI5.addAll(invntryStndUI5Services);
					}

				}

			}

			// Add in list and then insert
		}
		Set<InventoryStandardFioriIntermediate> result = invtryStntdFioriListIWSV.stream()
				  .distinct()
				  .filter(invtryStntdFioriListOUI5::contains)
				  .collect(Collectors.toSet());
		invtryStntdFioriList.addAll(result);
				
		inventoryStandardFioriInsert(invtryStntdFioriList, session);
	}

	protected List<InventoryStandardFioriIntermediate> compareOdataServices(final long requestID,
			List<OdataFioriMasterData> fioriMasterDataList, OdataFioriApps odataFioriApps,String sourceVersion, String targetVersion) {
		logger.info("IWSV.........." + odataFioriApps.getReadProg());
		List<InventoryStandardFioriIntermediate> invtryStndFioriList = new ArrayList<InventoryStandardFioriIntermediate>();
		for (OdataFioriMasterData fioriMasterData : fioriMasterDataList) {
			String odataServicesCombined = fioriMasterData.getOdataServicesCombined();// dont
			String srcVersion = "";														// do
																						// this
			if (odataServicesCombined != null && !odataServicesCombined.equalsIgnoreCase("")) {
				odataServicesCombined = odataServicesCombined.toUpperCase();
				
				if (sourceVersion.startsWith("S/4HANA")) {
					srcVersion = sourceVersion.split("S/4HANA")[1];
				} else if (sourceVersion.equalsIgnoreCase("ECC6.0EHP7")) {
					srcVersion = "SAP enhancement package 7";
				} else if (sourceVersion.equalsIgnoreCase("ECC6.0EHP8")) {
					srcVersion = "SAP enhancement package 8";
				}
				
				String pvBackendCombined = fioriMasterData.getPvBackendCombined();
				if (odataServicesCombined.contains(odataFioriApps.getReadProg().toUpperCase()) && !srcVersion.equalsIgnoreCase("") && pvBackendCombined.contains(srcVersion)) {

					InventoryStandardFioriIntermediate invtryStndFiori = new InventoryStandardFioriIntermediate();
					invtryStndFiori.setRequestID(requestID);
					invtryStndFiori.setAppId(fioriMasterData.getAppId());
					//invtryStndFiori.setObject(odataFioriApps.getObject());
					//invtryStndFiori.setObjName(odataFioriApps.getObjName());
					invtryStndFiori.setAppName(fioriMasterData.getAppName());
					invtryStndFiori.setBspNameCombined(fioriMasterData.getBspNameCombined());
					invtryStndFiori.setOdataServicesCombined(fioriMasterData.getOdataServicesCombined());
					String version = "";
					if (targetVersion.startsWith("S/4HANA"))
						version = targetVersion.split("S/4HANA")[1];
					if (pvBackendCombined.contains(version)) {
						invtryStndFiori.setAvailability("Available in " + version);
						invtryStndFiori.setVersion("");
						invtryStndFiori.setAltName("Activate the application");
					} else {
						invtryStndFiori.setAvailability("Not Available in " + version);
						invtryStndFiori=checkSuccessorRelatedApp(fioriMasterData,fioriMasterDataList,invtryStndFiori,targetVersion);
					}
					invtryStndFioriList.add(invtryStndFiori);
				}
			}
		}
		return invtryStndFioriList;

	}
	protected InventoryStandardFioriIntermediate checkSuccessorRelatedApp(OdataFioriMasterData fioriMasterData,
			List<OdataFioriMasterData> fioriMasterDataList, InventoryStandardFioriIntermediate invtryStndFiori,
			String targetVersion) {

		String appId = "";
	

		if (fioriMasterData != null) {
			if (!fioriMasterData.getSuccessorApp().equalsIgnoreCase("NA")) {
				appId = fioriMasterData.getSuccessorApp();
				for (OdataFioriMasterData app : fioriMasterDataList) {
					if (app.getAppId().equalsIgnoreCase(appId)) {
						String pvBackendCombined = app.getPvBackendCombined();
						String version = "";
						if (targetVersion.startsWith("S/4HANA"))
							version = targetVersion.split("S/4HANA")[1];
						if (pvBackendCombined.contains(version)) {
							invtryStndFiori.setSuccessorAppId(fioriMasterData.getSuccessorApp());
							invtryStndFiori.setRelatedAppId("");
						} else {
							invtryStndFiori.setSuccessorAppId("");
							invtryStndFiori.setRelatedAppId("");
						}
					}
				}
			}
			if (!fioriMasterData.getRelatedApp().equalsIgnoreCase("NA")) {
				appId = fioriMasterData.getRelatedApp();
				for (OdataFioriMasterData app : fioriMasterDataList) {
					if (app.getAppId().equalsIgnoreCase(appId)) {
						String pvBackendCombined = app.getPvBackendCombined();
						String version = "";
						if (targetVersion.startsWith("S/4HANA"))
							version = targetVersion.split("S/4HANA")[1];
						if (pvBackendCombined.contains(version)) {
							invtryStndFiori.setSuccessorAppId("");
							invtryStndFiori.setRelatedAppId(fioriMasterData.getRelatedApp());
						} else {
							invtryStndFiori.setSuccessorAppId("");
							invtryStndFiori.setRelatedAppId("");
						}
					}
				}
			}
		}
		return invtryStndFiori;
	}
	protected List<InventoryStandardFioriIntermediate> compareUI5Services(final long requestID,
			List<OdataFioriMasterData> fioriMasterDataList, OdataFioriApps odataFioriApps, String sourceVersion, String targetVersion) {

		List<InventoryStandardFioriIntermediate> invtryStndFioriList = new ArrayList<InventoryStandardFioriIntermediate>();
		String srcVersion = "";
		for (OdataFioriMasterData fioriMasterData : fioriMasterDataList) {
			String bspNameCombined = fioriMasterData.getBspNameCombined();
			if (bspNameCombined != null && !bspNameCombined.equalsIgnoreCase("")) {
				bspNameCombined = bspNameCombined.toUpperCase();
				String pcdCombined = fioriMasterData.getPcdCombined();
				String pvBackendCombined = fioriMasterData.getPvBackendCombined();
				
				if (sourceVersion.startsWith("S/4HANA")) {
					srcVersion = sourceVersion.split("S/4HANA")[1];
				} else if (sourceVersion.equalsIgnoreCase("ECC6.0EHP7")) {
					srcVersion = "SAP enhancement package 7";
				} else if (sourceVersion.equalsIgnoreCase("ECC6.0EHP8")) {
					srcVersion = "SAP enhancement package 8";
				}
				if (bspNameCombined.contains("$"+odataFioriApps.getObjName().toUpperCase()+"$") && !srcVersion.equalsIgnoreCase("") && pvBackendCombined.contains(srcVersion)) {
					InventoryStandardFioriIntermediate invtryStndFiori = new InventoryStandardFioriIntermediate();
					invtryStndFiori.setRequestID(requestID);
					invtryStndFiori.setAppId(fioriMasterData.getAppId());
					//invtryStndFiori.setObject(odataFioriApps.getObject());
					invtryStndFiori.setAppName(fioriMasterData.getAppName());
					//invtryStndFiori.setObjName(odataFioriApps.getObjName());
					invtryStndFiori.setBspNameCombined(fioriMasterData.getBspNameCombined());
					invtryStndFiori.setOdataServicesCombined(fioriMasterData.getOdataServicesCombined());
					String version = "";
					if (targetVersion.startsWith("S/4HANA"))
						version = targetVersion.split("S/4HANA")[1];
					if (pvBackendCombined.contains(version)) {
						invtryStndFiori.setAvailability("Available in " + version);
						invtryStndFiori.setVersion("");
						invtryStndFiori.setAltName("Activate the application");
					} else {
						invtryStndFiori.setAvailability("Not Available in " + version);
						invtryStndFiori=checkSuccessorRelatedApp(fioriMasterData,fioriMasterDataList,invtryStndFiori,targetVersion);
					}

					invtryStndFioriList.add(invtryStndFiori);
				}
			}

		}
		return invtryStndFioriList;

	}

	protected List<OdataFioriMasterData> getFioriFromMasterData(HttpSession session) throws SQLException {// App
																											// Id,
																											// App
																											// Name,PVBackendCombined,ODataServicesCombined,bspName
																											// we
																											// need
																											// only
																											// from
																											// master
																											// for
																											// now,
		final String SELECT_SQL = "Select AppId, BspName, BSPNameCombined, ODataServicesCombined,AppName,PVBackendCombined,successorApp,relatedApp from Fiori_MasterData";
		List<OdataFioriMasterData> masterDataList = new ArrayList<OdataFioriMasterData>();
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);

			conn.setAutoCommit(false);

			stmt = conn.prepareStatement(SELECT_SQL);

			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {

				OdataFioriMasterData fioriMasterData = new OdataFioriMasterData();
				fioriMasterData.setAppId(rs.getString("AppId"));
				fioriMasterData.setBspName(rs.getString("BspName"));
				fioriMasterData.setBspNameCombined(rs.getString("BSPNameCombined"));
				fioriMasterData.setOdataServicesCombined(rs.getString("ODataServicesCombined"));
				fioriMasterData.setAppName(rs.getString("AppName"));
				fioriMasterData.setPvBackendCombined(rs.getString("PVBackendCombined"));
				fioriMasterData.setSuccessorApp(rs.getString("successorApp"));
				fioriMasterData.setRelatedApp(rs.getString("relatedApp"));

				masterDataList.add(fioriMasterData);
			}

			logger.info("Fiori Master Sheet  Data selected SUCCESSFULLY");

		} finally {
			if (stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				conn.close();
			}

		}
		return masterDataList;

	}

	public static String inventoryStandardFioriInsert(List<InventoryStandardFioriIntermediate> invtrystndFioriList,
			HttpSession session) throws SQLException {

		final String INSERT_SQL = "INSERT INTO Inventory_Std_Fiori_Intermediate "
				+ "(AppId, Availability, REQUEST_ID, App_Name, VERSION, Alternate_Name, BSPNameCombined, OdataServicesCombined, SuccessorAppId, RelatedAppId) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);

			stmt = conn.prepareStatement(INSERT_SQL);
			int batch = 1;

			for (InventoryStandardFioriIntermediate stndFiori : invtrystndFioriList) {
				//stmt.setString(1, stndFiori.getObject());
				//stmt.setString(2, stndFiori.getObjName());
				stmt.setString(1, stndFiori.getAppId());
				stmt.setString(2, stndFiori.getAvailability());
				stmt.setLong(3, stndFiori.getRequestID());
				stmt.setString(4, stndFiori.getAppName());
				stmt.setString(5, stndFiori.getVersion());
				stmt.setString(6, stndFiori.getAltName());
				stmt.setString(7, stndFiori.getBspNameCombined());
				stmt.setString(8, stndFiori.getOdataServicesCombined());
				stmt.setString(9, stndFiori.getSuccessorAppId());
				stmt.setString(10, stndFiori.getRelatedAppId());

				// Add statement to batch
				stmt.addBatch();
				counter++;
				// Execute batch of 10000 records
				if (counter % 10000 == 0) {
					counter = 0;
					stmt.executeBatch();
					conn.commit();
					logger.info("Batch " + (batch++) + " executed successfully");
				}
			}

			stmt.executeBatch();
			conn.commit();
			logger.info("Standard Fiori Inventory intermediate Data INSERTED SUCCESSFULLY");

		} finally {
			if (stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				conn.close();
			}

		}

		return result;

	}

	public void updateAvailabilityAndVersion(Long requestId, HttpSession session, String targetVersion) {
		String updateSQL = "UPDATE Inventory_Std_Fiori_Intermediate isfi "
				+ "INNER JOIN "
				+ "Fiori_Rebuild_Master frms "
				+ "ON isfi.AppId = frms.App_Id "
				+ "SET Version = CASE "
					+ "WHEN isfi.Availability LIKE 'Not Available%'"
					+ "THEN "
						+ "CASE "
							+ "WHEN frms.Version_Check LIKE '%" + targetVersion + "%' "
							+ "THEN frms.List_Of_Similar_Applications "
							+ "ELSE  ''"
							+ "END "
					+ "ELSE Version "
					+ "END "
				+ ", "
				+ "Alternate_Name = CASE "
				    + "WHEN isfi.Availability LIKE 'Not Available%' " 
					+ "THEN " 
				    	+ "CASE " 
				    		+ "WHEN frms.Version_Check LIKE '%" + targetVersion + "%' " 
				    		+ "THEN frms.remarks " 
				    		+ "ELSE 'Functional inputs required to generate custom apps' " 
				    		+ "END "
				    + "ELSE Alternate_Name "
					+ "END";

		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {
			conn = DBConfig.getJDBCConnection(session);

			stmt = conn.prepareStatement(updateSQL);
			stmt.executeUpdate();
		} catch (SQLException e) {
			logger.error("updateAvailabilityAndVersion :: ", e);
		}
	}
}
