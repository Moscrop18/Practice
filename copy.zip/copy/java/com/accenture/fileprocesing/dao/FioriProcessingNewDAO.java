package com.accenture.fileprocesing.dao;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpSession;

import com.accenture.fiori.models.CustomReportOutput;
import com.accenture.fiori.models.OdataFioriApps;

public interface FioriProcessingNewDAO {

	public String processFioriApps(final long requestID, List<CustomReportOutput> customReportOutputList, String sourceVersion, String targetVersion,
			HttpSession session) throws Exception;
}
