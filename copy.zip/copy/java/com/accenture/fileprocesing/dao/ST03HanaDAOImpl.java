package com.accenture.fileprocesing.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.commons.collections.CollectionUtils;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.accenture.constant.Hana_Profiler_Constant;
import com.accenture.displaygrid.model.DBConfig;
import com.accenture.exceptions.HibernateException;
import com.accenture.fileprocessing.model.HanaProfilerStepOutput;
import com.accenture.fileprocessing.model.TestTab;
import com.accenture.fileprocessing.model.TestTab1;

@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
public class ST03HanaDAOImpl {

	final Logger logger = LoggerFactory.getLogger(ST03HanaDAOImpl.class);

	public SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public void insertORUpdate(Long requestID, String sql) {
		try {
			logger.info("Executing query::" + sql);
			Session session = sessionFactory.getCurrentSession();
			if (null == session) {
				session = sessionFactory.openSession();
			}
			Query query = session.createQuery(sql);
			logger.info("requestID" + requestID);
			query.setParameter("requestID", requestID);
			query.executeUpdate();
			logger.info("Successfully Save the in Database");
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}

	}

	@Transactional
	public int delete(Long requestID, String sql) {
		Session session = sessionFactory.getCurrentSession();
		if (null == session) {
			session = sessionFactory.openSession();
		}

		Query query = session.createQuery(sql);
		query.setParameter("requestID", requestID);
		int count = query.executeUpdate();

		logger.info("Successfully Save the in Database");

		return count;
	}

	@Transactional
	public void deleteFromTable(Long requestID, String tableName) {
		Session session = sessionFactory.getCurrentSession();
		if (null == session) {
			session = sessionFactory.openSession();
		}

		String sql = "delete from " + tableName + " where requestID=" + requestID;
		logger.info("sql" + sql);
		Query query = session.createQuery(sql);
		query.executeUpdate();
		logger.info("Successfully deleted from the Database");

		// session.close();
	}

	@Transactional
	public void deleteFromTableWithReqIdName(Long requestID, String tableName, String reqColName) {
		try {
			Session session = sessionFactory.getCurrentSession();

			String sql = "delete from " + tableName + " where " + reqColName + "=" + requestID;
			logger.info("SQL : " + sql);
			Query query = session.createQuery(sql);
			query.executeUpdate();
			logger.info("Successfully deleted from the Database");
		} catch (Exception e) {
			logger.error("Error while deleting from " + tableName + " : ", e);
		}
	}

	@Transactional
	public void deleteFromSmodilogFunctionTable(Long requestID, String tableName) {
		Session session = sessionFactory.getCurrentSession();
		if (null == session) {
			session = sessionFactory.openSession();
		}

		String sql = "delete from " + tableName + " where requestId=" + requestID;
		logger.info("sql" + sql);
		Query query = session.createQuery(sql);
		query.executeUpdate();
		logger.info("Successfully deleted from the Database Table SmodilogFunction");

		// session.close();
	}

	@Transactional
	public void deleteFromRequestidTable(Long requestid, String tableName) {
		Session session = sessionFactory.getCurrentSession();
		if (null == session) {
			session = sessionFactory.openSession();
		}

		String sql = "delete from " + tableName + " where requestid=" + requestid;
		logger.info("sql" + sql);
		Query query = session.createQuery(sql);
		query.executeUpdate();
		logger.info("Successfully deleted from the Database");

		// session.close();
	}

	public void deleteTables(Long requestID, String tableName) {
		Session session = sessionFactory.getCurrentSession();
		if (null == session) {
			session = sessionFactory.openSession();
		}

		String sql = "delete from " + tableName + " where REQUEST_ID=" + requestID;
		logger.info("sql" + sql);
		Query query = session.createQuery(sql);
		query.executeUpdate();
		logger.info("Successfully deleted from the Database");

		// session.close();
	}

	public void deleteREQUEST_IDforScripts(long requestID, String tableName) {
		Session session = sessionFactory.getCurrentSession();
		if (null == session) {
			session = sessionFactory.openSession();
		}

		String sql = "delete from " + tableName + " where REQUEST_ID=" + requestID;
		logger.info("sql" + sql);
		Query query = session.createQuery(sql);
		query.executeUpdate();
		logger.info("Successfully deleted from the Database");

		// session.close();
	}

	public void deleteREQUEST_IDTables(Long requestID, String tableName) {
		Session session = sessionFactory.getCurrentSession();
		if (null == session) {
			session = sessionFactory.openSession();
		}

		String sql = "delete from " + tableName + " where REQUEST_ID=" + requestID;
		logger.info("sql" + sql);
		Query query = session.createQuery(sql);
		query.executeUpdate();
		logger.info("Successfully deleted from the Database");

		// session.close();
	}

	@Transactional
	public void transferData(String sql) {

		Session session = sessionFactory.getCurrentSession();
		if (null == session) {
			session = sessionFactory.openSession();
		}
		logger.info("sql" + sql);
		Query query = session.createSQLQuery(sql);
		query.executeUpdate();
		logger.info("Successfully Inserted data into table");
		// session.close();
	}

	@Transactional
	public List<String> select(String sql, Long requestID) {
		Session session = sessionFactory.getCurrentSession();
		if (null == session) {
			session = sessionFactory.openSession();
		}

		Query query = session.createQuery(sql);
		query.setParameter("requestID", requestID);
		List<String> list = query.list();

		logger.info("Inside select with requestID");

		// session.close();
		return list;
	}

	@Transactional
	public void deleteWithList(final Long requestID, final String sql, final List<String> progNameList) {
		if (CollectionUtils.isNotEmpty(progNameList)) {
			Session session = sessionFactory.getCurrentSession();
			if (null == session) {
				session = sessionFactory.openSession();
			}
			Query query = session.createQuery(sql);
			query.setParameter("requestID", requestID);
			query.setParameterList("progName", progNameList);
			query.executeUpdate();
			logger.info("Successfully Save the in Database");
		}
		// session.close();
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public List<TestTab> getTestTabData(long requestId) {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(TestTab.class);
			criteria.add(Restrictions.eq("requestID", requestId));
			return criteria.list();

		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

	@Transactional
	public List<TestTab1> getTestTab1Data(long requestId) {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(TestTab1.class);
			criteria.add(Restrictions.eq("requestID", requestId));
			return criteria.list();

		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

	// ST03 Code deleted
	/*
	 * @SuppressWarnings("unchecked")
	 * 
	 * @Transactional public List<ST03MonthData> getSt03MonthData(final long
	 * requestId, final Set<String> progNameSet) { Session session = null;
	 * List<ST03MonthData> st03MonthDataList = null; try { if
	 * (CollectionUtils.isNotEmpty(progNameSet)) { session =
	 * sessionFactory.openSession(); final Criteria criteria =
	 * session.createCriteria(ST03MonthData.class);
	 * criteria.add(Restrictions.eq("requestID", requestId));
	 * criteria.add(Restrictions.in("progName", progNameSet)); st03MonthDataList
	 * = criteria.list(); } return st03MonthDataList; } catch (Exception e) {
	 * logger.error(e.getMessage()); logger.trace(e.getMessage()); throw new
	 * HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE); }
	 * finally { if (session != null) { session.close(); } }
	 * 
	 * }
	 * 
	 * @SuppressWarnings("unchecked")
	 * 
	 * @Transactional public List<ST03Custom> getSt03CustomData(final long
	 * requestId, final Set<String> progNameSet) { Session session = null; try {
	 * session = sessionFactory.openSession(); final Criteria criteria =
	 * session.createCriteria(ST03Custom.class);
	 * criteria.add(Restrictions.eq("requestID", requestId)); if
	 * (CollectionUtils.isNotEmpty(progNameSet)) {
	 * criteria.add(Restrictions.in("progName", progNameSet)); } return
	 * criteria.list(); } catch (Exception e) { logger.error(e.getMessage());
	 * logger.trace(e.getMessage()); throw new
	 * HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE); }
	 * finally { if (session != null) { session.close(); } }
	 * 
	 * }
	 * 
	 * public List<String> getIncludeList(final long requestId) {
	 * 
	 * Session session = null; try { session = sessionFactory.openSession();
	 * final Criteria criteria = session.createCriteria(IncludeExtractor.class);
	 * criteria.add(Restrictions.eq("status", "YES"));
	 * criteria.add(Restrictions.eq("requestID", requestId));
	 * criteria.setProjection(Projections.property("includes")); return
	 * criteria.list(); } catch (Exception e) { logger.error(e.getMessage());
	 * logger.trace(e.getMessage()); throw new
	 * HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE); }
	 * finally { if (session != null) { session.close(); } }
	 * 
	 * }
	 */
	@SuppressWarnings("unchecked")
	public List<HanaProfilerStepOutput> getHanaProfilerStepOutputList(final long requestId,
			final List<String> objectNameList) {

		Session session = null;
		try {
			session = sessionFactory.openSession();
			final Criteria criteria = session.createCriteria(HanaProfilerStepOutput.class);
			criteria.add(Restrictions.eq("objectType", "PROG"));
			criteria.add(Restrictions.eq("requestID", requestId));
			criteria.add(Restrictions.in("objName", objectNameList));
			// criteria.add(Restrictions.ne("usedUnused", "Used"));
			return criteria.list();
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

	/*
	 * @SuppressWarnings("unchecked") public List<String>
	 * getST03CustomObjectProgNameList(final long requestId) {
	 * 
	 * Session session = null; try { session = sessionFactory.openSession();
	 * final Criteria criteria =
	 * session.createCriteria(ST03CustomObjects.class);
	 * criteria.add(Restrictions.eq("requestID", requestId));
	 * criteria.setProjection(Projections.property("progName")); return
	 * criteria.list(); } catch (Exception e) { logger.error(e.getMessage());
	 * logger.trace(e.getMessage()); throw new
	 * HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE); }
	 * finally { if (session != null) { session.close(); } }
	 * 
	 * }
	 * 
	 * @SuppressWarnings("unchecked") public List<IncludeExtractor>
	 * getIncludeExtractorList(final long requestId, final List<String>
	 * progNameList) {
	 * 
	 * Session session = null; try { session = sessionFactory.openSession();
	 * final Criteria criteria = session.createCriteria(IncludeExtractor.class);
	 * criteria.add(Restrictions.eq("requestID", requestId));
	 * criteria.add(Restrictions.in("progName", progNameList)); //
	 * criteria.add(Restrictions.ne("status", "YES")); return criteria.list(); }
	 * catch (Exception e) { logger.error(e.getMessage());
	 * logger.trace(e.getMessage()); throw new
	 * HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE); }
	 * finally { if (session != null) { session.close(); } }
	 * 
	 * }
	 * 
	 * public List<String> getST03CustomProgNameList(long requestId) {
	 * 
	 * Session session = null; try { session = sessionFactory.openSession();
	 * final Criteria criteria = session.createCriteria(ST03Custom.class);
	 * criteria.add(Restrictions.eq("requestID", requestId));
	 * criteria.setProjection(Projections.property("progName")); return
	 * criteria.list(); } catch (Exception e) { logger.error(e.getMessage());
	 * logger.trace(e.getMessage()); throw new
	 * HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE); }
	 * finally { if (session != null) { session.close(); } }
	 * 
	 * }
	 * 
	 * @SuppressWarnings("unchecked") public List<ST03CustomDialog>
	 * getSt03CustomDialogList(long requestId) {
	 * 
	 * Session session = null; try { session = sessionFactory.openSession();
	 * final Criteria criteria = session.createCriteria(ST03CustomDialog.class);
	 * criteria.add(Restrictions.eq("requestID", requestId)); return
	 * criteria.list(); } catch (Exception e) { logger.error(e.getMessage());
	 * logger.trace(e.getMessage()); throw new
	 * HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE); }
	 * finally { if (session != null) { session.close(); } }
	 * 
	 * }
	 */
	@SuppressWarnings("unchecked")
	public List<HanaProfilerStepOutput> getHanaProfilerStepOutputListWithDialgStepNull(long requestId) {

		Session session = null;
		try {
			session = sessionFactory.openSession();
			final Criteria criteria = session.createCriteria(HanaProfilerStepOutput.class);
			criteria.add(Restrictions.eq("requestID", requestId));
			criteria.add(Restrictions.isNull("dialogSteps"));
			criteria.add(Restrictions.eq("objectType", "PROG"));
			return criteria.list();
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

	public List<HanaProfilerStepOutput> getHanaProfilerStepOutputListWithDbChangePercentNull(final long requestId) {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			final Criteria criteria = session.createCriteria(HanaProfilerStepOutput.class);
			criteria.add(Restrictions.eq("requestID", requestId));
			criteria.add(Restrictions.or(Restrictions.isNull("dbPercent"), Restrictions.isNull("changePercent")));
			criteria.add(Restrictions.eq("objectType", "PROG"));
			return criteria.list();
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

	public List<String> getDB_ChangePercent(Long requestId, String hql) {
		List<String> resultList = new ArrayList<String>();
		Session session = null;
		try {
			session = sessionFactory.openSession();
			hql = hql + "" + requestId;

			List<List<Object>> resulmap = session.createSQLQuery(hql).setResultTransformer(Transformers.TO_LIST).list();
			if (!resulmap.isEmpty()) {
				for (List<Object> x : resulmap) {
					resultList.add((String) x.get(0).toString() + "@@@@" + (String) x.get(1).toString());
				}
			}
			return resultList;
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

	public void saveDBPercentMonth(Long requestId, String hql, List<String> dataList) {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Query query = session.createQuery(hql);
			String records[];
			int size = dataList.size();
			if (size > 0) {
				for (int i = 0; i < size; i++) {
					records = dataList.get(i).split("@@@@");
					query.setParameter("dbPercentMonth", records[0]);
					query.setParameter("requestID", requestId);
					query.setParameter("objectName", records[1]);
					query.executeUpdate();
				}
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

	public void saveChangePercentMonth(Long requestId, String hql, List<String> dataList) {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Query query = session.createQuery(hql);
			String records[];
			int size = dataList.size();
			if (size > 0) {
				for (int i = 0; i < size; i++) {
					records = dataList.get(i).split("@@@@");
					query.setParameter("changePercentMonth", records[0]);
					query.setParameter("requestID", requestId);
					query.setParameter("objectName", records[1]);
					query.executeUpdate();
				}
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

	public String getClientNameSpace_Name(Long REQUEST_ID) {
		String name = "";
		Session session = null;
		session = sessionFactory.openSession();
		ArrayList list = (ArrayList) session
				.createSQLQuery("SELECT CUSTOMER_NAMESPACE FROM REQUEST_FORM  WHERE  REQUEST_ID =" + REQUEST_ID).list();
		name = list.get(0).toString().trim();
		session.close();
		return name;
	}

	public void deleteFromEstimatesTable(Long requestID, String tableName) throws SQLException {
		Session session = sessionFactory.getCurrentSession();

		String sql = "delete from " + tableName + " where requestID=" + requestID;
		logger.info("sql" + sql);
		Query query = session.createQuery(sql);
		query.executeUpdate();
		logger.info("Successfully Deleted from the Estimates_Request_Master Table ");
	}

	public void deleteFromRomEstimatesTable(Long requestID, String tableName) throws SQLException {
		Session session = sessionFactory.getCurrentSession();

		String sql = "delete from " + tableName + " where requestID=" + requestID;
		logger.info("sql" + sql);
		Query query = session.createQuery(sql);
		query.executeUpdate();
		logger.info("Successfully Deleted from the TADIR Inventory Table ");
	}

	@Transactional
	public void deleteFromCvitAssessmentTable(Long requestID, String tableName) {
		Session session = sessionFactory.getCurrentSession();
		if (null == session) {
			session = sessionFactory.openSession();
		}
		String sql = "delete from " + tableName + " where requestId=" + requestID;
		logger.info("sql" + sql);
		Query query = session.createQuery(sql);
		query.executeUpdate();
		logger.info("Successfully deleted from the Database");

		// session.close();
	}

	@Transactional
	public void deleteFromFioriTable(Long requestID, String tableName) {
		Session session = sessionFactory.getCurrentSession();
		if (null == session) {
			session = sessionFactory.openSession();
		}
		String sql = "delete from " + tableName + " where requestId=" + requestID;
		logger.info("sql" + sql);
		Query query = session.createQuery(sql);
		query.executeUpdate();
		logger.info("Successfully deleted from the Database");

		// session.close();
	}

	@Transactional
	public void deleteFromExtTable(Long requestId, String tableName) {
		Session session = sessionFactory.getCurrentSession();
		if (null == session) {
			session = sessionFactory.openSession();
		}

		String sql = "delete from " + tableName + " where requestId=" + requestId;
		logger.info("sql" + sql);
		Query query = session.createQuery(sql);
		query.executeUpdate();
		logger.info("Successfully deleted from the Database");
	}

	public void truncateTable(String tableName, HttpSession session) {
		StringBuilder truncateSQL = new StringBuilder("TRUNCATE " + tableName);

		try (java.sql.Connection conn = DBConfig.getJDBCConnection(session);
				java.sql.Statement stmt = conn.createStatement()) {
			stmt.executeUpdate(truncateSQL.toString());
		} catch (Exception e) {
			logger.error("Error while truncating table " + tableName + " : ", e);
		}
	}

	public void deleteFromSimplification(Long requestId) {
		String deleteQuery = "DELETE FROM S4HanaProfiler WHERE requestID = :requestId AND "
				+ "(operations = :drilldown OR descOfChange = :obsoletefm)";
		Session session = null;

		try {
			session = sessionFactory.openSession();
			Query query = session.createQuery(deleteQuery);
			query.setParameter("requestId", requestId);
			query.setParameter("drilldown", "DRILLDOWN REPORT");
			query.setParameter("obsoletefm", "OBSOLETE FM DUE TO UPGRADE");

			query.executeUpdate();
		} catch (Exception e) {
			logger.error("Error while deleting drill down and obsolete fm entries from detailed report : ", e);
		} finally {
			if (session != null)
				session.close();
		}
	}
}
