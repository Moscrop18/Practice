package com.accenture.fileprocesing.dao;

import java.util.List;

import javax.servlet.http.HttpSession;

import com.accenture.fiori.models.OdataFioriApps;

public interface FioriProcessingDAO {

	public String processFioriApps(final long requestID,List<OdataFioriApps>odataFioriAppsList ,String sourceVersion, String targetVersion,HttpSession session) throws Exception;
	
}
