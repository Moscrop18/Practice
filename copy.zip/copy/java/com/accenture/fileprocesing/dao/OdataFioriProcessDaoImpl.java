package com.accenture.fileprocesing.dao;

import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.IntRange;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.accenture.constant.Hana_Profiler_Constant;
import com.accenture.constant.ST03HanaConstant;
import com.accenture.displaygrid.model.DBConfig;
import com.accenture.fiori.models.BadiMasterData;
import com.accenture.fiori.models.CustomFioriIssues;
import com.accenture.fiori.models.CustomFioriIssuesMaster;
import com.accenture.fiori.models.FioriAppsOutput;
import com.accenture.fiori.models.FioriFinalOutputList;
import com.accenture.fiori.models.InventoryCustomFiori;
import com.accenture.fiori.models.InventoryExtensionFiori;
import com.accenture.fiori.models.InventoryStandardFiori;
import com.accenture.fiori.models.OdataFioriApps;
import com.accenture.fiori.models.OdataFioriMasterData;
import com.accenture.fiori.models.PortableStandardAppsFiori;
import com.accenture.fiori.models.StandardTcodesFiori;
import com.accenture.master.FioriRequestMaster;
import com.accenture.master.ProcessedRequestDetail;
import com.accenture.utility.odatafiori.AppsType;
import org.hibernate.Criteria;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;



@Transactional

public class OdataFioriProcessDaoImpl implements OdataFioriProcessDao {
	
	protected final static Logger logger = LoggerFactory.getLogger(OdataFioriProcessDaoImpl.class);
	SessionFactory sessionFactory;
	
	static FioriFinalOutputList fioriFinalOutputList;
	
	

	public static FioriFinalOutputList getFioriFinalOutputList() {
		return fioriFinalOutputList;
	}

	public static void setFioriFinalOutputList(FioriFinalOutputList fioriFinalOutputList) {
		OdataFioriProcessDaoImpl.fioriFinalOutputList = fioriFinalOutputList;
	}


	
	private  String hql;
	static FioriRequestMaster fioriRequestMaster = new FioriRequestMaster();
	
	
	public static FioriRequestMaster getFioriRequestMaster() {
		return fioriRequestMaster;
	}

	public static void setFioriRequestMaster(FioriRequestMaster fioriRequestMaster) {
		OdataFioriProcessDaoImpl.fioriRequestMaster = fioriRequestMaster;
	}
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory=sessionFactory;
	}
	
	

	public String processFioriApps(final long requestID,List<OdataFioriApps>odataFioriAppsList , String targetVersion,HttpSession session) throws Exception {
		try {
			logger.info("Inside processFioriApps method ..");
			fioriFinalOutputList = new FioriFinalOutputList();
			List<OdataFioriMasterData> fioriMasterDataList = getFioriFromMasterData(session);
			List<CustomFioriIssuesMaster> customIssuesMasterList = getFioriCustomIssuesList(session);//comment this

			HashMap<String, HashMap<String, BadiMasterData>> badiMasterMap = getBadiMasterData(session);//comment
			buildFioriFinalOutput(requestID, odataFioriAppsList, badiMasterMap, fioriMasterDataList, targetVersion,customIssuesMasterList);//comment
			InventoryStndFioriAppCount();
			InvntryExtensionFioriCount();
			InventoryCustomFioriAppCount();
			StandardTcodesFioriAppCount();
			CustomOdataIssuesCount();
			inventoryStandardFioriInsert(fioriFinalOutputList.getInvtryStntdFioriList(), session);
			inventoryExtensionFioriInsert(fioriFinalOutputList.getInventoryExtnFioriList(), session);
			inventoryCustomFioriInsert(fioriFinalOutputList.getInventoryCustomFioriList(), session);
			standardTcodesFioriInsert(fioriFinalOutputList.getStandardTcodesFioriList(), session);
			portableStndAppsFioriInsert(fioriFinalOutputList.getStandardTcodesFioriList(), session);
			customOdataIssueInsert(fioriFinalOutputList.getCustomFioriIssuesList(), session);
		}catch(Exception e) {
			logger.error("Catching exception stack trace.............. .."+e.getMessage());
			throw new Exception("Exception in processing Fiori files");
			
		}
		return "success";
		
	}
	/**
	 * Method used to calculate the counts for Issues in Custom ODATA classes - Use case 4 for 
	 * Fiory Automation in the requirement Document
	 */
	private void CustomOdataIssuesCount() {		
		List<CustomFioriIssues> customFioriIssuesListForCount = fioriFinalOutputList.getCustomFioriIssuesList();
		if(customFioriIssuesListForCount != null && customFioriIssuesListForCount.size()>0) {
			//TODO Need to Remove all SYSOUT Statements after testing
			//TODO Need to find the best Approach to calculate all the below counts calculation
			
			//Count after Removing Duplicates
			Set<String> set = new HashSet<>(customFioriIssuesListForCount.size());
			int uniqueCount = customFioriIssuesListForCount.stream().filter(p -> set.add(p.getObjName())).collect(Collectors.toList()).size();
			logger.info("uniqueCount :" + uniqueCount);
			//Count of objects which contains the OPRCD has proper values and format
			List<String> oprList = new ArrayList<String>(customFioriIssuesListForCount.size());
			customFioriIssuesListForCount.stream().filter(p -> oprList.add(p.getOpercode())).collect(Collectors.toList());
			int oprCount = oprList.stream().filter(p -> p.length()== 6).filter(p -> p.startsWith("F")).filter(p -> isInRange(p.substring(1, 3))).collect(Collectors.toList()).size();
			logger.info("oprCount :" + oprCount);		
			//Count of Objects which contains the Object Type as Mandatory
			List<CustomFioriIssues> mandatet = new ArrayList<CustomFioriIssues>();
			int mandatCount = customFioriIssuesListForCount.stream().filter(p -> mandatet.add(p)).filter(p -> p.getObjType().equalsIgnoreCase("Mandatory")).collect(Collectors.toList()).size();		
			logger.info("MandateCount :" + mandatCount);      
			//Count of Objects which contains the Object Type as Not-Mandatory
			List<CustomFioriIssues> notMandate = new ArrayList<CustomFioriIssues>();
			int notMandateCount = customFioriIssuesListForCount.stream().filter(p -> notMandate.add(p)).filter(p -> p.getObjType().equalsIgnoreCase("Not-Mandatory")).collect(Collectors.toList()).size();
			logger.info("Not-MandateCount :" + notMandateCount);		
			//Count of Objects For impact as High and SubCategory as Security
			List<CustomFioriIssues> highSec = new ArrayList<CustomFioriIssues>();
			int highSecCount = customFioriIssuesListForCount.stream().filter(p -> highSec.add(p)).filter(p -> p.getImpact().equalsIgnoreCase("High")).filter(p -> p.getSubCategory().equalsIgnoreCase("Security")).collect(Collectors.toList()).size();
			logger.info("highSecCount :" + highSecCount);
			//Count of Objects For impact as High and SubCategory as Performance
			List<CustomFioriIssues> highPer = new ArrayList<CustomFioriIssues>();
			int highPerCount = customFioriIssuesListForCount.stream().filter(p -> highPer.add(p)).filter(p -> p.getImpact().equalsIgnoreCase("High")).filter(p -> p.getSubCategory().equalsIgnoreCase("Performance")).collect(Collectors.toList()).size();
			logger.info("highPerCount :" + highPerCount);
			//Count of Objects For impact as High and SubCategory as Development
			List<CustomFioriIssues> highDev = new ArrayList<CustomFioriIssues>();
			int highDevCount = customFioriIssuesListForCount.stream().filter(p -> highPer.add(p)).filter(p -> p.getImpact().equalsIgnoreCase("High")).filter(p -> p.getSubCategory().equalsIgnoreCase("Development")).collect(Collectors.toList()).size();
			logger.info("highDevCount :" + highDevCount);		
			//Count of Objects For impact as Medium and SubCategory as Security
			List<CustomFioriIssues> medSec = new ArrayList<CustomFioriIssues>();
			int medSecCount = customFioriIssuesListForCount.stream().filter(p -> medSec.add(p)).filter(p -> p.getImpact().equalsIgnoreCase("Medium")).filter(p -> p.getSubCategory().equalsIgnoreCase("Security")).collect(Collectors.toList()).size();
			logger.info("medSecCount :" + medSecCount);
			//Count of Objects For impact as Medium and SubCategory as Performance
			List<CustomFioriIssues> medPer = new ArrayList<CustomFioriIssues>();
			int medPerCount = customFioriIssuesListForCount.stream().filter(p -> medPer.add(p)).filter(p -> p.getImpact().equalsIgnoreCase("Medium")).filter(p -> p.getSubCategory().equalsIgnoreCase("Performance")).collect(Collectors.toList()).size();
			logger.info("medPerCount :" + medPerCount);
			//Count of Objects For impact as Medium and SubCategory as Development
			List<CustomFioriIssues> medDev = new ArrayList<CustomFioriIssues>();
			int medDevCount = customFioriIssuesListForCount.stream().filter(p -> medDev.add(p)).filter(p -> p.getImpact().equalsIgnoreCase("Medium")).filter(p -> p.getSubCategory().equalsIgnoreCase("Development")).collect(Collectors.toList()).size();
			logger.info("medDevCount :" + medDevCount);		
			//Count of Objects For impact as Low and SubCategory as Security
			List<CustomFioriIssues> lowSec = new ArrayList<CustomFioriIssues>();
			int lowSecCount = customFioriIssuesListForCount.stream().filter(p -> lowSec.add(p)).filter(p -> p.getImpact().equalsIgnoreCase("Low")).filter(p -> p.getSubCategory().equalsIgnoreCase("Security")).collect(Collectors.toList()).size();
			logger.info("lowSecCount :" + lowSecCount);
			//Count of Objects For impact as Low and SubCategory as Performance
			List<CustomFioriIssues> lowPer = new ArrayList<CustomFioriIssues>();
			int lowPerCount = customFioriIssuesListForCount.stream().filter(p -> lowPer.add(p)).filter(p -> p.getImpact().equalsIgnoreCase("Low")).filter(p -> p.getSubCategory().equalsIgnoreCase("Performance")).collect(Collectors.toList()).size();
			logger.info("lowPerCount :" + lowPerCount);
			//Count of Objects For impact as Low and SubCategory as Development
			List<CustomFioriIssues> lowDev = new ArrayList<CustomFioriIssues>();
			int lowDevCount = customFioriIssuesListForCount.stream().filter(p -> lowDev.add(p)).filter(p -> p.getImpact().equalsIgnoreCase("Low")).filter(p -> p.getSubCategory().equalsIgnoreCase("Development")).collect(Collectors.toList()).size();
			logger.info("lowDevCount :" + lowDevCount);

			
			// Setting all the count values in the fioriRequestMaster object to store in the Request Master
			
			//Not Required
			//fioriRequestMaster.setFioCustOdataClassIssue(0);
			//Unique after removing duplicates based on object name
			fioriRequestMaster.setFioCustomOdataClass(uniqueCount);
			//contains proper format and values for OPRCD
			fioriRequestMaster.setFioCustOdataClassIssue(oprCount);
			//Count for Object type as Mandatory
			fioriRequestMaster.setMandatory(mandatCount);
			//Count for Object type as Not-Mandatory count
			fioriRequestMaster.setNotMandatory(notMandateCount);
			//For impact as High
			fioriRequestMaster.setFioCustOdataHighSecIssue(highSecCount);
			fioriRequestMaster.setFioCustOdataHighPerfIssue(highPerCount);
			fioriRequestMaster.setFioCustOdataHighDevIssue(highDevCount);
			//For impact as Medium
			fioriRequestMaster.setFioCustOdataMediumSecIssue(medSecCount);
			fioriRequestMaster.setFioCustOdataMediumPerfIssue(medPerCount);
			fioriRequestMaster.setFioCustOdataMediumDevIssue(medDevCount);
			//For impact as Low
			fioriRequestMaster.setFioCustOdataLowSecIssue(lowSecCount);
			fioriRequestMaster.setFioCustOdataLowPerfIssue(lowPerCount);
			fioriRequestMaster.setFioCustOdataLowDevIssue(lowDevCount);
		}else {
			logger.info("Final Custom Fiori List is Empty.Can not calculate the Counts for use case 4");
		}
	}

	/**
	 * This Method used to get the Master Data for Use case 4 - Issues in Custom ODATA Classes.
	 * 
	 * @param session
	 * 			Current Session object to retrieve store values
	 * @return
	 * 		the list contains Master Data
	 * @throws SQLException
	 * 		the exception Object thrown if some issue happen while fetching the Records
	 */
	private List<CustomFioriIssuesMaster> getFioriCustomIssuesList(HttpSession session) throws SQLException {
		//TODO - Need to find the alternate Approach using Hibernate
		final String SELECT_SQL = "Select objCode, objType, subcategory, impact from fiori_class_masterdata";
		List<CustomFioriIssuesMaster> masterDataList= new ArrayList<CustomFioriIssuesMaster>();
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {
			conn = DBConfig.getJDBCConnection(session);
			conn.setAutoCommit(false);
				stmt = conn.prepareStatement(SELECT_SQL);
				ResultSet rs = stmt.executeQuery();
				while (rs.next()) {
					CustomFioriIssuesMaster fioriMasterData=new CustomFioriIssuesMaster();
					fioriMasterData.setCode(rs.getString("objCode"));
					fioriMasterData.setObjType(rs.getString("objType"));
					fioriMasterData.setSubCategory(rs.getString("subcategory"));
					fioriMasterData.setImpact(rs.getString("impact"));
					masterDataList.add(fioriMasterData);
				}
				logger.info("Fiori Class Master Sheet  Data selected SUCCESSFULLY");
		}  finally {
			if (stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		}
		return masterDataList;
	}
	
	protected void buildFioriFinalOutput(final long requestID,List<OdataFioriApps>odataFioriAppsList,HashMap<String, HashMap<String,BadiMasterData>>   badiMasterMap,List<OdataFioriMasterData> fioriMasterDataList,String targetVersion, List<CustomFioriIssuesMaster> customIssuesMasterList) {
		
		List<InventoryCustomFiori>  inventoryCustomFioriList=new ArrayList<InventoryCustomFiori>();
		List<InventoryCustomFiori>  customFioriUi5List=new ArrayList<InventoryCustomFiori>();	
		List<InventoryCustomFiori>  customFioriOdataList=new ArrayList<InventoryCustomFiori>();
		List<InventoryStandardFiori> invtryStntdFioriList  =new ArrayList<InventoryStandardFiori>();
		List<InventoryExtensionFiori> invtryExtnFioriList= new ArrayList<InventoryExtensionFiori>();
		List<StandardTcodesFiori> standardTcodesFioriList= new ArrayList<StandardTcodesFiori>();
		List<CustomFioriIssues> customFioriIssuesList = new ArrayList<CustomFioriIssues>();
		for ( OdataFioriApps odataFioriApps : odataFioriAppsList) {
			if(odataFioriApps.getObject().equalsIgnoreCase("IWSV")) {
				
				if(odataFioriApps.getReadProg()!=null && !odataFioriApps.getReadProg().equalsIgnoreCase("")) {
					//usecase1
					List<InventoryStandardFiori>  invtryStntdFiori=compareOdataServices(requestID,fioriMasterDataList, odataFioriApps, targetVersion);
					if(invtryStntdFiori!=null && !invtryStntdFiori.isEmpty()) {
						invtryStntdFioriList.addAll(invtryStntdFiori);
					}
					//usecase3
					InventoryCustomFiori customFioriOdata  =getCustomFioriInventoryOdata(requestID, odataFioriApps);
					if(customFioriOdata!=null) {
						customFioriOdataList.add(customFioriOdata);
					}
				}
				
			}
			if (odataFioriApps.getObject().equalsIgnoreCase("OUI5")) {
				// usecase1
				if (odataFioriApps.getObjName()!=null && !odataFioriApps.getObjName().equalsIgnoreCase("")) {
					List<InventoryStandardFiori> invntryStndUI5Services = compareUI5Services(requestID,
							fioriMasterDataList, odataFioriApps, targetVersion);
					if (invntryStndUI5Services != null  &&  !invntryStndUI5Services.isEmpty()) {
						invtryStntdFioriList.addAll(invntryStndUI5Services);
					}
					// usecase 3
					InventoryCustomFiori customFioriUi5 = getCustomFioriInventoryUi5(requestID, odataFioriApps);
					if (customFioriUi5 != null) {
						customFioriUi5List.add(customFioriUi5);
					}
					if(odataFioriApps.getOperationCode()!=null && odataFioriApps.getOperationCode().equalsIgnoreCase("FE")) {
						List<InventoryExtensionFiori> extnUI5Fiori   =extensionUI5Services(requestID, fioriMasterDataList, odataFioriApps, targetVersion);
					
						if (extnUI5Fiori != null && !extnUI5Fiori.isEmpty()) {
							invtryExtnFioriList.addAll(extnUI5Fiori);
						}
					}
					
				}
				
			}
			//usecase 2
			if (odataFioriApps.getObject().equalsIgnoreCase("SRVC") && odataFioriApps.getReadProg()!=null && !odataFioriApps.getReadProg().equalsIgnoreCase("")) {
				List<InventoryExtensionFiori> extnOdataFiori   =extensionOdataServices(requestID, fioriMasterDataList, odataFioriApps, targetVersion);
				if (extnOdataFiori != null  && !extnOdataFiori.isEmpty()) {
					invtryExtnFioriList.addAll(extnOdataFiori);
				}
			
			}
			
			if (odataFioriApps.getObject().equalsIgnoreCase("BADI")  &&  odataFioriApps.getReadProg()!=null && !odataFioriApps.getReadProg().equalsIgnoreCase("")) {
				List<InventoryExtensionFiori> extnBadiFiori   =compareFromBadiMasterData(requestID, badiMasterMap, odataFioriApps, targetVersion);
				if (extnBadiFiori != null  && !extnBadiFiori.isEmpty()) {
					invtryExtnFioriList.addAll(extnBadiFiori);
				}
			
			}
			
			if (odataFioriApps.getObject().equalsIgnoreCase("TCOD") && odataFioriApps.getComments()!=null && !odataFioriApps.getComments().equalsIgnoreCase("")) {
				String commentColumn =odataFioriApps.getComments();				
				
				String[] commentsSplit= commentColumn.split(",");
		    	Set<String> commentsSet = new HashSet(Arrays.asList(commentsSplit));
		    	for(String comments : commentsSet){
		    		odataFioriApps.setComments(comments.trim());
		    		List<StandardTcodesFiori> tcodesFiori   =compareTcodesCombined(requestID, fioriMasterDataList, odataFioriApps, targetVersion);
					if (tcodesFiori != null  && !tcodesFiori.isEmpty()) {
						standardTcodesFioriList.addAll(tcodesFiori);
					}
		    	}
			}
			//Use case 4: Issues in Custom OData Service
			if (odataFioriApps.getObject().equalsIgnoreCase("CLAS")) {
				if(odataFioriApps.getObjName()!=null && odataFioriApps.getObjName().endsWith("_DPC_EXT")) {
					CustomFioriIssues customFioriIssues = null;
					String oprcd = odataFioriApps.getOperationCode().trim();
					if(oprcd != null && oprcd.length()>= 3 && isInRange(oprcd.substring(1, 3))) {
						 String simplified = oprcd.substring(1, 3);						 
						 customFioriIssues = compareWithMasterForCustomIssues(requestID,simplified,oprcd,customIssuesMasterList,odataFioriApps);
					}else {
						customFioriIssues = new CustomFioriIssues();
						customFioriIssues.setRequestID(requestID);
						customFioriIssues.setObject(odataFioriApps.getObject());
						customFioriIssues.setObjName(odataFioriApps.getObjName());
						customFioriIssues.setOpercode(oprcd);
					}
					customFioriIssuesList.add(customFioriIssues);
				}
			}// end of use case 4
		}
				
		if(customFioriUi5List!=null && !customFioriUi5List.isEmpty()) {
			inventoryCustomFioriList.addAll(customFioriUi5List);
			
		}
		if(customFioriOdataList!=null && !customFioriOdataList.isEmpty()) {
			inventoryCustomFioriList.addAll(customFioriOdataList);
		}
		
		logger.info("Custom issues Size :" + customFioriIssuesList.size());
		
		fioriFinalOutputList.setInvtryStntdFioriList(invtryStntdFioriList);
		fioriFinalOutputList.setInventoryCustomFioriList(inventoryCustomFioriList);
		fioriFinalOutputList.setInventoryExtnFioriList(invtryExtnFioriList);
		fioriFinalOutputList.setStandardTcodesFioriList(standardTcodesFioriList);
		fioriFinalOutputList.setCustomFioriIssuesList(customFioriIssuesList);
		
	}
	
	/**
	 * Method used to find the given number is within the Range ( 59 to 76 )
	 * 
	 * @param simplified
	 * 			the number we need to check
	 * @return
	 * 		boolean value true or false
	 */
	private boolean isInRange(String simplified) {
		IntRange range = new IntRange(59,76);
		if(range.containsInteger(Integer.valueOf(simplified))) {
			return true;
		}
		return false;
	}

	/**
	 * Method used to compare the incoming list attribute with the Master data
	 * 
	 * @param requestID
	 * 			the Id for which request is processed
	 * @param simplified
	 * 			the two digit number after the first CHAR "F" from OPRCD
	 * @param oprcd
	 * 			the value from OPRCD Column
	 * @param customIssuesMasterList
	 * 			the list of Master data
	 * @param odataFioriApps
	 * 			the incoming object which needs to be verified
	 * @return
	 * 			the CustomFioriIssues object populated with values from Master data after finding the Match
	 */
	private CustomFioriIssues compareWithMasterForCustomIssues(long requestID, String simplified,
			String oprcd, List<CustomFioriIssuesMaster> customIssuesMasterList, OdataFioriApps odataFioriApps) {
		CustomFioriIssues customFioriIssues = null;
		if(customIssuesMasterList != null && customIssuesMasterList.size()>0) {
			for(CustomFioriIssuesMaster custom : customIssuesMasterList) {
				
				if(custom.getCode() != null && custom.getCode().equalsIgnoreCase(simplified)) {
					customFioriIssues = new CustomFioriIssues();
					customFioriIssues.setRequestID(requestID);
					customFioriIssues.setObject(odataFioriApps.getObject());
					customFioriIssues.setObjName(odataFioriApps.getObjName());
					customFioriIssues.setOpercode(oprcd);
					customFioriIssues.setCode(simplified);
					customFioriIssues.setObjType(custom.getObjType());
					customFioriIssues.setSubCategory(custom.getSubCategory());
					customFioriIssues.setImpact(custom.getImpact());
				}
			}
		}
		return customFioriIssues;
	}
	protected List<StandardTcodesFiori> compareTcodesCombined(final long requestID,List<OdataFioriMasterData> fioriMasterDataList, OdataFioriApps odataFioriApps,String targetVersion) {
		
		List<StandardTcodesFiori> stndTcodesFioriList=new ArrayList<StandardTcodesFiori> ();
		for( OdataFioriMasterData fioriMasterData : fioriMasterDataList) {
			String todesCombined=fioriMasterData.getTcodesCombined();
			String pcdCombined=fioriMasterData.getPcdCombined();
			String comments=odataFioriApps.getComments().toUpperCase();
			if(todesCombined!=null && !todesCombined.equalsIgnoreCase("")   ) {
				todesCombined=todesCombined.toUpperCase();
				if (todesCombined.contains(comments)) {
					
					String pvBackendCombined=fioriMasterData.getPvBackendCombined();
					StandardTcodesFiori stndTcodesFiori = new StandardTcodesFiori();
					stndTcodesFiori.setComments(comments);
					stndTcodesFiori.setRequestID(requestID);
					stndTcodesFiori.setAppId(fioriMasterData.getAppId());
					stndTcodesFiori.setTcodesCombined(todesCombined);
					stndTcodesFiori.setPcdCombined(pcdCombined);
					
					String appTypeCombined=fioriMasterData.getAppTypeCombined();
					appTypeCombined=appTypeCombined.replaceAll("\\$", StringUtils.EMPTY);
					appTypeCombined=appTypeCombined.replaceAll("\\*", ",");
					stndTcodesFiori.setAppTypeCombined(appTypeCombined);
					stndTcodesFiori.setObject(odataFioriApps.getObject());
					stndTcodesFiori.setObjName(odataFioriApps.getObjName());
					stndTcodesFiori.setFormFactors(fioriMasterData.getFormFactors());
					stndTcodesFiori.setAppName(fioriMasterData.getAppName());
					stndTcodesFiori.setPvBackendCombined(pvBackendCombined);
					String version = "";
					if (targetVersion.startsWith("ECC6.0EHP")) {
						version = targetVersion.substring(9);
						String compareVersion = "EHP ".concat(version);
						if (pcdCombined != null && !pcdCombined.equals("") && pcdCombined.contains(compareVersion)) {
							stndTcodesFiori.setAvailability("Y");
						} else if (pvBackendCombined != null && !pvBackendCombined.equals("") && pvBackendCombined.contains(compareVersion)) {
							stndTcodesFiori.setAvailability("Y");
						}else {
							stndTcodesFiori.setAvailability("N");
						}

					} else if (targetVersion.startsWith("S/4")) {
						version = targetVersion.substring(3);
						if (pcdCombined != null && !pcdCombined.equals("") && pcdCombined.contains(version)) {
							stndTcodesFiori.setAvailability("Y");
						} else if (pvBackendCombined != null && !pvBackendCombined.equals("") && pvBackendCombined.contains(version)) {
							stndTcodesFiori.setAvailability("Y");
						} else {
							stndTcodesFiori.setAvailability("N");
						}
					}

					stndTcodesFioriList.add(stndTcodesFiori);
				}
			}
			
		}
		return stndTcodesFioriList;
		
	}
	
	
	protected InventoryCustomFiori getCustomFioriInventoryUi5( final long requestID,OdataFioriApps odataFioriApps) {
		InventoryCustomFiori customFioriUi5=null;
		String objName=odataFioriApps.getObjName();
		objName=objName.toUpperCase();
		if (odataFioriApps.getAct_st()!=null && odataFioriApps.getAct_st().equals("")) {
			if (objName.startsWith("Z") || objName.startsWith("Y")) {
				String comments = odataFioriApps.getComments();
				customFioriUi5 = new InventoryCustomFiori();

				customFioriUi5.setRequestID(requestID);
				customFioriUi5.setObj_name(objName);
				customFioriUi5.setObject(odataFioriApps.getObject());
				if (!comments.equalsIgnoreCase("")) {
					
					customFioriUi5.setComments(comments);
				}
			}
		}
	return customFioriUi5;
	}
	
	protected InventoryCustomFiori getCustomFioriInventoryOdata(final long requestID,OdataFioriApps odataFioriApps) {
		InventoryCustomFiori customOdataCds=null;
			
				String readProg=odataFioriApps.getReadProg();	
				readProg=readProg.toUpperCase();
				if(readProg.startsWith("Z")  ||  readProg.startsWith("Y")) {					
					customOdataCds= new InventoryCustomFiori();
					customOdataCds.setRequestID(requestID);
					customOdataCds.setObj_name(odataFioriApps.getObjName());
					customOdataCds.setRead_prog(readProg);
					customOdataCds.setObject(odataFioriApps.getObject());
					if(readProg.contains("_CDS")) {
						
						customOdataCds.setCds(readProg);
					}
				}
			
	
		return customOdataCds;
		
	}
	protected List<InventoryStandardFiori> compareOdataServices(final long requestID,List<OdataFioriMasterData> fioriMasterDataList, OdataFioriApps odataFioriApps,String targetVersion) {
		logger.info("IWSV.........."+odataFioriApps.getReadProg());
		List<InventoryStandardFiori> invtryStndFioriList=new ArrayList<InventoryStandardFiori> ();
		for( OdataFioriMasterData fioriMasterData : fioriMasterDataList) {
			String odataServicesCombined=fioriMasterData.getOdataServicesCombined();//dont do this
			if(odataServicesCombined!=null && !odataServicesCombined.equalsIgnoreCase("")) {
				odataServicesCombined=odataServicesCombined.toUpperCase();
				String pcdCombined=fioriMasterData.getPcdCombined();
				String pvBackendCombined=fioriMasterData.getPvBackendCombined();
				if(odataServicesCombined.contains(odataFioriApps.getReadProg().toUpperCase())) {
				
				
				InventoryStandardFiori  invtryStndFiori=new InventoryStandardFiori();
				invtryStndFiori.setRequestID(requestID);
				invtryStndFiori.setAppId(fioriMasterData.getAppId());
				invtryStndFiori.setOdataServicesCombined(odataServicesCombined);
				invtryStndFiori.setBspName(fioriMasterData.getBspName());
				invtryStndFiori.setPcdCombined(pcdCombined);
				invtryStndFiori.setAppsTypeCombined(fioriMasterData.getAppTypeCombined());
				invtryStndFiori.setObject(odataFioriApps.getObject());
				invtryStndFiori.setObjName(odataFioriApps.getObjName());
				invtryStndFiori.setReadProg(odataFioriApps.getReadProg());
				invtryStndFiori.setSessioId(odataFioriApps.getSessionID());
				invtryStndFiori.setSubtype(odataFioriApps.getSubtype());
				invtryStndFiori.setAppName(fioriMasterData.getAppName());
				invtryStndFiori.setPvBackendCombined(pvBackendCombined);
				String version="";
				if(targetVersion.startsWith("ECC6.0EHP")) {
					 version=targetVersion.substring(9);
					 String compareVersion="EHP ".concat(version);
					 if(pcdCombined!=null && !pcdCombined.equals("") &&  pcdCombined.contains(compareVersion)  ) {
						 invtryStndFiori.setAvailability("Y");
					 }else if (pvBackendCombined != null && !pvBackendCombined.equals("") && pvBackendCombined.contains(compareVersion)) {
						 invtryStndFiori.setAvailability("Y");
					}else {
						 invtryStndFiori.setAvailability("N");
					 }
					 
				}else if(targetVersion.startsWith("S/4")) {
					version=targetVersion.substring(3);
					if(pcdCombined!=null && !pcdCombined.equals("") &&  pcdCombined.contains(version)  ) {
						 invtryStndFiori.setAvailability("Y");
					 }else if (pvBackendCombined != null && !pvBackendCombined.equals("") && pvBackendCombined.contains(version)) {
						 invtryStndFiori.setAvailability("Y");
						}else {
						 invtryStndFiori.setAvailability("N");
					 }
				}
				
				
				invtryStndFioriList.add(invtryStndFiori);
			}
		}
		}
		return invtryStndFioriList;
		
	}
	
protected List<InventoryExtensionFiori> extensionOdataServices(final long requestID,List<OdataFioriMasterData> fioriMasterDataList, OdataFioriApps odataFioriApps,String targetVersion) {
		
		List<InventoryExtensionFiori> invtryExtnFioriList=new ArrayList<InventoryExtensionFiori> ();
		for( OdataFioriMasterData fioriMasterData : fioriMasterDataList) {
			String odataServicesCombined=fioriMasterData.getOdataServicesCombined();
			if(odataServicesCombined!=null && !odataServicesCombined.equalsIgnoreCase("")) {
				odataServicesCombined=odataServicesCombined.toUpperCase();
			String pcdCombined=fioriMasterData.getPcdCombined();
			String pvBackendCombined=fioriMasterData.getPvBackendCombined();
			if( odataServicesCombined.contains(odataFioriApps.getReadProg().toUpperCase())) {
				
				InventoryExtensionFiori  invtryExtnFiori=new InventoryExtensionFiori();
				invtryExtnFiori.setRequestID(requestID);
				invtryExtnFiori.setAppId(fioriMasterData.getAppId());
				invtryExtnFiori.setOdataServicesCombined(odataServicesCombined);
				invtryExtnFiori.setBspName(fioriMasterData.getBspName());
				invtryExtnFiori.setPcdCombined(pcdCombined);
				invtryExtnFiori.setObject(odataFioriApps.getObject());
				invtryExtnFiori.setObjName(odataFioriApps.getObjName());
				invtryExtnFiori.setReadProg(odataFioriApps.getReadProg());
				invtryExtnFiori.setPvBackendCombined(pvBackendCombined);
				String version="";
				if(targetVersion.startsWith("ECC6.0EHP")) {
					 version=targetVersion.substring(9);
					 String compareVersion="EHP ".concat(version);
					 if(pcdCombined!=null && !pcdCombined.equals("") &&  pcdCombined.contains(compareVersion)  ) {
						 invtryExtnFiori.setAvailability("Y");
					 } else if (pvBackendCombined != null && !pvBackendCombined.equals("") && pvBackendCombined.contains(compareVersion)) {
						 invtryExtnFiori.setAvailability("Y");
						}else {
						 invtryExtnFiori.setAvailability("N");
					 }
					 
				}else if(targetVersion.startsWith("S/4")) {
					version=targetVersion.substring(3);
					if(pcdCombined!=null && !pcdCombined.equals("") &&  pcdCombined.contains(version)  ) {
						invtryExtnFiori.setAvailability("Y");
					 }else if (pvBackendCombined != null && !pvBackendCombined.equals("") && pvBackendCombined.contains(version)) {
						 invtryExtnFiori.setAvailability("Y");
						} else {
						 invtryExtnFiori.setAvailability("N");
					 }
				}
				
				
				invtryExtnFioriList.add(invtryExtnFiori);
			}
		}
		}
		return invtryExtnFioriList;
		
	}

protected List<InventoryExtensionFiori>  extensionUI5Services(final long requestID,List<OdataFioriMasterData> fioriMasterDataList, OdataFioriApps odataFioriApps,String targetVersion) {
	
	List<InventoryExtensionFiori> invtryExtnFioriList=new ArrayList<InventoryExtensionFiori> ();;
	for( OdataFioriMasterData fioriMasterData : fioriMasterDataList) {
		String bspName=fioriMasterData.getBspName();
		if(bspName!=null && !bspName.equalsIgnoreCase("") ) {
			bspName=bspName.toUpperCase();
			String pvBackendCombined=fioriMasterData.getPvBackendCombined();
		String pcdCombined=fioriMasterData.getPcdCombined();
		if(bspName.contains(odataFioriApps.getObjName().toUpperCase())) {
			
			InventoryExtensionFiori  invtryExtnFiori=new InventoryExtensionFiori();
			invtryExtnFiori.setRequestID(requestID);
			invtryExtnFiori.setAppId(fioriMasterData.getAppId());
			invtryExtnFiori.setOdataServicesCombined(fioriMasterData.getOdataServicesCombined());
			invtryExtnFiori.setBspName(fioriMasterData.getBspName());
			invtryExtnFiori.setPcdCombined(pcdCombined);			
			invtryExtnFiori.setObject(odataFioriApps.getObject());
			invtryExtnFiori.setObjName(odataFioriApps.getObjName());
			invtryExtnFiori.setReadProg(odataFioriApps.getReadProg());
			invtryExtnFiori.setPvBackendCombined(pvBackendCombined);
			String version="";
			if(targetVersion.startsWith("ECC6.0EHP")) {
				 version=targetVersion.substring(9);
				 String compareVersion="EHP ".concat(version);
				 if(pcdCombined!=null && !pcdCombined.equals("") &&  pcdCombined.contains(compareVersion)  ) {
					 invtryExtnFiori.setAvailability("Y");
				 } else if (pvBackendCombined != null && !pvBackendCombined.equals("") && pvBackendCombined.contains(compareVersion)) {
					 invtryExtnFiori.setAvailability("Y");
					}else {
					 invtryExtnFiori.setAvailability("N");
				 }
				 
			}else if(targetVersion.startsWith("S/4")) {
				version=targetVersion.substring(3);
				if(pcdCombined!=null && !pcdCombined.equals("") &&  pcdCombined.contains(version)  ) {
					invtryExtnFiori.setAvailability("Y");
				 }else if (pvBackendCombined != null && !pvBackendCombined.equals("") && pvBackendCombined.contains(version)) {
					 invtryExtnFiori.setAvailability("Y");
					} else {
					 invtryExtnFiori.setAvailability("N");
				 }
			}
			
			
			invtryExtnFioriList.add(invtryExtnFiori);
		}
	}
	}
	return invtryExtnFioriList;
	
}

protected List<InventoryExtensionFiori>  compareFromBadiMasterData(final long requestID,HashMap<String,HashMap<String,BadiMasterData>>   badiMasterMap, OdataFioriApps odataFioriApps,String targetVersion) {
	
	List<InventoryExtensionFiori> invtryExtnFioriList=null;	
	
	String readProg=odataFioriApps.getReadProg();
	readProg=readProg.toUpperCase();
	if(!badiMasterMap.isEmpty()  && badiMasterMap.containsKey(readProg)) {
		invtryExtnFioriList=new ArrayList<InventoryExtensionFiori> ();
		HashMap<String,BadiMasterData>  badiAppIdMap=badiMasterMap.get(readProg);
		for (Map.Entry<String, BadiMasterData> entry : badiAppIdMap.entrySet()) {
			BadiMasterData  badiMasterData=entry.getValue();
			String pcdCombined=badiMasterData.getPcdCombined();
			String pvBackendCombined=badiMasterData.getPvBackendCombined();
			InventoryExtensionFiori  invtryExtnFiori=new InventoryExtensionFiori();
			invtryExtnFiori.setRequestID(requestID);
			invtryExtnFiori.setAppId(badiMasterData.getAppId());
			invtryExtnFiori.setQueryName(badiMasterData.getQueryName());
			invtryExtnFiori.setPcdCombined(pcdCombined);			
			invtryExtnFiori.setObject(odataFioriApps.getObject());
			invtryExtnFiori.setObjName(odataFioriApps.getObjName());
			invtryExtnFiori.setReadProg(odataFioriApps.getReadProg());
			String version="";
			if(targetVersion.startsWith("ECC6.0EHP")) {
				 version=targetVersion.substring(9);
				 String compareVersion="EHP ".concat(version);
				 if(pcdCombined!=null && !pcdCombined.equals("") &&  pcdCombined.contains(compareVersion)  ) {
					 invtryExtnFiori.setAvailability("Y");
				 }else if (pvBackendCombined != null && !pvBackendCombined.equals("") && pvBackendCombined.contains(compareVersion)) {
					 invtryExtnFiori.setAvailability("Y");
					}else {
					 invtryExtnFiori.setAvailability("N");
				 }
				 
			}else if(targetVersion.startsWith("S/4")) {
				version=targetVersion.substring(3);
				if(pcdCombined!=null && !pcdCombined.equals("") &&  pcdCombined.contains(version)  ) {
					invtryExtnFiori.setAvailability("Y");
				 }else if (pvBackendCombined != null && !pvBackendCombined.equals("") && pvBackendCombined.contains(version)) {
					 invtryExtnFiori.setAvailability("Y");
					} else {
					 invtryExtnFiori.setAvailability("N");
				 }
			}
			
			
			invtryExtnFioriList.add(invtryExtnFiori);
		
		      logger.info("Key : " + entry.getKey() + " value : " + entry.getValue());
		    }
	}
	
	
	return invtryExtnFioriList;
	
}
protected List<InventoryStandardFiori> compareUI5Services(final long requestID,List<OdataFioriMasterData> fioriMasterDataList, OdataFioriApps odataFioriApps,String targetVersion) {
		
		List<InventoryStandardFiori> invtryStndFioriList=new ArrayList<InventoryStandardFiori> ();
		for( OdataFioriMasterData fioriMasterData : fioriMasterDataList) {
			String bspName=fioriMasterData.getBspName();
			if(bspName!=null && !bspName.equalsIgnoreCase("") ) {
				bspName=bspName.toUpperCase();
			String pcdCombined=fioriMasterData.getPcdCombined();
			String pvBackendCombined=fioriMasterData.getPvBackendCombined();
			if( bspName.contains(odataFioriApps.getObjName().toUpperCase())) {
				InventoryStandardFiori  invtryStndFiori=new InventoryStandardFiori();
				invtryStndFiori.setRequestID(requestID);
				invtryStndFiori.setAppId(fioriMasterData.getAppId());
				invtryStndFiori.setOdataServicesCombined(fioriMasterData.getOdataServicesCombined());
				invtryStndFiori.setBspName(fioriMasterData.getBspName());
				invtryStndFiori.setPcdCombined(pcdCombined);
				invtryStndFiori.setAppsTypeCombined(fioriMasterData.getAppTypeCombined());
				invtryStndFiori.setObject(odataFioriApps.getObject());
				invtryStndFiori.setAppName(fioriMasterData.getAppName());
				invtryStndFiori.setObjName(odataFioriApps.getObjName());
				invtryStndFiori.setReadProg(odataFioriApps.getReadProg());
				invtryStndFiori.setSessioId(odataFioriApps.getSessionID());
				invtryStndFiori.setSubtype(odataFioriApps.getSubtype());
				invtryStndFiori.setPvBackendCombined(pvBackendCombined);
				String version="";
				if(targetVersion.startsWith("ECC6.0EHP")) {
					 version=targetVersion.substring(9);
					 String compareVersion="EHP ".concat(version);
					 if(pcdCombined!=null && !pcdCombined.equals("") &&  pcdCombined.contains(compareVersion)  ) {
						 invtryStndFiori.setAvailability("Y");
					 }else if (pvBackendCombined != null && !pvBackendCombined.equals("") && pvBackendCombined.contains(compareVersion)) {
						 invtryStndFiori.setAvailability("Y");
						}else {
						 invtryStndFiori.setAvailability("N");
					 }
					 
				}else if(targetVersion.startsWith("S/4")) {
					version=targetVersion.substring(3);
					if(pcdCombined!=null && !pcdCombined.equals("") &&  pcdCombined.contains(version)  ) {
						 invtryStndFiori.setAvailability("Y");
					 }else if (pvBackendCombined != null && !pvBackendCombined.equals("") && pvBackendCombined.contains(version)) {
						 invtryStndFiori.setAvailability("Y");
						}else {
						 invtryStndFiori.setAvailability("N");
					 }
				}
				
				
				invtryStndFioriList.add(invtryStndFiori);
			}
		}
			
		}
		return invtryStndFioriList;
		
	}

	protected void InvntryExtensionFioriCount() {
		
		int fioExtnUILayer=0;
		int fioExtnServiceLayer=0;
		int fioExtnBackendLayer=0;
		int fioExtnStdFioriApps=0;
		
		int fioImpactExtnTargetSys=0;
		int fioImpactExtnUiTarget=0;
		int fioImpactExtnServiceTarget=0;
		int fioImpactExtnBackendTarget=0;

		int fioExtnTargetSys=0;
		int fioExtnUiTarget=0;
		int fioExtnServiceTarget=0;
		int fioExtnBackendTarget=0;

		Set<String> appIdFiori= new HashSet<String>();
		Set<String>appIdBadi=new HashSet<String>();
		Set<String>appIdSrvc=new HashSet<String>();
		Set<String>appIdOUI5=new HashSet<String>();

		List<InventoryExtensionFiori>   invtryExtnFioriList  =fioriFinalOutputList.getInventoryExtnFioriList();
		for(InventoryExtensionFiori  invtryExtnFiori:invtryExtnFioriList) {
			String appId=invtryExtnFiori.getAppId();
			if(invtryExtnFiori.getObject().equalsIgnoreCase("BADI")) {
				
				if(!appIdBadi.contains(appId)) {
					
					appIdBadi.add(appId);
					if(invtryExtnFiori.getAvailability().equalsIgnoreCase("Y")) {
						fioExtnBackendTarget++;
					}else {
						fioImpactExtnBackendTarget++;
					}
				}
				
				
				
				
			}else if(invtryExtnFiori.getObject().equalsIgnoreCase("SRVC")) {
				if(!appIdSrvc.contains(appId)) {
					appIdSrvc.add(invtryExtnFiori.getAppId());
										if(invtryExtnFiori.getAvailability().equalsIgnoreCase("Y")) {
						fioExtnServiceTarget++;
					}else {
						fioImpactExtnServiceTarget++;
					}
				}
				
			}else if(invtryExtnFiori.getObject().equalsIgnoreCase("OUI5")) {
				if(!appIdOUI5.contains(appId)) {
					appIdOUI5.add(invtryExtnFiori.getAppId());
					
					if(invtryExtnFiori.getAvailability().equalsIgnoreCase("Y")) {
						fioExtnUiTarget++;
					}else {
						fioImpactExtnUiTarget++;
					}
				}
				
			}
			if(invtryExtnFiori.getAvailability().equalsIgnoreCase("Y") && ! appIdFiori.contains(invtryExtnFiori.getAppId()) ) {
				fioExtnTargetSys++;
			}else if(invtryExtnFiori.getAvailability().equalsIgnoreCase("N") && ! appIdFiori.contains(invtryExtnFiori.getAppId()) ) {
				fioImpactExtnTargetSys++;
			}
			appIdFiori.add(invtryExtnFiori.getAppId());
			
		}
		fioExtnBackendLayer=appIdBadi.size();
		fioExtnServiceLayer=appIdSrvc.size();
		fioExtnUILayer=appIdOUI5.size();
		fioExtnStdFioriApps=appIdFiori.size();
		
		fioriRequestMaster.setFioExtnBackendLayer(fioExtnBackendLayer);
		fioriRequestMaster.setFioExtnServiceLayer(fioExtnServiceLayer);
		fioriRequestMaster.setFioExtnUILayer(fioExtnUILayer);
		fioriRequestMaster.setFioExtnStdFioriApps(fioExtnStdFioriApps);
		fioriRequestMaster.setFioImpactExtnTargetSys(fioImpactExtnTargetSys);
		fioriRequestMaster.setFioImpactExtnServiceTarget(fioImpactExtnServiceTarget);
		fioriRequestMaster.setFioImpactExtnBackendTarget(fioImpactExtnBackendTarget);
		fioriRequestMaster.setFioImpactExtnUiTarget(fioImpactExtnUiTarget);
		fioriRequestMaster.setFioExtnTargetSys(fioExtnTargetSys);
		fioriRequestMaster.setFioExtnUiTarget(fioExtnUiTarget);
		fioriRequestMaster.setFioExtnServiceTarget(fioExtnServiceTarget);
		fioriRequestMaster.setFioExtnBackendTarget(fioExtnBackendTarget);
		
		
	}


	protected void InventoryStndFioriAppCount(){
		int fioStdAppsEnabled=0;
		int fioStdAppsActive=0;
		int fioTrxnAppType=0;
		int fioAnalyticAppType=0;
		int fioFactsheetAppType=0;
		int fioWebdynAppType=0;
		int fioGuiAppType=0;
		int fioOtherAppType=0;
		int fioAppsNotAvlTargetVer=0;
		int fioAppsAvlTargetVer=0;

		Set<String> appIdFiori= new HashSet<String>();
		Set<String> appIdIWSV= new HashSet<String>();
		Set<String> appIdOUI5= new HashSet<String>();
		
		List<InventoryStandardFiori>   invtrystndFioriList  =fioriFinalOutputList.getInvtryStntdFioriList();
		for(InventoryStandardFiori  invtrystndFiori:invtrystndFioriList) {
			
			if(invtrystndFiori.getAvailability().equalsIgnoreCase("Y") && ! appIdFiori.contains(invtrystndFiori.getAppId()) ) {
				fioAppsAvlTargetVer++;
			}else if(invtrystndFiori.getAvailability().equalsIgnoreCase("N") && ! appIdFiori.contains(invtrystndFiori.getAppId()) ) {
				fioAppsNotAvlTargetVer++;
			}
			
			if(invtrystndFiori.getObject().equalsIgnoreCase("IWSV")) {
				appIdIWSV.add(invtrystndFiori.getAppId());
			}
			if(invtrystndFiori.getObject().equalsIgnoreCase("OUI5")) {
				appIdOUI5.add(invtrystndFiori.getAppId());
			}
			String appType=invtrystndFiori.getAppsTypeCombined();
			if (StringUtils.isNotBlank(appType) && ! appIdFiori.contains(invtrystndFiori.getAppId())) {
				appType=appType.replaceAll("\\$", StringUtils.EMPTY);
				appType = appType.replaceAll("\\s", StringUtils.EMPTY);
				appType=appType.replaceAll("\\*", ",");
				String[] appTypeSplit= appType.split(",");
		    	Set<String> appTypeSet = new HashSet(Arrays.asList(appTypeSplit));
		    	for(String app : appTypeSet){
		    			app=app.toUpperCase();
		    			if(app.equalsIgnoreCase("Transactional".toUpperCase())) {
		    				fioTrxnAppType++;
		    			}else if (app.contains("Analytical".toUpperCase())) {
		    				fioAnalyticAppType++;
		    			}else if(app.contains("GUI".toUpperCase())) {
		    				fioGuiAppType++;
		    			}else if(app.contains("Factsheet".toUpperCase())) {
		    				fioFactsheetAppType++;
		    			}else if (app.contains("WebDynpro".toUpperCase())) {
		    				fioWebdynAppType++;
		    			}else {
		    				fioOtherAppType++;
		    			}
		    		}

			}
			appIdFiori.add(invtrystndFiori.getAppId());
		}
		
		fioStdAppsEnabled=appIdFiori.size();
		appIdIWSV.retainAll(appIdOUI5);
		fioStdAppsActive=appIdIWSV.size();
		fioriRequestMaster.setFioStdAppsEnabled(fioStdAppsEnabled);
		fioriRequestMaster.setFioStdAppsActive(fioStdAppsActive);
		
		fioriRequestMaster.setFioAppsAvlTargetVer(fioAppsAvlTargetVer);
		fioriRequestMaster.setFioAppsNotAvlTargetVer(fioAppsNotAvlTargetVer);
		
		fioriRequestMaster.setFioAnalyticAppType(fioAnalyticAppType);
		fioriRequestMaster.setFioFactsheetAppType(fioFactsheetAppType);
		fioriRequestMaster.setFioGuiAppType(fioGuiAppType);
		fioriRequestMaster.setFioWebdynAppType(fioWebdynAppType);
		fioriRequestMaster.setFioTrxnAppType(fioTrxnAppType);
		fioriRequestMaster.setFioOtherAppType(fioOtherAppType);
	}
	
	protected void InventoryCustomFioriAppCount() {

		int fioCustomUi5Apps = 0;
		int fioCustUi5ConsumingService = 0;
		int fioCustOdataServices = 0;
		int fioCustServiceExposeCds = 0;		
		List<InventoryCustomFiori> inventoryCustomFioriList = fioriFinalOutputList.getInventoryCustomFioriList();
		for (InventoryCustomFiori invtryCustomFiori : inventoryCustomFioriList) {

			if (invtryCustomFiori.getObject().equalsIgnoreCase("OUI5")) {

				fioCustomUi5Apps++;
				if (invtryCustomFiori.getComments()!=null  && !invtryCustomFiori.getComments().equals("")) {
					fioCustUi5ConsumingService++;

				}
			} else if (invtryCustomFiori.getObject().equalsIgnoreCase("IWSV")) {
				fioCustOdataServices++;
				if (invtryCustomFiori.getRead_prog().contains("_CDS")) {
					fioCustServiceExposeCds++;

				}
			}
		}
		fioriRequestMaster.setFioCustomUi5Apps(fioCustomUi5Apps);
		fioriRequestMaster.setFioCustUi5ConsumingService(fioCustUi5ConsumingService);
		fioriRequestMaster.setFioCustOdataServices(fioCustOdataServices);
		fioriRequestMaster.setFioCustServiceExposeCds(fioCustServiceExposeCds);
	}
	
	protected void StandardTcodesFioriAppCount() {

		String fioTcodesStandardApp="";
		
		List<PortableStandardAppsFiori> portableStndFioriList=new ArrayList<>();
		HashMap<String,Integer> appIdCountMap=new HashMap<String,Integer>();
		HashSet<String>appIdSet=new HashSet<String>();
		Integer count=1;		
		List<StandardTcodesFiori> stdTcodesFioriList = fioriFinalOutputList.getStandardTcodesFioriList();
		for (StandardTcodesFiori stdTcodesFiori : stdTcodesFioriList) {
			//Calculating counts
			String appId=stdTcodesFiori.getAppId();
			if("Y".equalsIgnoreCase(stdTcodesFiori.getAvailability())) {
				
				if(appIdCountMap.containsKey(appId)) {
					 count=appIdCountMap.get(appId);
					 count=count+1;
					 appIdCountMap.put(appId, count);
				}else {
					appIdCountMap.put(appId, count);
				}
			}
		}
		
		
		 fioTcodesStandardApp= getDelimiedCountString(appIdCountMap);		
		
		fioriRequestMaster.setFioTcodesStandardApps(fioTcodesStandardApp);
		
	}
	
	
	protected String getDelimiedCountString(Map<String,Integer> appIdMap) {
		StringBuffer delimitedString = new StringBuffer();
		for (Map.Entry<String, Integer> entryAppId : appIdMap.entrySet()) {
			String appId = entryAppId.getKey();
			Integer count = entryAppId.getValue();

			delimitedString.append(appId).append(":").append(count).append("|");

		}
				
		return delimitedString.toString();

	}
	protected List<OdataFioriMasterData> getFioriFromMasterData(HttpSession session) throws SQLException {//App Id, App Name,PVBackendCombined,ODataServicesCombined,bspName we need only from master for now,
		final String SELECT_SQL = "Select AppId, BspName, ODataServicesCombined, AppTypeCombined, PCDCombined,TCodesCombined,FormFactors,AppName,PVBackendCombined from Fiori_MasterData";
		List<OdataFioriMasterData> masterDataList= new ArrayList<OdataFioriMasterData>();
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);

			conn.setAutoCommit(false);
			
				stmt = conn.prepareStatement(SELECT_SQL);

				ResultSet rs = stmt.executeQuery();
				while (rs.next()) {
					
					OdataFioriMasterData fioriMasterData=new OdataFioriMasterData();
					fioriMasterData.setAppId(rs.getString("AppId"));
					fioriMasterData.setBspName(rs.getString("BspName"));
					fioriMasterData.setOdataServicesCombined(rs.getString("ODataServicesCombined"));					
					fioriMasterData.setAppTypeCombined(rs.getString("AppTypeCombined"));
					fioriMasterData.setPcdCombined(rs.getString("PCDCombined"));
					fioriMasterData.setTcodesCombined(rs.getString("TCodesCombined"));
					fioriMasterData.setFormFactors(rs.getString("FormFactors"));
					fioriMasterData.setAppName(rs.getString("AppName"));
					fioriMasterData.setPvBackendCombined(rs.getString("PVBackendCombined"));
					
					masterDataList.add(fioriMasterData);
				}
					
				logger.info("Fiori Master Sheet  Data selected SUCCESSFULLY");

			
		}  finally {
			if (stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				conn.close();
			}

		}
		return masterDataList;

	}
	
	protected HashMap<String, HashMap<String,BadiMasterData>>  getBadiMasterData(HttpSession session) throws SQLException {
		HashMap<String, HashMap<String,BadiMasterData>>   badiMasterMap   =new HashMap<String, HashMap<String,BadiMasterData>>();
		final String SELECT_SQL = "Select AppId, name, PCDCombined ,PVBackendCombined from Badi_MasterData";
		Set<String>appIdSet=new HashSet<String>();
		List<BadiMasterData> masterDataList= new ArrayList<BadiMasterData>();
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);

			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(SELECT_SQL);

				ResultSet rs = stmt.executeQuery();
								
				while (rs.next()) {
					String name = rs.getString("name");
					String appId=rs.getString("AppId");
					if (name != null) {
						name=name.toUpperCase();
						if (badiMasterMap.containsKey(name)) {
							HashMap<String, BadiMasterData> badiSubMap = badiMasterMap.get(name);
							if (!badiSubMap.containsKey(appId)) {
								BadiMasterData badiMasterData = new BadiMasterData();
								badiMasterData.setAppId(appId);
								badiMasterData.setQueryName(name);
								badiMasterData.setPcdCombined(rs.getString("PCDCombined"));
								badiMasterData.setPvBackendCombined("PVBackendCombined");
								badiSubMap.put(appId, badiMasterData);
							}
						} else {

							HashMap<String, BadiMasterData> badiSubMap = new HashMap<String, BadiMasterData>();
							BadiMasterData badiMasterData = new BadiMasterData();
							badiMasterData.setAppId(appId);
							badiMasterData.setQueryName(name);
							badiMasterData.setPcdCombined(rs.getString("PCDCombined"));
							badiMasterData.setPvBackendCombined("PVBackendCombined");
							badiSubMap.put(appId, badiMasterData);
							badiMasterMap.put(name, badiSubMap);
						}
					}
				}		
					
				logger.info("Badi Master Sheet  Data selected SUCCESSFULLY");

			} catch (Exception e) {
				
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			
			logger.error(e.getMessage());

		} finally {
			if (stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				conn.close();
			}

		}
		return badiMasterMap;

	}
public static void inventoryCustomFioriInsert(List<InventoryCustomFiori> customFioriList,HttpSession session ) throws SQLException {
		
		final String INSERT_SQL = "INSERT INTO Inventory_Custom_Fiori " 
		           + "(Object, Obj_name, Comments, read_prog, cds, request_id) values (?, ?, ?, ?, ?, ?)";
  
		  String result = "SUCCESS";
	      java.sql.Connection conn= null;
	      java.sql.PreparedStatement stmt= null;
	      try {
	    	  
	    	      conn =DBConfig.getJDBCConnection(session);
		    	  int counter=1;
		          conn.setAutoCommit(false);
		          try {
		        	  stmt = conn.prepareStatement(INSERT_SQL);
		        	  int batch = 1;
		        	         	
		        		  for (InventoryCustomFiori customFiori :  customFioriList) {
		        		  stmt.setString(1, customFiori.getObject());
		        		  stmt.setString(2, customFiori.getObj_name());
		        		  stmt.setString(3, customFiori.getComments());
		        		  stmt.setString(4, customFiori.getRead_prog());
		        		  stmt.setString(5, customFiori.getCds());
		        		  stmt.setLong(6, customFiori.getRequestID());	        		  
		        		  
		                 //Add statement to batch
		                  stmt.addBatch();
		                  counter++;
		                  //Execute batch of 10000 records
		                  if(counter%10000==0){
		                	 counter=0;
		                     stmt.executeBatch();
		                     conn.commit();
		                     logger.info("Batch "+(batch++)+" executed successfully");
		                  }
		               }	        	  
		        	  
		        		  stmt.executeBatch();
		                  conn.commit();
		                 logger.info("Custom Fiori Inventory Data INSERTED SUCCESSFULLY");
		        	  
		          }catch(Exception e) {
		        	  result = "FAILURE in insert";
		        	  logger.error(e.getMessage());
		        	  }
		          }	catch(Exception e) {
		        	  result = "FAILURE in Getting Connection";
		        	  logger.error(e.getMessage());
				
			}		finally {
				if (stmt != null) {
					stmt.close();
				}
				if (conn != null) {
					conn.close();
				}

			}
		
		
		
	}	

public static String inventoryStandardFioriInsert(List<InventoryStandardFiori>   invtrystndFioriList,HttpSession session ) throws SQLException {
	
	final String INSERT_SQL = "INSERT INTO Inventory_Standard_Fiori " 
	           + "(Object,Obj_Name,Read_Prog,AppId,BspName,OdataServicesCombined,AppsTypeCombined,PCDCombined,Availability,REQUEST_ID,PVBackendCombined, SESSION_ID, SUBTYPE, App_Name) values (?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?,?,?)";

	  String result = "SUCCESS";
      java.sql.Connection conn= null;
      java.sql.PreparedStatement stmt= null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);

			stmt = conn.prepareStatement(INSERT_SQL);
			int batch = 1;

			for (InventoryStandardFiori stndFiori : invtrystndFioriList) {
				stmt.setString(1, stndFiori.getObject());
				stmt.setString(2, stndFiori.getObjName());
				stmt.setString(3, stndFiori.getReadProg());
				stmt.setString(4, stndFiori.getAppId());
				stmt.setString(5, stndFiori.getBspName());
				stmt.setString(6, stndFiori.getOdataServicesCombined());
				stmt.setString(7, stndFiori.getAppsTypeCombined());
				stmt.setString(8, stndFiori.getPcdCombined());
				stmt.setString(9, stndFiori.getAvailability());
				stmt.setLong(10, stndFiori.getRequestID());
				stmt.setString(11, stndFiori.getPvBackendCombined());
				stmt.setString(12, stndFiori.getSessioId());
				stmt.setString(13, stndFiori.getSubtype());
				stmt.setString(14, stndFiori.getAppName());

				// Add statement to batch
				stmt.addBatch();
				counter++;
				// Execute batch of 10000 records
				if (counter % 10000 == 0) {
					counter = 0;
					stmt.executeBatch();
					conn.commit();
					logger.info("Batch " + (batch++) + " executed successfully");
				}
			}

			stmt.executeBatch();
			conn.commit();
			logger.info("Standard Fiori Inventory Data INSERTED SUCCESSFULLY");

		} finally {
			if (stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				conn.close();
			}

		}
	
	
	return result;
	
}	

public static void inventoryExtensionFioriInsert(List<InventoryExtensionFiori>   invtryExtnFioriList,HttpSession session ) throws SQLException {
	
	final String INSERT_SQL = "INSERT INTO Inventory_Extension_Fiori " 
	           + "(Object,Obj_Name,Read_Prog,AppId,BspName,OdataServicesCombined,PCDCombined,Availability,QueryName,REQUEST_ID,PVBackendCombined) values (?,?,?, ?, ?, ?, ?, ?,?,?,?)";

	 
      java.sql.Connection conn= null;
      java.sql.PreparedStatement stmt= null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);

			stmt = conn.prepareStatement(INSERT_SQL);
			int batch = 1;

			for (InventoryExtensionFiori extnFiori : invtryExtnFioriList) {
				stmt.setString(1, extnFiori.getObject());
				stmt.setString(2, extnFiori.getObjName());
				stmt.setString(3, extnFiori.getReadProg());
				stmt.setString(4, extnFiori.getAppId());
				stmt.setString(5, extnFiori.getBspName());
				stmt.setString(6, extnFiori.getOdataServicesCombined());				
				stmt.setString(7, extnFiori.getPcdCombined());
				stmt.setString(8, extnFiori.getAvailability());
				stmt.setString(9, extnFiori.getQueryName());
				stmt.setLong(10, extnFiori.getRequestID());
				stmt.setString(11, extnFiori.getPvBackendCombined());

				// Add statement to batch
				stmt.addBatch();
				counter++;
				// Execute batch of 10000 records
				if (counter % 10000 == 0) {
					counter = 0;
					stmt.executeBatch();
					conn.commit();
					logger.info("Batch " + (batch++) + " executed successfully");
				}
			}

			stmt.executeBatch();
			conn.commit();
			logger.info("Extension Fiori Inventory Data INSERTED SUCCESSFULLY");

		}		finally {			
			stmt.close();
			conn.close();
	}
	
	
	
	
}	

public static void standardTcodesFioriInsert(List<StandardTcodesFiori>   stndTcodesFioriList,HttpSession session ) throws SQLException {
	
	final String INSERT_SQL = "INSERT INTO Standard_Tcodes_Fiori " 
	           + "(Object,Obj_Name,AppId,AppName,AppTypeCombined,PCDCombined,TCodesCombined,Availability,Comments,FormFactors,REQUEST_ID,PVBackendCombined) values (?, ?, ?, ?, ?, ?,?,?,?,?,?,?)";

	 
      java.sql.Connection conn= null;
      java.sql.PreparedStatement stmt= null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);

			stmt = conn.prepareStatement(INSERT_SQL);
			int batch = 1;

			for (StandardTcodesFiori tcodesFiori : stndTcodesFioriList) {
				stmt.setString(1, tcodesFiori.getObject());
				stmt.setString(2, tcodesFiori.getObjName());
				
				stmt.setString(3, tcodesFiori.getAppId());
				stmt.setString(4, tcodesFiori.getAppName());
				stmt.setString(5, tcodesFiori.getAppTypeCombined());
				
				stmt.setString(6, tcodesFiori.getPcdCombined());
				stmt.setString(7, tcodesFiori.getTcodesCombined());
				stmt.setString(8, tcodesFiori.getAvailability());
				
				stmt.setString(9, tcodesFiori.getComments());
				stmt.setString(10, tcodesFiori.getFormFactors());
				stmt.setLong(11, tcodesFiori.getRequestID());
				stmt.setString(12, tcodesFiori.getPvBackendCombined());
				// Add statement to batch
				stmt.addBatch();
				counter++;
				// Execute batch of 10000 records
				if (counter % 10000 == 0) {
					counter = 0;
					stmt.executeBatch();
					conn.commit();
					logger.info("Batch " + (batch++) + " executed successfully");
				}
			}

			stmt.executeBatch();
			conn.commit();
			logger.info("Standard Tcodes Data INSERTED SUCCESSFULLY");

		}		finally {
			if (stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				conn.close();
			}

		}
	
	
	
	
}	


public static void portableStndAppsFioriInsert(List<StandardTcodesFiori>   stndTcodesFioriList,HttpSession session ) throws SQLException {
	
	final String INSERT_SQL = "INSERT INTO Portable_Apps_Fiori " 
	           + "(AppId,AppName,AppTypeCombined,FormFactors,REQUEST_ID) values (?, ?, ?, ?, ?)";

	 HashSet<String> appIdSet=new HashSet<String>();
      java.sql.Connection conn= null;
      java.sql.PreparedStatement stmt= null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);

			stmt = conn.prepareStatement(INSERT_SQL);
			int batch = 1;
		
			for (StandardTcodesFiori tcodesFiori : stndTcodesFioriList) {
				
				
				if(!appIdSet.contains(tcodesFiori.getAppId())) {
					appIdSet.add(tcodesFiori.getAppId());		
				
				stmt.setString(1, tcodesFiori.getAppId());
				stmt.setString(2, tcodesFiori.getAppName());
				stmt.setString(3, tcodesFiori.getAppTypeCombined());				
				stmt.setString(4, tcodesFiori.getFormFactors());
				stmt.setLong(5, tcodesFiori.getRequestID());
				
				// Add statement to batch
				stmt.addBatch();
				counter++;
				// Execute batch of 10000 records
				if (counter % 10000 == 0) {
					counter = 0;
					stmt.executeBatch();
					conn.commit();
					logger.info("Batch " + (batch++) + " executed successfully");
				}
			}
		}
			stmt.executeBatch();
			conn.commit();
			logger.info("Portable Standard Apps Data INSERTED SUCCESSFULLY");

		}		finally {			
			stmt.close();
			conn.close();
	}
	
}	

public static void customOdataIssueInsert(List<CustomFioriIssues>   customFioriIssueLst,HttpSession session ) throws SQLException {
	
	final String INSERT_SQL = "INSERT INTO Custom_Fiori_Issues " 
	           + "(Object,Obj_name,Oprcd,simplified,Type,SubCategory,Impact,REQUEST_ID) values (?, ?, ?, ?, ?, ?, ?, ?)";

      java.sql.Connection conn= null;
      java.sql.PreparedStatement stmt= null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);

			stmt = conn.prepareStatement(INSERT_SQL);
			int batch = 1;
		
			for (CustomFioriIssues customFiori : customFioriIssueLst) {
				
				
				
				
				stmt.setString(1, customFiori.getObject());
				stmt.setString(2, customFiori.getObjName());
				stmt.setString(3, customFiori.getOpercode());				
				stmt.setString(4, customFiori.getCode());
				stmt.setString(5, customFiori.getObjType());
				stmt.setString(6, customFiori.getSubCategory());
				stmt.setString(7, customFiori.getImpact());
				stmt.setLong(8, customFiori.getRequestID());
				
				// Add statement to batch
				stmt.addBatch();
				counter++;
				// Execute batch of 10000 records
				if (counter % 10000 == 0) {
					counter = 0;
					stmt.executeBatch();
					conn.commit();
					logger.info("Batch " + (batch++) + " executed successfully");
				}
			
		}
			stmt.executeBatch();
			conn.commit();
			logger.info("Custom Fiori Issue Data INSERTED SUCCESSFULLY");

		}		finally {			
			stmt.close();
			conn.close();
	}
	
}	

@Override
public void updateRequestMasterFiori(long requestId) {
	
	
	logger.info("Inside updateRequestMasterFiori  !!!!!!!!!!!!!!!!! ");
	Session session = sessionFactory.getCurrentSession();
	if (null == session) {
		session = sessionFactory.openSession();
	}
	fioriRequestMaster.setRequestID(requestId);
	fioriRequestMaster.setScope("Fiori");
	FioriRequestMaster fioriRm=new FioriRequestMaster();
	fioriRm.setRequestID(requestId);
	fioriRm.setScope("Fiori");
	fioriRm.setFioStdAppsEnabled(fioriRequestMaster.getFioStdAppsEnabled());
	fioriRm.setFioStdAppsActive(fioriRequestMaster.getFioStdAppsActive());
	fioriRm.setFioTrxnAppType(fioriRequestMaster.getFioTrxnAppType());
	fioriRm.setFioAnalyticAppType(fioriRequestMaster.getFioAnalyticAppType());
	fioriRm.setFioFactsheetAppType(fioriRequestMaster.getFioFactsheetAppType());
	fioriRm.setFioWebdynAppType(fioriRequestMaster.getFioWebdynAppType());
	fioriRm.setFioGuiAppType(fioriRequestMaster.getFioGuiAppType());
	fioriRm.setFioOtherAppType(fioriRequestMaster.getFioOtherAppType());
	fioriRm.setFioExtnUILayer(fioriRequestMaster.getFioExtnUILayer());
	fioriRm.setFioExtnServiceLayer(fioriRequestMaster.getFioExtnServiceLayer());
	fioriRm.setFioExtnBackendLayer(fioriRequestMaster.getFioExtnBackendLayer());
	fioriRm.setFioExtnStdFioriApps(fioriRequestMaster.getFioExtnStdFioriApps());
	fioriRm.setFioExtnTargetSys(fioriRequestMaster.getFioExtnTargetSys());
	fioriRm.setFioExtnUiTarget(fioriRequestMaster.getFioExtnUiTarget());
	fioriRm.setFioExtnServiceTarget(fioriRequestMaster.getFioExtnServiceTarget());
	fioriRm.setFioExtnBackendTarget(fioriRequestMaster.getFioExtnBackendTarget());
	fioriRm.setFioTcodesStandardApps(fioriRequestMaster.getFioTcodesStandardApps());
	fioriRm.setFioCustomUi5Apps(fioriRequestMaster.getFioCustomUi5Apps());
	fioriRm.setFioCustUi5ConsumingService(fioriRequestMaster.getFioCustUi5ConsumingService());
	fioriRm.setFioCustOdataServices(fioriRequestMaster.getFioCustOdataServices());
	fioriRm.setFioCustServiceExposeCds(fioriRequestMaster.getFioCustServiceExposeCds());
	fioriRm.setFioCustomClass(fioriRequestMaster.getFioCustomClass());
	fioriRm.setFioCustomOdataClass(fioriRequestMaster.getFioCustomOdataClass());
	fioriRm.setFioCustOdataClassIssue(fioriRequestMaster.getFioCustOdataClassIssue());
	fioriRm.setFioCustOdataHighSecIssue(fioriRequestMaster.getFioCustOdataHighSecIssue());
	fioriRm.setFioCustOdataHighPerfIssue(fioriRequestMaster.getFioCustOdataHighPerfIssue());
	fioriRm.setFioCustOdataHighDevIssue(fioriRequestMaster.getFioCustOdataHighDevIssue());
	fioriRm.setFioCustOdataMediumSecIssue(fioriRequestMaster.getFioCustOdataMediumSecIssue());
	fioriRm.setFioCustOdataMediumPerfIssue(fioriRequestMaster.getFioCustOdataMediumPerfIssue());
	fioriRm.setFioCustOdataMediumDevIssue(fioriRequestMaster.getFioCustOdataMediumDevIssue());
	fioriRm.setFioCustOdataLowSecIssue(fioriRequestMaster.getFioCustOdataLowSecIssue());
	fioriRm.setFioCustOdataLowPerfIssue(fioriRequestMaster.getFioCustOdataLowPerfIssue());
	fioriRm.setFioCustOdataLowDevIssue(fioriRequestMaster.getFioCustOdataLowDevIssue());
	fioriRm.setFioAppsNotAvlTargetVer(fioriRequestMaster.getFioAppsNotAvlTargetVer());
	fioriRm.setFioAppsAvlTargetVer(fioriRequestMaster.getFioAppsAvlTargetVer());
	fioriRm.setFioImpactExtnTargetSys(fioriRequestMaster.getFioImpactExtnTargetSys());
	fioriRm.setFioImpactExtnUiTarget(fioriRequestMaster.getFioImpactExtnUiTarget());
	fioriRm.setFioImpactExtnServiceTarget(fioriRequestMaster.getFioImpactExtnServiceTarget());
	fioriRm.setFioImpactExtnBackendTarget(fioriRequestMaster.getFioImpactExtnBackendTarget());
	fioriRm.setMandatory(fioriRequestMaster.getMandatory());
	fioriRm.setNotMandatory(fioriRequestMaster.getNotMandatory());
	
	
	try{	
		session.saveOrUpdate(fioriRm);
		
	}
	catch (Exception e) {
		 e.getMessage();
		throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
	}
	logger.info("processing completed for updateRequestMasterFiori  !!!!!!!!!!!!!!!!! ");
}

public List<AppsType> getFioriDataFromDB(HttpSession session, String target) {
	logger.info("Inside getFioriDataFromDB");
	List<AppsType> appsTypeList = new ArrayList<AppsType>();
	String sql = "SELECT TCODESCOMBINED, APPID, APPNAME, APPLICATIONTYPE, APPLICATIONCOMPONENT,  APPLICATIONCOMPONENTTEXT FROM FIORI_MASTERDATA";
	
	if(target!=null && !target.isEmpty()) {
		sql = sql+" WHERE PVFrontendCombined LIKE ?";
	}
	
	try {
	  Connection conn =DBConfig.getJDBCConnection(session);
	  PreparedStatement stmt = conn.prepareStatement(sql);
	  
	  if(target!=null && !target.isEmpty()) {
		
		  stmt.setString(1, "%" + target + "%");
	  }
	  ResultSet rs=stmt.executeQuery();
	  
	  while(rs.next()) {
		  String tCode = rs.getString(1).trim();
		  String appId = rs.getString(2).trim();
		  String appName = rs.getString(3).trim();
		  String appType = rs.getString(4).trim();
		  String applicationComponent = rs.getString(5);
		  String applicationComponentText = rs.getString(6);
		 
		  AppsType appsType = new AppsType();
		  appsType.setTcodesCombined(tCode);
		  appsType.setAppId(appId);
		  appsType.setAppName(appName);
		  appsType.setApplicationType(appType);
		  appsType.setApplicationComponent(applicationComponent==null?"":applicationComponent.trim());
		  appsType.setApplicationComponentText(applicationComponentText==null?"":applicationComponentText.trim());
		  
		  appsTypeList.add(appsType); 
	  }
	}catch(SQLException se) {
		logger.error("Exception occured:"+se);
	}
	return appsTypeList;
}

@Override
public String insertFioriAppsData(List<AppsType> appsTypeList, HttpSession session,
		Long requestId) throws SQLException {
	final String INSERT_SQL = "INSERT INTO FIORI_APPS_OUTPUT "
			+ "(REQUEST_ID, TCODE, APP_ID, APP_NAME, APP_TYPE, SCORE, COMMENTS, APPLICATION_COMPONENT, APPLICATION_COMPONENT_TEXT) values (?, ?, ?, ?, ?, ?, ?, ?,?)";

	String result = "SUCCESS";
	java.sql.Connection conn = null;
	java.sql.PreparedStatement stmt = null;
	try {

		conn = DBConfig.getJDBCConnection(session);
		int counter = 1;
		conn.setAutoCommit(false);
		try {
			stmt = conn.prepareStatement(INSERT_SQL);
			int batch = 1;

			for (AppsType appsType : appsTypeList) {

				
				stmt.setLong(1, requestId);
				stmt.setString(2, appsType.getTcodesCombined());
				stmt.setString(3, appsType.getAppId());
				stmt.setString(4, appsType.getAppName());
				stmt.setString(5, appsType.getApplicationType());
				
				if(appsType.getScore()!=null) {
					stmt.setLong(6, appsType.getScore());
				}else {
					stmt.setNull(6, Types.BIGINT);
				}
				stmt.setString(7, appsType.getComments()==null?"":appsType.getComments());
				stmt.setString(8, appsType.getApplicationComponent());
				stmt.setString(9, appsType.getApplicationComponentText());

				// Add statement to batch
				stmt.addBatch();
				counter++;
				// Execute batch of 1000 records
				if (counter % 1000 == 0) {
					counter = 0;
					stmt.executeBatch();
					conn.commit();
					logger.info("Batch " + (batch++) + " executed successfully");
				}
			}

			stmt.executeBatch();
			conn.commit();
			logger.info("Fiori output Data INSERTED SUCCESSFULLY");

		} catch (Exception e) {
			result = "FAILURE in insert";
			logger.error(e.getMessage());
		}
	} catch (Exception e) {
		result = "FAILURE in Getting Connection";
		logger.error(e.getMessage());

	} finally {
		stmt.close();
		conn.close();
	}

	return result;
	
}

	public List<FioriAppsOutput> getFioriOutputData(long requestId) {
		final Session session=sessionFactory.openSession();
		try{
			final Criteria criteria=session.createCriteria(FioriAppsOutput.class);
			criteria.add(Restrictions.eq("requestId", requestId));
			return criteria.list();
		} catch(Exception e) {
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if(session!=null){
				session.close();
			}
		}
	}

	public List<AppsType> getFioriMasterData() {
		final Session session=sessionFactory.openSession();
		
		try{
			final Criteria criteria=session.createCriteria(AppsType.class);
			final ProjectionList projection = Projections.projectionList();
			projection.add(Projections.property("tcodesCombined"));
			projection.add(Projections.property("appName"));
			projection.add(Projections.property("appId"));
			projection.add(Projections.property("applicationType"));
			
			criteria.add(Restrictions.and(
					Restrictions.in("applicationType", ST03HanaConstant.APP_LIST),
					Restrictions.ne("tcodesCombined", ST03HanaConstant.EMPTY_TCODE)));
			criteria.setProjection(projection);
			
			List<Object[]> response = criteria.list();
			
			List<AppsType> appsTypeList = new ArrayList<AppsType>();
			Iterator<Object[]> it = response.iterator();
			
			while(it.hasNext()) {
				Object[] column =  it.next();
				AppsType appsType = new AppsType();
				appsType.setTcodesCombined(column[0].toString());
				appsType.setAppName(column[1].toString());
				appsType.setAppId(column[2].toString());
				appsType.setApplicationType(column[3].toString());
				
				appsTypeList.add(appsType);
			}
			return appsTypeList;
		} catch(Exception e) {
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if(session!=null){
				session.close();
			}
		}
	}


}	
