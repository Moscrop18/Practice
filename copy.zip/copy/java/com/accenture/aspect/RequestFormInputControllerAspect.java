/* MODIFIED 
 *FOR Enhancement CR-3.0:- Remove unused fields(like Customer_namespaces,
				SPECIFIC_NAMING_CONEVNTIONS,NAMESPACE_DETAILS_FILE,NAMESPACE_DETAILS_FILE_NAME,NAMING_CONEVNTIONS_FILE,
				NAMING_CONVENTIONS_FILE_NAME) from create request form. -23/12/16 -monika.mishra */
package com.accenture.aspect;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.accenture.client.dao.RequestFormDAO;
import com.accenture.client.model.RequestForm;
import com.accenture.constant.Hana_Profiler_Constant;
import com.accenture.exceptions.RequestNotValidException;
import com.accenture.exceptions.ResetPasswordException;
import com.accenture.poc.dao.POCRequestMappingDAO;
import com.accenture.poc.dao.UserDAO;
import com.accenture.poc.model.User;

@Aspect
@Component
public class RequestFormInputControllerAspect {

	@Autowired
	public UserDAO userdata;

	@Autowired
	public POCRequestMappingDAO pocRequestMappingdao;

	@Autowired
	public RequestFormDAO requestDetails;

	@Pointcut("(within(com.accenture.client.controller.RequestFormInputController) || within(com.accenture.poc.controller.POCLoginController) || within(com.accenture.displaygraph.controller.DisplayGraphControler)) && @annotation(org.springframework.web.bind.annotation.RequestMapping)")
	private void resetPasswordPointCut() {

	}

	@Pointcut("execution(* com.accenture.client.controller.RequestFormInputController.signup(..)) || execution(* com.accenture.client.controller.RequestFormInputController.clientSignedup(..))")
	private void signUpPointCut() {

	}

	@Pointcut("execution(* com.accenture.client.controller.RequestFormInputController.getProgress(..))")
	private void getProgressPointCut() {

	}

	@Pointcut("execution(* com.accenture.client.controller.RequestFormInputController.loadRequestFromDisplay(..)) || execution(* com.accenture.client.controller.RequestFormInputController.clientFilesProcessing(..)) || execution(* com.accenture.client.controller.RequestFormInputController.requestStatus(..)) || execution(* com.accenture.client.controller.RequestFormInputController.downloadTransportRequestFile(..))  || execution(* com.accenture.client.controller.RequestFormInputController.uploadFiles(..))  || execution(* com.accenture.client.controller.RequestFormInputController.validateFilesAndAnalyseST03Data(..)) || execution(* com.accenture.client.controller.RequestFormInputController.showRequestIDDetails(..)) || execution(* com.accenture.poc.controller.POCLoginController.showStatusRequestID(..)) || execution(* com.accenture.poc.controller.POCLoginController.showRequestIDDetails(..)) || execution(* com.accenture.poc.controller.POCLoginController.downloadnamingConvention(..)) ||  execution(* com.accenture.poc.controller.POCLoginController.downloadnameSpaces(..)) ||  execution(* com.accenture.poc.controller.POCLoginController.requestApprovalORRejection(..)) ||  execution(* com.accenture.poc.controller.POCLoginController.downloadApprovedTR(..)) ||  execution(* com.accenture.poc.controller.POCLoginController.requestApproved(..)) ||  execution(* com.accenture.poc.controller.POCLoginController.requestNotApproved(..)) ||  execution(* com.accenture.poc.controller.POCLoginController.requestRejection(..)) ||  execution(* com.accenture.poc.controller.POCLoginController.clientFilesProcessing(..)) ||  execution(* com.accenture.poc.controller.POCLoginController.finalOutput(..))")
	private void checkRequestIdPointCut() {

	}

	@Before("checkRequestIdPointCut()")
	public void checkRequestIdAdvice(JoinPoint joinPoint) {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes())
				.getRequest();
		Object requestIdObject = joinPoint.getArgs()[0];
		if (requestIdObject != null && StringUtils.isNotBlank(requestIdObject.toString())) {
			Long requestId = Long.parseLong(requestIdObject.toString());
			final RequestForm requestForm = requestDetails.getRequestObj(requestId);
			if (requestForm == null) {
				throw new RequestNotValidException();
			}

			if (!request.isUserInRole(Hana_Profiler_Constant.ADMIN)) {
				String userName = SecurityContextHolder.getContext().getAuthentication().getName();

				boolean isClient = false;
				if (request.isUserInRole(Hana_Profiler_Constant.CLIENT)) {
					isClient = true;
				}
				if (!pocRequestMappingdao.checkRequestId(requestId, userName, isClient)) {
					throw new RequestNotValidException();
				}
			}
		}
	}

}
