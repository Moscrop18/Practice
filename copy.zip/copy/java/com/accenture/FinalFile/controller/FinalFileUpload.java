package com.accenture.FinalFile.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.accenture.FinalFile.dao.FinalFileUploadDaoImpl;
import com.accenture.POCReader.Xlsx.MigrationPOCReader;
import com.accenture.POCUtility.models.InventoryListPOC;
import com.accenture.POCUtility.models.POC_AffectedByCustomFields;
import com.accenture.POCUtility.models.POC_AppendStructureAnalysis;
import com.accenture.POCUtility.models.POC_BWCleanUpUtility;
import com.accenture.POCUtility.models.POC_BWInventory;
import com.accenture.POCUtility.models.POC_BWStandardExtract;
import com.accenture.POCUtility.models.POC_CVITROutput;
import com.accenture.POCUtility.models.POC_DRS4Simplification1;
import com.accenture.POCUtility.models.POC_DRS4Simplification2;
import com.accenture.POCUtility.models.POC_DRS4Simplification3;
import com.accenture.POCUtility.models.POC_DR_DB_Change;
import com.accenture.POCUtility.models.POC_DR_ExistingErrors;
import com.accenture.POCUtility.models.POC_DR_FioriOdata;
import com.accenture.POCUtility.models.POC_DrillDownReport;
import com.accenture.POCUtility.models.POC_FioriOutput;
import com.accenture.POCUtility.models.POC_ImpactedBackgroundJob;
import com.accenture.POCUtility.models.POC_ImpactedCloneAnalysis;
import com.accenture.POCUtility.models.POC_ImpactedCloneProgramAnalysis;
import com.accenture.POCUtility.models.POC_ImpactedCustomTable;
import com.accenture.POCUtility.models.POC_ImpactedEnhancementBadi;
import com.accenture.POCUtility.models.POC_ImpactedIdoc;
import com.accenture.POCUtility.models.POC_ImpactedObjectList;
import com.accenture.POCUtility.models.POC_ImpactedSAPScript;
import com.accenture.POCUtility.models.POC_ImpactedSearchHelp;
import com.accenture.POCUtility.models.POC_ImpactedStandardTransaction;
import com.accenture.POCUtility.models.POC_ImpactedTables;
import com.accenture.POCUtility.models.POC_Impacted_Variant;
import com.accenture.POCUtility.models.POC_InactiveObjects;
import com.accenture.POCUtility.models.POC_InconsistentFUGR;
import com.accenture.POCUtility.models.POC_NonUnicodeObjects;
import com.accenture.POCUtility.models.POC_OS_Migration;
import com.accenture.POCUtility.models.POC_OS_Migration_FilePath;
import com.accenture.POCUtility.models.POC_OS_Migration_LogicalCMD;
import com.accenture.POCUtility.models.POC_OutputManagement;
import com.accenture.POCUtility.models.POC_S4_SID;
import com.accenture.POCUtility.models.POC_SecAnalyzerTCDReport;
import com.accenture.POCUtility.models.POC_Smodilog;
import com.accenture.POCUtility.models.POC_TestingScope;
import com.accenture.POCUtility.models.POC_Ui5FinalOutput;
import com.accenture.POCUtility.models.POC_Ui5HighLevelReport;
import com.accenture.client.dao.RequestFormDAO;
import com.accenture.client.model.RequestForm;
import com.accenture.constant.Hana_Profiler_Constant;
import com.accenture.constant.POC_Upload_Constant;
import com.accenture.utility.AppGenUtility;
import com.accenture.utility.FileUtility;
import com.accenture.utility.UtilityForPoc;
import com.monitorjbl.xlsx.StreamingReader;

@Service
public class FinalFileUpload implements FinalFileUpload_Interface {

	private final Logger logger = LoggerFactory.getLogger(FinalFileUpload.class);

	@Autowired
	private RequestFormDAO requestDetails;

	public RequestFormDAO getRequestDetails() {
		return requestDetails;
	}

	String uploadPath = null;
	String filename = "";

	@Autowired
	private FinalFileUploadDaoImpl detailReportJDBCBatchInsertUpdate;

	// Read Migration Sheet From POC::::::::::::::: --himani.malhotra
	@SuppressWarnings("static-access")
	public String readMigrationSheetData(String path, long requestId, RequestForm requestForm, HttpSession session,
			Map<String, String> fileMap) throws Exception {

		final Logger logger = LoggerFactory.getLogger(getClass());

		MigrationPOCReader migrationSheet = new MigrationPOCReader();

		String comment = "";

		try {
			boolean scopeAUCT = requestForm.getUPGRADE();
			boolean scopeUI5 = requestForm.getUI5();
			boolean scopeSOH = requestForm.getSOH();
			boolean scopeS4Tech = requestForm.getS4Technical();
			boolean scopeOsMig = requestForm.getOsMig();
			boolean scopeBwTech = requestForm.getBwTech();
			boolean scopeFiori = requestForm.getFiori();
			boolean scopeUi5 = requestForm.getUI5();
			boolean scopeSIA = requestForm.getSia();

			// Getting the sheet names based on the selected scope
			Map<String, String> sheetname = getSheetNameScopeBasedFromPropFile("ScopeBased_SheetName");
			Set<String> sheetNameSet = new HashSet<String>();
			getSheetNameSetForPoc(scopeAUCT, scopeUI5, scopeSOH, scopeS4Tech, scopeOsMig, scopeBwTech, scopeFiori,
					scopeUi5, scopeSIA, sheetname, sheetNameSet);

			// Reading Security Analyzer TCD Report
			if (fileMap.containsKey("SIAFile") && path.contains(fileMap.get("SIAFile"))) {
				readSIAFinalReport(path, requestId, sheetNameSet, session, migrationSheet);
			}

			// Reading Final File Report
			if (fileMap.containsKey("HANAS4File") && path.contains(fileMap.get("HANAS4File"))) {
				readHANAS4FinalReport(path, requestId, sheetNameSet, session, migrationSheet);
			}

			comment = "success";

			logger.info("Reading of Final File Report Successful ...");
		} catch (Exception e) {
			logger.error("Error in readMigrationData()  :: ", e);
			throw e;
		}

		return comment;
	}

	private void getSheetNameSetForPoc(boolean scopeAUCT, boolean scopeUI5, boolean scopeSOH, boolean scopeS4Tech,
			boolean scopeOsMig, boolean scopeBwTech, boolean scopeFiori, boolean scopeUi5, boolean scopeSIA,
			Map<String, String> sheetname, Set<String> sheetNameSet) {
		if (scopeBwTech) {
			String[] parts = sheetname.get("BwTech").split(",");
			sheetNameSet.addAll(Arrays.asList(parts));
		}

		if (scopeOsMig) {
			String[] parts = sheetname.get("OsMig").split(",");
			sheetNameSet.addAll(Arrays.asList(parts));
		}

		if (scopeS4Tech) {
			String[] parts = sheetname.get("S4Tech").split(",");
			sheetNameSet.addAll(Arrays.asList(parts));
		}

		if (scopeSOH) {
			String[] parts = sheetname.get("SOH").split(",");
			sheetNameSet.addAll(Arrays.asList(parts));
		}

		if (scopeUI5) {
			String[] parts = sheetname.get("UI5").split(",");
			sheetNameSet.addAll(Arrays.asList(parts));
		}

		if (scopeAUCT) {
			String[] parts = sheetname.get("Upgrade").split(",");
			sheetNameSet.addAll(Arrays.asList(parts));
		}

		if (scopeFiori) {
			String[] parts = sheetname.get("FIORI").split(",");
			sheetNameSet.addAll(Arrays.asList(parts));
		}

		if (scopeUi5) {
			String[] parts = sheetname.get("UI5").split(",");
			sheetNameSet.addAll(Arrays.asList(parts));
		}

		if (scopeSIA) {
			String[] parts = sheetname.get("SIA").split(",");
			sheetNameSet.addAll(Arrays.asList(parts));
		}
	}

	private void readHANAS4FinalReport(String path, long requestId, Set<String> sheetNameSet, HttpSession session,
			MigrationPOCReader migrationSheet) throws Exception {
		try {
			if (sheetNameSet != null) {
				for (String sheet : sheetNameSet) {
					if (sheet != null && POC_Upload_Constant.POC_INVENTORY_LIST.equalsIgnoreCase(sheet.trim())) {
						pocSheetProcessingBusinessLogicInventoryList(path, requestId, session, migrationSheet, sheet);
					}

					else if (sheet != null && POC_Upload_Constant.POC_IMPACTED_OBJECT.equalsIgnoreCase(sheet.trim())) {
						getImpactedObjectListPoc(path, requestId, session, migrationSheet, sheet);
					}

					else if (sheet != null && POC_Upload_Constant.POC_DRDB.equalsIgnoreCase(sheet.trim())) {
						getImpactedDueToDBChangePoc(path, requestId, session, migrationSheet, sheet);
					}

					else if (sheet != null
							&& POC_Upload_Constant.POC_S4_DETAIL_REPORT1.equalsIgnoreCase(sheet.trim())) {
						Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet,
								requestId, session);

						int rowIndex = 0;

						final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
						UtilityForPoc pocUtility = new UtilityForPoc();
						pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

						final File file = new File(path);
						InputStream inputStream = new FileInputStream(file);

						try {
							List<POC_DRS4Simplification1> s4DR1List = new ArrayList<POC_DRS4Simplification1>();
							StreamingReader s4DR1Listreader = StreamingReader.builder().rowCacheSize(1002)
									.bufferSize(1024).sheetName(sheet).read(inputStream);

							if (s4DR1Listreader != null) {
								for (Row row : s4DR1Listreader) {
									if (!AppGenUtility.isRowEmpty(row)) {
										if (row.getRowNum() > rowIndex) {
											POC_DRS4Simplification1 s4DR1 = migrationSheet
													.getS4FinalOutputListValueXlsx(row, requestId, sheet);
											if (s4DR1 != null) {
												s4DR1List.add(s4DR1);
											}
										}
									}
								}

								if (s4DR1List != null && !s4DR1List.isEmpty()) {
									detailReportJDBCBatchInsertUpdate
											.pocS4Simplification1ListBatchInsertUpdate(s4DR1List, session);
								} else {
									logger.info("S4-1 List is null");
								}

								logger.info("POC_DRS4Simplification1 :::::::::: READING AND PERSISTING DONE");
							}
						} finally {
							IOUtils.closeQuietly(inputStream);
						}
					}

					else if (POC_Upload_Constant.POC_EXISTING_ERRORS.equalsIgnoreCase(sheet.trim())) {
						pocFileProcessingBusinessLogicAuctUpgrade(path, requestId, session, migrationSheet, sheet);
					}

					/*else if (sheet != null && POC_Upload_Constant.POC_FIORI_ODATA.equalsIgnoreCase(sheet.trim())) {
						Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet,
								requestId, session);

						int rowIndex = 0;

						final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
						UtilityForPoc pocUtility = new UtilityForPoc();
						pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

						final File file = new File(path);
						InputStream inputStream = new FileInputStream(file);

						try {
							List<POC_DR_FioriOdata> fioriOdataList = new ArrayList<POC_DR_FioriOdata>();
							StreamingReader fioriOdataListreader = StreamingReader.builder().rowCacheSize(1002)
									.bufferSize(1024).sheetName(sheet).read(inputStream);

							if (fioriOdataListreader != null) {
								for (Row row : fioriOdataListreader) {
									if (!AppGenUtility.isRowEmpty(row)) {
										if (row.getRowNum() > rowIndex) {
											POC_DR_FioriOdata fioriOdata = migrationSheet
													.getFioriOdataListValueXlsx(row, requestId, sheet);
											if (fioriOdata != null) {
												fioriOdataList.add(fioriOdata);
											}
										}
									}
								}

								if (fioriOdataList != null && !fioriOdataList.isEmpty()) {
									detailReportJDBCBatchInsertUpdate.pocFioriBatchInsertUpdate(fioriOdataList,
											session);
								} else {
									logger.info("Fiori List is null");
								}

								logger.info("POC_DR_FioriOdata :::::::::: READING AND PERSISTING DONE");
							}
						} finally {
							IOUtils.closeQuietly(inputStream);
						}
					}*/

					else if (sheet != null
							&& POC_Upload_Constant.POC_OUTPUT_MANAGEMENT.equalsIgnoreCase(sheet.trim())) {
						Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet,
								requestId, session);

						int rowIndex = 6;

						final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
						UtilityForPoc pocUtility = new UtilityForPoc();
						pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

						final File file = new File(path);
						InputStream inputStream = new FileInputStream(file);

						try {
							List<POC_OutputManagement> outputMngmtList = new ArrayList<POC_OutputManagement>();
							StreamingReader outputMngmtListreader = StreamingReader.builder().rowCacheSize(1002)
									.bufferSize(1024).sheetName(sheet).read(inputStream);

							if (outputMngmtListreader != null) {
								for (Row row : outputMngmtListreader) {

									if (!AppGenUtility.isRowEmpty(row)) {
										if (row.getRowNum() > rowIndex) {
											POC_OutputManagement outputMngmt = migrationSheet
													.getOutputMngmtListValueXlsx(row, requestId, sheet);
											if (outputMngmt != null) {
												outputMngmtList.add(outputMngmt);
											}
										}
									}
								}

								if (outputMngmtList != null && !outputMngmtList.isEmpty()) {
									detailReportJDBCBatchInsertUpdate
											.pocOutputMngmtListBatchInsertUpdate(outputMngmtList, session);
								} else {
									logger.info("Output Mngmt List is null");
								}

								logger.info("POC_OutputManagement :::::::::: READING AND PERSISTING DONE");
							}
						} finally {
							IOUtils.closeQuietly(inputStream);
						}
					}

					else if (sheet != null && POC_Upload_Constant.POC_AFFECTED_CUSTOM.equalsIgnoreCase(sheet.trim())) {
						Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet,
								requestId, session);

						int rowIndex = 7;

						final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
						UtilityForPoc pocUtility = new UtilityForPoc();
						pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

						final File file = new File(path);
						InputStream inputStream = new FileInputStream(file);

						try {
							List<POC_AffectedByCustomFields> affectCustomList = new ArrayList<POC_AffectedByCustomFields>();
							StreamingReader affectCustomListreader = StreamingReader.builder().rowCacheSize(1002)
									.bufferSize(1024).sheetName(sheet).read(inputStream);

							if (affectCustomListreader != null) {
								for (Row row : affectCustomListreader) {
									if (!AppGenUtility.isRowEmpty(row)) {
										if (row.getRowNum() > rowIndex) {
											POC_AffectedByCustomFields affectCustom = migrationSheet
													.getAffectedCustomFieldsListValueXlsx(row, requestId, sheet);
											if (affectCustom != null) {
												affectCustomList.add(affectCustom);
											}
										}
									}
								}

								if (affectCustomList != null && !affectCustomList.isEmpty()) {
									detailReportJDBCBatchInsertUpdate
											.pocAffectedCustomFieldListBatchInsertUpdate(affectCustomList, session);
								} else {
									logger.info("Affected by Custom Fields List is null");
								}

								logger.info("POC_AffectedByCustomFields :::::::::: READING AND PERSISTING DONE");
							}
						} finally {
							IOUtils.closeQuietly(inputStream);
						}
					}

					else if (sheet != null && POC_Upload_Constant.POC_IMPACTED_TABLES.equalsIgnoreCase(sheet.trim())) {
						Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet,
								requestId, session);
						int rowIndex = 3;

						final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
						UtilityForPoc pocUtility = new UtilityForPoc();
						pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

						final File file = new File(path);
						InputStream inputStream = new FileInputStream(file);

						try {
							List<POC_ImpactedTables> impactedTablesList = new ArrayList<POC_ImpactedTables>();
							StreamingReader impactedTablesListreader = StreamingReader.builder().rowCacheSize(1002)
									.bufferSize(1024).sheetName(sheet).read(inputStream);

							if (impactedTablesListreader != null) {
								for (Row row : impactedTablesListreader) {
									if (!AppGenUtility.isRowEmpty(row)) {
										if (row.getRowNum() > rowIndex) {
											POC_ImpactedTables impactedTables = migrationSheet
													.getImpactedTablesListValueXlsx(row, requestId, sheet);
											if (impactedTables != null) {
												impactedTablesList.add(impactedTables);
											}
										}
									}
								}
								if (impactedTablesList != null && !impactedTablesList.isEmpty()) {
									detailReportJDBCBatchInsertUpdate
											.pocImpactedTablesBatchInsertUpdate(impactedTablesList, session);
								} else {
									logger.info("Impacted Tables List is null");
								}

								logger.info("POC_ImpactedTables :::::::::: READING AND PERSISTING DONE");
							}
						} finally {
							IOUtils.closeQuietly(inputStream);
						}
					}

					else if (sheet != null && POC_Upload_Constant.POC_IMPACTED_IDOC.equalsIgnoreCase(sheet.trim())) {
						Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet,
								requestId, session);

						int rowIndex = 2;

						final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
						UtilityForPoc pocUtility = new UtilityForPoc();
						pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

						final File file = new File(path);
						InputStream inputStream = new FileInputStream(file);

						try {
							List<POC_ImpactedIdoc> impactedIDOCList = new ArrayList<POC_ImpactedIdoc>();
							StreamingReader impactedIDOCListreader = StreamingReader.builder().rowCacheSize(1002)
									.bufferSize(1024).sheetName(sheet).read(inputStream);

							if (impactedIDOCListreader != null) {
								for (Row row : impactedIDOCListreader) {

									if (!AppGenUtility.isRowEmpty(row)) {
										if (row.getRowNum() > rowIndex) {
											POC_ImpactedIdoc impactedIDOC = migrationSheet
													.getImpactedIDOCListValueXlsx(row, requestId, sheet);
											if (impactedIDOC != null) {
												impactedIDOCList.add(impactedIDOC);
											}
										}
									}
								}
								if (impactedIDOCList != null && !impactedIDOCList.isEmpty()) {
									detailReportJDBCBatchInsertUpdate.pocImpactedIDOCBatchInsertUpdate(impactedIDOCList,
											session);
								} else {
									logger.info("Impacted IDOC List is null");
								}

								logger.info("POC_ImpactedIdoc :::::::::: READING AND PERSISTING DONE");
							}
						} finally {
							IOUtils.closeQuietly(inputStream);
						}
					}

					else if (sheet != null
							&& POC_Upload_Constant.POC_IMPACTED_STANDARD.equalsIgnoreCase(sheet.trim())) {
						Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet,
								requestId, session);

						int rowIndex = 2;

						final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
						UtilityForPoc pocUtility = new UtilityForPoc();
						pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

						final File file = new File(path);
						InputStream inputStream = new FileInputStream(file);

						try {
							List<POC_ImpactedStandardTransaction> impactedStandardTransactionsList = new ArrayList<POC_ImpactedStandardTransaction>();
							StreamingReader impactedStandardTransactionsListreader = StreamingReader.builder()
									.rowCacheSize(1002).bufferSize(1024).sheetName(sheet).read(inputStream);

							if (impactedStandardTransactionsListreader != null) {
								for (Row row : impactedStandardTransactionsListreader) {
									if (!AppGenUtility.isRowEmpty(row)) {
										if (row.getRowNum() > rowIndex) {
											POC_ImpactedStandardTransaction impactedStandardTransactions = migrationSheet
													.getImpactedStandardTransactionListValueXlsx(row, requestId, sheet);
											if (impactedStandardTransactions != null) {
												impactedStandardTransactionsList.add(impactedStandardTransactions);
											}
										}
									}
								}

								if (impactedStandardTransactionsList != null
										&& !impactedStandardTransactionsList.isEmpty()) {
									detailReportJDBCBatchInsertUpdate.pocImpactedStandardTransactionBatchInsertUpdate(
											impactedStandardTransactionsList, session);
								} else {
									logger.info("Impacted Transactions List is null");
								}

								logger.info("POC_ImpactedStandardTransaction :::::::::: READING AND PERSISTING DONE");
							}
						} finally {
							IOUtils.closeQuietly(inputStream);
						}
					}

					else if (sheet != null && POC_Upload_Constant.POC_IMPACTED_SEARCH.equalsIgnoreCase(sheet.trim())) {
						Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet,
								requestId, session);

						int rowIndex = 2;

						final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
						UtilityForPoc pocUtility = new UtilityForPoc();
						pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

						final File file = new File(path);
						InputStream inputStream = new FileInputStream(file);

						try {
							List<POC_ImpactedSearchHelp> impactedSearchHelpList = new ArrayList<POC_ImpactedSearchHelp>();
							StreamingReader impactedSearchHelpListreader = StreamingReader.builder().rowCacheSize(1002)
									.bufferSize(1024).sheetName(sheet).read(inputStream);

							if (impactedSearchHelpListreader != null) {
								for (Row row : impactedSearchHelpListreader) {

									if (!AppGenUtility.isRowEmpty(row)) {
										if (row.getRowNum() > rowIndex) {
											POC_ImpactedSearchHelp impactedSearchHelp = migrationSheet
													.getImpactedSearchHelpListValueXlsx(row, requestId, sheet);
											if (impactedSearchHelp != null) {
												impactedSearchHelpList.add(impactedSearchHelp);
											}
										}
									}
								}

								if (impactedSearchHelpList != null && !impactedSearchHelpList.isEmpty()) {
									detailReportJDBCBatchInsertUpdate
											.pocImpactedSearchHelpBatchInsertUpdate(impactedSearchHelpList, session);
								} else {
									logger.info("Impacted Search Help List is null");

								}

								logger.info("POC_ImpactedSearchHelp :::::::::: READING AND PERSISTING DONE");
							}
						} finally {
							IOUtils.closeQuietly(inputStream);
						}
					}

					else if (sheet != null && POC_Upload_Constant.POC_APPEND_STRUCTURE.equalsIgnoreCase(sheet.trim())) {
						Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet,
								requestId, session);

						int rowIndex = 2;

						final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
						UtilityForPoc pocUtility = new UtilityForPoc();
						pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

						final File file = new File(path);
						InputStream inputStream = new FileInputStream(file);

						try {
							List<POC_AppendStructureAnalysis> appendStructureList = new ArrayList<POC_AppendStructureAnalysis>();
							StreamingReader appendStructureListreader = StreamingReader.builder().rowCacheSize(1002)
									.bufferSize(1024).sheetName(sheet).read(inputStream);

							if (appendStructureListreader != null) {
								for (Row row : appendStructureListreader) {

									if (!AppGenUtility.isRowEmpty(row)) {
										if (row.getRowNum() > rowIndex) {
											POC_AppendStructureAnalysis appendStructure = migrationSheet
													.getAppendStructureListValueXlsx(row, requestId, sheet);
											if (appendStructure != null) {
												appendStructureList.add(appendStructure);
											}
										}
									}
								}

								if (appendStructureList != null && !appendStructureList.isEmpty()) {
									detailReportJDBCBatchInsertUpdate
											.pocAppendStructureBatchInsertUpdate(appendStructureList, session);
								} else {
									logger.info("Append Structure List is null");
								}

								logger.info("POC_AppendStructureAnalysis :::::::::: READING AND PERSISTING DONE");
							}
						} finally {
							IOUtils.closeQuietly(inputStream);
						}
					}

					else if (sheet != null && POC_Upload_Constant.POC_CLONE_PROG.equalsIgnoreCase(sheet.trim())) {
						Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet,
								requestId, session);

						int rowIndex = 2;

						final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
						UtilityForPoc pocUtility = new UtilityForPoc();
						pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

						final File file = new File(path);
						InputStream inputStream = new FileInputStream(file);

						try {
							List<POC_ImpactedCloneProgramAnalysis> cloneProgList = new ArrayList<POC_ImpactedCloneProgramAnalysis>();
							StreamingReader cloneProgListreader = StreamingReader.builder().rowCacheSize(1002)
									.bufferSize(1024).sheetName(sheet).read(inputStream);

							if (cloneProgListreader != null) {
								for (Row row : cloneProgListreader) {

									if (!AppGenUtility.isRowEmpty(row)) {
										if (row.getRowNum() > rowIndex) {
											POC_ImpactedCloneProgramAnalysis cloneProg = migrationSheet
													.getCloneProgValueXlsx(row, requestId, sheet);
											if (cloneProg != null) {
												cloneProgList.add(cloneProg);
											}

										}
									}
								}

								if (cloneProgList != null && !cloneProgList.isEmpty()) {
									detailReportJDBCBatchInsertUpdate.pocCloneProgBatchInsertUpdate(cloneProgList,
											session);
								} else {
									logger.info("Clone Prog List is null");
								}

								logger.info("POC_ImpactedCloneProgramAnalysis :::::::::: READING AND PERSISTING DONE");
							}
						} finally {
							IOUtils.closeQuietly(inputStream);
						}
					}

					else if (sheet != null && POC_Upload_Constant.POC_ENHANCEMENT.equalsIgnoreCase(sheet.trim())) {
						Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet,
								requestId, session);

						int rowIndex = 2;

						final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
						UtilityForPoc pocUtility = new UtilityForPoc();
						pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

						final File file = new File(path);
						InputStream inputStream = new FileInputStream(file);

						try {
							List<POC_ImpactedEnhancementBadi> impactedBadiList = new ArrayList<POC_ImpactedEnhancementBadi>();
							StreamingReader impactedBadiListreader = StreamingReader.builder().rowCacheSize(1002)
									.bufferSize(1024).sheetName(sheet).read(inputStream);

							if (impactedBadiListreader != null) {
								for (Row row : impactedBadiListreader) {

									if (!AppGenUtility.isRowEmpty(row)) {
										if (row.getRowNum() > rowIndex) {
											POC_ImpactedEnhancementBadi impactedBadi = migrationSheet
													.getEnhancementBADIListValueXlsx(row, requestId, sheet);
											if (impactedBadi != null) {
												impactedBadiList.add(impactedBadi);
											}
										}
									}
								}

								if (impactedBadiList != null && !impactedBadiList.isEmpty()) {
									detailReportJDBCBatchInsertUpdate
											.pocEnhancementBADIBatchInsertUpdate(impactedBadiList, session);
								} else {
									logger.info("Enhancement Badi List is null");
								}

								logger.info("POC_ImpactedEnhancementBadi :::::::::: READING AND PERSISTING DONE");
							}
						} finally {
							IOUtils.closeQuietly(inputStream);
						}
					}

					else if (sheet != null
							&& POC_Upload_Constant.POC_S4_DETAIL_REPORT2.equalsIgnoreCase(sheet.trim())) {
						Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet,
								requestId, session);

						int rowIndex = 0;

						final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
						UtilityForPoc pocUtility = new UtilityForPoc();
						pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

						final File file = new File(path);
						InputStream inputStream = new FileInputStream(file);

						try {
							List<POC_DRS4Simplification2> s4DR2List = new ArrayList<POC_DRS4Simplification2>();
							StreamingReader s4DR2Listreader = StreamingReader.builder().rowCacheSize(1002)
									.bufferSize(1024).sheetName(sheet).read(inputStream);

							if (s4DR2Listreader != null) {
								for (Row row : s4DR2Listreader) {

									if (!AppGenUtility.isRowEmpty(row)) {
										rowIndex = Integer.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE
												.get(requestId).get(sheet).get("Obj.Type"));
										if (row.getRowNum() > rowIndex) {
											POC_DRS4Simplification2 s4DR2 = migrationSheet
													.getS4Simplification2ListValueXlsx(row, requestId, sheet);
											if (s4DR2 != null) {
												s4DR2List.add(s4DR2);
											}
										}
									}
								}

								if (s4DR2List != null && !s4DR2List.isEmpty()) {
									detailReportJDBCBatchInsertUpdate.pocDRS4Simplification2BatchInsertUpdate(s4DR2List,
											session);
								} else {
									logger.info("S4-2 List is null");
								}

								logger.info("POC_DRS4Simplification2 :::::::::: READING AND PERSISTING DONE");
							}
						} finally {
							IOUtils.closeQuietly(inputStream);
						}
					}

					else if (sheet != null
							&& POC_Upload_Constant.POC_S4_DETAIL_REPORT3.equalsIgnoreCase(sheet.trim())) {
						Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet,
								requestId, session);

						int rowIndex = 0;

						final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
						UtilityForPoc pocUtility = new UtilityForPoc();
						pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

						final File file = new File(path);
						InputStream inputStream = new FileInputStream(file);

						try {
							List<POC_DRS4Simplification3> s4DR3List = new ArrayList<POC_DRS4Simplification3>();
							StreamingReader s4DR3Listreader = StreamingReader.builder().rowCacheSize(1002)
									.bufferSize(1024).sheetName(sheet).read(inputStream);

							if (s4DR3Listreader != null) {
								for (Row row : s4DR3Listreader) {

									if (!AppGenUtility.isRowEmpty(row)) {
										rowIndex = Integer.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE
												.get(requestId).get(sheet).get("Obj.Type"));
										if (row.getRowNum() > rowIndex) {
											POC_DRS4Simplification3 s4DR2 = migrationSheet
													.getS4Simplification3ListValueXlsx(row, requestId, sheet);
											if (s4DR2 != null) {
												s4DR3List.add(s4DR2);
											}
										}
									}
								}

								if (s4DR3List != null && !s4DR3List.isEmpty()) {
									detailReportJDBCBatchInsertUpdate.pocDRS4Simplification3BatchInsertUpdate(s4DR3List,
											session);
								} else {
									logger.info("S4-3 List is null");
								}

								logger.info("POC_DRS4Simplification3 :::::::::: READING AND PERSISTING DONE");
							}
						} finally {
							IOUtils.closeQuietly(inputStream);
						}
					}

					else if (POC_Upload_Constant.POC_UI5.equalsIgnoreCase(sheet.trim())) {
						pocFileProcessingBusinessLogicUI5(path, requestId, session, migrationSheet, sheet);
					} else if (POC_Upload_Constant.POC_UI5_HIGHLEVEL.equalsIgnoreCase(sheet.trim())) {
						pocFileProcessingBusinessLogicUI5HighLevel(path, requestId, session, migrationSheet, sheet);
					} else if (sheet != null && POC_Upload_Constant.POC_TESTING_SCOPE.equalsIgnoreCase(sheet.trim())) {
						Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet,
								requestId, session);

						int rowIndex = 0;

						final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
						UtilityForPoc pocUtility = new UtilityForPoc();
						pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

						final File file = new File(path);
						InputStream inputStream = new FileInputStream(file);

						try {
							List<POC_TestingScope> pocTestingScopeList = new ArrayList<POC_TestingScope>();
							StreamingReader pocTestingScopeListreader = StreamingReader.builder().rowCacheSize(1002)
									.bufferSize(1024).sheetName(sheet).read(inputStream);

							if (pocTestingScopeListreader != null) {
								for (Row row : pocTestingScopeListreader) {

									if (!AppGenUtility.isRowEmpty(row)) {
										rowIndex = Integer.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE
												.get(requestId).get(sheet).get("Process"));
										if (row.getRowNum() > rowIndex) {
											POC_TestingScope pocTestingScope = migrationSheet
													.getTestingScopeValueXlsx(row, requestId, sheet);
											if (pocTestingScope != null)
												pocTestingScopeList.add(pocTestingScope);
										}
									}
								}

								if (pocTestingScopeList != null && !pocTestingScopeList.isEmpty()) {
									detailReportJDBCBatchInsertUpdate
											.pocTestingScopeBatchInsertUpdate(pocTestingScopeList, session);
								} else {
									logger.info("Testing_Scope List is null");
								}

								logger.info("POC_TestingScope :::::::::: READING AND PERSISTING DONE");
							}
						} finally {
							IOUtils.closeQuietly(inputStream);
						}
					}

					else if (sheet != null
							&& POC_Upload_Constant.POC_IMPACTED_BACKGROUND_JOB.equalsIgnoreCase(sheet.trim())) {
						Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet,
								requestId, session);

						int rowIndex = 0;

						final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
						UtilityForPoc pocUtility = new UtilityForPoc();
						pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

						final File file = new File(path);
						InputStream inputStream = new FileInputStream(file);

						try {
							List<POC_ImpactedBackgroundJob> pocImpactedBackgroundJobList = new ArrayList<POC_ImpactedBackgroundJob>();
							StreamingReader pocImpactedBackgroundJobreader = StreamingReader.builder()
									.rowCacheSize(1002).bufferSize(1024).sheetName(sheet).read(inputStream);

							if (pocImpactedBackgroundJobreader != null) {
								for (Row row : pocImpactedBackgroundJobreader) {
									if (!AppGenUtility.isRowEmpty(row)) {
										rowIndex = Integer.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE
												.get(requestId).get(sheet).get("Object"));
										if (row.getRowNum() > rowIndex) {
											POC_ImpactedBackgroundJob pocImpactedBackgroundJob = migrationSheet
													.getImpactedBackgroundJobValueXlsx(row, requestId, sheet);
											if (pocImpactedBackgroundJob != null) {
												pocImpactedBackgroundJobList.add(pocImpactedBackgroundJob);
											}
										}
									}
								}

								if (pocImpactedBackgroundJobList != null && !pocImpactedBackgroundJobList.isEmpty()) {
									detailReportJDBCBatchInsertUpdate.pocImpactedBackgroundJobBatchInsertUpdate(
											pocImpactedBackgroundJobList, session);
								} else {
									logger.info("Impacted_Background_Job List is null");
								}

								logger.info("POC_ImpactedBackgroundJob :::::::::: READING AND PERSISTING DONE");
							}
						} finally {
							IOUtils.closeQuietly(inputStream);
						}
					}

					else if (sheet != null && POC_Upload_Constant.POC_SMODILOG.equalsIgnoreCase(sheet.trim())) {
						Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet,
								requestId, session);

						int rowIndex = 0;

						final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
						UtilityForPoc pocUtility = new UtilityForPoc();
						pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

						final File file = new File(path);
						InputStream inputStream = new FileInputStream(file);

						try {
							List<POC_Smodilog> pocSmodilogList = new ArrayList<POC_Smodilog>();
							StreamingReader pocSmodilogListreader = StreamingReader.builder().rowCacheSize(1002)
									.bufferSize(1024).sheetName(sheet).read(inputStream);

							if (pocSmodilogListreader != null) {
								for (Row row : pocSmodilogListreader) {

									if (!AppGenUtility.isRowEmpty(row)) {
										if (row.getRowNum() > rowIndex) {
											POC_Smodilog pocSmodilog = migrationSheet.getSmodilogValueXlsx(row,
													requestId, sheet);
											if (pocSmodilog != null) {
												pocSmodilogList.add(pocSmodilog);
											}
										}
									}
								}

								if (pocSmodilogList != null && !pocSmodilogList.isEmpty()) {
									detailReportJDBCBatchInsertUpdate.pocSmodilogListBatchInsertUpdate(pocSmodilogList,
											session);
								} else {
									logger.info("Smodilog List is null");
								}

								logger.info("POC_Smodilog :::::::::: READING AND PERSISTING DONE");
							}
						} finally {
							IOUtils.closeQuietly(inputStream);
						}
					}

					else if (sheet != null
							&& POC_Upload_Constant.POC_IMPACTEDSAP_SCRIPTS.equalsIgnoreCase(sheet.trim())) {
						Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet,
								requestId, session);

						int rowIndex = 0;

						final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
						UtilityForPoc pocUtility = new UtilityForPoc();
						pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

						final File file = new File(path);
						InputStream inputStream = new FileInputStream(file);

						try {

							List<POC_ImpactedSAPScript> pocImpactedSAPScriptsList = new ArrayList<POC_ImpactedSAPScript>();
							StreamingReader pocImpactedSAPScriptsListreader = StreamingReader.builder()
									.rowCacheSize(1002).bufferSize(1024).sheetName(sheet).read(inputStream);

							if (pocImpactedSAPScriptsListreader != null) {
								for (Row row : pocImpactedSAPScriptsListreader) {

									if (!AppGenUtility.isRowEmpty(row)) {
										rowIndex = Integer.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE
												.get(requestId).get(sheet).get("Prog"));
										if (row.getRowNum() > rowIndex) {
											POC_ImpactedSAPScript pocImpactedSAPScript = migrationSheet
													.getImpactedSAPScriptValueXlsx(row, requestId, sheet);
											if (pocImpactedSAPScript != null) {
												pocImpactedSAPScriptsList.add(pocImpactedSAPScript);
											}
										}
									}
								}

								if (pocImpactedSAPScriptsList != null && !pocImpactedSAPScriptsList.isEmpty()) {
									detailReportJDBCBatchInsertUpdate.pocImpactedSAPScriptListBatchInsertUpdate(
											pocImpactedSAPScriptsList, session);
								} else {
									logger.info("Impacted SAP Scripts List is null");
								}

								logger.info("POC_ImpactedSAPScript :::::::::: READING AND PERSISTING DONE");
							}
						} finally {
							IOUtils.closeQuietly(inputStream);
						}
					}

					else if (sheet != null && POC_Upload_Constant.POC_OS_MIGRATION_1_1.equalsIgnoreCase(sheet.trim())) {
						Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet,
								requestId, session);

						int rowIndex = 0;

						final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
						UtilityForPoc pocUtility = new UtilityForPoc();
						pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

						final File file = new File(path);
						InputStream inputStream = new FileInputStream(file);

						try {
							List<POC_OS_Migration> osMigrationList = new ArrayList<>();
							StreamingReader osMigrationListreader = StreamingReader.builder().rowCacheSize(1002)
									.bufferSize(1024).sheetName(sheet).read(inputStream);

							if (osMigrationListreader != null) {
								for (Row row : osMigrationListreader) {
									
									if (!AppGenUtility.isRowEmpty(row)) {
									if (row.getRowNum() > rowIndex) {
										POC_OS_Migration pocOSMigration = migrationSheet.getOSMigrationValueXlsx(row,
												requestId, sheet.trim());
										if (pocOSMigration != null) {
											osMigrationList.add(pocOSMigration);
										}
									}
								}
							}

								if (osMigrationList != null && !osMigrationList.isEmpty()) {
									detailReportJDBCBatchInsertUpdate.pocOSMigrationBatchInsertUpdate(osMigrationList,
											session);
								} else {
									logger.info("OS Migration List is null");
								}

								logger.info("POC_OS_Migration :::::::::: READING AND PERSISTING DONE");
							}
						} finally {
							IOUtils.closeQuietly(inputStream);
						}
					} else if (sheet != null
							&& POC_Upload_Constant.POC_OS_MIGRATION_2_2.equalsIgnoreCase(sheet.trim())) {
						Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet,
								requestId, session);

						int rowIndex = 0;

						final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
						UtilityForPoc pocUtility = new UtilityForPoc();
						pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

						final File file = new File(path);
						InputStream inputStream = new FileInputStream(file);

						try {
							List<POC_OS_Migration_LogicalCMD> osMigrationList = new ArrayList<>();
							StreamingReader osMigrationListreader = StreamingReader.builder().rowCacheSize(1002)
									.bufferSize(1024).sheetName(sheet).read(inputStream);

							if (osMigrationListreader != null) {
								for (Row row : osMigrationListreader) {

									if (!AppGenUtility.isRowEmpty(row)) {
										if (row.getRowNum() > rowIndex) {
											POC_OS_Migration_LogicalCMD pocOSMigration = migrationSheet
													.getOSMigrationLogicalCMDValueXlsx(row, requestId, sheet.trim());
											if (pocOSMigration != null) {
												osMigrationList.add(pocOSMigration);
											}
										}
									}
								}

								if (osMigrationList != null && !osMigrationList.isEmpty()) {
									detailReportJDBCBatchInsertUpdate
											.pocOSMigrationLogCMDBatchInsertUpdate(osMigrationList, session);
								} else {
									logger.info("OS Migration List is null");
								}

								logger.info("POC_OS_Migration :::::::::: READING AND PERSISTING DONE");
							}
						} finally {
							IOUtils.closeQuietly(inputStream);
						}
					} else if (sheet != null
							&& POC_Upload_Constant.POC_OS_MIGRATION_3_3.equalsIgnoreCase(sheet.trim())) {
						Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet,
								requestId, session);

						int rowIndex = 0;

						final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
						UtilityForPoc pocUtility = new UtilityForPoc();
						pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

						final File file = new File(path);
						InputStream inputStream = new FileInputStream(file);

						try {
							List<POC_OS_Migration_FilePath> osMigrationList = new ArrayList<>();
							StreamingReader osMigrationListreader = StreamingReader.builder().rowCacheSize(1002)
									.bufferSize(1024).sheetName(sheet).read(inputStream);

							if (osMigrationListreader != null) {
								for (Row row : osMigrationListreader) {

									if (!AppGenUtility.isRowEmpty(row)) {
										if (row.getRowNum() > rowIndex) {
											POC_OS_Migration_FilePath pocOSMigration = migrationSheet
													.getOSMigrationFilePathValueXlsx(row, requestId, sheet.trim());
											if (pocOSMigration != null) {
												osMigrationList.add(pocOSMigration);
											}
										}
									}
								}

								if (osMigrationList != null && !osMigrationList.isEmpty()) {
									detailReportJDBCBatchInsertUpdate
											.pocOSMigrationFilePathBatchInsertUpdate(osMigrationList, session);
								} else {
									logger.info("OS Migration List is null");
								}

								logger.info("POC_OS_Migration :::::::::: READING AND PERSISTING DONE");
							}
						} finally {
							IOUtils.closeQuietly(inputStream);
						}
					}

					else if (sheet != null
							&& POC_Upload_Constant.POC_IMPACTEDCLONE_ANALYSIS.equalsIgnoreCase(sheet.trim())) {
						Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet,
								requestId, session);

						int rowIndex = 0;

						final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
						UtilityForPoc pocUtility = new UtilityForPoc();
						pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

						final File file = new File(path);
						InputStream inputStream = new FileInputStream(file);

						try {
							List<POC_ImpactedCloneAnalysis> impactedCloneList = new ArrayList<>();
							StreamingReader impactedCloneListreader = StreamingReader.builder().rowCacheSize(1002)
									.bufferSize(1024).sheetName(sheet).read(inputStream);

							if (impactedCloneListreader != null) {
								for (Row row : impactedCloneListreader) {

									if (!AppGenUtility.isRowEmpty(row)) {
										if (row.getRowNum() > rowIndex) {
											POC_ImpactedCloneAnalysis pocImpactedClone = migrationSheet
													.getImpactedCloneAnalysisValueXlsx(row, requestId, sheet);
											if (pocImpactedClone != null) {
												impactedCloneList.add(pocImpactedClone);
											}
										}
									}
								}

								if (impactedCloneList != null && !impactedCloneList.isEmpty()) {
									detailReportJDBCBatchInsertUpdate
											.pocImpactedCloneAnalysisListBatchInsertUpdate(impactedCloneList, session);
								} else {
									logger.info("Impacted Clone List is null");
								}

								logger.info("POC_Impacted Clone :::::::::: READING AND PERSISTING DONE");
							}
						} finally {
							IOUtils.closeQuietly(inputStream);
						}
					}

					else if (sheet != null
							&& POC_Upload_Constant.POC_INCONSISTENT_FUGR.equalsIgnoreCase(sheet.trim())) {
						Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet,
								requestId, session);

						int rowIndex = 0;

						final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
						UtilityForPoc pocUtility = new UtilityForPoc();
						pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

						final File file = new File(path);
						InputStream inputStream = new FileInputStream(file);

						try {
							List<POC_InconsistentFUGR> inconsistentFUGRList = new ArrayList<>();
							StreamingReader inconsistentFUGRReader = StreamingReader.builder().rowCacheSize(1002)
									.bufferSize(1024).sheetName(sheet).read(inputStream);

							if (inconsistentFUGRReader != null) {
								for (Row row : inconsistentFUGRReader) {

									if (!AppGenUtility.isRowEmpty(row)) {
										if (row.getRowNum() > rowIndex) {
											POC_InconsistentFUGR pocInconsistentFUGR = migrationSheet
													.getInconsistentFUGR(row, requestId, sheet);
											if (pocInconsistentFUGR != null) {
												inconsistentFUGRList.add(pocInconsistentFUGR);
											}
										}
									}
								}

								if (inconsistentFUGRList != null && !inconsistentFUGRList.isEmpty()) {
									detailReportJDBCBatchInsertUpdate.pocInconsistentFUGR(inconsistentFUGRList,
											session);
								} else {
									logger.info("Inconsistent FUGR List is null");
								}

								logger.info("POC Inconsistent FUGR :::::::::: READING AND PERSISTING DONE");
							}
						} finally {
							IOUtils.closeQuietly(inputStream);
						}
					}

					else if (sheet != null && POC_Upload_Constant.POC_HARDCODING.equalsIgnoreCase(sheet.trim())) {
						Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet,
								requestId, session);

						int rowIndex = 0;

						final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
						UtilityForPoc pocUtility = new UtilityForPoc();
						pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

						final File file = new File(path);
						InputStream inputStream = new FileInputStream(file);

						try {
							List<POC_S4_SID> s4SIDList = new ArrayList<>();
							StreamingReader impactedHardcoding = StreamingReader.builder().rowCacheSize(1002)
									.bufferSize(1024).sheetName(sheet).read(inputStream);

							if (impactedHardcoding != null) {
								for (Row row : impactedHardcoding) {

									if (!AppGenUtility.isRowEmpty(row)) {
										if (row.getRowNum() > rowIndex) {
											POC_S4_SID pocS4SID = migrationSheet.getS4SID(row, requestId, sheet);
											if (pocS4SID != null) {
												s4SIDList.add(pocS4SID);
											}
										}
									}
								}

								if (s4SIDList != null && !s4SIDList.isEmpty()) {
									detailReportJDBCBatchInsertUpdate.pocS4SIDInsert(s4SIDList, session);
								} else {
									logger.info("S4 SID List is null");
								}

								logger.info("POC  :::::::::: READING AND PERSISTING DONE");
							}
						} finally {
							IOUtils.closeQuietly(inputStream);
						}
					}

					else if (sheet != null && POC_Upload_Constant.POC_IMPACTED_VARIANT.equalsIgnoreCase(sheet.trim())) {
						Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet,
								requestId, session);

						int rowIndex = 0;

						final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
						UtilityForPoc pocUtility = new UtilityForPoc();
						pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

						final File file = new File(path);
						InputStream inputStream = new FileInputStream(file);

						try {
							List<POC_Impacted_Variant> impactedVariantList = new ArrayList<>();
							StreamingReader impactedVariantReader = StreamingReader.builder().rowCacheSize(1002)
									.bufferSize(1024).sheetName(sheet).read(inputStream);

							if (impactedVariantReader != null) {
								for (Row row : impactedVariantReader) {

									if (!AppGenUtility.isRowEmpty(row)) {
										if (row.getRowNum() > rowIndex) {
											POC_Impacted_Variant pocImpactedVariant = migrationSheet
													.getImpactedVariant(row, requestId, sheet);
											if (pocImpactedVariant != null) {
												impactedVariantList.add(pocImpactedVariant);
											}
										}
									}
								}

								if (impactedVariantList != null && !impactedVariantList.isEmpty()) {
									detailReportJDBCBatchInsertUpdate.pocImpactedVariantInsert(impactedVariantList,
											session);
								} else {
									logger.info("Impacted Variant List is null");
								}

								logger.info("POC  :::::::::: READING AND PERSISTING DONE");
							}
						} finally {
							IOUtils.closeQuietly(inputStream);
						}
					}

					else if (sheet != null && POC_Upload_Constant.POC_NON_UNICODE.equalsIgnoreCase(sheet.trim())) {
						Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet,
								requestId, session);

						int rowIndex = 0;

						final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
						UtilityForPoc pocUtility = new UtilityForPoc();
						pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

						final File file = new File(path);
						InputStream inputStream = new FileInputStream(file);

						try {
							List<POC_NonUnicodeObjects> nonUnicodeList = new ArrayList<>();
							StreamingReader impactedVariantReader = StreamingReader.builder().rowCacheSize(1002)
									.bufferSize(1024).sheetName(sheet).read(inputStream);

							if (impactedVariantReader != null) {
								for (Row row : impactedVariantReader) {

									if (!AppGenUtility.isRowEmpty(row)) {
										if (row.getRowNum() > rowIndex) {
											POC_NonUnicodeObjects pocNonUnicode = migrationSheet
													.getNonUnicodeObjectsPoc(row, requestId, sheet);
											if (pocNonUnicode != null) {
												nonUnicodeList.add(pocNonUnicode);
											}
										}
									}
								}

								if (nonUnicodeList != null && !nonUnicodeList.isEmpty()) {
									detailReportJDBCBatchInsertUpdate.pocNonUnicodeObjectsInsert(nonUnicodeList,
											session);
								} else {
									logger.info("Non Unicode List is null");
								}

								logger.info("POC Non Unicode :::::::::: READING AND PERSISTING DONE");
							}
						} finally {
							IOUtils.closeQuietly(inputStream);
						}
					}

					else if (sheet != null && POC_Upload_Constant.POC_CVITROUTPUT.equalsIgnoreCase(sheet.trim())) {
						/*
						 * pocSheetProcessingCVITROutputList(path, requestId,
						 * session, logger, migrationSheet,
						 * detailReportJDBCBatchInsertUpdate, sheet);
						 */
					}

					else if (sheet != null && POC_Upload_Constant.POC_BWINVENTORY.equalsIgnoreCase(sheet.trim())) {
						pocSheetProcessingBWInventoryList(path, requestId, session, migrationSheet, sheet);
					}

					else if (sheet != null && POC_Upload_Constant.POC_FIORIOUTPUT.equalsIgnoreCase(sheet.trim())) {
						pocSheetProcessingFioriOutputList(path, requestId, session, migrationSheet, sheet);
					}

					else if (sheet != null
							&& POC_Upload_Constant.POC_BW_CLEANUPUTILITY.equalsIgnoreCase(sheet.trim())) {
						pocSheetProcessingBWCleanUpList(path, requestId, session, migrationSheet, sheet);
					}

					else if (sheet != null
							&& POC_Upload_Constant.POC_IMPACTEDCUSTOM_TABLE.equalsIgnoreCase(sheet.trim())) {
						pocSheetProcessingImpactedCustomTableList(path, requestId, session, migrationSheet, sheet);
					}

					else if (sheet != null
							&& POC_Upload_Constant.POC_BWSTANDARD_EXTRACT.equalsIgnoreCase(sheet.trim())) {
						pocSheetProcessingBWStandardExList(path, requestId, session, migrationSheet, sheet);
					}

					else if (sheet != null && POC_Upload_Constant.POC_INACTIVEOBJECTS.equalsIgnoreCase(sheet.trim())) {
						pocSheetProcessingInactiveObjList(path, requestId, session, migrationSheet, sheet);
					}

					else if (sheet != null && POC_Upload_Constant.POC_DRILLDOWNREPORT.equalsIgnoreCase(sheet.trim())) {
						pocSheetProcessingDrillDownReportList(path, requestId, session, migrationSheet, sheet);
					}
				}
			}
		} catch (Exception e) {
			logger.error("Error while reading Final File Report from POC : ", e);
			throw new Exception();
		}
	}

	private void readSIAFinalReport(String path, long requestId, Set<String> sheetNameSet, HttpSession session,
			MigrationPOCReader migrationSheet) throws Exception {
		try {
			String sheet = POC_Upload_Constant.POC_SECANALYZER_TCD_REPORT;
			if (sheetNameSet.contains(sheet)) {
				Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet, requestId,
						session);

				int rowIndex = 0;

				Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
				new UtilityForPoc().getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

				InputStream inputStream = new FileInputStream(new File(path));

				try {
					List<POC_SecAnalyzerTCDReport> secAnalyzerTCDList = new ArrayList<>();
					StreamingReader secAnalyzerTCDReader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024)
							.sheetName(sheet).read(inputStream);

					if (secAnalyzerTCDReader != null) {
						for (Row row : secAnalyzerTCDReader) {

							if (!AppGenUtility.isRowEmpty(row)) {
								if (row.getRowNum() > rowIndex) {
									POC_SecAnalyzerTCDReport pocSecAnalyzerTCD = migrationSheet
											.getSecAnalyzerTCDdataPOC(row, requestId, sheet);
									if (pocSecAnalyzerTCD != null) {
										secAnalyzerTCDList.add(pocSecAnalyzerTCD);
									}
								}
							}
						}

						if (CollectionUtils.isNotEmpty(secAnalyzerTCDList)) {
							detailReportJDBCBatchInsertUpdate.pocSecAnalyzerTCDDataInsert(secAnalyzerTCDList, session);
						} else {
							logger.info("Security Analyzer TCD List is empty ...");
						}

						logger.info("POC Security Analyzer TCD Report - READING AND PERSISTING DONE");
					}
				} finally {
					IOUtils.closeQuietly(inputStream);
				}
			}
		} catch (Exception e) {
			logger.error("Error while reading Security Analyzer TCD Report from POC : ", e);
			throw new Exception();
		}
	}

	private void getImpactedBackgroundJobPoc(final String path, final long requestId, HttpSession session,
			final Logger logger, MigrationPOCReader migrationSheet,
			FinalFileUploadDaoImpl detailReportJDBCBatchInsertUpdate, String sheet)
			throws URISyntaxException, IOException, FileNotFoundException, SQLException {
		Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet, requestId, session);

		int rowIndex = 0;

		final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
		UtilityForPoc pocUtility = new UtilityForPoc();
		pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

		final File file = new File(path);
		InputStream inputStream = new FileInputStream(file);

		try {
			List<POC_ImpactedBackgroundJob> pocImpactedBackgroundJobList = new ArrayList<POC_ImpactedBackgroundJob>();
			StreamingReader pocImpactedBackgroundJobreader = StreamingReader.builder().rowCacheSize(1002)
					.bufferSize(1024).sheetName(sheet).read(inputStream);

			if (pocImpactedBackgroundJobreader != null) {
				for (Row row : pocImpactedBackgroundJobreader) {

					if (!AppGenUtility.isRowEmpty(row)) {
						rowIndex = Integer.parseInt(
								POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(sheet).get("Object"));
						if (row.getRowNum() > rowIndex) {
							POC_ImpactedBackgroundJob pocImpactedBackgroundJob = migrationSheet
									.getImpactedBackgroundJobValueXlsx(row, requestId, sheet);
							if (pocImpactedBackgroundJob != null) {
								pocImpactedBackgroundJobList.add(pocImpactedBackgroundJob);
							}
						}
					}
				}

				if (pocImpactedBackgroundJobList != null && !pocImpactedBackgroundJobList.isEmpty()) {
					detailReportJDBCBatchInsertUpdate
							.pocImpactedBackgroundJobBatchInsertUpdate(pocImpactedBackgroundJobList, session);
				} else {
					logger.info("Impacted_Background_Job List is null");
				}

				logger.info("POC_ImpactedBackgroundJob :::::::::: READING AND PERSISTING DONE");
			}
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
	}

	private void getImpactedDueToDBChangePoc(String path, long requestId, HttpSession session,
			MigrationPOCReader migrationSheet, String sheet)
			throws URISyntaxException, IOException, FileNotFoundException, SQLException {
		Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet, requestId, session);

		int rowIndex = 0;

		final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
		UtilityForPoc pocUtility = new UtilityForPoc();
		pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

		final File file = new File(path);
		InputStream inputStream = new FileInputStream(file);

		try {
			List<POC_DR_DB_Change> hanaDataList = new ArrayList<POC_DR_DB_Change>();
			StreamingReader hanaDataListreader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024)
					.sheetName(sheet).read(inputStream);

			if (hanaDataListreader != null) {
				for (Row row : hanaDataListreader) {

					if (!AppGenUtility.isRowEmpty(row)) {
						if (row.getRowNum() > rowIndex) {
							POC_DR_DB_Change hanaData = migrationSheet.getFinalOutputValueXlsx(row, requestId, sheet);
							if (hanaData != null) {
								hanaDataList.add(hanaData);
							}
						}
					}
				}

				if (hanaDataList != null && !hanaDataList.isEmpty()) {
					detailReportJDBCBatchInsertUpdate.pocFinalOutputBatchInsertUpdate(hanaDataList, session);
				} else {
					logger.info("DR_DB Change List is null");
				}

				logger.info("POC_DR_DB_Change :::::::::: READING AND PERSISTING DONE");
			}
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
	}

	private void getImpactedObjectListPoc(String path, long requestId, HttpSession session,
			MigrationPOCReader migrationSheet, String sheet)
			throws URISyntaxException, IOException, FileNotFoundException, SQLException {
		Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet, requestId, session);

		int rowIndex = 0;

		final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
		UtilityForPoc pocUtility = new UtilityForPoc();
		pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

		final File file = new File(path);
		InputStream inputStream = new FileInputStream(file);

		try {
			List<POC_ImpactedObjectList> impactedObjList = new ArrayList<POC_ImpactedObjectList>();
			StreamingReader impactedObjListreader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024)
					.sheetName(sheet).read(inputStream);

			if (impactedObjListreader != null) {
				for (Row row : impactedObjListreader) {

					if (!AppGenUtility.isRowEmpty(row)) {
						if (row.getRowNum() > rowIndex) {
							POC_ImpactedObjectList impactedObj = migrationSheet.getImpactedObjListValueXlsx(row,
									requestId, sheet);
							if (impactedObj != null) {
								impactedObjList.add(impactedObj);
							}
						}
					}
				}

				if (impactedObjList != null && !impactedObjList.isEmpty()) {
					detailReportJDBCBatchInsertUpdate.pocImpactedObjListBatchInsertUpdate(impactedObjList, session);
				} else {
					logger.info("Impacted Object List is null");
				}

				logger.info("POC_ImpactedObjectList :::::::::: READING AND PERSISTING DONE");
			}
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
	}

	private void pocSheetProcessingBusinessLogicInventoryList(String path, long requestId, HttpSession session,
			MigrationPOCReader migrationSheet, String sheet)
			throws URISyntaxException, IOException, FileNotFoundException, SQLException {
		Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet, requestId, session);

		int rowIndex = 0;

		final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
		UtilityForPoc pocUtility = new UtilityForPoc();
		pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

		final File file = new File(path);
		InputStream inputStream = new FileInputStream(file);

		try {
			List<InventoryListPOC> pocInventoryList = new ArrayList<InventoryListPOC>();
			StreamingReader inventoryListreader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024)
					.sheetName(sheet).read(inputStream);

			if (inventoryListreader != null) {
				for (Row row : inventoryListreader) {

					if (!AppGenUtility.isRowEmpty(row)) {
						if (row.getRowNum() > rowIndex) {
							InventoryListPOC pocInventory = migrationSheet.getInventoryValueXlsx(row, requestId, sheet);
							if (pocInventory != null) {
								pocInventoryList.add(pocInventory);
							}
						}
					}
				}

				if (pocInventoryList != null && !pocInventoryList.isEmpty()) {
					detailReportJDBCBatchInsertUpdate.pocInventoryBatchInsertUpdate(pocInventoryList, session);
				} else {
					logger.info("Inventory List is null");
				}

				logger.info("InventoryListPOC :::::::::: READING AND PERSISTING DONE");
			}
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
	}

	private void pocFileProcessingBusinessLogicAuctUpgrade(String path, long requestId, HttpSession session,
			MigrationPOCReader migrationSheet, String sheet)
			throws URISyntaxException, IOException, FileNotFoundException, SQLException {
		Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet, requestId, session);

		int rowIndex = 0;

		final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
		UtilityForPoc pocUtility = new UtilityForPoc();
		pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

		final File file = new File(path);
		InputStream inputStream = new FileInputStream(file);

		try {
			List<POC_DR_ExistingErrors> auctList = new ArrayList<POC_DR_ExistingErrors>();
			StreamingReader auctListreader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024)
					.sheetName(sheet).read(inputStream);

			if (auctListreader != null) {
				for (Row row : auctListreader) {

					if (!AppGenUtility.isRowEmpty(row)) {
						if (row.getRowNum() > rowIndex) {
							POC_DR_ExistingErrors auct = migrationSheet.getAUCTValueXlsx(row, requestId, sheet);
							if (auct != null) {
								auctList.add(auct);
							}
						}
					}
				}

				if (auctList != null && !auctList.isEmpty()) {
					detailReportJDBCBatchInsertUpdate.pocAUCTBatchInsertUpdate(auctList, session);
				} else {
					logger.info("AUCT/Upgrade List is null");
				}

				logger.info("POC_DR_ExistingErrors :::::::::: READING AND PERSISTING DONE");
			}
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
	}

	private void pocFileProcessingBusinessLogicUI5(String path, long requestId, HttpSession session,
			MigrationPOCReader migrationSheet, String sheet)
			throws URISyntaxException, IOException, FileNotFoundException, SQLException {
		Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet, requestId, session);

		int rowIndex = 0;

		final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
		UtilityForPoc pocUtility = new UtilityForPoc();
		pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

		final File file = new File(path);
		InputStream inputStream = new FileInputStream(file);

		try {
			List<POC_Ui5FinalOutput> ui5FinalOutputList = new ArrayList<POC_Ui5FinalOutput>();
			StreamingReader ui5FinalOutputListreader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024)
					.sheetName(sheet).read(inputStream);

			if (ui5FinalOutputListreader != null) {
				for (Row row : ui5FinalOutputListreader) {

					if (!AppGenUtility.isRowEmpty(row)) {
						rowIndex = Integer.parseInt(
								POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(sheet).get("UI.Element"));
						if (row.getRowNum() > rowIndex) {
							POC_Ui5FinalOutput ui5FinalOutput = migrationSheet.getUI5FinalOutputListValueXlsx(row,
									requestId, sheet);
							if (ui5FinalOutput != null) {
								ui5FinalOutputList.add(ui5FinalOutput);
							}
						}
					}
				}

				if (ui5FinalOutputList != null && !ui5FinalOutputList.isEmpty()) {
					detailReportJDBCBatchInsertUpdate.pocUI5FinalOutputBatchInsertUpdate(ui5FinalOutputList, session);
				} else {
					logger.info("UI5_Final_Output List is null");
				}

				logger.info("POC_Ui5FinalOutput :::::::::: READING AND PERSISTING DONE");
			}

		} finally {
			IOUtils.closeQuietly(inputStream);
		}
	}

	private void pocFileProcessingBusinessLogicUI5HighLevel(String path, long requestId, HttpSession session,
			MigrationPOCReader migrationSheet, String sheet)
			throws URISyntaxException, IOException, FileNotFoundException, SQLException {
		Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet, requestId, session);

		int rowIndex = 0;

		final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
		UtilityForPoc pocUtility = new UtilityForPoc();
		pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

		final File file = new File(path);
		InputStream inputStream = new FileInputStream(file);

		try {
			List<POC_Ui5HighLevelReport> pocUi5HighLevelReportList = new ArrayList<POC_Ui5HighLevelReport>();
			StreamingReader pocUi5HighLevelReportListreader = StreamingReader.builder().rowCacheSize(1002)
					.bufferSize(1024).sheetName(sheet).read(inputStream);

			if (pocUi5HighLevelReportListreader != null) {
				for (Row row : pocUi5HighLevelReportListreader) {

					if (!AppGenUtility.isRowEmpty(row)) {
						rowIndex = Integer.parseInt(
								POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(sheet).get("Project.Name"));
						if (row.getRowNum() > rowIndex) {
							POC_Ui5HighLevelReport pocUi5HighLevelReport = migrationSheet
									.getUi5HighLevelReportValueXlsx(row, requestId, sheet);
							if (pocUi5HighLevelReport != null) {
								pocUi5HighLevelReportList.add(pocUi5HighLevelReport);
							}
						}
					}
				}

				if (pocUi5HighLevelReportList != null && !pocUi5HighLevelReportList.isEmpty()) {
					detailReportJDBCBatchInsertUpdate.pocUi5HighLevelReportBatchInsertUpdate(pocUi5HighLevelReportList,
							session);
				} else {
					logger.info("UI5_High_Level List is null");
				}

				logger.info("POC_Ui5HighLevelReport :::::::::: READING AND PERSISTING DONE");
			}
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
	}

	public Map<String, String> getSheetNameScopeBasedFromPropFile(String fileName) {
		Properties property = new Properties();
		Map<String, String> requiredColumnMap1 = new HashMap<String, String>();
		try {
			Path pocFolderPath = Paths
					.get(UtilityForPoc.class.getClassLoader().getResource("POCUploadDetailReport_Properties").toURI());

			String pocPropertySheetsPath = pocFolderPath.toString();
			File[] listFiles = new File(pocPropertySheetsPath).listFiles();

			for (File currentFile : listFiles) {
				if (currentFile.getName().toLowerCase().contains(fileName.toLowerCase())) {
					InputStream inputStream = new FileInputStream(currentFile);
					property.load(inputStream);
					requiredColumnMap1 = UtilityForPoc.getRequiredColumnForPOCProperties(currentFile, property);
					inputStream.close();

				}
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return requiredColumnMap1;

	}

	private void pocSheetCI(final String path, final long requestId, HttpSession session, final Logger logger,
			MigrationPOCReader migrationSheet, FinalFileUploadDaoImpl detailReportJDBCBatchInsertUpdate, String sheet)
			throws URISyntaxException, IOException, FileNotFoundException, SQLException {
		Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet, requestId, session);
		int rowIndex = 0;
		final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
		UtilityForPoc pocUtility = new UtilityForPoc();
		pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);
		final File file = new File(path);

		InputStream inputStream = new FileInputStream(file);

		try {
			List<InventoryListPOC> pocInventoryList = new ArrayList<InventoryListPOC>();
			StreamingReader inventoryListreader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024)
					.sheetName(sheet).read(inputStream);

			if (inventoryListreader != null) {
				for (Row row : inventoryListreader) {

					if (!AppGenUtility.isRowEmpty(row)) {
						if (row.getRowNum() > rowIndex) {
							InventoryListPOC pocInventory = migrationSheet.getInventoryValueXlsx(row, requestId, sheet);
							if (pocInventory != null) {
								pocInventoryList.add(pocInventory);
							}
						}
					}
				}
				if (pocInventoryList != null && !pocInventoryList.isEmpty()) {
					detailReportJDBCBatchInsertUpdate.pocInventoryBatchInsertUpdate(pocInventoryList, session);
				} else {
					logger.info("Inventory List is null");
				}
				logger.info("InventoryListPOC :::::::::: READING AND PERSISTING DONE");

			}
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
	}

	private void pocSheetProcessingCVITROutputList(final String path, final long requestId, HttpSession session,
			final Logger logger, MigrationPOCReader migrationSheet,
			FinalFileUploadDaoImpl detailReportJDBCBatchInsertUpdate, String sheet)
			throws URISyntaxException, IOException, FileNotFoundException, SQLException {
		Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet, requestId, session);
		int rowIndex = 0;
		final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
		UtilityForPoc pocUtility = new UtilityForPoc();
		pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);
		final File file = new File(path);

		InputStream inputStream = new FileInputStream(file);

		try {
			List<POC_CVITROutput> cvitrOutputList = new ArrayList<POC_CVITROutput>();
			StreamingReader cvitListreader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024)
					.sheetName(sheet).read(inputStream);

			if (cvitListreader != null) {
				for (Row row : cvitListreader) {

					if (!AppGenUtility.isRowEmpty(row)) {
						if (row.getRowNum() > rowIndex) {
							POC_CVITROutput pocCVIT = migrationSheet.getCVITROutput(row, requestId, sheet);
							if (pocCVIT != null) {
								cvitrOutputList.add(pocCVIT);
							}
						}
					}
				}
				if (cvitrOutputList != null && !cvitrOutputList.isEmpty()) {
					detailReportJDBCBatchInsertUpdate.pocCVITRBatchInsertUpdate(cvitrOutputList, session);
				} else {
					logger.info("CVITR List is null");
				}
				logger.info("CVITR List POC :::::::::: READING AND PERSISTING DONE");

			}
		} finally {
			IOUtils.closeQuietly(inputStream);
		}

	}

	private void pocSheetProcessingBWInventoryList(String path, long requestId, HttpSession session,
			MigrationPOCReader migrationSheet, String sheet)
			throws URISyntaxException, IOException, FileNotFoundException, SQLException {
		Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet, requestId, session);

		int rowIndex = 0;

		final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
		UtilityForPoc pocUtility = new UtilityForPoc();
		pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

		final File file = new File(path);
		InputStream inputStream = new FileInputStream(file);

		try {
			List<POC_BWInventory> bwInventoryList = new ArrayList<POC_BWInventory>();
			StreamingReader bwInventoryListreader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024)
					.sheetName(sheet).read(inputStream);

			if (bwInventoryListreader != null) {
				for (Row row : bwInventoryListreader) {

					if (!AppGenUtility.isRowEmpty(row)) {
						if (row.getRowNum() > rowIndex) {
							POC_BWInventory pocBWInventory = migrationSheet.getBWInventory(row, requestId, sheet);
							if (pocBWInventory != null) {
								bwInventoryList.add(pocBWInventory);
							}
						}
					}
				}

				if (bwInventoryList != null && !bwInventoryList.isEmpty()) {
					detailReportJDBCBatchInsertUpdate.pocBWInventoryBatchInsertUpdate(bwInventoryList, session);
				} else {
					logger.info("BW Inventory List is null");
				}

				logger.info("BW Inventory List POC :::::::::: READING AND PERSISTING DONE");
			}
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
	}

	private void pocSheetProcessingFioriOutputList(String path, long requestId, HttpSession session,
			MigrationPOCReader migrationSheet, String sheet)
			throws URISyntaxException, IOException, FileNotFoundException, SQLException {
		Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet, requestId, session);

		int rowIndex = 0;

		final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
		UtilityForPoc pocUtility = new UtilityForPoc();
		pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

		final File file = new File(path);
		InputStream inputStream = new FileInputStream(file);

		try {
			List<POC_FioriOutput> fioriOutputList = new ArrayList<POC_FioriOutput>();
			StreamingReader fioriOutputListreader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024)
					.sheetName(sheet).read(inputStream);

			if (fioriOutputListreader != null) {
				for (Row row : fioriOutputListreader) {

					if (!AppGenUtility.isRowEmpty(row)) {
						if (row.getRowNum() > rowIndex) {
							POC_FioriOutput pocFioriOutput = migrationSheet.getFioriOutput(row, requestId, sheet);
							if (pocFioriOutput != null) {
								fioriOutputList.add(pocFioriOutput);
							}
						}
					}
				}

				if (fioriOutputList != null && !fioriOutputList.isEmpty()) {
					detailReportJDBCBatchInsertUpdate.pocFIORIOutputBatchInsertUpdate(fioriOutputList, session);
				} else {
					logger.info("Fiori Output List is null");
				}

				logger.info("Fiori Output List POC :::::::::: READING AND PERSISTING DONE");
			}
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
	}

	private void pocSheetProcessingBWCleanUpList(String path, long requestId, HttpSession session,
			MigrationPOCReader migrationSheet, String sheet)
			throws URISyntaxException, IOException, FileNotFoundException, SQLException {
		Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet, requestId, session);

		int rowIndex = 0;

		final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
		UtilityForPoc pocUtility = new UtilityForPoc();
		pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

		final File file = new File(path);
		InputStream inputStream = new FileInputStream(file);

		try {
			List<POC_BWCleanUpUtility> bwCleanUpList = new ArrayList<POC_BWCleanUpUtility>();
			StreamingReader bwCleanUpListreader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024)
					.sheetName(sheet).read(inputStream);

			if (bwCleanUpListreader != null) {
				for (Row row : bwCleanUpListreader) {

					if (!AppGenUtility.isRowEmpty(row)) {
						if (row.getRowNum() > rowIndex) {
							POC_BWCleanUpUtility pocBWCleanUp = migrationSheet.getBWCleanUpUtil(row, requestId, sheet);
							if (pocBWCleanUp != null) {
								bwCleanUpList.add(pocBWCleanUp);
							}
						}
					}
				}

				if (bwCleanUpList != null && !bwCleanUpList.isEmpty()) {
					detailReportJDBCBatchInsertUpdate.pocBWClanUpBatchInsertUpdate(bwCleanUpList, session);
				} else {
					logger.info("BW Clean up util List is null");
				}

				logger.info("BW Clean up util List POC :::::::::: READING AND PERSISTING DONE");
			}
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
	}

	private void pocSheetProcessingImpactedCustomTableList(String path, long requestId, HttpSession session,
			MigrationPOCReader migrationSheet, String sheet)
			throws URISyntaxException, IOException, FileNotFoundException, SQLException {
		Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet, requestId, session);

		int rowIndex = 0;

		final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
		UtilityForPoc pocUtility = new UtilityForPoc();
		pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

		final File file = new File(path);
		InputStream inputStream = new FileInputStream(file);

		try {
			List<POC_ImpactedCustomTable> impactedCustomTableList = new ArrayList<POC_ImpactedCustomTable>();
			StreamingReader impactedCusTablListreader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024)
					.sheetName(sheet).read(inputStream);

			if (impactedCusTablListreader != null) {
				for (Row row : impactedCusTablListreader) {

					if (!AppGenUtility.isRowEmpty(row)) {
						if (row.getRowNum() > rowIndex) {
							POC_ImpactedCustomTable pocImpactedCusTabl = migrationSheet.getImpactedCustomTable(row,
									requestId, sheet);
							if (pocImpactedCusTabl != null) {
								impactedCustomTableList.add(pocImpactedCusTabl);
							}
						}
					}
				}

				if (impactedCustomTableList != null && !impactedCustomTableList.isEmpty()) {
					detailReportJDBCBatchInsertUpdate.pocImpactedCustomTableBatchInsertUpdate(impactedCustomTableList,
							session);
				} else {
					logger.info("Impacted custom table List is null");
				}

				logger.info("Impacted custom table List POC :::::::::: READING AND PERSISTING DONE");
			}
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
	}

	private void pocSheetProcessingBWStandardExList(String path, long requestId, HttpSession session,
			MigrationPOCReader migrationSheet, String sheet)
			throws URISyntaxException, IOException, FileNotFoundException, SQLException {
		Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet, requestId, session);

		int rowIndex = 0;

		final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
		UtilityForPoc pocUtility = new UtilityForPoc();
		pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

		final File file = new File(path);
		InputStream inputStream = new FileInputStream(file);

		try {
			List<POC_BWStandardExtract> bwStandExList = new ArrayList<POC_BWStandardExtract>();
			StreamingReader bwStandExListreader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024)
					.sheetName(sheet).read(inputStream);

			if (bwStandExListreader != null) {
				for (Row row : bwStandExListreader) {

					if (!AppGenUtility.isRowEmpty(row)) {
						if (row.getRowNum() > rowIndex) {
							POC_BWStandardExtract pocBWStandEx = migrationSheet.getBwStandardExtract(row, requestId,
									sheet);
							if (pocBWStandEx != null) {
								bwStandExList.add(pocBWStandEx);
							}
						}
					}
				}

				if (bwStandExList != null && !bwStandExList.isEmpty()) {
					detailReportJDBCBatchInsertUpdate.pocBWStandardExBatchInsertUpdate(bwStandExList, session);
				} else {
					logger.info("BW standard extract List is null");
				}

				logger.info("BW standard extract List POC :::::::::: READING AND PERSISTING DONE");
			}
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
	}

	private void pocSheetProcessingInactiveObjList(String path, long requestId, HttpSession session,
			MigrationPOCReader migrationSheet, String sheet)
			throws URISyntaxException, IOException, FileNotFoundException, SQLException {
		Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet, requestId, session);

		int rowIndex = 0;

		final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
		UtilityForPoc pocUtility = new UtilityForPoc();
		pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

		final File file = new File(path);
		InputStream inputStream = new FileInputStream(file);

		try {
			List<POC_InactiveObjects> inactiveObjList = new ArrayList<POC_InactiveObjects>();
			StreamingReader inactiveObjListreader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024)
					.sheetName(sheet).read(inputStream);

			if (inactiveObjListreader != null) {
				for (Row row : inactiveObjListreader) {

					if (!AppGenUtility.isRowEmpty(row)) {
						if (row.getRowNum() > rowIndex) {
							POC_InactiveObjects pocInactiveObj = migrationSheet.getInactiveObject(row, requestId,
									sheet);
							if (pocInactiveObj != null) {
								inactiveObjList.add(pocInactiveObj);
							}
						}
					}
				}
				if (inactiveObjList != null && !inactiveObjList.isEmpty()) {
					detailReportJDBCBatchInsertUpdate.pocInactiveObjectsBatchInsertUpdate(inactiveObjList, session);
				} else {
					logger.info("Inactive object List is null");
				}

				logger.info("Inactive object List POC :::::::::: READING AND PERSISTING DONE");
			}
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
	}

	/* Writing Files at Server Location - Upload */
	public void writeFile(long requestId, String clientName, String filePath, MultipartFile[] files) throws Exception {

		for (MultipartFile file : files) {
			try {
				filename = file.getOriginalFilename();
				FileUtility.chckUploadFilesAlphaNum(filename);

				if (!filename.toUpperCase().endsWith("XLSX") || !filename.toUpperCase().endsWith("XLS")) {
					logger.error("Please upload the file with '.xlsx' extension only !!!");
				}

				// Check if any file already exists in directory. If yes, delete
				// it
				File directory = new File(filePath);
				if (directory.exists()) {
					FileUtils.cleanDirectory(directory);
				}
				if (StringUtils.isNotEmpty(filename) && !"".equals(filename)) {
					String extension = Hana_Profiler_Constant.XLSX_EXTENSTION_CONSTANT;
					String fileExtension = filename.substring(filename.length() - extension.length(),
							filename.length());

					if (extension.equalsIgnoreCase(fileExtension)) {
						logger.info("Matched Extension - .xlsx");
						filename = filename.toUpperCase();
						byte[] bytes = file.getBytes();
						Path path = Paths.get(filePath + File.separator + filename);
						Files.write(path, bytes);
						logger.info("Wrote in file path");
					}
				}
			} catch (FileNotFoundException exception) {
				logger.error("Excel File to be read" + filename + " was not found. ", exception);
				throw new Exception();
			}
		}
	}

	private void pocSheetProcessingDrillDownReportList(String path, long requestId, HttpSession session,
			MigrationPOCReader migrationSheet, String sheet)
			throws URISyntaxException, IOException, FileNotFoundException, SQLException {
		Map<String, String> fileColumnAndIndex = migrationSheet.validateXlsxFiles(path, sheet, requestId, session);

		int rowIndex = 0;

		final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(sheet.trim());
		UtilityForPoc pocUtility = new UtilityForPoc();
		pocUtility.getFileColumnReaderForPOC(requiredColumnMap, fileColumnAndIndex, sheet, requestId);

		final File file = new File(path);
		InputStream inputStream = new FileInputStream(file);

		try {
			List<POC_DrillDownReport> drillDownRprtList = new ArrayList<POC_DrillDownReport>();
			StreamingReader drillDownRprtReader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024)
					.sheetName(sheet).read(inputStream);

			if (drillDownRprtReader != null) {
				for (Row row : drillDownRprtReader) {

					if (!AppGenUtility.isRowEmpty(row)) {
						if (row.getRowNum() > rowIndex) {
							POC_DrillDownReport pocDrillDownReprt = migrationSheet.getDrillDownReportValues(row,
									requestId, sheet);
							if (pocDrillDownReprt != null) {
								drillDownRprtList.add(pocDrillDownReprt);
							}
						}
					}
				}
				if (CollectionUtils.isNotEmpty(drillDownRprtList)) {
					detailReportJDBCBatchInsertUpdate.pocDrillDownRprtBatchInsert(drillDownRprtList, session);
				} else {
					logger.info("DrillDown Report List is null");
				}

				logger.info("DrillDown Report List POC :::::::::: READING AND PERSISTING DONE");
			}
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
	}
}
