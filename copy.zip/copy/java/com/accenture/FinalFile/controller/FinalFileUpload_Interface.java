package com.accenture.FinalFile.controller;

import java.io.IOException;
import java.net.URISyntaxException;
import java.sql.SQLException;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.poi.openxml4j.exceptions.OpenXML4JException;

import com.accenture.client.model.RequestForm;

public interface FinalFileUpload_Interface {
	public String readMigrationSheetData(String path, long requestId, RequestForm requestForm, HttpSession session, 
			Map<String, String> fileMap) throws URISyntaxException, SQLException, IOException, OpenXML4JException, Exception;
}