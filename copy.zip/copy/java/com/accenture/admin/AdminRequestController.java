package com.accenture.admin;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.accenture.constant.Hana_Profiler_Constant;

@Controller
public class AdminRequestController {

	private final long nOfRecordsPerPage = 10;

	@RequestMapping(value = { "admin/topContributor/{iG}/{sIG}/{assmType}/{dur}",
			"admin/topContributor" }, method = { RequestMethod.POST, RequestMethod.GET })
	public String toTopContributor(@RequestParam("iG") Optional<String> iG, @RequestParam("sIG") Optional<String> sIG,
			@RequestParam("assmType") Optional<String> assmType, @RequestParam("dur") Optional<Integer> dur,
			Model model, HttpServletRequest request, HttpServletResponse response, HttpSession session)
			throws Exception {
		if (iG.isPresent()) {
			model.addAttribute("iG", iG.get()); // Industry Group
		} else {
			model.addAttribute("iG", ""); // Industry Group Default
		}
		if (sIG.isPresent()) {
			model.addAttribute("sIG", sIG.get()); // Sub-Industry Group
		} else {
			model.addAttribute("sIG", ""); // Sub-Industry Group Default
		}
		if (assmType.isPresent()) {
			model.addAttribute("assmType", assmType.get()); // Assessment Type
		} else {
			model.addAttribute("assmType", ""); // Assessment Type Default
		}
		if (dur.isPresent()) {
			model.addAttribute("dur", dur.get()); // Assement Duration
		} else {
			model.addAttribute("dur", new Integer(0)); // Assement Duration Default
		}

		// Below Data will change upon Query
		Map<String, Integer> assmntChart = new LinkedHashMap<String, Integer>();
		assmntChart.put("S4 SOH", 90);
		assmntChart.put("Hana", 65);
		assmntChart.put("Fiat", 40);

		model.addAttribute("chartData", assmntChart);

		// static List to be populated on the drop-downs.
		model.addAttribute("iGList", getIGList());
		model.addAttribute("sIGList", getSubIGList());
		model.addAttribute("assessmentTypeList", getAssessmentTypeList());
		model.addAttribute("durationMap", getDurationMap());
		model.addAttribute("nOfRecordsPerPage", nOfRecordsPerPage);

		return "admin/topContributor";
	}

	public Map<String, Integer> getDurationMap() {
		Map<String, Integer> durMap = new LinkedHashMap<String, Integer>();

		durMap.put("Last Month", 1);
		durMap.put("Last 3 Months", 3);
		durMap.put("Last 6 Months", 6);

		return durMap;
	}

	public List<String> getAssessmentTypeList() {
		List<String> ATList = new ArrayList<String>();
		ATList.add("S4 Soh");
		ATList.add("Hana");
		ATList.add("Fiat");
		return ATList;
	}

	public List<String> getIGList() {
		List<String> IGList = new ArrayList<String>();
		IGList.add(Hana_Profiler_Constant.IG_CMT);
		IGList.add(Hana_Profiler_Constant.IG_FS);
		IGList.add(Hana_Profiler_Constant.IG_HPS);
		IGList.add(Hana_Profiler_Constant.IG_Product);
		IGList.add(Hana_Profiler_Constant.IG_RS);
		IGList.add("others");

		return IGList;
	}

	public List<String> getSubIGList() {
		List<String> SubIGList = new ArrayList<String>();
		SubIGList.add(Hana_Profiler_Constant.Com);
		SubIGList.add(Hana_Profiler_Constant.EHT);
		SubIGList.add(Hana_Profiler_Constant.ME);
		SubIGList.add(Hana_Profiler_Constant.BCM);
		SubIGList.add(Hana_Profiler_Constant.Ins);
		SubIGList.add(Hana_Profiler_Constant.Health);
		SubIGList.add(Hana_Profiler_Constant.PS);
		SubIGList.add(Hana_Profiler_Constant.CGRTS);
		SubIGList.add(Hana_Profiler_Constant.Industrial);
		SubIGList.add(Hana_Profiler_Constant.LS);
		SubIGList.add(Hana_Profiler_Constant.CNR);
		SubIGList.add(Hana_Profiler_Constant.Energy);
		SubIGList.add(Hana_Profiler_Constant.Utilities);
		SubIGList.add("others");

		return SubIGList;
	}

}
