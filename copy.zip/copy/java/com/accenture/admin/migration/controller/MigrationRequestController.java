package com.accenture.admin.migration.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.accenture.client.model.RequestForm;
import com.accenture.constant.Hana_Profiler_Constant;

@Controller
public class MigrationRequestController {

	@RequestMapping(value = "admin/migration/dashboard", method = RequestMethod.GET)
	public ModelAndView goToMigrationDashboard(ModelMap model) {
		String view = "admin/migration/dashboard";
		ModelAndView modenAndView = null;
		modenAndView = new ModelAndView(view);
		// modenAndView.addObject("ImpactedAbapObjects",
		// reportGraphService.getImpactedAbapObjects());

		return modenAndView;

	}

	@RequestMapping(value = "admin/migration/requestForm", method = RequestMethod.GET)
	public String loadRequestFrom(Model model, HttpSession session) {

		String toolName = (String) session.getAttribute("tool");

		model.addAttribute("ClientRequestForm", new RequestForm());
		// CR-4.0: Adding List to model.
		model.addAttribute("IGList", getIGList());
		model.addAttribute("SubIGList", getSubIGList());
		model.addAttribute("Ui5Version", getUi5Version());
		model.addAttribute("sourceVersionList", getSourceVersion());
		model.addAttribute("targetVersionList", getTargetVersion());
		return "admin/migration/requestForm";

	}

	public List<String> getIGList() {
		List<String> IGList = new ArrayList<String>();
		IGList.add(Hana_Profiler_Constant.IG_CMT);
		IGList.add(Hana_Profiler_Constant.IG_FS);
		IGList.add(Hana_Profiler_Constant.IG_HPS);
		IGList.add(Hana_Profiler_Constant.IG_Product);
		IGList.add(Hana_Profiler_Constant.IG_RS);
		IGList.add("others");

		return IGList;
	}

	public List<String> getSubIGList() {
		List<String> SubIGList = new ArrayList<String>();
		SubIGList.add(Hana_Profiler_Constant.Com);
		SubIGList.add(Hana_Profiler_Constant.EHT);
		SubIGList.add(Hana_Profiler_Constant.ME);
		SubIGList.add(Hana_Profiler_Constant.BCM);
		SubIGList.add(Hana_Profiler_Constant.Ins);
		SubIGList.add(Hana_Profiler_Constant.Health);
		SubIGList.add(Hana_Profiler_Constant.PS);
		SubIGList.add(Hana_Profiler_Constant.CGRTS);
		SubIGList.add(Hana_Profiler_Constant.Industrial);
		SubIGList.add(Hana_Profiler_Constant.LS);
		SubIGList.add(Hana_Profiler_Constant.CNR);
		SubIGList.add(Hana_Profiler_Constant.Energy);
		SubIGList.add(Hana_Profiler_Constant.Utilities);
		SubIGList.add("others");

		return SubIGList;
	}

	public List<String> getSourceVersion() {
		List<String> SourceVersion = new ArrayList<String>();
		SourceVersion.add("4.6C");
		SourceVersion.add("4.7");
		SourceVersion.add("ECC6.0EHP1");
		SourceVersion.add("ECC6.0EHP2");
		SourceVersion.add("ECC6.0EHP3");
		SourceVersion.add("ECC6.0EHP4");
		SourceVersion.add("ECC6.0EHP5");
		SourceVersion.add("ECC6.0EHP6");
		SourceVersion.add("ECC6.0EHP7");
		SourceVersion.add("ECC6.0EHP8");
		SourceVersion.add("S41503");
		SourceVersion.add("S41511");
		SourceVersion.add("S41610");
		SourceVersion.add("S41709");
		return SourceVersion;
	}

	public List<String> getTargetVersion() {
		List<String> TargetVersion = new ArrayList<String>();
		TargetVersion.add("ECC6.0EHP6");
		TargetVersion.add("ECC6.0EHP7");
		TargetVersion.add("ECC6.0EHP8");
		TargetVersion.add("S41503");
		TargetVersion.add("S41511");
		TargetVersion.add("S41610");
		TargetVersion.add("S41709");
		TargetVersion.add("S41809");
		TargetVersion.add("SOH");

		return TargetVersion;
	}

	public List<String> getUi5Version() {
		List<String> Version = new ArrayList<String>();

		Version.add("0.15");
		Version.add("0.17");
		Version.add("1.0");
		Version.add("1.10");
		Version.add("1.11");
		Version.add("1.12");
		Version.add("1.13");
		Version.add("1.14");
		Version.add("1.15");
		Version.add("1.16");
		Version.add("1.17");
		Version.add("1.18");
		Version.add("1.19");
		Version.add("1.1");
		Version.add("1.20");
		Version.add("1.21");
		Version.add("1.22");
		Version.add("1.23");
		Version.add("1.24");
		Version.add("1.25");
		Version.add("1.26");
		Version.add("1.27");
		Version.add("1.28");
		Version.add("1.29");
		Version.add("1.30");
		Version.add("1.31");
		Version.add("1.32");
		Version.add("1.34");
		Version.add("1.36");
		Version.add("1.38");
		Version.add("1.39");
		Version.add("1.40");
		Version.add("1.42");
		Version.add("1.44");
		Version.add("1.45");
		Version.add("1.46");
		Version.add("1.44");
		Version.add("1.48");
		Version.add("1.50");
		Version.add("1.52");
		Version.add("1.3");
		Version.add("1.4");
		Version.add("1.5");
		Version.add("1.6");
		Version.add("1.7");
		Version.add("1.9");
		Version.add("7.20");

		return Version;
	}
}
