package com.accenture.admin.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.accenture.S4.constant.S4HanaProfilerConstant;
import com.accenture.S4.dao.S4ValidationDAO;
import com.accenture.S4.models.FileStore;
import com.accenture.S4.models.FioriRebuildMaster;
import com.accenture.S4.models.GrcMasterdata;
import com.accenture.S4.models.S4ValidationFile;
import com.accenture.S4.models.S4ValidationList;
import com.accenture.S4.models.TCDSimplification;
import com.accenture.S4.models.TarUsobtc;
import com.accenture.bw.model.BwExtractorMaster;
import com.accenture.constant.Hana_Profiler_Constant;
import com.accenture.constant.ST03HanaConstant;
import com.accenture.exceptions.UploadFilesNotValidException;
import com.accenture.fileprocessing.CheckFileListStatus;
import com.accenture.fileprocessing.InitialDataValidation;
import com.accenture.testingscope.model.AppComponentSubProcessTestScript;
import com.accenture.testingscope.model.TCodeSubProcessTestScript;
import com.accenture.utility.FileUtility;
import com.accenture.utility.HANAUtility;
import com.accenture.validator.xlsx.XlsxValidator;
import com.monitorjbl.xlsx.StreamingReader;

@Service
public class AdminSimplificationServiceImpl implements AdminSimplificationService {
	protected final Logger logger = LoggerFactory.getLogger(getClass());
	@Autowired
	private S4ValidationDAO s4ValidDao;

	@Override
	public String adminS4ValidatinUploadList(S4ValidationFile s4ValidationFile, RedirectAttributes redirectAttributes,
			Model model, HttpServletRequest request, HttpSession session, MultipartFile file) throws Exception {
		logger.info(":: adminS4ValidatinUploadList Start ::");
		String fileName="Validation";
		long requestId=0;
		
		HANAUtility.deleteFile(fileName, requestId,null);
		final String filePath = HANAUtility.getFilePath(fileName, requestId);
		logger.info("FilePath::::" +filePath);
		
		String s4ValFilename="";

		logger.info("Inside Initial Data validation method");

		/* File Validation Loop  Validation of files **/	
		try {
				s4ValFilename = file.getOriginalFilename();
				FileUtility.chckUploadFilesAlphaNum(s4ValFilename);
				FileUtility.checkFileSizeByItem(file,"Validation");
				if (StringUtils.isNotEmpty(s4ValFilename) && !"".equals(s4ValFilename)) {
					String extension=Hana_Profiler_Constant.XLSX_EXTENSTION_CONSTANT;
					String fileExtension = s4ValFilename.substring(s4ValFilename.length() - extension.length(), s4ValFilename.length());
					if (extension.equalsIgnoreCase(fileExtension)) {
						logger.info("Matched Extension");
						byte[] bytes = file.getBytes();
						Path path = Paths.get(filePath + File.separator + s4ValFilename);
						Files.write(path, bytes);
						logger.info("Wrote in file path **");
						String statusCreateZip = createZipS4ValidationFile(filePath, s4ValFilename);
						if("Success".equalsIgnoreCase(statusCreateZip)) {
							addS4ValidationFile(filePath, s4ValFilename, session);
							redirectAttributes.addFlashAttribute("message", "Validation File Added Succesfully");
							removeFileAfterAdd(filePath, s4ValFilename);
						}
					} else {
						redirectAttributes.addFlashAttribute("fileException", "Please Upload the file with .xlsx extension only.");
						return "redirect:/admin/simplificationN";
					}
				} else {
					redirectAttributes.addFlashAttribute("fileException", "Please Upload atleast one file.");
					return "redirect:/admin/simplificationN";
				}
			} catch (UploadFilesNotValidException exception) {
				redirectAttributes.addFlashAttribute("fileException", "The filename is not correct.");
				return "redirect:/admin/simplificationN";
			} catch (Exception exception) {
				redirectAttributes.addFlashAttribute("fileException", exception.getMessage());
				return "redirect:/admin/simplificationN";
			}

		String comment = readS4ValidationData((filePath + File.separator + s4ValFilename),requestId,request,session);
		if(comment.equalsIgnoreCase("success")){
			redirectAttributes.addFlashAttribute("message", "File uploaded successfully");
		} else {
			redirectAttributes.addFlashAttribute("fileException", comment);
			return "redirect:/admin/simplificationN";
		}
		logger.info(":: adminS4ValidatinUploadList End ::");
		return "redirect:/admin/simplificationN";	
	}

	@Override
	public String createZipS4ValidationFile(String filePath, String fileName) {
		byte[] buffer = new byte[1024];
		String fileNameSeparated = "";
		try {
			if(StringUtils.isNotBlank(fileName)) {
				String[] fName = fileName.split("\\.");
				fileNameSeparated = fName[0];
			}
			FileOutputStream fos = new FileOutputStream(filePath+ File.separator + fileNameSeparated+".zip");
			ZipOutputStream zos = new ZipOutputStream(fos);
			ZipEntry ze = new ZipEntry(fileName);
			zos.putNextEntry(ze);
			FileInputStream in = new FileInputStream(filePath+ File.separator + fileName);

			int len;
			while ((len = in.read(buffer)) > 0) {
				zos.write(buffer, 0, len);
			}

			in.close();
			zos.closeEntry();

			// remember close it
			zos.close();

			logger.info("Zip Created with name");

		} catch (IOException ex) {
			logger.error("Error in creating validation file Zip :: ", ex);
			return null;
		}

		return "Success";
	}

	@Override
	public void addS4ValidationFile(String filePath, String fileName, HttpSession session) {
		byte[] zipContent = null;
		S4ValidationFile s4ValidationFile = new S4ValidationFile();
		String[] separatedFileName = fileName.split("\\.");
		try {
			zipContent = convertFileContentToByteArray(filePath+ File.separator + separatedFileName[0]+".zip");
			s4ValidationFile.setValidationFile(zipContent);
			s4ValidationFile.setValidationFileName(separatedFileName[0]+".zip");
			int maxId = s4ValidDao.getS4ValidationMaxID();
			String s4ValVersion="V"+maxId;
			s4ValidationFile.setValidationVersion(s4ValVersion);
			s4ValidDao.saveS4ValidationFile(s4ValidationFile);
			
		} catch (Exception e ) {
			logger.error("Error in inserting validation file :: ", e);
		}
		
	}
	
	public byte[] convertFileContentToByteArray(String filePath) throws IOException {
		File file = new File(filePath);
		  byte[] bytesArray = new byte[(int) file.length()]; 

		  FileInputStream fis = new FileInputStream(file);
		  fis.read(bytesArray); 
		  fis.close();
					
		  return bytesArray;
	}
	
public String readS4ValidationData(final String path, final long requestId, HttpServletRequest request, HttpSession session) {
		
		logger.info("Coming inside readValidationData");
		String comment="Success";
		FileInputStream inputStream;
		List<S4ValidationList> validationDataS4List=new ArrayList<S4ValidationList>();
		try {
			inputStream = new FileInputStream(new File(path));
			logger.info("Coming inside readValidationData inputStream::::" + inputStream);
			 StreamingReader reader = StreamingReader.builder()
						.rowCacheSize(1002)    
						.bufferSize(1024)     
						.sheetIndex(0)        
						.read(inputStream);   

			 
			for (Row row : reader) {					
				if(row.getRowNum()>0) {
					
				S4ValidationList validDataS4=new S4ValidationList();
				validDataS4.setIdentifier((row.getCell(0)==null ?"":row.getCell(0).getStringCellValue()));
				if(row.getCell(1)!=null){
					int versionCellType=row.getCell(1).getCellType();
					if(versionCellType==1)
						validDataS4.setVersion(row.getCell(1)==null?"": row.getCell(1).getStringCellValue());
						//opDataS4.setErrCategoryNumeric((row.getCell(8)==null ?"":row.getCell(8).getStringCellValue()));
					if(versionCellType==0)
						validDataS4.setVersion(row.getCell(1)==null?"": String.valueOf((int)(row.getCell(1).getNumericCellValue())));
				}
				validDataS4.setValidTo((row.getCell(2)==null?"":row.getCell(2).getStringCellValue()));
				validDataS4.setObject((row.getCell(3)==null?"":row.getCell(3).getStringCellValue()));
				validDataS4.setSubObject((row.getCell(4)==null?"":row.getCell(4).getStringCellValue()));
				validDataS4.setObjectType(row.getCell(5)==null?"":row.getCell(5).getStringCellValue());
				validDataS4.setProgramName((row.getCell(6)==null?"":row.getCell(6).getStringCellValue()));
				//validDataS4.setScreen(row.getCell(6)==null?"":String.valueOf((int)(row.getCell(6).getNumericCellValue())));
				validDataS4.setScreen(row.getCell(7)==null?"":row.getCell(7).getStringCellValue());
				validDataS4.setObsolete(row.getCell(8)==null?"":row.getCell(8).getStringCellValue());
				validDataS4.setNew_Len(row.getCell(9)==null?"":row.getCell(9).getStringCellValue());
				validDataS4.setAffectedArea(row.getCell(10)==null?"":row.getCell(10).getStringCellValue());
				validDataS4.setDetails(row.getCell(11)==null?"":row.getCell(11).getStringCellValue());
				validationDataS4List.add(validDataS4);
				
				}
			}
			
			//truncate table to do
			comment = s4ValidDao.validationFileDataBatchInsertUpdate(validationDataS4List, session);
		} catch (Exception ex) {
			logger.error("Error in S4ProcessingConroller : readValidationData()", ex);
		}
		return comment;
	}

	public void removeFileAfterAdd(String filePath, String fileName) {
		String[] separatedFileName = fileName.split("\\.");
		
try{
    		
	File file = new File(filePath+ File.separator + separatedFileName[0]+".zip");
        	
    		if(file.delete()){
    			logger.info("*.zip deleted removed sucessfully from directory");
    		}else{
    			logger.info("Delete Operation failed for *.zip");
    		}
    	   
    	} catch(Exception e) {
    		logger.error("Error while deleteing the file ::AdminSimplificationServiceImpl removeFileAfterAdd() :: ", e);
    	}
	}

	@Override
	public void addPreRequisiteFile(String filePath, String fileName, HttpSession session, String fileNameKey) {
		byte[] zipContent = null;
		FileStore fileStore = new FileStore();
		try {
			zipContent = convertFileContentToByteArray(filePath+ File.separator +fileName);
			/*preRequisiteFile.setPrerequisiteFile(zipContent);
			preRequisiteFile.setPrerequisiteFileName(fileName);
			int maxId = getS4ValidDao().getPreRequisiteMaxID();
			String prValVersion="PR"+maxId;
			preRequisiteFile.setPrerequisiteFileVersion(prValVersion);*/
			s4ValidDao.saveFiles(fileStore,zipContent,fileName,fileNameKey);
		} catch (Exception e ) {
			logger.error("Error in inserting validation file :: ", e);
		}
	}

	@Override
	public String adminPreRequisiteUpload(FileStore fileStore, RedirectAttributes redirectAttributes,
			Model model, HttpServletRequest request, HttpSession session, MultipartFile file) throws Exception {
		logger.info(":: adminPreRequisiteUpload Start :: ");
		String fileName="PreRequisite";
		long requestId=0;
		
		HANAUtility.deleteFile(fileName, requestId, null);
		final String filePath = HANAUtility.getFilePath(fileName, requestId);
		logger.info("FilePath for PreRequisite is fetched" );

		String preReqFilename="";

		/* File Validation Loop  Validation of files **/	
		try {
				preReqFilename = file.getOriginalFilename();
				FileUtility.detectZipFileType(file);
				FileUtility.chckUploadFilesAlphaNum(preReqFilename);
				FileUtility.checkFileSizeByItem(file,"PreRequisite");
				if (StringUtils.isNotEmpty(preReqFilename) && !"".equals(preReqFilename)) {
					String extension=Hana_Profiler_Constant.ZIP_EXTENSTION_CONSTANT;
					String fileExtension = preReqFilename.substring(preReqFilename.length() - extension.length(),preReqFilename.length());
					if (extension.equalsIgnoreCase(fileExtension)) {
						logger.info("Matched Extension");
						byte[] bytes = file.getBytes();
						Path path = Paths.get(filePath + File.separator + preReqFilename);
						Files.write(path, bytes);
						logger.info("Wrote in file path ");
						addPreRequisiteFile(filePath, preReqFilename, session, "PR");
						redirectAttributes.addFlashAttribute("message", "Pre Requisite File Added Succesfully");
							removeFileAfterAdd(filePath, preReqFilename);
					} else {
						redirectAttributes.addFlashAttribute("fileException", "Please Upload the file with .zip extension only.");
						return "redirect:/admin/simplificationN";
					}
				} else {
					redirectAttributes.addFlashAttribute("fileException", "Please Upload atleast one file.");
					return "redirect:/admin/simplificationN";
				}
			} catch (UploadFilesNotValidException exception) {
				redirectAttributes.addFlashAttribute("fileException", "The filename is not correct.");
				return "redirect:/admin/simplificationN";
			} catch (Exception exception) {
				redirectAttributes.addFlashAttribute("fileException", exception.getMessage());
				return "redirect:/admin/simplificationN";
			}
	
		logger.info(":: adminPreRequisiteUpload End ::");
		return "redirect:/admin/simplificationN";
	}
	
	@Override
	public String adminReviewChecklistUpload(FileStore fileStore, RedirectAttributes redirectAttributes, Model model,
			HttpServletRequest request, HttpSession session, MultipartFile file) throws Exception {
		logger.info(":: adminReviewChecklistUpload Start ::");
		String fileName="ReviewChecklist";
		long requestId=0;
		
		HANAUtility.deleteFile(fileName, requestId,null);
		final String filePath = HANAUtility.getFilePath(fileName, requestId);
		logger.info("FilePath for ReviewChecklist is fetched");
		
		String chckListFilename="";

		/* File Validation Loop  Validation of files **/	
		try {
				chckListFilename = file.getOriginalFilename();
				FileUtility.detectZipFileType(file);
				FileUtility.chckUploadFilesAlphaNum(chckListFilename);
					FileUtility.checkFileSizeByItem(file,"ReviewChecklist");

					if (StringUtils.isNotEmpty(chckListFilename) && !"".equals(chckListFilename)) {
						String extension=Hana_Profiler_Constant.ZIP_EXTENSTION_CONSTANT;
						String fileExtension = chckListFilename.substring(chckListFilename.length() - extension.length(),chckListFilename.length());
						if (extension.equalsIgnoreCase(fileExtension)) {
							logger.info("Matched Extension");
							byte[] bytes = file.getBytes();
							Path path = Paths.get(filePath + File.separator + chckListFilename);
							Files.write(path, bytes);
							logger.info("Wrote in file path");
							addReviewChecklistFile(filePath, chckListFilename, session, "RC");
							redirectAttributes.addFlashAttribute("message", "Review Checklist File Added Succesfully");
								removeFileAfterAdd(filePath, chckListFilename);
						} else {
							redirectAttributes.addFlashAttribute("fileException", "Please Upload the file with .zip extension only.");
							return "redirect:/admin/simplificationN";
						}
					} else {
						redirectAttributes.addFlashAttribute("fileException", "Please Upload atleast one file.");
						return "redirect:/admin/simplificationN";
					}
				}  catch (UploadFilesNotValidException exception) {
					redirectAttributes.addFlashAttribute("fileException", "The filename is not correct.");
					return "redirect:/admin/simplificationN";
				} catch (Exception exception) {
					redirectAttributes.addFlashAttribute("fileException", exception.getMessage());
					return "redirect:/admin/simplificationN";
				}
		logger.info(":: adminReviewChecklistUpload End ::");
		return "redirect:/admin/simplificationN";
	}

	@Override
	public void addReviewChecklistFile(String filePath, String fileName, HttpSession session, String fileNameKey) {
		byte[] zipContent = null;
		FileStore fileStore = new FileStore();
		try {
			zipContent = convertFileContentToByteArray(filePath+ File.separator +fileName);
			s4ValidDao.saveFiles(fileStore,zipContent,fileName,fileNameKey);
		} catch (Exception e ) {
			logger.error("Error in inserting validation file :: ", e);
		}
	}
	
	@Override
	public String adminTCDSimplificationUpload(FileStore fileStore, RedirectAttributes redirectAttributes, Model model,
			HttpServletRequest request, HttpSession session, MultipartFile file) throws Exception {
		logger.info(":: adminTCDSimplificationUpload Start ::");
		
		String fileName="TCD";
		long requestId=0;
		
		String comments = "";
		String message = "Analysis is in progress";
		HANAUtility.changeRequestProgressValue(requestId, 0, message);
		Map<String, String> fileList = new HashMap<String, String>();
		
		HANAUtility.deleteFile(fileName, requestId,null);
		final String filePath = HANAUtility.getFilePath(fileName, requestId);
		logger.info("FilePath for TCDSimplification is fetched");
		
		String tcdFilename = "";
		
		try {
			tcdFilename = file.getOriginalFilename();
			FileUtility.chckUploadFilesAlphaNum(tcdFilename);
			FileUtility.checkFileSizeByItem(file, "TCD");
			if (StringUtils.isNotEmpty(tcdFilename) && !"".equals(tcdFilename)) {
				String extension = Hana_Profiler_Constant.XLSX_EXTENSTION_CONSTANT;
				String fileExtension = tcdFilename.substring(tcdFilename.length() - extension.length(),
						tcdFilename.length());
					if (extension.equalsIgnoreCase(fileExtension)) {
						logger.info("Matched Extension");
						byte[] bytes = file.getBytes();
						Path path = Paths.get(filePath + File.separator + tcdFilename);
						Files.write(path, bytes);
						logger.info("Wrote in file path");
					} else {
							redirectAttributes.addFlashAttribute("fileException",
									"Please Upload the file with .xlsx extension only.");
							return "redirect:/admin/simplificationN";
					}
				} else {
					redirectAttributes.addFlashAttribute("fileException", "Please Upload atleast one file.");
					return "redirect:/admin/simplificationN";
				}
			} catch (UploadFilesNotValidException exception) {
				redirectAttributes.addFlashAttribute("fileException", "The filename is not correct.");
				return "redirect:/admin/simplificationN";
			}catch (Exception exception) {
				redirectAttributes.addFlashAttribute("fileException", exception.getMessage());
				return "redirect:/admin/simplificationN";
			}
		
			List<String> missingFiles = new ArrayList<String>();
			try {
				InitialDataValidation initialDataValidation = new InitialDataValidation(filePath);
				CheckFileListStatus checkObject = new CheckFileListStatus(filePath);
	
				boolean checkListStatus = true;
	
				Map<String, String> filesNameWithStatus = checkObject.validateFiles("TCDSimplification", filePath);
				Iterator<String> listKeysIterator = filesNameWithStatus.keySet().iterator();
				Map<String, String> tempMap = new HashMap<>();
				while (listKeysIterator.hasNext()) {
					String checkListName = listKeysIterator.next();
					// If the files is not present corresponding to checkList.
					if (!(filesNameWithStatus.get(checkListName)).equalsIgnoreCase("VALID")) {
						// If all the required files are not present then, add the missing files.
						checkListStatus = false;
						missingFiles.add(checkListName);
					} else {
						for (Map.Entry<String, String> entry : fileList.entrySet()) {
							if (entry.getKey().startsWith(checkListName.toUpperCase())) {
								tempMap.put(entry.getKey(), "VALID");
							}
						}
					}
				}
				boolean isAnyInvalidFile = false;
				// At the end, make all the files that have unexpected name as invalid.
				for (Map.Entry<String, String> entry : fileList.entrySet()) {
					if (!tempMap.containsKey(entry.getKey())) {
						isAnyInvalidFile = true;
						if (fileList.get(entry.getKey()).equalsIgnoreCase("VALID")) {
							fileList.put(entry.getKey(), "INVALID FILE NAME.");
						}
					}
				}
				logger.info("after checkListStatus");
	
				// If all required file are present, then proceed for XLSX validation.
				try {
					if (initialDataValidation.validateAllFiles(fileList, "TCDSimplification")) {
						message = HANAUtility.getPropertyValue("testing.properties", "filelistokmessage");
						HANAUtility.changeRequestProgressValue(requestId, 10, message);
					} else {
						// Somehow validation of files have failed and instead of throwing an exception
						// it has returned false.
						logger.info("inside else block ");
	
						comments = HANAUtility.getPropertyValue("testing.properties", "filelistnotokmessage");
						redirectAttributes.addFlashAttribute("fileException", comments);
						return "redirect:/admin/simplificationN";
	
					}
					if (!checkListStatus || isAnyInvalidFile) {
						if (!missingFiles.isEmpty()) {
							comments = "Please upload " + missingFiles + " files for processing this request.";
							redirectAttributes.addFlashAttribute("fileException", comments);
							return "redirect:/admin/simplificationN";
						} else {
							comments = "Please upload valid files only";
							redirectAttributes.addFlashAttribute("fileException", comments);
							return "redirect:/admin/simplificationN";
						}
					}
			}

			catch (Exception e) {
				logger.info("In Exception catch: " + e);
				redirectAttributes.addFlashAttribute("message", e.getMessage());
				return "redirect:/admin/simplificationN";
			}
		} finally {}

		try {
			HANAUtility.changeRequestProgressValue(requestId, 20, "Files Uploaded Successfully.");
			String comment = readTCDSimplificationData((filePath), requestId, request, session);
			if (comment.equalsIgnoreCase("success")) {
				HANAUtility.changeRequestProgressValue(requestId, 40, "Data Saved Successfully.");
				// redirectAttributes.addFlashAttribute("message", "File uploaded successfully,
				// creation under process.");
				// comment=createSimplification(requestId);
				// if(comment.equalsIgnoreCase("success")){
				HANAUtility.changeRequestProgressValue(requestId, 100,
						"TCD uploaded successfully.");
				model.addAttribute("uploaded", "true");
				model.addAttribute("message", "TCD created successfully");
				return "admin/simplificationN";
				/*
				 * }else{ redirectAttributes.addFlashAttribute("fileException", comment); }
				 */
			} else {
				redirectAttributes.addFlashAttribute("fileException", comment);
			}

		} catch (Exception e) {
			redirectAttributes.addFlashAttribute("fileException", e.getMessage());
			return "redirect:/admin/simplificationN";
		}
		return "redirect:/admin/simplificationN";
	}

public String readTCDSimplificationData(final String path, final long requestId, HttpServletRequest request, HttpSession session) throws FileNotFoundException {
		
		logger.info("Coming inside ReadTCDSimplificationDATA");
		String filePath="";
		String comment="";
		//final String rootPath = HANAUtility.getFilePath("Simplification Files", 0);
		final File rootFolderFileList[] = new File(path).listFiles();
		try {
			for (File file : rootFolderFileList) {
				logger.info("Analysing file");
				filePath = file.getCanonicalPath();
				logger.info("filePath is fetched");
				
				final File fil = new File(filePath);
				String filPath=fil.getName().toUpperCase();
				if (filPath.toUpperCase().contains(ST03HanaConstant.TCD_SIMPLIFICATION_CONSTANT)) {
					comment=addTCDSimplificationData(filePath, requestId, session);
				} 
				/*else if (filPath.toUpperCase().contains(Services_Constant.ZAICAT_DETECTION)) {
					comment=addDetectionData(filePath, requestId);
				}*/
				
			}
		} catch (IOException e) {
			logger.error(e.getMessage());
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		
		return comment;
	}
private String addTCDSimplificationData(String filePath, long requestId, HttpSession session) throws FileNotFoundException {
	File file = new File(filePath);
	InputStream inputStream = new FileInputStream(file);
	String comment="";

	String fileName = file.getName();
	
		List<TCDSimplification> tcdSimpliList=new ArrayList<TCDSimplification>();
		logger.info("Coming inside ReadTCDSimplificationDATA :::");
		try {
			
			logger.info("Coming inside ReadTCDSimplificationDATA inputStream::::" + inputStream);
			 StreamingReader reader = StreamingReader.builder()
						.rowCacheSize(1002)    
						.bufferSize(1024)     
						.sheetIndex(0)        
						.read(inputStream);   

			 
			for (Row row : reader) {					
				if(row.getRowNum()>0) {
				
			//validDataS4.setIdentifier((row.getCell(0)==null ?"":row.getCell(0).getStringCellValue()));
					int oldIndex=Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Old"));
					int newTcodeIndex=Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("NewTcode"));
					int functionalAreaIndex=Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("functional.area"));
					int referanceIndex=Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("referance"));
					int targetVersionIndex=Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("targetVersion"));
					
					int fioriOldIndex=Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("fioriId.old"));
					int appNameOldIndex=Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("appName.old"));
					int appTypeOldIndex=Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("appType.old"));
					int frontEndOldIndex=Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("frontEnd.old"));
					int productVersionIndex=Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("productVersion.old"));
					int primaryodataOldIndex=Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("primaryOdata.old"));
					int additionalOdataIndex=Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("AdditionalOdata"));
					int wdaCnfOldIndex=Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("wdaConf.old"));
					int fioriIdNewIndex=Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("fioriId.new"));
					int appNameNewIndex=Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("appName.new"));
					int appTypeNewIndex=Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("appType.new"));
					int frontEndNewIndex=Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("frontEnd.new"));
					int productVersionNewIndex=Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("productVersion.new"));
					int primaryOdataNewIndex=Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("primaryOdata.new"));
					int additionalOdataNewIndex=Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("AdditinalOdata.new"));
					int wdaCOnfNewIndex=Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("wdaConf.new"));
							
					
					TCDSimplification tcd=new TCDSimplification();
					tcd.setOld((row.getCell(oldIndex)==null ?"":row.getCell(oldIndex).getStringCellValue()));
					tcd.setNewTcode(row.getCell(newTcodeIndex)==null?"":(row.getCell(newTcodeIndex).getStringCellValue()));
					tcd.setFunctionalArea((row.getCell(functionalAreaIndex)==null?"":row.getCell(functionalAreaIndex).getStringCellValue()));
					tcd.setReference((row.getCell(referanceIndex)==null?"":row.getCell(referanceIndex).getStringCellValue()));
					tcd.setTargetVersion((row.getCell(targetVersionIndex)==null?"":row.getCell(targetVersionIndex).getStringCellValue()));
					tcd.setFioriIdOldTcode((row.getCell(fioriOldIndex)==null?"":row.getCell(fioriOldIndex).getStringCellValue()));
					tcd.setAppNameOldTcode((row.getCell(appNameOldIndex)==null?"":row.getCell(appNameOldIndex).getStringCellValue()));
					tcd.setAppTypeOldTcode((row.getCell(appTypeOldIndex)==null?"":row.getCell(appTypeOldIndex).getStringCellValue()));
					tcd.setFrntEndPrdVerOldTcode((row.getCell(frontEndOldIndex)==null?"":row.getCell(frontEndOldIndex).getStringCellValue()));
					tcd.setPrdVerNameBckEndOldTcode((row.getCell(productVersionIndex)==null?"":row.getCell(productVersionIndex).getStringCellValue()));
					tcd.setPriOdataSerNameOldTcode((row.getCell(primaryodataOldIndex)==null?"":row.getCell(primaryodataOldIndex).getStringCellValue()));
					tcd.setAddOdataSerOldTcode((row.getCell(additionalOdataIndex)==null?"":row.getCell(additionalOdataIndex).getStringCellValue()));
					tcd.setWdaConfOldTcode((row.getCell(wdaCnfOldIndex)==null?"":row.getCell(wdaCnfOldIndex).getStringCellValue()));
					tcd.setFioriIdNewTcode((row.getCell(fioriIdNewIndex)==null?"":row.getCell(fioriIdNewIndex).getStringCellValue()));
					tcd.setAppNameNewTcode((row.getCell(appNameNewIndex)==null?"":row.getCell(appNameNewIndex).getStringCellValue()));
					tcd.setAppTypeNewTcode((row.getCell(appTypeNewIndex)==null?"":row.getCell(appTypeNewIndex).getStringCellValue()));
					tcd.setFrntEndPrdVerNewTcode((row.getCell(frontEndNewIndex)==null?"":row.getCell(frontEndNewIndex).getStringCellValue()));
					tcd.setPrdVerNameBckEndNewTcode((row.getCell(productVersionNewIndex)==null?"":row.getCell(productVersionNewIndex).getStringCellValue()));
					tcd.setPriOdataSerNameNewTcode((row.getCell(primaryOdataNewIndex)==null?"":row.getCell(primaryOdataNewIndex).getStringCellValue()));
					tcd.setAddOdataSerNewTcode((row.getCell(additionalOdataNewIndex)==null?"":row.getCell(additionalOdataNewIndex).getStringCellValue()));
					tcd.setWdaConfNewTcode((row.getCell(wdaCOnfNewIndex)==null?"":row.getCell(wdaCOnfNewIndex).getStringCellValue()));
					tcdSimpliList.add(tcd);
					
					}
				}
			
			comment = s4ValidDao.tcdSimplificationDataBatchInsertUpdate(tcdSimpliList, session);	
		} catch (Exception e) {
			logger.error("Error !!! " + e);
		}
	
		return comment;		
}

@Override
public String adminTargetUsobtcUpload(FileStore fileStore, RedirectAttributes redirectAttributes, Model model,
		HttpServletRequest request, HttpSession session, MultipartFile file) throws Exception {
	logger.info(":: adminTargetUsobtcUpload Start ::");
	String fileName="TAR_USOBTC";
	long requestId=0;
	
	String comments = "";
	String message = "Analysis is in progress";
	HANAUtility.changeRequestProgressValue(requestId, 0, message);
	Map<String, String> fileList = new HashMap<String, String>();
	
	HANAUtility.deleteFile(fileName, requestId,null);
	final String filePath = HANAUtility.getFilePath(fileName, requestId);
	logger.info("FilePath for TargetUSOBTC is fetched ::::");

	String targetUSOBTCFilename="";

	/* File Validation Loop  Validation of files **/	
	try {
			targetUSOBTCFilename = file.getOriginalFilename();
			FileUtility.chckUploadFilesAlphaNum(targetUSOBTCFilename);
			FileUtility.checkFileSizeByItem(file, "Target_USOBTC");
			if (StringUtils.isNotEmpty(targetUSOBTCFilename) && !"".equals(targetUSOBTCFilename)) {
					String extension=Hana_Profiler_Constant.XLSX_EXTENSTION_CONSTANT;
					String fileExtension = targetUSOBTCFilename.substring(targetUSOBTCFilename.length() - extension.length(),targetUSOBTCFilename.length());
					if (extension.equalsIgnoreCase(fileExtension)) {
						logger.info("Matched Extension");
						byte[] bytes = file.getBytes();
						Path path = Paths.get(filePath + File.separator + targetUSOBTCFilename);
						Files.write(path, bytes);
						logger.info("Wrote in file path **");
					} else {
						redirectAttributes.addFlashAttribute("fileException", "Please Upload the file with .xlsx extension only.");
						return "redirect:/admin/simplificationN";
					}
				} else {
					redirectAttributes.addFlashAttribute("fileException", "Please Upload atleast one file.");
					return "redirect:/admin/simplificationN";
				}
			} catch (UploadFilesNotValidException exception) {
				redirectAttributes.addFlashAttribute("fileException", "The filename is not correct.");
				return "redirect:/admin/simplificationN";
			} catch (Exception exception) {
				redirectAttributes.addFlashAttribute("fileException", exception.getMessage());
				return "redirect:/admin/simplificationN";
			}
	
	List<String> missingFiles = new ArrayList<String>();
	
	try {
		InitialDataValidation initialDataValidation = new InitialDataValidation(filePath);
		CheckFileListStatus checkObject = new CheckFileListStatus(filePath);

		boolean checkListStatus = true;

		Map<String, String> filesNameWithStatus = checkObject.validateFiles("Tar_Usobtc", filePath);
		Iterator<String> listKeysIterator = filesNameWithStatus.keySet().iterator();
		Map<String, String> tempMap = new HashMap<>();
		while (listKeysIterator.hasNext()) {
			String checkListName = listKeysIterator.next();
			// If the files is not present corresponding to checkList.
			if (!(filesNameWithStatus.get(checkListName)).equalsIgnoreCase("VALID")) {
				// If all the required files are not present then, add the missing files.
				checkListStatus = false;
				missingFiles.add(checkListName);
			} else {
				for (Map.Entry<String, String> entry : fileList.entrySet()) {
					if (entry.getKey().startsWith(checkListName.toUpperCase())) {
						tempMap.put(entry.getKey(), "VALID");
					}
				}
			}
		}
		boolean isAnyInvalidFile = false;
		// At the end, make all the files that have unexpected name as invalid.
		for (Map.Entry<String, String> entry : fileList.entrySet()) {
			if (!tempMap.containsKey(entry.getKey())) {
				isAnyInvalidFile = true;
				if (fileList.get(entry.getKey()).equalsIgnoreCase("VALID")) {
					fileList.put(entry.getKey(), "INVALID FILE NAME.");
				}
			}
		}
		logger.info("after checkListStatus");

		// If all required file are present, then proceed for XLSX validation.
		try {
			if (initialDataValidation.validateAllFiles(fileList, "Tar_Usobtc")) {
				message = HANAUtility.getPropertyValue("testing.properties", "filelistokmessage");
				HANAUtility.changeRequestProgressValue(requestId, 10, message);
			} else {
				// Somehow validation of files have failed and instead of throwing an exception
				// it has returned false.
				logger.info("inside else block ");

				comments = HANAUtility.getPropertyValue("testing.properties", "filelistnotokmessage");
				redirectAttributes.addFlashAttribute("fileException", comments);
				return "redirect:/admin/simplificationN";

			}
			if (!checkListStatus || isAnyInvalidFile) {
				if (!missingFiles.isEmpty()) {
					comments = "Please upload " + missingFiles + " files for processing this request.";
					redirectAttributes.addFlashAttribute("fileException", comments);
					return "redirect:/admin/simplificationN";
				} else {
					comments = "Please upload valid files only";
					redirectAttributes.addFlashAttribute("fileException", comments);
					return "redirect:/admin/simplificationN";
				}
			}
		} catch (Exception e) {
			logger.error("In Exception catch: " + e.getMessage());
			logger.error("Error !!! " + e);
			redirectAttributes.addFlashAttribute("message", e.getMessage());
			return "redirect:/admin/simplificationN";
		}
	} finally {}

	try {
		HANAUtility.changeRequestProgressValue(requestId, 20, "Files Uploaded Successfully.");
		String comment = readTargetUSOBTCData((filePath + File.separator + targetUSOBTCFilename), requestId, request, session);
		if (comment.equalsIgnoreCase("success")) {
			HANAUtility.changeRequestProgressValue(requestId, 40, "Data Saved Successfully.");
			HANAUtility.changeRequestProgressValue(requestId, 100,
					"Target USOBTC uploaded successfully.");
			model.addAttribute("uploaded", "true");
			model.addAttribute("message", "Target USOBTC created successfully");
			return "admin/simplificationN";
		} else {
			redirectAttributes.addFlashAttribute("fileException", comment);
		}
	} catch (Exception e) {
		redirectAttributes.addFlashAttribute("fileException", e.getMessage());
		return "redirect:/admin/simplificationN";
	}
	return "redirect:/admin/simplificationN";
}

public String readTargetUSOBTCData(final String path, final long requestId, HttpServletRequest request,
		HttpSession session) {
	logger.info("Coming inside readTargetUSOBTCData");
	String comment = "Success";
	try {
		FileInputStream inputStream;
		File file = new File(path);
		inputStream = new FileInputStream(file);

		String fileName = file.getName();
		List<TarUsobtc> TarUsobtcList = new ArrayList<TarUsobtc>();

		logger.info("Coming inside readTargetUSOBTCData inputStream::::" + inputStream);
		StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
				.read(inputStream);

		for (Row row : reader) {
			if (row.getRowNum() > 0) {

				TarUsobtc tarUsobtc = new TarUsobtc();
				int versionIndex = Integer.parseInt(
						Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("version"));
				int tcdIndex = Integer
						.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("tcd"));
				int objIndex = Integer
						.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("obj"));
				int filedIndex = Integer.parseInt(
						Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("field"));
				int lowIndex = Integer
						.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("low"));
				int highIndex = Integer.parseInt(
						Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("high"));

				tarUsobtc.setVersion(
						(row.getCell(versionIndex) == null ? "" : row.getCell(versionIndex).getStringCellValue()).trim());
				tarUsobtc.setTcd((row.getCell(tcdIndex) == null ? "" : row.getCell(tcdIndex).getStringCellValue()).trim());
				tarUsobtc.setObject(
						(row.getCell(objIndex) == null ? "" : row.getCell(objIndex).getStringCellValue()).trim());
				tarUsobtc.setField(
						(row.getCell(filedIndex) == null ? "" : row.getCell(filedIndex).getStringCellValue()).trim());
				tarUsobtc.setLow((row.getCell(lowIndex) == null ? "" : row.getCell(lowIndex).getStringCellValue()).trim());
				tarUsobtc.setHigh(
						(row.getCell(highIndex) == null ? "" : row.getCell(highIndex).getStringCellValue()).trim());
				TarUsobtcList.add(tarUsobtc);

			}
		}

		// truncate table to do
		comment = s4ValidDao.targetUsobtcDataBatchInsertUpdate(TarUsobtcList, session);
	} catch (Exception ex) {
		logger.error("Error in AdminSimplificationServiceImpl : readTargetUSOBTCData()", ex);
	}
	return comment;
}

public String readGrcMasterData(final String path, final long requestId, HttpServletRequest request, HttpSession session) throws FileNotFoundException {
	
	logger.info("Coming inside readGrcMasterData");
	String filePath="";
	String comment="";
	//final String rootPath = HANAUtility.getFilePath("Simplification Files", 0);
	final File rootFolderFileList[] = new File(path).listFiles();
	try {
		for (File file : rootFolderFileList) {
			logger.info("Analysing file");
			filePath = file.getCanonicalPath();
			logger.info("filePath is fetched");
			
			final File fil = new File(filePath);
			String filPath=fil.getName().toUpperCase();
			if (filPath.toUpperCase().contains(ST03HanaConstant.GRC_MASTER_CONSTANT)) {
				comment=addGrcMasterData(filePath, requestId, session);
			} 
			/*else if (filPath.toUpperCase().contains(Services_Constant.ZAICAT_DETECTION)) {
				comment=addDetectionData(filePath, requestId);
			}*/
			
		}
	} catch (IOException e) {
		logger.error(e.getMessage());
	} catch (Exception e) {
		logger.error(e.getMessage());
	}
	
	return comment;
}
private String addGrcMasterData(String filePath, long requestId, HttpSession session) throws FileNotFoundException {
	File file = new File(filePath);
	InputStream inputStream = new FileInputStream(file);
	String comment="";

	String fileName = file.getName();
	
		List<GrcMasterdata> grcMasterList=new ArrayList<GrcMasterdata>();
		logger.info("Coming inside addGrcMasterData :::");
		try {
			
			logger.info("Coming inside addGrcMasterData inputStream::::" + inputStream);
			 StreamingReader reader = StreamingReader.builder()
						.rowCacheSize(1002)    
						.bufferSize(1024)     
						.sheetIndex(0)        
						.read(inputStream);   

			 
			for (Row row : reader) {					
				if(row.getRowNum()>0) {
				
			//validDataS4.setIdentifier((row.getCell(0)==null ?"":row.getCell(0).getStringCellValue()));
					int mandtIndex=Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("mandt"));
					int functIdIndex=Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("functid"));
					int actionIndex=Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("action"));
					int connectorIndex=Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("connector"));
					int activeIndex=Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("active"));
					
					
					
					GrcMasterdata grc=new GrcMasterdata();
					grc.setMandt(row.getCell(mandtIndex)==null ?"":row.getCell(mandtIndex).getStringCellValue());
					grc.setFunctId(row.getCell(functIdIndex)==null ?"":row.getCell(functIdIndex).getStringCellValue());
					grc.setAction(row.getCell(actionIndex)==null ?"":row.getCell(actionIndex).getStringCellValue());
					grc.setConnector(row.getCell(connectorIndex)==null ?"":row.getCell(connectorIndex).getStringCellValue());
					grc.setActive(row.getCell(activeIndex)==null ?"":row.getCell(activeIndex).getStringCellValue());
					
					grcMasterList.add(grc);
					
					}
				}
			
			comment = s4ValidDao.grcMasterdataDataBatchInsertUpdate(grcMasterList, session);
			}catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return comment;
			
}
@Override
public String adminGRCMasterdataUpload(FileStore fileStore, RedirectAttributes redirectAttributes, Model model,
		HttpServletRequest request, HttpSession session, MultipartFile file) throws Exception {
	logger.info(":: adminGRCMasterdataUpload Start ::");
	
	String fileName="TCD";
	long requestId=0;
	
	String comments = "";
	String message = "Analysis is in progress";
	HANAUtility.changeRequestProgressValue(requestId, 0, message);
	Map<String, String> fileList = new HashMap<String, String>();
	
	HANAUtility.deleteFile(fileName, requestId,null);
	final String filePath = HANAUtility.getFilePath(fileName, requestId);
	logger.info("FilePath for GRCMaster is fetched");
	
	String grcFilename = "";
	
	try {
		grcFilename = file.getOriginalFilename();
		FileUtility.chckUploadFilesAlphaNum(grcFilename);
		FileUtility.checkFileSizeByItem(file, "TCD");
		if (StringUtils.isNotEmpty(grcFilename) && !"".equals(grcFilename)) {
			String extension = Hana_Profiler_Constant.XLSX_EXTENSTION_CONSTANT;
			String fileExtension = grcFilename.substring(grcFilename.length() - extension.length(),
					grcFilename.length());
				if (extension.equalsIgnoreCase(fileExtension)) {
					logger.info("Matched Extension");
					byte[] bytes = file.getBytes();
					Path path = Paths.get(filePath + File.separator + grcFilename);
					Files.write(path, bytes);
					logger.info("Wrote in file path");
				} else {
						redirectAttributes.addFlashAttribute("fileException",
								"Please Upload the file with .xlsx extension only.");
						return "redirect:/admin/simplificationN";
				}
			} else {
				redirectAttributes.addFlashAttribute("fileException", "Please Upload atleast one file.");
				return "redirect:/admin/simplificationN";
			}
		} catch (UploadFilesNotValidException exception) {
			redirectAttributes.addFlashAttribute("fileException", "The filename is not correct.");
			return "redirect:/admin/simplificationN";
		}catch (Exception exception) {
			redirectAttributes.addFlashAttribute("fileException", exception.getMessage());
			return "redirect:/admin/simplificationN";
		}
	
		List<String> missingFiles = new ArrayList<String>();
		try {
			InitialDataValidation initialDataValidation = new InitialDataValidation(filePath);
			CheckFileListStatus checkObject = new CheckFileListStatus(filePath);

			boolean checkListStatus = true;

			Map<String, String> filesNameWithStatus = checkObject.validateFiles("GRC_STANDARDRULES", filePath);
			Iterator<String> listKeysIterator = filesNameWithStatus.keySet().iterator();
			Map<String, String> tempMap = new HashMap<>();
			while (listKeysIterator.hasNext()) {
				String checkListName = listKeysIterator.next();
				// If the files is not present corresponding to checkList.
				if (!(filesNameWithStatus.get(checkListName)).equalsIgnoreCase("VALID")) {
					// If all the required files are not present then, add the missing files.
					checkListStatus = false;
					missingFiles.add(checkListName);
				} else {
					for (Map.Entry<String, String> entry : fileList.entrySet()) {
						if (entry.getKey().startsWith(checkListName.toUpperCase())) {
							tempMap.put(entry.getKey(), "VALID");
						}
					}
				}
			}
			boolean isAnyInvalidFile = false;
			// At the end, make all the files that have unexpected name as invalid.
			for (Map.Entry<String, String> entry : fileList.entrySet()) {
				if (!tempMap.containsKey(entry.getKey())) {
					isAnyInvalidFile = true;
					if (fileList.get(entry.getKey()).equalsIgnoreCase("VALID")) {
						fileList.put(entry.getKey(), "INVALID FILE NAME.");
					}
				}
			}
			logger.info("after checkListStatus");

			// If all required file are present, then proceed for XLSX validation.
			try {
				if (initialDataValidation.validateAllFiles(fileList, "GRC_STANDARDRULES")) {
					message = HANAUtility.getPropertyValue("testing.properties", "filelistokmessage");
					HANAUtility.changeRequestProgressValue(requestId, 10, message);
				} else {
					// Somehow validation of files have failed and instead of throwing an exception
					// it has returned false.
					logger.info("inside else block ");

					comments = HANAUtility.getPropertyValue("testing.properties", "filelistnotokmessage");
					redirectAttributes.addFlashAttribute("fileException", comments);
					return "redirect:/admin/simplificationN";

				}
				if (!checkListStatus || isAnyInvalidFile) {
					if (!missingFiles.isEmpty()) {
						comments = "Please upload " + missingFiles + " files for processing this request.";
						redirectAttributes.addFlashAttribute("fileException", comments);
						return "redirect:/admin/simplificationN";
					} else {
						comments = "Please upload valid files only";
						redirectAttributes.addFlashAttribute("fileException", comments);
						return "redirect:/admin/simplificationN";
					}
				}
		}

		catch (Exception e) {
			logger.info("In adminGRCMasterdataUpload catch: " ,e);
			redirectAttributes.addFlashAttribute("message", e.getMessage());
			return "redirect:/admin/simplificationN";
		}
	}finally {}

	try {
		HANAUtility.changeRequestProgressValue(requestId, 20, "Files Uploaded Successfully.");
		String comment = readGrcMasterData((filePath), requestId, request, session);
		if (comment.equalsIgnoreCase("success")) {
			HANAUtility.changeRequestProgressValue(requestId, 40, "Data Saved Successfully.");
			// redirectAttributes.addFlashAttribute("message", "File uploaded successfully,
			// creation under process.");
			// comment=createSimplification(requestId);
			// if(comment.equalsIgnoreCase("success")){
			HANAUtility.changeRequestProgressValue(requestId, 100,
					"TCD uploaded successfully.");
			model.addAttribute("uploaded", "true");
			model.addAttribute("message", "GRC STandard Ruleset saved successfully");
			return "admin/simplificationN";
			/*
			 * }else{ redirectAttributes.addFlashAttribute("fileException", comment); }
			 */
		} else {
			redirectAttributes.addFlashAttribute("fileException", comment);
		}

	} catch (Exception e) {
		redirectAttributes.addFlashAttribute("fileException", e.getMessage());
		return "redirect:/admin/simplificationN";
	}
	return "redirect:/admin/simplificationN";
}

	private File adminAddTScopeMasterData(MultipartFile file, String prefix, long requestId) throws Exception {
		String fileName = S4HanaProfilerConstant.TSCOPE_CONSTANT;
		String comments = "";
		String directoryPath = "";
		String filePath = "";
		File masterFile;
		
		try {
			//Writing the uploaded file to the server path
			directoryPath = HANAUtility.getFilePath(fileName, requestId);
			filePath = directoryPath + File.separator + prefix + file.getOriginalFilename();
			File directory = new File(directoryPath);
			File[] files = directory.listFiles();
			Path path = Paths.get(filePath);
			
			if(directory.exists()) {
				for(File tcodeFile : files) {
					if(tcodeFile.getName().startsWith(prefix))
						tcodeFile.delete();
				}
			}
	
			byte[] bytes = file.getBytes();
			Files.write(path, bytes);
			logger.info(prefix +  " Mapping File - Wrote in file path");
		
			masterFile = new File(filePath);
			
			//To validate if all mandatory columns are present
			if(!(new XlsxValidator().validateXlsxFiles(masterFile.getAbsoluteFile().toString(), prefix))) {
				Files.deleteIfExists(path);
				comments = "All columns in " + file.getOriginalFilename() +  " are not present.";
				logger.info(comments);
				throw new UploadFilesNotValidException(comments);
			} else {
				comments = "All mandatory columns are present for processing - " + file.getOriginalFilename();
				logger.info(comments);
				return masterFile;
			}
		} catch (UploadFilesNotValidException e) {
			comments = "Error -- SubProcess Test Script";
			logger.error(comments, e);
			throw new UploadFilesNotValidException(e.getMessage());
		} catch (Exception e) {
			comments = "Error -- SubProcess Test Script";
			logger.error(comments, e);
			throw new Exception();
		} 
	}
	
	@Override
	public String adminTCodeSubProcessMappingFile(HttpSession session, MultipartFile file) throws Exception {
		logger.info("Start - adminTCodeSubProcessMappingFile() ...");
		
		long requestId = 0L;
		String comments = "";
		String result = "";
		File tcodeFile;
		try {
		    tcodeFile = adminAddTScopeMasterData(file, "TCODE_SUBPROCESS", requestId);
			result = addTCodeSubProcessData(tcodeFile, requestId, session);
		} catch (UploadFilesNotValidException e) {
			comments = "Error -- TCode SubProcess Test Script";
			logger.error(comments, e);
			throw new UploadFilesNotValidException(e.getMessage());
		} catch (Exception e) {
			comments = "Error -- TCode SubProcess Test Script";
			logger.error(comments, e);
			throw new Exception();
		} finally {
			logger.info("End - adminTCodeSubProcessMappingFile() ...");
		}
		
		return result;
	}
	
	private String addTCodeSubProcessData(File tcodeFile, long requestId, HttpSession session) 
			throws Exception {
		InputStream inputStream = new FileInputStream(tcodeFile);
		String comment = "";
		String fileName = tcodeFile.getName();
		
		List<TCodeSubProcessTestScript> tcodeSubProcessList = new ArrayList<>();
		logger.info("Reading TCode SubProcess Data ...");
		try {
			StreamingReader reader = StreamingReader.builder()
							.rowCacheSize(1002)    
							.bufferSize(1024)     
							.sheetIndex(0)        
							.read(inputStream);   
	
			for (Row row : reader) {					
				if(row.getRowNum()>0) {
					int scenarioIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.
							get(requestId).get(fileName).get("Scenario.Level1"));
					int mainProcessIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.
							get(requestId).get(fileName).get("MainProcess.Level2"));
					int subProcessIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.
							get(requestId).get(fileName).get("SubProces.Level3"));
					int testScriptIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.
							get(requestId).get(fileName).get("Test.Script.Level4"));
					int tcodesECCIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.
							get(requestId).get(fileName).get("TCodes.ECC"));
					int tcodesS41610Index = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.
							get(requestId).get(fileName).get("TCodes.S4.1610"));
					int tcodesS41709Index = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.
							get(requestId).get(fileName).get("TCodes.S4.1709"));
					int tcodesS41809Index = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.
							get(requestId).get(fileName).get("TCodes.S4.1809"));
					int tcodesS41909Index = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.
							get(requestId).get(fileName).get("TCodes.S4.1909"));
					int appCompIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.
							get(requestId).get(fileName).get("Application.Component"));
					int fioriAppIdIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.
							get(requestId).get(fileName).get("Fiori.AppID"));
					int fioriAppNameIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.
							get(requestId).get(fileName).get("Fiori.AppName"));
					
					String scenario = row.getCell(scenarioIndex)==null ? "" : row.getCell(scenarioIndex).getStringCellValue().trim();
					String mainProcess = row.getCell(mainProcessIndex)==null ? "" : row.getCell(mainProcessIndex).getStringCellValue().trim();
					String subProcess = row.getCell(subProcessIndex)==null ? "" : row.getCell(subProcessIndex).getStringCellValue().trim();
					String testScript = row.getCell(testScriptIndex)==null ? "" : row.getCell(testScriptIndex).getStringCellValue().trim();	
					String tcodesECC = row.getCell(tcodesECCIndex)==null ? "" : row.getCell(tcodesECCIndex).getStringCellValue().trim();	
					String tcodesS41610 = row.getCell(tcodesS41610Index)==null ? "" : row.getCell(tcodesS41610Index).getStringCellValue().trim();
					String tcodesS41709 = row.getCell(tcodesS41709Index)==null ? "" : row.getCell(tcodesS41709Index).getStringCellValue().trim();		
					String tcodesS41809 = row.getCell(tcodesS41809Index)==null ? "" : row.getCell(tcodesS41809Index).getStringCellValue().trim();
					String tcodesS41909 = row.getCell(tcodesS41909Index)==null ? "" : row.getCell(tcodesS41909Index).getStringCellValue().trim();
					String appComponent = row.getCell(appCompIndex)==null ? "" : row.getCell(appCompIndex).getStringCellValue().trim();	
					String fioriAppID = row.getCell(fioriAppIdIndex)==null ? "" : row.getCell(fioriAppIdIndex).getStringCellValue().trim();
					String fioriAppName = row.getCell(fioriAppNameIndex)==null ? "" : row.getCell(fioriAppNameIndex).getStringCellValue().trim();
					
					TCodeSubProcessTestScript tcodeSubProcess = new TCodeSubProcessTestScript();
					tcodeSubProcess.setScenarioLevelOne(scenario);
					tcodeSubProcess.setMainProcessLevelTwo(mainProcess);
					tcodeSubProcess.setSubProcessLevelThree(subProcess);
					tcodeSubProcess.setTestScriptLevelFour(testScript);
					tcodeSubProcess.setTcodesECC(tcodesECC);
					tcodeSubProcess.setTcodesS41610(tcodesS41610);
					tcodeSubProcess.setTcodesS41709(tcodesS41709);
					tcodeSubProcess.setTcodesS41809(tcodesS41809);
					tcodeSubProcess.setTcodesS41909(tcodesS41909);
					tcodeSubProcess.setApplicationComponent(appComponent);
					tcodeSubProcess.setFioriAppID(fioriAppID);
					tcodeSubProcess.setFioriAppName(fioriAppName);
					
					tcodeSubProcessList.add(tcodeSubProcess);	
				}
			}
				
			s4ValidDao.truncateTable("TCode_SubProcessTestScript", session);
			comment = s4ValidDao.tcodeSubProcessInsertData(tcodeSubProcessList, session);
		} catch (Exception e) {
			comment = "FAILURE in Inserting";
			logger.error("Error while inserting TCode SubProcess TestScript Data ", e);
			throw new Exception();
		}
		
		return comment;
	}
	
	@Override
	public String adminAppCompSubProcessMappingFile(HttpSession session, MultipartFile file) 
			throws Exception {
		logger.info("Start - adminAppComponentProcessMappingFile() ...");
		long requestId = 0L;
		String comments = "";
		String result = "";
		File appCompFile;
		try {
		    appCompFile = adminAddTScopeMasterData(file, "APPCOMP_SUBPROCESS", requestId);
			result = addAppCompSubProcessData(appCompFile, requestId, session);
		} catch (UploadFilesNotValidException e) {
			comments = "Error -- Application_Component SubProcess Test Script";
			logger.error(comments, e);
			throw new UploadFilesNotValidException(e.getMessage());
		} catch (Exception e) {
			comments = "Error -- Application_Component SubProcess Test Script";
			logger.error(comments, e);
			throw new Exception();
		} finally {
			logger.info("End - adminAppCompSubProcessMappingFile() ...");
		}
		
		return result;
	}
	
	private String addAppCompSubProcessData(File appCompFile, long requestId, HttpSession session) 
			throws Exception {
		InputStream inputStream = new FileInputStream(appCompFile);
		String comment = "";
		String fileName = appCompFile.getName();
		
		List<AppComponentSubProcessTestScript> appCompSubProcessList = new ArrayList<>();
		logger.info("Reading Application_Component SubProcess Data ...");
		try {
			StreamingReader reader = StreamingReader.builder()
							.rowCacheSize(1002)    
							.bufferSize(1024)     
							.sheetIndex(0)        
							.read(inputStream);   
	
			for (Row row : reader) {					
				if(row.getRowNum()>0) {
					int appComponentIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.
							get(requestId).get(fileName).get("Application.Component"));
					int scenarioIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.
							get(requestId).get(fileName).get("Scenario.Level1"));
					int mainProcessIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.
							get(requestId).get(fileName).get("MainProcess.Level2"));
					int subProcessIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.
							get(requestId).get(fileName).get("SubProces.Level3"));
					
					String applicationComponent = row.getCell(appComponentIndex)==null ? "" : row.getCell(appComponentIndex).getStringCellValue().trim();
					String scenario = row.getCell(scenarioIndex)==null ? "" : row.getCell(scenarioIndex).getStringCellValue().trim();
					String mainProcess = row.getCell(mainProcessIndex)==null ? "" : row.getCell(mainProcessIndex).getStringCellValue().trim();
					String subProcess = row.getCell(subProcessIndex)==null ? "" : row.getCell(subProcessIndex).getStringCellValue().trim();
							
					AppComponentSubProcessTestScript appCompSubProcess = new AppComponentSubProcessTestScript();
					appCompSubProcess.setAppComponent(applicationComponent);
					appCompSubProcess.setScenarioLevelOne(scenario);
					appCompSubProcess.setMainProcessLevelTwo(mainProcess);
					appCompSubProcess.setSubProcessLevelThree(subProcess);
					
					appCompSubProcessList.add(appCompSubProcess);	
				}
			}
				
			s4ValidDao.deleteTableData("AppComponentSubProcessTestScript");
			comment = s4ValidDao.appCompSubProcessInsertData(appCompSubProcessList, session);
		} catch (Exception e) {
			comment = "FAILURE in Inserting";
			logger.error("Error while inserting Application_Component SubProcess TestScript Data ", e);
			throw new Exception();
		}
		
		return comment;
	}
	
	public String readBwExtractMasterData(final String path, final long requestId, HttpServletRequest request, HttpSession session) throws FileNotFoundException {
		
		logger.info("Coming inside readBwExtractMasterData");
		String filePath="";
		String comment="";
		//final String rootPath = HANAUtility.getFilePath("Simplification Files", 0);
		final File rootFolderFileList[] = new File(path).listFiles();
		try {
			for (File file : rootFolderFileList) {
				logger.info("Analysing file");
				filePath = file.getCanonicalPath();
				logger.info("filePath is fetched");
				
				final File fil = new File(filePath);
				String filPath=fil.getName().toUpperCase();
				if (filPath.toUpperCase().contains(ST03HanaConstant.BWEXTRACT_MASTER_CONSTANT)) {
					comment=addBwExtractMasterData(filePath, requestId, session);
				} 
				/*else if (filPath.toUpperCase().contains(Services_Constant.ZAICAT_DETECTION)) {
					comment=addDetectionData(filePath, requestId);
				}*/
				
			}
		} catch (IOException e) {
			logger.error(e.getMessage());
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		
		return comment;
	}

	private String addBwExtractMasterData(String filePath, long requestId, HttpSession session) throws FileNotFoundException {
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);
		String comment="";

		String fileName = file.getName();
		
			List<BwExtractorMaster> bwMasterList=new ArrayList<BwExtractorMaster>();
			logger.info("Coming inside addBwExtractMasterData :::");
			try {
				
				logger.info("Coming inside addBwExtractMasterData inputStream::::" + inputStream);
				 StreamingReader reader = StreamingReader.builder()
							.rowCacheSize(1002)    
							.bufferSize(1024)     
							.sheetIndex(0)        
							.read(inputStream);   

				 
			for (Row row : reader) {
				if (row.getRowNum() > 4) {

					// validDataS4.setIdentifier((row.getCell(0)==null
					// ?"":row.getCell(0).getStringCellValue()));
					int vlookupIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("vlookup"));
					int phaseIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("phase"));
					int areaIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("area_of_responsibility"));
					int dataSourceIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("dataSource"));
					int apCompIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Appl_component"));
					int clasifyIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("classifiction"));
					int catIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("category"));
					int restrictIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("restriction"));
					int relSimpliIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("related_simplification_item"));
					int noteIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("note"));
					int del1511Index = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("del1511"));
					int del1610Index = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("del1610"));
					int delrestrIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("delta_restrictions"));
					int comIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("comments"));

					if (row.getCell(vlookupIndex).getStringCellValue().trim() != "") {
						BwExtractorMaster bwExtract = new BwExtractorMaster();
						bwExtract.setObjName(row.getCell(vlookupIndex) == null ? ""
								: row.getCell(vlookupIndex).getStringCellValue().trim());
						bwExtract.setPhase(row.getCell(phaseIndex) == null ? ""
								: row.getCell(phaseIndex).getStringCellValue().trim());
						bwExtract.setAreaResponsibility(row.getCell(areaIndex) == null ? ""
								: row.getCell(areaIndex).getStringCellValue().trim());
						bwExtract.setDataSrc(row.getCell(dataSourceIndex) == null ? ""
								: row.getCell(dataSourceIndex).getStringCellValue().trim());
						bwExtract.setAppComp(row.getCell(apCompIndex) == null ? ""
								: row.getCell(apCompIndex).getStringCellValue().trim());
						bwExtract.setClassification(row.getCell(clasifyIndex) == null ? ""
								: row.getCell(clasifyIndex).getStringCellValue().trim());
						bwExtract.setCategory(
								row.getCell(catIndex) == null ? "" : row.getCell(catIndex).getStringCellValue().trim());
						bwExtract.setRestrictions(row.getCell(restrictIndex) == null ? ""
								: row.getCell(restrictIndex).getStringCellValue().trim());
						bwExtract.setRelSimpliItem(row.getCell(relSimpliIndex) == null ? ""
								: row.getCell(relSimpliIndex).getStringCellValue().trim());
						bwExtract.setNote(row.getCell(noteIndex) == null ? ""
								: row.getCell(noteIndex).getStringCellValue().trim());
						bwExtract.setDel1511(row.getCell(del1511Index) == null ? ""
								: row.getCell(del1511Index).getStringCellValue().trim());
						bwExtract.setDel1610(row.getCell(del1610Index) == null ? ""
								: row.getCell(del1610Index).getStringCellValue().trim());
						bwExtract.setDelRestrict(row.getCell(delrestrIndex) == null ? ""
								: row.getCell(delrestrIndex).getStringCellValue().trim());
						bwExtract.setComments(
								row.getCell(comIndex) == null ? "" : row.getCell(comIndex).getStringCellValue().trim());

						bwMasterList.add(bwExtract);
					}

				}
			}
				
				comment=s4ValidDao.bwExtractMasterdataDataBatchInsertUpdate(bwMasterList, session);
				
				
				}catch (Exception e) {
					// TODO Auto-generated catch block
					logger.error("addBwExtractMasterData :: ",e);
				}
				return comment;
				
	}



	@Override
	public String adminBwExtractMasterUpload(FileStore fileStore, RedirectAttributes redirectAttributes, Model model,
			HttpServletRequest request, HttpSession session, MultipartFile file) throws Exception {
	logger.info(":: adminBwExtractMasterUpload Start ::");
		
		String fileName="BWEXTRACTMST";
		long requestId=0;
		
		String comments = "";
		String message = "Analysis is in progress";
		HANAUtility.changeRequestProgressValue(requestId, 0, message);
		Map<String, String> fileList = new HashMap<String, String>();
		
		HANAUtility.deleteFile(fileName, requestId,null);
		final String filePath = HANAUtility.getFilePath(fileName, requestId);
		logger.info("FilePath for BW Extract Master is fetched");
		
		String BwExtrctFilename = "";
		
		try {
			BwExtrctFilename = file.getOriginalFilename();
			FileUtility.chckUploadFilesAlphaNum(BwExtrctFilename);
			FileUtility.checkFileSizeByItem(file, "BWEXTRACTMST");
			if (StringUtils.isNotEmpty(BwExtrctFilename) && !"".equals(BwExtrctFilename)) {
				String extension = Hana_Profiler_Constant.XLSX_EXTENSTION_CONSTANT;
				String fileExtension = BwExtrctFilename.substring(BwExtrctFilename.length() - extension.length(),
						BwExtrctFilename.length());
					if (extension.equalsIgnoreCase(fileExtension)) {
						logger.info("Matched Extension");
						byte[] bytes = file.getBytes();
						Path path = Paths.get(filePath + File.separator + BwExtrctFilename);
						Files.write(path, bytes);
						logger.info("Wrote in file path");
					} else {
							redirectAttributes.addFlashAttribute("fileException",
									"Please Upload the file with .xlsx extension only.");
							return "redirect:/admin/simplificationN";
					}
				} else {
					redirectAttributes.addFlashAttribute("fileException", "Please Upload atleast one file.");
					return "redirect:/admin/simplificationN";
				}
			} catch (UploadFilesNotValidException exception) {
				redirectAttributes.addFlashAttribute("fileException", "The filename is not correct.");
				return "redirect:/admin/simplificationN";
			}catch (Exception exception) {
				redirectAttributes.addFlashAttribute("fileException", exception.getMessage());
				return "redirect:/admin/simplificationN";
			}
		
			List<String> missingFiles = new ArrayList<String>();
			try {
				InitialDataValidation initialDataValidation = new InitialDataValidation(filePath);
				CheckFileListStatus checkObject = new CheckFileListStatus(filePath);

				boolean checkListStatus = true;

				Map<String, String> filesNameWithStatus = checkObject.validateFiles("BW_EXTRACT_MASTER", filePath);
				Iterator<String> listKeysIterator = filesNameWithStatus.keySet().iterator();
				Map<String, String> tempMap = new HashMap<>();
				while (listKeysIterator.hasNext()) {
					String checkListName = listKeysIterator.next();
					// If the files is not present corresponding to checkList.
					if (!(filesNameWithStatus.get(checkListName)).equalsIgnoreCase("VALID")) {
						// If all the required files are not present then, add the missing files.
						checkListStatus = false;
						missingFiles.add(checkListName);
					} else {
						for (Map.Entry<String, String> entry : fileList.entrySet()) {
							if (entry.getKey().startsWith(checkListName.toUpperCase())) {
								tempMap.put(entry.getKey(), "VALID");
							}
						}
					}
				}
				boolean isAnyInvalidFile = false;
				// At the end, make all the files that have unexpected name as invalid.
				for (Map.Entry<String, String> entry : fileList.entrySet()) {
					if (!tempMap.containsKey(entry.getKey())) {
						isAnyInvalidFile = true;
						if (fileList.get(entry.getKey()).equalsIgnoreCase("VALID")) {
							fileList.put(entry.getKey(), "INVALID FILE NAME.");
						}
					}
				}
				logger.info("after checkListStatus");

				// If all required file are present, then proceed for XLSX validation.
				try {
					if (initialDataValidation.validateAllFiles(fileList, "BW_EXTRACT_MASTER")) {
						message = HANAUtility.getPropertyValue("testing.properties", "filelistokmessage");
						HANAUtility.changeRequestProgressValue(requestId, 10, message);
					} else {
						// Somehow validation of files have failed and instead of throwing an exception
						// it has returned false.
						logger.info("inside else block ");

						comments = HANAUtility.getPropertyValue("testing.properties", "filelistnotokmessage");
						redirectAttributes.addFlashAttribute("fileException", comments);
						return "redirect:/admin/simplificationN";

					}
					if (!checkListStatus || isAnyInvalidFile) {
						if (!missingFiles.isEmpty()) {
							comments = "Please upload " + missingFiles + " files for processing this request.";
							redirectAttributes.addFlashAttribute("fileException", comments);
							return "redirect:/admin/simplificationN";
						} else {
							comments = "Please upload valid files only";
							redirectAttributes.addFlashAttribute("fileException", comments);
							return "redirect:/admin/simplificationN";
						}
					}
			}

			catch (Exception e) {
				logger.info("In adminBWMasterdataUpload catch: " ,e);
				redirectAttributes.addFlashAttribute("message", e.getMessage());
				return "redirect:/admin/simplificationN";
			}
		}finally {}

		try {
			HANAUtility.changeRequestProgressValue(requestId, 20, "Files Uploaded Successfully.");
			String comment = readBwExtractMasterData((filePath), requestId, request, session);
			if (comment.equalsIgnoreCase("success")) {
				HANAUtility.changeRequestProgressValue(requestId, 40, "Data Saved Successfully.");
				// redirectAttributes.addFlashAttribute("message", "File uploaded successfully,
				// creation under process.");
				// comment=createSimplification(requestId);
				// if(comment.equalsIgnoreCase("success")){
				HANAUtility.changeRequestProgressValue(requestId, 100,
						"BW Master uploaded successfully.");
				model.addAttribute("uploaded", "true");
				model.addAttribute("message", "BW Extract Master saved successfully");
				return "admin/simplificationN";
				/*
				 * }else{ redirectAttributes.addFlashAttribute("fileException", comment); }
				 */
			} else {
				redirectAttributes.addFlashAttribute("fileException", comment);
			}

		} catch (Exception e) {
			redirectAttributes.addFlashAttribute("fileException", e.getMessage());
			return "redirect:/admin/simplificationN";
		}
		return "redirect:/admin/simplificationN";
	}
	@Override
	public String adminFioriRebuildUpload(FileStore fileStore, RedirectAttributes redirectAttributes, Model model,
			HttpServletRequest request, HttpSession session, MultipartFile file) throws Exception {

		logger.info(":: adminFioriRebuildUpload Start ::");
		String fileName="Fiori_Rebuild_Master";
		long requestId=0;
		
		String comments = "";
		String message = "Analysis is in progress";
		HANAUtility.changeRequestProgressValue(requestId, 0, message);
		Map<String, String> fileList = new HashMap<String, String>();
		
		HANAUtility.deleteFile(fileName, requestId,null);
		final String filePath = HANAUtility.getFilePath(fileName, requestId);
		logger.info("FilePath for FioriRebuild is fetched ::::");

		String FioriRebuildFilename="";

		/* File Validation Loop  Validation of files **/	
		try {
				FioriRebuildFilename = file.getOriginalFilename();
				FileUtility.chckUploadFilesAlphaNum(FioriRebuildFilename);
				FileUtility.checkFileSizeByItem(file, "Fiori_Rebuild_Master");
				if (StringUtils.isNotEmpty(FioriRebuildFilename) && !"".equals(FioriRebuildFilename)) {
						String extension=Hana_Profiler_Constant.XLSX_EXTENSTION_CONSTANT;
						String fileExtension = FioriRebuildFilename.substring(FioriRebuildFilename.length() - extension.length(),FioriRebuildFilename.length());
						if (extension.equalsIgnoreCase(fileExtension)) {
							logger.info("Matched Extension");
							byte[] bytes = file.getBytes();
							Path path = Paths.get(filePath + File.separator + FioriRebuildFilename);
							Files.write(path, bytes);
							logger.info("Wrote in file path **");
						} else {
							redirectAttributes.addFlashAttribute("fileException", "Please Upload the file with .xlsx extension only.");
							return "redirect:/admin/simplificationN";
						}
					} else {
						redirectAttributes.addFlashAttribute("fileException", "Please Upload atleast one file.");
						return "redirect:/admin/simplificationN";
					}
				} catch (UploadFilesNotValidException exception) {
					redirectAttributes.addFlashAttribute("fileException", "The filename is not correct.");
					return "redirect:/admin/simplificationN";
				} catch (Exception exception) {
					redirectAttributes.addFlashAttribute("fileException", exception.getMessage());
					return "redirect:/admin/simplificationN";
				}
		
		List<String> missingFiles = new ArrayList<String>();
		
		try {
			InitialDataValidation initialDataValidation = new InitialDataValidation(filePath);
			CheckFileListStatus checkObject = new CheckFileListStatus(filePath);

			boolean checkListStatus = true;

			Map<String, String> filesNameWithStatus = checkObject.validateFiles("Fiori_Rebuild_Master", filePath);
			Iterator<String> listKeysIterator = filesNameWithStatus.keySet().iterator();
			Map<String, String> tempMap = new HashMap<>();
			while (listKeysIterator.hasNext()) {
				String checkListName = listKeysIterator.next();
				// If the files is not present corresponding to checkList.
				if (!(filesNameWithStatus.get(checkListName)).equalsIgnoreCase("VALID")) {
					// If all the required files are not present then, add the missing files.
					checkListStatus = false;
					missingFiles.add(checkListName);
				} else {
					for (Map.Entry<String, String> entry : fileList.entrySet()) {
						if (entry.getKey().startsWith(checkListName.toUpperCase())) {
							tempMap.put(entry.getKey(), "VALID");
						}
					}
				}
			}
			boolean isAnyInvalidFile = false;
			// At the end, make all the files that have unexpected name as invalid.
			for (Map.Entry<String, String> entry : fileList.entrySet()) {
				if (!tempMap.containsKey(entry.getKey())) {
					isAnyInvalidFile = true;
					if (fileList.get(entry.getKey()).equalsIgnoreCase("VALID")) {
						fileList.put(entry.getKey(), "INVALID FILE NAME.");
					}
				}
			}
			logger.info("after checkListStatus");

			// If all required file are present, then proceed for XLSX validation.
			try {
				if (initialDataValidation.validateAllFiles(fileList, "Fiori_Rebuild_Master")) {
					message = HANAUtility.getPropertyValue("testing.properties", "filelistokmessage");
					HANAUtility.changeRequestProgressValue(requestId, 10, message);
				} else {
					// Somehow validation of files have failed and instead of throwing an exception
					// it has returned false.
					logger.info("inside else block ");

					comments = HANAUtility.getPropertyValue("testing.properties", "filelistnotokmessage");
					redirectAttributes.addFlashAttribute("fileException", comments);
					return "redirect:/admin/simplificationN";

				}
				if (!checkListStatus || isAnyInvalidFile) {
					if (!missingFiles.isEmpty()) {
						comments = "Please upload " + missingFiles + " files for processing this request.";
						redirectAttributes.addFlashAttribute("fileException", comments);
						return "redirect:/admin/simplificationN";
					} else {
						comments = "Please upload valid files only";
						redirectAttributes.addFlashAttribute("fileException", comments);
						return "redirect:/admin/simplificationN";
					}
				}
			} catch (Exception e) {
				logger.error("In Exception catch: " + e.getMessage());
				logger.error("Error !!! " + e);
				redirectAttributes.addFlashAttribute("message", e.getMessage());
				return "redirect:/admin/simplificationN";
			}
		} finally {}

		try {
			HANAUtility.changeRequestProgressValue(requestId, 20, "Files Uploaded Successfully.");
			String comment = readFioriRebuildMasterData((filePath + File.separator + FioriRebuildFilename), requestId, request, session);
			if (comment.equalsIgnoreCase("success")) {
				HANAUtility.changeRequestProgressValue(requestId, 40, "Data Saved Successfully.");
				HANAUtility.changeRequestProgressValue(requestId, 100,
						"Fiori Rebuild uploaded successfully.");
				model.addAttribute("uploaded", "true");
				model.addAttribute("message", "Fiori Rebuild created successfully");
				return "admin/simplificationN";
			} else {
				redirectAttributes.addFlashAttribute("fileException", comment);
			}
		} catch (Exception e) {
			redirectAttributes.addFlashAttribute("fileException", e.getMessage());
			return "redirect:/admin/simplificationN";
		}
		return "redirect:/admin/simplificationN";

	}

	public String readFioriRebuildMasterData(final String path, final long requestId, HttpServletRequest request,
			HttpSession session) {
		logger.info("Coming inside readFioriRebuildMasterData");
		String comment = "Success";
		try {
			FileInputStream inputStream;
			File file = new File(path);
			inputStream = new FileInputStream(file);

			String fileName = file.getName();
			List<FioriRebuildMaster> fioriRebuildMasterList = new ArrayList<FioriRebuildMaster>();

			logger.info("Coming inside readFioriRebuildMasterData inputStream::::" + inputStream);
			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);

			for (Row row : reader) {
				if (row.getRowNum() > 0) {

					FioriRebuildMaster fioriRebuildMaster = new FioriRebuildMaster();
					
					int appIdIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("appId"));
					int appNameIndex = Integer
							.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("appName"));
					int availableVersionIndex = Integer
							.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("availableVersion"));
					int list_of_similar_aplicationsIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("list_of_similar_aplications"));
					int remarksIndex = Integer
							.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("remarks"));
					int versionCheckIndex = Integer
							.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("version.check"));
					
					// adding .trim() method
					fioriRebuildMaster.setAppId(row.getCell(appIdIndex) == null ? "" : row.getCell(appIdIndex).getStringCellValue().trim());
					fioriRebuildMaster.setAppName(row.getCell(appNameIndex) == null ? "" : row.getCell(appNameIndex).getStringCellValue().trim());
					fioriRebuildMaster.setAvailableVersion(
							(row.getCell(availableVersionIndex) == null ? "" : row.getCell(availableVersionIndex).getStringCellValue().trim()));
					fioriRebuildMaster.setList_of_similar_aplications(
							row.getCell(list_of_similar_aplicationsIndex) == null ? "" : row.getCell(list_of_similar_aplicationsIndex).getStringCellValue().trim());
					fioriRebuildMaster.setRemarks(row.getCell(remarksIndex) == null ? "" : row.getCell(remarksIndex).getStringCellValue().trim());
					fioriRebuildMaster.setVersionCheck(row.getCell(versionCheckIndex) == null ? "" : row.getCell(versionCheckIndex).getStringCellValue().trim());
					
					fioriRebuildMasterList.add(fioriRebuildMaster);

				}
			}

			// truncate table to do
			comment = s4ValidDao.fioriRebuildDataBatchInsertUpdate(fioriRebuildMasterList, session);
		} catch (Exception ex) {
			logger.error("Error in AdminSimplificationServiceImpl : readFioriRebuildMasterData()", ex);
		}
		return comment;
	}
}
