package com.accenture.admin.model;

public class SummaryAssessmentCount {
private String requestStatus;

private long countValue;

public String getRequestStatus() {
	return requestStatus;
}

public void setRequestStatus(String requestStatus) {
	this.requestStatus = requestStatus;
}

public long getCountValue() {
	return countValue;
}

public void setCountValue(long countValue) {
	this.countValue = countValue;
}
}
