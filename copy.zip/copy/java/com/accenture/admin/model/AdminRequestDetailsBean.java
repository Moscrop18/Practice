package com.accenture.admin.model;

public class AdminRequestDetailsBean {


	private long requestId;
	
	private String request_id_ui;	
	
	public String status;
	private String comments;
	private Long updatedDate;	
	private String assigned_poc_emailId;
	private String poc_status;
	private String poc_comments;
	private Boolean fiatScope;
	private Boolean otherScope;
	private Boolean soh;
	private Boolean s4Technical;
	private Boolean rfp;
	private Boolean sia;
	private Boolean osMig;
	private Boolean bwUsage;
	private Boolean bwTech;
	private Boolean grc;
	
	private Boolean EXT;
	
	public Boolean getGrc() {
		return grc;
	}
	public void setGrc(Boolean grc) {
		this.grc = grc;
	}
	
	public Boolean getBwUsage() {
		return bwUsage;
	}
	public void setBwUsage(Boolean bwUsage) {
		this.bwUsage = bwUsage;
	}
	public Boolean getBwTech() {
		return bwTech;
	}
	public void setBwTech(Boolean bwTech) {
		this.bwTech = bwTech;
	}
	public Boolean getOsMig() {
		return osMig;
	}
	public void setOsMig(Boolean osMig) {
		this.osMig = osMig;
	}
	public Boolean getSia() {
		return sia;
	}
	public void setSia(Boolean sia) {
		this.sia = sia;
	}
	public Boolean getRfp() {
		return rfp;
	}
	public void setRfp(Boolean rfp) {
		this.rfp = rfp;
	}
	private Boolean s4Functional;
	
	private Boolean ui5;
	
	private Boolean fiori;
	
	private Boolean upgrade; 
	
	private String endDate; 
	
	private String journeyCategory;
	private String assignedFaitEmailId;
	private String pocFiatStatus;
	private Long createdDate;
	
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getRequest_id_ui() {
		return request_id_ui;
	}
	public void setRequest_id_ui(String request_id_ui) {
		this.request_id_ui = request_id_ui;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public Long getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(Long updatedDate) {
		this.updatedDate = updatedDate;
	}
	public String getAssigned_poc_emailId() {
		return assigned_poc_emailId;
	}
	public void setAssigned_poc_emailId(String assigned_poc_emailId) {
		this.assigned_poc_emailId = assigned_poc_emailId;
	}
	public String getPoc_status() {
		return poc_status;
	}
	public void setPoc_status(String poc_status) {
		this.poc_status = poc_status;
	}
	public String getPoc_comments() {
		return poc_comments;
	}
	public void setPoc_comments(String poc_comments) {
		this.poc_comments = poc_comments;
	}
	
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public Boolean getFiatScope() {
		return fiatScope;
	}
	public void setFiatScope(Boolean fiatScope) {
		this.fiatScope = fiatScope;
	}
	public Boolean getOtherScope() {
		return otherScope;
	}
	public void setOtherScope(Boolean otherScope) {
		this.otherScope = otherScope;
	}
	public Boolean getSoh() {
		return soh;
	}
	public void setSoh(Boolean soh) {
		this.soh = soh;
	}
	public Boolean getS4Technical() {
		return s4Technical;
	}
	public void setS4Technical(Boolean s4Technical) {
		this.s4Technical = s4Technical;
	}
	public Boolean getS4Functional() {
		return s4Functional;
	}
	public void setS4Functional(Boolean s4Functional) {
		this.s4Functional = s4Functional;
	}
	public Boolean getUi5() {
		return ui5;
	}
	public void setUi5(Boolean ui5) {
		this.ui5 = ui5;
	}
	public Boolean getFiori() {
		return fiori;
	}
	public void setFiori(Boolean fiori) {
		this.fiori = fiori;
	}
	public Boolean getUpgrade() {
		return upgrade;
	}
	public void setUpgrade(Boolean upgrade) {
		this.upgrade = upgrade;
	}
	public String getJourneyCategory() {
		return journeyCategory;
	}
	public void setJourneyCategory(String journeyCategory) {
		this.journeyCategory = journeyCategory;
	}
	public String getAssignedFaitEmailId() {
		return assignedFaitEmailId;
	}
	public void setAssignedFaitEmailId(String assignedFaitEmailId) {
		this.assignedFaitEmailId = assignedFaitEmailId;
	}
	public Long getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Long createdDate) {
		this.createdDate = createdDate;
	}
	
	
	


	public String getPocFiatStatus() {
		return pocFiatStatus;
	}
	public void setPocFiatStatus(String pocFiatStatus) {
		this.pocFiatStatus = pocFiatStatus;
	}
	
	public Boolean getEXT() {
		return EXT;
	}
	public void setEXT(Boolean eXT) {
		EXT = eXT;
	}
	
	


}
