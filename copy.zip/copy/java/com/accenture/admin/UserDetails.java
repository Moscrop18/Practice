/**
 * CR 17: Added user details class to contain the information of User 
 * and corresponding User Role at one place.
 * 
 */
package com.accenture.admin;

public class UserDetails {	
	private String userName;
	private String emailId;
	private String userRole;
	private String accountValidTill;
	private boolean active;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	public String getAccountValidTill() {
		return accountValidTill;
	}
	public void setAccountValidTill(String accountValidTill) {
		this.accountValidTill = accountValidTill;
	}
	public boolean isActive() {
		return active;
	}
	public UserDetails(String userName, String emailId, String userRole, String accountValidTill, boolean active) {
		super();
		this.userName = userName;
		this.emailId = emailId;
		this.userRole = userRole;
		this.accountValidTill = accountValidTill;
		this.active = active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	
}
