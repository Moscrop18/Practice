package com.accenture.admin.dao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.accenture.admin.model.AdminRequestDetailsBean;
import com.accenture.admin.model.SummaryAssessmentCount;
import com.accenture.client.model.RequestForm;
import com.accenture.poc.dao.UserDAO;
import com.accenture.poc.model.User;

public interface AdminRequestMappingDAO {

	//public List<AdminRequestDetailsBean> getRequests(String status, Integer limit, Integer start);

	public List<AdminRequestDetailsBean> getOverdueRequests(String status, Integer limit, Integer start,
			String currentDate);

	public List<AdminRequestDetailsBean> getPendingRequest(String status, Integer limit, Integer start);

	public Integer getPendingRequestCount(String status);

	public Long getOverdueRequestCount(String status, String currentDate);

	public List<SummaryAssessmentCount> getSummaryAssessmentCount();

	public Integer getTotalRequestCount(String status);

	public void AssignPocDataStore(RequestForm form, String userName, String toolName, String valVersion);

	public void updatePocDataStore(RequestForm form);
	
	public List<AdminRequestDetailsBean> getRequestManagementRequests(Integer limit, Integer start);
	
	public Integer getRequestManagementRequestsCount();
	
	public Integer getUserStatusCount(String userStatus);

	public void UpdateRejectedStatus(long requestId);

	public List<User> getNewUserAccount(Integer limit, Integer start, String userId, String role, String project);

	public List<User> getInactiveUsers(String userStatus, String uiserId, String expiresOn, Integer limit,
			Integer start);
	
	public List<User> getActiveUsers(String userStatus, String uiserId, Integer limit, Integer start);

	public List<User> getExpireUsers(String userStatus, String uiserId, String expiresOn, Integer limit, Integer start);

	public void performActionOnUser(String userName, String userAction, String userRole, UserDAO userDao, HttpServletRequest request,
			HttpSession session) throws Exception;

	public List<AdminRequestDetailsBean> getCompletedRequests(String status, Integer limit, Integer start);

	public Integer getCompletedRequestCount();

	public Integer getCompletedPendingRequestCount();

	public List<AdminRequestDetailsBean> getCompletedWithPendingRequests(String status, Integer limit, Integer start);

	public Integer getActiveUserCount();

	public void changeUserRole(String userName, String userRole, UserDAO userDao, HttpServletRequest request,
				HttpSession session) throws Exception;
	
	public void updateClientUser(Long requestId, String user);
}
