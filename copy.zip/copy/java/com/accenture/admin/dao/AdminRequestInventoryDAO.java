package com.accenture.admin.dao;

import java.util.List;

import com.accenture.client.model.RequestFormDetailsBean;

public interface AdminRequestInventoryDAO {

	List<RequestFormDetailsBean> getInitiatedRequests(final int limit, final  int start, final String toolName, Long requestId);
	
	Integer getTotalInitiatedRequests(final String toolName);
	
	public void updateClientUserPocRequestMapping(Long requestId, String clientUser);
}
