package com.accenture.admin.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;

import com.accenture.client.model.RequestFormDetailsBean;
import com.accenture.client.model.RequestInventory;
import com.accenture.constant.Hana_Profiler_Constant;
import com.accenture.exceptions.HibernateException;
import com.accenture.poc.model.POCRequestMapping;

@Transactional
public class AdminRequestInventoryDAOImpl implements AdminRequestInventoryDAO {

	final public Logger logger = LoggerFactory.getLogger(AdminRequestInventoryDAOImpl.class);
	SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<RequestFormDetailsBean> getInitiatedRequests(final int limit, final int start, final String toolName, Long requestId) {
		try {
			final Session session = sessionFactory.getCurrentSession();

			final ProjectionList projection = Projections.projectionList();
			projection.add(Projections.property("requestForm.requestID"), "requestId");
			projection.add(Projections.property("requestForm.endDate"), "endDate");
			projection.add(Projections.property("requestForm.REQUEST_ID_UI"), "REQUEST_ID_UI");
			projection.add(Projections.property("requestInventory.requestShortdescription"), "shortDescription");
			projection.add(Projections.property("requestInventory.requestStatus"), "status");
			projection.add(Projections.property("requestInventory.comments"), "comments");
			projection.add(Projections.property("requestInventory.updatedDate"), "updatedDate");

			final Criteria criteria = session.createCriteria(RequestInventory.class, "requestInventory");
			criteria.createAlias("requestInventory.requestForm", "requestForm");
			criteria.add(Restrictions.eq("requestInventory.requestStatus", Hana_Profiler_Constant.INITIATED_STATUS));
			criteria.add(Restrictions.eq("toolName", toolName));
			criteria.setProjection(projection);
			criteria.addOrder(Order.asc("updatedDate"));
			criteria.setFirstResult(start);
			criteria.setMaxResults(limit);
			if (requestId != null) {
				criteria.add(Restrictions.eq("requestInventory.requestID", requestId));
			}
			criteria.setResultTransformer(Transformers.aliasToBean(RequestFormDetailsBean.class));
			return criteria.list();

		} catch (Exception e) {
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

		
	@Override
	public Integer getTotalInitiatedRequests(final String toolName) {
		try {
			final Session session = sessionFactory.getCurrentSession();

			final Criteria criteria = session.createCriteria(RequestInventory.class);
			criteria.add(Restrictions.eq("requestStatus", Hana_Profiler_Constant.INITIATED_STATUS));
			criteria.add(Restrictions.eq("toolName", toolName));
			criteria.setProjection(Projections.rowCount());
			return ((Long) criteria.uniqueResult()).intValue();

		} catch (Exception e) {
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	
	@Override
	public void updateClientUserPocRequestMapping(Long requestId, String clientUser) {
		try {
			final Session session = sessionFactory.getCurrentSession();
			final Criteria criteria = session.createCriteria(POCRequestMapping.class);
			criteria.add(Restrictions.eq("requestId", requestId));
			List<POCRequestMapping> poc = criteria.list();
			poc.get(0).setEmailId(clientUser);
			poc.get(0).setClientName(clientUser);
			poc.get(0).setUserName(clientUser);
			session.saveOrUpdate(poc.get(0));

		} catch (Exception e) {
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
}
