/*MODIFIED 
 *FOR Enhancement CR-1.0:-Update the automation_Status according to Sel_line-20/12/16 -monika.mishra
 *
 *CR-25.0- Few fields which will be moved to JAVA tool in HANA Profiler - 10/07/2017 - monika.mishra
 *
 * CR-26.0:-adding 3 New Sheets implementation -25/07/17-rohan.a.mehra
 * 
 *
 *
 *CR-28.0:- Add col Total Line Scanned and read & get data from Op-COde col-24/07/17 -monika.mishra
 *
 *CR-48:- Consolidated both the tool so that they can executed separately -monika.mishra
 *
 *CR-67: Usage Analysis Object Name value checks ,if special character value comes or null 
 *		then input will be "" otherwise as input from sheet uploaded.-19/3/2018-rohan.a.mehra
 *
 *US: Usage Analysis sheet new column Dialog Steps added -04/09/2018 -himani.malhotra
 *
 *DEF043: Remove code related to USEREXIT -28/02/2019 -himani.malhotra
 *
 **/
package com.accenture.reader.xlsx;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.map.HashedMap;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.util.IOUtils;
import org.drools.WorkingMemory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.accenture.Aadt.models.ACNIPZVERComp;
import com.accenture.Aadt.models.AuctFinalOutput;
import com.accenture.Aadt.models.BWExtractor;
import com.accenture.Aadt.models.ImpactedCloneAnalysis;
import com.accenture.Aadt.models.ImpactedVariant;
import com.accenture.Aadt.models.OSMigrationFinal;
import com.accenture.S4.constant.S4HanaProfilerConstant;
import com.accenture.S4.models.BwCleanupUtil;
import com.accenture.S4.models.CvitCustomisingLogs;
import com.accenture.S4.models.CvitErrorMessages;
import com.accenture.S4.models.GrtGracfuncact;
import com.accenture.S4.models.InactiveObjects;
import com.accenture.S4.models.InconsistentFUGR;
import com.accenture.S4.models.S4AppendStructureAnalysis;
import com.accenture.S4.models.S4CloneIntermediate;
import com.accenture.S4.models.S4CvitAssessment;
import com.accenture.S4.models.S4Detection;
import com.accenture.S4.models.S4EnhancementIntermediate;
import com.accenture.S4.models.S4ImpactedCustomTables;
import com.accenture.S4.models.S4ImpactedIDOC;
import com.accenture.S4.models.S4ImpactedSearchHelp;
import com.accenture.S4.models.S4ImpactedTables;
import com.accenture.S4.models.S4ImpactedTransaction;
import com.accenture.S4.models.S4InventoryList;
import com.accenture.S4.models.S4_SID;
import com.accenture.S4.models.S4cvitr;
import com.accenture.S4.models.SrcAgr1251;
import com.accenture.S4.models.SrcAgrUsers;
import com.accenture.S4.models.SrcUsobtc;
import com.accenture.S4.models.Unicode;
import com.accenture.Scripts.model.ImpactedScripts;
import com.accenture.UI5.models.UI5InputExtract;
import com.accenture.bw.dao.BwCleanUpDAO;
import com.accenture.bw.model.BwInventoryList;
import com.accenture.bw.model.RsantProcess;
import com.accenture.bw.model.RsantProcessr;
import com.accenture.bw.model.Rsbkdtp;
import com.accenture.bw.model.Rsbkdtpstat;
import com.accenture.bw.model.Rsbkrequest;
import com.accenture.bw.model.Rsbohdest;
import com.accenture.bw.model.Rsdcube;
import com.accenture.bw.model.Rsdiobj;
import com.accenture.bw.model.Rsds;
import com.accenture.bw.model.Rsiccont;
import com.accenture.bw.model.Rsldpio;
import com.accenture.bw.model.Rsohcpr;
import com.accenture.bw.model.Rspcchain;
import com.accenture.bw.model.Rspcchainattr;
import com.accenture.bw.model.Rspcprocesslog;
import com.accenture.bw.model.Rsqiset;
import com.accenture.bw.model.Rsrrepdir;
import com.accenture.bw.model.Rsrrworkbook;
import com.accenture.bw.model.Rsrwbindex;
import com.accenture.bw.model.Rstran;
import com.accenture.bw.model.Rsts;
import com.accenture.bw.model.Rsupdinfo;
import com.accenture.bw.model.Rszwbtmphead;
import com.accenture.bw.model.Rszwtemplate;
import com.accenture.bw.model.WebTemplate3;
import com.accenture.bw.model.WebTemplate7;
import com.accenture.client.dao.RequestFormDAO;
import com.accenture.client.model.Lsmw;
import com.accenture.client.model.RequestForm;
import com.accenture.client.model.UserExit;
import com.accenture.config.bean.CollectionsBean;
import com.accenture.constant.Hana_Profiler_Constant;
import com.accenture.constant.ST03HanaConstant;
import com.accenture.constant.Services_Constant;
import com.accenture.displaygrid.model.DBConfig;
import com.accenture.displaygrid.model.HanaProfile;
import com.accenture.displaygrid.model.TRDR_DATA;
import com.accenture.drools.helper.DroolsHelper;
import com.accenture.fileprocessing.PopulateHanaTables;
import com.accenture.fileprocessing.VerifyOutputSheet;
import com.accenture.fileprocessing.model.ComplexityRules;
import com.accenture.fileprocessing.model.ExtensionRules;
import com.accenture.fileprocessing.model.MetaData;
import com.accenture.fileprocessing.model.ST03Tadir;
import com.accenture.fileprocessing.model.UsageAnalysis;
import com.accenture.fileprocessing.model.UsageAnalysisExt;
import com.accenture.fiori.models.CustomReportOutput;
import com.accenture.fiori.models.St03NData;
import com.accenture.impactedBackgroundJob.ImpactedBackgroundJob;
import com.accenture.model.DRL.CodeAssessmentPayLoad;
import com.accenture.rfp.models.TADIRInventory;
import com.accenture.securityAnalyser.dao.SecurityAnalyserDAOimpl;
import com.accenture.smodilog.model.SmodilogFunction;
import com.accenture.testingscope.dao.TestingScopeDAO;
import com.accenture.testingscope.model.BusinessProcessDetail;
import com.accenture.testingscope.model.TestingScopeModel;
import com.accenture.testingscope.model.Testingscopepojo;
import com.monitorjbl.xlsx.StreamingReader;
import com.rometools.utils.Strings;

public class St03ReaderXlsx extends ConsolidateReaderXlsx {
	List<Lsmw> lsmwList = null;
	List<UsageAnalysis> usageAnalysisList = null;
	Set<String> usageAnalysisObjNameType = null;
	Set<String> usageAnalysisObjNameTypeReadProg = null;
	List<St03NData> st03nDataList = null;
	List<S4InventoryList> inventoryList = null;
	private RequestFormDAO requestDetails;
	static List<UI5InputExtract> UI5InputList = new ArrayList<UI5InputExtract>();;
	static List<Testingscopepojo> tscopeList = null;

	// static List<OdataFioriApps> odataFioriAppsList = null;
	static List<CustomReportOutput> customReportOutputList = null;

	static List<ImpactedBackgroundJob> impactedBackgroundJobList = null;
	static List<ImpactedBackgroundJob> impactedBackgroundJobListIntermediate = null;

	static List<ImpactedScripts> impactedScriptsList = null;
	static List<ImpactedScripts> impactedScriptsListIntermediate = null;

	public static List<ImpactedScripts> getImpactedScriptsList() {
		return impactedScriptsList;
	}

	public static void setImpactedScriptsList(List<ImpactedScripts> impactedScriptsList) {
		St03ReaderXlsx.impactedScriptsList = impactedScriptsList;
	}

	public static List<ImpactedBackgroundJob> getImpactedBackgroundJobList() {
		return impactedBackgroundJobList;
	}

	public static void setImpactedBackgroundJobList(List<ImpactedBackgroundJob> impactedBackgroundJobList) {
		St03ReaderXlsx.impactedBackgroundJobList = impactedBackgroundJobList;
	}

	public static List<CustomReportOutput> getCustomReportOutputList() {
		return customReportOutputList;
	}

	public static void setCustomReportOutputList(List<CustomReportOutput> customReportOutputList) {
		St03ReaderXlsx.customReportOutputList = customReportOutputList;
	}

	// public static List<OdataFioriApps> getOdataFioriAppsList() {
	// return odataFioriAppsList;
	// }

	// public static void setOdataFioriAppsList(List<OdataFioriApps>
	// odataFioriAppsList) {
	// St03ReaderXlsx.odataFioriAppsList = odataFioriAppsList;
	// }

	public static List<Testingscopepojo> getTscopeList() {
		return tscopeList;
	}

	public static void setTscopeList(List<Testingscopepojo> tscopeList) {
		St03ReaderXlsx.tscopeList = tscopeList;
	}

	public static List<UI5InputExtract> getUI5InputList() {
		return UI5InputList;
	}

	public static void setUI5InputList(List<UI5InputExtract> uI5InputList) {
		UI5InputList = uI5InputList;
	}

	public void setRequestDetails(final RequestFormDAO requestDetails) {
		this.requestDetails = requestDetails;
	}

	public RequestFormDAO getRequestDetails() {
		return requestDetails;
	}

	static CodeAssessmentPayLoad hm = new CodeAssessmentPayLoad();

	public static CodeAssessmentPayLoad getHm() {
		return hm;
	}

	public void setHm(CodeAssessmentPayLoad hm) {
		this.hm = hm;
	}

	final static Logger logger = LoggerFactory.getLogger(St03ReaderXlsx.class);

	private PopulateHanaTables populateHanaTable;
	private VerifyOutputSheet verifyOutput;

	private SecurityAnalyserDAOimpl secAnalyseDao;

	@Autowired
	private BwCleanUpDAO bwCleanDao;
	@Autowired
	private RequestFormDAO requestFormDao;

	public SecurityAnalyserDAOimpl getSecAnalyseDao() {
		return secAnalyseDao;
	}

	@Autowired
	public void setSecAnalyseDao(SecurityAnalyserDAOimpl secAnalyseDao) {
		this.secAnalyseDao = secAnalyseDao;
	}

	public void setVerifyOutput(VerifyOutputSheet verifyOutput) {
		this.verifyOutput = verifyOutput;
	}

	public void setPopulateHanaTable(PopulateHanaTables populateHanaTable) {
		this.populateHanaTable = populateHanaTable;
	}

	public void addOperationData() {
		hm.setResultMap(populateHanaTable.getOperationValuesdb());
	}

	@Autowired
	private TestingScopeDAO testingScopeDao;

	@Autowired
	private CollectionsBean collectionBean;

	public CollectionsBean getCollectionBean() {
		return collectionBean;
	}

	public void setCollectionBean(CollectionsBean collectionBean) {
		this.collectionBean = collectionBean;
	}

	protected void addZAICATDetectionData(final String path, final long requestId, String toolName, HttpSession session,
			RequestForm requestForm) throws Exception {
		File file = new File(path);
		InputStream inputStream = new FileInputStream(file);
		logger.info("populateHanaTable::::::" + populateHanaTable);
		int rowCount = 0;

		String status, comments;
		boolean scopeHana = requestForm.getSOH();
		boolean scopeS4 = requestForm.getS4Technical();
		boolean scopeFIAT = requestForm.getS4Functional();
		boolean scopeUI5 = requestForm.getUI5();
		boolean scopeFiori = requestForm.getFiori();
		boolean scopeAUCT = requestForm.getUPGRADE();
		boolean scopeOSMigration = requestForm.getOsMig();

		String fileName = file.getName();

		List<String> externalNamespaceList = null;

		if (StringUtils.isNotEmpty(requestForm.getExternalNamespace())) {
			externalNamespaceList = new ArrayList<>(Arrays.asList(requestForm.getExternalNamespace().split(",")));
		}

		try {
			// odataFioriAppsList = new ArrayList<OdataFioriApps>();
			// List<HanaProfilerStepOutput> hanaProfileStepOutputList = new
			// ArrayList<HanaProfilerStepOutput>();
			List<CustomReportOutput> customReportOutputList = new ArrayList<CustomReportOutput>();
			List<HanaProfile> hanaProfileList = new ArrayList<HanaProfile>();
			List<S4Detection> s4DetectionList = new ArrayList<S4Detection>();
			List<S4_SID> s4SIDList = new ArrayList<>();
			List<S4cvitr> cvitrList = new ArrayList<S4cvitr>();
			List<AuctFinalOutput> auctList = new ArrayList<AuctFinalOutput>();
			List<InconsistentFUGR> inconsistentFUGRsList = new ArrayList<>();
			List<S4ImpactedSearchHelp> s4ImpactedList = new ArrayList<S4ImpactedSearchHelp>();
			List<String> uniqueKeyList = new ArrayList<String>();
			CodeAssessmentPayLoad ca = new CodeAssessmentPayLoad();
			tscopeList = new ArrayList<Testingscopepojo>();

			impactedBackgroundJobList = new ArrayList<ImpactedBackgroundJob>();
			impactedBackgroundJobListIntermediate = new ArrayList<ImpactedBackgroundJob>();

			List<S4CvitAssessment> s4CvitList = new ArrayList<S4CvitAssessment>();
			Set<String> objNameSet = new HashSet<String>();

			List<OSMigrationFinal> osMigrationFinlList = new ArrayList<>();

			ImpactedBackgroundJob impactedBackJob = new ImpactedBackgroundJob();

			Testingscopepojo tscope = new Testingscopepojo();

			ImpactedScripts impactedScripts = new ImpactedScripts();
			impactedScriptsList = new ArrayList<ImpactedScripts>();
			impactedScriptsListIntermediate = new ArrayList<ImpactedScripts>();

			List<ImpactedVariant> impactedVariantList = new ArrayList<>();
			List<S4EnhancementIntermediate> s4EnhancementIntermediateList = new ArrayList<S4EnhancementIntermediate>();
			List<S4ImpactedIDOC> s4ImpactedIDOCList = new ArrayList<S4ImpactedIDOC>();
			List<S4ImpactedTables> s4ImpactedTableList = new ArrayList<S4ImpactedTables>();
			List<BwCleanupUtil> bwCleanUpUtilList = new ArrayList<BwCleanupUtil>();
			List<S4ImpactedCustomTables> s4ImpactedCustTablesList = new ArrayList<S4ImpactedCustomTables>();
			List<S4Detection> newList = new ArrayList<S4Detection>();
			List<CvitCustomisingLogs> cvitCustomLogsList = new ArrayList<>();
			List<CvitErrorMessages> cvitErrorMsgsList = new ArrayList<>();

			List<TestingScopeModel> irpaTScopeList = getCollectionBean().getIrpaTScopeList();

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);

			for (Row r : reader) {
				if (r.getRowNum() > 0) {
					rowCount = rowCount + 1;
					logger.info(
							"File--" + fileName + "-----RowNum---" + r.getRowNum() + "Table Row Count---" + rowCount);

					int indentifierIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Operation.Code"));
					String identifierCellVal = r.getCell(indentifierIndex) == null ? ""
							: r.getCell(indentifierIndex).getStringCellValue().replaceAll("\\s", StringUtils.EMPTY);

					if (identifierCellVal.startsWith("&301")) {
						ImpactedVariant impactedVariantData = getImpactedVariant(r, requestId, fileName,
								externalNamespaceList);
						if (impactedVariantData != null)
							impactedVariantList.add(impactedVariantData);
					} else if (identifierCellVal.startsWith("&314")) {
						BwCleanupUtil beCleanUtil = getBwCleanupUtil(r, requestId, fileName);
						if (beCleanUtil != null) {
							bwCleanUpUtilList.add(beCleanUtil);
						}
					} else {
						if (scopeHana) {
							HanaProfile hanaProfile = addListwithLoopValueXlsx(r, rowCount, requestId, fileName,
									externalNamespaceList);
							if (hanaProfile != null) {
								if (!(hanaProfile.getObject_Type().equalsIgnoreCase("LSMW")
										&& hanaProfile.getReadProgram().equalsIgnoreCase("/SAPDMC/SAP_LSMW_CONV_FORMS")
										&& hanaProfile.getSub_Type().equalsIgnoreCase("INITIALIZATIONS"))) {
									hanaProfileList.add(hanaProfile);
								}
							}

						}

						if (scopeS4 || requestForm.getBwTech()) {
							S4Detection s4Detection = getDetectionValueXlsx(r, requestId, fileName,
									hm.getUsageAnalysisObjNameType(), hm.getUsageAnalysisObjNameTypeReadProg(),
									externalNamespaceList);

							if (s4Detection != null) {
								if (uniqueKeyList.isEmpty() || !uniqueKeyList.contains(s4Detection.getUniqueKey())) {
									uniqueKeyList.add(s4Detection.getUniqueKey());
									s4DetectionList.add(s4Detection);

								}
							}

							int operationIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE
									.get(requestId).get(fileName).get("Act.Status"));
							String operation = r.getCell(operationIndex) == null ? ""
									: r.getCell(operationIndex).getStringCellValue().trim();
							if ("CUSTOM TABLES".equalsIgnoreCase(operation)) {
								S4ImpactedCustomTables s4ImpactCusttable = getS4ImpactedCustomTableValues(r, requestId,
										fileName);
								if (null != s4ImpactCusttable) {
									s4ImpactedCustTablesList.add(s4ImpactCusttable);
								}
							}

							// Drill Down Report
							if (identifierCellVal.startsWith("{") && "DRILLDOWN REPORT".equalsIgnoreCase(operation)) {
								List<S4Detection> s4DetectList = getS4DrillDownValues(r, requestId, fileName);
								newList.addAll(s4DetectList);
							}

							// CVIT & CVITR
							S4cvitr CVITR = getCVITRValueXlsx(r, requestId, fileName);
							if (CVITR != null) {
								cvitrList.add(CVITR);
							}

							S4CvitAssessment s4CvitAssessment = getCvitAssessment(r, requestId, fileName);
							if (s4CvitAssessment != null) {
								s4CvitList.add(s4CvitAssessment);
								objNameSet.add(s4CvitAssessment.getObjName());
							}

							// Cvit customising logs
							CvitCustomisingLogs cvitCustLogs = getCvitCustomLogs(r, requestId, fileName);
							if (!Objects.isNull(cvitCustLogs))
								cvitCustomLogsList.add(cvitCustLogs);

							// Cvit error messages in detail
							CvitErrorMessages cvitErrorMsgs = getCvitErrorMessages(r, requestId, fileName);
							if (!Objects.isNull(cvitErrorMsgs))
								cvitErrorMsgsList.add(cvitErrorMsgs);

							// Inconsistent FUGRs
							InconsistentFUGR inconsistentFUGR = createListForInconsistentFUGRs(r, requestId, fileName,
									externalNamespaceList);
							if (inconsistentFUGR != null)
								inconsistentFUGRsList.add(inconsistentFUGR);

							// Impacted Search Help
							if (identifierCellVal.startsWith("&310")) {
								S4ImpactedSearchHelp s4Impacted = getImpactedSearchValueXlsx(r, requestId, fileName,
										externalNamespaceList);
								if (s4Impacted != null) {
									s4ImpactedList.add(s4Impacted);
								}
							}

							// Impacted IDOC
							if (identifierCellVal.startsWith("&311")) {
								S4ImpactedIDOC s4ImpactedIDOCIntermediate = getImpactedIDOCXlsx(r, requestId, fileName);
								if (s4ImpactedIDOCIntermediate != null) {
									s4ImpactedIDOCList.add(s4ImpactedIDOCIntermediate);
								}
							}

							if (identifierCellVal.startsWith("&313")) {
								S4EnhancementIntermediate s4EnhancementIntermediate = getEnhancementValueXlsx(r,
										requestId, fileName);
								if (s4EnhancementIntermediate != null) {
									s4EnhancementIntermediateList.add(s4EnhancementIntermediate);
								}
							}

							if (identifierCellVal.startsWith("&303")) {
								S4ImpactedTables s4ImpactedTables = getImpactedTablesValueXlsx(r, requestId, fileName);
								if (s4ImpactedTables != null) {
									s4ImpactedTableList.add(s4ImpactedTables);
								}
							}

						}

						if (scopeUI5) {
							getUI5ValueXlsx(r, rowCount, requestId, fileName);
						}

						// AUCT
						// Implementation:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
						// ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
						if (scopeAUCT) {
							AuctFinalOutput auctOutput = getAuctValueXlsx(r, requestId, fileName,
									hm.getUsageAnalysisObjNameType(), hm.getUsageAnalysisObjNameTypeReadProg(),
									externalNamespaceList);

							if (auctOutput != null) {
								auctList.add(auctOutput);
							}

						}

						if (scopeHana || scopeS4 || scopeAUCT || requestForm.getBwTech()) {
							// Testing Scope
							tscope = createListforTscope(r, requestId, fileName);
							if (tscope != null) {
								tscopeList.add(tscope);
							}

							// IRPA - Testing Scope
							TestingScopeModel tscopeObj = createListIRPA(r, requestId, fileName);
							if (tscopeObj != null)
								irpaTScopeList.add(tscopeObj);

							// Impacted Background Jobs
							impactedBackJob = createListforImpactedBackJob(r, requestId, fileName,
									externalNamespaceList);
							if (impactedBackJob != null)
								impactedBackgroundJobListIntermediate.add(impactedBackJob);

							// Impacted Scripts:::::::::::
							impactedScripts = createListforImpactedScripts(r, requestId, fileName,
									externalNamespaceList);
							if (impactedScripts != null)
								impactedScriptsListIntermediate.add(impactedScripts);
						}

						if (scopeFiori) {
							// OdataFioriApps odataFioriApps =
							// getOdataFioriApps(r, requestId, fileName);
							CustomReportOutput customReportOutput = getZaicatDetectionData(r, requestId, fileName);

							if (customReportOutput != null) {
								customReportOutputList.add(customReportOutput);
							}
						}

						if (scopeOSMigration) {
							OSMigrationFinal osMigrationFinal = addOSMigarationList(r, rowCount, requestId, fileName,
									hm.getUsageAnalysisObjNameType(), hm.getUsageAnalysisObjNameTypeReadProg(),
									externalNamespaceList);
							if (osMigrationFinal != null)
								osMigrationFinlList.add(osMigrationFinal);

						}
						if (scopeHana || scopeS4 || scopeAUCT || requestForm.getBwTech() || scopeOSMigration) {
							if (identifierCellVal.startsWith("&316")) {
								S4_SID s4SID = getS4SID(identifierCellVal, r, requestId, fileName,
										hm.getUsageAnalysisObjNameType(), hm.getUsageAnalysisObjNameTypeReadProg(),
										externalNamespaceList);
								if (s4SID != null)
									s4SIDList.add(s4SID);
							}
							if (identifierCellVal.startsWith("&317")) {
								S4_SID s4SID = getS4SID(identifierCellVal, r, requestId, fileName,
										hm.getUsageAnalysisObjNameType(), hm.getUsageAnalysisObjNameTypeReadProg(),
										externalNamespaceList);
								if (s4SID != null)
									s4SIDList.add(s4SID);
							}
						}
					}
				}
			}

			Set<String> set = new HashSet<>();
			if (impactedBackgroundJobListIntermediate != null && !impactedBackgroundJobListIntermediate.isEmpty()) {
				for (ImpactedBackgroundJob jobList : impactedBackgroundJobListIntermediate) {
					if (!set.contains(jobList.getObjectName())) {
						set.add(jobList.getObjectName());
						impactedBackgroundJobList.add(jobList);
					}
				}
				impactedBackgroundJobBatchInsertUpdate(impactedBackgroundJobList, session);
			}

			// Impacted SAP Scripts::::::::::
			Set<String> scriptSet = new HashSet<>();
			if (CollectionUtils.isNotEmpty(impactedScriptsListIntermediate)) {
				for (ImpactedScripts scriptsList : impactedScriptsListIntermediate) {
					if (!scriptSet.contains(scriptsList.getObjNameTypeStatus())) {
						set.add(scriptsList.getObjNameTypeStatus());
						impactedScriptsList.add(scriptsList);
					}
				}

				impactedScriptsBatchInsertUpdate(impactedScriptsList, session);
			}

			// below three lines added for rule implementation
			if (hanaProfileList != null && !hanaProfileList.isEmpty()) {
				hm.setListOfHanaProfile(hanaProfileList);
			}

			Set<S4Detection> uniqueSet = new HashSet<S4Detection>(newList);
			s4DetectionList.addAll(uniqueSet);
			hm.setS4DetectionList(s4DetectionList);

			/*
			 * if ((cvitrList != null && !cvitrList.isEmpty()) || (s4CvitList !=
			 * null && !s4CvitList.isEmpty())) { hm.setS4cvitrList(cvitrList);
			 * if (objNameSet.size() == 53 && !objNameSet.contains("")) {
			 * requestForm.setCVIT(true);
			 * requestFormDao.updateCvit(requestForm);
			 * hm.setS4CvitAssessmentList(s4CvitList);
			 * hm.setS4cvitrList(cvitrList); } else { throw new
			 * Exception("Size of the cvit list is not correct"); } }
			 */
			if (cvitrList != null && !cvitrList.isEmpty()) {
				hm.setS4cvitrList(cvitrList);
				requestForm.setCVIT(true);
				requestFormDao.updateCvit(requestForm);
			}
			if (s4CvitList != null && !s4CvitList.isEmpty()) {
				if (objNameSet.size() == 49 && !objNameSet.contains("")) {
					requestForm.setCVIT(true);
					requestFormDao.updateCvit(requestForm);
					hm.setS4CvitAssessmentList(s4CvitList);
				} else {
					throw new Exception("Size of the cvit list is not correct");
				}
			}

			if (auctList != null && !auctList.isEmpty()) {
				hm.setAuctList(auctList);
			}

			if (customReportOutputList != null && !customReportOutputList.isEmpty()) {
				St03ReaderXlsx.setCustomReportOutputList(customReportOutputList);
			}

			if (osMigrationFinlList != null && !osMigrationFinlList.isEmpty())
				hm.setOsMigrationList(osMigrationFinlList);

			if (inconsistentFUGRsList != null && !inconsistentFUGRsList.isEmpty())
				inconsistentFUGRInsert(inconsistentFUGRsList, session);

			if (s4SIDList != null && !s4SIDList.isEmpty())
				s4SIDInsert(s4SIDList, session);

			if (impactedVariantList != null && !impactedVariantList.isEmpty())
				impactedVariantInsert(impactedVariantList, session);

			verifyOutput.setHanaProfilerExcelData(hanaProfileList);
			verifyOutput.setRequestId(requestId);
			verifyOutput.setHanaFilePath(path);

			s4DetectionBatchInsertUpdate(s4DetectionList, session);
			s4CVITRBatchInsertUpdate(cvitrList, session);
			UI5BatchInsertUpdate(UI5InputList, session);
			s4CvitAssessmentBatchInsert(s4CvitList, session);
			aUCTBatchInsertUpdate(auctList, session);
			s4ImpactedSearchBatchInsertUpdate(s4ImpactedList, session);
			enhancementBatchInsertUpdate(s4EnhancementIntermediateList, session);
			s4ImpactedIDOCBatchInsertUpdate(s4ImpactedIDOCList, session);
			s4ImpactedTableBatchInsertUpdate(s4ImpactedTableList, session);
			bwCleanupUtilBatchInsertUpdate(bwCleanUpUtilList, session);
			s4ImpactedCustomTablesBatchInsertUpdate(s4ImpactedCustTablesList, session);
			if (CollectionUtils.isNotEmpty(cvitCustomLogsList)) {
				insertCvitCustomLogs(cvitCustomLogsList, session, requestId);
			}

			if (CollectionUtils.isNotEmpty(cvitErrorMsgsList)) {
				insertCvitErrorMessagesList(cvitErrorMsgsList, session, requestId);
			}
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
	}

	public TADIRInventory addTadirData(final String path, final long requestId, String toolName, HttpSession session,
			RequestForm requestForm) throws Exception {
		File file = new File(path);
		InputStream inputStream = new FileInputStream(file);
		logger.info("populateHanaTable::::::" + populateHanaTable);
		// int rowCount =populateHanaTable.getRowCount(requestId);
		int rowCount = 0;

		Map<String, Integer> count = new HashedMap();
		count.put("Classes", 0);
		count.put("Programs", 0);
		count.put("Enhancement", 0);
		count.put("LSMW", 0);
		count.put("FunctionGroup", 0);
		count.put("Forms", 0);
		count.put("UserExits", 0);
		count.put("Workflow", 0);
		count.put("Interfaces", 0);
		count.put("WebDynpro", 0);

		String fileName = file.getName();
		try {
			TADIRInventory tadirInventory = new TADIRInventory();
			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);

			for (Row r : reader) {
				if (r.getRowNum() > 0) {
					rowCount = rowCount + 1;
					logger.info(
							"File--" + fileName + "-----RowNum---" + r.getRowNum() + "Table Row Count---" + rowCount);
					getTadirValueXlsx(r, requestId, fileName, count);
				}
				tadirInventory.setRequestID(requestId);
				tadirInventory.setClasses(count.get("Classes"));
				tadirInventory.setPrograms(count.get("Programs"));
				tadirInventory.setEnhancements(count.get("Enhancement"));
				tadirInventory.setLsmw(count.get("LSMW"));
				tadirInventory.setFunctionGroups(count.get("FunctionGroup"));
				tadirInventory.setForm(count.get("Forms"));
				tadirInventory.setUserExists(count.get("UserExits"));
				tadirInventory.setWorkflow(count.get("Workflow"));
				tadirInventory.setInterfaces(count.get("Interfaces"));
				tadirInventory.setWebDynpro(count.get("WebDynpro"));
				tadirInventory.setRicefwCount(0);
			}
			return tadirInventory;
		} finally {
			IOUtils.closeQuietly(inputStream);
		}

	}

	protected void getUI5ValueXlsx(final Row r, int rowId, final Long requestId, String fileName) {

		int indentifierIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Operation.Code"));
		String identifierCellVal = r.getCell(indentifierIndex) == null ? ""
				: r.getCell(indentifierIndex).getStringCellValue().replaceAll("\\s", StringUtils.EMPTY);
		if (identifierCellVal.startsWith("XU")) {

			int UIControlIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name"));
			int attributeIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Code"));
			int FileNameIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sub.Type"));
			int ProjectNameIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Operation"));

			String[] splitArr;
			int LineNumber = 0;
			int Counter;

			if (identifierCellVal.startsWith("XUI5")) {

				splitArr = identifierCellVal.split("X");
				if (splitArr.length == 3) {
					Counter = Integer.parseInt(splitArr[1].substring(3));
					LineNumber = Integer.parseInt(splitArr[2]);
				} else {
					Counter = 0;
					LineNumber = 0;
				}

			}

			String UIControl = r.getCell(UIControlIndex) == null ? ""
					: r.getCell(UIControlIndex).getStringCellValue().trim();
			String attribute = r.getCell(attributeIndex) == null ? ""
					: r.getCell(attributeIndex).getStringCellValue().trim();
			String FileName = r.getCell(FileNameIndex) == null ? ""
					: r.getCell(FileNameIndex).getStringCellValue().trim();
			String ProjectName = r.getCell(ProjectNameIndex) == null ? ""
					: r.getCell(ProjectNameIndex).getStringCellValue().trim();

			UI5InputExtract UI5InputExtractObj = new UI5InputExtract();

			UI5InputExtractObj.setUielemt(UIControl);
			UI5InputExtractObj.setAttribute(attribute);
			UI5InputExtractObj.setLinenumber(LineNumber);
			UI5InputExtractObj.setFilename(FileName);
			UI5InputExtractObj.setProjectName(ProjectName);
			UI5InputExtractObj.setREQUEST_ID(requestId);

			UI5InputList.add(UI5InputExtractObj);

		}
	}

	/*
	 * private HanaProfile addListwithLoopValueXlsx(final Row row, int rowId,
	 * final Long requestID, String fileName) {
	 * 
	 * final HanaProfile model = new HanaProfile();
	 * 
	 * int subPrgIndex = Integer
	 * .parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(
	 * fileName).get("Sub.program")); int subTypeIndex = Integer
	 * .parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(
	 * fileName).get("Sub.Type")); int readPrgIndex = Integer
	 * .parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(
	 * fileName).get("Read.Prog")); int lineNoIndex = Integer
	 * .parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(
	 * fileName).get("Line.No")); int levelIndex = Integer
	 * .parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(
	 * fileName).get("Levels")); int tableIndex = Integer
	 * .parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(
	 * fileName).get("Tables")); int joinIndex = Integer
	 * .parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(
	 * fileName).get("Joins")); int tableTypeIndex = Integer
	 * .parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(
	 * fileName).get("Table.Type")); int keyIndex = Integer
	 * .parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(
	 * fileName).get("Keys")); int wherConIndex = Integer
	 * .parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(
	 * fileName).get("Where.Con")); int joinTypeIndex = Integer
	 * .parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(
	 * fileName).get("Join.Type")); int loopsIndex = Integer
	 * .parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(
	 * fileName).get("LOOPS")); int infoIndex = Integer
	 * .parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(
	 * fileName).get("INFO"));
	 * 
	 * // col25 int selLineIndex = Integer
	 * .parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(
	 * fileName).get("Sel.Line")); // CR-25.0 int codeIndex = Integer
	 * .parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(
	 * fileName).get("CODE"));
	 * 
	 * // col26 int oDataIndex = Integer
	 * .parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(
	 * fileName).get("Odata"));
	 * 
	 * model.setSub_Program(row.getCell(subPrgIndex) == null ? "" :
	 * row.getCell(subPrgIndex).getStringCellValue());
	 * model.setSub_Type(row.getCell(subTypeIndex) == null ? "" :
	 * row.getCell(subTypeIndex).getStringCellValue());
	 * model.setReadProgram(row.getCell(readPrgIndex) == null ? "" :
	 * row.getCell(readPrgIndex).getStringCellValue());
	 * model.setLine_Number((int) Double.parseDouble(row.getCell(lineNoIndex) ==
	 * null ? "0" :
	 * row.getCell(lineNoIndex).getStringCellValue().replaceAll("\\.0",
	 * "").replace(".", "").replace(",", "")));
	 * 
	 * String level = (row.getCell(levelIndex) == null) ? "0" :
	 * row.getCell(levelIndex).getStringCellValue(); if ("".equals(level)) {
	 * level = "0"; }
	 * 
	 * 
	 * model.setLevels(getParsedValue(level, fileName, rowId, levelIndex));
	 * 
	 * 
	 * model.setTables(row.getCell(tableIndex) == null ? "" :
	 * row.getCell(tableIndex).getStringCellValue());
	 * model.setJoins(row.getCell(joinIndex) == null ? "" :
	 * row.getCell(joinIndex).getStringCellValue()); model.setTable_Type(
	 * row.getCell(tableTypeIndex) == null ? "" :
	 * row.getCell(tableTypeIndex).getStringCellValue());
	 * model.setKeys(row.getCell(keyIndex) == null ? "" :
	 * row.getCell(keyIndex).getStringCellValue()); model.setWhere_Condition(
	 * row.getCell(wherConIndex) == null ? "" :
	 * row.getCell(wherConIndex).getStringCellValue());
	 * model.setJoin_Type(row.getCell(joinTypeIndex) == null ? "" :
	 * row.getCell(joinTypeIndex).getStringCellValue());
	 * model.setLoop(row.getCell(loopsIndex) == null ? "" :
	 * row.getCell(loopsIndex).getStringCellValue());
	 * model.setInfo(row.getCell(infoIndex) == null ? "" :
	 * row.getCell(infoIndex).getStringCellValue()); // CR-25.0
	 * model.setCode(row.getCell(codeIndex) == null ? "" :
	 * row.getCell(codeIndex).getStringCellValue());
	 * model.setRequestID(requestID); model.setJoinID(rowId);
	 * 
	 * // col25 model.setSel_Line((int) Double.parseDouble(
	 * (row.getCell(selLineIndex) == null ||
	 * row.getCell(selLineIndex).getStringCellValue().isEmpty()) ? "0" :
	 * row.getCell(selLineIndex).getStringCellValue().replaceAll("\\.0",
	 * "").replace(".", "") .replace(",", ""))); // col26
	 * model.setOdata(row.getCell(oDataIndex) == null ? "" :
	 * row.getCell(oDataIndex).getStringCellValue()); return model;
	 * 
	 * 
	 * }
	 */

	/*
	 * private int getParsedValue(String value, String fileName, int rowId, int
	 * levelIndex) {
	 * 
	 * try{ return (int) Double.parseDouble(value); }
	 * catch(NumberFormatException e){ throw new
	 * ST03DataAnalysisException(fileName, ++rowId, ++levelIndex); } }
	 */

	/*
	 * private HanaProfilerStepOutput getHanaProfilerStepOutputData(final Row
	 * row,int rowId,final Long requestID,String fileName) {
	 * 
	 * 
	 * 
	 * HanaProfilerStepOutput hanaProfilerStepOutput = new
	 * HanaProfilerStepOutput();
	 * 
	 * int onjNameIndex=
	 * Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).
	 * get( fileName).get("Obj.Name")); int typeIndex=
	 * Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).
	 * get( fileName).get("Type")); int opCodeIndex=
	 * Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).
	 * get( fileName).get("Operation.Code"));
	 * 
	 * 
	 * //int codeIndex=
	 * Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).
	 * get( fileName).get("CODE"));
	 * 
	 * hanaProfilerStepOutput.setObjName(row.getCell(onjNameIndex)==null
	 * ?"":row.getCell(onjNameIndex).getStringCellValue().trim());
	 * hanaProfilerStepOutput.setObjectType(row.getCell(typeIndex)==null?"":row.
	 * getCell(typeIndex).getStringCellValue()); //CR-28.0 String[] splitArr;
	 * String opCode = ""; int lineNo = 0; String totalScannedLines=""; String
	 * opcodeCellVal=row.getCell(opCodeIndex)==null?"":row.getCell(opCodeIndex).
	 * getStringCellValue(); if(opcodeCellVal.startsWith("H")){
	 * splitArr=opcodeCellVal.split("H"); if(splitArr.length==4 &&
	 * null!=splitArr[1] && null !=splitArr[3]){ opCode=splitArr[1];
	 * lineNo=Integer.parseInt(splitArr[2]); totalScannedLines=splitArr[3]; }
	 * if(splitArr.length<4 && null!=splitArr[1] ){ opCode=splitArr[1];
	 * lineNo=Integer.parseInt(splitArr[2]); totalScannedLines="0"; }
	 * 
	 * }
	 * //hanaProfilerStepOutput.setOperationCode(row.getCell(opCodeIndex)==null?
	 * "": row.getCell(opCodeIndex).getStringCellValue());
	 * hanaProfilerStepOutput.setOperationCode(opCode);
	 * hanaProfilerStepOutput.setTotalLineScanned(totalScannedLines);
	 * hanaProfilerStepOutput.setLineNo(lineNo);
	 * hanaProfilerStepOutput.setRequestID(requestID);
	 * hanaProfilerStepOutput.setJoinID(rowId);
	 * 
	 * return hanaProfilerStepOutput; }
	 */

	/*
	 * private void addHANAData(final String path, final long requestId) throws
	 * Exception { File file = new File(path); InputStream inputStream = new
	 * FileInputStream(file); int rowCount =
	 * populateHanaTable.getRowCount(requestId);
	 * 
	 * String fileName = file.getName(); try { List<HanaProfilerStepOutput>
	 * hanaProfileStepOutputList = new ArrayList<HanaProfilerStepOutput>();
	 * List<HanaProfile> hanaProfileList = new ArrayList<HanaProfile>();
	 * 
	 * StreamingReader reader =
	 * StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(
	 * 0) .read(inputStream);
	 * 
	 * for (Row r : reader) { if (r.getRowNum() > 0) { rowCount = rowCount + 1;
	 * logger.info( "File--" + fileName + "-----RowNum---" + r.getRowNum() +
	 * "Table Row Count---" + rowCount);
	 * 
	 * // col25 & col 26
	 * hanaProfileStepOutputList.add(getHanaProfilerStepOutputData(r, rowCount,
	 * requestId, fileName)); hanaProfileList.add(addListwithLoopValueXlsx(r,
	 * rowCount, requestId, fileName)); }
	 * 
	 * }
	 * 
	 * verifyOutput.setHanaProfilerExcelData(hanaProfileList);
	 * verifyOutput.setRequestId(requestId); verifyOutput.setHanaFilePath(path);
	 * 
	 * populateHanaTable.populateDataList(hanaProfileStepOutputList);
	 * populateHanaTable.populateDataList(hanaProfileList); } finally {
	 * IOUtils.closeQuietly(inputStream); }
	 * 
	 * }
	 */

	/*
	 * private ST03MonthData getST03MonthData(Row row, final long requestId,
	 * String fileName) {
	 * 
	 * ST03MonthData st03MonthData = new ST03MonthData();
	 * 
	 * int timeDBChangeIndex =
	 * Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).
	 * get( fileName) .get("Total.Time.for.Logical.DB.Changes")); int
	 * progNameIndex = Integer.parseInt(
	 * Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).
	 * get( "Report.Transaction.name")); int resTimeIndex = Integer.parseInt(
	 * Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).
	 * get( "Total.Response.Time")); int dbTimeIndex = Integer.parseInt(
	 * Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).
	 * get( "Total.Database.Time"));
	 * 
	 * String modificationTime = (row.getCell(timeDBChangeIndex) == null ? "" :
	 * row.getCell(timeDBChangeIndex).getStringCellValue()).replaceAll("\\.0",
	 * "").replace(".", "") .replace(",", ""); String progName =
	 * row.getCell(progNameIndex) == null ? "" :
	 * row.getCell(progNameIndex).getStringCellValue(); // 1,4,10,24 String
	 * responseTimeString = StringUtils .remove(row.getCell(resTimeIndex) ==
	 * null ? "" : row.getCell(resTimeIndex).getStringCellValue(),
	 * Hana_Profiler_Constant.COMMA_SEPERATOR) .trim();
	 * 
	 * String responceTemp = responseTimeString.replaceAll("\\.0",
	 * "").replace(".", "").replace(",", "").trim();
	 * 
	 * BigDecimal responseTime = StringUtils.isBlank(responseTimeString) ? new
	 * BigDecimal(0) : new BigDecimal(responceTemp); String dbTime =
	 * row.getCell(dbTimeIndex) == null ? "" :
	 * row.getCell(dbTimeIndex).getStringCellValue().replaceAll("\\.0",
	 * "").replace(".", "").replace(",", "");
	 * 
	 * modificationTime = StringUtils.remove(modificationTime,
	 * Hana_Profiler_Constant.COMMA_SEPERATOR); dbTime =
	 * StringUtils.remove(dbTime, Hana_Profiler_Constant.COMMA_SEPERATOR);
	 * st03MonthData.setModificationTime(modificationTime);
	 * st03MonthData.setResponseTime(responseTime);
	 * st03MonthData.setRequestID(requestId); st03MonthData.setDbTime(dbTime);
	 * st03MonthData.setProgName(progName);
	 * 
	 * return st03MonthData;
	 * 
	 * }
	 * 
	 * private SunBaseData getSunBaseData(Row row, final long requestId, final
	 * String monthEntry, String fileName) {
	 * 
	 * SunBaseData sunBaseData = new SunBaseData();
	 * 
	 * int dialogStepsIndex = Integer.parseInt(
	 * Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).
	 * get( "Number.Dialog.Steps")); int repTraTimeIndex = Integer.parseInt(
	 * Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).
	 * get( "Report.Transaction.name"));
	 * 
	 * String dialogString = StringUtils.remove( row.getCell(dialogStepsIndex)
	 * == null ? "" : row.getCell(dialogStepsIndex).getStringCellValue(),
	 * Hana_Profiler_Constant.COMMA_SEPERATOR); BigDecimal dialog =
	 * StringUtils.isBlank(dialogString) ? new BigDecimal(0) : new
	 * BigDecimal(dialogString.replaceAll("\\.0", "").replace(".",
	 * "").replace(",", "").trim());
	 * 
	 * sunBaseData .setProg(row.getCell(repTraTimeIndex) == null ? "" :
	 * row.getCell(repTraTimeIndex).getStringCellValue());
	 * sunBaseData.setDialog(dialog); sunBaseData.setRequestID(requestId);
	 * sunBaseData.setMonthYear(monthEntry);
	 * 
	 * return sunBaseData;
	 * 
	 * }
	 * 
	 * private void addST03Data(final String path, final long requestId) throws
	 * Exception { File file = new File(path); InputStream inputStream = new
	 * FileInputStream(file);
	 * 
	 * try { String monthEntry = HANAUtility.getMonthEntry(path);
	 * List<ST03MonthData> st03MonthDataList = new ArrayList<ST03MonthData>();
	 * List<SunBaseData> sunBaseDataList = new ArrayList<SunBaseData>(); String
	 * fileName = file.getName();
	 * 
	 * StreamingReader reader =
	 * StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(
	 * 0) .read(inputStream);
	 * 
	 * for (Row r : reader) { if (r.getRowNum() > 0) { logger.info("File--" +
	 * fileName + "-----RowNum---" + r.getRowNum());
	 * st03MonthDataList.add(getST03MonthData(r, requestId, fileName));
	 * sunBaseDataList.add(getSunBaseData(r, requestId, monthEntry, fileName));
	 * } }
	 * 
	 * //populateHanaTable.populateDataList(st03MonthDataList);
	 * //populateHanaTable.populateDataList(sunBaseDataList); } finally {
	 * IOUtils.closeQuietly(inputStream);
	 * 
	 * } }
	 * 
	 * private void addIncludeExtractorData(final String path, final long
	 * requestId) throws Exception { File file = new File(path); InputStream
	 * inputStream = new FileInputStream(file);
	 * 
	 * String fileName = file.getName(); try { List<IncludeExtractor>
	 * includeExtractorList = new ArrayList<IncludeExtractor>();
	 * 
	 * StreamingReader reader =
	 * StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(
	 * 0) .read(inputStream);
	 * 
	 * for (Row r : reader) { if (r.getRowNum() > 0) {
	 * 
	 * int progIndex = Integer.parseInt(
	 * Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).
	 * get( "program")); int includeIndex = Integer.parseInt(
	 * Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).
	 * get( "includes"));
	 * 
	 * final IncludeExtractor includeExtractor = new IncludeExtractor();
	 * includeExtractor .setProgName(r.getCell(progIndex) == null ? "" :
	 * r.getCell(progIndex).getStringCellValue()); includeExtractor.setIncludes(
	 * r.getCell(includeIndex) == null ? "" :
	 * r.getCell(includeIndex).getStringCellValue());
	 * includeExtractor.setRequestID(requestId); includeExtractor.setStatus("");
	 * includeExtractorList.add(includeExtractor);
	 * 
	 * } } populateHanaTable.populateDataList(includeExtractorList);
	 * populateHanaTable.deleteInvalidCharFromIncludeExt(); } finally {
	 * IOUtils.closeQuietly(inputStream); } }
	 * 
	 * private void addTSTCData(final String path, final long requestId) throws
	 * Exception { File file = new File(path); InputStream inputStream = new
	 * FileInputStream(file); String fileName = file.getName(); List<ST03Tstc>
	 * tstcList = new ArrayList<ST03Tstc>(); try {
	 * 
	 * StreamingReader reader =
	 * StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(
	 * 0) .read(inputStream);
	 * 
	 * for (Row r : reader) { if (r.getRowNum() > 0) {
	 * 
	 * int tcodeIndex = Integer.parseInt(
	 * Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).
	 * get( "TCODE")); int pgmaIndex = Integer.parseInt(
	 * Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).
	 * get( "PGMNA")); ST03Tstc st03Tstc = new ST03Tstc();
	 * st03Tstc.settCode(r.getCell(tcodeIndex) == null ? "" :
	 * r.getCell(tcodeIndex).getStringCellValue());
	 * st03Tstc.setProgName(r.getCell(pgmaIndex) == null ? "" :
	 * r.getCell(pgmaIndex).getStringCellValue());
	 * st03Tstc.setRequestID(requestId); tstcList.add(st03Tstc); } }
	 * 
	 * populateHanaTable.populateDataList(tstcList);
	 * 
	 * } finally { IOUtils.closeQuietly(inputStream); } }
	 * 
	 * private void addTSTCPData(final String path, final long requestId) throws
	 * Exception { File file = new File(path); InputStream inputStream = new
	 * FileInputStream(file); String fileName = file.getName(); List<ST03Tstcp>
	 * tstcpList = new ArrayList<ST03Tstcp>();
	 * 
	 * try { StreamingReader reader =
	 * StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(
	 * 0) .read(inputStream);
	 * 
	 * for (Row r : reader) { if (r.getRowNum() > 0) { int tcodeIndex =
	 * Integer.parseInt(
	 * Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).
	 * get( "TCODE")); int paramIndex = Integer.parseInt(
	 * Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).
	 * get( "PARAM")); final ST03Tstcp st03tscp = new ST03Tstcp(); String tCode
	 * = r.getCell(tcodeIndex) == null ? "" :
	 * r.getCell(tcodeIndex).getStringCellValue(); String parameter =
	 * r.getCell(paramIndex) == null ? "" :
	 * r.getCell(paramIndex).getStringCellValue(); st03tscp.settCode(tCode);
	 * st03tscp.setParameter(parameter); st03tscp.setRequestID(requestId);
	 * tstcpList.add(st03tscp); }
	 * 
	 * } populateHanaTable.populateDataList(tstcpList);
	 * 
	 * } finally { IOUtils.closeQuietly(inputStream); }
	 * 
	 * }
	 */

	public void addTRDIRData(final String path, final long requestId, HttpSession session) throws Exception {

		File file = new File(path);
		InputStream inputStream = new FileInputStream(file);
		String fileName = file.getName();
		List<TRDR_DATA> trdrDataList = new ArrayList<TRDR_DATA>();
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);

			for (Row r : reader) {
				if (r.getRowNum() > 0) {

					int subcIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("SUBC").get(1));
					int nameIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("NAME").get(1));

					String subc = r.getCell(subcIndex) == null ? "" : r.getCell(subcIndex).getStringCellValue().trim();
					String name = r.getCell(nameIndex) == null ? "" : r.getCell(nameIndex).getStringCellValue().trim();

					if (!subc.equals("") && !name.equals("")) {

						TRDR_DATA tr_dr_model = new TRDR_DATA();

						tr_dr_model.setSubc(subc);
						tr_dr_model.setName(name);
						tr_dr_model.setRequestID(requestId);

						trdrDataList.add(tr_dr_model);
					}

				}
			}

			TRDRBatchInsertUpdate(trdrDataList, session);
			// populateHanaTable.populateDataList(trdrDataList);
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
	}

	public void addUi5Data(final String path, final long requestId, HttpSession session) throws Exception {

		File file = new File(path);
		InputStream inputStream = new FileInputStream(file);
		String fileName = file.getName();
		UI5InputList = new ArrayList<UI5InputExtract>();
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);

			for (Row r : reader) {
				if (r.getRowNum() > 0) {

					int UIControlIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("UI.Control").get(1));
					int attributeIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Attribute").get(1));
					int FileNameIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("File.Name").get(1));
					int ProjectNameIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Project.Name").get(1));

					String UIControl = r.getCell(UIControlIndex) == null ? ""
							: r.getCell(UIControlIndex).getStringCellValue().trim();
					String attribute = r.getCell(attributeIndex) == null ? ""
							: r.getCell(attributeIndex).getStringCellValue().trim();
					int LineNumber = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Line.Number").get(0));
					String FileName = r.getCell(FileNameIndex) == null ? ""
							: r.getCell(FileNameIndex).getStringCellValue().trim();
					String ProjectName = r.getCell(ProjectNameIndex) == null ? ""
							: r.getCell(ProjectNameIndex).getStringCellValue().trim();

					if (!UIControl.equals("")) {

						UI5InputExtract UI5InputExtractObj = new UI5InputExtract();

						UI5InputExtractObj.setUielemt(UIControl);
						UI5InputExtractObj.setAttribute(attribute);
						UI5InputExtractObj.setLinenumber(LineNumber);
						UI5InputExtractObj.setFilename(FileName);
						UI5InputExtractObj.setProjectName(ProjectName);
						UI5InputExtractObj.setREQUEST_ID(requestId);

						UI5InputList.add(UI5InputExtractObj);
					}

				}
			}

			UI5BatchInsertUpdate(UI5InputList, session);

		} finally {
			IOUtils.closeQuietly(inputStream);
		}
	}

	/*
	 * public void addTADIRData(final String path, final long requestId,
	 * HttpSession session) throws Exception { File file = new File(path);
	 * InputStream inputStream = new FileInputStream(file); String fileName =
	 * file.getName(); List<ST03Tadir> tadirDataList = new
	 * ArrayList<ST03Tadir>(); try {
	 * 
	 * StreamingReader reader =
	 * StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(
	 * 0) .read(inputStream);
	 * 
	 * for (Row r : reader) { if (r.getRowNum() > 0) {
	 * 
	 * int objectIndex = Integer.parseInt(
	 * S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).
	 * get( "OBJECT").get(1)); int objNameIndex =
	 * Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
	 * .get(fileName).get("OBJNAME").get(1));
	 * 
	 * String object = r.getCell(objectIndex) == null ? "" :
	 * r.getCell(objectIndex).getStringCellValue(); String objName =
	 * r.getCell(objNameIndex) == null ? "" :
	 * r.getCell(objNameIndex).getStringCellValue();
	 * 
	 * if (!object.equals("") && !objName.equals("")) { ST03Tadir tadirmodel =
	 * new ST03Tadir();
	 * 
	 * tadirmodel.setObjectType(object); tadirmodel.setObjectName(objName);
	 * tadirmodel.setRequestID(requestId);
	 * 
	 * tadirDataList.add(tadirmodel); } } }
	 * 
	 * TADIRBatchInsertUpdate(tadirDataList, session); //
	 * populateHanaTable.populateDataList(tadirDataList); } finally {
	 * IOUtils.closeQuietly(inputStream); } }
	 */
	// DEF035
	protected void addEnhancementData(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException, SQLException {

		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);

		String fileName = file.getName();
		try {
			List<S4EnhancementIntermediate> s4EnhancementIntermediateList = new ArrayList<S4EnhancementIntermediate>();
			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);

			for (Row r : reader) {
				int rowIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName)
						.get("ENHANC.TYPE").get(0));
				if (r.getRowNum() > rowIndex) {
					logger.info("File--" + fileName + "-----RowNum---" + r.getRowNum());
					int objTypeIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("ENHANC.TYPE").get(1));
					if (r.getCell(objTypeIndex) != null && !r.getCell(objTypeIndex).getStringCellValue().isEmpty()) {
						S4EnhancementIntermediate s4EnhancementIntermediate = getEnhancementValueXlsx(r, requestId,
								fileName);
						if (s4EnhancementIntermediate != null) {
							s4EnhancementIntermediateList.add(s4EnhancementIntermediate);
						}

					} else {
						if (r.getRowNum() == rowIndex + 5) {
							break;
						}
					}
				}
			}
			enhancementBatchInsertUpdate(s4EnhancementIntermediateList, session);
			// populateHanaTable.populateDataList(s4CloneProgIntermediateList);
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
	}

	public void addUsageData(final String path, final long requestId, HttpSession session) throws Exception {
		File file = new File(path);
		InputStream inputStream = new FileInputStream(file);
		String fileName = file.getName();
		usageAnalysisList = new ArrayList<UsageAnalysis>();
		usageAnalysisObjNameType = new TreeSet<String>(String.CASE_INSENSITIVE_ORDER);
		usageAnalysisObjNameTypeReadProg = new TreeSet<String>(String.CASE_INSENSITIVE_ORDER);
		st03nDataList = new ArrayList<St03NData>();

		try {
			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row r : reader) {
				if (r.getRowNum() > 0) {
					int typeIndex = Integer
							.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("OBJ"));
					int objNameIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name"));
					int subTypeIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sub.Type"));
					int operCdIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Operation.Code"));
					int infoIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Info"));
					int readProgIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Read.Prog"));

					String type = r.getCell(typeIndex) == null ? "" : r.getCell(typeIndex).getStringCellValue().trim();
					String subType = r.getCell(subTypeIndex) == null ? ""
							: r.getCell(subTypeIndex).getStringCellValue();
					String operCd = r.getCell(operCdIndex) == null ? "" : r.getCell(operCdIndex).getStringCellValue();
					String readProg = r.getCell(readProgIndex) == null ? ""
							: r.getCell(readProgIndex).getStringCellValue().trim();

					if (operCd.trim().startsWith("&302")) {
						if (subType.trim().equalsIgnoreCase("USGE")) {
							UsageAnalysis usagemodel = new UsageAnalysis();
							usagemodel.setType(type);

							// CR-67 :Usage Analysis Object Name value checks
							// ,if special character value
							// comes or null then input will be "" otherwise as
							// input from sheet uploaded.
							String ObjName = r.getCell(objNameIndex) == null ? ""
									: r.getCell(objNameIndex).getStringCellValue().trim();
							String specialCharacters = " !#$%&'()*+,-.:;<=>?@[]^_`{|}";

							if (ObjName != "" && specialCharacters.contains(Character.toString(ObjName.charAt(0)))) {
								usagemodel.setObjName("");
							} else {
								usagemodel.setObjName(ObjName);
							}

							String usageCount = r.getCell(infoIndex) == null ? ""
									: r.getCell(infoIndex).getStringCellValue().trim().replaceAll("[^a-zA-Z0-9]", "");
							usagemodel.setUsageCount(usageCount);

							usagemodel
									.setObjNameType(r.getCell(typeIndex) == null || r.getCell(objNameIndex) == null ? ""
											: (r.getCell(typeIndex).getStringCellValue().trim())
													+ (r.getCell(objNameIndex).getStringCellValue().trim()));
							usagemodel.setRequestID(requestId);
							usagemodel.setObjTypeNameReadProg(type + ObjName + readProg);

							usageAnalysisList.add(usagemodel);
							usageAnalysisObjNameType.add(usagemodel.getObjNameType());
							usageAnalysisObjNameTypeReadProg.add(type + ObjName + readProg);
						} else {
							St03NData st03nData = getSt03nData(r, requestId, fileName);
							if (st03nData != null)
								st03nDataList.add(st03nData);
						}
					}
				}
			}

			if (CollectionUtils.isNotEmpty(usageAnalysisList)) {
				hm.setUsageAnalysisList(usageAnalysisList);
				hm.setUsageAnalysisObjNameType(usageAnalysisObjNameType);
				hm.setUsageAnalysisObjNameTypeReadProg(usageAnalysisObjNameTypeReadProg);
				usageAnalysisBatchInsertUpdate(usageAnalysisList, session);
			}

			if (st03nDataList != null && !st03nDataList.isEmpty()) {
				hm.setSt03nList(st03nDataList);

				// IRPA - Getting top 20 critical transactions
				List<String[]> resultList = new LinkedList<>();
				st03nDataList.stream().sorted(Comparator.comparing(St03NData::getUsageCount).reversed())
						.filter(obj -> Strings.isNotEmpty(obj.gettCodeName()))
						.filter(distinctByKey(obj -> obj.gettCodeName().trim()
								.concat(Optional.ofNullable(obj.getObjType().trim()).orElse(StringUtils.EMPTY))))
						.limit(20).collect(Collectors.toList()).stream().forEach(obj -> {
							resultList.add(new String[] { obj.gettCodeName().trim(),
									Optional.ofNullable(obj.getObjType().trim()).orElse(StringUtils.EMPTY) });
						});

				getCollectionBean().setSt03List(resultList);
			}
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
	}

	private static <T> Predicate<T> distinctByKey(Function<? super T, ?> keyExtractor) {
		Map<Object, Boolean> seen = new ConcurrentHashMap<>();
		return t -> seen.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
	}

	public Testingscopepojo createListforTscope(final Row row, final Long requestID, String fileName)
			throws FileNotFoundException, SQLException {
		Testingscopepojo tscope = null;
		int opCodeIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Operation.Code"));
		String opcodeCellVal = row.getCell(opCodeIndex) == null ? ""
				: row.getCell(opCodeIndex).getStringCellValue().trim();

		if (opcodeCellVal.toUpperCase().trim().startsWith("&308")
				|| opcodeCellVal.toUpperCase().trim().startsWith("&309")) {
			int commentsCellIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Comments"));
			int infoCellIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Info"));
			int codeCellIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Code"));
			int objectTypeIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("OBJ").trim());
			int objectNameIndex = Integer.parseInt(
					Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Obj.Name").trim());

			String commentsCellVal = row.getCell(commentsCellIndex) == null ? ""
					: row.getCell(commentsCellIndex).getStringCellValue().trim();
			String infoCellVal = row.getCell(infoCellIndex) == null ? ""
					: row.getCell(infoCellIndex).getStringCellValue().trim();
			String codeCellValue = row.getCell(codeCellIndex) == null ? ""
					: row.getCell(codeCellIndex).getStringCellValue().trim();
			String objectTypeCellVal = row.getCell(objectTypeIndex) == null ? ""
					: row.getCell(objectTypeIndex).getStringCellValue().trim();
			String objectNameCellVal = row.getCell(objectNameIndex) == null ? ""
					: row.getCell(objectNameIndex).getStringCellValue().trim();

			tscope = new Testingscopepojo();

			if (opcodeCellVal.startsWith("&308")) {
				if (commentsCellVal.trim().isEmpty() && codeCellValue.trim().isEmpty() && infoCellVal.trim().isEmpty())
					tscope.setOpercd("Custom Impacted");
				else
					tscope.setOpercd("Custom");
			} else if (opcodeCellVal.startsWith("&309"))
				tscope.setOpercd("Standard");
			tscope.setObjecttype(objectTypeCellVal);
			tscope.setObjectname(objectNameCellVal);
			tscope.setComments(commentsCellVal);
			tscope.setInfo(infoCellVal);
			tscope.setCode(codeCellValue);
		}

		return tscope;
	}

	public TestingScopeModel createListIRPA(final Row row, final Long requestID, String fileName)
			throws FileNotFoundException, SQLException {
		TestingScopeModel tscopeObj = null;

		int opCodeIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Operation.Code"));
		String opcodeCellVal = row.getCell(opCodeIndex) == null ? ""
				: row.getCell(opCodeIndex).getStringCellValue().trim();

		if (opcodeCellVal.toUpperCase().trim().startsWith(ST03HanaConstant.CUSTOM_OPCODE)
				|| opcodeCellVal.toUpperCase().trim().startsWith(ST03HanaConstant.STANDARD_OPCODE)) {
			int commentsCellIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Comments"));
			int infoCellIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Info"));
			int objectTypeIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("OBJ").trim());
			int objectNameIndex = Integer.parseInt(
					Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Obj.Name").trim());

			String commentsCellVal = row.getCell(commentsCellIndex) == null ? ""
					: row.getCell(commentsCellIndex).getStringCellValue().trim();
			String infoCellVal = row.getCell(infoCellIndex) == null ? ""
					: row.getCell(infoCellIndex).getStringCellValue().trim();
			String objectTypeCellVal = row.getCell(objectTypeIndex) == null ? ""
					: row.getCell(objectTypeIndex).getStringCellValue().trim();
			String objectNameCellVal = row.getCell(objectNameIndex) == null ? ""
					: row.getCell(objectNameIndex).getStringCellValue().trim();

			tscopeObj = new TestingScopeModel();

			tscopeObj.setObjectType(objectTypeCellVal);
			tscopeObj.setObjectName(objectNameCellVal);
			tscopeObj.setComments(commentsCellVal);
			tscopeObj.setInfo(infoCellVal);
			tscopeObj.setOperationCode(opcodeCellVal);
		}

		return tscopeObj;
	}

	public ImpactedBackgroundJob createListforImpactedBackJob(final Row row, final Long requestID, String fileName,
			List<String> externalNamespaceList) throws FileNotFoundException, SQLException {

		ImpactedBackgroundJob backJob = null;
		int opCodeIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Operation.Code"));
		int objecttypeIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("OBJ").trim());
		int objectnameIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Obj.Name").trim());
		int subTypeIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Sub.Type"));
		int readProgIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Read.Prog"));
		int packageIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("OBJ.Pckg"));
		int actStatusIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Act.Status"));

		String opcodeCellVal = row.getCell(opCodeIndex) == null ? "" : row.getCell(opCodeIndex).getStringCellValue();
		String objecttypeCellVal = row.getCell(objecttypeIndex) == null ? ""
				: row.getCell(objecttypeIndex).getStringCellValue().trim();
		String objectnameCellVal = row.getCell(objectnameIndex) == null ? ""
				: row.getCell(objectnameIndex).getStringCellValue().trim();
		String subTypeIndexValue = row.getCell(subTypeIndex) == null ? ""
				: row.getCell(subTypeIndex).getStringCellValue();
		String readProgIndexValue = row.getCell(readProgIndex) == null ? ""
				: row.getCell(readProgIndex).getStringCellValue();
		String packageIndexValue = row.getCell(packageIndex) == null ? ""
				: row.getCell(packageIndex).getStringCellValue();
		String actStatusIndexValue = row.getCell(actStatusIndex) == null ? ""
				: row.getCell(actStatusIndex).getStringCellValue();

		if (opcodeCellVal.startsWith("&304")) {
			backJob = new ImpactedBackgroundJob();
			backJob.setObject(objecttypeCellVal);
			backJob.setObjectName(objectnameCellVal);
			backJob.setSubType(subTypeIndexValue);
			backJob.setREAD_PROG(readProgIndexValue);
			backJob.setObjPackage(packageIndexValue);
			backJob.setActStatus(actStatusIndexValue);
			backJob.setRequestId(requestID);

			// Setting External Namespace
			if (CollectionUtils.isNotEmpty(externalNamespaceList)
					&& !externalNamespaceList.stream().anyMatch("NA"::equalsIgnoreCase)) {
				if (!objectnameCellVal.isEmpty()) {
					for (String externalNamespace : externalNamespaceList) {
						if (StringUtils.containsIgnoreCase(objectnameCellVal.trim(), externalNamespace.trim())) {
							backJob.setExternalNamespace("Y");
							break;
						}
					}
				}
			}
		}

		return backJob;
	}

	public InconsistentFUGR createListForInconsistentFUGRs(final Row row, final Long requestID, String fileName,
			List<String> externalNamespaceList) throws FileNotFoundException, SQLException {
		InconsistentFUGR inconsistentFUGR = null;
		int opCodeIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Operation.Code"));
		int objecttypeIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("OBJ").trim());
		int objectnameIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Obj.Name").trim());
		int subTypeIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Sub.Type"));

		String opcodeCellVal = row.getCell(opCodeIndex) == null ? "" : row.getCell(opCodeIndex).getStringCellValue();

		if (opcodeCellVal.startsWith("&305")) {
			String objectTypeCellValue = row.getCell(objecttypeIndex) == null ? ""
					: row.getCell(objecttypeIndex).getStringCellValue();
			String objNameCellValue = row.getCell(objectnameIndex) == null ? ""
					: row.getCell(objectnameIndex).getStringCellValue();
			String subTypeCellValue = row.getCell(subTypeIndex) == null ? ""
					: row.getCell(subTypeIndex).getStringCellValue();
			inconsistentFUGR = new InconsistentFUGR();
			inconsistentFUGR.setObjectType(objectTypeCellValue);
			inconsistentFUGR.setFugrName(objNameCellValue);
			inconsistentFUGR.setMasterProgram(subTypeCellValue);
			inconsistentFUGR.setRequestId(requestID);

			// Setting External Namespace
			if (CollectionUtils.isNotEmpty(externalNamespaceList)
					&& !externalNamespaceList.stream().anyMatch("NA"::equalsIgnoreCase)) {
				if (!objNameCellValue.isEmpty()) {
					for (String externalNamespace : externalNamespaceList) {
						if (StringUtils.containsIgnoreCase(objNameCellValue.trim(), externalNamespace.trim())) {
							inconsistentFUGR.setExternalNamespace("Y");
							break;
						}
					}
				}
			}
		}

		return inconsistentFUGR;
	}

	protected void createListforSmodilogFunction(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException, SQLException {

		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);
		SmodilogFunction smodilogFunction = null;

		List<SmodilogFunction> smodilogFunctionList = new ArrayList<SmodilogFunction>();
		Map<String, SmodilogFunction> smodMap = new HashedMap();
		String fileName = file.getName();
		logger.info("Inside Method createListforSmodilogFunction Filename is" + fileName);
		try {
			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);

			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int objectNameIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Obj.Name").get(1));
					String objectName = row.getCell(objectNameIndex) == null ? ""
							: row.getCell(objectNameIndex).getStringCellValue();

					if (!objectName.startsWith("/ACNIP/")) {
						int objectTypeIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
								.get(fileName).get("Obj.Type").get(1));
						int subTypeIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
								.get(fileName).get("Sub.Type").get(1));
						int subNameIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
								.get(fileName).get("Sub.Name").get(1));
						int intTypeIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
								.get(fileName).get("Int.Type").get(1));
						int intNameIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
								.get(fileName).get("Int.Name").get(1));
						int modUserIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
								.get(fileName).get("Mod.User").get(1));
						int modDateIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
								.get(fileName).get("Mod.Date").get(1));
						int modTimeIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
								.get(fileName).get("Mod.Time").get(1));
						int trkorrIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
								.get(fileName).get("Trkorr").get(1));
						int OperIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
								.get(fileName).get("Operation").get(1));

						String objectType = row.getCell(objectTypeIndex) == null ? ""
								: row.getCell(objectTypeIndex).getStringCellValue();
						logger.info("From SMO excel file objectType Is" + objectType);
						String subType = row.getCell(subTypeIndex) == null ? ""
								: row.getCell(subTypeIndex).getStringCellValue();
						String subName = row.getCell(subNameIndex) == null ? ""
								: row.getCell(subNameIndex).getStringCellValue();
						String intType = row.getCell(intTypeIndex) == null ? ""
								: row.getCell(intTypeIndex).getStringCellValue();
						String intName = row.getCell(intNameIndex) == null ? ""
								: row.getCell(intNameIndex).getStringCellValue();
						String modUser = row.getCell(modUserIndex) == null ? ""
								: row.getCell(modUserIndex).getStringCellValue();
						String modDate = row.getCell(modDateIndex) == null ? ""
								: row.getCell(modDateIndex).getStringCellValue();
						String modTime = row.getCell(modTimeIndex) == null ? ""
								: row.getCell(modTimeIndex).getStringCellValue();
						String trkorr = row.getCell(trkorrIndex) == null ? ""
								: row.getCell(trkorrIndex).getStringCellValue();
						String operation = row.getCell(OperIndex) == null ? ""
								: row.getCell(OperIndex).getStringCellValue();

						smodilogFunction = new SmodilogFunction();

						if ("PU".equalsIgnoreCase(intType) && "MOD".equalsIgnoreCase(operation)) {

							smodilogFunction.setObjType(objectType);
							smodilogFunction.setObjName(objectName);
							smodilogFunction.setObjNameType(objectType.trim() + objectName.trim());
							smodilogFunction.setRequestId(requestId);
							smodMap.put(objectType.trim() + objectName.trim(), smodilogFunction);

						}
						smodilogFunction.setObjType(objectType);
						smodilogFunction.setObjName(objectName);
						smodilogFunction.setObjNameType(objectType.trim() + objectName.trim());
						smodilogFunction.setSubType(subType);
						smodilogFunction.setSubName(subName);
						smodilogFunction.setIntType(intType);
						smodilogFunction.setIntName(intName);
						smodilogFunction.setModUser(modUser);
						smodilogFunction.setModDate(modDate);
						smodilogFunction.setModTime(modTime);
						smodilogFunction.setTrkorr(trkorr);
						smodilogFunction.setRequestId(requestId);

						if (!objectType.isEmpty()) {
							if (objectType.matches("TABL|DTEL|TTYP|DOMA|TOBJ"))
								smodilogFunction.setSpddObjects("X");
							else
								smodilogFunction.setSpauObjects("X");
						}

						smodilogFunctionList.add(smodilogFunction);

					}
				}
			}

			hm.setSmodilogMapImpMod(smodMap);
			logger.info("setInventoryList Size :: " + hm.getInventoryList().size());
			smodilogFunctionInsertUpdate(smodilogFunctionList, session);
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
	}

	public static String smodilogFunctionInsertUpdate(List<SmodilogFunction> smodilogFunctionList, HttpSession session)
			throws SQLException {

		final String INSERT_SQL = "INSERT INTO smodilogfunction "
				+ "(OBJ_TYPE, OBJ_NAME, SUB_TYPE, SUB_NAME, INT_TYPE, INT_NAME, MOD_USER, MOD_DATE, "
				+ "MOD_TIME, TRKORR, SPDD_Objects, SPAU_Objects, Request_Id) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {
			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (SmodilogFunction smodilogFunction : smodilogFunctionList) {
					stmt.setString(1, smodilogFunction.getObjType());
					stmt.setString(2, smodilogFunction.getObjName());
					stmt.setString(3, smodilogFunction.getSubType());
					stmt.setString(4, smodilogFunction.getSubName());
					stmt.setString(5, smodilogFunction.getIntType());
					stmt.setString(6, smodilogFunction.getIntName());
					stmt.setString(7, smodilogFunction.getModUser());
					stmt.setString(8, smodilogFunction.getModDate());
					stmt.setString(9, smodilogFunction.getModTime());
					stmt.setString(10, smodilogFunction.getTrkorr());
					stmt.setString(11, smodilogFunction.getSpddObjects());
					stmt.setString(12, smodilogFunction.getSpauObjects());
					stmt.setLong(13, smodilogFunction.getRequestId());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("SmodilogFunction Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;
	}

	public void addLSMWData(String filePath, long requestID) throws FileNotFoundException {
		logger.info("populateHanaTable::::::" + populateHanaTable);

		int rowCount = populateHanaTable.getRowCount(requestID);

		lsmwList = addLSMWDataList(filePath, requestID, rowCount);
		hm.setLsmwList(lsmwList);
		populateHanaTable.populateDataList(lsmwList);

	}

	// DEF043
	/*
	 * protected void addUserExitData(String filePath, long
	 * requestID,HttpSession session) throws FileNotFoundException, SQLException
	 * {
	 * 
	 * System.out.println("populateHanaTable::::::" + populateHanaTable);
	 * 
	 * int rowCount =populateHanaTable.getRowCount(requestID);
	 * 
	 * List<UserExit>
	 * userExitList=addUserExitDataList(filePath,requestID,rowCount);
	 * hm.setUserExitList(userExitList);
	 * UserExitBatchInsertUpdate(userExitList,session);
	 * //populateHanaTable.populateDataList(userExitList);
	 * 
	 * 
	 * }
	 */

	public static String UserExitBatchInsertUpdate(List<UserExit> listOfUserExit, HttpSession session)
			throws SQLException {

		final String INSERT_SQL = "INSERT INTO USER_EXIT"
				+ "(OBJ_NAME, OBJ_NAME_TYPE, OBJ_TYPE, REQUEST_ID) values (?, ?, ?, ?) ";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);

			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (UserExit hpro : listOfUserExit) {
					stmt.setString(1, hpro.getObjName());
					stmt.setString(2, hpro.getObjNameType());
					stmt.setString(3, hpro.getObjType());
					stmt.setLong(4, hpro.getRequestID());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}
				stmt.executeBatch();
				conn.commit();
				logger.info("Final batch executed successfully");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	protected void addInventoryData(String filePath, long requestID, HttpSession session)
			throws FileNotFoundException, SQLException {

		logger.info("populateHanaTable::::::" + populateHanaTable);

		int rowCount = populateHanaTable.getRowCount(requestID);

		List<String> externalNamespaceList = null;

		RequestForm requestForm = requestFormDao.getRequestObj(requestID);

		if (!StringUtils.isEmpty(requestForm.getExternalNamespace())) {
			externalNamespaceList = new ArrayList<>(
					Arrays.asList(requestForm.getExternalNamespace().trim().split(",")));
		}

		inventoryList = addInventoryDataList(filePath, requestID, rowCount, externalNamespaceList);
		hm.setInventoryList(inventoryList);

		// Defect fix if we write we get duplicate values
		s4InventoryListBatchInsertUpdate(inventoryList, session);

		// populateHanaTable.populateDataList(inventoryList);

	}

	/*
	 * public synchronized void st03Read(final String filePath, final long
	 * requestId,String toolName) throws Exception { final long requestID =
	 * requestId; final File file = new File(filePath); String path =
	 * file.getName().toUpperCase();
	 * 
	 * /*if (path.contains(ST03HanaConstant.CONSOLIDATE_CONSTANT.toUpperCase()))
	 * { addConsolidatedData(filePath, requestId,toolName); } else if
	 * (path.contains(ST03HanaConstant.ST03_CONSTANT.toUpperCase())) {
	 * addST03Data(filePath, requestId); } else if
	 * (path.contains(ST03HanaConstant.INCLUDE_CONSTANT.toUpperCase())) {
	 * addIncludeExtractorData(filePath, requestID); } else if
	 * (path.contains(ST03HanaConstant.TSTC_CONSTANT.toUpperCase())) {
	 * addTSTCData(filePath, requestID); } else if
	 * (path.contains(ST03HanaConstant.TSTCP_CONSTANT.toUpperCase())) {
	 * addTSTCPData(filePath, requestId); } else if
	 * (path.contains(ST03HanaConstant.TRDIR_CONSTANT.toUpperCase())) {
	 * addTRDIRData(filePath, requestID); } else if
	 * (path.contains(ST03HanaConstant.TADIR_CONSTANT.toUpperCase())) {
	 * addTADIRData(filePath, requestID); }else if
	 * (path.contains(ST03HanaConstant.USAGE_CONSTANT.toUpperCase())) {
	 * addUsageData(filePath, requestID); }else if
	 * (path.contains(S4HanaProfilerConstant.LSMW_CONSTANT.toUpperCase())) {
	 * addLSMWData(filePath, requestID); }else if
	 * (path.contains(S4HanaProfilerConstant.USER_EXIT_CONSTANT.toUpperCase()))
	 * { addUserExitData(filePath, requestID); } else if
	 * (path.contains(S4HanaProfilerConstant.INVENTORY_CONSTANT.toUpperCase()))
	 * { addInventoryData(filePath, requestID); } }
	 */
	public synchronized void readZaicatDetectionFile(final String filePath, final long requestId, String toolName,
			HttpSession session, RequestForm requestForm) throws Exception {
		hm.setSession(session);
		// Reading Zaicat Detection for Usage Analysis
		addUsageData(filePath, requestId, session);
		addZAICATDetectionData(filePath, requestId, toolName, session, requestForm);
	}

	public synchronized TADIRInventory readTadirFile(final String filePath, final long requestId, String toolName,
			HttpSession session, RequestForm requestForm) throws Exception {
		hm.setSession(session);
		return addTadirData(filePath, requestId, toolName, session, requestForm);
	}

	/**
	 * US-AADT file reading for aadt file processing combined file reading
	 * function- rohan.a.mehra
	 *
	 */
	public synchronized void AadtReadFiles(final String filePath, final long requestId, String toolName,
			HttpSession session) throws Exception {

		final long requestID = requestId;
		final File file = new File(filePath);
		String path = file.getName().toUpperCase();

		// Setting session value for jdbc(.Properties)
		hm.setSession(session);
		logger.info("Inside AadtReadFiles");
		if (path.contains(ST03HanaConstant.TRDIR_CONSTANT.toUpperCase())) {
			addTRDIRData(filePath, requestID, session);
		} else if (path.contains(S4HanaProfilerConstant.INVENTORY_CONSTANT.toUpperCase())) {
			if (S4HanaProfilerConstant.BWINVENTORY_CONSTANT.toUpperCase().equalsIgnoreCase(path)) {
				addBwInventoryData(filePath, requestID, session);
			} else {
				addInventoryData(filePath, requestID, session);
			}
		} else if (path.contains(S4HanaProfilerConstant.IMPACTED_CLONE_CONSTANT.toUpperCase())) {
			addImpactedCloneData(filePath, requestId, session);
		} else if (path.contains(S4HanaProfilerConstant.BW_EXTRACTOR_CONSTANT.toUpperCase())) {
			addBWExtractorData(filePath, requestId, session);
		} else if (path.contains(S4HanaProfilerConstant.ACNIP_ZVER_COMP_CONSTANT.toUpperCase())) {
			addACNIP_ZVER_COMPData(filePath, requestId, session);
		} /*
			 * else if
			 * (path.contains(S4HanaProfilerConstant.CLONE_CONSTANT.toUpperCase(
			 * )) &&
			 * !path.contains(S4HanaProfilerConstant.IMPACTED_CLONE_CONSTANT.
			 * toUpperCase())) { addCloneProgData(filePath, requestId, session);
			 * }
			 */else if (path.contains(S4HanaProfilerConstant.APPEND_CONSTANT.toUpperCase())) {
			addAppendStructureData(filePath, requestId, session);
		} else if (path.contains(S4HanaProfilerConstant.IMPACTED_STANDARD_TRANSACTION_CONSTANT.toUpperCase())) {
			addImpactedTransactionData(filePath, requestID, session);
		} else if (path.contains(Services_Constant.SMODILOG_CONSTANT.toUpperCase())) {
			createListforSmodilogFunction(filePath, requestID, session);
		} else if (path.contains(Services_Constant.SRC_AGR1251_CONSTANT.toUpperCase())) {
			createListforSecurityAnalyserSrcAgr(filePath, requestID, session);
		} else if (path.contains(Services_Constant.SRC_USOBTC_CONSTANT.toUpperCase())) {
			createListforSourceUSOBTC(filePath, requestID, session);
		} else if (path.contains(Services_Constant.SRC_USERS_CONSTANT.toUpperCase())) {
			createListforAgrUsers(filePath, requestID, session);
		} else if (path.contains(Services_Constant.RSICCONT_CONSTANT.toUpperCase())) {
			createListforRsiccont(filePath, requestId, session);// Dso/Infocube

		} else if (path.contains(Services_Constant.RSDCUBE_CONSTANT.toUpperCase())) {
			createListforInfoCubeMaster(filePath, requestID, session);
		} else if (path.contains(Services_Constant.RSDODSO_CONSTANT.toUpperCase())) {
			createListforDsoMaster(filePath, requestID, session);
		} else if (path.contains(Services_Constant.RSANT_PROCESSR_CONSTANT.toUpperCase())) {
			createListforRsantProcessr(filePath, requestId, session);// APD
		} else if (path.contains(Services_Constant.RSBKREQUEST_CONSTANT.toUpperCase())) {
			createListForRsbkrequest(filePath, requestId, session); // OHD/DTP/Transformation
		} else if (path.contains(Services_Constant.RSRREPDIR_CONSTANT.toUpperCase())) {
			createListforRsrrepdir(filePath, requestId, session);// BEX
		} else if (path.contains(Services_Constant.RSBKDTP_CONSTANT.toUpperCase())) {
			createListforRsbkdtp(filePath, requestId, session);

		} else if (path.contains(Services_Constant.RSBKDTPSTAT_CONSTANT.toUpperCase())) {
			createListforRsbkdtpstat(filePath, requestId, session);

		} else if (path.contains(Services_Constant.RSTRAN_CONSTANT.toUpperCase())) {
			createListforRstran(filePath, requestId, session);

		} else if (path.contains(Services_Constant.RSPCPROCESSLOG_CONSTANT.toUpperCase())) {
			createListforRspcprocesslog(filePath, requestId, session);
		} else if (path.contains(Services_Constant.RSZWTEMPLATE_CONSTANT.toUpperCase())) {
			createListforRszwTemplate(filePath, requestId, session);
		} else if (path.contains(Services_Constant.RSZWBTMPDATA_CONSTANT.toUpperCase())) {
			createListforRszwbtmpdata(filePath, requestId, session);
		} else if (path.contains(Services_Constant.BIOAPEARS_CONSTANT.toUpperCase())) {
			createListforWebtemplate3(filePath, requestId, session);
			createListforWebtemplate7(filePath, requestId, session);
		} else if (path.contains(Services_Constant.RSRWBINDEXT_CONSTANT.toUpperCase())) {
			createListforRsrwbindext(filePath, requestID, session);
		} else if (path.contains(Services_Constant.RSRWBINDEX_CONSTANT.toUpperCase())) {
			createListforRSRWBINDEX(filePath, requestID, session);
		} else if (path.contains(Services_Constant.RSRWORKBOOK_CONSTANT.toUpperCase())) {
			createListforRsrworkbook(filePath, requestID, session);
		} else if (path.contains(Services_Constant.RSPCCHAINATTR_CONSTANT.toUpperCase())) {
			createListforRSPCCHAINATTR(filePath, requestID, session);
		} else if (path.contains(Services_Constant.RSPCCHAIN_CONSTANT.toUpperCase())) {
			createListforRspchain(filePath, requestID, session);
		} else if (path.contains(Services_Constant.RSDIOBJ_CONSTANT.toUpperCase())) {
			createListforRsdiobj(filePath, requestID, session);
		} else if (path.contains(Services_Constant.RSQISET_CONSTANT.toUpperCase())) {
			createListforRsqiset(filePath, requestID, session);
		} else if (path.contains(Services_Constant.RSBOHDEST_CONSTANT.toUpperCase())) {
			createListforRsbohdest(filePath, requestID, session);// ODH
		} else if (path.contains(Services_Constant.RSANT_PROCESS_CONSTANT.toUpperCase())) {
			createListforRsant_process(filePath, requestID, session);// APD
		} else if (path.contains(Services_Constant.RSOHCPR_CONSTANT.toUpperCase())) {
			// createListforRsohcpr(filePath, requestID, session);//sample files
			// not
			// delievered. need to check on google
		} else if (path.contains(Services_Constant.RSUPDINFO_CONSTANT.toUpperCase())) {
			createListforRsupdinfo(filePath, requestID, session);
		} else if (path.contains(Services_Constant.RSTS_CONSTANT.toUpperCase())) {
			createListforRsts(filePath, requestID, session);
		} else if (path.contains(Services_Constant.RSDS_CONSTANT.toUpperCase())) {
			createListforRsds(filePath, requestID, session);
		} else if (path.contains(Services_Constant.RSLDPIO_CONSTANT.toUpperCase())) {
			createListforRsldpio(filePath, requestID, session);
		} else if (path.contains(Services_Constant.RSZWBTMPHEAD_CONSTANT.toUpperCase())) {
			createListforRszwbtmphead(filePath, requestID, session);
		} else if (path.contains(Services_Constant.UNICODE_CONSTANT.toUpperCase())) {
			createListforUnicode(filePath, requestID, session);
		} else if (path.contains(Services_Constant.COMPLEXITY_RULES.toUpperCase())) {
			addComplexityRules(filePath, requestId, session);
		} else if (path.contains(Services_Constant.EXTENSIBILITY_RULES.toUpperCase())) {
			addExtensibilityRules(filePath, requestId, session);
		} else if (path.contains(Services_Constant.METADATA_EXT.toUpperCase())) {
			addMetaData(filePath, requestId, session);
		} else if (path.contains(Services_Constant.USAGE_ANALYSIS_EXT.toUpperCase())) {
			addExtUsgaeAnalysisData(filePath, requestId, session);
		} else if (path.contains(Services_Constant.INACTIVE_OBJECTS.toUpperCase())) {
			createListforInactiveObjects(filePath, requestID, session);
		} else if (path.contains(Services_Constant.BUSINESS_PROCESS_DETAIL.toUpperCase())) {
			addBusinessProcessDetailData(filePath, requestId, session);
		} else if (path.contains(Services_Constant.CUSTOM_REPORT_OUTPUT_CONSTANT.toUpperCase())) {
			addCustomReportData(filePath, requestId, session);
		}

	}

	protected void addCloneProgData(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException, SQLException {

		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);

		String fileName = file.getName();
		try {
			List<S4CloneIntermediate> s4CloneProgIntermediateList = new ArrayList<S4CloneIntermediate>();
			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);

			for (Row r : reader) {
				int rowIndex = Integer.parseInt(
						S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Type").get(0));
				if (r.getRowNum() > rowIndex) {
					logger.info("File--" + fileName + "-----RowNum---" + r.getRowNum());
					int objTypeIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Obj.Type").get(1));
					if (r.getCell(objTypeIndex) != null && !r.getCell(objTypeIndex).getStringCellValue().isEmpty()) {

						S4CloneIntermediate s4CloneProgIntermediate = getCloneProgValueXlsx(r, requestId, fileName);
						if (s4CloneProgIntermediate != null) {
							s4CloneProgIntermediateList.add(s4CloneProgIntermediate);
						}

					} else {
						if (r.getRowNum() == rowIndex + 5) {
							break;
						}
					}
				}
			}
			cloneProgBatchInsertUpdate(s4CloneProgIntermediateList, session);
		} finally {
			IOUtils.closeQuietly(inputStream);
		}

	}

	private S4CloneIntermediate getCloneProgValueXlsx(Row row, long requestId, String fileName) {

		int objTypeIndex = Integer
				.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Type").get(1));
		int objNameIndex = Integer
				.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name").get(1));
		int includeIndex = Integer
				.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Include").get(1));

		String objType = row.getCell(objTypeIndex) == null ? "" : row.getCell(objTypeIndex).getStringCellValue();
		String objName = row.getCell(objNameIndex) == null ? "" : row.getCell(objNameIndex).getStringCellValue();

		if (!objType.equals("") && !objName.equals("")) {
			final S4CloneIntermediate s4CloneProgIntermediate = new S4CloneIntermediate();

			s4CloneProgIntermediate.setObjType(objType);
			s4CloneProgIntermediate.setObjName(objName);
			s4CloneProgIntermediate.setInclude(
					row.getCell(includeIndex) == null ? "" : row.getCell(includeIndex).getStringCellValue());
			s4CloneProgIntermediate.setRequestId(requestId);

			return s4CloneProgIntermediate;
		}

		return null;
	}

	protected void addImpactedCloneData(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException, SQLException {

		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);

		String fileName = file.getName();
		try {
			List<ImpactedCloneAnalysis> impactedCloneList = new ArrayList<ImpactedCloneAnalysis>();
			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);

			for (Row r : reader) {
				int rowIndex = Integer.parseInt(
						S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Type").get(0));
				if (r.getRowNum() > rowIndex) {
					logger.info("File--" + fileName + "-----RowNum---" + r.getRowNum());
					int objTypeIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Obj.Type").get(1));
					if (r.getCell(objTypeIndex) != null && !r.getCell(objTypeIndex).getStringCellValue().isEmpty()) {

						ImpactedCloneAnalysis impactedCloneAnalysis = getImpactedCloneAnalysisValueXlsx(r, requestId,
								fileName);
						if (impactedCloneAnalysis != null) {
							impactedCloneList.add(impactedCloneAnalysis);
						}
					}
				}
			}

			hm.setImpactedcloneList(impactedCloneList);
		} finally {
			IOUtils.closeQuietly(inputStream);
		}

	}

	private ImpactedCloneAnalysis getImpactedCloneAnalysisValueXlsx(Row row, long requestId, String fileName) {
		int namespaceIndex = Integer.parseInt(
				S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Namespace").get(1));
		int objTypeIndex = Integer
				.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Type").get(1));
		int objNameIndex = Integer
				.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name").get(1));
		int packageIndex = Integer
				.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Package").get(1));
		int creationDateIndex = Integer.parseInt(
				S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Creation.Date").get(1));
		int interfaceObjTypeIndex = Integer.parseInt(
				S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Interface.Obj.Type").get(1));
		int interfaceObjIndex = Integer.parseInt(
				S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Interface.Obj").get(1));
		int referencePercentIndex = Integer.parseInt(
				S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Reference.Percent").get(1));
		int appComponentIndex = Integer.parseInt(
				S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("App.Component").get(1));
		int execDateIndex = Integer.parseInt(
				S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Exec.Date").get(1));
		int execTimeIndex = Integer.parseInt(
				S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Exec.Time").get(1));

		String namespace = row.getCell(namespaceIndex) == null ? "" : row.getCell(namespaceIndex).getStringCellValue();
		String objType = row.getCell(objTypeIndex) == null ? "" : row.getCell(objTypeIndex).getStringCellValue();
		String objName = row.getCell(objNameIndex) == null ? "" : row.getCell(objNameIndex).getStringCellValue();
		String objPackage = row.getCell(packageIndex) == null ? "" : row.getCell(packageIndex).getStringCellValue();
		String creationDate = row.getCell(creationDateIndex) == null ? ""
				: row.getCell(creationDateIndex).getStringCellValue();
		String interfaceObjType = row.getCell(interfaceObjTypeIndex) == null ? ""
				: row.getCell(interfaceObjTypeIndex).getStringCellValue();
		String interfaceObj = row.getCell(interfaceObjIndex) == null ? ""
				: row.getCell(interfaceObjIndex).getStringCellValue();
		String referencePercent = row.getCell(referencePercentIndex) == null ? ""
				: row.getCell(referencePercentIndex).getStringCellValue();
		String appComponent = row.getCell(appComponentIndex) == null ? ""
				: row.getCell(appComponentIndex).getStringCellValue();
		String execDate = row.getCell(execDateIndex) == null ? "" : row.getCell(execDateIndex).getStringCellValue();
		String execTime = row.getCell(execTimeIndex) == null ? "" : row.getCell(execTimeIndex).getStringCellValue();

		String objTypeName = objType.concat(objName);
		String interfaceConcat = interfaceObj.concat(interfaceObjType);
		String year = "";
		String reference = "";
		if (creationDate.length() > 4)
			year = creationDate.substring(0, 4);
		else
			year = creationDate;

		if (!objType.equals("") && !objName.equals("") && !objName.toUpperCase().contains("TABLEFRAME")) {
			final ImpactedCloneAnalysis impactedCloneAnalysis = new ImpactedCloneAnalysis();

			impactedCloneAnalysis.setNamespace(namespace);
			impactedCloneAnalysis.setObjType(objType);
			impactedCloneAnalysis.setObjName(objName);
			impactedCloneAnalysis.setObjPackage(objPackage);
			impactedCloneAnalysis.setCreationDate(creationDate);
			impactedCloneAnalysis.setInterfaceObjType(interfaceObjType);
			impactedCloneAnalysis.setInterfaceObj(interfaceObj);
			impactedCloneAnalysis.setExecDate(execDate);
			impactedCloneAnalysis.setExecTime(execTime);

			// for object types SFPF, SSFO and FORM if reference percentage is
			// Blank then reference field will be blank
			if (referencePercent.isEmpty() || referencePercent == null) {
				referencePercent = "";
			}
			impactedCloneAnalysis.setReferencePercent(referencePercent);

			int refPercent = 0;
			if (referencePercent.contains("%")) {
				String[] refPerArr = referencePercent.split("%");
				refPercent = refPerArr == null || refPerArr.length == 0 || refPerArr[0].isEmpty() ? 0
						: Integer.parseInt(refPerArr[0].trim());
				logger.info("refPercent :: " + refPercent);
			} else if (!referencePercent.equalsIgnoreCase("")) {
				refPercent = Integer.parseInt(referencePercent);
			}
			if (refPercent <= 100 && refPercent >= 99)
				reference = "Identical Source Code";
			else if (refPercent <= 98 && refPercent >= 81)
				reference = "Very Similar Source Code";
			else if (refPercent <= 80 && refPercent >= 60)
				reference = "Similar Source Code";
			else if (refPercent < 60)
				reference = "Partly Similar Source Code";

			if (referencePercent.equalsIgnoreCase(""))
				reference = "";
			impactedCloneAnalysis.setReference(reference);
			impactedCloneAnalysis.setAppComponent(appComponent);
			impactedCloneAnalysis.setInterfaceConcat(interfaceConcat);
			impactedCloneAnalysis.setObjTypeName(objTypeName);
			impactedCloneAnalysis.setYear(year);

			impactedCloneAnalysis.setRequestID(requestId);

			return impactedCloneAnalysis;
		}

		return null;
	}

	private S4EnhancementIntermediate getEnhancementValueXlsx(Row row, long requestId, String fileName) {

		int typeIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("OBJ"));
		int objNameIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("DESC"));
		int enhanceNameIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Act.Status"));
		int implNameIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Comment.C"));

		String type = row.getCell(typeIndex) == null ? ""
				: row.getCell(typeIndex).getStringCellValue().replaceAll("\\s", StringUtils.EMPTY);
		String objName = row.getCell(objNameIndex) == null ? ""
				: row.getCell(objNameIndex).getStringCellValue().replaceAll("\\s", StringUtils.EMPTY);
		String enhancementName = row.getCell(enhanceNameIndex) == null ? ""
				: row.getCell(enhanceNameIndex).getStringCellValue().replaceAll("\\s", StringUtils.EMPTY);
		String implName = row.getCell(implNameIndex) == null ? ""
				: row.getCell(implNameIndex).getStringCellValue().replaceAll("\\s", StringUtils.EMPTY);

		if (type.equals("BADI")) {
			final S4EnhancementIntermediate s4EnhancementIntermediate = new S4EnhancementIntermediate();

			s4EnhancementIntermediate.setType(type);
			s4EnhancementIntermediate.setObjName(objName);
			s4EnhancementIntermediate.setEnhancementName(enhancementName);
			s4EnhancementIntermediate.setImplName(implName);
			s4EnhancementIntermediate.setRequestID(requestId);

			return s4EnhancementIntermediate;
		}

		return null;
	}

	protected void addImpactedSeachData(String filePath, long requestID, HttpSession session,
			List<String> externalNamespaceList) throws FileNotFoundException, SQLException {

		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);

		String fileName = file.getName();
		try {
			List<S4ImpactedSearchHelp> s4ImpactedList = new ArrayList<S4ImpactedSearchHelp>();
			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);

			for (Row r : reader) {
				int rowIndex = Integer.parseInt(
						S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestID).get(fileName).get("Obj.Type").get(0));
				if (r.getRowNum() > rowIndex) {
					logger.info("File--" + fileName + "-----RowNum---" + r.getRowNum());

					S4ImpactedSearchHelp s4Impacted = getImpactedSearchValueXlsx(r, requestID, fileName,
							externalNamespaceList);
					if (s4Impacted != null) {
						s4ImpactedList.add(s4Impacted);
					}

				}
			}
			s4ImpactedSearchBatchInsertUpdate(s4ImpactedList, session);
			// populateHanaTable.populateDataList(s4ImpactedList);
		} finally {
			IOUtils.closeQuietly(inputStream);
		}

	}

	private S4ImpactedSearchHelp getImpactedSearchValueXlsx(Row row, long requestId, String fileName,
			List<String> externalNamespaceList) {

		int ojTypeIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("OBJ").trim());
		int objNameIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name").trim());
		int dataIndex = Integer.parseInt(
				Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Read.Prog").trim());

		String objType = row.getCell(ojTypeIndex) == null ? "" : row.getCell(ojTypeIndex).getStringCellValue();
		String objName = row.getCell(objNameIndex) == null ? "" : row.getCell(objNameIndex).getStringCellValue();
		String searchData = row.getCell(dataIndex) == null ? "" : row.getCell(dataIndex).getStringCellValue();

		if (!objType.equals("")) {
			final S4ImpactedSearchHelp s4Impacted = new S4ImpactedSearchHelp();

			s4Impacted.setSearchData(searchData);
			s4Impacted.setObjectType(objType);
			s4Impacted.setObjectName(objName);
			s4Impacted.setRequestId(requestId);

			// Setting External Namespace
			if (CollectionUtils.isNotEmpty(externalNamespaceList)
					&& !externalNamespaceList.stream().anyMatch("NA"::equalsIgnoreCase)) {
				if (!objName.isEmpty()) {
					for (String externalNamespace : externalNamespaceList) {
						if (StringUtils.containsIgnoreCase(objName.trim(), externalNamespace.trim())) {
							s4Impacted.setExternalNamespace("Y");
							break;
						}
					}
				}
			}
			return s4Impacted;
		}

		return null;

	}

	protected void addACNIP_ZVER_COMPData(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException, SQLException {

		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);

		String fileName = file.getName();
		try {
			List<ACNIPZVERComp> acnipzverCompList = new ArrayList<ACNIPZVERComp>();
			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);

			for (Row r : reader) {
				int rowIndex = Integer.parseInt(
						S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Object").get(0));
				if (r.getRowNum() > rowIndex) {
					logger.info("File--" + fileName + "-----RowNum---" + r.getRowNum());

					ACNIPZVERComp acnipzverComp = getACNIPZVERCompXlsx(r, requestId, fileName);
					if (acnipzverComp != null) {
						acnipzverCompList.add(acnipzverComp);
					}

				}
			}
			hm.setAcnipList(acnipzverCompList);
			// ACNIPZVERCompBatchInsertUpdate(acnipzverCompList, session);
			// populateHanaTable.populateDataList(s4ImpactedList);
		} finally {
			IOUtils.closeQuietly(inputStream);
		}

	}

	private ACNIPZVERComp getACNIPZVERCompXlsx(Row row, long requestId, String fileName) {

		int mandtIndex = Integer
				.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Mandt").get(1));
		int sessionIdIndex = Integer.parseInt(
				S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Session.Id").get(1));
		int serialNoIndex = Integer.parseInt(
				S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Serial.No").get(1));
		int namespaceIndex = Integer.parseInt(
				S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Namespace").get(1));
		int objectR3TRIndex = Integer.parseInt(
				S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Object.R3TR").get(1));
		int ObjNameR3TRIndex = Integer.parseInt(
				S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name.R3TR").get(1));
		int objectIndex = Integer
				.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Object").get(1));
		int ObjNameIndex = Integer
				.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name").get(1));
		int createDateIndex = Integer.parseInt(
				S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Create.Date").get(1));
		int changeDateIndex = Integer.parseInt(
				S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Change.Date").get(1));
		int devClassIndex = Integer
				.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Devclass").get(1));
		int codeSizeIndex = Integer.parseInt(
				S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Code.Size").get(1));
		int versionCountIndex = Integer.parseInt(
				S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Version.Count").get(1));
		int refInfosapIndex = Integer.parseInt(
				S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Ref.Infosap").get(1));
		int refTypeTextsapIndex = Integer.parseInt(
				S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Ref.Type.Textsap").get(1));
		int lastTransportIndex = Integer.parseInt(
				S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Last.Transport").get(1));
		int lastTransportRfcIndex = Integer.parseInt(
				S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Last.Transport.rfc").get(1));
		int object1Index = Integer
				.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Object1").get(1));
		int objName1Index = Integer.parseInt(
				S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name1").get(1));
		int length1Index = Integer
				.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Length1").get(1));
		int cntVers1Index = Integer.parseInt(
				S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Cnt.Vers1").get(1));
		int iconCompIndex = Integer.parseInt(
				S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Icon.Comp").get(1));
		int object2Index = Integer
				.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Object2").get(1));
		int objName2Index = Integer.parseInt(
				S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name2").get(1));
		int length2Index = Integer
				.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Length2").get(1));
		int cntVerse2Index = Integer.parseInt(
				S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Cnt.vers2").get(1));
		int rfcDest2Index = Integer
				.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Rfcdest2").get(1));
		int recordDateIndex = Integer.parseInt(
				S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Record.Date").get(1));
		int recordTimeIndex = Integer.parseInt(
				S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Record.Time").get(1));

		String mandt = row.getCell(mandtIndex).getStringCellValue() == null ? ""
				: row.getCell(mandtIndex).getStringCellValue().trim();
		String sessionId = row.getCell(sessionIdIndex).getStringCellValue() == null ? ""
				: row.getCell(sessionIdIndex).getStringCellValue().trim();
		String serialNo = row.getCell(serialNoIndex).getStringCellValue() == null ? ""
				: row.getCell(serialNoIndex).getStringCellValue().trim();
		String namespace = row.getCell(namespaceIndex).getStringCellValue() == null ? ""
				: row.getCell(namespaceIndex).getStringCellValue().trim();
		String objectR3TR = row.getCell(objectR3TRIndex).getStringCellValue() == null ? ""
				: row.getCell(objectR3TRIndex).getStringCellValue().trim();
		String ObjNameR3TR = row.getCell(ObjNameR3TRIndex).getStringCellValue() == null ? ""
				: row.getCell(ObjNameR3TRIndex).getStringCellValue().trim();
		String object = row.getCell(objectIndex).getStringCellValue() == null ? ""
				: row.getCell(objectIndex).getStringCellValue().trim();
		String ObjName = row.getCell(ObjNameIndex).getStringCellValue() == null ? ""
				: row.getCell(ObjNameIndex).getStringCellValue().trim();
		String createDate = row.getCell(createDateIndex).getStringCellValue() == null ? ""
				: row.getCell(createDateIndex).getStringCellValue().trim();
		String changeDate = row.getCell(changeDateIndex).getStringCellValue() == null ? ""
				: row.getCell(changeDateIndex).getStringCellValue().trim();
		String devClass = row.getCell(devClassIndex).getStringCellValue() == null ? ""
				: row.getCell(devClassIndex).getStringCellValue().trim();
		String codeSize = row.getCell(codeSizeIndex).getStringCellValue() == null ? ""
				: row.getCell(codeSizeIndex).getStringCellValue().trim();
		String versionCount = row.getCell(versionCountIndex).getStringCellValue() == null ? ""
				: row.getCell(versionCountIndex).getStringCellValue().trim();
		String refInfosap = row.getCell(refInfosapIndex).getStringCellValue() == null ? ""
				: row.getCell(refInfosapIndex).getStringCellValue().trim();
		String refTypeTextsap = row.getCell(refTypeTextsapIndex).getStringCellValue() == null ? ""
				: row.getCell(refTypeTextsapIndex).getStringCellValue().trim();
		String lastTransport = row.getCell(lastTransportIndex).getStringCellValue() == null ? ""
				: row.getCell(lastTransportIndex).getStringCellValue().trim();
		String lastTransportRfc = row.getCell(lastTransportRfcIndex).getStringCellValue() == null ? ""
				: row.getCell(lastTransportRfcIndex).getStringCellValue().trim();
		String object1 = row.getCell(object1Index).getStringCellValue() == null ? ""
				: row.getCell(object1Index).getStringCellValue().trim();
		String objName1 = row.getCell(objName1Index).getStringCellValue() == null ? ""
				: row.getCell(objName1Index).getStringCellValue().trim();
		String length1 = row.getCell(length1Index).getStringCellValue() == null ? ""
				: row.getCell(length1Index).getStringCellValue().trim();
		String cntVers1 = row.getCell(cntVers1Index).getStringCellValue() == null ? ""
				: row.getCell(cntVers1Index).getStringCellValue().trim();
		String iconComp = row.getCell(iconCompIndex).getStringCellValue() == null ? ""
				: row.getCell(iconCompIndex).getStringCellValue().trim();
		String object2 = row.getCell(object2Index).getStringCellValue() == null ? ""
				: row.getCell(object2Index).getStringCellValue().trim();
		String objName2 = row.getCell(objName2Index).getStringCellValue() == null ? ""
				: row.getCell(objName2Index).getStringCellValue().trim();
		String length2 = row.getCell(length2Index).getStringCellValue() == null ? ""
				: row.getCell(length2Index).getStringCellValue().trim();
		String cntVers2 = row.getCell(cntVerse2Index).getStringCellValue() == null ? ""
				: row.getCell(cntVerse2Index).getStringCellValue().trim();
		String rfcDest2 = row.getCell(rfcDest2Index).getStringCellValue() == null ? ""
				: row.getCell(rfcDest2Index).getStringCellValue().trim();
		String recordDate = row.getCell(recordDateIndex).getStringCellValue() == null ? ""
				: row.getCell(recordDateIndex).getStringCellValue().trim();
		String recordTime = row.getCell(recordTimeIndex).getStringCellValue() == null ? ""
				: row.getCell(recordTimeIndex).getStringCellValue().trim();

		if (!object.equals("")) {
			final ACNIPZVERComp acnipzverComp = new ACNIPZVERComp();

			acnipzverComp.setMandt(mandt);
			acnipzverComp.setSessionId(sessionId);
			acnipzverComp.setSerialNo(serialNo);
			acnipzverComp.setNamespace(namespace);
			acnipzverComp.setObjectR3TR(objectR3TR);
			acnipzverComp.setObjNameR3TR(ObjNameR3TR);
			acnipzverComp.setObject(object);
			acnipzverComp.setObjName(ObjName);
			acnipzverComp.setCreateDate(createDate);
			acnipzverComp.setChangeDate(changeDate);
			acnipzverComp.setDevClass(devClass);
			acnipzverComp.setCodeSize(codeSize);
			acnipzverComp.setVersionCount(versionCount);
			acnipzverComp.setRefInfosap(refInfosap);
			acnipzverComp.setRefTypeTextsap(refTypeTextsap);
			acnipzverComp.setLastTransport(lastTransport);
			acnipzverComp.setLastTransportRfc(lastTransportRfc);
			acnipzverComp.setObject1(object1);
			acnipzverComp.setObjName1(objName1);
			acnipzverComp.setLength1(length1);
			acnipzverComp.setCntVers1(cntVers1);
			acnipzverComp.setIconComp(iconComp);
			acnipzverComp.setObject2(object2);
			acnipzverComp.setObjName2(objName2);
			acnipzverComp.setLength2(length2);
			acnipzverComp.setCntVers2(cntVers2);
			acnipzverComp.setRfcDest2(rfcDest2);
			acnipzverComp.setRecordDate(recordDate);
			acnipzverComp.setRecordTime(recordTime);

			acnipzverComp.setRequestID(requestId);

			return acnipzverComp;
		}

		return null;

	}

	// BW_Extractor
	protected void addBWExtractorData(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException, SQLException {

		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);

		String fileName = file.getName();
		try {
			List<BWExtractor> bwExtractorList = new ArrayList<BWExtractor>();
			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);

			for (Row r : reader) {
				int rowIndex = Integer.parseInt(
						S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("OLTSOURCE").get(0));
				if (r.getRowNum() > rowIndex) {
					logger.info("File--" + fileName + "-----RowNum---" + r.getRowNum());

					BWExtractor bwExtractor = getBWExtractorXlsx(r, requestId, fileName);
					if (bwExtractor != null) {
						bwExtractorList.add(bwExtractor);
					}

				}
			}

			BWExtractBatchInsertUpdate(bwExtractorList, session);
		} finally {
			IOUtils.closeQuietly(inputStream);
		}

	}

	private BWExtractor getBWExtractorXlsx(Row row, long requestId, String fileName) {

		int oltsourceIndex = Integer.parseInt(
				S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("OLTSOURCE").get(1));
		int extractorIndex = Integer.parseInt(
				S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("EXTRACTOR").get(1));

		String oltsource = row.getCell(oltsourceIndex).getStringCellValue() == null ? ""
				: row.getCell(oltsourceIndex).getStringCellValue().trim();
		String extractor = row.getCell(extractorIndex).getStringCellValue() == null ? ""
				: row.getCell(extractorIndex).getStringCellValue().trim();

		final BWExtractor bwExtractor = new BWExtractor();

		bwExtractor.setOltsource(oltsource);
		bwExtractor.setExtractor(extractor);
		bwExtractor.setRequestID(requestId);

		return bwExtractor;

	}

	protected void addAppendStructureData(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException, SQLException {

		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);

		String fileName = file.getName();
		try {
			List<S4AppendStructureAnalysis> s4AppendList = new ArrayList<S4AppendStructureAnalysis>();
			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);

			for (Row r : reader) {
				int rowIndex = Integer.parseInt(
						S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Table.Name").get(0));
				if (r.getRowNum() > rowIndex) {
					logger.info("File--" + fileName + "-----RowNum---" + r.getRowNum());

					S4AppendStructureAnalysis s4AppendStructureAnalysis = getAppendValueXlsx(r, requestId, fileName);
					if (s4AppendStructureAnalysis != null) {
						s4AppendList.add(s4AppendStructureAnalysis);
					}

				}
			}
			AppendStructureBatchInsertUpdate(s4AppendList, session);
			// populateHanaTable.populateDataList(s4AppendList);
		} finally {
			IOUtils.closeQuietly(inputStream);
		}

	}

	private S4AppendStructureAnalysis getAppendValueXlsx(Row row, long requestId, String fileName) {

		int tableNameIndex = Integer.parseInt(
				S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Table.Name").get(1));
		int fieldNameIndex = Integer.parseInt(
				S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Field.Name").get(1));
		int nameIncludeIndex = Integer.parseInt(
				S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Name.Include").get(1));

		String tableName = row.getCell(tableNameIndex) == null ? "" : row.getCell(tableNameIndex).getStringCellValue();
		String fieldName = row.getCell(fieldNameIndex) == null ? "" : row.getCell(fieldNameIndex).getStringCellValue();
		String nameInclude = row.getCell(nameIncludeIndex) == null ? ""
				: row.getCell(nameIncludeIndex).getStringCellValue();

		if (!tableName.equals("")) {
			final S4AppendStructureAnalysis s4AppendStructureAnalysis = new S4AppendStructureAnalysis();

			s4AppendStructureAnalysis.setTableName(tableName);
			s4AppendStructureAnalysis.setFieldName(fieldName);
			s4AppendStructureAnalysis.setNameOfInclude(nameInclude);
			s4AppendStructureAnalysis.setRequestId(requestId);

			return s4AppendStructureAnalysis;
		}

		return null;

	}

	// DEF075
	protected void addImpactedIDOCData(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException, SQLException {

		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);

		String fileName = file.getName();
		try {
			List<S4ImpactedIDOC> s4ImpactedIDOCList = new ArrayList<S4ImpactedIDOC>();
			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);

			for (Row r : reader) {
				int rowIndex = Integer.parseInt(
						S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Identifier").get(0));
				if (r.getRowNum() > rowIndex) {
					logger.info("File--" + fileName + "-----RowNum---" + r.getRowNum());
					int msgTypeIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("IDOC.MSG.TYPE").get(1));
					if (r.getCell(msgTypeIndex) != null && !r.getCell(msgTypeIndex).getStringCellValue().isEmpty()) {
						S4ImpactedIDOC s4ImpactedIDOCIntermediate = getImpactedIDOCXlsx(r, requestId, fileName);
						if (s4ImpactedIDOCIntermediate != null) {
							s4ImpactedIDOCList.add(s4ImpactedIDOCIntermediate);
						}

					} else {
						if (r.getRowNum() == rowIndex + 5) {
							break;
						}
					}
				}
			}
			s4ImpactedIDOCBatchInsertUpdate(s4ImpactedIDOCList, session);
			// s4ImpactedIDOCIntermediateBatchInsertUpdate(s4ImpactedIDOCList,
			// session);

		} finally {
			IOUtils.closeQuietly(inputStream);
		}

	}

	private S4ImpactedIDOC getImpactedIDOCXlsx(Row row, long requestId, String fileName) {
		int identifierIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("OBJ.Pckg"));
		int msgTypeIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name"));
		int basicTypeIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sub.Type"));
		int segmentIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Comment.C"));
		int operationIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Operation"));
		int readProgIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Read.Prog"));

		String identifier = row.getCell(identifierIndex) == null ? ""
				: row.getCell(identifierIndex).getStringCellValue().replaceAll("\\s", StringUtils.EMPTY);
		String msgType = row.getCell(msgTypeIndex) == null ? ""
				: row.getCell(msgTypeIndex).getStringCellValue().replaceAll("\\s", StringUtils.EMPTY);
		String basicType = row.getCell(basicTypeIndex) == null ? ""
				: row.getCell(basicTypeIndex).getStringCellValue().replaceAll("\\s", StringUtils.EMPTY);
		String segment = row.getCell(segmentIndex) == null ? ""
				: row.getCell(segmentIndex).getStringCellValue().replaceAll("\\s", StringUtils.EMPTY);
		String operation = row.getCell(operationIndex) == null ? ""
				: row.getCell(operationIndex).getStringCellValue().trim();
		String readProg = row.getCell(readProgIndex) == null ? ""
				: row.getCell(readProgIndex).getStringCellValue().trim();

		if (!identifier.equals("")) {
			final S4ImpactedIDOC s4ImpactedIDOC = new S4ImpactedIDOC();

			s4ImpactedIDOC.setIdentifier(identifier);
			if (basicType.isEmpty())
				s4ImpactedIDOC.setBasicType(readProg);
			else
				s4ImpactedIDOC.setBasicType(basicType);
			s4ImpactedIDOC.setMsgType(msgType);
			s4ImpactedIDOC.setSegment(segment);
			s4ImpactedIDOC.setTypeOfIDOC(operation);
			s4ImpactedIDOC.setRequestID(requestId);

			return s4ImpactedIDOC;
		}

		return null;
	}

	/*
	 * protected void addIDOCData(String filePath, long requestID, HttpSession
	 * session) throws FileNotFoundException, SQLException { File file = new
	 * File(filePath); InputStream inputStream = new FileInputStream(file);
	 * 
	 * String fileName = file.getName(); try { List<S4ImpactedIDOC>
	 * s4ImpactedIDOCList = new ArrayList<S4ImpactedIDOC>(); StreamingReader
	 * reader =
	 * StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(
	 * 0) .read(inputStream);
	 * 
	 * for (Row r : reader) { int rowIndex = Integer.parseInt(
	 * S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestID).get(fileName).
	 * get( "Identifier").get(0)); if (r.getRowNum() > rowIndex) {
	 * 
	 * logger.info("File--" + fileName + "-----RowNum---" + r.getRowNum()); int
	 * basicTypeIndex =
	 * Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestID)
	 * .get(fileName).get("Basic.type").get(1)); if (r.getCell(basicTypeIndex)
	 * != null && !r.getCell(basicTypeIndex).getStringCellValue().isEmpty()) {
	 * 
	 * S4ImpactedIDOC s4ImpactedIDOC = getImpactedIDOCValueXlsx(r, requestID,
	 * fileName); if (s4ImpactedIDOC != null) {
	 * s4ImpactedIDOCList.add(s4ImpactedIDOC); } } else { if (r.getRowNum() ==
	 * rowIndex + 5) { break; } } } }
	 * s4ImpactedIDOCBatchInsertUpdate(s4ImpactedIDOCList, session); //
	 * populateHanaTable.populateDataList(s4ImpactedIDOCList); } finally {
	 * IOUtils.closeQuietly(inputStream); }
	 * 
	 * }
	 */
	/*
	 * private S4ImpactedIDOC getImpactedIDOCValueXlsx(Row row, long requestId,
	 * String fileName) {
	 * 
	 * int basicTypeIndex = Integer.parseInt(
	 * S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).
	 * get( "Basic.type").get(1)); int extensionIndex = Integer.parseInt(
	 * S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).
	 * get( "Extension").get(1)); int segmentTypeIndex = Integer.parseInt(
	 * S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).
	 * get( "Segment.type").get(1)); int positionFieldIndex =
	 * Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).
	 * get( fileName) .get("Position.field.table").get(1)); int fieldNameIndex =
	 * Integer.parseInt(
	 * S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).
	 * get( "Field.Name").get(1)); int dataElementIndex = Integer.parseInt(
	 * S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).
	 * get( "Data.element").get(1)); int idocDevIndex = Integer
	 * .parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(
	 * fileName).get("IDOC.Dev").get(1));
	 * 
	 * String basicType = row.getCell(basicTypeIndex) == null ? "" :
	 * row.getCell(basicTypeIndex).getStringCellValue();
	 * 
	 * if (!basicType.equals("")) { final S4ImpactedIDOC s4ImpactedIDOC = new
	 * S4ImpactedIDOC();
	 * 
	 * s4ImpactedIDOC.setBasicType(basicType); s4ImpactedIDOC.setExtension(
	 * row.getCell(extensionIndex) == null ? "" :
	 * row.getCell(extensionIndex).getStringCellValue());
	 * s4ImpactedIDOC.setSegmentType( row.getCell(segmentTypeIndex) == null ? ""
	 * : row.getCell(segmentTypeIndex).getStringCellValue());
	 * s4ImpactedIDOC.setPositionFieldInTable(row.getCell(positionFieldIndex) ==
	 * null ? "" : row.getCell(positionFieldIndex).getStringCellValue());
	 * s4ImpactedIDOC.setFieldName( row.getCell(fieldNameIndex) == null ? "" :
	 * row.getCell(fieldNameIndex).getStringCellValue());
	 * s4ImpactedIDOC.setDataElement( row.getCell(dataElementIndex) == null ? ""
	 * : row.getCell(dataElementIndex).getStringCellValue());
	 * s4ImpactedIDOC.setIdocDev( row.getCell(idocDevIndex) == null ? "" :
	 * row.getCell(idocDevIndex).getStringCellValue());
	 * s4ImpactedIDOC.setRequestID(requestId);
	 * 
	 * return s4ImpactedIDOC; }
	 * 
	 * return null; }
	 */
	protected void addImpactedTableData(String filePath, long requestID, HttpSession session)
			throws FileNotFoundException, SQLException {
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);

		String fileName = file.getName();
		try {
			List<S4ImpactedTables> s4ImpactedTableList = new ArrayList<S4ImpactedTables>();
			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);

			for (Row r : reader) {
				int rowIndex = Integer.parseInt(
						S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestID).get(fileName).get("Object").get(0));
				if (r.getRowNum() > rowIndex) {
					logger.info("File--" + fileName + "-----RowNum---" + r.getRowNum());
					int objectIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestID).get(fileName).get("Object").get(1));
					if (r.getCell(objectIndex) != null && !r.getCell(objectIndex).getStringCellValue().isEmpty()) {

						S4ImpactedTables s4ImpactedTables = getImpactedTablesValueXlsx(r, requestID, fileName);
						if (s4ImpactedTables != null) {
							s4ImpactedTableList.add(s4ImpactedTables);
						}
					} else {
						if (r.getRowNum() == rowIndex + 5) {
							break;
						}
					}
				}
			}
			s4ImpactedTableBatchInsertUpdate(s4ImpactedTableList, session);
			// populateHanaTable.populateDataList(s4ImpactedTableList);
		} finally {
			IOUtils.closeQuietly(inputStream);
		}

	}

	private List<S4ImpactedTables> getImpactedTablesList(long requestId, Set<String> objectSet) {
		List<S4ImpactedTables> s4ImpactedTableList = new ArrayList<S4ImpactedTables>();
		Iterator<String> objecItr = objectSet.iterator();

		while (objecItr.hasNext()) {

			final S4ImpactedTables s4ImpactedTables = new S4ImpactedTables();

			s4ImpactedTables.setObject(objecItr.next());
			s4ImpactedTables.setRequestID(requestId);
			s4ImpactedTableList.add(s4ImpactedTables);

		}
		return s4ImpactedTableList;

	}

	private S4ImpactedTables getImpactedTablesValueXlsx(Row row, long requestId, String fileName) {

		int objectIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name"));
		String object = row.getCell(objectIndex) == null ? "" : row.getCell(objectIndex).getStringCellValue().trim();
		int usedIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Read.Prog"));
		String used = row.getCell(usedIndex) == null ? "" : row.getCell(usedIndex).getStringCellValue().trim();
		if (!object.equals("") && used.equalsIgnoreCase("Yes")) {
			final S4ImpactedTables s4ImpactedTables = new S4ImpactedTables();

			s4ImpactedTables.setObject(object.trim());
			s4ImpactedTables.setRequestID(requestId);

			return s4ImpactedTables;
		}

		return null;
	}

	protected void addImpactedTransactionData(String filePath, long requestID, HttpSession session)
			throws FileNotFoundException, SQLException {
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);

		String fileName = file.getName();
		try {
			List<S4ImpactedTransaction> s4ImpactedTransactionList = new ArrayList<S4ImpactedTransaction>();
			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);

			for (Row r : reader) {
				int rowIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestID).get(fileName)
						.get("Impacted.Transactions").get(0));
				if (r.getRowNum() > rowIndex) {
					logger.info("File--" + fileName + "-----RowNum---" + r.getRowNum());
					int transactionIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestID)
							.get(fileName).get("Impacted.Transactions").get(1));
					if (r.getCell(transactionIndex) != null
							&& !r.getCell(transactionIndex).getStringCellValue().isEmpty()) {

						S4ImpactedTransaction s4ImpactedTransaction = getImpactedTransactionValueXlsx(r, requestID,
								fileName);
						if (s4ImpactedTransaction != null) {
							s4ImpactedTransactionList.add(s4ImpactedTransaction);
						}
					} else {
						if (r.getRowNum() == rowIndex + 5) {
							break;
						}
					}
				}
			}
			s4ImpactedStandardBatchInsertUpdate(s4ImpactedTransactionList, session);
			// populateHanaTable.populateDataList(s4ImpactedTransactionList);
		} finally {
			IOUtils.closeQuietly(inputStream);
		}

	}

	private S4ImpactedTransaction getImpactedTransactionValueXlsx(Row row, long requestId, String fileName) {

		int transactionIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName)
				.get("Impacted.Transactions").get(1));
		String transaction = row.getCell(transactionIndex) == null ? ""
				: row.getCell(transactionIndex).getStringCellValue();

		if (!transaction.equals("")) {

			final S4ImpactedTransaction s4ImpactedTransaction = new S4ImpactedTransaction();

			s4ImpactedTransaction.setImpactedTransaction(transaction.trim());
			s4ImpactedTransaction.setRequestID(requestId);

			return s4ImpactedTransaction;
		}
		return null;
	}

	public static void processS4Detection(CodeAssessmentPayLoad ca, HttpSession session) throws SQLException {

		List<S4Detection> s4DetectionList = ca.getS4DetectionList();
		String result = s4DetectionBatchInsertUpdate(s4DetectionList, session);
		if (result.equals("SUCCESS")) {
			logger.info("S4 Detection Data INSERTED SUCCESSFULLY");
		} else {
			logger.info("Unsuccessful!!!!!!!!!!!!!!!!");
		}

	}

	public static String aUCTBatchInsertUpdate(List<AuctFinalOutput> auctList, HttpSession session)
			throws SQLException {

		final String INSERT_SQL = "INSERT INTO Auct_Final_Output "
				+ "(INFO, LINE_NUMBER, OBJ_NAME, OBJ_NAME_TYPE, OBJ_PACKAGE, OPCODE, OPERCD, READ_PROG, REQUEST_ID, SUB_TYPE, TOTAL_LINE_NUMBER, "
				+ "TYPE, Used_Unused, AUTOMATION_STATUS, External_Namespace, CODE) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (AuctFinalOutput auct : auctList) {
					stmt.setString(1, auct.getINFO());
					stmt.setLong(2, auct.getLINE_NUMBER());
					stmt.setString(3, auct.getOBJ_NAME());
					stmt.setString(4, auct.getOBJ_NAME_TYPE());
					stmt.setString(5, auct.getOBJ_PACKAGE());
					stmt.setString(6, auct.getOPCODE());
					stmt.setString(7, auct.getOPERCD());
					stmt.setString(8, auct.getREAD_PROG());
					stmt.setLong(9, auct.getREQUEST_ID());
					stmt.setString(10, auct.getSUB_TYPE());
					stmt.setLong(11, auct.getTOTAL_LINE_NUMBER());
					stmt.setString(12, auct.getTYPE());
					stmt.setString(13, auct.getUsed_Unused());
					stmt.setString(14, auct.getAUTOMATION_STATUS());
					stmt.setString(15, auct.getExtNamespace());
					stmt.setString(16, auct.getCODE());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}
				stmt.executeBatch();
				conn.commit();
				logger.info("Final batch executed successfully");

				// updateAUCTAutomationStatus(auctList);

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;
	}

	/*
	 * private static String updateAUCTAutomationStatus(List<AuctFinalOutput>
	 * auctList) throws SQLException { long start = System.currentTimeMillis();
	 * logger.
	 * info("start of updateAutomationStatus:::::::::::::::::::::::::::::::::::::::::::::::::"
	 * +start);
	 * 
	 * final String UPDATE_SQL =
	 * "UPDATE auct_final_output auct LEFT JOIN operation_data odata ON auct.OPCODE = odata.OPERAION_CODE SET auct.AUTOMATION_STATUS= odata.Automation_Status"
	 * ;
	 * 
	 * String jdbcUrl = "jdbc:mysql://localhost:3306/hanadb1"; String username =
	 * "root"; String password = "root"; String result = "SUCCESS";
	 * java.sql.Connection conn= null; java.sql.PreparedStatement stmt= null;
	 * try { conn = DriverManager.getConnection(jdbcUrl, username, password);
	 * int counter=1; conn.setAutoCommit(false); try { stmt =
	 * conn.prepareStatement(UPDATE_SQL); int batch = 1;
	 * 
	 * for (AuctFinalOutput auct : auctList) { stmt.setString(1,
	 * auct.getAUTOMATION_STATUS());
	 * 
	 * //Add statement to batch stmt.addBatch(); counter++; //Execute batch of
	 * 1000 records if(counter%1000==0){ counter=0; stmt.executeBatch();
	 * conn.commit();
	 * System.out.println("Batch "+(batch++)+" executed successfully"); } }
	 * 
	 * stmt.executeBatch(); conn.commit();
	 * System.out.println("Final batch executed successfully");
	 * 
	 * }catch(Exception e) { result = "FAILURE in insert";
	 * System.out.println(e.getMessage()); } } catch(Exception e) { result =
	 * "FAILURE in Getting Connection"; System.out.println(e.getMessage());
	 * 
	 * } finally { stmt.close(); conn.close(); }
	 * 
	 * 
	 * return result;
	 * 
	 * 
	 * }
	 */
	public static String s4DetectionBatchInsertUpdate(List<S4Detection> s4DetectionList, HttpSession session)
			throws SQLException {

		final String INSERT_SQL = "INSERT INTO S4_DETECTION "
				+ "(COMMENTS, COUNTER, DESCRIPTION, EXEC_BY, EXEC_DATE, EXEC_TIME, IDENTIFIER, LINE_NO, OBJ_NAME_TYPE, OBJ_PACKAGE, "
				+ "OBJ_TYPE, OBJ_NAME, OPERATIONS, REQUEST_ID, SESSION_ID, STATEMENT, SUB_PROGRAM, SUB_TYPE, TOOL_VERSION, "
				+ "Total_Scanned_Line, TYPE, READ_PROG, USED, CUSTOM_FIELDS, SELECT_LINE, Correction_ProgName, Correction_LineNo, External_Namespace, Automation_Status) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (S4Detection s4Detection : s4DetectionList) {
					stmt.setString(1, s4Detection.getComments());
					stmt.setString(2, s4Detection.getCounter());
					stmt.setString(3, s4Detection.getDescription());
					stmt.setString(4, s4Detection.getExecBy());
					stmt.setString(5, s4Detection.getExecDate());
					stmt.setString(6, s4Detection.getExecTime());
					stmt.setString(7, s4Detection.getIdentifier());
					stmt.setLong(8, s4Detection.getLineNo());
					stmt.setString(9, s4Detection.getObjNameType());
					stmt.setString(10, s4Detection.getObjPackage());
					stmt.setString(11, s4Detection.getObjType());
					stmt.setString(12, s4Detection.getObjectName());
					stmt.setString(13, s4Detection.getOperations());
					stmt.setLong(14, s4Detection.getRequestId());
					stmt.setLong(15, s4Detection.getSessionId());
					stmt.setString(16, s4Detection.getStatement());
					stmt.setString(17, s4Detection.getSubProgram());
					stmt.setString(18, s4Detection.getSubType());
					stmt.setLong(19, s4Detection.getToolVersion());
					stmt.setLong(20, s4Detection.getTotalScannedLine());
					stmt.setString(21, s4Detection.getType());
					stmt.setString(22, s4Detection.getREAD_PROG());
					stmt.setString(23, s4Detection.getUsed());
					stmt.setString(24, s4Detection.getCustomFields());
					stmt.setString(25, s4Detection.getSelectLine());
					stmt.setString(26, s4Detection.getCorProgName());
					stmt.setString(27, s4Detection.getCorLineNo());
					stmt.setString(28, s4Detection.getExtNamespace());
					stmt.setString(29, s4Detection.getAutomationStatus());
					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("S4 Detection Data INSERTED SUCCESSFULLY");
			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;
	}

	public static String s4CVITRBatchInsertUpdate(List<S4cvitr> cvitrList, HttpSession session) throws SQLException {

		final String INSERT_SQL = "INSERT INTO S4_CVITR "
				+ "(COMMENTS, COMMENT_C, SELECT_LINE, IDENTIFIER, REQUEST_ID, NEW_LINE, VENDOR_EXTERNAL, CUSTOMER_EXTERNAL) values (?, ?, ?, ?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;

		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (S4cvitr cvitr : cvitrList) {
					stmt.setString(1, cvitr.getComments());
					stmt.setString(2, cvitr.getCommentC());
					stmt.setString(3, cvitr.getSelectLine());
					stmt.setString(4, cvitr.getIdentifier());
					stmt.setLong(5, cvitr.getRequestID());
					stmt.setString(6, cvitr.getNewLine());
					stmt.setString(7, cvitr.getVendorExt());
					stmt.setString(8, cvitr.getCustomerExt());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("S4 CVITR Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}

		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;
	}

	public String inconsistentFUGRInsert(List<InconsistentFUGR> inconsistentFUGRList, HttpSession session)
			throws SQLException {
		final String INSERT_SQL = "INSERT INTO Inconsitent_FUGR "
				+ "(request_id, object_type, fugr_name, master_program, External_Namespace) "
				+ "values (?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {
			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;
				for (InconsistentFUGR inconsistentFUGR : inconsistentFUGRList) {
					stmt.setLong(1, inconsistentFUGR.getRequestId());
					stmt.setString(2, inconsistentFUGR.getObjectType());
					stmt.setString(3, inconsistentFUGR.getFugrName());
					stmt.setString(4, inconsistentFUGR.getMasterProgram());
					stmt.setString(5, inconsistentFUGR.getExternalNamespace());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 1000 records
					if (counter % 1000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();

				logger.info("Inconsistent FUGR Data INSERTED SUCCESSFULLY");
			} catch (Exception e) {
				result = "FAILURE in inserting data into Inconsistent FUGR DB";
				logger.error(result + " --- " + e.getMessage());
			}

		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(result + " --- " + e.getMessage());
		} finally {
			stmt.close();
			conn.close();
		}

		return result;
	}

	public String s4SIDInsert(List<S4_SID> s4SIDList, HttpSession session) throws SQLException {
		final String INSERT_SQL = "INSERT INTO S4_SID "
				+ "(REQUEST_ID, OBJ_NAME, SUB_OBJ_TYPE, PCKG, USED, TYPE, LINE_NO, STMT, OPERATIONS, IMPACT_REASON, DESC_OF_CHANGE"
				+ ", SOLUTION_STEPS, Complexity, ISSUE_CATEGORY, IDENTIFIER, Total_Scanned_Line, OBJ_NAME_TYPE, READ_PROG"
				+ ", Automation_Status, EXTERNAL_NAMESPACE) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {
			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;
				for (S4_SID s4SID : s4SIDList) {
					stmt.setLong(1, s4SID.getRequestID());
					stmt.setString(2, s4SID.getObjName());
					stmt.setString(3, s4SID.getSubObjType());
					stmt.setString(4, s4SID.getPckg());
					stmt.setString(5, s4SID.getUsed());
					stmt.setString(6, s4SID.getType());
					stmt.setInt(7, s4SID.getLineNo());
					stmt.setString(8, s4SID.getStmt());
					stmt.setString(9, s4SID.getOperations());
					stmt.setString(10, s4SID.getImpactReason());
					stmt.setString(11, s4SID.getDescOfChange());
					stmt.setString(12, s4SID.getSolutionSteps());
					stmt.setString(13, s4SID.getComplexity());
					stmt.setString(14, s4SID.getIssueCategory());
					stmt.setString(15, s4SID.getIdentifier());
					stmt.setInt(16, s4SID.getTotalScannedLine());
					stmt.setString(17, s4SID.getObjNameType());
					stmt.setString(18, s4SID.getReadProgram());
					stmt.setString(19, s4SID.getAutomationStatus());
					stmt.setString(20, s4SID.getExternalNamespace());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 1000 records
					if (counter % 1000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();

				logger.info("S4 SID Data INSERTED SUCCESSFULLY");
			} catch (Exception e) {
				result = "FAILURE in inserting data into S4 SID DB";
				logger.error(result + " --- " + e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(result + " --- " + e.getMessage());
		} finally {
			stmt.close();
			conn.close();
		}

		return result;
	}

	public String impactedVariantInsert(List<ImpactedVariant> impactedVariantList, HttpSession session)
			throws SQLException {
		final String INSERT_SQL = "INSERT INTO Impacted_Variant "
				+ "(Request_ID, Report_Name, Variant_Name, Selection_Screen_Field_Name, Kind, Sign, Low, High, Variant_Option, User_Name, Variant_Type"
				+ ", Comments, Variant_Operation, EXTERNAL_NAMESPACE) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {
			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;
				for (ImpactedVariant impactedVariant : impactedVariantList) {
					stmt.setLong(1, impactedVariant.getRequestID());
					stmt.setString(2, impactedVariant.getReportName());
					stmt.setString(3, impactedVariant.getVariantName());
					stmt.setString(4, impactedVariant.getSelScreenFieldName());
					stmt.setString(5, impactedVariant.getKind());
					stmt.setString(6, impactedVariant.getSign());
					stmt.setString(7, impactedVariant.getLow());
					stmt.setString(8, impactedVariant.getHigh());
					stmt.setString(9, impactedVariant.getVariantOption());
					stmt.setString(10, impactedVariant.getUserName());
					stmt.setString(11, impactedVariant.getVariantType());
					stmt.setString(12, impactedVariant.getComments());
					stmt.setString(13, impactedVariant.getVariantOperation());
					stmt.setString(14, impactedVariant.getExternalNamespace());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 1000 records
					if (counter % 1000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();

				logger.info("Impacted Variant Data INSERTED SUCCESSFULLY");
			} catch (Exception e) {
				result = "FAILURE in inserting data into Impacted Variant DB";
				logger.error(result + " --- " + e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(result + " --- " + e.getMessage());
		} finally {
			stmt.close();
			conn.close();
		}

		return result;
	}

	public static String impactedBackgroundJobBatchInsertUpdate(List<ImpactedBackgroundJob> impactedBackgroundJobList,
			HttpSession session) throws SQLException {

		final String INSERT_SQL = "INSERT INTO Impacted_Background_Job "
				+ "(OBJECT, OBJECT_NAME, SUB_TYPE, READ_PROG, OBJ_PACKAGE, ACT_STATUS,Request_Id, External_Namespace) values (?, ?, ?, ?, ?, ?,?,?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (ImpactedBackgroundJob impactedBackgroundJob : impactedBackgroundJobList) {
					stmt.setString(1, impactedBackgroundJob.getObject());
					stmt.setString(2, impactedBackgroundJob.getObjectName());
					stmt.setString(3, impactedBackgroundJob.getSubType());
					stmt.setString(4, impactedBackgroundJob.getREAD_PROG());
					stmt.setString(5, impactedBackgroundJob.getObjPackage());
					stmt.setString(6, impactedBackgroundJob.getActStatus());
					stmt.setLong(7, impactedBackgroundJob.getRequestId());
					stmt.setString(8, impactedBackgroundJob.getExternalNamespace());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("Impacted_Background_Job Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	public static String s4InventoryListBatchInsertUpdate(List<S4InventoryList> inventoryList, HttpSession session)
			throws SQLException {

		final String INSERT_SQL = "INSERT INTO S4_Inventory_List "
				+ "(OBJ_NAME, OBJ_NAME_TYPE, OBJ_TYPE, Package, Count_Lines, "
				+ "External_Namespace, Transport_Request, REQUEST_ID, User_Group, ABAP_Query, Read_Prog, "
				+ "CREATED_BY, CREATED_ON, CHANGED_BY, CHANGED_ON, TR, TR_STATUS) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (S4InventoryList s4Inventory : inventoryList) {
					stmt.setString(1, s4Inventory.getObjName());
					stmt.setString(2, s4Inventory.getObjNameType());
					stmt.setString(3, s4Inventory.getObjType());
					stmt.setString(4, s4Inventory.getPckg());
					stmt.setObject(5, s4Inventory.getCountLines());
					stmt.setString(6, s4Inventory.getExtNamespace());
					stmt.setString(7, s4Inventory.getTransReq());
					stmt.setLong(8, s4Inventory.getRequestID());
					stmt.setString(9, s4Inventory.getUserGroup());
					stmt.setString(10, s4Inventory.getABAPQuery());
					stmt.setString(11, s4Inventory.getReadProg());
					// stmt.setString(9, s4Inventory.getUsage());
					stmt.setString(12, s4Inventory.getCreatedBy());
					stmt.setString(13, s4Inventory.getCreatedOn());
					stmt.setString(14, s4Inventory.getChangedBy());
					stmt.setString(15, s4Inventory.getChangedOn());
					stmt.setString(16, s4Inventory.getTr());
					stmt.setString(17, s4Inventory.getTrStatus());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("S4_Inventory_List Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	public static String UI5BatchInsertUpdate(List<UI5InputExtract> UI5InputExtractList, HttpSession session)
			throws SQLException {

		final String INSERT_SQL = "INSERT INTO UI5_EXTRACT "
				+ "(UI_Element, REQUEST_ID, Attribute, LineNumber, FileName, ProjectName ) values (?, ?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (UI5InputExtract ui5 : UI5InputExtractList) {

					long requestid = ui5.getREQUEST_ID();
					stmt.setString(1, ui5.getUielemt());
					stmt.setLong(2, requestid);
					stmt.setString(3, ui5.getAttribute());
					stmt.setInt(4, ui5.getLinenumber());
					stmt.setString(5, ui5.getFilename());
					stmt.setString(6, ui5.getProjectName());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("UI5 Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	public static String TRDRBatchInsertUpdate(List<TRDR_DATA> trdrDataList, HttpSession session) throws SQLException {

		final String INSERT_SQL = "INSERT INTO TR_DR_RECORDS " + "(NAME, Request_ID, SUBC) values (?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (TRDR_DATA trd : trdrDataList) {

					long requestid = trd.getRequestID().longValue();
					stmt.setString(1, trd.getName());
					stmt.setLong(2, requestid);
					stmt.setString(3, trd.getSubc());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("TR_DR_RECORDS Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	public static String TADIRBatchInsertUpdate(List<ST03Tadir> tadirDataList, HttpSession session)
			throws SQLException {

		final String INSERT_SQL = "INSERT INTO ST03_TADIR " + "(objectName, objectType, requestID) values (?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (ST03Tadir tadir : tadirDataList) {
					long requestid = tadir.getRequestID().longValue();
					stmt.setString(1, tadir.getObjectName());
					stmt.setString(2, tadir.getObjectType());
					stmt.setLong(3, requestid);

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("ST03_TADIR Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	public static String enhancementBatchInsertUpdate(List<S4EnhancementIntermediate> s4EnhancementIntermediateList,
			HttpSession session) throws SQLException {

		final String INSERT_SQL = "INSERT INTO S4_Enhancement_Intermediate "
				+ "(TYPE, OBJECT_NAME, ENHANCEMENT_NAME, IMPLEMENTATION_NAME, REQUEST_ID) values (?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (S4EnhancementIntermediate s4Enhancement : s4EnhancementIntermediateList) {
					stmt.setString(1, s4Enhancement.getType());
					stmt.setString(2, s4Enhancement.getObjName());
					stmt.setString(3, s4Enhancement.getEnhancementName());
					stmt.setString(4, s4Enhancement.getImplName());
					stmt.setLong(5, s4Enhancement.getRequestID());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("S4_Enhancement_Intermediate Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	public static String cloneProgBatchInsertUpdate(List<S4CloneIntermediate> s4CloneProgIntermediateList,
			HttpSession session) throws SQLException {

		final String INSERT_SQL = "INSERT INTO S4_Clone_Prog_Intermediate "
				+ "(INCLUDE, OBJ_NAME, OBJ_TYPE, REQUEST_ID) values (?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (S4CloneIntermediate cloneProg : s4CloneProgIntermediateList) {
					stmt.setString(1, cloneProg.getInclude());
					stmt.setString(2, cloneProg.getObjName());
					stmt.setString(3, cloneProg.getObjType());
					stmt.setLong(4, cloneProg.getRequestId());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("S4_Clone_Prog_Intermediate Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	public static String impactedCloneBatchInsertUpdate(List<ImpactedCloneAnalysis> impactedCloneList,
			HttpSession session) throws SQLException {

		final String INSERT_SQL = "INSERT INTO IMPACTED_CLONE_ANALYSIS "
				+ "(APPLICATION_COMPONENT, CREATION_DATE, INTERFACE, INTERFACE_OBJECT_TYPE, NAMESPACE, OBJECT_NAME, PACKAGE, OBJECT_TYPE,  REFERENCE, REFERENCE_PERCENT, OBJ_TYPE_NAME, INTERFACE_CONCATENATED, YEAR, USED, IMPACTED_DUE_TO_DB_CHANGE, IMPACTED_DUE_TO_SIMPLIFICATION, IMPACTED_DUE_TO_EXISTING_ERRORS, IMPACTED_DUE_TO_OS_MIGRATION, EXTERNAL_NAMESPACE, REQUEST_ID, EXEC_DATE, EXEC_TIME) values ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (ImpactedCloneAnalysis impactedClone : impactedCloneList) {
					stmt.setString(1, impactedClone.getAppComponent());
					stmt.setString(2, impactedClone.getCreationDate());
					stmt.setString(3, impactedClone.getInterfaceObj());
					stmt.setString(4, impactedClone.getInterfaceObjType());
					stmt.setString(5, impactedClone.getNamespace());
					stmt.setString(6, impactedClone.getObjName());
					stmt.setString(7, impactedClone.getObjPackage());
					stmt.setString(8, impactedClone.getObjType());
					stmt.setString(9, impactedClone.getReference());
					stmt.setString(10, impactedClone.getReferencePercent());
					stmt.setString(11, impactedClone.getObjTypeName());
					stmt.setString(12, impactedClone.getInterfaceConcat());
					stmt.setString(13, impactedClone.getYear());
					stmt.setString(14, impactedClone.getUsed());
					stmt.setString(15, impactedClone.getImpactedDB());
					stmt.setString(16, impactedClone.getImpactedSimpl());
					stmt.setString(17, impactedClone.getImpactedExistingError());
					stmt.setString(18, impactedClone.getImpactedOSMigration());
					stmt.setString(19, impactedClone.getImpactedOSMigration());
					stmt.setLong(20, impactedClone.getRequestID());
					stmt.setString(21, impactedClone.getExecDate());
					stmt.setString(22, impactedClone.getExecTime());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("IMPACTED_CLONE_ANALYSIS Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	public static String ACNIPZVERCompBatchInsertUpdate(List<ACNIPZVERComp> acnipzverCompList, HttpSession session)
			throws SQLException {

		final String INSERT_SQL = "INSERT INTO ACNIP_ZVER_COMP "
				+ "(REQUEST_ID, MANDT, SESSION_ID, SERIAL_NO, NAMESPACE, OBJECT_R3TR, OBJ_NAME_R3TR, OBJECT, "
				+ "OBJ_NAME, CREATE_DATE, CHANGE_DATE, DEVCLASS, CODE_SIZE, VERSION_COUNT, REF_INFOSAP, REF_TYPE_TEXTSAP, "
				+ "LAST_TRANSPORT, LAST_TRANSPORT_RFC, OBJECT1, OBJ_NAME1, LENGTH1, CNT_VERS1, ICON_COMP, OBJECT2, OBJ_NAME2, "
				+ "LENGTH2, CNT_VERS2, RFCDEST2, RECORD_DATE, RECORD_TIME, RICEF_CATEGORY, RICEF_SUB_CATEGORY) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "
				+ "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (ACNIPZVERComp acnipzverComp : acnipzverCompList) {
					stmt.setLong(1, acnipzverComp.getRequestID());
					stmt.setString(2, acnipzverComp.getMandt());
					stmt.setString(3, acnipzverComp.getSessionId());
					stmt.setString(4, acnipzverComp.getSerialNo());
					stmt.setString(5, acnipzverComp.getNamespace());
					stmt.setString(6, acnipzverComp.getObjectR3TR());
					stmt.setString(7, acnipzverComp.getObjNameR3TR());
					stmt.setString(8, acnipzverComp.getObject());
					stmt.setString(9, acnipzverComp.getObjName());
					stmt.setString(10, acnipzverComp.getCreateDate());
					stmt.setString(11, acnipzverComp.getChangeDate());
					stmt.setString(12, acnipzverComp.getDevClass());
					stmt.setString(13, acnipzverComp.getCodeSize());
					stmt.setString(14, acnipzverComp.getVersionCount());
					stmt.setString(15, acnipzverComp.getRefInfosap());
					stmt.setString(16, acnipzverComp.getRefTypeTextsap());
					stmt.setString(17, acnipzverComp.getLastTransport());
					stmt.setString(18, acnipzverComp.getLastTransportRfc());
					stmt.setString(19, acnipzverComp.getObject1());
					stmt.setString(20, acnipzverComp.getObjName1());
					stmt.setString(21, acnipzverComp.getLength1());
					stmt.setString(22, acnipzverComp.getCntVers1());
					stmt.setString(23, acnipzverComp.getIconComp());
					stmt.setString(24, acnipzverComp.getObject2());
					stmt.setString(25, acnipzverComp.getObjName2());
					stmt.setString(26, acnipzverComp.getLength2());
					stmt.setString(27, acnipzverComp.getCntVers2());
					stmt.setString(28, acnipzverComp.getRfcDest2());
					stmt.setString(29, acnipzverComp.getRecordDate());
					stmt.setString(30, acnipzverComp.getRecordTime());
					stmt.setString(31, acnipzverComp.getRicefCategory());
					stmt.setString(32, acnipzverComp.getRicefSubCategory());
					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("ACNIP_ZVER_COMP Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	public static String BWExtractBatchInsertUpdate(List<BWExtractor> bwExtractorList, HttpSession session)
			throws SQLException {

		final String INSERT_SQL = "INSERT INTO BW_EXTRACTOR " + "(REQUEST_ID, OLTSOURCE, EXTRACTOR) values (?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (BWExtractor bwExtractor : bwExtractorList) {
					stmt.setLong(1, bwExtractor.getRequestID());
					stmt.setString(2, bwExtractor.getOltsource());
					stmt.setString(3, bwExtractor.getExtractor());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("ACNIP_ZVER_COMP Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	public static String s4ImpactedSearchBatchInsertUpdate(List<S4ImpactedSearchHelp> s4ImpactedList,
			HttpSession session) throws SQLException {

		final String INSERT_SQL = "INSERT INTO S4_Impacted_Search "
				+ "(REQUEST_ID, search_data, OBJECT_TYPE, OBJECT_NAME, EXTERNAL_NAMESPACE) values (?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (S4ImpactedSearchHelp s4Impacted : s4ImpactedList) {
					stmt.setLong(1, s4Impacted.getRequestId());
					stmt.setString(2, s4Impacted.getSearchData());
					stmt.setString(3, s4Impacted.getObjectType());
					stmt.setString(4, s4Impacted.getObjectName());
					stmt.setString(5, s4Impacted.getExternalNamespace());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("S4_Impacted_Search Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	public static String AppendStructureBatchInsertUpdate(List<S4AppendStructureAnalysis> s4AppendList,
			HttpSession session) throws SQLException {

		final String INSERT_SQL = "INSERT INTO S4_Append_Structure "
				+ "(FIELD_NAME, NAME_OF_INCLUDE, REQUEST_ID, TABLE_NAME) values (?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (S4AppendStructureAnalysis s4Append : s4AppendList) {
					stmt.setString(1, s4Append.getFieldName());
					stmt.setString(2, s4Append.getNameOfInclude());
					stmt.setLong(3, s4Append.getRequestId());
					stmt.setString(4, s4Append.getTableName());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("S4_Append_Structure Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	public static String s4ImpactedIDOCBatchInsertUpdate(List<S4ImpactedIDOC> s4ImpactedIDOCList, HttpSession session)
			throws SQLException {

		final String INSERT_SQL = "INSERT INTO S4_IMPACTED_IDOC "
				+ "(Identifier, IDOC_MSG_TYPE, IDOC_BASIC_TYPE, IDOC_SEGMENT, REQUEST_ID, TYPE_OF_IDOC) values (?, ?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (S4ImpactedIDOC s4IDOC : s4ImpactedIDOCList) {
					stmt.setString(1, s4IDOC.getIdentifier());
					stmt.setString(2, s4IDOC.getMsgType());
					stmt.setString(3, s4IDOC.getBasicType());
					stmt.setString(4, s4IDOC.getSegment());
					stmt.setLong(5, s4IDOC.getRequestID());
					stmt.setString(6, s4IDOC.getTypeOfIDOC());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("S4_IMPACTED_IDOC Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	public static String s4ImpactedStandardBatchInsertUpdate(List<S4ImpactedTransaction> s4ImpactedTransactionList,
			HttpSession session) throws SQLException {

		final String INSERT_SQL = "INSERT INTO S4_IMPACTED_TRANSACTION "
				+ "(AFFECTED_AREA, DESCRIPTION, IMPACTED_TRANSACTION, REQUEST_ID, SAP_NOTES, SOLUTION_STEPS) values (?, ?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (S4ImpactedTransaction s4ImpactedTransaction : s4ImpactedTransactionList) {
					stmt.setString(1, s4ImpactedTransaction.getAffectedArea());
					stmt.setString(2, s4ImpactedTransaction.getDescription());
					stmt.setString(3, s4ImpactedTransaction.getImpactedTransaction());
					stmt.setLong(4, s4ImpactedTransaction.getRequestID());
					stmt.setString(5, s4ImpactedTransaction.getSapNotes());
					stmt.setString(6, s4ImpactedTransaction.getSolSteps());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("S4_IMPACTED_TRANSACTION Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	public static String s4ImpactedTableBatchInsertUpdate(List<S4ImpactedTables> s4ImpactedTableList,
			HttpSession session) throws SQLException {

		final String INSERT_SQL = "INSERT INTO S4_IMPACTED_TABLES "
				+ "(DESCRIPTION, Object, REQUEST_ID, SAP_NOTES, SOLUTION_STEPS) values (?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (S4ImpactedTables s4ImpactedTable : s4ImpactedTableList) {
					stmt.setString(1, s4ImpactedTable.getDescription());
					stmt.setString(2, s4ImpactedTable.getObject());
					stmt.setLong(3, s4ImpactedTable.getRequestID());
					stmt.setString(4, s4ImpactedTable.getSapNotes());
					stmt.setString(5, s4ImpactedTable.getSolSteps());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("S4_IMPACTED_TABLES Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	protected CustomReportOutput getZaicatDetectionData(final Row row, final long requestId, String fileName) {

		// CustomReportOutput customReportOutput=null;

		int indentifierIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Operation.Code"));
		String identifierCellVal = row.getCell(indentifierIndex) == null ? ""
				: row.getCell(indentifierIndex).getStringCellValue().replaceAll("\\s", StringUtils.EMPTY);

		if (identifierCellVal.startsWith("F")) {
			CustomReportOutput customReportOutput = new CustomReportOutput();
			int selectLineIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Select.Line"));
			String selectLine = row.getCell(selectLineIndex) == null ? ""
					: row.getCell(selectLineIndex).getStringCellValue().trim();

			int operationIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Operation"));
			String operation = row.getCell(operationIndex) == null ? ""
					: row.getCell(operationIndex).getStringCellValue().trim();

			int codeIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Code"));
			String code = row.getCell(codeIndex) == null ? "" : row.getCell(codeIndex).getStringCellValue().trim();

			int infoIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Info"));
			String info = row.getCell(infoIndex) == null ? "" : row.getCell(infoIndex).getStringCellValue().trim();

			int commentsIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Comments"));
			String comments = row.getCell(commentsIndex) == null ? ""
					: row.getCell(commentsIndex).getStringCellValue().trim();

			int commentCIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Comment.C"));
			String commentC = row.getCell(commentCIndex) == null ? ""
					: row.getCell(commentCIndex).getStringCellValue().trim();

			int trIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Tr"));
			String tr = row.getCell(trIndex) == null ? "" : row.getCell(trIndex).getStringCellValue().trim();

			int descIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("DESC"));
			String desc = row.getCell(descIndex) == null ? "" : row.getCell(descIndex).getStringCellValue().trim();

			customReportOutput.setTechnicalCatalogId(selectLine);
			customReportOutput.setTechnicalcatalogtitle(operation);
			customReportOutput.setSemanticObjectAction(code);
			customReportOutput.setLaunchpadApplicationType(info);
			customReportOutput.setLaunchpadApplicationName(comments);
			customReportOutput.setStatusOfTheApplication(commentC);
			customReportOutput.setFlagForCustomApplication(tr);
			// customReportOutput.setComponent(desc);

			String concat = selectLine + code;
			customReportOutput.setConcat(concat);
			customReportOutput.setRequestID(requestId);
			customReportOutput.setFioriId("");
			customReportOutput.setSuccessorApp("");
			customReportOutput.setRelatedApp("");

			return customReportOutput;
		} else {
			return null;
		}

	}

	// protected OdataFioriApps getOdataFioriApps(final Row row, final long
	// requestId, String fileName) {
	// OdataFioriApps odataFioriApps = null;
	// int indentifierIndex = Integer
	// .parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Operation.Code"));
	// String identifierCellVal = row.getCell(indentifierIndex) == null ? ""
	// : row.getCell(indentifierIndex).getStringCellValue().replaceAll("\\s",
	// StringUtils.EMPTY);
	// int typeIndex = Integer
	// .parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("OBJ").trim());
	// String objectType = row.getCell(typeIndex) == null ? "" :
	// row.getCell(typeIndex).getStringCellValue().trim();
	// identifierCellVal = identifierCellVal.toUpperCase();
	// if (identifierCellVal.startsWith("F") &&
	// "IWSV".equalsIgnoreCase(objectType)
	// || "OUI5".equalsIgnoreCase(objectType)) {
	//
	// int readPrgIndex = Integer
	// .parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Read.Prog"));
	// String readProg = row.getCell(readPrgIndex) == null ? "" :
	// row.getCell(readPrgIndex).getStringCellValue().trim();
	// int objNameIndex = Integer.parseInt(
	// Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name").trim());
	// String objName = row.getCell(objNameIndex) == null ? ""
	// : row.getCell(objNameIndex).getStringCellValue().trim();
	//// int actStatusIndex = Integer
	//// .parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Act.Status"));
	//// String actStatusValue = row.getCell(actStatusIndex) == null ? ""
	//// : row.getCell(actStatusIndex).getStringCellValue();
	//// int commentsIndex = Integer
	//// .parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Comments"));
	//// String commentsValue = row.getCell(commentsIndex) == null ? ""
	//// : row.getCell(commentsIndex).getStringCellValue();
	//// int sessionIdIndex = Integer
	//// .parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Session.ID"));
	//// String sessionIDValue = row.getCell(sessionIdIndex) == null ? ""
	//// : row.getCell(sessionIdIndex).getStringCellValue();
	//// int subtypeIndex = Integer
	//// .parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sub.Type"));
	//// String subtypeValue = row.getCell(subtypeIndex) == null ? ""
	//// : row.getCell(subtypeIndex).getStringCellValue();
	// int operCodeIndex = Integer.parseInt(
	// Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Operation.Code"));
	// String operCodeValue = row.getCell(operCodeIndex) == null ? ""
	// : row.getCell(operCodeIndex).getStringCellValue();
	//
	// odataFioriApps = new OdataFioriApps();
	// odataFioriApps.setObject(objectType);
	// odataFioriApps.setObjName(objName);
	// odataFioriApps.setReadProg(readProg);
	// odataFioriApps.setOperationCode(operCodeValue);
	//
	// }
	//
	// return odataFioriApps;
	//
	// }

	public static String usageAnalysisBatchInsertUpdate(List<UsageAnalysis> usageAnalysisList, HttpSession session)
			throws SQLException {

		final String INSERT_SQL = "INSERT INTO Usage_Analysis "
				+ "(objName, objNameType, requestID, type, usageCount, objTypeNameReadProg) values (?, ?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (UsageAnalysis usage : usageAnalysisList) {
					long requestid = usage.getRequestID().longValue();
					stmt.setString(1, usage.getObjName());
					stmt.setString(2, usage.getObjNameType());
					stmt.setLong(3, requestid);
					stmt.setString(4, usage.getType());
					stmt.setString(5, usage.getUsageCount());
					stmt.setString(6, usage.getObjTypeNameReadProg());
					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("Usage_Analysis Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;
	}

	// Impacted Scripts:::::::::::::::::::::::::::: himani.malhotra
	public ImpactedScripts createListforImpactedScripts(final Row row, final Long requestID, String fileName,
			List<String> externalNamespaceList) throws FileNotFoundException, SQLException {

		ImpactedScripts scripts = null;
		int opCodeIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Operation.Code"));
		int objecttypeIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("OBJ").trim());
		int objectnameIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Obj.Name").trim());
		int readProgIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Read.Prog"));
		int actStatusIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Act.Status"));

		String opcodeCellVal = row.getCell(opCodeIndex) == null ? ""
				: row.getCell(opCodeIndex).getStringCellValue().trim();
		String objecttypeCellVal = row.getCell(objecttypeIndex) == null ? ""
				: row.getCell(objecttypeIndex).getStringCellValue().trim();
		String objectnameCellVal = row.getCell(objectnameIndex) == null ? ""
				: row.getCell(objectnameIndex).getStringCellValue().trim();
		String readProgIndexValue = row.getCell(readProgIndex) == null ? ""
				: row.getCell(readProgIndex).getStringCellValue().trim();
		String actStatusIndexValue = row.getCell(actStatusIndex) == null ? ""
				: row.getCell(actStatusIndex).getStringCellValue().trim();

		if (opcodeCellVal.startsWith("SCRIPT") && objecttypeCellVal.equals("PROG")
				&& StringUtils.isNotBlank(objectnameCellVal)) {
			scripts = new ImpactedScripts();
			scripts.setObjType(objecttypeCellVal);
			scripts.setObjName(objectnameCellVal);
			scripts.setObjNameType(objecttypeCellVal + objectnameCellVal);
			scripts.setObjNameTypeStatus(objectnameCellVal + actStatusIndexValue);
			scripts.setReadProg(readProgIndexValue);
			scripts.setActStaus(actStatusIndexValue);
			scripts.setRequestId(requestID);

			// Setting External Namespace
			if (CollectionUtils.isNotEmpty(externalNamespaceList)
					&& !externalNamespaceList.stream().anyMatch("NA"::equalsIgnoreCase)) {
				if (!objectnameCellVal.isEmpty()) {
					for (String externalNamespace : externalNamespaceList) {
						if (StringUtils.containsIgnoreCase(objectnameCellVal.trim(), externalNamespace.trim())) {
							scripts.setExternalNamespace("Y");
							break;
						}
					}
				}
			}
		}

		return scripts;
	}

	// Impacted Scripts Batch Insert
	public static String impactedScriptsBatchInsertUpdate(List<ImpactedScripts> impactedScriptsListIntermediate,
			HttpSession session) throws SQLException {

		final String INSERT_SQL = "INSERT INTO Impacted_Scripts "
				+ "(OBJ_TYPE, OBJ_NAME, OBJ_NAME_TYPE_STATUS, READ_PROG, ACT_STATUS, OPERCD, REQUEST_ID, OBJ_NAME_TYPE, EXTERNAL_NAMESPACE) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {
			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (ImpactedScripts impactedScripts : impactedScriptsListIntermediate) {
					stmt.setString(1, impactedScripts.getObjType());
					stmt.setString(2, impactedScripts.getObjName());
					stmt.setString(3, impactedScripts.getObjNameTypeStatus());
					stmt.setString(4, impactedScripts.getReadProg());
					stmt.setString(5, impactedScripts.getActStaus());
					stmt.setString(6, impactedScripts.getOpCode());
					stmt.setLong(7, impactedScripts.getRequestId());
					stmt.setString(8, impactedScripts.getObjNameType());
					stmt.setString(9, impactedScripts.getExternalNamespace());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}
				stmt.executeBatch();
				conn.commit();
				logger.info("Impacted_Scripts Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	public static String s4CvitAssessmentBatchInsert(List<S4CvitAssessment> s4CvitAssessmentList, HttpSession session)
			throws SQLException {

		final String INSERT_SQL = "INSERT INTO S4_CVIT_ASSESSMENT "
				+ "(OBJ_NAME, CVIT_VALUE, REQUEST_ID) values (?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (S4CvitAssessment s4CvitAssessment : s4CvitAssessmentList) {
					stmt.setString(1, s4CvitAssessment.getObjName());
					stmt.setString(2, s4CvitAssessment.getCvitValue());
					stmt.setLong(3, s4CvitAssessment.getRequestId());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("S4 CVIT Assessment Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	public void fireRules() {
		try {
			DroolsHelper droolsHelper = new DroolsHelper();
			WorkingMemory workingMemory = droolsHelper.getStatefulSession();
			workingMemory.insert(hm);
			workingMemory.fireAllRules();
			workingMemory.dispose();
		} catch (Exception e) {
			logger.error("Error !!! " + e);
		}

	}

	protected void createListforSecurityAnalyserSrcAgr(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException, SQLException {

		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);
		SrcAgr1251 srcAgr1251 = null;

		List<SrcAgr1251> srcAgr1251List = new ArrayList<SrcAgr1251>();

		String fileName = file.getName();
		logger.info("Inside Method createListforSecurityAnalyser Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);

			for (Row row : reader) {
				if (row.getRowNum() > 0) {

					int mandtIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("mandt").get(1));
					int agrNameIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("agr.name").get(1));
					int objectIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("object").get(1));
					int fieldIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("field").get(1));
					int lowIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("low").get(1));
					int highIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("high").get(1));
					int modifiedIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("modified").get(1));
					int deletedIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("deleted").get(1));
					int copiedIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("copied").get(1));

					String mandt = row.getCell(mandtIndex) == null ? ""
							: row.getCell(mandtIndex).getStringCellValue().trim();
					String agrName = row.getCell(agrNameIndex) == null ? ""
							: row.getCell(agrNameIndex).getStringCellValue().trim();
					String object = row.getCell(objectIndex) == null ? ""
							: row.getCell(objectIndex).getStringCellValue().trim();
					String field = row.getCell(fieldIndex) == null ? ""
							: row.getCell(fieldIndex).getStringCellValue().trim();
					String low = row.getCell(lowIndex) == null ? "" : row.getCell(lowIndex).getStringCellValue().trim();
					String high = row.getCell(highIndex) == null ? ""
							: row.getCell(highIndex).getStringCellValue().trim();
					String modified = row.getCell(modifiedIndex) == null ? ""
							: row.getCell(modifiedIndex).getStringCellValue().trim();
					String deleted = row.getCell(deletedIndex) == null ? ""
							: row.getCell(deletedIndex).getStringCellValue().trim();
					String copied = row.getCell(copiedIndex) == null ? ""
							: row.getCell(copiedIndex).getStringCellValue().trim();

					srcAgr1251 = new SrcAgr1251();
					srcAgr1251.setMandt(mandt);
					srcAgr1251.setAgrName(agrName);
					srcAgr1251.setObject(object);
					srcAgr1251.setField(field);
					srcAgr1251.setLow(low);
					srcAgr1251.setHigh(high);
					srcAgr1251.setModified(modified);
					srcAgr1251.setDeleted(deleted);
					srcAgr1251.setCopied(copied);
					srcAgr1251.setRequestID((int) requestId);
					srcAgr1251List.add(srcAgr1251);
				}
			}
			getSecAnalyseDao().securityAnalyserSrcAgrBatchInsertUpdate(srcAgr1251List, session);

		} finally {
			IOUtils.closeQuietly(inputStream);
		}
	}

	protected void createListforSourceUSOBTC(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException, SQLException {
		logger.debug("createListforSourceUSOBTC() - Start");
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);
		SrcUsobtc srcUsobtc = null;

		List<SrcUsobtc> srcUsobtcList = new ArrayList<SrcUsobtc>();

		String fileName = file.getName();
		logger.info("Inside Method createListforSourceUSOBTC Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);

			for (Row row : reader) {
				if (row.getRowNum() > 0) {

					int nameIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("name").get(1));
					int objectIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("object").get(1));
					int fieldIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("field").get(1));
					int lowIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("low").get(1));
					int highIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("high").get(1));

					String name = row.getCell(nameIndex) == null ? ""
							: row.getCell(nameIndex).getStringCellValue().trim();
					String object = row.getCell(objectIndex) == null ? ""
							: row.getCell(objectIndex).getStringCellValue().trim();
					String field = row.getCell(fieldIndex) == null ? ""
							: row.getCell(fieldIndex).getStringCellValue().trim();
					String low = row.getCell(lowIndex) == null ? "" : row.getCell(lowIndex).getStringCellValue().trim();
					String high = row.getCell(highIndex) == null ? ""
							: row.getCell(highIndex).getStringCellValue().trim();

					srcUsobtc = new SrcUsobtc();
					srcUsobtc.setName(name);
					srcUsobtc.setObject(object);
					srcUsobtc.setField(field);
					srcUsobtc.setLow(low);
					srcUsobtc.setHigh(high);
					srcUsobtc.setRequestID((int) requestId);
					srcUsobtcList.add(srcUsobtc);
				}
			}
			getSecAnalyseDao().securityAnalyserSourceUSOBTCBatchInsertUpdate(srcUsobtcList, session);
			logger.debug("createListforSourceUSOBTC() - End");
		} catch (Exception e) {
			logger.error("createListforSourceUSOBTC :: ", e);
		} finally {
			IOUtils.closeQuietly(inputStream);

		}
	}

	protected void createListforAgrUsers(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException, SQLException {
		logger.debug("createListforAgrUsers() - Start");
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);
		SrcAgrUsers srcAgrUsers = null;

		List<SrcAgrUsers> srcAgrUsersList = new ArrayList<SrcAgrUsers>();

		String fileName = file.getName();
		logger.info("Inside Method createListforAgrUsers Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int roleIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("role").get(1));
					int unameIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("user.name").get(1));

					String role = row.getCell(roleIndex) == null ? ""
							: row.getCell(roleIndex).getStringCellValue().trim();
					String uname = row.getCell(unameIndex) == null ? ""
							: row.getCell(unameIndex).getStringCellValue().trim();

					srcAgrUsers = new SrcAgrUsers();
					srcAgrUsers.setRole(role);
					srcAgrUsers.setUserName(uname);
					srcAgrUsers.setRequestID((int) requestId);
					srcAgrUsersList.add(srcAgrUsers);
				}
			}
			getSecAnalyseDao().securityAnalyserAgrUsersBatchInsertUpdate(srcAgrUsersList, session);
			logger.debug("createListforAgrUsers() - End");
		} catch (Exception e) {
			logger.error("createListforAgrUsers :: ", e);
			throw e;
		} finally {
			IOUtils.closeQuietly(inputStream);

		}
	}

	protected void createListforGrtGracfuncactDetails(String filePath, long requestId, HttpSession session)
			throws Exception {
		logger.debug("createListforGrtGracfuncactDetails() - Start");
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);
		GrtGracfuncact grc = null;

		List<GrtGracfuncact> grcList = new ArrayList<GrtGracfuncact>();

		String fileName = file.getName();
		logger.info("Inside Method createListforGrtGracfuncactDetails Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int mandtIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("mandt").get(1));
					int funcIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("func").get(1));
					int actionIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("action").get(1));
					int connectorIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("connector").get(1));
					int activeIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("active").get(1));
					// if
					// (hm.getWebTemplate7List().contains(row.getCell(tctobjnmIndex).getStringCellValue().trim()))
					// {
					String mandt = row.getCell(mandtIndex) == null ? ""
							: row.getCell(mandtIndex).getStringCellValue().trim();
					String func = row.getCell(funcIndex) == null ? ""
							: row.getCell(funcIndex).getStringCellValue().trim();
					String action = row.getCell(actionIndex) == null ? ""
							: row.getCell(actionIndex).getStringCellValue().trim();
					String connector = row.getCell(connectorIndex) == null ? ""
							: row.getCell(connectorIndex).getStringCellValue().trim();
					String active = row.getCell(activeIndex) == null ? ""
							: row.getCell(activeIndex).getStringCellValue().trim();

					grc = new GrtGracfuncact();
					grc.setMandt(mandt);
					grc.setFunc(func);
					grc.setAction(action);
					grc.setConnector(connector);
					grc.setActive(active);
					grc.setRequestId(requestId);
					grcList.add(grc);
				}
			}
			// }

			getSecAnalyseDao().securityAnalyserGrcDetailsBatchInsertUpdate(grcList, session);
			logger.debug("createListforGrtGracfuncactDetails() - End");
		} catch (Exception e) {
			logger.error("createListforGrtGracfuncactDetails :: ", e);
			throw e;
		} finally {
			IOUtils.closeQuietly(inputStream);

		}
	}

	protected void createListforRsantProcessr(String filePath, long requestId, HttpSession session) throws Exception {
		logger.debug("createListforRsantProcessr() - Start");
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);
		RsantProcessr rsantProcessr = null;

		List<RsantProcessr> rsantProcessrList = new ArrayList<RsantProcessr>();

		String fileName = file.getName();
		logger.info("Inside Method createListforRsantProcessr Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int processIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("process").get(1));
					int strtTimeIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("start.time").get(1));

					String process = row.getCell(processIndex) == null ? ""
							: row.getCell(processIndex).getStringCellValue().trim();
					Date strtTime = row.getCell(strtTimeIndex).getDateCellValue();
					DataFormatter dataFormatter = new DataFormatter();
					String cellStringValue = dataFormatter.formatCellValue(row.getCell(strtTimeIndex));

					Date dt = null;
					java.sql.Timestamp sqlTime = null;
					if (cellStringValue.contains(":") || cellStringValue.contains("-")) {
						dt = row.getCell(strtTimeIndex).getDateCellValue();
						sqlTime = new java.sql.Timestamp(dt.getTime());
					} else {
						SimpleDateFormat formatter = new SimpleDateFormat(hm.getDateFormatList().get("rsantProcessr")); // your
																														// template
																														// here
						dt = formatter.parse(cellStringValue);
						sqlTime = new java.sql.Timestamp(dt.getTime());
					}

					rsantProcessr = new RsantProcessr();
					rsantProcessr.setProcess(process);
					;
					rsantProcessr.setStartTime(sqlTime);
					rsantProcessr.setRequestId(requestId);
					rsantProcessr.setObjectType("APD");
					rsantProcessrList.add(rsantProcessr);
				}
			}
			bwCleanDao.batchInsertionForRsantProcessr(rsantProcessrList, session);
			logger.debug("createListforRsantProcessr() - End");
		} catch (Exception e) {
			logger.error("createListforRsantProcessr :: ", e);
			throw e;
		} finally {
			IOUtils.closeQuietly(inputStream);

		}
	}

	protected void createListforRsbkdtp(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException, SQLException {
		logger.debug("createListforRsbkdtp() - Start");
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);
		Rsbkdtp rsbkdtp = null;

		List<Rsbkdtp> rsbkdtpList = new ArrayList<Rsbkdtp>();

		String fileName = file.getName();
		logger.info("Inside Method createListforRsbkdtp Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int objversIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objvers").get(1));
					int dtpIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("dtp").get(1));

					if ("A".equalsIgnoreCase(row.getCell(objversIndex).getStringCellValue().trim())) {
						String dtp = row.getCell(dtpIndex) == null ? ""
								: row.getCell(dtpIndex).getStringCellValue().trim();

						rsbkdtp = new Rsbkdtp();
						rsbkdtp.setDtp(dtp);
						rsbkdtp.setRequestId(requestId);
						rsbkdtp.setObjectType("DTPs");
						rsbkdtpList.add(rsbkdtp);
					}
				}
			}
			bwCleanDao.batchInsertionForRsbkdtp(rsbkdtpList, session);
			logger.debug("createListforRsbkdtp() - End");
		} catch (Exception e) {
			logger.error("createListforRsbkdtp :: ", e);
			throw e;
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
	}

	protected void createListforRsbkdtpstat(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException, SQLException {
		logger.debug("createListforRsbkdtpstat() - Start");
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);
		Rsbkdtpstat rsbkdtpstat = null;

		List<Rsbkdtpstat> rsbkdtpstatList = new ArrayList<Rsbkdtpstat>();

		String fileName = file.getName();
		logger.info("Inside Method createListforRsbkdtpstat Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int dtpIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("dtp").get(1));
					int objStatIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("obj.stat").get(1));

					String dtp = row.getCell(dtpIndex) == null ? "" : row.getCell(dtpIndex).getStringCellValue().trim();
					String objStat = row.getCell(objStatIndex) == null ? ""
							: row.getCell(objStatIndex).getStringCellValue().trim();

					rsbkdtpstat = new Rsbkdtpstat();
					rsbkdtpstat.setDtp(dtp);
					rsbkdtpstat.setObjStat(objStat);
					rsbkdtpstat.setRequestId(requestId);
					rsbkdtpstat.setObjectType("DTPs");
					rsbkdtpstatList.add(rsbkdtpstat);
				}
			}
			bwCleanDao.batchInsertionForRsbkdtpstat(rsbkdtpstatList, session);
			logger.debug("createListforRsbkdtpstat() - End");
		} catch (Exception e) {
			logger.error("createListforRsbkdtpstat :: ", e);
			throw e;
		} finally {
			IOUtils.closeQuietly(inputStream);

		}
	}

	protected void createListForRsbkrequest(String filePath, long requestId, HttpSession session) throws Exception {
		logger.debug("createListforRsbkrequest() - Start");
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);
		Rsbkrequest rsbkrequest = null;

		List<Rsbkrequest> rsbkrequestList = new ArrayList<Rsbkrequest>();

		String fileName = file.getName();
		logger.info("Inside Method createListforRsbkrequest Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int tgttpIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("tgttp").get(1));
					int tgtIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("tgt").get(1));
					int tstampStrtIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("tstamp.start").get(1));
					int dtpIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("dtp").get(1));
					int srcIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("src").get(1));

					String tgttp = row.getCell(tgttpIndex) == null ? ""
							: row.getCell(tgttpIndex).getStringCellValue().trim();
					String tgt = row.getCell(tgtIndex) == null ? "" : row.getCell(tgtIndex).getStringCellValue().trim();
					String dtp = row.getCell(dtpIndex) == null ? "" : row.getCell(dtpIndex).getStringCellValue().trim();
					String src = row.getCell(srcIndex) == null ? "" : row.getCell(srcIndex).getStringCellValue().trim();

					Date tstampStrt = row.getCell(tstampStrtIndex).getDateCellValue();
					DataFormatter dataFormatter = new DataFormatter();
					String cellStringValue = dataFormatter.formatCellValue(row.getCell(tstampStrtIndex));

					Date dt = null;
					java.sql.Timestamp sqlTime = null;
					if (cellStringValue.contains(":") || cellStringValue.contains("-")) {
						dt = row.getCell(tstampStrtIndex).getDateCellValue();
						sqlTime = new java.sql.Timestamp(dt.getTime());
					} else {
						SimpleDateFormat formatter = new SimpleDateFormat(hm.getDateFormatList().get("rsbkrequest"));

						dt = formatter.parse(cellStringValue);
						sqlTime = new java.sql.Timestamp(dt.getTime());
					}

					rsbkrequest = new Rsbkrequest();
					rsbkrequest.setTgttp(tgttp);
					rsbkrequest.setTgt(tgt);
					rsbkrequest.setTstmpStart(sqlTime);
					rsbkrequest.setRequestId(requestId);
					rsbkrequest.setDtp(dtp);
					rsbkrequest.setSrc(src);
					rsbkrequestList.add(rsbkrequest);
				}
			}

			bwCleanDao.batchInsertionForRsbkrequest(rsbkrequestList, session);
			logger.debug("createListforRsbkrequest() - End");
		} catch (Exception e) {
			logger.error("createListforRsbkrequest :: ", e);
			throw e;
		} finally {
			IOUtils.closeQuietly(inputStream);

		}
	}

	protected void createListforRsiccont(String filePath, long requestId, HttpSession session) throws Exception {
		logger.debug("createListforRsiccont() - Start");
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);
		Rsiccont rsiccont = null;

		List<Rsiccont> rsiccontList = new ArrayList<Rsiccont>();

		String fileName = file.getName();
		logger.info("Inside Method createListforRsiccont Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int icubeIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("icube").get(1));
					String icube = row.getCell(icubeIndex) == null ? ""
							: row.getCell(icubeIndex).getStringCellValue().trim();

					if (hm.getDsoList().contains(icube) || hm.getInfocubeList().contains(icube)) {
						int timeStmpIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
								.get(fileName).get("time.stamp").get(1));

						DataFormatter dataFormatter = new DataFormatter();
						String cellStringValue = dataFormatter.formatCellValue(row.getCell(timeStmpIndex));
						if (cellStringValue.contains(",")) {
							cellStringValue = cellStringValue.replace(",", "");
							logger.info("date string after comma removed :: " + cellStringValue);
						}

						Date dt = null;
						java.sql.Timestamp sqlTime = null;
						if (cellStringValue.contains(":") || cellStringValue.contains("-")) {
							dt = row.getCell(timeStmpIndex).getDateCellValue();
							sqlTime = new java.sql.Timestamp(dt.getTime());
						} else {
							SimpleDateFormat formatter = new SimpleDateFormat(hm.getDateFormatList().get("rsiccont")); // your
							dt = formatter.parse(cellStringValue);
							sqlTime = new java.sql.Timestamp(dt.getTime());
						}

						rsiccont = new Rsiccont();
						rsiccont.setIcube(icube);
						rsiccont.setTimeStamp(sqlTime);
						rsiccont.setRequestId(requestId);
						if (hm.getDsoList().contains(icube)) {
							rsiccont.setObjectType("DSO");
						}

						else if (hm.getInfocubeList().contains(icube)) {
							rsiccont.setObjectType("InfoCube");
						}

						rsiccontList.add(rsiccont);
					}
				}
			}
			bwCleanDao.batchInsertionForRsiccont(rsiccontList, session);
			logger.debug("createListforRsiccont() - End");
		} catch (Exception e) {
			logger.error("createListforRsiccont :: ", e);
			throw e;
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
	}

	protected void createListforRspcprocesslog(String filePath, long requestId, HttpSession session) throws Exception {
		logger.debug("createListforRspcprocesslog() - Start");
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);
		Rspcprocesslog rspcprocesslog = null;

		List<Rspcprocesslog> rspcprocesslogList = new ArrayList<Rspcprocesslog>();

		String fileName = file.getName();
		logger.info("Inside Method createListforRspcprocesslog Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int typeIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("type").get(1));
					String type = row.getCell(typeIndex) == null ? ""
							: row.getCell(typeIndex).getStringCellValue().trim();
					if (type.equalsIgnoreCase("TRIGGER")) {
						int varianteIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
								.get(fileName).get("variante").get(1));
						int strtTmpStmpIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
								.get(fileName).get("startTime.stamp").get(1));

						String variante = row.getCell(varianteIndex) == null ? ""
								: row.getCell(varianteIndex).getStringCellValue().trim();
						Date strtTmpStmp = row.getCell(strtTmpStmpIndex).getDateCellValue();
						DataFormatter dataFormatter = new DataFormatter();
						String cellStringValue = dataFormatter.formatCellValue(row.getCell(strtTmpStmpIndex));

						Date dt = null;
						java.sql.Timestamp sqlTime = null;
						if (cellStringValue.contains(":") || cellStringValue.contains("-")) {
							dt = row.getCell(strtTmpStmpIndex).getDateCellValue();
							sqlTime = new java.sql.Timestamp(dt.getTime());
						} else {
							SimpleDateFormat formatter = new SimpleDateFormat(
									hm.getDateFormatList().get("rspcprocesslog")); // your
																					// template
																					// here
							dt = formatter.parse(cellStringValue);
							sqlTime = new java.sql.Timestamp(dt.getTime());
						}

						rspcprocesslog = new Rspcprocesslog();
						rspcprocesslog.setType(type);
						rspcprocesslog.setVariante(variante);
						rspcprocesslog.setStrtTimeStamp(sqlTime);
						rspcprocesslog.setRequestId(requestId);
						rspcprocesslog.setObjectType("Process Chain");
						rspcprocesslogList.add(rspcprocesslog);
					}
				}
			}
			bwCleanDao.batchInsertionForRspcprocesslog(rspcprocesslogList, session);
			logger.debug("createListforRspcprocesslog() - End");
		} catch (Exception e) {
			logger.error("createListforRspcprocesslog :: ", e);
			throw e;
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
	}

	protected void createListforRsrrepdir(String filePath, long requestId, HttpSession session) throws Exception {
		logger.debug("createListforRsrrepdir() - Start");
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);
		Rsrrepdir rsrrepdir = null;

		List<Rsrrepdir> rsrrepdirList = new ArrayList<Rsrrepdir>();
		List<Rsrrepdir> rsrrepdirInaObjList = new ArrayList<Rsrrepdir>();

		String fileName = file.getName();
		logger.info("Inside Method createListforRsrrepdir Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int objversIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objvers").get(1));
					int repTimeIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("reptime").get(1));
					int compIdIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("compid").get(1));
					int genIdIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("genuineid").get(1));
					int objstatIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objstat").get(1));
					String compId = "";
					String genuineId = "";
					java.sql.Timestamp sqlTime = null;
					rsrrepdir = new Rsrrepdir();
					if ("A".equalsIgnoreCase(row.getCell(objversIndex).getStringCellValue().trim())
							&& "INA".equalsIgnoreCase(row.getCell(objstatIndex).getStringCellValue().trim())) {
						compId = row.getCell(compIdIndex) == null ? ""
								: row.getCell(compIdIndex).getStringCellValue().trim();
						genuineId = row.getCell(genIdIndex) == null ? ""
								: row.getCell(genIdIndex).getStringCellValue().trim();
						rsrrepdir.setObjStatus("INACTIVE");
						rsrrepdir.setCompId(compId);
						rsrrepdir.setObjectType("BEX");
						rsrrepdir.setGenuineId(genuineId);
						rsrrepdir.setRequestId(requestId);
						rsrrepdirInaObjList.add(rsrrepdir);
					}
					if ("A".equalsIgnoreCase(row.getCell(objversIndex).getStringCellValue().trim())
							&& !"INA".equalsIgnoreCase(row.getCell(objstatIndex).getStringCellValue().trim())) {
						compId = row.getCell(compIdIndex) == null ? ""
								: row.getCell(compIdIndex).getStringCellValue().trim();
						genuineId = row.getCell(genIdIndex) == null ? ""
								: row.getCell(genIdIndex).getStringCellValue().trim();
						DataFormatter dataFormatter = new DataFormatter();
						String cellStringValue = dataFormatter.formatCellValue(row.getCell(repTimeIndex));

						// java.util.Date dateStr =
						// formatter.parse(cellStringValue);
						// java.sql.Date dateDB = new
						// java.sql.Date(dateStr.getTime());
						// sqlTime=new java.sql.Timestamp(dateStr.getTime());
						rsrrepdir.setObjStatus("ACTIVE");
						Date dt = null;
						if (cellStringValue.contains(":") || cellStringValue.contains("-")) {
							dt = row.getCell(repTimeIndex).getDateCellValue();
							sqlTime = new java.sql.Timestamp(dt.getTime());
						} else {
							if (cellStringValue.contains(",")) {
								cellStringValue = cellStringValue.replace(",", "");
								logger.info("RSRREPSIR value :: " + cellStringValue);
							}
							SimpleDateFormat formatter = new SimpleDateFormat(hm.getDateFormatList().get("rsrrepdir")); // your
																														// template
																														// here
							dt = formatter.parse(cellStringValue);
							sqlTime = new java.sql.Timestamp(dt.getTime());
						}
						rsrrepdir.setCompId(compId);
						rsrrepdir.setRepTime(sqlTime);
						rsrrepdir.setRequestId(requestId);
						rsrrepdir.setObjectType("BEX");
						rsrrepdir.setGenuineId(genuineId);
						rsrrepdirList.add(rsrrepdir);
					}
				}
			}
			if (null != rsrrepdirInaObjList) {
				hm.setRsrrepdirINAList(rsrrepdirInaObjList);
			}
			bwCleanDao.batchInsertionForRsrrepdir(rsrrepdirList, session);
			logger.debug("createListforRsrrepdir() - End");
		} catch (Exception e) {
			logger.error("createListforRsrrepdir :: ", e);
			throw e;
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
	}

	protected void createListforRstran(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException, SQLException {
		logger.debug("createListforRstran() - Start");
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);
		Rstran rstran = null;

		List<Rstran> rstranList = new ArrayList<Rstran>();

		String fileName = file.getName();
		logger.info("Inside Method createListforRstran Filename is" + fileName);
		try {
			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 0) {

					int transIdIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("transid").get(1));
					int objverIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objvers").get(1));
					int objstatIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objstat").get(1));
					int srcIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("sourcename").get(1));
					int targetIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("targetname").get(1));

					if ("A".equalsIgnoreCase(row.getCell(objverIndex).getStringCellValue().trim())) {
						String transId = row.getCell(transIdIndex) == null ? ""
								: row.getCell(transIdIndex).getStringCellValue().trim();
						String objStat = row.getCell(objstatIndex) == null ? ""
								: row.getCell(objstatIndex).getStringCellValue().trim();
						String source = row.getCell(srcIndex) == null ? ""
								: row.getCell(srcIndex).getStringCellValue().trim();
						String target = row.getCell(targetIndex) == null ? ""
								: row.getCell(targetIndex).getStringCellValue().trim();

						rstran = new Rstran();
						rstran.setTransId(transId);
						rstran.setObjStat(objStat);
						rstran.setSource(source);
						rstran.setTarget(target);
						rstran.setRequestId(requestId);
						rstran.setObjectType("Transformation");
						rstranList.add(rstran);
					}
				}
			}

			bwCleanDao.batchInsertionForRstran(rstranList, session);
			logger.debug("createListforRstran() - End");
		} catch (Exception e) {
			logger.error("createListforRstran :: ", e);
			throw e;
		} finally {
			IOUtils.closeQuietly(inputStream);

		}
	}

	protected List<String> createListforRszwbtmpdata(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException, SQLException {
		logger.debug("createListforRszwbtmpdata() - Start");
		logger.info("createListforRszwbtmpdata() file path before :: ", filePath);
		filePath = filePath.replace("BIOAPERS_SOD00.XLSX", "RSZWBTMPDATA.XLSX");
		logger.info("createListforRszwbtmpdata() file path after :: ", filePath);
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);

		List<String> objIdList = new ArrayList<String>();

		String fileName = file.getName();
		logger.info("Inside Method createListforRszwbtmpdata Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int objidIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get("RSZWBTMPDATA.XLSX").get("objid").get(1));
					int objversIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get("RSZWBTMPDATA.XLSX").get("objvers").get(1));

					String objvers = row.getCell(objversIndex) == null ? ""
							: row.getCell(objversIndex).getStringCellValue().trim();

					String objId = row.getCell(objidIndex) == null ? ""
							: row.getCell(objidIndex).getStringCellValue().trim();
					if ("A".equalsIgnoreCase(objvers)) {
						objIdList.add(objId);
					}
				}
			}
			if (null != objIdList) {
				hm.setWebTemplate7List(objIdList);
			}
			logger.debug("createListforRszwbtmpdata() - End");
		} catch (Exception e) {
			logger.error("createListforRszwbtmpdata :: ", e);
			throw e;
		} finally {
			IOUtils.closeQuietly(inputStream);

		}
		return objIdList;
	}

	protected List<String> createListforRszwTemplate(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException, SQLException {
		logger.debug("createListforRszwTemplate() - Start");
		logger.info("createListforRszwTemplate() file path before :: " + filePath);
		// filePath = filePath.replace("BIOAPERS_SOD00.XLSX",
		// "RSZWTEMPLATE.XLSX");
		logger.info("createListforRszwTemplate() file path after :: " + filePath);
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);

		List<String> tmplIdList = new ArrayList<String>();
		List<Rszwtemplate> tmplIdINAList = new ArrayList<Rszwtemplate>();
		Rszwtemplate rszwtemplate = null;
		String fileName = file.getName();
		logger.info("Inside Method createListforRszwTemplate Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int tmplIdIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("tmplid").get(1));

					int objversIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objvers").get(1));
					int objstatIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objstat").get(1));

					String tmplId = row.getCell(tmplIdIndex) == null ? ""
							: row.getCell(tmplIdIndex).getStringCellValue().trim();
					String objvers = row.getCell(objversIndex) == null ? ""
							: row.getCell(objversIndex).getStringCellValue().trim();
					String objStat = row.getCell(objstatIndex) == null ? ""
							: row.getCell(objstatIndex).getStringCellValue().trim();

					if ("A".equalsIgnoreCase(objvers) && !"INA".equalsIgnoreCase(objStat)) {
						tmplIdList.add(tmplId);
						logger.info("Template Id 1::: " + tmplId);
					}
					if ("A".equalsIgnoreCase(objvers) && "INA".equalsIgnoreCase(objStat)) {
						rszwtemplate = new Rszwtemplate();
						rszwtemplate.setTmplId(tmplId);
						rszwtemplate.setObjType("Web Template 3.x");
						rszwtemplate.setObjStatus("INACTIVE");
						rszwtemplate.setRequestId(requestId);
						tmplIdINAList.add(rszwtemplate);
						logger.info("Template Id 2::: " + tmplId);
					}
				}
			}
			if (null != tmplIdList) {
				hm.setWebTemplate3List(tmplIdList);
			}
			if (null != tmplIdINAList) {
				hm.setWebTemplate3INAList(tmplIdINAList);
			}
			logger.debug("createListforRszwTemplate() - End");
		} catch (Exception e) {
			logger.error("createListforRszwTemplate :: ", e);
			throw e;
		} finally {
			IOUtils.closeQuietly(inputStream);

		}
		return tmplIdList;
	}

	protected List<String> createListforDsoMaster(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException, SQLException {
		logger.debug("createListforDsoMaster() - Start");
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);

		List<String> dsoList = new ArrayList<String>();

		String fileName = file.getName();
		logger.info("Inside Method createListforDsoMaster Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int dsoIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("osdobject").get(1));

					String dso = row.getCell(dsoIndex) == null ? "" : row.getCell(dsoIndex).getStringCellValue().trim();

					dsoList.add(dso);
				}
			}
			if (null != dsoList) {
				hm.setDsoList(dsoList);
			}
			logger.debug("createListforDsoMaster() - End");
		} catch (Exception e) {
			logger.error("createListforDsoMaster :: ", e);
			throw e;
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
		return dsoList;
	}

	protected List<String> createListforInfoCubeMaster(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException, SQLException {
		logger.debug("createListforDsoInfoCubeMaster() - Start");
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);

		List<String> infoCubeList = new ArrayList<String>();
		List<Rsdcube> rsdinfoCubeList = new ArrayList<Rsdcube>();
		List<Rsdcube> mproList = new ArrayList<Rsdcube>();
		Rsdcube rsdcube = null;
		String fileName = file.getName();
		logger.info("Inside Method createListforDsoInfoCubeMaster Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int infoCubeIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("infocube").get(1));
					int objversIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objvers").get(1));
					int objStatIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objstat").get(1));
					int cubeTypeIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("cubetype").get(1));

					String infoCube = row.getCell(infoCubeIndex) == null ? ""
							: row.getCell(infoCubeIndex).getStringCellValue().trim();

					infoCubeList.add(infoCube);
					boolean cubetype = "A".equalsIgnoreCase(row.getCell(cubeTypeIndex).getStringCellValue().trim())
							|| "B".equalsIgnoreCase(row.getCell(cubeTypeIndex).getStringCellValue().trim())
							|| "R".equalsIgnoreCase(row.getCell(cubeTypeIndex).getStringCellValue().trim())
							|| "V".equalsIgnoreCase(row.getCell(cubeTypeIndex).getStringCellValue().trim());
					if ("A".equalsIgnoreCase(row.getCell(objversIndex).getStringCellValue().trim())
							&& "INA".equalsIgnoreCase(row.getCell(objStatIndex).getStringCellValue().trim())
							&& cubetype) {

						String infoCubeCon = row.getCell(infoCubeIndex) == null ? ""
								: row.getCell(infoCubeIndex).getStringCellValue().trim();
						rsdcube = new Rsdcube();
						rsdcube.setInfoCube(infoCubeCon);
						rsdcube.setObjStatus("INACTIVE");
						rsdcube.setObjType("InfoCube");
						rsdcube.setRequestId(requestId);
						rsdinfoCubeList.add(rsdcube);
					}
					if ("A".equalsIgnoreCase(row.getCell(objversIndex).getStringCellValue().trim())
							&& "INA".equalsIgnoreCase(row.getCell(objStatIndex).getStringCellValue().trim())
							&& "M".equalsIgnoreCase(row.getCell(cubeTypeIndex).getStringCellValue().trim())) {
						String infoCubeMpro = row.getCell(infoCubeIndex) == null ? ""
								: row.getCell(infoCubeIndex).getStringCellValue().trim();
						rsdcube = new Rsdcube();
						rsdcube.setMpro(infoCubeMpro);
						rsdcube.setObjStatus("INACTIVE");
						rsdcube.setObjType("MultiProvider");
						rsdcube.setRequestId(requestId);
						mproList.add(rsdcube);
					}
				}
			}
			if (null != infoCubeList) {
				hm.setInfocubeList(infoCubeList);
			}
			if (null != rsdinfoCubeList) {
				hm.setRsdcubeInfocubeList(rsdinfoCubeList);
			}
			if (null != mproList) {
				hm.setRsdcubeMproList(mproList);
			}
			logger.debug("createListforDsoInfoCubeMaster() - End");
		} catch (Exception e) {
			logger.error("createListforDsoInfoCubeMaster :: ", e);
			throw e;
		} finally {
			IOUtils.closeQuietly(inputStream);

		}
		return infoCubeList;
	}

	protected void createListforWebtemplate3(String filePath, long requestId, HttpSession session) throws Exception {
		logger.debug("createListforWebtemplate3() - Start");
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);
		WebTemplate3 webTemp3 = null;

		List<WebTemplate3> webTemp3List = new ArrayList<WebTemplate3>();

		String fileName = file.getName();
		logger.info("Inside Method createListforWebtemplate3 Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int tctobjnmIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("tctobjnm").get(1));
					String tctobjnm = row.getCell(tctobjnmIndex) == null ? ""
							: row.getCell(tctobjnmIndex).getStringCellValue().trim();

					if (hm.getWebTemplate3List().contains(tctobjnm)) {
						int tcttmpstmpIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
								.get(fileName).get("tcttimstmp").get(1));

						String tcttmpstmp = row.getCell(tcttmpstmpIndex) == null ? ""
								: row.getCell(tcttmpstmpIndex).getStringCellValue().trim();

						Date dt = null;
						java.sql.Timestamp sqlTime = null;
						if (tcttmpstmp.contains(":") || tcttmpstmp.contains("-")) {
							dt = row.getCell(tcttmpstmpIndex).getDateCellValue();
							sqlTime = new java.sql.Timestamp(dt.getTime());
						} else {
							SimpleDateFormat formatter = new SimpleDateFormat(
									hm.getDateFormatList().get("bioapersSod00")); //
							dt = formatter.parse(tcttmpstmp);
							sqlTime = new java.sql.Timestamp(dt.getTime());
						}

						webTemp3 = new WebTemplate3();
						webTemp3.setTctObjNm(tctobjnm);
						webTemp3.setTctTimStmp(sqlTime);
						webTemp3.setRequestID(requestId);
						webTemp3.setObjectType("Web Template 3.x");
						webTemp3List.add(webTemp3);
					}
				}
			}

			bwCleanDao.batchInsertionForWebTemplate3(webTemp3List, session);
			logger.debug("createListforWebtemplate3() - End");
		} catch (Exception e) {
			logger.error("createListforWebtemplate3 :: ", e);
			throw e;
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
	}

	protected void createListforWebtemplate7(String filePath, long requestId, HttpSession session) throws Exception {
		logger.debug("createListforWebtemplate7() - Start");
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);
		WebTemplate7 webTemp7 = null;

		List<WebTemplate7> webTemp7List = new ArrayList<WebTemplate7>();

		String fileName = file.getName();
		logger.info("Inside Method createListforWebtemplate7 Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int tctobjnmIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("tctobjnm").get(1));
					String tctobjnm = row.getCell(tctobjnmIndex) == null ? ""
							: row.getCell(tctobjnmIndex).getStringCellValue().trim();

					if (hm.getWebTemplate7List().contains(tctobjnm)) {
						int tcttmpstmpIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
								.get(fileName).get("tcttimstmp").get(1));
						String tcttmpstmp = row.getCell(tcttmpstmpIndex) == null ? ""
								: row.getCell(tcttmpstmpIndex).getStringCellValue().trim();

						Date dt = null;
						java.sql.Timestamp sqlTime = null;
						if (tcttmpstmp.contains(":") || tcttmpstmp.contains("-")) {
							dt = row.getCell(tcttmpstmpIndex).getDateCellValue();
							sqlTime = new java.sql.Timestamp(dt.getTime());
						} else {
							SimpleDateFormat formatter = new SimpleDateFormat(
									hm.getDateFormatList().get("bioapersSod00")); //
							dt = formatter.parse(tcttmpstmp);
							sqlTime = new java.sql.Timestamp(dt.getTime());
						}

						webTemp7 = new WebTemplate7();
						webTemp7.setTctObjNm(tctobjnm);
						webTemp7.setTctTimStmp(sqlTime);
						webTemp7.setRequestId(requestId);
						webTemp7.setObjectType("Web Template 7.x");
						webTemp7List.add(webTemp7);
					}
				}
			}

			bwCleanDao.batchInsertionForWebTemplate7(webTemp7List, session);
			logger.debug("createListforWebtemplate7() - End");
		} catch (Exception e) {
			logger.error("createListforWebtemplate7 :: ", e);
			throw e;
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
	}

	protected void createListforRspchain(String filePath, long requestId, HttpSession session) throws Exception {
		logger.debug("createListforRspchain() - Start");
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);
		Rspcchain rspchain = null;

		List<Rspcchain> rspchainList = new ArrayList<Rspcchain>();

		String fileName = file.getName();
		logger.info("Inside Method createListforRspchain Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int varianteIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("variante").get(1));
					int chainIdIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("chainid").get(1));
					// if
					// (hm.getWebTemplate7List().contains(row.getCell(tctobjnmIndex).getStringCellValue().trim()))
					// {
					String variante = row.getCell(varianteIndex) == null ? ""
							: row.getCell(varianteIndex).getStringCellValue().trim();
					String chainId = row.getCell(chainIdIndex) == null ? ""
							: row.getCell(chainIdIndex).getStringCellValue().trim();

					rspchain = new Rspcchain();
					rspchain.setChainId(chainId);
					rspchain.setVariante(variante);
					rspchain.setRequestId(requestId);
					rspchain.setObjectType("Process Chains");
					rspchain.setObjStatus("ACTIVE");
					rspchainList.add(rspchain);
				}
			}

			// }

			bwCleanDao.batchInsertionForRspcchain(rspchainList, session);
			logger.debug("createListforRspchain() - End");
		} catch (Exception e) {
			logger.error("createListforRspchain :: ", e);
			throw e;
		} finally {
			IOUtils.closeQuietly(inputStream);

		}
	}

	protected void createListforRsrworkbook(String filePath, long requestId, HttpSession session) throws Exception {
		logger.debug("createListforRsrworkbook() - Start");
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);
		Rsrrworkbook rsrrwrkbk = null;
		List<Rsrrworkbook> genIdList = new ArrayList<Rsrrworkbook>();

		String fileName = file.getName();
		logger.info("Inside Method createListforRsrworkbook Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int objversIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objvers").get(1));
					int genIdIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("genuineid").get(1));
					int workIdIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("workbookid").get(1));
					if ("A".equalsIgnoreCase(row.getCell(objversIndex).getStringCellValue().trim())
							&& hm.getWorkbookIdList().contains(row.getCell(workIdIndex).getStringCellValue().trim())) {
						String genuineId = row.getCell(genIdIndex) == null ? ""
								: row.getCell(genIdIndex).getStringCellValue().trim();
						String workbookId = row.getCell(workIdIndex) == null ? ""
								: row.getCell(workIdIndex).getStringCellValue().trim();
						rsrrwrkbk = new Rsrrworkbook();
						rsrrwrkbk.setGenuineId(genuineId);
						rsrrwrkbk.setWorkbookId(workbookId);
						rsrrwrkbk.setRequestID(requestId);
						rsrrwrkbk.setObjType("Workbook");
						genIdList.add(rsrrwrkbk);
					}
				}
			}
			bwCleanDao.batchInsertionForRsrrworkbook(genIdList, session);
			logger.debug("createListforRsrworkbook() - End");
		} catch (Exception e) {
			logger.error("createListforRsrworkbook :: ", e);
			throw e;
		} finally {
			IOUtils.closeQuietly(inputStream);

		}

	}

	protected List<String> createListforRsrwbindext(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException, SQLException {
		logger.debug("createListforDsoInfoCubeMaster() - Start");
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);

		List<String> rsrwbIndexList = new ArrayList<String>();

		String fileName = file.getName();
		logger.info("Inside Method createListforRsrwbindext Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int objversIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objvers").get(1));
					int workbookIdIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("workbookid").get(1));
					if ("A".equalsIgnoreCase(row.getCell(objversIndex).getStringCellValue().trim())) {
						String workbookId = row.getCell(workbookIdIndex) == null ? ""
								: row.getCell(workbookIdIndex).getStringCellValue().trim();

						rsrwbIndexList.add(workbookId);
					}
				}
			}
			if (null != rsrwbIndexList) {
				hm.setWorkbookIdList(rsrwbIndexList);
			}
			logger.debug("createListforRsrwbindext() - End");
		} catch (Exception e) {
			logger.error("createListforRsrwbindext :: ", e);
			throw e;
		} finally {
			IOUtils.closeQuietly(inputStream);

		}
		return rsrwbIndexList;
	}

	protected List<Rspcchainattr> createListforRSPCCHAINATTR(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException, SQLException {
		logger.debug("createListforRSPCCHAINATTR() - Start");
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);

		List<Rspcchainattr> rspcAttrIndexList = new ArrayList<Rspcchainattr>();
		Rspcchainattr srpc = null;
		String fileName = file.getName();
		logger.info("Inside Method createListforRSPCCHAINATTR Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int objversIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objvers").get(1));
					int objStatIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objstat").get(1));
					int chainIdIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("chainId").get(1));
					if ("A".equalsIgnoreCase(row.getCell(objversIndex).getStringCellValue().trim())
							&& "INA".equalsIgnoreCase(row.getCell(objStatIndex).getStringCellValue().trim())) {
						String chainId = row.getCell(chainIdIndex) == null ? ""
								: row.getCell(chainIdIndex).getStringCellValue().trim();

						srpc = new Rspcchainattr();
						srpc.setChainId(chainId);
						srpc.setObjectType("Process Chains");
						srpc.setObjStatus("INACTIVE");
						srpc.setRequestId(requestId);
						rspcAttrIndexList.add(srpc);
					}
				}
			}
			if (null != rspcAttrIndexList) {
				hm.setRspcchainattrINAList(rspcAttrIndexList);
			}
			logger.debug("createListforRSPCCHAINATTR() - End");
		} catch (Exception e) {
			logger.error("createListforRSPCCHAINATTR :: ", e);
			throw e;
		} finally {
			IOUtils.closeQuietly(inputStream);

		}
		return rspcAttrIndexList;
	}

	protected List<Rsrwbindex> createListforRSRWBINDEX(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException, SQLException {
		logger.debug("createListforRSRWBINDEX() - Start");
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);

		List<Rsrwbindex> rsrwbIndexList = new ArrayList<Rsrwbindex>();
		Rsrwbindex rsrw = null;
		String fileName = file.getName();
		logger.info("Inside Method createListforRSRWBINDEX Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int objversIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objvers").get(1));
					int objStatIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objstat").get(1));
					int workIdIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("workid").get(1));
					if ("A".equalsIgnoreCase(row.getCell(objversIndex).getStringCellValue().trim())
							&& "INA".equalsIgnoreCase(row.getCell(objStatIndex).getStringCellValue().trim())) {
						String workBkId = row.getCell(workIdIndex) == null ? ""
								: row.getCell(workIdIndex).getStringCellValue().trim();
						logger.info("Row no :: " + row.getRowNum());
						rsrw = new Rsrwbindex();
						rsrw.setWorkbookId(workBkId);
						rsrw.setObjType("Workbook");
						rsrw.setObjStatus("INACTIVE");
						rsrw.setRequestID(requestId);
						rsrwbIndexList.add(rsrw);
					}
				}
			}
			if (null != rsrwbIndexList) {
				hm.setRsrwbindexList(rsrwbIndexList);
			}
			logger.debug("createListforRSRWBINDEX() - End");
		} catch (Exception e) {
			logger.error("createListforRSRWBINDEX :: ", e);
			throw e;
		} finally {
			IOUtils.closeQuietly(inputStream);

		}
		return rsrwbIndexList;
	}

	protected List<Rsdiobj> createListforRsdiobj(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException, SQLException {
		logger.debug("createListforRsdiobj() - Start");
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);

		List<Rsdiobj> rsdiobjList = new ArrayList<Rsdiobj>();
		Rsdiobj rsdi = null;
		String fileName = file.getName();
		logger.info("Inside Method createListforRsdiobj Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int objversIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objvers").get(1));
					int objStatIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objstat").get(1));
					int iobjnmIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("iobjnm").get(1));
					if ("A".equalsIgnoreCase(row.getCell(objversIndex).getStringCellValue().trim())
							&& "INA".equalsIgnoreCase(row.getCell(objStatIndex).getStringCellValue().trim())) {
						String iobjNm = row.getCell(iobjnmIndex) == null ? ""
								: row.getCell(iobjnmIndex).getStringCellValue().trim();

						rsdi = new Rsdiobj();
						rsdi.setIobjnm(iobjNm);
						rsdi.setObjType("InfoObject");
						rsdi.setObjStatus("INACTIVE");
						rsdi.setRequestId(requestId);
						rsdiobjList.add(rsdi);
					}
				}
			}
			if (null != rsdiobjList) {
				hm.setRsdiobjList(rsdiobjList);
			}
			logger.info("createListforRsdiobj() - End");
		} catch (Exception e) {
			logger.error("createListforRsdiobj :: ", e);
			throw e;
		} finally {
			IOUtils.closeQuietly(inputStream);

		}
		return rsdiobjList;
	}

	protected List<Rsqiset> createListforRsqiset(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException, SQLException {
		logger.debug("createListforRsqiset() - Start");
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);

		List<Rsqiset> rsqisetList = new ArrayList<Rsqiset>();
		Rsqiset rsqi = null;
		String fileName = file.getName();
		logger.info("Inside Method createListforRsqiset Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int objversIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objvers").get(1));
					int objStatIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objstat").get(1));
					int infosetIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("infoset").get(1));
					if ("A".equalsIgnoreCase(row.getCell(objversIndex).getStringCellValue().trim())
							&& "INA".equalsIgnoreCase(row.getCell(objStatIndex).getStringCellValue().trim())) {
						String infoset = row.getCell(infosetIndex) == null ? ""
								: row.getCell(infosetIndex).getStringCellValue().trim();

						rsqi = new Rsqiset();
						rsqi.setInfoSet(infoset);
						rsqi.setObjType("InfoSet");
						rsqi.setObjStatus("INACTIVE");
						rsqi.setRequestId(requestId);
						rsqisetList.add(rsqi);
					}
				}
			}
			if (null != rsqisetList) {
				hm.setRsqisetList(rsqisetList);
			}
			logger.info("createListforRsqiset() - End");
		} catch (Exception e) {
			logger.error("createListforRsqiset :: ", e);
			throw e;
		} finally {
			IOUtils.closeQuietly(inputStream);

		}
		return rsqisetList;
	}

	protected List<Rsbohdest> createListforRsbohdest(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException, SQLException {
		logger.debug("createListforRsqiset() - Start");
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);

		List<Rsbohdest> rsbohList = new ArrayList<Rsbohdest>();
		Rsbohdest rsboh = null;
		String fileName = file.getName();
		logger.info("Inside Method createListforRsqiset Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int objversIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objvers").get(1));
					int objStatIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objstat").get(1));
					int ohdestIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("ohdest").get(1));
					if ("A".equalsIgnoreCase(row.getCell(objversIndex).getStringCellValue().trim())
							&& "INA".equalsIgnoreCase(row.getCell(objStatIndex).getStringCellValue().trim())) {
						String ohDest = row.getCell(ohdestIndex) == null ? ""
								: row.getCell(ohdestIndex).getStringCellValue().trim();

						rsboh = new Rsbohdest();
						rsboh.setOhDest(ohDest);
						rsboh.setObjType("ODH");
						rsboh.setObjStatus("INACTIVE");
						rsboh.setRequestid(requestId);
						rsbohList.add(rsboh);
					}
				}
			}
			if (null != rsbohList) {
				hm.setRsbohDestList(rsbohList);
			}
			logger.info("createListforRsqiset() - End");
		} catch (Exception e) {
			logger.error("createListforRsqiset :: ", e);
			throw e;
		} finally {
			IOUtils.closeQuietly(inputStream);

		}
		return rsbohList;
	}

	protected List<Rsohcpr> createListforRsohcpr(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException, SQLException {
		logger.debug("createListforRsohcpr() - Start");
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);

		List<Rsohcpr> rsohcprList = new ArrayList<Rsohcpr>();
		Rsohcpr rsoh = null;
		String fileName = file.getName();
		logger.info("Inside Method createListforRsohcpr Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int objversIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objvers").get(1));
					int objStatIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objstat").get(1));
					int hcprnmIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("hcprnm").get(1));
					if ("A".equalsIgnoreCase(row.getCell(objversIndex).getStringCellValue().trim())
							&& "INA".equalsIgnoreCase(row.getCell(objStatIndex).getStringCellValue().trim())) {
						String hcpRnm = row.getCell(hcprnmIndex) == null ? ""
								: row.getCell(hcprnmIndex).getStringCellValue().trim();

						rsoh = new Rsohcpr();
						rsoh.setHcprnm(hcpRnm);
						rsoh.setObjType("HANA Composite Provider");
						rsoh.setObjStatus("INACTIVE");
						rsoh.setRequestId(requestId);
						rsohcprList.add(rsoh);
					}
				}
			}
			if (null != rsohcprList) {
				hm.setRsohcprList(rsohcprList);
			}
			logger.info("createListforRsohcpr() - End");
		} catch (Exception e) {
			logger.error("createListforRsohcpr :: ", e);
			throw e;
		} finally {
			IOUtils.closeQuietly(inputStream);

		}
		return rsohcprList;
	}

	protected List<Rsupdinfo> createListforRsupdinfo(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException, SQLException {
		logger.debug("createListforRsupdinfo() - Start");
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);

		List<Rsupdinfo> rsupList = new ArrayList<Rsupdinfo>();
		Rsupdinfo rsup = null;
		String fileName = file.getName();
		logger.info("Inside Method createListforRsupdinfo Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int objversIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objvers").get(1));
					int objStatIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objstat").get(1));
					int updidIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("updid").get(1));
					if ("A".equalsIgnoreCase(row.getCell(objversIndex).getStringCellValue().trim())
							&& "INA".equalsIgnoreCase(row.getCell(objStatIndex).getStringCellValue().trim())) {
						String updid = row.getCell(updidIndex) == null ? ""
								: row.getCell(updidIndex).getStringCellValue().trim();

						rsup = new Rsupdinfo();
						rsup.setUpdid(updid);
						rsup.setObjType("Update rules");
						rsup.setObjStatus("INACTIVE");
						rsup.setRequestId(requestId);
						rsupList.add(rsup);
					}
				}
			}
			if (null != rsupList) {
				hm.setRsupdinfoList(rsupList);
			}
			logger.info("createListforRsupdinfo() - End");
		} catch (Exception e) {
			logger.error("createListforRsupdinfo :: ", e);
			throw e;
		} finally {
			IOUtils.closeQuietly(inputStream);

		}
		return rsupList;
	}

	protected List<Rsts> createListforRsts(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException, SQLException {
		logger.debug("createListforRsts() - Start");
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);

		List<Rsts> rstsList = new ArrayList<Rsts>();
		Rsts rsts = null;
		String fileName = file.getName();
		logger.info("Inside Method createListforRsts Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int objversIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objvers").get(1));
					int objStatIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objstat").get(1));
					int transtruIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("transtru").get(1));
					int logsysIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("logsys").get(1));
					if ("A".equalsIgnoreCase(row.getCell(objversIndex).getStringCellValue().trim())
							&& "INA".equalsIgnoreCase(row.getCell(objStatIndex).getStringCellValue().trim())) {
						String transtru = row.getCell(transtruIndex) == null ? ""
								: row.getCell(transtruIndex).getStringCellValue().trim();
						String logsys = row.getCell(logsysIndex) == null ? ""
								: row.getCell(logsysIndex).getStringCellValue().trim();

						rsts = new Rsts();
						rsts.setLogsys(logsys);
						rsts.setTranstru(transtru);
						rsts.setObjType("Transfer Structure/Transfer rules");
						rsts.setObjStatus("INACTIVE");
						rsts.setRequestId(requestId);
						rstsList.add(rsts);
					}
				}
			}
			if (null != rstsList) {
				hm.setRstsList(rstsList);
			}
			logger.info("createListforRsts() - End");
		} catch (Exception e) {
			logger.error("createListforRsts :: ", e);
			throw e;
		} finally {
			IOUtils.closeQuietly(inputStream);

		}
		return rstsList;
	}

	protected List<Rsds> createListforRsds(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException, SQLException {
		logger.debug("createListforRsds() - Start");
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);

		List<Rsds> rsdsList = new ArrayList<Rsds>();
		Rsds rsds = null;
		String fileName = file.getName();
		logger.info("Inside Method createListforRsds Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int objversIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objvers").get(1));
					int objStatIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objstat").get(1));
					int dataIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("datasource").get(1));

					if ("A".equalsIgnoreCase(row.getCell(objversIndex).getStringCellValue().trim())
							&& "INA".equalsIgnoreCase(row.getCell(objStatIndex).getStringCellValue().trim())) {
						String datasource = row.getCell(dataIndex) == null ? ""
								: row.getCell(dataIndex).getStringCellValue().trim();

						rsds = new Rsds();
						rsds.setDataSource(datasource);
						rsds.setObjType("Datasources(7.X)");
						rsds.setObjStatus("INACTIVE");
						rsds.setRequestId(requestId);
						rsdsList.add(rsds);
					}
				}
			}
			if (null != rsdsList) {
				hm.setRsdsList(rsdsList);
			}
			logger.info("createListforRsds() - End");
		} catch (Exception e) {
			logger.error("createListforRsds :: ", e);
			throw e;
		} finally {
			IOUtils.closeQuietly(inputStream);

		}
		return rsdsList;
	}

	protected List<Rsldpio> createListforRsldpio(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException, SQLException {
		logger.debug("createListforRsds() - Start");
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);

		List<Rsldpio> rsldpioList = new ArrayList<Rsldpio>();
		Rsldpio rsldpio = null;
		String fileName = file.getName();
		logger.info("Inside Method createListforRsds Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int objversIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objvers").get(1));
					int objStatIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objstat").get(1));
					int logdPidIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("logdpid").get(1));

					if ("A".equalsIgnoreCase(row.getCell(objversIndex).getStringCellValue().trim())
							&& "INA".equalsIgnoreCase(row.getCell(objStatIndex).getStringCellValue().trim())) {
						String logdPid = row.getCell(logdPidIndex) == null ? ""
								: row.getCell(logdPidIndex).getStringCellValue().trim();

						rsldpio = new Rsldpio();
						rsldpio.setLogdPid(logdPid);
						rsldpio.setObjType("Infopackages");
						rsldpio.setObjStatus("INACTIVE");
						rsldpio.setRequestId(requestId);
						rsldpioList.add(rsldpio);
					}
				}
			}
			if (null != rsldpioList) {
				hm.setRsldpioList(rsldpioList);
			}
			logger.info("createListforRsds() - End");
		} catch (Exception e) {
			logger.error("createListforRsds :: ", e);
			throw e;
		} finally {
			IOUtils.closeQuietly(inputStream);

		}
		return rsldpioList;
	}

	protected List<RsantProcess> createListforRsant_process(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException, SQLException {
		logger.debug("createListforRsant_process() - Start");
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);

		List<RsantProcess> rsantProcessList = new ArrayList<RsantProcess>();
		RsantProcess rasntProcess = null;
		String fileName = file.getName();
		logger.info("Inside Method createListforRsant_process Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int objversIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objvers").get(1));
					int objStatIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objstat").get(1));
					int processIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("process").get(1));

					if ("A".equalsIgnoreCase(row.getCell(objversIndex).getStringCellValue().trim())
							&& "INA".equalsIgnoreCase(row.getCell(objStatIndex).getStringCellValue().trim())) {
						String process = row.getCell(processIndex) == null ? ""
								: row.getCell(processIndex).getStringCellValue().trim();

						rasntProcess = new RsantProcess();
						rasntProcess.setProcess(process);
						rasntProcess.setObjType("APD");
						rasntProcess.setObjStatus("INACTIVE");
						rasntProcess.setRequestId(requestId);
						rsantProcessList.add(rasntProcess);
					}
				}
			}
			if (null != rsantProcessList) {
				hm.setRsantprocessList(rsantProcessList);
			}
			logger.info("createListforRsant_process() - End");
		} catch (Exception e) {
			logger.error("createListforRsant_process :: ", e);
			throw e;
		} finally {
			IOUtils.closeQuietly(inputStream);

		}
		return rsantProcessList;
	}

	protected List<Rszwbtmphead> createListforRszwbtmphead(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException, SQLException {
		logger.debug("createListforRszwbtmphead() - Start");
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);

		List<Rszwbtmphead> rszwbtmpheadList = new ArrayList<Rszwbtmphead>();
		Rszwbtmphead rszwbtmphead = null;
		String fileName = file.getName();
		logger.info("Inside Method createListforRszwbtmphead Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int objversIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objvers").get(1));
					int objStatIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("objstat").get(1));
					int objidIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("objid").get(1));

					if ("A".equalsIgnoreCase(row.getCell(objversIndex).getStringCellValue().trim())
							&& "INA".equalsIgnoreCase(row.getCell(objStatIndex).getStringCellValue().trim())) {
						String objid = row.getCell(objidIndex) == null ? ""
								: row.getCell(objidIndex).getStringCellValue().trim();

						rszwbtmphead = new Rszwbtmphead();
						rszwbtmphead.setObjid(objid);
						rszwbtmphead.setObjType("APD");
						rszwbtmphead.setObjStatus("INACTIVE");
						rszwbtmphead.setRequestId(requestId);
						rszwbtmpheadList.add(rszwbtmphead);
					}
				}
			}
			if (null != rszwbtmpheadList) {
				hm.setRszwbtmpheadList(rszwbtmpheadList);
			}
			logger.info("createListforRszwbtmphead() - End");
		} catch (Exception e) {
			logger.error("createListforRszwbtmphead :: ", e);
			throw e;
		} finally {
			IOUtils.closeQuietly(inputStream);

		}
		return rszwbtmpheadList;
	}

	protected List<Unicode> createListforUnicode(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException, SQLException {
		logger.debug("createListforUnicode() - Start");
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);

		List<Unicode> unicodeList = new ArrayList<Unicode>();
		Unicode unicode = null;
		String fileName = file.getName();
		logger.info("Inside Method createListforUnicode Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int orgSysIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("orgSys").get(1));
					int programIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("program").get(1));
					int includeIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("include").get(1));
					int rowIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("row").get(1));
					int errorCodeIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("errorCode").get(1));
					int messageIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("message").get(1));
					int createdByIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("createdBy").get(1));
					int packIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("package").get(1));
					int packPersIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("packagePerResp").get(1));
					int appCompIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("appComp").get(1));

					String orgSys = row.getCell(orgSysIndex) == null ? ""
							: row.getCell(orgSysIndex).getStringCellValue().trim();
					String program = row.getCell(programIndex) == null ? ""
							: row.getCell(programIndex).getStringCellValue().trim();
					String include = row.getCell(includeIndex) == null ? ""
							: row.getCell(includeIndex).getStringCellValue().trim();
					String rowi = row.getCell(rowIndex) == null ? ""
							: row.getCell(rowIndex).getStringCellValue().trim();
					String errorCode = row.getCell(errorCodeIndex) == null ? ""
							: row.getCell(errorCodeIndex).getStringCellValue().trim();
					String message = row.getCell(messageIndex) == null ? ""
							: row.getCell(messageIndex).getStringCellValue().trim();
					String createdBy = row.getCell(createdByIndex) == null ? ""
							: row.getCell(createdByIndex).getStringCellValue().trim();
					String pack = row.getCell(packIndex) == null ? ""
							: row.getCell(packIndex).getStringCellValue().trim();
					String packPers = row.getCell(packPersIndex) == null ? ""
							: row.getCell(packPersIndex).getStringCellValue().trim();
					String appComp = row.getCell(appCompIndex) == null ? ""
							: row.getCell(appCompIndex).getStringCellValue().trim();

					unicode = new Unicode();
					unicode.setObjType("PROG");
					unicode.setProgram(program);
					unicode.setInclude(include);
					unicode.setRoww(rowi);
					unicode.setErrorCode(errorCode);
					unicode.setMessage(message);
					unicode.setCreatedBy(createdBy);
					unicode.setPack(pack);
					unicode.setPackPerResp(packPers);
					unicode.setRequestId(requestId);
					unicode.setConcatCol(program + include + rowi + errorCode);
					unicode.setApplicationComp(appComp);
					unicodeList.add(unicode);

				}
			}
			if (null != unicodeList) {
				batchInsertForUnicode(unicodeList, session, requestId);
			}
			logger.info("createListforUnicode() - End");
		} catch (Exception e) {
			logger.error("createListforUnicode :: ", e);
			throw e;
		} finally {
			IOUtils.closeQuietly(inputStream);

		}
		return unicodeList;
	}

	public String batchInsertForUnicode(List<Unicode> unicodeList, HttpSession session, Long requestID)
			throws SQLException {
		final String INSERT_SQL = "INSERT INTO UNICODE_Tbl "
				+ "(Program, Include, Roww, Error_Code, Message, Created_By, Pack, Pack_Per_Resp, Request_Id, Concat_Col,Object_Type) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {
			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;
				for (Unicode unicode : unicodeList) {
					stmt.setString(1, unicode.getProgram());
					stmt.setString(2, unicode.getInclude());
					stmt.setString(3, unicode.getRoww());
					stmt.setString(4, unicode.getErrorCode());
					stmt.setString(5, unicode.getMessage());
					stmt.setString(6, unicode.getCreatedBy());
					stmt.setString(7, unicode.getPack());
					stmt.setString(8, unicode.getPackPerResp());
					stmt.setLong(9, unicode.getRequestId());
					stmt.setString(10, unicode.getConcatCol());
					stmt.setString(11, unicode.getObjType());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 1000 records
					if (counter % 1000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();

				logger.info("batchInsertForUnicode Data INSERTED SUCCESSFULLY");
			} catch (Exception e) {
				result = "FAILURE in inserting data";
				logger.error("Error in batchInsertForUnicode :: ", e);
			}

		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error("Error in batchInsertForUnicode :: ", e);
		} finally {
			stmt.close();
			conn.close();
		}

		return result;
	}

	private void addExtUsgaeAnalysisData(final String filePath, final long requestId, final HttpSession session)
			throws FileNotFoundException {
		final File file = new File(filePath);
		final InputStream inputStream = new FileInputStream(file);
		final String fileName = file.getName();
		final List<UsageAnalysisExt> usageAnalysisExtList = new ArrayList<UsageAnalysisExt>();
		try {
			final StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (final Row r : reader) {
				if (r.getRowNum() > 0) {
					final int objectIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Object").get(1));
					final int onjNameIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Obj.name").get(1));
					final int volumeIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Volume").get(1));
					final int frequencyIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Frequency").get(1));
					final int usageIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Usage").get(1));
					final String object = (r.getCell(objectIndex) == null) ? ""
							: r.getCell(objectIndex).getStringCellValue().trim();

					final String objName = (r.getCell(onjNameIndex) == null) ? ""
							: r.getCell(onjNameIndex).getStringCellValue().trim();
					if (object.equals("") || objName.equals("")) {
						continue;
					}
					final Integer volume = Integer.parseInt(
							(r.getCell(volumeIndex) == null || r.getCell(volumeIndex).getStringCellValue().equals(""))
									? "0" : r.getCell(volumeIndex).getStringCellValue().trim());
					final Integer frequency = Integer.parseInt((r.getCell(frequencyIndex) == null
							|| r.getCell(frequencyIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(frequencyIndex).getStringCellValue().trim());
					final String usage = (r.getCell(usageIndex) == null) ? ""
							: r.getCell(usageIndex).getStringCellValue().trim();

					final UsageAnalysisExt usageAnalysisExt = new UsageAnalysisExt();
					usageAnalysisExt.setObject(object);
					usageAnalysisExt.setObjName(objName);
					usageAnalysisExt.setFrequency(frequency);
					usageAnalysisExt.setVolume(volume);
					usageAnalysisExt.setUsage(usage);
					usageAnalysisExtList.add(usageAnalysisExt);
				}
			}
			if (usageAnalysisExtList != null && !usageAnalysisExtList.isEmpty()) {
				hm.setUsageAnalysisExtList(usageAnalysisExtList);
			}
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
		IOUtils.closeQuietly(inputStream);
	}

	private void addComplexityRules(final String filePath, final long requestId, final HttpSession session)
			throws FileNotFoundException {
		final File file = new File(filePath);
		final InputStream inputStream = new FileInputStream(file);
		final String fileName = file.getName();
		final List<ComplexityRules> complexityRulesList = new ArrayList<ComplexityRules>();
		try {
			final StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (final Row r : reader) {
				if (r.getRowNum() > 0) {
					final int objectIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Object").get(1));
					final int categoryIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Category").get(1));
					final int complexityIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Complexity").get(1));
					final int fileExtIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("File.ext").get(1));
					final int rfcIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Rfc").get(1));

					final int tabSapIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Tab.sap").get(1));
					final int tabCustIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Tab.cust").get(1));

					final int updCountIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Upd.count").get(1));
					final int insCountIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Ins.count").get(1));
					final int delCountIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Del.count").get(1));
					final int bapiCudIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Bapi.cud").get(1));
					final int drillIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Drill").get(1));
					final int tabFieldIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Tab.field").get(1));

					final int fmSapIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Fm.sap").get(1));
					final int fmCustIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Fm.cust").get(1));
					final int entityCountIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE
							.get(requestId).get(fileName).get("Entity.count").get(1));
					final int viewCustIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("View.cust").get(1));

					final int moduleScreenIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE
							.get(requestId).get(fileName).get("Module.Screen").get(1));
					final int enhImplIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Enh.Impl").get(1));
					final int authObjIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Auth.obj").get(1));
					final int dblinkIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Db.link").get(1));
					final int selCountIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Sel.count").get(1));
					final int dynproUseIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Dynpro.use").get(1));
					final int sumFmSelIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("sum.fmSel").get(1));
					final int sumTabsIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("sum.tabs").get(1));
					final int sumCrudIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("sum.crud").get(1));

					final String object = (r.getCell(objectIndex) == null) ? ""
							: r.getCell(objectIndex).getStringCellValue().trim();
					final String category = (r.getCell(categoryIndex) == null) ? ""
							: r.getCell(categoryIndex).getStringCellValue().trim();
					if (object.equals("") || category.equals("")) {
						continue;
					}
					final String complexity = (r.getCell(complexityIndex) == null) ? ""
							: r.getCell(complexityIndex).getStringCellValue().trim();
					final String fileExt = (r.getCell(fileExtIndex) == null
							|| r.getCell(fileExtIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(fileExtIndex).getStringCellValue().trim();
					final String rfc = (r.getCell(rfcIndex) == null
							|| r.getCell(rfcIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(rfcIndex).getStringCellValue().trim();
					final String tabSap = (r.getCell(tabSapIndex) == null
							|| r.getCell(tabSapIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(tabSapIndex).getStringCellValue().trim();
					final String tabCust = (r.getCell(tabCustIndex) == null
							|| r.getCell(tabCustIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(tabCustIndex).getStringCellValue().trim();

					final String updCount = (r.getCell(updCountIndex) == null
							|| r.getCell(updCountIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(updCountIndex).getStringCellValue().trim();
					final String insCount = (r.getCell(insCountIndex) == null
							|| r.getCell(insCountIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(insCountIndex).getStringCellValue().trim();
					final String delCount = (r.getCell(delCountIndex) == null
							|| r.getCell(delCountIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(delCountIndex).getStringCellValue().trim();
					final String bapiCud = (r.getCell(bapiCudIndex) == null
							|| r.getCell(bapiCudIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(bapiCudIndex).getStringCellValue().trim();
					final String drill = (r.getCell(drillIndex) == null
							|| r.getCell(drillIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(drillIndex).getStringCellValue().trim();

					final String tabField = (r.getCell(tabFieldIndex) == null
							|| r.getCell(tabFieldIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(tabFieldIndex).getStringCellValue().trim();

					final String fmSap = (r.getCell(fmSapIndex) == null
							|| r.getCell(fmSapIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(fmSapIndex).getStringCellValue().trim();
					final String fmCust = (r.getCell(fmCustIndex) == null
							|| r.getCell(fmCustIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(fmCustIndex).getStringCellValue().trim();
					final String entityCount = (r.getCell(entityCountIndex) == null
							|| r.getCell(entityCountIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(entityCountIndex).getStringCellValue().trim();
					final String viewCust = (r.getCell(viewCustIndex) == null
							|| r.getCell(viewCustIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(viewCustIndex).getStringCellValue().trim();

					final String moduleScreen = (r.getCell(moduleScreenIndex) == null
							|| r.getCell(moduleScreenIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(moduleScreenIndex).getStringCellValue().trim();

					final String enhImpl = (r.getCell(enhImplIndex) == null
							|| r.getCell(enhImplIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(enhImplIndex).getStringCellValue().trim();

					final String authObj = (r.getCell(authObjIndex) == null
							|| r.getCell(authObjIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(authObjIndex).getStringCellValue().trim();

					final String dbLinkCount = (r.getCell(dblinkIndex) == null
							|| r.getCell(dblinkIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(dblinkIndex).getStringCellValue().trim();

					final String selCount = (r.getCell(selCountIndex) == null
							|| r.getCell(selCountIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(selCountIndex).getStringCellValue().trim();

					final String dynproUse = (r.getCell(dynproUseIndex) == null
							|| r.getCell(dynproUseIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(dynproUseIndex).getStringCellValue().trim();

					final String sumFmSel = (r.getCell(sumFmSelIndex) == null
							|| r.getCell(sumFmSelIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(sumFmSelIndex).getStringCellValue().trim();

					final String sumTabs = (r.getCell(sumTabsIndex) == null
							|| r.getCell(sumTabsIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(sumTabsIndex).getStringCellValue().trim();

					final String sumCrud = (r.getCell(sumCrudIndex) == null
							|| r.getCell(sumCrudIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(sumCrudIndex).getStringCellValue().trim();

					final ComplexityRules complexityRules = new ComplexityRules();

					complexityRules.setObject(object);
					complexityRules.setCategory(category);
					complexityRules.setComplexity(complexity);

					complexityRules.setFileExt(checkPattern(fileExt) ? getPValue(fileExt) : fileExt);
					complexityRules.setSfileExt(checkPattern(fileExt) ? getSValue(fileExt) : fileExt);

					complexityRules.setRfc(checkPattern(rfc) ? getPValue(rfc) : rfc);
					complexityRules.setSrfc(checkPattern(rfc) ? getSValue(rfc) : rfc);

					complexityRules.setTabCust(checkPattern(tabCust) ? getPValue(tabCust) : tabCust);
					complexityRules.setTabCust(checkPattern(tabCust) ? getSValue(tabCust) : tabCust);

					complexityRules.setTabSap(checkPattern(tabSap) ? getPValue(tabSap) : tabSap);
					complexityRules.setStabSap(checkPattern(tabSap) ? getSValue(tabSap) : tabSap);

					complexityRules.setSumOfCrud(checkPattern(sumCrud) ? getPValue(sumCrud) : sumCrud);
					complexityRules.setSsumOfCrud(checkPattern(sumCrud) ? getSValue(sumCrud) : sumCrud);

					complexityRules.setSumOfTabs(checkPattern(sumTabs) ? getPValue(sumTabs) : sumTabs);
					complexityRules.setSsumOfTabs(checkPattern(sumTabs) ? getSValue(sumTabs) : sumTabs);

					complexityRules.setDrill(checkPattern(drill) ? getPValue(drill) : drill);
					complexityRules.setSdrill(checkPattern(drill) ? getSValue(drill) : drill);

					complexityRules.setTabField(checkPattern(tabField) ? getPValue(tabField) : tabField);
					complexityRules.setStabField(checkPattern(tabField) ? getSValue(tabField) : tabField);

					complexityRules.setFmSap(checkPattern(fmSap) ? getPValue(fmSap) : fmSap);
					complexityRules.setSfmSap(checkPattern(fmSap) ? getSValue(fmSap) : fmSap);

					complexityRules.setFmCust(checkPattern(fmCust) ? getPValue(fmCust) : fmCust);
					complexityRules.setSfmCust(checkPattern(fmCust) ? getSValue(fmCust) : fmCust);

					complexityRules.setEntityCount(checkPattern(entityCount) ? getPValue(entityCount) : entityCount);
					complexityRules.setSentityCount(checkPattern(entityCount) ? getSValue(entityCount) : entityCount);

					complexityRules.setViewCust(checkPattern(viewCust) ? getPValue(viewCust) : viewCust);
					complexityRules.setSviewCust(checkPattern(viewCust) ? getSValue(viewCust) : viewCust);

					complexityRules
							.setModuleScreen(checkPattern(moduleScreen) ? getPValue(moduleScreen) : moduleScreen);
					complexityRules
							.setSmoduleScreen(checkPattern(moduleScreen) ? getSValue(moduleScreen) : moduleScreen);

					complexityRules.setEnhImpl(checkPattern(enhImpl) ? getPValue(enhImpl) : enhImpl);
					complexityRules.setSenhImpl(checkPattern(enhImpl) ? getSValue(enhImpl) : enhImpl);

					complexityRules.setAuthObj(checkPattern(authObj) ? getPValue(authObj) : authObj);
					complexityRules.setSauthObj(checkPattern(authObj) ? getSValue(authObj) : authObj);

					complexityRules.setDbLinkCount(checkPattern(dbLinkCount) ? getPValue(dbLinkCount) : dbLinkCount);
					complexityRules.setSdbLinkCount(checkPattern(dbLinkCount) ? getSValue(dbLinkCount) : dbLinkCount);

					complexityRules.setSelCount(checkPattern(selCount) ? getPValue(selCount) : selCount);
					complexityRules.setSselCount(checkPattern(selCount) ? getSValue(selCount) : selCount);

					complexityRules.setDynproUse(checkPattern(dynproUse) ? getPValue(dynproUse) : dynproUse);
					complexityRules.setSdynproUse(checkPattern(dynproUse) ? getSValue(dynproUse) : dynproUse);

					complexityRules.setSumfmSel(checkPattern(sumFmSel) ? getPValue(sumFmSel) : sumFmSel);
					complexityRules.setSsumfmSel(checkPattern(sumFmSel) ? getSValue(sumFmSel) : sumFmSel);

					complexityRulesList.add(complexityRules);
				}
			}
			if (complexityRulesList != null && !complexityRulesList.isEmpty()) {
				hm.setComplexityRulesList(complexityRulesList);
			}
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
		IOUtils.closeQuietly(inputStream);
	}

	private boolean checkPattern(String value) {
		if (value.contains("_")) {
			return true;
		}
		return false;
	}

	private String getPValue(String value) {
		String primary = value.split("_")[0];
		return primary;
	}

	private String getSValue(String value) {
		String secondary = value.split("_")[1];
		return secondary;
	}

	private void addExtensibilityRules(final String filePath, final long requestId, final HttpSession session)
			throws FileNotFoundException {
		final File file = new File(filePath);
		final InputStream inputStream = new FileInputStream(file);
		final String fileName = file.getName();
		final List<ExtensionRules> extRulesList = new ArrayList<ExtensionRules>();
		try {
			final StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (final Row r : reader) {
				if (r.getRowNum() == 1) {
					final int fileExtIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("File.ext").get(1));
					final int volumeIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Volume").get(1));
					final int frequencyIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Frequency").get(1));
					final int ricefDepIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Ricef.depd").get(1));
					final int updCountIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Upd.count").get(1));
					final int tabSapIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Tab.sap").get(1));
					final int nativeIntfIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Native.intf").get(1));
					final int dynproUseIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Dynpro.use").get(1));
					final int bapiReadIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Bapi.read").get(1));

					final String fileExtComments = (r.getCell(fileExtIndex) == null) ? ""
							: r.getCell(fileExtIndex).getStringCellValue().trim();
					final String volumeComments = (r.getCell(volumeIndex) == null) ? ""
							: r.getCell(volumeIndex).getStringCellValue().trim();
					final String frequencyComments = (r.getCell(frequencyIndex) == null) ? ""
							: r.getCell(frequencyIndex).getStringCellValue().trim();
					final String ricefDepComments = (r.getCell(ricefDepIndex) == null) ? ""
							: r.getCell(ricefDepIndex).getStringCellValue().trim();
					final String sumComments = (r.getCell(updCountIndex) == null) ? ""
							: r.getCell(updCountIndex).getStringCellValue().trim();
					final String tabComments = (r.getCell(tabSapIndex) == null) ? ""
							: r.getCell(tabSapIndex).getStringCellValue().trim();
					final String nativeIntfComments = (r.getCell(nativeIntfIndex) == null) ? ""
							: r.getCell(nativeIntfIndex).getStringCellValue().trim();
					final String dynproUseComments = (r.getCell(dynproUseIndex) == null) ? ""
							: r.getCell(dynproUseIndex).getStringCellValue().trim();
					final String bapiReadComments = (r.getCell(bapiReadIndex) == null) ? ""
							: r.getCell(bapiReadIndex).getStringCellValue().trim();

					final ExtensionRules extensionComments = new ExtensionRules();

					extensionComments.setFileExtComments(fileExtComments);
					extensionComments.setVolumeComments(volumeComments);
					extensionComments.setFrequencyComments(frequencyComments);
					extensionComments.setSumComments(sumComments);
					extensionComments.setRicefDepdComments(ricefDepComments);
					extensionComments.setTabComments(tabComments);
					extensionComments.setNativeIntfComments(nativeIntfComments);
					extensionComments.setDynproUseComments(dynproUseComments);
					extensionComments.setBapiReadComments(bapiReadComments);
					if (extensionComments != null) {
						hm.setExtensionComments(extensionComments);
					}
				}
				if (r.getRowNum() > 1) {
					final int objectIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Object").get(1));
					final int categoryIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Category").get(1));
					final int extensibilityIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE
							.get(requestId).get(fileName).get("Extensibility").get(1));
					final int fileExtIndex2 = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("File.ext").get(1));
					final int volumeIndex2 = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Volume").get(1));
					final int frequencyIndex2 = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Frequency").get(1));
					final int ricefDepIndex2 = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Ricef.depd").get(1));

					final int updCountIndex2 = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Upd.count").get(1));
					final int insCountIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Ins.count").get(1));
					final int delCountIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Del.count").get(1));
					final int bapiCudIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Bapi.cud").get(1));
					final int drillIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Drill").get(1));
					final int zUpdCountIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("zUpd.count").get(1));
					final int zInsCountIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("zIns.count").get(1));
					final int zDelCountIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("zDel.count").get(1));
					final int bapiReadIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Bapi.read").get(1));

					final int nativeIntfIndex2 = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE
							.get(requestId).get(fileName).get("Native.intf").get(1));
					final int dynproUseIndex2 = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Dynpro.use").get(1));

					final int tabSapIndex2 = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Tab.sap").get(1));
					final int tabCustIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Tab.cust").get(1));
					final int subcatDtlIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Subcat.dtl").get(1));
					final int subcatFIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Subcat.f").get(1));
					final int subcatIIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Subcat.i").get(1));
					final int viewCustIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("View.cust").get(1));
					final int viewSapIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("View.sap").get(1));

					final int fmSapIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Fm.sap").get(1));
					final int fmCustIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Fm.cust").get(1));

					final String object = (r.getCell(objectIndex) == null) ? ""
							: r.getCell(objectIndex).getStringCellValue().trim();
					final String category = (r.getCell(categoryIndex) == null) ? ""
							: r.getCell(categoryIndex).getStringCellValue().trim();
					if (object.equals("") || category.equals("")) {
						continue;
					}
					final String extensibility = (r.getCell(extensibilityIndex) == null) ? ""
							: r.getCell(extensibilityIndex).getStringCellValue().trim();
					final Integer fileExt = Integer.parseInt((r.getCell(fileExtIndex2) == null
							|| r.getCell(fileExtIndex2).getStringCellValue().equals("")) ? "0"
									: r.getCell(fileExtIndex2).getStringCellValue().trim());
					final Integer volume = Integer.parseInt(
							(r.getCell(volumeIndex2) == null || r.getCell(volumeIndex2).getStringCellValue().equals(""))
									? "0" : r.getCell(volumeIndex2).getStringCellValue().trim());
					final Integer frequency = Integer.parseInt((r.getCell(frequencyIndex2) == null
							|| r.getCell(frequencyIndex2).getStringCellValue().equals("")) ? "0"
									: r.getCell(frequencyIndex2).getStringCellValue().trim());
					final Integer ricefDep = Integer.parseInt((r.getCell(ricefDepIndex2) == null
							|| r.getCell(ricefDepIndex2).getStringCellValue().equals("")) ? "0"
									: r.getCell(ricefDepIndex2).getStringCellValue().trim());

					final Integer updCount = Integer.parseInt((r.getCell(updCountIndex2) == null
							|| r.getCell(updCountIndex2).getStringCellValue().equals("")) ? "0"
									: r.getCell(updCountIndex2).getStringCellValue().trim());
					final Integer insCount = Integer.parseInt((r.getCell(insCountIndex) == null
							|| r.getCell(insCountIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(insCountIndex).getStringCellValue().trim());
					final Integer delCount = Integer.parseInt((r.getCell(delCountIndex) == null
							|| r.getCell(delCountIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(delCountIndex).getStringCellValue().trim());
					final Integer bapiCud = Integer.parseInt(
							(r.getCell(bapiCudIndex) == null || r.getCell(bapiCudIndex).getStringCellValue().equals(""))
									? "0" : r.getCell(bapiCudIndex).getStringCellValue().trim());
					final Integer drill = Integer.parseInt(
							(r.getCell(drillIndex) == null || r.getCell(drillIndex).getStringCellValue().equals(""))
									? "0" : r.getCell(drillIndex).getStringCellValue().trim());
					final Integer zUpdCount = Integer.parseInt((r.getCell(zUpdCountIndex) == null
							|| r.getCell(zUpdCountIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(zUpdCountIndex).getStringCellValue().trim());
					final Integer zInsCount = Integer.parseInt((r.getCell(zInsCountIndex) == null
							|| r.getCell(zInsCountIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(zInsCountIndex).getStringCellValue().trim());
					final Integer zDelCount = Integer.parseInt((r.getCell(zDelCountIndex) == null
							|| r.getCell(zDelCountIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(zDelCountIndex).getStringCellValue().trim());
					final Integer bapiRead = Integer.parseInt((r.getCell(bapiReadIndex) == null
							|| r.getCell(bapiReadIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(bapiReadIndex).getStringCellValue().trim());

					final Integer tabSap = Integer.parseInt(
							(r.getCell(tabSapIndex2) == null || r.getCell(tabSapIndex2).getStringCellValue().equals(""))
									? "0" : r.getCell(tabSapIndex2).getStringCellValue().trim());
					final Integer tabCust = Integer.parseInt(
							(r.getCell(tabCustIndex) == null || r.getCell(tabCustIndex).getStringCellValue().equals(""))
									? "0" : r.getCell(tabCustIndex).getStringCellValue().trim());

					final Integer nativeIntf = Integer.parseInt((r.getCell(nativeIntfIndex2) == null
							|| r.getCell(nativeIntfIndex2).getStringCellValue().equals("")) ? "0"
									: r.getCell(nativeIntfIndex2).getStringCellValue().trim());
					final Integer dynproUse = Integer.parseInt((r.getCell(dynproUseIndex2) == null
							|| r.getCell(dynproUseIndex2).getStringCellValue().equals("")) ? "0"
									: r.getCell(dynproUseIndex2).getStringCellValue().trim());

					final String subcatDtl = (r.getCell(subcatDtlIndex) == null) ? ""
							: r.getCell(subcatDtlIndex).getStringCellValue().trim();
					final String subcatF = (r.getCell(subcatFIndex) == null) ? ""
							: r.getCell(subcatFIndex).getStringCellValue().trim();
					final String subcatI = (r.getCell(subcatIIndex) == null) ? ""
							: r.getCell(subcatIIndex).getStringCellValue().trim();
					final Integer viewCust = Integer.parseInt((r.getCell(viewCustIndex) == null
							|| r.getCell(viewCustIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(viewCustIndex).getStringCellValue().trim());
					final Integer viewSap = Integer.parseInt(
							(r.getCell(viewSapIndex) == null || r.getCell(viewSapIndex).getStringCellValue().equals(""))
									? "0" : r.getCell(viewSapIndex).getStringCellValue().trim());

					final Integer fmSap = Integer.parseInt(
							(r.getCell(fmSapIndex) == null || r.getCell(fmSapIndex).getStringCellValue().equals(""))
									? "0" : r.getCell(fmSapIndex).getStringCellValue().trim());
					final Integer fmCust = Integer.parseInt(
							(r.getCell(fmCustIndex) == null || r.getCell(fmCustIndex).getStringCellValue().equals(""))
									? "0" : r.getCell(fmCustIndex).getStringCellValue().trim());

					final ExtensionRules extensibilityRules = new ExtensionRules();

					final Integer sumOfCRUD = updCount + insCount + delCount + bapiCud;
					final Integer sumOfZCRUD = zUpdCount + zInsCount + zDelCount;

					extensibilityRules.setObject(object);
					extensibilityRules.setRicefCategory(category);
					extensibilityRules.setExtensibility(extensibility);
					extensibilityRules.setFileExt(fileExt);
					extensibilityRules.setVolume(volume);
					extensibilityRules.setFrequency(frequency);
					extensibilityRules.setSumOfCrud(sumOfCRUD);
					extensibilityRules.setSumOfZCRUD(sumOfZCRUD);
					extensibilityRules.setDrill(drill);
					extensibilityRules.setRicefDepd(ricefDep);
					extensibilityRules.setNativeIntf(nativeIntf);
					extensibilityRules.setDynproUse(dynproUse);
					extensibilityRules.setTabCust(tabCust);
					extensibilityRules.setTabSap(tabSap);
					extensibilityRules.setSubcatDtl(subcatDtl);
					extensibilityRules.setSubcatF(subcatF);
					extensibilityRules.setSubcatI(subcatI);
					extensibilityRules.setViewCust(viewCust);
					extensibilityRules.setViewSap(viewSap);
					extensibilityRules.setFmCust(fmCust);
					extensibilityRules.setFmSap(fmSap);
					extensibilityRules.setBapiRead(bapiRead);
					extRulesList.add(extensibilityRules);
				}
			}
			if (extRulesList != null && !extRulesList.isEmpty()) {
				hm.setExtRulesList(extRulesList);
			}
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
		IOUtils.closeQuietly(inputStream);
	}

	private void addMetaData(final String filePath, final long requestId, final HttpSession session)
			throws SQLException, FileNotFoundException {
		final File file = new File(filePath);
		final InputStream inputStream = new FileInputStream(file);
		final String fileName = file.getName();
		final List<MetaData> metaDataList = new ArrayList<MetaData>();
		try {
			final StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (final Row r : reader) {
				if (r.getRowNum() > 0) {
					final int objectIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Object").get(1));
					final int nameIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Obj.name").get(1));
					final int objDescIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Obj.Desc").get(1));
					final int intIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Interface").get(1));
					final int convIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Conversion").get(1));
					final int reportIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Report").get(1));
					final int formsIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Forms").get(1));
					final int workflowIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Workflow").get(1));
					final int enhancementIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE
							.get(requestId).get(fileName).get("Enhancement").get(1));

					final int fileExtIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("File.Ext").get(1));
					final int rfcIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Rfc").get(1));
					final int fmSapIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Fm.sap").get(1));
					final int fmCustIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Fm.cust").get(1));
					final int ricefDepIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Ricef.dep").get(1));

					final int tabSapIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Tab.sap").get(1));
					final int tabCustIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Tab.cust").get(1));
					final int selCountIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Sel.count").get(1));
					final int updCountIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Upd.count").get(1));
					final int insCountIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Ins.count").get(1));
					final int delCountIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Del.count").get(1));
					final int bapiCudIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Bapi.cud").get(1));
					final int drillIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Drill").get(1));
					final int bapiReadIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Bapi.read").get(1));

					final int zUpdCountIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("zUpd.count").get(1));
					final int zInsCountIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("zIns.count").get(1));
					final int zDelCountIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("zDel.count").get(1));
					final int zDrillIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("z.drill").get(1));

					final int subcatIIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Subcat.i").get(1));
					final int subcatCIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Subcat.c").get(1));
					final int subcatRIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Subcat.r").get(1));
					final int subcatFIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Subcat.f").get(1));
					final int subcatWIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Subcat.w").get(1));
					final int subcatDtlIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Subcat.dtl").get(1));

					final int tabSapNameIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Tabsap.name").get(1));
					final int authObjIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Auth.obj").get(1));
					final int nativeIntfIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Native.intf").get(1));
					final int dynproUseIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Dynpro.use").get(1));
					final int objPackageIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Obj.package").get(1));
					final int enhTcodeIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Enh.tcode").get(1));
					// final int orphanIndex =
					// Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Orphan").get(1));
					final int tabFieldIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Tab.field").get(1));
					final int entityCountIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE
							.get(requestId).get(fileName).get("Entity.count").get(1));
					final int viewCustIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("View.cust").get(1));
					final int viewSapIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("View.sap").get(1));

					final int commentsIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Comments").get(1));

					final int moduleScreenIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE
							.get(requestId).get(fileName).get("Module.Screen").get(1));
					final int enhImplIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Enh.Impl").get(1));

					final int subTypeIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Sub.type").get(1));
					final int packageDescIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE
							.get(requestId).get(fileName).get("package.info").get(1));

					final int appAreaIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Application.component").get(1));

					final int appAreaDescIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE
							.get(requestId).get(fileName).get("Apparea.description").get(1));

					final int modCountIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Mod.Count").get(1));

					final int zModCountIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("zMod.Count").get(1));

					final int descriptionIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE
							.get(requestId).get(fileName).get("Description").get(1));

					final int readProgIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Read.prog").get(1));

					final String object = (r.getCell(objectIndex) == null) ? ""
							: r.getCell(objectIndex).getStringCellValue().trim();
					final String objName = (r.getCell(nameIndex) == null) ? ""
							: r.getCell(nameIndex).getStringCellValue().trim();
					if (object.equals("") || objName.equals("")) {
						continue;
					}
					final String objDesc = (r.getCell(objDescIndex) == null) ? ""
							: r.getCell(objDescIndex).getStringCellValue().trim();

					final Integer interfaceValue = Integer.parseInt(
							(r.getCell(intIndex) == null || r.getCell(intIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(intIndex).getStringCellValue().trim());
					final Integer conversion = Integer.parseInt(
							(r.getCell(convIndex) == null || r.getCell(convIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(convIndex).getStringCellValue().trim());
					final Integer forms = Integer.parseInt(
							(r.getCell(formsIndex) == null || r.getCell(formsIndex).getStringCellValue().equals(""))
									? "0" : r.getCell(formsIndex).getStringCellValue().trim());
					final Integer workflow = Integer.parseInt((r.getCell(workflowIndex) == null
							|| r.getCell(workflowIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(workflowIndex).getStringCellValue().trim());
					final Integer reports = Integer.parseInt(
							(r.getCell(reportIndex) == null || r.getCell(reportIndex).getStringCellValue().equals(""))
									? "0" : r.getCell(reportIndex).getStringCellValue().trim());
					final Integer enhancement = Integer.parseInt((r.getCell(enhancementIndex) == null
							|| r.getCell(enhancementIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(enhancementIndex).getStringCellValue().trim());

					final Integer fileExt = Integer.parseInt(
							(r.getCell(fileExtIndex) == null || r.getCell(fileExtIndex).getStringCellValue().equals(""))
									? "0" : r.getCell(fileExtIndex).getStringCellValue().trim());
					final Integer rfc = Integer.parseInt(
							(r.getCell(rfcIndex) == null || r.getCell(rfcIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(rfcIndex).getStringCellValue().trim());
					final Integer ricefDep = Integer.parseInt((r.getCell(ricefDepIndex) == null
							|| r.getCell(ricefDepIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(ricefDepIndex).getStringCellValue().trim());

					final Integer tabSap = Integer.parseInt(
							(r.getCell(tabSapIndex) == null || r.getCell(tabSapIndex).getStringCellValue().equals(""))
									? "0" : r.getCell(tabSapIndex).getStringCellValue().trim());
					final Integer tabCust = Integer.parseInt(
							(r.getCell(tabCustIndex) == null || r.getCell(tabCustIndex).getStringCellValue().equals(""))
									? "0" : r.getCell(tabCustIndex).getStringCellValue().trim());
					final Integer fmSap = Integer.parseInt(
							(r.getCell(fmSapIndex) == null || r.getCell(fmSapIndex).getStringCellValue().equals(""))
									? "0" : r.getCell(fmSapIndex).getStringCellValue().trim());
					final Integer fmCust = Integer.parseInt(
							(r.getCell(fmCustIndex) == null || r.getCell(fmCustIndex).getStringCellValue().equals(""))
									? "0" : r.getCell(fmCustIndex).getStringCellValue().trim());

					final Integer selCount = Integer.parseInt((r.getCell(selCountIndex) == null
							|| r.getCell(selCountIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(selCountIndex).getStringCellValue().trim());
					final Integer updCount = Integer.parseInt((r.getCell(updCountIndex) == null
							|| r.getCell(updCountIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(updCountIndex).getStringCellValue().trim());
					final Integer insCount = Integer.parseInt((r.getCell(insCountIndex) == null
							|| r.getCell(insCountIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(insCountIndex).getStringCellValue().trim());
					final Integer delCount = Integer.parseInt((r.getCell(delCountIndex) == null
							|| r.getCell(delCountIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(delCountIndex).getStringCellValue().trim());
					final Integer bapiCud = Integer.parseInt(
							(r.getCell(bapiCudIndex) == null || r.getCell(bapiCudIndex).getStringCellValue().equals(""))
									? "0" : r.getCell(bapiCudIndex).getStringCellValue().trim());
					final Integer drill = Integer.parseInt(
							(r.getCell(drillIndex) == null || r.getCell(drillIndex).getStringCellValue().equals(""))
									? "0" : r.getCell(drillIndex).getStringCellValue().trim());

					final Integer zUpdCount = Integer.parseInt((r.getCell(zUpdCountIndex) == null
							|| r.getCell(zUpdCountIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(zUpdCountIndex).getStringCellValue().trim());
					final Integer zInsCount = Integer.parseInt((r.getCell(zInsCountIndex) == null
							|| r.getCell(zInsCountIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(zInsCountIndex).getStringCellValue().trim());
					final Integer zDelCount = Integer.parseInt((r.getCell(zDelCountIndex) == null
							|| r.getCell(zDelCountIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(zDelCountIndex).getStringCellValue().trim());
					final Integer zDrill = Integer.parseInt(
							(r.getCell(zDrillIndex) == null || r.getCell(zDrillIndex).getStringCellValue().equals(""))
									? "0" : r.getCell(zDrillIndex).getStringCellValue().trim());
					final Integer bapiRead = Integer.parseInt((r.getCell(bapiReadIndex) == null
							|| r.getCell(bapiReadIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(bapiReadIndex).getStringCellValue().trim());

					final Integer nativeIntf = Integer.parseInt((r.getCell(nativeIntfIndex) == null
							|| r.getCell(nativeIntfIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(nativeIntfIndex).getStringCellValue().trim());
					final Integer dynproUse = Integer.parseInt((r.getCell(dynproUseIndex) == null
							|| r.getCell(dynproUseIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(dynproUseIndex).getStringCellValue().trim());
					final String objPackage = (r.getCell(objPackageIndex) == null) ? ""
							: r.getCell(objPackageIndex).getStringCellValue().trim();

					final String subcatI = (r.getCell(subcatIIndex) == null) ? ""
							: r.getCell(subcatIIndex).getStringCellValue().trim();
					final String subcatC = (r.getCell(subcatCIndex) == null) ? ""
							: r.getCell(subcatCIndex).getStringCellValue().trim();
					final String subcatR = (r.getCell(subcatRIndex) == null) ? ""
							: r.getCell(subcatRIndex).getStringCellValue().trim();
					final String subcatF = (r.getCell(subcatFIndex) == null) ? ""
							: r.getCell(subcatFIndex).getStringCellValue().trim();
					final String subcatW = (r.getCell(subcatWIndex) == null) ? ""
							: r.getCell(subcatWIndex).getStringCellValue().trim();
					final String subcatDtl = (r.getCell(subcatDtlIndex) == null) ? ""
							: r.getCell(subcatDtlIndex).getStringCellValue().trim();

					final String tabSapName = (r.getCell(tabSapNameIndex) == null) ? ""
							: r.getCell(tabSapNameIndex).getStringCellValue().trim();
					final String authObj = (r.getCell(authObjIndex) == null) ? ""
							: r.getCell(authObjIndex).getStringCellValue().trim();

					final String enhTcode = (r.getCell(enhTcodeIndex) == null) ? ""
							: r.getCell(enhTcodeIndex).getStringCellValue().trim();
					// final String orphan = (r.getCell(orphanIndex) == null) ?
					// "" :
					// r.getCell(orphanIndex).getStringCellValue().trim();
					final Integer tabField = Integer.parseInt((r.getCell(tabFieldIndex) == null
							|| r.getCell(tabFieldIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(tabFieldIndex).getStringCellValue().trim());
					final Integer entityCount = Integer.parseInt((r.getCell(entityCountIndex) == null
							|| r.getCell(entityCountIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(entityCountIndex).getStringCellValue().trim());
					final Integer viewCust = Integer.parseInt((r.getCell(viewCustIndex) == null
							|| r.getCell(viewCustIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(viewCustIndex).getStringCellValue().trim());
					final Integer viewSap = Integer.parseInt(
							(r.getCell(viewSapIndex) == null || r.getCell(viewSapIndex).getStringCellValue().equals(""))
									? "0" : r.getCell(viewSapIndex).getStringCellValue().trim());
					final String comments = (r.getCell(commentsIndex) == null) ? ""
							: r.getCell(commentsIndex).getStringCellValue().trim();

					final Integer moduleScreen = Integer.parseInt((r.getCell(moduleScreenIndex) == null
							|| r.getCell(moduleScreenIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(moduleScreenIndex).getStringCellValue().trim());

					final Integer enhImpl = Integer.parseInt(
							(r.getCell(enhImplIndex) == null || r.getCell(enhImplIndex).getStringCellValue().equals(""))
									? "0" : r.getCell(enhImplIndex).getStringCellValue().trim());

					final String subType = (r.getCell(subTypeIndex) == null) ? ""
							: r.getCell(subTypeIndex).getStringCellValue().trim();

					final String packageDesc = (r.getCell(packageDescIndex) == null) ? ""
							: r.getCell(packageDescIndex).getStringCellValue().trim();

					final String appArea = (r.getCell(appAreaIndex) == null) ? ""
							: r.getCell(appAreaIndex).getStringCellValue().trim();

					final String appAreaDesc = (r.getCell(appAreaDescIndex) == null) ? ""
							: r.getCell(appAreaDescIndex).getStringCellValue().trim();

					final Integer modCount = Integer.parseInt((r.getCell(modCountIndex) == null
							|| r.getCell(modCountIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(modCountIndex).getStringCellValue().trim());

					final Integer zModCount = Integer.parseInt((r.getCell(zModCountIndex) == null
							|| r.getCell(zModCountIndex).getStringCellValue().equals("")) ? "0"
									: r.getCell(zModCountIndex).getStringCellValue().trim());

					final String description = (r.getCell(descriptionIndex) == null) ? ""
							: r.getCell(descriptionIndex).getStringCellValue().trim();

					final String readProg = (r.getCell(readProgIndex) == null) ? ""
							: r.getCell(readProgIndex).getStringCellValue().trim();

					final MetaData metaData = new MetaData();
					final Integer sumOfCRUD = updCount + insCount + delCount + bapiCud + modCount;
					final Integer sumOfZCRUD = zUpdCount + zInsCount + zDelCount + zModCount;

					Integer authObjCount = authObj.split(";").length;

					metaData.setObj(object);
					metaData.setObjName(objName);
					metaData.setRequestId(Long.valueOf(requestId));
					metaData.setInterfaceValue(interfaceValue);
					metaData.setForms(forms);
					metaData.setConversion(conversion);
					metaData.setWorkflow(workflow);
					metaData.setReports(reports);
					metaData.setEnhancement(enhancement);
					metaData.setTabSap(tabSap);
					metaData.setTabCust(tabCust);
					metaData.setFmSap(fmSap);
					metaData.setFmCust(fmCust);
					metaData.setFileExt(fileExt);
					metaData.setRfc(rfc);
					metaData.setRicefDepd(ricefDep);
					metaData.setSumOfCRUD(sumOfCRUD);
					metaData.setSumOfZCRUD(sumOfZCRUD);
					metaData.setSelCount(selCount);
					metaData.setDrill(drill);
					metaData.setzDrill(zDrill);
					metaData.setSubcatI(subcatI);
					metaData.setSubcatC(subcatC);
					metaData.setSubcatF(subcatF);
					metaData.setSubcatR(subcatR);
					metaData.setSubcatW(subcatW);
					metaData.setSubcatDtl(subcatDtl);
					metaData.setAuthObj(authObjCount);
					metaData.setTabSapName(tabSapName);
					metaData.setNativeIntf(nativeIntf);
					metaData.setDynproUse(dynproUse);
					metaData.setObjPackage(objPackage);
					metaData.setEnhTcode(enhTcode);
					metaData.setObjTypeName(object.trim() + objName.trim());
					// metaData.setOrphan(orphan);
					metaData.setTabField(tabField);
					metaData.setEntityCount(entityCount);
					metaData.setViewCust(viewCust);
					metaData.setViewSap(viewSap);
					metaData.setMetaDataComments(comments);
					metaData.setModuleScreen(moduleScreen);
					metaData.setEnhImpl(enhImpl);
					metaData.setSubType(subType);
					metaData.setBapiCud(bapiCud);
					metaData.setPackageDesc(packageDesc);
					metaData.setAppArea(appArea);
					metaData.setAppAreaDesc(appAreaDesc);
					metaData.setObjDesc(objDesc);
					metaData.setModCount(modCount);
					metaData.setDescription(description);
					metaData.setzModCount(zModCount);
					metaData.setReadProg(readProg);
					metaData.setBapiRead(bapiRead);
					metaDataList.add(metaData);
				}

				if (r.getRowNum() == 1) {
					final int descriptionIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE
							.get(requestId).get(fileName).get("Description").get(1));
					final String description = (r.getCell(descriptionIndex) == null) ? ""
							: r.getCell(descriptionIndex).getStringCellValue().trim();
					if (description != null && !description.isEmpty()) {
						hm.setMeteaDataDescription(description);
					}
				}
			}
			if (metaDataList != null && !metaDataList.isEmpty()) {
				hm.setMetaDataList(metaDataList);
			}
			// this.MetaDataBatchInsert(metaDataList, session);
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
		IOUtils.closeQuietly(inputStream);
	}

	private String MetaDataBatchInsert(final List<MetaData> metaDataList, final HttpSession session)
			throws SQLException {
		final String INSERT_SQL = "INSERT INTO META_DATA(OBJECT, OBJECT_NAME, INTERFACE, FORMS, WORKFLOW, REPORTS, CONVERSION, FILE_EXT, RICEF_DEPD,TAB_SAP, "
				+ "TAB_CUST, SEL_COUNT, SUM_CRUD,SUM_ZCRUD, DRILL,Z_DRILL, RFC, FM_SAP, FM_CUST, SUBCAT_I,SUBCAT_R,SUBCAT_F,SUBCAT_C,SUBCAT_W,SUBCAT_DTL,"
				+ "TAB_SAP_NAME,AUTH_OBJ, NATIVE_INTF, DYNPRO_USE, OBJ_PACKAGE,ENH_TCODE, ENHANCEMENT, TAB_FIELD,REQUEST_ID,OBJ_TYPE_NAME) values"
				+ " (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?, ?,?,?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {
			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;
				for (final MetaData metaData : metaDataList) {
					stmt.setString(1, metaData.getObj());
					stmt.setString(2, metaData.getObjName());
					stmt.setInt(3, metaData.getInterfaceValue());
					stmt.setInt(4, metaData.getForms());
					stmt.setInt(5, metaData.getWorkflow());
					stmt.setInt(6, metaData.getReports());
					stmt.setInt(7, metaData.getConversion());
					stmt.setInt(8, metaData.getFileExt());
					stmt.setInt(9, metaData.getRicefDepd());
					stmt.setInt(10, metaData.getTabSap());
					stmt.setInt(11, metaData.getTabCust());
					stmt.setInt(12, metaData.getSelCount());
					stmt.setInt(13, metaData.getSumOfCRUD());
					stmt.setInt(14, metaData.getSumOfZCRUD());
					stmt.setInt(15, metaData.getDrill());
					stmt.setInt(16, metaData.getzDrill());
					stmt.setInt(17, metaData.getRfc());
					stmt.setInt(18, metaData.getFmSap());
					stmt.setInt(19, metaData.getFmCust());
					stmt.setString(20, metaData.getSubcatI());
					stmt.setString(21, metaData.getSubcatR());
					stmt.setString(22, metaData.getSubcatF());
					stmt.setString(23, metaData.getSubcatC());
					stmt.setString(24, metaData.getSubcatW());
					stmt.setString(25, metaData.getSubcatDtl());
					stmt.setString(26, metaData.getTabSapName());
					stmt.setInt(27, metaData.getAuthObj());
					stmt.setInt(28, metaData.getNativeIntf());
					stmt.setInt(29, metaData.getDynproUse());
					stmt.setString(30, metaData.getObjPackage());
					stmt.setString(31, metaData.getEnhTcode());
					stmt.setInt(32, metaData.getEnhancement());
					stmt.setInt(33, metaData.getTabField());
					stmt.setLong(34, metaData.getRequestId());
					stmt.setString(35, metaData.getObjTypeName());
					stmt.addBatch();
					if (++counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + batch++ + " executed successfully");
					}
				}
				stmt.executeBatch();
				conn.commit();
				logger.info("META_DATA INSERTED SUCCESSFULLY");
			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e2) {
			result = "FAILURE in Getting Connection";
			logger.error(e2.getMessage());
			return result;
		} finally {
			stmt.close();
			conn.close();
		}
		stmt.close();
		conn.close();
		return result;
	}

	protected void addBwInventoryData(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException, SQLException {
		logger.debug("addBwInventoryData() - Start");
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);
		BwInventoryList bwInventory = null;

		List<BwInventoryList> bwInventoryList = new ArrayList<BwInventoryList>();

		String fileName = file.getName();
		logger.info("Inside Method addBwInventoryData Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int objTypeIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Package").trim());
					int objNameIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Object.Name").trim());
					int packageIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Package").trim());
					int proUseIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Profiler.Used").trim());

					String objType = row.getCell(objTypeIndex) == null ? ""
							: row.getCell(objTypeIndex).getStringCellValue().trim();
					String objName = row.getCell(objNameIndex) == null ? ""
							: row.getCell(objNameIndex).getStringCellValue().trim();
					String packageName = row.getCell(packageIndex) == null ? ""
							: row.getCell(packageIndex).getStringCellValue().trim();
					String proUse = row.getCell(proUseIndex) == null ? ""
							: row.getCell(proUseIndex).getStringCellValue().trim();

					bwInventory = new BwInventoryList();
					bwInventory.setObjType(objType);
					bwInventory.setObjName(objName);
					bwInventory.setPckg(packageName);
					bwInventory.setProfilersUsed(proUse);
					bwInventory.setRequestID((int) requestId);
					bwInventoryList.add(bwInventory);
				}
			}
			bwCleanDao.batchInsertionForBwInventory(bwInventoryList, session);
			logger.debug("addBwInventoryData() - End");
		} catch (Exception e) {
			logger.error("addBwInventoryData :: ", e);
			throw e;
		} finally {
			IOUtils.closeQuietly(inputStream);

		}
	}

	public static String bwCleanupUtilBatchInsertUpdate(List<BwCleanupUtil> bwCleanUpUtilList, HttpSession session)
			throws SQLException {

		final String INSERT_SQL = "INSERT INTO Bw_Cleanup_Util "
				+ "(Object_Type, Object_Name, Last_Used, Elapsed_Time_Year, Status,Request_ID) values (?, ?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (BwCleanupUtil bwCleanUtil : bwCleanUpUtilList) {
					stmt.setString(1, bwCleanUtil.getObjectType());
					stmt.setString(2, bwCleanUtil.getObjectName());
					stmt.setString(3, bwCleanUtil.getLastUsedDate());
					stmt.setString(4, bwCleanUtil.getElapsedTimInYrs());
					stmt.setString(5, bwCleanUtil.getStatus());
					stmt.setLong(6, bwCleanUtil.getRequestId());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("Bw_Cleanup_Util Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	public static String s4ImpactedCustomTablesBatchInsertUpdate(List<S4ImpactedCustomTables> s4ImpactedCustomTableList,
			HttpSession session) throws SQLException {

		final String INSERT_SQL = "INSERT INTO S4_Impacted_CustomTables "
				+ "(OBJ_NAME, OBJ_PACKAGE, COMMENTS, INFO, REQUEST_ID) values (?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (S4ImpactedCustomTables s4ImpactCustTable : s4ImpactedCustomTableList) {
					HashSet<String> myHashSet = new HashSet(500000); // Or a
																		// more
																		// realistic
																		// size
					StringTokenizer st = new StringTokenizer(s4ImpactCustTable.getInfo(), ",");
					while (st.hasMoreTokens()) {
						myHashSet.add(st.nextToken());
					}
					Iterator<String> it = myHashSet.iterator();
					stmt.setString(1, s4ImpactCustTable.getObjectName());
					stmt.setString(2, s4ImpactCustTable.getObjPackage());
					stmt.setString(3, s4ImpactCustTable.getComments().replace("IMPACTED FIELDS:", ""));
					stmt.setString(4, it.next());
					stmt.setLong(5, s4ImpactCustTable.getRequestId());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					while (it.hasNext()) {
						stmt.setNull(1, Types.NULL);
						stmt.setNull(2, Types.NULL);
						stmt.setNull(3, Types.NULL);
						stmt.setString(4, it.next());
						stmt.setLong(5, s4ImpactCustTable.getRequestId());
						stmt.addBatch();
						counter++;
					}
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("Bw_Cleanup_Util Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	protected List<InactiveObjects> createListforInactiveObjects(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException, SQLException {
		logger.debug("createListforInactiveObjects() - Start");
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);

		List<InactiveObjects> inactiveObjList = new ArrayList<InactiveObjects>();
		InactiveObjects inactive = null;
		String fileName = file.getName();
		logger.info("Inside Method createListforInactiveObjects Filename is" + fileName);
		try {

			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int objectIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("obj").get(1));
					int objNameIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("obj.name").get(1));
					int unameIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("uname").get(1));
					int deletFlgIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("delet.flag").get(1));
					int tabClsIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("delet.flag").get(1));

					String object = row.getCell(objectIndex) == null ? ""
							: row.getCell(objectIndex).getStringCellValue().trim();
					String objectName = row.getCell(objNameIndex) == null ? ""
							: row.getCell(objNameIndex).getStringCellValue().trim();
					String uName = row.getCell(unameIndex) == null ? ""
							: row.getCell(unameIndex).getStringCellValue().trim();
					String deletFlag = row.getCell(deletFlgIndex) == null ? ""
							: row.getCell(deletFlgIndex).getStringCellValue().trim();
					String tabCls = row.getCell(tabClsIndex) == null ? ""
							: row.getCell(tabClsIndex).getStringCellValue().trim();

					inactive = new InactiveObjects();
					inactive.setObject(object);
					inactive.setObjName(objectName);
					inactive.setUname(uName);
					inactive.setDeleteFlag(deletFlag);
					inactive.setRequestId(requestId);
					inactive.setTabCls(tabCls);
					inactiveObjList.add(inactive);

				}
			}
			if (null != inactiveObjList) {
				batchInsertForInactiveObjects(inactiveObjList, session, requestId);
			}
			logger.info("createListforUnicode() - End");
		} catch (Exception e) {
			logger.error("createListforUnicode :: ", e);
			throw e;
		} finally {
			IOUtils.closeQuietly(inputStream);

		}
		return inactiveObjList;
	}

	public String batchInsertForInactiveObjects(List<InactiveObjects> inactiveObjList, HttpSession session,
			Long requestID) throws SQLException {
		final String INSERT_SQL = "INSERT INTO Inactive_Objects "
				+ "(OBJECT, OBJ_NAME, UNAME, DELET_FLAG, Request_Id, TAB_CLASS) " + "values (?, ?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {
			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;
				for (InactiveObjects inaObj : inactiveObjList) {
					stmt.setString(1, inaObj.getObject());
					stmt.setString(2, inaObj.getObjName());
					stmt.setString(3, inaObj.getUname());
					stmt.setString(4, inaObj.getDeleteFlag());
					stmt.setLong(5, inaObj.getRequestId());
					stmt.setString(6, inaObj.getTabCls());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 1000 records
					if (counter % 1000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();

				logger.info("batchInsertForInactiveObjects Data INSERTED SUCCESSFULLY");
			} catch (Exception e) {
				result = "FAILURE in inserting data";
				logger.error("Error in batchInsertForInactiveObjects :: ", e);
			}

		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error("Error in batchInsertForInactiveObjects :: ", e);
		} finally {
			stmt.close();
			conn.close();
		}

		return result;
	}

	private void addBusinessProcessDetailData(final String filePath, final long requestId, final HttpSession session)
			throws FileNotFoundException {
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);
		String fileName = file.getName();
		List<BusinessProcessDetail> businessProcessDetailList = new ArrayList<>();
		BusinessProcessDetail businessProcessDetail = null;

		try {
			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row r : reader) {
				if (r.getRowNum() > 0) {
					int objectTypeIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Object.Type").get(1));
					int objectNameIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Object.Name").get(1));
					int descIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Description").get(1));
					int appCompIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Application.Component").get(1));
					int titleIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Title").get(1));
					int modLogIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Modification.Log").get(1));
					int rtrIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("RTR").get(1));
					int otcIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("OTC").get(1));
					int ptpIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("PTP").get(1));
					int htrIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("HTR").get(1));
					int s2dIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("S2D").get(1));
					int othersIndex = Integer.parseInt(
							S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Others").get(1));

					String objectType = (r.getCell(objectTypeIndex) == null) ? ""
							: r.getCell(objectTypeIndex).getStringCellValue().trim();
					String objectName = (r.getCell(objectNameIndex) == null) ? ""
							: r.getCell(objectNameIndex).getStringCellValue().trim();
					String description = (r.getCell(descIndex) == null) ? ""
							: r.getCell(descIndex).getStringCellValue().trim();
					String appComponent = (r.getCell(appCompIndex) == null) ? ""
							: r.getCell(appCompIndex).getStringCellValue().trim();
					String title = (r.getCell(titleIndex) == null) ? ""
							: r.getCell(titleIndex).getStringCellValue().trim();
					String modLog = (r.getCell(modLogIndex) == null) ? ""
							: r.getCell(modLogIndex).getStringCellValue().trim();
					String rtrValue = (r.getCell(rtrIndex) == null) ? ""
							: r.getCell(rtrIndex).getStringCellValue().trim();
					String otcValue = (r.getCell(otcIndex) == null) ? ""
							: r.getCell(otcIndex).getStringCellValue().trim();
					String ptpValue = (r.getCell(ptpIndex) == null) ? ""
							: r.getCell(ptpIndex).getStringCellValue().trim();
					String htrValue = (r.getCell(htrIndex) == null) ? ""
							: r.getCell(htrIndex).getStringCellValue().trim();
					String s2dValue = (r.getCell(s2dIndex) == null) ? ""
							: r.getCell(s2dIndex).getStringCellValue().trim();
					String othersValue = (r.getCell(othersIndex) == null) ? ""
							: r.getCell(othersIndex).getStringCellValue().trim();

					businessProcessDetail = new BusinessProcessDetail();
					businessProcessDetail.setObjectType(objectType);
					businessProcessDetail.setObjectName(objectName);
					businessProcessDetail.setObjNameType(objectType.concat(objectName));
					businessProcessDetail.setRtr(rtrValue);
					businessProcessDetail.setOtc(otcValue);
					businessProcessDetail.setPtp(ptpValue);
					businessProcessDetail.setHtr(htrValue);
					businessProcessDetail.setS2d(s2dValue);
					businessProcessDetail.setOthers(othersValue);
					businessProcessDetail.setFinalBusinessProcessCat("");
					businessProcessDetail.setRequestId(requestId);

					businessProcessDetailList.add(businessProcessDetail);
				}
			}

			testingScopeDao.businessPrcessDetInsert(session, businessProcessDetailList);
		} catch (Exception e) {
			logger.error("Error while reading Business Process Detail file : ", e);
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
	}

	private void addCustomReportData(final String filePath, final long requestId, final HttpSession session)
			throws SQLException, FileNotFoundException {
		logger.info("Inside addCustomReportData");
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);
		String fileName = file.getName();
		List<CustomReportOutput> customReportOutputList = new ArrayList<>();
		CustomReportOutput customReportOutput = null;
		try {
			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);
			for (Row r : reader) {
				if (r.getRowNum() > 0) {
					int technicalCatalogIdIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE
							.get(requestId).get(fileName).get("TechnicalCatalog.Id").get(1));
					int technicalCatalogTitleIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE
							.get(requestId).get(fileName).get("TechnicalCatalog.Title").get(1));
					int semanticObjectActionIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE
							.get(requestId).get(fileName).get("SemanticObject.Action").get(1));
					int launchpadApplicationTypeIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE
							.get(requestId).get(fileName).get("LaunchpadApplication.Type").get(1));
					int launchpadApplicationNameIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE
							.get(requestId).get(fileName).get("LaunchpadApplication.Name").get(1));
					int statusOfApplicationIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE
							.get(requestId).get(fileName).get("StatusOf.Application").get(1));
					int flagForCustomApplicationIndex = Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE
							.get(requestId).get(fileName).get("FlagFor.CustomApplication").get(1));

					String technicalCatalogId = (r.getCell(technicalCatalogIdIndex) == null) ? ""
							: r.getCell(technicalCatalogIdIndex).getStringCellValue().trim();
					String technicalCatalogTitle = (r.getCell(technicalCatalogTitleIndex) == null) ? ""
							: r.getCell(technicalCatalogTitleIndex).getStringCellValue().trim();
					String semanticObjectAction = (r.getCell(semanticObjectActionIndex) == null) ? ""
							: r.getCell(semanticObjectActionIndex).getStringCellValue().trim();
					String launchpadApplicationType = (r.getCell(launchpadApplicationTypeIndex) == null) ? ""
							: r.getCell(launchpadApplicationTypeIndex).getStringCellValue().trim();
					String launchpadApplicationName = (r.getCell(launchpadApplicationNameIndex) == null) ? ""
							: r.getCell(launchpadApplicationNameIndex).getStringCellValue().trim();
					String statusOfApplication = (r.getCell(statusOfApplicationIndex) == null) ? ""
							: r.getCell(statusOfApplicationIndex).getStringCellValue().trim();
					String flagForCustomApplication = (r.getCell(flagForCustomApplicationIndex) == null) ? ""
							: r.getCell(flagForCustomApplicationIndex).getStringCellValue().trim();
					String concat = technicalCatalogId + semanticObjectAction;

					customReportOutput = new CustomReportOutput();
					customReportOutput.setTechnicalCatalogId(technicalCatalogId);
					customReportOutput.setTechnicalcatalogtitle(technicalCatalogTitle);
					customReportOutput.setSemanticObjectAction(semanticObjectAction);
					customReportOutput.setLaunchpadApplicationType(launchpadApplicationType);
					customReportOutput.setLaunchpadApplicationName(launchpadApplicationName);
					customReportOutput.setStatusOfTheApplication(statusOfApplication);
					customReportOutput.setFlagForCustomApplication(flagForCustomApplication);
					customReportOutput.setConcat(concat);
					customReportOutput.setRequestID(requestId);
					customReportOutput.setFioriId("");
					customReportOutput.setSuccessorApp("");
					customReportOutput.setRelatedApp("");

					customReportOutputList.add(customReportOutput);

				}
			}
			if (customReportOutputList != null && !customReportOutputList.isEmpty()) {
				St03ReaderXlsx.setCustomReportOutputList(customReportOutputList);
			}
		} catch (Exception e) {
			logger.error("Error while reading Custom Report Output file : ", e);
		} finally {
			logger.info("addCustomReportData ended");
			IOUtils.closeQuietly(inputStream);
		}
	}

	public String insertCvitCustomLogs(List<CvitCustomisingLogs> cvitCustomLogsList, HttpSession session,
			Long requestId) throws SQLException {
		final String insertSql = "insert into Cvit_CustomisingLogs "
				+ "(Object_Name, Customising_Errors, Text, Customer_Count, Vendor_Count, Customer_Logs, Vendor_Logs, Request_Id) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;

		try {
			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(insertSql);
				int batch = 1;
				for (CvitCustomisingLogs obj : cvitCustomLogsList) {
					stmt.setString(1, obj.getObjectName());
					stmt.setString(2, obj.getCustomisingErrors());
					stmt.setString(3, obj.getText());
					stmt.setInt(4, obj.getCustomerCount());
					stmt.setInt(5, obj.getVendorCount());
					stmt.setString(6, obj.getCustomerLogs());
					stmt.setString(7, obj.getVendorLogs());
					stmt.setLong(8, obj.getRequestId());

					// Add statement to batch
					stmt.addBatch();
					counter++;

					// Execute batch of 1000 records
					if (counter % 1000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();

				logger.info("Batch for cvit customising logs data inserted successfully !!!");
			} catch (Exception e) {
				result = "FAILURE in inserting data";
				logger.error("Error in inserting batch for customising logs data :: ", e);
			}

		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error("Error in inserting batch for customising logs data :: ", e);
		} finally {
			stmt.close();
			conn.close();
		}

		return result;
	}

	public String insertCvitErrorMessagesList(List<CvitErrorMessages> cvitErrorMsgsList, HttpSession session,
			Long requestId) throws SQLException {
		final String insertSql = "insert into Cvit_ErrorMessages "
				+ "(Run_Id, Indicator, Customer_Vendor, Field_Name, Error_Log, Request_Id) "
				+ "values (?, ?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;

		try {
			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(insertSql);
				int batch = 1;
				for (CvitErrorMessages obj : cvitErrorMsgsList) {
					stmt.setString(1, obj.getRunId());
					stmt.setString(2, obj.getIndicator());
					stmt.setString(3, obj.getCustomerVendor());
					stmt.setString(4, obj.getFieldName());
					stmt.setString(5, obj.getErrorLog());
					stmt.setLong(6, obj.getRequestId());

					// Add statement to batch
					stmt.addBatch();
					counter++;

					// Execute batch of 1000 records
					if (counter % 1000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();

				logger.info("Batch for cvit error messages data inserted successfully !!!");
			} catch (Exception e) {
				result = "FAILURE in inserting data";
				logger.error("Error in inserting batch for cvit error messages data :: ", e);
			}

		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error("Error in inserting batch for cvit error messages data :: ", e);
		} finally {
			stmt.close();
			conn.close();
		}

		return result;
	}

}
