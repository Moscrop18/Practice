/*
 * 
 * CR-9.0:- Manual upload for Estimator & assuptions(Create new table in DB) -17/01/17 -monika.mishra
 * 
 * CR-13.0- New Output Sheet implementation - 03/03/2017 - monika.mishra
 * */

package com.accenture.displaygrid.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="HANA_ESTIMATOR")
public class HanaEstimator {
	
	/**
	 * 
	 */
	//private static final long serialVersionUID = -1664086921273798940L;
	@Id	
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "ID")
	private Integer Id;
	@Column(name = "Cust_FugrCount")
	private Integer CustFugrCount;
	
	
	@Column(name = "CustEnhanCount")
	private Integer CustEnhanCount;
	@Column(name = "CustWebCount")
	private Integer CustWebCount;
	@Column(name = "CustLsmwCount")
	private Integer CustLsmwCount;
	

	//CR:56-Adding New Estimation sheet
	@Column(name = "Cust_ProgCount")
	private Integer CustProgCount;
	@Column(name = "Cust_ClasCount")
	private Integer CustClasCount;
	@Column(name = "Cust_ExitCount")
	private Integer CustExitCount;
	@Column(name = "Cust_FormCount")
	private Integer CustFormCount;
	@Column(name = "DefectExitCount")
	private Integer DefectExitCount;
	@Column(name = "DefectFormCount")
	private Integer DefectFormCount;
	@Column(name = "DefectEnhanCount")
	private Integer DefectEnhanCount;
	@Column(name = "DefectWebCount")
	private Integer DefectWebCount;
	@Column(name = "DefectLsmwCount")
	private Integer DefectLsmwCount;
	@Column(name = "DefectFugrCount")
	private Integer DefectFugrCount;
	@Column(name = "Defect_ProgCount")
	private Integer DefectProgCount;
	@Column(name = "Defect_ClasCount")
	private Integer DefectClasCount;
	@Column(name = "migration_ManualCount")
	private Integer migrationManualCount;
	@Column(name = "migration_AutomatedCount")
	private Integer migrationAutomatedCount;
	@Column(name = "defectCount")
	private Integer defectCount;
	@Column(name = "Migration_Fix_Effort_Manual_Fixing_Count")
	private Integer Migration_Fix_Effort_Manual_Fixing_Count;
	@Column(name = "Used_Migration_Fix_Effort_Manual_Fixing_Count")
	private Integer Used_Migration_Fix_Effort_Manual_Fixing_Count;
	@Column(name = "CustUsedEnhanCount")
	private Integer CustUsedEnhanCount;
	@Column(name = "CustUsedFugrCount")
	private Integer CustUsedFugrCount;
	@Column(name = "CustUsedWebCount")
	private Integer CustUsedWebCount;
	@Column(name = "CustUsedLsmwCount")
	private Integer CustUsedLsmwCount;
	@Column(name = "CustUsed_ProgCount")
	private Integer CustUsedProgCount;
	@Column(name = "CustUsed_ClasCount")
	private Integer CustUsedClasCount;
	@Column(name = "CustUsed_ExitCount")
	private Integer CustUsedExitCount;
	@Column(name = "CustUsed_FormCount")
	private Integer CustUsedFormCount;
	@Column(name = "DefectUsedExitCount")
	private Integer DefectUsedExitCount;
	@Column(name = "DefectUsedFormCount")
	private Integer DefectUsedFormCount;
	@Column(name = "DefectUsedEnhanCount")
	private Integer DefectUsedEnhanCount;
	@Column(name = "DefectUsedWebCount")
	private Integer DefectUsedWebCount;
	@Column(name = "DefectUsedLsmwCount")
	private Integer DefectUsedLsmwCount;
	@Column(name = "DefectUsedFugrCount")
	private Integer DefectUsedFugrCount;
	@Column(name = "DefectUsed_ProgCount")
	private Integer DefectUsedProgCount;
	@Column(name = "DefectUsed_ClasCount")
	private Integer DefectUsedClasCount;
	


	@Column(name = "Request_ID",nullable=false,unique=true)
	private Long requestID;

	//CR-13.0 adding cols
	@Column(name = "migration_manualEfforts_hrs")
	private Integer migration_manualEfforts_hrs;
	
	@Column(name = "mgmt_estim_efforts_hrs")
	private Integer mgmt_estim_efforts_hrs;
	
	@Column(name = "res_TL_SSE",columnDefinition = "int default 0")
	private Integer res_TL_SSE;
	
	@Column(name = "res_SSE_SE",columnDefinition = "int default 0")
	private Integer res_SSE_SE;
	
	
	public Integer getId() {
		return Id;
	}



	public void setId(Integer id) {
		Id = id;
	}



	public Integer getCustFugrCount() {
		return CustFugrCount;
	}



	public void setCustFugrCount(Integer custFugrCount) {
		CustFugrCount = custFugrCount;
	}



	public Integer getCustProgCount() {
		return CustProgCount;
	}



	public void setCustProgCount(Integer custProgCount) {
		CustProgCount = custProgCount;
	}



	public Integer getCustClasCount() {
		return CustClasCount;
	}



	public void setCustClasCount(Integer custClasCount) {
		CustClasCount = custClasCount;
	}



	public Integer getCustExitCount() {
		return CustExitCount;
	}



	public void setCustExitCount(Integer CustExitCount) {
		CustExitCount = CustExitCount;
	}



	public Integer getCustFormCount() {
		return CustFormCount;
	}



	public void setCustFormCount(Integer custFormCount) {
		CustFormCount = custFormCount;
	}



	public Integer getCustEnhanCount() {
		return CustEnhanCount;
	}



	public void setCustEnhanCount(Integer custEnhanCount) {
		CustEnhanCount = custEnhanCount;
	}



	public Integer getCustWebCount() {
		return CustWebCount;
	}



	public void setCustWebCount(Integer custWebCount) {
		CustWebCount = custWebCount;
	}



	public Integer getCustLsmwCount() {
		return CustLsmwCount;
	}



	public void setCustLsmwCount(Integer custLsmwCount) {
		CustLsmwCount = custLsmwCount;
	}



	public Integer getDefectFugrCount() {
		return DefectFugrCount;
	}



	public void setDefectFugrCount(Integer defectFugrCount) {
		DefectFugrCount = defectFugrCount;
	}



	public Integer getDefectProgCount() {
		return DefectProgCount;
	}



	public void setDefectProgCount(Integer defectProgCount) {
		DefectProgCount = defectProgCount;
	}



	public Integer getDefectClasCount() {
		return DefectClasCount;
	}



	public void setDefectClasCount(Integer defectClasCount) {
		DefectClasCount = defectClasCount;
	}



	public Integer getMigrationManualCount() {
		return migrationManualCount;
	}



	public void setMigrationManualCount(Integer migrationManualCount) {
		this.migrationManualCount = migrationManualCount;
	}



	public Integer getMigrationAutomatedCount() {
		return migrationAutomatedCount;
	}



	public void setMigrationAutomatedCount(Integer migrationAutomatedCount) {
		this.migrationAutomatedCount = migrationAutomatedCount;
	}



	public Integer getDefectCount() {
		return defectCount;
	}



	public void setDefectCount(Integer defectCount) {
		this.defectCount = defectCount;
	}



	public Long getRequestID() {
		return requestID;
	}



	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}



	public Integer getMigration_manualEfforts_hrs() {
		return migration_manualEfforts_hrs;
	}



	public void setMigration_manualEfforts_hrs(Integer migration_manualEfforts_hrs) {
		this.migration_manualEfforts_hrs = migration_manualEfforts_hrs;
	}



	public Integer getMgmt_estim_efforts_hrs() {
		return mgmt_estim_efforts_hrs;
	}



	public void setMgmt_estim_efforts_hrs(Integer mgmt_estim_efforts_hrs) {
		this.mgmt_estim_efforts_hrs = mgmt_estim_efforts_hrs;
	}



	public Integer getRes_TL_SSE() {
		return res_TL_SSE;
	}



	public void setRes_TL_SSE(Integer res_TL_SSE) {
		this.res_TL_SSE = res_TL_SSE;
	}



	public Integer getRes_SSE_SE() {
		return res_SSE_SE;
	}



	public void setRes_SSE_SE(Integer res_SSE_SE) {
		this.res_SSE_SE = res_SSE_SE;
	}

	public Integer getDefectExitCount() {
		return DefectExitCount;
	}



	public void setDefectExitCount(Integer defectExitCount) {
		DefectExitCount = defectExitCount;
	}



	public Integer getDefectFormCount() {
		return DefectFormCount;
	}



	public void setDefectFormCount(Integer defectFormCount) {
		DefectFormCount = defectFormCount;
	}



	public Integer getDefectEnhanCount() {
		return DefectEnhanCount;
	}



	public void setDefectEnhanCount(Integer defectEnhanCount) {
		DefectEnhanCount = defectEnhanCount;
	}



	public Integer getDefectWebCount() {
		return DefectWebCount;
	}



	public void setDefectWebCount(Integer defectWebCount) {
		DefectWebCount = defectWebCount;
	}



	public Integer getDefectLsmwCount() {
		return DefectLsmwCount;
	}

	public void setDefectLsmwCount(Integer defectLsmwCount) {
		DefectLsmwCount = defectLsmwCount;
	}

	public Integer getMigration_Fix_Effort_Manual_Fixing_Count() {
		return Migration_Fix_Effort_Manual_Fixing_Count;
	}



	public void setMigration_Fix_Effort_Manual_Fixing_Count(Integer migration_Fix_Effort_Manual_Fixing_Count) {
		Migration_Fix_Effort_Manual_Fixing_Count = migration_Fix_Effort_Manual_Fixing_Count;
	}



	public Integer getUsed_Migration_Fix_Effort_Manual_Fixing_Count() {
		return Used_Migration_Fix_Effort_Manual_Fixing_Count;
	}



	public void setUsed_Migration_Fix_Effort_Manual_Fixing_Count(Integer used_Migration_Fix_Effort_Manual_Fixing_Count) {
		Used_Migration_Fix_Effort_Manual_Fixing_Count = used_Migration_Fix_Effort_Manual_Fixing_Count;
	}


	public Integer getCustUsedEnhanCount() {
		return CustUsedEnhanCount;
	}



	public void setCustUsedEnhanCount(Integer custUsedEnhanCount) {
		CustUsedEnhanCount = custUsedEnhanCount;
	}



	public Integer getCustUsedWebCount() {
		return CustUsedWebCount;
	}



	public void setCustUsedWebCount(Integer custUsedWebCount) {
		CustUsedWebCount = custUsedWebCount;
	}



	public Integer getCustUsedLsmwCount() {
		return CustUsedLsmwCount;
	}



	public void setCustUsedLsmwCount(Integer custUsedLsmwCount) {
		CustUsedLsmwCount = custUsedLsmwCount;
	}



	public Integer getCustUsedProgCount() {
		return CustUsedProgCount;
	}



	public void setCustUsedProgCount(Integer custUsedProgCount) {
		CustUsedProgCount = custUsedProgCount;
	}



	public Integer getCustUsedClasCount() {
		return CustUsedClasCount;
	}



	public void setCustUsedClasCount(Integer custUsedClasCount) {
		CustUsedClasCount = custUsedClasCount;
	}



	public Integer getCustUsedExitCount() {
		return CustUsedExitCount;
	}



	public void setCustUsedExitCount(Integer custUsedExitCount) {
		CustUsedExitCount = custUsedExitCount;
	}



	public Integer getCustUsedFormCount() {
		return CustUsedFormCount;
	}



	public void setCustUsedFormCount(Integer custUsedFormCount) {
		CustUsedFormCount = custUsedFormCount;
	}



	public Integer getDefectUsedExitCount() {
		return DefectUsedExitCount;
	}



	public void setDefectUsedExitCount(Integer defectUsedExitCount) {
		DefectUsedExitCount = defectUsedExitCount;
	}



	public Integer getDefectUsedFormCount() {
		return DefectUsedFormCount;
	}



	public void setDefectUsedFormCount(Integer defectUsedFormCount) {
		DefectUsedFormCount = defectUsedFormCount;
	}



	public Integer getDefectUsedEnhanCount() {
		return DefectUsedEnhanCount;
	}



	public void setDefectUsedEnhanCount(Integer defectUsedEnhanCount) {
		DefectUsedEnhanCount = defectUsedEnhanCount;
	}



	public Integer getDefectUsedWebCount() {
		return DefectUsedWebCount;
	}



	public void setDefectUsedWebCount(Integer defectUsedWebCount) {
		DefectUsedWebCount = defectUsedWebCount;
	}



	public Integer getDefectUsedLsmwCount() {
		return DefectUsedLsmwCount;
	}



	public void setDefectUsedLsmwCount(Integer defectUsedLsmwCount) {
		DefectUsedLsmwCount = defectUsedLsmwCount;
	}



	public Integer getDefectUsedFugrCount() {
		return DefectUsedFugrCount;
	}



	public void setDefectUsedFugrCount(Integer defectUsedFugrCount) {
		DefectUsedFugrCount = defectUsedFugrCount;
	}



	public Integer getDefectUsedProgCount() {
		return DefectUsedProgCount;
	}



	public void setDefectUsedProgCount(Integer defectUsedProgCount) {
		DefectUsedProgCount = defectUsedProgCount;
	}



	public Integer getDefectUsedClasCount() {
		return DefectUsedClasCount;
	}



	public void setDefectUsedClasCount(Integer defectUsedClasCount) {
		DefectUsedClasCount = defectUsedClasCount;
	}

	public Integer getCustUsedFugrCount() {
		return CustUsedFugrCount;
	}



	public void setCustUsedFugrCount(Integer custUsedFugrCount) {
		CustUsedFugrCount = custUsedFugrCount;
	}
	
	

}
