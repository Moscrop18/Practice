package com.accenture.displaygrid.model;

public class HanaProfile1 {
	private Long requestID;
	private String abc;

	public Long getRequestID() {
		return requestID;
	}

	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}

	public String getAbc() {
		return abc;
	}

	public void setAbc(String abc) {
		this.abc = abc;
	}

}
