/**
 * 
 * @author rohan.a.mehra
 * 
 */

package com.accenture.displaygrid.model;
import java.io.IOException;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.S4.dao.DisplayGraphS4DAOImpl;
import com.accenture.utility.CustomBasicDataSourceEncryptor;
import com.accenture.utility.HANAUtility;


public class DBConfig {

	 final public static Logger logger = LoggerFactory.getLogger(DisplayGraphS4DAOImpl.class);
	 // For all the class Generic code
	 public static java.sql.Connection getJDBCConnection(HttpSession session) {
			String jdbcUrl = null,username = null,password = null;
			
			String Filename=GetJdbcProperties(session);

			try {
				jdbcUrl  = HANAUtility.getPropertyValueEnv(Filename, "jdbcUrl");
				username = HANAUtility.getPropertyValueEnv(Filename, "username");
			    password = CustomBasicDataSourceEncryptor.decrypt(HANAUtility.getPropertyValueEnv(Filename, "password"));
			} catch (IOException e1) {
				logger.error("Error !!! " + e1);
			}
			java.sql.Connection conn = null;
			try {
				conn = DriverManager.getConnection(jdbcUrl, username, password);

			} catch (SQLException e) {
				logger.error("SQL Error occured while getting JDBC connection : " , e);
			} catch (Exception e) {
				logger.error("Error !!! " + e);
			}
			return conn;
		}
		
		//This function return the file name to the corresponding Environment
			public static String GetJdbcProperties(HttpSession session)  {
				
				String FileName=null;
				String Enviroment=(String) session.getAttribute("Enviroment");
				logger.info("::::::::::::::Enviroment--"+Enviroment);
				if (Enviroment.equals("tools-dev.accenture.com"))
				{
					FileName="DB_Dev.properties";
		     	}
				else if (Enviroment.equals("sapcodeanalyzer.myconcerto.accenture.com"))
				{
					FileName="DB_Prd.properties";
				}
				else if (Enviroment.equals("tools-stage.accenture.com"))
				{
					FileName="DB_Stage.properties";
				}
				else if (Enviroment.equals("localhost"))
				{
					FileName="DB_Localhost.properties";
		     	}
				logger.info("::::::::::::::File Name--"+FileName);		
				return FileName;	
			}
			
} 