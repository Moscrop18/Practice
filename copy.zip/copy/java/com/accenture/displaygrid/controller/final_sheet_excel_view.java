package com.accenture.displaygrid.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.accenture.constant.Hana_Profiler_Constant;
import com.accenture.displaygrid.model.HanaProfile;
import com.accenture.utility.HANAUtility;

public class final_sheet_excel_view extends AbstractExcelView {
/*@Value("${ExcelFileLabale}")
private String 	msg;*/
	/**
	 * @author j.patidar
	 * @see com.accenture.displaygrid.controller.buildExcelDocument()
	 * Create a Excel File
	 */
	
	//InputStream input = null;
	
	public final_sheet_excel_view(){
	
	//input = getClass().getClassLoader().getResourceAsStream(filename);
	}
	@Override
	protected void buildExcelDocument(Map model, HSSFWorkbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

//System.err.println("Properties File Value.................................."+this.msg);
		//Properties prop = new Properties();
		/*if (input == null) {
			System.out.println("Sorry, unable to find " + filename);
			return;
		}*/

		//prop.load(input);
		// get data model which is passed by the Spring container
		Map<String,String> propertyValueMap = HANAUtility.getAllPropertyValue(Hana_Profiler_Constant.EXCEL_CONVERSION_PROPERTY_FILE_NAME);
		List<HanaProfile> HanaList = (List<HanaProfile>) model.get("list");
		// create a new Excel sheet
		HSSFSheet excelSheet = workbook.createSheet(propertyValueMap.get("ExcelFileLabale"));
		excelSheet.setDefaultColumnWidth(Hana_Profiler_Constant.Hana_Column_Width);
		CellStyle style = workbook.createCellStyle();
		Font font = workbook.createFont();
		font.setFontName(propertyValueMap.get("Font_Type"));
		style.setFillForegroundColor(HSSFColor.BLUE.index);
		style.setFillPattern(CellStyle.SOLID_FOREGROUND);
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		font.setColor(HSSFColor.WHITE.index);
		style.setFont(font);
		

		// create header row
		HSSFRow excelHeader = excelSheet.createRow(Integer.parseInt(propertyValueMap.get("ExcelHeaderRow")));
		/*excelHeader.createCell(0).setCellValue("Id");
		excelHeader.getCell(0).setCellStyle(style);*/
		excelHeader.createCell(Integer.parseInt(propertyValueMap.get("Object_Type"))).setCellValue("Object_Type");
		excelHeader.getCell(Integer.parseInt(propertyValueMap.get("Object_Type"))).setCellStyle(style);
		excelHeader.createCell(Integer.parseInt(propertyValueMap.get("Obj_Name"))).setCellValue("Obj_Name");
		excelHeader.getCell(Integer.parseInt(propertyValueMap.get("Obj_Name"))).setCellStyle(style);
		
		excelHeader.createCell(Integer.parseInt(propertyValueMap.get("Sub_Program"))).setCellValue("Sub_Program");
		excelHeader.getCell(Integer.parseInt(propertyValueMap.get("Sub_Program"))).setCellStyle(style);
		excelHeader.createCell(Integer.parseInt(propertyValueMap.get("Used_Unused"))).setCellValue("Used_Unused");
		excelHeader.getCell(Integer.parseInt(propertyValueMap.get("Used_Unused"))).setCellStyle(style);
		//excelHeader.createCell(Integer.parseInt(propertyValueMap.get("Dialog_Steps"))).setCellValue("Dialog_Steps");
		//excelHeader.getCell(Integer.parseInt(propertyValueMap.get("Dialog_Steps"))).setCellStyle(style);
		excelHeader.createCell(Integer.parseInt(propertyValueMap.get("Keys"))).setCellValue("Keys");
		excelHeader.getCell(Integer.parseInt(propertyValueMap.get("Keys"))).setCellStyle(style);
		excelHeader.createCell(Integer.parseInt(propertyValueMap.get("Sub_Type"))).setCellValue("Sub_Type");
		excelHeader.getCell(Integer.parseInt(propertyValueMap.get("Sub_Type"))).setCellStyle(style);
		excelHeader.createCell(Integer.parseInt(propertyValueMap.get("Line_Number"))).setCellValue("Line_Number");
		excelHeader.getCell(Integer.parseInt(propertyValueMap.get("Line_Number"))).setCellStyle(style);
		excelHeader.createCell(Integer.parseInt(propertyValueMap.get("operation_code"))).setCellValue("operation_code");
		excelHeader.getCell(Integer.parseInt(propertyValueMap.get("operation_code"))).setCellStyle(style);
		excelHeader.createCell(Integer.parseInt(propertyValueMap.get("Category"))).setCellValue("Category");
		excelHeader.getCell(Integer.parseInt(propertyValueMap.get("Category"))).setCellStyle(style);
		excelHeader.createCell(Integer.parseInt(propertyValueMap.get("Subcategory"))).setCellValue("Subcategory");
		excelHeader.getCell(Integer.parseInt(propertyValueMap.get("Subcategory"))).setCellStyle(style);
		excelHeader.createCell(Integer.parseInt(propertyValueMap.get("Opertaion"))).setCellValue("Opertaion");
		excelHeader.getCell(Integer.parseInt(propertyValueMap.get("Opertaion"))).setCellStyle(style);
		excelHeader.createCell(Integer.parseInt(propertyValueMap.get("Levels"))).setCellValue("Levels");
		excelHeader.getCell(Integer.parseInt(propertyValueMap.get("Levels"))).setCellStyle(style);
		excelHeader.createCell(Integer.parseInt(propertyValueMap.get("Tables"))).setCellValue("Tables");
		excelHeader.getCell(Integer.parseInt(propertyValueMap.get("Tables"))).setCellStyle(style);
		excelHeader.createCell(Integer.parseInt(propertyValueMap.get("Joins"))).setCellValue("Joins");
		excelHeader.getCell(Integer.parseInt(propertyValueMap.get("Joins"))).setCellStyle(style);
		excelHeader.createCell(Integer.parseInt(propertyValueMap.get("Table_Type"))).setCellValue("Table_Type");
		excelHeader.getCell(Integer.parseInt(propertyValueMap.get("Table_Type"))).setCellStyle(style);
		excelHeader.createCell(Integer.parseInt(propertyValueMap.get("Keys"))).setCellValue("Keys");
		excelHeader.getCell(Integer.parseInt(propertyValueMap.get("Keys"))).setCellStyle(style);
		excelHeader.createCell(Integer.parseInt(propertyValueMap.get("Where_Condition"))).setCellValue("Where_Condition");
		excelHeader.getCell(Integer.parseInt(propertyValueMap.get("Where_Condition"))).setCellStyle(style);
		excelHeader.createCell(Integer.parseInt(propertyValueMap.get("Join_Type"))).setCellValue("Join_Type");
		excelHeader.getCell(Integer.parseInt(propertyValueMap.get("Join_Type"))).setCellStyle(style);
		excelHeader.createCell(Integer.parseInt(propertyValueMap.get("Info"))).setCellValue("Info");
		excelHeader.getCell(Integer.parseInt(propertyValueMap.get("Info"))).setCellStyle(style);
		excelHeader.createCell(Integer.parseInt(propertyValueMap.get("impact"))).setCellValue("impact");
		excelHeader.getCell(Integer.parseInt(propertyValueMap.get("impact"))).setCellStyle(style);
		excelHeader.createCell(Integer.parseInt(propertyValueMap.get("DB"))).setCellValue("DB");
		excelHeader.getCell(Integer.parseInt(propertyValueMap.get("DB"))).setCellStyle(style);
		excelHeader.createCell(Integer.parseInt(propertyValueMap.get("Change"))).setCellValue("Change");
		excelHeader.getCell(Integer.parseInt(propertyValueMap.get("Change"))).setCellStyle(style);

		int record = Integer.parseInt(propertyValueMap.get("record"));
		for (int i = 0; i < HanaList.size(); i++) {
			HanaProfile hanaProfile = HanaList.get(i);

			HSSFRow excelRow = excelSheet.createRow(record++);

			//excelRow.createCell(0).setCellValue(hanaProfile.getId());
			if (hanaProfile.getObject_Type() != null && !"".equals(hanaProfile.getObject_Type())) {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Object_Type"))).setCellValue(hanaProfile.getObject_Type());
			}

			else {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Object_Type"))).setCellValue("");
			}
			if (hanaProfile.getObj_Name() != null && !"".equals(hanaProfile.getObj_Name())) {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Obj_Name"))).setCellValue(hanaProfile.getObj_Name());
			} else {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Obj_Name"))).setCellValue("");
			}
			
			if (hanaProfile.getSub_Program() != null && !"".equals(hanaProfile.getSub_Program())) {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Sub_Program"))).setCellValue(hanaProfile.getSub_Program());
			}

			else {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Sub_Program"))).setCellValue("");
			}
			if (hanaProfile.getUsed_Unused() != null && !"".equals(hanaProfile.getUsed_Unused())) {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Used_Unused"))).setCellValue(hanaProfile.getUsed_Unused());
			}

			else {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Used_Unused"))).setCellValue("");
			}
			/*
			 * if (hanaProfile.getDialog_Steps() != null &&
			 * !"".equals(hanaProfile.getDialog_Steps())) {
			 * excelRow.createCell(Integer.parseInt(propertyValueMap.get("Dialog_Steps"))).
			 * setCellValue(hanaProfile.getDialog_Steps()); }
			 * 
			 * else {
			 * excelRow.createCell(Integer.parseInt(propertyValueMap.get("Dialog_Steps"))).
			 * setCellValue(""); }
			 */
			if (hanaProfile.getSub_Type() != null && !"".equals(hanaProfile.getSub_Type())) {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Sub_Type"))).setCellValue(hanaProfile.getSub_Type());
			} else {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Sub_Type"))).setCellValue("");
			}
			if (hanaProfile.getLine_Number() != null) {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Line_Number"))).setCellValue(hanaProfile.getLine_Number());
			} else {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Line_Number"))).setCellValue("");
			}
			if (hanaProfile.getOperation_code() != null && !"".equals(hanaProfile.getOperation_code())) {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("operation_code"))).setCellValue(hanaProfile.getOperation_code());
			} else {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("operation_code"))).setCellValue("");
			}
			if (hanaProfile.getCategory() != null && !"".equals(hanaProfile.getCategory())) {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Category"))).setCellValue(hanaProfile.getCategory());
			} else {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Category"))).setCellValue("");
			}
			if (hanaProfile.getSubcategory() != null && !"".equals(hanaProfile.getSubcategory())) {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Subcategory"))).setCellValue(hanaProfile.getSubcategory());
			} else {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Subcategory"))).setCellValue("");
			}
			if (hanaProfile.getOpertaion() != null && !"".equals(hanaProfile.getOpertaion())) {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Opertaion"))).setCellValue(hanaProfile.getOpertaion());
			} else {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Opertaion"))).setCellValue("");
			}
			if (hanaProfile.getLevels() != null) {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Levels"))).setCellValue(hanaProfile.getLevels());
			} else {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Levels"))).setCellValue("");
			}
			if (hanaProfile.getTables() != null && !"".equals(hanaProfile.getTables())) {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Tables"))).setCellValue(hanaProfile.getTables());
			} else {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Tables"))).setCellValue("");
			}
			if (hanaProfile.getJoins() != null && !"".equals(hanaProfile.getJoins())) {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Joins"))).setCellValue(hanaProfile.getJoins());
			} else {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Joins"))).setCellValue("");
			}
			if (hanaProfile.getTable_Type() != null && !"".equals(hanaProfile.getTable_Type())) {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Table_Type"))).setCellValue(hanaProfile.getTable_Type());
			} else {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Table_Type"))).setCellValue("");
			}
			if (hanaProfile.getKeys() != null && !"".equals(hanaProfile.getKeys())) {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Keys"))).setCellValue(hanaProfile.getKeys());
			} else {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Keys"))).setCellValue("");
			}
			if (hanaProfile.getWhere_Condition() != null && !"".equals(hanaProfile.getWhere_Condition())) {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Where_Condition"))).setCellValue(hanaProfile.getWhere_Condition());
			} else {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Where_Condition"))).setCellValue("");
			}
			if (hanaProfile.getJoin_Type() != null && !"".equals(hanaProfile.getJoin_Type())) {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Join_Type"))).setCellValue(hanaProfile.getJoin_Type());
			} else {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Join_Type"))).setCellValue("");
			}
			if (hanaProfile.getInfo() != null && !"".equals(hanaProfile.getInfo())) {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Info"))).setCellValue(hanaProfile.getInfo());
			} else {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Info"))).setCellValue("");
			}
			if (hanaProfile.getImpact() != null && !"".equals(hanaProfile.getImpact())) {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("impact"))).setCellValue(hanaProfile.getImpact());
			} else {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("impact"))).setCellValue("");
			}
			if (hanaProfile.getDB() != null && !"".equals(hanaProfile.getDB())) {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("DB"))).setCellValue(hanaProfile.getDB());
			} else {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("DB"))).setCellValue("");
			}
			if (hanaProfile.getChange() != null && !"".equals(hanaProfile.getChange())) {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Change"))).setCellValue(hanaProfile.getChange());
			} else {
				excelRow.createCell(Integer.parseInt(propertyValueMap.get("Change"))).setCellValue("");
			}

		}
	}
}
