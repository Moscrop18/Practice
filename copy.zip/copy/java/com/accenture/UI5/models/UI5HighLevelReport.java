package com.accenture.UI5.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

/**
 * @author rohan.a.mehra
 *
 */
@Entity
@Table(name = "UI5_REPORT")
public class UI5HighLevelReport implements Serializable {

	/**
	 * 
	 */

	@Id	
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "ID")
	private Integer Id;
	@Column(name = "ProjectName")
	private String projectName;
	@Column(name = "Total_API_Counts")
	private int totalApiCounts;
	@Column(name = "Depricated_API_Counts")
	private int depricatedApiCounts;
	@Column(name = "NonValid_API_Counts")
	private int nonValidApiCounts;
	@Column(name = "Recommented_Changes_API_Counts")
	private int recommendedChangesApiCounts;
	@Column(name = "Final_Message")
	private String finalMessage;
	
	
	
	@Column(name="REQUEST_ID")
	@Index(name="Index_Request_id")
	private long REQUEST_ID;
	
	
	
	public long getREQUEST_ID() {
		return REQUEST_ID;
	}
	public void setREQUEST_ID(long rEQUEST_ID) {
		REQUEST_ID = rEQUEST_ID;
	}
	/**
	 * @return the id
	 */
	public final Integer getId() {
		return Id;
	}
	/**
	 * @param id the id to set
	 */
	public final void setId(Integer id) {
		Id = id;
	}
	/**
	 * @return the projectName
	 */
	public final String getProjectName() {
		return projectName;
	}
	/**
	 * @param projectName the projectName to set
	 */
	public final void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	/**
	 * @return the totalApiCounts
	 */
	public final int getTotalApiCounts() {
		return totalApiCounts;
	}
	/**
	 * @param totalApiCounts the totalApiCounts to set
	 */
	public final void setTotalApiCounts(int totalApiCounts) {
		this.totalApiCounts = totalApiCounts;
	}
	/**
	 * @return the depricatedApiCounts
	 */
	public final int getDepricatedApiCounts() {
		return depricatedApiCounts;
	}
	/**
	 * @param depricatedApiCounts the depricatedApiCounts to set
	 */
	public final void setDepricatedApiCounts(int depricatedApiCounts) {
		this.depricatedApiCounts = depricatedApiCounts;
	}
	/**
	 * @return the nonValidApiCounts
	 */
	public final int getNonValidApiCounts() {
		return nonValidApiCounts;
	}
	/**
	 * @param nonValidApiCounts the nonValidApiCounts to set
	 */
	public final void setNonValidApiCounts(int nonValidApiCounts) {
		this.nonValidApiCounts = nonValidApiCounts;
	}
	/**
	 * @return the recommendedChangesApiCounts
	 */
	public final int getRecommendedChangesApiCounts() {
		return recommendedChangesApiCounts;
	}
	/**
	 * @param recommendedChangesApiCounts the recommendedChangesApiCounts to set
	 */
	public final void setRecommendedChangesApiCounts(int recommendedChangesApiCounts) {
		this.recommendedChangesApiCounts = recommendedChangesApiCounts;
	}
	/**
	 * @return the finalMessage
	 */
	public final String getFinalMessage() {
		return finalMessage;
	}
	/**
	 * @param finalMessage the finalMessage to set
	 */
	public final void setFinalMessage(String finalMessage) {
		this.finalMessage = finalMessage;
	}	
	
	}
