package com.accenture.UI5.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

/**
 * @author rohan.a.mehra
 *
 */
@Entity
@Table(name = "UI5_FINAL_OUTPUT")
public class UI5FinalOutput implements Serializable {


	private static final long serialVersionUID = -1664086921273798940L;
	@Id	
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "ID")
	private Integer Id;
	@Column(name = "UI_Element")
	private String uielemt;
	@Column(name = "Attribute")
	private String attribute;
	@Column(name = "Type")
	private String type;
	
	@Column(name = "Description" ,columnDefinition = "TEXT")
	private String description;
	@Column(name = "Version")
	private String version;
	@Column(name = "LineNumber")
	private int linenumber;
	@Column(name = "ProjectName")
	private String projectName;
	@Column(name = "FileName")
	private String filename;
	@Column(name = "Status")
	private String status;
	@Column(name = "Message")
	private String message;
	@Column(name = "Api_Reference")
	private String apireference;
	
	
	@Column(name="REQUEST_ID")
	@Index(name="Index_Request_id")
	private long REQUEST_ID;
	
	
	
	public long getREQUEST_ID() {
		return REQUEST_ID;
	}

	public void setREQUEST_ID(long rEQUEST_ID) {
		REQUEST_ID = rEQUEST_ID;
	}

	public final String getUielemt() {
		return uielemt;
	}

	public final void setUielemt(String uielemt) {
		this.uielemt = uielemt;
	}

	public final String getAttribute() {
		return attribute;
	}

	public final void setAttribute(String attribute) {
		this.attribute = attribute;
	}

	public final String getType() {
		return type;
	}

	public final void setType(String type) {
		this.type = type;
	}

	public final String getDescription() {
		return description;
	}

	public final void setDescription(String description) {
		this.description = description;
	}

	public final String getVersion() {
		return version;
	}

	public final void setVersion(String version) {
		this.version = version;
	}

	public final int getLinenumber() {
		return linenumber;
	}

	public final void setLinenumber(int linenumber) {
		this.linenumber = linenumber;
	}

	public final String getFilename() {
		return filename;
	}

	public final void setFilename(String filename) {
		this.filename = filename;
	}

	public final String getStatus() {
		return status;
	}

	public final void setStatus(String status) {
		this.status = status;
	}

	public final String getMessage() {
		return message;
	}

	public final void setMessage(String message) {
		this.message = message;
	}

	public final String getApireference() {
		return apireference;
	}

	public final void setApireference(String apireference) {
		this.apireference = apireference;
	}

	/**
	 * @return the projectName
	 */
	public final String getProjectName() {
		return projectName;
	}

	/**
	 * @param projectName the projectName to set
	 */
	public final void setProjectName(String projectName) {
		this.projectName = projectName;
	}	
	
	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
		Id = id;
	}


}
