package com.accenture.client.service;

import java.util.List;

import com.accenture.client.model.RequestForm;
import com.accenture.fileprocessing.model.ComplexityGraphRules;
import com.accenture.fileprocessing.model.ExtensibilityGraphRules;
import com.accenture.fileprocessing.model.MetaData;
import com.accenture.master.ExtensionScope;
import com.accenture.model.DRL.CodeAssessmentPayLoad;

public interface ExtensionService {
	
	public List<MetaData> findRicefCategory(CodeAssessmentPayLoad cPL, ExtensionScope extensionScope);
	
	public List<MetaData> calculateComplexity(CodeAssessmentPayLoad cPL, List<MetaData> metaDataListWithCategory, ExtensionScope extensionScope) ;
	
	public List<MetaData> findExtRecommendation(RequestForm requestForm, CodeAssessmentPayLoad cPL,List<MetaData> metaDataList, ExtensionScope extensionScope);

	public List<ComplexityGraphRules> getComplexityGraphRules();
	
	public List<ExtensibilityGraphRules> getExtensibilityGraphRules();
	
	public void setRicefComments(List<MetaData> metaDataList);
}
