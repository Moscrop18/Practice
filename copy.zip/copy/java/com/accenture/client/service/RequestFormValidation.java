package com.accenture.client.service;

import org.springframework.validation.Errors;

import com.accenture.client.model.RequestForm;
import com.accenture.utility.VersionValidation;

public class RequestFormValidation {

	VersionValidation versionValidation;
		
	public void setVersionValidation(VersionValidation versionValidation) {
		this.versionValidation = versionValidation;
	}

	public void validate(Object target, Errors errors) {
	    RequestForm requestForm = (RequestForm) target;
	   

	   
	    
	    String sourceVersion = requestForm.getSourceVersion();
	    String targetVersion = requestForm.getTargetVersion();
	    
	    String message=versionValidation.validation(sourceVersion, targetVersion);
	    
	    if (message != null ) 
	    {
	      errors.rejectValue("targetVersion",
	          "matchingsourceVersion.registration.targetVersion",
	          message);
	    }
	    
	    
	  }
}
