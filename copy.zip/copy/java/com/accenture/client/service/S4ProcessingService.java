package com.accenture.client.service;

import java.util.List;
import java.util.Map;

import com.accenture.S4.models.S4CvitAssessment;

public interface S4ProcessingService {
	
	public List<S4CvitAssessment> getS4CvitAssessment(long requestId);
	
	public Map<Integer, String> getS4CvitAssessmentMap(List<S4CvitAssessment> list);
}
