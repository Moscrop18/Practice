package com.accenture.client.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.accenture.Aadt.models.ImpactedCloneAnalysis;
import com.accenture.client.dao.ExtensibilityDao;
import com.accenture.client.model.RequestForm;
import com.accenture.constant.ST03HanaConstant;
import com.accenture.fileprocesing.dao.OdataFioriProcessDao;
import com.accenture.fileprocessing.model.ComplexityGraphRules;
import com.accenture.fileprocessing.model.ComplexityRules;
import com.accenture.fileprocessing.model.ExtensibilityGraphRules;
import com.accenture.fileprocessing.model.ExtensionFinder;
import com.accenture.fileprocessing.model.ExtensionRules;
import com.accenture.fileprocessing.model.MetaData;
import com.accenture.fileprocessing.model.UsageAnalysis;
import com.accenture.master.ExtensionScope;
import com.accenture.model.DRL.CodeAssessmentPayLoad;
import com.accenture.utility.odatafiori.AppsType;
import com.accenture.utility.odatafiori.TCodeStandardizationService;

@Service
public class ExtensionServiceImpl implements ExtensionService {

	protected static final Logger logger = LoggerFactory.getLogger(ExtensionServiceImpl.class);

	private ExtensibilityDao extensibilityDao;
	private OdataFioriProcessDao odataFioriProcessDao;
	private TCodeStandardizationService tcodeStandardizationService;
	
	private static Map<String, String> OdataExtMap = new HashMap<>();

	public OdataFioriProcessDao getOdataFioriProcessDao() {
		return odataFioriProcessDao;
	}

	@Autowired
	public void setOdataFioriProcessDao(OdataFioriProcessDao odataFioriProcessDao) {
		this.odataFioriProcessDao = odataFioriProcessDao;
	}

	public TCodeStandardizationService getTcodeStandardizationService() {
		return tcodeStandardizationService;
	}

	@Autowired
	public void setTcodeStandardizationService(TCodeStandardizationService tcodeStandardizationService) {
		this.tcodeStandardizationService = tcodeStandardizationService;
	}

	public ExtensibilityDao getExtensibilityDao() {
		return extensibilityDao;
	}

	@Autowired
	public void setExtensibilityDao(ExtensibilityDao extensibilityDao) {
		this.extensibilityDao = extensibilityDao;
	}

	public List<MetaData> findRicefCategory(CodeAssessmentPayLoad cPL, ExtensionScope extensionScope) {

		logger.info("...inside findRicefCategory...");

		List<MetaData> metaDataList = cPL.getMetaDataList();
		List<MetaData> metaDataWithCategory = new ArrayList<MetaData>();
		Map<String, MetaData> badiMap = new HashMap<>();
		Map<String, MetaData> enhoMap = new HashMap<>();
		Map<String, MetaData> enhcMap = new HashMap<>();

		Map<String, MetaData> metaMap = new HashMap<>();
		List<String> objectList = new ArrayList<>();
		
		for (MetaData metaData : metaDataList) {

			if(objectList.contains(metaData.getObj().trim() + metaData.getObjName().trim())) 
				continue;
			
			metaData.setRicefCategory("");
			metaData.setRicefCategory2("");
			metaData.setRicefCategory3("");
			metaData.setRicefSubCategory("");

			
			if (metaData.getObj().equalsIgnoreCase(ST03HanaConstant.INCL)||metaData.getObj().equalsIgnoreCase(ST03HanaConstant.CLAS)||
					metaData.getObj().equalsIgnoreCase(ST03HanaConstant.FUGS)||metaData.getObj().equalsIgnoreCase(ST03HanaConstant.FUGR)||
					metaData.getObj().equalsIgnoreCase(ST03HanaConstant.ODATA)||metaData.getObj().equalsIgnoreCase(ST03HanaConstant.CDS)) {
				metaData.setRicefCategory(ST03HanaConstant.OTHERS);
				if(metaData.getObj().equalsIgnoreCase(ST03HanaConstant.ODATA)) {
					metaData.setRicefSubCategory(ST03HanaConstant.ODATA);
					metaData.setObj(ST03HanaConstant.CLAS);
				}
			
			} else {

				List<String> categoryList = addCategoryByPriority(metaData);

				if (categoryList.size() > 0) {
					metaData.setRicefCategory(categoryList.get(0));
					if (categoryList.size() >= 2) {
						metaData.setRicefCategory2(categoryList.get(1));
						if (categoryList.size() >= 3) {
							metaData.setRicefCategory3(categoryList.get(2));
						}
					}
				} else {
					if (metaData.getObj().equalsIgnoreCase(ST03HanaConstant.PROG)) {
						if (metaData.getSubcatDtl().equalsIgnoreCase(ST03HanaConstant.NO_CODE_LINES)) {
								metaData.setRicefComments(metaData.getSubcatDtl());
						}else {
							metaData.setRicefCategory(ST03HanaConstant.REPORTS);
						}
					}
				}
				
			}
			findRicefSubCategory(metaData);
			
			if(StringUtils.isNotEmpty(metaData.getDescription())) {
				
				String[] descArr = metaData.getDescription().split(";");
				if(descArr.length>=2) {
					metaData.setCommentedLines(descArr[0].split("_")[0]);
					metaData.setExeLines(descArr[1].split("_")[0]);
				}	
			}
			
			//For other scopes
			MetaData metaObj = new MetaData();
			metaObj.setObj(metaData.getObj());
			metaObj.setObjName(metaData.getObjName());
			metaObj.setObjTypeName(metaData.getObjTypeName());
			metaObj.setRicefCategory(metaData.getRicefCategory());
			metaObj.setRicefSubCategory(metaData.getRicefSubCategory());
			// create a new oject and set ricef cateory for INCL and Module pool -
			// Category(other-MP/other-INCL)
			if (ST03HanaConstant.MODULE_POOL.equalsIgnoreCase(metaData.getObj())) {
				metaObj.setRicefCategory(ST03HanaConstant.OTHERS);
				metaObj.setRicefSubCategory(metaData.getRicefCategory());
				// set obj type = PROG in newly created object also for MP and INCL.
			}
			if (ST03HanaConstant.MODULE_POOL.equalsIgnoreCase(metaData.getObj())
					|| ST03HanaConstant.INCL.equalsIgnoreCase(metaData.getObj())) {
				metaData.setObj(ST03HanaConstant.PROG);
			}
			metaMap.put(metaData.getObj().trim() + metaData.getObjName().trim(), metaObj);
			
			if((metaData.getObj().equalsIgnoreCase(ST03HanaConstant.CLAS) && metaData.getRicefSubCategory().equals(ST03HanaConstant.CLAS))
					|| metaData.getObj().equalsIgnoreCase(ST03HanaConstant.FUGR)
					|| metaData.getObj().equalsIgnoreCase(ST03HanaConstant.FUGS) 
					|| metaData.getMetaDataComments().equalsIgnoreCase(ST03HanaConstant.SSF_TEXT_MODULE)){
						continue;
					}
			if(metaData.getObj().equalsIgnoreCase("BADI")) {
				badiMap.put(metaData.getObjName(),metaData);
			}
			else if(metaData.getObj().equalsIgnoreCase("ENHO")) {
				enhoMap.put(metaData.getObjName(), metaData);
			}else if(metaData.getObj().equalsIgnoreCase("ENHC")) {
				enhcMap.put(metaData.getObjName(), metaData);
			}else {
				metaDataWithCategory.add(metaData);
			}
			
			objectList.add(metaData.getObj().trim() + metaData.getObjName().trim());
		}
		
		cPL.setMetaDataMap(metaMap);
		
		//removing duplicate enho objects for EOF report
		removeDuplicates(badiMap, enhoMap);
		removeDuplicates(enhoMap, enhcMap);
		
		metaDataWithCategory.addAll(badiMap.values());
		metaDataWithCategory.addAll(enhoMap.values());
		metaDataWithCategory.addAll(enhcMap.values());
		
		
		
		setTotalObjsCount(metaDataWithCategory.size(), extensionScope);
		if (cPL.getMeteaDataDescription() != null
				&& cPL.getMeteaDataDescription().contains(ST03HanaConstant.RICEFW)) {
			Map<String, List<MetaData>> metaDataMap = separateMetaDataForGraphs(metaDataWithCategory);
			setRicefCount(metaDataMap, extensionScope);
			extensionScope.setRicefFlag(ST03HanaConstant.RICEFW);
		}

		return metaDataWithCategory;

	}

	private void removeDuplicates(Map<String, MetaData> map1, Map<String,MetaData> map2) {
		
		for(Map.Entry<String, MetaData> entrySet: map1.entrySet()) {
			String objName = entrySet.getKey();
			if(map2.containsKey(objName)) {
				map2.remove(objName);
			}
		}
	}
	
	
	
	private void findRicefSubCategory(MetaData metaData) {
		
		if(metaData.getObj().equalsIgnoreCase(ST03HanaConstant.INCL)) {
			metaData.setRicefSubCategory(ST03HanaConstant.INCLUDE);	
		}
		else if(metaData.getObj().equalsIgnoreCase(ST03HanaConstant.CDS)) {
			metaData.setRicefSubCategory(ST03HanaConstant.CDS);
		}
		else if(metaData.getObj().equalsIgnoreCase(ST03HanaConstant.CLAS) 
				&& metaData.getRicefSubCategory().equals("")) {
			metaData.setRicefSubCategory(ST03HanaConstant.CLAS);
		}else if(metaData.getObj().equalsIgnoreCase(ST03HanaConstant.FUGR)) {
			metaData.setRicefSubCategory(ST03HanaConstant.FUGR);
		}
		else if(metaData.getObj().equalsIgnoreCase(ST03HanaConstant.FUGS)) {
			metaData.setRicefSubCategory(ST03HanaConstant.FUGS);
		}
		else if(metaData.getObj().equalsIgnoreCase(ST03HanaConstant.AQQU)) {
			metaData.setRicefSubCategory(ST03HanaConstant.CONFIGURABLE_REPORT);
		}
		else if (metaData.getRicefCategory().equalsIgnoreCase(ST03HanaConstant.REPORTS)) {
			if(metaData.getSubcatR().contains(ST03HanaConstant.INTERACTIVE)) {
				metaData.setRicefSubCategory(ST03HanaConstant.INTERACTIVE_REPORT);
			}
			else if (metaData.getSumOfCRUD() == 0) {
				metaData.setRicefSubCategory(ST03HanaConstant.ANALYTICAL_REPORT);
			} else {
				metaData.setRicefSubCategory(ST03HanaConstant.TRANSACTIONAL_REPORT);
			}
		} else if (metaData.getRicefCategory().equalsIgnoreCase(ST03HanaConstant.FORMS)
				&& metaData.getObj().equalsIgnoreCase(ST03HanaConstant.PROG)) {
			String subcatF = metaData.getSubcatF().split(";")[0];
			if(subcatF.contains("SMART")) {
				subcatF = subcatF.replace("SMART", "SMARTFORMS");
			}
			metaData.setRicefSubCategory(subcatF);

		}
		else if (metaData.getRicefCategory().equalsIgnoreCase(ST03HanaConstant.FORMS)
				|| (metaData.getRicefCategory().equalsIgnoreCase(ST03HanaConstant.CONVERSION)
						&& metaData.getObj().equalsIgnoreCase(ST03HanaConstant.LSMW))) {
			
			metaData.setRicefSubCategory(metaData.getMetaDataComments());
		
		}else if(metaData.getRicefCategory().equalsIgnoreCase(ST03HanaConstant.ENHANCEMENT) ){
			
			if(metaData.getObj().equalsIgnoreCase("BADI")){
				metaData.setRicefSubCategory(metaData.getMetaDataComments().split(";")[0]);
			}else {
				metaData.setRicefSubCategory(metaData.getMetaDataComments());
			}
			
		}else if (metaData.getRicefCategory().equalsIgnoreCase(ST03HanaConstant.CONVERSION)
				&& metaData.getObj().equalsIgnoreCase(ST03HanaConstant.PROG)) {
			metaData.setRicefSubCategory(metaData.getSubcatC());

		} else if (metaData.getRicefCategory().equalsIgnoreCase(ST03HanaConstant.INTERFACE)
				&& metaData.getObj().equalsIgnoreCase(ST03HanaConstant.PROG)) {
			String subCatI = metaData.getSubcatI();
			if(subCatI.contains(ST03HanaConstant.FILE)) {
				subCatI = subCatI.replace(ST03HanaConstant.FILE, "FILE INTERFACE");
			}
			metaData.setRicefSubCategory(subCatI);
			

		}else if (metaData.getRicefCategory().equalsIgnoreCase(ST03HanaConstant.WORKFLOW)) {
			metaData.setRicefSubCategory(metaData.getSubcatW());
		}
		else if (metaData.getRicefCategory().equalsIgnoreCase(ST03HanaConstant.UI5)) {
			if(metaData.getMetaDataComments().equalsIgnoreCase(ST03HanaConstant.SMART_BASED)) {
				metaData.setRicefSubCategory(ST03HanaConstant.SMART_BASED);
			}else {
				metaData.setRicefSubCategory(ST03HanaConstant.FREE_STYLE);
			}
			
		}
	}

	private List<String> addCategoryByPriority(MetaData metaData) {

		List<String> categoryList = new ArrayList<String>();
		if(metaData.getObj().equalsIgnoreCase(ST03HanaConstant.AQQU)) {
			metaData.setRicefCategory(ST03HanaConstant.REPORTS);
		}
		if(metaData.getObj().equalsIgnoreCase(ST03HanaConstant.MODULE_POOL)){
			categoryList.add(ST03HanaConstant.CLASSICAL_DYNPRO);
		}
		if(metaData.getObj().equalsIgnoreCase(ST03HanaConstant.UI5)){
			categoryList.add(ST03HanaConstant.UI5);
		}
		if(metaData.getObj().equalsIgnoreCase(ST03HanaConstant.SSFO) || metaData.getObj().equalsIgnoreCase(ST03HanaConstant.SFPF)){
			categoryList.add(ST03HanaConstant.FORMS);
		}
		if (metaData.getEnhancement() > 0) {
			categoryList.add(ST03HanaConstant.ENHANCEMENT);
		}
		if (metaData.getWorkflow() > 0) {
			categoryList.add(ST03HanaConstant.WORKFLOW);
		}
		
		if (metaData.getInterfaceValue() > 0) {
			categoryList.add(ST03HanaConstant.INTERFACE);
		}
		if (metaData.getConversion() > 0) {
			categoryList.add(ST03HanaConstant.CONVERSION);
		}
		if (metaData.getForms() > 0) {
			if(!categoryList.contains(ST03HanaConstant.FORMS)) {
				categoryList.add(ST03HanaConstant.FORMS);
			}	
		}
		if (metaData.getReports() > 0) {
			if(!categoryList.contains(ST03HanaConstant.REPORTS)) {
				categoryList.add(ST03HanaConstant.REPORTS);
		}
			
		}
		return categoryList;
	}

	private HashMap<String, Integer> sortMapByCategory(Map<String, Integer> categoryMap) {

		HashMap<String,Integer> sortedMap =
        		categoryMap.entrySet().stream()
				.sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
        	       .collect(Collectors.toMap(
        	          Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));
		return sortedMap;
	}

	public List<MetaData> calculateComplexity(CodeAssessmentPayLoad cPL, List<MetaData> metaDataListWithCategory,
			ExtensionScope extensionScope) {

		logger.info("...inside calculateComplexity...");

		List<ComplexityRules> complexityRulesList = cPL.getComplexityRulesList();
		List<MetaData> metaDataWithComplexity = new ArrayList<MetaData>();
		Map<String, List<ComplexityRules>> complexityMap = null;
		// map rules based on category
		if (complexityRulesList != null && !complexityRulesList.isEmpty()) {
			complexityMap = separateComplexityRules(complexityRulesList);
		}

		Map<String, List<MetaData>> metaDataMap = separateMetaData(metaDataListWithCategory);
		
		if(complexityMap!=null && complexityMap.size()>0){

			List<MetaData> reportsComplexityList = calculateComplexityForReports(
					metaDataMap.get(ST03HanaConstant.REPORTS), complexityMap.get(ST03HanaConstant.REPORTS));
			List<MetaData> formsComplexityList = calculateComplexityForForms(metaDataMap.get(ST03HanaConstant.FORMS),
					complexityMap.get(ST03HanaConstant.FORMS));
			List<MetaData> interfaceComplexityList = calculateComplexityForInterface(
					metaDataMap.get(ST03HanaConstant.INTERFACE), complexityMap.get(ST03HanaConstant.INTERFACE));
			List<MetaData> conversionComplexityList = calculateComplexityForConversion(
					metaDataMap.get(ST03HanaConstant.CONVERSION), complexityMap.get(ST03HanaConstant.CONVERSION));
			List<MetaData> workflowComplexityList = calculateComplexityForWorkflow(
					metaDataMap.get(ST03HanaConstant.WORKFLOW), complexityMap.get(ST03HanaConstant.WORKFLOW));
			List<MetaData> enhancementComplexityList = calculateComplexityForEnhancement(
					metaDataMap.get(ST03HanaConstant.ENHANCEMENT), complexityMap.get(ST03HanaConstant.ENHANCEMENT));
			List<MetaData> oDataComplexityList = calculateComplexityForOdata(metaDataMap.get(ST03HanaConstant.ODATA),
					complexityMap.get(ST03HanaConstant.ODATA));
			List<MetaData> cdsComplexityList = calculateComplexityForCds(metaDataMap.get(ST03HanaConstant.CDS),
					complexityMap.get(ST03HanaConstant.CDS));
			List<MetaData> modulePoolComplexityList = calculateComplexityForModulePool(metaDataMap.get(ST03HanaConstant.CLASSICAL_DYNPRO),
					complexityMap.get(ST03HanaConstant.CLASSICAL_DYNPRO));
			List<MetaData> Ui5FreeStyleComplexityList = calculateComplexityForFreeStyleUI5(
					metaDataMap.get(ST03HanaConstant.FREE_STYLE), complexityMap.get(ST03HanaConstant.FREE_STYLE));
			List<MetaData> Ui5SmartBasedComplexityList = calculateComplexityForSmartBasedUI5(
					metaDataMap.get(ST03HanaConstant.SMART_BASED), complexityMap.get(ST03HanaConstant.SMART_BASED));
			
			List<MetaData> noCategoryComplexityList = complexityForNoCategory(metaDataMap.get(""));
			List<MetaData> othersComplexityList = metaDataMap.get(ST03HanaConstant.OTHERS);
			
			
			/*
			 * List<MetaData> othersComplexityList = new ArrayList<>();
			 * 
			 * if(othersList!=null && !othersList.isEmpty()) { for(MetaData metaData:
			 * othersList) { if(metaData.getObj().equalsIgnoreCase(ST03HanaConstant.CLAS) ||
			 * metaData.getObj().equalsIgnoreCase(ST03HanaConstant.FUGR)||
			 * metaData.getObj().equalsIgnoreCase(ST03HanaConstant.FUGS)){ continue; }else {
			 * othersComplexityList.add(metaData); } } }
			 */

			othersComplexityList = complexityForOthers(othersComplexityList);
			if (reportsComplexityList != null) {
				metaDataWithComplexity.addAll(reportsComplexityList);
			}
			if (formsComplexityList != null) {
				metaDataWithComplexity.addAll(formsComplexityList);
			}
			if (interfaceComplexityList != null) {
				metaDataWithComplexity.addAll(interfaceComplexityList);
			}
			if (conversionComplexityList != null) {
				metaDataWithComplexity.addAll(conversionComplexityList);
			}
			if (workflowComplexityList != null) {
				metaDataWithComplexity.addAll(workflowComplexityList);
			}
			if (enhancementComplexityList != null) {
				metaDataWithComplexity.addAll(enhancementComplexityList);
			}
			if (oDataComplexityList != null) {
				metaDataWithComplexity.addAll(oDataComplexityList);
			}
			if (cdsComplexityList != null) {
				metaDataWithComplexity.addAll(cdsComplexityList);
			}
			if (modulePoolComplexityList != null) {
				metaDataWithComplexity.addAll(modulePoolComplexityList);
			}
			if (noCategoryComplexityList != null) {
				metaDataWithComplexity.addAll(noCategoryComplexityList);
			}
			if (othersComplexityList != null) {
				metaDataWithComplexity.addAll(othersComplexityList);
			}
			if (Ui5FreeStyleComplexityList != null) {
				metaDataWithComplexity.addAll(Ui5FreeStyleComplexityList);
			}
			if (Ui5SmartBasedComplexityList != null) {
				metaDataWithComplexity.addAll(Ui5SmartBasedComplexityList);
			}
			setRicefCount(separateMetaDataForGraphs(metaDataListWithCategory), extensionScope);
			setComplexityCount(metaDataWithComplexity, extensionScope);
		}

		return metaDataWithComplexity;
	}


	private void setComplexityCount(List<MetaData> metaDataWithComplexity, ExtensionScope extensionScope) {
		Map<String, Integer> complexityCountMap = new HashMap<>();
		for (MetaData metaData : metaDataWithComplexity) {
			if (ST03HanaConstant.CAT_LIST.contains(metaData.getRicefCategory())) {

				if (!metaData.getComplexity().equals("")) {

					if (complexityCountMap.containsKey(metaData.getComplexity())) {
						Integer count = complexityCountMap.get(metaData.getComplexity());
						complexityCountMap.put(metaData.getComplexity(), count + 1);
					} else {
						complexityCountMap.put(metaData.getComplexity(), 1);
					}

				}
			}

		}

		StringBuffer complexityCount = new StringBuffer();

		for (Entry<String, Integer> ricefMap : complexityCountMap.entrySet()) {
			String complexity = ricefMap.getKey();
			Integer count = ricefMap.getValue();
			complexityCount.append(complexity).append(":").append(count).append("|");
		}
		extensionScope.setTotalComplexityCount(complexityCount.toString());

	}

	private void setRicefCount(Map<String, List<MetaData>> metaDataMap, ExtensionScope extensionScope) {

		StringBuffer ricefCount = new StringBuffer();
		StringBuffer othersRicefCount = new StringBuffer();

		for (Entry<String, List<MetaData>> ricefMap : metaDataMap.entrySet()) {
			String category = ricefMap.getKey();
			Integer count = ricefMap.getValue().size();

			if (ST03HanaConstant.CAT_LIST.contains(category)) {
				ricefCount.append(category).append(":").append(count).append("|");
			} else if(category.equals("")){
					category = "Uncategorized";
					othersRicefCount.append(category).append(":").append(count).append("|");
				} else {
					othersRicefCount.append(category).append(":").append(count).append("|");
				}
			}
			extensionScope.setTotalRicefCount(ricefCount.toString());
			extensionScope.setOthersRicefCount(othersRicefCount.toString());

		}

	private void setTotalObjsCount(Integer size, ExtensionScope extensionScope) {
		StringBuffer objCount = new StringBuffer();
		objCount.append("Total Custom Inventory").append(":").append(size).append("|");

		extensionScope.setTotalObjsCount(objCount.toString());

	}

	public void setRicefComments(List<MetaData> metaDataList) {
		
		for(MetaData metaData:metaDataList) {
			
			if(metaData.getObj().equalsIgnoreCase("BADI")) {
				if(StringUtils.isNotEmpty(metaData.getSubType())){
					if(StringUtils.isNotEmpty(metaData.getRicefComments())) {
						String ricefComments=metaData.getRicefComments();
						
						metaData.setRicefComments(ricefComments+", "+"BADI Name -> "+metaData.getSubType());
					}else {
						metaData.setRicefComments("BADI Name -> "+metaData.getSubType());
					}
					
					if(metaData.getMetaDataComments().contains("INACTIVE")) {
						String ricefComments = metaData.getRicefComments()+", "+metaData.getMetaDataComments().split(";")[1];
						metaData.setRicefComments(ricefComments);
					}
				}
				
		}
			if(metaData.getRicefSubCategory().equalsIgnoreCase(ST03HanaConstant.INCLUDE)) {
				metaData.setRicefComments(ST03HanaConstant.INCLUDE_COMMENTS);	
			}
			
			if(metaData.getRicefCategory().equals(ST03HanaConstant.INTERFACE)) {
				setInterfaceComments(metaData);
			}
			
			if(metaData.getRicefCategory2().equalsIgnoreCase(ST03HanaConstant.INTERFACE) && metaData.getSubcatI().contains("AIF")){
				if(StringUtils.isNotEmpty(metaData.getRicefComments())) {
					String ricefComments=metaData.getRicefComments();
					metaData.setRicefComments(ricefComments+", "+ST03HanaConstant.AIF);
				}
				else {
					metaData.setRicefComments(ST03HanaConstant.AIF);
				}
			}
			
			if(metaData.getMetaDataComments().equalsIgnoreCase("HANA PROCEDURE")) {
				metaData.setRicefComments("Usage of HANA PROCEDURE");
			}
			
			if(metaData.getRicefSubCategory().equalsIgnoreCase(ST03HanaConstant.CDS)) {
				if(StringUtils.isNotEmpty(metaData.getReadProg())){
					if(StringUtils.isNotEmpty(metaData.getRicefComments())) {
						String ricefComments=metaData.getRicefComments();
						metaData.setRicefComments(ricefComments+", "+"ODATA name -> "+metaData.getReadProg() );
					}else{
						metaData.setRicefComments("ODATA name -> "+metaData.getReadProg());
					}
				}

			}
		}
		
			
	}
	
		
	private List<MetaData> calculateComplexityForReports(List<MetaData> metaDataList, List<ComplexityRules> rulesList) {

		logger.info("...inside calculateComplexityForReports...");

		List<MetaData> metaDataWithComplexity = null;
		if (metaDataList != null && !(metaDataList.isEmpty())) {
			metaDataWithComplexity = new ArrayList<MetaData>();

			for (MetaData metaData : metaDataList) {
				
				if(metaData.getObj().equalsIgnoreCase(ST03HanaConstant.AQQU)){
					metaData.setComplexity("");
					metaDataWithComplexity.add(metaData);   
				}
				else {
					boolean simpleCheck = false;
					boolean mediumCheck = false;
					boolean authCheck = false;
					boolean selAndFMCheck = false;
					if (rulesList != null && !(rulesList.isEmpty())) {
	
						Integer sumOftables = metaData.getTabSap() + metaData.getTabCust();
						Integer sumOfSelFM = metaData.getSelCount()+metaData.getFmCust()+metaData.getFmSap();
						for (int i = 0; i < rulesList.size(); i++) {
							ComplexityRules complexityRules = rulesList.get(i);
							ComplexityRules prevComplexityRules = null;
							
							String sumOfSelFMRules = complexityRules.getSsumfmSel();
	
							if (complexityRules.getComplexity().equalsIgnoreCase(ST03HanaConstant.LOW)) {
								if (complexityRules.getSumOfTabs().equalsIgnoreCase("X")?true:sumOftables <= Integer.parseInt(complexityRules.getSumOfTabs())) {
									simpleCheck = true;
									if(sumOfSelFMRules.equalsIgnoreCase("X")?true:sumOfSelFM<=Integer.parseInt(sumOfSelFMRules)) {
										selAndFMCheck=true;
									}
									if(complexityRules.getSauthObj().equalsIgnoreCase("X")?true:metaData.getAuthObj()<=Integer.parseInt(complexityRules.getSauthObj())) {
										authCheck=true;
									}
								} else {
									continue;
								}
							}
							else if (complexityRules.getComplexity().equalsIgnoreCase(ST03HanaConstant.MEDIUM)) {
								prevComplexityRules = rulesList.get(i - 1);
								String prevSumOfTabs = prevComplexityRules.getSumOfTabs();
								String sumOftabs = complexityRules.getSumOfTabs();
								if (((prevSumOfTabs.equalsIgnoreCase("X")?true: sumOftables > Integer.parseInt(prevSumOfTabs))
										&& (sumOftabs.equalsIgnoreCase("X")?true:sumOftables <= Integer.parseInt(sumOftabs)))) {
									mediumCheck = true;
									if(sumOfSelFMRules.equalsIgnoreCase("X")?true:sumOfSelFM<=Integer.parseInt(sumOfSelFMRules)) {
										selAndFMCheck=true;
									}
									if(complexityRules.getSauthObj().equalsIgnoreCase("X")?true:metaData.getAuthObj()<=Integer.parseInt(complexityRules.getSauthObj())) {
										authCheck=true;
									}
								} else {
									continue;
								}
							}
							else {
								// We don't need to check other conditions as this is highest complexity
								// Rules:if((metaData.getDrill()>=complexityRules.getDrill())
								// && (metaData.getSumOfCRUD()>=complexityRules.getSumOfCrud()))
								metaData.setComplexity(complexityRules.getComplexity().toUpperCase());
								metaDataWithComplexity.add(metaData);
								break;
							}
							
							
							if ((simpleCheck || mediumCheck)) {
								if ((complexityRules.getDrill().equalsIgnoreCase("X")?true:metaData.getDrill() <= Integer.parseInt(complexityRules.getDrill()))
									&& (complexityRules.getSumOfCrud().equalsIgnoreCase("X")?true:(metaData.getSumOfCRUD()) <= 
									Integer.parseInt(complexityRules.getSumOfCrud()) )) {
									
									if(selAndFMCheck && authCheck) {
									
									metaData.setComplexity(complexityRules.getComplexity().toUpperCase());
									metaDataWithComplexity.add(metaData);
									break;
								} else {
									if (i != rulesList.size() - 1) {
										// setting the next available complexity
										ComplexityRules nextComplexityRules = rulesList.get(i + 1);
										metaData.setComplexity(nextComplexityRules.getComplexity().toUpperCase());
										String ricefComments ="";
										
										if(!selAndFMCheck) {
											ricefComments+="High usage of SELECT & FM COUNT"+" : "+sumOfSelFM+",";	
										}
										if(!authCheck) {
											ricefComments+="High usage of Authoriztion object"+" : "+metaData.getAuthObj();
										}
											
											if (ricefComments.lastIndexOf(",") == ricefComments.length() - 1) {
												ricefComments = StringUtils.chop(ricefComments);
											}
											metaData.setRicefComments(ricefComments);
										}
										
										metaDataWithComplexity.add(metaData);
										break;
									}
								}else {
									if (i != rulesList.size() - 1) {
										// setting the next available complexity
										ComplexityRules nextComplexityRules = rulesList.get(i + 1);
										metaData.setComplexity(nextComplexityRules.getComplexity().toUpperCase());
										metaDataWithComplexity.add(metaData);
										break;
									}
								}
							}
						}
					}
				}
			}
		}
		return metaDataWithComplexity;

	}

	private List<MetaData> calculateComplexityForForms(List<MetaData> metaDataList, List<ComplexityRules> rulesList) {

		logger.info("...inside calculateComplexityForForms...");

		List<MetaData> metaDataWithComplexity = null;

		if (metaDataList != null && !(metaDataList.isEmpty())) {
			metaDataWithComplexity = new ArrayList<MetaData>();
			
			for (MetaData metaData : metaDataList) {
				boolean categoryCheck = false;
				boolean selCheck = false;
				
				if (rulesList != null && !(rulesList.isEmpty())) {
					
					Integer sumOfSelFM = metaData.getSelCount()+metaData.getFmCust()+metaData.getFmSap();

					Integer sumOftables = metaData.getTabSap() + metaData.getTabCust();
					for (int i =0; i<rulesList.size(); i++) {
						
						ComplexityRules complexityRules = rulesList.get(i);
						String sumOfSelFMRules = complexityRules.getSsumfmSel();
						
						if (complexityRules.getComplexity().equalsIgnoreCase(ST03HanaConstant.LOW)) {
								
							if (complexityRules.getSumOfTabs().equalsIgnoreCase("X")?true:sumOftables <= Integer.parseInt(complexityRules.getSumOfTabs())) {
								
								if(metaData.getRicefCategory2().equals("") || (metaData.getRicefCategory2().equals(ST03HanaConstant.REPORTS) 
										&& !(metaData.getSubcatR().contains("ALV")||metaData.getSubcatR().contains("INTERACTIVE")))) {
									categoryCheck = true;
								}
								if(sumOfSelFMRules.equalsIgnoreCase("X")?true:sumOfSelFM<=Integer.parseInt(sumOfSelFMRules)) {
									selCheck =true;
								}
							} else {
								continue;
							}
						} else if (complexityRules.getComplexity().equalsIgnoreCase(ST03HanaConstant.MEDIUM)) {
							if (complexityRules.getSumOfTabs().equalsIgnoreCase("X")?true:sumOftables <= Integer.parseInt(complexityRules.getSumOfTabs())) {
								if(metaData.getRicefCategory3().equals("") || (metaData.getRicefCategory3().equals(ST03HanaConstant.REPORTS) 
										&& !(metaData.getSubcatR().contains("ALV")||metaData.getSubcatR().contains("INTERACTIVE")))) {
									categoryCheck = true;
								}
								if(sumOfSelFMRules.equalsIgnoreCase("X")?true:sumOfSelFM<=Integer.parseInt(sumOfSelFMRules)) {
									selCheck =true;
								}
							} else {
								continue;
							}
						} else {
							metaData.setComplexity(complexityRules.getComplexity().toUpperCase());
							metaDataWithComplexity.add(metaData);
							break;
						}
						
						if(categoryCheck && selCheck) {
							metaData.setComplexity(complexityRules.getComplexity().toUpperCase());
							metaDataWithComplexity.add(metaData);
							break;
						}else {
							if (i != rulesList.size() - 1) {
								// setting the next available complexity
								ComplexityRules nextComplexityRules = rulesList.get(i + 1);
								metaData.setComplexity(nextComplexityRules.getComplexity().toUpperCase());
								String ricefComments ="";
								if(!categoryCheck) {
									ricefComments+="Multiple Categories Present"+",";
								
								}
								if(!selCheck) {
									ricefComments+="High usage of SELECT & FM COUNT : "+sumOfSelFM;
								}
								if (ricefComments.lastIndexOf(",") == ricefComments.length() - 1) {
									ricefComments = StringUtils.chop(ricefComments);
								}
								metaData.setRicefComments(ricefComments);
								metaDataWithComplexity.add(metaData);
								break;
								}
						}
					}
				}
			}
		}
		return metaDataWithComplexity;
	}

	private List<MetaData> calculateComplexityForInterface(List<MetaData> metaDataList,
			List<ComplexityRules> rulesList) {

		logger.info("...inside calculateComplexityForInterface...");

		List<MetaData> metaDataWithComplexity = null;

		if (metaDataList != null && !(metaDataList.isEmpty())) {
			metaDataWithComplexity = new ArrayList<MetaData>();

			for (MetaData metaData : metaDataList) {

				boolean categoryCheck = false;
				boolean selCheck = false;
				int dbLinkCount=0;
				boolean subcatCheck = false;
				
				Integer sumOfSelFM = metaData.getSelCount()+metaData.getFmCust()+metaData.getFmSap();
				String subcatDtl = metaData.getSubcatDtl();
				if(subcatDtl.contains(ST03HanaConstant.DB_LINK)) {
					dbLinkCount = Character.getNumericValue(subcatDtl.charAt(subcatDtl.indexOf(ST03HanaConstant.DB_LINK)-2));
				}
				
				Integer sumOfFR = metaData.getFileExt() + metaData.getRfc();
				if (rulesList != null && !(rulesList.isEmpty())) {

					for (int i =0; i<rulesList.size(); i++) {
						ComplexityRules complexityRules = rulesList.get(i);
						String sumFR ="";
						if(complexityRules.getFileExt().equalsIgnoreCase("X") && complexityRules.getRfc().equalsIgnoreCase("X")) {
							sumFR ="X";
						}
						
						
						Integer sumOfRulesFR =(complexityRules.getFileExt().equalsIgnoreCase("X")?0: Integer.parseInt(complexityRules.getFileExt()))+
									(complexityRules.getRfc().equalsIgnoreCase("X")?0:Integer.parseInt(complexityRules.getRfc()));
					
						String sumOfSelFMRules = complexityRules.getSsumfmSel();

						if (complexityRules.getComplexity().equalsIgnoreCase(ST03HanaConstant.LOW) ||
								complexityRules.getComplexity().equalsIgnoreCase(ST03HanaConstant.MEDIUM)) {
							if (sumFR.equalsIgnoreCase("X")?true: sumOfFR <= sumOfRulesFR) {
								if (complexityRules.getComplexity().equalsIgnoreCase(ST03HanaConstant.LOW)){
									if(metaData.getRicefCategory2().equals("") || (metaData.getRicefCategory2().equals(ST03HanaConstant.REPORTS) 
											&& !(metaData.getSubcatR().contains("ALV")||metaData.getSubcatR().contains("INTERACTIVE")))) {
										categoryCheck = true;
									}
									if(!metaData.getRicefSubCategory().contains(ST03HanaConstant.DB_LINK)) {
										subcatCheck = true;
									}
								}
								if (complexityRules.getComplexity().equalsIgnoreCase(ST03HanaConstant.MEDIUM)){
									if(metaData.getRicefCategory3().equals("") || (metaData.getRicefCategory3().equals(ST03HanaConstant.REPORTS) 
											&& !(metaData.getSubcatR().contains("ALV")||metaData.getSubcatR().contains("INTERACTIVE")))) {
										categoryCheck = true;
										
									}
									if(metaData.getRicefSubCategory().contains(ST03HanaConstant.DB_LINK)) {
										if(complexityRules.getDbLinkCount().equalsIgnoreCase("X")?true:
											dbLinkCount<=Integer.parseInt(complexityRules.getDbLinkCount())){
											subcatCheck = true;
										}
									}else {
										subcatCheck = true;
									}		
								}
								if(sumOfSelFMRules.equalsIgnoreCase("X")?true:sumOfSelFM<=Integer.parseInt(sumOfSelFMRules)) {
									selCheck =true;
								}
								
							} else {
								continue;
							}
						} 
						else {
						metaData.setComplexity(complexityRules.getComplexity().toUpperCase());
						metaDataWithComplexity.add(metaData);
						break;
					}
					
						if(categoryCheck && selCheck && subcatCheck) {
							metaData.setComplexity(complexityRules.getComplexity().toUpperCase());
							metaDataWithComplexity.add(metaData);
							break;
						}else {
							if (i != rulesList.size() - 1) {
								// setting the next available complexity
								ComplexityRules nextComplexityRules = rulesList.get(i + 1);
								metaData.setComplexity(nextComplexityRules.getComplexity().toUpperCase());
								
								String ricefComments ="";
								if(!categoryCheck) {
									ricefComments+="Multiple Categories Present"+",";
								
								}
								if(!selCheck) {
									ricefComments+="High usage of SELECT & FM COUNT :"+sumOfSelFM;
								}
								if (ricefComments.lastIndexOf(",") == ricefComments.length() - 1) {
									ricefComments = StringUtils.chop(ricefComments);
								}
								metaData.setRicefComments(ricefComments);
								metaDataWithComplexity.add(metaData);
								break;
								}
						}
					}
				}

			}
		}
		return metaDataWithComplexity;
	}

	private List<MetaData> calculateComplexityForConversion(List<MetaData> metaDataList,
			List<ComplexityRules> rulesList) {

		logger.info("...inside calculateComplexityForConversion...");

		List<MetaData> metaDataWithComplexity = null;

		if (metaDataList != null && !(metaDataList.isEmpty())) {
			metaDataWithComplexity = new ArrayList<MetaData>();

			for (MetaData metaData : metaDataList) {
				
				if(metaData.getRicefSubCategory().equalsIgnoreCase(ST03HanaConstant.LSMW)) {
					metaData.setComplexity("");
					metaDataWithComplexity.add(metaData);
				}else {
					boolean categoryCheck = false;
					boolean selCheck = false;
					
					Integer sumOfSelFM = metaData.getSelCount()+metaData.getFmCust()+metaData.getFmSap();
					if (rulesList != null && !(rulesList.isEmpty())) {
	
						Integer sumOftables = metaData.getTabSap() + metaData.getTabCust();
						for (int i = 0; i < rulesList.size(); i++) {
							ComplexityRules complexityRules = rulesList.get(i);
							ComplexityRules prevComplexityRules = null;
							
							String sumOfSelFMRules = complexityRules.getSsumfmSel();
	
							if (complexityRules.getComplexity().equalsIgnoreCase(ST03HanaConstant.LOW)) {
								if (complexityRules.getSumOfTabs().equalsIgnoreCase("X")?true:sumOftables <= Integer.parseInt(complexityRules.getSumOfTabs())) {
									if(metaData.getRicefCategory2().equals("") || (metaData.getRicefCategory2().equals(ST03HanaConstant.REPORTS) 
											&& !(metaData.getSubcatR().contains("ALV")||metaData.getSubcatR().contains("INTERACTIVE")))) {
										categoryCheck = true;
									}
									if(sumOfSelFMRules.equalsIgnoreCase("X")?true:sumOfSelFM<=Integer.parseInt(sumOfSelFMRules)) {
										selCheck =true;
									}
								} else {
									continue;
								}
							}
							if (complexityRules.getComplexity().equalsIgnoreCase(ST03HanaConstant.MEDIUM)) {
								prevComplexityRules = rulesList.get(i - 1);
								String prevSumOfTabs = prevComplexityRules.getSumOfTabs();
								String sumOftabs = complexityRules.getSumOfTabs();
								
								if (((prevSumOfTabs.equalsIgnoreCase("X")?true: sumOftables > Integer.parseInt(prevSumOfTabs))
										&& (sumOftabs.equalsIgnoreCase("X")?true:sumOftables <= Integer.parseInt(sumOftabs)))) {
									if(metaData.getRicefCategory3().equals("") || (metaData.getRicefCategory3().equals(ST03HanaConstant.REPORTS) 
											&& !(metaData.getSubcatR().contains("ALV")||metaData.getSubcatR().contains("INTERACTIVE")))) {
										categoryCheck = true;
									}
									if(sumOfSelFMRules.equalsIgnoreCase("X")?true:sumOfSelFM<=Integer.parseInt(sumOfSelFMRules)) {
										selCheck =true;
									}
								} else {
									continue;
								}
							}
							if (complexityRules.getComplexity().equalsIgnoreCase(ST03HanaConstant.HIGH)) {
								metaData.setComplexity(complexityRules.getComplexity().toUpperCase());
								metaDataWithComplexity.add(metaData);
								break;
							}
							
							if ((complexityRules.getDrill().equalsIgnoreCase("X")?true:metaData.getDrill() <= Integer.parseInt(complexityRules.getDrill()))
									&& (complexityRules.getSumOfCrud().equalsIgnoreCase("X")?true:(metaData.getSumOfCRUD()) <= 
									Integer.parseInt(complexityRules.getSumOfCrud()))) {
										if(categoryCheck && selCheck) {
											metaData.setComplexity(complexityRules.getComplexity().toUpperCase());
											metaDataWithComplexity.add(metaData);
											break;
										}else {
											if (i != rulesList.size() - 1) {
												ComplexityRules nextComplexityRules = rulesList.get(i + 1);
												metaData.setComplexity(nextComplexityRules.getComplexity().toUpperCase());
												String ricefComments ="";
												if(!categoryCheck) {
													ricefComments+="Multiple Categories Present"+",";
												
												}
												if(!selCheck) {
													ricefComments+="High usage of SELECT & FM COUNT :"+sumOfSelFM;
												}
												if (ricefComments.lastIndexOf(",") == ricefComments.length() - 1) {
													ricefComments = StringUtils.chop(ricefComments);
												}
												metaData.setRicefComments(ricefComments);
												metaDataWithComplexity.add(metaData);
												break;
											}
										}
								} else {
									if (i != rulesList.size() - 1) {
										// setting the next available complexity
										ComplexityRules nextComplexityRules = rulesList.get(i + 1);
										metaData.setComplexity(nextComplexityRules.getComplexity().toUpperCase());
										metaDataWithComplexity.add(metaData);
										break;
									}
								}
						}
					}
				}
			}
		}
		return metaDataWithComplexity;
	}

	private List<MetaData> calculateComplexityForWorkflow(List<MetaData> metaDataList,
			List<ComplexityRules> rulesList) {

		logger.info("...inside calculateComplexityForWorkflow...");

		List<MetaData> metaDataWithComplexity = null;

		if (metaDataList != null && !(metaDataList.isEmpty())) {
			metaDataWithComplexity = new ArrayList<MetaData>();
			for (MetaData metaData : metaDataList) {
				metaData.setComplexity("");
				metaDataWithComplexity.add(metaData);
			}
		}
		return metaDataWithComplexity;
	}
	
	private List<MetaData> calculateComplexityForFreeStyleUI5(List<MetaData> metaDataList,
			List<ComplexityRules> rulesList) {

		logger.info("...inside calculateComplexityForFreeStyleUI5...");

		List<MetaData> metaDataWithComplexity = null;

		if (metaDataList != null && !(metaDataList.isEmpty())) {
			metaDataWithComplexity = new ArrayList<MetaData>();
			for (MetaData metaData : metaDataList) {
				Integer sumOfViewEntity=metaData.getViewCust()+metaData.getEntityCount();
				Integer sumOfCud = metaData.getSumOfCRUD()-metaData.getBapiCud();
				
				if (rulesList != null && !(rulesList.isEmpty())) {
					for(ComplexityRules complexityRules : rulesList) {
						String sumVE ="";
						if(complexityRules.getViewCust().equalsIgnoreCase("X") && complexityRules.getEntityCount().equalsIgnoreCase("X")) {
							sumVE="X";
						}
						
						Integer sumOfVErules = (complexityRules.getViewCust().equalsIgnoreCase("X")?0:Integer.parseInt(complexityRules.getViewCust()))+
								(complexityRules.getEntityCount().equalsIgnoreCase("X")?0:Integer.parseInt(complexityRules.getEntityCount()));
						
						if (complexityRules.getComplexity().equalsIgnoreCase(ST03HanaConstant.LOW)||
								complexityRules.getComplexity().equalsIgnoreCase(ST03HanaConstant.MEDIUM)){
							if((sumVE.equalsIgnoreCase("X")?true:sumOfViewEntity<=sumOfVErules) && 
									(complexityRules.getSelCount().equalsIgnoreCase("X")?true:metaData.getSelCount()
											<=Integer.parseInt(complexityRules.getSelCount()))
									&& (complexityRules.getSumOfCrud().equalsIgnoreCase("X")?true:sumOfCud<=Integer.parseInt(complexityRules.getSumOfCrud()))) {
								metaData.setComplexity(complexityRules.getComplexity().toUpperCase());
								metaDataWithComplexity.add(metaData);
								break;
							}else
								continue;
						}else {
							metaData.setComplexity(complexityRules.getComplexity().toUpperCase());
							metaDataWithComplexity.add(metaData);
							break;
						}
					}
				}
			}
		}
		return metaDataWithComplexity;
	}
	
	private List<MetaData> calculateComplexityForSmartBasedUI5(List<MetaData> metaDataList,
			List<ComplexityRules> rulesList) {

		logger.info("...inside calculateComplexityForSmartBasedUI5...");

		List<MetaData> metaDataWithComplexity = null;

		if (metaDataList != null && !(metaDataList.isEmpty())) {
			metaDataWithComplexity = new ArrayList<MetaData>();
			for (MetaData metaData : metaDataList) {
				Integer sumOfDynproTab=metaData.getDynproUse()+metaData.getTabField();
				Integer sumOfCud = metaData.getSumOfCRUD()-metaData.getBapiCud();
				
				if (rulesList != null && !(rulesList.isEmpty())) {
					for(ComplexityRules complexityRules : rulesList) {
						
						String sumTD ="";
						if(complexityRules.getDynproUse().equalsIgnoreCase("X") && complexityRules.getTabField().equalsIgnoreCase("X")) {
							sumTD="X";
						}
						
						Integer sumOfDTrules = (complexityRules.getDynproUse().equalsIgnoreCase("X")?0:Integer.parseInt(complexityRules.getDynproUse()))+
								(complexityRules.getTabField().equalsIgnoreCase("X")?0:Integer.parseInt(complexityRules.getTabField()));
						
						
						
						if (complexityRules.getComplexity().equalsIgnoreCase(ST03HanaConstant.LOW)||
								complexityRules.getComplexity().equalsIgnoreCase(ST03HanaConstant.MEDIUM)){
							if((sumTD.equals("X")?true: sumOfDynproTab<=sumOfDTrules) && 
									(complexityRules.getSelCount().equalsIgnoreCase("X")?true:metaData.getSelCount()
											<=Integer.parseInt(complexityRules.getSelCount()))
									&& (complexityRules.getSumOfCrud().equalsIgnoreCase("X")?true: sumOfCud<=Integer.parseInt(complexityRules.getSumOfCrud()))) {
								metaData.setComplexity(complexityRules.getComplexity().toUpperCase());
								metaDataWithComplexity.add(metaData);
								break;
							}else
								continue;
						}else {
							metaData.setComplexity(complexityRules.getComplexity().toUpperCase());
							metaDataWithComplexity.add(metaData);
							break;
						}
					}
				}
			}
		}
		return metaDataWithComplexity;
	}

	private List<MetaData> calculateComplexityForEnhancement(List<MetaData> metaDataList,
			List<ComplexityRules> rulesList) {

		logger.info("...inside calculateComplexityForEnhancement...");

		List<MetaData> metaDataWithComplexity = null;

		if (metaDataList != null && !(metaDataList.isEmpty())) {
			metaDataWithComplexity = new ArrayList<MetaData>();

			for (MetaData metaData : metaDataList) {
				if(metaData.getRicefSubCategory().equalsIgnoreCase("EMPTY ENHANCEMENTS")) {
					metaData.setComplexity("");
					metaDataWithComplexity.add(metaData);
				}else {
					boolean categoryCheck = false;
					boolean selCheck = false;
					Integer sumOfSelFM = metaData.getSelCount()+metaData.getFmCust()+metaData.getFmSap();
					
					if (rulesList != null && !(rulesList.isEmpty())) {
						for (int i = 0; i < rulesList.size(); i++) {
							ComplexityRules complexityRules = rulesList.get(i);
							
							String sumOfSelFMRules = complexityRules.getSsumfmSel();
							
							if (complexityRules.getComplexity().equalsIgnoreCase(ST03HanaConstant.LOW)){
								if(complexityRules.getEnhImpl().equalsIgnoreCase("X")?true: metaData.getEnhImpl()<=Integer.parseInt(complexityRules.getEnhImpl())){
									if(metaData.getRicefCategory2().equals("") || (metaData.getRicefCategory2().equals(ST03HanaConstant.REPORTS) 
											&& !(metaData.getSubcatR().contains("ALV")||metaData.getSubcatR().contains("INTERACTIVE")))) {
										categoryCheck = true;
									}
									if(sumOfSelFMRules.equalsIgnoreCase("X")?true:sumOfSelFM<=Integer.parseInt(sumOfSelFMRules)) {
										selCheck =true;
									}
								}else {
									continue;
								}
							}
							if (complexityRules.getComplexity().equalsIgnoreCase(ST03HanaConstant.MEDIUM)){
								if(complexityRules.getEnhImpl().equalsIgnoreCase("X")?true: metaData.getEnhImpl()<=Integer.parseInt(complexityRules.getEnhImpl())){
									if(metaData.getRicefCategory3().equals("") || (metaData.getRicefCategory3().equals(ST03HanaConstant.REPORTS) 
											&& !(metaData.getSubcatR().contains("ALV")||metaData.getSubcatR().contains("INTERACTIVE")))) {
										categoryCheck = true;
									}
									if(sumOfSelFMRules.equalsIgnoreCase("X")?true:sumOfSelFM<=Integer.parseInt(sumOfSelFMRules)) {
										selCheck =true;
									}
								}else {
									continue;
								}
							}
							if (complexityRules.getComplexity().equalsIgnoreCase(ST03HanaConstant.HIGH)) {
								metaData.setComplexity(complexityRules.getComplexity().toUpperCase());
								metaDataWithComplexity.add(metaData);
								break;
							}
							if (complexityRules.getSumOfCrud().equalsIgnoreCase("X")?true:
								(metaData.getSumOfCRUD() <= Integer.parseInt(complexityRules.getSumOfCrud()))) {
									if(categoryCheck && selCheck) {
										metaData.setComplexity(complexityRules.getComplexity().toUpperCase());
										metaDataWithComplexity.add(metaData);
										break;
									}else {
										if (i != rulesList.size() - 1) {
											ComplexityRules nextComplexityRules = rulesList.get(i + 1);
											metaData.setComplexity(nextComplexityRules.getComplexity().toUpperCase());
											String ricefComments ="";
											if(!categoryCheck) {
												ricefComments+="Multiple Categories Present"+",";
											
											}
											if(!selCheck) {
												ricefComments+="High usage of SELECT & FM COUNT : "+sumOfSelFM;
											}
											if (ricefComments.lastIndexOf(",") == ricefComments.length() - 1) {
												ricefComments = StringUtils.chop(ricefComments);
											}
											metaData.setRicefComments(ricefComments);
											metaDataWithComplexity.add(metaData);
											break;
										}
									}
							} else {
								if (i != rulesList.size() - 1) {
									// setting the next available complexity
									ComplexityRules nextComplexityRules = rulesList.get(i + 1);
									metaData.setComplexity(nextComplexityRules.getComplexity().toUpperCase());
									metaDataWithComplexity.add(metaData);
									break;
								}
							}
						}
					}
				}
			}
		}
		return metaDataWithComplexity;
	}

	private List<MetaData> calculateComplexityForOdata(List<MetaData> metaDataList, List<ComplexityRules> rulesList) {
		logger.info("...inside calculateComplexityForOdata...");

		List<MetaData> metaDataWithComplexity = null;

		if (metaDataList != null && !(metaDataList.isEmpty())) {
			metaDataWithComplexity = new ArrayList<MetaData>();

			for (MetaData metaData : metaDataList) {
				if (rulesList != null && !(rulesList.isEmpty())) {

					Integer sumOftables = metaData.getTabSap() + metaData.getTabCust();
					for (int i = 0; i < rulesList.size(); i++) {
						ComplexityRules complexityRules = rulesList.get(i);

						if (complexityRules.getComplexity().equalsIgnoreCase(ST03HanaConstant.LOW) 
								|| complexityRules.getComplexity().equalsIgnoreCase(ST03HanaConstant.MEDIUM)) {
							
							if ((complexityRules.getSumOfTabs().equalsIgnoreCase("X")?true:sumOftables <= Integer.parseInt(complexityRules.getSumOfTabs()))
									&& (complexityRules.getTabField().equalsIgnoreCase("X")?true: metaData.getTabField() < Integer.parseInt(complexityRules.getTabField()))
									&& (complexityRules.getSumOfCrud().equalsIgnoreCase("X")?true:metaData.getSumOfCRUD() <= Integer.parseInt(complexityRules.getSumOfCrud()))
									&& (complexityRules.getFmSap().equalsIgnoreCase("X")?true:metaData.getFmSap() <= Integer.parseInt(complexityRules.getFmSap()))
									&& (complexityRules.getFmCust().equalsIgnoreCase("X")?true:metaData.getFmCust() <= Integer.parseInt(complexityRules.getFmCust()))
									&& (complexityRules.getRfc().equalsIgnoreCase("X")?true:metaData.getRfc() <= Integer.parseInt(complexityRules.getRfc()))
									&& (complexityRules.getEntityCount().equalsIgnoreCase("X")?true: metaData.getEntityCount() <= Integer.parseInt(complexityRules.getEntityCount()))
									&& (complexityRules.getViewCust().equalsIgnoreCase("X")?true:metaData.getViewCust() <= Integer.parseInt(complexityRules.getViewCust()))) {
								
								metaData.setComplexity(complexityRules.getComplexity().toUpperCase());
								metaDataWithComplexity.add(metaData);
								break;
							} else {
								continue;
							}
						}
					
						else {
							metaData.setComplexity(complexityRules.getComplexity().toUpperCase());
							metaDataWithComplexity.add(metaData);
							break;
						}
					}
				}
			}
		}
		return metaDataWithComplexity;

	}

	private List<MetaData> calculateComplexityForModulePool(List<MetaData> metaDataList, List<ComplexityRules> rulesList) {

		logger.info("...inside calculateComplexityForModulePool...");

		List<MetaData> metaDataWithComplexity = null;

		if (metaDataList != null && !(metaDataList.isEmpty())) {
			metaDataWithComplexity = new ArrayList<MetaData>();
			for (MetaData metaData : metaDataList) {
				
				 boolean categoryCheck = false;
				 boolean selCheck = false;
				 Integer sumOfSelFM = metaData.getSelCount()+metaData.getFmCust()+metaData.getFmSap();
				
				if (rulesList != null && !(rulesList.isEmpty())) {
					for (int i = 0; i < rulesList.size(); i++) {
						ComplexityRules complexityRules = rulesList.get(i);
						ComplexityRules prevComplexityRules = null;
						
						String sumOfSelFMRules = complexityRules.getSsumfmSel();
						
						if (complexityRules.getComplexity().equalsIgnoreCase(ST03HanaConstant.LOW)) {
							if(complexityRules.getModuleScreen().equalsIgnoreCase("X")?true:metaData.getModuleScreen()<=Integer.parseInt(complexityRules.getModuleScreen())) {
								if(metaData.getRicefCategory2().equals("") || (metaData.getRicefCategory2().equals(ST03HanaConstant.REPORTS) 
										&& !(metaData.getSubcatR().contains("ALV")||metaData.getSubcatR().contains("INTERACTIVE")))) {
									categoryCheck = true;
								}
								if(sumOfSelFMRules.equalsIgnoreCase("X")?true:sumOfSelFM<=Integer.parseInt(sumOfSelFMRules)) {
									selCheck=true;
								}
							}else {
								continue;
							}
						}
						else if (complexityRules.getComplexity().equalsIgnoreCase(ST03HanaConstant.MEDIUM)) {
							prevComplexityRules = rulesList.get(i - 1);
							String prevMS = prevComplexityRules.getModuleScreen();
							String moduleScreen = complexityRules.getModuleScreen();
							if (((prevMS.equalsIgnoreCase("X")?true: metaData.getModuleScreen() > Integer.parseInt(prevMS))
									&& (moduleScreen.equalsIgnoreCase("X")?true:metaData.getModuleScreen() <= Integer.parseInt(moduleScreen)))) {
							
								if(metaData.getRicefCategory3().equals("") || (metaData.getRicefCategory3().equals(ST03HanaConstant.REPORTS) 
										&& !(metaData.getSubcatR().contains("ALV")||metaData.getSubcatR().contains("INTERACTIVE")))) {
									categoryCheck = true;
								}
								if(sumOfSelFMRules.equalsIgnoreCase("X")?true:sumOfSelFM<=Integer.parseInt(sumOfSelFMRules)) {
									selCheck=true;
								}
							}else {
								continue;
							}
						}else {
							metaData.setComplexity(complexityRules.getComplexity().toUpperCase());
							metaDataWithComplexity.add(metaData);
							break;
						}
						
						if ((complexityRules.getSumOfCrud().equalsIgnoreCase("X")?true:
							(metaData.getSumOfCRUD()-metaData.getBapiCud()) <= Integer.parseInt(complexityRules.getSumOfCrud()))) {
							if(categoryCheck && selCheck) {
								metaData.setComplexity(complexityRules.getComplexity().toUpperCase());
								metaDataWithComplexity.add(metaData);
								break;
							}else {
								if (i != rulesList.size() - 1) {
									ComplexityRules nextComplexityRules = rulesList.get(i + 1);
									metaData.setComplexity(nextComplexityRules.getComplexity().toUpperCase());
									String ricefComments ="";
									if(!categoryCheck) {
										ricefComments+="Multiple Categories Present"+",";
									}
									if(!selCheck) {
										ricefComments+="High usage of SELECT & FM COUNT : "+sumOfSelFM;
									}
									if (ricefComments.lastIndexOf(",") == ricefComments.length() - 1) {
										ricefComments = StringUtils.chop(ricefComments);
									}
									metaData.setRicefComments(ricefComments);
									metaDataWithComplexity.add(metaData);
									break;
								}
							}
					} else {
						if (i != rulesList.size() - 1) {
							// setting the next available complexity
							ComplexityRules nextComplexityRules = rulesList.get(i + 1);
							metaData.setComplexity(nextComplexityRules.getComplexity().toUpperCase());
							metaDataWithComplexity.add(metaData);
							break;
						}
					}
						}	
					}
				}
				
			}
		return metaDataWithComplexity;
	}
	
	private List<MetaData> calculateComplexityForCds(List<MetaData> metaDataList, List<ComplexityRules> rulesList) {
		logger.info("...inside calculateComplexityForCds...");

		List<MetaData> metaDataWithComplexity = null;

		if (metaDataList != null && !(metaDataList.isEmpty())) {

			metaDataWithComplexity = new ArrayList<MetaData>();

			for (MetaData metaData : metaDataList) {
				if (rulesList != null && !(rulesList.isEmpty())) {

					for (int i = 0; i < rulesList.size(); i++) {
						ComplexityRules complexityRules = rulesList.get(i);

						if (complexityRules.getComplexity().equalsIgnoreCase(ST03HanaConstant.LOW)
								|| complexityRules.getComplexity().equalsIgnoreCase(ST03HanaConstant.MEDIUM)) {
							if (complexityRules.getViewCust().equalsIgnoreCase("X")?true:
								metaData.getViewCust() <= Integer.parseInt(complexityRules.getViewCust())) {
								metaData.setComplexity(complexityRules.getComplexity().toUpperCase());
								metaDataWithComplexity.add(metaData);
								break;
							} else {
								continue;
							}
						}
						else {
							metaData.setComplexity(complexityRules.getComplexity().toUpperCase());
							metaDataWithComplexity.add(metaData);
							break;
						}
					}
				}
			}
		}

		return metaDataWithComplexity;
	}
	
	private List<MetaData> complexityForNoCategory(List<MetaData> metaDataList) {

		logger.info("...inside complexityForNoCategory...");

		List<MetaData> metaDataWithComplexity = null;
		if (metaDataList != null && !(metaDataList.isEmpty())) {
			metaDataWithComplexity = new ArrayList<MetaData>();

			for (MetaData metaData : metaDataList) {
				metaData.setComplexity("");
				metaData.setExtensibility(ST03HanaConstant.EXT_FOR_NOCAT);
				metaDataWithComplexity.add(metaData);
			}
		}
		return metaDataWithComplexity;
	}

	private List<MetaData> complexityForOthers(List<MetaData> metaDataList) {

		logger.info("...inside complexityForInclude...");

		List<MetaData> metaDataWithComplexity = null;
		if (metaDataList != null && !(metaDataList.isEmpty())) {
			metaDataWithComplexity = new ArrayList<MetaData>();

			for (MetaData metaData : metaDataList) {
				metaData.setComplexity("");
				metaData.setExtensibility("");
				/*
				 * String comments=""; if(metaData.getOrphan().equalsIgnoreCase("X")) {
				 * comments="Object is Orphan"; } metaData.setComments(comments);
				 */
				metaDataWithComplexity.add(metaData);
			}
		}
		return metaDataWithComplexity;
	}

	private Map<String, List<ComplexityRules>> separateComplexityRules(List<ComplexityRules> complexityRulesList) {

		Map<String, List<ComplexityRules>> complexityMap = new HashMap<String, List<ComplexityRules>>();

		for (ComplexityRules complexityRules : complexityRulesList) {
			if (complexityMap.containsKey(complexityRules.getCategory().toUpperCase())) {
				List<ComplexityRules> rulesList = complexityMap.get(complexityRules.getCategory().toUpperCase());
				rulesList.add(complexityRules);
				complexityMap.put(complexityRules.getCategory().toUpperCase(), rulesList);
			} else {
				List<ComplexityRules> rulesList = new ArrayList<ComplexityRules>();
				rulesList.add(complexityRules);
				complexityMap.put(complexityRules.getCategory().toUpperCase(), rulesList);

			}
		}
		return complexityMap;

	}

	private Map<String, List<MetaData>> separateMetaData(List<MetaData> metaDataList) {

		Map<String, List<MetaData>> metaDataMap = new HashMap<String, List<MetaData>>();

		for (MetaData metaData : metaDataList) {
				if(metaData.getObj().equalsIgnoreCase(ST03HanaConstant.CDS)||
						metaData.getRicefSubCategory().equalsIgnoreCase(ST03HanaConstant.ODATA)||
						metaData.getRicefCategory().equalsIgnoreCase(ST03HanaConstant.UI5)) {
					if (metaDataMap.containsKey(metaData.getRicefSubCategory())) {
						List<MetaData> metaDataListWithCategory = metaDataMap.get(metaData.getRicefSubCategory());
						metaDataListWithCategory.add(metaData);
						metaDataMap.put(metaData.getRicefSubCategory(), metaDataListWithCategory);
					} else {
						List<MetaData> metaDataListWithCategory = new ArrayList<MetaData>();
						metaDataListWithCategory.add(metaData);
						metaDataMap.put(metaData.getRicefSubCategory(), metaDataListWithCategory);
	
					}
				}else {
					if (metaDataMap.containsKey(metaData.getRicefCategory())) {
						List<MetaData> metaDataListWithCategory = metaDataMap.get(metaData.getRicefCategory());
						metaDataListWithCategory.add(metaData);
						metaDataMap.put(metaData.getRicefCategory(), metaDataListWithCategory);
					} else {
						List<MetaData> metaDataListWithCategory = new ArrayList<MetaData>();
						metaDataListWithCategory.add(metaData);
						metaDataMap.put(metaData.getRicefCategory(), metaDataListWithCategory);
	
					}
				}
			}
		return metaDataMap;

	}
	
	private Map<String, List<MetaData>> separateMetaDataForGraphs(List<MetaData> metaDataList) {

		Map<String, List<MetaData>> metaDataMap = new HashMap<String, List<MetaData>>();

		for (MetaData metaData : metaDataList) {
				if(metaData.getObj().equalsIgnoreCase(ST03HanaConstant.CDS)||metaData.getRicefSubCategory().equalsIgnoreCase(ST03HanaConstant.ODATA)
						||metaData.getRicefSubCategory().equals(ST03HanaConstant.INCLUDE)) {
					if (metaDataMap.containsKey(metaData.getRicefSubCategory())) {
						List<MetaData> metaDataListWithCategory = metaDataMap.get(metaData.getRicefSubCategory());
						metaDataListWithCategory.add(metaData);
						metaDataMap.put(metaData.getRicefSubCategory(), metaDataListWithCategory);
					} else {
						List<MetaData> metaDataListWithCategory = new ArrayList<MetaData>();
						metaDataListWithCategory.add(metaData);
						metaDataMap.put(metaData.getRicefSubCategory(), metaDataListWithCategory);
	
					}
				}else {
					if (metaDataMap.containsKey(metaData.getRicefCategory())) {
						List<MetaData> metaDataListWithCategory = metaDataMap.get(metaData.getRicefCategory());
						metaDataListWithCategory.add(metaData);
						metaDataMap.put(metaData.getRicefCategory(), metaDataListWithCategory);
					} else {
						List<MetaData> metaDataListWithCategory = new ArrayList<MetaData>();
						metaDataListWithCategory.add(metaData);
						metaDataMap.put(metaData.getRicefCategory(), metaDataListWithCategory);
	
					}
				}
			}
			
		return metaDataMap;

	}
	
	public List<MetaData> findExtRecommendation(RequestForm requestForm, CodeAssessmentPayLoad cPL,
			List<MetaData> metaDataList, ExtensionScope extensionScope) {

		logger.info("...inside findExtRecommendation...");

		List<ExtensionRules> extRulesList = cPL.getExtRulesList();
		List<UsageAnalysis> usageAnalysisList = cPL.getUsageAnalysisList();
		List<ImpactedCloneAnalysis> impactedCloneList = cPL.getImpactedcloneList();
		
		//List<MetaData> mergedListwithUA = null;
		// map usage analysis fields to meta data for extensibility
		if (usageAnalysisList != null && !usageAnalysisList.isEmpty()) {
			mapMetaDataWithUA(metaDataList, usageAnalysisList);
		} 
		if(impactedCloneList!=null && !impactedCloneList.isEmpty()) {
			mapImpactedCloneData(metaDataList, impactedCloneList);
		}
		// separate meta data based on Ricef category
		Map<String, List<MetaData>> metaDataMap = separateMetaData(metaDataList);
		Map<String, List<ExtensionRules>> extensionMap = null;
		// map rules based on category
		if (extRulesList != null && !extRulesList.isEmpty()) {
			extensionMap = separateExtensionRules(extRulesList);
		}

		// find extensibility availability on the basis of target system
		ExtensionFinder externsionFinder = getExtensionDataFromDB(requestForm);
		List<MetaData> metaDataListWithExtension = new ArrayList<MetaData>();

		ExtensionRules extensionComments = cPL.getExtensionComments();

		if (extensionMap != null && !extensionMap.isEmpty()) {

			List<MetaData> reportsExtensionList = findExtensionForReports(metaDataMap.get(ST03HanaConstant.REPORTS),
					extensionMap.get(ST03HanaConstant.REPORTS), externsionFinder, extensionComments);
			List<MetaData> formsExtensionList = findExtensionForForms(metaDataMap.get(ST03HanaConstant.FORMS),
					extensionMap.get(ST03HanaConstant.FORMS), externsionFinder, extensionComments);
			List<MetaData> interfaceExtensionList = findExtensionForInterface(
					metaDataMap.get(ST03HanaConstant.INTERFACE), extensionMap.get(ST03HanaConstant.INTERFACE),
					externsionFinder, extensionComments);
			List<MetaData> conversionExtensionList = findExtensionForConversion(
					metaDataMap.get(ST03HanaConstant.CONVERSION), extensionMap.get(ST03HanaConstant.CONVERSION),
					externsionFinder, extensionComments);
			List<MetaData> workflowExtensionList = findExtensionForWorkflow(metaDataMap.get(ST03HanaConstant.WORKFLOW),
					extensionMap.get(ST03HanaConstant.WORKFLOW), externsionFinder, extensionComments);
			List<MetaData> enhancementExtensionList = findExtensionForEnhancement(
					metaDataMap.get(ST03HanaConstant.ENHANCEMENT), extensionMap.get(ST03HanaConstant.ENHANCEMENT),
					externsionFinder, extensionComments);
			List<MetaData> oDataExtensionList = findExtensionForOdata(metaDataMap.get(ST03HanaConstant.ODATA),
					extensionMap.get(ST03HanaConstant.ODATA), externsionFinder, extensionComments);
		
			List<MetaData> cdsExtensionList = findExtensionForCds(metaDataMap.get(ST03HanaConstant.CDS),
					extensionMap.get(ST03HanaConstant.CDS), externsionFinder, extensionComments);
			
			//module pool extensibility rules similar to reports
			List<MetaData> modulePoolExtensionList = findExtensionForReports(metaDataMap.get(ST03HanaConstant.CLASSICAL_DYNPRO),
					extensionMap.get(ST03HanaConstant.REPORTS), externsionFinder, extensionComments);
			
			List<MetaData> otherObjectsList = metaDataMap.get(ST03HanaConstant.OTHERS);
			
			List<MetaData> ui5List = new ArrayList<>();
			if(metaDataMap.get(ST03HanaConstant.FREE_STYLE)!=null){
				ui5List.addAll(metaDataMap.get(ST03HanaConstant.FREE_STYLE));
			}
			if(metaDataMap.get(ST03HanaConstant.SMART_BASED)!=null) {
				ui5List.addAll(metaDataMap.get(ST03HanaConstant.SMART_BASED));
			}
			
			List<MetaData> ui5ExtensionList = findExtensionForUI5(ui5List);
			
			
			List<MetaData> noCategoryExtensionList = metaDataMap.get("");

			if (reportsExtensionList != null) {
				metaDataListWithExtension.addAll(reportsExtensionList);
			}
			if (formsExtensionList != null) {
				metaDataListWithExtension.addAll(formsExtensionList);
			}
			if (interfaceExtensionList != null) {
				metaDataListWithExtension.addAll(interfaceExtensionList);
			}
			if (conversionExtensionList != null) {
				metaDataListWithExtension.addAll(conversionExtensionList);
			}
			if (workflowExtensionList != null) {
				metaDataListWithExtension.addAll(workflowExtensionList);
			}
			if (enhancementExtensionList != null) {
				metaDataListWithExtension.addAll(enhancementExtensionList);
			}
			if (oDataExtensionList != null) {
				metaDataListWithExtension.addAll(oDataExtensionList);
			}
			if (cdsExtensionList != null) {
				metaDataListWithExtension.addAll(cdsExtensionList);
			}
			if (modulePoolExtensionList != null) {
				metaDataListWithExtension.addAll(modulePoolExtensionList);
			}
			if	(ui5ExtensionList!=null) {
				metaDataListWithExtension.addAll(ui5ExtensionList);
			}
			if (otherObjectsList != null) {
				metaDataListWithExtension.addAll(otherObjectsList);
			}
			if (noCategoryExtensionList != null) {
				metaDataListWithExtension.addAll(noCategoryExtensionList);
			}
			setExtensionCount(metaDataListWithExtension, extensionScope);
		}
		return metaDataListWithExtension;
	}

	private void setExtensionCount(List<MetaData> metaDataListWithExtension, ExtensionScope extensionScope) {
		Map<String, Integer> extCountMap = new HashMap<>();
		for (MetaData metaData : metaDataListWithExtension) {
			if (ST03HanaConstant.CAT_LIST.contains(metaData.getRicefCategory())) {
				if (!metaData.getComplexity().equals("")) {

					if (extCountMap.containsKey(metaData.getExtensibility())) {
						Integer count = extCountMap.get(metaData.getExtensibility());
						extCountMap.put(metaData.getExtensibility(), count + 1);
					} else {
						extCountMap.put(metaData.getExtensibility(), 1);
					}

				}
			}
		}

		StringBuffer extensionCount = new StringBuffer();

		
		for (Entry<String, Integer> ricefMap : extCountMap.entrySet()) {
			String extension = ricefMap.getKey();
			Integer count = ricefMap.getValue();
			extensionCount.append(extension).append(":").append(count).append("|");
		}
		extensionScope.setTotalExtensionCount(extensionCount.toString());
		 

	}

	private List<MetaData> findExtensionForCds(List<MetaData> metaDataList, List<ExtensionRules> rulesList,
			ExtensionFinder externsionFinder, ExtensionRules extensionComments) {
		logger.info("...inside findExtensionForCds...");
		List<MetaData> metaDataListWithExtension = null;
		if (metaDataList != null && !(metaDataList.isEmpty())) {
			metaDataListWithExtension = new ArrayList<MetaData>();

			for (MetaData metaData : metaDataList) {

				if (rulesList != null && !rulesList.isEmpty()) {
					for (ExtensionRules extensionRules : rulesList) {

						if (extensionRules.getExtensibility().equalsIgnoreCase(ST03HanaConstant.SIDE_BY_SIDE)) {

							if (externsionFinder.getSideBySideExt().equals(ST03HanaConstant.A)) {

								if (metaData.getViewCust() > extensionRules.getViewCust() && metaData.getViewSap() == extensionRules.getViewSap()) {

									metaData.setExtensibility(extensionRules.getExtensibility());
									metaDataListWithExtension.add(metaData);
									break;
								} else if (metaData.getViewCust() == extensionRules.getViewCust() && metaData.getViewSap() == extensionRules.getViewSap()
										&& metaData.getTabCust() > extensionRules.getTabCust() && metaData.getTabSap() == extensionRules.getTabSap()) {

									metaData.setExtensibility(extensionRules.getExtensibility());
									metaDataListWithExtension.add(metaData);
									break;

								} else {
									continue;
								}

							} else {
								continue;
							}

						} else {
							if (externsionFinder.getClassicExt().equals(ST03HanaConstant.A)
									|| externsionFinder.getClassicExt().equals(ST03HanaConstant.PA)) {

								if (externsionFinder.getClassicExt().equals(ST03HanaConstant.A)) {
									metaData.setExtensibility(extensionRules.getExtensibility());
									// setClassicalComments(metaData, extensionRules, extensionComments, sumOfRD,
									// sumofExRD);
									metaDataListWithExtension.add(metaData);
								} else {
									if ((metaData.getNativeIntf() > extensionRules.getNativeIntf())
											|| (metaData.getDynproUse() > extensionRules.getDynproUse())) {
										metaData.setExtensibility(ST03HanaConstant.EXTENSION_NOT_POSSIBLE);
										metaData.setComments(ST03HanaConstant.PA_COMMENTS);
										metaDataListWithExtension.add(metaData);
									} else {
										metaData.setExtensibility(extensionRules.getExtensibility());
										// setClassicalComments(metaData, extensionRules, extensionComments, sumOfRD,
										// sumofExRD);
										metaDataListWithExtension.add(metaData);
									}
								}
							} else {
								metaData.setExtensibility(ST03HanaConstant.EXTENSION_NOT_AVAILABLE);
								metaData.setComments(ST03HanaConstant.NA_COMMENTS);
								metaDataListWithExtension.add(metaData);
								break;
							}
						}
					}

				}
			}
		}

		return metaDataListWithExtension;
	}

	private List<MetaData> findExtensionForOdata(List<MetaData> metaDataList, List<ExtensionRules> rulesList,
			ExtensionFinder externsionFinder, ExtensionRules extensionComments) {
		logger.info("...inside findExtensionForOdata...");

		List<MetaData> metaDataListWithExtension = null;
		if (metaDataList != null && !(metaDataList.isEmpty())) {
			
			metaDataListWithExtension = new ArrayList<MetaData>();

			for (MetaData metaData : metaDataList) {

				Integer sumOfRD = metaData.getRicefDepd() + metaData.getDrill();
				Integer sumOfCrud = metaData.getSumOfCRUD()-metaData.getBapiCud();

				if (rulesList != null && !rulesList.isEmpty()) {
					for (ExtensionRules extensionRules : rulesList) {
						Integer sumofExRD = extensionRules.getRicefDepd() + extensionRules.getDrill();

						if (extensionRules.getExtensibility().equalsIgnoreCase(ST03HanaConstant.SIDE_BY_SIDE)) {
							if (externsionFinder.getSideBySideExt().equals(ST03HanaConstant.A)
									&& (metaData.getComplexity().equalsIgnoreCase(ST03HanaConstant.LOW)
											|| metaData.getComplexity().equalsIgnoreCase(ST03HanaConstant.MEDIUM))) {
								if (metaData.getViewCust() > extensionRules.getViewCust()) {
									if (((metaData.getUsage() == null || metaData.getUsage().equals("")) ? true
													: metaData.getUsageCount() <= extensionRules.getFrequency())
											&& sumOfCrud-metaData.getSumOfZCRUD() <= extensionRules.getSumOfCrud()
											&& metaData.getSumOfZCRUD() >= extensionRules.getSumOfZCRUD()
											&& metaData.getTabCust() > extensionRules.getTabCust()
											&& metaData.getViewSap() == extensionRules.getViewSap()) {

										metaData.setExtensibility(extensionRules.getExtensibility());
										OdataExtMap.put(metaData.getObjName(), metaData.getExtensibility());
										setComments(metaData, extensionComments);
										metaDataListWithExtension.add(metaData);
										break;
									} else {
										continue;
									}
								} else if (((metaData.getUsage() == null || metaData.getUsage().equals("")) ? true
												: metaData.getUsageCount() <= extensionRules.getFrequency())
										&& sumOfCrud-metaData.getSumOfZCRUD() <= extensionRules.getSumOfCrud()
										&& metaData.getSumOfZCRUD() >= extensionRules.getSumOfZCRUD()
										&& metaData.getTabCust() > extensionRules.getTabCust()) {

									metaData.setExtensibility(extensionRules.getExtensibility());
									OdataExtMap.put(metaData.getObjName(), metaData.getExtensibility());
									setComments(metaData, extensionComments);
									metaDataListWithExtension.add(metaData);
									break;
								} else {
									continue;
								}
							} else {
								continue;
							}
						} else {
							if (externsionFinder.getClassicExt().equals(ST03HanaConstant.A)
									|| externsionFinder.getClassicExt().equals(ST03HanaConstant.PA)) {

								if (externsionFinder.getClassicExt().equals(ST03HanaConstant.A)) {
									metaData.setExtensibility(extensionRules.getExtensibility());
									OdataExtMap.put(metaData.getObjName(), metaData.getExtensibility());
									setClassicalComments(metaData, extensionRules, extensionComments, sumOfRD,
											sumofExRD);
									metaDataListWithExtension.add(metaData);
								} else {
									if ((metaData.getNativeIntf() > extensionRules.getNativeIntf())
											|| (metaData.getDynproUse() > extensionRules.getDynproUse())) {
										metaData.setExtensibility(ST03HanaConstant.EXTENSION_NOT_POSSIBLE);
										OdataExtMap.put(metaData.getObjName(), metaData.getExtensibility());
										metaData.setComments(ST03HanaConstant.PA_COMMENTS);
										metaDataListWithExtension.add(metaData);
									} else {
										metaData.setExtensibility(extensionRules.getExtensibility());
										OdataExtMap.put(metaData.getObjName(), metaData.getExtensibility());
										setClassicalComments(metaData, extensionRules, extensionComments, sumOfRD,
												sumofExRD);
										metaDataListWithExtension.add(metaData);
									}
								}
							} else {
								metaData.setExtensibility(ST03HanaConstant.EXTENSION_NOT_AVAILABLE);
								OdataExtMap.put(metaData.getObjName(), metaData.getExtensibility());
								metaData.setComments(ST03HanaConstant.NA_COMMENTS);
								metaDataListWithExtension.add(metaData);
								break;
							}
						}
					}
				}
			}
		}
		return metaDataListWithExtension;

	}

	private List<MetaData> findExtensionForUI5(List<MetaData> metaDataList) {

		logger.info("...inside findExtensionForUI5...");

		List<MetaData> metaDataListWithExtension = null;

		if (metaDataList != null && !(metaDataList.isEmpty())) {
			metaDataListWithExtension = new ArrayList<MetaData>();
			for (MetaData metaData : metaDataList) {
				if(OdataExtMap.containsKey(metaData.getSubType())) {
					metaData.setExtensibility(OdataExtMap.get(metaData.getSubType()));
					metaDataListWithExtension.add(metaData);
				}else {
					metaData.setExtensibility(ST03HanaConstant.SIDE_BY_SIDE);
					metaDataListWithExtension.add(metaData);
				}
			}
		}
		return metaDataListWithExtension;
	}
	
	private List<MetaData> findExtensionForWorkflow(List<MetaData> metaDataList, List<ExtensionRules> rulesList,
			ExtensionFinder externsionFinder, ExtensionRules extensionComments) {

		logger.info("...inside findExtensionForWorkflow...");

		List<MetaData> metaDataListWithExtension = null;

		if (metaDataList != null && !(metaDataList.isEmpty())) {
			metaDataListWithExtension = new ArrayList<MetaData>();
			for (MetaData metaData : metaDataList) {
				metaData.setExtensibility("");
				metaData.setComments("");
				metaDataListWithExtension.add(metaData);
			}
		}
		return metaDataListWithExtension;
	}

	private List<MetaData> findExtensionForModulePool(List<MetaData> metaDataList, List<ExtensionRules> rulesList,
			ExtensionFinder externsionFinder, ExtensionRules extensionComments) {

		logger.info("...inside findExtensionForModulePool...");

		List<MetaData> metaDataListWithExtension = null;

		if (metaDataList != null && !(metaDataList.isEmpty())) {
			metaDataListWithExtension = new ArrayList<MetaData>();
			for (MetaData metaData : metaDataList) {
				metaData.setExtensibility("");
				metaData.setComments("");
				metaDataListWithExtension.add(metaData);
			}
		}
		return metaDataListWithExtension;
	}

	private List<MetaData> findExtensionForEnhancement(List<MetaData> metaDataList, List<ExtensionRules> rulesList,
			ExtensionFinder externsionFinder, ExtensionRules extensionComments) {

		logger.info("...inside findExtensionForEnhancement...");

		List<MetaData> metaDataListWithExtension = null;

		if (metaDataList != null && !(metaDataList.isEmpty())) {

			metaDataListWithExtension = new ArrayList<MetaData>();
			List<AppsType> appsTypeList = getOdataFioriProcessDao().getFioriMasterData();
			List<List<AppsType>> finalAppsTypeList = getTcodeStandardizationService().refineTCodes(appsTypeList);
			List<AppsType> refinedAppsTypeList = new ArrayList<>();
			if(finalAppsTypeList!=null && refinedAppsTypeList.size()>=1) {
				refinedAppsTypeList = finalAppsTypeList.get(0);
			}
			

			for (MetaData metaData : metaDataList) {
				
				if(metaData.getRicefSubCategory().equalsIgnoreCase("EMPTY ENHANCEMENTS")) {
					metaData.setExtensibility("");
					metaDataListWithExtension.add(metaData);
				}
				else {

					Map<String, List<String>> tcodeMap = new LinkedHashMap<>();
					List<String> enhTcodes = new ArrayList<String>();
	
					if (metaData.getEnhTcode() != null && !metaData.getEnhTcode().isEmpty()) {
						enhTcodes = Arrays.asList(metaData.getEnhTcode().split(";"));
					}
	
					String comments = "";
					String constantString = "Tcodes with Fiori apps: ";
					int count = 0;
					if (enhTcodes != null && !enhTcodes.isEmpty()) {
						for (String metaDataTcode : enhTcodes) {
	
							List<String> appNamesList = new ArrayList<String>();
							for (AppsType appsType : refinedAppsTypeList) {
	
								List<String> tCode = appsType.gettCodesList();
	
								if (tCode.contains(metaDataTcode)) {
									String appName = appsType.getAppName();
	
									if (appName != null && !appName.isEmpty()) {
										appNamesList.add(appName);
									}
								}
							}
	
							tcodeMap.put(metaDataTcode, appNamesList);
						}
					}
	
					for (Entry<String, List<String>> entry : tcodeMap.entrySet()) {
						if (!entry.getValue().isEmpty() && count <= ST03HanaConstant.TCODE_LIMIT) {
							comments += entry.getKey() + ",";
							count++;
						}
					}
					if (count > 0) {
						// metaData.setExtensibility(ST03HanaConstant.IN_APP);
						comments = StringUtils.chop(constantString + comments);
						// metaDataListWithExtension.add(metaData);
	
					}
					/*
					 * if(metaData.getOrphan().equalsIgnoreCase("X")) {
					 * comments="Object is orphan"+"\n"+comments; }
					 */
					if (rulesList != null && !rulesList.isEmpty()) {
						for (ExtensionRules extensionRules : rulesList) {
							if (externsionFinder.getClassicExt().equals(ST03HanaConstant.A)
									|| externsionFinder.getClassicExt().equals(ST03HanaConstant.PA)) {
	
								if (externsionFinder.getClassicExt().equals(ST03HanaConstant.A)) {
									metaData.setExtensibility(extensionRules.getExtensibility());
									metaData.setComments(comments);
									metaDataListWithExtension.add(metaData);
								} else {
									if ((metaData.getNativeIntf() > extensionRules.getNativeIntf())
											|| (metaData.getDynproUse() > extensionRules.getDynproUse())) {
										metaData.setExtensibility(ST03HanaConstant.EXTENSION_NOT_POSSIBLE);
										metaData.setComments(ST03HanaConstant.PA_COMMENTS + "\n" + comments);
										metaDataListWithExtension.add(metaData);
									} else {
										metaData.setExtensibility(extensionRules.getExtensibility());
										metaData.setComments(comments);
										metaDataListWithExtension.add(metaData);
									}
								}
							} else {
								metaData.setExtensibility(ST03HanaConstant.EXTENSION_NOT_AVAILABLE);
								metaData.setComments(ST03HanaConstant.NA_COMMENTS + "\n" + comments);
								metaDataListWithExtension.add(metaData);
							}
						}
					}
				}
			}
		}
		return metaDataListWithExtension;
	}

	private List<MetaData> findExtensionForConversion(List<MetaData> metaDataList, List<ExtensionRules> rulesList,
			ExtensionFinder externsionFinder, ExtensionRules extensionComments) {

		logger.info("...inside findExtensionForConversion...");

		List<MetaData> metaDataListWithExtension = null;

		if (metaDataList != null && !(metaDataList.isEmpty())) {
			metaDataListWithExtension = new ArrayList<MetaData>();

			for (MetaData metaData : metaDataList) {
				
				if (rulesList != null && !rulesList.isEmpty()) {
					for (ExtensionRules extensionRules : rulesList) {
						if (externsionFinder.getClassicExt().equals(ST03HanaConstant.A)
								|| externsionFinder.getClassicExt().equals(ST03HanaConstant.PA)) {

							if (externsionFinder.getClassicExt().equals(ST03HanaConstant.A)) {
								metaData.setExtensibility(extensionRules.getExtensibility());
								
								metaDataListWithExtension.add(metaData);
							} else {
								if ((metaData.getNativeIntf() > extensionRules.getNativeIntf())
										|| (metaData.getDynproUse() > extensionRules.getDynproUse())) {
									metaData.setExtensibility(ST03HanaConstant.EXTENSION_NOT_POSSIBLE);
									metaData.setComments(ST03HanaConstant.PA_COMMENTS);
									metaDataListWithExtension.add(metaData);

								} else {
									metaData.setExtensibility(extensionRules.getExtensibility());
								
									metaDataListWithExtension.add(metaData);
								}
							}
						} else {
							metaData.setExtensibility(ST03HanaConstant.EXTENSION_NOT_AVAILABLE);
							metaData.setComments(ST03HanaConstant.NA_COMMENTS);
							metaDataListWithExtension.add(metaData);
						}
					}
				}
			}
		}
		return metaDataListWithExtension;
	}

	private List<MetaData> findExtensionForInterface(List<MetaData> metaDataList, List<ExtensionRules> rulesList,
			ExtensionFinder externsionFinder, ExtensionRules extensionComments) {

		logger.info("...inside findExtensionForInterface...");

		List<MetaData> metaDataListWithExtension = null;
		if (metaDataList != null && !(metaDataList.isEmpty())) {

			metaDataListWithExtension = new ArrayList<MetaData>();

			for (MetaData metaData : metaDataList) {

				
				if (rulesList != null && !rulesList.isEmpty()) {
					for (ExtensionRules extensionRules : rulesList) {
						if (externsionFinder.getClassicExt().equals(ST03HanaConstant.A)
								|| externsionFinder.getClassicExt().equals(ST03HanaConstant.PA)) {

							if (externsionFinder.getClassicExt().equals(ST03HanaConstant.A)) {
								metaData.setExtensibility(extensionRules.getExtensibility());
								metaDataListWithExtension.add(metaData);
							} else {
								if ((metaData.getNativeIntf() > extensionRules.getNativeIntf())
										|| (metaData.getDynproUse() > extensionRules.getDynproUse())) {
									metaData.setExtensibility(ST03HanaConstant.EXTENSION_NOT_POSSIBLE);
									metaData.setComments(ST03HanaConstant.PA_COMMENTS);
									metaDataListWithExtension.add(metaData);
								} else {
									metaData.setExtensibility(extensionRules.getExtensibility());
								
									metaDataListWithExtension.add(metaData);
								}
							}
						} else {
							metaData.setExtensibility(ST03HanaConstant.EXTENSION_NOT_AVAILABLE);
							metaData.setComments(ST03HanaConstant.NA_COMMENTS);
							metaDataListWithExtension.add(metaData);
						}
						
					}
				}
			}
		}
		return metaDataListWithExtension;
	}

	private List<MetaData> findExtensionForReports(List<MetaData> metaDataList, List<ExtensionRules> rulesList,
			ExtensionFinder externsionFinder, ExtensionRules extensionComments) {

		logger.info("...inside findExtensionForReports...");

		List<MetaData> metaDataListWithExtension = null;

		if (metaDataList != null && !(metaDataList.isEmpty())) {
			metaDataListWithExtension = new ArrayList<MetaData>();
			
			for (MetaData metaData : metaDataList) {
				
				if(metaData.getObj().equalsIgnoreCase(ST03HanaConstant.AQQU)){
					metaData.setExtensibility("");
					metaDataListWithExtension.add(metaData);   
				}
				else {
					Integer sumOfRD = metaData.getRicefDepd() + metaData.getDrill();
					Integer sumOfCrud = metaData.getSumOfCRUD();
					
					if (rulesList != null && !rulesList.isEmpty()) {
						for (ExtensionRules extensionRules : rulesList) {
							Integer sumofExRD = extensionRules.getRicefDepd() + extensionRules.getDrill();
	
							if (extensionRules.getExtensibility().equalsIgnoreCase(ST03HanaConstant.SIDE_BY_SIDE)) {
	
								if (externsionFinder.getSideBySideExt().equals(ST03HanaConstant.A)
										&& (((metaData.getUsage() == null) || (metaData.getUsage().equals(""))) ? true
												: metaData.getUsageCount() <= extensionRules.getFrequency())
										&& ((sumOfCrud-metaData.getSumOfZCRUD()) <= extensionRules.getSumOfCrud())
										&& (metaData.getBapiRead()<=extensionRules.getBapiRead())) {
	
									metaData.setExtensibility(extensionRules.getExtensibility());
									setCommentsForSideBySide(metaData, extensionComments);
									metaDataListWithExtension.add(metaData);
									break;
								} else {
									continue;
								}
							} else if (extensionRules.getExtensibility().equalsIgnoreCase(ST03HanaConstant.IN_APP)) {
	
								if (externsionFinder.getInAppExt().equals(ST03HanaConstant.A)
										&& (metaData.getComplexity().equalsIgnoreCase(ST03HanaConstant.LOW)
												|| metaData.getComplexity().equalsIgnoreCase(ST03HanaConstant.MEDIUM))
										&& (metaData.getNativeIntf() <= extensionRules.getNativeIntf())
										&& (((metaData.getUsage() == null) || (metaData.getUsage().equals(""))) ? true
												: metaData.getUsageCount() >= extensionRules.getFrequency())
										&& ((sumOfCrud-metaData.getSumOfZCRUD()) == extensionRules.getSumOfCrud())
										&& (metaData.getSumOfZCRUD() <= extensionRules.getSumOfZCRUD())
										&& (sumOfRD == sumofExRD) && metaData.getFmCust() == extensionRules.getFmCust()
										&& metaData.getFmSap() == extensionRules.getFmSap()) {
	
									metaData.setExtensibility(extensionRules.getExtensibility());
									setComments(metaData, extensionComments);
									metaDataListWithExtension.add(metaData);
									break;
								} else {
									continue;
								}
							} else {
								if (externsionFinder.getClassicExt().equals(ST03HanaConstant.A)
										|| externsionFinder.getClassicExt().equals(ST03HanaConstant.PA)) {
	
									if (externsionFinder.getClassicExt().equals(ST03HanaConstant.A)) {
										metaData.setExtensibility(extensionRules.getExtensibility());
										setClassicalComments(metaData, extensionRules, extensionComments, sumOfRD,
												sumofExRD);
										metaDataListWithExtension.add(metaData);
									} else {
										if (metaData.getNativeIntf() > extensionRules.getNativeIntf()) {
											metaData.setExtensibility(ST03HanaConstant.EXTENSION_NOT_POSSIBLE);
											metaData.setComments(ST03HanaConstant.PA_COMMENTS);
											metaDataListWithExtension.add(metaData);
										} else {
											metaData.setExtensibility(extensionRules.getExtensibility());
											setClassicalComments(metaData, extensionRules, extensionComments, sumOfRD,
													sumofExRD);
											metaDataListWithExtension.add(metaData);
										}
									}
								} else {
									metaData.setExtensibility(ST03HanaConstant.EXTENSION_NOT_AVAILABLE);
									metaData.setComments(ST03HanaConstant.NA_COMMENTS);
									metaDataListWithExtension.add(metaData);
									break;
								}
							}
						}
					}
				}
			}

		}
		return metaDataListWithExtension;
	}

	private List<MetaData> findExtensionForForms(List<MetaData> metaDataList, List<ExtensionRules> rulesList,
			ExtensionFinder externsionFinder, ExtensionRules extensionComments) {

		logger.info("...inside findExtensionForForms...");

		List<MetaData> metaDataListWithExtension = null;

		if (metaDataList != null && !(metaDataList.isEmpty())) {
			metaDataListWithExtension = new ArrayList<MetaData>();

			for (MetaData metaData : metaDataList) {
			
				Integer sumOfRD = metaData.getRicefDepd() + metaData.getDrill();
				Integer sumOfCrud = metaData.getSumOfCRUD()-metaData.getBapiCud();

				if (rulesList != null && !rulesList.isEmpty()) {
					for (ExtensionRules extensionRules : rulesList) {
						Integer sumofExRD = extensionRules.getRicefDepd() + extensionRules.getDrill();

						if (extensionRules.getExtensibility().equalsIgnoreCase(ST03HanaConstant.SIDE_BY_SIDE)) {

							String exsubcatDtl = extensionRules.getSubcatDtl() + "_" + extensionRules.getSubcatF();

							if (externsionFinder.getSideBySideExt().equals(ST03HanaConstant.A)&&
									 ((metaData.getObj().equals(ST03HanaConstant.PROG) || 
											 metaData.getObj().equalsIgnoreCase(ST03HanaConstant.SSFO)) ? ((metaData.getSubcatDtl().equalsIgnoreCase(exsubcatDtl))
												&& (metaData.getSubcatF().equalsIgnoreCase(extensionRules.getSubcatF()))) :true)
									&& (metaData.getNativeIntf() <= extensionRules.getNativeIntf())
									&& ((sumOfCrud - metaData.getSumOfZCRUD()) <= extensionRules.getSumOfCrud())
									&& (metaData.getSumOfZCRUD() >= extensionRules.getSumOfZCRUD())
									&& (sumOfRD == sumofExRD)) {

								metaData.setExtensibility(extensionRules.getExtensibility());
								setComments(metaData, extensionComments);
								metaDataListWithExtension.add(metaData);
								break;
							} else {
								continue;
							}
						} else {
							if (externsionFinder.getClassicExt().equals(ST03HanaConstant.A)
									|| externsionFinder.getClassicExt().equals(ST03HanaConstant.PA)) {

								if (externsionFinder.getClassicExt().equals(ST03HanaConstant.A)) {
									metaData.setExtensibility(extensionRules.getExtensibility());
									setClassicalComments(metaData, extensionRules, extensionComments, sumOfRD,
											sumofExRD);
									metaDataListWithExtension.add(metaData);
								} else {
									if ((metaData.getNativeIntf() > extensionRules.getNativeIntf())
											|| (metaData.getDynproUse() > extensionRules.getDynproUse())) {
										metaData.setExtensibility(ST03HanaConstant.EXTENSION_NOT_POSSIBLE);
										metaData.setComments(ST03HanaConstant.PA_COMMENTS);
										metaDataListWithExtension.add(metaData);
									} else {
										metaData.setExtensibility(extensionRules.getExtensibility());
										setClassicalComments(metaData, extensionRules, extensionComments, sumOfRD,
												sumofExRD);
										metaDataListWithExtension.add(metaData);
									}
								}
							} else {
								metaData.setExtensibility(ST03HanaConstant.EXTENSION_NOT_AVAILABLE);
								metaData.setComments(ST03HanaConstant.NA_COMMENTS);
								metaDataListWithExtension.add(metaData);
							}
						}
					}
				}
			}
		}
		return metaDataListWithExtension;
	}

	private void setInterfaceComments(MetaData metaData){
		
		String[] subCatArray = metaData.getRicefSubCategory().split(";");
		StringBuilder comments = new StringBuilder("");
		String ricefComments="";
		for(String ricefSubCategory:subCatArray) {
			if(ricefSubCategory.equals("")) {
				comments.append(ST03HanaConstant.UPDOWN_COMMENTS+",");
			}
			if(ricefSubCategory.equalsIgnoreCase(ST03HanaConstant.FTP)) {
				comments.append(ST03HanaConstant.FILE_COMMENTS+",");
			}
			if(ricefSubCategory.equalsIgnoreCase(ST03HanaConstant.FILE_INTERFACE) && comments.indexOf(ST03HanaConstant.FILE_COMMENTS)==-1) {
				comments.append(ST03HanaConstant.FILE_COMMENTS+",");
			}
			if(ricefSubCategory.equalsIgnoreCase(ST03HanaConstant.DB_LINK)) {
				comments.append(ST03HanaConstant.DBLINK_COMMENTS+",");
			}
			if(ricefSubCategory.equalsIgnoreCase(ST03HanaConstant.IDOC)) {
				comments.append(ST03HanaConstant.IDOC_COMMENTS+"");
			}
		}
		ricefComments = comments.toString();
		if(comments.lastIndexOf(",")==comments.length()-1) {
			 ricefComments = StringUtils.chop(comments.toString());
		}
		metaData.setComments(ricefComments);
	}
	private void setComments(MetaData metaData, ExtensionRules extensionComments) {
		String comments = "";
		String low = "Low ";
		String high = "High ";
		
		if (metaData.getRicefCategory().equalsIgnoreCase(ST03HanaConstant.FORMS)) {
			comments += low + extensionComments.getRicefDepdComments() + ",";
		}

		comments += low + extensionComments.getNativeIntfComments() + ",";
		
		if (metaData.getRicefCategory().equalsIgnoreCase(ST03HanaConstant.REPORTS)
				|| metaData.getRicefSubCategory().equalsIgnoreCase(ST03HanaConstant.ODATA)) {
			if (((metaData.getUsage() != null) && !(metaData.getUsage().equals("")))) {
					comments += low + extensionComments.getFrequencyComments() + ",";
				
			}
			if (metaData.getExtensibility().equalsIgnoreCase(ST03HanaConstant.SIDE_BY_SIDE)) {
				comments += high + extensionComments.getTabComments() + ",";
			} else {
				comments += low + extensionComments.getTabComments() + ",";
			}
		}
		if (metaData.getRicefCategory().equalsIgnoreCase(ST03HanaConstant.FORMS)
				&& metaData.getExtensibility().equalsIgnoreCase(ST03HanaConstant.IN_APP)) {
			comments += low + extensionComments.getTabComments() + ",";
		}
		comments += low + extensionComments.getSumComments() + ",";

		if (comments.lastIndexOf(",") == comments.length() - 1) {
			comments = StringUtils.chop(comments);
		}

		metaData.setComments(comments);
	}
	
	private void setCommentsForSideBySide(MetaData metaData, ExtensionRules extensionComments) {
		String comments = "";
		String low = "Low ";

		if (((metaData.getUsage() != null) && !(metaData.getUsage().equals("")))) {
					comments += low + extensionComments.getFrequencyComments() + ",";
				
		}
		comments += low + extensionComments.getSumComments() + ",";
		comments += low + extensionComments.getBapiReadComments() + ",";

		if (comments.lastIndexOf(",") == comments.length() - 1) {
			comments = StringUtils.chop(comments);
		}

		metaData.setComments(comments);
	}

	private void setClassicalComments(MetaData metaData, ExtensionRules extensionRules,
			ExtensionRules extensionComments, Integer sumOfRD, Integer sumofExRD) {
		String comments = "";
		String high = "High ";
		String low = "Low ";

		
		if (metaData.getRicefCategory().equalsIgnoreCase(ST03HanaConstant.FORMS) ||
				metaData.getRicefCategory().equalsIgnoreCase(ST03HanaConstant.REPORTS)) {
			if (sumOfRD >= sumofExRD) {
				comments += high + extensionComments.getRicefDepdComments() + ",";
			}
		}
		
		if (metaData.getRicefCategory().equalsIgnoreCase(ST03HanaConstant.REPORTS)
				|| metaData.getRicefSubCategory().equalsIgnoreCase(ST03HanaConstant.ODATA)) {
			
			if (metaData.getUsage() != null && metaData.getUsageCount() >= extensionRules.getFrequency()) {
				comments += high + extensionComments.getFrequencyComments() + ",";
				
			}
		}
		if (metaData.getRicefCategory().equalsIgnoreCase(ST03HanaConstant.REPORTS)){
			if (((metaData.getSumOfCRUD()) >= extensionRules.getSumOfCrud())
					&& (metaData.getSumOfZCRUD() >= extensionRules.getSumOfZCRUD())) {
				comments += high + extensionComments.getSumComments() + ",";
			}
			if (metaData.getTabSap() >= extensionRules.getTabSap()) {
				comments += low + extensionComments.getTabComments();
			}
		}
		else {
			if (((metaData.getSumOfCRUD()-metaData.getBapiCud()) >= extensionRules.getSumOfCrud())
					&& (metaData.getSumOfZCRUD() >= extensionRules.getSumOfZCRUD())) {
				comments += high + extensionComments.getSumComments() + ",";
			}
		}

		if (metaData.getRicefSubCategory().equalsIgnoreCase(ST03HanaConstant.ODATA)) {
			if (metaData.getTabCust() >= extensionRules.getTabSap()) {
				comments += low + extensionComments.getTabComments();
			}
		}
		if (comments.lastIndexOf(",") == comments.length() - 1) {
			comments = StringUtils.chop(comments);
		}
		metaData.setComments(comments);
	}

	private Map<String, List<ExtensionRules>> separateExtensionRules(List<ExtensionRules> extensionRulesList) {
		Map<String, List<ExtensionRules>> extensionMap = new HashMap<String, List<ExtensionRules>>();
		for (ExtensionRules extensionRules : extensionRulesList) {
			if (extensionMap.containsKey(extensionRules.getRicefCategory().toUpperCase())) {
				List<ExtensionRules> rulesList = extensionMap.get(extensionRules.getRicefCategory().toUpperCase());
				rulesList.add(extensionRules);
				extensionMap.put(extensionRules.getRicefCategory().toUpperCase(), rulesList);
			} else {
				List<ExtensionRules> rulesList = new ArrayList<ExtensionRules>();
				rulesList.add(extensionRules);
				extensionMap.put(extensionRules.getRicefCategory().toUpperCase(), rulesList);

			}
		}
		return extensionMap;

	}

	private void mapMetaDataWithUA(List<MetaData> metaDataList, List<UsageAnalysis> usageAnalysisList) {
		//List<MetaData> metaDataListWithUA = new ArrayList<MetaData>();
		Map<String, UsageAnalysis> usageAnalysisMap = new HashMap<>();
		for(UsageAnalysis usageAnalysis:usageAnalysisList) {
			usageAnalysisMap.put(usageAnalysis.getObjNameType(), usageAnalysis);
		}
		
		for(MetaData metadata : metaDataList) {
			if(usageAnalysisMap.containsKey(metadata.getObjTypeName())) {
				metadata.setUsage("Y");
				String usageCount = usageAnalysisMap.get(metadata.getObjTypeName()).getUsageCount();
				if(StringUtils.isNumeric(usageCount)) {
					metadata.setUsageCount(Integer.parseInt(usageCount));
				}
				
			}
		}
	}

	private ExtensionFinder getExtensionDataFromDB(RequestForm requestForm) {
		String targetVersion = requestForm.getTargetVersion();
		if (targetVersion.startsWith("S/4HANA") && !(targetVersion.contains("Cloud"))) {
			requestForm.setTargetVersion("S/4HANA on Premise");
		}
		ExtensionFinder externsionFinder = getExtensibilityDao().getMasterExtensionData(requestForm);
		return externsionFinder;
	}

	public List<ComplexityGraphRules> getComplexityGraphRules() {

		List<ComplexityGraphRules> complexityRules = getExtensibilityDao().getComplexityGraphRules();
		return complexityRules;
	}

	public List<ExtensibilityGraphRules> getExtensibilityGraphRules() {

		List<ExtensibilityGraphRules> extensibilityRules = getExtensibilityDao().getExtensibilityGraphRules();
		return extensibilityRules;
	}

	private void mapImpactedCloneData(List<MetaData> metaDataList, List<ImpactedCloneAnalysis> impactedCloneList){
		Map<String, ImpactedCloneAnalysis> impactedCloneMap = new HashMap<>();
		
		for(ImpactedCloneAnalysis impactedClone : impactedCloneList) {
			impactedCloneMap.put(impactedClone.getObjTypeName(), impactedClone);
		}
		
		for(MetaData metaData:metaDataList) {
			if(impactedCloneMap.containsKey(metaData.getObjTypeName())) {
				metaData.setCloneObj("X");
				//metaData.setCloneType(impactedCloneMap.get(metaData.getObjTypeName()).getReference());
				//metaData.setCloneObj(impactedCloneMap.get(metaData.getObjTypeName()).getInterfaceObj());
			}
		}
	}
}
