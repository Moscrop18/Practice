/* MODIFIED 
 *FOR Enhancement CR-3.0:- Remove unused fields(like Customer_namespaces,
				SPECIFIC_NAMING_CONEVNTIONS,NAMESPACE_DETAILS_FILE,NAMESPACE_DETAILS_FILE_NAME,NAMING_CONEVNTIONS_FILE,
				NAMING_CONVENTIONS_FILE_NAME) from create request form. -23/12/16 -monika.mishra */
package com.accenture.client.model;

import java.util.ArrayList;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.persistence.TableGenerator;


@Entity
@Table(name="REQUEST_FORM")
public class RequestForm implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	private long requestID;
	
	private String REQUEST_ID_UI;

	private String clientName;

	private String clientTeamDetails;

	private String sourceVersion;

	private String targetVersion;

	private String unicodeCompliant;

	private String enableUnicode;

	private String sap_NonSAPcomponents;

	private String pocName;

	private String wbsCode;

	private String startDate;
	
	private String endDate;

	private String dealSize;

	private String industryGroup;

	private String dbSize;

	private String projectName;

	private String industrySubGroup;

	private String clienttype;

	private String systemId;

	private String systemType;

	private String customerNamespace;

	private String externalNamespace;
	
	private String SapClientId;

	private String databaseDB;

	private String host;

	private String instalNo;
	
	private String appServer;
	@Column(name = "APP_SERVER", nullable = false)
	public String getAppServer() {
		return appServer;
	}  

	public void setAppServer(String appServer) {
		this.appServer = appServer;
	}


	private String projectPocId;

	private String numberOfUsers;

	private String toolName;

	private String currencyType;

	private String supportedAtci;
	
	private ArrayList<String> scope;
	
	private Boolean SOH;
	
	private Boolean S4Technical;
	
	private Boolean S4Functional;
	
	private Boolean UI5;
	
	private Boolean Fiori;
	
	private Boolean UPGRADE;
	
	private Boolean RFP;
	
	private Boolean CVIT;
   
	private String WBSE;
	
	private Boolean EXT;
	
	private String licenseSelect;
		
	private String serviceProvider;

	public String getWBSE() {
		return WBSE;
	}
	
	public void setWBSE(String wBSE) {
		WBSE = wBSE;
	}

	public Boolean getCVIT() {
		return CVIT;
	}

	public void setCVIT(Boolean cVIT) {
		CVIT = cVIT;
	}

	
	private String valueRFP;
	
	private String sandbox;
	
	private String numberDevelopment;
	
	private String numberQuality;
	
	private String numberProduction;
	
	private String numberOtherSystem;
	
	private String sapInterface;
	
	private String non_sapInterface;
	
	private String sapModules;
	
	private String indSolution;
	
	private String fioriSetup_apps;
	
	private String supportComponents;
	
	private String sandbox_ID_instalNo;
	
	private String rfc;
	
	private String appName;
	
	private String central_embedded;
	
	private String central_gateSystem;
	
	private String sandbox_sysId;
	
	private String oldVersion;
	
	private String newVersion;
	
	private String assignedPocEmailId;
	
	private String assignedFaitEmailId;
	
	private String systemEnvt;
	
	private Boolean sia;
	
	private String secVer;

	private String srcOSVer;
	
	private String tarOSVer;
	
	private boolean osMig;
	
	private String ale;
	private String fle;
	
	private String marketUnit;
	
	@Column(name = "ALE")
	public String getAle() {
		return ale;
	}

	public void setAle(String ale) {
		this.ale = ale;
	}

	@Column(name = "FLE")
	public String getFle() {
		return fle;
	}

	public void setFle(String fle) {
		this.fle = fle;
	}


	private Boolean grc;


	@Column(name = "GRC", nullable = false)
	public Boolean getGrc() {
		return grc;
	}

	public void setGrc(Boolean grc) {
		this.grc = grc;
	}

	
	public boolean getOsMig() {
		return osMig;
	}

	public void setOsMig(boolean osMig) {
		this.osMig = osMig;
	}

	public String getSrcOSVer() {
		return srcOSVer;
	}

	public void setSrcOSVer(String srcOSVer) {
		this.srcOSVer = srcOSVer;
	}

	public String getTarOSVer() {
		return tarOSVer;
	}

	public void setTarOSVer(String tarOSVer) {
		this.tarOSVer = tarOSVer;
	}

	@Id
	@TableGenerator(name="seq",initialValue=1,allocationSize=0)
	@GeneratedValue(strategy=GenerationType.TABLE, generator="seq")
	@Column(name="REQUEST_ID")
	public long getRequestID() {
		return requestID;
	}

	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}

	@Column(name = "SUPPORTED_BY_ATCI", nullable = false)
	public String getSupportedAtci() {
		return supportedAtci;
	}

	public void setSupportedAtci(String supportedAtci) {
		this.supportedAtci = supportedAtci;
	}

	@Column(name = "CLIENT_NAME", nullable = false)
	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	@Column(name = "END_DATE")
	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	@Column(name = "START_DATE")
	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String string) {
		this.startDate = string;
	}

	@Column(name = "PROJECT_NAME", nullable = false)
	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	@Column(name = "INDUSTRY_SUB_GROUP", nullable = false)
	public String getIndustrySubGroup() {
		return industrySubGroup;
	}

	public void setIndustrySubGroup(String industrySubGroup) {
		this.industrySubGroup = industrySubGroup;
	}

	@Column(name = "INDUSTRY_GROUP", nullable = false)
	public String getIndustryGroup() {
		return industryGroup;
	}

	public void setIndustryGroup(String industryGroup) {
		this.industryGroup = industryGroup;
	}
	
	@Column(name = "CLIENT_TYPE", nullable = false)
	public String getClienttype() {
		return clienttype;
	}

	public void setClienttype(String clienttype) {
		this.clienttype = clienttype;
	}

	@Column(name = "SYSTEM_ID", nullable = false)
	public String getSystemId() {
		return systemId;
	}

	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}

	@Column(name = "SYSTEM_TYPE", nullable = false)
	public String getSystemType() {
		return systemType;
	}

	public void setSystemType(String systemType) {
		this.systemType = systemType;
	}

	@Column(name = "CUSTOMER_NAMESPACE", nullable = false)
	public String getCustomerNamespace() {
		return customerNamespace;
	}

	public void setCustomerNamespace(String customerNamespace) {
		this.customerNamespace = customerNamespace;
	}
	
	@Column(name = "EXTERNAL_NAMESPACE",columnDefinition="Text", nullable = true)
	public String getExternalNamespace() {
		return externalNamespace;
	}

	public void setExternalNamespace(String externalNamespace) {
		this.externalNamespace = externalNamespace;
	}

	@Column(name = "SAP_CLIENT_ID", nullable = false)
	public String getSapClientId() {
		return SapClientId;
	}

	public void setSapClientId(String sapClientId) {
		SapClientId = sapClientId;
	}

	@Column(name = "INSTAL_NO", nullable = false)
	public String getInstalNo() {
		return instalNo;
	}

	public void setInstalNo(String instalNo) {
		this.instalNo = instalNo;
	}

	@Column(name = "DATABASE_DB", nullable = false)
	public String getDatabaseDB() {
		return databaseDB;
	}

	public void setDatabaseDB(String databaseDB) {
		this.databaseDB = databaseDB;
	}

	@Column(name = "HOST", nullable = false)
	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	@Column(name = "PROJECT_POC_ID", nullable = false)
	public String getProjectPocId() {
		return projectPocId;
	}

	public void setProjectPocId(String projectPocId) {
		this.projectPocId = projectPocId;
	}

	@Column(name = "CLIENT_TEAM_DETAILS", nullable = false)
	public String getClientTeamDetails() {
		return clientTeamDetails;
	}

	public void setClientTeamDetails(String clientTeamDetails) {
		this.clientTeamDetails = clientTeamDetails;
	}

	@Column(name = "SOURCE_VERSION", nullable = false)
	public String getSourceVersion() {
		return sourceVersion;
	}

	public void setSourceVersion(String sourceVersion) {
		this.sourceVersion = sourceVersion;
	}

	@Column(name = "TARGET_VERSION", nullable = false)
	public String getTargetVersion() {
		return targetVersion;
	}

	public void setTargetVersion(String targetVersion) {
		this.targetVersion = targetVersion;
	}

	@Column(name = "UNICODE_COMPLIANT", nullable = false)
	public String getUnicodeCompliant() {
		return unicodeCompliant;
	}

	public void setUnicodeCompliant(String unicodeCompliant) {
		this.unicodeCompliant = unicodeCompliant;
	}

	@Column(name = "ENABLE_UNICODE", nullable = false)
	public String getEnableUnicode() {
		return enableUnicode;
	}

	public void setEnableUnicode(String enableUnicode) {
		this.enableUnicode = enableUnicode;
	}

	@Column(name = "SAP_NONSAP_COMPONENTS", nullable = false)
	public String getSap_NonSAPcomponents() {
		return sap_NonSAPcomponents;
	}

	public void setSap_NonSAPcomponents(String sap_NonSAPcomponents) {
		this.sap_NonSAPcomponents = sap_NonSAPcomponents;
	}

	@Column(name = "POC_NAME", nullable = false)
	public String getPocName() {
		return pocName;
	}

	public void setPocName(String pocName) {
		this.pocName = pocName;
	}

	@Column(name = "WBS_CODE", nullable = false)
	public String getWbsCode() {
		return wbsCode;
	}

	public void setWbsCode(String wbsCode) {
		this.wbsCode = wbsCode;
	}

	@Column(name = "DEAL_SIZE", nullable = false)
	public String getDealSize() {
		return dealSize;
	}

	public void setDealSize(String dealSize) {
		this.dealSize = dealSize;
	}

	@Column(name = "DB_SIZE", nullable = false)
	public String getDbSize() {
		return dbSize;
	}

	public void setDbSize(String dbSize) {
		this.dbSize = dbSize;
	}

	@Column(name = "NUMBER_OF_USERS")
	public String getNumberOfUsers() {
		return numberOfUsers;
	}

	public void setNumberOfUsers(String numberOfUsers) {
		this.numberOfUsers = numberOfUsers;
	}

	public RequestForm() {
	}

	@Column(name = "TOOL_NAME", nullable = false)
	public String getToolName() {
		return toolName;
	}

	public void setToolName(String toolName) {
		this.toolName = toolName;
	}

	@Column(name = "Currency_Type", nullable = false)
	public String getCurrencyType() {
		return currencyType;
	}

	public void setCurrencyType(String currencyType) {
		this.currencyType = currencyType;
	}

	@Column(name = "scope", nullable = false)
	public ArrayList<String> getScope() {
		return scope;
	}
	public void setScope(ArrayList<String> scope) {
		this.scope = scope;
	}

	@Column(name = "SOH", nullable = false)
	public Boolean getSOH() {
		return SOH;
	}

	public void setSOH(Boolean sOH) {
		SOH = sOH;
	}

	@Column(name = "S4Technical", nullable = false)
	public Boolean getS4Technical() {
		return S4Technical;
	}

	public void setS4Technical(Boolean s4Technical) {
		S4Technical = s4Technical;
	}

	@Column(name = "S4Functional", nullable = false)
	public Boolean getS4Functional() {
		return S4Functional;
	}

	public void setS4Functional(Boolean s4Functional) {
		S4Functional = s4Functional;
	}

	@Column(name = "UI5", nullable = false)	
	public Boolean getUI5() {
		return UI5;
	}
	public void setUI5(Boolean uI5) {
		UI5 = uI5;
	}

	@Column(name = "Fiori", nullable = false)
	public Boolean getFiori() {
		return Fiori;
	}
	public void setFiori(Boolean fiori) {
		Fiori = fiori;
	}

	@Column(name = "UPGRADE", nullable = false)
	public Boolean getUPGRADE() {
		return UPGRADE;
	}

	public void setUPGRADE(Boolean uPGRADE) {
		UPGRADE = uPGRADE;
	}
	
	@Column(name="REQUEST_ID_UI",nullable = false)
	public String getREQUEST_ID_UI() {
		return REQUEST_ID_UI;
	}
	public void setREQUEST_ID_UI(String rEQUEST_ID_UI) {
		REQUEST_ID_UI = rEQUEST_ID_UI;
	}

	@Column(name = "sandbox")
	public String getSandbox() {
		return sandbox;
	}
	public void setSandbox(String sandbox) {
		this.sandbox = sandbox;
	}

	@Column(name = "numberDevelopment")
	public String getNumberDevelopment() {
		return numberDevelopment;
	}
	public void setNumberDevelopment(String numberDevelopment) {
		this.numberDevelopment = numberDevelopment;
	}
	
	@Column(name = "numberQuality")
	public String getNumberQuality() {
		return numberQuality;
	}
	public void setNumberQuality(String numberQuality) {
		this.numberQuality = numberQuality;
	}

	@Column(name = "numberProduction")
	public String getNumberProduction() {
		return numberProduction;
	}
	public void setNumberProduction(String numberProduction) {
		this.numberProduction = numberProduction;
	}
	
	@Column(name = "numberOtherSystem")
	public String getNumberOtherSystem() {
		return numberOtherSystem;
	}
	public void setNumberOtherSystem(String numberOtherSystem) {
		this.numberOtherSystem = numberOtherSystem;
	}

	@Column(name = "sapInterface")
	public String getSapInterface() {
		return sapInterface;
	}
	public void setSapInterface(String sapInterface) {
		this.sapInterface = sapInterface;
	}

	@Column(name = "non_sapInterface")
	public String getNon_sapInterface() {
		return non_sapInterface;
	}
	public void setNon_sapInterface(String non_sapInterface) {
		this.non_sapInterface = non_sapInterface;
	}

	@Column(name = "sapModules")
	public String getSapModules() {
		return sapModules;
	}
	public void setSapModules(String sapModules) {
		this.sapModules = sapModules;
	}

	@Column(name = "indSolution")
	public String getIndSolution() {
		return indSolution;
	}
	public void setIndSolution(String indSolution) {
		this.indSolution = indSolution;
	}

	@Column(name = "fioriSetup_apps")
	public String getFioriSetup_apps() {
		return fioriSetup_apps;
	}
	public void setFioriSetup_apps(String fioriSetup_apps) {
		this.fioriSetup_apps = fioriSetup_apps;
	}

	@Column(name = "supportComponents")
	public String getSupportComponents() {
		return supportComponents;
	}
	public void setSupportComponents(String supportComponents) {
		this.supportComponents = supportComponents;
	}

	@Column(name = "sandbox_ID_instalNo")
	public String getSandbox_ID_instalNo() {
		return sandbox_ID_instalNo;
	}
	public void setSandbox_ID_instalNo(String sandbox_ID_instalNo) {
		this.sandbox_ID_instalNo = sandbox_ID_instalNo;
	}

	@Column(name = "rfc")
	public String getRfc() {
		return rfc;
	}
	public void setRfc(String rfc) {
		this.rfc = rfc;
	}

	@Column(name = "appName")
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}

	@Column(name = "central_embedded")
	public String getCentral_embedded() {
		return central_embedded;
	}
	public void setCentral_embedded(String central_embedded) {
		this.central_embedded = central_embedded;
	}

	@Column(name = "central_gateSystem")
	public String getCentral_gateSystem() {
		return central_gateSystem;
	}
	public void setCentral_gateSystem(String central_gateSystem) {
		this.central_gateSystem = central_gateSystem;
	}

	@Column(name = "sandbox_sysId")
	public String getSandbox_sysId() {
		return sandbox_sysId;
	}

	public void setSandbox_sysId(String sandbox_sysId) {
		this.sandbox_sysId = sandbox_sysId;
	}
	
	@Column(name = "oldVersion")
	public String getOldVersion() {
		return oldVersion;
	}
	public void setOldVersion(String oldVersion) {
		this.oldVersion = oldVersion;
	}

	@Column(name = "newVersion")
	public String getNewVersion() {
		return newVersion;
	}
	public void setNewVersion(String newVersion) {
		this.newVersion = newVersion;
	}
	
	@Column(name = "assigned_Poc_EmailId")
	public String getAssignedPocEmailId() {
		return assignedPocEmailId;
	}

	public void setAssignedPocEmailId(String assignedPocEmailId) {
		this.assignedPocEmailId = assignedPocEmailId;
	}

	@Column(name = "assigned_Fait_EmailId")
	public String getAssignedFaitEmailId() {
		return assignedFaitEmailId;
	}

	public void setAssignedFaitEmailId(String assignedFaitEmailId) {
		this.assignedFaitEmailId = assignedFaitEmailId;
	}

	public String getValueRFP() {
		return valueRFP;
	}

	public void setValueRFP(String valueRFP) {
		this.valueRFP = valueRFP;
	}

	public Boolean getRFP() {
		return RFP;
	}

	public void setRFP(Boolean rFP) {
		RFP = rFP;
	}	
	
	@Column(name = "SYSTEM_ENVIRONMENT")
	public String getSystemEnvt() {
		return systemEnvt;
	}

	public void setSystemEnvt(String systemEnvt) {
		this.systemEnvt = systemEnvt;
	}

	private RequestInventory requestInventory;

	@OneToOne(cascade = CascadeType.ALL)
	@PrimaryKeyJoinColumn
	public RequestInventory getRequestInventory() {
		return requestInventory;
	}

	public void setRequestInventory(RequestInventory requestInventory) {
		this.requestInventory = requestInventory;
	}
	
	  
	@Column(name = "security_Analyser", nullable = false)
	public Boolean getSia() {
		return sia;
	}

	public void setSia(Boolean sia) {
		this.sia = sia;
	}

	@Column(name = "Security_Version")
	public String getSecVer() {
		return secVer;
	}

	public void setSecVer(String secVer) {
		this.secVer = secVer;
	}
	
	private Boolean bwUsage;
	private Boolean bwTech;
	
	@Column(name = "BW_Tech", nullable = false)
	public Boolean getBwTech() {
		return bwTech;
	}

	public void setBwTech(Boolean bwTech) {
		this.bwTech = bwTech;
	}

	@Column(name = "BW_Usage", nullable = false)
	public Boolean getBwUsage() {
		return bwUsage;
	}

	public void setBwUsage(Boolean bwUsage) {
		this.bwUsage = bwUsage;
	}

	@Column(name="LICENSE_SELECTION")
	public String getLicenseSelect() {
		return licenseSelect;
	}

	public void setLicenseSelect(String licenseSelect) {
		this.licenseSelect = licenseSelect;
	}

	@Column(name="SERVICE_PROVIDER")
	public String getServiceProvider() {
		return serviceProvider;
	}

	public void setServiceProvider(String serviceProvider) {
		this.serviceProvider = serviceProvider;
	}
	
	@Column(name="EXT", nullable = false)
	public Boolean getEXT() {
		return EXT;
	}

	public void setEXT(Boolean EXT) {
		this.EXT = EXT;
	}
	@Column(name = "Market_Unit")
	public String getMarketUnit() {
		return marketUnit;
	}

	public void setMarketUnit(String marketUnit) {
		this.marketUnit = marketUnit;
	}
}
