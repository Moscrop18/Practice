package com.accenture.client.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="UploadFiles_Number")
public class UploadFilesNumber {
	
	@Id
	private long requestId;
	private int num_SRC_AGR1251;
	private int num_SRC_USOBTC;
	private int num_SRC_AGRUSERS;
	private int out_File_Cnt;
	
	public int getOut_File_Cnt() {
		return out_File_Cnt;
	}
	public void setOut_File_Cnt(int out_File_Cnt) {
		this.out_File_Cnt = out_File_Cnt;
	}
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public int getNum_SRC_AGR1251() {
		return num_SRC_AGR1251;
	}
	public void setNum_SRC_AGR1251(int num_SRC_AGR1251) {
		this.num_SRC_AGR1251 = num_SRC_AGR1251;
	}
	public int getNum_SRC_USOBTC() {
		return num_SRC_USOBTC;
	}
	public void setNum_SRC_USOBTC(int num_SRC_USOBTC) {
		this.num_SRC_USOBTC = num_SRC_USOBTC;
	}
	public int getNum_SRC_AGRUSERS() {
		return num_SRC_AGRUSERS;
	}
	public void setNum_SRC_AGRUSERS(int num_SRC_AGRUSERS) {
		this.num_SRC_AGRUSERS = num_SRC_AGRUSERS;
	}
}
