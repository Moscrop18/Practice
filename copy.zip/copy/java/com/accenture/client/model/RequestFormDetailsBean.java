package com.accenture.client.model;

import java.util.Date;

import com.accenture.utility.HANAUtility;

import javax.persistence.Column;

public class RequestFormDetailsBean {

	private long requestId;
	
	private String REQUEST_ID_UI;
	
	private String shortDescription;
	public String status;
	private String comments;
	private Long updatedDate;
	private String userName;
	private Date updatedDateDt;
	private String emailId;
	private String toolName;
	public String code;
	private Boolean trDownloadStatus;
	private Boolean deletiontrDownloadStatus; 
	private Boolean contentDownloadStatus;
	private String s4ValidationVersion;
	private Boolean s4ValidationDownloadStatus;
	private Boolean preReqDownloadStatus;
	private String endDate; 
	private Boolean s4Technical;
	private Boolean RFP;
	private String rfpStatus;
	private Boolean sia;
	private Boolean isSubRequest;
	private Long mainRequestId;
private String mainRequestIdUI;
	
	public String getMainRequestIdUI() {
		return mainRequestIdUI;
	}
	public void setMainRequestIdUI(String mainRequestIdUI) {
		this.mainRequestIdUI = mainRequestIdUI;
	}
	public Boolean getIsSubRequest() {
		return isSubRequest;
	}
	public void setIsSubRequest(Boolean isSubRequest) {
		this.isSubRequest = isSubRequest;
	}
	public Long getMainRequestId() {
		return mainRequestId;
	}
	public void setMainRequestId(Long mainRequestId) {
		this.mainRequestId = mainRequestId;
	}
	public Boolean getSia() {
		return sia;
	}
	public void setSia(Boolean sia) {
		this.sia = sia;
	}
	public String getRfpStatus() {
		return rfpStatus;
	}
	public void setRfpStatus(String rfpStatus) {
		this.rfpStatus = rfpStatus;
	}
	public Boolean getDeletiontrDownloadStatus() {
		return deletiontrDownloadStatus;
	}
	public void setDeletiontrDownloadStatus(Boolean deletiontrDownloadStatus) {
		this.deletiontrDownloadStatus = deletiontrDownloadStatus;
	}
	public Boolean getS4Technical() {
		return s4Technical;
	}
	public void setS4Technical(Boolean s4Technical) {
		this.s4Technical = s4Technical;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public Boolean getContentDownloadStatus() {
		return contentDownloadStatus;
	}
	public void setContentDownloadStatus(Boolean contentDownloadStatus) {
		this.contentDownloadStatus = contentDownloadStatus;
	}
	public Boolean getTrDownloadStatus() {
		return trDownloadStatus;
	}
	public void setTrDownloadStatus(Boolean trDownloadStatus) {
		this.trDownloadStatus = trDownloadStatus;
	}
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(final long requestId) {
		this.requestId = requestId;
	}
	
	@Column(name="REQUEST_ID_UI")
	public String getREQUEST_ID_UI() {
		return REQUEST_ID_UI;
	}
	public void setREQUEST_ID_UI(String rEQUEST_ID_UI) {
		REQUEST_ID_UI = rEQUEST_ID_UI;
	}
	

	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getShortDescription() {
		return shortDescription;
	}
	public void setShortDescription(final String shortDescription) {
		this.shortDescription = shortDescription;
	}
	public String getStatus() {
		return HANAUtility.getBusinessStatus(status);
	}
	public void setStatus(final String status) {
		this.status = status;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(final String comments) {
		this.comments = comments;
	}
	public Long getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(final Long updatedDate) {
		this.updatedDate = updatedDate;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(final String userName) {
		this.userName = userName;
	}
	
	public Date getUpdatedDateDt() {
		return updatedDate!=null ? new Date(updatedDate) : null;
	}

	public void setUpdatedDateDt(final Date updatedDateDt) {
		this.updatedDateDt = updatedDateDt;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(final String emailId) {
		this.emailId = emailId;
	}
	public String getToolName() {
		return toolName;
	}
	public void setToolName(final String toolName) {
		this.toolName = toolName;
	}
	public String getS4ValidationVersion() {
		return s4ValidationVersion;
	}
	public void setS4ValidationVersion(String s4ValidationVersion) {
		this.s4ValidationVersion = s4ValidationVersion;
	}
	public Boolean getS4ValidationDownloadStatus() {
		return s4ValidationDownloadStatus;
	}
	public void setS4ValidationDownloadStatus(Boolean s4ValidationDownloadStatus) {
		this.s4ValidationDownloadStatus = s4ValidationDownloadStatus;
	}
	public Boolean getRFP() {
		return RFP;
	}
	public void setRFP(Boolean rFP) {
		RFP = rFP;
	}
	public Boolean getPreReqDownloadStatus() {
		return preReqDownloadStatus;
	}
	public void setPreReqDownloadStatus(Boolean preReqDownloadStatus) {
		this.preReqDownloadStatus = preReqDownloadStatus;
	}
}
