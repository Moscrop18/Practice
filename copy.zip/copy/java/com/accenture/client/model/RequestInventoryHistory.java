package com.accenture.client.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity

@Table(name="REQUEST_INVENTORY_HISTORY")

public class RequestInventoryHistory {

	//public int requestInventoryID;
	private Long id;
	public long requestID;
	public String requestShortdescription;
	public String requestStatus;
	public String  trAttachementName;
	public String  deletionTRAttachementName;
  
	
	public String REQUEST_ID_UI;
	
	/*public String pendingReason;
	String rejectionComments;
	String completedStatus;*/
	String comments;
	private Boolean trDownloadStatus=false;

	
	private Long createdDate;
	
	
	private Long updatedDate;
	
	private String creatorUser;
	private String updatedUser;
	
	private String historyCreatorUser;
	private Long historyCreatedDate;
	
	public RequestInventoryHistory() {
	}
   
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID")
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	@Column(name = "REQUEST_ID")
	public long getRequestID() {
		return requestID;
	}

	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}
	
	@Column(name="HISTORY_CREATOR_USER",nullable = false)
	public String getHistoryCreatorUser() {
		return historyCreatorUser;
	}

	public void setHistoryCreatorUser(String historyCreatorUser) {
		this.historyCreatorUser = historyCreatorUser;
	}

	@Column(name="HISTORY_CREATED_DATE",nullable = false)
	public Long getHistoryCreatedDate() {
		return historyCreatedDate;
	}

	public void setHistoryCreatedDate(Long historyCreatedDate) {
		this.historyCreatedDate = historyCreatedDate;
	}
	
	
	@Column(name="CREATOR_USER",nullable = false)
	public String getCreatorUser() {
		return creatorUser;
	}

	public void setCreatorUser(String creatorUser) {
		this.creatorUser = creatorUser;
	}
	
	
	@Column(name="UPDATED_USER",nullable = false)
	public String getUpdatedUser() {
		return updatedUser;
	}

	public void setUpdatedUser(String updatedUser) {
		this.updatedUser = updatedUser;
	}
	
	
	
	
	
	
	
	@Column(name="REQUEST_SHORT_DESCRIPTION",nullable = false)
	public String getRequestShortdescription() {
		return requestShortdescription;
	}

	

	public void setRequestShortdescription(String requestShortdescription) {
		this.requestShortdescription = requestShortdescription;
	}
	
	@Column(name="REQUEST_STATUS",nullable = false)
	public String getRequestStatus() {
		return requestStatus;
	}

	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	
	}
	
	@Column(name="DELETION_TR_ATTACHMENT")
	public String getDeletionTRAttachementName() {
		return deletionTRAttachementName;
	}

	public void setDeletionTRAttachementName(String deletionTRAttachementName) {
		this.deletionTRAttachementName = deletionTRAttachementName;
	}
	
	
	
	@Column(name="TR_ATTACHMENT")
	public String getTrAttachementName() {
		return trAttachementName;
	}
	public void setTrAttachementName(String trAttachementName) {
		this.trAttachementName = trAttachementName;
	}
	
	
	
	
	@Column(name="COMMENTS" , length = 200)
	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}
	

	@Column(name="CREATED_DATE")
	public Long getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(final Long createdDate) {
		this.createdDate = createdDate;
	}
	
	@Column(name="UPDATED_DATE")
	public Long getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(final Long updatedDate) {
		this.updatedDate = updatedDate;
	}
	
	@Column(name="TR_DOWNLOAD_STATUS")
	public Boolean getTrDownloadStatus() {
		return trDownloadStatus;
	}

	public void setTrDownloadStatus(Boolean trDownloadStatus) {
		this.trDownloadStatus = trDownloadStatus;
	}

	
	@Column(name="REQUEST_ID_UI")
	public String getREQUEST_ID_UI() {
		return REQUEST_ID_UI;
	}
	public void setREQUEST_ID_UI(String rEQUEST_ID_UI) {
		REQUEST_ID_UI = rEQUEST_ID_UI;
	}

	
	
}
