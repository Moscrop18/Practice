package com.accenture.client.dao;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpSession;

import com.accenture.Aadt.models.ImpactedCloneAnalysis;
import com.accenture.client.model.RequestForm;
import com.accenture.fileprocessing.model.ComplexityGraphRules;
import com.accenture.fileprocessing.model.ExtensibilityGraphRules;
import com.accenture.fileprocessing.model.ExtensionFinder;
import com.accenture.fileprocessing.model.ExtensionOutput;
import com.accenture.fileprocessing.model.MetaData;

public interface ExtensibilityDao {

	public ExtensionFinder getMasterExtensionData(RequestForm requestForm);
	
	public List<ExtensionOutput> getExtensionOutput(Long requestId);
	
	public String ExtensionOutputBatchInsert(List<MetaData> metaDataList,String ricefFlag,
			HttpSession session) throws SQLException;

	public List<ComplexityGraphRules> getComplexityGraphRules();
	
	public List<ExtensibilityGraphRules> getExtensibilityGraphRules();
	
	public String impactedCloneBatchInsertUpdate(List<ImpactedCloneAnalysis> impactedCloneList,
			HttpSession session) throws SQLException;
	
	public List<ImpactedCloneAnalysis> getImpactedCloneList(Long REQUEST_ID) ;
	
}
