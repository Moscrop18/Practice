/* MODIFIED 
 *FOR Enhancement CR-3.0:- Remove unused fields(like Customer_namespaces,
				SPECIFIC_NAMING_CONEVNTIONS,NAMESPACE_DETAILS_FILE,NAMESPACE_DETAILS_FILE_NAME,NAMING_CONEVNTIONS_FILE,
				NAMING_CONVENTIONS_FILE_NAME) from create request form. -23/12/16 -monika.mishra 
 *				
 *CR-4.0:- Industry Group field changes from text field to drop-down. -04/01/17 -monika.mishra
 *
 *CR-9.0:- Manual upload for Estimator & assuptions -17/01/17 -monika.mishra
 *
 **CR-29.0:- Shown CDS View on basis of tables column value -5/08/17 -monika.mishra
 *
 *CR-48:- Consolidated both the tool so that they can executed separately -monika.mishra
 *
 *CR:47- Admin will activate new user account ,till that new user can't login-rohan.a.mehra
 *
 *CR:43- Client should be able to edit the existing request if it is rejected by the Admin -himani.malhotra
 *
 *CR-68- admin can change WBSE at any time after request initiation -7/05/2018 -himani.malhotra
 *
 *AADT Requirement: AUCT Implementation -11/02/2018 -himani.malhotra
 *
 *Upload Detail Report from POC -25/07/2019 -himani.malhotra
 */

package com.accenture.client.controller;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Name;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.support.ByteArrayMultipartFileEditor;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.accenture.S4.Controller.S4ProcessingController;
import com.accenture.S4.dao.DisplayGraphS4DAO;
import com.accenture.S4.models.FileStore;
import com.accenture.S4.models.S4ValidationFile;
import com.accenture.UI5.models.UI5GraphCounts;
import com.accenture.bw.dao.BwCleanUpDAO;
import com.accenture.bw.model.BwObjectTypeDateFormat;
import com.accenture.client.model.RequestForm;
import com.accenture.client.model.RequestFormDetailsBean;
import com.accenture.client.model.RequestFormFile;
import com.accenture.client.model.RequestFormModel;
import com.accenture.client.model.RequestInventory;
import com.accenture.client.model.RequestStatusMaster;
import com.accenture.client.model.UploadFilesNumber;
import com.accenture.client.model.UploadFilesNumberModel;
import com.accenture.client.service.ExtensionService;
import com.accenture.client.service.ReportGraphService;
import com.accenture.constant.File_Size_Constant;
import com.accenture.constant.Hana_Profiler_Constant;
import com.accenture.constant.ST03HanaConstant;
import com.accenture.exceptions.HibernateException;
import com.accenture.exceptions.IDVFailedException;
import com.accenture.exceptions.ReqIDNotValidException;
import com.accenture.exceptions.SignUpException;
import com.accenture.exceptions.UploadFilesNotValidException;
import com.accenture.fileprocessing.CheckFileListStatus;
import com.accenture.fileprocessing.InitialDataValidation;
import com.accenture.fileprocessing.model.ComplexityGraphRules;
import com.accenture.fileprocessing.model.ExtensibilityGraphRules;
import com.accenture.impactedBackgroundJob.ImpactedBackgroundCounts;
import com.accenture.master.ExtensionScope;
import com.accenture.master.FioriRequestMaster;
import com.accenture.master.IRPATScopeEstimatesModel;
import com.accenture.master.ProcessedRequestDetail;
import com.accenture.master.TestingScope;
import com.accenture.model.StatusMaster;
import com.accenture.poc.model.User;
import com.accenture.poc.model.UserModel;
import com.accenture.rfp.models.TADIRInventory;
import com.accenture.service.RequestIDValidateService;
import com.accenture.statictables.model.ContentFile;
import com.accenture.statictables.model.DeletionTransportRequestFile;
import com.accenture.statictables.model.TransportRequestFile;
import com.accenture.testingscope.model.CustomTcodeTable;
import com.accenture.testingscope.model.StandardTcodeTable;
import com.accenture.utility.AppGenUtility;
import com.accenture.utility.FileUtility;
import com.accenture.utility.HANAUtility;
import com.accenture.utility.RequestFormUtility;
import com.accenture.utility.SendEmail;
import com.accenture.utility.UtilityForPoc;
import com.accenture.validator.BwDateFormatValidator;
import com.accenture.validator.NumberOfUploadFilesValidator;
import com.accenture.validator.RequestFormValidator;
import com.accenture.validator.RequestID_Validator_Utility;

@Controller
@SessionAttributes("User")

public class RequestFormInputController extends S4ProcessingController {
	protected static final Logger logger = LoggerFactory.getLogger(RequestFormInputController.class);
	private static final List<RequestInventory> RequestInventory = null;

	@Resource
	private Environment environment;

	private InitialDataValidation initialDataValidation;

	final String VALID = "VALID";
	String graphTemplete = "";

	private Enumeration<String> parameterNames;

	String filename = "";
	// AADT Requirement: AUCT Implementation

	@Autowired
	ReportGraphService reportGraphService;

	@Autowired
	private RequestFormValidator validator;

	@Autowired
	private NumberOfUploadFilesValidator numUploadFilesvalidator;

	@Autowired
	private RequestIDValidateService reqIDValid;

	@Autowired
	private BwDateFormatValidator dateFormatValidator;

	@Autowired
	private BwCleanUpDAO bwCleanDao;

	@Autowired
	ExtensionService extensionService;

	@RequestMapping(value = "/signup/signupAiesDemo", method = RequestMethod.GET)
	public String signupAies(Model model, HttpServletRequest request) {

		final long requestID = 326;
		final RequestForm requestForm = getRequestDetails().getRequestObj(requestID);

		RequestInventory requestInventory = getClientRequestInventoryDAO()
				.getRequestInventory(requestForm.getRequestID());

		Map<String, String> scopeMap = new HashMap<String, String>();
		boolean scopeHana = requestForm.getSOH();
		boolean scopeS4 = requestForm.getS4Technical();
		boolean scopeFIAT = requestForm.getS4Functional();
		boolean scopeUI5 = requestForm.getUI5();
		boolean scopeFiori = requestForm.getFiori();
		boolean scopeAUCT = requestForm.getUPGRADE();
		boolean scopeOSMigration = requestForm.getOsMig();

		try {
			Map<String, ProcessedRequestDetail> reqMap = new HashMap<String, ProcessedRequestDetail>();

			// ProcessedRequestDetail reqMaster = new ProcessedRequestDetail();
			List<ProcessedRequestDetail> reqMasterList = getGraphDao().getReqMaster(requestID);
			if (!reqMasterList.isEmpty() && reqMasterList.size() > 0) {
				for (ProcessedRequestDetail req : reqMasterList) {
					reqMap.put(req.getScope(), req);
				}
				// reqMaster = reqMasterList.get(0);
			}

			TestingScope testingScopeMaster = new TestingScope();
			List<TestingScope> testingReqMasterList = getGraphDao().getTestingReqMaster(requestID);
			if (!testingReqMasterList.isEmpty() && testingReqMasterList.size() > 0) {
				testingScopeMaster = testingReqMasterList.get(0);
			}

			FioriRequestMaster fioriRequestMaster = new FioriRequestMaster();
			List<FioriRequestMaster> fioriRequestMasterList = getGraphDao().getFioriRequestMaster(requestID);
			if (!fioriRequestMasterList.isEmpty() && fioriRequestMasterList.size() > 0) {
				fioriRequestMaster = fioriRequestMasterList.get(0);
			}

			UI5GraphCounts uI5GraphMaster = new UI5GraphCounts();
			List<UI5GraphCounts> UI5GraphCountsList = getGraphDao().getUI5Master(requestID);
			if (!UI5GraphCountsList.isEmpty() && UI5GraphCountsList.size() > 0) {
				uI5GraphMaster = UI5GraphCountsList.get(0);
			}

			ImpactedBackgroundCounts impactedBackgroundCounts = new ImpactedBackgroundCounts();
			List<ImpactedBackgroundCounts> impactedBackgroundCountsList = getGraphDao()
					.getImpactedBackgroundCounts(requestID);
			if (!impactedBackgroundCountsList.isEmpty() && impactedBackgroundCountsList.size() > 0) {
				impactedBackgroundCounts = impactedBackgroundCountsList.get(0);
			}

			Map<String, HashSet<String>> StandardTcodes = getGraphDao()
					.getTestingScopeProcessTabWithoutCount(requestID);
			Map<String, String> CustomTcodes = getGraphDao().getTestingScopeProcessTabWithCount(requestID);

			Map<String, ArrayList<String>> ProbableFitmentStandardAppsCount = getGraphDao()
					.getProbableFitmentStandardAppsTable(requestID);

			if (scopeHana) {
				scopeMap.put("soh", "Impact due to HANA DB");
				ProcessedRequestDetail reqMaster = reqMap.get("Hana");

				// Slide no. 6(Hana) && 16(S4)
				model.addAttribute("ImpactedVSUsedObjects",
						reportGraphService.getImpactedVSUsedObjects(requestID, reqMaster));
				// Slide no. 7.1(Hana) && 17.1(S4)
				model.addAttribute("ImpactedABAPObjects",
						reportGraphService.getImpactedABAPObjects(requestID, reqMaster));
				// Slide no. 7.2(Hana) && 17.2(S4)
				model.addAttribute("CustomInventoryObjects",
						reportGraphService.getCustomInventoryObjects(requestID, reqMaster));
				// Slide no. 10 (Hana)
				model.addAttribute("ManNumCorErTy", reportGraphService.getManNumCorErrorTypeHana(requestID, reqMaster));
				// Slide 8.1(Hana) && Slide 18.1(S4)
				model.addAttribute("ImpactedRemediationCategoryCount",
						reportGraphService.getImpactedRemediationCategoryCount(requestID, reqMaster));
				// Slide 8.2(Hana) && Slide 18.2(S4)
				model.addAttribute("ErrorRemediationCategoryCount",
						reportGraphService.getErrorRemediationCategoryCount(requestID, reqMaster));
				// Slide 9.1 Hana
				model.addAttribute("RemediationAndCorrectionTypeCounts",
						reportGraphService.getRemediationAndCorrectionTypeCounts(requestID, reqMaster));
				// Slide 9.2 Hana
				model.addAttribute("ErrorRemediationAndCorrectionTypeCounts",
						reportGraphService.getErrorRemediationAndCorrectionTypeCounts(requestID, reqMaster));
				// Slide 12 Hana
				model.addAttribute("DBLevelHanaOptimizationCounts",
						reportGraphService.getDBLevelHanaOptimizationCounts(requestID, reqMaster));
				// Slide 13 Hana
				model.addAttribute("ApplicationLevelOptimizationCount",
						reportGraphService.getApplicationLevelOptimizationCount(requestID, reqMaster));
				// Slide14 - 2 level Hierarchial
				model.addAttribute("HouseKeepingForHANACounts",
						reportGraphService.getHouseKeepingForHANACounts(requestID, reqMaster));
				// Slide no. 11
				model.addAttribute("MandatoryCorrectionsbyIssueErrorAutomation",
						reportGraphService.getMandatoryCorrectionsByIssueErrorAutomationHana(requestID, reqMaster));
			}
			if (scopeS4) {
				scopeMap.put("s4Technical", "Simplification Technical Analysis");
				ProcessedRequestDetail reqMaster = reqMap.get("S4");
				// Slide no. 6(Hana) && 16(S4)
				model.addAttribute("S4ImpactedVSUsedObjects",
						reportGraphService.getImpactedVSUsedObjects(requestID, reqMaster));
				// Slide no. 7.1(Hana) && 17.1(S4)
				model.addAttribute("S4ImpactedABAPObjects",
						reportGraphService.getImpactedABAPObjects(requestID, reqMaster));
				// Slide no. 7.2(Hana) && 17.2(S4)
				model.addAttribute("S4CustomInventoryObjects",
						reportGraphService.getCustomInventoryObjects(requestID, reqMaster));
				// Slide 18.1(S4)
				model.addAttribute("S4ImpactedRemediationCategoryCount",
						reportGraphService.getImpactedRemediationCategoryCount(requestID, reqMaster));
				// Slide 18.2(S4)
				model.addAttribute("S4ErrorRemediationCategoryCount",
						reportGraphService.getErrorRemediationCategoryCount(requestID, reqMaster));
				// Slide 19
				model.addAttribute("FunctionalAreaObjectCount",
						reportGraphService.getFunctionalAreaObjectCount(requestID, reqMaster));
				// Slide 20.1
				model.addAttribute("RemidiIssueCatCount",
						reportGraphService.getRemidiIssueCatCount(requestID, reqMaster));
				// Slide 20.2
				model.addAttribute("RemidiIssueCatErrorCount",
						reportGraphService.getRemidiIssueCatErrorCount(requestID, reqMaster));
				// Slide 21
				model.addAttribute("SimplificationCategoryObjectCount",
						reportGraphService.getSimplificationCategoryObjectCount(requestID, reqMaster));
				// Slide 22
				model.addAttribute("RemediationCategoryCounts",
						reportGraphService.getRemediationCategoryCounts(requestID, reqMaster));
			}
			if (scopeFIAT) {
				scopeMap.put("s4Functional", "Simplification Functional Analysis");
			}

			// Testing Scope
			if (scopeHana || scopeS4 || scopeAUCT) {
				scopeMap.put("testingScope", "Testing Scope");
				try {
					model.addAttribute("ProcessObjectCount",
							reportGraphService.getTestingScopeProcessCount(requestID, testingScopeMaster));
					model.addAttribute("ProcessMasterMap",
							reportGraphService.getTestingScopeProcessMaster(requestID, testingScopeMaster));
					model.addAttribute("ProcessHeatMap",
							reportGraphService.getTestingScopeProcessCount(requestID, testingScopeMaster));
					model.addAttribute("UniqueCustomAndStandardCount",
							reportGraphService.getUniqueCustomAndStandard(requestID, testingScopeMaster));
				} catch (Exception e) {
					logger.error("Error while Testing Scope Request Master !!! ", e);
				}
			}

			// Impacted Background Job
			if (scopeHana || scopeS4 || scopeAUCT) {
				scopeMap.put("impactedBcgJob", "Impacted Background Job");
				model.addAttribute("cobj",
						reportGraphService.getImpactedBackgroundJobCounts(requestID, impactedBackgroundCounts));

			}

			if (scopeUI5) {
				scopeMap.put("ui5", "UI5 Impact Analysis");

				model.addAttribute("TotalAPICounts", reportGraphService.getTotalAPICounts(requestID, uI5GraphMaster));
				model.addAttribute("DeprecatedAPICounts",
						reportGraphService.getDeprecatedAPICounts(requestID, uI5GraphMaster));

			}
			if (scopeFiori) {
				scopeMap.put("fiori", "Fiori / OData Assement");

				model.addAttribute("IOSFAApp",
						reportGraphService.getInventoryOfStandardFioriAAppCounts(requestID, fioriRequestMaster));
				model.addAttribute("IOSFAAppTypes", reportGraphService.getIOSFAAppTypes(requestID, fioriRequestMaster));
				model.addAttribute("IOEFA", reportGraphService.getIOEFACounts(requestID, fioriRequestMaster));
				model.addAttribute("IOCFO", reportGraphService.getIOCFOCounts(requestID, fioriRequestMaster));
				model.addAttribute("IICOSManvNMan",
						reportGraphService.getIICOSManvNManCounts(requestID, fioriRequestMaster));
				model.addAttribute("IICOS", reportGraphService.getIICOSCounts(requestID, fioriRequestMaster));
				model.addAttribute("AESAHana", reportGraphService.getAESAHanaCounts(requestID, fioriRequestMaster));
				model.addAttribute("IoE", reportGraphService.getIoECounts(requestID, fioriRequestMaster));
				model.addAttribute("PFSA", reportGraphService.getPFSACounts(requestID, fioriRequestMaster));
				model.addAttribute("ProbableFitmentStandardAppsCount", ProbableFitmentStandardAppsCount);
			}
			if (scopeAUCT) {
				scopeMap.put("upgrade", "Functional Insight");
			}
			if (scopeOSMigration)
				scopeMap.put("osMigration", "OS Migration");
		} catch (Exception e) {
			logger.error("Error in signupAies" , e);
		}

		model.addAttribute("requestID", requestID);
		model.addAttribute("requestIdUI", requestForm.getREQUEST_ID_UI());
		model.addAttribute("RequestStatus", requestInventory.getRequestStatus());
		model.addAttribute("ScopeMap", scopeMap);

		return "client/viewReportsAies";
	}

	@RequestMapping(value = "/client/requestForm", method = RequestMethod.GET)
	public String loadRequestFrom(Model model, HttpSession session) {

		String toolName = (String) session.getAttribute("tool");

		model.addAttribute("ClientRequestForm", new RequestFormModel());
		// CR-4.0: Adding List to model.
		model.addAttribute("IGList", RequestFormUtility.getIGList());
		model.addAttribute("SubIGList", RequestFormUtility.getSubIGList());
		model.addAttribute("Ui5Version", RequestFormUtility.getUi5Version());
		model.addAttribute("sourceVersionList", RequestFormUtility.getSourceVersion());
		model.addAttribute("targetVersionList", RequestFormUtility.getTargetVersion());
		model.addAttribute("sourceOSVersionList", RequestFormUtility.getSourceOSVersion());
		model.addAttribute("targetOSVersionList", RequestFormUtility.getTargetOSVersion());
		model.addAttribute("objectList", RequestFormUtility.getObjectList());
		model.addAttribute("sysEnvtList", RequestFormUtility.getSystemEnvtList());
		model.addAttribute("ewaSize", File_Size_Constant.FIAT_DOC_SIZE);
		model.addAttribute("sizingReportSize", File_Size_Constant.FIAT_TXT_SIZE);
		model.addAttribute("otherSize", File_Size_Constant.FIAT_OTHER_SIZE);

		return "client/requestForm";

	}

	@RequestMapping(value = "/requestFormDisplay/{requestID}", method = RequestMethod.GET)
	public String loadRequestFromDisplay(@PathVariable("requestID") final long requestId, final Model model,
			final RedirectAttributes redirectAttributes) {
		try {
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestId));
			RequestID_Validator_Utility.chckReqIdUser(reqIDValid.getCreator(reqIDValid.getRequestInv(requestId)),
					getPrincipal());
			model.addAttribute("requestID", requestId);

			if (model.asMap() == null || model.asMap().get("SucessMsg") == null) {
				RequestInventory requestInventory = getClientRequestInventoryDAO().getRequestInventory(requestId);
				model.addAttribute("requestInventory", requestInventory);
				model.addAttribute("requestForm", getRequestDetails().getRequestObj(requestId));
				model.addAttribute("SucessMsg", "Request Form with requestID "
						+ requestInventory.getREQUEST_ID_UI().toUpperCase() + " Submited Succesfully");
			}
		} catch (ReqIDNotValidException ex) {
			model.addAttribute("errorMsg", ex.getMessage());
			return "errors";
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return "requestFormDisplay";
	}

	@RequestMapping(value = "/client/submitRequest", method = RequestMethod.POST)
	public String submitRequestForm(@ModelAttribute("ClientRequestForm") RequestFormModel requestFormModel,
			BindingResult result, Model model, HttpServletRequest servletRequest,
			final RedirectAttributes redirectAttributes, HttpServletRequest request, HttpSession session)
			throws Exception {

		validator.validate(requestFormModel, result);
		if (result.hasErrors()) {
			logger.info("Returning requestForm.jsp page -- Server Side Validation Fails");

			model.addAttribute("IGList", RequestFormUtility.getIGList());
			model.addAttribute("SubIGList", RequestFormUtility.getSubIGList());
			model.addAttribute("Ui5Version", RequestFormUtility.getUi5Version());
			model.addAttribute("sourceVersionList", RequestFormUtility.getSourceVersion());
			model.addAttribute("targetVersionList", RequestFormUtility.getTargetVersion());
			model.addAttribute("sourceOSVersionList", RequestFormUtility.getSourceOSVersion());
			model.addAttribute("targetOSVersionList", RequestFormUtility.getTargetOSVersion());
			model.addAttribute("objectList", RequestFormUtility.getObjectList());
			model.addAttribute("sysEnvtList", RequestFormUtility.getSystemEnvtList());

			return "client/requestForm";
		}

		RequestForm requestForm = prepareRequestFormModel(requestFormModel);

		try {
			String emailContext = "";
			String toolName = (String) session.getAttribute("tool");

			requestForm.setToolName(toolName);

			final String userName = getPrincipal();

			String requestIdUi = requestIdUIGenerator(requestForm);
			requestForm.setREQUEST_ID_UI(requestIdUi);

			// For Saving the request Form in DataBase
			logger.info("Before the process of saving the form in the DB ...");
			getRequestDetails().saveRequestForm(requestForm, userName, toolName);
			logger.info("Saved the form in the DB ...");

			Long requestId = requestForm.getRequestID();

			if (requestForm.getS4Functional()) {
				RequestFormFile requestFormFile = prapareRequestFormFile(requestFormModel);
				requestFormFile.setRequestID(requestId);
				requestFormFile.setREQUEST_ID_UI(requestIdUi);

				logger.info("Saving files in the DB for FAIT");
				getRequestDetails().saveRequestFormFile(requestFormFile);
				logger.info("Saved the File form in the DB");
			}

			if (requestForm.getRFP()) {
				TADIRInventory tadirInv = preapreTADIRInv(requestFormModel);
				tadirInv.setRequestID(requestId);
				getRequestDetails().saveTadirForm(tadirInv);
			}
			
			// Saving the Request Status Master Data
			RequestStatusMaster reqStatusMaster = new RequestStatusMaster();
			reqStatusMaster.setRequestId(requestId);
			getRequestDetails().saveReqStatusMaster(reqStatusMaster);

			emailContext = "https://" + servletRequest.getServerName() + ":" + servletRequest.getServerPort();
			getPocRequestMappingdao().addClientData(requestForm.getRequestID(), userName, requestIdUi, toolName);

			RequestInventory requestInventory = getClientRequestInventoryDAO()
					.getRequestInventory(requestForm.getRequestID());
			redirectAttributes.addFlashAttribute("requestInventory", requestInventory);
			redirectAttributes.addFlashAttribute("SucessMsg",
					"Request Form with requestID " + requestIdUi + " Submited Succesfully");
			Set<String> emailData = new HashSet<String>();
			Set<String> emailCc = new HashSet<String>();
			SendEmail email = new SendEmail();
			email.setMailFrom("IDC_SAPUpgrade_Sales@accenture.com");

			emailData.add(getEmailIDDao().getEmail(userName));
			emailCc.add("IDC_SAPUpgrade_Sales@accenture.com");
			email.setMailTo(emailData);
			email.setMailCC(emailCc);
			email.setMailSubject("Request ID : " + requestForm.getREQUEST_ID_UI() + " Created Successfully");
			email.setMailBody("\n\nDear " + userName + ",\n\nYour Request Has Been Submitted Successfully With ID : "
					+ requestForm.getREQUEST_ID_UI() + " . Kindly Note It For Your Future References.\n\n" + "<a href="
					+ emailContext + "/hanaprofilerperformance/client/requestDetails/" + requestForm.getRequestID()
					+ ">Client - View Request Detail</a>\n\n" + "<a href=" + emailContext
					+ "/hanaprofilerperformance/requestDetails/" + requestForm.getRequestID()
					+ ">Admin/Poc - View Request Detail</a>" + "\n\nRegards,\nS/4HANA conversion Team ATCI");
			email.emailSend(email, request, session);

		} catch (HibernateException e) {
			logger.error("Error in submitRequestForm " , e);
			getRequestDetails().deleteRequestFormdata(requestForm.getRequestID());
			return "requestFormDisplayError";
		}

		model.addAttribute("requestID", requestForm.getREQUEST_ID_UI());
		model.addAttribute("Status", "Pending Approval");

		return "client/display";
	}

	@RequestMapping(value = "/client/updateRequestform/{requestID}", method = RequestMethod.GET)
	public String loadRequestUpdateForm(@PathVariable("requestID") final long requestId,
			@RequestParam(value = "action", required = false) String action, Model model, HttpSession session,
			RedirectAttributes redirectAttributes) {
		logger.info("Coming inside method to update::::::::::::::::::::");
		String toolName = (String) session.getAttribute("tool");
		model.addAttribute("requestID", requestId);
		model.addAttribute("UpdateRequestForm", new RequestFormModel());

		model.addAttribute("IGList", RequestFormUtility.getIGList());
		model.addAttribute("sourceVersionList",
				getTransportRequestDAO().getVersionList(Hana_Profiler_Constant.SOURCE_VERSION, toolName));
		model.addAttribute("targetVersionList",
				getTransportRequestDAO().getVersionList(Hana_Profiler_Constant.TARGET_VERSION, toolName));

		if (model.asMap() == null || model.asMap().get("SucessMsg") == null) {
			model.addAttribute("requestForm", getRequestDetails().getRequestObj(requestId));
		}
		return "client/updateRequestform";

	}

	private RequestForm prepareRequestFormModel(RequestFormModel rfm) {
		boolean SOH = false, S4Functional = false, UPGRADE = false, S4Technical = false, Fiori = false, UI5 = false,
				RFP = false, SIA = false, BW = false, OSMIG = false, GRC = false;
		;
		boolean EXT = false;
		RequestForm rf = new RequestForm();

		rf.setClientName(rfm.getClientName());
		rf.setClientTeamDetails(rfm.getClientTeamDetails());
		rf.setClienttype(rfm.getClienttype());
		rf.setCurrencyType(rfm.getCurrencyType());
		rf.setCustomerNamespace(rfm.getCustomerNamespace());
		rf.setExternalNamespace(rfm.getExternalNamespace());
		rf.setDatabaseDB(rfm.getDatabaseDB());
		rf.setDbSize(rfm.getDbSize());
		rf.setDealSize(rfm.getDealSize());
		if (rfm.getWBSE().equalsIgnoreCase("REQUESTED"))
			rf.setWbsCode("WBSE REQUESTED");
		else
			rf.setWbsCode(rfm.getWbsCode());
		rf.setSystemEnvt(rfm.getSystemEnvt());
		rf.setSystemId(rfm.getSystemId());
		rf.setSourceVersion(rfm.getSourceVersion());
		rf.setIndustryGroup(rfm.getIndustryGroup());
		rf.setIndustrySubGroup(rfm.getIndustrySubGroup());
		rf.setInstalNo(rfm.getInstalNo());
		rf.setAppServer(rfm.getAppServer());
		rf.setSupportedAtci(rfm.getSupportedAtci());
		rf.setNumberOfUsers(rfm.getNumberOfUsers());
		rf.setNumberOtherSystem(rfm.getNumberOtherSystem());
		rf.setNumberProduction(rfm.getNumberProduction());
		rf.setNumberQuality(rfm.getNumberQuality());
		rf.setNumberDevelopment(rfm.getNumberDevelopment());
		rf.setSandbox(rfm.getSandbox());
		rf.setPocName(rfm.getPocName());
		rf.setProjectName(rfm.getProjectName());
		rf.setProjectPocId(rfm.getProjectPocId());
		rf.setHost(rfm.getHost());
		rf.setEndDate(rfm.getEndDate());
		rf.setStartDate(rfm.getStartDate());
		rf.setUnicodeCompliant(rfm.getUnicodeCompliant());
		rf.setSap_NonSAPcomponents(rfm.getSap_NonSAPcomponents());
		rf.setSapClientId(rfm.getSapClientId());
		rf.setSystemType(rfm.getSystemType());
		rf.setTargetVersion(rfm.getTargetVersion());
		rf.setCVIT(false);
		rf.setWBSE(rfm.getWBSE());
		rf.setSrcOSVer(rfm.getSrcOSVer());
		rf.setTarOSVer(rfm.getTarOSVer());
		rf.setEnableUnicode(rfm.getEnableUnicode());
		rf.setUnicodeCompliant(rfm.getUnicodeCompliant());
		rf.setScope(rfm.getScope());

		if (rfm.getScope().contains("SOH"))
			SOH = true;
		if (rfm.getScope().contains("S4Functional"))
			S4Functional = true;
		if (rfm.getScope().contains("UPGRADE"))
			UPGRADE = true;
		if (rfm.getScope().contains("S4Technical"))
			S4Technical = true;
		if (rfm.getScope().contains("Fiori"))
			Fiori = true;
		if (rfm.getScope().contains("UI5"))
			UI5 = true;
		if (rfm.getScope().contains("RFP"))
			RFP = true;
		if (rfm.getScope().contains("SIA"))
			SIA = true;
		if (rfm.getScope().contains("OSMigration"))
			OSMIG = true;
		if (rfm.getScope().contains("BW"))
			BW = true;
		if (rfm.getScope().contains("GRC"))
			GRC = true;
		if (rfm.getScope().contains("EXT"))
			EXT = true;
		rf.setSOH(SOH);
		rf.setS4Functional(S4Functional);
		rf.setS4Technical(S4Technical);
		rf.setUPGRADE(UPGRADE);
		rf.setFiori(Fiori);
		rf.setUI5(UI5);
		rf.setRFP(RFP);
		rf.setSia(SIA);
		rf.setOsMig(OSMIG);
		rf.setGrc(GRC);
		rf.setBwTech(rfm.isBw_tech());
		rf.setBwUsage(rfm.isBw_use());
		rf.setEXT(EXT);

		if (SIA) {
			if (rfm.getTargetVersion().startsWith("S/4HANA"))
				// SIA
				rf.setSecVer(rfm.getTargetVersion().split("S/4HANA")[1]);
			else
				rf.setSecVer("");
		}
		if(S4Technical) {
			rf.setFle(rfm.getFle_e());
			rf.setAle(rfm.getAle_e());
		}else {
			rf.setFle("NA");
			rf.setAle("NA");
		}

		if (RFP) {
			rf.setValueRFP(rfm.getValueRFP());
		} else {
			rf.setValueRFP("NA");
		}

		if (Fiori) {
			rf.setCentral_embedded(rfm.getCentral_embedded());
			rf.setCentral_gateSystem(rfm.getCentral_gateSystem());
		} else {
			rf.setCentral_embedded("NA");
			rf.setCentral_gateSystem("NA");
		}

		if (UI5) {
			rf.setRfc(rfm.getRfc());
			rf.setAppName(rfm.getAppName());
			rf.setOldVersion(rfm.getOldVersion());
			rf.setNewVersion(rfm.getNewVersion());
		} else {
			rf.setRfc("NA");
			rf.setAppName("NA");
			rf.setOldVersion("NA");
			rf.setNewVersion("NA");
		}

		if (S4Functional) {
			rf.setSapInterface(rfm.getSapInterface());
			rf.setNon_sapInterface(rfm.getNon_sapInterface());
			rf.setSapModules(rfm.getSapModules());
			rf.setIndSolution(rfm.getIndSolution());
			rf.setSupportComponents(rfm.getSupportComponents());
			rf.setFioriSetup_apps(rfm.getFioriSetup_apps());
			rf.setSandbox_ID_instalNo(rfm.getSandbox_ID_instalNo());
			rf.setSandbox_sysId(rfm.getSandbox_sysId());
		} else {
			rf.setSapInterface("NA");
			rf.setNon_sapInterface("NA");
			rf.setSapModules("NA");
			rf.setIndSolution("NA");
			rf.setFioriSetup_apps("NA");
			rf.setSupportComponents("NA");
			rf.setSandbox_ID_instalNo("NA");
			rf.setSandbox_sysId("NA");
		}
		if (EXT) {
			rf.setLicenseSelect(rfm.getLicenseSelect());
			rf.setServiceProvider(rfm.getServiceProvider());
		} else {
			rf.setLicenseSelect("NA");
			rf.setServiceProvider("NA");
		}

		return rf;
	}

	private RequestFormFile prapareRequestFormFile(RequestFormModel requestFormModel) throws IOException {
		RequestFormFile reqFormFile = new RequestFormFile();
		reqFormFile.setFiatFile1(requestFormModel.getFiatEWAFile().getBytes());
		reqFormFile.setFiatFile2(requestFormModel.getFiatSizingRptFile().getBytes());
		reqFormFile.setFiatFile3(requestFormModel.getFiatOtherFile().getBytes());
		reqFormFile.setEwaFile1Name(requestFormModel.getFiatEWAFile().getOriginalFilename());
		reqFormFile.setSizingReportFile2Name(requestFormModel.getFiatSizingRptFile().getOriginalFilename());
		reqFormFile.setOtherFile3Name(requestFormModel.getFiatOtherFile().getOriginalFilename());
		return reqFormFile;

	}

	private TADIRInventory preapreTADIRInv(RequestFormModel requestFormModel) {
		TADIRInventory tadirInv = new TADIRInventory();

		tadirInv.setRicefwCount(requestFormModel.getRicefwCount());
		tadirInv.setFunctionGroups(requestFormModel.getFunctionGroups());
		tadirInv.setClasses(requestFormModel.getClasses());
		tadirInv.setEnhancements(requestFormModel.getEnhancements());
		tadirInv.setInterfaces(requestFormModel.getInterfaces());
		tadirInv.setForm(requestFormModel.getForm());
		tadirInv.setLsmw(requestFormModel.getLsmw());
		tadirInv.setPrograms(requestFormModel.getPrograms());
		tadirInv.setUserExists(requestFormModel.getUserExists());
		tadirInv.setWebDynpro(requestFormModel.getWebDynpro());
		tadirInv.setWorkflow(requestFormModel.getWorkflow());

		return tadirInv;
	}

	private User prepareUserModel(UserModel um) {
		User u = new User();
		u.setClientName(um.getClientName());
		u.setConfirmPassword(um.getConfirmPassword());
		u.setCreatedOn(um.getCreatedOn());
		u.setCurrentPassword(um.getCurrentPassword());
		u.setEmailId(um.getEmailId());
		u.setPassword(um.getPassword());
		u.setPocRequestMapping(um.getPocRequestMapping());
		u.setProjectName(um.getProjectName());
		u.setReject(um.getReject());
		u.setReset(um.getReset());
		u.setRolesAccess(um.getRolesAccess());
		u.setUserName(um.getUserName());
		u.setUserRole(um.getUserRole());
		u.setUserRoleValue(um.getUserRoleValue());
		u.setValidTill(um.getValidTill());

		return u;
	}

	@InitBinder
	protected void initBinder(ServletRequestDataBinder binder) {
		binder.registerCustomEditor(byte[].class, new ByteArrayMultipartFileEditor());
	}

	@RequestMapping(value = "/client/downloadTransportRequestFile/{requestID}", method = RequestMethod.GET)
	public String downloadTransportRequestFile(@PathVariable("requestID") Long requestID, Model model,
			HttpServletResponse response, final RedirectAttributes redirectAttributes, final HttpSession session)
			throws Exception {
		try {
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestID));
			RequestID_Validator_Utility.chckReqIdUser(reqIDValid.getCreator(reqIDValid.getRequestInv(requestID)),
					getPrincipal());

			TransportRequestFile transportRequest = getTransportRequestDAO().getNewTRobj(requestID);

			byte[] fileBytes = transportRequest.getTrFile();
			String fileName = transportRequest.getTrFileName();

			boolean Status = getClientRequestInventoryDAO().getTrDownloadStatus(requestID);

			if (Status) {
				return "redirect:/client/dashboardTR";
			}

			String message = getFileDownload().downloadFile(fileBytes, response, fileName);
			if (message == null || message.isEmpty()) {
				getClientRequestInventoryDAO().setTrDownloadStatus(requestID, true);
			}

			return "redirect:/client/dashboardTR";
		} catch (IOException e) {
			logger.trace(e.getMessage());
			return "redirect:/client/dashboardTR";
		} catch (ReqIDNotValidException ex) {
			model.addAttribute("errorMsg", ex.getMessage());
			return "errors";
		}
	}

	@RequestMapping(value = "/client/downloadDeletionTransportRequestFile/{requestID}", method = RequestMethod.GET)
	public String downloadDeletionTransportRequestFile(@PathVariable("requestID") Long requestID, Model model,
			HttpServletResponse response, final RedirectAttributes redirectAttributes, final HttpSession session)
			throws Exception {
		try {
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestID));
			RequestID_Validator_Utility.chckReqIdUser(reqIDValid.getCreator(reqIDValid.getRequestInv(requestID)),
					getPrincipal());

			DeletionTransportRequestFile transportRequest = getTransportRequestDAO().getNewDelTRobj(requestID);

			byte[] fileBytes = transportRequest.getTrFile();
			String fileName = transportRequest.getTrFileName();

			boolean Status = getClientRequestInventoryDAO().getDelTrDownloadStatus(requestID);

			if (Status) {
				return "redirect:/client/dashboardTR";
			}

			String message = getFileDownload().downloadFile(fileBytes, response, fileName);
			if (message == null || message.isEmpty()) {
				getClientRequestInventoryDAO().setDelTrDownloadStatus(requestID, true);
			}

			return "redirect:/client/dashboardTR";
		} catch (IOException e) {
			logger.trace(e.getMessage());
			return "redirect:/client/dashboardTR";
		} catch (ReqIDNotValidException ex) {
			model.addAttribute("errorMsg", ex.getMessage());
			return "errors";
		}
	}

	@RequestMapping(value = "/client/downloadValidationFile/{requestID}", method = RequestMethod.GET)
	public String downloadValidationFile(@PathVariable("requestID") Long requestID, Model model,
			HttpServletResponse response, final RedirectAttributes redirectAttributes, final HttpSession session)
			throws Exception {
		try {
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestID));
			RequestID_Validator_Utility.chckReqIdUser(reqIDValid.getCreator(reqIDValid.getRequestInv(requestID)),
					getPrincipal());

			S4ValidationFile validationFile = getS4ValidDao().getNewValidationobj(requestID);

			byte[] fileBytes = validationFile.getValidationFile();
			String fileName = validationFile.getValidationFileName();

			boolean Status = getS4ValidDao().getFileDownloadStatus(requestID, "VALIDATION");

			if (Status) {
				return "redirect:/client/dashboardTR";
			}

			String message = getFileDownload().downloadFile(fileBytes, response, fileName);
			if (message == null || message.isEmpty()) {
				getS4ValidDao().setValidationDownloadStatus(requestID, true);
			}

			return "redirect:/client/dashboardTR";
		} catch (IOException e) {
			logger.trace(e.getMessage());
			return "redirect:/client/dashboardTR";
		} catch (ReqIDNotValidException ex) {
			model.addAttribute("errorMsg", ex.getMessage());
			return "errors";
		}
	}

	@RequestMapping(value = "/client/downloadPreRequisiteFile/{requestID}", method = RequestMethod.GET)
	public String downloadPreRequisiteFile(@PathVariable("requestID") Long requestID, Model model,
			HttpServletResponse response, final RedirectAttributes redirectAttributes, final HttpSession session)
			throws Exception {
		try {
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestID));
			RequestID_Validator_Utility.chckReqIdUser(reqIDValid.getCreator(reqIDValid.getRequestInv(requestID)),
					getPrincipal());

			String fileNameKey = "'PR'";
			FileStore fileStore = getS4ValidDao().getFileFromFileStoreTable(fileNameKey);

			byte[] fileBytes = fileStore.getFileContent();
			String fileName = fileStore.getFileName();

			boolean Status = getS4ValidDao().getFileDownloadStatus(requestID, "PREREQUISITE");

			if (Status) {
				return "redirect:/client/dashboardTR";
			}

			String message = getFileDownload().downloadFile(fileBytes, response, fileName);
			if (message == null || message.isEmpty()) {
				getS4ValidDao().setPreRequisiteDownloadStatus(requestID, true);
			}

			return "redirect:/client/dashboardTR";
		} catch (IOException e) {
			logger.trace(e.getMessage());
			return "redirect:/client/dashboardTR";
		} catch (ReqIDNotValidException ex) {
			model.addAttribute("errorMsg", ex.getMessage());
			return "errors";
		}
	}

	@RequestMapping(value = "/client/downloadContentFile/{requestID}", method = RequestMethod.GET)
	public String downloadContentFile(@PathVariable("requestID") Long requestID, Model model,
			HttpServletResponse response, final RedirectAttributes redirectAttributes, final HttpSession session)
			throws Exception {
		try {
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestID));
			RequestID_Validator_Utility.chckReqIdUser(reqIDValid.getCreator(reqIDValid.getRequestInv(requestID)),
					getPrincipal());

			ContentFile contentFile = getTransportRequestDAO().getContentFileobj(requestID);

			byte[] fileBytes = contentFile.getContentFile();
			String fileName = contentFile.getContentFileName();

			boolean Status = getClientRequestInventoryDAO().getContentDownloadStatus(requestID);

			if (Status) {
				return "redirect:/client/dashboardTR";
			}

			String message = getFileDownload().downloadFile(fileBytes, response, fileName);
			if (message == null || message.isEmpty()) {
				getClientRequestInventoryDAO().setContentDownloadStatus(requestID, true);

			}

			return "redirect:/client/dashboardTR";
		} catch (IOException e) {
			logger.trace(e.getMessage());
			return "redirect:/client/dashboardTR";
		} catch (ReqIDNotValidException ex) {
			model.addAttribute("errorMsg", ex.getMessage());
			return "errors";
		}
	}

	@RequestMapping(value = "/client/dashboardTR", method = RequestMethod.GET)
	public String downloadTRFile(Model model) {

		return "redirect:/client/dashboard";
	}

	@ExceptionHandler(value = { NumberFormatException.class, BindException.class })
	public String handleException(HttpServletRequest req, BindException be, NumberFormatException e) {
		logger.info("Inside Exception handler");

		return "error.invalidNumberFormat";
	}

	@ExceptionHandler(value = Exception.class)
	public String handleGenericException(HttpServletRequest request, Exception ex) {

		logger.info("Inside Exception handler");
		logger.info(request.getRequestURL().toString());
		logger.error("Error handleGenericException " , ex);
		return ex.getMessage();
	}

	@RequestMapping(value = "/client/numberFilesUpload/{requestID}", method = RequestMethod.GET)
	public String numberFilesUpload(@PathVariable("requestID") long requestID,
			final RedirectAttributes redirectAttributes, Model model, final HttpServletRequest request,
			final HttpSession session) {
		final RequestForm requestForm = getRequestDetails().getRequestObj(requestID);
		final RequestInventory requestInventory = getClientRequestInventoryDAO().getRequestInventory(requestID);
		try {
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestID));
			RequestID_Validator_Utility.chckReqIdUser(reqIDValid.getCreator(reqIDValid.getRequestInv(requestID)),
					getPrincipal());
			boolean reqScope = requestForm.getSia() || requestForm.getBwUsage();
			boolean reqStatus = requestInventory.getRequestStatus().equalsIgnoreCase("Approved");
			if (reqScope && reqStatus) {
				if (requestForm.getSia() && reqStatus) {
					model.addAttribute("numberFilesUpload", new UploadFilesNumberModel());
					model.addAttribute("filesToBeUploadedList", RequestFormUtility.getFilesToBeUploadedList());
					model.addAttribute("requestIDUI", requestForm.getREQUEST_ID_UI());
					model.addAttribute("SIA", "SIA");
				}

				if (requestForm.getBwUsage() && reqStatus) {
					model.addAttribute("numberFilesUpload", new UploadFilesNumberModel());
					model.addAttribute("fileNameAndDateFormat", RequestFormUtility.getBwObjectsAndFileName());
					model.addAttribute("sourceVersion", requestForm.getSourceVersion());
					model.addAttribute("requestIDUI", requestForm.getREQUEST_ID_UI());
					model.addAttribute("BW", "BW_Usage");
				}
				return "client/numberFilesUpload";
			} else {
				return "redirect:/client/uploadFiles/{requestID}";
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			model.addAttribute("errorMsg", e.getMessage());
			return "errors";
		}
	}

	@RequestMapping(value = "/client/saveUploadFilesNumber/{requestID}", method = RequestMethod.POST)
	public String saveNumUploadFiles(@ModelAttribute("numberFilesUpload") UploadFilesNumberModel uploadFilesNumModel,
			BindingResult result, @PathVariable("requestID") long requestID, Model model,
			RedirectAttributes redirectAttributes) {
		boolean siaHasError = false;
		boolean bwHasError = false;
		boolean bwHasSelError = false;
		boolean bwHasDtDiffError = false;
		final RequestForm requestForm = getRequestDetails().getRequestObj(requestID);
		if (requestForm.getSia()) {
			numUploadFilesvalidator.validate(uploadFilesNumModel, result);
			if (result.hasErrors()) {
				siaHasError = true;
			}

			UploadFilesNumber uploadFileNum = new UploadFilesNumber();
			uploadFileNum.setRequestId(requestID);
			uploadFileNum.setNum_SRC_AGR1251(uploadFilesNumModel.getNum_SRC_AGR1251());
			uploadFileNum.setNum_SRC_AGRUSERS(uploadFilesNumModel.getNum_SRC_AGRUSERS());
			uploadFileNum.setNum_SRC_USOBTC(uploadFilesNumModel.getNum_SRC_USOBTC());
			getRequestDetails().saveUploadFilesNumber(uploadFileNum);
		}
		if (requestForm.getBwUsage()) {
			boolean chkFlag = dateFormatValidator.checkDateFormatNotEmptyAndValid(uploadFilesNumModel);
			if (!chkFlag) {
				bwHasError = true;
			}
			boolean chkFlgSel = dateFormatValidator.validateTheAtleastOneObjSelection(uploadFilesNumModel);
			if (!chkFlgSel) {
				bwHasSelError = true;
			}
			boolean chkSameDt = dateFormatValidator.checkDiffInDtFormatForSameInputFiles(uploadFilesNumModel);
			if (!chkSameDt) {
				bwHasDtDiffError = true;
			}
			boolean odso = false, iobj = false, cube = false, mpro = false, iset = false, odh = false, anpr = false,
					adso = false, hrpr = false, trfn = false, updr = false, ists = false, rsds = false, ismp = false,
					isip = false, dtpa = false, elem = false, xlwb = false, btmp = false, tmpl = false, rspc = false;
			BwObjectTypeDateFormat bwDateFormat = new BwObjectTypeDateFormat();
			if (StringUtils.isNotBlank(uploadFilesNumModel.getDt_BIOAPERS_SOD00Web_Application_Design3x())
					&& !StringUtils.equalsIgnoreCase("noValSelect",
							uploadFilesNumModel.getDt_BIOAPERS_SOD00Web_Application_Design3x())
					&& uploadFilesNumModel.getObjscope().contains("Web_Application_Design3x"))
				bwDateFormat.setBioapersSod00(uploadFilesNumModel.getDt_BIOAPERS_SOD00Web_Application_Design3x());
			if (StringUtils.isNotBlank(uploadFilesNumModel.getDt_BIOAPERS_SOD00Web_Application_Design7x())
					&& !StringUtils.equalsIgnoreCase("noValSelect",
							uploadFilesNumModel.getDt_BIOAPERS_SOD00Web_Application_Design7x())
					&& uploadFilesNumModel.getObjscope().contains("Web_Application_Design7x"))
				bwDateFormat.setBioapersSod00(uploadFilesNumModel.getDt_BIOAPERS_SOD00Web_Application_Design7x());
			if (StringUtils.isNotBlank(uploadFilesNumModel.getDt_RSANT_PROCESSRAnalysis_Process_Designer())
					&& !StringUtils.equalsIgnoreCase("noValSelect",
							uploadFilesNumModel.getDt_RSANT_PROCESSRAnalysis_Process_Designer())
					&& uploadFilesNumModel.getObjscope().contains("APD"))
				bwDateFormat.setRsantProcessr(uploadFilesNumModel.getDt_RSANT_PROCESSRAnalysis_Process_Designer());
			if (StringUtils.isNotBlank(uploadFilesNumModel.getDt_RSBKREQUESTOpen_Hub_Destination())
					&& !StringUtils.equalsIgnoreCase("noValSelect",
							uploadFilesNumModel.getDt_RSBKREQUESTOpen_Hub_Destination())
					&& uploadFilesNumModel.getObjscope().contains("Open_Hub_Destination"))
				bwDateFormat.setRsbkrequest(uploadFilesNumModel.getDt_RSBKREQUESTOpen_Hub_Destination());
			if (StringUtils.isNotBlank(uploadFilesNumModel.getDt_RSICCONTODSO())
					&& !StringUtils.equalsIgnoreCase("noValSelect", uploadFilesNumModel.getDt_RSICCONTODSO())
					&& uploadFilesNumModel.getObjscope().contains("ODSO"))
				bwDateFormat.setRsiccont(uploadFilesNumModel.getDt_RSICCONTODSO());
			if (StringUtils.isNotBlank(uploadFilesNumModel.getDt_RSICCONTInfocube())
					&& !StringUtils.equalsIgnoreCase("noValSelect", uploadFilesNumModel.getDt_RSICCONTInfocube())
					&& uploadFilesNumModel.getObjscope().contains("Infocube"))
				bwDateFormat.setRsiccont(uploadFilesNumModel.getDt_RSICCONTInfocube());
			if (StringUtils.isNotBlank(uploadFilesNumModel.getDt_RSPCPROCESSLOGProcess_Chain())
					&& !StringUtils.equalsIgnoreCase("noValSelect",
							uploadFilesNumModel.getDt_RSPCPROCESSLOGProcess_Chain())
					&& uploadFilesNumModel.getObjscope().contains("Process_Chain"))
				bwDateFormat.setRspcprocesslog(uploadFilesNumModel.getDt_RSPCPROCESSLOGProcess_Chain());
			if (StringUtils.isNotBlank(uploadFilesNumModel.getDt_RSRREPDIRBEX_Queries())
					&& !StringUtils.equalsIgnoreCase("noValSelect", uploadFilesNumModel.getDt_RSRREPDIRBEX_Queries())
					&& uploadFilesNumModel.getObjscope().contains("BEX_Queries"))
				bwDateFormat.setRsrrepdir(uploadFilesNumModel.getDt_RSRREPDIRBEX_Queries());
			if (StringUtils.isNotBlank(uploadFilesNumModel.getDt_RSRREPDIRBEX_Workbook())
					&& !StringUtils.equalsIgnoreCase("noValSelect", uploadFilesNumModel.getDt_RSRREPDIRBEX_Workbook())
					&& uploadFilesNumModel.getObjscope().contains("BEX_Workbook"))
				bwDateFormat.setRsrrepdir(uploadFilesNumModel.getDt_RSRREPDIRBEX_Workbook());
			bwDateFormat.setRequestId(requestID);
			if (uploadFilesNumModel.getObjscope().contains("ODSO")) {
				odso = true;
				bwDateFormat.setOdso(odso);
			} else {
				bwDateFormat.setOdso(odso);
			}
			if (uploadFilesNumModel.getObjscope().contains("InfoObject")) {
				iobj = true;
				bwDateFormat.setIobj(iobj);
			} else {
				bwDateFormat.setIobj(iobj);
			}
			if (uploadFilesNumModel.getObjscope().contains("Infocube")) {
				cube = true;
				bwDateFormat.setCuba(cube);
			} else {
				bwDateFormat.setCuba(cube);
			}
			if (uploadFilesNumModel.getObjscope().contains("Multiprovider")) {
				mpro = true;
				bwDateFormat.setMpro(mpro);
			} else {
				bwDateFormat.setMpro(mpro);
			}
			if (uploadFilesNumModel.getObjscope().contains("InfoSet")) {
				iset = true;
				bwDateFormat.setIset(iset);
			} else {
				bwDateFormat.setIset(iset);
			}
			if (uploadFilesNumModel.getObjscope().contains("Open_Hub_Destination")) {
				odh = true;
				bwDateFormat.setOdh(odh);
			} else {
				bwDateFormat.setOdh(odh);
			}
			if (uploadFilesNumModel.getObjscope().contains("Analysis_Process_Designer")) {
				anpr = true;
				bwDateFormat.setAnpr(anpr);
			} else {
				bwDateFormat.setAnpr(anpr);
			}
			if (uploadFilesNumModel.getObjscope().contains("ADSO")) {
				adso = true;
				bwDateFormat.setAdso(adso);
			} else {
				bwDateFormat.setAdso(adso);
			}
			if (uploadFilesNumModel.getObjscope().contains("HANA_Composite_Provider")) {
				hrpr = true;
				bwDateFormat.setHcpr(hrpr);
			} else {
				bwDateFormat.setHcpr(hrpr);
			}
			if (uploadFilesNumModel.getObjscope().contains("Transformation")) {
				trfn = true;
				bwDateFormat.setTrn(trfn);
			} else {
				bwDateFormat.setTrn(trfn);
			}
			if (uploadFilesNumModel.getObjscope().contains("Update_Rules")) {
				updr = true;
				bwDateFormat.setUpdr(updr);
			} else {
				bwDateFormat.setUpdr(updr);
			}
			if (uploadFilesNumModel.getObjscope().contains("Transfer_Structure/Transfer_Rules")) {
				ists = true;
				bwDateFormat.setIsts(ists);
			} else {
				bwDateFormat.setIsts(ists);
			}
			if (uploadFilesNumModel.getObjscope().contains("Datasources(7.X)")) {
				rsds = true;
				bwDateFormat.setRsds(rsds);
			} else {
				bwDateFormat.setRsds(rsds);
			}
			if (uploadFilesNumModel.getObjscope().contains("ISMP")) {
				ismp = true;
				bwDateFormat.setIsmp(ismp);
			} else {
				bwDateFormat.setIsmp(ismp);
			}
			if (uploadFilesNumModel.getObjscope().contains("Infopackages")) {
				isip = true;
				bwDateFormat.setIsip(isip);
			} else {
				bwDateFormat.setIsip(isip);
			}
			if (uploadFilesNumModel.getObjscope().contains("Data_Transfer_Process")) {
				dtpa = true;
				bwDateFormat.setDtpa(dtpa);
			} else {
				bwDateFormat.setDtpa(dtpa);
			}
			if (uploadFilesNumModel.getObjscope().contains("BEX_Queries")) {
				elem = true;
				bwDateFormat.setElem(elem);
			} else {
				bwDateFormat.setElem(elem);
			}
			if (uploadFilesNumModel.getObjscope().contains("BEX_Workbook")) {
				xlwb = true;
				bwDateFormat.setXlwb(xlwb);
			} else {
				bwDateFormat.setXlwb(xlwb);
			}
			if (uploadFilesNumModel.getObjscope().contains("Web_Application_Design7x")) {
				btmp = true;
				bwDateFormat.setBtmp(btmp);
			} else {
				bwDateFormat.setBtmp(btmp);
			}
			if (uploadFilesNumModel.getObjscope().contains("Web_Application_Design3x")) {
				tmpl = true;
				bwDateFormat.setTmpl(tmpl);
			} else {
				bwDateFormat.setTmpl(tmpl);
			}
			if (uploadFilesNumModel.getObjscope().contains("Process_Chain")) {
				rspc = true;
				bwDateFormat.setRspc(rspc);
			} else {
				bwDateFormat.setRspc(rspc);
			}
			getRequestDetails().saveFileDateFormat(bwDateFormat);
		}
		if (requestForm.getSia() && requestForm.getBwUsage()
				&& (siaHasError || bwHasError || bwHasSelError || bwHasDtDiffError)) {
			logger.info("Returning  numberFilesUpload.jsp page -- Server Side Validation Fails FOR sia");
			model.addAttribute("numberFilesUpload", new UploadFilesNumberModel());
			model.addAttribute("filesToBeUploadedList", RequestFormUtility.getFilesToBeUploadedList());
			model.addAttribute("requestIDUI", getRequestDetails().getRequestObj(requestID).getREQUEST_ID_UI());
			model.addAttribute("SIA", "SIA");

			logger.info("Returning  numberFilesUpload.jsp page -- Server Side Validation Fails for bw");
			model.addAttribute("numberFilesUpload", new UploadFilesNumberModel());
			model.addAttribute("fileNameAndDateFormat", RequestFormUtility.getBwObjectsAndFileName());
			model.addAttribute("requestIDUI", requestForm.getREQUEST_ID_UI());
			model.addAttribute("BW", "BW");
			if (bwHasError) {
				model.addAttribute("bwException", "Please select date formats.");
			}
			if (bwHasSelError) {
				model.addAttribute("bwException", "Please select atleast one Object Type");
			}
			if (bwHasError && bwHasSelError) {
				model.addAttribute("bwException",
						"Please select atleast one Object Type and date format for the input file");
			}
			if (bwHasDtDiffError) {
				model.addAttribute("bwException", "Date Format should be same for the Input files with the same name");
			}
			return "client/numberFilesUpload";
		} else if (siaHasError) {
			logger.info("Returning  numberFilesUpload.jsp page -- Server Side Validation Fails FOR sia");
			model.addAttribute("numberFilesUpload", new UploadFilesNumberModel());
			model.addAttribute("filesToBeUploadedList", RequestFormUtility.getFilesToBeUploadedList());
			model.addAttribute("requestIDUI", getRequestDetails().getRequestObj(requestID).getREQUEST_ID_UI());
			model.addAttribute("SIA", "SIA");
			return "client/numberFilesUpload";
		} else if (bwHasError || bwHasSelError || bwHasDtDiffError) {
			logger.info("Returning  numberFilesUpload.jsp page -- Server Side Validation Fails for bw");
			model.addAttribute("numberFilesUpload", uploadFilesNumModel);
			model.addAttribute("fileNameAndDateFormat", RequestFormUtility.getBwObjectsAndFileName());
			model.addAttribute("requestIDUI", requestForm.getREQUEST_ID_UI());
			model.addAttribute("BW", "BW");
			if (bwHasError) {
				model.addAttribute("bwException", "Please select date formats.");
			}
			if (bwHasSelError) {
				model.addAttribute("bwException", "Please select atleast one Object Type");
			}
			if (bwHasError && bwHasSelError) {
				model.addAttribute("bwException",
						"Please select atleast one Object Type and date format for the input file");
			}
			if (bwHasDtDiffError) {
				model.addAttribute("bwException", "Date Format should be same for the Input files with the same name");
			}
			return "client/numberFilesUpload";
		}
		return "redirect:/client/uploadFiles/{requestID}";

	}

	@RequestMapping(value = "/client/uploadFiles/{requestID}", method = RequestMethod.GET)
	public String uploadFiles(@PathVariable("requestID") long requestId, final RedirectAttributes redirectAttributes,
			Model model, @ModelAttribute("fileList") HashMap<String, String> fileList, final HttpServletRequest request,
			final HttpSession session) {
		final RequestForm requestForm = getRequestDetails().getRequestObj(requestId);
		final UploadFilesNumber uploadFileNum = getRequestDetails().getnumOfUploadFiles(requestId);
		try {
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestId));
			RequestID_Validator_Utility.chckReqIdUser(reqIDValid.getCreator(reqIDValid.getRequestInv(requestId)),
					getPrincipal());
			/*
			 * CR 18: Changes made to show the list of files that were already uploaded in
			 * previous upload attempt.
			 */
			if (fileList.isEmpty()) {
				fileList = new HashMap<String, String>();
				final String clientName = requestForm.getClientName();
				final String filePath = HANAUtility.getFilePath(clientName, requestId);
				// We need to remove all such files that may have been leftover
				// from previous upload attempt. These files are left at the filePath location.
				File[] existingFiles = new File(filePath).listFiles();
				if (null != existingFiles && existingFiles.length > 0) {
					// If the left-over file is not a file rather a directory or something else,
					// then delete it.
					String existingFileName = "";
					for (File file : existingFiles) {
						existingFileName = file.getName().toUpperCase();
						if (!(existingFileName.endsWith("XLSX") || existingFileName.endsWith("XLS"))) {
							FileUtils.forceDelete(file);
							continue;
						}
						fileList.put(existingFileName, VALID);
					}
					Map<String, Object> returnMap = checkListAndValidate(filePath, fileList, clientName, requestId,
							getPrincipal(), session);
				}
			}

			String status = getClientRequestInventoryDAO().getRequestInventory(requestId).getRequestStatus();
			String rfpStatus = requestForm.getValueRFP();
			String comments = getClientRequestInventoryDAO().getRequestInventory(requestId).getComments();
			String requestIdUI = getClientRequestInventoryDAO().getRequestInventory(requestId).getREQUEST_ID_UI();
			String toolName = (String) session.getAttribute("tool");

			boolean scopeHana = requestForm.getSOH();
			boolean scopeS4 = requestForm.getS4Technical();
			boolean scopeFIAT = requestForm.getS4Functional();
			boolean scopeUI5 = requestForm.getUI5();
			boolean scopeFiori = requestForm.getFiori();
			boolean scopeAUCT = requestForm.getUPGRADE();
			boolean scopeRFP = requestForm.getRFP();
			boolean scopeOSMigration = requestForm.getOsMig();
			boolean scopeEXT = requestForm.getEXT();
			String sourceVersion = requestForm.getSourceVersion();
			String targetVersion = requestForm.getTargetVersion();

			HashMap<String, String> ScopeBasedFileList = new HashMap<String, String>();
			HashMap<String, Long> fileSize = new HashMap<String, Long>();
			if (scopeHana) {
				ScopeBasedFileList.put("ZAICAT_DETECTION", "fileList");
				fileSize.put("ZAICAT_DETECTION", File_Size_Constant.ZAICAT_DETECTION_SIZE);
				// ScopeBasedFileList.put("CDS VIEW", "fileList");// CDS
				// fileSize.put("CDS VIEW",File_Size_Constant.CDS_VIEW_SIZE);
				ScopeBasedFileList.put("TRDIR", "fileList");// TR_DIR
				fileSize.put("TRDIR", File_Size_Constant.TRDIR_SIZE);
				ScopeBasedFileList.put("INVENTORY LIST", "fileList");// INVENTORY LIST
				fileSize.put("INVENTORY LIST", File_Size_Constant.INVENTORY_SIZE);
				ScopeBasedFileList.put("SMODILOG", "fileList"); //
				fileSize.put("SMODILOG", File_Size_Constant.SMODILOG_SIZE);
				ScopeBasedFileList.put("IMPACTED CLONE", "fileList");// IMPACTED CLONE
				fileSize.put("IMPACTED CLONE", File_Size_Constant.IMPACTED_CLONE_SIZE);
				if ("NO".equalsIgnoreCase(requestForm.getUnicodeCompliant())
						&& "YES".equalsIgnoreCase(requestForm.getEnableUnicode())) {
					ScopeBasedFileList.put("UNICODE", "fileList");
					fileSize.put("UNICODE", File_Size_Constant.UNICODE);
				}
				ScopeBasedFileList.put("INACTIVE_OBJECTS", "fileList");// INACTIVE_OBJECTS
				fileSize.put("INACTIVE_OBJECTS", File_Size_Constant.INACTIVE_OBJECT_SIZE);
				ScopeBasedFileList.put("METADATA", "fileList");
				fileSize.put("METADATA", File_Size_Constant.METADATA_SIZE);
				ScopeBasedFileList.put("ACNIP_ZVER_COMP", "fileList");
				fileSize.put("ACNIP_ZVER_COMP", File_Size_Constant.ACNIP_ZVER_COMP_SIZE);
				model.addAttribute("SoH", "SoH");
			}

			if (scopeS4) {
				ScopeBasedFileList.put("ZAICAT_DETECTION", "fileList");
				fileSize.put("ZAICAT_DETECTION", File_Size_Constant.ZAICAT_DETECTION_SIZE);
				/*
				 * ScopeBasedFileList.put("ENHANCEMENT", "fileList");// ENHANCEMENT
				 * fileSize.put("ENHANCEMENT",File_Size_Constant.ENHANCEMENT_SIZE);
				 */
				ScopeBasedFileList.put("TRDIR", "fileList");// TR_DIR
				fileSize.put("TRDIR", File_Size_Constant.TRDIR_SIZE);
				ScopeBasedFileList.put("INVENTORY LIST", "fileList");// INVENTORY LIST
				fileSize.put("INVENTORY LIST", File_Size_Constant.INVENTORY_SIZE);
				/*
				 * ScopeBasedFileList.put("IMPACTED IDOC", "fileList");// Impacted IDOC
				 * fileSize.put("IMPACTED IDOC",File_Size_Constant.IDOC_SIZE);
				 * ScopeBasedFileList.put("IMPACTED TABLES", "fileList");// Impacted Tables
				 * fileSize.put("IMPACTED TABLES", File_Size_Constant.IMPACTED_TABLES_SIZE);
				 */
				ScopeBasedFileList.put("APPEND STRUCTURE", "fileList");// Append Structure
				fileSize.put("APPEND STRUCTURE", File_Size_Constant.APPEND_SIZE);
				// ScopeBasedFileList.put("CLONE ANALYSIS", "fileList");// Clone Analysis
				// fileSize.put("CLONE ANALYSIS",File_Size_Constant.CLONE_SIZE);
				ScopeBasedFileList.put("IMPACTED STANDARD TRANSACTIONS", "fileList");
				fileSize.put("IMPACTED STANDARD TRANSACTIONS", File_Size_Constant.IMPACTED_STANDARD_TRANSACTION_SIZE);
				ScopeBasedFileList.put("SMODILOG", "fileList"); // SMODILOG
				fileSize.put("SMODILOG", File_Size_Constant.SMODILOG_SIZE);
				ScopeBasedFileList.put("IMPACTED CLONE", "fileList");// IMPACTED CLONE
				fileSize.put("IMPACTED CLONE", File_Size_Constant.IMPACTED_CLONE_SIZE);
				if ("NO".equalsIgnoreCase(requestForm.getUnicodeCompliant())
						&& "YES".equalsIgnoreCase(requestForm.getEnableUnicode())) {
					ScopeBasedFileList.put("UNICODE", "fileList");
					fileSize.put("UNICODE", File_Size_Constant.UNICODE);
				}
				ScopeBasedFileList.put("INACTIVE_OBJECTS", "fileList");// INACTIVE_OBJECTS
				fileSize.put("INACTIVE_OBJECTS", File_Size_Constant.INACTIVE_OBJECT_SIZE);
				ScopeBasedFileList.put("METADATA", "fileList");
				fileSize.put("METADATA", File_Size_Constant.METADATA_SIZE);
				ScopeBasedFileList.put("ACNIP_ZVER_COMP", "fileList");
				fileSize.put("ACNIP_ZVER_COMP", File_Size_Constant.ACNIP_ZVER_COMP_SIZE);
				ScopeBasedFileList.put("BW_EXTRACTOR", "fileList");
				fileSize.put("BW_EXTRACTOR", File_Size_Constant.BW_EXTRACTOR_SIZE);
				model.addAttribute("Technical", "Technical");
			}
			if (requestForm.getBwTech()) {
				ScopeBasedFileList.put("BW_INVENTORY", "fileList");
				fileSize.put("BW_INVENTORY", File_Size_Constant.BwInventory_SIZE);
				ScopeBasedFileList.put("ZAICAT_DETECTION", "fileList");
				fileSize.put("ZAICAT_DETECTION", File_Size_Constant.ZAICAT_DETECTION_SIZE);
				/*
				 * ScopeBasedFileList.put("ENHANCEMENT", "fileList");// ENHANCEMENT
				 * fileSize.put("ENHANCEMENT",File_Size_Constant.ENHANCEMENT_SIZE);
				 */
				ScopeBasedFileList.put("TRDIR", "fileList");// TR_DIR
				fileSize.put("TRDIR", File_Size_Constant.TRDIR_SIZE);
				ScopeBasedFileList.put("INVENTORY LIST", "fileList");// INVENTORY LIST
				fileSize.put("INVENTORY LIST", File_Size_Constant.INVENTORY_SIZE);
				/*
				 * ScopeBasedFileList.put("IMPACTED IDOC", "fileList");// Impacted IDOC
				 * fileSize.put("IMPACTED IDOC",File_Size_Constant.IDOC_SIZE);
				 * ScopeBasedFileList.put("IMPACTED TABLES", "fileList");// Impacted Tables
				 * fileSize.put("IMPACTED TABLES", File_Size_Constant.IMPACTED_TABLES_SIZE);
				 */
				ScopeBasedFileList.put("APPEND STRUCTURE", "fileList");// Append Structure
				fileSize.put("APPEND STRUCTURE", File_Size_Constant.APPEND_SIZE);
				// ScopeBasedFileList.put("CLONE ANALYSIS", "fileList");// Clone Analysis
				// fileSize.put("CLONE ANALYSIS",File_Size_Constant.CLONE_SIZE);
				ScopeBasedFileList.put("IMPACTED STANDARD TRANSACTIONS", "fileList");
				fileSize.put("IMPACTED STANDARD TRANSACTIONS", File_Size_Constant.IMPACTED_STANDARD_TRANSACTION_SIZE);
				ScopeBasedFileList.put("SMODILOG", "fileList"); // SMODILOG
				fileSize.put("SMODILOG", File_Size_Constant.SMODILOG_SIZE);
				ScopeBasedFileList.put("IMPACTED CLONE", "fileList");// IMPACTED CLONE
				fileSize.put("IMPACTED CLONE", File_Size_Constant.IMPACTED_CLONE_SIZE);
				ScopeBasedFileList.put("INACTIVE_OBJECTS", "fileList");// INACTIVE_OBJECTS
				fileSize.put("INACTIVE_OBJECTS", File_Size_Constant.INACTIVE_OBJECT_SIZE);
				ScopeBasedFileList.put("METADATA", "fileList");
				fileSize.put("METADATA", File_Size_Constant.METADATA_SIZE);
			}
			if (scopeAUCT) {
				ScopeBasedFileList.put("ZAICAT_DETECTION", "fileList");
				fileSize.put("ZAICAT_DETECTION", File_Size_Constant.ZAICAT_DETECTION_SIZE);
				ScopeBasedFileList.put("TRDIR", "fileList");// TR_DIR
				fileSize.put("TRDIR", File_Size_Constant.TRDIR_SIZE);
				ScopeBasedFileList.put("INVENTORY LIST", "fileList");// INVENTORY LIST
				fileSize.put("INVENTORY LIST", File_Size_Constant.INVENTORY_SIZE);
				ScopeBasedFileList.put("SMODILOG", "fileList"); // SMODILOG
				fileSize.put("SMODILOG", File_Size_Constant.SMODILOG_SIZE);
				ScopeBasedFileList.put("IMPACTED CLONE", "fileList");// IMPACTED CLONE
				fileSize.put("IMPACTED CLONE", File_Size_Constant.IMPACTED_CLONE_SIZE);
				if ("NO".equalsIgnoreCase(requestForm.getUnicodeCompliant())
						&& "YES".equalsIgnoreCase(requestForm.getEnableUnicode())) {
					ScopeBasedFileList.put("UNICODE", "fileList");
					fileSize.put("UNICODE", File_Size_Constant.UNICODE);
				}
				ScopeBasedFileList.put("INACTIVE_OBJECTS", "fileList");// INACTIVE_OBJECTS
				fileSize.put("INACTIVE_OBJECTS", File_Size_Constant.INACTIVE_OBJECT_SIZE);
				ScopeBasedFileList.put("METADATA", "fileList");
				fileSize.put("METADATA", File_Size_Constant.METADATA_SIZE);
				ScopeBasedFileList.put("ACNIP_ZVER_COMP", "fileList");
				fileSize.put("ACNIP_ZVER_COMP", File_Size_Constant.ACNIP_ZVER_COMP_SIZE);
				model.addAttribute("Upgrade", "Upgrade");
			}

			// IRPA - Input File Upload - Business Process Detail
			if ((scopeHana || scopeS4 || scopeAUCT) && AppGenUtility.getTScopeVer(sourceVersion, targetVersion)) {
				ScopeBasedFileList.put("BUSINESS PROCESS DETAIL", "fileList");
				fileSize.put("BUSINESS PROCESS DETAIL", File_Size_Constant.BUSINESS_PROCESS_DETAIL_SIZE);
				ScopeBasedFileList.put("ACNIP_ZVER_COMP", "fileList");
				fileSize.put("ACNIP_ZVER_COMP", File_Size_Constant.ACNIP_ZVER_COMP_SIZE);
			}

			if (scopeUI5) {
				ScopeBasedFileList.put("ZAICAT_DETECTION", "fileList");
				fileSize.put("ZAICAT_DETECTION", File_Size_Constant.ZAICAT_DETECTION_SIZE);
				model.addAttribute("UI5", "UI5");
			}

			if (scopeFiori) {
				ScopeBasedFileList.put("ZAICAT_DETECTION", "fileList");
				fileSize.put("ZAICAT_DETECTION", File_Size_Constant.ZAICAT_DETECTION_SIZE);
//				ScopeBasedFileList.put("CUSTOM REPORT OUTPUT", "fileList");
//				fileSize.put("CUSTOM REPORT OUTPUT", File_Size_Constant.CUSTOM_REPORT_OUTPUT_SIZE);
				model.addAttribute("Fiori", "Fiori");
			}

			if (scopeFIAT) {
				ScopeBasedFileList.put("ZAICAT_DETECTION", "fileList");
				fileSize.put("ZAICAT_DETECTION", File_Size_Constant.ZAICAT_DETECTION_SIZE);
				ScopeBasedFileList.put("ENHANCEMENT", "fileList");// ENHANCEMENT
				fileSize.put("ENHANCEMENT", File_Size_Constant.ENHANCEMENT_SIZE);
				model.addAttribute("Functional", "Functional");
			}

			if (requestForm.getSia()) {
				for (int i = 1; i <= uploadFileNum.getNum_SRC_AGR1251(); i++) {
					ScopeBasedFileList.put("SRC_AGR1251_" + i, "fileList");
					fileSize.put("SRC_AGR1251_" + i, File_Size_Constant.SRC_ARG1251_SIZE);
				}
				for (int i = 1; i <= uploadFileNum.getNum_SRC_AGRUSERS(); i++) {
					ScopeBasedFileList.put("SRC_AGRUSERS_" + i, "fileList");
					fileSize.put("SRC_AGRUSERS_" + i, File_Size_Constant.ARG_USER_SIZE);
				}
				for (int i = 1; i <= uploadFileNum.getNum_SRC_USOBTC(); i++) {
					ScopeBasedFileList.put("SRC_USOBTC_" + i, "fileList");
					fileSize.put("SRC_USOBTC_" + i, File_Size_Constant.SRC_USOBTC_SIZE);
				}
				model.addAttribute("num_SRC_AGR1251", uploadFileNum.getNum_SRC_AGR1251());
				model.addAttribute("num_SRC_AGRUSERS", uploadFileNum.getNum_SRC_AGRUSERS());
				model.addAttribute("num_SRC_USOBTC", uploadFileNum.getNum_SRC_USOBTC());
				model.addAttribute("SIA", "SIA");
			}

			if (requestForm.getBwUsage()) {
				BwObjectTypeDateFormat dateAndObj = bwCleanDao.getBwObjectType(requestId);
				if (dateAndObj.getOdso()) {
					ScopeBasedFileList.put("RSDODSO", "fileList");
					fileSize.put("RSDODSO", File_Size_Constant.RSDODSO_SIZE);
					ScopeBasedFileList.put("RSICCONT", "fileList");
					fileSize.put("RSICCONT", File_Size_Constant.RSICCONT_SIZE);
				}
				if (dateAndObj.getIobj()) {
					ScopeBasedFileList.put("RSDIOBJ", "fileList");
					fileSize.put("RSDIOBJ", File_Size_Constant.RSPCCHAIN_SIZE);
				}
				if (dateAndObj.getCuba()) {
					ScopeBasedFileList.put("RSDCUBE", "fileList");
					fileSize.put("RSDCUBE", File_Size_Constant.RSDCUBE_SIZE);
					ScopeBasedFileList.put("RSICCONT", "fileList");
					fileSize.put("RSICCONT", File_Size_Constant.RSICCONT_SIZE);
				}
				if (dateAndObj.getMpro()) {
					ScopeBasedFileList.put("RSDCUBE", "fileList");
					fileSize.put("RSDCUBE", File_Size_Constant.RSDCUBE_SIZE);
				}
				if (dateAndObj.getIset()) {
					ScopeBasedFileList.put("RSQISET", "fileList");
					fileSize.put("RSQISET", File_Size_Constant.RSPCCHAIN_SIZE);
				}
				if (dateAndObj.getOdh()) {
					ScopeBasedFileList.put("RSBOHDEST", "fileList");
					fileSize.put("RSBOHDEST", File_Size_Constant.RSPCCHAIN_SIZE);
					ScopeBasedFileList.put("RSBKREQUEST", "fileList");
					fileSize.put("RSBKREQUEST", File_Size_Constant.RSBKREQUEST_SIZE);
				}
				if (dateAndObj.getAnpr()) {
					ScopeBasedFileList.put("RSANT_PROCESS", "fileList");
					fileSize.put("RSANT_PROCESS", File_Size_Constant.RSPCCHAIN_SIZE);
					ScopeBasedFileList.put("RSANT_PROCESSR", "fileList");
					fileSize.put("RSANT_PROCESSR", File_Size_Constant.RSANT_PROCESSR_SIZE);
				}
				if (dateAndObj.getHcpr()) {
					ScopeBasedFileList.put("RSOHCPR", "fileList");
					fileSize.put("RSOHCPR", File_Size_Constant.RSPCCHAIN_SIZE);
				}
				if (dateAndObj.getTrn()) {
					ScopeBasedFileList.put("RSTRAN", "fileList");
					fileSize.put("RSTRAN", File_Size_Constant.RSTRAN_SIZE);
				}
				if (dateAndObj.getUpdr()) {
					ScopeBasedFileList.put("RSUPDINFO", "fileList");
					fileSize.put("RSUPDINFO", File_Size_Constant.RSPCCHAIN_SIZE);
				}
				if (dateAndObj.getIsts()) {
					ScopeBasedFileList.put("RSTS", "fileList");
					fileSize.put("RSTS", File_Size_Constant.RSPCCHAIN_SIZE);
				}
				if (dateAndObj.getRsds()) {
					ScopeBasedFileList.put("RSDS", "fileList");
					fileSize.put("RSDS", File_Size_Constant.RSPCCHAIN_SIZE);
				}
				if (dateAndObj.getIsip()) {
					ScopeBasedFileList.put("RSLDPIO", "fileList");
					fileSize.put("RSLDPIO", File_Size_Constant.RSPCCHAIN_SIZE);
				}
				if (dateAndObj.getDtpa()) {
					ScopeBasedFileList.put("RSBKDTP", "fileList");
					fileSize.put("RSBKDTP", File_Size_Constant.RSBKDTP_SIZE);
					ScopeBasedFileList.put("RSBKDTPSTAT", "fileList");
					fileSize.put("RSBKDTPSTAT", File_Size_Constant.RSBKDTPSTAT_SIZE);
				}
				if (dateAndObj.getElem()) {
					ScopeBasedFileList.put("RSRREPDIR", "fileList");
					fileSize.put("RSRREPDIR", File_Size_Constant.RSRREPDIR_SIZE);
				}
				if (dateAndObj.getXlwb()) {
					ScopeBasedFileList.put("RSRWBINDEX", "fileList");
					fileSize.put("RSRWBINDEX", File_Size_Constant.RSPCCHAIN_SIZE);
					ScopeBasedFileList.put("RSRWBINDEXT", "fileList");
					fileSize.put("RSRWBINDEXT", File_Size_Constant.RSRWBINDEXT_SIZE);
					ScopeBasedFileList.put("RSRWORKBOOK", "fileList");
					fileSize.put("RSRWORKBOOK", File_Size_Constant.RSRWORKBOOK_SIZE);
					ScopeBasedFileList.put("RSRREPDIR", "fileList");
					fileSize.put("RSRREPDIR", File_Size_Constant.RSRREPDIR_SIZE);
				}
				if (dateAndObj.getBtmp()) {
					ScopeBasedFileList.put("RSZWBTMPHEAD", "fileList");
					fileSize.put("RSZWBTMPHEAD", File_Size_Constant.RSPCCHAIN_SIZE);
					ScopeBasedFileList.put("RSZWBTMPDATA", "fileList");
					fileSize.put("RSZWBTMPDATA", File_Size_Constant.RSZWBTMPDATA_SIZE);
					ScopeBasedFileList.put("BIOAPERS_SOD00", "fileList");
					fileSize.put("BIOAPERS_SOD00", File_Size_Constant.BIOAPEARS_SIZE);
				}
				if (dateAndObj.getTmpl()) {
					ScopeBasedFileList.put("RSZWTEMPLATE", "fileList");
					fileSize.put("RSZWTEMPLATE", File_Size_Constant.RSZWTEMPLATE_SIZE);
					ScopeBasedFileList.put("BIOAPERS_SOD00", "fileList");
					fileSize.put("BIOAPERS_SOD00", File_Size_Constant.BIOAPEARS_SIZE);
				}
				if (dateAndObj.getRspc()) {
					ScopeBasedFileList.put("RSPCCHAINATTR", "fileList");
					fileSize.put("RSPCCHAINATTR", File_Size_Constant.RSPCCHAIN_SIZE);
					ScopeBasedFileList.put("RSPCPROCESSLOG", "fileList");
					fileSize.put("RSPCPROCESSLOG", File_Size_Constant.RSPCPROCESSLOG_SIZE);
					ScopeBasedFileList.put("RSPCCHAIN", "fileList");
					fileSize.put("RSPCCHAIN", File_Size_Constant.RSPCCHAIN_SIZE);
				}
				model.addAttribute("BW", "BW");
			}
			if (requestForm.getGrc()) {
				ScopeBasedFileList.put("GRT_GRACFUNCACT_DETAILS", "fileList");
				fileSize.put("GRT_GRACFUNCACT_DETAILS", File_Size_Constant.GRT_GRACFUNCACT_SIZE);
			}

			if (scopeOSMigration) {
				ScopeBasedFileList.put("INVENTORY LIST", "fileList");
				fileSize.put("INVENTORY LIST", File_Size_Constant.INVENTORY_SIZE);
				ScopeBasedFileList.put("ZAICAT_DETECTION", "fileList");
				fileSize.put("ZAICAT_DETECTION", File_Size_Constant.ZAICAT_DETECTION_SIZE);
				ScopeBasedFileList.put("IMPACTED CLONE", "fileList");
				fileSize.put("IMPACTED CLONE", File_Size_Constant.IMPACTED_CLONE_SIZE);
				ScopeBasedFileList.put("INACTIVE_OBJECTS", "fileList");// INACTIVE_OBJECTS
				fileSize.put("INACTIVE_OBJECTS", File_Size_Constant.INACTIVE_OBJECT_SIZE);
				model.addAttribute("osMigration", "osMigration");
				ScopeBasedFileList.put("METADATA", "fileList");
				fileSize.put("METADATA", File_Size_Constant.METADATA_SIZE);
				ScopeBasedFileList.put("ACNIP_ZVER_COMP", "fileList");
				fileSize.put("ACNIP_ZVER_COMP", File_Size_Constant.ACNIP_ZVER_COMP_SIZE);
			}

			if (scopeRFP) {
				if (rfpStatus.equalsIgnoreCase("uploadRFPFile")) {
					ScopeBasedFileList.put("TADIR", "fileList");
					fileSize.put("TADIR", File_Size_Constant.TADIR_SIZE);
					model.addAttribute("RFP", "RFP");
				} else {
					getRequestInventorydao().updateRfpSatus(requestId,
							Hana_Profiler_Constant.RFP_CLIENT_UL_SUCCESS_STATUS, getPrincipal(), toolName, null,
							Hana_Profiler_Constant.RFP_UPLOAD_SUCC);
				}
				model.addAttribute("fileList", new TreeMap<String, String>(fileList));
				model.addAttribute("ScopeBasedFileList", new TreeMap<String, String>(ScopeBasedFileList));
				model.addAttribute("fileSize", fileSize);
				model.addAttribute("requestID", requestId);
				model.addAttribute("requestIDUI", requestIdUI);
				model.addAttribute("status", status);
			} else {
				model.addAttribute("statusMessage", comments);
				model.addAttribute("fileList", new TreeMap<String, String>(fileList));
				model.addAttribute("ScopeBasedFileList", new TreeMap<String, String>(ScopeBasedFileList));
				model.addAttribute("fileSize", fileSize);
				model.addAttribute("requestID", requestId);
				model.addAttribute("requestIDUI", requestIdUI);
				model.addAttribute("status", status);
			}

			if (scopeEXT) {
				ScopeBasedFileList.put("METADATA", "fileList");
				fileSize.put("METADATA", File_Size_Constant.METADATA_SIZE);
				ScopeBasedFileList.put("ZAICAT_DETECTION", "fileList");
				fileSize.put("ZAICAT_DETECTION", File_Size_Constant.ZAICAT_DETECTION_SIZE);
				ScopeBasedFileList.put("COMPLEXITY_RULES", "fileList");
				fileSize.put("COMPLEXITY_RULES", File_Size_Constant.COMPLEXITY_RULES_SIZE);
				ScopeBasedFileList.put("EXTENSIBILITY_RULES", "fileList");
				fileSize.put("EXTENSIBILITY_RULES", File_Size_Constant.EXTENSIBILITY_RULES_SIZE);
				ScopeBasedFileList.put("IMPACTED CLONE", "fileList");
				fileSize.put("IMPACTED CLONE", File_Size_Constant.IMPACTED_CLONE_SIZE);

				model.addAttribute("EXT", "EXT");
				model.addAttribute("statusMessage", comments);
				model.addAttribute("fileList", fileList);
				model.addAttribute("ScopeBasedFileList", ScopeBasedFileList);
				model.addAttribute("fileSize", fileSize);
				model.addAttribute("requestID", requestId);
				model.addAttribute("requestIDUI", requestIdUI);
				model.addAttribute("status", status);
			}
		} catch (ReqIDNotValidException ex) {
			model.addAttribute("errorMsg", ex.getMessage());
			return "errors";
		} catch (Exception e) {
			logger.error("uploadFiles() :: ", e);
		}
		return "client/uploadFiles";
	}

	@RequestMapping(value = "/client/clientFilesProcessing", method = RequestMethod.GET)
	public @ResponseBody void clientFilesProcessing(final Long requestId, final HttpServletRequest request,
			HttpSession session) {

		try {
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestId));
			RequestID_Validator_Utility.chckReqIdUser(reqIDValid.getCreator(reqIDValid.getRequestInv(requestId)),
					getPrincipal());

			DisplayGraphS4DAO graphS4DAO = getGraphS4DAO();
			final RequestForm requestForm = getRequestDetails().getRequestObj(requestId);
			boolean scopeRFP = requestForm.getRFP();

			if (scopeRFP) {
				clientFileRFPProcessingBusinessLogic(requestId, request, session, graphS4DAO, requestForm);
			} else {
				clientFileProcessingBusinessLogic(requestId, request, session, graphS4DAO, requestForm);
			}
		} catch (ReqIDNotValidException ex) {
			HANAUtility.changeRequestProgressValue(requestId, Hana_Profiler_Constant.FAILED_PROCESS_PERCENT_VALUE,
					"Not Authorised");
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}

	@RequestMapping(value = "/getProgress", method = RequestMethod.GET)
	public @ResponseBody Map<String, String> getProgress(final long requestId) {
		Map<String, String> percentCommentMap = Hana_Profiler_Constant.REQUEST_PROGRESS_MAP.get(requestId);

		if (percentCommentMap != null) {
			String percentage = percentCommentMap.get(Hana_Profiler_Constant.PERCENTAGE_KEY);
			if (StringUtils.equals(percentage,
					Integer.toString(Hana_Profiler_Constant.PROCESS_COMPLETE_PERCENT_VALUE))) {
				Hana_Profiler_Constant.REQUEST_PROGRESS_MAP.remove(requestId);
			}
		} /*
			 * else { percentCommentMap = new HashMap<String, String>();
			 * percentCommentMap.put(Hana_Profiler_Constant.PERCENTAGE_KEY, "0");
			 * percentCommentMap.put(Hana_Profiler_Constant.COMMENTS_KEY,
			 * Hana_Profiler_Constant.ST03_IN_PROGRESS_MSG); }
			 */

		return percentCommentMap;
	}

	@RequestMapping(value = "/signup/signup", method = RequestMethod.GET)
	public String signup(Model model, HttpServletRequest request, HttpSession session) {
		String url = request.getRequestURI().substring(request.getContextPath().length());
		session.setAttribute("demoFromURL", url);
		session.setAttribute("Enviroment", request.getServerName());
		if (model.asMap().get("user") == null) {
			String userName = (String) request.getSession().getAttribute("UserName");
			model.addAttribute("UserID", userName);
			model.addAttribute("user", new UserModel());
		}
		return "client/signup";
	}

	@RequestMapping(value = "/signup/signedup", method = RequestMethod.POST)
	public String clientSignedup(@Valid @ModelAttribute("user") UserModel userModel, BindingResult result,
			RedirectAttributes redirectAttribute, HttpServletRequest request, HttpSession session) throws Exception {
		User user = prepareUserModel(userModel);
		String pageName = "redirect:/signup/signup";
		try {

			if (StringUtils.isBlank(user.getUserName())) {
				redirectAttribute.addFlashAttribute("userNameErrorMessage", "User Name can't be blank.");
			} else if (user.getUserName().length() <= 3) {
				redirectAttribute.addFlashAttribute("userNameErrorMessage", "User Name must have min 4 Characters");
			}
			if (StringUtils.isBlank(user.getProjectName())) {
				redirectAttribute.addFlashAttribute("ProjectNameErrorMessage", "Project Name can't be blank.");
			}
			if (StringUtils.isBlank(user.getClientName())) {
				redirectAttribute.addFlashAttribute("ClientNameErrorMessage", "Client Name can't be blank.");
			}

			/*
			 * if (result.hasErrors()) { pageName = "client/signup"; } else {
			 */
			/*
			 * Modified the logic to add account validity column in the user table. For
			 * client, the account validity is 0 months from the time of registration.
			 */

			Calendar calendar = Calendar.getInstance();
			// Current date on which account is created.
			Date createdOn = new Date(calendar.getTimeInMillis());
			user.setCreatedOn(createdOn);
			user.setNewUserFlag(true);
			// Account valid for 0 months at time of account creation for new user

			// CR:47- admin will activate new user account ,till that new user can't
			// login-rohan.a.mehra
			logger.info("Inside clientSignup client account created with 0,months validity");
			calendar.add(Calendar.MONTH, 0);
			Date validTill = new Date(calendar.getTimeInMillis());
			user.setValidTill(validTill);
			user.setEnabled(false);
			user.setPassword(user.getUserName());
			user.setUserName(user.getUserName());
			user.setConfirmPassword(user.getUserName());
			String Userid = (String) request.getSession().getAttribute("UserName");
			user.setEmailId(Userid);
			logger.info("Saving data for user");
			getPocLoginService().pocSignedup(user, Hana_Profiler_Constant.CLIENT_ROLE);

			logger.info("Sending Email for user account activation");
			sendEmailForAccountActivation(user.getUserName(), user.getEmailId(), request, session);

			logger.info("An email has been sent to Administrator for account activation with user name");
			redirectAttribute.addFlashAttribute("msg",
					"<b>An email has been sent to Administrator for your account activation. Kindly wait for further communication.");
			logger.info("Message displayed on screen for user regarding mail communictaion to administrator");
			/* } */
		} catch (SignUpException exception) {
			redirectAttribute.addFlashAttribute("user", user);
			redirectAttribute.addFlashAttribute("userNameDuplicateErrorMessage", "Username already exists");
		} catch (Exception e) {
			logger.error(e.getMessage() + " : " , e);
		}
		return pageName;
	}

	// CR:47- admin will activate new user account ,till that new user can't
	// login-rohan.a.mehra
	/**
	 * This private method sends an email to the administrator for Activation of
	 * user account on account creation.
	 * 
	 * @param userName
	 * @param request
	 */

	private void sendEmailForAccountActivation(String userName, String emailId, HttpServletRequest request,
			HttpSession session) {
		logger.info("Inside sendEmailForAccountActivationRequest method");
		String emailContext = "https://" + request.getServerName() + ":" + request.getServerPort();
		Set<String> emailData = new HashSet<String>();
		Set<String> emailCc = new HashSet<String>();
		SendEmail email = new SendEmail();
		email.setMailFrom("IDC_SAPUpgrade_Sales@accenture.com");
		emailData.add("IDC_SAPUpgrade_Sales@accenture.com");
		emailCc.add(emailId);
		email.setMailTo(emailData);
		email.setMailCC(emailCc);

		email.setMailSubject("Account Activation Request for User : " + userName);

		String emailBody = "\n\n" + userName + " has requested to activate the account for file processing. "
				+ "Please visit the New User Requests section to Activate the account for the user"
				+ " Click here to admin login: " + "\n<a href=" + emailContext + "/hanaprofilerperformance/homepage"
				+ ">Login</a>" + "\n\nRegards,\nS/4HANA conversion Team ATCI";
		logger.info("Email sent for Account Activation");
		email.setMailBody(emailBody);

		email.emailSend(email, request, session);
	}

	@RequestMapping(value = "/client/dashboard", method = RequestMethod.GET)
	public String dashBoard(Model model, final String status, Long requestId, final String requestIdUi,
			HttpServletRequest request, HttpSession session) throws Exception {
		String userName = getPrincipal();
		String url = request.getRequestURI().substring(request.getContextPath().length());
		session.setAttribute("demoFromURL", url);
		if (requestIdUi != null) {

			if (requestIdUi.length() != 14) {
				model.addAttribute("IdError", "Please enter a valid Request ID.");
			} else {
				requestId = getRequestDetails().getRequestID(requestIdUi);
			}
		}

		String toolName = (String) session.getAttribute("tool");

		final List<StatusMaster> statusList = getDashBoard().getStatusList();
		final List<RequestInventory> mainRequestIdList = getClientRequestInventoryDAO().getRequestIdList(session, getPrincipal());
		final List<RequestFormDetailsBean> requestDetailsList = getDashBoard().getClientRequests(userName, status,
				requestId, null, null, toolName);

		for (RequestFormDetailsBean RequestList : requestDetailsList) {

			if (RequestList.status.equalsIgnoreCase("Initiated")) {
				RequestList.code = "INI";
			} else if (RequestList.status.equalsIgnoreCase("Pending")) {
				RequestList.code = "PEN";
			} else if (RequestList.status.equalsIgnoreCase("Approved")) {
				RequestList.code = "APP";
			} else if (RequestList.status.equalsIgnoreCase("Rejected")) {
				RequestList.code = "REJ";
			} else if (RequestList.status.equalsIgnoreCase("IDVSuccess")) {
				RequestList.code = "FUS";
			} else if (RequestList.status.equalsIgnoreCase("IDVFailed")) {
				RequestList.code = "FUF";
			} else if (RequestList.status.equalsIgnoreCase("Success")) {
				RequestList.code = "SUC";
			} else if (RequestList.status.equalsIgnoreCase("ST03Failed")) {
				RequestList.code = "PFA";
			} else if (RequestList.status.equalsIgnoreCase("HANAQuerySuccess")) {
				RequestList.code = "SUC";
			} else if (RequestList.status.equalsIgnoreCase("HANAQueryFailed")) {
				RequestList.code = "FAI";
			} else if (RequestList.status.equalsIgnoreCase("Completed")) {
				RequestList.code = "COM";
			} else if (RequestList.status.equalsIgnoreCase("Not Completed")) {
				RequestList.code = "NCO";
			} else if (RequestList.status.equalsIgnoreCase("HANARefiningFailed")) {
				RequestList.code = "FAI";
			} else if (RequestList.status.equalsIgnoreCase("HANARefiningSuccess")) {
				RequestList.code = "SUC";
			} else if (RequestList.status.equalsIgnoreCase("ROMRefiningFailed")) {
				RequestList.code = "RFAI";
			} else if (RequestList.status.equalsIgnoreCase("ROMRefiningSuccess")) {
				RequestList.code = "RSUC";
			} else if (RequestList.status.equalsIgnoreCase("HanaRefiningCompleted")) {
				RequestList.code = "COM";
			} else if (RequestList.status.equalsIgnoreCase("RomRefiningCompleted")) {
				RequestList.code = "RCOM";
			} else if (RequestList.status.equalsIgnoreCase("Completed With Pending Estimations")) {
				RequestList.code = "CPE";
			}

		}

		for (StatusMaster statusListData : statusList) {

			if (statusListData.code.equalsIgnoreCase("Initiated")) {
				statusListData.code = "Initiated";
			} else if (statusListData.code.equalsIgnoreCase("Pending")) {
				statusListData.code = "Pending";
			} else if (statusListData.code.equalsIgnoreCase("Approved")) {
				statusListData.code = "Approved";
			} else if (statusListData.code.equalsIgnoreCase("Rejected")) {
				statusListData.code = "Rejected";
			} else if (statusListData.code.equalsIgnoreCase("IDVSuccess")) {
				statusListData.code = "File Upload Successful";
			} else if (statusListData.code.equalsIgnoreCase("IDVFailed")) {
				statusListData.code = "File Upload Failed";
			} else if (statusListData.code.equalsIgnoreCase("Success")) {
				statusListData.code = "Success";
			} else if (statusListData.code.equalsIgnoreCase("ST03Failed")
					|| statusListData.code.equalsIgnoreCase("HANAQueryFailed")
					|| statusListData.code.equalsIgnoreCase("Not Completed")
					|| statusListData.code.equalsIgnoreCase("HANARefiningFailed")
					|| statusListData.code.equalsIgnoreCase("ROMRefiningFailed")) {
				statusListData.code = "Failed";
			} else if (statusListData.code.equalsIgnoreCase("HANAQuerySuccess")) {
				statusListData.code = "Success";
			} else if (statusListData.code.equalsIgnoreCase("Completed")) {
				statusListData.code = "Completed";
			} else if (statusListData.code.equalsIgnoreCase("HANARefiningSuccess")) {
				statusListData.code = "Success";
			} else if (statusListData.code.equalsIgnoreCase("ROMRefiningSuccess")) {
				statusListData.code = "Success";
			} else if (statusListData.code.equalsIgnoreCase("HanaRefiningCompleted")) {
				statusListData.code = "Completed ";
			} else if (statusListData.code.equalsIgnoreCase("RomRefiningCompleted")) {
				statusListData.code = "Completed ";
			} else if (statusListData.code.equalsIgnoreCase("Completed With Pending Estimations")) {
				statusListData.code = "Completed With Pending Estimations";
			}
		}

		model.addAttribute("statusList", statusList);
		model.addAttribute("status", status);
		model.addAttribute("requestIdUi", requestIdUi);
		model.addAttribute("requestId", requestId);
		model.addAttribute("UserName", userName);
		model.addAttribute("reqUIIdList", mainRequestIdList);

		if (CollectionUtils.isNotEmpty(requestDetailsList)) {
			model.addAttribute("requestList", requestDetailsList);
			model.addAttribute("totalRecords",
					getDashBoard().getTotalClientRequests(userName, status, requestId, toolName));
		} else {
			model.addAttribute("requestListEmptyMessage", "No request is created");
		}
		return "client/dashboard";

	}

	@RequestMapping(value = "/client/requestDetails/{requestID}", method = RequestMethod.GET)
	public String showRequestIDDetails(@PathVariable("requestID") long requestID, Model model) throws IOException {

		RequestForm requestForm = getRequestDetails().getRequestObj(requestID);
		RequestInventory requestInventory = (getClientRequestInventoryDAO().getRequestInventory(requestID));
		model.addAttribute("requestForm", requestForm);
		model.addAttribute("requestInventory", requestInventory);
		return "clientProcessRequest";

	}
	/* end of addition by rahul on 28122015 */

	// Upload Detailed Report from POC:::::::::::::::::
	@RequestMapping(value = "/poc/uploadDetailReport/{requestID}", method = RequestMethod.POST)
	public String uploadDetailReportFromPOC(@PathVariable("requestID") final long requestID,
			final RedirectAttributes redirectAttributes, final HttpServletRequest request, HttpSession session)
			throws FileUploadException, IOException, URISyntaxException {
		String comment = "";
		List<String> sheetList = new ArrayList<String>();
		sheetList.add("Inventory List");
		sheetList.add("Impacted Object List");
		sheetList.add("DR_DB Change");
		sheetList.add("DR_S4 Simplification-1");
		sheetList.add("DR_Existing Errors");
		sheetList.add("DR_FIORI ODATA");
		sheetList.add("Output Management");
		sheetList.add("Affected by Custom Fields");
		sheetList.add("Impacted Tables");
		sheetList.add("Impacted IDOC");
		sheetList.add("Impacted Standard Transaction");
		sheetList.add("Impacted Search Help");
		sheetList.add("Append Structure Analysis");
		sheetList.add("Impacted Clone Program Analysis");
		sheetList.add("Impacted Enhancement BADI");

		sheetList.add("DR_S4 Simplification-2");
		sheetList.add("DR_S4 Simplification-3");
		sheetList.add("UI5 Final Output");
		sheetList.add("UI5 High Level Report");
		sheetList.add("Testing Scope");

		for (String name : sheetList) {
			final Map<String, String> requiredColumnMap = UtilityForPoc.getPOCRequiredColumn(name);
			Map<String, Map<String, String>> requiredFileColumnProperty = new HashMap<String, Map<String, String>>();
			requiredFileColumnProperty.put(name, requiredColumnMap);
		}

		return comment;
	}

	/* CR-9.0 Monika */
	@RequestMapping(value = "/poc/uploadEstimations/{requestID}", method = RequestMethod.POST)
	public String uploadEstimations(@PathVariable("requestID") final long requestID,
			final RedirectAttributes redirectAttributes, final HttpServletRequest request, HttpSession session)
			throws FileUploadException {

		final RequestForm reuquestForm = getRequestDetails().getRequestObj(requestID);
		final String clientName = reuquestForm.getClientName();
		HANAUtility.deleteFile(clientName, requestID, null);
		final String filePath = HANAUtility.getFilePath(clientName, requestID);

		String toolName = (String) session.getAttribute("tool");

		DiskFileItemFactory factory = new DiskFileItemFactory();
		factory.setSizeThreshold(0);
		factory.setRepository(new File(HANAUtility.getRepositoryTemp(clientName, requestID)));

		ServletFileUpload upload = new ServletFileUpload(factory);
		upload.setFileSizeMax(-1);
		upload.setSizeMax(-1);

		String filename = "";
		List<FileItem> multipart = new ServletFileUpload(factory).parseRequest(request);

		logger.info("Inside Initial Data validation method");

		final String userName = getPrincipal();
		boolean isFileExists = false;

		/* File Validation Loop Validation of files **/

		for (FileItem item : multipart) {
			filename = "";
			if (!item.isFormField()) {
				try {
					isFileExists = true;
					filename = new File(item.getName()).getName();
					if (StringUtils.isNotEmpty(filename) && !"".equals(filename)) {
						String extension = Hana_Profiler_Constant.XLSX_EXTENSTION_CONSTANT;
						String fileExtension = filename.substring(filename.length() - extension.length(),
								filename.length());
						if (extension.equalsIgnoreCase(fileExtension)) {
							logger.info("Matched Extension");
							item.write(new File(filePath + File.separator + filename));
							logger.info("Wrote in file path");

						} else {
							redirectAttributes.addFlashAttribute("donLoadXlsxError",
									"Please Upload the file with .xlsx extension only.");
							return "redirect:/requestDetails/{requestID}";
						}

					} else {
						redirectAttributes.addFlashAttribute("donLoadXlsxError", "Please Upload atleast one file.");
						return "redirect:/requestDetails/{requestID}";
					}
				} catch (Exception exception) {
					redirectAttributes.addFlashAttribute("donLoadXlsxError", exception.getMessage());
					return "redirect:/requestDetails/{requestID}";
				}
			} else {
			}
		}

		String comment = readEstimatorData((filePath + File.separator + filename), requestID, request, toolName,
				session);
		if (comment.equalsIgnoreCase("success")) {
			redirectAttributes.addFlashAttribute("SucessMsg", "File uploaded successfully");
		} else {
			redirectAttributes.addFlashAttribute("donLoadXlsxError", comment);
		}
		return "redirect:/requestDetails/{requestID}";
	}

	/**
	 * This method sends email to user with the list of all the files that failed to
	 * upload.
	 * 
	 * @param userName
	 * @param requestID
	 * @param request
	 * @param fileList
	 * @param missingFiles
	 */
	private void sendEmailForFailedFiles(String userName, long requestID, HttpServletRequest request,
			Map<String, String> fileList, List<String> missingFiles, HttpSession session) {
		// Get the list of failed files.
		String failedFiles = "";
		Set<String> fileEntry = fileList.keySet();
		Iterator<String> iterator = fileEntry.iterator();
		int count = 0;
		while (iterator.hasNext()) {
			String key = iterator.next();
			String value = fileList.get(key);
			if (!(VALID.equalsIgnoreCase(value))) {
				key = key.trim();
				if (key.equalsIgnoreCase("ZAICAT_DETECTION")) {
					failedFiles += (++count) + ". " + "ZAICAT_DETECTION" + "\n";
				} else if (key.equalsIgnoreCase("cds")) {
					failedFiles += (++count) + ". " + "CDS VIEW" + "\n";
				} else if (key.equalsIgnoreCase("trd")) {
					failedFiles += (++count) + ". " + "TRDIR" + "\n";
				} else if (key.equalsIgnoreCase("INVENTORY LIST")) {
					failedFiles += (++count) + ". " + "INVENTORY LIST" + "\n";
				} else if (key.equalsIgnoreCase("SMODILOG")) {
					failedFiles += (++count) + ". " + "SMODILOG" + "\n";
				} else if (key.equalsIgnoreCase("ENHANCEMENT")) {
					failedFiles += (++count) + ". " + "ENHANCEMENT" + "\n";
				} else if (key.equalsIgnoreCase("Impacted IDOC")) {
					failedFiles += (++count) + ". " + "IMPACTED IDOC" + "\n";
				} else if (key.equalsIgnoreCase("Impacted Tables")) {
					failedFiles += (++count) + ". " + "IMPACTED TABLES" + "\n";
				} else if (key.equalsIgnoreCase("SEARCH")) {
					failedFiles += (++count) + ". " + "SEARCH_HELP" + "\n";
				} else if (key.equalsIgnoreCase("APPEND")) {
					failedFiles += (++count) + ". " + "APPEND STRUCTURE" + "\n";
				} else if (key.equalsIgnoreCase("IMPACTED CLONE")) {
					failedFiles += (++count) + ". " + "IMPACTED CLONE ANALYSIS" + "\n";
				} else if (key.equalsIgnoreCase("CLONE")) {
					failedFiles += (++count) + ". " + "CLONE ANALYSIS" + "\n";
				} else if (key.equalsIgnoreCase("Impacted Standard")) {
					failedFiles += (++count) + ". " + "IMPACTED STANDARD TRANSACTIONS" + "\n";
				} else if (key.equalsIgnoreCase("TADIR")) {
					failedFiles += (++count) + ". " + "TADIR" + "\n";
				} else if (key.equalsIgnoreCase("ACNIP_ZVER_COMP")) {
					failedFiles += (++count) + ". " + "ACNIP_ZVER_COMP" + "\n";
				} else {
					failedFiles += (++count) + ". " + key + "\n";
				}
			}
		}
		String missingFile = "";
		int missingCount = 0;
		if (null != missingFiles && !missingFiles.isEmpty()) {
			for (String fileName : missingFiles) {
				fileName = fileName.trim();
				if (fileName.equalsIgnoreCase("ZAICAT_DETECTION")) {
					missingFile += (++missingCount) + ". " + "ZAICAT_DETECTION" + "\n";
				} else if (fileName.equalsIgnoreCase("cds")) {
					missingFile += (++missingCount) + ". " + "CDS VIEW" + "\n";
				} else if (fileName.equalsIgnoreCase("trd")) {
					missingFile += (++missingCount) + ". " + "TRDIR" + "\n";
				} else if (fileName.equalsIgnoreCase("USAGE ANALYSIS")) {
					missingFile += (++missingCount) + ". " + "USAGE ANALYSIS" + "\n";
				} else if (fileName.equalsIgnoreCase("INVENTORY LIST")) {
					missingFile += (++missingCount) + ". " + "INVENTORY LIST" + "\n";
				} else if (fileName.equalsIgnoreCase("SMODILOG")) {
					missingFile += (++missingCount) + ". " + "SMODILOG" + "\n";
				} else if (fileName.equalsIgnoreCase("ENHANCEMENT")) {
					missingFile += (++missingCount) + ". " + "ENHANCEMENT" + "\n";
				} else if (fileName.equalsIgnoreCase("Impacted IDOC")) {
					missingFile += (++missingCount) + ". " + "IMPACTED IDOC" + "\n";
				} else if (fileName.equalsIgnoreCase("Impacted Tables")) {
					missingFile += (++missingCount) + ". " + "IMPACTED TABLES" + "\n";
				} else if (fileName.equalsIgnoreCase("SEARCH")) {
					missingFile += (++missingCount) + ". " + "SEARCH_HELP" + "\n";
				} else if (fileName.equalsIgnoreCase("APPEND")) {
					missingFile += (++missingCount) + ". " + "APPEND STRUCTURE" + "\n";
				} else if (fileName.equalsIgnoreCase("CLONE")) {
					missingFile += (++missingCount) + ". " + "CLONE ANALYSIS" + "\n";
				} else if (fileName.equalsIgnoreCase("Impacted Standard")) {
					missingFile += (++missingCount) + ". " + "IMPACTED STANDARD TRANSACTIONS" + "\n";
				} else if (fileName.equalsIgnoreCase("TADIR")) {
					missingFile += (++missingCount) + ". " + "TADIR" + "\n";
				} else if (fileName.equalsIgnoreCase("ACNIP_ZVER_COMP")) {
					missingFile += (++missingCount) + ". " + "ACNIP_ZVER_COMP" + "\n";
				} else {
					missingFile += (++missingCount) + ". " + fileName + "\n";
				}

			}
		}
		final RequestForm requestForm = getRequestDetails().getRequestObj(requestID);
		String requestUID = requestForm.getREQUEST_ID_UI();
		String emailContext = "https://" + request.getServerName() + ":" + request.getServerPort();
		Set<String> emailData = new HashSet<String>();
		Set<String> emailCc = new HashSet<String>();
		SendEmail email = new SendEmail();
		email.setMailFrom("IDC_SAPUpgrade_Sales@accenture.com");
		emailData.add(getEmailIDDao().getEmail(userName));
		emailCc.add("IDC_SAPUpgrade_Sales@accenture.com");
		email.setMailTo(emailData);
		email.setMailCC(emailCc);

		email.setMailSubject("File uploading failed for Request ID : " + requestUID);

		String emailBody = "\n\nDear " + userName
				+ ",\n\nPlease find the list of files that failed to upload for your request ID : " + requestUID + "";
		if (!failedFiles.isEmpty())
			emailBody += "\nFailed upload\n" + failedFiles;
		if (!missingFile.isEmpty())
			emailBody += "\nMissing Files\n" + missingFile;
		emailBody += "\nKindly upload the failed/ missing files.\n\n"
				/*
				 * + "Note - While uploading the input files " +
				 * "HANA Profiler, TSTC, TSTCP, ST03 Month data, Include Extractor,CDS_VIEW, TA_DIR and TR_DIR file is mandatory"
				 */
				+ "\n<a href=" + emailContext + "/hanaprofilerperformance/homepage"
				+ ">Client - View Request Detail</a>\n\n" + "\n\nRegards,\nS/4HANA conversion Team ATCI";
		logger.info("Email Body is written and email will be sent");
		email.setMailBody(emailBody);

		email.emailSend(email, request, session);
	}

	@RequestMapping(value = "/client/validateAndAnalyseData/{requestID}", method = RequestMethod.POST)
	public String validateFilesAndAnalyseData(@PathVariable("requestID") final long requestID,
			@RequestParam("files") MultipartFile[] files, Model model, final RedirectAttributes redirectAttributes,
			final HttpServletRequest request, final HttpSession session) throws FileUploadException {
		String toolName = (String) session.getAttribute("tool");
		String status = null;
		String rfpStatus = null;
		Map<String, String> fileList = new HashMap<String, String>();
		final String userName = getPrincipal();
		try {
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestID));
			RequestID_Validator_Utility.chckReqIdUser(reqIDValid.getCreator(reqIDValid.getRequestInv(requestID)),
					getPrincipal());
			final String allFilesNotPresentStatus = HANAUtility.getPropertyValue("testing.properties",
					"filelistnotokmessage");
			final RequestForm requestForm = getRequestDetails().getRequestObj(requestID);
			final String clientName = requestForm.getClientName();

			final String filePath = HANAUtility.getFilePath(clientName, requestID);
			boolean initialValidationSuccess = true;

			// We need to remove all such files that may have been leftover
			// from previous upload attempt. These files are left at the filePath location.
			File[] existingFiles = new File(filePath).listFiles();
			// If the left-over file is not a file rather a directory or something else,
			// then delete it.
			String existingFileName = "";
			if (existingFiles.length > 0) {
				for (File file : existingFiles) {
					existingFileName = file.getName().toUpperCase();
					if (!(existingFileName.endsWith("XLSX") || existingFileName.endsWith("XLS"))) {
						FileUtils.forceDelete(file);
						continue;
					}
					fileList.put(existingFileName, VALID);
				}
			}

			/*
			 * DiskFileItemFactory factory = new DiskFileItemFactory();
			 * factory.setSizeThreshold(0); factory.setRepository(new
			 * File(HANAUtility.getRepositoryTemp(clientName, requestID)));
			 * 
			 * ServletFileUpload upload = new ServletFileUpload(factory);
			 * upload.setFileSizeMax(-1); upload.setSizeMax(-1);
			 * 
			 * List<FileItem> multipart = upload.parseRequest(request); String
			 * fileUploadSelection = ""; for (FileItem item : multipart) { if
			 * (item.isFormField()) { if ("fileUploadSelection".equals(item.getFieldName()))
			 * { fileUploadSelection = item.getString(); } } }
			 */

			// Get the status of the request. If it is not approved or IDVFailed, then do
			// not proceed.
			status = getClientRequestInventoryDAO().getRequestInventory(requestID).getRequestStatus();
			rfpStatus = getClientRequestInventoryDAO().getRequestInventory(requestID).getRfpStatus();
			if (!StringUtils.equals(status, Hana_Profiler_Constant.APPROVED_STATUS)
					&& !StringUtils.equals(status, Hana_Profiler_Constant.IDVFAILED_STATUS)
					&& !StringUtils.equals(status, Hana_Profiler_Constant.ST03FAILED_STATUS)
					&& !StringUtils.equals(rfpStatus, Hana_Profiler_Constant.RFP_CLIENT_UL_FAILED_STATUS)
					&& !StringUtils.equals(rfpStatus, Hana_Profiler_Constant.RFP_CLIENT_PENDING_STATUS)) {
				redirectAttributes.addFlashAttribute("statusMessage", "The request is not approved.");
				return "redirect:/client/uploadFiles/{requestID}";
			}

			// Check if the file is a zip or multiple upload.
			boolean isZipFile = false;

			logger.info("Inside Initial Data validation method");
			getProcessingFileUploadValidator().setExtensionList(new ArrayList<String>());
			getProcessingFileUploadValidator().setExtensionList(Hana_Profiler_Constant.XLSX_FILE_EXTENSION);
			getProcessingFileUploadValidator().setExtensionList(Hana_Profiler_Constant.XLS_FILE_EXTENSION);
			/*
			 * if (StringUtils.equals(Hana_Profiler_Constant.UPLOAD_SINGLE_FILE_CONSTANT,
			 * fileUploadSelection)) { isZipFile = true; }
			 */

			boolean isFileExists = false;
			String fileName = "";

			// File Extension Validation Loop
			if (!isZipFile) {
				// Since multiple files are present, then check the extension of all the files.
				/*
				 * for (FileItem item : multipart) { fileName = ""; if (!item.isFormField()) {
				 * try { isFileExists = true; fileName = new File(item.getName()).getName();
				 * getProcessingFileUploadValidator().validate(fileName); if
				 * (StringUtils.isNotEmpty(fileName)) { // If same name file is already present,
				 * then delete the previous and copy the // new one. if
				 * (fileList.containsKey(fileName.toUpperCase())) {
				 * HANAUtility.deleteFile(clientName, requestID, fileName); } item.write(new
				 * File(filePath + File.separator + fileName)); }
				 * fileList.put(fileName.toUpperCase(), VALID); } catch (FileUploadException
				 * exception) { initialValidationSuccess = false;
				 * fileList.put(fileName.toUpperCase(), exception.getMessage()); } catch
				 * (Exception exception) { initialValidationSuccess = false;
				 * fileList.put(fileName.toUpperCase(), exception.getMessage());
				 * HANAUtility.deleteFile(clientName, requestID, fileName); } finally { if (null
				 * != item) { item.getOutputStream().close(); } } } }
				 */
				for (MultipartFile file : files) {
					try {
						isFileExists = true;
						fileName = file.getOriginalFilename();
						FileUtility.chckUploadFilesAlphaNum(fileName);
						getProcessingFileUploadValidator().validate(fileName);

						if (StringUtils.isNotEmpty(fileName)) {
							// If same name file is already present, then delete the previous and copy the
							// new one.
							if (fileList.containsKey(fileName.toUpperCase())) {
								HANAUtility.deleteFile(clientName, requestID, fileName);
							}
							byte[] bytes = file.getBytes();
							Path path = Paths.get(filePath + File.separator + fileName);
							Files.write(path, bytes);

							fileList.put(fileName.toUpperCase(), VALID);
						}
					} catch (UploadFilesNotValidException e) {
						model.addAttribute("errorMsg", e.getMessage());
						return "errors";
					} catch (FileUploadException exception) {
						initialValidationSuccess = false;
						fileList.put(fileName.toUpperCase(), exception.getMessage());
					} catch (Exception exception) {
						initialValidationSuccess = false;
						fileList.put(fileName.toUpperCase(), exception.getMessage());
						HANAUtility.deleteFile(clientName, requestID, fileName);
					}
				}
			} /*
				 * else { // This means it is a zip file. for (FileItem item : multipart) {
				 * fileName = ""; if (!item.isFormField()) { try { isFileExists = true; String
				 * zipfileName = new File(item.getName()).getName(); if
				 * (!zipfileName.toLowerCase().endsWith(Hana_Profiler_Constant.
				 * ZIP_EXTENSTION_CONSTANT)) { initialValidationSuccess = false; String message
				 * = "Please upload the file only in zip ext.";
				 * redirectAttributes.addFlashAttribute("statusMessage", message); break; }
				 * 
				 * // Extract the zip and copy all the files in the a temp directory first.
				 * String tempPath = filePath + File.separator + "temp" + File.separator; File
				 * tempDir = new File(tempPath); File correctDir = new File(filePath); if
				 * (StringUtils.isNotEmpty(zipfileName)) { if (!tempDir.exists()) {
				 * FileUtils.forceMkdir(tempDir); } item.write(new File(filePath +
				 * File.separator + zipfileName)); } ZipFileReadUtility.extractFile(filePath +
				 * File.separator + zipfileName, tempPath);
				 * ZipFileReadUtility.copyFileFromDirectory(filePath + File.separator,
				 * tempPath);
				 * 
				 * File zipFileDir = new File(tempPath); File[] zipFiles =
				 * zipFileDir.listFiles(); for (File file : zipFiles) { fileName =
				 * file.getName(); // If same name file is already present, then delete the
				 * previous one. if (fileList.containsKey(fileName.toUpperCase())) {
				 * HANAUtility.deleteFile(clientName, requestID, fileName); } try { if
				 * (!fileName.equalsIgnoreCase(tempDir.getName())) {
				 * getProcessingFileUploadValidator().validate(fileName);
				 * FileUtils.copyFileToDirectory(file, correctDir);
				 * fileList.put(fileName.toUpperCase(), VALID); } } catch (FileUploadException
				 * exception) { initialValidationSuccess = false;
				 * fileList.put(fileName.toUpperCase(), exception.getMessage()); // This means
				 * the file has invalid extension and we need to delete the file from //
				 * directory. HANAUtility.deleteFile(clientName, requestID, fileName); } catch
				 * (Exception exception) { initialValidationSuccess = false;
				 * fileList.put(fileName.toUpperCase(), exception.getMessage());
				 * HANAUtility.deleteFile(clientName, requestID, fileName); } }
				 * 
				 * // After copying the files from the zip file, delete the temp folder.
				 * FileUtils.deleteDirectory(tempDir); } catch (FileUploadException exception) {
				 * initialValidationSuccess = false; fileList.put(fileName.toUpperCase(),
				 * exception.getMessage()); // This means the file has invalid extension and we
				 * need to delete the file from // directory. HANAUtility.deleteFile(clientName,
				 * requestID, fileName); } catch (Exception exception) {
				 * initialValidationSuccess = false; fileList.put(fileName.toUpperCase(),
				 * exception.getMessage()); HANAUtility.deleteFile(clientName, requestID,
				 * fileName); } finally { if (null != item) { item.getOutputStream().close(); }
				 * } } } }
				 */
			if (!isFileExists) {
				redirectAttributes.addFlashAttribute("statusMessage", "Please Upload atleast one file.");
				return "redirect:/client/uploadFiles/{requestID}";
			}

			/*
			 * CR 18- Moved the code for file validation and check for all the sufficient
			 * files present to a private method so that it can be re-used in delete as well
			 * as upload functionality.
			 */
			Map<String, Object> returnMap = checkListAndValidate(filePath, fileList, clientName, requestID, userName,
					session);
			status = (String) returnMap.get("status");
			@SuppressWarnings("unchecked")
			List<String> missingFiles = (List<String>) returnMap.get("missingFiles");
			redirectAttributes.addFlashAttribute("fileList", fileList);
			if (Hana_Profiler_Constant.IDVFAILED_STATUS.equals(status)) {
				sendEmailForFailedFiles(userName, requestID, request, fileList, missingFiles, session);
			}
			if (!initialValidationSuccess) {
				// initial validation has failed.
				status = Hana_Profiler_Constant.IDVFAILED_STATUS;
				getRequestInventorydao().updateSatus(requestID, status, userName, allFilesNotPresentStatus, toolName);
			}
		} catch (ReqIDNotValidException ex) {
			model.addAttribute("errorMsg", ex.getMessage());
			return "errors";
		} catch (Exception e) {
			logger.error("Some error happened. Check the logs. " , e.getMessage());
			status = Hana_Profiler_Constant.IDVFAILED_STATUS;
			getRequestInventorydao().updateSatus(requestID, status, userName, e.getMessage(), toolName);
		}
		return "redirect:/client/uploadFiles/{requestID}";
	}

	/**
	 * CR 18: This method deletes the files selected from the UI while uploading
	 * files.
	 * 
	 * @param request
	 * @param redirectAttributes
	 * @return
	 */
	@RequestMapping(value = "/client/uploadFiles/deleteFiles")
	public String deleteFiles(HttpServletRequest request, final RedirectAttributes redirectAttributes,
			final HttpSession session) {
		String toolName = (String) session.getAttribute("tool");
		try {
			logger.info("Inside deleteFiles method");
			boolean deleted = false;
			String fileName = request.getParameter("fileName");
			Long requestId = Long.valueOf(request.getParameter("requestId"));
			String clientName = getRequestDetails().getRequestObj(requestId).getClientName();
			ArrayList<String> scope = getRequestDetails().getRequestObj(requestId).getScope();
			String[] fileNames = fileName.split(",");
			for (String file : fileNames) {
				if (!file.equalsIgnoreCase(",")) {
					HANAUtility.deleteUploadFile(clientName, requestId, file);
					deleted = true;
				}
			}
			if (deleted) {
				final String userName = getPrincipal();
				String comments = HANAUtility.getPropertyValue("testing.properties", "filelistnotokmessage");
				getRequestInventorydao().updateSatus(requestId, Hana_Profiler_Constant.IDVFAILED_STATUS, userName,
						comments, toolName);
			}

			Map<String, String> fileList = new HashMap<String, String>();
			String filePath = HANAUtility.getFilePath(clientName, requestId);
			File[] existingFiles = new File(filePath).listFiles();
			for (File file : existingFiles) {
				fileList.put(file.getName().toUpperCase(), VALID);
			}

			Map<String, Object> returnMap = checkListAndValidate(filePath, fileList, clientName, requestId,
					getPrincipal(), session);
			redirectAttributes.addFlashAttribute("fileList", fileList);
			redirectAttributes.addAttribute("requestID", requestId);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return "redirect:/client/uploadFiles/{requestID}";
	}

	/**
	 * This method check if all the necessary files required for Hana Request
	 * Processing are present or not Also validates the files and if invalid deletes
	 * the files uploaded in file directory.
	 * 
	 * @param filePath
	 * @param fileList
	 * @param clientName
	 * @param requestID
	 * @param userName
	 * @return
	 */
	private Map<String, Object> checkListAndValidate(String filePath, Map<String, String> fileList, String clientName,
			Long requestID, String userName, final HttpSession session) {
		String toolName = (String) session.getAttribute("tool");
		final RequestForm requestForm = getRequestDetails().getRequestObj(requestID);
		final UploadFilesNumber uploadFileNum = getRequestDetails().getnumOfUploadFiles(requestID);
		BwObjectTypeDateFormat dateAndObj = bwCleanDao.getBwObjectType(requestID);
		Map<String, String> filesNameWithStatus= new HashMap<String, String>();
		Map<String, Object> returnMap = new HashMap<String, Object>();
		String comments = "";
		String status = "";
		List<String> missingFiles = new ArrayList<String>();
		try {
			logger.info("Inside checkListAndValidate");
			initialDataValidation = new InitialDataValidation(filePath);
			CheckFileListStatus checkObject = new CheckFileListStatus(filePath);

			boolean checkListStatus = true;
			if (requestForm.getBwUsage())
				filesNameWithStatus = checkObject.checkListStatusBWusage(toolName, requestForm, uploadFileNum, dateAndObj);
			else
				filesNameWithStatus = checkObject.checkListStatus(toolName, requestForm, uploadFileNum);
			Iterator<String> listKeysIterator = filesNameWithStatus.keySet().iterator();
			Map<String, String> tempMap = new HashMap<>();
			while (listKeysIterator.hasNext()) {
				String checkListName = listKeysIterator.next();
				// If the files is not present corresponding to checkList.
				if (!(filesNameWithStatus.get(checkListName)).equalsIgnoreCase(VALID)) {
					// If all the required files are not present then, add the missing files.
					checkListStatus = false;
					missingFiles.add(checkListName);
				} else {
					for (Map.Entry<String, String> entry : fileList.entrySet()) {
						if (entry.getKey().startsWith(checkListName.toUpperCase())) {
							tempMap.put(entry.getKey(), VALID);
						}
					}
				}
			}
			boolean isAnyInvalidFile = false;
			// At the end, make all the files that have unexpected name as invalid.
			for (Map.Entry<String, String> entry : fileList.entrySet()) {
				if (!tempMap.containsKey(entry.getKey())) {
					isAnyInvalidFile = true;
					if (fileList.get(entry.getKey()).equalsIgnoreCase(VALID)) {
						fileList.put(entry.getKey(), "INVALID FILE NAME.");
					}
				}
			}
			logger.info("after checkListStatus");

			// If all required file are present, then proceed for XLSX validation.
			try {
				if (initialDataValidation.validateAllFiles(fileList, clientName, requestID, toolName)) {
					String message = HANAUtility.getPropertyValue("testing.properties", "filelistokmessage");
					logger.info("inside if block ");
					status = Hana_Profiler_Constant.IDVSUCESS_STATUS;
					getRequestInventorydao().updateSatus(requestID, status, userName,
							Hana_Profiler_Constant.UPLOAD_INPUT_FILES_SUCC, toolName);
					if (requestForm.getRFP()) {
						getRequestInventorydao().updateRfpSatus(requestID,
								Hana_Profiler_Constant.RFP_CLIENT_UL_SUCCESS_STATUS, getPrincipal(), toolName, null,
								Hana_Profiler_Constant.RFP_UPLOAD_SUCC);
					}

				} else {
					// Somehow validation of files have failed and instead of throwing an exception
					// it has returned false.
					logger.info("inside else block ");
					status = Hana_Profiler_Constant.IDVFAILED_STATUS;
					String allFilesNotPresentStatus = HANAUtility.getPropertyValue("testing.properties",
							"filelistnotokmessage");
					getRequestInventorydao().updateSatus(requestID, status, userName,
							Hana_Profiler_Constant.UPLOAD_INPUT_FILES_FAIL, toolName);
					if (requestForm.getRFP()) {
						getRequestInventorydao().updateRfpSatus(requestID,
								Hana_Profiler_Constant.RFP_CLIENT_UL_FAILED_STATUS, getPrincipal(), toolName, null,
								Hana_Profiler_Constant.RFP_UPLOAD_FAIL);
					}
				}
				if (!checkListStatus || isAnyInvalidFile) {
					if (!missingFiles.isEmpty()) {
						comments = "Please upload " + missingFiles + " files for processing this request.";
					} else {
						comments = "Please upload valid files only";
					}
					status = Hana_Profiler_Constant.IDVFAILED_STATUS;
					getRequestInventorydao().updateSatus(requestID, status, userName,
							Hana_Profiler_Constant.UPLOAD_INPUT_FILES_FAIL, toolName);
					if (requestForm.getRFP()) {
						getRequestInventorydao().updateRfpSatus(requestID,
								Hana_Profiler_Constant.RFP_CLIENT_UL_FAILED_STATUS, getPrincipal(), toolName, null,
								Hana_Profiler_Constant.RFP_UPLOAD_FAIL);
					}
				}
			} catch (IDVFailedException e) {
				logger.error("In IDV Failed catch: " , e.getMessage());
				logger.error("Error checkListAndValidate :: " , e);
				status = Hana_Profiler_Constant.IDVFAILED_STATUS;
				getRequestInventorydao().updateSatus(requestID, status, userName,
						Hana_Profiler_Constant.UPLOAD_INPUT_FILES_FAIL, toolName);
				if (requestForm.getRFP()) {
					getRequestInventorydao().updateRfpSatus(requestID,
							Hana_Profiler_Constant.RFP_CLIENT_UL_FAILED_STATUS, getPrincipal(), toolName, null,
							Hana_Profiler_Constant.RFP_UPLOAD_FAIL);
				}
			} catch (Exception e) {
				logger.error("In Exception catch: " , e.getMessage());
				logger.error("Error in checkListAndValidate " , e);
				status = Hana_Profiler_Constant.IDVFAILED_STATUS;
				getRequestInventorydao().updateSatus(requestID, status, userName,
						Hana_Profiler_Constant.UPLOAD_INPUT_FILES_FAIL, toolName);
				if (requestForm.getRFP()) {
					getRequestInventorydao().updateRfpSatus(requestID,
							Hana_Profiler_Constant.RFP_CLIENT_UL_FAILED_STATUS, getPrincipal(), toolName, null,
							Hana_Profiler_Constant.RFP_UPLOAD_FAIL);
				}
			}

		} catch (IOException e) {
			logger.error(e.getMessage());
		}
		returnMap.put("status", status);
		returnMap.put("missingFiles", missingFiles);
		return returnMap;
	}

	@RequestMapping(value = "/client/viewReports/{requestId}", method = RequestMethod.GET)
	public String viewReports(@PathVariable("requestId") final long requestID,
			@RequestParam(value = "action", required = false) String action, Model model, HttpSession session,
			RedirectAttributes redirectAttributes) {
		try {
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestID));
			RequestID_Validator_Utility.chckReqIdUser(reqIDValid.getCreator(reqIDValid.getRequestInv(requestID)),
					getPrincipal());

			final RequestForm requestForm = getRequestDetails().getRequestObj(requestID);

			RequestInventory requestInventory = getClientRequestInventoryDAO()
					.getRequestInventory(requestForm.getRequestID());

			Map<String, String> scopeMap = new HashMap<String, String>();
			boolean scopeHana = requestForm.getSOH();
			boolean scopeS4 = requestForm.getS4Technical();
			boolean scopeFIAT = requestForm.getS4Functional();
			boolean scopeUI5 = requestForm.getUI5();
			boolean scopeFiori = requestForm.getFiori();
			boolean scopeAUCT = requestForm.getUPGRADE();
			boolean scopeSIA = requestForm.getSia();
			boolean scopeGRC = requestForm.getGrc();
			boolean scopeOSMigration = requestForm.getOsMig();
			boolean scopeBWTech = requestForm.getBwTech();
			boolean scopeBWusage = requestForm.getBwUsage();
			boolean scopeEXT = requestForm.getEXT();

			String targetSystem = requestForm.getTargetVersion();

			Map<String, ProcessedRequestDetail> reqMap = new HashMap<String, ProcessedRequestDetail>();

			// ProcessedRequestDetail reqMaster = new ProcessedRequestDetail();
			List<ProcessedRequestDetail> reqMasterList = getGraphDao().getReqMaster(requestID);
			if (!reqMasterList.isEmpty() && reqMasterList.size() > 0) {
				for (ProcessedRequestDetail req : reqMasterList) {
					reqMap.put(req.getScope(), req);
				}
				// reqMaster = reqMasterList.get(0);
			}

			TestingScope testingScopeMaster = new TestingScope();
			List<TestingScope> testingReqMasterList = getGraphDao().getTestingReqMaster(requestID);
			if (!testingReqMasterList.isEmpty() && testingReqMasterList.size() > 0) {
				testingScopeMaster = testingReqMasterList.get(0);
			}

			FioriRequestMaster fioriRequestMaster = new FioriRequestMaster();
			List<FioriRequestMaster> fioriRequestMasterList = getGraphDao().getFioriRequestMaster(requestID);
			if (!fioriRequestMasterList.isEmpty() && fioriRequestMasterList.size() > 0) {
				fioriRequestMaster = fioriRequestMasterList.get(0);
			}

			UI5GraphCounts uI5GraphMaster = new UI5GraphCounts();
			List<UI5GraphCounts> UI5GraphCountsList = getGraphDao().getUI5Master(requestID);
			if (!UI5GraphCountsList.isEmpty() && UI5GraphCountsList.size() > 0) {
				uI5GraphMaster = UI5GraphCountsList.get(0);
			}

			ImpactedBackgroundCounts impactedBackgroundCounts = new ImpactedBackgroundCounts();
			List<ImpactedBackgroundCounts> impactedBackgroundCountsList = getGraphDao()
					.getImpactedBackgroundCounts(requestID);
			if (!impactedBackgroundCountsList.isEmpty() && impactedBackgroundCountsList.size() > 0) {
				impactedBackgroundCounts = impactedBackgroundCountsList.get(0);
			}

			ExtensionScope extensionScope = new ExtensionScope();
			List<ExtensionScope> extensionScopeList = getGraphDao().getExtensionScopeMaster(requestID);
			if (!extensionScopeList.isEmpty() && extensionScopeList.size() > 0) {
				extensionScope = extensionScopeList.get(0);
			}

			Map<String, ArrayList<String>> ProbableFitmentStandardAppsCount = getGraphDao()
					.getProbableFitmentStandardAppsTable(requestID);

			if (scopeHana) {
				scopeMap.put("soh", "Impact due to HANA DB");
				ProcessedRequestDetail reqMaster = reqMap.get("Hana");

				// Slide no. 6(Hana) && 16(S4)
				model.addAttribute("ImpactedVSUsedObjects",
						reportGraphService.getImpactedVSUsedObjects(requestID, reqMaster));
				// Slide no. 7.1(Hana) && 17.1(S4)
				model.addAttribute("ImpactedABAPObjects",
						reportGraphService.getImpactedABAPObjects(requestID, reqMaster));
				// Slide no. 7.2(Hana) && 17.2(S4)
				model.addAttribute("CustomInventoryObjects",
						reportGraphService.getCustomInventoryObjects(requestID, reqMaster));
				// Slide no. 10 (Hana)
				model.addAttribute("ManNumCorErTy", reportGraphService.getManNumCorErrorTypeHana(requestID, reqMaster));
				// Slide 8.1(Hana) && Slide 18.1(S4)
				model.addAttribute("ImpactedRemediationCategoryCount",
						reportGraphService.getImpactedRemediationCategoryCount(requestID, reqMaster));
				// Slide 8.2(Hana) && Slide 18.2(S4)
				model.addAttribute("ErrorRemediationCategoryCount",
						reportGraphService.getErrorRemediationCategoryCount(requestID, reqMaster));
				// Slide 9.1 Hana
				model.addAttribute("RemediationAndCorrectionTypeCounts",
						reportGraphService.getRemediationAndCorrectionTypeCounts(requestID, reqMaster));
				// Slide 9.2 Hana
				model.addAttribute("ErrorRemediationAndCorrectionTypeCounts",
						reportGraphService.getErrorRemediationAndCorrectionTypeCounts(requestID, reqMaster));
				// Slide 12 Hana
				model.addAttribute("DBLevelHanaOptimizationCounts",
						reportGraphService.getDBLevelHanaOptimizationCounts(requestID, reqMaster));
				// Slide 13 Hana
				model.addAttribute("ApplicationLevelOptimizationCount",
						reportGraphService.getApplicationLevelOptimizationCount(requestID, reqMaster));
				// Slide14 - 2 level Hierarchial
				model.addAttribute("HouseKeepingForHANACounts",
						reportGraphService.getHouseKeepingForHANACounts(requestID, reqMaster));
				// Slide no. 11
				model.addAttribute("MandatoryCorrectionsbyIssueErrorAutomation",
						reportGraphService.getMandatoryCorrectionsByIssueErrorAutomationHana(requestID, reqMaster));
			}
			if (scopeS4) {
				scopeMap.put("s4Technical", "Simplification Technical Analysis");
				ProcessedRequestDetail reqMaster = reqMap.get("S4");
				// Slide no. 6(Hana) && 16(S4)
				model.addAttribute("S4ImpactedVSUsedObjects",
						reportGraphService.getImpactedVSUsedObjects(requestID, reqMaster));
				// Slide no. 7.1(Hana) && 17.1(S4)
				model.addAttribute("S4ImpactedABAPObjects",
						reportGraphService.getImpactedABAPObjects(requestID, reqMaster));
				// Slide no. 7.2(Hana) && 17.2(S4)
				model.addAttribute("S4CustomInventoryObjects",
						reportGraphService.getCustomInventoryObjects(requestID, reqMaster));
				// Slide 18.1(S4)
				model.addAttribute("S4ImpactedRemediationCategoryCount",
						reportGraphService.getImpactedRemediationCategoryCount(requestID, reqMaster));
				// Slide 18.2(S4)
				model.addAttribute("S4ErrorRemediationCategoryCount",
						reportGraphService.getErrorRemediationCategoryCount(requestID, reqMaster));
				// Slide 19
				model.addAttribute("FunctionalAreaObjectCount",
						reportGraphService.getFunctionalAreaObjectCount(requestID, reqMaster));
				// Slide 20.1
				model.addAttribute("RemidiIssueCatCount",
						reportGraphService.getRemidiIssueCatCount(requestID, reqMaster));
				// Slide 20.2
				model.addAttribute("RemidiIssueCatErrorCount",
						reportGraphService.getRemidiIssueCatErrorCount(requestID, reqMaster));
				// Slide 21
				model.addAttribute("SimplificationCategoryObjectCount",
						reportGraphService.getSimplificationCategoryObjectCount(requestID, reqMaster));
				// Slide 22
				model.addAttribute("RemediationCategoryCounts",
						reportGraphService.getRemediationCategoryCounts(requestID, reqMaster));
			}
			if (scopeFIAT) {
				scopeMap.put("s4Functional", "Simplification Functional Analysis");
			}
			// Testing Scope
			if (scopeHana || scopeS4 || scopeAUCT) {
				scopeMap.put("testingScope", "Testing Scope");
				try {
					model.addAttribute("ProcessObjectCount",
							reportGraphService.getTestingScopeProcessCount(requestID, testingScopeMaster));
					model.addAttribute("ProcessMasterMap",
							reportGraphService.getTestingScopeProcessMaster(requestID, testingScopeMaster));
					model.addAttribute("ProcessHeatMap",
							reportGraphService.getTestingScopeProcessCount(requestID, testingScopeMaster));
					model.addAttribute("UniqueCustomAndStandardCount",
							reportGraphService.getUniqueCustomAndStandard(requestID, testingScopeMaster));
				} catch (Exception e) {
					logger.error("Error while retrieving TScope Master Data !!! ", e);
				}
			}

			if ((scopeHana || scopeS4 || scopeAUCT)
					&& AppGenUtility.getTScopeVer(requestForm.getSourceVersion(), requestForm.getTargetVersion())
					&& getTestingScopeService().irpaTScopeRowCount(requestID) > 0) {
				try {
					scopeMap.put("irpaTScope", ST03HanaConstant.IRPA_SCOPE);
				
					// IRPA - Status
					RequestStatusMaster reqStatusMasterObj = getRequestDetails().getReqStatusMaster(requestID);
					if(reqStatusMasterObj != null)
						model.addAttribute("irpaStatus", reqStatusMasterObj.getIrpaStatus());
					
					// IRPA - Graph - 1 - Overview of Testing Scope
					org.json.JSONObject irpaImpactedCounts = getTestingScopeService().getGraphOneRMJSONObj(requestID);
					if(irpaImpactedCounts != null)
						model.addAttribute("irpaImpactedCounts", irpaImpactedCounts);
					
					// IRPA - Graph - 2 - Overview of Business Scenarios
					org.json.JSONObject irpaTScopeJSONObj = getTestingScopeService().getScenarioReqMasterJSONObject(requestID);
					if(irpaTScopeJSONObj != null)
						model.addAttribute("irpaTScopeJSONObj", irpaTScopeJSONObj);
	
					// IRPA - Estimators
					IRPATScopeEstimatesModel estimatorObj = getTestingScopeService().getIRPAEstimatesModel(requestID);
					if(estimatorObj != null)
						model.addAttribute("estimatorObj", estimatorObj);
				} catch (Exception e) {
					model.addAttribute("irpaErrorMsg", ST03HanaConstant.IRPA_ERROR_MSG);
				}
			}

			if (scopeSIA) {
				scopeMap.put("SIA", "SIA");
			}
			if (scopeGRC) {
				scopeMap.put("GRC", "GRC");
			}
			if (scopeBWTech) {
				scopeMap.put("BW_Tech", "BW_Tech");
			}
			if (scopeBWusage) {
				scopeMap.put("BW_Usage", "BW_Usage");
			}

			// Impacted Background Job
			if (scopeHana || scopeS4 || scopeAUCT) {
				scopeMap.put("impactedBcgJob", "Impacted Background Job");
				model.addAttribute("cobj",
						reportGraphService.getImpactedBackgroundJobCounts(requestID, impactedBackgroundCounts));

			}
			if (scopeUI5) {
				scopeMap.put("ui5", "UI5 Impact Analysis");

				model.addAttribute("TotalAPICounts", reportGraphService.getTotalAPICounts(requestID, uI5GraphMaster));
				model.addAttribute("DeprecatedAPICounts",
						reportGraphService.getDeprecatedAPICounts(requestID, uI5GraphMaster));

			}
			if (scopeFiori) {
				scopeMap.put("fiori", "Fiori / OData Assement");

				model.addAttribute("IOSFAApp",
						reportGraphService.getInventoryOfStandardFioriAAppCounts(requestID, fioriRequestMaster));
				model.addAttribute("IOSFAAppTypes", reportGraphService.getIOSFAAppTypes(requestID, fioriRequestMaster));
				model.addAttribute("IOEFA", reportGraphService.getIOEFACounts(requestID, fioriRequestMaster));
				model.addAttribute("IOCFO", reportGraphService.getIOCFOCounts(requestID, fioriRequestMaster));
				model.addAttribute("IICOSManvNMan",
						reportGraphService.getIICOSManvNManCounts(requestID, fioriRequestMaster));
				model.addAttribute("IICOS", reportGraphService.getIICOSCounts(requestID, fioriRequestMaster));
				model.addAttribute("AESAHana", reportGraphService.getAESAHanaCounts(requestID, fioriRequestMaster));
				model.addAttribute("IoE", reportGraphService.getIoECounts(requestID, fioriRequestMaster));

				model.addAttribute("PFSA", reportGraphService.getPFSACounts(requestID, fioriRequestMaster));

				model.addAttribute("ProbableFitmentStandardAppsCount", ProbableFitmentStandardAppsCount);

			}
			if (scopeAUCT) {
				scopeMap.put("upgrade", "Functional Insight");
			}
			if (scopeEXT) {
				scopeMap.put("EXT", "Extensibility Recommendation");
				model.addAttribute("totalObjects",
						reportGraphService.getExtensionScopeMaster(requestID, extensionScope.getTotalObjsCount()));
				model.addAttribute("RicefObjectCount",
						reportGraphService.getExtensionScopeMaster(requestID, extensionScope.getTotalRicefCount()));
				model.addAttribute("OthersObjectCount",
						reportGraphService.getExtensionScopeMaster(requestID, extensionScope.getOthersRicefCount()));
				model.addAttribute("ComplexityCount", reportGraphService.getExtensionScopeMaster(requestID,
						extensionScope.getTotalComplexityCount()));

				model.addAttribute("extensionCount",
						reportGraphService.getExtensionScopeMaster(requestID, extensionScope.getTotalExtensionCount()));

				model.addAttribute("formsExtensionCount",
						reportGraphService.getExtensionScopeMaster(requestID, extensionScope.getForms_Extension()));
				model.addAttribute("interfaceExtensionCount",
						reportGraphService.getExtensionScopeMaster(requestID, extensionScope.getInterface_Extension()));
				model.addAttribute("workflowExtensionCount",
						reportGraphService.getExtensionScopeMaster(requestID, extensionScope.getWorkflow_Extension()));
				model.addAttribute("enhancementExtensionCount", reportGraphService.getExtensionScopeMaster(requestID,
						extensionScope.getEnhancement_Extension()));
				model.addAttribute("conversionExtensionCount", reportGraphService.getExtensionScopeMaster(requestID,
						extensionScope.getConversion_Extension()));
				model.addAttribute("reportsExtensionCount",
						reportGraphService.getExtensionScopeMaster(requestID, extensionScope.getReports_Extension()));

				model.addAttribute("reportsComplexityCount",
						reportGraphService.getExtensionScopeMaster(requestID, extensionScope.getReports_Complexity()));
				model.addAttribute("formsComplexityCount",
						reportGraphService.getExtensionScopeMaster(requestID, extensionScope.getForms_Complexity()));
				model.addAttribute("interfaceComplexityCount", reportGraphService.getExtensionScopeMaster(requestID,
						extensionScope.getInterface_Complexity()));
				model.addAttribute("enhancementComplexityCount", reportGraphService.getExtensionScopeMaster(requestID,
						extensionScope.getEnhancement_Complexity()));
				model.addAttribute("conversionComplexityCount", reportGraphService.getExtensionScopeMaster(requestID,
						extensionScope.getConversion_Complexity()));
				model.addAttribute("workflowComplexityCount",
						reportGraphService.getExtensionScopeMaster(requestID, extensionScope.getWorkflow_Complexity()));
				model.addAttribute("stackedComplexityCount", reportGraphService.getExtensionScopeMasterStack(requestID,
						extensionScope.getStackedComplexityCount()));
				model.addAttribute("stackedExtensionCount", reportGraphService.getExtensionScopeMasterStack(requestID,
						extensionScope.getStackedExtensionCount()));
				model.addAttribute("targetSystem", targetSystem);
			}
			if (scopeOSMigration)
				scopeMap.put("osMigration", "OS Migration");

			model.addAttribute("requestID", requestID);
			model.addAttribute("requestIdUI", requestForm.getREQUEST_ID_UI());
			model.addAttribute("requestStatus", requestInventory.getRequestStatus());
			model.addAttribute("pocStatus", requestInventory.getPoc_status());
			model.addAttribute("ScopeMap", scopeMap);
			if (requestForm.getSia()) {
				model.addAttribute("outFileCnt", getSecAnalyseService().getOutputFileCount(session, requestID));
			}
		} catch (ReqIDNotValidException ex) {
			model.addAttribute("errorMsg", ex.getMessage());
			return "errors";
		} catch (Exception e) {
			logger.error("Error !!! ", e);
		}
		
		return "client/viewReports";
	}

	// New updated View Reports
		@RequestMapping(value = "/client/viewReportsUpdate/{requestId}", method = RequestMethod.GET)
		public String viewReportsUpdated(@PathVariable("requestId") long requestID, Model model, HttpSession session,
				RedirectAttributes redirectAttributes) {
			try {
				// Validation
				RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestID));
				RequestID_Validator_Utility.chckReqIdUser(reqIDValid.getCreator(reqIDValid.getRequestInv(requestID)),
						getPrincipal());

				RequestForm requestForm = getRequestDetails().getRequestObj(requestID);
				RequestInventory requestInventory = getClientRequestInventoryDAO()
						.getRequestInventory(requestForm.getRequestID());

				// scopeMap - Contains the scopes for a request
				Map<String, String> scopeMap = new HashMap<String, String>();

				// Scopes
				boolean scopeHANA = requestForm.getSOH();
				boolean scopeS4 = requestForm.getS4Technical();
				boolean scopeAUCT = requestForm.getUPGRADE();
				boolean scopeEXT = requestForm.getEXT();
		
				boolean scopeFIAT = requestForm.getS4Functional();
				boolean scopeUI5 = requestForm.getUI5();
				boolean scopeFiori = requestForm.getFiori();
				boolean scopeSIA = requestForm.getSia();
				boolean scopeGRC = requestForm.getGrc();
				boolean scopeOSMigration = requestForm.getOsMig();
				boolean scopeBWTech = requestForm.getBwTech();
				boolean scopeBWusage = requestForm.getBwUsage();
				
				if (scopeHANA) {
					scopeMap.put("soh", "Impact due to HANA DB");
				}	
				
				if (scopeS4) {
					scopeMap.put("s4Technical", "Simplification Technical Analysis");
				}	

				if (scopeFIAT) {
					scopeMap.put("s4Functional", "Simplification Functional Analysis");
				}
				
				if (scopeHANA || scopeS4 || scopeAUCT) {
					scopeMap.put("testingScope", "Testing Scope");
				}
				// Impacted Background Job
				if (scopeHANA || scopeS4 || scopeAUCT) {
					scopeMap.put("impactedBcgJob", "Impacted Background Job");
				}
				
				if (scopeUI5) {
					scopeMap.put("ui5", "UI5 Impact Analysis");
				}	
				
				if (scopeFiori) {
					scopeMap.put("fiori", "Fiori / OData Assement");
				}	
				if (scopeAUCT) {
					scopeMap.put("upgrade", "Functional Insight");
				}
				
				if (scopeOSMigration) {
					scopeMap.put("osMigration", "OS Migration");
				}
				
				if (scopeSIA) {
					scopeMap.put("SIA", "SIA");
				}
				if (scopeGRC) {
					scopeMap.put("GRC", "GRC");
				}
				if (scopeBWTech) {
					scopeMap.put("BW_Tech", "BW_Tech");
				}
				if (scopeBWusage) {
					scopeMap.put("BW_Usage", "BW_Usage");
				}
				if (scopeEXT) {
					scopeMap.put("EXT", "Extensibility Recommendation");
				}	
				
				
				// IRPA Tile
				if ((scopeHANA || scopeS4 || scopeAUCT)
						&& AppGenUtility.getTScopeVer(requestForm.getSourceVersion(), requestForm.getTargetVersion())
						&& getTestingScopeService().irpaTScopeRowCount(requestID) > 0) {
					try {
						scopeMap.put("irpaTScope", ST03HanaConstant.IRPA_SCOPE);

						// IRPA - Status
						//RequestStatusMaster reqStatusMasterObj = getRequestDetails().getReqStatusMaster(requestID);
						//if (reqStatusMasterObj != null)
							//model.addAttribute("irpaStatus", reqStatusMasterObj.getIrpaStatus());
					} catch (Exception e) {
						model.addAttribute("irpaErrorMsg", ST03HanaConstant.IRPA_ERROR_MSG);
					}
				}
				
				if (requestForm.getSia()) {
                    model.addAttribute("outFileCnt", getSecAnalyseService().getOutputFileCount(session, requestID));
                }
				
				model.addAttribute("requestID", requestID);
				model.addAttribute("requestIdUI", requestForm.getREQUEST_ID_UI());
				model.addAttribute("requestStatus", requestInventory.getRequestStatus());
				model.addAttribute("pocStatus", requestInventory.getPoc_status());
				model.addAttribute("ScopeMap", scopeMap);
			} catch (ReqIDNotValidException ex) {
				model.addAttribute("errorMsg", ex.getMessage());
				return "errors";
			} catch (Exception e) {
				logger.error("Error !!! ", e);
			}

			return "client/viewReportsUpdate";
		}

		// IRPA Graphs
		@RequestMapping(value = "/client/IRPAGraphs/{requestId}", method = RequestMethod.GET)
		public String viewIRPAGraphs(@PathVariable("requestId") long requestID, Model model, HttpSession session) {
			try {
				// Validation
				RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestID));
				RequestID_Validator_Utility.chckReqIdUser(reqIDValid.getCreator(reqIDValid.getRequestInv(requestID)),
						getPrincipal());

				// IRPA - Graph - 1 - Overview of Testing Scope
				org.json.JSONObject irpaImpactedCounts = getTestingScopeService().getGraphOneRMJSONObj(requestID);
				if (irpaImpactedCounts != null)
					model.addAttribute("irpaImpactedCounts", irpaImpactedCounts);

				// IRPA - Graph - 2 - Overview of Business Scenarios
				org.json.JSONObject irpaTScopeJSONObj = getTestingScopeService().getScenarioReqMasterJSONObject(requestID);
				if (irpaTScopeJSONObj != null)
					model.addAttribute("irpaTScopeJSONObj", irpaTScopeJSONObj);

				model.addAttribute("requestID", requestID);
			} catch (ReqIDNotValidException ex) {
				model.addAttribute("errorMsg", ex.getMessage());
				return "errors";
			} catch (Exception e) {
				logger.error("Error while displaying IRPA Graphs : ", e);
				model.addAttribute("irpaErrorMsg", ST03HanaConstant.IRPA_ERROR_MSG);
			}

			return "client/IRPAGraphs";
		}

		// IRPA Estimates
		@RequestMapping(value = "/client/IRPAEstimates/{requestId}", method = RequestMethod.GET)
		public String viewIRPAEstimates(@PathVariable("requestId") long requestID, Model model, HttpSession session) {
			try {
				// Validation
				RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestID));
				RequestID_Validator_Utility.chckReqIdUser(reqIDValid.getCreator(reqIDValid.getRequestInv(requestID)),
						getPrincipal());

				// IRPA - Estimators
				IRPATScopeEstimatesModel estimatorObj = getTestingScopeService().getIRPAEstimatesModel(requestID);
				if (estimatorObj != null)
					model.addAttribute("estimatorObj", estimatorObj);

				model.addAttribute("requestID", requestID);
			} catch (ReqIDNotValidException ex) {
				model.addAttribute("errorMsg", ex.getMessage());
				return "errors";
			} catch (Exception e) {
				logger.error("Error while displaying IRPA Estimates : ", e);
				model.addAttribute("irpaErrorMsg", ST03HanaConstant.IRPA_ERROR_MSG);
			}

			return "client/IRPAEstimates";
		}

		@RequestMapping(value = "/client/saveIRPAEstimates/{requestId}", method = RequestMethod.POST)
		public String saveIRPAEstimates(@PathVariable("requestId") long requestId,
				@Valid @ModelAttribute("estimatorObj") IRPATScopeEstimatesModel estimatorObj, BindingResult result,
				RedirectAttributes redirectAttributes, Model model) {
			try {
				RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestId));
				RequestID_Validator_Utility.chckReqIdUser(reqIDValid.getCreator(reqIDValid.getRequestInv(requestId)),
						getPrincipal());

				if (result.hasErrors()) {
					logger.info("Server Side Validation Fails -- While saving the IRPA Estimates ...");

					return "redirect:/client/viewReportsUpdate/" + requestId;
				}

				getTestingScopeService().saveIRPAEstimates(estimatorObj);

				redirectAttributes.addFlashAttribute("successMsg", "IRPA TScope Estimates saved successfully. Now you can download file.");
			} catch (ReqIDNotValidException ex) {
				model.addAttribute("errorMsg", ex.getMessage());
				return "errors";
			} catch (Exception e) {
				logger.error("Saving IRPA TScope Estimated failed ...", e);
				redirectAttributes.addFlashAttribute("erroMsg", "Saving IRPA TScope Estimated failed ...");
			}

			return "redirect:/client/IRPAEstimates/" + requestId;
		}

	@RequestMapping(value = "/downloadTCodeExcel/{requestID}/{tCode}", method = RequestMethod.GET)
	public synchronized String downloadTestingScopeGraphListFile(@PathVariable("requestID") Long request_ID,
			@PathVariable("tCode") String tCode, Model model, HttpServletResponse response, HttpServletRequest request,
			final RedirectAttributes redirectAttributes) throws Exception {

		String graphTemplete = request.getSession().getServletContext()
				.getRealPath("/staticResources/GraphTemplate/GraphList_Client.xlsx");

		XSSFWorkbook workbook = new XSSFWorkbook(OPCPackage.open(new FileInputStream(graphTemplete)));
		@SuppressWarnings("resource")
		SXSSFWorkbook workbookTemp = new SXSSFWorkbook(workbook);
		workbookTemp.setCompressTempFiles(true);
		XSSFSheet graphTable = workbookTemp.getXSSFWorkbook().getSheetAt(0);

		if (tCode.equalsIgnoreCase("standard")) {
			try {
				List<StandardTcodeTable> standardTcodeList = getStandardTcodeGraphList(request_ID);
				writeStandardTcode(graphTable, standardTcodeList, request_ID);
				final RequestForm requestForm = getRequestDetails().getRequestObj(request_ID);
				ByteArrayOutputStream bos = new ByteArrayOutputStream();
				workbookTemp.write(bos);
				bos.close();
				byte[] bytes = bos.toByteArray();
				getFileDownload().downloadFile(bytes, response,
						HANAUtility.join("_", "StandardTCode", requestForm.getClientName(),
								requestForm.getSourceVersion(), requestForm.getTargetVersion(), request_ID.toString())
								+ ".xlsx");
			} catch (Exception e) {
				logger.error("Error in downloadTestingScopeGraphListFile :: " , e);
				throw new Exception();
			}
		} else if (tCode.equalsIgnoreCase("custom")) {
			List<CustomTcodeTable> customTcodeList = getCustomTcodeGraphList(request_ID);
			writeCustomTcode(graphTable, customTcodeList, request_ID);
			final RequestForm requestForm = getRequestDetails().getRequestObj(request_ID);
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			workbookTemp.write(bos);
			bos.close();
			byte[] bytes = bos.toByteArray();
			getFileDownload().downloadFile(bytes, response,
					HANAUtility.join("_", "CustomTCode", requestForm.getClientName(), requestForm.getSourceVersion(),
							requestForm.getTargetVersion(), request_ID.toString()) + ".xlsx");
		}

		return null;

	}

	private List<StandardTcodeTable> getStandardTcodeGraphList(long requestID) throws Exception {
		Map<String, HashSet<String>> standardTcodes = getGraphDao().getTestingScopeProcessTabWithoutCount(requestID);
		TestingScope testingScopeMaster = new TestingScope();
		List<StandardTcodeTable> stndTcodeGraphList = new ArrayList<StandardTcodeTable>();
		List<TestingScope> testingReqMasterList = getGraphDao().getTestingReqMaster(requestID);
		if (!testingReqMasterList.isEmpty() && testingReqMasterList.size() > 0) {
			testingScopeMaster = testingReqMasterList.get(0);
		}
		LinkedHashMap<String, String> retrieveDescription = reportGraphService.getTestingScopeProcessMaster(requestID,
				testingScopeMaster);
		for (Map.Entry<String, HashSet<String>> stcodeEntry : standardTcodes.entrySet()) {

			for (Map.Entry<String, String> desc : retrieveDescription.entrySet()) {
				if (desc.getKey().contains(stcodeEntry.getKey())) {
					StandardTcodeTable standard = new StandardTcodeTable();
					standard.setDescription(desc.getValue());
					standard.setProcess(stcodeEntry.getKey());
					standard.setStandardtcode(stcodeEntry.getValue());
					stndTcodeGraphList.add(standard);

				}
			}
		}

		logger.info("Size of standard tcode table " + stndTcodeGraphList.size());

		return stndTcodeGraphList;

	}

	private void writeStandardTcode(XSSFSheet graphTable, List<StandardTcodeTable> standardTcodeList, Long requestID) {
		int rowIndex = 0;
		Row stndTcodeRow = graphTable.createRow(rowIndex);
		stndTcodeRow.createCell(0).setCellValue("Description");
		stndTcodeRow.createCell(1).setCellValue("Process");
		stndTcodeRow.createCell(2).setCellValue("Standard TCode");
		rowIndex++;
		for (StandardTcodeTable stndTcode : standardTcodeList) {

			@SuppressWarnings("unchecked")
			HashSet<String> stcodeSet = stndTcode.getStandardtcode();

			for (String stcode : stcodeSet) {
				Row stcodeRow = graphTable.createRow(rowIndex);
				stcodeRow.createCell(0).setCellValue(stndTcode.getDescription());
				stcodeRow.createCell(1).setCellValue(stndTcode.getProcess());
				stcodeRow.createCell(2).setCellValue(stcode);
				rowIndex++;
			}
		}
		logger.info("Sucessfully Wrote Standard Tcodes:::%%%%%%%");
	}

	private List<CustomTcodeTable> getCustomTcodeGraphList(long request_ID) {
		Map<String, String> customTcodes = getGraphDao().getTestingScopeProcessTabWithCount(request_ID);
		List<CustomTcodeTable> customTcodeGraphList = new ArrayList<CustomTcodeTable>();
		for (Map.Entry<String, String> customcodeEntry : customTcodes.entrySet()) {
			CustomTcodeTable custom = new CustomTcodeTable();
			custom.setDescription(customcodeEntry.getValue());
			custom.setCustomtcode(customcodeEntry.getKey());
			customTcodeGraphList.add(custom);
		}

		logger.info("Size of custom tcode table " + customTcodeGraphList.size());

		return customTcodeGraphList;

	}

	private void writeCustomTcode(XSSFSheet graphTable, List<CustomTcodeTable> customTcodeGraphList, Long requestID) {
		int rowIndex = 0;
		Row customTcodeRow = graphTable.createRow(rowIndex);
		customTcodeRow.createCell(0).setCellValue("Custom Tcode");
		customTcodeRow.createCell(1).setCellValue("Description");
		// rowIndex++;
		int rowNum = 1;
		for (CustomTcodeTable customTcode : customTcodeGraphList) {
			Row customtcodeRow = graphTable.createRow(rowNum);
			customtcodeRow.createCell(0).setCellValue(customTcode.getCustomtcode());
			customtcodeRow.createCell(1).setCellValue(customTcode.getDescription());
			rowNum++;

		}
		logger.info("Sucessfully Wrote Custom Tcodes:::%%%%%%%");
	}

	@RequestMapping(value = "/client/downloadExcelHANAGraphs/{requestId}", method = RequestMethod.GET)
	public String downloadExcelGraphs(HttpServletRequest request, @PathVariable("requestId") final long requestId,
			Model model, HttpSession session, RedirectAttributes redirectAttributes, HttpServletResponse response) {

		String message = "";

		try {
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestId));
			RequestID_Validator_Utility.chckReqIdUser(reqIDValid.getCreator(reqIDValid.getRequestInv(requestId)),
					getPrincipal());

			Map<String, ProcessedRequestDetail> reqMasterMap = new HashMap<>();
			List<ProcessedRequestDetail> reqMasterList = getGraphDao().getReqMaster(requestId);

			if (!(reqMasterList.isEmpty()) || reqMasterList.size() > 0) {
				for (ProcessedRequestDetail processedReqDetail : reqMasterList) {
					reqMasterMap.put(processedReqDetail.getScope(), processedReqDetail);
				}
			}

			if (reqMasterMap.containsKey("Hana")) {
				ProcessedRequestDetail processedReq = reqMasterMap.get("Hana");

				graphTemplete = request.getSession().getServletContext()
						.getRealPath("/staticResources/GraphTemplate/GraphsTemplate_HANA.xlsx");

				XSSFWorkbook workbook = new XSSFWorkbook(OPCPackage.open(new FileInputStream(graphTemplete)));

				@SuppressWarnings("resource")
				SXSSFWorkbook workbookTemp = new SXSSFWorkbook(workbook);

				XSSFCellStyle styleCellName = workbook.createCellStyle();
				styleCellName.setFillForegroundColor(IndexedColors.PALE_BLUE.getIndex());
				styleCellName.setFillPattern(CellStyle.SOLID_FOREGROUND);

				XSSFFont fontCellName = workbook.createFont();
				fontCellName.setFontName("ARIAL");
				fontCellName.setFontHeightInPoints((short) 10);
				fontCellName.setBold(true);
				fontCellName.setColor(HSSFColor.BLACK.index);
				styleCellName.setFont(fontCellName);

				XSSFCellStyle styleCellValue = workbook.createCellStyle();

				XSSFFont fontCellValue = workbook.createFont();
				fontCellValue.setFontName("ARIAL");
				fontCellValue.setFontHeightInPoints((short) 8);
				fontCellValue.setColor(HSSFColor.BLACK.index);
				styleCellValue.setFont(fontCellValue);

				downloadGraphSheet0(requestId, processedReq, workbookTemp, styleCellName, styleCellValue);
				downloadGraphSheet1(requestId, processedReq, workbookTemp, styleCellName, styleCellValue);
				downloadGraphSheet2(requestId, processedReq, workbookTemp, styleCellName, styleCellValue);
				downloadGraphSheet3(requestId, processedReq, workbookTemp, styleCellName, styleCellValue);
				downloadGraphSheet4(requestId, processedReq, workbookTemp, styleCellName, styleCellValue);
				downloadGraphSheet5(requestId, processedReq, workbookTemp, styleCellName, styleCellValue);
				downloadGraphSheet6(requestId, processedReq, workbookTemp, styleCellName, styleCellValue);

				String graphFileName = "HANA_Graphs_" + requestId + ".xlsx";

				ByteArrayOutputStream bos = new ByteArrayOutputStream();
				workbook.write(bos);
				bos.close();

				byte[] bytes = bos.toByteArray();
				getFileDownload().downloadFile(bytes, response, graphFileName);
			}

			message = "Graphs Downloaded Sucessfully !!!";
			logger.info(message);
		} catch (ReqIDNotValidException ex) {
			logger.error(ex.getMessage());
			model.addAttribute("errorMsg", ex.getMessage());
			return "errors";
		} catch (Exception e) {
			message = "Error While Downloading Graphs !!!";
			logger.error(message + " " + e.getStackTrace());
		}

		return null;
	}

	public void downloadGraphSheet0(final long requestId, ProcessedRequestDetail processedReq, SXSSFWorkbook workbook,
			XSSFCellStyle style, XSSFCellStyle styleCellValue) throws Exception {

		try {

			XSSFSheet sh = workbook.getXSSFWorkbook().getSheetAt(0);
			String sheetName = sh.getSheetName();

			int totalRows = sh.getLastRowNum();

			// remove values from third row but keep third row blank
			for (int i = 0; i <= totalRows; i++) {

				if (sh.getRow(i) != null)
					sh.removeRow(sh.getRow(i));
			}

			// GRAPH - 1 - Inventory of Custom Objects
			Cell rowLabelCell = sh.createRow(3).createCell(0);
			rowLabelCell.setCellStyle(style);
			rowLabelCell.setCellValue("Row Labels");

			Cell countOfObjCell = sh.getRow(3).createCell(1);
			countOfObjCell.setCellStyle(style);
			countOfObjCell.setCellValue("Count of Objects");

			Cell rowLabelInvCell = null, countOfObjInvCell = null;

			int countInvCustObj = 4;

			Map<String, Integer> custInvObjMap = reportGraphService.getCustomInventoryObjects(requestId, processedReq);

			for (String keyObjName : custInvObjMap.keySet()) {

				Row row = sh.getRow(countInvCustObj);

				if (row == null)
					row = sh.createRow(countInvCustObj);

				rowLabelInvCell = row.getCell(0);
				countOfObjInvCell = row.getCell(1);

				if (rowLabelInvCell == null) {
					rowLabelInvCell = row.createCell(0);
					rowLabelInvCell.setCellValue(keyObjName);
				} else {
					rowLabelInvCell.setCellValue(keyObjName);
				}

				rowLabelInvCell.setCellStyle(styleCellValue);

				if (countOfObjInvCell == null) {
					countOfObjInvCell = row.createCell(1);
					countOfObjInvCell.setCellValue(custInvObjMap.get(keyObjName));
				} else
					countOfObjInvCell.setCellValue(custInvObjMap.get(keyObjName));

				countOfObjInvCell.setCellStyle(styleCellValue);

				++countInvCustObj;
			}

			Name rangeInvCell = workbook.getName("Row_Labels_Inv");
			// Set new range for named range
			String referenceInv = sheetName + "!$A$" + (5) + ":$A$" + (countInvCustObj);
			// Assigns range value to named range
			rangeInvCell.setRefersToFormula(referenceInv);

			rangeInvCell = workbook.getName("Count_of_Objects_Inv");
			referenceInv = sheetName + "!$B$" + (5) + ":$B$" + (countInvCustObj);
			rangeInvCell.setRefersToFormula(referenceInv);

			// Graph - 2 - Impacted ABAP Objects
			Cell rowLabelCell_1 = sh.createRow(32).createCell(0);
			rowLabelCell_1.setCellStyle(style);
			rowLabelCell_1.setCellValue("Row Labels");

			Cell countOfObjCell_2 = sh.getRow(32).createCell(1);
			countOfObjCell_2.setCellStyle(style);
			countOfObjCell_2.setCellValue("Count of Objects");

			Cell rowLabelAbapCell = null, countOfObjAbapCell = null;

			int countAbapCustObj = 33;

			LinkedHashMap<String, Integer> custAbapObjMap = reportGraphService.getImpactedABAPObjects(requestId,
					processedReq);

			for (String keyObjName : custAbapObjMap.keySet()) {

				Row row = sh.getRow(countAbapCustObj);

				if (row == null)
					row = sh.createRow(countAbapCustObj);

				rowLabelAbapCell = row.getCell(0);
				countOfObjAbapCell = row.getCell(1);

				if (rowLabelAbapCell == null) {
					rowLabelAbapCell = row.createCell(0);
					rowLabelAbapCell.setCellValue(keyObjName);

				} else {
					rowLabelAbapCell.setCellValue(keyObjName);
				}

				rowLabelAbapCell.setCellStyle(styleCellValue);

				if (countOfObjAbapCell == null) {
					countOfObjAbapCell = row.createCell(1);
					countOfObjAbapCell.setCellValue(custAbapObjMap.get(keyObjName));
				} else
					countOfObjAbapCell.setCellValue(custAbapObjMap.get(keyObjName));

				countOfObjAbapCell.setCellStyle(styleCellValue);

				++countAbapCustObj;
			}

			Name rangeAbapCell = workbook.getName("Row_Labels_ABAP");
			String referenceAbap = sheetName + "!$A$" + (34) + ":$A$" + (countAbapCustObj);
			rangeAbapCell.setRefersToFormula(referenceAbap);

			rangeAbapCell = workbook.getName("Count_Of_Objects_ABAP");
			referenceAbap = sheetName + "!$B$" + (34) + ":$B$" + (countAbapCustObj);
			rangeAbapCell.setRefersToFormula(referenceAbap);

			// Graph - 3 - Impacted vs Used Objects
			Cell objectTypeCell = sh.createRow(59).createCell(0);
			objectTypeCell.setCellStyle(style);
			objectTypeCell.setCellValue("Object Type");

			Cell invCell = sh.getRow(59).createCell(1);
			invCell.setCellStyle(style);
			invCell.setCellValue("Total Inventory");

			Cell useCell = sh.getRow(59).createCell(2);
			useCell.setCellStyle(style);
			useCell.setCellValue("Total Used");

			Cell impaCell = sh.getRow(59).createCell(3);
			impaCell.setCellStyle(style);
			impaCell.setCellValue("Total Impacted");

			Cell useImpCell = sh.getRow(59).createCell(4);
			useImpCell.setCellStyle(style);
			useImpCell.setCellValue("Total Used Impacted");

			Cell objTypeCell = null, totInvCell = null, totUsedCell = null, totImpCell = null, totUsedImpCell = null;

			int countImpUsed = 60;

			Map<String, List<Integer>> impUsedMap = reportGraphService.getImpactedVSUsedObjects(requestId,
					processedReq);

			for (String keyObjName : impUsedMap.keySet()) {

				ArrayList<Integer> impUsedList = (ArrayList<Integer>) impUsedMap.get(keyObjName);

				Row row = sh.getRow(countImpUsed);

				if (row == null)
					row = sh.createRow(countImpUsed);

				objTypeCell = row.getCell(0);
				totInvCell = row.getCell(1);
				totUsedCell = row.getCell(2);
				totImpCell = row.getCell(3);
				totUsedImpCell = row.getCell(4);

				if (objTypeCell == null) {
					objTypeCell = row.createCell(0);
					objTypeCell.setCellValue(keyObjName);
				} else
					objTypeCell.setCellValue(keyObjName);

				if (totInvCell == null) {
					totInvCell = row.createCell(1);
					totInvCell.setCellValue(impUsedList.get(0));
				} else
					totInvCell.setCellValue(impUsedList.get(0));

				if (totUsedCell == null) {
					totUsedCell = row.createCell(2);
					totUsedCell.setCellValue(impUsedList.get(1));
				} else
					totUsedCell.setCellValue(impUsedList.get(1));

				if (totImpCell == null) {
					totImpCell = row.createCell(3);
					totImpCell.setCellValue(impUsedList.get(2));
				} else
					totImpCell.setCellValue(impUsedList.get(2));

				if (totUsedImpCell == null) {
					totUsedImpCell = row.createCell(4);
					totUsedImpCell.setCellValue(impUsedList.get(3));
				} else
					totUsedImpCell.setCellValue(impUsedList.get(3));

				objTypeCell.setCellStyle(styleCellValue);
				totInvCell.setCellStyle(styleCellValue);
				totUsedCell.setCellStyle(styleCellValue);
				totImpCell.setCellStyle(styleCellValue);
				totUsedImpCell.setCellStyle(styleCellValue);

				++countImpUsed;
			}

			Name rangeImpUsedCell = workbook.getName("Object_Type");
			String referenceImpUsed = sheetName + "!$A$" + (61) + ":$A$" + (countImpUsed);
			rangeImpUsedCell.setRefersToFormula(referenceImpUsed);

			rangeImpUsedCell = workbook.getName("Total_Inventory");
			referenceImpUsed = sheetName + "!$B$" + (61) + ":$B$" + (countImpUsed);
			rangeImpUsedCell.setRefersToFormula(referenceImpUsed);

			rangeImpUsedCell = workbook.getName("Total_Used");
			referenceImpUsed = sheetName + "!$C$" + (61) + ":$C$" + (countImpUsed);
			rangeImpUsedCell.setRefersToFormula(referenceImpUsed);

			rangeImpUsedCell = workbook.getName("Total_Impacted");
			referenceImpUsed = sheetName + "!$D$" + (61) + ":$D$" + (countImpUsed);
			rangeImpUsedCell.setRefersToFormula(referenceImpUsed);

			rangeImpUsedCell = workbook.getName("Total_Used_Impacted");
			referenceImpUsed = sheetName + "!$E$" + (61) + ":$E$" + (countImpUsed);
			rangeImpUsedCell.setRefersToFormula(referenceImpUsed);

		} catch (Exception e) {
			logger.error("Exceptions occurs while downloading graph sheet 0", e.getMessage(), e);
			throw new Exception();
		}
	}

	public void downloadGraphSheet1(final long requestId, ProcessedRequestDetail processedReq, SXSSFWorkbook workbook,
			XSSFCellStyle style, XSSFCellStyle styleCellValue) throws Exception {

		try {

			XSSFSheet sh = workbook.getXSSFWorkbook().getSheetAt(1);
			String sheetName = sh.getSheetName();

			int totalRows = sh.getLastRowNum();

			// remove values from third row but keep third row blank
			for (int i = 0; i <= totalRows; i++) {

				if (sh.getRow(i) != null)
					sh.removeRow(sh.getRow(i));
			}

			// GRAPH -1 - Number of Findings
			Cell findObjSevCell = sh.createRow(1).createCell(0);
			findObjSevCell.setCellStyle(style);
			findObjSevCell.setCellValue("Findings/Objects by Severity");

			Cell numFinfCell = sh.getRow(1).createCell(1);
			numFinfCell.setCellStyle(style);
			numFinfCell.setCellValue("Number of Findings");

			Cell objSevCell = null, numFindingCell = null;

			int countNumFinding = 2;

			LinkedHashMap<String, Integer> numFindingMap = reportGraphService
					.getErrorRemediationCategoryCount(requestId, processedReq);

			for (String keyObjectName : numFindingMap.keySet()) {

				Row row = sh.getRow(countNumFinding);

				if (row == null)
					row = sh.createRow(countNumFinding);

				objSevCell = row.getCell(0);
				numFindingCell = row.getCell(1);

				if (objSevCell == null) {
					objSevCell = row.createCell(0);
					objSevCell.setCellValue(keyObjectName);

				} else {
					objSevCell.setCellValue(keyObjectName);
				}

				if (numFindingCell == null) {
					numFindingCell = row.createCell(1);
					numFindingCell.setCellValue(numFindingMap.get(keyObjectName));
				} else
					numFindingCell.setCellValue(numFindingMap.get(keyObjectName));

				objSevCell.setCellStyle(styleCellValue);
				numFindingCell.setCellStyle(styleCellValue);

				++countNumFinding;
			}

			Name rangeFindingCell = workbook.getName("ObjSev");
			String referenceFinding = sheetName + "!$A$" + (3) + ":$A$" + (countNumFinding);
			rangeFindingCell.setRefersToFormula(referenceFinding);

			rangeFindingCell = workbook.getName("NumFindings");
			referenceFinding = sheetName + "!$B$" + (3) + ":$B$" + (countNumFinding);
			rangeFindingCell.setRefersToFormula(referenceFinding);

			// GRAPH - 2 - Number of Distinct ABAP Objects
			Cell objSevCell_1 = sh.createRow(20).createCell(0);
			objSevCell_1.setCellStyle(style);
			objSevCell_1.setCellValue("Findings/Objects by Severity");

			Cell numAbapCell = sh.getRow(20).createCell(1);
			numAbapCell.setCellStyle(style);
			numAbapCell.setCellValue("Number of ABAP Objects");

			Cell numFindCell = sh.getRow(20).createCell(2);
			numFindCell.setCellStyle(style);
			numFindCell.setCellValue("Number of Findings");

			Cell objSeverityCell = null, numABAPObjCell = null, numABAPFindingCell = null;

			int countNumABAPObj = 21;

			LinkedHashMap<String, Integer> numABAPObjMap = reportGraphService
					.getImpactedRemediationCategoryCount(requestId, processedReq);

			for (String keyObjName : numABAPObjMap.keySet()) {

				Row row = sh.getRow(countNumABAPObj);

				if (row == null)
					row = sh.createRow(countNumABAPObj);

				objSeverityCell = row.getCell(0);
				numABAPObjCell = row.getCell(1);
				numABAPFindingCell = row.getCell(2);

				if (objSeverityCell == null) {
					objSeverityCell = row.createCell(0);
					objSeverityCell.setCellValue(keyObjName);

				} else {
					objSeverityCell.setCellValue(keyObjName);
				}

				if (numABAPObjCell == null) {
					numABAPObjCell = row.createCell(1);
					numABAPObjCell.setCellValue(numABAPObjMap.get(keyObjName));
				} else
					numABAPObjCell.setCellValue(numABAPObjMap.get(keyObjName));

				if (numABAPFindingCell == null) {
					numABAPFindingCell = row.createCell(2);
					numABAPFindingCell.setCellValue(numFindingMap.get(keyObjName));
				} else
					numABAPFindingCell.setCellValue(numFindingMap.get(keyObjName));

				objSeverityCell.setCellStyle(styleCellValue);
				numABAPObjCell.setCellStyle(styleCellValue);
				numABAPFindingCell.setCellStyle(styleCellValue);

				++countNumABAPObj;
			}

			Name rangeAbapCell = workbook.getName("NumABAPObj");
			String referenceAbap = sheetName + "!$B$" + (22) + ":$B$" + (countNumABAPObj);
			rangeAbapCell.setRefersToFormula(referenceAbap);

			// GRAPH - 3 - Line of Code by Remediation & Correction Type
			Cell abapObjCell = sh.createRow(39).createCell(0);
			abapObjCell.setCellStyle(style);
			abapObjCell.setCellValue("ABAP Objects by Remediation Type");

			Cell autoCorr = sh.getRow(39).createCell(1);
			autoCorr.setCellStyle(style);
			autoCorr.setCellValue("Automated Correction");

			Cell manCorr = sh.getRow(39).createCell(2);
			manCorr.setCellStyle(style);
			manCorr.setCellValue("Manual Correction");

			Cell abapObjRemErrCell = null, autoCorrErrCell = null, manCorrErrCell = null;

			int countABAPErrRem = 40;

			LinkedHashMap<String, List<Integer>> abapErrRemMap = reportGraphService
					.getErrorRemediationAndCorrectionTypeCounts(requestId, processedReq);

			for (String keyObjName : abapErrRemMap.keySet()) {

				ArrayList<Integer> abapRemErrList = (ArrayList<Integer>) abapErrRemMap.get(keyObjName);

				Row row = sh.getRow(countABAPErrRem);

				if (row == null)
					row = sh.createRow(countABAPErrRem);

				abapObjRemErrCell = row.getCell(0);
				autoCorrErrCell = row.getCell(1);
				manCorrErrCell = row.getCell(2);

				if (abapObjRemErrCell == null) {
					abapObjRemErrCell = row.createCell(0);
					abapObjRemErrCell.setCellValue(keyObjName);
				} else
					abapObjRemErrCell.setCellValue(keyObjName);

				if (autoCorrErrCell == null) {
					autoCorrErrCell = row.createCell(1);
					autoCorrErrCell.setCellValue(abapRemErrList.get(0));
				} else
					autoCorrErrCell.setCellValue(abapRemErrList.get(0));

				if (manCorrErrCell == null) {
					manCorrErrCell = row.createCell(2);
					manCorrErrCell.setCellValue(abapRemErrList.get(1));
				} else
					manCorrErrCell.setCellValue(abapRemErrList.get(1));

				abapObjRemErrCell.setCellStyle(styleCellValue);
				autoCorrErrCell.setCellStyle(styleCellValue);
				manCorrErrCell.setCellStyle(styleCellValue);

				++countABAPErrRem;

			}

			Name rangeAbapErrRemCell = workbook.getName("AutoCorrErr");
			String referenceErrAbapRem = sheetName + "!$B$" + (41) + ":$B$" + (countABAPErrRem);
			rangeAbapErrRemCell.setRefersToFormula(referenceErrAbapRem);

			rangeAbapErrRemCell = workbook.getName("ManCorrErr");
			referenceErrAbapRem = sheetName + "!$C$" + (41) + ":$C$" + (countABAPErrRem);
			rangeAbapErrRemCell.setRefersToFormula(referenceErrAbapRem);

			// GRAPH - 4 - Line of Code by Remediation & Correction Type
			Cell abapObjRem = sh.createRow(56).createCell(0);
			abapObjRem.setCellStyle(style);
			abapObjRem.setCellValue("ABAP Objects by Remediation Type");

			Cell autoErr = sh.getRow(56).createCell(1);
			autoErr.setCellStyle(style);
			autoErr.setCellValue("Automated Correction");

			Cell manErr = sh.getRow(56).createCell(2);
			manErr.setCellStyle(style);
			manErr.setCellValue("Manual Correction");

			Cell abapObjRemCell = null, autoCorrCell = null, manCorrCell = null;

			int countABAPRem = 57;

			LinkedHashMap<String, List<Integer>> abapRemMap = reportGraphService
					.getRemediationAndCorrectionTypeCounts(requestId, processedReq);

			for (String keyObjName : abapRemMap.keySet()) {

				ArrayList<Integer> abapRemList = (ArrayList<Integer>) abapRemMap.get(keyObjName);

				Row row = sh.getRow(countABAPRem);

				if (row == null)
					row = sh.createRow(countABAPRem);

				abapObjRemCell = row.getCell(0);
				autoCorrCell = row.getCell(1);
				manCorrCell = row.getCell(2);

				if (abapObjRemCell == null) {
					abapObjRemCell = row.createCell(0);
					abapObjRemCell.setCellValue(keyObjName);
				} else
					abapObjRemCell.setCellValue(keyObjName);

				if (autoCorrCell == null) {
					autoCorrCell = row.createCell(1);
					autoCorrCell.setCellValue(abapRemList.get(0));
				} else
					autoCorrCell.setCellValue(abapRemList.get(0));

				if (manCorrCell == null) {
					manCorrCell = row.createCell(2);
					manCorrCell.setCellValue(abapRemList.get(1));
				} else
					manCorrCell.setCellValue(abapRemList.get(1));

				abapObjRemCell.setCellStyle(styleCellValue);
				autoCorrCell.setCellStyle(styleCellValue);
				manCorrCell.setCellStyle(styleCellValue);

				++countABAPRem;
			}

			Name rangeAbapRemCell = workbook.getName("AutoCorr");
			String referenceAbapRem = sheetName + "!$B$" + (58) + ":$B$" + (countABAPRem);
			rangeAbapRemCell.setRefersToFormula(referenceAbapRem);

			rangeAbapRemCell = workbook.getName("ManCorr");
			referenceAbapRem = sheetName + "!$C$" + (58) + ":$C$" + (countABAPRem);
			rangeAbapRemCell.setRefersToFormula(referenceAbapRem);
		} catch (Exception e) {
			logger.error("Exceptions occurs while downloading graph sheet 1", e.getMessage(), e);
			throw new Exception();
		}
	}

	public void downloadGraphSheet2(final long requestId, ProcessedRequestDetail processedReq, SXSSFWorkbook workbook,
			XSSFCellStyle style, XSSFCellStyle styleCellValue) throws Exception {

		try {

			XSSFSheet sh = workbook.getXSSFWorkbook().getSheetAt(2);
			String sheetName = sh.getSheetName();

			int totalRows = sh.getLastRowNum();

			// remove values from third row but keep third row blank
			for (int i = 0; i <= totalRows; i++) {

				if (sh.getRow(i) != null)
					sh.removeRow(sh.getRow(i));
			}

			Cell autoStat = sh.createRow(6).createCell(2);
			autoStat.setCellStyle(style);
			autoStat.setCellValue("Automation Status");

			Cell issSubcat = sh.getRow(6).createCell(3);
			issSubcat.setCellStyle(style);
			issSubcat.setCellValue("Issue Subcategory");

			Cell issCat = sh.getRow(6).createCell(4);
			issCat.setCellStyle(style);
			issCat.setCellValue("Issue Category");

			Cell numAbap = sh.getRow(6).createCell(5);
			numAbap.setCellStyle(style);
			numAbap.setCellValue("Number of ABAP Objects");

			Cell numFind = sh.getRow(6).createCell(6);
			numFind.setCellStyle(style);
			numFind.setCellValue("Number of Findings");

			Cell automationStatusCell = null;
			Cell issueSubcategoryCell = null;
			Cell issueCategoryCell = null;
			Cell NoAbapObjectsCell = null;
			Cell NoFindingsCell = null;

			int countManCorrErrType = 7;

			Map<String, Map<String, Map<String, Map<String, Integer>>>> mandatoryCorrectionsByErrorTypeMap = reportGraphService
					.getManNumCorErrorTypeHana(requestId, processedReq);

			for (String autoStatus : mandatoryCorrectionsByErrorTypeMap.keySet()) {

				Row row = sh.getRow(countManCorrErrType);

				if (row == null)
					row = sh.createRow(countManCorrErrType);

				automationStatusCell = row.getCell(2);

				if (automationStatusCell == null) {
					automationStatusCell = row.createCell(2);
					automationStatusCell.setCellValue(autoStatus);
				} else {
					automationStatusCell.setCellValue(autoStatus);
				}

				automationStatusCell.setCellStyle(styleCellValue);

				Map<String, Map<String, Map<String, Integer>>> issueSubCatMap = mandatoryCorrectionsByErrorTypeMap
						.get(autoStatus);

				for (String issueSubcat : issueSubCatMap.keySet()) {

					row = sh.getRow(countManCorrErrType);

					if (row == null)
						row = sh.createRow(countManCorrErrType);

					issueSubcategoryCell = row.getCell(3);

					if (issueSubcategoryCell == null) {
						issueSubcategoryCell = row.createCell(3);
						issueSubcategoryCell.setCellValue(issueSubcat);
					} else {
						issueSubcategoryCell.setCellValue(issueSubcat);
					}

					issueSubcategoryCell.setCellStyle(styleCellValue);

					Map<String, Map<String, Integer>> issueCatMap = issueSubCatMap.get(issueSubcat);

					for (String issueCat : issueCatMap.keySet()) {

						row = sh.getRow(countManCorrErrType);

						if (row == null)
							row = sh.createRow(countManCorrErrType);

						issueCategoryCell = row.getCell(4);

						if (issueCategoryCell == null) {
							issueCategoryCell = row.createCell(4);
							issueCategoryCell.setCellValue(issueCat);
						} else {
							issueCategoryCell.setCellValue(issueCat);
						}

						issueCategoryCell.setCellStyle(styleCellValue);

						Map<String, Integer> valueABAPMap = issueCatMap.get(issueCat);

						for (String valueABAP : valueABAPMap.keySet()) {

							NoAbapObjectsCell = row.getCell(5);
							NoFindingsCell = row.getCell(6);

							if ("Number of ABAP objects".equalsIgnoreCase(valueABAP)) {

								if (NoAbapObjectsCell == null) {
									NoAbapObjectsCell = row.createCell(5);
									NoAbapObjectsCell.setCellValue(valueABAPMap.get(valueABAP));

								} else {
									NoAbapObjectsCell.setCellValue(valueABAPMap.get(valueABAP));
								}

								NoAbapObjectsCell.setCellStyle(styleCellValue);

							} else if ("Number of findings".equalsIgnoreCase(valueABAP)) {

								if (NoFindingsCell == null) {
									NoFindingsCell = row.createCell(6);
									NoFindingsCell.setCellValue(valueABAPMap.get(valueABAP));
								} else
									NoFindingsCell.setCellValue(valueABAPMap.get(valueABAP));

								NoFindingsCell.setCellStyle(styleCellValue);

							}

						}

						++countManCorrErrType;
					}

					++countManCorrErrType;
				}

			}

			for (int i = 8; i <= sh.getLastRowNum(); i++) {
				if (sh.getRow(i) == null) {
					sh.shiftRows(i + 1, sh.getLastRowNum(), -1);
					i--;
					continue;
				}
			}

			Name rangeManCorrErrTypeCell = workbook.getName("Number_of_ABAP_Objects");
			String referenceManCorrErrType = sheetName + "!$F$" + (8) + ":$F$" + (sh.getLastRowNum() + 1);
			rangeManCorrErrTypeCell.setRefersToFormula(referenceManCorrErrType);

			rangeManCorrErrTypeCell = workbook.getName("Number_of_Findings");
			referenceManCorrErrType = sheetName + "!$G$" + (8) + ":$G$" + (sh.getLastRowNum() + 1);
			rangeManCorrErrTypeCell.setRefersToFormula(referenceManCorrErrType);

			rangeManCorrErrTypeCell = workbook.getName("ManCorrErrType");
			referenceManCorrErrType = sheetName + "!$C$" + (8) + ":$E$" + (sh.getLastRowNum() + 1);
			rangeManCorrErrTypeCell.setRefersToFormula(referenceManCorrErrType);
		} catch (Exception e) {
			logger.error("Exception occurs while downloading graph sheet 0", e.getMessage(), e);
			throw new Exception();
		}
	}

	public void downloadGraphSheet3(final long requestId, ProcessedRequestDetail processedReq, SXSSFWorkbook workbook,
			XSSFCellStyle style, XSSFCellStyle styleCellValue) throws Exception {

		try {

			XSSFSheet sh = workbook.getXSSFWorkbook().getSheetAt(3);
			String sheetName = sh.getSheetName();

			int totalRows = sh.getLastRowNum();

			// remove values from third row but keep third row blank
			for (int i = 0; i <= totalRows; i++) {

				if (sh.getRow(i) != null)
					sh.removeRow(sh.getRow(i));
			}

			Cell autoStat = sh.createRow(4).createCell(2);
			autoStat.setCellStyle(style);
			autoStat.setCellValue("Automation Status");

			Cell issSubcat = sh.getRow(4).createCell(3);
			issSubcat.setCellStyle(style);
			issSubcat.setCellValue("Issue Subcategory");

			Cell oper = sh.getRow(4).createCell(4);
			oper.setCellStyle(style);
			oper.setCellValue("Operation");

			Cell numAbap = sh.getRow(4).createCell(5);
			numAbap.setCellStyle(style);
			numAbap.setCellValue("Number of ABAP Objects");

			Cell numFind = sh.getRow(4).createCell(6);
			numFind.setCellStyle(style);
			numFind.setCellValue("Number of Findings");

			Cell autoStatusCell = null;
			Cell issueSubcatCell = null;
			Cell operCell = null;
			Cell numABAPObjCell = null;
			Cell numFindingsCell = null;

			int countManCorrByIssueErrAuto = 5;

			Map<String, Map<String, Map<String, Map<String, Integer>>>> manCorrBYIssueErrAutoMap = reportGraphService
					.getMandatoryCorrectionsByIssueErrorAutomationHana(requestId, processedReq);

			for (String autoStatus : manCorrBYIssueErrAutoMap.keySet()) {

				Row row = sh.getRow(countManCorrByIssueErrAuto);

				if (row == null)
					row = sh.createRow(countManCorrByIssueErrAuto);

				autoStatusCell = row.getCell(2);

				if (autoStatusCell == null) {
					autoStatusCell = row.createCell(2);
					autoStatusCell.setCellValue(autoStatus);
				} else {
					autoStatusCell.setCellValue(autoStatus);
				}

				autoStatusCell.setCellStyle(styleCellValue);

				Map<String, Map<String, Map<String, Integer>>> issueSubCatMap = manCorrBYIssueErrAutoMap
						.get(autoStatus);

				for (String issueSubcat : issueSubCatMap.keySet()) {

					row = sh.getRow(countManCorrByIssueErrAuto);

					if (row == null)
						row = sh.createRow(countManCorrByIssueErrAuto);

					issueSubcatCell = row.getCell(3);

					if (issueSubcatCell == null) {
						issueSubcatCell = row.createCell(3);
						issueSubcatCell.setCellValue(issueSubcat);
					} else {
						issueSubcatCell.setCellValue(issueSubcat);
					}

					issueSubcatCell.setCellStyle(styleCellValue);

					Map<String, Map<String, Integer>> oprMap = issueSubCatMap.get(issueSubcat);

					for (String opr : oprMap.keySet()) {

						row = sh.getRow(countManCorrByIssueErrAuto);

						if (row == null)
							row = sh.createRow(countManCorrByIssueErrAuto);

						operCell = row.getCell(4);

						if (operCell == null) {
							operCell = row.createCell(4);
							operCell.setCellValue(opr);
						} else {
							operCell.setCellValue(opr);
						}

						operCell.setCellStyle(styleCellValue);

						Map<String, Integer> valueABAPMap = oprMap.get(opr);

						for (String valueABAP : valueABAPMap.keySet()) {

							numABAPObjCell = row.getCell(5);
							numFindingsCell = row.getCell(6);

							if ("Number of ABAP objects".equalsIgnoreCase(valueABAP)) {

								if (numABAPObjCell == null) {
									numABAPObjCell = row.createCell(5);
									numABAPObjCell.setCellValue(valueABAPMap.get(valueABAP));

								} else {
									numABAPObjCell.setCellValue(valueABAPMap.get(valueABAP));
								}

								numABAPObjCell.setCellStyle(styleCellValue);

							} else if ("Number of findings".equalsIgnoreCase(valueABAP)) {

								if (numFindingsCell == null) {
									numFindingsCell = row.createCell(6);
									numFindingsCell.setCellValue(valueABAPMap.get(valueABAP));
								} else
									numFindingsCell.setCellValue(valueABAPMap.get(valueABAP));

								numFindingsCell.setCellStyle(styleCellValue);
							}

						}

						++countManCorrByIssueErrAuto;
					}

					++countManCorrByIssueErrAuto;
				}
			}

			for (int i = 6; i <= sh.getLastRowNum(); ++i) {
				if (sh.getRow(i) == null) {
					sh.shiftRows(i + 1, sh.getLastRowNum(), -1);
					i--;
					continue;
				}
			}

			Name rangeManCorrErrIssueAuto = workbook.getName("NumABAPManCorrErrIssueAuto");
			String refManCorrErrIssueAuto = sheetName + "!$F$" + (6) + ":$F$" + (sh.getLastRowNum() + 1);
			rangeManCorrErrIssueAuto.setRefersToFormula(refManCorrErrIssueAuto);

			rangeManCorrErrIssueAuto = workbook.getName("NumFindingManCorrErrIssueAuto");
			refManCorrErrIssueAuto = sheetName + "!$G$" + (6) + ":$G$" + (sh.getLastRowNum() + 1);
			rangeManCorrErrIssueAuto.setRefersToFormula(refManCorrErrIssueAuto);

			rangeManCorrErrIssueAuto = workbook.getName("ManCorrErrIssueAuto");
			refManCorrErrIssueAuto = sheetName + "!$C$" + (6) + ":$E$" + (sh.getLastRowNum() + 1);
			rangeManCorrErrIssueAuto.setRefersToFormula(refManCorrErrIssueAuto);
		} catch (Exception e) {

			logger.error("Exception occurs while downloading graph sheet 0", e.getMessage(), e);
			throw new Exception();
		}
	}

	public void downloadGraphSheet4(final long requestId, ProcessedRequestDetail processedReq, SXSSFWorkbook workbook,
			XSSFCellStyle style, XSSFCellStyle styleCellValue) throws Exception {

		try {

			XSSFSheet sh = workbook.getXSSFWorkbook().getSheetAt(4);
			String sheetName = sh.getSheetName();

			int totalRows = sh.getLastRowNum();

			// remove values from third row but keep third row blank
			for (int i = 0; i <= totalRows; i++) {

				if (sh.getRow(i) != null)
					sh.removeRow(sh.getRow(i));
			}

			Cell issSubcat = sh.createRow(4).createCell(2);
			issSubcat.setCellStyle(style);
			issSubcat.setCellValue("Issue Subcategory");

			Cell issCat = sh.getRow(4).createCell(3);
			issCat.setCellStyle(style);
			issCat.setCellValue("Issue Category");

			Cell oper = sh.getRow(4).createCell(4);
			oper.setCellStyle(style);
			oper.setCellValue("Operation");

			Cell numAbap = sh.getRow(4).createCell(5);
			numAbap.setCellStyle(style);
			numAbap.setCellValue("Number of ABAP Objects");

			Cell numFind = sh.getRow(4).createCell(6);
			numFind.setCellStyle(style);
			numFind.setCellValue("Number of Findings");

			Cell issueSubcategoryCell = null;
			Cell issueCategoryCell = null;
			Cell oprCell = null;
			Cell NoAbapObjectsCell = null;
			Cell NoFindingsCell = null;

			int countDBLevelOpt = 5;

			Map<String, Map<String, Map<String, Map<String, Integer>>>> dbLevelOptMap = reportGraphService
					.getDBLevelHanaOptimizationCounts(requestId, processedReq);

			for (String issueSubcat : dbLevelOptMap.keySet()) {

				Row row = sh.getRow(countDBLevelOpt);

				if (row == null)
					row = sh.createRow(countDBLevelOpt);

				issueSubcategoryCell = row.getCell(2);

				if (issueSubcategoryCell == null) {
					issueSubcategoryCell = row.createCell(2);
					issueSubcategoryCell.setCellValue(issueSubcat);
				} else {
					issueSubcategoryCell.setCellValue(issueSubcat);
				}

				issueSubcategoryCell.setCellStyle(styleCellValue);

				Map<String, Map<String, Map<String, Integer>>> issueCatMap = dbLevelOptMap.get(issueSubcat);

				for (String issueCat : issueCatMap.keySet()) {

					row = sh.getRow(countDBLevelOpt);

					if (row == null)
						row = sh.createRow(countDBLevelOpt);

					issueCategoryCell = row.getCell(3);

					if (issueCategoryCell == null) {
						issueCategoryCell = row.createCell(3);
						issueCategoryCell.setCellValue(issueCat);
					} else {
						issueCategoryCell.setCellValue(issueCat);
					}

					issueCategoryCell.setCellStyle(styleCellValue);

					Map<String, Map<String, Integer>> oprMap = issueCatMap.get(issueCat);

					for (String opr : oprMap.keySet()) {

						row = sh.getRow(countDBLevelOpt);

						if (row == null)
							row = sh.createRow(countDBLevelOpt);

						oprCell = row.getCell(4);

						if (oprCell == null) {
							oprCell = row.createCell(4);
							oprCell.setCellValue(opr);
						} else {
							oprCell.setCellValue(opr);
						}

						oprCell.setCellStyle(styleCellValue);

						Map<String, Integer> valueABAPMap = oprMap.get(opr);

						for (String valueABAP : valueABAPMap.keySet()) {

							NoAbapObjectsCell = row.getCell(5);
							NoFindingsCell = row.getCell(6);

							if ("Number of ABAP objects".equalsIgnoreCase(valueABAP)) {

								if (NoAbapObjectsCell == null) {
									NoAbapObjectsCell = row.createCell(5);
									NoAbapObjectsCell.setCellValue(valueABAPMap.get(valueABAP));

								} else {
									NoAbapObjectsCell.setCellValue(valueABAPMap.get(valueABAP));
								}

								NoAbapObjectsCell.setCellStyle(styleCellValue);

							} else if ("Number of findings".equalsIgnoreCase(valueABAP)) {

								if (NoFindingsCell == null) {
									NoFindingsCell = row.createCell(6);
									NoFindingsCell.setCellValue(valueABAPMap.get(valueABAP));
								} else
									NoFindingsCell.setCellValue(valueABAPMap.get(valueABAP));

								NoFindingsCell.setCellStyle(styleCellValue);
							}
						}

						++countDBLevelOpt;
					}
				}
			}

			Name rangeDBLevelCell = workbook.getName("DBLevel_NumABAPObj");
			String referenceDBLevel = sheetName + "!$F$" + (6) + ":$F$" + (countDBLevelOpt);
			rangeDBLevelCell.setRefersToFormula(referenceDBLevel);

			rangeDBLevelCell = workbook.getName("DBLevel_NumFindings");
			referenceDBLevel = sheetName + "!$G$" + (6) + ":$G$" + (countDBLevelOpt);
			rangeDBLevelCell.setRefersToFormula(referenceDBLevel);

			rangeDBLevelCell = workbook.getName("DBLevelOpt");
			referenceDBLevel = sheetName + "!$C$" + (6) + ":$E$" + (countDBLevelOpt);
			rangeDBLevelCell.setRefersToFormula(referenceDBLevel);
		} catch (Exception e) {

			logger.error("Exceptions occurs while downloading graph sheet 0", e.getMessage(), e);
			throw new Exception();
		}
	}

	public void downloadGraphSheet5(final long requestId, ProcessedRequestDetail processedReq, SXSSFWorkbook workbook,
			XSSFCellStyle style, XSSFCellStyle styleCellValue) throws Exception {

		try {

			XSSFSheet sh = workbook.getXSSFWorkbook().getSheetAt(5);
			String sheetName = sh.getSheetName();

			int totalRows = sh.getLastRowNum();

			// remove values from third row but keep third row blank
			for (int i = 0; i <= totalRows; i++) {

				if (sh.getRow(i) != null)
					sh.removeRow(sh.getRow(i));
			}

			Cell issSubcat = sh.createRow(4).createCell(2);
			issSubcat.setCellStyle(style);
			issSubcat.setCellValue("Issue Subcategory");

			Cell issCat = sh.getRow(4).createCell(3);
			issCat.setCellStyle(style);
			issCat.setCellValue("Issue Category");

			Cell numAbap = sh.getRow(4).createCell(4);
			numAbap.setCellStyle(style);
			numAbap.setCellValue("Number of ABAP Objects");

			Cell numFind = sh.getRow(4).createCell(5);
			numFind.setCellStyle(style);
			numFind.setCellValue("Number of Findings");

			Cell issueSubcatCell = null;
			Cell issueCatCell = null;
			Cell NoAbapObjectsCell = null;
			Cell NoFindingsCell = null;

			int countAppLevelOpt = 5;

			Map<String, Map<String, Map<String, Integer>>> appLevelOptMap = reportGraphService
					.getApplicationLevelOptimizationCount(requestId, processedReq);

			for (String issueSubcat : appLevelOptMap.keySet()) {

				Row row = sh.getRow(countAppLevelOpt);

				if (row == null)
					row = sh.createRow(countAppLevelOpt);

				issueSubcatCell = row.getCell(2);

				if (issueSubcatCell == null) {
					issueSubcatCell = row.createCell(2);
					issueSubcatCell.setCellValue(issueSubcat);
				} else {
					issueSubcatCell.setCellValue(issueSubcat);
				}

				issueSubcatCell.setCellStyle(styleCellValue);

				Map<String, Map<String, Integer>> issueCatMap = appLevelOptMap.get(issueSubcat);

				for (String issueCat : issueCatMap.keySet()) {

					row = sh.getRow(countAppLevelOpt);

					if (row == null)
						row = sh.createRow(countAppLevelOpt);

					issueCatCell = row.getCell(3);

					if (issueCatCell == null) {
						issueCatCell = row.createCell(3);
						issueCatCell.setCellValue(issueCat);
					} else {
						issueCatCell.setCellValue(issueCat);
					}

					issueCatCell.setCellStyle(styleCellValue);

					Map<String, Integer> valueABAPMap = issueCatMap.get(issueCat);

					for (String valueABAP : valueABAPMap.keySet()) {

						NoAbapObjectsCell = row.getCell(4);
						NoFindingsCell = row.getCell(5);

						if ("Number of ABAP objects".equalsIgnoreCase(valueABAP)) {

							if (NoAbapObjectsCell == null) {
								NoAbapObjectsCell = row.createCell(4);
								NoAbapObjectsCell.setCellValue(valueABAPMap.get(valueABAP));

							} else {
								NoAbapObjectsCell.setCellValue(valueABAPMap.get(valueABAP));
							}

							NoAbapObjectsCell.setCellStyle(styleCellValue);

						} else if ("Number of findings".equalsIgnoreCase(valueABAP)) {

							if (NoFindingsCell == null) {
								NoFindingsCell = row.createCell(5);
								NoFindingsCell.setCellValue(valueABAPMap.get(valueABAP));
							} else
								NoFindingsCell.setCellValue(valueABAPMap.get(valueABAP));

							NoFindingsCell.setCellStyle(styleCellValue);

						}

					}

					++countAppLevelOpt;
				}

				++countAppLevelOpt;
			}

			for (int i = 6; i <= sh.getLastRowNum(); ++i) {
				if (sh.getRow(i) == null) {
					sh.shiftRows(i + 1, sh.getLastRowNum(), -1);
					i--;
					continue;
				}
			}

			Name rangeAppLevelOpt = workbook.getName("AppLevelNumABAP");
			String refAppLevelOpt = sheetName + "!$E$" + (6) + ":$E$" + (sh.getLastRowNum() + 1);
			rangeAppLevelOpt.setRefersToFormula(refAppLevelOpt);

			rangeAppLevelOpt = workbook.getName("AppLevelNumFindings");
			refAppLevelOpt = sheetName + "!$F$" + (6) + ":$F$" + (sh.getLastRowNum() + 1);
			rangeAppLevelOpt.setRefersToFormula(refAppLevelOpt);

			rangeAppLevelOpt = workbook.getName("AppLevelNum");
			refAppLevelOpt = sheetName + "!$C$" + (6) + ":$D$" + (sh.getLastRowNum() + 1);
			rangeAppLevelOpt.setRefersToFormula(refAppLevelOpt);
		} catch (Exception e) {

			logger.error("Exceptions occurs while downloading graph sheet 0", e.getMessage(), e);
			throw new Exception();
		}
	}

	public void downloadGraphSheet6(final long requestId, ProcessedRequestDetail processedReq, SXSSFWorkbook workbook,
			XSSFCellStyle style, XSSFCellStyle styleCellValue) throws Exception {

		try {

			XSSFSheet sh = workbook.getXSSFWorkbook().getSheetAt(6);
			String sheetName = sh.getSheetName();

			int totalRows = sh.getLastRowNum();

			// remove values from third row but keep third row blank
			for (int i = 0; i <= totalRows; i++) {

				if (sh.getRow(i) != null)
					sh.removeRow(sh.getRow(i));
			}

			Cell issSubcat = sh.createRow(4).createCell(2);
			issSubcat.setCellStyle(style);
			issSubcat.setCellValue("Issue Subcategory");

			Cell issCat = sh.getRow(4).createCell(3);
			issCat.setCellStyle(style);
			issCat.setCellValue("Issue Category");

			Cell oper = sh.getRow(4).createCell(4);
			oper.setCellStyle(style);
			oper.setCellValue("Operation");

			Cell numAbap = sh.getRow(4).createCell(5);
			numAbap.setCellStyle(style);
			numAbap.setCellValue("Number of ABAP Objects");

			Cell numFind = sh.getRow(4).createCell(6);
			numFind.setCellStyle(style);
			numFind.setCellValue("Number of Findings");

			Cell issueSubcategoryCell = null;
			Cell issueCategoryCell = null;
			Cell oprCell = null;
			Cell NoAbapObjectsCell = null;
			Cell NoFindingsCell = null;

			int countHousekeepingOpt = 5;

			Map<String, Map<String, Map<String, Map<String, Integer>>>> housekeepOptMap = reportGraphService
					.getHouseKeepingForHANACounts(requestId, processedReq);

			for (String issueSubcat : housekeepOptMap.keySet()) {

				Row row = sh.getRow(countHousekeepingOpt);

				if (row == null)
					row = sh.createRow(countHousekeepingOpt);

				issueSubcategoryCell = row.getCell(2);

				if (issueSubcategoryCell == null) {
					issueSubcategoryCell = row.createCell(2);
					issueSubcategoryCell.setCellValue(issueSubcat);
				} else {
					issueSubcategoryCell.setCellValue(issueSubcat);
				}

				issueSubcategoryCell.setCellStyle(styleCellValue);

				Map<String, Map<String, Map<String, Integer>>> issueCatMap = housekeepOptMap.get(issueSubcat);

				for (String issueCat : issueCatMap.keySet()) {

					row = sh.getRow(countHousekeepingOpt);
					
					if (row == null)
						row = sh.createRow(countHousekeepingOpt);

					issueCategoryCell = row.getCell(3);

					if (issueCategoryCell == null) {
						issueCategoryCell = row.createCell(3);
						issueCategoryCell.setCellValue(issueCat);
					} else {
						issueCategoryCell.setCellValue(issueCat);
					}

					issueCategoryCell.setCellStyle(styleCellValue);

					Map<String, Map<String, Integer>> oprMap = issueCatMap.get(issueCat);

					for (String opr : oprMap.keySet()) {

						row = sh.getRow(countHousekeepingOpt);

						if (row == null)
							row = sh.createRow(countHousekeepingOpt);

						oprCell = row.getCell(4);

						if (oprCell == null) {
							oprCell = row.createCell(4);
							oprCell.setCellValue(opr);
						} else {
							oprCell.setCellValue(opr);
						}

						oprCell.setCellStyle(styleCellValue);

						Map<String, Integer> valueABAPMap = oprMap.get(opr);

						for (String valueABAP : valueABAPMap.keySet()) {

							NoAbapObjectsCell = row.getCell(5);
							NoFindingsCell = row.getCell(6);

							if ("Number of ABAP objects".equalsIgnoreCase(valueABAP)) {

								if (NoAbapObjectsCell == null) {
									NoAbapObjectsCell = row.createCell(5);
									NoAbapObjectsCell.setCellValue(valueABAPMap.get(valueABAP));

								} else {
									NoAbapObjectsCell.setCellValue(valueABAPMap.get(valueABAP));
								}

								NoAbapObjectsCell.setCellStyle(styleCellValue);

							} else if ("Number of findings".equalsIgnoreCase(valueABAP)) {

								if (NoFindingsCell == null) {
									NoFindingsCell = row.createCell(6);
									NoFindingsCell.setCellValue(valueABAPMap.get(valueABAP));
								} else
									NoFindingsCell.setCellValue(valueABAPMap.get(valueABAP));

								NoFindingsCell.setCellStyle(styleCellValue);

							}

						}

						++countHousekeepingOpt;
					}
				}

			}

			Name rangeAppLevelOpt = workbook.getName("HouseKeep_NumABAP");
			String refAppLevelOpt = sheetName + "!$F$" + (6) + ":$F$" + (countHousekeepingOpt);
			rangeAppLevelOpt.setRefersToFormula(refAppLevelOpt);

			rangeAppLevelOpt = workbook.getName("HouseKeep_NumFindings");
			refAppLevelOpt = sheetName + "!$G$" + (6) + ":$G$" + (countHousekeepingOpt);
			rangeAppLevelOpt.setRefersToFormula(refAppLevelOpt);

			rangeAppLevelOpt = workbook.getName("HouseKeep_Num");
			refAppLevelOpt = sheetName + "!$C$" + (6) + ":$E$" + (countHousekeepingOpt);
			rangeAppLevelOpt.setRefersToFormula(refAppLevelOpt);
		} catch (Exception e) {

			logger.error("Exceptions occurs while downloading graph sheet 0", e.getMessage(), e);
			throw new Exception();
		}
	}

	@RequestMapping(value = "/client/downloadSampleDeliverables", method = RequestMethod.GET)
	public String downloadSampleDeliverablesFile(Long requestID, Model model, HttpServletResponse response,
			final RedirectAttributes redirectAttributes, final HttpSession session, final HttpServletRequest request)
			throws Exception {
		String folderName = "SampleDeliverables";
		long requestId = 0;

		String propFileName = "";
		String Enviroment = (String) session.getAttribute("Enviroment");

		if (Enviroment.equals("tools-dev.accenture.com")) {
			propFileName = "Video_Dev.properties";
		} else if (Enviroment.equals("sapcodeanalyzer.myconcerto.accenture.com")) {
			propFileName = "Video_Prd.properties";
		} else if (Enviroment.equals("tools-stage.accenture.com")) {
			propFileName = "Video_Stage.properties";
		} else if (Enviroment.equals("localhost")) {
			propFileName = "Video_Local.properties";
		}
		final String filePath = HANAUtility.getPropertyValue(propFileName, "sdFilePath");
		Path path = Paths.get(filePath);
		// Path fileName = path.getFileName();
		String fileName = "";
		File folder = new File(filePath);
		File[] listOfFiles = folder.listFiles();

		for (File file : listOfFiles) {
			if (file.isFile()) {
				fileName = file.getName();
				logger.info("Sample Deliverable file name ::" + file.getName());
			}
		}
		try {
			byte[] fileBytes = convertFileContentToByteArray(filePath + File.separator + fileName);

			String message = getFileDownload().downloadFile(fileBytes, response, fileName.toString());
			if (null != message) {
				redirectAttributes.addFlashAttribute("fileException",
						"Unable to download the file, Please check if file available or not");
			}

		} catch (IOException e) {
			logger.trace(e.getMessage());
			logger.error("downloadSampleDeliverablesFile :: ", e);
			redirectAttributes.addFlashAttribute("fileException", "Something went wrong while downloading");
			return "redirect:/client/dashboard";
		}

		return "redirect:/client/dashboard";
	}

	public byte[] convertFileContentToByteArray(String filePath) throws IOException {
		File file = new File(filePath);
		byte[] bytesArray = new byte[(int) file.length()];

		FileInputStream fis = new FileInputStream(file);
		fis.read(bytesArray);
		fis.close();

		return bytesArray;
	}

	@RequestMapping(value = "client/uploadTestingScopeFinalReport/{requestId}", method = RequestMethod.POST)
	public String uploadTestingScopeFinalReport(HttpServletRequest request, HttpSession session,
			@PathVariable("requestId") long requestId, RedirectAttributes redirectAttributes,
			@RequestParam("files") MultipartFile file, Model model) {
		String comments = "", finalReportName = "", fileExtension = "";

		try {
			// Validating the client
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestId));
			RequestID_Validator_Utility.chckReqIdUser(reqIDValid.getCreator(reqIDValid.getRequestInv(requestId)),
					getPrincipal());

			finalReportName = file.getOriginalFilename();
			fileExtension = FilenameUtils.getExtension(finalReportName);

			if (StringUtils.isNotBlank(finalReportName)) {
				// Validating file name
				FileUtility.chckUploadFilesAlphaNum(finalReportName);

				// Validating the extension of final report
				if (Hana_Profiler_Constant.XLSM_FILE_EXTENSION.equalsIgnoreCase(fileExtension)) {
					comments = "Matched Extension - Final Report.";
					logger.info(comments);
				} else {
					comments = "Extension of file : Final Report does not match. "
							+ "Please upload the file with .xlsx extension only.";

					throw new UploadFilesNotValidException(comments);
				}
			} else {
				comments = "No file uploaded. Please upload atleast one file.";

				throw new UploadFilesNotValidException(comments);
			}

			// Reading Uploaded Final Report
			getTestingScopeService().readFinalReport(session, file, requestId,
					getRequestDetails().getRequestObj(requestId).getClientName());

			// Calculating Request Master Counts
			getTestingScopeService().updateIRPATScopeRMScenarios(session, requestId);

			// Transferring Data From Intermediate To Download Table
			getTestingScopeService().dataTransferToDownload(requestId, session);
			
			// Updating the status of successful IRPA file upload
			getTestingScopeService().updateIRPAStatus(requestId);
			
			// Saving the defaults in the IRPA Estimator 
			getTestingScopeService().saveIRPAEstimatesDefaults(requestId);
			
			comments = "Testing Scope Report Uploaded Successfully ...";
			logger.info(comments);
			redirectAttributes.addFlashAttribute("successMsg", comments);
		} catch (ReqIDNotValidException e) {
			logger.error("Error while uploading Testing Scope Report : " , e.getMessage());

			model.addAttribute("errorMsg", e.getMessage());
			return "errors";
		} catch (UploadFilesNotValidException e) {
			logger.error("IRPA - Testing Scope Report is not correct : ", e.getMessage());
			
			redirectAttributes.addFlashAttribute("errorMsg", e.getMessage());
		} catch (Exception e) {
			redirectAttributes.addFlashAttribute("errorMsg", "Uploading of Testing Scope Report Failed !!!");
		}

		return "redirect:/client/viewReportsUpdate/" + requestId;
	}

	@RequestMapping(value = "/client/complexityRules", method = RequestMethod.GET)
	public String getComplexityRules(Model model) throws Exception {
		List<ComplexityGraphRules> complexityRules = extensionService.getComplexityGraphRules();
		model.addAttribute("ComplexityRules", complexityRules);
		return "client/complexityRules";

	}

	@RequestMapping(value = "/client/extensibilityRules", method = RequestMethod.GET)
	public String getExtenisibilityRules(Model model) throws Exception {
		List<ExtensibilityGraphRules> extensibilityRules = extensionService.getExtensibilityGraphRules();
		model.addAttribute("ExtensibilityRules", extensibilityRules);
		return "client/extensibilityRules";

	}

	@RequestMapping(value = "/demo/downloadTDSDetailReport", method = RequestMethod.GET)
	public String downloadTDSDetailReportFile(Long requestID, Model model, HttpServletResponse response,
			final RedirectAttributes redirectAttributes, final HttpSession session, final HttpServletRequest request)
			throws Exception {

		String propFileName = "";
		String Enviroment = (String) session.getAttribute("Enviroment");

		if (Enviroment.equals("tools-dev.accenture.com")) {
			propFileName = "Video_Dev.properties";
		} else if (Enviroment.equals("sapcodeanalyzer.myconcerto.accenture.com")) {
			propFileName = "Video_Prd.properties";
		} else if (Enviroment.equals("tools-stage.accenture.com")) {
			propFileName = "Video_Stage.properties";
		} else if (Enviroment.equals("localhost")) {
			propFileName = "Video_Local.properties";
		}
		final String filePath = HANAUtility.getPropertyValue(propFileName, "tdsFilePath");
		String fileName = "";
		File folder = new File(filePath);
		File[] listOfFiles = folder.listFiles();

		for (File file : listOfFiles) {
			if (file.isFile()) {
				fileName = file.getName();
				logger.info("TDS Detail Report file name ::" + file.getName());
			}
		}
		try {
			byte[] fileBytes = convertFileContentToByteArray(filePath + File.separator + fileName);

			String message = getFileDownload().downloadFile(fileBytes, response, fileName.toString());
			if (null != message) {
				redirectAttributes.addFlashAttribute("fileException",
						"Unable to download the file, Please check if file available or not");
			}

		} catch (IOException e) {
			logger.trace(e.getMessage());
			logger.error("downloadTDSDetailReportFile :: ", e);
			redirectAttributes.addFlashAttribute("fileException", "Something went wrong while downloading");
			return "redirect:/client/dashboard";
		}

		return "redirect:/client/dashboard";
	}

	@RequestMapping(value = "/demo/downloadTDSpptx", method = RequestMethod.GET)
	public String downloadTDSpptxFile(Long requestID, Model model, HttpServletResponse response,
			final RedirectAttributes redirectAttributes, final HttpSession session, final HttpServletRequest request)
			throws Exception {

		String propFileName = "";
		String Enviroment = (String) session.getAttribute("Enviroment");

		if (Enviroment.equals("tools-dev.accenture.com")) {
			propFileName = "Video_Dev.properties";
		} else if (Enviroment.equals("sapcodeanalyzer.myconcerto.accenture.com")) {
			propFileName = "Video_Prd.properties";
		} else if (Enviroment.equals("tools-stage.accenture.com")) {
			propFileName = "Video_Stage.properties";
		} else if (Enviroment.equals("localhost")) {
			propFileName = "Video_Local.properties";
		}
		final String filePath = HANAUtility.getPropertyValue(propFileName, "tdsPptxFilePath");
		String fileName = "";
		File folder = new File(filePath);
		File[] listOfFiles = folder.listFiles();

		for (File file : listOfFiles) {
			if (file.isFile()) {
				fileName = file.getName();
				logger.info("TDS pptx file name ::" + file.getName());
			}
		}
		try {
			byte[] fileBytes = convertFileContentToByteArray(filePath + File.separator + fileName);

			String message = getFileDownload().downloadFile(fileBytes, response, fileName.toString());
			if (null != message) {
				redirectAttributes.addFlashAttribute("fileException",
						"Unable to download the file, Please check if file available or not");
			}

		} catch (IOException e) {
			logger.trace(e.getMessage());
			logger.error("downloadTDSpptxFile :: ", e);
			redirectAttributes.addFlashAttribute("fileException", "Something went wrong while downloading");
			return "redirect:/client/dashboard";
		}

		return "redirect:/client/dashboard";
	}

	@RequestMapping(value = "/client/EXTGraphs/{requestId}", method = RequestMethod.GET)
	public String viewExtGraphs(@PathVariable("requestId") long requestID, Model model, HttpSession session) {
		try {
			
			ExtensionScope extensionScope = new ExtensionScope();
			List<ExtensionScope> extensionScopeList = getGraphDao().getExtensionScopeMaster(requestID);
			if (!extensionScopeList.isEmpty() && extensionScopeList.size() > 0) {
				extensionScope = extensionScopeList.get(0);
			}
			
			RequestForm requestForm = getRequestDetails().getRequestObj(requestID);
			String targetSystem = requestForm.getTargetVersion();
			
			model.addAttribute("totalObjects",
					reportGraphService.getExtensionScopeMaster(requestID, extensionScope.getTotalObjsCount()));
			model.addAttribute("RicefObjectCount",
					reportGraphService.getExtensionScopeMaster(requestID, extensionScope.getTotalRicefCount()));
			model.addAttribute("OthersObjectCount",
					reportGraphService.getExtensionScopeMaster(requestID, extensionScope.getOthersRicefCount()));
			model.addAttribute("ComplexityCount", reportGraphService.getExtensionScopeMaster(requestID,
					extensionScope.getTotalComplexityCount()));

			model.addAttribute("extensionCount",
					reportGraphService.getExtensionScopeMaster(requestID, extensionScope.getTotalExtensionCount()));

			model.addAttribute("formsExtensionCount",
					reportGraphService.getExtensionScopeMaster(requestID, extensionScope.getForms_Extension()));
			model.addAttribute("interfaceExtensionCount",
					reportGraphService.getExtensionScopeMaster(requestID, extensionScope.getInterface_Extension()));
			model.addAttribute("workflowExtensionCount",
					reportGraphService.getExtensionScopeMaster(requestID, extensionScope.getWorkflow_Extension()));
			model.addAttribute("enhancementExtensionCount", reportGraphService.getExtensionScopeMaster(requestID,
					extensionScope.getEnhancement_Extension()));
			model.addAttribute("conversionExtensionCount", reportGraphService.getExtensionScopeMaster(requestID,
					extensionScope.getConversion_Extension()));
			model.addAttribute("reportsExtensionCount",
					reportGraphService.getExtensionScopeMaster(requestID, extensionScope.getReports_Extension()));

			model.addAttribute("reportsComplexityCount",
					reportGraphService.getExtensionScopeMaster(requestID, extensionScope.getReports_Complexity()));
			model.addAttribute("formsComplexityCount",
					reportGraphService.getExtensionScopeMaster(requestID, extensionScope.getForms_Complexity()));
			model.addAttribute("interfaceComplexityCount", reportGraphService.getExtensionScopeMaster(requestID,
					extensionScope.getInterface_Complexity()));
			model.addAttribute("enhancementComplexityCount", reportGraphService.getExtensionScopeMaster(requestID,
					extensionScope.getEnhancement_Complexity()));
			model.addAttribute("conversionComplexityCount", reportGraphService.getExtensionScopeMaster(requestID,
					extensionScope.getConversion_Complexity()));
			model.addAttribute("workflowComplexityCount",
					reportGraphService.getExtensionScopeMaster(requestID, extensionScope.getWorkflow_Complexity()));
			model.addAttribute("stackedComplexityCount", reportGraphService.getExtensionScopeMasterStack(requestID,
					extensionScope.getStackedComplexityCount()));
			model.addAttribute("stackedExtensionCount", reportGraphService.getExtensionScopeMasterStack(requestID,
					extensionScope.getStackedExtensionCount()));
			model.addAttribute("targetSystem", targetSystem);

			model.addAttribute("requestID", requestID);
		} catch (ReqIDNotValidException ex) {
			model.addAttribute("errorMsg", ex.getMessage());
			return "errors";
		} catch (Exception e) {
			logger.error("Error while displaying Extensibility Graphs : ", e);
		}

		return "client/EXTGraphs";
	}
	
	/**Merge from sub request branch */
	
	@RequestMapping(value = "/client/loadMainRequestScope/{requestId}", method = RequestMethod.GET)
	public void loadMainRequestScope(@PathVariable("requestId") final Long requestId,Model model, HttpSession session,
			HttpServletResponse response, HttpServletRequest request) throws IOException {
		try {
		JSONObject result = new JSONObject();
		PrintWriter out = response.getWriter();
		RequestForm requestForm = getRequestDetails().getRequestFormScopes(requestId);
		boolean scopeHana=false, scopeS4=false, scopeFIAT=false, scopeUI5=false,scopeFiori=false,scopeAUCT=false,scopeRFP=false,scopeOSMigration=false,scopeEXT = false, scopeBWTech = false, scopeBWUsage = false;
		if(null != requestForm.getSOH())
		 scopeHana = requestForm.getSOH();
		if(null != requestForm.getS4Technical())
		 scopeS4 = requestForm.getS4Technical();
		if(null != requestForm.getS4Functional())
		 scopeFIAT = requestForm.getS4Functional();
		if(null != requestForm.getUI5())
		 scopeUI5 = requestForm.getUI5();
		if(null != requestForm.getFiori())
		 scopeFiori = requestForm.getFiori();
		if(null != requestForm.getUPGRADE())
		 scopeAUCT = requestForm.getUPGRADE();
		if(null != requestForm.getRFP()) {
		 scopeRFP = requestForm.getRFP();
		}
		if(null != requestForm.getBwTech()) {
			 scopeBWTech = requestForm.getBwTech();
			}
		if(null != requestForm.getBwUsage()) {
			 scopeBWUsage = requestForm.getBwUsage();
			}
		 scopeOSMigration = requestForm.getOsMig();
		if(null != requestForm.getEXT())
		 scopeEXT = requestForm.getEXT();
		
		Map<String, String> scopeMap = new HashMap<>();
		
		if (scopeHana) {
			scopeMap.put("SOH", "SOH");
		}
		if (scopeS4) {
			scopeMap.put("S4Technical", "S4Technical");
		}
		if (scopeFIAT) {
			scopeMap.put("S4Functional", "S4Functional");
		}
		if (scopeUI5) {
			scopeMap.put("UI5", "UI5");
		}
		if (scopeFiori) {
			scopeMap.put("Fiori", "Fiori");
		}
		if (scopeAUCT) {
			scopeMap.put("Upgrade", "Upgrade");
		}
		if (scopeRFP) {
			scopeMap.put("RFP", "RFP");
		}
		if (scopeOSMigration) {
			scopeMap.put("osMigration", "osMigration");
		}
		if (scopeEXT) {
			scopeMap.put("EXT", "EXT");
		}
		if (requestForm.getSia()) {
			scopeMap.put("SIA", "SIA");
		}
		if (scopeBWTech) {
			scopeMap.put("bwTech", "bwTech");
		}
		if (scopeBWUsage) {
			scopeMap.put("bwUsage", "bwUsage");
		}
		
		List<RequestForm> subScpList = getRequestDetails().getSubRequestScopes(requestId, session);
		for (RequestForm scpSub : subScpList) {
			String soh = "";
			String s4tech = "";
			String S4Func = "";
			String ui5 = "";
			String fiori = "";
			String upgrade = "";
			String rfp = "";
			String osMig = "";
			String ext = "";
			String sia = "";
			String bwTech = "";
			String bwUsage = "";
			
			if (scpSub.getSOH()) {
				soh = "SOH";
			}
			if (scpSub.getS4Technical()) {
				s4tech = "S4Technical";
			}
			if (scpSub.getS4Functional()) {
				S4Func="S4Functional";
			}
			if (scpSub.getUI5()) {
				ui5="UI5";
			}
			if (scpSub.getFiori()) {
				fiori="Fiori";
			}
			if (scpSub.getUPGRADE()) {
				upgrade="Upgrade";
			}
			if (scpSub.getRFP()) {
				rfp="RFP";
			}
			if (scpSub.getOsMig()) {
				osMig="osMigration";
			}
			if (scpSub.getEXT()) {
				ext="EXT";
			}
			if (scpSub.getSia()) {
				sia="SIA";
			}
			if (scpSub.getBwTech()) {
				bwTech="bwTech";
			}
			if (scpSub.getBwUsage()) {
				bwUsage="bwUsage";
			}
			if(scopeMap.containsKey(soh)) {
				scopeMap.put(soh, "Done");
			}
			if(scopeMap.containsKey(s4tech)) {
				scopeMap.put(s4tech, "Done");
			}
			if(scopeMap.containsKey(S4Func)) {
				scopeMap.put(S4Func, "Done");
			}
			if(scopeMap.containsKey(ui5)) {
				scopeMap.put(ui5, "Done");
			}
			if(scopeMap.containsKey(fiori)) {
				scopeMap.put(fiori, "Done");
			}
			if(scopeMap.containsKey(upgrade)) {
				scopeMap.put(upgrade, "Done");
			}
			if(scopeMap.containsKey(rfp)) {
				scopeMap.put(rfp, "Done");
			}
			if(scopeMap.containsKey(osMig)) {
				scopeMap.put(osMig, "Done");
			}
			if(scopeMap.containsKey(ext)) {
				scopeMap.put(ext, "Done");
			}
			if(scopeMap.containsKey(sia)) {
				scopeMap.put(sia, "Done");
			}
			if(scopeMap.containsKey(bwTech)) {
				scopeMap.put(bwTech, "Done");
			}
			if(scopeMap.containsKey(bwUsage)) {
				scopeMap.put(bwUsage, "Done");
			}
		}
		
		RequestInventory requestInventory = getClientRequestInventoryDAO()
				.getRequestInventory(requestId);
		result.put("clientName", requestForm.getClientName());
		if(null != requestInventory && null != requestInventory.getCreatedDate()){
		result.put("createdDate", requestInventory.getCreatedDate());
		}
		result.put("getScopeList", scopeMap);
		
		out.write(result.toJSONString());
		}catch (Exception e) {
			logger.error("loadMainRequestScope :: ",e);
		}
	}
	
	@RequestMapping(value = "/client/subRequest/{mainRequestId}", method = RequestMethod.POST)
	public String SubmitSubRequest( @PathVariable("mainRequestId")  Long requestId, HttpSession session, HttpServletRequest request, final RedirectAttributes redirectAttributes) {
		
		String toolName = (String) session.getAttribute("tool");
		String reqIdUI = (request.getParameter("requestID"));
		String scopes = (request.getParameter("scopes"));
		logger.info("scope from UI : "+scopes);
		String[] scopeArr = null;
		ArrayList<String> ScopeList = new ArrayList<>();;
		if(StringUtils.isNotBlank(scopes)) {
			scopeArr = scopes.split(",");
			ScopeList = new ArrayList<>(Arrays.asList(scopeArr));
		
		logger.info("scopeList : "+ScopeList);
		  RequestForm requestForm = getRequestDetails().getRequestFormData(requestId);
		  RequestForm SubRequestForm = prepareRequestFormForSubRequest(requestForm,ScopeList); 
		  SubRequestForm.setToolName(toolName);
		 
			final String userName = getPrincipal();
			String requestIdUi = requestIdUIGeneratorForSubRequest(SubRequestForm);
			SubRequestForm.setREQUEST_ID_UI(requestIdUi);
			getRequestDetails().saveSubRequestForm(SubRequestForm, userName, toolName, requestId,reqIdUI);
			getPocRequestMappingdao().addClientData(SubRequestForm.getRequestID(), userName, requestIdUi, toolName);
		}else{
			redirectAttributes.addFlashAttribute("fileException", "Please Select at least one scope");
		}
		
		return "redirect:/client/dashboard";

	}
	
	private RequestForm prepareRequestFormForSubRequest(RequestForm rfm,ArrayList<String> scpList) {
		boolean SOH = false, S4Functional = false, UPGRADE = false, S4Technical = false, Fiori = false, UI5 = false,
				RFP = false, SIA = false, BW = false, OSMIG = false, GRC = false;
		;
		boolean EXT = false;
		RequestForm rf = new RequestForm();

		rf.setClientName(rfm.getClientName());
		rf.setClientTeamDetails(rfm.getClientTeamDetails());
		rf.setClienttype(rfm.getClienttype());
		rf.setCurrencyType(rfm.getCurrencyType());
		rf.setCustomerNamespace(rfm.getCustomerNamespace());
		rf.setDatabaseDB(rfm.getDatabaseDB());
		rf.setDbSize(rfm.getDbSize());
		rf.setDealSize(rfm.getDealSize());
		if (rfm.getWBSE().equalsIgnoreCase("REQUESTED"))
			rf.setWbsCode("WBSE REQUESTED");
		else
			rf.setWbsCode(rfm.getWbsCode());
		rf.setSystemEnvt(rfm.getSystemEnvt());
		rf.setSystemId(rfm.getSystemId());
		rf.setSourceVersion(rfm.getSourceVersion());
		rf.setIndustryGroup(rfm.getIndustryGroup());
		rf.setIndustrySubGroup(rfm.getIndustrySubGroup());
		rf.setInstalNo(rfm.getInstalNo());
		rf.setAppServer(rfm.getAppServer());
		rf.setSupportedAtci(rfm.getSupportedAtci());
		rf.setNumberOfUsers(rfm.getNumberOfUsers());
		rf.setNumberOtherSystem(rfm.getNumberOtherSystem());
		rf.setNumberProduction(rfm.getNumberProduction());
		rf.setNumberQuality(rfm.getNumberQuality());
		rf.setNumberDevelopment(rfm.getNumberDevelopment());
		rf.setSandbox(rfm.getSandbox());
		rf.setPocName(rfm.getPocName());
		rf.setProjectName(rfm.getProjectName());
		rf.setProjectPocId(rfm.getProjectPocId());
		rf.setHost(rfm.getHost());
		rf.setEndDate(rfm.getEndDate());
		rf.setStartDate(rfm.getStartDate());
		rf.setUnicodeCompliant(rfm.getUnicodeCompliant());
		rf.setSap_NonSAPcomponents(rfm.getSap_NonSAPcomponents());
		rf.setSapClientId(rfm.getSapClientId());
		rf.setSystemType(rfm.getSystemType());
		rf.setTargetVersion(rfm.getTargetVersion());
		rf.setCVIT(false);
		rf.setWBSE(rfm.getWBSE());
		rf.setSrcOSVer(rfm.getSrcOSVer());
		rf.setTarOSVer(rfm.getTarOSVer());
		rf.setExternalNamespace(rfm.getExternalNamespace());

		if (rfm.getUnicodeCompliant().equalsIgnoreCase("YES"))
			rf.setEnableUnicode("No");
		else
			rf.setEnableUnicode("Yes");

		rf.setScope(scpList);

		if (scpList.contains("SOH")){
			SOH = true;
		logger.info("SOH found");
		}
		if (scpList.contains("S4Functional")){
			S4Functional = true;
		logger.info("S4Functional found");
		}
		if (scpList.contains("Upgrade")){
			UPGRADE = true;
		logger.info("Upgrade found");
		}
		if (scpList.contains("S4Technical")){
			S4Technical = true;
			logger.info("S4Technical found");
		}
		if (scpList.contains("Fiori")){
			Fiori = true;
			logger.info("Fiori found");
		}
		if (scpList.contains("UI5")){
			UI5 = true;
			logger.info("UI5 found");
		}
		if (scpList.contains("RFP")){
			RFP = true;
			logger.info("RFP found");
		}
		if (scpList.contains("SIA")){
			SIA = true;
			logger.info("SIA found");
		}
		if (scpList.contains("osMigration")){
			OSMIG = true;
			logger.info("osMigration found");
		}
		if (scpList.contains("BW")){
			BW = true;
			logger.info("BW found");
		}
		if (scpList.contains("GRC")){
			GRC = true;
			logger.info("GRC found");
		}
		if (scpList.contains("EXT")){
			EXT = true;
			logger.info("EXT found");
		}
		rf.setSOH(SOH);
		rf.setS4Functional(S4Functional);
		rf.setS4Technical(S4Technical);
		rf.setUPGRADE(UPGRADE);
		rf.setFiori(Fiori);
		rf.setUI5(UI5);
		rf.setRFP(RFP);
		rf.setSia(SIA);
		rf.setOsMig(OSMIG);
		rf.setGrc(GRC);
		rf.setBwTech(scpList.contains("bwTech"));
		rf.setBwUsage(scpList.contains("bwUsage"));
		rf.setEXT(EXT);

		if (S4Technical) {
			rf.setAle(rfm.getAle());
			rf.setFle(rfm.getFle());
		}
		if (SIA) {
			if (rfm.getTargetVersion().startsWith("S/4HANA"))
				// SIA
				rf.setSecVer(rfm.getTargetVersion().split("S/4HANA")[1]);
			else
				rf.setSecVer("");
		}

		if (RFP) {
			rf.setValueRFP(rfm.getValueRFP());
		} else {
			rf.setValueRFP("NA");
		}

		if (Fiori) {
			rf.setCentral_embedded(rfm.getCentral_embedded());
			rf.setCentral_gateSystem(rfm.getCentral_gateSystem());
		} else {
			rf.setCentral_embedded("NA");
			rf.setCentral_gateSystem("NA");
		}

		if (UI5) {
			rf.setRfc(rfm.getRfc());
			rf.setAppName(rfm.getAppName());
			rf.setOldVersion(rfm.getOldVersion());
			rf.setNewVersion(rfm.getNewVersion());
		} else {
			rf.setRfc("NA");
			rf.setAppName("NA");
			rf.setOldVersion("NA");
			rf.setNewVersion("NA");
		}

		if (S4Functional) {
			rf.setSapInterface(rfm.getSapInterface());
			rf.setNon_sapInterface(rfm.getNon_sapInterface());
			rf.setSapModules(rfm.getSapModules());
			rf.setIndSolution(rfm.getIndSolution());
			rf.setSupportComponents(rfm.getSupportComponents());
			rf.setFioriSetup_apps(rfm.getFioriSetup_apps());
			rf.setSandbox_ID_instalNo(rfm.getSandbox_ID_instalNo());
			rf.setSandbox_sysId(rfm.getSandbox_sysId());
		} else {
			rf.setSapInterface("NA");
			rf.setNon_sapInterface("NA");
			rf.setSapModules("NA");
			rf.setIndSolution("NA");
			rf.setFioriSetup_apps("NA");
			rf.setSupportComponents("NA");
			rf.setSandbox_ID_instalNo("NA");
			rf.setSandbox_sysId("NA");
		}
		if (EXT) {
			rf.setLicenseSelect(rfm.getLicenseSelect());
			rf.setServiceProvider(rfm.getServiceProvider());
		} else {
			rf.setLicenseSelect("NA");
			rf.setServiceProvider("NA");
		}

		return rf;
	}
}