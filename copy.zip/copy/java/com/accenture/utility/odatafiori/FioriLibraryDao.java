package com.accenture.utility.odatafiori;

import java.sql.SQLException;
import java.util.List;

public interface FioriLibraryDao {
	
	public void  insertFioriRecords(List<AppListResultEntity> listOfAppsType, String environment) throws SQLException;

	public void truncateMasterSheetTables(String environment) throws SQLException;
	
	public void truncateMasterSheetBackupTables(String environment) throws SQLException;
	
	public void updateMasterSheetBackupTables(String environment) throws SQLException;
	
	public void upadateProcessOnSucess(String environment) throws SQLException;

}
