package com.accenture.utility.odatafiori;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties({"__count"})
public class AppResult {
	
	/*@JsonProperty("__count")
	private String count;*/
	
	@JsonProperty("results")
	private List<AppListResult> results;

	/*public String getCount() {
		return count;
	}

	public void setCount(String count) {
		this.count = count;
	}*/

	public List<AppListResult> getResults() {
		return results;
	}

	public void setResults(List<AppListResult> results) {
		this.results = results;
	}
	
	
}
