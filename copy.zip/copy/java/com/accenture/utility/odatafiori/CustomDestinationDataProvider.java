package com.accenture.utility.odatafiori;


import java.util.Hashtable;
import java.util.Properties;

import com.sap.conn.jco.ext.DestinationDataEventListener;

import com.sap.conn.jco.ext.DestinationDataProvider;

public class CustomDestinationDataProvider implements DestinationDataProvider {
	
	private static CustomDestinationDataProvider myDestinationDataProvider = null;
	
	private Hashtable<String, Properties> propertiesTab = new Hashtable<String, Properties>();
	private DestinationDataEventListener eL;
	
	private CustomDestinationDataProvider() {
	}
	
	public static CustomDestinationDataProvider getInstance() {
	    if (myDestinationDataProvider == null) {
	        myDestinationDataProvider = new CustomDestinationDataProvider();
	    }
	    return myDestinationDataProvider;
	}


	public Properties getDestinationProperties(String destinationName) {
		if (propertiesTab.containsKey(destinationName)) {
			return propertiesTab.get(destinationName);
		}

		return null;
	}

	public void setDestinationDataEventListener(DestinationDataEventListener eventListener) {
		this.eL = eventListener;
	}

	public void changePropertiesForABAP_AS(Properties pConProps) {
		
		propertiesTab.put(pConProps.getProperty("jco.client.dest"), pConProps);
		

	}

	public boolean supportsEvents() {
		return false;
	}

}
