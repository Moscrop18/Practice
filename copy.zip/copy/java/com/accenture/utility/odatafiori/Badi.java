package com.accenture.utility.odatafiori;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name="Badi_MasterData")

public class Badi {
	

	@Id	
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "AutoId")
	private Integer autoId;
	
	@Column(name = "Id",columnDefinition="LONGTEXT")
	private String id;
	
	@Column(name = "ProductInstanceBE", columnDefinition="TEXT")
	private String productInstanceBE  ;
	
	@Column(name = "ReleaseGroupText")
	private String releaseGroupText  ;
	
	@Column(name = "AppId" ,columnDefinition="varchar(500)" )
	@Index(name="INDEX_OBJ_NAME")
	private String appId  ;
	
	@Column(name = "ReleaseId" ,columnDefinition="varchar(255)" )
	private String  releaseId ;
	
	@Column(name = "ReleaseName" ,columnDefinition="varchar(255)")
	private String  releaseName ;
	
	@Column(name = "OtherReleases" , columnDefinition="TEXT" )
	private String  otherReleases ;
	
	@Column(name = "AppNameAll" , columnDefinition="TEXT" )
	private String  appNameAll ;
	
	@Column(name = "RoleNameCombined" , columnDefinition="TEXT" )
	private String  roleNameCombined ;
	
	@Column(name = "SolutionsCapabilityCombined" , columnDefinition="TEXT" )
	private String  solutionsCapabilityCombined ;
	
	@Column(name = "SolutionsCapabilityIDCombined" , columnDefinition="TEXT" )
	private String   solutionsCapabilityIDCombined;
	
	@Column(name = "TitleCombined" , columnDefinition="TEXT" )
	private String  titleCombined ;
	
	@Column(name = "AvailabilityInFaaSCombined" , columnDefinition="TEXT" )
	private String  availabilityInFaaSCombined ;
	
	@Column(name = "LobCombined" , columnDefinition="TEXT" )
	private String  lobCombined ;
	
	@Column(name = "IndustryCombined" , columnDefinition="TEXT" )
	private String  industryCombined ;
	
	@Column(name = "PCDCombined" , columnDefinition="TEXT" )
	private String   pcdCombined;
	
	@Column(name = "ACHCombined" , columnDefinition="TEXT" )
	private String   achCombined ;
	
	@Column(name = "ACHLevel2Combined" , columnDefinition="TEXT" )
	private String   achLevel2Combined;
	
	@Column(name = "DatabaseCombined" , columnDefinition="TEXT" )
	private String   databaseCombined;
	
	@Column(name = "PrimaryPVOfficialNameCombined" , columnDefinition="TEXT" )
	private String   primaryPVOfficialNameCombined;
	
	@Column(name = "PVFrontendCombined" , columnDefinition="TEXT" )
	private String  pvFrontendCombined ;
	
	@Column(name = "PVBackendCombined" , columnDefinition="TEXT" )
	private String   pvBackendCombined;
	
	@Column(name = "AppTypeCombined" , columnDefinition="TEXT" )
	private String  	appTypeCombined ;
	
	@Column(name = "TechnicalCatalogNameCombined" , columnDefinition="TEXT" )
	private String  technicalCatalogNameCombined ;
	
	@Column(name = "BusinessCatalogNameCombined" , columnDefinition="LONGTEXT" )
	private String  businessCatalogNameCombined ;
	
	@Column(name = "FrontendSCVCombined" ,  columnDefinition="TEXT" )
	private String   frontendSCVCombined;
	
	@Column(name = "HANASCVCombined" ,  columnDefinition="TEXT" )
	private String  hanaSCVCombined ;
	
	@Column(name = "BackendSCVCombined" ,  columnDefinition="TEXT" )
	private String  backendSCVCombined ;
	
	@Column(name = "ReleaseGroupTextCombined" ,  columnDefinition="TEXT" )
	private String  releaseGroupTextCombined ;
	
	@Column(name = "PortfolioCategoryCombined" ,  columnDefinition="TEXT" )
	private String  portfolioCategoryCombined ;
	
	@Column(name = "ProductCategoryDetails" ,  columnDefinition="TEXT" )
	private String  productCategoryDetails ;
	
	@Column(name = "RoleDescription" ,  columnDefinition="TEXT" )
	private String  roleDescription ;
	
	@Column(name = "BusinessCatalog" ,  columnDefinition="TEXT" )
	private String  businessCatalog ;
	
	@Column(name = "TechnicalCatalog" , columnDefinition="varchar(500)" )
	private String  technicalCatalog ;
	
	@Column(name = "FitAnalysisACH"  )
	private String  fitAnalysisACH ;
	
	@Column(name = "PVBackend" ,  columnDefinition="TEXT" )
	private String  pvBackend ;
	
	@Column(name = "PVFrontend" ,  columnDefinition="TEXT" )
	private String   pvFrontend;
	
	@Column(name = "AppTypeLevel" )
	private String  appTypeLevel ;
	
	@Column(name = "ProductInstanceHANA" ,  columnDefinition="TEXT" )
	private String  productInstanceHANA ;
	
	@Column(name = "ApplicationComponentText" ,columnDefinition="TEXT" )
	private String  applicationComponentText ;
	
	@Column(name = "FormFactors" ,  columnDefinition="TEXT" )
	private String  formFactors ;
	
	@Column(name = "PortfolioCategoryIV" ,  columnDefinition="TEXT" )
	private String  portfolioCategoryIV ;
	
	@Column(name = "PortfolioCategoryImp" ,  columnDefinition="TEXT" )
	private String  portfolioCategoryImp ;
	
	@Column(name = "AppName" ,  columnDefinition="TEXT" )
	private String  appName ;
	
	@Column(name = "ApplicationType" , columnDefinition="varchar(500)" )
	private String  applicationType ;
	
	@Column(name = "BSPName" )
	private String  bspName ;
	
	@Column(name = "BSPApplicationURL" ,columnDefinition="varchar(500)")
	private String  bspApplicationURL ;
	
	@Column(name = "NewRoleName" ,columnDefinition="varchar(500)" )
	private String  newRoleName ;
	
	@Column(name = "RoleName" , columnDefinition="varchar(500)" )
	private String  roleName ;
	
	@Column(name = "GTMLoBName" , columnDefinition="varchar(500)")
	private String   gtmLoBName;
	
	@Column(name = "ProductCategory" , columnDefinition="varchar(500)" )
	private String  productCategory ;
	
	@Column(name = "ApplicationComponent" ,columnDefinition="varchar(500)")
	private String  applicationComponent ;
	
	@Column(name = "DatabaseName" , columnDefinition="varchar(500)")
	private String  database ;
	
	@Column(name = "BackendSoftwareComponentVersions"  ,columnDefinition="varchar(500)")
	private String  backendSoftwareComponentVersions ;
	
	@Column(name = "FrontendSoftwareComponent"  ,columnDefinition="varchar(500)")
	private String  frontendSoftwareComponent ;
	
	@Column(name = "HANASoftwareComponentVersions" ,columnDefinition="varchar(500)" )
	private String  hanaSoftwareComponentVersions ;
	
	@Column(name = "RoleCombinedToolTipDescription" ,  columnDefinition="TEXT" )
	private String  roleCombinedToolTipDescription ;
	
	@Column(name = "BusinessRoleOAMName" ,  columnDefinition="TEXT" )
	private String  businessRoleOAMName ;
	
	@Column(name = "InnovationsCombined" ,  columnDefinition="TEXT" )
	private String  innovationsCombined ;
	
	@Column(name = "IntentsCombined" ,  columnDefinition="TEXT" )
	private String  intentsCombined ;
	
	@Column(name = "BSPNameCombined" ,  columnDefinition="TEXT" )
	private String  bspNameCombined ;
	
	@Column(name = "ODataServicesCombined" ,  columnDefinition="TEXT" )
	private String  odataServicesCombined ;
	
	@Column(name = "WebDynproComponentNameCombined" ,  columnDefinition="TEXT" )
	private String  webDynproComponentNameCombined ;
	
	@Column(name = "TCodesCombined" ,  columnDefinition="TEXT" )
	private String  tcodesCombined ;
	
	@Column(name = "RoleNameCombinedOnlyName" ,  columnDefinition="TEXT" )
	private String  roleNameCombinedOnlyName ;
	
	@Column(name = "BusinessGroupNameCombined" ,  columnDefinition="TEXT" )
	private String  businessGroupNameCombined ;
	
	@Column(name = "BusinessGroupDescriptionCombined" ,  columnDefinition="TEXT" )
	private String  businessGroupDescriptionCombined ;
	
	@Column(name = "BExQueryNameCombined" ,  columnDefinition="TEXT" )
	private String  bexQueryNameCombined ;
	
	@Column(name = "BExQueryDescriptionCombined" ,  columnDefinition="TEXT" )
	private String  bexQueryDescriptionCombined ;
	
	@Column(name = "SAPUI5ComponentIdCombined" ,  columnDefinition="TEXT" )
	private String  sapUI5ComponentIdCombined ;
	
	@Column(name = "BusinessRoleNameCombined" ,  columnDefinition="TEXT" )
	private String  businessRoleNameCombined ;
	
	@Column(name = "BusinessRoleDescriptionCombined" ,  columnDefinition="TEXT" )
	private String  businessRoleDescriptionCombined ;
	
	@Column(name = "FitAnalysisACHCombined" ,  columnDefinition="TEXT" )
	private String  fitAnalysisACHCombined ;
	
	@Column(name = "FormFactorsCombined" ,  columnDefinition="TEXT" )
	private String  formFactorsCombined ;
	
	@Column(name = "UITechnologyCombined" ,  columnDefinition="TEXT" )
	private String  uiTechnologyCombined ;
	
	@Column(name = "AppNameCombined" ,  columnDefinition="TEXT" )
	private String  appNameCombined ;
	
	@Column(name = "ProductInstanceUI" ,  columnDefinition="TEXT" )
	private String  productInstanceUI ;
	
	@Column(name = "AppLauncherTitleCombined" , columnDefinition="LONGTEXT" )
	private String  appLauncherTitleCombined ;
	
	@Column(name = "ScopeItemID" ,  columnDefinition="TEXT")
	private String  scopeItemID ;
	
///////
	
	@Column(name = "ReleaseGroupId" )
	private String releaseGroupId;
	
	@Column(name = "FioriId" , length = 500,columnDefinition="varchar(500)" )
	@Index(name="INDEX_FIORI_ID")
	private String fioriId;
	
	@Column(name = "AllReleases" )
	private String allReleases;
	
	@Column(name = "Type" )
	private String type;
	
	@Column(name = "Name" )
	private String name;
	
	@Column(name = "File" ,columnDefinition="varchar(500)" )
	private String file;
	
	@Column(name = "Description" , columnDefinition="varchar(5000)")
	private String description;

	public Integer getAutoId() {
		return autoId;
	}

	public void setAutoId(Integer autoId) {
		this.autoId = autoId;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getProductInstanceBE() {
		return productInstanceBE;
	}

	public void setProductInstanceBE(String productInstanceBE) {
		this.productInstanceBE = productInstanceBE;
	}

	public String getReleaseGroupText() {
		return releaseGroupText;
	}

	public void setReleaseGroupText(String releaseGroupText) {
		this.releaseGroupText = releaseGroupText;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public String getReleaseId() {
		return releaseId;
	}

	public void setReleaseId(String releaseId) {
		this.releaseId = releaseId;
	}

	public String getReleaseName() {
		return releaseName;
	}

	public void setReleaseName(String releaseName) {
		this.releaseName = releaseName;
	}

	public String getOtherReleases() {
		return otherReleases;
	}

	public void setOtherReleases(String otherReleases) {
		this.otherReleases = otherReleases;
	}

	public String getAppNameAll() {
		return appNameAll;
	}

	public void setAppNameAll(String appNameAll) {
		this.appNameAll = appNameAll;
	}

	public String getRoleNameCombined() {
		return roleNameCombined;
	}

	public void setRoleNameCombined(String roleNameCombined) {
		this.roleNameCombined = roleNameCombined;
	}

	public String getSolutionsCapabilityCombined() {
		return solutionsCapabilityCombined;
	}

	public void setSolutionsCapabilityCombined(String solutionsCapabilityCombined) {
		this.solutionsCapabilityCombined = solutionsCapabilityCombined;
	}

	public String getSolutionsCapabilityIDCombined() {
		return solutionsCapabilityIDCombined;
	}

	public void setSolutionsCapabilityIDCombined(String solutionsCapabilityIDCombined) {
		this.solutionsCapabilityIDCombined = solutionsCapabilityIDCombined;
	}

	public String getTitleCombined() {
		return titleCombined;
	}

	public void setTitleCombined(String titleCombined) {
		this.titleCombined = titleCombined;
	}

	public String getAvailabilityInFaaSCombined() {
		return availabilityInFaaSCombined;
	}

	public void setAvailabilityInFaaSCombined(String availabilityInFaaSCombined) {
		this.availabilityInFaaSCombined = availabilityInFaaSCombined;
	}

	public String getLobCombined() {
		return lobCombined;
	}

	public void setLobCombined(String lobCombined) {
		this.lobCombined = lobCombined;
	}

	public String getIndustryCombined() {
		return industryCombined;
	}

	public void setIndustryCombined(String industryCombined) {
		this.industryCombined = industryCombined;
	}

	public String getPcdCombined() {
		return pcdCombined;
	}

	public void setPcdCombined(String pcdCombined) {
		this.pcdCombined = pcdCombined;
	}

	public String getAchCombined() {
		return achCombined;
	}

	public void setAchCombined(String achCombined) {
		this.achCombined = achCombined;
	}

	public String getAchLevel2Combined() {
		return achLevel2Combined;
	}

	public void setAchLevel2Combined(String achLevel2Combined) {
		this.achLevel2Combined = achLevel2Combined;
	}

	public String getDatabaseCombined() {
		return databaseCombined;
	}

	public void setDatabaseCombined(String databaseCombined) {
		this.databaseCombined = databaseCombined;
	}

	public String getPrimaryPVOfficialNameCombined() {
		return primaryPVOfficialNameCombined;
	}

	public void setPrimaryPVOfficialNameCombined(String primaryPVOfficialNameCombined) {
		this.primaryPVOfficialNameCombined = primaryPVOfficialNameCombined;
	}

	public String getPvFrontendCombined() {
		return pvFrontendCombined;
	}

	public void setPvFrontendCombined(String pvFrontendCombined) {
		this.pvFrontendCombined = pvFrontendCombined;
	}

	public String getPvBackendCombined() {
		return pvBackendCombined;
	}

	public void setPvBackendCombined(String pvBackendCombined) {
		this.pvBackendCombined = pvBackendCombined;
	}

	public String getAppTypeCombined() {
		return appTypeCombined;
	}

	public void setAppTypeCombined(String appTypeCombined) {
		this.appTypeCombined = appTypeCombined;
	}

	public String getTechnicalCatalogNameCombined() {
		return technicalCatalogNameCombined;
	}

	public void setTechnicalCatalogNameCombined(String technicalCatalogNameCombined) {
		this.technicalCatalogNameCombined = technicalCatalogNameCombined;
	}

	public String getBusinessCatalogNameCombined() {
		return businessCatalogNameCombined;
	}

	public void setBusinessCatalogNameCombined(String businessCatalogNameCombined) {
		this.businessCatalogNameCombined = businessCatalogNameCombined;
	}

	public String getFrontendSCVCombined() {
		return frontendSCVCombined;
	}

	public void setFrontendSCVCombined(String frontendSCVCombined) {
		this.frontendSCVCombined = frontendSCVCombined;
	}

	public String getHanaSCVCombined() {
		return hanaSCVCombined;
	}

	public void setHanaSCVCombined(String hanaSCVCombined) {
		this.hanaSCVCombined = hanaSCVCombined;
	}

	public String getBackendSCVCombined() {
		return backendSCVCombined;
	}

	public void setBackendSCVCombined(String backendSCVCombined) {
		this.backendSCVCombined = backendSCVCombined;
	}

	public String getReleaseGroupTextCombined() {
		return releaseGroupTextCombined;
	}

	public void setReleaseGroupTextCombined(String releaseGroupTextCombined) {
		this.releaseGroupTextCombined = releaseGroupTextCombined;
	}

	public String getPortfolioCategoryCombined() {
		return portfolioCategoryCombined;
	}

	public void setPortfolioCategoryCombined(String portfolioCategoryCombined) {
		this.portfolioCategoryCombined = portfolioCategoryCombined;
	}

	public String getProductCategoryDetails() {
		return productCategoryDetails;
	}

	public void setProductCategoryDetails(String productCategoryDetails) {
		this.productCategoryDetails = productCategoryDetails;
	}

	public String getRoleDescription() {
		return roleDescription;
	}

	public void setRoleDescription(String roleDescription) {
		this.roleDescription = roleDescription;
	}

	public String getBusinessCatalog() {
		return businessCatalog;
	}

	public void setBusinessCatalog(String businessCatalog) {
		this.businessCatalog = businessCatalog;
	}

	public String getTechnicalCatalog() {
		return technicalCatalog;
	}

	public void setTechnicalCatalog(String technicalCatalog) {
		this.technicalCatalog = technicalCatalog;
	}

	public String getFitAnalysisACH() {
		return fitAnalysisACH;
	}

	public void setFitAnalysisACH(String fitAnalysisACH) {
		this.fitAnalysisACH = fitAnalysisACH;
	}

	public String getPvBackend() {
		return pvBackend;
	}

	public void setPvBackend(String pvBackend) {
		this.pvBackend = pvBackend;
	}

	public String getPvFrontend() {
		return pvFrontend;
	}

	public void setPvFrontend(String pvFrontend) {
		this.pvFrontend = pvFrontend;
	}

	public String getAppTypeLevel() {
		return appTypeLevel;
	}

	public void setAppTypeLevel(String appTypeLevel) {
		this.appTypeLevel = appTypeLevel;
	}

	public String getProductInstanceHANA() {
		return productInstanceHANA;
	}

	public void setProductInstanceHANA(String productInstanceHANA) {
		this.productInstanceHANA = productInstanceHANA;
	}

	public String getApplicationComponentText() {
		return applicationComponentText;
	}

	public void setApplicationComponentText(String applicationComponentText) {
		this.applicationComponentText = applicationComponentText;
	}

	public String getFormFactors() {
		return formFactors;
	}

	public void setFormFactors(String formFactors) {
		this.formFactors = formFactors;
	}

	public String getPortfolioCategoryIV() {
		return portfolioCategoryIV;
	}

	public void setPortfolioCategoryIV(String portfolioCategoryIV) {
		this.portfolioCategoryIV = portfolioCategoryIV;
	}

	public String getPortfolioCategoryImp() {
		return portfolioCategoryImp;
	}

	public void setPortfolioCategoryImp(String portfolioCategoryImp) {
		this.portfolioCategoryImp = portfolioCategoryImp;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getApplicationType() {
		return applicationType;
	}

	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}

	public String getBspName() {
		return bspName;
	}

	public void setBspName(String bspName) {
		this.bspName = bspName;
	}

	public String getBspApplicationURL() {
		return bspApplicationURL;
	}

	public void setBspApplicationURL(String bspApplicationURL) {
		this.bspApplicationURL = bspApplicationURL;
	}

	public String getNewRoleName() {
		return newRoleName;
	}

	public void setNewRoleName(String newRoleName) {
		this.newRoleName = newRoleName;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getGtmLoBName() {
		return gtmLoBName;
	}

	public void setGtmLoBName(String gtmLoBName) {
		this.gtmLoBName = gtmLoBName;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public String getApplicationComponent() {
		return applicationComponent;
	}

	public void setApplicationComponent(String applicationComponent) {
		this.applicationComponent = applicationComponent;
	}

	public String getDatabase() {
		return database;
	}

	public void setDatabase(String database) {
		this.database = database;
	}

	public String getBackendSoftwareComponentVersions() {
		return backendSoftwareComponentVersions;
	}

	public void setBackendSoftwareComponentVersions(String backendSoftwareComponentVersions) {
		this.backendSoftwareComponentVersions = backendSoftwareComponentVersions;
	}

	public String getFrontendSoftwareComponent() {
		return frontendSoftwareComponent;
	}

	public void setFrontendSoftwareComponent(String frontendSoftwareComponent) {
		this.frontendSoftwareComponent = frontendSoftwareComponent;
	}

	public String getHanaSoftwareComponentVersions() {
		return hanaSoftwareComponentVersions;
	}

	public void setHanaSoftwareComponentVersions(String hanaSoftwareComponentVersions) {
		this.hanaSoftwareComponentVersions = hanaSoftwareComponentVersions;
	}

	public String getRoleCombinedToolTipDescription() {
		return roleCombinedToolTipDescription;
	}

	public void setRoleCombinedToolTipDescription(String roleCombinedToolTipDescription) {
		this.roleCombinedToolTipDescription = roleCombinedToolTipDescription;
	}

	public String getBusinessRoleOAMName() {
		return businessRoleOAMName;
	}

	public void setBusinessRoleOAMName(String businessRoleOAMName) {
		this.businessRoleOAMName = businessRoleOAMName;
	}

	public String getInnovationsCombined() {
		return innovationsCombined;
	}

	public void setInnovationsCombined(String innovationsCombined) {
		this.innovationsCombined = innovationsCombined;
	}

	public String getIntentsCombined() {
		return intentsCombined;
	}

	public void setIntentsCombined(String intentsCombined) {
		this.intentsCombined = intentsCombined;
	}

	public String getBspNameCombined() {
		return bspNameCombined;
	}

	public void setBspNameCombined(String bspNameCombined) {
		this.bspNameCombined = bspNameCombined;
	}

	public String getOdataServicesCombined() {
		return odataServicesCombined;
	}

	public void setOdataServicesCombined(String odataServicesCombined) {
		this.odataServicesCombined = odataServicesCombined;
	}

	public String getWebDynproComponentNameCombined() {
		return webDynproComponentNameCombined;
	}

	public void setWebDynproComponentNameCombined(String webDynproComponentNameCombined) {
		this.webDynproComponentNameCombined = webDynproComponentNameCombined;
	}

	public String getTcodesCombined() {
		return tcodesCombined;
	}

	public void setTcodesCombined(String tcodesCombined) {
		this.tcodesCombined = tcodesCombined;
	}

	public String getRoleNameCombinedOnlyName() {
		return roleNameCombinedOnlyName;
	}

	public void setRoleNameCombinedOnlyName(String roleNameCombinedOnlyName) {
		this.roleNameCombinedOnlyName = roleNameCombinedOnlyName;
	}

	public String getBusinessGroupNameCombined() {
		return businessGroupNameCombined;
	}

	public void setBusinessGroupNameCombined(String businessGroupNameCombined) {
		this.businessGroupNameCombined = businessGroupNameCombined;
	}

	public String getBusinessGroupDescriptionCombined() {
		return businessGroupDescriptionCombined;
	}

	public void setBusinessGroupDescriptionCombined(String businessGroupDescriptionCombined) {
		this.businessGroupDescriptionCombined = businessGroupDescriptionCombined;
	}

	public String getBexQueryNameCombined() {
		return bexQueryNameCombined;
	}

	public void setBexQueryNameCombined(String bexQueryNameCombined) {
		this.bexQueryNameCombined = bexQueryNameCombined;
	}

	public String getBexQueryDescriptionCombined() {
		return bexQueryDescriptionCombined;
	}

	public void setBexQueryDescriptionCombined(String bexQueryDescriptionCombined) {
		this.bexQueryDescriptionCombined = bexQueryDescriptionCombined;
	}

	public String getSapUI5ComponentIdCombined() {
		return sapUI5ComponentIdCombined;
	}

	public void setSapUI5ComponentIdCombined(String sapUI5ComponentIdCombined) {
		this.sapUI5ComponentIdCombined = sapUI5ComponentIdCombined;
	}

	public String getBusinessRoleNameCombined() {
		return businessRoleNameCombined;
	}

	public void setBusinessRoleNameCombined(String businessRoleNameCombined) {
		this.businessRoleNameCombined = businessRoleNameCombined;
	}

	public String getBusinessRoleDescriptionCombined() {
		return businessRoleDescriptionCombined;
	}

	public void setBusinessRoleDescriptionCombined(String businessRoleDescriptionCombined) {
		this.businessRoleDescriptionCombined = businessRoleDescriptionCombined;
	}

	public String getFitAnalysisACHCombined() {
		return fitAnalysisACHCombined;
	}

	public void setFitAnalysisACHCombined(String fitAnalysisACHCombined) {
		this.fitAnalysisACHCombined = fitAnalysisACHCombined;
	}

	public String getFormFactorsCombined() {
		return formFactorsCombined;
	}

	public void setFormFactorsCombined(String formFactorsCombined) {
		this.formFactorsCombined = formFactorsCombined;
	}

	public String getUiTechnologyCombined() {
		return uiTechnologyCombined;
	}

	public void setUiTechnologyCombined(String uiTechnologyCombined) {
		this.uiTechnologyCombined = uiTechnologyCombined;
	}

	public String getAppNameCombined() {
		return appNameCombined;
	}

	public void setAppNameCombined(String appNameCombined) {
		this.appNameCombined = appNameCombined;
	}

	public String getProductInstanceUI() {
		return productInstanceUI;
	}

	public void setProductInstanceUI(String productInstanceUI) {
		this.productInstanceUI = productInstanceUI;
	}

	public String getAppLauncherTitleCombined() {
		return appLauncherTitleCombined;
	}

	public void setAppLauncherTitleCombined(String appLauncherTitleCombined) {
		this.appLauncherTitleCombined = appLauncherTitleCombined;
	}

	public String getScopeItemID() {
		return scopeItemID;
	}

	public void setScopeItemID(String scopeItemID) {
		this.scopeItemID = scopeItemID;
	}

	public String getReleaseGroupId() {
		return releaseGroupId;
	}

	public void setReleaseGroupId(String releaseGroupId) {
		this.releaseGroupId = releaseGroupId;
	}

	public String getFioriId() {
		return fioriId;
	}

	public void setFioriId(String fioriId) {
		this.fioriId = fioriId;
	}

	public String getAllReleases() {
		return allReleases;
	}

	public void setAllReleases(String allReleases) {
		this.allReleases = allReleases;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFile() {
		return file;
	}

	public void setFile(String file) {
		this.file = file;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	
	
}
