package com.accenture.utility.odatafiori;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.accenture.utility.AppGenUtility;

public class FioriLibraryMasterSheetGenerator {
	protected static final Logger logger = LoggerFactory.getLogger(FioriLibraryMasterSheetGenerator.class);

	private FioriLibraryDao fioriLibraryDao;
	Map<String, String> appList = new HashMap<String, String>();

	public FioriLibraryDao getFioriLibraryDao() {
		return fioriLibraryDao;
	}

	@Autowired
	public void setFioriLibraryDao(FioriLibraryDao fioriLibraryDao) {
		this.fioriLibraryDao = fioriLibraryDao;
	}

	public void createFioriMasterSheet(String environment) throws IOException, SQLException {
		logger.info("Entering method createFioriMasterSheet ..");
		try {
			long fioriQueryStartTime = 0;
			long fioriQueryEndTime = 0;
			long fioriQueryTotalTime = 0;

			fioriLibraryDao = new FioriLibraryDaoImpl();
			fioriLibraryDao.truncateMasterSheetTables(environment);
			fioriQueryStartTime = System.currentTimeMillis();
			String[] urlList = { OdataFiori_Constants.FIORI_APP_LIBRARY_SAP_S4HANA_URL,
					OdataFiori_Constants.FIORI_APP_LIBRARY_SAP_BUSINESS_SUITE_LOWER_BACKEND_VERSIONS_URL,
					OdataFiori_Constants.FIORI_APP_LIBRARY_SAP_BUSINESS_SUITE_URL,
					OdataFiori_Constants.FIORI_APP_LIBRARY_SAP_S4HANA_CLOUD_URL };
			// OdataFiori_Constants.FIORI_APP_LIBRARY_URL
			// applistentity object, add in this
			List<AppListResultEntity> finalAppsListResultEntity = new ArrayList<AppListResultEntity>();
			// for loop start
			for (int i = 0; i < urlList.length; i++) {
				List<AppListResult> appsListResult = getFioriMasterLibradyApps(urlList[i]);
				fioriQueryEndTime = System.currentTimeMillis();
				List<AppListResultEntity> appsListResultEntity = converToEntity(appsListResult);
				finalAppsListResultEntity.addAll(appsListResultEntity);
			}
			// loop end
			fioriLibraryDao.insertFioriRecords(finalAppsListResultEntity, environment);

			// calling the urls for different s4 hana versions
			getFioriAppIdsS4HanaBatch(environment);

			fioriQueryTotalTime = fioriQueryEndTime - fioriQueryStartTime;
			logger.info("Total time taken in fiori query fetching data from Odata service ::{}", fioriQueryTotalTime);
		} catch (Exception e) {
			logger.error("createFioriMasterSheet :: ", e);
		}
	}

	private void getFioriAppIdsS4HanaBatch(String environment) throws Exception {
		List<String> urlList = Arrays.asList(OdataFiori_Constants.FIORI_APP_LIBRARY_S4HANA2021_VERSION,
				//OdataFiori_Constants.FIORI_APP_LIBRARY_S4HANA2020_VERSION,
				//OdataFiori_Constants.FIORI_APP_LIBRARY_S4HANA1909_VERSION,
				//OdataFiori_Constants.FIORI_APP_LIBRARY_S4HANA1809_VERSION,
				//OdataFiori_Constants.FIORI_APP_LIBRARY_S4HANA1709_VERSION,
				//OdataFiori_Constants.FIORI_APP_LIBRARY_S4HANA1609_VERSION,
				OdataFiori_Constants.FIORI_APP_LIBRARY_S4HANA1509_VERSION);

		urlList.forEach(url -> {
			List<AppListResultEntity> finalAppsListResultList = new ArrayList<>();
			int i = 0, count;

			try {
				count = AppGenUtility
						.getFioriAppLibraryCount(url.concat(OdataFiori_Constants.FIORI_APP_LIBRARY_COUNT_API));

				int counter = (int) Math.ceil((float) count / (float) OdataFiori_Constants.DEFAULT_BATCH_SIZE);

				int skip = 0;
				int top = OdataFiori_Constants.DEFAULT_BATCH_SIZE;

				while (i < counter) {
					List<AppListResultEntity> fioriAppsResultList = converToEntity(
							getFioriMasterLibradyApps(url + "?skip=" + skip + "&$top=" + top
									+ OdataFiori_Constants.FIORI_APP_LIBRARY_S4HANA_COMMON_PART));
					finalAppsListResultList.addAll(fioriAppsResultList);

					skip += OdataFiori_Constants.DEFAULT_BATCH_SIZE;
					++i;
				}

				fioriLibraryDao.insertFioriRecords(finalAppsListResultList, environment);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}

	public List<AppListResultEntity> converToEntity(List<AppListResult> appsListResult) {
		List<AppListResultEntity> appListResultEntity = new ArrayList<AppListResultEntity>();
		Set<String> techCatalogName = new HashSet<String>();
		Set<String> additionalIntents = new HashSet<String>();

		for (AppListResult app : appsListResult) {

			if (app.getTechnicalCatalogName() != null && !app.getTechnicalCatalogName().isEmpty()) {
				if (app.getTechnicalCatalogName() != null && app.getTechnicalCatalogName().contains("|")) {
					String techCName[] = app.getTechnicalCatalogName().split("\\|");
					for (String x : techCName) {
						techCatalogName.add(x);
					}
				} else {
					techCatalogName.add(app.getTechnicalCatalogName());
				}
			} else {
				techCatalogName.add("");
			}

			if (app.getAdditionalIntents() != null && !app.getAdditionalIntents().isEmpty()) {
				if (app.getAdditionalIntents().contains(",")) {
					String addIntent[] = app.getAdditionalIntents().split(",");
					for (String y : addIntent) {
						additionalIntents.add(y);
					}
				} else {
					additionalIntents.add(app.getAdditionalIntents());
				}
			} else {
				additionalIntents.add("");
			}

			for (String techC : techCatalogName) {

				for (String addInt : additionalIntents) {

					AppListResultEntity appEntity = new AppListResultEntity();

					BeanUtils.copyProperties(app, appEntity, AppGenUtility.getNullPropertyNames(app));
					appEntity.setAdditionalIntents(addInt.trim());
					appEntity.setTechnicalCatalogName(techC.trim());
					appListResultEntity.add(appEntity);
				}

			}
			techCatalogName.clear();
			additionalIntents.clear();
		}
		return appListResultEntity;
	}

	public List<AppListResult> getFioriMasterLibradyApps(String url) throws Exception {
		List<AppListResult> appList = new ArrayList<>();
		Map<String, AppResult> dMap = AppGenUtility.getJSONMap(url.concat("&$format=json"));

		try {
			appList.addAll((dMap.get("d")).getResults());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return appList;

	}

	//public static void main(String[] args) {
	public void generateFioriAppListResultMasterData() {
		String result = "Success";
		logger.info("Start Creating Fiori Master Sheet ..");
		FioriLibraryMasterSheetGenerator generator = new FioriLibraryMasterSheetGenerator();
		String environment = System.getProperty("environment");
		try {
			environment="localhost";
			generator.createFioriMasterSheet(environment);
		} catch (Exception e) {
			result = "Fail";
			logger.error("Exception is .................", e);
		}
		if ("Success".equalsIgnoreCase(result)) {
		}
		logger.info("Done Creating Fiori Master Sheet ..");
	}
}
