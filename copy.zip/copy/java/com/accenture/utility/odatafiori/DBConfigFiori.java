package com.accenture.utility.odatafiori;

import java.io.IOException;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.admin.dao.AdminRequestMappingDAOImpl;
import com.accenture.utility.CustomBasicDataSourceEncryptor;
import com.accenture.utility.HANAUtility;

public class DBConfigFiori {
	
	final public static Logger logger = LoggerFactory.getLogger(DBConfigFiori.class);
	 
	 // For all the class Generic code
	 public static java.sql.Connection getJDBCConnection(String Environment) {
			String jdbcUrl = null;
			String username = null;
			String password = null;
			
			String filename=GetJdbcProperties(Environment);

			try {
				jdbcUrl = HANAUtility.getPropertyValueEnv(filename, "jdbcUrl");
				username =HANAUtility.getPropertyValueEnv(filename, "username");
			    password =CustomBasicDataSourceEncryptor.decrypt(HANAUtility.getPropertyValueEnv(filename, "password"));
			} catch (IOException e1) {
				
				logger.error("Error !!! " + e1);
			}
			java.sql.Connection conn = null;
			try {
				conn = DriverManager.getConnection(jdbcUrl, username, password);

			} catch (SQLException e) {
				logger.error("SQL Error occured while getting JDBC connection : " + e);
			} catch (Exception e) {
				logger.error("Error !!! " + e);
			}
			return conn;
		}
		
		//This function return the file name to the corresponding Environment
			public static String GetJdbcProperties(String Environment)  {
				
				String filename=null;
				
				System.out.print("::::::::::::::Enviroment--"+Environment);
				if (Environment.equalsIgnoreCase("DEV"))
				{
					filename="DB_Dev.properties";
		     	}
				else if (Environment.equalsIgnoreCase("PROD"))
				{
					filename="DB_Prd.properties";
				}
				else if (Environment.equalsIgnoreCase("STAGE"))
				{
					filename="DB_Stage.properties";
				}
				else if (Environment.equalsIgnoreCase("localhost"))
				{
					filename="DB_Localhost.properties";
		     	}
				System.out.print("::::::::::::::File Name--"+filename);		
				return filename;	
			}
			
}
