package com.accenture.utility.odatafiori;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;


@JsonIgnoreProperties({"metadata"})
public class AppListResult {
	
	@JsonIgnore
	@Transient
	private Metadata metadata;
	
	@Id	
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "AutoId")
	private Integer autoId;
	
	
	@JsonProperty("localId")	
	private String localId;
	
	@JsonProperty("fioriId")	
	private String fioriId;
	
	@JsonProperty("ACHLevel2")
	private String achLevel2;
	
	@JsonProperty("releaseId")	
	private String releaseId;
	
	@JsonProperty("BSPApplicationURL")	
	private String bspApplicationURL;
	
	@JsonProperty("BSPName")	
	private String bspName;
	
	@JsonProperty("SemanticObject")	
	private String semanticObject;
	
	@JsonProperty("SemanticAction")	
	private String semanticAction;
	
	@JsonProperty("TechnicalCatalogName")	
	private String technicalCatalogName;
	
	@JsonProperty("TechnicalCatalogDescription")	
	private String technicalCatalogDescription;
	
	@JsonProperty("BusinessCatalogName")	
	private String businessCatalogName;
	
	@JsonProperty("BusinessCatalogDescription")	
	private String businessCatalogDescription;
	
	@JsonProperty("BusinessGroupName")	
	private String businessGroupName;
	
	@JsonProperty("BusinessGroupDescription")	
	private String businessGroupDescription;
	
	@JsonProperty("PrimaryODataServiceName")	
	private String primaryODataServiceName;
	
	@JsonProperty("AdditionalODataServices")	
	private String additionalODataServices;
	
	@JsonProperty("AdditionalODataServicesVersions")	
	private String additionalODataServicesVersions;
	
	@JsonProperty("ProductVersionNameBackend")	
	private String productVersionNameBackend;
	
	@JsonProperty("PVBackendAll")	
	private String pvBackendAll;
	
	@JsonProperty("HANAProductVersion")	
	private String hanaProductVersion;
	
	@JsonProperty("ProductCategory")	
	private String productCategory;
	
	@JsonProperty("NoteCollection")	
	private String noteCollection;
	
	@JsonProperty("PrimaryPVOfficialName")	
	private String primaryPVOfficialName;
	
	@JsonProperty("PVFrontendAll")	
	private String pvFrontendAll;
	
	@JsonProperty("RoleName")	
	private String roleName;
	
	@JsonProperty("BusinessRoleOAMName")	
	private String businessRoleOAMName;
	
	@JsonProperty("RoleNameBusinessDescCombo")	
	private String roleNameBusinessDescCombo;
	
	@JsonProperty("AppName")	
	private String appName;
	
	@JsonProperty("ExternalReleaseName")	
	private String externalReleaseName;
	
	@JsonProperty("ApplicationType")	
	private String applicationType;
	
	@JsonProperty("Database_App")	
	private String databaseApp;
	
	@JsonProperty("GTMInnovationName")	
	private String gtmInnovationName;
	
	@JsonProperty("GTMInnovationID")	
	private String gtmInnovationID;
	
	@JsonProperty("PFDBIndustry")	
	private String pfdbIndustry;
	
	@JsonProperty("Description")	
	private String description;
	
	@JsonProperty("ACH")	
	private String ach;
	
	@JsonProperty("releaseGroupText")	
	private String releaseGroupText;
	
	@JsonProperty("BackendMinSP")	
	private String backendMinSP;
	
	@JsonProperty("HANAMinSP")	
	private String hanaMinSP;
	
	@JsonProperty("SolutionsCapabilityID")	
	private String solutionsCapabilityID;
	
	@JsonProperty("ACH_L2_TEXT")	
	private String achL2Text;
	
	@JsonProperty("releaseRank")	
	private Double releaseRank;
	
	@JsonProperty("TRANSACTION_MATCH")	
	private String transactionMatch;
	
	@JsonProperty("FormFactors")	
	private String formFactors;
	
	@JsonProperty("PortfolioCategoryIV")	
	private String portfolioCategoryIV;
	
	@JsonProperty("PortfolioCategoryImp")	
	private String portfolioCategoryImp;
	
	@JsonProperty("UITechnology")	
	private String uiTechnology;
	
	@JsonProperty("AdditionalIntents")	
	private String additionalIntents;
	
	@JsonProperty("SAPUI5ComponentId")	
	private String sapUI5ComponentId;
	
	@JsonProperty("WDAConfiguration")	
	private String wdaConfiguration;
	
	@JsonProperty("GTMLoBName")	
	private String gtmLoBName;
	
	@JsonProperty("KPIID")	
	private String kpiID;
	
	@JsonProperty("PrimaryODataServiceVersion")	
	private String primaryODataServiceVersion;
	
	@JsonProperty("PortfolioCategory")	
	private String portfolioCategory;
	
	@JsonProperty("FrontendProductVersion")	
	private String frontendProductVersion;
	
	@JsonProperty("GTMAppDescription")	
	private String gtmAppDescription;
	
	@JsonProperty("availabilityInFaaS")	
	private String availabilityInFaaS;
	
	@JsonProperty("SolutionsCapability")	
	private String solutionsCapability;
	
	@JsonProperty("ScopeItemID")	
	private String scopeItemID;
	
	@JsonProperty("ScopeItemDescription")	
	private String scopeItemDescription;
	
	@JsonProperty("highlightKey")	
	private String highlightKey;
	
	@JsonProperty("SolutionsCapabilityGUID")	
	private String solutionsCapabilityGUID;
	
	@JsonProperty("ScopeItemGroup")	
	private String scopeItemGroup;
	
	@JsonProperty("FrontendSoftwareComponent")	
	private String frontendSoftwareComponent;
	
	@JsonProperty("BackendSoftwareComponentVersions")	
	private String backendSoftwareComponentVersions;
	
	@JsonProperty("HANASoftwareComponentVersions")	
	private String hanaSoftwareComponentVersions;
	
	@JsonProperty("BexQueryName")	
	private String bexQueryName;
	
	@JsonProperty("CombinedTitle")	
	private String combinedTitle;
	
	@JsonProperty("ScreenshotLinks")	
	private String screenshotLinks;
	
	@JsonProperty("BusinessRoleName")	
	private String businessRoleName;
	
	@JsonProperty("BusinessRoleDescription")	
	private String businessRoleDescription;
	
	@JsonProperty("LeadingBusinessRoleName")	
	private String leadingBusinessRoleName;
	
	@JsonProperty("LeadingBusinessRoleDescription")	
	private String leadingBusinessRoleDescription;
	
	@JsonProperty("LeadBRAdditionalLanguage")	
	private String leadBRAdditionalLanguage;
	
	@JsonProperty("LeadBRAdditional")	
	private String leadBRAdditional;
	
	@JsonProperty("BRAdditionalLanguage")	
	private String brAdditionalLanguage;
	
	@JsonProperty("BRAdditional")	
	private String brAdditional;
	
	@JsonProperty("BCAdditionalLanguage")	
	private String bcAdditionalLanguage;
	
	@JsonProperty("BCAdditional")	
	private String bcAdditional;
	
	@JsonProperty("BGAdditionalLanguage")	
	private String bgAdditionalLanguage;
	
	@JsonProperty("BGAdditional")	
	private String bgAdditional;
	
	@JsonProperty("CombinedTitleAdditionalLang")	
	private String combinedTitleAdditionalLang;
	
	@JsonProperty("TCAdditionalLanguage")	
	private String tcAdditionalLanguage;
	
	@JsonProperty("TCAdditional")	
	private String tcAdditional;
	
	@JsonProperty("FrontendProductVersionStack")	
	private String frontendProductVersionStack;
	
	@JsonProperty("FrontendActivatedInstance")	
	private String frontendActivatedInstance;
	
	@JsonProperty("FrontendMinSP")	
	private String frontendMinSP;
	
	@JsonProperty("BackendProductVersionStack")	
	private String backendProductVersionStack;
	
	@JsonProperty("BackendActivatedInstance")	
	private String backendActivatedInstance;
	
	@JsonProperty("HANAProductVersionStack")	
	private String hanaProductVersionStack;
	
	@JsonProperty("HANAActivatedInstance")	
	private String hanaActivatedInstance;

	public Integer getAutoId() {
		return autoId;
	}

	public void setAutoId(Integer autoId) {
		this.autoId = autoId;
	}

	public String getLocalId() {
		return localId;
	}

	public void setLocalId(String localId) {
		this.localId = localId;
	}

	public String getFioriId() {
		return fioriId;
	}

	public void setFioriId(String fioriId) {
		this.fioriId = fioriId;
	}

	public String getAchLevel2() {
		return achLevel2;
	}

	public void setAchLevel2(String achLevel2) {
		this.achLevel2 = achLevel2;
	}

	public String getReleaseId() {
		return releaseId;
	}

	public void setReleaseId(String releaseId) {
		this.releaseId = releaseId;
	}

	public String getBspApplicationURL() {
		return bspApplicationURL;
	}

	public void setBspApplicationURL(String bspApplicationURL) {
		this.bspApplicationURL = bspApplicationURL;
	}

	public String getBspName() {
		return bspName;
	}

	public void setBspName(String bspName) {
		this.bspName = bspName;
	}

	public String getSemanticObject() {
		return semanticObject;
	}

	public void setSemanticObject(String semanticObject) {
		this.semanticObject = semanticObject;
	}

	public String getSemanticAction() {
		return semanticAction;
	}

	public void setSemanticAction(String semanticAction) {
		this.semanticAction = semanticAction;
	}

	public String getTechnicalCatalogName() {
		return technicalCatalogName;
	}

	public void setTechnicalCatalogName(String technicalCatalogName) {
		this.technicalCatalogName = technicalCatalogName;
	}

	public String getTechnicalCatalogDescription() {
		return technicalCatalogDescription;
	}

	public void setTechnicalCatalogDescription(String technicalCatalogDescription) {
		this.technicalCatalogDescription = technicalCatalogDescription;
	}

	public String getBusinessCatalogName() {
		return businessCatalogName;
	}

	public void setBusinessCatalogName(String businessCatalogName) {
		this.businessCatalogName = businessCatalogName;
	}

	public String getBusinessCatalogDescription() {
		return businessCatalogDescription;
	}

	public void setBusinessCatalogDescription(String businessCatalogDescription) {
		this.businessCatalogDescription = businessCatalogDescription;
	}

	public String getBusinessGroupName() {
		return businessGroupName;
	}

	public void setBusinessGroupName(String businessGroupName) {
		this.businessGroupName = businessGroupName;
	}

	public String getBusinessGroupDescription() {
		return businessGroupDescription;
	}

	public void setBusinessGroupDescription(String businessGroupDescription) {
		this.businessGroupDescription = businessGroupDescription;
	}

	public String getPrimaryODataServiceName() {
		return primaryODataServiceName;
	}

	public void setPrimaryODataServiceName(String primaryODataServiceName) {
		this.primaryODataServiceName = primaryODataServiceName;
	}

	public String getAdditionalODataServices() {
		return additionalODataServices;
	}

	public void setAdditionalODataServices(String additionalODataServices) {
		this.additionalODataServices = additionalODataServices;
	}

	public String getAdditionalODataServicesVersions() {
		return additionalODataServicesVersions;
	}

	public void setAdditionalODataServicesVersions(String additionalODataServicesVersions) {
		this.additionalODataServicesVersions = additionalODataServicesVersions;
	}

	public String getProductVersionNameBackend() {
		return productVersionNameBackend;
	}

	public void setProductVersionNameBackend(String productVersionNameBackend) {
		this.productVersionNameBackend = productVersionNameBackend;
	}

	public String getPvBackendAll() {
		return pvBackendAll;
	}

	public void setPvBackendAll(String pvBackendAll) {
		this.pvBackendAll = pvBackendAll;
	}

	public String getHanaProductVersion() {
		return hanaProductVersion;
	}

	public void setHanaProductVersion(String hanaProductVersion) {
		this.hanaProductVersion = hanaProductVersion;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public String getNoteCollection() {
		return noteCollection;
	}

	public void setNoteCollection(String noteCollection) {
		this.noteCollection = noteCollection;
	}

	public String getPrimaryPVOfficialName() {
		return primaryPVOfficialName;
	}

	public void setPrimaryPVOfficialName(String primaryPVOfficialName) {
		this.primaryPVOfficialName = primaryPVOfficialName;
	}

	public String getPvFrontendAll() {
		return pvFrontendAll;
	}

	public void setPvFrontendAll(String pvFrontendAll) {
		this.pvFrontendAll = pvFrontendAll;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getBusinessRoleOAMName() {
		return businessRoleOAMName;
	}

	public void setBusinessRoleOAMName(String businessRoleOAMName) {
		this.businessRoleOAMName = businessRoleOAMName;
	}

	public String getRoleNameBusinessDescCombo() {
		return roleNameBusinessDescCombo;
	}

	public void setRoleNameBusinessDescCombo(String roleNameBusinessDescCombo) {
		this.roleNameBusinessDescCombo = roleNameBusinessDescCombo;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getExternalReleaseName() {
		return externalReleaseName;
	}

	public void setExternalReleaseName(String externalReleaseName) {
		this.externalReleaseName = externalReleaseName;
	}

	public String getApplicationType() {
		return applicationType;
	}

	public void setApplicationType(String applicationType) {
		this.applicationType = applicationType;
	}

	public String getDatabaseApp() {
		return databaseApp;
	}

	public void setDatabaseApp(String databaseApp) {
		this.databaseApp = databaseApp;
	}

	public String getGtmInnovationName() {
		return gtmInnovationName;
	}

	public void setGtmInnovationName(String gtmInnovationName) {
		this.gtmInnovationName = gtmInnovationName;
	}

	public String getGtmInnovationID() {
		return gtmInnovationID;
	}

	public void setGtmInnovationID(String gtmInnovationID) {
		this.gtmInnovationID = gtmInnovationID;
	}

	public String getPfdbIndustry() {
		return pfdbIndustry;
	}

	public void setPfdbIndustry(String pfdbIndustry) {
		this.pfdbIndustry = pfdbIndustry;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getAch() {
		return ach;
	}

	public void setAch(String ach) {
		this.ach = ach;
	}

	public String getReleaseGroupText() {
		return releaseGroupText;
	}

	public void setReleaseGroupText(String releaseGroupText) {
		this.releaseGroupText = releaseGroupText;
	}

	public String getBackendMinSP() {
		return backendMinSP;
	}

	public void setBackendMinSP(String backendMinSP) {
		this.backendMinSP = backendMinSP;
	}

	public String getHanaMinSP() {
		return hanaMinSP;
	}

	public void setHanaMinSP(String hanaMinSP) {
		this.hanaMinSP = hanaMinSP;
	}

	public String getSolutionsCapabilityID() {
		return solutionsCapabilityID;
	}

	public void setSolutionsCapabilityID(String solutionsCapabilityID) {
		this.solutionsCapabilityID = solutionsCapabilityID;
	}

	public String getAchL2Text() {
		return achL2Text;
	}

	public void setAchL2Text(String achL2Text) {
		this.achL2Text = achL2Text;
	}

	public Double getReleaseRank() {
		return releaseRank;
	}

	public void setReleaseRank(Double releaseRank) {
		this.releaseRank = releaseRank;
	}

	public String getTransactionMatch() {
		return transactionMatch;
	}

	public void setTransactionMatch(String transactionMatch) {
		this.transactionMatch = transactionMatch;
	}

	public String getFormFactors() {
		return formFactors;
	}

	public void setFormFactors(String formFactors) {
		this.formFactors = formFactors;
	}

	public String getPortfolioCategoryIV() {
		return portfolioCategoryIV;
	}

	public void setPortfolioCategoryIV(String portfolioCategoryIV) {
		this.portfolioCategoryIV = portfolioCategoryIV;
	}

	public String getPortfolioCategoryImp() {
		return portfolioCategoryImp;
	}

	public void setPortfolioCategoryImp(String portfolioCategoryImp) {
		this.portfolioCategoryImp = portfolioCategoryImp;
	}

	public String getUiTechnology() {
		return uiTechnology;
	}

	public void setUiTechnology(String uiTechnology) {
		this.uiTechnology = uiTechnology;
	}

	public String getAdditionalIntents() {
		return additionalIntents;
	}

	public void setAdditionalIntents(String additionalIntents) {
		this.additionalIntents = additionalIntents;
	}

	public String getSapUI5ComponentId() {
		return sapUI5ComponentId;
	}

	public void setSapUI5ComponentId(String sapUI5ComponentId) {
		this.sapUI5ComponentId = sapUI5ComponentId;
	}

	public String getWdaConfiguration() {
		return wdaConfiguration;
	}

	public void setWdaConfiguration(String wdaConfiguration) {
		this.wdaConfiguration = wdaConfiguration;
	}

	public String getGtmLoBName() {
		return gtmLoBName;
	}

	public void setGtmLoBName(String gtmLoBName) {
		this.gtmLoBName = gtmLoBName;
	}

	public String getKpiID() {
		return kpiID;
	}

	public void setKpiID(String kpiID) {
		this.kpiID = kpiID;
	}

	public String getPrimaryODataServiceVersion() {
		return primaryODataServiceVersion;
	}

	public void setPrimaryODataServiceVersion(String primaryODataServiceVersion) {
		this.primaryODataServiceVersion = primaryODataServiceVersion;
	}

	public String getPortfolioCategory() {
		return portfolioCategory;
	}

	public void setPortfolioCategory(String portfolioCategory) {
		this.portfolioCategory = portfolioCategory;
	}

	public String getFrontendProductVersion() {
		return frontendProductVersion;
	}

	public void setFrontendProductVersion(String frontendProductVersion) {
		this.frontendProductVersion = frontendProductVersion;
	}

	public String getGtmAppDescription() {
		return gtmAppDescription;
	}

	public void setGtmAppDescription(String gtmAppDescription) {
		this.gtmAppDescription = gtmAppDescription;
	}

	public String getAvailabilityInFaaS() {
		return availabilityInFaaS;
	}

	public void setAvailabilityInFaaS(String availabilityInFaaS) {
		this.availabilityInFaaS = availabilityInFaaS;
	}

	public String getSolutionsCapability() {
		return solutionsCapability;
	}

	public void setSolutionsCapability(String solutionsCapability) {
		this.solutionsCapability = solutionsCapability;
	}

	public String getScopeItemID() {
		return scopeItemID;
	}

	public void setScopeItemID(String scopeItemID) {
		this.scopeItemID = scopeItemID;
	}

	public String getScopeItemDescription() {
		return scopeItemDescription;
	}

	public void setScopeItemDescription(String scopeItemDescription) {
		this.scopeItemDescription = scopeItemDescription;
	}

	public String getHighlightKey() {
		return highlightKey;
	}

	public void setHighlightKey(String highlightKey) {
		this.highlightKey = highlightKey;
	}

	public String getSolutionsCapabilityGUID() {
		return solutionsCapabilityGUID;
	}

	public void setSolutionsCapabilityGUID(String solutionsCapabilityGUID) {
		this.solutionsCapabilityGUID = solutionsCapabilityGUID;
	}

	public String getScopeItemGroup() {
		return scopeItemGroup;
	}

	public void setScopeItemGroup(String scopeItemGroup) {
		this.scopeItemGroup = scopeItemGroup;
	}

	public String getFrontendSoftwareComponent() {
		return frontendSoftwareComponent;
	}

	public void setFrontendSoftwareComponent(String frontendSoftwareComponent) {
		this.frontendSoftwareComponent = frontendSoftwareComponent;
	}

	public String getBackendSoftwareComponentVersions() {
		return backendSoftwareComponentVersions;
	}

	public void setBackendSoftwareComponentVersions(String backendSoftwareComponentVersions) {
		this.backendSoftwareComponentVersions = backendSoftwareComponentVersions;
	}

	public String getHanaSoftwareComponentVersions() {
		return hanaSoftwareComponentVersions;
	}

	public void setHanaSoftwareComponentVersions(String hanaSoftwareComponentVersions) {
		this.hanaSoftwareComponentVersions = hanaSoftwareComponentVersions;
	}

	public String getBexQueryName() {
		return bexQueryName;
	}

	public void setBexQueryName(String bexQueryName) {
		this.bexQueryName = bexQueryName;
	}

	public String getCombinedTitle() {
		return combinedTitle;
	}

	public void setCombinedTitle(String combinedTitle) {
		this.combinedTitle = combinedTitle;
	}

	public String getScreenshotLinks() {
		return screenshotLinks;
	}

	public void setScreenshotLinks(String screenshotLinks) {
		this.screenshotLinks = screenshotLinks;
	}

	public String getBusinessRoleName() {
		return businessRoleName;
	}

	public void setBusinessRoleName(String businessRoleName) {
		this.businessRoleName = businessRoleName;
	}

	public String getBusinessRoleDescription() {
		return businessRoleDescription;
	}

	public void setBusinessRoleDescription(String businessRoleDescription) {
		this.businessRoleDescription = businessRoleDescription;
	}

	public String getLeadingBusinessRoleName() {
		return leadingBusinessRoleName;
	}

	public void setLeadingBusinessRoleName(String leadingBusinessRoleName) {
		this.leadingBusinessRoleName = leadingBusinessRoleName;
	}

	public String getLeadingBusinessRoleDescription() {
		return leadingBusinessRoleDescription;
	}

	public void setLeadingBusinessRoleDescription(String leadingBusinessRoleDescription) {
		this.leadingBusinessRoleDescription = leadingBusinessRoleDescription;
	}

	public String getLeadBRAdditionalLanguage() {
		return leadBRAdditionalLanguage;
	}

	public void setLeadBRAdditionalLanguage(String leadBRAdditionalLanguage) {
		this.leadBRAdditionalLanguage = leadBRAdditionalLanguage;
	}

	public String getLeadBRAdditional() {
		return leadBRAdditional;
	}

	public void setLeadBRAdditional(String leadBRAdditional) {
		this.leadBRAdditional = leadBRAdditional;
	}

	public String getBrAdditionalLanguage() {
		return brAdditionalLanguage;
	}

	public void setBrAdditionalLanguage(String brAdditionalLanguage) {
		this.brAdditionalLanguage = brAdditionalLanguage;
	}

	public String getBrAdditional() {
		return brAdditional;
	}

	public void setBrAdditional(String brAdditional) {
		this.brAdditional = brAdditional;
	}

	public String getBcAdditionalLanguage() {
		return bcAdditionalLanguage;
	}

	public void setBcAdditionalLanguage(String bcAdditionalLanguage) {
		this.bcAdditionalLanguage = bcAdditionalLanguage;
	}

	public String getBcAdditional() {
		return bcAdditional;
	}

	public void setBcAdditional(String bcAdditional) {
		this.bcAdditional = bcAdditional;
	}

	public String getBgAdditionalLanguage() {
		return bgAdditionalLanguage;
	}

	public void setBgAdditionalLanguage(String bgAdditionalLanguage) {
		this.bgAdditionalLanguage = bgAdditionalLanguage;
	}

	public String getBgAdditional() {
		return bgAdditional;
	}

	public void setBgAdditional(String bgAdditional) {
		this.bgAdditional = bgAdditional;
	}

	public String getCombinedTitleAdditionalLang() {
		return combinedTitleAdditionalLang;
	}

	public void setCombinedTitleAdditionalLang(String combinedTitleAdditionalLang) {
		this.combinedTitleAdditionalLang = combinedTitleAdditionalLang;
	}

	public String getTcAdditionalLanguage() {
		return tcAdditionalLanguage;
	}

	public void setTcAdditionalLanguage(String tcAdditionalLanguage) {
		this.tcAdditionalLanguage = tcAdditionalLanguage;
	}

	public String getTcAdditional() {
		return tcAdditional;
	}

	public void setTcAdditional(String tcAdditional) {
		this.tcAdditional = tcAdditional;
	}

	public String getFrontendProductVersionStack() {
		return frontendProductVersionStack;
	}

	public void setFrontendProductVersionStack(String frontendProductVersionStack) {
		this.frontendProductVersionStack = frontendProductVersionStack;
	}

	public String getFrontendActivatedInstance() {
		return frontendActivatedInstance;
	}

	public void setFrontendActivatedInstance(String frontendActivatedInstance) {
		this.frontendActivatedInstance = frontendActivatedInstance;
	}

	public String getFrontendMinSP() {
		return frontendMinSP;
	}

	public void setFrontendMinSP(String frontendMinSP) {
		this.frontendMinSP = frontendMinSP;
	}

	public String getBackendProductVersionStack() {
		return backendProductVersionStack;
	}

	public void setBackendProductVersionStack(String backendProductVersionStack) {
		this.backendProductVersionStack = backendProductVersionStack;
	}

	public String getBackendActivatedInstance() {
		return backendActivatedInstance;
	}

	public void setBackendActivatedInstance(String backendActivatedInstance) {
		this.backendActivatedInstance = backendActivatedInstance;
	}

	public String getHanaProductVersionStack() {
		return hanaProductVersionStack;
	}

	public void setHanaProductVersionStack(String hanaProductVersionStack) {
		this.hanaProductVersionStack = hanaProductVersionStack;
	}

	public String getHanaActivatedInstance() {
		return hanaActivatedInstance;
	}

	public void setHanaActivatedInstance(String hanaActivatedInstance) {
		this.hanaActivatedInstance = hanaActivatedInstance;
	}

	
	
}
