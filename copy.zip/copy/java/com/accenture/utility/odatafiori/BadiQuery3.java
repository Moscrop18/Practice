package com.accenture.utility.odatafiori;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonSetter;

public class BadiQuery3 {
	@JsonIgnore
	private Metadata metadata;
	private String appId;
	private String releaseId;
	private String Type;
	private String Name;
	private String File;
	private String Description;
	private String GUID;
	private String SubType;
	public Metadata getMetadata() {
		return metadata;
	}
	
	@JsonSetter("_metadata")
	public void setMetadata(Metadata metadata) {
		this.metadata = metadata;
	}
	public String getAppId() {
		return appId;
	}
	
	@JsonSetter("appId")
	public void setAppId(String appId) {
		this.appId = appId;
	}
	public String getReleaseId() {
		return releaseId;
	}
	
	@JsonSetter("releaseId")
	public void setReleaseId(String releaseId) {
		this.releaseId = releaseId;
	}
	public String getType() {
		return Type;
	}
	
	@JsonSetter("Type")
	public void setType(String type) {
		Type = type;
	}
	public String getName() {
		return Name;
	}
	
	@JsonSetter("Name")
	public void setName(String name) {
		Name = name;
	}
	public String getFile() {
		return File;
	}
	
	@JsonSetter("File")
	public void setFile(String file) {
		File = file;
	}
	public String getDescription() {
		return Description;
	}
	
	@JsonSetter("Description")
	public void setDescription(String description) {
		Description = description;
	}
	public String getGUID() {
		return GUID;
	}
	
	@JsonSetter("GUID")
	public void setGUID(String gUID) {
		GUID = gUID;
	}
	public String getSubType() {
		return SubType;
	}
	
	@JsonSetter("SubType")
	public void setSubType(String subType) {
		SubType = subType;
	}
}
