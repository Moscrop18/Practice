package com.accenture.utility;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.tika.detect.DefaultDetector;
import org.apache.tika.detect.Detector;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.mime.MediaType;
import org.springframework.web.multipart.MultipartFile;

import com.accenture.S4.constant.S4HanaProfilerConstant;
import com.accenture.constant.File_Size_Constant;
import com.accenture.constant.ST03HanaConstant;
import com.accenture.constant.Services_Constant;
import com.accenture.exceptions.UploadFilesNotValidException;

public class FileUtility {

	public static void checkFileSize(File file) throws Exception {
		Long size = FileUtils.sizeOf(file);
		Long s = 0L;
		if ((file.getName().toUpperCase()).contains("ROM".toUpperCase())) {
			s = File_Size_Constant.ROM_SIZE;
			if (size > s)
				throw new Exception("The File size exceeded for "+file);
		}
		if ((file.getName().toUpperCase()).startsWith("AADT".toUpperCase())) {
			s = File_Size_Constant.FINAL_REPORT_SIZE;
			if (size > s)
				throw new Exception("The File size exceeded for "+file);
		}
		if ((file.getName().toUpperCase()).startsWith("Estimate".toUpperCase())) {
			s = File_Size_Constant.ESTIMATE_SIZE;
			if (size > s)
				throw new Exception("The File size exceeded for "+file);
		}
		if ((file.getName().toUpperCase()).contains("TADIR".toUpperCase())) {
			s = File_Size_Constant.TADIR_SIZE;
			if (size > s)
				throw new Exception("The File size exceeded for "+file.getName());
		}
		if ((file.getName().toUpperCase()).contains("ZAICAT_DETECTION".toUpperCase())) {
			s = File_Size_Constant.ZAICAT_DETECTION_SIZE;
			if (size > s)
				throw new Exception("The File size exceeded for "+file.getName());
		}
		if ((file.getName().toUpperCase()).contains(ST03HanaConstant.TRDIR_CONSTANT.toUpperCase())) {
			s = File_Size_Constant.TRDIR_SIZE;
			if (size > s)
				throw new Exception("The File size exceeded for "+file.getName());
			}
		if ((file.getName().toUpperCase()).contains(ST03HanaConstant.USAGE_CONSTANT.toUpperCase())) {
			s = File_Size_Constant.USAGE_ANALYSIS_SIZE;
			if (size > s)
				throw new Exception("The File size exceeded for "+file.getName());
			}
		if ((file.getName().toUpperCase()).contains(S4HanaProfilerConstant.INVENTORY_CONSTANT.toUpperCase())) {
			s = File_Size_Constant.INVENTORY_SIZE;
			if (size > s)
				throw new Exception("The File size exceeded for "+file.getName());
			}
		if ((file.getName().toUpperCase()).contains(S4HanaProfilerConstant.CLONE_CONSTANT.toUpperCase())) {
			s = File_Size_Constant.CLONE_SIZE;
			if (size > s)
				throw new Exception("The File size exceeded for "+file.getName());
			}
		if ((file.getName().toUpperCase()).contains(S4HanaProfilerConstant.SEARCH_CONSTANT.toUpperCase())) {
			s = File_Size_Constant.SEARCH_SIZE;
			if (size > s)
				throw new Exception("The File size exceeded for "+file.getName());
			}
		if ((file.getName().toUpperCase()).contains(S4HanaProfilerConstant.APPEND_CONSTANT.toUpperCase())) {
			s = File_Size_Constant.APPEND_SIZE;
			if (size > s)
				throw new Exception("The File size exceeded for "+file.getName());
			}
		if ((file.getName().toUpperCase()).contains(S4HanaProfilerConstant.IDOC_CONSTANT.toUpperCase())) {
			s = File_Size_Constant.IDOC_SIZE;
			if (size > s)
				throw new Exception("The File size exceeded for "+file.getName());
			}
		if ((file.getName().toUpperCase()).contains(Services_Constant.SMODILOG_CONSTANT.toUpperCase())) {
			s = File_Size_Constant.SMODILOG_SIZE;
			if (size > s)
				throw new Exception("The File size exceeded for "+file.getName());
			}
		if ((file.getName().toUpperCase()).contains(S4HanaProfilerConstant.IMPACTED_TABLES_CONSTANT.toUpperCase())) {
			s = File_Size_Constant.IMPACTED_TABLES_SIZE;
			if (size > s)
				throw new Exception("The File size exceeded for "+file.getName());
		}
		if ((file.getName().toUpperCase())
				.contains(S4HanaProfilerConstant.IMPACTED_STANDARD_TRANSACTION_CONSTANT.toUpperCase())) {
			s = File_Size_Constant.IMPACTED_STANDARD_TRANSACTION_SIZE;
			if (size > s)
				throw new Exception("The File size exceeded for "+file.getName());
		}
		if ((file.getName().toUpperCase()).contains(S4HanaProfilerConstant.ENHANCEMENT_CONSTANT.toUpperCase())) {
			s = File_Size_Constant.ENHANCEMENT_SIZE;
			if (size > s)
				throw new Exception("The File size exceeded for "+file.getName());
		}
		if ((file.getName().toUpperCase()).contains(Services_Constant.SRC_AGR1251_CONSTANT.toUpperCase())) {
			s = File_Size_Constant.SRC_ARG1251_SIZE;
			if (size > s)
				throw new Exception("The File size exceeded for "+file.getName());		
			}
		if ((file.getName().toUpperCase()).contains(Services_Constant.SRC_USOBTC_CONSTANT.toUpperCase())) {
			s = File_Size_Constant.SRC_USOBTC_SIZE;
			if (size > s)
				throw new Exception("The File size exceeded for "+file.getName());		
			}
		if ((file.getName().toUpperCase()).contains(Services_Constant.SRC_USERS_CONSTANT.toUpperCase())) {
			s = File_Size_Constant.ARG_USER_SIZE;
			if (size > s)
				throw new Exception("The File size exceeded for "+file.getName());		
			}
	}
	
	public static void checkFileSizeByItem(MultipartFile file, String fileName) throws Exception {
		Long size = file.getSize();
		Long s = 0L;
		if (fileName.equalsIgnoreCase("TCD")) {
			s = File_Size_Constant.TCD_SIZE;
			if (size > s)
				throw new Exception("The File size exceeded for "+file.getOriginalFilename());
		}
		if (fileName.equalsIgnoreCase("FIAT_FI")) {
			s = File_Size_Constant.FIAT_FI_SIZE;
			if (size > s)
				throw new Exception("The File size exceeded for "+file.getOriginalFilename());
		}
		if (fileName.equalsIgnoreCase("Early watch report")) {
			s = File_Size_Constant.FIAT_DOC_SIZE;
			if (size > s)
				throw new Exception("The File size exceeded for "+file.getOriginalFilename());
		}if (fileName.equalsIgnoreCase("Other File")) {
			s = File_Size_Constant.FIAT_OTHER_SIZE;
			if (size > s)
				throw new Exception("The File size exceeded for "+file.getOriginalFilename());
		}
		if (fileName.equalsIgnoreCase("Sizing report")) {
			s = File_Size_Constant.FIAT_TXT_SIZE;
			if (size > s)
				throw new Exception("The File size exceeded for "+file.getOriginalFilename());
		}
		if (fileName.equalsIgnoreCase("Simplification")) {
			s = File_Size_Constant.SIMPLIFCATION_SIZE;
			if (size > s)
				throw new Exception("The File size exceeded for "+file.getOriginalFilename());
		}
		if (fileName.equalsIgnoreCase("Big")) {
			s = File_Size_Constant.SIMPLIFCATION_DB_SIZE;
			if (size > s)
				throw new Exception("The File size exceeded for "+file.getOriginalFilename());
		}
		if (fileName.equalsIgnoreCase("Validation")) {
			s = File_Size_Constant.VALIDATION_SIZE;
			if (size > s)
				throw new Exception("The File size exceeded for "+file.getOriginalFilename());
		}
		if (fileName.equalsIgnoreCase("Target_USOBTC")) {
			s = File_Size_Constant.TRG_USOBTC_SIZE;
			if (size > s)
				throw new Exception("The File size exceeded for "+file.getOriginalFilename());
		}
		if (fileName.equalsIgnoreCase("TR")) {
			s = File_Size_Constant.TR_SIZE;
			if (size > s)
				throw new Exception("The File size exceeded for "+file.getOriginalFilename());
		}
		if (fileName.equalsIgnoreCase("DEL_TR")) {
			s = File_Size_Constant.DEL_TR_SIZE;
			if (size > s)
				throw new Exception("The File size exceeded for "+file.getOriginalFilename());
		}  
		if (fileName.equalsIgnoreCase("CR")) {
			s = File_Size_Constant.CR_SIZE;
			if (size > s)
				throw new Exception("The File size exceeded for "+file.getOriginalFilename());
		}
		if (fileName.equalsIgnoreCase("ReviewChecklist")) {
			s = File_Size_Constant.REVIEW_CHECKLIST_SIZE;
			if (size > s)
				throw new Exception("The File size exceeded for "+file.getOriginalFilename());
		}
		if (fileName.equalsIgnoreCase("PreRequisite")) {
			s = File_Size_Constant.PRE_REQ_SIZE;
			if (size > s)
				throw new Exception("The File size exceeded for "+file.getOriginalFilename());
		}
		if (fileName.equalsIgnoreCase("Fiori_Rebuild_Master")) {
			s = (Long) File_Size_Constant.Fiori_Rebuild_SIZE;
			if (size > s)
				throw new Exception("The File size exceeded for " + file.getOriginalFilename());
		}
	}
 	
	public static void detectZipFileType(MultipartFile file) throws Exception {
		InputStream stream = new ByteArrayInputStream(file.getBytes());
		InputStream streamBuff = new BufferedInputStream(stream);
		Detector detector = new DefaultDetector();
		Metadata metadata = new Metadata();
		MediaType mediatype = detector.detect(streamBuff, metadata);
		String fileType = mediatype.toString();
		if (!fileType.equalsIgnoreCase("application/zip"))
			throw new Exception("Not .zip File.  Please upload .zip File.");
	}
	
	
	public static void chckUploadFilesAlphaNum(String name) throws UploadFilesNotValidException {
		String regexAlphaNum = "^[a-zA-Z0-9._\\s\\(\\)-]+$";
        Pattern patternAlphaNum = Pattern.compile(regexAlphaNum);
        Matcher matcherclientTeamDet = patternAlphaNum.matcher(name);
        if(!name.equals("")
                && !matcherclientTeamDet.matches())
        	throw new UploadFilesNotValidException(name + " - The filename is not correct.");
	}
}
