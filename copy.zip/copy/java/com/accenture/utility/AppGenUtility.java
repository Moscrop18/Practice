package com.accenture.utility;

import java.net.URLDecoder;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.web.client.RestTemplate;

import com.accenture.constant.ST03HanaConstant;
import com.accenture.utility.odatafiori.AppResult;

public class AppGenUtility {

	public static boolean getTScopeVer(String sourceVer, String targetVer) {
		boolean result = false;

		String src = getSrc(sourceVer);
		String tar = getTar(targetVer);
		if (!src.isEmpty() && !tar.isEmpty() && !(src.equals(tar)))
			result = true;

		return result;
	}

	public static String getTCodeSourceCol(String sourceVersion) {
		List<String> tcodesColumns = ST03HanaConstant.TSCOPE_TCODES_COLS;
		String src = getSrc(sourceVersion);
		String srcCol = "";

		if (!src.isEmpty()) {
			for (String col : tcodesColumns) {
				if (col.contains(src)) {
					srcCol = col;
					break;
				}
			}
		}

		return srcCol;
	}

	public static String getTCodeTargetCol(String targetVersion) {
		List<String> tcodesColumns = ST03HanaConstant.TSCOPE_TCODES_COLS;
		String tar = getTar(targetVersion);
		String tarCol = "";

		if (!tar.isEmpty()) {
			for (String col : tcodesColumns) {
				if (col.contains(tar)) {
					tarCol = col;
					break;
				}
			}
		}

		if (tarCol.equals("TCodes_S4_2020"))
			tarCol = "TCodes_S4_1909";

		return tarCol;
	}

	private static String getSrc(String sourceVersion) {
		List<String> srcVersion = ST03HanaConstant.TSCOPE_SRC_VER_LIST;
		String srcValue = "";
		for (String src : srcVersion) {
			if (sourceVersion.contains(src)) {
				srcValue = src;
				break;
			}
		}

		return srcValue;
	}

	private static String getTar(String targetVersion) {
		List<String> tarVersion = ST03HanaConstant.TSCOPE_TAR_VER_LIST;
		String tarValue = "";
		for (String tar : tarVersion) {
			if (targetVersion.contains(tar)) {
				tarValue = tar;
				break;
			}
		}

		if (tarValue.equals("2020"))
			tarValue = "1909";

		return tarValue;
	}

	public static String[] getNullPropertyNames(Object source) {
		final BeanWrapper src = new BeanWrapperImpl(source);
		java.beans.PropertyDescriptor[] pds = src.getPropertyDescriptors();

		Set<String> emptyNames = new HashSet<String>();
		for (java.beans.PropertyDescriptor pd : pds) {
			Object srcValue = src.getPropertyValue(pd.getName());

			if (srcValue != null) {
				if (srcValue instanceof String && ((String) srcValue).isEmpty())
					emptyNames.add(pd.getName());
				else if (srcValue instanceof Integer && (Integer) srcValue == 0)
					emptyNames.add(pd.getName());
				else if (srcValue instanceof Long && (Long) srcValue == 0L)
					emptyNames.add(pd.getName());
				else if (srcValue instanceof Float && (Float) srcValue == 0.0F)
					emptyNames.add(pd.getName());
			} else
				emptyNames.add(pd.getName());
		}

		String[] result = new String[emptyNames.size()];
		return emptyNames.toArray(result);
	}

	public static boolean isRowEmpty(Row row) {
		Iterator<Cell> cellIterator = row.cellIterator();
		boolean cellEmpty = Boolean.TRUE;

		while (cellIterator.hasNext()) {
			Cell cell = cellIterator.next();
			if (cell != null && cell.getCellType() != HSSFCell.CELL_TYPE_BLANK) {
				cellEmpty = Boolean.FALSE;
				break;
			}
		}

		return cellEmpty;
	}

	public static Map<String, AppResult> getJSONMap(String url) throws Exception {
		try {
			HttpHeaders headers = new HttpHeaders();

			HttpEntity<String> request = new HttpEntity<>(headers);

			RestTemplate restTemplate = new RestTemplate();

			Map<String, AppResult> dMap = restTemplate.exchange(URLDecoder.decode(url, "UTF-8"), HttpMethod.GET,
					request, new ParameterizedTypeReference<Map<String, AppResult>>() {
					}).getBody();

			return dMap;
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception();
		}
	}

	public static int getFioriAppLibraryCount(String url) throws Exception {
		int count = 0;
		
		try {
			String value = new RestTemplate().exchange(URLDecoder.decode(
					url, "UTF-8"), HttpMethod.GET, null, String.class).getBody();
			
			if (StringUtils.isNumeric(value))
				count = Integer.parseInt(value);

			return count;
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception();
		}
	}
}
