package com.accenture.springsecurity.service;

import java.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory; 
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.transaction.annotation.Transactional;

import com.accenture.constant.Hana_Profiler_Constant;
import com.accenture.model.RolesAccess;
import com.accenture.poc.model.UserRole;

@Transactional
public class POCUserDetailsService implements UserDetailsService{


   final Logger logger=LoggerFactory.getLogger(POCUserDetailsService.class);
    private POCUserService userService;
     
    public void setUserService(POCUserService userService) {
		this.userService = userService;
	}


	
    public UserDetails loadUserByUsername(String userName)
            throws UsernameNotFoundException {
		logger.info(userName);
    	com.accenture.poc.model.User user = userService.findByUserName(userName);
        if(user==null){
            logger.info("User not found");
            throw new UsernameNotFoundException("Username not found");
        }
        RolesAccess rolesAccess = user.getRolesAccess();
        Set<String> uRoles = new HashSet<String>();
        if(rolesAccess.getR_admin()) uRoles.add(Hana_Profiler_Constant.ADMIN_ROLE);
        if(rolesAccess.getR_poc()) uRoles.add(Hana_Profiler_Constant.POC_ROLE);
        if(rolesAccess.getR_client()) uRoles.add(Hana_Profiler_Constant.CLIENT_ROLE);
			
        List<GrantedAuthority> authorities = buildUserAuthority(uRoles);
        //List<GrantedAuthority> authorities = buildUserAuthority(user.getUserRole());
    	return buildUserForAuthentication(user, authorities);
		
    	}
    
    private List<GrantedAuthority> buildUserAuthority(Set<String> userRoles) {

		Set<GrantedAuthority> setAuths = new HashSet<GrantedAuthority>();

		// Build user's authorities
		for (String userRole : userRoles) {
			setAuths.add(new SimpleGrantedAuthority(userRole));
			logger.info(userRole);
		}

		List<GrantedAuthority> Result = new ArrayList<GrantedAuthority>(setAuths);

		return Result;
	}

    //commented below method to enable new user role authentication  via role_access table 2019.11.28
	/*
		private List<GrantedAuthority> buildUserAuthority(Set<UserRole> userRoles) {

			Set<GrantedAuthority> setAuths = new HashSet<GrantedAuthority>();

			// Build user's authorities
			for (UserRole userRole : userRoles) {
				setAuths.add(new SimpleGrantedAuthority(userRole.getUserRole()));
				logger.info(userRole.getUserRole());
			}

			List<GrantedAuthority> Result = new ArrayList<GrantedAuthority>(setAuths);

			return Result;
		}
		*/
		
		// Converts com.accenture.poc.model.User user to org.springframework.security.core.userdetails.User
		
    	private User buildUserForAuthentication(com.accenture.poc.model.User user, List<GrantedAuthority> authorities) 
    	{
				return new User(user.getUserName(), user.getPassword(), 
					user.isEnabled(), true, true, true, authorities);
			}

}