package com.accenture.springsecurity.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.poc.dao.UserDAO;
import com.accenture.poc.model.User;

public class POCUserService {

	final Logger logger = LoggerFactory.getLogger(POCUserService.class);
	public UserDAO userDAO;
	
	public void setUserDAO(UserDAO userDAO) {
		this.userDAO = userDAO;
	}

	public User findByUserName(String userName) {
		logger.info("Inside find by username");
		return userDAO.getUser(userName);
    }
}
