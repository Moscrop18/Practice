package com.accenture.security.saml;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.saml.SAMLCredential;
import org.springframework.security.saml.userdetails.SAMLUserDetailsService;

import com.accenture.constant.Hana_Profiler_Constant;
import com.accenture.controller.AbstractBaseController;
import com.accenture.model.RolesAccess;
import com.accenture.poc.model.UserRole;


public class SimpleSAMLUserDetailsService extends AbstractBaseController implements SAMLUserDetailsService  {
    public static final String DUMMY_STRING = "DUMMY_STRING";
    private List<String> roles;
    public void setRoles(List<String> roles) {
        this.roles = roles;
    }
    String userRole = null ;
	@Override
	public Object loadUserBySAML(SAMLCredential credential) throws UsernameNotFoundException {
		logger.info("########### Inside loadUserBySAML method of SimpleSAMLUserDetailsService #######################");
		String userID = credential.getNameID().getValue();
		logger.info("USER ID BY SAML : " + userID);		
        //Collection<GrantedAuthority> gas = new ArrayList<GrantedAuthority>();
        Set<GrantedAuthority> setAuths = new HashSet<GrantedAuthority>();        
        com.accenture.poc.model.User user = getUserdata().getUser(userID);
        if(user != null){
        	
        	//commented below code to enable new user role authentication  via role_access table 2019.11.28
        	/*
        	Set<UserRole> userRoles = user.getUserRole();
        	
    		for (UserRole userRole : userRoles) {
    			setAuths.add(new SimpleGrantedAuthority(userRole.getUserRole()));
    			logger.info("USER ROLE BY SAML :");
    			logger.info(userRole.getUserRole());
    		}*/
        	RolesAccess rolesAccess = user.getRolesAccess();
        	Set<String> userRoles = new HashSet<String>();
             if(rolesAccess.getR_admin()) userRoles.add(Hana_Profiler_Constant.ADMIN_ROLE);
             if(rolesAccess.getR_poc()) userRoles.add(Hana_Profiler_Constant.POC_ROLE);
             if(rolesAccess.getR_client()) userRoles.add(Hana_Profiler_Constant.CLIENT_ROLE);
        	
    		for (String userRole : userRoles) {
    			setAuths.add(new SimpleGrantedAuthority(userRole));
    			logger.info("USER ROLE BY SAML :");
    			logger.info(userRole);
    		}
    		
        }else{
        	setAuths.add(new SimpleGrantedAuthority("ROLE_NEW"));
        	logger.info("Dummy Role Added for New user");
        }      
        logger.info("###### GrantedAuthority SIZE  ######### ::::::*****     ");
        logger.info("Size : " + setAuths.size());
        String username = userID;
        return new User(username, DUMMY_STRING, setAuths);
	}

}
