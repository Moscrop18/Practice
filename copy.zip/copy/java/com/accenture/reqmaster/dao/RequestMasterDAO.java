package com.accenture.reqmaster.dao;

import java.util.List;
import java.util.Map;

import com.accenture.master.ProcessedRMCounts;
import com.accenture.master.ProcessedRequestMaster;

public interface RequestMasterDAO {

	public Map<String, Map<String, Map<String, Integer>>> getAppLevelHANACounts(long requestId) throws Exception;

	public Map<String, Map<String, Integer>> getDBLevelHouskeepHANACounts(long requestId, String remCategory)
			throws Exception;

	public Map<String, Map<String, Map<String, Integer>>> getRemCatAutomationHANACounts(long requestId)
			throws Exception;

	public Map<String, Map<String, Map<String, Integer>>> getMandatoryHANACounts(long requestId) throws Exception;

	public Map<String, Map<String, Integer>> getRemCatHANACounts(long requestId) throws Exception;

	public Map<String, Map<String, Map<String, Integer>>> getRemCatIssueCatHANACounts(long requestId) throws Exception;

	public Map<String, Map<String, Integer>> getInventoryObjectCounts(long requestId) throws Exception;

	public Map<String, Map<String, Integer>> getRemCatS4Counts(long requestId) throws Exception;

	public Map<String, Map<String, Map<String, Integer>>> getRemCatCompS4Counts(long requestId) throws Exception;

	public Map<String, Integer> getS4Counts(long requestId, String s4ColName) throws Exception;

	public Integer getImpStdTransCount(long requestId) throws Exception;

	public Map<String, Map<String, Integer>> getImpactedObjectCounts(long requestId) throws Exception;

	public Map<String, Integer> getImpactedObjCountHANA(long requestId, String extNamespaceVal) throws Exception;
	
	public Map<String, Integer> getImpactedObjCountS4(long requestId, String extNamespaceVal) throws Exception;

	public Map<String, Integer> getDistinctCloneObjCount(long requestId) throws Exception;

	public Integer getDistinctCloneObjCountHANAS4(long requestId, String scope) throws Exception;

	public Map<String, Integer> getImpactedCloneObjectRefCountsHANAS4(long requestId, String scope) throws Exception;

	public Map<String, Map<String, Integer>> getTotalCloneObjects(long requestId) throws Exception;

	public Map<String, Map<String, Integer>> getSmodilogDistinctObjCount(long requestId) throws Exception;

	public Integer getTScopeProcessCount(long requestId) throws Exception;

	public Integer getTScopeObjectCount(long requestId) throws Exception;

	public Map<String, Integer> getAUCTCounts(long requestId) throws Exception;

	public Integer getInactiveObjCounts(long requestId) throws Exception;

	public Integer getDistinctRoleSIACounts(List<Long> reqIdsList) throws Exception;
	
	public Integer getImpactedRoleSIACounts(List<Long> reqIdsList) throws Exception;

	public Map<String, Integer> getSIACounts(List<Long> reqIdsList) throws Exception;

	public List<Long> getSIARequestIDsList(List<String> siaRequestIdsList) throws Exception;

	public Map<String, Integer> getDistinctObjCountHANAS4OSMig(long requestId) throws Exception;

	public Map<String, Integer> getDistinctMandObjCountHANAS4OSMig(long requestId) throws Exception;

	public Map<String, Integer> getCommonImpactedObjCountHANAS4OSMig(long requestId) throws Exception;

	public Map<String, Integer> getCommonImpactedMandObjCountHANAS4OSMig(long requestId) throws Exception;

	public Map<String, Integer> getDistinctObjCountHANAS4(long requestId) throws Exception;

	public Map<String, Integer> getDistinctMandObjCountHANAS4(long requestId) throws Exception;

	public Map<String, Integer> getCommonImpactedObjCountHANAS4(long requestId) throws Exception;

	public Map<String, Integer> getCommonImpactedMandObjCountHANAS4(long requestId) throws Exception;

	public Map<String, Integer> getImpactedBackgroundJobCounts(long requestId) throws Exception;

	public Map<String, Integer> getObjCountOSMig(long requestId) throws Exception;

	public Map<String, Integer> getMandObjCountOSMig(long requestId) throws Exception;

	public Integer getLogCommandCountOSMig(long requestId) throws Exception;
	
	public Integer getLogFilePathCountOSMig(long requestId) throws Exception;
	
	public Map<String, Map<String, Map<String, Integer>>> getRemCatDescOSMigCounts(long requestId) throws Exception;

	public Map<String, Map<String, Integer>> getHANAS4ObjectErrorCounts(long requestId, String objTypeCol,
			String usedCol, String requestIdCol, String tableName) throws Exception;

	public Map<String, Map<String, Map<String, Integer>>> getS4RemCatIssueCatCounts(long requestId) throws Exception;

	public Map<String, Map<String, Integer>> getS4IssueCatCounts(long requestId) throws Exception;

	public Map<String, Integer> getHANAAutoStatusYCounts(long requestId) throws Exception;
	
	public Map<String, Integer> getExtNamespaceInventoryObjCounts(long requestId) throws Exception;

	public Map<String, Integer> getExtNamespaceMandObjCountHANAS4(long requestId, String tableName,
			String remCatColName, String usedColName) throws Exception;
	
	public Map<String, Integer> getCommonExtNamespaceImpactedObjCountHANAS4(long requestId) throws Exception;
	
	public Map<String, Integer> getCommonExtNamespaceImpactedMandObjCountHANAS4(long requestId) throws Exception;
	
	public Map<String, Integer> getExtNamespaceAUCTCounts(long requestId) throws Exception;

	public void saveReqMasterData(ProcessedRequestMaster processedReqMaster) throws Exception;

	public void saveReqMasterCountsData(List<ProcessedRMCounts> reqMasterCountsList) throws Exception;
	
	public Integer getNonUnicodeCounts(long requestId) throws Exception;
	
	public Integer getNonUnicodeExternalNamespaceCounts(long requestId) throws Exception;
	
	public List<ProcessedRequestMaster> getReqMasterData();
}
