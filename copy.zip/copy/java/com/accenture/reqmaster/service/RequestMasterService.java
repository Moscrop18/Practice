package com.accenture.reqmaster.service;

import java.util.List;

import com.accenture.master.ProcessedRequestMasterModel;

public interface RequestMasterService {
	public void getRequestMasterCounts(long requestId, List<String> siaReqIDsList) throws Exception;

	public List<ProcessedRequestMasterModel> getRequestMasterList();
}
