/*MODIFIED 
 *FOR Enhancement CR-1.0:-Update the automation_Status according to Sel_line-20/12/16 -monika.mishra
 *
 *CR-13.0:- New Output sheet implementation. -03/02/17 -monika.mishra
 *
 *CR-25.0- Few fields which will be moved to JAVA tool in HANA Profiler - 10/07/2017 - monika.mishra
 *
 *CR-29.0:- Shown CDS View on basis of tables column value -5/08/17 -monika.mishra
 *
 *CR-39.0:- Upload Consolidated file for HANA,S4,Consolidated -5/10/17 -monika.mishra
 **/

package com.accenture.constant;

import java.util.Arrays;
import java.util.List;

public class ST03HanaConstant {

	/*
	 *Populate ST03CustomObjects Column value
	 * ST03 Code not required
	*/
	//public static final String SQL1_2_3 = "insert into ST03CustomObjects(tCode,dialogSteps,requestID) select st.prog,CAST(sum(st.dialog) as string),st.requestID from SunBaseData st where st.requestID=:requestID and (st.prog  like 'Y%' or  st.prog  like  'Z%') group by st.prog,st.requestID";
	/*public static final String sql1="Insert into ST03CustomObjects(tCode) select distinct prog from SunBaseData where requestID=:requestID and (prog  like 'Y%' or  prog  like  'Z%')" ;
	public static final String sql2="update ST03CustomObjects set requestID=:requestID where requestID is null" ;
	public static final String sql3="UPDATE ST03CustomObjects t  set t.dialogSteps = (SELECT SUM(dialog) FROM SunBaseData WHERE prog = t.tCode and requestID=:requestID GROUP BY prog)";
	
	public static final String sql11="Update ST03CustomObjects t set  :monthColumnListValue=(select SUM(dialog) from (SELECT prog,SUM(dialog) dialog,monthYear FROM SunBaseData where requestID=:requestID GROUP BY prog,monthYear )  where monthYear=:monthYearListValue and prog=t.tCode and requestID=:requestID)";
	*/ 
	/*public static final String SQL_12_13_14 = "DELETE FROM ST03CustomObjects WHERE requestID=:requestID and (tCode  like '%[abcdefghijklmnopqrstuvwxyz]%' OR tCode LIKE '<%' OR LTRIM(RTRIM(tCode)) LIKE 'Y369%'	OR tCode LIKE 'zacat%' OR tCode LIKE 'Y_SCR_01%' OR tCode LIKE 'Y_FM_ALL%'    OR tCode LIKE 'Y369%'  OR tCode LIKE 'Y_SCR_01%'  OR tCode LIKE 'YCOMPLEX'  OR tCode LIKE 'YINP1'  OR tCode LIKE 'LY369%'  OR tCode LIKE 'SAPLY369%'  OR tCode LIKE 'YOUT1'  OR tCode LIKE 'YOUT2'  OR tCode LIKE 'YSCREENS'  OR tCode LIKE 'YtCodeS'  OR tCode LIKE 'Z_UNICODE_CHECK'  OR tCode LIKE 'YUB1'  OR tCode LIKE 'Y_BDC_01'  OR tCode LIKE 'Y_CLO_01'  OR tCode LIKE 'Y_OBJ_01'  OR tCode LIKE 'Y_WU_01'  OR tCode LIKE 'YSCR'  OR tCode LIKE 'Y_FM_ALL%'  OR tCode LIKE 'ZBDC_FNAM'  OR tCode LIKE 'ZTROBJ'  OR tCode LIKE 'ZCAMSTAB'  OR tCode LIKE 'ZFM01'  OR tCode LIKE 'ZIN01'  OR tCode LIKE 'ZACAT%' or tCode LIKE 'ZRICEFW%' OR UPPER(tCode) <> tCode)";
	
    public static final String sql4="UPDATE ST03Tstc SET tCode = LTRIM(RTRIM(tCode)),progName = LTRIM(RTRIM(progName)) where requestID=:requestID";
	public static final String sql5="UPDATE ST03Tstcp SET tCode = LTRIM(RTRIM(tCode)),parameter = LTRIM(RTRIM(parameter)) where requestID=:requestID";
	public static final String sql6="UPDATE ST03CustomObjects SET classification = 'TRAN' WHERE tCode IN (SELECT tCode FROM ST03Tstc where requestID=:requestID)  and requestID=:requestID" ;
	public static final String sql7="UPDATE ST03CustomObjects SET classification = 'PROG' WHERE classification IS NULL and requestID=:requestID";
	public static final String sql8="UPDATE ST03CustomObjects SET progName = tCode WHERE classification = 'PROG' and requestID=:requestID";
	//public static final String SQL_7_8=	"UPDATE ST03CustomObjects SET progName = tCode, classification = 'PROG' WHERE classification IS NULL and requestID=:requestID";
	public static final String sql9="UPDATE ST03CustomObjects t  SET t.progName = (SELECT progName FROM ST03Tstc WHERE tCode = t.tCode  and requestID=:requestID) WHERE t.progName IS NULL and t.requestID=:requestID";
	public static final String sql10="UPDATE ST03CustomObjects t SET t.progName = (SELECT parameter FROM ST03Tstcp WHERE tCode =t.tCode and requestID=:requestID) WHERE (t.progName IS NULL or t.progName='') and t.requestID=:requestID";
	
	
   
	*/
	/*public static final String sql12="DELETE FROM SunBaseData WHERE requestID=:requestID and prog  like '%[abcdefghijklmnopqrstuvwxyz]%'  OR prog LIKE '<%'";
	public static final String sql13="DELETE from SunBaseData where requestID=:requestID and (LTRIM(RTRIM(prog)) LIKE 'Y369%'	OR prog LIKE 'zacat%' OR prog LIKE 'Y_SCR_01%' OR prog LIKE 'Y_FM_ALL%'    OR prog LIKE 'Y369%'  OR prog LIKE 'Y_SCR_01%'  OR prog LIKE 'YCOMPLEX'  OR prog LIKE 'YINP1'  OR prog LIKE 'LY369%'  OR prog LIKE 'SAPLY369%'  OR prog LIKE 'YOUT1'  OR prog LIKE 'YOUT2'  OR prog LIKE 'YSCREENS'  OR prog LIKE 'YtCodeS'  OR prog LIKE 'Z_UNICODE_CHECK'  OR prog LIKE 'YUB1'  OR prog LIKE 'Y_BDC_01'  OR prog LIKE 'Y_CLO_01'  OR prog LIKE 'Y_OBJ_01'  OR prog LIKE 'Y_WU_01'  OR prog LIKE 'YSCR'  OR prog LIKE 'Y_FM_ALL%'  OR prog LIKE 'ZBDC_FNAM'  OR prog LIKE 'ZTROBJ'  OR prog LIKE 'ZCAMSTAB'  OR prog LIKE 'ZFM01'  OR prog LIKE 'ZIN01'  OR prog LIKE 'ZACAT%' or prog LIKE 'ZRICEFW%')";
	public static final String sql14="DELETE FROM SunBaseData WHERE requestID=:requestID and UPPER(prog) <> prog";
	*/
	
	
	
    //public static final String sql45="UPDATE ST03CustomObjects SET progName = tcode WHERE classification = 'TRAN' AND progName='' and requestID=:requestID"; 
    
    /*public static final String sql46="UPDATE ST03CustomObjects SET progClass = 'CUSTOM DIALOG POOL' WHERE progName LIKE 'SAPDZ%' OR progName LIKE 'SAPDY%' and requestID=:requestID";

    		public static final String sql47="UPDATE ST03CustomObjects SET progClass = 'CUSTOM FUNCTION POOL' WHERE progName LIKE 'SAPLZ%' OR progName LIKE 'SAPLY%' and requestID=:requestID";

    		public static final String sql48="UPDATE ST03CustomObjects SET progClass = 'CUSTOM MODULE POOL' WHERE progName LIKE 'SAPMZ%' OR progName LIKE 'SAPMY%' and requestID=:requestID";

    		public static final String sql49="UPDATE ST03CustomObjects SET progClass = 'CUSTOM SUBROUTINE POOL' WHERE progName LIKE 'SAPFZ%' OR progName LIKE 'SAPFY%' and requestID=:requestID";


    		public static final String sql50="UPDATE ST03CustomObjects SET progName = 'SAPLSETB',progClass = 'DATA BROWSER', defCan = 'No' WHERE progName LIKE 'SE16%' and requestID=:requestID";

    		public static final String sql51="UPDATE ST03CustomObjects SET progName = 'SAPMSVMA',progClass = 'TABLE MAINTENANCE',defCan = 'No' WHERE progName LIKE '/*SM31%' OR progName LIKE '/*SM30%' and requestID=:requestID";

    		public static final String sql52="UPDATE ST03CustomObjects SET progName = 'SAPMSVMA',progClass = 'VIEWCLUSTER MAINTENANCE CALL',defCan = 'No ' WHERE progName LIKE '/*SM34%' and requestID=:requestID";


    		public static final String sql53="UPDATE ST03CustomObjects SET progClass = 'CUSTOM PROGRAM' WHERE (progName  like 'Y%' or  progName  like  'Z%')  AND progClass IS NULL and requestID=:requestID";
    		public static final String sql54="UPDATE ST03CustomObjects SET progClass = 'CUSTOM PROGRAM' WHERE (progName  like 'Y%' or  progName  like  'Z%') AND progClass = 'BLANK TYPE' and requestID=:requestID";

    		public static final String sql55="UPDATE ST03CustomObjects SET progClass = 'STANDARD PROGRAM',defCan ='No' WHERE ( defCan IS NULL AND progClass IS NULL ) AND (progName NOT LIKE 'Y%' or  progName NOT LIKE  'Z%') and requestID=:requestID";




    		public static final String sql56="UPDATE ST03CustomObjects SET progName = SUBSTRING(progName,POSITION('D_SREPOVARI-EXTDREPORT' in progName),LENGTH(progName)-(POSITION('D_SREPOVARI-EXTDREPORT' in progName)-1)),progClass='ABAP QUERY',defCan = 'No' WHERE progName LIKE '%REPORTTYPE=AQ%' and requestID=:requestID";

    		public static final String sql57="UPDATE ST03CustomObjects SET progName = LEFT(SUBSTRING(progName,24,LENGTH(progName)-23),LOCATE(';',SUBSTRING(progName,24,LENGTH(progName)-23))-1) WHERE progClass ='ABAP QUERY' and requestID=:requestID";


    		public static final String sql58="UPDATE ST03CustomObjects SET progName = SUBSTRING(progName,POSITION('D_SREPOVARI-REPORT='in progName),LENGTH(progName)-(POSITION('D_SREPOVARI-REPORT='in progName)-1)),progClass ='BLANK TYPE' WHERE progName LIKE '%REPORTTYPE=;%' and requestID=:requestID";



    		public static final String sql59="UPDATE ST03CustomObjects SET progName = LEFT(SUBSTRING(progName,20,LENGTH(progName)-19),LOCATE(';',SUBSTRING(progName,20,LENGTH(progName)-19))-1) WHERE progClass ='BLANK TYPE' and requestID=:requestID";


    		public static final String sql60="UPDATE ST03CustomObjects SET defCan = 'No', progClass = 'STANDARD PROGRAM' where progClass ='BLANK TYPE' and (progName  like 'Y%' or  progName  like  'Z%') and requestID=:requestID";

    		public static final String sql61="UPDATE ST03CustomObjects SET progClass = 'CUSTOM PROGRAM' where progClass ='BLANK TYPE' and (progName  like 'Y%' or  progName  like  'Z%') and requestID=:requestID";



    		public static final String sql62="UPDATE ST03CustomObjects SET progName = SUBSTRING(progName,POSITION('D_SREPOVARI-EXTDREPORT=' in progName),LENGTH(progName)-(POSITION('D_SREPOVARI-EXTDREPORT=' in progName)-1)),progClass ='KE30 PROFITABILITY REPORT',defCan = 'No' WHERE progName LIKE '%REPORTTYPE=RE;%' and requestID=:requestID";




    		public static final String sql63="UPDATE ST03CustomObjects SET progName = LEFT(SUBSTRING(progName,24,LENGTH(progName)-23),LOCATE(';',SUBSTRING(progName,24,LENGTH(progName)-23))-1) WHERE progClass ='KE30 PROFITABILITY REPORT' and requestID=:requestID";


    		public static final String sql64="UPDATE ST03CustomObjects SET progName = SUBSTRING(progName,POSITION('D_SREPOVARI-REPORT=' in progName),LENGTH(progName)-(POSITION('D_SREPOVARI-REPORT=' in progName)-1)),progClass ='REPORT WRITER',defCan = 'No' WHERE progName LIKE '%REPORTTYPE=RW;%' and requestID=:requestID";

    		public static final String sql65="UPDATE ST03CustomObjects SET progName = LEFT(SUBSTRING(progName,20,LENGTH(progName)-19),LOCATE(';',SUBSTRING(progName,20,LENGTH(progName)-19))-1) WHERE progClass = 'REPORT WRITER' and requestID=:requestID";



    		public static final String sql66="UPDATE ST03CustomObjects SET progClass = 'ABAP QUERY',defCan = 'No' WHERE progName LIKE 'AQ%' and requestID=:requestID";


    		public static final String sql67="UPDATE ST03CustomObjects SET progName = LEFT(SUBSTRING(progName,3,LENGTH(progName)-2),LOCATE(' ',(SUBSTRING(progName,3,LENGTH(progName)-2)))), progClass = 'LATER'  WHERE LOCATE(' ',(SUBSTRING(progName,3,LENGTH(progName)-2))) != 0 and (progName LIKE '/*Y%' OR progName LIKE '/*Z%') and requestID=:requestID";

    		public static final String sql68="UPDATE ST03CustomObjects SET progName = LEFT(SUBSTRING(progName,3,LENGTH(progName)-2),LENGTH(progName)-2), progClass = 'LATER'  WHERE LOCATE(' ',(SUBSTRING(progName,3,LENGTH(progName)-2))) = 0 and (progName LIKE '/*Y%' OR progName LIKE '/*Z%') and requestID=:requestID";

    		public static final String sql69="UPDATE ST03CustomObjects SET progName = LTRIM(RTRIM(progName)) where requestID=:requestID";

    		public static final String sql70="UPDATE ST03CustomObjects SET progName = (SELECT progName FROM ST03Tstc WHERE TCODE = ST03CustomObjects.progName) WHERE progClass = 'LATER' and requestID=:requestID";

    		public static final String sql71="UPDATE ST03CustomObjects SET progClass = 'CUSTOM PROGRAM' WHERE progClass = 'LATER' and progName IS NOT NULL and requestID=:requestID";
    		public static final String sql72="UPDATE ST03CustomObjects SET progClass = 'THIRD PARTY' , defCan = 'No' WHERE progClass = 'LATER' and progName IS NULL and requestID=:requestID";

    		public static final String sql73="UPDATE ST03CustomObjects SET  progClass = 'LATER1' WHERE progName LIKE '/*%' AND progName NOT LIKE '/*Y%' AND progName NOT LIKE '/*Z%' AND progName NOT LIKE '/*SM%' and requestID=:requestID";


    		public static final String sql74="UPDATE ST03CustomObjects SET progName = LEFT(SUBSTRING(progName,3,LENGTH(progName)-2),LOCATE(' ',(SUBSTRING(progName,3,LENGTH(progName)-2)))) WHERE LOCATE(' ',(SUBSTRING(progName,3,LENGTH(progName)-2))) != 0 and progClass = 'LATER1' and requestID=:requestID";

    		public static final String sql75="UPDATE ST03CustomObjects SET progName = LEFT(SUBSTRING(progName,3,LENGTH(progName)-2),LENGTH(progName)-2) WHERE LOCATE(' ',(SUBSTRING(progName,3,LENGTH(progName)-2))) = 0 and progClass = 'LATER1' and requestID=:requestID";



    		public static final String sql76="UPDATE ST03CustomObjects SET progName = LTRIM(RTRIM(progName)) where requestID=:requestID";

    		public static final String sql77="UPDATE ST03CustomObjects SET defCan = 'No' , progClass = 'VENDOR PROGRAM' WHERE progName IS NULL and requestID=:requestID";;

    		need to check with vrishti

    		public static final String sql78="UPDATE ST03CustomObjects SET progName = (SELECT pgmna FROM TSTC_46 WHERE TCODE = ST03CustomObjects.progName), progClass = (select description from tstc_46 where TCODE = ST03CustomObjects.progName), defCan = 'No' WHERE progClass = 'LATER1' and requestID=:requestID";

    		




    		public static final String sql79="UPDATE ST03CustomObjects SET progClass = 'slash n' WHERE progName LIKE '/N%' AND progName NOT LIKE '/N/%' and requestID=:requestID";


    		public static final String sql80="UPDATE ST03CustomObjects SET progName = LEFT(SUBSTRING(progName,3,LENGTH(progName)-2),LENGTH(progName)-2) WHERE LOCATE(' ',(SUBSTRING(progName,3,LENGTH(progName)-2))) = 0 and progClass = 'slash n' and requestID=:requestID";
    		 
    		public static final String sql81="UPDATE ST03CustomObjects SET progName = LEFT(SUBSTRING(progName,3,LENGTH(progName)-2),LOCATE(' ',(SUBSTRING(progName,3,LENGTH(progName)-2)))) WHERE LOCATE(' ',(SUBSTRING(progName,3,LENGTH(progName)-2))) != 0 and progClass = 'slash n'  and requestID=:requestID";

    		public static final String sql82="UPDATE ST03CustomObjects SET progName = LTRIM(RTRIM(progName)) where requestID=:requestID";

    		need to check with vrishti
    		public static final String sql83="UPDATE ST03CustomObjects SET progName = (SELECT pgmna FROM TSTC_46 WHERE TCODE = ST03CustomObjects.progName), progClass = (select description from tstc_46 where TCODE = ST03CustomObjects.progName), defCan = 'No' WHERE progClass = 'slash n' and requestID=:requestID";
    		



    		public static final String sql84="UPDATE ST03CustomObjects SET progName = SUBSTRING(progName,2,LENGTH(progName)-1) , progClass = 'LITTLE ABSURD' WHERE progName LIKE '@%' and requestID=:requestID";

    		public static final String sql85="UPDATE ST03CustomObjects SET progName = SUBSTRING(progName,3,LENGTH(progName)-2) , progClass = 'ABSURD' WHERE progName LIKE '@@%' and requestID=:requestID";

    		public static final String sql86="UPDATE ST03CustomObjects SET progClass = 'STANDARD PROGRAM' where defCan ='No' and progClass is null and requestID=:requestID";

    		public static final String sql87="UPDATE ST03CustomObjects SET progClass = 'STANDARD PROGRAM',defCan ='No' WHERE ( defCan IS NULL AND progClass IS NULL ) AND (progName  not like 'Y%' or  progName not like  'Z%') and requestID=:requestID";
        	need to check with vrishti

    		public static final String sql88="UPDATE ST03CustomObjects SET defCan = (select DEFECTIVE_CAN from UBINVENTORY_SHEET where OBJECT_NAME = ST03CustomObjects.progName and OBJECT_TYPE = 'PROG' ) where defCan is NULL and 

    		progClass like 'CUSTOM%' and requestID=:requestID";

    		
	       public static final String sql89="UPDATE ST03CustomObjects SET progName = SUBSTRING(progName,5,LENGTH(progName)-4) where progName like 'SAPL%' and defCan is NULL and progClass like 'CUSTOM%' and requestID=:requestID";

    		need to check with vrishti

    		public static final String sql90="UPDATE ST03CustomObjects SET defCan = (select DEFECTIVE_CAN from UBINVENTORY_SHEET where OBJECT_NAME = ST03CustomObjects.progName and OBJECT_TYPE = 'FUGR' ) where defCan is NULL and 

    		progClass = 'CUSTOM FUNCTION POOL' and requestID=:requestID";;
    		
         	public static final String sql91="UPDATE ST03CustomObjects SET defCan = 'Unknown' where defCan is NULL and requestID=:requestID";;



    		public static final String sql92="UPDATE  ST03CustomObjects SET progName = 'SAPL'+progName where progClass = 'CUSTOM FUNCTION POOL' and requestID=:requestID";
    		
    		*/
    
    //public static final String sql46="UPDATE ST03_CUSTOM_OBJECTS SET PROG_CLASS = 'CUSTOM DIALOG POOL' WHERE PROG_NAME LIKE 'SAPDZ%' OR PROG_NAME LIKE 'SAPDY%' and REQUEST_ID=:REQUEST_ID";
  /*  public static final String sql46_hql="UPDATE ST03CustomObjects SET progClass = 'CUSTOM DIALOG POOL' WHERE (progName LIKE 'SAPDZ%' OR progName LIKE 'SAPDY%') and requestID=:requestID";

	//public static final String sql47="UPDATE ST03_CUSTOM_OBJECTS SET PROG_CLASS = 'CUSTOM FUNCTION POOL' WHERE PROG_NAME LIKE 'SAPLZ%' OR PROG_NAME LIKE 'SAPLY%' and REQUEST_ID=:REQUEST_ID";
    public static final String sql47_hql="UPDATE ST03CustomObjects SET progClass = 'CUSTOM FUNCTION POOL' WHERE (progName LIKE 'SAPLZ%' OR progName LIKE 'SAPLY%') and requestID=:requestID";

	//public static final String sql48="UPDATE ST03_CUSTOM_OBJECTS SET PROG_CLASS = 'CUSTOM MODULE POOL' WHERE PROG_NAME LIKE 'SAPMZ%' OR PROG_NAME LIKE 'SAPMY%' and REQUEST_ID=:REQUEST_ID";
    public static final String sql48_hql="UPDATE ST03CustomObjects SET progClass = 'CUSTOM MODULE POOL' WHERE (progName LIKE 'SAPMZ%' OR progName LIKE 'SAPMY%') and requestID=:requestID";

	//public static final String sql49="UPDATE ST03_CUSTOM_OBJECTS SET PROG_CLASS = 'CUSTOM SUBROUTINE POOL' WHERE PROG_NAME LIKE 'SAPFZ%' OR PROG_NAME LIKE 'SAPFY%' and REQUEST_ID=:REQUEST_ID";
    public static final String sql49_hql="UPDATE ST03CustomObjects SET progClass = 'CUSTOM SUBROUTINE POOL' WHERE (progName LIKE 'SAPFZ%' OR progName LIKE 'SAPFY%') and requestID=:requestID";


	//public static final String sql50="UPDATE ST03_CUSTOM_OBJECTS SET PROG_NAME = 'SAPLSETB',PROG_CLASS = 'DATA BROWSER', DEF_CAN = 'No' WHERE PROG_NAME LIKE 'SE16%' and REQUEST_ID=:REQUEST_ID";
    public static final String sql50_hql="UPDATE ST03CustomObjects SET progName = 'SAPLSETB',progClass = 'DATA BROWSER', defCan = 'No' WHERE progName LIKE 'SE16%' and requestID=:requestID";

	//public static final String sql51="UPDATE ST03_CUSTOM_OBJECTS SET PROG_NAME = 'SAPMSVMA',PROG_CLASS = 'TABLE MAINTENANCE',DEF_CAN = 'No' WHERE PROG_NAME LIKE '/*SM31%' OR PROG_NAME LIKE '/*SM30%' and REQUEST_ID=:REQUEST_ID";
    public static final String sql51_hql="UPDATE ST03CustomObjects SET progName = 'SAPMSVMA',progClass = 'TABLE MAINTENANCE',defCan = 'No' WHERE (progName LIKE '/*SM31%' OR progName LIKE '/*SM30%') and requestID=:requestID";

	//public static final String sql52="UPDATE ST03_CUSTOM_OBJECTS SET PROG_NAME = 'SAPMSVMA',PROG_CLASS = 'VIEWCLUSTER MAINTENANCE CALL',DEF_CAN = 'No ' WHERE PROG_NAME LIKE '/*SM34%' and REQUEST_ID=:REQUEST_ID";
    public static final String sql52_hql="UPDATE ST03CustomObjects SET progName = 'SAPMSVMA',progClass = 'VIEWCLUSTER MAINTENANCE CALL',defCan = 'No ' WHERE progName LIKE '/*SM34%' and requestID=:requestID";


	//public static final String sql53="UPDATE ST03_CUSTOM_OBJECTS SET PROG_CLASS = 'CUSTOM PROGRAM' WHERE (PROG_NAME  like 'Y%' or  PROG_NAME  like  'Z%')  AND PROG_CLASS IS NULL and REQUEST_ID=:REQUEST_ID";
    public static final String sql53_hql="UPDATE ST03CustomObjects SET progClass = 'CUSTOM PROGRAM' WHERE (progName  like 'Y%' or  progName  like  'Z%')  AND progClass IS NULL and requestID=:requestID";
	//public static final String sql54="UPDATE ST03_CUSTOM_OBJECTS SET PROG_CLASS = 'CUSTOM PROGRAM' WHERE (PROG_NAME  like 'Y%' or  PROG_NAME  like  'Z%') AND PROG_CLASS = 'BLANK TYPE' and REQUEST_ID=:REQUEST_ID";
    public static final String sql54_hql="UPDATE ST03CustomObjects SET progClass = 'CUSTOM PROGRAM' WHERE (progName  like 'Y%' or  progName  like  'Z%') AND progClass = 'BLANK TYPE' and requestID=:requestID";

	//public static final String sql55="UPDATE ST03_CUSTOM_OBJECTS SET PROG_CLASS = 'STANDARD PROGRAM',DEF_CAN ='No' WHERE ( DEF_CAN IS NULL AND PROG_CLASS IS NULL ) AND (PROG_NAME NOT LIKE 'Y%' or  PROG_NAME NOT LIKE  'Z%') and REQUEST_ID=:REQUEST_ID";
    public static final String sql55_hql="UPDATE ST03CustomObjects SET progClass = 'STANDARD PROGRAM',defCan ='No' WHERE ( defCan IS NULL AND progClass IS NULL ) AND (progName NOT LIKE 'Y%' or  progName NOT LIKE  'Z%') and requestID=:requestID";




	//public static final String sql56="UPDATE ST03_CUSTOM_OBJECTS SET PROG_NAME = SUBSTRING(PROG_NAME,POSITION('D_SREPOVARI-EXTDREPORT' in PROG_NAME),LENGTH(PROG_NAME)-(POSITION('D_SREPOVARI-EXTDREPORT' in PROG_NAME)-1)),PROG_CLASS='ABAP QUERY',DEF_CAN = 'No' WHERE PROG_NAME LIKE '%REPORTTYPE=AQ%' and REQUEST_ID=:REQUEST_ID";
    public static final String sql56_hql="UPDATE ST03CustomObjects SET progName = SUBSTRING(progName,LOCATE('D_SREPOVARI-EXTDREPORT',progName),LENGTH(progName)-(LOCATE('D_SREPOVARI-EXTDREPORT',progName)-1)),progClass='ABAP QUERY',defCan = 'No' WHERE progName LIKE '%REPORTTYPE=AQ%' and requestID=:requestID";

	
	
	//public static final String sql57="UPDATE ST03_CUSTOM_OBJECTS SET PROG_NAME = LEFT(SUBSTRING(PROG_NAME,24,LENGTH(PROG_NAME)-23),LOCATE(';',SUBSTRING(PROG_NAME,24,LENGTH(PROG_NAME)-23))-1) WHERE PROG_CLASS ='ABAP QUERY' and REQUEST_ID=:REQUEST_ID";
    public static final String sql57_hql="UPDATE ST03CustomObjects SET progName = SUBSTRING(SUBSTRING(progName,24,LENGTH(progName)-23),1,LOCATE(';',SUBSTRING(progName,24,LENGTH(progName)-23))-1) WHERE progClass ='ABAP QUERY' and requestID=:requestID";


	//public static final String sql58="UPDATE ST03_CUSTOM_OBJECTS SET PROG_NAME = SUBSTRING(PROG_NAME,POSITION('D_SREPOVARI-REPORT='in PROG_NAME),LENGTH(PROG_NAME)-(POSITION('D_SREPOVARI-REPORT='in PROG_NAME)-1)),PROG_CLASS ='BLANK TYPE' WHERE PROG_NAME LIKE '%REPORTTYPE=;%' and REQUEST_ID=:REQUEST_ID";
    public static final String sql58_hql="UPDATE ST03CustomObjects SET progName = SUBSTRING(progName,LOCATE('D_SREPOVARI-REPORT=', progName),LENGTH(progName)-(LOCATE('D_SREPOVARI-REPORT=',progName)-1)),progClass ='BLANK TYPE' WHERE progName LIKE '%REPORTTYPE=;%' and requestID=:requestID";



	//public static final String sql59="UPDATE ST03_CUSTOM_OBJECTS SET PROG_NAME = LEFT(SUBSTRING(PROG_NAME,20,LENGTH(PROG_NAME)-19),LOCATE(';',SUBSTRING(PROG_NAME,20,LENGTH(PROG_NAME)-19))-1) WHERE PROG_CLASS ='BLANK TYPE' and REQUEST_ID=:REQUEST_ID";
    public static final String sql59_hql="UPDATE ST03CustomObjects SET progName = SUBSTRING(SUBSTRING(progName,20,LENGTH(progName)-19),1,LOCATE(';',SUBSTRING(progName,20,LENGTH(progName)-19))-1) WHERE progClass ='BLANK TYPE' and requestID=:requestID";


	//public static final String sql60="UPDATE ST03_CUSTOM_OBJECTS SET DEF_CAN = 'No', PROG_CLASS = 'STANDARD PROGRAM' where PROG_CLASS ='BLANK TYPE' and (PROG_NAME  like 'Y%' or  PROG_NAME  like  'Z%') and REQUEST_ID=:REQUEST_ID";
    public static final String sql60_hql="UPDATE ST03CustomObjects SET defCan = 'No', progClass = 'STANDARD PROGRAM' where progClass ='BLANK TYPE' and (progName  NOT LIKE 'Y%' and progName  NOT LIKE 'Z%') and requestID=:requestID";

	//public static final String sql61="UPDATE ST03_CUSTOM_OBJECTS SET PROG_CLASS = 'CUSTOM PROGRAM' where PROG_CLASS ='BLANK TYPE' and (PROG_NAME  like 'Y%' or  PROG_NAME  like  'Z%') and REQUEST_ID=:REQUEST_ID";
    public static final String sql61_hql="UPDATE ST03CustomObjects SET progClass = 'CUSTOM PROGRAM' where progClass ='BLANK TYPE' and (progName  like 'Y%' or  progName  like  'Z%') and requestID=:requestID";



	//public static final String sql62="UPDATE ST03_CUSTOM_OBJECTS SET PROG_NAME = SUBSTRING(PROG_NAME,POSITION('D_SREPOVARI-EXTDREPORT=' in PROG_NAME),LENGTH(PROG_NAME)-(POSITION('D_SREPOVARI-EXTDREPORT=' in PROG_NAME)-1)),PROG_CLASS ='KE30 PROFITABILITY REPORT',DEF_CAN = 'No' WHERE PROG_NAME LIKE '%REPORTTYPE=RE;%' and REQUEST_ID=:REQUEST_ID";
    public static final String sql62_hql="UPDATE ST03CustomObjects SET progName = SUBSTRING(progName,LOCATE('D_SREPOVARI-EXTDREPORT=',progName),LENGTH(progName)-(LOCATE('D_SREPOVARI-EXTDREPORT=',progName)-1)),progClass ='KE30 PROFITABILITY REPORT',defCan = 'No' WHERE progName LIKE '%REPORTTYPE=RE;%' and requestID=:requestID";




	//public static final String sql63="UPDATE ST03_CUSTOM_OBJECTS SET PROG_NAME = LEFT(SUBSTRING(PROG_NAME,24,LENGTH(PROG_NAME)-23),LOCATE(';',SUBSTRING(PROG_NAME,24,LENGTH(PROG_NAME)-23))-1) WHERE PROG_CLASS ='KE30 PROFITABILITY REPORT' and REQUEST_ID=:REQUEST_ID";
    public static final String sql63_hql="UPDATE ST03CustomObjects SET progName = SUBSTRING(SUBSTRING(progName,24,LENGTH(progName)-23),1,LOCATE(';',SUBSTRING(progName,24,LENGTH(progName)-23))-1) WHERE progClass ='KE30 PROFITABILITY REPORT' and requestID=:requestID";


	//public static final String sql64="UPDATE ST03_CUSTOM_OBJECTS SET PROG_NAME = SUBSTRING(PROG_NAME,POSITION('D_SREPOVARI-REPORT=' in PROG_NAME),LENGTH(PROG_NAME)-(POSITION('D_SREPOVARI-REPORT=' in PROG_NAME)-1)),PROG_CLASS ='REPORT WRITER',DEF_CAN = 'No' WHERE PROG_NAME LIKE '%REPORTTYPE=RW;%' and REQUEST_ID=:REQUEST_ID";
	public static final String sql64_hql="UPDATE ST03CustomObjects SET progName = SUBSTRING(progName,LOCATE('D_SREPOVARI-REPORT=' , progName),LENGTH(progName)-(LOCATE('D_SREPOVARI-REPORT=' , progName)-1)),progClass ='REPORT WRITER',defCan = 'No' WHERE progName LIKE '%REPORTTYPE=RW;%' and requestID=:requestID";

	//public static final String sql65="UPDATE ST03_CUSTOM_OBJECTS SET PROG_NAME = LEFT(SUBSTRING(PROG_NAME,20,LENGTH(PROG_NAME)-19),LOCATE(';',SUBSTRING(PROG_NAME,20,LENGTH(PROG_NAME)-19))-1) WHERE PROG_CLASS = 'REPORT WRITER' and REQUEST_ID=:REQUEST_ID";
	public static final String sql65_hql="UPDATE ST03CustomObjects SET progName = SUBSTRING(SUBSTRING(progName,20,LENGTH(progName)-19),1,LOCATE(';',SUBSTRING(progName,20,LENGTH(progName)-19))-1) WHERE progClass = 'REPORT WRITER' and requestID=:requestID";



	//public static final String sql66="UPDATE ST03_CUSTOM_OBJECTS SET PROG_CLASS = 'ABAP QUERY',DEF_CAN = 'No' WHERE PROG_NAME LIKE 'AQ%' and REQUEST_ID=:REQUEST_ID";
	public static final String sql66_hql="UPDATE ST03CustomObjects SET progClass = 'ABAP QUERY',defCan = 'No' WHERE progName LIKE 'AQ%' and requestID=:requestID";


	//public static final String sql67="UPDATE ST03_CUSTOM_OBJECTS SET PROG_NAME = LEFT(SUBSTRING(PROG_NAME,3,LENGTH(PROG_NAME)-2),LOCATE(' ',(SUBSTRING(PROG_NAME,3,LENGTH(PROG_NAME)-2)))), PROG_CLASS = 'LATER'  WHERE LOCATE(' ',(SUBSTRING(PROG_NAME,3,LENGTH(PROG_NAME)-2))) != 0 and (PROG_NAME LIKE '/*Y%' OR PROG_NAME LIKE '/*Z%') and REQUEST_ID=:REQUEST_ID";
	public static final String sql67_hql="UPDATE ST03CustomObjects SET progName = SUBSTRING(SUBSTRING(progName,3,LENGTH(progName)-2),1,LOCATE(' ',(SUBSTRING(progName,3,LENGTH(progName)-2)))), progClass = 'LATER'  WHERE LOCATE(' ',(SUBSTRING(progName,3,LENGTH(progName)-2))) != 0 and (progName LIKE '/*Y%' OR progName LIKE '/*Z%') and requestID=:requestID";

	//public static final String sql68="UPDATE ST03_CUSTOM_OBJECTS SET PROG_NAME = LEFT(SUBSTRING(PROG_NAME,3,LENGTH(PROG_NAME)-2),LENGTH(PROG_NAME)-2), PROG_CLASS = 'LATER'  WHERE LOCATE(' ',(SUBSTRING(PROG_NAME,3,LENGTH(PROG_NAME)-2))) = 0 and (PROG_NAME LIKE '/*Y%' OR PROG_NAME LIKE '/*Z%') and REQUEST_ID=:REQUEST_ID";
	public static final String sql68_hql="UPDATE ST03CustomObjects SET progName = SUBSTRING(SUBSTRING(progName,3,LENGTH(progName)-2),1,LENGTH(progName)-2), progClass = 'LATER'  WHERE LOCATE(' ',(SUBSTRING(progName,3,LENGTH(progName)-2))) = 0 and (progName LIKE '/*Y%' OR progName LIKE '/*Z%') and requestID=:requestID";

	//public static final String sql69="UPDATE ST03_CUSTOM_OBJECTS SET PROG_NAME = LTRIM(RTRIM(PROG_NAME)) where REQUEST_ID=:REQUEST_ID";
	public static final String sql69_hql="UPDATE ST03CustomObjects SET progName = LTRIM(RTRIM(progName)) where requestID=:requestID";

	//public static final String sql70="UPDATE ST03_CUSTOM_OBJECTS SET PROG_NAME = (SELECT PROG_NAME FROM ST03_TSTC WHERE TCODE = ST03_CUSTOM_OBJECTS.PROG_NAME) WHERE PROG_CLASS = 'LATER' and REQUEST_ID=:REQUEST_ID";
	public static final String sql70_hql="UPDATE ST03CustomObjects t SET progName = (SELECT progName FROM ST03Tstc WHERE tCode = t.progName and requestID=:requestID) WHERE progClass = 'LATER' and requestID=:requestID";

	//public static final String sql71="UPDATE ST03_CUSTOM_OBJECTS SET PROG_CLASS = 'CUSTOM PROGRAM' WHERE PROG_CLASS = 'LATER' and PROG_NAME IS NOT NULL and REQUEST_ID=:REQUEST_ID";
	public static final String sql71_hql="UPDATE ST03CustomObjects SET progClass = 'CUSTOM PROGRAM' WHERE progClass = 'LATER' and progName IS NOT NULL and requestID=:requestID";
	
	//public static final String sql72="UPDATE ST03_CUSTOM_OBJECTS SET PROG_CLASS = 'THIRD PARTY' , DEF_CAN = 'No' WHERE PROG_CLASS = 'LATER' and PROG_NAME IS NULL and REQUEST_ID=:REQUEST_ID";
	public static final String sql72_hql="UPDATE ST03CustomObjects SET progClass = 'THIRD PARTY' , defCan = 'No' WHERE progClass = 'LATER' and progName IS NULL and requestID=:requestID";

	//public static final String sql73="UPDATE ST03_CUSTOM_OBJECTS SET  PROG_CLASS = 'LATER1' WHERE PROG_NAME LIKE '/*%' AND PROG_NAME NOT LIKE '/*Y%' AND PROG_NAME NOT LIKE '/*Z%' AND PROG_NAME NOT LIKE '/*SM%' and REQUEST_ID=:REQUEST_ID";
	public static final String sql73_hql="UPDATE ST03CustomObjects SET  progClass = 'LATER1' WHERE progName LIKE '/*%' AND progName NOT LIKE '/*Y%' AND progName NOT LIKE '/*Z%' AND progName NOT LIKE '/*SM%' and requestID=:requestID";


	//public static final String sql74="UPDATE ST03_CUSTOM_OBJECTS SET PROG_NAME = LEFT(SUBSTRING(PROG_NAME,3,LENGTH(PROG_NAME)-2),LOCATE(' ',(SUBSTRING(PROG_NAME,3,LENGTH(PROG_NAME)-2)))) WHERE LOCATE(' ',(SUBSTRING(PROG_NAME,3,LENGTH(PROG_NAME)-2))) != 0 and PROG_CLASS = 'LATER1' and REQUEST_ID=:REQUEST_ID";
	public static final String sql74_hql="UPDATE ST03CustomObjects SET progName = SUBSTRING(SUBSTRING(progName,3,LENGTH(progName)-2),1,LOCATE(' ',(SUBSTRING(progName,3,LENGTH(progName)-2)))) WHERE LOCATE(' ',(SUBSTRING(progName,3,LENGTH(progName)-2))) != 0 and progClass = 'LATER1' and requestID=:requestID";

	//public static final String sql75="UPDATE ST03_CUSTOM_OBJECTS SET PROG_NAME = LEFT(SUBSTRING(PROG_NAME,3,LENGTH(PROG_NAME)-2),LENGTH(PROG_NAME)-2) WHERE LOCATE(' ',(SUBSTRING(PROG_NAME,3,LENGTH(PROG_NAME)-2))) = 0 and PROG_CLASS = 'LATER1' and REQUEST_ID=:REQUEST_ID";
	public static final String sql75_hql="UPDATE ST03CustomObjects SET progName = SUBSTRING(SUBSTRING(progName,3,LENGTH(progName)-2),1,LENGTH(progName)-2) WHERE LOCATE(' ',(SUBSTRING(progName,3,LENGTH(progName)-2))) = 0 and progClass = 'LATER1' and requestID=:requestID";



	//public static final String sql76="UPDATE ST03_CUSTOM_OBJECTS SET PROG_NAME = LTRIM(RTRIM(PROG_NAME)) where REQUEST_ID=:REQUEST_ID";
	public static final String sql76_hql="UPDATE ST03CustomObjects SET progName = LTRIM(RTRIM(progName)) where requestID=:requestID";

	//public static final String sql77="UPDATE ST03_CUSTOM_OBJECTS SET DEF_CAN = 'No' , PROG_CLASS = 'VENDOR PROGRAM' WHERE PROG_NAME IS NULL and REQUEST_ID=:REQUEST_ID";;
	public static final String sql77_hql="UPDATE ST03CustomObjects SET defCan = 'No' , progClass = 'VENDOR PROGRAM' WHERE progName IS NULL and requestID=:requestID";

	//need to check with vrishti

	//public static final String sql78="UPDATE ST03_CUSTOM_OBJECTS SET PROG_NAME = (SELECT pgmna FROM TSTC_46 WHERE TCODE = ST03_CUSTOM_OBJECTS.PROG_NAME), PROG_CLASS = (select description from tstc_46 where TCODE = ST03_CUSTOM_OBJECTS.PROG_NAME), DEF_CAN = 'No' WHERE PROG_CLASS = 'LATER1' and REQUEST_ID=:REQUEST_ID";
	public static final String sql78_hql="UPDATE ST03CustomObjects t SET progName = (SELECT pgmna FROM Tstc_46 WHERE tCode = t.progName), progClass = (select description from Tstc_46 where tCode = t.progName), defCan = 'No' WHERE progClass = 'LATER1' and requestID=:requestID";





	//public static final String sql79="UPDATE ST03_CUSTOM_OBJECTS SET PROG_CLASS = 'slash n' WHERE PROG_NAME LIKE '/N%' AND PROG_NAME NOT LIKE '/N/%' and REQUEST_ID=:REQUEST_ID";
	public static final String sql79_hql="UPDATE ST03CustomObjects SET progClass = 'slash n' WHERE progName LIKE '/N%' AND progName NOT LIKE '/N/%' and requestID=:requestID";


	//public static final String sql80="UPDATE ST03_CUSTOM_OBJECTS SET PROG_NAME = LEFT(SUBSTRING(PROG_NAME,3,LENGTH(PROG_NAME)-2),LENGTH(PROG_NAME)-2) WHERE LOCATE(' ',(SUBSTRING(PROG_NAME,3,LENGTH(PROG_NAME)-2))) = 0 and PROG_CLASS = 'slash n' and REQUEST_ID=:REQUEST_ID";
	public static final String sql80_hql="UPDATE ST03CustomObjects SET progName = SUBSTRING(SUBSTRING(progName,3,LENGTH(progName)-2),1,LENGTH(progName)-2) WHERE LOCATE(' ',(SUBSTRING(progName,3,LENGTH(progName)-2))) = 0 and progClass = 'slash n' and requestID=:requestID";
	 
	//public static final String sql81="UPDATE ST03_CUSTOM_OBJECTS SET PROG_NAME = LEFT(SUBSTRING(PROG_NAME,3,LENGTH(PROG_NAME)-2),LOCATE(' ',(SUBSTRING(PROG_NAME,3,LENGTH(PROG_NAME)-2)))) WHERE LOCATE(' ',(SUBSTRING(PROG_NAME,3,LENGTH(PROG_NAME)-2))) != 0 and PROG_CLASS = 'slash n'  and REQUEST_ID=:REQUEST_ID";
	public static final String sql81_hql="UPDATE ST03CustomObjects SET progName = SUBSTRING(SUBSTRING(progName,3,LENGTH(progName)-2),1,LOCATE(' ',(SUBSTRING(progName,3,LENGTH(progName)-2)))) WHERE LOCATE(' ',(SUBSTRING(progName,3,LENGTH(progName)-2))) != 0 and progClass = 'slash n'  and requestID=:requestID";

	//public static final String sql82="UPDATE ST03_CUSTOM_OBJECTS SET PROG_NAME = LTRIM(RTRIM(PROG_NAME)) where REQUEST_ID=:REQUEST_ID";
	public static final String sql82_hql="UPDATE ST03CustomObjects SET progName = LTRIM(RTRIM(progName)) where requestID=:requestID";

	//need to check with vrishti
	//public static final String sql83="UPDATE ST03_CUSTOM_OBJECTS SET PROG_NAME = (SELECT pgmna FROM TSTC_46 WHERE TCODE = ST03_CUSTOM_OBJECTS.PROG_NAME), PROG_CLASS = (select description from tstc_46 where TCODE = ST03_CUSTOM_OBJECTS.PROG_NAME), DEF_CAN = 'No' WHERE PROG_CLASS = 'slash n' and REQUEST_ID=:REQUEST_ID";
	public static final String sql83_hql="UPDATE ST03CustomObjects t SET progName = (SELECT pgmna FROM Tstc_46 WHERE tCode = t.progName), progClass = (select description from Tstc_46 where tCode = t.progName), defCan = 'No' WHERE progClass = 'slash n' and requestID=:requestID";
	



	//public static final String sql84="UPDATE ST03_CUSTOM_OBJECTS SET PROG_NAME = SUBSTRING(PROG_NAME,2,LENGTH(PROG_NAME)-1) , PROG_CLASS = 'LITTLE ABSURD' WHERE PROG_NAME LIKE '@%' and REQUEST_ID=:REQUEST_ID";
	public static final String sql84_hql="UPDATE ST03CustomObjects SET progName = SUBSTRING(progName,2,LENGTH(progName)-1) , progClass = 'LITTLE ABSURD' WHERE progName LIKE '@%' and requestID=:requestID";

	//public static final String sql85="UPDATE ST03_CUSTOM_OBJECTS SET PROG_NAME = SUBSTRING(PROG_NAME,3,LENGTH(PROG_NAME)-2) , PROG_CLASS = 'ABSURD' WHERE PROG_NAME LIKE '@@%' and REQUEST_ID=:REQUEST_ID";
	public static final String sql85_hql="UPDATE ST03CustomObjects SET progName = SUBSTRING(progName,3,LENGTH(progName)-2) , progClass = 'ABSURD' WHERE progName LIKE '@@%' and requestID=:requestID";

	//public static final String sql86="UPDATE ST03_CUSTOM_OBJECTS SET PROG_CLASS = 'STANDARD PROGRAM' where DEF_CAN ='No' and PROG_CLASS is null and REQUEST_ID=:REQUEST_ID";
	public static final String sql86_hql="UPDATE ST03CustomObjects SET progClass = 'STANDARD PROGRAM' where defCan ='No' and progClass is null and requestID=:requestID";

	//public static final String sql87="UPDATE ST03_CUSTOM_OBJECTS SET PROG_CLASS = 'STANDARD PROGRAM',DEF_CAN ='No' WHERE ( DEF_CAN IS NULL AND PROG_CLASS IS NULL ) AND (PROG_NAME  not like 'Y%' or  PROG_NAME not like  'Z%') and REQUEST_ID=:REQUEST_ID";
	public static final String sql87_hql="UPDATE ST03CustomObjects SET progClass = 'STANDARD PROGRAM',defCan ='No' WHERE ( progClass IS NULL AND progClass IS NULL ) AND (progName  not like 'Y%' and  progName not like  'Z%') and requestID=:requestID";
	*//*need to check with vrishti

	public static final String sql88="UPDATE ST03_CUSTOM_OBJECTS SET DEF_CAN = (select DEFECTIVE_CAN from UBINVENTORY_SHEET where OBJECT_NAME = ST03_CUSTOM_OBJECTS.PROG_NAME and OBJECT_TYPE = 'PROG' ) where DEF_CAN is NULL and 

	PROG_CLASS like 'CUSTOM%' and REQUEST_ID=:REQUEST_ID";

	*/
	//public static final String sql89="UPDATE ST03_CUSTOM_OBJECTS SET PROG_NAME = SUBSTRING(PROG_NAME,5,LENGTH(PROG_NAME)-4) where PROG_NAME like 'SAPL%' and DEF_CAN is NULL and PROG_CLASS like 'CUSTOM%' and REQUEST_ID=:REQUEST_ID";
	//public static final String sql89_hql="UPDATE ST03CustomObjects SET progName = SUBSTRING(progName,5,LENGTH(progName)-4) where progName like 'SAPL%' and defCan is NULL and progClass like 'CUSTOM%' and requestID=:requestID";

	/*need to check with vrishti

	public static final String sql90="UPDATE ST03_CUSTOM_OBJECTS SET DEF_CAN = (select DEFECTIVE_CAN from UBINVENTORY_SHEET where OBJECT_NAME = ST03_CUSTOM_OBJECTS.PROG_NAME and OBJECT_TYPE = 'FUGR' ) where DEF_CAN is NULL and 

	PROG_CLASS = 'CUSTOM FUNCTION POOL' and REQUEST_ID=:REQUEST_ID";;
	*/
 	//public static final String sql91="UPDATE ST03_CUSTOM_OBJECTS SET DEF_CAN = 'Unknown' where DEF_CAN is NULL and REQUEST_ID=:REQUEST_ID";
 	//public static final String sql91_hql="UPDATE ST03CustomObjects SET defCan = 'Unknown' where defCan is NULL and requestID=:requestID";



	//public static final String sql92="UPDATE  ST03_CUSTOM_OBJECTS SET PROG_NAME = CONCAT('SAPL',PROG_NAME) where PROG_CLASS = 'CUSTOM FUNCTION POOL' and REQUEST_ID=:REQUEST_ID";
 	//public static final String sql92_hql="UPDATE  ST03CustomObjects SET progName = CONCAT('SAPL',progName) where progClass = 'CUSTOM FUNCTION POOL' and requestID=:requestID";



	
	//public static final String sql15="UPDATE IncludeExtractor  SET status = 'YES' WHERE progName IN (SELECT progName FROM ST03CustomObjects where requestID=:requestID) and  requestID=:requestID";

	/*
	 *Populate ST03Custom Column value
	 * 
	*/
	
	//public static final String SQL16_1 = "insert into ST03Custom(requestID,objectName,objectType,progName,dialogSteps) SELECT requestID,tCode,classification,progName,dialogSteps FROM ST03CustomObjects where requestID = :requestID";
	
	//public static final String sql16="SELECT requestID,tCode,classification,progName,dialogSteps  FROM ST03CustomObjects where requestID=:requestID";
	
	/*
	 *Populate ST03Customdialog Column value
	 * 
	*/
	
	//public static final String SQL17_1 ="insert into ST03CustomDialog(requestID,progName,dialogSteps) SELECT st.requestID,st.progName,Max(st.dialogSteps) FROM ST03CustomObjects st where st.requestID = :requestID group by st.progName,st.requestID";
	//public final static String sql17="SELECT requestID,progName,Max(dialogSteps) FROM ST03CustomObjects where requestID=:requestID group by requestID,progName";
	
	
	
	

	
	

	
	public static final String sql18="UPDATE HanaProfilerStepOutput SET objectType = LTRIM(RTRIM(objectType)), objName = LTRIM(RTRIM(objName)), operationCode = ltrim(rtrim(operationCode)) where requestID=:requestID";
	
	/*Instead of below query function is called which does exactly the same thing.*/
	//public static final String sql19="UPDATE HanaProfilerStepOutput SET usedUnused = 'Used' WHERE objName IN (SELECT progName  FROM ST03Custom where requestID=:requestID) and objectType = 'PROG' and requestID=:requestID";
	/*Instead of below query function is called which does exactly the same thing.*/
	//public static final String sql20="UPDATE HanaProfilerStepOutput SET usedUnused = 'used'  WHERE objName IN (SELECT LTRIM(RTRIM(includes)) FROM IncludeExtractor  where status='YES' and requestID=:requestID) and objectType = 'PROG' and requestID=:requestID";
	public static final String sql21="UPDATE HanaProfilerStepOutput SET usedUnused = 'Unused' WHERE usedUnused IS NULL AND objectType = 'PROG' and requestID=:requestID";
	
	/*Instead of below query function is called which does exactly the same thing.*/
	//public static final String sql22="UPDATE HanaProfilerStepOutput t SET t.dialogSteps = ( SELECT dialogSteps FROM ST03CustomDialog WHERE progName  =t.objName and requestID=:requestID)	WHERE t.dialogSteps IS NULL and t.requestID=:requestID";
	
	
	//public static final String sql23="UPDATE HanaProfilerStepOutput t SET t.operation = (SELECT operation FROM OperationData WHERE  LTRIM(RTRIM(operationCode+'.0')) = LTRIM(RTRIM(t.operationCode)) and requestID=:requestID)	WHERE operation IS NULL and requestID=:requestID";
	//public static final String sql24="UPDATE HanaProfilerStepOutput t SET t.actST  = (SELECT actStatus FROM OperationData WHERE operationCode+'.0' = t.operationCode  and requestID=:requestID) WHERE actST  IS NULL and requestID=:requestID";
	//public static final String sql25="UPDATE HanaProfilerStepOutput t SET t.subCategory = (SELECT subCategory FROM OperationData WHERE operationCode+'.0' = t.operationCode and requestID=:requestID) WHERE subCategory IS NULL and requestID=:requestID";
	//public static final String sql26="UPDATE HanaProfilerStepOutput t SET t.impact = (SELECT critical FROM OperationData WHERE operationCode+'.0' = t.operationCode and requestID=:requestID)	WHERE impact IS NULL and requestID=:requestID";
	
	public static final String sql23="UPDATE HanaProfilerStepOutput t SET t.operation = (SELECT operation FROM OperationData WHERE  LTRIM(RTRIM(operationCode)) = LTRIM(RTRIM(t.operationCode)))	WHERE operation IS NULL and requestID=:requestID";
	public static final String sql24="UPDATE HanaProfilerStepOutput t SET t.actST  = (SELECT actStatus FROM OperationData WHERE operationCode = t.operationCode) WHERE actST  IS NULL and requestID=:requestID";
	public static final String sql25="UPDATE HanaProfilerStepOutput t SET t.subCategory = (SELECT subCategory FROM OperationData WHERE operationCode = t.operationCode) WHERE subCategory IS NULL and requestID=:requestID";
	public static final String sql26="UPDATE HanaProfilerStepOutput t SET t.impact = (SELECT critical FROM OperationData WHERE operationCode = t.operationCode)	WHERE impact IS NULL and requestID=:requestID";
	
	//CR-13.0 
	public static final String sql27="UPDATE HanaProfilerStepOutput t SET t.high_lvl_desc = (SELECT high_lvl_desc FROM OperationData WHERE operationCode = t.operationCode)	WHERE high_lvl_desc IS NULL and requestID=:requestID";
	
	//CR-25.0 
	public static final String sql28="UPDATE HanaProfilerStepOutput t SET t.activeStatus = (SELECT activeSTatus FROM OperationData WHERE operationCode = t.operationCode)	WHERE activeStatus IS NULL and requestID=:requestID";
	/*Instead of below query function is called which does exactly the same thing.*/
	//public static final String sql27="UPDATE HanaProfilerStepOutput t SET t.dbPercent = (SELECT dbPercentMonth FROM ST03Custom WHERE progName  = t.objName  and requestID=:requestID) WHERE dbPercent IS NULL and requestID=:requestID";
	//public static final String sql28="UPDATE HanaProfilerStepOutput t SET t.changePercent = (SELECT changePercentMonth FROM ST03Custom WHERE progName  = t.objName and requestID=:requestID) WHERE changePercent IS NULL and requestID=:requestID";

	
	//public static final String sql29="UPDATE ST03MonthData SET dbPercent = 'Division not possible' WHERE responseTime = '0' and requestID=:requestID";
	//public static final String sql30="UPDATE ST03MonthData SET changePercent = 'Division not possible' WHERE responseTime = '0' and requestID=:requestID";
	//public static final String sql31="UPDATE ST03MonthData SET  dbPercent  =  (CAST (dbTime as float) /responseTime)*100 WHERE dbPercent IS NULL and requestID=:requestID";
	//public static final String sql31="UPDATE ST03MonthData SET  dbPercent  = convert((CAST (dbTime as decimal) /responseTime)*100,decimal(18,9)) WHERE dbPercent IS NULL and requestID=:requestID";
	//public static final String sql31="UPDATE ST03MonthData SET  dbPercent  = cast(((CAST (dbTime as big_decimal) /responseTime)*100) as big_decimal) WHERE dbPercent IS NULL and requestID=:requestID";
	//public static final String sql32="UPDATE ST03MonthData SET changePercent = cast(((CAST (modificationTime as big_decimal) /responseTime)*100) as big_decimal) WHERE changePercent IS NULL and requestID=:requestID"; 
	
   /*31 and 32 Quiers for supporting mysql
	public static final String sql31="UPDATE ST03MonthData SET  dbPercent  = dbTime /responseTime *100 WHERE dbPercent IS NULL and requestID=:requestID";
	public static final String sql32="UPDATE ST03MonthData SET changePercent = modificationTime/responseTime *100  WHERE changePercent IS NULL and requestID=:requestID";*/
	
	/*Instead of below query function is called which does exactly the same thing.*/
	//public static final String sql33="delete from ST03MonthData s where exists(select t from TestTab t where tCode = s.progName and dbPercent <> s.dbPercent and requestID=:requestID) and requestID=:requestID";
	//public static final String sql34="delete from ST03MonthData where progName in(select progName from ST03MonthData where requestID=:requestID group by progName having count(*) >1 ) and requestID=:requestID";
		
	/*34_sub and 34 Quiers for supporting mysql*/
	//public static final String sql34_sub="select progName from ST03MonthData where requestID=:requestID group by progName having count(*) >1";
	//public static final String sql34="delete from ST03MonthData  where progName in (:progName) and requestID=:requestID";
	//public static final String SQL34_1="delete from ST03MonthData  where progName in (:progName) and requestID=:requestID";
		
	public static final String sql35="INSERT INTO TestTab(tCode,dbPercent,requestID)select progName, max(dbPercent),requestID from ST03MonthData where requestID=:requestID and dbPercent!='Division not possible'  GROUP BY progName";
	
	public static final String sql36="INSERT INTO TestTab1(progName,dbPercent,requestID) SELECT progName ,MAX(dbPercentMonth),requestID from ST03Custom where requestID=:requestID and dbPercentMonth!='Division not possible' GROUP BY progName ";
	public static final String sql37="DELETE from TestTab1 WHERE dbPercent IS NULL and requestID=:requestID";
	
	//public static final String sql38="SELECT SMD.DB_PERCENT,SU.OBJECT_NAME FROM ST03_MONTH_DATA SMD,ST03_CUSTOM SU  WHERE SMD.PROG_NAME=SU.OBJECT_NAME  AND SMD.REQUEST_ID=";
	//public static final String sql38_sub="UPDATE ST03Custom  SET dbPercentMonth =:dbPercentMonth where requestID=:requestID and objectName=:objectName";
	//public static final String sql39="SELECT SMD.CHANGE_PERCENT,SU.OBJECT_NAME FROM ST03_MONTH_DATA SMD,ST03_CUSTOM SU  WHERE SMD.PROG_NAME=SU.OBJECT_NAME  AND SMD.REQUEST_ID=";
	//public static final String sql39_sub="UPDATE ST03Custom  SET changePercentMonth =:changePercentMonth where requestID=:requestID and objectName=:objectName";

	
	
	
	//public static final String sql38="UPDATE ST03Custom t SET t.dbPercentMonth = (SELECT dbPercent FROM ST03MonthData WHERE progName = t.objectName and requestID=:requestID) where requestID=:requestID";
	//public static final String sql39="UPDATE ST03Custom t SET t.changePercentMonth = (SELECT changePercent FROM ST03MonthData WHERE progName = t.objectName  and requestID=:requestID) where requestID=:requestID";
	//public static final String sql40="delete s from ST03Custom s where exists(select t from TestTab1 t where t.progName = s.progName  and t.dbPercent <> s.dbPercentMonth and t.requestID=:requestID) and s.requestID=:requestID";
	
	
	//public static final String sql41="delete from ST03Custom where dbPercentMonth is NULL and requestID=:requestID";
	
	//delete from ST03_Custom where Program_Name in(select Program_Name from ST03_Custom group by Program_Name, [db%_month] having count(*)>1)

	//public static final String sql41_next_sub="select progName from ST03Custom where requestID=:requestID group by progName, dbPercentMonth having count(*)>1";
	//public static final String sql41_next="delete from ST03Custom where progName in(:progName) and requestID=:requestID ";

	
	
	//populate Monthyearlist
	//public final static String sql42="select  distinct(monthYear) from  SunBaseData where requestID=:requestID";
	
	//get HanaProfilerStepOutput
	public final static String sql43="select h from HanaProfilerStepOutput h where h.requestID=:requestID";
	
	//getCount of FinalOutput
		public final static String sql44="select count(*) from HanaProfile where requestID=:requestID";
	
	//CR-39.0
	
	public static final String CONSOLIDATE_CONSTANT = "CONSOLIDATE";
	public static final String UI5_CONSTANT = "UI5";
	
	public static final String USAGE_CONSTANT = "USAGE ANALYSIS";
	
	//DEF 45
		public static final String USED_CONSTANT = "used";
		public static final String USED_Y_CONSTANT = "Y";
	
	public static final String HANA_CONSTANT = "HANA";
	public static final String HANA_PROFILER_STEP_COLUMNS = "2,3,8";
	public static final String OUTPUT_SHEET_COLUMNS = "4,5,6,7,11,12,13,14,17,18,19,22,24";
	public static final String HANA_TABLE_NAME = "Output_Profiler_tabs";
	
	//CR-1.0:col25
	public static final String HANA_REQUIRED_COLUMN_LIST="Session ID,Type,Obj_Name,Sub_program,Sub_Type,Read_Prog,Line_No.,Operation/Code,ACT_ST,Operation,Levels,Tables,Joins,Table_Type,Fields,Filter,Keys,Where_Con,Join Type,ITAB,WA,LOOPS,CODE,INFO,SEL_LINE,automation_status";
	
	
	public static final String[] HANA_COLUMN_ARRAY = HANA_REQUIRED_COLUMN_LIST.split(Hana_Profiler_Constant.COMMA_SEPERATOR);

	public static final String ST03_CONSTANT = "ST03";
	public static final String ST03_COLUMNS = "1,3,4,10,24";
	public static final String ST03_TABLE_NAME = "MONTH_DATA_TABS";
	
	public static final String ST03N_CONSTANT = "ST03N";
	public static final String ST03N_REQUIRED_COLUMN_LIST = "Report or Transaction name,Number of Dialog Steps,Total Response Time (s),Total Database Time (s),Total Time for Logical DB Changes (s)";
	public static final String[] ST03N_COLUMN_ARRAY = ST03N_REQUIRED_COLUMN_LIST.split(Hana_Profiler_Constant.COMMA_SEPERATOR);

	public static final String TSTC_CONSTANT = "TSTC.";
	public static final String TSTC_COLUMNS = "2,3";
	public static final String TSTC_TABLE_NAME = "ST03_TSTC";
	public static final String TSTC_REQUIRED_COLUMNS="TCODE,PGMNA";
	public static final String[] TSTC_COLUMN_ARRAY = TSTC_REQUIRED_COLUMNS.split(Hana_Profiler_Constant.COMMA_SEPERATOR);

	public static final String INCLUDE_CONSTANT = "INCLUDE";
	public static final String INCLUDE_COLUMNS = "1,2";
	public static final String INCLUDE_TABLE_NAME = "Include_Extractor";
	public static final String INCLUDE_REQUIRED_COLUMNS="program,includes";
	public static final String INCLUDE_REQUIRED_COLUMNS_NUMBERS="1,2";
	public static final String[] INCLUDE_COLUMN_ARRAY = INCLUDE_REQUIRED_COLUMNS.split(Hana_Profiler_Constant.COMMA_SEPERATOR);

	public static final String TSTCP_CONSTANT = "TSTCP.";
	public static final String TSTCP_COLUMNS = "2,3";
	public static final String TSTCP_TABLE_NAME = "ST03_TSTCP";
	public static final String TSTCP_REQUIRED_COLUMNS="TCODE,PARAM";
	public static final String[] TSTCP_COLUMN_ARRAY = TSTCP_REQUIRED_COLUMNS.split(Hana_Profiler_Constant.COMMA_SEPERATOR);
	
	public static final String TADIR_CONSTANT = "TADIR";
	public static final String TADIR_REQUIRED_COLUMNS="OBJECT,OBJ_NAME";
	
	public static final String TR_CONSTANT="tr";
	public static final String TR_REQUIRED_COLUMNS="TRDRIRFILE";
	
	public static final String TRD_CONSTANT = "trd";
	//CR-29.0
	public static final String CDS_CONSTANT = "cds";
	//CR-29.0
	public static final String CDS_REQUIRED_COLUMN_LIST="CDS_View,Table_Name";
	
	//CR-52.0
	public static final String USAGE_REQUIRED_COLUMN_LIST="TYPE,OBJ_NAME";
	
	public static final String[] CDS_COLUMN_ARRAY = CDS_REQUIRED_COLUMN_LIST.split(Hana_Profiler_Constant.COMMA_SEPERATOR);
	
	public static final String TRD_REQUIRED_COLUMNS = "SUBC,NAME";
	public static final String[] TRD_COLUMN_ARRAY = TRD_REQUIRED_COLUMNS.split(Hana_Profiler_Constant.COMMA_SEPERATOR);
	
	public static final String OPERATION_DATA_FILE_NAME= "Operation data.txt";
	public static final String OPERATION_DATA_COLUMNS="1,2,3,4,5";
	public static final String OPERATION_DATA_TABLE_NAME="OPERATION_DATA";
	public static final String OPERATION_CONSTANT = "Operation";
	
	public static final String UNEXPECTED_FILE_FOUND_MESSAGE = "An Unexpected File Found";
	
	public static final String NINE_NINE_NINE ="999";
	
	public static final String TRDIR_CONSTANT = "trdir";
	public static final String TRDIR_COLUMNS = "1,10";
	
	public static final String OUTPUT_HEADING_CONSTANT = "OutputHeading";
	
	
	
	
	public static final String TSTC_46_TABLE_NAME = "TSCTC_46";
	public static final String TSTC_46_CONSTANT="TSCTC_46";
	
	
	public static final String SIMPLIFICATION_LATEST_CONSTANT="SIMPLIFICATION";
	public static final String TCD_SIMPLIFICATION_CONSTANT="TCD";
	public static final String DETECTION_CONSTANT="CONSOLIDATE";
	public static final String GRC_MASTER_CONSTANT="GRC";
	
	public static final String INTERFACE = "INTERFACE";
	public static final String REPORTS = "REPORTS";
	public static final String FORMS = "FORMS";
	public static final String CONVERSION = "CONVERSION";
	public static final String WORKFLOW = "WORKFLOW";
	public static final String ENHANCEMENT = "ENHANCEMENT";
	public static final String ODATA = "ODATA";
	public static final String UI5 = "UI5";
	public static final String SMART_BASED ="SMART BASED";
	public static final String FREE_STYLE ="FREE STYLE";
	public static final String CLAS = "CLAS";
	public static final String FUGS = "FUGS";
	public static final String FUGR = "FUGR";
	public static final String CDS = "CDS";
	public static final String AQQU = "AQQU";
	public static final String ANALYTICAL_REPORT = "ANALYTICAL REPORT";
	public static final String TRANSACTIONAL_REPORT = "TRANSACTIONAL REPORT";
	public static final String CONFIGURABLE_REPORT = "CONFIGURABLE REPORT";
	public static final String LOW = "LOW";
	public static final String MEDIUM = "MEDIUM";
	public static final String HIGH = "HIGH";
	public static final String PROG = "PROG";
	public static final String INCL = "INCL";
	public static final String INCLUDE = "INCLUDE";
	public static final String MODULE_POOL = "MODULE POOL";
	public static final String NO_CODE_LINES = "No Code Lines";
	public static final String LSMW = "LSMW";
	public static final String REPS = "REPS";
	public static final String SSFO = "SSFO";
	public static final String SFPF = "SFPF";
	public static final String SIDE_BY_SIDE = "SIDE BY SIDE";
	public static final String IN_APP = "IN APP";
	public static final String CLASSICAL = "CLASSICAL";
	public static final String SAP_CPI_INTERFACE = "SAP CPI INTERFACE";
	public static final String A="A";
	public static final String PA="PA";
	public static final String EXTENSION_NOT_POSSIBLE = "STE- Extensibility cannot be determined";
	public static final String PA_COMMENTS = "STE - Classical extensibility partially allowed, Further evaluation is needed";
	public static final String EXTENSION_NOT_AVAILABLE = "MTE- Extensibility Cannot be determined";
	public static final String NA_COMMENTS="For MTE Core modification is not possible, Further evaluation is needed";
	public static final List<String> APP_LIST = Arrays.asList("TRANSACTIONAL", "ANALYTICAL");
	public static final String EMPTY_TCODE = "$$";
	public static final String EXT_FOR_NOCAT = "Extensibility cannot be determined";
	public static final String COMMENTS_FOR_NOCAT = "Ricef categorisation cannot be determined";
	public static final List<String> OBJ_LIST = Arrays.asList("PROG", "REPS","LSMW","MODULE POOL", "SFPI", "SSFO");	
	public static final List<String> CAT_LIST = Arrays.asList("REPORTS", "FORMS","CONVERSION","WORKFLOW", "INTERFACE", "ENHANCEMENT");	
	public static final int TCODE_LIMIT = 49;
	public static final String RICEFW = "RICEFW"; 
	public static final String S4HANA_CloudMT="S/4HANA Cloud(MT)";
	public static final String S4HANA_CloudST="S/4HANA Cloud-ST";
	public static final String OTHERS = "OTHERS";
	public static final String CLASSICAL_DYNPRO = "CLASSICAL DYNPRO";
	public static final String PROXY_OBJECT="Proxy Object";
	public static final String SSF_TEXT_MODULE ="SSF TEXT MODULE";
	public static final String DB_LINK = "DB LINK";
	public static final String FILE ="FILE";
	public static final String FILE_INTERFACE ="FILE INTERFACE";
	public static final String INTERACTIVE_REPORT="INTERACTIVE REPORT";
	public static final String INTERACTIVE="INTERACTIVE";
	public static final String FTP="FTP";
	public static final String IDOC="IDOC";
	public static final String FILE_COMMENTS = "High Usage of Application file server";
	public static final String IDOC_COMMENTS="High depedency on core";
	public static final String DBLINK_COMMENTS="High Native SQL usage";
	public static final String UPDOWN_COMMENTS ="High Dependency on presentation server";
	public static final String INCLUDE_COMMENTS ="No Where use Found";
	public static final String AIF="Usage of AIF Interface";
	
	// IRPA Constants
	public static final String CUSTOM_OPCODE = "&308";
	public static final String STANDARD_OPCODE = "&309";
	
	public static final String IRPA_SCOPE = "IRPA Testing Scope";
	
	public static final String IRPA_ERROR_MSG = "No data found ...";
	
	public static final String TRAN_OBJ = "TRAN";
	
	public static final String IRPA_TSCOPE_SHEET_NAME = "Testing Scope";
	public static final String IRPA_TESTSCRIPT_COUNT_SHEET_NAME = "Test_Script_Counts";
	public static final List<String> TSCOPE_SRC_VER_LIST = Arrays.asList("ECC", "1610", "1709", "1809", "1909");
	public static final List<String> TSCOPE_TAR_VER_LIST = Arrays.asList("ECC", "1610", "1709", "1809", "1909", "2020");
	public static final List<String> TSCOPE_TCODES_COLS = Arrays.asList("TCodes_ECC", "TCodes_S4_1610", "TCodes_S4_1709", "TCodes_S4_1809", "TCodes_S4_1909", "TCodes_S4_2020");
	public static final List<String> RTR_LIST = Arrays.asList("FI", "CO", "CA", "AC-INT", "EC-PCA");
	public static final List<String> HTR_LIST = Arrays.asList("HCM", "HR");
	public static final List<String> OTC_LIST = Arrays.asList("SD", "LE", "LO", "EWM");
	public static final List<String> PTP_LIST = Arrays.asList("MM", "IM");
	public static final List<String> S2D_LIST = Arrays.asList("PP", "PM", "QM", "PLM");
	
	public static final String IRPA_TSCOPEREPORT_PWD = "password";
	
	public static final int IRPA_ROWS_START = 7;
	
	public static final String IRPA_IMPACTED_MOSTUSED = "Impacted Most Used";
	public static final String IRPA_NONIMPACTED_MOST_USED = "Non-Impacted Most Used";
	public static final String IRPA_OTHERS_IMPACTED = "Others Impacted";
	public static final String IRPA_ADDITIONAL_BUSINESS_SCENARIOS = "Additional Business Scenarios";
	
	public static final int IRPA_MANUAL_SCRIPT_CREATION_DEFAULT = 10;
	public static final int IRPA_MANUAL_SCRIPT_MODIFICATION_DEFAULT = 20;
	public static final int IRPA_SCRIPTS_UNITTEST_DEFAULT = 10;
	public static final int IRPA_SCRIPTS_SIT1_DEFAULT = 30;
	public static final int IRPA_SCRIPTS_SIT2_DEFAULT = 80;
	public static final int IRPA_SCRIPTS_REGRESSIONTEST_DEFAULT = 70;
	public static final int IRPA_SCRIPTS_UAT_DEFAULT = 60;
	public static final int IRPA_SCRIPTS_SMOKETEST_DEFAULT = 0;
	public static final int IRPA_SIMPLE_DEFAULT = 20;
	public static final int IRPA_MEDIUM_DEFAULT = 50;
	public static final int IRPA_COMPLEX_DEFAULT = 30;

	public static final String IRPA_INVENTORY_SHEET = "Inventory";
	public static final String IRPA_ESTIMATIONS_SHEET = "Estimation";
	
	public static final String IRPA_ESTIMATES_BLANK_ERROR_MSG = "Please enter a value. Can't be blank.";
	
	public static final Boolean TRUE = true;
	public static final Boolean FALSE = false;
	
	public static final String CUST_IMP_MOST_USED = "Custom Impacted Most Used";
	public static final String STD_IMP_MOST_USED = "Standard Impacted Most Used";
	public static final String CUST_IMP = "Custom Impacted";
	public static final String STD_IMP = "Standard Impacted";
	public static final String CUST_NONIMP_MOST_USED = "Custom Non Impacted Most Used";
	public static final String STD_NONIMP_MOST_USED = "Standard Non Impacted Most Used";
	
	public static final String FRST_KEY = "1";
	public static final String SCND_KEY = "2";
	public static final String THRD_KEY = "3";
	public static final String MODULE_KEY = "module";
	public static final String MODULE = "Module";
	public static final String PROCESS_KEY = "process";
	public static final String DISTINCT_BUSINESS_SCENARIOS = "Distinct Business Scenarios";
	public static final String TEST_SCRIPTS_KEY = "testScript";
	public static final String TEST_SCRIPTS_AVAIL_YES = "Test Scripts Available";
	public static final String TEST_SCRIPTS_AVAIL_NO = "Test Scripts Not Available";
	public static final String TO_BE_UPDATED_KEY = "toBeUpdated";
	public static final String TO_BE_UPDATED_YES = "Test Scripts To Be Updated/Created";
	public static final String TO_BE_UPDATED_NO = "Test Scripts Not To Be Updated/Created";
	public static final String DATA_KEY = "data";
	public static final String COLS_KEY = "cols";
	public static final String ROWS_KEY = "rows";
	public static final String V_VALUE = "v";
	public static final String C_VALUE = "c";
	public static final String STRING_VALUE = "string";
	public static final String NUMBER_VALUE = "number";
	public static final String ROLE_KEY = "role";
	public static final String ANNOTATION_VALUE = "annotation";
	public static final String LABEL_KEY = "label";
	public static final String TYPE_KEY = "type";
	public static final String VALUE_KEY = "value";
	public static final String IMPACTED_KEY = "Impacted";
	public static final String NON_IMPACTED_KEY = "Non Impacted";
	public static final String IMPACTED_MOST_USED_KEY = "Impacted Most Used";
	public static final String NON_IMPACTED_MOST_USED_KEY = "Non Impacted Most Used";
	public static final String IMPACTED = "impacted";
	public static final String IMPACTED_MOST_USED = "impacted_most_used";
	
	public static final String BWEXTRACT_MASTER_CONSTANT="BW_EXTRACT";
}

