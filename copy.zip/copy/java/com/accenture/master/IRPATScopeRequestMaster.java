package com.accenture.master;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "IRPATScope_RM")
public class IRPATScopeRequestMaster {
	private long requestId;
	private int addBusinessScenariosToTest;
	private int addTestScriptsToTest;
	private int noTestStepsToTest;
	private int addStandardBusinessScenariosToTest;
	private int addCustomBusinessScenariosToTest;
	private int impactedBusinessScenariosCount;
	private int nonImpactedBusinessScenariosCount;
	private int impactedMostUsedBusinessScenariosCount;
	private int nonImpactedMostUsedBusinessScenariosCount;

	@Id
	@Column(name = "Request_Id")
	public long getRequestId() {
		return requestId;
	}

	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}

	@Column(name = "AddBusinessScenarios_ToTest")
	public int getAddBusinessScenariosToTest() {
		return addBusinessScenariosToTest;
	}

	public void setAddBusinessScenariosToTest(int addBusinessScenariosToTest) {
		this.addBusinessScenariosToTest = addBusinessScenariosToTest;
	}

	@Column(name = "AddTestScript_ToTest")
	public int getAddTestScriptsToTest() {
		return addTestScriptsToTest;
	}

	public void setAddTestScriptsToTest(int addTestScriptsToTest) {
		this.addTestScriptsToTest = addTestScriptsToTest;
	}

	@Column(name = "NoTestSteps_ToTest")
	public int getNoTestStepsToTest() {
		return noTestStepsToTest;
	}

	public void setNoTestStepsToTest(int noTestStepsToTest) {
		this.noTestStepsToTest = noTestStepsToTest;
	}

	@Column(name = "AddStandardBusinessScenarios_ToTest")
	public int getAddStandardBusinessScenariosToTest() {
		return addStandardBusinessScenariosToTest;
	}

	public void setAddStandardBusinessScenariosToTest(int addStandardBusinessScenariosToTest) {
		this.addStandardBusinessScenariosToTest = addStandardBusinessScenariosToTest;
	}

	@Column(name = "AddCustomBusinessScenarios_ToTest")
	public int getAddCustomBusinessScenariosToTest() {
		return addCustomBusinessScenariosToTest;
	}

	public void setAddCustomBusinessScenariosToTest(int addCustomBusinessScenariosToTest) {
		this.addCustomBusinessScenariosToTest = addCustomBusinessScenariosToTest;
	}

	@Column(name = "Impacted_BusinessScenarios_Count")
	public int getImpactedBusinessScenariosCount() {
		return impactedBusinessScenariosCount;
	}

	public void setImpactedBusinessScenariosCount(int impactedBusinessScenariosCount) {
		this.impactedBusinessScenariosCount = impactedBusinessScenariosCount;
	}

	@Column(name = "NonImpacted_BusinessScenarios_Count")
	public int getNonImpactedBusinessScenariosCount() {
		return nonImpactedBusinessScenariosCount;
	}

	public void setNonImpactedBusinessScenariosCount(int nonImpactedBusinessScenariosCount) {
		this.nonImpactedBusinessScenariosCount = nonImpactedBusinessScenariosCount;
	}

	@Column(name = "Impacted_MostUsed_BusinessScenarios_Count")
	public int getImpactedMostUsedBusinessScenariosCount() {
		return impactedMostUsedBusinessScenariosCount;
	}

	public void setImpactedMostUsedBusinessScenariosCount(int impactedMostUsedBusinessScenariosCount) {
		this.impactedMostUsedBusinessScenariosCount = impactedMostUsedBusinessScenariosCount;
	}

	@Column(name = "NonImpacted_MostUsed_BusinessScenarios_Count")
	public int getNonImpactedMostUsedBusinessScenariosCount() {
		return nonImpactedMostUsedBusinessScenariosCount;
	}

	public void setNonImpactedMostUsedBusinessScenariosCount(int nonImpactedMostUsedBusinessScenariosCount) {
		this.nonImpactedMostUsedBusinessScenariosCount = nonImpactedMostUsedBusinessScenariosCount;
	}
}
