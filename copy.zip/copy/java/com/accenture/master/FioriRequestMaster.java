package com.accenture.master;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "FioriRequest_Master")
public class FioriRequestMaster {	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Integer Id;
	
	@Column(name = "Request_ID", nullable = false)
	private long	requestID	;
	
	@Column(name = "scope", nullable = false)
	private String	scope	;
	
	@Column(name = "fioStdAppsEnabled",columnDefinition = "int default 0")
	private Integer	fioStdAppsEnabled;
	
	@Column(name = "fioStdAppsActive",columnDefinition = "int default 0")
	private Integer	fioStdAppsActive;
	
	@Column(name = "fioTrxnAppType",columnDefinition = "int default 0")
	private Integer	fioTrxnAppType;
	
	@Column(name = "fioAnalyticAppType",columnDefinition = "int default 0")
	private Integer	fioAnalyticAppType;
	
	@Column(name = "fioFactsheetAppType",columnDefinition = "int default 0")
	private Integer	fioFactsheetAppType;
	
	@Column(name = "fioWebdynAppType",columnDefinition = "int default 0")
	private Integer	fioWebdynAppType;
	
	@Column(name = "fioGuiAppType",columnDefinition = "int default 0")
	private Integer	fioGuiAppType;
	
	@Column(name = "fioOtherAppType",columnDefinition = "int default 0")
	private Integer	fioOtherAppType;
	
	@Column(name = "fioExtnUILayer",columnDefinition = "int default 0")
	private Integer	fioExtnUILayer;
	
	@Column(name = "fioExtnServiceLayer",columnDefinition = "int default 0")
	private Integer	fioExtnServiceLayer;
	
	@Column(name = "fioExtnBackendLayer",columnDefinition = "int default 0")
	private Integer	fioExtnBackendLayer;
	
	@Column(name = "fioExtnStdFioriApps",columnDefinition = "int default 0")
	private Integer	fioExtnStdFioriApps;
	
	@Column(name = "fioExtnTargetSys",columnDefinition = "int default 0")
	private Integer fioExtnTargetSys;
	
	@Column(name = "fioExtnUiTarget",columnDefinition = "int default 0")
	private Integer fioExtnUiTarget;
	
	@Column(name = "fioExtnServiceTarget",columnDefinition = "int default 0")
	private Integer fioExtnServiceTarget;
	
	@Column(name = "fioExtnBackendTarget",columnDefinition = "int default 0")
	private Integer fioExtnBackendTarget;
	
	@Column(name = "fioTcodesStandardApps",columnDefinition = "LONGTEXT")
	private String fioTcodesStandardApps;

	
	public Integer getFioExtnTargetSys() {
		return fioExtnTargetSys;
	}

	public void setFioExtnTargetSys(Integer fioExtnTargetSys) {
		this.fioExtnTargetSys = fioExtnTargetSys;
	}

	@Column(name = "fioCustomUi5Apps",columnDefinition = "int default 0")
	private Integer	fioCustomUi5Apps;
	
	@Column(name = "fioCustUi5ConsumingService",columnDefinition = "int default 0")
	private Integer	fioCustUi5ConsumingService;
	
	
	@Column(name = "fioCustOdataServices",columnDefinition = "int default 0")
	private Integer	fioCustOdataServices;
	
	@Column(name = "fioCustServiceExposeCds",columnDefinition = "int default 0")
	private Integer	fioCustServiceExposeCds;
	
	@Column(name = "fioCustomClass",columnDefinition = "int default 0")
	private Integer	fioCustomClass;
	
	@Column(name = "fioCustomOdataClass",columnDefinition = "int default 0")
	private Integer	fioCustomOdataClass;
	
	@Column(name = "fioCustOdataClassIssue",columnDefinition = "int default 0")
	private Integer	fioCustOdataClassIssue;
	
	@Column(name = "fioCustOdataHighSecIssue",columnDefinition = "int default 0")
	private Integer	fioCustOdataHighSecIssue;
	
	@Column(name = "fioCustOdataHighPerfIssue",columnDefinition = "int default 0")
	private Integer	fioCustOdataHighPerfIssue;
	
	@Column(name = "fioCustOdataHighDevIssue",columnDefinition = "int default 0")
	private Integer	fioCustOdataHighDevIssue;
	
	
	@Column(name = "fioCustOdataMediumSecIssue",columnDefinition = "int default 0")
	private Integer	fioCustOdataMediumSecIssue;
	
	@Column(name = "fioCustOdataMediumPerfIssue",columnDefinition = "int default 0")
	private Integer	fioCustOdataMediumPerfIssue;
	
	@Column(name = "fioCustOdataMediumDevIssue",columnDefinition = "int default 0")
	private Integer	fioCustOdataMediumDevIssue;
	
	
	@Column(name = "fioCustOdataLowSecIssue",columnDefinition = "int default 0")
	private Integer	fioCustOdataLowSecIssue;
	
	@Column(name = "fioCustOdataLowPerfIssue",columnDefinition = "int default 0")
	private Integer	fioCustOdataLowPerfIssue;
	
	@Column(name = "fioCustOdataLowDevIssue",columnDefinition = "int default 0")
	private Integer	fioCustOdataLowDevIssue;
	
	@Column(name = "fioAppsNotAvlTargetVer",columnDefinition = "int default 0")	
	private Integer	fioAppsNotAvlTargetVer;
	
	@Column(name = "fioAppsAvlTargetVer",columnDefinition = "int default 0")
	private Integer	fioAppsAvlTargetVer;
	
	@Column(name = "fioImpactExtnTargetSys",columnDefinition = "int default 0")
	private Integer	fioImpactExtnTargetSys;
	
	@Column(name = "fioImpactExtnUiTarget",columnDefinition = "int default 0")
	private Integer	fioImpactExtnUiTarget;
	
	@Column(name = "fioImpactExtnServiceTarget",columnDefinition = "int default 0")
	private Integer	fioImpactExtnServiceTarget;
	
	@Column(name = "fioImpactExtnBackendTarget",columnDefinition = "int default 0")
	private Integer	fioImpactExtnBackendTarget;

	//**************************************************************************
	//Graph: Issue in Custom Odata Services
	@Column(name = "fioMandatory",columnDefinition = "int default 0")	
	private Integer mandatory;
	
	@Column(name = "fioNotMandatory",columnDefinition = "int default 0")	
	private Integer notMandatory;
	
	
	public Integer getMandatory() {
		return mandatory;
	}

	public void setMandatory(Integer mandatory) {
		this.mandatory = mandatory;
	}

	public Integer getNotMandatory() {
		return notMandatory;
	}

	public void setNotMandatory(Integer notMandatory) {
		this.notMandatory = notMandatory;
	}

	public Integer getFioStdAppsEnabled() {
		return fioStdAppsEnabled;
	}

	public void setFioStdAppsEnabled(Integer fioStdAppsEnabled) {
		this.fioStdAppsEnabled = fioStdAppsEnabled;
	}

	public Integer getFioStdAppsActive() {
		return fioStdAppsActive;
	}

	public void setFioStdAppsActive(Integer fioStdAppsActive) {
		this.fioStdAppsActive = fioStdAppsActive;
	}

	public Integer getFioTrxnAppType() {
		return fioTrxnAppType;
	}

	public void setFioTrxnAppType(Integer fioTrxnAppType) {
		this.fioTrxnAppType = fioTrxnAppType;
	}

	public Integer getFioAnalyticAppType() {
		return fioAnalyticAppType;
	}

	public void setFioAnalyticAppType(Integer fioAnalyticAppType) {
		this.fioAnalyticAppType = fioAnalyticAppType;
	}

	public Integer getFioFactsheetAppType() {
		return fioFactsheetAppType;
	}

	public void setFioFactsheetAppType(Integer fioFactsheetAppType) {
		this.fioFactsheetAppType = fioFactsheetAppType;
	}

	public Integer getFioWebdynAppType() {
		return fioWebdynAppType;
	}

	public void setFioWebdynAppType(Integer fioWebdynAppType) {
		this.fioWebdynAppType = fioWebdynAppType;
	}

	public Integer getFioGuiAppType() {
		return fioGuiAppType;
	}

	public void setFioGuiAppType(Integer fioGuiAppType) {
		this.fioGuiAppType = fioGuiAppType;
	}

	public Integer getFioOtherAppType() {
		return fioOtherAppType;
	}

	public void setFioOtherAppType(Integer fioOtherAppType) {
		this.fioOtherAppType = fioOtherAppType;
	}

	public Integer getFioExtnUILayer() {
		return fioExtnUILayer;
	}

	public void setFioExtnUILayer(Integer fioExtnUILayer) {
		this.fioExtnUILayer = fioExtnUILayer;
	}

	public Integer getFioExtnServiceLayer() {
		return fioExtnServiceLayer;
	}

	public void setFioExtnServiceLayer(Integer fioExtnServiceLayer) {
		this.fioExtnServiceLayer = fioExtnServiceLayer;
	}

	public Integer getFioExtnBackendLayer() {
		return fioExtnBackendLayer;
	}

	public void setFioExtnBackendLayer(Integer fioExtnBackendLayer) {
		this.fioExtnBackendLayer = fioExtnBackendLayer;
	}

	public Integer getFioExtnStdFioriApps() {
		return fioExtnStdFioriApps;
	}

	public void setFioExtnStdFioriApps(Integer fioExtnStdFioriApps) {
		this.fioExtnStdFioriApps = fioExtnStdFioriApps;
	}

	public Integer getFioCustomUi5Apps() {
		return fioCustomUi5Apps;
	}

	public void setFioCustomUi5Apps(Integer fioCustomUi5Apps) {
		this.fioCustomUi5Apps = fioCustomUi5Apps;
	}

	public Integer getFioCustUi5ConsumingService() {
		return fioCustUi5ConsumingService;
	}

	public void setFioCustUi5ConsumingService(Integer fioCustUi5ConsumingService) {
		this.fioCustUi5ConsumingService = fioCustUi5ConsumingService;
	}

	public Integer getFioCustOdataServices() {
		return fioCustOdataServices;
	}

	public void setFioCustOdataServices(Integer fioCustOdataServices) {
		this.fioCustOdataServices = fioCustOdataServices;
	}

	public Integer getFioCustServiceExposeCds() {
		return fioCustServiceExposeCds;
	}

	public void setFioCustServiceExposeCds(Integer fioCustServiceExposeCds) {
		this.fioCustServiceExposeCds = fioCustServiceExposeCds;
	}

	public Integer getFioCustomClass() {
		return fioCustomClass;
	}

	public void setFioCustomClass(Integer fioCustomClass) {
		this.fioCustomClass = fioCustomClass;
	}

	public Integer getFioCustomOdataClass() {
		return fioCustomOdataClass;
	}

	public void setFioCustomOdataClass(Integer fioCustomOdataClass) {
		this.fioCustomOdataClass = fioCustomOdataClass;
	}

	public Integer getFioCustOdataClassIssue() {
		return fioCustOdataClassIssue;
	}

	public void setFioCustOdataClassIssue(Integer fioCustOdataClassIssue) {
		this.fioCustOdataClassIssue = fioCustOdataClassIssue;
	}

	

	public Integer getFioAppsNotAvlTargetVer() {
		return fioAppsNotAvlTargetVer;
	}

	public void setFioAppsNotAvlTargetVer(Integer fioAppsNotAvlTargetVer) {
		this.fioAppsNotAvlTargetVer = fioAppsNotAvlTargetVer;
	}

	public Integer getFioAppsAvlTargetVer() {
		return fioAppsAvlTargetVer;
	}

	public void setFioAppsAvlTargetVer(Integer fioAppsAvlTargetVer) {
		this.fioAppsAvlTargetVer = fioAppsAvlTargetVer;
	}

	public Integer getFioImpactExtnTargetSys() {
		return fioImpactExtnTargetSys;
	}

	public void setFioImpactExtnTargetSys(Integer fioImpactExtnTargetSys) {
		this.fioImpactExtnTargetSys = fioImpactExtnTargetSys;
	}

	public Integer getFioImpactExtnUiTarget() {
		return fioImpactExtnUiTarget;
	}

	public void setFioImpactExtnUiTarget(Integer fioImpactExtnUiTarget) {
		this.fioImpactExtnUiTarget = fioImpactExtnUiTarget;
	}

	public Integer getFioImpactExtnServiceTarget() {
		return fioImpactExtnServiceTarget;
	}

	public void setFioImpactExtnServiceTarget(Integer fioImpactExtnServiceTarget) {
		this.fioImpactExtnServiceTarget = fioImpactExtnServiceTarget;
	}

	public Integer getFioImpactExtnBackendTarget() {
		return fioImpactExtnBackendTarget;
	}

	public void setFioImpactExtnBackendTarget(Integer fioImpactExtnBackendTarget) {
		this.fioImpactExtnBackendTarget = fioImpactExtnBackendTarget;
	}

	public Integer getFioExtnUiTarget() {
		return fioExtnUiTarget;
	}

	public void setFioExtnUiTarget(Integer fioExtnUiTarget) {
		this.fioExtnUiTarget = fioExtnUiTarget;
	}

	public Integer getFioExtnServiceTarget() {
		return fioExtnServiceTarget;
	}

	public void setFioExtnServiceTarget(Integer fioExtnServiceTarget) {
		this.fioExtnServiceTarget = fioExtnServiceTarget;
	}

	public Integer getFioExtnBackendTarget() {
		return fioExtnBackendTarget;
	}

	public void setFioExtnBackendTarget(Integer fioExtnBackendTarget) {
		this.fioExtnBackendTarget = fioExtnBackendTarget;
	}

	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
		Id = id;
	}

	public long getRequestID() {
		return requestID;
	}

	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}

	public String getScope() {
		return scope;
	}

	public void setScope(String scope) {
		this.scope = scope;
	}

	public String getFioTcodesStandardApps() {
		return fioTcodesStandardApps;
	}

	public void setFioTcodesStandardApps(String fioTcodesStandardApps) {
		this.fioTcodesStandardApps = fioTcodesStandardApps;
	}

	public Integer getFioCustOdataHighSecIssue() {
		return fioCustOdataHighSecIssue;
	}

	public void setFioCustOdataHighSecIssue(Integer fioCustOdataHighSecIssue) {
		this.fioCustOdataHighSecIssue = fioCustOdataHighSecIssue;
	}

	public Integer getFioCustOdataHighPerfIssue() {
		return fioCustOdataHighPerfIssue;
	}

	public void setFioCustOdataHighPerfIssue(Integer fioCustOdataHighPerfIssue) {
		this.fioCustOdataHighPerfIssue = fioCustOdataHighPerfIssue;
	}

	public Integer getFioCustOdataHighDevIssue() {
		return fioCustOdataHighDevIssue;
	}

	public void setFioCustOdataHighDevIssue(Integer fioCustOdataHighDevIssue) {
		this.fioCustOdataHighDevIssue = fioCustOdataHighDevIssue;
	}

	public Integer getFioCustOdataMediumSecIssue() {
		return fioCustOdataMediumSecIssue;
	}

	public void setFioCustOdataMediumSecIssue(Integer fioCustOdataMediumSecIssue) {
		this.fioCustOdataMediumSecIssue = fioCustOdataMediumSecIssue;
	}

	public Integer getFioCustOdataMediumPerfIssue() {
		return fioCustOdataMediumPerfIssue;
	}

	public void setFioCustOdataMediumPerfIssue(Integer fioCustOdataMediumPerfIssue) {
		this.fioCustOdataMediumPerfIssue = fioCustOdataMediumPerfIssue;
	}

	public Integer getFioCustOdataMediumDevIssue() {
		return fioCustOdataMediumDevIssue;
	}

	public void setFioCustOdataMediumDevIssue(Integer fioCustOdataMediumDevIssue) {
		this.fioCustOdataMediumDevIssue = fioCustOdataMediumDevIssue;
	}

	public Integer getFioCustOdataLowSecIssue() {
		return fioCustOdataLowSecIssue;
	}

	public void setFioCustOdataLowSecIssue(Integer fioCustOdataLowSecIssue) {
		this.fioCustOdataLowSecIssue = fioCustOdataLowSecIssue;
	}

	public Integer getFioCustOdataLowPerfIssue() {
		return fioCustOdataLowPerfIssue;
	}

	public void setFioCustOdataLowPerfIssue(Integer fioCustOdataLowPerfIssue) {
		this.fioCustOdataLowPerfIssue = fioCustOdataLowPerfIssue;
	}

	public Integer getFioCustOdataLowDevIssue() {
		return fioCustOdataLowDevIssue;
	}

	public void setFioCustOdataLowDevIssue(Integer fioCustOdataLowDevIssue) {
		this.fioCustOdataLowDevIssue = fioCustOdataLowDevIssue;
	}
	

}
