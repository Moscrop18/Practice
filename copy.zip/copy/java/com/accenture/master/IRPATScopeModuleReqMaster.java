package com.accenture.master;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "IRPATScope_Module_ReqMaster")
public class IRPATScopeModuleReqMaster {
	private int id;
	private long requestId;
	private String module;
	private int scenarioCount;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Id")
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Column(name = "Request_Id")
	public long getRequestId() {
		return requestId;
	}

	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}

	@Column(name = "Module")
	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	@Column(name = "Scenario_Count")
	public int getScenarioCount() {
		return scenarioCount;
	}

	public void setScenarioCount(int scenarioCount) {
		this.scenarioCount = scenarioCount;
	}
}
