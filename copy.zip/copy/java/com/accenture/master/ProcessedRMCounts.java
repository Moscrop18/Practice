package com.accenture.master;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Processed_RM_Counts")
public class ProcessedRMCounts {
	
	private int id;
	private long requestId;
	private String colName;
	private String colValue;
	private int count;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	@Column(name = "Request_Id")
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	
	@Column(name = "Column_Name")
	public String getColName() {
		return colName;
	}
	public void setColName(String colName) {
		this.colName = colName;
	}
	
	@Column(name = "Column_Value")
	public String getColValue() {
		return colValue;
	}
	public void setColValue(String colValue) {
		this.colValue = colValue;
	}
	
	@Column(name = "Count")
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
}
