/*CR-12.0- Create Master table of request after completion. - 22/02/2017 - monika.mishra
 * 
 *CR-13.0- Rename the category & subcatefory. - 09/03/2017 - monika.mishra
 * */

package com.accenture.master;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Request_Master")
public class ProcessedRequestDetail {	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Integer Id;
	
	@Column(name = "Request_ID", nullable = false)
	private long	requestID;
	
	@Column(name = "scope", nullable = false)
	private String	scope;
	
	@Column(name = "TotalObjectCount", columnDefinition = "int default 0")
	private Integer	totalObjectCount;
	
	@Column(name = "used_count", columnDefinition = "int default 0")
	private Integer	used_count;
	
	@Column(name = "Cust_ClasCount", columnDefinition = "int default 0")
	private Integer	custClasCount;
	
	@Column(name = "Cust_BWTRCount", columnDefinition = "int default 0")
	private Integer	cust_BWTRCount;
	
	@Column(name = "Cust_BWTSCount", columnDefinition = "int default 0")
	private Integer	cust_BWTSCount;
	
	@Column(name = "Cust_BWURCount", columnDefinition = "int default 0")
	private Integer	cust_BWURCount;
	
	@Column(name = "Cust_BWIGCount", columnDefinition = "int default 0")
	private Integer	cust_BWIGCount;
	
	@Column(name = "Cust_ProgCount", columnDefinition = "int default 0")
	private Integer	custProgCount;
	
	@Column(name = "Cust_FormCount", columnDefinition = "int default 0")
	private Integer	custFormCount;
	
	@Column(name = "Cust_FugrCount", columnDefinition = "int default 0")
	private Integer	custFugrCount;
	
	@Column(name = "CustEnhanCount", columnDefinition = "int default 0")
	private Integer	custEnhanCount;
	
	@Column(name = "CustLsmwCount", columnDefinition = "int default 0")
	private Integer	custLsmwCount;
	
	@Column(name = "CustWebCount", columnDefinition = "int default 0")
	private Integer	custWebCount;
	
	@Column(name = "CustReptCount", columnDefinition = "int default 0")
	private Integer	custReptCount;
	
	@Column(name = "CustViewCount", columnDefinition = "int default 0")
	private Integer	custViewCount;
	
	@Column(name = "CustIndeCount", columnDefinition = "int default 0")
	private Integer	custIndeCount;
	
	@Column(name = "CustDtelCount", columnDefinition = "int default 0")
	private Integer	custDtelCount;
	
	@Column(name = "CustUsed_BWTRCount", columnDefinition = "int default 0")
	private Integer	custUsed_BWTRCount;
	
	@Column(name = "CustUsed_BWTSCount", columnDefinition = "int default 0")
	private Integer	custUsed_BWTSCount;
	
	@Column(name = "CustUsed_BWURCount", columnDefinition = "int default 0")
	private Integer	custUsed_BWURCount;
	
	@Column(name = "CustUsed_BWIGCount", columnDefinition = "int default 0")
	private Integer	custUsed_BWIGCount;
	
	@Column(name = "CustUsed_ClasCount", columnDefinition = "int default 0")
	private Integer	custUsedClasCount;
	
	@Column(name = "CustUsed_ProgCount", columnDefinition = "int default 0")
	private Integer	custUsedProgCount;
	
	@Column(name = "CustUsed_FormCount", columnDefinition = "int default 0")
	private Integer	custUsedFormCount;
	
	@Column(name = "CustUsedFugrCount", columnDefinition = "int default 0")
	private Integer	custUsedFugrCount;
	
	@Column(name = "CustUsedEnhanCount", columnDefinition = "int default 0")
	private Integer	custUsedEnhanCount;
	
	@Column(name = "CustUsedLsmwCount", columnDefinition = "int default 0")
	private Integer	custUsedLsmwCount;
	
	@Column(name = "CustUsedWebCount", columnDefinition = "int default 0")
	private Integer	custUsedWebCount;
	
	@Column(name = "CustUsedReptCount", columnDefinition = "int default 0")
	private Integer	custUsedReptCount;
	
	@Column(name = "CustUsedViewCount", columnDefinition = "int default 0")
	private Integer	custUsedViewCount;
	
	@Column(name = "CustUsedIndxCount", columnDefinition = "int default 0")
	private Integer	custUsedIndxCount;
	
	@Column(name = "CustUsedDtelCount", columnDefinition = "int default 0")
	private Integer	custUsedDtelCount;
	
	@Column(name = "TotalErrorCount", columnDefinition = "int default 0")
	private Integer	totalErrorCount;
	
	@Column(name = "ErrorUsedCount", columnDefinition = "int default 0")
	private Integer	errorUsedCount;
	
	@Column(name = "defectCount", columnDefinition = "int default 0")
	private Integer	defectCount;
	
	@Column(name = "Defect_ClasCount",columnDefinition = "int default 0")
	private Integer	defectClasCount;
	
	@Column(name = "Defect_BWTRCount",columnDefinition = "int default 0")
	private Integer	defect_BWTRCount;
	
	@Column(name = "Defect_BWTSCount",columnDefinition = "int default 0")
	private Integer	defect_BWTSCount;
	
	@Column(name = "Defect_BWURCount",columnDefinition = "int default 0")
	private Integer	defect_BWURCount;
	
	@Column(name = "Defect_BWIGCount",columnDefinition = "int default 0")
	private Integer	defect_BWIGCount;
	
	@Column(name = "Defect_ProgCount",columnDefinition = "int default 0")
	private Integer	defectProgCount;
	
	@Column(name = "DefectFormCount", columnDefinition = "int default 0")
	private Integer	defectFormCount;
	
	@Column(name = "Defect_FugrCount", columnDefinition = "int default 0")
	private Integer	defectFugrCount;
	
	@Column(name = "DefectEnhanCount", columnDefinition = "int default 0")
	private Integer	defectEnhanCount;
	
	@Column(name = "DefectLsmwCount", columnDefinition = "int default 0")
	private Integer	defectLsmwCount;
	
	@Column(name = "DefectWebCount", columnDefinition = "int default 0")
	private Integer	defectWebCount;
	
	@Column(name = "DefectReptCount", columnDefinition = "int default 0")
	private Integer	defectReptCount;
	
	@Column(name = "DefectViewCount", columnDefinition = "int default 0")
	private Integer	defectViewCount;
	
	@Column(name = "DefectIndeCount", columnDefinition = "int default 0")
	private Integer	defectIndeCount;
	
	@Column(name = "DefectDtelCount", columnDefinition = "int default 0")
	private Integer	defectDtelCount;

	@Column(name = "ErrorClasCount", columnDefinition = "int default 0")
	private Integer	errorClasCount;
	
	@Column(name = "ErrorBWTRCount", columnDefinition = "int default 0")
	private Integer	errorBWTRCount;
	
	@Column(name = "ErrorBWTSCount", columnDefinition = "int default 0")
	private Integer	errorBWTSCount;
	
	@Column(name = "ErrorBWURCount", columnDefinition = "int default 0")
	private Integer	errorBWURCount;
	
	@Column(name = "ErrorBWIGCount", columnDefinition = "int default 0")
	private Integer	errorBWIGCount;
	
	@Column(name = "ErrorProgCount", columnDefinition = "int default 0")
	private Integer	errorProgCount;
	
	@Column(name = "ErrorFormCount", columnDefinition = "int default 0")
	private Integer	errorFormCount;
	
	@Column(name = "ErrorFugrCount", columnDefinition = "int default 0")
	private Integer	errorFugrCount;
	
	@Column(name = "ErrorEnhCount", columnDefinition = "int default 0")
	private Integer	errorEnhCount;
	
	@Column(name = "ErrorLsmwCount", columnDefinition = "int default 0")
	private Integer	errorLsmwCount;
	
	@Column(name = "ErrorWdynCount", columnDefinition = "int default 0")
	private Integer	errorWdynCount;
	
	@Column(name = "ErrorReptCount", columnDefinition = "int default 0")
	private Integer	errorReptCount;
	
	@Column(name = "ErrorViewCount", columnDefinition = "int default 0")
	private Integer	errorViewCount;
	
	@Column(name = "ErrorIndxCount", columnDefinition = "int default 0")
	private Integer	errorIndxCount;
	
	@Column(name = "ErrorDtelCount", columnDefinition = "int default 0")
	private Integer	errorDtelCount;
	
	@Column(name = "DefectUsed_ClasCount", columnDefinition = "int default 0")
	private Integer	defectUsedClasCount;
	
	@Column(name = "DefectUsed_BWTRCount", columnDefinition = "int default 0")
	private Integer	defectUsed_BWTRCount;
	
	@Column(name = "DefectUsed_BWTSCount", columnDefinition = "int default 0")
	private Integer	defectUsed_BWTSCount;
	
	@Column(name = "DefectUsed_BWURCount", columnDefinition = "int default 0")
	private Integer	defectUsed_BWURCount;
	
	@Column(name = "DefectUsed_BWIGCount", columnDefinition = "int default 0")
	private Integer	defectUsed_BWIGCount;
	
	@Column(name = "DefectUsed_ProgCount", columnDefinition = "int default 0")
	private Integer	defectUsedProgCount;
	
	@Column(name = "DefectUsedFormCount", columnDefinition = "int default 0")
	private Integer	defectUsedFormCount;
	
	@Column(name = "DefectUsedFugrCount", columnDefinition = "int default 0")
	private Integer	defectUsedFugrCount;
	
	@Column(name = "DefectUsedEnhanCount", columnDefinition = "int default 0")
	private Integer	defectUsedEnhanCount;
	
	@Column(name = "DefectUsedLsmwCount", columnDefinition = "int default 0")
	private Integer	defectUsedLsmwCount;
	
	@Column(name = "DefectUsedWebCount", columnDefinition = "int default 0")
	private Integer	defectUsedWebCount;
	
	@Column(name = "DefectUsedReptCount", columnDefinition = "int default 0")
	private Integer	defectUsedReptCount;
	
	@Column(name = "DefectUsedViewCount", columnDefinition = "int default 0")
	private Integer	defectUsedViewCount;
	
	@Column(name = "DefectUsedIndxCount", columnDefinition = "int default 0")
	private Integer	defectUsedIndxCount;
	
	@Column(name = "DefectUsedDtelCount", columnDefinition = "int default 0")
	private Integer	defectUsedDtelCount;
	
	@Column(name = "ErrorUsedClasCount", columnDefinition = "int default 0")
	private Integer	errorUsedClasCount;
	
	@Column(name = "ErrorUsedBWTRCount", columnDefinition = "int default 0")
	private Integer	errorUsedBWTRCount;
	
	@Column(name = "ErrorUsedBWTSCount", columnDefinition = "int default 0")
	private Integer	errorUsedBWTSCount;
	
	@Column(name = "ErrorUsedBWURCount", columnDefinition = "int default 0")
	private Integer	errorUsedBWURCount;
	
	@Column(name = "ErrorUsedBWIGCount", columnDefinition = "int default 0")
	private Integer	errorUsedBWIGCount;
	
	@Column(name = "ErrorUsedProgCount", columnDefinition = "int default 0")
	private Integer	errorUsedProgCount;
	
	@Column(name = "ErrorUsedFormCount", columnDefinition = "int default 0")
	private Integer	errorUsedFormCount;
	
	@Column(name = "ErrorUsedFugrCount", columnDefinition = "int default 0")
	private Integer	errorUsedFugrCount;
	
	@Column(name = "ErrorUsedEnhCount", columnDefinition = "int default 0")
	private Integer	errorUsedEnhCount;
	
	@Column(name = "ErrorUsedLsmwCount", columnDefinition = "int default 0")
	private Integer	errorUsedLsmwCount;
	
	@Column(name = "ErrorUsedWdynCount", columnDefinition = "int default 0")
	private Integer	errorUsedWdynCount;
	
	@Column(name = "ErrorUsedReptCount", columnDefinition = "int default 0")
	private Integer	errorUsedReptCount;
	
	@Column(name = "ErrorUsedViewCount", columnDefinition = "int default 0")
	private Integer	errorUsedViewCount;
	
	@Column(name = "ErrorUsedIndxCount", columnDefinition = "int default 0")
	private Integer	errorUsedIndxCount;
	
	@Column(name = "ErrorUsedDtelCount", columnDefinition = "int default 0")
	private Integer	errorUsedDtelCount;
	
	@Column(name = "Mandatory_Category_count", columnDefinition = "int default 0")
	private Integer	mandatory_Category_count;
	
	@Column(name = "app_level_category_count", columnDefinition = "int default 0")
	private Integer	app_level_category_count;
	
	@Column(name = "db_level_category_count", columnDefinition = "int default 0")
	private Integer	db_level_category_count;
	
	@Column(name = "housekeeping_for_HANA_category_count", columnDefinition = "int default 0")
	private Integer	housekeeping_for_HANA_category_count;
	
	@Column(name = "ObjectOutputManagement", columnDefinition = "int default 0")
	private Integer	objectOutputManagement;
	
	@Column(name = "ObjectCustomFields", columnDefinition = "int default 0")
	private Integer	objectCustomFields;
	
	@Column(name = "OptionalCount", columnDefinition = "int default 0")
	private Integer	optionalCount;
	
	@Column(name = "ErrorRemediationMandatory", columnDefinition = "int default 0")
	private Integer	errorRemediationMandatory;
	
	@Column(name = "ErrorRemediationAppLevel", columnDefinition = "int default 0")
	private Integer	errorRemediationAppLevel;
	
	@Column(name = "ErrorRemediationDbLevel", columnDefinition = "int default 0")
	private Integer	errorRemediationDbLevel;
	
	@Column(name = "ErrorRemediationHouseKeeping", columnDefinition = "int default 0")
	private Integer	errorRemediationHouseKeeping;
	
	@Column(name = "ErrorRemediationOptional", columnDefinition = "int default 0")
	private Integer	errorRemediationOptional;
	
	@Column(name = "MandUsedCount", columnDefinition = "int default 0")
	private Integer	mandUsedCount;
	
	@Column(name = "ObjectUsedRemAppLevel", columnDefinition = "int default 0")
	private Integer	objectUsedRemAppLevel;
	
	@Column(name = "ObjectUsedRemDbLevel", columnDefinition = "int default 0")
	private Integer	objectUsedRemDbLevel;
	
	@Column(name = "ObjectUsedRemHouseKeeping", columnDefinition = "int default 0")
	private Integer	objectUsedRemHouseKeeping;
	
	@Column(name = "ObjectUsedOutputMgmt", columnDefinition = "int default 0")
	private Integer	objectUsedOutputMgmt;
	
	@Column(name = "ObjectUsedCustomFields", columnDefinition = "int default 0")
	private Integer	objectUsedCustomFields;
	
	@Column(name = "OptionalUsedCount", columnDefinition = "int default 0")
	private Integer	optionalUsedCount;
	
	@Column(name = "ErrorUsedRemMandatory", columnDefinition = "int default 0")
	private Integer	errorUsedRemMandatory;
	
	@Column(name = "ErrorUsedRemAppLevel", columnDefinition = "int default 0")
	private Integer	errorUsedRemAppLevel;
	
	@Column(name = "ErrorUsedRemDbLevel", columnDefinition = "int default 0")
	private Integer	errorUsedRemDbLevel;
	
	@Column(name = "ErrorUsedRemHouseKeeping", columnDefinition = "int default 0")
	private Integer	errorUsedRemHouseKeeping;
	
	@Column(name = "ErrorUsedRemOptional", columnDefinition = "int default 0")
	private Integer	errorUsedRemOptional;
	
	@Column(name = "migration_AutomatedCount", columnDefinition = "int default 0")
	private Integer	migrationAutomatedCount;
	
	@Column(name = "ErrorAutomationY", columnDefinition = "int default 0")
	private Integer	errorAutomationY;
	
	@Column(name = "dbMinAmtRepeatDbAutoN", columnDefinition = "int default 0")
	private Integer	dbMinAmtRepeatDbAutoN;
	
	@Column(name = "dbMinAmtJoinSelectStmtAutoN", columnDefinition = "int default 0")
	private Integer	dbMinAmtJoinSelectStmtAutoN;
	
	@Column(name = "dbMinAmtAllEntriesAutoN", columnDefinition = "int default 0")
	private Integer	dbMinAmtAllEntriesAutoN;
	
	@Column(name = "dbMinAmtCurrencyConvAutoN", columnDefinition = "int default 0")
	private Integer	dbMinAmtCurrencyConvAutoN;
	
	@Column(name = "dbMinAmtFaeJoinAutoN", columnDefinition = "int default 0")
	private Integer	dbMinAmtFaeJoinAutoN;
	
	@Column(name = "dbMinAmtAggStmtCollectAutoN", columnDefinition = "int default 0")
	private Integer	dbMinAmtAggStmtCollectAutoN;
	
	@Column(name = "dbMinAmtRepeatDbAutoNError", columnDefinition = "int default 0")
	private Integer	dbMinAmtRepeatDbAutoNError;
	
	@Column(name = "dbMinAmtJoinSelectAutoNError", columnDefinition = "int default 0")
	private Integer	dbMinAmtJoinSelectAutoNError;
	
	@Column(name = "dbMinAmtAllEntriesAutoNError", columnDefinition = "int default 0")
	private Integer	dbMinAmtAllEntriesAutoNError;
	
	@Column(name = "dbMinAmtCurrencyAutoNError", columnDefinition = "int default 0")
	private Integer	dbMinAmtCurrencyAutoNError;
	
	@Column(name = "dbMinAmtFaeJoinAutoNError", columnDefinition = "int default 0")
	private Integer	dbMinAmtFaeJoinAutoNError;
	
	@Column(name = "dbMinAmtAggStmtAutoNError", columnDefinition = "int default 0")
	private Integer	dbMinAmtAggStmtAutoNError;
	
	@Column(name = "totalImpactUsageCount", columnDefinition = "int default 0")
	private Integer	totalImpactUsageCount;
	
	@Column(name = "mandatoryAutoY", columnDefinition = "int default 0")
	private Integer	mandatoryAutoY;
	
	@Column(name = "hkAutoY", columnDefinition = "int default 0")
	private Integer	hkAutoY;

	@Column(name = "dbLevelAutoY", columnDefinition = "int default 0")
	private Integer	dbLevelAutoY;
	
	@Column(name = "appLevelAutoY", columnDefinition = "int default 0")
	private Integer	appLevelAutoY;
	
	@Column(name = "mandatoryAutoN", columnDefinition = "int default 0")
	private Integer	mandatoryAutoN;
	
	@Column(name = "hkAutoN", columnDefinition = "int default 0")
	private Integer	hkAutoN;
	
	@Column(name = "dbLevelAutoN", columnDefinition = "int default 0")
	private Integer	dbLevelAutoN;
	
	@Column(name = "appLevelAutoN", columnDefinition = "int default 0")
	private Integer	appLevelAutoN;
	
	@Column(name = "errorMandatoryAutoY", columnDefinition = "int default 0")
	private Integer	errorMandatoryAutoY;
	
	@Column(name = "errorHkAutoY", columnDefinition = "int default 0")
	private Integer	errorHkAutoY;
	
	@Column(name = "errorDbLevelAutoY", columnDefinition = "int default 0")
	private Integer	errorDbLevelAutoY;
	
	@Column(name = "errorAppLevelAutoY", columnDefinition = "int default 0")
	private Integer	errorAppLevelAutoY;
	
	@Column(name = "errorMandatoryAutoN", columnDefinition = "int default 0")
	private Integer	errorMandatoryAutoN;
	
	@Column(name = "errorHkAutoN", columnDefinition = "int default 0")
	private Integer	errorHkAutoN;
	
	@Column(name = "errorDbLevelAutoN", columnDefinition = "int default 0")
	private Integer	errorDbLevelAutoN;
	
	@Column(name = "errorAppLevelAutoN", columnDefinition = "int default 0")
	private Integer	errorAppLevelAutoN;
	
	@Column(name = "manFunSemanticAutoY", columnDefinition = "int default 0")
	private Integer	manFunSemanticAutoY;
	
	@Column(name = "manFunSemanticAutoN", columnDefinition = "int default 0")
	private Integer	manFunSemanticAutoN;
	
	@Column(name = "manFunHanaSortAutoY", columnDefinition = "int default 0")
	private Integer	manFunHanaSortAutoY;
	
	@Column(name = "manFunHanaSortAutoN", columnDefinition = "int default 0")
	private Integer	manFunHanaSortAutoN;
	
	@Column(name = "manSynValidAutoY", columnDefinition = "int default 0")
	private Integer	manSynValidAutoY;
	
	@Column(name = "manSynValidAutoN", columnDefinition = "int default 0")
	private Integer	manSynValidAutoN;
	
	@Column(name = "manSynPotentialAutoY", columnDefinition = "int default 0")
	private Integer	manSynPotentialAutoY;
	
	@Column(name = "manSynPotentialAutoN", columnDefinition = "int default 0")
	private Integer	manSynPotentialAutoN;
	
	@Column(name = "manSemPoolClustAutoY", columnDefinition = "int default 0")
	private Integer	manSemPoolClustAutoY;
	
	@Column(name = "manSemPoolClustAutoN", columnDefinition = "int default 0")
	private Integer	manSemPoolClustAutoN;
	
	@Column(name = "manSemDbPoolAutoY", columnDefinition = "int default 0")
	private Integer	manSemDbPoolAutoY;
	
	@Column(name = "manSemDbPoolAutoN", columnDefinition = "int default 0")
	private Integer	manSemDbPoolAutoN;
	
	@Column(name = "manVSynNsqlAutoY", columnDefinition = "int default 0")
	private Integer	manVSynNsqlAutoY;

	@Column(name = "manVSynNsqlAutoN", columnDefinition = "int default 0")
	private Integer	manVSynNsqlAutoN;
	
	@Column(name = "manVSynDDICFmlAutoY", columnDefinition = "int default 0")
	private Integer	manVSynDDICFmlAutoY;
	
	@Column(name = "manVSynDDICFmlAutoN", columnDefinition = "int default 0")
	private Integer	manVSynDDICFmlAutoN;
	
	@Column(name = "manVSynAdbcUsAutoY", columnDefinition = "int default 0")
	private Integer	manVSynAdbcUsAutoY;
	
	@Column(name = "manVSynAdbcUsAutoN", columnDefinition = "int default 0")
	private Integer	manVSynAdbcUsAutoN;
	
	@Column(name = "manHSortUnInternalAutoY", columnDefinition = "int default 0")
	private Integer	manHSortUnInternalAutoY;
	
	@Column(name = "manHSortUnInternalAutoN", columnDefinition = "int default 0")
	private Integer	manHSortUnInternalAutoN;
	
	@Column(name = "manHSortSelWKyAutoY", columnDefinition = "int default 0")
	private Integer	manHSortSelWKyAutoY;
	
	@Column(name = "manHSortSelWKyAutoN", columnDefinition = "int default 0")
	private Integer	manHSortSelWKyAutoN;
	
	@Column(name = "manHSortRBWSOAutoY", columnDefinition = "int default 0")
	private Integer	manHSortRBWSOAutoY;
	
	@Column(name = "manHSortRBWSOAutoN", columnDefinition = "int default 0")
	private Integer	manHSortRBWSOAutoN;
	
	@Column(name = "manHSortDelAdjAutoY", columnDefinition = "int default 0")
	private Integer	manHSortDelAdjAutoY;
	
	@Column(name = "manHSortDelAdjAutoN", columnDefinition = "int default 0")
	private Integer	manHSortDelAdjAutoN;
	
	@Column(name = "manHSortConStmtAutoY", columnDefinition = "int default 0")
	private Integer	manHSortConStmtAutoY;

	@Column(name = "manHSortConStmtAutoN", columnDefinition = "int default 0")
	private Integer	manHSortConStmtAutoN;
	
	@Column(name = "hkHsStmtDbHintUsed", columnDefinition = "int default 0")
	private Integer	hkHsStmtDbHintUsed;
	
	@Column(name = "hkHSLoadByTableBuff", columnDefinition = "int default 0")
	private Integer	hkHSLoadByTableBuff;
	
	@Column(name = "hkHsStmtDbHintUsedError", columnDefinition = "int default 0")
	private Integer	hkHsStmtDbHintUsedError;
	
	@Column(name = "hkHSLoadByTableBuffError", columnDefinition = "int default 0")
	private Integer	hkHSLoadByTableBuffError;
	
	@Column(name = "appHSLoad", columnDefinition = "int default 0")
	private Integer	appHSLoad;
	
	@Column(name = "appHSLoadError", columnDefinition = "int default 0")
	private Integer	appHSLoadError;
	
	@Column(name = "appLoadOptimizeDb", columnDefinition = "int default 0")
	private Integer	appLoadOptimizeDb;
	
	@Column(name = "appLoadOptimizeDbError", columnDefinition = "int default 0")
	private Integer	appLoadOptimizeDbError;
	
	@Column(name = "appLoadPerfGen", columnDefinition = "int default 0")
	private Integer	appLoadPerfGen;
	
	@Column(name = "appLoadPerfGenError", columnDefinition = "int default 0")
	private Integer	appLoadPerfGenError;
	
	@Column(name = "appResSmlPerfGen", columnDefinition = "int default 0")
	private Integer	appResSmlPerfGen;
	
	@Column(name = "appResSmlPerfGenError", columnDefinition = "int default 0")
	private Integer	appResSmlPerfGenError;
	
	@Column(name = "appMinDataPerfGen", columnDefinition = "int default 0")
	private Integer	appMinDataPerfGen;
	
	@Column(name = "appMinDataPerfGenError", columnDefinition = "int default 0")
	private Integer	appMinDataPerfGenError;
	
	@Column(name = "appMinDataHS", columnDefinition = "int default 0")
	private Integer	appMinDataHS;
	
	@Column(name = "appMinDataHSError", columnDefinition = "int default 0")
	private Integer	appMinDataHSError;
	
	@Column(name = "outputMgmtCustomFields", columnDefinition = "int default 0")
	private Integer	outputMgmtCustomFields;
	
	@Column(name = "remCategoryObj", columnDefinition = "int default 0")
	private Integer	remCategoryObj;
	
	@Column(name = "remCategoryObjError", columnDefinition = "int default 0")
	private Integer	remCategoryObjError;
	
	@Column(name = "errorHanaDbCount", columnDefinition = "int default 0")
	private Integer	errorHanaDbCount;
	
	@Column(name = "acFinanceIntlTrade", columnDefinition = "int default 0")
	private Integer	acFinanceIntlTrade;
	
	@Column(name = "acFinanceMisc", columnDefinition = "int default 0")
	private Integer	acFinanceMisc;
	
	@Column(name = "acFinanceCntrl", columnDefinition = "int default 0")
	private Integer	acFinanceCntrl;
	
	@Column(name = "acMasterData", columnDefinition = "int default 0")
	private Integer	acMasterData;
	
	@Column(name = "acIndustryRetail", columnDefinition = "int default 0")
	private Integer	acIndustryRetail;
	
	@Column(name = "acLogisticsMMIM", columnDefinition = "int default 0")
	private Integer	acLogisticsMMIM;
	
	@Column(name = "acProcurement", columnDefinition = "int default 0")
	private Integer	acProcurement;
	
	@Column(name = "acLogisticsEHS", columnDefinition = "int default 0")
	private Integer	acLogisticsEHS;
	
	@Column(name = "acSalesDistribution", columnDefinition = "int default 0")
	private Integer	acSalesDistribution;
	
	@Column(name = "acIndustryBeverage", columnDefinition = "int default 0")
	private Integer	acIndustryBeverage;
	
	@Column(name = "acIndustryDimpEco", columnDefinition = "int default 0")
	private Integer	acIndustryDimpEco;
	
	@Column(name = "acFinanceGeneral", columnDefinition = "int default 0")
	private Integer	acFinanceGeneral;
	
	@Column(name = "acLogisticsPP", columnDefinition = "int default 0")
	private Integer	acLogisticsPP;
	
	@Column(name = "acIndustryPubSec", columnDefinition = "int default 0")
	private Integer	acIndustryPubSec;
	
	@Column(name = "acIndustryDimpHt", columnDefinition = "int default 0")
	private Integer	acIndustryDimpHt;
	
	@Column(name = "acIndustryCross", columnDefinition = "int default 0")
	private Integer	acIndustryCross;
	
	@Column(name = "acIndustryAeroDef", columnDefinition = "int default 0")
	private Integer	acIndustryAeroDef;
	
	@Column(name = "acLogisticsPm", columnDefinition = "int default 0")
	private Integer	acLogisticsPm;
	
	@Column(name = "acLogisticsPlm", columnDefinition = "int default 0")
	private Integer	acLogisticsPlm;
	
	@Column(name = "acIndustryAuto", columnDefinition = "int default 0")
	private Integer	acIndustryAuto;
	
	@Column(name = "acFinanceCashMgmt", columnDefinition = "int default 0")
	private Integer	acFinanceCashMgmt;
	
	@Column(name = "acMiscellaneous", columnDefinition = "int default 0")
	private Integer	acMiscellaneous;
	
	@Column(name = "acMM", columnDefinition = "int default 0")
	private Integer	acMM;
	
	@Column(name = "acLogisticsPS", columnDefinition = "int default 0")
	private Integer	acLogisticsPS;
	
	@Column(name = "acLogisticsATP", columnDefinition = "int default 0")
	private Integer	acLogisticsATP;
	
	@Column(name = "acIndustryMedia", columnDefinition = "int default 0")
	private Integer	acIndustryMedia;
	
	@Column(name = "acFinAssetAccount", columnDefinition = "int default 0")
	private Integer	acFinAssetAccount;
	
	@Column(name = "acCrossTopics", columnDefinition = "int default 0")
	private Integer	acCrossTopics;
	
	@Column(name = "acBatchMasterData", columnDefinition = "int default 0")
	private Integer	acBatchMasterData;
	
	@Column(name = "acLogisticsPss", columnDefinition = "int default 0")
	private Integer	acLogisticsPss;
	
	@Column(name = "acPortfolioPm", columnDefinition = "int default 0")
	private Integer	acPortfolioPm;
	
	@Column(name = "acFinGeneralLedger", columnDefinition = "int default 0")
	private Integer	acFinGeneralLedger;
	
	@Column(name = "acIndustryUtil", columnDefinition = "int default 0")
	private Integer	acIndustryUtil;
	
	@Column(name = "acGlobalLogistic", columnDefinition = "int default 0")
	private Integer	acGlobalLogistic;
	
	@Column(name = "acIndustryOil", columnDefinition = "int default 0")
	private Integer	acIndustryOil;
	
	@Column(name = "acLogisticQm", columnDefinition = "int default 0")
	private Integer	acLogisticQm;
	
	@Column(name = "acFinAcctPayRecieve", columnDefinition = "int default 0")
	private Integer	acFinAcctPayRecieve;
	
	@Column(name = "acFinTreasury", columnDefinition = "int default 0")
	private Integer	acFinTreasury;
	
	@Column(name = "acLogisticsGt", columnDefinition = "int default 0")
	private Integer	acLogisticsGt;
	
	@Column(name = "acHumanResources", columnDefinition = "int default 0")
	private Integer	acHumanResources;
	
	@Column(name = "simpCategoryCOEF", columnDefinition = "int default 0")
	private Integer	simpCategoryCOEF;
	
	@Column(name = "simpCategoryFEA", columnDefinition = "int default 0")
	private Integer	simpCategoryFEA;
	
	@Column(name = "simpCategoryFENA", columnDefinition = "int default 0")
	private Integer	simpCategoryFENA;
	
	@Column(name = "simpCategoryNsfFEA", columnDefinition = "int default 0")
	private Integer	simpCategoryNsfFEA;
	
	@Column(name = "simpCategoryNsfFENA", columnDefinition = "int default 0")
	private Integer	simpCategoryNsfFENA;
	
	@Column(name = "simpCategoryNewS4Fun", columnDefinition = "int default 0")
	private Integer	simpCategoryNewS4Fun;
	
	@Column(name = "manCompHigh", columnDefinition = "int default 0")
	private Integer	manCompHigh;
	
	@Column(name = "manCompMedium", columnDefinition = "int default 0")
	private Integer	manCompMedium;
	
	@Column(name = "manCompLow", columnDefinition = "int default 0")
	private Integer	manCompLow;
	
	@Column(name = "manCompTbd", columnDefinition = "int default 0")
	private Integer	manCompTbd;
	
	@Column(name = "optCompMedium", columnDefinition = "int default 0")
	private Integer	optCompMedium;
	
	@Column(name = "optCompLow", columnDefinition = "int default 0")
	private Integer	optCompLow;
	
	@Column(name = "optCompVeryLow", columnDefinition = "int default 0")
	private Integer	optCompVeryLow;
	
	@Column(name = "manCustomCd", columnDefinition = "int default 0")
	private Integer	manCustomCd;
	
	@Column(name = "manDataElement", columnDefinition = "int default 0")
	private Integer	manDataElement;
	
	@Column(name = "manStatusTable", columnDefinition = "int default 0")
	private Integer	manStatusTable;
	
	@Column(name = "manMatLength", columnDefinition = "int default 0")
	private Integer	manMatLength;
	
	@Column(name = "manDataModel", columnDefinition = "int default 0")
	private Integer	manDataModel;
	
	@Column(name = "manNewS4Fun", columnDefinition = "int default 0")
	private Integer	manNewS4Fun;
	
	@Column(name = "manNewTrans", columnDefinition = "int default 0")
	private Integer	manNewTrans;
	
	@Column(name = "manRemOrphan", columnDefinition = "int default 0")
	private Integer	manRemOrphan;
	
	@Column(name = "manRetiredFun", columnDefinition = "int default 0")
	private Integer	manRetiredFun;
	
	@Column(name = "manSimpExistTab", columnDefinition = "int default 0")
	private Integer	manSimpExistTab;
	
	@Column(name = "manRepNewFun", columnDefinition = "int default 0")
	private Integer	manRepNewFun;
	
	@Column(name = "manFunEqvAvl", columnDefinition = "int default 0")
	private Integer	manFunEqvAvl;
	
	@Column(name = "manAdaptCustCd", columnDefinition = "int default 0")
	private Integer	manAdaptCustCd;
	
	@Column(name = "manCustFields", columnDefinition = "int default 0")
	private Integer	manCustFields;
	
	@Column(name = "manObsTrans", columnDefinition = "int default 0")
	private Integer	manObsTrans;
	
	@Column(name = "manOutputMgmt", columnDefinition = "int default 0")
	private Integer	manOutputMgmt;
	
	@Column(name = "optCustomCd", columnDefinition = "int default 0")
	private Integer	optCustomCd;
	
	@Column(name = "optDataElement", columnDefinition = "int default 0")
	private Integer	optDataElement;
	
	@Column(name = "optStatusTable", columnDefinition = "int default 0")
	private Integer	optStatusTable;
	
	@Column(name = "optMatLength", columnDefinition = "int default 0")
	private Integer	optMatLength;
	
	@Column(name = "optDataModel", columnDefinition = "int default 0")
	private Integer	optDataModel;
	
	@Column(name = "optNewS4Fun", columnDefinition = "int default 0")
	private Integer	optNewS4Fun;
	
	@Column(name = "optNewTrans", columnDefinition = "int default 0")
	private Integer	optNewTrans;
	
	@Column(name = "optRemOrphan", columnDefinition = "int default 0")
	private Integer	optRemOrphan;
	
	@Column(name = "optRetiredFun", columnDefinition = "int default 0")
	private Integer	optRetiredFun;
	
	@Column(name = "optSimpExistTab", columnDefinition = "int default 0")
	private Integer	optSimpExistTab;
	
	@Column(name = "optRepNewFun", columnDefinition = "int default 0")
	private Integer	optRepNewFun;
	
	@Column(name = "optFunEqvAvl", columnDefinition = "int default 0")
	private Integer	optFunEqvAvl;
	
	@Column(name = "optAdaptCustCd", columnDefinition = "int default 0")
	private Integer	optAdaptCustCd;
	
	@Column(name = "optCustFields", columnDefinition = "int default 0")
	private Integer	optCustFields;
	
	@Column(name = "optObsTrans", columnDefinition = "int default 0")
	private Integer	optObsTrans;
	
	@Column(name = "optOutputMgmt", columnDefinition = "int default 0")
	private Integer	optOutputMgmt;
	
	@Column(name = "manCustomCdError", columnDefinition = "int default 0")
	private Integer	manCustomCdError;
	
	@Column(name = "manDataElementError", columnDefinition = "int default 0")
	private Integer	manDataElementError;
	
	@Column(name = "manStatusTableError", columnDefinition = "int default 0")
	private Integer	manStatusTableError;
	
	@Column(name = "manMatLengthError", columnDefinition = "int default 0")
	private Integer	manMatLengthError;
	
	@Column(name = "manDataModelError", columnDefinition = "int default 0")
	private Integer	manDataModelError;
	
	@Column(name = "manNewS4FunError", columnDefinition = "int default 0")
	private Integer	manNewS4FunError;
	
	@Column(name = "manNewTransError", columnDefinition = "int default 0")
	private Integer	manNewTransError;
	
	@Column(name = "manRemOrphanError", columnDefinition = "int default 0")
	private Integer	manRemOrphanError;
	
	@Column(name = "manRetiredFunError", columnDefinition = "int default 0")
	private Integer	manRetiredFunError;
	
	@Column(name = "manSimpExistTabError", columnDefinition = "int default 0")
	private Integer	manSimpExistTabError;
	
	@Column(name = "manRepNewFunError", columnDefinition = "int default 0")
	private Integer	manRepNewFunError;
	
	@Column(name = "manFunEqvAvlError", columnDefinition = "int default 0")
	private Integer	manFunEqvAvlError;
	
	@Column(name = "manAdaptCustCdError", columnDefinition = "int default 0")
	private Integer	manAdaptCustCdError;
	
	@Column(name = "manCustFieldsError", columnDefinition = "int default 0")
	private Integer	manCustFieldsError;
	
	@Column(name = "manObsTransError", columnDefinition = "int default 0")
	private Integer	manObsTransError;
	
	@Column(name = "manOutputMgmtError", columnDefinition = "int default 0")
	private Integer	manOutputMgmtError;
	
	@Column(name = "optCustomCdError", columnDefinition = "int default 0")
	private Integer	optCustomCdError;
	
	@Column(name = "optDataElementError", columnDefinition = "int default 0")
	private Integer	optDataElementError;
	
	@Column(name = "optStatusTableError", columnDefinition = "int default 0")
	private Integer	optStatusTableError;
	
	@Column(name = "optMatLengthError", columnDefinition = "int default 0")
	private Integer	optMatLengthError;
	
	@Column(name = "optDataModelError", columnDefinition = "int default 0")
	private Integer	optDataModelError;
	
	@Column(name = "optNewS4FunError", columnDefinition = "int default 0")
	private Integer	optNewS4FunError;
	
	@Column(name = "optNewTransError", columnDefinition = "int default 0")
	private Integer	optNewTransError;
	
	@Column(name = "optRemOrphanError", columnDefinition = "int default 0")
	private Integer	optRemOrphanError;
	
	@Column(name = "optRetiredFunError", columnDefinition = "int default 0")
	private Integer	optRetiredFunError;
	
	@Column(name = "optSimpExistTabError", columnDefinition = "int default 0")
	private Integer	optSimpExistTabError;
	
	@Column(name = "optRepNewFunError", columnDefinition = "int default 0")
	private Integer	optRepNewFunError;
	
	@Column(name = "optFunEqvAvlError", columnDefinition = "int default 0")
	private Integer	optFunEqvAvlError;
	
	@Column(name = "optAdaptCustCdError", columnDefinition = "int default 0")
	private Integer	optAdaptCustCdError;
	
	@Column(name = "optCustFieldsError", columnDefinition = "int default 0")
	private Integer	optCustFieldsError;
	
	@Column(name = "optObsTransError", columnDefinition = "int default 0")
	private Integer	optObsTransError;
	
	@Column(name = "optOutputMgmtError", columnDefinition = "int default 0")
	private Integer	optOutputMgmtError;
	
	@Column(name = "usreCount", columnDefinition = "int default 0")
	private Integer	usreCount;
	
	@Column(name = "usrrCount", columnDefinition = "int default 0")
	private Integer	usrrCount;
	
	@Column(name = "fugsCount", columnDefinition = "int default 0")
	private Integer	fugsCount;
	
	@Column(name = "usreUsedCount", columnDefinition = "int default 0")
	private Integer	usreUsedCount;
	
	@Column(name = "usrrUsedCount", columnDefinition = "int default 0")
	private Integer	usrrUsedCount;
	
	@Column(name = "fugsUsedCount", columnDefinition = "int default 0")
	private Integer	fugsUsedCount;
	
	@Column(name = "defectUsreCount", columnDefinition = "int default 0")
	private Integer	defectUsreCount;
	
	@Column(name = "defectUsrrCount", columnDefinition = "int default 0")
	private Integer	defectUsrrCount;
	
	@Column(name = "defectFugsCount", columnDefinition = "int default 0")
	private Integer	defectFugsCount;
	
	@Column(name = "errorUsreCount", columnDefinition = "int default 0")
	private Integer	errorUsreCount;
	
	@Column(name = "errorUsrrCount", columnDefinition = "int default 0")
	private Integer	errorUsrrCount;
	
	@Column(name = "errorFugsCount", columnDefinition = "int default 0")
	private Integer	errorFugsCount;
	
	@Column(name = "defectUsedUsreCount", columnDefinition = "int default 0")
	private Integer	defectUsedUsreCount;
	
	@Column(name = "defectUsedUsrrCount", columnDefinition = "int default 0")
	private Integer	defectUsedUsrrCount;
	
	@Column(name = "defectUsedFugsCount", columnDefinition = "int default 0")
	private Integer	defectUsedFugsCount;
	
	@Column(name = "errorUsedUsreCount", columnDefinition = "int default 0")
	private Integer	errorUsedUsreCount;
	
	@Column(name = "errorUsedUsrrCount", columnDefinition = "int default 0")
	private Integer	errorUsedUsrrCount;
	
	@Column(name = "errorUsedFugsCount", columnDefinition = "int default 0")
	private Integer	errorUsedFugsCount;
	
	@Column(name = "hANA_Sorting_cnt",columnDefinition = "int default 0")
	private Integer	hANA_Sorting_cnt;
	
	@Column(name = "minimize_amnt_data_trnsfr_cnt",columnDefinition = "int default 0")
	private Integer	minimize_amnt_data_trnsfr_cnt;
	
	@Column(name = "potential_syntax_err_cnt",columnDefinition = "int default 0")
	private Integer	potential_syntax_err_cnt;
	
	@Column(name = "result_set_small_subcategry_count",columnDefinition = "int default 0")
	private Integer	result_set_small_subcategry_count;
	
	@Column(name = "semantic_Err_cnt",columnDefinition = "int default 0")
	private Integer	semantic_Err_cnt;
	
	@Column(name = "statement_ignr_HANA_sbcatgry",columnDefinition = "int default 0")
	private Integer	statement_ignr_HANA_sbcatgry;
	
	@Column(name = "unneces_loa_away_subcategry_count",columnDefinition = "int default 0")
	private Integer	unneces_loa_away_subcategry_count;
	
	@Column(name = "validat_syntx_err_subcatgry",columnDefinition = "int default 0")
	private Integer	validat_syntx_err_subcatgry;
	
	@Column(name = "hANA_Sorting_usedCnt",columnDefinition = "int default 0")
	private Integer	hanaSortingUsedCnt;
	
	@Column(name = "minimize_amnt_data_trnsfr_usedCnt",columnDefinition = "int default 0")
	private Integer	minimizeAmntDataTrnsfrUsedCnt;
	
	@Column(name = "potential_syntax_err_usedCnt",columnDefinition = "int default 0")
	private Integer	potentialSyntaxErrUsedCnt;
	
	@Column(name = "result_set_small_usedCnt",columnDefinition = "int default 0")
	private Integer	resultSetSmallUsedCnt;
	
	@Column(name = "semantic_Err_usedCnt",columnDefinition = "int default 0")
	private Integer	semanticErrUsedCnt;
	
	@Column(name = "statement_ignr_HANA_usedCnt",columnDefinition = "int default 0")
	private Integer	statementIgnrHanaUsedCnt;
	
	@Column(name = "unneces_loa_away_usedCnt",columnDefinition = "int default 0")
	private Integer	UnnecesLoaAwayUsedCnt;
	
	@Column(name = "validat_syntx_err_usedCnt",columnDefinition = "int default 0")
	private Integer	ValidatSyntxErrUsedCnt;
	
	@Column(name = "new_dataModel_cnt",columnDefinition = "int default 0")
	private Integer	newDataModelCnt;
	
	@Column(name = "material_lengthExtension_cnt",columnDefinition = "int default 0")
	private Integer	Material_lengthExtension_cnt;
	
	@Column(name = "data_Element_lengthExtension_cnt",columnDefinition = "int default 0")
	private Integer	Data_Element_lengthExtension_cnt;
	
	@Column(name = "eliminationOf_Status_Table_cnt",columnDefinition = "int default 0")
	private Integer	eliminationOf_Status_Table_cnt;
	
	@Column(name = "removalOf_OrphenedObjects_cnt",columnDefinition = "int default 0")
	private Integer	removalOf_OrphenedObjects_cnt;
	
	@Column(name = "customCode_Adaption_cnt",columnDefinition = "int default 0")
	private Integer	customCode_Adaption_cnt;
	
	@Column(name = "retiredFunctionality_cnt",columnDefinition = "int default 0")
	private Integer retiredFunctionality_cnt;
	
	@Column(name = "newS4Functionality_cnt",columnDefinition = "int default 0")
	private Integer newS4Functionality_cnt;
	
	@Column(name = "replacedByNewFunctionality_cnt",columnDefinition = "int default 0")
	private Integer replacedByNewFunctionality_cnt;
	
	@Column(name = "newTransaction_cnt",columnDefinition = "int default 0")
	private Integer newTransaction_cnt;
	
	@Column(name = "functionalEquivalentAvailable_cnt",columnDefinition = "int default 0")
	private Integer functionalEquivalentAvailable_cnt;
	
	@Column(name = "simplificationOfExistingTable_cnt",columnDefinition = "int default 0")
	private Integer	simplificationOfExistingTable_cnt;
	
	@Column(name = "new_dataModel_Usedcnt",columnDefinition = "int default 0")
	private Integer	new_dataModel_Usedcnt;
	
	@Column(name = "Material_lengthExtension_Usedcnt",columnDefinition = "int default 0")
	private Integer	Material_lengthExtension_Usedcnt;
	
	@Column(name = "data_Element_lengthExtension_Usedcnt",columnDefinition = "int default 0")
	private Integer	data_Element_lengthExtension_Usedcnt;
	
	@Column(name = "eliminationOf_Status_Table_Usedcnt",columnDefinition = "int default 0")
	private Integer	eliminationOf_Status_Table_Usedcnt;
	
	@Column(name = "removalOf_OrphenedObjects_Usedcnt",columnDefinition = "int default 0")
	private Integer	removalOf_OrphenedObjects_Usedcnt;
	
	@Column(name = "customCode_Adaption_Usedcnt",columnDefinition = "int default 0")
	private Integer	customCode_Adaption_Usedcnt;
	
	@Column(name = "retiredFunctionality_Usedcnt",columnDefinition = "int default 0")
	private Integer	retiredFunctionality_Usedcnt;
	
	@Column(name = "newS4Functionality_Usedcnt",columnDefinition = "int default 0")
	private Integer	newS4Functionality_Usedcnt;
	
	@Column(name = "replacedByNewFunctionality_Usedcnt",columnDefinition = "int default 0")
	private Integer replacedByNewFunctionality_Usedcnt;
	
	@Column(name = "newTransaction_Usedcnt",columnDefinition = "int default 0")
	private Integer newTransaction_Usedcnt;

	@Column(name = "functionalEquivalentAvailable_Usedcnt",columnDefinition = "int default 0")
	private Integer functionalEquivalentAvailable_Usedcnt;

	@Column(name = "simplificationOfExistingTable_Usedcnt",columnDefinition = "int default 0")
	private Integer simplificationOfExistingTable_Usedcnt;

	@Column(name = "defectHanaSorting",columnDefinition = "int default 0")
	private Integer	defectHanaSorting;
	
	@Column(name = "defecMminimizeAmntDataTrnsfr",columnDefinition = "int default 0")
	private Integer	defecMminimizeAmntDataTrnsfr;
	
	@Column(name = "defectPotentialSyntax",columnDefinition = "int default 0")
	private Integer	defectPotentialSyntax;
	
	@Column(name = "defectResultsetSmallSubcategry",columnDefinition = "int default 0")
	private Integer	defectResultsetSmallSubcategry;
	
	@Column(name = "defectSemanticErr",columnDefinition = "int default 0")
	private Integer	defectSemanticErr;
	
	@Column(name = "defectStmtIgnrHanaSbcatgry",columnDefinition = "int default 0")
	private Integer	defectStmtIgnrHanaSbcatgry;
	
	@Column(name = "defectUnnecesLoaAwaySbcatgry",columnDefinition = "int default 0")
	private Integer	defectUnnecesLoaAwaySbcatgry;
	
	@Column(name = "defectValidatSyntxSubcatgry",columnDefinition = "int default 0")
	private Integer	defectValidatSyntxSubcatgry;
	
	@Column(name = "defectHanaSortingUsedCnt",columnDefinition = "int default 0")
	private Integer	defectHanaSortingUsedCnt;
	
	@Column(name = "defectMinAmntDataTrnsfrUsedCnt",columnDefinition = "int default 0")
	private Integer	defectMinAmntDataTrnsfrUsedCnt;
	
	@Column(name = "defectPotentialSyntaxUsedCnt",columnDefinition = "int default 0")
	private Integer	defectPotentialSyntaxUsedCnt;
	
	@Column(name = "defectResultSetSmallUsedCnt",columnDefinition = "int default 0")
	private Integer	defectResultSetSmallUsedCnt;
	
	@Column(name = "defectSemanticErrUsedCnt",columnDefinition = "int default 0")
	private Integer	defectSemanticErrUsedCnt;
	
	@Column(name = "defectStmtIgnrHanaUsedCnt",columnDefinition = "int default 0")
	private Integer	defectStmtIgnrHanaUsedCnt;
	
	@Column(name = "defectUnnecesLoaAwayUsedCnt",columnDefinition = "int default 0")
	private Integer	defectUnnecesLoaAwayUsedCnt;
	
	@Column(name = "defectValidatSyntxErrUsedCnt",columnDefinition = "int default 0")
	private Integer	defectValidatSyntxErrUsedCnt;
	
	@Column(name = "defNewDataModel",columnDefinition = "int default 0")
	private Integer	defNewDataModel;
	
	@Column(name = "defMaterialLengthExt",columnDefinition = "int default 0")
	private Integer	defMaterialLengthExt;
	
	@Column(name = "defDataElementlengthExt",columnDefinition = "int default 0")
	private Integer	defDataElementlengthExt;
	
	@Column(name = "defEliminationOfStatusTable",columnDefinition = "int default 0")
	private Integer	defEliminationOfStatusTable;
	
	@Column(name = "defRemovalOrphenObjects",columnDefinition = "int default 0")
	private Integer	defRemovalOrphenObjects;
	
	@Column(name = "defCustomCodeAdaption",columnDefinition = "int default 0")
	private Integer	defCustomCodeAdaption;
	
	@Column(name = "defRetiredFunctionality",columnDefinition = "int default 0")
	private Integer	defRetiredFunctionality;
	
	@Column(name = "defNewS4Functionality",columnDefinition = "int default 0")
	private Integer	defNewS4Functionality;
	
	@Column(name = "defReplacNewFunctionality",columnDefinition = "int default 0")
	private Integer	defReplacNewFunctionality;
	
	@Column(name = "defNewTransaction",columnDefinition = "int default 0")
	private Integer	defNewTransaction;
	
	@Column(name = "defFunctionalEqvAvailable",columnDefinition = "int default 0")
	private Integer	defFunctionalEqvAvailable;
	
	@Column(name = "defSimplificationExistTable",columnDefinition = "int default 0")
	private Integer	defSimplificationExistTable;
	
	@Column(name = "defNewDataModelUsed",columnDefinition = "int default 0")
	private Integer	defNewDataModelUsed;
	
	@Column(name = "defMaterialLengthExtUsed",columnDefinition = "int default 0")
	private Integer	defMaterialLengthExtUsed;
	
	@Column(name = "defDataElementlengthExtUsed",columnDefinition = "int default 0")
	private Integer	defDataElementlengthExtUsed;
	
	@Column(name = "defEliminationOfStatusTableUsed",columnDefinition = "int default 0")
	private Integer	defEliminationOfStatusTableUsed;
	
	@Column(name = "defRemovalOrphenObjectsUsed",columnDefinition = "int default 0")
	private Integer	defRemovalOrphenObjectsUsed;
	
	@Column(name = "defCustomCodeAdaptionUsed",columnDefinition = "int default 0")
	private Integer	defCustomCodeAdaptionUsed;
	
	@Column(name = "defRetiredFunctionalityUsed",columnDefinition = "int default 0")
	private Integer	defRetiredFunctionalityUsed;
	
	@Column(name = "defNewS4FunctionalityUsed",columnDefinition = "int default 0")
	private Integer	defNewS4FunctionalityUsed;
	
	@Column(name = "defReplacNewFunctionalityUsed",columnDefinition = "int default 0")
	private Integer	defReplacNewFunctionalityUsed;
	
	@Column(name = "defNewTransactionUsed",columnDefinition = "int default 0")
	private Integer	defNewTransactionUsed;
	
	@Column(name = "defFunctionalEqvAvailableUsed",columnDefinition = "int default 0")
	private Integer	defFunctionalEqvAvailableUsed;
	
	@Column(name = "defSimplificationExistTableUsed",columnDefinition = "int default 0")
	private Integer	defSimplificationExistTableUsed;
	
	//Slide 10 and 11 Error objects
	
	@Column(name = "ManFunSemanticAutoYError", columnDefinition = "int default 0")
	private Integer	manFunSemanticAutoYError;
	
	@Column(name = "ManFunSemanticAutoNError", columnDefinition = "int default 0")
	private Integer	manFunSemanticAutoNError;
	
	@Column(name = "ManFunHanaSortAutoYError", columnDefinition = "int default 0")
	private Integer	manFunHanaSortAutoYError;
	
	@Column(name = "ManFunHanaSortAutoNError", columnDefinition = "int default 0")
	private Integer	manFunHanaSortAutoNError;
	
	@Column(name = "ManSynValidAutoYError", columnDefinition = "int default 0")
	private Integer	manSynValidAutoYError;
	
	@Column(name = "ManSynValidAutoNError", columnDefinition = "int default 0")
	private Integer	manSynValidAutoNError;
	
	@Column(name = "ManSynPotentialAutoYError", columnDefinition = "int default 0")
	private Integer	manSynPotentialAutoYError;
	
	@Column(name = "ManSynPotentialAutoNError", columnDefinition = "int default 0")
	private Integer	manSynPotentialAutoNError;
	
	@Column(name = "manSemPoolClustAutoYError", columnDefinition = "int default 0")
	private Integer	manSemPoolClustAutoYError;
	
	@Column(name = "manSemPoolClustAutoNError", columnDefinition = "int default 0")
	private Integer	manSemPoolClustAutoNError;
	
	@Column(name = "manSemDbPoolAutoYError", columnDefinition = "int default 0")
	private Integer	manSemDbPoolAutoYError;
	
	@Column(name = "manSemDbPoolAutoNError", columnDefinition = "int default 0")
	private Integer	manSemDbPoolAutoNError;
	
	@Column(name = "manVSynNsqlAutoYError", columnDefinition = "int default 0")
	private Integer	manVSynNsqlAutoYError;
	
	@Column(name = "manVSynNsqlAutoNError", columnDefinition = "int default 0")
	private Integer	manVSynNsqlAutoNError;
	
	@Column(name = "manVSynDDICFmlAutoYError", columnDefinition = "int default 0")
	private Integer	manVSynDDICFmlAutoYError;
	
	@Column(name = "manVSynDDICFmlAutoNError", columnDefinition = "int default 0")
	private Integer	manVSynDDICFmlAutoNError;
	
	@Column(name = "manVSynAdbcUsAutoYError", columnDefinition = "int default 0")
	private Integer	manVSynAdbcUsAutoYError;
	
	@Column(name = "manVSynAdbcUsAutoNError", columnDefinition = "int default 0")
	private Integer	manVSynAdbcUsAutoNError;
	
	@Column(name = "manHSortUnInternalAutoYError", columnDefinition = "int default 0")
	private Integer	manHSortUnInternalAutoYError;
	
	@Column(name = "manHSortUnInternalAutoNError", columnDefinition = "int default 0")
	private Integer	manHSortUnInternalAutoNError;

	@Column(name = "manHSortSelWKyAutoYError", columnDefinition = "int default 0")
	private Integer	manHSortSelWKyAutoYError;
	
	@Column(name = "manHSortSelWKyAutoNError", columnDefinition = "int default 0")
	private Integer	manHSortSelWKyAutoNError;
	
	@Column(name = "manHSortRBWSOAutoYError", columnDefinition = "int default 0")
	private Integer	manHSortRBWSOAutoYError;
	
	@Column(name = "manHSortRBWSOAutoNError", columnDefinition = "int default 0")
	private Integer	manHSortRBWSOAutoNError;
	
	@Column(name = "manHSortDelAdjAutoYError", columnDefinition = "int default 0")
	private Integer	manHSortDelAdjAutoYError;
	
	@Column(name = "manHSortDelAdjAutoNError", columnDefinition = "int default 0")
	private Integer	manHSortDelAdjAutoNError;
	
	@Column(name = "manHSortConStmtAutoYError", columnDefinition = "int default 0")
	private Integer	manHSortConStmtAutoYError;
	
	@Column(name = "manHSortConStmtAutoNError", columnDefinition = "int default 0")
	private Integer	manHSortConStmtAutoNError;
	
	@Column(name = "manUnsortIntTabAccFMAutoY", columnDefinition = "int default 0")
	private Integer manUnsortIntTabAccFMAutoY;
	
	@Column(name = "manUnsortIntTabAccFMAutoYError", columnDefinition = "int default 0")
	private Integer manUnsortIntTabAccFMAutoYError;

	/* --------------------------------------------------------------------------------------------- */
	/* --------------------------------------------------------------------------------------------- */
	
	@Column(name = "acProjectManagement", columnDefinition = "int default 0")
	private Integer	acProjectManagement;
	
	@Column(name = "acGlobalTrade", columnDefinition = "int default 0")
	private Integer	acGlobalTrade;
	
	@Column(name = "acCollaborativeEngineeringAndProjectManagement", columnDefinition = "int default 0")
	private Integer	acCollaborativeEngineeringAndProjectManagement;
	
	@Column(name = "acResultsRecording", columnDefinition = "int default 0")
	private Integer	acResultsRecording;
	
	@Column(name = "acDiscreteIndustriesAndMillProducts", columnDefinition = "int default 0")
	private Integer	acDiscreteIndustriesAndMillProducts;
	
	@Column(name = "acGeneralLedgerAccounting", columnDefinition = "int default 0")
	private Integer	acGeneralLedgerAccounting;
	
	@Column(name = "acActualCostingMaterialLedger", columnDefinition = "int default 0")
	private Integer	acActualCostingMaterialLedger;
	
	@Column(name = "acPricingAndConditions", columnDefinition = "int default 0")
	private Integer	acPricingAndConditions;
	
	@Column(name = "acCreditManagement", columnDefinition = "int default 0")
	private Integer	acCreditManagement;
	
	@Column(name = "acManufacturerPartNumber", columnDefinition = "int default 0")
	private Integer	acManufacturerPartNumber;
	
	@Column(name = "acSupplierWorkplace", columnDefinition = "int default 0")
	private Integer	acSupplierWorkplace;
	
	@Column(name = "acDealerPortal", columnDefinition = "int default 0")
	private Integer	acDealerPortal;
	
	@Column(name = "acSettlementManagement", columnDefinition = "int default 0")
	private Integer	acSettlementManagement;
	
	@Column(name = "acTreasuryAndRiskManagement", columnDefinition = "int default 0")
	private Integer	acTreasuryAndRiskManagement;
	
	@Column(name = "acCommodityManagement", columnDefinition = "int default 0")
	private Integer	acCommodityManagement;
	
	@Column(name = "acEnhancementsActualLaborCostingTimeRecording", columnDefinition = "int default 0")
	private Integer	acEnhancementsActualLaborCostingTimeRecording;
	
	@Column(name = "acInstalledBaseManagement", columnDefinition = "int default 0")
	private Integer	acInstalledBaseManagement;
	
	@Column(name = "acBusinessPartners", columnDefinition = "int default 0")
	private Integer	acBusinessPartners;
	
	@Column(name = "acSuiteEnablementForAriba", columnDefinition = "int default 0")
	private Integer	acSuiteEnablementForAriba;
	
	@Column(name = "acArticles", columnDefinition = "int default 0")
	private Integer	acArticles;
	
	@Column(name = "acConsumerDecisionTree", columnDefinition = "int default 0")
	private Integer	acConsumerDecisionTree;
	
	@Column(name = "acAssortmentList", columnDefinition = "int default 0")
	private Integer	acAssortmentList;
	
	@Column(name = "acAvailabilityCheck", columnDefinition = "int default 0")
	private Integer	acAvailabilityCheck;

	@Column(name = "acSalesAndDistributionSdEnhancements", columnDefinition = "int default 0")
	private Integer	acSalesAndDistributionSdEnhancements;
	
	@Column(name = "acConvergentInvoicing", columnDefinition = "int default 0")
	private Integer	acConvergentInvoicing;
	
	@Column(name = "acSapCashManagement", columnDefinition = "int default 0")
	private Integer	acSapCashManagement;
	
	@Column(name = "acVirtualDataModelForPpKanban", columnDefinition = "int default 0")
	private Integer	acVirtualDataModelForPpKanban;
	
	@Column(name = "acMultichannelFoundationForUtilities", columnDefinition = "int default 0")
	private Integer	acMultichannelFoundationForUtilities;
	
	@Column(name = "acTargetGroups", columnDefinition = "int default 0")
	private Integer	acTargetGroups;
	
	@Column(name = "acCommodityManagementAnalytics", columnDefinition = "int default 0")
	private Integer	acCommodityManagementAnalytics;
	
	@Column(name = "acLoansManagement", columnDefinition = "int default 0")
	private Integer	acLoansManagement;
	
	@Column(name = "acGroupingPeggingDistribution", columnDefinition = "int default 0")
	private Integer	acGroupingPeggingDistribution;
	
	@Column(name = "acBasicFunctions", columnDefinition = "int default 0")
	private Integer	acBasicFunctions;
	
	@Column(name = "acContractManagement", columnDefinition = "int default 0")
	private Integer	acContractManagement;
	
	@Column(name = "acTransactionManager", columnDefinition = "int default 0")
	private Integer	acTransactionManager;
	
	@Column(name = "acExtendedLogistics", columnDefinition = "int default 0")
	private Integer	acExtendedLogistics;
	
	@Column(name = "acProductConfigurator", columnDefinition = "int default 0")
	private Integer	acProductConfigurator;
	
	@Column(name = "acFreightSettlement", columnDefinition = "int default 0")
	private Integer	acFreightSettlement;
	
	@Column(name = "acCustomFields", columnDefinition = "int default 0")
	private Integer	acCustomFields;
	
	@Column(name = "acFieldLengthExtensionForMaterial", columnDefinition = "int default 0")
	private Integer	acFieldLengthExtensionForMaterial;
	
	@Column(name = "acProductMasterData", columnDefinition = "int default 0")
	private Integer	acProductMasterData;
	
	@Column(name = "acAssetAccounting", columnDefinition = "int default 0")
	private Integer	acAssetAccounting;
	
	@Column(name = "acFundAccounting", columnDefinition = "int default 0")
	private Integer	acFundAccounting;
	
	@Column(name = "acCustomerInteractionCenter", columnDefinition = "int default 0")
	private Integer	acCustomerInteractionCenter;
	
	@Column(name = "acFundsManagement", columnDefinition = "int default 0")
	private Integer	acFundsManagement;
	
	@Column(name = "acInboundTracking", columnDefinition = "int default 0")
	private Integer	acInboundTracking;
	
	@Column(name = "acDocumentManagementSystem", columnDefinition = "int default 0")
	private Integer	acDocumentManagementSystem;
	
	@Column(name = "acSapUtilities", columnDefinition = "int default 0")
	private Integer	acSapUtilities;
	
	@Column(name = "acConstructionEquipmentManagement", columnDefinition = "int default 0")
	private Integer	acConstructionEquipmentManagement;
	
	@Column(name = "acRetailFashionManagementInS4Hana", columnDefinition = "int default 0")
	private Integer	acRetailFashionManagementInS4Hana;
	
	@Column(name = "acLogisticsGeneralLoEnhancements", columnDefinition = "int default 0")
	private Integer	acLogisticsGeneralLoEnhancements;
	
	@Column(name = "acFioriUi", columnDefinition = "int default 0")
	private Integer	acFioriUi;
	
	@Column(name = "acFlightScheduling", columnDefinition = "int default 0")
	private Integer	acFlightScheduling;
	
	@Column(name = "acPerishablesProcurement", columnDefinition = "int default 0")
	private Integer	acPerishablesProcurement;
	
	@Column(name = "acPricecatalogue", columnDefinition = "int default 0")
	private Integer	acPricecatalogue;
	
	@Column(name = "acAmountFieldExtension", columnDefinition = "int default 0")
	private Integer	acAmountFieldExtension;
	
	@Column(name = "acChargeback", columnDefinition = "int default 0")
	private Integer	acChargeback;
	
	@Column(name = "acCountrySpecificCustomizingFunctionality", columnDefinition = "int default 0")
	private Integer	acCountrySpecificCustomizingFunctionality;
	
	@Column(name = "acGoodsReceiptCapacityCheck", columnDefinition = "int default 0")
	private Integer	acGoodsReceiptCapacityCheck;
	
	@Column(name = "acProductStructureAndAssemblyManagement", columnDefinition = "int default 0")
	private Integer	acProductStructureAndAssemblyManagement;
	
	@Column(name = "acOilGasSecondaryDistribution", columnDefinition = "int default 0")
	private Integer	acOilGasSecondaryDistribution;
	
	@Column(name = "acInstoreProduction", columnDefinition = "int default 0")
	private Integer	acInstoreProduction;
	
	@Column(name = "acLeaseAccounting", columnDefinition = "int default 0")
	private Integer	acLeaseAccounting;
	
	@Column(name = "acIntrastatReporting", columnDefinition = "int default 0")
	private Integer	acIntrastatReporting;
	
	@Column(name = "acProductDesigner", columnDefinition = "int default 0")
	private Integer	acProductDesigner;
	
	@Column(name = "acExciseDutyWithActiveExtensionEaCp", columnDefinition = "int default 0")
	private Integer	acExciseDutyWithActiveExtensionEaCp;
	
	@Column(name = "acContractAccountsReceivableAndPayable", columnDefinition = "int default 0")
	private Integer	acContractAccountsReceivableAndPayable;
	
	@Column(name = "acBatchMaster", columnDefinition = "int default 0")
	private Integer	acBatchMaster;
	
	@Column(name = "acMaterialRequirementsPlanning", columnDefinition = "int default 0")
	private Integer	acMaterialRequirementsPlanning;
	
	@Column(name = "acManualAccruals", columnDefinition = "int default 0")
	private Integer	acManualAccruals;
	
	@Column(name = "acIndustrySpecificComponentHighTech", columnDefinition = "int default 0")
	private Integer	acIndustrySpecificComponentHighTech;
	
	@Column(name = "acDistributorResellerManagement", columnDefinition = "int default 0")
	private Integer	acDistributorResellerManagement;
	
	@Column(name = "acRetailPricing", columnDefinition = "int default 0")
	private Integer	acRetailPricing;
	
	@Column(name = "acGfClassification", columnDefinition = "int default 0")
	private Integer	acGfClassification;
	
	@Column(name = "acMerchandiseAndAssortmentPlanning", columnDefinition = "int default 0")
	private Integer	acMerchandiseAndAssortmentPlanning;
	
	@Column(name = "acProductionPlanningAndControlPpEnhancements", columnDefinition = "int default 0")
	private Integer	acProductionPlanningAndControlPpEnhancements;
	
	@Column(name = "acSales", columnDefinition = "int default 0")
	private Integer	acSales;
	
	@Column(name = "acDependencies", columnDefinition = "int default 0")
	private Integer	acDependencies;
	
	@Column(name = "acMaintenanceOrders", columnDefinition = "int default 0")
	private Integer	acMaintenanceOrders;
	
	@Column(name = "acBrazil", columnDefinition = "int default 0")
	private Integer	acBrazil;
	
	@Column(name = "acBillingOfQuantity", columnDefinition = "int default 0")
	private Integer	acBillingOfQuantity;
	
	@Column(name = "acBillOfServices", columnDefinition = "int default 0")
	private Integer	acBillOfServices;
	
	@Column(name = "acHydrocarbonProductManagement", columnDefinition = "int default 0")
	private Integer	acHydrocarbonProductManagement;
	
	@Column(name = "acProductCatalog", columnDefinition = "int default 0")
	private Integer	acProductCatalog;
	
	@Column(name = "acBulkSecondaryLogisticsManagement", columnDefinition = "int default 0")
	private Integer	acBulkSecondaryLogisticsManagement;
	
	@Column(name = "acBusinessAnalytics", columnDefinition = "int default 0")
	private Integer	acBusinessAnalytics;
	
	@Column(name = "acPlmEnterpriseSearch", columnDefinition = "int default 0")
	private Integer	acPlmEnterpriseSearch;
	
	@Column(name = "acLabeling", columnDefinition = "int default 0")
	private Integer	acLabeling;
	
	@Column(name = "acRecipeDevelopment", columnDefinition = "int default 0")
	private Integer	acRecipeDevelopment;
	
	@Column(name = "acPortalContent", columnDefinition = "int default 0")
	private Integer	acPortalContent;
	
	@Column(name = "acPortfolioManagement", columnDefinition = "int default 0")
	private Integer	acPortfolioManagement;
	
	@Column(name = "acPricecatalogueOutbound", columnDefinition = "int default 0")
	private Integer	acPricecatalogueOutbound;
	
	@Column(name = "acProducts", columnDefinition = "int default 0")
	private Integer	acProducts;
	
	@Column(name = "acQualityManagement", columnDefinition = "int default 0")
	private Integer	acQualityManagement;
	
	@Column(name = "acHomeBuilidngSolutions", columnDefinition = "int default 0")
	private Integer	acHomeBuilidngSolutions;
	
	@Column(name = "acRecipe", columnDefinition = "int default 0")
	private Integer	acRecipe;
	
	@Column(name = "acClassification", columnDefinition = "int default 0")
	private Integer	acClassification;
	
	@Column(name = "acBopfBusinessObjectFrameworkForAbap", columnDefinition = "int default 0")
	private Integer	acBopfBusinessObjectFrameworkForAbap;
	
	@Column(name = "acSapSimpleFinanceDataMigration", columnDefinition = "int default 0")
	private Integer	acSapSimpleFinanceDataMigration;
	
	@Column(name = "acReplenishment", columnDefinition = "int default 0")
	private Integer	acReplenishment;

	@Column(name = "acAdditionalsManagement", columnDefinition = "int default 0")
	private Integer	acAdditionalsManagement;
	
	@Column(name = "acFreeGoods", columnDefinition = "int default 0")
	private Integer	acFreeGoods;
	
	@Column(name = "acAnalyticalApplications", columnDefinition = "int default 0")
	private Integer	acAnalyticalApplications;
	
	@Column(name = "acRetailDemandManagement", columnDefinition = "int default 0")
	private Integer	acRetailDemandManagement;
	
	@Column(name = "acLogisticsBasicData", columnDefinition = "int default 0")
	private Integer	acLogisticsBasicData;
	
	@Column(name = "acRetailInformationSystem", columnDefinition = "int default 0")
	private Integer	acRetailInformationSystem;
	
	@Column(name = "acPurchaseOrders", columnDefinition = "int default 0")
	private Integer	acPurchaseOrders;
	
	@Column(name = "acRetailLedger", columnDefinition = "int default 0")
	private Integer	acRetailLedger;
	
	@Column(name = "acPromotion", columnDefinition = "int default 0")
	private Integer	acPromotion;
	
	@Column(name = "acRetailMethodOfAccounting", columnDefinition = "int default 0")
	private Integer	acRetailMethodOfAccounting;
	
	@Column(name = "acRetail", columnDefinition = "int default 0")
	private Integer	acRetail;
	
	@Column(name = "acLoadBuilding", columnDefinition = "int default 0")
	private Integer	acLoadBuilding;
	
	@Column(name = "acInventoryManagement", columnDefinition = "int default 0")
	private Integer	acInventoryManagement;
	
	@Column(name = "acSalesPriceValuation", columnDefinition = "int default 0")
	private Integer	acSalesPriceValuation;
	
	@Column(name = "acIndustryRetailAndFashion", columnDefinition = "int default 0")
	private Integer	acIndustryRetailAndFashion;
	
	@Column(name = "acSapRetailStore", columnDefinition = "int default 0")
	private Integer	acSapRetailStore;
	
	@Column(name = "acAutomaticDocumentAdjustment", columnDefinition = "int default 0")
	private Integer	acAutomaticDocumentAdjustment;
	
	@Column(name = "acSalesSupport", columnDefinition = "int default 0")
	private Integer	acSalesSupport;
	
	@Column(name = "acERecruiting", columnDefinition = "int default 0")
	private Integer	acERecruiting;
	
	@Column(name = "acTrainingManagement", columnDefinition = "int default 0")
	private Integer	acTrainingManagement;
	
	@Column(name = "acWasteManagement", columnDefinition = "int default 0")
	private Integer	acWasteManagement;
	
	@Column(name = "acBilling", columnDefinition = "int default 0")
	private Integer	acBilling;
	
	@Column(name = "acOrdersAndContracts", columnDefinition = "int default 0")
	private Integer	acOrdersAndContracts;
	
	@Column(name = "acProjectSystem", columnDefinition = "int default 0")
	private Integer	acProjectSystem;
	
	@Column(name = "acInformationSystem", columnDefinition = "int default 0")
	private Integer	acInformationSystem;
	
	@Column(name = "acMaterialMaster", columnDefinition = "int default 0")
	private Integer	acMaterialMaster;
	
	@Column(name = "acWorkbenchUtilities", columnDefinition = "int default 0")
	private Integer	acWorkbenchUtilities;
	
	@Column(name = "acSoftwareLicenseManagement", columnDefinition = "int default 0")
	private Integer	acSoftwareLicenseManagement;
	
	@Column(name = "acCrossApplicationComponentCaEnhancements", columnDefinition = "int default 0")
	private Integer	acCrossApplicationComponentCaEnhancements;
	
	@Column(name = "acOrderAllocationRun", columnDefinition = "int default 0")
	private Integer	acOrderAllocationRun;
	
	@Column(name = "acNetweaverEnterpriseSearch", columnDefinition = "int default 0")
	private Integer	acNetweaverEnterpriseSearch;
	
	@Column(name = "acMeasurementSystem", columnDefinition = "int default 0")
	private Integer	acMeasurementSystem;
	
	@Column(name = "acFind", columnDefinition = "int default 0")
	private Integer	acFind;
	
	@Column(name = "acProductSafety", columnDefinition = "int default 0")
	private Integer	acProductSafety;
	
	@Column(name = "acExpenditureCertification", columnDefinition = "int default 0")
	private Integer	acExpenditureCertification;
	
	@Column(name = "acRebateProcessing", columnDefinition = "int default 0")
	private Integer	acRebateProcessing;
	
	@Column(name = "acPlmWebUserInterface", columnDefinition = "int default 0")
	private Integer	acPlmWebUserInterface;
	
	@Column(name = "acBillsOfMaterial", columnDefinition = "int default 0")
	private Integer	acBillsOfMaterial;
	
	@Column(name = "acConstructionProgressReport", columnDefinition = "int default 0")
	private Integer	acConstructionProgressReport;
	
	@Column(name = "acRiskAssessment", columnDefinition = "int default 0")
	private Integer	acRiskAssessment;
	
	@Column(name = "acConfirmation", columnDefinition = "int default 0")
	private Integer	acConfirmation;
	
	@Column(name = "acTraderAndSchedulerWorkbench", columnDefinition = "int default 0")
	private Integer	acTraderSchedulerWorkbench;
	
	@Column(name = "acEnetting", columnDefinition = "int default 0")
	private Integer	acEnetting;
	
	@Column(name = "acProductionOrders", columnDefinition = "int default 0")
	private Integer	acProductionOrders;
	
	@Column(name = "acExchanges", columnDefinition = "int default 0")
	private Integer	acExchanges;
	
	@Column(name = "acGoodsMovementValuation", columnDefinition = "int default 0")
	private Integer	acGoodsMovementValuation;
	
	@Column(name = "acMaintenanceProcessing", columnDefinition = "int default 0")
	private Integer	acMaintenanceProcessing;
	
	@Column(name = "acDownstream", columnDefinition = "int default 0")
	private Integer	acDownstream;
	
	@Column(name = "acProductStructure", columnDefinition = "int default 0")
	private Integer	acProductStructure;
	
	@Column(name = "acConsulting", columnDefinition = "int default 0")
	private Integer	acConsulting;
	
	@Column(name = "acScheduling", columnDefinition = "int default 0")
	private Integer	acScheduling;
	
	@Column(name = "acReporting", columnDefinition = "int default 0")
	private Integer	acReporting;
	
	@Column(name = "acKanban", columnDefinition = "int default 0")
	private Integer	acKanban;
	
	@Column(name = "acIndia", columnDefinition = "int default 0")
	private Integer	acIndia;
	
	@Column(name = "acSearch", columnDefinition = "int default 0")
	private Integer	acSearch;
	
	@Column(name = "acRevenueRecognition", columnDefinition = "int default 0")
	private Integer	acRevenueRecognition;
	
	@Column(name = "acSubsequentSettlement", columnDefinition = "int default 0")
	private Integer	acSubsequentSettlement;
	
	@Column(name = "acInterfaceToExternalProjectSoftware", columnDefinition = "int default 0")
	private Integer	acInterfaceToExternalProjectSoftware;
	
	@Column(name = "acBusinessSuiteReleaseInformation", columnDefinition = "int default 0")
	private Integer	acBusinessSuiteReleaseInformation;
	
	@Column(name = "acProductionOptimizationInterfacePoi", columnDefinition = "int default 0")
	private Integer	acProductionOptimizationInterfacePoi;
	
	@Column(name = "acFunctionsForUSFederalGovernment", columnDefinition = "int default 0")
	private Integer	acFunctionsForUSFederalGovernment;
	
	@Column(name = "acIndustrialHygieneAndSafety", columnDefinition = "int default 0")
	private Integer	acIndustrialHygieneAndSafety;
	
	@Column(name = "acOccupationalHealth", columnDefinition = "int default 0")
	private Integer	acOccupationalHealth;
	
	@Column(name = "acBasicDataAndTools", columnDefinition = "int default 0")
	private Integer	acBasicDataAndTools;
	
	@Column(name = "acProductCompliance", columnDefinition = "int default 0")
	private Integer	acProductCompliance;
	
	@Column(name = "acSapProductAndReachCompliance", columnDefinition = "int default 0")
	private Integer	acSapProductAndReachCompliance;
	
	@Column(name = "acExternalServiceAgent", columnDefinition = "int default 0")
	private Integer	acExternalServiceAgent;
	
	@Column(name = "acComplaintsProcessing", columnDefinition = "int default 0")
	private Integer	acComplaintsProcessing;
	
	@Column(name = "acForecastingProcedures", columnDefinition = "int default 0")
	private Integer	acForecastingProcedures;
	
	@Column(name = "acEnhancementsInTransportationBordero", columnDefinition = "int default 0")
	private Integer	acEnhancementsInTransportationBordero;
	
	@Column(name = "acSoftwareMaintenanceProcessing", columnDefinition = "int default 0")
	private Integer	acSoftwareMaintenanceProcessing;
	
	@Column(name = "acPerishablesPlanning", columnDefinition = "int default 0")
	private Integer	acPerishablesPlanning;
	
	@Column(name = "acAlternativeHistoricalDataForForecasting", columnDefinition = "int default 0")
	private Integer	acAlternativeHistoricalDataForForecasting;
	
	@Column(name = "acMerchandiseCategories", columnDefinition = "int default 0")
	private Integer	acMerchandiseCategories;
	
	@Column(name = "acBpForSubcontracting", columnDefinition = "int default 0")
	private Integer	acBpForSubcontracting;
	
	@Column(name = "acCollaborationFolders", columnDefinition = "int default 0")
	private Integer	acCollaborationFolders;
	
	@Column(name = "acGeneralFunctions", columnDefinition = "int default 0")
	private Integer	acGeneralFunctions;
	
	@Column(name = "acRoutingEbomAssignment", columnDefinition = "int default 0")
	private Integer	acRoutingEbomAssignment;
	
	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
		Id = id;
	}

	public long getRequestID() {
		return requestID;
	}

	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}

	public String getScope() {
		return scope;
	}

	public void setScope(String scope) {
		this.scope = scope;
	}

	public Integer getTotalObjectCount() {
		return totalObjectCount;
	}

	public void setTotalObjectCount(Integer totalObjectCount) {
		this.totalObjectCount = totalObjectCount;
	}

	public Integer getUsed_count() {
		return used_count;
	}

	public void setUsed_count(Integer used_count) {
		this.used_count = used_count;
	}

	public Integer getCustClasCount() {
		return custClasCount;
	}

	public void setCustClasCount(Integer custClasCount) {
		this.custClasCount = custClasCount;
	}

	public Integer getCustProgCount() {
		return custProgCount;
	}

	public void setCustProgCount(Integer custProgCount) {
		this.custProgCount = custProgCount;
	}

	public Integer getCustFormCount() {
		return custFormCount;
	}

	public void setCustFormCount(Integer custFormCount) {
		this.custFormCount = custFormCount;
	}

	public Integer getCustFugrCount() {
		return custFugrCount;
	}

	public void setCustFugrCount(Integer custFugrCount) {
		this.custFugrCount = custFugrCount;
	}

	public Integer getCustEnhanCount() {
		return custEnhanCount;
	}

	public void setCustEnhanCount(Integer custEnhanCount) {
		this.custEnhanCount = custEnhanCount;
	}

	public Integer getCustLsmwCount() {
		return custLsmwCount;
	}

	public void setCustLsmwCount(Integer custLsmwCount) {
		this.custLsmwCount = custLsmwCount;
	}

	public Integer getCustWebCount() {
		return custWebCount;
	}

	public void setCustWebCount(Integer custWebCount) {
		this.custWebCount = custWebCount;
	}

	public Integer getCustReptCount() {
		return custReptCount;
	}

	public void setCustReptCount(Integer custReptCount) {
		this.custReptCount = custReptCount;
	}

	public Integer getCustViewCount() {
		return custViewCount;
	}

	public void setCustViewCount(Integer custViewCount) {
		this.custViewCount = custViewCount;
	}

	public Integer getCustIndeCount() {
		return custIndeCount;
	}

	public void setCustIndeCount(Integer custIndeCount) {
		this.custIndeCount = custIndeCount;
	}

	public Integer getCustUsedClasCount() {
		return custUsedClasCount;
	}

	public void setCustUsedClasCount(Integer custUsedClasCount) {
		this.custUsedClasCount = custUsedClasCount;
	}

	public Integer getCustUsedProgCount() {
		return custUsedProgCount;
	}

	public void setCustUsedProgCount(Integer custUsedProgCount) {
		this.custUsedProgCount = custUsedProgCount;
	}

	public Integer getCustUsedFormCount() {
		return custUsedFormCount;
	}

	public void setCustUsedFormCount(Integer custUsedFormCount) {
		this.custUsedFormCount = custUsedFormCount;
	}

	public Integer getCustUsedFugrCount() {
		return custUsedFugrCount;
	}

	public void setCustUsedFugrCount(Integer custUsedFugrCount) {
		this.custUsedFugrCount = custUsedFugrCount;
	}

	public Integer getCustUsedEnhanCount() {
		return custUsedEnhanCount;
	}

	public void setCustUsedEnhanCount(Integer custUsedEnhanCount) {
		this.custUsedEnhanCount = custUsedEnhanCount;
	}

	public Integer getCustUsedLsmwCount() {
		return custUsedLsmwCount;
	}

	public void setCustUsedLsmwCount(Integer custUsedLsmwCount) {
		this.custUsedLsmwCount = custUsedLsmwCount;
	}

	public Integer getCustUsedWebCount() {
		return custUsedWebCount;
	}

	public void setCustUsedWebCount(Integer custUsedWebCount) {
		this.custUsedWebCount = custUsedWebCount;
	}

	public Integer getCustUsedReptCount() {
		return custUsedReptCount;
	}

	public void setCustUsedReptCount(Integer custUsedReptCount) {
		this.custUsedReptCount = custUsedReptCount;
	}

	public Integer getCustUsedViewCount() {
		return custUsedViewCount;
	}

	public void setCustUsedViewCount(Integer custUsedViewCount) {
		this.custUsedViewCount = custUsedViewCount;
	}

	public Integer getCustUsedIndxCount() {
		return custUsedIndxCount;
	}

	public void setCustUsedIndxCount(Integer custUsedIndxCount) {
		this.custUsedIndxCount = custUsedIndxCount;
	}



	public Integer getDefectCount() {
		return defectCount;
	}

	public void setDefectCount(Integer defectCount) {
		this.defectCount = defectCount;
	}

	public Integer getDefectClasCount() {
		return defectClasCount;
	}

	public void setDefectClasCount(Integer defectClasCount) {
		this.defectClasCount = defectClasCount;
	}

	public Integer getDefectProgCount() {
		return defectProgCount;
	}

	public void setDefectProgCount(Integer defectProgCount) {
		this.defectProgCount = defectProgCount;
	}

	public Integer getDefectFormCount() {
		return defectFormCount;
	}

	public void setDefectFormCount(Integer defectFormCount) {
		this.defectFormCount = defectFormCount;
	}

	public Integer getDefectFugrCount() {
		return defectFugrCount;
	}

	public void setDefectFugrCount(Integer defectFugrCount) {
		this.defectFugrCount = defectFugrCount;
	}

	public Integer getDefectEnhanCount() {
		return defectEnhanCount;
	}

	public void setDefectEnhanCount(Integer defectEnhanCount) {
		this.defectEnhanCount = defectEnhanCount;
	}

	public Integer getDefectLsmwCount() {
		return defectLsmwCount;
	}

	public void setDefectLsmwCount(Integer defectLsmwCount) {
		this.defectLsmwCount = defectLsmwCount;
	}

	public Integer getDefectWebCount() {
		return defectWebCount;
	}

	public void setDefectWebCount(Integer defectWebCount) {
		this.defectWebCount = defectWebCount;
	}

	public Integer getDefectReptCount() {
		return defectReptCount;
	}

	public void setDefectReptCount(Integer defectReptCount) {
		this.defectReptCount = defectReptCount;
	}

	public Integer getDefectViewCount() {
		return defectViewCount;
	}

	public void setDefectViewCount(Integer defectViewCount) {
		this.defectViewCount = defectViewCount;
	}

	public Integer getDefectIndeCount() {
		return defectIndeCount;
	}

	public void setDefectIndeCount(Integer defectIndeCount) {
		this.defectIndeCount = defectIndeCount;
	}

	public Integer getErrorClasCount() {
		return errorClasCount;
	}

	public void setErrorClasCount(Integer errorClasCount) {
		this.errorClasCount = errorClasCount;
	}

	public Integer getErrorProgCount() {
		return errorProgCount;
	}

	public void setErrorProgCount(Integer errorProgCount) {
		this.errorProgCount = errorProgCount;
	}

	public Integer getErrorFormCount() {
		return errorFormCount;
	}

	public void setErrorFormCount(Integer errorFormCount) {
		this.errorFormCount = errorFormCount;
	}

	public Integer getErrorFugrCount() {
		return errorFugrCount;
	}

	public void setErrorFugrCount(Integer errorFugrCount) {
		this.errorFugrCount = errorFugrCount;
	}

	public Integer getErrorEnhCount() {
		return errorEnhCount;
	}

	public void setErrorEnhCount(Integer errorEnhCount) {
		this.errorEnhCount = errorEnhCount;
	}

	public Integer getErrorLsmwCount() {
		return errorLsmwCount;
	}

	public void setErrorLsmwCount(Integer errorLsmwCount) {
		this.errorLsmwCount = errorLsmwCount;
	}

	public Integer getErrorWdynCount() {
		return errorWdynCount;
	}

	public void setErrorWdynCount(Integer errorWdynCount) {
		this.errorWdynCount = errorWdynCount;
	}

	public Integer getErrorReptCount() {
		return errorReptCount;
	}

	public void setErrorReptCount(Integer errorReptCount) {
		this.errorReptCount = errorReptCount;
	}

	public Integer getErrorViewCount() {
		return errorViewCount;
	}

	public void setErrorViewCount(Integer errorViewCount) {
		this.errorViewCount = errorViewCount;
	}

	public Integer getErrorIndxCount() {
		return errorIndxCount;
	}

	public void setErrorIndxCount(Integer errorIndxCount) {
		this.errorIndxCount = errorIndxCount;
	}

	public Integer getDefectUsedClasCount() {
		return defectUsedClasCount;
	}

	public void setDefectUsedClasCount(Integer defectUsedClasCount) {
		this.defectUsedClasCount = defectUsedClasCount;
	}

	public Integer getDefectUsedProgCount() {
		return defectUsedProgCount;
	}

	public void setDefectUsedProgCount(Integer defectUsedProgCount) {
		this.defectUsedProgCount = defectUsedProgCount;
	}

	public Integer getDefectUsedFormCount() {
		return defectUsedFormCount;
	}

	public void setDefectUsedFormCount(Integer defectUsedFormCount) {
		this.defectUsedFormCount = defectUsedFormCount;
	}

	public Integer getDefectUsedFugrCount() {
		return defectUsedFugrCount;
	}

	public void setDefectUsedFugrCount(Integer defectUsedFugrCount) {
		this.defectUsedFugrCount = defectUsedFugrCount;
	}

	public Integer getDefectUsedEnhanCount() {
		return defectUsedEnhanCount;
	}

	public void setDefectUsedEnhanCount(Integer defectUsedEnhanCount) {
		this.defectUsedEnhanCount = defectUsedEnhanCount;
	}

	public Integer getDefectUsedLsmwCount() {
		return defectUsedLsmwCount;
	}

	public void setDefectUsedLsmwCount(Integer defectUsedLsmwCount) {
		this.defectUsedLsmwCount = defectUsedLsmwCount;
	}

	public Integer getDefectUsedWebCount() {
		return defectUsedWebCount;
	}

	public void setDefectUsedWebCount(Integer defectUsedWebCount) {
		this.defectUsedWebCount = defectUsedWebCount;
	}

	public Integer getDefectUsedReptCount() {
		return defectUsedReptCount;
	}

	public void setDefectUsedReptCount(Integer defectUsedReptCount) {
		this.defectUsedReptCount = defectUsedReptCount;
	}

	public Integer getDefectUsedViewCount() {
		return defectUsedViewCount;
	}

	public void setDefectUsedViewCount(Integer defectUsedViewCount) {
		this.defectUsedViewCount = defectUsedViewCount;
	}

	public Integer getDefectUsedIndxCount() {
		return defectUsedIndxCount;
	}

	public void setDefectUsedIndxCount(Integer defectUsedIndxCount) {
		this.defectUsedIndxCount = defectUsedIndxCount;
	}

	public Integer getErrorUsedClasCount() {
		return errorUsedClasCount;
	}

	public void setErrorUsedClasCount(Integer errorUsedClasCount) {
		this.errorUsedClasCount = errorUsedClasCount;
	}

	public Integer getErrorUsedProgCount() {
		return errorUsedProgCount;
	}

	public void setErrorUsedProgCount(Integer errorUsedProgCount) {
		this.errorUsedProgCount = errorUsedProgCount;
	}

	public Integer getErrorUsedFormCount() {
		return errorUsedFormCount;
	}

	public void setErrorUsedFormCount(Integer errorUsedFormCount) {
		this.errorUsedFormCount = errorUsedFormCount;
	}

	public Integer getErrorUsedFugrCount() {
		return errorUsedFugrCount;
	}

	public void setErrorUsedFugrCount(Integer errorUsedFugrCount) {
		this.errorUsedFugrCount = errorUsedFugrCount;
	}

	public Integer getErrorUsedEnhCount() {
		return errorUsedEnhCount;
	}

	public void setErrorUsedEnhCount(Integer errorUsedEnhCount) {
		this.errorUsedEnhCount = errorUsedEnhCount;
	}

	public Integer getErrorUsedLsmwCount() {
		return errorUsedLsmwCount;
	}

	public void setErrorUsedLsmwCount(Integer errorUsedLsmwCount) {
		this.errorUsedLsmwCount = errorUsedLsmwCount;
	}

	public Integer getErrorUsedWdynCount() {
		return errorUsedWdynCount;
	}

	public void setErrorUsedWdynCount(Integer errorUsedWdynCount) {
		this.errorUsedWdynCount = errorUsedWdynCount;
	}

	public Integer getErrorUsedReptCount() {
		return errorUsedReptCount;
	}

	public void setErrorUsedReptCount(Integer errorUsedReptCount) {
		this.errorUsedReptCount = errorUsedReptCount;
	}

	public Integer getErrorUsedViewCount() {
		return errorUsedViewCount;
	}

	public void setErrorUsedViewCount(Integer errorUsedViewCount) {
		this.errorUsedViewCount = errorUsedViewCount;
	}

	public Integer getErrorUsedIndxCount() {
		return errorUsedIndxCount;
	}

	public void setErrorUsedIndxCount(Integer errorUsedIndxCount) {
		this.errorUsedIndxCount = errorUsedIndxCount;
	}

	public Integer getMandatory_Category_count() {
		return mandatory_Category_count;
	}

	public void setMandatory_Category_count(Integer mandatory_Category_count) {
		this.mandatory_Category_count = mandatory_Category_count;
	}

	public Integer getApp_level_category_count() {
		return app_level_category_count;
	}

	public void setApp_level_category_count(Integer app_level_category_count) {
		this.app_level_category_count = app_level_category_count;
	}

	public Integer getDb_level_category_count() {
		return db_level_category_count;
	}

	public void setDb_level_category_count(Integer db_level_category_count) {
		this.db_level_category_count = db_level_category_count;
	}

	public Integer getHousekeeping_for_HANA_category_count() {
		return housekeeping_for_HANA_category_count;
	}

	public void setHousekeeping_for_HANA_category_count(Integer housekeeping_for_HANA_category_count) {
		this.housekeeping_for_HANA_category_count = housekeeping_for_HANA_category_count;
	}

	public Integer getObjectOutputManagement() {
		return objectOutputManagement;
	}

	public void setObjectOutputManagement(Integer objectOutputManagement) {
		this.objectOutputManagement = objectOutputManagement;
	}

	public Integer getObjectCustomFields() {
		return objectCustomFields;
	}

	public void setObjectCustomFields(Integer objectCustomFields) {
		this.objectCustomFields = objectCustomFields;
	}

	public Integer getOptionalCount() {
		return optionalCount;
	}

	public void setOptionalCount(Integer optionalCount) {
		this.optionalCount = optionalCount;
	}

	public Integer getErrorRemediationMandatory() {
		return errorRemediationMandatory;
	}

	public void setErrorRemediationMandatory(Integer errorRemediationMandatory) {
		this.errorRemediationMandatory = errorRemediationMandatory;
	}

	public Integer getErrorRemediationAppLevel() {
		return errorRemediationAppLevel;
	}

	public void setErrorRemediationAppLevel(Integer errorRemediationAppLevel) {
		this.errorRemediationAppLevel = errorRemediationAppLevel;
	}

	public Integer getErrorRemediationDbLevel() {
		return errorRemediationDbLevel;
	}

	public void setErrorRemediationDbLevel(Integer errorRemediationDbLevel) {
		this.errorRemediationDbLevel = errorRemediationDbLevel;
	}

	public Integer getErrorRemediationHouseKeeping() {
		return errorRemediationHouseKeeping;
	}

	public void setErrorRemediationHouseKeeping(Integer errorRemediationHouseKeeping) {
		this.errorRemediationHouseKeeping = errorRemediationHouseKeeping;
	}

	public Integer getErrorRemediationOptional() {
		return errorRemediationOptional;
	}

	public void setErrorRemediationOptional(Integer errorRemediationOptional) {
		this.errorRemediationOptional = errorRemediationOptional;
	}

	public Integer getMandUsedCount() {
		return mandUsedCount;
	}

	public void setMandUsedCount(Integer mandUsedCount) {
		this.mandUsedCount = mandUsedCount;
	}

	public Integer getObjectUsedRemAppLevel() {
		return objectUsedRemAppLevel;
	}

	public void setObjectUsedRemAppLevel(Integer objectUsedRemAppLevel) {
		this.objectUsedRemAppLevel = objectUsedRemAppLevel;
	}

	public Integer getObjectUsedRemDbLevel() {
		return objectUsedRemDbLevel;
	}

	public void setObjectUsedRemDbLevel(Integer objectUsedRemDbLevel) {
		this.objectUsedRemDbLevel = objectUsedRemDbLevel;
	}

	public Integer getObjectUsedRemHouseKeeping() {
		return objectUsedRemHouseKeeping;
	}

	public void setObjectUsedRemHouseKeeping(Integer objectUsedRemHouseKeeping) {
		this.objectUsedRemHouseKeeping = objectUsedRemHouseKeeping;
	}

	public Integer getObjectUsedOutputMgmt() {
		return objectUsedOutputMgmt;
	}

	public void setObjectUsedOutputMgmt(Integer objectUsedOutputMgmt) {
		this.objectUsedOutputMgmt = objectUsedOutputMgmt;
	}

	public Integer getObjectUsedCustomFields() {
		return objectUsedCustomFields;
	}

	public void setObjectUsedCustomFields(Integer objectUsedCustomFields) {
		this.objectUsedCustomFields = objectUsedCustomFields;
	}

	public Integer getOptionalUsedCount() {
		return optionalUsedCount;
	}

	public void setOptionalUsedCount(Integer optionalUsedCount) {
		this.optionalUsedCount = optionalUsedCount;
	}

	public Integer getErrorUsedRemMandatory() {
		return errorUsedRemMandatory;
	}

	public void setErrorUsedRemMandatory(Integer errorUsedRemMandatory) {
		this.errorUsedRemMandatory = errorUsedRemMandatory;
	}

	public Integer getErrorUsedRemAppLevel() {
		return errorUsedRemAppLevel;
	}

	public void setErrorUsedRemAppLevel(Integer errorUsedRemAppLevel) {
		this.errorUsedRemAppLevel = errorUsedRemAppLevel;
	}

	public Integer getErrorUsedRemDbLevel() {
		return errorUsedRemDbLevel;
	}

	public void setErrorUsedRemDbLevel(Integer errorUsedRemDbLevel) {
		this.errorUsedRemDbLevel = errorUsedRemDbLevel;
	}

	public Integer getErrorUsedRemHouseKeeping() {
		return errorUsedRemHouseKeeping;
	}

	public void setErrorUsedRemHouseKeeping(Integer errorUsedRemHouseKeeping) {
		this.errorUsedRemHouseKeeping = errorUsedRemHouseKeeping;
	}

	public Integer getErrorUsedRemOptional() {
		return errorUsedRemOptional;
	}

	public void setErrorUsedRemOptional(Integer errorUsedRemOptional) {
		this.errorUsedRemOptional = errorUsedRemOptional;
	}

	public Integer getMigrationAutomatedCount() {
		return migrationAutomatedCount;
	}

	public void setMigrationAutomatedCount(Integer migrationAutomatedCount) {
		this.migrationAutomatedCount = migrationAutomatedCount;
	}

	public Integer getErrorAutomationY() {
		return errorAutomationY;
	}

	public void setErrorAutomationY(Integer errorAutomationY) {
		this.errorAutomationY = errorAutomationY;
	}

	public Integer getDbMinAmtRepeatDbAutoN() {
		return dbMinAmtRepeatDbAutoN;
	}

	public void setDbMinAmtRepeatDbAutoN(Integer dbMinAmtRepeatDbAutoN) {
		this.dbMinAmtRepeatDbAutoN = dbMinAmtRepeatDbAutoN;
	}

	public Integer getDbMinAmtJoinSelectStmtAutoN() {
		return dbMinAmtJoinSelectStmtAutoN;
	}

	public void setDbMinAmtJoinSelectStmtAutoN(Integer dbMinAmtJoinSelectStmtAutoN) {
		this.dbMinAmtJoinSelectStmtAutoN = dbMinAmtJoinSelectStmtAutoN;
	}

	public Integer getDbMinAmtAllEntriesAutoN() {
		return dbMinAmtAllEntriesAutoN;
	}

	public void setDbMinAmtAllEntriesAutoN(Integer dbMinAmtAllEntriesAutoN) {
		this.dbMinAmtAllEntriesAutoN = dbMinAmtAllEntriesAutoN;
	}

	public Integer getDbMinAmtCurrencyConvAutoN() {
		return dbMinAmtCurrencyConvAutoN;
	}

	public void setDbMinAmtCurrencyConvAutoN(Integer dbMinAmtCurrencyConvAutoN) {
		this.dbMinAmtCurrencyConvAutoN = dbMinAmtCurrencyConvAutoN;
	}

	public Integer getDbMinAmtFaeJoinAutoN() {
		return dbMinAmtFaeJoinAutoN;
	}

	public void setDbMinAmtFaeJoinAutoN(Integer dbMinAmtFaeJoinAutoN) {
		this.dbMinAmtFaeJoinAutoN = dbMinAmtFaeJoinAutoN;
	}

	public Integer getDbMinAmtAggStmtCollectAutoN() {
		return dbMinAmtAggStmtCollectAutoN;
	}

	public void setDbMinAmtAggStmtCollectAutoN(Integer dbMinAmtAggStmtCollectAutoN) {
		this.dbMinAmtAggStmtCollectAutoN = dbMinAmtAggStmtCollectAutoN;
	}

	public Integer getDbMinAmtRepeatDbAutoNError() {
		return dbMinAmtRepeatDbAutoNError;
	}

	public void setDbMinAmtRepeatDbAutoNError(Integer dbMinAmtRepeatDbAutoNError) {
		this.dbMinAmtRepeatDbAutoNError = dbMinAmtRepeatDbAutoNError;
	}

	public Integer getDbMinAmtJoinSelectAutoNError() {
		return dbMinAmtJoinSelectAutoNError;
	}

	public void setDbMinAmtJoinSelectAutoNError(Integer dbMinAmtJoinSelectAutoNError) {
		this.dbMinAmtJoinSelectAutoNError = dbMinAmtJoinSelectAutoNError;
	}

	public Integer getDbMinAmtAllEntriesAutoNError() {
		return dbMinAmtAllEntriesAutoNError;
	}

	public void setDbMinAmtAllEntriesAutoNError(Integer dbMinAmtAllEntriesAutoNError) {
		this.dbMinAmtAllEntriesAutoNError = dbMinAmtAllEntriesAutoNError;
	}

	public Integer getDbMinAmtCurrencyAutoNError() {
		return dbMinAmtCurrencyAutoNError;
	}

	public void setDbMinAmtCurrencyAutoNError(Integer dbMinAmtCurrencyAutoNError) {
		this.dbMinAmtCurrencyAutoNError = dbMinAmtCurrencyAutoNError;
	}

	public Integer getDbMinAmtFaeJoinAutoNError() {
		return dbMinAmtFaeJoinAutoNError;
	}

	public void setDbMinAmtFaeJoinAutoNError(Integer dbMinAmtFaeJoinAutoNError) {
		this.dbMinAmtFaeJoinAutoNError = dbMinAmtFaeJoinAutoNError;
	}

	public Integer getDbMinAmtAggStmtAutoNError() {
		return dbMinAmtAggStmtAutoNError;
	}

	public void setDbMinAmtAggStmtAutoNError(Integer dbMinAmtAggStmtAutoNError) {
		this.dbMinAmtAggStmtAutoNError = dbMinAmtAggStmtAutoNError;
	}

	public Integer getTotalImpactUsageCount() {
		return totalImpactUsageCount;
	}

	public void setTotalImpactUsageCount(Integer totalImpactUsageCount) {
		this.totalImpactUsageCount = totalImpactUsageCount;
	}

	public Integer getMandatoryAutoY() {
		return mandatoryAutoY;
	}

	public void setMandatoryAutoY(Integer mandatoryAutoY) {
		this.mandatoryAutoY = mandatoryAutoY;
	}

	public Integer getHkAutoY() {
		return hkAutoY;
	}

	public void setHkAutoY(Integer hkAutoY) {
		this.hkAutoY = hkAutoY;
	}

	public Integer getDbLevelAutoY() {
		return dbLevelAutoY;
	}

	public void setDbLevelAutoY(Integer dbLevelAutoY) {
		this.dbLevelAutoY = dbLevelAutoY;
	}

	public Integer getAppLevelAutoY() {
		return appLevelAutoY;
	}

	public void setAppLevelAutoY(Integer appLevelAutoY) {
		this.appLevelAutoY = appLevelAutoY;
	}

	public Integer getMandatoryAutoN() {
		return mandatoryAutoN;
	}

	public void setMandatoryAutoN(Integer mandatoryAutoN) {
		this.mandatoryAutoN = mandatoryAutoN;
	}

	public Integer getHkAutoN() {
		return hkAutoN;
	}

	public void setHkAutoN(Integer hkAutoN) {
		this.hkAutoN = hkAutoN;
	}

	public Integer getDbLevelAutoN() {
		return dbLevelAutoN;
	}

	public void setDbLevelAutoN(Integer dbLevelAutoN) {
		this.dbLevelAutoN = dbLevelAutoN;
	}

	public Integer getAppLevelAutoN() {
		return appLevelAutoN;
	}

	public void setAppLevelAutoN(Integer appLevelAutoN) {
		this.appLevelAutoN = appLevelAutoN;
	}

	public Integer getErrorMandatoryAutoY() {
		return errorMandatoryAutoY;
	}

	public void setErrorMandatoryAutoY(Integer errorMandatoryAutoY) {
		this.errorMandatoryAutoY = errorMandatoryAutoY;
	}

	public Integer getErrorHkAutoY() {
		return errorHkAutoY;
	}

	public void setErrorHkAutoY(Integer errorHkAutoY) {
		this.errorHkAutoY = errorHkAutoY;
	}

	public Integer getErrorDbLevelAutoY() {
		return errorDbLevelAutoY;
	}

	public void setErrorDbLevelAutoY(Integer errorDbLevelAutoY) {
		this.errorDbLevelAutoY = errorDbLevelAutoY;
	}

	public Integer getErrorAppLevelAutoY() {
		return errorAppLevelAutoY;
	}

	public void setErrorAppLevelAutoY(Integer errorAppLevelAutoY) {
		this.errorAppLevelAutoY = errorAppLevelAutoY;
	}

	public Integer getErrorMandatoryAutoN() {
		return errorMandatoryAutoN;
	}

	public void setErrorMandatoryAutoN(Integer errorMandatoryAutoN) {
		this.errorMandatoryAutoN = errorMandatoryAutoN;
	}

	public Integer getErrorHkAutoN() {
		return errorHkAutoN;
	}

	public void setErrorHkAutoN(Integer errorHkAutoN) {
		this.errorHkAutoN = errorHkAutoN;
	}

	public Integer getErrorDbLevelAutoN() {
		return errorDbLevelAutoN;
	}

	public void setErrorDbLevelAutoN(Integer errorDbLevelAutoN) {
		this.errorDbLevelAutoN = errorDbLevelAutoN;
	}

	public Integer getErrorAppLevelAutoN() {
		return errorAppLevelAutoN;
	}

	public void setErrorAppLevelAutoN(Integer errorAppLevelAutoN) {
		this.errorAppLevelAutoN = errorAppLevelAutoN;
	}

	public Integer getManFunSemanticAutoY() {
		return manFunSemanticAutoY;
	}

	public void setManFunSemanticAutoY(Integer manFunSemanticAutoY) {
		this.manFunSemanticAutoY = manFunSemanticAutoY;
	}

	public Integer getManFunSemanticAutoN() {
		return manFunSemanticAutoN;
	}

	public void setManFunSemanticAutoN(Integer manFunSemanticAutoN) {
		this.manFunSemanticAutoN = manFunSemanticAutoN;
	}

	public Integer getManFunHanaSortAutoY() {
		return manFunHanaSortAutoY;
	}

	public void setManFunHanaSortAutoY(Integer manFunHanaSortAutoY) {
		this.manFunHanaSortAutoY = manFunHanaSortAutoY;
	}

	public Integer getManFunHanaSortAutoN() {
		return manFunHanaSortAutoN;
	}

	public void setManFunHanaSortAutoN(Integer manFunHanaSortAutoN) {
		this.manFunHanaSortAutoN = manFunHanaSortAutoN;
	}

	public Integer getManSynValidAutoY() {
		return manSynValidAutoY;
	}

	public void setManSynValidAutoY(Integer manSynValidAutoY) {
		this.manSynValidAutoY = manSynValidAutoY;
	}

	public Integer getManSynValidAutoN() {
		return manSynValidAutoN;
	}

	public void setManSynValidAutoN(Integer manSynValidAutoN) {
		this.manSynValidAutoN = manSynValidAutoN;
	}

	public Integer getManSynPotentialAutoY() {
		return manSynPotentialAutoY;
	}

	public void setManSynPotentialAutoY(Integer manSynPotentialAutoY) {
		this.manSynPotentialAutoY = manSynPotentialAutoY;
	}

	public Integer getManSynPotentialAutoN() {
		return manSynPotentialAutoN;
	}

	public void setManSynPotentialAutoN(Integer manSynPotentialAutoN) {
		this.manSynPotentialAutoN = manSynPotentialAutoN;
	}

	public Integer getManSemPoolClustAutoY() {
		return manSemPoolClustAutoY;
	}

	public void setManSemPoolClustAutoY(Integer manSemPoolClustAutoY) {
		this.manSemPoolClustAutoY = manSemPoolClustAutoY;
	}

	public Integer getManSemPoolClustAutoN() {
		return manSemPoolClustAutoN;
	}

	public void setManSemPoolClustAutoN(Integer manSemPoolClustAutoN) {
		this.manSemPoolClustAutoN = manSemPoolClustAutoN;
	}

	public Integer getManSemDbPoolAutoY() {
		return manSemDbPoolAutoY;
	}

	public void setManSemDbPoolAutoY(Integer manSemDbPoolAutoY) {
		this.manSemDbPoolAutoY = manSemDbPoolAutoY;
	}

	public Integer getManSemDbPoolAutoN() {
		return manSemDbPoolAutoN;
	}

	public void setManSemDbPoolAutoN(Integer manSemDbPoolAutoN) {
		this.manSemDbPoolAutoN = manSemDbPoolAutoN;
	}

	public Integer getManVSynNsqlAutoY() {
		return manVSynNsqlAutoY;
	}

	public void setManVSynNsqlAutoY(Integer manVSynNsqlAutoY) {
		this.manVSynNsqlAutoY = manVSynNsqlAutoY;
	}

	public Integer getManVSynNsqlAutoN() {
		return manVSynNsqlAutoN;
	}

	public void setManVSynNsqlAutoN(Integer manVSynNsqlAutoN) {
		this.manVSynNsqlAutoN = manVSynNsqlAutoN;
	}

	public Integer getManVSynDDICFmlAutoY() {
		return manVSynDDICFmlAutoY;
	}

	public void setManVSynDDICFmlAutoY(Integer manVSynDDICFmlAutoY) {
		this.manVSynDDICFmlAutoY = manVSynDDICFmlAutoY;
	}

	public Integer getManVSynDDICFmlAutoN() {
		return manVSynDDICFmlAutoN;
	}

	public void setManVSynDDICFmlAutoN(Integer manVSynDDICFmlAutoN) {
		this.manVSynDDICFmlAutoN = manVSynDDICFmlAutoN;
	}

	public Integer getManVSynAdbcUsAutoY() {
		return manVSynAdbcUsAutoY;
	}

	public void setManVSynAdbcUsAutoY(Integer manVSynAdbcUsAutoY) {
		this.manVSynAdbcUsAutoY = manVSynAdbcUsAutoY;
	}

	public Integer getManVSynAdbcUsAutoN() {
		return manVSynAdbcUsAutoN;
	}

	public void setManVSynAdbcUsAutoN(Integer manVSynAdbcUsAutoN) {
		this.manVSynAdbcUsAutoN = manVSynAdbcUsAutoN;
	}

	public Integer getManHSortUnInternalAutoY() {
		return manHSortUnInternalAutoY;
	}

	public void setManHSortUnInternalAutoY(Integer manHSortUnInternalAutoY) {
		this.manHSortUnInternalAutoY = manHSortUnInternalAutoY;
	}

	public Integer getManHSortUnInternalAutoN() {
		return manHSortUnInternalAutoN;
	}

	public void setManHSortUnInternalAutoN(Integer manHSortUnInternalAutoN) {
		this.manHSortUnInternalAutoN = manHSortUnInternalAutoN;
	}

	public Integer getManHSortSelWKyAutoY() {
		return manHSortSelWKyAutoY;
	}

	public void setManHSortSelWKyAutoY(Integer manHSortSelWKyAutoY) {
		this.manHSortSelWKyAutoY = manHSortSelWKyAutoY;
	}

	public Integer getManHSortSelWKyAutoN() {
		return manHSortSelWKyAutoN;
	}

	public void setManHSortSelWKyAutoN(Integer manHSortSelWKyAutoN) {
		this.manHSortSelWKyAutoN = manHSortSelWKyAutoN;
	}

	public Integer getManHSortRBWSOAutoY() {
		return manHSortRBWSOAutoY;
	}

	public void setManHSortRBWSOAutoY(Integer manHSortRBWSOAutoY) {
		this.manHSortRBWSOAutoY = manHSortRBWSOAutoY;
	}

	public Integer getManHSortRBWSOAutoN() {
		return manHSortRBWSOAutoN;
	}

	public void setManHSortRBWSOAutoN(Integer manHSortRBWSOAutoN) {
		this.manHSortRBWSOAutoN = manHSortRBWSOAutoN;
	}

	public Integer getManHSortDelAdjAutoY() {
		return manHSortDelAdjAutoY;
	}

	public void setManHSortDelAdjAutoY(Integer manHSortDelAdjAutoY) {
		this.manHSortDelAdjAutoY = manHSortDelAdjAutoY;
	}

	public Integer getManHSortDelAdjAutoN() {
		return manHSortDelAdjAutoN;
	}

	public void setManHSortDelAdjAutoN(Integer manHSortDelAdjAutoN) {
		this.manHSortDelAdjAutoN = manHSortDelAdjAutoN;
	}

	public Integer getManHSortConStmtAutoY() {
		return manHSortConStmtAutoY;
	}

	public void setManHSortConStmtAutoY(Integer manHSortConStmtAutoY) {
		this.manHSortConStmtAutoY = manHSortConStmtAutoY;
	}

	public Integer getManHSortConStmtAutoN() {
		return manHSortConStmtAutoN;
	}

	public void setManHSortConStmtAutoN(Integer manHSortConStmtAutoN) {
		this.manHSortConStmtAutoN = manHSortConStmtAutoN;
	}

	public Integer getHkHsStmtDbHintUsed() {
		return hkHsStmtDbHintUsed;
	}

	public void setHkHsStmtDbHintUsed(Integer hkHsStmtDbHintUsed) {
		this.hkHsStmtDbHintUsed = hkHsStmtDbHintUsed;
	}

	public Integer getHkHSLoadByTableBuff() {
		return hkHSLoadByTableBuff;
	}

	public void setHkHSLoadByTableBuff(Integer hkHSLoadByTableBuff) {
		this.hkHSLoadByTableBuff = hkHSLoadByTableBuff;
	}

	public Integer getHkHsStmtDbHintUsedError() {
		return hkHsStmtDbHintUsedError;
	}

	public void setHkHsStmtDbHintUsedError(Integer hkHsStmtDbHintUsedError) {
		this.hkHsStmtDbHintUsedError = hkHsStmtDbHintUsedError;
	}

	public Integer getHkHSLoadByTableBuffError() {
		return hkHSLoadByTableBuffError;
	}

	public void setHkHSLoadByTableBuffError(Integer hkHSLoadByTableBuffError) {
		this.hkHSLoadByTableBuffError = hkHSLoadByTableBuffError;
	}

	public Integer getAppHSLoad() {
		return appHSLoad;
	}

	public void setAppHSLoad(Integer appHSLoad) {
		this.appHSLoad = appHSLoad;
	}

	public Integer getAppHSLoadError() {
		return appHSLoadError;
	}

	public void setAppHSLoadError(Integer appHSLoadError) {
		this.appHSLoadError = appHSLoadError;
	}

	public Integer getAppLoadOptimizeDb() {
		return appLoadOptimizeDb;
	}

	public void setAppLoadOptimizeDb(Integer appLoadOptimizeDb) {
		this.appLoadOptimizeDb = appLoadOptimizeDb;
	}

	public Integer getAppLoadOptimizeDbError() {
		return appLoadOptimizeDbError;
	}

	public void setAppLoadOptimizeDbError(Integer appLoadOptimizeDbError) {
		this.appLoadOptimizeDbError = appLoadOptimizeDbError;
	}

	public Integer getAppLoadPerfGen() {
		return appLoadPerfGen;
	}

	public void setAppLoadPerfGen(Integer appLoadPerfGen) {
		this.appLoadPerfGen = appLoadPerfGen;
	}

	public Integer getAppLoadPerfGenError() {
		return appLoadPerfGenError;
	}

	public void setAppLoadPerfGenError(Integer appLoadPerfGenError) {
		this.appLoadPerfGenError = appLoadPerfGenError;
	}

	public Integer getAppResSmlPerfGen() {
		return appResSmlPerfGen;
	}

	public void setAppResSmlPerfGen(Integer appResSmlPerfGen) {
		this.appResSmlPerfGen = appResSmlPerfGen;
	}

	public Integer getAppResSmlPerfGenError() {
		return appResSmlPerfGenError;
	}

	public void setAppResSmlPerfGenError(Integer appResSmlPerfGenError) {
		this.appResSmlPerfGenError = appResSmlPerfGenError;
	}

	public Integer getAppMinDataPerfGen() {
		return appMinDataPerfGen;
	}

	public void setAppMinDataPerfGen(Integer appMinDataPerfGen) {
		this.appMinDataPerfGen = appMinDataPerfGen;
	}

	public Integer getAppMinDataPerfGenError() {
		return appMinDataPerfGenError;
	}

	public void setAppMinDataPerfGenError(Integer appMinDataPerfGenError) {
		this.appMinDataPerfGenError = appMinDataPerfGenError;
	}

	public Integer getAppMinDataHS() {
		return appMinDataHS;
	}

	public void setAppMinDataHS(Integer appMinDataHS) {
		this.appMinDataHS = appMinDataHS;
	}

	public Integer getAppMinDataHSError() {
		return appMinDataHSError;
	}

	public void setAppMinDataHSError(Integer appMinDataHSError) {
		this.appMinDataHSError = appMinDataHSError;
	}

	public Integer getOutputMgmtCustomFields() {
		return outputMgmtCustomFields;
	}

	public void setOutputMgmtCustomFields(Integer outputMgmtCustomFields) {
		this.outputMgmtCustomFields = outputMgmtCustomFields;
	}

	public Integer getRemCategoryObj() {
		return remCategoryObj;
	}

	public void setRemCategoryObj(Integer remCategoryObj) {
		this.remCategoryObj = remCategoryObj;
	}

	public Integer getRemCategoryObjError() {
		return remCategoryObjError;
	}

	public void setRemCategoryObjError(Integer remCategoryObjError) {
		this.remCategoryObjError = remCategoryObjError;
	}

	public Integer getErrorHanaDbCount() {
		return errorHanaDbCount;
	}

	public void setErrorHanaDbCount(Integer errorHanaDbCount) {
		this.errorHanaDbCount = errorHanaDbCount;
	}

	public Integer getAcFinanceIntlTrade() {
		return acFinanceIntlTrade;
	}

	public void setAcFinanceIntlTrade(Integer acFinanceIntlTrade) {
		this.acFinanceIntlTrade = acFinanceIntlTrade;
	}

	public Integer getAcFinanceMisc() {
		return acFinanceMisc;
	}

	public void setAcFinanceMisc(Integer acFinanceMisc) {
		this.acFinanceMisc = acFinanceMisc;
	}

	public Integer getAcFinanceCntrl() {
		return acFinanceCntrl;
	}

	public void setAcFinanceCntrl(Integer acFinanceCntrl) {
		this.acFinanceCntrl = acFinanceCntrl;
	}

	public Integer getAcMasterData() {
		return acMasterData;
	}

	public void setAcMasterData(Integer acMasterData) {
		this.acMasterData = acMasterData;
	}

	public Integer getAcIndustryRetail() {
		return acIndustryRetail;
	}

	public void setAcIndustryRetail(Integer acIndustryRetail) {
		this.acIndustryRetail = acIndustryRetail;
	}

	public Integer getAcLogisticsMMIM() {
		return acLogisticsMMIM;
	}

	public void setAcLogisticsMMIM(Integer acLogisticsMMIM) {
		this.acLogisticsMMIM = acLogisticsMMIM;
	}

	public Integer getAcProcurement() {
		return acProcurement;
	}

	public void setAcProcurement(Integer acProcurement) {
		this.acProcurement = acProcurement;
	}

	public Integer getAcLogisticsEHS() {
		return acLogisticsEHS;
	}

	public void setAcLogisticsEHS(Integer acLogisticsEHS) {
		this.acLogisticsEHS = acLogisticsEHS;
	}

	public Integer getAcSalesDistribution() {
		return acSalesDistribution;
	}

	public void setAcSalesDistribution(Integer acSalesDistribution) {
		this.acSalesDistribution = acSalesDistribution;
	}

	public Integer getAcIndustryBeverage() {
		return acIndustryBeverage;
	}

	public void setAcIndustryBeverage(Integer acIndustryBeverage) {
		this.acIndustryBeverage = acIndustryBeverage;
	}

	public Integer getAcIndustryDimpEco() {
		return acIndustryDimpEco;
	}

	public void setAcIndustryDimpEco(Integer acIndustryDimpEco) {
		this.acIndustryDimpEco = acIndustryDimpEco;
	}

	public Integer getAcFinanceGeneral() {
		return acFinanceGeneral;
	}

	public void setAcFinanceGeneral(Integer acFinanceGeneral) {
		this.acFinanceGeneral = acFinanceGeneral;
	}

	public Integer getAcLogisticsPP() {
		return acLogisticsPP;
	}

	public void setAcLogisticsPP(Integer acLogisticsPP) {
		this.acLogisticsPP = acLogisticsPP;
	}

	public Integer getAcIndustryPubSec() {
		return acIndustryPubSec;
	}

	public void setAcIndustryPubSec(Integer acIndustryPubSec) {
		this.acIndustryPubSec = acIndustryPubSec;
	}

	public Integer getAcIndustryDimpHt() {
		return acIndustryDimpHt;
	}

	public void setAcIndustryDimpHt(Integer acIndustryDimpHt) {
		this.acIndustryDimpHt = acIndustryDimpHt;
	}

	public Integer getAcIndustryCross() {
		return acIndustryCross;
	}

	public void setAcIndustryCross(Integer acIndustryCross) {
		this.acIndustryCross = acIndustryCross;
	}

	public Integer getAcIndustryAeroDef() {
		return acIndustryAeroDef;
	}

	public void setAcIndustryAeroDef(Integer acIndustryAeroDef) {
		this.acIndustryAeroDef = acIndustryAeroDef;
	}

	public Integer getAcLogisticsPm() {
		return acLogisticsPm;
	}

	public void setAcLogisticsPm(Integer acLogisticsPm) {
		this.acLogisticsPm = acLogisticsPm;
	}

	public Integer getAcLogisticsPlm() {
		return acLogisticsPlm;
	}

	public void setAcLogisticsPlm(Integer acLogisticsPlm) {
		this.acLogisticsPlm = acLogisticsPlm;
	}

	public Integer getAcIndustryAuto() {
		return acIndustryAuto;
	}

	public void setAcIndustryAuto(Integer acIndustryAuto) {
		this.acIndustryAuto = acIndustryAuto;
	}

	public Integer getAcFinanceCashMgmt() {
		return acFinanceCashMgmt;
	}

	public void setAcFinanceCashMgmt(Integer acFinanceCashMgmt) {
		this.acFinanceCashMgmt = acFinanceCashMgmt;
	}

	public Integer getAcMiscellaneous() {
		return acMiscellaneous;
	}

	public void setAcMiscellaneous(Integer acMiscellaneous) {
		this.acMiscellaneous = acMiscellaneous;
	}

	public Integer getAcMM() {
		return acMM;
	}

	public void setAcMM(Integer acMM) {
		this.acMM = acMM;
	}

	public Integer getAcLogisticsPS() {
		return acLogisticsPS;
	}

	public void setAcLogisticsPS(Integer acLogisticsPS) {
		this.acLogisticsPS = acLogisticsPS;
	}

	public Integer getAcLogisticsATP() {
		return acLogisticsATP;
	}

	public void setAcLogisticsATP(Integer acLogisticsATP) {
		this.acLogisticsATP = acLogisticsATP;
	}

	public Integer getAcIndustryMedia() {
		return acIndustryMedia;
	}

	public void setAcIndustryMedia(Integer acIndustryMedia) {
		this.acIndustryMedia = acIndustryMedia;
	}

	public Integer getAcFinAssetAccount() {
		return acFinAssetAccount;
	}

	public void setAcFinAssetAccount(Integer acFinAssetAccount) {
		this.acFinAssetAccount = acFinAssetAccount;
	}

	public Integer getAcCrossTopics() {
		return acCrossTopics;
	}

	public void setAcCrossTopics(Integer acCrossTopics) {
		this.acCrossTopics = acCrossTopics;
	}

	public Integer getAcBatchMasterData() {
		return acBatchMasterData;
	}

	public void setAcBatchMasterData(Integer acBatchMasterData) {
		this.acBatchMasterData = acBatchMasterData;
	}

	public Integer getAcLogisticsPss() {
		return acLogisticsPss;
	}

	public void setAcLogisticsPss(Integer acLogisticsPss) {
		this.acLogisticsPss = acLogisticsPss;
	}

	public Integer getAcPortfolioPm() {
		return acPortfolioPm;
	}

	public void setAcPortfolioPm(Integer acPortfolioPm) {
		this.acPortfolioPm = acPortfolioPm;
	}

	public Integer getAcFinGeneralLedger() {
		return acFinGeneralLedger;
	}

	public void setAcFinGeneralLedger(Integer acFinGeneralLedger) {
		this.acFinGeneralLedger = acFinGeneralLedger;
	}

	public Integer getAcIndustryUtil() {
		return acIndustryUtil;
	}

	public void setAcIndustryUtil(Integer acIndustryUtil) {
		this.acIndustryUtil = acIndustryUtil;
	}

	public Integer getAcGlobalLogistic() {
		return acGlobalLogistic;
	}

	public void setAcGlobalLogistic(Integer acGlobalLogistic) {
		this.acGlobalLogistic = acGlobalLogistic;
	}

	public Integer getAcIndustryOil() {
		return acIndustryOil;
	}

	public void setAcIndustryOil(Integer acIndustryOil) {
		this.acIndustryOil = acIndustryOil;
	}

	public Integer getAcLogisticQm() {
		return acLogisticQm;
	}

	public void setAcLogisticQm(Integer acLogisticQm) {
		this.acLogisticQm = acLogisticQm;
	}

	public Integer getAcFinAcctPayRecieve() {
		return acFinAcctPayRecieve;
	}

	public void setAcFinAcctPayRecieve(Integer acFinAcctPayRecieve) {
		this.acFinAcctPayRecieve = acFinAcctPayRecieve;
	}

	public Integer getAcFinTreasury() {
		return acFinTreasury;
	}

	public void setAcFinTreasury(Integer acFinTreasury) {
		this.acFinTreasury = acFinTreasury;
	}

	public Integer getAcLogisticsGt() {
		return acLogisticsGt;
	}

	public void setAcLogisticsGt(Integer acLogisticsGt) {
		this.acLogisticsGt = acLogisticsGt;
	}

	public Integer getAcHumanResources() {
		return acHumanResources;
	}

	public void setAcHumanResources(Integer acHumanResources) {
		this.acHumanResources = acHumanResources;
	}

	public Integer getSimpCategoryCOEF() {
		return simpCategoryCOEF;
	}

	public void setSimpCategoryCOEF(Integer simpCategoryCOEF) {
		this.simpCategoryCOEF = simpCategoryCOEF;
	}

	public Integer getSimpCategoryFEA() {
		return simpCategoryFEA;
	}

	public void setSimpCategoryFEA(Integer simpCategoryFEA) {
		this.simpCategoryFEA = simpCategoryFEA;
	}

	public Integer getSimpCategoryFENA() {
		return simpCategoryFENA;
	}

	public void setSimpCategoryFENA(Integer simpCategoryFENA) {
		this.simpCategoryFENA = simpCategoryFENA;
	}

	public Integer getSimpCategoryNsfFEA() {
		return simpCategoryNsfFEA;
	}

	public void setSimpCategoryNsfFEA(Integer simpCategoryNsfFEA) {
		this.simpCategoryNsfFEA = simpCategoryNsfFEA;
	}

	public Integer getSimpCategoryNsfFENA() {
		return simpCategoryNsfFENA;
	}

	public void setSimpCategoryNsfFENA(Integer simpCategoryNsfFENA) {
		this.simpCategoryNsfFENA = simpCategoryNsfFENA;
	}

	public Integer getSimpCategoryNewS4Fun() {
		return simpCategoryNewS4Fun;
	}

	public void setSimpCategoryNewS4Fun(Integer simpCategoryNewS4Fun) {
		this.simpCategoryNewS4Fun = simpCategoryNewS4Fun;
	}

	public Integer getManCompHigh() {
		return manCompHigh;
	}

	public void setManCompHigh(Integer manCompHigh) {
		this.manCompHigh = manCompHigh;
	}

	public Integer getManCompMedium() {
		return manCompMedium;
	}

	public void setManCompMedium(Integer manCompMedium) {
		this.manCompMedium = manCompMedium;
	}

	public Integer getManCompLow() {
		return manCompLow;
	}

	public void setManCompLow(Integer manCompLow) {
		this.manCompLow = manCompLow;
	}

	public Integer getManCompTbd() {
		return manCompTbd;
	}

	public void setManCompTbd(Integer manCompTbd) {
		this.manCompTbd = manCompTbd;
	}

	public Integer getOptCompMedium() {
		return optCompMedium;
	}

	public void setOptCompMedium(Integer optCompMedium) {
		this.optCompMedium = optCompMedium;
	}

	public Integer getOptCompLow() {
		return optCompLow;
	}

	public void setOptCompLow(Integer optCompLow) {
		this.optCompLow = optCompLow;
	}

	public Integer getOptCompVeryLow() {
		return optCompVeryLow;
	}

	public void setOptCompVeryLow(Integer optCompVeryLow) {
		this.optCompVeryLow = optCompVeryLow;
	}

	public Integer getManCustomCd() {
		return manCustomCd;
	}

	public void setManCustomCd(Integer manCustomCd) {
		this.manCustomCd = manCustomCd;
	}

	public Integer getManDataElement() {
		return manDataElement;
	}

	public void setManDataElement(Integer manDataElement) {
		this.manDataElement = manDataElement;
	}

	public Integer getManStatusTable() {
		return manStatusTable;
	}

	public void setManStatusTable(Integer manStatusTable) {
		this.manStatusTable = manStatusTable;
	}

	public Integer getManMatLength() {
		return manMatLength;
	}

	public void setManMatLength(Integer manMatLength) {
		this.manMatLength = manMatLength;
	}

	public Integer getManDataModel() {
		return manDataModel;
	}

	public void setManDataModel(Integer manDataModel) {
		this.manDataModel = manDataModel;
	}

	public Integer getManNewS4Fun() {
		return manNewS4Fun;
	}

	public void setManNewS4Fun(Integer manNewS4Fun) {
		this.manNewS4Fun = manNewS4Fun;
	}

	public Integer getManNewTrans() {
		return manNewTrans;
	}

	public void setManNewTrans(Integer manNewTrans) {
		this.manNewTrans = manNewTrans;
	}

	public Integer getManRemOrphan() {
		return manRemOrphan;
	}

	public void setManRemOrphan(Integer manRemOrphan) {
		this.manRemOrphan = manRemOrphan;
	}

	public Integer getManRetiredFun() {
		return manRetiredFun;
	}

	public void setManRetiredFun(Integer manRetiredFun) {
		this.manRetiredFun = manRetiredFun;
	}

	public Integer getManSimpExistTab() {
		return manSimpExistTab;
	}

	public void setManSimpExistTab(Integer manSimpExistTab) {
		this.manSimpExistTab = manSimpExistTab;
	}

	public Integer getManRepNewFun() {
		return manRepNewFun;
	}

	public void setManRepNewFun(Integer manRepNewFun) {
		this.manRepNewFun = manRepNewFun;
	}

	public Integer getManFunEqvAvl() {
		return manFunEqvAvl;
	}

	public void setManFunEqvAvl(Integer manFunEqvAvl) {
		this.manFunEqvAvl = manFunEqvAvl;
	}

	public Integer getManAdaptCustCd() {
		return manAdaptCustCd;
	}

	public void setManAdaptCustCd(Integer manAdaptCustCd) {
		this.manAdaptCustCd = manAdaptCustCd;
	}

	public Integer getManCustFields() {
		return manCustFields;
	}

	public void setManCustFields(Integer manCustFields) {
		this.manCustFields = manCustFields;
	}

	public Integer getManObsTrans() {
		return manObsTrans;
	}

	public void setManObsTrans(Integer manObsTrans) {
		this.manObsTrans = manObsTrans;
	}

	public Integer getManOutputMgmt() {
		return manOutputMgmt;
	}

	public void setManOutputMgmt(Integer manOutputMgmt) {
		this.manOutputMgmt = manOutputMgmt;
	}

	public Integer getOptCustomCd() {
		return optCustomCd;
	}

	public void setOptCustomCd(Integer optCustomCd) {
		this.optCustomCd = optCustomCd;
	}

	public Integer getOptDataElement() {
		return optDataElement;
	}

	public void setOptDataElement(Integer optDataElement) {
		this.optDataElement = optDataElement;
	}

	public Integer getOptStatusTable() {
		return optStatusTable;
	}

	public void setOptStatusTable(Integer optStatusTable) {
		this.optStatusTable = optStatusTable;
	}

	public Integer getOptMatLength() {
		return optMatLength;
	}

	public void setOptMatLength(Integer optMatLength) {
		this.optMatLength = optMatLength;
	}

	public Integer getOptDataModel() {
		return optDataModel;
	}

	public void setOptDataModel(Integer optDataModel) {
		this.optDataModel = optDataModel;
	}

	public Integer getOptNewS4Fun() {
		return optNewS4Fun;
	}

	public void setOptNewS4Fun(Integer optNewS4Fun) {
		this.optNewS4Fun = optNewS4Fun;
	}

	public Integer getOptNewTrans() {
		return optNewTrans;
	}

	public void setOptNewTrans(Integer optNewTrans) {
		this.optNewTrans = optNewTrans;
	}

	public Integer getOptRemOrphan() {
		return optRemOrphan;
	}

	public void setOptRemOrphan(Integer optRemOrphan) {
		this.optRemOrphan = optRemOrphan;
	}

	public Integer getOptRetiredFun() {
		return optRetiredFun;
	}

	public void setOptRetiredFun(Integer optRetiredFun) {
		this.optRetiredFun = optRetiredFun;
	}

	public Integer getOptSimpExistTab() {
		return optSimpExistTab;
	}

	public void setOptSimpExistTab(Integer optSimpExistTab) {
		this.optSimpExistTab = optSimpExistTab;
	}

	public Integer getOptRepNewFun() {
		return optRepNewFun;
	}

	public void setOptRepNewFun(Integer optRepNewFun) {
		this.optRepNewFun = optRepNewFun;
	}

	public Integer getOptFunEqvAvl() {
		return optFunEqvAvl;
	}

	public void setOptFunEqvAvl(Integer optFunEqvAvl) {
		this.optFunEqvAvl = optFunEqvAvl;
	}

	public Integer getOptAdaptCustCd() {
		return optAdaptCustCd;
	}

	public void setOptAdaptCustCd(Integer optAdaptCustCd) {
		this.optAdaptCustCd = optAdaptCustCd;
	}

	public Integer getOptCustFields() {
		return optCustFields;
	}

	public void setOptCustFields(Integer optCustFields) {
		this.optCustFields = optCustFields;
	}

	public Integer getOptObsTrans() {
		return optObsTrans;
	}

	public void setOptObsTrans(Integer optObsTrans) {
		this.optObsTrans = optObsTrans;
	}

	public Integer getOptOutputMgmt() {
		return optOutputMgmt;
	}

	public void setOptOutputMgmt(Integer optOutputMgmt) {
		this.optOutputMgmt = optOutputMgmt;
	}

	public Integer getManCustomCdError() {
		return manCustomCdError;
	}

	public void setManCustomCdError(Integer manCustomCdError) {
		this.manCustomCdError = manCustomCdError;
	}

	public Integer getManDataElementError() {
		return manDataElementError;
	}

	public void setManDataElementError(Integer manDataElementError) {
		this.manDataElementError = manDataElementError;
	}

	public Integer getManStatusTableError() {
		return manStatusTableError;
	}

	public void setManStatusTableError(Integer manStatusTableError) {
		this.manStatusTableError = manStatusTableError;
	}

	public Integer getManMatLengthError() {
		return manMatLengthError;
	}

	public void setManMatLengthError(Integer manMatLengthError) {
		this.manMatLengthError = manMatLengthError;
	}

	public Integer getManDataModelError() {
		return manDataModelError;
	}

	public void setManDataModelError(Integer manDataModelError) {
		this.manDataModelError = manDataModelError;
	}

	public Integer getManNewS4FunError() {
		return manNewS4FunError;
	}

	public void setManNewS4FunError(Integer manNewS4FunError) {
		this.manNewS4FunError = manNewS4FunError;
	}

	public Integer getManNewTransError() {
		return manNewTransError;
	}

	public void setManNewTransError(Integer manNewTransError) {
		this.manNewTransError = manNewTransError;
	}

	public Integer getManRemOrphanError() {
		return manRemOrphanError;
	}

	public void setManRemOrphanError(Integer manRemOrphanError) {
		this.manRemOrphanError = manRemOrphanError;
	}

	public Integer getManRetiredFunError() {
		return manRetiredFunError;
	}

	public void setManRetiredFunError(Integer manRetiredFunError) {
		this.manRetiredFunError = manRetiredFunError;
	}

	public Integer getManSimpExistTabError() {
		return manSimpExistTabError;
	}

	public void setManSimpExistTabError(Integer manSimpExistTabError) {
		this.manSimpExistTabError = manSimpExistTabError;
	}

	public Integer getManRepNewFunError() {
		return manRepNewFunError;
	}

	public void setManRepNewFunError(Integer manRepNewFunError) {
		this.manRepNewFunError = manRepNewFunError;
	}

	public Integer getManFunEqvAvlError() {
		return manFunEqvAvlError;
	}

	public void setManFunEqvAvlError(Integer manFunEqvAvlError) {
		this.manFunEqvAvlError = manFunEqvAvlError;
	}

	public Integer getManAdaptCustCdError() {
		return manAdaptCustCdError;
	}

	public void setManAdaptCustCdError(Integer manAdaptCustCdError) {
		this.manAdaptCustCdError = manAdaptCustCdError;
	}

	public Integer getManCustFieldsError() {
		return manCustFieldsError;
	}

	public void setManCustFieldsError(Integer manCustFieldsError) {
		this.manCustFieldsError = manCustFieldsError;
	}

	public Integer getManObsTransError() {
		return manObsTransError;
	}

	public void setManObsTransError(Integer manObsTransError) {
		this.manObsTransError = manObsTransError;
	}

	public Integer getManOutputMgmtError() {
		return manOutputMgmtError;
	}

	public void setManOutputMgmtError(Integer manOutputMgmtError) {
		this.manOutputMgmtError = manOutputMgmtError;
	}

	public Integer getOptCustomCdError() {
		return optCustomCdError;
	}

	public void setOptCustomCdError(Integer optCustomCdError) {
		this.optCustomCdError = optCustomCdError;
	}

	public Integer getOptDataElementError() {
		return optDataElementError;
	}

	public void setOptDataElementError(Integer optDataElementError) {
		this.optDataElementError = optDataElementError;
	}

	public Integer getOptStatusTableError() {
		return optStatusTableError;
	}

	public void setOptStatusTableError(Integer optStatusTableError) {
		this.optStatusTableError = optStatusTableError;
	}

	public Integer getOptMatLengthError() {
		return optMatLengthError;
	}

	public void setOptMatLengthError(Integer optMatLengthError) {
		this.optMatLengthError = optMatLengthError;
	}

	public Integer getOptDataModelError() {
		return optDataModelError;
	}

	public void setOptDataModelError(Integer optDataModelError) {
		this.optDataModelError = optDataModelError;
	}

	public Integer getOptNewS4FunError() {
		return optNewS4FunError;
	}

	public void setOptNewS4FunError(Integer optNewS4FunError) {
		this.optNewS4FunError = optNewS4FunError;
	}

	public Integer getOptNewTransError() {
		return optNewTransError;
	}

	public void setOptNewTransError(Integer optNewTransError) {
		this.optNewTransError = optNewTransError;
	}

	public Integer getOptRemOrphanError() {
		return optRemOrphanError;
	}

	public void setOptRemOrphanError(Integer optRemOrphanError) {
		this.optRemOrphanError = optRemOrphanError;
	}

	public Integer getOptRetiredFunError() {
		return optRetiredFunError;
	}

	public void setOptRetiredFunError(Integer optRetiredFunError) {
		this.optRetiredFunError = optRetiredFunError;
	}

	public Integer getOptSimpExistTabError() {
		return optSimpExistTabError;
	}

	public void setOptSimpExistTabError(Integer optSimpExistTabError) {
		this.optSimpExistTabError = optSimpExistTabError;
	}

	public Integer getOptRepNewFunError() {
		return optRepNewFunError;
	}

	public void setOptRepNewFunError(Integer optRepNewFunError) {
		this.optRepNewFunError = optRepNewFunError;
	}

	public Integer getOptFunEqvAvlError() {
		return optFunEqvAvlError;
	}

	public void setOptFunEqvAvlError(Integer optFunEqvAvlError) {
		this.optFunEqvAvlError = optFunEqvAvlError;
	}

	public Integer getOptAdaptCustCdError() {
		return optAdaptCustCdError;
	}

	public void setOptAdaptCustCdError(Integer optAdaptCustCdError) {
		this.optAdaptCustCdError = optAdaptCustCdError;
	}

	public Integer getOptCustFieldsError() {
		return optCustFieldsError;
	}

	public void setOptCustFieldsError(Integer optCustFieldsError) {
		this.optCustFieldsError = optCustFieldsError;
	}

	public Integer getOptObsTransError() {
		return optObsTransError;
	}

	public void setOptObsTransError(Integer optObsTransError) {
		this.optObsTransError = optObsTransError;
	}

	public Integer getOptOutputMgmtError() {
		return optOutputMgmtError;
	}

	public void setOptOutputMgmtError(Integer optOutputMgmtError) {
		this.optOutputMgmtError = optOutputMgmtError;
	}

	public Integer getUsreCount() {
		return usreCount;
	}

	public void setUsreCount(Integer usreCount) {
		this.usreCount = usreCount;
	}

	public Integer getUsrrCount() {
		return usrrCount;
	}

	public void setUsrrCount(Integer usrrCount) {
		this.usrrCount = usrrCount;
	}

	public Integer getFugsCount() {
		return fugsCount;
	}

	public void setFugsCount(Integer fugsCount) {
		this.fugsCount = fugsCount;
	}

	public Integer getUsreUsedCount() {
		return usreUsedCount;
	}

	public void setUsreUsedCount(Integer usreUsedCount) {
		this.usreUsedCount = usreUsedCount;
	}

	public Integer getUsrrUsedCount() {
		return usrrUsedCount;
	}

	public void setUsrrUsedCount(Integer usrrUsedCount) {
		this.usrrUsedCount = usrrUsedCount;
	}

	public Integer getFugsUsedCount() {
		return fugsUsedCount;
	}

	public void setFugsUsedCount(Integer fugsUsedCount) {
		this.fugsUsedCount = fugsUsedCount;
	}

	public Integer getDefectUsreCount() {
		return defectUsreCount;
	}

	public void setDefectUsreCount(Integer defectUsreCount) {
		this.defectUsreCount = defectUsreCount;
	}

	public Integer getDefectUsrrCount() {
		return defectUsrrCount;
	}

	public void setDefectUsrrCount(Integer defectUsrrCount) {
		this.defectUsrrCount = defectUsrrCount;
	}

	public Integer getDefectFugsCount() {
		return defectFugsCount;
	}

	public void setDefectFugsCount(Integer defectFugsCount) {
		this.defectFugsCount = defectFugsCount;
	}

	public Integer getErrorUsreCount() {
		return errorUsreCount;
	}

	public void setErrorUsreCount(Integer errorUsreCount) {
		this.errorUsreCount = errorUsreCount;
	}

	public Integer getErrorUsrrCount() {
		return errorUsrrCount;
	}

	public void setErrorUsrrCount(Integer errorUsrrCount) {
		this.errorUsrrCount = errorUsrrCount;
	}

	public Integer getErrorFugsCount() {
		return errorFugsCount;
	}

	public void setErrorFugsCount(Integer errorFugsCount) {
		this.errorFugsCount = errorFugsCount;
	}

	public Integer getDefectUsedUsreCount() {
		return defectUsedUsreCount;
	}

	public void setDefectUsedUsreCount(Integer defectUsedUsreCount) {
		this.defectUsedUsreCount = defectUsedUsreCount;
	}

	public Integer getDefectUsedUsrrCount() {
		return defectUsedUsrrCount;
	}

	public void setDefectUsedUsrrCount(Integer defectUsedUsrrCount) {
		this.defectUsedUsrrCount = defectUsedUsrrCount;
	}

	public Integer getDefectUsedFugsCount() {
		return defectUsedFugsCount;
	}

	public void setDefectUsedFugsCount(Integer defectUsedFugsCount) {
		this.defectUsedFugsCount = defectUsedFugsCount;
	}

	public Integer getErrorUsedUsreCount() {
		return errorUsedUsreCount;
	}

	public void setErrorUsedUsreCount(Integer errorUsedUsreCount) {
		this.errorUsedUsreCount = errorUsedUsreCount;
	}

	public Integer getErrorUsedUsrrCount() {
		return errorUsedUsrrCount;
	}

	public void setErrorUsedUsrrCount(Integer errorUsedUsrrCount) {
		this.errorUsedUsrrCount = errorUsedUsrrCount;
	}

	public Integer getErrorUsedFugsCount() {
		return errorUsedFugsCount;
	}

	public void setErrorUsedFugsCount(Integer errorUsedFugsCount) {
		this.errorUsedFugsCount = errorUsedFugsCount;
	}

	public Integer gethANA_Sorting_cnt() {
		return hANA_Sorting_cnt;
	}

	public void sethANA_Sorting_cnt(Integer hANA_Sorting_cnt) {
		this.hANA_Sorting_cnt = hANA_Sorting_cnt;
	}

	public Integer getMinimize_amnt_data_trnsfr_cnt() {
		return minimize_amnt_data_trnsfr_cnt;
	}

	public void setMinimize_amnt_data_trnsfr_cnt(Integer minimize_amnt_data_trnsfr_cnt) {
		this.minimize_amnt_data_trnsfr_cnt = minimize_amnt_data_trnsfr_cnt;
	}

	public Integer getPotential_syntax_err_cnt() {
		return potential_syntax_err_cnt;
	}

	public void setPotential_syntax_err_cnt(Integer potential_syntax_err_cnt) {
		this.potential_syntax_err_cnt = potential_syntax_err_cnt;
	}

	public Integer getResult_set_small_subcategry_count() {
		return result_set_small_subcategry_count;
	}

	public void setResult_set_small_subcategry_count(Integer result_set_small_subcategry_count) {
		this.result_set_small_subcategry_count = result_set_small_subcategry_count;
	}

	public Integer getSemantic_Err_cnt() {
		return semantic_Err_cnt;
	}

	public void setSemantic_Err_cnt(Integer semantic_Err_cnt) {
		this.semantic_Err_cnt = semantic_Err_cnt;
	}

	public Integer getStatement_ignr_HANA_sbcatgry() {
		return statement_ignr_HANA_sbcatgry;
	}

	public void setStatement_ignr_HANA_sbcatgry(Integer statement_ignr_HANA_sbcatgry) {
		this.statement_ignr_HANA_sbcatgry = statement_ignr_HANA_sbcatgry;
	}

	public Integer getUnneces_loa_away_subcategry_count() {
		return unneces_loa_away_subcategry_count;
	}

	public void setUnneces_loa_away_subcategry_count(Integer unneces_loa_away_subcategry_count) {
		this.unneces_loa_away_subcategry_count = unneces_loa_away_subcategry_count;
	}

	public Integer getValidat_syntx_err_subcatgry() {
		return validat_syntx_err_subcatgry;
	}

	public void setValidat_syntx_err_subcatgry(Integer validat_syntx_err_subcatgry) {
		this.validat_syntx_err_subcatgry = validat_syntx_err_subcatgry;
	}

	public Integer getHanaSortingUsedCnt() {
		return hanaSortingUsedCnt;
	}

	public void setHanaSortingUsedCnt(Integer hanaSortingUsedCnt) {
		this.hanaSortingUsedCnt = hanaSortingUsedCnt;
	}

	public Integer getMinimizeAmntDataTrnsfrUsedCnt() {
		return minimizeAmntDataTrnsfrUsedCnt;
	}

	public void setMinimizeAmntDataTrnsfrUsedCnt(Integer minimizeAmntDataTrnsfrUsedCnt) {
		this.minimizeAmntDataTrnsfrUsedCnt = minimizeAmntDataTrnsfrUsedCnt;
	}

	public Integer getPotentialSyntaxErrUsedCnt() {
		return potentialSyntaxErrUsedCnt;
	}

	public void setPotentialSyntaxErrUsedCnt(Integer potentialSyntaxErrUsedCnt) {
		this.potentialSyntaxErrUsedCnt = potentialSyntaxErrUsedCnt;
	}

	public Integer getResultSetSmallUsedCnt() {
		return resultSetSmallUsedCnt;
	}

	public void setResultSetSmallUsedCnt(Integer resultSetSmallUsedCnt) {
		this.resultSetSmallUsedCnt = resultSetSmallUsedCnt;
	}

	public Integer getSemanticErrUsedCnt() {
		return semanticErrUsedCnt;
	}

	public void setSemanticErrUsedCnt(Integer semanticErrUsedCnt) {
		this.semanticErrUsedCnt = semanticErrUsedCnt;
	}

	public Integer getStatementIgnrHanaUsedCnt() {
		return statementIgnrHanaUsedCnt;
	}

	public void setStatementIgnrHanaUsedCnt(Integer statementIgnrHanaUsedCnt) {
		this.statementIgnrHanaUsedCnt = statementIgnrHanaUsedCnt;
	}

	public Integer getUnnecesLoaAwayUsedCnt() {
		return UnnecesLoaAwayUsedCnt;
	}

	public void setUnnecesLoaAwayUsedCnt(Integer unnecesLoaAwayUsedCnt) {
		UnnecesLoaAwayUsedCnt = unnecesLoaAwayUsedCnt;
	}

	public Integer getValidatSyntxErrUsedCnt() {
		return ValidatSyntxErrUsedCnt;
	}

	public void setValidatSyntxErrUsedCnt(Integer validatSyntxErrUsedCnt) {
		ValidatSyntxErrUsedCnt = validatSyntxErrUsedCnt;
	}

	public Integer getNewDataModelCnt() {
		return newDataModelCnt;
	}

	public void setNewDataModelCnt(Integer newDataModelCnt) {
		this.newDataModelCnt = newDataModelCnt;
	}

	public Integer getMaterial_lengthExtension_cnt() {
		return Material_lengthExtension_cnt;
	}

	public void setMaterial_lengthExtension_cnt(Integer material_lengthExtension_cnt) {
		Material_lengthExtension_cnt = material_lengthExtension_cnt;
	}

	public Integer getData_Element_lengthExtension_cnt() {
		return Data_Element_lengthExtension_cnt;
	}

	public void setData_Element_lengthExtension_cnt(Integer data_Element_lengthExtension_cnt) {
		Data_Element_lengthExtension_cnt = data_Element_lengthExtension_cnt;
	}

	public Integer getEliminationOf_Status_Table_cnt() {
		return eliminationOf_Status_Table_cnt;
	}

	public void setEliminationOf_Status_Table_cnt(Integer eliminationOf_Status_Table_cnt) {
		this.eliminationOf_Status_Table_cnt = eliminationOf_Status_Table_cnt;
	}

	public Integer getRemovalOf_OrphenedObjects_cnt() {
		return removalOf_OrphenedObjects_cnt;
	}

	public void setRemovalOf_OrphenedObjects_cnt(Integer removalOf_OrphenedObjects_cnt) {
		this.removalOf_OrphenedObjects_cnt = removalOf_OrphenedObjects_cnt;
	}

	public Integer getCustomCode_Adaption_cnt() {
		return customCode_Adaption_cnt;
	}

	public void setCustomCode_Adaption_cnt(Integer customCode_Adaption_cnt) {
		this.customCode_Adaption_cnt = customCode_Adaption_cnt;
	}

	public Integer getRetiredFunctionality_cnt() {
		return retiredFunctionality_cnt;
	}

	public void setRetiredFunctionality_cnt(Integer retiredFunctionality_cnt) {
		this.retiredFunctionality_cnt = retiredFunctionality_cnt;
	}

	public Integer getNewS4Functionality_cnt() {
		return newS4Functionality_cnt;
	}

	public void setNewS4Functionality_cnt(Integer newS4Functionality_cnt) {
		this.newS4Functionality_cnt = newS4Functionality_cnt;
	}

	public Integer getReplacedByNewFunctionality_cnt() {
		return replacedByNewFunctionality_cnt;
	}

	public void setReplacedByNewFunctionality_cnt(Integer replacedByNewFunctionality_cnt) {
		this.replacedByNewFunctionality_cnt = replacedByNewFunctionality_cnt;
	}

	public Integer getNewTransaction_cnt() {
		return newTransaction_cnt;
	}

	public void setNewTransaction_cnt(Integer newTransaction_cnt) {
		this.newTransaction_cnt = newTransaction_cnt;
	}

	public Integer getFunctionalEquivalentAvailable_cnt() {
		return functionalEquivalentAvailable_cnt;
	}

	public void setFunctionalEquivalentAvailable_cnt(Integer functionalEquivalentAvailable_cnt) {
		this.functionalEquivalentAvailable_cnt = functionalEquivalentAvailable_cnt;
	}

	public Integer getSimplificationOfExistingTable_cnt() {
		return simplificationOfExistingTable_cnt;
	}

	public void setSimplificationOfExistingTable_cnt(Integer simplificationOfExistingTable_cnt) {
		this.simplificationOfExistingTable_cnt = simplificationOfExistingTable_cnt;
	}

	public Integer getNew_dataModel_Usedcnt() {
		return new_dataModel_Usedcnt;
	}

	public void setNew_dataModel_Usedcnt(Integer new_dataModel_Usedcnt) {
		this.new_dataModel_Usedcnt = new_dataModel_Usedcnt;
	}

	public Integer getMaterial_lengthExtension_Usedcnt() {
		return Material_lengthExtension_Usedcnt;
	}

	public void setMaterial_lengthExtension_Usedcnt(Integer material_lengthExtension_Usedcnt) {
		Material_lengthExtension_Usedcnt = material_lengthExtension_Usedcnt;
	}

	public Integer getData_Element_lengthExtension_Usedcnt() {
		return data_Element_lengthExtension_Usedcnt;
	}

	public void setData_Element_lengthExtension_Usedcnt(Integer data_Element_lengthExtension_Usedcnt) {
		this.data_Element_lengthExtension_Usedcnt = data_Element_lengthExtension_Usedcnt;
	}

	public Integer getEliminationOf_Status_Table_Usedcnt() {
		return eliminationOf_Status_Table_Usedcnt;
	}

	public void setEliminationOf_Status_Table_Usedcnt(Integer eliminationOf_Status_Table_Usedcnt) {
		this.eliminationOf_Status_Table_Usedcnt = eliminationOf_Status_Table_Usedcnt;
	}

	public Integer getRemovalOf_OrphenedObjects_Usedcnt() {
		return removalOf_OrphenedObjects_Usedcnt;
	}

	public void setRemovalOf_OrphenedObjects_Usedcnt(Integer removalOf_OrphenedObjects_Usedcnt) {
		this.removalOf_OrphenedObjects_Usedcnt = removalOf_OrphenedObjects_Usedcnt;
	}

	public Integer getCustomCode_Adaption_Usedcnt() {
		return customCode_Adaption_Usedcnt;
	}

	public void setCustomCode_Adaption_Usedcnt(Integer customCode_Adaption_Usedcnt) {
		this.customCode_Adaption_Usedcnt = customCode_Adaption_Usedcnt;
	}

	public Integer getRetiredFunctionality_Usedcnt() {
		return retiredFunctionality_Usedcnt;
	}

	public void setRetiredFunctionality_Usedcnt(Integer retiredFunctionality_Usedcnt) {
		this.retiredFunctionality_Usedcnt = retiredFunctionality_Usedcnt;
	}

	public Integer getNewS4Functionality_Usedcnt() {
		return newS4Functionality_Usedcnt;
	}

	public void setNewS4Functionality_Usedcnt(Integer newS4Functionality_Usedcnt) {
		this.newS4Functionality_Usedcnt = newS4Functionality_Usedcnt;
	}

	public Integer getReplacedByNewFunctionality_Usedcnt() {
		return replacedByNewFunctionality_Usedcnt;
	}

	public void setReplacedByNewFunctionality_Usedcnt(Integer replacedByNewFunctionality_Usedcnt) {
		this.replacedByNewFunctionality_Usedcnt = replacedByNewFunctionality_Usedcnt;
	}

	public Integer getNewTransaction_Usedcnt() {
		return newTransaction_Usedcnt;
	}

	public void setNewTransaction_Usedcnt(Integer newTransaction_Usedcnt) {
		this.newTransaction_Usedcnt = newTransaction_Usedcnt;
	}

	public Integer getFunctionalEquivalentAvailable_Usedcnt() {
		return functionalEquivalentAvailable_Usedcnt;
	}

	public void setFunctionalEquivalentAvailable_Usedcnt(Integer functionalEquivalentAvailable_Usedcnt) {
		this.functionalEquivalentAvailable_Usedcnt = functionalEquivalentAvailable_Usedcnt;
	}

	public Integer getSimplificationOfExistingTable_Usedcnt() {
		return simplificationOfExistingTable_Usedcnt;
	}

	public void setSimplificationOfExistingTable_Usedcnt(Integer simplificationOfExistingTable_Usedcnt) {
		this.simplificationOfExistingTable_Usedcnt = simplificationOfExistingTable_Usedcnt;
	}

	public Integer getDefectHanaSorting() {
		return defectHanaSorting;
	}

	public void setDefectHanaSorting(Integer defectHanaSorting) {
		this.defectHanaSorting = defectHanaSorting;
	}

	public Integer getDefecMminimizeAmntDataTrnsfr() {
		return defecMminimizeAmntDataTrnsfr;
	}

	public void setDefecMminimizeAmntDataTrnsfr(Integer defecMminimizeAmntDataTrnsfr) {
		this.defecMminimizeAmntDataTrnsfr = defecMminimizeAmntDataTrnsfr;
	}

	public Integer getDefectPotentialSyntax() {
		return defectPotentialSyntax;
	}

	public void setDefectPotentialSyntax(Integer defectPotentialSyntax) {
		this.defectPotentialSyntax = defectPotentialSyntax;
	}

	public Integer getDefectResultsetSmallSubcategry() {
		return defectResultsetSmallSubcategry;
	}

	public void setDefectResultsetSmallSubcategry(Integer defectResultsetSmallSubcategry) {
		this.defectResultsetSmallSubcategry = defectResultsetSmallSubcategry;
	}

	public Integer getDefectSemanticErr() {
		return defectSemanticErr;
	}

	public void setDefectSemanticErr(Integer defectSemanticErr) {
		this.defectSemanticErr = defectSemanticErr;
	}

	public Integer getDefectStmtIgnrHanaSbcatgry() {
		return defectStmtIgnrHanaSbcatgry;
	}

	public void setDefectStmtIgnrHanaSbcatgry(Integer defectStmtIgnrHanaSbcatgry) {
		this.defectStmtIgnrHanaSbcatgry = defectStmtIgnrHanaSbcatgry;
	}

	public Integer getDefectUnnecesLoaAwaySbcatgry() {
		return defectUnnecesLoaAwaySbcatgry;
	}

	public void setDefectUnnecesLoaAwaySbcatgry(Integer defectUnnecesLoaAwaySbcatgry) {
		this.defectUnnecesLoaAwaySbcatgry = defectUnnecesLoaAwaySbcatgry;
	}

	public Integer getDefectValidatSyntxSubcatgry() {
		return defectValidatSyntxSubcatgry;
	}

	public void setDefectValidatSyntxSubcatgry(Integer defectValidatSyntxSubcatgry) {
		this.defectValidatSyntxSubcatgry = defectValidatSyntxSubcatgry;
	}

	public Integer getDefectHanaSortingUsedCnt() {
		return defectHanaSortingUsedCnt;
	}

	public void setDefectHanaSortingUsedCnt(Integer defectHanaSortingUsedCnt) {
		this.defectHanaSortingUsedCnt = defectHanaSortingUsedCnt;
	}

	public Integer getDefectMinAmntDataTrnsfrUsedCnt() {
		return defectMinAmntDataTrnsfrUsedCnt;
	}

	public void setDefectMinAmntDataTrnsfrUsedCnt(Integer defectMinAmntDataTrnsfrUsedCnt) {
		this.defectMinAmntDataTrnsfrUsedCnt = defectMinAmntDataTrnsfrUsedCnt;
	}

	public Integer getDefectPotentialSyntaxUsedCnt() {
		return defectPotentialSyntaxUsedCnt;
	}

	public void setDefectPotentialSyntaxUsedCnt(Integer defectPotentialSyntaxUsedCnt) {
		this.defectPotentialSyntaxUsedCnt = defectPotentialSyntaxUsedCnt;
	}

	public Integer getDefectResultSetSmallUsedCnt() {
		return defectResultSetSmallUsedCnt;
	}

	public void setDefectResultSetSmallUsedCnt(Integer defectResultSetSmallUsedCnt) {
		this.defectResultSetSmallUsedCnt = defectResultSetSmallUsedCnt;
	}

	public Integer getDefectSemanticErrUsedCnt() {
		return defectSemanticErrUsedCnt;
	}

	public void setDefectSemanticErrUsedCnt(Integer defectSemanticErrUsedCnt) {
		this.defectSemanticErrUsedCnt = defectSemanticErrUsedCnt;
	}

	public Integer getDefectStmtIgnrHanaUsedCnt() {
		return defectStmtIgnrHanaUsedCnt;
	}

	public void setDefectStmtIgnrHanaUsedCnt(Integer defectStmtIgnrHanaUsedCnt) {
		this.defectStmtIgnrHanaUsedCnt = defectStmtIgnrHanaUsedCnt;
	}

	public Integer getDefectUnnecesLoaAwayUsedCnt() {
		return defectUnnecesLoaAwayUsedCnt;
	}

	public void setDefectUnnecesLoaAwayUsedCnt(Integer defectUnnecesLoaAwayUsedCnt) {
		this.defectUnnecesLoaAwayUsedCnt = defectUnnecesLoaAwayUsedCnt;
	}

	public Integer getDefectValidatSyntxErrUsedCnt() {
		return defectValidatSyntxErrUsedCnt;
	}

	public void setDefectValidatSyntxErrUsedCnt(Integer defectValidatSyntxErrUsedCnt) {
		this.defectValidatSyntxErrUsedCnt = defectValidatSyntxErrUsedCnt;
	}

	public Integer getDefNewDataModel() {
		return defNewDataModel;
	}

	public void setDefNewDataModel(Integer defNewDataModel) {
		this.defNewDataModel = defNewDataModel;
	}

	public Integer getDefMaterialLengthExt() {
		return defMaterialLengthExt;
	}

	public void setDefMaterialLengthExt(Integer defMaterialLengthExt) {
		this.defMaterialLengthExt = defMaterialLengthExt;
	}

	public Integer getDefDataElementlengthExt() {
		return defDataElementlengthExt;
	}

	public void setDefDataElementlengthExt(Integer defDataElementlengthExt) {
		this.defDataElementlengthExt = defDataElementlengthExt;
	}

	public Integer getDefEliminationOfStatusTable() {
		return defEliminationOfStatusTable;
	}

	public void setDefEliminationOfStatusTable(Integer defEliminationOfStatusTable) {
		this.defEliminationOfStatusTable = defEliminationOfStatusTable;
	}

	public Integer getDefRemovalOrphenObjects() {
		return defRemovalOrphenObjects;
	}

	public void setDefRemovalOrphenObjects(Integer defRemovalOrphenObjects) {
		this.defRemovalOrphenObjects = defRemovalOrphenObjects;
	}

	public Integer getDefCustomCodeAdaption() {
		return defCustomCodeAdaption;
	}

	public void setDefCustomCodeAdaption(Integer defCustomCodeAdaption) {
		this.defCustomCodeAdaption = defCustomCodeAdaption;
	}

	public Integer getDefRetiredFunctionality() {
		return defRetiredFunctionality;
	}

	public void setDefRetiredFunctionality(Integer defRetiredFunctionality) {
		this.defRetiredFunctionality = defRetiredFunctionality;
	}

	public Integer getDefNewS4Functionality() {
		return defNewS4Functionality;
	}

	public void setDefNewS4Functionality(Integer defNewS4Functionality) {
		this.defNewS4Functionality = defNewS4Functionality;
	}

	public Integer getDefReplacNewFunctionality() {
		return defReplacNewFunctionality;
	}

	public void setDefReplacNewFunctionality(Integer defReplacNewFunctionality) {
		this.defReplacNewFunctionality = defReplacNewFunctionality;
	}

	public Integer getDefNewTransaction() {
		return defNewTransaction;
	}

	public void setDefNewTransaction(Integer defNewTransaction) {
		this.defNewTransaction = defNewTransaction;
	}

	public Integer getDefFunctionalEqvAvailable() {
		return defFunctionalEqvAvailable;
	}

	public void setDefFunctionalEqvAvailable(Integer defFunctionalEqvAvailable) {
		this.defFunctionalEqvAvailable = defFunctionalEqvAvailable;
	}

	public Integer getDefSimplificationExistTable() {
		return defSimplificationExistTable;
	}

	public void setDefSimplificationExistTable(Integer defSimplificationExistTable) {
		this.defSimplificationExistTable = defSimplificationExistTable;
	}

	public Integer getDefNewDataModelUsed() {
		return defNewDataModelUsed;
	}

	public void setDefNewDataModelUsed(Integer defNewDataModelUsed) {
		this.defNewDataModelUsed = defNewDataModelUsed;
	}

	public Integer getDefMaterialLengthExtUsed() {
		return defMaterialLengthExtUsed;
	}

	public void setDefMaterialLengthExtUsed(Integer defMaterialLengthExtUsed) {
		this.defMaterialLengthExtUsed = defMaterialLengthExtUsed;
	}

	public Integer getDefDataElementlengthExtUsed() {
		return defDataElementlengthExtUsed;
	}

	public void setDefDataElementlengthExtUsed(Integer defDataElementlengthExtUsed) {
		this.defDataElementlengthExtUsed = defDataElementlengthExtUsed;
	}

	public Integer getDefEliminationOfStatusTableUsed() {
		return defEliminationOfStatusTableUsed;
	}

	public void setDefEliminationOfStatusTableUsed(Integer defEliminationOfStatusTableUsed) {
		this.defEliminationOfStatusTableUsed = defEliminationOfStatusTableUsed;
	}

	public Integer getDefRemovalOrphenObjectsUsed() {
		return defRemovalOrphenObjectsUsed;
	}

	public void setDefRemovalOrphenObjectsUsed(Integer defRemovalOrphenObjectsUsed) {
		this.defRemovalOrphenObjectsUsed = defRemovalOrphenObjectsUsed;
	}

	public Integer getDefCustomCodeAdaptionUsed() {
		return defCustomCodeAdaptionUsed;
	}

	public void setDefCustomCodeAdaptionUsed(Integer defCustomCodeAdaptionUsed) {
		this.defCustomCodeAdaptionUsed = defCustomCodeAdaptionUsed;
	}

	public Integer getDefRetiredFunctionalityUsed() {
		return defRetiredFunctionalityUsed;
	}

	public void setDefRetiredFunctionalityUsed(Integer defRetiredFunctionalityUsed) {
		this.defRetiredFunctionalityUsed = defRetiredFunctionalityUsed;
	}

	public Integer getDefNewS4FunctionalityUsed() {
		return defNewS4FunctionalityUsed;
	}

	public void setDefNewS4FunctionalityUsed(Integer defNewS4FunctionalityUsed) {
		this.defNewS4FunctionalityUsed = defNewS4FunctionalityUsed;
	}

	public Integer getDefReplacNewFunctionalityUsed() {
		return defReplacNewFunctionalityUsed;
	}

	public void setDefReplacNewFunctionalityUsed(Integer defReplacNewFunctionalityUsed) {
		this.defReplacNewFunctionalityUsed = defReplacNewFunctionalityUsed;
	}

	public Integer getDefNewTransactionUsed() {
		return defNewTransactionUsed;
	}

	public void setDefNewTransactionUsed(Integer defNewTransactionUsed) {
		this.defNewTransactionUsed = defNewTransactionUsed;
	}

	public Integer getDefFunctionalEqvAvailableUsed() {
		return defFunctionalEqvAvailableUsed;
	}

	public void setDefFunctionalEqvAvailableUsed(Integer defFunctionalEqvAvailableUsed) {
		this.defFunctionalEqvAvailableUsed = defFunctionalEqvAvailableUsed;
	}

	public Integer getDefSimplificationExistTableUsed() {
		return defSimplificationExistTableUsed;
	}

	public void setDefSimplificationExistTableUsed(Integer defSimplificationExistTableUsed) {
		this.defSimplificationExistTableUsed = defSimplificationExistTableUsed;
	}


	public Integer getManFunSemanticAutoYError() {
		return manFunSemanticAutoYError;
	}

	public void setManFunSemanticAutoYError(Integer manFunSemanticAutoYError) {
		this.manFunSemanticAutoYError = manFunSemanticAutoYError;
	}

	public Integer getManFunSemanticAutoNError() {
		return manFunSemanticAutoNError;
	}

	public void setManFunSemanticAutoNError(Integer manFunSemanticAutoNError) {
		this.manFunSemanticAutoNError = manFunSemanticAutoNError;
	}

	public Integer getManFunHanaSortAutoYError() {
		return manFunHanaSortAutoYError;
	}

	public void setManFunHanaSortAutoYError(Integer manFunHanaSortAutoYError) {
		this.manFunHanaSortAutoYError = manFunHanaSortAutoYError;
	}

	public Integer getManFunHanaSortAutoNError() {
		return manFunHanaSortAutoNError;
	}

	public void setManFunHanaSortAutoNError(Integer manFunHanaSortAutoNError) {
		this.manFunHanaSortAutoNError = manFunHanaSortAutoNError;
	}

	public Integer getManSynValidAutoYError() {
		return manSynValidAutoYError;
	}

	public void setManSynValidAutoYError(Integer manSynValidAutoYError) {
		this.manSynValidAutoYError = manSynValidAutoYError;
	}

	public Integer getManSynValidAutoNError() {
		return manSynValidAutoNError;
	}

	public void setManSynValidAutoNError(Integer manSynValidAutoNError) {
		this.manSynValidAutoNError = manSynValidAutoNError;
	}

	public Integer getManSynPotentialAutoYError() {
		return manSynPotentialAutoYError;
	}

	public void setManSynPotentialAutoYError(Integer manSynPotentialAutoYError) {
		this.manSynPotentialAutoYError = manSynPotentialAutoYError;
	}

	public Integer getManSynPotentialAutoNError() {
		return manSynPotentialAutoNError;
	}

	public void setManSynPotentialAutoNError(Integer manSynPotentialAutoNError) {
		this.manSynPotentialAutoNError = manSynPotentialAutoNError;
	}

	public Integer getManSemPoolClustAutoYError() {
		return manSemPoolClustAutoYError;
	}

	public void setManSemPoolClustAutoYError(Integer manSemPoolClustAutoYError) {
		this.manSemPoolClustAutoYError = manSemPoolClustAutoYError;
	}

	public Integer getManSemPoolClustAutoNError() {
		return manSemPoolClustAutoNError;
	}

	public void setManSemPoolClustAutoNError(Integer manSemPoolClustAutoNError) {
		this.manSemPoolClustAutoNError = manSemPoolClustAutoNError;
	}

	public Integer getManSemDbPoolAutoYError() {
		return manSemDbPoolAutoYError;
	}

	public void setManSemDbPoolAutoYError(Integer manSemDbPoolAutoYError) {
		this.manSemDbPoolAutoYError = manSemDbPoolAutoYError;
	}

	public Integer getManSemDbPoolAutoNError() {
		return manSemDbPoolAutoNError;
	}

	public void setManSemDbPoolAutoNError(Integer manSemDbPoolAutoNError) {
		this.manSemDbPoolAutoNError = manSemDbPoolAutoNError;
	}

	public Integer getManVSynNsqlAutoYError() {
		return manVSynNsqlAutoYError;
	}

	public void setManVSynNsqlAutoYError(Integer manVSynNsqlAutoYError) {
		this.manVSynNsqlAutoYError = manVSynNsqlAutoYError;
	}

	public Integer getManVSynNsqlAutoNError() {
		return manVSynNsqlAutoNError;
	}

	public void setManVSynNsqlAutoNError(Integer manVSynNsqlAutoNError) {
		this.manVSynNsqlAutoNError = manVSynNsqlAutoNError;
	}

	public Integer getManVSynDDICFmlAutoYError() {
		return manVSynDDICFmlAutoYError;
	}

	public void setManVSynDDICFmlAutoYError(Integer manVSynDDICFmlAutoYError) {
		this.manVSynDDICFmlAutoYError = manVSynDDICFmlAutoYError;
	}

	public Integer getManVSynDDICFmlAutoNError() {
		return manVSynDDICFmlAutoNError;
	}

	public void setManVSynDDICFmlAutoNError(Integer manVSynDDICFmlAutoNError) {
		this.manVSynDDICFmlAutoNError = manVSynDDICFmlAutoNError;
	}

	public Integer getManVSynAdbcUsAutoYError() {
		return manVSynAdbcUsAutoYError;
	}

	public void setManVSynAdbcUsAutoYError(Integer manVSynAdbcUsAutoYError) {
		this.manVSynAdbcUsAutoYError = manVSynAdbcUsAutoYError;
	}

	public Integer getManVSynAdbcUsAutoNError() {
		return manVSynAdbcUsAutoNError;
	}

	public void setManVSynAdbcUsAutoNError(Integer manVSynAdbcUsAutoNError) {
		this.manVSynAdbcUsAutoNError = manVSynAdbcUsAutoNError;
	}

	public Integer getManHSortUnInternalAutoYError() {
		return manHSortUnInternalAutoYError;
	}

	public void setManHSortUnInternalAutoYError(Integer manHSortUnInternalAutoYError) {
		this.manHSortUnInternalAutoYError = manHSortUnInternalAutoYError;
	}

	public Integer getManHSortUnInternalAutoNError() {
		return manHSortUnInternalAutoNError;
	}

	public void setManHSortUnInternalAutoNError(Integer manHSortUnInternalAutoNError) {
		this.manHSortUnInternalAutoNError = manHSortUnInternalAutoNError;
	}

	public Integer getManHSortSelWKyAutoYError() {
		return manHSortSelWKyAutoYError;
	}

	public void setManHSortSelWKyAutoYError(Integer manHSortSelWKyAutoYError) {
		this.manHSortSelWKyAutoYError = manHSortSelWKyAutoYError;
	}

	public Integer getManHSortSelWKyAutoNError() {
		return manHSortSelWKyAutoNError;
	}

	public void setManHSortSelWKyAutoNError(Integer manHSortSelWKyAutoNError) {
		this.manHSortSelWKyAutoNError = manHSortSelWKyAutoNError;
	}

	public Integer getManHSortRBWSOAutoYError() {
		return manHSortRBWSOAutoYError;
	}

	public void setManHSortRBWSOAutoYError(Integer manHSortRBWSOAutoYError) {
		this.manHSortRBWSOAutoYError = manHSortRBWSOAutoYError;
	}

	public Integer getManHSortRBWSOAutoNError() {
		return manHSortRBWSOAutoNError;
	}

	public void setManHSortRBWSOAutoNError(Integer manHSortRBWSOAutoNError) {
		this.manHSortRBWSOAutoNError = manHSortRBWSOAutoNError;
	}

	public Integer getManHSortDelAdjAutoYError() {
		return manHSortDelAdjAutoYError;
	}

	public void setManHSortDelAdjAutoYError(Integer manHSortDelAdjAutoYError) {
		this.manHSortDelAdjAutoYError = manHSortDelAdjAutoYError;
	}

	public Integer getManHSortDelAdjAutoNError() {
		return manHSortDelAdjAutoNError;
	}

	public void setManHSortDelAdjAutoNError(Integer manHSortDelAdjAutoNError) {
		this.manHSortDelAdjAutoNError = manHSortDelAdjAutoNError;
	}

	public Integer getManHSortConStmtAutoYError() {
		return manHSortConStmtAutoYError;
	}

	public void setManHSortConStmtAutoYError(Integer manHSortConStmtAutoYError) {
		this.manHSortConStmtAutoYError = manHSortConStmtAutoYError;
	}

	public Integer getManHSortConStmtAutoNError() {
		return manHSortConStmtAutoNError;
	}

	public void setManHSortConStmtAutoNError(Integer manHSortConStmtAutoNError) {
		this.manHSortConStmtAutoNError = manHSortConStmtAutoNError;
	}

	public Integer getTotalErrorCount() {
		return totalErrorCount;
	}

	public void setTotalErrorCount(Integer totalErrorCount) {
		this.totalErrorCount = totalErrorCount;
	}

	public Integer getErrorUsedCount() {
		return errorUsedCount;
	}

	public void setErrorUsedCount(Integer errorUsedCount) {
		this.errorUsedCount = errorUsedCount;
	}

	public Integer getCustDtelCount() {
		return custDtelCount;
	}

	public void setCustDtelCount(Integer custDtelCount) {
		this.custDtelCount = custDtelCount;
	}

	public Integer getCustUsedDtelCount() {
		return custUsedDtelCount;
	}

	public void setCustUsedDtelCount(Integer custUsedDtelCount) {
		this.custUsedDtelCount = custUsedDtelCount;
	}

	public Integer getDefectDtelCount() {
		return defectDtelCount;
	}

	public void setDefectDtelCount(Integer defectDtelCount) {
		this.defectDtelCount = defectDtelCount;
	}

	public Integer getErrorDtelCount() {
		return errorDtelCount;
	}

	public void setErrorDtelCount(Integer errorDtelCount) {
		this.errorDtelCount = errorDtelCount;
	}

	public Integer getDefectUsedDtelCount() {
		return defectUsedDtelCount;
	}

	public void setDefectUsedDtelCount(Integer defectUsedDtelCount) {
		this.defectUsedDtelCount = defectUsedDtelCount;
	}

	public Integer getErrorUsedDtelCount() {
		return errorUsedDtelCount;
	}

	public void setErrorUsedDtelCount(Integer errorUsedDtelCount) {
		this.errorUsedDtelCount = errorUsedDtelCount;
	}

	public Integer getAcProjectManagement() {
		return acProjectManagement;
	}

	public void setAcProjectManagement(Integer acProjectManagement) {
		this.acProjectManagement = acProjectManagement;
	}

	public Integer getAcGlobalTrade() {
		return acGlobalTrade;
	}

	public void setAcGlobalTrade(Integer acGlobalTrade) {
		this.acGlobalTrade = acGlobalTrade;
	}

	public Integer getAcCollaborativeEngineeringAndProjectManagement() {
		return acCollaborativeEngineeringAndProjectManagement;
	}

	public void setAcCollaborativeEngineeringAndProjectManagement(Integer acCollaborativeEngineeringAndProjectManagement) {
		this.acCollaborativeEngineeringAndProjectManagement = acCollaborativeEngineeringAndProjectManagement;
	}

	public Integer getAcResultsRecording() {
		return acResultsRecording;
	}

	public void setAcResultsRecording(Integer acResultsRecording) {
		this.acResultsRecording = acResultsRecording;
	}

	public Integer getAcDiscreteIndustriesAndMillProducts() {
		return acDiscreteIndustriesAndMillProducts;
	}

	public void setAcDiscreteIndustriesAndMillProducts(Integer acDiscreteIndustriesAndMillProducts) {
		this.acDiscreteIndustriesAndMillProducts = acDiscreteIndustriesAndMillProducts;
	}

	public Integer getAcGeneralLedgerAccounting() {
		return acGeneralLedgerAccounting;
	}

	public void setAcGeneralLedgerAccounting(Integer acGeneralLedgerAccounting) {
		this.acGeneralLedgerAccounting = acGeneralLedgerAccounting;
	}

	public Integer getAcActualCostingMaterialLedger() {
		return acActualCostingMaterialLedger;
	}

	public void setAcActualCostingMaterialLedger(Integer acActualCostingMaterialLedger) {
		this.acActualCostingMaterialLedger = acActualCostingMaterialLedger;
	}

	public Integer getAcPricingAndConditions() {
		return acPricingAndConditions;
	}

	public void setAcPricingAndConditions(Integer acPricingAndConditions) {
		this.acPricingAndConditions = acPricingAndConditions;
	}

	public Integer getAcCreditManagement() {
		return acCreditManagement;
	}

	public void setAcCreditManagement(Integer acCreditManagement) {
		this.acCreditManagement = acCreditManagement;
	}

	public Integer getAcManufacturerPartNumber() {
		return acManufacturerPartNumber;
	}

	public void setAcManufacturerPartNumber(Integer acManufacturerPartNumber) {
		this.acManufacturerPartNumber = acManufacturerPartNumber;
	}

	public Integer getAcSupplierWorkplace() {
		return acSupplierWorkplace;
	}

	public void setAcSupplierWorkplace(Integer acSupplierWorkplace) {
		this.acSupplierWorkplace = acSupplierWorkplace;
	}

	public Integer getAcDealerPortal() {
		return acDealerPortal;
	}

	public void setAcDealerPortal(Integer acDealerPortal) {
		this.acDealerPortal = acDealerPortal;
	}

	public Integer getAcSettlementManagement() {
		return acSettlementManagement;
	}

	public void setAcSettlementManagement(Integer acSettlementManagement) {
		this.acSettlementManagement = acSettlementManagement;
	}

	public Integer getAcTreasuryAndRiskManagement() {
		return acTreasuryAndRiskManagement;
	}

	public void setAcTreasuryAndRiskManagement(Integer acTreasuryAndRiskManagement) {
		this.acTreasuryAndRiskManagement = acTreasuryAndRiskManagement;
	}

	public Integer getAcCommodityManagement() {
		return acCommodityManagement;
	}

	public void setAcCommodityManagement(Integer acCommodityManagement) {
		this.acCommodityManagement = acCommodityManagement;
	}

	public Integer getAcEnhancementsActualLaborCostingTimeRecording() {
		return acEnhancementsActualLaborCostingTimeRecording;
	}

	public void setAcEnhancementsActualLaborCostingTimeRecording(Integer acEnhancementsActualLaborCostingTimeRecording) {
		this.acEnhancementsActualLaborCostingTimeRecording = acEnhancementsActualLaborCostingTimeRecording;
	}

	public Integer getAcInstalledBaseManagement() {
		return acInstalledBaseManagement;
	}

	public void setAcInstalledBaseManagement(Integer acInstalledBaseManagement) {
		this.acInstalledBaseManagement = acInstalledBaseManagement;
	}

	public Integer getAcBusinessPartners() {
		return acBusinessPartners;
	}

	public void setAcBusinessPartners(Integer acBusinessPartners) {
		this.acBusinessPartners = acBusinessPartners;
	}

	public Integer getAcSuiteEnablementForAriba() {
		return acSuiteEnablementForAriba;
	}

	public void setAcSuiteEnablementForAriba(Integer acSuiteEnablementForAriba) {
		this.acSuiteEnablementForAriba = acSuiteEnablementForAriba;
	}

	public Integer getAcArticles() {
		return acArticles;
	}

	public void setAcArticles(Integer acArticles) {
		this.acArticles = acArticles;
	}

	public Integer getAcConsumerDecisionTree() {
		return acConsumerDecisionTree;
	}

	public void setAcConsumerDecisionTree(Integer acConsumerDecisionTree) {
		this.acConsumerDecisionTree = acConsumerDecisionTree;
	}

	public Integer getAcAssortmentList() {
		return acAssortmentList;
	}

	public void setAcAssortmentList(Integer acAssortmentList) {
		this.acAssortmentList = acAssortmentList;
	}

	public Integer getAcAvailabilityCheck() {
		return acAvailabilityCheck;
	}

	public void setAcAvailabilityCheck(Integer acAvailabilityCheck) {
		this.acAvailabilityCheck = acAvailabilityCheck;
	}

	public Integer getAcSalesAndDistributionSdEnhancements() {
		return acSalesAndDistributionSdEnhancements;
	}

	public void setAcSalesAndDistributionSdEnhancements(Integer acSalesAndDistributionSdEnhancements) {
		this.acSalesAndDistributionSdEnhancements = acSalesAndDistributionSdEnhancements;
	}

	public Integer getAcConvergentInvoicing() {
		return acConvergentInvoicing;
	}

	public void setAcConvergentInvoicing(Integer acConvergentInvoicing) {
		this.acConvergentInvoicing = acConvergentInvoicing;
	}

	public Integer getAcSapCashManagement() {
		return acSapCashManagement;
	}

	public void setAcSapCashManagement(Integer acSapCashManagement) {
		this.acSapCashManagement = acSapCashManagement;
	}

	public Integer getAcVirtualDataModelForPpKanban() {
		return acVirtualDataModelForPpKanban;
	}

	public void setAcVirtualDataModelForPpKanban(Integer acVirtualDataModelForPpKanban) {
		this.acVirtualDataModelForPpKanban = acVirtualDataModelForPpKanban;
	}

	public Integer getAcMultichannelFoundationForUtilities() {
		return acMultichannelFoundationForUtilities;
	}

	public void setAcMultichannelFoundationForUtilities(Integer acMultichannelFoundationForUtilities) {
		this.acMultichannelFoundationForUtilities = acMultichannelFoundationForUtilities;
	}

	public Integer getAcTargetGroups() {
		return acTargetGroups;
	}

	public void setAcTargetGroups(Integer acTargetGroups) {
		this.acTargetGroups = acTargetGroups;
	}

	public Integer getAcCommodityManagementAnalytics() {
		return acCommodityManagementAnalytics;
	}

	public void setAcCommodityManagementAnalytics(Integer acCommodityManagementAnalytics) {
		this.acCommodityManagementAnalytics = acCommodityManagementAnalytics;
	}

	public Integer getAcLoansManagement() {
		return acLoansManagement;
	}

	public void setAcLoansManagement(Integer acLoansManagement) {
		this.acLoansManagement = acLoansManagement;
	}

	public Integer getAcGroupingPeggingDistribution() {
		return acGroupingPeggingDistribution;
	}

	public void setAcGroupingPeggingDistribution(Integer acGroupingPeggingDistribution) {
		this.acGroupingPeggingDistribution = acGroupingPeggingDistribution;
	}

	public Integer getAcBasicFunctions() {
		return acBasicFunctions;
	}

	public void setAcBasicFunctions(Integer acBasicFunctions) {
		this.acBasicFunctions = acBasicFunctions;
	}

	public Integer getAcContractManagement() {
		return acContractManagement;
	}

	public void setAcContractManagement(Integer acContractManagement) {
		this.acContractManagement = acContractManagement;
	}

	public Integer getAcTransactionManager() {
		return acTransactionManager;
	}

	public void setAcTransactionManager(Integer acTransactionManager) {
		this.acTransactionManager = acTransactionManager;
	}

	public Integer getAcExtendedLogistics() {
		return acExtendedLogistics;
	}

	public void setAcExtendedLogistics(Integer acExtendedLogistics) {
		this.acExtendedLogistics = acExtendedLogistics;
	}

	public Integer getAcProductConfigurator() {
		return acProductConfigurator;
	}

	public void setAcProductConfigurator(Integer acProductConfigurator) {
		this.acProductConfigurator = acProductConfigurator;
	}

	public Integer getAcFreightSettlement() {
		return acFreightSettlement;
	}

	public void setAcFreightSettlement(Integer acFreightSettlement) {
		this.acFreightSettlement = acFreightSettlement;
	}

	public Integer getAcCustomFields() {
		return acCustomFields;
	}

	public void setAcCustomFields(Integer acCustomFields) {
		this.acCustomFields = acCustomFields;
	}

	public Integer getAcFieldLengthExtensionForMaterial() {
		return acFieldLengthExtensionForMaterial;
	}

	public void setAcFieldLengthExtensionForMaterial(Integer acFieldLengthExtensionForMaterial) {
		this.acFieldLengthExtensionForMaterial = acFieldLengthExtensionForMaterial;
	}

	public Integer getAcProductMasterData() {
		return acProductMasterData;
	}

	public void setAcProductMasterData(Integer acProductMasterData) {
		this.acProductMasterData = acProductMasterData;
	}

	public Integer getAcAssetAccounting() {
		return acAssetAccounting;
	}

	public void setAcAssetAccounting(Integer acAssetAccounting) {
		this.acAssetAccounting = acAssetAccounting;
	}

	public Integer getAcFundAccounting() {
		return acFundAccounting;
	}

	public void setAcFundAccounting(Integer acFundAccounting) {
		this.acFundAccounting = acFundAccounting;
	}

	public Integer getAcCustomerInteractionCenter() {
		return acCustomerInteractionCenter;
	}

	public void setAcCustomerInteractionCenter(Integer acCustomerInteractionCenter) {
		this.acCustomerInteractionCenter = acCustomerInteractionCenter;
	}

	public Integer getAcFundsManagement() {
		return acFundsManagement;
	}

	public void setAcFundsManagement(Integer acFundsManagement) {
		this.acFundsManagement = acFundsManagement;
	}

	public Integer getAcInboundTracking() {
		return acInboundTracking;
	}

	public void setAcInboundTracking(Integer acInboundTracking) {
		this.acInboundTracking = acInboundTracking;
	}

	public Integer getAcDocumentManagementSystem() {
		return acDocumentManagementSystem;
	}

	public void setAcDocumentManagementSystem(Integer acDocumentManagementSystem) {
		this.acDocumentManagementSystem = acDocumentManagementSystem;
	}

	public Integer getAcSapUtilities() {
		return acSapUtilities;
	}

	public void setAcSapUtilities(Integer acSapUtilities) {
		this.acSapUtilities = acSapUtilities;
	}

	public Integer getAcConstructionEquipmentManagement() {
		return acConstructionEquipmentManagement;
	}

	public void setAcConstructionEquipmentManagement(Integer acConstructionEquipmentManagement) {
		this.acConstructionEquipmentManagement = acConstructionEquipmentManagement;
	}

	public Integer getAcRetailFashionManagementInS4Hana() {
		return acRetailFashionManagementInS4Hana;
	}

	public void setAcRetailFashionManagementInS4Hana(Integer acRetailFashionManagementInS4Hana) {
		this.acRetailFashionManagementInS4Hana = acRetailFashionManagementInS4Hana;
	}

	public Integer getAcLogisticsGeneralLoEnhancements() {
		return acLogisticsGeneralLoEnhancements;
	}

	public void setAcLogisticsGeneralLoEnhancements(Integer acLogisticsGeneralLoEnhancements) {
		this.acLogisticsGeneralLoEnhancements = acLogisticsGeneralLoEnhancements;
	}

	public Integer getAcFioriUi() {
		return acFioriUi;
	}

	public void setAcFioriUi(Integer acFioriUi) {
		this.acFioriUi = acFioriUi;
	}

	public Integer getAcFlightScheduling() {
		return acFlightScheduling;
	}

	public void setAcFlightScheduling(Integer acFlightScheduling) {
		this.acFlightScheduling = acFlightScheduling;
	}

	public Integer getAcPerishablesProcurement() {
		return acPerishablesProcurement;
	}

	public void setAcPerishablesProcurement(Integer acPerishablesProcurement) {
		this.acPerishablesProcurement = acPerishablesProcurement;
	}

	public Integer getAcPricecatalogue() {
		return acPricecatalogue;
	}

	public void setAcPricecatalogue(Integer acPricecatalogue) {
		this.acPricecatalogue = acPricecatalogue;
	}

	public Integer getAcAmountFieldExtension() {
		return acAmountFieldExtension;
	}

	public void setAcAmountFieldExtension(Integer acAmountFieldExtension) {
		this.acAmountFieldExtension = acAmountFieldExtension;
	}

	public Integer getAcChargeback() {
		return acChargeback;
	}

	public void setAcChargeback(Integer acChargeback) {
		this.acChargeback = acChargeback;
	}

	public Integer getAcCountrySpecificCustomizingFunctionality() {
		return acCountrySpecificCustomizingFunctionality;
	}

	public void setAcCountrySpecificCustomizingFunctionality(Integer acCountrySpecificCustomizingFunctionality) {
		this.acCountrySpecificCustomizingFunctionality = acCountrySpecificCustomizingFunctionality;
	}

	public Integer getAcGoodsReceiptCapacityCheck() {
		return acGoodsReceiptCapacityCheck;
	}

	public void setAcGoodsReceiptCapacityCheck(Integer acGoodsReceiptCapacityCheck) {
		this.acGoodsReceiptCapacityCheck = acGoodsReceiptCapacityCheck;
	}

	public Integer getAcProductStructureAndAssemblyManagement() {
		return acProductStructureAndAssemblyManagement;
	}

	public void setAcProductStructureAndAssemblyManagement(Integer acProductStructureAndAssemblyManagement) {
		this.acProductStructureAndAssemblyManagement = acProductStructureAndAssemblyManagement;
	}

	public Integer getAcOilGasSecondaryDistribution() {
		return acOilGasSecondaryDistribution;
	}

	public void setAcOilGasSecondaryDistribution(Integer acOilGasSecondaryDistribution) {
		this.acOilGasSecondaryDistribution = acOilGasSecondaryDistribution;
	}

	public Integer getAcInstoreProduction() {
		return acInstoreProduction;
	}

	public void setAcInstoreProduction(Integer acInstoreProduction) {
		this.acInstoreProduction = acInstoreProduction;
	}

	public Integer getAcLeaseAccounting() {
		return acLeaseAccounting;
	}

	public void setAcLeaseAccounting(Integer acLeaseAccounting) {
		this.acLeaseAccounting = acLeaseAccounting;
	}

	public Integer getAcIntrastatReporting() {
		return acIntrastatReporting;
	}

	public void setAcIntrastatReporting(Integer acIntrastatReporting) {
		this.acIntrastatReporting = acIntrastatReporting;
	}

	public Integer getAcProductDesigner() {
		return acProductDesigner;
	}

	public void setAcProductDesigner(Integer acProductDesigner) {
		this.acProductDesigner = acProductDesigner;
	}

	public Integer getAcExciseDutyWithActiveExtensionEaCp() {
		return acExciseDutyWithActiveExtensionEaCp;
	}

	public void setAcExciseDutyWithActiveExtensionEaCp(Integer acExciseDutyWithActiveExtensionEaCp) {
		this.acExciseDutyWithActiveExtensionEaCp = acExciseDutyWithActiveExtensionEaCp;
	}

	public Integer getAcContractAccountsReceivableAndPayable() {
		return acContractAccountsReceivableAndPayable;
	}

	public void setAcContractAccountsReceivableAndPayable(Integer acContractAccountsReceivableAndPayable) {
		this.acContractAccountsReceivableAndPayable = acContractAccountsReceivableAndPayable;
	}

	public Integer getAcBatchMaster() {
		return acBatchMaster;
	}

	public void setAcBatchMaster(Integer acBatchMaster) {
		this.acBatchMaster = acBatchMaster;
	}

	public Integer getAcMaterialRequirementsPlanning() {
		return acMaterialRequirementsPlanning;
	}

	public void setAcMaterialRequirementsPlanning(Integer acMaterialRequirementsPlanning) {
		this.acMaterialRequirementsPlanning = acMaterialRequirementsPlanning;
	}

	public Integer getAcManualAccruals() {
		return acManualAccruals;
	}

	public void setAcManualAccruals(Integer acManualAccruals) {
		this.acManualAccruals = acManualAccruals;
	}

	public Integer getAcIndustrySpecificComponentHighTech() {
		return acIndustrySpecificComponentHighTech;
	}

	public void setAcIndustrySpecificComponentHighTech(Integer acIndustrySpecificComponentHighTech) {
		this.acIndustrySpecificComponentHighTech = acIndustrySpecificComponentHighTech;
	}

	public Integer getAcDistributorResellerManagement() {
		return acDistributorResellerManagement;
	}

	public void setAcDistributorResellerManagement(Integer acDistributorResellerManagement) {
		this.acDistributorResellerManagement = acDistributorResellerManagement;
	}

	public Integer getAcRetailPricing() {
		return acRetailPricing;
	}

	public void setAcRetailPricing(Integer acRetailPricing) {
		this.acRetailPricing = acRetailPricing;
	}

	public Integer getAcGfClassification() {
		return acGfClassification;
	}

	public void setAcGfClassification(Integer acGfClassification) {
		this.acGfClassification = acGfClassification;
	}

	public Integer getAcMerchandiseAndAssortmentPlanning() {
		return acMerchandiseAndAssortmentPlanning;
	}

	public void setAcMerchandiseAndAssortmentPlanning(Integer acMerchandiseAndAssortmentPlanning) {
		this.acMerchandiseAndAssortmentPlanning = acMerchandiseAndAssortmentPlanning;
	}

	public Integer getAcProductionPlanningAndControlPpEnhancements() {
		return acProductionPlanningAndControlPpEnhancements;
	}

	public void setAcProductionPlanningAndControlPpEnhancements(Integer acProductionPlanningAndControlPpEnhancements) {
		this.acProductionPlanningAndControlPpEnhancements = acProductionPlanningAndControlPpEnhancements;
	}

	public Integer getAcSales() {
		return acSales;
	}

	public void setAcSales(Integer acSales) {
		this.acSales = acSales;
	}

	public Integer getAcDependencies() {
		return acDependencies;
	}

	public void setAcDependencies(Integer acDependencies) {
		this.acDependencies = acDependencies;
	}

	public Integer getAcMaintenanceOrders() {
		return acMaintenanceOrders;
	}

	public void setAcMaintenanceOrders(Integer acMaintenanceOrders) {
		this.acMaintenanceOrders = acMaintenanceOrders;
	}

	public Integer getAcBrazil() {
		return acBrazil;
	}

	public void setAcBrazil(Integer acBrazil) {
		this.acBrazil = acBrazil;
	}

	public Integer getAcBillingOfQuantity() {
		return acBillingOfQuantity;
	}

	public void setAcBillingOfQuantity(Integer acBillingOfQuantity) {
		this.acBillingOfQuantity = acBillingOfQuantity;
	}

	public Integer getAcBillOfServices() {
		return acBillOfServices;
	}

	public void setAcBillOfServices(Integer acBillOfServices) {
		this.acBillOfServices = acBillOfServices;
	}

	public Integer getAcHydrocarbonProductManagement() {
		return acHydrocarbonProductManagement;
	}

	public void setAcHydrocarbonProductManagement(Integer acHydrocarbonProductManagement) {
		this.acHydrocarbonProductManagement = acHydrocarbonProductManagement;
	}

	public Integer getAcProductCatalog() {
		return acProductCatalog;
	}

	public void setAcProductCatalog(Integer acProductCatalog) {
		this.acProductCatalog = acProductCatalog;
	}

	public Integer getAcBulkSecondaryLogisticsManagement() {
		return acBulkSecondaryLogisticsManagement;
	}

	public void setAcBulkSecondaryLogisticsManagement(Integer acBulkSecondaryLogisticsManagement) {
		this.acBulkSecondaryLogisticsManagement = acBulkSecondaryLogisticsManagement;
	}

	public Integer getAcBusinessAnalytics() {
		return acBusinessAnalytics;
	}

	public void setAcBusinessAnalytics(Integer acBusinessAnalytics) {
		this.acBusinessAnalytics = acBusinessAnalytics;
	}

	public Integer getAcPlmEnterpriseSearch() {
		return acPlmEnterpriseSearch;
	}

	public void setAcPlmEnterpriseSearch(Integer acPlmEnterpriseSearch) {
		this.acPlmEnterpriseSearch = acPlmEnterpriseSearch;
	}

	public Integer getAcLabeling() {
		return acLabeling;
	}

	public void setAcLabeling(Integer acLabeling) {
		this.acLabeling = acLabeling;
	}

	public Integer getAcRecipeDevelopment() {
		return acRecipeDevelopment;
	}

	public void setAcRecipeDevelopment(Integer acRecipeDevelopment) {
		this.acRecipeDevelopment = acRecipeDevelopment;
	}

	public Integer getAcPortalContent() {
		return acPortalContent;
	}

	public void setAcPortalContent(Integer acPortalContent) {
		this.acPortalContent = acPortalContent;
	}

	public Integer getAcPortfolioManagement() {
		return acPortfolioManagement;
	}

	public void setAcPortfolioManagement(Integer acPortfolioManagement) {
		this.acPortfolioManagement = acPortfolioManagement;
	}

	public Integer getAcPricecatalogueOutbound() {
		return acPricecatalogueOutbound;
	}

	public void setAcPricecatalogueOutbound(Integer acPricecatalogueOutbound) {
		this.acPricecatalogueOutbound = acPricecatalogueOutbound;
	}

	public Integer getAcProducts() {
		return acProducts;
	}

	public void setAcProducts(Integer acProducts) {
		this.acProducts = acProducts;
	}

	public Integer getAcQualityManagement() {
		return acQualityManagement;
	}

	public void setAcQualityManagement(Integer acQualityManagement) {
		this.acQualityManagement = acQualityManagement;
	}

	public Integer getAcHomeBuilidngSolutions() {
		return acHomeBuilidngSolutions;
	}

	public void setAcHomeBuilidngSolutions(Integer acHomeBuilidngSolutions) {
		this.acHomeBuilidngSolutions = acHomeBuilidngSolutions;
	}

	public Integer getAcRecipe() {
		return acRecipe;
	}

	public void setAcRecipe(Integer acRecipe) {
		this.acRecipe = acRecipe;
	}

	public Integer getAcClassification() {
		return acClassification;
	}

	public void setAcClassification(Integer acClassification) {
		this.acClassification = acClassification;
	}

	public Integer getAcBopfBusinessObjectFrameworkForAbap() {
		return acBopfBusinessObjectFrameworkForAbap;
	}

	public void setAcBopfBusinessObjectFrameworkForAbap(Integer acBopfBusinessObjectFrameworkForAbap) {
		this.acBopfBusinessObjectFrameworkForAbap = acBopfBusinessObjectFrameworkForAbap;
	}

	public Integer getAcSapSimpleFinanceDataMigration() {
		return acSapSimpleFinanceDataMigration;
	}

	public void setAcSapSimpleFinanceDataMigration(Integer acSapSimpleFinanceDataMigration) {
		this.acSapSimpleFinanceDataMigration = acSapSimpleFinanceDataMigration;
	}

	public Integer getAcReplenishment() {
		return acReplenishment;
	}

	public void setAcReplenishment(Integer acReplenishment) {
		this.acReplenishment = acReplenishment;
	}

	public Integer getAcAdditionalsManagement() {
		return acAdditionalsManagement;
	}

	public void setAcAdditionalsManagement(Integer acAdditionalsManagement) {
		this.acAdditionalsManagement = acAdditionalsManagement;
	}

	public Integer getAcFreeGoods() {
		return acFreeGoods;
	}

	public void setAcFreeGoods(Integer acFreeGoods) {
		this.acFreeGoods = acFreeGoods;
	}

	public Integer getAcAnalyticalApplications() {
		return acAnalyticalApplications;
	}

	public void setAcAnalyticalApplications(Integer acAnalyticalApplications) {
		this.acAnalyticalApplications = acAnalyticalApplications;
	}

	public Integer getAcRetailDemandManagement() {
		return acRetailDemandManagement;
	}

	public void setAcRetailDemandManagement(Integer acRetailDemandManagement) {
		this.acRetailDemandManagement = acRetailDemandManagement;
	}

	public Integer getAcLogisticsBasicData() {
		return acLogisticsBasicData;
	}

	public void setAcLogisticsBasicData(Integer acLogisticsBasicData) {
		this.acLogisticsBasicData = acLogisticsBasicData;
	}

	public Integer getAcRetailInformationSystem() {
		return acRetailInformationSystem;
	}

	public void setAcRetailInformationSystem(Integer acRetailInformationSystem) {
		this.acRetailInformationSystem = acRetailInformationSystem;
	}

	public Integer getAcPurchaseOrders() {
		return acPurchaseOrders;
	}

	public void setAcPurchaseOrders(Integer acPurchaseOrders) {
		this.acPurchaseOrders = acPurchaseOrders;
	}

	public Integer getAcRetailLedger() {
		return acRetailLedger;
	}

	public void setAcRetailLedger(Integer acRetailLedger) {
		this.acRetailLedger = acRetailLedger;
	}

	public Integer getAcPromotion() {
		return acPromotion;
	}

	public void setAcPromotion(Integer acPromotion) {
		this.acPromotion = acPromotion;
	}

	public Integer getAcRetailMethodOfAccounting() {
		return acRetailMethodOfAccounting;
	}

	public void setAcRetailMethodOfAccounting(Integer acRetailMethodOfAccounting) {
		this.acRetailMethodOfAccounting = acRetailMethodOfAccounting;
	}

	public Integer getAcRetail() {
		return acRetail;
	}

	public void setAcRetail(Integer acRetail) {
		this.acRetail = acRetail;
	}

	public Integer getAcLoadBuilding() {
		return acLoadBuilding;
	}

	public void setAcLoadBuilding(Integer acLoadBuilding) {
		this.acLoadBuilding = acLoadBuilding;
	}

	public Integer getAcInventoryManagement() {
		return acInventoryManagement;
	}

	public void setAcInventoryManagement(Integer acInventoryManagement) {
		this.acInventoryManagement = acInventoryManagement;
	}

	public Integer getAcSalesPriceValuation() {
		return acSalesPriceValuation;
	}

	public void setAcSalesPriceValuation(Integer acSalesPriceValuation) {
		this.acSalesPriceValuation = acSalesPriceValuation;
	}

	public Integer getAcIndustryRetailAndFashion() {
		return acIndustryRetailAndFashion;
	}

	public void setAcIndustryRetailAndFashion(Integer acIndustryRetailAndFashion) {
		this.acIndustryRetailAndFashion = acIndustryRetailAndFashion;
	}

	public Integer getAcSapRetailStore() {
		return acSapRetailStore;
	}

	public void setAcSapRetailStore(Integer acSapRetailStore) {
		this.acSapRetailStore = acSapRetailStore;
	}

	public Integer getAcAutomaticDocumentAdjustment() {
		return acAutomaticDocumentAdjustment;
	}

	public void setAcAutomaticDocumentAdjustment(Integer acAutomaticDocumentAdjustment) {
		this.acAutomaticDocumentAdjustment = acAutomaticDocumentAdjustment;
	}

	public Integer getAcSalesSupport() {
		return acSalesSupport;
	}

	public void setAcSalesSupport(Integer acSalesSupport) {
		this.acSalesSupport = acSalesSupport;
	}

	public Integer getAcERecruiting() {
		return acERecruiting;
	}

	public void setAcERecruiting(Integer acERecruiting) {
		this.acERecruiting = acERecruiting;
	}

	public Integer getAcTrainingManagement() {
		return acTrainingManagement;
	}

	public void setAcTrainingManagement(Integer acTrainingManagement) {
		this.acTrainingManagement = acTrainingManagement;
	}

	public Integer getAcWasteManagement() {
		return acWasteManagement;
	}

	public void setAcWasteManagement(Integer acWasteManagement) {
		this.acWasteManagement = acWasteManagement;
	}

	public Integer getAcBilling() {
		return acBilling;
	}

	public void setAcBilling(Integer acBilling) {
		this.acBilling = acBilling;
	}

	public Integer getAcOrdersAndContracts() {
		return acOrdersAndContracts;
	}

	public void setAcOrdersAndContracts(Integer acOrdersAndContracts) {
		this.acOrdersAndContracts = acOrdersAndContracts;
	}

	public Integer getAcProjectSystem() {
		return acProjectSystem;
	}

	public void setAcProjectSystem(Integer acProjectSystem) {
		this.acProjectSystem = acProjectSystem;
	}

	public Integer getAcInformationSystem() {
		return acInformationSystem;
	}

	public void setAcInformationSystem(Integer acInformationSystem) {
		this.acInformationSystem = acInformationSystem;
	}

	public Integer getAcMaterialMaster() {
		return acMaterialMaster;
	}

	public void setAcMaterialMaster(Integer acMaterialMaster) {
		this.acMaterialMaster = acMaterialMaster;
	}

	public Integer getAcWorkbenchUtilities() {
		return acWorkbenchUtilities;
	}

	public void setAcWorkbenchUtilities(Integer acWorkbenchUtilities) {
		this.acWorkbenchUtilities = acWorkbenchUtilities;
	}

	public Integer getAcSoftwareLicenseManagement() {
		return acSoftwareLicenseManagement;
	}

	public void setAcSoftwareLicenseManagement(Integer acSoftwareLicenseManagement) {
		this.acSoftwareLicenseManagement = acSoftwareLicenseManagement;
	}

	public Integer getAcCrossApplicationComponentCaEnhancements() {
		return acCrossApplicationComponentCaEnhancements;
	}

	public void setAcCrossApplicationComponentCaEnhancements(Integer acCrossApplicationComponentCaEnhancements) {
		this.acCrossApplicationComponentCaEnhancements = acCrossApplicationComponentCaEnhancements;
	}

	public Integer getAcOrderAllocationRun() {
		return acOrderAllocationRun;
	}

	public void setAcOrderAllocationRun(Integer acOrderAllocationRun) {
		this.acOrderAllocationRun = acOrderAllocationRun;
	}

	public Integer getAcNetweaverEnterpriseSearch() {
		return acNetweaverEnterpriseSearch;
	}

	public void setAcNetweaverEnterpriseSearch(Integer acNetweaverEnterpriseSearch) {
		this.acNetweaverEnterpriseSearch = acNetweaverEnterpriseSearch;
	}

	public Integer getAcMeasurementSystem() {
		return acMeasurementSystem;
	}

	public void setAcMeasurementSystem(Integer acMeasurementSystem) {
		this.acMeasurementSystem = acMeasurementSystem;
	}

	public Integer getAcFind() {
		return acFind;
	}

	public void setAcFind(Integer acFind) {
		this.acFind = acFind;
	}

	public Integer getAcProductSafety() {
		return acProductSafety;
	}

	public void setAcProductSafety(Integer acProductSafety) {
		this.acProductSafety = acProductSafety;
	}

	public Integer getAcExpenditureCertification() {
		return acExpenditureCertification;
	}

	public void setAcExpenditureCertification(Integer acExpenditureCertification) {
		this.acExpenditureCertification = acExpenditureCertification;
	}

	public Integer getAcRebateProcessing() {
		return acRebateProcessing;
	}

	public void setAcRebateProcessing(Integer acRebateProcessing) {
		this.acRebateProcessing = acRebateProcessing;
	}

	public Integer getAcPlmWebUserInterface() {
		return acPlmWebUserInterface;
	}

	public void setAcPlmWebUserInterface(Integer acPlmWebUserInterface) {
		this.acPlmWebUserInterface = acPlmWebUserInterface;
	}

	public Integer getAcBillsOfMaterial() {
		return acBillsOfMaterial;
	}

	public void setAcBillsOfMaterial(Integer acBillsOfMaterial) {
		this.acBillsOfMaterial = acBillsOfMaterial;
	}

	public Integer getAcConstructionProgressReport() {
		return acConstructionProgressReport;
	}

	public void setAcConstructionProgressReport(Integer acConstructionProgressReport) {
		this.acConstructionProgressReport = acConstructionProgressReport;
	}

	public Integer getAcRiskAssessment() {
		return acRiskAssessment;
	}

	public void setAcRiskAssessment(Integer acRiskAssessment) {
		this.acRiskAssessment = acRiskAssessment;
	}

	public Integer getAcConfirmation() {
		return acConfirmation;
	}

	public void setAcConfirmation(Integer acConfirmation) {
		this.acConfirmation = acConfirmation;
	}

	public Integer getAcTraderSchedulerWorkbench() {
		return acTraderSchedulerWorkbench;
	}

	public void setAcTraderSchedulerWorkbench(Integer acTraderSchedulerWorkbench) {
		this.acTraderSchedulerWorkbench = acTraderSchedulerWorkbench;
	}

	public Integer getAcEnetting() {
		return acEnetting;
	}

	public void setAcEnetting(Integer acEnetting) {
		this.acEnetting = acEnetting;
	}

	public Integer getAcProductionOrders() {
		return acProductionOrders;
	}

	public void setAcProductionOrders(Integer acProductionOrders) {
		this.acProductionOrders = acProductionOrders;
	}

	public Integer getAcExchanges() {
		return acExchanges;
	}

	public void setAcExchanges(Integer acExchanges) {
		this.acExchanges = acExchanges;
	}

	public Integer getAcGoodsMovementValuation() {
		return acGoodsMovementValuation;
	}

	public void setAcGoodsMovementValuation(Integer acGoodsMovementValuation) {
		this.acGoodsMovementValuation = acGoodsMovementValuation;
	}

	public Integer getAcMaintenanceProcessing() {
		return acMaintenanceProcessing;
	}

	public void setAcMaintenanceProcessing(Integer acMaintenanceProcessing) {
		this.acMaintenanceProcessing = acMaintenanceProcessing;
	}

	public Integer getAcDownstream() {
		return acDownstream;
	}

	public void setAcDownstream(Integer acDownstream) {
		this.acDownstream = acDownstream;
	}

	public Integer getAcProductStructure() {
		return acProductStructure;
	}

	public void setAcProductStructure(Integer acProductStructure) {
		this.acProductStructure = acProductStructure;
	}

	public Integer getAcConsulting() {
		return acConsulting;
	}

	public void setAcConsulting(Integer acConsulting) {
		this.acConsulting = acConsulting;
	}

	public Integer getAcScheduling() {
		return acScheduling;
	}

	public void setAcScheduling(Integer acScheduling) {
		this.acScheduling = acScheduling;
	}

	public Integer getAcReporting() {
		return acReporting;
	}

	public void setAcReporting(Integer acReporting) {
		this.acReporting = acReporting;
	}

	public Integer getAcKanban() {
		return acKanban;
	}

	public void setAcKanban(Integer acKanban) {
		this.acKanban = acKanban;
	}

	public Integer getAcIndia() {
		return acIndia;
	}

	public void setAcIndia(Integer acIndia) {
		this.acIndia = acIndia;
	}

	public Integer getAcSearch() {
		return acSearch;
	}

	public void setAcSearch(Integer acSearch) {
		this.acSearch = acSearch;
	}

	public Integer getAcRevenueRecognition() {
		return acRevenueRecognition;
	}

	public void setAcRevenueRecognition(Integer acRevenueRecognition) {
		this.acRevenueRecognition = acRevenueRecognition;
	}

	public Integer getAcSubsequentSettlement() {
		return acSubsequentSettlement;
	}

	public void setAcSubsequentSettlement(Integer acSubsequentSettlement) {
		this.acSubsequentSettlement = acSubsequentSettlement;
	}

	public Integer getAcInterfaceToExternalProjectSoftware() {
		return acInterfaceToExternalProjectSoftware;
	}

	public void setAcInterfaceToExternalProjectSoftware(Integer acInterfaceToExternalProjectSoftware) {
		this.acInterfaceToExternalProjectSoftware = acInterfaceToExternalProjectSoftware;
	}

	public Integer getAcBusinessSuiteReleaseInformation() {
		return acBusinessSuiteReleaseInformation;
	}

	public void setAcBusinessSuiteReleaseInformation(Integer acBusinessSuiteReleaseInformation) {
		this.acBusinessSuiteReleaseInformation = acBusinessSuiteReleaseInformation;
	}

	public Integer getAcProductionOptimizationInterfacePoi() {
		return acProductionOptimizationInterfacePoi;
	}

	public void setAcProductionOptimizationInterfacePoi(Integer acProductionOptimizationInterfacePoi) {
		this.acProductionOptimizationInterfacePoi = acProductionOptimizationInterfacePoi;
	}

	public Integer getAcFunctionsForUSFederalGovernment() {
		return acFunctionsForUSFederalGovernment;
	}

	public void setAcFunctionsForUSFederalGovernment(Integer acFunctionsForUSFederalGovernment) {
		this.acFunctionsForUSFederalGovernment = acFunctionsForUSFederalGovernment;
	}

	public Integer getAcIndustrialHygieneAndSafety() {
		return acIndustrialHygieneAndSafety;
	}

	public void setAcIndustrialHygieneAndSafety(Integer acIndustrialHygieneAndSafety) {
		this.acIndustrialHygieneAndSafety = acIndustrialHygieneAndSafety;
	}

	public Integer getAcOccupationalHealth() {
		return acOccupationalHealth;
	}

	public void setAcOccupationalHealth(Integer acOccupationalHealth) {
		this.acOccupationalHealth = acOccupationalHealth;
	}

	public Integer getAcBasicDataAndTools() {
		return acBasicDataAndTools;
	}

	public void setAcBasicDataAndTools(Integer acBasicDataAndTools) {
		this.acBasicDataAndTools = acBasicDataAndTools;
	}

	public Integer getAcProductCompliance() {
		return acProductCompliance;
	}

	public void setAcProductCompliance(Integer acProductCompliance) {
		this.acProductCompliance = acProductCompliance;
	}

	public Integer getAcSapProductAndReachCompliance() {
		return acSapProductAndReachCompliance;
	}

	public void setAcSapProductAndReachCompliance(Integer acSapProductAndReachCompliance) {
		this.acSapProductAndReachCompliance = acSapProductAndReachCompliance;
	}

	public Integer getAcExternalServiceAgent() {
		return acExternalServiceAgent;
	}

	public void setAcExternalServiceAgent(Integer acExternalServiceAgent) {
		this.acExternalServiceAgent = acExternalServiceAgent;
	}

	public Integer getAcComplaintsProcessing() {
		return acComplaintsProcessing;
	}

	public void setAcComplaintsProcessing(Integer acComplaintsProcessing) {
		this.acComplaintsProcessing = acComplaintsProcessing;
	}

	public Integer getAcForecastingProcedures() {
		return acForecastingProcedures;
	}

	public void setAcForecastingProcedures(Integer acForecastingProcedures) {
		this.acForecastingProcedures = acForecastingProcedures;
	}

	public Integer getAcEnhancementsInTransportationBordero() {
		return acEnhancementsInTransportationBordero;
	}

	public void setAcEnhancementsInTransportationBordero(Integer acEnhancementsInTransportationBordero) {
		this.acEnhancementsInTransportationBordero = acEnhancementsInTransportationBordero;
	}

	public Integer getAcSoftwareMaintenanceProcessing() {
		return acSoftwareMaintenanceProcessing;
	}

	public void setAcSoftwareMaintenanceProcessing(Integer acSoftwareMaintenanceProcessing) {
		this.acSoftwareMaintenanceProcessing = acSoftwareMaintenanceProcessing;
	}

	public Integer getAcPerishablesPlanning() {
		return acPerishablesPlanning;
	}

	public void setAcPerishablesPlanning(Integer acPerishablesPlanning) {
		this.acPerishablesPlanning = acPerishablesPlanning;
	}

	public Integer getAcAlternativeHistoricalDataForForecasting() {
		return acAlternativeHistoricalDataForForecasting;
	}

	public void setAcAlternativeHistoricalDataForForecasting(Integer acAlternativeHistoricalDataForForecasting) {
		this.acAlternativeHistoricalDataForForecasting = acAlternativeHistoricalDataForForecasting;
	}

	public Integer getAcMerchandiseCategories() {
		return acMerchandiseCategories;
	}

	public void setAcMerchandiseCategories(Integer acMerchandiseCategories) {
		this.acMerchandiseCategories = acMerchandiseCategories;
	}

	public Integer getAcBpForSubcontracting() {
		return acBpForSubcontracting;
	}

	public void setAcBpForSubcontracting(Integer acBpForSubcontracting) {
		this.acBpForSubcontracting = acBpForSubcontracting;
	}

	public Integer getAcCollaborationFolders() {
		return acCollaborationFolders;
	}

	public void setAcCollaborationFolders(Integer acCollaborationFolders) {
		this.acCollaborationFolders = acCollaborationFolders;
	}

	public Integer getAcGeneralFunctions() {
		return acGeneralFunctions;
	}

	public void setAcGeneralFunctions(Integer acGeneralFunctions) {
		this.acGeneralFunctions = acGeneralFunctions;
	}

	public Integer getAcRoutingEbomAssignment() {
		return acRoutingEbomAssignment;
	}

	public void setAcRoutingEbomAssignment(Integer acRoutingEbomAssignment) {
		this.acRoutingEbomAssignment = acRoutingEbomAssignment;
	}

	public Integer getManUnsortIntTabAccFMAutoY() {
		return manUnsortIntTabAccFMAutoY;
	}

	public void setManUnsortIntTabAccFMAutoY(Integer manUnsortIntTabAccFMAutoY) {
		this.manUnsortIntTabAccFMAutoY = manUnsortIntTabAccFMAutoY;
	}

	public Integer getManUnsortIntTabAccFMAutoYError() {
		return manUnsortIntTabAccFMAutoYError;
	}

	public void setManUnsortIntTabAccFMAutoYError(Integer manUnsortIntTabAccFMAutoYError) {
		this.manUnsortIntTabAccFMAutoYError = manUnsortIntTabAccFMAutoYError;
	}

	public Integer getCust_BWTRCount() {
		return cust_BWTRCount;
	}

	public void setCust_BWTRCount(Integer cust_BWTRCount) {
		this.cust_BWTRCount = cust_BWTRCount;
	}

	public Integer getCust_BWTSCount() {
		return cust_BWTSCount;
	}

	public void setCust_BWTSCount(Integer cust_BWTSCount) {
		this.cust_BWTSCount = cust_BWTSCount;
	}

	public Integer getCust_BWURCount() {
		return cust_BWURCount;
	}

	public void setCust_BWURCount(Integer cust_BWURCount) {
		this.cust_BWURCount = cust_BWURCount;
	}

	public Integer getCust_BWIGCount() {
		return cust_BWIGCount;
	}

	public void setCust_BWIGCount(Integer cust_BWIGCount) {
		this.cust_BWIGCount = cust_BWIGCount;
	}

	public Integer getCustUsed_BWTRCount() {
		return custUsed_BWTRCount;
	}

	public void setCustUsed_BWTRCount(Integer custUsed_BWTRCount) {
		this.custUsed_BWTRCount = custUsed_BWTRCount;
	}

	public Integer getCustUsed_BWTSCount() {
		return custUsed_BWTSCount;
	}

	public void setCustUsed_BWTSCount(Integer custUsed_BWTSCount) {
		this.custUsed_BWTSCount = custUsed_BWTSCount;
	}

	public Integer getCustUsed_BWURCount() {
		return custUsed_BWURCount;
	}

	public void setCustUsed_BWURCount(Integer custUsed_BWURCount) {
		this.custUsed_BWURCount = custUsed_BWURCount;
	}

	public Integer getCustUsed_BWIGCount() {
		return custUsed_BWIGCount;
	}

	public void setCustUsed_BWIGCount(Integer custUsed_BWIGCount) {
		this.custUsed_BWIGCount = custUsed_BWIGCount;
	}

	public Integer getDefect_BWTRCount() {
		return defect_BWTRCount;
	}

	public void setDefect_BWTRCount(Integer defect_BWTRCount) {
		this.defect_BWTRCount = defect_BWTRCount;
	}

	public Integer getDefect_BWTSCount() {
		return defect_BWTSCount;
	}

	public void setDefect_BWTSCount(Integer defect_BWTSCount) {
		this.defect_BWTSCount = defect_BWTSCount;
	}

	public Integer getDefect_BWURCount() {
		return defect_BWURCount;
	}

	public void setDefect_BWURCount(Integer defect_BWURCount) {
		this.defect_BWURCount = defect_BWURCount;
	}

	public Integer getDefect_BWIGCount() {
		return defect_BWIGCount;
	}

	public void setDefect_BWIGCount(Integer defect_BWIGCount) {
		this.defect_BWIGCount = defect_BWIGCount;
	}

	public Integer getErrorBWTRCount() {
		return errorBWTRCount;
	}

	public void setErrorBWTRCount(Integer errorBWTRCount) {
		this.errorBWTRCount = errorBWTRCount;
	}

	public Integer getErrorBWTSCount() {
		return errorBWTSCount;
	}

	public void setErrorBWTSCount(Integer errorBWTSCount) {
		this.errorBWTSCount = errorBWTSCount;
	}

	public Integer getErrorBWURCount() {
		return errorBWURCount;
	}

	public void setErrorBWURCount(Integer errorBWURCount) {
		this.errorBWURCount = errorBWURCount;
	}

	public Integer getErrorBWIGCount() {
		return errorBWIGCount;
	}

	public void setErrorBWIGCount(Integer errorBWIGCount) {
		this.errorBWIGCount = errorBWIGCount;
	}

	public Integer getDefectUsed_BWTRCount() {
		return defectUsed_BWTRCount;
	}

	public void setDefectUsed_BWTRCount(Integer defectUsed_BWTRCount) {
		this.defectUsed_BWTRCount = defectUsed_BWTRCount;
	}

	public Integer getDefectUsed_BWTSCount() {
		return defectUsed_BWTSCount;
	}

	public void setDefectUsed_BWTSCount(Integer defectUsed_BWTSCount) {
		this.defectUsed_BWTSCount = defectUsed_BWTSCount;
	}

	public Integer getDefectUsed_BWURCount() {
		return defectUsed_BWURCount;
	}

	public void setDefectUsed_BWURCount(Integer defectUsed_BWURCount) {
		this.defectUsed_BWURCount = defectUsed_BWURCount;
	}

	public Integer getDefectUsed_BWIGCount() {
		return defectUsed_BWIGCount;
	}

	public void setDefectUsed_BWIGCount(Integer defectUsed_BWIGCount) {
		this.defectUsed_BWIGCount = defectUsed_BWIGCount;
	}

	public Integer getErrorUsedBWTRCount() {
		return errorUsedBWTRCount;
	}

	public void setErrorUsedBWTRCount(Integer errorUsedBWTRCount) {
		this.errorUsedBWTRCount = errorUsedBWTRCount;
	}

	public Integer getErrorUsedBWTSCount() {
		return errorUsedBWTSCount;
	}

	public void setErrorUsedBWTSCount(Integer errorUsedBWTSCount) {
		this.errorUsedBWTSCount = errorUsedBWTSCount;
	}

	public Integer getErrorUsedBWURCount() {
		return errorUsedBWURCount;
	}

	public void setErrorUsedBWURCount(Integer errorUsedBWURCount) {
		this.errorUsedBWURCount = errorUsedBWURCount;
	}

	public Integer getErrorUsedBWIGCount() {
		return errorUsedBWIGCount;
	}

	public void setErrorUsedBWIGCount(Integer errorUsedBWIGCount) {
		this.errorUsedBWIGCount = errorUsedBWIGCount;
	}
}
