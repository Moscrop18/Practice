/*CR-12.0- Create Master table of request after completion. - 22/02/2017 - monika.mishra
 * 
 *CR-13.0- Rename the category & subcatefory. - 09/03/2017 - monika.mishra
 * */

package com.accenture.master;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "TestingScopeMaster")
public class TestingScope {	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Integer Id;
	
	@Column(name = "Request_ID", nullable = false)
	@Index(name="Index_Request_id")
	private long	requestID	;
	
	@Column(name = "Object_count", columnDefinition = "LONGTEXT")
	private String	Object_count	;
	
	@Column(name = "process_count", columnDefinition = "LONGTEXT")
	private String	process_count	;
	
	@Column(name = "processObjectcount", columnDefinition = "LONGTEXT")
	private String	processObjectcount	;
	
	@Column(name = "processMasterMap", columnDefinition = "LONGTEXT")
	private String	processMasterMap	;
	
	@Column(name="uniqueCustomAndStandardTransactionsCntMap", columnDefinition = "LONGTEXT")
	private String uniqueCustomAndStandardTransactionsCntMap;

	public String getUniqueCustomAndStandardTransactionsCntMap() {
		return uniqueCustomAndStandardTransactionsCntMap;
	}

	public void setUniqueCustomAndStandardTransactionsCntMap(String uniqueCustomAndStandardTransactionsCntMap) {
		this.uniqueCustomAndStandardTransactionsCntMap = uniqueCustomAndStandardTransactionsCntMap;
	}

	public long getRequestID() {
		return requestID;
	}

	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}

	public String getObject_count() {
		return Object_count;
	}

	public void setObject_count(String object_count) {
		Object_count = object_count;
	}

	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
		Id = id;
	}

	public String getProcess_count() {
		return process_count;
	}

	public void setProcess_count(String process_count) {
		this.process_count = process_count;
	}

	public String getProcessObjectcount() {
		return processObjectcount;
	}

	public void setProcessObjectcount(String processObjectcount) {
		this.processObjectcount = processObjectcount;
	}

	public String getProcessMasterMap() {
		return processMasterMap;
	}

	public void setProcessMasterMap(String processMasterMap) {
		this.processMasterMap = processMasterMap;
	}
}
