package com.accenture.POCUtility.models;

import javax.persistence.Column;

public class POC_InactiveObjects {

	private String objName;
	private String object;
	private String uName;
	private String deleteFlag;	
	private long requestId;
	private String tabClass;
	
	public String getObjName() {
		return objName;
	}
	public void setObjName(String objName) {
		this.objName = objName;
	}
	public String getObject() {
		return object;
	}
	public void setObject(String object) {
		this.object = object;
	}
	public String getuName() {
		return uName;
	}
	public void setuName(String uName) {
		this.uName = uName;
	}
	public String getDeleteFlag() {
		return deleteFlag;
	}
	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getTabClass() {
		return tabClass;
	}
	public void setTabClass(String tabClass) {
		this.tabClass = tabClass;
	}
}
