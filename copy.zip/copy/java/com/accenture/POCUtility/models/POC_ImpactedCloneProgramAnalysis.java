package com.accenture.POCUtility.models;

public class POC_ImpactedCloneProgramAnalysis{

	private long requestId;
	private String impactedProgram;
	private String cloneProgram;
	private String descriptionOfChange;
	private String solutionStep;
	private String relatedNote;
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getImpactedProgram() {
		return impactedProgram;
	}
	public void setImpactedProgram(String impactedProgram) {
		this.impactedProgram = impactedProgram;
	}
	public String getCloneProgram() {
		return cloneProgram;
	}
	public void setCloneProgram(String cloneProgram) {
		this.cloneProgram = cloneProgram;
	}
	public String getDescriptionOfChange() {
		return descriptionOfChange;
	}
	public void setDescriptionOfChange(String descriptionOfChange) {
		this.descriptionOfChange = descriptionOfChange;
	}
	public String getSolutionStep() {
		return solutionStep;
	}
	public void setSolutionStep(String solutionStep) {
		this.solutionStep = solutionStep;
	}
	public String getRelatedNote() {
		return relatedNote;
	}
	public void setRelatedNote(String relatedNote) {
		this.relatedNote = relatedNote;
	}
	
	
}