package com.accenture.POCUtility.models;

public class POC_ImpactedTables{

	private long requestId;
	private String object;
	private String description;
	private String solutionSteps;
	private String sapNotes;
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getObject() {
		return object;
	}
	public void setObject(String object) {
		this.object = object;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getSolutionSteps() {
		return solutionSteps;
	}
	public void setSolutionSteps(String solutionSteps) {
		this.solutionSteps = solutionSteps;
	}
	public String getSapNotes() {
		return sapNotes;
	}
	public void setSapNotes(String sapNotes) {
		this.sapNotes = sapNotes;
	}
	
	
}