package com.accenture.POCUtility.models;

import javax.persistence.Column;

public class POC_BWCleanUpUtility {
	private String objType;
	private String lastUsedDate;
	private long requestId;
	private String elapsedTypeInYears;
	private String status;
	private String objName;
	
	public String getObjName() {
		return objName;
	}
	public void setObjName(String objName) {
		this.objName = objName;
	}
	public String getObjType() {
		return objType;
	}
	public void setObjType(String objType) {
		this.objType = objType;
	}
	public String getLastUsedDate() {
		return lastUsedDate;
	}
	public void setLastUsedDate(String lastUsedDate) {
		this.lastUsedDate = lastUsedDate;
	}
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getElapsedTypeInYears() {
		return elapsedTypeInYears;
	}
	public void setElapsedTypeInYears(String elapsedTypeInYears) {
		this.elapsedTypeInYears = elapsedTypeInYears;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}
