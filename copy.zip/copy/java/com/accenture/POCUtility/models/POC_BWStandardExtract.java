package com.accenture.POCUtility.models;

public class POC_BWStandardExtract{

	private long requestId;
	private String extractorList;
	private String phase;
	private String areaOfRes;
	private String dataSource;
	private String applcomponent;
	private String classification;
	private String category;
	private String resMandatoryForStatus;
	private String relSimItem;
	private String note;
	private String del1511;
	private String del1610;
	private String deltaRes;
	private String comments;
	
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getExtractorList() {
		return extractorList;
	}
	public void setExtractorList(String extractorList) {
		this.extractorList = extractorList;
	}
	public String getPhase() {
		return phase;
	}
	public void setPhase(String phase) {
		this.phase = phase;
	}
	public String getAreaOfRes() {
		return areaOfRes;
	}
	public void setAreaOfRes(String areaOfRes) {
		this.areaOfRes = areaOfRes;
	}
	public String getDataSource() {
		return dataSource;
	}
	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}
	public String getApplcomponent() {
		return applcomponent;
	}
	public void setApplcomponent(String applcomponent) {
		this.applcomponent = applcomponent;
	}
	public String getClassification() {
		return classification;
	}
	public void setClassification(String classification) {
		this.classification = classification;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getResMandatoryForStatus() {
		return resMandatoryForStatus;
	}
	public void setResMandatoryForStatus(String resMandatoryForStatus) {
		this.resMandatoryForStatus = resMandatoryForStatus;
	}
	public String getRelSimItem() {
		return relSimItem;
	}
	public void setRelSimItem(String relSimItem) {
		this.relSimItem = relSimItem;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public String getDel1511() {
		return del1511;
	}
	public void setDel1511(String del1511) {
		this.del1511 = del1511;
	}
	public String getDel1610() {
		return del1610;
	}
	public void setDel1610(String del1610) {
		this.del1610 = del1610;
	}
	public String getDeltaRes() {
		return deltaRes;
	}
	public void setDeltaRes(String deltaRes) {
		this.deltaRes = deltaRes;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	
	
}