package com.accenture.POCUtility.models;

public class POC_DR_FioriOdata {

	private long requestId;
	private String objType;
	private String objName;
	private String subType;
	private String appId;
	private String appType;
	private String versAvailable;
	private String appname;
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getObjType() {
		return objType;
	}
	public void setObjType(String objType) {
		this.objType = objType;
	}
	public String getObjName() {
		return objName;
	}
	public void setObjName(String objName) {
		this.objName = objName;
	}
	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
	}
	public String getAppId() {
		return appId;
	}
	public void setAppId(String appId) {
		this.appId = appId;
	}
	public String getAppType() {
		return appType;
	}
	public void setAppType(String appType) {
		this.appType = appType;
	}
	public String getVersAvailable() {
		return versAvailable;
	}
	public void setVersAvailable(String versAvailable) {
		this.versAvailable = versAvailable;
	}
	public String getAppname() {
		return appname;
	}
	public void setAppname(String appname) {
		this.appname = appname;
	}
	
	
	
}
