package com.accenture.POCUtility.models;

public class POC_Smodilog{

	private long requestId;
	private String objType;
	private String objName;
	private String subType;
	private String subName;
	private String intType;
	private String intName;
	private String modUser;
	private String modDate;
	private String modTime;
	private String trkorr;
	
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getObjType() {
		return objType;
	}
	public void setObjType(String objType) {
		this.objType = objType;
	}
	public String getObjName() {
		return objName;
	}
	public void setObjName(String objName) {
		this.objName = objName;
	}
	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
	}
	public String getSubName() {
		return subName;
	}
	public void setSubName(String subName) {
		this.subName = subName;
	}
	public String getIntType() {
		return intType;
	}
	public void setIntType(String intType) {
		this.intType = intType;
	}
	public String getIntName() {
		return intName;
	}
	public void setIntName(String intName) {
		this.intName = intName;
	}
	public String getModUser() {
		return modUser;
	}
	public void setModUser(String modUser) {
		this.modUser = modUser;
	}
	public String getModDate() {
		return modDate;
	}
	public void setModDate(String modDate) {
		this.modDate = modDate;
	}
	public String getModTime() {
		return modTime;
	}
	public void setModTime(String modTime) {
		this.modTime = modTime;
	}
	public String getTrkorr() {
		return trkorr;
	}
	public void setTrkorr(String trkorr) {
		this.trkorr = trkorr;
	}	
}