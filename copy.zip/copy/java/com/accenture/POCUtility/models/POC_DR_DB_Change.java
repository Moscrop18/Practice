package com.accenture.POCUtility.models;

public class POC_DR_DB_Change {

	private long requestId;
	private String objType;
	private String objName;
	private String subObjName;
	private String readProgram;
	private String pkg; //package
	private String operation; 
	private Integer lineNo;
	private String statement;
	private String remediationCategory;
	private String issueCategory;
	private String issueSubCategory;
	private String descOfChange;
	private String solutionSteps;
	private Integer levelOfNesting;
	private String tables;
	private String joins;
	private String tableType;
	private String whereCondition;
	private String joinType;
	private String impact;
	private String automationStatus;
	private String complexity;
	private String operationCode;
	private String used;
	private String skipReason;
	private String skip;
	private String objectNameType;
	private String selectLine;
	private String externalNamespace;
	private String ricefwCategory;
	private String ricefwSubCategory;
	
	
	
	public String getRicefwCategory() {
		return ricefwCategory;
	}
	public void setRicefwCategory(String ricefwCategory) {
		this.ricefwCategory = ricefwCategory;
	}
	public String getRicefwSubCategory() {
		return ricefwSubCategory;
	}
	public void setRicefwSubCategory(String ricefwSubCategory) {
		this.ricefwSubCategory = ricefwSubCategory;
	}
	public String getExternalNamespace() {
		return externalNamespace;
	}
	public void setExternalNamespace(String externalNamespace) {
		this.externalNamespace = externalNamespace;
	}
	
	public String getObjectNameType() {
		return objectNameType;
	}
	public void setObjectNameType(String objectNameType) {
		this.objectNameType = objectNameType;
	}
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getObjType() {
		return objType;
	}
	public void setObjType(String objType) {
		this.objType = objType;
	}
	public String getObjName() {
		return objName;
	}
	public void setObjName(String objName) {
		this.objName = objName;
	}
	public String getSubObjName() {
		return subObjName;
	}
	public void setSubObjName(String subObjName) {
		this.subObjName = subObjName;
	}
	public String getReadProgram() {
		return readProgram;
	}
	public void setReadProgram(String readProgram) {
		this.readProgram = readProgram;
	}
	public String getPkg() {
		return pkg;
	}
	public void setPkg(String pkg) {
		this.pkg = pkg;
	}
	public String getOperation() {
		return operation;
	}
	public void setOperation(String operation) {
		this.operation = operation;
	}
	public Integer getLineNo() {
		return lineNo;
	}
	public void setLineNo(Integer lineNo) {
		this.lineNo = lineNo;
	}
	public String getStatement() {
		return statement;
	}
	public void setStatement(String statement) {
		this.statement = statement;
	}
	public String getRemediationCategory() {
		return remediationCategory;
	}
	public void setRemediationCategory(String remediationCategory) {
		this.remediationCategory = remediationCategory;
	}
	public String getIssueCategory() {
		return issueCategory;
	}
	public void setIssueCategory(String issueCategory) {
		this.issueCategory = issueCategory;
	}
	public String getIssueSubCategory() {
		return issueSubCategory;
	}
	public void setIssueSubCategory(String issueSubCategory) {
		this.issueSubCategory = issueSubCategory;
	}
	public String getDescOfChange() {
		return descOfChange;
	}
	public void setDescOfChange(String descOfChange) {
		this.descOfChange = descOfChange;
	}
	public String getSolutionSteps() {
		return solutionSteps;
	}
	public void setSolutionSteps(String solutionSteps) {
		this.solutionSteps = solutionSteps;
	}
	public Integer getLevelOfNesting() {
		return levelOfNesting;
	}
	public void setLevelOfNesting(Integer levelOfNesting) {
		this.levelOfNesting = levelOfNesting;
	}
	public String getTables() {
		return tables;
	}
	public void setTables(String tables) {
		this.tables = tables;
	}
	public String getJoins() {
		return joins;
	}
	public void setJoins(String joins) {
		this.joins = joins;
	}
	public String getTableType() {
		return tableType;
	}
	public void setTableType(String tableType) {
		this.tableType = tableType;
	}
	public String getWhereCondition() {
		return whereCondition;
	}
	public void setWhereCondition(String whereCondition) {
		this.whereCondition = whereCondition;
	}
	public String getJoinType() {
		return joinType;
	}
	public void setJoinType(String joinType) {
		this.joinType = joinType;
	}
	public String getImpact() {
		return impact;
	}
	public void setImpact(String impact) {
		this.impact = impact;
	}
	public String getAutomationStatus() {
		return automationStatus;
	}
	public void setAutomationStatus(String automationStatus) {
		this.automationStatus = automationStatus;
	}
	public String getComplexity() {
		return complexity;
	}
	public void setComplexity(String complexity) {
		this.complexity = complexity;
	}
	public String getOperationCode() {
		return operationCode;
	}
	public void setOperationCode(String operationCode) {
		this.operationCode = operationCode;
	}
	public String getUsed() {
		return used;
	}
	public void setUsed(String used) {
		this.used = used;
	}
	public String getSkipReason() {
		return skipReason;
	}
	public void setSkipReason(String skipReason) {
		this.skipReason = skipReason;
	}
	public String getSkip() {
		return skip;
	}
	public void setSkip(String skip) {
		this.skip = skip;
	}
	public String getSelectLine() {
		return selectLine;
	}
	public void setSelectLine(String selectLine) {
		this.selectLine = selectLine;
	}
}
