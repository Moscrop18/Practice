package com.accenture.POCUtility.models;

import javax.persistence.Column;

public class InventoryListPOC {

	private String objName;
	private String objType;
	private String used;
	private String usageCount;	
	private long requestId;
	private String profilerUsed;
	private String transReq;
	private String externalNamespace;
	
	private String ricefwCategory;
	private String ricefwSubCategory;
	private String standardMod;
	private String linesOfCode;

	public String getRicefwCategory() {
		return ricefwCategory;
	}
	public void setRicefwCategory(String ricefwCategory) {
		this.ricefwCategory = ricefwCategory;
	}
	public String getRicefwSubCategory() {
		return ricefwSubCategory;
	}
	public void setRicefwSubCategory(String ricefwSubCategory) {
		this.ricefwSubCategory = ricefwSubCategory;
	}
	
	public String getStandardMod() {
		return standardMod;
	}
	public void setStandardMod(String standardMod) {
		this.standardMod = standardMod;
	}
	public String getLinesOfCode() {
		return linesOfCode;
	}
	public void setLinesOfCode(String linesOfCode) {
		this.linesOfCode = linesOfCode;
	}
	public String getExternalNamespace() {
		return externalNamespace;
	}
	public void setExternalNamespace(String externalNamespace) {
		this.externalNamespace = externalNamespace;
	}
	public String getUsageCount() {
		return usageCount;
	}
	public void setUsageCount(String usageCount) {
		this.usageCount = usageCount;
	}
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getObjName() {
		return objName;
	}
	public void setObjName(String objName) {
		this.objName = objName;
	}
	public String getObjType() {
		return objType;
	}
	public void setObjType(String objType) {
		this.objType = objType;
	}
	public String getUsed() {
		return used;
	}
	public void setUsed(String used) {
		this.used = used;
	}
	public String getProfilerUsed() {
		return profilerUsed;
	}
	public void setProfilerUsed(String profilerUsed) {
		this.profilerUsed = profilerUsed;
	}
	public String getTransReq() {
		return transReq;
	}
	public void setTransReq(String transReq) {
		this.transReq = transReq;
	}
}
