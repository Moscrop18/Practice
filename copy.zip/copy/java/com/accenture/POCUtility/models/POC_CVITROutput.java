package com.accenture.POCUtility.models;

import javax.persistence.Column;

public class POC_CVITROutput {

	private String customerNr;
	private String subIntervalFrom;
	private String subIntervalTo;
	private String vendorNr;	
	private long requestId;
	private String vendorExt;	
	private String customerExt;	
	
	public String getVendorExt() {
		return vendorExt;
	}
	public void setVendorExt(String vendorExt) {
		this.vendorExt = vendorExt;
	}
	public String getCustomerExt() {
		return customerExt;
	}
	public void setCustomerExt(String customerExt) {
		this.customerExt = customerExt;
	}
	public String getCustomerNr() {
		return customerNr;
	}
	public void setCustomerNr(String customerNr) {
		this.customerNr = customerNr;
	}
	public String getSubIntervalFrom() {
		return subIntervalFrom;
	}
	public void setSubIntervalFrom(String subIntervalFrom) {
		this.subIntervalFrom = subIntervalFrom;
	}
	public String getSubIntervalTo() {
		return subIntervalTo;
	}
	public void setSubIntervalTo(String subIntervalTo) {
		this.subIntervalTo = subIntervalTo;
	}
	public String getVendorNr() {
		return vendorNr;
	}
	public void setVendorNr(String vendorNr) {
		this.vendorNr = vendorNr;
	}
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}

}
