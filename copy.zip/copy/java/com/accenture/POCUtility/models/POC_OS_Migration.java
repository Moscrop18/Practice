package com.accenture.POCUtility.models;

public class POC_OS_Migration {

	private Long requestID;
	private String objType;
	private String objName;
	private String subType;
	private String readProgram;
	private String objPackage;
	private String operationCode;
	private Integer lineNo;
	private String statement;
	private String remCategory;
	private String issueCategory;
	private String issueSubcategory;
	private String info;
	private String highLvlDesc;
	private String automationStatus;
	private String complexity;
	private String used;
	private String impact;
	private String externalNamespace;
	private String ricefwCategory;
	private String ricefwSubCategory;
	
	public String getRicefwCategory() {
		return ricefwCategory;
	}
	public void setRicefwCategory(String ricefwCategory) {
		this.ricefwCategory = ricefwCategory;
	}
	public String getRicefwSubCategory() {
		return ricefwSubCategory;
	}
	public void setRicefwSubCategory(String ricefwSubCategory) {
		this.ricefwSubCategory = ricefwSubCategory;
	}
	public String getExternalNamespace() {
		return externalNamespace;
	}
	public void setExternalNamespace(String externalNamespace) {
		this.externalNamespace = externalNamespace;
	}
	public Long getRequestID() {
		return requestID;
	}
	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}
	public String getObjType() {
		return objType;
	}
	public void setObjType(String objType) {
		this.objType = objType;
	}
	public String getObjName() {
		return objName;
	}
	public void setObjName(String objName) {
		this.objName = objName;
	}
	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
	}
	public String getReadProgram() {
		return readProgram;
	}
	public void setReadProgram(String readProgram) {
		this.readProgram = readProgram;
	}
	public String getObjPackage() {
		return objPackage;
	}
	public void setObjPackage(String objPackage) {
		this.objPackage = objPackage;
	}
	public String getOperationCode() {
		return operationCode;
	}
	public void setOperationCode(String operationCode) {
		this.operationCode = operationCode;
	}
	public Integer getLineNo() {
		return lineNo;
	}
	public void setLineNo(Integer lineNo) {
		this.lineNo = lineNo;
	}
	public String getStatement() {
		return statement;
	}
	public void setStatement(String statement) {
		this.statement = statement;
	}
	public String getRemCategory() {
		return remCategory;
	}
	public void setRemCategory(String remCategory) {
		this.remCategory = remCategory;
	}
	public String getIssueCategory() {
		return issueCategory;
	}
	public void setIssueCategory(String issueCategory) {
		this.issueCategory = issueCategory;
	}
	public String getIssueSubcategory() {
		return issueSubcategory;
	}
	public void setIssueSubcategory(String issueSubcategory) {
		this.issueSubcategory = issueSubcategory;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	public String getHighLvlDesc() {
		return highLvlDesc;
	}
	public void setHighLvlDesc(String highLvlDesc) {
		this.highLvlDesc = highLvlDesc;
	}
	public String getAutomationStatus() {
		return automationStatus;
	}
	public void setAutomationStatus(String automationStatus) {
		this.automationStatus = automationStatus;
	}
	public String getComplexity() {
		return complexity;
	}
	public void setComplexity(String complexity) {
		this.complexity = complexity;
	}
	public String getUsed() {
		return used;
	}
	public void setUsed(String used) {
		this.used = used;
	}
	public String getImpact() {
		return impact;
	}
	public void setImpact(String impact) {
		this.impact = impact;
	}


}
