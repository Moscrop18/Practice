package com.accenture.POCUtility.models;

public class POC_ImpactedIdoc{

	private long requestId;
	private String idocMsgType;
	private String idocBasicType;
	private String idocSegment;
	private String impactedObjectType;
	private String impactedObjectName;
	private String description;
	private String sapNote;
	private String solutionStep;
	private String typeOfIDOC;
	
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getIdocMsgType() {
		return idocMsgType;
	}
	public void setIdocMsgType(String idocMsgType) {
		this.idocMsgType = idocMsgType;
	}
	public String getIdocBasicType() {
		return idocBasicType;
	}
	public void setIdocBasicType(String idocBasicType) {
		this.idocBasicType = idocBasicType;
	}
	public String getIdocSegment() {
		return idocSegment;
	}
	public void setIdocSegment(String idocSegment) {
		this.idocSegment = idocSegment;
	}
	public String getImpactedObjectType() {
		return impactedObjectType;
	}
	public void setImpactedObjectType(String impactedObjectType) {
		this.impactedObjectType = impactedObjectType;
	}
	public String getImpactedObjectName() {
		return impactedObjectName;
	}
	public void setImpactedObjectName(String impactedObjectName) {
		this.impactedObjectName = impactedObjectName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getSapNote() {
		return sapNote;
	}
	public void setSapNote(String sapNote) {
		this.sapNote = sapNote;
	}
	public String getSolutionStep() {
		return solutionStep;
	}
	public void setSolutionStep(String solutionStep) {
		this.solutionStep = solutionStep;
	}
	public String getTypeOfIDOC() {
		return typeOfIDOC;
	}
	public void setTypeOfIDOC(String typeOfIDOC) {
		this.typeOfIDOC = typeOfIDOC;
	}
}