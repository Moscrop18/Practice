package com.accenture.POCUtility.models;

public class POC_InconsistentFUGR {
	
	private long requestId;
	private String objectType;
	private String fugrName;
	private String masterProgram;
	private String externalNamespace;

	
	public String getExternalNamespace() {
		return externalNamespace;
	}
	public void setExternalNamespace(String externalNamespace) {
		this.externalNamespace = externalNamespace;
	}
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getObjectType() {
		return objectType;
	}
	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}
	public String getFugrName() {
		return fugrName;
	}
	public void setFugrName(String fugrName) {
		this.fugrName = fugrName;
	}
	public String getMasterProgram() {
		return masterProgram;
	}
	public void setMasterProgram(String masterProgram) {
		this.masterProgram = masterProgram;
	}
}
