package com.accenture.POCUtility.models;

public class POC_S4_SID {

	private String objName;
	private String subObjType;
	private String pckg;
	private String used;
	private String type;
	private int lineNo;
	private String stmt;
	private String operations;
	private String impactReason;
	private String descOfChange;
	private String solutionSteps;
	private String complexity;
	private String issueCategory;
	private String identifier;
	private Integer totalScannedLine;
	private long requestID;
	private String objNameType;
	private String readProgram;
	private String automationStatus;
	private String externalNamespace;


	public String getExternalNamespace() {
		return externalNamespace;
	}

	public void setExternalNamespace(String externalNamespace) {
		this.externalNamespace = externalNamespace;
	}

	public String getObjNameType() {
		return objNameType;
	}

	public void setObjNameType(String objNameType) {
		this.objNameType = objNameType;
	}

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}

	public String getPckg() {
		return pckg;
	}

	public void setPckg(String pckg) {
		this.pckg = pckg;
	}

	public String getUsed() {
		return used;
	}

	public void setUsed(String used) {
		this.used = used;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getLineNo() {
		return lineNo;
	}

	public void setLineNo(int lineNo) {
		this.lineNo = lineNo;
	}

	public String getStmt() {
		return stmt;
	}

	public void setStmt(String stmt) {
		this.stmt = stmt;
	}

	public String getOperations() {
		return operations;
	}

	public void setOperations(String operations) {
		this.operations = operations;
	}

	public String getImpactReason() {
		return impactReason;
	}

	public void setImpactReason(String impactReason) {
		this.impactReason = impactReason;
	}

	public String getDescOfChange() {
		return descOfChange;
	}

	public void setDescOfChange(String descOfChange) {
		this.descOfChange = descOfChange;
	}

	public String getSolutionSteps() {
		return solutionSteps;
	}

	public void setSolutionSteps(String solutionSteps) {
		this.solutionSteps = solutionSteps;
	}

	public String getComplexity() {
		return complexity;
	}

	public void setComplexity(String complexity) {
		this.complexity = complexity;
	}

	public String getIssueCategory() {
		return issueCategory;
	}

	public void setIssueCategory(String issueCategory) {
		this.issueCategory = issueCategory;
	}
	
	public long getRequestID() {
		return requestID;
	}

	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}

	public String getReadProgram() {
		return readProgram;
	}

	public void setReadProgram(String readProgram) {
		this.readProgram = readProgram;
	}

	public String getIdentifier() {
		return identifier;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	public Integer getTotalScannedLine() {
		return totalScannedLine;
	}

	public String getSubObjType() {
		return subObjType;
	}

	public void setSubObjType(String subObjType) {
		this.subObjType = subObjType;
	}

	public void setTotalScannedLine(Integer totalScannedLine) {
		this.totalScannedLine = totalScannedLine;
	}

	public String getAutomationStatus() {
		return automationStatus;
	}

	public void setAutomationStatus(String automationStatus) {
		this.automationStatus = automationStatus;
	}
}
