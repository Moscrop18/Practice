package com.accenture.POCUtility.models;

public class POC_DRS4Simplification3 {

	private long requestId;
	private String type;
	private String object;
	private String used;
	private String subObject;
	private String method;
	private String pkg;
	private String impactedObjectType;
	private Integer lineNumber;
	private String statement;
	private String operations;
	private String impactReason;
	private String affectedObjectDescription;
	private String descriptionOfChange;
	private String sapNotes;
	private String solutionSteps;
	private String complexity;
	private String issueCategory;
	private String errorCategory;
	private String triggerObject;
	private String remediationCategory;
	private String sapSimplificationListChapter;
	private String applicationComponent;
	private String sapSimplCategory;
	private String itemArea;
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getObject() {
		return object;
	}
	public void setObject(String object) {
		this.object = object;
	}
	public String getUsed() {
		return used;
	}
	public void setUsed(String used) {
		this.used = used;
	}
	public String getSubObject() {
		return subObject;
	}
	public void setSubObject(String subObject) {
		this.subObject = subObject;
	}
	public String getMethod() {
		return method;
	}
	public void setMethod(String method) {
		this.method = method;
	}
	public String getPkg() {
		return pkg;
	}
	public void setPkg(String pkg) {
		this.pkg = pkg;
	}
	public String getImpactedObjectType() {
		return impactedObjectType;
	}
	public void setImpactedObjectType(String impactedObjectType) {
		this.impactedObjectType = impactedObjectType;
	}
	public Integer getLineNumber() {
		return lineNumber;
	}
	public void setLineNumber(Integer lineNumber) {
		this.lineNumber = lineNumber;
	}
	public String getStatement() {
		return statement;
	}
	public void setStatement(String statement) {
		this.statement = statement;
	}
	public String getOperations() {
		return operations;
	}
	public void setOperations(String operations) {
		this.operations = operations;
	}
	public String getImpactReason() {
		return impactReason;
	}
	public void setImpactReason(String impactReason) {
		this.impactReason = impactReason;
	}
	public String getAffectedObjectDescription() {
		return affectedObjectDescription;
	}
	public void setAffectedObjectDescription(String affectedObjectDescription) {
		this.affectedObjectDescription = affectedObjectDescription;
	}
	public String getDescriptionOfChange() {
		return descriptionOfChange;
	}
	public void setDescriptionOfChange(String descriptionOfChange) {
		this.descriptionOfChange = descriptionOfChange;
	}
	public String getSapNotes() {
		return sapNotes;
	}
	public void setSapNotes(String sapNotes) {
		this.sapNotes = sapNotes;
	}
	public String getSolutionSteps() {
		return solutionSteps;
	}
	public void setSolutionSteps(String solutionSteps) {
		this.solutionSteps = solutionSteps;
	}
	public String getComplexity() {
		return complexity;
	}
	public void setComplexity(String complexity) {
		this.complexity = complexity;
	}
	public String getIssueCategory() {
		return issueCategory;
	}
	public void setIssueCategory(String issueCategory) {
		this.issueCategory = issueCategory;
	}
	public String getErrorCategory() {
		return errorCategory;
	}
	public void setErrorCategory(String errorCategory) {
		this.errorCategory = errorCategory;
	}
	public String getTriggerObject() {
		return triggerObject;
	}
	public void setTriggerObject(String triggerObject) {
		this.triggerObject = triggerObject;
	}
	public String getRemediationCategory() {
		return remediationCategory;
	}
	public void setRemediationCategory(String remediationCategory) {
		this.remediationCategory = remediationCategory;
	}
	public String getSapSimplificationListChapter() {
		return sapSimplificationListChapter;
	}
	public void setSapSimplificationListChapter(String sapSimplificationListChapter) {
		this.sapSimplificationListChapter = sapSimplificationListChapter;
	}
	public String getApplicationComponent() {
		return applicationComponent;
	}
	public void setApplicationComponent(String applicationComponent) {
		this.applicationComponent = applicationComponent;
	}
	public String getSapSimplCategory() {
		return sapSimplCategory;
	}
	public void setSapSimplCategory(String sapSimplCategory) {
		this.sapSimplCategory = sapSimplCategory;
	}
	public String getItemArea() {
		return itemArea;
	}
	public void setItemArea(String itemArea) {
		this.itemArea = itemArea;
	}
	
}
