/*MODIFIED 
 *FOR Enhancement CR-1.0:-Update the automation_Status according to Sel_line-20/12/16 -monika.mishra
 *
 *CR-13.0- New Output Sheet implementation - 03/03/2017 - monika.mishra
 *
 *CR-25.0- Few fields which will be moved to JAVA tool in HANA Profiler - 10/07/2017 - monika.mishra
 *
 *CR-26.0:-adding 3 New Sheets implementation -25/07/17-rohan.a.mehra
 *
 *CR-28.0:- Add col Total Line Scanned -24/07/17 -monika.mishra
 *
 *DEF041: -- Automation status should be 'No' where SKIP= X -01/03/2019 -himani.malhotra
 **/

package com.accenture.rfp.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import org.hibernate.annotations.Parameter;

import org.hibernate.annotations.GenericGenerator;

import com.accenture.client.model.RequestForm;

@Entity
@Table(name = "TADIR_Inventory")
public class TADIRInventory implements Serializable {

	@Column(name = "REQUEST_ID")
	private Long requestID;
	@Column(name = "RICEFW_COUNT")
	private Integer ricefwCount;
	@Column(name = "FUNCTION_GROUPS")
	private Integer functionGroups;
	@Column(name = "PROGRAMS")
	private Integer programs;
	@Column(name = "CLASSES")
	private Integer classes;
	@Column(name = "FORMS")
	private Integer form;
	@Column(name = "ENHANCEMENTS")
	private Integer enhancements;
	@Column(name = "WEB_DYNPRO")
	private Integer webDynpro;
	@Column(name = "LSMW")
	private Integer lsmw;
	@Column(name = "USER_EXITS")
	private Integer userExists;
	@Column(name = "INTERFACES")
	private Integer interfaces;
	@Column(name = "WORKFLOWS")
	private Integer workflow;
	
	@Id
	public Long getRequestID() {
		return requestID;
	}
	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}
	
	public Integer getRicefwCount() {
		return ricefwCount;
	}
	public void setRicefwCount(Integer ricefwCount) {
		this.ricefwCount = ricefwCount;
	}
	
	public Integer getFunctionGroups() {
		return functionGroups;
	}
	public void setFunctionGroups(Integer functionGroups) {
		this.functionGroups = functionGroups;
	}
	
	public Integer getPrograms() {
		return programs;
	}
	public void setPrograms(Integer programs) {
		this.programs = programs;
	}
	
	public Integer getClasses() {
		return classes;
	}
	public void setClasses(Integer classes) {
		this.classes = classes;
	}
	
	public Integer getForm() {
		return form;
	}
	public void setForm(Integer form) {
		this.form = form;
	}
	
	public Integer getEnhancements() {
		return enhancements;
	}
	public void setEnhancements(Integer enhancements) {
		this.enhancements = enhancements;
	}
	
	public Integer getWebDynpro() {
		return webDynpro;
	}
	public void setWebDynpro(Integer webDynpro) {
		this.webDynpro = webDynpro;
	}
	
	public Integer getLsmw() {
		return lsmw;
	}
	public void setLsmw(Integer lsmw) {
		this.lsmw = lsmw;
	}
	
	public Integer getUserExists() {
		return userExists;
	}
	public void setUserExists(Integer userExists) {
		this.userExists = userExists;
	}
	
	public Integer getInterfaces() {
		return interfaces;
	}
	public void setInterfaces(Integer interfaces) {
		this.interfaces = interfaces;
	}
	
	public Integer getWorkflow() {
		return workflow;
	}
	public void setWorkflow(Integer workflow) {
		this.workflow = workflow;
	}
}