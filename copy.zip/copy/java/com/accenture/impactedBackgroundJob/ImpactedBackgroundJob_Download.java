package com.accenture.impactedBackgroundJob;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.Index;
/**
 * @author himani.malhotra
 *
 */
@Entity
@Table(name="Impacted_Background_Job_Download" )
public class ImpactedBackgroundJob_Download {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="Id")
	private int id;

	@Column(name="OBJECT")
	private String object;
	
	@Column(name="BACKGROUND_JOB_NAME")
	private String bJobName;
	
	@Column(name="PROGRAM_NAME")
	private String progName;

	@Column(name="VARIANT")
	private String variant;

	@Column(name="TCODE")
	private String tCode;

	@Column(name="RUN")
	private String run;
	
	@Index(name="Index_Request_id")
	@Column(name="Request_Id")
	private Long requestId;
	
	@Column(name="External_Namespace")
	private String externalNamespace;
	
    
	public String getExternalNamespace() {
		return externalNamespace;
	}

	public void setExternalNamespace(String externalNamespace) {
		this.externalNamespace = externalNamespace;
	}

	public Long getRequestId() {
		return requestId;
	}

	public void setRequestId(Long requestId) {
		this.requestId = requestId;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getObject() {
		return object;
	}

	public void setObject(String object) {
		this.object = object;
	}

	public String getbJobName() {
		return bJobName;
	}

	public void setbJobName(String bJobName) {
		this.bJobName = bJobName;
	}

	public String getProgName() {
		return progName;
	}

	public void setProgName(String progName) {
		this.progName = progName;
	}

	public String getVariant() {
		return variant;
	}

	public void setVariant(String variant) {
		this.variant = variant;
	}

	public String gettCode() {
		return tCode;
	}

	public void settCode(String tCode) {
		this.tCode = tCode;
	}

	public String getRun() {
		return run;
	}

	public void setRun(String run) {
		this.run = run;
	}
}

