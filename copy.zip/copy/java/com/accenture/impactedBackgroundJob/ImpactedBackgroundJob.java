package com.accenture.impactedBackgroundJob;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

/**
 * @author himani.malhotra
 *
 */
@Entity
@Table(name="Impacted_Background_Job" )
public class ImpactedBackgroundJob {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="Id")
	private int id;

	@Column(name="OBJECT")
	private String object;
	
	@Column(name="OBJECT_NAME")
	private String objectName;
	
	@Column(name="SUB_TYPE")
	private String subType;

	@Column(name="READ_PROG")
	private String READ_PROG;

	@Column(name="OBJ_PACKAGE")
	private String objPackage;

	@Column(name="ACT_STATUS")
	private String actStatus;

	@Column(name="Request_Id")
	@Index(name="Index_Request_id")
	private Long requestId;
	
	@Column(name="External_Namespace")
	private String externalNamespace;

	public Long getRequestId() {
		return requestId;
	}

	public void setRequestId(Long requestId) {
		this.requestId = requestId;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getObject() {
		return object;
	}

	public void setObject(String object) {
		this.object = object;
	}

	public String getObjectName() {
		return objectName;
	}

	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public String getREAD_PROG() {
		return READ_PROG;
	}

	public void setREAD_PROG(String rEAD_PROG) {
		READ_PROG = rEAD_PROG;
	}

	public String getObjPackage() {
		return objPackage;
	}

	public void setObjPackage(String objPackage) {
		this.objPackage = objPackage;
	}

	public String getActStatus() {
		return actStatus;
	}

	public void setActStatus(String actStatus) {
		this.actStatus = actStatus;
	}

	public String getExternalNamespace() {
		return externalNamespace;
	}

	public void setExternalNamespace(String externalNamespace) {
		this.externalNamespace = externalNamespace;
	}
	

}
