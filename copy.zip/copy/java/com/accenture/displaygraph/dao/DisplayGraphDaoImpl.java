/* For Enhancement CR-1.0: - Update the automation_Status according to Sel_line -3/1/17 - monika.mishra
 * 
 * CR-9.0:- Manual upload for Estimator & assuptions -17/01/17 -monika.mishra
 * 
 * CR-12.0- Update Master table of request after completion. - 22/02/2017 - monika.mishra
 * 
 * CR-13.0- New Output Sheet implementation - 03/03/2017 - monika.mishra
 * 
 * CR-27.0- Populating Data on Fiori reporting DHL sheet-3/08/17-rohan.a.mehra
 * 
 * CR:56- Change in Hana Estimation to get used count--rohan.a.mehra
 * 
 * DEF043- Remove code related to USEREXIT -28/02/2019 -himani.malhotra
 * */
package com.accenture.displaygraph.dao;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigInteger;
import java.sql.Date;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.apache.commons.collections.CollectionUtils;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.accenture.S4.models.S4Estimations;
import com.accenture.UI5.models.UI5GraphCounts;
import com.accenture.client.model.RequestForm;
import com.accenture.client.model.RequestInventory;
import com.accenture.constant.Hana_Profiler_Constant;
import com.accenture.constant.ST03HanaConstant;
import com.accenture.displaygrid.model.DBConfig;
import com.accenture.displaygrid.model.HanaAssumption;
import com.accenture.displaygrid.model.HanaEstimator;
import com.accenture.exceptions.HibernateException;
import com.accenture.fileprocessing.model.MetaData;
import com.accenture.impactedBackgroundJob.ImpactedBackgroundCounts;
import com.accenture.master.ExtensionScope;
import com.accenture.master.FioriRequestMaster;
import com.accenture.master.ProcessedRequestDetail;
import com.accenture.master.TestingScope;
import com.accenture.utility.HANAUtility;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;

@SuppressWarnings({ "unchecked" })
@Transactional
public class DisplayGraphDaoImpl implements DisplayGraphDao {

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	// CR-27: populating data on fioriDHL sheet sheet
	@Override
	public Map<String, Integer> getUniqueOdataCount(Long requestId) {

		final Map<String, Integer> resultMap = new HashMap<String, Integer>();
		session = sessionFactory.openSession();
		hql = "SELECT Odata,count(distinct Obj_Name) from HanaProfile where requestID=" + requestId
				+ "and operation_code in ('59','60','61','62','63','64','65','66','71','72','73','74','75','76') GROUP BY Odata";
		Query query = session.createQuery(hql);
		List<Object[]> resultList = query.list();
		if (CollectionUtils.isNotEmpty(resultList)) {
			for (Object[] object : resultList) {
				resultMap.put((String) object[0], ((Long) object[1]).intValue());
			}
		}

		session.close();
		return resultMap;

	}

	public DisplayGraphDaoImpl() {
	}

	private SessionFactory sessionFactory;
	private Session session;

	private String hql;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public Map<String, Integer> getCountCategory(final Long requestId) {
		final Map<String, Integer> resultMap = new HashMap<String, Integer>();
		session = sessionFactory.openSession();
		// CR-2.0 CR-13.0
		hql = "select Category,count(*) from HanaProfile where requestID= :requestID and Category in ('Mandatory','DB Level HANA Optimization','Application level optimization','Housekeeping for HANA') GROUP BY Category";
		Query query = session.createQuery(hql);
		query.setParameter("requestID", requestId);
		List<Object[]> resultList = query.list();
		if (CollectionUtils.isNotEmpty(resultList)) {
			for (Object[] object : resultList) {
				resultMap.put((String) object[0], ((Long) object[1]).intValue());
			}
		}
		session.close();
		return resultMap;
	}

	@Override
	public Map<String, Integer> getCountUsedUnused(final Long requestId) {

		final Map<String, Integer> resultMap = new HashMap<String, Integer>();
		session = sessionFactory.openSession();
		hql = "select Used_Unused,count(*) from HanaProfile where requestID= :requestID and Used_Unused in ('Unused','Used') GROUP BY Used_Unused";
		Query query = session.createQuery(hql);
		query.setParameter("requestID", requestId);
		List<Object[]> resultList = query.list();
		if (CollectionUtils.isNotEmpty(resultList)) {
			for (Object[] object : resultList) {
				resultMap.put((String) object[0], ((Long) object[1]).intValue());
			}
		}
		session.close();
		return resultMap;

	}

	@Override
	public Map<String, Integer> getCountImpact(final Long requestId) {

		final Map<String, Integer> resultMap = new HashMap<String, Integer>();
		session = sessionFactory.openSession();
		// CR-2.0
		hql = "select impact,count(*) from HanaProfile where requestID= :requestID and impact in ('HIGH','LOW','MEDIUM','VERY HIGH','NO IMPACT') GROUP BY impact";
		Query query = session.createQuery(hql);
		query.setParameter("requestID", requestId);
		List<Object[]> resultList = query.list();
		if (CollectionUtils.isNotEmpty(resultList)) {
			for (Object[] object : resultList) {
				resultMap.put((String) object[0], ((Long) object[1]).intValue());
			}
		}
		session.close();
		return resultMap;

	}

	@Override
	public Map<String, Integer> getGraphCountCategory(final Long requestId) {
		final Map<String, Integer> resultMap = new HashMap<String, Integer>();
		session = sessionFactory.openSession();
		// CR-2.0 CR-13.0
		hql = "select Mandatory_Category_count,db_level_category_count,app_level_category_count,housekeeping_for_HANA_category_count from Request_Master where Request_ID= :requestID";
		Query query = session.createSQLQuery(hql);
		query.setParameter("requestID", requestId);
		List<Object[]> resultList = query.list();

		if (CollectionUtils.isNotEmpty(resultList)) {
			for (Object[] object : resultList) {
				resultMap.put("Mandatory", (Integer) (object[0]));
				resultMap.put("DB Level HANA Optimization", (Integer) (object[1]));
				resultMap.put("Application level optimization", (Integer) (object[2]));
				resultMap.put("Housekeeping for HANA", (Integer) (object[3]));
			}
		}
		session.close();
		return resultMap;
	}

	@Override
	public Map<String, Integer> getGraphCountSubCategory(final Long requestId) {

		final Map<String, Integer> resultMap = new HashMap<String, Integer>();
		session = sessionFactory.openSession();
		hql = "select unneces_loa_away_subcategry_count,result_set_small_subcategry_count,validat_syntx_err_subcatgry,statement_ignr_HANA_sbcatgry,potential_syntax_err_cnt,semantic_Err_cnt,hANA_Sorting_cnt,minimize_amnt_data_trnsfr_cnt,sECONDARY_DATABASE_PERSPECTIVE_cnt from Request_Master where Request_ID= :requestID";
		Query query = session.createSQLQuery(hql);
		query.setParameter("requestID", requestId);
		List<Object[]> resultList = query.list();

		if (CollectionUtils.isNotEmpty(resultList)) {
			for (Object[] object : resultList) {
				resultMap.put("Keep unnecessary load away from database", (Integer) (object[0]));
				resultMap.put("Keep the result set small", (Integer) (object[1]));
				resultMap.put("Validated syntax error", (Integer) (object[2]));
				resultMap.put("Statement ignored by HANA", (Integer) (object[3]));
				resultMap.put("Potential syntax error", (Integer) (object[4]));
				resultMap.put("Semantic Error", (Integer) (object[5]));
				resultMap.put("HANA Sorting", (Integer) (object[6]));
				resultMap.put("Minimize the amount of transferred data", (Integer) (object[7]));
				resultMap.put("SECONDARY DATABASE PERSPECTIVE", (Integer) (object[8]));
			}
		}
		session.close();
		return resultMap;

	}

	@Override
	public Map<String, Integer> getGraphCountUsedUnused(final Long requestId) {

		final Map<String, Integer> resultMap = new HashMap<String, Integer>();
		session = sessionFactory.openSession();
		hql = "select Unused_count,used_count from Request_Master where Request_ID= :requestID";
		Query query = session.createSQLQuery(hql);
		query.setParameter("requestID", requestId);
		List<Object[]> resultList = query.list();

		if (CollectionUtils.isNotEmpty(resultList)) {
			for (Object[] object : resultList) {
				resultMap.put("Unused", (Integer) (object[0]));
				resultMap.put("Used", (Integer) (object[1]));
			}
		}
		session.close();
		return resultMap;

	}

	@Override
	public Map<String, Integer> getGraphCountImpact(final Long requestId) {

		final Map<String, Integer> resultMap = new HashMap<String, Integer>();
		session = sessionFactory.openSession();
		// CR-2.0
		hql = "select HIGH_impact_count,low_impact_count,medium_impact_count,very_high_impact_count,NO_IMPACT_count from Request_Master where Request_ID= :requestID";
		Query query = session.createSQLQuery(hql);
		query.setParameter("requestID", requestId);
		List<Object[]> resultList = query.list();

		if (CollectionUtils.isNotEmpty(resultList)) {
			for (Object[] object : resultList) {
				resultMap.put("HIGH", (Integer) (object[0]));
				resultMap.put("LOW", (Integer) (object[1]));
				resultMap.put("MEDIUM", (Integer) (object[2]));
				resultMap.put("VERY HIGH", (Integer) (object[3]));
				resultMap.put("NO IMPACT", (Integer) (object[4]));

			}
		}
		session.close();
		return resultMap;

	}

	@Override
	public Map<String, Map<String, Integer>> getObjectTypeUsedunusedCount(Long requestID) {

		final Map<String, Map<String, Integer>> resultMap = new HashMap<String, Map<String, Integer>>();
		Map<String, Integer> usedUnusedMap = null;
		session = sessionFactory.openSession();
		hql = "select Object_Type,Used_Unused,count(*) from HanaProfile where requestID= :requestID and Object_Type in ('CLAS','PROG','FUGR') AND Used_Unused in ('Unused','Used') GROUP BY Object_Type,Used_Unused";
		Query query = session.createQuery(hql);
		query.setParameter("requestID", requestID);
		List<Object[]> resultList = query.list();
		String objectType;
		if (CollectionUtils.isNotEmpty(resultList)) {
			for (Object[] object : resultList) {
				objectType = (String) object[0];
				if (resultMap.get(objectType) != null) {
					usedUnusedMap = resultMap.get(objectType);
					usedUnusedMap.put((String) object[1], ((Long) object[2]).intValue());
				} else {
					usedUnusedMap = new HashMap<String, Integer>();
					usedUnusedMap.put((String) object[1], ((Long) object[2]).intValue());
					resultMap.put(objectType, usedUnusedMap);
				}

			}
		}
		session.close();
		return resultMap;

	}

	@Override
	public int getStatusWiseCount(String status, String toolName) {

		session = sessionFactory.openSession();

		final Criteria criteria = session.createCriteria(RequestInventory.class);
		/* CR-9.0 */
		if (Hana_Profiler_Constant.NOT_COMPLETED_STATUS.equalsIgnoreCase(status)
				|| Hana_Profiler_Constant.COMPLETED_STATUS.equalsIgnoreCase(status)
				|| Hana_Profiler_Constant.COMPLETED_PENDING_ESTIMATIONS.equalsIgnoreCase(status)) {
			criteria.add(Restrictions.in("requestStatus", HANAUtility.getApplicationStatus(status)));
		} else {
			criteria.add(Restrictions.eq("requestStatus", status));
		}
		criteria.add(Restrictions.eq("toolName", toolName));
		criteria.setProjection(Projections.rowCount());

		final Long count = (Long) criteria.uniqueResult();
		session.close();
		return count.intValue();
	}

	// CR-56: Change in Estimation
	@Override
	public Map<String, String> getTotalCountCustomObjets(Long requestId, String objectType) {

		final Map<String, String> resultMap = new HashMap<String, String>();
		resultMap.put("Count", "0");

		session = sessionFactory.openSession();
		hql = "select count(distinct OBJ_NAME) from S4_Inventory_List where REQUEST_ID=" + requestId
				+ " and OBJ_TYPE IN (" + objectType + ") AND OBJ_NAME NOT LIKE 'ZHANA%' ";
		List<List<Object>> resultList = session.createSQLQuery(hql).setResultTransformer(Transformers.TO_LIST).list();
		if (!resultList.isEmpty()) {
			for (List<Object> x : resultList) {
				resultMap.put("Count", (String) x.get(0).toString());
			}
		}
		session.close();
		return resultMap;

	}

	/*
	 * @Override public Map<String, String> getHighMediumLowCount(Long requestId,
	 * String ObjectType) { // TODO Auto-generated method stub
	 * 
	 * Map<String,String> retrunResult = new HashMap(); Map<String,String> resultMap
	 * = new HashMap(); session = sessionFactory.openSession();
	 * 
	 * hql = "select Object_Name,count(*) from st03_tadir where REQUEST_ID="
	 * +requestId+" and OBJECT_TYPE IN ("+ObjectType+") GROUP BY Object_Name";
	 * 
	 * List<List<Object>> resultList =
	 * session.createSQLQuery(hql).setResultTransformer(Transformers.TO_LIST).list()
	 * ; if(!resultList.isEmpty()){ for(List<Object> x: resultList){
	 * resultMap.put((String)x.get(0).toString(),(String) x.get(1).toString()); } }
	 * retrunResult = calculateHeighMediumLow(resultMap); session.close(); return
	 * retrunResult; }
	 */
	private Map<String, String> calculateHeighMediumLow(Map<String, String> heighMediumLowCount) {

		int heigh = 0;
		int medium = 0;
		int low = 0;

		Map<String, String> returnCount = new HashMap();
		returnCount.put("Heigh", "0");
		returnCount.put("Medium", "0");
		returnCount.put("Low", "0");

		if (!heighMediumLowCount.isEmpty()) {

			for (String key : heighMediumLowCount.keySet()) {
				int value = Integer.parseInt(heighMediumLowCount.get(key));

				if (value > 82) {
					heigh = heigh + value;
				} else if (value >= 25 && value <= 82) {
					medium = medium + value;
				} else if (value >= 1 && value <= 24) {
					low = low + value;
				}
			}
		}
		returnCount.put("High", Integer.toString(heigh));
		returnCount.put("Medium", Integer.toString(medium));
		returnCount.put("Low", Integer.toString(low));

		return returnCount;
	}

	// CR:56- Change in Hana Estimation to get used estimation
	@Override
	public Multimap<String, BigInteger> getTotal_UsedDefectObjectCount(Long requestId, String clientNameSpace_Name) {
		final Multimap<String, BigInteger> resultMap = ArrayListMultimap.create();
		session = sessionFactory.openSession();
		if (!"".equals(clientNameSpace_Name)) {
			String multiNameSpace[] = clientNameSpace_Name.split(",");
			String multipleNameSpacesAnd = "";
			for (int i = 0; i < multiNameSpace.length; i++) {
				if ("".equals(multipleNameSpacesAnd)) {
					multipleNameSpacesAnd = " AND Obj_Name NOT like '" + multiNameSpace[i].trim() + "/SAPL%'";
				} else {
					multipleNameSpacesAnd = multipleNameSpacesAnd + " AND Obj_Name NOT like '"
							+ multiNameSpace[i].trim() + "/SAPL%'";
				}
			}
			hql = "select Object_Type,count(distinct Obj_Name) from final_output where Request_ID=" + requestId
					+ " and Category In ('Mandatory') and Category IS NOT NULL and Used_Unused In ('Used') and (Obj_Name NOT LIKE 'SAPL%' "
					+ multipleNameSpacesAnd + ")  group by Object_Type";
		} else {
			hql = "select Object_Type,count(distinct Obj_Name) from final_output where Request_ID=" + requestId
					+ " and Category In ('Mandatory') and Category IS NOT NULL and Used_Unused In ('Used') and Obj_Name NOT LIKE 'SAPL%' group by Object_Type";
		}

		Query query = session.createSQLQuery(hql);
		List<Object[]> resultList = query.list();
		if (CollectionUtils.isNotEmpty(resultList)) {
			for (Object[] object : resultList) {
				resultMap.put((String) object[0], (BigInteger) object[1]);
			}
		}

		session.close();
		return resultMap;
	}

	@Override
	public Multimap<String, BigInteger> getTotal_DefectObjectCount(Long requestId, String clientNameSpace_Name) {
		final Multimap<String, BigInteger> resultMap = ArrayListMultimap.create();
		session = sessionFactory.openSession();
		if (!"".equals(clientNameSpace_Name)) {
			String multiNameSpace[] = clientNameSpace_Name.split(",");
			String multipleNameSpacesAnd = "";
			for (int i = 0; i < multiNameSpace.length; i++) {
				if ("".equals(multipleNameSpacesAnd)) {
					multipleNameSpacesAnd = " AND Obj_Name NOT like '" + multiNameSpace[i].trim() + "/SAPL%'";
				} else {
					multipleNameSpacesAnd = multipleNameSpacesAnd + " AND Obj_Name NOT like '"
							+ multiNameSpace[i].trim() + "/SAPL%'";
				}
			}
			hql = "select Object_Type,count(distinct Obj_Name) from final_output where Request_ID=" + requestId
					+ " and Category In ('Mandatory') and Category IS NOT NULL and (Obj_Name NOT LIKE 'SAPL%' "
					+ multipleNameSpacesAnd + ")  group by Object_Type";
		} else {
			hql = "select Object_Type,count(distinct Obj_Name) from final_output where Request_ID=" + requestId
					+ " and Category In ('Mandatory') and Category IS NOT NULL  and Obj_Name NOT LIKE 'SAPL%' group by Object_Type";
		}

		Query query = session.createSQLQuery(hql);
		List<Object[]> resultList = query.list();
		if (CollectionUtils.isNotEmpty(resultList)) {
			for (Object[] object : resultList) {
				resultMap.put((String) object[0], (BigInteger) object[1]);
			}
		}

		session.close();
		return resultMap;
	}

	@Override
	public int calculateActualCount(int count) {
		// TODO Auto-generated method stub
		int retValue = 0;

		if (count > 0 && count < 1000) {
			retValue = 10;
		} else if (count > 1000 && count <= 2000) {
			retValue = 15;
		} else if (count > 2000 && count <= 3000) {
			retValue = 20;
		} else if (count > 3000 && count <= 4000) {
			retValue = 25;
		} else if (count > 4000) {
			retValue = 30;
		}
		return retValue;
	}

	@Override
	public String getClientNameSpace_Name(Long REQUEST_ID) {
		String name = "";
		session = sessionFactory.openSession();
		ArrayList list = (ArrayList) session
				.createSQLQuery("SELECT CLIENT_NAMESPACE_NAME FROM REQUEST_FORM  WHERE  REQUEST_ID =" + REQUEST_ID)
				.list();
		name = list.get(0).toString().trim();
		session.close();
		if ("".equals(name)) {
			logger.info("No Name Space Available");
		} else {
			logger.info("*** Available NBame Space ***" + name);
		}
		return name;
	}

	@Override
	public Map<String, String> getOperation_ErrorMap() {
		Map<String, String> resultMap = new HashMap();
		session = sessionFactory.openSession();
		hql = "SELECT Operation, Error_Type FROM map_error_type ";

		List<List<Object>> resultList = session.createSQLQuery(hql).setResultTransformer(Transformers.TO_LIST).list();
		if (!resultList.isEmpty()) {
			for (List<Object> x : resultList) {
				resultMap.put((String) x.get(0).toString(), (String) x.get(1).toString());
			}
		}
		session.close();
		return resultMap;
	}

	@Override
	public Map<String, String> getSecond_SubCat() {
		Map<String, String> resultMap = new HashMap();
		session = sessionFactory.openSession();
		hql = "SELECT Operation, Second_Sub_Cat FROM map_error_type ";

		List<List<Object>> resultList = session.createSQLQuery(hql).setResultTransformer(Transformers.TO_LIST).list();
		if (!resultList.isEmpty()) {
			for (List<Object> x : resultList) {
				resultMap.put((String) x.get(0).toString(), (String) x.get(1).toString());
			}
		}
		session.close();
		return resultMap;

	}

	/* CR-9.0 */
	@Override
	public List<HanaEstimator> getHanaEstimatorObjects(Long requestId) {
		session = sessionFactory.openSession();

		try {
			final Criteria criteria = session.createCriteria(HanaEstimator.class);
			criteria.add(Restrictions.eq("requestID", requestId));
			return criteria.list();

		} catch (Exception e) {
			logger.error("Error in DisplayGraphDaoImpl" , e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);

		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

	// CR-68
	@Override
	public List<S4Estimations> getS4EstimatorObjects(Long requestId) {
		session = sessionFactory.openSession();

		try {
			final Criteria criteria = session.createCriteria(S4Estimations.class);
			criteria.add(Restrictions.eq("requestID", requestId));
			return criteria.list();

		} catch (Exception e) {
			logger.error("Error DisplayGraphDaoImpl getS4Estimator" , e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);

		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

	/* CR-9.0 */
	@Override
	public List<HanaAssumption> getHanaAssumptionsObjects(Long requestId) {
		session = sessionFactory.openSession();

		try {
			final Criteria criteria = session.createCriteria(HanaAssumption.class);
			criteria.add(Restrictions.eq("requestID", requestId));
			return criteria.list();

		} catch (Exception e) {
			logger.error("Error DisplayGraphDaoImpl getHanaAssumptionObjects" , e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);

		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

	// CR-13.0 Getting Distinct obj_name on basis of obj_type(PROG)
	@Override
	public Map<String, Integer> getDistObjNameCountPROG(final Long requestId) {
		final Map<String, Integer> resultMap = new HashMap<String, Integer>();
		session = sessionFactory.openSession();
		hql = "select Sub_Type,count(distinct obj_name) from HanaProfile where request_ID= " + requestId
				+ " and Sub_Type in ('Executable Program','Function Group','Include Program','Module Pool','Subroutine Pool') and  Object_Type in ('PROG','FUGR') GROUP BY Sub_Type";
		Query query = session.createQuery(hql);
		List<Object[]> resultList = query.list();
		if (CollectionUtils.isNotEmpty(resultList)) {
			for (Object[] object : resultList) {
				resultMap.put((String) object[0], ((Long) object[1]).intValue());
			}
		}
		session.close();
		return resultMap;

	}

	// CR-13.0 Getting Distinct obj_name on basis of obj_type(CLAS)
	@Override
	public Map<String, Integer> getDistObjNameCountCLAS(final Long requestId) {
		final Map<String, Integer> resultMap = new HashMap<String, Integer>();
		session = sessionFactory.openSession();
		hql = "SELECT SUM(cnt) FROM (select count(distinct obj_name) as cnt from final_output  where Request_ID= "
				+ requestId + "  and  Object_Type in ('CLAS') GROUP BY sub_type) as cnt";
		List<List<Object>> resultList = session.createSQLQuery(hql).setResultTransformer(Transformers.TO_LIST).list();

		if (null != resultList.get(0) && !resultList.isEmpty()) {

			for (List<Object> x : resultList) {
				if (x.get(0) != null) {
					resultMap.put("CLAS", Integer.parseInt((String) x.get(0).toString()));
				}
			}
		}
		session.close();
		return resultMap;
	}

	@Override
	public void updateTestingScopeMasterData(long requestId, TestingScope master) {
		Session session = sessionFactory.openSession();
		try {
			session.saveOrUpdate(master);
			session.close();
		} catch (Exception e) {
			e.getMessage();
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		logger.info("Updated Testing scope Request Master !!!!!!!!!!!!!!!!! ");
	}

	@Override
	public void updateImpatedBackgroundJobCount(long requestId) {
		logger.info("Inside update Batch Job  !!!!!!!!!!!!!!!!! ");
		Session session = sessionFactory.getCurrentSession();
		if (null == session) {
			session = sessionFactory.openSession();
		}
		ImpactedBackgroundCounts batchJob=new ImpactedBackgroundCounts();
		Map<String, Integer> resultJobRunCount = getJobRunCount(requestId);
		batchJob.setRequestID(requestId);
		batchJob.setJobRunCount_Daily(resultJobRunCount.get("DAILY"));
		batchJob.setJobRunCount_Weekly(resultJobRunCount.get("WEEKLY"));
		batchJob.setJobRunCount_Monthly(resultJobRunCount.get("MONTHLY"));	
		batchJob.setJobRunCount_Others(resultJobRunCount.get("OTHERS"));		

		batchJob.setBackgroundJobCount(getBackgroundJobCount(requestId));
		try{	
			session.saveOrUpdate(batchJob);
			
		}
		catch (Exception e) {
			logger.error("Error DisplayGraphDaoImpl updateImpactedBackgroundJobCount " , e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		logger.info("processing completed for Impacted Batch Job Counts !!!!!!!!!!!!!!!!! ");

	}
	
	private Integer getBackgroundJobCount(long requestId) {
		session = sessionFactory.openSession();
		Integer count=0;
			hql = "select count(bJobName) from ImpactedBackgroundJob_Download where requestId=:requestId";

			Query query = session.createQuery(hql);
			query.setParameter("requestId", requestId);

			Object object= query.uniqueResult();
			if(object!= null) {
				count= ((Long) object).intValue();
			}
			session.close();
	
		return count;
	}
	
	@Override
	public void updateRequestMaster(long requestId, ProcessedRequestDetail requestMasterCommon) {
		logger.info("Inside updateRequestMaster  !!!!!!!!!!!!!!!!! ");
		ProcessedRequestDetail reqMaster = new ProcessedRequestDetail();
		reqMaster.setRequestID(requestId);
		Map<String, Map<String, Integer>> resultImpactedObjList = getUsedCountImpactObjList(requestId);
		Map<String, Integer> resultTotalImpactedObjList = getTotalUsedCountImpactObjList(requestId);
		Map<String, Map<String, Integer>> resultErrorObject = getErrorObjectandUsedCount(requestId);
		Map<String, Map<String, Integer>> resultRemediCategory = getRemediationUsedCount(requestId);
		Map<String, Map<String, Integer>> resultAutomationUsedObject = getObjectAutomationUsedCount(requestId);
		Map<String, Map<String, Integer>> subCategory = getCountSubCategory(requestId);
		Integer errorAutomationYcount = getErrorAutomationY(requestId);
		Map<String, Map<String, Integer>> resultDbOperationObject = getDBLevelOperationCount(requestId);
		Map<String, Map<String, Integer>> resultRemediAuto = getRemediationAutoCount(requestId);
		Map<String, Map<String, Map<String, Integer>>> houseKeepingCnt = getHouseKeepHanaCount(requestId);
		Map<String, Map<String, Map<String, Integer>>> appLevelCnt = getAppLevelHanaCount(requestId);
		Map<String, Map<String, Map<String, Integer>>> manIssueCatAutoY = getManIssueCatgAutoYCount(requestId);
		Map<String, Map<String, Map<String, Integer>>> manIssueCatAutoN = getManIssueCatgAutoNCount(requestId);
		Map<String, Map<String, Map<String, Integer>>> manOperationAutoY = getManIssueOperationAutoYCount(requestId);
		Map<String, Map<String, Map<String, Integer>>> manOperationAutoN = getManIssueOperationAutoNCount(requestId);

		reqMaster.setScope("Hana");

		// Request master Common columns
		reqMaster.setTotalObjectCount(requestMasterCommon.getTotalObjectCount());
		reqMaster.setUsed_count(requestMasterCommon.getUsed_count());
		reqMaster.setCustClasCount(requestMasterCommon.getCustClasCount());
		reqMaster.setCustProgCount(requestMasterCommon.getCustProgCount());
		reqMaster.setCustFormCount(requestMasterCommon.getCustFormCount());
		reqMaster.setCustFugrCount(requestMasterCommon.getCustFugrCount());
		reqMaster.setCustEnhanCount(requestMasterCommon.getCustEnhanCount());
		reqMaster.setCustLsmwCount(requestMasterCommon.getCustLsmwCount());
		reqMaster.setCustWebCount(requestMasterCommon.getCustWebCount());
		reqMaster.setCustReptCount(requestMasterCommon.getCustReptCount());
		reqMaster.setCustViewCount(requestMasterCommon.getCustViewCount());
		reqMaster.setCustIndeCount(requestMasterCommon.getCustIndeCount());
		reqMaster.setCustDtelCount(requestMasterCommon.getCustDtelCount());
		reqMaster.setUsreCount(requestMasterCommon.getUsreCount());
		reqMaster.setUsrrCount(requestMasterCommon.getUsrrCount());
		reqMaster.setFugsCount(requestMasterCommon.getFugsCount());
		reqMaster.setCust_BWTRCount(requestMasterCommon.getCust_BWTRCount());
		reqMaster.setCust_BWTSCount(requestMasterCommon.getCust_BWTSCount());
		reqMaster.setCust_BWURCount(requestMasterCommon.getCust_BWURCount());
		reqMaster.setCust_BWIGCount(requestMasterCommon.getCust_BWIGCount());

		reqMaster.setCustUsedClasCount(requestMasterCommon.getCustUsedClasCount());
		reqMaster.setCustUsedProgCount(requestMasterCommon.getCustUsedProgCount());
		reqMaster.setCustUsedFormCount(requestMasterCommon.getCustUsedFormCount());
		reqMaster.setCustUsedFugrCount(requestMasterCommon.getCustUsedFugrCount());
		reqMaster.setCustUsedEnhanCount(requestMasterCommon.getCustUsedEnhanCount());
		reqMaster.setCustUsedLsmwCount(requestMasterCommon.getCustUsedLsmwCount());

		reqMaster.setCustUsedWebCount(requestMasterCommon.getCustUsedWebCount());
		reqMaster.setCustUsedReptCount(requestMasterCommon.getCustUsedReptCount());
		reqMaster.setCustUsedViewCount(requestMasterCommon.getCustUsedViewCount());
		reqMaster.setCustUsedIndxCount(requestMasterCommon.getCustUsedIndxCount());
		reqMaster.setCustUsedDtelCount(requestMasterCommon.getCustUsedDtelCount());

		reqMaster.setUsreUsedCount(requestMasterCommon.getUsreUsedCount());
		reqMaster.setUsrrUsedCount(requestMasterCommon.getUsrrUsedCount());
		reqMaster.setFugsUsedCount(requestMasterCommon.getFugsUsedCount());
		
		reqMaster.setCustUsed_BWTRCount(requestMasterCommon.getCustUsed_BWTRCount());
		reqMaster.setCustUsed_BWTSCount(requestMasterCommon.getCustUsed_BWTSCount());
		reqMaster.setCustUsed_BWURCount(requestMasterCommon.getCustUsed_BWURCount());
		reqMaster.setCustUsed_BWIGCount(requestMasterCommon.getCustUsed_BWIGCount());

		int enhanImpact = 0;
		int formImpact = 0;
		enhanImpact = (geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("ENHC"))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("ENHC")))
				+ (geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("ENHO"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("ENHO")))
				+ (geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("ENHS"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("ENHS")));

		formImpact = (geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("SFPF"))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("SFPF")))
				+ (geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("SSFO"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("SSFO")));

		reqMaster.setDefectClasCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("CLAS"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("CLAS")));
		
		reqMaster.setDefect_BWTRCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("BWTR"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("BWTR")));
		reqMaster.setDefect_BWTSCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("BWTS"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("BWTS")));
		reqMaster.setDefect_BWURCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("BWUR"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("BWUR")));
		reqMaster.setDefect_BWIGCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("BWIG"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("BWIG")));
		
		reqMaster.setDefectProgCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("PROG"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("PROG")));
		reqMaster.setDefectFormCount(formImpact);
		reqMaster.setDefectFugrCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("FUGR"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("FUGR")));
		reqMaster.setDefectEnhanCount(enhanImpact);
		reqMaster.setDefectLsmwCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("LSMW"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("LSMW")));

		reqMaster.setDefectWebCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("WDYN"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("WDYN")));
		reqMaster.setDefectReptCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("REPT"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("REPT")));
		reqMaster.setDefectViewCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("VIEW"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("VIEW")));
		reqMaster.setDefectIndeCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("INDE"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("INDE")));
		reqMaster.setDefectDtelCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("DTEL"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("DTEL")));
		reqMaster.setDefectUsreCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("USRE"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("USRE")));
		reqMaster.setDefectUsrrCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("USRR"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("USRR")));
		reqMaster.setDefectFugsCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("FUGS"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("FUGS")));

		int enhanUsedImpact = 0;
		int formUsedImpact = 0;
		enhanUsedImpact = (geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("ENHC"))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("ENHO"))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("ENHS")));

		formUsedImpact = (geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("SFPF"))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("SSFO")));

		reqMaster.setDefectUsedClasCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("CLAS")));
		
		reqMaster.setDefectUsed_BWTRCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("BWTR")));
		reqMaster.setDefectUsed_BWTSCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("BWTS")));
		reqMaster.setDefectUsed_BWURCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("BWUR")));
		reqMaster.setDefectUsed_BWIGCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("BWIG")));
		
		reqMaster.setDefectUsedProgCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("PROG")));
		reqMaster.setDefectUsedFormCount(formUsedImpact);
		reqMaster.setDefectUsedFugrCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("FUGR")));
		reqMaster.setDefectUsedEnhanCount(enhanUsedImpact);
		reqMaster.setDefectUsedLsmwCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("LSMW")));
		reqMaster.setDefectUsedWebCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("WDYN")));
		reqMaster.setDefectUsedReptCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("REPT")));
		reqMaster.setDefectUsedViewCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("VIEW")));
		reqMaster.setDefectUsedIndxCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("INDE")));
		reqMaster.setDefectUsedDtelCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("DTEL")));
		reqMaster.setDefectUsedUsreCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("USRE")));
		reqMaster.setDefectUsedUsrrCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("USRR")));
		reqMaster.setDefectUsedFugsCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("FUGS")));
		
		reqMaster.setTotalErrorCount(getTotalCount(resultErrorObject));
		reqMaster.setErrorUsedCount(getTotalUsedCount("Y", resultErrorObject));

		reqMaster.setRemCategoryObj(geUsedUnsedColumnCount("Y", resultTotalImpactedObjList)
				+ geUsedUnsedColumnCount("N", resultTotalImpactedObjList));
		reqMaster.setRemCategoryObjError(getTotalCount(resultErrorObject));
		// Get total object count from Impacted Object List where toolname="hana"
		reqMaster.setDefectCount(geUsedUnsedColumnCount("Y", resultTotalImpactedObjList)
				+ geUsedUnsedColumnCount("N", resultTotalImpactedObjList));

		reqMaster.setTotalImpactUsageCount(geUsedUnsedColumnCount("Y", resultTotalImpactedObjList));
		reqMaster.setErrorHanaDbCount(getTotalCount(resultErrorObject));

		int errorEnhanCount = 0;
		int errorFormCount = 0;
		errorEnhanCount = (geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("ENHC"))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultErrorObject.get("ENHC")))
				+ (geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("ENHO"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultErrorObject.get("ENHO")))
				+ (geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("ENHS"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultErrorObject.get("ENHS")));

		errorFormCount = (geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("SFPF"))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultErrorObject.get("SFPF")))
				+ (geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("SSFO"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultErrorObject.get("SSFO")));

		reqMaster.setErrorClasCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("CLAS"))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultErrorObject.get("CLAS")));
		
		reqMaster.setErrorBWTRCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("BWTR"))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultErrorObject.get("BWTR")));
		reqMaster.setErrorBWTSCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("BWTS"))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultErrorObject.get("BWTS")));
		reqMaster.setErrorBWURCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("BWUR"))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultErrorObject.get("BWUR")));
		reqMaster.setErrorBWIGCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("BWIG"))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultErrorObject.get("BWIG")));
		
		reqMaster.setErrorProgCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("PROG"))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultErrorObject.get("PROG")));
		reqMaster.setErrorFormCount(errorFormCount);
		reqMaster.setErrorFugrCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("FUGR"))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultErrorObject.get("FUGR")));
		reqMaster.setErrorEnhCount(errorEnhanCount);
		reqMaster.setErrorLsmwCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("LSMW"))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultErrorObject.get("LSMW")));
		reqMaster.setErrorWdynCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("WDYN"))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultErrorObject.get("WDYN")));
		reqMaster.setErrorReptCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("REPT"))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultErrorObject.get("REPT")));
		reqMaster.setErrorViewCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("VIEW"))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultErrorObject.get("VIEW")));
		reqMaster.setErrorIndxCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("INDE"))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultErrorObject.get("INDE")));
		reqMaster.setErrorDtelCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("DTEL"))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultErrorObject.get("DTEL")));
		reqMaster.setErrorUsreCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("USRE"))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultErrorObject.get("USRE")));
		reqMaster.setErrorUsrrCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("USRR"))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultErrorObject.get("USRR")));
		reqMaster.setErrorFugsCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("FUGS"))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultErrorObject.get("FUGS")));

		int errorUsedFormCount = 0;
		int errorUsedEnhanCount = 0;

		errorUsedEnhanCount = (geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("ENHC")))
				+ (geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("ENHO")))
				+ (geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("ENHS")));

		errorUsedFormCount = (geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("SFPF")))
				+ (geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("SSFO")));

		reqMaster.setErrorUsedClasCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("CLAS")));
		
		reqMaster.setErrorUsedBWTRCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("BWTR")));
		reqMaster.setErrorUsedBWTSCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("BWTS")));
		reqMaster.setErrorUsedBWURCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("BWUR")));
		reqMaster.setErrorUsedBWIGCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("BWIG")));
		
		reqMaster.setErrorUsedProgCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("PROG")));
		reqMaster.setErrorUsedFormCount(errorUsedFormCount);
		reqMaster.setErrorUsedFugrCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("FUGR")));
		reqMaster.setErrorUsedEnhCount(errorUsedEnhanCount);
		reqMaster.setErrorUsedLsmwCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("LSMW")));
		reqMaster.setErrorUsedWdynCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("WDYN")));
		reqMaster.setErrorUsedReptCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("REPT")));
		reqMaster.setErrorUsedViewCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("VIEW")));
		reqMaster.setErrorUsedIndxCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("INDE")));
		reqMaster.setErrorUsedDtelCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("DTEL")));
		reqMaster.setErrorUsedUsreCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("USRE")));
		reqMaster.setErrorUsedUsrrCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("USRR")));
		reqMaster.setErrorUsedFugsCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultErrorObject.get("FUGS")));

		reqMaster.setMandatory_Category_count(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
				resultRemediCategory.get(("Mandatory").toUpperCase()))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_DISTINCT,
						resultRemediCategory.get(("Mandatory").toUpperCase())));
		reqMaster.setApp_level_category_count(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
				resultRemediCategory.get(("Application level optimization").toUpperCase()))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_DISTINCT,
						resultRemediCategory.get(("Application level optimization").toUpperCase())));
		reqMaster.setDb_level_category_count(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
				resultRemediCategory.get(("DB Level HANA Optimization").toUpperCase()))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_DISTINCT,
						resultRemediCategory.get(("DB Level HANA Optimization").toUpperCase())));

		reqMaster.setHousekeeping_for_HANA_category_count(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
				resultRemediCategory.get(("Housekeeping for HANA").toUpperCase()))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_DISTINCT,
						resultRemediCategory.get(("Housekeeping for HANA").toUpperCase())));

		reqMaster.setErrorRemediationMandatory(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
				resultRemediCategory.get(("Mandatory").toUpperCase()))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT,
						resultRemediCategory.get(("Mandatory").toUpperCase())));
		reqMaster.setErrorRemediationAppLevel(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
				resultRemediCategory.get(("Application level optimization").toUpperCase()))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT,
						resultRemediCategory.get(("Application level optimization").toUpperCase())));
		reqMaster.setErrorRemediationDbLevel(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
				resultRemediCategory.get(("DB Level HANA Optimization").toUpperCase()))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT,
						resultRemediCategory.get(("DB Level HANA Optimization").toUpperCase())));

		reqMaster.setErrorRemediationHouseKeeping(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
				resultRemediCategory.get(("Housekeeping for HANA").toUpperCase()))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT,
						resultRemediCategory.get(("Housekeeping for HANA").toUpperCase())));

		reqMaster.setMandUsedCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
				resultRemediCategory.get(("Mandatory").toUpperCase())));
		reqMaster.setObjectUsedRemAppLevel(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
				resultRemediCategory.get(("Application level optimization").toUpperCase())));
		reqMaster.setObjectUsedRemDbLevel(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
				resultRemediCategory.get(("DB Level HANA Optimization").toUpperCase())));
		reqMaster.setObjectUsedRemHouseKeeping(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
				resultRemediCategory.get(("Housekeeping for HANA").toUpperCase())));

		reqMaster.setErrorUsedRemMandatory(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
				resultRemediCategory.get(("Mandatory").toUpperCase())));
		reqMaster.setErrorUsedRemAppLevel(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
				resultRemediCategory.get(("Application level optimization").toUpperCase())));
		reqMaster.setErrorUsedRemDbLevel(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
				resultRemediCategory.get(("DB Level HANA Optimization").toUpperCase())));
		reqMaster.setErrorUsedRemHouseKeeping(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
				resultRemediCategory.get(("Housekeeping for HANA").toUpperCase())));

		reqMaster.setMigrationAutomatedCount(getTotalCount(resultAutomationUsedObject));
		reqMaster.setErrorAutomationY(errorAutomationYcount);

		reqMaster.sethANA_Sorting_cnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
				subCategory.get(("HANA Sorting").toUpperCase()))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT,
						subCategory.get(("HANA Sorting").toUpperCase())));
		reqMaster.setMinimize_amnt_data_trnsfr_cnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
				subCategory.get(("Minimize the amount of transferred data").toUpperCase()))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT,
						subCategory.get(("Minimize the amount of transferred data").toUpperCase())));

		reqMaster.setPotential_syntax_err_cnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
				subCategory.get("Potential syntax error".toUpperCase()))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT,
						subCategory.get("Potential syntax error".toUpperCase())));
		reqMaster.setResult_set_small_subcategry_count(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
				subCategory.get("Keep the result set small".toUpperCase()))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT,
						subCategory.get("Keep the result set small".toUpperCase())));

		reqMaster.setSemantic_Err_cnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
				subCategory.get("Semantic Error".toUpperCase()))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT,
						subCategory.get("Semantic Error".toUpperCase())));
		reqMaster.setStatement_ignr_HANA_sbcatgry(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
				subCategory.get("Statement ignored by HANA".toUpperCase()))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT,
						subCategory.get("Statement ignored by HANA".toUpperCase())));
		reqMaster.setUnneces_loa_away_subcategry_count(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
				subCategory.get("Keep unnecessary load away from database".toUpperCase()))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT,
						subCategory.get("Keep unnecessary load away from database".toUpperCase())));
		reqMaster.setValidat_syntx_err_subcatgry(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
				subCategory.get("Validated syntax error".toUpperCase()))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT,
						subCategory.get("Validated syntax error".toUpperCase())));

		reqMaster.setHanaSortingUsedCnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
				subCategory.get("HANA Sorting".toUpperCase())));
		reqMaster.setMinimizeAmntDataTrnsfrUsedCnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
				subCategory.get("Minimize the amount of transferred data".toUpperCase())));
		reqMaster.setPotentialSyntaxErrUsedCnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
				subCategory.get("Potential syntax error".toUpperCase())));
		reqMaster.setResultSetSmallUsedCnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
				subCategory.get("Keep the result set small".toUpperCase())));

		reqMaster.setSemanticErrUsedCnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
				subCategory.get("Semantic Error".toUpperCase())));
		reqMaster.setStatementIgnrHanaUsedCnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
				subCategory.get("Statement ignored by HANA".toUpperCase())));
		reqMaster.setUnnecesLoaAwayUsedCnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
				subCategory.get("Keep unnecessary load away from database".toUpperCase())));
		reqMaster.setValidatSyntxErrUsedCnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
				subCategory.get("Validated syntax error".toUpperCase())));

		////
		reqMaster.setDefectHanaSorting(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
				subCategory.get(("HANA Sorting").toUpperCase()))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_DISTINCT,
						subCategory.get(("HANA Sorting").toUpperCase())));
		reqMaster.setDefecMminimizeAmntDataTrnsfr(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
				subCategory.get(("Minimize the amount of transferred data").toUpperCase()))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_DISTINCT,
						subCategory.get(("Minimize the amount of transferred data").toUpperCase())));

		reqMaster.setDefectPotentialSyntax(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
				subCategory.get("Potential syntax error".toUpperCase()))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_DISTINCT,
						subCategory.get("Potential syntax error".toUpperCase())));
		reqMaster.setDefectResultsetSmallSubcategry(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
				subCategory.get("Keep the result set small".toUpperCase()))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_DISTINCT,
						subCategory.get("Keep the result set small".toUpperCase())));

		reqMaster.setDefectSemanticErr(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
				subCategory.get("Semantic Error".toUpperCase()))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_DISTINCT,
						subCategory.get("Semantic Error".toUpperCase())));
		reqMaster.setDefectStmtIgnrHanaSbcatgry(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
				subCategory.get("Statement ignored by HANA".toUpperCase()))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_DISTINCT,
						subCategory.get("Statement ignored by HANA".toUpperCase())));
		reqMaster.setDefectUnnecesLoaAwaySbcatgry(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
				subCategory.get("Keep unnecessary load away from database".toUpperCase()))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_DISTINCT,
						subCategory.get("Keep unnecessary load away from database".toUpperCase())));
		reqMaster.setDefectValidatSyntxSubcatgry(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
				subCategory.get("Validated syntax error".toUpperCase()))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_DISTINCT,
						subCategory.get("Validated syntax error".toUpperCase())));

		reqMaster.setDefectHanaSortingUsedCnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
				subCategory.get("HANA Sorting".toUpperCase())));
		reqMaster.setDefectMinAmntDataTrnsfrUsedCnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
				subCategory.get("Minimize the amount of transferred data".toUpperCase())));
		reqMaster.setDefectPotentialSyntaxUsedCnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
				subCategory.get("Potential syntax error".toUpperCase())));
		reqMaster.setDefectResultSetSmallUsedCnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
				subCategory.get("Keep the result set small".toUpperCase())));

		reqMaster.setDefectSemanticErrUsedCnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
				subCategory.get("Semantic Error".toUpperCase())));
		reqMaster.setDefectStmtIgnrHanaUsedCnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
				subCategory.get("Statement ignored by HANA".toUpperCase())));
		reqMaster.setDefectUnnecesLoaAwayUsedCnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
				subCategory.get("Keep unnecessary load away from database".toUpperCase())));
		reqMaster.setDefectValidatSyntxErrUsedCnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
				subCategory.get("Validated syntax error".toUpperCase())));

		Map<String, Integer> distinctDbOptnMap = resultDbOperationObject.get("distinctCountMap");
		if (distinctDbOptnMap != null && !distinctDbOptnMap.isEmpty()) {

			reqMaster.setDbMinAmtRepeatDbAutoN(
					(distinctDbOptnMap.containsKey("Repeated Database Hits On Table".toUpperCase())
							? (distinctDbOptnMap.get("Repeated Database Hits On Table".toUpperCase()))
							: 0));
			reqMaster.setDbMinAmtJoinSelectStmtAutoN(
					(distinctDbOptnMap.containsKey("JOINS ON TABLES IN SELECT STATEMENTS".toUpperCase())
							? (distinctDbOptnMap.get("JOINS ON TABLES IN SELECT STATEMENTS".toUpperCase()))
							: 0));
			reqMaster.setDbMinAmtAllEntriesAutoN((distinctDbOptnMap.containsKey("For All Entries used".toUpperCase())
					? (distinctDbOptnMap.get("For All Entries used".toUpperCase()))
					: 0));
			reqMaster.setDbMinAmtCurrencyConvAutoN(
					(distinctDbOptnMap.containsKey("FM USED FOR CURRENCY CONVERSION".toUpperCase())
							? (distinctDbOptnMap.get("FM USED FOR CURRENCY CONVERSION".toUpperCase()))
							: 0));
			reqMaster.setDbMinAmtFaeJoinAutoN((distinctDbOptnMap.containsKey("FAE & JOIN".toUpperCase())
					? (distinctDbOptnMap.get("FAE & JOIN".toUpperCase()))
					: 0));
			reqMaster.setDbMinAmtAggStmtCollectAutoN(
					(distinctDbOptnMap.containsKey("AGGREGATION STATEMENT COLLECT".toUpperCase())
							? (distinctDbOptnMap.get("AGGREGATION STATEMENT COLLECT".toUpperCase()))
							: 0));

		}

		Map<String, Integer> errorDbOPtnMap = resultDbOperationObject.get("errorCountMap");

		if (errorDbOPtnMap != null && !errorDbOPtnMap.isEmpty()) {

			reqMaster.setDbMinAmtRepeatDbAutoNError(
					(errorDbOPtnMap.containsKey("Repeated Database Hits On Table".toUpperCase())
							? (errorDbOPtnMap.get("Repeated Database Hits On Table".toUpperCase()))
							: 0));
			reqMaster.setDbMinAmtJoinSelectAutoNError(
					(errorDbOPtnMap.containsKey("JOINS ON TABLES IN SELECT STATEMENTS".toUpperCase())
							? (errorDbOPtnMap.get("JOINS ON TABLES IN SELECT STATEMENTS".toUpperCase()))
							: 0));
			reqMaster.setDbMinAmtAllEntriesAutoNError((errorDbOPtnMap.containsKey("For All Entries used".toUpperCase())
					? (errorDbOPtnMap.get("For All Entries used".toUpperCase()))
					: 0));
			reqMaster.setDbMinAmtCurrencyAutoNError(
					(errorDbOPtnMap.containsKey("FM USED FOR CURRENCY CONVERSION".toUpperCase())
							? (errorDbOPtnMap.get("FM USED FOR CURRENCY CONVERSION".toUpperCase()))
							: 0));
			reqMaster.setDbMinAmtFaeJoinAutoNError((errorDbOPtnMap.containsKey("FAE & JOIN".toUpperCase())
					? (errorDbOPtnMap.get("FAE & JOIN".toUpperCase()))
					: 0));
			reqMaster.setDbMinAmtAggStmtAutoNError(
					(errorDbOPtnMap.containsKey("AGGREGATION STATEMENT COLLECT".toUpperCase())
							? (errorDbOPtnMap.get("AGGREGATION STATEMENT COLLECT".toUpperCase()))
							: 0));

		}

		reqMaster.setMandatoryAutoY(
				geUsedUnsedColumnCount("autoYDistinct", resultRemediAuto.get(("Mandatory").toUpperCase())));
		reqMaster.setHkAutoY(
				geUsedUnsedColumnCount("autoYDistinct", resultRemediAuto.get(("Housekeeping for HANA").toUpperCase())));
		reqMaster.setDbLevelAutoY(geUsedUnsedColumnCount("autoYDistinct",
				resultRemediAuto.get(("DB Level HANA Optimization").toUpperCase())));
		reqMaster.setAppLevelAutoY(geUsedUnsedColumnCount("autoYDistinct",
				resultRemediAuto.get(("Application level optimization").toUpperCase())));
		reqMaster.setMandatoryAutoN(
				geUsedUnsedColumnCount("autoNDistinct", resultRemediAuto.get(("Mandatory").toUpperCase())));
		reqMaster.setHkAutoN(
				geUsedUnsedColumnCount("autoNDistinct", resultRemediAuto.get(("Housekeeping for HANA").toUpperCase())));
		reqMaster.setDbLevelAutoN(geUsedUnsedColumnCount("autoNDistinct",
				resultRemediAuto.get(("DB Level HANA Optimization").toUpperCase())));
		reqMaster.setAppLevelAutoN(geUsedUnsedColumnCount("autoNDistinct",
				resultRemediAuto.get(("Application level optimization").toUpperCase())));

		reqMaster.setErrorMandatoryAutoY(
				geUsedUnsedColumnCount("autoYAll", resultRemediAuto.get(("Mandatory").toUpperCase())));
		reqMaster.setErrorHkAutoY(
				geUsedUnsedColumnCount("autoYAll", resultRemediAuto.get(("Housekeeping for HANA").toUpperCase())));
		reqMaster.setErrorDbLevelAutoY(
				geUsedUnsedColumnCount("autoYAll", resultRemediAuto.get(("DB Level HANA Optimization").toUpperCase())));
		reqMaster.setErrorAppLevelAutoY(geUsedUnsedColumnCount("autoYAll",
				resultRemediAuto.get(("Application level optimization").toUpperCase())));
		reqMaster.setErrorMandatoryAutoN(
				geUsedUnsedColumnCount("autoNAll", resultRemediAuto.get(("Mandatory").toUpperCase())));
		reqMaster.setErrorHkAutoN(
				geUsedUnsedColumnCount("autoNAll", resultRemediAuto.get(("Housekeeping for HANA").toUpperCase())));
		reqMaster.setErrorDbLevelAutoN(
				geUsedUnsedColumnCount("autoNAll", resultRemediAuto.get(("DB Level HANA Optimization").toUpperCase())));
		reqMaster.setErrorAppLevelAutoN(geUsedUnsedColumnCount("autoNAll",
				resultRemediAuto.get(("Application level optimization").toUpperCase())));

		if (houseKeepingCnt.containsKey("Keep unnecessary load away from database".toUpperCase())) {
			Map<String, Map<String, Integer>> oprtnMap = houseKeepingCnt
					.get("Keep unnecessary load away from database".toUpperCase());
			if (oprtnMap.containsKey("BYPASS TABLE BUFFER".toUpperCase())) {
				reqMaster.setHkHSLoadByTableBuff(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						oprtnMap.get(("BYPASS TABLE BUFFER").toUpperCase())));
				reqMaster.setHkHSLoadByTableBuffError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						oprtnMap.get(("BYPASS TABLE BUFFER").toUpperCase())));

			}
		} else {
			reqMaster.setHkHSLoadByTableBuff(0);
			reqMaster.setHkHSLoadByTableBuffError(0);

		}

		if (houseKeepingCnt.containsKey("Statement ignored by HANA".toUpperCase())) {
			Map<String, Map<String, Integer>> oprtnMap = houseKeepingCnt.get("Statement ignored by HANA".toUpperCase());
			if (oprtnMap.containsKey("DB HINTS USED".toUpperCase())) {
				reqMaster.setHkHsStmtDbHintUsed(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						oprtnMap.get(("DB HINTS USED").toUpperCase())));
				reqMaster.setHkHsStmtDbHintUsedError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						oprtnMap.get(("DB HINTS USED").toUpperCase())));

			}
		} else {
			reqMaster.setHkHsStmtDbHintUsed(0);
			reqMaster.setHkHsStmtDbHintUsedError(0);

		}

		if (appLevelCnt.containsKey("Code maintainability (HANA specific)".toUpperCase())) {
			Map<String, Map<String, Integer>> subCatMap = appLevelCnt
					.get("Code maintainability (HANA specific)".toUpperCase());
			if (subCatMap.containsKey("Keep unnecessary load away from database".toUpperCase())) {
				reqMaster.setAppHSLoad(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						subCatMap.get(("Keep unnecessary load away from database").toUpperCase())));
				reqMaster.setAppHSLoadError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						subCatMap.get(("Keep unnecessary load away from database").toUpperCase())));

			}
		} else {
			reqMaster.setAppHSLoad(0);
			reqMaster.setAppHSLoadError(0);

		}
		if (appLevelCnt.containsKey("Optimize the use of Logical Database".toUpperCase())) {
			Map<String, Map<String, Integer>> subCatMap = appLevelCnt
					.get("Optimize the use of Logical Database".toUpperCase());
			if (subCatMap.containsKey("Keep unnecessary load away from database".toUpperCase())) {
				reqMaster.setAppLoadOptimizeDb(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						subCatMap.get(("Keep unnecessary load away from database").toUpperCase())));
				reqMaster.setAppLoadOptimizeDbError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						subCatMap.get(("Keep unnecessary load away from database").toUpperCase())));

			}
		} else {
			reqMaster.setAppLoadOptimizeDb(0);
			reqMaster.setAppLoadOptimizeDbError(0);

		}

		if (appLevelCnt.containsKey("Performance (general)".toUpperCase())) {
			Map<String, Map<String, Integer>> subCatMap = appLevelCnt.get("Performance (general)".toUpperCase());
			if (subCatMap.containsKey("Keep unnecessary load away from database".toUpperCase())) {
				reqMaster.setAppLoadPerfGen(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						subCatMap.get(("Keep unnecessary load away from database").toUpperCase())));
				reqMaster.setAppLoadPerfGenError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						subCatMap.get(("Keep unnecessary load away from database").toUpperCase())));

			} else {
				reqMaster.setAppLoadPerfGen(0);
				reqMaster.setAppLoadPerfGenError(0);
			}

			if (subCatMap.containsKey("Keep the result set small".toUpperCase())) {
				reqMaster.setAppResSmlPerfGen(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						subCatMap.get(("Keep the result set small").toUpperCase())));
				reqMaster.setAppResSmlPerfGenError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						subCatMap.get(("Keep the result set small").toUpperCase())));

			} else {
				reqMaster.setAppResSmlPerfGen(0);
				reqMaster.setAppResSmlPerfGenError(0);
			}

			if (subCatMap.containsKey("Minimize the amount of transferred data".toUpperCase())) {
				reqMaster.setAppMinDataPerfGen(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						subCatMap.get(("Minimize the amount of transferred data").toUpperCase())));
				reqMaster.setAppMinDataPerfGenError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						subCatMap.get(("Minimize the amount of transferred data").toUpperCase())));

			} else {
				reqMaster.setAppMinDataPerfGen(0);
				reqMaster.setAppMinDataPerfGenError(0);
			}

		}

		if (appLevelCnt.containsKey("Performance (HANA specific)".toUpperCase())) {
			Map<String, Map<String, Integer>> subCatMap = appLevelCnt.get("Performance (HANA specific)".toUpperCase());
			if (subCatMap.containsKey("Minimize the amount of transferred data".toUpperCase())) {
				reqMaster.setAppMinDataHS(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						subCatMap.get(("Minimize the amount of transferred data").toUpperCase())));
				reqMaster.setAppMinDataHSError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						subCatMap.get(("Minimize the amount of transferred data").toUpperCase())));

			}
		} else {
			reqMaster.setAppMinDataHS(0);
			reqMaster.setAppMinDataHSError(0);

		}

		if (manIssueCatAutoY.containsKey("Functional error".toUpperCase())) {
			Map<String, Map<String, Integer>> subCatMap = manIssueCatAutoY.get("Functional error".toUpperCase());
			if (subCatMap.containsKey("Semantic Error".toUpperCase())) {
				reqMaster.setManFunSemanticAutoY(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						subCatMap.get(("Semantic Error").toUpperCase())));
				reqMaster.setManFunSemanticAutoYError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						subCatMap.get(("Semantic Error").toUpperCase())));

			} else {
				reqMaster.setManFunSemanticAutoY(0);
				reqMaster.setManFunSemanticAutoYError(0);
			}

			if (subCatMap.containsKey("HANA Sorting".toUpperCase())) {
				reqMaster.setManFunHanaSortAutoY(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						subCatMap.get(("HANA Sorting").toUpperCase())));
				reqMaster.setManFunHanaSortAutoYError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						subCatMap.get(("HANA Sorting").toUpperCase())));

			} else {
				reqMaster.setManFunHanaSortAutoY(0);
				reqMaster.setManFunHanaSortAutoYError(0);
			}

		} else {
			reqMaster.setManFunSemanticAutoY(0);
			reqMaster.setManFunSemanticAutoYError(0);
			reqMaster.setManFunHanaSortAutoY(0);
			reqMaster.setManFunHanaSortAutoYError(0);
		}

		if (manIssueCatAutoY.containsKey("Syntax Error".toUpperCase())) {
			Map<String, Map<String, Integer>> subCatMap = manIssueCatAutoY.get("Syntax Error".toUpperCase());
			if (subCatMap.containsKey("Validated syntax error".toUpperCase())) {
				reqMaster.setManSynValidAutoY(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						subCatMap.get(("Validated syntax error").toUpperCase())));
				reqMaster.setManSynValidAutoYError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						subCatMap.get(("Validated syntax error").toUpperCase())));

			} else {
				reqMaster.setManSynValidAutoY(0);
				reqMaster.setManSynValidAutoYError(0);
			}

			if (subCatMap.containsKey("Potential syntax error".toUpperCase())) {
				reqMaster.setManSynPotentialAutoY(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						subCatMap.get(("Potential syntax error").toUpperCase())));
				reqMaster.setManSynPotentialAutoYError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						subCatMap.get(("Potential syntax error").toUpperCase())));

			} else {
				reqMaster.setManSynPotentialAutoY(0);
				reqMaster.setManSynPotentialAutoYError(0);
			}

		} else {
			reqMaster.setManSynValidAutoY(0);
			reqMaster.setManSynValidAutoYError(0);
			reqMaster.setManSynPotentialAutoY(0);
			reqMaster.setManSynPotentialAutoYError(0);
		}

		if (manIssueCatAutoN.containsKey("Functional error".toUpperCase())) {
			Map<String, Map<String, Integer>> subCatMap = manIssueCatAutoN.get("Functional error".toUpperCase());
			if (subCatMap.containsKey(("Semantic Error").toUpperCase())) {
				reqMaster.setManFunSemanticAutoN(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						subCatMap.get(("Semantic Error").toUpperCase())));
				reqMaster.setManFunSemanticAutoNError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						subCatMap.get(("Semantic Error").toUpperCase())));

			} else {
				reqMaster.setManFunSemanticAutoN(0);
				reqMaster.setManFunSemanticAutoNError(0);
			}

			if (subCatMap.containsKey(("HANA Sorting").toUpperCase())) {
				reqMaster.setManFunHanaSortAutoN(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						subCatMap.get(("HANA Sorting").toUpperCase())));
				reqMaster.setManFunHanaSortAutoNError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						subCatMap.get(("HANA Sorting").toUpperCase())));

			} else {
				reqMaster.setManFunHanaSortAutoN(0);
				reqMaster.setManFunHanaSortAutoNError(0);
			}

		} else {
			reqMaster.setManFunSemanticAutoN(0);
			reqMaster.setManFunSemanticAutoNError(0);
			reqMaster.setManFunHanaSortAutoN(0);
			reqMaster.setManFunHanaSortAutoNError(0);
		}

		if (manIssueCatAutoN.containsKey("Syntax Error".toUpperCase())) {
			Map<String, Map<String, Integer>> subCatMap = manIssueCatAutoN.get("Syntax Error".toUpperCase());
			if (subCatMap.containsKey("Validated syntax error".toUpperCase())) {
				reqMaster.setManSynValidAutoN(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						subCatMap.get(("Validated syntax error").toUpperCase())));
				reqMaster.setManSynValidAutoNError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						subCatMap.get(("Validated syntax error").toUpperCase())));

			} else {
				reqMaster.setManSynValidAutoN(0);
				reqMaster.setManSynValidAutoNError(0);
			}

			if (subCatMap.containsKey("Potential syntax error".toUpperCase())) {
				reqMaster.setManSynPotentialAutoN(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						subCatMap.get(("Potential syntax error").toUpperCase())));
				reqMaster.setManSynPotentialAutoNError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						subCatMap.get(("Potential syntax error").toUpperCase())));

			} else {
				reqMaster.setManSynPotentialAutoN(0);
				reqMaster.setManSynPotentialAutoNError(0);
			}

		} else {
			reqMaster.setManSynValidAutoN(0);
			reqMaster.setManSynValidAutoNError(0);
			reqMaster.setManSynPotentialAutoN(0);
			reqMaster.setManSynPotentialAutoNError(0);
		}
		// Slide 11

		if (manOperationAutoY.containsKey("Semantic Error".toUpperCase())) {
			Map<String, Map<String, Integer>> operationMap = manOperationAutoY.get("Semantic Error".toUpperCase());
			if (operationMap.containsKey("Pool/Cluster Table".toUpperCase())) {
				reqMaster.setManSemPoolClustAutoY(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						operationMap.get(("Pool/Cluster Table").toUpperCase())));
				reqMaster.setManSemPoolClustAutoYError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						operationMap.get(("Pool/Cluster Table").toUpperCase())));

			} else {
				reqMaster.setManSemPoolClustAutoY(0);
				reqMaster.setManSemPoolClustAutoYError(0);
			}

			if (operationMap.containsKey("DB operations on Table pool & Table Cluster".toUpperCase())) {
				reqMaster.setManSemDbPoolAutoY(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						operationMap.get(("DB operations on Table pool & Table Cluster").toUpperCase())));
				reqMaster.setManSemDbPoolAutoYError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						operationMap.get(("DB operations on Table pool & Table Cluster").toUpperCase())));

			} else {
				reqMaster.setManSemDbPoolAutoY(0);
				reqMaster.setManSemDbPoolAutoYError(0);
			}

		} else {
			reqMaster.setManSemPoolClustAutoY(0);
			reqMaster.setManSemPoolClustAutoYError(0);
			reqMaster.setManSemDbPoolAutoY(0);
			reqMaster.setManSemDbPoolAutoYError(0);
		}

		if (manOperationAutoY.containsKey("Validated syntax error".toUpperCase())) {
			Map<String, Map<String, Integer>> operationMap = manOperationAutoY
					.get("Validated syntax error".toUpperCase());
			if (operationMap.containsKey("NATIVE SQL CALL".toUpperCase())) {
				reqMaster.setManVSynNsqlAutoY(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						operationMap.get(("NATIVE SQL CALL").toUpperCase())));
				reqMaster.setManVSynNsqlAutoYError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						operationMap.get(("NATIVE SQL CALL").toUpperCase())));

			} else {
				reqMaster.setManVSynNsqlAutoY(0);
				reqMaster.setManVSynNsqlAutoYError(0);
			}

			if (operationMap.containsKey("DDIC FUNCTION MODULE CALL".toUpperCase())) {
				reqMaster.setManVSynDDICFmlAutoY(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						operationMap.get(("DDIC FUNCTION MODULE CALL").toUpperCase())));
				reqMaster.setManVSynDDICFmlAutoYError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						operationMap.get(("DDIC FUNCTION MODULE CALL").toUpperCase())));

			} else {
				reqMaster.setManVSynDDICFmlAutoY(0);
				reqMaster.setManVSynDDICFmlAutoYError(0);
			}

		} else {
			reqMaster.setManVSynNsqlAutoY(0);
			reqMaster.setManVSynNsqlAutoYError(0);
			reqMaster.setManVSynDDICFmlAutoY(0);
			reqMaster.setManVSynDDICFmlAutoYError(0);
		}

		if (manOperationAutoY.containsKey("Potential syntax error".toUpperCase())) {
			Map<String, Map<String, Integer>> operationMap = manOperationAutoY
					.get("Potential syntax error".toUpperCase());
			if (operationMap.containsKey("ADBC USAGE".toUpperCase())) {
				reqMaster.setManVSynAdbcUsAutoY(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						operationMap.get(("ADBC USAGE").toUpperCase())));
				reqMaster.setManVSynAdbcUsAutoYError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						operationMap.get(("ADBC USAGE").toUpperCase())));

			}
		} else {
			reqMaster.setManVSynAdbcUsAutoY(0);
			reqMaster.setManVSynAdbcUsAutoYError(0);
		}

		if (manOperationAutoY.containsKey("HANA Sorting".toUpperCase())) {
			Map<String, Map<String, Integer>> operationMap = manOperationAutoY.get("HANA Sorting".toUpperCase());
			if (operationMap.containsKey("UNSORTED INTERNAL TABLE ACCESSED WITH INDEX".toUpperCase())) {
				reqMaster.setManHSortUnInternalAutoY(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						operationMap.get(("UNSORTED INTERNAL TABLE ACCESSED WITH INDEX").toUpperCase())));
				reqMaster.setManHSortUnInternalAutoYError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						operationMap.get(("UNSORTED INTERNAL TABLE ACCESSED WITH INDEX").toUpperCase())));

			} else {
				reqMaster.setManHSortUnInternalAutoY(0);
				reqMaster.setManHSortUnInternalAutoYError(0);
			}

			if (operationMap.containsKey("Select Single without key fields".toUpperCase())) {
				reqMaster.setManHSortSelWKyAutoY(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						operationMap.get(("Select Single without key fields").toUpperCase())));
				reqMaster.setManHSortSelWKyAutoYError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						operationMap.get(("Select Single without key fields").toUpperCase())));

			} else {
				reqMaster.setManHSortSelWKyAutoY(0);
				reqMaster.setManHSortSelWKyAutoYError(0);
			}

			if (operationMap.containsKey("READ STATEMENT WITH BINARY AND WITHOUT SORTING".toUpperCase())) {
				reqMaster.setManHSortRBWSOAutoY(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						operationMap.get(("READ STATEMENT WITH BINARY AND WITHOUT SORTING").toUpperCase())));
				reqMaster.setManHSortRBWSOAutoYError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						operationMap.get(("READ STATEMENT WITH BINARY AND WITHOUT SORTING").toUpperCase())));

			} else {
				reqMaster.setManHSortRBWSOAutoY(0);
				reqMaster.setManHSortRBWSOAutoYError(0);
			}
			if (operationMap.containsKey("DELETE ADJACENT DUPLICATES IS USED WITHOUT SORTING".toUpperCase())) {
				reqMaster.setManHSortDelAdjAutoY(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						operationMap.get(("DELETE ADJACENT DUPLICATES IS USED WITHOUT SORTING").toUpperCase())));
				reqMaster.setManHSortDelAdjAutoYError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						operationMap.get(("DELETE ADJACENT DUPLICATES IS USED WITHOUT SORTING").toUpperCase())));

			} else {
				reqMaster.setManHSortDelAdjAutoY(0);
				reqMaster.setManHSortDelAdjAutoYError(0);
			}

			if (operationMap.containsKey(
					"Control statement inside loop (Only when loop is using internal table which is not sorted)"
							.toUpperCase())) {
				reqMaster.setManHSortConStmtAutoY(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						operationMap.get(
								("Control statement inside loop (Only when loop is using internal table which is not sorted)")
										.toUpperCase())));
				reqMaster.setManHSortConStmtAutoYError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						operationMap.get(
								("Control statement inside loop (Only when loop is using internal table which is not sorted)")
										.toUpperCase())));

			} else {
				reqMaster.setManHSortConStmtAutoY(0);
				reqMaster.setManHSortConStmtAutoYError(0);
			}
			
			if (operationMap.containsKey("UNSORTED INTERNAL TABLE ACCESSED WITH FM".toUpperCase())) {
				reqMaster.setManUnsortIntTabAccFMAutoY(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						operationMap.get(("UNSORTED INTERNAL TABLE ACCESSED WITH FM").toUpperCase())));
				reqMaster.setManUnsortIntTabAccFMAutoYError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						operationMap.get(("UNSORTED INTERNAL TABLE ACCESSED WITH FM").toUpperCase())));
			} else {
				reqMaster.setManUnsortIntTabAccFMAutoY(0);
				reqMaster.setManUnsortIntTabAccFMAutoYError(0);
			}
		} else {
			reqMaster.setManHSortUnInternalAutoY(0);
			reqMaster.setManHSortUnInternalAutoYError(0);
			reqMaster.setManHSortSelWKyAutoY(0);
			reqMaster.setManHSortSelWKyAutoYError(0);
			reqMaster.setManHSortRBWSOAutoY(0);
			reqMaster.setManHSortRBWSOAutoYError(0);
			reqMaster.setManHSortDelAdjAutoY(0);
			reqMaster.setManHSortDelAdjAutoYError(0);
			reqMaster.setManHSortConStmtAutoY(0);
			reqMaster.setManHSortConStmtAutoYError(0);
			reqMaster.setManUnsortIntTabAccFMAutoY(0);
			reqMaster.setManUnsortIntTabAccFMAutoYError(0);
		}

		///

		if (manOperationAutoN.containsKey("Semantic Error".toUpperCase())) {
			Map<String, Map<String, Integer>> operationMap = manOperationAutoN.get("Semantic Error".toUpperCase());
			if (operationMap.containsKey("Pool/Cluster Table".toUpperCase())) {
				reqMaster.setManSemPoolClustAutoN(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						operationMap.get(("Pool/Cluster Table").toUpperCase())));
				reqMaster.setManSemPoolClustAutoNError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						operationMap.get(("Pool/Cluster Table").toUpperCase())));

			} else {
				reqMaster.setManSemPoolClustAutoN(0);
				reqMaster.setManSemPoolClustAutoNError(0);
			}

			if (operationMap.containsKey("DB operations on Table pool & Table Cluster".toUpperCase())) {
				reqMaster.setManSemDbPoolAutoN(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						operationMap.get(("DB operations on Table pool & Table Cluster").toUpperCase())));
				reqMaster.setManSemDbPoolAutoNError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						operationMap.get(("DB operations on Table pool & Table Cluster").toUpperCase())));

			} else {
				reqMaster.setManSemDbPoolAutoN(0);
				reqMaster.setManSemDbPoolAutoNError(0);
			}

		} else {
			reqMaster.setManSemPoolClustAutoN(0);
			reqMaster.setManSemPoolClustAutoNError(0);
			reqMaster.setManSemDbPoolAutoN(0);
			reqMaster.setManSemDbPoolAutoNError(0);
		}

		if (manOperationAutoN.containsKey("Validated syntax error".toUpperCase())) {
			Map<String, Map<String, Integer>> operationMap = manOperationAutoN
					.get("Validated syntax error".toUpperCase());
			if (operationMap.containsKey("NATIVE SQL CALL".toUpperCase())) {
				reqMaster.setManVSynNsqlAutoN(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						operationMap.get(("NATIVE SQL CALL").toUpperCase())));
				reqMaster.setManVSynNsqlAutoNError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						operationMap.get(("NATIVE SQL CALL").toUpperCase())));

			} else {
				reqMaster.setManVSynNsqlAutoN(0);
				reqMaster.setManVSynNsqlAutoNError(0);
			}

			if (operationMap.containsKey("DDIC FUNCTION MODULE CALL".toUpperCase())) {
				reqMaster.setManVSynDDICFmlAutoN(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						operationMap.get(("DDIC FUNCTION MODULE CALL").toUpperCase())));
				reqMaster.setManVSynDDICFmlAutoNError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						operationMap.get(("DDIC FUNCTION MODULE CALL").toUpperCase())));

			} else {
				reqMaster.setManVSynDDICFmlAutoN(0);
				reqMaster.setManVSynDDICFmlAutoNError(0);
			}

		} else {
			reqMaster.setManVSynNsqlAutoN(0);
			reqMaster.setManVSynNsqlAutoNError(0);
			reqMaster.setManVSynDDICFmlAutoN(0);
			reqMaster.setManVSynDDICFmlAutoNError(0);

		}

		if (manOperationAutoN.containsKey("Potential syntax error".toUpperCase())) {
			Map<String, Map<String, Integer>> operationMap = manOperationAutoN
					.get("Potential syntax error".toUpperCase());
			if (operationMap.containsKey("ADBC USAGE".toUpperCase())) {
				reqMaster.setManVSynAdbcUsAutoN(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						operationMap.get(("ADBC USAGE").toUpperCase())));
				reqMaster.setManVSynAdbcUsAutoNError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						operationMap.get(("ADBC USAGE").toUpperCase())));
			} else {
				reqMaster.setManVSynAdbcUsAutoN(0);
				reqMaster.setManVSynAdbcUsAutoNError(0);
			}
		} else {
			reqMaster.setManVSynAdbcUsAutoN(0);
			reqMaster.setManVSynAdbcUsAutoNError(0);
		}

		if (manOperationAutoN.containsKey("HANA Sorting".toUpperCase())) {
			Map<String, Map<String, Integer>> operationMap = manOperationAutoN.get("HANA Sorting".toUpperCase());
			if (operationMap.containsKey("UNSORTED INTERNAL TABLE ACCESSED WITH INDEX".toUpperCase())) {
				reqMaster.setManHSortUnInternalAutoN(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						operationMap.get(("UNSORTED INTERNAL TABLE ACCESSED WITH INDEX").toUpperCase())));
				reqMaster.setManHSortUnInternalAutoNError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						operationMap.get(("UNSORTED INTERNAL TABLE ACCESSED WITH INDEX").toUpperCase())));

			} else {
				reqMaster.setManHSortUnInternalAutoN(0);
				reqMaster.setManHSortUnInternalAutoNError(0);
			}

			if (operationMap.containsKey("Select Single without key fields".toUpperCase())) {
				reqMaster.setManHSortSelWKyAutoN(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						operationMap.get(("Select Single without key fields").toUpperCase())));
				reqMaster.setManHSortSelWKyAutoNError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						operationMap.get(("Select Single without key fields").toUpperCase())));

			} else {
				reqMaster.setManHSortSelWKyAutoN(0);
				reqMaster.setManHSortSelWKyAutoNError(0);
			}

			if (operationMap.containsKey("READ STATEMENT WITH BINARY AND WITHOUT SORTING".toUpperCase())) {
				reqMaster.setManHSortRBWSOAutoN(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						operationMap.get(("READ STATEMENT WITH BINARY AND WITHOUT SORTING").toUpperCase())));
				reqMaster.setManHSortRBWSOAutoNError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						operationMap.get(("READ STATEMENT WITH BINARY AND WITHOUT SORTING").toUpperCase())));

			} else {
				reqMaster.setManHSortRBWSOAutoN(0);
				reqMaster.setManHSortRBWSOAutoNError(0);
			}
			if (operationMap.containsKey("DELETE ADJACENT DUPLICATES IS USED WITHOUT SORTING".toUpperCase())) {
				reqMaster.setManHSortDelAdjAutoN(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						operationMap.get(("DELETE ADJACENT DUPLICATES IS USED WITHOUT SORTING").toUpperCase())));
				reqMaster.setManHSortDelAdjAutoNError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						operationMap.get(("DELETE ADJACENT DUPLICATES IS USED WITHOUT SORTING").toUpperCase())));

			} else {
				reqMaster.setManHSortDelAdjAutoN(0);
				reqMaster.setManHSortDelAdjAutoNError(0);
			}

			if (operationMap.containsKey(
					"Control statement inside loop (Only when loop is using internal table which is not sorted)"
							.toUpperCase())) {
				reqMaster.setManHSortConStmtAutoN(geUsedUnsedColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						operationMap.get(
								("Control statement inside loop (Only when loop is using internal table which is not sorted)")
										.toUpperCase())));
				reqMaster.setManHSortConStmtAutoNError(geUsedUnsedColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						operationMap.get(
								("Control statement inside loop (Only when loop is using internal table which is not sorted)")
										.toUpperCase())));

			} else {
				reqMaster.setManHSortConStmtAutoN(0);
				reqMaster.setManHSortConStmtAutoNError(0);
			}	
		} else {
			reqMaster.setManHSortUnInternalAutoN(0);
			reqMaster.setManHSortUnInternalAutoNError(0);
			reqMaster.setManHSortSelWKyAutoN(0);
			reqMaster.setManHSortSelWKyAutoNError(0);
			reqMaster.setManHSortRBWSOAutoN(0);
			reqMaster.setManHSortRBWSOAutoNError(0);
			reqMaster.setManHSortDelAdjAutoN(0);
			reqMaster.setManHSortDelAdjAutoNError(0);
			reqMaster.setManHSortConStmtAutoN(0);
			reqMaster.setManHSortConStmtAutoNError(0);	
		}
		//
		// Fields not being used are set as "zero" instead of null
		/*
		reqMaster.setObjectOutputManagement(0);
		reqMaster.setObjectCustomFields(0);
		reqMaster.setOptionalCount(0);
		reqMaster.setErrorRemediationOptional(0);
		reqMaster.setErrorUsedRemOptional(0);

		reqMaster.setObjectUsedCustomFields(0);
		reqMaster.setObjectUsedOutputMgmt(0);
		reqMaster.setOutputMgmtCustomFields(0);

		reqMaster.setOptionalUsedCount(0);

		reqMaster.setAcFinanceIntlTrade(0);
		reqMaster.setAcFinanceMisc(0);
		reqMaster.setAcFinanceCntrl(0);
		reqMaster.setAcMasterData(0);
		reqMaster.setAcIndustryRetail(0);
		reqMaster.setAcLogisticsMMIM(0);
		reqMaster.setAcProcurement(0);
		reqMaster.setAcLogisticsEHS(0);
		reqMaster.setAcSalesDistribution(0);
		reqMaster.setAcIndustryBeverage(0);
		reqMaster.setAcIndustryDimpEco(0);
		reqMaster.setAcFinanceGeneral(0);
		reqMaster.setAcLogisticsPP(0);
		reqMaster.setAcIndustryPubSec(0);
		reqMaster.setAcIndustryDimpHt(0);
		reqMaster.setAcIndustryCross(0);
		reqMaster.setAcIndustryAeroDef(0);
		reqMaster.setAcLogisticsPm(0);
		reqMaster.setAcLogisticsPlm(0);
		reqMaster.setAcIndustryAuto(0);
		reqMaster.setAcFinanceCashMgmt(0);
		reqMaster.setAcMiscellaneous(0);
		reqMaster.setAcMM(0);
		reqMaster.setAcLogisticsPS(0);
		reqMaster.setAcLogisticsATP(0);
		reqMaster.setAcIndustryMedia(0);
		reqMaster.setAcFinAssetAccount(0);
		reqMaster.setAcCrossTopics(0);
		reqMaster.setAcBatchMasterData(0);
		reqMaster.setAcLogisticsPss(0);
		reqMaster.setAcPortfolioPm(0);
		reqMaster.setAcFinGeneralLedger(0);
		reqMaster.setAcIndustryUtil(0);
		reqMaster.setAcGlobalLogistic(0);
		reqMaster.setAcIndustryOil(0);
		reqMaster.setAcLogisticQm(0);
		reqMaster.setAcFinAcctPayRecieve(0);
		reqMaster.setAcFinTreasury(0);
		reqMaster.setAcLogisticsGt(0);
		reqMaster.setAcHumanResources(0);

		reqMaster.setSimpCategoryCOEF(0);
		reqMaster.setSimpCategoryFEA(0);
		reqMaster.setSimpCategoryFENA(0);
		reqMaster.setSimpCategoryNsfFEA(0);
		reqMaster.setSimpCategoryNsfFENA(0);
		reqMaster.setSimpCategoryNewS4Fun(0);
		reqMaster.setManCompHigh(0);
		reqMaster.setManCompMedium(0);
		reqMaster.setManCompLow(0);
		reqMaster.setManCompTbd(0);
		reqMaster.setOptCompMedium(0);
		reqMaster.setOptCompLow(0);
		reqMaster.setOptCompVeryLow(0);
		reqMaster.setManCustomCd(0);
		reqMaster.setManDataElement(0);
		reqMaster.setManStatusTable(0);
		reqMaster.setManMatLength(0);
		reqMaster.setManDataModel(0);
		reqMaster.setManNewS4Fun(0);
		reqMaster.setManNewTrans(0);
		reqMaster.setManRemOrphan(0);
		reqMaster.setManRetiredFun(0);
		reqMaster.setManSimpExistTab(0);
		reqMaster.setManRepNewFun(0);
		reqMaster.setManFunEqvAvl(0);
		reqMaster.setManAdaptCustCd(0);
		reqMaster.setManCustFields(0);
		reqMaster.setManObsTrans(0);
		reqMaster.setManOutputMgmt(0);
		reqMaster.setOptCustomCd(0);
		reqMaster.setOptDataElement(0);
		reqMaster.setOptStatusTable(0);
		reqMaster.setOptMatLength(0);
		reqMaster.setOptDataModel(0);
		reqMaster.setOptNewS4Fun(0);
		reqMaster.setOptNewTrans(0);
		reqMaster.setOptRemOrphan(0);
		reqMaster.setOptRetiredFun(0);
		reqMaster.setOptSimpExistTab(0);
		reqMaster.setOptRepNewFun(0);
		reqMaster.setOptFunEqvAvl(0);
		reqMaster.setOptAdaptCustCd(0);
		reqMaster.setOptCustFields(0);
		reqMaster.setOptObsTrans(0);
		reqMaster.setOptOutputMgmt(0);
		reqMaster.setManCustomCdError(0);
		reqMaster.setManDataElementError(0);
		reqMaster.setManStatusTableError(0);
		reqMaster.setManMatLengthError(0);
		reqMaster.setManDataModelError(0);
		reqMaster.setManNewS4FunError(0);
		reqMaster.setManNewTransError(0);
		reqMaster.setManRemOrphanError(0);
		reqMaster.setManRetiredFunError(0);
		reqMaster.setManSimpExistTabError(0);
		reqMaster.setManRepNewFunError(0);
		reqMaster.setManFunEqvAvlError(0);
		reqMaster.setManAdaptCustCdError(0);
		reqMaster.setManCustFieldsError(0);
		reqMaster.setManObsTransError(0);
		reqMaster.setManOutputMgmtError(0);
		reqMaster.setOptCustomCdError(0);
		reqMaster.setOptDataElementError(0);
		reqMaster.setOptStatusTableError(0);
		reqMaster.setOptMatLengthError(0);
		reqMaster.setOptDataModelError(0);
		reqMaster.setOptNewS4FunError(0);
		reqMaster.setOptNewTransError(0);
		reqMaster.setOptRemOrphanError(0);
		reqMaster.setOptRetiredFunError(0);
		reqMaster.setOptSimpExistTabError(0);
		reqMaster.setOptRepNewFunError(0);
		reqMaster.setOptFunEqvAvlError(0);
		reqMaster.setOptAdaptCustCdError(0);
		reqMaster.setOptCustFieldsError(0);
		reqMaster.setOptObsTransError(0);
		reqMaster.setOptOutputMgmtError(0);

		reqMaster.setNewDataModelCnt(0);
		reqMaster.setMaterial_lengthExtension_cnt(0);
		reqMaster.setData_Element_lengthExtension_cnt(0);
		reqMaster.setEliminationOf_Status_Table_cnt(0);
		reqMaster.setRemovalOf_OrphenedObjects_cnt(0);
		reqMaster.setCustomCode_Adaption_cnt(0);
		reqMaster.setRetiredFunctionality_cnt(0);
		reqMaster.setNewS4Functionality_cnt(0);
		reqMaster.setReplacedByNewFunctionality_cnt(0);
		reqMaster.setNewTransaction_cnt(0);
		reqMaster.setFunctionalEquivalentAvailable_cnt(0);
		reqMaster.setSimplificationOfExistingTable_cnt(0);
		reqMaster.setNew_dataModel_Usedcnt(0);
		reqMaster.setMaterial_lengthExtension_Usedcnt(0);
		reqMaster.setData_Element_lengthExtension_Usedcnt(0);
		reqMaster.setEliminationOf_Status_Table_Usedcnt(0);
		reqMaster.setRemovalOf_OrphenedObjects_Usedcnt(0);
		reqMaster.setCustomCode_Adaption_Usedcnt(0);
		reqMaster.setRetiredFunctionality_Usedcnt(0);
		reqMaster.setNewS4Functionality_Usedcnt(0);
		reqMaster.setReplacedByNewFunctionality_Usedcnt(0);
		reqMaster.setNewTransaction_Usedcnt(0);
		reqMaster.setFunctionalEquivalentAvailable_Usedcnt(0);
		reqMaster.setSimplificationOfExistingTable_Usedcnt(0);
		reqMaster.setDefNewDataModel(0);
		reqMaster.setDefMaterialLengthExt(0);
		reqMaster.setDefDataElementlengthExt(0);
		reqMaster.setDefEliminationOfStatusTable(0);
		reqMaster.setDefRemovalOrphenObjects(0);
		reqMaster.setDefCustomCodeAdaption(0);
		reqMaster.setDefRetiredFunctionality(0);
		reqMaster.setDefNewS4Functionality(0);
		reqMaster.setDefReplacNewFunctionality(0);
		reqMaster.setDefNewTransaction(0);
		reqMaster.setDefFunctionalEqvAvailable(0);
		reqMaster.setDefSimplificationExistTable(0);
		reqMaster.setDefNewDataModelUsed(0);
		reqMaster.setDefMaterialLengthExtUsed(0);
		reqMaster.setDefDataElementlengthExtUsed(0);
		reqMaster.setDefEliminationOfStatusTableUsed(0);
		reqMaster.setDefRemovalOrphenObjectsUsed(0);
		reqMaster.setDefCustomCodeAdaptionUsed(0);
		reqMaster.setDefRetiredFunctionalityUsed(0);
		reqMaster.setDefNewS4FunctionalityUsed(0);
		reqMaster.setDefReplacNewFunctionalityUsed(0);
		reqMaster.setDefNewTransactionUsed(0);
		reqMaster.setDefFunctionalEqvAvailableUsed(0);
		reqMaster.setDefSimplificationExistTableUsed(0);*/

		Session session = sessionFactory.openSession();
		try {
			session.saveOrUpdate(reqMaster);
			session.close();
		} catch (Exception e) {
			e.getMessage();
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		logger.info("processing completed for updateRequestMaster  !!!!!!!!!!!!!!!!! ");
	}
	// CR-12.3 End

	private List<RequestForm> getReqForm(long requestId) {

		session = sessionFactory.openSession();

		try {
			final Criteria criteria = session.createCriteria(RequestForm.class);
			criteria.add(Restrictions.eq("requestID", requestId));
			return criteria.list();
		} catch (Exception e) {
			logger.error("Error DisplayGraphDaoImpl getReqForm " , e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);

		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	private List<RequestInventory> getReqInventory(long requestId) {

		session = sessionFactory.openSession();

		try {
			final Criteria criteria = session.createCriteria(RequestInventory.class);
			criteria.add(Restrictions.eq("requestID", requestId));
			return criteria.list();
		} catch (Exception e) {
			logger.error("Error DisplayGraphDaoImpl getReqInventory " , e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);

		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

	/*
	 * @Override public Map<String, String> getHighMediumLow_DefectObjectCount(Long
	 * requestId, String ObjectType) { // TODO Auto-generated method stub
	 * 
	 * Map<String,String> retrunResult = new HashMap(); Map<String,String> resultMap
	 * = new HashMap(); session = sessionFactory.openSession();
	 * 
	 * if(ObjectType.equals("FUGR")){ hql =
	 * "select Obj_Name, count(*) from final_output where Request_ID="+requestId+
	 * " and Category In ('Mandatory','Recommended Corrections') and Obj_Name LIKE 'SAPL%' GROUP BY Obj_Name"
	 * ; } else{ hql =
	 * "select Obj_Name, count(*) from final_output where Request_ID="+requestId+
	 * " and Category In ('Mandatory','Recommended Corrections') and Object_Type= '"
	 * +ObjectType+"'  GROUP BY Obj_Name"; }
	 * 
	 * List<List<Object>> resultList =
	 * session.createSQLQuery(hql).setResultTransformer(Transformers.TO_LIST).list()
	 * ; if(!resultList.isEmpty()){ for(List<Object> x: resultList){
	 * resultMap.put((String)x.get(0).toString(),(String) x.get(1).toString()); } }
	 * retrunResult = calculateHeighMediumLow(resultMap); session.close(); return
	 * retrunResult; }
	 */
	// CR-12.3 Start
	@Override
	public Map<String, Integer> getYearCount(String ig, String status, String toolName) {
		final Map<String, Integer> resultMap = new LinkedHashMap<String, Integer>();
		session = sessionFactory.openSession();
		if (StringUtils.isEmpty(ig)) {
			hql = "select year(updatedDate), count(*) from ProcessedRequestDetail where requestStatus = :requestStatus and toolName = :tool group by year(updatedDate)";
		} else {
			hql = "select year(updatedDate), count(*) from ProcessedRequestDetail where requestStatus = :requestStatus and industryGroup = :ig and toolName = :tool group by year(updatedDate)";
		}
		Query query = session.createQuery(hql);
		query.setParameter("requestStatus", status);
		if (!(StringUtils.isEmpty(ig))) {
			query.setParameter("ig", ig);
		}
		query.setParameter("tool", toolName);
		List<Object[]> resultList = query.list();
		if (CollectionUtils.isNotEmpty(resultList)) {
			for (Object[] object : resultList) {
				resultMap.put(String.valueOf(object[0]), ((Long) object[1]).intValue());
			}
		}
		session.close();
		return resultMap;
	}

	@Override
	public Map<String, Integer> getMonthCount(String ig, String status, String toolName) {
		final Map<String, Integer> resultMap = new LinkedHashMap<String, Integer>();
		long millis = System.currentTimeMillis();
		Date currDate = new Date(millis);
		String strDate = currDate.toString();
		String[] strArr = strDate.split("-");
		String currYear = strArr[0];
		String currMonth = strArr[1];
		String startDate;
		String startYear;
		String startMonth = "09";
		String startDay = "01";
		if (currMonth.equals("09") || currMonth.equals("10") || currMonth.equals("11") || currMonth.equals("12")) {
			startYear = currYear;
		} else {
			int numYear = Integer.parseInt(currYear);
			numYear--;
			startYear = String.valueOf(numYear);
		}
		startDate = startYear + "-" + startMonth + "-" + startDay;
		Date stDate = Date.valueOf(startDate);
		session = sessionFactory.openSession();
		if (StringUtils.isEmpty(ig)) {
			hql = "select updatedDate, count(*) from ProcessedRequestDetail where requestStatus = :requestStatus and updatedDate >= :startDate and updatedDate <= :endDate and toolName = :tool group by month(updatedDate) order by updatedDate";
		} else {
			hql = "select updatedDate, count(*) from ProcessedRequestDetail where requestStatus = :requestStatus and updatedDate >= :startDate and updatedDate <= :endDate and industryGroup = :ig and toolName = :tool group by month(updatedDate) order by updatedDate";
		}
		Query query = session.createQuery(hql);
		query.setParameter("requestStatus", status);
		if (!(StringUtils.isEmpty(ig))) {
			query.setParameter("ig", ig);
		}
		query.setParameter("tool", toolName);
		query.setParameter("startDate", stDate);
		query.setParameter("endDate", currDate);
		List<Object[]> resultList = query.list();
		if (CollectionUtils.isNotEmpty(resultList)) {
			SimpleDateFormat dispFormat = new SimpleDateFormat("MMM yyyy");
			for (Object[] object : resultList) {
				resultMap.put(dispFormat.format(object[0]), ((Long) object[1]).intValue());
			}
		}
		session.close();
		return resultMap;
	}

	@Override
	public Map<String, Integer> getQuarterCount(String ig, String status, String toolName) {
		final Map<String, Integer> resultMap = new LinkedHashMap<String, Integer>();
		long millis = System.currentTimeMillis();
		Date currDate = new Date(millis);
		String strDate = currDate.toString();
		String[] strArr = strDate.split("-");
		String currYear = strArr[0];
		String currMonth = strArr[1];
		String startDate;
		String startYear;
		String startMonth;
		String startDay = "01";
		if (currMonth.equals("09") || currMonth.equals("10") || currMonth.equals("11")) {
			startYear = currYear;
			startMonth = "09";
		} else if (currMonth.equals("12") || currMonth.equals("01") || currMonth.equals("02")) {
			if (currMonth.equals("12")) {
				startYear = currYear;
			} else {
				int numYear = Integer.parseInt(currYear);
				numYear--;
				startYear = String.valueOf(numYear);
			}
			startMonth = "12";
		} else if (currMonth.equals("03") || currMonth.equals("04") || currMonth.equals("05")) {
			startYear = currYear;
			startMonth = "03";
		} else {
			startYear = currYear;
			startMonth = "06";
		}
		startDate = startYear + "-" + startMonth + "-" + startDay;
		Date stDate = Date.valueOf(startDate);
		session = sessionFactory.openSession();
		if (StringUtils.isEmpty(ig)) {
			hql = "select updatedDate, count(*) from ProcessedRequestDetail where requestStatus = :requestStatus and updatedDate >= :startDate and updatedDate <= :endDate and toolName = :tool group by month(updatedDate) order by updatedDate";
		} else {
			hql = "select updatedDate, count(*) from ProcessedRequestDetail where requestStatus = :requestStatus and updatedDate >= :startDate and updatedDate <= :endDate and industryGroup = :ig and toolName = :tool group by month(updatedDate) order by updatedDate";
		}
		Query query = session.createQuery(hql);
		query.setParameter("requestStatus", status);
		query.setParameter("startDate", stDate);
		query.setParameter("endDate", currDate);
		if (!(StringUtils.isEmpty(ig))) {
			query.setParameter("ig", ig);
		}
		query.setParameter("tool", toolName);

		List<Object[]> resultList = query.list();
		if (CollectionUtils.isNotEmpty(resultList)) {
			SimpleDateFormat dispFormat = new SimpleDateFormat("MMM yyyy");
			for (Object[] object : resultList) {
				resultMap.put(dispFormat.format(object[0]), ((Long) object[1]).intValue());
			}
		}
		session.close();
		return resultMap;
	}

	@Override
	public Map<String, Integer> getDayCount(String ig, String status, String toolName) {
		final Map<String, Integer> resultMap = new LinkedHashMap<String, Integer>();
		long millis = System.currentTimeMillis();
		Date currDate = new Date(millis);
		String strDate = currDate.toString();
		String[] strArr = strDate.split("-");
		String currYear = strArr[0];
		String currMonth = strArr[1];
		String startDate;
		String startYear;
		String startMonth;
		String startDay = "01";
		startYear = currYear;
		startMonth = currMonth;
		startDate = startYear + "-" + startMonth + "-" + startDay;
		Date stDate = Date.valueOf(startDate);
		session = sessionFactory.openSession();
		if (StringUtils.isEmpty(ig)) {
			hql = "select updatedDate, count(*) from ProcessedRequestDetail where requestStatus = :requestStatus and updatedDate >= :startDate and updatedDate <= :endDate and toolName = :tool group by dayofmonth(updatedDate)";
		} else {
			hql = "select updatedDate, count(*) from ProcessedRequestDetail where requestStatus = :requestStatus and updatedDate >= :startDate and updatedDate <= :endDate and industryGroup = :ig and toolName = :tool group by dayofmonth(updatedDate)";
		}
		Query query = session.createQuery(hql);
		query.setParameter("requestStatus", status);
		query.setParameter("startDate", stDate);
		query.setParameter("endDate", currDate);
		query.setParameter("tool", toolName);
		if (!(StringUtils.isEmpty(ig))) {
			query.setParameter("ig", ig);
		}
		List<Object[]> resultList = query.list();
		if (CollectionUtils.isNotEmpty(resultList)) {
			SimpleDateFormat dispFormat = new SimpleDateFormat("d MMM");
			for (Object[] object : resultList) {
				resultMap.put(dispFormat.format(object[0]), ((Long) object[1]).intValue());
			}
		}
		session.close();
		return resultMap;
	}

	@Override
	public Map<String, Integer> getIgCount(String status, String toolName) {
		final Map<String, Integer> resultMap = new LinkedHashMap<String, Integer>();
		session = sessionFactory.openSession();
		hql = "select industryGroup, count(*) from ProcessedRequestDetail where requestStatus = :requestStatus and toolName = :tool group by industryGroup order by industryGroup";
		Query query = session.createQuery(hql);
		query.setParameter("requestStatus", status);
		query.setParameter("tool", toolName);
		List<Object[]> resultList = query.list();
		if (CollectionUtils.isNotEmpty(resultList)) {
			for (Object[] object : resultList) {
				resultMap.put((String) object[0], ((Long) object[1]).intValue());
			}
		}
		session.close();
		return resultMap;
	}

	// CR-68
	@Override
	public void updateRequestMasterEstimations(long requestId) {

		RequestInventory reqInventory = getReqInventory(requestId).get(0);

		long date = reqInventory.getUpdatedDate();
		Date sqlDate = new Date(date);

		String toolName = (String) reqInventory.getToolName();
		Query query = null;

		if ("hana".equalsIgnoreCase(toolName)) {

			HanaEstimator hanaestimator = getHanaEstimatorObjects(requestId).get(0);

			String hql = "update ProcessedRequestDetail set DefectUsedClasCount = :DefectUsedClasCount,"
					+ "DefectUsedProgCount = :DefectUsedProgCount,DefectUsedFugrCount = :DefectUsedFugrCount,"
					+ "DefectUsedLsmwCount = :DefectUsedLsmwCount,DefectUsedWebCount = :DefectUsedWebCount,"
					+ "DefectUsedEnhanCount = :DefectUsedEnhanCount,DefectUsedFormCount = :DefectUsedFormCount,"
					+ "DefectUsedExitCount = :DefectUsedExitCount,CustUsedFormCount = :CustUsedFormCount,"
					+ "CustUsedExitCount = :CustUsedExitCount,CustUsedClasCount = :CustUsedClasCount,"
					+ "CustUsedProgCount = :CustUsedProgCount,"
					+ "CustUsedLsmwCount = :CustUsedLsmwCount,CustUsedWebCount = :CustUsedWebCount,"
					+ "CustUsedFugrCount = :CustUsedFugrCount,CustUsedEnhanCount = :CustUsedEnhanCount,"
					+ "Migration_Fix_Effort_Manual_Fixing_Count = :Migration_Fix_Effort_Manual_Fixing_Count, "
					+ "Used_Migration_Fix_Effort_Manual_Fixing_Count = :Used_Migration_Fix_Effort_Manual_Fixing_Count, "
					+ "DefectExitCount = :DefectExitCount, DefectFormCount = :DefectFormCount, DefectWebCount = :DefectWebCount, "
					+ "DefectEnhanCount = :DefectEnhanCount, DefectLsmwCount = :DefectLsmwCount, CustEnhanCount = :CustEnhanCount, CustWebCount = :CustWebCount, "
					+ "CustLsmwCount = :CustLsmwCount, CustExitCount = :CustExitCount, CustFugrCount = :CustFugrCount, CustProgCount = :CustProgCount, "
					+ "CustClasCount = :CustClasCount, CustFormCount = :CustFormCount,  DefectClasCount = :DefectClasCount, DefectFugrCount = :DefectFugrCount, "
					+ "DefectProgCount = :DefectProgCount, migrationManualCount = :migrationManualCount, migrationAutomatedCount = :migrationAutomatedCount, "
					+ "defectCount = :defectCount, updatedDate = :updatedDate, requestStatus = :requestStatus where requestID = :requestId";

			Session session = sessionFactory.openSession();
			try {
				// Session session=sessionFactory.openSession();
				query = session.createQuery(hql);
				// CR:56-Adding New Estimation sheet
				query.setParameter("DefectUsedClasCount", hanaestimator.getDefectUsedClasCount());
				query.setParameter("DefectUsedProgCount", hanaestimator.getDefectUsedProgCount());
				query.setParameter("DefectUsedFugrCount", hanaestimator.getDefectUsedFugrCount());
				query.setParameter("DefectUsedLsmwCount", hanaestimator.getDefectUsedLsmwCount());
				query.setParameter("DefectUsedWebCount", hanaestimator.getDefectUsedWebCount());
				query.setParameter("DefectUsedEnhanCount", hanaestimator.getDefectUsedEnhanCount());
				query.setParameter("DefectUsedFormCount", hanaestimator.getDefectUsedFormCount());
				query.setParameter("DefectUsedExitCount", hanaestimator.getDefectUsedExitCount());
				query.setParameter("CustUsedFormCount", hanaestimator.getCustUsedFormCount());
				query.setParameter("CustUsedExitCount", hanaestimator.getCustUsedExitCount());
				query.setParameter("CustUsedClasCount", hanaestimator.getCustUsedClasCount());
				query.setParameter("CustUsedProgCount", hanaestimator.getCustUsedProgCount());
				query.setParameter("CustUsedLsmwCount", hanaestimator.getCustUsedLsmwCount());
				query.setParameter("CustUsedWebCount", hanaestimator.getCustUsedWebCount());
				query.setParameter("CustUsedFugrCount", hanaestimator.getCustUsedFugrCount());
				query.setParameter("CustUsedEnhanCount", hanaestimator.getCustUsedEnhanCount());
				query.setParameter("Migration_Fix_Effort_Manual_Fixing_Count",
						hanaestimator.getMigration_Fix_Effort_Manual_Fixing_Count());
				query.setParameter("Used_Migration_Fix_Effort_Manual_Fixing_Count",
						hanaestimator.getUsed_Migration_Fix_Effort_Manual_Fixing_Count());
				query.setParameter("DefectLsmwCount", hanaestimator.getDefectLsmwCount());
				query.setParameter("DefectWebCount", hanaestimator.getDefectWebCount());
				query.setParameter("DefectEnhanCount", hanaestimator.getDefectEnhanCount());
				query.setParameter("DefectFormCount", hanaestimator.getDefectFormCount());
				query.setParameter("DefectExitCount", hanaestimator.getDefectExitCount());
				query.setParameter("CustLsmwCount", hanaestimator.getCustLsmwCount());
				query.setParameter("CustWebCount", hanaestimator.getCustWebCount());
				query.setParameter("CustEnhanCount", hanaestimator.getCustEnhanCount());
				query.setParameter("CustExitCount", hanaestimator.getCustExitCount());

				query.setParameter("CustFugrCount", hanaestimator.getCustFugrCount());
				query.setParameter("CustProgCount", hanaestimator.getCustProgCount());
				query.setParameter("CustClasCount", hanaestimator.getCustClasCount());
				query.setParameter("CustFormCount", hanaestimator.getCustFormCount());
				query.setParameter("DefectClasCount", hanaestimator.getDefectClasCount());
				query.setParameter("DefectFugrCount", hanaestimator.getDefectFugrCount());
				query.setParameter("DefectProgCount", hanaestimator.getDefectProgCount());
				query.setParameter("migrationManualCount", hanaestimator.getMigrationManualCount());
				query.setParameter("migrationAutomatedCount", hanaestimator.getMigrationAutomatedCount());
				query.setParameter("defectCount", hanaestimator.getDefectCount());
				query.setParameter("updatedDate", sqlDate);
				query.setParameter("requestStatus", reqInventory.getRequestStatus());
				query.setParameter("requestId", requestId);
				query.executeUpdate();
				session.close();
			} catch (Exception e) {
				e.getMessage();
				throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
			}
		} else if ("s4".equalsIgnoreCase(toolName)) {

			String Date = new SimpleDateFormat("yyyy-MM-dd").format(new Date(reqInventory.getUpdatedDate()));

			S4Estimations S4Estimatior = getS4EstimatorObjects(requestId).get(0);

			String hql = "update Request_Master set Optional_Used_Analysis_Efforts_High = :OptionalUsedAnalysisEffortsHigh, "
					+ "Optional_Used_Design_Efforts_High = :OptionalUsedDesignEffortsHigh, Optional_Used_Build_Efforts_High = :OptionalUsedBuildEffortsHigh,"
					+ "Optional_Used_Unit_Testing_High = :OptionalUsedUnitTestingHigh, Optional_Used_Effort_Remediate_Custom_High = :OptionalUsedEffortRemediateCustomHigh,"
					+ "Optional_Used_SPDD_SPAU_Efforts_High = :OptionalUsedSPDD_SPAU_EffortsHigh, Optional_Analysis_Efforts_High = :OptionalAnalysisEffortsHigh,"
					+ "Optional_Design_Efforts_High = :OptionalDesignEffortsHigh, Optional_Build_Efforts_High = :OptionalBuildEffortsHigh,"
					+ "Optional_Unit_Testing_High = :OptionalUnitTestingHigh, Optional_Effort_Remediate_Custom_High = :OptionalEffortRemediateCustomHigh,"
					+ "Optional_SPDD_SPAU_Efforts_High = :OptionalSPDD_SPAU_EffortsHigh, Mandatory_Used_Analysis_Efforts_High = :MandatoryUsedAnalysisEffortsHigh,"
					+ "Mandatory_Used_Design_Efforts_High = :MandatoryUsedDesignEffortsHigh, Mandatory_Used_Build_Efforts_High = :MandatoryUsedBuildEffortsHigh,"
					+ "Mandatory_Used_Unit_Testing_High = :MandatoryUsedUnitTestingHigh, Mandatory_Used_Effort_Remediate_Custom_High = :MandatoryUsedEffortRemediateCustomHigh,"
					+ "Mandatory_Used_SPDD_SPAU_Efforts_High = :MandatoryUsedSPDD_SPAU_EffortsHigh, Mandatory_Analysis_Efforts_High = :MandatoryAnalysisEffortsHigh,"
					+ "Mandatory_Design_Efforts_High = :MandatoryDesignEffortsHigh, Mandatory_Build_Efforts_High = :MandatoryBuildEffortsHigh,"
					+ "Mandatory_Unit_Testing_High = :MandatoryUnitTestingHigh, Mandatory_Effort_Remediate_Custom_High = :MandatoryEffortRemediateCustomHigh,"
					+ "Mandatory_SPDD_SPAU_Efforts_High = :MandatorySPDD_SPAU_EffortsHigh, Optional_Used_Analysis_Efforts_Low = :OptionalUsedAnalysisEffortsLow,"
					+ "Optional_Used_Design_Efforts_Low = :OptionalUsedDesignEffortsLow, Optional_Used_Build_Efforts_Low = :OptionalUsedBuildEffortsLow,"
					+ "Optional_Used_Unit_Testing_Low = :OptionalUsedUnitTestingLow, Optional_Used_Effort_Remediate_Custom_Low = :OptionalUsedEffortRemediateCustomLow,"
					+ "Optional_Used_SPDD_SPAU_Efforts_Low = :OptionalUsedSPDD_SPAU_EffortsLow, Optional_Analysis_Efforts_Low = :OptionalAnalysisEffortsLow,"
					+ "Optional_Design_Efforts_Low = :OptionalDesignEffortsLow, Optional_Build_Efforts_Low = :OptionalBuildEffortsLow,"
					+ "Optional_Unit_Testing_Low = :OptionalUnitTestingLow, Optional_Effort_Remediate_Custom_Low = :OptionalEffortRemediateCustomLow,"
					+ "Optional_SPDD_SPAU_Efforts_Low = :OptionalSPDD_SPAU_EffortsLow, Mandatory_Used_Analysis_Efforts_Low = :MandatoryUsedAnalysisEffortsLow,"
					+ "Mandatory_Used_Design_Efforts_Low = :MandatoryUsedDesignEffortsLow, Mandatory_Used_Build_Efforts_Low = :MandatoryUsedBuildEffortsLow,"
					+ "Mandatory_Used_Unit_Testing_Low = :MandatoryUsedUnitTestingLow, Mandatory_Used_Effort_Remediate_Custom_Low = :MandatoryUsedEffortRemediateCustomLow,"
					+ "Mandatory_Used_SPDD_SPAU_Efforts_Low = :MandatoryUsedSPDD_SPAU_EffortsLow, Mandatory_Analysis_Efforts_Low = :MandatoryAnalysisEffortsLow,"
					+ "Mandatory_Design_Efforts_Low = :MandatoryDesignEffortsLow, Mandatory_Build_Efforts_Low = :MandatoryBuildEffortsLow,"
					+ "Mandatory_Unit_Testing_Low = :MandatoryUnitTestingLow, Mandatory_Effort_Remediate_Custom_Low = :MandatoryEffortRemediateCustomLow,"
					+ "Mandatory_SPDD_SPAU_Efforts_Low = :MandatorySPDD_SPAU_EffortsLow,"
					+ "UPDATED_DATE = :updatedDate," + "REQUEST_STATUS = :requestStatus " + "where Request_ID ="
					+ requestId + "";

			/* Session session = sessionFactory.openSession(); */
			try {
				Session session = sessionFactory.openSession();
				Query query1 = session.createSQLQuery(hql);

				query1.setParameter("MandatoryAnalysisEffortsHigh", S4Estimatior.getMandatoryAnalysisEffortsHigh());
				query1.setParameter("MandatoryDesignEffortsHigh", S4Estimatior.getMandatoryDesignEffortsHigh());
				query1.setParameter("MandatoryBuildEffortsHigh", S4Estimatior.getMandatoryBuildEffortsHigh());
				query1.setParameter("MandatoryUnitTestingHigh", S4Estimatior.getMandatoryUnitTestingHigh());
				query1.setParameter("MandatoryEffortRemediateCustomHigh",
						S4Estimatior.getMandatoryEffortRemediateCustomHigh());
				query1.setParameter("MandatorySPDD_SPAU_EffortsHigh", S4Estimatior.getMandatorySPDD_SPAU_EffortsHigh());

				query1.setParameter("MandatoryAnalysisEffortsLow", S4Estimatior.getMandatoryAnalysisEffortsLow());
				query1.setParameter("MandatoryDesignEffortsLow", S4Estimatior.getMandatoryDesignEffortsLow());
				query1.setParameter("MandatoryBuildEffortsLow", S4Estimatior.getMandatoryBuildEffortsLow());
				query1.setParameter("MandatoryUnitTestingLow", S4Estimatior.getMandatoryUnitTestingLow());
				query1.setParameter("MandatoryEffortRemediateCustomLow",
						S4Estimatior.getMandatoryEffortRemediateCustomLow());
				query1.setParameter("MandatorySPDD_SPAU_EffortsLow", S4Estimatior.getMandatorySPDD_SPAU_EffortsLow());

				query1.setParameter("MandatoryUsedAnalysisEffortsHigh",
						S4Estimatior.getMandatoryUsedAnalysisEffortsHigh());
				query1.setParameter("MandatoryUsedDesignEffortsHigh", S4Estimatior.getMandatoryUsedDesignEffortsHigh());
				query1.setParameter("MandatoryUsedBuildEffortsHigh", S4Estimatior.getMandatoryUsedBuildEffortsHigh());
				query1.setParameter("MandatoryUsedUnitTestingHigh", S4Estimatior.getMandatoryUsedUnitTestingHigh());
				query1.setParameter("MandatoryUsedEffortRemediateCustomHigh",
						S4Estimatior.getMandatoryUsedEffortRemediateCustomHigh());
				query1.setParameter("MandatoryUsedSPDD_SPAU_EffortsHigh",
						S4Estimatior.getMandatoryUsedSPDD_SPAU_EffortsHigh());

				query1.setParameter("MandatoryUsedAnalysisEffortsLow",
						S4Estimatior.getMandatoryUsedAnalysisEffortsLow());
				query1.setParameter("MandatoryUsedDesignEffortsLow", S4Estimatior.getMandatoryUsedDesignEffortsLow());
				query1.setParameter("MandatoryUsedBuildEffortsLow", S4Estimatior.getMandatoryUsedBuildEffortsLow());
				query1.setParameter("MandatoryUsedUnitTestingLow", S4Estimatior.getMandatoryUsedUnitTestingLow());
				query1.setParameter("MandatoryUsedEffortRemediateCustomLow",
						S4Estimatior.getMandatoryUsedEffortRemediateCustomLow());
				query1.setParameter("MandatoryUsedSPDD_SPAU_EffortsLow",
						S4Estimatior.getMandatoryUsedSPDD_SPAU_EffortsLow());

				query1.setParameter("OptionalAnalysisEffortsHigh", S4Estimatior.getOptionalAnalysisEffortsHigh());
				query1.setParameter("OptionalDesignEffortsHigh", S4Estimatior.getOptionalDesignEffortsHigh());
				query1.setParameter("OptionalBuildEffortsHigh", S4Estimatior.getOptionalBuildEffortsHigh());
				query1.setParameter("OptionalUnitTestingHigh", S4Estimatior.getOptionalUnitTestingHigh());
				query1.setParameter("OptionalEffortRemediateCustomHigh",
						S4Estimatior.getOptionalEffortRemediateCustomHigh());
				query1.setParameter("OptionalSPDD_SPAU_EffortsHigh", S4Estimatior.getOptionalSPDD_SPAU_EffortsHigh());

				query1.setParameter("OptionalAnalysisEffortsLow", S4Estimatior.getOptionalAnalysisEffortsLow());
				query1.setParameter("OptionalDesignEffortsLow", S4Estimatior.getOptionalDesignEffortsLow());
				query1.setParameter("OptionalBuildEffortsLow", S4Estimatior.getOptionalBuildEffortsLow());
				query1.setParameter("OptionalUnitTestingLow", S4Estimatior.getOptionalUnitTestingLow());
				query1.setParameter("OptionalEffortRemediateCustomLow",
						S4Estimatior.getOptionalEffortRemediateCustomLow());
				query1.setParameter("OptionalSPDD_SPAU_EffortsLow", S4Estimatior.getOptionalSPDD_SPAU_EffortsLow());

				query1.setParameter("OptionalUsedAnalysisEffortsHigh",
						S4Estimatior.getOptionalUsedAnalysisEffortsHigh());
				query1.setParameter("OptionalUsedDesignEffortsHigh", S4Estimatior.getOptionalUsedDesignEffortsHigh());
				query1.setParameter("OptionalUsedBuildEffortsHigh", S4Estimatior.getOptionalUsedBuildEffortsHigh());
				query1.setParameter("OptionalUsedUnitTestingHigh", S4Estimatior.getOptionalUsedUnitTestingHigh());
				query1.setParameter("OptionalUsedEffortRemediateCustomHigh",
						S4Estimatior.getOptionalUsedEffortRemediateCustomHigh());
				query1.setParameter("OptionalUsedSPDD_SPAU_EffortsHigh",
						S4Estimatior.getOptionalUsedSPDD_SPAU_EffortsHigh());

				query1.setParameter("OptionalUsedAnalysisEffortsLow", S4Estimatior.getOptionalUsedAnalysisEffortsLow());
				query1.setParameter("OptionalUsedDesignEffortsLow", S4Estimatior.getOptionalUsedDesignEffortsLow());
				query1.setParameter("OptionalUsedBuildEffortsLow", S4Estimatior.getOptionalUsedBuildEffortsLow());
				query1.setParameter("OptionalUsedUnitTestingLow", S4Estimatior.getOptionalUsedUnitTestingLow());
				query1.setParameter("OptionalUsedEffortRemediateCustomLow",
						S4Estimatior.getOptionalUsedEffortRemediateCustomLow());
				query1.setParameter("OptionalUsedSPDD_SPAU_EffortsLow",
						S4Estimatior.getOptionalUsedSPDD_SPAU_EffortsLow());

				query1.setParameter("updatedDate", Date);
				query1.setParameter("requestStatus", reqInventory.getRequestStatus());
				query1.executeUpdate();

				session.close();
			} catch (Exception e) {
				e.getMessage();
				throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
			}

		} else {

			// ADD update Logic for Consolidation tool

		}

	}

	// CR-52.0 AIES Tool Integration
	@Override
	public List<ProcessedRequestDetail> getReqMaster(long requestId) {

		session = sessionFactory.openSession();

		try {
			final Criteria criteria = session.createCriteria(ProcessedRequestDetail.class);
			criteria.add(Restrictions.eq("requestID", requestId));
			return criteria.list();
		} catch (Exception e) {
			logger.error("Error DisplayGraphDaoImpl getReqMaster " , e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);

		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	@Override
	public List<TestingScope> getTestingReqMaster(long requestId) {

		session = sessionFactory.openSession();

		try {
			final Criteria criteria = session.createCriteria(TestingScope.class);
			criteria.add(Restrictions.eq("requestID", requestId));
			return criteria.list();
		} catch (Exception e) {
			logger.error("Error DisplayGraphDaoImpl getTestingReqMaster" , e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);

		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	@Override
	public List<ImpactedBackgroundCounts> getImpactedBackgroundCounts(long requestId) {

		session = sessionFactory.openSession();

		try {
			final Criteria criteria = session.createCriteria(ImpactedBackgroundCounts.class);
			criteria.add(Restrictions.eq("requestID", requestId));
			return criteria.list();
		} catch (Exception e) {
			logger.error("Error DisplayGraphDaoImpl getImpactedBackgroundCounts" , e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);

		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	@Override
	public List<FioriRequestMaster> getFioriRequestMaster(long requestId) {

		session = sessionFactory.openSession();

		try {
			final Criteria criteria = session.createCriteria(FioriRequestMaster.class);
			criteria.add(Restrictions.eq("requestID", requestId));
			return criteria.list();
		} catch (Exception e) {
			logger.error("Error DisplayGraphDaoImpl getFioriRequestMaster " , e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);

		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	
	@Override
	public List<UI5GraphCounts> getUI5Master(long requestId) {

		session = sessionFactory.openSession();

		try {
			final Criteria criteria = session.createCriteria(UI5GraphCounts.class);
			criteria.add(Restrictions.eq("REQUEST_ID", requestId));
			return criteria.list();
		} catch (Exception e) {
			logger.error("Error DisplayGraphDaoImpl getUI5Master " , e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);

		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	// CR-57
	@Override
	public Map<String, Integer> getYearCountGraph(String ig, String status, String toolName, String dealType,
			String unicode, String source, String target) {
		final Map<String, Integer> resultMap = new LinkedHashMap<String, Integer>();
		session = sessionFactory.openSession();

		String queryfinal = "select year(updatedDate), count(*) from ProcessedRequestDetail where ";
		String queryEnd = "group by year(updatedDate)";
		if (!StringUtils.isEmpty(toolName)) {
			queryfinal = queryfinal + "toolName = :tool ";
		}
		if (!StringUtils.isEmpty(unicode)) {
			queryfinal = queryfinal + "and enableUnicode = :unicode ";
		}
		if (!StringUtils.isEmpty(ig)) {
			queryfinal = queryfinal + "and industryGroup = :ig ";
		}
		if (!StringUtils.isEmpty(status)) {
			queryfinal = queryfinal + "and requestStatus = :requestStatus ";
		}
		if (!StringUtils.isEmpty(dealType)) {
			queryfinal = queryfinal + "and kindOfDeal = :dealType ";
		}
		if (!StringUtils.isEmpty(source)) {
			queryfinal = queryfinal + "and sourceVersion = :source ";
		}
		if (!StringUtils.isEmpty(target)) {
			queryfinal = queryfinal + "and targetVersion = :target ";
		}

		queryfinal = queryfinal + queryEnd;
		hql = queryfinal;
		if (StringUtils.isEmpty(ig) && StringUtils.isEmpty(dealType) && StringUtils.isEmpty(status)
				&& StringUtils.isEmpty(unicode) && StringUtils.isEmpty(source) && StringUtils.isEmpty(target)) {
			hql = "select year(updatedDate), count(*) from ProcessedRequestDetail where toolName = :tool group by year(updatedDate)";
		}
		Query query = session.createQuery(hql);
		if (!(StringUtils.isEmpty(status))) {
			query.setParameter("requestStatus", status);
		}
		if (!(StringUtils.isEmpty(unicode))) {
			query.setParameter("unicode", unicode);
		}

		if (!(StringUtils.isEmpty(dealType))) {
			query.setParameter("dealType", dealType);
		}
		if (!(StringUtils.isEmpty(ig))) {
			query.setParameter("ig", ig);
		}
		if (!(StringUtils.isEmpty(source))) {
			query.setParameter("source", source);
		}
		if (!(StringUtils.isEmpty(target))) {
			query.setParameter("target", target);
		}

		query.setParameter("tool", toolName);
		List<Object[]> resultList = query.list();
		if (CollectionUtils.isNotEmpty(resultList)) {
			for (Object[] object : resultList) {
				resultMap.put(String.valueOf(object[0]), ((Long) object[1]).intValue());
			}
		}
		session.close();
		return resultMap;
	}

	// CR-57
	@Override
	public Map<String, Integer> getMonthCountGraph(String ig, String status, String toolName, String dealtype,
			String unicode, String Source, String target) {
		final Map<String, Integer> resultMap = new LinkedHashMap<String, Integer>();
		long millis = System.currentTimeMillis();
		Date currDate = new Date(millis);
		String strDate = currDate.toString();
		String[] strArr = strDate.split("-");
		String currYear = strArr[0];
		String currMonth = strArr[1];
		String startDate;
		String startYear;
		String startMonth = "09";
		String startDay = "01";
		if (currMonth.equals("09") || currMonth.equals("10") || currMonth.equals("11") || currMonth.equals("12")) {
			startYear = currYear;
		} else {
			int numYear = Integer.parseInt(currYear);
			numYear--;
			startYear = String.valueOf(numYear);
		}
		startDate = startYear + "-" + startMonth + "-" + startDay;
		Date stDate = Date.valueOf(startDate);
		session = sessionFactory.openSession();
		if (StringUtils.isEmpty(ig) && StringUtils.isEmpty(dealtype) && StringUtils.isEmpty(status)
				&& StringUtils.isEmpty(unicode) && StringUtils.isEmpty(Source) && StringUtils.isEmpty(target)) {
			hql = "select updatedDate, count(*) from ProcessedRequestDetail where updatedDate >= :startDate and updatedDate <= :endDate and toolName = :tool group by month(updatedDate) order by updatedDate";
		} else {
			String queryfinal = "select updatedDate, count(*) from ProcessedRequestDetail where updatedDate >= :startDate and updatedDate <= :endDate ";
			String queryEnd = "group by month(updatedDate) order by updatedDate";
			if (!StringUtils.isEmpty(toolName)) {
				queryfinal = queryfinal + "and toolName = :tool ";
			}
			if (!StringUtils.isEmpty(unicode)) {
				queryfinal = queryfinal + "and enableUnicode = :unicode ";
			}
			if (!StringUtils.isEmpty(ig)) {
				queryfinal = queryfinal + "and industryGroup = :ig ";
			}
			if (!StringUtils.isEmpty(status)) {
				queryfinal = queryfinal + "and requestStatus = :requestStatus ";
			}
			if (!StringUtils.isEmpty(dealtype)) {
				queryfinal = queryfinal + "and kindOfDeal = :dealType ";
			}
			if (!StringUtils.isEmpty(Source)) {
				queryfinal = queryfinal + "and sourceVersion = :source ";
			}
			if (!StringUtils.isEmpty(target)) {
				queryfinal = queryfinal + "and targetVersion = :target ";
			}

			queryfinal = queryfinal + queryEnd;
			hql = queryfinal;
		}
		Query query = session.createQuery(hql);
		if (!(StringUtils.isEmpty(status))) {
			query.setParameter("requestStatus", status);
		}
		if (!(StringUtils.isEmpty(unicode))) {
			query.setParameter("unicode", unicode);
		}

		if (!(StringUtils.isEmpty(dealtype))) {
			query.setParameter("dealType", dealtype);
		}
		if (!(StringUtils.isEmpty(ig))) {
			query.setParameter("ig", ig);
		}
		if (!(StringUtils.isEmpty(Source))) {
			query.setParameter("source", Source);
		}
		if (!(StringUtils.isEmpty(target))) {
			query.setParameter("target", target);
		}
		query.setParameter("tool", toolName);
		query.setParameter("startDate", stDate);
		query.setParameter("endDate", currDate);
		List<Object[]> resultList = query.list();
		if (CollectionUtils.isNotEmpty(resultList)) {
			SimpleDateFormat dispFormat = new SimpleDateFormat("MMM yyyy");
			for (Object[] object : resultList) {
				resultMap.put(dispFormat.format(object[0]), ((Long) object[1]).intValue());
			}
		}
		session.close();
		return resultMap;
	}
	/////////////////////// started Coding

	public Map<String, Map<String, Integer>> getUsedCountImpactObjList(final Long requestId) {
		final Map<String, Map<String, Integer>> resultMap = new HashMap<String, Map<String, Integer>>();
		Map<String, Integer> usedUnusedMap = null;
		session = sessionFactory.openSession();
		//try {
			hql = "select OBJ_TYPE,Used,count(*) from ImpactedObjList where REQUEST_ID=:requestID  and DB_Impact=:DB_Impact group by OBJ_TYPE,Used";

			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);
			query.setParameter("DB_Impact", "X");

			String unused = "N";
			List<Object[]> resultList = query.list();
			String objectType;
			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] object : resultList) {
					objectType = (String) object[0];
					if (objectType != null) {
						objectType = objectType.trim().toUpperCase();
						if (resultMap.get(objectType) != null) {
							usedUnusedMap = resultMap.get(objectType);
							if (object[1] == null) {
								usedUnusedMap.put(unused, ((Long) object[2]).intValue());
							} else if (((String) object[1]).equalsIgnoreCase("")) {
								usedUnusedMap.put(unused, ((Long) object[2]).intValue());
							} else {
								usedUnusedMap.put(((String) object[1]).trim().toUpperCase(), ((Long) object[2]).intValue());
							}
						} else {
							usedUnusedMap = new HashMap<String, Integer>();
							if (object[1] == null) {
								usedUnusedMap.put(unused, ((Long) object[2]).intValue());
							} else if (((String) object[1]).equalsIgnoreCase("")) {
								usedUnusedMap.put(unused, ((Long) object[2]).intValue());
							} else {
								usedUnusedMap.put(((String) object[1]).trim().toUpperCase(), ((Long) object[2]).intValue());
							}

							resultMap.put(objectType, usedUnusedMap);
						}
					}
				}
			}

			session.close();
		/*} catch (Exception e) {
			logger.error("Error !!! " + e);
		}*/
		return resultMap;
	}

	public Map<String, Map<String, Integer>> getObjectUsedCountInventory(final Long requestId) {
		final Map<String, Map<String, Integer>> resultMap = new HashMap<String, Map<String, Integer>>();
		Map<String, Integer> usedUnusedMap = null;
		session = sessionFactory.openSession();
		try {
			hql = "select objType,used,count(*) from S4InventoryList where requestID=:requestID group by objType,used";

			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);

			String unused = "N";
			List<Object[]> resultList = query.list();
			String objectType;
			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] object : resultList) {
					objectType = ((String) object[0]).trim();
					if (objectType != null) {
						objectType = objectType.toUpperCase();
						
						if(resultMap.containsKey(objectType)) {
							usedUnusedMap = resultMap.get(objectType);
							if (object[1] == null || ((String) object[1]).trim().equalsIgnoreCase("")) {
								long count = usedUnusedMap.containsKey(unused) ? usedUnusedMap.get(unused) : 0L;
								count += ((Long) object[2]).intValue();
								usedUnusedMap.put(unused, (int) count);
								} else {
									usedUnusedMap.put(((String) object[1]).trim().toUpperCase(), ((Long) object[2]).intValue());

								}
							resultMap.put(objectType, usedUnusedMap);
							
						} else {
							usedUnusedMap = new HashMap<String,Integer>();
							if (object[1] == null || ((String) object[1]).trim().equalsIgnoreCase("")) {
								usedUnusedMap.put(unused, (int) ((Long) object[2]).intValue());
								} else {
									usedUnusedMap.put(((String) object[1]).trim().toUpperCase(), ((Long) object[2]).intValue());

								}
							resultMap.put(objectType, usedUnusedMap);
						}
							resultMap.put(objectType, usedUnusedMap);
						}

					}

				}
		
			session.close();
		} catch (Exception e) {
			logger.error("Error DisplayGraphDaoImpl getObjectUsedCountInventory " , e);
		}
		return resultMap;
	}

	public Map<String, Map<String, Integer>> getErrorObjectandUsedCount(final Long requestId) {
		final Map<String, Map<String, Integer>> resultMap = new HashMap<String, Map<String, Integer>>();
		Map<String, Integer> usedUnusedMap = null;
		session = sessionFactory.openSession();
		//try {
			hql = "select Object_Type,Used_Unused,count(*) from HanaProfile where requestID=:requestID  group by Object_Type,Used_Unused";

			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);
			String N = "N";
			List<Object[]> resultList = query.list();
			String objectType;
			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] object : resultList) {
					objectType = (String) object[0];
					if (objectType != null) {
						objectType = objectType.trim().toUpperCase();
						if (resultMap.get(objectType) != null) {
							usedUnusedMap = resultMap.get(objectType);
							if (object[1] == null) {
								usedUnusedMap.put(N, ((Long) object[2]).intValue());
							} else if (((String) object[1]).equalsIgnoreCase("")) {
								usedUnusedMap.put(N, ((Long) object[2]).intValue());
							} else {
								usedUnusedMap.put(((String) object[1]).trim().toUpperCase(), ((Long) object[2]).intValue());
							}
						} else {
							usedUnusedMap = new HashMap<String, Integer>();
							if (object[1] == null) {
								usedUnusedMap.put(N, ((Long) object[2]).intValue());
							} else if (((String) object[1]).equalsIgnoreCase("")) {
								usedUnusedMap.put(N, ((Long) object[2]).intValue());
							} else {
								usedUnusedMap.put(((String) object[1]).trim().toUpperCase(), ((Long) object[2]).intValue());
							}

							resultMap.put(objectType, usedUnusedMap);
						}
					}

				}
			}

			session.close();
		/*} catch (Exception e) {
			logger.error("Error !!! " + e);
		}*/
		return resultMap;
	}

	private Integer geUsedUnsedColumnCount(String key, Map<String, Integer> usedUnsedMap) {
		Integer count = 0;
		key = key.toUpperCase();
		if (usedUnsedMap != null && usedUnsedMap.containsKey(key)) {
			count = usedUnsedMap.get(key);
		}

		return count;
	}

	public Map<String, Integer> getErrorUsedObjectCount(final Long requestId) {
		final Map<String, Integer> resultMap = new HashMap<String, Integer>();
		session = sessionFactory.openSession();
		try {
			hql = "select Object_Type,count(*) from HanaProfile where requestID=:requestID and Used_Unused=:used_unused group by Object_Type";

			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);
			query.setParameter("used_unused", "Used");
			List<Object[]> resultList = query.list();
			if (CollectionUtils.isNotEmpty(resultList))
				if (CollectionUtils.isNotEmpty(resultList)) {
					for (Object[] object : resultList) {
						resultMap.put(((String) object[0]).toUpperCase(), ((Long) object[1]).intValue());
					}
				}
			session.close();
		} catch (Exception e) {
			logger.error("Error DisplayGraphDaoImpl getErrorusedObjectCount" , e);
		}
		return resultMap;
	}

	public Map<String, Map<String, Integer>> getRemediationUsedCount(final Long requestId) {
		final Map<String, Map<String, Integer>> resultMap = new HashMap<String, Map<String, Integer>>();
		Map<String, Integer> usedUnusedMap = null;
		session = sessionFactory.openSession();
		//try {
			hql = "select Category,Used_Unused,count(*),count(distinct objNameType) from HanaProfile where requestID=:requestID  group by Category,Used_Unused";

			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);

			List<Object[]> resultList = query.list();
			String category;
			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] object : resultList) {
					category = (String) object[0];
					if (category != null) {
						category = category.trim().toUpperCase();
						if (resultMap.get(category) != null) {
							usedUnusedMap = resultMap.get(category);
							if (object[1] == null) {
								usedUnusedMap.put("unusedAll".toUpperCase(), ((Long) object[2]).intValue());
								usedUnusedMap.put("unusedDistinct".toUpperCase(), ((Long) object[3]).intValue());
							} else if (((String) object[1]).equalsIgnoreCase("")) {
								usedUnusedMap.put("unusedAll".toUpperCase(), ((Long) object[2]).intValue());
								usedUnusedMap.put("unusedDistinct".toUpperCase(), ((Long) object[3]).intValue());
							} else {
								usedUnusedMap.put("usedAll".toUpperCase(), ((Long) object[2]).intValue());
								usedUnusedMap.put("usedDistinct".toUpperCase(), ((Long) object[3]).intValue());
							}
						} else {
							usedUnusedMap = new HashMap<String, Integer>();
							if (object[1] == null) {
								usedUnusedMap.put("unusedAll".toUpperCase(), ((Long) object[2]).intValue());
								usedUnusedMap.put("unusedDistinct".toUpperCase(), ((Long) object[3]).intValue());
							} else if (((String) object[1]).equalsIgnoreCase("")) {
								usedUnusedMap.put("unusedAll".toUpperCase(), ((Long) object[2]).intValue());
								usedUnusedMap.put("unusedDistinct".toUpperCase(), ((Long) object[3]).intValue());
							} else {
								usedUnusedMap.put("usedAll".toUpperCase(), ((Long) object[2]).intValue());
								usedUnusedMap.put("usedDistinct".toUpperCase(), ((Long) object[3]).intValue());
							}

							resultMap.put(category, usedUnusedMap);
						}
					}
				}
			}

			session.close();
		/*} catch (Exception e) {
			logger.error("Error !!! " + e);
		}*/
		return resultMap;
	}

	public Map<String, Map<String, Integer>> getObjectAutomationUsedCount(final Long requestId) {
		final Map<String, Map<String, Integer>> resultMap = new HashMap<String, Map<String, Integer>>();
		Map<String, Integer> usedUnusedMap = null;
		session = sessionFactory.openSession();
		//try {
			hql = "select Object_Type,Used_Unused,count(distinct objNameType) from HanaProfile where requestID=:requestID and automation_status=:automation_status group by Object_Type,Used_Unused";

			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);
			query.setParameter("automation_status", "Yes");
			String N = "UNUSED";
			List<Object[]> resultList = query.list();
			String objectType;
			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] object : resultList) {
					objectType = ((String) object[0]).trim();
					if (resultMap.get(objectType) != null) {
						usedUnusedMap = resultMap.get(objectType);
						if (object[1] == null) {
							usedUnusedMap.put(N, ((Long) object[2]).intValue());
						} else if (((String) object[1]).equalsIgnoreCase("")) {
							usedUnusedMap.put(N, ((Long) object[2]).intValue());
						} else {
							usedUnusedMap.put(((String) object[1]).trim().toUpperCase(), ((Long) object[2]).intValue());
						}
					} else {
						usedUnusedMap = new HashMap<String, Integer>();
						if (object[1] == null) {
							usedUnusedMap.put(N, ((Long) object[2]).intValue());
						} else if (((String) object[1]).equalsIgnoreCase("")) {
							usedUnusedMap.put(N, ((Long) object[2]).intValue());
						} else {
							usedUnusedMap.put(((String) object[1]).trim().toUpperCase(), ((Long) object[2]).intValue());
						}

						resultMap.put(objectType, usedUnusedMap);
					}

				}
			}

			session.close();
		/*} catch (Exception e) {
			logger.error("Error !!! " + e);
		}*/
		return resultMap;
	}

	public Map<String, Map<String, Integer>> getCountSubCategory111111111111111111111(final Long requestId) {

		final Map<String, Map<String, Integer>> resultMap = new HashMap<String, Map<String, Integer>>();
		Map<String, Integer> usedUnusedMap = null;
		session = sessionFactory.openSession();

		hql = "select Subcategory,Used_Unused,count(*) from HanaProfile where requestID= :requestID GROUP BY Subcategory,Used_Unused";

		Query query = session.createQuery(hql);
		query.setParameter("requestID", requestId);
		String N = "N";
		List<Object[]> resultList = query.list();
		String subcategory;
		if (CollectionUtils.isNotEmpty(resultList)) {
			for (Object[] object : resultList) {
				subcategory = (String) object[0];
				if (subcategory != null) {
					subcategory = subcategory.toUpperCase();
					if (resultMap.get(subcategory) != null) {
						usedUnusedMap = resultMap.get(subcategory);
						if (object[1] == null) {
							usedUnusedMap.put(N, ((Long) object[2]).intValue());
						} else if (((String) object[1]).equalsIgnoreCase("")) {
							usedUnusedMap.put(N, ((Long) object[2]).intValue());
						} else {
							usedUnusedMap.put(((String) object[1]).toUpperCase(), ((Long) object[2]).intValue());
						}
					} else {
						usedUnusedMap = new HashMap<String, Integer>();
						if (object[1] == null) {
							usedUnusedMap.put(N, ((Long) object[2]).intValue());
						} else if (((String) object[1]).equalsIgnoreCase("")) {
							usedUnusedMap.put(N, ((Long) object[2]).intValue());
						} else {
							usedUnusedMap.put(((String) object[1]).toUpperCase(), ((Long) object[2]).intValue());
						}

						resultMap.put(subcategory, usedUnusedMap);
					}
				}

			}
		}

		session.close();
		return resultMap;

	}
	public Map<String, Map<String, Integer>> getCountSubCategory(final Long requestId) {
		final Map<String, Map<String, Integer>> resultMap = new HashMap<String, Map<String, Integer>>();
		Map<String, Integer> usedUnusedMap = null;
		session = sessionFactory.openSession();
		//try {
			hql = "select Subcategory,Used_Unused,count(*),count(distinct objNameType) from HanaProfile where requestID=:requestID  group by Subcategory,Used_Unused";

			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);

			List<Object[]> resultList = query.list();
			String category;
			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] object : resultList) {
					category = (String) object[0];
					if (category != null) {
						category = category.trim().toUpperCase();
						if (resultMap.get(category) != null) {
							usedUnusedMap = resultMap.get(category);
							if (object[1] == null) {
								usedUnusedMap.put("unusedAll".toUpperCase(), ((Long) object[2]).intValue());
								usedUnusedMap.put("unusedDistinct".toUpperCase(), ((Long) object[3]).intValue());
							} else if (((String) object[1]).equalsIgnoreCase("")) {
								usedUnusedMap.put("unusedAll".toUpperCase(), ((Long) object[2]).intValue());
								usedUnusedMap.put("unusedDistinct".toUpperCase(), ((Long) object[3]).intValue());
							} else {
								usedUnusedMap.put("usedAll".toUpperCase(), ((Long) object[2]).intValue());
								usedUnusedMap.put("usedDistinct".toUpperCase(), ((Long) object[3]).intValue());
							}
						} else {
							usedUnusedMap = new HashMap<String, Integer>();
							if (object[1] == null) {
								usedUnusedMap.put("unusedAll".toUpperCase(), ((Long) object[2]).intValue());
								usedUnusedMap.put("unusedDistinct".toUpperCase(), ((Long) object[3]).intValue());
							} else if (((String) object[1]).equalsIgnoreCase("")) {
								usedUnusedMap.put("unusedAll".toUpperCase(), ((Long) object[2]).intValue());
								usedUnusedMap.put("unusedDistinct".toUpperCase(), ((Long) object[3]).intValue());
							} else {
								usedUnusedMap.put("usedAll".toUpperCase(), ((Long) object[2]).intValue());
								usedUnusedMap.put("usedDistinct".toUpperCase(), ((Long) object[3]).intValue());
							}

							resultMap.put(category, usedUnusedMap);
						}
					}
				}
			}

			session.close();
		/*} catch (Exception e) {
			logger.error("Error !!! " + e);
		}*/
		return resultMap;
	}

	private Integer getTotalUsedCount(String key, Map<String, Map<String, Integer>> resultMap) {
		Integer count = 0;
		String keyUpper = key.toUpperCase();
		if (resultMap != null && !resultMap.isEmpty()) {
			count = resultMap.values().stream().flatMap(innerMap -> innerMap.entrySet().stream())
					.filter(filterMap -> keyUpper.equals(filterMap.getKey()))
					.mapToInt(filterMap -> filterMap.getValue()).sum();
		}

		return count;
	}

	private Integer getTotalCount(Map<String, Map<String, Integer>> resultMap) {
		Integer count = 0;
		if (resultMap != null && !resultMap.isEmpty()) {
			count = resultMap.values().stream().flatMap(innerMap -> innerMap.entrySet().stream())
					.mapToInt(map -> map.getValue()).sum();
		}

		return count;
	}

	public Map<String, Integer> getTotalUsedCountImpactObjList(final Long requestId) {
		final Map<String, Integer> resultMap = new HashMap<String, Integer>();

		session = sessionFactory.openSession();
		//try {
			hql = "select Used,count(*) from ImpactedObjList  where REQUEST_ID=:requestID and DB_Impact=:DB_Impact group by  Used";

			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);
			query.setParameter("DB_Impact", "X");

			String unused = "N";
			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] object : resultList) {
					if (object[0] == null || ((String) object[0]).equalsIgnoreCase("")) {
						long count = resultMap.containsKey(unused) ? resultMap.get(unused) : 0L;
						count += ((Long) object[1]).intValue();
						resultMap.put(unused, (int) count);
					} else {
						resultMap.put(((String) object[0]).trim().toUpperCase(), ((Long) object[1]).intValue());

					}
				}
			}
			session.close();
		/*
		} catch (Exception e) {
			logger.error("Error !!! " + e);
		}*/
		return resultMap;
	}

	public Integer getErrorAutomationY(final Long requestId) {
		int count = 0;
		session = sessionFactory.openSession();
		try {
			hql = "select count(*) from HanaProfile where requestID=:requestID and automation_status=:automation_status";

			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);
			query.setParameter("automation_status", "Yes");
			count = ((Long) query.uniqueResult()).intValue();

		} finally {
			if (session != null) {
				session.close();
			}
		}
		return count;
	}
	
	public Map<String, Integer> getUniqueCustomAndStandardTransactionsCount(final Long requestID) {
		Map<String, Integer> uniqueCustomAndStandardTransactionsMap = new HashMap<String, Integer>();
		String sqlCustom = "select transactions, role from ExtractedDatapojo where requestid=:requestID and opercd=:opercd";
		String sqlStandard = "select transactions, role from ExtractedDatapojo where requestid=:requestID and opercd=:opercd";
		Set<String> customTransactionSet = new HashSet<>();
		Set<String> customRoleSet = new HashSet<>();
		Set<String> standardTransactionSet = new HashSet<>();
		Set<String> standardRoleSet = new HashSet<>();
		session = sessionFactory.openSession();
		try {
			Query queryCustom = session.createQuery(sqlCustom);
			queryCustom.setParameter("requestID", requestID);
			queryCustom.setParameter("opercd", "Custom");
			
			List<Object[]> resultListCustom = queryCustom.list();
			
			if(CollectionUtils.isNotEmpty(resultListCustom)) {
				for (Object[] data : resultListCustom) {
					String[] transactions = ((String) data[0]).split("[,]", 0);
					String[] role = ((String) data[1]).split("[,]", 0);
					for(String transactionValue : transactions) {
						if(transactionValue != null && !transactionValue.isEmpty())
							customTransactionSet.add(transactionValue);
					}
					for(String roleValue : role) {
						if(roleValue != null && !roleValue.isEmpty())
							customRoleSet.add(roleValue);
					}
				}
			}
			
			Query queryStandard = session.createQuery(sqlStandard);
			queryStandard.setParameter("requestID", requestID);
			queryStandard.setParameter("opercd", "Standard");
			
			List<Object[]> resultListStandard = queryStandard.list();
			
			if(CollectionUtils.isNotEmpty(resultListStandard)) {
				for (Object[] data : resultListStandard) {
					String[] transactions = ((String) data[0]).split("[,]", 0);
					String[] role = ((String) data[1]).split("[,]", 0);
					for(String transactionValue : transactions) {
						if(transactionValue != null && !transactionValue.isEmpty())
							standardTransactionSet.add(transactionValue);
					}
					for(String roleValue : role) {
						if(roleValue != null && !roleValue.isEmpty())
							standardRoleSet.add(roleValue);
					}
				}
			}
			
			uniqueCustomAndStandardTransactionsMap.put("Custom Transactions", customTransactionSet.size());
			uniqueCustomAndStandardTransactionsMap.put("Custom Role", customRoleSet.size());
			uniqueCustomAndStandardTransactionsMap.put("Standard Transactions", standardTransactionSet.size());
			uniqueCustomAndStandardTransactionsMap.put("Standard Role", standardRoleSet.size());
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.error("Error DisplayGraphDaoImpl getUniqueCustomAndStandardTransactionsCount" , e);
		}
		
		return uniqueCustomAndStandardTransactionsMap;
	}

	public Map<String, HashSet<String>> getTestingScopeProcessCount(final Long requestId) {
		Map<String, HashSet<String>> processTcodeMap = new HashMap<String, HashSet<String>>();
		HashSet<String> transactionSet = null;
		session = sessionFactory.openSession();
		try {
			hql = "SELECT process, transactions FROM ExtractedDatapojo where requestid=:requestID GROUP BY process, transactions";

			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] data : resultList) {
					if (data[0] != null && !((String) data[0]).isEmpty()) {
						String process = (String) data[0];
						String transactions = (String) data[1];
						if (processTcodeMap.containsKey(process)) {
							transactionSet = processTcodeMap.get(process);
							if (transactions != null && !transactions.equalsIgnoreCase("")) 
								transactionSet.addAll(splitTcodes(transactions));	
							processTcodeMap.put(process, transactionSet);
						} else {
							transactionSet = new HashSet<String>();
							if (transactions != null && !transactions.equalsIgnoreCase("")) 
								transactionSet.addAll(splitTcodes(transactions));
							processTcodeMap.put(process, transactionSet);
						}
					}
				}
			}
			session.close();
		} catch (Exception e) {
			logger.error("Error DisplayGraphDaoImpl getTestingScopeProcessCount " , e);
		}
		
		return processTcodeMap;
	}
	
	public Map<String, Integer> getTestingScopeProcessObjectCount(final Long requestId,HttpSession session) {
		Map<String, Integer> processObjectMap = new HashMap<String,Integer>();
		
		try {
			hql = "SELECT process, Count(distinct objectTypeObjectName, process)AS count FROM FinalOutputTestingscope where requestid="+requestId+" GROUP BY process";
			java.sql.Connection conn = null;
			java.sql.Statement stmt = null;
			ResultSet rs=null;
			
			conn = DBConfig.getJDBCConnection(session);
			conn.setAutoCommit(false);
				
			stmt = conn.createStatement();
			rs= stmt.executeQuery(hql);
			if (rs!= null) {
				while(rs.next()){
						String process =  rs.getString("process");
						int count =  rs.getInt("count");
						processObjectMap.put(process, count);
						} 
					}
		} catch (Exception e) {
			logger.error("Error DisplayGraphDaoImpl getTestingScopeProcessObjectCount  " , e);
		}
		
		return processObjectMap;
	}
	
	
	public Map<String, String> getTestingScopeStandardTcodesMasterMapping(Map<String, String> staticMasterData, Map<String, HashSet<String>> tcodeMap) {
		Map<String, String> processMasterMap = new HashMap<String,String>();
		
			StringBuffer delimitedString = new StringBuffer();
			String mappingData="";
			for (Map.Entry<String, HashSet<String>> entryProcess : tcodeMap.entrySet()) {
				
				String MappingValue="";
				String processKey=entryProcess.getKey().toUpperCase();
				if (staticMasterData.containsKey(processKey)) {
					 mappingData = staticMasterData.get(processKey);
			    }
				
				String componentidData="";
				String applcompdescriptionData="";	
					 
					if(!mappingData.equals(""))
					{
					String[] dataArr = mappingData.split("\\*%");
					if(dataArr!= null)
					{
					 componentidData= dataArr[0];
					 applcompdescriptionData=dataArr[1];	
					}
					}

				if(applcompdescriptionData.equals("")||applcompdescriptionData.equals("&%"))
				{
					MappingValue="";
				}
				else
				{
					MappingValue=applcompdescriptionData;
				}
				
				processMasterMap.put(processKey, MappingValue);	
			}
		
		return processMasterMap;

	}

	public Map<String, String> getTestingScopeProcessMasterMapping(Map<String, String> staticMasterData, Map<String,Integer> processObjectMap) {
		Map<String, String> processMasterMap = new HashMap<String,String>();
		
			StringBuffer delimitedString = new StringBuffer();
			String mappingData = "";
			for (Map.Entry<String, Integer> entryProcess : processObjectMap.entrySet()) {
				
				String MappingValue = "";
				String processKey = entryProcess.getKey().toUpperCase();
				if (staticMasterData.containsKey(processKey)) {
					 mappingData = staticMasterData.get(processKey);
			    }
				else {
					mappingData = "";
				}
				
				String componentidData = "";
				String applcompdescriptionData = "";	
					 
					if(!mappingData.equals("")) {
						String[] dataArr = mappingData.split("\\*%");
						if(dataArr!= null) {
						 componentidData = dataArr[0];
						 applcompdescriptionData = dataArr[1];	
						}	
					}

				if(applcompdescriptionData.equals("")||applcompdescriptionData.equals("&%")) {
					MappingValue="";
				}
				else {
					MappingValue = applcompdescriptionData;
				}	
				processMasterMap.put(processKey, MappingValue);	
			}
		
		return processMasterMap;
	}

	public Map<String, HashSet<String>> getTestingScopeObjectCount(final Long requestId) {
		Map<String, HashSet<String>> objectTcodeMap = new HashMap<String, HashSet<String>>();
		HashSet<String> transactionSet = null;
		session = sessionFactory.openSession();
		try {
			hql = "SELECT objecttype, transactions FROM ExtractedDatapojo where requestid=:requestID GROUP BY objecttype, transactions";

			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] object : resultList) {
					if (object[0] != null && !((String) object[0]).equalsIgnoreCase("")) {
						String objectType = (String) object[0];
						String transactions = (String) object[1];
						if (objectTcodeMap.containsKey(objectType)) {
							transactionSet = objectTcodeMap.get(objectType);
							if (transactions != null && !transactions.equalsIgnoreCase(""))
								transactionSet.addAll(splitTcodesBasedOnYZ(transactions));
							objectTcodeMap.put(objectType, transactionSet);
						} else {
							transactionSet = new HashSet<String>();
							if (transactions != null && !transactions.equalsIgnoreCase(""))
								transactionSet.addAll(splitTcodesBasedOnYZ(transactions));
							objectTcodeMap.put(objectType, transactionSet);
						}
					}
				}
			}
			session.close();
		} catch (Exception e) {
			logger.error("Error DisplayGraphDaoImpl getTestingScopeObjectCount " , e);
		}
		
		return objectTcodeMap;
	}

	protected HashSet<String> splitTcodes(String tcode) {
		tcode = tcode.toUpperCase();
		String[] tcodeSplit = tcode.split(",");
		HashSet<String> tcodeSet = new HashSet(Arrays.asList(tcodeSplit));
		return tcodeSet;
	}
	
	
	@Override
	public void testingScopeRequestMaster(Long requestId,HttpSession session) {
		logger.info("Starting Request Master TestingScope update !!!!!!!!!!!!!!!!! ");
		TestingScope master = new TestingScope();
		Map<String, String> staticdata_pojo = getTestingscopeValuesdb();

		Map<String, HashSet<String>> processTcodeMap = getTestingScopeProcessCount(requestId);
		Map<String, HashSet<String>> objectTcodeMap = getTestingScopeObjectCount(requestId);
	
		Map<String,Integer> processObjectCountMap = getTestingScopeProcessObjectCount(requestId, session);
		Map<String,String> processMasterMap = getTestingScopeProcessMasterMapping(staticdata_pojo, processObjectCountMap);
		String processObjectString = getDelimiedProcessObjectCountString(processObjectCountMap);
		String processMapString = getDelimiedProcessMasterMapString(processMasterMap);
		master.setProcessObjectcount(processObjectString);
		master.setProcessMasterMap(processMapString);
		
		Map<String, Integer> uniqueCustomAndStandardTransactionsCnt = getUniqueCustomAndStandardTransactionsCount(requestId);

		String processString = getDelimiedCountString(processTcodeMap);
		String objectString = getDelimiedCountString(objectTcodeMap);
		
		String uniqueCustomAndStandardString = getDelimiedProcessObjectCountString(uniqueCustomAndStandardTransactionsCnt);

		master.setRequestID(requestId);
		master.setProcess_count(processString);
		master.setObject_count(objectString);
		master.setUniqueCustomAndStandardTransactionsCntMap(uniqueCustomAndStandardString);
		
		updateTestingScopeMasterData(requestId, master);

		logger.info("Request Master TestingScope updated !!!!!!!!!!!!!!!!! ");
	}

	protected String getDelimiedTcodeObjectCountString(Map<String, Integer> testScopeMap) {
		StringBuffer delimitedString = new StringBuffer();
		for (Map.Entry<String, Integer> entryProcess : testScopeMap.entrySet()) {
			String processKey = entryProcess.getKey();
			Integer tcode = entryProcess.getValue();

			delimitedString.append(processKey).append(":").append(tcode).append("|");
		}
		
		return delimitedString.toString();		
	}
	
	protected String getDelimiedCountString(Map<String, HashSet<String>> testScopeMap) {
		StringBuffer delimitedString = new StringBuffer();
		for (Map.Entry<String, HashSet<String>> entryProcess : testScopeMap.entrySet()) {
			String processKey = entryProcess.getKey();
			HashSet<String> tcodeSet = entryProcess.getValue();
			delimitedString.append(processKey).append(":").append(tcodeSet.size()).append("|");
		}

		return delimitedString.toString();		
	}
	
	protected String getDelimiedProcessMasterMapString(Map<String,String> ProcessObjectCountMap) {
		StringBuffer delimitedString = new StringBuffer();
		for (Map.Entry<String, String> entryProcess : ProcessObjectCountMap.entrySet()) {
			String processKey = entryProcess.getKey();
			String value = entryProcess.getValue();
			delimitedString.append(processKey).append(":").append(value).append("|");
		}
		
		return delimitedString.toString();		
	}
	
	protected String getDelimiedtcodeMasterMapString(Map<String,String> tcodeObjectCountMap) {
		StringBuffer delimitedString = new StringBuffer();
		for (Map.Entry<String, String> entryProcess : tcodeObjectCountMap.entrySet()) {
			String processKey = entryProcess.getKey();
			String value = entryProcess.getValue();
			delimitedString.append(processKey).append(":").append(value).append("|");
		}
		
		return delimitedString.toString();		

	}
	
	protected String getDelimiedProcessObjectCountString(Map<String,Integer> ProcessObjectCountMap) {
		StringBuffer delimitedString = new StringBuffer();
		for (Map.Entry<String, Integer> entryProcess : ProcessObjectCountMap.entrySet()) {
			String processKey = entryProcess.getKey();
			Integer count = entryProcess.getValue();
			delimitedString.append(processKey).append(":").append(count).append("|");
		}
		
		return delimitedString.toString();		
	}
	
	
	public Map<String, String> getTestingscopeValuesdb()
	{
		Session session = null;
		final Map<String,String> resultMap = new HashMap<String,String>();
		session = sessionFactory.openSession();
		String hql = "select componentid, applcompdescription from testingscope";
		Query query = session.createSQLQuery(hql);
		List<Object[]> resultList = query.list();
		
		
		if(CollectionUtils.isNotEmpty(resultList))
		{	
			for(Object[] object : resultList)
			{
				String Data="";	
				String componentid="&%";
				String applcompdescription="&%";
				
						if(!((String) object[0]).equals(""))
						{
						  componentid=(String) object[0];
						  Data=Data+componentid;
						}
						else if(object[0].equals(""))
						{
							Data=Data+componentid;
						}
						if(!((String) object[1]).equals(""))
						{
						  applcompdescription=(String) object[1];
						  Data=Data+"*%"+applcompdescription;
						}
						else if(object[1].equals(""))
						{
							Data=Data+"*%"+applcompdescription;
						}					 
						 resultMap.put(componentid.toUpperCase(),Data);
						
			}
		}
		session.close();
		return resultMap;
	}
	
	
	

	@Override
	public ProcessedRequestDetail getRequestMasterCommonColumns(Long requestId) {
		logger.info("inside getRequestMasterCommonColumns  !!!!!!!!!!!!!!!!! ");

		ProcessedRequestDetail reqMaster = new ProcessedRequestDetail();

		Map<String, Map<String, Integer>> resultInventoryObject = getObjectUsedCountInventory(requestId);

		int enhanCount = 0;
		int formCount = 0;
		enhanCount = (geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("ENHC"))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultInventoryObject.get("ENHC")))
				+ (geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("ENHO"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultInventoryObject.get("ENHO")))
				+ (geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("ENHS"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultInventoryObject.get("ENHS")));

		formCount = (geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("SFPF"))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultInventoryObject.get("SFPF")))
				+ (geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("SSFO"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultInventoryObject.get("SSFO")));

		reqMaster.setTotalObjectCount(getTotalCount(resultInventoryObject));
		reqMaster.setUsed_count(getTotalUsedCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject));
		reqMaster.setCustClasCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("CLAS"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultInventoryObject.get("CLAS")));
		
		reqMaster.setCust_BWTRCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("BWTR"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultInventoryObject.get("BWTR")));
		reqMaster.setCust_BWTSCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("BWTS"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultInventoryObject.get("BWTS")));
		reqMaster.setCust_BWURCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("BWUR"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultInventoryObject.get("BWUR")));
		reqMaster.setCust_BWIGCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("BWIG"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultInventoryObject.get("BWIG")));
		
		reqMaster.setCustProgCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("PROG"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultInventoryObject.get("PROG")));
		reqMaster.setCustFormCount(formCount);
		reqMaster.setCustFugrCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("FUGR"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultInventoryObject.get("FUGR")));
		reqMaster.setCustEnhanCount(enhanCount);
		reqMaster.setCustLsmwCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("LSMW"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultInventoryObject.get("LSMW")));

		reqMaster.setCustWebCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("WDYN"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultInventoryObject.get("WDYN")));
		reqMaster.setCustReptCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("REPT"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultInventoryObject.get("REPT")));
		reqMaster.setCustViewCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("VIEW"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultInventoryObject.get("VIEW")));
		reqMaster.setCustIndeCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("INDE"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultInventoryObject.get("INDE")));
		reqMaster.setCustDtelCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("DTEL"))
						+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultInventoryObject.get("DTEL")));
		reqMaster.setUsreCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("USRE"))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultInventoryObject.get("USRE")));
		reqMaster.setUsrrCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("USRR"))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultInventoryObject.get("USRR")));
		reqMaster.setFugsCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("FUGS"))
				+ geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultInventoryObject.get("FUGS")));

		int enhanUsedCount = 0;
		int formUsedCount = 0;
		enhanUsedCount = (geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("ENHC")))
				+ (geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("ENHO")))
				+ (geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("ENHS")));

		formUsedCount = (geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("SFPF")))
				+ (geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("SSFO")));

		reqMaster.setCustUsedClasCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("CLAS")));
		
		reqMaster.setCustUsed_BWTRCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("BWTR")));
		reqMaster.setCustUsed_BWTSCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("BWTS")));
		reqMaster.setCustUsed_BWURCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("BWUR")));
		reqMaster.setCustUsed_BWIGCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("BWIG")));
		
		reqMaster.setCustUsedProgCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("PROG")));
		reqMaster.setCustUsedFormCount(formUsedCount);
		reqMaster.setCustUsedFugrCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("FUGR")));
		reqMaster.setCustUsedEnhanCount(enhanUsedCount);
		reqMaster.setCustUsedLsmwCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("LSMW")));

		reqMaster.setCustUsedWebCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("WDYN")));
		reqMaster.setCustUsedReptCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("REPT")));
		reqMaster.setCustUsedViewCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("VIEW")));
		reqMaster.setCustUsedIndxCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("INDE")));
		reqMaster.setCustUsedDtelCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("DTEL")));
		reqMaster.setUsreUsedCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("USRE")));
		reqMaster.setUsrrUsedCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("USRR")));
		reqMaster.setFugsUsedCount(
				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultInventoryObject.get("FUGS")));

		logger.info("ending  getRequestMasterCommonColumns  !!!!!!!!!!!!!!!!! ");

		return reqMaster;

	}

	public Map<String, Integer> getJobRunCount(final Long requestId) {
		final Map<String, Integer> resultMap = new HashMap<String, Integer>();

		session = sessionFactory.openSession();
		//try {
			hql = "select run, count(*) from ImpactedBackgroundJob_Download where requestId=:requestID group by run";

			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] job : resultList) {
					if (job[0] != null) {
						resultMap.put(((String) job[0]).toUpperCase(), ((Long) job[1]).intValue());
					}

				}
			}
			session.close();
			
		return resultMap;

	}
	
	public Map<String, Map<String, Integer>> getDBLevelOperationCount(final Long requestId) {
		final Map<String, Map<String, Integer>> resultMap = new HashMap<String, Map<String, Integer>>();
		Map<String, Integer> errorImpactMap = new HashMap<String, Integer>();
		Map<String, Integer> objDistinctImpactMap = new HashMap<String, Integer>();

		session = sessionFactory.openSession();
		
			hql = "select Opertaion, count(*), count(distinct obj_name_type) from HanaProfile where requestID=:requestID and "
					+ "Category='DB Level HANA Optimization' and Subcategory='Minimize the amount of transferred data' and  "
					+ "IssueSecondSubCat='Performance (HANA specific)' and   automation_status='No'  group by Opertaion";

			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] object : resultList) {
					if (object[0] != null) {
						errorImpactMap.put(((String) object[0]).trim().toUpperCase(), ((Long) object[1]).intValue());
						objDistinctImpactMap.put(((String) object[0]).trim().toUpperCase(), ((Long) object[2]).intValue());
					}

				}
			}
			session.close();
			resultMap.put("errorCountMap", errorImpactMap);
			resultMap.put("distinctCountMap", objDistinctImpactMap);
		return resultMap;

	}

	public Map<String, Map<String, Integer>> getRemediationAutoCount(final Long requestId) {
		final Map<String, Map<String, Integer>> resultMap = new HashMap<String, Map<String, Integer>>();
		Map<String, Integer> usedUnusedMap = null;
		session = sessionFactory.openSession();
		//try {
			hql = "select Category,automation_status,count(*),count(distinct objNameType) from HanaProfile where requestID=:requestID  group by Category,automation_status";

			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);

			List<Object[]> resultList = query.list();
			String category;
			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] object : resultList) {
					// category = (String) object[0];
					if (object[0] != null) {
						category = ((String) object[0]).trim().toUpperCase();
						if (resultMap.get(category) != null) {
							usedUnusedMap = resultMap.get(category);
							if (object[1] != null && !((String) object[1]).equalsIgnoreCase("")
									&& ((String) object[1]).equalsIgnoreCase("Yes")) {
								usedUnusedMap.put("autoYAll".toUpperCase(), ((Long) object[2]).intValue());
								usedUnusedMap.put("autoYDistinct".toUpperCase(), ((Long) object[3]).intValue());

							} else {
								usedUnusedMap.put("autoNAll".toUpperCase(), ((Long) object[2]).intValue());
								usedUnusedMap.put("autoNDistinct".toUpperCase(), ((Long) object[3]).intValue());
							}
						} else {
							usedUnusedMap = new HashMap<String, Integer>();
							if (object[1] != null && !((String) object[1]).equalsIgnoreCase("")
									&& ((String) object[1]).equalsIgnoreCase("Yes")) {
								usedUnusedMap.put("autoYAll".toUpperCase(), ((Long) object[2]).intValue());
								usedUnusedMap.put("autoYDistinct".toUpperCase(), ((Long) object[3]).intValue());
							} else {
								usedUnusedMap.put("autoNAll".toUpperCase(), ((Long) object[2]).intValue());
								usedUnusedMap.put("autoNDistinct".toUpperCase(), ((Long) object[3]).intValue());
							}

							resultMap.put(category, usedUnusedMap);
						}
					}
				}
			}

			session.close();
		/*} catch (Exception e) {
			logger.error("Error !!! " + e);
		}*/
		return resultMap;
	}

	public Map<String, Map<String, Map<String, Integer>>> getHouseKeepHanaCount(final Long requestId) {
		final Map<String, Map<String, Map<String, Integer>>> resultMap = new HashMap<String, Map<String, Map<String, Integer>>>();
		Map<String, Map<String, Integer>> oprtnMap = null;

		session = sessionFactory.openSession();
		//try {
			hql = "select Subcategory,Opertaion , count(*), count(distinct objNameType) from HanaProfile where requestID=:requestID and category ='Housekeeping for HANA' and IssueSecondSubCat='Code maintainability (HANA specific)' group by Subcategory,Opertaion";

			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);

			List<Object[]> resultList = query.list();
			String subcategory;
			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] object : resultList) {

					if (object[0] != null) {
						subcategory = ((String) object[0]).trim().toUpperCase();
						if (resultMap.get(subcategory) != null) {

							oprtnMap = resultMap.get(subcategory);
							if (object[1] != null) {
								Map<String, Integer> countMap = new HashMap<String, Integer>();
								countMap.put("errorCount".toUpperCase(), ((Long) object[2]).intValue());
								countMap.put("distinctCount".toUpperCase(), ((Long) object[3]).intValue());
								oprtnMap.put(((String) object[1]).trim().toUpperCase(), countMap);
							}

						} else {

							if (object[1] != null) {

								Map<String, Map<String, Integer>> operationMap = new HashMap<String, Map<String, Integer>>();
								Map<String, Integer> countMap = new HashMap<String, Integer>();
								countMap.put("errorCount".toUpperCase(), ((Long) object[2]).intValue());
								countMap.put("distinctCount".toUpperCase(), ((Long) object[3]).intValue());
								operationMap.put(((String) object[1]).trim().toUpperCase(), countMap);
								resultMap.put(((String) object[0]).trim().toUpperCase(), operationMap);

							}

						}
					}
				}
			}

			session.close();
		/*} catch (Exception e) {
			logger.error("Error !!! " + e);
		}*/
		return resultMap;
	}

	public Map<String, Map<String, Map<String, Integer>>> getAppLevelHanaCount(final Long requestId) {
		final Map<String, Map<String, Map<String, Integer>>> resultMap = new HashMap<String, Map<String, Map<String, Integer>>>();
		Map<String, Map<String, Integer>> subCatMap = null;

		session = sessionFactory.openSession();
		//try {
			hql = "select issueSecondSubCat,Subcategory , count(*), count(distinct objNameType) from HanaProfile where requestID=:requestID and category ='Application level optimization'  group by issueSecondSubCat,Subcategory";

			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);

			List<Object[]> resultList = query.list();
			String secondSubcategory;
			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] object : resultList) {

					if (object[0] != null) {
						secondSubcategory = ((String) object[0]).trim().toUpperCase();
						if (resultMap.get(secondSubcategory) != null) {

							subCatMap = resultMap.get(secondSubcategory);
							if (object[1] != null) {
								Map<String, Integer> countMap = new HashMap<String, Integer>();
								countMap.put("errorCount".toUpperCase(), ((Long) object[2]).intValue());
								countMap.put("distinctCount".toUpperCase(), ((Long) object[3]).intValue());
								subCatMap.put(((String) object[1]).trim().toUpperCase(), countMap);
							}

						} else {

							if (object[1] != null) {

								Map<String, Map<String, Integer>> subCategoryMap = new HashMap<String, Map<String, Integer>>();
								Map<String, Integer> countMap = new HashMap<String, Integer>();
								countMap.put("errorCount".toUpperCase(), ((Long) object[2]).intValue());
								countMap.put("distinctCount".toUpperCase(), ((Long) object[3]).intValue());
								subCategoryMap.put(((String) object[1]).trim().toUpperCase(), countMap);
								resultMap.put(((String) object[0]).trim().toUpperCase(), subCategoryMap);

							}

						}
					}
				}
			}

			session.close();
		/*} catch (Exception e) {
			logger.error("Error !!! " + e);
		}*/
		return resultMap;
	}

	public Map<String, Map<String, Map<String, Integer>>> getManIssueCatgAutoYCount(final Long requestId) {
		final Map<String, Map<String, Map<String, Integer>>> resultMap = new HashMap<String, Map<String, Map<String, Integer>>>();
		Map<String, Map<String, Integer>> subCatMap = null;

		session = sessionFactory.openSession();
		//try {
			hql = "select issueSecondSubCat,Subcategory , count(*), count(distinct objNameType) from HanaProfile where requestID=:requestID and category ='Mandatory' and automation_status='Yes' group by issueSecondSubCat,Subcategory";

			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);

			List<Object[]> resultList = query.list();
			String secondSubcategory;
			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] object : resultList) {

					if (object[0] != null) {
						secondSubcategory = ((String) object[0]).trim().toUpperCase();
						if (resultMap.get(secondSubcategory) != null) {

							subCatMap = resultMap.get(secondSubcategory);
							if (object[1] != null) {
								Map<String, Integer> countMap = new HashMap<String, Integer>();
								countMap.put("errorCount".toUpperCase(), ((Long) object[2]).intValue());
								countMap.put("distinctCount".toUpperCase(), ((Long) object[3]).intValue());
								subCatMap.put(((String) object[1]).trim().toUpperCase(), countMap);
							}

						} else {

							if (object[1] != null) {

								Map<String, Map<String, Integer>> subCategoryMap = new HashMap<String, Map<String, Integer>>();
								Map<String, Integer> countMap = new HashMap<String, Integer>();
								countMap.put("errorCount".toUpperCase(), ((Long) object[2]).intValue());
								countMap.put("distinctCount".toUpperCase(), ((Long) object[3]).intValue());
								subCategoryMap.put(((String) object[1]).trim().toUpperCase(), countMap);
								resultMap.put(((String) object[0]).trim().toUpperCase(), subCategoryMap);

							}

						}
					}
				}
			}

			session.close();
		/*} catch (Exception e) {
			logger.error("Error !!! " + e);
		}*/
		return resultMap;
	}

	public Map<String, Map<String, Map<String, Integer>>> getManIssueCatgAutoNCount(final Long requestId) {
		final Map<String, Map<String, Map<String, Integer>>> resultMap = new HashMap<String, Map<String, Map<String, Integer>>>();
		Map<String, Map<String, Integer>> subCatMap = null;

		session = sessionFactory.openSession();
		//try {
			hql = "select issueSecondSubCat,Subcategory , count(*), count(distinct objNameType) from HanaProfile where requestID=:requestID and category ='Mandatory' and automation_status='No' group by issueSecondSubCat,Subcategory";

			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);

			List<Object[]> resultList = query.list();
			String secondSubcategory;
			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] object : resultList) {

					if (object[0] != null) {
						secondSubcategory = ((String) object[0]).trim().toUpperCase();
						if (resultMap.get(secondSubcategory) != null) {

							subCatMap = resultMap.get(secondSubcategory);
							if (object[1] != null) {
								Map<String, Integer> countMap = new HashMap<String, Integer>();
								countMap.put("errorCount".toUpperCase(), ((Long) object[2]).intValue());
								countMap.put("distinctCount".toUpperCase(), ((Long) object[3]).intValue());
								subCatMap.put(((String) object[1]).trim().toUpperCase(), countMap);
							}

						} else {

							if (object[1] != null) {

								Map<String, Map<String, Integer>> subCategoryMap = new HashMap<String, Map<String, Integer>>();
								Map<String, Integer> countMap = new HashMap<String, Integer>();
								countMap.put("errorCount".toUpperCase(), ((Long) object[2]).intValue());
								countMap.put("distinctCount".toUpperCase(), ((Long) object[3]).intValue());
								subCategoryMap.put(((String) object[1]).trim().toUpperCase(), countMap);
								resultMap.put(((String) object[0]).trim().toUpperCase(), subCategoryMap);

							}

						}
					}
				}
			}

			session.close();
		/*} catch (Exception e) {
			logger.error("Error !!! " + e);
		}*/
		return resultMap;
	}

	public Map<String, Map<String, Map<String, Integer>>> getManIssueOperationAutoYCount(final Long requestId) {
		final Map<String, Map<String, Map<String, Integer>>> resultMap = new HashMap<String, Map<String, Map<String, Integer>>>();
		Map<String, Map<String, Integer>> operationMap = null;

		session = sessionFactory.openSession();
		//try {
			hql = "select Subcategory ,Opertaion ,count(*), count(distinct objNameType) from HanaProfile where requestID=:requestID and category ='Mandatory' and automation_status='Yes' group by Subcategory, Opertaion";

			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);

			List<Object[]> resultList = query.list();
			String subcategory;
			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] object : resultList) {

					if (object[0] != null) {
						subcategory = ((String) object[0]).trim().toUpperCase();
						if (resultMap.get(subcategory) != null) {

							operationMap = resultMap.get(subcategory);
							if (object[1] != null) {
								Map<String, Integer> countMap = new HashMap<String, Integer>();
								countMap.put("errorCount".toUpperCase(), ((Long) object[2]).intValue());
								countMap.put("distinctCount".toUpperCase(), ((Long) object[3]).intValue());
								operationMap.put(((String) object[1]).trim().toUpperCase(), countMap);
							}

						} else {

							if (object[1] != null) {

								Map<String, Map<String, Integer>> oprtnMap = new HashMap<String, Map<String, Integer>>();
								Map<String, Integer> countMap = new HashMap<String, Integer>();
								countMap.put("errorCount".toUpperCase(), ((Long) object[2]).intValue());
								countMap.put("distinctCount".toUpperCase(), ((Long) object[3]).intValue());
								oprtnMap.put(((String) object[1]).trim().toUpperCase(), countMap);
								resultMap.put(((String) object[0]).trim().toUpperCase(), oprtnMap);

							}

						}
					}
				}
			}

			session.close();
		/*} catch (Exception e) {
			logger.error("Error !!! " + e);
		}*/
		return resultMap;
	}

	public Map<String, Map<String, Map<String, Integer>>> getManIssueOperationAutoNCount(final Long requestId) {
		final Map<String, Map<String, Map<String, Integer>>> resultMap = new HashMap<String, Map<String, Map<String, Integer>>>();
		Map<String, Map<String, Integer>> operationMap = null;

		session = sessionFactory.openSession();
		//try {
			hql = "select Subcategory ,Opertaion ,count(*), count(distinct objNameType) from HanaProfile where requestID=:requestID and category ='Mandatory' and automation_status='No' group by Subcategory, Opertaion";

			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);

			List<Object[]> resultList = query.list();
			String subcategory;
			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] object : resultList) {

					if (object[0] != null) {
						subcategory = ((String) object[0]).trim().toUpperCase();
						if (resultMap.get(subcategory) != null) {

							operationMap = resultMap.get(subcategory);
							if (object[1] != null) {
								Map<String, Integer> countMap = new HashMap<String, Integer>();
								countMap.put("errorCount".toUpperCase(), ((Long) object[2]).intValue());
								countMap.put("distinctCount".toUpperCase(), ((Long) object[3]).intValue());
								operationMap.put(((String) object[1]).trim().toUpperCase(), countMap);
							}

						} else {

							if (object[1] != null) {

								Map<String, Map<String, Integer>> oprtnMap = new HashMap<String, Map<String, Integer>>();
								Map<String, Integer> countMap = new HashMap<String, Integer>();
								countMap.put("errorCount".toUpperCase(), ((Long) object[2]).intValue());
								countMap.put("distinctCount".toUpperCase(), ((Long) object[3]).intValue());
								oprtnMap.put(((String) object[1]).trim().toUpperCase(), countMap);
								resultMap.put(((String) object[0]).trim().toUpperCase(), oprtnMap);

							}

						}
					}
				}
			}

			session.close();
		/*} catch (Exception e) {
			logger.error("Error !!! " + e);
		}*/
		return resultMap;
	}

	@Override
	public void updateUI5GraphCountApi(long requestId) {
		logger.info("Inside updateUi5GraphCounts  !!!!!!!!!!!!!!!!! ");
		UI5GraphCounts uI5GraphCountApi = new UI5GraphCounts();
		uI5GraphCountApi.setREQUEST_ID(requestId);

		Map<String, ArrayList<Long>> uI5GraphCountMultipleCount = getUI5GraphCountMultiple(requestId);

		if (uI5GraphCountMultipleCount.containsKey(("Source code is compatible with target UI5 library").toUpperCase())) {
			ArrayList<Long> countList = uI5GraphCountMultipleCount
					.get(("Source code is compatible with target UI5 library").toUpperCase());
			int i = 0;
			Iterator<Long> countListApi = countList.iterator();
			while (countListApi.hasNext()) {
				if (i == 0) {
					uI5GraphCountApi.setComptibleTotalApiCounts(countListApi.next());
					i++;
				}
				if (i != 0) {
					uI5GraphCountApi.setCompatibleDepricatedApiCounts(countListApi.next());
				}
			}
		}
		if (uI5GraphCountMultipleCount
				.containsKey(("Source code needs changes to be compatible with target UI5 library").toUpperCase())) {
			ArrayList<Long> countList = uI5GraphCountMultipleCount
					.get(("Source code needs changes to be compatible with target UI5 library").toUpperCase());
			int i = 0;
			Iterator<Long> countListApi = countList.iterator();
			while (countListApi.hasNext()) {
				if (i == 0) {
					uI5GraphCountApi.setSrcCodeChangesTotalApiCounts(countListApi.next());
					i++;
				}
				if (i != 0) {
					uI5GraphCountApi.setSrcCodeChangesDepricatedApiCounts(countListApi.next());
				}
			}
		}
		if (uI5GraphCountMultipleCount
				.containsKey(("Source code is compatible, however changes are recommended before migration").toUpperCase())) {
			ArrayList<Long> countList = uI5GraphCountMultipleCount
					.get(("Source code is compatible, however changes are recommended before migration").toUpperCase());
			int i = 0;
			Iterator<Long> countListApi = countList.iterator();
			while (countListApi.hasNext()) {
				if (i == 0) {
					uI5GraphCountApi.setRecommendedChangesTotalApiCounts(countListApi.next());
					i++;
				}
				if (i != 0) {
					uI5GraphCountApi.setRecommendedChangesDepricatedApiCounts(countListApi.next());
				}
			}
		}

		Session session = sessionFactory.openSession();
		try {
			session.saveOrUpdate(uI5GraphCountApi);
			session.close();
		} catch (Exception e) {
			e.getMessage();
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		logger.info("Done Updating UI5 Graph Counts  !!!!!!!!!!!!!!!!! ");
	}

	public Map<String, ArrayList<Long>> getUI5GraphCountMultiple(final Long requestId) {
		Map<String, ArrayList<Long>> multiMap = new HashMap<String, ArrayList<Long>>();
		session = sessionFactory.openSession();

		hql = "SELECT finalMessage,SUM(totalApiCounts),SUM(depricatedApiCounts)  FROM UI5HighLevelReport  where REQUEST_ID=:requestID GROUP BY finalMessage";
		Query query = session.createQuery(hql);
		query.setParameter("requestID", requestId);
		List<Object[]> resultList = query.list();

		if (CollectionUtils.isNotEmpty(resultList)) {
			for (Object[] object : resultList) {
				List<Long> values = new ArrayList<Long>();
				if (object[1] != null) {
					values.add((Long) object[1]);
				} else {
					values.add(new Long(0));
				}
				if (object[2] != null) {
					values.add((Long) object[2]);
				} else {
					values.add(new Long(0));
				}
				multiMap.put(((String) object[0]).toUpperCase(), (ArrayList<Long>) values);
			}
		}
		session.close();

		return multiMap;

	}
	
	public Map<String, ArrayList<String>> getProbableFitmentStandardAppsTable(final Long requestId) {
		Map<String, ArrayList<String>> multiMap = new HashMap<String, ArrayList<String>>();
		session = sessionFactory.openSession();

		hql = "SELECT appId, appTypeCombined, appName, formFactors  FROM PortableStandardAppsFiori  where REQUEST_ID=:requestID";
		Query query = session.createQuery(hql);
		query.setParameter("requestID", requestId);
		List<Object[]> resultList = query.list();

		if (CollectionUtils.isNotEmpty(resultList)) {
			for (Object[] object : resultList) {
				List<String> values = new ArrayList<String>();

				if (object[1] != null) {
					values.add((String) object[1]);
					}
				if (object[2] != null) {
					values.add((String) object[2]);
				}
				if (object[3] != null) {
					values.add((String) object[3]);
				}
				multiMap.put(((String) object[0]).toUpperCase(), (ArrayList<String>) values);
			}
		}
		session.close();

		return multiMap;

	}
	@Override
	public Map<String, HashSet<String>> getTestingScopeProcessTabWithoutCount(final Long requestId) {
		Map<String, HashSet<String>> processTcodeMap = new HashMap<String, HashSet<String>>();
		session = sessionFactory.openSession();
		try {

			hql = "SELECT process,standardTcode FROM ExtractedDatapojo where requestid=:requestID";

			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] object : resultList) {
					if (object[0] != null && !((String) object[0]).equalsIgnoreCase("")) {
						String objectType = (String) object[0];
						String tcode = (String) object[1];
						if (processTcodeMap.containsKey(objectType)) {
							HashSet<String> tcodeSet = processTcodeMap.get(objectType);

							if (tcode != null && !tcode.equalsIgnoreCase("")) {

								tcodeSet.addAll(splitTcodeswithoutXY(tcode));
							}
							tcodeSet.addAll(processTcodeMap.get(objectType));
							processTcodeMap.put(objectType, tcodeSet);
						} else {
							HashSet<String> tcodeSet = new HashSet<String>();
							if (tcode != null && !tcode.equalsIgnoreCase("")) {
								tcodeSet.addAll(splitTcodeswithoutXY(tcode));
							}
							processTcodeMap.put(objectType, tcodeSet);

						}

					}
				}
			}
			session.close();

		} catch (Exception e) {
			logger.error("Error DisplayGraphDaoImpl getTestingScopeProcessTabWithoutCount  " , e);
		}
		return processTcodeMap;

	}
	
	
	
	public Map<String, Integer> getTestingScopeTcodeObjectCount(final Long requestId) {
		Map<String, Integer> processTcodeMap = new HashMap<String, Integer>();
		session = sessionFactory.openSession();
		try {
			hql = "SELECT objecttype,standardTcode FROM ExtractedDatapojo where requestid=:requestID and standardTcode <> '' ";

			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);
			
			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] object : resultList) {
					if (object[0] != null && !((String) object[0]).equalsIgnoreCase("")) {
						int length=0;
						String objectType = (String) object[0];
						String standardTcode = (String) object[1];
						
						String[] dataArr = standardTcode.split(",");
						length = dataArr.length;
						
						
						if(processTcodeMap.containsKey(objectType))
						{
							length=length+processTcodeMap.get(objectType);
							processTcodeMap.put(objectType, length);
						}
						else
						{
						processTcodeMap.put(objectType, length);
						}
						}

					}
				}
			
			session.close();

		} catch (Exception e) {
			logger.error("Error DisplayGraphDaoImpl getTestingScopeTcodeObjectCount" , e);
		}
		return processTcodeMap;

	}
	
	
	
	
	@Override
	public Map<String, String> getTestingScopeProcessTabWithCount(final Long requestId) {
		Map<String, String> processTcodeMap = new HashMap<String, String>();
		session = sessionFactory.openSession();
		try {

			hql = "SELECT customTcodes,description FROM ExtractedDatapojo where requestid=:requestID";

			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] object : resultList) {
					if (object[0] != null && !((String) object[0]).equalsIgnoreCase("")) {
						String customTcodes = (String) object[0];
						String description = (String) object[1];
					
							if (customTcodes != null && !customTcodes.equalsIgnoreCase("")) {

								processTcodeMap.put(customTcodes, description);
							}
							
						} 

					}
				}
			
			session.close();

		} catch (Exception e) {
			logger.error("Error DisplayGraphDaoImpl getTestingScopeProcessTabWithCount " , e);
		}
		return processTcodeMap;

	}
	
	protected HashSet<String> splitTcodesBasedOnYZ(String tcode) {
		tcode = tcode.toUpperCase();
		String[] tcodeSplit = tcode.split(",");
		List<String> tcodeSplitFinal = new ArrayList<String>();
		
		for(String data : tcodeSplit)
		{
			if(data.toUpperCase().startsWith("Y")||data.toUpperCase().startsWith("Z"))
			{
				tcodeSplitFinal.add(data);
			}
		}
		
		HashSet<String> tcodeSet = new HashSet(tcodeSplitFinal);
		return tcodeSet;

	}
	
	protected HashSet<String> splitTcodeswithoutXY(String tcode) {
		tcode = tcode.toUpperCase();
		String[] tcodeSplit = tcode.split(",");
		List<String> tcodeSplitFinal = new ArrayList<String>();
		
		for(String data : tcodeSplit)
		{
			if((!data.toUpperCase().startsWith("Y"))||(!data.toUpperCase().startsWith("Z")))
			{
				tcodeSplitFinal.add(data);
			}
		}
		
		HashSet<String> tcodeSet = new HashSet(tcodeSplitFinal);
		return tcodeSet;

	}
	
	@Override
	public void saveGraphDataForExt(ExtensionScope extensionScope, Long requestId, HttpSession session) throws NoSuchMethodException, SecurityException {
		extensionScope.setRequestId(requestId);
		
		if(extensionScope.getRicefFlag()!=null && extensionScope.getRicefFlag().equalsIgnoreCase(ST03HanaConstant.RICEFW)) {
			insertRicefCounts(extensionScope);
		}else {
			Map<String, List<MetaData>> ricefComplexityCount = getRicefComplexity(requestId ,session);
			String targetSystem = getTargetSystem(requestId);
			
			Map<String, List<MetaData>> ricefExtensionCount = getRicefExtension(requestId ,session) ;
			
			extensionScope=separateComplexityCountByCategory(ricefComplexityCount,  extensionScope);
			
			extensionScope=separateExtensionCountByCategory(ricefExtensionCount,  extensionScope);
			
			extensionScope = setTotalComplexityCount(ricefComplexityCount, extensionScope);
			extensionScope = setTotalExtensionCount(ricefExtensionCount, targetSystem,extensionScope);
				
			insertRicefCounts(extensionScope);
		}
		
	}

	
	private void insertRicefCounts(ExtensionScope extensionScope) {
		
		Session session = sessionFactory.openSession();
		try {
			session.saveOrUpdate(extensionScope);
			session.close();
		} catch (Exception e) {
			e.getMessage();
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		logger.info("Updated Extension Scope Master !!!!!!!!!!!!!!!!! ");

	}

	private Map<String, List<MetaData>> getRicefComplexity(Long requestId ,HttpSession session) {
		
		Map<String, List<MetaData>> complexityCountMap = new LinkedHashMap<>();
		try {
			String hql ="select complexity, RICEF_CATEGORY, count(complexity) as count from extension_output where request_id="+requestId+" group by complexity, RICEF_CATEGORY";
			java.sql.Connection conn = null;
			java.sql.Statement stmt = null;
			ResultSet rs=null;
			
			conn = DBConfig.getJDBCConnection(session);
			conn.setAutoCommit(false);
				
			stmt = conn.createStatement();
			rs= stmt.executeQuery(hql);
			if (rs!= null) {
				while(rs.next()){
					MetaData metaData = new MetaData();
					
						String complexity =  rs.getString("complexity");
						String ricef_Category =  rs.getString("RICEF_CATEGORY");
						int count =  rs.getInt("count");
						if(!(ricef_Category.equalsIgnoreCase("")||ricef_Category.equalsIgnoreCase(ST03HanaConstant.OTHERS) || 
								ricef_Category.equals(ST03HanaConstant.CLASSICAL_DYNPRO))) {
							metaData.setComplexity(complexity);
							metaData.setCount(count);
							//metaDataList.add(metaData);
							if(complexityCountMap.containsKey(ricef_Category)) {
								List<MetaData> existingMetaDataList = complexityCountMap.get(ricef_Category);
								existingMetaDataList.add(metaData);
								complexityCountMap.put(ricef_Category, existingMetaDataList);
								
							}else {
								List<MetaData> metaDataList = new ArrayList<>();
								metaDataList.add(metaData);
								complexityCountMap.put(ricef_Category, metaDataList);
							}
							
							}
						} 

					}
	
		} catch (Exception e) {
			e.printStackTrace();
		}
		return complexityCountMap;
	}
	
	private Map<String, List<MetaData>> getRicefExtension(Long requestId ,HttpSession session) {
		
		Map<String, List<MetaData>> extCountMap = new HashMap<>();
		try {
			String hql ="select extensibility, RICEF_CATEGORY, count(extensibility) as count from extension_output where request_id="+requestId+" group by extensibility, RICEF_CATEGORY";
			java.sql.Connection conn = null;
			java.sql.Statement stmt = null;
			ResultSet rs=null;
			
			conn = DBConfig.getJDBCConnection(session);
			conn.setAutoCommit(false);
				
			stmt = conn.createStatement();
			rs= stmt.executeQuery(hql);
			if (rs!= null) {
				while(rs.next()){
					MetaData metaData = new MetaData();
					
						String extensibility =  rs.getString("extensibility");
						String ricef_Category =  rs.getString("RICEF_CATEGORY");
						int count =  rs.getInt("count");
						if(!(ricef_Category.equalsIgnoreCase("")||ricef_Category.equalsIgnoreCase(ST03HanaConstant.OTHERS) || 
								ricef_Category.equals(ST03HanaConstant.CLASSICAL_DYNPRO))) {
							metaData.setExtensibility(extensibility);
							metaData.setCount(count);
							//metaDataList.add(metaData);
							if(extCountMap.containsKey(ricef_Category)) {
								List<MetaData> existingMetaDataList = extCountMap.get(ricef_Category);
								existingMetaDataList.add(metaData);
								extCountMap.put(ricef_Category, existingMetaDataList);
								
							}else {
								List<MetaData> metaDataList = new ArrayList<>();
								metaDataList.add(metaData);
								extCountMap.put(ricef_Category, metaDataList);
							}
							
							}
						} 

					}
	
		} catch (Exception e) {
			e.printStackTrace();
		}
		return extCountMap;
	}
	
	private ExtensionScope separateComplexityCountByCategory(Map<String, List<MetaData>> complexityCountMap, ExtensionScope extensionScope) throws NoSuchMethodException, SecurityException {
		
		for (Entry<String, List<MetaData>> entry : complexityCountMap.entrySet()) {
			String category = entry.getKey().replaceAll(" ", "");
			category = category.substring(0, 1).toUpperCase() + category.substring(1).toLowerCase();
			String setComplexity = "set" + category + "_Complexity";
			
			StringBuffer value = new StringBuffer();
			Map<String, Integer> compCountMap = new HashMap<>();
			
			List<MetaData> metaDataList = entry.getValue();
			
			for(MetaData metaData:metaDataList) {
				String complexity = metaData.getComplexity();
				Integer count = metaData.getCount();
				compCountMap.put(complexity, count);	
			}
			
			for (Entry<String, Integer> complexityMap : compCountMap.entrySet()) {
				value.append(complexityMap.getKey()).append(":").append(complexityMap.getValue()).append("|");
			}
					
			Class cls = extensionScope.getClass(); 
			
			Method method = cls.getDeclaredMethod(setComplexity, String.class);
			
			try {
				method.invoke(extensionScope, value.toString());
			} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
				logger.error("Error while setting Counts...");
				e.printStackTrace();
			}
		}

		return extensionScope;
	}
	
private ExtensionScope separateExtensionCountByCategory(Map<String, List<MetaData>> extensionCountMap, ExtensionScope extensionScope) throws NoSuchMethodException, SecurityException {
		
		for (Entry<String, List<MetaData>> entry : extensionCountMap.entrySet()) {
			String category = entry.getKey().replaceAll(" ", "");
			category = category.substring(0, 1).toUpperCase() + category.substring(1).toLowerCase();
			String setExtension = "set" + category + "_Extension";
			
			StringBuffer value = new StringBuffer();
			Map<String, Integer> extCountMap = new HashMap<>();
			
			List<MetaData> metaDataList = entry.getValue();
			
			for(MetaData metaData:metaDataList) {
				String extension = metaData.getExtensibility();
				Integer count = metaData.getCount();
				extCountMap.put(extension, count);	
			}
			
			for (Entry<String, Integer> extEntry : extCountMap.entrySet()) {
				value.append(extEntry.getKey()).append(":").append(extEntry.getValue()).append("|");
			}
					
			Class cls = extensionScope.getClass(); 
			
			Method method = cls.getDeclaredMethod(setExtension, String.class);
				
					try {
						method.invoke(extensionScope, value.toString());
					} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
						logger.error("Error while setting Counts...");
						e.printStackTrace();
					}
				
		
		}

		return extensionScope;
	}
	
	@Override
	public List<ExtensionScope> getExtensionScopeMaster(long requestId) {

		session = sessionFactory.openSession();

		try {
			final Criteria criteria = session.createCriteria(ExtensionScope.class);
			criteria.add(Restrictions.eq("requestId", requestId));
			return criteria.list();
		} catch (Exception e) {
			e.printStackTrace();
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);

		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	private ExtensionScope setTotalComplexityCount(Map<String, List<MetaData>> ricefComplexityCount, ExtensionScope extensionScope) {
		StringBuffer finalValue = new StringBuffer();
		for (Entry<String, List<MetaData>> entry : ricefComplexityCount.entrySet()) {
			
			String category = entry.getKey().toUpperCase();
			if(!ST03HanaConstant.CAT_LIST.contains(category)) {
				continue;
			}
			List<MetaData> value = entry.getValue();
			finalValue.append(category);
			
			Integer low = 0;
			Integer medium =0;
			Integer high=0;
			
			/*
			 * for(MetaData metaData :value) { String complexity = metaData.getComplexity();
			 * Integer count = metaData.getCount();
			 * finalValue.append(":").append(complexity).append(":").append(count); }
			 */
			
			for(MetaData metaData :value) {
				String complexity = metaData.getComplexity();
				if(complexity.equalsIgnoreCase(ST03HanaConstant.LOW)) {
					low=metaData.getCount();
				}
				if(complexity.equalsIgnoreCase(ST03HanaConstant.MEDIUM)) {
					medium = metaData.getCount();
				}
				if(complexity.equalsIgnoreCase(ST03HanaConstant.HIGH)) {
					high=metaData.getCount();
				}
			}
			finalValue.append(":").append(ST03HanaConstant.LOW).append(":").append(low);
			finalValue.append(":").append(ST03HanaConstant.MEDIUM).append(":").append(medium);
			finalValue.append(":").append(ST03HanaConstant.HIGH).append(":").append(high);
			finalValue.append("|");
		}
		
		extensionScope.setStackedComplexityCount(finalValue.toString());
		return extensionScope;
		
	}
	
	private ExtensionScope setTotalExtensionCount(Map<String, List<MetaData>> ricefExtensionCount, String targetSystem, ExtensionScope extensionScope) {
		
		StringBuffer finalValue = new StringBuffer();
		for (Entry<String, List<MetaData>> entry : ricefExtensionCount.entrySet()) {
			
			String category = entry.getKey().toUpperCase();
			if(!ST03HanaConstant.CAT_LIST.contains(category)) {
				continue;
			}
			List<MetaData> value = entry.getValue();
			
			Integer sideByside =0;
			Integer inApp = 0;
			Integer classical =0;
			Integer ste=0;
			Integer mte=0;
			
			finalValue.append(category);
			/*
			 * for(MetaData metaData :value) { String extensibility =
			 * metaData.getExtensibility(); Integer count = metaData.getCount();
			 * finalValue.append(":").append(extensibility).append(":").append(count); }
			 */
			for(MetaData metaData :value) {
				
				String extensibility = metaData.getExtensibility();
				if(extensibility.equalsIgnoreCase(ST03HanaConstant.SIDE_BY_SIDE)) {
					sideByside = metaData.getCount();
				}
				if(extensibility.equalsIgnoreCase(ST03HanaConstant.IN_APP)) {
					inApp = metaData.getCount();
				}
				if(extensibility.equalsIgnoreCase(ST03HanaConstant.CLASSICAL)) {
					classical = metaData.getCount();
				}
				if(extensibility.equalsIgnoreCase(ST03HanaConstant.EXTENSION_NOT_POSSIBLE)) {
					ste = metaData.getCount();
				}
				if(extensibility.equalsIgnoreCase(ST03HanaConstant.EXTENSION_NOT_AVAILABLE)) {
					mte = metaData.getCount();
				}
			}
			finalValue.append(":").append(ST03HanaConstant.SIDE_BY_SIDE).append(":").append(sideByside);
			finalValue.append(":").append(ST03HanaConstant.IN_APP).append(":").append(inApp);
			if(!targetSystem.equalsIgnoreCase(ST03HanaConstant.S4HANA_CloudMT)) {
				finalValue.append(":").append(ST03HanaConstant.CLASSICAL).append(":").append(classical);
			}
			if(targetSystem.equalsIgnoreCase(ST03HanaConstant.S4HANA_CloudST)) {
				finalValue.append(":").append(ST03HanaConstant.EXTENSION_NOT_POSSIBLE).append(":").append(ste);
			}
			if(targetSystem.equalsIgnoreCase(ST03HanaConstant.S4HANA_CloudMT)) {
				finalValue.append(":").append(ST03HanaConstant.EXTENSION_NOT_AVAILABLE).append(":").append(mte);
			}
			
			finalValue.append("|");
		}
		
		extensionScope.setStackedExtensionCount(finalValue.toString());
		
		return extensionScope;
	}
	
	public String getTargetSystem(long requestId) {
		final Session session=sessionFactory.openSession();
		//RequestForm requestForm = null;
		String targetSystem = null;
		
		try{
			final Criteria criteria=session.createCriteria(RequestForm.class);
			final ProjectionList projection = Projections.projectionList();
			projection.add(Projections.property("targetVersion"));
		
			criteria.add(Restrictions.eq("requestID",requestId));
			criteria.setProjection(projection);
			Object result = criteria.uniqueResult();
			if(result!=null) {
				targetSystem =  (String) result;
			}
			return targetSystem;
		
		} catch(Exception e) {
			logger.error("Error DisplayGraphDaoImpl getTargetSystem" , e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if(session!=null){
				session.close();
			}
		}
	}
}

// CR-12.3 End
