/* CR No.			- 	Requirement		- 	Date 		-		Modified By  *
 * 
 * CR-1.0: - Update the automation_Status according to Sel_line -20/12/16 - monika.mishra
 * 
 * CR-6.0:- Give accessibility of View Inventory, Tabular View,Graphical View and Download buttons to admin -5/1/17 -monika.mishra
 * 
 * CR-7.0:- Downloaded excel sheets should be modified for the admin & Client role -5/1/17 - monika.mishra
 * 
 * CR-9.0:- Manual upload for Estimator & assuptions -17/01/17 -monika.mishra
 * 
 * CR-13.0:- New Output Sheet implemetation -03/03/17 -monika.mishra
 * 
 * CR-26.0:-adding 3 New Sheets implementation -25/07/17-rohan.a.mehra
 * 
 * CR-27.0:-Populating Data on Fiori reporting DHL sheet-3/08/17-rohan.a.mehra
 * 
 * CR-28.0:- Add col Total Line Scanned -24/07/17 -monika.mishra
 * 
 * CR-35.0:-Adding new Templates-15/09/17-rohan.a.mehra
 * 
 * CR-36.0:-Removing col Error type from detail sheet-18/09/17-rohan.a.mehra
 * 
 * CR-40.0:Adding Statement Col in final output sheet-3/1/2018-rohan.a.mehra
 * 
 * CR-42.0:Changing estimation Sheet and assumption sheet-8/1/2018-rohan.a.mehra
 * 
 * CR-52.0:- AIES Tool Integration-10/11/2017 - monika.mishra
 * 
 * CR-56-Hana new Estimates-9/3/2018-rohan.a.mehra
 * 
 * */

package com.accenture.displaygraph.controller;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.accenture.S4.Controller.S4ProcessingController;
import com.accenture.S4.models.S4ImpactedObjectList;
import com.accenture.S4.models.S4InventoryList;
import com.accenture.client.model.RequestForm;
import com.accenture.client.model.RequestInventory;
import com.accenture.constant.Hana_Profiler_Constant;
import com.accenture.controller.AbstractBaseController;
import com.accenture.displaygrid.model.HanaAssumption;
import com.accenture.displaygrid.model.HanaEstimator;
import com.accenture.displaygrid.model.HanaProfile;
import com.accenture.master.ProcessedRequestDetail;
import com.accenture.poc.model.JqGridResponse;
import com.accenture.utility.HANAUtility;
import com.google.common.collect.Multimap;

@Controller
@SessionAttributes("User")

public class DisplayGraphControler extends S4ProcessingController {

/*	@RequestMapping(value = "/admin/grph", method = RequestMethod.GET)
	public ModelAndView graphView(ModelAndView model,
			@RequestParam(required = false, defaultValue = "") final String requestId) {
		ModelAndView modenAndView = new ModelAndView("admin/requestGraph");
		// modenAndView.addObject("requestIDList",
		// getGraphDao().getRequestList());
		if (StringUtils.isBlank(requestId) || Hana_Profiler_Constant.FOUR_ZEROS.equals(requestId))
			return modenAndView;
		final RequestInventory requestInventory = getClientRequestInventoryDAO()
				.getRequestInventory(Long.parseLong(requestId));
		 CR-9.0 Monika 
		if (requestInventory != null && (StringUtils.equals(requestInventory.getRequestStatus(),
				Hana_Profiler_Constant.HANAREFININGSUCCESS_STATUS) || StringUtils.equals(requestInventory.getRequestStatus(),
						Hana_Profiler_Constant.HANAREFININGCOMPLETED_STATUS))) {
			modenAndView.addObject("cateGory", getGraphDao().getGraphCountCategory(Long.parseLong(requestId)));
			modenAndView.addObject("subCateGory", getGraphDao().getGraphCountSubCategory(Long.parseLong(requestId)));
			modenAndView.addObject("usedUnused", getGraphDao().getGraphCountUsedUnused(Long.parseLong(requestId)));
			modenAndView.addObject("impact", getGraphDao().getGraphCountImpact(Long.parseLong(requestId)));
		} else {
			modenAndView.addObject("requestIdNotValidErrMsg", "Please enter valid Request ID");
		}
		modenAndView.addObject("requestId", requestId);
		return modenAndView;
	}

	 CR- 7.0 
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/downloadSummarySheet/{requestID}/{userRole}/{userAccess}", method = RequestMethod.GET)
	public synchronized String downloadTransportRequestFile(@PathVariable("requestID") Long requestID,@PathVariable("userAccess") final String userAccess,@PathVariable("userRole") final String userRole, Model model,
			HttpServletResponse response, HttpServletRequest request, final RedirectAttributes redirectAttributes)
					throws Exception {

		
		 * CR- 13.0 assigning different template based on ACCESS and User Role
		 
		String graphTemplete = "";

		if (Hana_Profiler_Constant.ACCESS_FALSE.equalsIgnoreCase(userAccess)) {
			graphTemplete = request.getSession().getServletContext()
					.getRealPath("/staticResources/GraphTemplate/Invent_Summary_Temp_Client.xlsx");
		} else if (Hana_Profiler_Constant.ACCESS_TRUE.equalsIgnoreCase(userAccess)
				&& Hana_Profiler_Constant.CLIENT.equalsIgnoreCase(userRole)) {
			graphTemplete = request.getSession().getServletContext()
					.getRealPath("/staticResources/GraphTemplate/Invent_Complete_Temp_Client.xlsx");
		} else if (Hana_Profiler_Constant.ACCESS_TRUE.equalsIgnoreCase(userAccess)
				&& Hana_Profiler_Constant.ADMIN.equalsIgnoreCase(userRole)) {
			graphTemplete = request.getSession().getServletContext()
					.getRealPath("/staticResources/GraphTemplate/Invent_Complete_Temp_admin.xlsx");
		}

		List<HanaProfile> inventoryList = new ArrayList<HanaProfile>();
		inventoryList = getDaoIntf().GetList(requestID, 0, 0);
		// CR-26: New Output Sheet implementation
		List<HanaProfile> fioriList = inventoryList;

		if (inventoryList.isEmpty()) {
			redirectAttributes.addFlashAttribute("donLoadXlsxError", "No Records Found To Download");
			return "redirect:/client/requestDetails/{requestID}";
		}

		final RequestForm requestForm = getRequestDetails().getRequestObj(requestID);

		XSSFWorkbook workbook = new XSSFWorkbook(OPCPackage.open(new FileInputStream(graphTemplete)));
		SXSSFWorkbook workbookTemp = new SXSSFWorkbook(workbook);
		workbookTemp.setCompressTempFiles(true);
		
		//Writing Inventory
		XSSFSheet inventory=workbookTemp.getXSSFWorkbook().getSheetAt(0);
		writeInventory(inventory,requestID);

		//Writing Impacted Object Type
		XSSFSheet impactObjSheet=workbookTemp.getXSSFWorkbook().getSheetAt(1);
		writeImpactObjSheet(impactObjSheet,requestID);

		// CR-13.0 Writing Detail report Sheets
		SXSSFSheet inventorySheet = (SXSSFSheet) workbookTemp.getSheetAt(2);
		inventorySheet.setRandomAccessWindowSize(100);
		wroteInventorySheet(inventorySheet, inventoryList);

		// CR-26: Writing Fiori sheet
		SXSSFSheet fioriSheet = (SXSSFSheet) workbookTemp.getSheetAt(4);
		fioriSheet.setRandomAccessWindowSize(100);
		wroteFioriSheet(fioriSheet, fioriList);

		// CR:27 Populating Data on Fiori reporting DHL a sheet
		XSSFSheet fiorireportingdhlSheet = workbookTemp.getXSSFWorkbook().getSheetAt(6);
		wroteFioriReportingDHLSheet(requestID, fiorireportingdhlSheet);

		// CR-13.0 Writing Estimations Sheets
		if (Hana_Profiler_Constant.ACCESS_TRUE.equalsIgnoreCase(userAccess)
				&& Hana_Profiler_Constant.ADMIN.equalsIgnoreCase(userRole)) {
			XSSFSheet hanaEstimatorSheet = workbookTemp.getXSSFWorkbook().getSheetAt(7);
			XSSFSheet hanaStaffingSheet = workbookTemp.getXSSFWorkbook().getSheetAt(9);
			wroteEstimationsSheetForAdmin(requestID, hanaEstimatorSheet, hanaStaffingSheet);

		} else if (Hana_Profiler_Constant.ACCESS_TRUE.equalsIgnoreCase(userAccess)
				&& Hana_Profiler_Constant.CLIENT.equalsIgnoreCase(userRole)) {
			XSSFSheet hanaEstimatorSheet = workbookTemp.getXSSFWorkbook().getSheetAt(7);
			XSSFSheet hanaStaffingSheet = workbookTemp.getXSSFWorkbook().getSheetAt(9);
			wroteEstimationsSheetForClient(requestID, hanaEstimatorSheet, hanaStaffingSheet);
			// Writing Assumptions Sheets
			XSSFSheet assumptionSheet = workbookTemp.getXSSFWorkbook().getSheetAt(8);
			wroteAssumptionSheetForClient(requestID, assumptionSheet);

		}

		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		workbookTemp.write(bos);
		bos.close();

		byte[] bytes = bos.toByteArray();
		getFileDownload()
				.downloadFile(bytes, response,
						HANAUtility.join("_", "HANA Profiler", requestForm.getClientName(),
								requestForm.getSourceVersion(), requestForm.getTargetVersion(), requestID.toString())
								+ ".xlsx");

		return null;
	}
	*/
	
/*	private void writeImpactObjSheet(XSSFSheet impactObjSheet, Long requestID) {
		int rowIndex=4;
		List<S4ImpactedObjectList> impactObjList=getGraphS4DAO().getImpactedObjList(requestID)	;	
		if(null!=impactObjList && !impactObjList.isEmpty()){
			Iterator<S4ImpactedObjectList> impactObjItr=impactObjList.iterator();
			while(impactObjItr.hasNext()){

				S4ImpactedObjectList impactObj=impactObjItr.next();
				Row impactObjRow=impactObjSheet.createRow(rowIndex);

				impactObjRow.createCell(0).setCellValue(impactObj.getObjType());
				impactObjRow.createCell(1).setCellValue(impactObj.getObjName());
				impactObjRow.createCell(2).setCellValue(impactObj.getUsage());
				rowIndex++;
			}
		}
		System.out.println("Sucessfully Wrote Impact Sheet:::%%%%%%%");
	}


	private void writeInventory(XSSFSheet inventorySheet, Long requestID) {
		int rowIndex=4;
		List<S4InventoryList> inventoryList= getGraphS4DAO().getInventory(requestID);

		if(null!= inventoryList && !inventoryList.isEmpty()){
			Iterator<S4InventoryList> inventoryItr=inventoryList.iterator();
			while(inventoryItr.hasNext()){

				S4InventoryList inventory=inventoryItr.next();
				Row inventryRow=inventorySheet.createRow(rowIndex);

				inventryRow.createCell(0).setCellValue(inventory.getObjType());
				inventryRow.createCell(1).setCellValue(inventory.getObjName());
				inventryRow.createCell(2).setCellValue(inventory.getUsage());
				rowIndex++;
			}
		}
		System.out.println("Sucessfully Wrote Inventory Sheet:::%%%%%%%");
	}

	 CR-9.0 
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/downloadEstimatorAssumptions/{requestID}", method = RequestMethod.GET)
	public synchronized String downloadEstimatorAssumptions(@PathVariable("requestID") Long requestID, Model model,
			HttpServletResponse response, HttpServletRequest request, final RedirectAttributes redirectAttributes)
			throws Exception {

		String graphTemplete = request.getSession().getServletContext()
				.getRealPath("/staticResources/GraphTemplate/Estimator_Assumption_Client.xlsx");

		final RequestForm requestForm = getRequestDetails().getRequestObj(requestID);

		XSSFWorkbook workbook = new XSSFWorkbook(OPCPackage.open(new FileInputStream(graphTemplete)));
		@SuppressWarnings("resource")
		SXSSFWorkbook workbookTemp = new SXSSFWorkbook(workbook);
		workbookTemp.setCompressTempFiles(true);

		XSSFSheet estimatorSheet = workbookTemp.getXSSFWorkbook().getSheetAt(0);
		XSSFSheet assumptionSheet = workbookTemp.getXSSFWorkbook().getSheetAt(1);
		XSSFSheet hanaStaffingSheet = workbookTemp.getXSSFWorkbook().getSheetAt(2);
		*//** Section For Estimator Start **//*
		wroteEstimationsSheetForClient(requestID, estimatorSheet, hanaStaffingSheet);
		*//** Section For Assumptions Start **//*
		wroteAssumptionSheetForClient(requestID, assumptionSheet);

		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		workbookTemp.write(bos);
		bos.close();

		byte[] bytes = bos.toByteArray();
		getFileDownload()
				.downloadFile(bytes, response,
						HANAUtility.join("_", "HANA Profiler", requestForm.getClientName(),
								requestForm.getSourceVersion(), requestForm.getTargetVersion(), requestID.toString())
								+ ".xlsx");

		return null;
	}

	// CR-27: for populating data on Fiori reporting DHL sheet
	private void wroteFioriReportingDHLSheet(Long requestID, XSSFSheet fiorireportingdhlsheet) {

		Map<String, Integer> count = getGraphDao().getUniqueOdataCount(requestID);

		int counta, counti;

		counta = ((count.containsKey("A")) ? count.get("A") : 0);// getting count of unique object with Odata -A
		counti = ((count.containsKey("I")) ? count.get("I") : 0);// getting count of unique object with Odata -I

		fiorireportingdhlsheet.getRow(3).getCell(10).setCellValue(counta + counti);
		fiorireportingdhlsheet.getRow(3).getCell(11).setCellValue(counta);
		fiorireportingdhlsheet.getRow(3).getCell(12).setCellValue(counti);

	}

	// CR-26: for Writing data on Fiori sheet
	private void wroteFioriSheet(SXSSFSheet fioriSheet, List<HanaProfile> fioriList) {

		Map<String, String> errorType = getGraphDao().getOperation_ErrorMap();
		Map<String, String> secondSubCat = getGraphDao().getSecond_SubCat();

		int j = 0;
		Row fioriRow;
		for (int i = 0; i < fioriList.size(); i++) {

			// Displaying data for required operation codes only
			if (fioriList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_59)
					|| fioriList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_60)
					|| fioriList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_61)
					|| fioriList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_62)
					|| fioriList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_63)
					|| fioriList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_64)
					|| fioriList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_65)
					|| fioriList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_66)
					|| fioriList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_71)
					|| fioriList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_72)
					|| fioriList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_73)
					|| fioriList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_74)
					|| fioriList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_75)
					|| fioriList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_76)) {

				fioriRow = fioriSheet.createRow(++j);

				fioriRow.createCell(0).setCellValue(fioriList.get(i).getObject_Type());
				fioriRow.createCell(1).setCellValue(fioriList.get(i).getObj_Name());
				fioriRow.createCell(2).setCellValue(fioriList.get(i).getSub_Program());
				fioriRow.createCell(3).setCellValue(fioriList.get(i).getOdata());
				fioriRow.createCell(4).setCellValue(fioriList.get(i).getSub_Type());
				fioriRow.createCell(5).setCellValue(fioriList.get(i).getLine_Number());
				fioriRow.createCell(7).setCellValue(fioriList.get(i).getCategory());
				fioriRow.createCell(8).setCellValue(fioriList.get(i).getSubcategory());

				if (secondSubCat != null && !secondSubCat.isEmpty()
						&& secondSubCat.containsKey(fioriList.get(i).getOpertaion())) {

					fioriRow.createCell(9).setCellValue(secondSubCat.get(fioriList.get(i).getOpertaion()));
				} else {
					fioriRow.createCell(9).setCellValue("");
				}

				fioriRow.createCell(11).setCellValue(fioriList.get(i).getHigh_lvl_desc());
				fioriRow.createCell(12).setCellValue(fioriList.get(i).getImpact());

				if (null != fioriList.get(i).getAutomation_status()) {
					fioriRow.createCell(13).setCellValue(fioriList.get(i).getAutomation_status());

				} else {
					fioriRow.createCell(13).setCellValue("");
				}
				fioriRow.createCell(6).setCellValue(fioriList.get(i).getOperation_code());

				if ("Mandatory".equals(fioriList.get(i).getCategory())) {
					if (errorType != null && !errorType.isEmpty()
							&& errorType.containsKey(fioriList.get(i).getOpertaion())) {
						fioriRow.createCell(10)
								.setCellValue((errorType.get(fioriList.get(i).getOpertaion())).equals("") ? "Error"
										: errorType.get(fioriList.get(i).getOpertaion()));
					}
				} else {
					fioriRow.createCell(10).setCellValue("");
				}

			}
		}

	}

	// CR-13.0 Writing Inventory Sheets
	private void wroteInventorySheet(SXSSFSheet inventorySheet, List<HanaProfile> inventoryList) {

		Map<String, String> errorType = getGraphDao().getOperation_ErrorMap();
		Map<String, String> secondSubCat = getGraphDao().getSecond_SubCat();
		// CR-26: for not adding data on inventory sheet for these Opcodes
		int j = 0;
		Row inventoryRow;
		for (int i = 0; i < inventoryList.size(); i++) {

			// for not displaying data,for the required Opertion codes on sheet
			if (!inventoryList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_59)
					&& !inventoryList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_60)
					&& !inventoryList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_61)
					&& !inventoryList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_62)
					&& !inventoryList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_63)
					&& !inventoryList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_64)
					&& !inventoryList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_65)
					&& !inventoryList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_66)
					&& !inventoryList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_71)
					&& !inventoryList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_72)
					&& !inventoryList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_73)
					&& !inventoryList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_74)
					&& !inventoryList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_75)
					&& !inventoryList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_76)) {
				inventoryRow = inventorySheet.createRow(++j);
				inventoryRow.createCell(0).setCellValue(inventoryList.get(i).getObject_Type());
				inventoryRow.createCell(1).setCellValue(inventoryList.get(i).getObj_Name());
				inventoryRow.createCell(2).setCellValue(inventoryList.get(i).getSub_Program());
				inventoryRow.createCell(3).setCellValue(inventoryList.get(i).getUsed_Unused());
				inventoryRow.createCell(4).setCellValue(inventoryList.get(i).getDialog_Steps());
				inventoryRow.createCell(5).setCellValue(inventoryList.get(i).getSub_Type());
				inventoryRow.createCell(25).setCellValue(inventoryList.get(i).getLine_Number());
				inventoryRow.createCell(6).setCellValue(inventoryList.get(i).getCategory());
				inventoryRow.createCell(7).setCellValue(inventoryList.get(i).getSubcategory());

				 CR-13.0 
				if (secondSubCat != null && !secondSubCat.isEmpty()
						&& secondSubCat.containsKey(inventoryList.get(i).getOpertaion())) {
					inventoryRow.createCell(8).setCellValue(secondSubCat.get(inventoryList.get(i).getOpertaion()));
				} else {
					inventoryRow.createCell(8).setCellValue("");
				}
				inventoryRow.createCell(9).setCellValue(inventoryList.get(i).getOpertaion());
				inventoryRow.createCell(10).setCellValue(inventoryList.get(i).getHigh_lvl_desc());

				inventoryRow.createCell(11).setCellValue(inventoryList.get(i).getLevels());
				inventoryRow.createCell(12).setCellValue(inventoryList.get(i).getTables());

				inventoryRow.createCell(13).setCellValue(inventoryList.get(i).getJoins());

				inventoryRow.createCell(14).setCellValue(inventoryList.get(i).getTable_Type());
				inventoryRow.createCell(15).setCellValue(inventoryList.get(i).getKeys());
				inventoryRow.createCell(16).setCellValue(inventoryList.get(i).getWhere_Condition());
				inventoryRow.createCell(17).setCellValue(inventoryList.get(i).getJoin_Type());
				inventoryRow.createCell(18).setCellValue(inventoryList.get(i).getInfo());
				inventoryRow.createCell(19).setCellValue(inventoryList.get(i).getImpact());
				inventoryRow.createCell(20).setCellValue(inventoryList.get(i).getDB());
				inventoryRow.createCell(21).setCellValue(inventoryList.get(i).getChange());
				//// CR-1.0:: writing automation_status in download sheet
				if (null != inventoryList.get(i).getAutomation_status()) {
					inventoryRow.createCell(22).setCellValue(inventoryList.get(i).getAutomation_status());
				} else {
					inventoryRow.createCell(22).setCellValue("");
				}
				inventoryRow.createCell(23).setCellValue(inventoryList.get(i).getOperation_code());

				
				 * if ("Mandatory".equals(inventoryList.get(i).getCategory())) { if (errorType
				 * != null && !errorType.isEmpty() &&
				 * errorType.containsKey(inventoryList.get(i).getOpertaion())) {
				 * inventoryRow.createCell(25)
				 * .setCellValue((errorType.get(inventoryList.get(i).getOpertaion())).equals("")
				 * ? "Error" : errorType.get(inventoryList.get(i).getOpertaion())); } }
				 * 
				 * else { inventoryRow.createCell(25).setCellValue(""); }
				 

				inventoryRow.createCell(24).setCellValue(inventoryList.get(i).getTotalLineScanned());
				// CR:39- for displaying code in final output sheet
				inventoryRow.createCell(26).setCellValue(inventoryList.get(i).getCode());
			}
		}
	}

	// CR-13.0 Writing Estimations Sheets for Admin
	*//**
	 * Section For Estimator Start
	 * 
	 * @param hanaStaffingSheet
	 **//*
	private void wroteEstimationsSheetForAdmin(Long requestID, XSSFSheet hanaEstimator, XSSFSheet hanaStaffingSheet) {

		String clientNameSpace_Name = getGraphDao().getClientNameSpace_Name(requestID);
		
		//CR-56
		//CR-56 Removed in this CR as asked by malika to be added in future as os now giving blank. 
		Map<String, String> CustFugrCount = getGraphDao().getTotalCountCustomObjets(requestID, "'FUGR'");
		Map<String, String> CustProgCount = getGraphDao().getTotalCountCustomObjets(requestID, "'PROG'");
		Map<String, String> CustClasCount = getGraphDao().getTotalCountCustomObjets(requestID, "'CLAS'");
		Map<String, String> CustExitCount = getGraphDao().getTotalCountCustomObjets(requestID, "'USER EXIT'");
		Map<String, String> CustFormCount = getGraphDao().getTotalCountCustomObjets(requestID, "'FORM','SSFO','SFPI'");
		Map<String, String> CustEnhanCount = getGraphDao().getTotalCountCustomObjets(requestID, "'ENHC','ENHO','ENHS'");
		Map<String, String> CustWebCount = getGraphDao().getTotalCountCustomObjets(requestID, "'WDYN'");
		Map<String, String> CustLsmwCount =getGraphDao().getTotalCountCustomObjets(requestID, "'LSMW'");
		 

		hanaEstimator.getRow(3).getCell(2).setCellValue(Integer.parseInt(CustFugrCount.get("Count")));
		hanaEstimator.getRow(3).getCell(5).setCellValue(Integer.parseInt(CustProgCount.get("Count")));
		hanaEstimator.getRow(3).getCell(8).setCellValue(Integer.parseInt(CustClasCount.get("Count")));
		hanaEstimator.getRow(3).getCell(23).setCellValue(Integer.parseInt(CustExitCount.get("Count")));
		hanaEstimator.getRow(3).getCell(11).setCellValue(Integer.parseInt(CustFormCount.get("Count")));
		hanaEstimator.getRow(3).getCell(14).setCellValue(Integer.parseInt(CustEnhanCount.get("Count")));
		hanaEstimator.getRow(3).getCell(17).setCellValue(Integer.parseInt(CustWebCount.get("Count")));
		hanaEstimator.getRow(3).getCell(20).setCellValue(Integer.parseInt(CustLsmwCount.get("Count")));
		 
		hanaEstimator.getRow(31).getCell(2).setCellValue(Integer.parseInt(CustFugrCount.get("Count")));
		hanaEstimator.getRow(31).getCell(5).setCellValue(Integer.parseInt(CustProgCount.get("Count")));
		hanaEstimator.getRow(31).getCell(8).setCellValue(Integer.parseInt(CustClasCount.get("Count")));
		hanaEstimator.getRow(31).getCell(23).setCellValue(Integer.parseInt(CustExitCount.get("Count")));
		hanaEstimator.getRow(31).getCell(11).setCellValue(Integer.parseInt(CustFormCount.get("Count")));
		hanaEstimator.getRow(31).getCell(14).setCellValue(Integer.parseInt(CustEnhanCount.get("Count")));
		hanaEstimator.getRow(31).getCell(17).setCellValue(Integer.parseInt(CustWebCount.get("Count")));
		hanaEstimator.getRow(31).getCell(20).setCellValue(Integer.parseInt(CustLsmwCount.get("Count")));
	
		
		
		
		//CR-56:Change in Hana estimation addition of used estimation
		Multimap<String,BigInteger> DefectObjCountMap=getGraphDao().getTotal_DefectObjectCount(requestID,clientNameSpace_Name);
		int DefectFugrCount=0;
		int DefectProgCount=0;
		int DefectClasCount=0;
		int DefectFormCount=0;
		int DefectEnhanCount=0;
		int DefectWebCount=0;
		int DefectLsmwCount=0;
		int DefectExitCount=0;
		for (Entry<String, BigInteger> entry : DefectObjCountMap.entries()) {
			if((entry.getKey()).equalsIgnoreCase("FUGR"))
			{
				DefectFugrCount=(entry.getValue()).intValue();
				
			}
			else if((entry.getKey()).equalsIgnoreCase("PROG"))
			{
				DefectProgCount=(entry.getValue()).intValue();
				
			}
			else if((entry.getKey()).equalsIgnoreCase("CLAS"))
			{
				DefectClasCount=(entry.getValue()).intValue();
				
			}
			else if((entry.getKey()).equalsIgnoreCase("USER EXIT"))
			{
				DefectExitCount=(entry.getValue()).intValue();
				
			}
			else if((entry.getKey()).equalsIgnoreCase("FORM"))
			{
				DefectFormCount+=(entry.getValue()).intValue();
				
			}
			else if((entry.getKey()).equalsIgnoreCase("SSFO"))
			{
				DefectFormCount+=(entry.getValue()).intValue();
				
			}
			else if((entry.getKey()).equalsIgnoreCase("SFPI"))
			{
				DefectFormCount+=(entry.getValue()).intValue();
				
			}
			else if((entry.getKey()).equalsIgnoreCase("ENHC"))
			{
				DefectEnhanCount+=(entry.getValue()).intValue();
				
			}
			else if((entry.getKey()).equalsIgnoreCase("ENHO"))
			{
				DefectEnhanCount+=(entry.getValue()).intValue();
				
			}
			else if((entry.getKey()).equalsIgnoreCase("ENHS"))
			{
				DefectEnhanCount+=(entry.getValue()).intValue();
				
			}
			else if((entry.getKey()).equalsIgnoreCase("WDYN"))
			{
				DefectWebCount=(entry.getValue()).intValue();
				
			}
			else if((entry.getKey()).equalsIgnoreCase("LSMW"))
			{
				DefectLsmwCount=(entry.getValue()).intValue();
				
			}
		}
		hanaEstimator.getRow(5).getCell(2).setCellValue(DefectFugrCount);
		hanaEstimator.getRow(5).getCell(5).setCellValue(DefectProgCount);
		hanaEstimator.getRow(5).getCell(8).setCellValue(DefectClasCount);
		hanaEstimator.getRow(5).getCell(11).setCellValue(DefectFormCount);
		hanaEstimator.getRow(5).getCell(14).setCellValue(DefectEnhanCount);
		hanaEstimator.getRow(5).getCell(17).setCellValue(DefectWebCount);
		hanaEstimator.getRow(5).getCell(20).setCellValue(DefectLsmwCount);
		hanaEstimator.getRow(5).getCell(23).setCellValue(DefectExitCount);
		
		Multimap<String,BigInteger> DefectUsedObjCountMap=getGraphDao().getTotal_UsedDefectObjectCount(requestID,clientNameSpace_Name);
		int DefectUsedFugrCount=0;
		int DefectUsedProgCount=0;
		int DefectUsedClasCount=0;
		int DefectUsedFormCount=0;
		int DefectUsedEnhanCount=0;
		int DefectUsedWebCount=0;
		int DefectUsedLsmwCount=0;
		int DefectUsedExitCount=0;
		for (Entry<String, BigInteger> entry : DefectUsedObjCountMap.entries()) {
			if((entry.getKey()).equalsIgnoreCase("FUGR"))
			{
				DefectUsedFugrCount=(entry.getValue()).intValue();
				
			}
			else if((entry.getKey()).equalsIgnoreCase("PROG"))
			{
				DefectUsedProgCount=(entry.getValue()).intValue();
				
			}
			else if((entry.getKey()).equalsIgnoreCase("CLAS"))
			{
				DefectUsedClasCount=(entry.getValue()).intValue();
				
			}
			else if((entry.getKey()).equalsIgnoreCase("USER EXIT"))
			{
				DefectUsedExitCount=(entry.getValue()).intValue();
				
			}
			else if((entry.getKey()).equalsIgnoreCase("FORM"))
			{
				DefectUsedFormCount+=(entry.getValue()).intValue();
				
			}
			else if((entry.getKey()).equalsIgnoreCase("SSFO"))
			{
				DefectUsedFormCount+=(entry.getValue()).intValue();
				
			}
			else if((entry.getKey()).equalsIgnoreCase("SFPI"))
			{
				DefectUsedFormCount+=(entry.getValue()).intValue();
				
			}
			else if((entry.getKey()).equalsIgnoreCase("ENHC"))
			{
				DefectUsedEnhanCount+=(entry.getValue()).intValue();
				
			}
			else if((entry.getKey()).equalsIgnoreCase("ENHO"))
			{
				DefectUsedEnhanCount+=(entry.getValue()).intValue();
				
			}
			else if((entry.getKey()).equalsIgnoreCase("ENHS"))
			{
				DefectUsedEnhanCount+=(entry.getValue()).intValue();
				
			}
			else if((entry.getKey()).equalsIgnoreCase("WDYN"))
			{
				DefectUsedWebCount=(entry.getValue()).intValue();
				
			}
			else if((entry.getKey()).equalsIgnoreCase("LSMW"))
			{
				DefectUsedLsmwCount=(entry.getValue()).intValue();
				
			}
		}
		hanaEstimator.getRow(33).getCell(2).setCellValue(DefectUsedFugrCount);
		hanaEstimator.getRow(33).getCell(5).setCellValue(DefectUsedProgCount);
		hanaEstimator.getRow(33).getCell(8).setCellValue(DefectUsedClasCount);
		hanaEstimator.getRow(33).getCell(11).setCellValue(DefectUsedFormCount);
		hanaEstimator.getRow(33).getCell(14).setCellValue(DefectUsedEnhanCount);
		hanaEstimator.getRow(33).getCell(17).setCellValue(DefectUsedWebCount);
		hanaEstimator.getRow(33).getCell(20).setCellValue(DefectUsedLsmwCount);
		hanaEstimator.getRow(33).getCell(23).setCellValue(DefectUsedExitCount);
		
		// Row 3

		List<HanaEstimator> hanaEstimatorList = getGraphDao().getHanaEstimatorObjects(requestID);

		if (null != hanaEstimatorList && hanaEstimatorList.size() > 0) {
			HanaEstimator hanaEstimtor = hanaEstimatorList.get(0);

			if (null != hanaEstimtor.getRes_TL_SSE()) {
				hanaStaffingSheet.getRow(1).getCell(2).setCellValue(hanaEstimtor.getRes_TL_SSE());
			} else
				hanaStaffingSheet.getRow(1).getCell(2).setCellValue(0);
			if (null != hanaEstimtor.getRes_SSE_SE())
				hanaStaffingSheet.getRow(2).getCell(2).setCellValue(hanaEstimtor.getRes_SSE_SE());
			else
				hanaStaffingSheet.getRow(2).getCell(2).setCellValue(0);
		}


		hanaEstimator.setForceFormulaRecalculation(true);
	}

	*//**
	 * Section For Estimator Close
	 * 
	 * @param hanaStaffingSheet
	 **//*

	// CR-13.0 Writing Estimations Sheets for Client
	private void wroteEstimationsSheetForClient(Long requestID, XSSFSheet estimatorSheet, XSSFSheet hanaStaffingSheet) {

		List<HanaEstimator> hanaEstimatorList = getGraphDao().getHanaEstimatorObjects(requestID);
		HanaEstimator hanaEstimtor = hanaEstimatorList.get(0);
		
		int Migration_Fix_Effort_Manual_Fixing_Count = hanaEstimtor.getMigration_Fix_Effort_Manual_Fixing_Count();
		int Used_Migration_Fix_Effort_Manual_Fixing_Count = hanaEstimtor.getUsed_Migration_Fix_Effort_Manual_Fixing_Count();
		estimatorSheet.getRow(4).getCell(14).setCellValue(Migration_Fix_Effort_Manual_Fixing_Count);
		estimatorSheet.getRow(16).getCell(14).setCellValue(Used_Migration_Fix_Effort_Manual_Fixing_Count);
		

		if (null != hanaEstimtor.getRes_TL_SSE()) {
			hanaStaffingSheet.getRow(1).getCell(2).setCellValue(hanaEstimtor.getRes_TL_SSE());
		} else
			hanaStaffingSheet.getRow(1).getCell(2).setCellValue(0);
		if (null != hanaEstimtor.getRes_SSE_SE())
			hanaStaffingSheet.getRow(2).getCell(2).setCellValue(hanaEstimtor.getRes_SSE_SE());
		else
			hanaStaffingSheet.getRow(2).getCell(2).setCellValue(0);
		estimatorSheet.setForceFormulaRecalculation(true);

	}

	// CR-13.0 Writing Assumptions Sheets
	private void wroteAssumptionSheetForClient(Long requestID, XSSFSheet assumptionSheet) {
		List<HanaAssumption> hanaAssumptionList = getGraphDao().getHanaAssumptionsObjects(requestID);

		if (null != hanaAssumptionList) {
			Iterator<HanaAssumption> hanaAssumptionItr = hanaAssumptionList.iterator();
			while (hanaAssumptionItr.hasNext()) {
				HanaAssumption hanaAssumption = (HanaAssumption) hanaAssumptionItr.next();

				String assumption = hanaAssumption.getAssumptions();
				String[] assumptionArr = assumption.split("@@@");
				for (int i = 0, j = 1; i <= assumptionArr.length && j <= assumptionArr.length; i++, j++) {
					assumptionSheet.getRow(j).getCell(2).setCellValue(assumptionArr[i]);
				}
				assumptionSheet.setForceFormulaRecalculation(true);
			}
		}
	}

	private Integer getUsedUnusedColumnCount(String key, Map<String, Integer> usedUnsedMap) {
		Integer count = 0;
		if (usedUnsedMap != null && usedUnsedMap.containsKey(key)) {
			count = usedUnsedMap.get(key);
		}

		return count;
	}

	 CR-6.0 
	@RequestMapping(value = "/view/summary/{requestID}/{viewType}", method = RequestMethod.GET)
	public ModelAndView graphView1(ModelAndView model, @PathVariable("requestID") final String requestId,
			@PathVariable("viewType") final String viewType) {

		String view = "";
		ModelAndView modenAndView = null;

		if (Hana_Profiler_Constant.GRAPHICAL.equals(viewType)) {
			view = "/summaryGraphViewClient";
			modenAndView = new ModelAndView(view);
			modenAndView.addObject("cateGory", getGraphDao().getGraphCountCategory(Long.parseLong(requestId)));
			modenAndView.addObject("subCateGory", getGraphDao().getGraphCountSubCategory(Long.parseLong(requestId)));
			modenAndView.addObject("usedUnused", getGraphDao().getGraphCountUsedUnused(Long.parseLong(requestId)));
			modenAndView.addObject("impact", getGraphDao().getGraphCountImpact(Long.parseLong(requestId)));
		} else {
			view = "/summaryTabularViewClient";
			modenAndView = new ModelAndView(view);
			modenAndView.addObject("cateGory", getGraphDao().getGraphCountCategory(Long.parseLong(requestId)));
			modenAndView.addObject("subCateGory", getGraphDao().getGraphCountSubCategory(Long.parseLong(requestId)));
			modenAndView.addObject("usedUnused", getGraphDao().getGraphCountUsedUnused(Long.parseLong(requestId)));
			modenAndView.addObject("impact", getGraphDao().getGraphCountImpact(Long.parseLong(requestId)));
			final Map<String, Map<String, Integer>> objectType = getGraphDao()
					.getObjectTypeUsedunusedCount(Long.parseLong(requestId));
			modenAndView.addObject("progUsedCount", getUsedUnusedColumnCount("Used", objectType.get("PROG")));
			modenAndView.addObject("progUnusedCount", getUsedUnusedColumnCount("Unused", objectType.get("PROG")));
			modenAndView.addObject("classUsedCount", getUsedUnusedColumnCount("Used", objectType.get("CLAS")));
			modenAndView.addObject("classUnusedCount", getUsedUnusedColumnCount("Unused", objectType.get("CLAS")));
			modenAndView.addObject("fugrUsedCount", getUsedUnusedColumnCount("Used", objectType.get("FUGR")));
			modenAndView.addObject("fugrUnusedCount", getUsedUnusedColumnCount("Unused", objectType.get("FUGR")));
			modenAndView.addObject("requestID", requestId);
		}
		return modenAndView;
	}

	 CR-6.0 
	@RequestMapping(value = "/view/inventory/{requestID}", method = RequestMethod.GET)
	public String finalOutput(@PathVariable("requestID") final long requestId, HttpServletRequest request,
			Model model) {
		model.addAttribute("requestID", requestId);
		request.getSession().setAttribute("requestID", requestId);
		return "client/clientGridDisplay";
	}

	 CR-6.0 
	@RequestMapping(value = "/view/inventory/jqgridDisplayview", method = RequestMethod.GET)
	public @ResponseBody JqGridResponse GetListwithValue(final long requestID, int rows, int page, Model model,
			HttpServletRequest request, HttpSession session) {
		Integer totalRecords = 0;
		if (session.getAttribute("count" + requestID) == null) {
			totalRecords = getDaoIntf().getTotalCountOfList(requestID);
			session.setAttribute("count" + requestID, totalRecords);
		} else {
			totalRecords = (Integer) session.getAttribute("count" + requestID);
		}
		final int to = page * rows;
		final int from = to - rows;
		List<HanaProfile> list = getDaoIntf().GetList(requestID, from, rows);

		model.addAttribute("hanaList", list);
		int total = (totalRecords) % rows;
		if (total > 0) {
			total = (totalRecords / rows) + 1;
		} else {
			total = (totalRecords / rows);
		}
		JqGridResponse response = new JqGridResponse();
		response.setRows(list);
		response.setTotal(Integer.toString(total));
		response.setRecords(Integer.toString(totalRecords));
		response.setPage(Integer.toString(page));
		return response;

	}

	// CR-52.0 AIES Tool Integration
	@RequestMapping(value = "/summary/view/{requestID}/{viewType}", method = RequestMethod.GET)
	public ModelAndView graphViewAIES(ModelAndView model, @PathVariable("requestID") final String requestId,
			@PathVariable("viewType") final String viewType,
			HttpServletRequest request, HttpSession session) {

		String view = "";
		ModelAndView modenAndView = null;
		String toolName = "";

		List<ProcessedRequestDetail> reqMasterList = getGraphDao().getReqMaster(Long.parseLong(requestId));
		if (!reqMasterList.isEmpty() && reqMasterList.size() > 0) {
			ProcessedRequestDetail reqMaster = reqMasterList.get(0);

			toolName = reqMaster.getToolName();
			// String clientName=reqMaster.getClientName();
		} else {
			toolName = "s4";
		}
		// session.setAttribute("clientName", clientName);
		if (toolName.equalsIgnoreCase("Hana")) {
			if (Hana_Profiler_Constant.GRAPHICAL.equalsIgnoreCase(viewType)) {
				view = "/summaryGraphViewClientAIES";
				modenAndView = new ModelAndView(view);
				modenAndView.addObject("cateGory", getGraphDao().getGraphCountCategory(Long.parseLong(requestId)));
				modenAndView.addObject("subCateGory", getGraphDao().getGraphCountSubCategory(Long.parseLong(requestId)));
				modenAndView.addObject("usedUnused", getGraphDao().getGraphCountUsedUnused(Long.parseLong(requestId)));
				modenAndView.addObject("impact", getGraphDao().getGraphCountImpact(Long.parseLong(requestId)));
				// modenAndView.addObject("clientName",clientName);
			} else {
				view = "/summaryTabularViewClientAIES";
				modenAndView = new ModelAndView(view);
				modenAndView.addObject("cateGory", getGraphDao().getGraphCountCategory(Long.parseLong(requestId)));
				modenAndView.addObject("subCateGory", getGraphDao().getGraphCountSubCategory(Long.parseLong(requestId)));
				modenAndView.addObject("usedUnused", getGraphDao().getGraphCountUsedUnused(Long.parseLong(requestId)));
				modenAndView.addObject("impact", getGraphDao().getGraphCountImpact(Long.parseLong(requestId)));
				// modenAndView.addObject("clientName",clientName);

				final Map<String, Map<String, Integer>> objectType = getGraphDao()
						.getObjectTypeUsedunusedCount(Long.parseLong(requestId));
				modenAndView.addObject("progUsedCount", getUsedUnusedColumnCount("Used", objectType.get("PROG")));
				modenAndView.addObject("progUnusedCount", getUsedUnusedColumnCount("Unused", objectType.get("PROG")));
				modenAndView.addObject("classUsedCount", getUsedUnusedColumnCount("Used", objectType.get("CLAS")));
				modenAndView.addObject("classUnusedCount", getUsedUnusedColumnCount("Unused", objectType.get("CLAS")));
				modenAndView.addObject("fugrUsedCount", getUsedUnusedColumnCount("Used", objectType.get("FUGR")));
				modenAndView.addObject("fugrUnusedCount", getUsedUnusedColumnCount("Unused", objectType.get("FUGR")));
				modenAndView.addObject("requestID", requestId);
			}
		} else {
			if (Hana_Profiler_Constant.GRAPHICAL.equalsIgnoreCase(viewType)) {
				view = "/summaryGraphViewS4AIES";
				modenAndView = new ModelAndView(view);
				modenAndView.addObject("cateGory", getGraphS4DAO().getGraphCountRemediCategry(Long.parseLong(requestId)));
				modenAndView.addObject("subCateGory", getGraphS4DAO().getGraphCountErrCategry(Long.parseLong(requestId)));
				modenAndView.addObject("usedUnused", getGraphS4DAO().getGraphCountFinalUsed(Long.parseLong(requestId)));
				modenAndView.addObject("impact", getGraphS4DAO().getGraphCountFinalComplexity(Long.parseLong(requestId)));
				// modenAndView.addObject("clientName",clientName);
			} else {
				view = "/summaryTabularViewS4AIES";
				modenAndView = new ModelAndView(view);
				modenAndView.addObject("cateGory", getGraphS4DAO().getGraphCountRemediCategry(Long.parseLong(requestId)));
				modenAndView.addObject("subCateGory", getGraphS4DAO().getGraphCountErrCategry(Long.parseLong(requestId)));
				modenAndView.addObject("usedUnused", getGraphS4DAO().getGraphCountFinalUsed(Long.parseLong(requestId)));
				modenAndView.addObject("impact", getGraphS4DAO().getGraphCountFinalComplexity(Long.parseLong(requestId)));
				// modenAndView.addObject("clientName",clientName);

				final Map<String, Map<String, Integer>> objectType = getGraphS4DAO()
						.getObjectTypeUsedCount(Long.parseLong(requestId));
				modenAndView.addObject("progUsedCount", getUsedColumnCount("Y", objectType.get("PROG")));

				modenAndView.addObject("classUsedCount", getUsedColumnCount("Y", objectType.get("CLAS")));

				modenAndView.addObject("fugrUsedCount", getUsedColumnCount("Y", objectType.get("FUGR")));

				modenAndView.addObject("enhoUsedCount", getUsedColumnCount("Y", objectType.get("ENHO")));

				modenAndView.addObject("enhcUsedCount", getUsedColumnCount("Y", objectType.get("ENHC")));

				modenAndView.addObject("enhsUsedCount", getUsedColumnCount("Y", objectType.get("ENHS")));
				modenAndView.addObject("indeUsedCount", getUsedColumnCount("Y", objectType.get("INDE")));

				modenAndView.addObject("viewUsedCount", getUsedColumnCount("Y", objectType.get("VIEW")));

				modenAndView.addObject("wdynUsedCount", getUsedColumnCount("Y", objectType.get("WDYN")));

				modenAndView.addObject("ssfoUsedCount", getUsedColumnCount("Y", objectType.get("SSFO")));

				modenAndView.addObject("requestID", requestId);
			}
		}
		return modenAndView;
	}

	private Integer getUsedColumnCount(String key, Map<String, Integer> usedUnsedMap) {
		Integer count = 0;
		if (usedUnsedMap != null && usedUnsedMap.containsKey(key)) {
			count = usedUnsedMap.get(key);
		}

		return count;
	}
*/
}
