package com.accenture.fiori.models;

import java.util.List;

public class FioriFinalOutputList {
	
	private List<InventoryStandardFiori> invtryStntdFioriList ;
	private List<InventoryCustomFiori>  inventoryCustomFioriList;
	private List<InventoryExtensionFiori> inventoryExtnFioriList;
	private List<StandardTcodesFiori>standardTcodesFioriList;
	private List<CustomFioriIssues> customFioriIssuesList;
	
	
	
	public List<CustomFioriIssues> getCustomFioriIssuesList() {
		return customFioriIssuesList;
	}
	public void setCustomFioriIssuesList(List<CustomFioriIssues> customFioriIssuesList) {
		this.customFioriIssuesList = customFioriIssuesList;
	}
	public List<InventoryStandardFiori> getInvtryStntdFioriList() {
		return invtryStntdFioriList;
	}
	public void setInvtryStntdFioriList(List<InventoryStandardFiori> invtryStntdFioriList) {
		this.invtryStntdFioriList = invtryStntdFioriList;
	}
	public List<InventoryCustomFiori> getInventoryCustomFioriList() {
		return inventoryCustomFioriList;
	}
	public void setInventoryCustomFioriList(List<InventoryCustomFiori> inventoryCustomFioriList) {
		this.inventoryCustomFioriList = inventoryCustomFioriList;
	}
	public List<InventoryExtensionFiori> getInventoryExtnFioriList() {
		return inventoryExtnFioriList;
	}
	public void setInventoryExtnFioriList(List<InventoryExtensionFiori> inventoryExtnFioriList) {
		this.inventoryExtnFioriList = inventoryExtnFioriList;
	}
	public List<StandardTcodesFiori> getStandardTcodesFioriList() {
		return standardTcodesFioriList;
	}
	public void setStandardTcodesFioriList(List<StandardTcodesFiori> standardTcodesFioriList) {
		this.standardTcodesFioriList = standardTcodesFioriList;
	}
	
	
	
}
