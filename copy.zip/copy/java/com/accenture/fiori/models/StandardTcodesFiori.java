package com.accenture.fiori.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name="Standard_Tcodes_Fiori")
public class StandardTcodesFiori {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID")
	private int id;
	
	@Column(name="REQUEST_ID")
	private long requestID;
	
	@Column(name="Object")
	private String object;	

	@Column(name = "AppId" ,columnDefinition="varchar(500)" )
	@Index(name="INDEX_APP_ID")
	private String appId;
	
	@Column(name = "TCodesCombined" ,  columnDefinition="TEXT" )
	private String  tcodesCombined ;
	
	@Column(name="AppTypeCombined", columnDefinition="TEXT")
	private String  appTypeCombined;
	
	@Column(name = "AppName" ,  columnDefinition="TEXT" )
	private String  appName ;
	
	@Column(name="PCDCombined", columnDefinition="TEXT")
	private String  pcdCombined;
	
	@Column(name = "PVBackendCombined" , columnDefinition="TEXT" )
	private String   pvBackendCombined;
	
	@Column(name="Availability")
	private String availability;
	
	@Column(name="Obj_Name")
	private String objName;
	
	@Column(name="Comments")
	private String comments;
	
	@Column(name = "FormFactors" ,  columnDefinition="TEXT" )
	private String  formFactors ;

	public String getObject() {
		return object;
	}

	public void setObject(String object) {
		this.object = object;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	

	public String getPcdCombined() {
		return pcdCombined;
	}

	public void setPcdCombined(String pcdCombined) {
		this.pcdCombined = pcdCombined;
	}

	public String getAvailability() {
		return availability;
	}

	public void setAvailability(String availability) {
		this.availability = availability;
	}
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTcodesCombined() {
		return tcodesCombined;
	}

	public void setTcodesCombined(String tcodesCombined) {
		this.tcodesCombined = tcodesCombined;
	}

	public String getAppTypeCombined() {
		return appTypeCombined;
	}

	public void setAppTypeCombined(String appTypeCombined) {
		this.appTypeCombined = appTypeCombined;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public long getRequestID() {
		return requestID;
	}

	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getFormFactors() {
		return formFactors;
	}

	public void setFormFactors(String formFactors) {
		this.formFactors = formFactors;
	}

	public String getPvBackendCombined() {
		return pvBackendCombined;
	}

	public void setPvBackendCombined(String pvBackendCombined) {
		this.pvBackendCombined = pvBackendCombined;
	}

	
}
