package com.accenture.fiori.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="FIORI_APPS_OUTPUT")
public class FioriAppsOutput implements java.io.Serializable{
 
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID")
	private Integer id;
	
	@Column(name="APP_ID")
	private String appId;
	
	@Column(name="APP_NAME")
	private String appName;
	
	@Column(name="TCODE")
	private String tCode;
	
	@Column(name="APP_TYPE")
	private String appType;
	
	@Column(name="REQUEST_ID")
	private Long requestId;
	
	@Column(name="SCORE")
	private Long score;

	@Column(name="COMMENTS")
	private String comments;
	
	@Column(name="APPLICATION_COMPONENT")
	private String applicationComponent;
	
	@Column(name="APPLICATION_COMPONENT_TEXT")
	private String applicationComponentText;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String gettCode() {
		return tCode;
	}

	public void settCode(String tCode) {
		this.tCode = tCode;
	}

	public String getAppType() {
		return appType;
	}

	public void setAppType(String appType) {
		this.appType = appType;
	}

	public Long getRequestId() {
		return requestId;
	}

	public void setRequestId(Long requestId) {
		this.requestId = requestId;
	}

	public Long getScore() {
		return score;
	}

	public void setScore(Long score) {
		this.score = score;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getApplicationComponent() {
		return applicationComponent;
	}

	public void setApplicationComponent(String applicationComponent) {
		this.applicationComponent = applicationComponent;
	}

	public String getApplicationComponentText() {
		return applicationComponentText;
	}

	public void setApplicationComponentText(String applicationComponentText) {
		this.applicationComponentText = applicationComponentText;
	}
}
