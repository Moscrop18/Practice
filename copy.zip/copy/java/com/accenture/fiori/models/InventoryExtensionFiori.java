package com.accenture.fiori.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Inventory_Extension_Fiori")
public class InventoryExtensionFiori {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID")
	private int id;
	
	@Column(name="REQUEST_ID")
	private long requestID;
	
	@Column(name="Object")
	private String object;
	
	

	@Column(name="AppId",columnDefinition="varchar(500)")
	private String appId;
	
	@Column(name="BspName")
	private String bspName;
	
	@Column(name="OdataServicesCombined",columnDefinition="TEXT")
	private String odataServicesCombined;
	
	@Column(name="QueryName")
	private String  queryName;
	
	@Column(name="PCDCombined",columnDefinition="TEXT")
	private String  pcdCombined;
	
	@Column(name="Availability")
	private String availability;
	
	@Column(name="Obj_Name")
	private String objName;
	
	@Column(name="Read_Prog")
	private String readProg;
	
	@Column(name = "PVBackendCombined" , columnDefinition="TEXT" )
	private String   pvBackendCombined;

	public String getObject() {
		return object;
	}

	public void setObject(String object) {
		this.object = object;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public String getBspName() {
		return bspName;
	}

	public void setBspName(String bspName) {
		this.bspName = bspName;
	}

	public String getOdataServicesCombined() {
		return odataServicesCombined;
	}

	public void setOdataServicesCombined(String odataServicesCombined) {
		this.odataServicesCombined = odataServicesCombined;
	}


	public String getPcdCombined() {
		return pcdCombined;
	}

	public void setPcdCombined(String pcdCombined) {
		this.pcdCombined = pcdCombined;
	}

	public String getAvailability() {
		return availability;
	}

	public void setAvailability(String availability) {
		this.availability = availability;
	}
	public long getRequestID() {
		return requestID;
	}

	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getQueryName() {
		return queryName;
	}

	public void setQueryName(String queryName) {
		this.queryName = queryName;
	}

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}

	public String getReadProg() {
		return readProg;
	}

	public void setReadProg(String readProg) {
		this.readProg = readProg;
	}

	public String getPvBackendCombined() {
		return pvBackendCombined;
	}

	public void setPvBackendCombined(String pvBackendCombined) {
		this.pvBackendCombined = pvBackendCombined;
	}
}
