package com.accenture.fiori.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Custom_Report_Output_download")
public class CustomReportOutput_download {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID")
	private int id;
		
	@Column(name="REQUEST_ID")
	private long requestID;
	
	@Column(name="TechnicalCatalogId")
	private String technicalCatalogId;
	
	@Column(name="Technicalcatalogtitle")
	private String technicalcatalogtitle;
	
	@Column(name="SemanticObjectAction")
	private String semanticObjectAction;
	
	@Column(name="LaunchpadApplicationType")
	private String launchpadApplicationType;
	
	@Column(name="LaunchpadApplicationName")
	private String launchpadApplicationName;
	
	@Column(name="StatusOfTheApplication")
	private String statusOfTheApplication;
	
	@Column(name="FlagForCustomApplication")
	private String flagForCustomApplication;
	
	@Column(name="Fiori_ID")
	private String fioriId;
	
	@Column(name="SuccessorApp")
	private String successorApp;
	
	@Column(name="RelatedApp")
	private String relatedApp;
		
	@Column(name="App_Name")
	private String appName;
	
	@Column(name="PVBackendCombined", columnDefinition="TEXT")
	private String pvBackendCombined;
	
	@Column(name="Availability")
	private String availability;
	
	
	@Column(name="Version")
	private String version;
	
	@Column(name="Alternate_Name")
	private String altName;
	
	@Column(name="Component")
	private String component;

	public String getComponent() {
		return component;
	}

	public void setComponent(String component) {
		this.component = component;
	}

	public String getFioriId() {
		return fioriId;
	}

	public void setFioriId(String fioriId) {
		this.fioriId = fioriId;
	}

	public String getSuccessorApp() {
		return successorApp;
	}

	public void setSuccessorApp(String successorApp) {
		this.successorApp = successorApp;
	}

	public String getRelatedApp() {
		return relatedApp;
	}

	public void setRelatedApp(String relatedApp) {
		this.relatedApp = relatedApp;
	}

	private String concat;

	public long getRequestID() {
		return requestID;
	}

	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}

	public String getTechnicalCatalogId() {
		return technicalCatalogId;
	}

	public void setTechnicalCatalogId(String technicalCatalogId) {
		this.technicalCatalogId = technicalCatalogId;
	}

	public String getTechnicalcatalogtitle() {
		return technicalcatalogtitle;
	}

	public void setTechnicalcatalogtitle(String technicalcatalogtitle) {
		this.technicalcatalogtitle = technicalcatalogtitle;
	}

	public String getSemanticObjectAction() {
		return semanticObjectAction;
	}

	public void setSemanticObjectAction(String semanticObjectAction) {
		this.semanticObjectAction = semanticObjectAction;
	}

	public String getLaunchpadApplicationType() {
		return launchpadApplicationType;
	}

	public void setLaunchpadApplicationType(String launchpadApplicationType) {
		this.launchpadApplicationType = launchpadApplicationType;
	}

	public String getLaunchpadApplicationName() {
		return launchpadApplicationName;
	}

	public void setLaunchpadApplicationName(String launchpadApplicationName) {
		this.launchpadApplicationName = launchpadApplicationName;
	}

	public String getStatusOfTheApplication() {
		return statusOfTheApplication;
	}

	public void setStatusOfTheApplication(String statusOfTheApplication) {
		this.statusOfTheApplication = statusOfTheApplication;
	}

	public String getFlagForCustomApplication() {
		return flagForCustomApplication;
	}

	public void setFlagForCustomApplication(String flagForCustomApplication) {
		this.flagForCustomApplication = flagForCustomApplication;
	}

	public String getConcat() {
		return concat;
	}

	public void setConcat(String concat) {
		this.concat = concat;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getPvBackendCombined() {
		return pvBackendCombined;
	}

	public void setPvBackendCombined(String pvBackendCombined) {
		this.pvBackendCombined = pvBackendCombined;
	}

	public String getAvailability() {
		return availability;
	}

	public void setAvailability(String availability) {
		this.availability = availability;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getAltName() {
		return altName;
	}

	public void setAltName(String altName) {
		this.altName = altName;
	}
	
	
}
