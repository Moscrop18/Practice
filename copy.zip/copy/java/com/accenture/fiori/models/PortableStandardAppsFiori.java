package com.accenture.fiori.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name="Portable_Apps_Fiori")
public class PortableStandardAppsFiori {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID")
	private int id;
	
	@Column(name="REQUEST_ID")
	private long requestID;
	
	
	@Column(name = "AppId" ,columnDefinition="varchar(500)" )
	@Index(name="INDEX_APP_ID")
	private String appId;
		
	
	@Column(name="AppTypeCombined", columnDefinition="TEXT")
	private String  appTypeCombined;
	
	@Column(name = "AppName" ,  columnDefinition="TEXT" )
	private String  appName ;
		
	@Column(name = "FormFactors" ,  columnDefinition="TEXT" )
	private String  formFactors ;


	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	
	public String getAppTypeCombined() {
		return appTypeCombined;
	}

	public void setAppTypeCombined(String appTypeCombined) {
		this.appTypeCombined = appTypeCombined;
	}

	public long getRequestID() {
		return requestID;
	}

	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getFormFactors() {
		return formFactors;
	}

	public void setFormFactors(String formFactors) {
		this.formFactors = formFactors;
	}

	

	
}
