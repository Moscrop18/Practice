package com.accenture.bw.dao;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpSession;

import com.accenture.S4.models.SrcAgr1251;
import com.accenture.bw.model.BwFinalOutput;
import com.accenture.bw.model.BwInventoryList;
import com.accenture.bw.model.BwObjectTypeDateFormat;
import com.accenture.bw.model.RsantProcessr;
import com.accenture.bw.model.Rsbkdtp;
import com.accenture.bw.model.Rsbkdtpstat;
import com.accenture.bw.model.Rsbkrequest;
import com.accenture.bw.model.Rsiccont;
import com.accenture.bw.model.Rspcchain;
import com.accenture.bw.model.Rspcprocesslog;
import com.accenture.bw.model.Rsrrepdir;
import com.accenture.bw.model.Rsrrworkbook;
import com.accenture.bw.model.Rstran;
import com.accenture.bw.model.WebTemplate3;
import com.accenture.bw.model.WebTemplate7;

public interface BwCleanUpDAO {
	public String batchInsertionForRsiccont(List<Rsiccont> rsiccontList, HttpSession session) throws SQLException;
	public String batchInsertionForRsantProcessr(List<RsantProcessr> rsantProcessrList, HttpSession session) throws SQLException;
	public String batchInsertionForRsbkrequest(List<Rsbkrequest> rsbkrequestList, HttpSession session) throws SQLException;
	public String batchInsertionForRsrrepdir(List<Rsrrepdir> rsrrepdirList, HttpSession session) throws SQLException;
	public String batchInsertionForRsbkdtp(List<Rsbkdtp> rsbkdtpList, HttpSession session) throws SQLException;
	public String batchInsertionForRsbkdtpstat(List<Rsbkdtpstat> rsbkdtpstatList, HttpSession session) throws SQLException;
	public String batchInsertionForRstran(List<Rstran> rstranList, HttpSession session) throws SQLException;
	public String batchInsertionForRspcprocesslog(List<Rspcprocesslog> rspcprocesslogList, HttpSession session) throws SQLException;
	public void getBwObjectCleanUpRecords(HttpSession session, String tbl1, String tbl2, String col1, String col2, String reqIdname) throws SQLException;
	public void getBwObjectInYears(HttpSession session, Long requestId) throws SQLException;
	public String batchInsertionForWebTemplate3(List<WebTemplate3> rsiccontList, HttpSession session) throws SQLException;
	public String batchInsertionForWebTemplate7(List<WebTemplate7> rsiccontList, HttpSession session) throws SQLException;
	public String batchInsertionForRspcchain(List<Rspcchain> rspcchainList, HttpSession session) throws SQLException;
	public String batchInsertionForRsrrworkbook(List<Rsrrworkbook> rsrrworkList, HttpSession session) throws SQLException;
	public List<BwFinalOutput> getBwCleanUpReport(Integer requestId);
	public void getDateFormatForBw(HttpSession session,Long requestId) throws SQLException;
	public void getBWObjectsRSBKRequest(HttpSession session, String inputTbl, String finalTbl, String timCol, String objNameCol, String reqIdColname) throws SQLException;
	public BwObjectTypeDateFormat getBwObjectType(Long requestId);
	public String batchInsertionForBwInventory(List<BwInventoryList> bwInvList, HttpSession session) throws SQLException;
	public void bwStandardExtractProcessing(HttpSession session,Long requestId) throws SQLException;
}
