package com.accenture.bw.model;

public class Rsldpio {
	private String logdPid;
	public String getLogdPid() {
		return logdPid;
	}
	public void setLogdPid(String logdPid) {
		this.logdPid = logdPid;
	}
	private Long requestId;
	private String objStatus;
	private String objType;
	public String getObjType() {
		return objType;
	}
	public void setObjType(String objType) {
		this.objType = objType;
	}
	public String getObjStatus() {
		return objStatus;
	}
	public void setObjStatus(String objStatus) {
		this.objStatus = objStatus;
	}
	
	public Long getRequestId() {
		return requestId;
	}
	public void setRequestId(Long requestId) {
		this.requestId = requestId;
	}
}
