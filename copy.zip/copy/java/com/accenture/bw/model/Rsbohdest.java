package com.accenture.bw.model;

public class Rsbohdest {

	private String ohDest;
	private String objType;
	private String objStatus;
	private Long requestid;
	public String getOhDest() {
		return ohDest;
	}
	public void setOhDest(String ohDest) {
		this.ohDest = ohDest;
	}
	public String getObjType() {
		return objType;
	}
	public void setObjType(String objType) {
		this.objType = objType;
	}
	public String getObjStatus() {
		return objStatus;
	}
	public void setObjStatus(String objStatus) {
		this.objStatus = objStatus;
	}
	public Long getRequestid() {
		return requestid;
	}
	public void setRequestid(Long requestid) {
		this.requestid = requestid;
	}
}
