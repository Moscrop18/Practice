package com.accenture.bw.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="BW_Object_Date")
public class BwObjectTypeDateFormat {

	@Id
	private long requestId;
	private String rsiccont;
	private String rsantProcessr;
	private String rsbkrequest;
	private String rsrrepdir;
	private String bioapersSod00;
	private String rspcprocesslog;
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getRsiccont() {
		return rsiccont;
	}
	public void setRsiccont(String rsiccont) {
		this.rsiccont = rsiccont;
	}
	public String getRsantProcessr() {
		return rsantProcessr;
	}
	public void setRsantProcessr(String rsantProcessr) {
		this.rsantProcessr = rsantProcessr;
	}
	public String getRsbkrequest() {
		return rsbkrequest;
	}
	public void setRsbkrequest(String rsbkrequest) {
		this.rsbkrequest = rsbkrequest;
	}
	public String getRsrrepdir() {
		return rsrrepdir;
	}
	public void setRsrrepdir(String rsrrepdir) {
		this.rsrrepdir = rsrrepdir;
	}
	public String getBioapersSod00() {
		return bioapersSod00;
	}
	public void setBioapersSod00(String bioapersSod00) {
		this.bioapersSod00 = bioapersSod00;
	}
	public String getRspcprocesslog() {
		return rspcprocesslog;
	}
	public void setRspcprocesslog(String rspcprocesslog) {
		this.rspcprocesslog = rspcprocesslog;
	}
	
	private Boolean odso;
	private Boolean iobj;
	private Boolean cuba;
	private Boolean mpro;
	private Boolean odh;
	private Boolean anpr;
	private Boolean adso;
	private Boolean hcpr;
	private Boolean trn;
	private Boolean updr;
	private Boolean ists;
	private Boolean rsds;
	private Boolean ismp;
	private Boolean isip;
	private Boolean dtpa;
	private Boolean elem;
	private Boolean xlwb;
	private Boolean btmp;
	private Boolean tmpl;
	private Boolean rspc;
	private Boolean iset;
	
	public Boolean getIset() {
		return iset;
	}
	public void setIset(Boolean iset) {
		this.iset = iset;
	}
	public Boolean getOdso() {
		return odso;
	}
	public void setOdso(Boolean odso) {
		this.odso = odso;
	}
	public Boolean getIobj() {
		return iobj;
	}
	public void setIobj(Boolean iobj) {
		this.iobj = iobj;
	}
	
	public Boolean getCuba() {
		return cuba;
	}
	public void setCuba(Boolean cuba) {
		this.cuba = cuba;
	}
	public Boolean getMpro() {
		return mpro;
	}
	public void setMpro(Boolean mpro) {
		this.mpro = mpro;
	}
	public Boolean getOdh() {
		return odh;
	}
	public void setOdh(Boolean odh) {
		this.odh = odh;
	}
	public Boolean getAnpr() {
		return anpr;
	}
	public void setAnpr(Boolean anpr) {
		this.anpr = anpr;
	}
	public Boolean getAdso() {
		return adso;
	}
	public void setAdso(Boolean adso) {
		this.adso = adso;
	}
	public Boolean getHcpr() {
		return hcpr;
	}
	public void setHcpr(Boolean hcpr) {
		this.hcpr = hcpr;
	}
	public Boolean getTrn() {
		return trn;
	}
	public void setTrn(Boolean trn) {
		this.trn = trn;
	}
	public Boolean getUpdr() {
		return updr;
	}
	public void setUpdr(Boolean updr) {
		this.updr = updr;
	}
	public Boolean getIsts() {
		return ists;
	}
	public void setIsts(Boolean ists) {
		this.ists = ists;
	}
	public Boolean getRsds() {
		return rsds;
	}
	public void setRsds(Boolean rsds) {
		this.rsds = rsds;
	}
	public Boolean getIsmp() {
		return ismp;
	}
	public void setIsmp(Boolean ismp) {
		this.ismp = ismp;
	}
	public Boolean getIsip() {
		return isip;
	}
	public void setIsip(Boolean isip) {
		this.isip = isip;
	}
	public Boolean getDtpa() {
		return dtpa;
	}
	public void setDtpa(Boolean dtpa) {
		this.dtpa = dtpa;
	}
	public Boolean getElem() {
		return elem;
	}
	public void setElem(Boolean elem) {
		this.elem = elem;
	}
	public Boolean getXlwb() {
		return xlwb;
	}
	public void setXlwb(Boolean xlwb) {
		this.xlwb = xlwb;
	}
	public Boolean getBtmp() {
		return btmp;
	}
	public void setBtmp(Boolean btmp) {
		this.btmp = btmp;
	}
	public Boolean getTmpl() {
		return tmpl;
	}
	public void setTmpl(Boolean tmpl) {
		this.tmpl = tmpl;
	}
	public Boolean getRspc() {
		return rspc;
	}
	public void setRspc(Boolean rspc) {
		this.rspc = rspc;
	}
	
	
}
