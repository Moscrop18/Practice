package com.accenture.bw.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="RSPCHAIN_Intermidiate ")
public class RspchainIntermediate {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column(name = "Id")
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Column(name = "chain_id")
	private String chainId;
	
	@Column(name = "strt_time_stmp")
	private Date strtTmStmp;
	
	@Column(name = "object_type")
	private String objType;
	
	@Column(name = "Request_Id")
	private Long requestID;
	
	@Column(name = "Variante")
	private String variante;

	public Long getRequestID() {
		return requestID;
	}
	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}
	public String getChainId() {
		return chainId;
	}
	public void setChainId(String chainId) {
		this.chainId = chainId;
	}
	public Date getStrtTmStmp() {
		return strtTmStmp;
	}
	public void setStrtTmStmp(Date strtTmStmp) {
		this.strtTmStmp = strtTmStmp;
	}
	public String getObjType() {
		return objType;
	}
	public void setObjType(String objType) {
		this.objType = objType;
	}
	public String getVariante() {
		return variante;
	}
	public void setVariante(String variante) {
		this.variante = variante;
	}
}
