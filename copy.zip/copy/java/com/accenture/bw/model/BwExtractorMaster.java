package com.accenture.bw.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="BW_EXTRACT_MASTER")
public class BwExtractorMaster {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column(name = "Id")
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Column(name = "obj_name")
	private String objName;
	
	@Column(name = "phase")
	private String phase;
	
	@Column(name = "area_responsibility")
	private String areaResponsibility;
	
	@Column(name = "data_source")
	private String dataSrc;
	
	@Column(name = "app_component")
	private String appComp;
	
	@Column(name = "classification")
	private String classification;
	
	@Column(name = "category")
	private String category;
	
	@Column(name = "restrictions")
	private String restrictions;
	
	@Column(name = "related_simplification_item")
	private String relSimpliItem;
	
	@Column(name = "note")
	private String note;
	
	@Column(name = "del_1511")
	private String del1511;
	
	@Column(name = "del_1610")
	private String del1610;
	
	@Column(name = "delta_restrict")
	private String delRestrict;
	
	@Column(name = "comments")
	private String comments;
	
	public String getObjName() {
		return objName;
	}
	public void setObjName(String objName) {
		this.objName = objName;
	}
	public String getPhase() {
		return phase;
	}
	public void setPhase(String phase) {
		this.phase = phase;
	}
	public String getAreaResponsibility() {
		return areaResponsibility;
	}
	public void setAreaResponsibility(String areaResponsibility) {
		this.areaResponsibility = areaResponsibility;
	}
	public String getDataSrc() {
		return dataSrc;
	}
	public void setDataSrc(String dataSrc) {
		this.dataSrc = dataSrc;
	}
	public String getAppComp() {
		return appComp;
	}
	public void setAppComp(String appComp) {
		this.appComp = appComp;
	}
	public String getClassification() {
		return classification;
	}
	public void setClassification(String classification) {
		this.classification = classification;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getRestrictions() {
		return restrictions;
	}
	public void setRestrictions(String restrictions) {
		this.restrictions = restrictions;
	}
	public String getRelSimpliItem() {
		return relSimpliItem;
	}
	public void setRelSimpliItem(String relSimpliItem) {
		this.relSimpliItem = relSimpliItem;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public String getDel1511() {
		return del1511;
	}
	public void setDel1511(String del1511) {
		this.del1511 = del1511;
	}
	public String getDel1610() {
		return del1610;
	}
	public void setDel1610(String del1610) {
		this.del1610 = del1610;
	}
	public String getDelRestrict() {
		return delRestrict;
	}
	public void setDelRestrict(String delRestrict) {
		this.delRestrict = delRestrict;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
}
