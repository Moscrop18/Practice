package com.accenture.bw.model;

import javax.persistence.Column;

public class Rspcchainattr {
	private String chainId;
	private Long requestId;
	public String getChainId() {
		return chainId;
	}
	public void setChainId(String chainId) {
		this.chainId = chainId;
	}
	public Long getRequestId() {
		return requestId;
	}
	public void setRequestId(Long requestId) {
		this.requestId = requestId;
	}
	private String objectType;
	
	public String getObjectType() {
		return objectType;
	}
	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}
	
private String objStatus;
	
	public String getObjStatus() {
		return objStatus;
	}
	public void setObjStatus(String objStatus) {
		this.objStatus = objStatus;
	}
}
