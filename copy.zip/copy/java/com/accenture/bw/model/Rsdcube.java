package com.accenture.bw.model;

public class Rsdcube {
	private String infoCube;
	private String mpro;
	public String getMpro() {
		return mpro;
	}
	public void setMpro(String mpro) {
		this.mpro = mpro;
	}
	public String getInfoCube() {
		return infoCube;
	}
	public void setInfoCube(String infoCube) {
		this.infoCube = infoCube;
	}
	private Long requestId;
	private String objStatus;
	private String objType;
	public String getObjType() {
		return objType;
	}
	public void setObjType(String objType) {
		this.objType = objType;
	}
	public String getObjStatus() {
		return objStatus;
	}
	public void setObjStatus(String objStatus) {
		this.objStatus = objStatus;
	}
	
	public Long getRequestId() {
		return requestId;
	}
	public void setRequestId(Long requestId) {
		this.requestId = requestId;
	}
}
