package com.accenture.bw.model;

public class BwInputFileNameAndDateFormat {

	private String fileName;
	private boolean dateFormat;
	
	
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public boolean isDateFormat() {
		return dateFormat;
	}
	public void setDateFormat(boolean dateFormat) {
		this.dateFormat = dateFormat;
	}
}
