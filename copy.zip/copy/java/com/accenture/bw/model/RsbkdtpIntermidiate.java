package com.accenture.bw.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="RSBKDTP_Intermidiate ")
public class RsbkdtpIntermidiate {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column(name = "Id")
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Column(name = "dtp")
	private String dtp;
	@Column(name = "object_type")
	private String objectType;
	@Column(name = "dtp_status")
	private String dtpStatus;
	
	@Column(name = "Request_Id")
	private Long requestID;
	public Long getRequestID() {
		return requestID;
	}
	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}
	public String getDtp() {
		return dtp;
	}
	public void setDtp(String dtp) {
		this.dtp = dtp;
	}
	public String getObjectType() {
		return objectType;
	}
	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}
	public String getDtpStatus() {
		return dtpStatus;
	}
	public void setDtpStatus(String dtpStatus) {
		this.dtpStatus = dtpStatus;
	}
}
