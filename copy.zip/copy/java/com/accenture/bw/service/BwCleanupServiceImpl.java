package com.accenture.bw.service;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.accenture.bw.dao.BwCleanUpDAO;
import com.accenture.bw.model.BwFinalOutput;
import com.accenture.client.model.RequestForm;
import com.accenture.client.model.RequestInventory;
import com.accenture.constant.Hana_Profiler_Constant;
import com.accenture.poc.dao.POCRequestInventoryDAO;
import com.accenture.service.FileDownload;
import com.accenture.utility.HANAUtility;

@Service
public class BwCleanupServiceImpl implements BwCleanupService {
	
	final static Logger logger = LoggerFactory.getLogger(BwCleanupServiceImpl.class);
	@Autowired
	private BwCleanUpDAO bwCleanUpdao;
	@Autowired
	private FileDownload fileDownload;
	@Autowired
	private POCRequestInventoryDAO requestInventorydao;
	
	
	private void writeBwCLeanUpReport(SXSSFSheet bwCleanupReportSheet, Integer requestID) {
		logger.info(":: writeBwCLeanUpReport started ::");
		try{
		int rowIndex = 1;
		List<BwFinalOutput> bwReportList = bwCleanUpdao.getBwCleanUpReport(requestID);

		if (null != bwReportList && !bwReportList.isEmpty()) {
			Iterator<BwFinalOutput> bwReportItr = bwReportList.iterator();
			while (bwReportItr.hasNext()) {

				BwFinalOutput bwReport = bwReportItr.next();
				Row bwRow = bwCleanupReportSheet.createRow(rowIndex);

				bwRow.createCell(0).setCellValue(bwReport.getObjType());
				bwRow.createCell(1).setCellValue(bwReport.getObjName());
				bwRow.createCell(2).setCellValue(bwReport.getLastUsed());
				bwRow.createCell(3).setCellValue(bwReport.getYears());
				bwRow.createCell(4).setCellValue(bwReport.getStatus());
				rowIndex++;
			}
		}
		}catch (Exception e) {
			logger.error("writeBwCLeanUpReport :: ",e);
			throw e;
		}
		logger.info("Sucessfully Wrote BW Clean up Report Sheet:::%%%%%%%");
		logger.info(":: writeBwCLeanUpReport Ended ::");
	}


	@Override
	public String getBWReportsFromClient(Integer requestID, String userAccess, String userRole, Model model,
			HttpServletResponse response, HttpServletRequest request, RedirectAttributes redirectAttributes,
			RequestForm requestForm, HttpSession session, String userName) {
		String result = "Success";
		// final RequestForm requestForm =
		// getRequestDetails().getRequestObj(requestID);
		try {
			String graphTemplete = "";

			if (Hana_Profiler_Constant.ACCESS_TRUE.equalsIgnoreCase(userAccess)) {
				graphTemplete = request.getSession().getServletContext()
						.getRealPath("/staticResources/GraphTemplate/BW_Reports.xlsx");
			}

			XSSFWorkbook workbook = new XSSFWorkbook(OPCPackage.open(new FileInputStream(graphTemplete)));
			@SuppressWarnings("resource")
			SXSSFWorkbook workbookTemp = new SXSSFWorkbook(workbook);
			workbookTemp.setCompressTempFiles(true);
						
			//Writing BW Clean up report
			SXSSFSheet bwCleanUpReportSheet = (SXSSFSheet) workbookTemp.getSheetAt(0);
			bwCleanUpReportSheet.setRandomAccessWindowSize(1000000);
			writeBwCLeanUpReport(bwCleanUpReportSheet, requestID);

			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			workbookTemp.write(bos);
			bos.close();

			byte[] bytes = bos.toByteArray();
			fileDownload.downloadFile(bytes, response, HANAUtility.join("_", "BW", requestForm.getClientName(),
					requestForm.getSourceVersion(), requestForm.getTargetVersion(), requestID.toString())
					+ ".xlsx");
			String message = "BW CleanUp File Downloaded succesfully";
			logger.info(message);
			if (StringUtils.isNotBlank(message) && "POC".equalsIgnoreCase(userRole)) {
				requestInventorydao.updateBwFileDownloadStatus(requestID, userName, true);

				
				RequestInventory reqInvObj = requestInventorydao.getRequestFromRequestId(new Long(requestID));
				
				/*if(requestForm.getSia() && reqInvObj.getSaFileDnldSts()){
					logger.info(":: Inside the scopes and download bits condition :: ");
					requestInventorydao.updatePOCStatusAndSubStatus(Long.valueOf(requestID), userName, "Final_DOWN_DONE_POC", Hana_Profiler_Constant.REQ_SS_PROCESSED_FL_DL_SUCC);
				}
				if(!requestForm.getSia() && reqInvObj.getFinalFileDnldSts()){
					logger.info(":: Inside the scopes and download bits condition :: ");
					requestInventorydao.updatePOCStatusAndSubStatus(Long.valueOf(requestID), userName, "Final_DOWN_DONE_POC", Hana_Profiler_Constant.REQ_SS_PROCESSED_FL_DL_SUCC);
				}
				if (requestForm.getSia() && requestForm.getSOH() || requestForm.getFiori()
						|| requestForm.getS4Functional() || requestForm.getS4Technical() || requestForm.getUI5()
						|| requestForm.getUPGRADE()) {
					if(reqInvObj.getSaFileDnldSts() && reqInvObj.getFinalFileDnldSts()){
						logger.info(":: Inside the scopes and download bits condition :: ");
						requestInventorydao.updatePOCStatusAndSubStatus(Long.valueOf(requestID), userName, "Final_DOWN_DONE_POC", Hana_Profiler_Constant.REQ_SS_PROCESSED_FL_DL_SUCC);
					}
				}*/
			}
		} catch (Exception e) {
			logger.error("Error in Downloading the BW Cleanup reports :: ", e);
			return null;
		}
		return result;
	}
}
