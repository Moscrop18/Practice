package com.accenture.Aadt.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "IMPACTED_CLONE_ANALYSIS")
public class ImpactedCloneAnalysis {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Integer Id;

	@Column(name = "REQUEST_ID")
	private Long requestID;

	@Column(name = "NAMESPACE")
	private String namespace;

	@Column(name = "OBJECT_TYPE")
	private String objType;

	@Column(name = "OBJECT_NAME")
	private String objName;

	@Column(name = "OBJ_TYPE_NAME")
	private String objTypeName;

	@Column(name = "PACKAGE")
	private String objPackage;

	@Column(name = "YEAR")
	private String year;

	@Column(name = "CREATION_DATE")
	private String creationDate;

	@Column(name = "INTERFACE_CONCATENATED")
	private String interfaceConcat;
		
	@Column(name = "INTERFACE_OBJECT_TYPE")
	private String interfaceObjType;

	@Column(name = "INTERFACE")
	private String interfaceObj;

	@Column(name = "REFERENCE")
	private String reference;

	@Column(name = "REFERENCE_PERCENT")
	private String referencePercent;

	@Column(name = "APPLICATION_COMPONENT")
	private String appComponent;

	@Column(name = "USED")
	private String used;

	@Column(name = "IMPACTED_DUE_TO_DB_CHANGE")
	private String impactedDB;

	@Column(name = "IMPACTED_DUE_TO_SIMPLIFICATION")
	private String impactedSimpl;

	@Column(name = "IMPACTED_DUE_TO_EXISTING_ERRORS")
	private String impactedExistingError;

	@Column(name = "IMPACTED_DUE_TO_OS_MIGRATION")
	private String impactedOSMigration;
	
	@Column(name = "EXTERNAL_NAMESPACE")
	private String externalNamespace ;
	
	@Column(name="EXEC_DATE")
	private String execDate;
	
	@Column(name="EXEC_TIME")
	private String execTime;

	public String getExternalNamespace() {
		return externalNamespace;
	}

	public void setExternalNamespace(String externalNamespace) {
		this.externalNamespace = externalNamespace;
	}

	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
		Id = id;
	}

	public Long getRequestID() {
		return requestID;
	}

	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}

	
	public String getNamespace() {
		return namespace;
	}

	public void setNamespace(String namespace) {
		this.namespace = namespace;
	}

	public String getObjType() {
		return objType;
	}

	public void setObjType(String objType) {
		this.objType = objType;
	}

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}

	public String getObjTypeName() {
		return objTypeName;
	}

	public void setObjTypeName(String objTypeName) {
		this.objTypeName = objTypeName;
	}

	public String getObjPackage() {
		return objPackage;
	}

	public void setObjPackage(String objPackage) {
		this.objPackage = objPackage;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}

	public String getInterfaceConcat() {
		return interfaceConcat;
	}

	public void setInterfaceConcat(String interfaceConcat) {
		this.interfaceConcat = interfaceConcat;
	}
	
	public String getInterfaceObjType() {
		return interfaceObjType;
	}

	public void setInterfaceObjType(String interfaceObjType) {
		this.interfaceObjType = interfaceObjType;
	}

	public String getInterfaceObj() {
		return interfaceObj;
	}

	public void setInterfaceObj(String interfaceObj) {
		this.interfaceObj = interfaceObj;
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	public String getReferencePercent() {
		return referencePercent;
	}

	public void setReferencePercent(String referencePercent) {
		this.referencePercent = referencePercent;
	}

	public String getAppComponent() {
		return appComponent;
	}

	public void setAppComponent(String appComponent) {
		this.appComponent = appComponent;
	}

	public String getUsed() {
		return used;
	}

	public void setUsed(String used) {
		this.used = used;
	}

	public String getImpactedDB() {
		return impactedDB;
	}

	public void setImpactedDB(String impactedDB) {
		this.impactedDB = impactedDB;
	}

	public String getImpactedSimpl() {
		return impactedSimpl;
	}

	public void setImpactedSimpl(String impactedSimpl) {
		this.impactedSimpl = impactedSimpl;
	}

	public String getImpactedExistingError() {
		return impactedExistingError;
	}

	public void setImpactedExistingError(String impactedExistingError) {
		this.impactedExistingError = impactedExistingError;
	}

	public String getImpactedOSMigration() {
		return impactedOSMigration;
	}

	public void setImpactedOSMigration(String impactedOSMigration) {
		this.impactedOSMigration = impactedOSMigration;
	}

	public String getExecDate() {
		return execDate;
	}

	public void setExecDate(String execDate) {
		this.execDate = execDate;
	}

	public String getExecTime() {
		return execTime;
	}

	public void setExecTime(String execTime) {
		this.execTime = execTime;
	}
	
	

}
