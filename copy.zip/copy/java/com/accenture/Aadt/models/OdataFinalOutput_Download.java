package com.accenture.Aadt.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

/**
 * @author rohan.a.mehra
 *
 */
@Entity
@Table(name="Odata_Final_Output_Download" )
public class OdataFinalOutput_Download {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ID")
	private int id;

	@Column(name="OBJECT_TYPE")
	private String OBJECT_TYPE;
	
	@Column(name="OBJ_NAME")
	private String OBJ_NAME;
	
	@Column(name="SUB_PROGRAM")
	private String SUB_PROGRAM;

	@Column(name="SUB_TYPE")
	private String SUB_TYPE;
	
	@Column(name="READ_PROGRAM")
	private String READ_PROGRAM;
	
	@Column(name="LINE_NUMBER")
	private Integer LINE_NUMBER;
	
	@Column(name="PACKAGE")
	private String PACKAGE;
	
	@Column(name="REF_LINE_NO")
	private Integer REF_LINE_NO;
	
	@Column(name="STATEMENT")
	private String STATEMENT;
	
	@Column(name="ODATA")
	private String ODATA;
	
	@Column(name="COUNTER")
	private Integer COUNTER;
	
	@Column(name="OPERATIONS")
	private String OPERATIONS;
	
	@Column(name="TABLES")
	private String TABLES;
	
	@Column(name="TABLE_TYPE")
	private String TABLE_TYPE;
	
	@Column(name="FIELDS")
	private String FIELDS;
	
	@Column(name="COMMENTS")
	private String COMMENTS;
	
	@Column(name="DESCRIPTION")
	private String DESCRIPTION;
	
	@Column(name="REMEDIATION_CATEGORY")
	private String REMEDIATION_CATEGORY;
	
	@Column(name="IMPACT")
	private String IMPACT;
	
	@Column(name="COMPLEXITY")
	private String COMPLEXITY;
	
	@Column(name="OBJ_NAME_TYPE")
	private String OBJ_NAME_TYPE;
	
	@Index(name="Index_Request_id")
	@Column(name="REQUEST_ID")
	private long REQUEST_ID;
	
	@Column(name="Used_Unused")
	private String Used_Unused;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getOBJECT_TYPE() {
		return OBJECT_TYPE;
	}

	public void setOBJECT_TYPE(String oBJECT_TYPE) {
		OBJECT_TYPE = oBJECT_TYPE;
	}

	public String getOBJ_NAME() {
		return OBJ_NAME;
	}

	public void setOBJ_NAME(String oBJ_NAME) {
		OBJ_NAME = oBJ_NAME;
	}

	public String getSUB_PROGRAM() {
		return SUB_PROGRAM;
	}

	public void setSUB_PROGRAM(String sUB_PROGRAM) {
		SUB_PROGRAM = sUB_PROGRAM;
	}

	public String getSUB_TYPE() {
		return SUB_TYPE;
	}

	public void setSUB_TYPE(String sUB_TYPE) {
		SUB_TYPE = sUB_TYPE;
	}

	public String getREAD_PROGRAM() {
		return READ_PROGRAM;
	}

	public void setREAD_PROGRAM(String rEAD_PROGRAM) {
		READ_PROGRAM = rEAD_PROGRAM;
	}

	public String getPACKAGE() {
		return PACKAGE;
	}

	public void setPACKAGE(String pACKAGE) {
		PACKAGE = pACKAGE;
	}


	public Integer getLINE_NUMBER() {
		return LINE_NUMBER;
	}

	public void setLINE_NUMBER(Integer lINE_NUMBER) {
		LINE_NUMBER = lINE_NUMBER;
	}

	public Integer getREF_LINE_NO() {
		return REF_LINE_NO;
	}

	public void setREF_LINE_NO(Integer rEF_LINE_NO) {
		REF_LINE_NO = rEF_LINE_NO;
	}

	public Integer getCOUNTER() {
		return COUNTER;
	}

	public void setCOUNTER(Integer cOUNTER) {
		COUNTER = cOUNTER;
	}

	public String getOBJ_NAME_TYPE() {
		return OBJ_NAME_TYPE;
	}

	public void setOBJ_NAME_TYPE(String oBJ_NAME_TYPE) {
		OBJ_NAME_TYPE = oBJ_NAME_TYPE;
	}

	public String getUsed_Unused() {
		return Used_Unused;
	}

	public void setUsed_Unused(String used_Unused) {
		Used_Unused = used_Unused;
	}

	public String getSTATEMENT() {
		return STATEMENT;
	}

	public void setSTATEMENT(String sTATEMENT) {
		STATEMENT = sTATEMENT;
	}

	public String getODATA() {
		return ODATA;
	}

	public void setODATA(String oDATA) {
		ODATA = oDATA;
	}


	public String getOPERATIONS() {
		return OPERATIONS;
	}

	public void setOPERATIONS(String oPERATIONS) {
		OPERATIONS = oPERATIONS;
	}

	public String getTABLES() {
		return TABLES;
	}

	public void setTABLES(String tABLES) {
		TABLES = tABLES;
	}

	public String getTABLE_TYPE() {
		return TABLE_TYPE;
	}

	public void setTABLE_TYPE(String tABLE_TYPE) {
		TABLE_TYPE = tABLE_TYPE;
	}

	public String getFIELDS() {
		return FIELDS;
	}

	public void setFIELDS(String fIELDS) {
		FIELDS = fIELDS;
	}

	public String getCOMMENTS() {
		return COMMENTS;
	}

	public void setCOMMENTS(String cOMMENTS) {
		COMMENTS = cOMMENTS;
	}

	public String getDESCRIPTION() {
		return DESCRIPTION;
	}

	public void setDESCRIPTION(String dESCRIPTION) {
		DESCRIPTION = dESCRIPTION;
	}

	public String getREMEDIATION_CATEGORY() {
		return REMEDIATION_CATEGORY;
	}

	public void setREMEDIATION_CATEGORY(String rEMEDIATION_CATEGORY) {
		REMEDIATION_CATEGORY = rEMEDIATION_CATEGORY;
	}

	public String getIMPACT() {
		return IMPACT;
	}

	public void setIMPACT(String iMPACT) {
		IMPACT = iMPACT;
	}

	public String getCOMPLEXITY() {
		return COMPLEXITY;
	}

	public void setCOMPLEXITY(String cOMPLEXITY) {
		COMPLEXITY = cOMPLEXITY;
	}

	public long getREQUEST_ID() {
		return REQUEST_ID;
	}

	public void setREQUEST_ID(long rEQUEST_ID) {
		REQUEST_ID = rEQUEST_ID;
	}

	
	

	
	

}
