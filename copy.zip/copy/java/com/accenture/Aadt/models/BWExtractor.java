package com.accenture.Aadt.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "BW_EXTRACTOR")
public class BWExtractor {
	
	@Id	
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "ID")
	private Integer Id;
	
	@Column(name = "REQUEST_ID")
	private Long requestID;

	@Column(name = "OLTSOURCE")
	private String oltsource;
	
	@Column(name="EXTRACTOR") 
	private String extractor;

	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
		Id = id;
	}

	public Long getRequestID() {
		return requestID;
	}

	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}

	public String getOltsource() {
		return oltsource;
	}

	public void setOltsource(String oltsource) {
		this.oltsource = oltsource;
	}

	public String getExtractor() {
		return extractor;
	}

	public void setExtractor(String extractor) {
		this.extractor = extractor;
	}
	
	
}
