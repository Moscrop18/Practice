package com.accenture.Aadt.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "OSMIGRATION_FINAL_LOGICAL_CMD_DOWNLOAD")
public class OSMigrationFinalLogicalCMD_Download {

	@Id	
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "ID")
	private Integer Id;
	
	@Column(name = "REQUEST_ID")
	private Long requestID;
	
	@Column(name = "READ_PROGRAM")
	private String readProgram;

	@Column(name = "STATEMENT", columnDefinition = "TEXT")
	private String statement;
	
	@Column(name = "REM_CATEGORY")
	private String remCategory;
	
	@Column(name = "ISSUE_CATEGORY")
	private String issueCategory;
	
	@Column(name = "ISSUE_SUBCATEGORY")
	private String issueSubcategory;
	
	@Column(name = "INFO")
	private String info;
	
	@Column(name = "HIGH_LVL_DESC")
	private String highLvlDesc;
	
	@Column(name = "IMPACT")
	private String impact;
	
	@Column(name = "AUTOMATION_STATUS")
	private String automationStatus;
	
	@Column(name = "COMPLEXITY")
	private String complexity;

	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
		Id = id;
	}

	public Long getRequestID() {
		return requestID;
	}

	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}

	public String getReadProgram() {
		return readProgram;
	}

	public void setReadProgram(String readProgram) {
		this.readProgram = readProgram;
	}

	public String getStatement() {
		return statement;
	}

	public void setStatement(String statement) {
		this.statement = statement;
	}

	public String getRemCategory() {
		return remCategory;
	}

	public void setRemCategory(String remCategory) {
		this.remCategory = remCategory;
	}

	public String getIssueCategory() {
		return issueCategory;
	}

	public void setIssueCategory(String issueCategory) {
		this.issueCategory = issueCategory;
	}

	public String getIssueSubcategory() {
		return issueSubcategory;
	}

	public void setIssueSubcategory(String issueSubcategory) {
		this.issueSubcategory = issueSubcategory;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public String getHighLvlDesc() {
		return highLvlDesc;
	}

	public void setHighLvlDesc(String highLvlDesc) {
		this.highLvlDesc = highLvlDesc;
	}

	public String getImpact() {
		return impact;
	}

	public void setImpact(String impact) {
		this.impact = impact;
	}

	public String getAutomationStatus() {
		return automationStatus;
	}

	public void setAutomationStatus(String automationStatus) {
		this.automationStatus = automationStatus;
	}

	public String getComplexity() {
		return complexity;
	}

	public void setComplexity(String complexity) {
		this.complexity = complexity;
	}

}
