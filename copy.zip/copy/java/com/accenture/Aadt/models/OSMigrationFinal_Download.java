package com.accenture.Aadt.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "OSMIGRATION_FINAL_DOWNLOAD")
public class OSMigrationFinal_Download {

	@Id	
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "ID")
	private Integer Id;
	
	@Column(name = "REQUEST_ID")
	private Long requestID;
	
	@Column(name = "OBJ_TYPE")
	private String objType;
	
	@Column(name = "OBJ_NAME") 
	private String objName;
	
	@Column(name = "OBJ_TYPE_NAME")
	private String objTypeName;
	
	@Column(name="SUB_TYPE") 
	private String subType;
	
	@Column(name = "READ_PROGRAM")
	private String readProgram;
	
	@Column(name = "OBJ_PACKAGE")
	private String objPackage;
	
	@Column(name = "OPERCD")
	private String operationCode;
	
	@Column(name = "LINE_NO")
	private Integer lineNo;
	
	@Column(name = "STATEMENT", columnDefinition = "TEXT")
	private String statement;
	
	@Column(name = "REM_CATEGORY")
	private String remCategory;
	
	@Column(name = "ISSUE_CATEGORY")
	private String issueCategory;
	
	@Column(name = "ISSUE_SUBCATEGORY")
	private String issueSubcategory;
	
	@Column(name = "INFO")
	private String info;
	
	@Column(name = "HIGH_LVL_DESC")
	private String highLvlDesc;
	
	@Column(name = "IMPACT")
	private String impact;
	
	@Column(name = "AUTOMATION_STATUS")
	private String automationStatus;
	
	@Column(name = "COMPLEXITY")
	private String complexity;
	
	@Column(name = "USED")
	private String used;
	
	@Column(name = "SKIP")
	private String skip;
	
	@Column(name = "SKIP_REASON")
	private String skipReason;
	
	@Column(name = "SELECT_LINE")
	private String selectLine;

	@Column(name = "EXTERNAL_NAMESPACE")
	private String externalNamespace ;

	public String getExternalNamespace() {
		return externalNamespace;
	}

	public void setExternalNamespace(String externalNamespace) {
		this.externalNamespace = externalNamespace;
	}
	
	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
		Id = id;
	}

	public Long getRequestID() {
		return requestID;
	}

	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}

	public String getObjType() {
		return objType;
	}

	public void setObjType(String objType) {
		this.objType = objType;
	}

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}

	public String getObjTypeName() {
		return objTypeName;
	}

	public void setObjTypeName(String objTypeName) {
		this.objTypeName = objTypeName;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public String getReadProgram() {
		return readProgram;
	}

	public void setReadProgram(String readProgram) {
		this.readProgram = readProgram;
	}

	public String getObjPackage() {
		return objPackage;
	}

	public void setObjPackage(String objPackage) {
		this.objPackage = objPackage;
	}

	public String getOperationCode() {
		return operationCode;
	}

	public void setOperationCode(String operationCode) {
		this.operationCode = operationCode;
	}

	public Integer getLineNo() {
		return lineNo;
	}

	public void setLineNo(Integer lineNo) {
		this.lineNo = lineNo;
	}

	public String getStatement() {
		return statement;
	}

	public void setStatement(String statement) {
		this.statement = statement;
	}

	public String getRemCategory() {
		return remCategory;
	}

	public void setRemCategory(String remCategory) {
		this.remCategory = remCategory;
	}

	public String getIssueCategory() {
		return issueCategory;
	}

	public void setIssueCategory(String issueCategory) {
		this.issueCategory = issueCategory;
	}

	public String getIssueSubcategory() {
		return issueSubcategory;
	}

	public void setIssueSubcategory(String issueSubcategory) {
		this.issueSubcategory = issueSubcategory;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public String getHighLvlDesc() {
		return highLvlDesc;
	}

	public void setHighLvlDesc(String highLvlDesc) {
		this.highLvlDesc = highLvlDesc;
	}

	public String getImpact() {
		return impact;
	}

	public void setImpact(String impact) {
		this.impact = impact;
	}

	public String getAutomationStatus() {
		return automationStatus;
	}

	public void setAutomationStatus(String automationStatus) {
		this.automationStatus = automationStatus;
	}

	public String getComplexity() {
		return complexity;
	}

	public void setComplexity(String complexity) {
		this.complexity = complexity;
	}

	public String getUsed() {
		return used;
	}

	public void setUsed(String used) {
		this.used = used;
	}

	public String getSkip() {
		return skip;
	}

	public void setSkip(String skip) {
		this.skip = skip;
	}

	public String getSkipReason() {
		return skipReason;
	}

	public void setSkipReason(String skipReason) {
		this.skipReason = skipReason;
	}

	public String getSelectLine() {
		return selectLine;
	}

	public void setSelectLine(String selectLine) {
		this.selectLine = selectLine;
	}
	@Column(name = "RICEF_CATEGORY")
	private String ricefCategory;

	public String getRicefCategory() {
		return ricefCategory;
	}

	public void setRicefCategory(String ricefCategory) {
		this.ricefCategory = ricefCategory;
	}
	
	
	@Column(name = "RICEF_SUB_CATEGORY")
	private String ricefSubCategory;
	
	public String getRicefSubCategory() {
		return ricefSubCategory;
	}

	public void setRicefSubCategory(String ricefSubCategory) {
		this.ricefSubCategory = ricefSubCategory;
	}

}
