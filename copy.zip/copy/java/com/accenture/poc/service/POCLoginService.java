package com.accenture.poc.service;

import com.accenture.poc.model.User;

public interface POCLoginService {

	
	void pocSignedup(final User user,String role);

	void assignRequest(final String userName, final String[] requestIdArray);
}
