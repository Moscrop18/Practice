package com.accenture.poc.estimates.service;

import java.util.List;

import com.accenture.client.model.RequestForm;
import com.accenture.master.ProcessedEstimates;
import com.accenture.rfp.models.TADIRInventory;

public interface ProcessedEstimatesService {
	void updateEstimatesHANA(Long requestId) throws NoSuchMethodException, SecurityException;
	void updateEstimatesS4(Long requestId);
	List<ProcessedEstimates> getEstimatesReqMaster(Long requestId);
	void insertEstimatesData(ProcessedEstimates processedEst);
	public List<TADIRInventory> getRomEstimates(Long requestId);
	public List<RequestForm> getRequestForm(Long requestId);
}
