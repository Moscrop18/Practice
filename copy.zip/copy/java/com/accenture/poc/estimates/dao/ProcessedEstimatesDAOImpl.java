package com.accenture.poc.estimates.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.accenture.client.model.RequestForm;
import com.accenture.constant.Hana_Profiler_Constant;
import com.accenture.exceptions.HibernateException;
import com.accenture.master.ProcessedEstimates;
import com.accenture.rfp.models.TADIRInventory;

import java.lang.reflect.*;

@Repository
@Transactional
public class ProcessedEstimatesDAOImpl implements ProcessedEstimatesDAO {

	final Logger logger = LoggerFactory.getLogger(ProcessedEstimatesDAOImpl.class);

	private SessionFactory sessionFactory;
	private Session session;

	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	/**
	 * @author sankhamala.a.pal
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<RequestForm> getRequestForm(Long requestId) {

		session = sessionFactory.openSession();
		try {
			final Criteria criteria = session.createCriteria(RequestForm.class);
			criteria.add(Restrictions.eq("requestID", requestId));
			return criteria.list();
		} catch (Exception e) {
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if (session != null)
				session.close();
		}
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<TADIRInventory> getRomEstimates(Long requestId) {

		session = sessionFactory.openSession();

		try {
			final Criteria criteria = session.createCriteria(TADIRInventory.class);
			criteria.add(Restrictions.eq("requestID", requestId));
			return criteria.list();
		} catch (Exception e) {
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if (session != null)
				session.close();
		}
	}
	/**
	 * @author shivani.o.gupta - This method is used for calculating estimates for HANA
	 * @throws SecurityException 
	 * @throws NoSuchMethodException 
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void updateEstimatesCountHANA(Long requestId) throws NoSuchMethodException, SecurityException {
		logger.info("Inside ProcessedEstimatesDAOImpl for HANA ...");
		
		ProcessedEstimates processedEstimates = new ProcessedEstimates();
		
		Map<String, Integer> mandatoryManualMap = getMandatoryManualCounts(requestId);
		Map<String, Map<String, Integer>> mandatoryManualAutoComplexityMap = getMandatoryManualAutoComplexityCounts(requestId);
		Map<String, Integer> usedMandatoryManualMap = getUsedMandatoryManualCounts(requestId);
		Map<String, Map<String, Integer>> usedMandatoryManualAutoComplexityMap = getUsedMandatoryManualAutoComplexityCounts(requestId);
		
		processedEstimates.setRequestID(requestId);
		processedEstimates.setScope("HANA");
		
		@SuppressWarnings("rawtypes")
		Class cls = processedEstimates.getClass(); 
		
		processedEstimates.setRequestID(requestId);
		processedEstimates.setScope("HANA");
	
		/* Estimates Counts --- Category = 'Manual' Counts */
		/* setter eg. --- setDmaCLAS_Count(Integer dmaCLAS_Count) */
		/* entry.getKey() -- Object Type --- CLAS etc. */
		for (Map.Entry<String,Integer> entry : mandatoryManualMap.entrySet()) {
			String setManualCounts = "setDma" + entry.getKey() + "_Count";
			  
			Method methodCall = cls.getDeclaredMethod(setManualCounts, Integer.class);
			  
			try {
				methodCall.invoke(processedEstimates, entry.getValue());
			} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
				logger.error("Error while setting Counts where Category = 'Manual' ... " + e);
			}
		}
		
		/* Estimates Counts --- Category = 'Manual' and Automation_Status='No' Counts with Complexity */
		/* setter eg. --- setDmaCLAS_Count_N_High(Integer dmaCLAS_Count_N_High_Count) */
		/* entry.getKey() -- Object Type --- CLAS etc. */
		for (Map.Entry<String, Map<String,Integer>> entry : mandatoryManualAutoComplexityMap.entrySet()) {
			String setManH = "setDma" + entry.getKey() + "_Count_N_High";
			String setManM = "setDma" + entry.getKey() + "_Count_N_Medium";
			String setManL = "setDma" + entry.getKey() + "_Count_N_Low";
			
			Map<String,Integer> complexityMap = entry.getValue();
			
			Method methodCall = null;
			
			for(Map.Entry<String,Integer> entry1 : complexityMap.entrySet()) {
				if(entry1.getKey().equalsIgnoreCase("HIGH"))
					methodCall = cls.getDeclaredMethod(setManH, Integer.class);
				else if(entry1.getKey().equalsIgnoreCase("MEDIUM"))
					methodCall = cls.getDeclaredMethod(setManM, Integer.class);
				else if(entry1.getKey().equalsIgnoreCase("LOW"))
					methodCall = cls.getDeclaredMethod(setManL, Integer.class);
				  
				try {
					methodCall.invoke(processedEstimates, entry1.getValue());
				} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
					logger.error("Error while setting Counts where Category = 'Manual' "
							+ "and Automation_Status='No' with Complexity ... " + e);
				}
			}	
		}
		
		/* Estimates Counts --- Category = 'Manual' and Used_Unused = 'Y' Counts */
		/* setter eg. --- setDumaCLAS_Count(Integer dumaCLAS_Count) */
		/* entry.getKey() -- Object Type --- CLAS etc. */
		for (Map.Entry<String,Integer> entry : usedMandatoryManualMap.entrySet()) {
			String string = "setDuma" + entry.getKey() + "_Count";
			  
			Method methodCall = cls.getDeclaredMethod(string, Integer.class);
			  
			try {
				methodCall.invoke(processedEstimates, entry.getValue());
			} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
				logger.error("Error while setting Counts where Category = 'Manual' and Used_Unused = 'Y' ... " + e);
			}
		}
		
		/* Estimates Counts --- Category = 'Manual' and Automation_Status='No' and Used_Unused='Y' Counts with Complexity */
		/* setter eg. --- setDumaCLAS_Count_N_High(Integer dmaCLAS_Count_N_High_Count) */
		/* entry.getKey() -- Object Type --- CLAS etc. */
		for (Map.Entry<String, Map<String,Integer>> entry : usedMandatoryManualAutoComplexityMap.entrySet()) {
			String setManH = "setDuma" + entry.getKey() + "_Count_N_High";
			String setManM = "setDuma" + entry.getKey() + "_Count_N_Medium";
			String setManL = "setDuma" + entry.getKey() + "_Count_N_Low";
			
			Map<String,Integer> complexityMap = entry.getValue();
			
			Method methodCall = null;
			
			for(Map.Entry<String,Integer> entry1 : complexityMap.entrySet()) {
				if(entry1.getKey().equalsIgnoreCase("HIGH"))
					methodCall = cls.getDeclaredMethod(setManH, Integer.class);
				else if(entry1.getKey().equalsIgnoreCase("MEDIUM"))
					methodCall = cls.getDeclaredMethod(setManM, Integer.class);
				else if(entry1.getKey().equalsIgnoreCase("LOW"))
					methodCall = cls.getDeclaredMethod(setManL, Integer.class);
				  
				try {
					methodCall.invoke(processedEstimates, entry1.getValue());
				} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
					logger.error("Error while setting Counts where Category = 'Manual' and Automation_Status='No' with Complexity ... " + e);
				}
			}	
		}
		
		/* Estimates Counts --- Category = 'Manual' and Automation_Status='Yes' Counts with Complexity */
		/* setter eg. --- setDmaCLAS_Count_Y_High(Integer dmaCLAS_Count_Y_High_Count) */
		/* entry.getKey() -- Object Type --- CLAS etc. */
		for (Map.Entry<String, Map<String,Integer>> entry : mandatoryManualAutoComplexityMap.entrySet()) {
			if(entry.getKey().equals("FUGR") || entry.getKey().equals("FUGS") || 
					entry.getKey().equals("PROG") || entry.getKey().equals("CLAS")) {
				String setManL = "setDma" + entry.getKey() + "_Count_Y_Low";
				
				Map<String,Integer> complexityMap = entry.getValue();
				
				Method methodCall = null;
				Integer sum  = 0;
				
				for(Integer value : complexityMap.values()) {
					sum += value;
				}
				
				methodCall = cls.getDeclaredMethod(setManL, Integer.class);
					  
				try {
					Integer count  = getAutoComplexityCount(mandatoryManualMap, sum, entry.getKey());
					methodCall.invoke(processedEstimates, count);
				} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
					logger.error("Error while setting Counts where Category = 'Manual' and Automation_Status='Yes' with Complexity ... " + e);
				}
			}		
		}
		
		/* Estimates Counts --- Category = 'Manual' and Used_Unused = 'Y' Counts and Automation_Status='No' with Complexity */
		/* setter eg. --- setDumaCLAS_Count_Y_High(Integer dmaCLAS_Count_Y_High_Count) */
		/* entry.getKey() -- Object Type --- CLAS etc. */
		for (Map.Entry<String, Map<String,Integer>> entry : usedMandatoryManualAutoComplexityMap.entrySet()) {
			if(entry.getKey().equals("FUGR") || entry.getKey().equals("FUGS") || 
					entry.getKey().equals("PROG") || entry.getKey().equals("CLAS")) {
				String setManL = "setDuma" + entry.getKey() + "_Count_Y_Low";
				
				Map<String,Integer> complexityMap = entry.getValue();
				
				Method methodCall = null;
				Integer sum  = 0;
				
				for(Integer value : complexityMap.values()) {
					sum += value;
				}
				
			    methodCall = cls.getDeclaredMethod(setManL, Integer.class);
					  
				try {
					Integer count = getAutoComplexityCount(usedMandatoryManualMap, sum, entry.getKey());
					methodCall.invoke(processedEstimates, count);
				} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
					logger.error("Error while setting Counts where Category = 'Manual' and Used_Unused = 'Y' Counts and Automation_Status='No' with Complexity ... " + e);
				}
			}	
		}
		
		insertEstimatesData(processedEstimates);
	    logger.info("Calculation of estimates of HANA is completed ...");
	}

	/**
	 * @author shivani.o.gupta - This method is used for calculating estimates for S4
	 */
	@Override
	public void updateEstimatesCountS4(Long requestId) {
		logger.info("Inside ProcessedEstimatesDAOImpl for S4 ...");
		
	}

	@Override
	public Map<String, Integer> getMandatoryManualCounts(Long requestId) {
		 Map<String, Integer> resultMap = new HashMap<String, Integer>();
		 
		 String hql = "select Object_Type, count(distinct objNameType) from HanaProfile_Download where requestID=:requestId and "
		 		+ "Category=:category group by Object_Type";
		 
		 try {
			 session = sessionFactory.openSession();
			 Query query = session.createQuery(hql);
			 query.setParameter("requestId", requestId);
			 query.setParameter("category", "Mandatory");
			 
			 @SuppressWarnings("unchecked")
			 List<Object[]> resultList = query.list();
			 
			 resultMap = calculateCountsForManadatoryAndMandatoryUsed(resultList);
			 
		 } catch(Exception e) {
			 logger.error("Error while calculating MandatoryManualCounts ...");
			 logger.error(e.getMessage());			 
		 } finally {
			 if(session!=null)
				session.close();
		 }
		 
		 return resultMap;
	}

	@Override
	public Map<String, Map<String, Integer>> getMandatoryManualAutoComplexityCounts(Long requestId) {
		Map<String, Map<String, Integer>> resultMap = new HashMap<String, Map<String, Integer>>();
		
		String hql = "select Object_Type, COMPLEXITY, count(distinct objNameType) from HanaProfile_Download where requestID=:requestId "
				+ "and Category=:category and automation_status=:autoStat group by Object_Type, COMPLEXITY";
		
		try {
			 session = sessionFactory.openSession();
			 Query query = session.createQuery(hql);
			 query.setParameter("requestId", requestId);
			 query.setParameter("category", "Mandatory");
			 query.setParameter("autoStat", "No");
			 
			 @SuppressWarnings("unchecked")
			 List<Object[]> resultList = query.list();
			 
			 resultMap = calculateCountsForManualAndManualUsed(resultList);
			 	 
		} catch(Exception e) {
			logger.error("Error while calculating MandatoryManualAutoComplexityCounts ...");
			logger.error(e.getMessage());					
		} finally {
			if(session!=null)
				session.close();
		}
		
		return resultMap;
	}

	@Override
	public Map<String, Integer> getUsedMandatoryManualCounts(Long requestId) {
		Map<String, Integer> resultMap = new HashMap<String, Integer>();
		
		String hql = "select Object_Type, count(distinct objNameType) from HanaProfile_Download where requestID=:requestId and "
				+ "Category=:category and Used_Unused=:usedUnused group by Object_Type";
		 
		 try {
			 session = sessionFactory.openSession();
			 Query query = session.createQuery(hql);
			 query.setParameter("requestId", requestId);
			 query.setParameter("category", "Mandatory");
			 query.setParameter("usedUnused", "Y");
			 
			 @SuppressWarnings("unchecked")
			 List<Object[]> resultList = query.list();
			 
			 resultMap = calculateCountsForManadatoryAndMandatoryUsed(resultList);
			 
		 } catch(Exception e) {
			 logger.error("Error while calculating UsedMandatoryManualCounts ...");
			 logger.error(e.getMessage());		
		 } finally {
			 if(session!=null)
					session.close();
		 }
		
		return resultMap;		
	}

	@Override
	public Map<String, Map<String, Integer>> getUsedMandatoryManualAutoComplexityCounts(Long requestId) {
		Map<String, Map<String, Integer>> resultMap = new HashMap<String, Map<String, Integer>>();
		
		String hql = "select Object_Type, COMPLEXITY, count(distinct objNameType) " + 
				"from HanaProfile_Download where requestID=:requestId and Category=:category and automation_status=:autoStat "
				+ "and Used_Unused=:usedUnused group by Object_Type, complexity";
		
		try {
			 session = sessionFactory.openSession();
			 Query query = session.createQuery(hql);
			 query.setParameter("requestId", requestId);
			 query.setParameter("category", "Mandatory");
			 query.setParameter("autoStat", "No");
			 query.setParameter("usedUnused", "Y");
			 
			 @SuppressWarnings("unchecked")
			 List<Object[]> resultList = query.list();
			 
			 resultMap = calculateCountsForManualAndManualUsed(resultList);
			 
		} catch(Exception e) {
			logger.error("Error while calculating UsedMandatoryManualAutoComplexityCounts ...");
			logger.error(e.getMessage());		
		} finally {
			if(session!=null)
				session.close();
		}
		
		return resultMap;
	}
	
    private Integer getAutoComplexityCount(Map<String, Integer> mandatoryManualMap, Integer sum, String manKey) {
		Integer countAutoComplexity = 0;
		if (mandatoryManualMap != null && mandatoryManualMap.containsKey(manKey)) {
			countAutoComplexity = mandatoryManualMap.get(manKey) - sum;
		}
		
		return countAutoComplexity;
	}
    
    private Map<String, Integer> calculateCountsForManadatoryAndMandatoryUsed (List<Object[]> resultList) {
    	final  Map<String, Integer> resultMap = new HashMap<String, Integer>();
    	
    	String objectType = "";
		Long objectValue = 0L;
		Long countENH = 0L;
		Long countUSEREXIT = 0L;
		Long countFORM = 0L;
		
		if (CollectionUtils.isNotEmpty(resultList)) {
			 for(Object[] object : resultList) {
				 objectType = ((String) object[0]).trim();
				 if(objectType.startsWith("ENH")) {
					 countENH += (Long) object[1];
					 objectValue = countENH;
					 resultMap.put("ENH", objectValue.intValue());
				 } else if (objectType.startsWith("US")) {
					 countUSEREXIT += (Long) object[1];
					 objectValue = countUSEREXIT;
					 resultMap.put("USEREXIT", objectValue.intValue());
				 } else if (objectType.equals("SFPI") || objectType.equals("SSFO")) {
					 countFORM += (Long) object[1];
					 objectValue = countFORM;
					 resultMap.put("FORM", objectValue.intValue());
				 } else {
					 objectValue = (Long) object[1];
					 resultMap.put(objectType.toUpperCase(), objectValue.intValue());
				 }
			 }
		 }
		
    	return resultMap;
    }

	private Map<String, Map<String, Integer>> calculateCountsForManualAndManualUsed (List<Object[]> resultList) {

		final Map<String, Map<String, Integer>> resultMap = new HashMap<String, Map<String, Integer>>();
		Map<String, Integer> complexityMap = null;

		String objectType = "";
		String complexity = "";
		Long objectValue = 0L;
		Long countENH_HIGH = 0L;
		Long countENH_MED = 0L;
		Long countENH_LOW = 0L;
		Long countUSEREXIT_HIGH = 0L;
		Long countUSEREXIT_MED = 0L;
		Long countUSEREXIT_LOW = 0L;
		Long countFORM_HIGH = 0L;
		Long countFORM_MED = 0L;
		Long countFORM_LOW = 0L;

		if (CollectionUtils.isNotEmpty(resultList)) {
			for (Object[] object : resultList) {
				objectType = ((String) object[0]).trim();
				complexity = ((String) object[1]).trim();

				if (objectType.startsWith("ENH")) {
					if (complexity.equalsIgnoreCase("High")) {
						countENH_HIGH += (Long) object[2];
						objectValue = countENH_HIGH;
					} else if (complexity.equalsIgnoreCase("Medium")) {
						countENH_MED += (Long) object[2];
						objectValue = countENH_MED;
					} else if (complexity.equalsIgnoreCase("Low")) {
						countENH_LOW += (Long) object[2];
						objectValue = countENH_LOW;
					}

					if (resultMap.containsKey("ENH")) {
						complexityMap = resultMap.get("ENH");
						complexityMap.put(complexity.toUpperCase(), objectValue.intValue());
					} else {
						complexityMap = new HashMap<String, Integer>();
						complexityMap.put(complexity.toUpperCase(), objectValue.intValue());
					}

					resultMap.put("ENH", complexityMap);
				} else if (objectType.startsWith("US")) {
					if (complexity.equalsIgnoreCase("High")) {
						countUSEREXIT_HIGH += (Long) object[2];
						objectValue = countUSEREXIT_HIGH;
					} else if (complexity.equalsIgnoreCase("Medium")) {
						countUSEREXIT_MED += (Long) object[2];
						objectValue = countUSEREXIT_MED;
					} else if (complexity.equalsIgnoreCase("Low")) {
						countUSEREXIT_LOW += (Long) object[2];
						objectValue = countUSEREXIT_LOW;
					}

					if (resultMap.containsKey("USEREXIT")) {
						complexityMap = resultMap.get("USEREXIT");
						complexityMap.put(complexity.toUpperCase(), objectValue.intValue());
					} else {
						complexityMap = new HashMap<String, Integer>();
						complexityMap.put(complexity.toUpperCase(), objectValue.intValue());
					}

					resultMap.put("USEREXIT", complexityMap);
				} else if (objectType.equals("SFPI") || objectType.equals("SSFO")) {
					if (complexity.equalsIgnoreCase("High")) {
						countFORM_HIGH += (Long) object[2];
						objectValue = countFORM_HIGH;
					} else if (complexity.equalsIgnoreCase("Medium")) {
						countFORM_MED += (Long) object[2];
						objectValue = countFORM_MED;
					} else if (complexity.equalsIgnoreCase("Low")) {
						countFORM_LOW += (Long) object[2];
						objectValue = countFORM_LOW;
					}

					if (resultMap.containsKey("FORM")) {
						complexityMap = resultMap.get("FORM");
						complexityMap.put(complexity.toUpperCase(), objectValue.intValue());
					} else {
						complexityMap = new HashMap<String, Integer>();
						complexityMap.put(complexity.toUpperCase(), objectValue.intValue());
					}

					resultMap.put("FORM", complexityMap);
				} else {
					objectValue = (Long) object[2];

					if (resultMap.containsKey(objectType)) {
						complexityMap = resultMap.get(objectType);
						complexityMap.put(complexity.toUpperCase(), objectValue.intValue());
					} else {
						complexityMap = new HashMap<String, Integer>();
						complexityMap.put(complexity.toUpperCase(), objectValue.intValue());
					}

					resultMap.put(objectType.toUpperCase(), complexityMap);
				}
			}
		}

		return resultMap;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ProcessedEstimates> getEstimatesReqMaster(Long requestId) {

		session = sessionFactory.openSession();

		try {
			final Criteria criteria = session.createCriteria(ProcessedEstimates.class);
			criteria.add(Restrictions.eq("requestID", requestId));
			return criteria.list();
		} catch (Exception e) {
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if (session != null)
				session.close();
		}
	}

	@Override
	public void insertEstimatesData(ProcessedEstimates processedEst) {
		session = sessionFactory.openSession();
		try {
			session.saveOrUpdate(processedEst);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if (session != null)
				session.close();
		}

		logger.info("Estimates data sucessfully written to DB !!!");
	}
	
}
