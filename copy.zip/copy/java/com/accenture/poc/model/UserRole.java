package com.accenture.poc.model;

import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.persistence.PrePersist;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "USER_ROLE")
public class UserRole implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1170469097396397465L;
	private Integer userRoleId;
	private User user;
	private String userRole;

	public UserRole() {
	}

	public UserRole(User user, String userRole) {
		this.user = user;
		this.userRole = userRole;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "USER_ROLE_ID", 
		nullable = false)
	
	public Integer getUserRoleId() {
		return this.userRoleId;
	}

	public void setUserRoleId(Integer userRoleId) {
		this.userRoleId = userRoleId;
	}

	/*@PrePersist
	public void prePersist() {
	    if(userRole == null) //We set default value in case if the value is not set yet.
	    	userRole = "USER";
	}*/
	
	@Column(name = "USER_ROLE", nullable = false, updatable = true, length = 45)
	
	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "EMAIL_ID", nullable = false)
	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	
}