package com.accenture.poc.model;

import com.accenture.client.model.RequestForm;

import javax.persistence.*;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;


@Entity

@Table(name="REQUEST_PROCESS")
public class RequestProcess {

	Long requestID;
	byte[] trAttachement;
	String rejectionComments;
	RequestForm requestForm;
	String status;
	
	
	@Id
    @GeneratedValue(generator = "gen")
    @GenericGenerator(name = "gen", strategy = "foreign",
    parameters = @Parameter(name = "property", value = "requestForm"))
	@Column(name="REQUEST_ID")
	public Long getRequestID() {
		return requestID;
	}
	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}
	
	@Column(name="TR_ATTACHMENT")
	public byte[] getTrAttachement() {
		return trAttachement;
	}
	public void setTrAttachement(byte[] trAttachement) {
		this.trAttachement = trAttachement;
	}
	
	@Column(name="REJECTION_COMMENTS")
	public String getRejectionComments() {
		return rejectionComments;
	}
	public void setRejectionComments(String rejectionComments) {
		this.rejectionComments = rejectionComments;
	}

	@Column(name="STATUS")
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	/*@OneToOne(mappedBy="requestProcess")

	public RequestForm getRequestForm() {
		return requestForm;
	}
	public void setRequestForm(RequestForm requestForm) {
		this.requestForm = requestForm;
	}*/
	
	public RequestProcess() {
	}
}
