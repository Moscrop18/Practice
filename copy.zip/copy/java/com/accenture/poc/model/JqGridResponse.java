package com.accenture.poc.model;

import java.util.List;

import com.accenture.S4.models.S4HanaProfiler;
import com.accenture.displaygrid.model.HanaProfile;

public class JqGridResponse {

	/**
	 * Current page of the query
	 */
	private String page;

	/**
	 * Total pages for the query
	 */
	private String total;

	/**
	 * Total number of records for the query
	 */
	private String records;

	/**
	 * An array that contains the actual objects
	 */
	private List rows;
	
	
	

	public JqGridResponse() {
		// TODO Auto-generated constructor stub
	}

	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public String getTotal() {
		return total;
	}

	public void setTotal(String total) {
		this.total = total;
	}

	public String getRecords() {
		return records;
	}

	public void setRecords(String records) {
		this.records = records;
	}

	public List getRows() {
		return rows;
	}

	public void setRows(List rows) {
		this.rows = rows;
	}
	
	

	
}
