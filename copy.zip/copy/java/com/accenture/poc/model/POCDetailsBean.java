package com.accenture.poc.model;

public class POCDetailsBean {

	private long requestId;
	
	private String request_id_ui;	
	
	public String status;
	private String comments;
	private Long updatedDate;	
	private String assigned_poc_emailId;
	private String poc_status;
	private String poc_comments;
	private String assignedFaitEmailId;
	private String poc_Fiat_Status;
	private String journey_Category;
	private String poc_sub_status;
	private Boolean sia;
	private Boolean soh;
	private Boolean s4;
	private Boolean fiat;
	private Boolean ui5;
	private Boolean fiori;
	private Boolean upgrd;
	private Boolean osMig;
	private Boolean otherScope;
	private Boolean bwUsage;
	private Boolean bwTech;
	private Boolean grc;
	private Boolean EXT;
	
	public Boolean getBwUsage() {
		return bwUsage;
	}

	public void setBwUsage(Boolean bwUsage) {
		this.bwUsage = bwUsage;
	}

	public Boolean getBwTech() {
		return bwTech;
	}

	public void setBwTech(Boolean bwTech) {
		this.bwTech = bwTech;
	}

	public Boolean getGrc() {
		return grc;
	}

	public void setGrc(Boolean grc) {
		this.grc = grc;
	}

	public Boolean getOsMig() {
		return osMig;
	}

	public void setOsMig(Boolean osMig) {
		this.osMig = osMig;
	}

	public void setOtherScope(Boolean otherScope) {
		this.otherScope = otherScope;
	}
	
	public Boolean getSia() {
		return sia;
	}
	
	public Boolean getFiori() {
		return fiori;
	}
	public void setFiori(Boolean fiori) {
		this.fiori = fiori;
	}
	public Boolean getUpgrd() {
		return upgrd;
	}
	public void setUpgrd(Boolean upgrd) {
		this.upgrd = upgrd;
	}
	public void setSia(Boolean sia) {
		this.sia = sia;
	}

	public String getRfpStatus() {
		return rfpStatus;
	}
	public void setRfpStatus(String rfpStatus) {
		this.rfpStatus = rfpStatus;
	}
	private Boolean RFP;
	
	
	public Boolean getRFP() {
		return RFP;
	}
	public void setRFP(Boolean rFP) {
		RFP = rFP;
	}
	private String rfpStatus;
	
	public String getAssignedFaitEmailId() {
		return assignedFaitEmailId;
	}
	public void setAssignedFaitEmailId(String assignedFaitEmailId) {
		this.assignedFaitEmailId = assignedFaitEmailId;
	}
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getRequest_id_ui() {
		return request_id_ui;
	}
	public void setRequest_id_ui(String request_id_ui) {
		this.request_id_ui = request_id_ui;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public Long getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(Long updatedDate) {
		this.updatedDate = updatedDate;
	}
	public String getAssigned_poc_emailId() {
		return assigned_poc_emailId;
	}
	public void setAssigned_poc_emailId(String assigned_poc_emailId) {
		this.assigned_poc_emailId = assigned_poc_emailId;
	}
	public String getPoc_status() {
		return poc_status;
	}
	public void setPoc_status(String poc_status) {
		this.poc_status = poc_status;
	}
	public String getPoc_comments() {
		return poc_comments;
	}
	public void setPoc_comments(String poc_comments) {
		this.poc_comments = poc_comments;
	}
	public String getPoc_Fiat_Status() {
		return poc_Fiat_Status;
	}
	public void setPoc_Fiat_Status(String poc_Fiat_Status) {
		this.poc_Fiat_Status = poc_Fiat_Status;
	}
	public String getJourney_Category() {
		return journey_Category;
	}
	public void setJourney_Category(String journey_Category) {
		this.journey_Category = journey_Category;
	}
	public String getPoc_sub_status() {
		return poc_sub_status;
	}
	public void setPoc_sub_status(String poc_sub_status) {
		this.poc_sub_status = poc_sub_status;
	}
	public Boolean getSoh() {
		return soh;
	}
	public void setSoh(Boolean soh) {
		this.soh = soh;
	}
	public Boolean getS4() {
		return s4;
	}
	public void setS4(Boolean s4) {
		this.s4 = s4;
	}
	public Boolean getFiat() {
		return fiat;
	}
	public void setFiat(Boolean fiat) {
		this.fiat = fiat;
	}
	public Boolean getUi5() {
		return ui5;
	}
	public void setUi5(Boolean ui5) {
		this.ui5 = ui5;
	}
	
	public Boolean getOtherScope() {
		boolean Scope = false;
		if (getS4() != null) {
			Scope = Scope || getS4();
		}
		if (getFiat() != null) {
			Scope = Scope || getFiat();
		}
		if (getSoh() != null) {
			Scope = Scope || getSoh();
		}
		if (getUi5() != null) {
			Scope = Scope || getUi5();
		}
		if (getUpgrd() != null) {
			Scope = Scope || getUpgrd();
		}
		if (getFiori() != null) {
			Scope = Scope || getFiori();
		}
		
		if (getOsMig() != null) {
			Scope = Scope || getOsMig();
		}
		if (getEXT()!= null) {
			Scope = Scope || getEXT();
		}
		return Scope;
	}

	
	public Boolean getEXT() {
		return EXT;
	}
	public void setEXT(Boolean eXT) {
		EXT = eXT;
	}
}
