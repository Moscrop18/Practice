package com.accenture.poc.dao;

import java.util.List;

import com.accenture.poc.model.User;

public interface POCLoginDao {

	User getUser(final String userName);

	void assignRequest(final String userName,final  List<Long> requestIdList);
}
