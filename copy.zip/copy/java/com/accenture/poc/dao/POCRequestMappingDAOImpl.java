package com.accenture.poc.dao;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Disjunction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.accenture.client.dao.RequestInventoryDAO;
import com.accenture.client.model.RequestForm;
import com.accenture.client.model.RequestFormDetailsBean;
import com.accenture.client.model.RequestInventory;
import com.accenture.constant.Hana_Profiler_Constant;
import com.accenture.exceptions.HibernateException;
import com.accenture.model.StatusMaster;
import com.accenture.poc.model.POCDetailsBean;
import com.accenture.poc.model.POCRequestMapping;
import com.accenture.utility.HANAUtility;

@Transactional
public class POCRequestMappingDAOImpl implements POCRequestMappingDAO {

	final public Logger logger = LoggerFactory.getLogger(POCRequestMappingDAOImpl.class);
	private HibernateTemplate hibernateTemplate;
	SessionFactory sessionFactory;
	RequestInventoryDAO requestInventoryDao;
	POCRequestInventoryDAO pocRequestInventorydao;

	public void setRequestInventoryDao(RequestInventoryDAO requestInventoryDao) {
		this.requestInventoryDao = requestInventoryDao;
	}

	public void setPocRequestInventorydao(POCRequestInventoryDAO pocRequestInventorydao) {
		this.pocRequestInventorydao = pocRequestInventorydao;
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	private List<POCRequestMapping> getRequests(final String userName) {
		try {

			logger.info("Inside DAOIMPL class");
			final Session session = sessionFactory.getCurrentSession();
			final Criteria criteria = session.createCriteria(POCRequestMapping.class, "requestMapping");
			criteria.createAlias("requestMapping.user", "user");
			criteria.add(Restrictions.eq("user.userName", userName));
			criteria.addOrder(Order.asc("user.userName"));
			criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			return criteria.list();

		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<RequestFormDetailsBean> getRequests(final String userName, final String status, final Long requestId,
			final Integer limit, final Integer start, final String toolName) {
		try {
			return (List<RequestFormDetailsBean>) hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {

					ProjectionList projection = Projections.projectionList();
					projection.add(Projections.property("requestForm.requestID"), "requestId");
					projection.add(Projections.property("requestForm.sia"), "sia");
					projection.add(Projections.property("requestMapping.REQUEST_ID_UI"), "REQUEST_ID_UI");
					projection.add(Projections.property("requestInventory.requestShortdescription"),
							"shortDescription");
					projection.add(Projections.property("requestInventory.requestStatus"), "status");
					projection.add(Projections.property("requestInventory.comments"), "comments");
					projection.add(Projections.property("requestInventory.updatedDate"), "updatedDate");
					//projection.add(Projections.property("pocUser.userName"), "emailId");
					projection.add(Projections.property("pocUser.emailId"), "emailId");

					final Criteria criteria = session.createCriteria(POCRequestMapping.class, "requestMapping");
					criteria.createAlias("requestMapping.requestForm", "requestForm");
					criteria.createAlias("requestForm.requestInventory", "requestInventory");
					criteria.createAlias("requestMapping.user", "pocUser");
					criteria.addOrder(Order.desc("updatedDate"));
					if (StringUtils.isNotBlank(userName)) {
						criteria.add(Restrictions.eq("pocUser.userName", userName));
						criteria.addOrder(Order.asc("pocUser.userName"));
					}
					if (StringUtils.isNotBlank(status)) {
						criteria.add(Restrictions.in("requestInventory.requestStatus",
								HANAUtility.getApplicationStatus(status)));
					}
					if (requestId != null) {
						criteria.add(Restrictions.eq("requestForm.requestID", requestId));
					}
					criteria.add(Restrictions.eq("toolName", toolName));
					criteria.setProjection(projection);
					if (start != null) {
						criteria.setFirstResult(start);
					}
					if (limit != null) {
						criteria.setMaxResults(limit);
					}
					criteria.setResultTransformer(Transformers.aliasToBean(RequestFormDetailsBean.class));
					return criteria.list();
				}
			});
		} catch (Exception e) {
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);

		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private POCRequestMapping getPOCRequestMapping(final Long requestId) {

		try {
			return (POCRequestMapping) hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {
					final Criteria criteria = session.createCriteria(POCRequestMapping.class);
					criteria.add(Restrictions.eq("requestId", requestId));
					return criteria.uniqueResult();
				}
			});
		} catch (Exception e) {
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);

		}

	}

	public void addUser(final String userName, final Long requestId) {

		try {
			POCRequestMapping pocRequestMapping = getPOCRequestMapping(requestId);
			pocRequestMapping.setUserName(userName);
			pocRequestMapping.setEmailId(userName);
			hibernateTemplate.update(pocRequestMapping);
		} catch (Exception e) {
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);

		}

	}

	public String resetStatus(String userName) {

		try {
			Session session = sessionFactory.getCurrentSession();

			List<POCRequestMapping> mappings = getRequests(userName);
			if (mappings != null) {
				for (POCRequestMapping mapping : mappings) {
					RequestForm request = mapping.getRequestForm();
					RequestInventory inventory = requestInventoryDao.getRequestInventory(request.getRequestID());
					if ((inventory.getRequestStatus()).equals("Pending")) {
						inventory.setRequestStatus("Initiated");
						inventory.setUpdatedDate(Calendar.getInstance().getTimeInMillis());
						inventory.setComments("Request is Submitted Successfully,our team will look into it");
						session.update(inventory);
						/*
						 * Object persistentInstance =
						 * session.get(POCRequestMapping.class,
						 * mapping.getPOCRequestMapping_ID()); if
						 * (persistentInstance != null) {
						 * session.delete(persistentInstance);
						 * 
						 * }
						 */
						mapping.setUserName(null);
						session.update(mapping);
					}
					logger.info("Inside remove mappings method,setting status to intitiated");
				}

				return "Mappings corresponding to the User" + userName + "are removed in POC_REQUEST_MAPPING table";
			} else {
				return "No Mappings in POC_REQUEST_MAPPING table corresponding to this user";
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	@SuppressWarnings("unchecked")
	public List<StatusMaster> getStatusList() {
		try {
			final Session session = sessionFactory.getCurrentSession();
			final Criteria criteria = session.createCriteria(StatusMaster.class);
			criteria.add(Restrictions.eq("isClientStatus", 1));
			return criteria.list();
		} catch (Exception e) {

			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);

		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<RequestFormDetailsBean> getClientRequests(final String userName, final String status,
			final Long requestId, final Integer limit, final Integer start, final String toolName) {
		try {
			return (List<RequestFormDetailsBean>) hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {

					ProjectionList projection = Projections.projectionList();
					projection.add(Projections.property("requestForm.requestID"), "requestId");
					projection.add(Projections.property("requestForm.s4Technical"), "s4Technical");
					projection.add(Projections.property("requestForm.RFP"), "RFP");
					projection.add(Projections.property("requestForm.sia"), "sia");
					projection.add(Projections.property("requestMapping.REQUEST_ID_UI"), "REQUEST_ID_UI");
					projection.add(Projections.property("requestInventory.requestShortdescription"),
							"shortDescription");
					projection.add(Projections.property("requestInventory.requestStatus"), "status");
					projection.add(Projections.property("requestInventory.trDownloadStatus"), "trDownloadStatus");
					projection.add(Projections.property("requestInventory.deletiontrDownloadStatus"), "deletiontrDownloadStatus");
					projection.add(Projections.property("requestInventory.contentDownloadStatus"), "contentDownloadStatus");
					projection.add(Projections.property("requestInventory.comments"), "comments");
					projection.add(Projections.property("requestInventory.updatedDate"), "updatedDate");
					projection.add(Projections.property("requestInventory.s4ValidationDownloadStatus"), "s4ValidationDownloadStatus");
					projection.add(Projections.property("requestInventory.preReqDownloadStatus"), "preReqDownloadStatus");
					projection.add(Projections.property("requestInventory.isSubRequest"), "isSubRequest");
					projection.add(Projections.property("requestInventory.mainRequestId"), "mainRequestId");
					projection.add(Projections.property("requestInventory.mainRequestIdUI"), "mainRequestIdUI");
					projection.add(Projections.property("pocUser.userName"), "userName");
					projection.add(Projections.property("pocUser.emailId"), "emailId");
					 
					projection.add(Projections.property("requestInventory.rfpStatus"), "rfpStatus");

					final Criteria criteria = session.createCriteria(POCRequestMapping.class, "requestMapping");
					criteria.createAlias("requestMapping.requestForm", "requestForm");
					criteria.createAlias("requestForm.requestInventory", "requestInventory");
					criteria.createAlias("requestMapping.user", "pocUser", JoinType.LEFT_OUTER_JOIN);
					criteria.add(Restrictions.eq("clientName", userName));
					criteria.add(Restrictions.eq("toolName", toolName));
					if (StringUtils.isNotBlank(status)) {
						criteria.add(Restrictions.in("requestInventory.requestStatus",
								HANAUtility.getApplicationStatus(status)));
					}
					if (requestId != null) {
						criteria.add(Restrictions.eq("requestForm.requestID", requestId));
					}
					criteria.setProjection(projection);
					criteria.addOrder(Order.desc("updatedDate"));
					/*
					 * criteria.setFirstResult(start); criteria.setMaxResults(limit);
					 */
					criteria.setResultTransformer(Transformers.aliasToBean(RequestFormDetailsBean.class));
					return criteria.list();
				}
			});
		} catch (Exception e) {
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);

		}
	}

	@Override
	public void addClientData(final long requestID, final String clientName, final String requestIdUI, final String toolName) {
		try {
			final POCRequestMapping pocRequestMapping = new POCRequestMapping();
			pocRequestMapping.setClientName(clientName);
			pocRequestMapping.setRequestId(requestID);
			pocRequestMapping.setREQUEST_ID_UI(requestIdUI);
			pocRequestMapping.setToolName(toolName);
			
			hibernateTemplate.save(pocRequestMapping);
		} catch (Exception e) {
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);

		}

	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public boolean checkRequestId(final Long requestId, final String userName, final boolean isClient) {
		try {
			long rowCount = (long) hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {
					final Criteria criteria = session.createCriteria(POCRequestMapping.class, "pocRequestMapping");
					if (isClient) {
						criteria.add(Restrictions.eq("clientName", userName));
					} else {
						criteria.add(Restrictions.or(Restrictions.isNull("userName"),
								Restrictions.eq("userName", userName)));
					}
					criteria.add(Restrictions.eq("requestId", requestId));
					criteria.setProjection(Projections.rowCount());
					return criteria.uniqueResult();
				}
			});
			return rowCount > 0;
		} catch (Exception e) {
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);

		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public Integer getTotalClientRequests(final String userName, final String status, final Long requestId, final String toolName) {
		try {
			Long count = (Long) hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {

					final Criteria criteria = session.createCriteria(POCRequestMapping.class, "requestMapping");
					criteria.add(Restrictions.eq("clientName", userName));
					criteria.add(Restrictions.eq("toolName", toolName));
					if (StringUtils.isNotBlank(status)) {
						criteria.createAlias("requestMapping.requestForm", "requestForm");
						criteria.createAlias("requestForm.requestInventory", "requestInventory");
						criteria.add(Restrictions.in("requestInventory.requestStatus",
								HANAUtility.getApplicationStatus(status)));
					}
					if (requestId != null) {
						criteria.add(Restrictions.eq("requestMapping.requestId", requestId));
					}
					criteria.setProjection(Projections.countDistinct("requestMapping.requestId"));
					return criteria.uniqueResult();
				}
			});

			return count.intValue();
		} catch (Exception e) {
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);

		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public Integer getTotalUserRequests(final String userName, final String status, final Long requestId, final String toolName) {
		try {
			Long count = (Long) hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {

					final Criteria criteria = session.createCriteria(POCRequestMapping.class, "requestMapping");
					if (StringUtils.isNotBlank(userName)) {
						criteria.add(Restrictions.eq("userName", userName));
					} else {
						criteria.add(Restrictions.isNotNull("userName"));
					}
					if (StringUtils.isNotBlank(status)) {
						criteria.createAlias("requestMapping.requestForm", "requestForm");
						criteria.createAlias("requestForm.requestInventory", "requestInventory");
						criteria.add(Restrictions.in("requestInventory.requestStatus",
								HANAUtility.getApplicationStatus(status)));
					}
					if (requestId != null) {
						criteria.add(Restrictions.eq("requestMapping.requestId", requestId));
					}
					criteria.add(Restrictions.eq("toolName", toolName));
					criteria.setProjection(Projections.countDistinct("requestMapping.requestId"));
					return criteria.uniqueResult();
				}
			});

			return count.intValue();
		} catch (Exception e) {
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);

		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<POCDetailsBean> getPOCRequests(String userName, String pocSubStatus, Long requestId, Integer limit,
			Integer start, String toolName, Integer month) {
		try {
			return (List<POCDetailsBean>) hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {

					ProjectionList projection = Projections.projectionList();				
					projection.add(Projections.property("requestID"), "requestId");
					projection.add(Projections.property("REQUEST_ID_UI"), "request_id_ui");					
					projection.add(Projections.property("requestStatus"), "status");
					projection.add(Projections.property("poc_status"), "poc_status");
					projection.add(Projections.property("poc_comments"), "poc_comments");
					projection.add(Projections.property("updatedDate"), "updatedDate");
					projection.add(Projections.property("assigned_poc_emailId"), "assigned_poc_emailId");	
					projection.add(Projections.property("assignedFaitEmailId"), "assignedFaitEmailId");
					projection.add(Projections.property("pocFiatStatus"), "poc_Fiat_Status");
					projection.add(Projections.property("journeyCategory"), "journey_Category");
					projection.add(Projections.property("pocSubStatus"), "poc_sub_status");
					projection.add(Projections.property("requestForm.RFP"), "RFP");
					projection.add(Projections.property("rfpStatus"), "rfpStatus");
					projection.add(Projections.property("requestForm.sia"), "sia");
					projection.add(Projections.property("requestForm.SOH"), "soh");
					projection.add(Projections.property("requestForm.s4Technical"), "s4");
					projection.add(Projections.property("requestForm.s4Functional"), "fiat");
					projection.add(Projections.property("requestForm.UI5"), "ui5");
					projection.add(Projections.property("requestForm.fiori"), "fiori");
					projection.add(Projections.property("requestForm.UPGRADE"), "upgrd");
					projection.add(Projections.property("requestForm.osMig"), "osMig");
					projection.add(Projections.property("requestForm.bwUsage"), "bwUsage");
					projection.add(Projections.property("requestForm.bwTech"), "bwTech");
					projection.add(Projections.property("requestForm.grc"), "grc");
					projection.add(Projections.property("requestForm.EXT"), "EXT");
					final Criteria criteria = session.createCriteria(RequestInventory.class, "requestInventory");
					criteria.createAlias("requestInventory.requestForm", "requestForm");
					Disjunction or = Restrictions.disjunction();
					or.add(Restrictions.eq("assigned_poc_emailId", userName));
					or.add(Restrictions.eq("assignedFaitEmailId", userName));
					criteria.add(or);
					
					if (limit != null) {
						criteria.setMaxResults(limit);
					}
					
					if (start != null) {
						criteria.setFirstResult(start);
					}
					
					if(requestId != null) {
						criteria.add(Restrictions.eq("requestID", requestId));
					}
					
					if(pocSubStatus != null) {
						criteria.add(Restrictions.eq("pocSubStatus", pocSubStatus));
					}
					
					if(month != null) {
						Calendar cal = Calendar.getInstance();
				        cal.add(Calendar.MONTH, -(month));
				        Date newDate = cal.getTime();
				        Date currDate = new Date();
				        
				        criteria.add(Restrictions.le("updatedDate", currDate.getTime()));
				        criteria.add(Restrictions.gt("updatedDate", newDate.getTime()));
				        
					}
					
					criteria.setProjection(projection);
					criteria.addOrder(Order.desc("updatedDate"));
					
					criteria.setResultTransformer(Transformers.aliasToBean(POCDetailsBean.class));
					return criteria.list();
				}
			});
		} catch (Exception e) {
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);

		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public Integer getTotalPOCRequests(final String userName, final String pocSubStatus, final Long requestId, final String toolName, final Integer month) {
		try {
			Long count = (Long) hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {

					final Criteria criteria = session.createCriteria(RequestInventory.class);
					Disjunction or = Restrictions.disjunction();
					or.add(Restrictions.eq("assigned_poc_emailId", userName));
					or.add(Restrictions.eq("assignedFaitEmailId", userName));
					criteria.add(or);
					
					if(requestId != null) {
						criteria.add(Restrictions.eq("requestID", requestId));
					}
					
					if(pocSubStatus != null) {
						criteria.add(Restrictions.eq("pocSubStatus", pocSubStatus));
					}
					
					if(month != null) {
						Calendar cal = Calendar.getInstance();
				        cal.add(Calendar.MONTH, -(month));
				        Date newDate = cal.getTime();
				        Date currDate = new Date();
				        
				        criteria.add(Restrictions.le("updatedDate", currDate.getTime()));
				        criteria.add(Restrictions.gt("updatedDate", newDate.getTime()));
				        
					}
					
					criteria.setProjection(Projections.countDistinct("requestID"));
					return criteria.uniqueResult();
				}
			});

			return count.intValue();
		} catch (Exception e) {
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);

		}
	}

}
