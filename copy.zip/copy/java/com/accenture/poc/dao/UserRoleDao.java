package com.accenture.poc.dao;

import com.accenture.poc.model.UserRole;
import java.util.*;

public interface UserRoleDao {

	public UserRole updateUserRole(String userName,String userRole);
	public List<UserRole> getUserRoles(String userName);
	
	public UserRole getUserRoleData(String userName);
}
