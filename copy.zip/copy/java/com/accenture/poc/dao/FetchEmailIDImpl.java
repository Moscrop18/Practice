package com.accenture.poc.dao;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.stereotype.Component;

import com.accenture.constant.Hana_Profiler_Constant;
import com.accenture.exceptions.HibernateException;
import com.accenture.poc.dao.factory.AbstractHibernateDao;
import com.accenture.poc.model.User;

@Component(value = "changePasswordDao")
@SuppressWarnings({ "unchecked", "rawtypes" })
public class FetchEmailIDImpl extends AbstractHibernateDao implements FetchEmailID {
	@Override
	public String getEmail(final String userName) {		
		try {
			return (String) getHibernateTemplate().execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {
					Criteria criteria = session.createCriteria(User.class);
					//Changed to match email for SSO -- Guna
					criteria.add(Restrictions.eq("emailId", userName));
					criteria.setProjection(Projections.property("emailId"));
					return criteria.uniqueResult();
				}
			});
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
}
