package com.accenture.poc.dao;


import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.stereotype.Component;

import com.accenture.constant.Hana_Profiler_Constant;
import com.accenture.exceptions.HibernateException;
import com.accenture.poc.dao.factory.AbstractHibernateDao;
import com.accenture.poc.model.User;

@Component(value = "pocLoginDao")
public class POCLoginDaoImpl extends AbstractHibernateDao implements POCLoginDao{

	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public User getUser(final String userName) {
		try{
		return (User)getHibernateTemplate().execute(new HibernateCallback()
	    {
	        public Object doInHibernate(Session session) throws HibernateException
	        {
	            final Criteria criteria = session.createCriteria(User.class);
	            criteria.add(Restrictions.eq("userName", userName));
	            criteria.add(Restrictions.eq("enabled", true));
	            return criteria.uniqueResult();
	        }});
		}catch(Exception e)
		{
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public void assignRequest(final String userName,final  List<Long> requestIdList) {
		try{
		getHibernateTemplate().execute(new HibernateCallback()
	    {
	        public Object doInHibernate(Session session) throws HibernateException
	        {
	            Query query = session.createQuery("update POCRequestMapping set userName = :userName where requestId in (:requestId)");
	            query.setParameter("userName", userName);
	            query.setParameterList("requestId", requestIdList);
	            return query.executeUpdate();
	        }});
		}catch(Exception e)
		{
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	
}
