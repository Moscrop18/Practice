package com.accenture.poc.dao;

import java.util.List;

import com.accenture.model.Skype;

public interface SkypeDao {
	public List<Skype> getActiveIds();
}
