package com.accenture.poc.dao;

import com.accenture.poc.model.User;
import java.util.*;

public interface UserDAO {

	public void save(User user,String role);
	public void saveUserData(User user,String role);
	public User getUser(String userName);
	public boolean deleteUser(String userName);
	public List<String> getUserNameList();
	//CR17: Added method for fetching all user list.
	public List<User> getUserList();
}
