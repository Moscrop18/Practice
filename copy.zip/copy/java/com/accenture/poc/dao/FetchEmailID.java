package com.accenture.poc.dao;

public interface FetchEmailID {
	public String getEmail(final String userName);
}
