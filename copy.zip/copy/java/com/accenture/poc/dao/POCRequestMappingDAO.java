package com.accenture.poc.dao;

import java.util.List;

import com.accenture.client.model.RequestFormDetailsBean;
import com.accenture.model.StatusMaster;
import com.accenture.poc.model.POCDetailsBean;

public interface POCRequestMappingDAO {

	public void addUser(String userName, Long requestID);

	public String resetStatus(String userName);

	public List<StatusMaster> getStatusList();

	List<RequestFormDetailsBean> getClientRequests(final String userName, final String status, final Long requestId,
			final Integer limit, final Integer start, final String toolName);

	void addClientData(long requestID, String clientName, String requestIdUI, String toolName);

	boolean checkRequestId(Long requestId, String userName, boolean isClient);

	Integer getTotalClientRequests(final String userName, final String status, final Long requestId, final String toolName);

	List<RequestFormDetailsBean> getRequests(String userName, String status, Long requestId, Integer limit,
			Integer start, final String toolName);

	Integer getTotalUserRequests(String userName, String status, Long requestId, final String toolName);
	
	public List<POCDetailsBean> getPOCRequests(String userName, String pocSubStatus, Long requestId, Integer limit,
			Integer start, String toolName, Integer month);

	public Integer getTotalPOCRequests(String userName, String pocSubStatus, Long requestId, String toolName,
			Integer month);
}
