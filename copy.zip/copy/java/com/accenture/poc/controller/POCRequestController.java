package com.accenture.poc.controller;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.accenture.FinalFile.controller.FinalFileUpload;
import com.accenture.S4.Controller.S4ProcessingController;
import com.accenture.client.controller.RequestFormInputController;
import com.accenture.client.model.RequestForm;
import com.accenture.client.model.RequestFormFile;
import com.accenture.client.model.RequestFormModel;
import com.accenture.client.model.RequestInventory;
import com.accenture.constant.File_Size_Constant;
import com.accenture.constant.Hana_Profiler_Constant;
import com.accenture.exceptions.ReqIDNotValidException;
import com.accenture.exceptions.TransportRequestException;
import com.accenture.exceptions.UploadFilesNotValidException;
import com.accenture.master.ProcessedEstimates;
import com.accenture.poc.model.POCDetailsBean;
import com.accenture.reader.xlsx.St03ReaderXlsx;
import com.accenture.rfp.models.TADIRInventory;
import com.accenture.service.RequestIDValidateService;
import com.accenture.statictables.model.ContentFile;
import com.accenture.statictables.model.DeletionTransportRequest;
import com.accenture.statictables.model.DeletionTransportRequestFile;
import com.accenture.statictables.model.TransportRequest;
import com.accenture.statictables.model.TransportRequestFile;
import com.accenture.utility.FileUtility;
import com.accenture.utility.HANAUtility;
import com.accenture.utility.SendEmail;
import com.accenture.validator.RequestID_Validator_Utility;
import com.monitorjbl.xlsx.StreamingReader;

import net.minidev.json.JSONArray;

@Controller
@SessionAttributes("User")
public class POCRequestController extends S4ProcessingController {

	S4ProcessingController S4ProcessingControllerObj = new S4ProcessingController();
	RequestFormInputController RequestFormInputController;
	St03ReaderXlsx st03ReaderXlsx;

	@Autowired
	private FinalFileUpload finalFileUpload;

	@Autowired
	private RequestIDValidateService reqIDValid;

	@RequestMapping(value = "poc/pocDashBoard", method = RequestMethod.GET)
	public String goToPOCDashboard(Model model, final String pocSubStatus, final Integer dateFilter,
			final String requestIdUi, HttpServletRequest request, HttpSession session) throws Exception {
		String userName = getPrincipal();
		Long requestId = null;

		if (requestIdUi != null) {

			if (requestIdUi.length() != 14) {
				model.addAttribute("IdError", "Please enter a valid Request ID.");
			} else {
				requestId = getRequestDetails().getRequestID(requestIdUi);
			}
		}
		String status = null;// use pocComment instead of status while updating the code

		String toolName = (String) session.getAttribute("tool");
		Integer limit = 10;// Configure this as per requirement.
		// final List<StatusMaster> statusList = getDashBoard().getStatusList();
		final List<POCDetailsBean> pocRequestDetailsList = getDashBoard().getPOCRequests(userName, pocSubStatus,
				requestId, limit, null, toolName, dateFilter);

		// model.addAttribute("statusList", statusList);
		model.addAttribute("pocSubStatus", pocSubStatus);
		model.addAttribute("requestIdUi", requestIdUi);
		model.addAttribute("dateFilter", dateFilter);
		model.addAttribute("requestId", requestId);
		model.addAttribute("UserName", userName);
		model.addAttribute("numRecords", limit);
		model.addAttribute("pocSubStatusList", getPOC_SubStatus_List());
		model.addAttribute("monthList", getMonthList());

		if (CollectionUtils.isNotEmpty(pocRequestDetailsList)) {
			model.addAttribute("requestList", pocRequestDetailsList);
			model.addAttribute("totalRecords",
					getDashBoard().getTotalPOCRequests(userName, pocSubStatus, requestId, toolName, dateFilter));
		} else {
			model.addAttribute("requestListEmptyMessage", "No request is created");
		}
		return "poc/pocDashBoard";

	}

	@RequestMapping(value = "poc/pocDashBoardScroll", method = RequestMethod.GET)
	public void geTNextRequestSet(final String pocSubStatus, final Integer dateFilter, final String requestIdUi,
			final Integer sIdx, final Integer numRecords, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {
		PrintWriter out = response.getWriter();

		Long requestId = null;

		if (requestIdUi != null) {
			requestId = getRequestDetails().getRequestID(requestIdUi);
		}

		String status = null;

		try {
			String userName = getPrincipal();
			String toolName = (String) session.getAttribute("tool");
			JSONArray jAr = new JSONArray();
			Integer startIndex = sIdx - 1;
			Integer limit = numRecords;

			final List<POCDetailsBean> pocRequestDetailsList = getDashBoard().getPOCRequests(userName, pocSubStatus,
					requestId, limit, startIndex, toolName, dateFilter);

			for (POCDetailsBean POCBean : pocRequestDetailsList) {
				JSONObject joBj = new JSONObject();
				joBj.put("requestIdUi", POCBean.getRequest_id_ui());
				joBj.put("requestId", POCBean.getRequestId());
				joBj.put("updatedDate", POCBean.getUpdatedDate());
				joBj.put("status", POCBean.getStatus());
				joBj.put("poc_Status", POCBean.getPoc_status());
				joBj.put("comment_poc", POCBean.getPoc_comments());

				joBj.put("pocEmail", POCBean.getAssigned_poc_emailId());
				joBj.put("fiatEmail", POCBean.getAssignedFaitEmailId());
				joBj.put("poc_Fiat_Status", POCBean.getPoc_Fiat_Status());
				joBj.put("journeyCategory", POCBean.getJourney_Category());
				joBj.put("poc_sub_status", POCBean.getPoc_sub_status());
				joBj.put("rfpStatus", POCBean.getRfpStatus());
				joBj.put("otherScope", POCBean.getOtherScope());
				joBj.put("sia", POCBean.getSia());
				joBj.put("rfp", POCBean.getRFP());
				jAr.add(joBj);
			}

			/* Comment Below code after backend Integration */
			/* Hard-Code Section Begins */
			/*
			 * for (long x = sIdx; x < endIdx; x++) { JSONObject joBj = new JSONObject();
			 * joBj.put("requestIdUi", "ABC00FNUXsid" + x); joBj.put("requestId", x + "");
			 * joBj.put("updatedDate", "1556258724586");
			 * 
			 * if (x % 9 == 0) { joBj.put("status", "HanaRefiningCompleted");
			 * joBj.put("poc_Status", "Completed_POC"); joBj.put("poc_fiat_Status", "");
			 * joBj.put("comment_poc", "Completed"); joBj.put("sub_status", "Completed");
			 * joBj.put("pocEmail", "d.b.kumar.choudhary@accenture.com");
			 * joBj.put("fiatEmail", ""); joBj.put("journeyCategory", "S4_Only"); } else if
			 * (x % 8 == 0) { joBj.put("status", "HANARefiningSuccess");
			 * joBj.put("poc_Status", "Final_APPROVED_POC"); joBj.put("poc_fiat_Status",
			 * ""); joBj.put("comment_poc", "Pending-Estimation"); joBj.put("sub_status",
			 * "Final File Approved"); joBj.put("pocEmail",
			 * "d.b.kumar.choudhary@accenture.com"); joBj.put("fiatEmail", "");
			 * joBj.put("journeyCategory", "S4_Only"); } else if (x % 7 == 0) {
			 * joBj.put("status", "HANARefiningSuccess"); joBj.put("poc_Status",
			 * "Final_DOWN_DONE_POC"); joBj.put("poc_fiat_Status", "Initiated_POC");
			 * joBj.put("comment_poc", "In-Progress"); joBj.put("sub_status",
			 * "Processed file Download Successful"); joBj.put("pocEmail",
			 * "d.b.kumar.choudhary@accenture.com"); joBj.put("fiatEmail",
			 * "ruchika.b.jain"); joBj.put("journeyCategory", "SR_TwoPOC"); } else if (x % 6
			 * == 0) { joBj.put("status", "Approved"); joBj.put("poc_Status",
			 * "TR_DONE_UPLOAD_POC"); joBj.put("poc_fiat_Status", "FIAT_UPLOAD_DONE_POC");
			 * joBj.put("comment_poc", "In-Progress"); joBj.put("sub_status",
			 * "FIAT file Upload successful"); joBj.put("pocEmail",
			 * "d.b.kumar.choudhary@accenture.com"); joBj.put("fiatEmail",
			 * "d.b.kumar.choudhary@accenture.com"); joBj.put("journeyCategory",
			 * "SR_SinglePOC");
			 * 
			 * } else if (x % 5 == 0) { joBj.put("status", "Approved");
			 * joBj.put("poc_Status", "TR_DONE_UPLOAD_POC"); joBj.put("poc_fiat_Status",
			 * "FIAT_DOWN_DONE_POC"); joBj.put("comment_poc", "In-Progress");
			 * joBj.put("sub_status", "FIAT file Download successful"); joBj.put("pocEmail",
			 * ""); joBj.put("fiatEmail", "d.b.kumar.choudhary@accenture.com");
			 * joBj.put("journeyCategory", "FIAT_Only"); } else if (x % 4 == 0) {
			 * joBj.put("status", "Approved"); joBj.put("poc_Status", "TR_DONE_UPLOAD_POC");
			 * joBj.put("poc_fiat_Status", "Initiated_POC"); joBj.put("comment_poc",
			 * "In-Progress"); joBj.put("sub_status", "Mandatory File Upload Successful");
			 * joBj.put("pocEmail", ""); joBj.put("fiatEmail",
			 * "d.b.kumar.choudhary@accenture.com"); joBj.put("journeyCategory",
			 * "FIAT_Only"); } else if (x % 3 == 0) { joBj.put("status", "Approved");
			 * joBj.put("poc_Status", "TR_DONE_UPLOAD_POC"); joBj.put("poc_fiat_Status",
			 * ""); joBj.put("comment_poc", "In-Progress"); joBj.put("sub_status",
			 * "Mandatory File Upload Successful"); joBj.put("pocEmail",
			 * "d.b.kumar.choudhary@accenture.com"); joBj.put("fiatEmail", "");
			 * joBj.put("journeyCategory", "S4_Only"); } else if (x % 2 == 0) {
			 * joBj.put("status", "Initiated"); joBj.put("poc_Status", "Initiated_POC");
			 * joBj.put("poc_fiat_Status", "Initiated_POC"); joBj.put("comment_poc",
			 * "In-Progress"); joBj.put("sub_status", "Initiated"); joBj.put("pocEmail",
			 * ""); joBj.put("fiatEmail", "d.b.kumar.choudhary@accenture.com");
			 * joBj.put("journeyCategory", "FIAT_Only"); } else { joBj.put("status",
			 * "Initiated"); joBj.put("poc_Status", "Initiated_POC");
			 * joBj.put("poc_fiat_Status", ""); joBj.put("comment_poc", "New Assignment");
			 * joBj.put("sub_status", "Initiated"); joBj.put("pocEmail",
			 * "d.b.kumar.choudhary@accenture.com"); joBj.put("fiatEmail", "");
			 * joBj.put("journeyCategory", "S4_Only"); } jAr.add(joBj); }
			 */
			/* Hard-Code Section Ends */
			out.write(jAr.toJSONString());
		} catch (Exception ex) {
			logger.error(ex.getMessage());
		} finally {
			out.close();
		}

	}

	private List<String> getPOC_SubStatus_List() {
		List<String> req_s_list = new ArrayList<String>();
		req_s_list.add(Hana_Profiler_Constant.REQ_SS_INI);
		// req_s_list.add(Hana_Profiler_Constant.REQ_SS_REJ);
		req_s_list.add(Hana_Profiler_Constant.REQ_SS_MAN_FL_UL_SUCC);
		req_s_list.add(Hana_Profiler_Constant.REQ_SS_MAN_FL_UL_FAIL);
		req_s_list.add(Hana_Profiler_Constant.REQ_SS_FIAT_FL_DL_SUCC);
		req_s_list.add(Hana_Profiler_Constant.REQ_SS_FIAT_FL_UL_SUCC);
		req_s_list.add(Hana_Profiler_Constant.REQ_SS_PROCESSED_FL_DL_SUCC);
		req_s_list.add(Hana_Profiler_Constant.REQ_SS_FINAL_FL_APPROVED);
		req_s_list.add(Hana_Profiler_Constant.REQ_SS_FINAL_FL_UL_FAIL);
		req_s_list.add(Hana_Profiler_Constant.REQ_SS_Estimate_FL_DL_SUCC);
		req_s_list.add(Hana_Profiler_Constant.REQ_SS_COMPLETED);
		req_s_list.add(Hana_Profiler_Constant.REQ_SS_ROM_Estimate_FL_DL_SUCC);
		req_s_list.add(Hana_Profiler_Constant.REQ_SS_ROM_Estimate_FL_UL_SUCC);
		req_s_list.add(Hana_Profiler_Constant.REQ_SS_ROM_Estimate_FL_UL_FAIL);
		return req_s_list;
	}

	private List<Integer> getMonthList() {
		List<Integer> mList = new ArrayList<Integer>();
		mList.add(1);
		mList.add(3);
		mList.add(6);
		return mList;
	}

	@RequestMapping(value = "poc/pocUploadTR/{requestID}", method = RequestMethod.GET)
	public String pocUploadTR(@PathVariable("requestID") long requestID, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		boolean TrStatus = false;
		boolean DelTrStatus = false;
		boolean ContentStatus = false;

		String toolName = (String) session.getAttribute("tool");

		try {
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestID));
			RequestID_Validator_Utility.chckReqIdPOC(reqIDValid.getPOCName(reqIDValid.getRequestInv(requestID)),
					getPrincipal());

			model.addAttribute("requestID", requestID);
			model.addAttribute("trSize", File_Size_Constant.TR_SIZE);
			model.addAttribute("deltrSize", File_Size_Constant.DEL_TR_SIZE);
			model.addAttribute("crSize", File_Size_Constant.CR_SIZE);
			model.addAttribute("trMap", getTransportRequestDAO().getAllTransportRequestListPoc());
			model.addAttribute("deltrMap", getTransportRequestDAO().getAllDeletionTransportRequestListPoc());

			String trStatus = getTransportRequestDAO().getTrAttachedStatus(requestID);
			String delTrStatus = getTransportRequestDAO().getDelTrAttachedStatus(requestID);
			if (trStatus == null || trStatus.equalsIgnoreCase("Empty")) {
				TrStatus = false;
				model.addAttribute("TransportRequest", new TransportRequest());
			} else {
				TrStatus = true;
			}
			if (delTrStatus == null || delTrStatus.equalsIgnoreCase("Empty")) {
				DelTrStatus = false;
				model.addAttribute("DeletionTransportRequest", new DeletionTransportRequest());
			} else {
				DelTrStatus = true;
			}
		} catch (ReqIDNotValidException ex) {
			model.addAttribute("errorMsg", ex.getMessage());
			return "errors";
		} catch (Exception ex) {
			TrStatus = false;
			model.addAttribute("TransportRequest", new TransportRequest());
		}
		model.addAttribute("trUploadStatus", TrStatus);
		model.addAttribute("deltrUploadStatus", DelTrStatus);

		try {
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestID));
			RequestID_Validator_Utility.chckReqIdPOC(reqIDValid.getPOCName(reqIDValid.getRequestInv(requestID)),
					getPrincipal());

			String contentStatus = getTransportRequestDAO().getContentAttachedStatus(requestID);
			if (contentStatus == null || contentStatus.equalsIgnoreCase("Empty")) {
				ContentStatus = false;
				model.addAttribute("ContentFile", new ContentFile());
			} else {
				ContentStatus = true;
			}
		} catch (ReqIDNotValidException ex) {
			model.addAttribute("errorMsg", ex.getMessage());
			return "errors";
		} catch (Exception ex) {
			ContentStatus = false;
			model.addAttribute("ContentFile", new ContentFile());
		}
		model.addAttribute("contentUploadStatus", ContentStatus);

		if (TrStatus && ContentStatus) {
			final RequestForm requestForm = getRequestDetails().getRequestObj(requestID);
			final String systemStatus = getAutoHANA().getSystemStatus(requestID);
			if ((StringUtils.equals(systemStatus, Hana_Profiler_Constant.INITIATED_STATUS)
					|| StringUtils.equals(systemStatus, Hana_Profiler_Constant.PENDING_STATUS))
					&& "federal".equalsIgnoreCase(requestForm.getSupportedAtci())) {
				String POC_Status = "POCEstimatesDlDone";
				String POC_Comment = "Download of Estimates File Done";
				getRequestInventorydao().updatePOCSatus(requestID, Hana_Profiler_Constant.APPROVED_STATUS,
						getPrincipal(), POC_Status, toolName, Hana_Profiler_Constant.REQ_SS_MAN_FL_UL_SUCC,
						Hana_Profiler_Constant.UPLOAD_TR_CR_SUCC);
				sendEmailForCRTRUpload(requestID, request, session);
			} else if (StringUtils.equals(systemStatus, Hana_Profiler_Constant.INITIATED_STATUS)
					|| StringUtils.equals(systemStatus, Hana_Profiler_Constant.PENDING_STATUS)) {
				getRequestInventorydao().updatePOCSatus(requestID, Hana_Profiler_Constant.APPROVED_STATUS,
						getPrincipal(), Hana_Profiler_Constant.TR_UPLOAD_DONE_POC, toolName,
						Hana_Profiler_Constant.REQ_SS_MAN_FL_UL_SUCC, Hana_Profiler_Constant.UPLOAD_TR_CR_SUCC);
			}
			return "redirect:/poc/pocDashBoard";
		}
		return "poc/pocUploadTR";
	}

	@RequestMapping(value = "poc/pocUploadFI/{requestID}", method = RequestMethod.GET)
	public String pocUploadFI(@PathVariable("requestID") long requestID, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {
		model.addAttribute("requestID", requestID);
		model.addAttribute("fiatFISize", File_Size_Constant.FIAT_FI_SIZE);
		Boolean fiFlag = false;
		return "poc/pocUploadFI";
	}

	@RequestMapping(value = "poc/pocUploadFISubmit/{requestID}", method = RequestMethod.POST)
	public String pocUploadFI11(@PathVariable("requestID") long requestID, final RedirectAttributes redirectAttributes,
			Model model, HttpServletRequest request, HttpServletResponse response, HttpSession session,
			@RequestParam("fiFile") MultipartFile file) throws Exception {

		String fileName = "";
		String toolName = (String) session.getAttribute("tool");

		try {
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestID));
			RequestID_Validator_Utility.chckReqIdPOC(reqIDValid.getPOCName(reqIDValid.getRequestInv(requestID)),
					getPrincipal());

			model.addAttribute("requestID", requestID);
			RequestFormFile requestFormFile = getRequestFormFileData().getRequestFormFileObj(requestID);
			fileName = file.getOriginalFilename();
			FileUtility.chckUploadFilesAlphaNum(fileName);
			FileUtility.checkFileSizeByItem(file, "FIAT_FI");

			String extension = ".zip";

			if (!fileName.equals("")) {
				String fileExtension = fileName.substring(fileName.length() - extension.length(), fileName.length());

				if (fileExtension.equalsIgnoreCase(".zip")) {
					requestFormFile.setFinalFiatFile(file.getBytes());
				}
			}

			logger.info("Saving files in the DB for FAIT");
			getRequestFormFileData().UpdateRequestFormFile(requestFormFile);
			logger.info("Saved the File form in the DB");
		} catch (ReqIDNotValidException ex) {
			model.addAttribute("errorMsg", ex.getMessage());
			return "errors";
		} catch (UploadFilesNotValidException ex) {
			redirectAttributes.addFlashAttribute("errorMsg", "The filename is not correct.");
			return "redirect:/poc/pocUploadFI/" + requestID;
		} catch (Exception e) {
			model.addAttribute("requestID", requestID);
			model.addAttribute("Error", "File Upload Failed");
			return "poc/pocUploadFI";
		}

		getRequestFormFileData().updateRequestInventorySatus(requestID, "FIAT_UPLOAD_DONE_POC",
				Hana_Profiler_Constant.REQ_SS_FIAT_FL_UL_SUCC, Hana_Profiler_Constant.POC_FIAT_UPLOAD_SUCC);
		return "redirect:/poc/pocDashBoard";
	}

	@RequestMapping(value = "poc/pocUploadS4/{requestID}", method = RequestMethod.GET)
	public String pocUploadS4(@PathVariable("requestID") long requestID, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {

		String toolName = (String) session.getAttribute("tool");
		Boolean s4Flag = false;

		model.addAttribute("requestID", requestID);
		model.addAttribute("s4ReportSize", File_Size_Constant.FINAL_REPORT_SIZE);

		// Getting SIA Sub Request IDs List
		model.addAttribute("requestFormObj", getRequestDetails().getRequestFormScopes(requestID));
		model.addAttribute("siaReqIDList", getRequestInventorydao().getSubReqIdUI(requestID));

		return "poc/pocUploadS4";
	}

	@RequestMapping(value = "poc/pocUploadFE/{requestID}", method = RequestMethod.GET)
	public String pocUploadFE(@PathVariable("requestID") long requestID, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {

		String toolName = (String) session.getAttribute("tool");
		model.addAttribute("requestID", requestID);
		model.addAttribute("estimationSize", File_Size_Constant.ESTIMATE_SIZE);
		Boolean feFlag = false;

		/* flag updation code goes below */

		return "poc/pocUploadFE";
	}

	// FIAT FILE
	// DOWNLOAD::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

	@RequestMapping(value = "/poc/dashboardFiatFile/{requestID}", method = RequestMethod.GET)
	public String downloadFiatFileFile(Model model, @PathVariable("requestID") Long requestID) {

		boolean file1Status = getRequestFormFileData().getFiatFile1Status(requestID);
		boolean file2Status = getRequestFormFileData().getFiatFile2Status(requestID);
		if (file1Status && file2Status) {
			getRequestFormFileData().updateRequestInventorySatus(requestID, "FIAT_DOWN_DONE_POC",
					Hana_Profiler_Constant.REQ_SS_FIAT_FL_DL_SUCC, Hana_Profiler_Constant.POC_FIAT_UPLOAD_SUCC);
		}

		return "redirect:/poc/pocDashBoard";
	}

	@RequestMapping(value = "/poc/downloadFiatFile1/{requestID}", method = RequestMethod.GET)
	public String downloadFiatFile1(@PathVariable("requestID") Long requestID, Model model,
			HttpServletResponse response, final RedirectAttributes redirectAttributes, final HttpSession session)
			throws Exception {
		byte[] fileBytes = null;
		String filename = "";

		try {
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestID));
			RequestID_Validator_Utility.chckReqIdPOC(reqIDValid.getPOCName(reqIDValid.getRequestInv(requestID)),
					getPrincipal());

			List<RequestFormFile> fiatFileObject = getRequestFormFileData().getRequestFormFile(requestID);
			for (RequestFormFile list : fiatFileObject) {
				fileBytes = list.getFiatFile1();
				filename = list.getEwaFile1Name();
			}

			String message = getFileDownload().downloadFile(fileBytes, response, filename);
			if (message == null || message.isEmpty()) {
				getRequestFormFileData().updateFIATFile1Satus(requestID, true);
			}

			boolean file1Status = getRequestFormFileData().getFiatFile1Status(requestID);
			boolean file2Status = getRequestFormFileData().getFiatFile2Status(requestID);
			if (file1Status && file2Status) {
				String toolName = (String) session.getAttribute("tool");
				getRequestInventorydao().updatePOCFIATSatus(requestID, getPrincipal(), "FIAT_DOWN_DONE_POC", toolName,
						Hana_Profiler_Constant.REQ_SS_FIAT_FL_DL_SUCC, Hana_Profiler_Constant.POC_FIAT_DOWN_SUCC);
			}
		} catch (IOException e) {
			logger.trace(e.getMessage());
		} catch (ReqIDNotValidException ex) {
			model.addAttribute("errorMsg", ex.getMessage());
			return "errors";
		}

		return null;
	}

	@RequestMapping(value = "/poc/downloadFiatFile2/{requestID}", method = RequestMethod.GET)
	public String downloadFiatFile2(@PathVariable("requestID") Long requestID, Model model,
			HttpServletResponse response, final RedirectAttributes redirectAttributes, final HttpSession session)
			throws Exception {
		byte[] fileBytes = null;
		String filename = "";

		try {
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestID));
			RequestID_Validator_Utility.chckReqIdPOC(reqIDValid.getPOCName(reqIDValid.getRequestInv(requestID)),
					getPrincipal());

			List<RequestFormFile> fiatFileObject = getRequestFormFileData().getRequestFormFile(requestID);
			for (RequestFormFile list : fiatFileObject) {
				fileBytes = list.getFiatFile2();
				filename = list.getSizingReportFile2Name();
			}

			String message = getFileDownload().downloadFile(fileBytes, response, filename);
			if (message == null || message.isEmpty()) {
				getRequestFormFileData().updateFIATFile2Satus(requestID, true);
			}

			boolean file1Status = getRequestFormFileData().getFiatFile1Status(requestID);
			boolean file2Status = getRequestFormFileData().getFiatFile2Status(requestID);
			if (file1Status && file2Status) {
				String toolName = (String) session.getAttribute("tool");
				getRequestInventorydao().updatePOCFIATSatus(requestID, getPrincipal(), "FIAT_DOWN_DONE_POC", toolName,
						Hana_Profiler_Constant.REQ_SS_FIAT_FL_DL_SUCC, Hana_Profiler_Constant.POC_FIAT_DOWN_SUCC);
			}
		} catch (IOException e) {
			logger.trace(e.getMessage());
		} catch (ReqIDNotValidException ex) {
			model.addAttribute("errorMsg", ex.getMessage());
			return "errors";
		}

		return null;
	}

	@RequestMapping(value = "/poc/contentFileAdded/{requestID}", method = RequestMethod.POST)
	public String addedContentFile(@PathVariable("requestID") final long requestID,
			final RedirectAttributes redirectAttributes, Model model, HttpServletRequest request, HttpSession session,
			@RequestParam("contentFile") MultipartFile[] files) throws IOException {

		ContentFile ContentFile = null;
		try {
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestID));
			RequestID_Validator_Utility.chckReqIdPOC(reqIDValid.getPOCName(reqIDValid.getRequestInv(requestID)),
					getPrincipal());

			String crFileName = "";
			String extension = ".zip";
			boolean TrStatus = false;
			boolean DelTrStatus = false;

			try {
				String trStatus = getTransportRequestDAO().getTrAttachedStatus(requestID);
				if (trStatus != null && !trStatus.equalsIgnoreCase("Empty"))
					TrStatus = true;
			} catch (Exception ex) {
				TrStatus = false;
			}
			try {
				String deltrStatus = getTransportRequestDAO().getDelTrAttachedStatus(requestID);
				if (deltrStatus != null && !deltrStatus.equalsIgnoreCase("Empty"))
					DelTrStatus = true;
			} catch (Exception ex) {
				DelTrStatus = false;
			}

			model.addAttribute("trUploadStatus", TrStatus);
			model.addAttribute("trMap", getTransportRequestDAO().getAllTransportRequestListPoc());
			model.addAttribute("deltrUploadStatus", DelTrStatus);
			model.addAttribute("deltrMap", getTransportRequestDAO().getAllDeletionTransportRequestListPoc());

			String toolName = (String) session.getAttribute("tool");

			for (MultipartFile file : files) {
				try {
					crFileName = file.getOriginalFilename();
					FileUtility.detectZipFileType(file);
					FileUtility.chckUploadFilesAlphaNum(crFileName);
					FileUtility.checkFileSizeByItem(file, "CR");
					if (!crFileName.equals("")) {
						String fileExtension = crFileName.substring(crFileName.length() - extension.length(),
								crFileName.length());
						if (fileExtension.equalsIgnoreCase(".zip")) {
							ContentFile = getTransportRequestService().getContentData(requestID);
							if(null == ContentFile){
								ContentFile = new ContentFile();
							}
							ContentFile.setContentFile(file.getBytes());
							ContentFile.setContentFileName(file.getOriginalFilename());
							ContentFile.setREQUEST_ID(requestID);
							getTransportRequestService().saveContentData(ContentFile);
							model.addAttribute("MessageSuccess", "Content File Added Succesfully");
							model.addAttribute("contentUploadStatus", true);
							if (TrStatus && DelTrStatus) {
								final RequestForm requestForm = getRequestDetails().getRequestObj(requestID);
								final String systemStatus = getAutoHANA().getSystemStatus(requestID);
								if ((StringUtils.equals(systemStatus, Hana_Profiler_Constant.INITIATED_STATUS)
										|| StringUtils.equals(systemStatus, Hana_Profiler_Constant.PENDING_STATUS))
										&& "federal".equalsIgnoreCase(requestForm.getSupportedAtci())) {
									String POC_Status = "POCEstimatesDlDone";
									String POC_Comment = "Download of Estimates File Done";
									getRequestInventorydao().updatePOCSatus(requestID,
											Hana_Profiler_Constant.APPROVED_STATUS, getPrincipal(), POC_Status,
											toolName, Hana_Profiler_Constant.REQ_SS_MAN_FL_UL_SUCC,
											Hana_Profiler_Constant.UPLOAD_TR_CR_SUCC);
									sendEmailForCRTRUpload(requestID, request, session);
								} else if (StringUtils.equals(systemStatus, Hana_Profiler_Constant.INITIATED_STATUS)
										|| StringUtils.equals(systemStatus, Hana_Profiler_Constant.PENDING_STATUS)) {
									getRequestInventorydao().updatePOCSatus(requestID,
											Hana_Profiler_Constant.APPROVED_STATUS, getPrincipal(),
											Hana_Profiler_Constant.TR_UPLOAD_DONE_POC, toolName,
											Hana_Profiler_Constant.REQ_SS_MAN_FL_UL_SUCC,
											Hana_Profiler_Constant.UPLOAD_TR_CR_SUCC);
									sendEmailForCRTRUpload(requestID, request, session);
								}
								return "redirect:/poc/pocDashBoard";
							} else {
								final String systemStatus = getAutoHANA().getSystemStatus(requestID);
								if (StringUtils.equals(systemStatus, Hana_Profiler_Constant.INITIATED_STATUS)
										|| StringUtils.equals(systemStatus, Hana_Profiler_Constant.PENDING_STATUS)) {
									getRequestInventorydao().updatePOCSatus(requestID,
											Hana_Profiler_Constant.PENDING_STATUS, getPrincipal(), "Pending_POC",
											toolName, Hana_Profiler_Constant.REQ_SS_MAN_FL_UL_FAIL,
											Hana_Profiler_Constant.UPLOAD_TR_CR_FAIL);
								}
								return "poc/pocUploadTR";
							}
						} else {
							model.addAttribute("MessageFail", "Content File upload failed  .zip format required.");
							model.addAttribute("ContentFile", new ContentFile());
							model.addAttribute("requestID", requestID);
							model.addAttribute("contentUploadStatus", false);
							return "poc/pocUploadTR";
						}
					}
				} catch (UploadFilesNotValidException ex) {
					redirectAttributes.addFlashAttribute("errorMsg", "The filename is not correct.");
					return "redirect:/poc/pocUploadTR/" + requestID;
				} catch (Exception ex) {
					logger.error("Error !!! " + ex);
				}
			}

//			File contentFile = new File("");
//			DiskFileItemFactory factory = new DiskFileItemFactory();
//			factory.setSizeThreshold(0);
//			ServletFileUpload upload = new ServletFileUpload(factory);
//			upload.setFileSizeMax(-1);
//			upload.setSizeMax(-1);
//			String toolName = (String) session.getAttribute("tool");
//			List<FileItem> multipart = new ServletFileUpload(factory).parseRequest(request);			
//			for (FileItem item : multipart) {
//				if (!item.isFormField()) {
//					try {
//						contentFile = new File(item.getName());
//						FileUtility.detectZipFileType(item);
//						FileUtility.checkFileSizeByItem(item,"CR");
//						fileName = contentFile.getName();
//						if (!fileName.equals("")) {
//							String fileExtension = fileName.substring(fileName.length() - extension.length(),
//									fileName.length());
//							if (fileExtension.equalsIgnoreCase(".zip")) {
//								ContentFile.setContentFile(item.get());
//								ContentFile.setContentFileName(item.getName());
//								ContentFile.setREQUEST_ID(requestID);
//								getTransportRequestService().saveContentData(ContentFile);
//								model.addAttribute("MessageSuccess", "Content File Added Succesfully");
//								model.addAttribute("contentUploadStatus", true);
//								if (TrStatus) {
//									final String systemStatus = getAutoHANA().getSystemStatus(requestID);
//									if (StringUtils.equals(systemStatus, Hana_Profiler_Constant.INITIATED_STATUS)
//											|| StringUtils.equals(systemStatus,
//													Hana_Profiler_Constant.PENDING_STATUS)) {
//										getRequestInventorydao().updatePOCSatus(requestID,
//												Hana_Profiler_Constant.APPROVED_STATUS, getPrincipal(), "TR_DONE_UPLOAD_POC", 
//												toolName, Hana_Profiler_Constant.REQ_SS_MAN_FL_UL_SUCC, Hana_Profiler_Constant.UPLOAD_TR_CR_SUCC);
//
//										sendEmailForCRTRUpload(requestID, request, session);
//									}
//									return "redirect:/poc/pocDashBoard";
//								} else {
//									final String systemStatus = getAutoHANA().getSystemStatus(requestID);
//									if (StringUtils.equals(systemStatus, Hana_Profiler_Constant.INITIATED_STATUS)
//											|| StringUtils.equals(systemStatus,
//													Hana_Profiler_Constant.PENDING_STATUS)) {
//										getRequestInventorydao().updatePOCSatus(requestID,
//												Hana_Profiler_Constant.PENDING_STATUS, getPrincipal(), "Pending_POC",
//												toolName, Hana_Profiler_Constant.REQ_SS_MAN_FL_UL_FAIL, Hana_Profiler_Constant.UPLOAD_TR_CR_FAIL);
//									}
//									return "poc/pocUploadTR";
//								}
//							} else {
//								model.addAttribute("MessageFail", "Content File upload failed  .zip format required.");
//								model.addAttribute("ContentFile", new ContentFile());
//								model.addAttribute("requestID", requestID);
//								model.addAttribute("contentUploadStatus", false);
//								return "poc/pocUploadTR";
//							}
//						}
//					} catch (Exception ex) {
//						logger.error("Error !!! " + ex);
//					}
//				}
//			}
		} catch (TransportRequestException exception) {
			logger.error("Inside TransportRequestException");
			redirectAttributes.addFlashAttribute("MessageFail", "Content File Already Exists");
		} catch (ReqIDNotValidException ex) {
			model.addAttribute("errorMsg", ex.getMessage());
			return "errors";
		} catch (Exception exception) {
			logger.error("Inside exception " + exception);
			redirectAttributes.addFlashAttribute("MessageFail", exception.getMessage());
		} finally {
			model.addAttribute("trSize", File_Size_Constant.TR_SIZE);
			model.addAttribute("deltrSize", File_Size_Constant.DEL_TR_SIZE);
			model.addAttribute("crSize", File_Size_Constant.CR_SIZE);
		}
		model.addAttribute("requestID", requestID);
		return "poc/pocUploadTR";
	}

	@RequestMapping(value = "/poc/contentFileAddedAdmin/{requestID}", method = RequestMethod.POST)
	public String addedContentFileAdmin(@PathVariable("requestID") final long requestID,
			final RedirectAttributes redirectAttributes, Model model, HttpServletRequest request, HttpSession session)
			throws IOException {
		ContentFile ContentFile = new ContentFile();

		try {
			String fileName = "";
			String extension = ".zip";
			File trFile = new File("");
			DiskFileItemFactory factory = new DiskFileItemFactory();
			factory.setSizeThreshold(0);
			ServletFileUpload upload = new ServletFileUpload(factory);
			upload.setFileSizeMax(-1);
			upload.setSizeMax(-1);
			String toolName = (String) session.getAttribute("tool");
			List<FileItem> multipart = new ServletFileUpload(factory).parseRequest(request);
			int latestTRIdValue = getTransportRequestService().checkMaxVersionCount();
			TransportRequestFile transportRequest = getTransportRequestDAO().getTransportRequestLatest(latestTRIdValue);

			for (FileItem item : multipart) {

				if (!item.isFormField()) {
					try {
						trFile = new File(item.getName());
						fileName = trFile.getName();
						if (!fileName.equals("")) {
							String fileExtension = fileName.substring(fileName.length() - extension.length(),
									fileName.length());
							if (fileExtension.equalsIgnoreCase(".zip")) {
								ContentFile.setContentFile(item.get());
								ContentFile.setContentFileName(item.getName());
								ContentFile.setREQUEST_ID(requestID);
								getTransportRequestService().saveContentData(ContentFile);
								model.addAttribute("Message", "Content File Added Succesfully");

								/* adding Request Inventory data and approving the request */

								final String systemStatus = getAutoHANA().getSystemStatus(requestID);
								if (StringUtils.equals(systemStatus, Hana_Profiler_Constant.PENDING_STATUS)) {
									getRequestInventorydao().updateSatus(requestID, "Approved", getPrincipal(),
											"Approved", toolName);
									getRequestInventorydao().addRequestApprovedTRFileName(requestID,
											transportRequest.getTrVersion());
								}
								return "redirect:/poc/dashBoard";
							} else {
								model.addAttribute("Message", "Content File upload failed  .zip format required.");
								model.addAttribute("TransportRequest", transportRequest);
								model.addAttribute("RequestID", requestID);
								return "poc/contentfileUpload";
							}
						}
					} catch (Exception ex) {
						logger.error("Error !!! " + ex);
					}
				}
			}
		}

		catch (final FileUploadException exception) {
			logger.error("Inside FileUploadException");
			redirectAttributes.addFlashAttribute("fileException", exception.getMessage());

		}

		catch (TransportRequestException exception) {

			logger.error("Inside TransportRequestException");
			redirectAttributes.addFlashAttribute("fileException", "Content File Already Exists");

		} catch (Exception exception) {
			logger.error("Inside exception " + exception);
			redirectAttributes.addFlashAttribute("fileException", exception.getMessage());

		}

		return "redirect:/admin/addnewTransportRequest";

	}

	@RequestMapping(value = "/poc/migrationFilesProcessing/{requestID}", method = RequestMethod.POST)
	public String migrationFilesProcessing(@PathVariable("requestID") long requestID, HttpServletRequest request,
			HttpSession session, RedirectAttributes redirectAttributes, Model model,
			@RequestParam(required = false) MultipartFile file, @RequestParam(required = false) MultipartFile siaFile,
			@RequestParam(required = false) List<String> siaReqIDsList) throws Exception {
		logger.info("Processing POC Migration function migrationFilesProcessing().");

		String pocStatus = "", pocComment = "";
		String toolName = (String) session.getAttribute("tool");

		try {
			// Validating the POC
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestID));
			//RequestID_Validator_Utility.chckReqIdPOC(reqIDValid.getPOCName(reqIDValid.getRequestInv(requestID)),
					//getPrincipal());

			RequestForm requestFormObj = getRequestDetails().getRequestObj(requestID);

			pocStatus = "Final_APPROVED_POC";
			pocComment = "Pending-Estimation";

			// Validating the Final File Report
			if ((requestFormObj.getSOH() || requestFormObj.getS4Technical() || requestFormObj.getOsMig()
					|| requestFormObj.getUPGRADE() || requestFormObj.getFiori() || requestFormObj.getUI5()
					|| requestFormObj.getBwTech()) && file.isEmpty())
				throw new UploadFilesNotValidException("File not uploaded. Please upload the valid file.");

			// Validating the Security Final File Report
			if (requestFormObj.getSia() && CollectionUtils.isEmpty(siaReqIDsList) && siaFile.isEmpty())
				throw new UploadFilesNotValidException(
						"'Please upload the Security Final Report.' OR 'Select atleast one Sub Request ID for Security.'");

			// Creating map of files
			Map<String, String> fileMap = new LinkedHashMap<>();

			// Clearing the directory
			String directoryPath = HANAUtility.getFinalFilePath(requestFormObj.getClientName(), requestID);
			File directory = new File(directoryPath);
			if (directory.exists())
				FileUtils.cleanDirectory(directory);

			// Writing final file report
			if (file != null && !file.isEmpty()) {
				writeFile(requestID, file, directoryPath);
				if(StringUtils.isNotBlank(file.getOriginalFilename())){
					fileMap.put("HANAS4File", file.getOriginalFilename());
				}else{
					fileMap.put("HANAS4File", file.getName());
				}
			}

			// Writing security final file report
			if (siaFile != null && !siaFile.isEmpty()) {
				writeFile(requestID, siaFile, directoryPath);
				if(StringUtils.isNotBlank(siaFile.getOriginalFilename())){
					fileMap.put("SIAFile", siaFile.getOriginalFilename());
				}else{
					fileMap.put("SIAFile", siaFile.getName());
				}
				
			}

			// Reading final file report
			inputFileMigrationRead(session, requestID, fileMap, siaReqIDsList);

			// Updating POC success status
			getRequestInventorydao().updateSatusPOC(requestID, getPrincipal(), toolName, pocStatus, pocComment,
					Hana_Profiler_Constant.REQ_SS_FINAL_FL_APPROVED, Hana_Profiler_Constant.POC_UPLOAD_SUMM_SUCC);

			// Updating request status
			getRequestInventorydao().updateSatus(requestID, Hana_Profiler_Constant.HANAREFININGSUCCESS_STATUS,
					getPrincipal(), Hana_Profiler_Constant.HANAREFININGSUCCESS_STATUS_COMMENT, toolName);

			// Sending E-Mail when processing is successful
			try {
				sendEmailForMigration(requestID, request, "Validation of the Detailed Report Successful", session);
			} catch (Exception e) {
				logger.error("Error while sending Email : ", e);
			}
		} catch (ReqIDNotValidException ex) {
			model.addAttribute("errorMsg", ex.getMessage());
			return "errors";
		} catch (UploadFilesNotValidException e) {
			redirectAttributes.addFlashAttribute("errorMsg", e.getMessage());
			return "redirect:/poc/pocUploadS4/" + requestID;
		} catch (Exception e) {
			pocStatus = "Final_UPLOAD_FAILED_POC";
			pocComment = "In-Progress";

			logger.error("Error while processing Final File Report (POC End) : ", e);

			// Updating POC failure status
			getRequestInventorydao().updateSatusPOC(requestID, getPrincipal(), toolName, pocStatus, pocComment,
					Hana_Profiler_Constant.REQ_SS_FINAL_FL_UL_FAIL, Hana_Profiler_Constant.POC_UPLOAD_SUMM_FAIL);

			// Sending E-Mail when exception occurs
			try {
				sendEmailForMigration(requestID, request, "Failure of validation of the Detailed Report", session);
			} catch (Exception ex) {
				logger.error("Error while sending Email : ", ex);
			}
		}

		return "redirect:/poc/pocDashBoard";
	}

	// Writing Final File Report
	private void writeFile(long requestId, MultipartFile file, String directoryPath) throws Exception {
		String comments = ""; String finalReportName = "";
				/*if(StringUtils.isNotBlank(file.getName()) || StringUtils.isNotBlank(file.getOriginalFilename())){
					finalReportName = file.getName();
				}else{
					finalReportName = file.getOriginalFilename();
				}*/
				finalReportName = file.getOriginalFilename();
				String fileExtension = FilenameUtils.getExtension(finalReportName);

		try {
			// Validating file name
			FileUtility.chckUploadFilesAlphaNum(finalReportName);

			// Validating the extension of final report
			if (Hana_Profiler_Constant.XLSX_EXTENSTION_CONSTANT.substring(1).equalsIgnoreCase(fileExtension)) {
				comments = "Matched Extension - Final Report.";

				logger.info(comments);
			} else {
				comments = "Extension of file : Final Report does not match. "
						+ "Please upload the file with .xlsx extension only.";

				throw new UploadFilesNotValidException(comments);
			}

			// Writing file at the server location
			Path path = Paths.get(directoryPath + File.separator + finalReportName);
			byte[] bytes = file.getBytes();
			Files.write(path, bytes);

			logger.info("Final Report File - Wrote in file path");
		} catch (UploadFilesNotValidException e) {
			logger.error("Uploaded Final File Report is not correct : ", e.getMessage());
			throw new UploadFilesNotValidException(e.getMessage());
		} catch (Exception e) {
			logger.error("Processing of file failed : ", e);
			throw new Exception();
		}
	}

	@RequestMapping(value = "/poc/uploadReportFileApprove/{requestID}", method = RequestMethod.GET)
	public String migrationFilesProcessingApprove(@PathVariable("requestID") Long requestID,
			final HttpServletRequest request, HttpSession session, Model model) throws Exception {
		String status, comments, subStatus, POCStatus, POCComment;
		String toolName = (String) session.getAttribute("tool");

		try {
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestID));
			RequestID_Validator_Utility.chckReqIdPOC(reqIDValid.getPOCName(reqIDValid.getRequestInv(requestID)),
					getPrincipal());

			final RequestForm requestForm = getRequestDetails().getRequestObj(requestID);

			logger.info("Going to send mail::: ");

			POCStatus = "Final_APPROVED_POC";
			POCComment = "Pending-Estimation";

			logger.info(
					"::::::::::::::::::::Approving POC Migration function migrationFilesProcessingApprove()::::::::::::::::");

			pocEstimationsProcessing(requestID, requestForm, session); // Calculating Estimates - POC
			getRequestInventorydao().updateSatusPOC(requestID, getPrincipal(), toolName, POCStatus, POCComment,
					Hana_Profiler_Constant.REQ_SS_FINAL_FL_APPROVED, Hana_Profiler_Constant.POC_UPLOAD_SUMM_SUCC);
			try {
				sendEmailForMigration(requestID, request, "Validation of the Detailed Report Successful", session);
			} catch (Exception ex) {
				logger.error("Error while sending Email");
			}

		} catch (ReqIDNotValidException ex) {
			model.addAttribute("errorMsg", ex.getMessage());
			return "errors";
		} catch (Exception e) {
			logger.info("Inside catch upload Report File Approve ");
			status = Hana_Profiler_Constant.HANAREFININGSUCCESS_STATUS;
			comments = Hana_Profiler_Constant.HANAREFININGSUCCESS_STATUS_COMMENT;
			POCStatus = "Final_UPLOAD_FAILED_POC";
			POCComment = "In-Progress";
			comments = Hana_Profiler_Constant.ST03FAILED_STATUS_EXCEPTION_COMMENT;
			getRequestInventorydao().updateSatusPOC(requestID, getPrincipal(), toolName, POCStatus, POCComment,
					Hana_Profiler_Constant.REQ_SS_FINAL_FL_UL_FAIL, Hana_Profiler_Constant.POC_UPLOAD_SUMM_FAIL);
			try {
				sendEmailForMigration(requestID, request, "Failure of validation of the Detailed Report", session);
			} catch (Exception ex) {
				logger.error("Error while sending Email");
			}

			// have to add the return Type to POC dashboard -- will be done while merging
			// code with UI

		}
		return "redirect:/poc/pocDashBoard";
		// have to add the return Type to POC dashboard -- will be done while merding
		// code with UI

	}

	protected void sendEmailForMigration(long requestId, HttpServletRequest request, String successOrFailure,
			HttpSession session) {

		String emailContext = "https://" + request.getServerName() + ":" + request.getServerPort();

		final RequestInventory requestInventory = getClientRequestInventoryDAO().getRequestInventory(requestId);

		String requestUID = requestInventory.getREQUEST_ID_UI();
		String emailId = requestInventory.getCreatorUser();

		Set<String> emailData = new HashSet<String>();
		Set<String> emailCc = new HashSet<String>();
		SendEmail email = new SendEmail();
		email.setMailFrom("IDC_SAPUpgrade_Sales@accenture.com");
		emailCc.add("IDC_SAPUpgrade_Sales@accenture.com");

		if (successOrFailure.equals("Validation of the Detailed Report Successful")) {
			emailData.add(emailId);
			emailCc.add(getEmailIDDao().getEmail(getPrincipal()));
			email.setMailSubject("Request ID : " + requestUID + successOrFailure);
			email.setMailBody("\n\nDear " + emailId + ",\n\nYour detailed report has been verified/processed by"
					+ " POC. Please download the report again." + "\n\n\nRegards,\nHana Technical Team");
		} else {
			emailData.add(getEmailIDDao().getEmail(getPrincipal()));
			email.setMailSubject("Request ID : " + requestUID + successOrFailure);
			email.setMailBody("\n\n Dear " + getPrincipal() + ",\n\nThe verification/processing of the detailed report"
					+ " has failed. Please check the file data." + "\n\n\nRegards,\nHana Technical Team");
		}

		email.setMailTo(emailData);
		email.setMailCC(emailCc);

		email.emailSend(email, request, session);

	}

	protected void sendEmailForCRTRUpload(long requestId, HttpServletRequest request, HttpSession session) {

		String emailContext = "https://" + request.getServerName() + ":" + request.getServerPort();
		Set<String> emailData = new HashSet<String>();
		Set<String> emailCc = new HashSet<String>();
		SendEmail email = new SendEmail();
		email.setMailFrom("IDC_SAPUpgrade_Sales@accenture.com");

		final RequestInventory requestInventoryObj = getClientRequestInventoryDAO()
				.saveRequestInventoryDataAssignPOC(requestId);
		String emailId = requestInventoryObj.getCreatorUser();
		String requestUID = requestInventoryObj.getREQUEST_ID_UI();

		emailData.add(emailId);
		emailCc.add("IDC_SAPUpgrade_Sales@accenture.com");
		email.setMailTo(emailData);
		email.setMailCC(emailCc);
		email.setMailSubject("Request ID : " + requestUID + " Approved");
		email.setMailBody("\n\nDear " + emailId + ",\n\nYour Request ID : " + requestUID
				+ " has been approved. Now, you can proceed with processing.\n\n"
				+ "Regards,\nS/4HANA conversion Team ATCI");
		email.emailSend(email, request, session);

	}

	@SuppressWarnings("null")
	@RequestMapping(value = "/poc/transportRequestAdded/{requestID}", method = RequestMethod.POST)
	public String addedTransportRequest(@PathVariable("requestID") long requestID,
			@RequestParam("trFile") MultipartFile[] files,
			@RequestParam(value = "version", required = false) String version,
			final RedirectAttributes redirectAttributes, Model model, HttpServletRequest request, HttpSession session)
			throws IOException {

		TransportRequestFile transportRequestFile = new TransportRequestFile();
		String toolName = (String) session.getAttribute("tool");

		try {
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestID));
			RequestID_Validator_Utility.chckReqIdPOC(reqIDValid.getPOCName(reqIDValid.getRequestInv(requestID)),
					getPrincipal());

			String trFileName = "";
			String extension = ".zip";
			boolean ContentStatus = false;
			boolean DelTrStatus = false;
			boolean trUlOrAppr = false;

			try {
				String contentStatus = getTransportRequestDAO().getContentAttachedStatus(requestID);
				if (contentStatus != null && !contentStatus.equalsIgnoreCase("Empty"))
					ContentStatus = true;
			} catch (Exception ex) {
				ContentStatus = false;
			}
			try {
				String deltrStatus = getTransportRequestDAO().getDelTrAttachedStatus(requestID);
				if (deltrStatus != null && !deltrStatus.equalsIgnoreCase("Empty"))
					DelTrStatus = true;
			} catch (Exception ex) {
				DelTrStatus = false;
			}
			model.addAttribute("contentUploadStatus", ContentStatus);
			model.addAttribute("trMap", getTransportRequestDAO().getAllTransportRequestListPoc());
			model.addAttribute("deltrUploadStatus", DelTrStatus);
			model.addAttribute("deltrMap", getTransportRequestDAO().getAllDeletionTransportRequestListPoc());

			/*
			 * DiskFileItemFactory factory = new DiskFileItemFactory();
			 * factory.setSizeThreshold(0); ServletFileUpload upload = new
			 * ServletFileUpload(factory); upload.setFileSizeMax(-1); upload.setSizeMax(-1);
			 * String toolName = (String) session.getAttribute("tool"); List<FileItem>
			 * multipart = new ServletFileUpload(factory).parseRequest(request);
			 */

			if (version != null && !version.equals("")) {
				getRequestInventorydao().addRequestApprovedTRFileName(requestID, version);
				model.addAttribute("MessageSuccess", "Transport Request Added Succesfully");
				model.addAttribute("trUploadStatus", true);
				trUlOrAppr = true;
			} else {
				try {
					for (MultipartFile file : files) {
						trFileName = file.getOriginalFilename();
						FileUtility.detectZipFileType(file);
						FileUtility.chckUploadFilesAlphaNum(trFileName);
						FileUtility.checkFileSizeByItem(file, "TR");
						if (!trFileName.equals("")) {
							String fileExtension = trFileName.substring(trFileName.length() - extension.length(),
									trFileName.length());
							if (fileExtension.equalsIgnoreCase(".zip")) {
								Boolean existingVersion = getTransportRequestDAO().getTrExistingStatus(trFileName);
								if (existingVersion) {
									model.addAttribute("MessageFail",
											"Transport Request with this version already exist, please upload a new version TR /Select from drop down, the existing one");
									return "poc/pocUploadTR";
								}
								transportRequestFile.setTrFile(file.getBytes());
								transportRequestFile.setTrFileName(trFileName);
								int maxid = getTransportRequestService().checkMaxVersionCount();
								String TrVersion = "TR" + maxid;
								transportRequestFile.setTrVersion(TrVersion);

								getTransportRequestService().saveTRData(transportRequestFile);
								getRequestInventorydao().addRequestApprovedTRFileName(requestID, TrVersion);
								model.addAttribute("MessageSuccess", "Transport Request Added Succesfully");
								model.addAttribute("trUploadStatus", true);
								trUlOrAppr = true;
							} else {
								model.addAttribute("MessageFail", "Transport Request failed upload .zip format.");
								model.addAttribute("TransportRequest", new TransportRequest());
								model.addAttribute("trUploadStatus", false);
								return "poc/pocUploadTR";
							}
						}
					}
				} catch (UploadFilesNotValidException ex) {
					redirectAttributes.addFlashAttribute("errorMsg", "The filename is not correct.");
					return "redirect:/poc/pocUploadTR/" + requestID;
				} catch (Exception ex) {
					logger.error("Error !!! " + ex);
				}

				if (trUlOrAppr && ContentStatus && DelTrStatus) {
					final RequestForm requestForm = getRequestDetails().getRequestObj(requestID);
					final String systemStatus = getAutoHANA().getSystemStatus(requestID);
					if ((StringUtils.equals(systemStatus, Hana_Profiler_Constant.INITIATED_STATUS)
							|| StringUtils.equals(systemStatus, Hana_Profiler_Constant.PENDING_STATUS))
							&& "federal".equalsIgnoreCase(requestForm.getSupportedAtci())) {
						String POC_Status = "POCEstimatesDlDone";
						String POC_Comment = "Download of Estimates File Done";
						getRequestInventorydao().updatePOCSatus(requestID, Hana_Profiler_Constant.APPROVED_STATUS,
								getPrincipal(), POC_Status, toolName, Hana_Profiler_Constant.REQ_SS_MAN_FL_UL_SUCC,
								Hana_Profiler_Constant.UPLOAD_TR_CR_SUCC);
						sendEmailForCRTRUpload(requestID, request, session);
					} else if (StringUtils.equals(systemStatus, Hana_Profiler_Constant.INITIATED_STATUS)
							|| StringUtils.equals(systemStatus, Hana_Profiler_Constant.PENDING_STATUS)) {
						getRequestInventorydao().updatePOCSatus(requestID, Hana_Profiler_Constant.APPROVED_STATUS,
								getPrincipal(), Hana_Profiler_Constant.TR_UPLOAD_DONE_POC, toolName,
								Hana_Profiler_Constant.REQ_SS_MAN_FL_UL_SUCC, Hana_Profiler_Constant.UPLOAD_TR_CR_SUCC);
						sendEmailForCRTRUpload(requestID, request, session);
					}
					return "redirect:/poc/pocDashBoard";
				} else {
					final String systemStatus = getAutoHANA().getSystemStatus(requestID);
					if (StringUtils.equals(systemStatus, Hana_Profiler_Constant.INITIATED_STATUS)
							|| StringUtils.equals(systemStatus, Hana_Profiler_Constant.PENDING_STATUS)) {
						getRequestInventorydao().updatePOCSatus(requestID, Hana_Profiler_Constant.PENDING_STATUS,
								getPrincipal(), "Pending_POC", toolName, Hana_Profiler_Constant.REQ_SS_MAN_FL_UL_FAIL,
								Hana_Profiler_Constant.UPLOAD_TR_CR_FAIL);
					}
					return "poc/pocUploadTR";
				}

//			for (FileItem item : multipart) {
//				if (!item.isFormField()) {
//					try {						
//						trFile = new File(item.getName());
//						FileUtility.detectZipFileType(item);
//						FileUtility.checkFileSizeByItem(item,"TR");
//						fileName=trFile.getName();
//						if (!fileName.equals("")) {
//							String fileExtension = fileName.substring(fileName.length() - extension.length(),
//									fileName.length());
//							if (fileExtension.equalsIgnoreCase(".zip")) {
//								Boolean existingVersion=getTransportRequestDAO().getTrExistingStatus(fileName);
//								if(existingVersion)
//								{
//									model.addAttribute("MessageFail", "Transport Request with this version already exist, please upload a new version TR /Select from drop down, the existing one");
//									return "poc/pocUploadTR";	
//								}
//								transportRequestFile.setTrFile(item.get());
//								//transportRequestFile.setTrFileName(item.getName());
//								transportRequestFile.setTrFileName(fileName);
//								int maxid=	getTransportRequestService().checkMaxVersionCount();
//								String TrVersion="TR"+maxid;	
//								transportRequestFile.setTrVersion(TrVersion);
//								
//								
//								getTransportRequestService().saveTRData(transportRequestFile);
//								getRequestInventorydao().addRequestApprovedTRFileName(requestID,TrVersion);
//								model.addAttribute("MessageSuccess", "Transport Request Added Succesfully");
//								model.addAttribute("trUploadStatus",true);
//								trUlOrAppr = true;
//							} else{
//								model.addAttribute("MessageFail", "Transport Request failed upload .zip format.");
//								model.addAttribute("TransportRequest", new TransportRequest());
//								model.addAttribute("trUploadStatus",false);
//								return "poc/pocUploadTR";
//							}
//						}
//					} catch (Exception ex) {
//						logger.error("Error !!! " + ex);
//					}
//				} else if (item.isFormField()) {
//					if ("version".equalsIgnoreCase(item.getFieldName())) {
//						 version = item.getString();
//						 getRequestInventorydao().addRequestApprovedTRFileName(requestID,version);
//						 model.addAttribute("MessageSuccess", "Transport Request Added Succesfully");
//						 model.addAttribute("trUploadStatus",true);
//						 trUlOrAppr = true;
//					}
//				}
//				
//				if(trUlOrAppr && ContentStatus) {
//					final String systemStatus = getAutoHANA().getSystemStatus(requestID);
//					if (StringUtils.equals(systemStatus, Hana_Profiler_Constant.INITIATED_STATUS)|| StringUtils.equals(systemStatus, Hana_Profiler_Constant.PENDING_STATUS)) {
//						getRequestInventorydao().updatePOCSatus(requestID, Hana_Profiler_Constant.APPROVED_STATUS, getPrincipal(), "TR_DONE_UPLOAD_POC",toolName, 
//								Hana_Profiler_Constant.REQ_SS_MAN_FL_UL_SUCC, Hana_Profiler_Constant.UPLOAD_TR_CR_SUCC);
//						sendEmailForCRTRUpload(requestID, request, session);
//					}
//					return "redirect:/poc/pocDashBoard";
//				}else {
//					final String systemStatus = getAutoHANA().getSystemStatus(requestID);
//					if (StringUtils.equals(systemStatus, Hana_Profiler_Constant.INITIATED_STATUS)|| StringUtils.equals(systemStatus, Hana_Profiler_Constant.PENDING_STATUS) ) {
//						getRequestInventorydao().updatePOCSatus(requestID, Hana_Profiler_Constant.PENDING_STATUS, getPrincipal(), "Pending_POC",toolName, 
//								Hana_Profiler_Constant.REQ_SS_MAN_FL_UL_FAIL, Hana_Profiler_Constant.UPLOAD_TR_CR_FAIL);
//					}
//					return "poc/pocUploadTR";
//				}
//			}			
			}
		} catch (TransportRequestException exception) {
			logger.error("Inside TransportRequestException");
			redirectAttributes.addFlashAttribute("MessageFail", "Transport Request Already Exists");
		} catch (ReqIDNotValidException ex) {
			model.addAttribute("errorMsg", ex.getMessage());
			return "errors";
		} catch (Exception exception) {
			logger.error("Inside exception " + exception);
			redirectAttributes.addFlashAttribute("MessageFail", exception.getMessage());
		} finally {
			model.addAttribute("trSize", File_Size_Constant.TR_SIZE);
			model.addAttribute("deltrSize", File_Size_Constant.DEL_TR_SIZE);
			model.addAttribute("crSize", File_Size_Constant.CR_SIZE);
		}
		return "poc/pocUploadTR";
	}

	@SuppressWarnings("null")
	@RequestMapping(value = "/poc/deletionTransportRequestAdded/{requestID}", method = RequestMethod.POST)
	public String addedDeletionTransportRequest(@PathVariable("requestID") long requestID,
			@RequestParam("trFile") MultipartFile[] files,
			@RequestParam(value = "version", required = false) String version,
			final RedirectAttributes redirectAttributes, Model model, HttpServletRequest request, HttpSession session)
			throws IOException {

		DeletionTransportRequestFile transportRequestFile = new DeletionTransportRequestFile();
		String toolName = (String) session.getAttribute("tool");

		try {
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestID));
			RequestID_Validator_Utility.chckReqIdPOC(reqIDValid.getPOCName(reqIDValid.getRequestInv(requestID)),
					getPrincipal());

			String trFileName = "";
			String extension = ".zip";
			boolean ContentStatus = false;
			boolean TrStatus = false;
			boolean trUlOrAppr = false;

			try {
				String contentStatus = getTransportRequestDAO().getContentAttachedStatus(requestID);
				if (contentStatus != null && !contentStatus.equalsIgnoreCase("Empty"))
					ContentStatus = true;
			} catch (Exception ex) {
				ContentStatus = false;
			}
			try {
				String trStatus = getTransportRequestDAO().getTrAttachedStatus(requestID);
				if (trStatus != null && !trStatus.equalsIgnoreCase("Empty"))
					TrStatus = true;
			} catch (Exception ex) {
				TrStatus = false;
			}
			model.addAttribute("trUploadStatus", TrStatus);
			model.addAttribute("trMap", getTransportRequestDAO().getAllTransportRequestListPoc());
			model.addAttribute("contentUploadStatus", ContentStatus);
			model.addAttribute("deltrMap", getTransportRequestDAO().getAllDeletionTransportRequestListPoc());

			if (version != null && !version.equals("")) {
				getRequestInventorydao().addRequestDeletionTRFileName(requestID, version);
				model.addAttribute("MessageSuccess", "Deletion Transport Request Added Succesfully");
				model.addAttribute("deltrUploadStatus", true);
				trUlOrAppr = true;
			} else {
				try {
					for (MultipartFile file : files) {
						trFileName = file.getOriginalFilename();
						FileUtility.detectZipFileType(file);
						FileUtility.chckUploadFilesAlphaNum(trFileName);
						FileUtility.checkFileSizeByItem(file, "DEL_TR");
						if (!trFileName.equals("")) {
							String fileExtension = trFileName.substring(trFileName.length() - extension.length(),
									trFileName.length());
							if (fileExtension.equalsIgnoreCase(".zip")) {
								Boolean existingVersion = getTransportRequestDAO()
										.getDeletionTrExistingStatus(trFileName);
								if (existingVersion) {
									model.addAttribute("MessageFail",
											"Deletion Transport Request with this version already exist, please upload a new version TR /Select from drop down, the existing one");
									return "poc/pocUploadTR";
								}
								transportRequestFile.setTrFile(file.getBytes());
								transportRequestFile.setTrFileName(trFileName);
								int maxid = getTransportRequestService().checkMaxDelVersionCount();
								String TrVersion = "DEL_TR" + maxid;
								transportRequestFile.setTrVersion(TrVersion);

								getTransportRequestService().saveDeletionTRData(transportRequestFile);
								getRequestInventorydao().addRequestDeletionTRFileName(requestID, TrVersion);
								model.addAttribute("MessageSuccess", "Deletion Transport Request Added Succesfully");
								model.addAttribute("deltrUploadStatus", true);
								trUlOrAppr = true;
							} else {
								model.addAttribute("MessageFail",
										"Deletion Transport Request failed upload .zip format.");
								model.addAttribute("DeletionTransportRequest", new DeletionTransportRequest());
								model.addAttribute("deltrUploadStatus", false);
								return "poc/pocUploadTR";
							}
						}
					}
				} catch (UploadFilesNotValidException ex) {
					redirectAttributes.addFlashAttribute("errorMsg", "The filename is not correct.");
					return "redirect:/poc/pocUploadTR/" + requestID;
				} catch (Exception ex) {
					logger.error("Error !!! " + ex);
				}

				if (trUlOrAppr && ContentStatus && TrStatus) {
					final RequestForm requestForm = getRequestDetails().getRequestObj(requestID);
					final String systemStatus = getAutoHANA().getSystemStatus(requestID);
					if ((StringUtils.equals(systemStatus, Hana_Profiler_Constant.INITIATED_STATUS)
							|| StringUtils.equals(systemStatus, Hana_Profiler_Constant.PENDING_STATUS))
							&& "federal".equalsIgnoreCase(requestForm.getSupportedAtci())) {
						String POC_Status = "POCEstimatesDlDone";
						String POC_Comment = "Download of Estimates File Done";
						getRequestInventorydao().updatePOCSatus(requestID, Hana_Profiler_Constant.APPROVED_STATUS,
								getPrincipal(), POC_Status, toolName, Hana_Profiler_Constant.REQ_SS_MAN_FL_UL_SUCC,
								Hana_Profiler_Constant.UPLOAD_TR_CR_SUCC);
					} else if (StringUtils.equals(systemStatus, Hana_Profiler_Constant.INITIATED_STATUS)
							|| StringUtils.equals(systemStatus, Hana_Profiler_Constant.PENDING_STATUS)) {
						getRequestInventorydao().updatePOCSatus(requestID, Hana_Profiler_Constant.APPROVED_STATUS,
								getPrincipal(), "TR_DONE_UPLOAD_POC", toolName,
								Hana_Profiler_Constant.REQ_SS_MAN_FL_UL_SUCC, Hana_Profiler_Constant.UPLOAD_TR_CR_SUCC);
						sendEmailForCRTRUpload(requestID, request, session);
					}
					return "redirect:/poc/pocDashBoard";

//				
				} else {
					final String systemStatus = getAutoHANA().getSystemStatus(requestID);
					if (StringUtils.equals(systemStatus, Hana_Profiler_Constant.INITIATED_STATUS)
							|| StringUtils.equals(systemStatus, Hana_Profiler_Constant.PENDING_STATUS)) {
						getRequestInventorydao().updatePOCSatus(requestID, Hana_Profiler_Constant.PENDING_STATUS,
								getPrincipal(), "Pending_POC", toolName, Hana_Profiler_Constant.REQ_SS_MAN_FL_UL_FAIL,
								Hana_Profiler_Constant.UPLOAD_TR_CR_FAIL);
					}
					return "poc/pocUploadTR";
				}

			}
		} catch (TransportRequestException exception) {
			logger.error("Inside TransportRequestException");
			redirectAttributes.addFlashAttribute("MessageFail", "Transport Request Already Exists");
		} catch (ReqIDNotValidException ex) {
			model.addAttribute("errorMsg", ex.getMessage());
			return "errors";
		} catch (Exception exception) {
			logger.error("Inside exception " + exception);
			redirectAttributes.addFlashAttribute("MessageFail", exception.getMessage());
		} finally {
			model.addAttribute("trSize", File_Size_Constant.TR_SIZE);
			model.addAttribute("deltrSize", File_Size_Constant.DEL_TR_SIZE);
			model.addAttribute("crSize", File_Size_Constant.CR_SIZE);
		}
		return "poc/pocUploadTR";
	}

	/**
	 * @author sankhamala.a.pal
	 * @param request
	 * @param requestId
	 * @param model
	 * @param session
	 * @param redirectAttributes
	 * @param response
	 */
	@RequestMapping(value = "/downloadRomEstimatesSheetPoc/{requestId}", method = RequestMethod.GET)
	public String downloadRomEstimateSheetPOC(HttpServletRequest request,
			@PathVariable("requestId") final long requestId, Model model, HttpSession session,
			RedirectAttributes redirectAttributes, HttpServletResponse response) {
		String message = "";
		try {
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestId));
			RequestID_Validator_Utility.chckReqIdPOC(reqIDValid.getPOCName(reqIDValid.getRequestInv(requestId)),
					getPrincipal());

			message = downloadRomEstimateSheet(request, requestId, model, session, redirectAttributes, response);

			// Updating POC Status and Sub-Status
			String status = Hana_Profiler_Constant.RFP_POC_DL_SUCCESS_STATUS;
			String toolName = (String) session.getAttribute("tool");
			getRequestInventorydao().updateRfpSatus(requestId, status, getPrincipal(), toolName,
					Hana_Profiler_Constant.REQ_SS_ROM_Estimate_FL_DL_SUCC, Hana_Profiler_Constant.DOWN_RFP_SUCC);
		} catch (ReqIDNotValidException ex) {
			model.addAttribute("errorMsg", ex.getMessage());
			return "errors";
		} catch (Exception e) {
			message = "Error While Downloading ROM Estimates Sheet !!!";
			logger.error(message + " " + e.getStackTrace());
		}

		return null;
	}

	@RequestMapping(value = "/downloadRomEstimatesSheetClient/{requestId}", method = RequestMethod.GET)
	public String downloadRomEstimateSheetClient(HttpServletRequest request,
			@PathVariable("requestId") final long requestId, Model model, HttpSession session,
			RedirectAttributes redirectAttributes, HttpServletResponse response) {

		String message = "";
		try {
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestId));
			RequestID_Validator_Utility.chckReqIdUser(reqIDValid.getCreator(reqIDValid.getRequestInv(requestId)),
					getPrincipal());

			message = downloadRomEstimateSheet(request, requestId, model, session, redirectAttributes, response);

			// Updating POC Status and Sub-Status
			String status = Hana_Profiler_Constant.RFP_POC_UL_SUCCESS_STATUS;
			String toolName = (String) session.getAttribute("tool");
			getRequestInventorydao().updateRfpSatus(requestId, status, getPrincipal(), toolName, null,
					Hana_Profiler_Constant.RFP_POC_APPROVE);
		} catch (ReqIDNotValidException ex) {
			model.addAttribute("errorMsg", ex.getMessage());
			return "errors";
		} catch (Exception e) {
			message = "Error While Downloading ROM Estimates Sheet !!!";
			logger.error(message + " " + e.getStackTrace());
		}

		return null;
	}

	public String downloadRomEstimateSheet(HttpServletRequest request, final long requestId, Model model,
			HttpSession session, RedirectAttributes redirectAttributes, HttpServletResponse response)
			throws InvalidFormatException, FileNotFoundException, IOException {
		String message = "";
		String graphTemplete = request.getSession().getServletContext()
				.getRealPath("/staticResources/GraphTemplate/ROM_Estimation_Temp.xlsx");

		XSSFWorkbook workbook = new XSSFWorkbook(OPCPackage.open(new FileInputStream(graphTemplete)));
		@SuppressWarnings("resource")
		SXSSFWorkbook workbookTemp = new SXSSFWorkbook(workbook);

		List<TADIRInventory> romEstimatesList = getProcessedEstimates().getRomEstimates(requestId);
		List<RequestForm> reqFormsList = getProcessedEstimates().getRequestForm(requestId);
		RequestForm req = new RequestForm();
		for (RequestForm r : reqFormsList) {
			if (r != null)
				req = r;
		}
		for (TADIRInventory tadir : romEstimatesList) {

			downloadRomEstimateSheet0(tadir, req, workbookTemp, workbook);
			FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
			for (Row r : workbook.getSheetAt(0)) {
				for (Cell c : r) {
					if (c.getCellType() == Cell.CELL_TYPE_FORMULA) {
						evaluator.evaluateFormulaCell(c);
					}
				}
			}
			workbook.setForceFormulaRecalculation(true);
			downloadRomEstimateSheet6(tadir, req, workbookTemp);

		}
		String graphFileName = "ROM_Estimates_" + requestId + ".xlsx";

		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		workbook.write(bos);
		bos.close();

		byte[] bytes = bos.toByteArray();
		getFileDownload().downloadFile(bytes, response, graphFileName);

		message = "Estimates Sheet Downloaded Sucessfully !!!";
		logger.info(message);

		return message;
	}

	public void downloadRomEstimateSheet0(TADIRInventory tadir, RequestForm req, SXSSFWorkbook workbookTemp,
			XSSFWorkbook workbook) {
		XSSFSheet sheet = workbookTemp.getXSSFWorkbook().getSheetAt(0);
		Row row;
		Cell col;
		String sys = "";

		// System Landscape Details
		row = sheet.getRow(12);
		col = row.getCell(10);
		sys = req.getSandbox();
		if ("".equals(sys))
			col.setCellValue(0);
		else
			col.setCellValue(Integer.parseInt(sys));

		row = sheet.getRow(13);
		col = row.getCell(10);
		sys = req.getNumberDevelopment();
		if ("".equals(sys))
			col.setCellValue(0);
		else
			col.setCellValue(Integer.parseInt(sys));

		row = sheet.getRow(14);
		col = row.getCell(10);
		sys = req.getNumberQuality();
		if ("".equals(sys))
			col.setCellValue(0);
		else
			col.setCellValue(Integer.parseInt(sys));

		row = sheet.getRow(15);
		col = row.getCell(10);
		sys = req.getNumberProduction();
		if ("".equals(sys))
			col.setCellValue(0);
		else
			col.setCellValue(Integer.parseInt(sys));

		col = row.getCell(16);
		sys = req.getNumberOtherSystem();
		if ("".equals(sys))
			col.setCellValue(0);
		else
			col.setCellValue(Integer.parseInt(sys));

		// System Details
		row = sheet.getRow(12);
		col = row.getCell(2);
		sys = req.getSourceVersion();
		col.setCellValue(sys);

		row = sheet.getRow(18);
		col = row.getCell(2);
		sys = req.getTargetVersion();
		col.setCellValue(sys);

		row = sheet.getRow(13);
		col = row.getCell(2);
		sys = req.getUnicodeCompliant();
		if (sys.equalsIgnoreCase("yes"))
			col.setCellValue("Yes");
		else
			col.setCellValue("No");
		row = sheet.getRow(19);
		col = row.getCell(2);
		sys = req.getEnableUnicode();
		if (sys.equalsIgnoreCase("yes"))
			col.setCellValue("Yes");
		else
			col.setCellValue("No");

		row = sheet.getRow(14);
		col = row.getCell(2);
		Boolean hana = req.getSOH();
		if (hana)
			col.setCellValue("Yes");
		else
			col.setCellValue("No");
		row = sheet.getRow(20);
		col = row.getCell(2);
		col.setCellValue("Yes");

		// Inventory Details
		if (tadir.getRicefwCount() == 0) {
			row = sheet.getRow(12);
			col = row.getCell(6);
			col.setCellValue(tadir.getFunctionGroups());

			row = sheet.getRow(13);
			col = row.getCell(6);
			col.setCellValue(tadir.getPrograms());

			row = sheet.getRow(14);
			col = row.getCell(6);
			col.setCellValue(tadir.getClasses());

			row = sheet.getRow(15);
			col = row.getCell(6);
			col.setCellValue(tadir.getForm());
			col = row.getCell(10);

			row = sheet.getRow(16);
			col = row.getCell(6);
			col.setCellValue(tadir.getEnhancements());

			row = sheet.getRow(17);
			col = row.getCell(6);
			col.setCellValue(tadir.getWebDynpro());

			row = sheet.getRow(18);
			col = row.getCell(6);
			col.setCellValue(tadir.getLsmw());

			row = sheet.getRow(19);
			col = row.getCell(6);
			col.setCellValue(tadir.getUserExists());

			row = sheet.getRow(20);
			col = row.getCell(6);
			col.setCellValue(tadir.getInterfaces());

			row = sheet.getRow(21);
			col = row.getCell(6);
			col.setCellValue(tadir.getWorkflow());

		} else {
			row = sheet.getRow(25);
			col = row.getCell(17);
			col.setCellValue(tadir.getRicefwCount());
			FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
			for (Row r : workbook.getSheetAt(0)) {
				for (Cell c : r) {
					if (c.getCellType() == Cell.CELL_TYPE_FORMULA) {
						evaluator.evaluateFormulaCell(c);
					}
				}
			}
			int x = 0;
			row = sheet.getRow(12);
			col = row.getCell(18);
			x = (int) col.getNumericCellValue();
			row = sheet.getRow(12);
			col = row.getCell(6);
			col.setCellValue(x);

			row = sheet.getRow(13);
			col = row.getCell(18);
			x = (int) col.getNumericCellValue();
			row = sheet.getRow(13);
			col = row.getCell(6);
			col.setCellValue(x);

			row = sheet.getRow(14);
			col = row.getCell(18);
			x = (int) col.getNumericCellValue();
			row = sheet.getRow(14);
			col = row.getCell(6);
			col.setCellValue(x);

			row = sheet.getRow(15);
			col = row.getCell(18);
			x = (int) col.getNumericCellValue();
			row = sheet.getRow(15);
			col = row.getCell(6);
			col.setCellValue(x);

			row = sheet.getRow(16);
			col = row.getCell(18);
			x = (int) col.getNumericCellValue();
			row = sheet.getRow(16);
			col = row.getCell(6);
			col.setCellValue(x);

			row = sheet.getRow(17);
			col = row.getCell(18);
			x = (int) col.getNumericCellValue();
			row = sheet.getRow(17);
			col = row.getCell(6);
			col.setCellValue(x);

			row = sheet.getRow(18);
			col = row.getCell(18);
			x = (int) col.getNumericCellValue();
			row = sheet.getRow(18);
			col = row.getCell(6);
			col.setCellValue(x);

			row = sheet.getRow(19);
			col = row.getCell(18);
			x = (int) col.getNumericCellValue();
			row = sheet.getRow(19);
			col = row.getCell(6);
			col.setCellValue(x);

			row = sheet.getRow(20);
			col = row.getCell(18);
			x = (int) col.getNumericCellValue();
			row = sheet.getRow(20);
			col = row.getCell(6);
			col.setCellValue(x);

			row = sheet.getRow(21);
			col = row.getCell(18);
			x = (int) col.getNumericCellValue();
			row = sheet.getRow(21);
			col = row.getCell(6);
			col.setCellValue(x);

		}

	}

	public void downloadRomEstimateSheet6(TADIRInventory tadir, RequestForm req, SXSSFWorkbook workbookTemp) {
		XSSFSheet sheet = workbookTemp.getXSSFWorkbook().getSheetAt(6);
		XSSFSheet sheet0 = workbookTemp.getXSSFWorkbook().getSheetAt(0);

		Row row;
		Cell col;
		String val = "";
		val = "Inventory Count is - " + (int) sheet0.getRow(23).getCell(6).getNumericCellValue() + "\n"
				+ "Functional Groups - " + (int) sheet0.getRow(12).getCell(6).getNumericCellValue() + "\n"
				+ "Programs - " + (int) sheet0.getRow(13).getCell(6).getNumericCellValue() + "\n" + "Classes - "
				+ (int) sheet0.getRow(14).getCell(6).getNumericCellValue() + "\n" + "Forms - "
				+ (int) sheet0.getRow(15).getCell(6).getNumericCellValue() + "\n" + "Enhancements - "
				+ (int) sheet0.getRow(16).getCell(6).getNumericCellValue() + "\n" + "Web Dynpro - "
				+ (int) sheet0.getRow(17).getCell(6).getNumericCellValue() + "\n" + "LSMW - "
				+ (int) sheet0.getRow(18).getCell(6).getNumericCellValue() + "\n" + "User Exists - "
				+ (int) sheet0.getRow(19).getCell(6).getNumericCellValue() + "\n" + "Interfaces - "
				+ (int) sheet0.getRow(20).getCell(6).getNumericCellValue() + "\n" + "Workflows - "
				+ (int) sheet0.getRow(21).getCell(6).getNumericCellValue();

		row = sheet.getRow(7);
		col = row.getCell(1);
		col.setCellValue(val);
	}

	@RequestMapping(value = "/poc/pocApproveRomEstimatesFile/{requestID}", method = RequestMethod.GET)
	public String approveRomEstimatesFilePOC(@PathVariable("requestID") Long requestID,
			final HttpServletRequest request, HttpSession session, Model model) throws Exception {
		String toolName = (String) session.getAttribute("tool");

		try {
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestID));
			RequestID_Validator_Utility.chckReqIdPOC(reqIDValid.getPOCName(reqIDValid.getRequestInv(requestID)),
					getPrincipal());

			// Updating POC Status, Sub-Status and Request Status
			String POC_Status = "Completed_POC";
			String POC_Comment = "Rom Estimation File uploaded by POC. Processing from POC is completed.";

			getRequestInventorydao().updateSatusPOC(requestID, getPrincipal(), toolName, POC_Status, POC_Comment,
					Hana_Profiler_Constant.REQ_SS_COMPLETED, Hana_Profiler_Constant.POC_UPLOAD_ROMESTIMATES_SUCC);
			getRequestInventorydao().updateSatus(requestID, Hana_Profiler_Constant.ROMREFININGCOMPLETED, getPrincipal(),
					Hana_Profiler_Constant.POC_UPLOAD_ROMESTIMATES_SUCC, toolName);

			String status = Hana_Profiler_Constant.RFP_POC_UL_SUCCESS_STATUS;
			getRequestInventorydao().updateRfpSatus(requestID, status, getPrincipal(), toolName,
					Hana_Profiler_Constant.REQ_SS_ROM_Estimate_FL_UL_SUCC, Hana_Profiler_Constant.RFP_POC_APPROVE);
			// Sending Email on Successful Upload of Estimates Report
			try {
				sendEmailForRomEstimatesFileUpload(requestID, request,
						"Successful Upload of ROM Estimates Report by POC", session);
			} catch (Exception e) {
				logger.error("Error while sending Email");
			}

			return "redirect:/poc/pocDashBoard";
		} catch (ReqIDNotValidException ex) {
			model.addAttribute("errorMsg", ex.getMessage());
			return "errors";
		} catch (Exception ex) {
			logger.error("Error while uploading and updating estimates in DB !!! " + ex.getStackTrace().toString());
			String status = Hana_Profiler_Constant.RFP_POC_UL_FAILED_STATUS;
			getRequestInventorydao().updateRfpSatus(requestID, status, getPrincipal(), toolName,
					Hana_Profiler_Constant.REQ_SS_ROM_Estimate_FL_UL_FAIL, Hana_Profiler_Constant.RFP_POC_APPROVE_FAIL);
			// Sending Email on Failure of Upload of Estimates Report
			try {
				sendEmailForRomEstimatesFileUpload(requestID, request, "Upload of ROM Estimates Report by POC Fails",
						session);
			} catch (Exception e) {
				logger.error("Error while sending Email " + e);
			}
			return "redirect:/poc/pocDashBoard";
		}
	}

	@RequestMapping(value = "/poc/uploadRomEstimatesFile/{requestID}", method = RequestMethod.POST)
	public String uploadRomEstimatesFilePOC(@PathVariable("requestID") long requestId,
			final RedirectAttributes redirectAttributes, Model model, final HttpSession session,
			final HttpServletRequest request, @RequestParam("files") MultipartFile[] files) throws Exception {
		String toolName = (String) session.getAttribute("tool");
		String status;

		try {
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestId));
			RequestID_Validator_Utility.chckReqIdPOC(reqIDValid.getPOCName(reqIDValid.getRequestInv(requestId)),
					getPrincipal());

			final RequestForm requestForm = getRequestDetails().getRequestObj(requestId);
			final String clientName = requestForm.getClientName();
			final String filePath = HANAUtility.getRomEstimatesFileUploadPath(clientName, requestId);

			// Writing Estimates File at Server Location
			logger.info("File Upload Starts ...");
			finalFileUpload.writeFile(requestId, clientName, filePath, files);
			logger.info("File Upload Successfull !!!");

			// Updating Database with Estimate Values Changed by POC
			logger.info("Writing to DB Starts ...");
			inputRomEstimatesFile(requestId);
			logger.info("DB is sucessfully updated !!!");

			// Updating POC Status, Sub-Status and Request Status

			String POC_Status = "Completed_POC";
			String POC_Comment = "Estimation File uploaded by POC. Processing from POC is completed.";

			getRequestInventorydao().updateSatusPOC(requestId, getPrincipal(), toolName, POC_Status, POC_Comment,
					Hana_Profiler_Constant.REQ_SS_COMPLETED, Hana_Profiler_Constant.POC_UPLOAD_ROMESTIMATES_SUCC);
			getRequestInventorydao().updateSatus(requestId, Hana_Profiler_Constant.ROMREFININGCOMPLETED, getPrincipal(),
					Hana_Profiler_Constant.POC_UPLOAD_ROMESTIMATES_SUCC, toolName);

			status = Hana_Profiler_Constant.RFP_POC_UL_SUCCESS_STATUS;
			getRequestInventorydao().updateRfpSatus(requestId, status, getPrincipal(), toolName,
					Hana_Profiler_Constant.REQ_SS_ROM_Estimate_FL_UL_SUCC, Hana_Profiler_Constant.RFP_POC_APPROVE);
			model.addAttribute("uploadSuccess", "File Uploaded Successfully");

			// Sending Email on Successful Upload of Estimates Report
			try {
				sendEmailForRomEstimatesFileUpload(requestId, request,
						"Successful Upload of ROM Estimates Report by POC", session);
			} catch (Exception e) {
				logger.error("Error while sending Email " + e);
			}

			return "redirect:/poc/pocDashBoard";
		} catch (ReqIDNotValidException ex) {
			model.addAttribute("errorMsg", ex.getMessage());
			return "errors";
		} catch (UploadFilesNotValidException ex) {
			redirectAttributes.addFlashAttribute("errorMsg", "The filename is not correct.");
			return "redirect:/poc/pocUploadRE/" + requestId;
		} catch (Exception ex) {
			logger.error("Error while uploading and updating estimates in DB !!! " + ex.getStackTrace().toString());
			status = Hana_Profiler_Constant.RFP_POC_UL_FAILED_STATUS;
			getRequestInventorydao().updateRfpSatus(requestId, status, getPrincipal(), toolName,
					Hana_Profiler_Constant.REQ_SS_ROM_Estimate_FL_UL_FAIL, Hana_Profiler_Constant.RFP_POC_APPROVE_FAIL);
			model.addAttribute("uploadSuccess", "Upload of ROM Estimates Report by POC Fails !!!");

			// Sending Email on Failure of Upload of Estimates Report
			try {
				sendEmailForRomEstimatesFileUpload(requestId, request, "Upload of ROM Estimates Report by POC Fails",
						session);
			} catch (Exception e) {
				logger.error("Error while sending Email");
				logger.error("Error !!! " + e);
			}
			return "redirect:/poc/pocDashBoard";
		}
	}

	public void inputRomEstimatesFile(Long requestId) throws Exception {
		logger.info("Reading Estimates File after Manipulation by POC Starts ...");
		final RequestForm requestForm = getRequestDetails().getRequestObj(requestId);

		String rootPath = HANAUtility.getRomEstimatesFileUploadPath(requestForm.getClientName(), requestId);
		File folder = new File(rootPath);
		File[] listOfFiles = folder.listFiles();

		for (File file : listOfFiles) {
			FileUtility.checkFileSize(file);
			if (file.isFile()) {
				try {
					String retrievedcompleteFilePath = rootPath + "\\" + file.getName();

					String comment = readRomEstimationSheetData(retrievedcompleteFilePath, requestId, requestForm);
					logger.info(comment);

				} catch (Exception e) {
					logger.error("Error while Writing Estimates File to DB " + e);
					throw new Exception();
				}
			}
		}
	}

	public String readRomEstimationSheetData(final String path, final long requestId, RequestForm requestForm)
			throws Exception {
		String comment = "";
		try {
			TADIRInventory tadir = new TADIRInventory();
			uploadRomEstimationSheetData(path, tadir);

			tadir.setRequestID(requestId);
			getRequestDetails().saveTadirForm(tadir);

			comment = "Reading of Excel File Successfull !!!";
		} catch (Exception e) {
			comment = "Reading of Rom Estimates File Fails !!! ";
			logger.error(comment + e);
			throw new Exception();
		}

		return comment;
	}

	public void uploadRomEstimationSheetData(final String path, TADIRInventory tadir)
			throws InvalidFormatException, FileNotFoundException, IOException {
		XSSFWorkbook workbook = new XSSFWorkbook(OPCPackage.open(new FileInputStream(path)));
		@SuppressWarnings("resource")
		SXSSFWorkbook workbookTemp = new SXSSFWorkbook(workbook);
		XSSFSheet sheet = workbookTemp.getXSSFWorkbook().getSheetAt(0);
		Row row, row1;
		Cell col, col1;
		row1 = sheet.getRow(25);
		col1 = row1.getCell(17);
		Integer ricefwcount = (int) col1.getNumericCellValue();
		if (ricefwcount == 0) {
			row = sheet.getRow(12);
			col = row.getCell(6);
			tadir.setFunctionGroups((int) col.getNumericCellValue());

			row = sheet.getRow(13);
			col = row.getCell(6);
			tadir.setPrograms((int) col.getNumericCellValue());

			row = sheet.getRow(14);
			col = row.getCell(6);
			tadir.setClasses((int) col.getNumericCellValue());

			row = sheet.getRow(15);
			col = row.getCell(6);
			tadir.setForm((int) col.getNumericCellValue());

			row = sheet.getRow(16);
			col = row.getCell(6);
			tadir.setEnhancements((int) col.getNumericCellValue());

			row = sheet.getRow(17);
			col = row.getCell(6);
			tadir.setWebDynpro((int) col.getNumericCellValue());

			row = sheet.getRow(18);
			col = row.getCell(6);
			tadir.setLsmw((int) col.getNumericCellValue());

			row = sheet.getRow(19);
			col = row.getCell(6);
			tadir.setUserExists((int) col.getNumericCellValue());

			row = sheet.getRow(20);
			col = row.getCell(6);
			tadir.setInterfaces((int) col.getNumericCellValue());

			row = sheet.getRow(21);
			col = row.getCell(6);
			tadir.setWorkflow((int) col.getNumericCellValue());

			tadir.setRicefwCount(ricefwcount);

		} else {
			tadir.setRicefwCount(ricefwcount);
			tadir.setFunctionGroups(0);
			tadir.setPrograms(0);
			tadir.setClasses(0);
			tadir.setForm(0);
			tadir.setEnhancements(0);
			tadir.setWebDynpro(0);
			tadir.setLsmw(0);
			tadir.setUserExists(0);
			tadir.setInterfaces(0);
			tadir.setWorkflow(0);

		}
	}

	/**
	 * @author shivani.o.gupta - Controller for Downloading Estimates Sheet
	 * @param request
	 * @param requestId
	 * @param model
	 * @param session
	 * @param redirectAttributes
	 * @param response
	 */
	@RequestMapping(value = "/downloadEstimatesSheet/{requestId}/{userRole}", method = RequestMethod.GET)
	public String downloadEstimateSheet(HttpServletRequest request, @PathVariable("requestId") final long requestId,
			@PathVariable("userRole") final String userRole, Model model, HttpSession session,
			RedirectAttributes redirectAttributes, HttpServletResponse response) {
		String message = "";

		try {
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestId));
			if (userRole.equalsIgnoreCase("CLIENT"))
				RequestID_Validator_Utility.chckReqIdUser(reqIDValid.getCreator(reqIDValid.getRequestInv(requestId)),
						getPrincipal());
			else if (userRole.equalsIgnoreCase("POC"))
				RequestID_Validator_Utility.chckReqIdPOC(reqIDValid.getPOCName(reqIDValid.getRequestInv(requestId)),
						getPrincipal());

			String graphTemplete = request.getSession().getServletContext()
					.getRealPath("/staticResources/GraphTemplate/Estimates_Temp_POC.xlsx");

			XSSFWorkbook workbook = new XSSFWorkbook(OPCPackage.open(new FileInputStream(graphTemplete)));

			@SuppressWarnings("resource")
			SXSSFWorkbook workbookTemp = new SXSSFWorkbook(workbook);

			XSSFCellStyle styleCellName = workbook.createCellStyle();

			Map<String, ProcessedEstimates> estimatesMap = new HashMap<>();
			List<ProcessedEstimates> estimatesList = getProcessedEstimates().getEstimatesReqMaster(requestId);

			if (!(estimatesList.isEmpty()) || estimatesList.size() > 0) {
				for (ProcessedEstimates estimatesDetail : estimatesList) {
					estimatesMap.put(estimatesDetail.getScope(), estimatesDetail);
				}
			}

			if (estimatesMap.containsKey("HANA")) {
				logger.info("Downloading of HANA Estimate Sheet starts ...");
				ProcessedEstimates processedReq = estimatesMap.get("HANA");

				downloadEstimateSheet0(processedReq, workbookTemp, styleCellName);
				downloadEstimateSheet1(processedReq, workbookTemp, styleCellName);
				downloadEstimateSheet2(processedReq, workbookTemp, styleCellName);
				downloadEstimateSheet3(processedReq, workbookTemp, styleCellName);

			}
			if (estimatesMap.containsKey("S4")) {

			}

			XSSFFormulaEvaluator.evaluateAllFormulaCells(workbook);

			String graphFileName = "Estimates_POC_" + requestId + ".xlsx";

			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			workbook.write(bos);
			bos.close();

			byte[] bytes = bos.toByteArray();
			getFileDownload().downloadFile(bytes, response, graphFileName);

			message = "Estimates Sheet Downloaded Sucessfully !!!";
			logger.info(message);

			// Updating POC Status and Sub-Status
			String POC_Status = "POCEstimatesDlDone";
			String POC_Comment = "Download of Estimates File Done";
			String toolName = (String) session.getAttribute("tool");

			getRequestInventorydao().updateSatusPOC(requestId, getPrincipal(), toolName, POC_Status, POC_Comment,
					Hana_Profiler_Constant.REQ_SS_Estimate_FL_DL_SUCC, Hana_Profiler_Constant.POC_DOWN_EST_SUCC);
		} catch (ReqIDNotValidException ex) {
			model.addAttribute("errorMsg", ex.getMessage());
			return "errors";
		} catch (Exception e) {
			message = "Error While Downloading Estimates Sheet !!!";
			logger.error(message + " " + e.getStackTrace());
		}

		return null;
	}

	public void downloadEstimateSheet0(ProcessedEstimates processedReq, SXSSFWorkbook workbookTemp,
			XSSFCellStyle styleCellName) {
		XSSFSheet sheet = workbookTemp.getXSSFWorkbook().getSheetAt(0);
		Row row = sheet.getRow(4);
		setObjectCountsSheet0AndSheet1(processedReq, sheet, styleCellName);

		for (int i = 2; i < 29; i++) {
			if (row.getCell(i).getCellType() != HSSFCell.CELL_TYPE_BLANK) {
				row.getCell(i).setCellType(HSSFCell.CELL_TYPE_BLANK);
			}
		}

		chckEstimateSheetCellsValue(2, processedReq.getDmaFUGR_Count_N_High(), row, styleCellName);
		chckEstimateSheetCellsValue(3, processedReq.getDmaFUGR_Count_N_Medium(), row, styleCellName);
		chckEstimateSheetCellsValue(4, processedReq.getDmaFUGR_Count_N_Low(), row, styleCellName);

		chckEstimateSheetCellsValue(5, processedReq.getDmaPROG_Count_N_High(), row, styleCellName);
		chckEstimateSheetCellsValue(6, processedReq.getDmaPROG_Count_N_Medium(), row, styleCellName);
		chckEstimateSheetCellsValue(7, processedReq.getDmaPROG_Count_N_Low(), row, styleCellName);

		chckEstimateSheetCellsValue(8, processedReq.getDmaCLAS_Count_N_High(), row, styleCellName);
		chckEstimateSheetCellsValue(9, processedReq.getDmaCLAS_Count_N_Medium(), row, styleCellName);
		chckEstimateSheetCellsValue(10, processedReq.getDmaCLAS_Count_N_Low(), row, styleCellName);

		chckEstimateSheetCellsValue(11, processedReq.getDmaFORM_Count_N_High(), row, styleCellName);
		chckEstimateSheetCellsValue(12, processedReq.getDmaFORM_Count_N_Medium(), row, styleCellName);
		chckEstimateSheetCellsValue(13, processedReq.getDmaFORM_Count_N_Low(), row, styleCellName);

		chckEstimateSheetCellsValue(14, processedReq.getDmaENH_Count_N_High(), row, styleCellName);
		chckEstimateSheetCellsValue(15, processedReq.getDmaENH_Count_N_Medium(), row, styleCellName);
		chckEstimateSheetCellsValue(16, processedReq.getDmaENH_Count_N_Low(), row, styleCellName);

		chckEstimateSheetCellsValue(17, processedReq.getDmaWDYN_Count_N_High(), row, styleCellName);
		chckEstimateSheetCellsValue(18, processedReq.getDmaWDYN_Count_N_Medium(), row, styleCellName);
		chckEstimateSheetCellsValue(19, processedReq.getDmaWDYN_Count_N_Low(), row, styleCellName);

		chckEstimateSheetCellsValue(20, processedReq.getDmaFUGS_Count_N_High(), row, styleCellName);
		chckEstimateSheetCellsValue(21, processedReq.getDmaFUGS_Count_N_Medium(), row, styleCellName);
		chckEstimateSheetCellsValue(22, processedReq.getDmaFUGS_Count_N_Low(), row, styleCellName);

		chckEstimateSheetCellsValue(23, processedReq.getDmaLSMW_Count_N_High(), row, styleCellName);
		chckEstimateSheetCellsValue(24, processedReq.getDmaLSMW_Count_N_Medium(), row, styleCellName);
		chckEstimateSheetCellsValue(25, processedReq.getDmaLSMW_Count_N_Low(), row, styleCellName);

		chckEstimateSheetCellsValue(26, processedReq.getDmaUSEREXIT_Count_N_High(), row, styleCellName);
		chckEstimateSheetCellsValue(27, processedReq.getDmaUSEREXIT_Count_N_Medium(), row, styleCellName);
		chckEstimateSheetCellsValue(28, processedReq.getDmaUSEREXIT_Count_N_Low(), row, styleCellName);

	}

	public void downloadEstimateSheet1(ProcessedEstimates processedReq, SXSSFWorkbook workbookTemp,
			XSSFCellStyle styleCellName) {
		XSSFSheet sheet = workbookTemp.getXSSFWorkbook().getSheetAt(1);
		Row row = sheet.getRow(4);
		setObjectCountsSheet0AndSheet1(processedReq, sheet, styleCellName);

		for (int i = 2; i < 29; i++) {
			if (row.getCell(i).getCellType() != HSSFCell.CELL_TYPE_BLANK) {
				row.getCell(i).setCellType(HSSFCell.CELL_TYPE_BLANK);
			}
		}

		chckEstimateSheetCellsValue(4, processedReq.getDmaFUGR_Count_Y_Low(), row, styleCellName);
		chckEstimateSheetCellsValue(7, processedReq.getDmaPROG_Count_Y_Low(), row, styleCellName);
		chckEstimateSheetCellsValue(10, processedReq.getDmaCLAS_Count_Y_Low(), row, styleCellName);
		chckEstimateSheetCellsValue(22, processedReq.getDmaFUGS_Count_Y_Low(), row, styleCellName);
	}

	public void setObjectCountsSheet0AndSheet1(ProcessedEstimates processedReq, XSSFSheet sheet,
			XSSFCellStyle styleCellName) {
		Row row = sheet.getRow(3);
		for (int i = 2; i < 27; i++) {
			if (row.getCell(i).getCellType() != HSSFCell.CELL_TYPE_BLANK) {
				row.getCell(i).setCellType(HSSFCell.CELL_TYPE_BLANK);
			}
		}

		chckEstimateSheetCellsValue(2, processedReq.getDmaFUGR_Count(), row, styleCellName);
		chckEstimateSheetCellsValue(5, processedReq.getDmaPROG_Count(), row, styleCellName);
		chckEstimateSheetCellsValue(8, processedReq.getDmaCLAS_Count(), row, styleCellName);
		chckEstimateSheetCellsValue(11, processedReq.getDmaFORM_Count(), row, styleCellName);
		chckEstimateSheetCellsValue(14, processedReq.getDmaENH_Count(), row, styleCellName);
		chckEstimateSheetCellsValue(17, processedReq.getDmaWDYN_Count(), row, styleCellName);
		chckEstimateSheetCellsValue(20, processedReq.getDmaFUGS_Count(), row, styleCellName);
		chckEstimateSheetCellsValue(23, processedReq.getDmaLSMW_Count(), row, styleCellName);
		chckEstimateSheetCellsValue(26, processedReq.getDmaUSEREXIT_Count(), row, styleCellName);
	}

	public void downloadEstimateSheet2(ProcessedEstimates processedReq, SXSSFWorkbook workbookTemp,
			XSSFCellStyle styleCellName) {
		XSSFSheet sheet = workbookTemp.getXSSFWorkbook().getSheetAt(2);
		Row row = sheet.getRow(4);
		setObjectCountsSheet2AndSheet3(processedReq, sheet, styleCellName);

		for (int i = 2; i < 29; i++) {
			if (row.getCell(i).getCellType() != HSSFCell.CELL_TYPE_BLANK) {
				row.getCell(i).setCellType(HSSFCell.CELL_TYPE_BLANK);
			}
		}

		chckEstimateSheetCellsValue(2, processedReq.getDumaFUGR_Count_N_High(), row, styleCellName);
		chckEstimateSheetCellsValue(3, processedReq.getDumaFUGR_Count_N_Medium(), row, styleCellName);
		chckEstimateSheetCellsValue(4, processedReq.getDumaFUGR_Count_N_Low(), row, styleCellName);

		chckEstimateSheetCellsValue(5, processedReq.getDumaPROG_Count_N_High(), row, styleCellName);
		chckEstimateSheetCellsValue(6, processedReq.getDumaPROG_Count_N_Medium(), row, styleCellName);
		chckEstimateSheetCellsValue(7, processedReq.getDumaPROG_Count_N_Low(), row, styleCellName);

		chckEstimateSheetCellsValue(8, processedReq.getDumaCLAS_Count_N_High(), row, styleCellName);
		chckEstimateSheetCellsValue(9, processedReq.getDumaCLAS_Count_N_Medium(), row, styleCellName);
		chckEstimateSheetCellsValue(10, processedReq.getDumaCLAS_Count_N_Low(), row, styleCellName);

		chckEstimateSheetCellsValue(11, processedReq.getDumaFORM_Count_N_High(), row, styleCellName);
		chckEstimateSheetCellsValue(12, processedReq.getDumaFORM_Count_N_Medium(), row, styleCellName);
		chckEstimateSheetCellsValue(13, processedReq.getDumaFORM_Count_N_Low(), row, styleCellName);

		chckEstimateSheetCellsValue(14, processedReq.getDumaENH_Count_N_High(), row, styleCellName);
		chckEstimateSheetCellsValue(15, processedReq.getDumaENH_Count_N_Medium(), row, styleCellName);
		chckEstimateSheetCellsValue(16, processedReq.getDumaENH_Count_N_Low(), row, styleCellName);

		chckEstimateSheetCellsValue(17, processedReq.getDumaWDYN_Count_N_High(), row, styleCellName);
		chckEstimateSheetCellsValue(18, processedReq.getDumaWDYN_Count_N_Medium(), row, styleCellName);
		chckEstimateSheetCellsValue(19, processedReq.getDumaWDYN_Count_N_Low(), row, styleCellName);

		chckEstimateSheetCellsValue(20, processedReq.getDumaFUGS_Count_N_High(), row, styleCellName);
		chckEstimateSheetCellsValue(21, processedReq.getDumaFUGS_Count_N_Medium(), row, styleCellName);
		chckEstimateSheetCellsValue(22, processedReq.getDumaFUGS_Count_N_Low(), row, styleCellName);

		chckEstimateSheetCellsValue(23, processedReq.getDumaLSMW_Count_N_High(), row, styleCellName);
		chckEstimateSheetCellsValue(24, processedReq.getDumaLSMW_Count_N_Medium(), row, styleCellName);
		chckEstimateSheetCellsValue(25, processedReq.getDumaLSMW_Count_N_Low(), row, styleCellName);

		chckEstimateSheetCellsValue(26, processedReq.getDumaUSEREXIT_Count_N_High(), row, styleCellName);
		chckEstimateSheetCellsValue(27, processedReq.getDumaUSEREXIT_Count_N_Medium(), row, styleCellName);
		chckEstimateSheetCellsValue(28, processedReq.getDumaUSEREXIT_Count_N_Low(), row, styleCellName);
	}

	public void downloadEstimateSheet3(ProcessedEstimates processedReq, SXSSFWorkbook workbookTemp,
			XSSFCellStyle styleCellName) {
		XSSFSheet sheet = workbookTemp.getXSSFWorkbook().getSheetAt(3);
		Row row = sheet.getRow(4);
		setObjectCountsSheet2AndSheet3(processedReq, sheet, styleCellName);

		for (int i = 2; i < 29; i++) {
			if (row.getCell(i).getCellType() != HSSFCell.CELL_TYPE_BLANK) {
				row.getCell(i).setCellType(HSSFCell.CELL_TYPE_BLANK);
			}
		}

		chckEstimateSheetCellsValue(4, processedReq.getDumaFUGR_Count_Y_Low(), row, styleCellName);
		chckEstimateSheetCellsValue(7, processedReq.getDumaPROG_Count_Y_Low(), row, styleCellName);
		chckEstimateSheetCellsValue(10, processedReq.getDumaCLAS_Count_Y_Low(), row, styleCellName);
		chckEstimateSheetCellsValue(13, processedReq.getDumaFUGS_Count_Y_Low(), row, styleCellName);
	}

	public void setObjectCountsSheet2AndSheet3(ProcessedEstimates processedReq, XSSFSheet sheet,
			XSSFCellStyle styleCellName) {
		Row row = sheet.getRow(3);

		for (int i = 2; i < 27; i++) {
			if (row.getCell(i).getCellType() != HSSFCell.CELL_TYPE_BLANK) {
				row.getCell(i).setCellType(HSSFCell.CELL_TYPE_BLANK);
			}
		}

		chckEstimateSheetCellsValue(2, processedReq.getDumaFUGR_Count(), row, styleCellName);
		chckEstimateSheetCellsValue(5, processedReq.getDumaPROG_Count(), row, styleCellName);
		chckEstimateSheetCellsValue(8, processedReq.getDumaCLAS_Count(), row, styleCellName);
		chckEstimateSheetCellsValue(11, processedReq.getDumaFORM_Count(), row, styleCellName);
		chckEstimateSheetCellsValue(14, processedReq.getDumaENH_Count(), row, styleCellName);
		chckEstimateSheetCellsValue(17, processedReq.getDumaWDYN_Count(), row, styleCellName);
		chckEstimateSheetCellsValue(20, processedReq.getDumaFUGS_Count(), row, styleCellName);
		chckEstimateSheetCellsValue(23, processedReq.getDumaLSMW_Count(), row, styleCellName);
		chckEstimateSheetCellsValue(26, processedReq.getDumaUSEREXIT_Count(), row, styleCellName);
	}

	public void chckEstimateSheetCellsValue(int i, Integer countValue, Row row, XSSFCellStyle styleCellName) {
		styleCellName.setBorderRight(BorderStyle.THIN);
		styleCellName.setRightBorderColor(IndexedColors.BLACK.getIndex());
		styleCellName.setBorderLeft(BorderStyle.THIN);
		styleCellName.setLeftBorderColor(IndexedColors.BLACK.getIndex());
		styleCellName.setBorderTop(BorderStyle.THIN);
		styleCellName.setTopBorderColor(IndexedColors.BLACK.getIndex());
		styleCellName.setBorderBottom(BorderStyle.THIN);
		styleCellName.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		styleCellName.setAlignment(HorizontalAlignment.CENTER);

		Cell valueCell = row.getCell(i);

		if (countValue != null && countValue != 0)
			valueCell.setCellValue(countValue);
		else
			valueCell.setCellType(HSSFCell.CELL_TYPE_BLANK);

		valueCell.setCellStyle(styleCellName);
	}

	@RequestMapping(value = "/poc/uploadEstimatesFile/{requestId}", method = RequestMethod.POST)
	public String uploadEstimatesFilePOC(@PathVariable("requestId") long requestId,
			final RedirectAttributes redirectAttributes, Model model, final HttpSession session,
			final HttpServletRequest request, @RequestParam("feFile") MultipartFile[] file) throws Exception {
		try {
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestId));
			RequestID_Validator_Utility.chckReqIdPOC(reqIDValid.getPOCName(reqIDValid.getRequestInv(requestId)),
					getPrincipal());

			final RequestForm requestForm = getRequestDetails().getRequestObj(requestId);
			final String clientName = requestForm.getClientName();
			final String filePath = HANAUtility.getEstimatesFileUploadPath(clientName, requestId);

			// Writing Estimates File at Server Location
			logger.info("File Upload Starts ...");
			finalFileUpload.writeFile(requestId, clientName, filePath, file);
			logger.info("File Upload Successfull !!!");

			// Updating Database with Estimate Values Changed by POC
			logger.info("Writing to DB Starts ...");
			inputEstimatesFile(requestId);
			logger.info("DB is sucessfully updated !!!");

			// Updating POC Status, Sub-Status and Request Status
			String POC_Status = "Completed_POC";
			String POC_Comment = "Estimation File uploaded by POC. Processing from POC is completed.";
			String toolName = (String) session.getAttribute("tool");

			getRequestInventorydao().updateSatusPOC(requestId, getPrincipal(), toolName, POC_Status, POC_Comment,
					Hana_Profiler_Constant.REQ_SS_COMPLETED, Hana_Profiler_Constant.POC_UPLOAD_ESTIMATES_SUCC);
			getRequestInventorydao().updateSatus(requestId, Hana_Profiler_Constant.HANAREFININGCOMPLETED,
					getPrincipal(), Hana_Profiler_Constant.POC_UPLOAD_ESTIMATES_SUCC, toolName);

			// Sending Email on Successful Upload of Estimates Report
			try {
				sendEmailForEstimatesFileUpload(requestId, request, "Successful Upload of Estimates Report by POC",
						session);
			} catch (Exception e) {
				logger.error("Error while sending Email");
				logger.error("Error !!! " + e);
			}

			return "redirect:/poc/pocDashBoard";
		} catch (ReqIDNotValidException ex) {
			model.addAttribute("errorMsg", ex.getMessage());
			return "errors";
		} catch (UploadFilesNotValidException ex) {
			redirectAttributes.addFlashAttribute("errorMsg", "The filename is not correct.");
			return "redirect:/poc/pocUploadFE/" + requestId;
		} catch (Exception ex) {
			logger.error("Error while uploading and updating estimates in DB !!! " + ex.getStackTrace().toString());

			// Sending Email on Failure of Upload of Estimates Report
			try {
				sendEmailForEstimatesFileUpload(requestId, request, "Upload of Estimates Report by POC Fails", session);
			} catch (Exception e) {
				logger.error("Error while sending Email");
				logger.error("Error !!! " + e);
			}
			return "redirect:/poc/pocDashBoard";
		}
	}

	public void inputEstimatesFile(Long requestId) throws Exception {
		logger.info("Reading Estimates File after Manipulation by POC Starts ...");
		final RequestForm requestForm = getRequestDetails().getRequestObj(requestId);

		try {
			logger.info("Clearing the Estimates Table ...");
			getAutoHANA().clearEstimatesTable(requestId);
		} catch (Exception e) {
			logger.error("Exception while Clearing Estimates Table " + e.getStackTrace());
			throw new Exception();
		}

		String rootPath = HANAUtility.getEstimatesFileUploadPath(requestForm.getClientName(), requestId);
		File folder = new File(rootPath);
		File[] listOfFiles = folder.listFiles();

		for (File file : listOfFiles) {
			FileUtility.checkFileSize(file);
			if (file.isFile()) {
				try {
					String retrievedcompleteFilePath = rootPath + "\\" + file.getName();
					logger.info("Retrieved Complete FilePath for Estimates File");

					String comment = readEstimationSheetData(retrievedcompleteFilePath, requestId, requestForm);
					logger.info(comment);

				} catch (Exception e) {
					logger.error("Error while Writing Estimates File to DB " + e);
					throw new Exception();
				}
			}
		}
	}

	public String readEstimationSheetData(final String path, final long requestId, RequestForm requestForm)
			throws Exception {
		String comment = "";
		List<String> sheetNameList = new ArrayList<>();
		InputStream sheetData = null;
		try {
			OPCPackage pkg = OPCPackage.open(new FileInputStream(path));
			XSSFReader r = new XSSFReader(pkg);
			Iterator<InputStream> sheets = r.getSheetsData();

			if (sheets instanceof XSSFReader.SheetIterator) {
				XSSFReader.SheetIterator sheetiterator = (XSSFReader.SheetIterator) sheets;
				while (sheetiterator.hasNext()) {
					sheetData = sheetiterator.next();
					sheetNameList.add(sheetiterator.getSheetName());
				}
			}

			Map<String, Double> estimatesMandatoryManMap = null;
			Map<String, Double> estimatesAutoManMap = null;
			Map<String, Double> estimatesUsedManualMap = null;
			Map<String, Double> estimatesUsedAutoMap = null;

			if (sheetNameList != null) {
				for (String sheetName : sheetNameList) {
					if (sheetName != null && sheetName.equals("Mandatory Manual")) {
						estimatesMandatoryManMap = readingSheetMandatoryManAndUsedManManual(sheetName, path);
					} else if (sheetName != null && sheetName.equals("Mandatory Automation")) {
						estimatesAutoManMap = readingSheetMandatoryAutoAndUsed(sheetName, path);
					} else if (sheetName != null && sheetName.equals("Used_Mandatory Manual")) {
						estimatesUsedManualMap = readingSheetMandatoryManAndUsedManManual(sheetName, path);
					} else if (sheetName != null && sheetName.equals("Used_Mandatory Automation")) {
						estimatesUsedAutoMap = readingSheetMandatoryAutoAndUsed(sheetName, path);
					}
				}
			}

			ProcessedEstimates processedEst = setEstimateCounts(estimatesMandatoryManMap, estimatesAutoManMap,
					estimatesUsedManualMap, estimatesUsedAutoMap);
			processedEst.setScope("HANA");
			processedEst.setRequestID(requestId);

			getProcessedEstimates().insertEstimatesData(processedEst);

			comment = "Reading of Excel File Successfull !!!";
		} catch (Exception e) {
			comment = "Reading of Estimates File Fails !!! ";
			logger.error(comment + e);
			throw new Exception();
		}

		return comment;
	}

	public Map<String, Double> readingSheetMandatoryAutoAndUsed(String sheetName, String path) throws Exception {
		final File file = new File(path);
		InputStream inputStream = new FileInputStream(file);
		Map<String, Double> estimatesMap = new HashMap<>();
		try (@SuppressWarnings("deprecation")
		StreamingReader manualMandatory_Used_Reader = StreamingReader.builder().rowCacheSize(5).bufferSize(1024)
				.sheetName(sheetName).read(inputStream)) {

			logger.info("Reading Mandatory Automation & Used_Mandatory Automation Sheets Starts ...");
			int counter_DMA_DUMA = 2;
			int counter_DMA_DUMA_Counts = 2;

			Row row1 = null;
			Row row2 = null;

			if (manualMandatory_Used_Reader != null) {
				for (Row row : manualMandatory_Used_Reader) {
					if (row.getRowNum() == 1) {
						row1 = row;
					} else if (row.getRowNum() == 2) {
						row2 = row;
					} else if (row.getRowNum() == 4) {
						for (Cell c : row) {
							if (counter_DMA_DUMA_Counts == 29) {
								break;
							} else if (c.getColumnIndex() == 0 || c.getColumnIndex() == 1) {
								continue;
							} else if (row.getCell(c.getColumnIndex()) != null) {
								estimatesMap.put(
										row1.getCell(counter_DMA_DUMA).getStringCellValue().trim() + "_"
												+ row2.getCell(counter_DMA_DUMA_Counts).getStringCellValue().trim(),
										(row.getCell(counter_DMA_DUMA_Counts) == null
												|| row.getCell(counter_DMA_DUMA_Counts).getStringCellValue().trim()
														.equals("")) ? 0
																: row.getCell(counter_DMA_DUMA_Counts)
																		.getNumericCellValue());
							}

							counter_DMA_DUMA_Counts++;
							if (counter_DMA_DUMA_Counts == (counter_DMA_DUMA + 3)) {
								counter_DMA_DUMA += 3;
							}
						}
						break;
					}
				}
			}

			logger.info("Reading Mandatory Automation & Used_Mandatory Automation Sheets Completes ...");
		} catch (Exception e) {
			logger.error("Failure while reading Estimates File !!!" + e);
			throw new Exception();
		}

		return estimatesMap;
	}

	public Map<String, Double> readingSheetMandatoryManAndUsedManManual(String sheetName, String path)
			throws Exception {
		final File file = new File(path);
		InputStream inputStream = new FileInputStream(file);
		Map<String, Double> estimatesMap = new HashMap<>();
		try (@SuppressWarnings("deprecation")
		StreamingReader manualMandatory_Used_Reader = StreamingReader.builder().rowCacheSize(5).bufferSize(1024)
				.sheetName(sheetName).read(inputStream)) {

			logger.info("Reading Mandatory Manual & Used_Mandatory Manual Sheets Starts ...");

			int counter_DMA_DUMA = 2;
			int counter_DMA_DUMA_Counts = 2;

			Row row1 = null;
			Row row2 = null;

			if (manualMandatory_Used_Reader != null) {
				for (Row row : manualMandatory_Used_Reader) {
					if (row.getRowNum() == 1) {
						row1 = row;
					} else if (row.getRowNum() == 2) {
						row2 = row;
					} else if (row.getRowNum() == 3) {
						for (Cell c : row) {
							if (counter_DMA_DUMA == 29) {
								break;
							} else if (c.getColumnIndex() == 0 || c.getColumnIndex() == 1) {
								continue;
							} else if (row.getCell(c.getColumnIndex()) != null) {
								estimatesMap.put(row1.getCell(counter_DMA_DUMA).getStringCellValue().trim(),
										(row.getCell(counter_DMA_DUMA) == null
												|| row.getCell(counter_DMA_DUMA).getStringCellValue().trim().equals(""))
														? 0
														: row.getCell(counter_DMA_DUMA).getNumericCellValue());
							}

							counter_DMA_DUMA += 3;
						}

						counter_DMA_DUMA = 2;
					} else if (row.getRowNum() == 4) {
						for (Cell c : row) {
							if (counter_DMA_DUMA_Counts == 29) {
								break;
							} else if (c.getColumnIndex() == 0 || c.getColumnIndex() == 1) {
								continue;
							} else if (row.getCell(c.getColumnIndex()) != null) {
								estimatesMap.put(
										row1.getCell(counter_DMA_DUMA).getStringCellValue().trim() + "_"
												+ row2.getCell(counter_DMA_DUMA_Counts).getStringCellValue().trim(),
										(row.getCell(counter_DMA_DUMA_Counts) == null
												|| row.getCell(counter_DMA_DUMA_Counts).getStringCellValue().trim()
														.equals("")) ? 0
																: row.getCell(counter_DMA_DUMA_Counts)
																		.getNumericCellValue());
							}

							counter_DMA_DUMA_Counts++;
							if (counter_DMA_DUMA_Counts == (counter_DMA_DUMA + 3)) {
								counter_DMA_DUMA += 3;
							}
						}
						break;
					}
				}
			}

			logger.info("Reading Mandatory Manual & Used_Mandatory Manual Sheets Completes ...");
		} catch (Exception e) {
			logger.error("Failure while reading Estimates File !!!" + e);
			throw new Exception();
		}

		return estimatesMap;
	}

	public ProcessedEstimates setEstimateCounts(Map<String, Double> estimatesManualMap,
			Map<String, Double> estimatesAutoMap, Map<String, Double> estimatesManualUsedMap,
			Map<String, Double> estimatesAutoUsedMap) throws NoSuchMethodException, SecurityException {
		ProcessedEstimates processedEst = new ProcessedEstimates();

		processedEst.setDmaFUGR_Count(estimatesManualMap.get("Function Groups").intValue());
		processedEst.setDmaPROG_Count(estimatesManualMap.get("Reports").intValue());
		processedEst.setDmaCLAS_Count(estimatesManualMap.get("Class").intValue());
		processedEst.setDmaFORM_Count(estimatesManualMap.get("Forms").intValue());
		processedEst.setDmaENH_Count(estimatesManualMap.get("Enhancements").intValue());
		processedEst.setDmaWDYN_Count(estimatesManualMap.get("Web-Dynpro").intValue());
		processedEst.setDmaFUGS_Count(estimatesManualMap.get("FUGS").intValue());
		processedEst.setDmaLSMW_Count(estimatesManualMap.get("LSMW").intValue());
		processedEst.setDmaUSEREXIT_Count(estimatesManualMap.get("UserExit").intValue());

		processedEst.setDmaFUGR_Count_N_High(estimatesManualMap.get("Function Groups_H").intValue());
		processedEst.setDmaFUGR_Count_N_Medium(estimatesManualMap.get("Function Groups_M").intValue());
		processedEst.setDmaFUGR_Count_N_Low(estimatesManualMap.get("Function Groups_L").intValue());

		processedEst.setDmaPROG_Count_N_High(estimatesManualMap.get("Reports_H").intValue());
		processedEst.setDmaPROG_Count_N_Medium(estimatesManualMap.get("Reports_M").intValue());
		processedEst.setDmaPROG_Count_N_Low(estimatesManualMap.get("Reports_L").intValue());

		processedEst.setDmaCLAS_Count_N_High(estimatesManualMap.get("Class_H").intValue());
		processedEst.setDmaCLAS_Count_N_Medium(estimatesManualMap.get("Class_M").intValue());
		processedEst.setDmaCLAS_Count_N_Low(estimatesManualMap.get("Class_L").intValue());

		processedEst.setDmaFORM_Count_N_High(estimatesManualMap.get("Forms_H").intValue());
		processedEst.setDmaFORM_Count_N_Medium(estimatesManualMap.get("Forms_M").intValue());
		processedEst.setDmaFORM_Count_N_Low(estimatesManualMap.get("Forms_L").intValue());

		processedEst.setDmaENH_Count_N_High(estimatesManualMap.get("Enhancements_H").intValue());
		processedEst.setDmaENH_Count_N_Medium(estimatesManualMap.get("Enhancements_M").intValue());
		processedEst.setDmaENH_Count_N_Low(estimatesManualMap.get("Enhancements_L").intValue());

		processedEst.setDmaWDYN_Count_N_High(estimatesManualMap.get("Web-Dynpro_H").intValue());
		processedEst.setDmaWDYN_Count_N_Medium(estimatesManualMap.get("Web-Dynpro_M").intValue());
		processedEst.setDmaWDYN_Count_N_Low(estimatesManualMap.get("Web-Dynpro_L").intValue());

		processedEst.setDmaFUGS_Count_N_High(estimatesManualMap.get("FUGS_H").intValue());
		processedEst.setDmaFUGS_Count_N_Medium(estimatesManualMap.get("FUGS_M").intValue());
		processedEst.setDmaFUGS_Count_N_Low(estimatesManualMap.get("FUGS_L").intValue());

		processedEst.setDmaLSMW_Count_N_High(estimatesManualMap.get("LSMW_H").intValue());
		processedEst.setDmaLSMW_Count_N_Medium(estimatesManualMap.get("LSMW_M").intValue());
		processedEst.setDmaLSMW_Count_N_Low(estimatesManualMap.get("LSMW_L").intValue());

		processedEst.setDmaUSEREXIT_Count_N_High(estimatesManualMap.get("UserExit_H").intValue());
		processedEst.setDmaUSEREXIT_Count_N_Medium(estimatesManualMap.get("UserExit_M").intValue());
		processedEst.setDmaUSEREXIT_Count_N_Low(estimatesManualMap.get("UserExit_L").intValue());

		processedEst.setDmaFUGR_Count_Y_Low(estimatesAutoMap.get("Function Groups_L").intValue());
		processedEst.setDmaFUGS_Count_Y_Low(estimatesAutoMap.get("FUGS_L").intValue());
		processedEst.setDmaCLAS_Count_Y_Low(estimatesAutoMap.get("Class_L").intValue());
		processedEst.setDmaPROG_Count_Y_Low(estimatesAutoMap.get("Reports_L").intValue());

		processedEst.setDumaFUGR_Count(estimatesManualUsedMap.get("Function Groups").intValue());
		processedEst.setDumaPROG_Count(estimatesManualUsedMap.get("Reports").intValue());
		processedEst.setDumaCLAS_Count(estimatesManualUsedMap.get("Class").intValue());
		processedEst.setDumaFORM_Count(estimatesManualUsedMap.get("Forms").intValue());
		processedEst.setDumaENH_Count(estimatesManualUsedMap.get("Enhancements").intValue());
		processedEst.setDumaWDYN_Count(estimatesManualUsedMap.get("Web-Dynpro").intValue());
		processedEst.setDumaFUGS_Count(estimatesManualUsedMap.get("FUGS").intValue());
		processedEst.setDumaLSMW_Count(estimatesManualUsedMap.get("LSMW").intValue());
		processedEst.setDumaUSEREXIT_Count(estimatesManualUsedMap.get("UserExit").intValue());

		processedEst.setDumaFUGR_Count_N_High(estimatesManualUsedMap.get("Function Groups_H").intValue());
		processedEst.setDumaFUGR_Count_N_Medium(estimatesManualUsedMap.get("Function Groups_M").intValue());
		processedEst.setDumaFUGR_Count_N_Low(estimatesManualUsedMap.get("Function Groups_L").intValue());

		processedEst.setDumaPROG_Count_N_High(estimatesManualUsedMap.get("Reports_H").intValue());
		processedEst.setDumaPROG_Count_N_Medium(estimatesManualUsedMap.get("Reports_M").intValue());
		processedEst.setDumaPROG_Count_N_Low(estimatesManualUsedMap.get("Reports_L").intValue());

		processedEst.setDumaCLAS_Count_N_High(estimatesManualUsedMap.get("Class_H").intValue());
		processedEst.setDumaCLAS_Count_N_Medium(estimatesManualUsedMap.get("Class_M").intValue());
		processedEst.setDumaCLAS_Count_N_Low(estimatesManualUsedMap.get("Class_L").intValue());

		processedEst.setDumaFORM_Count_N_High(estimatesManualUsedMap.get("Forms_H").intValue());
		processedEst.setDumaFORM_Count_N_Medium(estimatesManualUsedMap.get("Forms_M").intValue());
		processedEst.setDumaFORM_Count_N_Low(estimatesManualUsedMap.get("Forms_L").intValue());

		processedEst.setDumaENH_Count_N_High(estimatesManualUsedMap.get("Enhancements_H").intValue());
		processedEst.setDumaENH_Count_N_Medium(estimatesManualUsedMap.get("Enhancements_M").intValue());
		processedEst.setDumaENH_Count_N_Low(estimatesManualUsedMap.get("Enhancements_L").intValue());

		processedEst.setDumaWDYN_Count_N_High(estimatesManualUsedMap.get("Web-Dynpro_H").intValue());
		processedEst.setDumaWDYN_Count_N_Medium(estimatesManualUsedMap.get("Web-Dynpro_M").intValue());
		processedEst.setDumaWDYN_Count_N_Low(estimatesManualUsedMap.get("Web-Dynpro_L").intValue());

		processedEst.setDumaFUGS_Count_N_High(estimatesManualUsedMap.get("FUGS_H").intValue());
		processedEst.setDumaFUGS_Count_N_Medium(estimatesManualUsedMap.get("FUGS_M").intValue());
		processedEst.setDumaFUGS_Count_N_Low(estimatesManualUsedMap.get("FUGS_L").intValue());

		processedEst.setDumaLSMW_Count_N_High(estimatesManualUsedMap.get("LSMW_H").intValue());
		processedEst.setDumaLSMW_Count_N_Medium(estimatesManualUsedMap.get("LSMW_M").intValue());
		processedEst.setDumaLSMW_Count_N_Low(estimatesManualUsedMap.get("LSMW_L").intValue());

		processedEst.setDumaUSEREXIT_Count_N_High(estimatesManualUsedMap.get("UserExit_H").intValue());
		processedEst.setDumaUSEREXIT_Count_N_Medium(estimatesManualUsedMap.get("UserExit_M").intValue());
		processedEst.setDumaUSEREXIT_Count_N_Low(estimatesManualUsedMap.get("UserExit_L").intValue());

		processedEst.setDumaFUGR_Count_Y_Low(estimatesAutoUsedMap.get("Function Groups_L").intValue());
		processedEst.setDumaFUGS_Count_Y_Low(estimatesAutoUsedMap.get("FUGS_L").intValue());
		processedEst.setDumaCLAS_Count_Y_Low(estimatesAutoUsedMap.get("Class_L").intValue());
		processedEst.setDumaPROG_Count_Y_Low(estimatesAutoUsedMap.get("Reports_L").intValue());

		return processedEst;
	}

	protected void sendEmailForEstimatesFileUpload(long requestId, HttpServletRequest request,
			String successOrFailureMessage, HttpSession session) {
		final RequestInventory requestInventory = getClientRequestInventoryDAO().getRequestInventory(requestId);

		String requestUID = requestInventory.getREQUEST_ID_UI();
		String emailId = requestInventory.getCreatorUser();

		Set<String> emailData = new HashSet<String>();
		Set<String> emailCc = new HashSet<String>();
		SendEmail email = new SendEmail();
		email.setMailFrom("IDC_SAPUpgrade_Sales@accenture.com");
		emailCc.add("IDC_SAPUpgrade_Sales@accenture.com");

		if (successOrFailureMessage.equals("Successful Upload of Estimates Report by POC")) {
			emailData.add(emailId);
			emailCc.add(getEmailIDDao().getEmail(getPrincipal()));
			emailCc.add("IDC_SAPUpgrade_Sales@accenture.com");
			email.setMailSubject("Request ID : " + requestUID + " - " + successOrFailureMessage);
			email.setMailBody("\n\nDear " + emailId + ",\n\nThe Estimates Report for your Request ID: " + requestUID
					+ " has been successfully uploaded by POC. Please download the Estimates Report."
					+ "\n\n\nRegards,\nHana Technical Team");
		} else {
			emailData.add(getEmailIDDao().getEmail(getPrincipal()));
			emailCc.add("IDC_SAPUpgrade_Sales@accenture.com");
			email.setMailSubject("Request ID : " + requestUID + " - " + successOrFailureMessage);
			email.setMailBody("\n\n Dear " + getPrincipal() + ",\n\nThe upload of the Estimates Report"
					+ " is failed. Please check the file data." + "\n\n\nRegards,\nHana Technical Team");
		}

		email.setMailTo(emailData);
		email.setMailCC(emailCc);

		email.emailSend(email, request, session);
	}

	protected void sendEmailForRomEstimatesFileUpload(long requestId, HttpServletRequest request,
			String successOrFailureMessage, HttpSession session) {
		final RequestInventory requestInventory = getClientRequestInventoryDAO().getRequestInventory(requestId);

		String requestUID = requestInventory.getREQUEST_ID_UI();
		String emailId = requestInventory.getCreatorUser();

		Set<String> emailData = new HashSet<String>();
		Set<String> emailCc = new HashSet<String>();
		SendEmail email = new SendEmail();
		email.setMailFrom("IDC_SAPUpgrade_Sales@accenture.com");
		emailCc.add("IDC_SAPUpgrade_Sales@accenture.com");

		if (successOrFailureMessage.equals("Successful Upload of ROM Estimates Report by POC")) {
			emailData.add(emailId);
			emailCc.add(getEmailIDDao().getEmail(getPrincipal()));
			emailCc.add("IDC_SAPUpgrade_Sales@accenture.com");
			email.setMailSubject("Request ID : " + requestUID + " - " + successOrFailureMessage);
			email.setMailBody("\n\nDear " + emailId + ",\n\nThe ROM Estimates Report for your Request ID: " + requestUID
					+ " has been successfully uploaded by POC. Please download the ROM Estimates Report."
					+ "\n\n\nRegards,\nHana Technical Team");
		} else {
			emailData.add(getEmailIDDao().getEmail(getPrincipal()));
			emailCc.add("IDC_SAPUpgrade_Sales@accenture.com");
			email.setMailSubject("Request ID : " + requestUID + " - " + successOrFailureMessage);
			email.setMailBody("\n\n Dear " + getPrincipal() + ",\n\nThe upload of the Estimates Report"
					+ " is failed. Please check the file data." + "\n\n\nRegards,\nHana Technical Team");
		}

		email.setMailTo(emailData);
		email.setMailCC(emailCc);

		email.emailSend(email, request, session);
	}

	@RequestMapping(value = "poc/pocUploadRE/{requestID}", method = RequestMethod.GET)
	public String pocUploadRE(@PathVariable("requestID") long requestID, Model model, HttpServletRequest request,
			HttpServletResponse response, HttpSession session) throws Exception {

		String toolName = (String) session.getAttribute("tool");
		model.addAttribute("requestID", requestID);
		model.addAttribute("romEstimateSize", File_Size_Constant.ROM_SIZE);
		Boolean reFlag = false;

		/* flag updation code goes below */

		return "poc/pocUploadRE";
	}
	@RequestMapping(value = "/poc/historicData", method = RequestMethod.GET)
	public String readHistoricFormData(HttpServletRequest request,
			HttpSession session, RedirectAttributes redirectAttributes, Model model) throws Exception {
		try{
	String filePath = "C:\\Softwares\\apache-tomcat-9.0.37-windows-x64\\apache-tomcat-9.0.37\\tempFiles\\historicFormData\\Client Form details Template.xlsx";
		File file=new File(filePath);
		InputStream inputStream=new FileInputStream(file);
		RequestFormModel requestFormModel = null;
		ArrayList<String> scpList = null;
		String fileName=file.getName();
		List<String> siaReqIDsList = new ArrayList<>();
		
			StreamingReader reader=StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0).read(inputStream);
			for (Row row : reader) {
				if (row.getRowNum() > 3) {
					scpList = new ArrayList<>();
					requestFormModel = new RequestFormModel();
					requestFormModel.setClientName(row.getCell(0)==null ?"": row.getCell(0).getStringCellValue().trim());
					requestFormModel.setClientTeamDetails(row.getCell(1)==null?"":row.getCell(1).getStringCellValue().trim());
					requestFormModel.setIndustryGroup(row.getCell(2)==null?"":row.getCell(2).getStringCellValue().trim());
					requestFormModel.setIndustrySubGroup(row.getCell(3)==null?"":row.getCell(3).getStringCellValue().trim());
					requestFormModel.setProjectPocId(row.getCell(4)==null?"":row.getCell(4).getStringCellValue().trim());
					requestFormModel.setClienttype(row.getCell(5)==null?"":row.getCell(5).getStringCellValue().trim());
					requestFormModel.setSourceVersion(row.getCell(6)==null ?"": row.getCell(6).getStringCellValue().trim());
					requestFormModel.setTargetVersion(row.getCell(7)==null?"":row.getCell(7).getStringCellValue().trim());
					requestFormModel.setDbSize(row.getCell(8)==null?"":row.getCell(8).getStringCellValue().trim());
					if(row.getCell(9).getStringCellValue().trim().contains("1")) {
						scpList.add("SOH");
					}
					if(row.getCell(10).getStringCellValue().trim().contains("1")) {
						scpList.add("S4Technical");
					}
					if(row.getCell(11).getStringCellValue().trim().contains("1")) {
						scpList.add("fiori");
					}
					if(row.getCell(12).getStringCellValue().trim().contains("1")) {
						scpList.add("Upgrade");
					}
					if(row.getCell(13).getStringCellValue().trim().contains("1")) {
						scpList.add("UI5");
					}
					if(row.getCell(14).getStringCellValue().trim().contains("1")) {
						scpList.add("RFP");
					}
					if(row.getCell(15).getStringCellValue().trim().contains("1")) {
						scpList.add("OSMigration");
					}
					if(row.getCell(16).getStringCellValue().trim().contains("1")) {
						scpList.add("EXT");
					}
					if(row.getCell(17).getStringCellValue().trim().contains("1")) {
						scpList.add("SIA");
					}
					if("CREATED".equalsIgnoreCase(row.getCell(18).getStringCellValue().trim())) {
						requestFormModel.setWBSE("CREATED");
						requestFormModel.setWbsCode(row.getCell(19)==null?"":row.getCell(19).getStringCellValue().trim());
					}else {
						requestFormModel.setWBSE("REQUESTED");
					}
					String wbs=row.getCell(19)==null?"":row.getCell(19).getStringCellValue().trim();
					requestFormModel.setUnicodeCompliant(row.getCell(20)==null?"":row.getCell(20).getStringCellValue().trim());
					requestFormModel.setSystemId(row.getCell(21)==null?"":row.getCell(21).getStringCellValue().trim());
					requestFormModel.setAppServer(row.getCell(22)==null?"":row.getCell(22).getStringCellValue().trim());
					requestFormModel.setSupportedAtci(row.getCell(23)==null?"":row.getCell(23).getStringCellValue().trim());
					requestFormModel.setProjectName(row.getCell(24)==null?"":row.getCell(24).getStringCellValue().trim());
					requestFormModel.setSystemType(row.getCell(25)==null?"":row.getCell(25).getStringCellValue().trim());
					requestFormModel.setCustomerNamespace(row.getCell(26)==null?"":row.getCell(26).getStringCellValue().trim());
					requestFormModel.setSapClientId(row.getCell(27)==null?"":row.getCell(27).getStringCellValue().trim());
					requestFormModel.setInstalNo(row.getCell(28)==null?"":row.getCell(28).getStringCellValue().trim());
					requestFormModel.setDatabaseDB(row.getCell(29)==null?"":row.getCell(29).getStringCellValue().trim());
					requestFormModel.setHost(row.getCell(30)==null?"":row.getCell(30).getStringCellValue().trim());
					requestFormModel.setEnableUnicode(row.getCell(31)==null?"":row.getCell(31).getStringCellValue().trim());
					requestFormModel.setSap_NonSAPcomponents(row.getCell(32)==null?"":row.getCell(32).getStringCellValue().trim());
					requestFormModel.setPocName(row.getCell(33)==null?"":row.getCell(33).getStringCellValue().trim());
					requestFormModel.setDealSize(row.getCell(34)==null?"":row.getCell(34).getStringCellValue().trim());
					requestFormModel.setCurrencyType(row.getCell(35)==null?"":row.getCell(35).getStringCellValue().trim());
					requestFormModel.setMarketUnit(row.getCell(37)==null?"":row.getCell(37).getStringCellValue().trim());
					String finalFileName = row.getCell(38)==null?"":row.getCell(38).getStringCellValue().trim();
					String siaFileName = row.getCell(39)==null?"":row.getCell(39).getStringCellValue().trim();
					requestFormModel.setScope(scpList);
					RequestForm requestForm = prepareRequestFormModelHistoricData(requestFormModel,scpList);
					final String userName = row.getCell(36)==null?"":row.getCell(36).getStringCellValue().trim();
					requestForm.setToolName("services");

					String requestIdUi = requestIdUIGenerator(requestForm);
					requestForm.setREQUEST_ID_UI(requestIdUi);

					// For Saving the request Form in DataBase
					logger.info("Before the process of saving the form in the DB ...");
					getRequestDetails().saveHistoricRequestForm(requestForm, userName, "services");
					logger.info("Saved the form in the DB ...");
					getPocRequestMappingdao().addClientData(requestForm.getRequestID(), userName, requestIdUi, "services");
					Long requestID = getRequestDetails().getRequestID(requestIdUi);
					MultipartFile multipartFinalFile = null;
					if(StringUtils.isNotEmpty(finalFileName)) {
						multipartFinalFile = new MockMultipartFile(finalFileName, new FileInputStream(new File(HANAUtility.getHistoricFilePath()+File.separator+finalFileName)));
					logger.info("Historic Data :: Final File Name :: "+multipartFinalFile.getName());
					}
					MultipartFile multipartSiaFile = null;
					if(StringUtils.isNotEmpty(siaFileName)) {
						multipartSiaFile = new MockMultipartFile(siaFileName, new FileInputStream(new File(HANAUtility.getHistoricFilePath()+File.separator+siaFileName)));
					logger.info("Historic Data :: SIA File Name :: "+multipartSiaFile.getName());
					}
					migrationFilesProcessing(requestID, request, session, redirectAttributes, model, multipartFinalFile, multipartSiaFile, siaReqIDsList);
					
					}
			}
			
		} catch (Exception e) {
			//logger.error("Historic data read :: "+row.getCell(0).getStringCellValue().trim());
			logger.error("Historic data read :: ",e);
			model.addAttribute("fileException", "Data upload failed. Please check the error logs for more details.");
			return "poc/pocDashBoard";
		}finally {
			//IOUtils.closeQuietly(inputStream);
		}
		return "redirect:/poc/pocDashBoard";
	}

	
	
	
	private RequestForm prepareRequestFormModelHistoricData(RequestFormModel rfm, List<String> scpList) {
		boolean SOH = false, S4Functional = false, UPGRADE = false, S4Technical = false, Fiori = false, UI5 = false,
				RFP = false, SIA = false, BW = false, OSMIG = false, GRC = false;
		;
		boolean EXT = false;
		RequestForm rf = new RequestForm();

		rf.setClientName(rfm.getClientName());
		rf.setClientTeamDetails(rfm.getClientTeamDetails());
		rf.setClienttype(rfm.getClienttype());
		rf.setCurrencyType(rfm.getCurrencyType());
		rf.setCustomerNamespace(rfm.getCustomerNamespace());
		rf.setDatabaseDB(rfm.getDatabaseDB());
		rf.setDbSize(rfm.getDbSize());
		rf.setDealSize(rfm.getDealSize());
		if (rfm.getWBSE().equalsIgnoreCase("REQUESTED"))
			rf.setWbsCode("WBSE REQUESTED");
		else
			rf.setWbsCode(rfm.getWbsCode());
		rf.setSystemEnvt(rfm.getSystemEnvt());
		rf.setSystemId(rfm.getSystemId());
		rf.setSourceVersion(rfm.getSourceVersion());
		rf.setIndustryGroup(rfm.getIndustryGroup());
		rf.setIndustrySubGroup(rfm.getIndustrySubGroup());
		rf.setInstalNo(rfm.getInstalNo());
		rf.setAppServer(rfm.getAppServer());
		rf.setSupportedAtci(rfm.getSupportedAtci());
		rf.setNumberOfUsers(rfm.getNumberOfUsers());
		rf.setNumberOtherSystem(rfm.getNumberOtherSystem());
		rf.setNumberProduction(rfm.getNumberProduction());
		rf.setNumberQuality(rfm.getNumberQuality());
		rf.setNumberDevelopment(rfm.getNumberDevelopment());
		rf.setSandbox(rfm.getSandbox());
		rf.setPocName(rfm.getPocName());
		rf.setProjectName(rfm.getProjectName());
		rf.setProjectPocId(rfm.getProjectPocId());
		rf.setHost(rfm.getHost());
		rf.setEndDate(rfm.getEndDate());
		rf.setStartDate(rfm.getStartDate());
		rf.setUnicodeCompliant(rfm.getUnicodeCompliant());
		rf.setSap_NonSAPcomponents(rfm.getSap_NonSAPcomponents());
		rf.setSapClientId(rfm.getSapClientId());
		rf.setSystemType(rfm.getSystemType());
		rf.setTargetVersion(rfm.getTargetVersion());
		rf.setCVIT(false);
		rf.setWBSE(rfm.getWBSE());
		rf.setSrcOSVer(rfm.getSrcOSVer());
		rf.setTarOSVer(rfm.getTarOSVer());

		if (rfm.getUnicodeCompliant().equalsIgnoreCase("YES"))
			rf.setEnableUnicode("No");
		else
			rf.setEnableUnicode("Yes");

		rf.setScope(rfm.getScope());

		if (scpList.contains("SOH"))
			SOH = true;
		if (scpList.contains("S4Functional"))
			S4Functional = true;
		if (scpList.contains("Upgrade"))
			UPGRADE = true;
		if (scpList.contains("S4Technical"))
			S4Technical = true;
		if (scpList.contains("Fiori"))
			Fiori = true;
		if (scpList.contains("UI5"))
			UI5 = true;
		if (scpList.contains("RFP"))
			RFP = true;
		if (scpList.contains("SIA"))
			SIA = true;
		if (scpList.contains("OSMigration"))
			OSMIG = true;
		if (scpList.contains("BW"))
			BW = true;
		if (scpList.contains("GRC"))
			GRC = true;
		if (scpList.contains("EXT"))
			EXT = true;
		rf.setSOH(SOH);
		rf.setS4Functional(S4Functional);
		rf.setS4Technical(S4Technical);
		rf.setUPGRADE(UPGRADE);
		rf.setFiori(Fiori);
		rf.setUI5(UI5);
		rf.setRFP(RFP);
		rf.setSia(SIA);
		rf.setOsMig(OSMIG);
		rf.setGrc(GRC);
		rf.setBwTech(rfm.isBw_tech());
		rf.setBwUsage(rfm.isBw_use());
		rf.setEXT(EXT);
		rf.setMarketUnit(rfm.getMarketUnit());

		if (SIA) {
			if (rfm.getTargetVersion().startsWith("S/4HANA"))
				// SIA
				rf.setSecVer(rfm.getTargetVersion().split("S/4HANA")[1]);
			else
				rf.setSecVer("");
		}

		if (RFP) {
			rf.setValueRFP(rfm.getValueRFP());
		} else {
			rf.setValueRFP("NA");
		}

		if (Fiori) {
			rf.setCentral_embedded(rfm.getCentral_embedded());
			rf.setCentral_gateSystem(rfm.getCentral_gateSystem());
		} else {
			rf.setCentral_embedded("NA");
			rf.setCentral_gateSystem("NA");
		}

		if (UI5) {
			rf.setRfc(rfm.getRfc());
			rf.setAppName(rfm.getAppName());
			rf.setOldVersion(rfm.getOldVersion());
			rf.setNewVersion(rfm.getNewVersion());
		} else {
			rf.setRfc("NA");
			rf.setAppName("NA");
			rf.setOldVersion("NA");
			rf.setNewVersion("NA");
		}

		if (S4Functional) {
			rf.setSapInterface(rfm.getSapInterface());
			rf.setNon_sapInterface(rfm.getNon_sapInterface());
			rf.setSapModules(rfm.getSapModules());
			rf.setIndSolution(rfm.getIndSolution());
			rf.setSupportComponents(rfm.getSupportComponents());
			rf.setFioriSetup_apps(rfm.getFioriSetup_apps());
			rf.setSandbox_ID_instalNo(rfm.getSandbox_ID_instalNo());
			rf.setSandbox_sysId(rfm.getSandbox_sysId());
		} else {
			rf.setSapInterface("NA");
			rf.setNon_sapInterface("NA");
			rf.setSapModules("NA");
			rf.setIndSolution("NA");
			rf.setFioriSetup_apps("NA");
			rf.setSupportComponents("NA");
			rf.setSandbox_ID_instalNo("NA");
			rf.setSandbox_sysId("NA");
		}
		if (EXT) {
			rf.setLicenseSelect(rfm.getLicenseSelect());
			rf.setServiceProvider(rfm.getServiceProvider());
		} else {
			rf.setLicenseSelect("NA");
			rf.setServiceProvider("NA");
		}

		return rf;
	}
}
