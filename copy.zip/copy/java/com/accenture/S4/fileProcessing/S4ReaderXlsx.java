/*CR-No.    Desc     Date    Modified By
 * 
 * CR-26.0:- Make changes for Op-Code & show total scanned lines -05/09/17 -monika.mishra
 * 
 *  *CR-48:- Consolidated both the tool so that they can executed separately -monika.mishra
 *
 *DEF075: Impacted IDOC New Requirements -17/05/2019 -himani.malhotra

 * */

package com.accenture.S4.fileProcessing;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.util.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.S4.constant.S4HanaProfilerConstant;
import com.accenture.S4.models.S4AppendStructureAnalysis;
import com.accenture.S4.models.S4CloneIntermediate;
import com.accenture.S4.models.S4Detection;
import com.accenture.S4.models.S4ImpactedIDOC;
import com.accenture.S4.models.S4ImpactedSearchHelp;
import com.accenture.S4.models.S4ImpactedTables;
import com.accenture.S4.models.S4ImpactedTransaction;
import com.accenture.S4.models.S4InventoryList;
import com.accenture.S4.models.S4UsageAnalysis;
import com.accenture.client.model.Lsmw;
import com.accenture.client.model.UserExit;
import com.accenture.fileprocessing.PopulateHanaTables;
import com.accenture.reader.xlsx.ConsolidateReaderXlsx;
import com.monitorjbl.xlsx.StreamingReader;

/**
 * @author monika.mishra
 *
 */
public class S4ReaderXlsx extends ConsolidateReaderXlsx{

	final Logger logger = LoggerFactory.getLogger(S4ReaderXlsx.class);

	private PopulateHanaTables populateHanaTable;

	public void setPopulateHanaTable(PopulateHanaTables populateHanaTable) {
		this.populateHanaTable = populateHanaTable;
	}
	
	
	protected void addConsolidatedData(final String path, final long requestId, String toolName) throws Exception {
		File file = new File(path);
		InputStream inputStream = new FileInputStream(file);
		logger.info("populateHanaTable::::::" + populateHanaTable);
		int rowCount =populateHanaTable.getRowCount(requestId);

		String fileName = file.getName();
		try {
			List<S4Detection> s4DetectionList=new ArrayList<S4Detection>();
			
			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);

			for (Row r : reader) {
				if (r.getRowNum() > 0) {
					rowCount = rowCount + 1;
					logger.info(
							"File--" + fileName + "-----RowNum---" + r.getRowNum() + "Table Row Count---" + rowCount);

					// col25 & col 26
					
					s4DetectionList.add(getDetectionValueXlsx(r,requestId,fileName));
					
				}

			}
			logger.info("Detection count " + s4DetectionList.size());
			populateHanaTable.populateDataList(s4DetectionList);
			}
		finally {
			IOUtils.closeQuietly(inputStream);
		}
		
	}
	
	
	protected void addUserExitData(String filePath, long requestID) throws FileNotFoundException, SQLException {
	
		logger.info("populateHanaTable::::::" + populateHanaTable);
		
		int rowCount =populateHanaTable.getRowCount(requestID);
		
		List<UserExit> userExitList=addUserExitDataList(filePath,requestID,rowCount);
		populateHanaTable.populateDataList(userExitList);
			
		
	}
	
	private void addLSMWData(String filePath, long requestID) throws FileNotFoundException {
		logger.info("populateHanaTable::::::" + populateHanaTable);
		
		int rowCount =populateHanaTable.getRowCount(requestID);
		
		List<Lsmw> lsmwList=addLSMWDataList(filePath,requestID,rowCount);
		populateHanaTable.populateDataList(lsmwList);
		
	}

	protected void addInventoryData(String filePath, long requestID) throws FileNotFoundException {
		
		logger.info("populateHanaTable::::::" + populateHanaTable);
		
		int rowCount =populateHanaTable.getRowCount(requestID);
		
		// List<S4InventoryList> inventoryList=addInventoryDataList(filePath,requestID,rowCount);
		// populateHanaTable.populateDataList(inventoryList);
	}
	
	protected S4Detection getDetectionValueXlsx(final Row row,final long requestId, String fileName) {

		final S4Detection s4Detection=new S4Detection();

		int sessionIDIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Session.Id").get(1));
		int indentifierIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Identifier").get(1));
		int typeIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Type").get(1));
		int objNameIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Object.Name").get(1));
		int subProgIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sub.Program").get(1));
		int subTypeIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sub.Type").get(1));
		int objPackageIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Object.Package").get(1));
		int objTypeIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Object.Type").get(1));
		int counterIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Counter").get(1));
		int lineNoIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Line.No").get(1));
		int stmtIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Statement").get(1));
		int operationIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Operation.Code").get(1));
		int commentIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Comment").get(1));
		int descIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Description").get(1));
		int execDateIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Exec.Date").get(1));
		int execTimeIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Exec.Time").get(1));
		int execByIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Exec.By").get(1));
		int toolVersionIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Tool.Version").get(1));


		logger.info("Got Indexes of all cols::::" );
		
		//CR-26.0
				/*String[] splitArr;
				String identifier = "";
				int lineNo = 0;
				String totalScannedLines="";
				String identifierCellVal=row.getCell(indentifierIndex)==null ?"": row.getCell(indentifierIndex).getStringCellValue();
				if(identifierCellVal.startsWith("S")){
					splitArr=identifierCellVal.split("S");
					if(splitArr.length==4 && null!=splitArr[1] && null !=splitArr[3]){
						identifier=splitArr[1];
						lineNo=Integer.parseInt(splitArr[2]);
						totalScannedLines=splitArr[3];
					}
					if(splitArr.length<4 && null!=splitArr[1] ){
						identifier=splitArr[1];
						lineNo=Integer.parseInt(splitArr[2]);
						totalScannedLines="0";
					}
					
				}
		*/
		s4Detection.setSessionId((int) Double.parseDouble((row.getCell(sessionIDIndex)==null) ?"0":row.getCell(sessionIDIndex).getStringCellValue()));
		//s4Detection.setIdentifier(identifier);
		s4Detection.setIdentifier(row.getCell(indentifierIndex)==null?"":row.getCell(indentifierIndex).getStringCellValue());
		s4Detection.setType(row.getCell(typeIndex)==null?"":row.getCell(typeIndex).getStringCellValue());
		s4Detection.setObjectName(row.getCell(objNameIndex)==null?"":row.getCell(objNameIndex).getStringCellValue());
		s4Detection.setSubProgram(row.getCell(subProgIndex)==null?"":row.getCell(subProgIndex).getStringCellValue());
		s4Detection.setSubType(row.getCell(subTypeIndex)==null?"":row.getCell(subTypeIndex).getStringCellValue());
		s4Detection.setObjPackage(row.getCell(objPackageIndex)==null?"":row.getCell(objPackageIndex).getStringCellValue());
		s4Detection.setObjType(row.getCell(objTypeIndex)==null?"":row.getCell(objTypeIndex).getStringCellValue());
		//s4Detection.setCounter((int)Double.parseDouble ((row.getCell(counterIndex)==null || row.getCell(counterIndex).getStringCellValue().isEmpty())?"0":row.getCell(counterIndex).getStringCellValue()));
		
		s4Detection.setLineNo((int)Double.parseDouble(row.getCell(lineNoIndex)==null?"":row.getCell(lineNoIndex).getStringCellValue()));
		//s4Detection.setLineNo(lineNo);
		s4Detection.setStatement(row.getCell(stmtIndex)==null?"":row.getCell(stmtIndex).getStringCellValue());
		s4Detection.setOperations(row.getCell(operationIndex)==null?"":row.getCell(operationIndex).getStringCellValue());
		s4Detection.setComments(row.getCell(commentIndex)==null?"":row.getCell(commentIndex).getStringCellValue());
		s4Detection.setDescription(row.getCell(descIndex)==null?"":row.getCell(descIndex).getStringCellValue());
		s4Detection.setExecDate(row.getCell(execDateIndex)==null?"":row.getCell(execDateIndex).getStringCellValue());
		s4Detection.setExecTime(row.getCell(execTimeIndex)==null?"":row.getCell(execTimeIndex).getStringCellValue());
		s4Detection.setExecBy(row.getCell(execByIndex)==null?"":row.getCell(execByIndex).getStringCellValue());
		s4Detection.setToolVersion((int)Double.parseDouble((row.getCell(toolVersionIndex)==null|| row.getCell(toolVersionIndex).getStringCellValue().isEmpty())?"0":row.getCell(toolVersionIndex).getStringCellValue()));
		//CR-26.0
		s4Detection.setTotalScannedLine(0);
		//s4Detection.setTotalScannedLine(Integer.parseInt(totalScannedLines));
		
		s4Detection.setObjNameType(row.getCell(objNameIndex)==null  || row.getCell(objTypeIndex)==null ? "": (row.getCell(objTypeIndex).getStringCellValue().trim())+(row.getCell(objNameIndex).getStringCellValue().trim()));
		s4Detection.setRequestId(requestId);

		return s4Detection;
	}


	public void addDetectionData(final String path, final long requestId) throws Exception{

		File file=new File(path);
		InputStream inputStream=new FileInputStream(file);

		String fileName=file.getName();
		try{
			List<S4Detection> s4DetectionList=new ArrayList<S4Detection>();
			StreamingReader s4Reader=StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0).read(inputStream);

			for(Row r:s4Reader){
				int rowIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Identifier").get(0));
				
				logger.info("rowIndex::::" + rowIndex);
				
				if(r.getRowNum()>rowIndex){
					int identifierIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Identifier").get(1));
					logger.info("sessionIDIndex::::" + identifierIndex);
					if(r.getCell(identifierIndex)!=null && !r.getCell(identifierIndex).getStringCellValue().isEmpty()){
					logger.info("File--"+fileName+"-----RowNum---"+r.getRowNum());
					s4DetectionList.add(getDetectionValueXlsx(r,requestId,fileName));
					
					}else{
						if(r.getRowNum()==rowIndex+5){
							break;
						}
					}
				}
			}
			populateHanaTable.populateDataList(s4DetectionList);
		}finally {
			IOUtils.closeQuietly(inputStream);
		}

	}

	protected void addCloneProgData(String filePath, long requestId) throws FileNotFoundException {

		File file=new File(filePath);
		InputStream inputStream=new FileInputStream(file);

		String fileName=file.getName();
		try{
			List<S4CloneIntermediate> s4CloneProgIntermediateList=new ArrayList<S4CloneIntermediate>();
			StreamingReader reader=StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0).read(inputStream);

			for(Row r:reader){
				int rowIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Type").get(0));
				if(r.getRowNum()>rowIndex){
					logger.info("File--"+fileName+"-----RowNum---"+r.getRowNum());
					int objTypeIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Type").get(1));
					if(r.getCell(objTypeIndex)!=null && !r.getCell(objTypeIndex).getStringCellValue().isEmpty()){
						s4CloneProgIntermediateList.add(getCloneProgValueXlsx(r,requestId,fileName));
					}else{
						if(r.getRowNum()==rowIndex+5){
							break;
						}
					}
				}
			}
			populateHanaTable.populateDataList(s4CloneProgIntermediateList);
		}finally {
			IOUtils.closeQuietly(inputStream);
		}

	}

	private S4CloneIntermediate getCloneProgValueXlsx(Row row, long requestId, String fileName) {

		final S4CloneIntermediate s4CloneProgIntermediate=new S4CloneIntermediate();

		int objTypeIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Type").get(1));
		int objNameIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name").get(1));
		int includeIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Include").get(1));

		s4CloneProgIntermediate.setObjType(row.getCell(objTypeIndex)==null ?"": row.getCell(objTypeIndex).getStringCellValue());
		s4CloneProgIntermediate.setObjName(row.getCell(objNameIndex)==null?"":row.getCell(objNameIndex).getStringCellValue());
		s4CloneProgIntermediate.setInclude(row.getCell(includeIndex)==null?"":row.getCell(includeIndex).getStringCellValue());
		s4CloneProgIntermediate.setRequestId(requestId);
		
		return s4CloneProgIntermediate;
	}

	protected void addAppendStructureData(String filePath, long requestId) throws FileNotFoundException {

		File file=new File(filePath);
		InputStream inputStream=new FileInputStream(file);

		String fileName=file.getName();
		try{
			List<S4AppendStructureAnalysis> s4AppendList=new ArrayList<S4AppendStructureAnalysis>();
			StreamingReader reader=StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0).read(inputStream);

			for(Row r:reader){
				int rowIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Table.Name").get(0));
				if(r.getRowNum()>rowIndex){
					logger.info("File--"+fileName+"-----RowNum---"+r.getRowNum());
					s4AppendList.add(getAppendValueXlsx(r,requestId,fileName));
				}
			}
			populateHanaTable.populateDataList(s4AppendList);
		}finally {
			IOUtils.closeQuietly(inputStream);
		}
		
	}

	private S4AppendStructureAnalysis getAppendValueXlsx(Row row, long requestId, String fileName) {
		
		final S4AppendStructureAnalysis s4AppendStructureAnalysis=new S4AppendStructureAnalysis();
		
		int tableNameIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Table.Name").get(1));
		int fieldNameIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Field.Name").get(1));
		int nameIncludeIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Name.Include").get(1));
		
		logger.info("File::" + fileName +"tableNameIndex::" +tableNameIndex);
		logger.info("File::" + fileName +"fieldNameIndex::" +fieldNameIndex);
		logger.info("File::" + fileName +"nameIncludeIndex::" +nameIncludeIndex);
		
		s4AppendStructureAnalysis.setTableName(row.getCell(tableNameIndex)==null ?"": row.getCell(tableNameIndex).getStringCellValue());
		s4AppendStructureAnalysis.setFieldName(row.getCell(fieldNameIndex)==null?"":row.getCell(fieldNameIndex).getStringCellValue());
		s4AppendStructureAnalysis.setNameOfInclude(row.getCell(nameIncludeIndex)==null?"":row.getCell(nameIncludeIndex).getStringCellValue());
		s4AppendStructureAnalysis.setRequestId(requestId);
		
		return s4AppendStructureAnalysis;
	}

	protected void addImpactedSeachData(String filePath, long requestID) throws FileNotFoundException {
	
		File file=new File(filePath);
		InputStream inputStream=new FileInputStream(file);

		String fileName=file.getName();
		try{
			List<S4ImpactedSearchHelp> s4ImpactedList=new ArrayList<S4ImpactedSearchHelp>();
			StreamingReader reader=StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0).read(inputStream);

			for(Row r:reader){
				int rowIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestID).get(fileName).get("Data").get(0));
				if(r.getRowNum()>rowIndex){
					logger.info("File--"+fileName+"-----RowNum---"+r.getRowNum());
					s4ImpactedList.add(getImpactedSearchValueXlsx(r,requestID,fileName));
				}
			}
			populateHanaTable.populateDataList(s4ImpactedList);
		}finally {
			IOUtils.closeQuietly(inputStream);
		}
		
	}

	private S4ImpactedSearchHelp getImpactedSearchValueXlsx(Row row, long requestId, String fileName) {

		final S4ImpactedSearchHelp s4Impacted=new S4ImpactedSearchHelp();
	
		int dataIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Data").get(1));
		
		logger.info("File::" + fileName +"dataIndex::" +dataIndex);
		
		
		s4Impacted.setSearchData(row.getCell(dataIndex)==null ?"": row.getCell(dataIndex).getStringCellValue());
		
		s4Impacted.setRequestId(requestId);
		
		return s4Impacted;
	}

	private void addUsageAnalysisData(String filePath, long requestID) throws FileNotFoundException {
		
		File file=new File(filePath);
		InputStream inputStream=new FileInputStream(file);

		String fileName=file.getName();
		try{
			List<S4UsageAnalysis> s4UsageList=new ArrayList<S4UsageAnalysis>();
			StreamingReader reader=StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0).read(inputStream);

			for(Row r:reader){
				int rowIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestID).get(fileName).get("Type").get(0));
				if(r.getRowNum()>rowIndex){
					logger.info("File--"+fileName+"-----RowNum---"+r.getRowNum());
					int typeIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestID).get(fileName).get("Type").get(1));
					if(r.getCell(typeIndex)!=null && !r.getCell(typeIndex).getStringCellValue().isEmpty()){
					s4UsageList.add(getUsageValueXlsx(r,requestID,fileName));
				}else{
					if(r.getRowNum()==rowIndex+5){
						break;
					}
				}
				}
			}
			populateHanaTable.populateDataList(s4UsageList);
		}finally {
			IOUtils.closeQuietly(inputStream);
		}
		
		
	}

	private S4UsageAnalysis getUsageValueXlsx(Row row, long requestId, String fileName) {
		
		final S4UsageAnalysis s4UsageAnalysis=new S4UsageAnalysis();
		
		int typeIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Type").get(1));
		int objNameIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name").get(1));
		
		s4UsageAnalysis.setType(row.getCell(typeIndex)==null ?"": row.getCell(typeIndex).getStringCellValue());
		s4UsageAnalysis.setObjName(row.getCell(objNameIndex)==null?"":row.getCell(objNameIndex).getStringCellValue());
		s4UsageAnalysis.setObjNameType(row.getCell(objNameIndex)==null || row.getCell(typeIndex)==null ?"" : row.getCell(typeIndex).getStringCellValue().trim() + row.getCell(objNameIndex).getStringCellValue().trim());
		s4UsageAnalysis.setRequestId(requestId);
		
		return s4UsageAnalysis;
	}
	//CR-21.0
	public synchronized void  s4FilesRead(final String filePath, final long requestId ,String toolName) throws Exception {
		final long requestID = requestId;
		final File file = new File(filePath);
		String path=file.getName().toUpperCase();

		/*if (path.contains(ST03HanaConstant.CONSOLIDATE_CONSTANT.toUpperCase())) {
			if("s4".equalsIgnoreCase(toolName) ){
			addConsolidatedData(filePath, requestId,toolName);
			}*/
		 
		
		if (path.contains(S4HanaProfilerConstant.DETECTION_CONSTANT.toUpperCase())) {
		if("s4".equalsIgnoreCase(toolName) ){
			addDetectionData(filePath, requestId);
		}
		} else if (path.contains(S4HanaProfilerConstant.CLONE_CONSTANT.toUpperCase())) {
			addCloneProgData(filePath, requestId);
		} else if (path.contains(S4HanaProfilerConstant.USAGE_CONSTANT.toUpperCase())) {
			addUsageAnalysisData(filePath, requestID);
		} else if (path.contains(S4HanaProfilerConstant.SEARCH_CONSTANT.toUpperCase())) {
			addImpactedSeachData(filePath, requestID);
		} else if (path.contains(S4HanaProfilerConstant.APPEND_CONSTANT.toUpperCase())) {
			addAppendStructureData(filePath, requestId);
		} else if (path.contains(S4HanaProfilerConstant.IDOC_CONSTANT.toUpperCase())) {
			addIDOCData(filePath, requestID);
		}else if (path.contains(S4HanaProfilerConstant.IMPACTED_TABLES_CONSTANT.toUpperCase())) {
			addImpactedTableData(filePath, requestID);
		}else if (path.contains(S4HanaProfilerConstant.IMPACTED_STANDARD_TRANSACTION_CONSTANT.toUpperCase())) {
			addImpactedTransactionData(filePath, requestID);
		}else if (path.contains(S4HanaProfilerConstant.LSMW_CONSTANT.toUpperCase())) {
			if("s4".equalsIgnoreCase(toolName) )
				addLSMWData(filePath, requestID);
		}else if (path.contains(S4HanaProfilerConstant.USER_EXIT_CONSTANT.toUpperCase())) {
			if("s4".equalsIgnoreCase(toolName) )
				addUserExitData(filePath, requestID);
		}else if (path.contains(S4HanaProfilerConstant.INVENTORY_CONSTANT.toUpperCase())) {
			if("s4".equalsIgnoreCase(toolName) )
				addInventoryData(filePath, requestID);
		} 
	}
	

	


	//CR-47.0
	protected void addImpactedTransactionData(String filePath, long requestID) throws FileNotFoundException {
		File file=new File(filePath);
		InputStream inputStream=new FileInputStream(file);

		String fileName=file.getName();
		try{
			List<S4ImpactedTransaction> s4ImpactedTransactionList=new ArrayList<S4ImpactedTransaction>();
			StreamingReader reader=StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0).read(inputStream);

			for(Row r:reader){
				int rowIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestID).get(fileName).get("Impacted.Transactions").get(0));
				if(r.getRowNum()>rowIndex){
					logger.info("File--"+fileName+"-----RowNum---"+r.getRowNum());
					int transactionIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestID).get(fileName).get("Impacted.Transactions").get(1));
					if(r.getCell(transactionIndex)!=null && !r.getCell(transactionIndex).getStringCellValue().isEmpty()){
						s4ImpactedTransactionList.add(getImpactedTransactionValueXlsx(r,requestID,fileName));
				}else{
					if(r.getRowNum()==rowIndex+5){
						break;
					}
				}
				}
			}
			populateHanaTable.populateDataList(s4ImpactedTransactionList);
		}finally {
			IOUtils.closeQuietly(inputStream);
		}
		
		
	}

	//CR-47.0
	private S4ImpactedTransaction getImpactedTransactionValueXlsx(Row row, long requestId, String fileName) {
		
		final S4ImpactedTransaction s4ImpactedTransaction=new S4ImpactedTransaction();
		
		int transactionIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Impacted.Transactions").get(1));
		
		s4ImpactedTransaction.setImpactedTransaction(row.getCell(transactionIndex)==null ?"": row.getCell(transactionIndex).getStringCellValue());
		
		s4ImpactedTransaction.setRequestID(requestId);
		
		return s4ImpactedTransaction;
	}

	protected void addImpactedTableData(String filePath, long requestID) throws FileNotFoundException {
		File file=new File(filePath);
		InputStream inputStream=new FileInputStream(file);

		String fileName=file.getName();
		try{
			List<S4ImpactedTables> s4ImpactedTableList=new ArrayList<S4ImpactedTables>();
			StreamingReader reader=StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0).read(inputStream);

			for(Row r:reader){
				int rowIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestID).get(fileName).get("Object").get(0));
				if(r.getRowNum()>rowIndex){
					logger.info("File--"+fileName+"-----RowNum---"+r.getRowNum());
					int objectIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestID).get(fileName).get("Object").get(1));
					if(r.getCell(objectIndex)!=null && !r.getCell(objectIndex).getStringCellValue().isEmpty()){
						s4ImpactedTableList.add(getImpactedTablesValueXlsx(r,requestID,fileName));
				}else{
					if(r.getRowNum()==rowIndex+5){
						break;
					}
				}
				}
			}
			populateHanaTable.populateDataList(s4ImpactedTableList);
		}finally {
			IOUtils.closeQuietly(inputStream);
		}
		
		
	}

	private S4ImpactedTables getImpactedTablesValueXlsx(Row row, long requestId, String fileName) {
		
		final S4ImpactedTables s4ImpactedTables=new S4ImpactedTables();
		
		int objectIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Object").get(1));
		/*int descriptionIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Description").get(1));
		int solStepIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Solution.Steps").get(1));
		int sapNotesIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sap.Notes").get(1));
		*/
		s4ImpactedTables.setObject(row.getCell(objectIndex)==null ?"": row.getCell(objectIndex).getStringCellValue());
		/*s4ImpactedTables.setDescription(row.getCell(descriptionIndex)==null ?"": row.getCell(descriptionIndex).getStringCellValue());
		s4ImpactedTables.setSolSteps(row.getCell(solStepIndex)==null ?"": row.getCell(solStepIndex).getStringCellValue());
		s4ImpactedTables.setSapNotes(row.getCell(sapNotesIndex)==null ?"": row.getCell(sapNotesIndex).getStringCellValue());*/
		s4ImpactedTables.setRequestID(requestId);
		
		return s4ImpactedTables;
	}

	protected void addIDOCData(String filePath, long requestID) throws FileNotFoundException {
		File file=new File(filePath);
		InputStream inputStream=new FileInputStream(file);

		String fileName=file.getName();
		try{
			List<S4ImpactedIDOC> s4ImpactedIDOCList=new ArrayList<S4ImpactedIDOC>();
			StreamingReader reader=StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0).read(inputStream);

			for(Row r:reader){
				int rowIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestID).get(fileName).get("Basic.type").get(0));
				if(r.getRowNum()>rowIndex){
					logger.info("File--"+fileName+"-----RowNum---"+r.getRowNum());
					int basicTypeIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestID).get(fileName).get("Basic.type").get(1));
					if(r.getCell(basicTypeIndex)!=null && !r.getCell(basicTypeIndex).getStringCellValue().isEmpty()){
						//s4ImpactedIDOCList.add(getImpactedIDOCValueXlsx(r,requestID,fileName));
				}else{
					if(r.getRowNum()==rowIndex+5){
						break;
					}
				}
				}
			}
			populateHanaTable.populateDataList(s4ImpactedIDOCList);
		}finally {
			IOUtils.closeQuietly(inputStream);
		}
		
	}

	/*private S4ImpactedIDOC getImpactedIDOCValueXlsx(Row row, long requestId, String fileName) {
		final S4ImpactedIDOC s4ImpactedIDOC=new S4ImpactedIDOC();
		
		int basicTypeIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Basic.type").get(1));
		int extensionIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Extension").get(1));
		int segmentTypeIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Segment.type").get(1));
		int positionFieldIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Position.field.table").get(1));
		int fieldNameIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Field.Name").get(1));
		int dataElementIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Data.element").get(1));
		int idocDevIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("IDOC.Dev").get(1));
		int descriptionIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Description").get(1));
		int sapNoteIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("SAP.NOTE").get(1));
		int solStepIndex=Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).get(fileName).get("Solution.Steps").get(1));
		
		s4ImpactedIDOC.setBasicType(row.getCell(basicTypeIndex)==null ?"": row.getCell(basicTypeIndex).getStringCellValue());
		s4ImpactedIDOC.setExtension(row.getCell(extensionIndex)==null ?"": row.getCell(extensionIndex).getStringCellValue());
		s4ImpactedIDOC.setSegmentType(row.getCell(segmentTypeIndex)==null ?"": row.getCell(segmentTypeIndex).getStringCellValue());
		s4ImpactedIDOC.setPositionFieldInTable(row.getCell(positionFieldIndex)==null ?"": row.getCell(positionFieldIndex).getStringCellValue());
		s4ImpactedIDOC.setFieldName(row.getCell(fieldNameIndex)==null ?"": row.getCell(fieldNameIndex).getStringCellValue());
		s4ImpactedIDOC.setDataElement(row.getCell(dataElementIndex)==null ?"": row.getCell(dataElementIndex).getStringCellValue());
		s4ImpactedIDOC.setIdocDev(row.getCell(idocDevIndex)==null ?"": row.getCell(idocDevIndex).getStringCellValue());
		s4ImpactedIDOC.setDescription(row.getCell(descriptionIndex)==null ?"": row.getCell(descriptionIndex).getStringCellValue());
		s4ImpactedIDOC.setSapNote(row.getCell(sapNoteIndex)==null ?"": row.getCell(sapNoteIndex).getStringCellValue());
		s4ImpactedIDOC.setSolSteps(row.getCell(solStepIndex)==null ?"": row.getCell(solStepIndex).getStringCellValue());
		s4ImpactedIDOC.setRequestID(requestId);
		
		return s4ImpactedIDOC;
	}
*/
	


}
