package com.accenture.S4.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.accenture.S4.models.FileStore;
import com.accenture.S4.models.FioriRebuildMaster;
import com.accenture.S4.models.GrcMasterdata;
import com.accenture.S4.models.S4ValidationFile;
import com.accenture.S4.models.S4ValidationList;
import com.accenture.S4.models.TCDSimplification;
import com.accenture.S4.models.TarUsobtc;
import com.accenture.bw.model.BwExtractorMaster;
import com.accenture.client.dao.RequestFormDAO;
import com.accenture.client.dao.RequestInventoryDAO;
import com.accenture.client.model.RequestInventory;
import com.accenture.constant.Hana_Profiler_Constant;
import com.accenture.displaygrid.model.DBConfig;
import com.accenture.exceptions.HibernateException;
import com.accenture.testingscope.model.AppComponentSubProcessTestScript;
import com.accenture.testingscope.model.TCodeSubProcessTestScript;

@Transactional
@Repository
public class S4ValidationDAOImpl implements S4ValidationDAO {
	final Logger logger = LoggerFactory.getLogger(S4ValidationDAOImpl.class);
	
	@Autowired
	public SessionFactory sessionFactory;
	@Autowired
	RequestFormDAO daoobj;
	@Autowired
	RequestInventoryDAO inventoryDaoObj;
	 
	static PopulatingS4FinalOutput finaloutput = new PopulatingS4FinalOutput();

	public String getS4ValidationLatestVersion(HttpSession session) throws SQLException {
		String valVersion=null;
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {
			String queryStr = " select S4_VALIDATION_FILE_VERSION from s4_validation_file order by ID desc limit 1 ";
			conn = DBConfig.getJDBCConnection(session);
			conn.setAutoCommit(false);
			stmt = conn.prepareStatement(queryStr);
			ResultSet valVersionRs = stmt.executeQuery();
			while(valVersionRs.next()) {
				valVersion = valVersionRs.getString("S4_VALIDATION_FILE_VERSION");
			}
		}catch (Exception e) {
			logger.error("Error in getting validation version :: ",e);
			throw e;
		}finally {
			if(null != conn) {
				conn.close();
			}
			if(null != stmt) {
				stmt.close();
			}
		}
		return valVersion;
	}
	
	public Boolean getS4ValidationExistingStatus(String fileVersion) {
		try {
			Session session = sessionFactory.getCurrentSession();
			String sql = "Select Count(*) from S4ValidationFile where validationFileName in ('"+fileVersion+"')";
			Query query = session.createQuery(sql);
			Long count=   (Long) query.uniqueResult();
			if(count >=1L)
			{
				return true;
			}
			else
			{
				return false;	
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}

	}
	
	@Transactional
	public Integer getS4ValidationMaxID() {
		try {
			Session session = sessionFactory.getCurrentSession();
			String sql = "select max(ID) from S4ValidationFile";
			Integer maxCount;
			Query query = session.createQuery(sql);
			if((Integer) query.uniqueResult()!= null)
			{
				maxCount =  (Integer) query.uniqueResult();
			}
			else
			{
				maxCount=0;	
			}
			return maxCount;
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	
	public Integer getPreRequisiteMaxID() {
		try {
			Session session = sessionFactory.getCurrentSession();
			String sql = "select max(ID) from PreRequisiteFile";
			Integer maxCount;
			Query query = session.createQuery(sql);
			if((Integer) query.uniqueResult()!= null)
			{
				maxCount =  (Integer) query.uniqueResult();
			}
			else
			{
				maxCount=0;	
			}
			return maxCount;
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void saveS4ValidationFile(S4ValidationFile s4ValidationFile) throws SQLException {
		try {
			Session session = sessionFactory.getCurrentSession();
			java.util.Date dt = new java.util.Date();
			java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String currentTime = sdf.format(dt);
			s4ValidationFile.setUpdatedDate(currentTime);
			session.saveOrUpdate(s4ValidationFile);
			logger.info("s4ValidationFile stored in table sucessfully");
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void saveFiles(FileStore fileStore, byte[] prZipContent, String fileName, String fileNameKey) throws SQLException {
		try {
			Session session = sessionFactory.getCurrentSession();
			java.util.Date dt = new java.util.Date();
			java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String currentTime = sdf.format(dt);
			//fileStore.setFileContent(prZipContent);
			//fileStore.setFileName(fileName);
			Query query = session.createQuery("from FileStore");
			java.util.List list = query.list();
			for(Object obj :  list) {
				FileStore fileStoreObj = (FileStore) obj;
				if(fileNameKey.equalsIgnoreCase(fileStoreObj.getFileNameKey())) {
					fileStore = (FileStore) obj;
					break;
				}
			}
			//if(CollectionUtils.isNotEmpty(list) && null != list.get(0)) {
				//fileStore = (FileStore) list.get(0);
				fileStore.setFileContent(prZipContent);
				fileStore.setFileName(fileName);
				fileStore.setFileNameKey(fileNameKey);
			//}
			fileStore.setUpdatedDate(currentTime);
			session.saveOrUpdate(fileStore);
			logger.info("File stored in table sucessfully");
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	
	/*@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void addS4ValidationFileNameRequestInventory(Long requestID, String s4ValFileName) {
		try {
			Session session = sessionFactory.getCurrentSession();
			RequestInventory obj = (RequestInventory) session.get(RequestInventory.class, requestID);
			obj.setS4ValidationVersion(s4ValFileName);
			session.saveOrUpdate(obj);
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}*/
	
	public String validationFileDataBatchInsertUpdate(List<S4ValidationList> validationDataS4List,
			HttpSession session) throws SQLException {
		final String INSERT_SQL = "INSERT INTO s4_validation_data "
				+ "(Identifier, Version, Object, Sub_Object, Object_Type, Program_Name, Screen, Obsolete, New_Len, Affected_Area) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		deleteS4ValidateData();
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (S4ValidationList validationDataS4 : validationDataS4List) {
					stmt.setString(1, validationDataS4.getIdentifier());
					stmt.setString(2, validationDataS4.getVersion());
					stmt.setString(3, validationDataS4.getObject());
					stmt.setString(4, validationDataS4.getSubObject());
					stmt.setString(5, validationDataS4.getObjectType());
					stmt.setString(6, validationDataS4.getProgramName());
					stmt.setString(7, validationDataS4.getScreen());
					stmt.setString(8, validationDataS4.getObsolete());
					stmt.setString(9, validationDataS4.getNew_Len());
					stmt.setString(10, validationDataS4.getAffectedArea());
					
					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("S4 Validation data Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("s4_validation_data Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}
	
	public void deleteS4ValidateData(){
		Query query =null;
		String hql = "delete from S4ValidationList ";
		String hql1 = "select count(*) from S4ValidationList ";

		Session session = sessionFactory.openSession();
		try{
			query=session.createQuery(hql1);		
			int count = ((Long)query.uniqueResult()).intValue();	

			if(count!=0){
				query=session.createQuery(hql);		
				query.executeUpdate();
			}
			//Session session=sessionFactory.openSession();
			//session.saveOrUpdate(reqMaster);

			session.close();
		}
		catch (Exception e) {
			e.getMessage();
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}

	}
	public void deleteTCDSimplificationData(){
		Query query =null;
		String hql = "delete from TCDSimplification ";
		String hql1 = "select count(*) from TCDSimplification ";

		Session session = sessionFactory.openSession();
		try{
			query=session.createQuery(hql1);		
			int count = ((Long)query.uniqueResult()).intValue();	

			if(count!=0){
				query=session.createQuery(hql);		
				query.executeUpdate();
			}
			//Session session=sessionFactory.openSession();
			//session.saveOrUpdate(reqMaster);

			session.close();
		}
		catch (Exception e) {
			e.getMessage();
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}

	}
	
	public void deleteGRCMasterdataData(){
		Query query =null;
		String hql = "delete from GrcMasterdata ";
		String hql1 = "select count(*) from GrcMasterdata ";

		Session session = sessionFactory.openSession();
		try{
			query=session.createQuery(hql1);		
			int count = ((Long)query.uniqueResult()).intValue();	

			if(count!=0){
				query=session.createQuery(hql);		
				query.executeUpdate();
			}
			//Session session=sessionFactory.openSession();
			//session.saveOrUpdate(reqMaster);

			session.close();
		}
		catch (Exception e) {
			e.getMessage();
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}

	}
	
	public void deleteBwExtrctMasterdataData(){
		Query query =null;
		String hql = "delete from BwExtractorMaster ";
		String hql1 = "select count(*) from BwExtractorMaster ";

		Session session = sessionFactory.openSession();
		try{
			query=session.createQuery(hql1);		
			int count = ((Long)query.uniqueResult()).intValue();	

			if(count!=0){
				query=session.createQuery(hql);		
				query.executeUpdate();
			}
			//Session session=sessionFactory.openSession();
			//session.saveOrUpdate(reqMaster);

			session.close();
		}
		catch (Exception e) {
			e.getMessage();
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}

	}
	public S4ValidationFile getNewValidationobj(Long requestID) throws Exception {

		RequestInventory requestInventory=inventoryDaoObj.getRequestInventory(requestID);
		logger.info("After getting requestInventory obj");

		String valVersion=requestInventory.getS4ValidationVersion();
		logger.info("After getting Version from requestInventory obj");

		S4ValidationFile valFileObj=getValidationFile(valVersion);
		
		return valFileObj;

	}
	
	//@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public S4ValidationFile getValidationFile(String valVersion) {
		try {
			Session session = sessionFactory.getCurrentSession();
			/*
			 * TransportRequestID transportRequestID=new
			 * TransportRequestID(sourceVersion,targetVersion);
			 * 
			 * TransportRequest
			 * trobj=(TransportRequest)session.get(TransportRequest.class,
			 * transportRequestID);
			 */
			//String sql = "select t from TransportRequest t where t.transportRequestPK.sourceVersion=:sourceVersion and t.transportRequestPK.targetVersion=:targetVersion";
			String sql = "select s from S4ValidationFile s where s.validationVersion=:validationVersion";
			
			Query query = session.createQuery(sql);
			query.setParameter("validationVersion", valVersion);

			S4ValidationFile valObj = (S4ValidationFile) query.uniqueResult();

			return valObj;
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	
	//@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public boolean getFileDownloadStatus(Long requestID, String fileName) {
		boolean value = false;
		Session session = null;
		try {
			session = sessionFactory.getCurrentSession();
			Query query = session.createQuery(
					"select s4ValidationDownloadStatus from RequestInventory requestInventory where requestInventory.requestID=:requestID");
			if(StringUtils.isNotBlank(fileName) && "PREREQUISITE".equalsIgnoreCase(fileName)) {
			 query = session.createQuery(
					"select preReqDownloadStatus from RequestInventory requestInventory where requestInventory.requestID=:requestID");
			}
			query.setLong("requestID", requestID);
			Object obj = query.uniqueResult();
			if (obj != null) {
				value = (boolean) obj;
			}
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			logger.trace(ex.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		return value;
	}
	
	public RequestInventory setValidationDownloadStatus(Long requestID, boolean validationDownloadStatus) {
		Session session = sessionFactory.getCurrentSession();
		RequestInventory obj = (RequestInventory) session.get(RequestInventory.class, requestID);
		obj.setS4ValidationDownloadStatus(validationDownloadStatus);

		session.saveOrUpdate(obj);
		return obj;
	}
	public RequestInventory setPreRequisiteDownloadStatus(Long requestID, boolean preRequisiteDownloadStatus) {
		Session session = sessionFactory.getCurrentSession();
		RequestInventory obj = (RequestInventory) session.get(RequestInventory.class, requestID);
		obj.setPreReqDownloadStatus(preRequisiteDownloadStatus);

		session.saveOrUpdate(obj);
		return obj;
	}
	
	public FileStore getFileFromFileStoreTable(String fileNameKey) {
		try {
			Session session = sessionFactory.getCurrentSession();
			/*
			 * TransportRequestID transportRequestID=new
			 * TransportRequestID(sourceVersion,targetVersion);
			 * 
			 * TransportRequest
			 * trobj=(TransportRequest)session.get(TransportRequest.class,
			 * transportRequestID);
			 */
			//String sql = "select t from TransportRequest t where t.transportRequestPK.sourceVersion=:sourceVersion and t.transportRequestPK.targetVersion=:targetVersion";
			String sql = "select f from FileStore f where fileNameKey = "+fileNameKey;
			
			Query query = session.createQuery(sql);
			//query.setParameter("validationVersion", valVersion);

			FileStore fileObj = (FileStore) query.uniqueResult();

			return fileObj;
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	public String tcdSimplificationDataBatchInsertUpdate(List<TCDSimplification> tcdsimpliList,
			HttpSession session) throws SQLException {
		final String INSERT_SQL = "INSERT INTO TCD_MasterData "
				+ "(OldTcode, NewTcode, Functional_Area, Reference, TargetVersion, AdditionalODataServices_NewTcode, AdditionalODataServices_OldTcode, AppName_NewTcode, AppName_OldTcode, ApplicationType_NewTcode, ApplicationType_OldTcode, FioriID_NewTcode, FioriID_OldTcode, FrontendProductVersion_NewTcode, FrontendProductVersion_OldTcode, ProductVersionNameBackend_OldTcode, PrimaryODataServiceName_NewTcode, PrimaryODataServiceName_OldTcode, WDAConfiguration_NewTcode, WDAConfiguration_OldTcode, ProductVersionNameBackend_NewTcode) values (?, ?, ?, ?, ?, ?, ?, ?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		String comment="";
		deleteTCDSimplificationData();
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (TCDSimplification tcd : tcdsimpliList) {
					stmt.setString(1, tcd.getOld());
					stmt.setString(2, tcd.getNewTcode());
					stmt.setString(3, tcd.getFunctionalArea());
					stmt.setString(4, tcd.getReference());
					stmt.setString(5, tcd.getTargetVersion());
					stmt.setString(6, tcd.getAddOdataSerNewTcode());
					stmt.setString(7, tcd.getAddOdataSerOldTcode());
					stmt.setString(8, tcd.getAppNameNewTcode());
					stmt.setString(9, tcd.getAppNameOldTcode());
					stmt.setString(10, tcd.getAppTypeNewTcode());
					stmt.setString(11, tcd.getAppTypeOldTcode());
					stmt.setString(12, tcd.getFioriIdNewTcode());
					stmt.setString(13, tcd.getFioriIdOldTcode());
					stmt.setString(14, tcd.getFrntEndPrdVerNewTcode());
					stmt.setString(15, tcd.getFrntEndPrdVerOldTcode());
					stmt.setString(16, tcd.getPrdVerNameBckEndOldTcode());
					stmt.setString(17, tcd.getPriOdataSerNameNewTcode());
					stmt.setString(18, tcd.getPriOdataSerNameOldTcode());
					stmt.setString(19, tcd.getWdaConfNewTcode());
					stmt.setString(20, tcd.getWdaConfOldTcode());
					stmt.setString(21, tcd.getPrdVerNameBckEndNewTcode());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("TCD Simplification Data INSERTED SUCCESSFULLY");
				comment="success";
			
			} catch (Exception e) {
				comment = "FAILURE in insert";
				logger.error(e.getMessage());
				throw e;
			}
		} catch (Exception e) {
			comment = "FAILURE in Getting Connection";
			logger.error(e.getMessage());
			throw e;

		} finally {
			stmt.close();
			conn.close();
		}

		return comment;

	}
	
	public String grcMasterdataDataBatchInsertUpdate(List<GrcMasterdata> grcMasterList,
			HttpSession session) throws SQLException {
		final String INSERT_SQL = "INSERT INTO Grc_Masterdata "
				+ "(Mandt,Functid,action,connector,active) values (?,?,?,?,?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		String comment="";
		deleteGRCMasterdataData();
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (GrcMasterdata grc : grcMasterList) {
					stmt.setString(1, grc.getMandt());
					stmt.setString(2, grc.getFunctId());
					stmt.setString(3, grc.getAction());
					stmt.setString(4, grc.getConnector());
					stmt.setString(5, grc.getActive());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("GRC Master Data INSERTED SUCCESSFULLY");
				comment="success";
			
			} catch (Exception e) {
				comment = "FAILURE in insert";
				logger.error(e.getMessage());
				throw e;
			}
		} catch (Exception e) {
			comment = "FAILURE in Getting Connection";
			logger.error(e.getMessage());
			throw e;

		} finally {
			stmt.close();
			conn.close();
		}

		return comment;

	}
	
	public String targetUsobtcDataBatchInsertUpdate(List<TarUsobtc> tarUsobtcList,
			HttpSession session) throws SQLException {
		final String INSERT_SQL = "INSERT INTO tar_usobtc "
				+ "(VERSION, TCD, OBJ, FIELD, LOW, HIGH) values (?, ?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		String comment="SUCCESS";
		comment = deleteTableData("TarUsobtc");
		if (null != comment) {
			//do nothing
		} else {
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (TarUsobtc tarUso : tarUsobtcList) {
					stmt.setString(1, tarUso.getVersion());
					stmt.setString(2, tarUso.getTcd());
					stmt.setString(3, tarUso.getObject());
					stmt.setString(4, tarUso.getField());
					stmt.setString(5, tarUso.getLow());
					stmt.setString(6, tarUso.getHigh());
					

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("Target Usobtc Data INSERTED SUCCESSFULLY");
				comment="success";
			
			} catch (Exception e) {
				comment = "FAILURE in insert";
				logger.error("targetUsobtcDataBatchInsertUpdate :: ",e);
			}
		} catch (Exception e) {
			comment = "FAILURE in Getting Connection";
			logger.error("targetUsobtcDataBatchInsertUpdate :: ",e);

		} finally {
			stmt.close();
			conn.close();
			}
		}
		return comment;

	}
	
	public String deleteTableData(String tableName) {
		logger.debug(":: deleteTableData() Start :: table name :: "+tableName);

		String comment = null;
		Query query = null;
		String hql = "delete from " + tableName;
		String hql1 = "select count(*) from " + tableName;

		Session session = sessionFactory.openSession();
		try {
			query = session.createQuery(hql1);		
			int count = ((Long)query.uniqueResult()).intValue();	

			if(count != 0) {
				query = session.createQuery(hql);		
				query.executeUpdate();
			}
		} catch (Exception e) {
			comment = tableName + " : Data Upload Failed";
			logger.error("deleteTableData :: " + tableName + " :: ", e);
		} finally {
			session.close();
		}
			
		logger.debug(":: deleteTableData() End :: table name :: "+tableName);
		return comment;
	}

	@Override
	public String tcodeSubProcessInsertData(List<TCodeSubProcessTestScript> tcodeSubProcessList, HttpSession session)
			throws SQLException {
		final String INSERT_SQL = "INSERT INTO TCode_SubProcessTestScript "
				+ "(Scenario_Level1, Main_Process_Level2, Sub_Process_Level3, Test_Script_Level4, TCodes_ECC, TCodes_S4_1610, "
				+ "TCodes_S4_1709, TCodes_S4_1809, TCodes_S4_1909, Application_Component, Fiori_AppID, Fiori_AppName) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		String comment = "";
		
		try {
			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (TCodeSubProcessTestScript tcodeSubProcess : tcodeSubProcessList) {
					stmt.setString(1, tcodeSubProcess.getScenarioLevelOne());
					stmt.setString(2, tcodeSubProcess.getMainProcessLevelTwo());
					stmt.setString(3, tcodeSubProcess.getSubProcessLevelThree());
					stmt.setString(4, tcodeSubProcess.getTestScriptLevelFour());
					stmt.setString(5, tcodeSubProcess.getTcodesECC().trim());
					stmt.setString(6, tcodeSubProcess.getTcodesS41610().trim());
					stmt.setString(7, tcodeSubProcess.getTcodesS41709().trim());
					stmt.setString(8, tcodeSubProcess.getTcodesS41809().trim());
					stmt.setString(9, tcodeSubProcess.getTcodesS41909().trim());
					stmt.setString(10, tcodeSubProcess.getApplicationComponent());
					stmt.setString(11, tcodeSubProcess.getFioriAppID());
					stmt.setString(12, tcodeSubProcess.getFioriAppName());
					
					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("TCode SubProcess TestScript - Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.debug("TCode SubProcess TestScript Data INSERTED SUCCESSFULLY");
				comment="Success";
			} catch (Exception e) {
				comment = "FAILURE in Inserting";
				logger.error("Error while inserting TCode SubProcess TestScript Data ", e);
				throw e;
			}
		} catch (Exception e) {
			comment = "FAILURE in Getting Connection";
			logger.error("Error while inserting TCode SubProcess TestScript Data ", e);
			throw e;
		} finally {
			stmt.close();
			conn.close();
		}

		return comment;
	}
	
	@Override
	public String appCompSubProcessInsertData(List<AppComponentSubProcessTestScript> appCompSubProcessList, HttpSession session) 
			throws SQLException {
		final String INSERT_SQL = "INSERT INTO AppComponent_SubProcessTestScript "
				+ "(Application_Component, Scenario_Level1, Main_Process_Level2, Sub_Process_Level3) "
				+ "values (?, ?, ?, ?)";
		
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		String comment = "";
		
		try {
			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (AppComponentSubProcessTestScript appCompSubProcess : appCompSubProcessList) {
					stmt.setString(1, appCompSubProcess.getAppComponent());
					stmt.setString(2, appCompSubProcess.getScenarioLevelOne());
					stmt.setString(3, appCompSubProcess.getMainProcessLevelTwo());
					stmt.setString(4, appCompSubProcess.getSubProcessLevelThree());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Application_Component SubProcess TestScript - Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.debug("Application_Component SubProcess TestScript Data INSERTED SUCCESSFULLY");
				comment="Success";
			} catch (Exception e) {
				comment = "FAILURE in Inserting";
				logger.error("Error while inserting Application_Component SubProcess TestScript Data ", e);
				throw e;
			}
		} catch (Exception e) {
			comment = "FAILURE in Getting Connection";
			logger.error("Error while inserting Application_Component SubProcess TestScript Data ", e);
			throw e;
		} finally {
			stmt.close();
			conn.close();
		}

		return comment;	
	}
	
	@Override
	public void truncateTable(String tableName, HttpSession session) {
		StringBuilder truncateSQL = new StringBuilder("TRUNCATE " + tableName);
		
		try(java.sql.Connection conn = DBConfig.getJDBCConnection(session);
				java.sql.Statement stmt = conn.createStatement()) {
			stmt.executeUpdate(truncateSQL.toString());
		} catch(Exception e) {
			logger.error("Error while truncating table " + tableName + " : ", e);
		}
	}
	
	public String bwExtractMasterdataDataBatchInsertUpdate(List<BwExtractorMaster> bwMasterList,
			HttpSession session) throws SQLException {
		final String INSERT_SQL = "INSERT INTO BW_EXTRACT_MASTER "
				+ "(obj_name,phase,area_responsibility,data_source,app_component,classification,category,restrictions,related_simplification_item,note,del_1511,del_1610,delta_restrict,comments) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		String comment="";
		deleteBwExtrctMasterdataData();
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (BwExtractorMaster bwm : bwMasterList) {
					stmt.setString(1, bwm.getObjName());
					stmt.setString(2, bwm.getPhase());
					stmt.setString(3, bwm.getAreaResponsibility());
					stmt.setString(4, bwm.getDataSrc());
					stmt.setString(5, bwm.getAppComp());
					stmt.setString(6, bwm.getClassification());
					stmt.setString(7, bwm.getCategory());
					stmt.setString(8, bwm.getRestrictions());
					stmt.setString(9, bwm.getRelSimpliItem());
					stmt.setString(10, bwm.getNote());
					stmt.setString(11, bwm.getDel1511());
					stmt.setString(12, bwm.getDel1610());
					stmt.setString(13, bwm.getDelRestrict());
					stmt.setString(14, bwm.getComments());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("BW EXTRACT Master Data INSERTED SUCCESSFULLY");
				comment="success";
			
			} catch (Exception e) {
				comment = "FAILURE in insert";
				logger.error(e.getMessage());
				throw e;
			}
		} catch (Exception e) {
			comment = "FAILURE in Getting Connection";
			logger.error(e.getMessage());
			throw e;

		} finally {
			stmt.close();
			conn.close();
		}

		return comment;

	}
	@Override
	public String fioriRebuildDataBatchInsertUpdate(List<FioriRebuildMaster> fioriRebuildMasterList, HttpSession session)
			throws SQLException{
		final String insert_sql = "INSERT INTO Fiori_Rebuild_Master"
				+ "(App_Id, App_Name, Available_Version, List_Of_Similar_Applications, Remarks, Version_Check) "
				+ "values (?, ?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		String comment="SUCCESS";
		comment = deleteTableData("FioriRebuildMaster");
		if (null != comment) {
			//do nothing
		} else {
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(insert_sql);
				int batch = 1;

				for (FioriRebuildMaster fioriRebuildMaster : fioriRebuildMasterList) {
					stmt.setString(1, fioriRebuildMaster.getAppId());
					stmt.setString(2, fioriRebuildMaster.getAppName());
					stmt.setString(3, fioriRebuildMaster.getAvailableVersion());
					stmt.setString(4, fioriRebuildMaster.getList_of_similar_aplications());
					stmt.setString(5, fioriRebuildMaster.getRemarks());
					stmt.setString(6, fioriRebuildMaster.getVersionCheck());
					
					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("Fiori Rebuild Master Data INSERTED SUCCESSFULLY");
				comment="success";
			
			} catch (Exception e) {
				comment = "FAILURE in insert";
				logger.error("fioriRebuDataBatchInsertUpdate :: ",e);
			}
		} catch (Exception e) {
			comment = "FAILURE in Getting Connection";
			logger.error("fioriRebuDataBatchInsertUpdate :: ",e);

		} finally {
			stmt.close();
			conn.close();
			}
		}
		return comment;

	}
}
