package com.accenture.S4.dao;

import java.util.List;

import javax.servlet.http.HttpSession;

import com.accenture.S4.models.DrillDown_Download;
import com.accenture.S4.models.ObsoleteFmsDueToUpgrade;
import com.accenture.S4.models.S4Assumptions;
import com.accenture.S4.models.S4CvitAssessment;
import com.accenture.S4.models.S4Estimations;
import com.accenture.S4.models.S4HanaProfiler_Download;
import com.accenture.S4.models.S4ValidationList;
import com.accenture.client.model.RequestForm;
 
/**
 * @author monika.mishra
 *
 */
public interface PopulatingS4FinalOutputInterface {
	
	boolean getS4HanaProfilerFinalList(final long requestId, RequestForm requestForm, HttpSession session);

	<T> String addSimplificationData(List<T> list);
	
	List<S4HanaProfiler_Download> getList(Long requestID, final int from, final int limit);

	String addEstimatorData(S4Estimations s4Estimations);

	String addAssumptionsData(S4Assumptions s4Assumptions);

	String addValidationData(List<S4ValidationList> validationDataS4List);

	<T> String addSimplificationDBData(List<T> list);

	Integer getTotalCountOfList(Long requestID);

	<T> String addDetectionData(List<T> list);
	
	String updateS4OperationIdentifier(long requestId);
	
	String updateOperDataFrmSimplDB(long requestId);
	
	String updateImpact(long requestId);

	<T> String addSimplificationDataS(List<T> list);

	String deleteOprDataS4(long requestId);

	String updateOperDataFrmSimplLatest(long requestId);

	List<S4CvitAssessment> getS4CvitAssessmentData(long requestId);
	
	public List<DrillDown_Download> getDrillDownReportList(Long requestID);
	
	public List<ObsoleteFmsDueToUpgrade> getObsoleteFmsUpgradeReportList(Long requestID);
}
