/*CR-No.    Desc     Date    Modified By
 * 
 * CR-26.0:- Make changes for Op-Code & show total scanned lines -05/09/17 -monika.mishra
 * 
 * CR-22.0:- Impacted Obj Type Should come from Detection file.-05/09/17 -monika.mishra
 * 
 * DEF075: Impacted IDOC New Requirements -17/05/2019 -himani.malhotra
 * */

package com.accenture.S4.dao;

import java.math.BigInteger;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;

import com.accenture.S4.models.DrillDown_Download;
import com.accenture.S4.models.ObsoleteFmsDueToUpgrade;
import com.accenture.S4.models.S4AffectCustomField;
import com.accenture.S4.models.S4Assumptions;
import com.accenture.S4.models.S4CloneProg;
import com.accenture.S4.models.S4CvitAssessment;
import com.accenture.S4.models.S4DetailReportComplexity;
import com.accenture.S4.models.S4DetailReportRemediation;
import com.accenture.S4.models.S4Detection;
import com.accenture.S4.models.S4Enhancement;
import com.accenture.S4.models.S4EnhancementIntermediate;
import com.accenture.S4.models.S4Estimations;
import com.accenture.S4.models.S4HanaProfiler;
import com.accenture.S4.models.S4HanaProfiler_Download;
import com.accenture.S4.models.S4InventoryList;
import com.accenture.S4.models.S4OutputMgmt;
import com.accenture.S4.models.S4SimplificationDatabase;
import com.accenture.S4.models.S4ValidationList;
import com.accenture.S4.models.SimplificationLatest;
import com.accenture.client.model.RequestForm;
import com.accenture.constant.Hana_Profiler_Constant;
import com.accenture.displaygrid.model.DBConfig;
import com.accenture.exceptions.HibernateException;
import com.accenture.fileprocessing.PopulateHanaTables;
import com.accenture.model.DRL.CodeAssessmentPayLoad;
import com.accenture.reader.xlsx.St03ReaderXlsx;
import com.accenture.utility.HANAUtility;

/**
 * @author monika.mishra
 *
 */
public class PopulatingS4FinalOutput implements PopulatingS4FinalOutputInterface {

	private PopulateHanaTables populateHanaTable;
	private PopulatingS4FinalOutputInterface s4daoIntf;

	public PopulatingS4FinalOutputInterface getS4daoIntf() {
		return s4daoIntf;
	}

	public void setS4daoIntf(PopulatingS4FinalOutputInterface s4daoIntf) {
		this.s4daoIntf = s4daoIntf;
	}

	SessionFactory sessionFactory;
	final static Logger logger = LoggerFactory.getLogger(PopulatingS4FinalOutput.class);
	private HibernateTemplate hibernateTemplate;

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

	public void setPopulateHanaTable(PopulateHanaTables populateHanaTable) {
		this.populateHanaTable = populateHanaTable;
	}

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public String createSimplification(long requestId) {
		String comment = "";
		long startTimefordeleteOprDataS4 = System.currentTimeMillis();
		comment = deleteOprDataS4(requestId);
		long endTimefordeleteOprDataS4 = System.currentTimeMillis();
		long netTimedeleteOprDataS4 = endTimefordeleteOprDataS4 - startTimefordeleteOprDataS4;
		logger.info("Total time for deleteOprDataS4: " + netTimedeleteOprDataS4);

		long startTimeforupdateS4OperationIdentifier = System.currentTimeMillis();
		comment = updateS4OperationIdentifier(requestId);
		long endTimeforupdateS4OperationIdentifier = System.currentTimeMillis();
		long netTimeupdateS4OperationIdentifier = endTimeforupdateS4OperationIdentifier
				- startTimeforupdateS4OperationIdentifier;
		logger.info("Total time for updateS4OperationIdentifier: " + netTimeupdateS4OperationIdentifier);

		/*
		 * long startTimeforupdateOperDataFrmSimplLatest = System.currentTimeMillis();
		 * comment=updateOperDataFrmSimplLatest(requestId); long
		 * endTimeforupdateOperDataFrmSimplLatest = System.currentTimeMillis(); long
		 * netTimeupdateOperDataFrmSimplLatest = endTimeforupdateOperDataFrmSimplLatest
		 * - startTimeforupdateOperDataFrmSimplLatest;
		 * logger.info("Total time for updateOperDataFrmSimplLatest: " +
		 * netTimeupdateOperDataFrmSimplLatest);
		 */
		long startTimeforupdateOperDataFrmSimplDB = System.currentTimeMillis();
		comment = updateOperDataFrmSimplDB(requestId);
		long endTimeforupdateOperDataFrmSimplDB = System.currentTimeMillis();
		long netTimeupdateOperDataFrmSimplDB = endTimeforupdateOperDataFrmSimplDB
				- startTimeforupdateOperDataFrmSimplDB;
		logger.info("Total time for updateOperDataFrmSimplDB: " + netTimeupdateOperDataFrmSimplDB);

		long startTimeforupdateImpact = System.currentTimeMillis();
		comment = updateImpact(requestId);
		long endTimeforupdateImpact = System.currentTimeMillis();
		long netTimeupdateImpactB = endTimeforupdateImpact - startTimeforupdateImpact;
		logger.info("Total time for updateImpact: " + netTimeupdateImpactB);
		return comment;
	}

	@Override
	public boolean getS4HanaProfilerFinalList(long requestId, RequestForm requestForm, HttpSession session) {

		Boolean refiningStatus = false;
		try {

			long startTimeforcreateSimplification = System.currentTimeMillis();
			createSimplification(requestId);
			long endTimeforcreateSimplification = System.currentTimeMillis();
			long netTimecreateSimplification = endTimeforcreateSimplification - startTimeforcreateSimplification;
			logger.info("Total time for create simplification: " + netTimecreateSimplification);
			logger.info("simplification DONE%%%%%%%%%%%%%%%%%%");

			long startTimeforManualUpdate = System.currentTimeMillis();
			Map<String,Boolean> sapNotes=manualUpdate(requestId, session);
			long endTimeforManualUpdate = System.currentTimeMillis();
			long netTimeforManualUpdate = endTimeforManualUpdate - startTimeforManualUpdate;
			logger.info("Total time in Manual Update: " + netTimeforManualUpdate);
			logger.info("Manual Update DONE%%%%%%%%%%%%%%%%%%");

			long startTimeforupdateFrmOprData = System.currentTimeMillis();
			updateFrmOprData(requestId);
			long endTimeforupdateFrmOprData = System.currentTimeMillis();
			long netTimeupdateFrmOprData = endTimeforupdateFrmOprData - startTimeforupdateFrmOprData;
			logger.info("Total time for updateFrmOprData: " + netTimeupdateFrmOprData);
			logger.info("SimplificationList values got updated in Final Output%%%%%%%%%%%%%%%%%%%%%%%");

			// method to combine data of inventory+ lsmw+ userExit.
			// updateInventoryData(requestId);

			// Updated S4detection pojo to read usage while reading ZaicatDetection file
			// updateUsage(requestId);

			logger.info("updateUsage values got updated in Final Output%%%%%%%%%%%%%%%%%%%%%%%");

			// long netTimeFetchingOutput = endTime - startTime;
			// logger.info("Total time in fetching Final Output: " + netTimeFetchingOutput);
			refiningStatus = true;

			// updateInventoryUsage(requestId);
			// logger.info("updateInventoryUsage values got updated in Final
			// Output%%%%%%%%%%%%%%%%%%%%%%%");

			// CR-61.0
			long startTimeforupdateObjType = System.currentTimeMillis();
			updateObjType(requestId);
			long endTimeforupdateObjType = System.currentTimeMillis();
			long netTimeupdateObjType = endTimeforupdateObjType - startTimeforupdateObjType;
			logger.info("Total time for updateObjType: " + netTimeupdateObjType);
			logger.info("updateInventoryUsage values got updated in Final Output%%%%%%%%%%%%%%%%%%%%%%%");

			// DEF091
			long startTimeforupdateS4PackageFromInventory = System.currentTimeMillis();
			updateS4PackageFromInventory(requestId, session);
			long endTimeforupdateS4PackageFromInventory = System.currentTimeMillis();
			long netTimeupdateS4PackageFromInventory = endTimeforupdateS4PackageFromInventory
					- startTimeforupdateS4PackageFromInventory;
			logger.info("Total time for updateS4PackageFromInventory: " + netTimeupdateS4PackageFromInventory);
			logger.info("updateS4PackageFromInventory values got updated %%%%%%%%%%%%%%%%%%%%%%%");

			long startTimeforupdateComplexity = System.currentTimeMillis();
			//updateComplexity(requestId);
			long endTimeforupdateComplexity = System.currentTimeMillis();
			long netTimeupdateComplexity = endTimeforupdateComplexity - startTimeforupdateComplexity;
			logger.info("Total time for updateComplexity: " + netTimeupdateComplexity);
			logger.info("updateComplexity values got updated in Final Output%%%%%%%%%%%%%%%%%%%%%%%");

			//updateComplexityFromOperationsRemediation(requestId);
			
			// Updating Complexity - New Rules Checklist
			updateRulesChecklistComplexity(requestId);
			
			// ALE-FLE Logic
			updateIssueSubCategoryFrmOperation(requestId);	
			updateRemedCatAndIssueSubCatFromAleFle(requestForm, requestId);
			
			// CR-42.0
			// updateImpactedIDOC(requestId);
			// logger.info("updateImpactedIDOC values got updated in Detail
			// Report%%%%%%%%%%%%%%%%%%%%%%%");
			// DEF075
			long startTimeforupdateIDOCImpacted = System.currentTimeMillis();
			updateIDOCImpacted(requestId);
			long endTimeforupdateIDOCImpacted = System.currentTimeMillis();
			long netTimeupdateIDOCImpacted = endTimeforupdateIDOCImpacted - startTimeforupdateIDOCImpacted;
			logger.info("Total time for updateIDOCImpacted: " + netTimeupdateIDOCImpacted);
			logger.info("updateImpactedIDOC values got updated in Detail Report%%%%%%%%%%%%%%%%%%%%%%%");
			// CR-41.0
			long startTimeforupdateImpactedTables = System.currentTimeMillis();
			updateImpactedTables(requestId);
			long endTimeforupdateImpactedTables = System.currentTimeMillis();
			long netTimeupdateImpactedTables = endTimeforupdateImpactedTables - startTimeforupdateImpactedTables;
			logger.info("Total time for updateImpactedTables: " + netTimeupdateImpactedTables);
			// CR-47.0
			long startTimeforupdateImpactedTransaction = System.currentTimeMillis();
			updateImpactedTransaction(requestId, session);
			long endTimeforupdateImpactedTransaction = System.currentTimeMillis();
			long netTimeupdateImpactedTransaction = endTimeforupdateImpactedTransaction
					- startTimeforupdateImpactedTransaction;
			logger.info("Total time for updateImpactedTransaction: " + netTimeupdateImpactedTransaction);
			logger.info("updateImpactedTransaction values got updated in Detail Report%%%%%%%%%%%%%%%%%%%%%%%");

			/*
			 * long startTimeforupdateCloneProgAnalysis = System.currentTimeMillis();
			 * updateCloneProgAnalysis(requestId); long endTimeforupdateCloneProgAnalysis =
			 * System.currentTimeMillis(); long netTimeupdateCloneProgAnalysis =
			 * endTimeforupdateCloneProgAnalysis - startTimeforupdateCloneProgAnalysis;
			 * logger.info("Total time for updateCloneProgAnalysis: " +
			 * netTimeupdateCloneProgAnalysis); logger.
			 * info("updateCloneProgAnalysis values got updated %%%%%%%%%%%%%%%%%%%%%%%");
			 */

			// DEF035
			long startTimeforupdateS4Enhancement = System.currentTimeMillis();
			updateS4Enhancement(requestId, session);
			long endTimeforupdateS4Enhancement = System.currentTimeMillis();
			long netTimeupdateS4Enhancement = endTimeforupdateS4Enhancement - startTimeforupdateS4Enhancement;
			logger.info("Total time for updateS4Enhancement: " + netTimeupdateS4Enhancement);
			logger.info("updateEnhancement values got updated %%%%%%%%%%%%%%%%%%%%%%%");

			// CR-44.0
			long startTimeforupdateAffectCustom = System.currentTimeMillis();
			updateAffectCustom(requestId,sapNotes);
			long endTimeforupdateAffectCustom = System.currentTimeMillis();
			long netTimeupdateAffectCustom = endTimeforupdateAffectCustom - startTimeforupdateAffectCustom;
			logger.info("Total time for updateAffectCustom: " + netTimeupdateAffectCustom);
			logger.info("updateAffectCustom values got updated %%%%%%%%%%%%%%%%%%%%%%%");
			// CR-45.0
			long startTimeforupdateOutputManagement = System.currentTimeMillis();
			updateOutputManagement(requestId);
			long endTimeforupdateOutputManagement = System.currentTimeMillis();
			long netTimeupdateOutputManagement = endTimeforupdateOutputManagement - startTimeforupdateOutputManagement;
			logger.info("Total time for updateOutputManagement: " + netTimeupdateOutputManagement);
			logger.info("updateOutputManagement values got updated %%%%%%%%%%%%%%%%%%%%%%%");

			// need to check it with Uma and then comment below
			// Commenting below code because we are not using Dr2 and DR3 here.
			/*
			 * long startTimeforupdateDetailReport = System.currentTimeMillis();
			 * updateDetailReport(requestId); long endTimeforupdateDetailReport =
			 * System.currentTimeMillis(); long netTimeupdateDetailReport =
			 * endTimeforupdateDetailReport - startTimeforupdateDetailReport;
			 * logger.info("Total time for updateDetailReport: " +
			 * netTimeupdateDetailReport); logger.
			 * info("updateDetailReport values got updated in Detail Report%%%%%%%%%%%%%%%%%%%%%%%"
			 * );
			 * 
			 * long startTimeforupdateDetailRemediReport = System.currentTimeMillis();
			 * updateDetailRemediReport(requestId); long endTimeforupdateDetailRemediReport
			 * = System.currentTimeMillis(); long netTimeupdateDetailRemediReport =
			 * endTimeforupdateDetailRemediReport - startTimeforupdateDetailRemediReport;
			 * logger.info("Total time for updateDetailRemediReportt: " +
			 * netTimeupdateDetailRemediReport); logger.
			 * info("updateDetailRemediReport values got updated in Detail Report%%%%%%%%%%%%%%%%%%%%%%%"
			 * );
			 */

			/*
			 * updateDetailReportINDE(requestId); logger.
			 * info("updateDetailReportINDE values got updated in Detail Report%%%%%%%%%%%%%%%%%%%%%%%"
			 * );
			 */
			// updateImpactedObjList(requestId);
			// logger.info("updateImpactedObjList values got updated
			// %%%%%%%%%%%%%%%%%%%%%%%");
			insertDataImpactedCustomTables(requestId);

		} catch (Exception e) {
			logger.error("Exception in get_List_with_HanaProfiler_Final_Sheet_Data method" + e.getStackTrace());
			refiningStatus = false;
		}
		return refiningStatus;
	}
	
	private void updateRulesChecklistComplexity(long requestId) {
		Session session = null;
		Transaction tx = null;
		
		try {
			logger.info("Updating S4 Complexity - Start ...");
			
			String strQuery = "UPDATE S4_Final_Output SET complexity = " 
					+ "CASE " 
						+ "WHEN IMPACTED_OBJ_TYPE = 'CLAS' AND OPERATIONS = 'CLAS' " 
						+ "THEN 'MEDIUM' " 
						+ "WHEN IMPACTED_OBJ_TYPE = 'DATA ELEMENT' " 
						+ "THEN " 
							+ "CASE " 
								+ "WHEN OPERATIONS IN ('ASSIGNMENT', 'BAPI', 'CONCATENATE', 'CUSTOM VIEWS', "
								                    + "'DATA DECLARATION', 'EXPONENTIAL OPERATOR', " 
								                    + "'IMPACTED WRITE STATEMENT', 'INCOMPATIBLE CLASS PARAMETERS', "
								                    + "'LOOP WHERE COND', 'MAT_LEN_EXT', 'OFFSET', 'PERFORM', "
								                    + "'READ WITH COND', 'REPLACE', 'SELECT LIST', 'SELECT STATEMENT', "
								                    + "'SELECT WHERE COND', 'VALUE ASSIGNMENT', "
								                    + "'WHERE COND IN FOR ALL ENTRIES') " 
								+ "THEN 'LOW' " 
								+ "WHEN OPERATIONS = 'INCOMPATIBLE FM PARAMETERS' AND IMPACT_REASON LIKE '%FM_PARAMETERS-INCOMPATIBLE PARAMETERS%' " 
								+ "THEN 'LOW' " 
								+ "ELSE complexity "
							+ "END " 
						+ "WHEN IMPACTED_OBJ_TYPE = 'DOMAIN' "
						+ "THEN "
							+ "CASE "
								+ "WHEN OPERATIONS IN ('ASSIGNMENT', 'DATA DECLARATION', "
														+ "'IMPACTED DATA ELEMENTS', "
														+ "'INCOMPATIBLE FM PARAMETERS', " 
														+ "'LOOP WHERE COND', 'CONCATENATE', "
														+ "'PERFORM', 'READ WITH COND') " 
								+ "THEN 'LOW' "
								+ "WHEN OPERATIONS = 'IMPACTED WRITE STATEMENT' "
								+ "THEN 'MEDIUM' "
								+ "ELSE complexity "
							+ "END " 
						+ "WHEN IMPACTED_OBJ_TYPE = 'FUNCTION GROUP' AND OPERATIONS = 'FUNCTION MODULE' " 
						+ "THEN " 
							+ "CASE " 
								+ "WHEN ISSUE_CATEGORY = 'DATA ELEMENT LENGTH EXTENSION' " 
								+ "THEN 'LOW' " 
								+ "WHEN SAP_SIMPL_CATEGORY = 'Functionality Not Available: Functional Equivalent Available' "
								+ "THEN 'HIGH' " 
								+ "WHEN SAP_SIMPL_CATEGORY = 'Functionality Not Available: No Functional Equivalent' "
					            + "THEN 'MEDIUM' " 
					            + "WHEN SAP_SIMPL_CATEGORY IN ('Change Of Existing Functionality', 'Non-Strategic-Function: Functional Equivalent Available', " 
															   + "'Non-Strategic-Function: No Functional Equivalent') " 
							    + "THEN 'LOW' " 
							    + "ELSE complexity "
							+ "END " 
						+ "WHEN IMPACTED_OBJ_TYPE = 'FUNCTION MODULE' AND OPERATIONS IN ('BAPI', 'FUNCTION MODULE') " 
						+ "THEN " 
							+ "CASE " 
								+ "WHEN ISSUE_CATEGORY = 'DATA ELEMENT LENGTH EXTENSION' " 
							    + "THEN 'LOW' "
							    + "WHEN SAP_SIMPL_CATEGORY = 'Functionality Not Available: Functional Equivalent Available' "
							    + "THEN 'MEDIUM' " 
							    + "WHEN SAP_SIMPL_CATEGORY = 'Functionality Not Available: No Functional Equivalent' " 
							    + "THEN 'MEDIUM' " 
							    + "WHEN SAP_SIMPL_CATEGORY IN ('Change Of Existing Functionality', 'Non-Strategic-Function: Functional Equivalent Available', "
							    							 + "'Non-Strategic-Function: No Functional Equivalent') " 
							    + "THEN 'LOW' " 
							    + "ELSE complexity "
    						+ "END " 
    				   + "WHEN IMPACTED_OBJ_TYPE = 'IDOC' AND OPERATIONS = 'IDOC FM' " 
    				   + "THEN 'MEDIUM' " 
    				   + "WHEN IMPACTED_OBJ_TYPE = 'MESSAGE CLASS' AND OPERATIONS = 'MESSAGE CLASS' " 
    				   + "THEN 'LOW' " 
    				   + "WHEN IMPACTED_OBJ_TYPE = 'PROGRAM' AND OPERATIONS IN ('INCLUDE', 'SUBMIT PROGRAM') " 
    				   + "THEN 'HIGH' " 
    				   + "WHEN IMPACTED_OBJ_TYPE = 'RFC SERVICE' AND OPERATIONS = 'FUNCTION MODULE' " 
    				   + "THEN " 
    				   		+ "CASE " 
    				   			+ "WHEN SAP_SIMPL_CATEGORY = 'Functionality Not Available: Functional Equivalent Available' " 
    				   			+ "THEN 'HIGH' " 
    				   			+ "WHEN SAP_SIMPL_CATEGORY = 'Functionality Not Available: No Functional Equivalent' "
    				   			+ "THEN 'MEDIUM' " 
    				   			+ "WHEN SAP_SIMPL_CATEGORY IN ('Change Of Existing Functionality', 'Non-Strategic-Function: Functional Equivalent Available', " 
    				   										+ "'Non-Strategic-Function: No Functional Equivalent') " 
    				   			+ "THEN 'LOW' " 
	   							+ "ELSE complexity "
    				   		+ "END " 
    				   	+ "WHEN IMPACTED_OBJ_TYPE = 'REPORT SOURCE' AND OPERATIONS = 'INCLUDE' " 
    				   	+ "THEN 'MEDIUM' " 
    				   	+ "WHEN IMPACTED_OBJ_TYPE = 'SEARCH HELP' AND OPERATIONS = 'READ WITH COND' " 
    				   	+ "THEN 'LOW' " 
    				   	+ "WHEN IMPACTED_OBJ_TYPE = 'TABLE' " 
    				   	+ "THEN " 
    				   		+ "CASE " 
    				   			+ "WHEN OPERATIONS IN ('CUSTOM VIEWS', 'DATA DECLARATION', 'IMPACTED ABAP QUERIES', 'PERFORM', 'READ WITH COND', " 
    				   								+ "'REPORT PAINTER', 'SELECT LIST', 'SELECT STATEMENT', 'SELECT WHERE COND') " 
    				   			+ "THEN 'LOW' " 
    				   			+ "WHEN OPERATIONS IN ('UPDATE/DELETE', 'WRITE') " 
    				   			+ "THEN 'MEDIUM' "
    				   			+ "ELSE complexity "
    				   		+ "END " 
    				   	+ "WHEN IMPACTED_OBJ_TYPE = 'TABLE TYPE' AND OPERATIONS = 'PERFORM' " 
    				   	+ "THEN 'LOW' " 
    				   	+ "WHEN IMPACTED_OBJ_TYPE = 'TRANSACTION' " 
    				   	+ "THEN " 
    				   		+ "CASE "  
    				   			+ "WHEN OPERATIONS = 'BDC' " 
    				   			+ "THEN 'HIGH' " 
    				   			+ "WHEN OPERATIONS = 'CALL TRANSACTION' " 
    				   			+ "THEN " 
    				   				+ "CASE " 
    				   					+ "WHEN STMT LIKE '%BDC%' " 
    				   					+ "THEN 'HIGH' " 
    				   					+ "WHEN STMT LIKE '%SKIP FIRST SCREEN%' " 
    				   					+ "THEN 'LOW' " 
    				   					+ "ELSE 'MEDIUM' " 
    				   				+ "END " 
    				   			+ "WHEN OPERATIONS IN ('ASSIGNMENT', 'PERFORM', 'SELECT WHERE COND') " 
    				   			+ "THEN 'LOW' " 
    				   			+ "ELSE complexity "
    				   		+ "END " 
    				   	+ "WHEN IMPACTED_OBJ_TYPE = 'VIEW' AND OPERATIONS IN ('SELECT LIST', 'SELECT STATEMENT') " 
    				   	+ "THEN 'LOW' " 
    				   	+ "ELSE complexity "
					+ "END "
				+ ",Remediation_Category = "
					+ "CASE "
						+ "WHEN IMPACTED_OBJ_TYPE = 'DOMAIN' AND OPERATIONS = 'IMPACTED WRITE STATEMENT' "
						+ "THEN 'MANDATORY' "
						+ "WHEN IMPACTED_OBJ_TYPE = 'TABLE' AND OPERATIONS = 'WRITE' "
						+ "THEN 'MANDATORY'"
						+ "ELSE Remediation_Category "
					+ "END "
				+ ", ERROR_CATEGORY= " 
					+ "CASE "
						+ "WHEN IMPACTED_OBJ_TYPE = 'TABLE' AND OPERATIONS = 'WRITE' AND Obsolete = 'Y' "
						+ "THEN 'SYNTAX'"
						+ "WHEN IMPACTED_OBJ_TYPE = 'TABLE' AND OPERATIONS = 'WRITE' AND Obsolete = 'N' "
						+ "THEN 'SEMANTIC'"
						+ "ELSE ERROR_CATEGORY "
					+ "END " 
    				+ "WHERE REQUEST_ID =:requestId";
			
			session = sessionFactory.openSession(); 
			tx = session.beginTransaction();
			
			Query query = session.createSQLQuery(strQuery);
			query.setParameter("requestId", requestId);
			
			query.executeUpdate();
			
			tx.commit();
		} catch (Exception e) {
			if(tx != null)
				tx.rollback();
			
			logger.error("Error while updating S4 Complexity : ", e);
		} finally {
			if(session != null)
				session.close();
		}
		
		logger.info("Updating S4 Complexity - End ...");
	}

	private void updateRemedCatAndIssueSubCatFromAleFle(RequestForm requestForm, long requestId) {
		if ("No".equalsIgnoreCase(requestForm.getFle()) || "future_roadmap".equalsIgnoreCase(requestForm.getFle())) {
			updateRemedCatAndIssueSubCatFromFle(requestForm, requestId);
		}
		
		if ("No".equalsIgnoreCase(requestForm.getAle()) || "future_roadmap".equalsIgnoreCase(requestForm.getAle())) {
			updateRemedCatAndIssueSubCatFromAle(requestForm, requestId);
		}
	}
	
	private void updateRemedCatAndIssueSubCatFromFle(RequestForm requestForm, long requestId) {
		logger.info("updateRemedCatAndIssueSubCatFromFle - Start ...");
		
		try {
			String strQuery = "";
			
			if ("No".equalsIgnoreCase(requestForm.getFle())) {
				strQuery = "UPDATE s4_final_output SET "
						+ "Remediation_Category = "
						+ "CASE "
							+ "WHEN DESC_OF_CHANGE = 'MATERIAL LENGTH EXTENSIONS' " 
							+ "THEN CASE "
								+ "WHEN OPERATIONS IN ('INCOMPATIBLE FM PARAMETERS', 'INCOMPATIBLE CLASS PARAMETERS', 'BAPI', "
								+ "'Function Module', 'WHERE COND IN FOR ALL ENTRIES') " 
								+ "THEN 'MANDATORY' "
								+ "ELSE 'OPTIONAL' END "
							+ "ELSE Remediation_Category END "
						+ ", "
						+ "ERROR_CATEGORY = "
						+ "CASE "
							+ "WHEN DESC_OF_CHANGE = 'MATERIAL LENGTH EXTENSIONS' " 
						    + "THEN CASE " 
						    	+ "WHEN OPERATIONS NOT IN ('INCOMPATIBLE FM PARAMETERS', 'INCOMPATIBLE CLASS PARAMETERS', 'BAPI', "
								+ "'Function Module', 'WHERE COND IN FOR ALL ENTRIES') "
						    	+ "THEN 'INFORMATION' "
								+ "ELSE ERROR_CATEGORY END "
						    + "ELSE ERROR_CATEGORY END "
						+ "WHERE REQUEST_ID = :requestId";	
			} else if ("future_roadmap".equalsIgnoreCase(requestForm.getFle())) {
				strQuery = "UPDATE s4_final_output SET "
						+ "Remediation_Category = "
						+ "CASE "
							+ "WHEN DESC_OF_CHANGE = 'MATERIAL LENGTH EXTENSIONS' " 
							+ "THEN CASE "
								+ "WHEN OPERATIONS IN ('INCOMPATIBLE FM PARAMETERS', 'INCOMPATIBLE CLASS PARAMETERS', 'BAPI', "
								+ "'Function Module', 'WHERE COND IN FOR ALL ENTRIES') " 
								+ "THEN 'MANDATORY' "
								+ "ELSE 'OPTIONAL' END "
							+ "ELSE Remediation_Category END "
						+ ", "
						+ "ERROR_CATEGORY = "
						+ "CASE "
							+ "WHEN DESC_OF_CHANGE = 'MATERIAL LENGTH EXTENSIONS' " 
						    + "THEN CASE " 
						    	+ "WHEN OPERATIONS NOT IN ('INCOMPATIBLE FM PARAMETERS', 'INCOMPATIBLE CLASS PARAMETERS', 'BAPI', "
								+ "'Function Module', 'WHERE COND IN FOR ALL ENTRIES') "
						    	+ "THEN 'INFORMATION' "
								+ "ELSE ERROR_CATEGORY END "
						    + "ELSE ERROR_CATEGORY END "
						    + ", "
						    + "SOLUTION_STEPS = "
						    + "CASE "
						    + "WHEN DESC_OF_CHANGE = 'MATERIAL LENGTH EXTENSIONS' " 
						    + "THEN CASE " 
						    	+ "WHEN OPERATIONS NOT IN ('INCOMPATIBLE FM PARAMETERS', 'INCOMPATIBLE CLASS PARAMETERS', 'BAPI', "
								+ "'Function Module', 'WHERE COND IN FOR ALL ENTRIES') "
						    	+ "THEN CONCAT(SOLUTION_STEPS, 'TOOL RECOMMENDATION : Statement would be Impacted on opting Field Length Extension Activation') "
								+ "ELSE SOLUTION_STEPS END "
						    + "ELSE SOLUTION_STEPS END "
						+ "WHERE REQUEST_ID = :requestId";
			}
			
			Session session = this.hibernateTemplate.getSessionFactory().openSession();
			Query query = session.createSQLQuery(strQuery);
			query.setParameter("requestId", requestId);
			query.executeUpdate();
			session.close();
		} catch (Exception e) {
			logger.error("Error in updateRemedCatAndIssueSubCatFromFle() :: ", e);
		}
		
		logger.info("updateRemedCatAndIssueSubCatFromFle - End ...");
	}
	
	private void updateRemedCatAndIssueSubCatFromAle(RequestForm requestForm, long requestId) {
		logger.info("updateRemedCatAndIssueSubCatFromAle - Start ...");
		
		try {
			String strQuery = "";
			
			if ("No".equalsIgnoreCase(requestForm.getAle())) {
				strQuery = "UPDATE s4_final_output SET "
						+ "Remediation_Category = "
						+ "CASE "
							+ "WHEN DESC_OF_CHANGE = 'AMOUNT FIELD LENGTH EXTENSION' " 
							+ "THEN CASE "
								+ "WHEN OPERATIONS IN ('INCOMPATIBLE FM PARAMETERS', 'INCOMPATIBLE CLASS PARAMETERS', 'BAPI', "
								+ "'Function Module', 'WHERE COND IN FOR ALL ENTRIES') " 
								+ "THEN 'MANDATORY' "
								+ "ELSE 'OPTIONAL' END "
							+ "ELSE Remediation_Category END "
						+ ", "
						+ "ERROR_CATEGORY = "
						+ "CASE "
							+ "WHEN DESC_OF_CHANGE = 'AMOUNT FIELD LENGTH EXTENSION' " 
						    + "THEN CASE " 
						    	+ "WHEN OPERATIONS NOT IN ('INCOMPATIBLE FM PARAMETERS', 'INCOMPATIBLE CLASS PARAMETERS', 'BAPI', "
								+ "'Function Module', 'WHERE COND IN FOR ALL ENTRIES') "
						    	+ "THEN 'INFORMATION' "
								+ "ELSE ERROR_CATEGORY END "
						    + "ELSE ERROR_CATEGORY END "
						+ "WHERE REQUEST_ID = :requestId";
			} else if ("future_roadmap".equalsIgnoreCase(requestForm.getAle())) {
				strQuery = "UPDATE s4_final_output SET "
						+ "Remediation_Category = "
						+ "CASE "
							+ "WHEN DESC_OF_CHANGE = 'AMOUNT FIELD LENGTH EXTENSION' " 
							+ "THEN CASE "
								+ "WHEN OPERATIONS IN ('INCOMPATIBLE FM PARAMETERS', 'INCOMPATIBLE CLASS PARAMETERS', 'BAPI', "
								+ "'Function Module', 'WHERE COND IN FOR ALL ENTRIES') " 
								+ "THEN 'MANDATORY' "
								+ "ELSE 'OPTIONAL' END "
							+ "ELSE Remediation_Category END "
						+ ", "
						+ "ERROR_CATEGORY = "
						+ "CASE "
							+ "WHEN DESC_OF_CHANGE = 'AMOUNT FIELD LENGTH EXTENSION' " 
						    + "THEN CASE " 
						    	+ "WHEN OPERATIONS NOT IN ('INCOMPATIBLE FM PARAMETERS', 'INCOMPATIBLE CLASS PARAMETERS', 'BAPI', "
								+ "'Function Module', 'WHERE COND IN FOR ALL ENTRIES') "
						    	+ "THEN 'INFORMATION' "
								+ "ELSE ERROR_CATEGORY END "
						    + "ELSE ERROR_CATEGORY END "
						    + ", "
						    + "SOLUTION_STEPS = "
						    + "CASE "
						    + "WHEN DESC_OF_CHANGE = 'AMOUNT FIELD LENGTH EXTENSION' " 
						    + "THEN CASE " 
						    	+ "WHEN OPERATIONS NOT IN ('INCOMPATIBLE FM PARAMETERS', 'INCOMPATIBLE CLASS PARAMETERS', 'BAPI', "
								+ "'Function Module', 'WHERE COND IN FOR ALL ENTRIES') "
						    	+ "THEN CONCAT(SOLUTION_STEPS, 'TOOL RECOMMENDATION : Statement would be Impacted on opting Amount Field Length Extension Activation') "
								+ "ELSE SOLUTION_STEPS END "
						    + "ELSE SOLUTION_STEPS END "
						+ "WHERE REQUEST_ID = :requestId";
			}
			
			Session session = this.hibernateTemplate.getSessionFactory().openSession();
			Query query = session.createSQLQuery(strQuery);
			query.setParameter("requestId", requestId);
			query.executeUpdate();
			session.close();
		} catch (Exception e) {
			logger.error("Error in updateRemedCatAndIssueSubCatFromAle() :: ", e);
		}
		
		logger.info("updateRemedCatAndIssueSubCatFromAle - End ...");
	}
	
	private void updateIssueSubCategoryFrmOperation(long requestId) {
		logger.info("updateIssueSubCategoryFrmOperation - End ...");
		try {
			String strQuery = "update S4_Final_Output set ERROR_CATEGORY='INFORMATION', "
					+ "Remediation_Category='OPTIONAL' where OPERATIONS='IMPACTED DATA ELEMENTS' and REQUEST_ID=:requestId";
			Session session = this.hibernateTemplate.getSessionFactory().openSession();
			Query query = session.createSQLQuery(strQuery);
			query.setParameter("requestId", requestId);
			query.executeUpdate();
			session.close();
		} catch (Exception e) {
			logger.error("Error in updateIssueSubCategoryFrmOperation() :: ", e);
		}
		
		logger.info("updateIssueSubCategoryFrmOperation - End ...");
	}
	
	public void updateComplexityFromOperationsRemediation(long requestId) {
		try {
			logger.info("updateComplexityFromOperationsRemediation Start :: ");
			String strQuery = "update  s4_final_output set complexity=case WHEN OPERATIONS ='SYSTEM INDEX' AND Remediation_Category ='OPTIONAL' THEN 'VERY LOW' "
					+ " WHEN OPERATIONS ='SYSTEM INDEX' AND Remediation_Category ='MANDATORY' THEN 'LOW' "
					+ " WHEN OPERATIONS ='DATA DECLARATION' THEN 'LOW' " + " WHEN OPERATIONS ='ASSIGNMENT' THEN 'LOW' "
					+ " WHEN OPERATIONS ='FUNCTION MODULE' AND Remediation_Category ='OPTIONAL' THEN 'LOW' "
					+ " WHEN OPERATIONS ='FUNCTION MODULE' AND Remediation_Category ='MANDATORY' AND ISSUE_CATEGORY='DATA ELEMENT LENGTH EXTENSION' THEN 'LOW'   "
					+ " WHEN OPERATIONS ='SELECT LIST' THEN 'LOW' "
					+ " WHEN OPERATIONS ='SELECT STATEMENT' THEN 'LOW'  "
					+ " WHEN OPERATIONS ='SELECT WHERE COND' THEN 'LOW' "
					+ " WHEN OPERATIONS ='CONCATENATE' THEN 'LOW' " + " WHEN OPERATIONS ='DATA ELEMENT' THEN 'LOW' "
					+ " WHEN OPERATIONS ='BAPI' AND Remediation_Category ='OPTIONAL' THEN 'LOW' "
					+ " WHEN OPERATIONS ='BAPI' AND Remediation_Category ='MANDATORY' AND ISSUE_CATEGORY='DATA ELEMENT LENGTH EXTENSION' THEN 'LOW' "
					+ " WHEN IMPACTED_OBJ_TYPE='TRANSACTION' AND OPERATIONS ='CALL TRANSACTION' AND Remediation_Category ='MANDATORY' THEN 'MEDIUM' "
					+ " WHEN OPERATIONS ='CONSTANT DECLARATION' THEN 'LOW' " + " WHEN OPERATIONS ='OFFSET' THEN 'LOW' "
					+ " WHEN OPERATIONS ='PERFORM' THEN 'LOW' " + " WHEN OPERATIONS ='DATA ELEMENT OFFSET' THEN 'LOW' "
					+ " WHEN OPERATIONS ='WRITE' AND Remediation_Category ='MANDATORY' THEN 'MEDIUM' "
					+ " WHEN IMPACTED_OBJ_TYPE='TRANSACTION' AND OPERATIONS ='BDC' AND Remediation_Category ='MANDATORY' THEN 'HIGH' "
					+ " WHEN OPERATIONS ='BDC Screen field' AND Remediation_Category ='MANDATORY' THEN 'MEDIUM' "
					+ " WHEN OPERATIONS ='CUSTOM VIEWS' THEN 'LOW' "
					+ " WHEN OPERATIONS ='VALUE ASSIGNMENT' THEN 'LOW' "
					+ " WHEN OPERATIONS ='SUBMIT PROGRAM' THEN 'LOW' "
					+ " WHEN OPERATIONS ='INCLUDE' THEN 'LOW' ELSE complexity END, "
					+ " Remediation_Category = CASE WHEN IMPACT_REASON = 'FM_PARAMETERS' THEN 'MANDATORY' ELSE Remediation_Category END  "
					+ " where OPERATIONS in ('SYSTEM INDEX','DATA DECLARATION','ASSIGNMENT','FUNCTION MODULE','SELECT LIST','SELECT STATEMENT','SELECT WHERE COND','CONCATENATE','DATA ELEMENT','BAPI','CALL TRANSACTION','CONSTANT DECLARATION','OFFSET','PERFORM','DATA ELEMENT OFFSET','WRITE','BDC','BDC Screen field','CUSTOM VIEWS','VALUE ASSIGNMENT','SUBMIT PROGRAM','INCLUDE')  and  s4_final_output.REQUEST_ID=:requestId";
			Session session = this.hibernateTemplate.getSessionFactory().openSession();
			Query query = session.createSQLQuery(strQuery);
			query.setParameter("requestId", requestId);
			query.executeUpdate();
			session.close();
		} catch (Exception e) {
			logger.error("Error in updateComplexityFromOperationsRemediation() :: ", e);
		}
		logger.info("updateComplexityFromOperationsRemediation End :: ");
	}

	private void updateIDOCImpacted(long requestId) {
		// TODO Auto-generated method stub
		String updateImpactedIDOC = "update S4_IMPACTED_IDOC s4IDOC INNER JOIN s4_simplification_database simpliDb on s4IDOC.Identifier=simpliDb.Identifier set s4IDOC.IMPACTED_OBJECT_TYPE=simpliDb.Object_Type, s4IDOC.IMPACTED_OBJECT_NAME=simpliDb.Object, s4IDOC.DESCRIPTION=simpliDb.Description, s4IDOC.SOLUTION=simpliDb.Solution_Steps, s4IDOC.NOTE_NUMBER=simpliDb.Related_Notes,s4IDOC.REQUEST_ID="
				+ requestId + " where s4IDOC.REQUEST_ID=" + requestId;
		long startTimeforupdateFrmTables = System.currentTimeMillis();
		updateFrmTables(updateImpactedIDOC);
		long endTimeforupdateFrmTables = System.currentTimeMillis();
		long netTimeupdateFrmTables = endTimeforupdateFrmTables - startTimeforupdateFrmTables;
		logger.info("Total time for updateFrmTables: " + netTimeupdateFrmTables);

	}

	private void updateInventoryData(long requestId) {
		String frmLSMW = "INSERT INTO S4_Inventory_List (OBJ_TYPE, OBJ_NAME,OBJ_NAME_TYPE,REQUEST_ID) SELECT OBJ_TYPE, OBJ_NAME,OBJ_NAME_TYPE,REQUEST_ID FROM LSMW where REQUEST_ID= "
				+ requestId;
		String frmUserExit = "INSERT INTO S4_Inventory_List (OBJ_TYPE, OBJ_NAME,OBJ_NAME_TYPE,REQUEST_ID) SELECT OBJ_TYPE, OBJ_NAME,OBJ_NAME_TYPE,REQUEST_ID FROM USER_EXIT where REQUEST_ID= "
				+ requestId;
		updateFrmTables(frmLSMW);
		updateFrmTables(frmUserExit);
	}

	private void updateObjType(long requestId) {
		String updateFinalOutput = "update s4_final_output set TYPE= 'LSMW' where TYPE = 'PROG' and OBJ_NAME like ('/1CADMC/SAP_LSMW_CONV_%')  and request_id= "
				+ requestId;
		/*
		 * String
		 * updateInventory="update S4_Inventory_List set OBJ_TYPE= 'LSMW' where OBJ_TYPE = 'PROG' and OBJ_NAME like ('/%')  and REQUEST_ID= "
		 * +requestId;
		 */
		String updateFinalOutputUserExit = "update s4_final_output s4FinalOutput INNER JOIN USER_EXIT userExit on s4FinalOutput.OBJ_NAME=userExit.OBJ_NAME set s4FinalOutput.TYPE='USER Exit' where s4FinalOutput.REQUEST_ID= "
				+ requestId + " and userExit.REQUEST_ID=" + requestId;
		/*
		 * String
		 * updateInventoryUserExit="update S4_Inventory_List s4InventoryList INNER JOIN USER_EXIT userExit on s4InventoryList.OBJ_NAME=userExit.OBJ_NAME set s4InventoryList.OBJ_TYPE='USER Exit' where s4InventoryList.REQUEST_ID= "
		 * +requestId +" and userExit.REQUEST_ID=" +requestId ;
		 */
		long startTimeforupdateFrmTablesupdateFinalOutput = System.currentTimeMillis();
		updateFrmTables(updateFinalOutput);
		long endTimeforupdateFrmTablesupdateFinalOutput = System.currentTimeMillis();
		long netTimeupdateFrmTablesupdateFinalOutput = endTimeforupdateFrmTablesupdateFinalOutput
				- startTimeforupdateFrmTablesupdateFinalOutput;
		logger.info("Total time for updateFrmTables: " + netTimeupdateFrmTablesupdateFinalOutput);
		// updateFrmTables(updateInventory);
		long startTimeforupdateFrmTablesupdateFinalOutputUserExit = System.currentTimeMillis();
		updateFrmTables(updateFinalOutputUserExit);
		long endTimeforupdateFrmTablesupdateFinalOutputUserExit = System.currentTimeMillis();
		long netTimeupdateFrmTablesupdateFinalOutputUserExit = endTimeforupdateFrmTablesupdateFinalOutputUserExit
				- startTimeforupdateFrmTablesupdateFinalOutputUserExit;
		logger.info("Total time for updateFrmTablesupdateFinalOutputUserExit: "
				+ netTimeupdateFrmTablesupdateFinalOutputUserExit);
		// updateFrmTables(updateInventoryUserExit);
	}

	// DEF091
	// update S4 Final Output with Inventory List for Package Column
	public void updateS4PackageFromInventory(long requestId, HttpSession session) throws SQLException {
		List<S4HanaProfiler> s4HanaProfilerFinalList = new ArrayList<S4HanaProfiler>();
		List<S4HanaProfiler> s4DrillDownFinalList = new ArrayList<S4HanaProfiler>();
		List<S4InventoryList> inventoryList = St03ReaderXlsx.getHm().getInventoryList();
		
		List<S4HanaProfiler> s4HanaProfilerList = getS4FinalOutput(requestId);

		if (!inventoryList.isEmpty() || null != inventoryList) {
			if (!s4HanaProfilerList.isEmpty() || null != s4HanaProfilerList) {
				for (S4HanaProfiler s4Hp : s4HanaProfilerList) {
					if (s4Hp.getPckg().isEmpty() || s4Hp.getPckg() == null) {
						logger.info("Package is null::::::::::::::::::: for " + s4Hp.getObjName());
						for (S4InventoryList inv : inventoryList) {
							if (s4Hp.getObjNameType().equalsIgnoreCase(inv.getObjNameType())) {
								s4Hp.setPckg(inv.getPckg());
								s4HanaProfilerFinalList.add(s4Hp);
							}
						}
					}
					if ("DRILLDOWN REPORT".equalsIgnoreCase(s4Hp.getOperations())) {
						s4Hp.setImpactReason("Drill down report " + s4Hp.getObjName()
								+ " is impacted due to obsolete table " + s4Hp.getTriggerObj());
						s4DrillDownFinalList.add(s4Hp);
					}
					if ("IMPACTED REPORT VARIANT".equalsIgnoreCase(s4Hp.getOperations())
							|| "IMPACTED SCREEN VARIANT".equalsIgnoreCase(s4Hp.getOperations())
							|| "IMPACTED TRANSACTION VARIANT".equalsIgnoreCase(s4Hp.getOperations())) {
						s4Hp.setImpactReason(
								"Variant " + s4Hp.getObjName() + " is Impacted in Report " + s4Hp.getTriggerObj());
						s4DrillDownFinalList.add(s4Hp);
					}
				}
			}
		}
		S4PackageBatchInsertUpdate(s4HanaProfilerFinalList, session);
		S4DrillDownReportUpdate(s4DrillDownFinalList, session);
		logger.info(
				"******************************************Updated PackageFromInventory for S4********************************");

	}

	public static String S4PackageBatchInsertUpdate(List<S4HanaProfiler> s4Profilerlist, HttpSession session)
			throws SQLException {

		final String UPDATE_SQL = "UPDATE s4_final_output set PCKG=? where ID=?";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);

			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(UPDATE_SQL);
				int batch = 1;

				for (S4HanaProfiler s4hpro : s4Profilerlist) {
					stmt.setString(1, s4hpro.getPckg());
					stmt.setLong(2, s4hpro.getId());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " for S4 Package executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("Final batch executed successfully");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error("Error !!! " + result + e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error("Error !!! " + result + e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	public static String S4DrillDownReportUpdate(List<S4HanaProfiler> s4Profilerlist, HttpSession session)
			throws SQLException {

		final String UPDATE_SQL = "UPDATE s4_final_output set IMPACT_REASON=? where ID=?";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);

			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(UPDATE_SQL);
				int batch = 1;

				for (S4HanaProfiler s4hpro : s4Profilerlist) {
					stmt.setString(1, s4hpro.getImpactReason());
					stmt.setLong(2, s4hpro.getId());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " for Drill Down report Updated successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("Final batch executed successfully");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error("Error !!! " + result + e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error("Error !!! " + result + e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	@SuppressWarnings("unchecked")
	private List<S4InventoryList> getS4InventoryList(long requestId) {
		Session session = null;
		List<S4InventoryList> s4InventoryList = null;
		try {
			logger.info("Steps For S4InventoryList****************");
			session = this.hibernateTemplate.getSessionFactory().openSession();

			String sql = "Select * from S4_Inventory_List where request_id=:requestID";

			Query query = session.createSQLQuery(sql).addEntity(S4InventoryList.class);
			query.setParameter("requestID", requestId);

			logger.info("******************" + query.getQueryString());
			s4InventoryList = query.list();
		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			if (null != session) {
				session.close();
			}
		}
		return s4InventoryList;
	}

	@SuppressWarnings("unchecked")
	private List<S4HanaProfiler> getS4FinalOutput(long requestId) {
		List<S4HanaProfiler> s4HanaProfilerLst = null;
		Session session = null;
		try {
			logger.info("Steps For S4HanaProfiler****************");
			session = this.hibernateTemplate.getSessionFactory().openSession();

			String sql = "Select * from S4_Final_Output where request_id=:requestID";

			Query query = session.createSQLQuery(sql).addEntity(S4HanaProfiler.class);
			query.setParameter("requestID", requestId);

			logger.info("******************" + query.getQueryString());
			s4HanaProfilerLst = query.list();
		} catch (Exception e) {
			logger.error("getS4FinalOutput :: ", e);
		} finally {
			if (null != session) {
				session.close();
			}
		}
		return s4HanaProfilerLst;
	}

	// ***************************************************************************************************************

	private void updateImpactedObjList(long requestId) {

		String frmDetailComplex = "INSERT INTO S4_Impact_Obj_List (OBJ_TYPE, OBJ_NAME,REQUEST_ID,Used) SELECT Distinct TYPE, OBJ_NAME,REQUEST_ID,USED FROM s4_final_output where request_id= "
				+ requestId;
		String frmAffectCustom = "INSERT INTO S4_Impact_Obj_List (OBJ_TYPE, OBJ_NAME,REQUEST_ID) SELECT Type, Obj_Name,REQUEST_ID FROM S4_Affect_Custom where request_id= "
				+ requestId;
		String frmOutputMgmt = "INSERT INTO S4_Impact_Obj_List (OBJ_TYPE, OBJ_NAME,REQUEST_ID) SELECT Type, Obj_Name,REQUEST_ID FROM S4_Output_Management where request_id= "
				+ requestId;
		
		updateFrmTables(frmDetailComplex);
		updateFrmTables(frmAffectCustom);
		updateFrmTables(frmOutputMgmt);

	}

	private void updateFrmTables(String sql) {
		Session session = null;
		try {
			session = this.hibernateTemplate.getSessionFactory().openSession();
			Query query = session.createSQLQuery(sql);
			query.executeUpdate();
		} catch (Exception e) {
			logger.error("updateFrmTables :: ", e);
		} finally {
			if (null != session) {
				session.close();
			}
		}

	}

	private void updateOutputManagement(long requestId) {
		long startTimeforgetfrmDetailReportOutput = System.currentTimeMillis();
		List<S4HanaProfiler> s4HanaProfiler = getfrmDetailReportOutput(requestId, "2294198");
		long endTimeforgetfrmDetailReportOutput = System.currentTimeMillis();
		long netTimegetfrmDetailReportOutput = endTimeforgetfrmDetailReportOutput
				- startTimeforgetfrmDetailReportOutput;
		logger.info("Total time for getfrmDetailReportOutput: " + netTimegetfrmDetailReportOutput);
		long startTimeforinsertOutputManagement = System.currentTimeMillis();
		insertOutputManagement(requestId, s4HanaProfiler);
		long endTimeforinsertOutputManagement = System.currentTimeMillis();
		long netTimeinsertOutputManagement = endTimeforinsertOutputManagement - startTimeforinsertOutputManagement;
		logger.info("Total time for insertOutputManagement: " + netTimeinsertOutputManagement);

		// List<S4HanaProfiler>
		// s4HanaProfilerTrigger=getfrmDetailReportTrigger(requestId);
		// insertOutputMgmtTriggerObject(requestId,s4HanaProfilerTrigger);

		long startTimefordeleteFrmS4Profiler = System.currentTimeMillis();
		deleteFrmS4Profiler(requestId, "2294198");
		long endTimefordeleteFrmS4Profiler = System.currentTimeMillis();
		long netTimedeleteFrmS4Profiler = endTimefordeleteFrmS4Profiler - startTimefordeleteFrmS4Profiler;
		logger.info("Total time for deleteFrmS4Profiler: " + netTimedeleteFrmS4Profiler);
		// deleteFrmS4ProfilerTrigger(requestId);
	}

	private void deleteFrmS4ProfilerTrigger(long requestId) {
		Query query = null;
		String hql = "delete from S4HanaProfiler where requestID=:request_id and TRIGGER_OBJ IN ('WRITE_FORM', 'END_FORM', 'CLOSE_FORM', 'OPEN_FORM', 'CONTROL_FORM', 'START_FORM')";

		Session session = sessionFactory.openSession();
		try {
			query = session.createQuery(hql);
			query.setParameter("request_id", requestId);
			query.executeUpdate();

			session.close();
		} catch (Exception e) {
			e.getMessage();
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	private List<S4HanaProfiler> getfrmDetailReportTrigger(long requestId) {
		List<S4HanaProfiler> s4HanaProfilerLst = null;
		Session session = null;
		try {
			logger.info("Steps For getfrmDetailReportTrigger****************");
			session = this.hibernateTemplate.getSessionFactory().openSession();

			String sql = "SELECT DISTINCT * FROM s4_final_output s where request_id= :request_Id and TRIGGER_OBJ IN ('WRITE_FORM', 'END_FORM', 'CLOSE_FORM', 'OPEN_FORM', 'CONTROL_FORM', 'START_FORM') group by concat(OBJ_NAME,TYPE)";
			Query query = session.createSQLQuery(sql).addEntity(S4HanaProfiler.class);
			;
			query.setParameter("request_Id", requestId);

			logger.info("******************" + query.getQueryString());
			s4HanaProfilerLst = query.list();
		} catch (Exception e) {
			logger.error("getfrmDetailReportTrigger :: ", e);
		} finally {
			if (null != session) {
				session.close();
			}
		}
		return s4HanaProfilerLst;
	}

	private void insertOutputMgmtTriggerObject(long requestId, List<S4HanaProfiler> s4HanaProfilerTriggerList) {
		List<S4OutputMgmt> s4OutputMgmtList = new ArrayList<S4OutputMgmt>();
		if (null != s4HanaProfilerTriggerList && !s4HanaProfilerTriggerList.isEmpty()) {

			Iterator<S4HanaProfiler> s4HanaProfilerITR = s4HanaProfilerTriggerList.iterator();
			while (s4HanaProfilerITR.hasNext()) {

				S4HanaProfiler s4HanaProfiler = s4HanaProfilerITR.next();

				S4OutputMgmt s4OutputMgmt = new S4OutputMgmt();

				s4OutputMgmt.setObjName(s4HanaProfiler.getObjName());
				s4OutputMgmt.setType(s4HanaProfiler.getType());
				s4OutputMgmt.setUsed(s4HanaProfiler.getUsed());
				s4OutputMgmt.setObjNameType(s4HanaProfiler.getObjNameType());
				s4OutputMgmt.setRequestID(requestId);
				s4OutputMgmtList.add(s4OutputMgmt);
			}
		}
		populateHanaTable.populateDataList(s4OutputMgmtList);

	}

	private void insertOutputManagement(long requestId, List<S4HanaProfiler> s4HanaProfilerList) {
		List<S4OutputMgmt> s4OutputMgmtList = new ArrayList<S4OutputMgmt>();
		if (null != s4HanaProfilerList && !s4HanaProfilerList.isEmpty()) {

			Iterator<S4HanaProfiler> s4HanaProfilerITR = s4HanaProfilerList.iterator();
			while (s4HanaProfilerITR.hasNext()) {

				S4HanaProfiler s4HanaProfiler = s4HanaProfilerITR.next();

				S4OutputMgmt s4OutputMgmt = new S4OutputMgmt();

				s4OutputMgmt.setObjName(s4HanaProfiler.getObjName());
				s4OutputMgmt.setType(s4HanaProfiler.getType());
				s4OutputMgmt.setUsed(s4HanaProfiler.getUsed());
				s4OutputMgmt.setObjNameType(s4HanaProfiler.getObjNameType());
				s4OutputMgmt.setRequestID(s4HanaProfiler.getRequestId());
				s4OutputMgmtList.add(s4OutputMgmt);
			}
		}
		populateHanaTable.populateDataList(s4OutputMgmtList);

	}

	private void updateAffectCustom(long requestId, Map<String, Boolean> sapNote) {
		// For SapNotes : 2320132, 2206980, 2522971, 2340247

		long startTimeforgetfrmDetailReport = System.currentTimeMillis();
		List<S4HanaProfiler> s4HanaProfiler = getfrmDetailReport(requestId);
		long endTimeforgetfrmDetailReport = System.currentTimeMillis();
		long netTimegetfrmDetailReport = endTimeforgetfrmDetailReport - startTimeforgetfrmDetailReport;

		logger.info("Total time for getfrmDetailReport: " + netTimegetfrmDetailReport);
		logger.info("Got the Affect Custm Not no. list the size is: " + s4HanaProfiler.size());

		long startTimeforinsertAffectCustom = System.currentTimeMillis();
		insertAffectCustom(requestId, s4HanaProfiler);
		long endTimeforinsertAffectCustom = System.currentTimeMillis();
		long netTimeinsertAffectCustom = endTimeforinsertAffectCustom - startTimeforinsertAffectCustom;

		logger.info("Total time for insertAffectCustom: " + netTimeinsertAffectCustom);

		long startTimefordeleteFrmS4Profiler = System.currentTimeMillis();
		deleteFrmS4Profiler(requestId, "2320132");
		deleteOprFrmS4Profiler(requestId, "%CUSTOM_FIELDS%");
		
		if(sapNote.get("2522971"))
		deleteSAPNoteFrmS4Profiler(requestId, "2522971");
		
		if(sapNote.get("2340247"))
		deleteSAPNoteFrmS4Profiler(requestId, "2340247");

		long endTimefordeleteFrmS4Profiler = System.currentTimeMillis();
		long netTimedeleteFrmS4Profiler = endTimefordeleteFrmS4Profiler - startTimefordeleteFrmS4Profiler;

		logger.info("Total time for deleteFrmS4Profiler: " + netTimedeleteFrmS4Profiler);

		long startTimeforupdateAffectWithAppend = System.currentTimeMillis();
		updateAffectWithAppend(requestId);
		long endTimeforupdateAffectWithAppend = System.currentTimeMillis();
		long netTimeupdateAffectWithAppend = endTimeforupdateAffectWithAppend - startTimeforupdateAffectWithAppend;

		logger.info("Total time for updateAffectWithAppend: " + netTimeupdateAffectWithAppend);

	}

	private void updateAffectWithAppend(long requestId) {
		Session session = null;
		try {
			logger.info("Steps For updateAffectWithAppend****************");
			session = this.hibernateTemplate.getSessionFactory().openSession();

			String sql = "DELETE FROM s4_affect_custom  WHERE NOT EXISTS (SELECT * FROM s4_append_structure  WHERE s4_affect_custom.Trigger_obj = s4_append_structure.table_name and request_id= :requestId ) and request_id= :request_Id";
			Query query = session.createSQLQuery(sql);
			query.setParameter("requestId", requestId);
			query.setParameter("request_Id", requestId);
			logger.info("******************" + query.getQueryString());
			query.executeUpdate();
		} catch (Exception e) {
			logger.error("updateAffectWithAppend :: ", e);
		} finally {
			if (null != session) {
				session.close();
			}
		}
	}

	private void deleteFrmS4Profiler(long requestId, String sapNote) {
		Query query = null;
		String hql = "delete from S4HanaProfiler where requestID= :request_id and sapNotes LIKE CONCAT('%',:sapNote, '%')";

		Session session = sessionFactory.openSession();
		try {
			query = session.createQuery(hql);
			query.setParameter("request_id", requestId);
			query.setParameter("sapNote", sapNote);
			query.executeUpdate();

			session.close();
		} catch (Exception e) {
			e.getMessage();
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
		
	private void deleteSAPNoteFrmS4Profiler(long requestId,String sapNote) {
		Query query = null;
		String hql = "delete from S4HanaProfiler where requestID= :request_id and sapNotes LIKE CONCAT(:sapNote, '%') ";

		Session session = sessionFactory.openSession();
		try {
			query = session.createQuery(hql);
			query.setParameter("request_id", requestId);
			query.setParameter("sapNote", sapNote);
			query.executeUpdate();

			session.close();
		} catch (Exception e) {
			e.getMessage();
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	private void deleteOprFrmS4Profiler(long requestId, String customFields) {
		Query query = null;
		String hql = "delete from S4HanaProfiler where requestID= :request_id and customFields like :custom_Fields)";

		Session session = sessionFactory.openSession();
		try {
			query = session.createQuery(hql);
			query.setParameter("request_id", requestId);
			query.setParameter("custom_Fields", customFields);
			query.executeUpdate();

			session.close();
		} catch (Exception e) {
			e.getMessage();
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	private void insertAffectCustom(long requestId, List<S4HanaProfiler> s4HanaProfilerList) {
		List<S4AffectCustomField> s4AffectCustomList = new ArrayList<S4AffectCustomField>();
		if (null != s4HanaProfilerList && !s4HanaProfilerList.isEmpty()) {

			Iterator<S4HanaProfiler> s4HanaProfilerITR = s4HanaProfilerList.iterator();
			while (s4HanaProfilerITR.hasNext()) {

				S4HanaProfiler s4HanaProfiler = s4HanaProfilerITR.next();

				S4AffectCustomField s4AffectCustomField = new S4AffectCustomField();

				s4AffectCustomField.setObjName(s4HanaProfiler.getObjName());
				s4AffectCustomField.setTriggerObj(s4HanaProfiler.getTriggerObj());
				s4AffectCustomField.setType(s4HanaProfiler.getType());
				s4AffectCustomField.setUsed(s4HanaProfiler.getUsed());
				s4AffectCustomField.setObjNameType(s4HanaProfiler.getObjNameType());
				s4AffectCustomField.setRequestID(s4HanaProfiler.getRequestId());
				
				if(s4HanaProfiler.getCustomFields().equalsIgnoreCase("CUSTOM_FIELDS_CDS"))
					s4AffectCustomField.setReplacedByCDS("X");
				
				s4AffectCustomList.add(s4AffectCustomField);
			}
		}
		
		long startTimeforpopulateDataList = System.currentTimeMillis();
		populateHanaTable.populateDataList(s4AffectCustomList);
		long endTimeforpopulateDataList = System.currentTimeMillis();
		long netTimepopulateDataList = endTimeforpopulateDataList - startTimeforpopulateDataList;
		logger.info("Total time for populateDataList: " + netTimepopulateDataList);

	}

	private List<S4HanaProfiler> getfrmDetailReport(long requestId) {
		Session session = null;
		List<S4HanaProfiler> s4HanaProfilerLst = null;
		logger.info("Steps For getfrmDetailReport****************");
		try {
			session = this.hibernateTemplate.getSessionFactory().openSession();
			// Query data for SAPNOTES : 2320132, and sapnote like 2206980
			// String sql="SELECT DISTINCT * FROM s4_final_output s where
			// request_id=:request_Id and SAP_NOTES in (:sapNote) group by
			// concat(OBJ_NAME,TYPE,TRIGGER_OBJ)";
			String sql = "SELECT DISTINCT * FROM s4_final_output s where request_id=:request_Id and "
					+ "(SAP_NOTES LIKE '%2320132%' or SAP_NOTES LIKE '%2206980%' or CUSTOM_FIELDS LIKE '%CUSTOM_FIELDS%') "
					+ "group by concat(OBJ_NAME, TYPE, TRIGGER_OBJ)";

			Query query = session.createSQLQuery(sql).addEntity(S4HanaProfiler.class);
			;
			query.setParameter("request_Id", requestId);
			logger.info("******************" + query.getQueryString());

			s4HanaProfilerLst = query.list();
		} catch (Exception e) {
			logger.error("getfrmDetailReport :: ", e);
		} finally {
			if (null != session) {
				session.close();
			}
		}
		return s4HanaProfilerLst;
	}

	private List<S4HanaProfiler> getfrmDetailReportOutput(long requestId, String sapNote) {
		List<S4HanaProfiler> s4HanaProfilerLst = null;
		Session session = null;
		try {
			logger.info("Steps For getfrmDetailReport****************");
			session = this.hibernateTemplate.getSessionFactory().openSession();

			String sql = "SELECT DISTINCT * FROM s4_final_output s where request_id=:request_Id and SAP_NOTES= :sapNote group by concat(OBJ_NAME,TYPE)";
			Query query = session.createSQLQuery(sql).addEntity(S4HanaProfiler.class);
			;
			query.setParameter("request_Id", requestId);
			query.setParameter("sapNote", sapNote);
			logger.info("******************" + query.getQueryString());
			s4HanaProfilerLst = query.list();
		} catch (Exception e) {
			logger.error("getfrmDetailReportOutput :: ", e);
		} finally {
			if (null != session) {
				session.close();
			}
		}
		return s4HanaProfilerLst;
	}

	// DEF035
	public void updateS4Enhancement(long requestId, HttpSession session) {
		S4EnhancementIntermediate s4EnhancementIntermediate;
		logger.info("Steps For updateS4Enhancement");
		try {
			List<S4EnhancementIntermediate> s4EnhancementIntermediateList = getS4EnhancementFrmDetailReport(requestId);

			logger.info("GOT DATA FROM FINAL OUTPUT FOR S4Enhancement_Intermediate*******************");
			List<S4Enhancement> s4EnhancementList = new ArrayList<S4Enhancement>();

			if (null != s4EnhancementIntermediateList && !s4EnhancementIntermediateList.isEmpty()) {
				Iterator<S4EnhancementIntermediate> s4EnhancementListItr = s4EnhancementIntermediateList.iterator();
				while (s4EnhancementListItr.hasNext()) {
					s4EnhancementIntermediate = s4EnhancementListItr.next();
					S4Enhancement s4Enhancement = new S4Enhancement();
					s4Enhancement.setType(HANAUtility.getBlankvalueIfNull(s4EnhancementIntermediate.getType()));
					s4Enhancement.setObjName(HANAUtility.getBlankvalueIfNull(s4EnhancementIntermediate.getObjName()));
					s4Enhancement.setEnhancementName(
							HANAUtility.getBlankvalueIfNull(s4EnhancementIntermediate.getEnhancementName()));
					s4Enhancement.setImplName(HANAUtility.getBlankvalueIfNull(s4EnhancementIntermediate.getImplName()));
					s4Enhancement.setRequestID(s4EnhancementIntermediate.getRequestID());

					s4EnhancementList.add(s4Enhancement);
				}

			}
			long startTimefors4EnhancementBatchInsertUpdate = System.currentTimeMillis();
			s4EnhancementBatchInsertUpdate(s4EnhancementList, session);
			long endTimefors4EnhancementBatchInsertUpdate = System.currentTimeMillis();
			long netTimes4EnhancementBatchInsertUpdate = endTimefors4EnhancementBatchInsertUpdate
					- startTimefors4EnhancementBatchInsertUpdate;
			logger.info("Total time for s4EnhancementBatchInsertUpdate: " + netTimes4EnhancementBatchInsertUpdate);
			long startTimefordeleteDuplicateRecordsEnhancements = System.currentTimeMillis();
			// deleteDuplicateRecordsEnhancements(requestId);
			long endTimefordeleteDuplicateRecordsEnhancements = System.currentTimeMillis();
			long netTimedeleteDuplicateRecordsEnhancements = endTimefordeleteDuplicateRecordsEnhancements
					- startTimefordeleteDuplicateRecordsEnhancements;
			logger.info(
					"Total time for deleteDuplicateRecordsEnhancements: " + netTimedeleteDuplicateRecordsEnhancements);

		} catch (SQLException e) {
			logger.error("Error !!! " + e);
		}
	}

	@SuppressWarnings("unchecked")
	private List<S4EnhancementIntermediate> getS4EnhancementFrmDetailReport(long requestId) {
		List<S4EnhancementIntermediate> s4EnhancementIntermediateLst = new ArrayList<S4EnhancementIntermediate>();
		Session session = null;
		try {
			logger.info("Steps For updateEnhancementSheet****************");
			session = this.hibernateTemplate.getSessionFactory().openSession();

			/*
			 * String
			 * sql="Select DISTINCT * from S4_Enhancement_Intermediate s1 inner join S4_Final_Output s2 "
			 * + "on s1.OBJECT_NAME=s2.OBJ_NAME where s1.request_id=:requestID";
			 */
			String sql = "Select DISTINCT s1.TYPE, OBJECT_NAME, ENHANCEMENT_NAME, IMPLEMENTATION_NAME, s1.request_id from S4_Enhancement_Intermediate s1 inner join S4_Final_Output s2 "
					+ "on s1.OBJECT_NAME=s2.OBJ_NAME where s1.request_id=:requestID";

			Query query = session.createSQLQuery(sql);
			query.setParameter("requestID", requestId);

			logger.info("******************" + query.getQueryString());
			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] object : resultList) {
					S4EnhancementIntermediate dto = new S4EnhancementIntermediate();
					dto.setType((String) (object[0]));
					dto.setObjName((String) object[1]);
					dto.setEnhancementName((String) object[2]);
					dto.setImplName((String) object[3]);
					dto.setRequestID(((BigInteger) (object[4])).longValue());
					s4EnhancementIntermediateLst.add(dto);
				}
			}

		} catch (Exception e) {
			logger.error("getS4EnhancementFrmDetailReport :: ", e);
		} finally {
			if (null != session) {
				session.close();
			}
		}
		return s4EnhancementIntermediateLst;
	}

	public static String s4EnhancementBatchInsertUpdate(List<S4Enhancement> s4EnhancementList, HttpSession session)
			throws SQLException {

		final String INSERT_SQL = "INSERT INTO S4_Enhancement "
				+ "(TYPE, OBJECT_NAME, ENHANCEMENT_NAME, IMPLEMENTATION_NAME, REQUEST_ID) values (?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (S4Enhancement s4Enhancement : s4EnhancementList) {
					stmt.setString(1, s4Enhancement.getType());
					stmt.setString(2, s4Enhancement.getObjName());
					stmt.setString(3, s4Enhancement.getEnhancementName());
					stmt.setString(4, s4Enhancement.getImplName());
					stmt.setLong(5, s4Enhancement.getRequestID());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("S4_Enhancement Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void deleteDuplicateRecordsEnhancements(final long requestID) {

		try {
			// col25
			logger.info("Creting Dynamic table");
			hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {
					String SqlQuery = "CREATE TABLE ENHANCEMENT_OUTPUT" + requestID + "  AS SELECT "
							+ "TYPE, OBJECT_NAME, ENHANCEMENT_NAME, IMPLEMENTATION_NAME"
							+ " FROM S4_Enhancement WHERE Request_ID=" + requestID;
					logger.info("Creating" + SqlQuery);
					final Query query = session.createSQLQuery(SqlQuery);
					return query.executeUpdate();
				}
			});

			logger.info("Deleting Records From S4_Enhancement");
			hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {
					String SqlQuery = "DELETE FROM  S4_Enhancement WHERE Request_ID=" + requestID;
					final Query query = session.createSQLQuery(SqlQuery);
					logger.info("Deleting" + SqlQuery);
					return query.executeUpdate();
				}
			});

			// col25
			logger.info("Inserting Records From S4_Enhancement");
			hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {
					String SqlQuery = "INSERT INTO S4_Enhancement(TYPE, OBJECT_NAME, ENHANCEMENT_NAME, IMPLEMENTATION_NAME,Request_ID)"
							+ " SELECT DISTINCT TYPE, OBJECT_NAME, ENHANCEMENT_NAME, IMPLEMENTATION_NAME," + requestID
							+ "  AS Request_ID FROM ENHANCEMENT_OUTPUT" + requestID;
					final Query query = session.createSQLQuery(SqlQuery);
					logger.info("Copying" + SqlQuery);
					return query.executeUpdate();
				}
			});

			logger.info("Deleting Duplicate Records From Enhancement Sheet Has Been Done..");

			hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {
					String SqlQuery = "DROP TABLE ENHANCEMENT_OUTPUT" + requestID;
					final Query query = session.createSQLQuery(SqlQuery);
					logger.info("Drop" + SqlQuery);
					return query.executeUpdate();
				}
			});
		} catch (Exception e) {
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	/*
	 * private void updateS4Enhancement(long requestId, Map<String, String>
	 * enhancObjFrmDetailReportMap) { Session
	 * session=this.hibernateTemplate.getSessionFactory().openSession();
	 * 
	 * String
	 * sql="update S4_Enhancement s4Enhance Inner JOIN S4_Enhancement_Intermediate inter on s4Enhance.OBJECT_NAME=inter.OBJECT_NAME set s4Enhance.ENHANCEMENT_NAME=inter.ENHANCEMENT_NAME, s4Enhance.IMPLEMENTATION_NAME=inter.IMPLEMENTATION_NAME where s4Enhance.REQUEST_ID=:request_Id "
	 * ;
	 * 
	 * Query query=session.createSQLQuery(sql); query.setParameter("request_Id",
	 * requestId); query.executeUpdate();
	 * 
	 * }
	 */

	private void updateCloneProgAnalysis(long requestId) {

		long startTimeforgetCloneObjFrmValidation = System.currentTimeMillis();
		Map<String, String> cloneObjFrmValidationMap = getCloneObjFrmValidation(requestId);
		long endTimeforgetCloneObjFrmValidation = System.currentTimeMillis();
		long netTimegetCloneObjFrmValidation = endTimeforgetCloneObjFrmValidation
				- startTimeforgetCloneObjFrmValidation;
		logger.info("Total time for getCloneObjFrmValidation: " + netTimegetCloneObjFrmValidation);
		long startTimeforinsertCloneProg = System.currentTimeMillis();
		insertCloneProg(requestId, cloneObjFrmValidationMap);
		long endTimeforinsertCloneProg = System.currentTimeMillis();
		long netTimeinsertCloneProg = endTimeforinsertCloneProg - startTimeforinsertCloneProg;
		logger.info("Total time for insertCloneProg: " + netTimeinsertCloneProg);
		long startTimeforupdateCloneFrmSimpliDB = System.currentTimeMillis();
		updateCloneFrmSimpliDB(requestId, cloneObjFrmValidationMap);
		long endTimeforupdateCloneFrmSimpliDB = System.currentTimeMillis();
		long netTimeupdateCloneFrmSimpliDB = endTimeforupdateCloneFrmSimpliDB - startTimeforupdateCloneFrmSimpliDB;
		logger.info("Total time for updateCloneFrmSimpliDB: " + netTimeupdateCloneFrmSimpliDB);

	}

	private void updateCloneFrmSimpliDB(long requestId, Map<String, String> cloneObjFrmValidationMap) {
		Session session = null;
		try {
			session = this.hibernateTemplate.getSessionFactory().openSession();

			String sql = "update S4_Clone_Prog_Analysis cloneProg Inner JOIN S4_Simplification_Database simpliDb on cloneProg.Clone_prog=simpliDb.Object set cloneProg.Description=simpliDb.Description, cloneProg.Solution_Step=simpliDb.Solution_Steps, cloneProg.Related_Notes=simpliDb.Related_Notes  where cloneProg.REQUEST_ID=:request_Id ";

			Query query = session.createSQLQuery(sql);
			query.setParameter("request_Id", requestId);
			query.executeUpdate();
		} catch (Exception e) {
			logger.error("updateCloneFrmSimpliDB :: ", e);
		} finally {
			if (null != session) {
				session.close();
			}
		}
	}

	private void insertCloneProg(long requestId, Map<String, String> cloneObjFrmValidationMap) {
		List<S4CloneProg> s4CloneProgList = new ArrayList<S4CloneProg>();

		if (null != cloneObjFrmValidationMap && !cloneObjFrmValidationMap.isEmpty()) {

			Set<String> keySet = cloneObjFrmValidationMap.keySet();
			for (String key : keySet) {
				S4CloneProg s4CloneProg = new S4CloneProg();
				s4CloneProg.setImpactedProg(key);
				s4CloneProg.setCloneProg(cloneObjFrmValidationMap.get(key));
				s4CloneProg.setRequestID(requestId);
				s4CloneProgList.add(s4CloneProg);
			}
		}
		populateHanaTable.populateDataList(s4CloneProgList);
	}

	private Map<String, String> getCloneObjFrmValidation(long requestId) {

		final Map<String, String> resultMap = new HashMap<String, String>();
		Session session = this.hibernateTemplate.getSessionFactory().openSession();

		String hql = "SELECT clone.OBJ_NAME,clone.INCLUDE FROM s4_clone_prog_intermediate clone Inner JOIN s4_validation_data validat ON clone.INCLUDE=validat.Object WHERE clone.REQUEST_ID=:requestId";
		Query query = session.createSQLQuery(hql);
		query.setParameter("requestId", requestId);
		List<Object[]> resultList = query.list();

		if (CollectionUtils.isNotEmpty(resultList)) {
			for (Object[] object : resultList) {
				resultMap.put((String) object[0], (String) object[1]);
			}
		}

		if (null != session)
			session.close();

		return resultMap;

	}

	// CR-47.0
	private void updateImpactedTransaction(long requestId, HttpSession httpSession) throws SQLException {
		Session session = null;
		try {
			session = this.hibernateTemplate.getSessionFactory().openSession();
			List<S4SimplificationDatabase> s4SimplificationDatabaseList = getSimplificationDBforTransaction(requestId);
			deleteImpactedTransactionData(requestId);
			insertImpactedDBTransactionObjects(s4SimplificationDatabaseList, requestId, httpSession);
			Set<String> objectSet = new HashSet<>();

			if (s4SimplificationDatabaseList != null && !s4SimplificationDatabaseList.isEmpty()) {
				Iterator<S4SimplificationDatabase> s4SimplificationDatabaseItr = s4SimplificationDatabaseList
						.iterator();
				while (s4SimplificationDatabaseItr.hasNext()) {
					S4SimplificationDatabase s4SimplificationDatabase = s4SimplificationDatabaseItr.next();
					String object = s4SimplificationDatabase.getObject().trim();

					if (!objectSet.contains(object)) {

						String desc = s4SimplificationDatabase.getDescription();
						String relatedNotes = s4SimplificationDatabase.getRelatedNotes();
						String solSteps = s4SimplificationDatabase.getSolutionSteps();

						String sql = "update S4_IMPACTED_TRANSACTION set DESCRIPTION=:desc, "
								+ "SAP_NOTES=:relatedNotes,SOLUTION_STEPS=:solSteps where IMPACTED_TRANSACTION=:Object "
								+ "and REQUEST_ID=:REQUEST_ID";

						Query query = session.createSQLQuery(sql);
						query.setParameter("desc", desc);
						query.setParameter("relatedNotes", relatedNotes);
						query.setParameter("solSteps", solSteps);
						query.setParameter("Object", object.trim());
						query.setParameter("REQUEST_ID", requestId);
						query.executeUpdate();
						if (relatedNotes != null && !relatedNotes.equalsIgnoreCase("")) {
							objectSet.add(object);
						}
					}
				}
			}
		} catch (Exception e) {
			logger.error("updateImpactedTransaction :: ", e);
		} finally {
			if (null != session) {
				session.close();
			}
		}
	}

	private void insertImpactedDBTransactionObjects(List<S4SimplificationDatabase> s4SimplificationDatabaseList,
			long requestId, HttpSession session) throws SQLException {
		final String INSERT_SQL = "INSERT INTO S4_IMPACTED_TRANSACTION "
				+ "(IMPACTED_TRANSACTION,REQUEST_ID) values (?, ?)";

		Set<String> objectSet = new HashSet<>();
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {
			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);

			stmt = conn.prepareStatement(INSERT_SQL);
			int batch = 1;

			for (S4SimplificationDatabase impactedTransactionSimpliDB : s4SimplificationDatabaseList) {
				if (!objectSet.contains(impactedTransactionSimpliDB.getObject())) {
					objectSet.add(impactedTransactionSimpliDB.getObject());

					stmt.setString(1, impactedTransactionSimpliDB.getObject());
					stmt.setLong(2, requestId);
					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}
			}
			stmt.executeBatch();
			conn.commit();
			logger.info("S4_IMPACTED_TRANSACTION Data INSERTED SUCCESSFULLY");

		} finally {
			stmt.close();
			conn.close();
		}
	}

	// CR-47.0
	private List<S4SimplificationDatabase> getSimplificationDBforTransaction(long requestId) {
		List<S4SimplificationDatabase> S4SimplificationDatabaseLst = null;
		Session session = null;
		try {
			logger.info("Steps For getSimplificationDBforTransaction****************");
			session = this.hibernateTemplate.getSessionFactory().openSession();

			String sql = "SELECT * FROM S4_Simplification_Database s Inner JOIN S4_IMPACTED_TRANSACTION impTrans "
					+ "ON s.Object=impTrans.IMPACTED_TRANSACTION WHERE  impTrans.REQUEST_ID=:requestId";
			Query query = session.createSQLQuery(sql).addEntity(S4SimplificationDatabase.class);
			;
			query.setParameter("requestId", requestId);
			logger.info("******************" + query.getQueryString());
			S4SimplificationDatabaseLst = query.list();
		} catch (Exception e) {
			logger.error("getSimplificationDBforTransaction :: ", e);
		} finally {
			if (null != session) {
				session.close();
			}
		}
		return S4SimplificationDatabaseLst;
	}

	// CR-41.0
	private void updateImpactedTables(long requestId) {
		Session session = null;
		try {
			session = this.hibernateTemplate.getSessionFactory().openSession();
			List<S4SimplificationDatabase> s4SimplificationDatabaseList = getSimplificationDBforTable(requestId);
			if (s4SimplificationDatabaseList != null && !s4SimplificationDatabaseList.isEmpty()) {

				Iterator<S4SimplificationDatabase> s4SimplificationDatabaseItr = s4SimplificationDatabaseList
						.iterator();
				Set<String> objectSet = new HashSet<>();
				while (s4SimplificationDatabaseItr.hasNext()) {
					S4SimplificationDatabase s4SimplificationDatabase = s4SimplificationDatabaseItr.next();
					String object = (s4SimplificationDatabase.getObject()).trim();
					if (!objectSet.contains(object)) {

						String desc = s4SimplificationDatabase.getDescription();
						String relatedNotes = s4SimplificationDatabase.getRelatedNotes();
						String solSteps = s4SimplificationDatabase.getSolutionSteps();

						String sql = "update S4_IMPACTED_TABLES set DESCRIPTION=:desc,SAP_NOTES=:relatedNotes, "
								+ "SOLUTION_STEPS=:solSteps where Object=:Object and REQUEST_ID=:REQUEST_ID";

						Query query = session.createSQLQuery(sql);
						query.setParameter("desc", desc);
						query.setParameter("relatedNotes", relatedNotes);
						query.setParameter("solSteps", solSteps);
						query.setParameter("Object", object);
						query.setParameter("REQUEST_ID", requestId);
						query.executeUpdate();
						if (relatedNotes != null && !relatedNotes.equalsIgnoreCase("")) {
							objectSet.add(object);
						}
					}
				}
			}
		} catch (Exception e) {
			logger.error("updateImpactedTables :: ", e);
		} finally {
			if (null != session) {
				session.close();
			}
		}

	}

	// CR-41.0
	private List<S4SimplificationDatabase> getSimplificationDBforTable(long requestId) {

		List<S4SimplificationDatabase> s4SimplificationDatabaseLst = null;
		Session session = null;
		try {
			logger.info("Steps For updateImpactedIDOC****************");
			session = this.hibernateTemplate.getSessionFactory().openSession();

			String sql = "SELECT * FROM S4_Simplification_Database s Left outer JOIN S4_IMPACTED_TABLES impTable "
					+ "ON s.Object=impTable.Object WHERE  impTable.REQUEST_ID=:requestId";
			Query query = session.createSQLQuery(sql).addEntity(S4SimplificationDatabase.class);
			;
			query.setParameter("requestId", requestId);
			logger.info("******************" + query.getQueryString());
			s4SimplificationDatabaseLst = query.list();
		} catch (Exception e) {
			logger.error("getSimplificationDBforTable :: ", e);
		} finally {
			if (null != session) {
				session.close();
			}
		}
		return s4SimplificationDatabaseLst;
	}

	// CR-42.0
	private void updateImpactedIDOC(long requestId) {
		Session session = null;
		try {
			session = this.hibernateTemplate.getSessionFactory().openSession();
			List<S4SimplificationDatabase> s4SimplificationDatabaseList = getSimplificationDBforIDOC(requestId);
			if (s4SimplificationDatabaseList != null && !s4SimplificationDatabaseList.isEmpty()) {

				Iterator<S4SimplificationDatabase> s4SimplificationDatabaseItr = s4SimplificationDatabaseList
						.iterator();
				while (s4SimplificationDatabaseItr.hasNext()) {
					S4SimplificationDatabase s4SimplificationDatabase = s4SimplificationDatabaseItr.next();
					String desc = s4SimplificationDatabase.getDescription();
					String relatedNotes = s4SimplificationDatabase.getRelatedNotes();
					String solSteps = s4SimplificationDatabase.getSolutionSteps();
					String object = s4SimplificationDatabase.getObject();
					String sql = "update S4_IMPACTED_IDOC set Description=:desc,SAP_Note=:relatedNotes,Sol_Steps=:solSteps where LTRIM(RTRIM(Data_Element))=:Data_Element and REQUEST_ID=:REQUEST_ID";

					Query query = session.createSQLQuery(sql);
					query.setParameter("desc", desc);
					query.setParameter("relatedNotes", relatedNotes);
					query.setParameter("solSteps", solSteps);
					query.setParameter("Data_Element", object.trim());
					query.setParameter("REQUEST_ID", requestId);
					query.executeUpdate();
				}
			}
		} catch (Exception e) {
			logger.error("updateImpactedIDOC :: ", e);
		} finally {
			if (null != session) {
				session.close();
			}
		}

	}

	// CR-42.0
	private List<S4SimplificationDatabase> getSimplificationDBforIDOC(long requestId) {
		List<S4SimplificationDatabase> S4SimplificationDatabase = null;
		Session session = null;
		try {
			logger.info("Steps For updateImpactedIDOC****************");
			session = this.hibernateTemplate.getSessionFactory().openSession();

			String sql = "SELECT * FROM S4_Simplification_Database s Left outer JOIN S4_IMPACTED_IDOC impIDOC ON LTRIM(RTRIM(s.Object))=LTRIM(RTRIM(impIDOC.Data_Element)) WHERE  impIDOC.REQUEST_ID=:requestId";
			Query query = session.createSQLQuery(sql).addEntity(S4SimplificationDatabase.class);
			;
			query.setParameter("requestId", requestId);
			logger.info("******************" + query.getQueryString());
			S4SimplificationDatabase = query.list();
		} catch (Exception e) {
			logger.error("getSimplificationDBforIDOC :: ", e);
		} finally {
			if (null != session) {
				session.close();
			}
		}
		return S4SimplificationDatabase;
	}

	private void updateDetailReportINDE(long requestId) {
		logger.info("Step Into updateDetailReportINDE*******************");
		List<S4HanaProfiler> s4HanaProfilerList = getIndeTypeFrmFinalOutput(requestId);
		logger.info("GOT DATA FROM getIndeTypeFrmFinalOutput*******************");
		List<S4DetailReportComplexity> s4DetailReportList = new ArrayList<S4DetailReportComplexity>();

		if (null != s4HanaProfilerList && !s4HanaProfilerList.isEmpty()) {
			Iterator<S4HanaProfiler> s4HanaProfilerItr = s4HanaProfilerList.iterator();
			while (s4HanaProfilerItr.hasNext()) {
				S4HanaProfiler s4Profiler = s4HanaProfilerItr.next();

				S4DetailReportComplexity s4DetailReport = new S4DetailReportComplexity();

				s4DetailReport.setObjName(HANAUtility.getBlankvalueIfNull(s4Profiler.getObjName()));
				s4DetailReport.setSubObject(HANAUtility.getBlankvalueIfNull(s4Profiler.getSubObject()));
				s4DetailReport.setIdentifier(HANAUtility.getBlankvalueIfNull(s4Profiler.getIdentifier()));
				s4DetailReport.setMethod(HANAUtility.getBlankvalueIfNull(s4Profiler.getMethod()));
				s4DetailReport.setPckg(HANAUtility.getBlankvalueIfNull(s4Profiler.getPckg()));
				s4DetailReport.setType(HANAUtility.getBlankvalueIfNull(s4Profiler.getType()));
				s4DetailReport.setLineNo(s4Profiler.getLineNo());
				s4DetailReport.setStmt(HANAUtility.getBlankvalueIfNull(s4Profiler.getStmt()));
				s4DetailReport.setOperations(HANAUtility.getBlankvalueIfNull(s4Profiler.getOperations()));
				s4DetailReport.setImpactReason(HANAUtility.getBlankvalueIfNull(s4Profiler.getImpactReason()));
				s4DetailReport.setAffectObjDesc(HANAUtility.getBlankvalueIfNull(s4Profiler.getAffectObjDesc()));
				s4DetailReport.setRequestId((s4Profiler.getRequestId()));

				s4DetailReport
						.setApplicationComponent(HANAUtility.getBlankvalueIfNull(s4Profiler.getApplicationComponent()));
				s4DetailReport.setComplexity(HANAUtility.getBlankvalueIfNull(s4Profiler.getComplexity().toLowerCase()));
				s4DetailReport.setDescOfChange(HANAUtility.getBlankvalueIfNull(s4Profiler.getDescOfChange()));
				s4DetailReport.setErrorCategory(HANAUtility.getBlankvalueIfNull(s4Profiler.getErrorCategory()));
				s4DetailReport.setImpactedObjType(HANAUtility.getBlankvalueIfNull(s4Profiler.getImpactedObjType()));
				s4DetailReport.setIssueCategory(HANAUtility.getBlankvalueIfNull(s4Profiler.getIssueCategory()));
				s4DetailReport.setItemArea(HANAUtility.getBlankvalueIfNull(s4Profiler.getItemArea()));
				s4DetailReport.setSapNotes(HANAUtility.getBlankvalueIfNull(s4Profiler.getSapNotes()));
				s4DetailReport.setSapSimplCategry(HANAUtility.getBlankvalueIfNull(s4Profiler.getSapSimplCategry()));
				s4DetailReport
						.setSapSimpListChapter(HANAUtility.getBlankvalueIfNull(s4Profiler.getSapSimpListChapter()));
				s4DetailReport.setUsed(HANAUtility.getBlankvalueIfNull(s4Profiler.getUsed()));
				s4DetailReport.setTriggerObj(HANAUtility.getBlankvalueIfNull(s4Profiler.getTriggerObj()));
				s4DetailReport.setSolutionSteps(HANAUtility.getBlankvalueIfNull(s4Profiler.getSolutionSteps()));

				s4DetailReportList.add(s4DetailReport);
			}

			populateHanaTable.populateDataList(s4DetailReportList);

		}
	}

	private void updateDetailRemediReportINDE(long requestId) {
		logger.info("Step Into updateDetailRemediReportINDE*******************");
		List<S4HanaProfiler> s4HanaProfilerList = getIndeTypeFrmFinalOutput(requestId);
		logger.info("GOT DATA FROM getIndeTypeFrmFinalOutput*******************");
		List<S4DetailReportRemediation> s4DetailRemediReportList = new ArrayList<S4DetailReportRemediation>();

		if (null != s4HanaProfilerList && !s4HanaProfilerList.isEmpty()) {
			Iterator<S4HanaProfiler> s4HanaProfilerItr = s4HanaProfilerList.iterator();
			while (s4HanaProfilerItr.hasNext()) {
				S4HanaProfiler s4Profiler = s4HanaProfilerItr.next();

				S4DetailReportRemediation s4DetailRemediReport = new S4DetailReportRemediation();

				s4DetailRemediReport.setObjName(HANAUtility.getBlankvalueIfNull(s4Profiler.getObjName()));
				s4DetailRemediReport.setSubObject(HANAUtility.getBlankvalueIfNull(s4Profiler.getSubObject()));
				s4DetailRemediReport.setIdentifier(HANAUtility.getBlankvalueIfNull(s4Profiler.getIdentifier()));
				s4DetailRemediReport.setMethod(HANAUtility.getBlankvalueIfNull(s4Profiler.getMethod()));
				s4DetailRemediReport.setPckg(HANAUtility.getBlankvalueIfNull(s4Profiler.getPckg()));
				s4DetailRemediReport.setType(HANAUtility.getBlankvalueIfNull(s4Profiler.getType()));
				s4DetailRemediReport.setLineNo(s4Profiler.getLineNo());
				s4DetailRemediReport.setStmt(HANAUtility.getBlankvalueIfNull(s4Profiler.getStmt()));
				s4DetailRemediReport.setOperations(HANAUtility.getBlankvalueIfNull(s4Profiler.getOperations()));
				s4DetailRemediReport.setImpactReason(HANAUtility.getBlankvalueIfNull(s4Profiler.getImpactReason()));
				s4DetailRemediReport.setAffectObjDesc(HANAUtility.getBlankvalueIfNull(s4Profiler.getAffectObjDesc()));
				s4DetailRemediReport.setRequestId((s4Profiler.getRequestId()));

				s4DetailRemediReport
						.setApplicationComponent(HANAUtility.getBlankvalueIfNull(s4Profiler.getApplicationComponent()));
				s4DetailRemediReport.setComplexity(HANAUtility.getBlankvalueIfNull(s4Profiler.getComplexity()));
				s4DetailRemediReport.setDescOfChange(HANAUtility.getBlankvalueIfNull(s4Profiler.getDescOfChange()));
				s4DetailRemediReport.setErrorCategory(HANAUtility.getBlankvalueIfNull(s4Profiler.getErrorCategory()));
				s4DetailRemediReport
						.setImpactedObjType(HANAUtility.getBlankvalueIfNull(s4Profiler.getImpactedObjType()));
				s4DetailRemediReport.setIssueCategory(HANAUtility.getBlankvalueIfNull(s4Profiler.getIssueCategory()));
				s4DetailRemediReport.setItemArea(HANAUtility.getBlankvalueIfNull(s4Profiler.getItemArea()));
				s4DetailRemediReport.setSapNotes(HANAUtility.getBlankvalueIfNull(s4Profiler.getSapNotes()));
				s4DetailRemediReport
						.setSapSimplCategry(HANAUtility.getBlankvalueIfNull(s4Profiler.getSapSimplCategry()));
				s4DetailRemediReport
						.setSapSimpListChapter(HANAUtility.getBlankvalueIfNull(s4Profiler.getSapSimpListChapter()));
				s4DetailRemediReport.setUsed(HANAUtility.getBlankvalueIfNull(s4Profiler.getUsed()));
				s4DetailRemediReport.setTriggerObj(HANAUtility.getBlankvalueIfNull(s4Profiler.getTriggerObj()));
				s4DetailRemediReport.setSolutionSteps(HANAUtility.getBlankvalueIfNull(s4Profiler.getSolutionSteps()));

				s4DetailRemediReportList.add(s4DetailRemediReport);
			}

			populateHanaTable.populateDataList(s4DetailRemediReportList);

		}
	}

	private List<S4HanaProfiler> getIndeTypeFrmFinalOutput(long requestId) {
		logger.info("Step Into getIndeTypeFrmFinalOutput*******************");
		final Session session = sessionFactory.openSession();
		try {
			final Criteria criteria = session.createCriteria(S4HanaProfiler.class);
			criteria.add(Restrictions.eq("type", "INDE"));
			criteria.add(Restrictions.eq("requestID", requestId));
			return criteria.list();
		} catch (Exception e) {
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

	public void updateDetailReport(long requestId) {
		logger.info("Steps For updateDetailReport");
		S4HanaProfiler s4Profiler;
		List<S4HanaProfiler> s4ProfilerList = getDataFrDetailReport(requestId);
		logger.info("GOT DATA FROM FINAL OUTPUT FOR DETAIL REPORT*******************");
		List<S4DetailReportComplexity> s4DetailReportList = new ArrayList<S4DetailReportComplexity>();

		if (null != s4ProfilerList && !s4ProfilerList.isEmpty()) {
			Iterator<S4HanaProfiler> s4ProfilerItr = s4ProfilerList.iterator();
			while (s4ProfilerItr.hasNext()) {
				s4Profiler = s4ProfilerItr.next();
				S4DetailReportComplexity s4DetailReport = new S4DetailReportComplexity();
				s4DetailReport.setObjName(HANAUtility.getBlankvalueIfNull(s4Profiler.getObjName()));
				s4DetailReport.setSubObject(HANAUtility.getBlankvalueIfNull(s4Profiler.getSubObject()));
				s4DetailReport.setIdentifier(HANAUtility.getBlankvalueIfNull(s4Profiler.getIdentifier()));
				s4DetailReport.setMethod(HANAUtility.getBlankvalueIfNull(s4Profiler.getMethod()));
				s4DetailReport.setPckg(HANAUtility.getBlankvalueIfNull(s4Profiler.getPckg()));
				s4DetailReport.setType(HANAUtility.getBlankvalueIfNull(s4Profiler.getType()));
				s4DetailReport.setLineNo(s4Profiler.getLineNo());
				s4DetailReport.setStmt(HANAUtility.getBlankvalueIfNull(s4Profiler.getStmt()));
				s4DetailReport.setOperations(HANAUtility.getBlankvalueIfNull(s4Profiler.getOperations()));
				s4DetailReport.setImpactReason(HANAUtility.getBlankvalueIfNull(s4Profiler.getImpactReason()));
				s4DetailReport.setAffectObjDesc(HANAUtility.getBlankvalueIfNull(s4Profiler.getAffectObjDesc()));
				s4DetailReport.setRequestId((s4Profiler.getRequestId()));

				s4DetailReport
						.setApplicationComponent(HANAUtility.getBlankvalueIfNull(s4Profiler.getApplicationComponent()));
				s4DetailReport.setComplexity(HANAUtility.getBlankvalueIfNull(s4Profiler.getComplexity().toLowerCase()));
				s4DetailReport.setDescOfChange(HANAUtility.getBlankvalueIfNull(s4Profiler.getDescOfChange()));
				s4DetailReport.setErrorCategory(HANAUtility.getBlankvalueIfNull(s4Profiler.getErrorCategory()));
				s4DetailReport.setImpactedObjType(HANAUtility.getBlankvalueIfNull(s4Profiler.getImpactedObjType()));
				s4DetailReport.setIssueCategory(HANAUtility.getBlankvalueIfNull(s4Profiler.getIssueCategory()));
				s4DetailReport.setItemArea(HANAUtility.getBlankvalueIfNull(s4Profiler.getItemArea()));
				s4DetailReport.setSapNotes(HANAUtility.getBlankvalueIfNull(s4Profiler.getSapNotes()));
				s4DetailReport.setSapSimplCategry(HANAUtility.getBlankvalueIfNull(s4Profiler.getSapSimplCategry()));
				s4DetailReport
						.setSapSimpListChapter(HANAUtility.getBlankvalueIfNull(s4Profiler.getSapSimpListChapter()));
				s4DetailReport.setUsed(HANAUtility.getBlankvalueIfNull(s4Profiler.getUsed()));
				s4DetailReport.setTriggerObj(HANAUtility.getBlankvalueIfNull(s4Profiler.getTriggerObj()));
				s4DetailReport.setSolutionSteps(HANAUtility.getBlankvalueIfNull(s4Profiler.getSolutionSteps()));
				s4DetailReport
						.setRemediationCategory(HANAUtility.getBlankvalueIfNull(s4Profiler.getRemediationCategory()));

				s4DetailReport.setObjNameType(HANAUtility.getBlankvalueIfNull(s4Profiler.getObjNameType()));

				s4DetailReportList.add(s4DetailReport);
			}

			long startTimeforpopulateDataList = System.currentTimeMillis();
			populateHanaTable.populateDataList(s4DetailReportList);
			long endTimeforpopulateDataList = System.currentTimeMillis();
			long netTimepopulateDataList = endTimeforpopulateDataList - startTimeforpopulateDataList;
			logger.info("Total time for populateDataList: " + netTimepopulateDataList);
		}

	}

	@SuppressWarnings("unchecked")
	private List<S4HanaProfiler> getDataFrDetailReport(long requestId) {
		logger.info("Steps For updateDetailReport****************");
		Session session = null;
		Query query = null;
		List<S4HanaProfiler> s4HanaProfilerLst = null;
		try {
			session = this.hibernateTemplate.getSessionFactory().openSession();

			String sql = "Select * from s4_final_output natural join(select final_output.TYPE,final_output.OBJ_NAME, CASE"
					+ " WHEN final_output.complexty =  '1' THEN 'TBD' "
					+ " WHEN final_output.complexty =  '2' THEN 'HIGH' "
					+ " WHEN final_output.complexty =  '3' THEN 'MEDIUM' "
					+ " WHEN final_output.complexty =  '4' THEN 'LOW' "
					+ " WHEN final_output.complexty =  '5' THEN 'VERY LOW' "
					+ " END AS COMPLEXITY FROM(Select type, OBJ_NAME,MIN(CASE " + " WHEN COMPLEXITY = 'TBD' THEN '1' "
					+ " WHEN COMPLEXITY = 'HIGH' THEN '2' " + " WHEN  COMPLEXITY = 'MEDIUM' THEN '3' "
					+ " WHEN  COMPLEXITY = 'LOW' THEN '4' " + " WHEN  COMPLEXITY = 'VERY LOW' THEN '5' "
					+ " END)complexty FROM s4_final_output where request_id=:requesId GROUP BY concat(TYPE, OBJ_NAME))"
					+ " as final_output)as NJ where request_id=:requestId group by concat(OBJ_NAME,TYPE,Complexity)";

			query = session.createSQLQuery(sql).addEntity(S4HanaProfiler.class);
			query.setParameter("requesId", requestId);
			query.setParameter("requestId", requestId);
			s4HanaProfilerLst = query.list();
			logger.info("******************" + query.getQueryString());
		} catch (Exception e) {
			logger.error("getDataFrDetailReport :: ", e);
		} finally {
			if (null != session) {
				session.close();
			}
		}
		return s4HanaProfilerLst;

	}

	public void updateDetailRemediReport(long requestId) {
		logger.info("Steps For updateDetailRemediReport");
		List<S4HanaProfiler> s4ProfilerList = getDataFrRemediReport(requestId);
		logger.info("GOT DATA FROM FINAL OUTPUT FOR DETAIL REPORT*******************");
		List<S4DetailReportRemediation> s4DetailRemedReportList = new ArrayList<S4DetailReportRemediation>();

		if (null != s4ProfilerList && !s4ProfilerList.isEmpty()) {
			Iterator<S4HanaProfiler> s4ProfilerItr = s4ProfilerList.iterator();
			while (s4ProfilerItr.hasNext()) {
				S4HanaProfiler s4Profiler = s4ProfilerItr.next();
				S4DetailReportRemediation s4DetailRemediReport = new S4DetailReportRemediation();
				s4DetailRemediReport.setObjName(HANAUtility.getBlankvalueIfNull(s4Profiler.getObjName()));
				s4DetailRemediReport.setSubObject(HANAUtility.getBlankvalueIfNull(s4Profiler.getSubObject()));
				s4DetailRemediReport.setIdentifier(HANAUtility.getBlankvalueIfNull(s4Profiler.getIdentifier()));
				s4DetailRemediReport.setMethod(HANAUtility.getBlankvalueIfNull(s4Profiler.getMethod()));
				s4DetailRemediReport.setPckg(HANAUtility.getBlankvalueIfNull(s4Profiler.getPckg()));
				s4DetailRemediReport.setType(HANAUtility.getBlankvalueIfNull(s4Profiler.getType()));
				s4DetailRemediReport.setLineNo(s4Profiler.getLineNo());
				s4DetailRemediReport.setStmt(HANAUtility.getBlankvalueIfNull(s4Profiler.getStmt()));
				s4DetailRemediReport.setOperations(HANAUtility.getBlankvalueIfNull(s4Profiler.getOperations()));
				s4DetailRemediReport.setImpactReason(HANAUtility.getBlankvalueIfNull(s4Profiler.getImpactReason()));
				s4DetailRemediReport.setAffectObjDesc(HANAUtility.getBlankvalueIfNull(s4Profiler.getAffectObjDesc()));
				s4DetailRemediReport.setRequestId((s4Profiler.getRequestId()));

				s4DetailRemediReport
						.setApplicationComponent(HANAUtility.getBlankvalueIfNull(s4Profiler.getApplicationComponent()));
				s4DetailRemediReport.setComplexity(HANAUtility.getBlankvalueIfNull(s4Profiler.getComplexity()));
				s4DetailRemediReport.setDescOfChange(HANAUtility.getBlankvalueIfNull(s4Profiler.getDescOfChange()));
				s4DetailRemediReport.setErrorCategory(HANAUtility.getBlankvalueIfNull(s4Profiler.getErrorCategory()));
				s4DetailRemediReport
						.setImpactedObjType(HANAUtility.getBlankvalueIfNull(s4Profiler.getImpactedObjType()));
				s4DetailRemediReport.setIssueCategory(HANAUtility.getBlankvalueIfNull(s4Profiler.getIssueCategory()));
				s4DetailRemediReport.setItemArea(HANAUtility.getBlankvalueIfNull(s4Profiler.getItemArea()));
				s4DetailRemediReport.setSapNotes(HANAUtility.getBlankvalueIfNull(s4Profiler.getSapNotes()));
				s4DetailRemediReport
						.setSapSimplCategry(HANAUtility.getBlankvalueIfNull(s4Profiler.getSapSimplCategry()));
				s4DetailRemediReport
						.setSapSimpListChapter(HANAUtility.getBlankvalueIfNull(s4Profiler.getSapSimpListChapter()));
				s4DetailRemediReport.setUsed(HANAUtility.getBlankvalueIfNull(s4Profiler.getUsed()));
				s4DetailRemediReport.setTriggerObj(HANAUtility.getBlankvalueIfNull(s4Profiler.getTriggerObj()));
				s4DetailRemediReport.setSolutionSteps(HANAUtility.getBlankvalueIfNull(s4Profiler.getSolutionSteps()));
				s4DetailRemediReport
						.setRemediationCategory(HANAUtility.getBlankvalueIfNull(s4Profiler.getRemediationCategory()));

				s4DetailRemedReportList.add(s4DetailRemediReport);
			}

			populateHanaTable.populateDataList(s4DetailRemedReportList);
		}

	}

	@SuppressWarnings("unchecked")
	private List<S4HanaProfiler> getDataFrRemediReport(long requestId) {
		logger.info("Steps For updateDetailReport****************");
		List<S4HanaProfiler> s4HanaProfilerLst = null;
		Session session = null;
		try {
			session = this.hibernateTemplate.getSessionFactory().openSession();

			/*
			 * String sql="Select * from s4_final_output natural join( " +
			 * "select XYZ.TYPE,XYZ.OBJ_NAME,XYZ.remediation_category, CASE " +
			 * " WHEN XYZ.B1='1' THEN 'TBD' " + " WHEN XYZ.B1='2' THEN 'HIGH' " +
			 * " WHEN XYZ.B1 ='3' THEN 'MEDIUM' " + " WHEN XYZ.B1 ='4' THEN 'LOW' " +
			 * " WHEN XYZ.B1 ='5' THEN 'VERY LOW' " + " END AS COMPLEXITY FROM( " +
			 * " Select type, OBJ_NAME,remediation_category, MIN(CASE " +
			 * " WHEN COMPLEXITY ='TBD' THEN '1' " + " WHEN COMPLEXITY ='HIGH' THEN '2' " +
			 * " WHEN  COMPLEXITY ='MEDIUM' THEN '3' " +
			 * " WHEN  COMPLEXITY ='LOW' THEN '4' " +
			 * " WHEN  COMPLEXITY ='VERY LOW' THEN '5' " + " END)B1 " + " FROM ( " +
			 * " Select type,OBJ_NAME,complexity,  remediation_category " +
			 * " from s4_final_output f natural join( " +
			 * " select abc.TYPE,ABC.OBJ_NAME, abc.complexity, CASE " +
			 * " WHEN ABC.A1 =  '1' THEN 'Mandatory' " +
			 * " WHEN ABC.A1 =  '2' THEN 'Optional' " + " END as remediation_category  " +
			 * " FROM( " + " Select type, OBJ_NAME, complexity, MIN(CASE " +
			 * " wHEN remediation_category =  'Mandatory' THEN '1' " +
			 * " WHEN  remediation_category =  'Optional' THEN '2' " +" END)A1 "
			 * +" FROM s4_final_output where request_id=:requesId GROUP BY concat(TYPE, OBJ_NAME,complexity))as abc ) "
			 * + "  as  NJ "
			 * +" where request_id=:requestId GROUP BY concat(TYPE, OBJ_NAME,remediation_category, complexity)) "
			 * +" as Complexity  GROUP BY concat(TYPE, OBJ_NAME))as XYZ) "
			 * +"as NJO where request_id=:requstId group by concat(OBJ_NAME,TYPE,remediation_category)"
			 * ;
			 */

			String sql = "select * from s4_final_output f natural join "
					+ "(select type,obj_name, remediation_category,complexity, case when complexity='TBD' then '1' "
					+ " when complexity='High' then '2' " + " when complexity='Medium' then '3' "
					+ " when complexity='Low' then '4' " + " when complexity='Very Low' then '5' END as ABC "
					+ " from s4_final_output where request_id=:requestId group by "
					+ " concat(type, obj_name, abc, remediation_category)) as NJ where request_id=:requestId "
					+ " group by concat(f.type,f.obj_name)";

			Query query = session.createSQLQuery(sql).addEntity(S4HanaProfiler.class);
			query.setParameter("requestId", requestId);
			logger.info("******************" + query.getQueryString());
			s4HanaProfilerLst = query.list();
		} catch (Exception e) {
			logger.error("getDataFrRemediReport :: ", e);
		} finally {
			if (null != session) {
				session.close();
			}
		}

		return s4HanaProfilerLst;
	}

	// update complexity
	private void updateComplexity(long requestId) {
		logger.info("Steps For updateComplexity");
		long startTimeforupdateComplexityWrite = System.currentTimeMillis();
		updateComplexityWrite(requestId);
		long endTimeforupdateComplexityWrite = System.currentTimeMillis();
		long netTimeupdateComplexityWrite = endTimeforupdateComplexityWrite - startTimeforupdateComplexityWrite;
		logger.info("Total time for updateComplexityWrite: " + netTimeupdateComplexityWrite);
		long startTimeforupdatecomplexityOpr = System.currentTimeMillis();
		updatecomplexityOpr(requestId);
		long endTimeforupdatecomplexityOpr = System.currentTimeMillis();
		long netTimeupdatecomplexityOpr = endTimeforupdatecomplexityOpr - startTimeforupdatecomplexityOpr;
		logger.info("Total time for updatecomplexityOpr: " + netTimeupdatecomplexityOpr);
		// updateComplexityDataDeclar(requestId);
		long startTimeforupdateComplexityBDC = System.currentTimeMillis();
		updateComplexityBDC(requestId);
		long endTimeforupdateComplexityBDC = System.currentTimeMillis();
		long netTimeupdateComplexityBDC = endTimeforupdateComplexityBDC - startTimeforupdateComplexityBDC;
		logger.info("Total time for updateComplexityBDC: " + netTimeupdateComplexityBDC);
		long startTimeforupdateComplexityINDE = System.currentTimeMillis();
		updateComplexityINDE(requestId);
		long endTimeforupdateComplexityINDE = System.currentTimeMillis();
		long netTimeupdateComplexityINDE = endTimeforupdateComplexityINDE - startTimeforupdateComplexityINDE;
		logger.info("Total time for updateComplexityINDE: " + netTimeupdateComplexityINDE);

	}

	private void updateComplexityWrite(long requestId) {
		logger.info("Steps For updateComplexity");
		String identifier;
		Session session = null;
		String sql = "update  s4_final_output f set complexity=(select case WHEN Issue_Catgry =:issueCategory AND Identifier =:identifier THEN 'high' ELSE complexity end from S4_OPERATION_DATA where Identifier =:identfir and REQUEST_ID =:requestID),Remediation_Category=(select case WHEN Issue_Catgry =:issueCategory AND Identifier =:identifier THEN 'Mandatory' ELSE Remediation_Category end from S4_OPERATION_DATA where Identifier =:identfir and REQUEST_ID =:requestID) where f.request_Id =:requestID and f.operations=:operations and f.identifier=:identifr";
		try {
			session = this.hibernateTemplate.getSessionFactory().openSession();
			List<String> identifierList = getIdentifier(requestId, "WRITE");
			if (null != identifierList && !identifierList.isEmpty()) {
				Iterator<String> identifierItr = identifierList.iterator();
				while (identifierItr.hasNext()) {
					identifier = identifierItr.next();
					Query query = session.createSQLQuery(sql);
					query.setParameter("issueCategory", "New Data Model");
					query.setParameter("identifier", identifier);
					query.setParameter("identfir", identifier);
					query.setParameter("issueCategory", "New Data Model");
					query.setParameter("identifier", identifier);
					query.setParameter("identfir", identifier);
					query.setParameter("requestID", requestId);
					query.setParameter("operations", "WRITE");
					query.setParameter("identifr", identifier);
					query.executeUpdate();
				}
			}
		} catch (Exception e) {
			logger.error("updateComplexityWrite :: ", e);
		} finally {
			if (null != session) {
				session.close();
			}
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void updatecomplexityOpr(final Long requestId) {
		final int count = (int) hibernateTemplate.execute(new HibernateCallback() {
			public Object doInHibernate(Session session) throws HibernateException {
				final Query query = session.createQuery(
						"update S4HanaProfiler set complexity=:complexity where operations in (:operations) and requestID = :requestID");
				query.setParameter("complexity", "low");
				query.setParameterList("operations",
						new String[] { "Data Declaration", "Tables Declaration", "constant Declaration" });

				query.setParameter("requestID", requestId);
				return query.executeUpdate();
			}
		});
		logger.info("updatecomplexityOpr...." + count);

	}

	private void updateComplexityDataDeclar(long requestId) {
		logger.info("Steps For updateComplexityDataDeclar");
		String identifier;
		String sql = "update  S4HanaProfiler set complexity=(select case WHEN issueCatgry =:issueCatgry AND identifier =:identifier AND solutionSteps LIKE concat('%','Compatibility View: ',triggerObj,'%') THEN 'No Efforts' end from OperationDataS4 where identifier =:identifier) where requestID =:requestID and operations=:opr and identifier=:ident";

		Session session = this.hibernateTemplate.getSessionFactory().openSession();

		List<String> identifierList = getIdentifier(requestId, "Data Declaration");
		if (null != identifierList && !identifierList.isEmpty()) {
			Iterator<String> identifierItr = identifierList.iterator();
			while (identifierItr.hasNext()) {
				identifier = identifierItr.next();
				Query query = session.createQuery(sql);
				query.setParameter("issueCatgry", "New Data Model");
				query.setParameter("identifier", identifier);
				query.setParameter("identifier", identifier);
				query.setParameter("requestID", requestId);
				query.setParameter("opr", "Data Declaration");
				query.setParameter("ident", identifier);
				query.executeUpdate();
			}
		}
		if (session != null) {
			session.close();
		}
	}

	private void updateComplexityBDC(long requestId) {
		logger.info("Steps For updateComplexityBDC");
		String identifier;
		String sql = "update  S4HanaProfiler set complexity=(select case WHEN issueCatgry =:issueCatgry AND identifier =:identifier THEN 'medium' ELSE complexity end from OperationDataS4 where identifier =:identifier) where requestID =:requestID and operations=:opr AND identifier=:ident";

		Session session = this.hibernateTemplate.getSessionFactory().openSession();

		List<String> identifierList = getIdentifier(requestId, "BDC");
		if (null != identifierList && !identifierList.isEmpty()) {
			Iterator<String> identifierItr = identifierList.iterator();
			while (identifierItr.hasNext()) {
				identifier = identifierItr.next();
				Query query = session.createQuery(sql);
				query.setParameter("issueCatgry", "New Transaction");
				query.setParameter("identifier", identifier);
				query.setParameter("identifier", identifier);
				query.setParameter("requestID", requestId);
				query.setParameter("opr", "BDC");
				query.setParameter("ident", identifier);
				query.executeUpdate();
			}
		}
		if (session != null) {
			session.close();
		}
	}

	private void updateComplexityINDE(long requestId) {

		Session session = this.hibernateTemplate.getSessionFactory().openSession();
		String sql = "update S4HanaProfiler set complexity=:complexity where requestID=:requestID and type=:type";
		Query query = session.createQuery(sql);
		query.setParameter("complexity", "Low");
		query.setParameter("requestID", requestId);
		query.setParameter("type", "INDE");
		query.executeUpdate();
		if (session != null) {
			session.close();
		}
	}

	private List<String> getIdentifier(long requestId, String operation) {
		List<String> identifierLst = null;
		Session session = null;
		try {
			session = this.hibernateTemplate.getSessionFactory().openSession();
			String sql = "SELECT distinct identifier FROM S4Detection where requestID=:requestID  and operations=:operations";
			Query query = session.createQuery(sql);
			query.setParameter("requestID", requestId);
			query.setParameter("operations", operation);
			identifierLst = query.list();
		} catch (Exception e) {
			logger.error("getIdentifier :: ", e);
		} finally {
			if (null != session) {
				session.close();
			}
		}
		return identifierLst;
	}

	private void updateInventoryUsage(long requestId) {

		/*
		 * List<S4UsageAnalysis> usageList=getUsage(requestId); if(usageList!=null &&
		 * !usageList.isEmpty()){
		 * 
		 * Iterator<S4UsageAnalysis> usageItr=usageList.iterator();
		 * while(usageItr.hasNext()){ S4UsageAnalysis usage=usageItr.next(); String
		 * objName=usage.getObjName();
		 */
		/*
		 * update S4_Final_Output fo INNER JOIN s4_usage_analysis ua ON
		 * fo.OBJ_NAME=ua.OBJ_NAME set USED=:USED where fo.REQUEST_ID=:request_id &
		 * ua.REQUEST_ID=:requestId
		 */
		String sql = "update s4_inventory_list il Left outer JOIN Usage_Analysis ua ON il.OBJ_NAME_TYPE=ua.objNameType set used='Y' where il.REQUEST_ID= "
				+ requestId + " and ua.requestID= " + requestId;
		updateFrmTables(sql);

		/*
		 * } }
		 */

	}

	private void updateUsage(long requestId) {

		String sql = "update S4_Final_Output fo Left outer JOIN Usage_Analysis ua ON fo.OBJ_NAME_TYPE=ua.objNameType set fo.USED= 'Y' where fo.REQUEST_ID= "
				+ requestId + " and ua.requestID= " + requestId;

		updateFrmTables(sql);

	}

	private Map<String,Boolean> manualUpdate(long requestId, HttpSession session) throws SQLException {
		List<S4HanaProfiler> s4HanaProfilerList = new ArrayList<S4HanaProfiler>();
		
		final List<S4Detection> s4DetectionList = getS4DetectionList(requestId);
		Map<String,Boolean> sapNote= new HashMap<String,Boolean>();
		sapNote.put("2522971", false);
		sapNote.put("2340247", false);
		Boolean WMQK= false, WMWK= false;
		CodeAssessmentPayLoad ca = St03ReaderXlsx.getHm();
		
		if (s4DetectionList != null && !s4DetectionList.isEmpty()) {
			Iterator<S4Detection> s4DetectionIterator = s4DetectionList.iterator();
			while (s4DetectionIterator.hasNext()) {
				S4HanaProfiler s4Hanaprofiler = new S4HanaProfiler();

				S4Detection s4Detection = s4DetectionIterator.next();
				s4Hanaprofiler.setObjName(HANAUtility.getBlankvalueIfNull(s4Detection.getObjectName()));
				s4Hanaprofiler.setSubObject(HANAUtility.getBlankvalueIfNull(s4Detection.getSubProgram()));
				s4Hanaprofiler.setIdentifier(HANAUtility.getBlankvalueIfNull(s4Detection.getIdentifier()));
				s4Hanaprofiler.setMethod(HANAUtility.getBlankvalueIfNull(s4Detection.getSubType()));
				s4Hanaprofiler.setPckg(HANAUtility.getBlankvalueIfNull(s4Detection.getObjPackage()));
				s4Hanaprofiler.setType(HANAUtility.getBlankvalueIfNull(s4Detection.getType()));
				s4Hanaprofiler.setLineNo(s4Detection.getLineNo());
				s4Hanaprofiler.setStmt(HANAUtility.getBlankvalueIfNull(s4Detection.getStatement()));
				s4Hanaprofiler.setOperations(HANAUtility.getBlankvalueIfNull(s4Detection.getOperations()));
				s4Hanaprofiler.setImpactReason(HANAUtility.getBlankvalueIfNull(s4Detection.getComments()));
				s4Hanaprofiler.setAffectObjDesc(HANAUtility.getBlankvalueIfNull(s4Detection.getDescription()));
				s4Hanaprofiler.setREAD_PROG(HANAUtility.getBlankvalueIfNull(s4Detection.getREAD_PROG()));
				// Need to be checked from abap team
				s4Hanaprofiler.setTrigger_Object(HANAUtility.getBlankvalueIfNull(s4Detection.getDescription()));

				// CR-22.0
				s4Hanaprofiler.setImpactedObjType(HANAUtility.getBlankvalueIfNull(s4Detection.getObjType()));
				// CR-26.0
				s4Hanaprofiler.setTotalScannedLine(s4Detection.getTotalScannedLine());
				s4Hanaprofiler.setAutomationStatus(s4Detection.getAutomationStatus());
				s4Hanaprofiler.setCustomFields(s4Detection.getCustomFields());

				s4Hanaprofiler.setRequestId((s4Detection.getRequestId()));
				s4Hanaprofiler.setSELECT_LINE(s4Detection.getSelectLine());

				s4Hanaprofiler.setObjNameType(HANAUtility.getBlankvalueIfNull(s4Detection.getObjNameType()));
				s4Hanaprofiler.setUsed(HANAUtility.getBlankvalueIfNull(s4Detection.getUsed()));
				s4Hanaprofiler.setCorProgName(HANAUtility.getBlankvalueIfNull(s4Detection.getCorProgName()));
				s4Hanaprofiler.setCorLineNo(HANAUtility.getBlankvalueIfNull(s4Detection.getCorLineNo()));
				s4Hanaprofiler.setToolVersion(s4Detection.getToolVersion() == 0 ? "" : String.valueOf(s4Detection.getToolVersion()));
				s4Hanaprofiler.setExtNamespace(HANAUtility.getBlankvalueIfNull(s4Detection.getExtNamespace()));
				s4Hanaprofiler.setCounter(HANAUtility.getBlankvalueIfNull(s4Detection.getCounter()));
				
				if (MapUtils.isNotEmpty(ca.getMetaDataMap()) && ca.getMetaDataMap().containsKey(s4Detection.getObjNameType())) {
					if (null != ca.getMetaDataMap().get(s4Detection.getObjNameType())) {
						s4Hanaprofiler.setRicefCategory(
								ca.getMetaDataMap().get(s4Detection.getObjNameType()).getRicefCategory());
					}
					if (null != ca.getMetaDataMap().get(s4Detection.getObjNameType()) && null != ca.getMetaDataMap().get(s4Detection.getObjNameType()).getRicefSubCategory()) {
						s4Hanaprofiler.setRicefSubCategory(ca.getMetaDataMap().get(s4Detection.getObjNameType()).getRicefSubCategory());
					}
				}
				if (StringUtils.isBlank(s4Hanaprofiler.getRicefCategory()) && "SSFO".equalsIgnoreCase(s4Hanaprofiler.getType())) {
					s4Hanaprofiler.setRicefCategory("FORMS");
					s4Hanaprofiler.setRicefSubCategory("Smartforms");
				}
				if (StringUtils.isBlank(s4Hanaprofiler.getRicefCategory()) && "SFPF".equalsIgnoreCase(s4Hanaprofiler.getType())) {
					s4Hanaprofiler.setRicefCategory("FORMS");
					s4Hanaprofiler.setRicefSubCategory("Adobe");
				}
				if ("AQQU".equalsIgnoreCase(s4Hanaprofiler.getType())) {
					s4Hanaprofiler.setRicefCategory("Others");
					s4Hanaprofiler.setRicefSubCategory("Configurable Report");
				}
				
				if (StringUtils.isBlank(s4Hanaprofiler.getRicefCategory()))
					s4Hanaprofiler.setRicefCategory(Hana_Profiler_Constant.OTHERS);
				
				// SAP note 2522971 and 2340247 ( CR- 822 & 817)
				if (s4Hanaprofiler.getType().equalsIgnoreCase("TABL")
						&& s4Hanaprofiler.getIdentifier().startsWith("RELV")
						&& s4Hanaprofiler.getImpactReason().equalsIgnoreCase("N")) {

					if (s4Hanaprofiler.getObjName().equalsIgnoreCase("MARA")) {
						sapNote.put("2522971", true);
					}
					if (s4Hanaprofiler.getObjName().equalsIgnoreCase("WMQK")) {
						WMQK = true;
					}
					if (s4Hanaprofiler.getObjName().equalsIgnoreCase("WMWK")) {
						WMWK = true;
					}
					if (WMQK && WMWK) {
						sapNote.put("2340247", true);
					}
				}
	
				if (!(s4Hanaprofiler.getType().equalsIgnoreCase("TABL")
						&& s4Hanaprofiler.getIdentifier().startsWith("RELV")
						&& (s4Hanaprofiler.getObjName().equalsIgnoreCase("MARA")
								|| s4Hanaprofiler.getObjName().equalsIgnoreCase("WMQK")
								|| s4Hanaprofiler.getObjName().equalsIgnoreCase("WMWK")))) {
					s4HanaProfilerList.add(s4Hanaprofiler);
				}
			}
			
			logger.info("LIST SIZE Populate " + s4HanaProfilerList.size());

			long startTimeforjDBCBatchS4HanaProfilerUpdate = System.currentTimeMillis();
			jDBCBatchS4HanaProfilerUpdate(s4HanaProfilerList, session);
			long endTimeforjDBCBatchS4HanaProfilerUpdate = System.currentTimeMillis();
			long netTimejDBCBatchS4HanaProfilerUpdate = endTimeforjDBCBatchS4HanaProfilerUpdate
					- startTimeforjDBCBatchS4HanaProfilerUpdate;
			logger.info("Total time for jDBCBatchS4HanaProfilerUpdate: " + netTimejDBCBatchS4HanaProfilerUpdate);
			// populateHanaTable.populateDataList(s4HanaProfilerList);
		}
		return sapNote;
	}

	public static void jDBCBatchS4HanaProfilerUpdate(List<S4HanaProfiler> s4HanaProfilerList, HttpSession session)
			throws SQLException {
		final String INSERT_SQL = "INSERT INTO s4_final_output "
				+ "(OBJ_NAME, SUB_OBJ, METHOD, PCKG, USED, TYPE, IMPACTED_OBJ_TYPE, LINE_NO, STMT, "
				+ "OPERATIONS, IMPACT_REASON, AFFECT_OBJ_DESC, DESC_OF_CHANGE, SAP_NOTES, SOLUTION_STEPS, "
				+ "complexity, ISSUE_CATEGORY, ERROR_CATEGORY, TRIGGER_OBJ, SAP_SIMP_LIST, APP_COMPONENT, "
				+ "SAP_SIMPL_CATEGORY, ITEM_AREA, IDENTIFIER, Remediation_Category, Total_Scanned_Line, "
				+ "Affected_Area, REQUEST_ID, OBJ_NAME_TYPE, READ_PROG, SELECT_LINE, Issue_Sub_Category, "
				+ "Trigger_Object, Impact, CUSTOM_FIELDS, Correction_ProgName, Correction_LineNo, RICEF_CATEGORY, "
				+ "TOOL_VERSION, External_Namespace, Automation_Status, RICEF_SUB_CATEGORY, Counter) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (S4HanaProfiler hpro : s4HanaProfilerList) {
					stmt.setString(1, hpro.getObjName());
					stmt.setString(2, hpro.getSubObject());
					stmt.setString(3, hpro.getMethod());
					stmt.setString(4, hpro.getPckg());
					stmt.setString(5, hpro.getUsed());
					stmt.setString(6, hpro.getType());
					stmt.setString(7, hpro.getImpactedObjType());
					stmt.setLong(8, hpro.getLineNo());
					stmt.setString(9, hpro.getStmt());
					stmt.setString(10, hpro.getOperations());
					stmt.setString(11, hpro.getImpactReason());
					stmt.setString(12, hpro.getAffectObjDesc());
					stmt.setString(13, hpro.getDescOfChange());
					stmt.setString(14, hpro.getSapNotes());
					stmt.setString(15, hpro.getSolutionSteps());
					stmt.setString(16, hpro.getComplexity());
					stmt.setString(17, hpro.getIssueCategory());
					stmt.setString(18, hpro.getErrorCategory());
					stmt.setString(19, hpro.getTriggerObj());
					stmt.setString(20, hpro.getSapSimpListChapter());
					stmt.setString(21, hpro.getApplicationComponent());
					stmt.setString(22, hpro.getSapSimplCategry());
					stmt.setString(23, hpro.getItemArea());
					stmt.setString(24, hpro.getIdentifier());
					stmt.setString(25, hpro.getRemediationCategory());
					stmt.setLong(26, hpro.getTotalScannedLine());
					stmt.setString(27, hpro.getAffectedArea());
					stmt.setLong(28, hpro.getRequestId());
					stmt.setString(29, hpro.getObjNameType());
					stmt.setString(30, hpro.getREAD_PROG());
					stmt.setString(31, hpro.getSELECT_LINE());
					stmt.setString(32, hpro.getIssue_Sub_Category());
					stmt.setString(33, hpro.getTrigger_Object());
					stmt.setString(34, hpro.getImpact());
					stmt.setString(35, hpro.getCustomFields());
					stmt.setString(36, hpro.getCorProgName());
					stmt.setString(37, hpro.getCorLineNo());
					stmt.setString(38, hpro.getRicefCategory());
					stmt.setString(39, hpro.getToolVersion());
					stmt.setString(40, hpro.getExtNamespace());
					stmt.setString(41, hpro.getAutomationStatus());
					stmt.setString(42, hpro.getRicefSubCategory());
					stmt.setString(43, hpro.getCounter());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("Final batch executed successfully");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}
	}

	private void updateFrmOprData(final long requestId) {

		String sql = "update S4_Final_Output s4FinalOutput Left outer JOIN S4_OPERATION_DATA oprData on s4FinalOutput.IDENTIFIER=oprData.IDENTIFIER "
				+ "set s4FinalOutput.Affected_Area=oprData.Affected_Area, s4FinalOutput.DESC_OF_CHANGE=oprData.Description ,s4FinalOutput.SAP_NOTES=oprData.Related_Notes, "
				+ "s4FinalOutput.SOLUTION_STEPS=oprData.Solution_Steps,s4FinalOutput.ISSUE_CATEGORY=oprData.Issue_Catgry,s4FinalOutput.ERROR_CATEGORY=oprData.Err_category,s4FinalOutput.TRIGGER_OBJ=oprData.Trigger_Obj, "
				+ "s4FinalOutput.SAP_SIMP_LIST=oprData.Sap_Simpl_List_Chaptr,"
				+ "s4FinalOutput.IMPACTED_OBJ_TYPE=oprData.Object_Type, s4FinalOutput.Obsolete=oprData.Obsolete, "
				+ "s4FinalOutput.APP_COMPONENT=oprData.App_Comp,s4FinalOutput.SAP_SIMPL_CATEGORY=oprData.Sap_Simpl_Catry, "
				+ "s4FinalOutput.ITEM_AREA=oprData.Itm_Area,s4FinalOutput.COMPLEXITY=oprData.Complexity, "
				+ "s4FinalOutput.Impact=oprData.Impact, "
				+ "s4FinalOutput.Remediation_Category=oprData.Remediation_Catgry " + "where s4FinalOutput.request_id="
				+ requestId + " and oprData.REQUEST_ID=" + requestId;

		long startTimeforupdateFrmTables = System.currentTimeMillis();
		updateFrmTables(sql);
		long endTimeforupdateFrmTables = System.currentTimeMillis();
		long netTimeupdateFrmTables = endTimeforupdateFrmTables - startTimeforupdateFrmTables;
		logger.info("Total time for updateFrmTables: " + netTimeupdateFrmTables);

	}

	private List<SimplificationLatest> getSimpliLatestData() {
		List<SimplificationLatest> simplLatestLst = null;
		Session session = null;
		try {
			logger.info("Steps For getUsage****************");
			session = this.hibernateTemplate.getSessionFactory().openSession();

			String sql = "SELECT * FROM S4_Simplification_Latest s INNER JOIN S4_OPERATION_DATA dete ON s.Identifier=dete.Identifier ";
			Query query = session.createSQLQuery(sql).addEntity(SimplificationLatest.class);

			logger.info("******************" + query.getQueryString());
			simplLatestLst = query.list();
		} catch (Exception e) {
			logger.error("getSimpliLatestData :: ", e);
		} finally {
			if (null != session) {
				session.close();
			}
		}
		return simplLatestLst;
	}

	/*
	 * private List<OperationDataS4> getOprData() {
	 * 
	 * final Session session=sessionFactory.openSession(); try{ final Criteria
	 * criteria=session.createCriteria(OperationDataS4.class);
	 * //criteria.add(Restrictions.eq("identifier", identifier)); return
	 * criteria.list(); }catch(Exception e){ logger.error("Error !!! " + e);
	 * logger.error(e.getMessage()); logger.trace(e.getMessage()); throw new
	 * HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE); }finally{
	 * if(session!=null){ session.close(); } }
	 * 
	 * }
	 */

	private List<S4Detection> getS4DetectionList(long requestId) {

		final Session session = sessionFactory.openSession();
		try {
			final Criteria criteria = session.createCriteria(S4Detection.class);
			criteria.add(Restrictions.eq("requestID", requestId));
			return criteria.list();
		} catch (Exception e) {
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	/*
	 * private List<String> getS4DetectionOprJoinList(long requestId) {
	 * 
	 * logger.info("Steps For getS4DetectionOprJoinList****************"); Session
	 * session=this.hibernateTemplate.getSessionFactory().openSession();
	 * 
	 * String
	 * sql="SELECT distinct(sdetect.IDENTIFIER) FROM S4_DETECTION sdetect INNER JOIN S4_OPERATION_DATA soperate ON sdetect.IDENTIFIER=soperate.IDENTIFIER WHERE sdetect.REQUEST_ID=:requestId"
	 * ; Query query=session.createSQLQuery(sql); query.setParameter("requestId",
	 * requestId); //logger.info("******************"+query.getQueryString());
	 * return query.list(); }
	 * 
	 * 
	 * @SuppressWarnings("unchecked") private List<OperationDataS4>
	 * getOprDataJoinList(long requestId) {
	 * 
	 * logger.info("Steps For getOprDataJoinList****************"); Session
	 * session=this.hibernateTemplate.getSessionFactory().openSession();
	 * 
	 * String
	 * sql="SELECT * FROM s4_operation_data soperate INNER JOIN S4_DETECTION sdetect ON soperate.IDENTIFIER=sdetect.IDENTIFIER WHERE sdetect.REQUEST_ID=:requestId"
	 * ; Query query=session.createSQLQuery(sql).addEntity(OperationDataS4.class);;
	 * query.setParameter("requestId", requestId);
	 * logger.info("******************"+query.getQueryString()); return
	 * query.list(); }
	 */

	@Override
	public <T> String addSimplificationData(List<T> list) {
		String comment = "";
		Session session = null;
		try {
			session = sessionFactory.openSession();
			final int size = list.size();

			deleteSimpliLatestData();
			final int batchSize = 10000;
			for (int i = 0; i < size; i++) {
				session.saveOrUpdate(list.get(i));
				if (i % batchSize == 0) {
					session.flush();
					session.clear();
				}
			}
			session.flush();
			session.clear();
			comment = "success";

		} catch (Exception e) {
			comment = "err";
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if (session != null) {
				session.close();
			}
		}

		return comment;
	}

	public void deleteSimpliLatestData() {
		Query query = null;
		String hql = "delete from SimplificationLatest ";
		String hql1 = "select count(*) from SimplificationLatest ";

		Session session = sessionFactory.openSession();
		try {
			query = session.createQuery(hql1);
			int count = ((Long) query.uniqueResult()).intValue();

			if (count != 0) {
				query = session.createQuery(hql);
				query.executeUpdate();
			}
			// Session session=sessionFactory.openSession();
			// session.saveOrUpdate(reqMaster);

			session.close();
		} catch (Exception e) {
			e.getMessage();
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}

	}

	@Override
	public List<S4HanaProfiler_Download> getList(Long requestID, int from, int limit) {
		logger.info("Coming inside GetList method::::");
		Session session = this.hibernateTemplate.getSessionFactory().openSession();
		logger.info("Open Session successfully");
		Criteria criteria = session.createCriteria(S4HanaProfiler_Download.class);
		logger.info("Created Criteria successfully::::");
		ProjectionList projectionList = Projections.projectionList();
		projectionList.add(Projections.property("objName"), "objName");
		// projectionList.add(Projections.property("subObject"),"subObject");
		projectionList.add(Projections.property("method"), "method");
		projectionList.add(Projections.property("READ_PROG"), "READ_PROG");
		projectionList.add(Projections.property("pckg"), "pckg");
		projectionList.add(Projections.property("used"), "used");
		projectionList.add(Projections.property("type"), "type");
		projectionList.add(Projections.property("impactedObjType"), "impactedObjType");
		projectionList.add(Projections.property("lineNo"), "lineNo");
		projectionList.add(Projections.property("stmt"), "stmt");
		projectionList.add(Projections.property("operations"), "operations");
		projectionList.add(Projections.property("impactReason"), "impactReason");
		// projectionList.add(Projections.property("affectObjDesc"),"affectObjDesc");
		projectionList.add(Projections.property("descOfChange"), "descOfChange");
		projectionList.add(Projections.property("sapNotes"), "sapNotes");
		projectionList.add(Projections.property("solutionSteps"), "solutionSteps");
		projectionList.add(Projections.property("complexity"), "complexity");
		projectionList.add(Projections.property("issueCategory"), "issueCategory");
		projectionList.add(Projections.property("errorCategory"), "errorCategory");
		projectionList.add(Projections.property("triggerObj"), "triggerObj");
		// projectionList.add(Projections.property("Trigger_Object"),"Trigger_Object");
		projectionList.add(Projections.property("sapSimpListChapter"), "sapSimpListChapter");
		projectionList.add(Projections.property("applicationComponent"), "applicationComponent");
		projectionList.add(Projections.property("sapSimplCategry"), "sapSimplCategry");
		projectionList.add(Projections.property("itemArea"), "itemArea");
		// projectionList.add(Projections.property("identifier"),"identifier");
		// CR-26.0
		// projectionList.add(Projections.property("totalScannedLine"),"totalScannedLine");
		// CR-23.0
		// projectionList.add(Projections.property("affectedArea"),"affectedArea");

		projectionList.add(Projections.property("remediationCategory"), "remediationCategory");
		projectionList.add(Projections.property("SELECT_LINE"), "SELECT_LINE");
		projectionList.add(Projections.property("corProgName"), "corProgName");
		projectionList.add(Projections.property("corLineNo"), "corLineNo");
		projectionList.add(Projections.property("automationStatus"), "automationStatus");
		projectionList.add(Projections.property("Impact"), "Impact");
		projectionList.add(Projections.property("ricefCategory"), "ricefCategory");
		projectionList.add(Projections.property("toolVersion"), "toolVersion");
		projectionList.add(Projections.property("extNamespace"), "extNamespace");
		projectionList.add(Projections.property("ricefSubCategory"), "ricefSubCategory");
		projectionList.add(Projections.property("Issue_Sub_Category"), "Issue_Sub_Category");
		// projectionList.add(Projections.property("requestID"),"requestID");

		if (limit != 0) {
			criteria.setMaxResults(limit);
		}
		if (from != 0) {
			criteria.setFirstResult(from);
		}

		criteria.add(Restrictions.eq("requestID", requestID));
		criteria.setProjection(Projections.distinct(projectionList));
		criteria.setResultTransformer(Transformers.aliasToBean(S4HanaProfiler_Download.class));
		List<S4HanaProfiler_Download> s4HanaProfilerList = criteria.list();
		logger.info("List Size " + s4HanaProfilerList.size());
		session.close();
		return s4HanaProfilerList;
	}

	@Override
	public List<DrillDown_Download> getDrillDownReportList(Long requestID) {
		logger.info("Getting the list of DrillDown Report ...");

		Session session = null;
		List<DrillDown_Download> drilldownReportList = null;

		try {
			session = this.hibernateTemplate.getSessionFactory().openSession();

			Criteria criteria = session.createCriteria(DrillDown_Download.class);
			ProjectionList projectionList = Projections.projectionList();

			projectionList.add(Projections.property("objName"), "objName");
			projectionList.add(Projections.property("method"), "method");
			projectionList.add(Projections.property("readProgram"), "readProgram");
			projectionList.add(Projections.property("pckg"), "pckg");
			projectionList.add(Projections.property("used"), "used");
			projectionList.add(Projections.property("type"), "type");
			projectionList.add(Projections.property("impactedObjType"), "impactedObjType");
			projectionList.add(Projections.property("lineNo"), "lineNo");
			projectionList.add(Projections.property("stmt"), "stmt");
			projectionList.add(Projections.property("operations"), "operations");
			projectionList.add(Projections.property("impactReason"), "impactReason");
			projectionList.add(Projections.property("descOfChange"), "descOfChange");
			projectionList.add(Projections.property("sapNotes"), "sapNotes");
			projectionList.add(Projections.property("solutionSteps"), "solutionSteps");
			projectionList.add(Projections.property("complexity"), "complexity");
			projectionList.add(Projections.property("issueCategory"), "issueCategory");
			projectionList.add(Projections.property("errorCategory"), "errorCategory");
			projectionList.add(Projections.property("triggerObj"), "triggerObj");
			projectionList.add(Projections.property("sapSimpListChapter"), "sapSimpListChapter");
			projectionList.add(Projections.property("applicationComponent"), "applicationComponent");
			projectionList.add(Projections.property("sapSimplCategry"), "sapSimplCategry");
			projectionList.add(Projections.property("itemArea"), "itemArea");
			projectionList.add(Projections.property("remediationCategory"), "remediationCategory");
			projectionList.add(Projections.property("selectLine"), "selectLine");
			projectionList.add(Projections.property("corProgName"), "corProgName");
			projectionList.add(Projections.property("corLineNo"), "corLineNo");
			projectionList.add(Projections.property("impact"), "impact");
			projectionList.add(Projections.property("ricefCategory"), "ricefCategory");
			projectionList.add(Projections.property("toolVersion"), "toolVersion");

			criteria.add(Restrictions.eq("requestID", requestID));
			criteria.setProjection(projectionList);
			criteria.setResultTransformer(Transformers.aliasToBean(DrillDown_Download.class));
			drilldownReportList = criteria.list();
		} catch (Exception e) {
			logger.error("Error while fetching the DrillDown Report Data : ", e);
		} finally {
			if (session != null)
				session.close();
		}

		return drilldownReportList;
	}

	@Override
	public String addEstimatorData(final S4Estimations s4Estimations) {

		Query query = null;
		String comment;
		String hql = "delete from S4Estimations where requestID=" + s4Estimations.getRequestID();
		String hql1 = "select count(*) from S4Estimations where requestID=" + s4Estimations.getRequestID();

		Session session = sessionFactory.openSession();
		try {
			query = session.createQuery(hql1);
			int count = ((Long) query.uniqueResult()).intValue();

			if (count != 0) {
				query = session.createQuery(hql);
				query.executeUpdate();
			}
			// Session session=sessionFactory.openSession();
			session.saveOrUpdate(s4Estimations);

			session.close();
			comment = "success";
		} catch (Exception e) {
			comment = "Failed due to::" + e.getMessage();
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		return comment;
	}

	@Override
	public String addAssumptionsData(final S4Assumptions s4Assumptions) {

		Query query = null;
		String comment;
		String hql = "delete from S4Assumptions where requestID=" + s4Assumptions.getRequestID();
		String hql1 = "select count(*) from S4Assumptions where requestID=" + s4Assumptions.getRequestID();

		Session session = sessionFactory.openSession();
		try {
			query = session.createQuery(hql1);
			int count = ((Long) query.uniqueResult()).intValue();

			if (count != 0) {
				query = session.createQuery(hql);
				query.executeUpdate();
			}
			session.saveOrUpdate(s4Assumptions);

			session.close();
			comment = "success";
		} catch (Exception e) {
			comment = "Failed due to::" + e.getMessage();
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		return comment;
	}

	@Override
	public String addValidationData(List<S4ValidationList> validationDataS4List) {
		String comment = "";
		Session session = null;
		try {
			session = sessionFactory.openSession();
			final int size = validationDataS4List.size();
			deleteS4ValidateData();
			final int batchSize = Hana_Profiler_Constant.JDBC_BATCH_SIZE;
			for (int i = 0; i < size; i++) {
				session.saveOrUpdate(validationDataS4List.get(i));
				if (i % batchSize == 0) {
					session.flush();
					session.clear();
				}
			}
			session.flush();
			session.clear();
			comment = "success";

		} catch (Exception e) {
			comment = "err";
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if (session != null) {
				session.close();
			}
		}

		return comment;
	}

	public void deleteS4ValidateData() {
		Query query = null;
		String hql = "delete from S4ValidationList ";
		String hql1 = "select count(*) from S4ValidationList ";

		Session session = sessionFactory.openSession();
		try {
			query = session.createQuery(hql1);
			int count = ((Long) query.uniqueResult()).intValue();

			if (count != 0) {
				query = session.createQuery(hql);
				query.executeUpdate();
			}
			// Session session=sessionFactory.openSession();
			// session.saveOrUpdate(reqMaster);

			session.close();
		} catch (Exception e) {
			e.getMessage();
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}

	}

	// CR-40.0
	@Override
	public <T> String addSimplificationDBData(List<T> list) {
		String comment = "";
		Session session = null;
		try {
			session = sessionFactory.openSession();
			final int size = list.size();

			deleteS4SimpliDB();
			final int batchSize = Hana_Profiler_Constant.JDBC_BATCH_SIZE;
			for (int i = 0; i < size; i++) {
				session.saveOrUpdate(list.get(i));
				if (i % batchSize == 0) {
					session.flush();
					session.clear();
				}
			}
			session.flush();
			session.clear();
			comment = "success";

		} catch (Exception e) {
			comment = "err";
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if (session != null) {
				session.close();
			}
		}

		return comment;
	}

	public void deleteS4SimpliDB() {
		Query query = null;
		String hql = "delete from S4SimplificationDatabase ";
		String hql1 = "select count(*) from S4SimplificationDatabase ";

		Session session = sessionFactory.openSession();
		try {
			query = session.createQuery(hql1);
			int count = ((Long) query.uniqueResult()).intValue();

			if (count != 0) {
				query = session.createQuery(hql);
				query.executeUpdate();
			}
			// Session session=sessionFactory.openSession();
			// session.saveOrUpdate(reqMaster);

			session.close();
		} catch (Exception e) {
			e.getMessage();
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}

	}

	@Override
	public Integer getTotalCountOfList(Long requestID) {
		logger.info("Successfully get Sission From SessionFactory");
		Session session = sessionFactory.openSession();
		logger.info("create Criteria for get all records from DB");
		Criteria criteria = session.createCriteria(S4HanaProfiler.class);
		criteria.add(Restrictions.eq("requestID", requestID));
		criteria.setProjection(Projections.rowCount());
		Long count = (Long) criteria.uniqueResult();
		session.close();
		return count.intValue();

	}

	@Override
	public <T> String addDetectionData(List<T> list) {
		String comment = "";
		Session session = null;
		try {
			session = sessionFactory.openSession();
			final int size = list.size();

			deleteDetectionData();
			final int batchSize = 10000;
			for (int i = 0; i < size; i++) {
				session.saveOrUpdate(list.get(i));
				if (i % batchSize == 0) {
					session.flush();
					session.clear();
				}
			}
			session.flush();
			session.clear();
			comment = "success";

		} catch (Exception e) {
			comment = "err";
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if (session != null) {
				session.close();
			}
		}

		return comment;
	}

	private void deleteDetectionData() {
		Query query = null;
		String hql = "delete from S4Detection where requestID=0";
		String hql1 = "select count(*) from S4Detection where requestID=0";

		Session session = sessionFactory.openSession();
		try {
			query = session.createQuery(hql1);
			int count = ((Long) query.uniqueResult()).intValue();

			if (count != 0) {
				query = session.createQuery(hql);
				query.executeUpdate();
			}
			// Session session=sessionFactory.openSession();
			// session.saveOrUpdate(reqMaster);

			session.close();
		} catch (Exception e) {
			e.getMessage();
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}

	}

	@Override
	public String updateS4OperationIdentifier(long requestId) {
		String comment = "";
		try {
			String sql = "INSERT INTO S4_OPERATION_DATA (Identifier,REQUEST_ID) SELECT Distinct IDENTIFIER,REQUEST_ID FROM S4_DETECTION where REQUEST_ID= "
					+ requestId;

			updateFrmTables(sql);
			comment = "success";

		} catch (Exception e) {
			comment = "err";
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		return comment;
	}

	@Override
	public String updateOperDataFrmSimplLatest(long requestId) {
		String comment = "";
		try {
			String sql = "update S4_OPERATION_DATA o Inner JOIN S4_Simplification_Latest sl on o.Identifier=sl.Identifier "
					+ " set o.S4_Hana_Changes=sl.S4_Hana_Changes, o.Object=sl.Object,o.Object_Type=sl.Object_Type ,	"
					+ " o.Obsolete=sl.Obsolete,o.Description=sl.Description , o.Affected_Area=sl.Affected_Area,o.Related_Notes=sl.Related_Notes , "
					+ " o.Solution_Steps=sl.Solution_Steps,o.Err_Category_Numeric=sl.Err_Category_Numeric,o.Version=sl.Version,o.Complexity=sl.Complexity "
					+ " ,o.Issue_Catgry=sl.Issue_Catgry, o.Err_category=sl.Err_category ,o.Trigger_Obj=sl.Trigger_Obj, "
					+ " o.Remediation_Catgry=sl.Remediation_Catgry ,o.Sap_Simpl_List_Chaptr=sl.Sap_Simpl_List_Chaptr,o.App_Comp=sl.App_Comp , "
					+ " o.Sap_Simpl_Catry=sl.Sap_Simpl_Catry ,o.Itm_Area=sl.Itm_Area where o.REQUEST_ID= " + requestId;
			updateFrmTables(sql);
			comment = "success";

		} catch (Exception e) {
			comment = "err";
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		return comment;
	}

	public String updateOperDataFrmSimplDB(long requestId) {
		String comment = "";
		try {
			String sql = "update S4_OPERATION_DATA o Inner JOIN S4_Simplification_Database db "
					+ " on o.Identifier=db.Identifier set o.S4_Hana_Changes=db.S4_Hana_Changes, o.Object=db.Object, o.Object_Type=db.Object_Type,"
					+ " o.Obsolete=db.Obsolete, o.Description=db.Description, o.Affected_Area=db.Affected_Area, o.Related_Notes=db.Related_Notes,"
					+ " o.Solution_Steps=db.Solution_Steps, o.Err_Category_Numeric=db.Err_Category_Numeric, o.Version=db.Version,"
					+ " o.Complexity=db.Complexity, o.Issue_Catgry=db.Issue_Catgry,"
					+ " o.Err_category=db.Err_Category, o.Trigger_Obj=db.Trigger_Obj,"
					+ " o.Remediation_Catgry=db.Remediation_Catgry, o.Sap_Simpl_List_Chaptr=db.Sap_Simpl_List_Chaptr,"
					+ " o.App_Comp=db.App_Comp, o.Sap_Simpl_Catry=db.Sap_Simpl_Catry, o.Itm_Area=db.Itm_Area"
					+ " where o.Object IS NULL OR o.Object = '' AND o.REQUEST_ID= " + requestId;

			updateFrmTables(sql);
			comment = "success";
		} catch (Exception e) {
			comment = "err";
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		return comment;
	}

	public String updateImpact(long requestId) {
		String comment = "";
		try {
			String sql = "UPDATE " + "S4_OPERATION_DATA " + "SET " + "Impact = " + "CASE "
					+ "WHEN Sap_Simpl_Catry ='Functionality not available in SAP S/4HANA (no functional equivalent available)' THEN 'High' "
					+ "WHEN Sap_Simpl_Catry = 'Change of existing functionality' THEN 'Medium' "
					+ "WHEN Sap_Simpl_Catry = 'Non-Strategic-function (functional equivalent available)' THEN 'Low' "
					+ "WHEN Sap_Simpl_Catry = 'Non-Strategic-function (functional equivalent not available)' THEN 'Low' "
					+ "WHEN Sap_Simpl_Catry = 'Functionality not available in SAP S/4HANA ( functional equivalent available)' THEN 'Medium' "
					+ "WHEN Sap_Simpl_Catry = 'Functionality not available in SAP S/4HANA (functional equivalent available)' THEN 'Medium' "
					+ "WHEN Sap_Simpl_Catry = 'Functionality not available (functional equivalent available on roadmap for future release)' THEN 'High' "
					+ "END where REQUEST_ID= " + requestId;

			Session session = this.hibernateTemplate.getSessionFactory().openSession();
			Query query = session.createSQLQuery(sql);
			query.executeUpdate();
			if (null != session) {
				session.close();
			}
			comment = "success";
		} catch (Exception e) {
			comment = "err";
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		return comment;
	}

	@Override
	public String deleteOprDataS4(long requestId) {
		Query query = null;
		String hql = "delete from OperationDataS4 where REQUEST_ID= " + requestId;
		String hql1 = "select count(*) from OperationDataS4 where REQUEST_ID= " + requestId;
		String comment = "";

		Session session = sessionFactory.openSession();
		try {
			query = session.createQuery(hql1);
			int count = ((Long) query.uniqueResult()).intValue();

			if (count != 0) {
				query = session.createQuery(hql);
				query.executeUpdate();
			}

			session.close();
			comment = "success";

		} catch (Exception e) {
			comment = "err";
			e.getMessage();
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		return comment;

	}

	@Override
	public <T> String addSimplificationDataS(List<T> list) {
		String comment = "";
		Session session = null;
		try {
			session = sessionFactory.openSession();
			final int size = list.size();

			final int batchSize = 10000;
			for (int i = 0; i < size; i++) {
				session.saveOrUpdate(list.get(i));
				if (i % batchSize == 0) {
					session.flush();
					session.clear();
				}
			}
			session.flush();
			session.clear();
			comment = "success";

		} catch (Exception e) {
			comment = "err";
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if (session != null) {
				session.close();
			}
		}

		return comment;
	}

	private void deleteImpactedTransactionData(long requestId) {
		Query query = null;
		String hql = "delete from S4ImpactedTransaction where requestID= :request_id";

		Session session = sessionFactory.openSession();
		try {
			query = session.createQuery(hql);
			query.setParameter("request_id", requestId);
			query.executeUpdate();

			session.close();
		} catch (Exception e) {
			e.getMessage();
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	public List<S4CvitAssessment> getS4CvitAssessmentData(long requestId) {
		final Session session = sessionFactory.openSession();
		try {
			final Criteria criteria = session.createCriteria(S4CvitAssessment.class);
			criteria.add(Restrictions.eq("requestId", requestId));
			return criteria.list();
		} catch (Exception e) {
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	public String insertDataImpactedCustomTables(long requestId) {
		String comment = "";
		try {
			String sql = "insert into s4_impacted_custom_download (APPLICATION_COMP,"
					+ "COMMENTS,COMPLEXITY,DESC_CHANGE,INFO,ISSUE_CATEGORY,ITEM_AREA,"
					+ "OBJ_PACKAGE,OBJ_NAME,REMEDIATION_CATEGORY,SAP_SIMPLI_CATEGORY,"
					+ "SAP_SIMPLI_LIST,SOLUTION_STEP,TRIGGER_OBJECT,SAP_NOTE,REQUEST_ID,ISSUE_SUB_CATEGORY) "
					+ "select sd.App_Comp,im.COMMENTS,sd.Complexity,sd.Description,im.INFO,"
					+ "sd.Issue_Catgry,sd.Itm_Area,im.OBJ_PACKAGE,im.OBJ_NAME,sd.Remediation_Catgry,"
					+ "sd.Sap_Simpl_Catry,sd.Sap_Simpl_List_Chaptr,sd.Solution_Steps,sd.Trigger_Obj,"
					+ "sd.Related_Notes,im.REQUEST_ID, sd.Err_Category from s4_impacted_customtables im left join "
					+ "s4_simplification_database sd on im.INFO = sd.Identifier";

			updateFrmTables(sql);
			comment = "success";
		} catch (Exception e) {
			comment = "err";
			logger.error("Error in insertDataImpactedCustomTables :: ", e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		return comment;
	}
	
	@Override
	public List<ObsoleteFmsDueToUpgrade> getObsoleteFmsUpgradeReportList(Long requestID) {
		logger.info("Getting the list of Obsolete Fms Report ...");

		Session session = null;
		List<ObsoleteFmsDueToUpgrade> obsoleteReportList = null;

		try {
			session = this.hibernateTemplate.getSessionFactory().openSession();

			Criteria criteria = session.createCriteria(ObsoleteFmsDueToUpgrade.class);
			ProjectionList projectionList = Projections.projectionList();

			projectionList.add(Projections.property("objName"), "objName");
			projectionList.add(Projections.property("method"), "method");
			projectionList.add(Projections.property("readProgram"), "readProgram");
			projectionList.add(Projections.property("pckg"), "pckg");
			projectionList.add(Projections.property("used"), "used");
			projectionList.add(Projections.property("type"), "type");
			projectionList.add(Projections.property("impactedObjType"), "impactedObjType");
			projectionList.add(Projections.property("lineNo"), "lineNo");
			projectionList.add(Projections.property("stmt"), "stmt");
			projectionList.add(Projections.property("operations"), "operations");
			projectionList.add(Projections.property("impactReason"), "impactReason");
			projectionList.add(Projections.property("descOfChange"), "descOfChange");
			projectionList.add(Projections.property("sapNotes"), "sapNotes");
			projectionList.add(Projections.property("solutionSteps"), "solutionSteps");
			projectionList.add(Projections.property("complexity"), "complexity");
			projectionList.add(Projections.property("issueCategory"), "issueCategory");
			projectionList.add(Projections.property("triggerObj"), "triggerObj");
			projectionList.add(Projections.property("sapSimpListChapter"), "sapSimpListChapter");
			projectionList.add(Projections.property("applicationComponent"), "applicationComponent");
			projectionList.add(Projections.property("sapSimplCategry"), "sapSimplCategry");
			projectionList.add(Projections.property("itemArea"), "itemArea");
			projectionList.add(Projections.property("remediationCategory"), "remediationCategory");
			projectionList.add(Projections.property("selectLine"), "selectLine");
			projectionList.add(Projections.property("impact"), "impact");
			projectionList.add(Projections.property("ricefCategory"), "ricefCategory");
			projectionList.add(Projections.property("ricefSubCategory"), "ricefSubCategory");
			projectionList.add(Projections.property("extNamespace"), "extNamespace");
			projectionList.add(Projections.property("errorCategory"), "errorCategory");

			criteria.add(Restrictions.eq("requestID", requestID));
			criteria.setProjection(projectionList);
			criteria.setResultTransformer(Transformers.aliasToBean(ObsoleteFmsDueToUpgrade.class));
			obsoleteReportList = criteria.list();
		} catch (Exception e) {
			logger.error("Error while fetching the Obsolete Fms Report Data : ", e);
		} finally {
			if (session != null)
				session.close();
		}

		return obsoleteReportList;
	}
}