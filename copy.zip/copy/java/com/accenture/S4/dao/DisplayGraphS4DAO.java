package com.accenture.S4.dao;

import java.util.List;
import java.util.Map;

import com.accenture.Aadt.models.ACNIPZVERComp;
import com.accenture.S4.models.ABAPQueryInventoryDownload;
import com.accenture.S4.models.InventoryList_Download;
import com.accenture.S4.models.OperationDataS4;
import com.accenture.S4.models.S4AffectCustomField;
import com.accenture.S4.models.S4AffectCustomField_Download;
import com.accenture.S4.models.S4AppendStructureAnalysis;
import com.accenture.S4.models.S4AppendStructureAnalysis_Download;
import com.accenture.S4.models.S4Assumptions;
import com.accenture.S4.models.S4CloneProg;
import com.accenture.S4.models.S4CloneProg_Download;
import com.accenture.S4.models.S4DetailReportComplexity;
import com.accenture.S4.models.S4DetailReportComplexity_Download;
import com.accenture.S4.models.S4DetailReportRemediation;
import com.accenture.S4.models.S4DetailReportRemediation_Download;
import com.accenture.S4.models.S4Enhancement_Download;
import com.accenture.S4.models.S4Estimations;
import com.accenture.S4.models.S4HanaProfiler;
import com.accenture.S4.models.S4ImpactedIDOC;
import com.accenture.S4.models.S4ImpactedIDOC_Download;
import com.accenture.S4.models.S4ImpactedObjectList;
import com.accenture.S4.models.S4ImpactedSearchHelp;
import com.accenture.S4.models.S4ImpactedSearchHelp_Download;
import com.accenture.S4.models.S4ImpactedTables;
import com.accenture.S4.models.S4ImpactedTables_Download;
import com.accenture.S4.models.S4ImpactedTransaction;
import com.accenture.S4.models.S4ImpactedTransaction_Download;
import com.accenture.S4.models.S4InventoryList;
import com.accenture.S4.models.S4OutputMgmt;
import com.accenture.S4.models.S4OutputMgmt_Download;
import com.accenture.UI5.models.UI5FinalOutput;
import com.accenture.UI5.models.UI5HighLevelReport;
import com.accenture.impactedBackgroundJob.ImpactedBackgroundJob_Download;
import com.accenture.master.ProcessedRequestDetail;
import com.accenture.smodilog.model.SmodilogFunction_Download;
import com.accenture.testingscope.model.ExtractedDatapojo;
import com.google.common.collect.Multimap;

/**
 * @author monika.mishra
 *
 */
public interface DisplayGraphS4DAO {
	
	public List<S4ImpactedSearchHelp_Download> getImpactedSearch(final long requestId);
	public List<S4AppendStructureAnalysis_Download> getAppendStrctr(final long requestId);
	public List<S4CloneProg_Download> getCloneProg(final long requestID);
	public List<S4Enhancement_Download> getEnhancement(final long requestID);
	public List<InventoryList_Download> getInventory(final long requestID);
	List<S4ImpactedObjectList> getImpactedObjList(final long requestID);
	Map<String, Integer> getCountObjType(Long requestId);
	Map<String, Integer> getCountComplexity(Long requestId);
	//
	Map<String, Integer> getCountOutputManagement(Long requestId);
	Map<String, Integer> getCountCustomFields(Long requestId);

	Map<String, Integer> getCountInventoryType(Long requestId);
	Map<String, Integer> getCountDetailType(Long requestId);
	Map<String, Integer> getCountDetailTypeUsed(Long requestId);
	Map<String, Integer> getCountInventoryTypeUsed(Long requestId);
	Map<String, Integer> getCountDetailItemArea(Long requestId);
	Map<String, Integer> getCountInventoryTypeENH(Long requestId);
	Map<String, Integer> getCountInventoryTypeENHUsed(Long requestId);
	Map<String, Integer> getCountDetailTypeENH(Long requestId);
	Map<String, Integer> getCountItemArea(Long requestId);
	Map<String, Integer> getCountImpactObjType(Long requestId);
	Map<String, Integer> getDetail3CountRemediCategry(Long requestId);
	Map<String, Integer> getCountRemediCategry(Long requestId);
	Map<String, Map<String, Integer>> getDetail3RemediComplexCount(Long requestID);
	Map<String, Map<String, Integer>> getRemediComplexCount(Long requestID);

	Map<String, Map<String, Integer>> getDetail3RemediIssueCategoryCount(Long requestID);
	Map<String, Map<String, Integer>> getRemediIssueCategoryCount(Long requestID);
	Map<String, Map<String, Integer>> getDetail3RemedicomplexUsedCount(Long requestID);
	List<S4DetailReportComplexity_Download> getDetailReport2List(long requestID);
	List<S4DetailReportRemediation_Download> getDetailReport3List(long requestID);
	Map<String, Integer> getCountDetailTypeENHUsed(Long requestId);
	List<S4Estimations> getEstimations(long requestId);
	List<S4ImpactedTables_Download> getS4ImpactedTables(long requestID);
	List<S4ImpactedIDOC_Download> getS4ImpactedIDOC(long requestID);
	List<S4ImpactedTransaction_Download> getS4ImpactedTransaction(long requestID);
	// CR- 50,51,52
	Map<String, Integer> getCountErrCategry(Long requestId);
	Map<String, Integer> getCountFinalUsed(Long requestId);
	Map<String, Integer> getCountFinalComplexity(Long requestId);
	List getCountFinal(Long requestId);
	Map<String, Map<String, Integer>> getObjectTypeUsedCount(Long requestID);
	List<S4OutputMgmt_Download> getS4OutputMgmt(long requestID);
	List<S4AffectCustomField_Download> getS4AffectCustom(long requestID);
	
	//CR-61
	Multimap<String, String> getEstimateCount(final Long requestId,String remediationCategory);
	Multimap<String,String> getUsedEstimateCount(final Long requestId,String remediationCategory);
	List<OperationDataS4> getS4Simplification();
	
	//CR-68
	Map<String, Integer> getCustObjectCount(Long requestId);
	Map<String, Integer> getDefectObjectCount(Long requestId);
	Map<String, Integer> getComplexCount(Long requestId);
	Map<String, Integer> getUsedUnsedCount(Long requestId);
	Map<String, Integer> getUsedUnsedDefCount(Long requestId);
	
	
	void updateRequestMasterS4(long requestId,ProcessedRequestDetail requestMasterCommon);
	
	//CR-74
	Map<String, Integer> getCountApplicationComponent(Long requestId);
	Map<String, Integer> getMaxApplicationComponent(Long requestId);
	Map<String, Integer> getCountSAPNote(Long requestId, String applicationComponent);
	Map<String, Integer> getGraphCountRemediCategry(Long requestId);
	Map<String, Integer> getGraphCountErrCategry(Long requestId);
	Map<String, Integer> getGraphCountFinalUsed(Long requestId);
	Map<String, Integer> getGraphCountFinalComplexity(Long requestId);
	Map<String, Map<String, Integer>> getRemediUsedUnsedDDR2Count(Long requestId);
	Map<String, Map<String, Integer>> getRemediUsedUnsedDDR1Count(Long requestId);
	
	
	List<UI5FinalOutput> getUI5FinalOutputList(long requestID);
	List<UI5HighLevelReport> getUI5HighLevelReportList(long requestID); 
	
	List<ImpactedBackgroundJob_Download> getImpactedBackgroundJob(long requestID);

	List<SmodilogFunction_Download> getSmodilogData(long requestID);
	List<ACNIPZVERComp> getACNIPZVERComp(long requestID);
	List<ABAPQueryInventoryDownload> getInventoryABAP(long requestID);
	
}
