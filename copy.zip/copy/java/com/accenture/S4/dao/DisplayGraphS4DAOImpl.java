/*CR-No.    Desc     Date    Modified By
 * 
 * CR-61: New Estimation sheet added with a separate template addition for Admin-16/3/2018-rohan.a.mehra
 * 
 * */
package com.accenture.S4.dao;

import java.math.BigInteger;
import java.sql.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.Aadt.models.ACNIPZVERComp;
import com.accenture.S4.models.ABAPQueryInventoryDownload;
import com.accenture.S4.models.InventoryList_Download;
import com.accenture.S4.models.OperationDataS4;
import com.accenture.S4.models.S4AffectCustomField;
import com.accenture.S4.models.S4AffectCustomField_Download;
import com.accenture.S4.models.S4AppendStructureAnalysis;
import com.accenture.S4.models.S4AppendStructureAnalysis_Download;
import com.accenture.S4.models.S4CloneProg;
import com.accenture.S4.models.S4CloneProg_Download;
import com.accenture.S4.models.S4DetailReportComplexity;
import com.accenture.S4.models.S4DetailReportComplexity_Download;
import com.accenture.S4.models.S4DetailReportRemediation;
import com.accenture.S4.models.S4DetailReportRemediation_Download;
import com.accenture.S4.models.S4Enhancement_Download;
import com.accenture.S4.models.S4Estimations;
import com.accenture.S4.models.S4HanaProfiler;
import com.accenture.S4.models.S4ImpactedIDOC;
import com.accenture.S4.models.S4ImpactedIDOC_Download;
import com.accenture.S4.models.S4ImpactedObjectList;
import com.accenture.S4.models.S4ImpactedSearchHelp;
import com.accenture.S4.models.S4ImpactedSearchHelp_Download;
import com.accenture.S4.models.S4ImpactedTables;
import com.accenture.S4.models.S4ImpactedTables_Download;
import com.accenture.S4.models.S4ImpactedTransaction;
import com.accenture.S4.models.S4ImpactedTransaction_Download;
import com.accenture.S4.models.S4InventoryList;
import com.accenture.S4.models.S4OutputMgmt;
import com.accenture.S4.models.S4OutputMgmt_Download;
import com.accenture.client.model.RequestForm;
import com.accenture.client.model.RequestInventory;
import com.accenture.constant.Hana_Profiler_Constant;
import com.accenture.displaygrid.model.HanaProfile;
import com.accenture.exceptions.HibernateException;
import com.accenture.master.ProcessedRequestDetail;
import com.accenture.smodilog.model.SmodilogFunction_Download;
import com.accenture.testingscope.model.ExtractedDatapojo;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;

import com.accenture.impactedBackgroundJob.ImpactedBackgroundJob_Download;

import com.accenture.UI5.models.UI5FinalOutput;
import com.accenture.UI5.models.UI5HighLevelReport;
import com.accenture.admin.dao.AdminRequestMappingDAOImpl;


/**
 * @author monika.mishra
 *
 */
public class DisplayGraphS4DAOImpl implements DisplayGraphS4DAO {

	final public Logger logger = LoggerFactory.getLogger(DisplayGraphS4DAOImpl.class);
	
	public DisplayGraphS4DAOImpl(){

	}

	private SessionFactory sessionFactory;
	private Session session;
	private  String hql;

	public void setSessionFactory(SessionFactory sessionFactory){
		this.sessionFactory=sessionFactory;
	}

	public List<S4ImpactedSearchHelp_Download> getImpactedSearch(final long requestId){
		session=sessionFactory.openSession();
		try{
			final Criteria criteria=session.createCriteria(S4ImpactedSearchHelp_Download.class);
			criteria.add(Restrictions.eq("requestID", requestId));
			return criteria.list();
		}catch(Exception e){
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		finally{
			if(null != session){
				session.close();
			}
		}
	}

	public List<S4AppendStructureAnalysis_Download> getAppendStrctr(final long requestId){
		session=sessionFactory.openSession();

		try{
			final Criteria criteria=session.createCriteria(S4AppendStructureAnalysis_Download.class);
			criteria.add(Restrictions.eq("requestID", requestId));
			return criteria.list();
		}catch(Exception e){
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}finally {
			if(null!=session)
				session.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<S4CloneProg_Download> getCloneProg(long requestID) {
		session=sessionFactory.openSession();

		try{
			final Criteria criteria=session.createCriteria(S4CloneProg_Download.class);
			criteria.add(Restrictions.eq("requestID", requestID));
			return criteria.list();
		}catch(Exception e){
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}finally{
			if(null != session)
				session.close();
		}

		
	}

	@Override
	public List<S4Enhancement_Download> getEnhancement(final long requestId){
		session=sessionFactory.openSession();

		try{
			final Criteria criteria=session.createCriteria(S4Enhancement_Download.class);
			criteria.add(Restrictions.eq("requestID", requestId));
			return criteria.list();
		}catch(Exception e){
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}finally {
			if(null!=session)
				session.close();
		}
	}

	@Override
	public List<InventoryList_Download> getInventory(long requestID) {
		session=sessionFactory.openSession();

		try{
			final Criteria criteria=session.createCriteria(InventoryList_Download.class);
			criteria.add(Restrictions.eq("requestID", requestID));
			return criteria.list();
		}catch(Exception e){
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}finally{
			if(null != session)
				session.close();
		}

	}

	@Override
	public List<ABAPQueryInventoryDownload> getInventoryABAP(long requestID) {
		session=sessionFactory.openSession();

		try{
			final Criteria criteria=session.createCriteria(ABAPQueryInventoryDownload.class);
			criteria.add(Restrictions.eq("requestID", requestID));
			return criteria.list();
		}catch(Exception e){
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}finally{
			if(null != session)
				session.close();
		}

	}
	
	@Override
	public List<ACNIPZVERComp> getACNIPZVERComp(long requestID) {
		session=sessionFactory.openSession();

		try{
			final Criteria criteria=session.createCriteria(ACNIPZVERComp.class);
			criteria.add(Restrictions.eq("requestID", requestID));
			return criteria.list();
		}catch(Exception e){
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}finally{
			if(null != session)
				session.close();
		}

	}


	@SuppressWarnings("unchecked")
	@Override
	public List<S4ImpactedObjectList> getImpactedObjList(long requestID) {
		session=sessionFactory.openSession();
		try{
						
			Criteria criteria=session.createCriteria(S4ImpactedObjectList.class);
			ProjectionList projectionList=Projections.projectionList();
			projectionList.add(Projections.property("objType"),"objType");
			
			projectionList.add(Projections.property("objName"),"objName");
			projectionList.add(Projections.property("used"),"used");
			projectionList.add(Projections.property("requestID"),"requestID");
			criteria.add(Restrictions.eq("requestID", requestID));
			criteria.setProjection(Projections.distinct(projectionList));
			criteria.setResultTransformer(Transformers.aliasToBean(S4ImpactedObjectList.class));
			List<S4ImpactedObjectList> s4ImpactObjList= criteria.list();
			return s4ImpactObjList;
			
			
		}catch(Exception e){
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}finally{
			if(null != session)
				session.close();
		}

	}

	@Override
	public List<S4DetailReportComplexity_Download> getDetailReport2List(long requestID) {
		session=sessionFactory.openSession();

		try{
			final Criteria criteria=session.createCriteria(S4DetailReportComplexity_Download.class);
			criteria.add(Restrictions.eq("requestID", requestID));
			return criteria.list();
		}catch(Exception e){
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}finally{
			if(null != session){
				session.close();
			}
		}
	}

	@Override
	public List<S4DetailReportRemediation_Download> getDetailReport3List(long requestID) {
		session=sessionFactory.openSession();

		try{
			final Criteria criteria=session.createCriteria(S4DetailReportRemediation_Download.class);
			criteria.add(Restrictions.eq("requestID", requestID));
			return criteria.list();
		}catch(Exception e){
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}finally{
			if(null != session){
				session.close();
			}
		}
	}

	@Override
	public Map<String,Integer> getCountImpactObjType(final Long requestId)
	{
		final Map<String,Integer> resultMap = new HashMap<String,Integer>();
		session = sessionFactory.openSession();

		hql = "select type,count(*) from S4DetailReportComplexity where requestID=:requestID  GROUP BY type";
		Query query = session.createQuery(hql);
		query.setParameter("requestID", requestId);
		List<Object[]> resultList = query.list();
		if(CollectionUtils.isNotEmpty(resultList))
		{
			for(Object[] object : resultList)
			{
				resultMap.put((String) object[0], ((Long)object[1]).intValue());
			}
		}
		session.close();
		return resultMap;
	}


	@Override
	public Map<String,Integer> getCountObjType(final Long requestId)
	{
		final Map<String,Integer> resultMap = new HashMap<String,Integer>();
		session = sessionFactory.openSession();

		hql = "select type,count(*) from S4HanaProfiler where requestID=:requestID  GROUP BY type";
		Query query = session.createQuery(hql);
		query.setParameter("requestID", requestId);
		List<Object[]> resultList = query.list();
		if(CollectionUtils.isNotEmpty(resultList))
		{
			for(Object[] object : resultList)
			{
				resultMap.put((String) object[0], ((Long)object[1]).intValue());
			}
		}
		session.close();
		return resultMap;
	}



	@Override
	public Map<String,Integer> getCountComplexity(final Long requestId)
	{
		final Map<String,Integer> resultMap = new HashMap<String,Integer>();
		session = sessionFactory.openSession();

		hql = "select complexity,count(*) from S4DetailReportComplexity where requestID=:requestID  GROUP BY complexity";
		Query query = session.createQuery(hql);
		query.setParameter("requestID", requestId);
		List<Object[]> resultList = query.list();
		if(CollectionUtils.isNotEmpty(resultList))
		{
			for(Object[] object : resultList)
			{
				resultMap.put((String) object[0], ((Long)object[1]).intValue());
			}
		}
		session.close();
		return resultMap;
	}
	
	//Output Management Counts
	@Override
	public Map<String,Integer> getCountOutputManagement(final Long requestId)
	{
		final Map<String,Integer> resultMap = new HashMap<String,Integer>();
		session = sessionFactory.openSession();

		hql = "select type,count(*) from S4OutputMgmt where REQUEST_ID=:requestID  GROUP BY type";
		Query query = session.createQuery(hql);
		query.setParameter("requestID", requestId);
		List<Object[]> resultList = query.list();
		if(CollectionUtils.isNotEmpty(resultList)) {
			for(Object[] object : resultList) {
				resultMap.put(((String) object[0]).trim(), ((Long)object[1]).intValue());
			}
		}
		session.close();
		return resultMap;
	}

	//Custom Fields Counts
	@Override
	public Map<String,Integer> getCountCustomFields(final Long requestId)
	{
		final Map<String,Integer> resultMap = new HashMap<String,Integer>();
		session = sessionFactory.openSession();

		hql = "select type,count(*) from S4AffectCustomField where requestID=:requestID  GROUP BY type";
		Query query = session.createQuery(hql);
		query.setParameter("requestID", requestId);
		List<Object[]> resultList = query.list();
		if(CollectionUtils.isNotEmpty(resultList)) {
			for(Object[] object : resultList) {
				resultMap.put(((String) object[0]).trim(), ((Long)object[1]).intValue());
			}
		}
		session.close();
		return resultMap;
	}



	@Override
	public Map<String,Integer> getCountInventoryType(final Long requestId)
	{
		final Map<String,Integer> resultMap = new HashMap<String,Integer>();
		session = sessionFactory.openSession();

		hql = "select objType,count(*) from S4InventoryList where requestID=:requestID  GROUP BY objType";
		Query query = session.createQuery(hql);
		query.setParameter("requestID", requestId);
		List<Object[]> resultList = query.list();
		if(CollectionUtils.isNotEmpty(resultList))
		{
			for(Object[] object : resultList)
			{
				resultMap.put((String) object[0], ((Long)object[1]).intValue());
			}
		}
		session.close();
		return resultMap;
	}

	@Override
	public Map<String,Integer> getCountInventoryTypeUsed(final Long requestId)
	{
		final Map<String,Integer> resultMap = new HashMap<String,Integer>();
		session = sessionFactory.openSession();

		hql = "select objType,count(*) from S4InventoryList where requestID=:requestID and used='Y' GROUP BY objType,used";
		Query query = session.createQuery(hql);
		query.setParameter("requestID", requestId);
		//query.setParameter("used", 'Y');
		List<Object[]> resultList = query.list();
		if(CollectionUtils.isNotEmpty(resultList))
		{
			for(Object[] object : resultList)
			{
				resultMap.put((String) object[0], ((Long)object[1]).intValue());
			}
		}
		session.close();
		return resultMap;
	}


	@Override
	public Map<String,Integer> getCountDetailType(final Long requestId)
	{
		final Map<String,Integer> resultMap = new HashMap<String,Integer>();
		session = sessionFactory.openSession();

		hql = "select type,count(*) from S4DetailReportComplexity where requestID=:requestID  GROUP BY type";
		Query query = session.createQuery(hql);
		query.setParameter("requestID", requestId);
		List<Object[]> resultList = query.list();
		if(CollectionUtils.isNotEmpty(resultList))
		{
			for(Object[] object : resultList)
			{
				resultMap.put((String) object[0], ((Long)object[1]).intValue());
			}
		}
		session.close();
		return resultMap;
	}

	@Override
	public Map<String,Integer> getCountDetailTypeUsed(final Long requestId)
	{
		final Map<String,Integer> resultMap = new HashMap<String,Integer>();

		session = sessionFactory.openSession();

		hql = "select type,count(*) from S4DetailReportComplexity where requestID=:requestID and used='Y' GROUP BY type,used";
		Query query = session.createQuery(hql);
		query.setParameter("requestID", requestId);
		//query.setParameter("used", 'Y');
		List<Object[]> resultList = query.list();
		if(CollectionUtils.isNotEmpty(resultList))
		{
			for(Object[] object : resultList)
			{
				resultMap.put((String) object[0], ((Long)object[1]).intValue());
			}
		}


		return resultMap;
	}


	@Override
	public Map<String,Integer> getCountDetailItemArea(final Long requestId)
	{
		final Map<String,Integer> resultMap = new HashMap<String,Integer>();
		session = sessionFactory.openSession();

		hql = "select itemArea,count(*) from S4DetailReportComplexity where requestID=:requestID GROUP BY itemArea";
		Query query = session.createQuery(hql);
		query.setParameter("requestID", requestId);
		List<Object[]> resultList = query.list();
		if(CollectionUtils.isNotEmpty(resultList))
		{
			for(Object[] object : resultList)
			{
				resultMap.put((String) object[0], ((Long)object[1]).intValue());
			}
		}
		session.close();
		return resultMap;
	}

	@Override
	public Map<String,Integer> getCountItemArea(final Long requestId)
	{
		final Map<String,Integer> resultMap = new HashMap<String,Integer>();
		session = sessionFactory.openSession();

		hql = "select itemArea,count(*) from S4HanaProfiler where requestID=:requestID GROUP BY itemArea";
		Query query = session.createQuery(hql);
		query.setParameter("requestID", requestId);
		List<Object[]> resultList = query.list();
		if(CollectionUtils.isNotEmpty(resultList))
		{
			for(Object[] object : resultList)
			{
				resultMap.put((String) object[0], ((Long)object[1]).intValue());
			}
		}
		session.close();
		return resultMap;
	}

	@Override
	public Map<String,Integer> getCountInventoryTypeENH(final Long requestId)
	{
		final Map<String,Integer> resultMap = new HashMap<String,Integer>();
		session = sessionFactory.openSession();

		hql = "select count(*) from S4_Inventory_List where request_ID=:requestID and obj_Type like concat('EN','%') ";
		Query query = session.createSQLQuery(hql);
		query.setParameter("requestID", requestId);
		/*List<Object[]> resultList = query.list();
		if(CollectionUtils.isNotEmpty(resultList))
		{
			for(Object[] object : resultList)
			{
				resultMap.put("ENH", ((Long)object[1]).intValue());
			}
		}*/

		int count = ((BigInteger)query.uniqueResult()).intValue();

		resultMap.put("ENH", count);

		session.close();
		return resultMap;
	}

	@Override
	public Map<String,Integer> getCountInventoryTypeENHUsed(final Long requestId)
	{
		final Map<String,Integer> resultMap = new HashMap<String,Integer>();
		session = sessionFactory.openSession();

		hql = "select obj_Type,count(*) from S4_Inventory_List where request_ID=:requestID and used=:used and obj_Type like concat('EN','%')";
		Query query = session.createSQLQuery(hql);
		query.setParameter("requestID", requestId);
		query.setParameter("used", 'Y');
		List<Object[]> resultList = query.list();
		if(CollectionUtils.isNotEmpty(resultList))
		{
			for(Object[] object : resultList)
			{
				resultMap.put((String) object[0], ((BigInteger)object[1]).intValue());
			}
		}
		session.close();
		return resultMap;
	}

	@Override
	public Map<String,Integer> getCountDetailTypeENH(final Long requestId)
	{
		final Map<String,Integer> resultMap = new HashMap<String,Integer>();
		session = sessionFactory.openSession();

		hql = "select count(*) from S4_Detail_Report where request_ID=:requestID  and obj_Type like concat('EN','%')";
		Query query = session.createSQLQuery(hql);
		query.setParameter("requestID", requestId);
		//List<Object[]> resultList = query.list();
		int count = ((BigInteger)query.uniqueResult()).intValue();

		resultMap.put("ENH", count);

		session.close();
		return resultMap;
	}


	@Override
	public Map<String,Integer> getCountDetailTypeENHUsed(final Long requestId)
	{
		final Map<String,Integer> resultMap = new HashMap<String,Integer>();
		session = sessionFactory.openSession();

		hql = "select obj_Type,count(*) from S4_Detail_Report where request_ID=:requestID and used=:used  and obj_Type like concat('EN','%')" ;
		Query query = session.createSQLQuery(hql);
		query.setParameter("requestID", requestId);
		query.setParameter("used", 'Y');
		List<Object[]> resultList = query.list();
		if(CollectionUtils.isNotEmpty(resultList))
		{
			for(Object[] object : resultList)
			{
				resultMap.put((String) object[0], ((BigInteger)object[1]).intValue());
			}
		}
		session.close();
		return resultMap;
	}

	@Override
	public Map<String,Integer> getDetail3CountRemediCategry(final Long requestId)
	{
		final Map<String,Integer> resultMap = new HashMap<String,Integer>();
		session = sessionFactory.openSession();

		hql = "SELECT remediationCategory,count(*) FROM S4DetailReportRemediation where requestID=:requestID GROUP BY remediationCategory";
		Query query = session.createQuery(hql);
		query.setParameter("requestID", requestId);
		List<Object[]> resultList = query.list();
		if(CollectionUtils.isNotEmpty(resultList))
		{
			for(Object[] object : resultList)
			{
				resultMap.put((String) object[0], ((Long)object[1]).intValue());
			}
		}
		session.close();
		return resultMap;
	}


	@Override
	public Map<String,Integer> getCountRemediCategry(final Long requestId)
	{
		final Map<String,Integer> resultMap = new HashMap<String,Integer>();
		session = sessionFactory.openSession();

		hql = "SELECT remediationCategory,count(*) FROM S4HanaProfiler where requestID=:requestID and remediationCategory in ('Mandatory','Mandatory - CrossConf','Optional') GROUP BY remediationCategory";
		Query query = session.createQuery(hql);
		query.setParameter("requestID", requestId);
		List<Object[]> resultList = query.list();
		if(CollectionUtils.isNotEmpty(resultList))
		{
			for(Object[] object : resultList)
			{
				resultMap.put((String) object[0], ((Long)object[1]).intValue());
			}
		}
		session.close();
		return resultMap;
	}
	
	
	@Override
	public Map<String,Integer> getGraphCountRemediCategry(final Long requestId)
	{
		final Map<String,Integer> resultMap = new HashMap<String,Integer>();
		session = sessionFactory.openSession();

		hql = "select MandatoryCount,OptionalCount from Request_Master where Request_ID= :requestID";
		Query query = session.createSQLQuery(hql);
		query.setParameter("requestID", requestId);
		List<Object[]> resultList = query.list();
		
		if(CollectionUtils.isNotEmpty(resultList))
		{	
			for(Object[] object : resultList)
			{
						 resultMap.put("Mandatory", (Integer) (object[0]));
						 resultMap.put("Optional", (Integer) (object[1]));
			}
		}
		session.close();
		return resultMap;
	}
	
	//CR-74
	@Override
	public Map<String,Integer> getCountApplicationComponent(final Long requestId)
	{
		final Map<String,Integer> resultMap = new HashMap<String,Integer>();
		session = sessionFactory.openSession();
		hql = "SELECT applicationComponent,count(*) FROM S4DetailReportComplexity where requestID=:requestID GROUP BY applicationComponent";
		Query query = session.createQuery(hql);
		String misc="Other-Misc";
		query.setParameter("requestID", requestId);
		List<Object[]> resultList = query.list();
		if(CollectionUtils.isNotEmpty(resultList))
		{
			for(Object[] object : resultList)
			{
			    if(((String) object[0]).equalsIgnoreCase(""))
				{
			    	resultMap.put(misc, ((Long)object[1]).intValue());
				}
				else
				{
					resultMap.put(((String) object[0]).replace("\n"," "), ((Long)object[1]).intValue());	
				}
		}
		}
		session.close();
		return resultMap;
	}
	
	//CR-74
		@Override
		public Map<String,Integer> getMaxApplicationComponent(final Long requestId)
		{
			final Map<String,Integer> resultMap = new HashMap<String,Integer>();
			session = sessionFactory.openSession();
			hql = "SELECT applicationComponent,count(*) FROM S4DetailReportComplexity where requestID=:requestID GROUP BY applicationComponent";
			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);
			int max1 = 0,max2 = 0,max3 = 0,max4=0,totalcount=0,othersCount=0;
			
			String Smax1 = null,Smax2 = null,Smax3 = null,Smax4= null;
		
			List<Object[]> resultList = query.list();
			if(CollectionUtils.isNotEmpty(resultList))
			{
				for(Object[] object : resultList)
				{
					totalcount+=((Long)object[1]).intValue();
				    if(((String) object[0]).equalsIgnoreCase(""))
					{
				    	if(max1<((Long)object[1]).intValue())
				    	{
						max1=((Long)object[1]).intValue();	
				    	Smax1="";	
				    	}
						else if(max2<((Long)object[1]).intValue())
						{
						max2=((Long)object[1]).intValue();	
						Smax2="";	
						}
						else if(max3<((Long)object[1]).intValue())
						{
						max3=((Long)object[1]).intValue();		
						Smax3="";	
						}
						else if(max4<((Long)object[1]).intValue())
						{
						max4=((Long)object[1]).intValue();		
						Smax4="";	
						}
				    	
				}
					else
					{
						if(max1<((Long)object[1]).intValue())
				    	{
							if(max1>max2)
							{
								if(max2>max3)
								{
									if(max3>max4)
									{
										max4=max3;
										Smax4=Smax3;
									}
										max3=max2;
										Smax3=Smax2;
								}
								max2=max1;
								Smax2=Smax1;
							}
						max1=((Long)object[1]).intValue();	
				    	Smax1=(String)object[0];	
				    	}
						else if(max2<((Long)object[1]).intValue())
						{
							if(max2>max3)
							{
								if(max3>max4)
								{
									max4=max3;
									Smax4=Smax3;
								}
									max3=max2;
									Smax3=Smax2;	
							}
						max2=((Long)object[1]).intValue();	
						Smax2=(String)object[0];	
						}
						else if(max3<=((Long)object[1]).intValue())
						{
							if(max3>max4)
							{
								max4=max3;
								Smax4=Smax3;
							}
						max3=((Long)object[1]).intValue();		
						Smax3=(String)object[0];	
						}
						else if(max4<=((Long)object[1]).intValue())
						{	
						max4=((Long)object[1]).intValue();		
						Smax4=(String)object[0];	
						}
					  }
					}
				}
			
			if(CollectionUtils.isNotEmpty(resultList))
			{
				for(Object[] object : resultList)
				{
					if((object[0])==(Smax1))
					{
						resultMap.put(((String) object[0]).replace("\n"," "),((Long)object[1]).intValue());
						othersCount+=((Long)object[1]).intValue();
					}
					else if((object[0])==(Smax2))
					{
						resultMap.put(((String) object[0]).replace("\n"," "),((Long)object[1]).intValue());
						othersCount+=((Long)object[1]).intValue();
					}
					else if((object[0])==(Smax3))
					{
						resultMap.put(((String) object[0]).replace("\n"," "),((Long)object[1]).intValue());
						othersCount+=((Long)object[1]).intValue();
					}
					else if((object[0])==(Smax4))
					{
						resultMap.put(((String) object[0]).replace("\n"," "),((Long)object[1]).intValue());
						othersCount+=((Long)object[1]).intValue();
					}
				}
			}
			
			othersCount=totalcount-othersCount;
			resultMap.put("Others", othersCount);
			session.close();
			return resultMap;
		}
	
	
		//CR-74
		@Override
		public Map<String,Integer> getCountSAPNote(final Long requestId ,String applicationComponent)
		{
			final Map<String,Integer> resultMap = new HashMap<String,Integer>();
			session = sessionFactory.openSession();
			if(applicationComponent != null)
			{
				applicationComponent=applicationComponent.replace(" ","\n");
				hql = "SELECT sapNotes,count(*) FROM S4DetailReportComplexity where requestID=:requestID and applicationComponent in ('"+applicationComponent+"') GROUP BY sapNotes";
			}
			else
			{
				hql = "SELECT sapNotes,count(*) FROM S4DetailReportComplexity where requestID=:requestID GROUP BY sapNotes";
			}
			Query query = session.createQuery(hql);
			String Null="Other-Misc";
			query.setParameter("requestID", requestId);
			List<Object[]> resultList = query.list();
			if(CollectionUtils.isNotEmpty(resultList))
			{
				for(Object[] object : resultList)
				{
				    if(((String) object[0]).equalsIgnoreCase(""))
					{
				    	resultMap.put(Null, ((Long)object[1]).intValue());
					}
					else
					{
						resultMap.put((String) object[0], ((Long)object[1]).intValue());	
					}
			}
			}
			session.close();
			return resultMap;
		}


	@Override
	public Map<String, Map<String,Integer>> getDetail3RemediComplexCount(Long requestID) {

		final Map<String,Map<String,Integer>> resultMap = new HashMap<String,Map<String,Integer>>();
		Map<String,Integer> complexCountMap = null;
		session = sessionFactory.openSession();
		hql = "select remediationCategory,complexity,count(*) from S4DetailReportRemediation where requestID=:requestID GROUP BY complexity,remediationCategory";
		Query query = session.createQuery(hql);
		query.setParameter("requestID", requestID);
		List<Object[]> resultList = query.list();
		String remediationCategory;
		if(CollectionUtils.isNotEmpty(resultList))
		{
			for(Object[] object : resultList)
			{
				remediationCategory = (String) object[0];
				if(resultMap.get(remediationCategory)!=null)
				{
					complexCountMap = resultMap.get(remediationCategory);
					complexCountMap.put((String) object[1], ((Long)object[2]).intValue());
				}
				else
				{
					complexCountMap = new HashMap<String,Integer>();
					complexCountMap.put((String) object[1], ((Long)object[2]).intValue());
					resultMap.put(remediationCategory, complexCountMap);
				}

			}
		}
		session.close();
		return resultMap;

	}

	@Override
	public Map<String, Map<String,Integer>> getRemediComplexCount(Long requestID) {

		final Map<String,Map<String,Integer>> resultMap = new HashMap<String,Map<String,Integer>>();
		Map<String,Integer> complexCountMap = null;
		session = sessionFactory.openSession();
		hql = "select remediationCategory,complexity,count(*) from S4HanaProfiler where requestID=:requestID GROUP BY complexity,remediationCategory";
		Query query = session.createQuery(hql);
		query.setParameter("requestID", requestID);
		List<Object[]> resultList = query.list();
		String remediationCategory;
		if(CollectionUtils.isNotEmpty(resultList))
		{
			for(Object[] object : resultList)
			{
				remediationCategory = (String) object[0];
				if(resultMap.get(remediationCategory)!=null)
				{
					complexCountMap = resultMap.get(remediationCategory);
					complexCountMap.put((String) object[1], ((Long)object[2]).intValue());
				}
				else
				{
					complexCountMap = new HashMap<String,Integer>();
					complexCountMap.put((String) object[1], ((Long)object[2]).intValue());
					resultMap.put(remediationCategory, complexCountMap);
				}

			}
		}
		session.close();
		return resultMap;

	}


	@Override
	public Map<String, Map<String,Integer>> getDetail3RemediIssueCategoryCount(Long requestID) {

		final Map<String,Map<String,Integer>> resultMap = new HashMap<String,Map<String,Integer>>();
		Map<String,Integer> complexCountMap = null;
		session = sessionFactory.openSession();
		hql = "select remediationCategory,issueCategory,count(*) from S4DetailReportRemediation where requestID=:requestID GROUP BY issueCategory,remediationCategory";
		Query query = session.createQuery(hql);
		query.setParameter("requestID", requestID);
		List<Object[]> resultList = query.list();
		String remediationCategory;
		if(CollectionUtils.isNotEmpty(resultList))
		{
			for(Object[] object : resultList)
			{
				remediationCategory = (String) object[0];
				if(resultMap.get(remediationCategory)!=null)
				{
					complexCountMap = resultMap.get(remediationCategory);
					complexCountMap.put((String) object[1], ((Long)object[2]).intValue());
				}
				else
				{
					complexCountMap = new HashMap<String,Integer>();
					complexCountMap.put((String) object[1], ((Long)object[2]).intValue());
					resultMap.put(remediationCategory, complexCountMap);
				}

			}
		}
		session.close();
		return resultMap;

	}

	@Override
	public Map<String, Map<String,Integer>> getRemediIssueCategoryCount(Long requestID) {

		final Map<String,Map<String,Integer>> resultMap = new HashMap<String,Map<String,Integer>>();
		Map<String,Integer> complexCountMap = null;
		session = sessionFactory.openSession();
		hql = "select remediationCategory,issueCategory,count(*) from S4HanaProfiler where requestID=:requestID GROUP BY issueCategory,remediationCategory";
		Query query = session.createQuery(hql);
		query.setParameter("requestID", requestID);
		List<Object[]> resultList = query.list();
		String remediationCategory;
		if(CollectionUtils.isNotEmpty(resultList))
		{
			for(Object[] object : resultList)
			{
				remediationCategory = (String) object[0];
				if(resultMap.get(remediationCategory)!=null)
				{
					complexCountMap = resultMap.get(remediationCategory);
					complexCountMap.put((String) object[1], ((Long)object[2]).intValue());
				}
				else
				{
					complexCountMap = new HashMap<String,Integer>();
					complexCountMap.put((String) object[1], ((Long)object[2]).intValue());
					resultMap.put(remediationCategory, complexCountMap);
				}

			}
		}
		session.close();
		return resultMap;

	}

	@Override
	public Map<String, Map<String,Integer>> getDetail3RemedicomplexUsedCount(Long requestID) {

		final Map<String,Map<String,Integer>> resultMap = new HashMap<String,Map<String,Integer>>();
		Map<String,Integer> complexCountMap = null;
		session = sessionFactory.openSession();

		hql = "select remediationCategory,complexity,count(*) from S4DetailReportRemediation where request_ID=:requestID and used='Y' GROUP BY complexity,remediationCategory";
		Query query = session.createQuery(hql);
		query.setParameter("requestID", requestID);
		List<Object[]> resultList = query.list();
		String remediationCategory;
		if(CollectionUtils.isNotEmpty(resultList))
		{
			for(Object[] object : resultList)
			{
				remediationCategory = (String) object[0];
				if(resultMap.get(remediationCategory)!=null)
				{
					complexCountMap = resultMap.get(remediationCategory);
					complexCountMap.put((String) object[1], ((Long)object[2]).intValue());
				}
				else
				{
					complexCountMap = new HashMap<String,Integer>();
					complexCountMap.put((String) object[1], ((Long)object[2]).intValue());
					resultMap.put(remediationCategory, complexCountMap);
				}

			}
		}
		session.close();
		return resultMap;

	}

	@Override
	public List<S4Estimations> getEstimations(final long requestId){
		session=sessionFactory.openSession();
		try{
			Criteria criteria=session.createCriteria(S4Estimations.class);
			criteria.add(Restrictions.eq("requestID", requestId));
			return criteria.list();
		}catch(HibernateException e){
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}finally{
			if(null!=session){
				session.close();
			}
		}
	}
	//CR-32.0
	@Override
	public List<S4ImpactedTables_Download> getS4ImpactedTables(long requestID) {
		session=sessionFactory.openSession();

		try{
			Criteria criteria=session.createCriteria(S4ImpactedTables_Download.class);
			ProjectionList projectionList=Projections.projectionList();
			projectionList.add(Projections.property("object"),"object");
			projectionList.add(Projections.property("description"),"description");
			projectionList.add(Projections.property("solSteps"),"solSteps");
			projectionList.add(Projections.property("sapNotes"),"sapNotes");
			criteria.add(Restrictions.eq("requestID", requestID));
			criteria.setProjection(Projections.distinct(projectionList));
			criteria.setResultTransformer(Transformers.aliasToBean(S4ImpactedTables_Download.class));
			List<S4ImpactedTables_Download> S4ImpactedTables_Downloadlist = criteria.list();
			return S4ImpactedTables_Downloadlist;
		}catch(Exception e){
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}finally{
			if(null != session){
				session.close();
			}
		}
	}
	
	
	@Override
	public List<S4OutputMgmt_Download> getS4OutputMgmt(long requestID) {
		session=sessionFactory.openSession();

		try{
			final Criteria criteria=session.createCriteria(S4OutputMgmt_Download.class);
			ProjectionList projectionList=Projections.projectionList();
			projectionList.add(Projections.property("type"),"type");
			
			projectionList.add(Projections.property("ObjName"),"ObjName");
			projectionList.add(Projections.property("requestID"),"requestID");
			criteria.add(Restrictions.eq("requestID", requestID));
			criteria.setProjection(Projections.distinct(projectionList));
			criteria.setResultTransformer(Transformers.aliasToBean(S4OutputMgmt_Download.class));
			List<S4OutputMgmt_Download> s4OutputMgmtList= criteria.list();
			
			return s4OutputMgmtList;
		}catch(Exception e){
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}finally{
			if(null != session){
				session.close();
			}
		}
	}
	
	
	@Override
	public List<S4AffectCustomField_Download> getS4AffectCustom(long requestID) {
		session=sessionFactory.openSession();

		try{
			final Criteria criteria=session.createCriteria(S4AffectCustomField_Download.class);
		
			ProjectionList projectionList=Projections.projectionList();
			
			projectionList.add(Projections.property("type"), "type");
			projectionList.add(Projections.property("objName"), "objName");
			projectionList.add(Projections.property("triggerObj"), "triggerObj");
			projectionList.add(Projections.property("replacedByCDS"), "replacedByCDS");
			
			criteria.add(Restrictions.eq("requestID", requestID));
			criteria.setProjection(Projections.distinct(projectionList));
			criteria.setResultTransformer(Transformers.aliasToBean(S4AffectCustomField_Download.class));
			List<S4AffectCustomField_Download> s4AffectCustomList= criteria.list();
		
			return s4AffectCustomList;
		} catch(Exception e){
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally{
			if(null != session){
				session.close();
			}
		}
	}

	//CR-32.0
	@Override
	public List<S4ImpactedIDOC_Download> getS4ImpactedIDOC(long requestID) {
		session=sessionFactory.openSession();

		try{
			final Criteria criteria=session.createCriteria(S4ImpactedIDOC_Download.class);
			criteria.add(Restrictions.eq("requestID", requestID));
			return criteria.list();
		}catch(Exception e){
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}finally{
			if(null != session){
				session.close();
			}
		}
	}
	
	//CR-50.0
		@Override
		public List<S4ImpactedTransaction_Download> getS4ImpactedTransaction(long requestID) {
			session=sessionFactory.openSession();

			try{
				final Criteria criteria=session.createCriteria(S4ImpactedTransaction_Download.class);
				criteria.add(Restrictions.eq("requestID", requestID));
				return criteria.list();
			}catch(Exception e){
				logger.error("Error !!! " + e);
				throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
			}finally{
				if(null != session){
					session.close();
				}
			}
		}
		
		
		@Override
		public List<OperationDataS4> getS4Simplification() {
			session=sessionFactory.openSession();

			Criteria criteria = session.createCriteria(OperationDataS4.class);
			ProjectionList projection = Projections.projectionList();
			projection.add(Projections.property("s4_hana_changes"),"s4_hana_changes"); 
			projection.add(Projections.property("object"),"object"); 
			projection.add(Projections.property("objectType"),"objectType");  
			projection.add(Projections.property("description"),"description"); 
			projection.add(Projections.property("obsolete"),"obsolete");  
			projection.add(Projections.property("affectedArea"),"affectedArea"); 
			projection.add(Projections.property("relatedNotes"),"relatedNotes"); 
			projection.add(Projections.property("solutionSteps"),"solutionSteps");  
			projection.add(Projections.property("errCategoryNumeric"),"errCategoryNumeric"); 
			projection.add(Projections.property("version"),"version");  	
			projection.add(Projections.property("identifier"),"identifier");  
			projection.add(Projections.property("complexity"),"complexity");  
			projection.add(Projections.property("issueCatgry"),"issueCatgry");   
			projection.add(Projections.property("errorCatgry"),"errorCatgry");  
			projection.add(Projections.property("triggerObj"),"triggerObj"); 
			projection.add(Projections.property("remediationCatgry"),"remediationCatgry");  
			projection.add(Projections.property("sapSimplListChaptr"),"sapSimplListChaptr"); 
			projection.add(Projections.property("appComponent"),"appComponent");  
			projection.add(Projections.property("sapSimplCatry"),"sapSimplCatry");   
			projection.add(Projections.property("itm_Area"),"itm_Area"); 
			
			//criteria.add(Restrictions.isNotNull("version"));
			criteria.setProjection(projection);
			criteria.setResultTransformer(Transformers.aliasToBean(OperationDataS4.class));
			List<OperationDataS4> l = criteria.list();
			//logger.info("List Size " + l.size());
			session.close();
			return l;

		

			/*try{
				final Criteria criteria=session.createCriteria(OperationDataS4.class);
				return criteria.list();
			}catch(Exception e){
				logger.error("Error !!! " + e);
				throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
			}finally{
				if(null != session){
					session.close();
				}
			}*/
		}
		
		@Override
		public Map<String,Integer> getCountErrCategry(final Long requestId)
		{
			final Map<String,Integer> resultMap = new HashMap<String,Integer>();
			session = sessionFactory.openSession();

			hql = "SELECT errorCategory,count(*) FROM S4HanaProfiler where requestID=:requestID and errorCategory in ('Syntax','Semantic','Functional') GROUP BY errorCategory";
			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);
			List<Object[]> resultList = query.list();
			if(CollectionUtils.isNotEmpty(resultList))
			{
				for(Object[] object : resultList)
				{
					resultMap.put((String) object[0], ((Long)object[1]).intValue());
				}
			}
			session.close();
			return resultMap;
		}
		
		@Override
		public Map<String,Integer> getCountFinalUsed(final Long requestId)
		{
			List finalList=getCountFinal(requestId);
			final Map<String,Integer> resultMap = new HashMap<String,Integer>();
			session = sessionFactory.openSession();

			hql = "SELECT used,count(*) FROM S4HanaProfiler where requestID=:requestID and used ='Y' ";
			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);
			List<Object[]> resultList = query.list();
			if(CollectionUtils.isNotEmpty(resultList))
			{
				for(Object[] object : resultList)
				{
					int usedCount=((Long)object[1]).intValue();
					resultMap.put("Used", usedCount);
					int totalCount=((Long)finalList.get(0)).intValue();
					resultMap.put("Unused",(totalCount-usedCount));
				}
			}
			session.close();
			return resultMap;
		}
		
		@Override
		public Map<String,Integer> getCountFinalComplexity(final Long requestId)
		{
			final Map<String,Integer> resultMap = new HashMap<String,Integer>();
			session = sessionFactory.openSession();

			hql = "SELECT complexity,count(*) FROM S4HanaProfiler where requestID=:requestID and complexity in ('High','Medium','Low','Very Low','No Efforts') GROUP BY complexity";
			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);
			List<Object[]> resultList = query.list();
			if(CollectionUtils.isNotEmpty(resultList))
			{
				for(Object[] object : resultList)
				{
					resultMap.put((String) object[0], ((Long)object[1]).intValue());
				}
			}
			session.close();
			return resultMap;
		}
		
		
		
		//CR-50,51,52 :: Start
		@Override
		public Map<String,Integer> getGraphCountErrCategry(final Long requestId)
		{
			final Map<String,Integer> resultMap = new HashMap<String,Integer>();
			session = sessionFactory.openSession();

			hql = "select SyntaxErrorCount,SemanticErrorCount,FunctionalErrorCount from Request_Master where Request_ID= :requestID";
			Query query = session.createSQLQuery(hql);
			query.setParameter("requestID", requestId);
			List<Object[]> resultList = query.list();
			
			if(CollectionUtils.isNotEmpty(resultList))
			{	
				for(Object[] object : resultList)
				{
							 resultMap.put("Syntax", (Integer) (object[0]));
							 resultMap.put("Semantic", (Integer) (object[1]));
							 resultMap.put("Functional", (Integer) (object[2]));
				}
			}
			session.close();
			return resultMap;
		}
		
		@Override
		public List getCountFinal(final Long requestId)
		{
			
			session = sessionFactory.openSession();

			hql = "SELECT count(*) FROM S4HanaProfiler where requestID=:requestID ";
			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);
			List totalCount= query.list();
			
			session.close();
			return totalCount;
		}
		
		@Override
		public Map<String,Integer> getGraphCountFinalUsed(final Long requestId)
		{
			List finalList=getCountFinal(requestId);
			final Map<String,Integer> resultMap = new HashMap<String,Integer>();
			session = sessionFactory.openSession();

			hql = "select TotalUsedCount,TotalUnusedCount from Request_Master where Request_ID= :requestID";
			Query query = session.createSQLQuery(hql);
			query.setParameter("requestID", requestId);
			List<Object[]> resultList = query.list();
			
			if(CollectionUtils.isNotEmpty(resultList))
			{	
				for(Object[] object : resultList)
				{
							 resultMap.put("Used", (Integer) (object[0]));
							 resultMap.put("Unused", (Integer) (object[1]));
				}
			}
			session.close();
			return resultMap;
		}
		
		@Override
		public Map<String,Integer> getGraphCountFinalComplexity(final Long requestId)
		{
			final Map<String,Integer> resultMap = new HashMap<String,Integer>();
			session = sessionFactory.openSession();

			hql = "select HIGH_impact_count,medium_impact_count,low_impact_count,VeryLowImpactCount from Request_Master where Request_ID= :requestID";
			Query query = session.createSQLQuery(hql);
			query.setParameter("requestID", requestId);
			List<Object[]> resultList = query.list();
			
			if(CollectionUtils.isNotEmpty(resultList))
			{	
				for(Object[] object : resultList)
				{
							 resultMap.put("High", (Integer) (object[0]));
							 resultMap.put("Medium", (Integer) (object[1]));
							 resultMap.put("Low", (Integer) (object[2]));
							 resultMap.put("Very Low", (Integer) (object[3]));
				}
			}
			session.close();
			return resultMap;
		}
		
		@Override
		public Map<String, Map<String,Integer>> getObjectTypeUsedCount(Long requestID) {

			final Map<String,Map<String,Integer>> resultMap = new HashMap<String,Map<String,Integer>>();
			Map<String,Integer> usedUnusedMap = null;
			session = sessionFactory.openSession();
			hql = "select type,used,count(*) from S4HanaProfiler where requestID= :requestID and type in ('CLAS','PROG','ENHO','FUGR','ENHC','ENHS','INDE','VIEW','WDYN','SSFO') AND used ='Y' GROUP BY type,used";
			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestID);
			List<Object[]> resultList = query.list();
			String objectType;
			if(CollectionUtils.isNotEmpty(resultList))
			{
				for(Object[] object : resultList)
				{
					objectType = (String) object[0];
					if(resultMap.get(objectType)!=null)
					{
						usedUnusedMap = resultMap.get(objectType);
						usedUnusedMap.put((String) object[1], ((Long)object[2]).intValue());
					}
					else
					{
						usedUnusedMap = new HashMap<String,Integer>();
						usedUnusedMap.put((String) object[1], ((Long)object[2]).intValue());
						resultMap.put(objectType, usedUnusedMap);
					}

				}
			}
			session.close();
			return resultMap;

		}
		//CR-50,51,52 :: Ends
		
		//CR:61:Estimations Logic got changed S4
		@Override
		public Multimap<String,String> getEstimateCount(final Long requestId,String remediationCategory)
		{
			final Multimap<String,String> resultMap = ArrayListMultimap.create();
			session = sessionFactory.openSession();
			hql = "select type,complexity from S4DetailReportRemediation where requestID=:requestID and  Remediation_Category=:remediationCategory ";
			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);
			query.setParameter("remediationCategory", remediationCategory);
			List<Object[]> resultList = query.list();
			if(CollectionUtils.isNotEmpty(resultList))
			{
				for(Object[] object : resultList)
				{
					resultMap.put((String) object[0],(String) object[1]);
				}
			}
			session.close();
			return resultMap;
		}	
		
		//CR:61:Estimations Logic got changed S4
		@Override
		public Multimap<String,String> getUsedEstimateCount(final Long requestId,String remediationCategory)
		{
			final Multimap<String,String> resultMap = ArrayListMultimap.create();
			session = sessionFactory.openSession();
			hql = "select type,complexity from S4DetailReportRemediation where requestID=:requestID and  Remediation_Category=:remediationCategory and used In ('Y') ";
			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);
			query.setParameter("remediationCategory", remediationCategory);
			List<Object[]> resultList = query.list();
			if(CollectionUtils.isNotEmpty(resultList))
			{	
				for(Object[] object : resultList)
				{
					resultMap.put((String) object[0],(String) object[1]);
				}
			}
			session.close();
			return resultMap;
		}	
		
		//CR-68
		@Override
		public Map<String,Integer> getCustObjectCount(final Long requestId)
		{
			final Map<String, Integer> resultMap = new HashMap<String,Integer>();
			session = sessionFactory.openSession();
			try
			{
				hql = "select objType,count(*) from S4InventoryList where requestID=:requestID group by objType";
			
				Query query = session.createQuery(hql);
				query.setParameter("requestID", requestId);
				List<Object[]> resultList = query.list();
				if(CollectionUtils.isNotEmpty(resultList))
			if(CollectionUtils.isNotEmpty(resultList))
			{
				for(Object[] object : resultList)
				{
					resultMap.put((String) object[0],((Long) object[1]).intValue());
				}
			}
			session.close();}
			catch (Exception e) {
				logger.error("Error !!! " + e);
				}
			return resultMap;
		}	
		
		@Override
		public Map<String,Integer> getDefectObjectCount(final Long requestId)
		{
			final Map<String, Integer> resultMap = new HashMap<String,Integer>();
			session = sessionFactory.openSession();
			try
			{
			hql = "select objType,count(*) from S4ImpactedObjectList where requestID=:requestID group by objType";
			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);
			List<Object[]> resultList = query.list();
			if(CollectionUtils.isNotEmpty(resultList))
			{
				for(Object[] object : resultList)
				{
					resultMap.put((String) object[0],((Long) object[1]).intValue());
				}
			}
			session.close();}
			catch (Exception e) {
				logger.error("Error !!! " + e);
				}
			return resultMap;
		}	
		
		@Override
		public Map<String,Integer> getComplexCount(final Long requestId)
		{
			final Map<String, Integer> resultMap = new HashMap<String,Integer>();
			session = sessionFactory.openSession();
			try 
			{
			hql = "select complexity,count(*) from S4DetailReportComplexity where requestID=:requestID group by complexity";
			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);
			List<Object[]> resultList = query.list();
			if(CollectionUtils.isNotEmpty(resultList))
			{
				for(Object[] object : resultList)
				{
					resultMap.put((String) object[0],((Long) object[1]).intValue());
				}
			}
			session.close();}
			catch (Exception e) {
				logger.error("Error !!! " + e);
				}
			return resultMap;
		}	
		
		@Override
		public Map<String,Integer> getUsedUnsedCount(final Long requestId)
		{
			final Map<String, Integer> resultMap = new HashMap<String,Integer>();
			session = sessionFactory.openSession();
			try
			{
			hql = "select used,count(*) from S4InventoryList where requestID=:requestID group by used";
			Query query = session.createQuery(hql);
			String N="N";
			query.setParameter("requestID", requestId);
			List<Object[]> resultList = query.list();
			if(CollectionUtils.isNotEmpty(resultList))
			{
				for(Object[] object : resultList)
				{
					if(object[0] == null)
					{
						resultMap.put(N,((Long) object[1]).intValue());
					}
					else if(((String) object[0]).equalsIgnoreCase(""))
					{
						resultMap.put(N,((Long) object[1]).intValue());
					}
					else
					{
					resultMap.put((String) object[0],((Long) object[1]).intValue());
					}
				}
			}
			session.close();}
			catch (Exception e) {
				logger.error("Error !!! " + e);
				}
			return resultMap;
		}	
		
		@Override
		public Map<String,Integer> getUsedUnsedDefCount(final Long requestId)
		{
			final Map<String, Integer> resultMap = new HashMap<String,Integer>();
			session = sessionFactory.openSession();
			try {
			hql = "select used,count(*) from S4ImpactedObjectList where requestID=:requestID group by used";
			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);
			String N="N";
			List<Object[]> resultList = query.list();
			if(CollectionUtils.isNotEmpty(resultList))
			{
				for(Object[] object : resultList)
				{
					
					if( object[0] == null)
					{
						resultMap.put(N,((Long) object[1]).intValue());
					}
					else if(((String) object[0]).equalsIgnoreCase(""))
					{
						resultMap.put(N,((Long) object[1]).intValue());
					}
					else
					{
					resultMap.put((String) object[0],((Long) object[1]).intValue());
					}
				}
			}
			session.close();}
			catch (Exception e) {
				logger.error("Error !!! " + e);
				}
			return resultMap;
		}	
		
		
		@Override
		public Map<String, Map<String,Integer>> getRemediUsedUnsedDDR2Count(final Long requestId)
		{
			final Map<String,Map<String,Integer>> resultMap = new HashMap<String,Map<String,Integer>>();
			Map<String,Integer> usedUnusedMap = null;
			session = sessionFactory.openSession();
			try
			{
			hql = "select remediationCategory,used,count(*) from S4DetailReportComplexity where requestID=:requestID group by remediationCategory,used";
			Query query = session.createQuery(hql);
			String N="N";
			query.setParameter("requestID", requestId);
			List<Object[]> resultList = query.list();
			String remediationCategory;
			if(CollectionUtils.isNotEmpty(resultList))
			{
				for(Object[] object : resultList)
				{
					remediationCategory = (String) object[0];
					if(resultMap.get(remediationCategory)!=null)
					{
						usedUnusedMap = resultMap.get(remediationCategory);
						if( object[1] == null)
						{
							usedUnusedMap.put(N,((Long) object[2]).intValue());
						}
						else if(((String) object[1]).equalsIgnoreCase(""))
						{
							usedUnusedMap.put(N,((Long) object[2]).intValue());
						}
						else
						{ 
							if((String) object[1]!=null)
							{
							usedUnusedMap.put(((String) object[1]).toUpperCase(),((Long) object[2]).intValue());
							}
							else {
								usedUnusedMap.put((String) object[1],((Long) object[2]).intValue());
							}
						}
					}
					else
					{
						usedUnusedMap = new HashMap<String,Integer>();
						if( object[1] == null)
						{
							usedUnusedMap.put(N,((Long) object[2]).intValue());
						}
						else if(((String) object[1]).equalsIgnoreCase(""))
						{
							usedUnusedMap.put(N,((Long) object[2]).intValue());
						}
						else
						{
							if((String) object[1]!=null)
							{
							usedUnusedMap.put(((String) object[1]).toUpperCase(),((Long) object[2]).intValue());
							}
							else {
								usedUnusedMap.put((String) object[1],((Long) object[2]).intValue());
							}
						}
						
						resultMap.put(remediationCategory, usedUnusedMap);
					}

				}
			}
			session.close();}
			catch (Exception e) {
				logger.error("Error !!! " + e);
				}
			return resultMap;
		}
		
		@Override
		public Map<String, Map<String,Integer>> getRemediUsedUnsedDDR1Count(final Long requestId)
		{
			final Map<String,Map<String,Integer>> resultMap = new HashMap<String,Map<String,Integer>>();
			Map<String,Integer> usedUnusedMap = null;
			session = sessionFactory.openSession();
			try
			{
			hql = "select remediationCategory,used,count(*) from S4HanaProfiler where requestID=:requestID group by remediationCategory,used";
			Query query = session.createQuery(hql);
			String unused="N";
			query.setParameter("requestID", requestId);
			List<Object[]> resultList = query.list();
			String remediationCategory;
			if(CollectionUtils.isNotEmpty(resultList))
			{
				for(Object[] object : resultList)
				{
					remediationCategory = ((String) object[0]).trim().toUpperCase();
					
					if(resultMap.containsKey(remediationCategory)) {
						usedUnusedMap = resultMap.get(remediationCategory);
						if (object[1] == null || ((String) object[1]).equalsIgnoreCase("")) {
							long count = usedUnusedMap.containsKey(unused) ? usedUnusedMap.get(unused) : 0L;
							count += ((Long) object[2]).intValue();
							usedUnusedMap.put(unused, (int) count);
							} else {
								usedUnusedMap.put(((String) object[1]).trim().toUpperCase(), ((Long) object[2]).intValue());

							}
						
					} else {
						usedUnusedMap = new HashMap<String,Integer>();
						if (object[1] == null || ((String) object[1]).equalsIgnoreCase("")) {
							usedUnusedMap.put(unused, (int) ((Long) object[2]).intValue());
							} else {
								usedUnusedMap.put(((String) object[1]).trim().toUpperCase(), ((Long) object[2]).intValue());

							}
					}
					
					resultMap.put(remediationCategory, usedUnusedMap);
					
					/*
					 * if(resultMap.get(remediationCategory)!=null) { usedUnusedMap =
					 * resultMap.get(remediationCategory); if( object[1] == null) {
					 * usedUnusedMap.put(N,((Long) object[2]).intValue()); } else if(((String)
					 * object[1]).equalsIgnoreCase("")) { usedUnusedMap.put(N,((Long)
					 * object[2]).intValue()); } else { usedUnusedMap.put((String) object[1],((Long)
					 * object[2]).intValue()); } } else { usedUnusedMap = new
					 * HashMap<String,Integer>(); if( object[1] == null) {
					 * usedUnusedMap.put(N,((Long) object[2]).intValue()); } else if(((String)
					 * object[1]).equalsIgnoreCase("")) { usedUnusedMap.put(N,((Long)
					 * object[2]).intValue()); } else { usedUnusedMap.put((String) object[1],((Long)
					 * object[2]).intValue()); }
					 * 
					 * resultMap.put(remediationCategory, usedUnusedMap); }
					 */

				}
				
			}
			session.close();}
			catch (Exception e) {
				logger.error("Error !!! " + e);
				}
			return resultMap;
		}
		
		private Integer geUsedUnsedColumnCount(String key, Map<String, Integer> usedUnsedMap) {
			Integer count = 0;
			if (usedUnsedMap != null && usedUnsedMap.containsKey(key)) {
				count = usedUnsedMap.get(key);
			}

			return count;
		}
		
		private Integer geComplexityColumnCount(String key, Map<String, Integer> complexityMap) {
			Integer count = 0;
			if (complexityMap != null && complexityMap.containsKey(key)) {
				count = complexityMap.get(key);
			}

			return count;
		}
		
		private Integer getIssueCatColumnCount(String key, Map<String, Integer> issueCategoryMap) {
			Integer count = 0;
			if (issueCategoryMap != null && issueCategoryMap.containsKey(key)) {
				count = issueCategoryMap.get(key);
			}

			return count;
		}

		
		
		public Map<String,Integer> getIssueCatCount(final Long requestId)
		{
			final Map<String, Integer> resultMap = new HashMap<String,Integer>();
			session = sessionFactory.openSession();
			try
			{
			hql = "select errorCategory,count(*) from S4DetailReportComplexity where requestID=:requestID group by errorCategory";
			Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);
			List<Object[]> resultList = query.list();
			if(CollectionUtils.isNotEmpty(resultList))
			{
				for(Object[] object : resultList)
				{
					resultMap.put((String) object[0],((Long) object[1]).intValue());
				}
			}
			session.close();}
			catch (Exception e) {
				logger.error("Error !!! " + e);
				}
			return resultMap;
		}	
		
		private List<RequestForm> getReqForm(long requestId){

			session = sessionFactory.openSession();
			
			try {
				final Criteria criteria = session.createCriteria(RequestForm.class);
				criteria.add(Restrictions.eq("requestID", requestId));
				return  criteria.list();
			} catch (Exception e) {
				logger.error("Error !!! " + e);
				throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);

			} finally {
				if (session != null) {
					session.close();
				}
			}
		}
		
		private List<RequestInventory> getReqInventory(long requestId){

			session = sessionFactory.openSession();
			
			try {
				final Criteria criteria = session.createCriteria(RequestInventory.class);
				criteria.add(Restrictions.eq("requestID", requestId));
				return  criteria.list();
			} catch (Exception e) {
				logger.error("Error !!! " + e);
				throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);

			} finally {
				if (session != null) {
					session.close();
				}
			}
	}
		
		private Integer getTotalCount( Map<String, Map<String, Integer>> resultMap) {
			Integer count = 0;
			if (resultMap != null && !resultMap.isEmpty()) {
				count = resultMap.values().stream()
						.flatMap(innerMap -> innerMap.entrySet().stream())
						.mapToInt(map -> map.getValue())
						.sum();
			}

			return count;
		}
		
		public Map<String,Map<String,Integer>> getUsedCountImpactObjList(final Long requestId)
		{
			final Map<String,Map<String,Integer>> resultMap = new HashMap<String,Map<String,Integer>>();
			Map<String,Integer> usedUnusedMap = null;
			session = sessionFactory.openSession();
			try
			{
				
				hql = "select OBJ_TYPE,Used,count(*) from ImpactedObjList where REQUEST_ID= :requestID and S4_Simplification= :S4_Simplification group by OBJ_TYPE,Used";
							
				Query query = session.createQuery(hql);
				query.setParameter("requestID", requestId);
				query.setParameter("S4_Simplification", "X");
				
				String unused="N";
				List<Object[]> resultList = query.list();
				String objectType;
				if(CollectionUtils.isNotEmpty(resultList))
				{
					for(Object[] object : resultList)
					{
						objectType = ((String) object[0]).trim();
						
						if(resultMap.containsKey(objectType)) {
							usedUnusedMap = resultMap.get(objectType);
							if (object[1] == null || ((String) object[1]).equalsIgnoreCase("")) {
								long count = usedUnusedMap.containsKey(unused) ? usedUnusedMap.get(unused) : 0L;
								count += ((Long) object[2]).intValue();
								usedUnusedMap.put(unused, (int) count);
								} else {
									usedUnusedMap.put(((String) object[1]).trim().toUpperCase(), ((Long) object[2]).intValue());

								}
							
						} else {
							usedUnusedMap = new HashMap<String,Integer>();
							if (object[1] == null || ((String) object[1]).equalsIgnoreCase("")) {
								usedUnusedMap.put(unused, (int) ((Long) object[2]).intValue());
								} else {
									usedUnusedMap.put(((String) object[1]).trim().toUpperCase(), ((Long) object[2]).intValue());
								}
						}
						
						resultMap.put(objectType, usedUnusedMap);
					}
				}
				
			session.close();}
			catch (Exception e) {
				logger.error("Error !!! " + e);
			}
			return resultMap;
		}
		
		private Integer getTotalUsedCount(String key,Map<String,Map<String,Integer>> resultMap) {
			Integer count = 0;
			String keyUpper=key.toUpperCase();
			if (resultMap != null &&  !resultMap.isEmpty()) {
				count=resultMap.values().stream()
				.flatMap(innerMap -> innerMap.entrySet().stream())
				.filter(filterMap -> keyUpper.equals(filterMap.getKey()))
				.mapToInt(filterMap -> filterMap.getValue())
				.sum();
			}

			return count;
		}
		
		public Map<String,Map<String,Integer>> getErrorObjectandUsedCount(final Long requestId)
		{
			final Map<String,Map<String,Integer>> resultMap = new HashMap<String,Map<String,Integer>>();
			Map<String,Integer> usedUnusedMap = null;
			session = sessionFactory.openSession();
			try
			{
				hql = "select type,used,count(*) from S4HanaProfiler where requestID=:requestID  group by type,used";

				
				Query query = session.createQuery(hql);
				query.setParameter("requestID", requestId);
				String N="N";
				List<Object[]> resultList = query.list();
				String objectType;
				if(CollectionUtils.isNotEmpty(resultList))
				{
					for(Object[] object : resultList)
					{
						objectType = ((String) object[0]).trim();
						if(resultMap.get(objectType)!=null)
						{
							usedUnusedMap = resultMap.get(objectType);
							if( object[1] == null)
							{
								usedUnusedMap.put(N,((Long) object[2]).intValue());
							}
							else if(((String) object[1]).equalsIgnoreCase(""))
							{
								usedUnusedMap.put(N,((Long) object[2]).intValue());
							}
							else
							{ 
								if((String) object[1]!=null)
								{
								usedUnusedMap.put(((String) object[1]).trim().toUpperCase(),((Long) object[2]).intValue());
								}
								else {
									usedUnusedMap.put(((String) object[1]).trim(),((Long) object[2]).intValue());
								}
							}
						}
						else
						{
							usedUnusedMap = new HashMap<String,Integer>();
							if( object[1] == null)
							{
								usedUnusedMap.put(N,((Long) object[2]).intValue());
							}
							else if(((String) object[1]).equalsIgnoreCase(""))
							{
								usedUnusedMap.put(N,((Long) object[2]).intValue());
							}
							else
							{
								if((String) object[1]!=null)
								{
								usedUnusedMap.put(((String) object[1]).trim().toUpperCase(),((Long) object[2]).intValue());
								}
								else {
									usedUnusedMap.put(((String) object[1]).trim(),((Long) object[2]).intValue());
								}
							}
							
							resultMap.put(objectType, usedUnusedMap);
						}

					}
				}
			
					
					
					
			session.close();}
			catch (Exception e) {
				logger.error("Error !!! " + e);
			}
			return resultMap;
		}
		
		public Map<String,Map<String,Integer>> getComplexityCount(final Long requestId)
		{
			final Map<String,Map<String,Integer>> resultMap = new HashMap<String,Map<String,Integer>>();
			Map<String,Integer> errorImpactMap =new HashMap<String,Integer>();
			
			session = sessionFactory.openSession();
			try
			{
				hql = "select complexity,count(*) from S4HanaProfiler where requestID=:requestID  group by complexity";
				
				Query query = session.createQuery(hql);
				query.setParameter("requestID", requestId);
				
				List<Object[]> resultList = query.list();
				
			if(CollectionUtils.isNotEmpty(resultList))
			{
				for(Object[] object : resultList)
				{
					if((String) object[0]!=null)
					{
					errorImpactMap.put(((String) object[0]).toUpperCase(),((Long) object[1]).intValue());
					}
					else
						errorImpactMap.put((String) object[0],((Long) object[1]).intValue());
				}
			}
			session.close();
			resultMap.put("errorCountMap", errorImpactMap);
			}
			catch (Exception e) {
				logger.error("Error !!! " + e);
			}
			return resultMap;
			
		}
		
		public Map<String,Map<String,Integer>> getCompDdr2Count(final Long requestId)
		{
			final Map<String,Map<String,Integer>> resultMap = new HashMap<String,Map<String,Integer>>();
			Map<String,Integer> errorImpactMap =new HashMap<String,Integer>();
			Map<String,Integer> objDistinctImpactMap =new HashMap<String,Integer>();
			
			session = sessionFactory.openSession();
			try
			{
				hql = "select complexity,count(*),count(distinct objNameType) from S4DetailReportComplexity where requestID=:requestID  group by complexity";
				
				Query query = session.createQuery(hql);
				query.setParameter("requestID", requestId);
				
				List<Object[]> resultList = query.list();
				if(CollectionUtils.isNotEmpty(resultList))
			if(CollectionUtils.isNotEmpty(resultList))
			{
				for(Object[] object : resultList)
				{
					if((String) object[0]!=null)
					{
					errorImpactMap.put(((String) object[0]).toUpperCase(),((Long) object[1]).intValue());
					objDistinctImpactMap.put(((String) object[0]).toUpperCase(),((Long) object[2]).intValue());
					}
					else
					{
						errorImpactMap.put((String) object[0],((Long) object[1]).intValue());
						objDistinctImpactMap.put((String) object[0],((Long) object[2]).intValue());
					}
				}
			}
			session.close();
			resultMap.put("errorCountMap", errorImpactMap);
			resultMap.put("distinctCountMap", objDistinctImpactMap);
			}
			catch (Exception e) {
				logger.error("Error !!! " + e);
			}
			return resultMap;
			
		}
		
		//Functional Area Count
		public Map<String, Integer> getFunctionalAreaDDR2Count(final Long requestId)
		{
			
				final Map<String, Integer> resultMap = new HashMap<String,Integer>();
				session = sessionFactory.openSession();
				try 
				{
				 hql = "select itemArea,count(*) from S4DetailReportComplexity where requestID=:requestID group by itemArea";
				 Query query = session.createQuery(hql);
				 query.setParameter("requestID", requestId);
				
				 @SuppressWarnings("unchecked")
				 List<Object[]> resultList = query.list();
				
			     if(CollectionUtils.isNotEmpty(resultList))
		         {
				  for(Object[] object : resultList)
				   {
					 if((String) object[0]!=null) 
						resultMap.put(((String) object[0]).trim().toUpperCase(),((Long) object[1]).intValue());
				   }
		 	     }
		     	  session.close();
		        } catch (Exception e) {
		        	logger.error("Error !!! " + e);
			    }
			return resultMap;	
		}
		
		public Map<String,Map<String,Integer>> getCompDdr1Count(final Long requestId)
		{
			final Map<String,Map<String,Integer>> resultMap = new HashMap<String,Map<String,Integer>>();
			Map<String,Integer> errorImpactMap =new HashMap<String,Integer>();
		
			
			session = sessionFactory.openSession();
			try
			{
				hql = "select complexity,count(*) from S4HanaProfiler where requestID=:requestID  group by complexity";
				
				Query query = session.createQuery(hql);
				query.setParameter("requestID", requestId);
				List<Object[]> resultList = query.list();
				if(CollectionUtils.isNotEmpty(resultList))
			if(CollectionUtils.isNotEmpty(resultList))
			{
				for(Object[] object : resultList)
				{
					if((String) object[0]!=null)
					{
					errorImpactMap.put(((String) object[0]).toUpperCase(),((Long) object[1]).intValue());	
					}
					else
					{
					errorImpactMap.put((String) object[0],((Long) object[1]).intValue());
					}
				}
			}
			session.close();
			resultMap.put("errorCountMap", errorImpactMap);
			}
			catch (Exception e) {
				logger.error("Error !!! " + e);
			}
			return resultMap;
			
		}
		
		
		public Map<String, Integer> getSimpliCategoryDDR3Count(final Long requestId)
		{
			
				final Map<String, Integer> resultMap = new HashMap<String,Integer>();
				session = sessionFactory.openSession();
				try 
					{
						hql = "select sapSimplCategry,count(*) from S4DetailReportRemediation where requestID=:requestID group by sapSimplCategry";
						Query query = session.createQuery(hql);
						query.setParameter("requestID", requestId);
						List<Object[]> resultList = query.list();
				
						if(CollectionUtils.isNotEmpty(resultList)) {
							for(Object[] object : resultList) {
								if((String) object[0]!=null) {
									resultMap.put(((String) object[0]).trim().toUpperCase().replace(" ( ", "("),((Long) object[1]).intValue());
								}
							}
						}
			   
						session.close();
		     	} catch (Exception e) {
		     		logger.error("Error !!! " + e);
				}
			return resultMap;
			
		}
		public Map<String, Integer> getSimpliCategoryDDR1Count(final Long requestId)
		{
			
				
				final Map<String, Integer> resultMap = new HashMap<String,Integer>();
				session = sessionFactory.openSession();
				try 
				{
				hql = "select sapSimplCategry,count(*) from S4HanaProfiler where requestID= :requestID group by sapSimplCategry";
				Query query = session.createQuery(hql);
				query.setParameter("requestID", requestId);
				List<Object[]> resultList = query.list();
				
			   if(CollectionUtils.isNotEmpty(resultList))
		       {
				for(Object[] object : resultList)
				{
					if((String) object[0]!=null)
					{
					resultMap.put(((String) object[0]).toUpperCase(),((Long) object[1]).intValue());
					}
					else
					{
					resultMap.put((String) object[0],((Long) object[1]).intValue());	
					}
				}
		 	    }
			session.close();
			}
			catch (Exception e) {
				logger.error("Error !!! " + e);
			}
			return resultMap;
			
		}
		
		
		
		public Map<String,Map<String,Integer>> getErrorRemDdr3Count(final Long requestId)
		{
			final Map<String,Map<String,Integer>> resultMap = new HashMap<String,Map<String,Integer>>();
			Map<String,Integer> usedUnusedMap = null;
			session = sessionFactory.openSession();
			try
			{
				hql = "select remediationCategory,used,count(*) from S4DetailReportRemediation where requestID=:requestID group by remediationCategory,used";
			
				Query query = session.createQuery(hql);
				query.setParameter("requestID", requestId);
				
				String unused="N";
				List<Object[]> resultList = query.list();
				String objectType;
				if(CollectionUtils.isNotEmpty(resultList))
				{
					for(Object[] object : resultList)
					{
						objectType = ((String) object[0]).trim();
						
						if(resultMap.containsKey(objectType)) {
							usedUnusedMap = resultMap.get(objectType);
							if (object[1] == null || ((String) object[1]).equalsIgnoreCase("")) {
								long count = usedUnusedMap.containsKey(unused) ? usedUnusedMap.get(unused) : 0L;
								count += ((Long) object[2]).intValue();
								usedUnusedMap.put(unused, (int) count);
								} else {
									usedUnusedMap.put(((String) object[1]).trim().toUpperCase(), ((Long) object[2]).intValue());

								}
							
						} else {
							usedUnusedMap = new HashMap<String,Integer>();
							if (object[1] == null || ((String) object[1]).equalsIgnoreCase("")) {
								usedUnusedMap.put(unused, (int) ((Long) object[2]).intValue());
								} else {
									usedUnusedMap.put(((String) object[1]).trim().toUpperCase(), ((Long) object[2]).intValue());

								}
						}
						
						resultMap.put(objectType, usedUnusedMap);
						
					/*
					 * if(resultMap.get(objectType)!=null) { usedUnusedMap =
					 * resultMap.get(objectType); if( object[1] == null) {
					 * usedUnusedMap.put(unused,((Long) object[2]).intValue()); } else if(((String)
					 * object[1]).equalsIgnoreCase("")) { usedUnusedMap.put(unused,((Long)
					 * object[2]).intValue()); } else { if((String) object[1]!=null) {
					 * usedUnusedMap.put(((String) object[1]).toUpperCase(),((Long)
					 * object[2]).intValue()); } else { usedUnusedMap.put((String) object[1],((Long)
					 * object[2]).intValue()); } } } else { usedUnusedMap = new
					 * HashMap<String,Integer>(); if( object[1] == null) {
					 * usedUnusedMap.put(unused,((Long) object[2]).intValue()); } else if(((String)
					 * object[1]).equalsIgnoreCase("")) { usedUnusedMap.put(unused,((Long)
					 * object[2]).intValue()); } else { if((String) object[1]!=null) {
					 * usedUnusedMap.put(((String) object[1]).toUpperCase(),((Long)
					 * object[2]).intValue()); } else { usedUnusedMap.put((String) object[1],((Long)
					 * object[2]).intValue()); } }
					 * 
					 * resultMap.put(objectType, usedUnusedMap); }
					 */

					}
				}
				
				session.close();
			} catch (Exception e) {
				logger.error("Error !!! " + e);
			}
			return resultMap;
		}
		
		public Map<String,Map<String,Integer>> getRemComplexityDdr3Count(final Long requestId)
		{
			final Map<String,Map<String,Integer>> resultMap = new HashMap<String,Map<String,Integer>>();
			Map<String,Integer> complexityMap = null;
			session = sessionFactory.openSession();
			try
			{
				hql = "select remediationCategory,complexity,count(*) from S4DetailReportRemediation where requestID=:requestID group by remediationCategory,complexity";
			
				Query query = session.createQuery(hql);
				query.setParameter("requestID", requestId);
				
				String complexity="";
				List<Object[]> resultList = query.list();
				String objectType;
				if(CollectionUtils.isNotEmpty(resultList))
				{
					for(Object[] object : resultList)
					{
						objectType = ((String) object[0]).trim();
						if(resultMap.get(objectType)!=null)
						{
							complexityMap = (resultMap.get(objectType));
							if( object[1] == null)
							{
								complexityMap.put(complexity,((Long) object[2]).intValue());
							}
							else if(((String) object[1]).equalsIgnoreCase(""))
							{
								complexityMap.put(complexity,((Long) object[2]).intValue());
							}
							else
							{ 
								if((String) object[1]!=null)
								{
									complexityMap.put(((String) object[1]).trim().toUpperCase(),((Long) object[2]).intValue());
								}
								else {
									complexityMap.put(((String) object[1]).trim(),((Long) object[2]).intValue());
								}
							}
						}
						else
						{
							complexityMap = new HashMap<String,Integer>();
							if( object[1] == null)
							{
								complexityMap.put(complexity,((Long) object[2]).intValue());
							}
							else if(((String) object[1]).equalsIgnoreCase(""))
							{
								complexityMap.put(complexity,((Long) object[2]).intValue());
							}
							else
							{
								if((String) object[1]!=null)
								{
									complexityMap.put(((String) object[1]).trim().toUpperCase(),((Long) object[2]).intValue());
								}
								else {
									complexityMap.put(((String) object[1]).trim(),((Long) object[2]).intValue());
								}
							}
							
							resultMap.put(objectType, complexityMap);
						}

					}
				}
				
			session.close();}
			catch (Exception e) {
				logger.error("Error !!! " + e);
			}
			return resultMap;
		}
		
		
		
		
		
		public Map<String,Map<String,Integer>> getObjectUsedIssueCat(final Long requestId)
		{
			final Map<String,Map<String,Integer>> resultMap = new HashMap<String,Map<String,Integer>>();
			Map<String,Integer> usedUnusedMap = null;
			session = sessionFactory.openSession();
			try
			{
				hql = "select issueCategory,used,count(*) from S4HanaProfiler where requestID=:requestID group by issueCategory,used";
			
				Query query = session.createQuery(hql);
				query.setParameter("requestID", requestId);
				
				String unused="N";
				List<Object[]> resultList = query.list();
				String issueCategory;
				if(CollectionUtils.isNotEmpty(resultList))
				{
					for(Object[] object : resultList)
					{
						if(object[0]!=null) {
							issueCategory= ((String) object[0]).trim().toUpperCase();
						
								if(resultMap.containsKey(issueCategory)) {
									usedUnusedMap = resultMap.get(issueCategory);
									if (object[1] == null || ((String) object[1]).equalsIgnoreCase("")) {
										long count = usedUnusedMap.containsKey(unused) ? usedUnusedMap.get(unused) : 0L;
										count += ((Long) object[2]).intValue();
										usedUnusedMap.put(unused, (int) count);
										} else {
											usedUnusedMap.put(((String) object[1]).trim().toUpperCase(), ((Long) object[2]).intValue());

										}
							     } else {
							    	 usedUnusedMap = new HashMap<String,Integer>();
							    	 	if (object[1] == null || ((String) object[1]).equalsIgnoreCase("")) {
							    	 	usedUnusedMap.put(unused, (int) ((Long) object[2]).intValue());
							    	 	} else {
							    	 		usedUnusedMap.put(((String) object[1]).trim().toUpperCase(), ((Long) object[2]).intValue());
							    	 	}
							     }
						
						    resultMap.put(issueCategory, usedUnusedMap);
					   }
						
						/*if(object[0]!=null) {
						issueCategory= ((String) object[0]).toUpperCase();
						if(resultMap.get(issueCategory)!=null)
						{
							usedUnusedMap = resultMap.get(issueCategory);
							if( object[1] == null)
							{
								usedUnusedMap.put(unused,((Long) object[2]).intValue());
							}
							else if(((String) object[1]).equalsIgnoreCase(""))
							{
								usedUnusedMap.put(unused,((Long) object[2]).intValue());
							}
							else
							{ 
								if((String) object[1]!=null)
								{
								usedUnusedMap.put(((String) object[1]).toUpperCase(),((Long) object[2]).intValue());
								}
								else {
									usedUnusedMap.put((String) object[1],((Long) object[2]).intValue());
								}
							}
						}
						else
						{
							usedUnusedMap = new HashMap<String,Integer>();
							if( object[1] == null)
							{
								usedUnusedMap.put(unused,((Long) object[2]).intValue());
							}
							else if(((String) object[1]).equalsIgnoreCase(""))
							{
								usedUnusedMap.put(unused,((Long) object[2]).intValue());
							}
							else
							{
								if((String) object[1]!=null)
								{
								usedUnusedMap.put(((String) object[1]).toUpperCase(),((Long) object[2]).intValue());
								}
								else {
									usedUnusedMap.put((String) object[1],((Long) object[2]).intValue());
								}
							}*/
						
					}
				}
				
			session.close();
			} catch (Exception e) {
				logger.error("Error !!! " + e);
			}
			return resultMap;
		}
			
		
		//From DDR3 counts
		public Map<String,Map<String,Integer>> getRemIssueCatDdr3Count(final Long requestId)
		{
			final Map<String,Map<String,Integer>> resultMap = new HashMap<String,Map<String,Integer>>();
			Map<String,Integer> issueCatMap = null;
			session = sessionFactory.openSession();
			try
			{
				hql= "select  issueCategory, remediationCategory, count(*) from S4DetailReportRemediation where requestID=:requestID group by issueCategory, remediationCategory";
				
				Query query = session.createQuery(hql);
				query.setParameter("requestID", requestId);
				
				String issueCategory;
				String remediationCategory="";
				List<Object[]> resultList = query.list();
				String objectType;
				if(CollectionUtils.isNotEmpty(resultList))
				{
					for(Object[] object : resultList)
					{
						if(object[0]!=null) {
						issueCategory= ((String) object[0]).trim().toUpperCase();
						if(resultMap.get(issueCategory)!=null)
						{
							issueCatMap = resultMap.get(issueCategory);
							if( object[1] == null)
							{
								issueCatMap.put(remediationCategory.trim().toUpperCase(),((Long) object[2]).intValue());
							}
							else if(((String) object[1]).equalsIgnoreCase(""))
							{
								issueCatMap.put(remediationCategory.trim().toUpperCase(),((Long) object[2]).intValue());
							}
							else
							{ 
								if((String) object[1]!=null)
								{
									issueCatMap.put(((String) object[1]).trim().toUpperCase(),((Long) object[2]).intValue());
								}
								else {
									issueCatMap.put(((String) object[1]).trim(),((Long) object[2]).intValue());
								}
							}
						}
						else
						{
							issueCatMap = new HashMap<String,Integer>();
							if( object[1] == null)
							{
								issueCatMap.put(remediationCategory.trim().toUpperCase(),((Long) object[2]).intValue());
							}
							else if(((String) object[1]).equalsIgnoreCase(""))
							{
								issueCatMap.put(remediationCategory.trim().toUpperCase(),((Long) object[2]).intValue());
							}
							else
							{
								if((String) object[1]!=null)
								{
									issueCatMap.put(((String) object[1]).trim().toUpperCase(),((Long) object[2]).intValue());
								}
								else {
									issueCatMap.put(((String) object[1]).trim().toUpperCase(),((Long) object[2]).intValue());
								}
							}
							
							resultMap.put(issueCategory, issueCatMap);
						}
	
					}
					}
					}
				
			session.close();}
			catch (Exception e) {
				logger.error("Error !!! " + e);
			}
			return resultMap;
		}
		
		
		//From DDR1 counts
				public Map<String,Map<String,Integer>> getRemIssueCatDdr1Count(final Long requestId)
				{
					final Map<String,Map<String,Integer>> resultMap = new HashMap<String,Map<String,Integer>>();
					Map<String,Integer> issueCatDistinctMap = null;
					session = sessionFactory.openSession();
					try
					{
						hql = "select remediationCategory,issueCategory,count(*) from S4HanaProfiler where requestID=:requestID group by remediationCategory,issueCategory";
					
						Query query = session.createQuery(hql);
						query.setParameter("requestID", requestId);
						
						String issueCategory="";
						List<Object[]> resultList = query.list();
						String objectType;
						if(CollectionUtils.isNotEmpty(resultList))
						{
							for(Object[] object : resultList)
							{
								if(object[0]!=null) {
								objectType = ((String) object[0]).trim().toUpperCase();
								if(resultMap.get(objectType)!=null)
								{
									issueCatDistinctMap = resultMap.get(objectType);
									if( object[1] == null)
									{
										issueCatDistinctMap.put(issueCategory.trim().toUpperCase(),((Long) object[2]).intValue());
									}
									else if(((String) object[1]).equalsIgnoreCase(""))
									{
										issueCatDistinctMap.put(issueCategory.trim().toUpperCase(),((Long) object[2]).intValue());
									}
									else
									{ 
										if((String) object[1]!=null)
										{
											issueCatDistinctMap.put(((String) object[1]).trim().toUpperCase(),((Long) object[2]).intValue());
										}
										else {
											issueCatDistinctMap.put(((String) object[1]).trim().toUpperCase(),((Long) object[2]).intValue());
										}
									}
								}
								else
								{
									issueCatDistinctMap = new HashMap<String,Integer>();
									if( object[1] == null)
									{
										issueCatDistinctMap.put(issueCategory.trim().toUpperCase(),((Long) object[2]).intValue());
									}
									else if(((String) object[1]).equalsIgnoreCase(""))
									{
										issueCatDistinctMap.put(issueCategory.trim().toUpperCase(),((Long) object[2]).intValue());
									}
									else
									{
										if((String) object[1]!=null)
										{
											issueCatDistinctMap.put(((String) object[1]).trim().toUpperCase(),((Long) object[2]).intValue());
										}
										else {
											issueCatDistinctMap.put(((String) object[1]).trim().toUpperCase(),((Long) object[2]).intValue());
										}
									}
									
									resultMap.put(objectType, issueCatDistinctMap);
								}
			
							}
							}
							}
						
					session.close();}
					catch (Exception e) {
						logger.error("Error !!! " + e);
					}
					return resultMap;
				}
				
				public Map<String,Integer> getTotalUsedCountImpactObjList(final Long requestId)
				{
					final Map<String,Integer> resultMap = new HashMap<String,Integer>();
					
					session = sessionFactory.openSession();
					try
					{
						hql = "select Used,count(*) from ImpactedObjList  where REQUEST_ID=:requestID and S4_Simplification=:S4_Simplification group by  Used";
									
						Query query = session.createQuery(hql);
						query.setParameter("requestID", requestId);
						query.setParameter("S4_Simplification", "X");
						
						String unused="N";
						
						List<Object[]> resultList = query.list();
						
						if (CollectionUtils.isNotEmpty(resultList)) {
							for (Object[] object : resultList) {
								if (object[0] == null || ((String) object[0]).equalsIgnoreCase("")) {
									long count = resultMap.containsKey(unused) ? resultMap.get(unused) : 0L;
									count += ((Long) object[1]).intValue();
									resultMap.put(unused, (int) count);
								} else {
									resultMap.put(((String) object[0]).trim().toUpperCase(), ((Long) object[1]).intValue());

								}
							}
						}
						session.close();
									
					}
					catch (Exception e) {
						logger.error("Error !!! " + e);
					}
					return resultMap;
				}
				
				public Map<String,Integer> getUsedOutputMngmtCount(final Long requestId)
				{
					final Map<String,Integer> resultMap = new HashMap<String,Integer>();
					
					session = sessionFactory.openSession();
					try
					{
						hql = "select used,count(distinct objNameType) from S4OutputMgmt where requestID=:requestID group by used";
									
						Query query = session.createQuery(hql);
						query.setParameter("requestID", requestId);
						
						String unused="N";
						List<Object[]> resultList = query.list();
						
						if(CollectionUtils.isNotEmpty(resultList)) {
							for(Object[] object : resultList) {
								if(object[0] == null || "".equalsIgnoreCase((String) object[0])) {
									long count = resultMap.containsKey(unused) ? resultMap.get(unused) : 0L;
									count += ((Long) object[1]).intValue();
									resultMap.put(unused, (int) count);
								} else {
									resultMap.put(((String) object[0]).toUpperCase(),((Long) object[1]).intValue());	
								}					
							}
						}
						session.close();
									
					}
					catch (Exception e) {
						logger.error("Error !!! " + e);
					}
					return resultMap;
				}
		
				public Map<String,Integer> getUsedAffectedCustomCount(final Long requestId)
				{
					final Map<String,Integer> resultMap = new HashMap<String,Integer>();
					
					session = sessionFactory.openSession();
					try
					{
						hql = "select used,count(distinct objNameType) from S4AffectCustomField  where requestID=:requestID group by used";
									
						Query query = session.createQuery(hql);
						query.setParameter("requestID", requestId);
						
						String unused="N";
						List<Object[]> resultList = query.list();
						
						if(CollectionUtils.isNotEmpty(resultList)) {
							for(Object[] object : resultList) {
								if (object[0] == null || ((String) object[0]).equalsIgnoreCase("")) {
									long count = resultMap.containsKey(unused) ? resultMap.get(unused) : 0L;
									count += ((Long) object[1]).intValue();
									resultMap.put(unused, (int) count);
								} else {
									resultMap.put(((String) object[0]).toUpperCase(), ((Long) object[1]).intValue());
								}				
							}
						}
						session.close();
									
					}
					catch (Exception e) {
						logger.error("Error !!! " + e);
					}
					return resultMap;
				}
		
		@Override
		public void updateRequestMasterS4(long requestId,ProcessedRequestDetail requestMasterCommon) {
			
			
			logger.info("S4 request Master Updating part1");
			
			ProcessedRequestDetail reqMaster=new ProcessedRequestDetail();
			reqMaster.setRequestID(requestId);	

			//Map<String, Map<String, Integer>> resultComplexity = getComplexityCount(requestId);
			//Map<String, Map<String, Integer>>  resultCompDdr2Object = getCompDdr2Count(requestId);	
			//Map<String, Map<String, Integer>>  resultCompDdr1Object = getCompDdr1Count(requestId);
		    //Map<String, Map<String, Integer>> RemediDDR2 =getRemediUsedUnsedDDR2Count(requestId);
			//Map<String, Integer> SimpliErrorCategoryCount = getSimpliCategoryDDR1Count(requestId);
			
		    Map<String, Map<String, Integer>> RemediDDR1 =getRemediUsedUnsedDDR1Count(requestId);
		    Map<String, Integer> SimpliCategoryCount = getSimpliCategoryDDR3Count(requestId);
		    Map<String, Map<String, Integer>> ErrorRem =getErrorRemDdr3Count(requestId);
			
						
			logger.info("S4 request Master Updated part1-done");
				
			int MandatoryCount=0;
			int OptionalCount=0;
			 
			logger.info("S4 request Master Updating data in fields part2"); 
			reqMaster.setScope("S4");
			
			//Request master Common columns
			reqMaster.setTotalObjectCount(requestMasterCommon.getTotalObjectCount());
			reqMaster.setUsed_count(requestMasterCommon.getUsed_count());
			reqMaster.setCustClasCount(requestMasterCommon.getCustClasCount());
			reqMaster.setCustProgCount(requestMasterCommon.getCustProgCount());
			reqMaster.setCustFormCount(requestMasterCommon.getCustFormCount());
			reqMaster.setCustFugrCount(requestMasterCommon.getCustFugrCount());
			reqMaster.setCustEnhanCount(requestMasterCommon.getCustEnhanCount());
			reqMaster.setCustLsmwCount(requestMasterCommon.getCustLsmwCount());		
			reqMaster.setCustWebCount(requestMasterCommon.getCustWebCount());
			reqMaster.setCustReptCount(requestMasterCommon.getCustReptCount());
			reqMaster.setCustViewCount(requestMasterCommon.getCustViewCount());
			reqMaster.setCustIndeCount(requestMasterCommon.getCustIndeCount());
			reqMaster.setCustDtelCount(requestMasterCommon.getCustDtelCount());
			reqMaster.setUsreCount(requestMasterCommon.getUsreCount());
			reqMaster.setUsrrCount(requestMasterCommon.getUsrrCount());
			reqMaster.setFugsCount(requestMasterCommon.getFugsCount());
			
			reqMaster.setCust_BWTRCount(requestMasterCommon.getCust_BWTRCount());
			reqMaster.setCust_BWTSCount(requestMasterCommon.getCust_BWTSCount());
			reqMaster.setCust_BWURCount(requestMasterCommon.getCust_BWURCount());
			reqMaster.setCust_BWIGCount(requestMasterCommon.getCust_BWIGCount());
			
			reqMaster.setCustUsedClasCount(requestMasterCommon.getCustUsedClasCount());
			reqMaster.setCustUsedProgCount(requestMasterCommon.getCustUsedProgCount());
			reqMaster.setCustUsedFormCount(requestMasterCommon.getCustUsedFormCount());
			reqMaster.setCustUsedFugrCount(requestMasterCommon.getCustUsedFugrCount());
			reqMaster.setCustUsedEnhanCount(requestMasterCommon.getCustUsedEnhanCount());
			reqMaster.setCustUsedLsmwCount(requestMasterCommon.getCustUsedLsmwCount());
			reqMaster.setCustUsedWebCount(requestMasterCommon.getCustUsedWebCount());
			reqMaster.setCustUsedReptCount(requestMasterCommon.getCustUsedReptCount());
			reqMaster.setCustUsedViewCount(requestMasterCommon.getCustUsedViewCount());
			reqMaster.setCustUsedIndxCount(requestMasterCommon.getCustUsedIndxCount());		
			reqMaster.setCustUsedDtelCount(requestMasterCommon.getCustUsedDtelCount());
			reqMaster.setUsreUsedCount(requestMasterCommon.getUsreUsedCount());
			reqMaster.setUsrrUsedCount(requestMasterCommon.getUsrrUsedCount());
			reqMaster.setFugsUsedCount(requestMasterCommon.getFugsUsedCount());	
			
			reqMaster.setCustUsed_BWTRCount(requestMasterCommon.getCustUsed_BWTRCount());	
			reqMaster.setCustUsed_BWTSCount(requestMasterCommon.getCustUsed_BWTSCount());
			reqMaster.setCustUsed_BWURCount(requestMasterCommon.getCustUsed_BWURCount());
			reqMaster.setCustUsed_BWIGCount(requestMasterCommon.getCustUsed_BWIGCount());
			
			Map<String, Map<String, Integer>>  resultErrorObject = getErrorObjectandUsedCount(requestId);
			reqMaster.setTotalErrorCount(getTotalCount(resultErrorObject));
			reqMaster.setErrorUsedCount(getTotalUsedCount("Y", resultErrorObject));
	
			Map<String, Map<String, Integer>> resultImpactedObjList = getUsedCountImpactObjList(requestId);

			int enhanImpact=0;
			int formImpact=0;
			enhanImpact=(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("ENHC"))+geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("ENHC")))+
			 				(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("ENHO"))+geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("ENHO")))+
			 				(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("ENHS"))+geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("ENHS")));
			
			formImpact=(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("SFPF"))+geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("SFPF")))+
	 				(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("SSFO"))+geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("SSFO")));

			
			
			reqMaster.setDefectClasCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("CLAS"))+geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("CLAS")));
			
			reqMaster.setDefect_BWTRCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("BWTR"))+geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("BWTR")));
			reqMaster.setDefect_BWTSCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("BWTS"))+geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("BWTS")));
			reqMaster.setDefect_BWURCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("BWUR"))+geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("BWUR")));
			reqMaster.setDefect_BWIGCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("BWIG"))+geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("BWIG")));
			
			reqMaster.setDefectProgCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("PROG"))+geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("PROG")));
			reqMaster.setDefectFormCount(formImpact);
			reqMaster.setDefectFugrCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("FUGR"))+geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("FUGR")));
			reqMaster.setDefectEnhanCount(enhanImpact);
			reqMaster.setDefectLsmwCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("LSMW"))+geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("LSMW")));
			reqMaster.setDefectWebCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("WDYN"))+geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("WDYN")));
			reqMaster.setDefectReptCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("REPT"))+geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("REPT")));
			reqMaster.setDefectViewCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("VIEW"))+geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("VIEW")));
			reqMaster.setDefectDtelCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("DTEL"))+geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("DTEL")));
			reqMaster.setDefectIndeCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("INDE"))+geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("INDE")));
			reqMaster.setDefectUsreCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("USRE"))+geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("USRE")));
			reqMaster.setDefectUsrrCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("USRR"))+geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("USRR")));
			reqMaster.setDefectFugsCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("FUGS"))+geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultImpactedObjList.get("FUGS")));
			
			
			
			int enhanUsedImpact=0;
			int formUsedImpact=0;
			enhanUsedImpact=(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("ENHC"))+
			 				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("ENHO"))+
			 				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("ENHS")));
			
			formUsedImpact=(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("SFPF"))+
	 				geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("SSFO")));

			
			reqMaster.setDefectUsedClasCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("CLAS")));
			
			reqMaster.setDefectUsed_BWTRCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("BWTR")));
			reqMaster.setDefectUsed_BWTSCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("BWTS")));
			reqMaster.setDefectUsed_BWURCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("BWUR")));
			reqMaster.setDefectUsed_BWIGCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("BWIG")));
			
			reqMaster.setDefectUsedProgCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("PROG")));
			reqMaster.setDefectUsedFormCount(formUsedImpact);
			reqMaster.setDefectUsedFugrCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("FUGR")));
			reqMaster.setDefectUsedEnhanCount(enhanUsedImpact);
			reqMaster.setDefectUsedLsmwCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("LSMW")));
			reqMaster.setDefectUsedWebCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("WDYN")));
			reqMaster.setDefectUsedReptCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("REPT")));
			reqMaster.setDefectUsedViewCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("VIEW")));
			reqMaster.setDefectUsedIndxCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("INDE")));
			reqMaster.setDefectUsedDtelCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("DTEL")));
			reqMaster.setDefectUsedUsreCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("USRE")));
			reqMaster.setDefectUsedUsrrCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("USRR")));
			reqMaster.setDefectUsedFugsCount(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultImpactedObjList.get("FUGS")));

			/**********************************************************************************************************
			*/
			//ObjectUsedOutputMgmt
			Map<String, Integer> usedTotalOutputMngmtCount = getUsedOutputMngmtCount(requestId);
			reqMaster.setObjectUsedOutputMgmt(geUsedUnsedColumnCount("Y", usedTotalOutputMngmtCount));

			//ObjectUsedCustomFields
			Map<String, Integer> usedTotalAffectCustomCount = getUsedAffectedCustomCount(requestId);			
			reqMaster.setObjectUsedCustomFields(geUsedUnsedColumnCount("Y", usedTotalAffectCustomCount));
			
			/**********************************************************************************************************
			*/
			Map<String, Integer> resultTotalImpactedObjList = getTotalUsedCountImpactObjList(requestId);			
			reqMaster.setRemCategoryObj(geUsedUnsedColumnCount("Y", resultTotalImpactedObjList) 
					+ geUsedUnsedColumnCount("N", resultTotalImpactedObjList));
			
			reqMaster.setRemCategoryObjError(getTotalCount(resultErrorObject));
			//Get total object count from Impacted Object List where toolname="S4"
			reqMaster.setDefectCount(geUsedUnsedColumnCount("Y", resultTotalImpactedObjList) + geUsedUnsedColumnCount("N", resultTotalImpactedObjList));
			
			//Note: Getting total object count from Impacted Object List where tool="s4" where used="y"
			reqMaster.setTotalImpactUsageCount(geUsedUnsedColumnCount("Y", resultTotalImpactedObjList));
			
			
			//Note: Updating all the types of defect and error counts from DDR1 
			int errorFormCount=0;
			errorFormCount=(geUsedUnsedColumnCount("Y", resultErrorObject.get("SFPF"))+geUsedUnsedColumnCount("N", resultErrorObject.get("SFPF")))+
	 				(geUsedUnsedColumnCount("Y", resultErrorObject.get("SSFO"))+geUsedUnsedColumnCount("N", resultErrorObject.get("SSFO")));
		
			int errorEnhanCount=0;
			errorEnhanCount=(geUsedUnsedColumnCount("Y", resultErrorObject.get("ENHC"))+geUsedUnsedColumnCount("N", resultErrorObject.get("ENHC")))+
			 				(geUsedUnsedColumnCount("Y", resultErrorObject.get("ENHO"))+geUsedUnsedColumnCount("N", resultErrorObject.get("ENHO")))+
			 				(geUsedUnsedColumnCount("Y", resultErrorObject.get("ENHS"))+geUsedUnsedColumnCount("N", resultErrorObject.get("ENHS")));
						 
			reqMaster.setErrorClasCount(geUsedUnsedColumnCount("Y", resultErrorObject.get("CLAS"))+geUsedUnsedColumnCount("N", resultErrorObject.get("CLAS")));
			
			reqMaster.setErrorBWTRCount(geUsedUnsedColumnCount("Y", resultErrorObject.get("BWTR"))+geUsedUnsedColumnCount("N", resultErrorObject.get("BWTR")));
			reqMaster.setErrorBWTSCount(geUsedUnsedColumnCount("Y", resultErrorObject.get("BWTS"))+geUsedUnsedColumnCount("N", resultErrorObject.get("BWTS")));
			reqMaster.setErrorBWURCount(geUsedUnsedColumnCount("Y", resultErrorObject.get("BWUR"))+geUsedUnsedColumnCount("N", resultErrorObject.get("BWUR")));
			reqMaster.setErrorBWIGCount(geUsedUnsedColumnCount("Y", resultErrorObject.get("BWIG"))+geUsedUnsedColumnCount("N", resultErrorObject.get("BWIG")));
			
			reqMaster.setErrorProgCount(geUsedUnsedColumnCount("Y", resultErrorObject.get("PROG"))+geUsedUnsedColumnCount("N", resultErrorObject.get("PROG")));
			reqMaster.setErrorFormCount(errorFormCount);
			reqMaster.setErrorFugrCount(geUsedUnsedColumnCount("Y", resultErrorObject.get("FUGR"))+geUsedUnsedColumnCount("N", resultErrorObject.get("FUGR")));
			reqMaster.setErrorEnhCount(errorEnhanCount);
			reqMaster.setErrorLsmwCount(geUsedUnsedColumnCount("Y", resultErrorObject.get("LSMW"))+geUsedUnsedColumnCount("N", resultErrorObject.get("LSMW")));
			//reqMaster.setErrorUserExitCount(geUsedUnsedColumnCount("used", resultErrorObject.get("USER EXIT"))+geUsedUnsedColumnCount("unused", resultErrorObject.get("USER EXIT")));
			reqMaster.setErrorWdynCount(geUsedUnsedColumnCount("Y", resultErrorObject.get("WDYN"))+geUsedUnsedColumnCount("N", resultErrorObject.get("WDYN")));
			reqMaster.setErrorReptCount(geUsedUnsedColumnCount("Y", resultErrorObject.get("REPT"))+geUsedUnsedColumnCount("N", resultErrorObject.get("REPT")));
			reqMaster.setErrorViewCount(geUsedUnsedColumnCount("Y", resultErrorObject.get("VIEW"))+geUsedUnsedColumnCount("N", resultErrorObject.get("VIEW")));
			reqMaster.setErrorIndxCount(geUsedUnsedColumnCount("Y", resultErrorObject.get("INDE"))+geUsedUnsedColumnCount("N", resultErrorObject.get("INDE")));
			reqMaster.setErrorDtelCount(geUsedUnsedColumnCount("Y", resultErrorObject.get("DTEL"))+geUsedUnsedColumnCount("N", resultErrorObject.get("DTEL")));
			reqMaster.setErrorFugsCount(geUsedUnsedColumnCount("Y", resultErrorObject.get("FUGS"))+geUsedUnsedColumnCount("N", resultErrorObject.get("FUGS")));
			reqMaster.setErrorUsreCount(geUsedUnsedColumnCount("Y", resultErrorObject.get("USRE"))+geUsedUnsedColumnCount("N", resultErrorObject.get("USRE")));
			reqMaster.setErrorUsrrCount(geUsedUnsedColumnCount("Y", resultErrorObject.get("USRR"))+geUsedUnsedColumnCount("N", resultErrorObject.get("USRR")));

			
			//Note: Updating all the types of used error counts from DDR1 
			int errorUsedFormCount=0;
			int errorUsedEnhanCount=0;
					
			errorUsedEnhanCount=(geUsedUnsedColumnCount("Y", resultErrorObject.get("ENHC")))+
				(geUsedUnsedColumnCount("Y", resultErrorObject.get("ENHO")))+
				(geUsedUnsedColumnCount("Y", resultErrorObject.get("ENHS")));
			
			
			errorUsedFormCount=(geUsedUnsedColumnCount("Y", resultErrorObject.get("SFPF")))+
					(geUsedUnsedColumnCount("Y", resultErrorObject.get("SSFO")));
			
			reqMaster.setErrorUsedClasCount(geUsedUnsedColumnCount("Y", resultErrorObject.get("CLAS")));
			
			reqMaster.setErrorUsedBWTRCount(geUsedUnsedColumnCount("Y", resultErrorObject.get("BWTR")));
			reqMaster.setErrorUsedBWTSCount(geUsedUnsedColumnCount("Y", resultErrorObject.get("BWTS")));
			reqMaster.setErrorUsedBWURCount(geUsedUnsedColumnCount("Y", resultErrorObject.get("BWUR")));
			reqMaster.setErrorUsedBWIGCount(geUsedUnsedColumnCount("Y", resultErrorObject.get("BWIG")));
			
			
			reqMaster.setErrorUsedProgCount(geUsedUnsedColumnCount("Y", resultErrorObject.get("PROG")));
			reqMaster.setErrorUsedFormCount(errorUsedFormCount);
			reqMaster.setErrorUsedFugrCount(geUsedUnsedColumnCount("Y", resultErrorObject.get("FUGR")));
			reqMaster.setErrorUsedFugsCount(geUsedUnsedColumnCount("Y", resultErrorObject.get("FUGS")));

			reqMaster.setErrorUsedEnhCount(errorUsedEnhanCount);
			reqMaster.setErrorUsedLsmwCount(geUsedUnsedColumnCount("Y", resultErrorObject.get("LSMW")));
			//reqMaster.setErrorUsedUserExitCount(geUsedUnsedColumnCount("used", resultErrorObject.get("USER EXIT")));
			reqMaster.setErrorUsedWdynCount(geUsedUnsedColumnCount("Y", resultErrorObject.get("WDYN")));
			reqMaster.setErrorUsedReptCount(geUsedUnsedColumnCount("Y", resultErrorObject.get("REPT")));
			reqMaster.setErrorUsedViewCount(geUsedUnsedColumnCount("Y", resultErrorObject.get("VIEW")));
			reqMaster.setErrorUsedIndxCount(geUsedUnsedColumnCount("Y", resultErrorObject.get("INDE")));
			reqMaster.setErrorUsedDtelCount(geUsedUnsedColumnCount("Y", resultErrorObject.get("DTEL")));
			reqMaster.setErrorUsedUsreCount(geUsedUnsedColumnCount("Y", resultErrorObject.get("USRE")));	
			reqMaster.setErrorUsedUsrrCount(geUsedUnsedColumnCount("Y", resultErrorObject.get("USRR")));	
			
			
			
			//Note: Updating count from DDR3
			 MandatoryCount=(geUsedUnsedColumnCount("Y", ErrorRem.get("MANDATORY")))+(geUsedUnsedColumnCount("N", ErrorRem.get("MANDATORY")));
			 OptionalCount=(geUsedUnsedColumnCount("Y", ErrorRem.get("OPTIONAL")))+(geUsedUnsedColumnCount("N", ErrorRem.get("OPTIONAL")));
			
			 reqMaster.setOptionalCount(OptionalCount);
			 reqMaster.setMandatory_Category_count(MandatoryCount);
			 
			 
			//DDR3 RemidiComplexity Count
			Map<String, Map<String, Integer>> resultMandComplexity =getRemComplexityDdr3Count(requestId);

			 reqMaster.setManCompHigh(geComplexityColumnCount("HIGH", resultMandComplexity.get("MANDATORY")));
			 reqMaster.setManCompMedium(geComplexityColumnCount("MEDIUM", resultMandComplexity.get("MANDATORY")));
			 reqMaster.setManCompLow(geComplexityColumnCount("LOW", resultMandComplexity.get("MANDATORY")));
			 reqMaster.setManCompTbd(geComplexityColumnCount("TBD", resultMandComplexity.get("MANDATORY")));
			 
			 reqMaster.setOptCompMedium(geComplexityColumnCount("MEDIUM", resultMandComplexity.get("OPTIONAL")));
			 reqMaster.setOptCompLow(geComplexityColumnCount("LOW", resultMandComplexity.get("OPTIONAL")));
			 reqMaster.setOptCompVeryLow(geComplexityColumnCount("VERY LOW", resultMandComplexity.get("OPTIONAL")));
			 
			//Output Management Counts
			Map<String, Integer> resultOutputMngmtMap = getCountOutputManagement(requestId);
			int outputMngmtTypeCount= (resultOutputMngmtMap.containsKey(("CLAS")) ? (resultOutputMngmtMap.get("CLAS")) : 0)+
					 (resultOutputMngmtMap.containsKey(("ENHO")) ? (resultOutputMngmtMap.get("ENHO")) : 0)+
					 (resultOutputMngmtMap.containsKey(("ENHC")) ? (resultOutputMngmtMap.get("ENHC")) : 0)+
					 (resultOutputMngmtMap.containsKey(("ENHS")) ? (resultOutputMngmtMap.get("ENHS")) : 0)+
					 (resultOutputMngmtMap.containsKey(("FUGR")) ? (resultOutputMngmtMap.get("FUGR")) : 0)+
					 (resultOutputMngmtMap.containsKey(("PROG")) ? (resultOutputMngmtMap.get("PROG")) : 0)+
					 (resultOutputMngmtMap.containsKey(("INDE")) ? (resultOutputMngmtMap.get("INDE")) : 0)+
					 (resultOutputMngmtMap.containsKey(("WDYN")) ? (resultOutputMngmtMap.get("WDYN")) : 0)+
					 (resultOutputMngmtMap.containsKey(("VIEW")) ? (resultOutputMngmtMap.get("VIEW")) : 0);
			 reqMaster.setObjectOutputManagement(outputMngmtTypeCount);
		
			//Affected by Custom Fields Counts
			Map<String, Integer> resultCustomFieldsMap = getCountCustomFields(requestId);
			int customFIeldsTypeCount= (resultCustomFieldsMap.containsKey(("CLAS")) ? (resultCustomFieldsMap.get("CLAS")) : 0)+
					 (resultCustomFieldsMap.containsKey(("ENHO")) ? (resultCustomFieldsMap.get("ENHO")) : 0)+
					 (resultCustomFieldsMap.containsKey(("ENHC")) ? (resultCustomFieldsMap.get("ENHC")) : 0)+
					 (resultCustomFieldsMap.containsKey(("ENHS")) ? (resultCustomFieldsMap.get("ENHS")) : 0)+
					 (resultCustomFieldsMap.containsKey(("FUGR")) ? (resultCustomFieldsMap.get("FUGR")) : 0)+
					 (resultCustomFieldsMap.containsKey(("PROG")) ? (resultCustomFieldsMap.get("PROG")) : 0)+
					 (resultCustomFieldsMap.containsKey(("INDE")) ? (resultCustomFieldsMap.get("INDE")) : 0)+
					 (resultCustomFieldsMap.containsKey(("WDYN")) ? (resultCustomFieldsMap.get("WDYN")) : 0)+
					 (resultCustomFieldsMap.containsKey(("VIEW")) ? (resultCustomFieldsMap.get("VIEW")) : 0);
			 reqMaster.setObjectCustomFields(customFIeldsTypeCount);
		
			//Note: Updating count from DDR1-total count
			 reqMaster.setErrorRemediationMandatory(geUsedUnsedColumnCount("Y", RemediDDR1.get("MANDATORY"))+geUsedUnsedColumnCount("N", RemediDDR1.get("MANDATORY")));
			 reqMaster.setErrorRemediationOptional(geUsedUnsedColumnCount("Y", RemediDDR1.get("OPTIONAL"))+geUsedUnsedColumnCount("N", RemediDDR1.get("OPTIONAL")));
			
			 //Note: Updating count from DDR1-Used Count
			 reqMaster.setErrorUsedRemMandatory(geUsedUnsedColumnCount("Y", RemediDDR1.get("MANDATORY")));
			 reqMaster.setErrorUsedRemOptional(geUsedUnsedColumnCount("Y", RemediDDR1.get("OPTIONAL")));

			//Note: Updating count from DDR1
			 Map<String, Map<String, Integer>> resultDistinctObjectCountRemidiCat =getDistinctObjectCountRemidiCat(requestId);
			 reqMaster.setMandUsedCount(geUsedUnsedColumnCount("Y", resultDistinctObjectCountRemidiCat.get("MANDATORY"))); 
			 reqMaster.setOptionalUsedCount(geUsedUnsedColumnCount("Y", resultDistinctObjectCountRemidiCat.get("OPTIONAL"))); 

			//Note: Updating counts from DDR3 for SimpliCategoryCount
			 reqMaster.setSimpCategoryCOEF((SimpliCategoryCount.containsKey(("Change of existing functionality").toUpperCase()) ? (SimpliCategoryCount.get(("Change of existing functionality").toUpperCase())) : 0));
			 reqMaster.setSimpCategoryFEA((SimpliCategoryCount.containsKey(("Functionality not available in SAP S/4HANA (functional equivalent available)").toUpperCase()) ? (SimpliCategoryCount.get(("Functionality not available in SAP S/4HANA (functional equivalent available)").toUpperCase())) : 0));
			 reqMaster.setSimpCategoryFENA((SimpliCategoryCount.containsKey(("Functionality not available in SAP S/4HANA (functional equivalent not available)").toUpperCase()) ? (SimpliCategoryCount.get(("Functionality not available in SAP S/4HANA (functional equivalent not available)").toUpperCase())) : 0));
			 reqMaster.setSimpCategoryNsfFEA((SimpliCategoryCount.containsKey(("Non-Strategic-function (functional equivalent available)").toUpperCase()) ? (SimpliCategoryCount.get(("Non-Strategic-function (functional equivalent available)").toUpperCase())) : 0));
			 reqMaster.setSimpCategoryNsfFENA((SimpliCategoryCount.containsKey(("Non-Strategic-function (functional equivalent not available)").toUpperCase()) ? (SimpliCategoryCount.get(("Non-Strategic-function (functional equivalent not available)").toUpperCase())) : 0));
			 reqMaster.setSimpCategoryNewS4Fun((SimpliCategoryCount.containsKey(("New S4 Functionality").toUpperCase()) ? (SimpliCategoryCount.get(("New S4 Functionality").toUpperCase())) : 0));

			 
			//Functional Area count from DDR2
		    Map<String, Integer> FunctionalAreaCount = getFunctionalAreaDDR2Count(requestId);
			reqMaster.setAcFinanceIntlTrade((FunctionalAreaCount.containsKey(("Financials - International Trade").toUpperCase()) ? (FunctionalAreaCount.get(("Financials - International Trade").toUpperCase())) : 0));
			reqMaster.setAcFinanceMisc((FunctionalAreaCount.containsKey(("Financial-Miscellaneous").toUpperCase()) ? (FunctionalAreaCount.get(("Financial-Miscellaneous").toUpperCase())) : 0));
			reqMaster.setAcFinanceCntrl((FunctionalAreaCount.containsKey(("Financials - Controlling").toUpperCase()) ? (FunctionalAreaCount.get(("Financials - Controlling").toUpperCase())) : 0));
			reqMaster.setAcIndustryRetail((FunctionalAreaCount.containsKey(("Industry Retail & Fashion").toUpperCase()) ? (FunctionalAreaCount.get(("Industry Retail & Fashion").toUpperCase())) : 0));
			reqMaster.setAcLogisticsMMIM((FunctionalAreaCount.containsKey(("Logistics - MM-IM").toUpperCase()) ? (FunctionalAreaCount.get(("Logistics - MM-IM").toUpperCase())) : 0));
			reqMaster.setAcProcurement((FunctionalAreaCount.containsKey(("Procurement").toUpperCase()) ? (FunctionalAreaCount.get(("Procurement").toUpperCase())) : 0));
			reqMaster.setAcLogisticsEHS((FunctionalAreaCount.containsKey(("Logistics - Environment, Health & Safety (EHS)").toUpperCase()) ? (FunctionalAreaCount.get(("Logistics - Environment, Health & Safety (EHS)").toUpperCase())) : 0));
			reqMaster.setAcSalesDistribution((FunctionalAreaCount.containsKey(("Sales & Distribution").toUpperCase()) ? (FunctionalAreaCount.get(("Sales & Distribution").toUpperCase())) : 0));
			reqMaster.setAcIndustryBeverage((FunctionalAreaCount.containsKey(("Industry Beverage").toUpperCase()) ? (FunctionalAreaCount.get(("Industry Beverage").toUpperCase())) : 0));
			reqMaster.setAcIndustryDimpEco((FunctionalAreaCount.containsKey(("Industry DIMP - EC&O").toUpperCase()) ? (FunctionalAreaCount.get(("Industry DIMP - EC&O").toUpperCase())) : 0));
			reqMaster.setAcFinanceGeneral((FunctionalAreaCount.containsKey(("Financials - General").toUpperCase()) ? (FunctionalAreaCount.get(("Financials - General").toUpperCase())) : 0));
			reqMaster.setAcLogisticsPP((FunctionalAreaCount.containsKey(("Logistics - PP").toUpperCase()) ? (FunctionalAreaCount.get(("Logistics - PP").toUpperCase())) : 0));
			reqMaster.setAcIndustryPubSec((FunctionalAreaCount.containsKey(("Industry Public Sector").toUpperCase()) ? (FunctionalAreaCount.get(("Industry Public Sector").toUpperCase())) : 0));
			reqMaster.setAcIndustryDimpHt((FunctionalAreaCount.containsKey(("Industry DIMP - High Tec").toUpperCase()) ? (FunctionalAreaCount.get(("Industry DIMP - High Tec").toUpperCase())) : 0));
			reqMaster.setAcIndustryCross((FunctionalAreaCount.containsKey(("Industry - Cross").toUpperCase()) ? (FunctionalAreaCount.get(("Industry - Cross").toUpperCase())) : 0));
			reqMaster.setAcIndustryAeroDef((FunctionalAreaCount.containsKey(("Industry DIMP - Aerospace & Defense").toUpperCase()) ? (FunctionalAreaCount.get(("Industry DIMP - Aerospace & Defense").toUpperCase())) : 0));
			reqMaster.setAcLogisticsPm((FunctionalAreaCount.containsKey(("Logistics - PM").toUpperCase()) ? (FunctionalAreaCount.get(("Logistics - PM").toUpperCase())) : 0));
			reqMaster.setAcLogisticsPlm((FunctionalAreaCount.containsKey(("Logistics - PLM").toUpperCase()) ? (FunctionalAreaCount.get(("Logistics - PLM").toUpperCase())) : 0));
			reqMaster.setAcIndustryAuto((FunctionalAreaCount.containsKey(("Industry DIMP - Automotive").toUpperCase()) ? (FunctionalAreaCount.get(("Industry DIMP - Automotive").toUpperCase())) : 0));
			reqMaster.setAcMiscellaneous((FunctionalAreaCount.containsKey(("Miscellaneous").toUpperCase()) ? (FunctionalAreaCount.get(("Miscellaneous").toUpperCase())) : 0));
			reqMaster.setAcMM((FunctionalAreaCount.containsKey(("MM").toUpperCase()) ? (FunctionalAreaCount.get(("MM").toUpperCase())) : 0));
			reqMaster.setAcLogisticsPS((FunctionalAreaCount.containsKey(("Logistics - PS").toUpperCase()) ? (FunctionalAreaCount.get(("Logistics - PS").toUpperCase())) : 0));
			reqMaster.setAcLogisticsATP((FunctionalAreaCount.containsKey(("Logistics - ATP").toUpperCase()) ? (FunctionalAreaCount.get(("Logistics - ATP").toUpperCase())) : 0));
			reqMaster.setAcIndustryMedia((FunctionalAreaCount.containsKey(("Industry-Media Product Master").toUpperCase()) ? (FunctionalAreaCount.get(("Industry-Media Product Master").toUpperCase())) : 0));
			reqMaster.setAcFinAssetAccount((FunctionalAreaCount.containsKey(("Financials - Asset Accounting").toUpperCase()) ? (FunctionalAreaCount.get(("Financials - Asset Accounting").toUpperCase())) : 0));
			reqMaster.setAcCrossTopics((FunctionalAreaCount.containsKey(("Cross Topics").toUpperCase()) ? (FunctionalAreaCount.get(("Cross Topics").toUpperCase())) : 0));
			reqMaster.setAcBatchMasterData((FunctionalAreaCount.containsKey(("Batch Master Data").toUpperCase()) ? (FunctionalAreaCount.get(("Batch Master Data").toUpperCase())) : 0));
			reqMaster.setAcMasterData((FunctionalAreaCount.containsKey(("Master Data").toUpperCase()) ? (FunctionalAreaCount.get(("Master Data").toUpperCase())) : 0));
			reqMaster.setAcLogisticsPss((FunctionalAreaCount.containsKey(("Logistics - PSS").toUpperCase()) ? (FunctionalAreaCount.get(("Logistics - PSS").toUpperCase())) : 0));
			reqMaster.setAcPortfolioPm((FunctionalAreaCount.containsKey(("Portfolio and Project Management (PPM)").toUpperCase()) ? (FunctionalAreaCount.get(("Portfolio and Project Management (PPM)").toUpperCase())) : 0));
			reqMaster.setAcFinGeneralLedger((FunctionalAreaCount.containsKey(("Financials - General Ledger").toUpperCase()) ? (FunctionalAreaCount.get(("Financials - General Ledger").toUpperCase())) : 0));
			reqMaster.setAcIndustryUtil((FunctionalAreaCount.containsKey(("Industry Utilities").toUpperCase()) ? (FunctionalAreaCount.get(("Industry Utilities").toUpperCase())) : 0));
			reqMaster.setAcGlobalLogistic((FunctionalAreaCount.containsKey(("Globalization Logistics").toUpperCase()) ? (FunctionalAreaCount.get(("Globalization Logistics").toUpperCase())) : 0));
			reqMaster.setAcIndustryOil((FunctionalAreaCount.containsKey(("Industry Oil").toUpperCase()) ? (FunctionalAreaCount.get(("Industry Oil").toUpperCase())) : 0));
			reqMaster.setAcLogisticQm((FunctionalAreaCount.containsKey(("Logistics - QM").toUpperCase()) ? (FunctionalAreaCount.get(("Logistics - QM").toUpperCase())) : 0));
			reqMaster.setAcFinAcctPayRecieve((FunctionalAreaCount.containsKey(("Financials - Accounts Payable/Accounts Receivable").toUpperCase()) ? (FunctionalAreaCount.get(("Financials - Accounts Payable/Accounts Receivable").toUpperCase())) : 0));
			reqMaster.setAcFinTreasury((FunctionalAreaCount.containsKey(("Financials - Treasury and Risk Management").toUpperCase()) ? (FunctionalAreaCount.get(("Financials - Treasury and Risk Management").toUpperCase())) : 0));
			reqMaster.setAcLogisticsGt((FunctionalAreaCount.containsKey(("Logistics - GT").toUpperCase()) ? (FunctionalAreaCount.get(("Logistics - GT").toUpperCase())) : 0));
			reqMaster.setAcHumanResources((FunctionalAreaCount.containsKey(("Human Resources").toUpperCase()) ? (FunctionalAreaCount.get(("Human Resources").toUpperCase())) : 0));
			reqMaster.setAcFinanceCashMgmt((FunctionalAreaCount.containsKey(("Financials - Cash Management").toUpperCase()) ? (FunctionalAreaCount.get(("Financials - Cash Management").toUpperCase())) : 0));
			reqMaster.setAcProjectManagement((FunctionalAreaCount.containsKey(("Project Management").toUpperCase()) ? (FunctionalAreaCount.get(("Project Management").toUpperCase())) : 0));
			reqMaster.setAcGlobalTrade((FunctionalAreaCount.containsKey(("Global Trade").toUpperCase()) ? (FunctionalAreaCount.get(("Global Trade").toUpperCase())) : 0));
			reqMaster.setAcCollaborationFolders((FunctionalAreaCount.containsKey(("Collaborative Engineering And Project Management").toUpperCase()) ? (FunctionalAreaCount.get(("Collaborative Engineering And Project Management").toUpperCase())) : 0));
			reqMaster.setAcResultsRecording((FunctionalAreaCount.containsKey(("Results Recording").toUpperCase()) ? (FunctionalAreaCount.get(("Results Recording").toUpperCase())) : 0));
			reqMaster.setAcDiscreteIndustriesAndMillProducts((FunctionalAreaCount.containsKey(("Discrete Industries And Mill Products").toUpperCase()) ? (FunctionalAreaCount.get(("Discrete Industries And Mill Products").toUpperCase())) : 0));
			reqMaster.setAcGeneralLedgerAccounting((FunctionalAreaCount.containsKey(("General Ledger Accounting").toUpperCase()) ? (FunctionalAreaCount.get(("General Ledger Accounting").toUpperCase())) : 0));
			reqMaster.setAcActualCostingMaterialLedger((FunctionalAreaCount.containsKey(("Actual Costing/Material Ledger").toUpperCase()) ? (FunctionalAreaCount.get(("Actual Costing/Material Ledger").toUpperCase())) : 0));
			reqMaster.setAcPricingAndConditions((FunctionalAreaCount.containsKey(("Pricing And Conditions").toUpperCase()) ? (FunctionalAreaCount.get(("Pricing And Conditions").toUpperCase())) : 0));
			reqMaster.setAcCreditManagement((FunctionalAreaCount.containsKey(("Credit Management").toUpperCase()) ? (FunctionalAreaCount.get(("Credit Management").toUpperCase())) : 0));
			reqMaster.setAcManufacturerPartNumber((FunctionalAreaCount.containsKey(("Manufacturer Part Number").toUpperCase()) ? (FunctionalAreaCount.get(("Manufacturer Part Number").toUpperCase())) : 0));
			reqMaster.setAcSupplierWorkplace((FunctionalAreaCount.containsKey(("Supplier Workplace").toUpperCase()) ? (FunctionalAreaCount.get(("Supplier Workplace").toUpperCase())) : 0));
			reqMaster.setAcDealerPortal((FunctionalAreaCount.containsKey(("Dealer Portal").toUpperCase()) ? (FunctionalAreaCount.get(("Dealer Portal").toUpperCase())) : 0));
			reqMaster.setAcSettlementManagement((FunctionalAreaCount.containsKey(("Settlement Management").toUpperCase()) ? (FunctionalAreaCount.get(("Settlement Management").toUpperCase())) : 0));
			reqMaster.setAcTreasuryAndRiskManagement((FunctionalAreaCount.containsKey(("Treasury And Risk Management").toUpperCase()) ? (FunctionalAreaCount.get(("Treasury And Risk Management").toUpperCase())) : 0));
			reqMaster.setAcCommodityManagement((FunctionalAreaCount.containsKey(("Commodity Management").toUpperCase()) ? (FunctionalAreaCount.get(("Commodity Management").toUpperCase())) : 0));
			reqMaster.setAcEnhancementsActualLaborCostingTimeRecording((FunctionalAreaCount.containsKey(("Enhancements Actual Labor Costing / Time Recording").toUpperCase()) ? (FunctionalAreaCount.get(("Enhancements Actual Labor Costing / Time Recording").toUpperCase())) : 0));
			reqMaster.setAcInstalledBaseManagement((FunctionalAreaCount.containsKey(("Installed Base Management").toUpperCase()) ? (FunctionalAreaCount.get(("Installed Base Management").toUpperCase())) : 0));
			reqMaster.setAcBusinessPartners((FunctionalAreaCount.containsKey(("Business Partners").toUpperCase()) ? (FunctionalAreaCount.get(("Business Partners").toUpperCase())) : 0));
			reqMaster.setAcSuiteEnablementForAriba((FunctionalAreaCount.containsKey(("Suite Enablement For Ariba").toUpperCase()) ? (FunctionalAreaCount.get(("Suite Enablement For Ariba").toUpperCase())) : 0));
			reqMaster.setAcArticles((FunctionalAreaCount.containsKey(("Articles").toUpperCase()) ? (FunctionalAreaCount.get(("Articles").toUpperCase())) : 0));
			reqMaster.setAcConsumerDecisionTree((FunctionalAreaCount.containsKey(("Consumer Decision Tree").toUpperCase()) ? (FunctionalAreaCount.get(("Consumer Decision Tree").toUpperCase())) : 0));
			reqMaster.setAcAssortmentList((FunctionalAreaCount.containsKey(("Assortment List").toUpperCase()) ? (FunctionalAreaCount.get(("Assortment List").toUpperCase())) : 0));
			reqMaster.setAcAvailabilityCheck((FunctionalAreaCount.containsKey(("Availability Check").toUpperCase()) ? (FunctionalAreaCount.get(("Availability Check").toUpperCase())) : 0));
			reqMaster.setAcSalesAndDistributionSdEnhancements((FunctionalAreaCount.containsKey(("Sales And Distribution (Sd) Enhancements").toUpperCase()) ? (FunctionalAreaCount.get(("Sales And Distribution (Sd) Enhancements").toUpperCase())) : 0));
			reqMaster.setAcConvergentInvoicing((FunctionalAreaCount.containsKey(("Convergent Invoicing").toUpperCase()) ? (FunctionalAreaCount.get(("Convergent Invoicing").toUpperCase())) : 0));
			reqMaster.setAcSapCashManagement((FunctionalAreaCount.containsKey(("Sap Cash Management").toUpperCase()) ? (FunctionalAreaCount.get(("Sap Cash Management").toUpperCase())) : 0));
			reqMaster.setAcVirtualDataModelForPpKanban((FunctionalAreaCount.containsKey(("Virtual Data Model For Pp Kanban").toUpperCase()) ? (FunctionalAreaCount.get(("Virtual Data Model For Pp Kanban").toUpperCase())) : 0));
			reqMaster.setAcMultichannelFoundationForUtilities((FunctionalAreaCount.containsKey(("Multichannel Foundation For Utilities").toUpperCase()) ? (FunctionalAreaCount.get(("Multichannel Foundation For Utilities").toUpperCase())) : 0));
			reqMaster.setAcTargetGroups((FunctionalAreaCount.containsKey(("Target Groups").toUpperCase()) ? (FunctionalAreaCount.get(("Target Groups").toUpperCase())) : 0));
			reqMaster.setAcCommodityManagementAnalytics((FunctionalAreaCount.containsKey(("Commodity Management - Analytics").toUpperCase()) ? (FunctionalAreaCount.get(("Commodity Management - Analytics").toUpperCase())) : 0));
			reqMaster.setAcLoansManagement((FunctionalAreaCount.containsKey(("Loans Management").toUpperCase()) ? (FunctionalAreaCount.get(("Loans Management").toUpperCase())) : 0));
			reqMaster.setAcGroupingPeggingDistribution((FunctionalAreaCount.containsKey(("Grouping, Pegging & Distribution").toUpperCase()) ? (FunctionalAreaCount.get(("Grouping, Pegging & Distribution").toUpperCase())) : 0));
			reqMaster.setAcBasicFunctions((FunctionalAreaCount.containsKey(("Basic Functions").toUpperCase()) ? (FunctionalAreaCount.get(("Basic Functions").toUpperCase())) : 0));
			reqMaster.setAcContractManagement((FunctionalAreaCount.containsKey(("Contract Management").toUpperCase()) ? (FunctionalAreaCount.get(("Contract Management").toUpperCase())) : 0));
			reqMaster.setAcTransactionManager((FunctionalAreaCount.containsKey(("Transaction Manager").toUpperCase()) ? (FunctionalAreaCount.get(("Transaction Manager").toUpperCase())) : 0));
			reqMaster.setAcExtendedLogistics((FunctionalAreaCount.containsKey(("Extended Logistics").toUpperCase()) ? (FunctionalAreaCount.get(("Extended Logistics").toUpperCase())) : 0));
			reqMaster.setAcProductConfigurator((FunctionalAreaCount.containsKey(("Product Configurator").toUpperCase()) ? (FunctionalAreaCount.get(("Product Configurator").toUpperCase())) : 0));
			reqMaster.setAcFreightSettlement((FunctionalAreaCount.containsKey(("Freight Settlement").toUpperCase()) ? (FunctionalAreaCount.get(("Freight Settlement").toUpperCase())) : 0));
			reqMaster.setAcCustomFields((FunctionalAreaCount.containsKey(("Custom Fields").toUpperCase()) ? (FunctionalAreaCount.get(("Custom Fields").toUpperCase())) : 0));
			reqMaster.setAcFieldLengthExtensionForMaterial((FunctionalAreaCount.containsKey(("Field Length Extension For Material").toUpperCase()) ? (FunctionalAreaCount.get(("Field Length Extension For Material").toUpperCase())) : 0));
			reqMaster.setAcProductMasterData((FunctionalAreaCount.containsKey(("Product Master Data").toUpperCase()) ? (FunctionalAreaCount.get(("Product Master Data").toUpperCase())) : 0));
			reqMaster.setAcAssetAccounting((FunctionalAreaCount.containsKey(("Asset Accounting").toUpperCase()) ? (FunctionalAreaCount.get(("Asset Accounting").toUpperCase())) : 0));
			reqMaster.setAcFundAccounting((FunctionalAreaCount.containsKey(("Fund Accounting").toUpperCase()) ? (FunctionalAreaCount.get(("Fund Accounting").toUpperCase())) : 0));
			reqMaster.setAcCustomerInteractionCenter((FunctionalAreaCount.containsKey(("Customer Interaction Center").toUpperCase()) ? (FunctionalAreaCount.get(("Customer Interaction Center").toUpperCase())) : 0));
			reqMaster.setAcFundsManagement((FunctionalAreaCount.containsKey(("Funds Management").toUpperCase()) ? (FunctionalAreaCount.get(("Funds Management").toUpperCase())) : 0));
			reqMaster.setAcInboundTracking((FunctionalAreaCount.containsKey(("Inbound Tracking").toUpperCase()) ? (FunctionalAreaCount.get(("Inbound Tracking").toUpperCase())) : 0));
			reqMaster.setAcDocumentManagementSystem((FunctionalAreaCount.containsKey(("Document Management System").toUpperCase()) ? (FunctionalAreaCount.get(("Document Management System").toUpperCase())) : 0));
			reqMaster.setAcSapUtilities((FunctionalAreaCount.containsKey(("Sap Utilities").toUpperCase()) ? (FunctionalAreaCount.get(("Sap Utilities").toUpperCase())) : 0));
			reqMaster.setAcConstructionEquipmentManagement((FunctionalAreaCount.containsKey(("Construction Equipment Management").toUpperCase()) ? (FunctionalAreaCount.get(("Construction Equipment Management").toUpperCase())) : 0));
			reqMaster.setAcRetailFashionManagementInS4Hana((FunctionalAreaCount.containsKey(("Retail & Fashion Management In S/4Hana").toUpperCase()) ? (FunctionalAreaCount.get(("Retail & Fashion Management In S/4Hana").toUpperCase())) : 0));
			reqMaster.setAcLogisticsGeneralLoEnhancements((FunctionalAreaCount.containsKey(("Logistics - General (Lo) Enhancements").toUpperCase()) ? (FunctionalAreaCount.get(("Logistics - General (Lo) Enhancements").toUpperCase())) : 0));
			reqMaster.setAcFioriUi((FunctionalAreaCount.containsKey(("Fiori Ui").toUpperCase()) ? (FunctionalAreaCount.get(("Fiori Ui").toUpperCase())) : 0));
			reqMaster.setAcFlightScheduling((FunctionalAreaCount.containsKey(("Flight Scheduling").toUpperCase()) ? (FunctionalAreaCount.get(("Flight Scheduling").toUpperCase())) : 0));
			reqMaster.setAcPerishablesProcurement((FunctionalAreaCount.containsKey(("Perishables Procurement").toUpperCase()) ? (FunctionalAreaCount.get(("Perishables Procurement").toUpperCase())) : 0));
			reqMaster.setAcPricecatalogue((FunctionalAreaCount.containsKey(("Pricecatalogue").toUpperCase()) ? (FunctionalAreaCount.get(("Pricecatalogue").toUpperCase())) : 0));
			reqMaster.setAcAmountFieldExtension((FunctionalAreaCount.containsKey(("Amount Field Extension").toUpperCase()) ? (FunctionalAreaCount.get(("Amount Field Extension").toUpperCase())) : 0));
			reqMaster.setAcChargeback((FunctionalAreaCount.containsKey(("Chargeback").toUpperCase()) ? (FunctionalAreaCount.get(("Chargeback").toUpperCase())) : 0));
			reqMaster.setAcCountrySpecificCustomizingFunctionality((FunctionalAreaCount.containsKey(("Country Specific Customizing & Functionality").toUpperCase()) ? (FunctionalAreaCount.get(("Country Specific Customizing & Functionality").toUpperCase())) : 0));
			reqMaster.setAcGoodsReceiptCapacityCheck((FunctionalAreaCount.containsKey(("Goods Receipt Capacity Check").toUpperCase()) ? (FunctionalAreaCount.get(("Goods Receipt Capacity Check").toUpperCase())) : 0));
			reqMaster.setAcProductStructureAndAssemblyManagement((FunctionalAreaCount.containsKey(("Product Structure And Assembly Management").toUpperCase()) ? (FunctionalAreaCount.get(("Product Structure And Assembly Management").toUpperCase())) : 0));
			reqMaster.setAcOilGasSecondaryDistribution((FunctionalAreaCount.containsKey(("Oil&Gas Secondary Distribution").toUpperCase()) ? (FunctionalAreaCount.get(("Oil&Gas Secondary Distribution").toUpperCase())) : 0));
			reqMaster.setAcInstoreProduction((FunctionalAreaCount.containsKey(("Instore Production").toUpperCase()) ? (FunctionalAreaCount.get(("Instore Production").toUpperCase())) : 0));
			reqMaster.setAcLeaseAccounting((FunctionalAreaCount.containsKey(("Lease Accounting").toUpperCase()) ? (FunctionalAreaCount.get(("Lease Accounting").toUpperCase())) : 0));
			reqMaster.setAcIntrastatReporting((FunctionalAreaCount.containsKey(("Intrastat Reporting").toUpperCase()) ? (FunctionalAreaCount.get(("Intrastat Reporting").toUpperCase())) : 0));
			reqMaster.setAcProductDesigner((FunctionalAreaCount.containsKey(("Product Designer").toUpperCase()) ? (FunctionalAreaCount.get(("Product Designer").toUpperCase())) : 0));
			reqMaster.setAcExciseDutyWithActiveExtensionEaCp((FunctionalAreaCount.containsKey(("Excise Duty (With Active Extension Ea-Cp)").toUpperCase()) ? (FunctionalAreaCount.get(("Excise Duty (With Active Extension Ea-Cp)").toUpperCase())) : 0));
			reqMaster.setAcContractAccountsReceivableAndPayable((FunctionalAreaCount.containsKey(("Contract Accounts Receivable And Payable").toUpperCase()) ? (FunctionalAreaCount.get(("Contract Accounts Receivable And Payable").toUpperCase())) : 0));
			reqMaster.setAcBatchMaster((FunctionalAreaCount.containsKey(("Batch Master").toUpperCase()) ? (FunctionalAreaCount.get(("Batch Master").toUpperCase())) : 0));
			reqMaster.setAcMaterialRequirementsPlanning((FunctionalAreaCount.containsKey(("Material Requirements Planning").toUpperCase()) ? (FunctionalAreaCount.get(("Material Requirements Planning").toUpperCase())) : 0));
			reqMaster.setAcManualAccruals((FunctionalAreaCount.containsKey(("Manual Accruals").toUpperCase()) ? (FunctionalAreaCount.get(("Manual Accruals").toUpperCase())) : 0));
			reqMaster.setAcIndustrySpecificComponentHighTech((FunctionalAreaCount.containsKey(("Industry-Specific Component High Tech").toUpperCase()) ? (FunctionalAreaCount.get(("Industry-Specific Component High Tech").toUpperCase())) : 0));reqMaster.setAcLogisticsGeneralLoEnhancements((FunctionalAreaCount.containsKey(("Logistics - General (Lo) Enhancements").toUpperCase()) ? (FunctionalAreaCount.get(("Logistics - General (Lo) Enhancements").toUpperCase())) : 0));
			reqMaster.setAcDistributorResellerManagement((FunctionalAreaCount.containsKey(("Distributor-Reseller-Management").toUpperCase()) ? (FunctionalAreaCount.get(("Distributor-Reseller-Management").toUpperCase())) : 0));
			reqMaster.setAcRetailPricing((FunctionalAreaCount.containsKey(("Retail Pricing").toUpperCase()) ? (FunctionalAreaCount.get(("Retail Pricing").toUpperCase())) : 0));
			reqMaster.setAcGfClassification((FunctionalAreaCount.containsKey(("Gf: Classification").toUpperCase()) ? (FunctionalAreaCount.get(("Gf: Classification").toUpperCase())) : 0));
			reqMaster.setAcMerchandiseAndAssortmentPlanning((FunctionalAreaCount.containsKey(("Merchandise And Assortment Planning").toUpperCase()) ? (FunctionalAreaCount.get(("Merchandise And Assortment Planning").toUpperCase())) : 0));
			reqMaster.setAcProductionPlanningAndControlPpEnhancements((FunctionalAreaCount.containsKey(("Production Planning And Control (Pp) Enhancements").toUpperCase()) ? (FunctionalAreaCount.get(("Production Planning And Control (Pp) Enhancements").toUpperCase())) : 0));
			reqMaster.setAcSales((FunctionalAreaCount.containsKey(("Sales").toUpperCase()) ? (FunctionalAreaCount.get(("Sales").toUpperCase())) : 0));
			reqMaster.setAcDependencies((FunctionalAreaCount.containsKey(("Dependencies").toUpperCase()) ? (FunctionalAreaCount.get(("Dependencies").toUpperCase())) : 0));
			reqMaster.setAcMaintenanceOrders((FunctionalAreaCount.containsKey(("Maintenance Orders").toUpperCase()) ? (FunctionalAreaCount.get(("Maintenance Orders").toUpperCase())) : 0));
			reqMaster.setAcBillingOfQuantity((FunctionalAreaCount.containsKey(("Billing Of Quantity").toUpperCase()) ? (FunctionalAreaCount.get(("Billing Of Quantity").toUpperCase())) : 0));
			reqMaster.setAcBillOfServices((FunctionalAreaCount.containsKey(("Bill Of Services").toUpperCase()) ? (FunctionalAreaCount.get(("Bill Of Services").toUpperCase())) : 0));
			reqMaster.setAcBrazil((FunctionalAreaCount.containsKey(("Brazil").toUpperCase()) ? (FunctionalAreaCount.get(("Brazil").toUpperCase())) : 0));
			reqMaster.setAcHydrocarbonProductManagement((FunctionalAreaCount.containsKey(("Hydrocarbon Product Management").toUpperCase()) ? (FunctionalAreaCount.get(("Hydrocarbon Product Management").toUpperCase())) : 0));
			reqMaster.setAcProductCatalog((FunctionalAreaCount.containsKey(("Product Catalog").toUpperCase()) ? (FunctionalAreaCount.get(("Product Catalog").toUpperCase())) : 0));
			reqMaster.setAcBulkSecondaryLogisticsManagement((FunctionalAreaCount.containsKey(("Bulk Secondary Logistics Management").toUpperCase()) ? (FunctionalAreaCount.get(("Bulk Secondary Logistics Management").toUpperCase())) : 0));
			reqMaster.setAcBusinessAnalytics((FunctionalAreaCount.containsKey(("Business Analytics").toUpperCase()) ? (FunctionalAreaCount.get(("Business Analytics").toUpperCase())) : 0));
			reqMaster.setAcPlmEnterpriseSearch((FunctionalAreaCount.containsKey(("Plm Enterprise Search").toUpperCase()) ? (FunctionalAreaCount.get(("Plm Enterprise Search").toUpperCase())) : 0));
			reqMaster.setAcLabeling((FunctionalAreaCount.containsKey(("Labeling").toUpperCase()) ? (FunctionalAreaCount.get(("Labeling").toUpperCase())) : 0));
			reqMaster.setAcRecipeDevelopment((FunctionalAreaCount.containsKey(("Recipe Development").toUpperCase()) ? (FunctionalAreaCount.get(("Recipe Development").toUpperCase())) : 0));
			reqMaster.setAcPortalContent((FunctionalAreaCount.containsKey(("Portal Content").toUpperCase()) ? (FunctionalAreaCount.get(("Portal Content").toUpperCase())) : 0));
			reqMaster.setAcPortfolioManagement((FunctionalAreaCount.containsKey(("Portfolio Management").toUpperCase()) ? (FunctionalAreaCount.get(("Portfolio Management").toUpperCase())) : 0));
			reqMaster.setAcPricecatalogueOutbound((FunctionalAreaCount.containsKey(("Pricecatalogue Outbound").toUpperCase()) ? (FunctionalAreaCount.get(("Pricecatalogue Outbound").toUpperCase())) : 0));
			reqMaster.setAcProducts((FunctionalAreaCount.containsKey(("Products").toUpperCase()) ? (FunctionalAreaCount.get(("Products").toUpperCase())) : 0));
			reqMaster.setAcQualityManagement((FunctionalAreaCount.containsKey(("Quality Management").toUpperCase()) ? (FunctionalAreaCount.get(("Quality Management").toUpperCase())) : 0));
			reqMaster.setAcHomeBuilidngSolutions((FunctionalAreaCount.containsKey(("Home Builidng Solutions").toUpperCase()) ? (FunctionalAreaCount.get(("Home Builidng Solutions").toUpperCase())) : 0));
			reqMaster.setAcRecipe((FunctionalAreaCount.containsKey(("Recipe").toUpperCase()) ? (FunctionalAreaCount.get(("Recipe").toUpperCase())) : 0));
			reqMaster.setAcClassification((FunctionalAreaCount.containsKey(("Classification").toUpperCase()) ? (FunctionalAreaCount.get(("Classification").toUpperCase())) : 0));
			reqMaster.setAcBopfBusinessObjectFrameworkForAbap((FunctionalAreaCount.containsKey(("Bopf Business Object Framework For Abap").toUpperCase()) ? (FunctionalAreaCount.get(("Bopf Business Object Framework For Abap").toUpperCase())) : 0));
			reqMaster.setAcSapSimpleFinanceDataMigration((FunctionalAreaCount.containsKey(("Sap Simple Finance Data Migration").toUpperCase()) ? (FunctionalAreaCount.get(("Sap Simple Finance Data Migration").toUpperCase())) : 0));
			reqMaster.setAcReplenishment((FunctionalAreaCount.containsKey(("Replenishment").toUpperCase()) ? (FunctionalAreaCount.get(("Replenishment").toUpperCase())) : 0));
			reqMaster.setAcAdditionalsManagement((FunctionalAreaCount.containsKey(("Additionals Management").toUpperCase()) ? (FunctionalAreaCount.get(("Additionals Management").toUpperCase())) : 0));
			reqMaster.setAcFreeGoods((FunctionalAreaCount.containsKey(("Free Goods").toUpperCase()) ? (FunctionalAreaCount.get(("Free Goods").toUpperCase())) : 0));
			reqMaster.setAcAnalyticalApplications((FunctionalAreaCount.containsKey(("Analytical Applications").toUpperCase()) ? (FunctionalAreaCount.get(("Analytical Applications").toUpperCase())) : 0));
			reqMaster.setAcRetailDemandManagement((FunctionalAreaCount.containsKey(("Retail Demand Management").toUpperCase()) ? (FunctionalAreaCount.get(("Retail Demand Management").toUpperCase())) : 0));
			reqMaster.setAcLogisticsBasicData((FunctionalAreaCount.containsKey(("Logistics Basic Data").toUpperCase()) ? (FunctionalAreaCount.get(("Logistics Basic Data").toUpperCase())) : 0));
			reqMaster.setAcRetailInformationSystem((FunctionalAreaCount.containsKey(("Retail Information System").toUpperCase()) ? (FunctionalAreaCount.get(("Retail Information System").toUpperCase())) : 0));
			reqMaster.setAcPurchaseOrders((FunctionalAreaCount.containsKey(("Purchase Orders").toUpperCase()) ? (FunctionalAreaCount.get(("Purchase Orders").toUpperCase())) : 0));
			reqMaster.setAcRetailLedger((FunctionalAreaCount.containsKey(("Retail Ledger").toUpperCase()) ? (FunctionalAreaCount.get(("Retail Ledger").toUpperCase())) : 0));
			reqMaster.setAcPromotion((FunctionalAreaCount.containsKey(("Promotion").toUpperCase()) ? (FunctionalAreaCount.get(("Promotion").toUpperCase())) : 0));
			reqMaster.setAcRetailMethodOfAccounting((FunctionalAreaCount.containsKey(("Retail Method Of Accounting").toUpperCase()) ? (FunctionalAreaCount.get(("Retail Method Of Accounting").toUpperCase())) : 0));
			reqMaster.setAcRetail((FunctionalAreaCount.containsKey(("Retail").toUpperCase()) ? (FunctionalAreaCount.get(("Retail").toUpperCase())) : 0));
			reqMaster.setAcLoadBuilding((FunctionalAreaCount.containsKey(("Load Building").toUpperCase()) ? (FunctionalAreaCount.get(("Load Building").toUpperCase())) : 0));
			reqMaster.setAcInventoryManagement((FunctionalAreaCount.containsKey(("Inventory Management").toUpperCase()) ? (FunctionalAreaCount.get(("Inventory Management").toUpperCase())) : 0));
			reqMaster.setAcSalesPriceValuation((FunctionalAreaCount.containsKey(("Sales Price Valuation").toUpperCase()) ? (FunctionalAreaCount.get(("Sales Price Valuation").toUpperCase())) : 0));
			reqMaster.setAcIndustryRetailAndFashion((FunctionalAreaCount.containsKey(("Industry Retail And Fashion").toUpperCase()) ? (FunctionalAreaCount.get(("Industry Retail And Fashion").toUpperCase())) : 0));
			reqMaster.setAcSapRetailStore((FunctionalAreaCount.containsKey(("Sap Retail Store").toUpperCase()) ? (FunctionalAreaCount.get(("Sap Retail Store").toUpperCase())) : 0));
			reqMaster.setAcAutomaticDocumentAdjustment((FunctionalAreaCount.containsKey(("Automatic Document Adjustment").toUpperCase()) ? (FunctionalAreaCount.get(("Automatic Document Adjustment").toUpperCase())) : 0));
			reqMaster.setAcSalesSupport((FunctionalAreaCount.containsKey(("Sales Support").toUpperCase()) ? (FunctionalAreaCount.get(("Sales Support").toUpperCase())) : 0));
			reqMaster.setAcERecruiting((FunctionalAreaCount.containsKey(("E-Recruiting").toUpperCase()) ? (FunctionalAreaCount.get(("E-Recruiting").toUpperCase())) : 0));
			reqMaster.setAcTrainingManagement((FunctionalAreaCount.containsKey(("Training Management").toUpperCase()) ? (FunctionalAreaCount.get(("Training Management").toUpperCase())) : 0));
			reqMaster.setAcWasteManagement((FunctionalAreaCount.containsKey(("Waste Management").toUpperCase()) ? (FunctionalAreaCount.get(("Waste Management").toUpperCase())) : 0));
			reqMaster.setAcBilling((FunctionalAreaCount.containsKey(("Billing").toUpperCase()) ? (FunctionalAreaCount.get(("Billings").toUpperCase())) : 0));
			reqMaster.setAcOrdersAndContracts((FunctionalAreaCount.containsKey(("Orders And Contracts").toUpperCase()) ? (FunctionalAreaCount.get(("Orders And Contracts").toUpperCase())) : 0));
			reqMaster.setAcProjectSystem((FunctionalAreaCount.containsKey(("Project System").toUpperCase()) ? (FunctionalAreaCount.get(("Project System").toUpperCase())) : 0));
			reqMaster.setAcInformationSystem((FunctionalAreaCount.containsKey(("Information System").toUpperCase()) ? (FunctionalAreaCount.get(("Information System").toUpperCase())) : 0));
			reqMaster.setAcMaterialMaster((FunctionalAreaCount.containsKey(("Material Master").toUpperCase()) ? (FunctionalAreaCount.get(("Material Master").toUpperCase())) : 0));
			reqMaster.setAcWorkbenchUtilities((FunctionalAreaCount.containsKey(("Workbench Utilities").toUpperCase()) ? (FunctionalAreaCount.get(("Workbench Utilities").toUpperCase())) : 0));
			reqMaster.setAcSoftwareLicenseManagement((FunctionalAreaCount.containsKey(("Software License Management").toUpperCase()) ? (FunctionalAreaCount.get(("Software License Management").toUpperCase())) : 0));
			reqMaster.setAcCrossApplicationComponentCaEnhancements((FunctionalAreaCount.containsKey(("Cross-Application Component (Ca) Enhancements").toUpperCase()) ? (FunctionalAreaCount.get(("Cross-Application Component (Ca) Enhancements").toUpperCase())) : 0));
			reqMaster.setAcOrderAllocationRun((FunctionalAreaCount.containsKey(("Order Allocation Run").toUpperCase()) ? (FunctionalAreaCount.get(("Order Allocation Run").toUpperCase())) : 0));
			reqMaster.setAcNetweaverEnterpriseSearch((FunctionalAreaCount.containsKey(("Netweaver Enterprise Search").toUpperCase()) ? (FunctionalAreaCount.get(("Netweaver Enterprise Search").toUpperCase())) : 0));
			reqMaster.setAcMeasurementSystem((FunctionalAreaCount.containsKey(("Measurement System").toUpperCase()) ? (FunctionalAreaCount.get(("Measurement System").toUpperCase())) : 0));
			reqMaster.setAcFind((FunctionalAreaCount.containsKey(("Find").toUpperCase()) ? (FunctionalAreaCount.get(("Find").toUpperCase())) : 0));
			reqMaster.setAcProductSafety((FunctionalAreaCount.containsKey(("Product Safety").toUpperCase()) ? (FunctionalAreaCount.get(("Product Safety").toUpperCase())) : 0));
			reqMaster.setAcExpenditureCertification((FunctionalAreaCount.containsKey(("Expenditure Certification").toUpperCase()) ? (FunctionalAreaCount.get(("Expenditure Certification").toUpperCase())) : 0));
			reqMaster.setAcRebateProcessing((FunctionalAreaCount.containsKey(("Rebate Processing").toUpperCase()) ? (FunctionalAreaCount.get(("Rebate Processing").toUpperCase())) : 0));
			reqMaster.setAcPlmWebUserInterface((FunctionalAreaCount.containsKey(("Plm Web User Interface").toUpperCase()) ? (FunctionalAreaCount.get(("Plm Web User Interface").toUpperCase())) : 0));
			reqMaster.setAcBillsOfMaterial((FunctionalAreaCount.containsKey(("Bills Of Material").toUpperCase()) ? (FunctionalAreaCount.get(("Bills Of Material").toUpperCase())) : 0));
			reqMaster.setAcConstructionProgressReport((FunctionalAreaCount.containsKey(("Construction Progress Report").toUpperCase()) ? (FunctionalAreaCount.get(("Construction Progress Report").toUpperCase())) : 0));
			reqMaster.setAcRiskAssessment((FunctionalAreaCount.containsKey(("Risk Assessment").toUpperCase()) ? (FunctionalAreaCount.get(("Risk Assessment").toUpperCase())) : 0));
			reqMaster.setAcConfirmation((FunctionalAreaCount.containsKey(("Confirmation").toUpperCase()) ? (FunctionalAreaCount.get(("Confirmation").toUpperCase())) : 0));
			reqMaster.setAcTraderSchedulerWorkbench((FunctionalAreaCount.containsKey(("Trader'S And Scheduler'S Workbench").toUpperCase()) ? (FunctionalAreaCount.get(("Trader'S And Scheduler'S Workbench").toUpperCase())) : 0));
			reqMaster.setAcEnetting((FunctionalAreaCount.containsKey(("Enetting").toUpperCase()) ? (FunctionalAreaCount.get(("Enetting").toUpperCase())) : 0));
			reqMaster.setAcProductionOrders((FunctionalAreaCount.containsKey(("Production Orders").toUpperCase()) ? (FunctionalAreaCount.get(("Production Orders").toUpperCase())) : 0));
			reqMaster.setAcExchanges((FunctionalAreaCount.containsKey(("Exchanges").toUpperCase()) ? (FunctionalAreaCount.get(("Exchanges").toUpperCase())) : 0));
			reqMaster.setAcGoodsMovementValuation((FunctionalAreaCount.containsKey(("Goods Movement Valuation").toUpperCase()) ? (FunctionalAreaCount.get(("Goods Movement Valuation").toUpperCase())) : 0));
			reqMaster.setAcMaintenanceProcessing((FunctionalAreaCount.containsKey(("Maintenance Processing").toUpperCase()) ? (FunctionalAreaCount.get(("Maintenance Processing").toUpperCase())) : 0));
			reqMaster.setAcDownstream((FunctionalAreaCount.containsKey(("Downstream").toUpperCase()) ? (FunctionalAreaCount.get(("Downstream").toUpperCase())) : 0));
			reqMaster.setAcProductStructure((FunctionalAreaCount.containsKey(("Product Structure").toUpperCase()) ? (FunctionalAreaCount.get(("Product Structure").toUpperCase())) : 0));
			reqMaster.setAcConsulting((FunctionalAreaCount.containsKey(("Consulting").toUpperCase()) ? (FunctionalAreaCount.get(("Consulting").toUpperCase())) : 0));
			reqMaster.setAcInterfaceToExternalProjectSoftware((FunctionalAreaCount.containsKey(("Interface To External Project Software").toUpperCase()) ? (FunctionalAreaCount.get(("Interface To External Project Software").toUpperCase())) : 0));
			reqMaster.setAcRevenueRecognition((FunctionalAreaCount.containsKey(("Revenue Recognition").toUpperCase()) ? (FunctionalAreaCount.get(("Revenue Recognition").toUpperCase())) : 0));
			reqMaster.setAcSubsequentSettlement((FunctionalAreaCount.containsKey(("Subsequent Settlement").toUpperCase()) ? (FunctionalAreaCount.get(("Subsequent Settlement").toUpperCase())) : 0));
			reqMaster.setAcBusinessSuiteReleaseInformation((FunctionalAreaCount.containsKey(("Business Suite Release Information").toUpperCase()) ? (FunctionalAreaCount.get(("Business Suite Release Information").toUpperCase())) : 0));
			reqMaster.setAcProductionOptimizationInterfacePoi((FunctionalAreaCount.containsKey(("Production Optimization Interface (Poi)").toUpperCase()) ? (FunctionalAreaCount.get(("Production Optimization Interface (Poi)").toUpperCase())) : 0));
			reqMaster.setAcFunctionsForUSFederalGovernment((FunctionalAreaCount.containsKey(("Functions For U.S. Federal Government").toUpperCase()) ? (FunctionalAreaCount.get(("Functions For U.S. Federal Government").toUpperCase())) : 0));
			reqMaster.setAcIndustrialHygieneAndSafety((FunctionalAreaCount.containsKey(("Industrial Hygiene And Safety").toUpperCase()) ? (FunctionalAreaCount.get(("Industrial Hygiene And Safety").toUpperCase())) : 0));
			reqMaster.setAcKanban((FunctionalAreaCount.containsKey(("Kanban").toUpperCase()) ? (FunctionalAreaCount.get(("Kanban").toUpperCase())) : 0));
			reqMaster.setAcOccupationalHealth((FunctionalAreaCount.containsKey(("Occupational Health").toUpperCase()) ? (FunctionalAreaCount.get(("Occupational Health").toUpperCase())) : 0));
			reqMaster.setAcScheduling((FunctionalAreaCount.containsKey(("Scheduling").toUpperCase()) ? (FunctionalAreaCount.get(("Scheduling").toUpperCase())) : 0));
			reqMaster.setAcReporting((FunctionalAreaCount.containsKey(("Reporting").toUpperCase()) ? (FunctionalAreaCount.get(("Reporting").toUpperCase())) : 0));
			reqMaster.setAcBasicDataAndTools((FunctionalAreaCount.containsKey(("Basic Data And Tools").toUpperCase()) ? (FunctionalAreaCount.get(("Basic Data And Tools").toUpperCase())) : 0));
			reqMaster.setAcProductCompliance((FunctionalAreaCount.containsKey(("Product Compliance").toUpperCase()) ? (FunctionalAreaCount.get(("Product Compliance").toUpperCase())) : 0));
			reqMaster.setAcSapProductAndReachCompliance((FunctionalAreaCount.containsKey(("Sap Product And Reach Compliance").toUpperCase()) ? (FunctionalAreaCount.get(("Sap Product And Reach Compliance").toUpperCase())) : 0));
			reqMaster.setAcExternalServiceAgent((FunctionalAreaCount.containsKey(("External Service Agent").toUpperCase()) ? (FunctionalAreaCount.get(("External Service Agent").toUpperCase())) : 0));
			reqMaster.setAcComplaintsProcessing((FunctionalAreaCount.containsKey(("Complaints Processing").toUpperCase()) ? (FunctionalAreaCount.get(("Complaints Processing").toUpperCase())) : 0));
			reqMaster.setAcForecastingProcedures((FunctionalAreaCount.containsKey(("Forecasting Procedures").toUpperCase()) ? (FunctionalAreaCount.get(("Forecasting Procedures").toUpperCase())) : 0));
			reqMaster.setAcEnhancementsInTransportationBordero((FunctionalAreaCount.containsKey(("Enhancements In Transportation (Bordero)").toUpperCase()) ? (FunctionalAreaCount.get(("Enhancements In Transportation (Bordero)").toUpperCase())) : 0));
			reqMaster.setAcSoftwareMaintenanceProcessing((FunctionalAreaCount.containsKey(("Software Maintenance Processing").toUpperCase()) ? (FunctionalAreaCount.get(("Software Maintenance Processing").toUpperCase())) : 0));
			reqMaster.setAcPerishablesPlanning((FunctionalAreaCount.containsKey(("Perishables Planning").toUpperCase()) ? (FunctionalAreaCount.get(("Perishables Planning").toUpperCase())) : 0));
			reqMaster.setAcAlternativeHistoricalDataForForecasting((FunctionalAreaCount.containsKey(("Alternative Historical Data For Forecasting").toUpperCase()) ? (FunctionalAreaCount.get(("Alternative Historical Data For Forecasting").toUpperCase())) : 0));
			reqMaster.setAcMerchandiseCategories((FunctionalAreaCount.containsKey(("Merchandise Categories").toUpperCase()) ? (FunctionalAreaCount.get(("Merchandise Categories").toUpperCase())) : 0));
			reqMaster.setAcIndia((FunctionalAreaCount.containsKey(("India").toUpperCase()) ? (FunctionalAreaCount.get(("India").toUpperCase())) : 0));
			reqMaster.setAcBpForSubcontracting((FunctionalAreaCount.containsKey(("Bp For Subcontracting").toUpperCase()) ? (FunctionalAreaCount.get(("Bp For Subcontracting").toUpperCase())) : 0));
			reqMaster.setAcCollaborationFolders((FunctionalAreaCount.containsKey(("Collaboration Folders").toUpperCase()) ? (FunctionalAreaCount.get(("Collaboration Folders").toUpperCase())) : 0));
			reqMaster.setAcSearch((FunctionalAreaCount.containsKey(("Search").toUpperCase()) ? (FunctionalAreaCount.get(("Search").toUpperCase())) : 0));
			reqMaster.setAcGeneralFunctions((FunctionalAreaCount.containsKey(("General Functions").toUpperCase()) ? (FunctionalAreaCount.get(("General Functions").toUpperCase())) : 0));
			reqMaster.setAcRoutingEbomAssignment((FunctionalAreaCount.containsKey(("Routing: Ebom Assignment").toUpperCase()) ? (FunctionalAreaCount.get(("Routing: Ebom Assignment").toUpperCase())) : 0));
			
			
			//Note: Updating Error count from DDR1 for IssueCat counts
			Map<String, Map<String, Integer>> resultUsedIssueCat =getObjectUsedIssueCat(requestId);
			    reqMaster.setNewDataModelCnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultUsedIssueCat.get(("New Data Model").toUpperCase()))+geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultUsedIssueCat.get(("New Data Model").toUpperCase())));
				reqMaster.setMaterial_lengthExtension_cnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultUsedIssueCat.get(("Material Length Extension").toUpperCase()))+geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultUsedIssueCat.get(("Material Length Extension").toUpperCase())));
				reqMaster.setData_Element_lengthExtension_cnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultUsedIssueCat.get(("Data Element Length Extension").toUpperCase()))+geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultUsedIssueCat.get(("Data Element Length Extension").toUpperCase())));
				reqMaster.setEliminationOf_Status_Table_cnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultUsedIssueCat.get(("Elimination of Status Tables").toUpperCase()))+geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultUsedIssueCat.get(("Elimination of Status Tables").toUpperCase())));
				reqMaster.setRemovalOf_OrphenedObjects_cnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultUsedIssueCat.get(("Removal of Orphened Objects").toUpperCase()))+geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultUsedIssueCat.get(("Removal of Orphened Objects").toUpperCase())));
				reqMaster.setCustomCode_Adaption_cnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultUsedIssueCat.get(("Custom Code Adaption").toUpperCase()))+geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultUsedIssueCat.get(("Custom Code Adaption").toUpperCase())));
				reqMaster.setRetiredFunctionality_cnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultUsedIssueCat.get(("Retired Functionality").toUpperCase()))+geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultUsedIssueCat.get(("Retired Functionality").toUpperCase())));
				reqMaster.setNewS4Functionality_cnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultUsedIssueCat.get(("New S4 Functionality").toUpperCase()))+geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultUsedIssueCat.get(("New S4 Functionality").toUpperCase())));
				reqMaster.setReplacedByNewFunctionality_cnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultUsedIssueCat.get(("Replaced by new functionality").toUpperCase()))+geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultUsedIssueCat.get(("Replaced by new functionality").toUpperCase())));
				reqMaster.setNewTransaction_cnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultUsedIssueCat.get(("New Transaction").toUpperCase()))+geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultUsedIssueCat.get(("New Transaction").toUpperCase())));
				reqMaster.setFunctionalEquivalentAvailable_cnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultUsedIssueCat.get(("Functional equivalent available").toUpperCase()))+geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultUsedIssueCat.get(("Functional equivalent available").toUpperCase())));
				reqMaster.setSimplificationOfExistingTable_cnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultUsedIssueCat.get(("Simplification of Existing Table").toUpperCase()))+geUsedUnsedColumnCount(Hana_Profiler_Constant.UNUSED_N, resultUsedIssueCat.get(("Simplification of Existing Table").toUpperCase())));

				reqMaster.setNew_dataModel_Usedcnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultUsedIssueCat.get(("New Data Model").toUpperCase())));
				reqMaster.setMaterial_lengthExtension_Usedcnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultUsedIssueCat.get(("Material Length Extension").toUpperCase())));
				reqMaster.setData_Element_lengthExtension_Usedcnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultUsedIssueCat.get(("Data Element Length Extension").toUpperCase())));
				reqMaster.setEliminationOf_Status_Table_Usedcnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultUsedIssueCat.get(("Elimination of Status Tables").toUpperCase())));
				reqMaster.setRemovalOf_OrphenedObjects_Usedcnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultUsedIssueCat.get(("Removal of Orphened Objects").toUpperCase())));
				reqMaster.setCustomCode_Adaption_Usedcnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultUsedIssueCat.get(("Custom Code Adaption").toUpperCase())));
				reqMaster.setRetiredFunctionality_Usedcnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultUsedIssueCat.get(("Retired Functionality").toUpperCase())));
				reqMaster.setNewS4Functionality_Usedcnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultUsedIssueCat.get(("New S4 Functionality").toUpperCase())));
				reqMaster.setReplacedByNewFunctionality_Usedcnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultUsedIssueCat.get(("Replaced by new functionality").toUpperCase())));
				reqMaster.setNewTransaction_Usedcnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultUsedIssueCat.get(("New Transaction").toUpperCase())));
				reqMaster.setFunctionalEquivalentAvailable_Usedcnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultUsedIssueCat.get(("Functional equivalent available").toUpperCase())));
				reqMaster.setSimplificationOfExistingTable_Usedcnt(geUsedUnsedColumnCount(Hana_Profiler_Constant.USED_Y, resultUsedIssueCat.get(("Simplification of Existing Table").toUpperCase())));
			
			
			//Note: Updating Object/Distinct count from DDR1 for IssueCat counts
			Map<String, Map<String, Integer>> resultDistinctObjectCountIssueCat =getDistinctObjectCountIssueCat(requestId);
			    reqMaster.setDefNewDataModel(geUsedUnsedColumnCount("Y", resultDistinctObjectCountIssueCat.get(("New Data Model").toUpperCase()))+geUsedUnsedColumnCount("N", resultDistinctObjectCountIssueCat.get(("New Data Model").toUpperCase())));
				reqMaster.setDefMaterialLengthExt(geUsedUnsedColumnCount("Y", resultDistinctObjectCountIssueCat.get(("Material Length Extension").toUpperCase()))+geUsedUnsedColumnCount("N", resultDistinctObjectCountIssueCat.get(("Material Length Extension").toUpperCase())));
				reqMaster.setDefDataElementlengthExt(geUsedUnsedColumnCount("Y", resultDistinctObjectCountIssueCat.get(("Data Element Length Extension").toUpperCase()))+geUsedUnsedColumnCount("N", resultDistinctObjectCountIssueCat.get(("Data Element Length Extension").toUpperCase())));
				reqMaster.setDefEliminationOfStatusTable(geUsedUnsedColumnCount("Y", resultDistinctObjectCountIssueCat.get(("Elimination of Status Tables").toUpperCase()))+geUsedUnsedColumnCount("N", resultDistinctObjectCountIssueCat.get(("Elimination of Status Tables").toUpperCase())));
				reqMaster.setDefRemovalOrphenObjects(geUsedUnsedColumnCount("Y", resultDistinctObjectCountIssueCat.get(("Removal of Orphened Objects").toUpperCase()))+geUsedUnsedColumnCount("N", resultDistinctObjectCountIssueCat.get(("Removal of Orphened Objects").toUpperCase())));
				reqMaster.setDefCustomCodeAdaption(geUsedUnsedColumnCount("Y", resultDistinctObjectCountIssueCat.get(("Custom Code Adaption").toUpperCase()))+geUsedUnsedColumnCount("N", resultDistinctObjectCountIssueCat.get(("Custom Code Adaption").toUpperCase())));
				reqMaster.setDefRetiredFunctionality(geUsedUnsedColumnCount("Y", resultDistinctObjectCountIssueCat.get(("Retired Functionality").toUpperCase()))+geUsedUnsedColumnCount("N", resultDistinctObjectCountIssueCat.get(("Retired Functionality").toUpperCase())));
				reqMaster.setDefNewS4Functionality(geUsedUnsedColumnCount("Y", resultDistinctObjectCountIssueCat.get(("New S4 Functionality").toUpperCase()))+geUsedUnsedColumnCount("N", resultDistinctObjectCountIssueCat.get(("New S4 Functionality").toUpperCase())));
				reqMaster.setDefReplacNewFunctionality(geUsedUnsedColumnCount("Y", resultDistinctObjectCountIssueCat.get(("Replaced by new functionality").toUpperCase()))+geUsedUnsedColumnCount("N", resultDistinctObjectCountIssueCat.get(("Replaced by new functionality").toUpperCase())));
				reqMaster.setDefNewTransaction(geUsedUnsedColumnCount("Y", resultDistinctObjectCountIssueCat.get(("New Transaction").toUpperCase()))+geUsedUnsedColumnCount("N", resultDistinctObjectCountIssueCat.get(("New Transaction").toUpperCase())));
				reqMaster.setDefFunctionalEqvAvailable(geUsedUnsedColumnCount("Y", resultDistinctObjectCountIssueCat.get(("Functional equivalent available").toUpperCase()))+geUsedUnsedColumnCount("N", resultDistinctObjectCountIssueCat.get(("Functional equivalent available").toUpperCase())));
				reqMaster.setDefSimplificationExistTable(geUsedUnsedColumnCount("Y", resultDistinctObjectCountIssueCat.get(("Simplification of Existing Table").toUpperCase()))+geUsedUnsedColumnCount("N", resultDistinctObjectCountIssueCat.get(("Simplification of Existing Table").toUpperCase())));
				
				reqMaster.setDefNewDataModelUsed(geUsedUnsedColumnCount("Y", resultDistinctObjectCountIssueCat.get(("New Data Model").toUpperCase())));
				reqMaster.setDefMaterialLengthExtUsed(geUsedUnsedColumnCount("Y", resultDistinctObjectCountIssueCat.get(("Material Length Extension").toUpperCase())));
				reqMaster.setDefDataElementlengthExtUsed(geUsedUnsedColumnCount("Y", resultDistinctObjectCountIssueCat.get(("Data Element Length Extension").toUpperCase())));
				reqMaster.setDefEliminationOfStatusTableUsed(geUsedUnsedColumnCount("Y", resultDistinctObjectCountIssueCat.get(("Elimination of Status Tables").toUpperCase())));
				reqMaster.setDefRemovalOrphenObjectsUsed(geUsedUnsedColumnCount("Y", resultDistinctObjectCountIssueCat.get(("Removal of Orphened Objects").toUpperCase())));
				reqMaster.setDefCustomCodeAdaptionUsed(geUsedUnsedColumnCount("Y", resultDistinctObjectCountIssueCat.get(("Custom Code Adaption").toUpperCase())));
				reqMaster.setDefRetiredFunctionalityUsed(geUsedUnsedColumnCount("Y", resultDistinctObjectCountIssueCat.get(("Retired Functionality").toUpperCase())));
				reqMaster.setDefNewS4FunctionalityUsed(geUsedUnsedColumnCount("Y", resultDistinctObjectCountIssueCat.get(("New S4 Functionality").toUpperCase())));
				reqMaster.setDefReplacNewFunctionalityUsed(geUsedUnsedColumnCount("Y", resultDistinctObjectCountIssueCat.get(("Replaced by new functionality").toUpperCase())));
				reqMaster.setDefNewTransactionUsed(geUsedUnsedColumnCount("Y", resultDistinctObjectCountIssueCat.get(("New Transaction").toUpperCase())));
				reqMaster.setDefFunctionalEqvAvailableUsed(geUsedUnsedColumnCount("Y", resultDistinctObjectCountIssueCat.get(("Functional equivalent available").toUpperCase())));
				reqMaster.setDefSimplificationExistTableUsed(geUsedUnsedColumnCount("Y", resultDistinctObjectCountIssueCat.get(("Simplification of Existing Table").toUpperCase())));
			
				
			//Issue Category DDR3 counts
			Map<String, Map<String, Integer>> resultRemIssueCatDDR3 =getRemIssueCatDdr3Count(requestId);
				int manCustomCdCount=0;
				int manDataElementCount=0;
				int manStatusTableCount=0;
				int manMatLengthCount=0;				
				int manDataModelCount=0;
				int manNewS4FunCount=0;
				int manNewTransCount=0;
				int manRemOrphanCount=0;
				int manRetiredFunCount=0;
				int manSimpExistTabCount=0;
				int manRepNewFunCount=0;				
				int manFunEqvAvlCount=0;
				int manAdaptCustCdCount=0;
				int manCustFieldsCount=0;
				int manObsTransCount=0;
				int manOutputMgmtCount=0;

				int optCustomCdCount=0;
				int optDataElementCount=0;
				int optStatusTableCount=0;
				int optMatLengthCount=0;				
				int optDataModelCount=0;
				int optNewS4FunCount=0;
				int optNewTransCount=0;
				int optRemOrphanCount=0;
				int optRetiredFunCount=0;
				int optSimpExistTabCount=0;
				int optRepNewFunCount=0;				
				int optFunEqvAvlCount=0;
				int optAdaptCustCdCount=0;
				int optCustFieldsCount=0;
				int optObsTransCount=0;
				int optOutputMgmtCount=0;


				manCustomCdCount=(getIssueCatColumnCount("MANDATORY", resultRemIssueCatDDR3.get(("Custom Code").toUpperCase())));
				manDataElementCount=(getIssueCatColumnCount("MANDATORY", resultRemIssueCatDDR3.get(("Data Element Length Extension").toUpperCase())));
				manStatusTableCount=(getIssueCatColumnCount("MANDATORY", resultRemIssueCatDDR3.get(("Elimination of Status Tables").toUpperCase())));
				manMatLengthCount=(getIssueCatColumnCount("MANDATORY", resultRemIssueCatDDR3.get(("Material Length Extension").toUpperCase())));
				manDataModelCount=(getIssueCatColumnCount("MANDATORY", resultRemIssueCatDDR3.get(("New Data Model").toUpperCase())));
				manNewS4FunCount=(getIssueCatColumnCount("MANDATORY", resultRemIssueCatDDR3.get(("New S4 Functionality").toUpperCase())));
				manNewTransCount=(getIssueCatColumnCount("MANDATORY", resultRemIssueCatDDR3.get(("New Transaction").toUpperCase())));
				manRemOrphanCount=(getIssueCatColumnCount("MANDATORY", resultRemIssueCatDDR3.get(("Removal of Orphened Objects").toUpperCase())));
				manRetiredFunCount=(getIssueCatColumnCount("MANDATORY", resultRemIssueCatDDR3.get(("Retired Functionality").toUpperCase())));
				manSimpExistTabCount=(getIssueCatColumnCount("MANDATORY", resultRemIssueCatDDR3.get(("Simplification of Existing Table").toUpperCase())));
				manRepNewFunCount=(getIssueCatColumnCount("MANDATORY", resultRemIssueCatDDR3.get(("Replaced by new functionality").toUpperCase())));
				manFunEqvAvlCount=(getIssueCatColumnCount("MANDATORY", resultRemIssueCatDDR3.get(("Functional equivalent available").toUpperCase())));
				manAdaptCustCdCount=(getIssueCatColumnCount("MANDATORY", resultRemIssueCatDDR3.get(("Custom Code Adaption").toUpperCase())));
				manCustFieldsCount=(getIssueCatColumnCount("MANDATORY", resultRemIssueCatDDR3.get(("Custom Fields in SAP Tables").toUpperCase())));
				manObsTransCount=(getIssueCatColumnCount("MANDATORY", resultRemIssueCatDDR3.get(("Obsolete Transaction").toUpperCase())));
				manOutputMgmtCount=(getIssueCatColumnCount("MANDATORY", resultRemIssueCatDDR3.get(("Output Management").toUpperCase())));

				optCustomCdCount=(getIssueCatColumnCount("OPTIONAL", resultRemIssueCatDDR3.get(("Custom Code").toUpperCase())));
				optDataElementCount=(getIssueCatColumnCount("OPTIONAL", resultRemIssueCatDDR3.get(("Data Element Length Extension").toUpperCase())));
				optStatusTableCount=(getIssueCatColumnCount("OPTIONAL", resultRemIssueCatDDR3.get(("Elimination of Status Tables").toUpperCase())));
				optMatLengthCount=(getIssueCatColumnCount("OPTIONAL", resultRemIssueCatDDR3.get(("Material Length Extension").toUpperCase())));
				optDataModelCount=(getIssueCatColumnCount("OPTIONAL", resultRemIssueCatDDR3.get(("New Data Model").toUpperCase())));
				optNewS4FunCount=(getIssueCatColumnCount("OPTIONAL", resultRemIssueCatDDR3.get(("New S4 Functionality").toUpperCase())));
				optNewTransCount=(getIssueCatColumnCount("OPTIONAL", resultRemIssueCatDDR3.get(("New Transaction").toUpperCase())));
				optRemOrphanCount=(getIssueCatColumnCount("OPTIONAL", resultRemIssueCatDDR3.get(("Removal of Orphened Objects").toUpperCase())));
				optRetiredFunCount=(getIssueCatColumnCount("OPTIONAL", resultRemIssueCatDDR3.get(("Retired Functionality").toUpperCase())));
				optSimpExistTabCount=(getIssueCatColumnCount("OPTIONAL", resultRemIssueCatDDR3.get(("Simplification of Existing Table").toUpperCase())));
				optRepNewFunCount=(getIssueCatColumnCount("OPTIONAL", resultRemIssueCatDDR3.get(("Replaced by new functionality").toUpperCase())));
				optFunEqvAvlCount=(getIssueCatColumnCount("OPTIONAL", resultRemIssueCatDDR3.get(("Functional equivalent available").toUpperCase())));
				optAdaptCustCdCount=(getIssueCatColumnCount("OPTIONAL", resultRemIssueCatDDR3.get(("Custom Code Adaption").toUpperCase())));
				optCustFieldsCount=(getIssueCatColumnCount("OPTIONAL", resultRemIssueCatDDR3.get(("Custom Fields in SAP Tables").toUpperCase())));
				optObsTransCount=(getIssueCatColumnCount("OPTIONAL", resultRemIssueCatDDR3.get(("Obsolete Transaction").toUpperCase())));
				optOutputMgmtCount=(getIssueCatColumnCount("OPTIONAL", resultRemIssueCatDDR3.get(("Output Management").toUpperCase())));
				 
				reqMaster.setManCustomCd(manCustomCdCount);
				reqMaster.setManDataElement(manDataElementCount);
				reqMaster.setManStatusTable(manStatusTableCount);
				reqMaster.setManMatLength(manMatLengthCount);
				reqMaster.setManDataModel(manDataModelCount);
				reqMaster.setManNewS4Fun(manNewS4FunCount);
				reqMaster.setManNewTrans(manNewTransCount);
				reqMaster.setManRemOrphan(manRemOrphanCount);
				reqMaster.setManRetiredFun(manRetiredFunCount);
				reqMaster.setManSimpExistTab(manSimpExistTabCount);
				reqMaster.setManRepNewFun(manRepNewFunCount);
				reqMaster.setManFunEqvAvl(manFunEqvAvlCount);
				reqMaster.setManAdaptCustCd(manAdaptCustCdCount);
				reqMaster.setManCustFields(manCustFieldsCount);
				reqMaster.setManObsTrans(manObsTransCount);
				reqMaster.setManOutputMgmt(manOutputMgmtCount);
				
				reqMaster.setOptCustomCd(optCustomCdCount);
				reqMaster.setOptDataElement(optDataElementCount);
				reqMaster.setOptStatusTable(optStatusTableCount);
				reqMaster.setOptMatLength(optMatLengthCount);
				reqMaster.setOptDataModel(optDataModelCount);
				reqMaster.setOptNewS4Fun(optNewS4FunCount);
				reqMaster.setOptNewTrans(optNewTransCount);
				reqMaster.setOptRemOrphan(optRemOrphanCount);
				reqMaster.setOptRetiredFun(optRetiredFunCount);
				reqMaster.setOptSimpExistTab(optSimpExistTabCount);
				reqMaster.setOptRepNewFun(optRepNewFunCount);
				reqMaster.setOptFunEqvAvl(optFunEqvAvlCount);
				reqMaster.setOptAdaptCustCd(optAdaptCustCdCount);
				reqMaster.setOptCustFields(optCustFieldsCount);
				reqMaster.setOptObsTrans(optObsTransCount);
				reqMaster.setOptOutputMgmt(optOutputMgmtCount);

			//Issue Category DDR1 counts
			Map<String, Map<String, Integer>> resultRemIssueCatDDR1 =getRemIssueCatDdr1Count(requestId);
				 
				reqMaster.setManCustomCdError(getIssueCatColumnCount("Custom Code".toUpperCase(), resultRemIssueCatDDR1.get("MANDATORY")));
				reqMaster.setManDataElementError(getIssueCatColumnCount("Data Element Length Extension".toUpperCase(), resultRemIssueCatDDR1.get("MANDATORY")));
				reqMaster.setManStatusTableError(getIssueCatColumnCount("Elimination of Status Tables".toUpperCase(), resultRemIssueCatDDR1.get("MANDATORY")));
				reqMaster.setManMatLengthError(getIssueCatColumnCount("Material Length Extension".toUpperCase(), resultRemIssueCatDDR1.get("MANDATORY")));
				reqMaster.setManDataModelError(getIssueCatColumnCount("New Data Model".toUpperCase(), resultRemIssueCatDDR1.get("MANDATORY")));
				reqMaster.setManNewS4FunError(getIssueCatColumnCount("New S4 Functionality".toUpperCase(), resultRemIssueCatDDR1.get("MANDATORY")));
				reqMaster.setManNewTransError(getIssueCatColumnCount("New Transaction".toUpperCase(), resultRemIssueCatDDR1.get("MANDATORY")));
				reqMaster.setManRemOrphanError(getIssueCatColumnCount("Removal of Orphened Objects".toUpperCase(), resultRemIssueCatDDR1.get("MANDATORY")));
				reqMaster.setManRetiredFunError(getIssueCatColumnCount("Retired Functionality".toUpperCase(), resultRemIssueCatDDR1.get("MANDATORY")));
				reqMaster.setManSimpExistTabError(getIssueCatColumnCount("Simplification of Existing Table".toUpperCase(), resultRemIssueCatDDR1.get("MANDATORY")));
				reqMaster.setManRepNewFunError(getIssueCatColumnCount("Replaced by new functionality".toUpperCase(), resultRemIssueCatDDR1.get("MANDATORY")));
				reqMaster.setManFunEqvAvlError(getIssueCatColumnCount("Functional equivalent available".toUpperCase(), resultRemIssueCatDDR1.get("MANDATORY")));
				reqMaster.setManAdaptCustCdError(getIssueCatColumnCount("Custom Code Adaption".toUpperCase(), resultRemIssueCatDDR1.get("MANDATORY")));
				reqMaster.setManCustFieldsError(getIssueCatColumnCount("Custom Fields in SAP Tables".toUpperCase(), resultRemIssueCatDDR1.get("MANDATORY")));
				reqMaster.setManObsTransError(getIssueCatColumnCount("Obsolete Transaction".toUpperCase(), resultRemIssueCatDDR1.get("MANDATORY")));
				reqMaster.setManOutputMgmtError(getIssueCatColumnCount("Output Management".toUpperCase(), resultRemIssueCatDDR1.get("MANDATORY")));
				
				reqMaster.setOptCustomCdError(getIssueCatColumnCount("Custom Code".toUpperCase(), resultRemIssueCatDDR1.get("OPTIONAL")));
				reqMaster.setOptDataElementError(getIssueCatColumnCount("Data Element Length Extension".toUpperCase(), resultRemIssueCatDDR1.get("OPTIONAL")));
				reqMaster.setOptStatusTableError(getIssueCatColumnCount("Elimination of Status Tables".toUpperCase(), resultRemIssueCatDDR1.get("OPTIONAL")));
				reqMaster.setOptMatLengthError(getIssueCatColumnCount("Material Length Extension".toUpperCase(), resultRemIssueCatDDR1.get("OPTIONAL")));
				reqMaster.setOptDataModelError(getIssueCatColumnCount("New Data Model".toUpperCase(), resultRemIssueCatDDR1.get("OPTIONAL")));
				reqMaster.setOptNewS4FunError(getIssueCatColumnCount("New S4 Functionality".toUpperCase(), resultRemIssueCatDDR1.get("OPTIONAL")));
				reqMaster.setOptNewTransError(getIssueCatColumnCount("New Transaction".toUpperCase(), resultRemIssueCatDDR1.get("OPTIONAL")));
				reqMaster.setOptRemOrphanError(getIssueCatColumnCount("Removal of Orphened Objects".toUpperCase(), resultRemIssueCatDDR1.get("OPTIONAL")));
				reqMaster.setOptRetiredFunError(getIssueCatColumnCount("Retired Functionality".toUpperCase(), resultRemIssueCatDDR1.get("OPTIONAL")));
				reqMaster.setOptSimpExistTabError(getIssueCatColumnCount("Simplification of Existing Table".toUpperCase(), resultRemIssueCatDDR1.get("OPTIONAL")));
				reqMaster.setOptRepNewFunError(getIssueCatColumnCount("Replaced by new functionality".toUpperCase(), resultRemIssueCatDDR1.get("OPTIONAL")));
				reqMaster.setOptFunEqvAvlError(getIssueCatColumnCount("Functional equivalent available".toUpperCase(), resultRemIssueCatDDR1.get("OPTIONAL")));
				reqMaster.setOptAdaptCustCdError(getIssueCatColumnCount("Custom Code Adaption".toUpperCase(), resultRemIssueCatDDR1.get("OPTIONAL")));
				reqMaster.setOptCustFieldsError(getIssueCatColumnCount("Custom Fields in SAP Tables".toUpperCase(), resultRemIssueCatDDR1.get("OPTIONAL")));
				reqMaster.setOptObsTransError(getIssueCatColumnCount("Obsolete Transaction".toUpperCase(), resultRemIssueCatDDR1.get("OPTIONAL")));
				reqMaster.setOptOutputMgmtError(getIssueCatColumnCount("Output Management".toUpperCase(), resultRemIssueCatDDR1.get("OPTIONAL")));
				
				logger.info("S4 request Master Updated data in fields part2-done"); 
		
			Session session = sessionFactory.openSession();
			try{	
				session.saveOrUpdate(reqMaster);
				session.close();
			}
			catch (Exception e) {
				 e.getMessage();
				throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
			}
		}

		private Integer setErrorUsedUsrrCount(String string, Map<String, Integer> map) {
			// TODO Auto-generated method stub
			return null;
		}

		private Integer setErrorUsedUsreCount(String string, Map<String, Integer> map) {
			// TODO Auto-generated method stub
			return null;
		}

		private Map<String, Map<String, Integer>> getDistinctObjectCountIssueCat(long requestId) {
			final Map<String,Map<String,Integer>> resultMap = new HashMap<String,Map<String,Integer>>();
			Map<String,Integer> usedUnusedMap = null;
			session = sessionFactory.openSession();
			try
			{
				hql = "select distinct issueCategory,used,count(distinct objNameType) from S4HanaProfiler where requestID=:requestID group by issueCategory,used";
			
				Query query = session.createQuery(hql);
				query.setParameter("requestID", requestId);
				
				String unused="N";
				List<Object[]> resultList = query.list();
				String issueCategory;
				if(CollectionUtils.isNotEmpty(resultList))
				{
					for(Object[] object : resultList)
					{
						if(object[0]!=null) {
						issueCategory= ((String) object[0]).trim().toUpperCase();
						
						if(resultMap.containsKey(issueCategory)) {
							usedUnusedMap = resultMap.get(issueCategory);
							if (object[1] == null || ((String) object[1]).equalsIgnoreCase("")) {
								long count = usedUnusedMap.containsKey(unused) ? usedUnusedMap.get(unused) : 0L;
								count += ((Long) object[2]).intValue();
								usedUnusedMap.put(unused, (int) count);
								} else {
									usedUnusedMap.put(((String) object[1]).trim().toUpperCase(), ((Long) object[2]).intValue());

								}
							resultMap.put(issueCategory, usedUnusedMap);
							
						} else {
							usedUnusedMap = new HashMap<String,Integer>();
							if (object[1] == null || ((String) object[1]).equalsIgnoreCase("")) {
								usedUnusedMap.put(unused, (int) ((Long) object[2]).intValue());
								} else {
									usedUnusedMap.put(((String) object[1]).trim().toUpperCase(), ((Long) object[2]).intValue());

								}
							resultMap.put(issueCategory, usedUnusedMap);
						}
						
						resultMap.put(issueCategory, usedUnusedMap);
						}
					}
			}
						
				session.close();}
			catch (Exception e) {
				logger.error("Error !!! " + e);
				}
			return resultMap;	
		}
		
		private Map<String, Map<String, Integer>> getDistinctObjectCountRemidiCat(long requestId) {
			final Map<String,Map<String,Integer>> resultMap = new HashMap<String,Map<String,Integer>>();
			Map<String,Integer> usedUnusedMap = null;
			session = sessionFactory.openSession();
			try
			{
			hql = "select distinct remediationCategory,used,count(distinct objNameType) from S4HanaProfiler where requestID=:requestID group by remediationCategory,used";
			
				Query query = session.createQuery(hql);
				query.setParameter("requestID", requestId);
				
				String unused="N";
				List<Object[]> resultList = query.list();
				String remidiCategory;
				if(CollectionUtils.isNotEmpty(resultList))
				{
					for(Object[] object : resultList)
					{
						if(object[0]!=null) {
						remidiCategory= ((String) object[0]).trim().toUpperCase();
						
						if(resultMap.containsKey(remidiCategory)) {
							usedUnusedMap = resultMap.get(remidiCategory);
							if (object[1] == null || ((String) object[1]).equalsIgnoreCase("")) {
								long count = usedUnusedMap.containsKey(unused) ? usedUnusedMap.get(unused) : 0L;
								count += ((Long) object[2]).intValue();
								usedUnusedMap.put(unused, (int) count);
								} else {
									usedUnusedMap.put(((String) object[1]).trim().toUpperCase(), ((Long) object[2]).intValue());
								}							
						} else {
							usedUnusedMap = new HashMap<String,Integer>();
							if (object[1] == null || ((String) object[1]).equalsIgnoreCase("")) {
								usedUnusedMap.put(unused, (int) ((Long) object[2]).intValue());
								} else {
									usedUnusedMap.put(((String) object[1]).trim().toUpperCase(), ((Long) object[2]).intValue());

								}
						}
						
						resultMap.put(remidiCategory, usedUnusedMap);
						}
					}
				}
				session.close();
			} catch (Exception e) {
				logger.error("Error !!! " + e);
			}
			return resultMap;	
		}

		@Override
		public List<UI5FinalOutput> getUI5FinalOutputList(long requestID) {
			session=sessionFactory.openSession();

			try{
				final Criteria criteria=session.createCriteria(UI5FinalOutput.class);
				criteria.add(Restrictions.eq("REQUEST_ID", requestID));
				return criteria.list();
			}catch(Exception e){
				logger.error("Error !!! " + e);
				throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
			}finally{
				if(null != session){
					session.close();
				}
			}
		}
		
		@Override
		public List<UI5HighLevelReport> getUI5HighLevelReportList(long requestID) {
			session=sessionFactory.openSession();

			try{
				final Criteria criteria=session.createCriteria(UI5HighLevelReport.class);
				criteria.add(Restrictions.eq("REQUEST_ID", requestID));
				return criteria.list();
			}catch(Exception e){
				logger.error("Error !!! " + e);
				throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
			}finally{
				if(null != session){
					session.close();
				}
			}
		}
		
		@Override
		public List<ImpactedBackgroundJob_Download> getImpactedBackgroundJob(long requestID) {
			session=sessionFactory.openSession();

			try{
				final Criteria criteria=session.createCriteria(ImpactedBackgroundJob_Download.class);
				criteria.add(Restrictions.eq("requestId", requestID));
				return criteria.list();
			}catch(Exception e){
				logger.error("Error !!! " + e);
				throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
			}finally{
				if(null != session){
					session.close();
				}
			}
		}
		
		@SuppressWarnings("unchecked")
		@Override
		public List<SmodilogFunction_Download> getSmodilogData(long requestID) {
			session=sessionFactory.openSession();

			try{
				final Criteria criteria=session.createCriteria(SmodilogFunction_Download.class);
				criteria.add(Restrictions.eq("requestId", requestID));
				logger.info("Inside getSmodilogData method List Size FRom Database Table Is........."+criteria.list().size());
				return criteria.list();
			}catch(Exception e){
				logger.error("Error !!! " + e);
				throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
			}finally{
				if(null != session)
					session.close();
			}

		}
		
}
