package com.accenture.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "Sa_New_Objects_Intermediate")
public class SaNewObjectsIntermediate {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Id")
	private int id;
	
	@Index(name="Index_Request_id")
	@Column(name = "Request_ID")
	private Integer requestId;
	
	@Index(name="Index_Contact")
	@Column(name = "concat")
	private String concat;
	
	@Column(name = "Proposed" ,columnDefinition="LONGTEXT")
	private String proposed;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Integer getRequestId() {
		return requestId;
	}

	public void setRequestId(Integer requestId) {
		this.requestId = requestId;
	}

	public String getConcat() {
		return concat;
	}

	public void setConcat(String concat) {
		this.concat = concat;
	}

	public String getProposed() {
		return proposed;
	}

	public void setProposed(String proposed) {
		this.proposed = proposed;
	}
}
