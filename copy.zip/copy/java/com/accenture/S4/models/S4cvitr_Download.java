/*CR-No.    Desc     Date    Modified By
 * 
 * CR-26.0:- Make changes for Op-Code & show total scanned lines -05/09/17 -monika.mishra
 * 
 * 
 * */

package com.accenture.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * @author sankhamala.a.pal
 *
 */
@Entity
@Table(name="S4_CVITR_DOWNLOAD")
public class S4cvitr_Download {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="Id")
	private int id;
	
	@Column(name="REQUEST_ID")
	private long requestID;

	@Column(name="IDENTIFIER")
	private String identifier;
	
	@Column(name="SELECT_LINE")
	private String selectLine;

	@Column(name="COMMENT_C",length=500)
	private String commentC;
	
	@Column(name="COMMENTS",length=500)
	private String comments;
	
	@Column(name="VENDOR_EXTERNAL")
	private String vendorExt;
	
	@Column(name="CUSTOMER_EXTERNAL")
	private String customerExt;


	public String getVendorExt() {
		return vendorExt;
	}

	public void setVendorExt(String vendorExt) {
		this.vendorExt = vendorExt;
	}

	public String getCustomerExt() {
		return customerExt;
	}

	public void setCustomerExt(String customerExt) {
		this.customerExt = customerExt;
	}

	@Column(name="NEW_LINE",length=500)
	private String newLine;
	
	public String getNewLine() {
		return newLine;
	}

	public void setNewLine(String newLine) {
		this.newLine = newLine;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public long getRequestID() {
		return requestID;
	}

	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}

	public String getIdentifier() {
		return identifier;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	public String getSelectLine() {
		return selectLine;
	}

	public void setSelectLine(String selectLine) {
		this.selectLine = selectLine;
	}

	public String getCommentC() {
		return commentC;
	}

	public void setCommentC(String commentC) {
		this.commentC = commentC;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}
	
	

}
