package com.accenture.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

/**
 * @author monika.mishra
 *
 */
@Entity
@Table(name="S4_Clone_Prog_Analysis")
public class S4CloneProg {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ID")
	private int id;
	
	
	@Column(name="Impacted_Prog")
	private String impactedProg;
	
	@Column(name="Clone_prog")
	private String cloneProg;
	
	@Column(name="Description")
	private String desc;
	
	@Column(name="Solution_Step",length=500)
	private String solStep;
	
	@Column(name="Related_Notes")
	private String relatedNotes;
	
	@Index(name="Index_Request_id")
	@Column(name="REQUEST_ID")
	private long requestID;


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getImpactedProg() {
		return impactedProg;
	}

	public void setImpactedProg(String impactedProg) {
		this.impactedProg = impactedProg;
	}

	public String getCloneProg() {
		return cloneProg;
	}

	public void setCloneProg(String cloneProg) {
		this.cloneProg = cloneProg;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getSolStep() {
		return solStep;
	}

	public void setSolStep(String solStep) {
		this.solStep = solStep;
	}

	public String getRelatedNotes() {
		return relatedNotes;
	}

	public void setRelatedNotes(String relatedNotes) {
		this.relatedNotes = relatedNotes;
	}

	public long getRequestID() {
		return requestID;
	}

	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}

	

}
