package com.accenture.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

/**
 * @author rohan.a.mehra
 *
 */
@Entity
@Table(name="S4_Append_Structure_Download")
public class S4AppendStructureAnalysis_Download {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ID")
	private int id;
	
	@Column(name="TABLE_NAME")
	private String tableName;
	
	@Column(name="FIELD_NAME")
	private String fieldName;
	
	@Column(name="NAME_OF_INCLUDE")
	private String nameOfInclude;
	
	@Index(name="Index_Request_id")
	@Column(name="REQUEST_ID")
	private long requestID;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getNameOfInclude() {
		return nameOfInclude;
	}

	public void setNameOfInclude(String nameOfInclude) {
		this.nameOfInclude = nameOfInclude;
	}

	public long getRequestId() {
		return requestID;
	}

	public void setRequestId(long requestId) {
		this.requestID = requestId;
	}

}
