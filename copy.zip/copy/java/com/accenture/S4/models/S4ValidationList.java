package com.accenture.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="S4_VALIDATION_DATA")
public class S4ValidationList {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID")
	private int id;
	
	@Column(name="Identifier")
	private String identifier;
	
	@Column(name="Version")
	private String version;
	
	@Column(name="Valid_To")
	private String validTo;
	
	@Column(name="Object")
	private String object;
	
	@Column(name="Sub_Object")
	private String subObject;
	
	@Column(name="Object_Type")
	private String objectType;
	
	@Column(name="Program_Name")
	private String programName;
	
	@Column(name="Screen")
	private String screen;
	
	@Column(name="Obsolete" )
	private String obsolete;
	
	@Column(name="New_Len")
	private String new_Len;
	
	@Column(name="Affected_Area")
	private String affectedArea;
	
	@Column(name="Details")
	private String details;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getIdentifier() {
		return identifier;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getObject() {
		return object;
	}

	public void setObject(String object) {
		this.object = object;
	}

	public String getSubObject() {
		return subObject;
	}

	public void setSubObject(String subObject) {
		this.subObject = subObject;
	}

	public String getObjectType() {
		return objectType;
	}

	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}

	public String getProgramName() {
		return programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}

	public String getScreen() {
		return screen;
	}

	public void setScreen(String screen) {
		this.screen = screen;
	}

	public String getObsolete() {
		return obsolete;
	}

	public void setObsolete(String obsolete) {
		this.obsolete = obsolete;
	}

	public String getNew_Len() {
		return new_Len;
	}

	public void setNew_Len(String new_Len) {
		this.new_Len = new_Len;
	}

	public String getAffectedArea() {
		return affectedArea;
	}

	public void setAffectedArea(String affectedArea) {
		this.affectedArea = affectedArea;
	}

	public String getValidTo() {
		return validTo;
	}

	public void setValidTo(String validTo) {
		this.validTo = validTo;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}
	
	
}
