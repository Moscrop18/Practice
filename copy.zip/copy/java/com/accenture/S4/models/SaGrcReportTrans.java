package com.accenture.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "sa_grc_report_trans")
public class SaGrcReportTrans {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Id")
	private int id;
	
	@Column(name = "Cli_Mandt")
	private String cliMandt;
	
	@Column(name = "Cli_FunctId")
	private String cliFunctId;
	
	@Column(name = "Cli_Action")
	private String cliAction;
	
	@Column(name = "Cli_Connector")
	private String cliConnector;
	
	@Column(name = "Mast_FunctId")
	private String mastFunctId;
	
	@Column(name = "Mast_Action")
	private String mastAction;
	
	@Column(name = "Mast_Connector")
	private String mastConnector;
	
	@Column(name = "New_Proposed_Actions_for_CF")
	private String newProposedActionsforCF;
	
	@Column(name = "Status")
	private String status;
	
	@Column(name = "Connector_Name")
	private String connectorName;
	
	@Column(name = "Request_Id")
	private Long requestID;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCliMandt() {
		return cliMandt;
	}

	public void setCliMandt(String cliMandt) {
		this.cliMandt = cliMandt;
	}

	public String getCliFunctId() {
		return cliFunctId;
	}

	public void setCliFunctId(String cliFunctId) {
		this.cliFunctId = cliFunctId;
	}

	public String getCliAction() {
		return cliAction;
	}

	public void setCliAction(String cliAction) {
		this.cliAction = cliAction;
	}

	public String getCliConnector() {
		return cliConnector;
	}

	public void setCliConnector(String cliConnector) {
		this.cliConnector = cliConnector;
	}

	public String getMastFunctId() {
		return mastFunctId;
	}

	public void setMastFunctId(String mastFunctId) {
		this.mastFunctId = mastFunctId;
	}

	public String getMastAction() {
		return mastAction;
	}

	public void setMastAction(String mastAction) {
		this.mastAction = mastAction;
	}

	public String getMastConnector() {
		return mastConnector;
	}

	public void setMastConnector(String mastConnector) {
		this.mastConnector = mastConnector;
	}

	public String getNewProposedActionsforCF() {
		return newProposedActionsforCF;
	}

	public void setNewProposedActionsforCF(String newProposedActionsforCF) {
		this.newProposedActionsforCF = newProposedActionsforCF;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getConnectorName() {
		return connectorName;
	}

	public void setConnectorName(String connectorName) {
		this.connectorName = connectorName;
	}

	public Long getRequestID() {
		return requestID;
	}

	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}

	
}
