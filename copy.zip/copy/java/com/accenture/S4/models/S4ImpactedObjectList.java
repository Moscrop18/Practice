package com.accenture.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

/**
 * @author monika.mishra
 *
 */

@Entity
@Table(name="S4_Impact_Obj_List")
public class S4ImpactedObjectList {
	
		@Id
		@GeneratedValue(strategy=GenerationType.AUTO)
		@Column(name="ID")
		private int id;
		
		@Column(name="OBJ_TYPE")
		private String objType;
		
		@Column(name="OBJ_NAME")
		private String objName;
		
		@Column(name="Used")
		private String used; 

		@Column(name="REQUEST_ID")
		@Index(name="Index_Request_id")
		private long requestID;
		

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getObjType() {
			return objType;
		}

		public void setObjType(String objType) {
			this.objType = objType;
		}

		public String getObjName() {
			return objName;
		}

		public void setObjName(String objName) {
			this.objName = objName;
		}

		public String getUsage() {
			return used;
		}

		public void setUsage(String usage) {
			this.used = usage;
		}

		public long getRequestID() {
			return requestID;
		}

		public void setRequestID(long requestID) {
			this.requestID = requestID;
		}

	


}
