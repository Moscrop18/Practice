package com.accenture.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

/**
 * @author monika.mishra
 *
 */
@Entity
@Table(name="S4_Simplification_Database")
public class S4SimplificationDatabase {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID")
	private int id;
	
	@Column(name="S4_Hana_Changes")
	private String s4HANAChanges;
	
	@Column(name="Object",length=500)
	private String object;
	
	@Column(name="Object_Type")
	private String objectType;
	
	@Column(name="Obsolete")
	private String obsolete;
	
	@Column(name="Description", columnDefinition = "LONGTEXT")
	private String description;
	
	@Column(name="Affected_Area")
	private String affectedArea;
	
	@Column(name="Related_Notes")
	private String relatedNotes;
	
	@Column(name="Solution_Steps" ,length=500)
	private String solutionSteps;
	
	@Column(name="Err_Category")
	private String errCategory;
	
	@Column(name="Version")
	private String version;
	
	@Column(name="Identifier")
	@Index(name="Identifier")
	private String identifier;
	
	@Column(name="Err_Category_Numeric")
	private String errCategoryNumeric;
	
	@Column(name="Complexity")
	private String complexity;
	
	@Column(name="Issue_Catgry")
	private String issueCatgry;
	
	@Column(name="Trigger_Obj")
	private String triggerObj;
		
	@Column(name="Remediation_Catgry")
	private String remediationCatgry;
	
	@Column(name="Sap_Simpl_List_Chaptr")
	private String sapSimplListChaptr;
	
	@Column(name="App_Comp")
	private String appComponent;
	
	@Column(name="Sap_Simpl_Catry")
	private String sapSimplCatry;
	
	@Column(name="Itm_Area")
	private String itm_Area;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getS4HANAChanges() {
		return s4HANAChanges;
	}

	public void setS4HANAChanges(String s4hanaChanges) {
		s4HANAChanges = s4hanaChanges;
	}

	public String getObject() {
		return object;
	}

	public void setObject(String object) {
		this.object = object;
	}

	public String getObjectType() {
		return objectType;
	}

	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}

	public String getObsolete() {
		return obsolete;
	}

	public void setObsolete(String obsolete) {
		this.obsolete = obsolete;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getAffectedArea() {
		return affectedArea;
	}

	public void setAffectedArea(String affectedArea) {
		this.affectedArea = affectedArea;
	}

	public String getRelatedNotes() {
		return relatedNotes;
	}

	public void setRelatedNotes(String relatedNotes) {
		this.relatedNotes = relatedNotes;
	}

	public String getSolutionSteps() {
		return solutionSteps;
	}

	public void setSolutionSteps(String solutionSteps) {
		this.solutionSteps = solutionSteps;
	}

	public String getErrCategory() {
		return errCategory;
	}

	public void setErrCategory(String errCategory) {
		this.errCategory = errCategory;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getIdentifier() {
		return identifier;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	public String getErrCategoryNumeric() {
		return errCategoryNumeric;
	}

	public void setErrCategoryNumeric(String errCategoryNumeric) {
		this.errCategoryNumeric = errCategoryNumeric;
	}

	public String getComplexity() {
		return complexity;
	}

	public void setComplexity(String complexity) {
		this.complexity = complexity;
	}

	public String getIssueCatgry() {
		return issueCatgry;
	}

	public void setIssueCatgry(String issueCatgry) {
		this.issueCatgry = issueCatgry;
	}

	public String getTriggerObj() {
		return triggerObj;
	}

	public void setTriggerObj(String triggerObj) {
		this.triggerObj = triggerObj;
	}

	public String getRemediationCatgry() {
		return remediationCatgry;
	}

	public void setRemediationCatgry(String remediationCatgry) {
		this.remediationCatgry = remediationCatgry;
	}

	public String getSapSimplListChaptr() {
		return sapSimplListChaptr;
	}

	public void setSapSimplListChaptr(String sapSimplListChaptr) {
		this.sapSimplListChaptr = sapSimplListChaptr;
	}

	public String getAppComponent() {
		return appComponent;
	}

	public void setAppComponent(String appComponent) {
		this.appComponent = appComponent;
	}

	public String getSapSimplCatry() {
		return sapSimplCatry;
	}

	public void setSapSimplCatry(String sapSimplCatry) {
		this.sapSimplCatry = sapSimplCatry;
	}

	public String getItm_Area() {
		return itm_Area;
	}

	public void setItm_Area(String itm_Area) {
		this.itm_Area = itm_Area;
	}
}
