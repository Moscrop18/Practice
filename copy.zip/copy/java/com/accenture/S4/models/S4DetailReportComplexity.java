package com.accenture.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

/**
 * @author monika.mishra
 *
 */
@Entity
@Table(name="s4_Detail_Report")
public class S4DetailReportComplexity {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ID")
	private int id;

	@Column(name="OBJ_NAME")
	private String objName;

	@Column(name="SUB_OBJ")
	private String subObject;

	@Column(name="METHOD")
	private String method;

	@Column(name="PCKG")
	private String pckg;

	@Column(name="USED")
	private String used;

	@Column(name="OBJ_TYPE")
	private String type;

	@Column(name="IMPACTED_OBJ_TYPE")
	private String impactedObjType;

	@Column(name="LINE_NO")
	private int lineNo;

	@Column(name="STMT" ,length=500)
	private String stmt;

	@Column(name="OPERATIONS")
	private String operations;

	@Column(name="IMPACT_REASON",length=500)
	private String impactReason;

	@Column(name="AFFECT_OBJ_DESC" ,columnDefinition = "LONGTEXT")
	private String affectObjDesc;

	@Column(name="DESC_OF_CHANGE",length=500)
	private String descOfChange;

	@Column(name="SAP_NOTES")
	private String sapNotes;

	@Column(name="SOLUTION_STEPS",length=500)
	private String solutionSteps;

	@Column(name="COMPLEXITY")
	private String complexity;

	@Column(name="ISSUE_CATEGORY")
	private String issueCategory;

	@Column(name="ERROR_CATEGORY")
	private String errorCategory;

	@Column(name="TRIGGER_OBJ")
	private String triggerObj;

	@Column(name="SAP_SIMP_LIST")
	private String sapSimpListChapter;

	@Column(name="APP_COMPONENT")
	private String applicationComponent;

	@Column(name="SAP_SIMPL_CATEGORY")
	private String sapSimplCategry;

	@Column(name="ITEM_AREA")
	private String itemArea;
	
	@Column(name="Remediation_Category")
	private String remediationCategory;
	
	@Column(name="IDENTIFIER")
	private String identifier;
	
	@Column(name="REQUEST_ID")
	@Index(name="Index_Request_id")
	private long requestID;
	
	@Column(name="OBJ_NAME_TYPE")
	private String objNameType;

	public String getObjNameType() {
		return objNameType;
	}

	public void setObjNameType(String objNameType) {
		this.objNameType = objNameType;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}

	public String getSubObject() {
		return subObject;
	}

	public void setSubObject(String subObject) {
		this.subObject = subObject;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public String getPckg() {
		return pckg;
	}

	public void setPckg(String pckg) {
		this.pckg = pckg;
	}

	public String getUsed() {
		return used;
	}

	public void setUsed(String used) {
		this.used = used;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getImpactedObjType() {
		return impactedObjType;
	}

	public void setImpactedObjType(String impactedObjType) {
		this.impactedObjType = impactedObjType;
	}

	public int getLineNo() {
		return lineNo;
	}

	public void setLineNo(int lineNo) {
		this.lineNo = lineNo;
	}

	public String getStmt() {
		return stmt;
	}

	public void setStmt(String stmt) {
		this.stmt = stmt;
	}

	public String getOperations() {
		return operations;
	}

	public void setOperations(String operations) {
		this.operations = operations;
	}

	public String getImpactReason() {
		return impactReason;
	}

	public void setImpactReason(String impactReason) {
		this.impactReason = impactReason;
	}

	public String getAffectObjDesc() {
		return affectObjDesc;
	}

	public void setAffectObjDesc(String affectObjDesc) {
		this.affectObjDesc = affectObjDesc;
	}

	public String getDescOfChange() {
		return descOfChange;
	}

	public void setDescOfChange(String descOfChange) {
		this.descOfChange = descOfChange;
	}

	public String getSapNotes() {
		return sapNotes;
	}

	public void setSapNotes(String sapNotes) {
		this.sapNotes = sapNotes;
	}

	public String getSolutionSteps() {
		return solutionSteps;
	}

	public void setSolutionSteps(String solutionSteps) {
		this.solutionSteps = solutionSteps;
	}

	public String getComplexity() {
		return complexity;
	}

	public void setComplexity(String complexity) {
		this.complexity = complexity;
	}

	public String getIssueCategory() {
		return issueCategory;
	}

	public void setIssueCategory(String issueCategory) {
		this.issueCategory = issueCategory;
	}

	public String getErrorCategory() {
		return errorCategory;
	}

	public void setErrorCategory(String errorCategory) {
		this.errorCategory = errorCategory;
	}

	public String getTriggerObj() {
		return triggerObj;
	}

	public void setTriggerObj(String triggerObj) {
		this.triggerObj = triggerObj;
	}

	public String getSapSimpListChapter() {
		return sapSimpListChapter;
	}

	public void setSapSimpListChapter(String sapSimpListChapter) {
		this.sapSimpListChapter = sapSimpListChapter;
	}

	public String getApplicationComponent() {
		return applicationComponent;
	}

	public void setApplicationComponent(String applicationComponent) {
		this.applicationComponent = applicationComponent;
	}

	public String getSapSimplCategry() {
		return sapSimplCategry;
	}

	public void setSapSimplCategry(String sapSimplCategry) {
		this.sapSimplCategry = sapSimplCategry;
	}

	public String getItemArea() {
		return itemArea;
	}

	public void setItemArea(String itemArea) {
		this.itemArea = itemArea;
	}

	public long getRequestId() {
		return requestID;
	}

	public void setRequestId(long requestId) {
		this.requestID = requestId;
	}

	public String getIdentifier() {
		return identifier;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	public String getRemediationCategory() {
		return remediationCategory;
	}

	public void setRemediationCategory(String remediationCategory) {
		this.remediationCategory = remediationCategory;
	}

}
