package com.accenture.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Src_AgrUsers")
public class SrcAgrUsers {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Id")
	private int id;
	
	@Column(name="MANDT")
	private String mandt;
	
	@Column(name="Role")
	private String role;
	
	@Column(name="User_Name")
	private String userName;
	
	@Column(name="From_Date")
	private String fromDat;
	
	@Column(name="To_Date")
	private String toDat;
	
	@Column(name="Exclude")
	private String exclude;
	
	@Column(name="Change_Date")
	private String changeDat;
	
	@Column(name="Change_Time")
	private String changeTim;
	
	@Column(name="Change_Tst")
	private String changeTst;
	
	@Column(name="Org_Flag")
	private String orgFlag;
	
	@Column(name="Col_Flag")
	private String colFlag;

	@Column(name="Request_Id")
	private Integer requestID;
	
	public int getId() {
		return id;
	}

	public Integer getRequestID() {
		return requestID;
	}

	public void setRequestID(Integer requestID) {
		this.requestID = requestID;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMandt() {
		return mandt;
	}

	public void setMandt(String mandt) {
		this.mandt = mandt;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getFromDat() {
		return fromDat;
	}

	public void setFromDat(String fromDat) {
		this.fromDat = fromDat;
	}

	public String getToDat() {
		return toDat;
	}

	public void setToDat(String toDat) {
		this.toDat = toDat;
	}

	public String getExclude() {
		return exclude;
	}

	public void setExclude(String exclude) {
		this.exclude = exclude;
	}

	public String getChangeDat() {
		return changeDat;
	}

	public void setChangeDat(String changeDat) {
		this.changeDat = changeDat;
	}

	public String getChangeTim() {
		return changeTim;
	}

	public void setChangeTim(String changeTim) {
		this.changeTim = changeTim;
	}

	public String getChangeTst() {
		return changeTst;
	}

	public void setChangeTst(String changeTst) {
		this.changeTst = changeTst;
	}

	public String getOrgFlag() {
		return orgFlag;
	}

	public void setOrgFlag(String orgFlag) {
		this.orgFlag = orgFlag;
	}

	public String getColFlag() {
		return colFlag;
	}

	public void setColFlag(String colFlag) {
		this.colFlag = colFlag;
	}
	
}
