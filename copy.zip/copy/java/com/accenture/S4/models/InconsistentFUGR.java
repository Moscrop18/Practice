package com.accenture.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Inconsitent_FUGR")
public class InconsistentFUGR {
	
	private int id;
	private long requestId;
	private String objectType;
	private String fugrName;
	private String masterProgram;
	private String externalNamespace;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "ID")
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	@Column(name = "Request_ID")
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	
	@Column(name = "Object_Type")
	public String getObjectType() {
		return objectType;
	}
	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}
	
	@Column(name = "FUGR_Name")
	public String getFugrName() {
		return fugrName;
	}
	public void setFugrName(String fugrName) {
		this.fugrName = fugrName;
	}
	
	@Column(name="Master_Program", columnDefinition = "TEXT")
	public String getMasterProgram() {
		return masterProgram;
	}
	public void setMasterProgram(String masterProgram) {
		this.masterProgram = masterProgram;
	}
	
	@Column(name="External_Namespace")
	public String getExternalNamespace() {
		return externalNamespace;
	}
	public void setExternalNamespace(String externalNamespace) {
		this.externalNamespace = externalNamespace;
	}
	
	
}
