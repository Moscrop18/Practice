package com.accenture.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="TCD_MasterData")
public class TCDSimplification {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID")
	private int id;
	/*Old
	NewTcode
	functional_area
	referance
	targetVersion*/

	@Column(name="OldTcode")
	private String old;
	
	@Column(name="NewTcode")
	private String newTcode;
	
	@Column(name="Functional_Area")
	private String functionalArea;
	
	@Column(name="Reference")
	private String reference;
	
	@Column(name="TargetVersion")
	private String targetVersion;
	
	@Column(name="FioriID_OldTcode")
	private String fioriIdOldTcode;
	
	@Column(name="AppName_OldTcode")
	private String appNameOldTcode;
	
	@Column(name="ApplicationType_OldTcode")
	private String appTypeOldTcode;
	
	@Column(name="FrontendProductVersion_OldTcode")
	private String frntEndPrdVerOldTcode;
	
	@Column(name="ProductVersionNameBackend_OldTcode")
	private String prdVerNameBckEndOldTcode;
	
	@Column(name="PrimaryODataServiceName_OldTcode")
	private String priOdataSerNameOldTcode;
	
	@Column(name="AdditionalODataServices_OldTcode", columnDefinition="TEXT")
	private String addOdataSerOldTcode;
	
	@Column(name="WDAConfiguration_OldTcode")
	private String wdaConfOldTcode;
	
	@Column(name="FioriID_NewTcode")
	private String fioriIdNewTcode;
	
	@Column(name="AppName_NewTcode")
	private String appNameNewTcode;
	
	@Column(name="ApplicationType_NewTcode")
	private String appTypeNewTcode;
	
	@Column(name="FrontendProductVersion_NewTcode")
	private String frntEndPrdVerNewTcode;
	
	@Column(name="ProductVersionNameBackend_NewTcode")
	private String prdVerNameBckEndNewTcode;
	
	@Column(name="PrimaryODataServiceName_NewTcode")
	private String priOdataSerNameNewTcode;
	
	@Column(name="AdditionalODataServices_NewTcode")
	private String addOdataSerNewTcode;
	
	@Column(name="WDAConfiguration_NewTcode")
	private String wdaConfNewTcode;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getOld() {
		return old;
	}

	public void setOld(String old) {
		this.old = old;
	}

	public String getNewTcode() {
		return newTcode;
	}

	public void setNewTcode(String newTcode) {
		this.newTcode = newTcode;
	}

	public String getFunctionalArea() {
		return functionalArea;
	}

	public void setFunctionalArea(String functionalArea) {
		this.functionalArea = functionalArea;
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	public String getTargetVersion() {
		return targetVersion;
	}

	public void setTargetVersion(String targetVersion) {
		this.targetVersion = targetVersion;
	}

	public String getFioriIdOldTcode() {
		return fioriIdOldTcode;
	}

	public void setFioriIdOldTcode(String fioriIdOldTcode) {
		this.fioriIdOldTcode = fioriIdOldTcode;
	}

	public String getAppNameOldTcode() {
		return appNameOldTcode;
	}

	public void setAppNameOldTcode(String appNameOldTcode) {
		this.appNameOldTcode = appNameOldTcode;
	}

	public String getAppTypeOldTcode() {
		return appTypeOldTcode;
	}

	public void setAppTypeOldTcode(String appTypeOldTcode) {
		this.appTypeOldTcode = appTypeOldTcode;
	}

	public String getFrntEndPrdVerOldTcode() {
		return frntEndPrdVerOldTcode;
	}

	public void setFrntEndPrdVerOldTcode(String frntEndPrdVerOldTcode) {
		this.frntEndPrdVerOldTcode = frntEndPrdVerOldTcode;
	}

	public String getPrdVerNameBckEndOldTcode() {
		return prdVerNameBckEndOldTcode;
	}

	public void setPrdVerNameBckEndOldTcode(String prdVerNameBckEndOldTcode) {
		this.prdVerNameBckEndOldTcode = prdVerNameBckEndOldTcode;
	}

	public String getPriOdataSerNameOldTcode() {
		return priOdataSerNameOldTcode;
	}

	public void setPriOdataSerNameOldTcode(String priOdataSerNameOldTcode) {
		this.priOdataSerNameOldTcode = priOdataSerNameOldTcode;
	}

	public String getAddOdataSerOldTcode() {
		return addOdataSerOldTcode;
	}

	public void setAddOdataSerOldTcode(String addOdataSerOldTcode) {
		this.addOdataSerOldTcode = addOdataSerOldTcode;
	}

	public String getWdaConfOldTcode() {
		return wdaConfOldTcode;
	}

	public void setWdaConfOldTcode(String wdaConfOldTcode) {
		this.wdaConfOldTcode = wdaConfOldTcode;
	}

	public String getFioriIdNewTcode() {
		return fioriIdNewTcode;
	}

	public void setFioriIdNewTcode(String fioriIdNewTcode) {
		this.fioriIdNewTcode = fioriIdNewTcode;
	}

	public String getAppNameNewTcode() {
		return appNameNewTcode;
	}

	public void setAppNameNewTcode(String appNameNewTcode) {
		this.appNameNewTcode = appNameNewTcode;
	}

	public String getAppTypeNewTcode() {
		return appTypeNewTcode;
	}

	public void setAppTypeNewTcode(String appTypeNewTcode) {
		this.appTypeNewTcode = appTypeNewTcode;
	}

	public String getFrntEndPrdVerNewTcode() {
		return frntEndPrdVerNewTcode;
	}

	public void setFrntEndPrdVerNewTcode(String frntEndPrdVerNewTcode) {
		this.frntEndPrdVerNewTcode = frntEndPrdVerNewTcode;
	}

	public String getPrdVerNameBckEndNewTcode() {
		return prdVerNameBckEndNewTcode;
	}

	public void setPrdVerNameBckEndNewTcode(String prdVerNameBckEndNewTcode) {
		this.prdVerNameBckEndNewTcode = prdVerNameBckEndNewTcode;
	}

	public String getPriOdataSerNameNewTcode() {
		return priOdataSerNameNewTcode;
	}

	public void setPriOdataSerNameNewTcode(String priOdataSerNameNewTcode) {
		this.priOdataSerNameNewTcode = priOdataSerNameNewTcode;
	}

	public String getAddOdataSerNewTcode() {
		return addOdataSerNewTcode;
	}

	public void setAddOdataSerNewTcode(String addOdataSerNewTcode) {
		this.addOdataSerNewTcode = addOdataSerNewTcode;
	}

	public String getWdaConfNewTcode() {
		return wdaConfNewTcode;
	}

	public void setWdaConfNewTcode(String wdaConfNewTcode) {
		this.wdaConfNewTcode = wdaConfNewTcode;
	}
	
}
