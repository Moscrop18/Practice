package com.accenture.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

/**
 * @author monika.mishra
 *
 */
@Entity
@Table(name="S4_Estimations")
public class S4Estimations {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ID")
	private int id;
	
	
		//Mandatory Estimations-low
		@Column(name="Mandatory_Analysis_Efforts_Low")
		private int MandatoryAnalysisEffortsLow;
		
		@Column(name="Mandatory_Design_Efforts_Low")
		private int MandatoryDesignEffortsLow;
		
		@Column(name="Mandatory_Build_Efforts_Low")
		private int MandatoryBuildEffortsLow;
		
		@Column(name="Mandatory_Unit_Testing_Low")
		private int MandatoryUnitTestingLow;
		
		@Column(name="Mandatory_Effort_Remediate_Custom_Low")
		private int MandatoryEffortRemediateCustomLow;
		
		@Column(name="Mandatory_SPDD_SPAU_Efforts_Low")
		private int MandatorySPDD_SPAU_EffortsLow;	
		
		//Mandatory Used Estimations-low 	
		@Column(name="Mandatory_Used_Analysis_Efforts_Low")
		private int MandatoryUsedAnalysisEffortsLow;
		
		@Column(name="Mandatory_Used_Design_Efforts_Low")
		private int MandatoryUsedDesignEffortsLow;
		
		@Column(name="Mandatory_Used_Build_Efforts_Low")
		private int MandatoryUsedBuildEffortsLow;
		
		@Column(name="Mandatory_Used_Unit_Testing_Low")
		private int MandatoryUsedUnitTestingLow;
		
		@Column(name="Mandatory_Used_Effort_Remediate_Custom_Low")
		private int MandatoryUsedEffortRemediateCustomLow;
		
		@Column(name="Mandatory_Used_SPDD_SPAU_Efforts_Low")
		private int MandatoryUsedSPDD_SPAU_EffortsLow;	
		
		//Optional Estimations-low
		@Column(name="Optional_Analysis_Efforts_Low")
		private int OptionalAnalysisEffortsLow;
		
		@Column(name="Optional_Design_Efforts_Low")
		private int OptionalDesignEffortsLow;

		@Column(name="Optional_Build_Efforts_Low")
		private int OptionalBuildEffortsLow;

		@Column(name="Optional_Unit_Testing_Low")
		private int OptionalUnitTestingLow;
		
		@Column(name="Optional_Effort_Remediate_Custom_Low")
		private int OptionalEffortRemediateCustomLow;
		
		@Column(name="Optional_SPDD_SPAU_Efforts_Low")
		private int OptionalSPDD_SPAU_EffortsLow;	
		

		//Optional Used Estimations-low
		@Column(name="Optional_Used_Analysis_Efforts_Low")
		private int OptionalUsedAnalysisEffortsLow;
		
		@Column(name="Optional_Used_Design_Efforts_Low")
		private int OptionalUsedDesignEffortsLow;
		
		@Column(name="Optional_Used_Build_Efforts_Low")
		private int OptionalUsedBuildEffortsLow;
		
		@Column(name="Optional_Used_Unit_Testing_Low")
		private int OptionalUsedUnitTestingLow;
		
		@Column(name="Optional_Used_Effort_Remediate_Custom_Low")
		private int OptionalUsedEffortRemediateCustomLow;
		
		@Column(name="Optional_Used_SPDD_SPAU_Efforts_Low")
		private int OptionalUsedSPDD_SPAU_EffortsLow;	
	
	
		//Mandatory Estimations-high
		@Column(name="Mandatory_Analysis_Efforts_High")
		private int MandatoryAnalysisEffortsHigh;
		
		@Column(name="Mandatory_Design_Efforts_High")
		private int MandatoryDesignEffortsHigh;
		
		@Column(name="Mandatory_Build_Efforts_High")
		private int MandatoryBuildEffortsHigh;
		
		@Column(name="Mandatory_Unit_Testing_High")
		private int MandatoryUnitTestingHigh;
		
		@Column(name="Mandatory_Effort_Remediate_Custom_High")
		private int MandatoryEffortRemediateCustomHigh;
		
		@Column(name="Mandatory_SPDD_SPAU_Efforts_High")
		private int MandatorySPDD_SPAU_EffortsHigh;	
		
		//Mandatory Used Estimations-high	
		@Column(name="Mandatory_Used_Analysis_Efforts_High")
		private int MandatoryUsedAnalysisEffortsHigh;
		
		@Column(name="Mandatory_Used_Design_Efforts_High")
		private int MandatoryUsedDesignEffortsHigh;
		
		@Column(name="Mandatory_Used_Build_Efforts_High")
		private int MandatoryUsedBuildEffortsHigh;
		
		@Column(name="Mandatory_Used_Unit_Testing_High")
		private int MandatoryUsedUnitTestingHigh;
		
		@Column(name="Mandatory_Used_Effort_Remediate_Custom_High")
		private int MandatoryUsedEffortRemediateCustomHigh;
		
		@Column(name="Mandatory_Used_SPDD_SPAU_Efforts_High")
		private int MandatoryUsedSPDD_SPAU_EffortsHigh;	
		
		//Optional Estimations-high
		@Column(name="Optional_Analysis_Efforts_High")
		private int OptionalAnalysisEffortsHigh;
		
		@Column(name="Optional_Design_Efforts_High")
		private int OptionalDesignEffortsHigh;
	
		@Column(name="Optional_Build_Efforts_High")
		private int OptionalBuildEffortsHigh;
	
		@Column(name="Optional_Unit_Testing_High")
		private int OptionalUnitTestingHigh;
		
		@Column(name="Optional_Effort_Remediate_Custom_High")
		private int OptionalEffortRemediateCustomHigh;
		
		@Column(name="Optional_SPDD_SPAU_Efforts_High")
		private int OptionalSPDD_SPAU_EffortsHigh;	
		
	
		//Optional Used Estimations-high
		@Column(name="Optional_Used_Analysis_Efforts_High")
		private int OptionalUsedAnalysisEffortsHigh;
		
		@Column(name="Optional_Used_Design_Efforts_High")
		private int OptionalUsedDesignEffortsHigh;
		
		@Column(name="Optional_Used_Build_Efforts_High")
		private int OptionalUsedBuildEffortsHigh;
		
		@Column(name="Optional_Used_Unit_Testing_High")
		private int OptionalUsedUnitTestingHigh;
		
		@Column(name="Optional_Used_Effort_Remediate_Custom_High")
		private int OptionalUsedEffortRemediateCustomHigh;
		
		@Column(name="Optional_Used_SPDD_SPAU_Efforts_High")
		private int OptionalUsedSPDD_SPAU_EffortsHigh;	
		
	public int getMandatoryAnalysisEffortsLow() {
		return MandatoryAnalysisEffortsLow;
	}

	public void setMandatoryAnalysisEffortsLow(int mandatoryAnalysisEffortsLow) {
		MandatoryAnalysisEffortsLow = mandatoryAnalysisEffortsLow;
	}

	public int getMandatoryDesignEffortsLow() {
		return MandatoryDesignEffortsLow;
	}

	public void setMandatoryDesignEffortsLow(int mandatoryDesignEffortsLow) {
		MandatoryDesignEffortsLow = mandatoryDesignEffortsLow;
	}

	public int getMandatoryBuildEffortsLow() {
		return MandatoryBuildEffortsLow;
	}

	public void setMandatoryBuildEffortsLow(int mandatoryBuildEffortsLow) {
		MandatoryBuildEffortsLow = mandatoryBuildEffortsLow;
	}

	public int getMandatoryUnitTestingLow() {
		return MandatoryUnitTestingLow;
	}

	public void setMandatoryUnitTestingLow(int mandatoryUnitTestingLow) {
		MandatoryUnitTestingLow = mandatoryUnitTestingLow;
	}

	public int getMandatoryEffortRemediateCustomLow() {
		return MandatoryEffortRemediateCustomLow;
	}

	public void setMandatoryEffortRemediateCustomLow(int mandatoryEffortRemediateCustomLow) {
		MandatoryEffortRemediateCustomLow = mandatoryEffortRemediateCustomLow;
	}

	public int getMandatorySPDD_SPAU_EffortsLow() {
		return MandatorySPDD_SPAU_EffortsLow;
	}

	public void setMandatorySPDD_SPAU_EffortsLow(int mandatorySPDD_SPAU_EffortsLow) {
		MandatorySPDD_SPAU_EffortsLow = mandatorySPDD_SPAU_EffortsLow;
	}

	public int getMandatoryUsedAnalysisEffortsLow() {
		return MandatoryUsedAnalysisEffortsLow;
	}

	public void setMandatoryUsedAnalysisEffortsLow(int mandatoryUsedAnalysisEffortsLow) {
		MandatoryUsedAnalysisEffortsLow = mandatoryUsedAnalysisEffortsLow;
	}

	public int getMandatoryUsedDesignEffortsLow() {
		return MandatoryUsedDesignEffortsLow;
	}

	public void setMandatoryUsedDesignEffortsLow(int mandatoryUsedDesignEffortsLow) {
		MandatoryUsedDesignEffortsLow = mandatoryUsedDesignEffortsLow;
	}

	public int getMandatoryUsedBuildEffortsLow() {
		return MandatoryUsedBuildEffortsLow;
	}

	public void setMandatoryUsedBuildEffortsLow(int mandatoryUsedBuildEffortsLow) {
		MandatoryUsedBuildEffortsLow = mandatoryUsedBuildEffortsLow;
	}

	public int getMandatoryUsedUnitTestingLow() {
		return MandatoryUsedUnitTestingLow;
	}

	public void setMandatoryUsedUnitTestingLow(int mandatoryUsedUnitTestingLow) {
		MandatoryUsedUnitTestingLow = mandatoryUsedUnitTestingLow;
	}

	public int getMandatoryUsedEffortRemediateCustomLow() {
		return MandatoryUsedEffortRemediateCustomLow;
	}

	public void setMandatoryUsedEffortRemediateCustomLow(int mandatoryUsedEffortRemediateCustomLow) {
		MandatoryUsedEffortRemediateCustomLow = mandatoryUsedEffortRemediateCustomLow;
	}

	public int getMandatoryUsedSPDD_SPAU_EffortsLow() {
		return MandatoryUsedSPDD_SPAU_EffortsLow;
	}

	public void setMandatoryUsedSPDD_SPAU_EffortsLow(int mandatoryUsedSPDD_SPAU_EffortsLow) {
		MandatoryUsedSPDD_SPAU_EffortsLow = mandatoryUsedSPDD_SPAU_EffortsLow;
	}

	public int getOptionalAnalysisEffortsLow() {
		return OptionalAnalysisEffortsLow;
	}

	public void setOptionalAnalysisEffortsLow(int optionalAnalysisEffortsLow) {
		OptionalAnalysisEffortsLow = optionalAnalysisEffortsLow;
	}

	public int getOptionalDesignEffortsLow() {
		return OptionalDesignEffortsLow;
	}

	public void setOptionalDesignEffortsLow(int optionalDesignEffortsLow) {
		OptionalDesignEffortsLow = optionalDesignEffortsLow;
	}

	public int getOptionalBuildEffortsLow() {
		return OptionalBuildEffortsLow;
	}

	public void setOptionalBuildEffortsLow(int optionalBuildEffortsLow) {
		OptionalBuildEffortsLow = optionalBuildEffortsLow;
	}

	public int getOptionalUnitTestingLow() {
		return OptionalUnitTestingLow;
	}

	public void setOptionalUnitTestingLow(int optionalUnitTestingLow) {
		OptionalUnitTestingLow = optionalUnitTestingLow;
	}

	public int getOptionalEffortRemediateCustomLow() {
		return OptionalEffortRemediateCustomLow;
	}

	public void setOptionalEffortRemediateCustomLow(int optionalEffortRemediateCustomLow) {
		OptionalEffortRemediateCustomLow = optionalEffortRemediateCustomLow;
	}

	public int getOptionalSPDD_SPAU_EffortsLow() {
		return OptionalSPDD_SPAU_EffortsLow;
	}

	public void setOptionalSPDD_SPAU_EffortsLow(int optionalSPDD_SPAU_EffortsLow) {
		OptionalSPDD_SPAU_EffortsLow = optionalSPDD_SPAU_EffortsLow;
	}

	public int getOptionalUsedAnalysisEffortsLow() {
		return OptionalUsedAnalysisEffortsLow;
	}

	public void setOptionalUsedAnalysisEffortsLow(int optionalUsedAnalysisEffortsLow) {
		OptionalUsedAnalysisEffortsLow = optionalUsedAnalysisEffortsLow;
	}

	public int getOptionalUsedDesignEffortsLow() {
		return OptionalUsedDesignEffortsLow;
	}

	public void setOptionalUsedDesignEffortsLow(int optionalUsedDesignEffortsLow) {
		OptionalUsedDesignEffortsLow = optionalUsedDesignEffortsLow;
	}

	public int getOptionalUsedBuildEffortsLow() {
		return OptionalUsedBuildEffortsLow;
	}

	public void setOptionalUsedBuildEffortsLow(int optionalUsedBuildEffortsLow) {
		OptionalUsedBuildEffortsLow = optionalUsedBuildEffortsLow;
	}

	public int getOptionalUsedUnitTestingLow() {
		return OptionalUsedUnitTestingLow;
	}

	public void setOptionalUsedUnitTestingLow(int optionalUsedUnitTestingLow) {
		OptionalUsedUnitTestingLow = optionalUsedUnitTestingLow;
	}

	public int getOptionalUsedEffortRemediateCustomLow() {
		return OptionalUsedEffortRemediateCustomLow;
	}

	public void setOptionalUsedEffortRemediateCustomLow(int optionalUsedEffortRemediateCustomLow) {
		OptionalUsedEffortRemediateCustomLow = optionalUsedEffortRemediateCustomLow;
	}

	public int getOptionalUsedSPDD_SPAU_EffortsLow() {
		return OptionalUsedSPDD_SPAU_EffortsLow;
	}

	public void setOptionalUsedSPDD_SPAU_EffortsLow(int optionalUsedSPDD_SPAU_EffortsLow) {
		OptionalUsedSPDD_SPAU_EffortsLow = optionalUsedSPDD_SPAU_EffortsLow;
	}

	public int getMandatoryAnalysisEffortsHigh() {
		return MandatoryAnalysisEffortsHigh;
	}

	public void setMandatoryAnalysisEffortsHigh(int mandatoryAnalysisEffortsHigh) {
		MandatoryAnalysisEffortsHigh = mandatoryAnalysisEffortsHigh;
	}

	public int getMandatoryDesignEffortsHigh() {
		return MandatoryDesignEffortsHigh;
	}

	public void setMandatoryDesignEffortsHigh(int mandatoryDesignEffortsHigh) {
		MandatoryDesignEffortsHigh = mandatoryDesignEffortsHigh;
	}

	public int getMandatoryBuildEffortsHigh() {
		return MandatoryBuildEffortsHigh;
	}

	public void setMandatoryBuildEffortsHigh(int mandatoryBuildEffortsHigh) {
		MandatoryBuildEffortsHigh = mandatoryBuildEffortsHigh;
	}

	public int getMandatoryUnitTestingHigh() {
		return MandatoryUnitTestingHigh;
	}

	public void setMandatoryUnitTestingHigh(int mandatoryUnitTestingHigh) {
		MandatoryUnitTestingHigh = mandatoryUnitTestingHigh;
	}

	public int getMandatoryEffortRemediateCustomHigh() {
		return MandatoryEffortRemediateCustomHigh;
	}

	public void setMandatoryEffortRemediateCustomHigh(int mandatoryEffortRemediateCustomHigh) {
		MandatoryEffortRemediateCustomHigh = mandatoryEffortRemediateCustomHigh;
	}

	public int getMandatorySPDD_SPAU_EffortsHigh() {
		return MandatorySPDD_SPAU_EffortsHigh;
	}

	public void setMandatorySPDD_SPAU_EffortsHigh(int mandatorySPDD_SPAU_EffortsHigh) {
		MandatorySPDD_SPAU_EffortsHigh = mandatorySPDD_SPAU_EffortsHigh;
	}

	public int getMandatoryUsedAnalysisEffortsHigh() {
		return MandatoryUsedAnalysisEffortsHigh;
	}

	public void setMandatoryUsedAnalysisEffortsHigh(int mandatoryUsedAnalysisEffortsHigh) {
		MandatoryUsedAnalysisEffortsHigh = mandatoryUsedAnalysisEffortsHigh;
	}

	public int getMandatoryUsedDesignEffortsHigh() {
		return MandatoryUsedDesignEffortsHigh;
	}

	public void setMandatoryUsedDesignEffortsHigh(int mandatoryUsedDesignEffortsHigh) {
		MandatoryUsedDesignEffortsHigh = mandatoryUsedDesignEffortsHigh;
	}

	public int getMandatoryUsedBuildEffortsHigh() {
		return MandatoryUsedBuildEffortsHigh;
	}

	public void setMandatoryUsedBuildEffortsHigh(int mandatoryUsedBuildEffortsHigh) {
		MandatoryUsedBuildEffortsHigh = mandatoryUsedBuildEffortsHigh;
	}

	public int getMandatoryUsedUnitTestingHigh() {
		return MandatoryUsedUnitTestingHigh;
	}

	public void setMandatoryUsedUnitTestingHigh(int mandatoryUsedUnitTestingHigh) {
		MandatoryUsedUnitTestingHigh = mandatoryUsedUnitTestingHigh;
	}

	public int getMandatoryUsedEffortRemediateCustomHigh() {
		return MandatoryUsedEffortRemediateCustomHigh;
	}

	public void setMandatoryUsedEffortRemediateCustomHigh(int mandatoryUsedEffortRemediateCustomHigh) {
		MandatoryUsedEffortRemediateCustomHigh = mandatoryUsedEffortRemediateCustomHigh;
	}

	public int getMandatoryUsedSPDD_SPAU_EffortsHigh() {
		return MandatoryUsedSPDD_SPAU_EffortsHigh;
	}

	public void setMandatoryUsedSPDD_SPAU_EffortsHigh(int mandatoryUsedSPDD_SPAU_EffortsHigh) {
		MandatoryUsedSPDD_SPAU_EffortsHigh = mandatoryUsedSPDD_SPAU_EffortsHigh;
	}

	public int getOptionalAnalysisEffortsHigh() {
		return OptionalAnalysisEffortsHigh;
	}

	public void setOptionalAnalysisEffortsHigh(int optionalAnalysisEffortsHigh) {
		OptionalAnalysisEffortsHigh = optionalAnalysisEffortsHigh;
	}

	public int getOptionalDesignEffortsHigh() {
		return OptionalDesignEffortsHigh;
	}

	public void setOptionalDesignEffortsHigh(int optionalDesignEffortsHigh) {
		OptionalDesignEffortsHigh = optionalDesignEffortsHigh;
	}

	public int getOptionalBuildEffortsHigh() {
		return OptionalBuildEffortsHigh;
	}

	public void setOptionalBuildEffortsHigh(int optionalBuildEffortsHigh) {
		OptionalBuildEffortsHigh = optionalBuildEffortsHigh;
	}

	public int getOptionalUnitTestingHigh() {
		return OptionalUnitTestingHigh;
	}

	public void setOptionalUnitTestingHigh(int optionalUnitTestingHigh) {
		OptionalUnitTestingHigh = optionalUnitTestingHigh;
	}

	public int getOptionalEffortRemediateCustomHigh() {
		return OptionalEffortRemediateCustomHigh;
	}

	public void setOptionalEffortRemediateCustomHigh(int optionalEffortRemediateCustomHigh) {
		OptionalEffortRemediateCustomHigh = optionalEffortRemediateCustomHigh;
	}

	public int getOptionalSPDD_SPAU_EffortsHigh() {
		return OptionalSPDD_SPAU_EffortsHigh;
	}

	public void setOptionalSPDD_SPAU_EffortsHigh(int optionalSPDD_SPAU_EffortsHigh) {
		OptionalSPDD_SPAU_EffortsHigh = optionalSPDD_SPAU_EffortsHigh;
	}

	public int getOptionalUsedAnalysisEffortsHigh() {
		return OptionalUsedAnalysisEffortsHigh;
	}

	public void setOptionalUsedAnalysisEffortsHigh(int optionalUsedAnalysisEffortsHigh) {
		OptionalUsedAnalysisEffortsHigh = optionalUsedAnalysisEffortsHigh;
	}

	public int getOptionalUsedDesignEffortsHigh() {
		return OptionalUsedDesignEffortsHigh;
	}

	public void setOptionalUsedDesignEffortsHigh(int optionalUsedDesignEffortsHigh) {
		OptionalUsedDesignEffortsHigh = optionalUsedDesignEffortsHigh;
	}

	public int getOptionalUsedBuildEffortsHigh() {
		return OptionalUsedBuildEffortsHigh;
	}

	public void setOptionalUsedBuildEffortsHigh(int optionalUsedBuildEffortsHigh) {
		OptionalUsedBuildEffortsHigh = optionalUsedBuildEffortsHigh;
	}

	public int getOptionalUsedUnitTestingHigh() {
		return OptionalUsedUnitTestingHigh;
	}

	public void setOptionalUsedUnitTestingHigh(int optionalUsedUnitTestingHigh) {
		OptionalUsedUnitTestingHigh = optionalUsedUnitTestingHigh;
	}

	public int getOptionalUsedEffortRemediateCustomHigh() {
		return OptionalUsedEffortRemediateCustomHigh;
	}

	public void setOptionalUsedEffortRemediateCustomHigh(int optionalUsedEffortRemediateCustomHigh) {
		OptionalUsedEffortRemediateCustomHigh = optionalUsedEffortRemediateCustomHigh;
	}

	public int getOptionalUsedSPDD_SPAU_EffortsHigh() {
		return OptionalUsedSPDD_SPAU_EffortsHigh;
	}

	public void setOptionalUsedSPDD_SPAU_EffortsHigh(int optionalUsedSPDD_SPAU_EffortsHigh) {
		OptionalUsedSPDD_SPAU_EffortsHigh = optionalUsedSPDD_SPAU_EffortsHigh;
	}

	
	
	@Column(name="REQUEST_ID")
	@Index(name="Index_Request_id")
	private long requestID;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public long getRequestID() {
		return requestID;
	}

	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}

	

}
