package com.accenture.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import org.hibernate.annotations.Type;


public class S4ValidationFileModel implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;



	private int ID;



	
	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}
	
	public String validationFileName;
	
	

	public byte[] validationFile;
   
	private String validationVersion;
	
	private String updatedDate;


	
	public String getValidationFileName() {
		return validationFileName;
	}

	public void setValidationFileName(String validationFileName) {
		this.validationFileName = validationFileName;
	}
	
	
	
	@Type(type="org.hibernate.type.MaterializedBlobType")
	public byte[] getValidationFile() {
		return validationFile;
	}

	public void setValidationFile(byte[] validationFile) {
		this.validationFile = validationFile;
	}

	public String getValidationVersion() {
		return validationVersion;
	}

	public void setValidationVersion(String validationVersion) {
		this.validationVersion = validationVersion;
	}

	public String getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}
		
}
