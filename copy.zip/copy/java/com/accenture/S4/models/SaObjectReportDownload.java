package com.accenture.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "Sa_Object_Report_Download")
public class SaObjectReportDownload {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Id")
	private int id;
	
	@Index(name="Index_Request_id")
	@Column(name = "Request_ID")
	private Integer requestId;
	
	@Column(name = "Targetversion")
	private String targetVersion;
	
	@Column(name = "functional_area")
	private String functionalArea;
	
	@Column(name = "Agr_name")
	private String agrName;
	
	@Column(name = "OldTCode")
	private String oldTcode;
	
	@Column(name = "OldObj")
	private String oldObj;
	
	@Column(name = "OldField")
	private String oldField;
	
	@Column(name = "OldLow")
	private String oldLow;
	
	@Column(name = "OldHigh")
	private String oldHigh;
	
	@Column(name = "OldOBjValues",columnDefinition="Text")
	private String oldObjValues;
	
	@Column(name = "NewTCode")
	private String newTcode;
	
	@Column(name = "NewObj")
	private String newObj;
	
	@Column(name = "NewField")
	private String newField;
	
	@Column(name = "NewLow")
	private String newLow;
	
	@Column(name = "NewHigh")
	private String newHigh;
	
	@Column(name = "Proposed",columnDefinition="Text")
	private String proposed;
	
	/*@Index(name="Index_Concat_oldobj")
	@Column(name = "Concat_oldobj")
	private String concatOldObj;
	
	@Index(name="Index_Concat_newobj")
	@Column(name = "Concat_newobj")
	private String concatNewObj;
	
	@Index(name="Index_Concat_oldfield")
	@Column(name = "Concat_oldfield")
	private String concatOldField;
	
	@Column(name = "Concat_newfield")
	private String concatNewField;*/
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Integer getRequestId() {
		return requestId;
	}
	public void setRequestId(Integer requestId) {
		this.requestId = requestId;
	}
	public String getTargetVersion() {
		return targetVersion;
	}
	public void setTargetVersion(String targetVersion) {
		this.targetVersion = targetVersion;
	}
	public String getFunctionalArea() {
		return functionalArea;
	}
	public void setFunctionalArea(String functionalArea) {
		this.functionalArea = functionalArea;
	}
	public String getAgrName() {
		return agrName;
	}
	public void setAgrName(String agrName) {
		this.agrName = agrName;
	}
	public String getOldTcode() {
		return oldTcode;
	}
	public void setOldTcode(String oldTcode) {
		this.oldTcode = oldTcode;
	}
	public String getOldObj() {
		return oldObj;
	}
	public void setOldObj(String oldObj) {
		this.oldObj = oldObj;
	}
	public String getOldField() {
		return oldField;
	}
	public void setOldField(String oldField) {
		this.oldField = oldField;
	}
	public String getOldLow() {
		return oldLow;
	}
	public void setOldLow(String oldLow) {
		this.oldLow = oldLow;
	}
	public String getOldHigh() {
		return oldHigh;
	}
	public void setOldHigh(String oldHigh) {
		this.oldHigh = oldHigh;
	}
	public String getOldObjValues() {
		return oldObjValues;
	}
	public void setOldObjValues(String oldObjValues) {
		this.oldObjValues = oldObjValues;
	}
	public String getNewTcode() {
		return newTcode;
	}
	public void setNewTcode(String newTcode) {
		this.newTcode = newTcode;
	}
	public String getNewObj() {
		return newObj;
	}
	public void setNewObj(String newObj) {
		this.newObj = newObj;
	}
	public String getNewField() {
		return newField;
	}
	public void setNewField(String newField) {
		this.newField = newField;
	}
	public String getNewLow() {
		return newLow;
	}
	public void setNewLow(String newLow) {
		this.newLow = newLow;
	}
	public String getNewHigh() {
		return newHigh;
	}
	public void setNewHigh(String newHigh) {
		this.newHigh = newHigh;
	}
	public String getProposed() {
		return proposed;
	}
	public void setProposed(String proposed) {
		this.proposed = proposed;
	}
	
}
