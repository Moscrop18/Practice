package com.accenture.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "S4_Impacted_Custom_download")
public class S4ImpactedCustomTblDownload {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ID")
	private int id;
	
	@Column(name="OBJ_NAME")
	private String objectName;
	
	@Column(name="INFO")
	private String info;
	
	@Column(name="OBJ_PACKAGE")
	private String objPackage;
	
	@Column(name="COMMENTS",length=500)
	private String comments;
	
	@Column(name="REQUEST_ID")
	private Long requestId;
	
	@Column(name="DESC_CHANGE")
	private String descOfChange;
	
	@Column(name="SAP_NOTE")
	private String sapNote;
	
	@Column(name="SOLUTION_STEP" ,length=500)
	private String solStep;
	
	@Column(name="COMPLEXITY")
	private String complexity;
	
	@Column(name="ISSUE_CATEGORY")
	private String issueCat;
	
	@Column(name="ISSUE_SUB_CATEGORY")
	private String issueSubCat;
	
	@Column(name="TRIGGER_OBJECT")
	private String triggerObj;
	
	@Column(name="REMEDIATION_CATEGORY")
	private String remediCat;
	
	@Column(name="SAP_SIMPLI_LIST")
	private String sapSimpliList;
	
	@Column(name="APPLICATION_COMP")
	private String appComp;
	
	@Column(name="SAP_SIMPLI_CATEGORY")
	private String sapSimpliCat;
	
	@Column(name="ITEM_AREA")
	private String itemArea;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getObjectName() {
		return objectName;
	}
	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	public String getObjPackage() {
		return objPackage;
	}
	public void setObjPackage(String objPackage) {
		this.objPackage = objPackage;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public Long getRequestId() {
		return requestId;
	}
	public void setRequestId(Long requestId) {
		this.requestId = requestId;
	}
	public String getDescOfChange() {
		return descOfChange;
	}
	public void setDescOfChange(String descOfChange) {
		this.descOfChange = descOfChange;
	}
	public String getSapNote() {
		return sapNote;
	}
	public void setSapNote(String sapNote) {
		this.sapNote = sapNote;
	}
	public String getSolStep() {
		return solStep;
	}
	public void setSolStep(String solStep) {
		this.solStep = solStep;
	}
	public String getComplexity() {
		return complexity;
	}
	public void setComplexity(String complexity) {
		this.complexity = complexity;
	}
	public String getIssueCat() {
		return issueCat;
	}
	public void setIssueCat(String issueCat) {
		this.issueCat = issueCat;
	}
	public String getIssueSubCat() {
		return issueSubCat;
	}
	public void setIssueSubCat(String issueSubCat) {
		this.issueSubCat = issueSubCat;
	}
	public String getTriggerObj() {
		return triggerObj;
	}
	public void setTriggerObj(String triggerObj) {
		this.triggerObj = triggerObj;
	}
	public String getRemediCat() {
		return remediCat;
	}
	public void setRemediCat(String remediCat) {
		this.remediCat = remediCat;
	}
	public String getSapSimpliList() {
		return sapSimpliList;
	}
	public void setSapSimpliList(String sapSimpliList) {
		this.sapSimpliList = sapSimpliList;
	}
	public String getAppComp() {
		return appComp;
	}
	public void setAppComp(String appComp) {
		this.appComp = appComp;
	}
	public String getSapSimpliCat() {
		return sapSimpliCat;
	}
	public void setSapSimpliCat(String sapSimpliCat) {
		this.sapSimpliCat = sapSimpliCat;
	}
	public String getItemArea() {
		return itemArea;
	}
	public void setItemArea(String itemArea) {
		this.itemArea = itemArea;
	}
}
