package com.accenture.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author monika.mishra
 *
 */
@Entity
@Table(name="S4_Clone_Prog_Intermediate")
public class S4CloneIntermediate {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ID")
	private int id;
	
	@Column(name="OBJ_TYPE")
	private String objType;
	
	@Column(name="OBJ_NAME")
	private String objName;
	
	@Column(name="INCLUDE")
	private String include;
	
	@Column(name="REQUEST_ID")
	private long requestID;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getObjType() {
		return objType;
	}

	public void setObjType(String objType) {
		this.objType = objType;
	}

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}

	
	public String getInclude() {
		return include;
	}

	public void setInclude(String include) {
		this.include = include;
	}


	public long getRequestId() {
		return requestID;
	}

	public void setRequestId(long requestId) {
		this.requestID = requestId;
	}

}
