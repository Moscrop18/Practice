package com.accenture.S4.models;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

/**
 * @author rohan.a.mehra
 *
 */
@Entity
@Table(name = "Inventory_List_Downlaod")
public class InventoryList_Download {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	private int id;

	@Column(name = "OBJ_TYPE")
	private String objType;

	@Column(name = "OBJ_NAME")
	private String objName;

	@Column(name = "Used")
	private String used;

	@Column(name = "OBJ_NAME_TYPE")
	private String objNameType;

	@Column(name = "Package")
	private String pckg;

	private String usageCount;

	@Column(name = "Transport_Request")
	private String transReq;

	@Index(name = "Index_Request_id")
	@Column(name = "REQUEST_ID")
	private long requestID;

	@Column(name = "Standard_Modification")
	private String standMod;

	@Column(name = "Ricef_Category")
	private String ricefCategory;
	
	@Column(name = "External_Namespace")
	private String extNamespace;
	
	@Column(name = "Count_Lines")
	private String countLines;
	
	public String getCountLines() {
		return countLines;
	}

	public void setCountLines(String countLines) {
		this.countLines = countLines;
	}

	public String getRicefCategory() {
		return ricefCategory;
	}

	public void setRicefCategory(String ricefCategory) {
		this.ricefCategory = ricefCategory;
	}

	public String getObjNameType() {
		return objNameType;
	}

	public void setObjNameType(String objNameType) {
		this.objNameType = objNameType;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getObjType() {
		return objType;
	}

	public void setObjType(String objType) {
		this.objType = objType;
	}

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}
	
	public String getUsageCount() {
		return usageCount;
	}

	public void setUsageCount(String usageCount) {
		this.usageCount = usageCount;
	}

	public String getPckg() {
		return pckg;
	}

	public void setPckg(String pckg) {
		this.pckg = pckg;
	}

	public String getUsage() {
		return used;
	}

	public void setUsage(String usage) {
		this.used = usage;
	}

	public long getRequestID() {
		return requestID;
	}

	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}

	

	public String getUsed() {
		return used;
	}

	public void setUsed(String used) {
		this.used = used;
	}

	public String getStandMod() {
		return standMod;
	}

	public void setStandMod(String standMod) {
		this.standMod = standMod;
	}

	public String getTransReq() {
		return transReq;
	}

	public void setTransReq(String transReq) {
		this.transReq = transReq;
	}

	public String getExtNamespace() {
		return extNamespace;
	}

	public void setExtNamespace(String extNamespace) {
		this.extNamespace = extNamespace;
	}
	
	@Column(name="Ricef_Sub_Category")
	private String ricefSubCategory;
	
	@Column(name = "CREATED_BY")
	private String createdBy;

	@Column(name = "CREATED_ON")
	private String createdOn;

	@Column(name = "CHANGED_BY")
	private String changedBy;

	@Column(name = "CHANGED_ON")
	private String changedOn;
	
	@Column(name = "TR")
	private String tr;
	
	@Column(name = "TR_STATUS")
	private String trStatus;

	public String getRicefSubCategory() {
		return ricefSubCategory;
	}

	public void setRicefSubCategory(String ricefSubCategory) {
		this.ricefSubCategory = ricefSubCategory;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}


	public String getChangedBy() {
		return changedBy;
	}

	public void setChangedBy(String changedBy) {
		this.changedBy = changedBy;
	}


	public String getTr() {
		return tr;
	}

	public String getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}

	public String getChangedOn() {
		return changedOn;
	}

	public void setChangedOn(String changedOn) {
		this.changedOn = changedOn;
	}

	public void setTr(String tr) {
		this.tr = tr;
	}


	public String getTrStatus() {
		return trStatus;
	}

	public void setTrStatus(String trStatus) {
		this.trStatus = trStatus;
	}

	
}
