package com.accenture.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

/**
 * @author rohan.a.mehra
 *
 */
@Entity
@Table(name="S4_IMPACTED_TRANSACTION_DOWNLOAD")
public class S4ImpactedTransaction_Download {

	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ID")
	private int id;

	@Column(name="IMPACTED_TRANSACTION")
	private String impactedTransaction;

	@Column(name="DESCRIPTION",length=500)
	private String description;

	@Column(name="SOLUTION_STEPS",length=500)
	private String solSteps;

	@Column(name="SAP_NOTES",length=500)
	private String sapNotes;
	
	@Column(name="AFFECTED_AREA",length=500)
	private String affectedArea;

	@Index(name="Index_Request_id")
	@Column(name="REQUEST_ID")
	private long requestID;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getImpactedTransaction() {
		return impactedTransaction;
	}

	public void setImpactedTransaction(String impactedTransaction) {
		this.impactedTransaction = impactedTransaction;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSolSteps() {
		return solSteps;
	}

	public void setSolSteps(String solSteps) {
		this.solSteps = solSteps;
	}

	public String getSapNotes() {
		return sapNotes;
	}

	public void setSapNotes(String sapNotes) {
		this.sapNotes = sapNotes;
	}

	public long getRequestID() {
		return requestID;
	}

	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}
	
	public String getAffectedArea() {
		return affectedArea;
	}

	public void setAffectedArea(String affectedArea) {
		this.affectedArea = affectedArea;
	}
}
