package com.accenture.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author himani.malhotra
 *
 */

@Entity
@Table(name="S4_Enhancement_Intermediate")
public class S4EnhancementIntermediate {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ID")
	private int id;
	
	@Column(name="TYPE",length=500)
	private String type;

	@Column(name="OBJECT_NAME")
	private String objName;
	
	@Column(name="ENHANCEMENT_NAME")
	private String enhancementName;
	
	@Column(name="IMPLEMENTATION_NAME",length=500)
	private String implName;
	
	@Column(name="REQUEST_ID")
	private long requestID;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}

	public String getEnhancementName() {
		return enhancementName;
	}

	public void setEnhancementName(String enhancementName) {
		this.enhancementName = enhancementName;
	}

	public String getImplName() {
		return implName;
	}

	public void setImplName(String implName) {
		this.implName = implName;
	}

	public long getRequestID() {
		return requestID;
	}

	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}

}
