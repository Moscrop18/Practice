package com.accenture.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "ABAP_Inventory_List_Download")
public class ABAPQueryInventoryDownload {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	private int id;

	@Column(name = "OBJ_TYPE")
	private String objType;

	@Column(name = "OBJ_NAME")
	private String objName;

	@Column(name = "Used")
	private String used;

	@Column(name = "OBJ_NAME_TYPE")
	private String objNameType;

	@Column(name = "Package")
	private String pckg;

	private String usageCount;

	@Column(name = "Transport_Request")
	private String transReq;

	@Index(name = "Index_Request_id")
	@Column(name = "REQUEST_ID")
	private long requestID;

	@Column(name = "Ricef_Category")
	private String ricefCategory;
	
	@Column(name="Ricef_Sub_Category")
	private String ricefSubCategory;
	
	@Column(name = "External_Namespace")
	private String extNamespace;
	
	@Column(name = "Count_Lines")
	private String countLines;
	
	@Column(name = "User_Group")
	private String userGroup;
	
	@Column(name = "ABAP_Query")
	private String ABAPQuery;
	
	public String getCountLines() {
		return countLines;
	}

	public void setCountLines(String countLines) {
		this.countLines = countLines;
	}

	public String getRicefCategory() {
		return ricefCategory;
	}

	public void setRicefCategory(String ricefCategory) {
		this.ricefCategory = ricefCategory;
	}

	public String getObjNameType() {
		return objNameType;
	}

	public void setObjNameType(String objNameType) {
		this.objNameType = objNameType;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getObjType() {
		return objType;
	}

	public void setObjType(String objType) {
		this.objType = objType;
	}

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}
	
	public String getUsageCount() {
		return usageCount;
	}

	public void setUsageCount(String usageCount) {
		this.usageCount = usageCount;
	}

	public String getPckg() {
		return pckg;
	}

	public void setPckg(String pckg) {
		this.pckg = pckg;
	}

	public String getUsage() {
		return used;
	}

	public void setUsage(String usage) {
		this.used = usage;
	}

	public long getRequestID() {
		return requestID;
	}

	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}

	public String getTransReq() {
		return transReq;
	}

	public void setTransReq(String transReq) {
		this.transReq = transReq;
	}

	public String getExtNamespace() {
		return extNamespace;
	}

	public void setExtNamespace(String extNamespace) {
		this.extNamespace = extNamespace;
	}

	public String getRicefSubCategory() {
		return ricefSubCategory;
	}

	public void setRicefSubCategory(String ricefSubCategory) {
		this.ricefSubCategory = ricefSubCategory;
	}

	public String getUserGroup() {
		return userGroup;
	}

	public void setUserGroup(String userGroup) {
		this.userGroup = userGroup;
	}

	public String getABAPQuery() {
		return ABAPQuery;
	}

	public void setABAPQuery(String ABAPQuery) {
		this.ABAPQuery = ABAPQuery;
	}

	
}
