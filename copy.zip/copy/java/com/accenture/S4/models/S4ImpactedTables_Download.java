package com.accenture.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

/**
 * @author rohan.a.mehra
 *
 */

@Entity
@Table(name="S4_IMPACTED_TABLES_DOWNLOAD")
public class S4ImpactedTables_Download {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ID")
	private int id;

	@Column(name="Object")
	private String object;

	@Column(name="DESCRIPTION",length=500)
	private String description;

	@Column(name="SOLUTION_STEPS",length=500)
	private String solSteps;

	@Column(name="SAP_NOTES",length=500)
	private String sapNotes;

	@Index(name="Index_Request_id")
	@Column(name="REQUEST_ID")
	private long requestID;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getObject() {
		return object;
	}

	public void setObject(String object) {
		this.object = object;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSolSteps() {
		return solSteps;
	}

	public void setSolSteps(String solSteps) {
		this.solSteps = solSteps;
	}

	public String getSapNotes() {
		return sapNotes;
	}

	public void setSapNotes(String sapNotes) {
		this.sapNotes = sapNotes;
	}

	public long getRequestID() {
		return requestID;
	}

	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}

}
