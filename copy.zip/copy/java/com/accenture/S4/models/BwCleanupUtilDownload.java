package com.accenture.S4.models;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Bw_Cleanup_Util_Download")
public class BwCleanupUtilDownload {
	private int id;
	private long requestId;
	private String objectType;
	private String objectName;
	private String status;
	private String lastUsedDate;
	private String elapsedTimInYrs;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "ID")
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	@Column(name = "Request_ID")
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	
	@Column(name = "Object_Type")
	public String getObjectType() {
		return objectType;
	}
	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}
	
	@Column(name = "Object_Name")
	public String getObjectName() {
		return objectName;
	}
	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}
	
	@Column(name = "Last_Used")
	public String getLastUsedDate() {
		return lastUsedDate;
	}
	public void setLastUsedDate(String lastUsedDate) {
		this.lastUsedDate = lastUsedDate;
	}
	
	@Column(name = "Elapsed_Time_Year")
	public String getElapsedTimInYrs() {
		return elapsedTimInYrs;
	}
	public void setElapsedTimInYrs(String elapsedTimInYrs) {
		this.elapsedTimInYrs = elapsedTimInYrs;
	}
	
	@Column(name = "Status")
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}
