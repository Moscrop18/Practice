package com.accenture.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

/**
 * @author monika.mishra
 *
 */
@Entity
@Table(name="S4_Output_Management")
public class S4OutputMgmt {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ID")
	private int id;

	@Column(name="Type")
	private String type;

	@Column(name="Obj_Name",length=500)
	private String ObjName;
	
	@Column(name="Used")
	private String used;
	
	@Column(name="Obj_Name_Type")
	private String objNameType;

	
	public String getObjNameType() {
		return objNameType;
	}

	public void setObjNameType(String objNameType) {
		this.objNameType = objNameType;
	}

	@Column(name="REQUEST_ID")
	@Index(name="Index_Request_id")
	private long requestID;


	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getObjName() {
		return ObjName;
	}

	public void setObjName(String objName) {
		ObjName = objName;
	}

	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	

	public long getRequestID() {
		return requestID;
	}

	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}

	public String getUsed() {
		return used;
	}

	public void setUsed(String used) {
		this.used = used;
	}

	
}
