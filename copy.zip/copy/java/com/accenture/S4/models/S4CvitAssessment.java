package com.accenture.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="S4_CVIT_ASSESSMENT")
public class S4CvitAssessment{

	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ID")
	private Integer id;
	
	@Column(name="OBJ_NAME")
	private String objName;
	
	@Column(name="CVIT_VALUE")
	private String cvitValue;

	@Column(name="REQUEST_ID")
	private Long requestId;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}

	public String getCvitValue() {
		return cvitValue;
	}

	public void setCvitValue(String cvitValue) {
		this.cvitValue = cvitValue;
	}

	public Long getRequestId() {
		return requestId;
	}

	public void setRequestId(Long requestId) {
		this.requestId = requestId;
	}
	
	
	
}
