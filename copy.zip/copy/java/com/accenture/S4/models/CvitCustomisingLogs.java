package com.accenture.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Cvit_CustomisingLogs")
public class CvitCustomisingLogs {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Id")
	private int id;
	
	@Column(name = "Request_Id")
	private long requestId;
	
	@Column(name = "Object_Name")
	private String objectName;
	
	@Column(name = "Customising_Errors")
	private String customisingErrors;
	
	@Column(name = "Text")
	private String text;
	
	@Column(name = "Customer_Count")
	private int customerCount;
	
	@Column(name = "Vendor_Count")
	private int vendorCount;
	
	@Column(name = "Customer_Logs")
	private String customerLogs;
	
	@Column(name = "Vendor_Logs")
	private String vendorLogs;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public long getRequestId() {
		return requestId;
	}

	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}

	public String getObjectName() {
		return objectName;
	}

	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}

	public String getCustomisingErrors() {
		return customisingErrors;
	}

	public void setCustomisingErrors(String customisingErrors) {
		this.customisingErrors = customisingErrors;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public int getCustomerCount() {
		return customerCount;
	}

	public void setCustomerCount(int customerCount) {
		this.customerCount = customerCount;
	}

	public int getVendorCount() {
		return vendorCount;
	}

	public void setVendorCount(int vendorCount) {
		this.vendorCount = vendorCount;
	}

	public String getCustomerLogs() {
		return customerLogs;
	}

	public void setCustomerLogs(String customerLogs) {
		this.customerLogs = customerLogs;
	}

	public String getVendorLogs() {
		return vendorLogs;
	}

	public void setVendorLogs(String vendorLogs) {
		this.vendorLogs = vendorLogs;
	}
}
