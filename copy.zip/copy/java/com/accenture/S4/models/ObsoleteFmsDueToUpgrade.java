package com.accenture.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "ObsoleteFMs_Download")
public class ObsoleteFmsDueToUpgrade {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ID")
	private int id;

	@Column(name="OBJ_NAME")
	private String objName;
	
	@Column(name="SUB_OBJ")
	private String subObject;

	@Column(name="METHOD")
	private String method;

	@Column(name="PCKG")
	private String pckg;

	@Column(name="USED")
	private String used;

	@Column(name="TYPE")
	private String type;

	@Column(name="IMPACTED_OBJ_TYPE")
	private String impactedObjType;

	@Column(name="LINE_NO")
	private int lineNo;

	@Column(name="STMT" ,length=500)
	private String stmt;

	@Column(name="OPERATIONS")
	private String operations;

	@Column(name="IMPACT_REASON",length=500)
	private String impactReason;

	@Column(name="AFFECT_OBJ_DESC" ,columnDefinition = "LONGTEXT")
	private String affectObjDesc;

	@Column(name="DESC_OF_CHANGE",length=500)
	private String descOfChange;

	@Column(name="SAP_NOTES")
	private String sapNotes;

	@Column(name="SOLUTION_STEPS",length=500)
	private String solutionSteps;

	@Column(name="complexity")
	private String complexity;

	@Column(name="ISSUE_CATEGORY")
	private String issueCategory;

	@Column(name="TRIGGER_OBJ")
	private String triggerObj;

	@Column(name="SAP_SIMP_LIST")
	private String sapSimpListChapter;

	@Column(name="APP_COMPONENT")
	private String applicationComponent;

	@Column(name="SAP_SIMPL_CATEGORY")
	private String sapSimplCategry;

	@Column(name="ITEM_AREA")
	private String itemArea;
	
	@Column(name="IDENTIFIER")
	private String identifier;
	
	@Column(name="Remediation_Category")
	private String remediationCategory;
	
	@Column(name="Total_Scanned_Line")
	private Integer totalScannedLine;
	
	@Column(name="Affected_Area")
	private String affectedArea;
	
	@Index(name="Index_Request_id")
	@Column(name="REQUEST_ID")
	private long requestID;
	
	@Column(name="OBJ_NAME_TYPE")
	private String objNameType;

	@Column(name="READ_PROG")
	private String readProgram;
	
	@Column(name="SELECT_LINE")
	private String selectLine;
	
	@Column(name="Issue_Sub_Category")
	private String issueSubCategory;
	
	@Column(name="Trigger_Object" , columnDefinition = "LONGTEXT")
	private String triggerObject;
	
	@Column(name="Impact")
	private String impact;
	
	@Column(name = "RICEF_CATEGORY")
	private String ricefCategory;

	@Column(name="ERROR_CATEGORY")
	private String errorCategory;
	
	public String getObjNameType() {
		return objNameType;
	}

	public void setObjNameType(String objNameType) {
		this.objNameType = objNameType;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}

	public String getSubObject() {
		return subObject;
	}

	public void setSubObject(String subObject) {
		this.subObject = subObject;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public String getPckg() {
		return pckg;
	}

	public void setPckg(String pckg) {
		this.pckg = pckg;
	}

	public String getUsed() {
		return used;
	}

	public void setUsed(String used) {
		this.used = used;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getImpactedObjType() {
		return impactedObjType;
	}

	public void setImpactedObjType(String impactedObjType) {
		this.impactedObjType = impactedObjType;
	}

	public int getLineNo() {
		return lineNo;
	}

	public void setLineNo(int lineNo) {
		this.lineNo = lineNo;
	}

	public String getStmt() {
		return stmt;
	}

	public void setStmt(String stmt) {
		this.stmt = stmt;
	}

	public String getOperations() {
		return operations;
	}

	public void setOperations(String operations) {
		this.operations = operations;
	}

	public String getImpactReason() {
		return impactReason;
	}

	public void setImpactReason(String impactReason) {
		this.impactReason = impactReason;
	}

	public String getAffectObjDesc() {
		return affectObjDesc;
	}

	public void setAffectObjDesc(String affectObjDesc) {
		this.affectObjDesc = affectObjDesc;
	}

	public String getDescOfChange() {
		return descOfChange;
	}

	public void setDescOfChange(String descOfChange) {
		this.descOfChange = descOfChange;
	}

	public String getSapNotes() {
		return sapNotes;
	}

	public void setSapNotes(String sapNotes) {
		this.sapNotes = sapNotes;
	}

	public String getSolutionSteps() {
		return solutionSteps;
	}

	public void setSolutionSteps(String solutionSteps) {
		this.solutionSteps = solutionSteps;
	}

	public String getComplexity() {
		return complexity;
	}

	public void setComplexity(String complexity) {
		this.complexity = complexity;
	}

	public String getIssueCategory() {
		return issueCategory;
	}

	public void setIssueCategory(String issueCategory) {
		this.issueCategory = issueCategory;
	}


	public String getTriggerObj() {
		return triggerObj;
	}

	public void setTriggerObj(String triggerObj) {
		this.triggerObj = triggerObj;
	}

	public String getSapSimpListChapter() {
		return sapSimpListChapter;
	}

	public void setSapSimpListChapter(String sapSimpListChapter) {
		this.sapSimpListChapter = sapSimpListChapter;
	}

	public String getApplicationComponent() {
		return applicationComponent;
	}

	public void setApplicationComponent(String applicationComponent) {
		this.applicationComponent = applicationComponent;
	}

	public String getSapSimplCategry() {
		return sapSimplCategry;
	}

	public void setSapSimplCategry(String sapSimplCategry) {
		this.sapSimplCategry = sapSimplCategry;
	}

	public String getItemArea() {
		return itemArea;
	}

	public void setItemArea(String itemArea) {
		this.itemArea = itemArea;
	}

	public long getRequestId() {
		return requestID;
	}

	public void setRequestId(long requestId) {
		this.requestID = requestId;
	}

	public String getIdentifier() {
		return identifier;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	public String getRemediationCategory() {
		return remediationCategory;
	}

	public void setRemediationCategory(String remediationCategory) {
		this.remediationCategory = remediationCategory;
	}

	public Integer getTotalScannedLine() {
		return totalScannedLine;
	}

	public void setTotalScannedLine(Integer totalScannedLine) {
		this.totalScannedLine = totalScannedLine;
	}

	public String getAffectedArea() {
		return affectedArea;
	}

	public void setAffectedArea(String affectedArea) {
		this.affectedArea = affectedArea;
	}

	public String getRicefCategory() {
		return ricefCategory;
	}

	public void setRicefCategory(String ricefCategory) {
		this.ricefCategory = ricefCategory;
	}

	public long getRequestID() {
		return requestID;
	}

	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}

	public String getReadProgram() {
		return readProgram;
	}

	public void setReadProgram(String readProgram) {
		this.readProgram = readProgram;
	}

	public String getSelectLine() {
		return selectLine;
	}

	public void setSelectLine(String selectLine) {
		this.selectLine = selectLine;
	}

	public String getIssueSubCategory() {
		return issueSubCategory;
	}

	public void setIssueSubCategory(String issueSubCategory) {
		this.issueSubCategory = issueSubCategory;
	}

	public String getTriggerObject() {
		return triggerObject;
	}

	public void setTriggerObject(String triggerObject) {
		this.triggerObject = triggerObject;
	}

	public String getImpact() {
		return impact;
	}

	public void setImpact(String impact) {
		this.impact = impact;
	}
	@Column(name = "RICEF_SUB_CATEGORY")
	private String ricefSubCategory;
	
	public String getRicefSubCategory() {
		return ricefSubCategory;
	}

	public void setRicefSubCategory(String ricefSubCategory) {
		this.ricefSubCategory = ricefSubCategory;
	}
	@Column(name = "External_Namespace")
	private String extNamespace;
	
	public String getExtNamespace() {
		return extNamespace;
	}

	public void setExtNamespace(String extNamespace) {
		this.extNamespace = extNamespace;
	}
	public String getErrorCategory() {
		return errorCategory;
	}

	public void setErrorCategory(String errorCategory) {
		this.errorCategory = errorCategory;
	}
}
