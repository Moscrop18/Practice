/*CR-No.    Desc     Date    Modified By
 * 
 * CR-26.0:- Make changes for Op-Code & show total scanned lines -05/09/17 -monika.mishra
 * 
 * CR-50.0 & 51.0 :- Show different View For S4-10/11/2017 -monika.mishra
 * 
 * CR-61: New Estimation sheet added with a separate template addition for Admin-16/3/2018-rohan.a.mehra
 * 
 * */

package com.accenture.S4.Controller;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.accenture.S4.models.OperationDataS4;
import com.accenture.S4.models.S4AffectCustomField;
import com.accenture.S4.models.S4AppendStructureAnalysis;
import com.accenture.S4.models.S4CloneProg;
import com.accenture.S4.models.S4DetailReportComplexity;
import com.accenture.S4.models.S4DetailReportRemediation;
import com.accenture.S4.models.S4Estimations;
import com.accenture.S4.models.S4HanaProfiler;
import com.accenture.S4.models.S4ImpactedIDOC;
import com.accenture.S4.models.S4ImpactedObjectList;
import com.accenture.S4.models.S4ImpactedSearchHelp;
import com.accenture.S4.models.S4ImpactedTables;
import com.accenture.S4.models.S4ImpactedTransaction;
import com.accenture.S4.models.S4ImpactedTransaction_Download;
import com.accenture.S4.models.S4InventoryList;
import com.accenture.S4.models.S4OutputMgmt;
import com.accenture.client.model.RequestForm;
import com.accenture.constant.Hana_Profiler_Constant;
import com.accenture.displaygrid.model.HanaProfile;
import com.accenture.poc.model.JqGridResponse;
import com.accenture.utility.HANAUtility;
import com.google.common.collect.Multimap;

/**
 * @author monika.mishra
 *
 */
@Controller
@SessionAttributes("User")
public class DisplayGraphS4Controller extends S4ProcessingController{/*




	@RequestMapping(value = "/downloadDetailSheet/{requestID}/{userRole}/{userAccess}", method = RequestMethod.GET)
	public synchronized String downloadOutputFile(@PathVariable("requestID") Long requestID,@PathVariable("userAccess") final String userAccess,@PathVariable("userRole") final String userRole, Model model,
			HttpServletResponse response, HttpServletRequest request, final RedirectAttributes redirectAttributes)
					throws Exception {

		String graphTemplete="";
		//CR-61: New Estimation sheet added with a separate template addition for Admin
		if ( Hana_Profiler_Constant.ACCESS_FALSE.equalsIgnoreCase(userAccess) ) {
			graphTemplete= request.getSession().getServletContext()
					.getRealPath("/staticResources/GraphTemplate/S4_Invent_Summary_Temp_Client.xlsx");
		} else if(Hana_Profiler_Constant.ACCESS_TRUE.equalsIgnoreCase(userAccess) && Hana_Profiler_Constant.CLIENT.equalsIgnoreCase(userRole)) {
			graphTemplete= request.getSession().getServletContext()
					.getRealPath("/staticResources/GraphTemplate/S4_Invent_Complete_Temp_Client.xlsx");
		}else if(Hana_Profiler_Constant.ACCESS_TRUE.equalsIgnoreCase(userAccess) && Hana_Profiler_Constant.ADMIN.equalsIgnoreCase(userRole)) {
			graphTemplete= request.getSession().getServletContext()
					.getRealPath("/staticResources/GraphTemplate/S4_Invent_Complete_Temp_Admin.xlsx");
		}

		List<S4HanaProfiler> finalOutputList=new ArrayList<S4HanaProfiler>();
		finalOutputList=getS4DaoIntf().getList(requestID, 0, 0);

		if (finalOutputList.isEmpty()) {
			redirectAttributes.addFlashAttribute("donLoadXlsxError", "No Records Found To Download");
			return "redirect:/client/requestDetails/{requestID}";
		}
		final RequestForm requestForm = getRequestDetails().getRequestObj(requestID);

		XSSFWorkbook workbook = new XSSFWorkbook(OPCPackage.open(new FileInputStream(graphTemplete)));
		SXSSFWorkbook workbookTemp = new SXSSFWorkbook(workbook);
		workbookTemp.setCompressTempFiles(true);

		//Writing Inventory
		XSSFSheet inventorySheet=workbookTemp.getXSSFWorkbook().getSheetAt(0);
		writeInventorySheet(inventorySheet,requestID);

		//Writing Impacted Object Type
		XSSFSheet impactObjSheet=workbookTemp.getXSSFWorkbook().getSheetAt(1);
		writeImpactObjSheet(impactObjSheet,requestID);
		
		


		// Writing Detail Report Sheet
		SXSSFSheet detailReportSheet = (SXSSFSheet) workbookTemp.getSheetAt(2);
		detailReportSheet.setRandomAccessWindowSize(100);
		writeDetailReportSheet(detailReportSheet,finalOutputList);
		
		// Writing Output Management Sheet
		SXSSFSheet outputMgmntSheet = (SXSSFSheet) workbookTemp.getSheetAt(3);
		outputMgmntSheet.setRandomAccessWindowSize(100);
		writeOutputMgmntSheet(outputMgmntSheet,requestID);
		
		
		
		// Writing Affect By Custom Sheet
		SXSSFSheet affectByCustomSheet = (SXSSFSheet) workbookTemp.getSheetAt(4);
		affectByCustomSheet.setRandomAccessWindowSize(100);
		writeAffectCustomSheet(affectByCustomSheet,requestID);
		
		
		
		// Writing Impacted Table Sheet
		SXSSFSheet impactedTablesSheet = (SXSSFSheet) workbookTemp.getSheetAt(5);
		detailReportSheet.setRandomAccessWindowSize(100);
		writeImpactedTableSheet(impactedTablesSheet,requestID);
			
		// Writing Impacted IDOC Sheet
		SXSSFSheet impactedIDOCSheet = (SXSSFSheet) workbookTemp.getSheetAt(6);
		detailReportSheet.setRandomAccessWindowSize(100);
		writeImpactedIDOCSheet(impactedIDOCSheet,requestID);
		
		//CR-50.0
		// Writing Impacted Transaction Sheet
		SXSSFSheet impactedTransactionSheet = (SXSSFSheet) workbookTemp.getSheetAt(7);
		detailReportSheet.setRandomAccessWindowSize(100);
		writeImpactedTransactionSheet(impactedTransactionSheet,requestID);

		// Writing Impacted Search Help
		XSSFSheet searchHelpSheet= workbookTemp.getXSSFWorkbook().getSheetAt(8);
		writeImpactedSearchSheet(searchHelpSheet,requestID);

		//Writing Append Structure Analysis
		XSSFSheet appendSheet=workbookTemp.getXSSFWorkbook().getSheetAt(9);
		writeAppendStrctrSheet(appendSheet,requestID);

		//Writing Clone Prog Analysis
		XSSFSheet cloneSheet=workbookTemp.getXSSFWorkbook().getSheetAt(10);
		writeCLoneProgSheet(cloneSheet,requestID);



		//Writing Summary
		XSSFSheet summarySheet=workbookTemp.getXSSFWorkbook().getSheetAt(12);
		writeSummarySheet(summarySheet,requestID);

		//Writing Detail Report 2
		XSSFSheet detailReport2Sheet=workbookTemp.getXSSFWorkbook().getSheetAt(13);
		writedetailReport2Sheet(detailReport2Sheet,requestID);

		//Writing Detail Report 3
		XSSFSheet detailReport3Sheet=workbookTemp.getXSSFWorkbook().getSheetAt(14);
		writedetailReport3Sheet(detailReport3Sheet,requestID);
		//Writing Estimations for client
		XSSFSheet s4MandatoryEstimatorSheet=null;
		XSSFSheet s4MandatoryUsedEstimator=null;
		XSSFSheet s4OptionalEstimator=null;
		XSSFSheet s4OptionalaUsedEstimator=null;


		//CR-61: New Estimation sheet added with a separate template addition for Admin
		if (Hana_Profiler_Constant.ACCESS_TRUE.equalsIgnoreCase(userAccess)
				&& Hana_Profiler_Constant.ADMIN.equalsIgnoreCase(userRole)) {
			s4MandatoryEstimatorSheet = workbookTemp.getXSSFWorkbook().getSheetAt(15);
			s4MandatoryUsedEstimator = workbookTemp.getXSSFWorkbook().getSheetAt(16);
			s4OptionalEstimator = workbookTemp.getXSSFWorkbook().getSheetAt(17);
			s4OptionalaUsedEstimator = workbookTemp.getXSSFWorkbook().getSheetAt(18);
			
			 wroteMandatoryEstimationsSheet(s4MandatoryEstimatorSheet,requestID);
			 wroteOptionalEstimationsSheet(s4OptionalEstimator,requestID);
			 wroteOptionalUsedEstimationsSheet(s4OptionalaUsedEstimator,requestID);
			 wroteMandatoryUsedEstimationsSheet(s4MandatoryUsedEstimator,requestID);
			
		} 
				

		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		workbookTemp.write(bos);
		bos.close();

		byte[] bytes = bos.toByteArray();
		getFileDownload()
		.downloadFile(bytes, response,
				HANAUtility.join("_", "S4 Profiler", requestForm.getClientName(),
						requestForm.getSourceVersion(), requestForm.getTargetVersion(), requestID.toString())
				+ ".xlsx");

		return null;



	}

	//CR-50.0
	private void writeImpactedTransactionSheet(SXSSFSheet impactedIDOCSheet, Long requestID) {
		int rowIndex=3;
		Row impactedTransactionRow;
		List<S4ImpactedTransaction_Download> s4ImpactedTransactionList=getGraphS4DAO().getS4ImpactedTransaction(requestID);
		if(null!= s4ImpactedTransactionList && !s4ImpactedTransactionList.isEmpty()){
			Iterator<S4ImpactedTransaction_Download> s4ImpactedTransactionItr=s4ImpactedTransactionList.iterator();
			while(s4ImpactedTransactionItr.hasNext()){

				S4ImpactedTransaction_Download impactedTransaction=s4ImpactedTransactionItr.next();
				impactedTransactionRow=impactedIDOCSheet.createRow(rowIndex);
				impactedTransactionRow.createCell(0).setCellValue(impactedTransaction.getImpactedTransaction());
				impactedTransactionRow.createCell(1).setCellValue(impactedTransaction.getDescription());
				impactedTransactionRow.createCell(2).setCellValue(impactedTransaction.getAffectedArea());
				impactedTransactionRow.createCell(3).setCellValue(impactedTransaction.getSapNotes());
				
				impactedTransactionRow.createCell(4).setCellValue(impactedTransaction.getSolSteps());
				
				rowIndex++;
			}
		}
		System.out.println("Sucessfully Wrote Impacted Transaction Sheet:::%%%%%%%");
		

		
	}

	

	private void writeImpactedIDOCSheet(SXSSFSheet impactedIDOCSheet, Long requestID) {
		int rowIndex=3;
		Row impactedIDOCRow;
		List<S4ImpactedIDOC> s4ImpactedIDOCList=getGraphS4DAO().getS4ImpactedIDOC(requestID);
		if(null!= s4ImpactedIDOCList && !s4ImpactedIDOCList.isEmpty()){
			Iterator<S4ImpactedIDOC> s4ImpactedIDOCItr=s4ImpactedIDOCList.iterator();
			while(s4ImpactedIDOCItr.hasNext()){

				S4ImpactedIDOC impactedIDOC=s4ImpactedIDOCItr.next();
				 impactedIDOCRow=impactedIDOCSheet.createRow(rowIndex);
				impactedIDOCRow.createCell(0).setCellValue(impactedIDOC.getBasicType());
				impactedIDOCRow.createCell(1).setCellValue(impactedIDOC.getExtension());
				impactedIDOCRow.createCell(2).setCellValue(impactedIDOC.getSegmentType());
				impactedIDOCRow.createCell(3).setCellValue(impactedIDOC.getPositionFieldInTable());
				
				impactedIDOCRow.createCell(4).setCellValue(impactedIDOC.getFieldName());
				impactedIDOCRow.createCell(5).setCellValue(impactedIDOC.getDataElement());
				impactedIDOCRow.createCell(6).setCellValue(impactedIDOC.getIdocDev());
				impactedIDOCRow.createCell(7).setCellValue(impactedIDOC.getDescription());
				impactedIDOCRow.createCell(8).setCellValue(impactedIDOC.getSapNote());
				impactedIDOCRow.createCell(9).setCellValue(impactedIDOC.getSolSteps());
				rowIndex++;
			}
		}
		System.out.println("Sucessfully Wrote Impacted IDOC Sheet:::%%%%%%%");
		

		
	}
	
	
	private void writeOutputMgmntSheet(SXSSFSheet outputMgmntSheet, Long requestID) {
		int rowIndex=7;
		Row outputMgmtRow;
		List<S4OutputMgmt> s4OutputMgmtList=getGraphS4DAO().getS4OutputMgmt(requestID);
		if(null!= s4OutputMgmtList && !s4OutputMgmtList.isEmpty()){
			Iterator<S4OutputMgmt> s4OutputMgmtItr=s4OutputMgmtList.iterator();
			while(s4OutputMgmtItr.hasNext()){

				S4OutputMgmt outputMgmt=s4OutputMgmtItr.next();
				 outputMgmtRow=outputMgmntSheet.createRow(rowIndex);
				outputMgmtRow.createCell(0).setCellValue(outputMgmt.getType());
				outputMgmtRow.createCell(1).setCellValue(outputMgmt.getObjName());
				
				rowIndex++;
			}
		}
		System.out.println("Sucessfully Wrote OutputMgmt Sheet:::%%%%%%%");
		
	}
	
	private void writeAffectCustomSheet(SXSSFSheet affectByCustomSheet, Long requestID) {
		int rowIndex=8;
		Row affectCustomRow;
		List<S4AffectCustomField> s4AffectCustomList=getGraphS4DAO().getS4AffectCustom(requestID);
		if(null!= s4AffectCustomList && !s4AffectCustomList.isEmpty()){
			Iterator<S4AffectCustomField> s4AffectCustomItr=s4AffectCustomList.iterator();
			while(s4AffectCustomItr.hasNext()){

				S4AffectCustomField s4AffectCustom=s4AffectCustomItr.next();
				affectCustomRow=affectByCustomSheet.createRow(rowIndex);
				affectCustomRow.createCell(0).setCellValue(s4AffectCustom.getType());
				affectCustomRow.createCell(1).setCellValue(s4AffectCustom.getObjName());
				affectCustomRow.createCell(2).setCellValue(s4AffectCustom.getTriggerObj());
				rowIndex++;
			}
		}
		System.out.println("Sucessfully Wrote Affect Custom Sheet:::%%%%%%%");
		
	}



	private void writeImpactedTableSheet(SXSSFSheet impactedTablesSheet, Long requestID) {
		int rowIndex=4;
		Row impactedTablesRow;
		List<S4ImpactedTables> s4ImpactedTablesList=getGraphS4DAO().getS4ImpactedTables(requestID);
		if(null!= s4ImpactedTablesList && !s4ImpactedTablesList.isEmpty()){
			Iterator<S4ImpactedTables> s4ImpactedTablesItr=s4ImpactedTablesList.iterator();
			while(s4ImpactedTablesItr.hasNext()){

				S4ImpactedTables impactedTables=s4ImpactedTablesItr.next();
				impactedTablesRow=impactedTablesSheet.createRow(rowIndex);
				impactedTablesRow.createCell(0).setCellValue(impactedTables.getObject());
				impactedTablesRow.createCell(1).setCellValue(impactedTables.getDescription());
				impactedTablesRow.createCell(2).setCellValue(impactedTables.getSolSteps());
				impactedTablesRow.createCell(3).setCellValue(impactedTables.getSapNotes());
				rowIndex++;
			}
		}
		System.out.println("Sucessfully Wrote Impacted Tables Sheet:::%%%%%%%");
		
	}



	private void writedetailReport3Sheet(XSSFSheet detailReport3Sheet, Long requestID) {

		int rowIndex=1;
		Row detailReportRow;
		List<S4DetailReportRemediation> detailReport3List= getGraphS4DAO().getDetailReport3List(requestID);

		if(null!=detailReport3List && !detailReport3List.isEmpty()){
			Iterator<S4DetailReportRemediation> detailReportItr=detailReport3List.iterator();
			while(detailReportItr.hasNext()){
				S4DetailReportRemediation detailReport=detailReportItr.next();

				detailReportRow=detailReport3Sheet.createRow(rowIndex);

				detailReportRow.createCell(0).setCellValue(detailReport.getType());
				detailReportRow.createCell(1).setCellValue(detailReport.getObjName());
				detailReportRow.createCell(2).setCellValue(detailReport.getUsed());
				detailReportRow.createCell(3).setCellValue(detailReport.getSubObject());
				detailReportRow.createCell(4).setCellValue(detailReport.getMethod());
				detailReportRow.createCell(5).setCellValue(detailReport.getPckg());
				detailReportRow.createCell(6).setCellValue(detailReport.getImpactedObjType());
				detailReportRow.createCell(7).setCellValue(detailReport.getLineNo());
				detailReportRow.createCell(8).setCellValue(detailReport.getStmt());

				detailReportRow.createCell(9).setCellValue(detailReport.getOperations());
				detailReportRow.createCell(10).setCellValue(detailReport.getImpactReason());
				detailReportRow.createCell(11).setCellValue(detailReport.getAffectObjDesc());
				detailReportRow.createCell(12).setCellValue(detailReport.getDescOfChange());
				detailReportRow.createCell(13).setCellValue(detailReport.getSapNotes());
				detailReportRow.createCell(14).setCellValue(detailReport.getSolutionSteps());
				detailReportRow.createCell(15).setCellValue(detailReport.getComplexity());
				detailReportRow.createCell(16).setCellValue(detailReport.getIssueCategory());
				detailReportRow.createCell(17).setCellValue(detailReport.getErrorCategory());
				detailReportRow.createCell(18).setCellValue(detailReport.getTriggerObj());
				detailReportRow.createCell(19).setCellValue(detailReport.getRemediationCategory());

				detailReportRow.createCell(20).setCellValue(detailReport.getSapSimpListChapter());
				detailReportRow.createCell(21).setCellValue(detailReport.getApplicationComponent());
				detailReportRow.createCell(22).setCellValue(detailReport.getSapSimplCategry());
				detailReportRow.createCell(23).setCellValue(detailReport.getItemArea());

				rowIndex++;
			}
			System.out.println("Sucessfully Wrote Detail Report3:::%%%%%%%");
		}

	}

	private void writedetailReport2Sheet(XSSFSheet detailReport2Sheet, Long requestID) {

		int rowIndex=1;

		List<S4DetailReportComplexity> detailReport2List= getGraphS4DAO().getDetailReport2List(requestID);

		if(null!=detailReport2List && !detailReport2List.isEmpty()){
			Iterator<S4DetailReportComplexity> detailReportItr=detailReport2List.iterator();
			while(detailReportItr.hasNext()){
				S4DetailReportComplexity detailReport=detailReportItr.next();

				Row detailReportRow=detailReport2Sheet.createRow(rowIndex);

				detailReportRow.createCell(0).setCellValue(detailReport.getType());
				detailReportRow.createCell(1).setCellValue(detailReport.getObjName());
				detailReportRow.createCell(2).setCellValue(detailReport.getUsed());
				detailReportRow.createCell(3).setCellValue(detailReport.getSubObject());
				detailReportRow.createCell(4).setCellValue(detailReport.getMethod());
				detailReportRow.createCell(5).setCellValue(detailReport.getPckg());
				detailReportRow.createCell(6).setCellValue(detailReport.getImpactedObjType());
				detailReportRow.createCell(7).setCellValue(detailReport.getLineNo());
				detailReportRow.createCell(8).setCellValue(detailReport.getStmt());

				detailReportRow.createCell(9).setCellValue(detailReport.getOperations());
				detailReportRow.createCell(10).setCellValue(detailReport.getImpactReason());
				detailReportRow.createCell(11).setCellValue(detailReport.getAffectObjDesc());
				detailReportRow.createCell(12).setCellValue(detailReport.getDescOfChange());
				detailReportRow.createCell(13).setCellValue(detailReport.getSapNotes());
				detailReportRow.createCell(14).setCellValue(detailReport.getSolutionSteps());
				detailReportRow.createCell(15).setCellValue(detailReport.getComplexity());
				detailReportRow.createCell(16).setCellValue(detailReport.getIssueCategory());
				detailReportRow.createCell(17).setCellValue(detailReport.getErrorCategory());
				detailReportRow.createCell(18).setCellValue(detailReport.getTriggerObj());
				detailReportRow.createCell(19).setCellValue(detailReport.getRemediationCategory());

				detailReportRow.createCell(20).setCellValue(detailReport.getSapSimpListChapter());
				detailReportRow.createCell(21).setCellValue(detailReport.getApplicationComponent());
				detailReportRow.createCell(22).setCellValue(detailReport.getSapSimplCategry());
				detailReportRow.createCell(23).setCellValue(detailReport.getItemArea());

				rowIndex++;
			}
			System.out.println("Sucessfully Wrote Detail Report2:::%%%%%%%");
		}

	}



	private void writeImpactObjSheet(XSSFSheet impactObjSheet, Long requestID) {
		int rowIndex=4;
		List<S4ImpactedObjectList> impactObjList=getGraphS4DAO().getImpactedObjList(requestID)	;	
		if(null!=impactObjList && !impactObjList.isEmpty()){
			Iterator<S4ImpactedObjectList> impactObjItr=impactObjList.iterator();
			while(impactObjItr.hasNext()){

				S4ImpactedObjectList impactObj=impactObjItr.next();
				Row impactObjRow=impactObjSheet.createRow(rowIndex);

				impactObjRow.createCell(0).setCellValue(impactObj.getObjType());
				impactObjRow.createCell(1).setCellValue(impactObj.getObjName());
				impactObjRow.createCell(2).setCellValue(impactObj.getUsage());
				rowIndex++;
			}
		}
		System.out.println("Sucessfully Wrote Impact Sheet:::%%%%%%%");
	}


	private void writeInventorySheet(XSSFSheet inventorySheet, Long requestID) {
		int rowIndex=4;
		List<S4InventoryList> inventoryList= getGraphS4DAO().getInventory(requestID);

		if(null!= inventoryList && !inventoryList.isEmpty()){
			Iterator<S4InventoryList> inventoryItr=inventoryList.iterator();
			while(inventoryItr.hasNext()){

				S4InventoryList inventory=inventoryItr.next();
				Row inventryRow=inventorySheet.createRow(rowIndex);

				inventryRow.createCell(0).setCellValue(inventory.getObjType());
				inventryRow.createCell(1).setCellValue(inventory.getObjName());
				inventryRow.createCell(2).setCellValue(inventory.getUsage());
				rowIndex++;
			}
		}
		System.out.println("Sucessfully Wrote Inventory Sheet:::%%%%%%%");
	}

	private void writeCLoneProgSheet(XSSFSheet cloneSheet, Long requestID) {
		int rowIndex=3;
		List<S4CloneProg> cloneProgList=getGraphS4DAO().getCloneProg(requestID);
		if(null!= cloneProgList && !cloneProgList.isEmpty()){
			
			Iterator<S4CloneProg> cloneProgITR=cloneProgList.iterator();
			while(cloneProgITR.hasNext()){
				S4CloneProg s4CloneProg=cloneProgITR.next();
				Row cloneRow=cloneSheet.createRow(rowIndex);
				cloneRow.createCell(1).setCellValue(s4CloneProg.getImpactedProg());
				cloneRow.createCell(2).setCellValue(s4CloneProg.getCloneProg());
				cloneRow.createCell(3).setCellValue(s4CloneProg.getDesc());
				cloneRow.createCell(4).setCellValue(s4CloneProg.getSolStep());
				cloneRow.createCell(5).setCellValue(s4CloneProg.getRelatedNotes());
				rowIndex++;
			}
		}
		System.out.println("Sucessfully Wrote Clone Strctr Sheet:::%%%%%%%");
	}

	private void writeAppendStrctrSheet(XSSFSheet appendSheet, Long requestID) {
		int rowIndex=3;
		List<S4AppendStructureAnalysis> appendStrctrList=getGraphS4DAO().getAppendStrctr(requestID);
		if(null!= appendStrctrList && !appendStrctrList.isEmpty()){
			Iterator<S4AppendStructureAnalysis> appndStrctrItr=appendStrctrList.iterator();
			System.out.println("appendStrctrList.size()" + appendStrctrList.size());
			while(appndStrctrItr.hasNext()){

				S4AppendStructureAnalysis appndStrctr=appndStrctrItr.next();
				Row apendStrctrRow=appendSheet.createRow(rowIndex);
				apendStrctrRow.createCell(0).setCellValue(appndStrctr.getTableName());
				apendStrctrRow.createCell(1).setCellValue(appndStrctr.getFieldName());
				apendStrctrRow.createCell(2).setCellValue(appndStrctr.getNameOfInclude());

				rowIndex++;

			}
		}
		System.out.println("Sucessfully Wrote writeAppend Strctr Sheet:::%%%%%%%");

	}

	private void writeImpactedSearchSheet(XSSFSheet searchHelpSheet,final Long requestID) {
		int rowIndex=3;
		List<S4ImpactedSearchHelp> s4ImpactedSearchList=getGraphS4DAO().getImpactedSearch(requestID);
		if(null !=s4ImpactedSearchList  && !s4ImpactedSearchList.isEmpty()){
			Iterator<S4ImpactedSearchHelp> s4SearchItr=s4ImpactedSearchList.iterator();
			while(s4SearchItr.hasNext()){
				Row searchHelpRow=searchHelpSheet.createRow(rowIndex);
				for(int cellIndex=0;cellIndex<3;cellIndex++){
					S4ImpactedSearchHelp s4ImpactSearchHelp=s4SearchItr.next();
					searchHelpRow.createCell(cellIndex).setCellValue(s4ImpactSearchHelp.getSearchData());
				}
				rowIndex++;
			}
		}
		System.out.println("Sucessfully Wrote writeImpactedSearchSheet:::%%%%%%%");

	}

	private void writeDetailReportSheet(SXSSFSheet detailReportSheet, List<S4HanaProfiler> finalOutputList) {

		for(int i=1;i< finalOutputList.size();i++){
			Row detailReportRow=detailReportSheet.createRow(i);

			detailReportRow.createCell(0).setCellValue(finalOutputList.get(i).getType());
			detailReportRow.createCell(1).setCellValue(finalOutputList.get(i).getObjName());
			detailReportRow.createCell(2).setCellValue(finalOutputList.get(i).getUsed());
			detailReportRow.createCell(3).setCellValue(finalOutputList.get(i).getSubObject());
			detailReportRow.createCell(4).setCellValue(finalOutputList.get(i).getMethod());
			detailReportRow.createCell(5).setCellValue(finalOutputList.get(i).getPckg());
			detailReportRow.createCell(6).setCellValue(finalOutputList.get(i).getImpactedObjType());
			detailReportRow.createCell(7).setCellValue(finalOutputList.get(i).getLineNo());
			detailReportRow.createCell(8).setCellValue(finalOutputList.get(i).getStmt());

			detailReportRow.createCell(9).setCellValue(finalOutputList.get(i).getOperations());
			detailReportRow.createCell(10).setCellValue(finalOutputList.get(i).getImpactReason());
			detailReportRow.createCell(11).setCellValue(finalOutputList.get(i).getAffectObjDesc());
			detailReportRow.createCell(12).setCellValue(finalOutputList.get(i).getDescOfChange());
			detailReportRow.createCell(13).setCellValue(finalOutputList.get(i).getSapNotes());
			detailReportRow.createCell(14).setCellValue(finalOutputList.get(i).getSolutionSteps());
			detailReportRow.createCell(15).setCellValue(finalOutputList.get(i).getComplexity());
			detailReportRow.createCell(16).setCellValue(finalOutputList.get(i).getIssueCategory());
			detailReportRow.createCell(17).setCellValue(finalOutputList.get(i).getErrorCategory());
			detailReportRow.createCell(18).setCellValue(finalOutputList.get(i).getTriggerObj());
			detailReportRow.createCell(19).setCellValue(finalOutputList.get(i).getRemediationCategory());

			detailReportRow.createCell(20).setCellValue(finalOutputList.get(i).getSapSimpListChapter());
			detailReportRow.createCell(21).setCellValue(finalOutputList.get(i).getApplicationComponent());
			detailReportRow.createCell(22).setCellValue(finalOutputList.get(i).getSapSimplCategry());
			detailReportRow.createCell(23).setCellValue(finalOutputList.get(i).getItemArea());
			
			//CR-26
			detailReportRow.createCell(24).setCellValue(finalOutputList.get(i).getTotalScannedLine());
			//CR-23
			detailReportRow.createCell(25).setCellValue(finalOutputList.get(i).getAffectedArea());

		}
		System.out.println("Sucessfully Wrote Detail Report:::%%%%%%%");
	}

	private void writeSummarySheet(XSSFSheet summarySheet, Long requestID) {
		writeSummaryImpctObjGrph(summarySheet,requestID);
		writeSummaryObjTypeGrph(summarySheet,requestID);
		writeSummarydetail3RemediGrph(summarySheet,requestID);
		writeSummaryRemediGrph(summarySheet,requestID);
		writeSummarydetail3RemediComplxGrph(summarySheet,requestID);
		writeSummaryRemediComplxGrph(summarySheet,requestID);
		writeSummarydetail2ItemAreaGrph(summarySheet,requestID);
		writeSummaryItemAreaGrph(summarySheet,requestID);
		writeSummaryDetail3RemediIssueGrph(summarySheet,requestID);
		writeSummaryRemediIssueGrph(summarySheet,requestID);
		writeSummaryEstimateEffrtGrph(summarySheet,requestID);
		writeSummaryRemediComplexUsedGrph(summarySheet,requestID);
		writeSummaryGrph(summarySheet,requestID);
	}

	private void writeSummaryImpctObjGrph(XSSFSheet summarySheet, Long requestID){
		int rowIndex=2;
		int grandTotal=0;
		Row summarySheetRow=null;
		Map<String, Integer> impactObjTypeMap=getGraphS4DAO().getCountImpactObjType(requestID);

		for(Map.Entry<String, Integer> entry:impactObjTypeMap.entrySet()){
			summarySheetRow=summarySheet.createRow(rowIndex);
			summarySheetRow.createCell(9).setCellValue(entry.getKey());
			summarySheetRow.createCell(10).setCellValue(entry.getValue());
			grandTotal=grandTotal+entry.getValue();
			rowIndex=rowIndex+1;
		}
		summarySheetRow=summarySheet.createRow(rowIndex);
		summarySheetRow.createCell(9).setCellValue("Grand Total");
		summarySheetRow.createCell(10).setCellValue(grandTotal);

	}

	private void writeSummaryObjTypeGrph(XSSFSheet summarySheet, Long requestID){
		int rowIndex=26;
		int grandTotal=0;
		Row summarySheetRow=null;
		Map<String, Integer> objTypeMap=getGraphS4DAO().getCountObjType(requestID);

		for(Map.Entry<String, Integer> entry:objTypeMap.entrySet()){
			summarySheetRow=summarySheet.createRow(rowIndex);
			summarySheetRow.createCell(9).setCellValue(entry.getKey());
			summarySheetRow.createCell(10).setCellValue(entry.getValue());
			grandTotal=grandTotal+entry.getValue();
			rowIndex=rowIndex+1;
		}
		summarySheetRow=summarySheet.createRow(rowIndex);
		summarySheetRow.createCell(9).setCellValue("Grand Total");
		summarySheetRow.createCell(10).setCellValue(grandTotal);

	}

	private void writeSummarydetail3RemediGrph(XSSFSheet summarySheet, Long requestID){
		int rowIndex=52;
		int grandTotal=0;
		Row summarySheetRow=null;
		Map<String, Integer> remediMap=getGraphS4DAO().getDetail3CountRemediCategry(requestID);

		for(Map.Entry<String, Integer> entry:remediMap.entrySet()){
			summarySheetRow=summarySheet.createRow(rowIndex);
			summarySheetRow.createCell(9).setCellValue(entry.getKey());
			summarySheetRow.createCell(10).setCellValue(entry.getValue());
			grandTotal=grandTotal+entry.getValue();
			rowIndex=rowIndex+1;
		}
		summarySheetRow=summarySheet.createRow(rowIndex);
		summarySheetRow.createCell(9).setCellValue("Grand Total");
		summarySheetRow.createCell(10).setCellValue(grandTotal);

	}

	private void writeSummaryRemediGrph(XSSFSheet summarySheet, Long requestID){
		int rowIndex=76;
		int grandTotal=0;
		Row summarySheetRow=null;
		Map<String, Integer> remediMap=getGraphS4DAO().getCountRemediCategry(requestID);

		for(Map.Entry<String, Integer> entry:remediMap.entrySet()){
			summarySheetRow=summarySheet.createRow(rowIndex);
			summarySheetRow.createCell(9).setCellValue(entry.getKey());
			summarySheetRow.createCell(10).setCellValue(entry.getValue());
			grandTotal=grandTotal+entry.getValue();
			rowIndex=rowIndex+1;
		}
		summarySheetRow=summarySheet.createRow(rowIndex);
		summarySheetRow.createCell(9).setCellValue("Grand Total");
		summarySheetRow.createCell(10).setCellValue(grandTotal);

	}


	private void writeSummarydetail3RemediComplxGrph(XSSFSheet summarySheet, Long requestID){
		int rowIndex=100;
		int grandTotal=0;
		int total=0;
		Row summarySheetRow=null;
		Row summarySheetOldRow=null;
		Map<String, Map<String, Integer>> remediComplxMap=getGraphS4DAO().getDetail3RemediComplexCount(requestID);

		for(Map.Entry<String ,Map<String,Integer>> entryMap: remediComplxMap.entrySet()){
			summarySheetRow=summarySheet.createRow(rowIndex);
			summarySheetOldRow=summarySheetRow;
			summarySheetRow.createCell(9).setCellValue(entryMap.getKey());
			rowIndex=rowIndex+1;
			Map<String,Integer> complxCountMap=entryMap.getValue();
			for(Map.Entry<String, Integer> entry:complxCountMap.entrySet()){
				summarySheetRow=summarySheet.createRow(rowIndex);
				summarySheetRow.createCell(9).setCellValue(entry.getKey());
				summarySheetRow.createCell(10).setCellValue(entry.getValue());
				total=total+entry.getValue();
				grandTotal=grandTotal+entry.getValue();
				rowIndex=rowIndex+1;
			}
			summarySheetOldRow.createCell(10).setCellValue(total);
			total=0;
		}
		summarySheetRow=summarySheet.createRow(rowIndex);
		summarySheetRow.createCell(9).setCellValue("Grand Total");
		summarySheetRow.createCell(10).setCellValue(grandTotal);

	}


	private void writeSummaryRemediComplxGrph(XSSFSheet summarySheet, Long requestID){
		int rowIndex=124;
		int grandTotal=0;
		int total=0;
		Row summarySheetRow=null;
		Row summarySheetOldRow=null;
		Map<String, Map<String, Integer>> remediComplxMap=getGraphS4DAO().getRemediComplexCount(requestID);

		for(Map.Entry<String ,Map<String,Integer>> entryMap: remediComplxMap.entrySet()){
			summarySheetRow=summarySheet.createRow(rowIndex);
			summarySheetOldRow=summarySheetRow;
			summarySheetRow.createCell(9).setCellValue(entryMap.getKey());
			rowIndex=rowIndex+1;
			Map<String,Integer> complxCountMap=entryMap.getValue();
			for(Map.Entry<String, Integer> entry:complxCountMap.entrySet()){
				summarySheetRow=summarySheet.createRow(rowIndex);
				summarySheetRow.createCell(9).setCellValue(entry.getKey());
				summarySheetRow.createCell(10).setCellValue(entry.getValue());
				total=total+entry.getValue();
				grandTotal=grandTotal+entry.getValue();
				rowIndex=rowIndex+1;
			}
			summarySheetOldRow.createCell(10).setCellValue(total);
			total=0;
		}
		summarySheetRow=summarySheet.createRow(rowIndex);
		summarySheetRow.createCell(9).setCellValue("Grand Total");
		summarySheetRow.createCell(10).setCellValue(grandTotal);

	}


	private void writeSummarydetail2ItemAreaGrph(XSSFSheet summarySheet, Long requestID){
		int rowIndex=153;
		int grandTotal=0;
		Row summarySheetRow=null;
		Map<String, Integer> itemAreaMap=getGraphS4DAO().getCountDetailItemArea(requestID);

		for(Map.Entry<String, Integer> entry:itemAreaMap.entrySet()){
			summarySheetRow=summarySheet.createRow(rowIndex);
			summarySheetRow.createCell(9).setCellValue(entry.getKey());
			summarySheetRow.createCell(10).setCellValue(entry.getValue());
			grandTotal=grandTotal+entry.getValue();
			rowIndex=rowIndex+1;
		}
		summarySheetRow=summarySheet.createRow(rowIndex);
		summarySheetRow.createCell(9).setCellValue("Grand Total");
		summarySheetRow.createCell(10).setCellValue(grandTotal);

	}

	private void writeSummaryItemAreaGrph(XSSFSheet summarySheet, Long requestID){
		int rowIndex=180;
		int grandTotal=0;
		Row summarySheetRow=null;
		Map<String, Integer> itemAreaMap=getGraphS4DAO().getCountItemArea(requestID);

		for(Map.Entry<String, Integer> entry:itemAreaMap.entrySet()){
			summarySheetRow=summarySheet.createRow(rowIndex);
			summarySheetRow.createCell(9).setCellValue(entry.getKey());
			summarySheetRow.createCell(10).setCellValue(entry.getValue());
			grandTotal=grandTotal+entry.getValue();
			rowIndex=rowIndex+1;
		}
		summarySheetRow=summarySheet.createRow(rowIndex);
		summarySheetRow.createCell(9).setCellValue("Grand Total");
		summarySheetRow.createCell(10).setCellValue(grandTotal);

	}

	private void writeSummaryDetail3RemediIssueGrph(XSSFSheet summarySheet, Long requestID){
		int rowIndex=215;
		int grandTotal=0;
		int total=0;
		Row summarySheetRow=null;
		Row summarySheetOldRow=null;
		Map<String, Map<String, Integer>> remediIssueMap=getGraphS4DAO().getDetail3RemediIssueCategoryCount(requestID);

		for(Map.Entry<String ,Map<String,Integer>> entryMap: remediIssueMap.entrySet()){
			summarySheetRow=summarySheet.createRow(rowIndex);
			summarySheetOldRow=summarySheetRow;
			summarySheetRow.createCell(9).setCellValue(entryMap.getKey());
			rowIndex=rowIndex+1;
			Map<String,Integer> issueCountMap=entryMap.getValue();
			for(Map.Entry<String, Integer> entry:issueCountMap.entrySet()){
				summarySheetRow=summarySheet.createRow(rowIndex);
				summarySheetRow.createCell(9).setCellValue(entry.getKey());
				summarySheetRow.createCell(10).setCellValue(entry.getValue());
				total=total+entry.getValue();
				grandTotal=grandTotal+entry.getValue();
				rowIndex=rowIndex+1;
			}
			summarySheetOldRow.createCell(10).setCellValue(total);
			total=0;
		}
		summarySheetRow=summarySheet.createRow(rowIndex);
		summarySheetRow.createCell(9).setCellValue("Grand Total");
		summarySheetRow.createCell(10).setCellValue(grandTotal);

	}


	private void writeSummaryRemediIssueGrph(XSSFSheet summarySheet, Long requestID){
		int rowIndex=262;
		int grandTotal=0;
		int total=0;
		Row summarySheetRow=null;
		Row summarySheetOldRow=null;
		Map<String, Map<String, Integer>> remediIssueMap=getGraphS4DAO().getRemediIssueCategoryCount(requestID);

		for(Map.Entry<String ,Map<String,Integer>> entryMap: remediIssueMap.entrySet()){
			summarySheetRow=summarySheet.createRow(rowIndex);
			summarySheetOldRow=summarySheetRow;
			summarySheetRow.createCell(9).setCellValue(entryMap.getKey());
			rowIndex=rowIndex+1;
			Map<String,Integer> issueCountMap=entryMap.getValue();
			for(Map.Entry<String, Integer> entry:issueCountMap.entrySet()){
				summarySheetRow=summarySheet.createRow(rowIndex);
				summarySheetRow.createCell(9).setCellValue(entry.getKey());
				summarySheetRow.createCell(10).setCellValue(entry.getValue());
				total=total+entry.getValue();
				grandTotal=grandTotal+entry.getValue();
				rowIndex=rowIndex+1;
			}
			summarySheetOldRow.createCell(10).setCellValue(total);
			total=0;
		}
		summarySheetRow=summarySheet.createRow(rowIndex);
		summarySheetRow.createCell(9).setCellValue("Grand Total");
		summarySheetRow.createCell(10).setCellValue(grandTotal);

	}


	private void writeSummaryEstimateEffrtGrph(XSSFSheet summarySheet, Long requestID){
		int rowIndex=309;
		int grandTotal=0;
		int total=0;
		Row summarySheetRow=null;
		Row summarySheetOldRow=null;
		Map<String, Map<String, Integer>> remediComplxMap=getGraphS4DAO().getDetail3RemediComplexCount(requestID);

		for(Map.Entry<String ,Map<String,Integer>> entryMap: remediComplxMap.entrySet()){
			summarySheetRow=summarySheet.createRow(rowIndex);
			summarySheetOldRow=summarySheetRow;
			summarySheetRow.createCell(9).setCellValue(entryMap.getKey());
			rowIndex=rowIndex+1;
			Map<String,Integer> complxCountMap=entryMap.getValue();
			for(Map.Entry<String, Integer> entry:complxCountMap.entrySet()){
				summarySheetRow=summarySheet.createRow(rowIndex);
				summarySheetRow.createCell(9).setCellValue(entry.getKey());
				summarySheetRow.createCell(10).setCellValue(entry.getValue());
				total=total+entry.getValue();
				grandTotal=grandTotal+entry.getValue();
				rowIndex=rowIndex+1;
			}
			summarySheetOldRow.createCell(10).setCellValue(total);
			total=0;
		}
		summarySheetRow=summarySheet.createRow(rowIndex);
		summarySheetRow.createCell(9).setCellValue("Grand Total");
		summarySheetRow.createCell(10).setCellValue(grandTotal);

	}


	private void writeSummaryRemediComplexUsedGrph(XSSFSheet summarySheet, Long requestID){
		int rowIndex=343;
		int grandTotal=0;
		int total=0;
		Row summarySheetRow=null;
		Row summarySheetOldRow=null;
		Map<String, Map<String, Integer>> remediComplxMap=getGraphS4DAO().getDetail3RemedicomplexUsedCount(requestID);

		for(Map.Entry<String ,Map<String,Integer>> entryMap: remediComplxMap.entrySet()){
			summarySheetRow=summarySheet.createRow(rowIndex);
			summarySheetOldRow=summarySheetRow;
			summarySheetRow.createCell(9).setCellValue(entryMap.getKey());
			rowIndex=rowIndex+1;
			Map<String,Integer> complxCountMap=entryMap.getValue();
			for(Map.Entry<String, Integer> entry:complxCountMap.entrySet()){
				summarySheetRow=summarySheet.createRow(rowIndex);
				summarySheetRow.createCell(9).setCellValue(entry.getKey());
				summarySheetRow.createCell(10).setCellValue(entry.getValue());
				total=total+entry.getValue();
				grandTotal=grandTotal+entry.getValue();
				rowIndex=rowIndex+1;
			}
			summarySheetOldRow.createCell(10).setCellValue(total);
			total=0;
		}
		summarySheetRow=summarySheet.createRow(rowIndex);
		summarySheetRow.createCell(9).setCellValue("Grand Total");
		summarySheetRow.createCell(10).setCellValue(grandTotal);

	}

	private void writeSummaryGrph(XSSFSheet summarySheet, Long requestID){

		int invntryObjTotal=0;

		Map<String, Integer> invntryObjTypeMap=getGraphS4DAO().getCountInventoryType(requestID);
		summarySheet.getRow(367).getCell(1).setCellValue(invntryObjTypeMap.containsKey("CLAS")?(invntryObjTypeMap.get("CLAS")) :0);
		summarySheet.getRow(368).getCell(1).setCellValue(invntryObjTypeMap.containsKey("ENHO")?(invntryObjTypeMap.get("ENHO")) :0);
		summarySheet.getRow(369).getCell(1).setCellValue(invntryObjTypeMap.containsKey("ENHC")?(invntryObjTypeMap.get("ENHC")) :0);
		summarySheet.getRow(370).getCell(1).setCellValue(invntryObjTypeMap.containsKey("ENHS")?(invntryObjTypeMap.get("ENHS")) :0);
		summarySheet.getRow(371).getCell(1).setCellValue(invntryObjTypeMap.containsKey("FUGR")?(invntryObjTypeMap.get("FUGR")) :0);
		summarySheet.getRow(372).getCell(1).setCellValue(invntryObjTypeMap.containsKey("PROG")?(invntryObjTypeMap.get("PROG")) :0);
		summarySheet.getRow(373).getCell(1).setCellValue(invntryObjTypeMap.containsKey("INDE")?(invntryObjTypeMap.get("INDE")) :0);
		summarySheet.getRow(374).getCell(1).setCellValue(invntryObjTypeMap.containsKey("WDYN")?(invntryObjTypeMap.get("WDYN")) :0);
		summarySheet.getRow(375).getCell(1).setCellValue(invntryObjTypeMap.containsKey("VIEW")?(invntryObjTypeMap.get("VIEW")) :0);

		invntryObjTotal=(invntryObjTypeMap.containsKey("CLAS")?(invntryObjTypeMap.get("CLAS")) :0)+
				(invntryObjTypeMap.containsKey("ENHO")?(invntryObjTypeMap.get("ENHO")) :0)+
				(invntryObjTypeMap.containsKey("ENHC")?(invntryObjTypeMap.get("ENHC")) :0)+
				(invntryObjTypeMap.containsKey("ENHS")?(invntryObjTypeMap.get("ENHS")) :0)+
				(invntryObjTypeMap.containsKey("FUGR")?(invntryObjTypeMap.get("FUGR")) :0)+
				(invntryObjTypeMap.containsKey("PROG")?(invntryObjTypeMap.get("PROG")) :0)+
				(invntryObjTypeMap.containsKey("INDE")?(invntryObjTypeMap.get("INDE")) :0)+
				(invntryObjTypeMap.containsKey("WDYN")?(invntryObjTypeMap.get("WDYN")) :0)+
				(invntryObjTypeMap.containsKey("VIEW")?(invntryObjTypeMap.get("VIEW")) :0);

		summarySheet.getRow(376).getCell(1).setCellValue(invntryObjTotal);

		Map<String, Integer> invntryObjTypeUsedMap=getGraphS4DAO().getCountInventoryTypeUsed(requestID);
		summarySheet.getRow(367).getCell(2).setCellValue(invntryObjTypeUsedMap.containsKey("CLAS")?(invntryObjTypeUsedMap.get("CLAS")) :0);
		summarySheet.getRow(368).getCell(2).setCellValue(invntryObjTypeUsedMap.containsKey("ENHO")?(invntryObjTypeUsedMap.get("ENHO")) :0);
		summarySheet.getRow(369).getCell(2).setCellValue(invntryObjTypeUsedMap.containsKey("ENHC")?(invntryObjTypeUsedMap.get("ENHC")) :0);
		summarySheet.getRow(370).getCell(2).setCellValue(invntryObjTypeUsedMap.containsKey("ENHS")?(invntryObjTypeUsedMap.get("ENHS")) :0);
		summarySheet.getRow(371).getCell(2).setCellValue(invntryObjTypeUsedMap.containsKey("FUGR")?(invntryObjTypeUsedMap.get("FUGR")) :0);
		summarySheet.getRow(372).getCell(2).setCellValue(invntryObjTypeUsedMap.containsKey("PROG")?(invntryObjTypeUsedMap.get("PROG")) :0);
		summarySheet.getRow(373).getCell(2).setCellValue(invntryObjTypeUsedMap.containsKey("INDE")?(invntryObjTypeUsedMap.get("INDE")) :0);
		summarySheet.getRow(374).getCell(2).setCellValue(invntryObjTypeUsedMap.containsKey("WDYN")?(invntryObjTypeUsedMap.get("WDYN")) :0);
		summarySheet.getRow(375).getCell(2).setCellValue(invntryObjTypeUsedMap.containsKey("VIEW")?(invntryObjTypeUsedMap.get("VIEW")) :0);

		int invntryObjUsedTotal=(invntryObjTypeUsedMap.containsKey("CLAS")?(invntryObjTypeUsedMap.get("CLAS")) :0)+
				(invntryObjTypeUsedMap.containsKey("ENHO")?(invntryObjTypeUsedMap.get("ENHO")) :0)+
				(invntryObjTypeUsedMap.containsKey("ENHC")?(invntryObjTypeUsedMap.get("ENHC")) :0)+
				(invntryObjTypeUsedMap.containsKey("ENHS")?(invntryObjTypeUsedMap.get("ENHS")) :0)+
				(invntryObjTypeUsedMap.containsKey("FUGR")?(invntryObjTypeUsedMap.get("FUGR")) :0)+
				(invntryObjTypeUsedMap.containsKey("PROG")?(invntryObjTypeUsedMap.get("PROG")) :0)+
				(invntryObjTypeUsedMap.containsKey("INDE")?(invntryObjTypeUsedMap.get("INDE")) :0)+
				(invntryObjTypeUsedMap.containsKey("WDYN")?(invntryObjTypeUsedMap.get("WDYN")) :0)+
				(invntryObjTypeUsedMap.containsKey("VIEW")?(invntryObjTypeUsedMap.get("VIEW")) :0);

		summarySheet.getRow(376).getCell(2).setCellValue(invntryObjUsedTotal);


		Map<String, Integer> impactObjTypeMap=getGraphS4DAO().getCountDetailType(requestID);
		summarySheet.getRow(367).getCell(3).setCellValue(impactObjTypeMap.containsKey("CLAS")?(impactObjTypeMap.get("CLAS")) :0);
		summarySheet.getRow(368).getCell(3).setCellValue(impactObjTypeMap.containsKey("ENHO")?(impactObjTypeMap.get("ENHO")) :0);
		summarySheet.getRow(369).getCell(3).setCellValue(impactObjTypeMap.containsKey("ENHC")?(impactObjTypeMap.get("ENHC")) :0);
		summarySheet.getRow(370).getCell(3).setCellValue(impactObjTypeMap.containsKey("ENHS")?(impactObjTypeMap.get("ENHS")) :0);
		summarySheet.getRow(371).getCell(3).setCellValue(impactObjTypeMap.containsKey("FUGR")?(impactObjTypeMap.get("FUGR")) :0);
		summarySheet.getRow(372).getCell(3).setCellValue(impactObjTypeMap.containsKey("PROG")?(impactObjTypeMap.get("PROG")) :0);
		summarySheet.getRow(373).getCell(3).setCellValue(impactObjTypeMap.containsKey("INDE")?(impactObjTypeMap.get("INDE")) :0);
		summarySheet.getRow(374).getCell(3).setCellValue(impactObjTypeMap.containsKey("WDYN")?(impactObjTypeMap.get("WDYN")) :0);
		summarySheet.getRow(375).getCell(3).setCellValue(impactObjTypeMap.containsKey("VIEW")?(impactObjTypeMap.get("VIEW")) :0);

		int impactObjTotal=(impactObjTypeMap.containsKey("CLAS")?(impactObjTypeMap.get("CLAS")) :0)+
				(impactObjTypeMap.containsKey("ENHO")?(impactObjTypeMap.get("ENHO")) :0)+
				(impactObjTypeMap.containsKey("ENHC")?(impactObjTypeMap.get("ENHC")) :0)+
				(impactObjTypeMap.containsKey("ENHS")?(impactObjTypeMap.get("ENHS")) :0)+
				(impactObjTypeMap.containsKey("FUGR")?(impactObjTypeMap.get("FUGR")) :0)+
				(impactObjTypeMap.containsKey("PROG")?(impactObjTypeMap.get("PROG")) :0)+
				(impactObjTypeMap.containsKey("INDE")?(impactObjTypeMap.get("INDE")) :0)+
				(impactObjTypeMap.containsKey("WDYN")?(impactObjTypeMap.get("WDYN")) :0)+
				(impactObjTypeMap.containsKey("VIEW")?(impactObjTypeMap.get("VIEW")) :0);

		summarySheet.getRow(376).getCell(3).setCellValue(impactObjTotal);


		Map<String, Integer> impactObjTypeUsedMap=getGraphS4DAO().getCountDetailTypeUsed(requestID);
		summarySheet.getRow(367).getCell(4).setCellValue(impactObjTypeUsedMap.containsKey("CLAS")?(impactObjTypeUsedMap.get("CLAS")) :0);
		summarySheet.getRow(368).getCell(4).setCellValue(impactObjTypeUsedMap.containsKey("ENHO")?(impactObjTypeUsedMap.get("ENHO")) :0);
		summarySheet.getRow(369).getCell(4).setCellValue(impactObjTypeUsedMap.containsKey("ENHC")?(impactObjTypeUsedMap.get("ENHC")) :0);
		summarySheet.getRow(370).getCell(4).setCellValue(impactObjTypeUsedMap.containsKey("ENHS")?(impactObjTypeUsedMap.get("ENHS")) :0);
		summarySheet.getRow(371).getCell(4).setCellValue(impactObjTypeUsedMap.containsKey("FUGR")?(impactObjTypeUsedMap.get("FUGR")) :0);
		summarySheet.getRow(372).getCell(4).setCellValue(impactObjTypeUsedMap.containsKey("PROG")?(impactObjTypeUsedMap.get("PROG")) :0);
		summarySheet.getRow(373).getCell(4).setCellValue(impactObjTypeUsedMap.containsKey("INDE")?(impactObjTypeUsedMap.get("INDE")) :0);
		summarySheet.getRow(374).getCell(4).setCellValue(impactObjTypeUsedMap.containsKey("WDYN")?(impactObjTypeUsedMap.get("WDYN")) :0);
		summarySheet.getRow(375).getCell(4).setCellValue(impactObjTypeUsedMap.containsKey("VIEW")?(impactObjTypeUsedMap.get("VIEW")) :0);

		int impactObjUsedTotal=(impactObjTypeUsedMap.containsKey("CLAS")?(impactObjTypeUsedMap.get("CLAS")) :0)+
				(impactObjTypeUsedMap.containsKey("ENHO")?(impactObjTypeUsedMap.get("ENHO")) :0)+
				(impactObjTypeUsedMap.containsKey("ENHC")?(impactObjTypeUsedMap.get("ENHC")) :0)+
				(impactObjTypeUsedMap.containsKey("ENHS")?(impactObjTypeUsedMap.get("ENHS")) :0)+
				(impactObjTypeUsedMap.containsKey("FUGR")?(impactObjTypeUsedMap.get("FUGR")) :0)+
				(impactObjTypeUsedMap.containsKey("PROG")?(impactObjTypeUsedMap.get("PROG")) :0)+
				(impactObjTypeUsedMap.containsKey("INDE")?(impactObjTypeUsedMap.get("INDE")) :0)+
				(impactObjTypeUsedMap.containsKey("WDYN")?(impactObjTypeUsedMap.get("WDYN")) :0)+
				(impactObjTypeUsedMap.containsKey("VIEW")?(impactObjTypeUsedMap.get("VIEW")) :0);

		summarySheet.getRow(376).getCell(4).setCellValue(impactObjUsedTotal);

	}
	
	//CR-61: New Estimation sheet added with a separate template addition for Admin
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/downloadS4EstimatorAssumptions/{requestID}", method = RequestMethod.GET)
	public synchronized String downloadEstimatorAssumptions(@PathVariable("requestID") Long requestID, Model model,
			HttpServletResponse response, HttpServletRequest request, final RedirectAttributes redirectAttributes)
			throws Exception {

		String graphTemplete = request.getSession().getServletContext()
				.getRealPath("/staticResources/GraphTemplate/S4_Invent_Estimation_Temp_Client.xlsx");

		final RequestForm requestForm = getRequestDetails().getRequestObj(requestID);

		XSSFWorkbook workbook = new XSSFWorkbook(OPCPackage.open(new FileInputStream(graphTemplete)));
		@SuppressWarnings("resource")
		SXSSFWorkbook workbookTemp = new SXSSFWorkbook(workbook);
		workbookTemp.setCompressTempFiles(true);

		
		XSSFSheet s4MandatoryEstimatorSheet=null;
		XSSFSheet s4MandatoryUsedEstimator=null;
		XSSFSheet s4OptionalEstimator=null;
		XSSFSheet s4OptionalaUsedEstimator=null;


			s4MandatoryEstimatorSheet = workbookTemp.getXSSFWorkbook().getSheetAt(0);
			s4MandatoryUsedEstimator = workbookTemp.getXSSFWorkbook().getSheetAt(1);
			s4OptionalEstimator = workbookTemp.getXSSFWorkbook().getSheetAt(2);
			s4OptionalaUsedEstimator = workbookTemp.getXSSFWorkbook().getSheetAt(3);
			
			 wroteMandatoryEstimationsSheet(s4MandatoryEstimatorSheet,requestID);
			 wroteOptionalEstimationsSheet(s4OptionalEstimator,requestID);
			 wroteOptionalUsedEstimationsSheet(s4OptionalaUsedEstimator,requestID);
			 wroteMandatoryUsedEstimationsSheet(s4MandatoryUsedEstimator,requestID);
	

				ByteArrayOutputStream bos = new ByteArrayOutputStream();
				workbookTemp.write(bos);
				bos.close();
		
				byte[] bytes = bos.toByteArray();
				getFileDownload()
					.downloadFile(bytes, response,
						HANAUtility.join("_", "S4 Profiler", requestForm.getClientName(),
								requestForm.getSourceVersion(), requestForm.getTargetVersion(), requestID.toString())
						+ ".xlsx");

		return null;
	}
	

	//CR-61: New Estimation sheet added with a separate template addition for Admin	
	private void  wroteMandatoryEstimationsSheet(XSSFSheet s4EstimatorSheet, Long requestID) {
		//For Mandatory Estimation Sheet
	
		Multimap<String,String> inventryObjTypeMap=getGraphS4DAO().getEstimateCount(requestID,"Mandatory");

		int countProgVeryLow=0;
		int countProgLow=0;
		int countProgMedium=0;
		int countProgHigh=0;
		
		int countClassVeryLow=0;
		int countClassLow=0;
		int countClassMedium=0;
		int countClassHigh=0;
		
		int countFugrVeryLow=0;
		int countFugrLow=0;
		int countFugrMedium=0;
		int countFugrHigh=0;
		
		int countEnhoVeryLow=0;
		int countEnhoLow=0;
		int countEnhoMedium=0;
		int countEnhoHigh=0;
		
		int countSsfoVeryLow=0;
		int countSsfoLow=0;
		int countSsfoMedium=0;
		int countSsfoHigh=0;
		
		int countSfpiVeryLow=0;
		int countSfpiLow=0;
		int countSfpiMedium=0;
		int countSfpiHigh=0;
		
		int countUserExitVeryLow=0;
		int countUserExitLow=0;
		int countUserExitMedium=0;
		int countUserExitHigh=0;
		
		int countLsmwVeryLow=0;
		int countLsmwLow=0;
		int countLsmwMedium=0;
		int countLsmwHigh=0;
	
		
		int countWebVeryLow=0;
		int countWebLow=0;
		int countWebMedium=0;
		int countWebHigh=0;
		
		int countIndeVeryLow=0;
		int countIndeLow=0;
		int countIndeMedium=0;
		int countIndeHigh=0;
		
		int countIdocVeryLow=0;
		int countIdocLow=0;
		int countIdocMedium=0;
		int countIdocHigh=0;
		
		int countViewVeryLow=0;
		int countViewLow=0;
		int countViewMedium=0;
		int countViewHigh=0;
		
		int countTablLow=0;
	
	
		for (Map.Entry<String, String> entry : inventryObjTypeMap.entries()) {
			if((entry.getKey()).equalsIgnoreCase("PROG"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				countProgLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
				countProgVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
				countProgMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		countProgHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("Class"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				countClassLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		countClassVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		countClassMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countClassHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("FUGR"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				 countFugrLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		 countFugrVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		 countFugrMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countFugrHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("ENHO"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				 countEnhoLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		 countEnhoVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		 countEnhoMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countEnhoHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("SSFO"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				 countSsfoLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		 countSsfoVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		 countSsfoMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countSsfoHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("SFPI"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				 countSfpiLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		 countSfpiVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		 countSfpiMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countSfpiHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("USER EXIT"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				 countUserExitLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		 countUserExitVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		 countUserExitLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countUserExitHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("LSMW"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				 countLsmwLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		 countLsmwVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		 countLsmwMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countLsmwHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("WEBDYNPRO"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				countWebLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		countWebVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		countWebMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countWebHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("INDE"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				countIndeLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		countIndeVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		countIndeMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countIndeHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("IDOC"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				countIdocLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		countIdocVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		countIdocMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countIdocHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("VIEW"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				countViewLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		countViewVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		countViewMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countViewHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("TABL"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				countTablLow++;
				}
			}
			
			
		}
		
		s4EstimatorSheet.getRow(37).getCell(3).setCellValue(countProgVeryLow);
		s4EstimatorSheet.getRow(37).getCell(4).setCellValue(countProgLow);
		s4EstimatorSheet.getRow(37).getCell(5).setCellValue(countProgMedium);
		s4EstimatorSheet.getRow(37).getCell(6).setCellValue(countProgHigh);
		
		s4EstimatorSheet.getRow(37).getCell(7).setCellValue(countClassVeryLow);
		s4EstimatorSheet.getRow(37).getCell(8).setCellValue(countClassLow);
		s4EstimatorSheet.getRow(37).getCell(9).setCellValue(countClassMedium);
		s4EstimatorSheet.getRow(37).getCell(10).setCellValue(countClassHigh);
		
		s4EstimatorSheet.getRow(37).getCell(11).setCellValue(countFugrVeryLow);
		s4EstimatorSheet.getRow(37).getCell(12).setCellValue(countFugrLow);
		s4EstimatorSheet.getRow(37).getCell(13).setCellValue(countFugrMedium);
		s4EstimatorSheet.getRow(37).getCell(14).setCellValue(countFugrHigh);
		
		s4EstimatorSheet.getRow(37).getCell(15).setCellValue(countEnhoVeryLow);
		s4EstimatorSheet.getRow(37).getCell(16).setCellValue(countEnhoLow);
		s4EstimatorSheet.getRow(37).getCell(17).setCellValue(countEnhoMedium);
		s4EstimatorSheet.getRow(37).getCell(18).setCellValue(countEnhoHigh);
		
		
		s4EstimatorSheet.getRow(37).getCell(19).setCellValue(countSsfoVeryLow);
		s4EstimatorSheet.getRow(37).getCell(20).setCellValue(countSsfoLow);
		s4EstimatorSheet.getRow(37).getCell(21).setCellValue(countSsfoMedium);
		s4EstimatorSheet.getRow(37).getCell(22).setCellValue(countSsfoHigh);
		
		
		s4EstimatorSheet.getRow(37).getCell(23).setCellValue(countSfpiVeryLow);
		s4EstimatorSheet.getRow(37).getCell(24).setCellValue(countSfpiLow);
		s4EstimatorSheet.getRow(37).getCell(25).setCellValue(countSfpiMedium);
		s4EstimatorSheet.getRow(37).getCell(26).setCellValue(countSfpiHigh);
		
		s4EstimatorSheet.getRow(37).getCell(27).setCellValue(countUserExitVeryLow);
		s4EstimatorSheet.getRow(37).getCell(28).setCellValue(countUserExitLow);
		s4EstimatorSheet.getRow(37).getCell(29).setCellValue(countUserExitMedium);
		s4EstimatorSheet.getRow(37).getCell(30).setCellValue(countUserExitHigh);
		
		s4EstimatorSheet.getRow(37).getCell(31).setCellValue(countLsmwVeryLow);
		s4EstimatorSheet.getRow(37).getCell(32).setCellValue(countLsmwLow);
		s4EstimatorSheet.getRow(37).getCell(33).setCellValue(countLsmwMedium);
		s4EstimatorSheet.getRow(37).getCell(34).setCellValue(countLsmwHigh);
		
		s4EstimatorSheet.getRow(37).getCell(35).setCellValue(countWebVeryLow);
		s4EstimatorSheet.getRow(37).getCell(36).setCellValue(countWebLow);
		s4EstimatorSheet.getRow(37).getCell(37).setCellValue(countWebMedium);
		s4EstimatorSheet.getRow(37).getCell(38).setCellValue(countWebHigh);
		
		s4EstimatorSheet.getRow(37).getCell(39).setCellValue(countIndeVeryLow);
		s4EstimatorSheet.getRow(37).getCell(40).setCellValue(countIndeLow);
		s4EstimatorSheet.getRow(37).getCell(41).setCellValue(countIndeMedium);
		s4EstimatorSheet.getRow(37).getCell(42).setCellValue(countIndeHigh);
		
		s4EstimatorSheet.getRow(37).getCell(43).setCellValue(countIdocVeryLow);
		s4EstimatorSheet.getRow(37).getCell(44).setCellValue(countIdocLow);
		s4EstimatorSheet.getRow(37).getCell(45).setCellValue(countIdocMedium);
		s4EstimatorSheet.getRow(37).getCell(46).setCellValue(countIdocHigh);
		
		s4EstimatorSheet.getRow(37).getCell(47).setCellValue(countViewVeryLow);
		s4EstimatorSheet.getRow(37).getCell(48).setCellValue(countViewLow);
		s4EstimatorSheet.getRow(37).getCell(49).setCellValue(countViewMedium);
		s4EstimatorSheet.getRow(37).getCell(50).setCellValue(countViewHigh);
		
		s4EstimatorSheet.getRow(37).getCell(51).setCellValue(countTablLow);	
		System.out.println("Sucessfully Wrote estimation Madatory Sheet:::%%%%%%%");
	}
	
	//CR-61: New Estimation sheet added with a separate template addition for Admin
	private void  wroteMandatoryUsedEstimationsSheet(XSSFSheet s4EstimatorSheet, Long requestID) {
		//For Mandatory Used Estimation Sheet
	
		Multimap<String,String> inventryObjTypeMap=getGraphS4DAO().getUsedEstimateCount(requestID,"Mandatory");

		int countProgVeryLow=0;
		int countProgLow=0;
		int countProgMedium=0;
		int countProgHigh=0;
		
		int countClassVeryLow=0;
		int countClassLow=0;
		int countClassMedium=0;
		int countClassHigh=0;
		
		int countFugrVeryLow=0;
		int countFugrLow=0;
		int countFugrMedium=0;
		int countFugrHigh=0;
		
		int countEnhoVeryLow=0;
		int countEnhoLow=0;
		int countEnhoMedium=0;
		int countEnhoHigh=0;
		
		int countSsfoVeryLow=0;
		int countSsfoLow=0;
		int countSsfoMedium=0;
		int countSsfoHigh=0;
		
		int countSfpiVeryLow=0;
		int countSfpiLow=0;
		int countSfpiMedium=0;
		int countSfpiHigh=0;
		
		int countUserExitVeryLow=0;
		int countUserExitLow=0;
		int countUserExitMedium=0;
		int countUserExitHigh=0;
		
		int countLsmwVeryLow=0;
		int countLsmwLow=0;
		int countLsmwMedium=0;
		int countLsmwHigh=0;
	
		
		int countWebVeryLow=0;
		int countWebLow=0;
		int countWebMedium=0;
		int countWebHigh=0;
		
		int countIndeVeryLow=0;
		int countIndeLow=0;
		int countIndeMedium=0;
		int countIndeHigh=0;
		
		int countIdocVeryLow=0;
		int countIdocLow=0;
		int countIdocMedium=0;
		int countIdocHigh=0;
		
		int countViewVeryLow=0;
		int countViewLow=0;
		int countViewMedium=0;
		int countViewHigh=0;
		
		int countTablLow=0;
	
	
		for (Map.Entry<String, String> entry : inventryObjTypeMap.entries()) {
			if((entry.getKey()).equalsIgnoreCase("PROG"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				countProgLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
				countProgVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
				countProgMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		countProgHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("Class"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				countClassLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		countClassVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		countClassMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countClassHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("FUGR"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				 countFugrLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		 countFugrVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		 countFugrMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countFugrHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("ENHO"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				 countEnhoLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		 countEnhoVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		 countEnhoMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countEnhoHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("SSFO"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				 countSsfoLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		 countSsfoVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		 countSsfoMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countSsfoHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("SFPI"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				 countSfpiLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		 countSfpiVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		 countSfpiMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countSfpiHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("USER EXIT"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				 countUserExitLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		 countUserExitVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		 countUserExitLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countUserExitHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("LSMW"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				 countLsmwLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		 countLsmwVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		 countLsmwMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countLsmwHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("WEBDYNPRO"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				countWebLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		countWebVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		countWebMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countWebHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("INDE"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				countIndeLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		countIndeVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		countIndeMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countIndeHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("IDOC"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				countIdocLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		countIdocVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		countIdocMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countIdocHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("VIEW"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				countViewLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		countViewVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		countViewMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countViewHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("TABL"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				countTablLow++;
				}
			}
		}
		
		s4EstimatorSheet.getRow(37).getCell(3).setCellValue(countProgVeryLow);
		s4EstimatorSheet.getRow(37).getCell(4).setCellValue(countProgLow);
		s4EstimatorSheet.getRow(37).getCell(5).setCellValue(countProgMedium);
		s4EstimatorSheet.getRow(37).getCell(6).setCellValue(countProgHigh);
		
		s4EstimatorSheet.getRow(37).getCell(7).setCellValue(countClassVeryLow);
		s4EstimatorSheet.getRow(37).getCell(8).setCellValue(countClassLow);
		s4EstimatorSheet.getRow(37).getCell(9).setCellValue(countClassMedium);
		s4EstimatorSheet.getRow(37).getCell(10).setCellValue(countClassHigh);
		
		s4EstimatorSheet.getRow(37).getCell(11).setCellValue(countFugrVeryLow);
		s4EstimatorSheet.getRow(37).getCell(12).setCellValue(countFugrLow);
		s4EstimatorSheet.getRow(37).getCell(13).setCellValue(countFugrMedium);
		s4EstimatorSheet.getRow(37).getCell(14).setCellValue(countFugrHigh);
		
		s4EstimatorSheet.getRow(37).getCell(15).setCellValue(countEnhoVeryLow);
		s4EstimatorSheet.getRow(37).getCell(16).setCellValue(countEnhoLow);
		s4EstimatorSheet.getRow(37).getCell(17).setCellValue(countEnhoMedium);
		s4EstimatorSheet.getRow(37).getCell(18).setCellValue(countEnhoHigh);
		
		
		s4EstimatorSheet.getRow(37).getCell(19).setCellValue(countSsfoVeryLow);
		s4EstimatorSheet.getRow(37).getCell(20).setCellValue(countSsfoLow);
		s4EstimatorSheet.getRow(37).getCell(21).setCellValue(countSsfoMedium);
		s4EstimatorSheet.getRow(37).getCell(22).setCellValue(countSsfoHigh);
		
		
		s4EstimatorSheet.getRow(37).getCell(23).setCellValue(countSfpiVeryLow);
		s4EstimatorSheet.getRow(37).getCell(24).setCellValue(countSfpiLow);
		s4EstimatorSheet.getRow(37).getCell(25).setCellValue(countSfpiMedium);
		s4EstimatorSheet.getRow(37).getCell(26).setCellValue(countSfpiHigh);
		
		s4EstimatorSheet.getRow(37).getCell(27).setCellValue(countUserExitVeryLow);
		s4EstimatorSheet.getRow(37).getCell(28).setCellValue(countUserExitLow);
		s4EstimatorSheet.getRow(37).getCell(29).setCellValue(countUserExitMedium);
		s4EstimatorSheet.getRow(37).getCell(30).setCellValue(countUserExitHigh);
		
		s4EstimatorSheet.getRow(37).getCell(31).setCellValue(countLsmwVeryLow);
		s4EstimatorSheet.getRow(37).getCell(32).setCellValue(countLsmwLow);
		s4EstimatorSheet.getRow(37).getCell(33).setCellValue(countLsmwMedium);
		s4EstimatorSheet.getRow(37).getCell(34).setCellValue(countLsmwHigh);
		
		s4EstimatorSheet.getRow(37).getCell(35).setCellValue(countWebVeryLow);
		s4EstimatorSheet.getRow(37).getCell(36).setCellValue(countWebLow);
		s4EstimatorSheet.getRow(37).getCell(37).setCellValue(countWebMedium);
		s4EstimatorSheet.getRow(37).getCell(38).setCellValue(countWebHigh);
		
		s4EstimatorSheet.getRow(37).getCell(39).setCellValue(countIndeVeryLow);
		s4EstimatorSheet.getRow(37).getCell(40).setCellValue(countIndeLow);
		s4EstimatorSheet.getRow(37).getCell(41).setCellValue(countIndeMedium);
		s4EstimatorSheet.getRow(37).getCell(42).setCellValue(countIndeHigh);
		
		s4EstimatorSheet.getRow(37).getCell(43).setCellValue(countIdocVeryLow);
		s4EstimatorSheet.getRow(37).getCell(44).setCellValue(countIdocLow);
		s4EstimatorSheet.getRow(37).getCell(45).setCellValue(countIdocMedium);
		s4EstimatorSheet.getRow(37).getCell(46).setCellValue(countIdocHigh);
		
		s4EstimatorSheet.getRow(37).getCell(47).setCellValue(countViewVeryLow);
		s4EstimatorSheet.getRow(37).getCell(48).setCellValue(countViewLow);
		s4EstimatorSheet.getRow(37).getCell(49).setCellValue(countViewMedium);
		s4EstimatorSheet.getRow(37).getCell(50).setCellValue(countViewHigh);
		
		s4EstimatorSheet.getRow(37).getCell(51).setCellValue(countTablLow);	
		
		System.out.println("Sucessfully Wrote estimation Madatory Used Sheet:::%%%%%%%");
	}
	
	//CR-61: New Estimation sheet added with a separate template addition for Admin
	private void  wroteOptionalEstimationsSheet(XSSFSheet s4EstimatorSheet, Long requestID) {
		//For Optional Estimation Sheet
	
		Multimap<String,String> inventryObjTypeMap=getGraphS4DAO().getEstimateCount(requestID,"Optional");

		int countProgVeryLow=0;
		int countProgLow=0;
		int countProgMedium=0;
		int countProgHigh=0;
		
		int countClassVeryLow=0;
		int countClassLow=0;
		int countClassMedium=0;
		int countClassHigh=0;
		
		int countFugrVeryLow=0;
		int countFugrLow=0;
		int countFugrMedium=0;
		int countFugrHigh=0;
		
		int countEnhoVeryLow=0;
		int countEnhoLow=0;
		int countEnhoMedium=0;
		int countEnhoHigh=0;
		
		int countSsfoVeryLow=0;
		int countSsfoLow=0;
		int countSsfoMedium=0;
		int countSsfoHigh=0;
		
		int countSfpiVeryLow=0;
		int countSfpiLow=0;
		int countSfpiMedium=0;
		int countSfpiHigh=0;
		
		int countUserExitVeryLow=0;
		int countUserExitLow=0;
		int countUserExitMedium=0;
		int countUserExitHigh=0;
		
		int countLsmwVeryLow=0;
		int countLsmwLow=0;
		int countLsmwMedium=0;
		int countLsmwHigh=0;
	
		
		int countWebVeryLow=0;
		int countWebLow=0;
		int countWebMedium=0;
		int countWebHigh=0;
		
		int countIndeVeryLow=0;
		int countIndeLow=0;
		int countIndeMedium=0;
		int countIndeHigh=0;
		
		int countIdocVeryLow=0;
		int countIdocLow=0;
		int countIdocMedium=0;
		int countIdocHigh=0;
		
		int countViewVeryLow=0;
		int countViewLow=0;
		int countViewMedium=0;
		int countViewHigh=0;
		
		int countTablLow=0;
	
	
		for (Map.Entry<String, String> entry : inventryObjTypeMap.entries()) {
			if((entry.getKey()).equalsIgnoreCase("PROG"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				countProgLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
				countProgVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
				countProgMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		countProgHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("Class"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				countClassLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		countClassVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		countClassMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countClassHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("FUGR"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				 countFugrLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		 countFugrVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		 countFugrMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countFugrHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("ENHO"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				 countEnhoLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		 countEnhoVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		 countEnhoMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countEnhoHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("SSFO"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				 countSsfoLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		 countSsfoVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		 countSsfoMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countSsfoHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("SFPI"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				 countSfpiLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		 countSfpiVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		 countSfpiMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countSfpiHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("USER EXIT"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				 countUserExitLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		 countUserExitVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		 countUserExitLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countUserExitHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("LSMW"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				 countLsmwLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		 countLsmwVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		 countLsmwMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countLsmwHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("WEBDYNPRO"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				countWebLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		countWebVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		countWebMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countWebHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("INDE"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				countIndeLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		countIndeVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		countIndeMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countIndeHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("IDOC"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				countIdocLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		countIdocVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		countIdocMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countIdocHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("VIEW"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				countViewLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		countViewVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		countViewMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countViewHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("TABL"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				countTablLow++;
				}
			}
		}
		
		s4EstimatorSheet.getRow(37).getCell(3).setCellValue(countProgVeryLow);
		s4EstimatorSheet.getRow(37).getCell(4).setCellValue(countProgLow);
		s4EstimatorSheet.getRow(37).getCell(5).setCellValue(countProgMedium);
		s4EstimatorSheet.getRow(37).getCell(6).setCellValue(countProgHigh);
		
		s4EstimatorSheet.getRow(37).getCell(7).setCellValue(countClassVeryLow);
		s4EstimatorSheet.getRow(37).getCell(8).setCellValue(countClassLow);
		s4EstimatorSheet.getRow(37).getCell(9).setCellValue(countClassMedium);
		s4EstimatorSheet.getRow(37).getCell(10).setCellValue(countClassHigh);
		
		s4EstimatorSheet.getRow(37).getCell(11).setCellValue(countFugrVeryLow);
		s4EstimatorSheet.getRow(37).getCell(12).setCellValue(countFugrLow);
		s4EstimatorSheet.getRow(37).getCell(13).setCellValue(countFugrMedium);
		s4EstimatorSheet.getRow(37).getCell(14).setCellValue(countFugrHigh);
		
		s4EstimatorSheet.getRow(37).getCell(15).setCellValue(countEnhoVeryLow);
		s4EstimatorSheet.getRow(37).getCell(16).setCellValue(countEnhoLow);
		s4EstimatorSheet.getRow(37).getCell(17).setCellValue(countEnhoMedium);
		s4EstimatorSheet.getRow(37).getCell(18).setCellValue(countEnhoHigh);
		
		
		s4EstimatorSheet.getRow(37).getCell(19).setCellValue(countSsfoVeryLow);
		s4EstimatorSheet.getRow(37).getCell(20).setCellValue(countSsfoLow);
		s4EstimatorSheet.getRow(37).getCell(21).setCellValue(countSsfoMedium);
		s4EstimatorSheet.getRow(37).getCell(22).setCellValue(countSsfoHigh);
		
		
		s4EstimatorSheet.getRow(37).getCell(23).setCellValue(countSfpiVeryLow);
		s4EstimatorSheet.getRow(37).getCell(24).setCellValue(countSfpiLow);
		s4EstimatorSheet.getRow(37).getCell(25).setCellValue(countSfpiMedium);
		s4EstimatorSheet.getRow(37).getCell(26).setCellValue(countSfpiHigh);
		
		s4EstimatorSheet.getRow(37).getCell(27).setCellValue(countUserExitVeryLow);
		s4EstimatorSheet.getRow(37).getCell(28).setCellValue(countUserExitLow);
		s4EstimatorSheet.getRow(37).getCell(29).setCellValue(countUserExitMedium);
		s4EstimatorSheet.getRow(37).getCell(30).setCellValue(countUserExitHigh);
		
		s4EstimatorSheet.getRow(37).getCell(31).setCellValue(countLsmwVeryLow);
		s4EstimatorSheet.getRow(37).getCell(32).setCellValue(countLsmwLow);
		s4EstimatorSheet.getRow(37).getCell(33).setCellValue(countLsmwMedium);
		s4EstimatorSheet.getRow(37).getCell(34).setCellValue(countLsmwHigh);
		
		s4EstimatorSheet.getRow(37).getCell(35).setCellValue(countWebVeryLow);
		s4EstimatorSheet.getRow(37).getCell(36).setCellValue(countWebLow);
		s4EstimatorSheet.getRow(37).getCell(37).setCellValue(countWebMedium);
		s4EstimatorSheet.getRow(37).getCell(38).setCellValue(countWebHigh);
		
		s4EstimatorSheet.getRow(37).getCell(39).setCellValue(countIndeVeryLow);
		s4EstimatorSheet.getRow(37).getCell(40).setCellValue(countIndeLow);
		s4EstimatorSheet.getRow(37).getCell(41).setCellValue(countIndeMedium);
		s4EstimatorSheet.getRow(37).getCell(42).setCellValue(countIndeHigh);
		
		s4EstimatorSheet.getRow(37).getCell(43).setCellValue(countIdocVeryLow);
		s4EstimatorSheet.getRow(37).getCell(44).setCellValue(countIdocVeryLow);
		s4EstimatorSheet.getRow(37).getCell(45).setCellValue(countIdocMedium);
		s4EstimatorSheet.getRow(37).getCell(46).setCellValue(countIdocHigh);
		
		s4EstimatorSheet.getRow(37).getCell(47).setCellValue(countViewVeryLow);
		s4EstimatorSheet.getRow(37).getCell(48).setCellValue(countViewLow);
		s4EstimatorSheet.getRow(37).getCell(49).setCellValue(countViewMedium);
		s4EstimatorSheet.getRow(37).getCell(50).setCellValue(countViewHigh);
		
		s4EstimatorSheet.getRow(37).getCell(51).setCellValue(countTablLow);	
		
		System.out.println("Sucessfully Wrote estimation Optional Sheet:::%%%%%%%");
	}
	
	//CR-61: New Estimation sheet added with a separate template addition for Admin
	private void  wroteOptionalUsedEstimationsSheet(XSSFSheet s4EstimatorSheet, Long requestID) {
		//For Optional Used Estimation Sheet
	
		Multimap<String,String> inventryObjTypeMap=getGraphS4DAO().getUsedEstimateCount(requestID,"Optional");

		int countProgVeryLow=0;
		int countProgLow=0;
		int countProgMedium=0;
		int countProgHigh=0;
		
		int countClassVeryLow=0;
		int countClassLow=0;
		int countClassMedium=0;
		int countClassHigh=0;
		
		int countFugrVeryLow=0;
		int countFugrLow=0;
		int countFugrMedium=0;
		int countFugrHigh=0;
		
		int countEnhoVeryLow=0;
		int countEnhoLow=0;
		int countEnhoMedium=0;
		int countEnhoHigh=0;
		
		int countSsfoVeryLow=0;
		int countSsfoLow=0;
		int countSsfoMedium=0;
		int countSsfoHigh=0;
		
		int countSfpiVeryLow=0;
		int countSfpiLow=0;
		int countSfpiMedium=0;
		int countSfpiHigh=0;
		
		int countUserExitVeryLow=0;
		int countUserExitLow=0;
		int countUserExitMedium=0;
		int countUserExitHigh=0;
		
		int countLsmwVeryLow=0;
		int countLsmwLow=0;
		int countLsmwMedium=0;
		int countLsmwHigh=0;
	
		
		int countWebVeryLow=0;
		int countWebLow=0;
		int countWebMedium=0;
		int countWebHigh=0;
		
		int countIndeVeryLow=0;
		int countIndeLow=0;
		int countIndeMedium=0;
		int countIndeHigh=0;
		
		int countIdocVeryLow=0;
		int countIdocLow=0;
		int countIdocMedium=0;
		int countIdocHigh=0;
		
		int countViewVeryLow=0;
		int countViewLow=0;
		int countViewMedium=0;
		int countViewHigh=0;
		
		int countTablLow=0;
	
	
		for (Map.Entry<String, String> entry : inventryObjTypeMap.entries()) {
			if((entry.getKey()).equalsIgnoreCase("PROG"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				countProgLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
				countProgVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
				countProgMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		countProgHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("Class"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				countClassLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		countClassVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		countClassMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countClassHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("FUGR"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				 countFugrLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		 countFugrVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		 countFugrMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countFugrHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("ENHO"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				 countEnhoLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		 countEnhoVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		 countEnhoMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countEnhoHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("SSFO"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				 countSsfoLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		 countSsfoVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		 countSsfoMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countSsfoHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("SFPI"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				 countSfpiLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		 countSfpiVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		 countSfpiMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countSfpiHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("USER EXIT"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				 countUserExitLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		 countUserExitVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		 countUserExitLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countUserExitHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("LSMW"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				 countLsmwLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		 countLsmwVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		 countLsmwMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countLsmwHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("WEBDYNPRO"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				countWebLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		countWebVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		countWebMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countWebHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("INDE"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				countIndeLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		countIndeVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		countIndeMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countIndeHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("IDOC"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				countIdocLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		countIdocVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		countIdocMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countIdocHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("VIEW"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				countViewLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Very Low"))
				{
	    		countViewVeryLow++;
				}
				else if((entry.getValue()).equalsIgnoreCase("Medium"))
				{
	    		countViewMedium++;
				}
				else if((entry.getValue()).equalsIgnoreCase("High"))
				{
	    		 countViewHigh++;
				}
			}
			else if((entry.getKey()).equalsIgnoreCase("TABL"))
			{
				if((entry.getValue()).equalsIgnoreCase("Low"))
				{
				countTablLow++;
				}
			}
		}
		
		s4EstimatorSheet.getRow(37).getCell(3).setCellValue(countProgVeryLow);
		s4EstimatorSheet.getRow(37).getCell(4).setCellValue(countProgLow);
		s4EstimatorSheet.getRow(37).getCell(5).setCellValue(countProgMedium);
		s4EstimatorSheet.getRow(37).getCell(6).setCellValue(countProgHigh);
		
		s4EstimatorSheet.getRow(37).getCell(7).setCellValue(countClassVeryLow);
		s4EstimatorSheet.getRow(37).getCell(8).setCellValue(countClassLow);
		s4EstimatorSheet.getRow(37).getCell(9).setCellValue(countClassMedium);
		s4EstimatorSheet.getRow(37).getCell(10).setCellValue(countClassHigh);
		
		s4EstimatorSheet.getRow(37).getCell(11).setCellValue(countFugrVeryLow);
		s4EstimatorSheet.getRow(37).getCell(12).setCellValue(countFugrLow);
		s4EstimatorSheet.getRow(37).getCell(13).setCellValue(countFugrMedium);
		s4EstimatorSheet.getRow(37).getCell(14).setCellValue(countFugrHigh);
		
		s4EstimatorSheet.getRow(37).getCell(15).setCellValue(countEnhoVeryLow);
		s4EstimatorSheet.getRow(37).getCell(16).setCellValue(countEnhoLow);
		s4EstimatorSheet.getRow(37).getCell(17).setCellValue(countEnhoMedium);
		s4EstimatorSheet.getRow(37).getCell(18).setCellValue(countEnhoHigh);
		
		
		s4EstimatorSheet.getRow(37).getCell(19).setCellValue(countSsfoVeryLow);
		s4EstimatorSheet.getRow(37).getCell(20).setCellValue(countSsfoLow);
		s4EstimatorSheet.getRow(37).getCell(21).setCellValue(countSsfoMedium);
		s4EstimatorSheet.getRow(37).getCell(22).setCellValue(countSsfoHigh);
		
		
		s4EstimatorSheet.getRow(37).getCell(23).setCellValue(countSfpiVeryLow);
		s4EstimatorSheet.getRow(37).getCell(24).setCellValue(countSfpiLow);
		s4EstimatorSheet.getRow(37).getCell(25).setCellValue(countSfpiMedium);
		s4EstimatorSheet.getRow(37).getCell(26).setCellValue(countSfpiHigh);
		
		s4EstimatorSheet.getRow(37).getCell(27).setCellValue(countUserExitVeryLow);
		s4EstimatorSheet.getRow(37).getCell(28).setCellValue(countUserExitLow);
		s4EstimatorSheet.getRow(37).getCell(29).setCellValue(countUserExitMedium);
		s4EstimatorSheet.getRow(37).getCell(30).setCellValue(countUserExitHigh);
		
		s4EstimatorSheet.getRow(37).getCell(31).setCellValue(countLsmwVeryLow);
		s4EstimatorSheet.getRow(37).getCell(32).setCellValue(countLsmwLow);
		s4EstimatorSheet.getRow(37).getCell(33).setCellValue(countLsmwMedium);
		s4EstimatorSheet.getRow(37).getCell(34).setCellValue(countLsmwHigh);
		
		s4EstimatorSheet.getRow(37).getCell(35).setCellValue(countWebVeryLow);
		s4EstimatorSheet.getRow(37).getCell(36).setCellValue(countWebLow);
		s4EstimatorSheet.getRow(37).getCell(37).setCellValue(countWebMedium);
		s4EstimatorSheet.getRow(37).getCell(38).setCellValue(countWebHigh);
		
		s4EstimatorSheet.getRow(37).getCell(39).setCellValue(countIndeVeryLow);
		s4EstimatorSheet.getRow(37).getCell(40).setCellValue(countIndeLow);
		s4EstimatorSheet.getRow(37).getCell(41).setCellValue(countIndeMedium);
		s4EstimatorSheet.getRow(37).getCell(42).setCellValue(countIndeHigh);
		
		s4EstimatorSheet.getRow(37).getCell(43).setCellValue(countIdocVeryLow);
		s4EstimatorSheet.getRow(37).getCell(44).setCellValue(countIdocLow);
		s4EstimatorSheet.getRow(37).getCell(45).setCellValue(countIdocMedium);
		s4EstimatorSheet.getRow(37).getCell(46).setCellValue(countIdocHigh);
		
		s4EstimatorSheet.getRow(37).getCell(47).setCellValue(countViewVeryLow);
		s4EstimatorSheet.getRow(37).getCell(48).setCellValue(countViewLow);
		s4EstimatorSheet.getRow(37).getCell(49).setCellValue(countViewMedium);
		s4EstimatorSheet.getRow(37).getCell(50).setCellValue(countViewHigh);
		
		s4EstimatorSheet.getRow(37).getCell(51).setCellValue(countTablLow);
		
		System.out.println("Sucessfully Wrote estimation Optional Used Sheet:::%%%%%%%");
	}
	
	
	//CR-50,51: Views for S4
	
	@RequestMapping(value = "/view/summary/S4/{requestID}/{viewType}", method = RequestMethod.GET)
	public ModelAndView graphView1(ModelAndView model, @PathVariable("requestID") final String requestId,
			@PathVariable("viewType") final String viewType) {

		String view = "";
		ModelAndView modenAndView=null;
		Long ReqID=Long.parseLong(requestId);
		
		if ("application".equals(viewType)) {
			view = "/ApplicationComponentTabularViewClientS4";
			modenAndView=new ModelAndView(view);
			modenAndView.addObject("application", getGraphS4DAO().getCountApplicationComponent(Long.parseLong(requestId)));
			modenAndView.addObject("sapnote", getGraphS4DAO().getCountSAPNote(ReqID,null));
			modenAndView.addObject("sapnotecode","ALL");
		}
		else if (Hana_Profiler_Constant.GRAPHICAL.equals(viewType)) {
			view = "/summaryGraphViewS4";
			modenAndView=new ModelAndView(view);
			modenAndView.addObject("cateGory", getGraphS4DAO().getGraphCountRemediCategry(Long.parseLong(requestId)));
			modenAndView.addObject("subCateGory", getGraphS4DAO().getGraphCountErrCategry(Long.parseLong(requestId)));
			modenAndView.addObject("usedUnused", getGraphS4DAO().getGraphCountFinalUsed(Long.parseLong(requestId)));
			modenAndView.addObject("impact", getGraphS4DAO().getGraphCountFinalComplexity(Long.parseLong(requestId)));
			modenAndView.addObject("application",getGraphS4DAO().getMaxApplicationComponent(Long.parseLong(requestId)));
			
		} else if("Tabular".equals(viewType)) {
			view = "/summaryTabularViewS4";
			modenAndView=new ModelAndView(view);
			modenAndView.addObject("cateGory", getGraphS4DAO().getGraphCountRemediCategry(Long.parseLong(requestId)));
			modenAndView.addObject("subCateGory", getGraphS4DAO().getGraphCountErrCategry(Long.parseLong(requestId)));
			modenAndView.addObject("usedUnused", getGraphS4DAO().getGraphCountFinalUsed(Long.parseLong(requestId)));
			modenAndView.addObject("impact", getGraphS4DAO().getGraphCountFinalComplexity(Long.parseLong(requestId)));

			final Map<String, Map<String, Integer>> objectType = getGraphS4DAO()
					.getObjectTypeUsedCount(Long.parseLong(requestId));
			modenAndView.addObject("progUsedCount", getUsedColumnCount("Y", objectType.get("PROG")));
			
			modenAndView.addObject("classUsedCount", getUsedColumnCount("Y", objectType.get("CLAS")));
			
			modenAndView.addObject("fugrUsedCount", getUsedColumnCount("Y", objectType.get("FUGR")));
			
			modenAndView.addObject("enhoUsedCount", getUsedColumnCount("Y", objectType.get("ENHO")));
			
			modenAndView.addObject("enhcUsedCount", getUsedColumnCount("Y", objectType.get("ENHC")));
			
			modenAndView.addObject("enhsUsedCount", getUsedColumnCount("Y", objectType.get("ENHS")));
			modenAndView.addObject("indeUsedCount", getUsedColumnCount("Y", objectType.get("INDE")));
			
			modenAndView.addObject("viewUsedCount", getUsedColumnCount("Y", objectType.get("VIEW")));
			
			modenAndView.addObject("wdynUsedCount", getUsedColumnCount("Y", objectType.get("WDYN")));
			
			modenAndView.addObject("ssfoUsedCount", getUsedColumnCount("Y", objectType.get("SSFO")));
			
			modenAndView.addObject("requestID", requestId);
		}
		// this case is for application Component Tabular view
		else
		{
			String appComp=viewType;
			view = "/ApplicationComponentTabularViewClientS4";
			modenAndView=new ModelAndView(view);
			modenAndView.addObject("application", getGraphS4DAO().getCountApplicationComponent(Long.parseLong(requestId)));
			//this condition runs when we click on grand total button and we display all the sap notes 
			if(appComp.equals("total"))
			{
				modenAndView.addObject("sapnote", getGraphS4DAO().getCountSAPNote(ReqID,null));
				modenAndView.addObject("sapnotecode","ALL");
			}
			else
			{
				//this condition is for the blank application comp and then displaying corresponding Sap notes 
				if(appComp.equals("Other-Misc"))
				{
					modenAndView.addObject("sapnote", getGraphS4DAO().getCountSAPNote(ReqID,""));
					modenAndView.addObject("sapnotecode",appComp);
				}
				// this condition is for others application comp are clicked and then displaying corresponding Sap notes 
				else
				{
					modenAndView.addObject("sapnote", getGraphS4DAO().getCountSAPNote(ReqID,appComp));
					modenAndView.addObject("sapnotecode",appComp);
				}
				
			}
		}
		return modenAndView;
	}

	private Integer getUsedColumnCount(String key, Map<String, Integer> usedUnsedMap) {
		Integer count = 0;
		if (usedUnsedMap != null && usedUnsedMap.containsKey(key)) {
			count = usedUnsedMap.get(key);
		}

		return count;
	}

	
	@RequestMapping(value = "/view/inventory/S4/{requestID}", method = RequestMethod.GET)
	public String finalOutput(@PathVariable("requestID") final long requestId, HttpServletRequest request,
			Model model) {
		model.addAttribute("requestID", requestId);
		request.getSession().setAttribute("requestID", requestId);
		return "client/clientGridS4Display";
	}
	
	
	

	
	
	 CR- 
	@RequestMapping(value = "/view/inventory/S4/jqgridDisplayview", method = RequestMethod.GET)
	public @ResponseBody JqGridResponse GetListwithValue(final long requestID, int rows, int page, Model model,
			HttpServletRequest request, HttpSession session) {
		Integer totalRecords = 0;
		if (session.getAttribute("count" + requestID) == null) {
			totalRecords = getS4DaoIntf().getTotalCountOfList(requestID);
			session.setAttribute("count" + requestID, totalRecords);
		} else {
			totalRecords = (Integer) session.getAttribute("count" + requestID);
		}
		final int to = page * rows;
		final int from = to - rows;
		List<S4HanaProfiler> list = getS4DaoIntf().getList(requestID, from, rows);

		model.addAttribute("hanaList", list);
		int total = (totalRecords) % rows;
		if (total > 0) {
			total = (totalRecords / rows) + 1;
		} else {
			total = (totalRecords / rows);
		}
		JqGridResponse response = new JqGridResponse();
		response.setRows(list);
		response.setTotal(Integer.toString(total));
		response.setRecords(Integer.toString(totalRecords));
		response.setPage(Integer.toString(page));
		return response;

	}
	
	
	
	@RequestMapping(value = "/downloadSimplificationFile", method = RequestMethod.GET)
	public synchronized String downloadSimplificationFile(Model model,
			HttpServletResponse response, HttpServletRequest request, final RedirectAttributes redirectAttributes)
					throws Exception {

		 String graphTemplete= request.getSession().getServletContext()
					.getRealPath("/staticResources/GraphTemplate/Simplification To Be Uploaded.xlsx");
		

		XSSFWorkbook workbook = new XSSFWorkbook(OPCPackage.open(new FileInputStream(graphTemplete)));
		SXSSFWorkbook workbookTemp = new SXSSFWorkbook(workbook);
		workbookTemp.setCompressTempFiles(true);

		//Writing Inventory
		XSSFSheet simplificationSheet=workbookTemp.getXSSFWorkbook().getSheetAt(0);
		
		int rowIndex=1;
		List<OperationDataS4> simplificationList= getGraphS4DAO().getS4Simplification();
		
		if (simplificationList.isEmpty() || null== simplificationList ) {
			redirectAttributes.addFlashAttribute("donLoadXlsxError", "No Records Found To Download");
			return "redirect:/admin/simplification";
		}

		else{
			Iterator<OperationDataS4> simplificationItr=simplificationList.iterator();
			while(simplificationItr.hasNext()){

				OperationDataS4 oprData=simplificationItr.next();
				Row simplificationRow=simplificationSheet.createRow(rowIndex);

				simplificationRow.createCell(0).setCellValue(oprData.getS4_hana_changes()==null || oprData.getS4_hana_changes().isEmpty() ?"NA" : oprData.getS4_hana_changes());
				simplificationRow.createCell(1).setCellValue(oprData.getObject()==null || oprData.getObject().isEmpty() ?"NA" : oprData.getObject());
				simplificationRow.createCell(2).setCellValue(oprData.getObjectType()==null || oprData.getObjectType().isEmpty() ?"NA" : oprData.getObjectType());
				
				simplificationRow.createCell(3).setCellValue(oprData.getObsolete()==null || oprData.getObsolete().isEmpty() ?"NA" : oprData.getObsolete());
				simplificationRow.createCell(4).setCellValue(oprData.getDescription()==null || oprData.getDescription().isEmpty() ?"NA" : oprData.getDescription());
				simplificationRow.createCell(5).setCellValue(oprData.getAffectedArea()==null || oprData.getAffectedArea().isEmpty() ?"NA" : oprData.getAffectedArea());
				
				simplificationRow.createCell(6).setCellValue(oprData.getRelatedNotes()==null || oprData.getRelatedNotes().isEmpty() ?"NA" : oprData.getRelatedNotes());
				simplificationRow.createCell(7).setCellValue(oprData.getSolutionSteps()==null || oprData.getSolutionSteps().isEmpty() ?"NA" : oprData.getSolutionSteps());
				simplificationRow.createCell(8).setCellValue(oprData.getErrCategoryNumeric()==null || oprData.getErrCategoryNumeric().isEmpty() ?"NA" : oprData.getErrCategoryNumeric());
				
				simplificationRow.createCell(9).setCellValue(oprData.getVersion()==null || oprData.getVersion().isEmpty() ?"NA" : oprData.getVersion());
				simplificationRow.createCell(10).setCellValue(oprData.getIdentifier()==null || oprData.getIdentifier().isEmpty() ?"NA" : oprData.getIdentifier());
				simplificationRow.createCell(11).setCellValue(oprData.getComplexity()==null || oprData.getComplexity().isEmpty() ?"NA" : oprData.getComplexity());
				
				simplificationRow.createCell(12).setCellValue(oprData.getIssueCatgry()==null || oprData.getIssueCatgry().isEmpty() ?"NA" : oprData.getIssueCatgry());
				simplificationRow.createCell(13).setCellValue(oprData.getErrorCatgry()==null || oprData.getErrorCatgry().isEmpty() ?"NA" : oprData.getErrorCatgry());
				simplificationRow.createCell(14).setCellValue(oprData.getTriggerObj()==null || oprData.getTriggerObj().isEmpty() ?"NA" : oprData.getTriggerObj());
				
				simplificationRow.createCell(15).setCellValue(oprData.getRemediationCatgry()==null || oprData.getRemediationCatgry().isEmpty() ?"NA" : oprData.getRemediationCatgry());
				simplificationRow.createCell(16).setCellValue(oprData.getSapSimplListChaptr()==null || oprData.getSapSimplListChaptr().isEmpty() ?"NA" : oprData.getSapSimplListChaptr());
				simplificationRow.createCell(17).setCellValue(oprData.getAppComponent()==null || oprData.getAppComponent().isEmpty() ?"NA" : oprData.getAppComponent());
				
				simplificationRow.createCell(18).setCellValue(oprData.getSapSimplCatry()==null || oprData.getSapSimplCatry().isEmpty() ?"NA" : oprData.getSapSimplCatry());
				simplificationRow.createCell(19).setCellValue(oprData.getItm_Area()==null || oprData.getItm_Area().isEmpty() ?"NA" : oprData.getItm_Area());
				rowIndex++;
			}
		}
		System.out.println("Sucessfully Wrote Simplification Sheet:::%%%%%%%");

		
				

		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		workbookTemp.write(bos);
		bos.close();

		byte[] bytes = bos.toByteArray();
		getFileDownload()
		.downloadFile(bytes, response,
				HANAUtility.join("_", "Simplification To Be Uploaded")	+ ".xlsx");

		return null;



	}

*/}
