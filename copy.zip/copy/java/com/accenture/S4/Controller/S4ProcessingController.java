/* *CR-48:- Consolidated both the tool so that they can executed separately -monika.mishra
 * 
 * *CR-61: New Estimation sheet added with a separate template addition for Admin-16/3/2018-rohan.a.mehra
 **/

package com.accenture.S4.Controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.accenture.FinalFile.controller.FinalFileUpload;
import com.accenture.S4.constant.S4HanaProfilerConstant;
import com.accenture.S4.dao.DisplayGraphS4DAO;
import com.accenture.S4.dao.PopulatingS4FinalOutput;
import com.accenture.S4.dao.PopulatingS4FinalOutputInterface;
import com.accenture.S4.fileProcessing.AutomateS4;
import com.accenture.S4.fileProcessing.S4DataAnalysis;
import com.accenture.S4.models.OperationDataS4;
import com.accenture.S4.models.S4Detection;
import com.accenture.S4.models.S4Estimations;
import com.accenture.S4.models.S4SimplificationDatabase;
import com.accenture.S4.models.S4ValidationList;
import com.accenture.S4.models.SimplificationLatest;
import com.accenture.client.model.RequestForm;
import com.accenture.client.service.S4ProcessingService;
import com.accenture.constant.Hana_Profiler_Constant;
import com.accenture.constant.ST03HanaConstant;
import com.accenture.controller.AbstractBaseController;
import com.accenture.displaygrid.model.DBConfig;
import com.accenture.master.ProcessedRequestDetail;
import com.accenture.master.ProcessedRequestMaster;
import com.accenture.model.DRL.CodeAssessmentPayLoad;
import com.accenture.poc.estimates.service.ProcessedEstimatesService;
import com.accenture.reqmaster.service.RequestMasterService;
import com.accenture.utility.FileUtility;
import com.accenture.utility.HANAUtility;
import com.accenture.utility.SendEmail;
import com.monitorjbl.xlsx.StreamingReader;

/**
 * @author monika.mishra
 *
 */
@Controller
public class S4ProcessingController extends AbstractBaseController {

	protected static final Logger logger = LoggerFactory.getLogger(S4ProcessingController.class);

	// Monika-S4
	private AutomateS4 autoS4;
	private S4DataAnalysis s4DataAnalysis;
	private PopulatingS4FinalOutputInterface s4daoIntf;
	private DisplayGraphS4DAO graphS4DAO;
	private PopulatingS4FinalOutput populatingS4FinalOutput;
	private ProcessedEstimatesService processedEstimatesService;
	private S4ProcessingService s4ProcessingService;

	static PopulatingS4FinalOutput finaloutput = new PopulatingS4FinalOutput();

	static CodeAssessmentPayLoad hm = new CodeAssessmentPayLoad();

	public static CodeAssessmentPayLoad getHm() {
		return hm;
	}

	public void setHm(CodeAssessmentPayLoad hm) {
		this.hm = hm;
	}

	public S4ProcessingService getS4ProcessingService() {
		return s4ProcessingService;
	}

	@Autowired
	public void setS4ProcessingService(S4ProcessingService s4ProcessingService) {
		this.s4ProcessingService = s4ProcessingService;
	}

	public PopulatingS4FinalOutput getFinaloutput() {
		return finaloutput;
	}

	@Autowired
	public void setFinaloutput(PopulatingS4FinalOutput finaloutput) {
		this.finaloutput = finaloutput;
	}

	// Monika-S4
	public AutomateS4 getAutoS4() {
		return autoS4;
	}

	@Autowired
	public void setAutoS4(final AutomateS4 autoS4) {
		this.autoS4 = autoS4;
	}

	public S4DataAnalysis getS4DataAnalysis() {
		return s4DataAnalysis;
	}

	@Autowired
	public void setS4DataAnalysis(final S4DataAnalysis s4DataAnalysis) {
		this.s4DataAnalysis = s4DataAnalysis;
	}

	public PopulatingS4FinalOutputInterface getS4DaoIntf() {
		return s4daoIntf;
	}

	@Autowired
	public void setDaoIntf(final PopulatingS4FinalOutputInterface s4daoIntf) {
		this.s4daoIntf = s4daoIntf;
	}

	public DisplayGraphS4DAO getGraphS4DAO() {
		return graphS4DAO;
	}

	@Autowired
	public void setGraphS4DAO(DisplayGraphS4DAO graphS4DAO) {
		this.graphS4DAO = graphS4DAO;
	}

	public PopulatingS4FinalOutput getPopulatingS4FinalOutput() {
		return populatingS4FinalOutput;
	}

	@Autowired
	public void PopulatingS4FinalOutput(PopulatingS4FinalOutput populatingS4FinalOutput) {
		this.populatingS4FinalOutput = populatingS4FinalOutput;
	}

	public ProcessedEstimatesService getProcessedEstimates() {
		return processedEstimatesService;
	}

	@Autowired
	public void setProcessedEstimatesService(ProcessedEstimatesService processedEstimatesService) {
		this.processedEstimatesService = processedEstimatesService;
	}

	@Autowired
	private RequestMasterService reqMasterService;

	@Autowired
	private FinalFileUpload finalFileUpload;

	public String readSimplificationData(final String path, final long requestId, HttpServletRequest request,
			HttpSession session) throws FileNotFoundException {

		logger.info("Coming inside ReadSimplificationDATA");
		String filePath = "";
		String comment = "";
		// final String rootPath = HANAUtility.getFilePath("Simplification Files", 0);
		final File rootFolderFileList[] = new File(path).listFiles();
		try {
			for (File file : rootFolderFileList) {
				logger.info("Analysing file : " + file);
				filePath = file.getCanonicalPath();
				logger.info("filePath:::: " + filePath);

				final File fil = new File(filePath);
				String filPath = fil.getName().toUpperCase();
				if (filPath.toUpperCase().contains(ST03HanaConstant.SIMPLIFICATION_LATEST_CONSTANT)) {
					comment = addSimplificationLatestData(filePath, requestId, session);
				}
			}
		} catch (IOException e) {
			logger.error(e.getMessage());
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return comment;
	}

	private String addDetectionData(String filePath, long requestId) throws FileNotFoundException {
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);
		String comment = "";

		String fileName = file.getName();

		List<S4Detection> s4DetectionList = new ArrayList<S4Detection>();
		logger.info("Coming inside ReadSimplificationDATA opDataS4List::::" + s4DetectionList);
		try {

			logger.info("Coming inside addDetectionData inputStream::::" + inputStream);
			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);

			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					logger.info("FileName: " + fileName + "Row Number: " + row.getRowNum());
					int indentifierIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Operation.Code"));
					logger.info("indentifierIndex:" + indentifierIndex);
					String[] splitArr;
					String identifier = "";

					String identifierCellVal = row.getCell(indentifierIndex) == null ? ""
							: row.getCell(indentifierIndex).getStringCellValue().replaceAll("\\s", StringUtils.EMPTY);
					if (identifierCellVal.startsWith("S")) {
						splitArr = identifierCellVal.split("S");
						if (splitArr.length == 4 && null != splitArr[1] && null != splitArr[3]) {
							identifier = splitArr[1];
						}
						if (splitArr.length < 4 && null != splitArr[1]) {
							identifier = splitArr[1];
						}

					}

					S4Detection s4Detection = new S4Detection();
					if (!identifier.equalsIgnoreCase("") || !identifier.isEmpty()) {
						s4Detection.setIdentifier(identifier);
						s4Detection.setRequestId(requestId);
						s4DetectionList.add(s4Detection);
					}
				}
			}
			comment = getS4DaoIntf().addDetectionData(s4DetectionList);

		} catch (Exception e) {
			logger.error("Error !!! " + e);
		}
		return comment;

	}

	private String addSimplificationLatestData(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException {
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);
		String comment = "";

		String fileName = file.getName();

		List<SimplificationLatest> simpliLatestList = new ArrayList<SimplificationLatest>();
		logger.info("Coming inside ReadSimplificationDATA simpliLatestList::::" + simpliLatestList);
		try {

			logger.info("Coming inside ReadSimplificationDATA inputStream::::" + inputStream);
			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);

			for (Row row : reader) {
				if (row.getRowNum() > 0) {

					int s4HanaChangesIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("S4.Hana.Changes"));
					int objectIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Object"));
					int objTypeIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Object.Type"));
					int obsoleteIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("OBSOLETE"));
					int descIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Description"));
					int affectedAreaIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Affected.Area"));
					int relatedNotesIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Related.Notes"));
					int solStepsIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Solution.Steps"));
					int errCategryNumericIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE
							.get(requestId).get(fileName).get("Error.Category"));
					int versionIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Version"));
					int identifierIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Identifier"));
					int complexityIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("COMPLEXITY"));
					int issueCategoryIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("ISSUE.CATEGORY"));
					int errCategoryIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("ERROR.CATEGORY"));
					int triggerObjIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("TRIGGER.OBJECT"));
					int remediCategryIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Remediation.Category"));
					int sapSimpliListIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("SAP.Simplification.List.chapter"));
					int appCompIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("APPLICATION.COMPONENT"));
					int sapSimpCatgryIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("SAP.Simpl.Category"));
					int itemAreaIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Item.Area"));

					SimplificationLatest simpliLatest = new SimplificationLatest();
					simpliLatest.setS4_hana_changes((row.getCell(s4HanaChangesIndex) == null ? ""
							: row.getCell(s4HanaChangesIndex).getStringCellValue()));
					simpliLatest.setObject(row.getCell(objectIndex) == null ? ""
							: (row.getCell(objectIndex).getStringCellValue()).trim());
					simpliLatest.setObjectType(
							(row.getCell(objTypeIndex) == null ? "" : row.getCell(objTypeIndex).getStringCellValue()));
					simpliLatest.setObsolete((row.getCell(obsoleteIndex) == null ? ""
							: row.getCell(obsoleteIndex).getStringCellValue()));
					simpliLatest.setDescription(
							(row.getCell(descIndex) == null ? "" : row.getCell(descIndex).getStringCellValue()));
					simpliLatest.setAffectedArea((row.getCell(affectedAreaIndex) == null ? ""
							: row.getCell(affectedAreaIndex).getStringCellValue()));

					if (row.getCell(relatedNotesIndex) != null) {
						int relateCellType = row.getCell(relatedNotesIndex).getCellType();
						if (relateCellType == 1)
							simpliLatest.setRelatedNotes((row.getCell(relatedNotesIndex) == null ? ""
									: row.getCell(relatedNotesIndex).getStringCellValue()));
						if (relateCellType == 0)
							simpliLatest.setRelatedNotes(row.getCell(relatedNotesIndex) == null ? ""
									: String.valueOf((int) (row.getCell(relatedNotesIndex).getNumericCellValue())));
					}
					simpliLatest.setSolutionSteps((row.getCell(solStepsIndex) == null ? ""
							: row.getCell(solStepsIndex).getStringCellValue()));

					if (row.getCell(errCategryNumericIndex) != null) {
						int errCellType = row.getCell(8).getCellType();
						if (errCellType == 1)
							simpliLatest.setErrCategoryNumeric((row.getCell(errCategryNumericIndex) == null ? ""
									: row.getCell(errCategryNumericIndex).getStringCellValue()));
						if (errCellType == 0)
							simpliLatest.setErrCategoryNumeric(row.getCell(errCategryNumericIndex) == null ? ""
									: String.valueOf(row.getCell(errCategryNumericIndex).getNumericCellValue()));
					}
					// opDataS4.setErrCategoryNumeric((int)(row.getCell(8)==null
					// ?"":row.getCell(8).getNumericCellValue()));
					if (row.getCell(versionIndex) != null) {
						int versionCellType = row.getCell(versionIndex).getCellType();
						if (versionCellType == 1)
							simpliLatest.setVersion(String.valueOf(0d));
						// opDataS4.setErrCategoryNumeric((row.getCell(8)==null
						// ?"":row.getCell(8).getStringCellValue()));
						if (versionCellType == 0)
							simpliLatest.setVersion((row.getCell(versionIndex) == null ? ""
									: String.valueOf(row.getCell(versionIndex).getNumericCellValue())));
					}

					simpliLatest.setIdentifier((row.getCell(identifierIndex) == null ? ""
							: (row.getCell(identifierIndex).getStringCellValue()).trim()));
					simpliLatest.setComplexity(row.getCell(complexityIndex) == null ? ""
							: row.getCell(complexityIndex).getStringCellValue());
					simpliLatest.setIssueCatgry(row.getCell(issueCategoryIndex) == null ? ""
							: row.getCell(issueCategoryIndex).getStringCellValue());
					simpliLatest.setErrorCatgry(row.getCell(errCategoryIndex) == null ? ""
							: row.getCell(errCategoryIndex).getStringCellValue());
					simpliLatest.setTriggerObj(row.getCell(triggerObjIndex) == null ? ""
							: row.getCell(triggerObjIndex).getStringCellValue());
					simpliLatest.setRemediationCatgry(row.getCell(remediCategryIndex) == null ? ""
							: row.getCell(remediCategryIndex).getStringCellValue());
					simpliLatest.setSapSimplListChaptr(row.getCell(sapSimpliListIndex) == null ? ""
							: row.getCell(sapSimpliListIndex).getStringCellValue());
					simpliLatest.setAppComponent(
							row.getCell(appCompIndex) == null ? "" : row.getCell(appCompIndex).getStringCellValue());
					simpliLatest.setSapSimplCatry(row.getCell(sapSimpCatgryIndex) == null ? ""
							: row.getCell(sapSimpCatgryIndex).getStringCellValue());
					simpliLatest.setItm_Area(
							row.getCell(itemAreaIndex) == null ? "" : row.getCell(itemAreaIndex).getStringCellValue());
					simpliLatestList.add(simpliLatest);

				}
			}

			comment = SimplificationDataBatchInsertUpdate(simpliLatestList, session);

		} catch (Exception e) {
			logger.error("Error !!! " + e);
		}
		return comment;

	}

	public static String SimplificationDataBatchInsertUpdate(List<SimplificationLatest> simpliLatestList,
			HttpSession session) throws SQLException {
		final String INSERT_SQL = "INSERT INTO S4_Simplification_Latest "
				+ "(S4_Hana_Changes, Object, Object_Type, Description, Obsolete, Affected_Area, Related_Notes, Solution_Steps, Err_Category_Numeric, Version, Identifier, Complexity, Issue_Catgry,Err_category, Trigger_Obj, Remediation_Catgry, Sap_Simpl_List_Chaptr, App_Comp, Sap_Simpl_Catry, Itm_Area) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		String comment = "";
		finaloutput.deleteSimpliLatestData();
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (SimplificationLatest simpliLatestListData : simpliLatestList) {
					stmt.setString(1, simpliLatestListData.getS4_hana_changes());
					stmt.setString(2, simpliLatestListData.getObject());
					stmt.setString(3, simpliLatestListData.getObjectType());
					stmt.setString(4, simpliLatestListData.getDescription());
					stmt.setString(5, simpliLatestListData.getObsolete());
					stmt.setString(6, simpliLatestListData.getAffectedArea());
					stmt.setString(7, simpliLatestListData.getRelatedNotes());
					stmt.setString(8, simpliLatestListData.getSolutionSteps());
					stmt.setString(9, simpliLatestListData.getErrCategoryNumeric());
					stmt.setString(10, simpliLatestListData.getVersion());
					stmt.setString(11, simpliLatestListData.getIdentifier());
					stmt.setString(12, simpliLatestListData.getComplexity());
					stmt.setString(13, simpliLatestListData.getIssueCatgry());
					stmt.setString(14, simpliLatestListData.getErrorCatgry());
					stmt.setString(15, simpliLatestListData.getTriggerObj());
					stmt.setString(16, simpliLatestListData.getRemediationCatgry());
					stmt.setString(17, simpliLatestListData.getSapSimplListChaptr());
					stmt.setString(18, simpliLatestListData.getAppComponent());
					stmt.setString(19, simpliLatestListData.getSapSimplCatry());
					stmt.setString(20, simpliLatestListData.getItm_Area());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("SimplificationLatest Data INSERTED SUCCESSFULLY");
				comment = "success";

			} catch (Exception e) {
				comment = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			comment = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return comment;

	}

	private void addBigSimplificationDBData(String filePath, long requestId, HttpSession session)
			throws FileNotFoundException {
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);

		String fileName = file.getName();

		List<S4SimplificationDatabase> simpliDBList = new ArrayList<S4SimplificationDatabase>();
		logger.info("Coming inside ReadBIGSimplificationDATA simpliDBList::::" + simpliDBList);
		try {
			logger.info("Coming inside ReadBIGSimplificationDATA inputStream::::" + inputStream);
			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);

			for (Row row : reader) {
				if (row.getRowNum() > 0) {
					int s4HanaChangesIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("S4.Hana.Changes"));
					int objectIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Object"));
					int objTypeIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Object.Type"));
					int obsoleteIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("OBSOLETE"));
					int descIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Description"));
					int affectedAreaIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Affected.Area"));
					int relatedNotesIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Related.Notes"));
					int solStepsIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Solution.Steps"));
					int errCategryNumericIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE
							.get(requestId).get(fileName).get("Error.Category.Num"));
					int versionIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Version"));
					int identifierIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Identifier"));
					int complexityIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("COMPLEXITY"));
					int issueCategoryIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("ISSUE.CATEGORY"));
					int errCategoryIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("ERROR.CATEGORY"));
					int triggerObjIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("TRIGGER.OBJECT"));
					int remediCategryIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("Remediation.Category"));
					int sapSimpliListIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("SAP.Simplification.List.chapter"));
					int appCompIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("APPLICATION.COMPONENT"));
					int sapSimpCatgryIndex = Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId)
							.get(fileName).get("SAP.Simpl.Category"));
					int itemAreaIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Item.Area"));

					S4SimplificationDatabase simpliDB = new S4SimplificationDatabase();
					simpliDB.setS4HANAChanges((row.getCell(s4HanaChangesIndex) == null ? ""
							: row.getCell(s4HanaChangesIndex).getStringCellValue()));
					simpliDB.setObject(row.getCell(objectIndex) == null ? ""
							: (row.getCell(objectIndex).getStringCellValue()).trim());
					simpliDB.setObjectType(
							(row.getCell(objTypeIndex) == null ? "" : row.getCell(objTypeIndex).getStringCellValue()));
					simpliDB.setObsolete((row.getCell(obsoleteIndex) == null ? ""
							: row.getCell(obsoleteIndex).getStringCellValue()));
					simpliDB.setDescription(
							(row.getCell(descIndex) == null ? "" : row.getCell(descIndex).getStringCellValue()));
					simpliDB.setAffectedArea((row.getCell(affectedAreaIndex) == null ? ""
							: row.getCell(affectedAreaIndex).getStringCellValue()));
					simpliDB.setSolutionSteps((row.getCell(solStepsIndex) == null ? ""
							: row.getCell(solStepsIndex).getStringCellValue()));

					if (row.getCell(relatedNotesIndex) != null) {
						int relateCellType = row.getCell(relatedNotesIndex).getCellType();

						if (relateCellType == 1)
							simpliDB.setRelatedNotes((row.getCell(relatedNotesIndex) == null ? ""
									: row.getCell(relatedNotesIndex).getStringCellValue()));
						if (relateCellType == 0)
							simpliDB.setRelatedNotes(row.getCell(relatedNotesIndex) == null ? ""
									: String.valueOf((int) (row.getCell(relatedNotesIndex).getNumericCellValue())));
					}

					if (row.getCell(errCategryNumericIndex) != null) {
						int errCellType = row.getCell(8).getCellType();

						if (errCellType == 1)
							simpliDB.setErrCategoryNumeric((row.getCell(errCategryNumericIndex) == null ? ""
									: row.getCell(errCategryNumericIndex).getStringCellValue()));
						if (errCellType == 0)
							simpliDB.setErrCategoryNumeric(row.getCell(errCategryNumericIndex) == null ? ""
									: String.valueOf(row.getCell(errCategryNumericIndex).getNumericCellValue()));
					}

					if (row.getCell(versionIndex) != null) {
						int versionCellType = row.getCell(versionIndex).getCellType();

						if (versionCellType == 1)
							simpliDB.setVersion(String.valueOf(0d));
						if (versionCellType == 0)
							simpliDB.setVersion((row.getCell(versionIndex) == null ? ""
									: String.valueOf(row.getCell(versionIndex).getNumericCellValue())));
					}

					simpliDB.setIdentifier((row.getCell(identifierIndex) == null ? ""
							: (row.getCell(identifierIndex).getStringCellValue()).trim()));
					simpliDB.setComplexity(row.getCell(complexityIndex) == null ? ""
							: row.getCell(complexityIndex).getStringCellValue());
					simpliDB.setIssueCatgry(row.getCell(issueCategoryIndex) == null ? ""
							: row.getCell(issueCategoryIndex).getStringCellValue());
					simpliDB.setErrCategory(row.getCell(errCategoryIndex) == null ? ""
							: row.getCell(errCategoryIndex).getStringCellValue());
					simpliDB.setTriggerObj(row.getCell(triggerObjIndex) == null ? ""
							: row.getCell(triggerObjIndex).getStringCellValue());
					simpliDB.setRemediationCatgry(row.getCell(remediCategryIndex) == null ? ""
							: row.getCell(remediCategryIndex).getStringCellValue());
					simpliDB.setSapSimplListChaptr(row.getCell(sapSimpliListIndex) == null ? ""
							: row.getCell(sapSimpliListIndex).getStringCellValue());
					simpliDB.setAppComponent(
							row.getCell(appCompIndex) == null ? "" : row.getCell(appCompIndex).getStringCellValue());
					simpliDB.setSapSimplCatry(row.getCell(sapSimpCatgryIndex) == null ? ""
							: row.getCell(sapSimpCatgryIndex).getStringCellValue());
					simpliDB.setItm_Area(
							row.getCell(itemAreaIndex) == null ? "" : row.getCell(itemAreaIndex).getStringCellValue());
					simpliDBList.add(simpliDB);
				}
			}

			bigSimplificationDBDataBatchInsertUpdate(simpliDBList, session);
		} catch (Exception e) {
			logger.error("Error while inserting data to Big Simplification File " + e);
		}
	}

	public static String bigSimplificationDBDataBatchInsertUpdate(
			List<S4SimplificationDatabase> bigSimplificationDatabaseList, HttpSession session) throws SQLException {
		final String INSERT_SQL = "INSERT INTO S4_Simplification_Database "
				+ "(S4_Hana_Changes, Object, Object_Type, Obsolete, Description, Affected_Area, Related_Notes, Solution_Steps, Err_Category, Version, Identifier, "
				+ "Err_Category_Numeric, Complexity, Issue_Catgry, Trigger_Obj, Remediation_Catgry, Sap_Simpl_List_Chaptr, App_Comp, Sap_Simpl_Catry, "
				+ "Itm_Area) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		finaloutput.deleteS4SimpliDB();
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (S4SimplificationDatabase bigSimplificationDatabase : bigSimplificationDatabaseList) {
					stmt.setString(1, bigSimplificationDatabase.getS4HANAChanges());
					stmt.setString(2, bigSimplificationDatabase.getObject());
					stmt.setString(3, bigSimplificationDatabase.getObjectType());
					stmt.setString(4, bigSimplificationDatabase.getObsolete());
					stmt.setString(5, bigSimplificationDatabase.getDescription());

					stmt.setString(6, bigSimplificationDatabase.getAffectedArea());
					stmt.setString(7, bigSimplificationDatabase.getRelatedNotes());
					stmt.setString(8, bigSimplificationDatabase.getSolutionSteps());
					stmt.setString(9, bigSimplificationDatabase.getErrCategory());
					stmt.setString(10, bigSimplificationDatabase.getVersion());

					stmt.setString(11, bigSimplificationDatabase.getIdentifier());
					stmt.setString(12, bigSimplificationDatabase.getErrCategoryNumeric());
					stmt.setString(13, bigSimplificationDatabase.getComplexity());
					stmt.setString(14, bigSimplificationDatabase.getIssueCatgry());
					stmt.setString(15, bigSimplificationDatabase.getTriggerObj());

					stmt.setString(16, bigSimplificationDatabase.getRemediationCatgry());
					stmt.setString(17, bigSimplificationDatabase.getSapSimplListChaptr());
					stmt.setString(18, bigSimplificationDatabase.getAppComponent());
					stmt.setString(19, bigSimplificationDatabase.getSapSimplCatry());
					stmt.setString(20, bigSimplificationDatabase.getItm_Area());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("S4_Simplification_Database Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error("Error while inserting data in Big Simplification DB : ", e);
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error("Error while inserting data in Big Simplification DB : ", e);
		} finally {
			stmt.close();
			conn.close();
		}

		return result;
	}

	// CR-61: New Estimation sheet added with a separate template addition for Admin
	public String readEstimationData(final String path, final long requestId, HttpServletRequest request,
			String toolName, HttpSession session) {
		String comment = "";
		FileInputStream inputStream;
		try {
			inputStream = new FileInputStream(new File(path));
			Sheet estimatorSheet = null;
			Sheet assumptionsSheet = null;
			Workbook workbook = new XSSFWorkbook(inputStream);
			int noOfSheets = workbook.getNumberOfSheets();
			for (int i = 0; i < noOfSheets; i++) {
				if (workbook.getSheetAt(i) != null
						&& "Effort Estimation".equalsIgnoreCase(workbook.getSheetAt(i).getSheetName().trim())) {
					estimatorSheet = workbook.getSheetAt(i);
				}
				/*
				 * if(workbook.getSheetAt(i) !=null &&
				 * "S4 Assumptions".equalsIgnoreCase(workbook.getSheetAt(i).getSheetName().trim(
				 * ))){ assumptionsSheet = workbook.getSheetAt(i); }
				 */
			}
			if (estimatorSheet == null) {
				comment = "Upload xlsx file should have Effort Estimation sheet";
				return comment;
			} else {
				S4Estimations S4Estimatior = new S4Estimations();
				// Reading Mandatory Estimation
				S4Estimatior.setMandatoryAnalysisEffortsHigh(
						(int) (estimatorSheet.getRow(6).getCell(4).getNumericCellValue()));
				S4Estimatior.setMandatoryDesignEffortsHigh(
						(int) (estimatorSheet.getRow(7).getCell(4).getNumericCellValue()));
				S4Estimatior.setMandatoryBuildEffortsHigh(
						(int) (estimatorSheet.getRow(8).getCell(4).getNumericCellValue()));
				S4Estimatior
						.setMandatoryUnitTestingHigh((int) (estimatorSheet.getRow(9).getCell(4).getNumericCellValue()));
				S4Estimatior.setMandatoryEffortRemediateCustomHigh(
						(int) (estimatorSheet.getRow(10).getCell(4).getNumericCellValue()));
				S4Estimatior.setMandatorySPDD_SPAU_EffortsHigh(
						(int) (estimatorSheet.getRow(11).getCell(4).getNumericCellValue()));

				S4Estimatior.setMandatoryAnalysisEffortsLow(
						(int) (estimatorSheet.getRow(6).getCell(3).getNumericCellValue()));
				S4Estimatior.setMandatoryDesignEffortsLow(
						(int) (estimatorSheet.getRow(7).getCell(3).getNumericCellValue()));
				S4Estimatior
						.setMandatoryBuildEffortsLow((int) (estimatorSheet.getRow(8).getCell(3).getNumericCellValue()));
				S4Estimatior
						.setMandatoryUnitTestingLow((int) (estimatorSheet.getRow(9).getCell(3).getNumericCellValue()));
				S4Estimatior.setMandatoryEffortRemediateCustomLow(
						(int) (estimatorSheet.getRow(10).getCell(3).getNumericCellValue()));
				S4Estimatior.setMandatorySPDD_SPAU_EffortsLow(
						(int) (estimatorSheet.getRow(11).getCell(3).getNumericCellValue()));

				// Reading Mandatory Used Estimation
				S4Estimatior.setMandatoryUsedAnalysisEffortsHigh(
						(int) (estimatorSheet.getRow(18).getCell(4).getNumericCellValue()));
				S4Estimatior.setMandatoryUsedDesignEffortsHigh(
						(int) (estimatorSheet.getRow(19).getCell(4).getNumericCellValue()));
				S4Estimatior.setMandatoryUsedBuildEffortsHigh(
						(int) (estimatorSheet.getRow(20).getCell(4).getNumericCellValue()));
				S4Estimatior.setMandatoryUsedUnitTestingHigh(
						(int) (estimatorSheet.getRow(21).getCell(4).getNumericCellValue()));
				S4Estimatior.setMandatoryUsedEffortRemediateCustomHigh(
						(int) (estimatorSheet.getRow(22).getCell(4).getNumericCellValue()));
				S4Estimatior.setMandatoryUsedSPDD_SPAU_EffortsHigh(
						(int) (estimatorSheet.getRow(23).getCell(4).getNumericCellValue()));

				S4Estimatior.setMandatoryUsedAnalysisEffortsLow(
						(int) (estimatorSheet.getRow(18).getCell(3).getNumericCellValue()));
				S4Estimatior.setMandatoryUsedDesignEffortsLow(
						(int) (estimatorSheet.getRow(19).getCell(3).getNumericCellValue()));
				S4Estimatior.setMandatoryUsedBuildEffortsLow(
						(int) (estimatorSheet.getRow(20).getCell(3).getNumericCellValue()));
				S4Estimatior.setMandatoryUsedUnitTestingLow(
						(int) (estimatorSheet.getRow(21).getCell(3).getNumericCellValue()));
				S4Estimatior.setMandatoryUsedEffortRemediateCustomLow(
						(int) (estimatorSheet.getRow(22).getCell(3).getNumericCellValue()));
				S4Estimatior.setMandatoryUsedSPDD_SPAU_EffortsLow(
						(int) (estimatorSheet.getRow(23).getCell(3).getNumericCellValue()));

				// Reading Optional Estimation
				S4Estimatior.setOptionalAnalysisEffortsHigh(
						(int) (estimatorSheet.getRow(29).getCell(4).getNumericCellValue()));
				S4Estimatior.setOptionalDesignEffortsHigh(
						(int) (estimatorSheet.getRow(30).getCell(4).getNumericCellValue()));
				S4Estimatior.setOptionalBuildEffortsHigh(
						(int) (estimatorSheet.getRow(31).getCell(4).getNumericCellValue()));
				S4Estimatior
						.setOptionalUnitTestingHigh((int) (estimatorSheet.getRow(32).getCell(4).getNumericCellValue()));
				S4Estimatior.setOptionalEffortRemediateCustomHigh(
						(int) (estimatorSheet.getRow(33).getCell(4).getNumericCellValue()));
				S4Estimatior.setOptionalSPDD_SPAU_EffortsHigh(
						(int) (estimatorSheet.getRow(34).getCell(4).getNumericCellValue()));

				S4Estimatior.setOptionalAnalysisEffortsLow(
						(int) (estimatorSheet.getRow(29).getCell(3).getNumericCellValue()));
				S4Estimatior.setOptionalDesignEffortsLow(
						(int) (estimatorSheet.getRow(30).getCell(3).getNumericCellValue()));
				S4Estimatior
						.setOptionalBuildEffortsLow((int) (estimatorSheet.getRow(31).getCell(3).getNumericCellValue()));
				S4Estimatior
						.setOptionalUnitTestingLow((int) (estimatorSheet.getRow(32).getCell(3).getNumericCellValue()));
				S4Estimatior.setOptionalEffortRemediateCustomLow(
						(int) (estimatorSheet.getRow(33).getCell(3).getNumericCellValue()));
				S4Estimatior.setOptionalSPDD_SPAU_EffortsLow(
						(int) (estimatorSheet.getRow(34).getCell(3).getNumericCellValue()));

				// Reading Optional Used Estimation
				S4Estimatior.setOptionalUsedAnalysisEffortsHigh(
						(int) (estimatorSheet.getRow(40).getCell(4).getNumericCellValue()));
				S4Estimatior.setOptionalUsedDesignEffortsHigh(
						(int) (estimatorSheet.getRow(41).getCell(4).getNumericCellValue()));
				S4Estimatior.setOptionalUsedBuildEffortsHigh(
						(int) (estimatorSheet.getRow(42).getCell(4).getNumericCellValue()));
				S4Estimatior.setOptionalUsedUnitTestingHigh(
						(int) (estimatorSheet.getRow(43).getCell(4).getNumericCellValue()));
				S4Estimatior.setOptionalUsedEffortRemediateCustomHigh(
						(int) (estimatorSheet.getRow(44).getCell(4).getNumericCellValue()));
				S4Estimatior.setOptionalUsedSPDD_SPAU_EffortsHigh(
						(int) (estimatorSheet.getRow(45).getCell(4).getNumericCellValue()));

				S4Estimatior.setOptionalUsedAnalysisEffortsLow(
						(int) (estimatorSheet.getRow(40).getCell(3).getNumericCellValue()));
				S4Estimatior.setOptionalUsedDesignEffortsLow(
						(int) (estimatorSheet.getRow(41).getCell(3).getNumericCellValue()));
				S4Estimatior.setOptionalUsedBuildEffortsLow(
						(int) (estimatorSheet.getRow(42).getCell(3).getNumericCellValue()));
				S4Estimatior.setOptionalUsedUnitTestingLow(
						(int) (estimatorSheet.getRow(43).getCell(3).getNumericCellValue()));
				S4Estimatior.setOptionalUsedEffortRemediateCustomLow(
						(int) (estimatorSheet.getRow(44).getCell(3).getNumericCellValue()));
				S4Estimatior.setOptionalUsedSPDD_SPAU_EffortsLow(
						(int) (estimatorSheet.getRow(45).getCell(3).getNumericCellValue()));
				S4Estimatior.setRequestID(requestId);

				comment = getS4DaoIntf().addEstimatorData(S4Estimatior);
			}
			// for reading estimation
			/*
			 * String textToSave=""; StringBuilder finalStringb =new StringBuilder();
			 * if(assumptionsSheet!=null){ if(assumptionsSheet.getLastRowNum()>1){ for(int
			 * i=3; i<assumptionsSheet.getLastRowNum();i++){
			 * 
			 * int cellType=assumptionsSheet.getRow(i).getCell(1).getCellType(); if(cellType
			 * == 1)
			 * finalStringb.append(assumptionsSheet.getRow(i).getCell(1).getStringCellValue(
			 * )).append("@@@") ; else
			 * finalStringb.append(assumptionsSheet.getRow(i).getCell(1).getStringCellValue(
			 * )).append("@@@") ; } }textToSave=finalStringb.toString(); S4Assumptions
			 * s4Assumptions=new S4Assumptions(); s4Assumptions.setRequestID(requestId);
			 * s4Assumptions.setAssumptions(textToSave);
			 * comment=getS4DaoIntf().addAssumptionsData(s4Assumptions); }
			 */
			if (comment.equalsIgnoreCase("success")) {
				String status = Hana_Profiler_Constant.HANAREFININGCOMPLETED_STATUS;
				String comments = Hana_Profiler_Constant.HANAREFININGCOMPLETED_STATUS_COMMENT;
				// getRequestInventorydao().updateSatus(requestId, status, getPrincipal(),
				// comments,toolName);

				// CR-12.3 Update Request_master table with Estimations
				getGraphDao().updateRequestMasterEstimations(requestId);

				// call mail method from here
				sendEmailForCompletedRequest(status, requestId, request, Hana_Profiler_Constant.COMPLETED_STATUS,
						session);
			}

			return comment;

		} catch (FileNotFoundException e) {
			logger.error("Error !!! " + e);
		} catch (IOException e) {
			logger.error("Error !!! " + e);
		}
		return comment;
	}

	// CR-61: New Estimation sheet added with a separate template addition for Admin
	private void sendEmailForCompletedRequest(String succOrFailureReason, long requestId, HttpServletRequest request,
			String successOrFailure, HttpSession session) {
		logger.info("Coming Inside  sendEmailForProcessedRequest values " + succOrFailureReason + "****" + requestId
				+ "****" + request.getServerName() + "successOrFailure " + successOrFailure);
		String emailContext = "https://" + request.getServerName() + ":" + request.getServerPort();
		Set<String> emailData = new HashSet<String>();
		Set<String> emailCc = new HashSet<String>();
		SendEmail email = new SendEmail();
		email.setMailFrom("IDC_SAPUpgrade_Sales@accenture.com");
		emailCc.add("IDC_SAPUpgrade_Sales@accenture.com");

		final RequestForm requestForm = getRequestDetails().getRequestObj(requestId);

		emailData.add(requestForm.getClientTeamDetails());
		email.setMailTo(emailData);
		email.setMailCC(emailCc);

		email.setMailSubject(
				"Request ID : " + requestForm.getREQUEST_ID_UI() + " Processed " + "<" + successOrFailure + ">");
		email.setMailBody("\n\nDear " + getPrincipal() + ",\n\nYour Request " + requestForm.getREQUEST_ID_UI()
				+ "  Has Been Processsed With Status : " + successOrFailure + " .\n\n"
				+ "Estimator and(or) Assumptions has been uploaded by Administrator(" + requestForm.getPocName()
				+ ").\nYou can download output sheet from \n\n" + "<a href=" + emailContext
				+ "/hanaprofilerperformance/client/requestDetails/" + requestForm.getRequestID()
				+ ">Download Estimator/Assumptions</a>\n\n" +

				"<a href=" + emailContext + "/hanaprofilerperformance/client/requestDetails/"
				+ requestForm.getRequestID() + ">Download Complete Output</a>\n\n" +

				"\nNote:-Please Contact To Administrator (" + requestForm.getPocName()
				+ ") If Request Is Not Completed.\n\n" + "<a href=" + emailContext
				+ "/hanaprofilerperformance/client/requestDetails/" + requestForm.getRequestID()
				+ ">Client - View Request Detail</a>\n\n" + "<a href=" + emailContext
				+ "/hanaprofilerperformance/requestDetails/" + requestForm.getRequestID()
				+ ">Admin/Poc - View Request Detail</a>" + "\n\n\nRegards,\nS/4HANA conversion Team ATCI");
		email.emailSend(email, request, session);

	}

	public String readValidationData(final String path, final long requestId, HttpServletRequest request) {

		logger.info("Coming inside readValidationData");
		String comment = "";
		FileInputStream inputStream;
		List<S4ValidationList> validationDataS4List = new ArrayList<S4ValidationList>();
		logger.info("Coming inside readValidationData opDataS4List::::" + validationDataS4List);
		try {
			inputStream = new FileInputStream(new File(path));
			logger.info("Coming inside readValidationData inputStream::::" + inputStream);
			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);

			for (Row row : reader) {
				if (row.getRowNum() > 0) {

					S4ValidationList validDataS4 = new S4ValidationList();
					validDataS4.setIdentifier((row.getCell(0) == null ? "" : row.getCell(0).getStringCellValue()));
					if (row.getCell(1) != null) {
						int versionCellType = row.getCell(1).getCellType();
						if (versionCellType == 1)
							validDataS4.setVersion(row.getCell(1) == null ? "" : row.getCell(1).getStringCellValue());
						// opDataS4.setErrCategoryNumeric((row.getCell(8)==null
						// ?"":row.getCell(8).getStringCellValue()));
						if (versionCellType == 0)
							validDataS4.setVersion(row.getCell(1) == null ? ""
									: String.valueOf((int) (row.getCell(1).getNumericCellValue())));
					}
					validDataS4.setObject((row.getCell(2) == null ? "" : row.getCell(2).getStringCellValue()));
					validDataS4.setSubObject((row.getCell(3) == null ? "" : row.getCell(3).getStringCellValue()));
					validDataS4.setObjectType(row.getCell(4) == null ? "" : row.getCell(4).getStringCellValue());
					validDataS4.setProgramName((row.getCell(5) == null ? "" : row.getCell(5).getStringCellValue()));
					validDataS4.setScreen(
							row.getCell(6) == null ? "" : String.valueOf((int) (row.getCell(6).getNumericCellValue())));
					validDataS4.setObsolete(row.getCell(7) == null ? "" : row.getCell(7).getStringCellValue());
					validDataS4.setNew_Len(row.getCell(8) == null ? "" : row.getCell(8).getStringCellValue());
					validDataS4.setAffectedArea(row.getCell(9) == null ? "" : row.getCell(9).getStringCellValue());

					validationDataS4List.add(validDataS4);

				}
			}

			comment = getS4DaoIntf().addValidationData(validationDataS4List);
		} catch (FileNotFoundException e) {
			logger.error("Error !!! " + e);
		} catch (IOException e) {
			logger.error("Error !!! " + e);
		}
		return comment;
	}

	public String readSimplificationDBData(final String path, final long requestId, HttpServletRequest request) {

		logger.info("Coming inside ReadSimplificationDBDATA");
		String comment = "";
		FileInputStream inputStream;
		List<S4SimplificationDatabase> simplifiDBList = new ArrayList<S4SimplificationDatabase>();
		logger.info("Coming inside ReadSimplificationDBDATA simplifiDBList::::" + simplifiDBList);
		try {
			inputStream = new FileInputStream(new File(path));
			logger.info("Coming inside ReadSimplificationDBDATA inputStream::::" + inputStream);
			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);

			for (Row row : reader) {
				if (row.getRowNum() > 0) {

					S4SimplificationDatabase s4SimplificationDB = new S4SimplificationDatabase();
					s4SimplificationDB
							.setS4HANAChanges((row.getCell(0) == null ? "" : row.getCell(0).getStringCellValue()));
					s4SimplificationDB.setObject((row.getCell(1) == null ? "" : row.getCell(1).getStringCellValue()));
					s4SimplificationDB
							.setObjectType((row.getCell(2) == null ? "" : row.getCell(2).getStringCellValue()));
					s4SimplificationDB.setObsolete((row.getCell(3) == null ? "" : row.getCell(3).getStringCellValue()));
					s4SimplificationDB
							.setDescription((row.getCell(4) == null ? "" : row.getCell(4).getStringCellValue()));
					s4SimplificationDB
							.setAffectedArea((row.getCell(5) == null ? "" : row.getCell(5).getStringCellValue()));

					if (row.getCell(6) != null) {
						int relateCellType = row.getCell(6).getCellType();
						if (relateCellType == 1)
							s4SimplificationDB.setRelatedNotes(
									(row.getCell(6) == null ? "" : row.getCell(6).getStringCellValue()));
						if (relateCellType == 0)
							s4SimplificationDB.setRelatedNotes(row.getCell(6) == null ? ""
									: String.valueOf((int) (row.getCell(6).getNumericCellValue())));
					}
					s4SimplificationDB
							.setSolutionSteps((row.getCell(7) == null ? "" : row.getCell(7).getStringCellValue()));

					if (row.getCell(8) != null) {
						int errCellType = row.getCell(8).getCellType();
						if (errCellType == 1)
							s4SimplificationDB.setErrCategory(
									(row.getCell(8) == null ? "" : row.getCell(8).getStringCellValue()));
						if (errCellType == 0)
							s4SimplificationDB.setErrCategory(
									row.getCell(8) == null ? "" : String.valueOf(row.getCell(8).getNumericCellValue()));
					}
					// opDataS4.setErrCategoryNumeric((int)(row.getCell(8)==null
					// ?"":row.getCell(8).getNumericCellValue()));
					if ((row.getCell(9) != null)) {
						int versionCellType = (row.getCell(9).getCellType());
						if (versionCellType == 1)
							s4SimplificationDB
									.setVersion((row.getCell(9) == null ? "" : row.getCell(9).getStringCellValue()));
						// opDataS4.setErrCategoryNumeric((row.getCell(8)==null
						// ?"":row.getCell(8).getStringCellValue()));
						if (versionCellType == 0)
							s4SimplificationDB.setVersion((row.getCell(9) == null ? ""
									: String.valueOf((int) (row.getCell(9).getNumericCellValue()))));
					}

					// s4SimplificationDB.setVersion((row.getCell(9)==null?"":String.valueOf
					// (row.getCell(9).getNumericCellValue()))));
					s4SimplificationDB
							.setIdentifier((row.getCell(10) == null ? "" : row.getCell(10).getStringCellValue()));

					simplifiDBList.add(s4SimplificationDB);

				}
			}

			comment = getS4DaoIntf().addSimplificationDBData(simplifiDBList);
		} catch (FileNotFoundException e) {
			logger.error("Error !!! " + e);
		} catch (IOException e) {
			logger.error("Error !!! " + e);
		}
		return comment;
	}

	/*
	 * public String createSimplification(long requestId){ String comment="";
	 * comment=getS4DaoIntf().deleteOprDataS4();
	 * comment=getS4DaoIntf().updateS4OperationIdentifier(requestId);
	 * comment=getS4DaoIntf().updateOperDataFrmSimplLatest();
	 * comment=getS4DaoIntf().updateOperDataFrmSimplDB();
	 * comment=getS4DaoIntf().updateImpact(requestId);
	 * 
	 * return comment; }
	 */

	public String uploadSimplificationData(final String path, final long requestId, HttpServletRequest request)
			throws FileNotFoundException {
		logger.info("Coming inside ReadSimplificationDATA");
		String comment = "";
		FileInputStream inputStream;
		List<OperationDataS4> opDataS4List = new ArrayList<OperationDataS4>();
		logger.info("Coming inside ReadSimplificationDATA opDataS4List::::" + opDataS4List);
		try {
			inputStream = new FileInputStream(new File(path));
			logger.info("Coming inside ReadSimplificationDATA inputStream::::" + inputStream);
			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);

			for (Row row : reader) {
				if (row.getRowNum() > 0) {

					OperationDataS4 opDataS4 = new OperationDataS4();
					opDataS4.setS4_hana_changes((row.getCell(0) == null ? "" : row.getCell(0).getStringCellValue()));
					opDataS4.setObject((row.getCell(1) == null ? "" : row.getCell(1).getStringCellValue()));
					opDataS4.setObjectType((row.getCell(2) == null ? "" : row.getCell(2).getStringCellValue()));
					opDataS4.setObsolete((row.getCell(3) == null ? "" : row.getCell(3).getStringCellValue()));
					opDataS4.setDescription((row.getCell(4) == null ? "" : row.getCell(4).getStringCellValue()));
					opDataS4.setAffectedArea((row.getCell(5) == null ? "" : row.getCell(5).getStringCellValue()));

					if (row.getCell(6) != null) {
						int relateCellType = row.getCell(6).getCellType();
						if (relateCellType == 1)
							opDataS4.setRelatedNotes(
									(row.getCell(6) == null ? "" : row.getCell(6).getStringCellValue()));
						if (relateCellType == 0)
							opDataS4.setRelatedNotes(row.getCell(6) == null ? ""
									: String.valueOf((int) (row.getCell(6).getNumericCellValue())));
					}
					opDataS4.setSolutionSteps((row.getCell(7) == null ? "" : row.getCell(7).getStringCellValue()));

					if (row.getCell(8) != null) {
						int errCellType = row.getCell(8).getCellType();
						if (errCellType == 1)
							opDataS4.setErrCategoryNumeric(
									(row.getCell(8) == null ? "" : row.getCell(8).getStringCellValue()));
						if (errCellType == 0)
							opDataS4.setErrCategoryNumeric(row.getCell(8) == null ? ""
									: String.valueOf((int) (row.getCell(8).getNumericCellValue())));
					}
					// opDataS4.setErrCategoryNumeric((int)(row.getCell(8)==null
					// ?"":row.getCell(8).getNumericCellValue()));
					if (row.getCell(9) != null) {
						int versionCellType = row.getCell(9).getCellType();
						if (versionCellType == 1)
							opDataS4.setVersion(String.valueOf(0d));
						// opDataS4.setErrCategoryNumeric((row.getCell(8)==null
						// ?"":row.getCell(8).getStringCellValue()));
						if (versionCellType == 0)
							opDataS4.setVersion((row.getCell(9) == null ? ""
									: String.valueOf((int) ((row.getCell(9).getNumericCellValue())))));
					}

					opDataS4.setIdentifier((row.getCell(10) == null ? "" : row.getCell(10).getStringCellValue()));
					opDataS4.setComplexity(row.getCell(11) == null ? "" : row.getCell(11).getStringCellValue());
					opDataS4.setIssueCatgry(row.getCell(12) == null ? "" : row.getCell(12).getStringCellValue());
					opDataS4.setErrorCatgry(row.getCell(13) == null ? "" : row.getCell(13).getStringCellValue());
					opDataS4.setTriggerObj(row.getCell(14) == null ? "" : row.getCell(14).getStringCellValue());
					opDataS4.setRemediationCatgry(row.getCell(15) == null ? "" : row.getCell(15).getStringCellValue());
					opDataS4.setSapSimplListChaptr(row.getCell(16) == null ? "" : row.getCell(16).getStringCellValue());
					opDataS4.setAppComponent(row.getCell(17) == null ? "" : row.getCell(17).getStringCellValue());
					opDataS4.setSapSimplCatry(row.getCell(18) == null ? "" : row.getCell(18).getStringCellValue());
					opDataS4.setItm_Area(row.getCell(19) == null ? "" : row.getCell(19).getStringCellValue());
					opDataS4List.add(opDataS4);

				}
			}

			comment = getS4DaoIntf().addSimplificationDataS(opDataS4List);
		} catch (FileNotFoundException e) {
			logger.error("Error !!! " + e);
		} catch (IOException e) {
			logger.error("Error !!! " + e);
		}
		return comment;
	}

//New Defect for Big Simplification version 1809
	public synchronized void readBigSimplificationDBData(final String path, final long requestId,
			HttpServletRequest request, HttpSession session) throws FileNotFoundException {

		logger.info("Coming inside readSimplificationDBData");
		String filePath = "";
		String comment = "";
		hm.setSession(session);

		// final String rootPath = HANAUtility.getFilePath("DB Simplification Files",
		// 0);
		final File rootFolderFileList[] = new File(path).listFiles();
		try {
			for (File file : rootFolderFileList) {
				logger.info("Analysing file : " + file);
				filePath = file.getCanonicalPath();
				logger.info("filePath:::: " + filePath);

				final File fil = new File(filePath);
				String filPath = fil.getName().toUpperCase();
				if (filPath.toUpperCase()
						.contains((S4HanaProfilerConstant.BIG_SIMPLIFICATION_CONSTANT).toUpperCase())) {
					addBigSimplificationDBData(filePath, requestId, session);
				}
			}
		} catch (IOException e) {
			logger.error(e.getMessage());
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}

	public String inputFileMigrationRead(HttpSession session, long requestId, Map<String, String> fileMap,
			List<String> siaReqIDsList) throws Exception {
		RequestForm requestForm = getRequestDetails().getRequestObj(requestId);

		logger.info("Welcome to inputFileMigrationRead for reading the excel");
		String status = "";

		try {
			getAutoHANA().clearAllTables(requestId);
			getAutoHANA().clearDownloadTable(requestId);
			getAutoHANA().clearUI5Tables(requestId);
			getAutoHANA().clearTestingScopeTables(requestId);
			getAutoHANA().clearRequestMasterTable(requestId);
			getAutoHANA().clearSIATCDReport(requestId);
		} catch (Exception e) {
			status = Hana_Profiler_Constant.POC_CLEAR_TABLE_FAIL;
			logger.error(status + " :: " + e);
			logger.error(e.getMessage());
			throw new Exception(status);
		}

		String rootPath = HANAUtility.getFinalFilePath(requestForm.getClientName(), requestId);
		File folder = new File(rootPath);
		File[] listOfFiles = folder.listFiles();

		for (File file : listOfFiles) {
			FileUtility.checkFileSize(file);
			if (file.isFile()) {
				try {
					logger.info("USER Uploaded File");

					String retrievedcompleteFilePath = rootPath + "\\" + file.getName();
					logger.info("Retrieved complete FilePath");

					if (MapUtils.isNotEmpty(fileMap)) {
						String comment = finalFileUpload.readMigrationSheetData(retrievedcompleteFilePath, requestId,
								requestForm, session, fileMap);

						logger.info(comment);
					}
				} catch (Exception e) {
					status = Hana_Profiler_Constant.POC_TRANSFER_DATA_FAIL;
					logger.error(status + " :: " + e);
					logger.error(e.getMessage());
					throw new Exception(status);
				}
			}
		}

		try {
			reqMasterService.getRequestMasterCounts(requestId, siaReqIDsList);
			dataTransferAndClearTables(requestId,requestForm);
			// pocEstimationsProcessing(requestId, requestForm, session);
		} catch (Exception e) {
			logger.error("Error while reading and processing the Final Report : ", e);
			throw new Exception();
		}

		return status;
	}

	public void pocFileProcessing(long requestId, RequestForm requestForm, HttpSession session) throws Exception {

		String status = "";
		boolean scopeHana = requestForm.getSOH();
		boolean scopeS4 = requestForm.getS4Technical();
		boolean scopeUI5 = requestForm.getUI5();
		long startTimeforupdateDetailReport = System.currentTimeMillis();
		getPopulatingS4FinalOutput().updateDetailReport(requestId);
		long endTimeforupdateDetailReport = System.currentTimeMillis();
		long netTimeupdateDetailReport = endTimeforupdateDetailReport - startTimeforupdateDetailReport;
		logger.info("Total time for updateDetailReport: " + netTimeupdateDetailReport);
		logger.info("updateDetailReport values got updated in Detail Report%%%%%%%%%%%%%%%%%%%%%%%");

		long startTimeforupdateDetailRemediReport = System.currentTimeMillis();
		getPopulatingS4FinalOutput().updateDetailRemediReport(requestId);
		long endTimeforupdateDetailRemediReport = System.currentTimeMillis();
		long netTimeupdateDetailRemediReport = endTimeforupdateDetailRemediReport
				- startTimeforupdateDetailRemediReport;
		logger.info("Total time for updateDetailRemediReportt: " + netTimeupdateDetailRemediReport);
		logger.info("updateDetailRemediReport values got updated in Detail Report%%%%%%%%%%%%%%%%%%%%%%%");

		getAutoHANA().clearRequestMasterTable(requestId);

		try {
			ProcessedRequestDetail requestMasterCommon = getGraphDao().getRequestMasterCommonColumns(requestId);

			if (scopeHana) {
				getGraphDao().updateRequestMaster(requestId, requestMasterCommon);
			}
			if (scopeS4) {
				logger.info(
						"::::::::::::::::::::START======================================Scope S4 job Counts::::::::::::::::::::::");
				graphS4DAO.updateRequestMasterS4(requestId, requestMasterCommon);
				logger.info(
						"::::::::::::::::::::END======================================Scope S4 job Counts::::::::::::::::::::::");
			}

			getGraphDao().testingScopeRequestMaster(requestId, session);
			logger.info(
					"::::::::::::::::::::START======================================Impacted Background Job Counts::::::::::::::::::::::");
			getGraphDao().updateImpatedBackgroundJobCount(requestId);
			logger.info(
					"::::::::::::::::::::END======================================Impacted Background Job Counts::::::::::::::::::::::::");

			if (scopeUI5) {
				logger.info("*******Start of UI5 Graphs******");
				getGraphDao().updateUI5GraphCountApi(requestId);
				logger.info("*******End of UI5 Logic******");
			}
		} catch (Exception e) {

			status = Hana_Profiler_Constant.POC_REQUESTMASTER_CALC_FAIL;
			logger.error(status + " :: " + e);
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new Exception(status);
		}

		status = Hana_Profiler_Constant.POC_REQUESTMASTER_CALC_SUCCESS;
	}

	/**
	 * @author shivani.o.gupta - This method is for calculating the Estimate Counts.
	 * @param requestId
	 * @param requestForm
	 * @param session
	 * @throws SecurityException
	 * @throws NoSuchMethodException
	 */
	public void pocEstimationsProcessing(long requestId, RequestForm requestForm, HttpSession session)
			throws Exception {

		boolean scopeHana = requestForm.getSOH();
		boolean scopeS4 = requestForm.getS4Technical();

		try {
			logger.info("Clearing the Estimates Table ...");
			getAutoHANA().clearEstimatesTable(requestId);
		} catch (Exception e) {
			logger.error("Exception while Clearing Estimates Table " + e.getStackTrace());
		}

		if (scopeHana) {
			logger.info("Calculating estimate counts for HANA ...");
			getProcessedEstimates().updateEstimatesHANA(requestId);

		}
		if (scopeS4) {
			logger.info("Calculating estimate counts for S4 ...");
			getProcessedEstimates().updateEstimatesS4(requestId);
		}
	}


	public void dataTransferAndClearTables(Long requestId, RequestForm requestForm) throws Exception {
		String status = "";

		try {
			logger.info("Transfering Data from Intermediate Tables to Download Tables ...");
			DataTransfer(requestId,requestForm);
		} catch (Exception e) {
			logger.error("Exception while Transfering Data from Intermediate Tables to Download Tables ...");
			status = Hana_Profiler_Constant.POC_DATATRANSFER_FAIL;
			logger.error(status + " :: " + e);
			logger.error(e.getMessage());
			throw new Exception(status);
		}

		try {
			logger.info("Clearing Intermediate Tables ...");
			getAutoHANA().clearAllTables(requestId);
		} catch (Exception e) {
			logger.error("Exception while Clearing Intermaediate Tables ...");
			status = Hana_Profiler_Constant.POC_CLEAR_TABLE_FAIL;
			logger.error(status + " :: " + e);
			throw new Exception(status);
		}
	}
}
