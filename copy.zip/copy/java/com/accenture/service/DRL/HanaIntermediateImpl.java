package com.accenture.service.DRL;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.Iterator;

import org.drools.RuleBase;
import org.drools.RuleBaseFactory;
import org.drools.WorkingMemory;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.compiler.DroolsParserException;
import org.drools.compiler.PackageBuilder;
import org.drools.compiler.PackageBuilderErrors;
import org.drools.event.AgendaEventListener;
import org.drools.runtime.StatelessKnowledgeSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.accenture.client.model.LsmwDrool;
import com.accenture.model.DRL.CodeAssessmentPayLoad;


//@Component("HanaIntermediateImpl")
public class HanaIntermediateImpl {

	private PackageBuilderErrors errors;
	private Iterator<KnowledgeBuilderError> iterator;
	private String message;

/*	@Autowired
	private ApplicationContext applicationContext;*/
	
	
	/*public void processLSMW(Long RequestID,HanaIntermediate HanaIntermediateObj) throws DroolsParserException, IOException {

	      PackageBuilder packageBuilder = new PackageBuilder();
	      String ruleFile = "/rules/rules.drl";
	      InputStream resourceAsStream = getClass().getResourceAsStream(ruleFile);
	      Reader reader = new InputStreamReader(resourceAsStream);
	      packageBuilder.addPackageFromDrl(reader);	    
	      org.drools.rule.Package rulesPackage = packageBuilder.getPackage();
	      if(packageBuilder.hasErrors()) {
	    	  errors = packageBuilder.getErrors();
	    	  iterator = errors.iterator();
	    	  while(iterator.hasNext()) {
	    		  KnowledgeBuilderError kbe = iterator.next();
	    		  message = kbe.getMessage();
	    		  System.out.println("Error :::: " + message );
	    	  }
	      }
	      RuleBase ruleBase = RuleBaseFactory.newRuleBase();
	      ruleBase.addPackage(rulesPackage);
	      WorkingMemory workingMemory = ruleBase.newStatefulSession();
	      
	      //AgendaEventListener agendaEventListener = new TrackingAgendaEventListener();
	     // workingMemory.addEventListener(agendaEventListener);
	      
	      HanaIntermediateObj.setExecRequestId(RequestID);
	      
	      workingMemory.insert(HanaIntermediateObj);
	   
	      workingMemory.fireAllRules();
	      workingMemory.dispose();
		
	}*/

/*	public void processHana(HanaIntermediate hanaIntermediat) throws DroolsParserException, IOException {

			StatelessKnowledgeSession statelessKnowledgeSession = (StatelessKnowledgeSession) applicationContext
				.getBean("hanaInterMedSession");
		statelessKnowledgeSession.execute(hanaIntermediat);
	

	      PackageBuilder packageBuilder = new PackageBuilder();
	      String ruleFile = "/rules/rules.drl";
	      InputStream resourceAsStream = getClass().getResourceAsStream(ruleFile);
	      Reader reader = new InputStreamReader(resourceAsStream);
	      packageBuilder.addPackageFromDrl(reader);	    
	      org.drools.rule.Package rulesPackage = packageBuilder.getPackage();
	      if(packageBuilder.hasErrors()) {
	    	  errors = packageBuilder.getErrors();
	    	  iterator = errors.iterator();
	    	  while(iterator.hasNext()) {
	    		  KnowledgeBuilderError kbe = iterator.next();
	    		  message = kbe.getMessage();
	    		  System.out.println("Error :::: " + message );
	    	  }
	      }
	      RuleBase ruleBase = RuleBaseFactory.newRuleBase();
	      ruleBase.addPackage(rulesPackage);
	      WorkingMemory workingMemory = ruleBase.newStatefulSession();
	      
	      //AgendaEventListener agendaEventListener = new TrackingAgendaEventListener();
	     // workingMemory.addEventListener(agendaEventListener);
	      workingMemory.insert(hanaIntermediat);
	      workingMemory.fireAllRules();
	      workingMemory.dispose();
		
	}
	*/
	
}