package com.accenture.service;

import java.util.List;

import com.accenture.client.model.RequestInventory;

public interface RequestIDValidateService {
	String getCreator(RequestInventory requestInv);
	List<String> getPOCName(RequestInventory requestInv);
	RequestInventory getRequestInv(Long requestID);
}
