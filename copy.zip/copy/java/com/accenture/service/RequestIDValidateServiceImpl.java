package com.accenture.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.accenture.client.dao.RequestInventoryDAO;
import com.accenture.client.model.RequestInventory;

@Service
public class RequestIDValidateServiceImpl implements RequestIDValidateService {
	
	@Autowired
	private RequestInventoryDAO requestInventoryDetails;
	
	public String getCreator(RequestInventory requestInv) {
		String creatorUser = ""; 

		creatorUser = requestInv.getCreatorUser();
		return creatorUser;
	}
	
	public List<String> getPOCName(RequestInventory requestInv) {
		String pocName = ""; 
		String fiatPOCName = ""; 
		
		List<String> pocList = new ArrayList<String>();
		
		pocName = requestInv.getAssigned_poc_emailId();
		fiatPOCName = requestInv.getAssignedFaitEmailId();
		
		pocList.add(pocName);
		pocList.add(fiatPOCName);
		
		return pocList;
	}
	
	public RequestInventory getRequestInv(Long requestID) {
		final RequestInventory requestInv = requestInventoryDetails.getRequestInventory(requestID);
		if(requestInv!=null)
			return requestInv;
		
		return null;
	}
}
