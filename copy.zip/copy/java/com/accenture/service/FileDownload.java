package com.accenture.service;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URLConnection;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.FileCopyUtils;

public class FileDownload {

	final Logger logger = LoggerFactory.getLogger(FileDownload.class);

	public String downloadFile(byte[] fileBytes, HttpServletResponse response, String fileName) throws IOException {
		String errorMessage = null;
		if (fileBytes == null) {
			errorMessage = "Sorry. The file you are looking for does not exist";

			OutputStream outputStream = response.getOutputStream();
			outputStream.write(errorMessage.getBytes());
			outputStream.close();

		}
		String mimeType = URLConnection.guessContentTypeFromName(fileName);

		if (mimeType == null) {
			logger.info("mimetype is not detectable, will take default");
			mimeType = "application/octet-stream";
		}

		logger.info("mimetype : " + mimeType);

		response.setContentType(mimeType);
		response.setHeader("Content-Disposition", String.format("attachment; filename=\"%s\"", fileName));
		//logger.info(String.format("attachment; filename=\"%s\"", fileName));
		if (fileBytes != null) {
			response.setContentLength((int) fileBytes.length);
		} else {
			response.setContentLength(0);
		}

		ServletOutputStream outs = response.getOutputStream();
		FileCopyUtils.copy(fileBytes, response.getOutputStream());
		if (fileBytes != null) {
			outs.write(fileBytes);
		}
		outs.flush();
		outs.close();
		return errorMessage;
	}

}
