package com.accenture.staticinfo.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.accenture.client.dao.RequestFormDAOImpl;
import com.accenture.client.dao.RequestInventoryDAO;
import com.accenture.client.model.RequestFormFile;
import com.accenture.client.model.RequestInventory;
import com.accenture.constant.Hana_Profiler_Constant;
import com.accenture.exceptions.HibernateException;

@Transactional
public class RequestFormFileDAOImpl implements RequestFormFileDAO {

	SessionFactory sessionFactory;
	HibernateTemplate hibernateTemplate;
	RequestInventoryDAO inventoryDaoObj;
	
	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}
	final Logger logger = LoggerFactory.getLogger(RequestFormDAOImpl.class);

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	@Autowired
	public void setInventoryDaoObj(RequestInventoryDAO inventoryDaoObj) {
		this.inventoryDaoObj = inventoryDaoObj;
	}

	public List<RequestFormFile> getRequestFormFile(Long requestID)
	{
		try{
		Session session=sessionFactory.getCurrentSession();
		
		logger.info("create Criteria to get Object for RequestFormFile");
		Criteria criteria = session.createCriteria(RequestFormFile.class);
		criteria.add(Restrictions.eq("requestID", requestID));
		@SuppressWarnings("unchecked")
		List<RequestFormFile> obj = criteria.list();
		return obj;
		}catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}	
	
	public RequestFormFile getRequestFormFile1(Long requestID) throws Exception {
		logger.info("Before getting requestInventory obj");
		RequestInventory requestInventory=inventoryDaoObj.getRequestInventory(requestID);
		long reqId= requestInventory.getRequestID();
		logger.info("After getting Id from requestInventory obj" + reqId);

		RequestFormFile file1Obj= getFormFile1(reqId);
		
		return file1Obj;

		}

	public RequestFormFile getFormFile1(long requestId) {
		try {
			Session session = sessionFactory.getCurrentSession();
			String sql = "select t from REQUEST_FORM_FILE t where t.requestID=:requestId";
			
			Query query = session.createQuery(sql);
			query.setParameter("requestId", requestId);

			RequestFormFile file1Obj = (RequestFormFile) query.uniqueResult();

			return file1Obj;
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	public boolean getFiatFile1Status(Long requestID)
	{
		boolean value=false;
		Session session = null;
		try {
			session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("select downloadStatusFile1 from RequestFormFile requestFormFile where requestFormFile.requestID=:requestID");		
			query.setLong("requestID", requestID);	
			Object obj = query.uniqueResult();
			if(obj != null)
			{
				value = (boolean) obj;
			}
		}
		catch(Exception ex){
			logger.error(ex.getMessage());
			logger.trace(ex.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		return value;
	}
	@Override
	public boolean getFiatFile2Status(long requestID) {
		boolean value=false;
		Session session = null;
		try {
			session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("select downloadStatusFile2 from RequestFormFile requestFormFile where requestFormFile.requestID=:requestID");		
			query.setLong("requestID", requestID);	
			Object obj = query.uniqueResult();
			if(obj != null)
			{
				value = (boolean) obj;
			}
		}
		catch(Exception ex){
			logger.error(ex.getMessage());
			logger.trace(ex.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		return value;

	}
	
	//Set FIAT File1 Download Status to True  when successfully downloaded
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void updateFIATFile1Satus(Long requestID,boolean downloadFiatFile1) {
		try {
			logger.info("inside updating Status for downloaded FIAT file1");
			final Session session = sessionFactory.getCurrentSession();
			final Query query = session.createQuery(
					"update RequestFormFile set downloadStatusFile1 = :downloadStatusFile1 where requestID=:requestID");
			query.setParameter("downloadStatusFile1", downloadFiatFile1);
			query.setParameter("requestID", requestID);
			query.executeUpdate();
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	
	//Set FIAT File2 Download Status to True  when successfully downloaded
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void updateFIATFile2Satus(Long requestID,boolean downloadFiatFile2) {
		try {
			logger.info("inside updating Status for downloaded FIAT file2");
			final Session session = sessionFactory.getCurrentSession();
			final Query query = session.createQuery(
					"update RequestFormFile set downloadStatusFile2 = :downloadStatusFile2 where requestID=:requestID");
			query.setParameter("downloadStatusFile2", downloadFiatFile2);
			query.setParameter("requestID", requestID);
			query.executeUpdate();
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void updateRequestInventorySatus(Long requestID,String status, String pocSubStatus, String comments) {
		try {
	
			final Session session = sessionFactory.getCurrentSession();
			final Query query = session.createQuery(
					"update RequestInventory set pocFiatStatus = :pocFiatStatus, pocSubStatus = :pocSubStatus where requestID=:requestID");
			query.setParameter("pocFiatStatus", status);
			query.setParameter("pocSubStatus", pocSubStatus);
			query.setParameter("requestID", requestID);
			query.executeUpdate();
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	
	public void UpdateRequestFormFile(RequestFormFile requestFormFile) throws HibernateException{
		hibernateTemplate.saveOrUpdate(requestFormFile);
}
	public RequestFormFile getRequestFormFileObj(long requestID) {
		try {

			Session session = sessionFactory.getCurrentSession();
			RequestFormFile form = (RequestFormFile) session.get(RequestFormFile.class, requestID);
			return form;
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
}


