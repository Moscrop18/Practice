package com.accenture.staticinfo.dao;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.taglibs.standard.lang.jstl.BooleanLiteral;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.accenture.client.dao.RequestFormDAO;
import com.accenture.client.dao.RequestInventoryDAO;
import com.accenture.client.model.RequestForm;
import com.accenture.client.model.RequestInventory;
import com.accenture.constant.Hana_Profiler_Constant;
import com.accenture.exceptions.HibernateException;
import com.accenture.poc.model.User;
import com.accenture.statictables.model.ContentFile;
import com.accenture.statictables.model.DeletionTransportRequestFile;
import com.accenture.statictables.model.TransportRequest;
import com.accenture.statictables.model.TransportRequestFile;
 
@Transactional(propagation = Propagation.REQUIRED, readOnly = false)

public class TransportRequestDAOImpl implements TransportRequestDAO {

	final Logger logger = LoggerFactory.getLogger(TransportRequestDAOImpl.class);
	public SessionFactory sessionFactory;
	RequestFormDAO daoobj;
	RequestInventoryDAO inventoryDaoObj;
	private HibernateTemplate hibernateTemplate;

	@Autowired
	public void setInventoryDaoObj(RequestInventoryDAO inventoryDaoObj) {
		this.inventoryDaoObj = inventoryDaoObj;
	}

	public void setDaoobj(RequestFormDAO daoobj) {
		this.daoobj = daoobj;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

	public TransportRequest getTransportRequest(String sourceVersion, String targetVersion) {
		try {
			Session session = sessionFactory.getCurrentSession();
			/*
			 * TransportRequestID transportRequestID=new
			 * TransportRequestID(sourceVersion,targetVersion);
			 * 
			 * TransportRequest
			 * trobj=(TransportRequest)session.get(TransportRequest.class,
			 * transportRequestID);
			 */
			String sql = "select t from TransportRequest t where t.transportRequestPK.sourceVersion=:sourceVersion and t.transportRequestPK.targetVersion=:targetVersion";

			Query query = session.createQuery(sql);
			query.setParameter("sourceVersion", sourceVersion);
			query.setParameter("targetVersion", targetVersion);

			TransportRequest trobj = (TransportRequest) query.uniqueResult();

			return trobj;
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	
	
	public TransportRequestFile getTransportRequestLatest(int latestTRIdValue) {
		try {
			Session session = sessionFactory.getCurrentSession();
		
			String sql = "select t from TransportRequestFile t where t.ID=:Id ";

			Query query = session.createQuery(sql);
			query.setParameter("Id", latestTRIdValue);
			TransportRequestFile trobj = (TransportRequestFile) query.uniqueResult();

			return trobj;
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	
	public ContentFile getContentFile(Long REQUEST_ID) {
		try {
			Session session = sessionFactory.getCurrentSession();
		
			String sql = "select t from ContentFile t where t.REQUEST_ID=:REQUEST_ID ";

			Query query = session.createQuery(sql);
			query.setParameter("REQUEST_ID", REQUEST_ID);
			ContentFile trobj = (ContentFile) query.uniqueResult();

			return trobj;
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	
	

	
	
	public Integer getTransportRequestMaxID() {
		try {
			Session session = sessionFactory.getCurrentSession();
			String sql = "select max(ID) from TransportRequestFile";
			Integer maxCount;
			Query query = session.createQuery(sql);
			if((Integer) query.uniqueResult()!= null)
			{
				maxCount =  (Integer) query.uniqueResult();
			}
			else
			{
				maxCount=0;	
			}
			return maxCount;
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	public Integer getDeletionTransportRequestMaxID() {
		try {
			Session session = sessionFactory.getCurrentSession();
			String sql = "select max(ID) from DeletionTransportRequestFile";
			Integer maxCount;
			Query query = session.createQuery(sql);
			if((Integer) query.uniqueResult()!= null)
			{
				maxCount =  (Integer) query.uniqueResult();
			}
			else
			{
				maxCount=0;	
			}
			return maxCount;
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	
	public Map<String, String> getAllTransportRequestListPoc() {
		Map<String, String> trMap = new LinkedHashMap<String, String>();
		try {
			//String sql = "";
			//final Session session = sessionFactory.getCurrentSession();
			//sql="Select trFileName from TransportRequestFile";
			//Query query = session.createQuery(sql);
			//List<String> versionList = query.list();
			//return versionList;
			
			List<TransportRequestFile> trList =  (List<TransportRequestFile>) hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {
					ProjectionList projection = Projections.projectionList();
					projection.add(Projections.property("trFileName"), "trFileName");
					projection.add(Projections.property("trVersion"), "trVersion");
					final Criteria criteria = session.createCriteria(TransportRequestFile.class);
					criteria.setProjection(projection);
					criteria.addOrder(Order.desc("updatedDate"));
					criteria.setMaxResults(1);// top 1 tr versions will be shown on the UI.

					criteria.setResultTransformer(Transformers.aliasToBean(TransportRequestFile.class));
					return criteria.list();
				}
			});
			if(trList!=null && trList.size()>0) {
				for(TransportRequestFile tr: trList) {
					trMap.put(tr.getTrVersion(), tr.getTrFileName());
				}
			}
			return trMap;
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}

	}
	
	public Map<String, String> getAllDeletionTransportRequestListPoc() {
		Map<String, String> trMap = new LinkedHashMap<String, String>();
		try {
			//String sql = "";
			//final Session session = sessionFactory.getCurrentSession();
			//sql="Select trFileName from TransportRequestFile";
			//Query query = session.createQuery(sql);
			//List<String> versionList = query.list();
			//return versionList;
			
			List<DeletionTransportRequestFile> trList =  (List<DeletionTransportRequestFile>) hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {
					ProjectionList projection = Projections.projectionList();
					projection.add(Projections.property("trFileName"), "trFileName");
					projection.add(Projections.property("trVersion"), "trVersion");
					final Criteria criteria = session.createCriteria(DeletionTransportRequestFile.class);
					criteria.setProjection(projection);
					criteria.addOrder(Order.desc("updatedDate"));
					criteria.setMaxResults(1);// top 1 tr versions will be shown on the UI.
					
					criteria.setResultTransformer(Transformers.aliasToBean(DeletionTransportRequestFile.class));
					return criteria.list();
				}
			});
			if(trList!=null && trList.size()>0) {
				for(DeletionTransportRequestFile tr: trList) {
					trMap.put(tr.getTrVersion(), tr.getTrFileName());
				}
			}
			return trMap;
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}

	}
	
	public String getTrAttachedStatus(long requestID) {
		try {
			Session session = sessionFactory.getCurrentSession();
			String sql = "Select trAttachementName from RequestInventory where requestID ="+requestID;
			Query query = session.createQuery(sql);
			String name=(String) query.uniqueResult();
			if(name != null && !name.equalsIgnoreCase(""))
			{
				return name;
			}
			else
			{
				return "Empty";	
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}

	}
	public String getDelTrAttachedStatus(long requestID) {
		try {
			Session session = sessionFactory.getCurrentSession();
			String sql = "Select deletionTRAttachementName from RequestInventory where requestID ="+requestID;
			Query query = session.createQuery(sql);
			String name=(String) query.uniqueResult();
			if(name != null && !name.equalsIgnoreCase(""))
			{
				return name;
			}
			else
			{
				return "Empty";	
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}

	}
	
	public String getContentAttachedStatus(long requestID) {
		try {
			Session session = sessionFactory.getCurrentSession();
			String sql = "Select contentFileName from ContentFile where REQUEST_ID ="+requestID;
			Query query = session.createQuery(sql);
			String name=(String) query.uniqueResult();
			if(name != null && !name.equalsIgnoreCase(""))
			{
				return name;
			}
			else
			{
				return "Empty";	
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}

	}
	
	public Boolean getTrExistingStatus(String fileVersion) {
		try {
			Session session = sessionFactory.getCurrentSession();
			String sql = "Select Count(*) from TransportRequestFile where trFileName in (:fileVersion)";
			Query query = session.createQuery(sql);
			query.setParameter("fileVersion",fileVersion);

			Long count=   (Long) query.uniqueResult();
			if(count >=1L)
			{
				return true;
			}
			else
			{
				return false;	
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}

	}
	public Boolean getDeletionTrExistingStatus(String fileVersion) {
		try {
			Session session = sessionFactory.getCurrentSession();
			String sql = "Select Count(*) from DeletionTransportRequestFile where trFileName in (:fileVersion)";
			Query query = session.createQuery(sql);
			query.setParameter("fileVersion",fileVersion);

			Long count=   (Long) query.uniqueResult();
			if(count >=1L)
			{
				return true;
			}
			else
			{
				return false;	
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}

	}
	
	
	


	@SuppressWarnings("unchecked")
	public List<TransportRequest> getAllTransportRequest(final String toolName) {
		try {
			final Session session = sessionFactory.getCurrentSession();
			final Criteria criteria = session.createCriteria(TransportRequest.class);
			criteria.add(Restrictions.eq("toolName", toolName));
			return criteria.list();
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}

	}
	

	public void saveContentFile(ContentFile contentFile) {
		try {
			Session session = sessionFactory.getCurrentSession();
			java.util.Date dt = new java.util.Date();
			java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String currentTime = sdf.format(dt);
			contentFile.setUpdatedDate(currentTime);
			session.saveOrUpdate(contentFile);
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	
	public void saveTRFile(TransportRequestFile transportRequestFile) {
		try {
			Session session = sessionFactory.getCurrentSession();
			java.util.Date dt = new java.util.Date();
			java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String currentTime = sdf.format(dt);
			transportRequestFile.setUpdatedDate(currentTime);
			session.saveOrUpdate(transportRequestFile);
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	public void saveDelTRFile(DeletionTransportRequestFile transportRequestFile) {
		try {
			Session session = sessionFactory.getCurrentSession();
			java.util.Date dt = new java.util.Date();
			java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String currentTime = sdf.format(dt);
			transportRequestFile.setUpdatedDate(currentTime);
			session.saveOrUpdate(transportRequestFile);
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	public void save(TransportRequest transportRequest) {
		try {
			Session session = sessionFactory.getCurrentSession();
			session.saveOrUpdate(transportRequest);
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	public void deleteTrFile(String[] trFileVersion) {
		try {
			final Session session = sessionFactory.getCurrentSession();
			String[] fileVersion = null;
			Query query = session.createQuery(
					"delete TransportRequest where transportRequestPK.sourceVersion = :sourceVersion and transportRequestPK.targetVersion = :targetVersion");
			for (String file : trFileVersion) {
				fileVersion = file.split(Hana_Profiler_Constant.DELETE_TR_FILE_VALUE_SEPARATOR);
				query.setParameter("sourceVersion", fileVersion[0]);
				query.setParameter("targetVersion", fileVersion[1]);
				query.executeUpdate();
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}

	}

	@SuppressWarnings("unchecked")
	public List<String> getVersionList(String versionCalss, final String toolName) {
		try {
			//This code is not used and hence it is not tested
			String sql = "";
			final Session session = sessionFactory.getCurrentSession();
			if(toolName.equalsIgnoreCase("S4Hana")){
				sql="Select distinct(transportRequestPK.:versionCalss) from TransportRequest";
			}else{
				sql="Select distinct(transportRequestPK.:versionCalss) from TransportRequest where toolName=:toolName";
			}
			Query query = session.createQuery(sql);
			query.setParameter("versionCalss",versionCalss);
			query.setParameter("toolName",toolName);

			List<String> versionList = query.list();
			return versionList;

		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}

	}

	public TransportRequest getTransportRequestobj(Long requestID) throws Exception {
		logger.info("Before getting requestForm obj");
		RequestForm requestForm = daoobj.getRequestObj(requestID);
		logger.info("After getting requestForm obj");
		String sourceVersion = requestForm.getSourceVersion();
		String targetVersion = requestForm.getTargetVersion();
		logger.info("After getting Version from requestForm obj");
		TransportRequest trobj = getTransportRequest(sourceVersion, targetVersion);

		return trobj;

	}
	
	
	public ContentFile getContentFile(long requestId) {
		try {
			Session session = sessionFactory.getCurrentSession();
			/*
			 * TransportRequestID transportRequestID=new
			 * TransportRequestID(sourceVersion,targetVersion);
			 * 
			 * TransportRequest
			 * trobj=(TransportRequest)session.get(TransportRequest.class,
			 * transportRequestID);
			 */
			//String sql = "select t from TransportRequest t where t.transportRequestPK.sourceVersion=:sourceVersion and t.transportRequestPK.targetVersion=:targetVersion";
			String sql = "select t from ContentFile t where t.REQUEST_ID=:requestId";
			
			Query query = session.createQuery(sql);
			query.setParameter("requestId", requestId);

			ContentFile contentObj = (ContentFile) query.uniqueResult();

			return contentObj;
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	public TransportRequestFile getTRFile(String trVersion) {
		try {
			Session session = sessionFactory.getCurrentSession();
			/*
			 * TransportRequestID transportRequestID=new
			 * TransportRequestID(sourceVersion,targetVersion);
			 * 
			 * TransportRequest
			 * trobj=(TransportRequest)session.get(TransportRequest.class,
			 * transportRequestID);
			 */
			//String sql = "select t from TransportRequest t where t.transportRequestPK.sourceVersion=:sourceVersion and t.transportRequestPK.targetVersion=:targetVersion";
			String sql = "select t from TransportRequestFile t where t.trVersion=:trVersion";
			
			Query query = session.createQuery(sql);
			query.setParameter("trVersion", trVersion);

			TransportRequestFile trobj = (TransportRequestFile) query.uniqueResult();

			return trobj;
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	public DeletionTransportRequestFile getDelTRFile(String trVersion) {
		try {
			Session session = sessionFactory.getCurrentSession();
			/*
			 * TransportRequestID transportRequestID=new
			 * TransportRequestID(sourceVersion,targetVersion);
			 * 
			 * TransportRequest
			 * trobj=(TransportRequest)session.get(TransportRequest.class,
			 * transportRequestID);
			 */
			//String sql = "select t from TransportRequest t where t.transportRequestPK.sourceVersion=:sourceVersion and t.transportRequestPK.targetVersion=:targetVersion";
			String sql = "select t from DeletionTransportRequestFile t where t.trVersion=:trVersion";
			
			Query query = session.createQuery(sql);
			query.setParameter("trVersion", trVersion);

			DeletionTransportRequestFile trobj = (DeletionTransportRequestFile) query.uniqueResult();

			return trobj;
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	public TransportRequestFile getNewTRobj(Long requestID) throws Exception {

		logger.info("Before getting requestInventory obj");
		RequestForm requestForm = daoobj.getRequestObj(requestID);
		
		RequestInventory requestInventory=inventoryDaoObj.getRequestInventory(requestID);
		logger.info("After getting requestInventory obj");

		String trVersion=requestInventory.getTrAttachementName();
		logger.info("After getting Version from requestInventory obj");

		TransportRequestFile trFileObj=getTRFile(trVersion);
		
		return trFileObj;

	}
	
	public DeletionTransportRequestFile getNewDelTRobj(Long requestID) throws Exception {

		logger.info("Before getting requestInventory obj");
		RequestForm requestForm = daoobj.getRequestObj(requestID);
		
		RequestInventory requestInventory=inventoryDaoObj.getRequestInventory(requestID);
		logger.info("After getting requestInventory obj");

		String trVersion=requestInventory.getDeletionTRAttachementName();
		logger.info("After getting Version from requestInventory obj");

		DeletionTransportRequestFile trFileObj=getDelTRFile(trVersion);
		
		return trFileObj;

	}
	
	
	public ContentFile getContentFileobj(Long requestID) throws Exception {
	logger.info("Before getting requestInventory obj");
	RequestInventory requestInventory=inventoryDaoObj.getRequestInventory(requestID);
	long reqId= requestInventory.getRequestID();
	//String trVersion=requestInventory.getTrAttachementName();
	logger.info("After getting Id from requestInventory obj" + reqId);

	ContentFile contentObj= getContentFile(reqId);
	//TransportRequestFile trFileObj=getTRFile(trVersion);
	
	return contentObj;

	}

	
	

}
