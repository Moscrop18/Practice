package com.accenture.staticinfo.dao;

import java.util.*;
import com.accenture.statictables.model.*;

public interface TransportRequestDAO {

	
public Map<String, String> getAllTransportRequestListPoc();

public String getTrAttachedStatus(long requestID);

public String getContentAttachedStatus(long requestID);

public Boolean getTrExistingStatus(String fileVersion);
	
public List<TransportRequest> getAllTransportRequest(final String toolName);

public void  save(TransportRequest transportRequest);

public void  saveTRFile(TransportRequestFile transportRequestFile);

public void  saveContentFile(ContentFile contentFile);

public void deleteTrFile(String[] trFileVersion);

public TransportRequest getTransportRequest(String sourceVersion,String targetVersion);

public Integer getTransportRequestMaxID();

public List<String> getVersionList(String versionCalss, final String toolName);

TransportRequest getTransportRequestobj(Long requestID) throws Exception;

TransportRequestFile getTransportRequestLatest(int latestTRIdValue) throws Exception;

public ContentFile getContentFile(Long REQUEST_ID);

public void saveDelTRFile(DeletionTransportRequestFile transportRequestFile);
 
TransportRequestFile getNewTRobj(Long requestID) throws Exception;

public ContentFile getContentFileobj(Long requestID) throws Exception;

public Boolean getDeletionTrExistingStatus(String fileVersion);

public String getDelTrAttachedStatus(long requestID);

public Map<String, String> getAllDeletionTransportRequestListPoc();

public Integer getDeletionTransportRequestMaxID();

public DeletionTransportRequestFile getNewDelTRobj(Long requestID) throws Exception;

public DeletionTransportRequestFile getDelTRFile(String trVersion);





}
