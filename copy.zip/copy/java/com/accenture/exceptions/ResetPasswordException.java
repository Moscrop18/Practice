package com.accenture.exceptions;

public class ResetPasswordException extends RuntimeException{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7832132094319901047L;
	private String errMsg;

	

	public String getErrMsg() {
		return errMsg;
	}

	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}

	
	public ResetPasswordException()
	{
		
	}
	
	public ResetPasswordException(String errMsg)
	{
		super(errMsg);
		this.errMsg = errMsg;
	}
	
	
}
