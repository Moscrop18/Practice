package com.accenture.exceptions;

public class SignUpException extends RuntimeException{

	/**
	 * 
	 */
	
	private static final long serialVersionUID = 581893856235651890L;
	private int errCode;
	private String errMsg;

	public int getErrCode() {
		return errCode;
	}

	public void setErrCode(int errCode) {
		this.errCode = errCode;
	}

	public String getErrMsg() {
		return errMsg;
	}

	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}

	
	public SignUpException(int errCode)
	{
		super(errCode+"");
		this.errCode = errCode;
	}
	
	public SignUpException(int errCode, String errMsg) {
		this.errCode = errCode;
		this.errMsg = errMsg;
	}
}
