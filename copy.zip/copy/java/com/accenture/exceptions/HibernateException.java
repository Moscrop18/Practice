package com.accenture.exceptions;

public class HibernateException extends RuntimeException{
	private static final long serialVersionUID = 581893856235651890L;
	private String errMsg;

	

	public String getErrMsg() {
		return errMsg;
	}

	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}

	
	public HibernateException(String errMsg)
	{
		super(errMsg);
		this.errMsg = errMsg;
	}
	
	
}
