package com.accenture.Scripts.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

/**
 * @author himani.malhotra
 *
 */

@Entity
@Table(name="Impacted_Scripts_Download")
public class ImpactedScripts_Download {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ID")
	private int id;
	
	@Column(name="OBJ_TYPE")
	private String objType;
	
	@Column(name="PROGRAM")
	private String objName;
	
	@Column(name="OBJ_NAME_TYPE")
	private String objNameType;
	
	@Column(name="Impacted_SAP_Scripts")
	private String actStatus;

	@Column(name="REMEDIATION_CATEGORY")
	private String remidiCategory;
	
	@Column(name="Existing_Errors")
	private String existingErrors;
	
	@Column(name="DB_Impact")
	private String dbImpact;
	
	@Column(name="S4_Simplification")
	private String s4Simplification;

	@Column(name="OPERCD")
	private String opCode; 
	
	@Column(name = "EXTERNAL_NAMESPACE")
	private String externalNamespace ;

	public String getExternalNamespace() {
		return externalNamespace;
	}

	public void setExternalNamespace(String externalNamespace) {
		this.externalNamespace = externalNamespace;
	}

	@Index(name="Index_Request_id")
	@Column(name="REQUEST_ID")
		private long requestId;
		

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getObjType() {
			return objType;
		}

		public void setObjType(String objType) {
			this.objType = objType;
		}
		
		public String getObjName() {
			return objName;
		}

		public void setObjName(String objName) {
			this.objName = objName;
		}

		public String getActStatus() {
			return actStatus;
		}

		public void setActStatus(String actStatus) {
			this.actStatus = actStatus;
		}

		public String getRemidiCategory() {
			return remidiCategory;
		}

		public void setRemidiCategory(String remidiCategory) {
			this.remidiCategory = remidiCategory;
		}

		public String getExistingErrors() {
			return existingErrors;
		}

		public void setExistingErrors(String existingErrors) {
			this.existingErrors = existingErrors;
		}

		public String getDbImpact() {
			return dbImpact;
		}

		public void setDbImpact(String dbImpact) {
			this.dbImpact = dbImpact;
		}

		public String getS4Simplification() {
			return s4Simplification;
		}

		public void setS4Simplification(String s4Simplification) {
			this.s4Simplification = s4Simplification;
		}

		public String getObjNameType() {
			return objNameType;
		}

		public void setObjNameType(String objNameType) {
			this.objNameType = objNameType;
		}

		public String getOpCode() {
			return opCode;
		}

		public void setOpCode(String opCode) {
			this.opCode = opCode;
		}

		public long getRequestId() {
			return requestId;
		}

		public void setRequestId(long requestId) {
			this.requestId = requestId;
		}
}

