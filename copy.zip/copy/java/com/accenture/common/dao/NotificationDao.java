package com.accenture.common.dao;

import java.util.List;

import com.accenture.model.Notification;

public interface NotificationDao {
	public List<Notification> getUserNotifications(String user);
	public Boolean markNotificationAsRead(String user, Integer notificationId);
	public Boolean markUserAllNotificationsAsRead(String user);
}
