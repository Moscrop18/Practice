package com.accenture.common.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.transaction.annotation.Transactional;

import com.accenture.constant.Hana_Profiler_Constant;
import com.accenture.exceptions.HibernateException;
import com.accenture.model.Notification;

@Transactional
public class NotificationDaoImpl implements NotificationDao {

	final Logger logger = LoggerFactory.getLogger(NotificationDaoImpl.class);
	SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {

		this.sessionFactory = sessionFactory;
	}

	@Override
	public List<Notification> getUserNotifications(String user) {
		// TODO Auto-generated method stub
		try {
			Session session = sessionFactory.getCurrentSession();
			String hql = "select u from Notification u where u.user=(:user) and u.readStatus=(:readStatus)";

			Query query = session.createQuery(hql);
			query.setParameter("user", user);
			query.setParameter("readStatus", false);
			return query.list();

		} catch (UsernameNotFoundException e) {
			throw e;
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	@Override
	public Boolean markNotificationAsRead(String user, Integer notificationId) {
		// TODO Auto-generated method stub

		try {
			Session session = sessionFactory.getCurrentSession();
			String hql = "update Notification set readStatus=(:readStatus) where id = (:id) ";

			Query query = session.createQuery(hql);
			query.setParameter("readStatus", true);
			query.setParameter("id", notificationId);
			return (query.executeUpdate() > 0) ? true : false;

		} catch (UsernameNotFoundException e) {
			throw e;
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	@Override
	public Boolean markUserAllNotificationsAsRead(String user) {
		// TODO Auto-generated method stub
		try {
			Session session = sessionFactory.getCurrentSession();
			String hql = "update Notification set readStatus=(:readStatus) where user = (:user) ";

			Query query = session.createQuery(hql);
			query.setParameter("readStatus", true);
			query.setParameter("user", user);
			return (query.executeUpdate() > 0) ? true : false;

		} catch (UsernameNotFoundException e) {
			throw e;
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

}
