package com.accenture.fileprocessing;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

class HelperCheckFileList {

	String filePath = "";
	final Logger logger = LoggerFactory.getLogger(HelperCheckFileList.class);
	public HelperCheckFileList(String filePath)
	{
		super();
		this.filePath = filePath;
	}

	Map<String,String> checkIfReady(ArrayList<String> checkList)
	{
		Map<String,String> filesNameWithStatus= new HashMap<String, String>();
		Map<String,String> validFilesName= new HashMap<String, String>();
		File testFolder = new File(filePath);
		File flist[] = testFolder.listFiles();

		for (int i = 0; i < checkList.size(); i++) {
			int fileCount = 0;
			logger.info("Checking for file...  ");
			String checkListName = checkList.get(i);
			for (int j = 0; j < flist.length; j++) 
			{
				String fileName = flist[j].getName();
				
				if(!validFilesName.isEmpty() && validFilesName.containsKey(fileName.toUpperCase()))
				{
					if(!validFilesName.get(fileName.toUpperCase()).equalsIgnoreCase("VALID"))
					{
						validFilesName.put(fileName.toUpperCase(), "INVALID");
					}
				}
				else
				{
					validFilesName.put(fileName.toUpperCase(), "INVALID");
				}
				
				String extension = fileName.substring(fileName.lastIndexOf("."));
				if (fileName.toLowerCase().trim().startsWith(checkListName.toLowerCase().trim())
						&& !(".zip").equalsIgnoreCase(extension)) 
				{
					fileCount = fileCount + 1;
					validFilesName.put(fileName.toUpperCase(), "VALID");
				}
			}
			if (fileCount != 0)
			{
				filesNameWithStatus.put(checkListName, "VALID");
				logger.info(" :  " + fileCount + " instance of file found");
			}
			else 
			{
				logger.info("No instance of file found");
				filesNameWithStatus.put(checkListName, "No instance of file found");
			}
		}
		deleteInvalidFiles(validFilesName);
		return filesNameWithStatus;
	}
	private void deleteInvalidFiles(Map<String,String> validFilesName)
	{
		try 
		{
			File directory = new File(filePath);
			File flist[] = directory.listFiles();
			for (int j = 0; j < flist.length; j++) 
			{
				String fileName = flist[j].getName();
				if("INVALID".equalsIgnoreCase(validFilesName.get(fileName.toUpperCase())))
				{
					FileUtils.forceDelete(flist[j]);
				}
			}
		}
		catch (Exception e) 
		{
			logger.error(e.getMessage());
		}
	}
}
