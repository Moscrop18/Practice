package com.accenture.fileprocessing;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.accenture.bw.dao.BwCleanUpDAO;
import com.accenture.client.model.RequestForm;
import com.accenture.constant.Hana_Profiler_Constant;
import com.accenture.constant.ST03HanaConstant;
import com.accenture.exceptions.ST03DataAnalysisException;
import com.accenture.fileprocesing.dao.ST03HanaDAOImpl;

import com.accenture.reader.xlsx.St03ReaderXlsx;
import com.accenture.rfp.models.TADIRInventory;
import com.accenture.utility.FileUtility;
import com.accenture.utility.HANAUtility;

public class ST03DataAnalysis {

	private ST03HanaDAOImpl st03Hanadao;

	private St03ReaderXlsx st03ReaderXlsx;
	private PopulateHanaTables populateHanaTables;
	@Autowired
	private BwCleanUpDAO bwCleanDao;


	public void setPopulateHanaTables(PopulateHanaTables populateHanaTables) {
		this.populateHanaTables = populateHanaTables;
	}

	public void setSt03ReaderXlsx(St03ReaderXlsx st03ReaderXlsx) {
		this.st03ReaderXlsx = st03ReaderXlsx;
	}

	public void setSt03Hanadao(ST03HanaDAOImpl st03Hanadao) {
		this.st03Hanadao = st03Hanadao;
	}

	final Logger logger = LoggerFactory.getLogger(ST03DataAnalysis.class);
	private String rootFolderPath;

	public ST03DataAnalysis(String rootFolderPath) {
		super();
		this.rootFolderPath = rootFolderPath;
	}

	public ST03DataAnalysis() {

	}

	public String getRootFolderPath() {
		return rootFolderPath;
	}

	public void setRootFolderPath(String rootFolderPath) {
		this.rootFolderPath = rootFolderPath;
	}
	
	public String getFilePath()
	{
		final File rootFolderFileList[] = new File(this.getRootFolderPath()).listFiles();
		String filePath = "";
		try {
			for (File file : rootFolderFileList) {
				logger.info("Analysing file : " + file);
				String fileName = file.getName().toLowerCase();
				filePath = file.getCanonicalPath();
			}
		} catch (IOException e) {
			logger.error(e.getMessage());
		}
		
		return filePath;
	}
	public TADIRInventory readFile(final String filePath, final long requestId, String toolName,
			HttpSession session,  RequestForm requestForm) throws Exception
	{
		return st03ReaderXlsx.readTadirFile(filePath, requestId, toolName, session,requestForm);

	}
	
	public boolean readInputAadtFiles(final long requestId,String toolName,HttpSession session, RequestForm requestForm) {
		boolean st03Status = false;
		try {
			final File rootFolderFileList[] = new File(this.getRootFolderPath()).listFiles();

			long startTime = 0L;
			long endTime = 0L;
			long totalTime = 0L;
			String filePath = null;
			String zaicatDetectionFilePath=null;
			startTime=System.currentTimeMillis();
			HANAUtility.changeRequestProgressValue(requestId,3,"Files under processing");
			if(requestForm.getBwUsage()){
				bwCleanDao.getDateFormatForBw(session, requestId);
			}
			
			List<String> fileNameList = Arrays.asList("rszwtemplate.xlsx","rszwbtmpdata.xlsx");
			if(requestForm.getBwUsage()){
				for (File file : rootFolderFileList) {
					String fileName = file.getName().toLowerCase();
					filePath = file.getCanonicalPath();
					FileUtility.checkFileSize(file);
					if(fileNameList.contains(fileName)){
						logger.info("Reading  file="+fileName+"::::::::::::::::::::::Scope BW");
						st03ReaderXlsx.AadtReadFiles(filePath, requestId,toolName,session);		
						logger.info("Done Reading  file="+fileName+"::::::::::::::::::::::::Scope BW");

					}
				}
			}

			for (File file : rootFolderFileList) {
				logger.info("Analysing file : " + file);
				String fileName = file.getName().toLowerCase();
				filePath = file.getCanonicalPath();
				FileUtility.checkFileSize(file);
				if (fileName.contains("ZAICAT_DETECTION".toLowerCase())) {
					zaicatDetectionFilePath=filePath;
				}
					logger.info("filepath :"+filePath);
					logger.info("Reading  file="+fileName+":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
					st03ReaderXlsx.AadtReadFiles(filePath, requestId,toolName,session);		
					logger.info("Done Reading  file="+fileName+":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
								
			}
				
				if (zaicatDetectionFilePath!=null) {
					final File file = new File(zaicatDetectionFilePath);
					String fileName = file.getName().toLowerCase();
					logger.info("Reading  file="+ fileName +":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
					st03ReaderXlsx.readZaicatDetectionFile(filePath, requestId, toolName, session, requestForm);
					logger.info("Done Reading  file="+fileName+":::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
				}				
			
			HANAUtility.changeRequestProgressValue(requestId,20,"All input files have been read");
			
			logger.info("All input files have been read ......");

			endTime = System.currentTimeMillis();
			totalTime = endTime - startTime;
			logger.info("Total Time in reading input files =" + totalTime);
			st03Status = true;

		} catch (IOException e) {
			logger.error(e.getMessage());
		} catch (Exception e) {
			st03Status = false;
			logger.error("Exception in readInputAadtFiles :: " , e);
		}
		return st03Status;
		
	}

	public boolean analyseST03Data(final long requestId,String toolName,HttpSession session) {
		boolean st03Status = false;
		try {
			//final File rootFolderFileList[] = new File(this.getRootFolderPath()).listFiles();

			long startTime = 0L;
			long endTime = 0L;
			long totalTime = 0L;
			
			//setting operation data for mapping
			st03ReaderXlsx.addOperationData();
			
			HANAUtility.changeRequestProgressValue(requestId,20,"All files have been processed");
			long start=System.currentTimeMillis();
			logger.info("Fire Rules Start Time::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::" + start);
			st03ReaderXlsx.fireRules();
			long end=System.currentTimeMillis();
			logger.info("Fire rules end time::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::" + end);
			

			logger.info("Start executing queries to populate st03_object table ......");

			logger.info("requestID" + requestId);

			String clientNameSpace_Name=st03Hanadao.getClientNameSpace_Name(requestId);
			if("".equals(clientNameSpace_Name)){
				//COMMENTED FOR DELETION OF ST03=== TEMPORARY CHANGE
			//st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.SQL1_2_3);
			}
			else{
				String multiNameSpace[]=clientNameSpace_Name.split(",");
				String multipleNameSpaces="";
				for(int i=0;i<multiNameSpace.length;i++){
					if("".equals(multipleNameSpaces)){
						multipleNameSpaces="or  st.prog like '"+multiNameSpace[i].trim()+"%'";
					}
					else{
						multipleNameSpaces= multipleNameSpaces +  " or  st.prog like '"+multiNameSpace[i].trim()+"%'";
					}
				}
				
				
				//String SQL1_2_3= "insert into ST03CustomObjects(tCode,dialogSteps,requestID) select st.prog,CAST(sum(st.dialog) as string),st.requestID from SunBaseData st where st.requestID=:requestID and (st.prog  like 'Y%' or  st.prog  like  'Z%' "+multipleNameSpaces+" ) group by st.prog,st.requestID";

				//st03Hanadao.insertORUpdate(requestId,SQL1_2_3);
			}	
			/*st03Hanadao.delete(requestId, ST03HanaConstant.SQL_12_13_14);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql4);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql5);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql6);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql7);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql8);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql9);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql10);

			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql46_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql47_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql48_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql49_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql50_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql51_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql52_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql53_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql54_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql55_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql56_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql57_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql58_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql59_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql60_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql61_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql62_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql63_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql64_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql65_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql66_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql67_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql68_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql69_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql70_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql71_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql72_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql73_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql74_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql75_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql76_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql77_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql78_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql79_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql80_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql81_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql82_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql83_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql84_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql85_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql86_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql87_hql);
			// st03Hanadao.insertORUpdateSQL(requestId, ST03HanaConstant.sql88);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql89_hql);
			// st03Hanadao.insertORUpdateSQL(requestId, ST03HanaConstant.sql90);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql91_hql);
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql92_hql);
*/
			long sql15startTime = System.currentTimeMillis();
			//updateIncludeExtractorStatus(requestId);
			// st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql15);
			logger.info("time to execute sql 15 =" + (System.currentTimeMillis() - sql15startTime));

			logger.info("All Queries executed ......");

			endTime = System.currentTimeMillis();
			totalTime = endTime - startTime;
			logger.info("Total Time in populating ST03_CUSTOM_OBJECTS through ST03 Queries=" + totalTime);
			st03Status = true;

		} 
		catch (ST03DataAnalysisException e) {
			throw e;
		}
		catch (Exception e) {
			st03Status = false;
			logger.error("Exception in ST03 Analysis :: " , e);
		}
		return st03Status;
	}

/*	private void updateIncludeExtractorStatus(final long requestId) {
		List<String> progNameList = st03Hanadao.getST03CustomObjectProgNameList(requestId);
		if (CollectionUtils.isNotEmpty(progNameList)) {
			List<IncludeExtractor> includeExtractorList = st03Hanadao.getIncludeExtractorList(requestId, progNameList);
			for (IncludeExtractor includeExtractor : includeExtractorList) {
				includeExtractor.setStatus("YES");
			}

			populateHanaTables.populateDataList(includeExtractorList);
		}
	}*/
}
