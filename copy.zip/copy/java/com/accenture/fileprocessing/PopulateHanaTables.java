package com.accenture.fileprocessing;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.constant.Hana_Profiler_Constant;

import com.accenture.exceptions.HibernateException;


public class PopulateHanaTables {

	
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	final Logger logger = LoggerFactory.getLogger(PopulateHanaTables.class);

	/*public void setSt03Hanadao(ST03HanaDAOImpl st03Hanadao) {
		this.st03Hanadao = st03Hanadao;
	}

	public void populateST03CustomDialog(final long requestId) {

		st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.SQL17_1);

	}

	public void populateST03Custom(final long requestId) {
		st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.SQL16_1);
	}
*/
	
	
	public Map<String, String> getOperationValuesdb()
	{
		Session session = null;
		final Map<String,String> resultMap = new HashMap<String,String>();
		session = sessionFactory.openSession();
		String hql = "select ID,ACT_STATUS,ISSUE_SUB_CATEGORY,CRTICAL,high_lvl_desc,OPERAION,OPERAION_CODE,SUB_CATEGORY,COMPLEXITY,Automation_Status from OPERATION_DATA";
		Query query = session.createSQLQuery(hql);
		List<Object[]> resultList = query.list();
		
		if(CollectionUtils.isNotEmpty(resultList))
		{	
			for(Object[] object : resultList)
			{
						
				         Integer ID=(Integer) (object[0]);
						 String ACT_STATUS=(String) object[1];
						 String secondSubCategory=(String) object[2];
						 String CRTICAL=(String) object[3];
						 String high_lvl_desc=(String) object[4];
						 String OPERAION=(String) object[5];
						 String OPERAION_CODE=(String) object[6];
						 String SUB_CATEGORY=(String) object[7];
						 String COMPLEXITY=(String) object[8];
						 String Automation_Status=(String) object[9];
						 String Data=ID+"|"+ACT_STATUS+"|"+secondSubCategory+"|"+CRTICAL+"|"+high_lvl_desc+"|"+OPERAION+"|"+OPERAION_CODE+"|"+SUB_CATEGORY+"|"+COMPLEXITY+"|"+Automation_Status;						 
						 resultMap.put(OPERAION_CODE,Data);
						
			}
		}
		session.close();
		return resultMap;
	}
	
	
	public <T> void populateDataList(final List<T> list) {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			final int size = list.size();
			final int batchSize = Hana_Profiler_Constant.JDBC_BATCH_SIZE;
			for (int i = 0; i < size; i++) {
				session.saveOrUpdate(list.get(i));
				if (i % batchSize == 0) {
					session.flush();
					session.clear();
				}
			}
			session.flush();
			session.clear();

		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

	public <T> void deleteList(final List<T> list) {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			final int size = list.size();
			final int batchSize = Hana_Profiler_Constant.JDBC_BATCH_SIZE;
			for (int i = 0; i < size; i++) {
				session.delete(list.get(i));
				if (i % batchSize == 0) {
					session.flush();
					session.clear();
				}
			}
			session.flush();
			session.clear();

		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if (session != null) {
				session.close();
			}
		}

	}	

/*	public void deleteInvalidCharFromIncludeExt(){
		Session session = null;
		try{
			session = sessionFactory.openSession();		
			Query query = session.createQuery("DELETE FROM IncludeExtractor  WHERE includes LIKE :INCLUDE_CHAR OR includes LIKE :INCLUDE_TXT OR progName LIKE:PROG_CHAR");
			query.setParameter("INCLUDE_CHAR", "----"+"%");
			query.setParameter("INCLUDE_TXT", "ACAT Extractor include with"+"%");
			query.setParameter("PROG_CHAR", "----"+"%");
			int result = query.executeUpdate();	
			if (result > 0) {
				logger.info("Number Of Invalid Char Remove From Include Extractor :- "+result);
			}			
			session.flush();
			session.clear();
		}
		catch(Exception ex){
			logger.trace(ex.getMessage());
		}

		finally {
			if (session != null) {
				session.close();
			}
		}

	}*/

	public int getRowCount(long requestID){		
		int count= 0;
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Query query = session.createQuery("select count(*) from HanaProfilerStepOutput stepOutput where stepOutput.requestID=:requestID");
			query.setLong("requestID", requestID);			
			count = ((Long)query.uniqueResult()).intValue();			
		}
		catch(Exception ex){
			logger.error(ex.getMessage());
		}

		finally {
			if (session != null) {
				session.close();
			}
		}
		return count;
	}

}
