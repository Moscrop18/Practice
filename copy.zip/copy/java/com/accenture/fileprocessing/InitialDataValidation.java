/*CR-39.0:- Upload Consolidated file for HANA,S4,Consolidated -5/10/17 -monika.mishra
 * 
 * US-03.2: Merge Upload Logic of Hana, S4 & AUCT -02/08/2018 -himani.malhotra
 * */
package com.accenture.fileprocessing;

import java.io.File;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.constant.ST03HanaConstant;
import com.accenture.exceptions.IDVFailedException;
import com.accenture.utility.HANAUtility;
import com.accenture.validator.xlsx.XlsxValidator;

public class InitialDataValidation {
	private String rootFilePath = "";

	final Logger logger = LoggerFactory.getLogger(InitialDataValidation.class);

	public InitialDataValidation() {
	}

	public InitialDataValidation(String rootFilePath) {
		super();
		this.rootFilePath = rootFilePath;
	}

	public String getRootFilePath() {
		return rootFilePath;
	}

	public void setRootFilePath(String rootFilePath) {
		this.rootFilePath = rootFilePath;
	}

	public boolean validateAllFiles(Map<String, String> filesNameWithStatus, String clientName, long requestID, String toolName) throws Exception 
	{
		boolean isValid = true;
		logger.info("Validation of files in progress....");
		final File rootFolderFileList[] = new File(getRootFilePath()).listFiles();
		logger.info("no of files " + rootFolderFileList.length);
		String fileName="";
		for (final File file : rootFolderFileList) 
		{
			fileName = file.getName();
			if ((fileName.indexOf(ST03HanaConstant.OUTPUT_HEADING_CONSTANT) != -1)
					|| (fileName.indexOf(ST03HanaConstant.OPERATION_CONSTANT) != -1)) 
			{
				continue;
			}
			try 
			{   //US-03.2
				if("services".equalsIgnoreCase(toolName))
				{
					if (!(new XlsxValidator().validateSProfilerXlsxFiles(file.getAbsoluteFile().toString(), requestID, toolName)))
					{
						//Do we need to set this here?? Ideally if the validation fails, the catch block should take care of it.
						filesNameWithStatus.put(fileName.toUpperCase(), "Invalid");
						HANAUtility.deleteFile(clientName, requestID, fileName);
						isValid = false;
					}
				}	
				
				/*else{//CR-39.0
					if (!(new XlsxValidator().validateSProfilerXlsxFiles(file.getAbsoluteFile().toString(), requestID, toolName)))
					{
						//Do we need to set this here?? Ideally if the validation fails, the catch block should take care of it.
						filesNameWithStatus.put(fileName.toUpperCase(), "Invalid");
						HANAUtility.deleteFile(clientName, requestID, fileName);
						isValid = false;
					}
									
				}*/
			}
			catch (IDVFailedException e) 
			{
				isValid = false;
				filesNameWithStatus.put(fileName.toUpperCase(), e.getMessage());
				HANAUtility.deleteFile(clientName, requestID, fileName);
			}
			catch (Exception e) 
			{
				isValid = false;
				filesNameWithStatus.put(fileName.toUpperCase(), e.getMessage());
				HANAUtility.deleteFile(clientName, requestID, fileName);
			}
		}
		return isValid;
	}
	
	public boolean validateAllFiles(Map<String, String> filesNameWithStatus,  String functionality) throws Exception 
	{
		boolean isValid = true;
		logger.info("Validation of files in progress....");
		final File rootFolderFileList[] = new File(getRootFilePath()).listFiles();
		logger.info("no of files " + rootFolderFileList.length);
		String fileName="";
		for (final File file : rootFolderFileList) 
		{
			
			try 
			{   
				if("CreateSimplification".equalsIgnoreCase(functionality))
				{
					if (!(new XlsxValidator().validateXlsxFilesFrCreateSimpli(file.getAbsoluteFile().toString(), functionality)))
					{
						//Do we need to set this here?? Ideally if the validation fails, the catch block should take care of it.
						filesNameWithStatus.put(fileName.toUpperCase(), "Invalid");
						HANAUtility.deleteFile("Simplification Files", 0, fileName);
						isValid = false;
					}	
				}
				else if("Simplification".equalsIgnoreCase(functionality))
				{
					if (!(new XlsxValidator().validateXlsxFilesForSimpliDB(file.getAbsoluteFile().toString(), functionality)))
					{
						//Do we need to set this here?? Ideally if the validation fails, the catch block should take care of it.
						filesNameWithStatus.put(fileName.toUpperCase(), "Invalid");
						HANAUtility.deleteFile("Simplification File", 0, fileName);
						isValid = false;
					}	
				}
				else if("TCDSimplification".equalsIgnoreCase(functionality))
				{
					if (!(new XlsxValidator().validateXlsxFilesFrTCDSimpli(file.getAbsoluteFile().toString(), functionality)))
					{
						//Do we need to set this here?? Ideally if the validation fails, the catch block should take care of it.
						filesNameWithStatus.put(fileName.toUpperCase(), "Invalid");
						HANAUtility.deleteFile("TCD Simplification Files", 0, fileName);
						isValid = false;
					}	
				}

				else if ("Tar_Usobtc".equalsIgnoreCase(functionality)) {
					if (!(new XlsxValidator().validateXlsxFiles(file.getAbsoluteFile().toString(),
							functionality))) {
						// Do we need to set this here?? Ideally if the validation fails, the catch
						// block should take care of it.
						filesNameWithStatus.put(fileName.toUpperCase(), "Invalid");
						HANAUtility.deleteFile("Target Usobtc Files", 0, fileName);
						isValid = false;
					}
				}
				
				else if ("GRC_STANDARDRULES".equalsIgnoreCase(functionality)) {// validateXlsxFilesFrTargetUsobtc method can be used for GRC also.
					if (!(new XlsxValidator().validateXlsxFiles(file.getAbsoluteFile().toString(),
							functionality))) {
						// Do we need to set this here?? Ideally if the validation fails, the catch
						// block should take care of it.
						filesNameWithStatus.put(fileName.toUpperCase(), "Invalid");
						HANAUtility.deleteFile("Target Usobtc Files", 0, fileName);
						isValid = false;
					}
				}else if ("BW_EXTRACT_MASTER".equalsIgnoreCase(functionality)) {// validateXlsxFilesFrTargetUsobtc method can be used for GRC also.
					if (!(new XlsxValidator().validateXlsxFiles(file.getAbsoluteFile().toString(),
							functionality))) {
						// Do we need to set this here?? Ideally if the validation fails, the catch
						// block should take care of it.
						filesNameWithStatus.put(fileName.toUpperCase(), "Invalid");
						HANAUtility.deleteFile("BW Extract Master Files", 0, fileName);
						isValid = false;
					}
				}
				else if ("Fiori_Rebuild_Master".equalsIgnoreCase(functionality)) {// validateXlsxFilesFrTargetUsobtc method can be used for GRC also.
					if (!(new XlsxValidator().validateXlsxFiles(file.getAbsoluteFile().toString(),
							functionality))) {
						// Do we need to set this here?? Ideally if the validation fails, the catch
						// block should take care of it.
						filesNameWithStatus.put(fileName.toUpperCase(), "Invalid");
						HANAUtility.deleteFile("Fiori Rebuild Master File", 0, fileName);
						isValid = false;
					}
				}
			}
			catch (IDVFailedException e) 
			{
				isValid = false;
				filesNameWithStatus.put(fileName.toUpperCase(), e.getMessage());
				HANAUtility.deleteFile("Simplification Files", 0, fileName);
			}
			catch (Exception e) 
			{
				isValid = false;
				filesNameWithStatus.put(fileName.toUpperCase(), e.getMessage());
				HANAUtility.deleteFile("Simplification Files", 0, fileName);
			}
		}
		return isValid;
	}
}
