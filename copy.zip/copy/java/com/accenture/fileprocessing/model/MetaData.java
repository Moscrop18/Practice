package com.accenture.fileprocessing.model;


public class MetaData {
	

	private Integer id;
	
	private String obj;
	
	private String objName;
	
	private String objDesc;
	
	private Long requestId;

	private Integer interfaceValue;
	
	private Integer reports;
	
	private Integer workflow;
	
	private Integer forms;
	
	private Integer conversion;

	private Integer enhancement;

	private Integer ricefDepd; 

	private Integer fileExt;

	private Integer rfc;

	private Integer tabSap;

	private Integer tabCust;

	private Integer fmSap;

	private Integer fmCust;

	private Integer selCount;
	
	//sum of upd_count, ins_count, del_count, bapi_cud
	private Integer sumOfCRUD;
	
	//sum of z_upd_count, z_ins_count, z_del_count
	private Integer sumOfZCRUD;

	private Integer drill;

	private Integer zDrill;

	private String subcatI;

	private String subcatR;

	private String subcatF;

	private String subcatC;

	private String subcatW;

	private String subcatDtl;

	private String tabSapName;

	private Integer authObj;	

	private Integer nativeIntf;

	private Integer dynproUse;

	private String objPackage;

	private String enhTcode;
	
	private String drillSap;

	private String drillCust;

	private Integer tabField;

	private String orphan;

	private Integer entityCount;

	private Integer viewCust;

	private Integer viewSap;

	private String objTypeName;

	private String metaDataComments;
	
	private Integer moduleScreen;

	private Integer enhImpl;

	private String subType;

	private Integer bapiCud;
	
	private Integer bapiRead;

	private String ricefCategory;

	private String ricefSubCategory;

	private String ricefCategory2;

	private String ricefCategory3;
	
	private String complexity;

	private Integer volume;

	private Integer frequency;

	private String usage;

	private String extensibility;
	
	private String comments;
	
	private String tcode;
	
	Integer count;
	
	private String description;

	private String ricefComments;
	
	private String appArea;
	
	private String appAreaDesc;
	
	private String packageDesc;
	
	private Integer usageCount;
	
	private String cloneType;
	
	private String cloneObj;
	
	private Integer modCount;
	
	private Integer zModCount;
	
	private String commentedLines;
	
	private String exeLines;
	
	private String readProg;
	
	public String getObjTypeName() {
		return objTypeName;
	}

	public void setObjTypeName(String objTypeName) {
		this.objTypeName = objTypeName;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getObj() {
		return obj;
	}

	public void setObj(String obj) {
		this.obj = obj;
	}

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}

	public Long getRequestId() {
		return requestId;
	}

	public void setRequestId(Long requestId) {
		this.requestId = requestId;
	}

	public Integer getInterfaceValue() {
		return interfaceValue;
	}

	public void setInterfaceValue(Integer interfaceValue) {
		this.interfaceValue = interfaceValue;
	}

	public Integer getReports() {
		return reports;
	}

	public void setReports(Integer reports) {
		this.reports = reports;
	}

	public Integer getWorkflow() {
		return workflow;
	}

	public void setWorkflow(Integer workflow) {
		this.workflow = workflow;
	}

	public Integer getForms() {
		return forms;
	}

	public void setForms(Integer forms) {
		this.forms = forms;
	}

	public Integer getConversion() {
		return conversion;
	}

	public void setConversion(Integer conversion) {
		this.conversion = conversion;
	}

	public Integer getEnhancement() {
		return enhancement;
	}

	public void setEnhancement(Integer enhancement) {
		this.enhancement = enhancement;
	}

	public Integer getRicefDepd() {
		return ricefDepd;
	}

	public void setRicefDepd(Integer ricefDepd) {
		this.ricefDepd = ricefDepd;
	}

	public Integer getFileExt() {
		return fileExt;
	}

	public void setFileExt(Integer fileExt) {
		this.fileExt = fileExt;
	}

	public Integer getRfc() {
		return rfc;
	}

	public void setRfc(Integer rfc) {
		this.rfc = rfc;
	}

	public Integer getTabSap() {
		return tabSap;
	}

	public void setTabSap(Integer tabSap) {
		this.tabSap = tabSap;
	}

	public Integer getTabCust() {
		return tabCust;
	}
	
	public Integer getFmSap() {
		return fmSap;
	}

	public void setFmSap(Integer fmSap) {
		this.fmSap = fmSap;
	}

	public Integer getFmCust() {
		return fmCust;
	}

	public void setFmCust(Integer fmCust) {
		this.fmCust = fmCust;
	}

	public void setTabCust(Integer tabCust) {
		this.tabCust = tabCust;
	}

	public Integer getSelCount() {
		return selCount;
	}

	public void setSelCount(Integer selCount) {
		this.selCount = selCount;
	}

	public Integer getSumOfCRUD() {
		return sumOfCRUD;
	}

	public void setSumOfCRUD(Integer sumOfCRUD) {
		this.sumOfCRUD = sumOfCRUD;
	}

	public Integer getSumOfZCRUD() {
		return sumOfZCRUD;
	}

	public void setSumOfZCRUD(Integer sumOfZCRUD) {
		this.sumOfZCRUD = sumOfZCRUD;
	}

	public Integer getDrill() {
		return drill;
	}

	public void setDrill(Integer drill) {
		this.drill = drill;
	}

	public Integer getzDrill() {
		return zDrill;
	}

	public void setzDrill(Integer zDrill) {
		this.zDrill = zDrill;
	}

	public String getSubcatI() {
		return subcatI;
	}

	public void setSubcatI(String subcatI) {
		this.subcatI = subcatI;
	}

	public String getSubcatR() {
		return subcatR;
	}

	public void setSubcatR(String subcatR) {
		this.subcatR = subcatR;
	}

	public String getSubcatF() {
		return subcatF;
	}

	public void setSubcatF(String subcatF) {
		this.subcatF = subcatF;
	}

	public String getSubcatC() {
		return subcatC;
	}

	public void setSubcatC(String subcatC) {
		this.subcatC = subcatC;
	}

	public String getSubcatW() {
		return subcatW;
	}

	public void setSubcatW(String subcatW) {
		this.subcatW = subcatW;
	}

	public String getSubcatDtl() {
		return subcatDtl;
	}

	public void setSubcatDtl(String subcatDtl) {
		this.subcatDtl = subcatDtl;
	}

	public String getTabSapName() {
		return tabSapName;
	}

	public void setTabSapName(String tabSapName) {
		this.tabSapName = tabSapName;
	}

	public Integer getAuthObj() {
		return authObj;
	}

	public void setAuthObj(Integer authObj) {
		this.authObj = authObj;
	}
		
	public Integer getNativeIntf() {
		return nativeIntf;
	}

	public void setNativeIntf(Integer nativeIntf) {
		this.nativeIntf = nativeIntf;
	}

	public Integer getDynproUse() {
		return dynproUse;
	}

	public void setDynproUse(Integer dynproUse) {
		this.dynproUse = dynproUse;
	}

	public String getEnhTcode() {
		return enhTcode;
	}

	public void setEnhTcode(String enhTcode) {
		this.enhTcode = enhTcode;
	}

	public String getObjPackage() {
		return objPackage;
	}

	public void setObjPackage(String objPackage) {
		this.objPackage = objPackage;
	}

	public String getRicefCategory() {
		return ricefCategory;
	}

	public void setRicefCategory(String ricefCategory) {
		this.ricefCategory = ricefCategory;
	}

	public String getRicefSubCategory() {
		return ricefSubCategory;
	}

	public void setRicefSubCategory(String ricefSubCategory) {
		this.ricefSubCategory = ricefSubCategory;
	}

	public String getRicefCategory2() {
		return ricefCategory2;
	}

	public void setRicefCategory2(String ricefCategory2) {
		this.ricefCategory2 = ricefCategory2;
	}

	public String getRicefCategory3() {
		return ricefCategory3;
	}

	public void setRicefCategory3(String ricefCategory3) {
		this.ricefCategory3 = ricefCategory3;
	}

	public String getComplexity() {
		return complexity;
	}

	public void setComplexity(String complexity) {
		this.complexity = complexity;
	}

	public Integer getVolume() {
		return volume;
	}

	public void setVolume(Integer volume) {
		this.volume = volume;
	}

	public Integer getFrequency() {
		return frequency;
	}

	public void setFrequency(Integer frequency) {
		this.frequency = frequency;
	}

	public String getUsage() {
		return usage;
	}

	public void setUsage(String usage) {
		this.usage = usage;
	}

	public String getExtensibility() {
		return extensibility;
	}

	public void setExtensibility(String extensibility) {
		this.extensibility = extensibility;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getTcode() {
		return tcode;
	}

	public void setTcode(String tcode) {
		this.tcode = tcode;
	}

	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDrillSap() {
		return drillSap;
	}

	public void setDrillSap(String drillSap) {
		this.drillSap = drillSap;
	}

	public String getDrillCust() {
		return drillCust;
	}

	public void setDrillCust(String drillCust) {
		this.drillCust = drillCust;
	}

	public Integer getTabField() {
		return tabField;
	}

	public void setTabField(Integer tabField) {
		this.tabField = tabField;
	}

	public String getOrphan() {
		return orphan;
	}

	public void setOrphan(String orphan) {
		this.orphan = orphan;
	}

	public Integer getEntityCount() {
		return entityCount;
	}

	public void setEntityCount(Integer entityCount) {
		this.entityCount = entityCount;
	}

	public Integer getViewCust() {
		return viewCust;
	}

	public void setViewCust(Integer viewCust) {
		this.viewCust = viewCust;
	}

	public Integer getViewSap() {
		return viewSap;
	}

	public void setViewSap(Integer viewSap) {
		this.viewSap = viewSap;
	}

	public String getMetaDataComments() {
		return metaDataComments;
	}

	public void setMetaDataComments(String metaDataComments) {
		this.metaDataComments = metaDataComments;
	}

	public Integer getModuleScreen() {
		return moduleScreen;
	}

	public void setModuleScreen(Integer moduleScreen) {
		this.moduleScreen = moduleScreen;
	}

	public Integer getEnhImpl() {
		return enhImpl;
	}

	public void setEnhImpl(Integer enhImpl) {
		this.enhImpl = enhImpl;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public String getRicefComments() {
		return ricefComments;
	}

	public void setRicefComments(String ricefComments) {
		this.ricefComments = ricefComments;
	}

	public Integer getBapiCud() {
		return bapiCud;
	}

	public void setBapiCud(Integer bapiCud) {
		this.bapiCud = bapiCud;
	}
	
	public Integer getBapiRead() {
		return bapiRead;
	}

	public void setBapiRead(Integer bapiRead) {
		this.bapiRead = bapiRead;
	}

	public String getAppArea() {
		return appArea;
	}

	public void setAppArea(String appArea) {
		this.appArea = appArea;
	}

	public String getAppAreaDesc() {
		return appAreaDesc;
	}

	public void setAppAreaDesc(String appAreaDesc) {
		this.appAreaDesc = appAreaDesc;
	}

	public String getPackageDesc() {
		return packageDesc;
	}

	public void setPackageDesc(String packageDesc) {
		this.packageDesc = packageDesc;
	}

	public Integer getUsageCount() {
		return usageCount;
	}

	public void setUsageCount(Integer usageCount) {
		this.usageCount = usageCount;
	}

	public String getCloneType() {
		return cloneType;
	}

	public void setCloneType(String cloneType) {
		this.cloneType = cloneType;
	}

	public String getCloneObj() {
		return cloneObj;
	}

	public void setCloneObj(String cloneObj) {
		this.cloneObj = cloneObj;
	}

	public String getObjDesc() {
		return objDesc;
	}

	public void setObjDesc(String objDesc) {
		this.objDesc = objDesc;
	}

	public Integer getModCount() {
		return modCount;
	}

	public void setModCount(Integer modCount) {
		this.modCount = modCount;
	}

	public Integer getzModCount() {
		return zModCount;
	}

	public void setzModCount(Integer zModCount) {
		this.zModCount = zModCount;
	}

	public String getCommentedLines() {
		return commentedLines;
	}

	public void setCommentedLines(String commentedLines) {
		this.commentedLines = commentedLines;
	}

	public String getExeLines() {
		return exeLines;
	}

	public void setExeLines(String exeLines) {
		this.exeLines = exeLines;
	}

	public String getReadProg() {
		return readProg;
	}

	public void setReadProg(String readProg) {
		this.readProg = readProg;
	}
	
}
