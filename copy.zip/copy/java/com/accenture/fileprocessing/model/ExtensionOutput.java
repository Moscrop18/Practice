package com.accenture.fileprocessing.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="EXTENSION_OUTPUT")
public class ExtensionOutput {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID")
	private Integer id;
	
	@Column(name="OBJECT")
	private String obj;
	
	@Column(name="OBJECT_NAME")
	private String objName;
	
	@Column(name="REQUEST_ID")
	private Long requestId;
	
	@Column(name="RICEF_CATEGORY")
	private String ricefCategory;
	
	@Column(name="RICEF_SUB_CATEGORY")
	private String ricefSubCategory;
	
	@Column(name="RICEF_CATEGORY_2")
	private String ricefCategory2;
	
	@Column(name="RICEF_CATEGORY_3")
	private String ricefCategory3;
	
	@Column(name="COMPLEXITY")
	private String complexity;
	
	@Column(name="USAGE_VALUE")
	private String usage;
	
	@Column(name="USAGE_COUNT")
	private String usageCount;
	
	@Column(name="EXTENSIBILITY")
	private String extensibility;
	
	@Column(name="COMMENTS",columnDefinition = "LONGTEXT")
	private String comments;
	
	@Column(name="RICEFW_COMMENTS")
	private String ricefwComments;
	
	@Column(name="EFFORTS_COMPLEXITY")
	private String effortsComplexity;
	
	@Column(name="LOOSE_COUPLING")
	private String looseCoupling;
	
	@Column(name="CLONE_TYPE")
	private String cloneType;
	
	@Column(name="CLONE_OBJ")
	private String cloneobj;
	
	@Column(name="APP_AREA")
	private String appArea;
	
	@Column(name="APP_AREA_DESC")
	private String appAreaDesc;

	@Column(name="PACKAGE_NAME")
	private String packageName;
	
	@Column(name="PACKAGE_DESC")
	private String packageDesc;
	
	@Column(name="OBJECT_DESC")
	private String objectDesc;
	
	@Column(name="COMMENTED_LINES")
	private String commentedLines;
	
	@Column(name="EXE_LINES")
	private String exeLines;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getObj() {
		return obj;
	}

	public void setObj(String obj) {
		this.obj = obj;
	}

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}

	public Long getRequestId() {
		return requestId;
	}

	public void setRequestId(Long requestId) {
		this.requestId = requestId;
	}

	public String getRicefCategory() {
		return ricefCategory;
	}

	public void setRicefCategory(String ricefCategory) {
		this.ricefCategory = ricefCategory;
	}

	public String getRicefSubCategory() {
		return ricefSubCategory;
	}

	public void setRicefSubCategory(String ricefSubCategory) {
		this.ricefSubCategory = ricefSubCategory;
	}

	public String getRicefCategory2() {
		return ricefCategory2;
	}

	public void setRicefCategory2(String ricefCategory2) {
		this.ricefCategory2 = ricefCategory2;
	}

	public String getRicefCategory3() {
		return ricefCategory3;
	}

	public void setRicefCategory3(String ricefCategory3) {
		this.ricefCategory3 = ricefCategory3;
	}

	public String getComplexity() {
		return complexity;
	}

	public void setComplexity(String complexity) {
		this.complexity = complexity;
	}

	public String getUsage() {
		return usage;
	}

	public void setUsage(String usage) {
		this.usage = usage;
	}
	
	public String getUsageCount() {
		return usageCount;
	}

	public void setUsageCount(String usageCount) {
		this.usageCount = usageCount;
	}

	public String getExtensibility() {
		return extensibility;
	}

	public void setExtensibility(String extensibility) {
		this.extensibility = extensibility;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getEffortsComplexity() {
		return effortsComplexity;
	}

	public void setEffortsComplexity(String effortsComplexity) {
		this.effortsComplexity = effortsComplexity;
	}

	public String getRicefwComments() {
		return ricefwComments;
	}

	public void setRicefwComments(String ricefwComments) {
		this.ricefwComments = ricefwComments;
	}

	public String getLooseCoupling() {
		return looseCoupling;
	}

	public void setLooseCoupling(String looseCoupling) {
		this.looseCoupling = looseCoupling;
	}

	public String getCloneType() {
		return cloneType;
	}

	public void setCloneType(String cloneType) {
		this.cloneType = cloneType;
	}

	public String getCloneobj() {
		return cloneobj;
	}

	public void setCloneobj(String cloneobj) {
		this.cloneobj = cloneobj;
	}

	public String getAppArea() {
		return appArea;
	}

	public void setAppArea(String appArea) {
		this.appArea = appArea;
	}

	public String getAppAreaDesc() {
		return appAreaDesc;
	}

	public void setAppAreaDesc(String appAreaDesc) {
		this.appAreaDesc = appAreaDesc;
	}

	public String getPackageName() {
		return packageName;
	}

	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	public String getPackageDesc() {
		return packageDesc;
	}

	public void setPackageDesc(String packageDesc) {
		this.packageDesc = packageDesc;
	}

	public String getObjectDesc() {
		return objectDesc;
	}

	public void setObjectDesc(String objectDesc) {
		this.objectDesc = objectDesc;
	}

	public String getCommentedLines() {
		return commentedLines;
	}

	public void setCommentedLines(String commentedLines) {
		this.commentedLines = commentedLines;
	}

	public String getExeLines() {
		return exeLines;
	}

	public void setExeLines(String exeLines) {
		this.exeLines = exeLines;
	}	
}
