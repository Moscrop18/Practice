package com.accenture.fileprocessing.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.*;

import org.hibernate.annotations.GenericGenerator;
import org.springframework.stereotype.Component;


@Entity
@Table(name="ST03_CUSTOM_OBJECTS")
public class ST03CustomObjects {

	private int id;
	private Long requestID;
	private String tCode;
	private String dialogSteps;
	private String classification;
	private String progName;
	
	private String progClass;
	private String defCan;
	/*private Integer month01;
	private Integer month02;
	private Integer month03;
	private Integer month04;
	private Integer month05;
	private Integer month06;
	private Integer month07;
	private Integer month08;
	private Integer month09;
	private Integer month10;
	private Integer month11;
	private Integer month12;*/
	
	

	@Id
	/*@GenericGenerator(name="gen" , strategy="increment")
	@GeneratedValue(generator="gen")*/
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID")
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Column(name="REQUEST_ID")
	public Long getRequestID() {
		return requestID;
	}

	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}

	@Column(name="TCODE")
	public String gettCode() {
		return tCode;
	}

	public void settCode(String tCode) {
		this.tCode = tCode;
	}

	@Column(name="DIALOG_STEPS")
	public String getDialogSteps() {
		return dialogSteps;
	}

	public void setDialogSteps(String dialogSteps) {
		this.dialogSteps = dialogSteps;
	}

	@Column(name="CLASSIFICATION")
	public String getClassification() {
		return classification;
	}

	public void setClassification(String classification) {
		this.classification = classification;
	}

	/*@Column(name="MONTH01")
	public Integer getMonth01() {
		return month01;
	}

	public void setMonth01(Integer month01) {
		this.month01 = month01;
	}

	@Column(name="MONTH02")
	public Integer getMonth02() {
		return month02;
	}

	public void setMonth02(Integer month02) {
		this.month02 = month02;
	}

	@Column(name="MONTH03")
	public Integer getMonth03() {
		return month03;
	}

	public void setMonth03(Integer month03) {
		this.month03 = month03;
	}*/

	
	@Column(name="PROG_NAME")
	public String getProgName() {
		return progName;
	}

	public void setProgName(String progName) {
		this.progName = progName;
	}
	
	
	public ST03CustomObjects()
	{
		
	}

	/*@Column(name="MONTH04")
	public Integer getMonth04() {
		return month04;
	}

	public void setMonth04(Integer month04) {
		this.month04 = month04;
	}

	@Column(name="MONTH05")
	public Integer getMonth05() {
		return month05;
	}

	public void setMonth05(Integer month05) {
		this.month05 = month05;
	}

	@Column(name="MONTH06")
	public Integer getMonth06() {
		return month06;
	}

	public void setMonth06(Integer month06) {
		this.month06 = month06;
	}

	@Column(name="MONTH07")
	public Integer getMonth07() {
		return month07;
	}

	public void setMonth07(Integer month07) {
		this.month07 = month07;
	}

	@Column(name="MONTH08")
	public Integer getMonth08() {
		return month08;
	}

	public void setMonth08(Integer month08) {
		this.month08 = month08;
	}

	@Column(name="MONTH09")
	public Integer getMonth09() {
		return month09;
	}

	public void setMonth09(Integer month09) {
		this.month09 = month09;
	}

	@Column(name="MONTH10")
	public Integer getMonth10() {
		return month10;
	}

	public void setMonth10(Integer month10) {
		this.month10 = month10;
	}

	@Column(name="MONTH11")
	public Integer getMonth11() {
		return month11;
	}

	public void setMonth11(Integer month11) {
		this.month11 = month11;
	}

	@Column(name="MONTH12")
	public Integer getMonth12() {
		return month12;
	}

	public void setMonth12(Integer month12) {
		this.month12 = month12;
	}*/
	
	@Column(name="PROG_CLASS")
	public String getProgClass() {
		return progClass;
	}

	public void setProgClass(String progClass) {
		this.progClass = progClass;
	}

	@Column(name="DEF_CAN")
	public String getDefCan() {
		return defCan;
	}

	public void setDefCan(String defCan) {
		this.defCan = defCan;
	}

	

}



