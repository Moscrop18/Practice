package com.accenture.fileprocessing.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.Index;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.stereotype.Component;


@Entity
@Table(name="INCLUDE_EXTRACTOR")
public class IncludeExtractor {

	private int id;
	private Long requestID;
	private String progName;
	private String includes;
	private String status;

	
	

	@Id
	@GenericGenerator(name="kaugen" , strategy="increment")
	@GeneratedValue(generator="kaugen")
	@Column(name="ID")
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Column(name="REQUEST_ID")
	@Index(name="requestIDindex")
	public Long getRequestID() {
		return requestID;
	}

	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}

	@Column(name="PROG_NAME",length=2000)
	public String getProgName() {
		return progName;
	}

	public void setProgName(String progName) {
		this.progName = progName;
	}

	@Column(name="INCLUDES",length=2000)
	
	public String getIncludes() {
		return includes;
	}

	public void setIncludes(String includes) {
		this.includes = includes;
	}

	@Column(name="STATUS")
	@Index(name="statusindex")
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	
	public IncludeExtractor()
	{
		
	}
	
	

}
