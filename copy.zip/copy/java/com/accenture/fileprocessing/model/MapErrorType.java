/**
 * 
 */
package com.accenture.fileprocessing.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;


/**
 * @author abhishek.sahu
 *
 */

@Entity
@Table(name="Map_Error_Type")
public class MapErrorType {


	private int id;

	private String operation;
	private String errorType;
	private String secondSubCat;

	@Id
	@GenericGenerator(name="gen" , strategy="increment")
	@GeneratedValue(generator="gen")
	@Column(name="ID")
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	@Column(name="Operation")
	public String getOperation() {
		return operation;
	}
	public void setOperation(String operation) {
		this.operation = operation;
	}
	
	@Column(name="Error_Type")
	public String getErrorType() {
		return errorType;
	}
	public void setErrorType(String errorType) {
		this.errorType = errorType;
	}
	
	@Column(name="Second_Sub_Cat")
	public String getSecondSubCat() {
		return secondSubCat;
	}
	public void setSecondSubCat(String secondSubCat) {
		this.secondSubCat = secondSubCat;
	}

	
	
	






}
