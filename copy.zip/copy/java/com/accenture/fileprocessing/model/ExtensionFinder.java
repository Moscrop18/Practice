package com.accenture.fileprocessing.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="MASTER_EXTENSION_FINDER")
public class ExtensionFinder {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID")
	private int id;
	
	@Column(name="TARGET_SYSTEM")
	private String targetSystem;
	
	@Column(name="SIDE_BY_SIDE_EXT")
	private String sideBySideExt;
	
	@Column(name="IN_APP_EXT")
	private String inAppExt;
	
	@Column(name="CLASSIC_EXT")
	private String classicExt;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTargetSystem() {
		return targetSystem;
	}

	public void setTargetSystem(String targetSystem) {
		this.targetSystem = targetSystem;
	}

	public String getSideBySideExt() {
		return sideBySideExt;
	}

	public void setSideBySideExt(String sideBySideExt) {
		this.sideBySideExt = sideBySideExt;
	}

	public String getInAppExt() {
		return inAppExt;
	}

	public void setInAppExt(String inAppExt) {
		this.inAppExt = inAppExt;
	}

	public String getClassicExt() {
		return classicExt;
	}

	public void setClassicExt(String classicExt) {
		this.classicExt = classicExt;
	}
		
}
