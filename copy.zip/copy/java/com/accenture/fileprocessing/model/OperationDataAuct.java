package com.accenture.fileprocessing.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="OPERATION_DATA_AUCT")
public class OperationDataAuct {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID")
	private int id;
	
	@Column(name="OPCODE")
	private String  opCode;
	
	@Column(name="REMARKS")
	private String remarks;
	
	@Column(name="STATEMENT")
	private String statement;
	
	@Column(name="AUTOMATION_STATUS")
	private String automationStatus;
	
	@Column(name="DESCRIPTION_OF_CHANGE")
	private String descriptionOfChange;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getOpCode() {
		return opCode;
	}

	public void setOpCode(String opCode) {
		this.opCode = opCode;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getStatement() {
		return statement;
	}

	public void setStatement(String statement) {
		this.statement = statement;
	}

	public String getAutomationStatus() {
		return automationStatus;
	}

	public void setAutomationStatus(String automationStatus) {
		this.automationStatus = automationStatus;
	}

	public String getDescriptionOfChange() {
		return descriptionOfChange;
	}

	public void setDescriptionOfChange(String descriptionOfChange) {
		this.descriptionOfChange = descriptionOfChange;
	}
	
}
