package com.accenture.fileprocessing.model;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.springframework.stereotype.Component;


@Entity
@Table(name="ST03_CUSTOM_DIALOG")
public class ST03CustomDialog   {

	private int id;
	private Long requestID;
	private String progName;
	private String dialogSteps;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID")
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Column(name="REQUEST_ID")
	public Long getRequestID() {
		return requestID;
	}

	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}

	@Column(name="PROG_NAME")
	public String getProgName() {
		return progName;
	}

	public void setProgName(String progName) {
		this.progName = progName;
	}

	@Column(name="DIALOG_STEPS")
	public String getDialogSteps() {
		return dialogSteps;
	}

	public void setDialogSteps(String dialogSteps) {
		this.dialogSteps = dialogSteps;
	}


	
	public ST03CustomDialog()
	{
		
	}
	
	

}


