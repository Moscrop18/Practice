package com.accenture.fileprocessing.model;


import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.springframework.stereotype.Component;

@Entity
@Table(name="ST03_CUSTOM")
public class ST03Custom  {

	private int id;
	private Long requestID;
	private String progName;
	private String objectName;
	private String objectType;
	private String dialogSteps;
	private String  dbPercentMonth;
	private String  changePercentMonth;


	
	@Id
	//@GenericGenerator(name="gen" , strategy="increment")
	//@GeneratedValue(generator="gen")
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID")
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Column(name="REQUEST_ID")
	public Long getRequestID() {
		return requestID;
	}

	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}

	@Column(name="PROG_NAME")
	public String getProgName() {
		return progName;
	}

	public void setProgName(String progName) {
		this.progName = progName;
	}

	@Column(name="OBJECT_NAME")
	public String getObjectName() {
		return objectName;
	}

	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}

	@Column(name="OBJECT_TYPE")
	public String getObjectType() {
		return objectType;
	}

	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}

	@Column(name="DIALOG_STEPS")
	public String getDialogSteps() {
		return dialogSteps;
	}

	public void setDialogSteps(String dialogSteps) {
		this.dialogSteps = dialogSteps;
	}
	
	@Column(name="DB_PERCENT_MONTH")
	public String  getDbPercentMonth() {
		return dbPercentMonth;
	}

	public void setDbPercentMonth(String  dbPercentMonth) {
		this.dbPercentMonth = dbPercentMonth;
	}

	@Column(name="CHANGE_PERCENT_MONTH")
	public String  getChangePercentMonth() {
		return changePercentMonth;
	}

	public void setChangePercentMonth(String  changePercentMonth) {
		this.changePercentMonth = changePercentMonth;
	}

	
	
	public ST03Custom()
	{
		
	}
	
	

}

