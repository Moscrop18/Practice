package com.accenture.fileprocessing.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class SunBaseDataResultBean {

	private BigDecimal dialog;
	private String prog;
	private String monthYear;
	public BigDecimal getDialog() {
		return dialog;
	}
	public void setDialog(BigDecimal dialog) {
		this.dialog = dialog;
	}
	public String getProg() {
		return prog;
	}
	public void setProg(String prog) {
		this.prog = prog;
	}
	public String getMonthYear() {
		return monthYear;
	}
	public void setMonthYear(String monthYear) {
		this.monthYear = monthYear;
	}
}
