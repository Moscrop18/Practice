/*MODIFIED 
 *
 *CR-13.0- New Output Sheet implementation - 03/03/2017 - monika.mishra
 *
 *CR-25.0- Few fields which will be moved to JAVA tool in HANA Profiler - 10/07/2017 - monika.mishra
 **/

package com.accenture.fileprocessing;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.accenture.constant.Hana_Profiler_Constant;
import com.accenture.constant.ST03HanaConstant;
import com.accenture.fileprocesing.dao.ST03HanaDAOImpl;
import com.accenture.fileprocessing.model.HanaProfilerStepOutput;

import com.accenture.fileprocessing.model.TestTab;
import com.accenture.fileprocessing.model.TestTab1;
import com.accenture.utility.HANAUtility;

public class GenerateHANAFinalSheet {
	private String filePath;
	private ST03HanaDAOImpl st03Hanadao;
	private PopulateHanaTables populateHanaTables;

	public void setPopulateHanaTables(PopulateHanaTables populateHanaTables) {
		this.populateHanaTables = populateHanaTables;
	}

	public void setSt03Hanadao(ST03HanaDAOImpl st03Hanadao) {
		this.st03Hanadao = st03Hanadao;
	}

	public GenerateHANAFinalSheet(String filePath) {
		super();
		this.filePath = filePath;
	}

	public GenerateHANAFinalSheet() {

	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	final static Logger logger = LoggerFactory.getLogger(GenerateHANAFinalSheet.class);

	public boolean executeGenerateHanaFinalSheet(final long requestId) {
		logger.info("Hana Profiler step begins here.....");
		double initialTime = System.currentTimeMillis();
		boolean HANAStepStatus = false;
	
		
		try{
		
			long insertStartTime = System.currentTimeMillis();
			//populateHanaTables.populateST03Custom(requestId);
			long insertEndTime = System.currentTimeMillis();
			long insetTotalTime = insertEndTime - insertStartTime;
			logger.info("Total Time in inserting value to ST03_CUSTOM=" + insetTotalTime);

		
			long insertStartTimeSt03Customdialog = System.currentTimeMillis();
			//populateHanaTables.populateST03CustomDialog(requestId);
			long insertEndTimeSt03Customdialog = System.currentTimeMillis();
			long insetTotalTimeSt03Customdialog = insertEndTimeSt03Customdialog - insertStartTimeSt03Customdialog;

			logger.info("Total Time in inserting value to ST03_CUSTOM_DIALOG=" + insetTotalTime);
		
			//st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql21);
		
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql23);
			
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql24);
	
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql25);
			
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql26);
		
			//CR-13.0 adding data of high_level_description.
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql27);
			
			//CR-25.0 adding data of active_Status.
			st03Hanadao.insertORUpdate(requestId, ST03HanaConstant.sql28);
			
			//logger.info("Total Time in populating HANA PROFILER QUERY=" + totalTime);
			HANAStepStatus = true;

		} catch (Exception e) {
			HANAStepStatus = false;
			logger.error("Exception while executing the HANA Profiler Queries :: " + e);
		}
		logger.info("All Queries executed for HANA Profiler ......");

		double finalTime = System.currentTimeMillis();
		double netTime = finalTime - initialTime;

		logger.info("Total time for HANA Profiler Step =" + netTime);

		return HANAStepStatus;

	}

	private void updateUsedUnused(final long requestId, final List<String> objectNameList) {
		if (CollectionUtils.isNotEmpty(objectNameList)) {
			final List<HanaProfilerStepOutput> hanaProfilerStepOutputList = st03Hanadao
					.getHanaProfilerStepOutputList(requestId, objectNameList);
			if (CollectionUtils.isNotEmpty(hanaProfilerStepOutputList)) {
				for (HanaProfilerStepOutput bean : hanaProfilerStepOutputList) {
					bean.setUsedUnused("Used");
				}
				populateHanaTables.populateDataList(hanaProfilerStepOutputList);
			}
		}
	}

	/*private void updateUsedUnusedFromST03Custom(final long requestId) {
		final List<String> progNameList = st03Hanadao.getST03CustomProgNameList(requestId);
		updateUsedUnused(requestId, progNameList);
	}

	private void updateUsedUnUsedFromIncludeExtractor(final long requestId) {

		final List<String> includeList = st03Hanadao.getIncludeList(requestId);
		if (CollectionUtils.isNotEmpty(includeList)) {
			final List<String> includeTrimList = new ArrayList<String>();
			for (String include : includeList) {
				includeTrimList.add(StringUtils.trim(include));
			}
			updateUsedUnused(requestId, includeTrimList);
		}

	}
*/
	private Map<String, List<TestTab>> convertTestTabListToMap(final List<TestTab> testTabList) {
		final Map<String, List<TestTab>> testTabMap = new HashMap<String, List<TestTab>>();
		List<TestTab> testTabProgList;
		for (TestTab testTab : testTabList) {
			testTabProgList = testTabMap.get(StringUtils.lowerCase(testTab.gettCode()));
			if (testTabProgList == null) {
				testTabProgList = new ArrayList<TestTab>();
				testTabProgList.add(testTab);
				testTabMap.put(StringUtils.lowerCase(testTab.gettCode()), testTabProgList);
			} else {
				testTabProgList.add(testTab);
			}
		}

		return testTabMap;
	}

	/*private void deleteST03Data(final long requestId) {
		List<TestTab> testTabList = st03Hanadao.getTestTabData(requestId);
		if (CollectionUtils.isNotEmpty(testTabList)) {
			final Map<String, List<TestTab>> testTabMap = convertTestTabListToMap(testTabList);
			final Set<String> progSet = testTabMap.keySet();
			final List<ST03MonthData> st03MonthDataList = st03Hanadao.getSt03MonthData(requestId, progSet);

			if (CollectionUtils.isNotEmpty(st03MonthDataList)) {
				final List<ST03MonthData> deleteDataList = new ArrayList<ST03MonthData>();
				String prog;
				for (ST03MonthData st03MonthData : st03MonthDataList) {
					prog = st03MonthData.getProgName();
					testTabList = testTabMap.get(StringUtils.lowerCase(prog));
					if (CollectionUtils.isNotEmpty(testTabList)) {
						for (TestTab testTab : testTabList) {
							if (!StringUtils.equals(testTab.getDbPercent(), st03MonthData.getDbPercent())) {
								deleteDataList.add(st03MonthData);
							}
						}
					}
				}
				populateHanaTables.deleteList(deleteDataList);
			}

		}

	}

	private Map<String, String> convertST03CustomDialogListToMap(final List<ST03CustomDialog> st03CustomDialogList) {
		final Map<String, String> st03CustomDialogMap = new HashMap<String, String>();
		for (ST03CustomDialog st03CustomDialog : st03CustomDialogList) {
			st03CustomDialogMap.put(StringUtils.lowerCase(st03CustomDialog.getProgName()),
					st03CustomDialog.getDialogSteps());
		}

		return st03CustomDialogMap;
	}
*/
	/*private void updateHanaProfilerStepOutputDialogSteps(final long requestId) {
		final List<HanaProfilerStepOutput> hanaProfilerStepOuputList = st03Hanadao
				.getHanaProfilerStepOutputListWithDialgStepNull(requestId);

		if (CollectionUtils.isNotEmpty(hanaProfilerStepOuputList)) {
			final List<ST03CustomDialog> st03CustomDialogList = st03Hanadao.getSt03CustomDialogList(requestId);
			if (CollectionUtils.isNotEmpty(st03CustomDialogList)) {
				final Map<String, String> st03CustomDialogMap = convertST03CustomDialogListToMap(st03CustomDialogList);
				for (HanaProfilerStepOutput hanaProfilerStepOutput : hanaProfilerStepOuputList) {
					hanaProfilerStepOutput.setDialogSteps(
							st03CustomDialogMap.get(StringUtils.lowerCase(hanaProfilerStepOutput.getObjName())));
				}

				populateHanaTables.populateDataList(hanaProfilerStepOuputList);
			}
		}

	}

	private Map<String, ST03Custom> convertST03CustomListToMap(final List<ST03Custom> st03CustomList) {

		final Map<String, ST03Custom> st03CustomMap = new HashMap<String, ST03Custom>();
		for (ST03Custom st03Custom : st03CustomList) {
			st03CustomMap.put(StringUtils.lowerCase(st03Custom.getProgName()), st03Custom);
		}

		return st03CustomMap;

	}

	private void updateHanaProfilerStepOutputDBChangePercent(final long requestId) {

		final List<HanaProfilerStepOutput> hanaProfilerStepOutputList = st03Hanadao
				.getHanaProfilerStepOutputListWithDbChangePercentNull(requestId);
		if (CollectionUtils.isNotEmpty(hanaProfilerStepOutputList)) {
			final List<ST03Custom> st03CustomList = st03Hanadao.getSt03CustomData(requestId, null);
			if (CollectionUtils.isNotEmpty(st03CustomList)) {

				final Map<String, ST03Custom> st03CustomMap = convertST03CustomListToMap(st03CustomList);
				ST03Custom st03Custom = null;
				for (HanaProfilerStepOutput hanaProfilerStepOutput : hanaProfilerStepOutputList) {
					st03Custom = st03CustomMap.get(StringUtils.lowerCase(hanaProfilerStepOutput.getObjName()));
					// hanaProfilerStepOutput.setDbPercent(st03CustomMap.get(hanaProfilerStepOutput.getObjName()));
					if (st03Custom != null) {
						if (hanaProfilerStepOutput.getDbPercent() == null) {
							hanaProfilerStepOutput.setDbPercent(st03Custom.getDbPercentMonth());
						}
						if (hanaProfilerStepOutput.getChangePercent() == null) {
							hanaProfilerStepOutput.setChangePercent(st03Custom.getChangePercentMonth());
						}
					}
				}

				populateHanaTables.populateDataList(hanaProfilerStepOutputList);

			}
		}

	}

	private void deleteST03CustomData(final long requestId) {
		List<TestTab1> testTabList = st03Hanadao.getTestTab1Data(requestId);
		if (CollectionUtils.isNotEmpty(testTabList)) {
			final Map<String, List<TestTab1>> testTabMap = convertTestTab1ListToMap(testTabList);
			final Set<String> progSet = testTabMap.keySet();
			final List<ST03Custom> st03CustomDataList = st03Hanadao.getSt03CustomData(requestId, progSet);

			if (CollectionUtils.isNotEmpty(st03CustomDataList)) {
				final List<ST03Custom> deleteDataList = new ArrayList<ST03Custom>();
				String prog;
				for (ST03Custom st03CustomData : st03CustomDataList) {
					prog = st03CustomData.getProgName();
					testTabList = testTabMap.get(StringUtils.lowerCase(prog));
					if (CollectionUtils.isNotEmpty(testTabList)) {
						for (TestTab1 testTab : testTabList) {
							if (!StringUtils.equals(testTab.getDbPercent(), st03CustomData.getDbPercentMonth())) {
								deleteDataList.add(st03CustomData);
							}
						}
					}
				}
				populateHanaTables.deleteList(deleteDataList);
			}

		}

	}
*/
	private Map<String, List<TestTab1>> convertTestTab1ListToMap(final List<TestTab1> testTabList) {
		final Map<String, List<TestTab1>> testTabMap = new HashMap<String, List<TestTab1>>();
		List<TestTab1> testTabProgList;
		for (TestTab1 testTab1 : testTabList) {
			testTabProgList = testTabMap.get(StringUtils.lowerCase(testTab1.getProgName()));
			if (testTabProgList == null) {
				testTabProgList = new ArrayList<TestTab1>();
				testTabProgList.add(testTab1);
				testTabMap.put(StringUtils.lowerCase(testTab1.getProgName()), testTabProgList);
			} else {
				testTabProgList.add(testTab1);
			}
		}

		return testTabMap;
	}

}
