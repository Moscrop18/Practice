/*MODIFIED 
 *FOR Enhancement 
 * 
 *CR-29.0:- Shown CDS View on basis of tables column value -5/08/17 -monika.mishra
 *
 *CR-39.0:- Upload Consolidated file for HANA,S4,Consolidated -5/10/17 -monika.mishra
 *
 *US-03.2: Merge Upload Logic of Hana, S4 & AUCT: Upload Input Sheets -02/08/2018 -himani.malhotra
 *
 *US: Usage and Inventory sheet names as Usage Analysis, Inventory List respectively -04/09/2018 -himani.malhotra
 *
 *DEF: Big Simplification Changes -17/05/2019 -himani.malhotra
 **/

package com.accenture.fileprocessing;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import com.accenture.bw.model.BwObjectTypeDateFormat;
import com.accenture.client.model.RequestForm;
import com.accenture.client.model.UploadFilesNumber;
import com.accenture.constant.File_Size_Constant;
import com.accenture.utility.AppGenUtility;
import com.accenture.utility.HANAUtility;

public class CheckFileListStatus {

	private String rootPath;

	public String getRootPath() {
		return rootPath;
	}

	public void setRootPath(String rootPath) {
		this.rootPath = rootPath;
	}

	public CheckFileListStatus(String rootPath) {
		setRootPath(rootPath);
	}

	public Map<String, String> checkListStatus(String toolName, RequestForm requestForm,
			UploadFilesNumber uploadFileNum) throws IOException {
		ArrayList<String> checkList = new ArrayList<String>();

		if ("services".equals(toolName)) {
			if (requestForm.getSOH()) {
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "ZAICATDetectionToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "TRDIRNameToken"));
				// checkList.add(HANAUtility.getPropertyValue("testing.properties",
				// "CDSViewToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "INVENTORYNameToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "SmodilogToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "ImpactedCloneAnalysisToken"));
				if ("NO".equalsIgnoreCase(requestForm.getUnicodeCompliant())
						&& "YES".equalsIgnoreCase(requestForm.getEnableUnicode())) {
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "UNICODEToken"));
				}
				
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "InactiveObjectsToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "MetaDataToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "ACNIPZVERCOMPToken"));

			}

			if (requestForm.getUPGRADE()) {
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "ZAICATDetectionToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "TRDIRNameToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "INVENTORYNameToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "SmodilogToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "ImpactedCloneAnalysisToken"));
				if ("NO".equalsIgnoreCase(requestForm.getUnicodeCompliant())
						&& "YES".equalsIgnoreCase(requestForm.getEnableUnicode())) {
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "UNICODEToken"));
				}
				
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "InactiveObjectsToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "MetaDataToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "ACNIPZVERCOMPToken"));

			}

			if (requestForm.getS4Technical()) {
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "ZAICATDetectionToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "TRDIRNameToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "BWExtractorToken"));

				// checkList.add(HANAUtility.getPropertyValue("testing.properties",
				// "EnhancementNameToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "AppendStructureNameToken"));
				// checkList.add(HANAUtility.getPropertyValue("testing.properties",
				// "CloneAnalysisNameToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "INVENTORYNameToken"));
				// checkList.add(HANAUtility.getPropertyValue("testing.properties",
				// "SearchHelpNameToken"));
				// checkList.add(HANAUtility.getPropertyValue("testing.properties",
				// "IDOCNameToken"));
				// checkList.add(HANAUtility.getPropertyValue("testing.properties",
				// "ImpactedTableNameToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "ImpactedStandardTransactionsToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "SmodilogToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "ImpactedCloneAnalysisToken"));
				if ("NO".equalsIgnoreCase(requestForm.getUnicodeCompliant())
						&& "YES".equalsIgnoreCase(requestForm.getEnableUnicode())) {
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "UNICODEToken"));
				}

				checkList.add(HANAUtility.getPropertyValue("testing.properties", "InactiveObjectsToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "MetaDataToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "ACNIPZVERCOMPToken"));

			}

			// IRPA - Input File Upload - Business Process Detail
			if ((requestForm.getSOH() || requestForm.getS4Technical() || requestForm.getUPGRADE())
					&& AppGenUtility.getTScopeVer(requestForm.getSourceVersion(), requestForm.getTargetVersion())) {
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "BusinessProcessDetailsToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "ACNIPZVERCOMPToken"));

			}

			if (requestForm.getBwTech()) {
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "ZAICATDetectionToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "TRDIRNameToken"));
				// checkList.add(HANAUtility.getPropertyValue("testing.properties",
				// "EnhancementNameToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "AppendStructureNameToken"));
				// checkList.add(HANAUtility.getPropertyValue("testing.properties",
				// "CloneAnalysisNameToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "INVENTORYNameToken"));
				// checkList.add(HANAUtility.getPropertyValue("testing.properties",
				// "SearchHelpNameToken"));
				// checkList.add(HANAUtility.getPropertyValue("testing.properties",
				// "IDOCNameToken"));
				// checkList.add(HANAUtility.getPropertyValue("testing.properties",
				// "ImpactedTableNameToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "ImpactedStandardTransactionsToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "SmodilogToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "ImpactedCloneAnalysisToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "BWINVToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "InactiveObjectsToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "MetaDataToken"));
			}
			if (requestForm.getSOH() && requestForm.getUPGRADE() && requestForm.getS4Technical()) {
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "ZAICATDetectionToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "TRDIRNameToken"));
				// checkList.add(HANAUtility.getPropertyValue("testing.properties",
				// "CDSViewToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "INVENTORYNameToken"));
				// checkList.add(HANAUtility.getPropertyValue("testing.properties",
				// "EnhancementNameToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "AppendStructureNameToken"));
				// checkList.add(HANAUtility.getPropertyValue("testing.properties",
				// "CloneAnalysisNameToken"));
				// checkList.add(HANAUtility.getPropertyValue("testing.properties",
				// "SearchHelpNameToken"));
				// checkList.add(HANAUtility.getPropertyValue("testing.properties",
				// "IDOCNameToken"));
				// checkList.add(HANAUtility.getPropertyValue("testing.properties",
				// "ImpactedTableNameToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "ImpactedStandardTransactionsToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "ImpactedCloneAnalysisToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "InactiveObjectsToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "MetaDataToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "ACNIPZVERCOMPToken"));

			}

			if (requestForm.getS4Functional()) {
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "ZAICATDetectionToken"));
				 checkList.add(HANAUtility.getPropertyValue("testing.properties", "EnhancementNameToken"));
			}

			if (requestForm.getUI5()) {
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "ZAICATDetectionToken"));
			}

			if (requestForm.getFiori()) {
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "ZAICATDetectionToken"));
//				checkList.add(HANAUtility.getPropertyValue("testing.properties", "CustomReportOutputToken"));
			}

			if (requestForm.getRFP()) {
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "TADIRNameToken"));
			}

			if (requestForm.getSia()) {
				String srcAGRToken = HANAUtility.getPropertyValue("testing.properties", "SRCAGRToken");
				for (int i = 1; i <= uploadFileNum.getNum_SRC_AGR1251(); i++)
					checkList.add(srcAGRToken + "_" + i);
				String srcAgrUsersToken = HANAUtility.getPropertyValue("testing.properties", "SRCAGRUSERSToken");
				for (int i = 1; i <= uploadFileNum.getNum_SRC_AGRUSERS(); i++)
					checkList.add(srcAgrUsersToken + "_" + i);
				String srcUsobtcToken = HANAUtility.getPropertyValue("testing.properties", "SRCUSOBTCToken");
				for (int i = 1; i <= uploadFileNum.getNum_SRC_USOBTC(); i++)
					checkList.add(srcUsobtcToken + "_" + i);
			}

			if (requestForm.getOsMig()) {
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "INVENTORYNameToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "ImpactedCloneAnalysisToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "ZAICATDetectionToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "InactiveObjectsToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "MetaDataToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "ACNIPZVERCOMPToken"));

			}

			if (requestForm.getGrc()) {
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "GRTGRACFUNCACTToken"));
			}
			if (requestForm.getEXT()) {

				checkList.add(HANAUtility.getPropertyValue("testing.properties", "MetaDataToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "ZAICATDetectionToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "ComplexityRulesToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "ExtensibilityRulesToken"));
				checkList.add(HANAUtility.getPropertyValue("testing.properties", "ImpactedCloneAnalysisToken"));
			}
		}

		HelperCheckFileList helper = new HelperCheckFileList(rootPath);
		Map<String, String> resultList = helper.checkIfReady(checkList);
		return resultList;
	}
	
	public Map<String, String> checkListStatusBWusage(String toolName, RequestForm requestForm,
			UploadFilesNumber uploadFileNum, BwObjectTypeDateFormat dateAndObj) throws IOException {
		ArrayList<String> checkList = new ArrayList<String>();

		if ("services".equals(toolName)) {
			
			if (requestForm.getBwUsage()) {
				if (dateAndObj.getOdso()) {
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "RSDODSOToken"));
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "RSICCONTToken"));
				}
				if (dateAndObj.getIobj()) {
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "RSDIOBJToken"));
				}
				if (dateAndObj.getCuba()) {
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "RSDCUBEToken"));
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "RSICCONTToken"));

				}
				if (dateAndObj.getMpro()) {
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "RSDCUBEToken"));

				}

				if (dateAndObj.getIset()) {
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "RSQISETToken"));

				}
				if (dateAndObj.getOdh()) {
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "RSBOHDESTToken"));
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "RSBKREQUESTToken"));

				}
				if (dateAndObj.getAnpr()) {
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "RSANT_PROCESSToken"));
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "RSANT_PROCESSRToken"));

				}
				if (dateAndObj.getHcpr()) {
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "RSOHCPRToken"));

				}
				if (dateAndObj.getTrn()) {
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "RSTRANToken"));

				}
				if (dateAndObj.getUpdr()) {
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "RSUPDINFOToken"));

				}
				if (dateAndObj.getIsts()) {
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "RSTSToken"));

				}
				if (dateAndObj.getRsds()) {
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "RSDSToken"));

				}
				if (dateAndObj.getIsip()) {
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "RSLDPIOToken"));

				}
				if (dateAndObj.getDtpa()) {
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "RSBKDTPToken"));
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "RSBKDTPSTATToken"));

				}
				if (dateAndObj.getElem()) {
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "RSRREPDIRToken"));

				}
				if (dateAndObj.getXlwb()) {
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "RSRWBINDEXToken"));
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "RSRWBINDEXTToken"));
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "RSRWORKBOOKToken"));
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "RSRREPDIRToken"));

				}
				if (dateAndObj.getBtmp()) {
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "RSZWBTMPHEADToken"));
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "RSZWBTMPDATAToken"));
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "BIOAPERS_SOD00Token"));

				}
				if (dateAndObj.getTmpl()) {
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "RSZWTEMPLATEToken"));
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "BIOAPERS_SOD00Token"));

				}
				if (dateAndObj.getRspc()) {
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "RSPCCHAINATTRToken"));
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "RSPCPROCESSLOGToken"));
					checkList.add(HANAUtility.getPropertyValue("testing.properties", "RSPCCHAINToken"));

				}
			}
			
		}

		HelperCheckFileList helper = new HelperCheckFileList(rootPath);
		Map<String, String> resultList = helper.checkIfReady(checkList);
		return resultList;
	}

	// Monika : Create
	public Map<String, String> validateFiles(String funtionality, String rootPath) throws IOException {
		ArrayList<String> checkList = new ArrayList<String>();
		if ("CreateSimplification".equalsIgnoreCase(funtionality)) {

			checkList.add(HANAUtility.getPropertyValue("testing.properties", "SimplificationToken"));
		} // Big Simplification Reading Changes
		else if ("Simplification".equalsIgnoreCase(funtionality)) {
			checkList.add(HANAUtility.getPropertyValue("testing.properties", "SimplificationToken"));

		} else if ("TCDSimplification".equalsIgnoreCase(funtionality)) {
			checkList.add(HANAUtility.getPropertyValue("testing.properties", "TCDSimplificationtoken"));

		} else if ("Tar_Usobtc".equalsIgnoreCase(funtionality)) {
			checkList.add(HANAUtility.getPropertyValue("testing.properties", "TARUSOBTCToken"));
		} else if ("GRC_STANDARDRULES".equalsIgnoreCase(funtionality)) {
			checkList.add(HANAUtility.getPropertyValue("testing.properties", "GRCMastertoken"));
		} else if ("BW_EXTRACT_MASTER".equalsIgnoreCase(funtionality)) {
			checkList.add(HANAUtility.getPropertyValue("testing.properties", "BwExtractMasterToken"));
		}
		else if("Fiori_Rebuild_Master".equalsIgnoreCase(funtionality)) {
			checkList.add(HANAUtility.getPropertyValue("testing.properties", "FioriRebuildMasterToken"));
		}

		HelperCheckFileList helper = new HelperCheckFileList(rootPath);
		Map<String, String> resultList = helper.checkIfReady(checkList);
		return resultList;
	}

}
