package com.accenture.fileprocessing;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate4.HibernateTemplate;

import com.accenture.displaygrid.model.HanaProfile;

public class VerifyOutputSheet {
	private HibernateTemplate hibernateTemplate;
	public SessionFactory sessionFactory;

	final Logger logger = LoggerFactory.getLogger(VerifyOutputSheet.class);

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.hibernateTemplate = new HibernateTemplate(sessionFactory);
		this.sessionFactory = sessionFactory;
	}

	private String hanaFilePath = "";

	private List finalOutputList;
	private List<HanaProfile> hanaProfilerExcelData;
	private List<HanaProfile> FinalOutputTableData;
	long requestId;

	public List<HanaProfile> getFinalOutputTableData() {
		return FinalOutputTableData;
	}

	public void setFinalOutputTableData(List<HanaProfile> finalOutputTableData) {
		FinalOutputTableData = finalOutputTableData;
	}

	public long getRequestId() {
		return requestId;
	}

	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}

	public List<HanaProfile> getHanaProfilerExcelData() {
		return hanaProfilerExcelData;
	}

	public void setHanaProfilerExcelData(List<HanaProfile> hanaProfilerExcelData) {
		this.hanaProfilerExcelData = hanaProfilerExcelData;
	}

	public List getFinalOutputList() {
		return finalOutputList;
	}

	public void setFinalOutputList(List finalOutputList) {
		this.finalOutputList = finalOutputList;
	}

	public String getHanaFilePath() {
		return hanaFilePath;
	}

	public void setHanaFilePath(String hanaFilePath) {
		this.hanaFilePath = hanaFilePath;
	}

	/// 1

	private String getConcatenatedStringHanaList(int index) {
		List finalOutputList = this.getFinalOutputList();
		HanaProfile hanProfiler = (HanaProfile) finalOutputList.get(index);
		String concatString = hanProfiler.getObj_Name() + hanProfiler.getSub_Program() + hanProfiler.getLine_Number()
				+ hanProfiler.getOperation_code();
		return concatString;
	}

	private boolean checkConcatenatedStringFromExcelandDB(List<HanaProfile> hanaExcelData) {
		boolean concatStatus = false;

		// List<HanaProfile> hanaExcelData=this.getHanaProfilerExcelData();

		for (int i = 0; i < hanaExcelData.size(); i++) {
			HanaProfile hanaExcelObject = (HanaProfile) hanaExcelData.get(i);

			String testExcelString = hanaExcelObject.getObj_Name() + hanaExcelObject.getSub_Program()
					+ hanaExcelObject.getLine_Number() + hanaExcelObject.getOperation_code();
			String testDbString = getConcatenatedStringHanaList(i);

			if (!testExcelString.equals(testDbString)) {
				concatStatus = false;
				break;
			}

		}
		return concatStatus;
	}

	///

	private boolean checkObjectCount(List<HanaProfile> hanaExcelData) {
		boolean ObjectCountStatus = false;
		int objectCountExcel = 0;
		int mandatoryCountExcel = 0;

		for (int i = 0; i < hanaExcelData.size(); i++) {
			HanaProfile hanaExcelObject = (HanaProfile) hanaExcelData.get(i);

			if (!(hanaExcelObject.getOperation_code().equals("99") || hanaExcelObject.getOperation_code().equals("20")
					|| hanaExcelObject.getOperation_code().equals("45")
					|| hanaExcelObject.getOperation_code().equals("46"))) {
				objectCountExcel = objectCountExcel + 1;
				if (hanaExcelObject.getOperation_code().equals("11") || hanaExcelObject.getOperation_code().equals("12")
						|| hanaExcelObject.getOperation_code().equals("13")
						|| hanaExcelObject.getOperation_code().equals("16")) {
					mandatoryCountExcel = mandatoryCountExcel + 1;
				}
			}
		}
		int objectCountFinalOutput = this.getFinalOutputList().size();
		int mandatoryObjectCount = getFinalOutputMandatoryObjectCount();
		if (objectCountExcel == objectCountFinalOutput) {
			if (mandatoryCountExcel == mandatoryObjectCount) {
				ObjectCountStatus = true;
			}
		}
		return ObjectCountStatus;
	}

	private int getFinalOutputMandatoryObjectCount() {
		int count = 0;
		Session session = this.hibernateTemplate.getSessionFactory().openSession();
		Query q = session.createSQLQuery(
				"select * from final_output where operation_code=11 or operation_code=12 or operation_code=13 or operation_code=16");
		List Query_list = q.list();
		count = Query_list.size();
		return count;
	}

	///

	private boolean checkTransP(List<HanaProfile> hanaExcelData) {
		boolean ckeckTransPStatus = true;

		for (int i = 0; i < hanaExcelData.size(); i++) {
			HanaProfile hanaExcelObject = (HanaProfile) hanaExcelData.get(i);

			if (hanaExcelObject.getOperation_code().equals("16")) {
				if (hanaExcelObject.getTable_Type().equalsIgnoreCase("TRANSP")) {
					ckeckTransPStatus = false;
					break;
				}
			}
		}
		return ckeckTransPStatus;
	}

	///

	private boolean checkSubTypeForNA(List finalOutputList) {
		boolean naCheckStatus = true;
		logger.info("Checking for sub-type NA::---");
		for (int i = 0; i < finalOutputList.size(); i++) {
			HanaProfile finalOutputRow = (HanaProfile) finalOutputList;
			if ("NA".equalsIgnoreCase(finalOutputRow.getSub_Type())
					|| "N/A".equalsIgnoreCase(finalOutputRow.getSub_Type())) {
				naCheckStatus = false;
				break;
			}

		}
		return naCheckStatus;
	}

	///

	private boolean checkUsedUnused(List finalOutputList) {
		boolean usedUnusedStatus = true;
		for (int i = 0; i < finalOutputList.size(); i++) {
			HanaProfile finalOutputRow = (HanaProfile) finalOutputList;
			String objectType = finalOutputRow.getObject_Type();
			if (objectType.equalsIgnoreCase("CLAS")) {
				String usedUnused = finalOutputRow.getUsed_Unused();
				/*
				 * String dialogSteps = finalOutputRow.getDialog_Steps(); if
				 * (!(usedUnused.equals("") && dialogSteps.equals(""))) { usedUnusedStatus =
				 * false; break; }
				 */
			}

		}
		return usedUnusedStatus;
	}

	////

	private boolean checkUnwantedCategory() {
		long requestId = this.getRequestId();
		boolean unwantedCategoryStatus = true;
		int count = 0;
		Session session = this.hibernateTemplate.getSessionFactory().openSession();
		Query q = session.createSQLQuery("select * from final_output where request_id=" + requestId
				+ "and ( join_type like '|%' or join_type like '%|' or table_type like '|%' or table_type like '%|')");
		List Query_list = q.list();
		count = Query_list.size();
		if (count != 0) {
			unwantedCategoryStatus = false;

		}
		return unwantedCategoryStatus;
	}

	////

	private boolean checkForDuplicates() {
		boolean duplicateStatus = false;
		int countObject = 0;
		int countDistinctObject = 0;
		Session session = this.hibernateTemplate.getSessionFactory().openSession();
		Query q1 = session.createSQLQuery("select count(distinct obj_name)  from final_output");
		Query q2 = session.createSQLQuery("select count(obj_name) from final_output");
		List Query_list1 = q1.list();
		List Query_list2 = q2.list();
		countObject = Query_list1.size();
		countDistinctObject = Query_list2.size();
		if (countObject == countDistinctObject) {
			duplicateStatus = true;
		}
		return duplicateStatus;
	}

	////

	public boolean verifySheet() {

		boolean status = false;

		try {

			List<HanaProfile> finalOutputList = this.getFinalOutputTableData();
			List<HanaProfile> hanaListExcel = this.getHanaProfilerExcelData();

			status = checkConcatenatedStringFromExcelandDB(hanaListExcel);// concatenating
																			// OBJ_NAME
																			// ,
																			// SUB-PROGRAM
																			// ,
																			// LINE
																			// NO.
																			// ,
																			// OP-CODE
																			// from
																			// excel
																			// hana
																			// Profiler
																			// and
																			// Final
																			// Output
																			// Table
			status = checkObjectCount(hanaListExcel);// checking the count of
														// the objects in hana
														// profiler excel file
														// and Final _output
														// table excluding
														// operation code
														// 99,20,45 and 46 and
														// also matching the
														// count of mandatory
														// objects(11, 12, 13
														// ,15,16,17) in both.
			status = checkTransP(hanaListExcel);// For op_code 16 check for
												// table type enteries, there
												// should not be single TRANSP
												// category
			status = checkSubTypeForNA(finalOutputList); // Sub-type should not
															// be N/A
			status = checkUsedUnused(finalOutputList); // For object type 'CLAS'
														// used/unused & dialog
														// steps should be
														// blank.
			status = checkUnwantedCategory();// Check whether unwanted entries
												// has been removed from table
												// type,join type.
			status = checkForDuplicates();// Check for duplicate entries.

		} catch (Exception e) {
			logger.error("Exception in Verify Output:: " + e);
		}

		return status;
	}

}
