package com.act.bw.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="RSBKDTP ")
public class Rsbkdtp {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column(name = "Id")
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	private String dtp;
	private Long requestId;

	@Column(name = "Request_Id")
	public Long getRequestId() {
		return requestId;
	}
	public void setRequestId(Long requestId) {
		this.requestId = requestId;
	}
	@Column(name = "dtp")
	public String getDtp() {
		return dtp;
	}

	public void setDtp(String dtp) {
		this.dtp = dtp;
	}
	
	private String objectType;
	
	@Column(name = "object_Type")
	public String getObjectType() {
		return objectType;
	}
	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}
}
