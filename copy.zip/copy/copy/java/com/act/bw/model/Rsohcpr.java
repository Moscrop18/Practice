package com.act.bw.model;

public class Rsohcpr {

	public String getHcprnm() {
		return hcprnm;
	}
	public void setHcprnm(String hcprnm) {
		this.hcprnm = hcprnm;
	}
	public String getObjType() {
		return objType;
	}
	public void setObjType(String objType) {
		this.objType = objType;
	}
	public String getObjStatus() {
		return objStatus;
	}
	public void setObjStatus(String objStatus) {
		this.objStatus = objStatus;
	}
	public Long getRequestId() {
		return requestId;
	}
	public void setRequestId(Long requestId) {
		this.requestId = requestId;
	}
	private String hcprnm;
	private String objType;
	private String objStatus;
	private Long requestId;
}
