package com.act.bw.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="Web_template3")
public class WebTemplate3 {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column(name = "Id")
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	@Column(name = "TCTOBJNM")
	private String tctObjNm;
	
	@Column(name = "TCTTIMSTMP", columnDefinition="DATETIME")
	@Temporal(TemporalType.TIMESTAMP)
	private Date tctTimStmp;
	
	@Column(name = "Request_Id")
	private Long requestID;
	
	@Column(name = "obj_status")
	private String objStatus;
	
	public String getObjStatus() {
		return objStatus;
	}
	public void setObjStatus(String objStatus) {
		this.objStatus = objStatus;
	}

	public String getTctObjNm() {
		return tctObjNm;
	}
	public void setTctObjNm(String tctObjNm) {
		this.tctObjNm = tctObjNm;
	}
	public Date getTctTimStmp() {
		return tctTimStmp;
	}
	public void setTctTimStmp(Date tctTimStmp) {
		this.tctTimStmp = tctTimStmp;
	}
	public Long getRequestID() {
		return requestID;
	}
	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}
	@Column(name = "object_Type")
	private String objectType;
	
	public String getObjectType() {
		return objectType;
	}
	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}
}
