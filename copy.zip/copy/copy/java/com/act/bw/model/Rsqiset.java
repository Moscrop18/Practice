package com.act.bw.model;

public class Rsqiset {

	private String infoSet;
	private String objType;
	private String objStatus;
	private Long requestId;
	public String getInfoSet() {
		return infoSet;
	}
	public void setInfoSet(String infoSet) {
		this.infoSet = infoSet;
	}
	public String getObjType() {
		return objType;
	}
	public void setObjType(String objType) {
		this.objType = objType;
	}
	public String getObjStatus() {
		return objStatus;
	}
	public void setObjStatus(String objStatus) {
		this.objStatus = objStatus;
	}
	public Long getRequestId() {
		return requestId;
	}
	public void setRequestId(Long requestId) {
		this.requestId = requestId;
	}
}
