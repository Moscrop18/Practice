package com.act.bw.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="RSBKREQUEST")
public class Rsbkrequest {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column(name = "Id")
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	private String tgttp;
	private String tgt;
	private String dtp;
	private String src;
	private Date tstmpStart;
	private long requestId;
	
	@Column(name = "RequestId")
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	
	@Column(name = "tgt")
	public String getTgt() {
		return tgt;
	}
	public void setTgt(String tgt) {
		this.tgt = tgt;
	}
	
	@Column(name = "tstmp_start", columnDefinition="DATETIME")
	@Temporal(TemporalType.TIMESTAMP)
	public Date getTstmpStart() {
		return tstmpStart;
	}
	public void setTstmpStart(Date tstmpStart) {
		this.tstmpStart = tstmpStart;
	}

	@Column(name = "tgttp")
	public String getTgttp() {
		return tgttp;
	}
	public void setTgttp(String tgttp) {
		this.tgttp = tgttp;
	}
	
	@Column(name = "dtp")
	public String getDtp() {
		return dtp;
	}
	public void setDtp(String dtp) {
		this.dtp = dtp;
	}
	
	@Column(name = "src")
	public String getSrc() {
		return src;
	}
	public void setSrc(String src) {
		this.src = src;
	}
}
