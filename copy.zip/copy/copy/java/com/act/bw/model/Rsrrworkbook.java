package com.act.bw.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="RSRRWORKBOOK ")
public class Rsrrworkbook {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column(name = "Id")
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	@Column(name = "workbook_id")
	private String workbookId;
	
	@Column(name = "genuine_id")
	private String genuineId;
	
	@Column(name = "Request_Id")
	private Long requestID;
	
	@Column(name = "object_Type")
	private String objType;

	public String getWorkbookId() {
		return workbookId;
	}
	public void setWorkbookId(String workbookId) {
		this.workbookId = workbookId;
	}
	public String getGenuineId() {
		return genuineId;
	}
	public void setGenuineId(String genuineId) {
		this.genuineId = genuineId;
	}
	public Long getRequestID() {
		return requestID;
	}
	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}
	public String getObjType() {
		return objType;
	}
	public void setObjType(String objType) {
		this.objType = objType;
	}
}
