package com.act.bw.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name="BW_Inventory_Download")
public class BwInventoryDownload {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ID")
	private int id;
	
	@Column(name="Obj_Type")
	private String objType;
	
	@Column(name="Obj_Name")
	private String objName;
	
	@Column(name="Package")
	private String pckg;
	
	@Column(name="Profiler_Used")
	private String profilersUsed;
	
	public String getProfilersUsed() {
		return profilersUsed;
	}

	public void setProfilersUsed(String profilersUsed) {
		this.profilersUsed = profilersUsed;
	}

	public String getPckg() {
		return pckg;
	}

	public void setPckg(String pckg) {
		this.pckg = pckg;
	}

	@Column(name="REQUEST_ID")
	@Index(name="Index_Request_id")
	private long requestID;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getObjType() {
		return objType;
	}

	public void setObjType(String objType) {
		this.objType = objType;
	}

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}

	public long getRequestID() {
		return requestID;
	}

	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}
}
