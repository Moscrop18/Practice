package com.act.bw.model;

public class Rsts {
	public String getObjType() {
		return objType;
	}
	public void setObjType(String objType) {
		this.objType = objType;
	}
	public String getObjStatus() {
		return objStatus;
	}
	public void setObjStatus(String objStatus) {
		this.objStatus = objStatus;
	}
	public Long getRequestId() {
		return requestId;
	}
	public void setRequestId(Long requestId) {
		this.requestId = requestId;
	}
	private String transtru;
	public String getTranstru() {
		return transtru;
	}
	public void setTranstru(String transtru) {
		this.transtru = transtru;
	}
	public String getLogsys() {
		return logsys;
	}
	public void setLogsys(String logsys) {
		this.logsys = logsys;
	}
	private String logsys;
	private String objType;
	private String objStatus;
	private Long requestId;
}
