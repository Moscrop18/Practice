package com.act.bw.model;

public class Rsdiobj {

	private String iobjnm;
	private Long requestId;
	private String objStatus;
	private String objType;
	public String getObjType() {
		return objType;
	}
	public void setObjType(String objType) {
		this.objType = objType;
	}
	public String getObjStatus() {
		return objStatus;
	}
	public void setObjStatus(String objStatus) {
		this.objStatus = objStatus;
	}
	public String getIobjnm() {
		return iobjnm;
	}
	public void setIobjnm(String iobjnm) {
		this.iobjnm = iobjnm;
	}
	public Long getRequestId() {
		return requestId;
	}
	public void setRequestId(Long requestId) {
		this.requestId = requestId;
	}
	
}
