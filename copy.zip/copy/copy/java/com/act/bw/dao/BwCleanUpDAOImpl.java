package com.act.bw.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.act.S4.models.Unicode;
import com.act.bw.model.BwFinalOutput;
import com.act.bw.model.BwInventoryList;
import com.act.bw.model.BwObjectTypeDateFormat;
import com.act.bw.model.RsantProcess;
import com.act.bw.model.RsantProcessr;
import com.act.bw.model.Rsbkdtp;
import com.act.bw.model.Rsbkdtpstat;
import com.act.bw.model.Rsbkrequest;
import com.act.bw.model.Rsbohdest;
import com.act.bw.model.Rsdcube;
import com.act.bw.model.Rsdiobj;
import com.act.bw.model.Rsds;
import com.act.bw.model.Rsiccont;
import com.act.bw.model.Rsldpio;
import com.act.bw.model.Rsohcpr;
import com.act.bw.model.Rspcchain;
import com.act.bw.model.Rspcchainattr;
import com.act.bw.model.Rspcprocesslog;
import com.act.bw.model.Rsqiset;
import com.act.bw.model.Rsrrepdir;
import com.act.bw.model.Rsrrworkbook;
import com.act.bw.model.Rsrwbindex;
import com.act.bw.model.Rstran;
import com.act.bw.model.Rsts;
import com.act.bw.model.Rsupdinfo;
import com.act.bw.model.Rszwbtmphead;
import com.act.bw.model.Rszwtemplate;
import com.act.bw.model.WebTemplate3;
import com.act.bw.model.WebTemplate7;
import com.act.client.model.RequestInventory;
import com.act.constant.Hana_Profiler_Constant;
import com.act.displaygrid.model.DBConfig;
import com.act.exceptions.HibernateException;
import com.act.reader.xlsx.St03ReaderXlsx;

@Repository
public class BwCleanUpDAOImpl implements BwCleanUpDAO {
	final static Logger logger = LoggerFactory.getLogger(BwCleanUpDAOImpl.class);

	@Autowired
	private St03ReaderXlsx sto3ReaderXlsx;
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public String batchInsertionForRsiccont(List<Rsiccont> rsiccontList, HttpSession session) throws SQLException {

		logger.debug(":: batchInsertionForRsiccont() Start :: ");

		final String INSERT_SQL = "INSERT INTO RSICCONT (icube,timeStamp,requestId,object_Type) values (?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		// deleteSiaTableData(session, "Src_Usobtc");
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (Rsiccont rsiccont : rsiccontList) {
					stmt.setString(1, rsiccont.getIcube());
					stmt.setTimestamp(2, (Timestamp) rsiccont.getTimeStamp());
					stmt.setLong(3, rsiccont.getRequestId());
					stmt.setString(4, rsiccont.getObjectType());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("Rsiccont Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error("Error in batchInsertionForRsiccont - ", e);
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error("Error in batchInsertionForRsiccont - ", e);

		} finally {
			stmt.close();
			conn.close();
		}
		logger.debug(":: batchInsertionForRsiccont() End :: ");
		return result;

	}

	@Override
	public String batchInsertionForRsantProcessr(List<RsantProcessr> rsantProcessrList, HttpSession session)
			throws SQLException {

		logger.debug(":: batchInsertionForRsantProcessr() Start :: ");

		final String INSERT_SQL = "INSERT INTO RSANT_PROCESSR (process,startTime,requestId,object_Type) values (?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		// deleteSiaTableData(session, "Src_Usobtc");
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (RsantProcessr rsantProcessr : rsantProcessrList) {
					stmt.setString(1, rsantProcessr.getProcess());
					stmt.setTimestamp(2, (Timestamp) rsantProcessr.getStartTime());
					stmt.setLong(3, rsantProcessr.getRequestId());
					stmt.setString(4, rsantProcessr.getObjectType());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("RsantProcessr Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error("Error in batchInsertionForRsantProcessr - ", e);
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error("Error in batchInsertionForRsantProcessr - ", e);

		} finally {
			stmt.close();
			conn.close();
		}
		logger.debug(":: batchInsertionForRsantProcessr() End :: ");
		return result;

	}

	@Override
	public String batchInsertionForRsbkrequest(List<Rsbkrequest> rsbkrequestList, HttpSession session)
			throws SQLException {

		logger.debug(":: batchInsertionForRsbkrequest() Start :: ");

		final String INSERT_SQL = "INSERT INTO RSBKREQUEST (tgt, tstmpStart, requestId, dtp, src, tgttp) "
				+ "values (?, ?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		
		try {
			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (Rsbkrequest rsbkrequest : rsbkrequestList) {
					stmt.setString(1, rsbkrequest.getTgt());
					stmt.setTimestamp(2, (Timestamp) rsbkrequest.getTstmpStart());
					stmt.setLong(3, rsbkrequest.getRequestId());
					stmt.setString(4, rsbkrequest.getDtp());
					stmt.setString(5, rsbkrequest.getSrc());
					stmt.setString(6,  rsbkrequest.getTgttp());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("Rsbkrequest Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error("Error in batchInsertionForRsbkrequest - ", e);
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error("Error in batchInsertionForRsbkrequest - ", e);
		} finally {
			stmt.close();
			conn.close();
		}
		
		logger.debug(":: batchInsertionForRsbkrequest() End :: ");
		return result;
	}

	@Override
	public String batchInsertionForRsrrepdir(List<Rsrrepdir> rsrrepdirList, HttpSession session) throws SQLException {

		logger.debug(":: batchInsertionForRsrrepdir() Start :: ");

		final String INSERT_SQL = "INSERT INTO RSRREPDIR (repTime,compId,requestId,object_Type,genuineId,objStatus) values (?, ?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		// deleteSiaTableData(session, "Src_Usobtc");
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (Rsrrepdir rsrrepdir : rsrrepdirList) {
					stmt.setTimestamp(1, (Timestamp) rsrrepdir.getRepTime());
					stmt.setString(2, rsrrepdir.getCompId());
					stmt.setLong(3, rsrrepdir.getRequestId());
					stmt.setString(4, rsrrepdir.getObjectType());
					stmt.setString(5, rsrrepdir.getGenuineId());
					stmt.setString(6, rsrrepdir.getObjStatus());
					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("Rsrrepdir Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error("Error in batchInsertionForRsrrepdir - ", e);
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error("Error in batchInsertionForRsrrepdir - ", e);

		} finally {
			stmt.close();
			conn.close();
		}
		logger.debug(":: batchInsertionForRsrrepdir() End :: ");
		return result;

	}

	@Override
	public String batchInsertionForRsbkdtp(List<Rsbkdtp> rsbkdtpList, HttpSession session) throws SQLException {
		logger.debug(":: batchInsertionForRsbkdtp() Start :: ");

		final String INSERT_SQL = "INSERT INTO RSBKDTP (dtp,requestId,objectType) values (?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (Rsbkdtp rsbkdtp : rsbkdtpList) {
					stmt.setString(1, rsbkdtp.getDtp());
					stmt.setLong(2, rsbkdtp.getRequestId());
					stmt.setString(3, rsbkdtp.getObjectType());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("Rsbkdtp Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error("Error in batchInsertionForRsbkdtp - ", e);
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error("Error in batchInsertionForRsbkdtp - ", e);

		} finally {
			stmt.close();
			conn.close();
		}
		logger.debug(":: batchInsertionForRsbkdtp() End :: ");
		return result;

	}

	@Override
	public String batchInsertionForRsbkdtpstat(List<Rsbkdtpstat> rsbkdtpstatList, HttpSession session)
			throws SQLException {
		logger.debug(":: batchInsertionForRsbkdtpstat() Start :: ");

		final String INSERT_SQL = "INSERT INTO RSBKDTPSTAT (dtp,objStat,requestId,objectType) values (?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (Rsbkdtpstat rsbkdtpstat : rsbkdtpstatList) {
					stmt.setString(1, rsbkdtpstat.getDtp());
					stmt.setString(2, rsbkdtpstat.getObjStat());
					stmt.setLong(3, rsbkdtpstat.getRequestId());
					stmt.setString(4, rsbkdtpstat.getObjectType());
					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("Rsbkdtpstat Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error("Error in batchInsertionForRsbkdtpstat - ", e);
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error("Error in batchInsertionForRsbkdtpstat - ", e);

		} finally {
			stmt.close();
			conn.close();
		}
		logger.debug(":: batchInsertionForRsbkdtpstat() End :: ");
		return result;
	}

	@Override
	public String batchInsertionForRstran(List<Rstran> rstranList, HttpSession session) throws SQLException {
		logger.debug(":: batchInsertionForRstran() Start :: ");

		final String INSERT_SQL = "INSERT INTO RSTRAN (transId, requestId, object_Type, source, target, objStat) "
				+ "values (?, ?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		// deleteSiaTableData(session, "Src_Usobtc");
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (Rstran rstran : rstranList) {
					stmt.setString(1, rstran.getTransId());
					stmt.setLong(2, rstran.getRequestId());
					stmt.setString(3, rstran.getObjectType());
					stmt.setString(4, rstran.getSource());
					stmt.setString(5, rstran.getTarget());
					stmt.setString(6, rstran.getObjStat());
					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("Rstran Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error("Error in batchInsertionForRstran - ", e);
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error("Error in batchInsertionForRstran - ", e);

		} finally {
			stmt.close();
			conn.close();
		}
		logger.debug(":: batchInsertionForRstran() End :: ");
		return result;
	}

	@Override
	public String batchInsertionForRspcprocesslog(List<Rspcprocesslog> rspcprocesslogList, HttpSession session)
			throws SQLException {
		logger.debug(":: batchInsertionForRspcprocesslog() Start :: ");

		final String INSERT_SQL = "INSERT INTO RSPCPROCESSLOG (variante,strtTimeStamp,requestId,object_Type) values (?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		// deleteSiaTableData(session, "Src_Usobtc");
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (Rspcprocesslog rspcprocesslog : rspcprocesslogList) {
					stmt.setString(1, rspcprocesslog.getVariante());
					stmt.setTimestamp(2, (Timestamp) rspcprocesslog.getStrtTimeStamp());
					stmt.setLong(3, rspcprocesslog.getRequestId());
					stmt.setString(4, rspcprocesslog.getObjectType());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("Rspcprocesslog Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error("Error in batchInsertionForRspcprocesslog - ", e);
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error("Error in batchInsertionForRspcprocesslog - ", e);

		} finally {
			stmt.close();
			conn.close();
		}
		logger.debug(":: batchInsertionForRspcprocesslog() End :: ");
		return result;
	}

	@Override
	public void getBwObjectCleanUpRecords(HttpSession session, String inputTbl, String finalTbl, String timCol,
			String objNameCol, String reqIdColname) throws SQLException {
		logger.info("getBwObjectCleanUpRecords Start :: " + inputTbl);
		java.sql.Connection conn = null;
		java.sql.Statement stmt = null;
		conn = DBConfig.getJDBCConnection(session);
		conn.setAutoCommit(false);
		stmt = conn.createStatement();

		StringBuilder qStr = new StringBuilder(
				"create temporary table use_temp_tbl SELECT object_Type, " + objNameCol + ", " + reqIdColname + ", max("
						+ timCol + ") as " + timCol + " from " + inputTbl + " group by " + objNameCol);

		stmt.executeUpdate(qStr.toString());

		StringBuilder iStr = new StringBuilder(
				"insert into BW_FINAL_OUTPUT (obj_Type,obj_name,years,last_used,Request_Id,obj_stat) select object_Type,"
						+ objNameCol + ",ROUND((DATEDIFF(SYSDATE()," + timCol + ") / 365.25), 3) as timInYr," + timCol
						+ "," + reqIdColname
						+ ",'ACTIVE' from use_temp_tbl order by object_Type, cast(timInYr as Decimal(6,2)) desc");
		stmt.executeUpdate(iStr.toString());

		StringBuilder dStr = new StringBuilder("DROP TEMPORARY TABLE use_temp_tbl");
		stmt.executeUpdate(dStr.toString());
		conn.commit();
		logger.info("getBwObjectCleanUpRecords End :: ");
	}
	
	/*
	 * Method - To get the counts of OHD/Transformation/DTPs- Active
	 */
	@Override
	public void getBWObjectsRSBKRequest(HttpSession session, String inputTbl, String finalTbl, String timCol,
			String objNameCol, String reqIdColname) throws SQLException {
		logger.info("getBwObjectCleanUpRecords Start -- ODH/DTP/Transformation :: " + inputTbl);
		
		java.sql.Connection conn = null;
		java.sql.Statement stmt = null;
		conn = DBConfig.getJDBCConnection(session);
		conn.setAutoCommit(false);
		stmt = conn.createStatement();

		String qStr = "";
		if(objNameCol.equalsIgnoreCase("DTP")) 
			qStr = "create temporary table use_temp_tbl SELECT 'DTPs' as object_Type, " + objNameCol + ", " + reqIdColname + ", max("
							+ timCol + ") as " + timCol + " from " + inputTbl + " group by " + objNameCol;
		
		else if(objNameCol.equalsIgnoreCase("TGT"))
			qStr = "create temporary table use_temp_tbl SELECT 'OHD' as object_Type, " + objNameCol + ", " + reqIdColname + ", max("
							+ timCol + ") as " + timCol + " from " + inputTbl + " where tgttp='DEST' group by " + objNameCol;
		
		else if(objNameCol.equalsIgnoreCase("TRANSID"))
			qStr = "create temporary table use_temp_tbl SELECT object_Type, " + objNameCol + ", tran." + reqIdColname + ", max("
						+ timCol + ") as " + timCol + " from " + inputTbl + " as rbkreq inner join rstran as tran on rbkreq.src=tran.source"
								+ " and rbkreq.tgt=tran.target where tran.objStat='ACT' group by " + objNameCol;
		
		stmt.executeUpdate(qStr);

		StringBuilder iStr = new StringBuilder(
				"insert into BW_FINAL_OUTPUT (obj_Type,obj_name,years,last_used,Request_Id,obj_stat) select object_Type,"
						+ objNameCol + ",ROUND((DATEDIFF(SYSDATE()," + timCol + ") / 365.25), 3) as timInYr," + timCol
						+ "," + reqIdColname
						+ ",'ACTIVE' from use_temp_tbl order by object_Type, cast(timInYr as Decimal(6,2)) desc");
		stmt.executeUpdate(iStr.toString());

		StringBuilder dStr = new StringBuilder("DROP TEMPORARY TABLE use_temp_tbl");
		stmt.executeUpdate(dStr.toString());
		conn.commit();
		logger.info("getBwObjectCleanUpRecords End :: ");
	}

	private java.sql.Statement updateTimeFieldForIncObjects(String inputTbl, String timCol, java.sql.Connection conn)
			throws SQLException {
		java.sql.Statement stmt;
		StringBuilder upStr = new StringBuilder(
				"update " + inputTbl + " set " + timCol + "=0 where objStatus='INACTIVE'");
		stmt = conn.createStatement();
		stmt.executeUpdate(upStr.toString());
		return stmt;
	}

	@Override
	public void getBwObjectInYears(HttpSession session, Long requestId) throws SQLException {
		logger.info("getBwObjectInYears started ::");
		try {
			getBwObjectCleanUpRecords(session, "RSANT_PROCESSR", "BW_FINAL_OUTPUT", "startTime", "process","requestId");// APD
			loadInactiveObjectsIntoFinalBwTbl("Analysis_Process_Designer", session);
			getBWObjectsRSBKRequest(session, "RSBKREQUEST", "BW_FINAL_OUTPUT", "tstmpStart", "tgt", "requestId");// ODH
			loadInactiveObjectsIntoFinalBwTbl("Open_Hub_Destination", session);// ODH INA
			getBwObjectCleanUpRecords(session, "RSRREPDIR", "BW_FINAL_OUTPUT", "repTime", "compId", "requestId");// BEX
			loadInactiveObjectsIntoFinalBwTbl("BEx_Queries", session);// BEX INA
			getBwObjectCleanUpRecords(session, "RSICCONT", "BW_FINAL_OUTPUT", "timeStamp", "icube", "requestId");// DSO/Infocube
			loadInactiveObjectsIntoFinalBwTbl("InfoCube", session);// DSO INFOCUBE INA
			loadInactiveObjectsIntoFinalBwTbl("MultiProvider", session);// Multiprovider
			getBwObjectCleanUpRecords(session, "Web_template7", "BW_FINAL_OUTPUT", "TCTTIMSTMP", "TCTOBJNM","Request_Id");
			getBwObjectCleanUpRecords(session, "Web_template3", "BW_FINAL_OUTPUT", "TCTTIMSTMP", "TCTOBJNM","Request_Id");
			getRspchainObjects(session, "RSPCHAIN_Intermidiate", "strt_time_stmp", "variante", "BW_FINAL_OUTPUT",requestId);
			loadInactiveObjectsIntoFinalBwTbl("Process_Chains", session);
			getWorkbookObjects(session, "BW_FINAL_OUTPUT", requestId);// check this
			loadInactiveObjectsIntoFinalBwTbl("BEx_Work_Books", session);
			getBWObjectsRSBKRequest(session, "RSBKREQUEST", "BW_FINAL_OUTPUT", "tstmpStart", "dtp", "requestId"); //DTP-Active
			getDtpObjects(session, requestId); //DTP-Inactive
			getBWObjectsRSBKRequest(session, "RSBKREQUEST", "BW_FINAL_OUTPUT", "tstmpStart", "transid", "requestId");
			insertTransformationObjectInFinalTable(session); //Transformation-Inactive
			loadInactiveObjectsIntoFinalBwTbl("InfoObject", session);
			loadInactiveObjectsIntoFinalBwTbl("InfoSet", session);
			loadInactiveObjectsIntoFinalBwTbl("Update_rules", session);
			loadInactiveObjectsIntoFinalBwTbl("Transfer_Structure", session);
			loadInactiveObjectsIntoFinalBwTbl("Datasources(7.X)", session);
			loadInactiveObjectsIntoFinalBwTbl("Infopackages", session);
			loadInactiveObjectsIntoFinalBwTbl("Web_Application_Design(7.x)", session);
			loadInactiveObjectsIntoFinalBwTbl("Web_Application_Design(3.x)", session);
			loadInactiveObjectsIntoFinalBwTbl("Infopackages", session);

			clearInterAndFinaltablesAfterProcess(requestId, session);
		} catch (Exception e) {
			logger.error("Error in getBwObjectInYears :: ", e);
			throw e;
		}
		logger.info("getBwObjectInYears End ::");
	}

	public void getDtpObjects(HttpSession session, Long requestId) throws SQLException {
		logger.info("getDtpObjects Started :::: ");
		java.sql.Connection conn = null;

		conn = DBConfig.getJDBCConnection(session);
		java.sql.Statement stmt2 = conn.createStatement();
		try {
			conn.setAutoCommit(false);

			StringBuilder iqry = new StringBuilder(
					"insert into RSBKDTP_Intermidiate (dtp,object_type,dtp_status,Request_Id) select dtp,objectType,objStat,requestId from RSBKDTPSTAT where dtp in (select distinct dtp from RSBKDTP) and objStat='INA'");
			logger.info("query dtp :::: " + iqry);
			stmt2.executeUpdate(iqry.toString());
			conn.commit();
			insertDtpObjectInFinalTable(session);

		} catch (SQLException e) {
			logger.error("ERROR in getDtpObjects :: ", e);
			throw e;
		} finally {
			conn.close();
			stmt2.close();
		}
		logger.info("getDtpObjects End :::: ");
	}

	public void insertDtpObjectInFinalTable(HttpSession session) throws SQLException {
		logger.info("insertDtpObjectInFinalTable started ::");
		java.sql.Connection conn = null;
		java.sql.Statement stmt = null;
		conn = DBConfig.getJDBCConnection(session);
		try {
			conn.setAutoCommit(false);
			stmt = conn.createStatement();
			StringBuilder iStr = new StringBuilder(
					"insert into BW_FINAL_OUTPUT (obj_Type,obj_name,obj_stat,Request_Id) select object_Type,Dtp,dtp_status,Request_Id from RSBKDTP_Intermidiate ");
			stmt.executeUpdate(iStr.toString());
		} catch (Exception e) {
			logger.error("ERROR in insertDtpObjectInFinalTable :: ", e);
		} finally {
			conn.commit();
		}
		logger.info("insertDtpObjectInFinalTable End ::");
	}

	public void insertTransformationObjectInFinalTable(HttpSession session) throws SQLException {
		logger.info("insertTransformationObjectInFinalTable Start ::");
		java.sql.Connection conn = null;
		java.sql.Statement stmt = null;
		conn = DBConfig.getJDBCConnection(session);
		try {
			conn.setAutoCommit(false);
			stmt = conn.createStatement();
			StringBuilder iStr = new StringBuilder(
					"insert into BW_FINAL_OUTPUT (obj_Type,obj_name,obj_stat,Request_Id) select object_Type,transId,'INACTIVE',requestId from RSTRAN where objStat='INA'");
			stmt.executeUpdate(iStr.toString());
		} catch (Exception e) {
			logger.error("Error BWCleanUpDAO insertTransformationObjectInFinalTable " , e);
		} finally {
			conn.commit();
		}
		logger.info("insertTransformationObjectInFinalTable End ::");
	}

	@Override
	public String batchInsertionForWebTemplate3(List<WebTemplate3> webTemplate3List, HttpSession session)
			throws SQLException {
		logger.debug(":: batchInsertionForWebTemplate3() Start :: ");

		final String INSERT_SQL = "INSERT INTO Web_template3 (TCTOBJNM,TCTTIMSTMP,Request_Id,object_Type,obj_status) values (?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		// deleteSiaTableData(session, "Src_Usobtc");
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (WebTemplate3 webTemp3 : webTemplate3List) {
					if (sto3ReaderXlsx.getHm().getWebTemplate3List().contains(webTemp3.getTctObjNm())) {
						stmt.setString(1, webTemp3.getTctObjNm());
						stmt.setTimestamp(2, (Timestamp) webTemp3.getTctTimStmp());
						stmt.setLong(3, webTemp3.getRequestID());
						stmt.setString(4, webTemp3.getObjectType());
						stmt.setString(5, "ACTIVE");

//					if(sto3ReaderXlsx.getHm().getWebTemplate3INAList().contains(webTemp3.getTctObjNm())) {
//						stmt.setString(1, webTemp3.getTctObjNm());
//						stmt.setTimestamp(2, null);
//						stmt.setLong(3, webTemp3.getRequestID());
//						stmt.setString(4, webTemp3.getObjectType());
//						stmt.setString(5, "INACTIVE");
//					}
						// Add statement to batch
						stmt.addBatch();
						counter++;
						// Execute batch of 10000 records
						if (counter % 10000 == 0) {
							counter = 0;
							stmt.executeBatch();
							conn.commit();
							logger.info("Batch " + (batch++) + " executed successfully");

						}
					}
				}
				stmt.executeBatch();
				conn.commit();
				logger.info("WebTemplate3 Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error("Error in batchInsertionForWebTemplate3 - ", e);
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error("Error in batchInsertionForWebTemplate3 - ", e);

		} finally {
			stmt.close();
			conn.close();
		}
		logger.debug(":: batchInsertionForWebTemplate3() End :: ");
		return result;
	}

	@Override
	public String batchInsertionForWebTemplate7(List<WebTemplate7> webTemplate7List, HttpSession session)
			throws SQLException {
		logger.debug(":: batchInsertionForWebTemplate3() Start :: ");

		final String INSERT_SQL = "INSERT INTO Web_template7 (TCTOBJNM,TCTTIMSTMP,Request_Id,object_Type) values (?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		// deleteSiaTableData(session, "Src_Usobtc");
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (WebTemplate7 webTemp7 : webTemplate7List) {
					if (sto3ReaderXlsx.getHm().getWebTemplate7List().contains(webTemp7.getTctObjNm())) {
						stmt.setString(1, webTemp7.getTctObjNm());
						stmt.setTimestamp(2, (Timestamp) webTemp7.getTctTimStmp());
						stmt.setLong(3, webTemp7.getRequestId());
						stmt.setString(4, webTemp7.getObjectType());

						// Add statement to batch
						stmt.addBatch();
						counter++;
						// Execute batch of 10000 records
						if (counter % 10000 == 0) {
							counter = 0;
							stmt.executeBatch();
							conn.commit();
							logger.info("Batch " + (batch++) + " executed successfully");
						}
					}
				}
				stmt.executeBatch();
				conn.commit();
				logger.info("Rspcprocesslog Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error("Error in batchInsertionForWebTemplate3 - ", e);
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error("Error in batchInsertionForWebTemplate3 - ", e);

		} finally {
			stmt.close();
			conn.close();
		}
		logger.debug(":: batchInsertionForWebTemplate3() End :: ");
		return result;
	}

	@Override
	public String batchInsertionForRspcchain(List<Rspcchain> rspcchainList, HttpSession session) throws SQLException {
		logger.debug(":: batchInsertionForRspcchain() Start :: ");

		final String INSERT_SQL = "INSERT INTO RSPCCHAIN (variante,chainId,requestId,object_Type) values (?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		// deleteSiaTableData(session, "Src_Usobtc");
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (Rspcchain rspcchain : rspcchainList) {
					stmt.setString(1, rspcchain.getVariante());
					stmt.setString(2, rspcchain.getChainId());
					stmt.setLong(3, rspcchain.getRequestId());
					stmt.setString(4, rspcchain.getObjectType());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("RSPCHAIN Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error("Error in batchInsertionForRspcchain - ", e);
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error("Error in batchInsertionForRspcchain - ", e);

		} finally {
			stmt.close();
			conn.close();
		}
		logger.debug(":: batchInsertionForRspcprocesslog() End :: ");
		return result;
	}

	/*
	 * public void getRspcchain(HttpSession session) { java.sql.Connection conn =
	 * null; java.sql.Statement stmt = null; conn =
	 * DBConfig.getJDBCConnection(session); conn.setAutoCommit(false); StringBuilder
	 * qStr= new StringBuilder("create temporary table use_temp_tbl SELECT * FROM "
	 * +tbl1+" WHERE REP_TIME IN (SELECT MAX("+col1+") FROM @tableName1 GROUP BY "
	 * +col2+")"); stmt = conn.createStatement();
	 * 
	 * stmt.executeUpdate(qStr.toString());
	 * 
	 * StringBuilder qStr1= new
	 * StringBuilder("select distinct dtp from use_temp_tbl"); stmt =
	 * conn.createStatement();
	 * 
	 * ResultSet rs = stmt.executeQuery(qStr.toString()); String dtpVaConcat = "";
	 * while (rs.next()) { String dtpVal = rs.getString("obj_name");
	 * if(StringUtils.isNotEmpty(dtpVal)) { dtpVaConcat += dtpVal; }
	 * 
	 * }
	 * 
	 * StringBuilder queryStr= new
	 * StringBuilder("select chain_id, from RSPCCHAIN where variante in ("
	 * +dtpVaConcat+") and objStat='INA'"); ResultSet rsDtp =
	 * stmt.executeQuery(qStr.toString()); }
	 */

	/*
	 * public void getWebTemplates(HttpSession session) { java.sql.Connection conn =
	 * null; java.sql.Statement stmt = null; conn =
	 * DBConfig.getJDBCConnection(session); conn.setAutoCommit(false);
	 * //StringBuilder qStr= new
	 * StringBuilder("create temporary table use_temp_tbl SELECT * FROM "
	 * +tbl1+" WHERE REP_TIME IN (SELECT MAX("+col1+") FROM @tableName1 GROUP BY "
	 * +col2+")"); stmt = conn.createStatement();
	 * 
	 * stmt.executeUpdate(qStr.toString());
	 * 
	 * }
	 */
	public void getRspchainObjects(HttpSession session, String inputTbl, String timCol, String objNameCol,
			String finalTbl, Long requestId) throws SQLException {
		logger.info("getRspchainObjects  started ::");
		try {
			java.sql.Connection conn = null;
			java.sql.PreparedStatement prepStmt = null;
			conn = DBConfig.getJDBCConnection(session);
			conn.setAutoCommit(false);

			StringBuilder iStr = new StringBuilder("insert into " + inputTbl
					+ " (chain_id, variante, strt_time_stmp,object_type,Request_Id) select chainId, rs.variante, strtTimeStamp, rs.object_Type, rs.requestId from RSPCCHAIN rs inner join rspcprocesslog t1 on rs.variante = t1.variante where t1.requestId=?"); // this
																																																																	// will
																																																																	// compare
																																																																	// varainte
																																																																	// id
																																																																	// with
																																																																	// rspcprocesslog
																																																																	// and
																																																																	// rspchain
			prepStmt = conn.prepareStatement(iStr.toString());
			prepStmt.setLong(1, requestId);
			prepStmt.executeUpdate();

			StringBuilder qStr = new StringBuilder(
					"create temporary table use_temp_tbl SELECT object_type, MAX(" + timCol + ") as " + timCol + ", "
							+ objNameCol + ", Request_Id FROM " + inputTbl + " GROUP BY " + objNameCol);
			prepStmt = conn.prepareStatement(qStr.toString());
			prepStmt.executeUpdate();

			StringBuilder jStr = new StringBuilder(
					"insert into BW_FINAL_OUTPUT (obj_Type,obj_name,years,last_used,Request_Id,obj_stat) select object_Type, "
							+ objNameCol + ", ROUND((DATEDIFF(SYSDATE()," + timCol + ") / 365.25), 3), " + timCol
							+ ", Request_Id,'ACTIVE' from use_temp_tbl order by 1");
			prepStmt = conn.prepareStatement(jStr.toString());
			prepStmt.executeUpdate();

			StringBuilder dStr = new StringBuilder("DROP TEMPORARY TABLE use_temp_tbl");
			prepStmt = conn.prepareStatement(dStr.toString());
			prepStmt.executeUpdate();
			conn.commit();

		} catch (Exception e) {
			logger.error("Error in getRspchainObjects :: ", e);
			throw e;
		}
		logger.info("getRspchainObjects  End ::");
	}

	// modify this
	public void getWorkbookObjects(HttpSession session, String finalTbl, Long requestId) throws SQLException {
		java.sql.Connection conn = null;
		java.sql.PreparedStatement prepStmt = null;
		conn = DBConfig.getJDBCConnection(session);
		conn.setAutoCommit(false);

		StringBuilder iStr = new StringBuilder(
				"insert into Workbook_Intermediate (genuine_Id,repTime,object_type,Request_Id,workbook_id,objStatus) select genuine_id,repTime,rw.object_Type,Request_Id,rw.workbook_id,'ACTIVE' from RSRREPDIR rr inner join RSRRWORKBOOK rw on rr.genuineId=rw.genuine_id  where rw.Request_Id=? ");// this
																																																																										// rsrrepdir
		prepStmt = conn.prepareStatement(iStr.toString());
		prepStmt.setLong(1, requestId);
		prepStmt.executeUpdate();

		// mergeInactiveObjTypeIntoWorkbookInt(conn);
		// updateTimeFieldForIncObjects("Workbook_Intermediate", "repTime", conn);//This
		// we need to do because if we dont update the inactive fields with zero value
		// then in the next stpe time cal, it omit the inactive entries as the time
		// filed for them is null.

		StringBuilder qStr = new StringBuilder(
				"create temporary table use_temp_tbl SELECT object_Type, workbook_id, MAX(repTime) as repTime, Request_Id FROM Workbook_Intermediate GROUP BY workbook_id");
		prepStmt = conn.prepareStatement(qStr.toString());
		prepStmt.executeUpdate();
		StringBuilder jStr = new StringBuilder(
				"insert into BW_FINAL_OUTPUT (obj_Type,obj_name,years,last_used,Request_Id,obj_stat) select object_Type, workbook_Id,ROUND((DATEDIFF(SYSDATE(),repTime) / 365.25), 3),repTime,Request_Id,'ACTIVE' from use_temp_tbl order by 1");
		prepStmt = conn.prepareStatement(jStr.toString());
		// prepStmt.setString("finalTable", finalTbl);
		prepStmt.executeUpdate();
		StringBuilder dStr = new StringBuilder("DROP TEMPORARY TABLE use_temp_tbl");
		prepStmt = conn.prepareStatement(dStr.toString());
		prepStmt.executeUpdate();
		conn.commit();
	}

	private void mergeInactiveObjTypeIntoWorkbookInt(java.sql.Connection conn) throws SQLException {
		logger.info(":: mergeInactiveObjTypeIntoWorkbookInt() Start :: ");
		java.sql.PreparedStatement prepStmt;
		final String INSERT_SQL = "INSERT INTO Workbook_Intermediate (workbook_id,object_Type,objStatus,Request_Id) values (?, ?, ?, ?)";
		prepStmt = conn.prepareStatement(INSERT_SQL);
		int counter = 1;
		int batch = 1;
		if (!St03ReaderXlsx.getHm().getRsrwbindexList().isEmpty()) {
			List<Rsrwbindex> rsrwbindexList = St03ReaderXlsx.getHm().getRsrwbindexList();
			for (Rsrwbindex rsrwbindex : rsrwbindexList) {
				prepStmt.setString(1, rsrwbindex.getWorkbookId());
				prepStmt.setString(2, rsrwbindex.getObjType());
				prepStmt.setString(3, rsrwbindex.getObjStatus());
				prepStmt.setLong(4, rsrwbindex.getRequestID());

				// Add statement to batch
				prepStmt.addBatch();
				counter++;
				// Execute batch of 10000 records
				if (counter % 10000 == 0) {
					counter = 0;
					prepStmt.executeBatch();
					conn.commit();
					logger.info("Batch " + (batch++) + " executed successfully");
				}
			}
		}
		logger.info(":: mergeInactiveObjTypeIntoWorkbookInt() End :: ");
	}

	@Override
	public String batchInsertionForRsrrworkbook(List<Rsrrworkbook> rsrrworkList, HttpSession session)
			throws SQLException {
		logger.debug(":: batchInsertionForRsrrworkbook() Start :: ");

		final String INSERT_SQL = "INSERT INTO RSRRWORKBOOK (workbook_id,genuine_id,Request_Id,object_Type) values (?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		// deleteSiaTableData(session, "Src_Usobtc");
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (Rsrrworkbook rsrrwork : rsrrworkList) {
					if (sto3ReaderXlsx.getHm().getWorkbookIdList().contains(rsrrwork.getWorkbookId())) {
						stmt.setString(1, rsrrwork.getWorkbookId());
						stmt.setString(2, rsrrwork.getGenuineId());
						stmt.setLong(3, rsrrwork.getRequestID());
						stmt.setString(4, rsrrwork.getObjType());

						// Add statement to batch
						stmt.addBatch();
						counter++;
						// Execute batch of 10000 records
						if (counter % 10000 == 0) {
							counter = 0;
							stmt.executeBatch();
							conn.commit();
							logger.info("Batch " + (batch++) + " executed successfully");
						}
					}
				}
				stmt.executeBatch();
				conn.commit();
				logger.info("RSPCHAIN Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error("Error in batchInsertionForRsrrworkbook - ", e);
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error("Error in batchInsertionForRsrrworkbook - ", e);

		} finally {
			stmt.close();
			conn.close();
		}
		logger.debug(":: batchInsertionForRsrrworkbook() End :: ");
		return result;
	}

	private void clearInterAndFinaltablesAfterProcess(Long requestID, HttpSession session) throws SQLException {
		logger.info("clearInterAndFinaltablesAfterProcess started ::");
		try {
			java.sql.Connection conn = DBConfig.getJDBCConnection(session);
			deleteReportData("RSANT_PROCESSR", requestID, conn, "requestId");
			deleteReportData("RSBKDTP", requestID, conn, "requestId");
			deleteReportData("RSBKDTP_Intermidiate", requestID, conn, "Request_Id");
			deleteReportData("RSBKDTPSTAT", requestID, conn, "requestId");
			deleteReportData("RSBKREQUEST", requestID, conn, "requestId");
			deleteReportData("RSICCONT", requestID, conn, "requestId");
			deleteReportData("RSPCCHAIN", requestID, conn, "requestId");
			deleteReportData("RSPCHAIN_Intermidiate", requestID, conn, "Request_Id");
			deleteReportData("RSPCPROCESSLOG", requestID, conn, "requestId");
			deleteReportData("RSRREPDIR", requestID, conn, "requestId");
			deleteReportData("RSRRWORKBOOK", requestID, conn, "Request_Id");
			deleteReportData("RSTRAN", requestID, conn, "requestId");
			deleteReportData("Web_template3", requestID, conn, "Request_Id");
			deleteReportData("Web_template7", requestID, conn, "Request_Id");
			deleteReportData("Workbook_Intermediate", requestID, conn, "Request_Id");

		} catch (Exception e) {
			logger.error("Error in clearInterAndFinaltablesAfterProcess :: ", e);
			throw e;
		}
		logger.info("clearInterAndFinaltablesAfterProcess started ::");
	}

	private void deleteReportData(String table, Long requestID, java.sql.Connection conn, String rqIdColName)
			throws SQLException {
		String stmt = "delete from " + table + "  where " + rqIdColName + "= ?";
		PreparedStatement stmtData = conn.prepareStatement(stmt);
		stmtData.setLong(1, requestID);
		stmtData.executeUpdate();
		if (!stmtData.isClosed()) {
			stmtData.close();
		}
		logger.info(table + " table data deleted successfully");
	}

	@Override
	public List<BwFinalOutput> getBwCleanUpReport(Integer requestId) {
		Session session = sessionFactory.openSession();

		try {
			final Criteria criteria = session.createCriteria(BwFinalOutput.class);
			criteria.add(Restrictions.eq("requestId", requestId.longValue()));
			return criteria.list();
		} catch (Exception e) {
			logger.error("getBwCleanUpReport :: ", e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if (null != session)
				session.close();
		}
	}

	@Override
	public void getDateFormatForBw(HttpSession session, Long requestId) throws SQLException {
		java.sql.Connection conn = null;
		java.sql.Statement stmt = null;
		try {
			conn = DBConfig.getJDBCConnection(session);
			stmt = conn.createStatement();

			String sql = "select * from BW_Object_Date where requestId=" + requestId + "";
			ResultSet rs = stmt.executeQuery(sql);

			while (rs.next()) {
				sto3ReaderXlsx.getHm().getDateFormatList().put("rsiccont", rs.getString("rsiccont"));
				sto3ReaderXlsx.getHm().getDateFormatList().put("rsantProcessr", rs.getString("rsantProcessr"));
				sto3ReaderXlsx.getHm().getDateFormatList().put("rsbkrequest", rs.getString("rsbkrequest"));
				sto3ReaderXlsx.getHm().getDateFormatList().put("rsrrepdir", rs.getString("rsrrepdir"));
				sto3ReaderXlsx.getHm().getDateFormatList().put("bioapersSod00", rs.getString("bioapersSod00"));
				sto3ReaderXlsx.getHm().getDateFormatList().put("rspcprocesslog", rs.getString("rspcprocesslog"));
			}

		} catch (Exception e) {
			logger.error("getDateFormatForBw :: ", e);
		}
	}

	public String loadInactiveObjectsIntoFinalBwTbl(String functionality, HttpSession session) throws SQLException {
		logger.info(":: loadInactiveObjectsIntoFinalBwTbl() Start :: ");

		final String INSERT_SQL = "INSERT INTO BW_FINAL_OUTPUT (obj_type,obj_name,obj_stat,Request_Id) values (?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				if ("BEx_Work_Books".equalsIgnoreCase(functionality)) {
					List<Rsrwbindex> rsrwLst = St03ReaderXlsx.getHm().getRsrwbindexList();
					if (null != rsrwLst) {
						for (Rsrwbindex rsrw : rsrwLst) {

							stmt.setString(1, rsrw.getObjType());
							stmt.setString(2, rsrw.getWorkbookId());
							stmt.setString(3, rsrw.getObjStatus());
							stmt.setLong(4, rsrw.getRequestID());

							// Add statement to batch
							stmt.addBatch();
							counter++;
							// Execute batch of 10000 records
							if (counter % 10000 == 0) {
								counter = 0;
								stmt.executeBatch();
								conn.commit();
								logger.info("Batch " + (batch++) + " executed successfully");
							}
						}

						stmt.executeBatch();
						conn.commit();
						logger.info(functionality + " Data INSERTED SUCCESSFULLY");
					} else {
						logger.info(functionality + " list is empty");
					}
				} else if ("Process_Chains".equalsIgnoreCase(functionality)) {
					List<Rspcchainattr> rspcLst = St03ReaderXlsx.getHm().getRspcchainattrINAList();
					if (null != rspcLst) {
						for (Rspcchainattr rspc : rspcLst) {

							stmt.setString(1, rspc.getObjectType());
							stmt.setString(2, rspc.getChainId());
							stmt.setString(3, rspc.getObjStatus());
							stmt.setLong(4, rspc.getRequestId());

							// Add statement to batch
							stmt.addBatch();
							counter++;
							// Execute batch of 10000 records
							if (counter % 10000 == 0) {
								counter = 0;
								stmt.executeBatch();
								conn.commit();
								logger.info("Batch " + (batch++) + " executed successfully");
							}
						}

						stmt.executeBatch();
						conn.commit();
						logger.info(functionality + " Data INSERTED SUCCESSFULLY");
					} else {
						logger.info(functionality + " list is empty");
					}
				} else if ("BEx_Queries".equalsIgnoreCase(functionality)) {
					List<Rsrrepdir> rsrrepdirLst = St03ReaderXlsx.getHm().getRsrrepdirINAList();
					if (null != rsrrepdirLst) {
						for (Rsrrepdir rsrrepdir : rsrrepdirLst) {

							stmt.setString(1, rsrrepdir.getObjectType());
							stmt.setString(2, rsrrepdir.getCompId());
							stmt.setString(3, rsrrepdir.getObjStatus());
							stmt.setLong(4, rsrrepdir.getRequestId());

							// Add statement to batch
							stmt.addBatch();
							counter++;
							// Execute batch of 10000 records
							if (counter % 10000 == 0) {
								counter = 0;
								stmt.executeBatch();
								conn.commit();
								logger.info("Batch " + (batch++) + " executed successfully");
							}
						}

						stmt.executeBatch();
						conn.commit();
						logger.info(functionality + " Data INSERTED SUCCESSFULLY");
					} else {
						logger.info(functionality + " list is empty");
					}
				} else if ("Web_Application_Design(3.x)".equalsIgnoreCase(functionality)) {
					List<Rszwtemplate> rszwtmplLst = St03ReaderXlsx.getHm().getWebTemplate3INAList();
					if (null != rszwtmplLst) {
						for (Rszwtemplate rszwtmpl : rszwtmplLst) {

							stmt.setString(1, rszwtmpl.getObjType());
							stmt.setString(2, rszwtmpl.getTmplId());
							stmt.setString(3, rszwtmpl.getObjStatus());
							stmt.setLong(4, rszwtmpl.getRequestId());

							// Add statement to batch
							stmt.addBatch();
							counter++;
							// Execute batch of 10000 records
							if (counter % 10000 == 0) {
								counter = 0;
								stmt.executeBatch();
								conn.commit();
								logger.info("Batch " + (batch++) + " executed successfully");
							}
						}

						stmt.executeBatch();
						conn.commit();
						logger.info(functionality + " Data INSERTED SUCCESSFULLY");
					} else {
						logger.info(functionality + " list is empty");
					}
				} else if ("InfoObject".equalsIgnoreCase(functionality)) {
					List<Rsdiobj> rsdiobjLst = St03ReaderXlsx.getHm().getRsdiobjList();
					if (null != rsdiobjLst) {
						for (Rsdiobj rsdiobj : rsdiobjLst) {

							stmt.setString(1, rsdiobj.getObjType());
							stmt.setString(2, rsdiobj.getIobjnm());
							stmt.setString(3, rsdiobj.getObjStatus());
							stmt.setLong(4, rsdiobj.getRequestId());

							// Add statement to batch
							stmt.addBatch();
							counter++;
							// Execute batch of 10000 records
							if (counter % 10000 == 0) {
								counter = 0;
								stmt.executeBatch();
								conn.commit();
								logger.info("Batch " + (batch++) + " executed successfully");
							}
						}

						stmt.executeBatch();
						conn.commit();
						logger.info(functionality + " Data INSERTED SUCCESSFULLY");
					} else {
						logger.info(functionality + " list is empty");
					}
				} else if ("InfoCube".equalsIgnoreCase(functionality)) {
					List<Rsdcube> rsdcubeInfocubeLst = St03ReaderXlsx.getHm().getRsdcubeInfocubeList();
					if (null != rsdcubeInfocubeLst) {
						for (Rsdcube rsdcubeInfocube : rsdcubeInfocubeLst) {

							stmt.setString(1, rsdcubeInfocube.getObjType());
							stmt.setString(2, rsdcubeInfocube.getInfoCube());
							stmt.setString(3, rsdcubeInfocube.getObjStatus());
							stmt.setLong(4, rsdcubeInfocube.getRequestId());

							// Add statement to batch
							stmt.addBatch();
							counter++;
							// Execute batch of 10000 records
							if (counter % 10000 == 0) {
								counter = 0;
								stmt.executeBatch();
								conn.commit();
								logger.info("Batch " + (batch++) + " executed successfully");
							}
						}

						stmt.executeBatch();
						conn.commit();
						logger.info(functionality + " Data INSERTED SUCCESSFULLY");
					} else {
						logger.info(functionality + " list is empty");
					}
				} else if ("MultiProvider".equalsIgnoreCase(functionality)) {
					List<Rsdcube> rsdcubeMproLst = St03ReaderXlsx.getHm().getRsdcubeMproList();
					if (null != rsdcubeMproLst) {
						for (Rsdcube rsdcubeMpro : rsdcubeMproLst) {

							stmt.setString(1, rsdcubeMpro.getObjType());
							stmt.setString(2, rsdcubeMpro.getMpro());
							stmt.setString(3, rsdcubeMpro.getObjStatus());
							stmt.setLong(4, rsdcubeMpro.getRequestId());

							// Add statement to batch
							stmt.addBatch();
							counter++;
							// Execute batch of 10000 records
							if (counter % 10000 == 0) {
								counter = 0;
								stmt.executeBatch();
								conn.commit();
								logger.info("Batch " + (batch++) + " executed successfully");
							}
						}

						stmt.executeBatch();
						conn.commit();
						logger.info(functionality + " Data INSERTED SUCCESSFULLY");
					} else {
						logger.info(functionality + " list is empty");
					}
				} else if ("InfoSet".equalsIgnoreCase(functionality)) {
					List<Rsqiset> rsqiSetLst = St03ReaderXlsx.getHm().getRsqisetList();
					if (null != rsqiSetLst) {
						for (Rsqiset rsqiSet : rsqiSetLst) {

							stmt.setString(1, rsqiSet.getObjType());
							stmt.setString(2, rsqiSet.getInfoSet());
							stmt.setString(3, rsqiSet.getObjStatus());
							stmt.setLong(4, rsqiSet.getRequestId());

							// Add statement to batch
							stmt.addBatch();
							counter++;
							// Execute batch of 10000 records
							if (counter % 10000 == 0) {
								counter = 0;
								stmt.executeBatch();
								conn.commit();
								logger.info("Batch " + (batch++) + " executed successfully");
							}
						}

						stmt.executeBatch();
						conn.commit();
						logger.info(functionality + " Data INSERTED SUCCESSFULLY");
					} else {
						logger.info(functionality + " list is empty");
					}
				} else if ("Open_Hub_Destination".equalsIgnoreCase(functionality)) {
					List<Rsbohdest> rsbohdestLst = St03ReaderXlsx.getHm().getRsbohDestList();
					if (null != rsbohdestLst) {
						for (Rsbohdest rsbohdest : rsbohdestLst) {

							stmt.setString(1, rsbohdest.getObjType());
							stmt.setString(2, rsbohdest.getOhDest());
							stmt.setString(3, rsbohdest.getObjStatus());
							stmt.setLong(4, rsbohdest.getRequestid());

							// Add statement to batch
							stmt.addBatch();
							counter++;
							// Execute batch of 10000 records
							if (counter % 10000 == 0) {
								counter = 0;
								stmt.executeBatch();
								conn.commit();
								logger.info("Batch " + (batch++) + " executed successfully");
							}
						}

						stmt.executeBatch();
						conn.commit();
						logger.info(functionality + " Data INSERTED SUCCESSFULLY");
					} else {
						logger.info(functionality + " list is empty");
					}
				} else if ("Analysis_Process_Designer".equalsIgnoreCase(functionality)) {
					List<RsantProcess> rsantProcessLst = St03ReaderXlsx.getHm().getRsantprocessList();
					if (null != rsantProcessLst) {
						for (RsantProcess rsantProcess : rsantProcessLst) {

							stmt.setString(1, rsantProcess.getObjType());
							stmt.setString(2, rsantProcess.getProcess());
							stmt.setString(3, rsantProcess.getObjStatus());
							stmt.setLong(4, rsantProcess.getRequestId());

							// Add statement to batch
							stmt.addBatch();
							counter++;
							// Execute batch of 10000 records
							if (counter % 10000 == 0) {
								counter = 0;
								stmt.executeBatch();
								conn.commit();
								logger.info("Batch " + (batch++) + " executed successfully");
							}
						}

						stmt.executeBatch();
						conn.commit();
						logger.info(functionality + " Data INSERTED SUCCESSFULLY");
					} else {
						logger.info(functionality + " list is empty");
					}
				} else if ("HANA_Composite_Provider".equalsIgnoreCase(functionality)) {
					List<Rsohcpr> rsohcprLst = St03ReaderXlsx.getHm().getRsohcprList();
					if (null != rsohcprLst) {
						for (Rsohcpr rsohcpr : rsohcprLst) {

							stmt.setString(1, rsohcpr.getObjType());
							stmt.setString(2, rsohcpr.getHcprnm());
							stmt.setString(3, rsohcpr.getObjStatus());
							stmt.setLong(4, rsohcpr.getRequestId());

							// Add statement to batch
							stmt.addBatch();
							counter++;
							// Execute batch of 10000 records
							if (counter % 10000 == 0) {
								counter = 0;
								stmt.executeBatch();
								conn.commit();
								logger.info("Batch " + (batch++) + " executed successfully");
							}
						}

						stmt.executeBatch();
						conn.commit();
						logger.info(functionality + " Data INSERTED SUCCESSFULLY");
					} else {
						logger.info(functionality + " list is empty");
					}
				} else if ("Update_rules".equalsIgnoreCase(functionality)) {
					List<Rsupdinfo> rsupdInfoLst = St03ReaderXlsx.getHm().getRsupdinfoList();
					if (null != rsupdInfoLst) {
						for (Rsupdinfo rsupdInfo : rsupdInfoLst) {

							stmt.setString(1, rsupdInfo.getObjType());
							stmt.setString(2, rsupdInfo.getUpdid());
							stmt.setString(3, rsupdInfo.getObjStatus());
							stmt.setLong(4, rsupdInfo.getRequestId());

							// Add statement to batch
							stmt.addBatch();
							counter++;
							// Execute batch of 10000 records
							if (counter % 10000 == 0) {
								counter = 0;
								stmt.executeBatch();
								conn.commit();
								logger.info("Batch " + (batch++) + " executed successfully");
							}
						}

						stmt.executeBatch();
						conn.commit();
						logger.info(functionality + " Data INSERTED SUCCESSFULLY");
					} else {
						logger.info(functionality + " list is empty");
					}
				} else if ("Transfer_Structure".equalsIgnoreCase(functionality)) {
					List<Rsts> rstsLst = St03ReaderXlsx.getHm().getRstsList();
					if (null != rstsLst) {
						for (Rsts rsts : rstsLst) {
							String transLogsys = rsts.getTranstru() + "/" + rsts.getLogsys();
							stmt.setString(1, rsts.getObjType());
							stmt.setString(2, transLogsys);
							stmt.setString(3, rsts.getObjStatus());
							stmt.setLong(4, rsts.getRequestId());

							// Add statement to batch
							stmt.addBatch();
							counter++;
							// Execute batch of 10000 records
							if (counter % 10000 == 0) {
								counter = 0;
								stmt.executeBatch();
								conn.commit();
								logger.info("Batch " + (batch++) + " executed successfully");
							}
						}

						stmt.executeBatch();
						conn.commit();
						logger.info(functionality + " Data INSERTED SUCCESSFULLY");
					} else {
						logger.info(functionality + " list is empty");
					}
				}

				else if ("Datasources(7.X)".equalsIgnoreCase(functionality)) {
					List<Rsds> rsdsLst = St03ReaderXlsx.getHm().getRsdsList();
					if (null != rsdsLst) {
						for (Rsds rsds : rsdsLst) {
							stmt.setString(1, rsds.getObjType());
							stmt.setString(2, rsds.getDataSource());
							stmt.setString(3, rsds.getObjStatus());
							stmt.setLong(4, rsds.getRequestId());

							// Add statement to batch
							stmt.addBatch();
							counter++;
							// Execute batch of 10000 records
							if (counter % 10000 == 0) {
								counter = 0;
								stmt.executeBatch();
								conn.commit();
								logger.info("Batch " + (batch++) + " executed successfully");
							}
						}

						stmt.executeBatch();
						conn.commit();
						logger.info(functionality + " Data INSERTED SUCCESSFULLY");
					} else {
						logger.info(functionality + " list is empty");
					}
				}

				else if ("Infopackages".equalsIgnoreCase(functionality)) {
					List<Rsldpio> rsldpioLst = St03ReaderXlsx.getHm().getRsldpioList();
					if (null != rsldpioLst) {
						for (Rsldpio rsldpio : rsldpioLst) {
							stmt.setString(1, rsldpio.getObjType());
							stmt.setString(2, rsldpio.getLogdPid());
							stmt.setString(3, rsldpio.getObjStatus());
							stmt.setLong(4, rsldpio.getRequestId());

							// Add statement to batch
							stmt.addBatch();
							counter++;
							// Execute batch of 10000 records
							if (counter % 10000 == 0) {
								counter = 0;
								stmt.executeBatch();
								conn.commit();
								logger.info("Batch " + (batch++) + " executed successfully");
							}
						}

						stmt.executeBatch();
						conn.commit();
						logger.info(functionality + " Data INSERTED SUCCESSFULLY");
					} else {
						logger.info(functionality + " list is empty");
					}

				} else if ("Web_Application_Design(7.x)".equalsIgnoreCase(functionality)) {
					List<Rszwbtmphead> rszwbTmpLst = St03ReaderXlsx.getHm().getRszwbtmpheadList();
					if (null != rszwbTmpLst) {
						for (Rszwbtmphead rszwbTmp : rszwbTmpLst) {
							stmt.setString(1, rszwbTmp.getObjType());
							stmt.setString(2, rszwbTmp.getObjid());
							stmt.setString(3, rszwbTmp.getObjStatus());
							stmt.setLong(4, rszwbTmp.getRequestId());

							// Add statement to batch
							stmt.addBatch();
							counter++;
							// Execute batch of 10000 records
							if (counter % 10000 == 0) {
								counter = 0;
								stmt.executeBatch();
								conn.commit();
								logger.info("Batch " + (batch++) + " executed successfully");
							}
						}

						stmt.executeBatch();
						conn.commit();
						logger.info(functionality + " Data INSERTED SUCCESSFULLY");
					} else {
						logger.info(functionality + " list is empty");
					}
				}
			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error("Error in loadInactiveObjectsIntoFinalBwTbl - ", e);
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error("Error in loadInactiveObjectsIntoFinalBwTbl - ", e);

		} finally {
			stmt.close();
			conn.close();
		}
		logger.info(":: loadInactiveObjectsIntoFinalBwTbl() End :: ");
		return result;
	}

	@Override
	public BwObjectTypeDateFormat getBwObjectType(Long requestId) {
		try {
			Session session = sessionFactory.openSession();

			BwObjectTypeDateFormat obj = (BwObjectTypeDateFormat) session.get(BwObjectTypeDateFormat.class, requestId);
			return obj;
		} catch (Exception e) {
			logger.error("Error in getBwObjectType :: ",e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	@Override
	public String batchInsertionForBwInventory(List<BwInventoryList> bwInvList, HttpSession session)
			throws SQLException {
		logger.info("batchInsertionForBwInventory start :: ");
		final String INSERT_SQL = "INSERT INTO BW_Inventory_List "
				+ "(Obj_Type, Obj_Name, Package, Profiler_Used, REQUEST_ID) "
				+ "values (?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {
			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;
				for (BwInventoryList bwInv : bwInvList) {			
					stmt.setString(1, bwInv.getObjType());
					stmt.setString(2, bwInv.getObjName());
					stmt.setString(3, bwInv.getPckg());
					stmt.setString(4, bwInv.getProfilersUsed());
					stmt.setLong(5, bwInv.getRequestID());
					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 1000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();

				logger.info("batchInsertionForBwInventory Data INSERTED SUCCESSFULLY");
			} catch (Exception e) {
				result = "FAILURE in inserting data";
				logger.error("Error in batchInsertionForBwInventory :: ",e);
			}

		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error("Error in batchInsertionForBwInventory :: ",e);
		} finally {
			stmt.close();
			conn.close();
		}
		logger.info("batchInsertionForBwInventory End :: ");
		return result;
	}

	public void transferBwInventoryDataIntoDownloadTbl(HttpSession session, Long requestId) {
		logger.info("transferBwInventoryDataIntoDownloadTbl start :: ");
		try {
		final String INSERT_SQL = "INSERT INTO BW_Inventory_Download"
				+ "(Obj_Type, Obj_Name, Package, Profiler_Used, REQUEST_ID) select Obj_Type, Obj_Name, Package, Profiler_Used, REQUEST_ID from BW_Inventory_List where REQUEST_ID ="+requestId;
		java.sql.Connection conn = DBConfig.getJDBCConnection(session);

		Statement stmtBwinv = conn.createStatement();
		stmtBwinv.executeUpdate(INSERT_SQL);
		logger.info(":: transferBwInventoryDataIntoDownloadTbl data inserted succcessfully ::");
		logger.info(":: transferBwInventoryDataIntoDownloadTbl Ended ::");
		}catch (Exception e) {
			logger.error("Error in transferBwInventoryDataIntoDownloadTbl :: ",e);
		}
	}

	@Override
	public void bwStandardExtractProcessing(HttpSession session, Long requestId) throws SQLException {
		logger.info("bwStandardExtractProcessing start :: ");
		try {
		final String INSERT_SQL = "insert into BW_STANDARD_EXTRACT (obj_name,phase,area_responsibility,data_source,app_component,classification,category,restrictions,related_simplification_item,note,del_1511,del_1610,delta_restrict,comments,Request_Id) select bem.obj_name,phase,area_responsibility,data_source,app_component,classification,category,restrictions,related_simplification_item,note,del_1511,del_1610,delta_restrict,comments,"+requestId+" from BW_Inventory_List bil inner join BW_EXTRACT_MASTER bem on bil.Obj_Name=bem.obj_name where bil.Obj_Type='BWEX'";
		java.sql.Connection conn = DBConfig.getJDBCConnection(session);

		Statement stmtBwStd = conn.createStatement();
		stmtBwStd.executeUpdate(INSERT_SQL);
		logger.info(":: bwStandardExtractProcessing data inserted succcessfully ::");
		logger.info(":: bwStandardExtractProcessing Ended ::");
		}catch (Exception e) {
			logger.error("Error in bwStandardExtractProcessing :: ",e);
		}
		
	}
	
}
