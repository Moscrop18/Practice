package com.act.POCReader.Xlsx;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.util.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.act.POCUtility.models.InventoryListPOC;
import com.act.POCUtility.models.POC_AffectedByCustomFields;
import com.act.POCUtility.models.POC_AppendStructureAnalysis;
import com.act.POCUtility.models.POC_BWCleanUpUtility;
import com.act.POCUtility.models.POC_BWInventory;
import com.act.POCUtility.models.POC_BWStandardExtract;
import com.act.POCUtility.models.POC_CVITROutput;
import com.act.POCUtility.models.POC_DRS4Simplification1;
import com.act.POCUtility.models.POC_DRS4Simplification2;
import com.act.POCUtility.models.POC_DRS4Simplification3;
import com.act.POCUtility.models.POC_DR_DB_Change;
import com.act.POCUtility.models.POC_DR_ExistingErrors;
import com.act.POCUtility.models.POC_DR_FioriOdata;
import com.act.POCUtility.models.POC_DrillDownReport;
import com.act.POCUtility.models.POC_FioriOutput;
import com.act.POCUtility.models.POC_ImpactedBackgroundJob;
import com.act.POCUtility.models.POC_ImpactedCloneAnalysis;
import com.act.POCUtility.models.POC_ImpactedCloneProgramAnalysis;
import com.act.POCUtility.models.POC_ImpactedCustomTable;
import com.act.POCUtility.models.POC_ImpactedEnhancementBadi;
import com.act.POCUtility.models.POC_ImpactedIdoc;
import com.act.POCUtility.models.POC_ImpactedObjectList;
import com.act.POCUtility.models.POC_ImpactedSAPScript;
import com.act.POCUtility.models.POC_ImpactedSearchHelp;
import com.act.POCUtility.models.POC_ImpactedStandardTransaction;
import com.act.POCUtility.models.POC_ImpactedTables;
import com.act.POCUtility.models.POC_Impacted_Variant;
import com.act.POCUtility.models.POC_InactiveObjects;
import com.act.POCUtility.models.POC_InconsistentFUGR;
import com.act.POCUtility.models.POC_NonUnicodeObjects;
import com.act.POCUtility.models.POC_OS_Migration;
import com.act.POCUtility.models.POC_OS_Migration_LogicalCMD;
import com.act.POCUtility.models.POC_OS_Migration_FilePath;
import com.act.POCUtility.models.POC_OutputManagement;
import com.act.POCUtility.models.POC_S4_SID;
import com.act.POCUtility.models.POC_SecAnalyzerTCDReport;
import com.act.POCUtility.models.POC_Smodilog;
import com.act.POCUtility.models.POC_TestingScope;
import com.act.POCUtility.models.POC_Ui5FinalOutput;
import com.act.POCUtility.models.POC_Ui5HighLevelReport;
import com.act.constant.POC_Upload_Constant;
import com.monitorjbl.xlsx.StreamingReader;
import com.rometools.utils.Strings;

public class MigrationPOCReader {

	final static Logger logger = LoggerFactory.getLogger(MigrationPOCReader.class);

	static List<InventoryListPOC> inventoryListPOC = null;

	public static List<InventoryListPOC> getInventoryListPOC() {
		return inventoryListPOC;
	}

	public static void setInventoryListPOC(List<InventoryListPOC> inventoryListPOC) {
		MigrationPOCReader.inventoryListPOC = inventoryListPOC;
	}

	public Map<String, String> validateXlsxFiles(final String path, String sheet, final long requestId,
			HttpSession session) {

		final File file = new File(path);
		InputStream inputStream = null;
		Map<String, String> fileColumnAndIndex = new HashMap<String, String>();

		try {
			inputStream = new FileInputStream(file);
			@SuppressWarnings("deprecation")
			StreamingReader pocListreader = StreamingReader.builder().rowCacheSize(5).bufferSize(2048).sheetName(sheet)
					.read(inputStream);

			for (Row r : pocListreader) {
				if (POC_Upload_Constant.POC_OUTPUT_MANAGEMENT_CONSTANT.contains(sheet.trim())) {
					if (r.getRowNum() == 6) {
						for (Cell c : r) {
							if (r.getCell(c.getColumnIndex()) != null) {
								fileColumnAndIndex.put(r.getCell(c.getColumnIndex()).getStringCellValue().trim(),
										c.getColumnIndex() + "");
							}
						}

						break;
					}
				} else if (POC_Upload_Constant.POC_AFFECTED_CUSTOM_CONSTANT.contains(sheet.trim())) {
					if (r.getRowNum() == 7) {
						for (Cell c : r) {
							if (r.getCell(c.getColumnIndex()) != null) {
								fileColumnAndIndex.put(r.getCell(c.getColumnIndex()).getStringCellValue().trim(),
										c.getColumnIndex() + "");
							}
						}

						break;
					}
				} else if (POC_Upload_Constant.POC_IMPACTED_TABLES_CONSTANT.contains(sheet.trim())
						|| POC_Upload_Constant.POC_IMPACTED_CUSTOM_TABLE.contains(sheet.trim())) {
					if (r.getRowNum() == 3) {
						for (Cell c : r) {
							if (r.getCell(c.getColumnIndex()) != null) {
								fileColumnAndIndex.put(r.getCell(c.getColumnIndex()).getStringCellValue().trim(),
										c.getColumnIndex() + "");
							}
						}

						break;
					}
				} else if (POC_Upload_Constant.POC_IMPACTED_IDOC_CONSTANT.contains(sheet.trim())
						|| POC_Upload_Constant.POC_IMPACTED_STANDARD_CONSTANT.contains(sheet.trim())
						|| POC_Upload_Constant.POC_IMPACTED_SEARCH_CONSTANT.contains(sheet.trim())
						|| POC_Upload_Constant.POC_APPEND_STRUCTURECONSTANT.contains(sheet.trim())
						|| POC_Upload_Constant.POC_CLONE_PROG_CONSTANT.contains(sheet.trim())
						|| POC_Upload_Constant.POC_ENHANCEMENT_CONSTANT.contains(sheet.trim())) {
					if (r.getRowNum() == 2) {
						for (Cell c : r) {
							if (r.getCell(c.getColumnIndex()) != null) {
								fileColumnAndIndex.put(r.getCell(c.getColumnIndex()).getStringCellValue().trim(),
										c.getColumnIndex() + "");
							}
						}

						break;
					}
				} else {
					if (r.getRowNum() == 0) {
						for (Cell c : r) {
							if (r.getCell(c.getColumnIndex()) != null) {
								fileColumnAndIndex.put(r.getCell(c.getColumnIndex()).getStringCellValue().trim(),
										c.getColumnIndex() + "");
							}
						}

						break;
					}
				}
			}

			if (fileColumnAndIndex != null && !fileColumnAndIndex.isEmpty()) {
				return fileColumnAndIndex;
			}
		} catch (FileNotFoundException e) {
			logger.error("Exception while Reading Indices. " , e);
		} finally {
			IOUtils.closeQuietly(inputStream);
		}

		return fileColumnAndIndex;
	}

	// POC Inventory List Read Data
	public InventoryListPOC getInventoryValueXlsx(Row row, long requestId, String fileName) {

		int objTypeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Object.Type"));
		int objNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Object.Name"));
		int usedIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Used"));
		int usageCountIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Usage.Count"));
		int extNamespaceIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("External.Namespace"));
		int ricefwCategoryIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("RICEFW.Category"));
		int ricefwSubCategoryIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("RICEFW.Sub.Category"));
		int standardModIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Standard.Modification"));
		int linesOfCodeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Lines.of.Code"));
		int trIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Transport.Request"));
		
		String ricefwCategory = row.getCell(ricefwCategoryIndex) == null ? "" : row.getCell(ricefwCategoryIndex).getStringCellValue().trim();
		String ricefwSubCategory = row.getCell(ricefwSubCategoryIndex) == null ? "" : row.getCell(ricefwSubCategoryIndex).getStringCellValue().trim();
		String standardMod = row.getCell(standardModIndex) == null ? "" : row.getCell(standardModIndex).getStringCellValue().trim();
		String linesOfCode = row.getCell(linesOfCodeIndex) == null ? "" : row.getCell(linesOfCodeIndex).getStringCellValue().trim();
		String tr = row.getCell(trIndex) == null ? "" : row.getCell(trIndex).getStringCellValue().trim();
		String objType = row.getCell(objTypeIndex) == null ? "" : row.getCell(objTypeIndex).getStringCellValue().trim().toUpperCase();
		String objName = row.getCell(objNameIndex) == null ? "" : row.getCell(objNameIndex).getStringCellValue().trim().toUpperCase();
		String used = row.getCell(usedIndex) == null ? "" : row.getCell(usedIndex).getStringCellValue().trim();
		String usageCount = row.getCell(usageCountIndex) == null ? ""
				: row.getCell(usageCountIndex).getStringCellValue().trim();
		String extNmspce = row.getCell(extNamespaceIndex) == null ? ""
				: row.getCell(extNamespaceIndex).getStringCellValue().trim();

		if (!objType.equals("")) {
			final InventoryListPOC pocInventory = new InventoryListPOC();
			pocInventory.setRicefwCategory(ricefwCategory);
			pocInventory.setRicefwSubCategory(ricefwSubCategory);
			pocInventory.setStandardMod(standardMod);
			pocInventory.setLinesOfCode(linesOfCode);
			pocInventory.setTransReq(tr);
			pocInventory.setObjType(objType);
			pocInventory.setObjName(objName);
			pocInventory.setUsed(used);
			pocInventory.setRequestId(requestId);
			pocInventory.setUsageCount(usageCount);
			pocInventory.setExternalNamespace(extNmspce);

			return pocInventory;
		}

		return null;
	}

	// Impacted Object List
	// Sheet::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	public POC_ImpactedObjectList getImpactedObjListValueXlsx(Row row, long requestId, String fileName) {

		int objTypeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Object.Type"));
		int objNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Object.Name"));
		int usedIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Used"));
		int auctIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("AUCT"));
		int hanaIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Hana"));
		int s4Index = Integer.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("S4"));
		int odataIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Odata"));
		int osMigrationIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("OSMigration"));
		int usageCountIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Usage.Count"));
		int extNamespaceIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("External.Namespace"));
		int ricefwCategoryIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("RICEFW.Category"));
		int ricefwSubCategoryIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("RICEFW.Sub.Category"));
		int impactModIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Impacted.Modification"));
		
		String ricefwCategory = row.getCell(ricefwCategoryIndex) == null ? "" : row.getCell(ricefwCategoryIndex).getStringCellValue().trim();
		String ricefwSubCategory = row.getCell(ricefwSubCategoryIndex) == null ? "" : row.getCell(ricefwSubCategoryIndex).getStringCellValue().trim();
		String impactMod = row.getCell(impactModIndex) == null ? "" : row.getCell(impactModIndex).getStringCellValue().trim();
		String objType = row.getCell(objTypeIndex) == null ? "" : row.getCell(objTypeIndex).getStringCellValue().trim();
		String objName = row.getCell(objNameIndex) == null ? "" : row.getCell(objNameIndex).getStringCellValue().trim();
		String used = row.getCell(usedIndex) == null ? "" : row.getCell(usedIndex).getStringCellValue().trim();
		String auct = row.getCell(auctIndex) == null ? "" : row.getCell(auctIndex).getStringCellValue().trim();
		String hana = row.getCell(hanaIndex) == null ? "" : row.getCell(hanaIndex).getStringCellValue().trim();
		String s4 = row.getCell(s4Index) == null ? "" : row.getCell(s4Index).getStringCellValue().trim();
		String odata = row.getCell(odataIndex) == null ? "" : row.getCell(odataIndex).getStringCellValue().trim();
		String osMig = row.getCell(osMigrationIndex) == null ? "" : row.getCell(osMigrationIndex).getStringCellValue().trim();
		String usageCount = row.getCell(usageCountIndex) == null ? ""
				: row.getCell(usageCountIndex).getStringCellValue().trim();
		String extNmspce = row.getCell(extNamespaceIndex) == null ? ""
				: row.getCell(extNamespaceIndex).getStringCellValue().trim();

		if (!objType.equals("")) {
			final POC_ImpactedObjectList pocImpactedObjList = new POC_ImpactedObjectList();

			pocImpactedObjList.setRicefwCategory(ricefwCategory);
			pocImpactedObjList.setRicefwSubCategory(ricefwSubCategory);
			pocImpactedObjList.setImpactMod(impactMod);
			pocImpactedObjList.setObjectType(objType);
			pocImpactedObjList.setObjectName(objName);
			pocImpactedObjList.setUsed(used);
			pocImpactedObjList.setErrorsInExistingSystem(auct);
			pocImpactedObjList.setDbImpact(hana);
			pocImpactedObjList.setS4Simplification(s4);
			pocImpactedObjList.setOdata(odata);
			pocImpactedObjList.setRequestId(requestId);
			pocImpactedObjList.setOsMigration(osMig);
			pocImpactedObjList.setUsageCount(usageCount);
			pocImpactedObjList.setExternalNamespace(extNmspce);

			return pocImpactedObjList;
		}

		return null;
	}

	// DR_DB Change
	// Sheet:::::::::Hana::::::::::::::::::::::::::::::::::::::::::::::
	public POC_DR_DB_Change getFinalOutputValueXlsx(Row row, long requestId, String fileName) {
		int typeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Type"));
		int objNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name"));
		int subObjNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sub.Obj.Name"));
		int readPrgIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Read.Program"));
		int objPackageIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Package"));
		int opperationIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Operation"));
		int lineIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Line.No"));
		int stmtIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Statement"));
		int remidiCatIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Remediation.Category"));
		int issueCatIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Issue.Category"));
		int issueSubCatIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sub.Category"));
		int descIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Desc"));
		int solStepsIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Solution.Steps"));
		int levelOfNestingIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Level.Of.Nesting"));
		int tablesIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Tables"));
		int joinsIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Joins"));
		int tableTypeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Table.Type"));
		int whereConditionIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Where.Condition"));
		int joinTypeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Join.Type"));
		int impactIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Impact"));
		int automationStatusIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Automation.Status"));
		int complexityIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Complexity"));
		int usedIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Used"));
		int selLineIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Select.Line"));
		int extNamespaceIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("External.Namespace"));
		int ricefwCategoryIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("RICEFW.Category"));
		int ricefwSubCategoryIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("RICEFW.Sub.Category"));
		int skipReasonIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Skip.Reason"));
		int skipIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Skip"));

		String type = row.getCell(typeIndex) == null ? "" : row.getCell(typeIndex).getStringCellValue().trim().toUpperCase();
		String objName = row.getCell(objNameIndex) == null ? "" : row.getCell(objNameIndex).getStringCellValue().trim().toUpperCase();
		String subObjName = row.getCell(subObjNameIndex) == null ? ""
				: row.getCell(subObjNameIndex).getStringCellValue().trim();
		String readPrg = row.getCell(readPrgIndex) == null ? "" : row.getCell(readPrgIndex).getStringCellValue().trim();
		String objPackage = row.getCell(objPackageIndex) == null ? ""
				: row.getCell(objPackageIndex).getStringCellValue().trim();
		String operation = row.getCell(opperationIndex) == null ? ""
				: row.getCell(opperationIndex).getStringCellValue().trim().toUpperCase();
		Integer line = (int) Double
				.parseDouble(row.getCell(lineIndex) == null ? "0" : row.getCell(lineIndex).getStringCellValue().trim());
		String stmt = row.getCell(stmtIndex) == null ? "" : row.getCell(stmtIndex).getStringCellValue().trim();
		String remidiCat = row.getCell(remidiCatIndex) == null ? "" : row.getCell(remidiCatIndex).getStringCellValue().trim().toUpperCase();
		String issueCat = row.getCell(issueCatIndex) == null ? "" : row.getCell(issueCatIndex).getStringCellValue().trim().toUpperCase();
		String issueSubCat = row.getCell(issueSubCatIndex) == null ? ""
				: row.getCell(issueSubCatIndex).getStringCellValue().trim().toUpperCase();
		String desc = row.getCell(descIndex) == null ? "" : row.getCell(descIndex).getStringCellValue().trim();
		String solSteps = row.getCell(solStepsIndex) == null ? "" : row.getCell(solStepsIndex).getStringCellValue().trim();
		Integer levelOfNesting = (int) Double.parseDouble(row.getCell(levelOfNestingIndex) == null ? "0"
				: row.getCell(levelOfNestingIndex).getStringCellValue().trim());
		String tables = row.getCell(tablesIndex) == null ? "" : row.getCell(tablesIndex).getStringCellValue().trim();
		String joins = row.getCell(joinsIndex) == null ? "" : row.getCell(joinsIndex).getStringCellValue().trim();
		String tableType = row.getCell(tableTypeIndex) == null ? "" : row.getCell(tableTypeIndex).getStringCellValue().trim();
		String whereCondition = row.getCell(whereConditionIndex) == null ? ""
				: row.getCell(whereConditionIndex).getStringCellValue().trim();
		String joinType = row.getCell(joinTypeIndex) == null ? "" : row.getCell(joinTypeIndex).getStringCellValue().trim();
		String impact = row.getCell(impactIndex) == null ? "" : row.getCell(impactIndex).getStringCellValue().trim();
		String automationStatus = row.getCell(automationStatusIndex) == null ? ""
				: row.getCell(automationStatusIndex).getStringCellValue().trim().toUpperCase();
		String complexity = row.getCell(complexityIndex) == null ? ""
				: row.getCell(complexityIndex).getStringCellValue().trim();
		String used = row.getCell(usedIndex) == null ? "" : row.getCell(usedIndex).getStringCellValue().trim();
		String selLine = row.getCell(selLineIndex) == null ? "" : row.getCell(selLineIndex).getStringCellValue().trim();
		String extNmspce = row.getCell(extNamespaceIndex) == null ? ""
				: row.getCell(extNamespaceIndex).getStringCellValue().trim();
		String ricefwCategory = row.getCell(ricefwCategoryIndex) == null ? "" : row.getCell(ricefwCategoryIndex).getStringCellValue().trim();
		String ricefwSubCategory = row.getCell(ricefwSubCategoryIndex) == null ? "" : row.getCell(ricefwSubCategoryIndex).getStringCellValue().trim();
		String skipReason = row.getCell(skipReasonIndex) == null ? "" : row.getCell(skipReasonIndex).getStringCellValue().trim();
		String skip = row.getCell(skipIndex) == null ? "" : row.getCell(skipIndex).getStringCellValue().trim();
		
		if (!type.equals("")) {
			final POC_DR_DB_Change pocFinalOutput = new POC_DR_DB_Change();

			pocFinalOutput.setRicefwCategory(ricefwCategory);
			pocFinalOutput.setRicefwSubCategory(ricefwSubCategory);
			pocFinalOutput.setSkipReason(skipReason);
			pocFinalOutput.setSkip(skip);
			pocFinalOutput.setObjType(type);
			pocFinalOutput.setObjName(objName);
			pocFinalOutput.setSubObjName(subObjName);
			pocFinalOutput.setReadProgram(readPrg);
			pocFinalOutput.setPkg(objPackage);
			pocFinalOutput.setOperation(operation);
			pocFinalOutput.setLineNo(line);
			pocFinalOutput.setStatement(stmt);
			pocFinalOutput.setRemediationCategory(remidiCat);
			pocFinalOutput.setIssueCategory(issueCat);
			pocFinalOutput.setIssueSubCategory(issueSubCat);
			pocFinalOutput.setDescOfChange(desc);
			pocFinalOutput.setSolutionSteps(solSteps);
			pocFinalOutput.setLevelOfNesting(levelOfNesting);
			pocFinalOutput.setTables(tables);
			pocFinalOutput.setJoins(joins);
			pocFinalOutput.setTableType(tableType);
			pocFinalOutput.setWhereCondition(whereCondition);
			pocFinalOutput.setJoinType(joinType);
			pocFinalOutput.setImpact(impact);
			pocFinalOutput.setAutomationStatus(automationStatus);
			pocFinalOutput.setComplexity(complexity);
			pocFinalOutput.setUsed(used);
			pocFinalOutput.setSelectLine(selLine);
			pocFinalOutput.setRequestId(requestId);
			pocFinalOutput.setExternalNamespace(extNmspce);
			pocFinalOutput.setObjectNameType(row.getCell(objNameIndex) == null ? ""
					: (type) + (row.getCell(objNameIndex).getStringCellValue().trim()).toUpperCase());

			return pocFinalOutput;
		}

		return null;
	}

	// S4Simplification-1
	// Sheet::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::;
	public POC_DRS4Simplification1 getS4FinalOutputListValueXlsx(Row row, long requestId, String fileName) {

		int typeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Type"));
		int objNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name"));
		int subObjNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sub.Obj.Name"));
		int readPrgIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Read.Program"));
		int objPackageIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Package"));
		int operationIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Operation"));
		int lineIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Line.No"));
		int statementIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Statement"));
		int impactedObjIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Impacted.Obj"));
		int impactReasonIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Impact.reason"));
		int descIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Desc"));
		int noteNumberIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Note.No"));
		int solStepsIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Solution.Step"));
		int complexityIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Complexity"));
		int issueCatIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Issue.Category"));
		int issueSubCatIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sub.Category"));
		int triggerObjIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Trigger.object"));
		int remidiCatIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Remediation.Category"));
		int sapSimpliListIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("SAP.Simpli.List.Chapter"));
		int appComponentIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("App.Component"));
		int sapSimpliCatIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Simpli.Category"));
		int itemIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Item.Area"));
		int usedIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Used"));
		int selLineIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Select.Line"));
		int ricefwCategoryIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("RICEFW.Category"));
		int ricefwSubCategoryIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("RICEFW.Sub.Category"));
		int impactIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Impact"));
		int corProgNameIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Correction.Program.Name"));
		int corLineNoIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Correction.Line.Number"));
		int automationStatusIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Automation.Status"));
		int toolVersionIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Tool.Version"));
		
		String type = row.getCell(typeIndex) == null ? "" : row.getCell(typeIndex).getStringCellValue().trim().toUpperCase();
		int extNamespaceIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("External.Namespace"));
		String ricefwCategory = row.getCell(ricefwCategoryIndex) == null ? "" : row.getCell(ricefwCategoryIndex).getStringCellValue().trim();
		String ricefwSubCategory = row.getCell(ricefwSubCategoryIndex) == null ? "" : row.getCell(ricefwSubCategoryIndex).getStringCellValue().trim();
		String impact = row.getCell(impactIndex) == null ? "" : row.getCell(impactIndex).getStringCellValue().trim();
		String corProgName = row.getCell(corProgNameIndex) == null ? "" : row.getCell(corProgNameIndex).getStringCellValue().trim();
		String corLineNo = row.getCell(corLineNoIndex) == null ? "" : row.getCell(corLineNoIndex).getStringCellValue().trim();
		String automationStatus = row.getCell(automationStatusIndex) == null ? "" : row.getCell(automationStatusIndex).getStringCellValue().trim();
		String toolVersion = row.getCell(toolVersionIndex) == null ? "" : row.getCell(toolVersionIndex).getStringCellValue().trim();
	
		if (!type.equals("")) {
			final POC_DRS4Simplification1 pocS4FinalOutputList = new POC_DRS4Simplification1();
			pocS4FinalOutputList.setRicefwCategory(ricefwCategory);
			pocS4FinalOutputList.setRicefwSubCategory(ricefwSubCategory);
			pocS4FinalOutputList.setCorProgName(corProgName);
			pocS4FinalOutputList.setCorLineNo(corLineNo);
			pocS4FinalOutputList.setImpact(impact);
			pocS4FinalOutputList.setAutomationStatus(automationStatus);
			pocS4FinalOutputList.setToolVersion(toolVersion);
			pocS4FinalOutputList.setObjType(type);
			pocS4FinalOutputList.setObjName(
					row.getCell(objNameIndex) == null ? "" : row.getCell(objNameIndex).getStringCellValue().trim().toUpperCase());
			pocS4FinalOutputList.setSubObjName(
					row.getCell(subObjNameIndex) == null ? "" : row.getCell(subObjNameIndex).getStringCellValue().trim());
			pocS4FinalOutputList.setReadProgram(
					row.getCell(readPrgIndex) == null ? "" : row.getCell(readPrgIndex).getStringCellValue().trim());
			pocS4FinalOutputList.setPkg(
					row.getCell(objPackageIndex) == null ? "" : row.getCell(objPackageIndex).getStringCellValue().trim());
			pocS4FinalOutputList.setOperation(
					row.getCell(operationIndex) == null ? "" : row.getCell(operationIndex).getStringCellValue().trim());
			if (row.getCell(operationIndex).getStringCellValue().trim().contains("~")) {
				String[] splitStr = row.getCell(operationIndex).getStringCellValue().trim().split("~");
				pocS4FinalOutputList.setCorProgName(splitStr[1]);
				pocS4FinalOutputList.setCorLineNo(splitStr[2]);
			}
			pocS4FinalOutputList.setLineNo((int) Double.parseDouble(
					row.getCell(lineIndex) == null ? "0" : row.getCell(lineIndex).getStringCellValue().trim()));
			pocS4FinalOutputList.setStatement(
					row.getCell(statementIndex) == null ? "" : row.getCell(statementIndex).getStringCellValue().trim());
			pocS4FinalOutputList.setImpactedObj(
					row.getCell(impactedObjIndex) == null ? "" : row.getCell(impactedObjIndex).getStringCellValue().trim());
			pocS4FinalOutputList.setImpactReason(
					row.getCell(impactReasonIndex) == null ? "" : row.getCell(impactReasonIndex).getStringCellValue().trim());
			pocS4FinalOutputList
					.setDescOfChange(row.getCell(descIndex) == null ? "" : row.getCell(descIndex).getStringCellValue().trim());
			pocS4FinalOutputList.setSAPNote(
					row.getCell(noteNumberIndex) == null ? "" : row.getCell(noteNumberIndex).getStringCellValue().trim());
			pocS4FinalOutputList.setSolutionStep(
					row.getCell(solStepsIndex) == null ? "" : row.getCell(solStepsIndex).getStringCellValue().trim());
			pocS4FinalOutputList.setComplexity(
					row.getCell(complexityIndex) == null ? "" : row.getCell(complexityIndex).getStringCellValue().trim().toUpperCase());
			pocS4FinalOutputList.setIssueCategory(
					row.getCell(issueCatIndex) == null ? "" : row.getCell(issueCatIndex).getStringCellValue().trim().toUpperCase());
			pocS4FinalOutputList.setIssueSubCategory(
					row.getCell(issueSubCatIndex) == null ? "" : row.getCell(issueSubCatIndex).getStringCellValue().trim().toUpperCase());
			pocS4FinalOutputList.setTriggerObject(
					row.getCell(triggerObjIndex) == null ? "" : row.getCell(triggerObjIndex).getStringCellValue().trim());
			pocS4FinalOutputList.setRemediationCategory(
					row.getCell(remidiCatIndex) == null ? "" : row.getCell(remidiCatIndex).getStringCellValue().trim().toUpperCase());
			pocS4FinalOutputList.setSAPSimpliListChapter(row.getCell(sapSimpliListIndex) == null ? ""
					: row.getCell(sapSimpliListIndex).getStringCellValue().trim());
			pocS4FinalOutputList.setAppComponent(
					row.getCell(appComponentIndex) == null ? "" : row.getCell(appComponentIndex).getStringCellValue().trim());
			pocS4FinalOutputList.setSAPSimpliCategory(
					row.getCell(sapSimpliCatIndex) == null ? "" : row.getCell(sapSimpliCatIndex).getStringCellValue().trim().toUpperCase());
			pocS4FinalOutputList
					.setItemArea(row.getCell(itemIndex) == null ? "" : row.getCell(itemIndex).getStringCellValue().trim().toUpperCase());
			pocS4FinalOutputList
					.setUsed(row.getCell(usedIndex) == null ? "" : row.getCell(usedIndex).getStringCellValue().trim());
			pocS4FinalOutputList.setRequestId(requestId);
			pocS4FinalOutputList.setObjectNameType(row.getCell(objNameIndex) == null ? ""
					: (type) + (row.getCell(objNameIndex).getStringCellValue().trim()).toUpperCase());
			pocS4FinalOutputList.setSelLine(
					row.getCell(selLineIndex) == null ? "" : row.getCell(selLineIndex).getStringCellValue().trim());
			pocS4FinalOutputList.setExternalNamespace(
					row.getCell(extNamespaceIndex) == null ? "" : row.getCell(extNamespaceIndex).getStringCellValue().trim());

			return pocS4FinalOutputList;
		}

		return null;
	}

	// DR_Existing Errors Sheet::::::::::::::::::::::::::::::
	public POC_DR_ExistingErrors getAUCTValueXlsx(Row row, long requestId, String fileName) {

		int typeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Type"));
		int objNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name"));
		int subObjNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sub.Obj.Name"));
		int readPrgIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Read.Program"));
		int objPackageIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Package"));
		int lineIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Line.No"));
		int descIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Desc"));
		int automationStatusIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Automation.Status"));
		int usedIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Used"));
		int extNamespaceIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("External.Namespace"));
		int ricefwCategoryIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("RICEFW.Category"));
		int ricefwSubCategoryIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("RICEFW.Sub.Category"));
		int opCodeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("OpCode"));

		String type = row.getCell(typeIndex) == null ? "" : row.getCell(typeIndex).getStringCellValue().trim().toUpperCase();
		String ricefwCategory = row.getCell(ricefwCategoryIndex) == null ? "" : row.getCell(ricefwCategoryIndex).getStringCellValue().trim();
		String ricefwSubCategory = row.getCell(ricefwSubCategoryIndex) == null ? "" : row.getCell(ricefwSubCategoryIndex).getStringCellValue().trim();
		String opCode = row.getCell(opCodeIndex) == null ? "" : row.getCell(opCodeIndex).getStringCellValue().trim();

		if (!type.equals("")) {
			final POC_DR_ExistingErrors pocAUCTList = new POC_DR_ExistingErrors();
			pocAUCTList.setRicefwCategory(ricefwCategory);
			pocAUCTList.setRicefwSubCategory(ricefwSubCategory);
			pocAUCTList.setOpCode(opCode);	
			pocAUCTList.setObjType(type);
			pocAUCTList.setObjName(
					row.getCell(objNameIndex) == null ? "" : row.getCell(objNameIndex).getStringCellValue().trim().toUpperCase());
			pocAUCTList.setSubObjName(
					row.getCell(subObjNameIndex) == null ? "" : row.getCell(subObjNameIndex).getStringCellValue().trim());
			pocAUCTList.setReadProgram(
					row.getCell(readPrgIndex) == null ? "" : row.getCell(readPrgIndex).getStringCellValue().trim());
			pocAUCTList.setPkg(
					row.getCell(objPackageIndex) == null ? "" : row.getCell(objPackageIndex).getStringCellValue().trim());
			pocAUCTList.setLineNo((int) Double.parseDouble(
					row.getCell(lineIndex) == null ? "0" : row.getCell(lineIndex).getStringCellValue().trim()));
			pocAUCTList
					.setDescOfChange(row.getCell(descIndex) == null ? "" : row.getCell(descIndex).getStringCellValue().trim().toUpperCase());
			pocAUCTList.setAutomationStatus(row.getCell(automationStatusIndex) == null ? ""
					: row.getCell(automationStatusIndex).getStringCellValue());
			pocAUCTList.setUsed(row.getCell(usedIndex) == null ? "" : row.getCell(usedIndex).getStringCellValue().trim());
			pocAUCTList.setRequestId(requestId);
			pocAUCTList.setExternalNamespace(
					row.getCell(extNamespaceIndex) == null ? "" : row.getCell(extNamespaceIndex).getStringCellValue().trim());
			pocAUCTList.setObjectNameType(row.getCell(objNameIndex) == null ? ""
					: (type) + (row.getCell(objNameIndex).getStringCellValue().trim()).toUpperCase());

			return pocAUCTList;
		}

		return null;
	}

	// Fiori Detail Report
	// Sheet:::::::::::::::::::::::::::::::::::::::::::::::::::::
	public POC_DR_FioriOdata getFioriOdataListValueXlsx(Row row, long requestId, String fileName) {

		int typeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Type"));
		int objNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name"));
		int appIdIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("app.id"));
		int subTypeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sub.Type"));
		int appTypeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("application.type"));
		int verAvailIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("version.available"));
		int appNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("app.name"));

		String type = row.getCell(typeIndex) == null ? "" : row.getCell(typeIndex).getStringCellValue();

		if (!type.equals("")) {
			final POC_DR_FioriOdata pocFioriOdataList = new POC_DR_FioriOdata();

			pocFioriOdataList.setObjType(type);
			pocFioriOdataList.setObjName(
					row.getCell(objNameIndex) == null ? "" : row.getCell(objNameIndex).getStringCellValue());
			pocFioriOdataList
					.setAppId(row.getCell(appIdIndex) == null ? "" : row.getCell(appIdIndex).getStringCellValue());
			pocFioriOdataList.setSubType(
					row.getCell(subTypeIndex) == null ? "" : row.getCell(subTypeIndex).getStringCellValue());
			pocFioriOdataList.setAppType(
					row.getCell(appTypeIndex) == null ? "" : row.getCell(appTypeIndex).getStringCellValue());
			pocFioriOdataList.setVersAvailable(
					row.getCell(verAvailIndex) == null ? "" : row.getCell(verAvailIndex).getStringCellValue());
			pocFioriOdataList.setAppname(
					row.getCell(appNameIndex) == null ? "" : row.getCell(appNameIndex).getStringCellValue());
			pocFioriOdataList.setRequestId(requestId);

			return pocFioriOdataList;
		}

		return null;
	}

	// Output Management
	// Sheet::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	public POC_OutputManagement getOutputMngmtListValueXlsx(Row row, long requestId, String fileName) {

		int typeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Type"));
		int objNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name"));

		String type = row.getCell(typeIndex) == null ? "" : row.getCell(typeIndex).getStringCellValue();

		if (!type.equals("")) {
			final POC_OutputManagement pocOutputMngmtList = new POC_OutputManagement();

			pocOutputMngmtList.setObjectType(type);
			pocOutputMngmtList.setObjectName(
					row.getCell(objNameIndex) == null ? "" : row.getCell(objNameIndex).getStringCellValue());
			pocOutputMngmtList.setRequestId(requestId);
			return pocOutputMngmtList;
		}

		return null;
	}

	// Affect Custom
	// Sheet:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	public POC_AffectedByCustomFields getAffectedCustomFieldsListValueXlsx(Row row, long requestId, String fileName) {

		int typeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Type"));
		int objNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name"));
		int triggerObjectIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Trigger.object"));
		int replacedByCDSIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Replaced.By.CDS"));

		String type = row.getCell(typeIndex) == null ? "" : row.getCell(typeIndex).getStringCellValue();
		String replacedByCDS = row.getCell(replacedByCDSIndex) == null ? "" : row.getCell(replacedByCDSIndex).getStringCellValue().trim();

		if (!type.equals("")) {
			final POC_AffectedByCustomFields pocAffectedCustomList = new POC_AffectedByCustomFields();
			
			pocAffectedCustomList.setReplacedByCDS(replacedByCDS);
			pocAffectedCustomList.setObjectType(type);
			pocAffectedCustomList.setObjectName(
					row.getCell(objNameIndex) == null ? "" : row.getCell(objNameIndex).getStringCellValue());
			pocAffectedCustomList.setTriggerObject(row.getCell(triggerObjectIndex) == null ? ""
					: row.getCell(triggerObjectIndex).getStringCellValue());
			pocAffectedCustomList.setRequestId(requestId);
			return pocAffectedCustomList;
		}

		return null;
	}

	// Impacted Tables
	// Sheet::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	public POC_ImpactedTables getImpactedTablesListValueXlsx(Row row, long requestId, String fileName) {

		int objNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name"));
		int descIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Desc"));
		int solStepsIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Solution.Steps"));
		int noteNoIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Note.No"));

		final POC_ImpactedTables pocImpactedTablesList = new POC_ImpactedTables();

		pocImpactedTablesList
				.setObject(row.getCell(objNameIndex) == null ? "" : row.getCell(objNameIndex).getStringCellValue());
		pocImpactedTablesList
				.setDescription(row.getCell(descIndex) == null ? "" : row.getCell(descIndex).getStringCellValue());
		pocImpactedTablesList.setSolutionSteps(
				row.getCell(solStepsIndex) == null ? "" : row.getCell(solStepsIndex).getStringCellValue());
		pocImpactedTablesList
				.setSapNotes(row.getCell(noteNoIndex) == null ? "" : row.getCell(noteNoIndex).getStringCellValue());
		pocImpactedTablesList.setRequestId(requestId);
		return pocImpactedTablesList;

	}

	// Impacted IDOC
	// Sheet::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	public POC_ImpactedIdoc getImpactedIDOCListValueXlsx(Row row, long requestId, String fileName) {

		int msgTypeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("IDOC.Msg.Type"));
		int basicTypeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("IDOC.Basic.Type"));
		int segmentIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Segment"));
		int impactedObjTypeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Impacted.Obj.Type"));
		int impactedObjNamIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Impacted.Obj.Name"));
		int descIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Desc"));
		int noteNoIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Note.No"));
		int solStepsIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Solution.Step"));
		int typeOfIDOCIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Type.Of.IDOC"));
		
		String typeOfIDOC = row.getCell(typeOfIDOCIndex) == null ? "" : row.getCell(typeOfIDOCIndex).getStringCellValue().trim();
		
		final POC_ImpactedIdoc pocImpactedIDOCList = new POC_ImpactedIdoc();
		
		pocImpactedIDOCList.setTypeOfIDOC(typeOfIDOC);
		pocImpactedIDOCList.setIdocMsgType(
				row.getCell(msgTypeIndex) == null ? "" : row.getCell(msgTypeIndex).getStringCellValue());
		pocImpactedIDOCList.setIdocBasicType(
				row.getCell(basicTypeIndex) == null ? "" : row.getCell(basicTypeIndex).getStringCellValue());
		pocImpactedIDOCList.setIdocSegment(
				row.getCell(segmentIndex) == null ? "" : row.getCell(segmentIndex).getStringCellValue());
		pocImpactedIDOCList.setImpactedObjectType(row.getCell(impactedObjTypeIndex) == null ? ""
				: row.getCell(impactedObjTypeIndex).getStringCellValue());
		pocImpactedIDOCList.setImpactedObjectName(
				row.getCell(impactedObjNamIndex) == null ? "" : row.getCell(impactedObjNamIndex).getStringCellValue());
		pocImpactedIDOCList
				.setDescription(row.getCell(descIndex) == null ? "" : row.getCell(descIndex).getStringCellValue());
		pocImpactedIDOCList
				.setSapNote(row.getCell(noteNoIndex) == null ? "" : row.getCell(noteNoIndex).getStringCellValue());
		pocImpactedIDOCList.setSolutionStep(
				row.getCell(solStepsIndex) == null ? "" : row.getCell(solStepsIndex).getStringCellValue());
		pocImpactedIDOCList.setRequestId(requestId);
		return pocImpactedIDOCList;

	}

	// Standard Transaction
	// Tables:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	public POC_ImpactedStandardTransaction getImpactedStandardTransactionListValueXlsx(Row row, long requestId,
			String fileName) {

		int impactedTransactionIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Impacted.Transaction"));
		int descIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Desc"));
		int noteNoIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Note.No"));
		int solStepsIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Solution.Step"));

		final POC_ImpactedStandardTransaction pocImpactedStandardTransactionList = new POC_ImpactedStandardTransaction();

		pocImpactedStandardTransactionList.setImpactedTransaction(row.getCell(impactedTransactionIndex) == null ? ""
				: row.getCell(impactedTransactionIndex).getStringCellValue());
		pocImpactedStandardTransactionList
				.setDescription(row.getCell(descIndex) == null ? "" : row.getCell(descIndex).getStringCellValue());
		pocImpactedStandardTransactionList
				.setNoteNo(row.getCell(noteNoIndex) == null ? "" : row.getCell(noteNoIndex).getStringCellValue());
		pocImpactedStandardTransactionList.setSolutionStep(
				row.getCell(solStepsIndex) == null ? "" : row.getCell(solStepsIndex).getStringCellValue());
		pocImpactedStandardTransactionList.setRequestId(requestId);
		return pocImpactedStandardTransactionList;
	}

	// Search
	// Help::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	public POC_ImpactedSearchHelp getImpactedSearchHelpListValueXlsx(Row row, long requestId, String fileName) {

		/*
		 * int dataIndex = Integer
		 * .parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(requestId).
		 * get( fileName).get("Data").get(1)); String data =
		 * row.getCell(dataIndex) == null ? "" :
		 * row.getCell(dataIndex).getStringCellValue(); if (!data.equals("")) {
		 * final POC_ImpactedSearchHelp s4Impacted = new
		 * POC_ImpactedSearchHelp(); s4Impacted.setSearchData(data);
		 * s4Impacted.setRequestId(requestId); return s4Impacted; } return null;
		 */
		// Uncomment the below code and comment the above code once TR is
		// released from
		// ABAP end
		int objTypeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Type"));
		int customTableIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Custom.Table"));
		int impactedSearchHelpIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Impacted.Search"));
		int extNamespaceIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("External.Namespace"));
		String extNamespace = row.getCell(extNamespaceIndex) == null ? "" : row.getCell(extNamespaceIndex).getStringCellValue().trim();
		
		final POC_ImpactedSearchHelp pocImpactedSearchHelpList = new POC_ImpactedSearchHelp();
		
		pocImpactedSearchHelpList.setExternalNamespace(extNamespace);
		pocImpactedSearchHelpList
				.setObjectType(row.getCell(objTypeIndex) == null ? "" : row.getCell(objTypeIndex).getStringCellValue());
		pocImpactedSearchHelpList.setCustomTable(
				row.getCell(customTableIndex) == null ? "" : row.getCell(customTableIndex).getStringCellValue());
		pocImpactedSearchHelpList.setImpactedSearchHelp(row.getCell(impactedSearchHelpIndex) == null ? ""
				: row.getCell(impactedSearchHelpIndex).getStringCellValue());
		pocImpactedSearchHelpList.setRequestId(requestId);
		return pocImpactedSearchHelpList;
	}

	// Append
	// Structure::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
	public POC_AppendStructureAnalysis getAppendStructureListValueXlsx(Row row, long requestId, String fileName) {

		int tableIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Table.Name"));
		int fieldIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Field.Name"));
		int includeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Name.Of.Include"));

		final POC_AppendStructureAnalysis pocAppendStructureList = new POC_AppendStructureAnalysis();

		pocAppendStructureList
				.setTableName(row.getCell(tableIndex) == null ? "" : row.getCell(tableIndex).getStringCellValue());
		pocAppendStructureList
				.setFieldName(row.getCell(fieldIndex) == null ? "" : row.getCell(fieldIndex).getStringCellValue());
		pocAppendStructureList.setNameOfInclude(
				row.getCell(includeIndex) == null ? "" : row.getCell(includeIndex).getStringCellValue());
		pocAppendStructureList.setRequestId(requestId);

		return pocAppendStructureList;
	}

	// Clone Program Sheet:::::::::::::::::::::::::::::
	public POC_ImpactedCloneProgramAnalysis getCloneProgValueXlsx(Row row, long requestId, String fileName) {

		int impactedProgIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Impacted.Prog"));
		int cloneProgIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Clone.Prog"));
		int descIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Desc"));
		int solStepIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Solution.Step"));
		int noteNoIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Related.Note"));

		final POC_ImpactedCloneProgramAnalysis pocCloneProgList = new POC_ImpactedCloneProgramAnalysis();

		pocCloneProgList.setImpactedProgram(
				row.getCell(impactedProgIndex) == null ? "" : row.getCell(impactedProgIndex).getStringCellValue());
		pocCloneProgList.setCloneProgram(
				row.getCell(cloneProgIndex) == null ? "" : row.getCell(cloneProgIndex).getStringCellValue());
		pocCloneProgList.setDescriptionOfChange(
				row.getCell(descIndex) == null ? "" : row.getCell(descIndex).getStringCellValue());
		pocCloneProgList.setSolutionStep(
				row.getCell(solStepIndex) == null ? "" : row.getCell(solStepIndex).getStringCellValue());
		pocCloneProgList
				.setRelatedNote(row.getCell(noteNoIndex) == null ? "" : row.getCell(noteNoIndex).getStringCellValue());
		pocCloneProgList.setRequestId(requestId);

		return pocCloneProgList;
	}

	// Enhancement BADI Sheet:::::::::::::::::::::
	public POC_ImpactedEnhancementBadi getEnhancementBADIListValueXlsx(Row row, long requestId, String fileName) {

		int enhancementTypeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Enhancement.Type"));
		int classNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Class.Name"));
		int enhancementNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Enhancement.Name"));
		int implNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Impl.Name"));

		final POC_ImpactedEnhancementBadi pocEnhancementList = new POC_ImpactedEnhancementBadi();

		pocEnhancementList.setEnhancementType(row.getCell(enhancementTypeIndex) == null ? ""
				: row.getCell(enhancementTypeIndex).getStringCellValue());
		pocEnhancementList.setClassName(
				row.getCell(classNameIndex) == null ? "" : row.getCell(classNameIndex).getStringCellValue());
		pocEnhancementList.setEnhancemnetName(row.getCell(enhancementNameIndex) == null ? ""
				: row.getCell(enhancementNameIndex).getStringCellValue());
		pocEnhancementList.setImplementationName(
				row.getCell(implNameIndex) == null ? "" : row.getCell(implNameIndex).getStringCellValue());
		pocEnhancementList.setRequestId(requestId);

		return pocEnhancementList;
	}

	// DDR2 Sheet:::::::::::::::::::::::::
	public POC_DRS4Simplification2 getS4Simplification2ListValueXlsx(Row row, long requestId, String fileName) {

		int typeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Type"));
		int objNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name"));
		int usedIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Used"));
		int subObjIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sub.Obj"));
		int methodIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Method"));
		int objPackageIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Pckg"));
		int impactedObjTypeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Impacted.Obj.Type"));
		int lineIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Line.No"));
		int statementIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Stmt"));
		int operationIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Operation"));
		int impactReasonIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Impact.Reason"));
		int affctedObjIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Affected.Obj.Desc"));
		int descIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Desc"));
		int noteNumberIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Note.No"));
		int solStepsIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Solution.Steps"));
		int complexityIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Complexity"));
		int issueCatIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Issue.Category"));
		int errorCatIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Error.Category"));
		int triggerObjIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Trigger.Object"));
		int remidiCatIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Remediation.Category"));
		int sapSimpliListIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("SAP.Simpli.List.Chapter"));
		int appComponentIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("App.Component"));
		int sapSimpliCatIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Simpli.Category"));
		int itemIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Item.Area"));

		String type = row.getCell(typeIndex) == null ? "" : row.getCell(typeIndex).getStringCellValue();

		if (!type.equals("")) {
			final POC_DRS4Simplification2 pocS4FinalOutput2List = new POC_DRS4Simplification2();

			pocS4FinalOutput2List.setType(type);
			pocS4FinalOutput2List
					.setObject(row.getCell(objNameIndex) == null ? "" : row.getCell(objNameIndex).getStringCellValue());
			pocS4FinalOutput2List.setSubObject(
					row.getCell(subObjIndex) == null ? "" : row.getCell(subObjIndex).getStringCellValue());
			pocS4FinalOutput2List
					.setUsed(row.getCell(usedIndex) == null ? "" : row.getCell(usedIndex).getStringCellValue());
			pocS4FinalOutput2List
					.setMethod(row.getCell(methodIndex) == null ? "" : row.getCell(methodIndex).getStringCellValue());
			pocS4FinalOutput2List.setPkg(
					row.getCell(objPackageIndex) == null ? "" : row.getCell(objPackageIndex).getStringCellValue());
			pocS4FinalOutput2List.setImpactedObjType(row.getCell(impactedObjTypeIndex) == null ? ""
					: row.getCell(impactedObjTypeIndex).getStringCellValue());
			pocS4FinalOutput2List.setLineNumber((int) Double.parseDouble(
					row.getCell(lineIndex) == null ? "0" : row.getCell(lineIndex).getStringCellValue().trim()));
			pocS4FinalOutput2List.setStatement(
					row.getCell(statementIndex) == null ? "" : row.getCell(statementIndex).getStringCellValue());
			pocS4FinalOutput2List.setOperations(
					row.getCell(operationIndex) == null ? "" : row.getCell(operationIndex).getStringCellValue());
			pocS4FinalOutput2List.setImpactReason(
					row.getCell(impactReasonIndex) == null ? "" : row.getCell(impactReasonIndex).getStringCellValue());
			pocS4FinalOutput2List.setAffectedObjectDescription(
					row.getCell(affctedObjIndex) == null ? "" : row.getCell(affctedObjIndex).getStringCellValue());
			pocS4FinalOutput2List
					.setDescOfChange(row.getCell(descIndex) == null ? "" : row.getCell(descIndex).getStringCellValue());
			pocS4FinalOutput2List.setSapNotes(
					row.getCell(noteNumberIndex) == null ? "" : row.getCell(noteNumberIndex).getStringCellValue());
			pocS4FinalOutput2List.setSolutionSteps(
					row.getCell(solStepsIndex) == null ? "" : row.getCell(solStepsIndex).getStringCellValue());
			pocS4FinalOutput2List.setComplexity(
					row.getCell(complexityIndex) == null ? "" : row.getCell(complexityIndex).getStringCellValue());
			pocS4FinalOutput2List.setIssueCategory(
					row.getCell(issueCatIndex) == null ? "" : row.getCell(issueCatIndex).getStringCellValue());
			pocS4FinalOutput2List.setErrorCategory(
					row.getCell(errorCatIndex) == null ? "" : row.getCell(errorCatIndex).getStringCellValue());
			pocS4FinalOutput2List.setTriggerObject(
					row.getCell(triggerObjIndex) == null ? "" : row.getCell(triggerObjIndex).getStringCellValue());
			pocS4FinalOutput2List.setRemediCategory(
					row.getCell(remidiCatIndex) == null ? "" : row.getCell(remidiCatIndex).getStringCellValue());
			pocS4FinalOutput2List.setSapSimpliListChapter(row.getCell(sapSimpliListIndex) == null ? ""
					: row.getCell(sapSimpliListIndex).getStringCellValue());
			pocS4FinalOutput2List.setAppComponent(
					row.getCell(appComponentIndex) == null ? "" : row.getCell(appComponentIndex).getStringCellValue());
			pocS4FinalOutput2List.setSapSimpliCategory(
					row.getCell(sapSimpliCatIndex) == null ? "" : row.getCell(sapSimpliCatIndex).getStringCellValue());
			pocS4FinalOutput2List
					.setItemArea(row.getCell(itemIndex) == null ? "" : row.getCell(itemIndex).getStringCellValue());

			return pocS4FinalOutput2List;
		}
		return null;
	}

	// DDR3 Sheet:::::::::::::::::::::::::::::::::::::::
	public POC_DRS4Simplification3 getS4Simplification3ListValueXlsx(Row row, long requestId, String fileName) {

		int typeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Type"));
		int objNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name"));
		int usedIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Used"));
		int subObjIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sub.Obj"));
		int methodIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Method"));
		int objPackageIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Pckg"));
		int impactedObjTypeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Impacted.Obj.Type"));
		int lineIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Line.No"));
		int statementIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Stmt"));
		int operationIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Operation"));
		int impactReasonIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Impact.Reason"));
		int affctedObjIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Affected.Obj.Desc"));
		int descIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Desc"));
		int noteNumberIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Note.No"));
		int solStepsIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Solution.Steps"));
		int complexityIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Complexity"));
		int issueCatIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Issue.Category"));
		int errorCatIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Error.Category"));
		int triggerObjIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Trigger.Object"));
		int remidiCatIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Remediation.Category"));
		int sapSimpliListIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("SAP.Simpli.List.Chapter"));
		int appComponentIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("App.Component"));
		int sapSimpliCatIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Simpli.Category"));
		int itemIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Item.Area"));

		String type = row.getCell(typeIndex) == null ? "" : row.getCell(typeIndex).getStringCellValue();

		if (!type.equals("")) {
			final POC_DRS4Simplification3 pocS4FinalOutput3List = new POC_DRS4Simplification3();

			pocS4FinalOutput3List.setType(type);
			pocS4FinalOutput3List
					.setObject(row.getCell(objNameIndex) == null ? "" : row.getCell(objNameIndex).getStringCellValue());
			pocS4FinalOutput3List.setSubObject(
					row.getCell(subObjIndex) == null ? "" : row.getCell(subObjIndex).getStringCellValue());
			pocS4FinalOutput3List
					.setUsed(row.getCell(usedIndex) == null ? "" : row.getCell(usedIndex).getStringCellValue());
			pocS4FinalOutput3List
					.setMethod(row.getCell(methodIndex) == null ? "" : row.getCell(methodIndex).getStringCellValue());
			pocS4FinalOutput3List.setPkg(
					row.getCell(objPackageIndex) == null ? "" : row.getCell(objPackageIndex).getStringCellValue());
			pocS4FinalOutput3List.setImpactedObjectType(row.getCell(impactedObjTypeIndex) == null ? ""
					: row.getCell(impactedObjTypeIndex).getStringCellValue());
			pocS4FinalOutput3List.setLineNumber((int) Double.parseDouble(
					row.getCell(lineIndex) == null ? "0" : row.getCell(lineIndex).getStringCellValue().trim()));
			pocS4FinalOutput3List.setStatement(
					row.getCell(statementIndex) == null ? "" : row.getCell(statementIndex).getStringCellValue());
			pocS4FinalOutput3List.setOperations(
					row.getCell(operationIndex) == null ? "" : row.getCell(operationIndex).getStringCellValue());
			pocS4FinalOutput3List.setImpactReason(
					row.getCell(impactReasonIndex) == null ? "" : row.getCell(impactReasonIndex).getStringCellValue());
			pocS4FinalOutput3List.setAffectedObjectDescription(
					row.getCell(affctedObjIndex) == null ? "" : row.getCell(affctedObjIndex).getStringCellValue());
			pocS4FinalOutput3List.setDescriptionOfChange(
					row.getCell(descIndex) == null ? "" : row.getCell(descIndex).getStringCellValue());
			pocS4FinalOutput3List.setSapNotes(
					row.getCell(noteNumberIndex) == null ? "" : row.getCell(noteNumberIndex).getStringCellValue());
			pocS4FinalOutput3List.setSolutionSteps(
					row.getCell(solStepsIndex) == null ? "" : row.getCell(solStepsIndex).getStringCellValue());
			pocS4FinalOutput3List.setComplexity(
					row.getCell(complexityIndex) == null ? "" : row.getCell(complexityIndex).getStringCellValue());
			pocS4FinalOutput3List.setIssueCategory(
					row.getCell(issueCatIndex) == null ? "" : row.getCell(issueCatIndex).getStringCellValue());
			pocS4FinalOutput3List.setErrorCategory(
					row.getCell(errorCatIndex) == null ? "" : row.getCell(errorCatIndex).getStringCellValue());
			pocS4FinalOutput3List.setTriggerObject(
					row.getCell(triggerObjIndex) == null ? "" : row.getCell(triggerObjIndex).getStringCellValue());
			pocS4FinalOutput3List.setRemediationCategory(
					row.getCell(remidiCatIndex) == null ? "" : row.getCell(remidiCatIndex).getStringCellValue());
			pocS4FinalOutput3List.setSapSimplificationListChapter(row.getCell(sapSimpliListIndex) == null ? ""
					: row.getCell(sapSimpliListIndex).getStringCellValue());
			pocS4FinalOutput3List.setApplicationComponent(
					row.getCell(appComponentIndex) == null ? "" : row.getCell(appComponentIndex).getStringCellValue());
			pocS4FinalOutput3List.setSapSimplCategory(
					row.getCell(sapSimpliCatIndex) == null ? "" : row.getCell(sapSimpliCatIndex).getStringCellValue());
			pocS4FinalOutput3List
					.setItemArea(row.getCell(itemIndex) == null ? "" : row.getCell(itemIndex).getStringCellValue());

			return pocS4FinalOutput3List;
		}
		return null;
	}

	// UI5 Final Output
	public POC_Ui5FinalOutput getUI5FinalOutputListValueXlsx(Row row, long requestId, String fileName) {

		int uiElementIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("UI.Element"));
		int attributeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Attribute"));
		int typeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Type"));
		int descIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Desc"));
		int versionIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Version"));
		int lineNoIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Line.No"));
		int projectNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Project.Name"));
		int fileNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("File.Name"));
		int statusIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Status"));
		int msgIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Message"));
		int apiIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Api.Reference"));

		final POC_Ui5FinalOutput pocUi5FinalOutputList = new POC_Ui5FinalOutput();

		pocUi5FinalOutputList.setUiElement(
				row.getCell(uiElementIndex) == null ? "" : row.getCell(uiElementIndex).getStringCellValue());
		pocUi5FinalOutputList.setAttribute(
				row.getCell(attributeIndex) == null ? "" : row.getCell(attributeIndex).getStringCellValue());
		pocUi5FinalOutputList
				.setType(row.getCell(typeIndex) == null ? "" : row.getCell(typeIndex).getStringCellValue());
		pocUi5FinalOutputList
				.setDescription(row.getCell(descIndex) == null ? "" : row.getCell(descIndex).getStringCellValue());
		pocUi5FinalOutputList
				.setVersion(row.getCell(versionIndex) == null ? "" : row.getCell(versionIndex).getStringCellValue());
		pocUi5FinalOutputList
				.setLineNumber(row.getCell(lineNoIndex) == null ? "" : row.getCell(lineNoIndex).getStringCellValue());
		pocUi5FinalOutputList.setProjectName(
				row.getCell(projectNameIndex) == null ? "" : row.getCell(projectNameIndex).getStringCellValue());
		pocUi5FinalOutputList
				.setFileName(row.getCell(fileNameIndex) == null ? "" : row.getCell(fileNameIndex).getStringCellValue());
		pocUi5FinalOutputList
				.setStatus(row.getCell(statusIndex) == null ? "" : row.getCell(statusIndex).getStringCellValue());
		pocUi5FinalOutputList
				.setMessage(row.getCell(msgIndex) == null ? "" : row.getCell(msgIndex).getStringCellValue());
		pocUi5FinalOutputList
				.setApiReference(row.getCell(apiIndex) == null ? "" : row.getCell(apiIndex).getStringCellValue());
		pocUi5FinalOutputList.setRequestId(requestId);

		return pocUi5FinalOutputList;
	}

	// UI5 High Level Report:::::::::::::::::::::::
	public POC_Ui5HighLevelReport getUi5HighLevelReportValueXlsx(Row row, long requestId, String fileName) {

		int projectNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Project.Name"));
		int totalIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Total.API.Count"));
		int depricatedIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Depricated.API.Count"));
		int nonValidIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("NonValid.API"));
		int changeIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("RecommendedChanges.API"));
		int finalMsgIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Final.Msg"));

		final POC_Ui5HighLevelReport pocUi5HighLevelReportList = new POC_Ui5HighLevelReport();

		pocUi5HighLevelReportList.setProjectName(
				row.getCell(projectNameIndex) == null ? "" : row.getCell(projectNameIndex).getStringCellValue());
		pocUi5HighLevelReportList
				.setTotalApiCounts(row.getCell(totalIndex) == null ? "" : row.getCell(totalIndex).getStringCellValue());
		pocUi5HighLevelReportList.setDepricatedApiCounts(
				row.getCell(depricatedIndex) == null ? "" : row.getCell(depricatedIndex).getStringCellValue());
		pocUi5HighLevelReportList.setNonValidApiCounts(
				row.getCell(nonValidIndex) == null ? "" : row.getCell(nonValidIndex).getStringCellValue());
		pocUi5HighLevelReportList.setRecommendedChangesApiCounts(
				row.getCell(changeIndex) == null ? "" : row.getCell(changeIndex).getStringCellValue());
		pocUi5HighLevelReportList.setFinalMessage(
				row.getCell(finalMsgIndex) == null ? "" : row.getCell(finalMsgIndex).getStringCellValue());
		pocUi5HighLevelReportList.setRequestId(requestId);

		return pocUi5HighLevelReportList;

	}

	// Testing Scope::::::::::
	public POC_TestingScope getTestingScopeValueXlsx(Row row, long requestId, String fileName) {

		int objTypeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Type"));
		int objNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name"));
		int opcodeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Opercd"));
		int appComponentIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("App.Component"));
		int appCompDescIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("AppComp.Desc"));
		int roleIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Role"));
		int processIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Process"));
		int transactionsIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Transactions"));

		final POC_TestingScope pocTestingScopeList = new POC_TestingScope();

		pocTestingScopeList
				.setObject(row.getCell(objTypeIndex) == null ? "" : row.getCell(objTypeIndex).getStringCellValue());
		pocTestingScopeList
				.setObjName(row.getCell(objNameIndex) == null ? "" : row.getCell(objNameIndex).getStringCellValue());
		pocTestingScopeList
				.setOpercd(row.getCell(opcodeIndex) == null ? "" : row.getCell(opcodeIndex).getStringCellValue());
		pocTestingScopeList.setApplicationComponent(
				row.getCell(appComponentIndex) == null ? "" : row.getCell(appComponentIndex).getStringCellValue());
		pocTestingScopeList.setAppCompDesc(
				row.getCell(appCompDescIndex) == null ? "" : row.getCell(appCompDescIndex).getStringCellValue());
		pocTestingScopeList.setRole(row.getCell(roleIndex) == null ? "" : row.getCell(roleIndex).getStringCellValue());
		pocTestingScopeList
				.setProcess(row.getCell(processIndex) == null ? "" : row.getCell(processIndex).getStringCellValue());
		pocTestingScopeList.setTransactions(
				row.getCell(transactionsIndex) == null ? "" : row.getCell(transactionsIndex).getStringCellValue());
		pocTestingScopeList.setRequestId(requestId);

		return pocTestingScopeList;
	}

	// Impacted Background Job
	public POC_ImpactedBackgroundJob getImpactedBackgroundJobValueXlsx(Row row, long requestId, String fileName) {

		int objIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Object"));
		int backgroundJobIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Background.Job.Name"));
		int progNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Program.Name"));
		int variantIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Variant"));
		int tcodeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Tcode"));
		int runIndex = Integer.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Run"));
		int extNamespaceIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("External.Namespace"));

		final POC_ImpactedBackgroundJob pocImpactedBackgroundJobList = new POC_ImpactedBackgroundJob();

		pocImpactedBackgroundJobList
				.setObject(row.getCell(objIndex) == null ? "" : row.getCell(objIndex).getStringCellValue());
		pocImpactedBackgroundJobList.setBackgroundJobName(
				row.getCell(backgroundJobIndex) == null ? "" : row.getCell(backgroundJobIndex).getStringCellValue());
		pocImpactedBackgroundJobList.setProgramName(
				row.getCell(progNameIndex) == null ? "" : row.getCell(progNameIndex).getStringCellValue());
		pocImpactedBackgroundJobList
				.setVariant(row.getCell(variantIndex) == null ? "" : row.getCell(variantIndex).getStringCellValue());
		pocImpactedBackgroundJobList
				.setTcode(row.getCell(tcodeIndex) == null ? "" : row.getCell(tcodeIndex).getStringCellValue());
		pocImpactedBackgroundJobList
				.setRun(row.getCell(runIndex) == null ? "" : row.getCell(runIndex).getStringCellValue());
		pocImpactedBackgroundJobList.setExternalNamespace(
				row.getCell(extNamespaceIndex) == null ? "" : row.getCell(extNamespaceIndex).getStringCellValue());

		pocImpactedBackgroundJobList.setRequestId(requestId);

		return pocImpactedBackgroundJobList;

	}

	// Smodilog
	public POC_Smodilog getSmodilogValueXlsx(Row row, long requestId, String fileName) {
		int objTypeIdex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Type"));
		int objNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name"));
		int subTypeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sub.Type"));
		int subNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sub.Name"));
		int intTypeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Int.Type"));
		int intNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Int.Name"));
		int modUserIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Mod.User"));
		int modDateIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Mod.Date"));
		int modTimeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Mod.Time"));
		int trkorrIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Trkorr"));

		final POC_Smodilog pocSmodilogList = new POC_Smodilog();

		pocSmodilogList
				.setObjType(row.getCell(objTypeIdex) == null ? "" : row.getCell(objTypeIdex).getStringCellValue());
		pocSmodilogList
				.setObjName(row.getCell(objNameIndex) == null ? "" : row.getCell(objNameIndex).getStringCellValue());
		pocSmodilogList
				.setSubType(row.getCell(subTypeIndex) == null ? "" : row.getCell(subTypeIndex).getStringCellValue());
		pocSmodilogList
				.setSubName(row.getCell(subNameIndex) == null ? "" : row.getCell(subNameIndex).getStringCellValue());
		pocSmodilogList
				.setIntType(row.getCell(intTypeIndex) == null ? "" : row.getCell(intTypeIndex).getStringCellValue());
		pocSmodilogList
				.setIntName(row.getCell(intNameIndex) == null ? "" : row.getCell(intNameIndex).getStringCellValue());
		pocSmodilogList
				.setModUser(row.getCell(modUserIndex) == null ? "" : row.getCell(modUserIndex).getStringCellValue());
		pocSmodilogList
				.setModDate(row.getCell(modDateIndex) == null ? "" : row.getCell(modDateIndex).getStringCellValue());
		pocSmodilogList
				.setModTime(row.getCell(modTimeIndex) == null ? "" : row.getCell(modTimeIndex).getStringCellValue());
		pocSmodilogList
				.setTrkorr(row.getCell(trkorrIndex) == null ? "" : row.getCell(trkorrIndex).getStringCellValue());
		pocSmodilogList.setRequestId(requestId);

		return pocSmodilogList;
	}

	public POC_ImpactedSAPScript getImpactedSAPScriptValueXlsx(Row row, long requestId, String fileName) {

		int programIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Prog"));
		int impactedSapScriptIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Impacted.Sap.Script"));
		int dbImpactIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("DB.Impact"));
		int s4SimplificationIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("S4.Simplification"));
		int existingErrorIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Existing.Error"));
		int remediationCategory = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Remediation.Category"));
		int extNamespaceIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("External.Namespace"));
		String extNamespace = row.getCell(extNamespaceIndex) == null ? "" : row.getCell(extNamespaceIndex).getStringCellValue().trim();
		
		final POC_ImpactedSAPScript pocImpactedSAPScriptList = new POC_ImpactedSAPScript();

		pocImpactedSAPScriptList.setExternalNamespace(extNamespace);
		pocImpactedSAPScriptList
				.setProgram(row.getCell(programIndex) == null ? "" : row.getCell(programIndex).getStringCellValue());
		pocImpactedSAPScriptList.setImpactedSapScript(row.getCell(impactedSapScriptIndex) == null ? ""
				: row.getCell(impactedSapScriptIndex).getStringCellValue());
		pocImpactedSAPScriptList
				.setDbImpact(row.getCell(dbImpactIndex) == null ? "" : row.getCell(dbImpactIndex).getStringCellValue());
		pocImpactedSAPScriptList.setS4Simplification(row.getCell(s4SimplificationIndex) == null ? ""
				: row.getCell(s4SimplificationIndex).getStringCellValue());
		pocImpactedSAPScriptList.setExistingError(
				row.getCell(existingErrorIndex) == null ? "" : row.getCell(existingErrorIndex).getStringCellValue());
		pocImpactedSAPScriptList.setRemediationCategory(
				row.getCell(remediationCategory) == null ? "" : row.getCell(remediationCategory).getStringCellValue());

		pocImpactedSAPScriptList.setObjType(null);
		pocImpactedSAPScriptList.setObjNameType(null);
		pocImpactedSAPScriptList.setOpCode(null);
		pocImpactedSAPScriptList.setRequestId(requestId);
		return pocImpactedSAPScriptList;
	}

	public POC_ImpactedCloneAnalysis getImpactedCloneAnalysisValueXlsx(Row row, long requestId, String fileName) {

		int namespaceIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Namespace"));
		int objTypeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Type"));
		int objNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name"));
		int packageIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Package"));
		int creationDateIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Creation.Date"));
		int creationYearIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Creation.Year"));
		int interfaceObjTypeIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Interface.Obj.Type"));
		int interfaceObjIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Interface.Obj"));
		int referenceIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Reference"));
		int referencePercentIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Reference.Percent"));
		int appComponentIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("App.Component"));
		int usedIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Used"));
		int impactedDBIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Impacted.DB"));
		int impactedSimplificationIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Impacted.Simplification"));
		int impactedExistingErrorsIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Impacted.Existing.Errors"));
		int impactedOSMigrationIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Impacted.OSMigration"));
		int extNamespaceIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("External.Namespace"));

		String namespace = row.getCell(namespaceIndex) == null ? "" : row.getCell(namespaceIndex).getStringCellValue();
		String objType = row.getCell(objTypeIndex) == null ? "" : row.getCell(objTypeIndex).getStringCellValue();
		String objName = row.getCell(objNameIndex) == null ? "" : row.getCell(objNameIndex).getStringCellValue();
		String objPackage = row.getCell(packageIndex) == null ? "" : row.getCell(packageIndex).getStringCellValue();
		String creationDate = row.getCell(creationDateIndex) == null ? ""
				: row.getCell(creationDateIndex).getStringCellValue();
		String creationYear = row.getCell(creationYearIndex) == null ? ""
				: row.getCell(creationYearIndex).getStringCellValue();
		String interfaceObjType = row.getCell(interfaceObjTypeIndex) == null ? ""
				: row.getCell(interfaceObjTypeIndex).getStringCellValue();
		String interfaceObj = row.getCell(interfaceObjIndex) == null ? ""
				: row.getCell(interfaceObjIndex).getStringCellValue();
		String reference = row.getCell(referenceIndex) == null ? "" : row.getCell(referenceIndex).getStringCellValue();
		String referencePercent = row.getCell(referencePercentIndex) == null ? ""
				: row.getCell(referencePercentIndex).getStringCellValue();
		String appComponent = row.getCell(appComponentIndex) == null ? ""
				: row.getCell(appComponentIndex).getStringCellValue();

		String used = row.getCell(usedIndex) == null ? "" : row.getCell(usedIndex).getStringCellValue();
		String impactedDB = row.getCell(impactedDBIndex) == null ? ""
				: row.getCell(impactedDBIndex).getStringCellValue();
		String impactedSimplification = row.getCell(impactedSimplificationIndex) == null ? ""
				: row.getCell(impactedSimplificationIndex).getStringCellValue();
		String impactedExistingErrors = row.getCell(impactedExistingErrorsIndex) == null ? ""
				: row.getCell(impactedExistingErrorsIndex).getStringCellValue();
		String impactedOSMigration = row.getCell(impactedOSMigrationIndex) == null ? ""
				: row.getCell(impactedOSMigrationIndex).getStringCellValue();
		String extNamespace = row.getCell(extNamespaceIndex) == null ? ""
				: row.getCell(extNamespaceIndex).getStringCellValue();
		String objTypeName = objType.concat(objName);
		String interfaceConcat = interfaceObj.concat(interfaceObjType);

		if (!objType.equals("") && !objName.equals("")) {
			final POC_ImpactedCloneAnalysis impactedCloneAnalysis = new POC_ImpactedCloneAnalysis();

			impactedCloneAnalysis.setNamespace(namespace);
			impactedCloneAnalysis.setObjType(objType);
			impactedCloneAnalysis.setObjName(objName);
			impactedCloneAnalysis.setObjPackage(objPackage);
			impactedCloneAnalysis.setCreationDate(creationDate);
			impactedCloneAnalysis.setInterfaceObjType(interfaceObjType);
			impactedCloneAnalysis.setInterfaceObj(interfaceObj);
			impactedCloneAnalysis.setReference(reference);
			impactedCloneAnalysis.setReferencePercent(referencePercent);
			impactedCloneAnalysis.setAppComponent(appComponent);

			impactedCloneAnalysis.setUsed(used);
			impactedCloneAnalysis.setImpactedDB(impactedDB);
			impactedCloneAnalysis.setImpactedSimpl(impactedSimplification);
			impactedCloneAnalysis.setImpactedExistingError(impactedExistingErrors);
			impactedCloneAnalysis.setImpactedOSMigration(impactedOSMigration);

			impactedCloneAnalysis.setInterfaceConcat(interfaceConcat);
			impactedCloneAnalysis.setObjTypeName(objTypeName);
			impactedCloneAnalysis.setYear(creationYear);

			impactedCloneAnalysis.setRequestId(requestId);
			impactedCloneAnalysis.setExternalNamespace(extNamespace);

			return impactedCloneAnalysis;
		}

		return null;
	}

	public POC_OS_Migration getOSMigrationValueXlsx(Row row, long requestId, String fileName) {
		POC_OS_Migration pocOSMigartionOutput = null;
		String type = "", objName = "", subObjName = "", readPrg = "", objPackage = "", stmt = "", remidiCat = "",
				issueCat = "", issueSubCat = "", desc = "", solSteps = "", impact = "", automationStatus = "",
				complexity = "", opCode = "", used = "", extNamespace = "";
		Integer line = 0;

		int typeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Type"));
		int objNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name"));
		int subObjNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sub.Obj.Name"));
		int readPrgIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Read.Program"));
		int objPackageIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Package"));
		int opCodeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Operation.code"));
		int lineIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Line.No"));
		int stmtIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Statement"));
		int remidiCatIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Remediation.Category"));
		int issueCatIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Issue.Category"));
		int issueSubCatIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sub.Category"));
		int descIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Desc"));
		int solStepsIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Solution.Steps"));
		int automationStatusIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Automation.Status"));
		int complexityIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Complexity"));
		int usedIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Used"));
		int impactIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Impact"));
		int extNamespaceIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("External.Namespace"));
		int ricefwCategoryIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("RICEFW.Category"));
		int ricefwSubCategoryIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("RICEFW.Sub.Category"));
		
		String ricefwCategory = row.getCell(ricefwCategoryIndex) == null ? "" : row.getCell(ricefwCategoryIndex).getStringCellValue().trim();
		String ricefwSubCategory = row.getCell(ricefwSubCategoryIndex) == null ? "" : row.getCell(ricefwSubCategoryIndex).getStringCellValue().trim();
		
		type = row.getCell(typeIndex) == null ? "" : row.getCell(typeIndex).getStringCellValue().trim().toUpperCase();
		objName = row.getCell(objNameIndex) == null ? "" : row.getCell(objNameIndex).getStringCellValue().trim().toUpperCase();
		subObjName = row.getCell(subObjNameIndex) == null ? "" : row.getCell(subObjNameIndex).getStringCellValue().trim();
		readPrg = row.getCell(readPrgIndex) == null ? "" : row.getCell(readPrgIndex).getStringCellValue().trim();
		objPackage = row.getCell(objPackageIndex) == null ? "" : row.getCell(objPackageIndex).getStringCellValue().trim();
		opCode = row.getCell(opCodeIndex) == null ? "" : row.getCell(opCodeIndex).getStringCellValue().trim();
		line = Integer.parseInt(row.getCell(lineIndex) == null ? "" : row.getCell(lineIndex).getStringCellValue().trim());
		stmt = row.getCell(stmtIndex) == null ? "" : row.getCell(stmtIndex).getStringCellValue().trim();
		remidiCat = row.getCell(remidiCatIndex) == null ? "" : row.getCell(remidiCatIndex).getStringCellValue().trim().toUpperCase();
		issueCat = row.getCell(issueCatIndex) == null ? "" : row.getCell(issueCatIndex).getStringCellValue().trim();
		issueSubCat = row.getCell(issueSubCatIndex) == null ? "" : row.getCell(issueSubCatIndex).getStringCellValue().trim();
		desc = row.getCell(descIndex) == null ? "" : row.getCell(descIndex).getStringCellValue().trim().toUpperCase();
		solSteps = row.getCell(solStepsIndex) == null ? "" : row.getCell(solStepsIndex).getStringCellValue().trim();
		automationStatus = row.getCell(automationStatusIndex) == null ? ""
				: row.getCell(automationStatusIndex).getStringCellValue().trim();
		complexity = row.getCell(complexityIndex) == null ? "" : row.getCell(complexityIndex).getStringCellValue().trim();
		used = row.getCell(usedIndex) == null ? "" : row.getCell(usedIndex).getStringCellValue().trim();
		impact = row.getCell(impactIndex) == null ? "" : row.getCell(impactIndex).getStringCellValue().trim();
		extNamespace = row.getCell(extNamespaceIndex) == null ? ""
				: row.getCell(extNamespaceIndex).getStringCellValue().trim();

		pocOSMigartionOutput = new POC_OS_Migration();
		
		pocOSMigartionOutput.setRicefwCategory(ricefwCategory);
		pocOSMigartionOutput.setRicefwSubCategory(ricefwSubCategory);
		pocOSMigartionOutput.setObjType(type);
		pocOSMigartionOutput.setObjName(objName);
		pocOSMigartionOutput.setSubType(subObjName);
		pocOSMigartionOutput.setReadProgram(readPrg);
		pocOSMigartionOutput.setObjPackage(objPackage);
		pocOSMigartionOutput.setOperationCode(opCode);
		pocOSMigartionOutput.setLineNo(line);
		pocOSMigartionOutput.setStatement(stmt);
		pocOSMigartionOutput.setRemCategory(remidiCat);
		pocOSMigartionOutput.setIssueCategory(issueCat);
		pocOSMigartionOutput.setIssueSubcategory(issueSubCat);
		pocOSMigartionOutput.setInfo(desc);
		pocOSMigartionOutput.setHighLvlDesc(solSteps);
		pocOSMigartionOutput.setAutomationStatus(automationStatus);
		pocOSMigartionOutput.setComplexity(complexity);
		pocOSMigartionOutput.setUsed(used);
		pocOSMigartionOutput.setImpact(impact);
		pocOSMigartionOutput.setRequestID(requestId);
		pocOSMigartionOutput.setExternalNamespace(extNamespace);

		return pocOSMigartionOutput;
	}

	public POC_OS_Migration_LogicalCMD getOSMigrationLogicalCMDValueXlsx(Row row, long requestId, String fileName) {
		POC_OS_Migration_LogicalCMD pocOSMigartionOutput = null;
		String type = "", objName = "", stmt = "", remidiCat = "", issueCat = "", issueSubCat = "", desc = "",
				solSteps = "", impact = "", automationStatus = "", complexity = "";

		int objNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name"));
		int stmtIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Statement"));
		int remidiCatIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Remediation.Category"));
		int issueCatIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Issue.Category"));
		int issueSubCatIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sub.Category"));
		int descIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Desc"));
		int solStepsIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Solution.Steps"));
		int automationStatusIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Automation.Status"));
		int complexityIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Complexity"));
		int impactIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Impact"));

		type = "TABU";
		objName = row.getCell(objNameIndex) == null ? "" : row.getCell(objNameIndex).getStringCellValue().trim().toUpperCase();
		stmt = row.getCell(stmtIndex) == null ? "" : row.getCell(stmtIndex).getStringCellValue().trim();
		remidiCat = row.getCell(remidiCatIndex) == null ? "" : row.getCell(remidiCatIndex).getStringCellValue().trim().toUpperCase();
		issueCat = row.getCell(issueCatIndex) == null ? "" : row.getCell(issueCatIndex).getStringCellValue().trim();
		issueSubCat = row.getCell(issueSubCatIndex) == null ? "" : row.getCell(issueSubCatIndex).getStringCellValue().trim();
		desc = row.getCell(descIndex) == null ? "" : row.getCell(descIndex).getStringCellValue().trim();
		solSteps = row.getCell(solStepsIndex) == null ? "" : row.getCell(solStepsIndex).getStringCellValue().trim();
		automationStatus = row.getCell(automationStatusIndex) == null ? ""
				: row.getCell(automationStatusIndex).getStringCellValue().trim();
		complexity = row.getCell(complexityIndex) == null ? "" : row.getCell(complexityIndex).getStringCellValue().trim();
		impact = row.getCell(impactIndex) == null ? "" : row.getCell(impactIndex).getStringCellValue().trim();

		pocOSMigartionOutput = new POC_OS_Migration_LogicalCMD();
		pocOSMigartionOutput.setObjType(type);
		pocOSMigartionOutput.setReadProgram(objName);// objectName = readProgram
		pocOSMigartionOutput.setStatement(stmt);
		pocOSMigartionOutput.setRemCategory(remidiCat);
		pocOSMigartionOutput.setIssueCategory(issueCat);
		pocOSMigartionOutput.setIssueSubcategory(issueSubCat);
		pocOSMigartionOutput.setInfo(desc);
		pocOSMigartionOutput.setHighLvlDesc(solSteps);
		pocOSMigartionOutput.setAutomationStatus(automationStatus);
		pocOSMigartionOutput.setComplexity(complexity);
		pocOSMigartionOutput.setImpact(impact);
		pocOSMigartionOutput.setRequestID(requestId);

		return pocOSMigartionOutput;

	}

	public POC_OS_Migration_FilePath getOSMigrationFilePathValueXlsx(Row row, long requestId, String fileName) {
		POC_OS_Migration_FilePath pocOSMigartionOutput = null;
		String objName = "", subType = "", stmt = "", remidiCat = "", desc = "", solSteps = "", impact = "", skip = "",
				skipReason = "";

		int subTypeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sub.Type"));
		int objNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name"));
		int stmtIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Statement"));
		int remidiCatIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Remediation.Category"));
		int descIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Desc"));
		int solStepsIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Solution.Steps"));
		int impactIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Impact"));
		int skipIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Skip"));
		int skipReasonIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Skip.Reason"));

		subType = row.getCell(subTypeIndex) == null ? "" : row.getCell(subTypeIndex).getStringCellValue().trim();
		objName = row.getCell(objNameIndex) == null ? "" : row.getCell(objNameIndex).getStringCellValue().trim().toUpperCase();
		stmt = row.getCell(stmtIndex) == null ? "" : row.getCell(stmtIndex).getStringCellValue().trim();
		remidiCat = row.getCell(remidiCatIndex) == null ? "" : row.getCell(remidiCatIndex).getStringCellValue().trim().toUpperCase();
		desc = row.getCell(descIndex) == null ? "" : row.getCell(descIndex).getStringCellValue().trim();
		solSteps = row.getCell(solStepsIndex) == null ? "" : row.getCell(solStepsIndex).getStringCellValue().trim();
		impact = row.getCell(impactIndex) == null ? "" : row.getCell(impactIndex).getStringCellValue().trim();
		skip = row.getCell(skipIndex) == null ? "" : row.getCell(skipIndex).getStringCellValue().trim();
		skipReason = row.getCell(skipReasonIndex) == null ? "" : row.getCell(skipReasonIndex).getStringCellValue().trim();

		pocOSMigartionOutput = new POC_OS_Migration_FilePath();

		pocOSMigartionOutput.setSubType(subType);
		pocOSMigartionOutput.setObjName(objName);
		pocOSMigartionOutput.setStatement(stmt);
		pocOSMigartionOutput.setRemCategory(remidiCat);
		pocOSMigartionOutput.setInfo(desc);
		pocOSMigartionOutput.setHighLvlDesc(solSteps);
		pocOSMigartionOutput.setImpact(impact);
		pocOSMigartionOutput.setSkip(skip);
		pocOSMigartionOutput.setSkipReason(skipReason);
		pocOSMigartionOutput.setRequestID(requestId);

		return pocOSMigartionOutput;

	}

	public POC_InconsistentFUGR getInconsistentFUGR(Row row, long requestId, String fileName) {
		POC_InconsistentFUGR inconsistentFUGR = null;
		int objTypeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Type"));
		int fugrNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("FUGR.Name"));
		int masterProgramIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Master.Program"));
		int extNamespaceIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("External.Namespace"));
		
		String extNamespace = row.getCell(extNamespaceIndex) == null ? "" : row.getCell(extNamespaceIndex).getStringCellValue().trim();

		String objType = row.getCell(objTypeIndex) == null ? "" : row.getCell(objTypeIndex).getStringCellValue();
		String fugrName = row.getCell(fugrNameIndex) == null ? "" : row.getCell(fugrNameIndex).getStringCellValue();
		String masterProgram = row.getCell(masterProgramIndex) == null ? ""
				: row.getCell(masterProgramIndex).getStringCellValue();
		if (objType != null && !objType.isEmpty()) {
			inconsistentFUGR = new POC_InconsistentFUGR();
			
			inconsistentFUGR.setExternalNamespace(extNamespace);
			inconsistentFUGR.setObjectType(objType);
			inconsistentFUGR.setFugrName(fugrName);
			inconsistentFUGR.setMasterProgram(masterProgram);
			inconsistentFUGR.setRequestId(requestId);
		}

		return inconsistentFUGR;
	}

	public POC_S4_SID getS4SID(Row row, long requestId, String fileName) {
		POC_S4_SID s4SID = null;
		int objTypeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Type"));
		int objNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name"));
		int subObjNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sub.Obj.Name"));
		int readProgramIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Read.Program"));
		int pkgIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Package"));
		int operationIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Operation"));
		int lineNumberIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Line.No"));
		int stmntIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Statement"));
		int impactReasonIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Impact.reason"));
		int descIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Desc"));
		int solnStepIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Solution.Step"));
		int complexityIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Complexity"));
		int issueCatIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Issue.Category"));
		int usedIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Used"));
		int autoStatusIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Automation.Status"));
		int totalLinesScanIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Total.Lines.Scanned"));
		int extNamespaceIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("External.Namespace"));
		String extNamespace = row.getCell(extNamespaceIndex) == null ? "" : row.getCell(extNamespaceIndex).getStringCellValue().trim();
		
		String objType = row.getCell(objTypeIndex) == null ? "" : row.getCell(objTypeIndex).getStringCellValue();
		String objName = row.getCell(objNameIndex) == null ? "" : row.getCell(objNameIndex).getStringCellValue();
		String subObjName = row.getCell(subObjNameIndex) == null ? ""
				: row.getCell(subObjNameIndex).getStringCellValue();
		String readProgram = row.getCell(readProgramIndex) == null ? ""
				: row.getCell(readProgramIndex).getStringCellValue();
		String pkg = row.getCell(pkgIndex) == null ? "" : row.getCell(pkgIndex).getStringCellValue();
		String operation = row.getCell(operationIndex) == null ? "" : row.getCell(operationIndex).getStringCellValue();
		String autoStatus = row.getCell(autoStatusIndex) == null ? ""
				: row.getCell(autoStatusIndex).getStringCellValue();
		String used = row.getCell(usedIndex) == null ? "" : row.getCell(usedIndex).getStringCellValue();
		String complexity = row.getCell(complexityIndex) == null ? ""
				: row.getCell(complexityIndex).getStringCellValue();
		String totalLinesScanned = row.getCell(totalLinesScanIndex) == null
				|| Strings.isEmpty(row.getCell(totalLinesScanIndex).getStringCellValue()) ? "0"
						: row.getCell(totalLinesScanIndex).getStringCellValue();
		String solnSteps = row.getCell(solnStepIndex) == null ? "" : row.getCell(solnStepIndex).getStringCellValue();
		String desc = row.getCell(descIndex) == null ? "" : row.getCell(descIndex).getStringCellValue();
		String issueCat = row.getCell(issueCatIndex) == null ? "" : row.getCell(issueCatIndex).getStringCellValue();
		String lineNo = row.getCell(lineNumberIndex) == null ? "" : row.getCell(lineNumberIndex).getStringCellValue();
		String stmnt = row.getCell(stmntIndex) == null ? "" : row.getCell(stmntIndex).getStringCellValue();
		String impactReason = row.getCell(impactReasonIndex) == null ? ""
				: row.getCell(impactReasonIndex).getStringCellValue();

		if (objType != null && !objType.isEmpty()) {
			s4SID = new POC_S4_SID();

			s4SID.setExternalNamespace(extNamespace);
			s4SID.setType(objType);
			s4SID.setObjName(objName);
			s4SID.setObjNameType(objType.concat(objName));
			s4SID.setIdentifier("");
			s4SID.setSubObjType(subObjName);
			s4SID.setReadProgram(readProgram);
			s4SID.setPckg(pkg);
			s4SID.setOperations(operation);
			s4SID.setAutomationStatus(autoStatus);
			s4SID.setUsed(used);
			s4SID.setComplexity(complexity);
			s4SID.setTotalScannedLine(Integer.parseInt(totalLinesScanned));
			s4SID.setSolutionSteps(solnSteps);
			s4SID.setDescOfChange(desc);
			s4SID.setIssueCategory(issueCat);
			s4SID.setLineNo(Integer.parseInt(lineNo));
			s4SID.setStmt(stmnt);
			s4SID.setImpactReason(impactReason);
			s4SID.setRequestID(requestId);
		}

		return s4SID;
	}

	public POC_Impacted_Variant getImpactedVariant(Row row, long requestId, String fileName) {
		POC_Impacted_Variant impactedVariant = new POC_Impacted_Variant();
		int reportNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Report.Name"));
		int variantNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Variant.Name"));
		int selScreenFieldNameIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sel.Scree.Field.Name"));
		int kindIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Kind"));
		int optionIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Option"));
		int lowIndex = Integer.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Low"));
		int highIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("High"));
		int signIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sign"));
		int userNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("User.Name"));
		int variantTypeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Variant.Type"));
		int variantOperationIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Variant.Operation"));
		int commentsIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Comments"));
		int extNamespaceIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("External.Namespace"));
		
		String extNamespace = row.getCell(extNamespaceIndex) == null ? "" : row.getCell(extNamespaceIndex).getStringCellValue().trim();
		
		String reportName = row.getCell(reportNameIndex) == null ? ""
				: row.getCell(reportNameIndex).getStringCellValue();
		String variantName = row.getCell(variantNameIndex) == null ? ""
				: row.getCell(variantNameIndex).getStringCellValue();
		String selScreenFieldName = row.getCell(selScreenFieldNameIndex) == null ? ""
				: row.getCell(selScreenFieldNameIndex).getStringCellValue();
		String kind = row.getCell(kindIndex) == null ? "" : row.getCell(kindIndex).getStringCellValue();
		String sign = row.getCell(signIndex) == null ? "" : row.getCell(signIndex).getStringCellValue();
		String option = row.getCell(optionIndex) == null ? "" : row.getCell(optionIndex).getStringCellValue();
		String low = row.getCell(lowIndex) == null ? "" : row.getCell(lowIndex).getStringCellValue();
		String high = row.getCell(highIndex) == null ? "" : row.getCell(highIndex).getStringCellValue();
		String userName = row.getCell(userNameIndex) == null ? "" : row.getCell(userNameIndex).getStringCellValue();
		String variantType = row.getCell(variantTypeIndex) == null ? ""
				: row.getCell(variantTypeIndex).getStringCellValue();
		String variantOperation = row.getCell(variantOperationIndex) == null ? ""
				: row.getCell(variantOperationIndex).getStringCellValue();
		String comments = row.getCell(commentsIndex) == null ? "" : row.getCell(commentsIndex).getStringCellValue();
		
		impactedVariant.setExternalNamespace(extNamespace);
		impactedVariant.setReportName(reportName);
		impactedVariant.setVariantName(variantName);
		impactedVariant.setSelScreenFieldName(selScreenFieldName);
		impactedVariant.setKind(kind);
		impactedVariant.setSign(sign);
		impactedVariant.setVariantOption(option);
		impactedVariant.setLow(low);
		impactedVariant.setHigh(high);
		impactedVariant.setUserName(userName);
		impactedVariant.setVariantType(variantType);
		impactedVariant.setVariantOperation(variantOperation);
		impactedVariant.setComments(comments);
		impactedVariant.setRequestID(requestId);

		return impactedVariant;
	}

	public POC_NonUnicodeObjects getNonUnicodeObjectsPoc(Row row, long requestId, String fileName) {
		POC_NonUnicodeObjects nonUnicode = new POC_NonUnicodeObjects();
		int objTypeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Object.Type"));
		int progIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("prog"));
		int includeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("include"));
		int rowwIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("roww"));
		int errCodeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("err.code"));
		int msgIndex = Integer.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("msg"));
		int pkgIndex = Integer.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("pkg"));
		int appCompIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("app.comp"));
		int usedIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("used"));
		int extNamespaceIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("external.namespace"));

		String objType = row.getCell(objTypeIndex) == null ? "" : row.getCell(objTypeIndex).getStringCellValue();
		String prog = row.getCell(progIndex) == null ? "" : row.getCell(progIndex).getStringCellValue();
		String include = row.getCell(includeIndex) == null ? "" : row.getCell(includeIndex).getStringCellValue();
		String roww = row.getCell(rowwIndex) == null ? "" : row.getCell(rowwIndex).getStringCellValue();
		String errCode = row.getCell(errCodeIndex) == null ? "" : row.getCell(errCodeIndex).getStringCellValue();
		String msg = row.getCell(msgIndex) == null ? "" : row.getCell(msgIndex).getStringCellValue();
		String pkg = row.getCell(pkgIndex) == null ? "" : row.getCell(pkgIndex).getStringCellValue();
		String appComp = row.getCell(appCompIndex) == null ? "" : row.getCell(appCompIndex).getStringCellValue();
		String used = row.getCell(usedIndex) == null ? "" : row.getCell(usedIndex).getStringCellValue();
		String extNamespace = row.getCell(extNamespaceIndex) == null ? ""
				: row.getCell(extNamespaceIndex).getStringCellValue().trim();

		nonUnicode.setObjType(objType);;
		nonUnicode.setProg(prog);
		nonUnicode.setInclude(include);
		nonUnicode.setRoww(roww);
		nonUnicode.setErrCode(errCode);
		nonUnicode.setMsg(msg);
		nonUnicode.setPkg(pkg);
		nonUnicode.setAppComp(appComp);
		nonUnicode.setUsed(used);
		nonUnicode.setRequestID(requestId);
		nonUnicode.setExternalNamespace(extNamespace);

		return nonUnicode;
	}

	// POC CVITR Output Read Data
	public POC_CVITROutput getCVITROutput(Row row, long requestId, String fileName) {

		int customerNRIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Customer.NRs.Covered"));
		int subIntFromIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sub.Interval.From"));
		int subIntToIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sub.Interval.To"));
		int vendorNRIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("vendor.NRs.Covered"));
		int customerExtIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Customer.Ext"));
		int vendorExtIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Vendor.Ext"));
		
		String cusNR = row.getCell(customerNRIndex) == null ? "" : row.getCell(customerNRIndex).getStringCellValue();
		String subIntfrm = row.getCell(subIntFromIndex) == null ? ""
				: row.getCell(subIntFromIndex).getStringCellValue();
		String subIntTo = row.getCell(subIntToIndex) == null ? "" : row.getCell(subIntToIndex).getStringCellValue();
		String venNR = row.getCell(vendorNRIndex) == null ? "" : row.getCell(vendorNRIndex).getStringCellValue();
		String customerExt = row.getCell(customerExtIndex) == null ? "" : row.getCell(customerExtIndex).getStringCellValue();
		String vendorExt = row.getCell(vendorExtIndex) == null ? "" : row.getCell(vendorExtIndex).getStringCellValue();

		final POC_CVITROutput pocCVTIR = new POC_CVITROutput();

		pocCVTIR.setCustomerNr(cusNR);
		pocCVTIR.setSubIntervalFrom(subIntfrm);
		pocCVTIR.setSubIntervalTo(subIntTo);
		pocCVTIR.setRequestId(requestId);
		pocCVTIR.setVendorNr(venNR);
		pocCVTIR.setCustomerExt(customerExt);
		pocCVTIR.setVendorExt(vendorExt);

		return pocCVTIR;
	}

	// POC BW Inventory Read Data
	public POC_BWInventory getBWInventory(Row row, long requestId, String fileName) {
		int objTypeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Type"));
		int objNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name"));
		int usedIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Used"));
		int profileUsedIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Profiler.Used"));
		int usageCountIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Usage.Count"));
		int transReqIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Transport.Request"));

		String objT = row.getCell(objTypeIndex) == null ? "" : row.getCell(objTypeIndex).getStringCellValue();
		String objN = row.getCell(objNameIndex) == null ? "" : row.getCell(objNameIndex).getStringCellValue();
		String us = row.getCell(usedIndex) == null ? "" : row.getCell(usedIndex).getStringCellValue();
		String pUsed = row.getCell(profileUsedIndex) == null ? "" : row.getCell(profileUsedIndex).getStringCellValue();
		String uCount = row.getCell(usageCountIndex) == null ? "" : row.getCell(usageCountIndex).getStringCellValue();
		String tReq = row.getCell(transReqIndex) == null ? "" : row.getCell(transReqIndex).getStringCellValue();

		final POC_BWInventory pocBWInventory = new POC_BWInventory();

		pocBWInventory.setObjType(objT);
		pocBWInventory.setObjName(objN);
		pocBWInventory.setUsed(us);
		pocBWInventory.setRequestId(requestId);
		pocBWInventory.setProfilerUsed(pUsed);
		pocBWInventory.setUsageCount(uCount);
		pocBWInventory.setTransReq(tReq);

		return pocBWInventory;
	}

	// POC Fiori Output Read Data
	public POC_FioriOutput getFioriOutput(Row row, long requestId, String fileName) {
		int tCodeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Tcode"));
		int appIdIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("App.Id"));
		int appNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("App.Name"));
		int appTypeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("App.Type"));
		int appComponentIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Application.Component"));
		int appComponentTextIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Application.Component.Description"));

		String tCode = row.getCell(tCodeIndex) == null ? "" : row.getCell(tCodeIndex).getStringCellValue();
		String appId = row.getCell(appIdIndex) == null ? "" : row.getCell(appIdIndex).getStringCellValue();
		String appN = row.getCell(appNameIndex) == null ? "" : row.getCell(appNameIndex).getStringCellValue();
		String appT = row.getCell(appTypeIndex) == null ? "" : row.getCell(appTypeIndex).getStringCellValue();
		String appComponent = row.getCell(appComponentIndex) == null ? "" : row.getCell(appComponentIndex).getStringCellValue();
		String appComponentText = row.getCell(appComponentTextIndex) == null ? "" : row.getCell(appComponentTextIndex).getStringCellValue();

		final POC_FioriOutput pocFioriOutput = new POC_FioriOutput();

		pocFioriOutput.settCode(tCode);
		pocFioriOutput.setAppId(appId);
		pocFioriOutput.setAppType(appN);
		pocFioriOutput.setRequestId(requestId);
		pocFioriOutput.setComments(appT);
		pocFioriOutput.setApplicationComponent(appComponent);;
		pocFioriOutput.setApplicationComponentText(appComponentText);;

		return null;
	}

	// POC BW Inventory Read Data
	public POC_BWCleanUpUtility getBWCleanUpUtil(Row row, long requestId, String fileName) {
		int objTypeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Type"));
		int objNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name"));
		int LastUsedDIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Last.Used.Date"));
		int eTimeYearIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Elapsed.Time.Year"));
		int statusIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Status"));

		String objT = row.getCell(objTypeIndex) == null ? "" : row.getCell(objTypeIndex).getStringCellValue();
		String objN = row.getCell(objNameIndex) == null ? "" : row.getCell(objNameIndex).getStringCellValue();
		String lastUSedD = row.getCell(LastUsedDIndex) == null ? "" : row.getCell(LastUsedDIndex).getStringCellValue();
		String eTimeYear = row.getCell(eTimeYearIndex) == null ? "" : row.getCell(eTimeYearIndex).getStringCellValue();
		String status = row.getCell(statusIndex) == null ? "" : row.getCell(statusIndex).getStringCellValue();

		final POC_BWCleanUpUtility pocBWCleanUpUtil = new POC_BWCleanUpUtility();

		pocBWCleanUpUtil.setObjType(objT);
		pocBWCleanUpUtil.setObjName(objN);
		pocBWCleanUpUtil.setLastUsedDate(lastUSedD);
		pocBWCleanUpUtil.setRequestId(requestId);
		pocBWCleanUpUtil.setElapsedTypeInYears(eTimeYear);
		pocBWCleanUpUtil.setStatus(status);
		return pocBWCleanUpUtil;
	}

	// POC Impacted Custom table Read Data
	public POC_ImpactedCustomTable getImpactedCustomTable(Row row, long requestId, String fileName) {
		int objIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Object"));
		int pckgIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Package"));
		int impFieldsIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Impacted.Fields"));
		int impDataEleIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Impacted.Data.Ele"));
		int descOfChngIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Desc.Of.Change"));
		int sapNoteIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sap.Note"));
		int solStepIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sol.Step"));
		int compIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Complexity"));
		int issueCatIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Issue.Cat"));
		int issueSubCatIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Issue.Sub.Cat"));
		int triObjIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Trigger.Obj"));
		int remCatIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Remediation.Cat"));
		int sapSimpListIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("SAP.Simp.List.Chap"));
		int appCompIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("App.Comp"));
		int sapSimpCatIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("SAP.Simp.Cat"));
		int itemAreaIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Item.Area"));

		String obj = row.getCell(objIndex) == null ? "" : row.getCell(objIndex).getStringCellValue();
		String pckg = row.getCell(pckgIndex) == null ? "" : row.getCell(pckgIndex).getStringCellValue();
		String impFields = row.getCell(impFieldsIndex) == null ? "" : row.getCell(impFieldsIndex).getStringCellValue();
		String impDataEle = row.getCell(impDataEleIndex) == null ? ""
				: row.getCell(impDataEleIndex).getStringCellValue();
		String descOfChng = row.getCell(descOfChngIndex) == null ? ""
				: row.getCell(descOfChngIndex).getStringCellValue();
		String sapN = row.getCell(sapNoteIndex) == null ? "" : row.getCell(sapNoteIndex).getStringCellValue();
		String solStep = row.getCell(solStepIndex) == null ? "" : row.getCell(solStepIndex).getStringCellValue();
		String comp = row.getCell(compIndex) == null ? "" : row.getCell(compIndex).getStringCellValue();
		String issueCat = row.getCell(issueCatIndex) == null ? "" : row.getCell(issueCatIndex).getStringCellValue();
		String issuesubCat = row.getCell(issueSubCatIndex) == null ? ""
				: row.getCell(issueSubCatIndex).getStringCellValue();
		String triObj = row.getCell(triObjIndex) == null ? "" : row.getCell(triObjIndex).getStringCellValue();
		String remCat = row.getCell(remCatIndex) == null ? "" : row.getCell(remCatIndex).getStringCellValue();
		String sapSimp = row.getCell(sapSimpListIndex) == null ? ""
				: row.getCell(sapSimpListIndex).getStringCellValue();
		String appComp = row.getCell(appCompIndex) == null ? "" : row.getCell(appCompIndex).getStringCellValue();
		String sapSimpCat = row.getCell(sapSimpCatIndex) == null ? ""
				: row.getCell(sapSimpCatIndex).getStringCellValue();
		String itemArea = row.getCell(itemAreaIndex) == null ? "" : row.getCell(itemAreaIndex).getStringCellValue();

		final POC_ImpactedCustomTable pocImpactedCustomTable = new POC_ImpactedCustomTable();

		pocImpactedCustomTable.setObject(obj);
		pocImpactedCustomTable.setPackg(pckg);
		pocImpactedCustomTable.setImpactedFields(impFields);
		pocImpactedCustomTable.setRequestId(requestId);
		pocImpactedCustomTable.setImpactedDataEle(impDataEle);
		pocImpactedCustomTable.setDesOfChange(descOfChng);
		pocImpactedCustomTable.setSapNotes(sapN);
		pocImpactedCustomTable.setSolStep(solStep);
		pocImpactedCustomTable.setComplexity(comp);
		pocImpactedCustomTable.setIssueCategory(issueCat);
		pocImpactedCustomTable.setIssueSubCategory(issuesubCat);
		pocImpactedCustomTable.setTriggerObj(triObj);
		pocImpactedCustomTable.setRemediationCat(remCat);
		pocImpactedCustomTable.setSapSimListChapter(sapSimp);
		pocImpactedCustomTable.setAppComponent(appComp);
		pocImpactedCustomTable.setSapSimCategory(sapSimpCat);
		pocImpactedCustomTable.setItemArea(itemArea);
		return pocImpactedCustomTable;

	}

	// POC BW Standard Extract Read Data
	public POC_BWStandardExtract getBwStandardExtract(Row row, long requestId, String fileName) {
		int listWithExIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("List.With.Ext"));
		int phaseIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Phase"));
		int areaOfResIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Area.of.Res"));
		int dataSourceIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("DataSource"));
		int applCompIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Appl.component"));
		int classificationIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Classifiction"));
		int catIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Category"));
		int resIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("restriction"));
		int relSimpItemIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Related.Simp.Item"));
		int noteIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Note"));
		int del1511Index = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("del1511"));
		int del1610Index = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("del1610"));
		int delResIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("delta.restrictions"));
		int commentsIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("comments"));

		String listWithEx = row.getCell(listWithExIndex) == null ? ""
				: row.getCell(listWithExIndex).getStringCellValue();
		String phase = row.getCell(phaseIndex) == null ? "" : row.getCell(phaseIndex).getStringCellValue();
		String areaOfRes = row.getCell(areaOfResIndex) == null ? "" : row.getCell(areaOfResIndex).getStringCellValue();
		String dataSource = row.getCell(dataSourceIndex) == null ? ""
				: row.getCell(dataSourceIndex).getStringCellValue();
		String applComp = row.getCell(applCompIndex) == null ? "" : row.getCell(applCompIndex).getStringCellValue();
		String classification = row.getCell(classificationIndex) == null ? ""
				: row.getCell(classificationIndex).getStringCellValue();
		String cat = row.getCell(catIndex) == null ? "" : row.getCell(catIndex).getStringCellValue();
		String res = row.getCell(resIndex) == null ? "" : row.getCell(resIndex).getStringCellValue();
		String relSimpItem = row.getCell(relSimpItemIndex) == null ? ""
				: row.getCell(relSimpItemIndex).getStringCellValue();
		String note = row.getCell(noteIndex) == null ? "" : row.getCell(noteIndex).getStringCellValue();
		String del1511 = row.getCell(del1511Index) == null ? "" : row.getCell(del1511Index).getStringCellValue();
		String del1610 = row.getCell(del1610Index) == null ? "" : row.getCell(del1610Index).getStringCellValue();
		String delRes = row.getCell(delResIndex) == null ? "" : row.getCell(delResIndex).getStringCellValue();
		String comments = row.getCell(commentsIndex) == null ? "" : row.getCell(commentsIndex).getStringCellValue();

		final POC_BWStandardExtract pocBWStandardExtract = new POC_BWStandardExtract();

		pocBWStandardExtract.setExtractorList(listWithEx);
		pocBWStandardExtract.setPhase(phase);
		pocBWStandardExtract.setAreaOfRes(areaOfRes);
		pocBWStandardExtract.setRequestId(requestId);
		pocBWStandardExtract.setDataSource(dataSource);
		pocBWStandardExtract.setApplcomponent(applComp);
		pocBWStandardExtract.setClassification(classification);
		pocBWStandardExtract.setCategory(cat);
		pocBWStandardExtract.setResMandatoryForStatus(res);
		pocBWStandardExtract.setRelSimItem(relSimpItem);
		pocBWStandardExtract.setNote(note);
		pocBWStandardExtract.setDel1511(del1511);
		pocBWStandardExtract.setDel1610(del1610);
		pocBWStandardExtract.setDeltaRes(delRes);
		pocBWStandardExtract.setComments(comments);
		return pocBWStandardExtract;
	}

	// POC Inactive objects Read Data
	public POC_InactiveObjects getInactiveObject(Row row, long requestId, String fileName) {
		int objIndex = Integer.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj"));
		int objNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name"));
		int unameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Uname"));
		int delFlagIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Del.Flag"));
		int tabClassIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("TabClass"));

		String obj = row.getCell(objIndex) == null ? "" : row.getCell(objIndex).getStringCellValue();
		String objName = row.getCell(objNameIndex) == null ? "" : row.getCell(objNameIndex).getStringCellValue();
		String uname = row.getCell(unameIndex) == null ? "" : row.getCell(unameIndex).getStringCellValue();
		String delFlag = row.getCell(delFlagIndex) == null ? "" : row.getCell(delFlagIndex).getStringCellValue();
		String tabClass = row.getCell(tabClassIndex) == null ? "" : row.getCell(tabClassIndex).getStringCellValue();

		final POC_InactiveObjects pocInactiveObjects = new POC_InactiveObjects();

		pocInactiveObjects.setObject(obj);
		pocInactiveObjects.setObjName(objName);
		pocInactiveObjects.setuName(uname);
		pocInactiveObjects.setRequestId(requestId);
		pocInactiveObjects.setDeleteFlag(delFlag);
		pocInactiveObjects.setTabClass(tabClass);
		return pocInactiveObjects;
	}

	public POC_SecAnalyzerTCDReport getSecAnalyzerTCDdataPOC(Row row, long requestId, String fileName) {
		POC_SecAnalyzerTCDReport tcdData = new POC_SecAnalyzerTCDReport();

		int targetVersionIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Target.Version"));
		int functionalAreaIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Functional.Area"));
		int roleNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Role.Name"));
		int lowIndex = Integer.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Low"));
		int highIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("High"));
		int newTCodeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("New.TCode"));
		int statusIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Status"));

		String targetVersion = row.getCell(targetVersionIndex) == null ? ""
				: row.getCell(targetVersionIndex).getStringCellValue().trim();
		String functionalArea = row.getCell(functionalAreaIndex) == null ? ""
				: row.getCell(functionalAreaIndex).getStringCellValue().trim();
		String roleName = row.getCell(roleNameIndex) == null ? "" : row.getCell(roleNameIndex).getStringCellValue().trim().toUpperCase();
		String low = row.getCell(lowIndex) == null ? "" : row.getCell(lowIndex).getStringCellValue().trim();
		String high = row.getCell(highIndex) == null ? "" : row.getCell(highIndex).getStringCellValue().trim();
		String newTCode = row.getCell(newTCodeIndex) == null ? "" : row.getCell(newTCodeIndex).getStringCellValue().trim();
		String status = row.getCell(statusIndex) == null ? "" : row.getCell(statusIndex).getStringCellValue().trim().toUpperCase();

		tcdData.setTargetVersion(targetVersion);
		tcdData.setFunctionalArea(functionalArea);
		tcdData.setRoleName(roleName);
		tcdData.setLow(low);
		tcdData.setHigh(high);
		tcdData.setNewTcode(newTCode);
		tcdData.setStatus(status);
		tcdData.setRequestID(requestId);

		return tcdData;
	}

	public POC_DrillDownReport getDrillDownReportValues(Row row, long requestId, String fileName) {
		int typeIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Type"));
		int objNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name"));
		int subObjNameIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sub.Obj.Name"));
		int readPrgIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Read.Program"));
		int objPackageIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Package"));
		int operationIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Operation"));
		int lineIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Line.No"));
		int statementIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Statement"));
		int impactedObjIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Impacted.Obj"));
		int impactReasonIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Impact.reason"));
		int descIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Desc"));
		int noteNumberIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Note.No"));
		int solStepsIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Solution.Step"));
		int complexityIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Complexity"));
		int issueCatIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Issue.Category"));
		int issueSubCatIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sub.Category"));
		int triggerObjIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Trigger.object"));
		int remidiCatIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Remediation.Category"));
		int sapSimpliListIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("SAP.Simpli.List.Chapter"));
		int appComponentIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("App.Component"));
		int sapSimpliCatIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Simpli.Category"));
		int itemIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Item.Area"));
		int usedIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Used"));
		int selLineIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Select.Line"));

		int ricefCategoryIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Ricef.Category"));
		int impactIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Impact"));
		int corProgNameIndex = Integer.parseInt(
				POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Correction.Program.Name"));
		int corLineNoIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Correction.Line.Number"));
		int toolVersionIndex = Integer
				.parseInt(POC_Upload_Constant.POC_FILE_KEY_VALUE.get(requestId).get(fileName).get("Tool.Version"));
		
		String ricefCategory = row.getCell(ricefCategoryIndex) == null ? "" : row.getCell(ricefCategoryIndex).getStringCellValue();
		String impact = row.getCell(impactIndex) == null ? "" : row.getCell(impactIndex).getStringCellValue();
		String corProgName = row.getCell(corProgNameIndex) == null ? "" : row.getCell(corProgNameIndex).getStringCellValue();
		String corLineNo = row.getCell(corLineNoIndex) == null ? "" : row.getCell(corLineNoIndex).getStringCellValue();
		String toolVersion = row.getCell(toolVersionIndex) == null ? "" : row.getCell(toolVersionIndex).getStringCellValue();
	
		
		String type = row.getCell(typeIndex) == null ? "" : row.getCell(typeIndex).getStringCellValue();

		POC_DrillDownReport pocDrillDownRprtObj = null;

		if (!type.equals("")) {
			pocDrillDownRprtObj = new POC_DrillDownReport();
			
			pocDrillDownRprtObj.setCorProgName(corProgName);
			pocDrillDownRprtObj.setCorLineNo(corLineNo);
			pocDrillDownRprtObj.setImpact(impact);
			pocDrillDownRprtObj.setRicefCategory(ricefCategory);
			pocDrillDownRprtObj.setToolVersion(toolVersion);
			pocDrillDownRprtObj.setObjType(type);
			pocDrillDownRprtObj.setObjName(
					row.getCell(objNameIndex) == null ? "" : row.getCell(objNameIndex).getStringCellValue());
			pocDrillDownRprtObj.setSubObjName(
					row.getCell(subObjNameIndex) == null ? "" : row.getCell(subObjNameIndex).getStringCellValue());
			pocDrillDownRprtObj.setReadProgram(
					row.getCell(readPrgIndex) == null ? "" : row.getCell(readPrgIndex).getStringCellValue());
			pocDrillDownRprtObj.setPkg(
					row.getCell(objPackageIndex) == null ? "" : row.getCell(objPackageIndex).getStringCellValue());
			pocDrillDownRprtObj.setOperation(
					row.getCell(operationIndex) == null ? "" : row.getCell(operationIndex).getStringCellValue());
			if (row.getCell(operationIndex).getStringCellValue().trim().contains("~")) {
				String[] splitStr = row.getCell(operationIndex).getStringCellValue().trim().split("~");
				pocDrillDownRprtObj.setCorProgName(splitStr[1]);
				pocDrillDownRprtObj.setCorLineNo(splitStr[2]);
			}
			pocDrillDownRprtObj.setLineNo((int) Double.parseDouble(
					row.getCell(lineIndex) == null ? "0" : row.getCell(lineIndex).getStringCellValue().trim()));
			pocDrillDownRprtObj.setStatement(
					row.getCell(statementIndex) == null ? "" : row.getCell(statementIndex).getStringCellValue());
			pocDrillDownRprtObj.setImpactedObj(
					row.getCell(impactedObjIndex) == null ? "" : row.getCell(impactedObjIndex).getStringCellValue());
			pocDrillDownRprtObj.setImpactReason(
					row.getCell(impactReasonIndex) == null ? "" : row.getCell(impactReasonIndex).getStringCellValue());
			pocDrillDownRprtObj
					.setDescOfChange(row.getCell(descIndex) == null ? "" : row.getCell(descIndex).getStringCellValue());
			pocDrillDownRprtObj.setSAPNote(
					row.getCell(noteNumberIndex) == null ? "" : row.getCell(noteNumberIndex).getStringCellValue());
			pocDrillDownRprtObj.setSolutionStep(
					row.getCell(solStepsIndex) == null ? "" : row.getCell(solStepsIndex).getStringCellValue());
			pocDrillDownRprtObj.setComplexity(
					row.getCell(complexityIndex) == null ? "" : row.getCell(complexityIndex).getStringCellValue());
			pocDrillDownRprtObj.setIssueCategory(
					row.getCell(issueCatIndex) == null ? "" : row.getCell(issueCatIndex).getStringCellValue());
			pocDrillDownRprtObj.setIssueSubCategory(
					row.getCell(issueSubCatIndex) == null ? "" : row.getCell(issueSubCatIndex).getStringCellValue());
			pocDrillDownRprtObj.setTriggerObject(
					row.getCell(triggerObjIndex) == null ? "" : row.getCell(triggerObjIndex).getStringCellValue());
			pocDrillDownRprtObj.setRemediationCategory(
					row.getCell(remidiCatIndex) == null ? "" : row.getCell(remidiCatIndex).getStringCellValue());
			pocDrillDownRprtObj.setSAPSimpliListChapter(row.getCell(sapSimpliListIndex) == null ? ""
					: row.getCell(sapSimpliListIndex).getStringCellValue());
			pocDrillDownRprtObj.setAppComponent(
					row.getCell(appComponentIndex) == null ? "" : row.getCell(appComponentIndex).getStringCellValue());
			pocDrillDownRprtObj.setSAPSimpliCategory(
					row.getCell(sapSimpliCatIndex) == null ? "" : row.getCell(sapSimpliCatIndex).getStringCellValue());
			pocDrillDownRprtObj
					.setItemArea(row.getCell(itemIndex) == null ? "" : row.getCell(itemIndex).getStringCellValue());
			pocDrillDownRprtObj
					.setUsed(row.getCell(usedIndex) == null ? "" : row.getCell(usedIndex).getStringCellValue());
			pocDrillDownRprtObj.setRequestId(requestId);
			pocDrillDownRprtObj.setObjectNameType(row.getCell(objNameIndex) == null ? ""
					: (type) + (row.getCell(objNameIndex).getStringCellValue().trim()));
			pocDrillDownRprtObj.setSelLine(
					row.getCell(selLineIndex) == null ? "" : row.getCell(selLineIndex).getStringCellValue());
		}

		return pocDrillDownRprtObj;
	}
}
