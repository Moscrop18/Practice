package com.act.osmigration.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.act.Aadt.models.OSMigrationFinal;
import com.act.Aadt.models.OSMigrationFinal_Download;
import com.act.Aadt.models.OSMigrationFinalFilepath_Download;
import com.act.Aadt.models.OSMigrationFinalLogicalCMD_Download;


public interface OSMigrationDAO {

	public Map<String, String> getOprValuesDBOSMigration();
	public String osMigrationBatchInsert(List<OSMigrationFinal> osMigrationList, HttpSession session) throws SQLException, Exception;
	public List<OSMigrationFinal_Download> getOSMigrationList(final long requestId);
	public List<OSMigrationFinalLogicalCMD_Download> getOSMigrationLogCMDList(long requestId);
	public List<OSMigrationFinalFilepath_Download> getOSMigrationFilePathList(long requestId);

}
