package com.act.reader.xlsx;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.util.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.act.Aadt.models.AuctFinalOutput;
import com.act.Aadt.models.ImpactedVariant;
import com.act.Aadt.models.OSMigrationFinal;
import com.act.S4.models.BwCleanupUtil;
import com.act.S4.models.CvitCustomisingLogs;
import com.act.S4.models.CvitErrorMessages;
import com.act.S4.models.S4CvitAssessment;
import com.act.S4.models.S4Detection;
import com.act.S4.models.S4ImpactedCustomTables;
import com.act.S4.models.S4InventoryList;
import com.act.S4.models.S4_SID;
import com.act.S4.models.S4cvitr;
import com.act.client.model.Lsmw;
import com.act.client.model.UserExit;
import com.act.constant.Hana_Profiler_Constant;
import com.act.constant.Services_Constant;
import com.act.displaygrid.model.HanaProfile;
import com.act.exceptions.ST03DataAnalysisException;
import com.act.fileprocessing.model.HanaProfilerStepOutput;
import com.act.fiori.models.St03NData;
import com.monitorjbl.xlsx.StreamingReader;

/**
 * @author monika.mishra
 *
 */
public class ConsolidateReaderXlsx {

	final Logger logger = LoggerFactory.getLogger(ConsolidateReaderXlsx.class);

	protected HanaProfilerStepOutput getHanaProfilerStepOutputData(final Row row, int rowId, final Long requestID,
			String fileName) {

		HanaProfilerStepOutput hanaProfilerStepOutput = null;
		int opCodeIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Operation.Code"));
		String opcodeCellVal = row.getCell(opCodeIndex) == null ? ""
				: row.getCell(opCodeIndex).getStringCellValue().replaceAll("\\s", StringUtils.EMPTY);
		if (opcodeCellVal.startsWith("H")) {

			hanaProfilerStepOutput = new HanaProfilerStepOutput();
			int onjNameIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Obj.Name"));
			int typeIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("OBJ"));

			hanaProfilerStepOutput.setObjName(
					row.getCell(onjNameIndex) == null ? "" : row.getCell(onjNameIndex).getStringCellValue().trim());
			hanaProfilerStepOutput.setObjectType(
					row.getCell(typeIndex) == null ? "" : row.getCell(typeIndex).getStringCellValue().trim());
			hanaProfilerStepOutput
					.setObjNameType(row.getCell(onjNameIndex) == null || row.getCell(typeIndex) == null ? ""
							: (row.getCell(typeIndex).getStringCellValue().trim())
									+ (row.getCell(onjNameIndex).getStringCellValue().trim()));
			// CR-28.0
			String[] splitArr;
			String opCode = "";
			int lineNo = 0;
			String totalScannedLines = "";
			// String
			// opcodeCellVal=row.getCell(opCodeIndex)==null?"":row.getCell(opCodeIndex).getStringCellValue();
			if (opcodeCellVal.startsWith("H")) {
				splitArr = opcodeCellVal.split("H");
				if (splitArr.length == 4 && null != splitArr[1] && null != splitArr[3]) {
					opCode = splitArr[1];
					lineNo = Integer.parseInt(splitArr[2]);
					totalScannedLines = splitArr[3];
				}
				if (splitArr.length < 4 && null != splitArr[1]) {
					opCode = splitArr[1];
					lineNo = Integer.parseInt(splitArr[2]);
					totalScannedLines = "0";
				}

			}
			hanaProfilerStepOutput.setOperationCode(opCode);
			hanaProfilerStepOutput.setTotalLineScanned(totalScannedLines);
			hanaProfilerStepOutput.setLineNo(lineNo);
			hanaProfilerStepOutput.setRequestID(requestID);
			hanaProfilerStepOutput.setJoinID(rowId);
		}
		return hanaProfilerStepOutput;
	}

	protected HanaProfile addListwithLoopValueXlsx(final Row row, int rowId, final Long requestID, String fileName,
			List<String> customerNamespaceList) {
		HanaProfile model = null;
		int opCodeIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Operation.Code"));
		String opcodeCellVal = row.getCell(opCodeIndex) == null ? ""
				: row.getCell(opCodeIndex).getStringCellValue().replaceAll("\\s", StringUtils.EMPTY);
		if (opcodeCellVal.startsWith("H") && !opcodeCellVal.startsWith("H72")) {
			model = new HanaProfile();
			int onjNameIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Obj.Name"));
			int typeIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("OBJ"));
			int subTypeIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Sub.Type"));
			int readPrgIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Read.Prog"));
			int levelIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Levels"));
			int counterIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Counter"));

			// int
			// objPackageIndex=Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("OBJ.Pckg"));

			/*
			 * int keyIndex = Integer
			 * .parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID)
			 * .get( fileName).get("Keys")); int loopsIndex = Integer
			 * .parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID)
			 * .get( fileName).get("Loops"));
			 */

			int infoIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Info"));

			// col25
			int selLineIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Select.Line"));
			// CR-25.0
			int codeIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Code"));

			// col26
			/*
			 * int oDataIndex = Integer
			 * .parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID)
			 * .get( fileName).get("Odata"));
			 */
			// DEF041
			int skipIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Skip").trim());

			int skipReasonIndex = Integer.parseInt(
					Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Comment.C").trim());

			String objName = row.getCell(onjNameIndex) == null ? ""
					: row.getCell(onjNameIndex).getStringCellValue().trim();

			model.setObj_Name(objName);

			model.setSkip(row.getCell(skipIndex) == null ? "" : row.getCell(skipIndex).getStringCellValue().trim());
			model.setSkipReason(row.getCell(skipReasonIndex) == null ? ""
					: row.getCell(skipReasonIndex).getStringCellValue().trim());
			model.setSub_Type(
					row.getCell(subTypeIndex) == null ? "" : row.getCell(subTypeIndex).getStringCellValue().trim());
			model.setReadProgram(
					row.getCell(readPrgIndex) == null ? "" : row.getCell(readPrgIndex).getStringCellValue().trim());
			/*
			 * model.setLine_Number((int)
			 * Double.parseDouble(row.getCell(lineNoIndex) == null ? "0" :
			 * row.getCell(lineNoIndex).getStringCellValue().replaceAll("\\.0",
			 * "").replace(".", "").replace(",", "")));
			 */
			model.setAutomation_status(
					model.getSkipReason().equalsIgnoreCase("Correction has to be done manually") ? "NO" : "");

			String level = (row.getCell(levelIndex) == null) ? "0"
					: row.getCell(levelIndex).getStringCellValue().trim().replaceAll("[^a-zA-Z0-9]", "");
			if ("".equals(level)) {
				level = "0";
			}
			// CR-66:To add value 0 even if inputs contains (-1) or (1-) as
			// inputs from
			// sheet
			else if ("1-".equals(level) || "-1".equals(level)) {
				level = "0";
			}

			model.setLevels(getParsedValue(level, fileName, rowId, levelIndex));
			String info = (row.getCell(infoIndex) == null ? "" : row.getCell(infoIndex).getStringCellValue().trim());

			// CR-Removes first character if special character is present there
			// for info col
			String specialCharacters = " !#$%&'()*+,-.:;<=>?@[]^_`{|}";

			if (info.equals("")) {
				model.setInfo(info);
			} else if (specialCharacters.contains(Character.toString(info.charAt(0)))) {
				info = info.substring(1);
				model.setInfo(info);
			} else {
				model.setInfo(info);
			}

			model.setCode(row.getCell(codeIndex) == null ? "" : row.getCell(codeIndex).getStringCellValue().trim());
			model.setRequestID(requestID);
			model.setJoinID(rowId);
			model.setSel_Line(
					row.getCell(selLineIndex) == null ? "" : row.getCell(selLineIndex).getStringCellValue().trim());
			model.setObject_Type(
					row.getCell(typeIndex) == null ? "" : row.getCell(typeIndex).getStringCellValue().trim());
			model.setObjNameType(row.getCell(onjNameIndex) == null || row.getCell(typeIndex) == null ? ""
					: (row.getCell(typeIndex).getStringCellValue().trim())
							+ (row.getCell(onjNameIndex).getStringCellValue().trim()));

			model.setCounter(Objects.isNull(row.getCell(counterIndex))
					|| StringUtils.isEmpty(row.getCell(counterIndex).getStringCellValue()) ? ""
							: (row.getCell(counterIndex).getStringCellValue().trim()));

			String[] splitArr;
			String opCode = "";
			int lineNo = 0;
			String totalScannedLines = "";

			if (opcodeCellVal.startsWith("H")) {
				splitArr = opcodeCellVal.split("H");
				if (splitArr.length == 4 && null != splitArr[1] && null != splitArr[3]) {
					opCode = splitArr[1];
					lineNo = Integer.parseInt(splitArr[2]);
					totalScannedLines = splitArr[3];
				}
				if (splitArr.length < 4 && null != splitArr[1]) {
					opCode = splitArr[1];
					lineNo = Integer.parseInt(splitArr[2]);
					totalScannedLines = "0";
				}

			}

			model.setOperation_code(opCode);
			model.setTotalLineScanned(totalScannedLines);
			model.setLine_Number(lineNo);

			// Setting External Namespace
			if (CollectionUtils.isNotEmpty(customerNamespaceList)
					&& !customerNamespaceList.stream().anyMatch("NA"::equalsIgnoreCase)) {
				if (!objName.isEmpty()) {
					for (String custNamespace : customerNamespaceList) {
						if (StringUtils.containsIgnoreCase(objName.trim(), custNamespace.trim())) {
							model.setExtNamespace("Y");
							break;
						}
					}
				}
			}
		}

		return model;
	}

	protected S4Detection getDetectionValueXlsx(final Row row, final long requestId, String fileName,
			Set<String> usageAnalysisObjNameType, Set<String> usageAnalysisObjNameTypeReadProg,
			List<String> customerNamespaceList) {
		S4Detection s4Detection = null;
		String[] splitArr;
		String identifier = "";
		int lineNo = 0;
		String totalScannedLines = "0";

		int indentifierIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Operation.Code"));
		String identifierCellVal = row.getCell(indentifierIndex) == null ? ""
				: row.getCell(indentifierIndex).getStringCellValue().replaceAll("\\s", StringUtils.EMPTY);
		int operationIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Act.Status"));
		String operation = row.getCell(operationIndex) == null ? ""
				: row.getCell(operationIndex).getStringCellValue().trim();

		if (identifierCellVal.startsWith("{") && !identifierCellVal.startsWith("{SID")
				&& !"SCRIPT".equalsIgnoreCase(identifierCellVal) && !"CUSTOM TABLES".equalsIgnoreCase(operation)
				&& !"DRILLDOWN REPORT".equalsIgnoreCase(operation)) {
			s4Detection = new S4Detection();

			int sessionIDIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Session.ID"));
			int objNameIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name"));
			int subTypeIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sub.Type"));
			int objPackageIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("OBJ.Pckg"));
			int objTypeIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("OBJ"));
			int stmtIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Code"));
			int commentIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Comments"));
			// int
			// operationIndex=Integer.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.
			// get(requestId).get(fileName).get("Act.Status"));
			int descIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Info"));
			int execDateIndex = Integer.parseInt(
					Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Executed.Date"));
			int execTimeIndex = Integer.parseInt(
					Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Exceuted.Time"));
			int execByIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Executed.By"));
			int toolVersionIndex = Integer.parseInt(
					Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Tool.Version"));
			int readPrgIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Read.Prog"));
			int customFieldIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Operation"));
			int selLineIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Select.Line"));
			int skipIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Skip").trim());
			int counterIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Counter"));

			logger.info("Got Indexes of all cols for S4 ::::");

			splitArr = identifierCellVal.split("\\{");

			identifier = splitArr[1];
			if (!"IMPACTED REPORT VARIANT".equalsIgnoreCase(operation)
					&& !"IMPACTED SCREEN VARIANT".equalsIgnoreCase(operation)
					&& !"IMPACTED TRANSACTION VARIANT".equalsIgnoreCase(operation)) {
				if (StringUtils.isNotBlank(splitArr[2])) {
					lineNo = Integer.parseInt(splitArr[2]);
				} else {
					lineNo = 0;
				}

				if (splitArr.length == 4) {
					totalScannedLines = splitArr[3];
				} else if (splitArr.length < 4) {
					totalScannedLines = "0";
				}
			}
			String objType = row.getCell(objTypeIndex) == null ? ""
					: row.getCell(objTypeIndex).getStringCellValue().trim();
			String objectName = row.getCell(objNameIndex) == null ? ""
					: row.getCell(objNameIndex).getStringCellValue().trim();
			String readProgram = row.getCell(readPrgIndex) == null ? ""
					: row.getCell(readPrgIndex).getStringCellValue().trim();
			String objectNameType = row.getCell(objNameIndex) == null || row.getCell(objTypeIndex) == null ? ""
					: (row.getCell(objTypeIndex).getStringCellValue().trim())
							+ (row.getCell(objNameIndex).getStringCellValue().trim());
			String descOfChange = row.getCell(descIndex) == null ? ""
					: row.getCell(descIndex).getStringCellValue().trim();

			String impactReason = row.getCell(commentIndex) == null ? ""
					: row.getCell(commentIndex).getStringCellValue().trim();
			String statement = row.getCell(stmtIndex) == null ? "" : row.getCell(stmtIndex).getStringCellValue().trim();
			String pckg = row.getCell(objPackageIndex) == null ? ""
					: row.getCell(objPackageIndex).getStringCellValue().trim();
			String subObjectType = row.getCell(subTypeIndex) == null ? ""
					: row.getCell(subTypeIndex).getStringCellValue().trim();
			// String operation = row.getCell(operationIndex)==null ? "" :
			// row.getCell(operationIndex).getStringCellValue().trim();
			String sessionID = (row.getCell(sessionIDIndex) == null) ? "0"
					: row.getCell(sessionIDIndex).getStringCellValue().trim();
			String execDate = row.getCell(execDateIndex) == null ? ""
					: row.getCell(execDateIndex).getStringCellValue().trim();
			String execTime = row.getCell(execTimeIndex) == null ? ""
					: row.getCell(execTimeIndex).getStringCellValue().trim();
			String execBy = row.getCell(execByIndex) == null ? ""
					: row.getCell(execByIndex).getStringCellValue().trim();
			String customFields = row.getCell(customFieldIndex) == null ? ""
					: row.getCell(customFieldIndex).getStringCellValue().trim();
			String selLine = row.getCell(selLineIndex) == null ? ""
					: row.getCell(selLineIndex).getStringCellValue().trim();
			String toolVersion = (row.getCell(toolVersionIndex) == null
					|| row.getCell(toolVersionIndex).getStringCellValue().trim().isEmpty()) ? "0"
							: row.getCell(toolVersionIndex).getStringCellValue().trim();
			String skip = row.getCell(skipIndex) == null ? "" : row.getCell(skipIndex).getStringCellValue().trim();
			String counter = Objects.isNull(row.getCell(counterIndex))
					|| StringUtils.isEmpty(row.getCell(counterIndex).getStringCellValue()) ? "0"
							: (row.getCell(counterIndex).getStringCellValue().trim());
			String s4ListObj = objectNameType.trim();
			s4ListObj = (s4ListObj.startsWith("USRE") || s4ListObj.startsWith("USRR"))
					? s4ListObj.replace(s4ListObj.substring(0, 4), "PROG") : s4ListObj;

			if (skip.equalsIgnoreCase("X")) {
				s4Detection.setAutomationStatus("NO");
			} else {
				s4Detection.setAutomationStatus("YES");
			}

			s4Detection.setSessionId((int) Double.parseDouble(sessionID));
			s4Detection.setIdentifier(identifier.trim()); 
			s4Detection.setType(objType);
			if (s4Detection.getType().equalsIgnoreCase("")) {
				if (operation.equalsIgnoreCase("System Index")) {
					s4Detection.setType("INDE");
				} else if (operation.equalsIgnoreCase("IDOC MSG TYPE")) {
					s4Detection.setType("IDOC");
				}
			}

			s4Detection.setObjectName(objectName);
			s4Detection.setSubType(subObjectType);
			s4Detection.setObjPackage(pckg);
			s4Detection.setObjType(objType);
			s4Detection.setLineNo(lineNo);
			s4Detection.setUniqueKey(objType + objectName + subObjectType + readProgram + identifierCellVal);

			if (!"IMPACTED REPORT VARIANT".equalsIgnoreCase(operation)
					&& !"IMPACTED SCREEN VARIANT".equalsIgnoreCase(operation)
					&& !"IMPACTED TRANSACTION VARIANT".equalsIgnoreCase(operation)) {
				s4Detection.setStatement(statement);
			}

			s4Detection.setComments(impactReason);
			if (descOfChange.length() != 0) {
				if (descOfChange.charAt(descOfChange.length() - 1) == '$') {
					s4Detection.setDescription(descOfChange.substring(0, (descOfChange.length() - 1)));
				} else {
					s4Detection.setDescription(descOfChange);
				}
			}

			s4Detection.setExecDate(execDate);
			s4Detection.setExecTime(execTime);
			s4Detection.setExecBy(execBy);
			s4Detection.setToolVersion((int) Double.parseDouble(toolVersion));
			s4Detection.setTotalScannedLine(Integer.parseInt(totalScannedLines));
			s4Detection.setObjNameType(objectNameType);
			s4Detection.setREAD_PROG(readProgram);
			s4Detection.setOperations(operation);
			s4Detection.setCounter(counter);

			// where in ZAICAT_DETECTION, OPERATION='CUSTOM_FIELDS'
			s4Detection.setCustomFields(customFields);
			s4Detection.setSelectLine(selLine);

			// Correction Line in S4
			if (null != row.getCell(customFieldIndex) && null != row.getCell(customFieldIndex).getStringCellValue()
					&& row.getCell(customFieldIndex).getStringCellValue().trim().contains("~")) {
				if (row.getCell(customFieldIndex).getStringCellValue().trim().contains("~")) {
					String[] splitStr = row.getCell(customFieldIndex).getStringCellValue().trim().split("~");
					if (splitStr.length > 1) {
						s4Detection.setCorProgName(splitStr[1]);
					} else {
						s4Detection.setCorProgName("");
					}
					if (splitStr.length > 2) {
						s4Detection.setCorLineNo(splitStr[2]);
					} else {
						s4Detection.setCorLineNo("");
					}
				}
			} else {
				s4Detection.setCorProgName("");
				s4Detection.setCorLineNo("");
			}

			s4Detection.setRequestId(requestId);

			if (CollectionUtils.isNotEmpty(usageAnalysisObjNameType) && usageAnalysisObjNameType.contains(s4ListObj))
				s4Detection.setUsed("Y");

			if (s4Detection.getType().equalsIgnoreCase("AQQU")) {
				String objTypeNameReadProg = s4Detection.getObjType() + s4Detection.getObjectName()
						+ s4Detection.getREAD_PROG();
				if (CollectionUtils.isNotEmpty(usageAnalysisObjNameTypeReadProg)
						&& usageAnalysisObjNameTypeReadProg.contains(objTypeNameReadProg))
					s4Detection.setUsed("Y");
			}

			// Setting External Namespace
			if (CollectionUtils.isNotEmpty(customerNamespaceList)
					&& !customerNamespaceList.stream().anyMatch("NA"::equalsIgnoreCase)) {
				if (!objectName.isEmpty()) {
					for (String custNamespace : customerNamespaceList) {
						if (StringUtils.containsIgnoreCase(objectName.trim(), custNamespace.trim())) {
							s4Detection.setExtNamespace("Y");
							break;
						}
					}
				}
			}
		}

		return s4Detection;
	}

	protected S4cvitr getCVITRValueXlsx(final Row row, final long requestId, String fileName) {

		S4cvitr cvitr = null;

		int indentifierIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Operation.Code"));
		String identifierCellVal = row.getCell(indentifierIndex) == null ? ""
				: row.getCell(indentifierIndex).getStringCellValue().replaceAll("\\s", StringUtils.EMPTY);
		if (identifierCellVal.startsWith("CVNR")) {

			cvitr = new S4cvitr();
			int selectLineIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Select.Line"));
			String selectLineCellVal = row.getCell(selectLineIndex) == null ? ""
					: row.getCell(selectLineIndex).getStringCellValue().trim();
			int commentCIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Comment.C"));
			String commentCCellVal = row.getCell(commentCIndex) == null ? ""
					: row.getCell(commentCIndex).getStringCellValue().trim();
			int commentsIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Comments"));
			String commentsCellVal = row.getCell(commentsIndex) == null ? ""
					: row.getCell(commentsIndex).getStringCellValue().trim();
			int newLineIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("New.Line"));
			String newLineCellVal = row.getCell(newLineIndex) == null ? ""
					: row.getCell(newLineIndex).getStringCellValue().trim();

			logger.info("Got Indexes of all cols::::");

			String[] splitArr;
			String identifier = "";
			String selectLine = "";
			String commentC = "";
			String comments = "";
			String customerExt = "";
			String vendorExt = "";

			if (identifierCellVal.endsWith("X")) {
				customerExt = "X";
			}
			if (commentsCellVal.endsWith("X")) {
				vendorExt = "X";
			}
			if (identifierCellVal.startsWith("CVNR")) {
				splitArr = identifierCellVal.split("CVNR");
				if (null != splitArr[1]) {
					identifier = splitArr[1];
				}
			}

			splitArr = selectLineCellVal.split("CVNR");
			if (null != splitArr[1]) {
				selectLine = splitArr[1];
			}

			splitArr = commentCCellVal.split("CVNR");
			if (null != splitArr[1]) {
				commentC = splitArr[1];
			}

			splitArr = commentsCellVal.split("CVNR");
			if (null != splitArr[1]) {
				comments = splitArr[1];
			}

			cvitr.setRequestID(requestId);
			cvitr.setIdentifier(identifier.trim());
			cvitr.setCommentC(commentC);
			cvitr.setSelectLine(selectLine);
			cvitr.setComments(comments);
			cvitr.setNewLine(newLineCellVal);
			cvitr.setCustomerExt(customerExt);
			cvitr.setVendorExt(vendorExt);
		}
		return cvitr;
	}

	protected void getTadirValueXlsx(final Row row, final long requestId, String fileName, Map<String, Integer> count) {

		Integer l;
		/*
		 * int indentifierIndex=Integer.parseInt(Hana_Profiler_Constant.
		 * ID_FILE_KEY_VALUE. get(requestId).get(fileName).get("OBJECT"));
		 * 
		 * int objectIndex =
		 * Integer.parseInt(S4HanaProfilerConstant.S4_FILE_KEY_VALUE.get(
		 * requestId).get( fileName).get("OBJECT").get(1));
		 */
		String classes = row.getCell(1) == null ? "" : row.getCell(1).getStringCellValue();
		if (classes.equalsIgnoreCase(Services_Constant.CLAS_CONSTANT)) {
			l = count.get("Classes");
			l++;
			count.put("Classes", l);
		}
		if (classes.equalsIgnoreCase(Services_Constant.PROG_CONSTANT)) {
			l = count.get("Programs");
			l++;
			count.put("Programs", l);
		}
		if (classes.equalsIgnoreCase(Services_Constant.ENHO_CONSTANT)
				|| classes.equalsIgnoreCase(Services_Constant.ENHC_CONSTANT)
				|| classes.equalsIgnoreCase(Services_Constant.ENHS_CONSTANT)) {
			l = count.get("Enhancement");
			l++;
			count.put("Enhancement", l);
		}
		if (classes.equalsIgnoreCase(Services_Constant.LSMW_CONSTANT)) {
			l = count.get("LSMW");
			l++;
			count.put("LSMW", l);
		}
		if (classes.equalsIgnoreCase(Services_Constant.SSFO_CONSTANT)
				|| classes.equalsIgnoreCase(Services_Constant.SFPI_CONSTANT)) {
			l = count.get("FunctionGroup");
			l++;
			count.put("FunctionGroup", l);
		}
		if (classes.equalsIgnoreCase(Services_Constant.USRR_CONSTANT)
				|| classes.equalsIgnoreCase(Services_Constant.USRE_CONSTANT)) {
			l = count.get("Forms");
			l++;
			count.put("Forms", l);
		}
		if (classes.equalsIgnoreCase(Services_Constant.FUGR_CONSTANT)
				|| classes.equalsIgnoreCase(Services_Constant.FUGS_CONSTANT)) {
			l = count.get("UserExits");
			l++;
			count.put("UserExits", l);
		}
		if (classes.equalsIgnoreCase(Services_Constant.PDTS_CONSTANT)
				|| classes.equalsIgnoreCase(Services_Constant.PDWS_CONSTANT)
				|| classes.equalsIgnoreCase(Services_Constant.PDAC_CONSTANT)
				|| classes.equalsIgnoreCase(Services_Constant.PDTG_CONSTANT)) {
			l = count.get("Workflow");
			l++;
			count.put("Workflow", l);
		}
		if (classes.equalsIgnoreCase(Services_Constant.IDOC_CONSTANT)) {
			l = count.get("Interfaces");
			l++;
			count.put("Interfaces", l);
		}
		if (classes.equalsIgnoreCase(Services_Constant.WDYN_CONSTANT)) {
			l = count.get("WebDynpro");
			l++;
			count.put("WebDynpro", l);
		}
	}

	protected AuctFinalOutput getAuctValueXlsx(final Row row, final long requestId, String fileName,
			Set<String> usageAnalysisObjNameType, Set<String> usageAnalysisObjNameTypeReadProg,
			List<String> customerNamespaceList) {

		AuctFinalOutput auctObject = null;

		int indentifierIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Operation.Code"));
		String identifierCellVal = row.getCell(indentifierIndex) == null ? ""
				: row.getCell(indentifierIndex).getStringCellValue().replaceAll("\\s", StringUtils.EMPTY);
		if (identifierCellVal.startsWith("U") && !identifierCellVal.equalsIgnoreCase("USAGE")
				&& !identifierCellVal.equalsIgnoreCase("U000")) {

			auctObject = new AuctFinalOutput();

			int typeIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("OBJ").trim());
			int objNameIndex = Integer.parseInt(
					Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name").trim());
			int subTypeIndex = Integer.parseInt(
					Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sub.Type").trim());
			int readPrgIndex = Integer.parseInt(
					Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Read.Prog").trim());
			int objPackageIndex = Integer.parseInt(
					Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("OBJ.Pckg").trim());
			int descIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Info").trim());

			int codeIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Code").trim());

			logger.info("Got Indexes of all cols::::");

			// CR-26.0
			String[] splitArr;
			String identifier = "";
			int lineNo = 0;
			int totalScannedLines = 0;

			if (identifierCellVal.startsWith("U")) {
				splitArr = identifierCellVal.split("U");
				if (splitArr.length == 4 && null != splitArr[1] && null != splitArr[3]) {
					identifier = splitArr[1];
					lineNo = Integer.parseInt(splitArr[2]);
					totalScannedLines = Integer.parseInt(splitArr[3]);
				}
				if (splitArr.length < 4 && null != splitArr[1]) {
					identifier = splitArr[1];
					lineNo = Integer.parseInt(splitArr[2]);
					totalScannedLines = 0;
				}

			}

			String objName = row.getCell(objNameIndex) == null ? ""
					: row.getCell(objNameIndex).getStringCellValue().trim();

			auctObject
					.setTYPE(row.getCell(typeIndex) == null ? "" : row.getCell(typeIndex).getStringCellValue().trim());
			auctObject.setOBJ_NAME(objName);
			auctObject.setOBJ_NAME_TYPE(row.getCell(objNameIndex) == null || row.getCell(typeIndex) == null ? ""
					: (row.getCell(typeIndex).getStringCellValue().trim())
							+ (row.getCell(objNameIndex).getStringCellValue().trim()));
			auctObject.setSUB_TYPE(
					row.getCell(subTypeIndex) == null ? "" : row.getCell(subTypeIndex).getStringCellValue().trim());
			auctObject.setREAD_PROG(
					row.getCell(readPrgIndex) == null ? "" : row.getCell(readPrgIndex).getStringCellValue().trim());
			auctObject.setOBJ_PACKAGE(row.getCell(objPackageIndex) == null ? ""
					: row.getCell(objPackageIndex).getStringCellValue().trim());

			auctObject
					.setCODE(row.getCell(codeIndex) == null ? "" : row.getCell(codeIndex).getStringCellValue().trim());

			auctObject.setLINE_NUMBER(lineNo);
			auctObject
					.setINFO(row.getCell(descIndex) == null ? "" : row.getCell(descIndex).getStringCellValue().trim());
			auctObject.setOPCODE(identifier);
			auctObject.setOPERCD(identifierCellVal);
			if ("555".equalsIgnoreCase(auctObject.getOPCODE()) || "999".equalsIgnoreCase(auctObject.getOPCODE())) {
				auctObject.setAUTOMATION_STATUS("Manual");
			}

			auctObject.setTOTAL_LINE_NUMBER(totalScannedLines);
			auctObject.setREQUEST_ID(requestId);

			String auctListObj = auctObject.getOBJ_NAME_TYPE().trim();
			auctListObj = (auctListObj.startsWith("USRE") || auctListObj.startsWith("USRR"))
					? auctListObj.replace(auctListObj.substring(0, 4), "PROG") : auctListObj;

			if (CollectionUtils.isNotEmpty(usageAnalysisObjNameType)
					&& usageAnalysisObjNameType.contains(auctListObj)) {
				auctObject.setUsed_Unused("Y");
			}

			if (auctObject.getTYPE().equalsIgnoreCase("AQQU")) {
				String objectTypeNameReadProg = auctObject.getTYPE() + auctObject.getOBJ_NAME()
						+ auctObject.getREAD_PROG();
				if (CollectionUtils.isNotEmpty(usageAnalysisObjNameTypeReadProg)
						&& usageAnalysisObjNameTypeReadProg.contains(objectTypeNameReadProg)) {
					auctObject.setUsed_Unused("Y");
				}
			}

			// Setting External Namespace
			if (CollectionUtils.isNotEmpty(customerNamespaceList)
					&& !customerNamespaceList.stream().anyMatch("NA"::equalsIgnoreCase)) {
				if (!objName.isEmpty()) {
					for (String custNamespace : customerNamespaceList) {
						if (StringUtils.containsIgnoreCase(objName.trim(), custNamespace.trim())) {
							auctObject.setExtNamespace("Y");
							break;
						}
					}
				}
			}
		}

		return auctObject;
	}

	protected int getParsedValue(String value, String fileName, int rowId, int levelIndex) {

		try {
			return (int) Double.parseDouble(value);
		} catch (NumberFormatException e) {
			throw new ST03DataAnalysisException(fileName, ++rowId, ++levelIndex);
		}
	}

	protected List<UserExit> addUserExitDataList(String filePath, long requestID, int rowCount)
			throws FileNotFoundException {
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);
		List<UserExit> userExitList = new ArrayList<UserExit>();

		String fileName = file.getName();
		try {
			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);

			for (Row r : reader) {
				if (r.getRowNum() > 0) {
					rowCount = rowCount + 1;
					logger.info(
							"File--" + fileName + "-----RowNum---" + r.getRowNum() + "Table Row Count---" + rowCount);

					UserExit userExit = getUserExitValueXlsx(r, requestID, fileName);
					if (userExit != null) {
						userExitList.add(userExit);
					}

				}

			}
			logger.info("userExitList count " + userExitList.size());
		} finally {
			IOUtils.closeQuietly(inputStream);
		}

		return userExitList;

	}

	private UserExit getUserExitValueXlsx(Row row, long requestID, String fileName) {

		int objTypeIndex = Integer.parseInt(
				Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Object.Type").trim());
		int objNameIndex = Integer.parseInt(
				Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Object.Name").trim());

		String ObjType = row.getCell(objTypeIndex) == null ? "" : row.getCell(objTypeIndex).getStringCellValue().trim();
		String ObjName = row.getCell(objNameIndex) == null ? "" : row.getCell(objNameIndex).getStringCellValue().trim();
		String ObjNameType = row.getCell(objNameIndex) == null ? ""
				: ("PROG") + (row.getCell(objNameIndex).getStringCellValue().trim());

		if (!ObjType.equals("") && !ObjName.equals("")) {
			final UserExit userExit = new UserExit();
			userExit.setObjType(ObjType);
			userExit.setObjName(ObjName);
			userExit.setObjNameType(ObjNameType);
			userExit.setRequestID(requestID);
			return userExit;
		}

		return null;

	}

	protected List<Lsmw> addLSMWDataList(String filePath, long requestID, int rowCount) throws FileNotFoundException {
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);
		List<Lsmw> lsmwList = new ArrayList<Lsmw>();

		String fileName = file.getName();
		try {
			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);

			for (Row r : reader) {
				if (r.getRowNum() > 0) {
					rowCount = rowCount + 1;
					logger.info(
							"File--" + fileName + "-----RowNum---" + r.getRowNum() + "Table Row Count---" + rowCount);

					lsmwList.add(getLSMWValueXlsx(r, requestID, fileName));

				}

			}
			logger.info("lsmwList count " + lsmwList.size());
		} finally {
			IOUtils.closeQuietly(inputStream);
		}

		return lsmwList;

	}

	private Lsmw getLSMWValueXlsx(Row row, long requestID, String fileName) {
		final Lsmw lsmw = new Lsmw();

		int objTypeIndex = Integer.parseInt(
				Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Object.Type").trim());
		int objNameIndex = Integer.parseInt(
				Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Object.Name").trim());

		lsmw.setObjType(row.getCell(objTypeIndex) == null ? "" : row.getCell(objTypeIndex).getStringCellValue().trim());
		lsmw.setObjName(row.getCell(objNameIndex) == null ? "" : row.getCell(objNameIndex).getStringCellValue().trim());

		lsmw.setObjNameType(row.getCell(objNameIndex) == null ? ""
				: ("PROG") + (row.getCell(objNameIndex).getStringCellValue().trim()));

		lsmw.setRequestID(requestID);

		return lsmw;

	}

	protected List<S4InventoryList> addInventoryDataList(String filePath, long requestID, int rowCount,
			List<String> customerNamespaceList) throws FileNotFoundException {
		File file = new File(filePath);
		InputStream inputStream = new FileInputStream(file);

		String fileName = file.getName();
		try {
			List<S4InventoryList> s4InventoryList = new ArrayList<S4InventoryList>();
			StreamingReader reader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
					.read(inputStream);

			for (Row r : reader) {
				if (r.getRowNum() > 0) {
					rowCount = rowCount + 1;
					logger.info(
							"File--" + fileName + "-----RowNum---" + r.getRowNum() + "Table Row Count---" + rowCount);

					S4InventoryList s4Inventory = getInventoryValueXlsx(r, requestID, fileName, customerNamespaceList);
					if (s4Inventory != null) {
						s4InventoryList.add(s4Inventory);
					}
				}
			}

			return s4InventoryList;
		} finally {
			IOUtils.closeQuietly(inputStream);
		}
	}

	private S4InventoryList getInventoryValueXlsx(Row row, long requestId, String fileName,
			List<String> customerNamespaceList) {
		int objTypeIndex = Integer.parseInt(
				Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Object.Type").trim());
		int objNameIndex = Integer.parseInt(
				Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Object.Name").trim());
		int objPackageIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Package"));
		int profilerusedIndex = Integer.parseInt(
				Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Profiler.Used").trim());
		int linesIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Lines").trim());
		int userGroupIndex = Integer.parseInt(
				Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("User.Group").trim());
		int abapQueryIndex = Integer.parseInt(
				Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("ABAP.Query").trim());
		int readProgIndex = Integer.parseInt(
				Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Read.Prog").trim());

		int createdByIndex = Integer.parseInt(
				Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Created.By").trim());

		int createdOnIndex = Integer.parseInt(
				Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Created.On").trim());

		int changedByIndex = Integer.parseInt(
				Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Changed.By").trim());
		int changedOnIndex = Integer.parseInt(
				Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Changed.On").trim());
		int trIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Tr").trim());
		int trStatusIndex = Integer.parseInt(
				Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Tr.Status").trim());

		String ObjType = row.getCell(objTypeIndex) == null ? "" : row.getCell(objTypeIndex).getStringCellValue().trim();
		String ObjName = row.getCell(objNameIndex) == null ? "" : row.getCell(objNameIndex).getStringCellValue().trim();
		String ObjNameType = row.getCell(objTypeIndex) == null || row.getCell(objNameIndex) == null ? ""
				: (row.getCell(objTypeIndex).getStringCellValue().trim())
						+ (row.getCell(objNameIndex).getStringCellValue().trim());
		String obj_pcg = row.getCell(objPackageIndex) == null ? "" : row.getCell(objPackageIndex).getStringCellValue();
		String profilerUsed = row.getCell(profilerusedIndex) == null ? ""
				: row.getCell(profilerusedIndex).getStringCellValue().trim();
		String countLines = row.getCell(linesIndex) == null ? "" : row.getCell(linesIndex).getStringCellValue().trim();
		String UserGroup = row.getCell(userGroupIndex) == null ? ""
				: row.getCell(userGroupIndex).getStringCellValue().trim();
		String AbapQuery = row.getCell(abapQueryIndex) == null ? ""
				: row.getCell(abapQueryIndex).getStringCellValue().trim();
		String readProg = row.getCell(readProgIndex) == null ? ""
				: row.getCell(readProgIndex).getStringCellValue().trim();
		String createdBy = row.getCell(createdByIndex) == null ? ""
				: row.getCell(createdByIndex).getStringCellValue().trim();
		String createdOn = row.getCell(createdOnIndex) == null ? ""
				: row.getCell(createdOnIndex).getStringCellValue().trim();
		String changedBy = row.getCell(changedByIndex) == null ? ""
				: row.getCell(changedByIndex).getStringCellValue().trim();
		String changedOn = row.getCell(changedOnIndex) == null ? ""
				: row.getCell(changedOnIndex).getStringCellValue().trim();
		String tr = row.getCell(trIndex) == null ? "" : row.getCell(trIndex).getStringCellValue().trim();
		String trStatus = row.getCell(trStatusIndex) == null ? ""
				: row.getCell(trStatusIndex).getStringCellValue().trim();

		if (!ObjType.equals("") && !ObjName.equals("")) {
			final S4InventoryList s4Inventory = new S4InventoryList();
			s4Inventory.setObjType(ObjType);
			s4Inventory.setObjName(ObjName);
			s4Inventory.setObjNameType(ObjNameType);
			s4Inventory.setPckg(obj_pcg);
			s4Inventory.setCountLines(countLines);
			s4Inventory.setRequestID(requestId);
			s4Inventory.setUserGroup(UserGroup);
			s4Inventory.setReadProg(readProg);
			s4Inventory.setCreatedBy(createdBy);
			s4Inventory.setCreatedOn(createdOn);
			s4Inventory.setChangedBy(changedBy);
			s4Inventory.setChangedOn(changedOn);
			s4Inventory.setTr(tr);
			if (trStatus.equalsIgnoreCase("R")) {
				trStatus = "Released";
			} else if (trStatus.equalsIgnoreCase("D")) {
				trStatus = "Modifiable";
			}
			s4Inventory.setTrStatus(trStatus);

			if (AbapQuery != null && !AbapQuery.isEmpty() && AbapQuery.contains("~")) {
				String[] AbapQueryData = AbapQuery.split("\\~");
				s4Inventory.setABAPQuery(AbapQueryData[1]);
			} else {
				s4Inventory.setABAPQuery("");
			}

			if (profilerUsed != null && !profilerUsed.isEmpty() && profilerUsed.contains("$")) {
				String[] profilerData = profilerUsed.split("\\$");
				s4Inventory.setTransReq(profilerData[0]);
			} else {
				s4Inventory.setTransReq("");
			}

			// Setting External Namespace
			if (CollectionUtils.isNotEmpty(customerNamespaceList)
					&& !customerNamespaceList.stream().anyMatch("NA"::equalsIgnoreCase)) {
				if (!ObjName.isEmpty()) {
					for (String custNamespace : customerNamespaceList) {
						if (StringUtils.containsIgnoreCase(ObjName.trim(), custNamespace.trim())) {
							s4Inventory.setExtNamespace("Y");
							break;
						}
					}
				}
			}

			return s4Inventory;
		}

		return null;
	}

	protected S4CvitAssessment getCvitAssessment(final Row row, final long requestId, String fileName) {

		S4CvitAssessment s4CvitAssessment = null;
		int indentifierIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Operation.Code"));
		String identifierCellVal = row.getCell(indentifierIndex) == null ? ""
				: row.getCell(indentifierIndex).getStringCellValue().replaceAll("\\s", StringUtils.EMPTY);
		if (identifierCellVal.startsWith("CVIT") && !identifierCellVal.startsWith("CVITR")) {
			s4CvitAssessment = new S4CvitAssessment();
			int objNameIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name"));

			String objName = row.getCell(objNameIndex) == null ? ""
					: row.getCell(objNameIndex).getStringCellValue().trim();

			String cvitValue = null;
			String arr[] = identifierCellVal.split("CVIT");
			if (arr.length == 3 && arr[1] != null) {
				cvitValue = arr[1];
			}
			s4CvitAssessment.setCvitValue(cvitValue);
			s4CvitAssessment.setObjName(objName);
			s4CvitAssessment.setRequestId(requestId);
		}
		return s4CvitAssessment;
	}

	protected OSMigrationFinal addOSMigarationList(final Row row, int rowId, final Long requestID, String fileName,
			Set<String> usageAnalysisList, Set<String> usageAnalysisAQQUList, List<String> externalNamespaceList) {
		OSMigrationFinal osMigartionModel = null;

		int opCodeIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Operation.Code"));
		String opcodeCellVal = row.getCell(opCodeIndex) == null ? ""
				: row.getCell(opCodeIndex).getStringCellValue().replaceAll("\\s", StringUtils.EMPTY);
		if (opcodeCellVal.startsWith("[") && !opcodeCellVal.startsWith("[206")) {
			osMigartionModel = new OSMigrationFinal();

			String[] splitArr;
			String opCode = "";
			int lineNo = 0;

			splitArr = opcodeCellVal.split("\\[");
			if (splitArr.length == 4 && null != splitArr[1] && null != splitArr[2]) {
				opCode = splitArr[1];
				lineNo = Integer.parseInt(splitArr[2]);
			}

			osMigartionModel.setOperationCode(opCode);
			osMigartionModel.setLineNo(lineNo);

			int objNameIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Obj.Name"));
			int objTypeIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("OBJ"));
			int subTypeIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Sub.Type"));
			int readPrgIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Read.Prog"));
			int objPkgIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("OBJ.Pckg"));
			int selLineIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Select.Line"));
			int codeIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Code"));
			int skipIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Skip").trim());
			int skipReasonIndex = Integer.parseInt(
					Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestID).get(fileName).get("Comment.C").trim());

			osMigartionModel.setRequestID(requestID);
			osMigartionModel.setSubType(
					row.getCell(subTypeIndex) == null ? "" : row.getCell(subTypeIndex).getStringCellValue().trim());
			osMigartionModel.setReadProgram(
					row.getCell(readPrgIndex) == null ? "" : row.getCell(readPrgIndex).getStringCellValue().trim());
			osMigartionModel.setObjPackage(
					row.getCell(objPkgIndex) == null ? "" : row.getCell(objPkgIndex).getStringCellValue().trim());
			osMigartionModel.setStatement(
					row.getCell(codeIndex) == null ? "" : row.getCell(codeIndex).getStringCellValue().trim());
			osMigartionModel.setSelectLine(
					row.getCell(selLineIndex) == null ? "" : row.getCell(selLineIndex).getStringCellValue().trim());
			osMigartionModel.setObjName(
					row.getCell(objNameIndex) == null ? "" : row.getCell(objNameIndex).getStringCellValue().trim());
			osMigartionModel.setObjType(
					row.getCell(objTypeIndex) == null ? "" : row.getCell(objTypeIndex).getStringCellValue().trim());
			osMigartionModel.setObjTypeName(row.getCell(objNameIndex) == null || row.getCell(objTypeIndex) == null ? ""
					: (row.getCell(objTypeIndex).getStringCellValue().trim())
							.concat((row.getCell(objNameIndex).getStringCellValue().trim())));
			osMigartionModel
					.setSkip(row.getCell(skipIndex) == null ? "" : row.getCell(skipIndex).getStringCellValue().trim());
			osMigartionModel.setSkipReason(row.getCell(skipReasonIndex) == null ? ""
					: row.getCell(skipReasonIndex).getStringCellValue().trim());

			String osMigObjTypeName = osMigartionModel.getObjTypeName().trim();
			osMigObjTypeName = (osMigObjTypeName.startsWith("USRE") || osMigObjTypeName.startsWith("USRR"))
					? osMigObjTypeName.replace(osMigObjTypeName.substring(0, 4), "PROG") : osMigObjTypeName;

			if (CollectionUtils.isNotEmpty(usageAnalysisList) && usageAnalysisList.contains(osMigObjTypeName)) {
				osMigartionModel.setUsed("Y");
			} else {
				osMigartionModel.setUsed("");
			}

			if (osMigartionModel.getObjType().equalsIgnoreCase("AQQU")) {
				String objTypeNameReadProg = osMigartionModel.getObjType() + osMigartionModel.getObjName()
						+ osMigartionModel.getReadProgram();
				if (CollectionUtils.isNotEmpty(usageAnalysisAQQUList)
						&& usageAnalysisAQQUList.contains(objTypeNameReadProg)) {
					osMigartionModel.setUsed("Y");
				}
			}

			// Setting External Namespace
			if (CollectionUtils.isNotEmpty(externalNamespaceList)
					&& !externalNamespaceList.stream().anyMatch("NA"::equalsIgnoreCase)) {
				if (!osMigartionModel.getObjName().isEmpty()) {
					for (String externalNamespace : externalNamespaceList) {
						if (StringUtils.containsIgnoreCase(osMigartionModel.getObjName().trim(),
								externalNamespace.trim())) {
							osMigartionModel.setExternalNamespace("Y");
							break;
						}
					}
				}
			}
		}

		return osMigartionModel;
	}

	protected St03NData getSt03nData(final Row row, final long requestId, String fileName) {
		St03NData st03nData = new St03NData();
		int subTypeIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sub.Type"));

		String subType = row.getCell(subTypeIndex) == null ? "" : row.getCell(subTypeIndex).getStringCellValue().trim();

		if (subType.equalsIgnoreCase("ST03")) {
			int tCodeNameIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name"));
			int tCodeDescriptionIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Comment.C"));
			int usageCountIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Info"));
			int objTypeIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("OBJ"));

			String tCodeName = row.getCell(tCodeNameIndex) == null ? ""
					: row.getCell(tCodeNameIndex).getStringCellValue().trim();
			String tCodeDescription = row.getCell(tCodeDescriptionIndex) == null ? ""
					: row.getCell(tCodeDescriptionIndex).getStringCellValue().trim();
			String usageCount = row.getCell(usageCountIndex) == null ? "0"
					: row.getCell(usageCountIndex).getStringCellValue().replaceAll("[^0-9]", "");
			String objType = row.getCell(objTypeIndex) == null ? "" : row.getCell(objTypeIndex).getStringCellValue();

			st03nData.setRequestId(requestId);
			st03nData.settCodeName(tCodeName);
			st03nData.settCodeDescription(tCodeDescription);
			st03nData.setObjType(objType);

			if (StringUtils.isNotEmpty(usageCount) && StringUtils.isNumeric(usageCount))
				st03nData.setUsageCount(Integer.parseInt(usageCount));
		}

		return st03nData;
	}

	protected S4_SID getS4SID(String identifierCellValue, Row row, Long requestId, String fileName,
			Set<String> usageAnalysisObjNameType, Set<String> usageAnalysisObjNameTypeReadProg,
			List<String> externalNamespaceList) {
		S4_SID s4SID = new S4_SID();
		String[] splitArr = null;
		String identifier = "";
		int lineNo = 0;
		String totalScannedLines = "0";

		int objNameIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name"));
		int subTypeIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sub.Type"));
		int objPackageIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("OBJ.Pckg"));
		int objTypeIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("OBJ"));
		int stmtIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Code"));
		int commentIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Comments"));
		int descIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Info"));
		int readPrgIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Read.Prog"));
		int actStatusIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Act.Status"));

		if (identifierCellValue.startsWith("&31"))
			splitArr = identifierCellValue.split("&");

		identifier = splitArr[1];
		lineNo = Integer.parseInt(splitArr[2]);

		if (splitArr.length == 4) {
			totalScannedLines = splitArr[3];
		} else if (splitArr.length < 4) {
			totalScannedLines = "0";
		}

		String objType = row.getCell(objTypeIndex) == null ? "" : row.getCell(objTypeIndex).getStringCellValue().trim();
		String objectName = row.getCell(objNameIndex) == null ? ""
				: row.getCell(objNameIndex).getStringCellValue().trim();
		String readProgram = row.getCell(readPrgIndex) == null ? ""
				: row.getCell(readPrgIndex).getStringCellValue().trim();
		String objectNameType = row.getCell(objNameIndex) == null || row.getCell(objTypeIndex) == null ? ""
				: (row.getCell(objTypeIndex).getStringCellValue().trim())
						+ (row.getCell(objNameIndex).getStringCellValue().trim());
		/*
		 * String descOfChange = row.getCell(descIndex) == null ||
		 * row.getCell(descIndex).equals("") ||
		 * row.getCell(descIndex).getStringCellValue().trim().equals("") ?
		 * "SYSTEM ID: HARDCODING" :
		 * row.getCell(descIndex).getStringCellValue().trim();
		 */
		String impactReason = row.getCell(commentIndex) == null ? ""
				: row.getCell(commentIndex).getStringCellValue().trim();
		String statement = row.getCell(stmtIndex) == null ? "" : row.getCell(stmtIndex).getStringCellValue().trim();
		String pckg = row.getCell(objPackageIndex) == null ? ""
				: row.getCell(objPackageIndex).getStringCellValue().trim();
		String subObjectType = row.getCell(subTypeIndex) == null ? ""
				: row.getCell(subTypeIndex).getStringCellValue().trim();
		String actStatus = row.getCell(actStatusIndex) == null ? ""
				: row.getCell(actStatusIndex).getStringCellValue().trim();

		String s4ListObj = objectNameType.trim();
		s4ListObj = (s4ListObj.startsWith("USRE") || s4ListObj.startsWith("USRR"))
				? s4ListObj.replace(s4ListObj.substring(0, 4), "PROG") : s4ListObj;

		if (null != St03ReaderXlsx.getHm().getInventoryList()) {
			for (S4InventoryList invObj : St03ReaderXlsx.getHm().getInventoryList()) {
				if (invObj.getObjNameType().equalsIgnoreCase(objType + objectName)) {
					s4SID.setPckg(invObj.getPckg());
				}
			}
		} else {
			logger.info("Inventory List in Null or not filled yet");
		}
		s4SID.setIdentifier(identifier.trim());
		s4SID.setType(objType);
		s4SID.setObjName(objectName);
		s4SID.setSubObjType(subObjectType);
		s4SID.setLineNo(lineNo);
		s4SID.setStmt(statement);
		s4SID.setImpactReason(impactReason);
		// s4SID.setDescOfChange(descOfChange);
		s4SID.setTotalScannedLine(Integer.parseInt(totalScannedLines));
		s4SID.setObjNameType(objectNameType);
		s4SID.setReadProgram(readProgram);
		s4SID.setRequestID(requestId);

		// Setting External Namespace
		if (CollectionUtils.isNotEmpty(externalNamespaceList)
				&& !externalNamespaceList.stream().anyMatch("NA"::equalsIgnoreCase)) {
			if (!objectName.isEmpty()) {
				for (String externalNamespace : externalNamespaceList) {
					if (StringUtils.containsIgnoreCase(objectName.trim(), externalNamespace.trim())) {
						s4SID.setExternalNamespace("Y");
						break;
					}
				}
			}
		}

		// Hardcoded values for SID
		s4SID.setComplexity("Medium");
		s4SID.setIssueCategory("Information");
		if ("317".equalsIgnoreCase(identifier)) {
			s4SID.setOperations(actStatus);
			s4SID.setSolutionSteps(
					"Avoid Hardcoding; Instead use TVARVC or custom table to store the constant values.");
			s4SID.setDescOfChange("HARDCODED VALUES");
		} else {
			s4SID.setOperations(actStatus);
			s4SID.setSolutionSteps("Remove Hardcoding if system ID is changed");
			s4SID.setDescOfChange("SYSTEM ID: HARDCODING");
		}

		s4SID.setAutomationStatus("No");

		if (CollectionUtils.isNotEmpty(usageAnalysisObjNameType) && usageAnalysisObjNameType.contains(s4ListObj))
			s4SID.setUsed("Y");

		if (s4SID.getType().equalsIgnoreCase("AQQU")) {
			String objTypeNameReadProg = s4SID.getType() + s4SID.getObjName() + s4SID.getReadProgram();
			if (CollectionUtils.isNotEmpty(usageAnalysisObjNameTypeReadProg)
					&& usageAnalysisObjNameTypeReadProg.contains(objTypeNameReadProg))
				s4SID.setUsed("Y");
		}

		return s4SID;
	}

	protected ImpactedVariant getImpactedVariant(Row row, Long requestId, String fileName,
			List<String> externalNamespaceList) {
		ImpactedVariant impactedVariant = new ImpactedVariant();
		int objPkgIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("OBJ.Pckg"));
		int objNameIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name"));
		int readProgramIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Read.Prog"));
		int descIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("DESC"));
		int oDataIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Odata"));
		int commentCIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Comment.C"));
		int codeIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Code"));
		int infoIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Info"));
		int operationIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Operation"));
		int subTypeIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sub.Type"));
		int selectLineIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Select.Line"));
		int commntsIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Comments"));

		String objPackg = row.getCell(objPkgIndex) == null ? "" : row.getCell(objPkgIndex).getStringCellValue().trim();
		String objName = row.getCell(objNameIndex) == null ? "" : row.getCell(objNameIndex).getStringCellValue().trim();
		String readProgram = row.getCell(readProgramIndex) == null ? ""
				: row.getCell(readProgramIndex).getStringCellValue().trim();
		String desc = row.getCell(descIndex) == null ? "" : row.getCell(descIndex).getStringCellValue().trim();
		String oData = row.getCell(oDataIndex) == null ? "" : row.getCell(oDataIndex).getStringCellValue().trim();
		String commentC = row.getCell(commentCIndex) == null ? ""
				: row.getCell(commentCIndex).getStringCellValue().trim();
		String code = row.getCell(codeIndex) == null ? "" : row.getCell(codeIndex).getStringCellValue().trim();
		String info = row.getCell(infoIndex) == null ? "" : row.getCell(infoIndex).getStringCellValue().trim();
		String operation = row.getCell(operationIndex) == null ? ""
				: row.getCell(operationIndex).getStringCellValue().trim();
		String subType = row.getCell(subTypeIndex) == null ? "" : row.getCell(subTypeIndex).getStringCellValue().trim();
		String selectLine = row.getCell(selectLineIndex) == null ? ""
				: row.getCell(selectLineIndex).getStringCellValue().trim();
		String comments = row.getCell(commntsIndex) == null ? ""
				: row.getCell(commntsIndex).getStringCellValue().trim();

		impactedVariant.setReportName(objName);
		impactedVariant.setVariantName(objPackg);
		impactedVariant.setSelScreenFieldName(readProgram);
		impactedVariant.setKind(desc);
		impactedVariant.setSign(oData);
		impactedVariant.setVariantOption(commentC);
		impactedVariant.setLow(code);
		impactedVariant.setHigh(info);
		impactedVariant.setUserName(operation);
		impactedVariant.setVariantType(subType);
		impactedVariant.setComments(comments);
		impactedVariant.setVariantOperation(selectLine);
		impactedVariant.setRequestID(requestId);

		// Setting External Namespace
		if (CollectionUtils.isNotEmpty(externalNamespaceList)
				&& !externalNamespaceList.stream().anyMatch("NA"::equalsIgnoreCase)) {
			if (!objName.isEmpty()) {
				for (String externalNamespace : externalNamespaceList) {
					if (StringUtils.containsIgnoreCase(objName.trim(), externalNamespace.trim())) {
						impactedVariant.setExternalNamespace("Y");
						;
						break;
					}
				}
			}
		}

		return impactedVariant;
	}

	protected BwCleanupUtil getBwCleanupUtil(final Row row, final Long requestId, String fileName) {
		BwCleanupUtil bwCleanUtil = new BwCleanupUtil();
		int objTypeIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("OBJ.Pckg"));
		int objNameIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Operation"));
		int lastUsedIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Executed.By"));
		int elapsedTimIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("DESC"));
		int statusIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Comment.C"));

		String objType = row.getCell(objTypeIndex) == null ? "" : row.getCell(objTypeIndex).getStringCellValue().trim();
		String objName = row.getCell(objNameIndex) == null ? "" : row.getCell(objNameIndex).getStringCellValue().trim();
		String lastUsed = row.getCell(lastUsedIndex) == null ? ""
				: row.getCell(lastUsedIndex).getStringCellValue().trim();
		String elapsedTime = row.getCell(elapsedTimIndex) == null ? ""
				: row.getCell(elapsedTimIndex).getStringCellValue().trim();
		String status = row.getCell(statusIndex) == null ? "" : row.getCell(statusIndex).getStringCellValue().trim();

		bwCleanUtil.setObjectType(objType);
		bwCleanUtil.setObjectName(objName);
		bwCleanUtil.setLastUsedDate(lastUsed);
		bwCleanUtil.setElapsedTimInYrs(elapsedTime);
		bwCleanUtil.setStatus(status);
		bwCleanUtil.setRequestId(requestId);

		return bwCleanUtil;
	}

	protected S4ImpactedCustomTables getS4ImpactedCustomTableValues(Row row, Long requestId, String fileName) {
		S4ImpactedCustomTables s4ImpactCustomTbl = new S4ImpactedCustomTables();
		int objNameIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name"));
		int objPackageIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("OBJ.Pckg"));
		int commentIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Comments"));
		int infoIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Info"));

		String objectName = row.getCell(objNameIndex) == null ? ""
				: row.getCell(objNameIndex).getStringCellValue().trim();
		String impactReason = row.getCell(commentIndex) == null ? ""
				: row.getCell(commentIndex).getStringCellValue().trim();
		String info = row.getCell(infoIndex) == null ? "" : row.getCell(infoIndex).getStringCellValue().trim();

		String pckg = row.getCell(objPackageIndex) == null ? ""
				: row.getCell(objPackageIndex).getStringCellValue().trim();

		if (info.length() != 0) {
			if (info.charAt(info.length() - 1) == '$') {
				s4ImpactCustomTbl.setInfo(info.substring(0, (info.length() - 1)));
			} else {
				s4ImpactCustomTbl.setInfo(info);
			}
		}

		s4ImpactCustomTbl.setObjectName(objectName);
		s4ImpactCustomTbl.setComments(impactReason);
		// s4ImpactCustomTbl.setInfo(info);
		s4ImpactCustomTbl.setObjPackage(pckg);
		s4ImpactCustomTbl.setRequestId(requestId);

		return s4ImpactCustomTbl;
	}

	protected List<S4Detection> getS4DrillDownValues(Row row, Long requestId, String fileName) {
		S4Detection s4Detection = null;
		int infoIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Info"));
		String info = row.getCell(infoIndex) == null ? "" : row.getCell(infoIndex).getStringCellValue().trim();
		String[] strParts = info.split(",");
		List<String> listParts = Arrays.asList(strParts);
		HashSet<String> hsetFromString = new HashSet<String>(listParts);

		int objNameIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name"));
		int subTypeIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sub.Type"));
		int objPackageIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("OBJ.Pckg"));
		int objTypeIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("OBJ"));
		int commentIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Comments"));

		int readPrgIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Read.Prog"));
		int operationIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Act.Status"));

		String objType = row.getCell(objTypeIndex) == null ? "" : row.getCell(objTypeIndex).getStringCellValue().trim();
		String objectName = row.getCell(objNameIndex) == null ? ""
				: row.getCell(objNameIndex).getStringCellValue().trim();
		String readProgram = row.getCell(readPrgIndex) == null ? ""
				: row.getCell(readPrgIndex).getStringCellValue().trim();
		String impactReason = row.getCell(commentIndex) == null ? ""
				: row.getCell(commentIndex).getStringCellValue().trim();
		String pckg = row.getCell(objPackageIndex) == null ? ""
				: row.getCell(objPackageIndex).getStringCellValue().trim();
		String subObjectType = row.getCell(subTypeIndex) == null ? ""
				: row.getCell(subTypeIndex).getStringCellValue().trim();
		String operation = row.getCell(operationIndex) == null ? ""
				: row.getCell(operationIndex).getStringCellValue().trim();

		List<S4Detection> s4detect = new ArrayList<>();

		for (String s4Det : hsetFromString) {
			s4Detection = new S4Detection();

			s4Detection.setIdentifier(s4Det.trim());
			s4Detection.setObjectName(objectName);
			s4Detection.setSubType(subObjectType);
			s4Detection.setObjPackage(pckg);
			s4Detection.setObjType(objType);
			s4Detection.setComments(impactReason);
			s4Detection.setREAD_PROG(readProgram);
			s4Detection.setOperations(operation);
			s4Detection.setType(objType);
			// where in ZAICAT_DETECTION, OPERATION='CUSTOM_FIELDS'
			s4Detection.setRequestId(requestId);
			s4detect.add(s4Detection);
		}

		return s4detect;
	}

	protected CvitCustomisingLogs getCvitCustomLogs(Row row, long requestId, String fileName) {
		CvitCustomisingLogs cvitCustomLogs = null;

		int indentifierIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Operation.Code"));
		String identifierCellVal = row.getCell(indentifierIndex) == null ? ""
				: row.getCell(indentifierIndex).getStringCellValue().replaceAll("\\s", StringUtils.EMPTY);

		if (identifierCellVal.startsWith("LCVIT")) {
			cvitCustomLogs = new CvitCustomisingLogs();

			int objNameIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Obj.Name"));
			String objNameVal = row.getCell(objNameIndex) == null ? ""
					: row.getCell(objNameIndex).getStringCellValue().trim();
			int selectLineIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Select.Line"));
			String selectLineCellVal = row.getCell(selectLineIndex) == null ? ""
					: row.getCell(selectLineIndex).getStringCellValue().trim();
			int actStIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Act.Status"));
			String actStVal = row.getCell(actStIndex) == null ? ""
					: row.getCell(actStIndex).getStringCellValue().trim();

			String[] splitArr;
			splitArr = identifierCellVal.split("~");

			int customerCount = 0;
			String operationVal = "";
			int vendorCount = 0;
			String descVal = "";

			if (splitArr.length >= 3) {
				if (splitArr[1].equalsIgnoreCase("c")) {
					customerCount = Integer.parseInt(splitArr[2]);
					int operationIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Operation"));
					operationVal = row.getCell(operationIndex) == null ? ""
							: row.getCell(operationIndex).getStringCellValue().trim();
				} else if (splitArr[1].equalsIgnoreCase("v")) {
					vendorCount = Integer.parseInt(splitArr[2]);
					int descIndex = Integer.parseInt(
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("DESC"));
					descVal = row.getCell(descIndex) == null ? "" : row.getCell(descIndex).getStringCellValue().trim();
				}
			}

			cvitCustomLogs.setRequestId(requestId);
			cvitCustomLogs.setObjectName(objNameVal);
			cvitCustomLogs.setCustomisingErrors(actStVal);
			cvitCustomLogs.setText(selectLineCellVal);
			cvitCustomLogs.setCustomerCount(customerCount);
			cvitCustomLogs.setCustomerLogs(operationVal);
			cvitCustomLogs.setVendorCount(vendorCount);
			cvitCustomLogs.setVendorLogs(descVal);
		}

		return cvitCustomLogs;
	}

	protected CvitErrorMessages getCvitErrorMessages(Row row, long requestId, String fileName) {
		CvitErrorMessages cvitErrorMsgs = null;

		int indentifierIndex = Integer
				.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Operation.Code"));
		String identifierCellVal = row.getCell(indentifierIndex) == null ? ""
				: row.getCell(indentifierIndex).getStringCellValue().replaceAll("\\s", StringUtils.EMPTY);

		if (identifierCellVal.startsWith("MLCVIT")) {
			cvitErrorMsgs = new CvitErrorMessages();

			int subTypeIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Sub.Type"));
			String subTypeVal = row.getCell(subTypeIndex) == null ? ""
					: row.getCell(subTypeIndex).getStringCellValue().trim().replaceAll("^0+(?!$)", "");
			int selectLineIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Select.Line"));
			String selectLineCellVal = row.getCell(selectLineIndex) == null ? ""
					: row.getCell(selectLineIndex).getStringCellValue().trim();
			int actStIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Act.Status"));
			String actStVal = row.getCell(actStIndex) == null ? ""
					: row.getCell(actStIndex).getStringCellValue().trim().replaceAll("^0+(?!$)", "");
			int objectPackageIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("OBJ.Pckg"));
			String objPkgVal = row.getCell(objectPackageIndex) == null ? ""
					: row.getCell(objectPackageIndex).getStringCellValue().trim();
			int readProgIndex = Integer
					.parseInt(Hana_Profiler_Constant.ID_FILE_KEY_VALUE.get(requestId).get(fileName).get("Read.Prog"));
			String readProgVal = row.getCell(readProgIndex) == null ? ""
					: row.getCell(readProgIndex).getStringCellValue().trim();

			cvitErrorMsgs.setRequestId(requestId);
			cvitErrorMsgs.setRunId(subTypeVal);
			cvitErrorMsgs.setIndicator(readProgVal);
			cvitErrorMsgs.setCustomerVendor(actStVal);
			cvitErrorMsgs.setFieldName(objPkgVal);
			cvitErrorMsgs.setErrorLog(selectLineCellVal);
		}

		return cvitErrorMsgs;
	}
}
