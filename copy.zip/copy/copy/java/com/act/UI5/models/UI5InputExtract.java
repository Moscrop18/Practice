package com.act.UI5.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

/**
 * @author rohan.a.mehra
 *
 */
@Entity
@Table(name = "UI5_EXTRACT")
public class UI5InputExtract implements Serializable {


	@Id	
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "ID")
	private Integer Id;
	@Column(name = "UI_Element")
	private String uielemt;
	@Column(name = "Attribute")
	private String attribute;
	@Column(name = "LineNumber")
	private int linenumber;
	@Column(name = "FileName")
	private String filename;
	@Column(name = "ProjectName")
	private String projectName;
	
	@Column(name="REQUEST_ID")
	@Index(name="Index_Request_id")
	private long REQUEST_ID;
	
	public long getREQUEST_ID() {
		return REQUEST_ID;
	}
	public void setREQUEST_ID(long rEQUEST_ID) {
		REQUEST_ID = rEQUEST_ID;
	}
	/**
	 * @return the uielemt
	 */
	public final String getUielemt() {
		return uielemt;
	}
	/**
	 * @param uielemt the uielemt to set
	 */
	public final void setUielemt(String uielemt) {
		this.uielemt = uielemt;
	}
	/**
	 * @return the attribute
	 */
	public final String getAttribute() {
		return attribute;
	}
	/**
	 * @param attribute the attribute to set
	 */
	public final void setAttribute(String attribute) {
		this.attribute = attribute;
	}
	/**
	 * @return the linenumber
	 */
	public final int getLinenumber() {
		return linenumber;
	}
	/**
	 * @param linenumber the linenumber to set
	 */
	public final void setLinenumber(int linenumber) {
		this.linenumber = linenumber;
	}
	/**
	 * @return the filename
	 */
	public final String getFilename() {
		return filename;
	}
	/**
	 * @param filename the filename to set
	 */
	public final void setFilename(String filename) {
		this.filename = filename;
	}
	
	/**
	 * @return the id
	 */
	public final Integer getId() {
		return Id;
	}
	/**
	 * @param id the id to set
	 */
	public final void setId(Integer id) {
		Id = id;
	}
	/**
	 * @return the projectName
	 */
	public final String getProjectName() {
		return projectName;
	}
	/**
	 * @param projectName the projectName to set
	 */
	public final void setProjectName(String projectName) {
		this.projectName = projectName;
	}	
	
	}
