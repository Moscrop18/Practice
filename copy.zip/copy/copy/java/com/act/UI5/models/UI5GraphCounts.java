package com.act.UI5.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

/**
 * @author himani.malhotra
 *
 */
@Entity
@Table(name = "UI5_COUNTS")
public class UI5GraphCounts implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1664086921273798940L;
	@Id	
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "ID")
	private Integer Id;
	
	@Column(name = "Compatible_Total_API_Counts")
	private Long comptibleTotalApiCounts;
	@Column(name = "Source_Code_Changes_Total_API_Counts")
	private Long srcCodeChangesTotalApiCounts;
	@Column(name = "Recommended_Changes_Total_API_Counts")
	private Long recommendedChangesTotalApiCounts;
	
	@Column(name = "Compatible_Depricated_API_Counts")
	private Long compatibleDepricatedApiCounts;
	@Column(name = "Source_Code_Changes_Depricated_API_Counts")
	private Long srcCodeChangesDepricatedApiCounts;
	@Column(name = "Recommended_Changes_Depricated_API_Counts")
	private Long recommendedChangesDepricatedApiCounts;
	
	@Column(name="REQUEST_ID")
	@Index(name="Index_Request_id")
	private long REQUEST_ID;

	public long getREQUEST_ID() {
		return REQUEST_ID;
	}


	public void setREQUEST_ID(long rEQUEST_ID) {
		REQUEST_ID = rEQUEST_ID;
	}
	
	public Integer getId() {
		return Id;
	}


	public void setId(Integer id) {
		Id = id;
	}


	public Long getComptibleTotalApiCounts() {
		return comptibleTotalApiCounts;
	}


	public void setComptibleTotalApiCounts(Long countListApi) {
		this.comptibleTotalApiCounts = countListApi;
	}


	public Long getSrcCodeChangesTotalApiCounts() {
		return srcCodeChangesTotalApiCounts;
	}


	public void setSrcCodeChangesTotalApiCounts(Long srcCodeChangesTotalApiCounts) {
		this.srcCodeChangesTotalApiCounts = srcCodeChangesTotalApiCounts;
	}


	public Long getRecommendedChangesTotalApiCounts() {
		return recommendedChangesTotalApiCounts;
	}


	public void setRecommendedChangesTotalApiCounts(Long recommendedChangesTotalApiCounts) {
		this.recommendedChangesTotalApiCounts = recommendedChangesTotalApiCounts;
	}


	public Long getCompatibleDepricatedApiCounts() {
		return compatibleDepricatedApiCounts;
	}


	public void setCompatibleDepricatedApiCounts(Long compatibleDepricatedApiCounts) {
		this.compatibleDepricatedApiCounts = compatibleDepricatedApiCounts;
	}


	public Long getSrcCodeChangesDepricatedApiCounts() {
		return srcCodeChangesDepricatedApiCounts;
	}


	public void setSrcCodeChangesDepricatedApiCounts(Long srcCodeChangesDepricatedApiCounts) {
		this.srcCodeChangesDepricatedApiCounts = srcCodeChangesDepricatedApiCounts;
	}


	public Long getRecommendedChangesDepricatedApiCounts() {
		return recommendedChangesDepricatedApiCounts;
	}


	public void setRecommendedChangesDepricatedApiCounts(Long recommendedChangesDepricatedApiCounts) {
		this.recommendedChangesDepricatedApiCounts = recommendedChangesDepricatedApiCounts;
	}


	
}
