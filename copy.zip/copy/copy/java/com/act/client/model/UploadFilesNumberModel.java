package com.act.client.model;

import java.util.ArrayList;

import com.act.bw.model.BwInputFileNameAndDateFormat;

public class UploadFilesNumberModel {
	
	private int num_SRC_AGR1251;
	private int num_SRC_USOBTC;
	private int num_SRC_AGRUSERS;
	private long requestId;
	
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public int getNum_SRC_AGR1251() {
		return num_SRC_AGR1251;
	}
	public void setNum_SRC_AGR1251(int num_SRC_AGR1251) {
		this.num_SRC_AGR1251 = num_SRC_AGR1251;
	}
	public int getNum_SRC_USOBTC() {
		return num_SRC_USOBTC;
	}
	public void setNum_SRC_USOBTC(int num_SRC_USOBTC) {
		this.num_SRC_USOBTC = num_SRC_USOBTC;
	}
	public int getNum_SRC_AGRUSERS() {
		return num_SRC_AGRUSERS;
	}
	public void setNum_SRC_AGRUSERS(int num_SRC_AGRUSERS) {
		this.num_SRC_AGRUSERS = num_SRC_AGRUSERS;
	}
	
	private String dt_RSICCONTODSO;
	private String dt_RSICCONTInfocube;
	private String dt_RSANT_PROCESSRAnalysis_Process_Designer;
	private String dt_RSBKREQUESTOpen_Hub_Destination;
	private String dt_RSRREPDIRBEX_Queries;
	private String dt_RSRREPDIRBEX_Workbook;
	private String dt_BIOAPERS_SOD00Web_Application_Design7x;
	private String dt_BIOAPERS_SOD00Web_Application_Design3x;
	private String dt_RSPCPROCESSLOGProcess_Chain;

	
	
	public String getDt_RSICCONTODSO() {
		return dt_RSICCONTODSO;
	}
	public void setDt_RSICCONTODSO(String dt_RSICCONTODSO) {
		this.dt_RSICCONTODSO = dt_RSICCONTODSO;
	}
	public String getDt_RSICCONTInfocube() {
		return dt_RSICCONTInfocube;
	}
	public void setDt_RSICCONTInfocube(String dt_RSICCONTInfocube) {
		this.dt_RSICCONTInfocube = dt_RSICCONTInfocube;
	}
	
	public String getDt_RSBKREQUESTOpen_Hub_Destination() {
		return dt_RSBKREQUESTOpen_Hub_Destination;
	}
	public void setDt_RSBKREQUESTOpen_Hub_Destination(String dt_RSBKREQUESTOpen_Hub_Destination) {
		this.dt_RSBKREQUESTOpen_Hub_Destination = dt_RSBKREQUESTOpen_Hub_Destination;
	}
	public String getDt_RSRREPDIRBEX_Queries() {
		return dt_RSRREPDIRBEX_Queries;
	}
	public void setDt_RSRREPDIRBEX_Queries(String dt_RSRREPDIRBEX_Queries) {
		this.dt_RSRREPDIRBEX_Queries = dt_RSRREPDIRBEX_Queries;
	}
	public String getDt_RSRREPDIRBEX_Workbook() {
		return dt_RSRREPDIRBEX_Workbook;
	}
	public void setDt_RSRREPDIRBEX_Workbook(String dt_RSRREPDIRBEX_Workbook) {
		this.dt_RSRREPDIRBEX_Workbook = dt_RSRREPDIRBEX_Workbook;
	}
	public String getDt_BIOAPERS_SOD00Web_Application_Design7x() {
		return dt_BIOAPERS_SOD00Web_Application_Design7x;
	}
	public void setDt_BIOAPERS_SOD00Web_Application_Design7x(String dt_BIOAPERS_SOD00Web_Application_Design7x) {
		this.dt_BIOAPERS_SOD00Web_Application_Design7x = dt_BIOAPERS_SOD00Web_Application_Design7x;
	}
	public String getDt_BIOAPERS_SOD00Web_Application_Design3x() {
		return dt_BIOAPERS_SOD00Web_Application_Design3x;
	}
	public void setDt_BIOAPERS_SOD00Web_Application_Design3x(String dt_BIOAPERS_SOD00Web_Application_Design3x) {
		this.dt_BIOAPERS_SOD00Web_Application_Design3x = dt_BIOAPERS_SOD00Web_Application_Design3x;
	}
	public String getDt_RSPCPROCESSLOGProcess_Chain() {
		return dt_RSPCPROCESSLOGProcess_Chain;
	}
	public void setDt_RSPCPROCESSLOGProcess_Chain(String dt_RSPCPROCESSLOGProcess_Chain) {
		this.dt_RSPCPROCESSLOGProcess_Chain = dt_RSPCPROCESSLOGProcess_Chain;
	}
	public String getDt_RSANT_PROCESSRAnalysis_Process_Designer() {
		return dt_RSANT_PROCESSRAnalysis_Process_Designer;
	}
	public void setDt_RSANT_PROCESSRAnalysis_Process_Designer(String dt_RSANT_PROCESSRAnalysis_Process_Designer) {
		this.dt_RSANT_PROCESSRAnalysis_Process_Designer = dt_RSANT_PROCESSRAnalysis_Process_Designer;
	}

	private Boolean ODSO;
	private Boolean Multiprovider;
	private Boolean IOBJ;
	private Boolean Infocube;
	private Boolean Open_Hub_Destination;
	private ArrayList<String> objscope;
	
	public ArrayList<String> getObjscope() {
		return objscope;
	}
	public void setObjscope(ArrayList<String> objscope) {
		this.objscope = objscope;
	}
	public Boolean getODSO() {
		return ODSO;
	}
	public void setODSO(Boolean oDSO) {
		ODSO = oDSO;
	}
	public Boolean getMultiprovider() {
		return Multiprovider;
	}
	public void setMultiprovider(Boolean multiprovider) {
		Multiprovider = multiprovider;
	}
	public Boolean getIOBJ() {
		return IOBJ;
	}
	public void setIOBJ(Boolean iOBJ) {
		IOBJ = iOBJ;
	}
	public Boolean getInfocube() {
		return Infocube;
	}
	public void setInfocube(Boolean infocube) {
		Infocube = infocube;
	}
	public Boolean getOpen_Hub_Destination() {
		return Open_Hub_Destination;
	}
	public void setOpen_Hub_Destination(Boolean open_Hub_Destination) {
		Open_Hub_Destination = open_Hub_Destination;
	}

	

}
