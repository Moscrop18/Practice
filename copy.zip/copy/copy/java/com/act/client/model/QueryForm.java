package com.act.client.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="CLIENT_QUERY")
public class QueryForm implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	
	private int id;
	
	@NotEmpty(message ="Please Enter The Query Content")
	private String QueryContent;
	@NotEmpty(message ="Please Enter The Query Subject")
	private String QuerySubject;
	
	private String userEmailID;


	@Id
	@GenericGenerator(name="kaugen" , strategy="increment")
	@GeneratedValue(generator="kaugen")
	@Column(name="ID")
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}	

	@Column(name="Query_Subject",length=2000)
	public String getQuerySubject() {
		return QuerySubject;
	}

	public void setQuerySubject(String querySubject) {
		QuerySubject = querySubject;
	}

	@Column(name="Query_Content",length=2000)
	public String getQueryContent() {
		return QueryContent;
	}

	public void setQueryContent(String QueryContent) {
		this.QueryContent = QueryContent;
	}

	@Column(name="User_Email")
	public String getUserEmailID() {
		return userEmailID;
	}

	public void setUserEmailID(String userEmailID) {
		this.userEmailID = userEmailID;
	}
	
	
	



}
