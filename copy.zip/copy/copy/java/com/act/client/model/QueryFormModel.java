package com.act.client.model;

public class QueryFormModel implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	
	private int id;
	private String QueryContent;
	private String QuerySubject;
	private String userEmailID;

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}	
	public String getQuerySubject() {
		return QuerySubject;
	}
	public void setQuerySubject(String querySubject) {
		QuerySubject = querySubject;
	}
	public String getQueryContent() {
		return QueryContent;
	}
	public void setQueryContent(String QueryContent) {
		this.QueryContent = QueryContent;
	}
	public String getUserEmailID() {
		return userEmailID;
	}
	public void setUserEmailID(String userEmailID) {
		this.userEmailID = userEmailID;
	}

}
