/**
 * @author rohan.a.mehra
 *
 */
package com.act.client.model;



import javax.persistence.*;

import org.hibernate.annotations.Type;




@Entity
@Table(name="REQUEST_FORM_FILE")
public class RequestFormFile implements java.io.Serializable {

	
	//private long ID;

	private long requestID;
	
	private String REQUEST_ID_UI;
	
	private byte[] FiatFile1;
	
	private byte[] FiatFile2;
	
	private byte[] FiatFile3;  
	
	private boolean downloadStatusFile1=false;
	
	private boolean downloadStatusFile2=false;
	
	private boolean downloadStatusFile3=false;
	
	private byte[] FinalFiatFile;
	
	private String ewaFile1Name;
	
	private String sizingReportFile2Name;
	
	private String OtherFile3Name;

	
	@Column(name="FiatFile3") 
	@Type(type="org.hibernate.type.MaterializedBlobType")
	public byte[] getFiatFile3() {
		return FiatFile3;
	}
	public void setFiatFile3(byte[] fiatFile3) {
		FiatFile3 = fiatFile3;
	}
	
	@Column(name="Other_File3_Name")
	public String getOtherFile3Name() {
		return OtherFile3Name;
	}
	public void setOtherFile3Name(String otherFile3Name) {
		OtherFile3Name = otherFile3Name;
	}

	
	@Id
	@Column(name="requestID")
	public long getRequestID() {
			return requestID;
	}
	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}


	@Column(name="REQUEST_ID_UI",nullable = false)
	public String getREQUEST_ID_UI() {
		return REQUEST_ID_UI;
	}
	public void setREQUEST_ID_UI(String rEQUEST_ID_UI) {
		REQUEST_ID_UI = rEQUEST_ID_UI;
	}

	

	@Column(name="FiatFile1")
	@Type(type="org.hibernate.type.MaterializedBlobType")
	  public byte[] getFiatFile1() {
		return FiatFile1;
	}
	
	@Column(name="FiatFile3_Download_Status")
	public boolean isDownloadStatusFile3() {
		return downloadStatusFile3;
	}
	public void setDownloadStatusFile3(boolean downloadStatusFile3) {
		this.downloadStatusFile3 = downloadStatusFile3;
	}
	public void setFiatFile1(byte[] fiatFile1) {
		FiatFile1 = fiatFile1;
	}
	
	
	@Column(name="FiatFile2") 
	@Type(type="org.hibernate.type.MaterializedBlobType")
	public byte[] getFiatFile2() {
		return FiatFile2;
	}
	public void setFiatFile2(byte[] fiatFile2) {
		FiatFile2 = fiatFile2;
	}

	@Column(name="FiatFile1_Download_Status")
	public boolean isDownloadStatusFile1() {
		return downloadStatusFile1;
	}

	public void setDownloadStatusFile1(boolean downloadStatusFile1) {
		this.downloadStatusFile1 = downloadStatusFile1;
	}

	@Column(name="FiatFile2_Download_Status")
	public boolean isDownloadStatusFile2() {
		return downloadStatusFile2;
	}

	public void setDownloadStatusFile2(boolean downloadStatusFile2) {
		this.downloadStatusFile2 = downloadStatusFile2;
	}

	@Column(name="Final_Fiat_File")
	@Type(type="org.hibernate.type.MaterializedBlobType")
	public byte[] getFinalFiatFile() {
		return FinalFiatFile;
	}

	public void setFinalFiatFile(byte[] finalFiatFile) {
		FinalFiatFile = finalFiatFile;
	}

	@Column(name="EWA_File1_Name")
	public String getEwaFile1Name() {
		return ewaFile1Name;
	}

	public void setEwaFile1Name(String ewaFile1Name) {
		this.ewaFile1Name = ewaFile1Name;
	}

	@Column(name="SizingReport_File2_Name")
	public String getSizingReportFile2Name() {
		return sizingReportFile2Name;
	}

	public void setSizingReportFile2Name(String sizingReportFile2Name) {
		this.sizingReportFile2Name = sizingReportFile2Name;
	}

	
	
}
