package com.act.client.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "RequestStatus_Master")
public class RequestStatusMaster {

	private long requestId;
	private String irpaStatus = "NA";
	
	@Id
	@Column(name = "Request_Id")
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	
	@Column(name = "IRPA_Status")
	public String getIrpaStatus() {
		return irpaStatus;
	}
	public void setIrpaStatus(String irpaStatus) {
		this.irpaStatus = irpaStatus;
	}
}
