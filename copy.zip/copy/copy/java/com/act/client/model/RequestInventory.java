package com.act.client.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import com.act.utility.HANAUtility;


/**
 * @author rohan.a.mehra
 *
 */
@Entity

@Table(name="REQUEST_INVENTORY")

public class RequestInventory implements Serializable{

	//public int requestInventoryID;
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7651965613946139927L;
	public long requestID;
	public String requestShortdescription;
	public String requestStatus;
	public RequestForm requestForm;
	public String  trAttachementName;
	public String  deletionTRAttachementName;
	  
	
	private String REQUEST_ID_UI;
	
	public String  SUB_STATUS;
	public String assigned_poc_emailId;
	public String poc_status;
	public String poc_comments;
	
	private String rfpStatus;
	
	public String getRfpStatus() {
		return rfpStatus;
	}

	public void setRfpStatus(String rfpStatus) {
		this.rfpStatus = rfpStatus;
	}

	/*public String pendingReason;
	String rejectionComments;
	String completedStatus;*/
	String comments;
	private Boolean trDownloadStatus=false;
	private Boolean deletiontrDownloadStatus=false;
	
	@Column(name="DELETION_TR_DOWNLOAD_STATUS")
	public Boolean getDeletiontrDownloadStatus() {
		return deletiontrDownloadStatus;
	}

	public void setDeletiontrDownloadStatus(Boolean deletiontrDownloadStatus) {
		this.deletiontrDownloadStatus = deletiontrDownloadStatus;
	}

	private Boolean contentDownloadStatus=false;

	
	private Long createdDate;
	
	
	private Long updatedDate;
	
	
	private Date createdDateDt;
	
	private Date updatedDateDt;
	
	private String businessStatus;
	
	private String creatorUser;
	private String updateUser;
	private String toolName;
	
	
	private String assignedFaitEmailId;
	
	
	private String pocFiatStatus;
	
	private String journeyCategory;
	
	private String pocSubStatus;
	private String s4ValidationVersion;
	private Boolean s4ValidationDownloadStatus=false;
	private Boolean preReqDownloadStatus=false;
	private Boolean finalFileDnldSts=false;
	private Boolean saFileDnldSts=false;
	private Boolean bwFileDnldSts=false;
	public RequestInventory() {
	}
   
	/*@Id
	@GeneratedValue
	@Column(name="REQUEST_INVENTORY_ID")
	
	public int getRequestInventoryID() {
		return requestInventoryID;
	}

	public void setRequestInventoryID(int requestInventoryID) {
		this.requestInventoryID = requestInventoryID;
	}*/
	
	
	        @Id
	        @Column(name = "REQUEST_ID")
		    @GeneratedValue(generator = "gen")
		    @GenericGenerator(name = "gen", strategy = "foreign",
	        parameters = @Parameter(name = "property", value = "requestForm"))

	public long getRequestID() {
		return requestID;
	}

	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}
	
	@Column(name="CONTENT_DOWNLOAD_STATUS")
	public Boolean getContentDownloadStatus() {
		return contentDownloadStatus;
	}

	public void setContentDownloadStatus(Boolean contentDownloadStatus) {
		this.contentDownloadStatus = contentDownloadStatus;
	}


	@Column(name="CREATOR_USER",nullable = false)
	public String getCreatorUser() {
		return creatorUser;
	}

	public void setCreatorUser(String creatorUser) {
		this.creatorUser = creatorUser;
	}
	
	
	@Column(name="UPDATE_USER",nullable = false)
	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
	
	@Column(name="DELETION_TR_ATTACHMENT")
	public String getDeletionTRAttachementName() {
		return deletionTRAttachementName;
	}

	public void setDeletionTRAttachementName(String deletionTRAttachementName) {
		this.deletionTRAttachementName = deletionTRAttachementName;
	}
	
	
	
	
	
	@Column(name="REQUEST_SHORT_DESCRIPTION",nullable = false)
	public String getRequestShortdescription() {
		return requestShortdescription;
	}

	

	public void setRequestShortdescription(String requestShortdescription) {
		this.requestShortdescription = requestShortdescription;
	}
	
	@Column(name="REQUEST_STATUS",nullable = false)
	public String getRequestStatus() {
		return requestStatus;
	}

	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	
	}
	
	
	
	@OneToOne(mappedBy="requestInventory")

	public RequestForm getRequestForm() {
		return requestForm;
	}

	public void setRequestForm(RequestForm requestForm) {
		this.requestForm = requestForm;
	}
	
	@Column(name="TR_ATTACHMENT")
	public String getTrAttachementName() {
		return trAttachementName;
	}
	public void setTrAttachementName(String trAttachementName) {
		this.trAttachementName = trAttachementName;
	}
	
	
	/*@Column(name="REASON_FOR_PENDING")
	public String getPendingReason() {
		return pendingReason;
	}

	public void setPendingReason(String pendingReason) {
		pendingReason = pendingReason;
	}*/
	
	/*@Column(name="REJECTION_COMMENTS")
	public String getRejectionComments() {
		return rejectionComments;
	}
	public void setRejectionComments(String rejectionComments) {
		this.rejectionComments = rejectionComments;
	}
	
	@Column(name="COMPLETED_STATUS")
	public String getCompletedStatus() {
		return completedStatus;
	}

	public void setCompletedStatus(String completedStatus) {
		this.completedStatus = completedStatus;
	}*/
	
	@Column(name="COMMENTS" , length = 200)
	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}
	
	 /*@Autowired
    @OneToOne(fetch = FetchType.LAZY)
	@PrimaryKeyJoinColumn

	public RequestForm requestForm;
	
	public RequestForm getRequestForm() {
		return requestForm;
	}

	public void setRequestForm(RequestForm requestForm) {
		this.requestForm = requestForm;
	}
*/
	
	/*@OneToOne(cascade = CascadeType.ALL,targetEntity = RequestForm.class)
	@JoinColumn(name = "REQUEST_ID", referencedColumnName = "REQUEST_ID")*/
	
	/*@GenericGenerator(name = "generator", strategy = "foreign", 
			parameters = @Parameter(name = "property", value = "requestForm"))
			@Id
			@GeneratedValue(generator = "generator")
			@Column(name = "REQUEST_ID", unique = true, nullable = false)*/
	@Column(name="CREATED_DATE")
	public Long getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(final Long createdDate) {
		this.createdDate = createdDate;
	}
	
	@Column(name="UPDATED_DATE")
	public Long getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(final Long updatedDate) {
		this.updatedDate = updatedDate;
	}

	@Transient
	public Date getCreatedDateDt() {
		return createdDateDt;
	}

	public void setCreatedDateDt(final Date createdDateDt) {
		this.createdDateDt = createdDateDt;
	}

	@Transient
	public Date getUpdatedDateDt() {
		return updatedDate!=null ? new Date(updatedDate) : null;
		
		
	}

	public void setUpdatedDateDt(final Date updatedDateDt) {
		this.updatedDateDt = updatedDateDt;
	}

	@Transient
	public String getBusinessStatus() {
		return HANAUtility.getBusinessStatus(requestStatus);
	}
	public void setBusinessStatus(String businessStatus) {
		this.businessStatus = businessStatus;
	}
	
	@Column(name="TR_DOWNLOAD_STATUS")
	public Boolean getTrDownloadStatus() {
		return trDownloadStatus;
	}

	public void setTrDownloadStatus(Boolean trDownloadStatus) {
		this.trDownloadStatus = trDownloadStatus;
	}

	@Column(name="TOOL_NAME")
	public String getToolName() {
		return toolName;
	}

	public void setToolName(String toolName) {
		this.toolName = toolName;
	}
	
	@Column(name="REQUEST_ID_UI")
	public String getREQUEST_ID_UI() {
		return REQUEST_ID_UI;
	}
	public void setREQUEST_ID_UI(String rEQUEST_ID_UI) {
		REQUEST_ID_UI = rEQUEST_ID_UI;
	}

	
	
	@Column(name="SUB_STATUS")
	public String getSUB_STATUS() {
		return SUB_STATUS;
	}

	public void setSUB_STATUS(String sUB_STATUS) {
		SUB_STATUS = sUB_STATUS;
	}

	@Column(name="ASSIGNED_POC_EMAILID")
	public String getAssigned_poc_emailId() {
		return assigned_poc_emailId;
	}

	public void setAssigned_poc_emailId(String assigned_poc_emailId) {
		this.assigned_poc_emailId = assigned_poc_emailId;
	}

	@Column(name="POC_STATUS")
	public String getPoc_status() {
		return poc_status;
	}

	public void setPoc_status(String poc_status) {
		this.poc_status = poc_status;
	}

	@Column(name="POC_COMMENTS")
	public String getPoc_comments() {
		return poc_comments;
	}

	public void setPoc_comments(String poc_comments) {
		this.poc_comments = poc_comments;
	}

	
	

	@Column(name = "assigned_Fait_EmailId")
	public String getAssignedFaitEmailId() {
		return assignedFaitEmailId;
	}

	public void setAssignedFaitEmailId(String assignedFaitEmailId) {
		this.assignedFaitEmailId = assignedFaitEmailId;
	}

	
	@Column(name = "poc_Fiat_Status")
	public String getPocFiatStatus() {
		return pocFiatStatus;
	}

	public void setPocFiatStatus(String pocFiatStatus) {
		this.pocFiatStatus = pocFiatStatus;
	}
	
	@Column(name = "Journey_Category")
	public String getJourneyCategory() {
		return journeyCategory;
	}
	
	public void setJourneyCategory(String journeyCategory) {
		this.journeyCategory = journeyCategory;
	}

	@Column(name = "poc_sub_status")
	public String getPocSubStatus() {
		return pocSubStatus;
	}

	public void setPocSubStatus(String pocSubStatus) {
		this.pocSubStatus = pocSubStatus;
	}

	@Column(name = "S4_VALIDATION_VERSION")
	public String getS4ValidationVersion() {
		return s4ValidationVersion;
	}

	public void setS4ValidationVersion(String s4ValidationVersion) {
		this.s4ValidationVersion = s4ValidationVersion;
	}
	
	@Column(name = "S4_VAL_DOWNLOAD_STATUS")
	public Boolean getS4ValidationDownloadStatus() {
		return s4ValidationDownloadStatus;
	}

	public void setS4ValidationDownloadStatus(Boolean s4ValidationDownloadStatus) {
		this.s4ValidationDownloadStatus = s4ValidationDownloadStatus;
	}

	@Column(name = "PRE_REQ_DOWNLOAD_STATUS")
	public Boolean getPreReqDownloadStatus() {
		return preReqDownloadStatus;
	}

	public void setPreReqDownloadStatus(Boolean preReqDownloadStatus) {
		this.preReqDownloadStatus = preReqDownloadStatus;
	}

	@Column(name = "FNL_DOWNLOAD_STATUS")
	public Boolean getFinalFileDnldSts() {
		return finalFileDnldSts;
	}

	public void setFinalFileDnldSts(Boolean finalFileDnldSts) {
		this.finalFileDnldSts = finalFileDnldSts;
	}

	@Column(name = "SA_DOWNLOAD_STATUS")
	public Boolean getSaFileDnldSts() {
		return saFileDnldSts;
	}

	public void setSaFileDnldSts(Boolean saFileDnldSts) {
		this.saFileDnldSts = saFileDnldSts;
	}

	@Column(name = "BW_DOWNLOAD_STATUS")
	public Boolean getBwFileDnldSts() {
		return bwFileDnldSts;
	}

	public void setBwFileDnldSts(Boolean bwFileDnldSts) {
		this.bwFileDnldSts = bwFileDnldSts;
	}
	private Boolean isSubRequest =false;
	private Long mainRequestId;
	@Column(name = "IS_SUB_REQUEST", nullable = false)
	public Boolean getIsSubRequest() {
		return isSubRequest;
	}

	public void setIsSubRequest(Boolean isSubRequest) {
		this.isSubRequest = isSubRequest;
	}

	@Column(name = "MAIN_REQUEST_ID")
	public Long getMainRequestId() {
		return mainRequestId;
	}

	public void setMainRequestId(Long mainRequestId) {
		this.mainRequestId = mainRequestId;
	}
	private String mainRequestIdUI;

	@Column(name = "MAIN_REQUEST_UID")
	public String getMainRequestIdUI() {
		return mainRequestIdUI;
	}

	public void setMainRequestIdUI(String mainRequestIdUI) {
		this.mainRequestIdUI = mainRequestIdUI;
	}
}
