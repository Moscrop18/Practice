/* MODIFIED 
 *FOR Enhancement CR-3.0:- Remove unused fields(like Customer_namespaces,
				SPECIFIC_NAMING_CONEVNTIONS,NAMESPACE_DETAILS_FILE,NAMESPACE_DETAILS_FILE_NAME,NAMING_CONEVNTIONS_FILE,
				NAMING_CONVENTIONS_FILE_NAME) from create request form. -23/12/16 -monika.mishra */
package com.act.client.model;

import java.util.ArrayList;

import org.springframework.web.multipart.MultipartFile;

public class RequestFormModel implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	
	private long requestID;

	private String REQUEST_ID_UI;

	private String clientName;

	private String clientTeamDetails;

	private String sourceVersion;
	
	private String targetVersion;

	private String unicodeCompliant;

	private String enableUnicode;

	private String sap_NonSAPcomponents;

	private String pocName;

	private String wbsCode;

	private String startDate;
	
	private String endDate;

	private String dealSize;

	private String industryGroup;

	private String dbSize;

	private String projectName;

	private String industrySubGroup;

	private String clienttype;

	private String systemId;

	private String systemType;

	private String customerNamespace;
	
	private String externalNamespace;

	private String SapClientId;

	private String databaseDB;

	private String host;

	private String instalNo;

	private String projectPocId;

	private String numberOfUsers;

	private String toolName;

	private String currencyType;

	private String supportedAtci;
	
	private ArrayList<String> scope;
	
	private Boolean SOH;
	
	private Boolean S4Technical;
	
	private Boolean S4Functional;
	
	private Boolean UI5;
	
	private Boolean Fiori;
	
	private Boolean UPGRADE;
	
	private Boolean RFP;
	
	private Boolean CVIT;
	
	private String WBSE;
	
	private String srcOSVer;
	
	private String tarOSVer;
	
	private boolean osMig;
	
	private String marketUnit;
	
	public boolean getOsMig() {
		return osMig;
	}

	public void setOsMig(boolean osMig) {
		this.osMig = osMig;
	}

	public String getSrcOSVer() {
		return srcOSVer;
	}

	public void setSrcOSVer(String srcOSVer) {
		this.srcOSVer = srcOSVer;
	}

	public String getTarOSVer() {
		return tarOSVer;
	}

	public void setTarOSVer(String tarOSVer) {
		this.tarOSVer = tarOSVer;
	}

	public String getWBSE() {
		return WBSE;
	}

	public void setWBSE(String wBSE) {
		WBSE = wBSE;
	}
	
	public Boolean getCVIT() {
		return CVIT;
	}

	public void setCVIT(Boolean cVIT) {
		CVIT = cVIT;
	}

	private String valueRFP;
	
	private String sandbox;
	
	private String numberDevelopment;
	
	private String numberQuality;
	
	private String numberProduction;
	
	private String numberOtherSystem;
	
	private String sapInterface;
	
	private String non_sapInterface;
	
	private String sapModules;
	
	private String indSolution;
	
	private String fioriSetup_apps;
	
	private String supportComponents;
	
	private String sandbox_ID_instalNo;
	
	private String rfc;
	
	private String appName;
	
	private String central_embedded;
	
	private String central_gateSystem;
	
	private String sandbox_sysId;
	
	private String oldVersion;
	
	private String newVersion;
	
	private String assignedPocEmailId;
	
	private String assignedFaitEmailId;
	
	private String systemEnvt;
	
	private Boolean sia;
	
	private MultipartFile fiatEWAFile;
	
	private MultipartFile fiatSizingRptFile;
	
	private MultipartFile fiatOtherFile;
	
	private String appServer;
	
	private Boolean EXT;
	
	private String licenseSelect;
	
	private String serviceProvider;
	
	private String fle_e;
	private String ale_e;
	public String getFle_e() {
		return fle_e;
	}

	public void setFle_e(String fle_e) {
		this.fle_e = fle_e;
	}

	public String getAle_e() {
		return ale_e;
	}

	public void setAle_e(String ale_e) {
		this.ale_e = ale_e;
	}

	public String getAppServer() {
		return appServer;
	}


	public void setAppServer(String appServer) {
		this.appServer = appServer;
	}
	
	public MultipartFile getFiatOtherFile() {
		return fiatOtherFile;
	}

	public void setFiatOtherFile(MultipartFile fiatOtherFile) {
		this.fiatOtherFile = fiatOtherFile;
	}

	private Integer ricefwCount;
	
	private Integer functionGroups;
	
	private Integer programs;
	
	private Integer classes;

	private Integer form;
	
	private Integer enhancements;
	
	private Integer webDynpro;
	
	private Integer lsmw;
	
	private Integer userExists;

	private Integer interfaces;
	
	private Integer workflow;
	
	public long getRequestID() {
		return requestID;
	}

	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}

	public String getSupportedAtci() {
		return supportedAtci;
	}

	public void setSupportedAtci(String supportedAtci) {
		this.supportedAtci = supportedAtci;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String string) {
		this.startDate = string;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getIndustrySubGroup() {
		return industrySubGroup;
	}

	public void setIndustrySubGroup(String industrySubGroup) {
		this.industrySubGroup = industrySubGroup;
	}

	public String getIndustryGroup() {
		return industryGroup;
	}

	public void setIndustryGroup(String industryGroup) {
		this.industryGroup = industryGroup;
	}
	
	public String getClienttype() {
		return clienttype;
	}

	public void setClienttype(String clienttype) {
		this.clienttype = clienttype;
	}

	public String getSystemId() {
		return systemId;
	}

	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}

	public String getSystemType() {
		return systemType;
	}

	public void setSystemType(String systemType) {
		this.systemType = systemType;
	}

	public String getCustomerNamespace() {
		return customerNamespace;
	}

	public void setCustomerNamespace(String customerNamespace) {
		this.customerNamespace = customerNamespace;
	}
	
	public String getExternalNamespace() {
		return externalNamespace;
	}

	public void setExternalNamespace(String externalNamespace) {
		this.externalNamespace = externalNamespace;
	}

	public String getSapClientId() {
		return SapClientId;
	}

	public void setSapClientId(String sapClientId) {
		SapClientId = sapClientId;
	}

	public String getInstalNo() {
		return instalNo;
	}

	public void setInstalNo(String instalNo) {
		this.instalNo = instalNo;
	}

	public String getDatabaseDB() {
		return databaseDB;
	}

	public void setDatabaseDB(String databaseDB) {
		this.databaseDB = databaseDB;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getProjectPocId() {
		return projectPocId;
	}

	public void setProjectPocId(String projectPocId) {
		this.projectPocId = projectPocId;
	}

	public String getClientTeamDetails() {
		return clientTeamDetails;
	}

	public void setClientTeamDetails(String clientTeamDetails) {
		this.clientTeamDetails = clientTeamDetails;
	}

	public String getSourceVersion() {
		return sourceVersion;
	}

	public void setSourceVersion(String sourceVersion) {
		this.sourceVersion = sourceVersion;
	}

	public String getTargetVersion() {
		return targetVersion;
	}

	public void setTargetVersion(String targetVersion) {
		this.targetVersion = targetVersion;
	}

	public String getUnicodeCompliant() {
		return unicodeCompliant;
	}

	public void setUnicodeCompliant(String unicodeCompliant) {
		this.unicodeCompliant = unicodeCompliant;
	}

	public String getEnableUnicode() {
		return enableUnicode;
	}

	public void setEnableUnicode(String enableUnicode) {
		this.enableUnicode = enableUnicode;
	}

	public String getSap_NonSAPcomponents() {
		return sap_NonSAPcomponents;
	}

	public void setSap_NonSAPcomponents(String sap_NonSAPcomponents) {
		this.sap_NonSAPcomponents = sap_NonSAPcomponents;
	}

	public String getPocName() {
		return pocName;
	}

	public void setPocName(String pocName) {
		this.pocName = pocName;
	}

	public String getWbsCode() {
		return wbsCode;
	}

	public void setWbsCode(String wbsCode) {
		this.wbsCode = wbsCode;
	}

	public String getDealSize() {
		return dealSize;
	}

	public void setDealSize(String dealSize) {
		this.dealSize = dealSize;
	}

	public String getDbSize() {
		return dbSize;
	}

	public void setDbSize(String dbSize) {
		this.dbSize = dbSize;
	}

	public String getNumberOfUsers() {
		return numberOfUsers;
	}

	public void setNumberOfUsers(String numberOfUsers) {
		this.numberOfUsers = numberOfUsers;
	}

	public RequestFormModel() {
	}

	public String getToolName() {
		return toolName;
	}

	public void setToolName(String toolName) {
		this.toolName = toolName;
	}

	public String getCurrencyType() {
		return currencyType;
	}

	public void setCurrencyType(String currencyType) {
		this.currencyType = currencyType;
	}

	public ArrayList<String> getScope() {
		return scope;
	}
	public void setScope(ArrayList<String> scope) {
		this.scope = scope;
	}

	public Boolean getSOH() {
		return SOH;
	}

	public void setSOH(Boolean sOH) {
		SOH = sOH;
	}

	public Boolean getS4Technical() {
		return S4Technical;
	}

	public void setS4Technical(Boolean s4Technical) {
		S4Technical = s4Technical;
	}

	public Boolean getS4Functional() {
		return S4Functional;
	}

	public void setS4Functional(Boolean s4Functional) {
		S4Functional = s4Functional;
	}

	public Boolean getUI5() {
		return UI5;
	}
	public void setUI5(Boolean uI5) {
		UI5 = uI5;
	}

	public Boolean getFiori() {
		return Fiori;
	}
	public void setFiori(Boolean fiori) {
		Fiori = fiori;
	}

	public Boolean getUPGRADE() {
		return UPGRADE;
	}

	public void setUPGRADE(Boolean uPGRADE) {
		UPGRADE = uPGRADE;
	}
	
	public String getREQUEST_ID_UI() {
		return REQUEST_ID_UI;
	}
	public void setREQUEST_ID_UI(String rEQUEST_ID_UI) {
		REQUEST_ID_UI = rEQUEST_ID_UI;
	}

	public String getSandbox() {
		return sandbox;
	}
	public void setSandbox(String sandbox) {
		this.sandbox = sandbox;
	}

	public String getNumberDevelopment() {
		return numberDevelopment;
	}
	public void setNumberDevelopment(String numberDevelopment) {
		this.numberDevelopment = numberDevelopment;
	}
	
	public String getNumberQuality() {
		return numberQuality;
	}
	public void setNumberQuality(String numberQuality) {
		this.numberQuality = numberQuality;
	}

	public String getNumberProduction() {
		return numberProduction;
	}
	public void setNumberProduction(String numberProduction) {
		this.numberProduction = numberProduction;
	}
	
	public String getNumberOtherSystem() {
		return numberOtherSystem;
	}
	public void setNumberOtherSystem(String numberOtherSystem) {
		this.numberOtherSystem = numberOtherSystem;
	}

	public String getSapInterface() {
		return sapInterface;
	}
	public void setSapInterface(String sapInterface) {
		this.sapInterface = sapInterface;
	}

	public String getNon_sapInterface() {
		return non_sapInterface;
	}
	public void setNon_sapInterface(String non_sapInterface) {
		this.non_sapInterface = non_sapInterface;
	}

	public String getSapModules() {
		return sapModules;
	}
	public void setSapModules(String sapModules) {
		this.sapModules = sapModules;
	}

	public String getIndSolution() {
		return indSolution;
	}
	public void setIndSolution(String indSolution) {
		this.indSolution = indSolution;
	}

	public String getFioriSetup_apps() {
		return fioriSetup_apps;
	}
	public void setFioriSetup_apps(String fioriSetup_apps) {
		this.fioriSetup_apps = fioriSetup_apps;
	}

	public String getSupportComponents() {
		return supportComponents;
	}
	public void setSupportComponents(String supportComponents) {
		this.supportComponents = supportComponents;
	}

	public String getSandbox_ID_instalNo() {
		return sandbox_ID_instalNo;
	}
	public void setSandbox_ID_instalNo(String sandbox_ID_instalNo) {
		this.sandbox_ID_instalNo = sandbox_ID_instalNo;
	}

	public String getRfc() {
		return rfc;
	}
	public void setRfc(String rfc) {
		this.rfc = rfc;
	}

	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getCentral_embedded() {
		return central_embedded;
	}
	public void setCentral_embedded(String central_embedded) {
		this.central_embedded = central_embedded;
	}

	public String getCentral_gateSystem() {
		return central_gateSystem;
	}
	public void setCentral_gateSystem(String central_gateSystem) {
		this.central_gateSystem = central_gateSystem;
	}

	public String getSandbox_sysId() {
		return sandbox_sysId;
	}

	public void setSandbox_sysId(String sandbox_sysId) {
		this.sandbox_sysId = sandbox_sysId;
	}
	
	public String getOldVersion() {
		return oldVersion;
	}
	public void setOldVersion(String oldVersion) {
		this.oldVersion = oldVersion;
	}

	public String getNewVersion() {
		return newVersion;
	}
	public void setNewVersion(String newVersion) {
		this.newVersion = newVersion;
	}
	
	public String getAssignedPocEmailId() {
		return assignedPocEmailId;
	}

	public void setAssignedPocEmailId(String assignedPocEmailId) {
		this.assignedPocEmailId = assignedPocEmailId;
	}

	public String getAssignedFaitEmailId() {
		return assignedFaitEmailId;
	}

	public void setAssignedFaitEmailId(String assignedFaitEmailId) {
		this.assignedFaitEmailId = assignedFaitEmailId;
	}

	public String getValueRFP() {
		return valueRFP;
	}

	public void setValueRFP(String valueRFP) {
		this.valueRFP = valueRFP;
	}

	public Boolean getRFP() {
		return RFP;
	}

	public void setRFP(Boolean rFP) {
		RFP = rFP;
	}	
	
	public String getSystemEnvt() {
		return systemEnvt;
	}

	public void setSystemEnvt(String systemEnvt) {
		this.systemEnvt = systemEnvt;
	}
	
	public Boolean getSia() {
		return sia;
	}

	public void setSia(Boolean sia) {
		this.sia = sia;
	}

	public MultipartFile getFiatEWAFile() {
		return fiatEWAFile;
	}

	public void setFiatEWAFile(MultipartFile fiatEWAFile) {
		this.fiatEWAFile = fiatEWAFile;
	}

	public MultipartFile getFiatSizingRptFile() {
		return fiatSizingRptFile;
	}

	public void setFiatSizingRptFile(MultipartFile fiatSizingRptFile) {
		this.fiatSizingRptFile = fiatSizingRptFile;
	}

	public Integer getRicefwCount() {
		return ricefwCount;
	}

	public void setRicefwCount(Integer ricefwCount) {
		this.ricefwCount = ricefwCount;
	}

	public Integer getFunctionGroups() {
		return functionGroups;
	}

	public void setFunctionGroups(Integer functionGroups) {
		this.functionGroups = functionGroups;
	}

	public Integer getPrograms() {
		return programs;
	}

	public void setPrograms(Integer programs) {
		this.programs = programs;
	}

	public Integer getClasses() {
		return classes;
	}

	public void setClasses(Integer classes) {
		this.classes = classes;
	}

	public Integer getForm() {
		return form;
	}

	public void setForm(Integer form) {
		this.form = form;
	}

	public Integer getEnhancements() {
		return enhancements;
	}

	public void setEnhancements(Integer enhancements) {
		this.enhancements = enhancements;
	}

	public Integer getWebDynpro() {
		return webDynpro;
	}

	public void setWebDynpro(Integer webDynpro) {
		this.webDynpro = webDynpro;
	}

	public Integer getLsmw() {
		return lsmw;
	}

	public void setLsmw(Integer lsmw) {
		this.lsmw = lsmw;
	}

	public Integer getUserExists() {
		return userExists;
	}

	public void setUserExists(Integer userExists) {
		this.userExists = userExists;
	}

	public Integer getInterfaces() {
		return interfaces;
	}

	public void setInterfaces(Integer interfaces) {
		this.interfaces = interfaces;
	}

	public Integer getWorkflow() {
		return workflow;
	}

	public void setWorkflow(Integer workflow) {
		this.workflow = workflow;
	}	
	private boolean bw_tech;
	
	

	public boolean isBw_tech() {
		return bw_tech;
	}

	public void setBw_tech(boolean bw_tech) {
		this.bw_tech = bw_tech;
	}

	private boolean bw_use;

	public boolean isBw_use() {
		return bw_use;
	}

	public void setBw_use(boolean bw_use) {
		this.bw_use = bw_use;
	}
	
	
	public String getLicenseSelect() {
		return licenseSelect;
	}

	public void setLicenseSelect(String licenseSelect) {
		this.licenseSelect = licenseSelect;
	}

	public String getServiceProvider() {
		return serviceProvider;
	}

	public void setServiceProvider(String serviceProvider) {
		this.serviceProvider = serviceProvider;
	}

	public Boolean getEXT() {
		return EXT;
	}

	public void setEXT(Boolean EXT) {
		this.EXT = EXT;
	}
	public String getMarketUnit() {
		return marketUnit;
	}

	public void setMarketUnit(String marketUnit) {
		this.marketUnit = marketUnit;
	}
}
