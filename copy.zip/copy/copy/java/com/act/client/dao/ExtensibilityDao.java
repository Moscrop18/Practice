package com.act.client.dao;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpSession;

import com.act.Aadt.models.ImpactedCloneAnalysis;
import com.act.client.model.RequestForm;
import com.act.fileprocessing.model.ComplexityGraphRules;
import com.act.fileprocessing.model.ExtensibilityGraphRules;
import com.act.fileprocessing.model.ExtensionFinder;
import com.act.fileprocessing.model.ExtensionOutput;
import com.act.fileprocessing.model.MetaData;

public interface ExtensibilityDao {

	public ExtensionFinder getMasterExtensionData(RequestForm requestForm);
	
	public List<ExtensionOutput> getExtensionOutput(Long requestId);
	
	public String ExtensionOutputBatchInsert(List<MetaData> metaDataList,String ricefFlag,
			HttpSession session) throws SQLException;

	public List<ComplexityGraphRules> getComplexityGraphRules();
	
	public List<ExtensibilityGraphRules> getExtensibilityGraphRules();
	
	public String impactedCloneBatchInsertUpdate(List<ImpactedCloneAnalysis> impactedCloneList,
			HttpSession session) throws SQLException;
	
	public List<ImpactedCloneAnalysis> getImpactedCloneList(Long REQUEST_ID) ;
	
}
