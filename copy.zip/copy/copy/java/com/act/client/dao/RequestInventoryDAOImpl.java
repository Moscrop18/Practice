/*CR-No.     Desc               Date          Modified By
 * 
 * CR-9.0:- Manual upload for Estimator & assuptions -17/01/17 -monika.mishra
*/

package com.act.client.dao;

import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
//import org.apache.log4j.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;

import com.act.S4.models.InventoryList_Download;
import com.act.S4.models.S4InventoryList;
import com.act.client.model.RequestForm;
import com.act.client.model.RequestInventory;
import com.act.constant.Hana_Profiler_Constant;
import com.act.displaygrid.model.DBConfig;
import com.act.exceptions.HibernateException;
import com.act.fileprocessing.model.CurrentExecution;
import com.act.fileprocessing.model.QueueExecution;

@Transactional
public class RequestInventoryDAOImpl implements RequestInventoryDAO {

	SessionFactory sessionFactory;
	RequestInventory status;

	final Logger logger = LoggerFactory.getLogger(RequestInventoryDAOImpl.class);

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public RequestInventory saveRequestInventory(long requestID, String requestStatus, String userName,
			final String toolName, String RequestIdUI) {
		try {
			logger.info("InRequestInverntory DAOIMPL class to save obj" + requestID);
			String requestShortdescription = null;

			Session session = sessionFactory.getCurrentSession();
			RequestForm obj = (RequestForm) session.get(RequestForm.class, requestID);
			RequestInventory status = new RequestInventory();

			final long currentTimeInMilliSec = new Date().getTime();
			status.setCreatorUser(userName);
			status.setUpdateUser(userName);

			status.setCreatedDate(currentTimeInMilliSec);
			status.setUpdatedDate(currentTimeInMilliSec);
			requestShortdescription = obj.getClientName() + "," + obj.getPocName() + "," + obj.getSourceVersion() + ","
					+ obj.getTargetVersion();
			status.setRequestShortdescription(requestShortdescription);
			status.setRequestStatus(requestStatus);
			status.setRequestForm(obj);
			status.setToolName(toolName);
			status.setREQUEST_ID_UI(RequestIdUI);
			status.setComments(Hana_Profiler_Constant.CREATE_REQ_SUCC);

			return status;
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	public RequestInventory setTrDownloadStatus(Long requestID, boolean trDownloadStatus) {
		Session session = sessionFactory.getCurrentSession();
		RequestInventory obj = (RequestInventory) session.get(RequestInventory.class, requestID);
		obj.setTrDownloadStatus(trDownloadStatus);

		session.saveOrUpdate(obj);
		return obj;
	}

	public RequestInventory setDelTrDownloadStatus(Long requestID, boolean trDownloadStatus) {
		Session session = sessionFactory.getCurrentSession();
		RequestInventory obj = (RequestInventory) session.get(RequestInventory.class, requestID);
		obj.setDeletiontrDownloadStatus(trDownloadStatus);

		session.saveOrUpdate(obj);
		return obj;
	}

	public RequestInventory setContentDownloadStatus(Long requestID, boolean contentDownloadStatus) {
		Session session = sessionFactory.getCurrentSession();
		RequestInventory obj = (RequestInventory) session.get(RequestInventory.class, requestID);
		obj.setContentDownloadStatus(contentDownloadStatus);

		session.saveOrUpdate(obj);
		return obj;
	}

	public boolean getTrDownloadStatus(Long requestID) {
		boolean value = false;
		Session session = null;
		try {
			session = sessionFactory.getCurrentSession();
			Query query = session.createQuery(
					"select trDownloadStatus from RequestInventory requestInventory where requestInventory.requestID=:requestID");
			query.setLong("requestID", requestID);
			Object obj = query.uniqueResult();
			if (obj != null) {
				value = (boolean) obj;
			}
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			logger.trace(ex.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		return value;
	}

	public boolean getDelTrDownloadStatus(Long requestID) {
		boolean value = false;
		Session session = null;
		try {
			session = sessionFactory.getCurrentSession();
			Query query = session.createQuery(
					"select deletiontrDownloadStatus from RequestInventory requestInventory where requestInventory.requestID=:requestID");
			query.setLong("requestID", requestID);
			Object obj = query.uniqueResult();
			if (obj != null) {
				value = (boolean) obj;
			}
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			logger.trace(ex.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		return value;
	}

	public boolean getContentDownloadStatus(Long requestID) {
		boolean value = false;
		Session session = null;
		try {
			session = sessionFactory.getCurrentSession();
			Query query = session.createQuery(
					"select contentDownloadStatus from RequestInventory requestInventory where requestInventory.requestID=:requestID");
			query.setLong("requestID", requestID);
			Object obj = query.uniqueResult();
			if (obj != null) {
				value = (boolean) obj;
			}
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			logger.trace(ex.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		return value;
	}

	public RequestInventory getRequestInventory(Long requestID) {
		try {
			Session session = sessionFactory.getCurrentSession();

			RequestInventory obj = (RequestInventory) session.get(RequestInventory.class, requestID);
			return obj;
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	public int getRequestCount(String creatorUser) {
		int count = 0;
		Session session = null;
		try {
			session = sessionFactory.getCurrentSession();
			// CR-9.0 Added 1 more status so adding that also in select Query
			Query query = session.createQuery(
					"select count(*) from RequestInventory requestInventory where requestInventory.creatorUser=:creatorUser AND requestInventory.requestStatus!=:requestStatus OR requestInventory.requestStatus!=:requestStatus1");
			query.setString("creatorUser", creatorUser);
			query.setString("requestStatus", "HANARefiningSuccess");
			query.setString("requestStatus1", "HANARefiningCompleted");
			count = ((Long) query.uniqueResult()).intValue();
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			logger.trace(ex.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		return count;
	}

	public long getCurrentExecution() {
		long requestId = 0;
		Session session = null;
		try {
			session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("select requestID from CurrentExecution currentExecution");
			Object obj = query.uniqueResult();
			if (obj != null) {
				requestId = (long) obj;
			}
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			logger.trace(ex.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		return requestId;
	}

	@Override
	public void saveQueueExecution(Long requestID, String clientName, String clientEmail, final String toolName) {
		logger.info("saveQueueExecution start :: ");
		try {

			Session session = sessionFactory.getCurrentSession();
			QueueExecution queueExecute = new QueueExecution();
			queueExecute.setRequestID(requestID);
			queueExecute.setName(clientName);
			if (clientEmail.contains("ds.dev.")) {
				clientEmail = clientEmail.replace("ds.dev.", "");
				logger.info("clientEmail :: " + clientEmail);
			}
			queueExecute.setEmailId(clientEmail);
			queueExecute.setToolName(toolName);
			queueExecute.setTimeStamp(new Timestamp(System.currentTimeMillis()));
			session.saveOrUpdate(queueExecute);

		} catch (Exception e) {
			logger.error("Error in saveQueueExecution :: ", e);
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		logger.info("saveQueueExecution End :: ");
	}

	@Override
	public void saveCurrentExecution(Long requestID, final String toolName) {
		try {

			Session session = sessionFactory.getCurrentSession();
			CurrentExecution currentExecute = new CurrentExecution();
			currentExecute.setRequestID(requestID);
			currentExecute.setToolName(toolName);
			session.saveOrUpdate(currentExecute);
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	// CR-24: Changes related to Generate Request Health Report tab
	public List<Long> requestIdListByUser(String userName) {
		List requestIdList = null;
		Session session = null;
		// This code is not used and hence it is not tested
		try {
			session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("select requestID from RequestInventory WHERE creatorUser= :userName"
					+ " AND requestStatus=:reqStatus1" + " OR requestStatus= :reqStatus2"
					+ " OR requestStatus= :reqStatus3 OR requestStatus= :reqStatus4 ");
			query.setParameter("userName", userName);
			query.setParameter("reqStatus1", Hana_Profiler_Constant.HANAREFININGSUCCESS_STATUS);
			query.setParameter("reqStatus2", Hana_Profiler_Constant.HANAREFININGCOMPLETED_STATUS);
			query.setParameter("reqStatus3", Hana_Profiler_Constant.COMPLETED_STATUS);
			query.setParameter("reqStatus4", Hana_Profiler_Constant.COMPLETED_PENDING_ESTIMATIONS);

			requestIdList = ((List<Long>) query.list());
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			logger.trace(ex.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		return requestIdList;
	}

	public RequestInventory saveRequestInventoryDataAssignPOC(long requestID) {
		try {
			Session session = sessionFactory.getCurrentSession();
			RequestInventory obj = (RequestInventory) session.get(RequestInventory.class, requestID);
			return obj;
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	public RequestInventory saveSubRequestInventory(RequestForm form, String requestStatus, String userName,
			final String toolName, String RequestIdUI, Long subRequestId, String reqIdUI) {
		try {
			logger.info("InRequestInverntory DAOIMPL class to save obj" + form.getRequestID());
			String requestShortdescription = null;

			Session session = sessionFactory.getCurrentSession();
			RequestForm obj = (RequestForm) session.get(RequestForm.class, form.getRequestID());
			RequestInventory status = new RequestInventory();

			final long currentTimeInMilliSec = new Date().getTime();
			status.setCreatorUser(userName);
			status.setUpdateUser(userName);

			status.setCreatedDate(currentTimeInMilliSec);
			status.setUpdatedDate(currentTimeInMilliSec);
			requestShortdescription = obj.getClientName() + "," + obj.getPocName() + "," + obj.getSourceVersion() + ","
					+ obj.getTargetVersion();
			status.setRequestShortdescription(requestShortdescription);
			status.setRequestStatus(requestStatus);
			status.setRequestForm(obj);
			status.setToolName(toolName);
			status.setREQUEST_ID_UI(RequestIdUI);
			status.setComments(Hana_Profiler_Constant.CREATE_SUBREQ_SUCC);
			status.setIsSubRequest(true);
			status.setMainRequestId(subRequestId);
			status.setMainRequestIdUI(reqIdUI);
			status.setTrDownloadStatus(true);
			status.setDeletiontrDownloadStatus(true);
			status.setContentDownloadStatus(true);
			status.setPreReqDownloadStatus(true);
			if (form.getS4Technical()) {
				status.setS4ValidationDownloadStatus(true);
			}
			return status;
		} catch (Exception e) {
			logger.error("Error in saveSubRequestInventory :: ", e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	// RequestIdList for last 3 months
	public List<RequestInventory> getRequestIdList(HttpSession session, String userName) throws Exception {
		List<RequestInventory> requestIdList = new ArrayList<>();
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		RequestInventory reqInv = null;
		
		try {
			String queryStr = "SELECT request_inventory.REQUEST_ID, request_inventory.REQUEST_ID_UI FROM "
					+ "request_inventory WHERE "
					+ "from_unixtime(request_inventory.CREATED_DATE DIV 1000, '%m-%d-%Y') < now() - interval 3 month "
					+ "AND request_inventory.IS_SUB_REQUEST = ? " 
					+ "AND request_inventory.CREATOR_USER = ?"
					+ "AND request_inventory.REQUEST_STATUS = ? "
					+ "AND request_inventory.REQUEST_STATUS <> ?";

			conn = DBConfig.getJDBCConnection(session);
			conn.setAutoCommit(false);
			stmt = conn.prepareStatement(queryStr);
			stmt.setBoolean(1, Boolean.FALSE);
			stmt.setString(2, userName);
			stmt.setString(3, "Approved");
			stmt.setString(4, "HANARefiningSuccess");
			
			ResultSet reqIdnUiRs = stmt.executeQuery();
			
			while (reqIdnUiRs.next()) {
				reqInv = new RequestInventory();
				reqInv.setREQUEST_ID_UI(reqIdnUiRs.getString("REQUEST_ID_UI"));
				reqInv.setRequestID(reqIdnUiRs.getLong("REQUEST_ID"));
				requestIdList.add(reqInv);
			}

			logger.info("3 month requestlist size :: " + requestIdList.size());
		} catch (Exception e) {
			logger.error("Error in getRequestIdList :: ", e);
			throw e;
		} finally {
			if (null != conn) {
				conn.close();
			}
			if (null != stmt) {
				stmt.close();
			}
		}
		return requestIdList;
	}

	public RequestInventory saveHistoricRequestInventory(long requestID, String requestStatus, String userName,
			final String toolName, String RequestIdUI) {
		try {
			logger.info("InR Historic equestInverntory DAOIMPL class to save obj" + requestID);
			String requestShortdescription = null;

			Session session = sessionFactory.getCurrentSession();
			RequestForm obj = (RequestForm) session.get(RequestForm.class, requestID);
			RequestInventory status = new RequestInventory();

			final long currentTimeInMilliSec = new Date().getTime();
			status.setCreatorUser(userName);
			status.setUpdateUser(userName);
			status.setAssigned_poc_emailId(userName);// Added for poc upload
														// validation of
														// historic request
			status.setCreatedDate(currentTimeInMilliSec);
			status.setUpdatedDate(currentTimeInMilliSec);
			requestShortdescription = obj.getClientName() + "," + obj.getPocName() + "," + obj.getSourceVersion() + ","
					+ obj.getTargetVersion();
			status.setRequestShortdescription(requestShortdescription);
			status.setRequestStatus(requestStatus);
			status.setRequestForm(obj);
			status.setToolName(toolName);
			status.setREQUEST_ID_UI(RequestIdUI);
			status.setComments(Hana_Profiler_Constant.CREATE_REQ_SUCC);

			return status;
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	public List<S4InventoryList> getInventory(long requestID) {
		Session session=sessionFactory.openSession();

		try{
			final Criteria criteria=session.createCriteria(S4InventoryList.class);
			criteria.add(Restrictions.eq("requestID", requestID));
			return criteria.list();
		}catch(Exception e){
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}finally{
			if(null != session)
				session.close();
		}

	}

}
