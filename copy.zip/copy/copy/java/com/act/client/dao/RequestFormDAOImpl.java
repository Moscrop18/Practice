package com.act.client.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.act.bw.model.BwObjectTypeDateFormat;
import com.act.client.model.RequestForm;
import com.act.client.model.RequestFormFile;
import com.act.client.model.RequestInventory;
import com.act.client.model.RequestStatusMaster;
import com.act.client.model.UploadFilesNumber;
import com.act.constant.Hana_Profiler_Constant;
import com.act.displaygrid.model.DBConfig;
import com.act.exceptions.HibernateException;
import com.act.rfp.models.TADIRInventory;

@Transactional
public class RequestFormDAOImpl implements RequestFormDAO {

	private HibernateTemplate hibernateTemplate;
	private SessionFactory sessionFactory;
	private RequestInventoryDAO statusDAO;

	final Logger logger = LoggerFactory.getLogger(RequestFormDAOImpl.class);

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

	public void setStatusDAO(RequestInventoryDAO statusDAO) {
		this.statusDAO = statusDAO;
	}

	public void saveRequestForm(RequestForm form, String userName, String toolName) {
		try {
			hibernateTemplate.saveOrUpdate(form);

			RequestInventory status = statusDAO.saveRequestInventory(form.getRequestID(), "Initiated", userName,
					toolName, form.getREQUEST_ID_UI());

			form.setRequestInventory(status);
			hibernateTemplate.saveOrUpdate(form);
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	public void saveTadirForm(TADIRInventory tadirInv) {
		try {
			hibernateTemplate.saveOrUpdate(tadirInv);
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	public void saveUploadFilesNumber(UploadFilesNumber uploadFileNumber) {
		try {
			hibernateTemplate.saveOrUpdate(uploadFileNumber);
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	@Transactional
	public void deleteRequestFormdata(Long requestID) {
		try {

			Session session = sessionFactory.getCurrentSession();

			logger.info("Deleting POCRequestMapping table data for this id" + requestID);
			String hql = "delete from POCRequestMapping where requestId=" + requestID;
			Query query = session.createQuery(hql);
			int count = query.executeUpdate();
			logger.info("deletd row's count:" + count);

			logger.info("Deleting RequestForm table data for this id" + requestID);
			String hql1 = "delete from RequestForm where requestID=" + requestID;
			Query query1 = session.createQuery(hql1);
			int count1 = query1.executeUpdate();
			logger.info("deletd row's count:" + count1);

			logger.info("Deleting RequestInventory table data for this id" + requestID);
			String hql2 = "delete from RequestInventory where requestID=" + requestID;
			Query query2 = session.createQuery(hql2);
			int count2 = query2.executeUpdate();
			logger.info("deletd row's count:" + count2);

			logger.info("Deleting RequestFormFile table data for this id" + requestID);
			String hql3 = "delete from RequestFormFile where requestID=" + requestID;
			Query query3 = session.createQuery(hql3);
			int count3 = query3.executeUpdate();
			logger.info("deletd row's count:" + count3);

		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	public void saveRequestFormFile(RequestFormFile requestFormFile) throws HibernateException {
		hibernateTemplate.save(requestFormFile);
	}

	/* CR-68: Function to update WBSE -7/05/2018 -himani.malhotra */
	public void updateWBSElement(String wbsCode, long requestId, String userName, String toolName) {
		try {

			logger.info(" Coming inside method to update WBSE SQL Query::::: ");
			Session session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("update RequestForm set wbsCode = :wbsCode where requestID = :requestId");
			query.setParameter("wbsCode", wbsCode);
			query.setParameter("requestId", requestId);
			query.executeUpdate();

			query = session
					.createQuery("update ProcessedRequestDetail set wbsCode = :wbsCode where requestID = :requestId");
			query.setParameter("wbsCode", wbsCode);
			query.setParameter("requestId", requestId);
			query.executeUpdate();

		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	public String ValidateRequestIDGenerator(String Criteria) {
		String requestIdUI = "Blank";
		Session session = null;
		try {
			session = sessionFactory.getCurrentSession();

			Query query = session
					.createQuery("select REQUEST_ID_UI,requestID from RequestForm where REQUEST_ID_UI LIKE :Criteria");
			query.setParameter("Criteria", Criteria + '%');

			int counterValue, MaxId = 0;
			List<Object[]> result = null;
			result = query.list();
			Iterator<Object[]> iterator = result.iterator();

			while (iterator.hasNext()) {
				Object[] temp = iterator.next();
				String ID = temp[0].toString();
				counterValue = Integer.parseInt(ID.substring(12, 14));
				if (counterValue >= MaxId) {
					MaxId = counterValue;
					requestIdUI = ID;
				}
			}
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			logger.trace(ex.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		return requestIdUI;
	}
	
	public String ValidateRequestIDGeneratorSubRequest(String Criteria) {
		String requestIdUI = "Blank";
		Session session = null;
		try {
			session = sessionFactory.getCurrentSession();

			Query query = session
					.createQuery("select REQUEST_ID_UI,requestID from RequestForm where REQUEST_ID_UI LIKE :Criteria");
			query.setParameter("Criteria", Criteria + '%');

			int counterValue, MaxId = 0;
			List<Object[]> result = null;
			result = query.list();
			Iterator<Object[]> iterator = result.iterator();

			while (iterator.hasNext()) {
				Object[] temp = iterator.next();
				String ID = temp[0].toString();
				counterValue = Integer.parseInt(ID.substring(15, 17));
				if (counterValue >= MaxId) {
					MaxId = counterValue;
					requestIdUI = ID;
				}
			}
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			logger.trace(ex.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		return requestIdUI;
	}

	public Long getRequestID(String requestIdUi) {
		long requestId = 0;
		Session session = null;
		try {
			session = sessionFactory.getCurrentSession();
			Query query = session
					.createQuery("select requestID from RequestForm where REQUEST_ID_UI in (:requestIdUi)");
			query.setParameter("requestIdUi", requestIdUi);

			Object obj = query.uniqueResult();
			if (obj != null) {
				requestId = (long) obj;
			}
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			logger.trace(ex.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		return requestId;
	}

	/* CR:43 Function to update the existing request -himani.malhotra */
	@Override
	public void updateRequestForm(RequestForm form, Long requestID, String userName, String toolName) {
		try {

			logger.info(" Coming::::: ");

			Session session = sessionFactory.getCurrentSession();
			String requestShortdescription = null;

			Query query = session.createQuery(
					"update RequestForm set scope = :scope, clientName = :clientName, clientTeamDetails = :clientTeamDetails, sourceVersion = :sourceVersion, targetVersion = :targetVersion,"
							+ "unicodeCompliant = :unicodeCompliant, enableUnicode = :enableUnicode, sap_NonSAPcomponents = :sap_NonSAPcomponents, pocName = :pocName,"
							+ "dealSize = :dealSize, industryGroup = :industryGroup, dbSize = :dbSize,"
							+ "projectName = :projectName, industrySubGroup = :industrySubGroup, clienttype = :clienttype,"
							+ "systemId = :systemId, systemType = :systemType, customerNamespace = :customerNamespace,"
							+ "SapClientId = :SapClientId, database = :database, host = :host, instalNo = :instalNo, projectPocId = :projectPocId, numberOfUsers = :numberOfUsers,"
							+ "currencyType = :currencyType, supportedAtci= :supportedAtci, appServer = :appServer where requestID = :requestId");

			query.setParameter("scope", form.getScope());
			query.setParameter("clientName", form.getClientName());
			query.setParameter("clientTeamDetails", form.getClientTeamDetails());
			query.setParameter("sourceVersion", form.getSourceVersion());
			query.setParameter("targetVersion", form.getTargetVersion());
			query.setParameter("unicodeCompliant", form.getUnicodeCompliant());
			if (form.getEnableUnicode() != null) {
				query.setParameter("enableUnicode", form.getEnableUnicode());
			} else {
				query.setParameter("enableUnicode", "");
			}
			query.setParameter("sap_NonSAPcomponents", form.getSap_NonSAPcomponents());
			query.setParameter("pocName", form.getPocName());
			query.setParameter("wbsCode", form.getWbsCode());
			query = session.createQuery(
					"update RequestInventory set startDate= :startDate, requestShortdescription= :requestShortDescription, updateUser= :updateUser where requestID= :requestId");
			query.setParameter("startDate", new Date().getTime());
			query.setParameter("dealSize", form.getDealSize());
			query.setParameter("industryGroup", form.getIndustryGroup());
			query.setParameter("dbSize", form.getDbSize());
			query.setParameter("projectName", form.getProjectName());
			query.setParameter("industrySubGroup", form.getIndustrySubGroup());
			query.setParameter("clienttype", form.getClienttype());
			query.setParameter("systemId", form.getSystemId());
			query.setParameter("systemType", form.getSystemType());
			query.setParameter("customerNamespace", form.getCustomerNamespace());
			query.setParameter("SapClientId", form.getSapClientId());
			query.setParameter("database", form.getDatabaseDB());
			query.setParameter("host", form.getHost());
			query.setParameter("instalNo", form.getInstalNo());
			query.setParameter("appServer", form.getAppServer());
			query.setParameter("projectPocId", form.getProjectPocId());
			query.setParameter("numberOfUsers", form.getNumberOfUsers());
			query.setParameter("toolName", form.getToolName());
			query.setParameter("currencyType", form.getCurrencyType());
			query.setParameter("supportedAtci", form.getSupportedAtci());
			query.setParameter("scope", form.getScope());
			query.setParameter("requestId", form.getRequestID());
			query.executeUpdate();

			requestShortdescription = form.getClientName() + "," + form.getPocName() + "," + form.getSourceVersion()
					+ "," + form.getTargetVersion();

			query.setParameter("updateUser", userName);
			query.setParameter("requestShortDescription", requestShortdescription);
			query.setParameter("requestId", form.getRequestID());
			query.executeUpdate();

			query = session.createQuery(
					"update RequestInventoryHistory set comments= :comments, requestStatus= :status, updatedDate= :updatedDate, requestShortdescription= :requestShortDescription, updatedUser= :updatedUser where requestID= :requestId");
			query.setParameter("comments", "Reinitiated");
			query.setParameter("status", Hana_Profiler_Constant.INITIATED_STATUS);
			query.setParameter("updatedDate", new Date().getTime());
			query.setParameter("updatedUser", userName);
			query.setParameter("requestShortDescription", requestShortdescription);
			query.setParameter("requestId", form.getRequestID());
			query.executeUpdate();

			RequestInventory obj = (RequestInventory) session.get(RequestInventory.class, requestID);
			session.update(obj);

		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	/*
	 * CR:43 Function to update request Inventory after updating the existing
	 * Request -himani.malhotra
	 */
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void updateSatus(Long requestID, String status, String userName, String comments, String toolName) {
		try {
			Session session = sessionFactory.getCurrentSession();
			RequestInventory obj = (RequestInventory) session.get(RequestInventory.class, requestID);

			obj.setRequestStatus(status);
			obj.setUpdatedDate(new Date().getTime());
			obj.setComments(comments);
			obj.setUpdateUser(userName);

			obj.setToolName(toolName);
			session.update(obj);
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	public RequestForm getRequestObj(Long requestID) {
		try {
			Session session = sessionFactory.getCurrentSession();
			RequestForm form = (RequestForm) session.get(RequestForm.class, requestID);

			return form;
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	public UploadFilesNumber getnumOfUploadFiles(Long requestID) {
		try {
			Session session = sessionFactory.getCurrentSession();
			UploadFilesNumber numUploadFiles = (UploadFilesNumber) session.get(UploadFilesNumber.class, requestID);

			return numUploadFiles;
		} catch (Exception e) {
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	@SuppressWarnings("unchecked")
	public List<Long> getRequestIdWithSpecifiedVersion(final String sourceVersion, final String targetVersion) {
		try {
			logger.info("inside searching request id with version name=" + sourceVersion);

			final Session session = sessionFactory.getCurrentSession();
			final Criteria criteria = session.createCriteria(RequestForm.class, "requestForm");

			criteria.createAlias("requestForm.requestInventory", "inventory", JoinType.INNER_JOIN);
			criteria.add(Restrictions.eq("inventory.comments", Hana_Profiler_Constant.TR_FILE_NOT_FOUND_COMMENTS));
			criteria.add(Restrictions.eq("requestForm.sourceVersion", sourceVersion));
			criteria.add(Restrictions.eq("requestForm.targetVersion", targetVersion));
			criteria.setProjection(Projections.property("requestForm.requestID"));
			return criteria.list();
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	@Override
	public void updateCvit(RequestForm requestForm) {
		try {
			String hql = "update RequestForm set cvit= :cvit where requestID = :requestId";
			Session session = sessionFactory.getCurrentSession();

			Query query = session.createQuery(hql);
			query.setParameter("cvit", requestForm.getCVIT());
			query.setParameter("requestId", requestForm.getRequestID());
			query.executeUpdate();

		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	@Override
	public void saveFileDateFormat(BwObjectTypeDateFormat bwDateFormat) {
		try {
			hibernateTemplate.saveOrUpdate(bwDateFormat);
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	@Override
	public void saveReqStatusMaster(RequestStatusMaster reqStatusMaster) throws Exception {
		Session session = null;
		Transaction tx = null;
		
		try {
			session = sessionFactory.openSession();
			tx = session.beginTransaction();
			
			session.merge("RequestStatusMaster", reqStatusMaster);
			tx.commit();
		} catch (Exception e) {
			if(tx != null)
				tx.rollback();
			
			logger.error("Error while saving the Request Status Master Data : ", e);
			throw new Exception();
		} finally {
			if(session != null)
				session.close();
		}
	}
	
	@Override
	public RequestStatusMaster getReqStatusMaster(long requestId) throws Exception {
		Session session = null;
		
		try {
			session = sessionFactory.openSession();
			
			RequestStatusMaster reqStatusObj = (RequestStatusMaster) session.get(RequestStatusMaster.class, requestId);
			
			return reqStatusObj;
		} catch (Exception e) {
			logger.error("Error while fetching the Request Status Master Data : ", e);
			
			throw new Exception();
		} finally {
			if(session != null)
				session.close();
		}
	}
	
	@Override
	public RequestForm getRequestFormData(Long requestID) {
		final Session session = sessionFactory.getCurrentSession();
		final Criteria criteria=session.createCriteria(RequestForm.class);
		criteria.add(Restrictions.eq("requestID", requestID));
		List<RequestForm> reqFormLst = criteria.list();
		RequestForm requestForm = reqFormLst.get(0);
		return requestForm;
	}
	
	public void saveSubRequestForm(RequestForm form, String userName, String toolName, Long SubRequestId, String reqIdUI) {
		try {
			hibernateTemplate.saveOrUpdate(form);
			
			RequestInventory status = statusDAO.saveSubRequestInventory(form, "Approved", userName, 
					toolName,form.getREQUEST_ID_UI(),SubRequestId,reqIdUI);

			form.setRequestInventory(status);
			hibernateTemplate.saveOrUpdate(form);
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	
	@Override
	public RequestForm getRequestFormScopes(Long requestID) {
		final Session session = sessionFactory.getCurrentSession();
		final Criteria criteria = session.createCriteria(RequestForm.class);
		
		ProjectionList projection = Projections.projectionList();
		
		projection.add(Projections.property("clientName"), "clientName");
		projection.add(Projections.property("SOH"), "SOH");
		projection.add(Projections.property("s4Technical"), "s4Technical");
		projection.add(Projections.property("s4Functional"), "s4Functional");
		projection.add(Projections.property("UI5"), "UI5");
		projection.add(Projections.property("fiori"), "fiori");
		projection.add(Projections.property("UPGRADE"), "UPGRADE");
		projection.add(Projections.property("RFP"), "RFP");
		projection.add(Projections.property("EXT"), "EXT");
		projection.add(Projections.property("sia"), "sia");
		projection.add(Projections.property("osMig"), "osMig");
		projection.add(Projections.property("bwUsage"), "bwUsage");
		projection.add(Projections.property("bwTech"), "bwTech");
		projection.add(Projections.property("grc"), "grc");
		projection.add(Projections.property("CVIT"), "CVIT");
		
		criteria.add(Restrictions.eq("requestID", requestID));
		criteria.setProjection(Projections.distinct(projection));
		criteria.setResultTransformer(Transformers.aliasToBean(RequestForm.class));
		
		return (RequestForm) criteria.uniqueResult();	
	}
	
	@Override
	public List<RequestForm> getSubRequestScopes(Long requestID, HttpSession session) throws Exception {
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		RequestForm reqFrm = null;
		List<RequestForm> reqFrmlist = new ArrayList<>();
		try {
			String queryStr = "select SOH,S4Technical,S4Functional,UPGRADE,UI5,EXT,"
					+ "security_Analyser,Fiori,RFP,osMig, BW_Tech, BW_Usage from request_form where "
					+ "REQUEST_ID in (select REQUEST_ID from  request_inventory "
					+ "where MAIN_REQUEST_ID="+requestID+")";
			conn = DBConfig.getJDBCConnection(session);
			conn.setAutoCommit(false);
			stmt = conn.prepareStatement(queryStr);
			ResultSet rRs = stmt.executeQuery();
			while(rRs.next()) {
				reqFrm = new RequestForm();
				reqFrm.setSOH(rRs.getBoolean("SOH"));
				reqFrm.setS4Technical(rRs.getBoolean("S4Technical"));
				reqFrm.setS4Functional(rRs.getBoolean("S4Functional"));
				reqFrm.setUPGRADE(rRs.getBoolean("UPGRADE"));
				reqFrm.setUI5(rRs.getBoolean("UI5"));
				reqFrm.setEXT(rRs.getBoolean("EXT"));
				reqFrm.setSia(rRs.getBoolean("security_Analyser"));
				reqFrm.setFiori(rRs.getBoolean("Fiori"));
				reqFrm.setRFP(rRs.getBoolean("RFP"));
				reqFrm.setOsMig(rRs.getBoolean("osMig"));
				reqFrm.setBwTech(rRs.getBoolean("BW_Tech"));
				reqFrm.setBwUsage(rRs.getBoolean("BW_Usage"));
				reqFrmlist.add(reqFrm);
			}
		}catch (Exception e) {
			logger.error("Error in getSubRequestScopes :: ",e);
			throw e;
		}finally {
			if(null != conn) {
				conn.close();
			}
			if(null != stmt) {
				stmt.close();
			}
		}
		return reqFrmlist;
	}
	
	public void saveHistoricRequestForm(RequestForm form, String userName, String toolName) {
		try {
			hibernateTemplate.saveOrUpdate(form);
			
			RequestInventory status = statusDAO.saveHistoricRequestInventory(form.getRequestID(), "Initiated", userName, 
					toolName,form.getREQUEST_ID_UI());

			form.setRequestInventory(status);
			hibernateTemplate.saveOrUpdate(form);
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
}
