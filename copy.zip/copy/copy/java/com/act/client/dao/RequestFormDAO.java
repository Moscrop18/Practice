package com.act.client.dao;

import java.util.List;

import javax.servlet.http.HttpSession;

import com.act.bw.model.BwObjectTypeDateFormat;
import com.act.client.model.RequestForm;
import com.act.client.model.RequestFormFile;
import com.act.client.model.RequestStatusMaster;
import com.act.client.model.UploadFilesNumber;
import com.act.exceptions.HibernateException;
import com.act.rfp.models.TADIRInventory;

public interface RequestFormDAO {

	public void saveRequestForm(RequestForm form, String userName, final String toolName);

	public void saveRequestFormFile(RequestFormFile requestFormFile);

	public void deleteRequestFormdata(Long requestID);

	public RequestForm getRequestObj(Long requestID);

	List<Long> getRequestIdWithSpecifiedVersion(final String sourceVersion, final String targetVersion);

	void updateRequestForm(RequestForm form, Long requestID, String userName, String toolName);

	public void updateWBSElement(String wbsCode, long requestId, String userName, String toolName);

	public Long getRequestID(String requestIdUi);

	public String ValidateRequestIDGenerator(String rID_UI);

	public void saveTadirForm(TADIRInventory tadirInv);

	public void updateCvit(RequestForm requestform);

	public UploadFilesNumber getnumOfUploadFiles(Long requestID);

	public void saveUploadFilesNumber(UploadFilesNumber uploadFileNumber);

	public void saveFileDateFormat(BwObjectTypeDateFormat bwDateFormat);
	
	public void saveReqStatusMaster(RequestStatusMaster reqStatusMaster) throws Exception;
	
	public RequestStatusMaster getReqStatusMaster(long requestId) throws Exception;
	
	public RequestForm getRequestFormData(Long requestID);
	
	public void saveSubRequestForm(RequestForm form, String userName, final String toolName, Long subrequestId, String mainReqUid) ;
	
	public RequestForm getRequestFormScopes(Long requestID);
	
	public List<RequestForm> getSubRequestScopes(Long requestID, HttpSession session) throws Exception;
	
	public String ValidateRequestIDGeneratorSubRequest(String rID_UI);
	
	public void saveHistoricRequestForm(RequestForm form, String userName, final String toolName) ;
}
