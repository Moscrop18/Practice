package com.act.client.dao;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpSession;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.act.Aadt.models.ImpactedCloneAnalysis;
import com.act.client.model.RequestForm;
import com.act.constant.Hana_Profiler_Constant;
import com.act.constant.ST03HanaConstant;
import com.act.displaygrid.model.DBConfig;
import com.act.exceptions.HibernateException;
import com.act.fileprocessing.model.ComplexityGraphRules;
import com.act.fileprocessing.model.ExtensibilityGraphRules;
import com.act.fileprocessing.model.ExtensionFinder;
import com.act.fileprocessing.model.ExtensionOutput;
import com.act.fileprocessing.model.MetaData;

@Repository
public class ExtensibilityDaoImpl implements ExtensibilityDao {

	final Logger logger = LoggerFactory.getLogger(ExtensibilityDaoImpl.class);

	public SessionFactory sessionFactory;

	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	@Override
	public ExtensionFinder getMasterExtensionData(RequestForm requestForm) {
		ExtensionFinder extensionFinder = null;
		Session session = sessionFactory.openSession();
		try {
		Criteria criteria = session.createCriteria(ExtensionFinder.class);
		criteria.add(Restrictions.eq("targetSystem",requestForm.getTargetVersion()));
		Object result = criteria.uniqueResult();
		if(result!=null) {
			extensionFinder = (ExtensionFinder) result;
		}
		return extensionFinder;
	}
	catch (Exception e) {
		logger.error(e.getMessage());
		logger.trace(e.getMessage());
		throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
	} finally {
		if (session != null) {
			session.close();
		}
	}
	}
	
	public List<ExtensionOutput> getExtensionOutput(Long requestId) {
		Session session = sessionFactory.openSession();
		try {
		Criteria criteria = session.createCriteria(ExtensionOutput.class);
		criteria.add(Restrictions.eq("requestId",requestId));
		
		return criteria.list();
	}
	catch (Exception e) {
		logger.error(e.getMessage());
		logger.trace(e.getMessage());
		throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
	} finally {
		if (session != null) {
			session.close();
		}
	}
	}
	
	public String ExtensionOutputBatchInsert(List<MetaData> metaDataList, String ricefFlag,
			HttpSession session) throws SQLException {
		final String INSERT_SQL = "INSERT INTO EXTENSION_OUTPUT"
				+ "(OBJECT, OBJECT_NAME, RICEF_CATEGORY, RICEF_SUB_CATEGORY, RICEF_CATEGORY_2, RICEF_CATEGORY_3,  "
				+ "COMPLEXITY,EXTENSIBILITY,USAGE_VALUE, USAGE_COUNT, COMMENTS,REQUEST_ID, LOOSE_COUPLING,RICEFW_COMMENTS,PACKAGE_NAME, PACKAGE_DESC,"
				+ "APP_AREA,APP_AREA_DESC,CLONE_OBJ,OBJECT_DESC,COMMENTED_LINES,EXE_LINES) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?,?,?,?,?,?,?,?,?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (MetaData metaData : metaDataList) {
					stmt.setString(1, metaData.getObj());
					stmt.setString(2, metaData.getObjName());
					stmt.setString(3, metaData.getRicefCategory());
					stmt.setString(4, metaData.getRicefSubCategory());
					stmt.setString(5, metaData.getRicefCategory2());
					stmt.setString(6, metaData.getRicefCategory3());
					stmt.setString(7, metaData.getComplexity());
					stmt.setString(8, metaData.getExtensibility());
					stmt.setString(9, metaData.getUsage());
					stmt.setString(10, metaData.getUsageCount()==null?"":metaData.getUsageCount().toString());
					stmt.setString(11, metaData.getComments());
					stmt.setLong(12, metaData.getRequestId());
					if(metaData.getExtensibility()!=null && (metaData.getExtensibility().equals(ST03HanaConstant.SIDE_BY_SIDE)
							||metaData.getExtensibility().equals(ST03HanaConstant.IN_APP))) {
						stmt.setString(13, "X");
					}else {
						stmt.setString(13, "");
					}
					if(ricefFlag!=null && ricefFlag.equalsIgnoreCase(ST03HanaConstant.RICEFW)) {
						stmt.setString(14, "");
						stmt.setString(15, "");
						stmt.setString(16, "");
						stmt.setString(17, "");
						stmt.setString(18, "");
					}else {
						stmt.setString(14, metaData.getRicefComments());
						stmt.setString(15, metaData.getObjPackage());
						stmt.setString(16, metaData.getPackageDesc());
						stmt.setString(17, metaData.getAppArea());
						stmt.setString(18, metaData.getAppAreaDesc());
					}
					stmt.setString(19, metaData.getCloneObj());
					stmt.setString(20, metaData.getObjDesc());
					stmt.setString(21, metaData.getCommentedLines());
					stmt.setString(22, metaData.getExeLines());
					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("EXTENSION_OUTPUT INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;
	}
	
	public List<ComplexityGraphRules> getComplexityGraphRules() {
		Session session = sessionFactory.openSession();
		try {
		Criteria criteria = session.createCriteria(ComplexityGraphRules.class);
		
		return criteria.list();
	}
	catch (Exception e) {
		logger.error(e.getMessage());
		logger.trace(e.getMessage());
		throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
	} finally {
		if (session != null) {
			session.close();
		}
	}
	}
	
	public List<ExtensibilityGraphRules> getExtensibilityGraphRules() {
		Session session = sessionFactory.openSession();
		try {
		Criteria criteria = session.createCriteria(ExtensibilityGraphRules.class);
		
		return criteria.list();
	}
	catch (Exception e) {
		logger.error(e.getMessage());
		logger.trace(e.getMessage());
		throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
	} finally {
		if (session != null) {
			session.close();
		}
	}
	}
	
	public String impactedCloneBatchInsertUpdate(List<ImpactedCloneAnalysis> impactedCloneList,
			HttpSession session) throws SQLException {

		final String INSERT_SQL = "INSERT INTO IMPACTED_CLONE_ANALYSIS "
				+ "(APPLICATION_COMPONENT, CREATION_DATE, INTERFACE, INTERFACE_OBJECT_TYPE, NAMESPACE, OBJECT_NAME, PACKAGE, OBJECT_TYPE,  REFERENCE, REFERENCE_PERCENT, REQUEST_ID) "
				+ "values ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (ImpactedCloneAnalysis impactedClone : impactedCloneList) {
					stmt.setString(1, impactedClone.getAppComponent());
					stmt.setString(2, impactedClone.getCreationDate());
					stmt.setString(3, impactedClone.getInterfaceObj());
					stmt.setString(4, impactedClone.getInterfaceObjType());
					stmt.setString(5, impactedClone.getNamespace());
					stmt.setString(6, impactedClone.getObjName());
					stmt.setString(7, impactedClone.getObjPackage());
					stmt.setString(8, impactedClone.getObjType());
					stmt.setString(9, impactedClone.getReference());
					stmt.setString(10, impactedClone.getReferencePercent());
					stmt.setLong(11, impactedClone.getRequestID());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("IMPACTED_CLONE_ANALYSIS Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}
	
	public List<ImpactedCloneAnalysis> getImpactedCloneList(Long REQUEST_ID) {
		logger.info("in getImpactedCloneList method of extensibility");
		Session session = sessionFactory.openSession();
	
		Criteria criteria = session.createCriteria(ImpactedCloneAnalysis.class);
		ProjectionList projection = Projections.projectionList();
		projection.add(Projections.property("namespace"), "namespace");
		projection.add(Projections.property("objType"), "objType");
		projection.add(Projections.property("objName"), "objName");
		projection.add(Projections.property("objPackage"), "objPackage");
		projection.add(Projections.property("creationDate"), "creationDate");
		projection.add(Projections.property("interfaceObjType"), "interfaceObjType");
		projection.add(Projections.property("interfaceObj"), "interfaceObj");
		projection.add(Projections.property("reference"), "reference");
		projection.add(Projections.property("referencePercent"), "referencePercent");
		projection.add(Projections.property("appComponent"), "appComponent");
		
		
		criteria.add(Restrictions.eq("requestID", REQUEST_ID));
		List<ImpactedCloneAnalysis> l = criteria.list();
		session.close();
		return l;
	}

	
}
