package com.act.client.dao;

import java.util.List;

import javax.servlet.http.HttpSession;

import com.act.S4.models.InventoryList_Download;
import com.act.S4.models.S4InventoryList;
import com.act.client.model.RequestForm;
import com.act.client.model.RequestInventory;

public interface RequestInventoryDAO {

	public RequestInventory saveRequestInventory(long requestID, String requestStatus, String userName,
			final String toolName, String RequestIdUI);

	public RequestInventory setTrDownloadStatus(Long requestID, boolean trDownloadStatus);

	public boolean getTrDownloadStatus(Long requestID);

	RequestInventory getRequestInventory(Long requestID);

	public int getRequestCount(String userName);

	public long getCurrentExecution();

	// CR-24: Changes related to Generate Request Health Report tab
	List<Long> requestIdListByUser(String userName);

	// public int getCurrentExecution();
	public void saveQueueExecution(Long requestID, String clientName, String clientEmail, final String toolName);

	public void saveCurrentExecution(Long requestID, final String toolName);

	// Mine
	public RequestInventory setContentDownloadStatus(Long requestID, boolean contentDownloadStatus);

	public boolean getContentDownloadStatus(Long requestID);

	// Fetching data from table for assignedPOC
	public RequestInventory saveRequestInventoryDataAssignPOC(long requestID);
	 
	public boolean getDelTrDownloadStatus(Long requestID);
	
	public RequestInventory setDelTrDownloadStatus(Long requestID, boolean trDownloadStatus);
	
	public RequestInventory saveSubRequestInventory(RequestForm requestID, String requestStatus, String userName,
			final String toolName, String RequestIdUI, Long SubRequestId, String mainReqUID);
	
	public List<RequestInventory> getRequestIdList(HttpSession session, String userName) throws Exception;
	
	public RequestInventory saveHistoricRequestInventory(long requestID, String requestStatus, String userName,
			final String toolName, String RequestIdUI);

	public List<S4InventoryList> getInventory(long requestId);
} 
