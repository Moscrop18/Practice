package com.act.client.service;

import java.util.List;

import com.act.client.model.RequestForm;
import com.act.fileprocessing.model.ComplexityGraphRules;
import com.act.fileprocessing.model.ExtensibilityGraphRules;
import com.act.fileprocessing.model.MetaData;
import com.act.master.ExtensionScope;
import com.act.model.DRL.CodeAssessmentPayLoad;

public interface ExtensionService {
	
	public List<MetaData> findRicefCategory(CodeAssessmentPayLoad cPL, ExtensionScope extensionScope);
	
	public List<MetaData> calculateComplexity(CodeAssessmentPayLoad cPL, List<MetaData> metaDataListWithCategory, ExtensionScope extensionScope) ;
	
	public List<MetaData> findExtRecommendation(RequestForm requestForm, CodeAssessmentPayLoad cPL,List<MetaData> metaDataList, ExtensionScope extensionScope);

	public List<ComplexityGraphRules> getComplexityGraphRules();
	
	public List<ExtensibilityGraphRules> getExtensibilityGraphRules();
	
	public void setRicefComments(List<MetaData> metaDataList);
}
