package com.act.client.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.act.S4.dao.PopulatingS4FinalOutputInterface;
import com.act.S4.models.S4CvitAssessment;

@Service
public class S4ProcessingServiceImpl implements S4ProcessingService{

	@Autowired
	private PopulatingS4FinalOutputInterface s4ProcessingDao;
	
	@Override
	public List<S4CvitAssessment> getS4CvitAssessment(long requestId) {
		return s4ProcessingDao.getS4CvitAssessmentData(requestId);
	}

	@Override
	public Map<Integer, String> getS4CvitAssessmentMap(List<S4CvitAssessment> s4CvitList) {
		Map<Integer, String> s4CvitAssessmentMap = new HashMap<Integer, String>();
		for(S4CvitAssessment s4CvitAssessment:s4CvitList) {
			s4CvitAssessmentMap.put(Integer.valueOf(s4CvitAssessment.getObjName()), s4CvitAssessment.getCvitValue());
		}
		return s4CvitAssessmentMap;
		
	}
	
}
