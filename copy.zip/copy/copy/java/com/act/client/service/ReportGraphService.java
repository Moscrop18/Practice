/*
 * @author himani.malhotra -15/04/2019
*/
package com.act.client.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.act.S4.dao.DisplayGraphS4DAOImpl;
import com.act.UI5.models.UI5GraphCounts;
import com.act.impactedBackgroundJob.ImpactedBackgroundCounts;
import com.act.master.FioriRequestMaster;
import com.act.master.ProcessedRequestDetail;
import com.act.master.TestingScope;

@Service
public class ReportGraphService extends ProcessedRequestDetail {
	
	final public Logger logger = LoggerFactory.getLogger(DisplayGraphS4DAOImpl.class);

	// Slide 6-Hana && Slide 16-S4
	public LinkedHashMap<String, List<Integer>> getImpactedVSUsedObjects(long requestId,
			ProcessedRequestDetail reqMaster) {
		final LinkedHashMap<String, List<Integer>> resultMap = new LinkedHashMap<String, List<Integer>>();

		// Impacted v/s Used Class Counts both Hana & S4---
		List<Integer> listTotal_Hana = new ArrayList<Integer>();
		List<Integer> listTotal_S4 = new ArrayList<Integer>();
		
		List<Integer> listLsmw_Hana = new ArrayList<Integer>();
		List<Integer> listLsmw_S4 = new ArrayList<Integer>();
		
		List<Integer> listClass_Hana = new ArrayList<Integer>();
		List<Integer> listClass_S4 = new ArrayList<Integer>();

		List<Integer> listProg_Hana = new ArrayList<Integer>();
		List<Integer> listProg_S4 = new ArrayList<Integer>();

		List<Integer> listFUGR_Hana = new ArrayList<Integer>();
		List<Integer> listFUGR_S4 = new ArrayList<Integer>();

		List<Integer> listENH_Hana = new ArrayList<Integer>();
		List<Integer> listENH_S4 = new ArrayList<Integer>();

		List<Integer> listFORM_Hana = new ArrayList<Integer>();
		List<Integer> listFORM_S4 = new ArrayList<Integer>();

		List<Integer> listWDYN_Hana = new ArrayList<Integer>();
		List<Integer> listWDYN_S4 = new ArrayList<Integer>();

		List<Integer> listREPT_Hana = new ArrayList<Integer>();
		List<Integer> listREPT_S4 = new ArrayList<Integer>();

		List<Integer> listVIEW_Hana = new ArrayList<Integer>();
		List<Integer> listVIEW_S4 = new ArrayList<Integer>();

		List<Integer> listINDE_Hana = new ArrayList<Integer>();
		List<Integer> listINDE_S4 = new ArrayList<Integer>();
		
		List<Integer> listDTEL_Hana = new ArrayList<Integer>();
		List<Integer> listDTEL_S4 = new ArrayList<Integer>();

		List<Integer> listUSRE_Hana = new ArrayList<Integer>();
		List<Integer> listUSRE_S4 = new ArrayList<Integer>();

		List<Integer> listUSRR_Hana = new ArrayList<Integer>();
		List<Integer> listUSRR_S4 = new ArrayList<Integer>();

		List<Integer> listFUGS_Hana = new ArrayList<Integer>();
		List<Integer> listFUGS_S4 = new ArrayList<Integer>();

		List<Integer> listBWTR_Hana = new ArrayList<Integer>();
		List<Integer> listBWTR_S4 = new ArrayList<Integer>();
		
		List<Integer> listBWTS_Hana = new ArrayList<Integer>();
		List<Integer> listBWTS_S4 = new ArrayList<Integer>();
		
		List<Integer> listBWUR_Hana = new ArrayList<Integer>();
		List<Integer> listBWUR_S4 = new ArrayList<Integer>();
		
		List<Integer> listBWIG_Hana = new ArrayList<Integer>();
		List<Integer> listBWIG_S4 = new ArrayList<Integer>();

		String scope = reqMaster.getScope();
		if (scope.equalsIgnoreCase("Hana")) {
			
			if ((reqMaster.getCustClasCount() != null && reqMaster.getCustClasCount() != 0)
					|| (reqMaster.getCustUsedClasCount() != null && reqMaster.getCustUsedClasCount() != 0)
					|| (reqMaster.getDefectClasCount() != null && reqMaster.getDefectClasCount() != 0)
					|| (reqMaster.getDefectUsedClasCount() != null && reqMaster.getDefectUsedClasCount() != 0)) {
				listClass_Hana.add(reqMaster.getCustClasCount());
				listClass_Hana.add(reqMaster.getCustUsedClasCount());
				listClass_Hana.add(reqMaster.getDefectClasCount());
				listClass_Hana.add(reqMaster.getDefectUsedClasCount());
				resultMap.put("CLAS", listClass_Hana);
			}
			
			if ((reqMaster.getCust_BWTRCount() != null && reqMaster.getCust_BWTRCount() != 0)
					|| (reqMaster.getCustUsed_BWTRCount() != null && reqMaster.getCustUsed_BWTRCount() != 0)
					|| (reqMaster.getDefect_BWTRCount() != null && reqMaster.getDefect_BWTRCount() != 0)
					|| (reqMaster.getDefectUsed_BWTRCount() != null && reqMaster.getDefectUsed_BWTRCount() != 0)) {
				listBWTR_Hana.add(reqMaster.getCust_BWTRCount());
				listBWTR_Hana.add(reqMaster.getCustUsed_BWTRCount());
				listBWTR_Hana.add(reqMaster.getDefect_BWTRCount());
				listBWTR_Hana.add(reqMaster.getDefectUsed_BWTRCount());
				resultMap.put("BWTR", listBWTR_Hana);
			}
			
			if ((reqMaster.getCust_BWTSCount() != null && reqMaster.getCust_BWTSCount() != 0)
					|| (reqMaster.getCustUsed_BWTSCount() != null && reqMaster.getCustUsed_BWTSCount() != 0)
					|| (reqMaster.getDefect_BWTSCount() != null && reqMaster.getDefect_BWTSCount() != 0)
					|| (reqMaster.getDefectUsed_BWTSCount() != null && reqMaster.getDefectUsed_BWTSCount() != 0)) {
				listBWTS_Hana.add(reqMaster.getCust_BWTSCount());
				listBWTS_Hana.add(reqMaster.getCustUsed_BWTSCount());
				listBWTS_Hana.add(reqMaster.getDefect_BWTSCount());
				listBWTS_Hana.add(reqMaster.getDefectUsed_BWTSCount());
				resultMap.put("BWTS", listBWTS_Hana);
			}
			
			if ((reqMaster.getCust_BWURCount() != null && reqMaster.getCust_BWURCount() != 0)
					|| (reqMaster.getCustUsed_BWURCount() != null && reqMaster.getCustUsed_BWURCount() != 0)
					|| (reqMaster.getDefect_BWURCount() != null && reqMaster.getDefect_BWURCount() != 0)
					|| (reqMaster.getDefectUsed_BWURCount() != null && reqMaster.getDefectUsed_BWURCount() != 0)) {
				listBWUR_Hana.add(reqMaster.getCust_BWURCount());
				listBWUR_Hana.add(reqMaster.getCustUsed_BWURCount());
				listBWUR_Hana.add(reqMaster.getDefect_BWURCount());
				listBWUR_Hana.add(reqMaster.getDefectUsed_BWURCount());
				resultMap.put("BWUR", listBWUR_Hana);
			}
			
			if ((reqMaster.getCust_BWIGCount() != null && reqMaster.getCust_BWIGCount() != 0)
					|| (reqMaster.getCustUsed_BWIGCount() != null && reqMaster.getCustUsed_BWIGCount() != 0)
					|| (reqMaster.getDefect_BWIGCount() != null && reqMaster.getDefect_BWIGCount() != 0)
					|| (reqMaster.getDefectUsed_BWIGCount() != null && reqMaster.getDefectUsed_BWIGCount() != 0)) {
				listBWIG_Hana.add(reqMaster.getCust_BWIGCount());
				listBWIG_Hana.add(reqMaster.getCustUsed_BWIGCount());
				listBWIG_Hana.add(reqMaster.getDefect_BWIGCount());
				listBWIG_Hana.add(reqMaster.getDefectUsed_BWIGCount());
				resultMap.put("BWIG", listBWIG_Hana);
			}

			if ((reqMaster.getCustProgCount() != null && reqMaster.getCustProgCount() != 0)
					|| (reqMaster.getCustUsedProgCount() != null && reqMaster.getCustUsedProgCount() != 0)
					|| (reqMaster.getDefectProgCount() != null && reqMaster.getDefectProgCount() != 0)
					|| (reqMaster.getDefectUsedProgCount() != null && reqMaster.getDefectUsedProgCount() != 0)) {
				listProg_Hana.add(reqMaster.getCustProgCount());
				listProg_Hana.add(reqMaster.getCustUsedProgCount());
				listProg_Hana.add(reqMaster.getDefectProgCount());
				listProg_Hana.add(reqMaster.getDefectUsedProgCount());
				resultMap.put("PROG", listProg_Hana);
			}

			if ((reqMaster.getCustFugrCount() != null && reqMaster.getCustFugrCount() != 0)
					|| (reqMaster.getCustUsedFugrCount() != null && reqMaster.getCustUsedFugrCount() != 0)
					|| (reqMaster.getDefectFugrCount() != null && reqMaster.getDefectFugrCount() != 0)
					|| (reqMaster.getDefectUsedFugrCount() != null && reqMaster.getDefectUsedFugrCount() != 0)) {
				listFUGR_Hana.add(reqMaster.getCustFugrCount());
				listFUGR_Hana.add(reqMaster.getCustUsedFugrCount());
				listFUGR_Hana.add(reqMaster.getDefectFugrCount());
				listFUGR_Hana.add(reqMaster.getDefectUsedFugrCount());
				resultMap.put("FUGR", listFUGR_Hana);
			}

			if ((reqMaster.getCustEnhanCount() != null && reqMaster.getCustEnhanCount() != 0)
					|| (reqMaster.getCustUsedEnhanCount() != null && reqMaster.getCustUsedEnhanCount() != 0)
					|| (reqMaster.getDefectEnhanCount() != null && reqMaster.getDefectEnhanCount() != 0)
					|| (reqMaster.getDefectUsedEnhanCount() != null && reqMaster.getDefectUsedEnhanCount() != 0)) {
				listENH_Hana.add(reqMaster.getCustEnhanCount());
				listENH_Hana.add(reqMaster.getCustUsedEnhanCount());
				listENH_Hana.add(reqMaster.getDefectEnhanCount());
				listENH_Hana.add(reqMaster.getDefectUsedEnhanCount());
				resultMap.put("ENH*", listENH_Hana);
			}

			if ((reqMaster.getCustFormCount() != null && reqMaster.getCustFormCount() != 0)
					|| (reqMaster.getCustUsedFormCount() != null && reqMaster.getCustUsedFormCount() != 0)
					|| (reqMaster.getDefectFormCount() != null && reqMaster.getDefectFormCount() != 0)
					|| (reqMaster.getDefectUsedFormCount() != null && reqMaster.getDefectUsedFormCount() != 0)) {
				listFORM_Hana.add(reqMaster.getCustFormCount());
				listFORM_Hana.add(reqMaster.getCustUsedFormCount());
				listFORM_Hana.add(reqMaster.getDefectFormCount());
				listFORM_Hana.add(reqMaster.getDefectUsedFormCount());
				resultMap.put("FORM", listFORM_Hana);
			}

			if ((reqMaster.getCustWebCount() != null && reqMaster.getCustWebCount() != 0)
					|| (reqMaster.getCustUsedWebCount() != null && reqMaster.getCustUsedWebCount() != 0)
					|| (reqMaster.getDefectWebCount() != null && reqMaster.getDefectWebCount() != 0)
					|| (reqMaster.getDefectUsedWebCount() != null && reqMaster.getDefectUsedWebCount() != 0)) {
				listWDYN_Hana.add(reqMaster.getCustWebCount());
				listWDYN_Hana.add(reqMaster.getCustUsedWebCount());
				listWDYN_Hana.add(reqMaster.getDefectWebCount());
				listWDYN_Hana.add(reqMaster.getDefectUsedWebCount());
				resultMap.put("WDYN", listWDYN_Hana);
			}

			if ((reqMaster.getCustReptCount() != null && reqMaster.getCustReptCount() != 0)
					|| (reqMaster.getCustUsedReptCount() != null && reqMaster.getCustUsedReptCount() != 0)
					|| (reqMaster.getDefectReptCount() != null && reqMaster.getDefectReptCount() != 0)
					|| (reqMaster.getDefectUsedReptCount() != null && reqMaster.getDefectUsedReptCount() != 0)) {
				listREPT_Hana.add(reqMaster.getCustReptCount());
				listREPT_Hana.add(reqMaster.getCustUsedReptCount());
				listREPT_Hana.add(reqMaster.getDefectReptCount());
				listREPT_Hana.add(reqMaster.getDefectUsedReptCount());
				resultMap.put("REPT", listREPT_Hana);
			}

			if ((reqMaster.getCustViewCount() != null && reqMaster.getCustViewCount() != 0)
					|| (reqMaster.getCustUsedViewCount() != null && reqMaster.getCustUsedViewCount() != 0)
					|| (reqMaster.getDefectViewCount() != null && reqMaster.getDefectViewCount() != 0)
					|| (reqMaster.getDefectUsedViewCount() != null && reqMaster.getDefectUsedViewCount() != 0)) {
				listVIEW_Hana.add(reqMaster.getCustViewCount());
				listVIEW_Hana.add(reqMaster.getCustUsedViewCount());
				listVIEW_Hana.add(reqMaster.getDefectViewCount());
				listVIEW_Hana.add(reqMaster.getDefectUsedViewCount());
				resultMap.put("VIEW", listVIEW_Hana);
			}

			if ((reqMaster.getCustIndeCount() != null && reqMaster.getCustIndeCount() != 0)
					|| (reqMaster.getCustUsedIndxCount() != null && reqMaster.getCustUsedIndxCount() != 0)
					|| (reqMaster.getDefectIndeCount() != null && reqMaster.getDefectIndeCount() != 0)
					|| (reqMaster.getDefectUsedIndxCount() != null && reqMaster.getDefectUsedIndxCount() != 0)) {
				listINDE_Hana.add(reqMaster.getCustIndeCount());
				listINDE_Hana.add(reqMaster.getCustUsedIndxCount());
				listINDE_Hana.add(reqMaster.getDefectIndeCount());
				listINDE_Hana.add(reqMaster.getDefectUsedIndxCount());
				resultMap.put("INDE", listINDE_Hana);
			}
			
			if ((reqMaster.getCustDtelCount() != null && reqMaster.getCustDtelCount() != 0)
					|| (reqMaster.getCustUsedDtelCount() != null && reqMaster.getCustUsedDtelCount() != 0)
					|| (reqMaster.getDefectDtelCount() != null && reqMaster.getDefectDtelCount() != 0)
					|| (reqMaster.getDefectUsedDtelCount() != null && reqMaster.getDefectUsedDtelCount() != 0)) {
				listDTEL_Hana.add(reqMaster.getCustDtelCount());
				listDTEL_Hana.add(reqMaster.getCustUsedDtelCount());
				listDTEL_Hana.add(reqMaster.getDefectDtelCount());
				listDTEL_Hana.add(reqMaster.getDefectUsedDtelCount());
				resultMap.put("DTEL", listDTEL_Hana);
			}


			if ((reqMaster.getUsreCount() != null && reqMaster.getUsreCount() != 0)
					|| (reqMaster.getUsreUsedCount() != null && reqMaster.getUsreUsedCount() != 0)
					|| (reqMaster.getDefectUsreCount() != null && reqMaster.getDefectUsreCount() != 0)
					|| (reqMaster.getDefectUsedUsreCount() != null && reqMaster.getDefectUsedUsreCount() != 0)) {
				listUSRE_Hana.add(reqMaster.getUsreCount());
				listUSRE_Hana.add(reqMaster.getUsreUsedCount());
				listUSRE_Hana.add(reqMaster.getDefectUsreCount());
				listUSRE_Hana.add(reqMaster.getDefectUsedUsreCount());
				resultMap.put("USRE", listUSRE_Hana);
			}

			if ((reqMaster.getUsrrCount() != null && reqMaster.getUsrrCount() != 0)
					|| (reqMaster.getUsrrUsedCount() != null && reqMaster.getUsrrUsedCount() != 0)
					|| (reqMaster.getDefectUsrrCount() != null && reqMaster.getDefectUsrrCount() != 0)
					|| (reqMaster.getDefectUsedUsrrCount() != null && reqMaster.getDefectUsedUsrrCount() != 0)) {
				listUSRR_Hana.add(reqMaster.getUsrrCount());
				listUSRR_Hana.add(reqMaster.getUsrrUsedCount());
				listUSRR_Hana.add(reqMaster.getDefectUsrrCount());
				listUSRR_Hana.add(reqMaster.getDefectUsedUsrrCount());
				resultMap.put("USRR", listUSRR_Hana);
			}

			if ((reqMaster.getFugsCount() != null && reqMaster.getFugsCount() != 0)
					|| (reqMaster.getFugsUsedCount() != null && reqMaster.getFugsUsedCount() != 0)
					|| (reqMaster.getDefectFugsCount() != null && reqMaster.getDefectFugsCount() != 0)
					|| (reqMaster.getDefectUsedFugsCount() != null && reqMaster.getDefectUsedFugsCount() != 0)) {
				listFUGS_Hana.add(reqMaster.getFugsCount());
				listFUGS_Hana.add(reqMaster.getFugsUsedCount());
				listFUGS_Hana.add(reqMaster.getDefectFugsCount());
				listFUGS_Hana.add(reqMaster.getDefectUsedFugsCount());
				resultMap.put("FUGS", listFUGS_Hana);
			}
			
			if ((reqMaster.getCustLsmwCount() != null && reqMaster.getCustLsmwCount() != 0)
					|| (reqMaster.getCustUsedLsmwCount() != null && reqMaster.getCustUsedLsmwCount() != 0)
					|| (reqMaster.getDefectLsmwCount() != null && reqMaster.getDefectLsmwCount() != 0)
					|| (reqMaster.getDefectUsedLsmwCount() != null && reqMaster.getDefectUsedLsmwCount() != 0)) {
				listLsmw_Hana.add(reqMaster.getCustLsmwCount());
				listLsmw_Hana.add(reqMaster.getCustUsedLsmwCount());
				listLsmw_Hana.add(reqMaster.getDefectLsmwCount());
				listLsmw_Hana.add(reqMaster.getDefectUsedLsmwCount());
				resultMap.put("LSMW", listLsmw_Hana);
			}
			
			if ((reqMaster.getTotalObjectCount() != null && reqMaster.getTotalObjectCount() != 0)
					|| (reqMaster.getUsed_count() !=null && reqMaster.getUsed_count()!=0)
					|| (reqMaster.getDefectCount() != null && reqMaster.getDefectCount() != 0)
					|| (reqMaster.getTotalImpactUsageCount()!=null && reqMaster.getTotalImpactUsageCount()!=0)) {
				listTotal_Hana.add(reqMaster.getTotalObjectCount());
				listTotal_Hana.add(reqMaster.getUsed_count());
				listTotal_Hana.add(reqMaster.getDefectCount());
				listTotal_Hana.add(reqMaster.getTotalImpactUsageCount());
				resultMap.put("TOTAL", listTotal_Hana);
			}
			

		}
		if (scope.equalsIgnoreCase("S4")) {
			
			if ((reqMaster.getCustClasCount() != null && reqMaster.getCustClasCount() != 0)
					|| (reqMaster.getCustUsedClasCount() != null && reqMaster.getCustUsedClasCount() != 0)
					|| (reqMaster.getDefectClasCount() != null && reqMaster.getDefectClasCount() != 0)
					|| (reqMaster.getDefectUsedClasCount() != null && reqMaster.getDefectUsedClasCount() != 0)) {
				listClass_S4.add(reqMaster.getCustClasCount());
				listClass_S4.add(reqMaster.getCustUsedClasCount());
				listClass_S4.add(reqMaster.getDefectClasCount());
				listClass_S4.add(reqMaster.getDefectUsedClasCount());
				resultMap.put("CLAS", listClass_S4);
			}
			
			if ((reqMaster.getCust_BWTRCount() != null && reqMaster.getCust_BWTRCount() != 0)
					|| (reqMaster.getCustUsed_BWTRCount() != null && reqMaster.getCustUsed_BWTRCount() != 0)
					|| (reqMaster.getDefect_BWTRCount() != null && reqMaster.getDefect_BWTRCount() != 0)
					|| (reqMaster.getDefectUsed_BWTRCount() != null && reqMaster.getDefectUsed_BWTRCount() != 0)) {
				listBWTR_S4.add(reqMaster.getCust_BWTRCount());
				listBWTR_S4.add(reqMaster.getCustUsed_BWTRCount());
				listBWTR_S4.add(reqMaster.getDefect_BWTRCount());
				listBWTR_S4.add(reqMaster.getDefectUsed_BWTRCount());
				resultMap.put("BWTR", listBWTR_S4);
			}
			
			if ((reqMaster.getCust_BWTSCount() != null && reqMaster.getCust_BWTSCount() != 0)
					|| (reqMaster.getCustUsed_BWTSCount() != null && reqMaster.getCustUsed_BWTSCount() != 0)
					|| (reqMaster.getDefect_BWTSCount() != null && reqMaster.getDefect_BWTSCount() != 0)
					|| (reqMaster.getDefectUsed_BWTSCount() != null && reqMaster.getDefectUsed_BWTSCount() != 0)) {
				listBWTS_S4.add(reqMaster.getCust_BWTSCount());
				listBWTS_S4.add(reqMaster.getCustUsed_BWTSCount());
				listBWTS_S4.add(reqMaster.getDefect_BWTSCount());
				listBWTS_S4.add(reqMaster.getDefectUsed_BWTSCount());
				resultMap.put("BWTS", listBWTS_S4);
			}
			
			if ((reqMaster.getCust_BWURCount() != null && reqMaster.getCust_BWURCount() != 0)
					|| (reqMaster.getCustUsed_BWURCount() != null && reqMaster.getCustUsed_BWURCount() != 0)
					|| (reqMaster.getDefect_BWURCount() != null && reqMaster.getDefect_BWURCount() != 0)
					|| (reqMaster.getDefectUsed_BWURCount() != null && reqMaster.getDefectUsed_BWURCount() != 0)) {
				listBWUR_S4.add(reqMaster.getCust_BWURCount());
				listBWUR_S4.add(reqMaster.getCustUsed_BWURCount());
				listBWUR_S4.add(reqMaster.getDefect_BWURCount());
				listBWUR_S4.add(reqMaster.getDefectUsed_BWURCount());
				resultMap.put("BWUR", listBWUR_S4);
			}
			
			if ((reqMaster.getCust_BWIGCount() != null && reqMaster.getCust_BWIGCount() != 0)
					|| (reqMaster.getCustUsed_BWIGCount() != null && reqMaster.getCustUsed_BWIGCount() != 0)
					|| (reqMaster.getDefect_BWIGCount() != null && reqMaster.getDefect_BWIGCount() != 0)
					|| (reqMaster.getDefectUsed_BWIGCount() != null && reqMaster.getDefectUsed_BWIGCount() != 0)) {
				listBWIG_S4.add(reqMaster.getCust_BWIGCount());
				listBWIG_S4.add(reqMaster.getCustUsed_BWIGCount());
				listBWIG_S4.add(reqMaster.getDefect_BWIGCount());
				listBWIG_S4.add(reqMaster.getDefectUsed_BWIGCount());
				resultMap.put("BWIG", listBWIG_S4);
			}

			if ((reqMaster.getCustProgCount() != null && reqMaster.getCustProgCount() != 0)
					|| (reqMaster.getCustUsedProgCount() != null && reqMaster.getCustUsedProgCount() != 0)
					|| (reqMaster.getDefectProgCount() != null && reqMaster.getDefectProgCount() != 0)
					|| (reqMaster.getDefectUsedProgCount() != null && reqMaster.getDefectUsedProgCount() != 0)) {
				listProg_S4.add(reqMaster.getCustProgCount());
				listProg_S4.add(reqMaster.getCustUsedProgCount());
				listProg_S4.add(reqMaster.getDefectProgCount());
				listProg_S4.add(reqMaster.getDefectUsedProgCount());
				resultMap.put("PROG", listProg_S4);
			}

			if ((reqMaster.getCustFugrCount() != null && reqMaster.getCustFugrCount() != 0)
					|| (reqMaster.getCustUsedFugrCount() != null && reqMaster.getCustUsedFugrCount() != 0)
					|| (reqMaster.getDefectFugrCount() != null && reqMaster.getDefectFugrCount() != 0)
					|| (reqMaster.getDefectUsedFugrCount() != null && reqMaster.getDefectUsedFugrCount() != 0)) {
				listFUGR_S4.add(reqMaster.getCustFugrCount());
				listFUGR_S4.add(reqMaster.getCustUsedFugrCount());
				listFUGR_S4.add(reqMaster.getDefectFugrCount());
				listFUGR_S4.add(reqMaster.getDefectUsedFugrCount());
				resultMap.put("FUGR", listFUGR_S4);
			}

			if ((reqMaster.getCustEnhanCount() != null && reqMaster.getCustEnhanCount() != 0)
					|| (reqMaster.getCustUsedEnhanCount() != null && reqMaster.getCustUsedEnhanCount() != 0)
					|| (reqMaster.getDefectEnhanCount() != null && reqMaster.getDefectEnhanCount() != 0)
					|| (reqMaster.getDefectUsedEnhanCount() != null && reqMaster.getDefectUsedEnhanCount() != 0)) {
				listENH_S4.add(reqMaster.getCustEnhanCount());
				listENH_S4.add(reqMaster.getCustUsedEnhanCount());
				listENH_S4.add(reqMaster.getDefectEnhanCount());
				listENH_S4.add(reqMaster.getDefectUsedEnhanCount());
				resultMap.put("ENH*", listENH_S4);
			}

			if ((reqMaster.getCustFormCount() != null && reqMaster.getCustFormCount() != 0)
					|| (reqMaster.getCustUsedFormCount() != null && reqMaster.getCustUsedFormCount() != 0)
					|| (reqMaster.getDefectFormCount() != null && reqMaster.getDefectFormCount() != 0)
					|| (reqMaster.getDefectUsedFormCount() != null && reqMaster.getDefectUsedFormCount() != 0)) {
				listFORM_S4.add(reqMaster.getCustFormCount());
				listFORM_S4.add(reqMaster.getCustUsedFormCount());
				listFORM_S4.add(reqMaster.getDefectFormCount());
				listFORM_S4.add(reqMaster.getDefectUsedFormCount());
				resultMap.put("FORM", listFORM_S4);
			}

			if ((reqMaster.getCustWebCount() != null && reqMaster.getCustWebCount() != 0)
					|| (reqMaster.getCustUsedWebCount() != null && reqMaster.getCustUsedWebCount() != 0)
					|| (reqMaster.getDefectWebCount() != null && reqMaster.getDefectWebCount() != 0)
					|| (reqMaster.getDefectUsedWebCount() != null && reqMaster.getDefectUsedWebCount() != 0)) {
				listWDYN_S4.add(reqMaster.getCustWebCount());
				listWDYN_S4.add(reqMaster.getCustUsedWebCount());
				listWDYN_S4.add(reqMaster.getDefectWebCount());
				listWDYN_S4.add(reqMaster.getDefectUsedWebCount());
				resultMap.put("WDYN", listWDYN_S4);
			}

			if ((reqMaster.getCustReptCount() != null && reqMaster.getCustReptCount() != 0)
					|| (reqMaster.getCustUsedReptCount() != null && reqMaster.getCustUsedReptCount() != 0)
					|| (reqMaster.getDefectReptCount() != null && reqMaster.getDefectReptCount() != 0)
					|| (reqMaster.getDefectUsedReptCount() != null && reqMaster.getDefectUsedReptCount() != 0)) {
				listREPT_S4.add(reqMaster.getCustReptCount());
				listREPT_S4.add(reqMaster.getCustUsedReptCount());
				listREPT_S4.add(reqMaster.getDefectReptCount());
				listREPT_S4.add(reqMaster.getDefectUsedReptCount());
				resultMap.put("REPT", listREPT_S4);
			}

			if ((reqMaster.getCustViewCount() != null && reqMaster.getCustViewCount() != 0)
					|| (reqMaster.getCustUsedViewCount() != null && reqMaster.getCustUsedViewCount() != 0)
					|| (reqMaster.getDefectViewCount() != null && reqMaster.getDefectViewCount() != 0)
					|| (reqMaster.getDefectUsedViewCount() != null && reqMaster.getDefectUsedViewCount() != 0)) {
				listVIEW_S4.add(reqMaster.getCustViewCount());
				listVIEW_S4.add(reqMaster.getCustUsedViewCount());
				listVIEW_S4.add(reqMaster.getDefectViewCount());
				listVIEW_S4.add(reqMaster.getDefectUsedViewCount());
				resultMap.put("VIEW", listVIEW_S4);
			}

			if ((reqMaster.getCustIndeCount() != null && reqMaster.getCustIndeCount() != 0)
					|| (reqMaster.getCustUsedIndxCount() != null && reqMaster.getCustUsedIndxCount() != 0)
					|| (reqMaster.getDefectIndeCount() != null && reqMaster.getDefectIndeCount() != 0)
					|| (reqMaster.getDefectUsedIndxCount() != null && reqMaster.getDefectUsedIndxCount() != 0)) {
				listINDE_S4.add(reqMaster.getCustIndeCount());
				listINDE_S4.add(reqMaster.getCustUsedIndxCount());
				listINDE_S4.add(reqMaster.getDefectIndeCount());
				listINDE_S4.add(reqMaster.getDefectUsedIndxCount());
				resultMap.put("INDE", listINDE_S4);
			}
			
			if ((reqMaster.getCustDtelCount() != null && reqMaster.getCustDtelCount() != 0)
					|| (reqMaster.getCustUsedDtelCount() != null && reqMaster.getCustUsedDtelCount() != 0)
					|| (reqMaster.getDefectDtelCount() != null && reqMaster.getDefectDtelCount() != 0)
					|| (reqMaster.getDefectUsedDtelCount() != null && reqMaster.getDefectUsedDtelCount() != 0)) {
				listDTEL_S4.add(reqMaster.getCustDtelCount());
				listDTEL_S4.add(reqMaster.getCustUsedDtelCount());
				listDTEL_S4.add(reqMaster.getDefectDtelCount());
				listDTEL_S4.add(reqMaster.getDefectUsedDtelCount());
				resultMap.put("DTEL", listDTEL_S4);
			}

			if ((reqMaster.getUsreCount() != null && reqMaster.getUsreCount() != 0)
					|| (reqMaster.getUsreUsedCount() != null && reqMaster.getUsreUsedCount() != 0)
					|| (reqMaster.getDefectUsreCount() != null && reqMaster.getDefectUsreCount() != 0)
					|| (reqMaster.getDefectUsedUsreCount() != null && reqMaster.getDefectUsedUsreCount() != 0)) {
				listUSRE_S4.add(reqMaster.getUsreCount());
				listUSRE_S4.add(reqMaster.getUsreUsedCount());
				listUSRE_S4.add(reqMaster.getDefectUsreCount());
				listUSRE_S4.add(reqMaster.getDefectUsedUsreCount());
				resultMap.put("USRE", listUSRE_S4);
			}

			if ((reqMaster.getUsrrCount() != null && reqMaster.getUsrrCount() != 0)
					|| (reqMaster.getUsrrUsedCount() != null && reqMaster.getUsrrUsedCount() != 0)
					|| (reqMaster.getDefectUsrrCount() != null && reqMaster.getDefectUsrrCount() != 0)
					|| (reqMaster.getDefectUsedUsrrCount() != null && reqMaster.getDefectUsedUsrrCount() != 0)) {
				listUSRR_S4.add(reqMaster.getUsrrCount());
				listUSRR_S4.add(reqMaster.getUsrrUsedCount());
				listUSRR_S4.add(reqMaster.getDefectUsrrCount());
				listUSRR_S4.add(reqMaster.getDefectUsedUsrrCount());
				resultMap.put("USRR", listUSRR_S4);
			}

			if ((reqMaster.getFugsCount() != null && reqMaster.getFugsCount() != 0)
					|| (reqMaster.getFugsUsedCount() != null && reqMaster.getFugsUsedCount() != 0)
					|| (reqMaster.getDefectFugsCount() != null && reqMaster.getDefectFugsCount() != 0)
					|| (reqMaster.getDefectUsedFugsCount() != null && reqMaster.getDefectUsedFugsCount() != 0)) {
				listFUGS_S4.add(reqMaster.getFugsCount());
				listFUGS_S4.add(reqMaster.getFugsUsedCount());
				listFUGS_S4.add(reqMaster.getDefectFugsCount());
				listFUGS_S4.add(reqMaster.getDefectUsedFugsCount());
				resultMap.put("FUGS", listFUGS_S4);
			}
			
			if ((reqMaster.getTotalObjectCount() != null && reqMaster.getTotalObjectCount() != 0)
					|| (reqMaster.getUsed_count() !=null && reqMaster.getUsed_count()!=0)
					|| (reqMaster.getDefectCount() != null && reqMaster.getDefectCount() != 0)
					|| (reqMaster.getTotalImpactUsageCount()!=null && reqMaster.getTotalImpactUsageCount()!=0)) {
				listTotal_S4.add(reqMaster.getTotalObjectCount());
				listTotal_S4.add(reqMaster.getUsed_count());
				listTotal_S4.add(reqMaster.getDefectCount());
				listTotal_S4.add(reqMaster.getTotalImpactUsageCount());
				resultMap.put("TOTAL", listTotal_S4);
			}
			
		}

		return resultMap;
	}

	// Slide 7.1-Hana && Slide 17.1-S4
	public LinkedHashMap<String, Integer> getImpactedABAPObjects(long requestId, ProcessedRequestDetail reqMaster) {
		final LinkedHashMap<String, Integer> resultMap = new LinkedHashMap<String, Integer>();

		String scope = reqMaster.getScope();
		if (scope.equalsIgnoreCase("Hana")) {
			
			if (reqMaster.getDefectClasCount() != null && reqMaster.getDefectClasCount() != 0) 
				resultMap.put("CLAS", reqMaster.getDefectClasCount());
			
			if (reqMaster.getDefect_BWTRCount() != null && reqMaster.getDefect_BWTRCount() != 0) 
				resultMap.put("BWTR", reqMaster.getDefect_BWTRCount());
			
			if (reqMaster.getDefect_BWTSCount() != null && reqMaster.getDefect_BWTSCount() != 0) 
				resultMap.put("BWTS", reqMaster.getDefect_BWTSCount());
			
			if (reqMaster.getDefect_BWURCount() != null && reqMaster.getDefect_BWURCount() != 0) 
				resultMap.put("BWUR", reqMaster.getDefect_BWURCount());
			
			if (reqMaster.getDefect_BWIGCount() != null && reqMaster.getDefect_BWIGCount() != 0) 
				resultMap.put("BWIG", reqMaster.getDefect_BWIGCount());

			if ((reqMaster.getDefectProgCount() != null && reqMaster.getDefectProgCount() != 0)) 
				resultMap.put("PROG", reqMaster.getDefectProgCount());

			if (reqMaster.getDefectFugrCount() != null && reqMaster.getDefectFugrCount() != 0)
				resultMap.put("FUGR", reqMaster.getDefectFugrCount());

			if (reqMaster.getDefectEnhanCount() != null && reqMaster.getDefectEnhanCount() != 0) 
				resultMap.put("ENH*", reqMaster.getDefectEnhanCount());

			if (reqMaster.getDefectFormCount() != null && reqMaster.getDefectFormCount() != 0) 
				resultMap.put("FORM", reqMaster.getDefectFormCount());

			if (reqMaster.getDefectWebCount() != null && reqMaster.getDefectWebCount() != 0)
				resultMap.put("WDYN", reqMaster.getDefectWebCount());

			if (reqMaster.getDefectReptCount() != null && reqMaster.getDefectReptCount() != 0)
				resultMap.put("REPT", reqMaster.getDefectReptCount());

			if (reqMaster.getDefectViewCount() != null && reqMaster.getDefectViewCount() != 0)
				resultMap.put("VIEW", reqMaster.getDefectViewCount());

			if (reqMaster.getDefectIndeCount() != null && reqMaster.getDefectIndeCount() != 0) 
				resultMap.put("INDE", reqMaster.getDefectIndeCount());
			
			if (reqMaster.getDefectDtelCount() != null && reqMaster.getDefectDtelCount() != 0) 
				resultMap.put("DTEL", reqMaster.getDefectIndeCount());

			if (reqMaster.getDefectUsreCount() != null && reqMaster.getDefectUsreCount() != 0)
				resultMap.put("USRE", reqMaster.getDefectUsreCount());

			if (reqMaster.getDefectUsrrCount() != null && reqMaster.getDefectUsrrCount() != 0)
				resultMap.put("USRR", reqMaster.getDefectUsrrCount());

			if (reqMaster.getDefectFugsCount() != null && reqMaster.getDefectFugsCount() != 0) 
				resultMap.put("FUGS", reqMaster.getDefectFugsCount());
			
			if (reqMaster.getDefectLsmwCount() != null && reqMaster.getDefectLsmwCount() != 0) 
				resultMap.put("LSMW", reqMaster.getDefectLsmwCount());
			
			if (reqMaster.getDefectCount() != null && reqMaster.getDefectCount() != 0) 
				resultMap.put("TotalCount", reqMaster.getDefectCount());
		}
		
		if (scope.equalsIgnoreCase("S4")) {
			if (reqMaster.getDefectClasCount() != null && reqMaster.getDefectClasCount() != 0) 
				resultMap.put("CLAS", reqMaster.getDefectClasCount());
			
			if (reqMaster.getDefect_BWTRCount() != null && reqMaster.getDefect_BWTRCount() != 0) 
				resultMap.put("BWTR", reqMaster.getDefect_BWTRCount());
			
			if (reqMaster.getDefect_BWTSCount() != null && reqMaster.getDefect_BWTSCount() != 0) 
				resultMap.put("BWTS", reqMaster.getDefect_BWTSCount());
			
			if (reqMaster.getDefect_BWURCount() != null && reqMaster.getDefect_BWURCount() != 0) 
				resultMap.put("BWUR", reqMaster.getDefect_BWURCount());
			
			if (reqMaster.getDefect_BWIGCount() != null && reqMaster.getDefect_BWIGCount() != 0) 
				resultMap.put("BWIG", reqMaster.getDefect_BWIGCount());

			if ((reqMaster.getDefectProgCount() != null && reqMaster.getDefectProgCount() != 0)) 
				resultMap.put("PROG", reqMaster.getDefectProgCount());
			
			if (reqMaster.getDefectFugrCount() != null && reqMaster.getDefectFugrCount() != 0) 
				resultMap.put("FUGR", reqMaster.getDefectFugrCount());
			
			if (reqMaster.getDefectEnhanCount() != null && reqMaster.getDefectEnhanCount() != 0) 
				resultMap.put("ENH*", reqMaster.getDefectEnhanCount());
			
			if (reqMaster.getDefectFormCount() != null && reqMaster.getDefectFormCount() != 0) 
				resultMap.put("FORM", reqMaster.getDefectFormCount());
			
			if (reqMaster.getDefectWebCount() != null && reqMaster.getDefectWebCount() != 0) 
				resultMap.put("WDYN", reqMaster.getDefectWebCount());
			
			if (reqMaster.getDefectReptCount() != null && reqMaster.getDefectReptCount() != 0) 
				resultMap.put("REPT", reqMaster.getDefectReptCount());
			
			if (reqMaster.getDefectViewCount() != null && reqMaster.getDefectViewCount() != 0) 
				resultMap.put("VIEW", reqMaster.getDefectViewCount());
			
			if (reqMaster.getDefectIndeCount() != null && reqMaster.getDefectIndeCount() != 0) 
				resultMap.put("INDE", reqMaster.getDefectIndeCount());
			
			if (reqMaster.getDefectDtelCount() != null && reqMaster.getDefectDtelCount() != 0) 
				resultMap.put("DTEL", reqMaster.getDefectDtelCount());
			
			if (reqMaster.getDefectUsreCount() != null && reqMaster.getDefectUsreCount() != 0) 
				resultMap.put("USRE", reqMaster.getDefectUsreCount());
			
			if (reqMaster.getDefectUsrrCount() != null && reqMaster.getDefectUsrrCount() != 0) 
				resultMap.put("USRR", reqMaster.getDefectUsrrCount());
			
			if (reqMaster.getDefectFugsCount() != null && reqMaster.getDefectFugsCount() != 0) 
				resultMap.put("FUGS", reqMaster.getDefectFugsCount());
			
			if (reqMaster.getDefectLsmwCount() != null && reqMaster.getDefectLsmwCount() != 0) 
				resultMap.put("LSMW", reqMaster.getDefectLsmwCount());
			
			if (reqMaster.getDefectCount() != null && reqMaster.getDefectCount() != 0) 
				resultMap.put("TotalCount", reqMaster.getDefectCount());
		}

		return resultMap;
	}

	// Slide 7.2-Hana && Slide 17.2-S4
	public LinkedHashMap<String, Integer> getCustomInventoryObjects(long requestId, ProcessedRequestDetail reqMaster) {
		final LinkedHashMap<String, Integer> resultMap = new LinkedHashMap<String, Integer>();

		String scope = reqMaster.getScope();
		if (scope.equalsIgnoreCase("Hana")) {

			if (reqMaster.getCustClasCount() != null && reqMaster.getCustClasCount() != 0) 
				resultMap.put("CLAS", reqMaster.getCustClasCount());
			
			if (reqMaster.getCust_BWTRCount() != null && reqMaster.getCust_BWTRCount() != 0) 
				resultMap.put("BWTR", reqMaster.getCust_BWTRCount());
			
			if (reqMaster.getCust_BWTSCount() != null && reqMaster.getCust_BWTSCount() != 0) 
				resultMap.put("BWTS", reqMaster.getCust_BWTSCount());
			
			if (reqMaster.getCust_BWURCount() != null && reqMaster.getCust_BWURCount() != 0) 
				resultMap.put("BWUR", reqMaster.getCust_BWURCount());
			
			if (reqMaster.getCust_BWIGCount() != null && reqMaster.getCust_BWIGCount() != 0) 
				resultMap.put("BWIG", reqMaster.getCust_BWIGCount());
			
			if ((reqMaster.getCustProgCount() != null && reqMaster.getCustProgCount() != 0)) 
				resultMap.put("PROG", reqMaster.getCustProgCount());

			if (reqMaster.getCustFugrCount() != null && reqMaster.getCustFugrCount() != 0) 
				resultMap.put("FUGR", reqMaster.getCustFugrCount());

			if (reqMaster.getCustEnhanCount() != null && reqMaster.getCustEnhanCount() != 0) 
				resultMap.put("ENH*", reqMaster.getCustEnhanCount());

			if (reqMaster.getCustFormCount() != null && reqMaster.getCustFormCount() != 0) 
				resultMap.put("FORM", reqMaster.getCustFormCount());

			if (reqMaster.getCustWebCount() != null && reqMaster.getCustWebCount() != 0) 
				resultMap.put("WDYN", reqMaster.getCustWebCount());

			if (reqMaster.getCustReptCount() != null && reqMaster.getCustReptCount() != 0) 
				resultMap.put("REPT", reqMaster.getCustReptCount());

			if (reqMaster.getCustViewCount() != null && reqMaster.getCustViewCount() != 0) 
				resultMap.put("VIEW", reqMaster.getCustViewCount());

			if (reqMaster.getCustIndeCount() != null && reqMaster.getCustIndeCount() != 0)
				resultMap.put("INDE", reqMaster.getCustIndeCount());
			
			if(reqMaster.getCustDtelCount() != null && reqMaster.getCustDtelCount() != 0) 
				resultMap.put("DTEL", reqMaster.getCustDtelCount());

			if (reqMaster.getUsreCount() != null && reqMaster.getUsreCount() != 0)
				resultMap.put("USRE", reqMaster.getUsreCount());

			if (reqMaster.getUsrrCount() != null && reqMaster.getUsrrCount() != 0) 
				resultMap.put("USRR", reqMaster.getUsrrCount());

			if (reqMaster.getFugsCount() != null && reqMaster.getFugsCount() != 0) 
				resultMap.put("FUGS", reqMaster.getFugsCount());
			
			if (reqMaster.getCustLsmwCount() != null && reqMaster.getCustLsmwCount() != 0) 
				resultMap.put("LSMW", reqMaster.getCustLsmwCount());

			if (reqMaster.getTotalObjectCount() != null && reqMaster.getTotalObjectCount() != 0) 
				resultMap.put("TotalCount", reqMaster.getTotalObjectCount());
		}

		if (scope.equalsIgnoreCase("S4")) {

			if (reqMaster.getCustClasCount() != null && reqMaster.getCustClasCount() != 0) 
				resultMap.put("CLAS", reqMaster.getCustClasCount());
			
			if (reqMaster.getCust_BWTRCount() != null && reqMaster.getCust_BWTRCount() != 0) 
				resultMap.put("BWTR", reqMaster.getCust_BWTRCount());
			
			if (reqMaster.getCust_BWTSCount() != null && reqMaster.getCust_BWTSCount() != 0) 
				resultMap.put("BWTS", reqMaster.getCust_BWTSCount());
			
			if (reqMaster.getCust_BWURCount() != null && reqMaster.getCust_BWURCount() != 0) 
				resultMap.put("BWUR", reqMaster.getCust_BWURCount());
			
			if (reqMaster.getCust_BWIGCount() != null && reqMaster.getCust_BWIGCount() != 0) 
				resultMap.put("BWIG", reqMaster.getCust_BWIGCount());
		
			if ((reqMaster.getCustProgCount() != null && reqMaster.getCustProgCount() != 0)) 
				resultMap.put("PROG", reqMaster.getCustProgCount());

			if (reqMaster.getCustFugrCount() != null && reqMaster.getCustFugrCount() != 0) 
				resultMap.put("FUGR", reqMaster.getCustFugrCount());

			if (reqMaster.getCustEnhanCount() != null && reqMaster.getCustEnhanCount() != 0) 
				resultMap.put("ENH*", reqMaster.getCustEnhanCount());
			
			if (reqMaster.getCustFormCount() != null && reqMaster.getCustFormCount() != 0) 
				resultMap.put("FORM", reqMaster.getCustFormCount());
			
			if (reqMaster.getCustWebCount() != null && reqMaster.getCustWebCount() != 0) 
				resultMap.put("WDYN", reqMaster.getCustWebCount());
			
			if (reqMaster.getCustReptCount() != null && reqMaster.getCustReptCount() != 0) 
				resultMap.put("REPT", reqMaster.getCustReptCount());
			
			if (reqMaster.getCustViewCount() != null && reqMaster.getCustViewCount() != 0) 
				resultMap.put("VIEW", reqMaster.getCustViewCount());
			
			if (reqMaster.getCustIndeCount() != null && reqMaster.getCustIndeCount() != 0) 
				resultMap.put("INDE", reqMaster.getCustIndeCount());
		
			if (reqMaster.getCustDtelCount() != null && reqMaster.getCustDtelCount() != 0) 
				resultMap.put("DTEL", reqMaster.getCustDtelCount());
			
			if (reqMaster.getUsreCount() != null && reqMaster.getUsreCount() != 0) 
				resultMap.put("USRE", reqMaster.getUsreCount());
			
			if (reqMaster.getUsrrCount() != null && reqMaster.getUsrrCount() != 0) 
				resultMap.put("USRR", reqMaster.getUsrrCount());
			
			if (reqMaster.getFugsCount() != null && reqMaster.getFugsCount() != 0) 
				resultMap.put("FUGS", reqMaster.getFugsCount());
			
			if (reqMaster.getCustLsmwCount() != null && reqMaster.getCustLsmwCount() != 0) 
				resultMap.put("LSMW", reqMaster.getCustLsmwCount());
			
			if (reqMaster.getTotalObjectCount() != null && reqMaster.getTotalObjectCount() != 0) 
				resultMap.put("TotalCount", reqMaster.getTotalObjectCount());
		}

		return resultMap;
	}

	// Slide 10
	public Map<String, Map<String, Map<String, Map<String, Integer>>>> getManNumCorErrorTypeHana(long requestId,
			ProcessedRequestDetail reqMaster) {

		Map<String, Map<String, Map<String, Map<String, Integer>>>> MandatoryCorrectionsByErrorType = new LinkedHashMap<String, Map<String, Map<String, Map<String, Integer>>>>();

		Map<String, Map<String, Map<String, Integer>>> ManualRemidiationByErrorType = new LinkedHashMap<String, Map<String, Map<String, Integer>>>();
		Map<String, Map<String, Map<String, Integer>>> AutomaticRemidiationByErrorType = new LinkedHashMap<String, Map<String, Map<String, Integer>>>();

		Map<String, Map<String, Integer>> SyntaxError_ManualRemidi = new LinkedHashMap<String, Map<String, Integer>>();
		Map<String, Map<String, Integer>> FunctionalError_ManualRemidi = new LinkedHashMap<String, Map<String, Integer>>();

		Map<String, Map<String, Integer>> SyntaxError_AutomaticRemidi = new LinkedHashMap<String, Map<String, Integer>>();
		Map<String, Map<String, Integer>> FunctionalError_AutomaticRemidi = new LinkedHashMap<String, Map<String, Integer>>();

		Map<String, Integer> SemanticError_ManualRemidi = new LinkedHashMap<String, Integer>();
		Map<String, Integer> ValidatedSyntaxError_ManualRemidi = new LinkedHashMap<String, Integer>();
		Map<String, Integer> PotentialSyntaxError_ManualRemidi = new LinkedHashMap<String, Integer>();
		Map<String, Integer> HanaSorting_ManualRemidi = new LinkedHashMap<String, Integer>();

		Map<String, Integer> SemanticError_AutomaticRemidi = new LinkedHashMap<String, Integer>();
		Map<String, Integer> ValidatedSyntaxError_AutomaticRemidi = new LinkedHashMap<String, Integer>();
		Map<String, Integer> PotentialSyntaxError_AutomaticRemidi = new LinkedHashMap<String, Integer>();
		Map<String, Integer> HanaSorting_AutomaticRemidi = new LinkedHashMap<String, Integer>();

		/*
		 * Manual Remediation Counts:---
		 */
		// Syntax Error---
		if (reqMaster.getManSynPotentialAutoNError() != null && reqMaster.getManSynPotentialAutoNError() != 0) {
			PotentialSyntaxError_ManualRemidi.put("Number of ABAP objects", reqMaster.getManSynPotentialAutoN());
			PotentialSyntaxError_ManualRemidi.put("Number of findings", reqMaster.getManSynPotentialAutoNError());
			SyntaxError_ManualRemidi.put("Potential syntax error", PotentialSyntaxError_ManualRemidi);
		}

		if (reqMaster.getManSynValidAutoNError() != null && reqMaster.getManSynValidAutoNError() != 0) {
			ValidatedSyntaxError_ManualRemidi.put("Number of ABAP objects", reqMaster.getManSynValidAutoN());
			ValidatedSyntaxError_ManualRemidi.put("Number of findings", reqMaster.getManSynValidAutoNError());
			SyntaxError_ManualRemidi.put("Validated syntax error", ValidatedSyntaxError_ManualRemidi);
		}

		// Functional Error---
		if (reqMaster.getManFunSemanticAutoNError() != null && reqMaster.getManFunSemanticAutoNError() != 0) {
			SemanticError_ManualRemidi.put("Number of ABAP objects", reqMaster.getManFunSemanticAutoN());
			SemanticError_ManualRemidi.put("Number of findings", reqMaster.getManFunSemanticAutoNError());
			FunctionalError_ManualRemidi.put("Semantic Error", SemanticError_ManualRemidi);
		}

		if (reqMaster.getManFunHanaSortAutoNError() != null && reqMaster.getManFunHanaSortAutoNError() != 0) {
			HanaSorting_ManualRemidi.put("Number of ABAP objects", reqMaster.getManFunHanaSortAutoN());
			HanaSorting_ManualRemidi.put("Number of findings", reqMaster.getManFunHanaSortAutoNError());
			FunctionalError_ManualRemidi.put("HANA Sorting", HanaSorting_ManualRemidi);
		}

		/*
		 * Automatic Remediation Counts:---
		 */
		// Syntax Error---
		if (reqMaster.getManSynPotentialAutoYError() != null && reqMaster.getManSynPotentialAutoYError() != 0) {
			PotentialSyntaxError_AutomaticRemidi.put("Number of ABAP objects", reqMaster.getManSynPotentialAutoY());
			PotentialSyntaxError_AutomaticRemidi.put("Number of findings", reqMaster.getManSynPotentialAutoYError());
			SyntaxError_AutomaticRemidi.put("Potential syntax error", PotentialSyntaxError_AutomaticRemidi);
		}

		if (reqMaster.getManSynValidAutoYError() != null && reqMaster.getManSynValidAutoYError() != 0) {
			ValidatedSyntaxError_AutomaticRemidi.put("Number of ABAP objects", reqMaster.getManSynValidAutoY());
			ValidatedSyntaxError_AutomaticRemidi.put("Number of findings", reqMaster.getManSynValidAutoYError());
			SyntaxError_AutomaticRemidi.put("Validated syntax error", ValidatedSyntaxError_AutomaticRemidi);
		}

		// Functional Error---
		if (reqMaster.getManFunSemanticAutoYError() != null && reqMaster.getManFunSemanticAutoYError() != 0) {
			SemanticError_AutomaticRemidi.put("Number of ABAP objects", reqMaster.getManFunSemanticAutoY());
			SemanticError_AutomaticRemidi.put("Number of findings", reqMaster.getManFunSemanticAutoYError());
			FunctionalError_AutomaticRemidi.put("Semantic Error", SemanticError_AutomaticRemidi);
		}

		if (reqMaster.getManFunHanaSortAutoYError() != null && reqMaster.getManFunHanaSortAutoYError() != 0) {
			HanaSorting_AutomaticRemidi.put("Number of ABAP objects", reqMaster.getManFunHanaSortAutoY());
			HanaSorting_AutomaticRemidi.put("Number of findings", reqMaster.getManFunHanaSortAutoYError());
			FunctionalError_AutomaticRemidi.put("HANA Sorting", HanaSorting_AutomaticRemidi);
		}

		// Manual Remediation Maps---
		if (SyntaxError_ManualRemidi.size() > 0) {
			ManualRemidiationByErrorType.put("Syntax Error", SyntaxError_ManualRemidi);
		}
		if (FunctionalError_ManualRemidi.size() > 0) {
			ManualRemidiationByErrorType.put("Functional error", FunctionalError_ManualRemidi);
		}

		// Automatic Remediation Maps---
		if (SyntaxError_AutomaticRemidi.size() > 0) {
			AutomaticRemidiationByErrorType.put("Syntax Error", SyntaxError_AutomaticRemidi);
		}

		if (FunctionalError_AutomaticRemidi.size() > 0) {
			AutomaticRemidiationByErrorType.put("Functional error", FunctionalError_AutomaticRemidi);
		}

		// Mandatory Corrections by Error Type Map---
		if (ManualRemidiationByErrorType.size() > 0) {
			MandatoryCorrectionsByErrorType.put("Manual Remediation", ManualRemidiationByErrorType);
		}
		if (AutomaticRemidiationByErrorType.size() > 0) {
			MandatoryCorrectionsByErrorType.put("Automatic Remediation", AutomaticRemidiationByErrorType);
		}

		return MandatoryCorrectionsByErrorType;

	}

	// Slide 8.1(Hana) && Slide 18.1(S4)
	public LinkedHashMap<String, Integer> getImpactedRemediationCategoryCount(long requestId,
			ProcessedRequestDetail reqMaster) {
		final LinkedHashMap<String, Integer> resultMap = new LinkedHashMap<String, Integer>();

		String scope = reqMaster.getScope();
		if (scope.equalsIgnoreCase("Hana")) {

			if (reqMaster.getApp_level_category_count() != null && reqMaster.getApp_level_category_count() != 0) {
				resultMap.put("Application level optimization", reqMaster.getApp_level_category_count());
			}

			if ((reqMaster.getDb_level_category_count() != null && reqMaster.getDb_level_category_count() != 0)) {
				resultMap.put("DB Level HANA Optimization", reqMaster.getDb_level_category_count());
			}

			if (reqMaster.getHousekeeping_for_HANA_category_count() != null
					&& reqMaster.getHousekeeping_for_HANA_category_count() != 0) {
				resultMap.put("Housekeeping for HANA", reqMaster.getHousekeeping_for_HANA_category_count());
			}

			if (reqMaster.getMandatory_Category_count() != null && reqMaster.getMandatory_Category_count() != 0) {
				resultMap.put("Mandatory", reqMaster.getMandatory_Category_count());
			}
		}
		if (scope.equalsIgnoreCase("S4")) {

			if (reqMaster.getMandatory_Category_count() != null && reqMaster.getMandatory_Category_count() != 0) {
				resultMap.put("MANDATORY", reqMaster.getMandatory_Category_count());
			}

			if ((reqMaster.getOptionalCount() != null && reqMaster.getOptionalCount() != 0)) {
				resultMap.put("OPTIONAL", reqMaster.getOptionalCount());
			}
		}

		return resultMap;
	}

	// Slide 8.2(Hana) && Slide 18.2(S4)
	public LinkedHashMap<String, Integer> getErrorRemediationCategoryCount(long requestId,
			ProcessedRequestDetail reqMaster) {
		final LinkedHashMap<String, Integer> resultMap = new LinkedHashMap<String, Integer>();

		String scope = reqMaster.getScope();
		if (scope.equalsIgnoreCase("Hana")) {

			if (reqMaster.getErrorRemediationAppLevel() != null && reqMaster.getErrorRemediationAppLevel() != 0) {
				resultMap.put("Application level optimization", reqMaster.getErrorRemediationAppLevel());
			}

			if ((reqMaster.getErrorRemediationDbLevel() != null && reqMaster.getErrorRemediationDbLevel() != 0)) {
				resultMap.put("DB Level HANA Optimization", reqMaster.getErrorRemediationDbLevel());
			}

			if (reqMaster.getErrorRemediationHouseKeeping() != null
					&& reqMaster.getErrorRemediationHouseKeeping() != 0) {
				resultMap.put("Housekeeping for HANA", reqMaster.getErrorRemediationHouseKeeping());
			}

			if (reqMaster.getErrorRemediationMandatory() != null && reqMaster.getErrorRemediationMandatory() != 0) {
				resultMap.put("Mandatory", reqMaster.getErrorRemediationMandatory());
			}
		}
		if (scope.equalsIgnoreCase("S4")) {

			if (reqMaster.getErrorRemediationMandatory() != null && reqMaster.getErrorRemediationMandatory() != 0) {
				resultMap.put("MANDATORY", reqMaster.getErrorRemediationMandatory());
			}

			if ((reqMaster.getErrorRemediationOptional() != null && reqMaster.getErrorRemediationOptional() != 0)) {
				resultMap.put("OPTIONAL", reqMaster.getErrorRemediationOptional());
			}
		}

		return resultMap;
	}

	// Slide 9.1
	public LinkedHashMap<String, List<Integer>> getRemediationAndCorrectionTypeCounts(long requestId,
			ProcessedRequestDetail reqMaster) {
		final LinkedHashMap<String, List<Integer>> resultMap = new LinkedHashMap<String, List<Integer>>();

		List<Integer> listMandatory_Hana = new ArrayList<Integer>();

		List<Integer> listHouseKeeping_Hana = new ArrayList<Integer>();

		List<Integer> listDBLevel_Hana = new ArrayList<Integer>();

		List<Integer> listApplicationLevel_Hana = new ArrayList<Integer>();

		String scope = reqMaster.getScope();
		if (scope.equalsIgnoreCase("Hana")) {
			if ((reqMaster.getMandatoryAutoY() != null && reqMaster.getMandatoryAutoY() != 0)
					|| (reqMaster.getMandatoryAutoN() != null && reqMaster.getMandatoryAutoN() != 0)) {
				listMandatory_Hana.add(reqMaster.getMandatoryAutoY());
				listMandatory_Hana.add(reqMaster.getMandatoryAutoN());
				resultMap.put("Mandatory", listMandatory_Hana);
			}

			if ((reqMaster.getHkAutoY() != null && reqMaster.getHkAutoY() != 0)
					|| (reqMaster.getHkAutoN() != null && reqMaster.getHkAutoN() != 0)) {
				listHouseKeeping_Hana.add(reqMaster.getHkAutoY());
				listHouseKeeping_Hana.add(reqMaster.getHkAutoN());
				resultMap.put("Housekeeping for HANA", listHouseKeeping_Hana);
			}

			if ((reqMaster.getDbLevelAutoY() != null && reqMaster.getDbLevelAutoY() != 0)
					|| (reqMaster.getDbLevelAutoN() != null && reqMaster.getDbLevelAutoN() != 0)) {
				listDBLevel_Hana.add(reqMaster.getDbLevelAutoY());
				listDBLevel_Hana.add(reqMaster.getDbLevelAutoN());
				resultMap.put("DB Level HANA Optimization", listDBLevel_Hana);
			}

			if ((reqMaster.getAppLevelAutoY() != null && reqMaster.getAppLevelAutoY() != 0)
					|| (reqMaster.getAppLevelAutoN() != null && reqMaster.getAppLevelAutoN() != 0)) {
				listApplicationLevel_Hana.add(reqMaster.getAppLevelAutoY());
				listApplicationLevel_Hana.add(reqMaster.getAppLevelAutoN());
				resultMap.put("Application level optimization", listApplicationLevel_Hana);
			}
		}

		return resultMap;
	}

	// Slide 9.2
	public LinkedHashMap<String, List<Integer>> getErrorRemediationAndCorrectionTypeCounts(long requestId,
			ProcessedRequestDetail reqMaster) {
		final LinkedHashMap<String, List<Integer>> resultMap = new LinkedHashMap<String, List<Integer>>();

		List<Integer> listErrorMandatory_Hana = new ArrayList<Integer>();

		List<Integer> listErrorHouseKeeping_Hana = new ArrayList<Integer>();

		List<Integer> listErrorDBLevel_Hana = new ArrayList<Integer>();

		List<Integer> listErrorApplicationLevel_Hana = new ArrayList<Integer>();

		String scope = reqMaster.getScope();
		if (scope.equalsIgnoreCase("Hana")) {
			if ((reqMaster.getErrorMandatoryAutoY() != null && reqMaster.getErrorMandatoryAutoY() != 0)
					|| (reqMaster.getMandatoryAutoN() != null && reqMaster.getErrorMandatoryAutoN() != 0)) {
				listErrorMandatory_Hana.add(reqMaster.getErrorMandatoryAutoY());
				listErrorMandatory_Hana.add(reqMaster.getErrorMandatoryAutoN());
				resultMap.put("Mandatory", listErrorMandatory_Hana);
			}

			if ((reqMaster.getErrorHkAutoY() != null && reqMaster.getErrorHkAutoY() != 0)
					|| (reqMaster.getErrorHkAutoN() != null && reqMaster.getErrorHkAutoN() != 0)) {
				listErrorHouseKeeping_Hana.add(reqMaster.getErrorHkAutoY());
				listErrorHouseKeeping_Hana.add(reqMaster.getErrorHkAutoN());
				resultMap.put("Housekeeping for HANA", listErrorHouseKeeping_Hana);
			}

			if ((reqMaster.getErrorDbLevelAutoY() != null && reqMaster.getErrorDbLevelAutoY() != 0)
					|| (reqMaster.getDbLevelAutoN() != null && reqMaster.getErrorDbLevelAutoN() != 0)) {
				listErrorDBLevel_Hana.add(reqMaster.getErrorDbLevelAutoY());
				listErrorDBLevel_Hana.add(reqMaster.getErrorDbLevelAutoN());
				resultMap.put("DB Level HANA Optimization", listErrorDBLevel_Hana);
			}

			if ((reqMaster.getErrorAppLevelAutoY() != null && reqMaster.getErrorAppLevelAutoY() != 0)
					|| (reqMaster.getErrorAppLevelAutoN() != null && reqMaster.getErrorAppLevelAutoN() != 0)) {
				listErrorApplicationLevel_Hana.add(reqMaster.getErrorAppLevelAutoY());
				listErrorApplicationLevel_Hana.add(reqMaster.getErrorAppLevelAutoN());
				resultMap.put("Application level optimization", listErrorApplicationLevel_Hana);
			}
		}

		return resultMap;
	}

	// Slide 12
	public Map<String, Map<String, Map<String, Map<String, Integer>>>> getDBLevelHanaOptimizationCounts(long requestId,
			ProcessedRequestDetail reqMaster) {

		Map<String, Map<String, Map<String, Map<String, Integer>>>> DBLevelHanaOptimizationMap = new LinkedHashMap<String, Map<String, Map<String, Map<String, Integer>>>>();

		Map<String, Map<String, Map<String, Integer>>> Performance_HanaSpecific = new LinkedHashMap<String, Map<String, Map<String, Integer>>>();

		Map<String, Map<String, Integer>> MinimiseTransferredData_Performance_HanaSpecific = new LinkedHashMap<String, Map<String, Integer>>();

		Map<String, Integer> DbMinAmtRepeatDb = new LinkedHashMap<String, Integer>();
		Map<String, Integer> DbMinAmtJoinSelectStmt = new LinkedHashMap<String, Integer>();
		Map<String, Integer> DbMinAmtAllEntries = new LinkedHashMap<String, Integer>();
		Map<String, Integer> DbMinAmtCurrencyConv = new LinkedHashMap<String, Integer>();
		Map<String, Integer> DbMinAmtFaeJoin = new LinkedHashMap<String, Integer>();
		Map<String, Integer> DbMinAmtAggStmtCollect = new LinkedHashMap<String, Integer>();

		if ((reqMaster.getDbMinAmtRepeatDbAutoN() != null && reqMaster.getDbMinAmtRepeatDbAutoN() != 0)
				|| (reqMaster.getDbMinAmtRepeatDbAutoNError() != null
						&& reqMaster.getDbMinAmtRepeatDbAutoNError() != 0)) {
			DbMinAmtRepeatDb.put("Number of ABAP objects", reqMaster.getDbMinAmtRepeatDbAutoN());
			DbMinAmtRepeatDb.put("Number of findings", reqMaster.getDbMinAmtRepeatDbAutoNError());
			MinimiseTransferredData_Performance_HanaSpecific.put("Repeated Database Hits On Table", DbMinAmtRepeatDb);
		}

		if ((reqMaster.getDbMinAmtJoinSelectStmtAutoN() != null && reqMaster.getDbMinAmtJoinSelectStmtAutoN() != 0)
				|| (reqMaster.getDbMinAmtJoinSelectAutoNError() != null
						&& reqMaster.getDbMinAmtJoinSelectAutoNError() != 0)) {
			DbMinAmtJoinSelectStmt.put("Number of ABAP objects", reqMaster.getDbMinAmtJoinSelectStmtAutoN());
			DbMinAmtJoinSelectStmt.put("Number of findings", reqMaster.getDbMinAmtJoinSelectAutoNError());
			MinimiseTransferredData_Performance_HanaSpecific.put("JOINS ON TABLES IN SELECT STATEMENTS",
					DbMinAmtJoinSelectStmt);
		}

		if ((reqMaster.getDbMinAmtAllEntriesAutoN() != null && reqMaster.getDbMinAmtAllEntriesAutoN() != 0)
				|| (reqMaster.getDbMinAmtAllEntriesAutoNError() != null
						&& reqMaster.getDbMinAmtAllEntriesAutoNError() != 0)) {
			DbMinAmtAllEntries.put("Number of ABAP objects", reqMaster.getDbMinAmtAllEntriesAutoN());
			DbMinAmtAllEntries.put("Number of findings", reqMaster.getDbMinAmtAllEntriesAutoNError());
			MinimiseTransferredData_Performance_HanaSpecific.put("For All Entries used", DbMinAmtAllEntries);
		}

		if ((reqMaster.getDbMinAmtCurrencyConvAutoN() != null && reqMaster.getDbMinAmtCurrencyConvAutoN() != 0)
				|| (reqMaster.getDbMinAmtCurrencyAutoNError() != null
						&& reqMaster.getDbMinAmtCurrencyAutoNError() != 0)) {
			DbMinAmtCurrencyConv.put("Number of ABAP objects", reqMaster.getDbMinAmtCurrencyConvAutoN());
			DbMinAmtCurrencyConv.put("Number of findings", reqMaster.getDbMinAmtCurrencyAutoNError());
			MinimiseTransferredData_Performance_HanaSpecific.put("FM USED FOR CURRENCY CONVERSION",
					DbMinAmtCurrencyConv);
		}

		if ((reqMaster.getDbMinAmtFaeJoinAutoN() != null && reqMaster.getDbMinAmtFaeJoinAutoN() != 0)
				|| (reqMaster.getDbMinAmtFaeJoinAutoNError() != null
						&& reqMaster.getDbMinAmtFaeJoinAutoNError() != 0)) {
			DbMinAmtFaeJoin.put("Number of ABAP objects", reqMaster.getDbMinAmtFaeJoinAutoN());
			DbMinAmtFaeJoin.put("Number of findings", reqMaster.getDbMinAmtFaeJoinAutoNError());
			MinimiseTransferredData_Performance_HanaSpecific.put("FAE & JOIN", DbMinAmtFaeJoin);
		}

		if ((reqMaster.getDbMinAmtAggStmtCollectAutoN() != null && reqMaster.getDbMinAmtAggStmtCollectAutoN() != 0)
				|| (reqMaster.getDbMinAmtAggStmtAutoNError() != null
						&& reqMaster.getDbMinAmtAggStmtAutoNError() != 0)) {
			DbMinAmtAggStmtCollect.put("Number of ABAP objects", reqMaster.getDbMinAmtAggStmtCollectAutoN());
			DbMinAmtAggStmtCollect.put("Number of findings", reqMaster.getDbMinAmtAggStmtAutoNError());
			MinimiseTransferredData_Performance_HanaSpecific.put("AGGREGATION STATEMENT COLLECT",
					DbMinAmtAggStmtCollect);
		}

		if (MinimiseTransferredData_Performance_HanaSpecific.size() > 0) {
			Performance_HanaSpecific.put("Minimize the amount of transferred data",
					MinimiseTransferredData_Performance_HanaSpecific);
		}

		if (Performance_HanaSpecific.size() > 0) {
			DBLevelHanaOptimizationMap.put("PERFORMANCE (HANA SPECIFIC)", Performance_HanaSpecific);
		}

		return DBLevelHanaOptimizationMap;

	}

	// Slide 13
	public Map<String, Map<String, Map<String, Integer>>> getApplicationLevelOptimizationCount(long requestId,
			ProcessedRequestDetail reqMaster) {

		Map<String, Map<String, Map<String, Integer>>> ApplicationLevelOptimizationMap = new LinkedHashMap<String, Map<String, Map<String, Integer>>>();

		Map<String, Map<String, Integer>> CodeMaintainability_HanaSpecific = new LinkedHashMap<String, Map<String, Integer>>();
		Map<String, Map<String, Integer>> OptimizeLogicalDB = new LinkedHashMap<String, Map<String, Integer>>();
		Map<String, Map<String, Integer>> PerformanceGeneral = new LinkedHashMap<String, Map<String, Integer>>();
		Map<String, Map<String, Integer>> PerformanceGeneral_HanaSpecific = new LinkedHashMap<String, Map<String, Integer>>();

		Map<String, Integer> KeepUnnecessaryLoadDB_CodeMaintainability_HanaSpecific = new LinkedHashMap<String, Integer>();
		Map<String, Integer> KeepUnnecessaryLoadDB_OptimizeLogicalDB = new LinkedHashMap<String, Integer>();
		Map<String, Integer> KeepUnnecessaryLoadDB_PerformanceGeneral = new LinkedHashMap<String, Integer>();
		Map<String, Integer> KeepResultSetSmall_PerformanceGeneral = new LinkedHashMap<String, Integer>();
		Map<String, Integer> MinimizeTransferredData_PerformanceGeneral = new LinkedHashMap<String, Integer>();
		Map<String, Integer> MinimizeTransferredData_PerformanceGeneral_HanaSpecific = new LinkedHashMap<String, Integer>();

		// CodeMaintainability
		if ((reqMaster.getAppHSLoad() != null && reqMaster.getAppHSLoad() != 0)
				|| (reqMaster.getAppHSLoadError() != null && reqMaster.getAppHSLoadError() != 0)) {
			KeepUnnecessaryLoadDB_CodeMaintainability_HanaSpecific.put("Number of ABAP objects",
					reqMaster.getAppHSLoad());
			KeepUnnecessaryLoadDB_CodeMaintainability_HanaSpecific.put("Number of findings",
					reqMaster.getAppHSLoadError());
			CodeMaintainability_HanaSpecific.put("Keep unnecessary load away from database",
					KeepUnnecessaryLoadDB_CodeMaintainability_HanaSpecific);
		}

		// OptimizeLogicalDB
		if ((reqMaster.getAppLoadOptimizeDb() != null && reqMaster.getAppLoadOptimizeDb() != 0)
				|| (reqMaster.getAppLoadOptimizeDbError() != null && reqMaster.getAppLoadOptimizeDbError() != 0)) {
			KeepUnnecessaryLoadDB_OptimizeLogicalDB.put("Number of ABAP objects", reqMaster.getAppLoadOptimizeDb());
			KeepUnnecessaryLoadDB_OptimizeLogicalDB.put("Number of findings", reqMaster.getAppLoadOptimizeDbError());
			OptimizeLogicalDB.put("Keep unnecessary load away from database", KeepUnnecessaryLoadDB_OptimizeLogicalDB);
		}

		// PerformanceGeneral
		if ((reqMaster.getAppResSmlPerfGen() != null && reqMaster.getAppResSmlPerfGen() != 0)
				|| (reqMaster.getAppResSmlPerfGenError() != null && reqMaster.getAppResSmlPerfGenError() != 0)) {
			KeepResultSetSmall_PerformanceGeneral.put("Number of ABAP objects", reqMaster.getAppResSmlPerfGen());
			KeepResultSetSmall_PerformanceGeneral.put("Number of findings", reqMaster.getAppResSmlPerfGenError());
			PerformanceGeneral.put("Keep the result set small", KeepResultSetSmall_PerformanceGeneral);
		}

		if ((reqMaster.getAppLoadPerfGen() != null && reqMaster.getAppLoadPerfGen() != 0)
				|| (reqMaster.getAppLoadPerfGenError() != null && reqMaster.getAppLoadPerfGenError() != 0)) {
			KeepUnnecessaryLoadDB_PerformanceGeneral.put("Number of ABAP objects", reqMaster.getAppLoadPerfGen());
			KeepUnnecessaryLoadDB_PerformanceGeneral.put("Number of findings", reqMaster.getAppLoadPerfGenError());
			PerformanceGeneral.put("Keep unnecessary load away from database",
					KeepUnnecessaryLoadDB_PerformanceGeneral);
		}

		if ((reqMaster.getAppMinDataPerfGenError() != null && reqMaster.getAppMinDataPerfGenError() != 0)
				|| (reqMaster.getAppMinDataPerfGenError() != null && reqMaster.getAppMinDataPerfGenError() != 0)) {
			MinimizeTransferredData_PerformanceGeneral.put("Number of ABAP objects", reqMaster.getAppMinDataPerfGen());
			MinimizeTransferredData_PerformanceGeneral.put("Number of findings", reqMaster.getAppMinDataPerfGenError());
			PerformanceGeneral.put("Minimize the amount of transferred data",
					MinimizeTransferredData_PerformanceGeneral);
		}

		// PerformanceGeneral_HanaSpecific
		if ((reqMaster.getAppMinDataHS() != null && reqMaster.getAppMinDataHS() != 0)
				|| (reqMaster.getAppMinDataHSError() != null && reqMaster.getAppMinDataHSError() != 0)) {
			MinimizeTransferredData_PerformanceGeneral_HanaSpecific.put("Number of ABAP objects",
					reqMaster.getAppMinDataHS());
			MinimizeTransferredData_PerformanceGeneral_HanaSpecific.put("Number of findings",
					reqMaster.getAppMinDataHSError());
			PerformanceGeneral_HanaSpecific.put("Minimize the amount of transferred data",
					MinimizeTransferredData_PerformanceGeneral_HanaSpecific);
		}

		if (CodeMaintainability_HanaSpecific.size() > 0) {
			ApplicationLevelOptimizationMap.put("Code maintainability (HANA specific)",
					CodeMaintainability_HanaSpecific);
		}
		if (OptimizeLogicalDB.size() > 0) {
			ApplicationLevelOptimizationMap.put("Optimize the use of Logical Database", OptimizeLogicalDB);
		}
		if (PerformanceGeneral.size() > 0) {
			ApplicationLevelOptimizationMap.put("Performance (general)", PerformanceGeneral);
		}
		if (PerformanceGeneral_HanaSpecific.size() > 0) {
			ApplicationLevelOptimizationMap.put("Performance (HANA specific)", PerformanceGeneral_HanaSpecific);
		}

		return ApplicationLevelOptimizationMap;

	}

	// Slide14
	public Map<String, Map<String, Map<String, Map<String, Integer>>>> getHouseKeepingForHANACounts(long requestId,
			ProcessedRequestDetail reqMaster) {

		Map<String, Map<String, Map<String, Map<String, Integer>>>> HouseKeepingForHanaMap = new LinkedHashMap<String, Map<String, Map<String, Map<String, Integer>>>>();

		Map<String, Map<String, Map<String, Integer>>> CodeMaintainability_HanaSpecific = new LinkedHashMap<String, Map<String, Map<String, Integer>>>();

		Map<String, Map<String, Integer>> StmtIgnoredByHana_Performance_HanaSpecific = new LinkedHashMap<String, Map<String, Integer>>();
		Map<String, Map<String, Integer>> KeepUnnecessaryLoadDB_Performance_HanaSpecific = new LinkedHashMap<String, Map<String, Integer>>();

		Map<String, Integer> hkHsStmtDbHintUsed = new LinkedHashMap<String, Integer>();
		Map<String, Integer> hkHSLoadByTableBuff = new LinkedHashMap<String, Integer>();

		if ((reqMaster.getHkHsStmtDbHintUsed() != null && reqMaster.getHkHsStmtDbHintUsed() != 0)
				|| (reqMaster.getHkHsStmtDbHintUsedError() != null && reqMaster.getHkHsStmtDbHintUsedError() != 0)) {
			hkHsStmtDbHintUsed.put("Number of ABAP objects", reqMaster.getHkHsStmtDbHintUsed());
			hkHsStmtDbHintUsed.put("Number of findings", reqMaster.getHkHsStmtDbHintUsedError());
			StmtIgnoredByHana_Performance_HanaSpecific.put("DB HINTS USED", hkHsStmtDbHintUsed);
		}

		if ((reqMaster.getHkHSLoadByTableBuff() != null && reqMaster.getHkHSLoadByTableBuff() != 0)
				|| (reqMaster.getHkHSLoadByTableBuffError() != null && reqMaster.getHkHSLoadByTableBuffError() != 0)) {
			hkHSLoadByTableBuff.put("Number of ABAP objects", reqMaster.getHkHSLoadByTableBuff());
			hkHSLoadByTableBuff.put("Number of findings", reqMaster.getHkHSLoadByTableBuffError());
			KeepUnnecessaryLoadDB_Performance_HanaSpecific.put("BYPASS TABLE BUFFER", hkHSLoadByTableBuff);
		}

		if (StmtIgnoredByHana_Performance_HanaSpecific.size() > 0) {
			CodeMaintainability_HanaSpecific.put("Statement ignored by HANA",
					StmtIgnoredByHana_Performance_HanaSpecific);
		}
		if (KeepUnnecessaryLoadDB_Performance_HanaSpecific.size() > 0) {
			CodeMaintainability_HanaSpecific.put("Keep unnecessary load away from database",
					KeepUnnecessaryLoadDB_Performance_HanaSpecific);
		}

		if (CodeMaintainability_HanaSpecific.size() > 0) {
			HouseKeepingForHanaMap.put("Code maintainability (HANA specific)", CodeMaintainability_HanaSpecific);
		}

		return HouseKeepingForHanaMap;

	}

	/*
	 * Hierarical Graphs:::::::::::::::::::::::
	 */
	// Slide no. 11-- Hana Graph
	public Map<String, Map<String, Map<String, Map<String, Integer>>>> getMandatoryCorrectionsByIssueErrorAutomationHana(
			long requestId, ProcessedRequestDetail reqMaster) {

		Map<String, Map<String, Map<String, Map<String, Integer>>>> MandatoryCorrections = new LinkedHashMap<String, Map<String, Map<String, Map<String, Integer>>>>();

		Map<String, Map<String, Map<String, Integer>>> ManualRemidiation = new LinkedHashMap<String, Map<String, Map<String, Integer>>>();
		Map<String, Map<String, Map<String, Integer>>> AutomaticRemidiation = new LinkedHashMap<String, Map<String, Map<String, Integer>>>();

		Map<String, Map<String, Integer>> SemanticError_ManualRemidi = new LinkedHashMap<String, Map<String, Integer>>();
		Map<String, Map<String, Integer>> ValidatedSyntaxError_ManualRemidi = new LinkedHashMap<String, Map<String, Integer>>();
		Map<String, Map<String, Integer>> PotentialSyntaxError_ManualRemidi = new LinkedHashMap<String, Map<String, Integer>>();
		Map<String, Map<String, Integer>> HanaSorting_ManualRemidi = new LinkedHashMap<String, Map<String, Integer>>();

		Map<String, Map<String, Integer>> SemanticError_AutomaticRemidi = new LinkedHashMap<String, Map<String, Integer>>();
		Map<String, Map<String, Integer>> ValidatedSyntaxError_AutomaticRemidi = new LinkedHashMap<String, Map<String, Integer>>();
		Map<String, Map<String, Integer>> PotentialSyntaxError_AutomaticRemidi = new LinkedHashMap<String, Map<String, Integer>>();
		Map<String, Map<String, Integer>> HanaSorting_AutomaticRemidi = new LinkedHashMap<String, Map<String, Integer>>();

		Map<String, Integer> manualSemanticPoolCluster = new LinkedHashMap<String, Integer>();
		Map<String, Integer> manualSemanticDBPoolCluster = new LinkedHashMap<String, Integer>();
		Map<String, Integer> manualNativeSQL = new LinkedHashMap<String, Integer>();
		Map<String, Integer> manualDDICFunction = new LinkedHashMap<String, Integer>();
		Map<String, Integer> manualPotentialSyntax_ADBCUsage = new LinkedHashMap<String, Integer>();
		Map<String, Integer> manualHanaSorting_UnsortedInternalIndex = new LinkedHashMap<String, Integer>();
		Map<String, Integer> manualHanaSorting_SelectSinglewithoutKey = new LinkedHashMap<String, Integer>();
		Map<String, Integer> manualHanaSorting_ReadStmtwithBinary = new LinkedHashMap<String, Integer>();
		Map<String, Integer> manualHanaSorting_DeleteAdjacent = new LinkedHashMap<String, Integer>();
		Map<String, Integer> manualHanaSorting_ControlStmt = new LinkedHashMap<String, Integer>();

		Map<String, Integer> automaticSemanticPoolCluster = new LinkedHashMap<String, Integer>();
		Map<String, Integer> automaticSemanticDBPoolCluster = new LinkedHashMap<String, Integer>();
		Map<String, Integer> automaticNativeSQL = new LinkedHashMap<String, Integer>();
		Map<String, Integer> automaticDDICFunction = new LinkedHashMap<String, Integer>();
		Map<String, Integer> automaticPotentialSyntax_ADBCUsage = new LinkedHashMap<String, Integer>();
		Map<String, Integer> automaticHanaSorting_UnsortedInternalIndex = new LinkedHashMap<String, Integer>();
		Map<String, Integer> automaticHanaSorting_UnsortedInternalFM = new LinkedHashMap<String, Integer>();
		Map<String, Integer> automaticHanaSorting_SelectSinglewithoutKey = new LinkedHashMap<String, Integer>();
		Map<String, Integer> automaticHanaSorting_ReadStmtwithBinary = new LinkedHashMap<String, Integer>();
		Map<String, Integer> automaticHanaSorting_DeleteAdjacent = new LinkedHashMap<String, Integer>();
		Map<String, Integer> automaticHanaSorting_ControlStmt = new LinkedHashMap<String, Integer>();

		/*
		 * Manual Remidiation Counts:---
		 */
		// Semantic Error---
		if (reqMaster.getManSemPoolClustAutoNError() != null && reqMaster.getManSemPoolClustAutoNError() != 0) {
			manualSemanticPoolCluster.put("Number of ABAP objects", reqMaster.getManSemPoolClustAutoN());
			manualSemanticPoolCluster.put("Number of findings", reqMaster.getManSemPoolClustAutoNError());
			SemanticError_ManualRemidi.put("Pool/Cluster Table", manualSemanticPoolCluster);
		}

		if (reqMaster.getManSemDbPoolAutoNError() != null && reqMaster.getManSemDbPoolAutoNError() != 0) {
			manualSemanticDBPoolCluster.put("Number of ABAP objects", reqMaster.getManSemDbPoolAutoN());
			manualSemanticDBPoolCluster.put("Number of findings", reqMaster.getManSemDbPoolAutoNError());
			SemanticError_ManualRemidi.put("DB operations on Table pool & Table Cluster", manualSemanticDBPoolCluster);
		}

		// Validated Syntax Error---
		if (reqMaster.getManVSynNsqlAutoNError() != null && reqMaster.getManVSynNsqlAutoNError() != 0) {
			manualNativeSQL.put("Number of ABAP objects", reqMaster.getManVSynNsqlAutoN());
			manualNativeSQL.put("Number of findings", reqMaster.getManVSynNsqlAutoNError());
			ValidatedSyntaxError_ManualRemidi.put("NATIVE SQL CALL", manualNativeSQL);
		}

		if (reqMaster.getManVSynDDICFmlAutoNError() != null && reqMaster.getManVSynDDICFmlAutoNError() != 0) {
			manualDDICFunction.put("Number of ABAP objects", reqMaster.getManVSynDDICFmlAutoN());
			manualDDICFunction.put("Number of findings", reqMaster.getManVSynDDICFmlAutoNError());
			ValidatedSyntaxError_ManualRemidi.put("DDIC FUNCTION MODULE CALL", manualDDICFunction);
		}

		// Potential Syntax Error---
		if (reqMaster.getManVSynAdbcUsAutoNError() != null && reqMaster.getManVSynAdbcUsAutoNError() != 0) {
			manualPotentialSyntax_ADBCUsage.put("Number of ABAP objects", reqMaster.getManVSynAdbcUsAutoN());
			manualPotentialSyntax_ADBCUsage.put("Number of findings", reqMaster.getManVSynAdbcUsAutoNError());
			PotentialSyntaxError_ManualRemidi.put("ADBC USAGE", manualPotentialSyntax_ADBCUsage);
		}

		// Hana Sorting---
		if (reqMaster.getManHSortUnInternalAutoNError() != null && reqMaster.getManHSortUnInternalAutoNError() != 0) {
			manualHanaSorting_UnsortedInternalIndex.put("Number of ABAP objects",
					reqMaster.getManHSortUnInternalAutoN());
			manualHanaSorting_UnsortedInternalIndex.put("Number of findings",
					reqMaster.getManHSortUnInternalAutoNError());
			HanaSorting_ManualRemidi.put("UNSORTED INTERNAL TABLE ACCESSED WITH INDEX",
					manualHanaSorting_UnsortedInternalIndex);
		}

		if (reqMaster.getManHSortSelWKyAutoNError() != null && reqMaster.getManHSortSelWKyAutoNError() != 0) {
			manualHanaSorting_SelectSinglewithoutKey.put("Number of ABAP objects", reqMaster.getManHSortSelWKyAutoN());
			manualHanaSorting_SelectSinglewithoutKey.put("Number of findings", reqMaster.getManHSortSelWKyAutoNError());
			HanaSorting_ManualRemidi.put("Select Single without key fields", manualHanaSorting_SelectSinglewithoutKey);
		}

		if (reqMaster.getManHSortRBWSOAutoNError() != null && reqMaster.getManHSortRBWSOAutoNError() != 0) {
			manualHanaSorting_ReadStmtwithBinary.put("Number of ABAP objects", reqMaster.getManHSortRBWSOAutoN());
			manualHanaSorting_ReadStmtwithBinary.put("Number of findings", reqMaster.getManHSortRBWSOAutoNError());
			HanaSorting_ManualRemidi.put("READ STATEMENT WITH BINARY AND WITHOUT SORTING",
					manualHanaSorting_ReadStmtwithBinary);
		}

		if (reqMaster.getManHSortDelAdjAutoNError() != null && reqMaster.getManHSortDelAdjAutoNError() != 0) {
			manualHanaSorting_DeleteAdjacent.put("Number of ABAP objects", reqMaster.getManHSortDelAdjAutoN());
			manualHanaSorting_DeleteAdjacent.put("Number of findings", reqMaster.getManHSortDelAdjAutoNError());
			HanaSorting_ManualRemidi.put("DELETE ADJACENT DUPLICATES IS USED WITHOUT SORTING",
					manualHanaSorting_DeleteAdjacent);
		}
		if (reqMaster.getManHSortConStmtAutoNError() != null && reqMaster.getManHSortConStmtAutoNError() != 0) {
			manualHanaSorting_ControlStmt.put("Number of ABAP objects", reqMaster.getManHSortConStmtAutoN());
			manualHanaSorting_ControlStmt.put("Number of findings", reqMaster.getManHSortConStmtAutoNError());
			HanaSorting_ManualRemidi.put(
					"Control statement inside loop (Only when loop is using internal table which is not sorted)",
					manualHanaSorting_ControlStmt);
		}

		/*
		 * Automatic Remidiation Counts:---
		 */
		// Semantic Error---
		if (reqMaster.getManSemPoolClustAutoYError() != null && reqMaster.getManSemPoolClustAutoYError() != 0) {
			automaticSemanticPoolCluster.put("Number of ABAP objects", reqMaster.getManSemPoolClustAutoY());
			automaticSemanticPoolCluster.put("Number of findings", reqMaster.getManSemPoolClustAutoYError());
			SemanticError_AutomaticRemidi.put("Pool/Cluster Table", automaticSemanticPoolCluster);
		}

		if (reqMaster.getManSemDbPoolAutoYError() != null && reqMaster.getManSemDbPoolAutoYError() != 0) {
			automaticSemanticDBPoolCluster.put("Number of ABAP objects", reqMaster.getManSemDbPoolAutoY());
			automaticSemanticDBPoolCluster.put("Number of findings", reqMaster.getManSemDbPoolAutoYError());
			SemanticError_AutomaticRemidi.put("DB operations on Table pool & Table Cluster",
					automaticSemanticDBPoolCluster);
		}

		// Validated Syntax Error---
		if (reqMaster.getManVSynNsqlAutoYError() != null && reqMaster.getManVSynNsqlAutoYError() != 0) {
			automaticNativeSQL.put("Number of ABAP objects", reqMaster.getManVSynNsqlAutoY());
			automaticNativeSQL.put("Number of findings", reqMaster.getManVSynNsqlAutoYError());
			ValidatedSyntaxError_AutomaticRemidi.put("NATIVE SQL CALL", automaticNativeSQL);
		}

		if (reqMaster.getManVSynDDICFmlAutoYError() != null && reqMaster.getManVSynDDICFmlAutoYError() != 0) {
			automaticDDICFunction.put("Number of ABAP objects", reqMaster.getManVSynDDICFmlAutoY());
			automaticDDICFunction.put("Number of findings", reqMaster.getManVSynDDICFmlAutoYError());
			ValidatedSyntaxError_AutomaticRemidi.put("DDIC FUNCTION MODULE CALL", automaticDDICFunction);
		}

		// Potential Syntax Error---
		if (reqMaster.getManVSynAdbcUsAutoYError() != null && reqMaster.getManVSynAdbcUsAutoYError() != 0) {
			automaticPotentialSyntax_ADBCUsage.put("Number of ABAP objects", reqMaster.getManVSynAdbcUsAutoY());
			automaticPotentialSyntax_ADBCUsage.put("Number of findings", reqMaster.getManVSynAdbcUsAutoYError());
			PotentialSyntaxError_AutomaticRemidi.put("ADBC USAGE", automaticPotentialSyntax_ADBCUsage);
		}

		// Hana Sorting---
		if (reqMaster.getManUnsortIntTabAccFMAutoYError() != null && reqMaster.getManUnsortIntTabAccFMAutoYError() != 0) {
			automaticHanaSorting_UnsortedInternalIndex.put("Number of ABAP objects",
					reqMaster.getManUnsortIntTabAccFMAutoY());
			automaticHanaSorting_UnsortedInternalIndex.put("Number of findings",
					reqMaster.getManUnsortIntTabAccFMAutoYError());
			HanaSorting_AutomaticRemidi.put("UNSORTED INTERNAL TABLE ACCESSED WITH INDEX",
					automaticHanaSorting_UnsortedInternalIndex);
		}
		
		if (reqMaster.getManHSortUnInternalAutoYError() != null && reqMaster.getManHSortUnInternalAutoYError() != 0) {
			automaticHanaSorting_UnsortedInternalFM.put("Number of ABAP objects",
					reqMaster.getManHSortUnInternalAutoY());
			automaticHanaSorting_UnsortedInternalFM.put("Number of findings",
					reqMaster.getManHSortUnInternalAutoYError());
			HanaSorting_AutomaticRemidi.put("UNSORTED INTERNAL TABLE ACCESSED WITH FM",
					automaticHanaSorting_UnsortedInternalFM);
		}
		
		if (reqMaster.getManHSortSelWKyAutoYError() != null && reqMaster.getManHSortSelWKyAutoYError() != 0) {
			automaticHanaSorting_SelectSinglewithoutKey.put("Number of ABAP objects",
					reqMaster.getManHSortSelWKyAutoY());
			automaticHanaSorting_SelectSinglewithoutKey.put("Number of findings",
					reqMaster.getManHSortSelWKyAutoYError());
			HanaSorting_AutomaticRemidi.put("Select Single without key fields",
					automaticHanaSorting_SelectSinglewithoutKey);
		}

		if (reqMaster.getManHSortRBWSOAutoYError() != null && reqMaster.getManHSortRBWSOAutoYError() != 0) {
			automaticHanaSorting_ReadStmtwithBinary.put("Number of ABAP objects", reqMaster.getManHSortRBWSOAutoN());
			automaticHanaSorting_ReadStmtwithBinary.put("Number of findings", reqMaster.getManHSortRBWSOAutoNError());
			HanaSorting_AutomaticRemidi.put("READ STATEMENT WITH BINARY AND WITHOUT SORTING",
					automaticHanaSorting_ReadStmtwithBinary);
		}

		if (reqMaster.getManHSortDelAdjAutoYError() != null && reqMaster.getManHSortDelAdjAutoYError() != 0) {
			automaticHanaSorting_DeleteAdjacent.put("Number of ABAP objects", reqMaster.getManHSortDelAdjAutoY());
			automaticHanaSorting_DeleteAdjacent.put("Number of findings", reqMaster.getManHSortDelAdjAutoYError());
			HanaSorting_AutomaticRemidi.put("DELETE ADJACENT DUPLICATES IS USED WITHOUT SORTING",
					automaticHanaSorting_DeleteAdjacent);
		}
		if (reqMaster.getManHSortConStmtAutoYError() != null && reqMaster.getManHSortConStmtAutoYError() != 0) {
			automaticHanaSorting_ControlStmt.put("Number of ABAP objects", reqMaster.getManHSortConStmtAutoY());
			automaticHanaSorting_ControlStmt.put("Number of findings", reqMaster.getManHSortConStmtAutoYError());
			HanaSorting_AutomaticRemidi.put(
					"Control statement inside loop (Only when loop is using internal table which is not sorted)",
					automaticHanaSorting_ControlStmt);
		}

		// Manual Remidiation Maps---
		if (SemanticError_ManualRemidi.size() > 0) {
			ManualRemidiation.put("Semantic error", SemanticError_ManualRemidi);
		}
		if (ValidatedSyntaxError_ManualRemidi.size() > 0) {
			ManualRemidiation.put("Validated syntax error", ValidatedSyntaxError_ManualRemidi);
		}

		if (PotentialSyntaxError_ManualRemidi.size() > 0) {
			ManualRemidiation.put("Potential syntax error", PotentialSyntaxError_ManualRemidi);
		}

		if (HanaSorting_ManualRemidi.size() > 0) {
			ManualRemidiation.put("HANA sorting", HanaSorting_ManualRemidi);
		}

		// Automatic Remidiation Maps---
		if (SemanticError_AutomaticRemidi.size() > 0) {
			AutomaticRemidiation.put("Semantic error", SemanticError_AutomaticRemidi);
		}
		if (ValidatedSyntaxError_AutomaticRemidi.size() > 0) {
			AutomaticRemidiation.put("Validated syntax error", ValidatedSyntaxError_AutomaticRemidi);
		}
		if (PotentialSyntaxError_AutomaticRemidi.size() > 0) {
			AutomaticRemidiation.put("Potential syntax error", PotentialSyntaxError_AutomaticRemidi);
		}
		if (HanaSorting_AutomaticRemidi.size() > 0) {
			AutomaticRemidiation.put("HANA sorting", HanaSorting_AutomaticRemidi);
		}

		// Mandatory Corrections Map---
		if (ManualRemidiation.size() > 0) {
			MandatoryCorrections.put("Manual Remediation", ManualRemidiation);
		}
		if (AutomaticRemidiation.size() > 0) {
			MandatoryCorrections.put("Automatic Remediation", AutomaticRemidiation);
		}

		return MandatoryCorrections;

	}

	// Slide 19
	public LinkedHashMap<String, Integer> getFunctionalAreaObjectCount(long requestId,
			ProcessedRequestDetail reqMaster) {
		final LinkedHashMap<String, Integer> resultMap = new LinkedHashMap<String, Integer>();

		if (reqMaster.getAcFinanceIntlTrade() != null && reqMaster.getAcFinanceIntlTrade() != 0) {
			resultMap.put("Financials-International Trade", reqMaster.getAcFinanceIntlTrade());
		}

		if ((reqMaster.getAcFinanceMisc() != null && reqMaster.getAcFinanceMisc() != 0)) {
			resultMap.put("Financials-Miscellaneous", reqMaster.getAcFinanceMisc());
		}

		if (reqMaster.getAcFinanceCntrl() != null && reqMaster.getAcFinanceCntrl() != 0) {
			resultMap.put("Financials-Controlling", reqMaster.getAcFinanceCntrl());
		}

		if (reqMaster.getAcMasterData() != null && reqMaster.getAcMasterData() != 0) {
			resultMap.put("Master-Data", reqMaster.getAcMasterData());
		}

		if (reqMaster.getAcIndustryRetail() != null && reqMaster.getAcIndustryRetail() != 0) {
			resultMap.put("Industry retail & fashion", reqMaster.getAcIndustryRetail());
		}

		if ((reqMaster.getAcLogisticsMMIM() != null && reqMaster.getAcLogisticsMMIM() != 0)) {
			resultMap.put("Logistics - MM-IM", reqMaster.getAcLogisticsMMIM());
		}

		if (reqMaster.getAcProcurement() != null && reqMaster.getAcProcurement() != 0) {
			resultMap.put("Procurement", reqMaster.getAcProcurement());
		}

		if ((reqMaster.getAcLogisticsEHS() != null && reqMaster.getAcLogisticsEHS() != 0)) {
			resultMap.put("Logistics - Environment, Health & Safety (EHS)", reqMaster.getAcLogisticsEHS());
		}

		if (reqMaster.getAcSalesDistribution() != null && reqMaster.getAcSalesDistribution() != 0) {
			resultMap.put("Sales & Distribution", reqMaster.getAcSalesDistribution());
		}

		if (reqMaster.getAcIndustryBeverage() != null && reqMaster.getAcIndustryBeverage() != 0) {
			resultMap.put("Industry Beverage", reqMaster.getAcIndustryBeverage());
		}

		if (reqMaster.getAcIndustryDimpEco() != null && reqMaster.getAcIndustryDimpEco() != 0) {
			resultMap.put("Industry DIMP - EC&O", reqMaster.getAcIndustryDimpEco());
		}

		if ((reqMaster.getAcFinanceGeneral() != null && reqMaster.getAcFinanceGeneral() != 0)) {
			resultMap.put("Finance-General", reqMaster.getAcFinanceGeneral());
		}

		if (reqMaster.getAcLogisticsPP() != null && reqMaster.getAcLogisticsPP() != 0) {
			resultMap.put("Logistics - PP", reqMaster.getAcLogisticsPP());
		}

		if ((reqMaster.getAcIndustryPubSec() != null && reqMaster.getAcIndustryPubSec() != 0)) {
			resultMap.put("Industry Public Sector", reqMaster.getAcIndustryPubSec());
		}

		if (reqMaster.getAcIndustryDimpHt() != null && reqMaster.getAcIndustryDimpHt() != 0) {
			resultMap.put("Industry DIMP - High Tec", reqMaster.getAcIndustryDimpHt());
		}

		if ((reqMaster.getAcIndustryCross() != null && reqMaster.getAcIndustryCross() != 0)) {
			resultMap.put("Industry - Cross", reqMaster.getAcIndustryCross());
		}

		if (reqMaster.getAcIndustryAeroDef() != null && reqMaster.getAcIndustryAeroDef() != 0) {
			resultMap.put("Industry DIMP - Aerospace & Defense", reqMaster.getAcIndustryAeroDef());
		}

		if (reqMaster.getAcLogisticsPm() != null && reqMaster.getAcLogisticsPm() != 0) {
			resultMap.put("Logistics - PM", reqMaster.getAcLogisticsPm());
		}

		if (reqMaster.getAcLogisticsPlm() != null && reqMaster.getAcLogisticsPlm() != 0) {
			resultMap.put("Logistics - PLM", reqMaster.getAcLogisticsPlm());
		}

		if ((reqMaster.getAcIndustryAuto() != null && reqMaster.getAcIndustryAuto() != 0)) {
			resultMap.put("Industry DIMP - Automotive", reqMaster.getAcIndustryAuto());
		}

		if (reqMaster.getAcMiscellaneous() != null && reqMaster.getAcMiscellaneous() != 0) {
			resultMap.put("Miscellaneous", reqMaster.getAcMiscellaneous());
		}

		if ((reqMaster.getAcMM() != null && reqMaster.getAcMM() != 0)) {
			resultMap.put("MM", reqMaster.getAcMM());
		}

		if (reqMaster.getAcLogisticsPS() != null && reqMaster.getAcLogisticsPS() != 0) {
			resultMap.put("Logistics - PS", reqMaster.getAcLogisticsPS());
		}

		if ((reqMaster.getAcLogisticsATP() != null && reqMaster.getAcLogisticsATP() != 0)) {
			resultMap.put("Logistics - ATP", reqMaster.getAcLogisticsATP());
		}

		if (reqMaster.getAcIndustryMedia() != null && reqMaster.getAcIndustryMedia() != 0) {
			resultMap.put("Industry-Media Product Master", reqMaster.getAcIndustryMedia());
		}

		if ((reqMaster.getAcFinAssetAccount() != null && reqMaster.getAcFinAssetAccount() != 0)) {
			resultMap.put("Financials - Asset Accounting", reqMaster.getAcFinAssetAccount());
		}

		if (reqMaster.getAcCrossTopics() != null && reqMaster.getAcCrossTopics() != 0) {
			resultMap.put("Cross Topics", reqMaster.getAcCrossTopics());
		}

		if (reqMaster.getAcBatchMasterData() != null && reqMaster.getAcBatchMasterData() != 0) {
			resultMap.put("Batch Master Data", reqMaster.getAcBatchMasterData());
		}

		if (reqMaster.getAcLogisticsPss() != null && reqMaster.getAcLogisticsPss() != 0) {
			resultMap.put("Logistics - PSS", reqMaster.getAcLogisticsPss());
		}

		if ((reqMaster.getAcPortfolioPm() != null && reqMaster.getAcPortfolioPm() != 0)) {
			resultMap.put("Portfolio and Project Management (PPM)", reqMaster.getAcPortfolioPm());
		}

		if (reqMaster.getAcFinGeneralLedger() != null && reqMaster.getAcFinGeneralLedger() != 0) {
			resultMap.put("Financials - General Ledger", reqMaster.getAcFinGeneralLedger());
		}

		if ((reqMaster.getAcIndustryUtil() != null && reqMaster.getAcIndustryUtil() != 0)) {
			resultMap.put("Industry Utilities", reqMaster.getAcIndustryUtil());
		}

		if (reqMaster.getAcGlobalLogistic() != null && reqMaster.getAcGlobalLogistic() != 0) {
			resultMap.put("Globalization Logistics", reqMaster.getAcGlobalLogistic());
		}

		if ((reqMaster.getAcIndustryOil() != null && reqMaster.getAcIndustryOil() != 0)) {
			resultMap.put("Industry Oil", reqMaster.getAcIndustryOil());
		}

		if (reqMaster.getAcLogisticQm() != null && reqMaster.getAcLogisticQm() != 0) {
			resultMap.put("Logistics - QM", reqMaster.getAcLogisticQm());
		}

		if ((reqMaster.getAcFinAcctPayRecieve() != null && reqMaster.getAcFinAcctPayRecieve() != 0)) {
			resultMap.put("Financials - Accounts Payable/Accounts Receivable", reqMaster.getAcFinAcctPayRecieve());
		}

		if (reqMaster.getAcFinTreasury() != null && reqMaster.getAcFinTreasury() != 0) {
			resultMap.put("Financials - Treasury and Risk Management", reqMaster.getAcFinTreasury());
		}

		if (reqMaster.getAcLogisticsGt() != null && reqMaster.getAcLogisticsGt() != 0) {
			resultMap.put("Logistics - GT", reqMaster.getAcLogisticsGt());
		}

		if (reqMaster.getAcHumanResources() != null && reqMaster.getAcHumanResources() != 0) {
			resultMap.put("Human Resources", reqMaster.getAcHumanResources());
		}

		return resultMap;
	}

	// Slide 21
	public LinkedHashMap<String, Integer> getSimplificationCategoryObjectCount(long requestId,
			ProcessedRequestDetail reqMaster) {
		final LinkedHashMap<String, Integer> resultMap = new LinkedHashMap<String, Integer>();

		if (reqMaster.getSimpCategoryCOEF() != null && reqMaster.getSimpCategoryCOEF() != 0) {
			resultMap.put("Change of existing functionality", reqMaster.getSimpCategoryCOEF());
		}

		if ((reqMaster.getSimpCategoryFEA() != null && reqMaster.getSimpCategoryFEA() != 0)) {
			resultMap.put("Functionality not available in SAP S/4HANA (functional equivalent available)",
					reqMaster.getSimpCategoryFEA());
		}

		if (reqMaster.getSimpCategoryFENA() != null && reqMaster.getSimpCategoryFENA() != 0) {
			resultMap.put("Functionality not available in SAP S/4HANA (functional equivalent not available)",
					reqMaster.getSimpCategoryFENA());
		}

		if (reqMaster.getSimpCategoryNsfFEA() != null && reqMaster.getSimpCategoryNsfFEA() != 0) {
			resultMap.put("Non-Strategic-function (functional equivalent available)",
					reqMaster.getSimpCategoryNsfFEA());
		}

		if (reqMaster.getSimpCategoryNsfFENA() != null && reqMaster.getSimpCategoryNsfFENA() != 0) {
			resultMap.put("Non-Strategic-function (functional equivalent not available)",
					reqMaster.getSimpCategoryNsfFENA());
		}

		if ((reqMaster.getSimpCategoryNewS4Fun() != null && reqMaster.getSimpCategoryNewS4Fun() != 0)) {
			resultMap.put("New S4 Functionality", reqMaster.getSimpCategoryNewS4Fun());
		}

		return resultMap;

	}

	// Slide 22
	public Map<String, Map<String, Integer>> getRemediationCategoryCounts(long requestId,
			ProcessedRequestDetail reqMaster) {

		Map<String, Map<String, Integer>> RemediationCategoryMap = new LinkedHashMap<String, Map<String, Integer>>();

		Map<String, Integer> Mandatory = new LinkedHashMap<String, Integer>();
		Map<String, Integer> Optional = new LinkedHashMap<String, Integer>();

		// Mandatory Category
		if (reqMaster.getManCompHigh() != null && reqMaster.getManCompHigh() != 0) {
			Mandatory.put("HIGH", reqMaster.getManCompHigh());
		}

		if (reqMaster.getManCompMedium() != null && reqMaster.getManCompMedium() != 0) {
			Mandatory.put("MEDIUM", reqMaster.getManCompMedium());
		}

		if (reqMaster.getManCompLow() != null && reqMaster.getManCompLow() != 0) {
			Mandatory.put("LOW", reqMaster.getManCompLow());
		}

		if ((reqMaster.getManCompTbd() != null && reqMaster.getManCompTbd() != 0)) {
			Mandatory.put("TBD", reqMaster.getManCompTbd());
		}

		// Optional Category
		if (reqMaster.getOptCompMedium() != null && reqMaster.getOptCompMedium() != 0) {
			Optional.put("MEDIUM", reqMaster.getOptCompMedium());
		}

		if (reqMaster.getOptCompLow() != null && reqMaster.getOptCompLow() != 0) {
			Optional.put("LOW", reqMaster.getOptCompLow());
		}

		if ((reqMaster.getOptCompVeryLow() != null && reqMaster.getOptCompVeryLow() != 0)) {
			Optional.put("VERY LOW", reqMaster.getOptCompVeryLow());
		}

		if (Mandatory.size() > 0) {
			RemediationCategoryMap.put("Mandatory", Mandatory);
		}
		if (Optional.size() > 0) {
			RemediationCategoryMap.put("Optional", Optional);
		}
		return RemediationCategoryMap;

	}

	// Slide 20.1
	public Map<String, Map<String, Integer>> getRemidiIssueCatCount(long requestId, ProcessedRequestDetail reqMaster) {

		Map<String, Map<String, Integer>> RemidiIssueCatMap = new LinkedHashMap<String, Map<String, Integer>>();

		Map<String, Integer> Mandatory = new LinkedHashMap<String, Integer>();
		Map<String, Integer> Optional = new LinkedHashMap<String, Integer>();

		// Mandatory Category
		if (reqMaster.getManCustomCd() != null && reqMaster.getManCustomCd() != 0) {
			Mandatory.put("Custom Code Adaption", reqMaster.getManCustomCd());
		}

		if (reqMaster.getManDataElement() != null && reqMaster.getManDataElement() != 0) {
			Mandatory.put("Data Element Length Extension", reqMaster.getManDataElement());
		}

		if (reqMaster.getManStatusTable() != null && reqMaster.getManStatusTable() != 0) {
			Mandatory.put("Elimination of Status Tables", reqMaster.getManStatusTable());
		}

		if ((reqMaster.getManMatLength() != null && reqMaster.getManMatLength() != 0)) {
			Mandatory.put("Material Length Extension", reqMaster.getManMatLength());
		}

		if (reqMaster.getManDataModel() != null && reqMaster.getManDataModel() != 0) {
			Mandatory.put("New Data Model", reqMaster.getManDataModel());
		}

		if (reqMaster.getManNewS4Fun() != null && reqMaster.getManNewS4Fun() != 0) {
			Mandatory.put("New S4 Functionality", reqMaster.getManNewS4Fun());
		}

		if (reqMaster.getManNewTrans() != null && reqMaster.getManNewTrans() != 0) {
			Mandatory.put("New Transaction", reqMaster.getManNewTrans());
		}

		if ((reqMaster.getManRemOrphan() != null && reqMaster.getManRemOrphan() != 0)) {
			Mandatory.put("Removal of Orphened Objects", reqMaster.getManRemOrphan());
		}

		if (reqMaster.getManRetiredFun() != null && reqMaster.getManRetiredFun() != 0) {
			Mandatory.put("Retired Functionality", reqMaster.getManRetiredFun());
		}

		if (reqMaster.getManSimpExistTab() != null && reqMaster.getManSimpExistTab() != 0) {
			Mandatory.put("Simplification of Existing Table", reqMaster.getManSimpExistTab());
		}

		if (reqMaster.getManRepNewFun() != null && reqMaster.getManRepNewFun() != 0) {
			Mandatory.put("Replaced by new functionality", reqMaster.getManRepNewFun());
		}

		if ((reqMaster.getManFunEqvAvl() != null && reqMaster.getManFunEqvAvl() != 0)) {
			Mandatory.put("Functional equivalent available", reqMaster.getManFunEqvAvl());
		}

		if (reqMaster.getManAdaptCustCd() != null && reqMaster.getManAdaptCustCd() != 0) {
			Mandatory.put("Adapt Customer Coding", reqMaster.getManAdaptCustCd());
		}

		if (reqMaster.getManCustFields() != null && reqMaster.getManCustFields() != 0) {
			Mandatory.put("Custom Fields in SAP Tables", reqMaster.getManCustFields());
		}

		if (reqMaster.getManObsTrans() != null && reqMaster.getManObsTrans() != 0) {
			Mandatory.put("Obsolete Transaction", reqMaster.getManObsTrans());
		}

		if ((reqMaster.getManOutputMgmt() != null && reqMaster.getManOutputMgmt() != 0)) {
			Mandatory.put("Output Management", reqMaster.getManOutputMgmt());
		}

		// Optional Category
		if (reqMaster.getOptCustomCd() != null && reqMaster.getOptCustomCd() != 0) {
			Optional.put("Custom Code Adaption", reqMaster.getOptCustomCd());
		}

		if (reqMaster.getOptDataElement() != null && reqMaster.getOptDataElement() != 0) {
			Optional.put("Data Element Length Extension", reqMaster.getOptDataElement());
		}

		if (reqMaster.getOptStatusTable() != null && reqMaster.getOptStatusTable() != 0) {
			Optional.put("Elimination of Status Tables", reqMaster.getOptStatusTable());
		}

		if ((reqMaster.getOptMatLength() != null && reqMaster.getOptMatLength() != 0)) {
			Optional.put("Material Length Extension", reqMaster.getOptMatLength());
		}

		if (reqMaster.getOptDataModel() != null && reqMaster.getOptDataModel() != 0) {
			Optional.put("New Data Model", reqMaster.getOptDataModel());
		}

		if (reqMaster.getOptNewS4Fun() != null && reqMaster.getOptNewS4Fun() != 0) {
			Optional.put("New S4 Functionality", reqMaster.getOptNewS4Fun());
		}

		if (reqMaster.getOptNewTrans() != null && reqMaster.getOptNewTrans() != 0) {
			Optional.put("New Transaction", reqMaster.getOptNewTrans());
		}

		if ((reqMaster.getOptRemOrphan() != null && reqMaster.getOptRemOrphan() != 0)) {
			Optional.put("Removal of Orphened Objects", reqMaster.getOptRemOrphan());
		}

		if (reqMaster.getOptRetiredFun() != null && reqMaster.getOptRetiredFun() != 0) {
			Optional.put("Retired Functionality", reqMaster.getOptRetiredFun());
		}

		if (reqMaster.getOptSimpExistTab() != null && reqMaster.getOptSimpExistTab() != 0) {
			Optional.put("Simplification of Existing Table", reqMaster.getOptSimpExistTab());
		}

		if (reqMaster.getOptRepNewFun() != null && reqMaster.getOptRepNewFun() != 0) {
			Optional.put("Replaced by new functionality", reqMaster.getOptRepNewFun());
		}

		if ((reqMaster.getOptFunEqvAvl() != null && reqMaster.getOptFunEqvAvl() != 0)) {
			Optional.put("Functional equivalent available", reqMaster.getOptFunEqvAvl());
		}

		if (reqMaster.getOptAdaptCustCd() != null && reqMaster.getOptAdaptCustCd() != 0) {
			Optional.put("Adapt Customer Coding", reqMaster.getOptAdaptCustCd());
		}

		if (reqMaster.getOptCustFields() != null && reqMaster.getOptCustFields() != 0) {
			Optional.put("Custom Fields in SAP Tables", reqMaster.getOptCustFields());
		}

		if (reqMaster.getOptObsTrans() != null && reqMaster.getOptObsTrans() != 0) {
			Optional.put("Obsolete Transaction", reqMaster.getOptObsTrans());
		}

		if ((reqMaster.getOptOutputMgmt() != null && reqMaster.getOptOutputMgmt() != 0)) {
			Optional.put("Output Management", reqMaster.getOptOutputMgmt());
		}

		if (Mandatory.size() > 0) {
			RemidiIssueCatMap.put("MANDATORY", Mandatory);
		}
		if (Optional.size() > 0) {
			RemidiIssueCatMap.put("OPTIONAL", Optional);
		}

		return RemidiIssueCatMap;

	}

	// Slide 20.2
	public Map<String, Map<String, Integer>> getRemidiIssueCatErrorCount(long requestId,
			ProcessedRequestDetail reqMaster) {

		Map<String, Map<String, Integer>> RemidiIssueCatErrorMap = new LinkedHashMap<String, Map<String, Integer>>();

		Map<String, Integer> Mandatory = new LinkedHashMap<String, Integer>();
		Map<String, Integer> Optional = new LinkedHashMap<String, Integer>();

		// Mandatory Category
		if (reqMaster.getManCustomCdError() != null && reqMaster.getManCustomCdError() != 0) {
			Mandatory.put("Custom Code Adaption", reqMaster.getManCustomCdError());
		}

		if (reqMaster.getManDataElementError() != null && reqMaster.getManDataElementError() != 0) {
			Mandatory.put("Data Element Length Extension", reqMaster.getManDataElementError());
		}

		if (reqMaster.getManStatusTableError() != null && reqMaster.getManStatusTableError() != 0) {
			Mandatory.put("Elimination of Status Tables", reqMaster.getManStatusTableError());
		}

		if ((reqMaster.getManMatLengthError() != null && reqMaster.getManMatLengthError() != 0)) {
			Mandatory.put("Material Length Extension", reqMaster.getManMatLengthError());
		}

		if (reqMaster.getManDataModelError() != null && reqMaster.getManDataModelError() != 0) {
			Mandatory.put("New Data Model", reqMaster.getManDataModelError());
		}

		if (reqMaster.getManNewS4FunError() != null && reqMaster.getManNewS4FunError() != 0) {
			Mandatory.put("New S4 Functionality", reqMaster.getManNewS4FunError());
		}

		if (reqMaster.getManNewTransError() != null && reqMaster.getManNewTransError() != 0) {
			Mandatory.put("New Transaction", reqMaster.getManNewTransError());
		}

		if ((reqMaster.getManRemOrphanError() != null && reqMaster.getManRemOrphanError() != 0)) {
			Mandatory.put("Removal of Orphened Objects", reqMaster.getManRemOrphanError());
		}

		if (reqMaster.getManRetiredFunError() != null && reqMaster.getManRetiredFunError() != 0) {
			Mandatory.put("Retired Functionality", reqMaster.getManRetiredFunError());
		}

		if (reqMaster.getManSimpExistTabError() != null && reqMaster.getManSimpExistTabError() != 0) {
			Mandatory.put("Simplification of Existing Table", reqMaster.getManSimpExistTabError());
		}

		if (reqMaster.getManRepNewFunError() != null && reqMaster.getManRepNewFunError() != 0) {
			Mandatory.put("Replaced by new functionality", reqMaster.getManRepNewFunError());
		}

		if ((reqMaster.getManFunEqvAvlError() != null && reqMaster.getManFunEqvAvlError() != 0)) {
			Mandatory.put("Functional equivalent available", reqMaster.getManFunEqvAvlError());
		}

		if (reqMaster.getManAdaptCustCdError() != null && reqMaster.getManAdaptCustCdError() != 0) {
			Mandatory.put("Adapt Customer Coding", reqMaster.getManAdaptCustCdError());
		}

		if (reqMaster.getManCustFieldsError() != null && reqMaster.getManCustFieldsError() != 0) {
			Mandatory.put("Custom Fields in SAP Tables", reqMaster.getManCustFieldsError());
		}

		if (reqMaster.getManObsTransError() != null && reqMaster.getManObsTransError() != 0) {
			Mandatory.put("Obsolete Transaction", reqMaster.getManObsTransError());
		}

		if ((reqMaster.getManOutputMgmtError() != null && reqMaster.getManOutputMgmtError() != 0)) {
			Mandatory.put("Output Management", reqMaster.getManOutputMgmtError());
		}

		// Optional Category
		if (reqMaster.getOptCustomCdError() != null && reqMaster.getOptCustomCdError() != 0) {
			Optional.put("Custom Code Adaption", reqMaster.getOptCustomCdError());
		}

		if (reqMaster.getOptDataElementError() != null && reqMaster.getOptDataElementError() != 0) {
			Optional.put("Data Element Length Extension", reqMaster.getOptDataElementError());
		}

		if (reqMaster.getOptStatusTableError() != null && reqMaster.getOptStatusTableError() != 0) {
			Optional.put("Elimination of Status Tables", reqMaster.getOptStatusTableError());
		}

		if ((reqMaster.getOptMatLengthError() != null && reqMaster.getOptMatLengthError() != 0)) {
			Optional.put("Material Length Extension", reqMaster.getOptMatLengthError());
		}

		if (reqMaster.getOptDataModelError() != null && reqMaster.getOptDataModelError() != 0) {
			Optional.put("New Data Model", reqMaster.getOptDataModelError());
		}

		if (reqMaster.getOptNewS4FunError() != null && reqMaster.getOptNewS4FunError() != 0) {
			Optional.put("New S4 Functionality", reqMaster.getOptNewS4FunError());
		}

		if (reqMaster.getOptNewTransError() != null && reqMaster.getOptNewTransError() != 0) {
			Optional.put("New Transaction", reqMaster.getOptNewTransError());
		}

		if ((reqMaster.getOptRemOrphanError() != null && reqMaster.getOptRemOrphanError() != 0)) {
			Optional.put("Removal of Orphened Objects", reqMaster.getOptRemOrphanError());
		}

		if (reqMaster.getOptRetiredFunError() != null && reqMaster.getOptRetiredFunError() != 0) {
			Optional.put("Retired Functionality", reqMaster.getOptRetiredFunError());
		}

		if (reqMaster.getOptSimpExistTabError() != null && reqMaster.getOptSimpExistTabError() != 0) {
			Optional.put("Simplification of Existing Table", reqMaster.getOptSimpExistTabError());
		}

		if (reqMaster.getOptRepNewFunError() != null && reqMaster.getOptRepNewFunError() != 0) {
			Optional.put("Replaced by new functionality", reqMaster.getOptRepNewFunError());
		}

		if ((reqMaster.getOptFunEqvAvlError() != null && reqMaster.getOptFunEqvAvlError() != 0)) {
			Optional.put("Functional equivalent available", reqMaster.getOptFunEqvAvlError());
		}

		if (reqMaster.getOptAdaptCustCdError() != null && reqMaster.getOptAdaptCustCdError() != 0) {
			Optional.put("Adapt Customer Coding", reqMaster.getOptAdaptCustCdError());
		}

		if (reqMaster.getOptCustFieldsError() != null && reqMaster.getOptCustFieldsError() != 0) {
			Optional.put("Custom Fields in SAP Tables", reqMaster.getOptCustFieldsError());
		}

		if (reqMaster.getOptObsTransError() != null && reqMaster.getOptObsTransError() != 0) {
			Optional.put("Obsolete Transaction", reqMaster.getOptObsTransError());
		}

		if ((reqMaster.getOptOutputMgmtError() != null && reqMaster.getOptOutputMgmtError() != 0)) {
			Optional.put("Output Management", reqMaster.getOptOutputMgmtError());
		}

		if (Mandatory.size() > 0) {
			RemidiIssueCatErrorMap.put("MANDATORY", Mandatory);
		}
		if (Optional.size() > 0) {
			RemidiIssueCatErrorMap.put("OPTIONAL", Optional);
		}

		return RemidiIssueCatErrorMap;
	}

	public LinkedHashMap<String, Integer> getTestingScopeProcessCount(long requestId, TestingScope reqMaster) throws Exception {
		final LinkedHashMap<String, Integer> resultMap = new LinkedHashMap<String, Integer>();
		try {
			if (reqMaster.getProcess_count() != null && ! (reqMaster.getProcess_count().equalsIgnoreCase(""))) {
				String processCount = reqMaster.getProcessObjectcount();
				String[] processPlusCountSplit = processCount.split("\\|");
			
				for (String processPlusCountSplitData : processPlusCountSplit) {
					String[] CountSplit = processPlusCountSplitData.split("\\:");
	
					resultMap.put(CountSplit[0], Integer.parseInt(CountSplit[1]));
				}	
			} 
			else {
				resultMap.put("Empty", 0);
			}
		} catch(Exception e) {
			logger.error("Error !!! " + e);
			throw new Exception(); 
		}
	
		return resultMap;
	}
	
	public HashMap<String, Integer> getUniqueCustomAndStandard(long requestId, TestingScope reqMaster) throws Exception {
		final HashMap<String, Integer> resultMap = new HashMap<>();
		try {
			String uniqueCustomAndStandardCount = reqMaster.getUniqueCustomAndStandardTransactionsCntMap();
			String[] uniqueCustomAndStandardSplit = uniqueCustomAndStandardCount.split("\\|");
			
			for (String uniqueCustomAndStandardSplitData : uniqueCustomAndStandardSplit) {
				String[] countSplit = uniqueCustomAndStandardSplitData.split("\\:");

				resultMap.put(countSplit[0], Integer.parseInt(countSplit[1]));
			}
		} catch(Exception e) {
			logger.error("Error !!! " + e);
			throw new Exception(); 
		}
		
		return resultMap;
	}

	public LinkedHashMap<String, String> getTestingScopeProcessMaster(long requestId, TestingScope reqMaster) throws Exception {
		final LinkedHashMap<String, String> resultMap = new LinkedHashMap<String, String>();
		try {
			if (reqMaster.getProcess_count() != null && ! (reqMaster.getProcess_count().equalsIgnoreCase(""))) {
				String processCount = reqMaster.getProcessMasterMap();
				String[] processPlusCountSplit = processCount.split("\\|");
			
				for (String processPlusCountSplitData : processPlusCountSplit) {
					String[] CountSplit = processPlusCountSplitData.split("\\:");
					if(CountSplit.length == 2) {	
					resultMap.put(CountSplit[0], CountSplit[1]);
					} else {
						resultMap.put(CountSplit[0], "");
					}
				}
			} else {
				resultMap.put("Empty", "Empty");
			}
		} catch(Exception e) {
			logger.error("Error !!! " + e);
			throw new Exception(); 
		}
		return resultMap;
	}
	
	public LinkedHashMap<String, Integer> getTestingScopePercentageProcessCount(long requestId,
			TestingScope reqMaster) {
		final LinkedHashMap<String, Integer> resultMap = new LinkedHashMap<String, Integer>();
		if (reqMaster.getProcess_count() != null) {
			String processCount = reqMaster.getProcess_count();
			String[] processPlusCountSplit = processCount.split("\\|");
			int totalCount = 0;
			for (String processPlusCountSplitData : processPlusCountSplit) {
				String[] CountSplit = processPlusCountSplitData.split("\\:");

				totalCount = Integer.parseInt(CountSplit[1]);
			}
			for (String processPlusCountSplitData : processPlusCountSplit) {
				String[] CountSplit = processPlusCountSplitData.split("\\:");

				resultMap.put(CountSplit[0], ((Integer.parseInt(CountSplit[1]) * 100) / totalCount));
			}
		} else {
			resultMap.put("Empty", 0);
		}
		return resultMap;
	}

	public LinkedHashMap<String, Integer> getTestingScopeObjectCount(long requestId, TestingScope reqMaster) {
		final LinkedHashMap<String, Integer> resultMap = new LinkedHashMap<String, Integer>();

		if (reqMaster.getProcess_count() != null) {
			String objectCount = reqMaster.getObject_count();
			String[] objectPlusCountSplit = objectCount.split("\\|");
			for (String objectPlusCountSplitData : objectPlusCountSplit) {
				String[] countSplit = objectPlusCountSplitData.split("\\:");

				resultMap.put(countSplit[0], Integer.parseInt(countSplit[1]));
			}
		} else {
			resultMap.put("Empty", 0);
		}
		return resultMap;
	}

	// UI5 Graphs
	public Map<String, Map<String, Long>> getTotalAPICounts(long requestID, UI5GraphCounts uI5GraphCounts) {
		Map<String, Map<String, Long>> totalApiCountMap = new LinkedHashMap<String, Map<String, Long>>();

		Map<String, Long> TotalApi = new LinkedHashMap<String, Long>();

		// Total APi Counts
		if ((uI5GraphCounts.getComptibleTotalApiCounts() != null)
				&& (uI5GraphCounts.getComptibleTotalApiCounts() != 0)) {
			TotalApi.put("Source code is compatible with target UI5 library",
					uI5GraphCounts.getComptibleTotalApiCounts());
		}

		if ((uI5GraphCounts.getSrcCodeChangesTotalApiCounts() != null)
				&& (uI5GraphCounts.getSrcCodeChangesTotalApiCounts() != 0)) {
			TotalApi.put("Source code needs changes to be compatible with target UI5 library",
					uI5GraphCounts.getSrcCodeChangesTotalApiCounts());
		}

		if ((uI5GraphCounts.getRecommendedChangesTotalApiCounts() != null)
				&& (uI5GraphCounts.getRecommendedChangesTotalApiCounts() != 0)) {
			TotalApi.put("Source code is compatible, however changes are recommended before migration",
					uI5GraphCounts.getRecommendedChangesTotalApiCounts());
		}

		if (TotalApi.size() > 0) {
			totalApiCountMap.put("Total API Counts", TotalApi);
		}

		return totalApiCountMap;
	}

	public Map<String, Map<String, Long>> getDeprecatedAPICounts(long requestID, UI5GraphCounts uI5GraphCounts) {
		Map<String, Map<String, Long>> deprecatedApiCountMap = new LinkedHashMap<String, Map<String, Long>>();

		Map<String, Long> DeprecatedApi = new LinkedHashMap<String, Long>();

		// Deprecated API COunts
		if ((uI5GraphCounts.getCompatibleDepricatedApiCounts() != null)
				&& (uI5GraphCounts.getCompatibleDepricatedApiCounts() != 0)) {
			DeprecatedApi.put("Source code is compatible with target UI5 library",
					uI5GraphCounts.getCompatibleDepricatedApiCounts());
		}

		if ((uI5GraphCounts.getSrcCodeChangesDepricatedApiCounts() != null)
				&& (uI5GraphCounts.getSrcCodeChangesDepricatedApiCounts() != 0)) {
			DeprecatedApi.put("Source code needs changes to be compatible with target UI5 library",
					uI5GraphCounts.getSrcCodeChangesDepricatedApiCounts());
		}

		if ((uI5GraphCounts.getRecommendedChangesDepricatedApiCounts() != null)
				&& (uI5GraphCounts.getRecommendedChangesDepricatedApiCounts() != 0)) {
			DeprecatedApi.put("Source code is compatible, however changes are recommended before migration",
					uI5GraphCounts.getRecommendedChangesDepricatedApiCounts());
		}

		if (DeprecatedApi.size() > 0) {
			deprecatedApiCountMap.put("Deprecated API Counts", DeprecatedApi);
		}
		return deprecatedApiCountMap;

	}



	// FIORI
	public Map<String, Integer> getInventoryOfStandardFioriAAppCounts(long requestID, FioriRequestMaster fioriRequestMaster) {
		// Inventory Of Standard Fiori Apps - Apps counts
		Map<String, Integer> map = new LinkedHashMap<String, Integer>();
		if ((fioriRequestMaster.getFioStdAppsEnabled() != null && (fioriRequestMaster.getFioStdAppsEnabled() != 0)) 
			|| (fioriRequestMaster.getFioStdAppsActive() !=null && fioriRequestMaster.getFioStdAppsActive() !=0) ) {
		map.put("Total Standard Apps Enabled", fioriRequestMaster.getFioStdAppsEnabled());
		map.put("Total Standard Apps Active", fioriRequestMaster.getFioStdAppsActive());
		}
		return map;
	}

	public Map<String, Integer> getIOSFAAppTypes(long requestID, FioriRequestMaster fioriRequestMaster) {
		// Inventory Of Standard Fiori Apps - Apps Types
		Map<String, Integer> map = new LinkedHashMap<String, Integer>();
		if ((fioriRequestMaster.getFioTrxnAppType() !=null && fioriRequestMaster.getFioTrxnAppType()!=0)
				|| (fioriRequestMaster.getFioAnalyticAppType() !=null && fioriRequestMaster.getFioAnalyticAppType() !=0)
				|| (fioriRequestMaster.getFioFactsheetAppType() !=null && fioriRequestMaster.getFioFactsheetAppType() !=0)
				|| (fioriRequestMaster.getFioWebdynAppType() != null && (fioriRequestMaster.getFioWebdynAppType() != 0)) 
				|| (fioriRequestMaster.getFioGuiAppType() !=null && fioriRequestMaster.getFioGuiAppType() !=0)
				|| (fioriRequestMaster.getFioOtherAppType() !=null && fioriRequestMaster.getFioOtherAppType() !=0)) {
		map.put("Transactional", fioriRequestMaster.getFioOtherAppType());
		map.put("Analytical", fioriRequestMaster.getFioAnalyticAppType());
		map.put("FactSheet", fioriRequestMaster.getFioFactsheetAppType());
		map.put("WebDynpro", fioriRequestMaster.getFioWebdynAppType());
		map.put("GUI", fioriRequestMaster.getFioGuiAppType());
		map.put("Others", fioriRequestMaster.getFioOtherAppType());
		}
		return map;
	}

	public Map<String, Integer> getIOEFACounts(long requestID, FioriRequestMaster fioriRequestMaster) {
		// Inventory Of Extentensions to Fiori Apps
		Map<String, Integer> map = new LinkedHashMap<String, Integer>();
		if ((fioriRequestMaster.getFioExtnStdFioriApps() !=null && fioriRequestMaster.getFioExtnStdFioriApps()!=0)
				|| (fioriRequestMaster.getFioExtnUILayer() !=null && fioriRequestMaster.getFioExtnUILayer() !=0)
				|| (fioriRequestMaster.getFioExtnServiceLayer() !=null && fioriRequestMaster.getFioExtnServiceLayer() !=0)
				|| (fioriRequestMaster.getFioExtnBackendLayer() != null && (fioriRequestMaster.getFioExtnBackendLayer() != 0))){
		map.put("Total extensions made to standard fiori apps", fioriRequestMaster.getFioExtnStdFioriApps() );
		map.put("Extensions in UI Layer", fioriRequestMaster.getFioExtnUILayer());
		map.put("Extensions in Service Layer", fioriRequestMaster.getFioExtnServiceLayer() );
		map.put("Extensions in Backend Layer", fioriRequestMaster.getFioExtnBackendLayer());
		}
		return map;
	}

	public Map<String, Integer> getIOCFOCounts(long requestID, FioriRequestMaster fioriRequestMaster) {
		// Inventory Of Custom Fiori Objects
		Map<String, Integer> map = new LinkedHashMap<String, Integer>();
		if ((fioriRequestMaster.getFioCustomUi5Apps() !=null && fioriRequestMaster.getFioCustomUi5Apps()!=0)
				|| (fioriRequestMaster.getFioCustUi5ConsumingService() !=null && fioriRequestMaster.getFioCustUi5ConsumingService() !=0)
				|| (fioriRequestMaster.getFioCustOdataServices() !=null && fioriRequestMaster.getFioCustOdataServices() !=0)
				|| (fioriRequestMaster.getFioCustServiceExposeCds() != null && (fioriRequestMaster.getFioCustServiceExposeCds() != 0))){
		map.put("Count of custom UI5 Apps", fioriRequestMaster.getFioCustomUi5Apps());
		map.put("Count of custom UI5 Apps consuming services", fioriRequestMaster.getFioCustUi5ConsumingService());
		map.put("Number of custom OData Services", fioriRequestMaster.getFioCustOdataServices());
		map.put("Number of custom services exposed out of CDS", fioriRequestMaster.getFioCustServiceExposeCds());
		}
		return map;
	}

	public Map<String, Integer> getIICOSManvNManCounts(long requestID, FioriRequestMaster fioriRequestMaster) {
		// Issues in Custom OData Services - Mandatory vs Non-Mandatory
		Map<String, Integer> map = new LinkedHashMap<String, Integer>();
		if ((fioriRequestMaster.getMandatory() !=null && fioriRequestMaster.getMandatory()!=0)
				|| (fioriRequestMaster.getNotMandatory() !=null && fioriRequestMaster.getNotMandatory() !=0)) {
		map.put("Mandatory", fioriRequestMaster.getMandatory());
		map.put("Not-Mandatory", fioriRequestMaster.getNotMandatory());
		}
		return map;
	}

	public Map<String, Map<String, Integer>> getIICOSCounts(long requestID, FioriRequestMaster fioriRequestMaster) {
		// Issues in Custom OData Services
		Map<String, Map<String, Integer>> map = new LinkedHashMap<String, Map<String, Integer>>();

		Map<String, Integer> hMap = new LinkedHashMap<String, Integer>();
		if ((fioriRequestMaster.getFioCustOdataHighSecIssue() !=null && fioriRequestMaster.getFioCustOdataHighSecIssue()!=0)
				|| (fioriRequestMaster.getFioCustOdataHighPerfIssue() !=null && fioriRequestMaster.getFioCustOdataHighPerfIssue() !=0)
				|| (fioriRequestMaster.getFioCustOdataHighDevIssue() !=null && fioriRequestMaster.getFioCustOdataHighDevIssue() !=0)) {
		hMap.put("Development", fioriRequestMaster.getFioCustOdataHighDevIssue());
		hMap.put("Performance", fioriRequestMaster.getFioCustOdataHighPerfIssue());
		hMap.put("Security", fioriRequestMaster.getFioCustOdataHighSecIssue());
		}
		if(hMap.size() >0) {
		map.put("High", hMap);
		}

		Map<String, Integer> lMap = new LinkedHashMap<String, Integer>();
		if ((fioriRequestMaster.getFioCustOdataLowSecIssue() !=null && fioriRequestMaster.getFioCustOdataLowSecIssue()!=0)
				|| (fioriRequestMaster.getFioCustOdataLowPerfIssue() !=null && fioriRequestMaster.getFioCustOdataLowPerfIssue() !=0)
				|| (fioriRequestMaster.getFioCustOdataLowDevIssue() !=null && fioriRequestMaster.getFioCustOdataLowDevIssue() !=0)) {
		lMap.put("Development", fioriRequestMaster.getFioCustOdataLowDevIssue());
		lMap.put("Performance", fioriRequestMaster.getFioCustOdataLowPerfIssue());
		lMap.put("Security", fioriRequestMaster.getFioCustOdataLowSecIssue());
		}
		if(lMap.size() >0) {
		map.put("Low", lMap);
		}
		
		Map<String, Integer> mMap = new LinkedHashMap<String, Integer>();
		if ((fioriRequestMaster.getFioCustOdataMediumSecIssue() !=null && fioriRequestMaster.getFioCustOdataMediumSecIssue()!=0)
				|| (fioriRequestMaster.getFioCustOdataMediumPerfIssue() !=null && fioriRequestMaster.getFioCustOdataMediumPerfIssue() !=0)
				|| (fioriRequestMaster.getFioCustOdataMediumDevIssue() !=null && fioriRequestMaster.getFioCustOdataMediumDevIssue() !=0)) {
		mMap.put("Development", fioriRequestMaster.getFioCustOdataMediumDevIssue());
		mMap.put("Performance", fioriRequestMaster.getFioCustOdataMediumPerfIssue());
		mMap.put("Security", fioriRequestMaster.getFioCustOdataMediumSecIssue());
		}
		if(mMap.size() >0) {
		map.put("Medium", mMap);
		}
		return map;
	}

	public Map<String, Integer> getAESAHanaCounts(long requestID, FioriRequestMaster fioriRequestMaster) {
		// Availiblity of Existing Standard Apps for Targetting S/4 Hana 1711 Cloud
		Map<String, Integer> map = new LinkedHashMap<String, Integer>();
		if ((fioriRequestMaster.getFioAppsAvlTargetVer() !=null && fioriRequestMaster.getFioAppsAvlTargetVer()!=0)
				|| (fioriRequestMaster.getFioAppsNotAvlTargetVer() !=null && fioriRequestMaster.getFioAppsNotAvlTargetVer() !=0)) {
		map.put("Count of apps available for target version", fioriRequestMaster.getFioAppsAvlTargetVer());
		map.put("Count of apps not available for target version", fioriRequestMaster.getFioAppsNotAvlTargetVer());
		}
		return map;
	}

	public Map<String, Map<String, Integer>> getIoECounts(long requestID, FioriRequestMaster fioriRequestMaster) {
		// Impact of Extension
		Map<String, Map<String, Integer>> map = new LinkedHashMap<String, Map<String, Integer>>();

		Map<String, Integer> TEMap = new LinkedHashMap<String, Integer>();
		if ((fioriRequestMaster.getFioAppsAvlTargetVer() !=null && fioriRequestMaster.getFioAppsAvlTargetVer()!=0)
				|| (fioriRequestMaster.getFioAppsNotAvlTargetVer() !=null && fioriRequestMaster.getFioAppsNotAvlTargetVer() !=0)) {
		TEMap.put("Impacted Extensions", 1);
		TEMap.put("Extensions to Standard Apps", 5);
		}
		if(TEMap.size()>0) {
		map.put("Total Extensions", TEMap);
		}

		Map<String, Integer> EULMap = new LinkedHashMap<String, Integer>();
		if ((fioriRequestMaster.getFioAppsAvlTargetVer() !=null && fioriRequestMaster.getFioAppsAvlTargetVer()!=0)
				|| (fioriRequestMaster.getFioAppsNotAvlTargetVer() !=null && fioriRequestMaster.getFioAppsNotAvlTargetVer() !=0)) {
		EULMap.put("Impacted Extensions", 0);
		EULMap.put("Extensions to Standard Apps", 2);
		}
		if(EULMap.size()>0) {
		map.put("Extensions in UI Layer", EULMap);
		}
		
		Map<String, Integer> ESLMap = new LinkedHashMap<String, Integer>();
		if ((fioriRequestMaster.getFioAppsAvlTargetVer() !=null && fioriRequestMaster.getFioAppsAvlTargetVer()!=0)
				|| (fioriRequestMaster.getFioAppsNotAvlTargetVer() !=null && fioriRequestMaster.getFioAppsNotAvlTargetVer() !=0)) {
		ESLMap.put("Impacted Extensions", 1);
		ESLMap.put("Extensions to Standard Apps", 4);
		}
		if(ESLMap.size()>0) {
		map.put("Extensions in Service Layer", ESLMap);
		}

		Map<String, Integer> EBLMap = new LinkedHashMap<String, Integer>();
		if ((fioriRequestMaster.getFioAppsAvlTargetVer() !=null && fioriRequestMaster.getFioAppsAvlTargetVer()!=0)
				|| (fioriRequestMaster.getFioAppsNotAvlTargetVer() !=null && fioriRequestMaster.getFioAppsNotAvlTargetVer() !=0)) {
		EBLMap.put("Impacted Extensions", 0);
		EBLMap.put("Extensions to Standard Apps", 0);
		}
		if(EBLMap.size()>0) {
		map.put("Extensions in Backend Layer", EBLMap);
		}

		return map;
	}

	
	public Map<String, Integer> getPFSACounts(long requestID, FioriRequestMaster fioriRequestMaster) {
		// Probable Fitment of Standard Apps
		Map<String, Integer> resultMap = new LinkedHashMap<String, Integer>();
		if (fioriRequestMaster.getFioTcodesStandardApps() != null && !fioriRequestMaster.getFioTcodesStandardApps().isEmpty()) {
			String fioAppIdCount = fioriRequestMaster.getFioTcodesStandardApps();
			String[] fioAppIdCountSplit = fioAppIdCount.split("\\|");
			for (String fioAppIdCountSplitData : fioAppIdCountSplit) {
				String[] CountSplit = fioAppIdCountSplitData.split("\\:");

				resultMap.put(CountSplit[0], Integer.parseInt(CountSplit[1]));
			}
		} else {
			resultMap.put("Empty", 0);
		}
		return resultMap;
		
	}

	public Map<String, Integer> getImpactedBackgroundJobCounts(long requestID, ImpactedBackgroundCounts impactedBackgroundJob) {
		
	Map<String, Integer> impactedBackgroundJobMap = new HashMap<String, Integer>();
	
	if (impactedBackgroundJob.getJobRunCount_Daily() !=null && impactedBackgroundJob.getJobRunCount_Daily()!=0) {
	impactedBackgroundJobMap.put("Daily", impactedBackgroundJob.getJobRunCount_Daily());
	}
	if(impactedBackgroundJob.getJobRunCount_Weekly() !=null && impactedBackgroundJob.getJobRunCount_Weekly()!=0) {
	impactedBackgroundJobMap.put("Weekly", impactedBackgroundJob.getJobRunCount_Weekly());
	}
	if(impactedBackgroundJob.getJobRunCount_Monthly() !=null && impactedBackgroundJob.getJobRunCount_Monthly()!=0) {
		impactedBackgroundJobMap.put("Monthly", impactedBackgroundJob.getJobRunCount_Monthly());
	}
	if(impactedBackgroundJob.getJobRunCount_Others() !=null && impactedBackgroundJob.getJobRunCount_Others()!=0) {
		impactedBackgroundJobMap.put("Others", impactedBackgroundJob.getJobRunCount_Others());
	}
	
	if(impactedBackgroundJob.getBackgroundJobCount() !=null) {
		impactedBackgroundJobMap.put("Count of Background Job", impactedBackgroundJob.getBackgroundJobCount());
	}else {
		impactedBackgroundJobMap.put("Count of Background Job", 0);

	}
	
	return impactedBackgroundJobMap;
}
	
	public LinkedHashMap<String, Integer> getExtensionScopeMaster(long requestId, String ricefInput) throws Exception {
		final LinkedHashMap<String, Integer> resultMap = new LinkedHashMap<String, Integer>();
		try
		{
			if (ricefInput != null && ! (ricefInput.equalsIgnoreCase(""))) {
				
				String[] inputSplit = ricefInput.split("\\|");
			
				for (String ricefInputSplitData : inputSplit) {
					String[] CountSplit = ricefInputSplitData.split("\\:");
					
						resultMap.put(CountSplit[0], Integer.parseInt(CountSplit[1]));
				
				}
				
			} else {
				resultMap.put("Empty", 0);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new Exception(); 
		}
		return resultMap;
	}
	
	
	public LinkedHashMap<String, LinkedHashMap<String, String>> getExtensionScopeMasterStack(long requestId, String ricefInput) throws Exception {
		final LinkedHashMap<String, LinkedHashMap<String, String>> resultMap = new LinkedHashMap<String, LinkedHashMap<String, String>>();
		try
		{
			if (ricefInput != null && ! (ricefInput.equalsIgnoreCase(""))) {
				
				String[] inputSplit = ricefInput.split("\\|");
			
				for (String ricefInputSplitData : inputSplit) {
					String[] CountSplit = ricefInputSplitData.split("\\:");
					LinkedHashMap<String, String> countMap = new LinkedHashMap<String, String>();
					for(int i=1; i<CountSplit.length; i++) {
						
						countMap.put(CountSplit[i],CountSplit[i+1]);
						i++;
					}
					
						resultMap.put(CountSplit[0], countMap);
				
				}
				
			} else {
				resultMap.put("Empty", new LinkedHashMap<String, String>());
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new Exception(); 
		}
		return resultMap;
	}
}
