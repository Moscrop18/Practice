package com.act.dao.factory;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.hibernate.Session;

public class AbstractHibernateDao {

	
	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	
	@Autowired
	@Qualifier("mySessionFactory")
	private SessionFactory sessionFactory;
	private Session session;
	
	

	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}

	public void setSessionFactory(final SessionFactory sessionFactory) 
    {
		
		this.sessionFactory=sessionFactory;
	}
	
	public SessionFactory getSessionFactory()
	{
		return this.sessionFactory;
	}
	
	public Session getSession() {
		return this.session;
	}

	public void setSession(Session session) {
		this.session = this.sessionFactory.openSession();
		
	}
}
