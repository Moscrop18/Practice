package com.act.reqmaster.dao;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.act.constant.Hana_Profiler_Constant;
import com.act.master.ProcessedRMCounts;
import com.act.master.ProcessedRequestMaster;

@Repository
public class RequestMasterDAOImpl implements RequestMasterDAO {

	@Autowired
	private SessionFactory sessionFactory;

	private final Logger logger = LoggerFactory.getLogger(RequestMasterDAOImpl.class);

	@Override
	public Map<String, Map<String, Map<String, Integer>>> getAppLevelHANACounts(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder("SELECT issueSecondSubCat, Subcategory, COUNT(*), "
				+ "COUNT(DISTINCT objNameType) FROM HanaProfile WHERE requestID = :requestId AND "
				+ "category = :category AND extNamespace = :extNmSpc GROUP BY issueSecondSubCat, Subcategory");

		Session session = null;
		Map<String, Map<String, Map<String, Integer>>> resultMap = new LinkedHashMap<>();
		Map<String, Map<String, Integer>> categoryMap = null;
		Map<String, Integer> countMap = null;
		String issueCategory = "", issueSubCategory = "";
		int errorCount = 0, distinctCount = 0;

		try {
			session = sessionFactory.openSession();
			
			Query query = session.createQuery(getSQL.toString());
			query.setParameter("requestId", requestId);
			query.setParameter("category", "Application level optimization".toUpperCase());
			query.setParameter("extNmSpc", StringUtils.EMPTY);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					if (resultObj[0] != null && resultObj[1] != null) {
						issueSubCategory = resultObj[0].toString().toUpperCase().trim();
						issueCategory = resultObj[1].toString().toUpperCase().trim();
						errorCount = (resultObj[2] == null) ? 0 : ((Long) resultObj[2]).intValue();
						distinctCount = (resultObj[3] == null) ? 0 : ((Long) resultObj[3]).intValue();

						if (resultMap.containsKey(issueSubCategory)) {
							categoryMap = resultMap.get(issueSubCategory);
						} else {
							categoryMap = new LinkedHashMap<>();
						}

						countMap = new LinkedHashMap<>();
						countMap.put(Hana_Profiler_Constant.ERROR_COUNT, errorCount);
						countMap.put(Hana_Profiler_Constant.DISTINCT_COUNT, distinctCount);

						categoryMap.put(issueCategory, countMap);

						resultMap.put(issueSubCategory, categoryMap);
					}
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching the Application Level Optimization HANA Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	@Override
	public Map<String, Map<String, Integer>> getDBLevelHouskeepHANACounts(long requestId, String remCategory)
			throws Exception {
		StringBuilder getSQL = new StringBuilder("SELECT Opertaion, COUNT(*), "
				+ "COUNT(DISTINCT objNameType) FROM HanaProfile WHERE requestID = :requestId AND "
				+ "category = :remCategory AND extNamespace = :extNmSpc GROUP BY Opertaion");

		Session session = null;
		Map<String, Map<String, Integer>> resultMap = new LinkedHashMap<>();
		Map<String, Integer> countMap = null;
		String operation = "";
		int errorCount = 0, distinctCount = 0;

		try {
			session = sessionFactory.openSession();
			
			Query query = session.createQuery(getSQL.toString());
			query.setParameter("requestId", requestId);
			query.setParameter("remCategory", remCategory);
			query.setParameter("extNmSpc", StringUtils.EMPTY);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					if (resultObj[0] != null) {
						operation = resultObj[0].toString().toUpperCase().trim();
						errorCount = (resultObj[1] == null) ? 0 : ((Long) resultObj[1]).intValue();
						distinctCount = (resultObj[2] == null) ? 0 : ((Long) resultObj[2]).intValue();

						countMap = new LinkedHashMap<>();
						countMap.put(Hana_Profiler_Constant.ERROR_COUNT, errorCount);
						countMap.put(Hana_Profiler_Constant.DISTINCT_COUNT, distinctCount);

						resultMap.put(operation, countMap);
					}
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching the " + remCategory.toUpperCase().trim() + " HANA Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	@Override
	public Map<String, Map<String, Map<String, Integer>>> getRemCatAutomationHANACounts(long requestId)
			throws Exception {
		StringBuilder getSQL = new StringBuilder("SELECT Category AS remCategory, automation_status AS autoStatus, "
				+ "COALESCE(Used_Unused, '') AS usedUnused, COUNT(*) AS errorCount, COUNT(DISTINCT OBJ_NAME_TYPE) AS distinctCount "
				+ "FROM FINAL_OUTPUT WHERE Request_ID = :requestId AND External_Namespace = :extNmSpc "
				+ "GROUP BY Category, automation_status, usedUnused");

		Session session = null;
		Map<String, Map<String, Map<String, Integer>>> resultMap = new LinkedHashMap<>();
		Map<String, Map<String, Integer>> autoMap = null;
		Map<String, Integer> usedMap = null;
		String remCategory = "", automationStatus = "", used = "";
		int errorCount = 0, distinctCount = 0;

		try {
			session = sessionFactory.openSession();
			
			SQLQuery query = session.createSQLQuery(getSQL.toString());
			query.addScalar("remCategory", new StringType());
			query.addScalar("autoStatus", new StringType());
			query.addScalar("usedUnused", new StringType());
			query.addScalar("errorCount", new IntegerType());
			query.addScalar("distinctCount", new IntegerType());
			query.setLong("requestId", requestId);
			query.setParameter("extNmSpc", StringUtils.EMPTY);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					if (resultObj[0] != null) {
						remCategory = resultObj[0].toString().toUpperCase().trim();
						automationStatus = resultObj[1].toString().toUpperCase().trim();
						used = resultObj[2].toString();
						errorCount = (resultObj[3] == null) ? 0 : (Integer) resultObj[3];
						distinctCount = (resultObj[4] == null) ? 0 : (Integer) resultObj[4];

						if (resultMap.containsKey(remCategory))
							autoMap = resultMap.get(remCategory);
						else
							autoMap = new LinkedHashMap<>();

						if (autoMap.containsKey(automationStatus))
							usedMap = autoMap.get(automationStatus);
						else
							usedMap = new LinkedHashMap<>();

						if (used.isEmpty()) {
							usedMap.put(Hana_Profiler_Constant.UNUSED_ALL_COUNT, errorCount);
							usedMap.put(Hana_Profiler_Constant.UNUSED_DISTINCT, distinctCount);
						} else {
							usedMap.put(Hana_Profiler_Constant.USED_ALL_COUNT, errorCount);
							usedMap.put(Hana_Profiler_Constant.USED_DISTINCT, distinctCount);
						}

						autoMap.put(automationStatus, usedMap);
						resultMap.put(remCategory, autoMap);
					}
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching the HANA Counts Based on Remediation Category and Automation Status : ",
					e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	@Override
	public Map<String, Map<String, Map<String, Integer>>> getMandatoryHANACounts(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder("SELECT Subcategory, Opertaion, COUNT(*), "
				+ "COUNT(DISTINCT objNameType) FROM HanaProfile WHERE requestID = :requestId AND "
				+ "category = :category AND extNamespace = :extNmSpc GROUP BY Subcategory, Opertaion");

		Session session = null;
		Map<String, Map<String, Map<String, Integer>>> resultMap = new LinkedHashMap<>();
		Map<String, Map<String, Integer>> operationMap = null;
		Map<String, Integer> countMap = null;
		String issueCategory = "", operation = "";
		int errorCount = 0, distinctCount = 0;

		try {
			session = sessionFactory.openSession();
			
			Query query = session.createQuery(getSQL.toString());
			query.setParameter("requestId", requestId);
			query.setParameter("category", "Mandatory".toUpperCase());
			query.setParameter("extNmSpc", StringUtils.EMPTY);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					if (resultObj[0] != null && resultObj[1] != null) {
						issueCategory = resultObj[0].toString().toUpperCase().trim();
						operation = resultObj[1].toString().toUpperCase().trim();
						errorCount = (resultObj[2] == null) ? 0 : ((Long) resultObj[2]).intValue();
						distinctCount = (resultObj[3] == null) ? 0 : ((Long) resultObj[3]).intValue();

						if (resultMap.containsKey(issueCategory)) {
							operationMap = resultMap.get(issueCategory);
						} else {
							operationMap = new LinkedHashMap<>();
						}

						countMap = new LinkedHashMap<>();
						countMap.put(Hana_Profiler_Constant.ERROR_COUNT, errorCount);
						countMap.put(Hana_Profiler_Constant.DISTINCT_COUNT, distinctCount);
						operationMap.put(operation, countMap);

						resultMap.put(issueCategory, operationMap);
					}
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching the Mandatory HANA Counts Based on Issue Subcategory and Operation : ",
					e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	@Override
	public Map<String, Map<String, Integer>> getRemCatHANACounts(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder("SELECT Category AS remCategory, COALESCE(Used_Unused, '') AS usedUnused, "
				+ "COUNT(*) AS errorCount, COUNT(DISTINCT OBJ_NAME_TYPE) AS distinctCount FROM FINAL_OUTPUT WHERE "
				+ "Request_ID = :requestId AND External_Namespace = :extNmSpc GROUP BY Category, usedUnused");

		Session session = null;
		Map<String, Map<String, Integer>> resultMap = new LinkedHashMap<>();
		Map<String, Integer> usedMap = null;
		String remCategory = "", used = "";
		int errorCount = 0, distinctCount = 0;

		try {
			session = sessionFactory.openSession();
			
			SQLQuery query = session.createSQLQuery(getSQL.toString());
			query.addScalar("remCategory", new StringType());
			query.addScalar("usedUnused", new StringType());
			query.addScalar("errorCount", new IntegerType());
			query.addScalar("distinctCount", new IntegerType());
			query.setLong("requestId", requestId);
			query.setParameter("extNmSpc", StringUtils.EMPTY);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					if (resultObj[0] != null && resultObj[1] != null) {
						remCategory = resultObj[0].toString().toUpperCase().trim();
						used = resultObj[1].toString();
						errorCount = (resultObj[2] == null) ? 0 : (Integer) resultObj[2];
						distinctCount = (resultObj[3] == null) ? 0 : (Integer) resultObj[3];

						if (resultMap.containsKey(remCategory))
							usedMap = resultMap.get(remCategory);
						else
							usedMap = new LinkedHashMap<>();

						if (used.isEmpty()) {
							usedMap.put(Hana_Profiler_Constant.UNUSED_ALL_COUNT, errorCount);
							usedMap.put(Hana_Profiler_Constant.UNUSED_DISTINCT, distinctCount);
						} else {
							usedMap.put(Hana_Profiler_Constant.USED_ALL_COUNT, errorCount);
							usedMap.put(Hana_Profiler_Constant.USED_DISTINCT, distinctCount);
						}

						resultMap.put(remCategory, usedMap);
					}
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching the HANA Remediation Category Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	@Override
	public Map<String, Map<String, Map<String, Integer>>> getRemCatIssueCatHANACounts(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder("SELECT Category AS remCategory, Subcategory AS subCategory, COALESCE(Used_Unused, '') AS usedUnused, "
				+ "COUNT(*) AS errorCount, COUNT(DISTINCT OBJ_NAME_TYPE) AS distinctCount FROM FINAL_OUTPUT WHERE "
				+ "Request_ID = :requestId AND External_Namespace = :extNmSpc GROUP BY Category, Subcategory, usedUnused");

		Session session = null;
		Map<String, Map<String, Map<String, Integer>>> resultMap = new LinkedHashMap<>();
		Map<String, Map<String, Integer>> issueCategoryMap = null;
		Map<String, Integer> usedMap = null;
		String remCategory = "", issueCategory = "", used = "";
		int errorCount = 0, distinctCount = 0;

		try {
			session = sessionFactory.openSession();
			
			SQLQuery query = session.createSQLQuery(getSQL.toString());
			query.addScalar("remCategory", new StringType());
			query.addScalar("subCategory", new StringType());
			query.addScalar("usedUnused", new StringType());
			query.addScalar("errorCount", new IntegerType());
			query.addScalar("distinctCount", new IntegerType());
			query.setLong("requestId", requestId);
			query.setParameter("extNmSpc", StringUtils.EMPTY);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					if (resultObj[0] != null && resultObj[1] != null) {
						remCategory = resultObj[0].toString().toUpperCase().trim();
						issueCategory = resultObj[1].toString().toUpperCase().trim();
						used = resultObj[2].toString();
						errorCount = (resultObj[3] == null) ? 0 : (Integer) resultObj[3];
						distinctCount = (resultObj[4] == null) ? 0 : (Integer) resultObj[4];

						if (resultMap.containsKey(remCategory))
							issueCategoryMap = resultMap.get(remCategory);
						else
							issueCategoryMap = new LinkedHashMap<>();

						if (issueCategoryMap.containsKey(issueCategory))
							usedMap = issueCategoryMap.get(issueCategory);
						else
							usedMap = new LinkedHashMap<>();

						if (used.isEmpty()) {
							usedMap.put(Hana_Profiler_Constant.UNUSED_ALL_COUNT, errorCount);
							usedMap.put(Hana_Profiler_Constant.UNUSED_DISTINCT, distinctCount);
						} else {
							usedMap.put(Hana_Profiler_Constant.USED_ALL_COUNT, errorCount);
							usedMap.put(Hana_Profiler_Constant.USED_DISTINCT, distinctCount);
						}

						issueCategoryMap.put(issueCategory, usedMap);
						resultMap.put(remCategory, issueCategoryMap);
					}
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching the HANA Counts Based on Remediation Category and Issue Category : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	@Override
	public Map<String, Map<String, Integer>> getInventoryObjectCounts(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder("SELECT OBJ_TYPE AS objectType, COALESCE(Used, '') AS usedUnused, "
				+ "COUNT(OBJ_TYPE) AS count FROM S4_Inventory_List WHERE REQUEST_ID = :requestId AND External_Namespace = :extNmSpc "
				+ "GROUP BY OBJ_TYPE, usedUnused");

		Session session = null;
		Map<String, Map<String, Integer>> resultMap = new LinkedHashMap<>();
		Map<String, Integer> usedMap = null;
		String objType = "", used = "";
		int count = 0;

		try {
			session = sessionFactory.openSession();
			
			SQLQuery query = session.createSQLQuery(getSQL.toString());
			query.addScalar("objectType", new StringType());
			query.addScalar("usedUnused", new StringType());
			query.addScalar("count", new IntegerType());
			query.setLong("requestId", requestId);
			query.setParameter("extNmSpc", StringUtils.EMPTY);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObject : resultList) {
					if (resultObject[0] != null) {
						objType = resultObject[0].toString().toUpperCase().trim();
						used = resultObject[1].toString();
						count = (resultObject[2] == null) ? 0 : (Integer) resultObject[2];

						if (resultMap.containsKey(objType))
							usedMap = resultMap.get(objType);
						else
							usedMap = new LinkedHashMap<>();

						if (used.isEmpty())
							usedMap.put(Hana_Profiler_Constant.UNUSED_ALL_COUNT, count);
						else
							usedMap.put(Hana_Profiler_Constant.USED_ALL_COUNT, count);

						resultMap.put(objType, usedMap);
					}
				}
			}
		} catch (Exception e) {
			logger.error("Error while retrieving the Inventory Object Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	@Override
	public Map<String, Map<String, Integer>> getRemCatS4Counts(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder("SELECT Remediation_Category AS remCategory, COALESCE(USED, '') AS usedUnused, "
				+ "COUNT(*) AS errorCount, COUNT(DISTINCT OBJ_NAME_TYPE) AS distinctCount FROM S4_Final_Output WHERE "
				+ "REQUEST_ID = :requestId AND External_Namespace = :extNmSpc GROUP BY Remediation_Category, usedUnused");

		Session session = null;
		Map<String, Map<String, Integer>> resultMap = new LinkedHashMap<>();
		Map<String, Integer> usedMap = null;
		String remCat = "", used = "";
		int errorCount = 0, distinctCount = 0;

		try {
			session = sessionFactory.openSession();
			
			SQLQuery query = session.createSQLQuery(getSQL.toString());
			query.addScalar("remCategory", new StringType());
			query.addScalar("usedUnused", new StringType());
			query.addScalar("errorCount", new IntegerType());
			query.addScalar("distinctCount", new IntegerType());
			query.setLong("requestId", requestId);
			query.setParameter("extNmSpc", StringUtils.EMPTY);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					if (resultObj[0] != null && resultObj[1] != null) {
						remCat = resultObj[0].toString().toUpperCase().trim();
						used = resultObj[1].toString();
						errorCount = (resultObj[2] == null) ? 0 : (Integer) resultObj[2];
						distinctCount = (resultObj[3] == null) ? 0 : (Integer) resultObj[3];

						if (resultMap.containsKey(remCat))
							usedMap = resultMap.get(remCat);
						else
							usedMap = new LinkedHashMap<>();

						if (used.isEmpty()) {
							usedMap.put(Hana_Profiler_Constant.UNUSED_ALL_COUNT, errorCount);
							usedMap.put(Hana_Profiler_Constant.UNUSED_DISTINCT, distinctCount);
						} else {
							usedMap.put(Hana_Profiler_Constant.USED_ALL_COUNT, errorCount);
							usedMap.put(Hana_Profiler_Constant.USED_DISTINCT, distinctCount);
						}

						resultMap.put(remCat, usedMap);
					}
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching S4 Counts Based on Remediation Category : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	@Override
	public Map<String, Map<String, Map<String, Integer>>> getRemCatCompS4Counts(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder("SELECT Remediation_Category AS remCategory, complexity AS comp, "
				+ "COALESCE(Used, '') AS usedUnused, COUNT(*) AS errorCount, COUNT(DISTINCT OBJ_NAME_TYPE) AS distinctCount "
				+ "FROM S4_Final_Output WHERE REQUEST_ID = :requestId AND External_Namespace = :extNmSpc "
				+ "GROUP BY Remediation_Category, complexity, usedUnused");

		Session session = null;
		Map<String, Map<String, Map<String, Integer>>> resultMap = new LinkedHashMap<>();
		Map<String, Map<String, Integer>> complexityMap = null;
		Map<String, Integer> usedMap = null;
		String remCat = "", complexity = "", used = "";
		int errorCount = 0, distinctCount = 0;

		try {
			session = sessionFactory.openSession();
			SQLQuery query = session.createSQLQuery(getSQL.toString());
			query.addScalar("remCategory", new StringType());
			query.addScalar("comp", new StringType());
			query.addScalar("usedUnused", new StringType());
			query.addScalar("errorCount", new IntegerType());
			query.addScalar("distinctCount", new IntegerType());
			query.setLong("requestId", requestId);
			query.setParameter("extNmSpc", StringUtils.EMPTY);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					if (resultObj[0] != null && resultObj[1] != null) {
						remCat = resultObj[0].toString().toUpperCase().trim();
						complexity = resultObj[1].toString().toUpperCase().trim();
						used = resultObj[2].toString();
						errorCount = (resultObj[3] == null) ? 0 : (Integer) resultObj[3];
						distinctCount = (resultObj[4] == null) ? 0 : (Integer) resultObj[4];

						if (resultMap.containsKey(remCat))
							complexityMap = resultMap.get(remCat);
						else
							complexityMap = new LinkedHashMap<>();

						if (complexityMap.containsKey(complexity))
							usedMap = complexityMap.get(complexity);
						else
							usedMap = new LinkedHashMap<>();

						if (used.isEmpty()) {
							usedMap.put(Hana_Profiler_Constant.UNUSED_ALL_COUNT, errorCount);
							usedMap.put(Hana_Profiler_Constant.UNUSED_DISTINCT, distinctCount);
						} else {
							usedMap.put(Hana_Profiler_Constant.USED_ALL_COUNT, errorCount);
							usedMap.put(Hana_Profiler_Constant.USED_DISTINCT, distinctCount);
						}

						complexityMap.put(complexity, usedMap);
						resultMap.put(remCat, complexityMap);
					}
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching S4 Counts Based on Remediation Category and Complexity : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	public Map<String, Integer> getS4Counts(long requestId, String s4ColName) throws Exception {
		StringBuilder getSQL = new StringBuilder("SELECT " + s4ColName + ", COUNT(DISTINCT objNameType) "
				+ "FROM S4HanaProfiler WHERE requestID = :requestId AND extNamespace = :extNmSpc GROUP BY "
				+ s4ColName);

		Session session = null;
		Map<String, Integer> resultMap = new LinkedHashMap<>();
		String s4ColValue = "";
		int count = 0;

		try {
			session = sessionFactory.openSession();
			
			Query query = session.createQuery(getSQL.toString());
			query.setParameter("requestId", requestId);
			query.setParameter("extNmSpc", StringUtils.EMPTY);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					if (resultObj[0] != null) {
						s4ColValue = resultObj[0].toString().toUpperCase().trim();
						count = (resultObj[1] == null) ? 0 : ((Long) resultObj[1]).intValue();

						resultMap.put(s4ColValue, count);
					}
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching S4 Counts from " + s4ColName + "column : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	public Integer getImpStdTransCount(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder("SELECT COUNT(DISTINCT impactedTransaction) FROM "
				+ "S4ImpactedTransaction WHERE requestID = :requestId");

		Session session = null;
		Integer count = 0;
		try {
			session = sessionFactory.openSession();
			
			Query query = session.createQuery(getSQL.toString());
			query.setParameter("requestId", requestId);

			count = ((Long) query.uniqueResult()).intValue();
		} catch (Exception e) {
			logger.error("Error while fetching Impacted Standard Transactions Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return count;
	}

	public Map<String, Map<String, Integer>> getImpactedObjectCounts(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder("SELECT objCount.objType AS objType, objCount.usedUnused AS used, COUNT(*) AS count FROM "
				+ "(SELECT DISTINCT Object_Type AS objType, Obj_Name AS objName, COALESCE(Used_Unused, '') AS usedUnused "
				+ "FROM FINAL_OUTPUT WHERE Request_ID = :requestId AND External_Namespace = :extNmSpc "
				+ "UNION "
				+ "SELECT DISTINCT Type AS objType, Obj_Name as objName, COALESCE(Used, '') AS usedUnused "
				+ "FROM S4_Final_Output WHERE Request_ID = :requestId AND External_Namespace = :extNmSpc) objCount "
				+ "GROUP BY objCount.objType, objCount.usedUnused");
		
		Session session = null;
		Map<String, Map<String, Integer>> resultMap = new LinkedHashMap<>();
		Map<String, Integer> usedMap = null;
		String objType = "", used = "";
		int count = 0;

		try {
			session = sessionFactory.openSession();
			
			SQLQuery query = session.createSQLQuery(getSQL.toString());
			query.addScalar("objType", new StringType());
			query.addScalar("used", new StringType());
			query.addScalar("count", new IntegerType());
			query.setLong("requestId", requestId);
			query.setParameter("extNmSpc", StringUtils.EMPTY);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					if (resultObj[0] != null) {
						objType = resultObj[0].toString().toUpperCase().trim();
						used = resultObj[1].toString();
						count = (resultObj[2] == null) ? 0 : (Integer) resultObj[2];

						if (resultMap.containsKey(objType))
							usedMap = resultMap.get(objType);
						else
							usedMap = new LinkedHashMap<>();

						if (used.isEmpty())
							usedMap.put(Hana_Profiler_Constant.UNUSED_ALL_COUNT, count);
						else
							usedMap.put(Hana_Profiler_Constant.USED_ALL_COUNT, count);

						resultMap.put(objType, usedMap);
					}
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching the Impacted Object Counts ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	@Override
	public Map<String, Integer> getImpactedObjCountHANA(long requestId, String extNamespaceVal) throws Exception {
		StringBuilder getSQL = new StringBuilder(
				"SELECT COALESCE(Used_Unused, '') AS usedUnused, COUNT(DISTINCT OBJ_NAME_TYPE) AS distinctCount FROM FINAL_OUTPUT "
				+ "WHERE Request_ID = :requestId AND External_Namespace = :extNmSpc GROUP BY usedUnused");

		Session session = null;
		Map<String, Integer> resultMap = new LinkedHashMap<>();
		String used = "";
		int count = 0;

		try {
			session = sessionFactory.openSession();
			
			SQLQuery query = session.createSQLQuery(getSQL.toString());
			query.addScalar("usedUnused", new StringType());
			query.addScalar("distinctCount", new IntegerType());
			query.setLong("requestId", requestId);
			query.setParameter("extNmSpc", extNamespaceVal);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					used = resultObj[0].toString();
					count = (resultObj[1] == null) ? 0 : (Integer) resultObj[1];

					if (used.isEmpty())
						resultMap.put(Hana_Profiler_Constant.UNUSED_ALL_COUNT, count);
					else
						resultMap.put(Hana_Profiler_Constant.USED_ALL_COUNT, count);
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching the HANA Impacted Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}
	
	@Override
	public Map<String, Integer> getImpactedObjCountS4(long requestId, String extNamespaceVal) throws Exception {
		StringBuilder getSQL = new StringBuilder(
				"SELECT COALESCE(Used, '') AS usedUnused, COUNT(DISTINCT OBJ_NAME_TYPE) AS distinctCount FROM S4_Final_Output "
				+ "WHERE REQUEST_ID = :requestId AND External_Namespace = :extNmSpc GROUP BY usedUnused");

		Session session = null;
		Map<String, Integer> resultMap = new LinkedHashMap<>();
		String used = "";
		int count = 0;

		try {
			session = sessionFactory.openSession();
			
			SQLQuery query = session.createSQLQuery(getSQL.toString());
			query.addScalar("usedUnused", new StringType());
			query.addScalar("distinctCount", new IntegerType());
			query.setLong("requestId", requestId);
			query.setParameter("extNmSpc", extNamespaceVal);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					used = resultObj[0].toString();
					count = (resultObj[1] == null) ? 0 : (Integer) resultObj[1];

					if (used.isEmpty())
						resultMap.put(Hana_Profiler_Constant.UNUSED_ALL_COUNT, count);
					else
						resultMap.put(Hana_Profiler_Constant.USED_ALL_COUNT, count);
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching the S4 Impacted Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	@Override
	public Map<String, Integer> getDistinctCloneObjCount(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder("SELECT COALESCE(USED, '') AS usedUnused, COUNT(DISTINCT OBJ_TYPE_NAME) AS distinctCount "
				+ "FROM IMPACTED_CLONE_ANALYSIS where REQUEST_ID = :requestId AND EXTERNAL_NAMESPACE = :extNmSpc GROUP BY usedUnused");

		Session session = null;
		Map<String, Integer> resultMap = new LinkedHashMap<>();
		String used = "";
		int count = 0;

		try {
			session = sessionFactory.openSession();
			
			SQLQuery query = session.createSQLQuery(getSQL.toString());
			query.addScalar("usedUnused", new StringType());
			query.addScalar("distinctCount", new IntegerType());
			query.setLong("requestId", requestId);
			query.setParameter("extNmSpc", StringUtils.EMPTY);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					used = resultObj[0].toString();
					count = (resultObj[1] == null) ? 0 : (Integer) resultObj[1];

					if (used.isEmpty())
						resultMap.put(Hana_Profiler_Constant.UNUSED_ALL_COUNT, count);
					else
						resultMap.put(Hana_Profiler_Constant.USED_ALL_COUNT, count);
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching distinct Impacted Clone Object Used and Unused Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	@Override
	public Integer getDistinctCloneObjCountHANAS4(long requestId, String cloneColName) throws Exception {
		StringBuilder getSQL = new StringBuilder(
				"SELECT COUNT(DISTINCT objTypeName) FROM ImpactedCloneAnalysis WHERE requestID = :requestId AND "
						+ cloneColName + " = :impact AND externalNamespace = :extNmSpc ");

		Session session = null;
		int count = 0;

		try {
			session = sessionFactory.openSession();
			
			Query query = session.createQuery(getSQL.toString());
			query.setParameter("requestId", requestId);
			query.setParameter("impact", "Y");
			query.setParameter("extNmSpc", StringUtils.EMPTY);

			count = ((Long) query.uniqueResult()).intValue();
		} catch (Exception e) {
			logger.error("Error while fetching the Impacted Clone Object Counts for Hana/S4 : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return count;
	}

	@Override
	public Map<String, Integer> getImpactedCloneObjectRefCountsHANAS4(long requestId, String cloneColName)
			throws Exception {
		StringBuilder getSQL = new StringBuilder("SELECT reference, COUNT(DISTINCT objTypeName) FROM "
				+ "ImpactedCloneAnalysis WHERE requestID = :requestId AND " + cloneColName
				+ " = :impact AND externalNamespace = :extNmSpc GROUP BY reference");

		Session session = null;
		Map<String, Integer> resultMap = new LinkedHashMap<>();
		String reference = "";
		int count = 0;

		try {
			session = sessionFactory.openSession();
			
			Query query = session.createQuery(getSQL.toString());
			query.setParameter("requestId", requestId);
			query.setParameter("impact", "Y");
			query.setParameter("extNmSpc", StringUtils.EMPTY);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					reference = resultObj[0].toString().toUpperCase().trim();
					count = (resultObj[1] == null) ? 0 : ((Long) resultObj[1]).intValue();

					resultMap.put(reference, count);
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching the Impacted Clone Object Distinct Counts for Hana/S4 : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	@Override
	public Map<String, Map<String, Integer>> getTotalCloneObjects(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder("SELECT REFERENCE AS ref, COALESCE(USED, '') AS usedUnused, "
				+ "COUNT(DISTINCT OBJ_TYPE_NAME) AS distinctCount FROM IMPACTED_CLONE_ANALYSIS WHERE REQUEST_ID = :requestId  "
				+ "AND EXTERNAL_NAMESPACE = :extNmSpc GROUP BY REFERENCE, usedUnused");

		Session session = null;
		Map<String, Map<String, Integer>> resultMap = new LinkedHashMap<>();
		Map<String, Integer> usedMap = null;
		String reference = "", used = "";
		int count = 0;

		try {
			session = sessionFactory.openSession();
			
			SQLQuery query = session.createSQLQuery(getSQL.toString());
			query.addScalar("ref", new StringType());
			query.addScalar("usedUnused", new StringType());
			query.addScalar("distinctCount", new IntegerType());
			query.setLong("requestId", requestId);
			query.setParameter("extNmSpc", StringUtils.EMPTY);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					if (resultObj[0] != null)
						reference = resultObj[0].toString().toUpperCase().trim();
					used = resultObj[1].toString();
					count = (resultObj[2] == null) ? 0 : (Integer) resultObj[2];

					if (resultMap.containsKey(reference))
						usedMap = resultMap.get(reference);
					else
						usedMap = new LinkedHashMap<>();

					if (used.isEmpty())
						usedMap.put(Hana_Profiler_Constant.UNUSED_ALL_COUNT, count);
					else
						usedMap.put(Hana_Profiler_Constant.USED_ALL_COUNT, count);

					resultMap.put(reference, usedMap);
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching Total Impacted Clone object counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	@Override
	public Map<String, Map<String, Integer>> getSmodilogDistinctObjCount(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder("SELECT objType, COUNT(objType), COUNT(DISTINCT objNameType) "
				+ "FROM SmodilogFunction WHERE requestId = :requestId GROUP BY objType");

		Session session = null;
		Map<String, Map<String, Integer>> resultMap = new LinkedHashMap<>();
		Map<String, Integer> countMap = null;
		String object = "";
		int errorCount = 0, distinctCount = 0;

		try {
			session = sessionFactory.openSession();
			Query query = session.createQuery(getSQL.toString());
			query.setParameter("requestId", requestId);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					if (resultObj[0] != null) {
						object = resultObj[0].toString().toUpperCase().trim();
						errorCount = (resultObj[1] == null) ? 0 : ((Long) resultObj[1]).intValue();
						distinctCount = (resultObj[2] == null) ? 0 : ((Long) resultObj[2]).intValue();

						countMap = new LinkedHashMap<>();

						countMap.put(Hana_Profiler_Constant.ERROR_COUNT, errorCount);
						countMap.put(Hana_Profiler_Constant.DISTINCT_COUNT, distinctCount);

						resultMap.put(object, countMap);
					}
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching the Smodilog Object Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	@Override
	public Integer getTScopeProcessCount(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder(
				"SELECT COUNT(DISTINCT process) FROM ExtractedDatapojo WHERE requestid = :requestId");

		Session session = null;
		Integer count = 0;

		try {
			session = sessionFactory.openSession();
			Query query = session.createQuery(getSQL.toString());
			query.setParameter("requestId", requestId);

			count = ((Long) query.uniqueResult()).intValue();
		} catch (Exception e) {
			logger.error("Error while fetching the Testing Scope Process Count : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return count;
	}

	public Integer getTScopeObjectCount(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder("SELECT COUNT(DISTINCT objectTypeObjectName) FROM "
				+ "ExtractedDatapojo WHERE requestid = :requestId AND transactions <> '' AND transactions IS NOT NULL");

		Session session = null;
		Integer count = 0;

		try {
			session = sessionFactory.openSession();
			Query query = session.createQuery(getSQL.toString());
			query.setParameter("requestId", requestId);

			count = ((Long) query.uniqueResult()).intValue();
		} catch (Exception e) {
			logger.error("Error while fetching the Testing Scope Object Count : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return count;
	}

	public Map<String, Integer> getAUCTCounts(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder(
				"SELECT COUNT(CASE WHEN INFO LIKE :unicodeValue THEN OBJ_NAME_TYPE END) AS countUnicode, "
						+ "COUNT(CASE WHEN INFO NOT LIKE :unicodeValue THEN OBJ_NAME_TYPE END) AS countSyntax, "
						+ "COUNT(*) "
						+ "AS countPrecheck FROM Auct_Final_Output WHERE External_Namespace = :extNamespace "
						+ "AND REQUEST_ID = :requestId");

		Session session = null;
		Map<String, Integer> resultMap = new LinkedHashMap<String, Integer>();

		try {
			session = sessionFactory.openSession();
			SQLQuery query = session.createSQLQuery(getSQL.toString());
			query.addScalar("countUnicode", new IntegerType());
			query.addScalar("countSyntax", new IntegerType());
			query.addScalar("countPrecheck", new IntegerType());
			query.setLong("requestId", requestId);
			query.setString("extNamespace", StringUtils.EMPTY);
			query.setString("unicodeValue", "%Unicode%".toUpperCase());

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				resultMap.put("UNICODE", (resultList.get(0)[0] == null) ? 0 : (Integer) resultList.get(0)[0]);
				resultMap.put("SYNTAX", (resultList.get(0)[1] == null) ? 0 : (Integer) resultList.get(0)[1]);
				resultMap.put("PRECHECK", (resultList.get(0)[2] == null) ? 0 : (Integer) resultList.get(0)[2]);
			}
		} catch (Exception e) {
			logger.error("Error while fetching the AUCT Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	public Integer getNonUnicodeCounts(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder(
				"SELECT COUNT(*) AS countNonUnicode FROM UNICODE_Intermediate "
						+ "WHERE External_Namespace = :extNamespace AND Request_Id = :requestId");

		Session session = null;
		Integer count = 0;

		try {
			session = sessionFactory.openSession();
			SQLQuery query = session.createSQLQuery(getSQL.toString());
			query.addScalar("countNonUnicode", new IntegerType());
			query.setLong("requestId", requestId);
			query.setString("extNamespace", StringUtils.EMPTY);

			count = (Integer) query.uniqueResult();
		} catch (Exception e) {
			logger.error("Error while fetching the Non Unicode Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return count;
	}

	public Integer getNonUnicodeExternalNamespaceCounts(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder(
				"SELECT COUNT(*) AS countNonUnicode FROM UNICODE_Intermediate "
						+ "WHERE Request_Id = :requestId AND External_Namespace = :extNmSpc");

		Session session = null;
		Integer count = 0;

		try {
			session = sessionFactory.openSession();
			SQLQuery query = session.createSQLQuery(getSQL.toString());
			query.addScalar("countNonUnicode", new IntegerType());
			query.setLong("requestId", requestId);
			query.setString("extNmSpc", "Y");

			count = (Integer) query.uniqueResult();
		} catch (Exception e) {
			logger.error("Error while fetching the Non Unicode Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return count;
	}

	@Override
	public Integer getInactiveObjCounts(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder(
				"SELECT COUNT(CONCAT(OBJECT, OBJ_NAME)) AS count FROM Inactive_Objects "
						+ "WHERE Request_Id = :requestId");

		Session session = null;
		Integer count = 0;

		try {
			session = sessionFactory.openSession();
			SQLQuery query = session.createSQLQuery(getSQL.toString()).addScalar("count", new IntegerType());
			query.setParameter("requestId", requestId);

			count = (Integer) query.uniqueResult();
		} catch (Exception e) {
			logger.error("Error while fetching the Inactive Objects Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return count;
	}

	@Override
	public Map<String, Integer> getDistinctObjCountHANAS4OSMig(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder("SELECT objCount.usedUnused AS used, COUNT(*) AS count FROM "
				+ "(SELECT DISTINCT OBJ_NAME_TYPE, COALESCE(Used_Unused, '') AS usedUnused FROM FINAL_OUTPUT "
				+ "WHERE Request_ID = :requestId AND External_Namespace = :extNmSpc "
				+ "UNION "
				+ "SELECT DISTINCT OBJ_NAME_TYPE, COALESCE(USED, '') AS usedUnused FROM S4_Final_Output "
				+ "WHERE REQUEST_ID = :requestId AND External_Namespace = :extNmSpc "
				+ "UNION "
				+ "SELECT DISTINCT OBJ_TYPE_NAME, COALESCE(USED, '') AS usedUnused FROM OSMIGRATION_FINAL "
				+ "WHERE REQUEST_ID = :requestId AND External_Namespace = :extNmSpc) objCount "
				+ "GROUP BY used");

		Session session = null;
		Map<String, Integer> resultMap = new LinkedHashMap<>();
		String used = "";
		int count = 0;

		try {
			session = sessionFactory.openSession();
			
			SQLQuery query = session.createSQLQuery(getSQL.toString());
			query.addScalar("used", new StringType());
			query.addScalar("count", new IntegerType());
			query.setLong("requestId", requestId);
			query.setParameter("extNmSpc", StringUtils.EMPTY);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					used = resultObj[0].toString();
					count = (resultObj[1] == null) ? 0 : (Integer) resultObj[1];

					if (used.isEmpty())
						resultMap.put(Hana_Profiler_Constant.UNUSED_ALL_COUNT, count);
					else
						resultMap.put(Hana_Profiler_Constant.USED_ALL_COUNT, count);
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching the HANA, S4 and OS Migration Distinct Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	@Override
	public Map<String, Integer> getDistinctMandObjCountHANAS4OSMig(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder("SELECT objCount.usedUnused AS used, COUNT(*) AS count FROM "
				+ "(SELECT DISTINCT OBJ_NAME_TYPE, COALESCE(Used_Unused, '') AS usedUnused FROM FINAL_OUTPUT "
				+ "WHERE Request_ID = :requestId AND Category = :category AND External_Namespace = :extNmSpc "
				+ "UNION " 
				+ "SELECT DISTINCT OBJ_NAME_TYPE, COALESCE(USED, '') AS usedUnused FROM S4_Final_Output "
				+ "WHERE Request_ID = :requestId AND Remediation_Category = :category AND External_Namespace = :extNmSpc "
				+ "UNION " 
				+ "SELECT DISTINCT OBJ_TYPE_NAME, COALESCE(USED, '') AS usedUnused FROM OSMIGRATION_FINAL "
				+ "WHERE Request_ID = :requestId AND REM_CATEGORY = :category AND External_Namespace = :extNmSpc) objCount "
				+ "GROUP BY used");

		Session session = null;
		Map<String, Integer> resultMap = new LinkedHashMap<>();
		String used = "";
		int count = 0;

		try {
			session = sessionFactory.openSession();
			
			SQLQuery query = session.createSQLQuery(getSQL.toString());
			query.addScalar("used", new StringType());
			query.addScalar("count", new IntegerType());
			query.setLong("requestId", requestId);
			query.setString("category", "Mandatory".toUpperCase());
			query.setParameter("extNmSpc", StringUtils.EMPTY);

			List<Object[]> resultList = query.list();

			for (Object[] resultObj : resultList) {
				used = resultObj[0].toString();
				count = (resultObj[1] == null) ? 0 : (Integer) resultObj[1];

				if (used.isEmpty())
					resultMap.put(Hana_Profiler_Constant.UNUSED_ALL_COUNT, count);
				else
					resultMap.put(Hana_Profiler_Constant.USED_ALL_COUNT, count);
			}
		} catch (Exception e) {
			logger.error("Error while fetching the HANA, S4 and OS Migration Distinct Mandatory Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	@Override
	public Map<String, Integer> getCommonImpactedObjCountHANAS4OSMig(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder(
				"SELECT COALESCE(hanaTable.Used_Unused, '') AS usedUnused, COUNT(DISTINCT hanaTable.OBJ_NAME_TYPE) AS count "
						+ "FROM FINAL_OUTPUT hanaTable "
						+ "INNER JOIN S4_Final_Output s4Table "
						+ "ON "
						+ "hanaTable.OBJ_NAME_TYPE = s4Table.OBJ_NAME_TYPE " 
						+ "INNER JOIN "
						+ "OSMIGRATION_FINAL osTable "
						+ "ON "
						+ "s4Table.OBJ_NAME_TYPE = osTable.OBJ_TYPE_NAME "
						+ "WHERE hanaTable.Request_ID = :requestId AND s4Table.Request_ID = :requestId AND "
						+ "osTable.Request_ID = :requestId AND "
						+ "hanaTable.External_Namespace = :extNmSpc AND s4Table.External_Namespace = :extNmSpc "
						+ "AND osTable.EXTERNAL_NAMESPACE = :extNmSpc GROUP BY usedUnused");

		Session session = null;
		Map<String, Integer> resultMap = new LinkedHashMap<>();
		String used = "";
		int count = 0;

		try {
			session = sessionFactory.openSession();
			
			SQLQuery query = session.createSQLQuery(getSQL.toString());
			query.addScalar("usedUnused", new StringType());
			query.addScalar("count", new IntegerType());
			query.setLong("requestId", requestId);
			query.setParameter("extNmSpc", StringUtils.EMPTY);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					used = resultObj[0].toString();
					count = (resultObj[1] == null) ? 0 : (Integer) resultObj[1];

					if (used.isEmpty())
						resultMap.put(Hana_Profiler_Constant.UNUSED_ALL_COUNT, count);
					else
						resultMap.put(Hana_Profiler_Constant.USED_ALL_COUNT, count);
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching the Common Impacted HANA, S4 and OS Migration Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	@Override
	public Map<String, Integer> getCommonImpactedMandObjCountHANAS4OSMig(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder(
				"SELECT COALESCE(hanaTable.Used_Unused, '') AS usedUnused, COUNT(DISTINCT hanaTable.OBJ_NAME_TYPE) AS count "
						+ "FROM FINAL_OUTPUT hanaTable "
						+ "INNER JOIN S4_Final_Output s4Table "
						+ "ON "
						+ "hanaTable.OBJ_NAME_TYPE = s4Table.OBJ_NAME_TYPE " 
						+ "INNER JOIN "
						+ "OSMIGRATION_FINAL osTable "
						+ "ON "
						+ "s4Table.OBJ_NAME_TYPE = osTable.OBJ_TYPE_NAME "
						+ "WHERE hanaTable.Request_ID = :requestId AND s4Table.Request_ID = :requestId AND "
						+ "osTable.Request_ID = :requestId AND hanaTable.Category = :category AND "
						+ "s4Table.Remediation_Category = :category AND osTable.REM_CATEGORY = :category AND "
						+ "hanaTable.External_Namespace = :extNmSpc AND s4Table.External_Namespace = :extNmSpc "
						+ "AND osTable.EXTERNAL_NAMESPACE = :extNmSpc GROUP BY usedUnused");

		Session session = null;
		Map<String, Integer> resultMap = new LinkedHashMap<>();
		String used = "";
		int count = 0;

		try {
			session = sessionFactory.openSession();
			
			SQLQuery query = session.createSQLQuery(getSQL.toString());
			query.addScalar("usedUnused", new StringType());
			query.addScalar("count", new IntegerType());
			query.setLong("requestId", requestId);
			query.setString("category", "Mandatory".toUpperCase());
			query.setParameter("extNmSpc", StringUtils.EMPTY);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					used = resultObj[0].toString();
					count = (resultObj[1] == null) ? 0 : (Integer) resultObj[1];

					if (used.isEmpty())
						resultMap.put(Hana_Profiler_Constant.UNUSED_ALL_COUNT, count);
					else
						resultMap.put(Hana_Profiler_Constant.USED_ALL_COUNT, count);
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching the Common Mandatory HANA, S4 and OS Migration Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	@Override
	public Map<String, Integer> getDistinctObjCountHANAS4(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder("SELECT objCount.usedUnused as used, COUNT(*) AS count FROM "
				+ "(SELECT DISTINCT OBJ_NAME_TYPE, COALESCE(Used_Unused, '') AS usedUnused FROM FINAL_OUTPUT "
				+ "WHERE Request_ID = :requestId  AND External_Namespace = :extNmSpc "
				+ "UNION "
				+ "SELECT DISTINCT OBJ_NAME_TYPE, COALESCE(USED, '') AS usedUnused FROM S4_Final_Output "
				+ "WHERE REQUEST_ID = :requestId AND External_Namespace = :extNmSpc) objCount "
				+ "GROUP BY used");

		Session session = null;
		Map<String, Integer> resultMap = new LinkedHashMap<>();
		String used = "";
		int count = 0;

		try {
			session = sessionFactory.openSession();
			
			SQLQuery query = session.createSQLQuery(getSQL.toString());
			query.addScalar("used", new StringType());
			query.addScalar("count", new IntegerType());
			query.setLong("requestId", requestId);
			query.setParameter("extNmSpc", StringUtils.EMPTY);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					used = resultObj[0].toString();
					count = (resultObj[1] == null) ? 0 : (Integer) resultObj[1];

					if (used.isEmpty())
						resultMap.put(Hana_Profiler_Constant.UNUSED_ALL_COUNT, count);
					else
						resultMap.put(Hana_Profiler_Constant.USED_ALL_COUNT, count);
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching the HANA and S4 Distinct Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	@Override
	public Map<String, Integer> getDistinctMandObjCountHANAS4(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder("SELECT objCount.usedUnused AS used, COUNT(*) AS count FROM "
				+ "(SELECT DISTINCT OBJ_NAME_TYPE, COALESCE(Used_Unused, '') AS usedUnused FROM FINAL_OUTPUT "
				+ "WHERE Request_ID = :requestId AND Category = :category AND External_Namespace = :extNmSpc "
				+ "UNION " 
				+ "SELECT DISTINCT OBJ_NAME_TYPE, COALESCE(USED, '') AS usedUnused FROM S4_Final_Output "
				+ "WHERE Request_ID = :requestId AND Remediation_Category = :category AND External_Namespace = :extNmSpc) objCount "
				+ "GROUP BY used");

		Session session = null;
		Map<String, Integer> resultMap = new LinkedHashMap<>();
		String used = "";
		int count = 0;

		try {
			session = sessionFactory.openSession();
			
			SQLQuery query = session.createSQLQuery(getSQL.toString());
			query.addScalar("used", new StringType());
			query.addScalar("count", new IntegerType());
			query.setLong("requestId", requestId);
			query.setString("category", "Mandatory".toUpperCase());
			query.setParameter("extNmSpc", StringUtils.EMPTY);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					used = resultObj[0].toString();
					count = (resultObj[1] == null) ? 0 : (Integer) resultObj[1];

					if (used.isEmpty())
						resultMap.put(Hana_Profiler_Constant.UNUSED_ALL_COUNT, count);
					else
						resultMap.put(Hana_Profiler_Constant.USED_ALL_COUNT, count);
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching HANA and S4 Distinct Mandatory Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	@Override
	public Map<String, Integer> getCommonImpactedObjCountHANAS4(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder(
				"SELECT COALESCE(hanaTable.Used_Unused, '') AS usedUnused, COUNT(DISTINCT hanaTable.OBJ_NAME_TYPE) AS count "
						+ "FROM FINAL_OUTPUT hanaTable "
						+ "INNER JOIN "
						+ "S4_Final_Output s4Table "
						+ "ON "
						+ "hanaTable.OBJ_NAME_TYPE = s4Table.OBJ_NAME_TYPE "
						+ "WHERE hanaTable.Request_ID = :requestId AND s4Table.Request_ID = :requestId "
						+ "AND hanaTable.External_Namespace  = :extNamespace AND s4Table.External_Namespace = :extNamespace "
						+ "GROUP BY usedUnused");

		Session session = null;
		Map<String, Integer> resultMap = new LinkedHashMap<>();
		String used = "";
		int count = 0;

		try {
			session = sessionFactory.openSession();
			
			SQLQuery query = session.createSQLQuery(getSQL.toString());
			query.addScalar("usedUnused", new StringType());
			query.addScalar("count", new IntegerType());
			query.setLong("requestId", requestId);
			query.setString("extNamespace", StringUtils.EMPTY);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					used = resultObj[0].toString();
					count = (resultObj[1] == null) ? 0 : (Integer) resultObj[1];

					if (used.isEmpty())
						resultMap.put(Hana_Profiler_Constant.UNUSED_ALL_COUNT, count);
					else
						resultMap.put(Hana_Profiler_Constant.USED_ALL_COUNT, count);
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching the Common Impacted HANA and S4 Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	@Override
	public Map<String, Integer> getCommonImpactedMandObjCountHANAS4(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder(
				"SELECT COALESCE(hanaTable.Used_Unused, '') AS usedUnused, COUNT(DISTINCT hanaTable.OBJ_NAME_TYPE) AS count "
						+ "FROM FINAL_OUTPUT hanaTable "
						+ "INNER JOIN "
						+ "S4_Final_Output s4Table "
						+ "ON "
						+ "hanaTable.OBJ_NAME_TYPE = s4Table.OBJ_NAME_TYPE "
						+ "WHERE hanaTable.Request_ID = :requestId AND s4Table.Request_ID = :requestId "
						+ "AND hanaTable.Category = :category AND s4Table.Remediation_Category = :category "
						+ "AND hanaTable.External_Namespace  = :extNamespace AND s4Table.External_Namespace = :extNamespace "
						+ "GROUP BY usedUnused");

		Session session = null;
		Map<String, Integer> resultMap = new LinkedHashMap<>();
		String used = "";
		int count = 0;

		try {
			session = sessionFactory.openSession();
			
			SQLQuery query = session.createSQLQuery(getSQL.toString());
			query.addScalar("usedUnused", new StringType());
			query.addScalar("count", new IntegerType());
			query.setLong("requestId", requestId);
			query.setString("category", "Mandatory".toUpperCase());
			query.setString("extNamespace", StringUtils.EMPTY);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					used = resultObj[0].toString();
					count = (resultObj[1] == null) ? 0 : (Integer) resultObj[1];

					if (used.isEmpty())
						resultMap.put(Hana_Profiler_Constant.UNUSED_ALL_COUNT, count);
					else
						resultMap.put(Hana_Profiler_Constant.USED_ALL_COUNT, count);
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching the Common Mandatory HANA and S4 Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	@Override
	public Integer getDistinctRoleSIACounts(List<Long> reqIdsList) throws Exception {
		StringBuilder getSQL = new StringBuilder(
				"SELECT COUNT(DISTINCT roleName) FROM SecurityAnalyserTCDReportDownload WHERE requestID IN (");

		for (Iterator<Long> it = reqIdsList.iterator(); it.hasNext();) {
			long requestId = it.next();
			getSQL.append(requestId);
			if (it.hasNext()) {
				getSQL.append(", ");
			}
		}

		getSQL.append(")");

		Session session = null;
		Integer count = 0;

		try {
			session = sessionFactory.openSession();
			Query query = session.createQuery(getSQL.toString());

			count = ((Long) query.uniqueResult()).intValue();
		} catch (Exception e) {
			logger.error("Error while fetching SIA Distinct Roles Count : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return count;
	}
	
	@Override
	public Integer getImpactedRoleSIACounts(List<Long> reqIdsList) throws Exception {
		StringBuilder getSQL = new StringBuilder(
				"SELECT COUNT(DISTINCT roleName) FROM SecurityAnalyserTCDReportDownload WHERE requestID IN (");

		for (Iterator<Long> it = reqIdsList.iterator(); it.hasNext();) {
			long requestId = it.next();
			getSQL.append(requestId);
			if (it.hasNext()) {
				getSQL.append(", ");
			}
		}

		getSQL.append(") AND (status = :modImpact OR status = :fioriImpact OR status = :cleanupImpact)");

		Session session = null;
		Integer count = 0;

		try {
			session = sessionFactory.openSession();
			Query query = session.createQuery(getSQL.toString());
			query.setParameter("modImpact", "Role Needs Immediate Modification as there is a change in transaction code. New tranaction code may bring new auth objects. Object report may have some suggestions for the new tcode.".toUpperCase());
			query.setParameter("fioriImpact", "Role Need Modification Only if FIORI Adopted".toUpperCase());
			query.setParameter("cleanupImpact", "Role Needs Modification for cleanup activity.".toUpperCase());
			
			count = ((Long) query.uniqueResult()).intValue();
		} catch (Exception e) {
			logger.error("Error while fetching SIA Distinct Roles Count : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return count;
	}

	@Override
	public Map<String, Integer> getSIACounts(List<Long> reqIdsList) throws Exception {
		StringBuilder getSQL = new StringBuilder("SELECT status, COUNT(DISTINCT roleName) "
				+ "FROM SecurityAnalyserTCDReportDownload WHERE requestID IN (");

		for (Iterator<Long> it = reqIdsList.iterator(); it.hasNext();) {
			long requestId = it.next();
			getSQL.append(requestId);
			if (it.hasNext()) {
				getSQL.append(", ");
			}
		}

		getSQL.append(") GROUP BY status");

		Session session = null;
		Map<String, Integer> resultMap = new LinkedHashMap<>();
		String status = "";
		int count = 0;

		try {
			session = sessionFactory.openSession();
			Query query = session.createQuery(getSQL.toString());

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					if (resultObj[0] != null) {
						status = resultObj[0].toString().toUpperCase().trim();
						count = (resultObj[1] == null) ? 0 : ((Long) resultObj[1]).intValue();

						resultMap.put(status, count);
					}
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching SIA Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	@Override
	public List<Long> getSIARequestIDsList(List<String> siaRequestIdsList) throws Exception {
		StringBuilder getSQL = new StringBuilder("SELECT requestID FROM RequestForm WHERE REQUEST_ID_UI IN ('");

		for (Iterator<String> it = siaRequestIdsList.iterator(); it.hasNext();) {
			String requestIUId = it.next();
			getSQL.append(requestIUId);
			if (it.hasNext()) {
				getSQL.append("', '");
			}
		}

		getSQL.append("')");

		Session session = null;
		List<Long> resultList = new LinkedList<>();

		try {
			session = sessionFactory.openSession();
			
			Query query = session.createQuery(getSQL.toString());

			resultList = (List<Long>) query.list();
		} catch (Exception e) {
			logger.error("Error while fetching SIA Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultList;
	}

	@Override
	public Map<String, Integer> getImpactedBackgroundJobCounts(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder("SELECT COUNT(DISTINCT CONCAT(OBJECT, OBJECT_NAME)) AS batchJobCount, "
				+ "COUNT(DISTINCT SUB_TYPE) AS programCount FROM Impacted_Background_Job "
				+ "WHERE External_Namespace = :extNamespace AND Request_Id = :requestId");

		Session session = null;
		Map<String, Integer> resultMap = new LinkedHashMap<>();

		try {
			session = sessionFactory.openSession();
			
			SQLQuery query = session.createSQLQuery(getSQL.toString());
			query.addScalar("batchJobCount", new IntegerType());
			query.addScalar("programCount", new IntegerType());
			query.setLong("requestId", requestId);
			query.setString("extNamespace", StringUtils.EMPTY);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					resultMap.put("BATCH JOB COUNT", resultObj[0] == null ? 0 : (Integer) resultObj[0]);
					resultMap.put("PROGRAM COUNT", resultObj[1] == null ? 0 : (Integer) resultObj[1]);
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching Impacted Background Jobs Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	@Override
	public Map<String, Integer> getObjCountOSMig(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder("SELECT COUNT(*), COUNT(DISTINCT objTypeName) FROM OSMigrationFinal "
				+ "WHERE requestID = :requestId AND EXTERNAL_NAMESPACE = :extNamespace");

		Session session = null;
		Map<String, Integer> resultMap = new LinkedHashMap<>();

		try {
			session = sessionFactory.openSession();
			
			Query query = session.createQuery(getSQL.toString());
			query.setParameter("requestId", requestId);
			query.setParameter("extNamespace", StringUtils.EMPTY);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					resultMap.put(Hana_Profiler_Constant.ERROR_COUNT,
							resultObj[0] == null ? 0 : ((Long) resultObj[0]).intValue());
					resultMap.put(Hana_Profiler_Constant.DISTINCT_COUNT,
							resultObj[1] == null ? 0 : ((Long) resultObj[1]).intValue());
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching the OS Migration Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	@Override
	public Map<String, Integer> getMandObjCountOSMig(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder("SELECT COUNT(*), COUNT(DISTINCT objTypeName) FROM OSMigrationFinal "
				+ "WHERE requestID = :requestId AND EXTERNAL_NAMESPACE = :extNamespace AND remCategory = :remCategory");

		Session session = null;
		Map<String, Integer> resultMap = new LinkedHashMap<>();

		try {
			session = sessionFactory.openSession();
			
			Query query = session.createQuery(getSQL.toString());
			query.setParameter("requestId", requestId);
			query.setParameter("remCategory", "Mandatory".toUpperCase());
			query.setParameter("extNamespace", StringUtils.EMPTY);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					resultMap.put(Hana_Profiler_Constant.ERROR_COUNT,
							resultObj[0] == null ? 0 : ((Long) resultObj[0]).intValue());
					resultMap.put(Hana_Profiler_Constant.DISTINCT_COUNT,
							resultObj[1] == null ? 0 : ((Long) resultObj[1]).intValue());
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching the OS Migration Mandatory Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	@Override
	public Integer getLogCommandCountOSMig(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder(
				"SELECT COUNT(*) FROM OSMigrationFinalLogicalCMD_Intermediate WHERE requestID = :requestId AND "
						+ "remCategory = :remCategory");

		Session session = null;
		Integer count = 0;

		try {
			session = sessionFactory.openSession();
			
			Query query = session.createQuery(getSQL.toString());
			query.setParameter("requestId", requestId);
			query.setParameter("remCategory", "Mandatory".toUpperCase());

			count = ((Long) query.uniqueResult()).intValue();
		} catch (Exception e) {
			logger.error("Error while fetching OS Migration Logical Command Count : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return count;
	}

	@Override
	public Integer getLogFilePathCountOSMig(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder(
				"SELECT COUNT(*) FROM OSMigrationFinalFilepath_Intermediate WHERE requestID = :requestId AND "
						+ "remCategory = :remCategory");

		Session session = null;
		Integer count = 0;

		try {
			session = sessionFactory.openSession();
			
			Query query = session.createQuery(getSQL.toString());
			query.setParameter("requestId", requestId);
			query.setParameter("remCategory", "Mandatory".toUpperCase());

			count = ((Long) query.uniqueResult()).intValue();
		} catch (Exception e) {
			logger.error("Error while fetching OS Migration Logical File Path Count : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return count;
	}

	public Map<String, Map<String, Map<String, Integer>>> getRemCatDescOSMigCounts(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder(
				"SELECT remCategory, info, COUNT(*), COUNT(DISTINCT objTypeName) FROM OSMigrationFinal WHERE "
						+ "requestID = :requestId AND EXTERNAL_NAMESPACE = :extNamespace GROUP BY remCategory, info");

		Session session = null;
		Map<String, Map<String, Map<String, Integer>>> resultMap = new LinkedHashMap<>();
		Map<String, Map<String, Integer>> descMap = null;
		Map<String, Integer> countMap = null;

		String remCategory = "", description = "";
		int distinctCount = 0, errorCount = 0;

		try {
			session = sessionFactory.openSession();
			
			Query query = session.createQuery(getSQL.toString());
			query.setParameter("requestId", requestId);
			query.setParameter("extNamespace", StringUtils.EMPTY);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					remCategory = resultObj[0].toString().toUpperCase().trim();
					description = resultObj[1].toString().toUpperCase().trim();
					distinctCount = (resultObj[2] == null) ? 0 : ((Long) resultObj[2]).intValue();
					errorCount = (resultObj[3] == null) ? 0 : ((Long) resultObj[3]).intValue();

					if (resultMap.containsKey(remCategory))
						descMap = resultMap.get(remCategory);
					else
						descMap = new LinkedHashMap<>();

					countMap = new LinkedHashMap<>();

					countMap.put(Hana_Profiler_Constant.ERROR_COUNT, distinctCount);
					countMap.put(Hana_Profiler_Constant.DISTINCT_COUNT, errorCount);

					descMap.put(description, countMap);
					resultMap.put(remCategory, descMap);
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching OS Migration Counts based on Remediation Category and Description : ",
					e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	public Map<String, Map<String, Integer>> getHANAS4ObjectErrorCounts(long requestId, String objTypeCol,
			String usedCol, String requestIdCol, String tableName) throws Exception {
		StringBuilder getSQL = new StringBuilder("SELECT " + objTypeCol + " AS objectType, COALESCE(" + usedCol + ", '') AS usedUnused, "
				+ "COUNT(*) AS count FROM " + tableName + " WHERE " + requestIdCol
				+ " = :requestId AND External_Namespace = :extNmSpc GROUP BY " + objTypeCol + ", usedUnused");

		Session session = null;
		Map<String, Map<String, Integer>> resultMap = new LinkedHashMap<>();
		Map<String, Integer> usedMap = null;
		String objType = "", used = "";
		int count = 0;

		try {
			session = sessionFactory.openSession();
			
			SQLQuery query = session.createSQLQuery(getSQL.toString());
			query.addScalar("objectType", new StringType());
			query.addScalar("usedUnused", new StringType());
			query.addScalar("count", new IntegerType());
			query.setLong("requestId", requestId);
			query.setParameter("extNmSpc", StringUtils.EMPTY);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					if (resultObj[0] != null) {
						objType = resultObj[0].toString().toUpperCase().trim();
						used = resultObj[1].toString();
						count = (resultObj[2] == null) ? 0 : (Integer) resultObj[2];

						if (resultMap.containsKey(objType))
							usedMap = resultMap.get(objType);
						else
							usedMap = new LinkedHashMap<>();

						if (used.isEmpty())
							usedMap.put(Hana_Profiler_Constant.UNUSED_ALL_COUNT, count);
						else
							usedMap.put(Hana_Profiler_Constant.USED_ALL_COUNT, count);

						resultMap.put(objType, usedMap);
					}
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching HANA and S4 Object Error Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	@Override
	public Map<String, Map<String, Map<String, Integer>>> getS4RemCatIssueCatCounts(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder("SELECT remediationCategory, issueCategory, COUNT(*), "
				+ "COUNT(DISTINCT objNameType) FROM S4HanaProfiler WHERE requestID = :requestId "
				+ "AND extNamespace = :extNmSpc GROUP BY remediationCategory, issueCategory");

		Session session = null;
		Map<String, Map<String, Map<String, Integer>>> resultMap = new LinkedHashMap<>();
		Map<String, Map<String, Integer>> issueCatMap = null;
		Map<String, Integer> countMap = null;
		String remCategory = "", issueCategory = "";
		int errorCount = 0, distinctCount = 0;

		try {
			session = sessionFactory.openSession();
			Query query = session.createQuery(getSQL.toString());
			query.setParameter("requestId", requestId);
			query.setParameter("extNmSpc", StringUtils.EMPTY);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					if (resultObj[0] != null) {
						remCategory = resultObj[0].toString().toUpperCase().trim();
						issueCategory = resultObj[1].toString().toUpperCase().trim();
						errorCount = (resultObj[2] == null) ? 0 : ((Long) resultObj[2]).intValue();
						distinctCount = (resultObj[3] == null) ? 0 : ((Long) resultObj[3]).intValue();

						if (resultMap.containsKey(remCategory))
							issueCatMap = resultMap.get(remCategory);
						else
							issueCatMap = new LinkedHashMap<>();

						countMap = new LinkedHashMap<>();
						countMap.put(Hana_Profiler_Constant.ERROR_COUNT, errorCount);
						countMap.put(Hana_Profiler_Constant.DISTINCT_COUNT, distinctCount);

						issueCatMap.put(issueCategory, countMap);

						resultMap.put(remCategory, issueCatMap);
					}
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching the S4 Counts Based on Remediation Category and Issue Category : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	@Override
	public Map<String, Map<String, Integer>> getS4IssueCatCounts(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder("SELECT ISSUE_CATEGORY AS issueCat, COALESCE(USED, '') AS usedUnused, "
				+ "COUNT(*) AS errorCount, COUNT(DISTINCT OBJ_NAME_TYPE) AS distinctCount FROM S4_Final_Output WHERE "
				+ "REQUEST_ID = :requestId AND External_Namespace = :extNmSpc GROUP BY ISSUE_CATEGORY, usedUnused");

		Session session = null;
		Map<String, Map<String, Integer>> resultMap = new LinkedHashMap<>();
		Map<String, Integer> usedMap = null;
		String issueCategory = "", used = "";
		int errorCount = 0, distinctCount = 0;

		try {
			session = sessionFactory.openSession();
			
			SQLQuery query = session.createSQLQuery(getSQL.toString());
			query.addScalar("issueCat", new StringType());
			query.addScalar("usedUnused", new StringType());
			query.addScalar("errorCount", new IntegerType());
			query.addScalar("distinctCount", new IntegerType());
			query.setLong("requestId", requestId);
			query.setParameter("extNmSpc", StringUtils.EMPTY);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					if (resultObj[0] != null) {
						issueCategory = resultObj[0].toString().toUpperCase().trim();
						used = resultObj[1].toString();
						errorCount = (resultObj[2] == null) ? 0 : (Integer) resultObj[2];
						distinctCount = (resultObj[3] == null) ? 0 : (Integer) resultObj[3];

						if (resultMap.containsKey(issueCategory))
							usedMap = resultMap.get(issueCategory);
						else
							usedMap = new LinkedHashMap<>();

						if (used.isEmpty()) {
							usedMap.put(Hana_Profiler_Constant.UNUSED_ALL_COUNT, errorCount);
							usedMap.put(Hana_Profiler_Constant.UNUSED_DISTINCT, distinctCount);
						} else {
							usedMap.put(Hana_Profiler_Constant.USED_ALL_COUNT, errorCount);
							usedMap.put(Hana_Profiler_Constant.USED_DISTINCT, distinctCount);
						}

						resultMap.put(issueCategory, usedMap);
					}
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching S4 Counts Based on Issue Category : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	public Map<String, Integer> getHANAAutoStatusYCounts(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder("SELECT COUNT(*), COUNT(DISTINCT objNameType) FROM HanaProfile WHERE "
				+ "requestID = :requestId AND automation_status = :automationStatus  AND extNamespace = :extNmSpc ");

		Session session = null;
		Map<String, Integer> resultMap = new LinkedHashMap<>();
		int errorCount = 0, distinctCount = 0;

		try {
			session = sessionFactory.openSession();
			Query query = session.createQuery(getSQL.toString());
			query.setParameter("requestId", requestId);
			query.setParameter("automationStatus", "Yes");
			query.setParameter("extNmSpc", StringUtils.EMPTY);

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				errorCount = (resultList.get(0)[0] == null) ? 0 : ((Long) resultList.get(0)[0]).intValue();
				distinctCount = (resultList.get(0)[1] == null) ? 0 : ((Long) resultList.get(0)[1]).intValue();

				resultMap.put(Hana_Profiler_Constant.ERROR_COUNT, errorCount);
				resultMap.put(Hana_Profiler_Constant.DISTINCT_COUNT, distinctCount);
			}
		} catch (Exception e) {
			logger.error("Error while fetching HANA Automatic Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	@Override
	public Map<String, Integer> getExtNamespaceInventoryObjCounts(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder(
				"SELECT COALESCE(Used, '') AS usedUnused, COUNT(OBJ_TYPE) AS distinctCount FROM S4_Inventory_List "
				+ "WHERE REQUEST_ID = :requestId AND External_Namespace = :extNmSpc GROUP BY Used");

		Session session = null;
		Map<String, Integer> resultMap = new LinkedHashMap<>();
		String used = "";
		int count = 0;

		try {
			session = sessionFactory.openSession();
			
			SQLQuery query = session.createSQLQuery(getSQL.toString());
			query.addScalar("usedUnused", new StringType());
			query.addScalar("distinctCount", new IntegerType());
			query.setParameter("requestId", requestId);
			query.setParameter("extNmSpc", "Y");

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					used = resultObj[0].toString();
					count = (resultObj[1] == null) ? 0 : (Integer) resultObj[1];

					if (used.isEmpty())
						resultMap.put(Hana_Profiler_Constant.UNUSED_ALL_COUNT, count);
					else
						resultMap.put(Hana_Profiler_Constant.USED_ALL_COUNT, count);
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching the HANA or S4 External Namespace Impacted Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	@Override
	public Map<String, Integer> getExtNamespaceMandObjCountHANAS4(long requestId, String tableName,
			String remCatColName, String usedColName) throws Exception {
		StringBuilder getSQL = new StringBuilder("SELECT COALESCE(" + usedColName
				+ ", '') AS usedUnused, COUNT(DISTINCT OBJ_NAME_TYPE) AS distinctCount FROM " + tableName 
				+ " WHERE REQUEST_ID = :requestId AND "
				+ remCatColName + " = :remCategory AND External_Namespace = :extNmSpc GROUP BY usedUnused");

		Session session = null;
		Map<String, Integer> resultMap = new LinkedHashMap<>();
		String used = "";
		int count = 0;

		try {
			session = sessionFactory.openSession();
			
			SQLQuery query = session.createSQLQuery(getSQL.toString());
			query.addScalar("usedUnused", new StringType());
			query.addScalar("distinctCount", new IntegerType());
			query.setLong("requestId", requestId);
			query.setParameter("remCategory", "Mandatory".toUpperCase());
			query.setParameter("extNmSpc", "Y");

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					used = resultObj[0].toString();
					count = (resultObj[1] == null) ? 0 : (Integer) resultObj[1];

					if (used.isEmpty())
						resultMap.put(Hana_Profiler_Constant.UNUSED_ALL_COUNT, count);
					else
						resultMap.put(Hana_Profiler_Constant.USED_ALL_COUNT, count);
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching the HANA or S4 External Namespace Impacted Mandatory Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	@Override
	public Map<String, Integer> getCommonExtNamespaceImpactedObjCountHANAS4(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder(
				"SELECT COALESCE(hanaTable.Used_Unused, '') AS usedUnused, COUNT(DISTINCT hanaTable.OBJ_NAME_TYPE) AS count "
						+ "FROM FINAL_OUTPUT hanaTable "
						+ "INNER JOIN S4_Final_Output s4Table "
						+ "ON "
						+ "hanaTable.OBJ_NAME_TYPE = s4Table.OBJ_NAME_TYPE "
						+ "WHERE hanaTable.Request_ID = :requestId AND s4Table.Request_ID = :requestId "
						+ "AND hanaTable.External_Namespace = :extNmSpc AND s4Table.External_Namespace = :extNmSpc "
						+ "GROUP BY usedUnused");

		Session session = null;
		Map<String, Integer> resultMap = new LinkedHashMap<>();
		String used = "";
		int count = 0;

		try {
			session = sessionFactory.openSession();
			
			SQLQuery query = session.createSQLQuery(getSQL.toString());
			query.addScalar("usedUnused", new StringType());
			query.addScalar("count", new IntegerType());
			query.setLong("requestId", requestId);
			query.setString("extNmSpc", "Y");

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					used = resultObj[0].toString();
					count = (resultObj[1] == null) ? 0 : (Integer) resultObj[1];

					if (used.isEmpty())
						resultMap.put(Hana_Profiler_Constant.UNUSED_ALL_COUNT, count);
					else
						resultMap.put(Hana_Profiler_Constant.USED_ALL_COUNT, count);
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching the Common Impacted HANA and S4 Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	@Override
	public Map<String, Integer> getCommonExtNamespaceImpactedMandObjCountHANAS4(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder(
				"SELECT COALESCE(hanaTable.Used_Unused, '') AS usedUnused, COUNT(DISTINCT hanaTable.OBJ_NAME_TYPE) AS count "
						+ "FROM FINAL_OUTPUT hanaTable "
						+ "INNER JOIN S4_Final_Output s4Table "
						+ "ON "
						+ "hanaTable.OBJ_NAME_TYPE = s4Table.OBJ_NAME_TYPE "
						+ "WHERE hanaTable.Request_ID = :requestId AND s4Table.Request_ID = :requestId "
						+ "AND hanaTable.Category = :remCategory AND s4Table.Remediation_Category = :remCategory "
						+ "AND hanaTable.External_Namespace = :extNmSpc AND s4Table.External_Namespace = :extNmSpc "
						+ "GROUP BY usedUnused");

		Session session = null;
		Map<String, Integer> resultMap = new LinkedHashMap<>();
		String used = "";
		int count = 0;

		try {
			session = sessionFactory.openSession();
			
			SQLQuery query = session.createSQLQuery(getSQL.toString());
			query.addScalar("usedUnused", new StringType());
			query.addScalar("count", new IntegerType());
			query.setLong("requestId", requestId);
			query.setString("remCategory", "Mandatory".toUpperCase());
			query.setString("extNmSpc", "Y");

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				for (Object[] resultObj : resultList) {
					used = resultObj[0].toString();
					count = (resultObj[1] == null) ? 0 : (Integer) resultObj[1];

					if (used.isEmpty())
						resultMap.put(Hana_Profiler_Constant.UNUSED_ALL_COUNT, count);
					else
						resultMap.put(Hana_Profiler_Constant.USED_ALL_COUNT, count);
				}
			}
		} catch (Exception e) {
			logger.error("Error while fetching the Common Mandatory HANA and S4 Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	@Override
	public Map<String, Integer> getExtNamespaceAUCTCounts(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder(
				"SELECT COUNT(CASE WHEN INFO LIKE :unicodeValue THEN OBJ_NAME_TYPE END) AS countUnicode, "
						+ "COUNT(CASE WHEN INFO NOT LIKE :unicodeValue THEN OBJ_NAME_TYPE END) AS countSyntax, "
						+ "COUNT(*) "
						+ "AS countPrecheck FROM Auct_Final_Output WHERE REQUEST_ID = :requestId AND External_Namespace = :extNmSpc");

		Session session = null;
		Map<String, Integer> resultMap = new LinkedHashMap<String, Integer>();

		try {
			session = sessionFactory.openSession();
			SQLQuery query = session.createSQLQuery(getSQL.toString());
			query.addScalar("countUnicode", new IntegerType());
			query.addScalar("countSyntax", new IntegerType());
			query.addScalar("countPrecheck", new IntegerType());
			query.setLong("requestId", requestId);
			query.setString("unicodeValue", "%Unicode%");
			query.setString("extNmSpc", "Y");

			List<Object[]> resultList = query.list();

			if (CollectionUtils.isNotEmpty(resultList)) {
				resultMap.put("UNICODE_EXTNAMESPACE",
						(resultList.get(0)[0] == null) ? 0 : (Integer) resultList.get(0)[0]);
				resultMap.put("SYNTAX_EXTNAMESPACE",
						(resultList.get(0)[1] == null) ? 0 : (Integer) resultList.get(0)[1]);
				resultMap.put("PRECHECK_EXTNAMESPACE",
						(resultList.get(0)[2] == null) ? 0 : (Integer) resultList.get(0)[2]);
			}
		} catch (Exception e) {
			logger.error("Error while fetching the AUCT External Namespace Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return resultMap;
	}

	@Override
	public void saveReqMasterData(ProcessedRequestMaster processedReqMaster) {
		Session session = null;
		Transaction tx = null;

		try {
			session = sessionFactory.openSession();
			tx = session.beginTransaction();

			session.merge("ProcessedRequestMaster", processedReqMaster);
			tx.commit();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();

			logger.error("Error while saving the Request Master Data : ", e);
		} finally {
			if (session != null)
				session.close();
		}
	}

	@Override
	public void saveReqMasterCountsData(List<ProcessedRMCounts> reqMasterCountsList) {
		Session session = null;
		Transaction tx = null;

		try {
			session = sessionFactory.openSession();
			tx = session.beginTransaction();

			for (int i = 0; i < reqMasterCountsList.size(); i++) {
				ProcessedRMCounts reqMasterObj = reqMasterCountsList.get(i);
				session.save(reqMasterObj);

				if (i % 50 == 0) {
					session.flush();
					session.clear();
				}
			}

			tx.commit();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();

			logger.error("Error while saving the Request Master Counts(ProcessedRMCounts) : ", e);
		} finally {
			if (session != null)
				session.close();
		}
	}
	
	@Override
	public List<ProcessedRequestMaster> getReqMasterData() {
		List<ProcessedRequestMaster> masterDataList = null;
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Transaction tx = session.beginTransaction();
			Query query = session.createQuery("from ProcessedRequestMaster");
			 masterDataList = query.list();

		} catch (Exception e) {
			logger.error("getReqMasterData :: ", e);
		} finally {
			if (null != session) {
				session.close();
			}
		}
		return masterDataList;
	}
}
