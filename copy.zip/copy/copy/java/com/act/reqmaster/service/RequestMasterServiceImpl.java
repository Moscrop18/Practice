package com.act.reqmaster.service;

import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.act.client.dao.RequestFormDAO;
import com.act.client.model.RequestForm;
import com.act.constant.Hana_Profiler_Constant;
import com.act.master.ProcessedRMCounts;
import com.act.master.ProcessedRequestMaster;
import com.act.master.ProcessedRequestMasterModel;
import com.act.reqmaster.dao.RequestMasterDAO;
import com.act.utility.AppGenUtility;

@Service
public class RequestMasterServiceImpl implements RequestMasterService {

	@Autowired
	private RequestMasterDAO reqMasterDAO;

	@Autowired
	private RequestFormDAO reqFormDAO;

	private final Logger logger = LoggerFactory.getLogger(RequestMasterServiceImpl.class);

	@Override
	public void getRequestMasterCounts(long requestId, List<String> siaReqIDsList) throws Exception {
		RequestForm requestFormObj = reqFormDAO.getRequestObj(requestId);

		ProcessedRequestMaster commonReqFormFields = null, commonHANAS4OSAUCTCounts = null, commonHANAS4OSCounts = null,
				commonHANAS4AUCTCounts = null, commonHANAS4Counts = null;

		Set<ProcessedRequestMaster> reqMasterSet = null;

		try {
			if (requestFormObj != null) {
				if (requestFormObj.getSOH() || requestFormObj.getS4Technical() || requestFormObj.getOsMig()
						|| requestFormObj.getUPGRADE() || requestFormObj.getFiori() || requestFormObj.getSia()) {
					commonReqFormFields = getRequestFormFields(requestId, requestFormObj);
				}

				if (requestFormObj.getSOH() || requestFormObj.getS4Technical() || requestFormObj.getOsMig()
						|| requestFormObj.getUPGRADE()) {
					commonHANAS4OSAUCTCounts = getCommonHANAS4OSAUCTCounts(requestId);
				}

				if (requestFormObj.getSOH() || requestFormObj.getS4Technical() || requestFormObj.getOsMig()) {
					commonHANAS4OSCounts = getCommonHANAS4OSMigCounts(requestId);
				}

				if (requestFormObj.getSOH() || requestFormObj.getS4Technical() || requestFormObj.getUPGRADE()) {
					commonHANAS4AUCTCounts = getHANAS4AUCTCounts(requestId);
				}

				if (requestFormObj.getSOH() || requestFormObj.getS4Technical()) {
					commonHANAS4Counts = getHANAS4Counts(requestId);
				}

				if (requestFormObj.getSOH()) {
					reqMasterSet = new LinkedHashSet<>();

					reqMasterSet.add(commonReqFormFields);
					reqMasterSet.add(commonHANAS4Counts);
					reqMasterSet.add(commonHANAS4AUCTCounts);
					reqMasterSet.add(commonHANAS4OSCounts);
					reqMasterSet.add(commonHANAS4OSAUCTCounts);

					getHANACounts(requestId, reqMasterSet);
				}

				if (requestFormObj.getS4Technical()) {
					reqMasterSet = new LinkedHashSet<>();

					reqMasterSet.add(commonReqFormFields);
					reqMasterSet.add(commonHANAS4Counts);
					reqMasterSet.add(commonHANAS4AUCTCounts);
					reqMasterSet.add(commonHANAS4OSCounts);
					reqMasterSet.add(commonHANAS4OSAUCTCounts);

					getS4Counts(requestId, reqMasterSet);
				}

				if (requestFormObj.getUPGRADE()) {
					reqMasterSet = new LinkedHashSet<>();

					reqMasterSet.add(commonReqFormFields);
					reqMasterSet.add(commonHANAS4AUCTCounts);
					reqMasterSet.add(commonHANAS4OSAUCTCounts);

					getAUCTCounts(requestId, reqMasterSet, requestFormObj);
				}

				if (requestFormObj.getOsMig()) {
					reqMasterSet = new LinkedHashSet<>();

					reqMasterSet.add(commonReqFormFields);
					reqMasterSet.add(commonHANAS4OSCounts);
					reqMasterSet.add(commonHANAS4OSAUCTCounts);

					getOSMigrationCounts(requestId, reqMasterSet);
				}

				if (requestFormObj.getFiori()) {
					reqMasterSet = new LinkedHashSet<>();

					reqMasterSet.add(commonReqFormFields);

					getFioriCounts(requestId, reqMasterSet);
				}

				if (requestFormObj.getSia()) {
					reqMasterSet = new LinkedHashSet<>();

					reqMasterSet.add(commonReqFormFields);

					getSIACounts(requestId, siaReqIDsList, reqMasterSet);
				}
			}
		} catch (Exception e) {
			logger.error("Error while calculating Request Master Counts : ", e);
			throw new Exception();
		}
	}

	private ProcessedRequestMaster getRequestFormFields(long requestId, RequestForm requestForm) throws Exception {
		ProcessedRequestMaster commonReqFormFields = new ProcessedRequestMaster();

		try {
			if (requestForm != null) {
				// Setting Request Form Fields
				commonReqFormFields.setRequestId(requestId);
				commonReqFormFields.setClientName(requestForm.getClientName());
				commonReqFormFields.setIndGrp(requestForm.getIndustryGroup());
				commonReqFormFields.setSrcSystem(requestForm.getSourceVersion());
				commonReqFormFields.setTarSystem(requestForm.getTargetVersion());
				commonReqFormFields.setClientPOCEmail(requestForm.getClientTeamDetails());
				commonReqFormFields.setProjectPOCEmail(requestForm.getProjectPocId());
				commonReqFormFields.setClientType(requestForm.getClienttype());
				commonReqFormFields.setDbSize(requestForm.getDbSize());
				commonReqFormFields.setMarketUnit(requestForm.getMarketUnit());
				commonReqFormFields.setIndSubGrp(requestForm.getIndustrySubGroup());
			}
		} catch (Exception e) {
			logger.error("Error while setting Request Form Fields : ", e);
			throw new Exception();
		}

		return commonReqFormFields;
	}

	private ProcessedRequestMaster getCommonHANAS4OSAUCTCounts(long requestId) throws Exception {
		ProcessedRequestMaster processedReqMasterCommon = new ProcessedRequestMaster();

		try {
			// Setting Inventory Counts
			setInventoryObjectCounts(reqMasterDAO.getInventoryObjectCounts(requestId), processedReqMasterCommon);

			// Setting Inventory External Namespace Counts
			setExtNamespaceInventoryObjCounts(reqMasterDAO.getExtNamespaceInventoryObjCounts(requestId),
					processedReqMasterCommon);

			// Setting Impacted Clone Counts
			setImpactedCloneAnalysisCounts(reqMasterDAO.getDistinctCloneObjCount(requestId), processedReqMasterCommon);
			setTotalImpCloneObjCounts(reqMasterDAO.getTotalCloneObjects(requestId), processedReqMasterCommon);
		} catch (Exception e) {
			logger.error("Error while setting Common Counts (HANA, S4, AUCT and OS Migration) : ", e);
			throw new Exception();
		}

		return processedReqMasterCommon;
	}

	private ProcessedRequestMaster getCommonHANAS4OSMigCounts(long requestId) throws Exception {
		ProcessedRequestMaster processedReqMasterCommon = new ProcessedRequestMaster();

		try {
			// Setting Distinct Counts(HANA, S4 and OS Migration)
			setDistinctObjCountHANAS4OSMig(reqMasterDAO.getDistinctObjCountHANAS4OSMig(requestId),
					reqMasterDAO.getDistinctMandObjCountHANAS4OSMig(requestId),
					reqMasterDAO.getCommonImpactedObjCountHANAS4OSMig(requestId),
					reqMasterDAO.getCommonImpactedMandObjCountHANAS4OSMig(requestId), processedReqMasterCommon);

			// Setting Impacted Background Jobs Counts
			setImpactedBackgroundJobCounts(reqMasterDAO.getImpactedBackgroundJobCounts(requestId),
					processedReqMasterCommon);
		} catch (Exception e) {
			logger.error("Error while setting Common Counts (HANA, S4 and OS Migration) : ", e);
			throw new Exception();
		}

		return processedReqMasterCommon;
	}

	private ProcessedRequestMaster getHANAS4AUCTCounts(long requestId) throws Exception {
		ProcessedRequestMaster processedReqMasterCommon = new ProcessedRequestMaster();

		try {
			// Setting Smodilog Counts
			setSmodilogObjCounts(reqMasterDAO.getSmodilogDistinctObjCount(requestId), processedReqMasterCommon);

			// Setting TestingScope Counts
			setTScopeCounts(reqMasterDAO.getTScopeProcessCount(requestId), reqMasterDAO.getTScopeObjectCount(requestId),
					processedReqMasterCommon);
		} catch (Exception e) {
			logger.error("Error while setting Common Counts (HANA, S4 and AUCT) : ", e);
			throw new Exception();
		}

		return processedReqMasterCommon;
	}

	private ProcessedRequestMaster getHANAS4Counts(long requestId) throws Exception {
		ProcessedRequestMaster processedReqMasterCommon = new ProcessedRequestMaster();

		try {
			// Setting Impacted Object Counts
			setImpactedObjCounts(reqMasterDAO.getImpactedObjectCounts(requestId), processedReqMasterCommon);

			// Setting HANA and S4 Common Counts
			setDistinctObjCountHANAS4(reqMasterDAO.getDistinctObjCountHANAS4(requestId),
					reqMasterDAO.getDistinctMandObjCountHANAS4(requestId),
					reqMasterDAO.getCommonImpactedObjCountHANAS4(requestId),
					reqMasterDAO.getCommonImpactedMandObjCountHANAS4(requestId), processedReqMasterCommon);

			// Setting HANA and S4 External Namespace Counts
			setCommonHANAS4ExtNamespaceCounts(reqMasterDAO.getCommonExtNamespaceImpactedObjCountHANAS4(requestId),
					reqMasterDAO.getCommonExtNamespaceImpactedMandObjCountHANAS4(requestId), processedReqMasterCommon);

		} catch (Exception e) {
			logger.error("Error while setting Common Counts (HANA and S4) : ", e);
			throw new Exception();
		}

		return processedReqMasterCommon;
	}

	private void getHANACounts(long requestId, Set<ProcessedRequestMaster> reqMasterSet) throws Exception {
		logger.info("Calculating HANA Counts --- Start ...");

		ProcessedRequestMaster processedReqMaster = new ProcessedRequestMaster();

		try {
			// Setting Common Counts
			for (ProcessedRequestMaster reqMaster : reqMasterSet) {
				if (reqMaster != null)
					BeanUtils.copyProperties(reqMaster, processedReqMaster,
							AppGenUtility.getNullPropertyNames(reqMaster));
			}

			// Setting Impacted Object Counts w.r.t HANA
			setImpactedObjHANAS4Counts(reqMasterDAO.getImpactedObjCountHANA(requestId, StringUtils.EMPTY),
					processedReqMaster);

			// Setting External Namespaces Impacted Object Counts w.r.t HANA
			setExtNamespaceImpactedHANAS4Counts(reqMasterDAO.getImpactedObjCountHANA(requestId, "Y"),
					processedReqMaster);

			// Setting Application Level Optimization HANA Counts
			setAppLevelHANACounts(reqMasterDAO.getAppLevelHANACounts(requestId), processedReqMaster);

			// Setting DB Level Optimization HANA Counts
			setDBLevelHANACounts(reqMasterDAO.getDBLevelHouskeepHANACounts(requestId, "DB Level HANA Optimization".toUpperCase()),
					processedReqMaster);

			// Setting HANA Housekeeping Counts
			setHousekeepingHANACounts(reqMasterDAO.getDBLevelHouskeepHANACounts(requestId, "Housekeeping for HANA".toUpperCase()),
					processedReqMaster);

			// Setting HANA Counts Based on Remediation Category and Automation
			// Status
			setRemCatAutomationHANACounts(reqMasterDAO.getRemCatAutomationHANACounts(requestId), processedReqMaster);

			// Setting Mandatory HANA Counts
			setMandatoryHANACounts(reqMasterDAO.getMandatoryHANACounts(requestId), processedReqMaster);

			// Setting Remediation Category HANA Counts
			setRemCatHANACounts(reqMasterDAO.getRemCatHANACounts(requestId), processedReqMaster);

			// Setting RemCatIssueCat HANA Counts
			setRemCatIssueCatHANACounts(reqMasterDAO.getRemCatIssueCatHANACounts(requestId), processedReqMaster);

			// Setting HANA Percentage Counts Based on Automation Status
			autoStatusPercHANACounts(reqMasterDAO.getRemCatAutomationHANACounts(requestId), processedReqMaster);

			// Setting Impacted Clone Counts w.r.t HANA
			setRefImpactedCloneObjectsHANAS4(reqMasterDAO.getDistinctCloneObjCountHANAS4(requestId, "impactedDB"),
					reqMasterDAO.getImpactedCloneObjectRefCountsHANAS4(requestId, "impactedDB"), processedReqMaster);

			// Setting HANA Error Counts
			setErrorObjectCounts(reqMasterDAO.getHANAS4ObjectErrorCounts(requestId, "Object_Type", "Used_Unused",
					"Request_ID", "FINAL_OUTPUT"), processedReqMaster);

			// Setting HANA Automation Counts
			setHANAAutoStatusYCounts(reqMasterDAO.getHANAAutoStatusYCounts(requestId), processedReqMaster);

			// Setting HANA Mandatory External Namespace Counts
			setExtNamespaceMandHANAS4Counts(
					reqMasterDAO.getExtNamespaceMandObjCountHANAS4(requestId, "FINAL_OUTPUT", "Category", "Used_Unused"),
					processedReqMaster);

			// Setting Scope
			processedReqMaster.setScope("HANA");

			// Saving the Request Master Data
			reqMasterDAO.saveReqMasterData(processedReqMaster);
		} catch (Exception e) {
			logger.error("Error while setting HANA Counts : ", e);
			throw new Exception();
		} finally {
			logger.info("Calculating HANA Counts --- End ...");
		}
	}

	private void getS4Counts(long requestId, Set<ProcessedRequestMaster> reqMasterSet) throws Exception {
		logger.info("Calculating S4 Counts --- Start ...");

		ProcessedRequestMaster processedReqMaster = new ProcessedRequestMaster();

		try {
			List<ProcessedRMCounts> reqMasterCountsList = new LinkedList<>();

			// Setting Common Counts
			for (ProcessedRequestMaster reqMaster : reqMasterSet) {
				if (reqMaster != null)
					BeanUtils.copyProperties(reqMaster, processedReqMaster,
							AppGenUtility.getNullPropertyNames(reqMaster));
			}

			// Setting Impacted Object Counts w.r.t S4
			setImpactedObjHANAS4Counts(reqMasterDAO.getImpactedObjCountS4(requestId, StringUtils.EMPTY),
					processedReqMaster);

			// Setting External Namespaces Impacted Object Counts w.r.t HANA
			setExtNamespaceImpactedHANAS4Counts(
					reqMasterDAO.getImpactedObjCountS4(requestId, "Y"), processedReqMaster);

			// Setting S4 Counts Based on Remediation Category
			setRemCatS4Counts(reqMasterDAO.getRemCatS4Counts(requestId), processedReqMaster);

			// Setting S4 Counts Based on Remediation Category and Complexity
			setRemCatCompS4Counts(reqMasterDAO.getRemCatCompS4Counts(requestId), processedReqMaster);

			// Setting S4 Counts Based on SAP Simplification Category
			setSAPSimpCatS4Counts(reqMasterDAO.getS4Counts(requestId, "sapSimplCategry"), processedReqMaster);

			// Setting S4 Counts Based on Issue Category
			setIssueCatS4Counts(reqMasterDAO.getS4IssueCatCounts(requestId), processedReqMaster);

			// Setting S4 Counts Based on Item Area
			setItemAreaS4Counts(reqMasterDAO.getS4Counts(requestId, "itemArea"), reqMasterCountsList, requestId);

			// Setting S4 Impacted Standard Transactions
			setImpactedStdTransS4Count(reqMasterDAO.getImpStdTransCount(requestId), processedReqMaster);

			// Setting Impacted Clone Counts w.r.t S4
			setRefImpactedCloneObjectsHANAS4(reqMasterDAO.getDistinctCloneObjCountHANAS4(requestId, "impactedSimpl"),
					reqMasterDAO.getImpactedCloneObjectRefCountsHANAS4(requestId, "impactedSimpl"), processedReqMaster);

			// Setting S4 Error Counts
			setErrorObjectCounts(
					reqMasterDAO.getHANAS4ObjectErrorCounts(requestId, "TYPE", "Used", "REQUEST_ID", "S4_Final_Output"),
					processedReqMaster);

			// Setting S4 Counts Based on Reqmediation Category and Issue
			// Category
			setS4RemCatIssueCatCounts(reqMasterDAO.getS4RemCatIssueCatCounts(requestId), processedReqMaster);

			// Setting S4 Mandatory External Namespace Counts
			setExtNamespaceMandHANAS4Counts(reqMasterDAO.getExtNamespaceMandObjCountHANAS4(requestId, "S4_Final_Output",
					"Remediation_Category", "Used"), processedReqMaster);

			// Setting Scope
			processedReqMaster.setScope("S4");

			// Saving the Request Master Data
			reqMasterDAO.saveReqMasterData(processedReqMaster);
			reqMasterDAO.saveReqMasterCountsData(reqMasterCountsList);
		} catch (Exception e) {
			logger.error("Error while setting S4 Counts : ", e);
			throw new Exception();
		} finally {
			logger.info("Calculating S4 Counts --- End ...");
		}
	}

	private void getAUCTCounts(long requestId, Set<ProcessedRequestMaster> reqMasterSet, RequestForm requestFormObj)
			throws Exception {
		logger.info("Calculating AUCT Counts --- Start ...");

		ProcessedRequestMaster processedReqMaster = new ProcessedRequestMaster();

		try {
			// Setting Common Counts
			for (ProcessedRequestMaster reqMaster : reqMasterSet) {
				if (reqMaster != null)
					BeanUtils.copyProperties(reqMaster, processedReqMaster,
							AppGenUtility.getNullPropertyNames(reqMaster));
			}

			// Setting AUCT Counts
			setAUCTDescOfChangeCounts(reqMasterDAO.getInactiveObjCounts(requestId),
					reqMasterDAO.getAUCTCounts(requestId), processedReqMaster, requestFormObj,
					reqMasterDAO.getNonUnicodeCounts(requestId));

			// Setting AUCT External Namespace Counts
			setExtNamespaceAUCTCounts(reqMasterDAO.getExtNamespaceAUCTCounts(requestId), processedReqMaster,
					requestFormObj, reqMasterDAO.getNonUnicodeExternalNamespaceCounts(requestId));

			// Setting Scope
			processedReqMaster.setScope("Upgrade");

			// Saving the Request Master Data
			reqMasterDAO.saveReqMasterData(processedReqMaster);
		} catch (Exception e) {
			logger.error("Error while setting AUCT Counts : ", e);
			throw new Exception();
		} finally {
			logger.info("Calculating AUCT Counts --- End ...");
		}
	}

	private void getFioriCounts(long requestId, Set<ProcessedRequestMaster> reqMasterSet) throws Exception {
		logger.info("Calculating Fiori Counts --- Start ...");

		ProcessedRequestMaster processedReqMaster = new ProcessedRequestMaster();

		try {
			// Setting Common Counts
			for (ProcessedRequestMaster reqMaster : reqMasterSet) {
				if (reqMaster != null)
					BeanUtils.copyProperties(reqMaster, processedReqMaster,
							AppGenUtility.getNullPropertyNames(reqMaster));
			}

			// Setting Fiori Counts

			// Setting Scope
			processedReqMaster.setScope("Fiori");

			// Saving the Request Master Data
			reqMasterDAO.saveReqMasterData(processedReqMaster);
		} catch (Exception e) {
			logger.error("Error while setting Fiori Counts : ", e);
			throw new Exception();
		} finally {
			logger.info("Calculating Fiori Counts --- End ...");
		}
	}

	private void getSIACounts(long requestId, List<String> siaReqIDsList, Set<ProcessedRequestMaster> reqMasterSet)
			throws Exception {
		logger.info("Calculating SIA Counts --- Start ...");

		ProcessedRequestMaster processedReqMaster = new ProcessedRequestMaster();
		List<Long> reqIDsList = new LinkedList<>();

		try {
			// Setting Common Counts
			for (ProcessedRequestMaster reqMaster : reqMasterSet) {
				if (reqMaster != null)
					BeanUtils.copyProperties(reqMaster, processedReqMaster,
							AppGenUtility.getNullPropertyNames(reqMaster));
			}

			if (CollectionUtils.isNotEmpty(siaReqIDsList))
				reqIDsList = reqMasterDAO.getSIARequestIDsList(siaReqIDsList);
			else
				reqIDsList.add(requestId);

			// Setting SIA Counts
			if (CollectionUtils.isNotEmpty(reqIDsList))
				setSIACounts(reqMasterDAO.getSIACounts(reqIDsList), reqMasterDAO.getImpactedRoleSIACounts(reqIDsList),
						reqMasterDAO.getDistinctRoleSIACounts(reqIDsList), processedReqMaster);

			// Setting Scope
			processedReqMaster.setScope("SIA");

			// Saving the Request Master Data
			reqMasterDAO.saveReqMasterData(processedReqMaster);
		} catch (Exception e) {
			logger.error("Error while setting SIA Counts : ", e);
			throw new Exception();
		} finally {
			logger.info("Calculating SIA Counts --- End ...");
		}
	}

	private void getOSMigrationCounts(long requestId, Set<ProcessedRequestMaster> reqMasterSet) throws Exception {
		logger.info("Calculating OS Migration Counts --- Start ...");

		ProcessedRequestMaster processedReqMaster = new ProcessedRequestMaster();

		try {
			// Setting Common Counts
			for (ProcessedRequestMaster reqMaster : reqMasterSet) {
				if (reqMaster != null)
					BeanUtils.copyProperties(reqMaster, processedReqMaster,
							AppGenUtility.getNullPropertyNames(reqMaster));
			}

			// Setting OS Migration Counts
			setOSMigCounts(reqMasterDAO.getObjCountOSMig(requestId), reqMasterDAO.getMandObjCountOSMig(requestId),
					processedReqMaster);

			// Setting OS Migration Logical File Path and Command Counts
			setLogFilePathCmdOSMigCounts(reqMasterDAO.getLogCommandCountOSMig(requestId),
					reqMasterDAO.getLogFilePathCountOSMig(requestId), processedReqMaster);

			// Setting OS Migration Counts based on Remediation Category and
			// Description
			setRemCatDescOSMigCounts(reqMasterDAO.getRemCatDescOSMigCounts(requestId), processedReqMaster);

			// Setting Scope
			processedReqMaster.setScope("OS Migration");

			// Saving the Request Master Data
			reqMasterDAO.saveReqMasterData(processedReqMaster);
		} catch (Exception e) {
			logger.error("Error while setting OS Migration Counts : ", e);
			throw new Exception();
		} finally {
			logger.info("Calculating OS Migration Counts --- End ...");
		}
	}

	private void setInventoryObjectCounts(Map<String, Map<String, Integer>> invMap,
			ProcessedRequestMaster processedReqMaster) {
		int totalInvUsedObjCount = 0, totalInvUnusedObjCount = 0;

		totalInvUnusedObjCount = getTotalUsedCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, invMap);
		totalInvUsedObjCount = getTotalUsedCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap);

		processedReqMaster.setTotalInventoryUsedObj(totalInvUsedObjCount);
		processedReqMaster.setTotalInventoryObj(totalInvUnusedObjCount + totalInvUsedObjCount);

		processedReqMaster.setTotalInventoryUnusedObj(totalInvUnusedObjCount);

		if ((totalInvUnusedObjCount + totalInvUsedObjCount) != 0) {
			processedReqMaster.setTotalInvenoryUsedObjPercentage(
					((float) totalInvUsedObjCount / (float) (totalInvUnusedObjCount + totalInvUsedObjCount)) * 100);
			processedReqMaster.setTotalInvenoryUnusedObjPercentage(
					((float) totalInvUnusedObjCount / (float) (totalInvUnusedObjCount + totalInvUsedObjCount)) * 100);
		}

		processedReqMaster.setTotalInvPROG(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, invMap.get("PROG"))
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("PROG")));
		processedReqMaster
				.setTotalInvUsedPROG(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("PROG")));

		processedReqMaster.setTotalInvFUGR(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, invMap.get("FUGR"))
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("FUGR")));
		processedReqMaster
				.setTotalInvUsedFUGR(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("FUGR")));

		processedReqMaster.setTotalInvCLAS(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, invMap.get("CLAS"))
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("CLAS")));
		processedReqMaster
				.setTotalInvUsedCLAS(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("CLAS")));

		processedReqMaster.setTotalInvENHO(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, invMap.get("ENHO"))
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("ENHO")));
		processedReqMaster
				.setTotalInvUsedENHO(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("ENHO")));

		processedReqMaster.setTotalInvENHC(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, invMap.get("ENHC"))
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("ENHC")));
		processedReqMaster
				.setTotalInvUsedENHC(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("ENHC")));

		processedReqMaster.setTotalInvLSMW(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, invMap.get("LSMW"))
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("LSMW")));
		processedReqMaster
				.setTotalInvUsedLSMW(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("LSMW")));

		processedReqMaster.setTotalInvFUGS(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, invMap.get("FUGS"))
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("FUGS")));
		processedReqMaster
				.setTotalInvUsedFUGS(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("FUGS")));

		processedReqMaster.setTotalInvSSFO(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, invMap.get("SSFO"))
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("SSFO")));
		processedReqMaster
				.setTotalInvUsedSSFO(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("SSFO")));

		processedReqMaster.setTotalInvDTEL(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, invMap.get("DTEL"))
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("DTEL")));
		processedReqMaster
				.setTotalInvUsedDTEL(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("DTEL")));

		processedReqMaster.setTotalInvENHS(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, invMap.get("ENHS"))
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("ENHS")));
		processedReqMaster
				.setTotalInvUsedENHS(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("ENHS")));

		processedReqMaster.setTotalInvWDYN(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, invMap.get("WDYN"))
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("WDYN")));
		processedReqMaster
				.setTotalInvUsedWDYN(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("WDYN")));

		processedReqMaster.setTotalInvUSRE(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, invMap.get("USRE"))
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("USRE")));
		processedReqMaster
				.setTotalInvUsedUSRE(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("USRE")));

		processedReqMaster.setTotalInvUSRR(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, invMap.get("USRR"))
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("USRR")));
		processedReqMaster
				.setTotalInvUsedUSRR(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("USRR")));

		processedReqMaster.setTotalInvSFPI(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, invMap.get("SFPI"))
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("SFPI")));
		processedReqMaster
				.setTotalInvUsedSFPI(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("SFPI")));

		processedReqMaster.setTotalInvREPT(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, invMap.get("REPT"))
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("REPT")));
		processedReqMaster
				.setTotalInvUsedREPT(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("REPT")));

		processedReqMaster.setTotalInvVIEW(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, invMap.get("VIEW"))
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("VIEW")));
		processedReqMaster
				.setTotalInvUsedVIEW(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("VIEW")));

		processedReqMaster.setTotalInvINDX(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, invMap.get("INDX"))
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("INDX")));
		processedReqMaster
				.setTotalInvUsedINDX(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("INDX")));

		processedReqMaster.setTotalInvCDAT(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, invMap.get("CDAT"))
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("CDAT")));
		processedReqMaster
				.setTotalInvUsedCDAT(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("CDAT")));

		processedReqMaster.setTotalInvTABU(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, invMap.get("TABU"))
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("TABU")));
		processedReqMaster
				.setTotalInvUsedTABU(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("TABU")));

		processedReqMaster.setTotalInvBWTR(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, invMap.get("BWTR"))
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("BWTR")));
		processedReqMaster
				.setTotalInvUsedBWTR(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("BWTR")));

		processedReqMaster.setTotalInvBWTS(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, invMap.get("BWTS"))
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("BWTS")));
		processedReqMaster
				.setTotalInvUsedBWTS(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("BWTS")));

		processedReqMaster.setTotalInvBWUR(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, invMap.get("BWUR"))
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("BWUR")));
		processedReqMaster
				.setTotalInvUsedBWUR(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("BWUR")));

		processedReqMaster.setTotalInvBWIG(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, invMap.get("BWIG"))
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("BWIG")));
		processedReqMaster
				.setTotalInvUsedBWIG(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("BWIG")));

		processedReqMaster.setTotalInvINDE(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, invMap.get("INDE"))
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("INDE")));
		processedReqMaster
				.setTotalInvUsedINDE(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("INDE")));

		processedReqMaster.setTotalInvAQQU(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, invMap.get("AQQU"))
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("AQQU")));
		processedReqMaster
				.setTotalInvUsedAQQU(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, invMap.get("AQQU")));
	}

	private void setExtNamespaceInventoryObjCounts(Map<String, Integer> countMap,
			ProcessedRequestMaster processedReqMaster) {
		int totalExtNamespaceInvUsedObjCount = getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, countMap);
		int totalExtNamespaceInvUnusedObjCount = getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, countMap);

		processedReqMaster
				.setDistinctExtNamespaceInvCount(totalExtNamespaceInvUsedObjCount + totalExtNamespaceInvUnusedObjCount);

		processedReqMaster
				.setDistinctExtNamespaceInvUsedCount(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, countMap));

		if (totalExtNamespaceInvUsedObjCount + totalExtNamespaceInvUnusedObjCount != 0)
			processedReqMaster.setDistinctExtNamespaceInvUsedPerc(((float) totalExtNamespaceInvUsedObjCount
					/ (float) (totalExtNamespaceInvUsedObjCount + totalExtNamespaceInvUnusedObjCount)) * 100);
	}

	private void setImpactedObjHANAS4Counts(Map<String, Integer> countMap, ProcessedRequestMaster processedReqMaster) {
		processedReqMaster.setDistinctObjCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, countMap)
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, countMap));

		processedReqMaster.setDistinctUsedObjCount(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, countMap));
	}

	private void setExtNamespaceImpactedHANAS4Counts(Map<String, Integer> countMap,
			ProcessedRequestMaster processedReqMaster) {
		processedReqMaster
				.setDistinctExtNamespaceImpObjCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, countMap)
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, countMap));

		processedReqMaster.setDistinctExtNamespaceUsedImpObjCount(
				getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, countMap));
	}

	private void setImpactedObjCounts(Map<String, Map<String, Integer>> impObjMap,
			ProcessedRequestMaster processedReqMaster) {
		processedReqMaster.setTotalImpactedObjCount(getTotalObjectCount(impObjMap));
		processedReqMaster
				.setTotalImpactedUsedObjCount(getTotalUsedCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap));

		processedReqMaster
				.setTotalImpPROG(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, impObjMap.get("PROG"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("PROG")));
		processedReqMaster
				.setTotalImpUsedPROG(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("PROG")));

		processedReqMaster
				.setTotalImpFUGR(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, impObjMap.get("FUGR"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("FUGR")));
		processedReqMaster
				.setTotalImpUsedFUGR(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("FUGR")));

		processedReqMaster
				.setTotalImpCLAS(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, impObjMap.get("CLAS"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("CLAS")));
		processedReqMaster
				.setTotalImpUsedCLAS(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("CLAS")));

		processedReqMaster
				.setTotalImpENHO(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, impObjMap.get("ENHO"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("ENHO")));
		processedReqMaster
				.setTotalImpUsedENHO(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("ENHO")));

		processedReqMaster
				.setTotalImpENHC(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, impObjMap.get("ENHC"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("ENHC")));
		processedReqMaster
				.setTotalImpUsedENHC(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("ENHC")));

		processedReqMaster
				.setTotalImpLSMW(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, impObjMap.get("LSMW"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("LSMW")));
		processedReqMaster
				.setTotalImpUsedLSMW(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("LSMW")));

		processedReqMaster
				.setTotalImpFUGS(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, impObjMap.get("FUGS"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("FUGS")));
		processedReqMaster
				.setTotalImpUsedFUGS(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("FUGS")));

		processedReqMaster
				.setTotalImpSSFO(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, impObjMap.get("SSFO"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("SSFO")));
		processedReqMaster
				.setTotalImpUsedSSFO(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("SSFO")));

		processedReqMaster
				.setTotalImpDTEL(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, impObjMap.get("DTEL"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("DTEL")));
		processedReqMaster
				.setTotalImpUsedDTEL(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("DTEL")));

		processedReqMaster
				.setTotalImpENHS(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, impObjMap.get("ENHS"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("ENHS")));
		processedReqMaster
				.setTotalImpUsedENHS(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("ENHS")));

		processedReqMaster
				.setTotalImpWDYN(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, impObjMap.get("WDYN"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("WDYN")));
		processedReqMaster
				.setTotalImpUsedWDYN(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("WDYN")));

		processedReqMaster
				.setTotalImpUSRE(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, impObjMap.get("USRE"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("USRE")));
		processedReqMaster
				.setTotalImpUsedUSRE(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("USRE")));

		processedReqMaster
				.setTotalImpUSRR(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, impObjMap.get("USRR"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("USRR")));
		processedReqMaster
				.setTotalImpUsedUSRR(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("USRR")));

		processedReqMaster
				.setTotalImpSFPI(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, impObjMap.get("SFPI"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("SFPI")));
		processedReqMaster
				.setTotalImpUsedSFPI(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("SFPI")));

		processedReqMaster
				.setTotalImpREPT(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, impObjMap.get("REPT"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("REPT")));
		processedReqMaster
				.setTotalImpUsedREPT(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("REPT")));

		processedReqMaster
				.setTotalImpVIEW(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, impObjMap.get("VIEW"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("VIEW")));
		processedReqMaster
				.setTotalImpUsedVIEW(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("VIEW")));

		processedReqMaster
				.setTotalImpINDX(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, impObjMap.get("INDX"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("INDX")));
		processedReqMaster
				.setTotalImpUsedINDX(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("INDX")));

		processedReqMaster
				.setTotalImpCDAT(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, impObjMap.get("CDAT"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("CDAT")));
		processedReqMaster
				.setTotalImpUsedCDAT(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("CDAT")));

		processedReqMaster
				.setTotalImpTABU(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, impObjMap.get("TABU"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("TABU")));
		processedReqMaster
				.setTotalImpUsedTABU(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("TABU")));

		processedReqMaster
				.setTotalImpBWTR(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, impObjMap.get("BWTR"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("BWTR")));
		processedReqMaster
				.setTotalImpUsedBWTR(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("BWTR")));

		processedReqMaster
				.setTotalImpBWTS(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, impObjMap.get("BWTS"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("BWTS")));
		processedReqMaster
				.setTotalImpUsedBWTS(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("BWTS")));

		processedReqMaster
				.setTotalImpBWUR(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, impObjMap.get("BWUR"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("BWUR")));
		processedReqMaster
				.setTotalImpUsedBWUR(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("BWUR")));

		processedReqMaster
				.setTotalImpBWIG(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, impObjMap.get("BWIG"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("BWIG")));
		processedReqMaster
				.setTotalImpUsedBWIG(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("BWIG")));

		processedReqMaster
				.setTotalImpINDE(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, impObjMap.get("INDE"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("INDE")));
		processedReqMaster
				.setTotalImpUsedINDE(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("INDE")));

		processedReqMaster
				.setTotalImpAQQU(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, impObjMap.get("AQQU"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("AQQU")));
		processedReqMaster
				.setTotalImpUsedAQQU(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjMap.get("AQQU")));
	}

	private void setAppLevelHANACounts(Map<String, Map<String, Map<String, Integer>>> appLevelOptMap,
			ProcessedRequestMaster processedReqMaster) {
		if (appLevelOptMap.containsKey("Code maintainability (HANA specific)".toUpperCase().trim())) {
			Map<String, Map<String, Integer>> subCategoryMap = appLevelOptMap
					.get("Code maintainability (HANA specific)".toUpperCase().trim());

			if (subCategoryMap.containsKey("Keep unnecessary load away from database".toUpperCase().trim())) {
				processedReqMaster.setDistinctCodeMaintainHanaSpcKeepUnncecLoadAwayFromDB(
						getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
								subCategoryMap.get(("Keep unnecessary load away from database").toUpperCase().trim())));

				processedReqMaster.setErrorCodeMaintainHanaSpcKeepUnncecLoadAwayFromDB(
						getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
								subCategoryMap.get(("Keep unnecessary load away from database").toUpperCase().trim())));
			}
		}

		if (appLevelOptMap.containsKey("Performance (general)".toUpperCase().trim())) {
			Map<String, Map<String, Integer>> subCategoryMap = appLevelOptMap
					.get("Performance (general)".toUpperCase().trim());

			if (subCategoryMap.containsKey("Keep unnecessary load away from database".toUpperCase().trim())) {
				processedReqMaster
						.setDistinctPerfGenKeepUnnecLoadAwayFromDB(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
								subCategoryMap.get(("Keep unnecessary load away from database").toUpperCase().trim())));

				processedReqMaster
						.setErrorPerfGenKeepUnnecLoadAwayFromDB(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
								subCategoryMap.get(("Keep unnecessary load away from database").toUpperCase().trim())));
			}

			if (subCategoryMap.containsKey("Keep the result set small".toUpperCase().trim())) {
				processedReqMaster
						.setDistinctPerfGenKeepResultSetSmall(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
								subCategoryMap.get(("Keep the result set small").toUpperCase().trim())));

				processedReqMaster.setErrorPerfGenKeepResultSetSmall(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						subCategoryMap.get(("Keep the result set small").toUpperCase().trim())));

			}

			if (subCategoryMap.containsKey("Minimize the amount of transferred data".toUpperCase().trim())) {
				processedReqMaster
						.setDistinctPerfGenMinAmtTranData(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
								subCategoryMap.get(("Minimize the amount of transferred data").toUpperCase().trim())));

				processedReqMaster.setErrorPerfGenMinAmtTranData(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						subCategoryMap.get(("Minimize the amount of transferred data").toUpperCase().trim())));
			}

			if (subCategoryMap.containsKey(
					"Select Queries to be used in Global Routines(For Example: Start Routine)".toUpperCase().trim())) {
				processedReqMaster.setDistinctPerfGenSelectQueriesInGlobalRoutines(
						getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
								subCategoryMap
										.get(("Select Queries to be used in Global Routines(For Example: Start Routine)")
												.toUpperCase().trim())));
				processedReqMaster
						.setErrorPerfGenSelectQueriesInGlobalRoutines(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
								subCategoryMap
										.get(("Select Queries to be used in Global Routines(For Example: Start Routine)")
												.toUpperCase().trim())));
			}
		}

		if (appLevelOptMap.containsKey("Performance (HANA specific)".toUpperCase().trim())) {
			Map<String, Map<String, Integer>> subCategoryMap = appLevelOptMap
					.get("Performance (HANA specific)".toUpperCase().trim());

			if (subCategoryMap.containsKey("Minimize the amount of transferred data".toUpperCase().trim())) {
				processedReqMaster
						.setDistinctPerfHanaSpcMinAmtTranData(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
								subCategoryMap.get(("Minimize the amount of transferred data").toUpperCase().trim())));

				processedReqMaster.setErrorPerfHanaSpcMinAmtTranData(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						subCategoryMap.get(("Minimize the amount of transferred data").toUpperCase().trim())));
			}
		}

		if (appLevelOptMap.containsKey("Optimize the use of Logical Database".toUpperCase().trim())) {
			Map<String, Map<String, Integer>> subCategoryMap = appLevelOptMap
					.get("Optimize the use of Logical Database".toUpperCase().trim());

			if (subCategoryMap.containsKey("Keep unnecessary load away from database".toUpperCase().trim())) {
				processedReqMaster.setDistinctAppLoadOptimizeDB(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						subCategoryMap.get(("Keep unnecessary load away from database").toUpperCase().trim())));

				processedReqMaster.setErrorAppLoadOptimizeDB(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						subCategoryMap.get(("Keep unnecessary load away from database").toUpperCase().trim())));
			}
		}
	}

	private void setDBLevelHANACounts(Map<String, Map<String, Integer>> dbLevelOptMap,
			ProcessedRequestMaster processedReqMaster) {
		if (dbLevelOptMap.containsKey("AGGREGATION STATEMENT COLLECT".toUpperCase().trim())) {
			processedReqMaster.setDistinctAggrStatCollectCount(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
					dbLevelOptMap.get(("AGGREGATION STATEMENT COLLECT").toUpperCase().trim())));

			processedReqMaster.setErrorAggrStatCollectCount(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
					dbLevelOptMap.get(("AGGREGATION STATEMENT COLLECT").toUpperCase().trim())));
		}

		if (dbLevelOptMap.containsKey("FAE & JOIN".toUpperCase().trim())) {
			processedReqMaster.setDistinctFAEAndJoinCount(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
					dbLevelOptMap.get(("FAE & JOIN").toUpperCase().trim())));

			processedReqMaster.setErrorFAEAndJoinCount(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
					dbLevelOptMap.get(("FAE & JOIN").toUpperCase().trim())));
		}

		if (dbLevelOptMap.containsKey("For All Entries used".toUpperCase().trim())) {
			processedReqMaster.setDistinctForAllEntriesUsedCount(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
					dbLevelOptMap.get(("For All Entries used").toUpperCase().trim())));

			processedReqMaster.setErrorForAllEntriesUsedCount(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
					dbLevelOptMap.get(("For All Entries used").toUpperCase().trim())));
		}

		if (dbLevelOptMap.containsKey("JOINS ON TABLES IN SELECT STATEMENTS".toUpperCase().trim())) {
			processedReqMaster
					.setDistinctJoinsOnTablesInSelectStatCount(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
							dbLevelOptMap.get(("JOINS ON TABLES IN SELECT STATEMENTS").toUpperCase().trim())));

			processedReqMaster.setErrorJoinsOnTablesInSelectStatCount(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
					dbLevelOptMap.get(("JOINS ON TABLES IN SELECT STATEMENTS").toUpperCase().trim())));
		}

		if (dbLevelOptMap.containsKey("Repeated Database Hits On Table".toUpperCase().trim())) {
			processedReqMaster.setDistinctRepeatDBHitsOnTableCount(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
					dbLevelOptMap.get(("Repeated Database Hits On Table").toUpperCase().trim())));

			processedReqMaster.setErrorRepeatDBHitsOnTableCount(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
					dbLevelOptMap.get(("Repeated Database Hits On Table").toUpperCase().trim())));
		}

		if (dbLevelOptMap.containsKey("FM USED FOR CURRENCY CONVERSION".toUpperCase().trim())) {
			processedReqMaster.setDistinctFMUsedForCurrConvCount(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
					dbLevelOptMap.get(("FM USED FOR CURRENCY CONVERSION").toUpperCase().trim())));

			processedReqMaster.setErrorFMUsedForCurrConvCount(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
					dbLevelOptMap.get(("FM USED FOR CURRENCY CONVERSION").toUpperCase().trim())));
		}
	}

	private void setHousekeepingHANACounts(Map<String, Map<String, Integer>> housekeepingOptMap,
			ProcessedRequestMaster processedReqMaster) {
		if (housekeepingOptMap.containsKey("DB HINTS USED".toUpperCase().trim())) {
			processedReqMaster.setDistinctDBHintsUsedCount(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
					housekeepingOptMap.get(("DB HINTS USED").toUpperCase().trim())));

			processedReqMaster.setErrorDBHintsUsedCount(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
					housekeepingOptMap.get(("DB HINTS USED").toUpperCase().trim())));
		}

		if (housekeepingOptMap.containsKey("BYPASS TABLE BUFFER".toUpperCase().trim())) {
			processedReqMaster.setDistinctByPassTableBufferCount(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
					housekeepingOptMap.get(("BYPASS TABLE BUFFER").toUpperCase().trim())));

			processedReqMaster.setErrorByPassTableBufferCount(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
					housekeepingOptMap.get(("BYPASS TABLE BUFFER").toUpperCase().trim())));
		}
	}

	private void setRemCatAutomationHANACounts(Map<String, Map<String, Map<String, Integer>>> remCatAutoMap,
			ProcessedRequestMaster processedReqMaster) {
		if (remCatAutoMap.containsKey("Mandatory".toUpperCase().trim())) {
			Map<String, Map<String, Integer>> autoMap = remCatAutoMap.get("Mandatory".toUpperCase().trim());

			if (autoMap.containsKey("No".toUpperCase().trim())) {
				processedReqMaster.setDistinctMandManualCount(getColumnCount(Hana_Profiler_Constant.UNUSED_DISTINCT,
						autoMap.get("No".toUpperCase().trim()))
						+ getColumnCount(Hana_Profiler_Constant.USED_DISTINCT, autoMap.get("No".toUpperCase().trim())));

				processedReqMaster.setErrorMandManualCount(
						getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, autoMap.get("No".toUpperCase().trim()))
								+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
										autoMap.get("No".toUpperCase().trim())));
			}

			if (autoMap.containsKey("Yes".toUpperCase().trim())) {
				processedReqMaster.setDistinctMandAutomaticCount(
						getColumnCount(Hana_Profiler_Constant.UNUSED_DISTINCT, autoMap.get("Yes".toUpperCase().trim()))
								+ getColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
										autoMap.get("Yes".toUpperCase().trim())));

				processedReqMaster.setErrorMandAutomaticCount(
						getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, autoMap.get("Yes".toUpperCase().trim()))
								+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
										autoMap.get("Yes".toUpperCase().trim())));
			}
		}

		if (remCatAutoMap.containsKey("Application level optimization".toUpperCase().trim())) {
			Map<String, Map<String, Integer>> autoMap = remCatAutoMap
					.get("Application level optimization".toUpperCase().trim());

			if (autoMap.containsKey("Yes".toUpperCase().trim())) {
				processedReqMaster.setDistinctAppLevelAutomaticCount(
						getColumnCount(Hana_Profiler_Constant.UNUSED_DISTINCT, autoMap.get("Yes".toUpperCase().trim()))
								+ getColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
										autoMap.get("Yes".toUpperCase().trim())));

				processedReqMaster.setErrorAppLevelAutomaticCount(
						getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, autoMap.get("Yes".toUpperCase().trim()))
								+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
										autoMap.get("Yes".toUpperCase().trim())));
			}
		}

		if (remCatAutoMap.containsKey("DB Level HANA Optimization".toUpperCase().trim())) {
			Map<String, Map<String, Integer>> autoMap = remCatAutoMap
					.get("DB Level HANA Optimization".toUpperCase().trim());

			if (autoMap.containsKey("Yes".toUpperCase().trim())) {
				processedReqMaster.setDistinctDBLevelAutomaticCount(
						getColumnCount(Hana_Profiler_Constant.UNUSED_DISTINCT, autoMap.get("Yes".toUpperCase().trim()))
								+ getColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
										autoMap.get("Yes".toUpperCase().trim())));

				processedReqMaster.setErrorDBLevelAutomaticCount(
						getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, autoMap.get("Yes".toUpperCase().trim()))
								+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
										autoMap.get("Yes".toUpperCase().trim())));
			}
		}

		if (remCatAutoMap.containsKey("Housekeeping for HANA".toUpperCase().trim())) {
			Map<String, Map<String, Integer>> autoMap = remCatAutoMap.get("Housekeeping for HANA".toUpperCase().trim());

			if (autoMap.containsKey("Yes".toUpperCase().trim())) {
				processedReqMaster.setDistinctHANAHousekeepAutomaticCount(
						getColumnCount(Hana_Profiler_Constant.UNUSED_DISTINCT, autoMap.get("Yes".toUpperCase().trim()))
								+ getColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
										autoMap.get("Yes".toUpperCase().trim())));

				processedReqMaster.setErrorHANAHousekeepAutomaticCount(
						getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, autoMap.get("Yes".toUpperCase().trim()))
								+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
										autoMap.get("Yes".toUpperCase().trim())));
			}
		}
	}

	private void autoStatusPercHANACounts(Map<String, Map<String, Map<String, Integer>>> remCatMap,
			ProcessedRequestMaster processedReqMaster) {
		if (remCatMap.containsKey("Mandatory".toUpperCase())) {
			Map<String, Map<String, Integer>> countMap = remCatMap.get("Mandatory".toUpperCase().trim());

			if (countMap.containsKey("Yes".toUpperCase().trim())) {
				processedReqMaster.setTotalAutoYImpUsedObjCount(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
						countMap.get("Yes".toUpperCase().trim())));
			}

			if (processedReqMaster.getTotalManImpactedObjectCount() != 0)
				processedReqMaster.setManAutoYPercentage(((float) processedReqMaster.getErrorMandAutomaticCount()
						/ (float) processedReqMaster.getTotalManImpactedObjectCount()) * 100);

			if (processedReqMaster.getTotalManImpactedUsedObjCount() != 0)
				processedReqMaster.setManAutoYUsedPercentage(((float) processedReqMaster.getTotalAutoYImpUsedObjCount()
						/ (float) processedReqMaster.getTotalManImpactedUsedObjCount()) * 100);
		}
	}

	private void setMandatoryHANACounts(Map<String, Map<String, Map<String, Integer>>> mandatoryMap,
			ProcessedRequestMaster processedReqMaster) {
		if (mandatoryMap.containsKey("HANA Sorting".toUpperCase().trim())) {
			Map<String, Map<String, Integer>> operationMap = mandatoryMap.get("HANA Sorting".toUpperCase().trim());

			if (operationMap.containsKey("CHECK/EXIT/LEAVE STATEMENT WITHIN LOOP".toUpperCase().trim())) {
				processedReqMaster.setDistinctHanaSortChckExitLeaveStatWithLoop(
						getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
								operationMap.get(("CHECK/EXIT/LEAVE STATEMENT WITHIN LOOP").toUpperCase().trim())));

				processedReqMaster
						.setErrorHanaSortChckExitLeaveStatWithLoop(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
								operationMap.get(("CHECK/EXIT/LEAVE STATEMENT WITHIN LOOP").toUpperCase().trim())));
			}

			if (operationMap.containsKey("DELETE ADJACENT DUPLICATES IS USED WITHOUT SORTING".toUpperCase().trim())) {
				processedReqMaster.setDistinctHanaSortDelAdjDupWithoutSorting(getColumnCount(
						Hana_Profiler_Constant.DISTINCT_COUNT,
						operationMap.get(("DELETE ADJACENT DUPLICATES IS USED WITHOUT SORTING").toUpperCase().trim())));

				processedReqMaster.setErrorHanaSortDelAdjDupWithoutSorting(getColumnCount(
						Hana_Profiler_Constant.ERROR_COUNT,
						operationMap.get(("DELETE ADJACENT DUPLICATES IS USED WITHOUT SORTING").toUpperCase().trim())));
			}

			if (operationMap.containsKey("READ STATEMENT WITH BINARY AND WITHOUT SORTING".toUpperCase().trim())) {
				processedReqMaster.setDistinctHanaSortReadStatWithBinaryAndWithoutSorting(getColumnCount(
						Hana_Profiler_Constant.DISTINCT_COUNT,
						operationMap.get(("READ STATEMENT WITH BINARY AND WITHOUT SORTING").toUpperCase().trim())));

				processedReqMaster.setErrorHanaSortReadStatWithBinaryAndWithoutSorting(getColumnCount(
						Hana_Profiler_Constant.ERROR_COUNT,
						operationMap.get(("READ STATEMENT WITH BINARY AND WITHOUT SORTING").toUpperCase().trim())));
			}

			if (operationMap.containsKey("Select Single without key fields".toUpperCase().trim())) {
				processedReqMaster.setDistinctHanaSortSelectSingleWithoutKeyFields(
						getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
								operationMap.get(("Select Single without key fields").toUpperCase().trim())));

				processedReqMaster
						.setErrorHanaSortSelectSingleWithoutKeyFields(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
								operationMap.get(("Select Single without key fields").toUpperCase().trim())));
			}

			if (operationMap.containsKey("UNSORTED INTERNAL TABLE ACCESSED WITH FM".toUpperCase().trim())) {
				processedReqMaster.setDistinctHanaSortUnsortedIntTableAccessWithFM(
						getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
								operationMap.get(("UNSORTED INTERNAL TABLE ACCESSED WITH FM").toUpperCase().trim())));

				processedReqMaster
						.setErrorHanaSortUnsortedIntTableAccessWithFM(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
								operationMap.get(("UNSORTED INTERNAL TABLE ACCESSED WITH FM").toUpperCase().trim())));
			}

			if (operationMap.containsKey("UNSORTED INTERNAL TABLE ACCESSED WITH INDEX".toUpperCase().trim())) {
				processedReqMaster.setDistinctHanaSortUnsortedIntTableAccessWithIndex(getColumnCount(
						Hana_Profiler_Constant.DISTINCT_COUNT,
						operationMap.get(("UNSORTED INTERNAL TABLE ACCESSED WITH INDEX").toUpperCase().trim())));

				processedReqMaster.setErrorHanaSortUnsortedIntTableAccessWithIndex(getColumnCount(
						Hana_Profiler_Constant.ERROR_COUNT,
						operationMap.get(("UNSORTED INTERNAL TABLE ACCESSED WITH INDEX").toUpperCase().trim())));
			}

			if (operationMap.containsKey(
					"Control statement inside loop (Only when loop is using internal table which is not sorted)"
							.toUpperCase().trim())) {
				processedReqMaster
						.setDistinctHanaSortControlStmntInsideLoop(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
								operationMap
										.get(("Control statement inside loop (Only when loop is using internal table which is not sorted)")
												.toUpperCase().trim())));

				processedReqMaster
						.setErrorHanaSortControlStmntInsideLoop(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
								operationMap
										.get(("Control statement inside loop (Only when loop is using internal table which is not sorted)")
												.toUpperCase().trim())));
			}
		}

		if (mandatoryMap.containsKey("Semantic Error".toUpperCase().trim())) {
			Map<String, Map<String, Integer>> operationMap = mandatoryMap.get("Semantic Error".toUpperCase().trim());

			if (operationMap.containsKey("ADBC USAGE".toUpperCase().trim())) {
				processedReqMaster.setDistinctSemErrorADBCUsage(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
						operationMap.get(("ADBC USAGE").toUpperCase().trim())));

				processedReqMaster.setErrorSemErrorADBCUsage(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						operationMap.get(("ADBC USAGE").toUpperCase().trim())));
			}

			if (operationMap.containsKey("NATIVE SQL CALL".toUpperCase().trim())) {
				processedReqMaster
						.setDistinctSemErrorNativeSQLCall(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
								operationMap.get(("NATIVE SQL CALL").toUpperCase().trim())));

				processedReqMaster.setErrorSemErrorNativeSQLCall(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						operationMap.get(("NATIVE SQL CALL").toUpperCase().trim())));
			}

			if (operationMap.containsKey("Pool/Cluster Table".toUpperCase().trim())) {
				processedReqMaster
						.setDistinctSemErrorPollClusterTable(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
								operationMap.get(("Pool/Cluster Table").toUpperCase().trim())));

				processedReqMaster.setErrorSemErrorPollClusterTable(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						operationMap.get(("Pool/Cluster Table").toUpperCase().trim())));
			}

			if (operationMap.containsKey("DB operations on Table pool & Table Cluster".toUpperCase().trim())) {
				processedReqMaster.setDistinctSemErrorDBOperationOnPollClusterTable(getColumnCount(
						Hana_Profiler_Constant.DISTINCT_COUNT,
						operationMap.get(("DB operations on Table pool & Table Cluster").toUpperCase().trim())));

				processedReqMaster.setErrorSemErrorDBOperationOnPollClusterTable(getColumnCount(
						Hana_Profiler_Constant.ERROR_COUNT,
						operationMap.get(("DB operations on Table pool & Table Cluster").toUpperCase().trim())));
			}

			if (operationMap.containsKey("DDIC FUNCTION MODULE CALL".toUpperCase().trim())) {
				processedReqMaster
						.setDistinctSemErrorDDICFuncModCall(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
								operationMap.get(("DDIC FUNCTION MODULE CALL").toUpperCase().trim())));

				processedReqMaster.setErrorSemErrorDDICFuncModCall(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
						operationMap.get(("DDIC FUNCTION MODULE CALL").toUpperCase().trim())));
			}
		}
	}

	private void setRemCatHANACounts(Map<String, Map<String, Integer>> hanaCountMap,
			ProcessedRequestMaster processedReqMaster) {
		if (hanaCountMap.containsKey("Mandatory".toUpperCase().trim())) {
			Map<String, Integer> usedMap = hanaCountMap.get("Mandatory".toUpperCase().trim());

			processedReqMaster
					.setTotalManImpactedObjectCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, usedMap)
							+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));

			processedReqMaster
					.setTotalManImpactedUsedObjCount(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));

			processedReqMaster
					.setDistinctManImpactedObjCount(getColumnCount(Hana_Profiler_Constant.UNUSED_DISTINCT, usedMap)
							+ getColumnCount(Hana_Profiler_Constant.USED_DISTINCT, usedMap));

			processedReqMaster
					.setDistinctManImpactedUsedObjCount(getColumnCount(Hana_Profiler_Constant.USED_DISTINCT, usedMap));
		}

		if (hanaCountMap.containsKey("Application level optimization".toUpperCase().trim())) {
			Map<String, Integer> usedMap = hanaCountMap.get("Application level optimization".toUpperCase().trim());

			processedReqMaster
					.setTotalAppLevelOptImpObjCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, usedMap)
							+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));

			processedReqMaster
					.setTotalUsedAppLevelOptImpObjCount(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));

			processedReqMaster
					.setDistinctAppLevelOptImpObjCount(getColumnCount(Hana_Profiler_Constant.UNUSED_DISTINCT, usedMap)
							+ getColumnCount(Hana_Profiler_Constant.USED_DISTINCT, usedMap));

			processedReqMaster.setDistinctUsedAppLevelOptImpObjCount(
					getColumnCount(Hana_Profiler_Constant.USED_DISTINCT, usedMap));
		}

		if (hanaCountMap.containsKey("DB Level HANA Optimization".toUpperCase().trim())) {
			Map<String, Integer> usedMap = hanaCountMap.get("DB Level HANA Optimization".toUpperCase().trim());

			processedReqMaster
					.setTotalHanaLevelOptImpObjCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, usedMap)
							+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));

			processedReqMaster.setTotalUsedHanaLevelOptImpObjCount(
					getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));

			processedReqMaster
					.setDistinctHanaLevelOptImpObjCount(getColumnCount(Hana_Profiler_Constant.UNUSED_DISTINCT, usedMap)
							+ getColumnCount(Hana_Profiler_Constant.USED_DISTINCT, usedMap));

			processedReqMaster.setDistinctUsedHanaLevelOptImpObjCount(
					getColumnCount(Hana_Profiler_Constant.USED_DISTINCT, usedMap));
		}

		if (hanaCountMap.containsKey("Housekeeping for HANA".toUpperCase().trim())) {
			Map<String, Integer> usedMap = hanaCountMap.get("Housekeeping for HANA".toUpperCase().trim());

			processedReqMaster
					.setTotalHanaHouseKeepImpObjCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, usedMap)
							+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));

			processedReqMaster.setTotalUsedHanaHouseKeepImpObjCount(
					getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));

			processedReqMaster
					.setDistinctHanaHouseKeepImpObjCount(getColumnCount(Hana_Profiler_Constant.UNUSED_DISTINCT, usedMap)
							+ getColumnCount(Hana_Profiler_Constant.USED_DISTINCT, usedMap));

			processedReqMaster.setDistinctUsedHanaHouseKeepImpObjCount(
					getColumnCount(Hana_Profiler_Constant.USED_DISTINCT, usedMap));
		}
	}

	private void setRemCatIssueCatHANACounts(Map<String, Map<String, Map<String, Integer>>> hanaCountMap,
			ProcessedRequestMaster processedReqMaster) {
		if (hanaCountMap.containsKey("Mandatory".toUpperCase().trim())) {
			Map<String, Map<String, Integer>> issueCategoryMap = hanaCountMap.get("Mandatory".toUpperCase().trim());

			if (issueCategoryMap.containsKey("HANA Sorting".toUpperCase().trim())) {
				Map<String, Integer> usedMap = issueCategoryMap.get("HANA Sorting".toUpperCase().trim());

				processedReqMaster.setManHanSort(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, usedMap)
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));

				processedReqMaster.setUsedManHanaSort(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));
			}

			if (issueCategoryMap.containsKey("Semantic Error".toUpperCase().trim())) {
				Map<String, Integer> usedMap = issueCategoryMap.get("Semantic Error".toUpperCase().trim());

				processedReqMaster.setManSemError(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, usedMap)
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));

				processedReqMaster.setUsedManSemError(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));
			}
		}

		if (hanaCountMap.containsKey("Application level optimization".toUpperCase().trim())) {
			Map<String, Map<String, Integer>> issueCategoryMap = hanaCountMap
					.get("Application level optimization".toUpperCase().trim());

			if (issueCategoryMap.containsKey("Keep the result set small".toUpperCase().trim())) {
				Map<String, Integer> usedMap = issueCategoryMap.get("Keep the result set small".toUpperCase().trim());

				processedReqMaster.setAppLevelOptKeepResultSetSmall(
						getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, usedMap)
								+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));
			}

			if (issueCategoryMap.containsKey("Minimize the amount of transferred data".toUpperCase().trim())) {
				Map<String, Integer> usedMap = issueCategoryMap
						.get("Minimize the amount of transferred data".toUpperCase().trim());

				processedReqMaster
						.setAppLevelMinAmtOfTranData(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, usedMap)
								+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));
			}

			if (issueCategoryMap.containsKey("Keep unnecessary load away from database".toUpperCase().trim())) {
				Map<String, Integer> usedMap = issueCategoryMap
						.get("Keep unnecessary load away from database".toUpperCase().trim());

				processedReqMaster.setAppLevelOptKeepUnnecLoadAwayFromDB(
						getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap)
								+ getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, usedMap));
			}

			if (issueCategoryMap.containsKey(
					"Select Queries to be used in Global Routines(For Example: Start Routine)".toUpperCase().trim())) {
				Map<String, Integer> usedMap = issueCategoryMap
						.get("Select Queries to be used in Global Routines(For Example: Start Routine)".toUpperCase()
								.trim());

				processedReqMaster.setAppLevelSelectQueriesInGlobalRoutines(
						getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap)
								+ getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, usedMap));
			}
		}

		if (hanaCountMap.containsKey("DB Level HANA Optimization".toUpperCase().trim())) {
			Map<String, Map<String, Integer>> issueCategoryMap = hanaCountMap
					.get("DB Level HANA Optimization".toUpperCase().trim());

			if (issueCategoryMap.containsKey("Minimize the amount of transferred data".toUpperCase().trim())) {
				Map<String, Integer> usedMap = issueCategoryMap
						.get("Minimize the amount of transferred data".toUpperCase().trim());

				processedReqMaster.setHanaLevelOptMinAmtOfTranData(
						getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, usedMap)
								+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));
			}
		}

		if (hanaCountMap.containsKey("Housekeeping for HANA".toUpperCase().trim())) {
			Map<String, Map<String, Integer>> issueCategoryMap = hanaCountMap
					.get("Housekeeping for HANA".toUpperCase().trim());

			if (issueCategoryMap.containsKey("Keep unnecessary load away from database".toUpperCase().trim())) {
				Map<String, Integer> usedMap = issueCategoryMap
						.get("Keep unnecessary load away from database".toUpperCase().trim());

				processedReqMaster.setHanaHousKeepUnnecLoadAwayFromDB(
						getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap)
								+ getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, usedMap));
			}

			if (issueCategoryMap.containsKey("Statement ignored by HANA".toUpperCase().trim())) {
				Map<String, Integer> usedMap = issueCategoryMap.get("Statement ignored by HANA".toUpperCase().trim());

				processedReqMaster
						.setHanaHouseKeepStatIgnoreByHana(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap)
								+ getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, usedMap));
			}
		}
	}

	private void setRemCatS4Counts(Map<String, Map<String, Integer>> s4CountMap,
			ProcessedRequestMaster processedReqMaster) {
		if (s4CountMap.containsKey("Mandatory".toUpperCase().trim())) {
			Map<String, Integer> usedMap = s4CountMap.get("Mandatory".toUpperCase().trim());

			processedReqMaster
					.setTotalManImpactedObjectCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, usedMap)
							+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));

			processedReqMaster
					.setDistinctManImpactedObjCount(getColumnCount(Hana_Profiler_Constant.UNUSED_DISTINCT, usedMap)
							+ getColumnCount(Hana_Profiler_Constant.USED_DISTINCT, usedMap));

			processedReqMaster
					.setTotalManImpactedUsedObjCount(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));

			processedReqMaster
					.setDistinctManImpactedUsedObjCount(getColumnCount(Hana_Profiler_Constant.USED_DISTINCT, usedMap));
		}

		if (s4CountMap.containsKey("Optional".toUpperCase().trim())) {
			Map<String, Integer> usedMap = s4CountMap.get("Optional".toUpperCase().trim());

			processedReqMaster.setTotalOptionalImpactedObjectCount(
					getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, usedMap)
							+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));

			processedReqMaster
					.setDistinctOptionalImpactedObjCount(getColumnCount(Hana_Profiler_Constant.UNUSED_DISTINCT, usedMap)
							+ getColumnCount(Hana_Profiler_Constant.USED_DISTINCT, usedMap));

			processedReqMaster.setTotalOptionalImpactedUsedObjCount(
					getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));

			processedReqMaster.setDistinctOptionalImpactedUsedObjCount(
					getColumnCount(Hana_Profiler_Constant.USED_DISTINCT, usedMap));
		}
	}

	private void setRemCatCompS4Counts(Map<String, Map<String, Map<String, Integer>>> s4CountMap,
			ProcessedRequestMaster processedReqMaster) {
		if (s4CountMap.containsKey("Mandatory".toUpperCase().trim())) {
			Map<String, Map<String, Integer>> compMap = s4CountMap.get("Mandatory".toUpperCase().trim());

			if (compMap.containsKey("High".toUpperCase().trim())) {
				Map<String, Integer> usedMap = compMap.get("High".toUpperCase().trim());

				processedReqMaster.setManHighObjCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, usedMap)
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));

				processedReqMaster
						.setManHighUsedObjCount(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));
			}

			if (compMap.containsKey("Medium".toUpperCase().trim())) {
				Map<String, Integer> usedMap = compMap.get("Medium".toUpperCase().trim());

				processedReqMaster.setManMedObjCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, usedMap)
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));

				processedReqMaster
						.setManMedUsedObjCount(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));
			}

			if (compMap.containsKey("Low".toUpperCase().trim())) {
				Map<String, Integer> usedMap = compMap.get("Low".toUpperCase().trim());

				processedReqMaster.setManLowObjCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, usedMap)
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));

				processedReqMaster
						.setManLowUsedObjCount(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));
			}

			if (compMap.containsKey("TBD".toUpperCase().trim())) {
				Map<String, Integer> usedMap = compMap.get("TBD".toUpperCase().trim());

				processedReqMaster.setManTBDObjCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, usedMap)
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));

				processedReqMaster
						.setManTBDUsedObjCount(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));
			}
		}

		if (s4CountMap.containsKey("Optional".toUpperCase().trim())) {
			Map<String, Map<String, Integer>> compMap = s4CountMap.get("Optional".toUpperCase().trim());

			if (compMap.containsKey("High".toUpperCase().trim())) {
				Map<String, Integer> usedMap = compMap.get("High".toUpperCase().trim());

				processedReqMaster.setOptHighObjCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, usedMap)
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));

				processedReqMaster
						.setOptHighUsedObjCount(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));
			}

			if (compMap.containsKey("Medium".toUpperCase().trim())) {
				Map<String, Integer> usedMap = compMap.get("Medium".toUpperCase().trim());

				processedReqMaster.setOptMediumObjCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, usedMap)
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));

				processedReqMaster
						.setOptMedUsedObjCount(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));
			}

			if (compMap.containsKey("Low".toUpperCase().trim())) {
				Map<String, Integer> usedMap = compMap.get("Low".toUpperCase().trim());

				processedReqMaster.setOptLowObjCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, usedMap)
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));

				processedReqMaster
						.setOptLowUsedObjCount(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));
			}

			if (compMap.containsKey("Very Low".toUpperCase().trim())) {
				Map<String, Integer> usedMap = compMap.get("Very Low".toUpperCase().trim());

				processedReqMaster.setOptVryLowObjCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, usedMap)
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));

				processedReqMaster
						.setOptVryLowUsedObjCount(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));
			}
		}
	}

	private void setSAPSimpCatS4Counts(Map<String, Integer> sapSimpCatMap, ProcessedRequestMaster processedReqMaster) {
		processedReqMaster.setDistinctSAPChangeOfExistingFunctionality(
				getColumnCount("CHANGE OF EXISTING FUNCTIONALITY".toUpperCase().trim(), sapSimpCatMap));

		processedReqMaster.setDistinctSAPFunNotAvailFuncEquiAvail(getColumnCount(
				"FUNCTIONALITY NOT AVAILABLE: FUNCTIONAL EQUIVALENT AVAILABLE".toUpperCase().trim(), sapSimpCatMap));

		processedReqMaster.setDistinctSAPFunNotAvailNoFuncEquiAvail(getColumnCount(
				"FUNCTIONALITY NOT AVAILABLE: NO FUNCTIONAL EQUIVALENT".toUpperCase().trim(), sapSimpCatMap));

		processedReqMaster.setDistinctSAPNonStrategicFuncEquiAvail(getColumnCount(
				"NON-STRATEGIC-FUNCTION: FUNCTIONAL EQUIVALENT AVAILABLE".toUpperCase().trim(), sapSimpCatMap));

		processedReqMaster.setDistinctSAPNonStrategicNoFuncEquiAvail(
				getColumnCount("NON-STRATEGIC-FUNCTION: NO FUNCTIONAL EQUIVALENT".toUpperCase().trim(), sapSimpCatMap));
	}

	private void setIssueCatS4Counts(Map<String, Map<String, Integer>> issueCatMap,
			ProcessedRequestMaster processedReqMaster) {
		// Distinct Counts
		processedReqMaster.setDistinctIssueCatCustomCodeAdaption(getColumnCount(Hana_Profiler_Constant.UNUSED_DISTINCT,
				issueCatMap.get("CUSTOM CODE ADAPTION".toUpperCase().trim()))
				+ getColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
						issueCatMap.get("CUSTOM CODE ADAPTION".toUpperCase().trim())));

		processedReqMaster.setDistinctUsedIssueCatCustomCodeAdaption(getColumnCount(
				Hana_Profiler_Constant.USED_DISTINCT, issueCatMap.get("CUSTOM CODE ADAPTION".toUpperCase().trim())));

		processedReqMaster.setDistinctIssueCatDataEleLenExt(getColumnCount(Hana_Profiler_Constant.UNUSED_DISTINCT,
				issueCatMap.get("DATA ELEMENT LENGTH EXTENSION".toUpperCase().trim()))
				+ getColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
						issueCatMap.get("DATA ELEMENT LENGTH EXTENSION".toUpperCase().trim())));

		processedReqMaster.setDistinctUsedIssueCatDataEleLenExt(getColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
				issueCatMap.get("DATA ELEMENT LENGTH EXTENSION".toUpperCase().trim())));

		processedReqMaster.setDistinctIssueCatNewDataModel(getColumnCount(Hana_Profiler_Constant.UNUSED_DISTINCT,
				issueCatMap.get("NEW DATA MODEL".toUpperCase().trim()))
				+ getColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
						issueCatMap.get("NEW DATA MODEL".toUpperCase().trim())));

		processedReqMaster.setDistinctUsedIssueCatNewDataModel(getColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
				issueCatMap.get("NEW DATA MODEL".toUpperCase().trim())));

		processedReqMaster.setDistinctIssueCatNewS4Func(getColumnCount(Hana_Profiler_Constant.UNUSED_DISTINCT,
				issueCatMap.get("NEW S4 FUNCTIONALITY".toUpperCase().trim()))
				+ getColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
						issueCatMap.get("NEW S4 FUNCTIONALITY".toUpperCase().trim())));

		processedReqMaster.setDistinctUsedIssueCatNewS4Func(getColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
				issueCatMap.get("NEW S4 FUNCTIONALITY".toUpperCase().trim())));

		processedReqMaster.setDistinctIssueCatRemOfOrpObjects(getColumnCount(Hana_Profiler_Constant.UNUSED_DISTINCT,
				issueCatMap.get("REMOVAL OF ORPHANED OBJECTS".toUpperCase().trim()))
				+ getColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
						issueCatMap.get("REMOVAL OF ORPHANED OBJECTS".toUpperCase().trim())));

		processedReqMaster.setDistinctUsedIssueCatRemOfOrpObjects(getColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
				issueCatMap.get("REMOVAL OF ORPHANED OBJECTS".toUpperCase().trim())));

		processedReqMaster.setDistinctIssueCatRetFunc(getColumnCount(Hana_Profiler_Constant.UNUSED_DISTINCT,
				issueCatMap.get("RETIRED FUNCTIONALITY".toUpperCase().trim()))
				+ getColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
						issueCatMap.get("RETIRED FUNCTIONALITY".toUpperCase().trim())));

		processedReqMaster.setDistinctUsedIssueCatRetFunc(getColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
				issueCatMap.get("RETIRED FUNCTIONALITY".toUpperCase().trim())));

		processedReqMaster
				.setDistinctIssueCatEliminateOFStatusTables(getColumnCount(Hana_Profiler_Constant.UNUSED_DISTINCT,
						issueCatMap.get("ELIMINATION OF STATUS TABLES".toUpperCase().trim()))
						+ getColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
								issueCatMap.get("ELIMINATION OF STATUS TABLES".toUpperCase().trim())));

		processedReqMaster
				.setDistinctUsedIssueCatEliminateOFStatusTables(getColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
						issueCatMap.get("ELIMINATION OF STATUS TABLES".toUpperCase().trim())));

		processedReqMaster.setDistinctIssueCatReplaceNewFunc(getColumnCount(Hana_Profiler_Constant.UNUSED_DISTINCT,
				issueCatMap.get("REPLACED BY NEW FUNCTIONALITY".toUpperCase().trim()))
				+ getColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
						issueCatMap.get("REPLACED BY NEW FUNCTIONALITY".toUpperCase().trim())));

		processedReqMaster.setDistinctUsedIssueCatReplaceNewFunc(getColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
				issueCatMap.get("REPLACED BY NEW FUNCTIONALITY".toUpperCase().trim())));

		processedReqMaster.setDistinctIssueCatNewTransaction(getColumnCount(Hana_Profiler_Constant.UNUSED_DISTINCT,
				issueCatMap.get("NEW TRANSACTION".toUpperCase().trim()))
				+ getColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
						issueCatMap.get("NEW TRANSACTION".toUpperCase().trim())));

		processedReqMaster.setDistinctUsedIssueCatNewTransaction(getColumnCount(Hana_Profiler_Constant.USED_DISTINCT,
				issueCatMap.get("NEW TRANSACTION".toUpperCase().trim())));

		// Error Counts
		processedReqMaster.setErrorIssueCatCustomCodeAdaption(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT,
				issueCatMap.get("CUSTOM CODE ADAPTION".toUpperCase().trim()))
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
						issueCatMap.get("CUSTOM CODE ADAPTION".toUpperCase().trim())));

		processedReqMaster.setErrorUsedIssueCatCustomCodeAdaption(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
				issueCatMap.get("CUSTOM CODE ADAPTION".toUpperCase().trim())));

		processedReqMaster.setErrorIssueCatDataEleLenExt(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT,
				issueCatMap.get("DATA ELEMENT LENGTH EXTENSION".toUpperCase().trim()))
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
						issueCatMap.get("DATA ELEMENT LENGTH EXTENSION".toUpperCase().trim())));

		processedReqMaster.setErrorUsedIssueCatDataEleLenExt(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
				issueCatMap.get("DATA ELEMENT LENGTH EXTENSION".toUpperCase().trim())));

		processedReqMaster.setErrorIssueCatNewDataModel(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT,
				issueCatMap.get("NEW DATA MODEL".toUpperCase().trim()))
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
						issueCatMap.get("NEW DATA MODEL".toUpperCase().trim())));

		processedReqMaster.setErrorUsedIssueCatNewDataModel(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
				issueCatMap.get("NEW DATA MODEL".toUpperCase().trim())));

		processedReqMaster.setErrorIssueCatNewS4Func(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT,
				issueCatMap.get("NEW S4 FUNCTIONALITY".toUpperCase().trim()))
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
						issueCatMap.get("NEW S4 FUNCTIONALITY".toUpperCase().trim())));

		processedReqMaster.setErrorUsedIssueCatNewS4Func(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
				issueCatMap.get("NEW S4 FUNCTIONALITY".toUpperCase().trim())));

		processedReqMaster.setErrorIssueCatRemOfOrpObjects(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT,
				issueCatMap.get("REMOVAL OF ORPHANED OBJECTS".toUpperCase().trim()))
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
						issueCatMap.get("REMOVAL OF ORPHANED OBJECTS".toUpperCase().trim())));

		processedReqMaster.setErrorUsedIssueCatRemOfOrpObjects(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
				issueCatMap.get("REMOVAL OF ORPHANED OBJECTS".toUpperCase().trim())));

		processedReqMaster.setErrorIssueCatRetFunc(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT,
				issueCatMap.get("RETIRED FUNCTIONALITY".toUpperCase().trim()))
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
						issueCatMap.get("RETIRED FUNCTIONALITY".toUpperCase().trim())));

		processedReqMaster.setErrorUsedIssueCatRetFunc(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
				issueCatMap.get("RETIRED FUNCTIONALITY".toUpperCase().trim())));

		processedReqMaster
				.setErrorIssueCatEliminateOFStatusTables(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT,
						issueCatMap.get("ELIMINATION OF STATUS TABLES".toUpperCase().trim()))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
								issueCatMap.get("ELIMINATION OF STATUS TABLES".toUpperCase().trim())));

		processedReqMaster
				.setErrorUsedIssueCatEliminateOFStatusTables(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
						issueCatMap.get("ELIMINATION OF STATUS TABLES".toUpperCase().trim())));

		processedReqMaster.setErrorIssueCatReplaceNewFunc(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT,
				issueCatMap.get("REPLACED BY NEW FUNCTIONALITY".toUpperCase().trim()))
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
						issueCatMap.get("REPLACED BY NEW FUNCTIONALITY".toUpperCase().trim())));

		processedReqMaster.setErrorUsedIssueCatReplaceNewFunc(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
				issueCatMap.get("REPLACED BY NEW FUNCTIONALITY".toUpperCase().trim())));

		processedReqMaster.setErrorIssueCatNewTransaction(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT,
				issueCatMap.get("NEW TRANSACTION".toUpperCase().trim()))
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
						issueCatMap.get("NEW TRANSACTION".toUpperCase().trim())));

		processedReqMaster.setErrorUsedIssueCatNewTransaction(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT,
				issueCatMap.get("NEW TRANSACTION".toUpperCase().trim())));

	}

	private void setItemAreaS4Counts(Map<String, Integer> itemAreaMap, List<ProcessedRMCounts> reqMasterCountsList,
			long requestId) {
		for (Entry<String, Integer> entry : itemAreaMap.entrySet()) {
			ProcessedRMCounts processedRMCounts = new ProcessedRMCounts();

			processedRMCounts.setRequestId(requestId);
			processedRMCounts.setColName("Item Area");
			processedRMCounts.setColValue(entry.getKey());
			processedRMCounts.setCount(entry.getValue());

			reqMasterCountsList.add(processedRMCounts);
		}
	}

	private void setImpactedStdTransS4Count(Integer count, ProcessedRequestMaster processedReqMaster) {
		processedReqMaster.setTotalStdTransactionsCount(count);
	}

	private void setImpactedCloneAnalysisCounts(Map<String, Integer> cloneMap,
			ProcessedRequestMaster processedReqMaster) {
		processedReqMaster.setDistinctCloneObjCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, cloneMap)
				+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, cloneMap));

		processedReqMaster
				.setDistinctUsedCloneObjCount(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, cloneMap));
	}

	private void setRefImpactedCloneObjectsHANAS4(Integer cloneCount, Map<String, Integer> refMap,
			ProcessedRequestMaster processedReqMaster) {
		if (refMap.containsKey("Identical Source Code".toUpperCase().trim()))
			processedReqMaster.setIdenticalSrcCodeCount(refMap.get("Identical Source Code".toUpperCase().trim()));

		if (refMap.containsKey("Partly Similar Source Code".toUpperCase().trim()))
			processedReqMaster
					.setPartialSimilarSrcCodeCount(refMap.get("Partly Similar Source Code".toUpperCase().trim()));

		if (refMap.containsKey("Similar Source Code".toUpperCase().trim()))
			processedReqMaster.setSimilarSrcCodeCount(refMap.get("Similar Source Code".toUpperCase().trim()));

		if (refMap.containsKey("Very Similar Source Code".toUpperCase().trim()))
			processedReqMaster.setVrySimilarSrcCodeCount(refMap.get("Very Similar Source Code".toUpperCase().trim()));

		processedReqMaster.setDistinctCloneObjCountHANAS4(cloneCount);
	}

	private void setTotalImpCloneObjCounts(Map<String, Map<String, Integer>> totalCloneObjectMap,
			ProcessedRequestMaster processedReqMaster) {
		if (totalCloneObjectMap.containsKey("Identical Source Code".toUpperCase().trim())) {
			Map<String, Integer> usedMap = totalCloneObjectMap.get("Identical Source Code".toUpperCase().trim());
			processedReqMaster
					.setDistinctIdenticalSrcCodeCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, usedMap)
							+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));

			processedReqMaster.setDistinctIdenticalSrcCodeUsedCount(
					getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));
		}
		if (totalCloneObjectMap.containsKey("Partly Similar Source Code".toUpperCase().trim())) {
			Map<String, Integer> usedMap = totalCloneObjectMap.get("Partly Similar Source Code".toUpperCase().trim());
			processedReqMaster.setDistinctPartialSimilarSrcCodeCount(
					getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, usedMap)
							+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));

			processedReqMaster.setDistinctPartialSimilarSrcCodeUsedCount(
					getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));
		}
		if (totalCloneObjectMap.containsKey("Similar Source Code".toUpperCase().trim())) {
			Map<String, Integer> usedMap = totalCloneObjectMap.get("Similar Source Code".toUpperCase().trim());
			processedReqMaster
					.setDistinctSimilarSrcCodeCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, usedMap)
							+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));

			processedReqMaster
					.setDistinctSimilarSrcCodeUsedCount(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));
		}
		if (totalCloneObjectMap.containsKey("Very Similar Source Code".toUpperCase().trim())) {
			Map<String, Integer> usedMap = totalCloneObjectMap.get("Very Similar Source Code".toUpperCase().trim());
			processedReqMaster
					.setDistinctVrySimilarSrcCodeCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, usedMap)
							+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));

			processedReqMaster.setDistinctVrySimilarSrcCodeUsedCount(
					getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, usedMap));
		}
	}

	private void setSmodilogObjCounts(Map<String, Map<String, Integer>> objMap,
			ProcessedRequestMaster processedReqMater) {
		int totalDistinctCount = getTotalSmodilogCount(objMap, Hana_Profiler_Constant.DISTINCT_COUNT);

		int errorSPDDObjCount = 0, errorSPAUObjCount = 0;
		int totalErrorCount = getTotalSmodilogCount(objMap, Hana_Profiler_Constant.ERROR_COUNT);
		errorSPDDObjCount = getSmodilogObjErrorCount("DTEL", objMap) + getSmodilogObjErrorCount("TOBJ", objMap)
				+ getSmodilogObjErrorCount("TTYP", objMap) + getSmodilogObjErrorCount("DOMA", objMap)
				+ getSmodilogObjErrorCount("TABL", objMap);
		errorSPAUObjCount = totalErrorCount - errorSPDDObjCount;

		processedReqMater.setDistinctStdModObjCount(totalDistinctCount);

		processedReqMater.setErrorStdModObjCount(totalErrorCount);
		processedReqMater.setErrorSPDDObjCount(errorSPDDObjCount);
		processedReqMater.setErrorSPAUObjCount(errorSPAUObjCount);

		processedReqMater.setDistinctSmodDTELCount(getSmodilogObjCount("DTEL", objMap));
		processedReqMater.setDistinctSmodDOMACount(getSmodilogObjCount("DOMA", objMap));
		processedReqMater.setDistinctSmodTTYPCount(getSmodilogObjCount("TTYP", objMap));
		processedReqMater.setDistinctSmodTOBJCount(getSmodilogObjCount("TOBJ", objMap));
		processedReqMater.setDistinctSmodTABLCount(getSmodilogObjCount("TABL", objMap));
		processedReqMater.setDistinctSmodCLASCount(getSmodilogObjCount("CLAS", objMap));
		processedReqMater.setDistinctSmodPROGCount(getSmodilogObjCount("PROG", objMap));
		processedReqMater.setDistinctSmodFUGRCount(getSmodilogObjCount("FUGR", objMap));
		processedReqMater.setDistinctSmodPARACount(getSmodilogObjCount("PARA", objMap));
		processedReqMater.setDistinctSmodSMIMCount(getSmodilogObjCount("SMIM", objMap));
		processedReqMater.setDistinctSmodSXSDCount(getSmodilogObjCount("SXSD", objMap));
		processedReqMater.setDistinctSmodVIEWCount(getSmodilogObjCount("VIEW", objMap));
		processedReqMater.setDistinctSmodWAPACount(getSmodilogObjCount("WAPA", objMap));
		processedReqMater.setDistinctSmodENHOCount(getSmodilogObjCount("ENHO", objMap));
		processedReqMater.setDistinctSmodINTFCount(getSmodilogObjCount("INTF", objMap));
		processedReqMater.setDistinctSmodSHLPCount(getSmodilogObjCount("SHLP", objMap));
		processedReqMater.setDistinctSmodSMODCount(getSmodilogObjCount("SMOD", objMap));
		processedReqMater.setDistinctSmodSXCICount(getSmodilogObjCount("SXCI", objMap));
		processedReqMater.setDistinctSmodFUGXCount(getSmodilogObjCount("FUGX", objMap));
		processedReqMater.setDistinctSmodPDTSCount(getSmodilogObjCount("PDTS", objMap));
		processedReqMater.setDistinctSmodLODECount(getSmodilogObjCount("LODE", objMap));
		processedReqMater.setDistinctSmodDEVCCount(getSmodilogObjCount("DEVC", objMap));
		processedReqMater.setDistinctSmodTRANCount(getSmodilogObjCount("TRAN", objMap));
		processedReqMater.setDistinctSmodENQUCount(getSmodilogObjCount("ENQU", objMap));
		processedReqMater.setDistinctSmodMSAGCount(getSmodilogObjCount("MSAG", objMap));
		processedReqMater.setDistinctSmodSPRXCount(getSmodilogObjCount("SPRX", objMap));
		processedReqMater.setDistinctSmodPDWSCount(getSmodilogObjCount("PDWS", objMap));
		processedReqMater.setDistinctSmodSSFOCount(getSmodilogObjCount("SSFO", objMap));
		processedReqMater.setDistinctSmodSSSTCount(getSmodilogObjCount("SSST", objMap));
		processedReqMater.setDistinctSmodENHSCount(getSmodilogObjCount("ENHS", objMap));
		processedReqMater.setDistinctSmodSFPICount(getSmodilogObjCount("SFPI", objMap));
		processedReqMater.setDistinctSmodSFPFCount(getSmodilogObjCount("SFPF", objMap));
		processedReqMater.setDistinctSmodPFCSCount(getSmodilogObjCount("PFCS", objMap));
		processedReqMater.setDistinctSmodLOIECount(getSmodilogObjCount("LOIE", objMap));
		processedReqMater.setDistinctSmodLODCCount(getSmodilogObjCount("LODC", objMap));
		processedReqMater.setDistinctSmodSOBJCount(getSmodilogObjCount("SOBJ", objMap));
		processedReqMater.setDistinctSmodSOTRCount(getSmodilogObjCount("SOTR", objMap));
		processedReqMater.setDistinctSmodUSRRCount(getSmodilogObjCount("USRR", objMap));
		processedReqMater.setDistinctSmodUSRECount(getSmodilogObjCount("USRE", objMap));
		processedReqMater.setDistinctSmodENHCCount(getSmodilogObjCount("ENHC", objMap));
		processedReqMater.setDistinctSmodLSMWCount(getSmodilogObjCount("LSMW", objMap));
		processedReqMater.setDistinctSmodWDYNCount(getSmodilogObjCount("WDYN", objMap));
		processedReqMater.setDistinctSmodIATUCount(getSmodilogObjCount("IATU", objMap));
		processedReqMater.setDistinctSmodXSLTCount(getSmodilogObjCount("XSLT", objMap));
		processedReqMater.setDistinctSmodACGRCount(getSmodilogObjCount("ACGR", objMap));
		processedReqMater.setDistinctSmodSCVICount(getSmodilogObjCount("SCVI", objMap));
		processedReqMater.setDistinctSmodPHDECount(getSmodilogObjCount("PHDE", objMap));
		processedReqMater.setDistinctSmodPOCSCount(getSmodilogObjCount("POCS", objMap));
		processedReqMater.setDistinctSmodFUGSCount(getSmodilogObjCount("FUGS", objMap));
		processedReqMater.setDistinctSmodWEBICount(getSmodilogObjCount("WEBI", objMap));
		processedReqMater.setDistinctSmodBOBFCount(getSmodilogObjCount("BOBF", objMap));
		processedReqMater.setDistinctSmodSUSOCount(getSmodilogObjCount("SUSO", objMap));
		processedReqMater.setDistinctSmodVCLSCount(getSmodilogObjCount("VCLS", objMap));
		processedReqMater.setDistinctSmodINDXCount(getSmodilogObjCount("INDX", objMap));
		processedReqMater.setDistinctSmodREPTCount(getSmodilogObjCount("REPT", objMap));
		processedReqMater.setDistinctSmodDIALCount(getSmodilogObjCount("DIAL", objMap));
		processedReqMater.setDistinctSmodSTVICount(getSmodilogObjCount("STVI", objMap));
		processedReqMater.setDistinctSmodAQSGCount(getSmodilogObjCount("AQSG", objMap));
		processedReqMater.setDistinctSmodAQBGCount(getSmodilogObjCount("AQBG", objMap));
		processedReqMater.setDistinctSmodAQQUCount(getSmodilogObjCount("AQQU", objMap));
	}

	private void setAUCTDescOfChangeCounts(Integer inactiveObjCount, Map<String, Integer> countMap,
			ProcessedRequestMaster processedReqMaster, RequestForm requestFormObj, Integer nonUniCount) {
		if ("No".equalsIgnoreCase(requestFormObj.getUnicodeCompliant())
				&& "Yes".equalsIgnoreCase(requestFormObj.getEnableUnicode())) {
			processedReqMaster.setUnicodeErrorCount(nonUniCount);
			processedReqMaster.setManPreCheckErrors(countMap.get("PRECHECK") + nonUniCount + inactiveObjCount);
		} else {
			processedReqMaster.setUnicodeErrorCount(countMap.get("UNICODE"));
			processedReqMaster.setManPreCheckErrors(countMap.get("PRECHECK") + inactiveObjCount);
		}

		processedReqMaster.setSyntaxErrorCount(countMap.get("SYNTAX"));
		processedReqMaster.setInactiveObjCount(inactiveObjCount);
	}

	private void setExtNamespaceAUCTCounts(Map<String, Integer> countMap, ProcessedRequestMaster processedReqMaster,
			RequestForm requestFormObj, Integer nonUniExtCount) {
		if ("No".equalsIgnoreCase(requestFormObj.getUnicodeCompliant())
				&& "Yes".equalsIgnoreCase(requestFormObj.getEnableUnicode())) {
			processedReqMaster.setErrorExtNamespaceUnicodeErrorCount(nonUniExtCount);
			processedReqMaster
					.setErrorExtNamespacePreCheckErrorCount(countMap.get("PRECHECK_EXTNAMESPACE") + nonUniExtCount);
		} else {
			processedReqMaster.setErrorExtNamespaceUnicodeErrorCount(countMap.get("UNICODE_EXTNAMESPACE"));
			processedReqMaster.setErrorExtNamespacePreCheckErrorCount(countMap.get("PRECHECK_EXTNAMESPACE"));
		}

		processedReqMaster.setErrorExtNamespaceSyntaxErrorCount(countMap.get("SYNTAX_EXTNAMESPACE"));
	}

	private void setTScopeCounts(Integer processCount, Integer objCount, ProcessedRequestMaster processedReqMaster) {
		processedReqMaster.setTscopeProcessCount(processCount);

		processedReqMaster.setTscopeObjCount(objCount);
	}

	private void setDistinctObjCountHANAS4OSMig(Map<String, Integer> distinctObjMap,
			Map<String, Integer> distinctMandObjMap, Map<String, Integer> commonObjMap,
			Map<String, Integer> commonMandObjMap, ProcessedRequestMaster processedReqMaster) {
		processedReqMaster
				.setDistinctImpactHanaS4OsMig(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, distinctObjMap)
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, distinctObjMap));

		processedReqMaster.setDistinctImpactUsedHanaS4OsMig(
				getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, distinctObjMap));

		processedReqMaster.setDistinctMandatoryImpactHanaS4OsMig(
				getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, distinctMandObjMap)
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, distinctMandObjMap));

		processedReqMaster.setDistinctMandatoryImpacUnusedHanaS4OsMig(
				getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, distinctMandObjMap));

		if (processedReqMaster.getDistinctImpactHanaS4OsMig() != 0)
			processedReqMaster
					.setManImpactHanaS4OsMigPerc(((float) processedReqMaster.getDistinctMandatoryImpactHanaS4OsMig()
							/ (float) processedReqMaster.getDistinctImpactHanaS4OsMig()) * 100);

		if (processedReqMaster.getDistinctMandatoryImpactHanaS4OsMig() != 0)
			processedReqMaster.setManImpacUnusedPercHanaS4OsMigPerc(
					((float) processedReqMaster.getDistinctMandatoryImpacUnusedHanaS4OsMig()
							/ (float) processedReqMaster.getDistinctMandatoryImpactHanaS4OsMig()) * 100);

		processedReqMaster.setTotalCommonImpactedObjCountHanaAndS4AndOSMig(
				getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, commonObjMap)
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, commonObjMap));

		processedReqMaster.setTotalCommonImpactedUsedObjCountHanaAndS4AndOSMig(
				getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, commonObjMap));

		processedReqMaster.setTotalCommonManImpactedObjCountHanaAndS4AndOSMig(
				getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, commonMandObjMap)
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, commonMandObjMap));

		processedReqMaster.setTotalCommonManImpactedUsedObjCountHanaAndS4AndOSMig(
				getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, commonMandObjMap));
	}

	private void setDistinctObjCountHANAS4(Map<String, Integer> distinctObjMap, Map<String, Integer> distinctMandObjMap,
			Map<String, Integer> commonObjMap, Map<String, Integer> commonMandObjMap,
			ProcessedRequestMaster processedReqMaster) {
		processedReqMaster
				.setDistinctImpactHanaS4(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, distinctObjMap)
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, distinctObjMap));

		processedReqMaster
				.setDistinctImpactUsedHanaS4(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, distinctObjMap));

		processedReqMaster.setDistinctMandatoryImpactHanaS4(
				getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, distinctMandObjMap)
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, distinctMandObjMap));

		processedReqMaster.setDistinctMandatoryImpacUnusedHanaS4(
				getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, distinctMandObjMap));

		if (processedReqMaster.getDistinctImpactHanaS4() != 0)
			processedReqMaster.setManImpactHanaS4Perc(((float) processedReqMaster.getDistinctMandatoryImpactHanaS4()
					/ (float) processedReqMaster.getDistinctImpactHanaS4()) * 100);

		if (processedReqMaster.getDistinctMandatoryImpactHanaS4() != 0)
			processedReqMaster
					.setManImpacUnusedPercHanaS4Perc(((float) processedReqMaster.getDistinctMandatoryImpacUnusedHanaS4()
							/ (float) processedReqMaster.getDistinctMandatoryImpactHanaS4()) * 100);

		processedReqMaster.setTotalCommonImpactedObjCountHanaAndS4(
				getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, commonObjMap)
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, commonObjMap));

		processedReqMaster.setTotalCommonImpactedUsedObjCountHanaAndS4(
				getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, commonObjMap));

		processedReqMaster.setTotalCommonManImpactedObjCountHanaAndS4(
				getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, commonMandObjMap)
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, commonMandObjMap));

		processedReqMaster.setTotalCommonManImpactedUsedObjCountHanaAndS4(
				getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, commonMandObjMap));
	}

	public void setCommonHANAS4ExtNamespaceCounts(Map<String, Integer> impObjCountMap,
			Map<String, Integer> mandObjCountMap, ProcessedRequestMaster processedReqMaster) {
		processedReqMaster.setDistinctExtNamespaceCommonImpObjCountHANAS4(
				getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, impObjCountMap)
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjCountMap));

		processedReqMaster.setDistinctExtNamespaceCommonUsedImpObjCountHANAS4(
				getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, impObjCountMap));

		processedReqMaster.setDistinctExtNamespaceCommonMandCountHANAS4(
				getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, mandObjCountMap)
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, mandObjCountMap));

		processedReqMaster.setDistinctExtNamespaceCommonMandUsedCountHANAS4(
				getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, mandObjCountMap));
	}

	private void setSIACounts(Map<String, Integer> countMap, Integer impactedRoleCount, Integer roleCount,
			ProcessedRequestMaster processedReqMaster) {
		processedReqMaster.setSecurityTotalRoles(roleCount);

		processedReqMaster.setTotalRolesImpacted(impactedRoleCount);

		processedReqMaster.setSecRoleNeedsModification(getColumnCount(
				"Role Needs Immediate Modification as there is a change in transaction code. New tranaction code may bring new auth objects. Object report may have some suggestions for the new tcode."
						.toUpperCase().trim(),
				countMap));

		processedReqMaster.setSecRoleModFiori(
				getColumnCount("Role Need Modification Only if FIORI Adopted".toUpperCase().trim(), countMap));

		processedReqMaster.setSecTcodeObsOrNoReplacement(
				getColumnCount("Tcode is Obsolete or No Replacement available.".toUpperCase().trim(), countMap));

		processedReqMaster.setSecRoleNeedModCleanup(
				getColumnCount("Role Needs Modification for cleanup activity.".toUpperCase().trim(), countMap));

		processedReqMaster.setSecSapNewTcodeVersions(getColumnCount(
				"SAP may comeout with a new version of these tcodes. Immediate modification may not be required"
						.toUpperCase().trim(),
				countMap));

		if (processedReqMaster.getSecurityTotalRoles() != 0)
			processedReqMaster.setSecRoleNeedModPercentage(((float) processedReqMaster.getTotalRolesImpacted()
					/ (float) processedReqMaster.getSecurityTotalRoles()) * 100);
	}

	private void setImpactedBackgroundJobCounts(Map<String, Integer> countMap,
			ProcessedRequestMaster processedReqMaster) {
		processedReqMaster.setTotalImpBackgrounJob(countMap.get("BATCH JOB COUNT"));

		processedReqMaster.setDistinctImpProgramCount(countMap.get("PROGRAM COUNT"));
	}

	private void setOSMigCounts(Map<String, Integer> objCountMap, Map<String, Integer> mandCountMap,
			ProcessedRequestMaster processedReqMaster) {
		processedReqMaster.setDistinctObjCount(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT, objCountMap));

		processedReqMaster.setTotalErrorCount(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT, objCountMap));

		processedReqMaster
				.setDistinctManImpactedObjCount(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT, mandCountMap));

		processedReqMaster
				.setTotalManImpactedObjectCount(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT, mandCountMap));
	}

	private void setLogFilePathCmdOSMigCounts(Integer logCommandCount, Integer logFilePathCount,
			ProcessedRequestMaster processedReqMaster) {
		processedReqMaster.setDistinctLogCommandCountOSMig(logCommandCount);

		processedReqMaster.setDistinctLogFilePathCountOSMig(logFilePathCount);
	}

	private void setRemCatDescOSMigCounts(Map<String, Map<String, Map<String, Integer>>> remCatDescMap,
			ProcessedRequestMaster processedReqMaster) {
		if (remCatDescMap.containsKey("Mandatory".toUpperCase().trim())) {
			Map<String, Map<String, Integer>> descMap = remCatDescMap.get("Mandatory".toUpperCase().trim());

			if (descMap.containsKey("CALL SYSTEM ID".toUpperCase().trim())) {
				Map<String, Integer> countMap = descMap.get("CALL SYSTEM ID".toUpperCase().trim());

				processedReqMaster.setDistinctManImpactedObjCountCallSystemID(
						getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT, countMap));

				processedReqMaster.setTotalManImpactedObjectCountCallSystemID(
						getColumnCount(Hana_Profiler_Constant.ERROR_COUNT, countMap));
			}

			if (descMap.containsKey("SXPG_COMMAND_EXECUTE".toUpperCase().trim())) {
				Map<String, Integer> countMap = descMap.get("SXPG_COMMAND_EXECUTE".toUpperCase().trim());

				processedReqMaster.setDistinctManImpactedObjCountSXPGCommandExecute(
						getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT, countMap));

				processedReqMaster.setTotalManImpactedObjectCountSXPGCommandExecute(
						getColumnCount(Hana_Profiler_Constant.ERROR_COUNT, countMap));
			}
		}

		if (remCatDescMap.containsKey("Optional".toUpperCase().trim())) {
			Map<String, Map<String, Integer>> descMap = remCatDescMap.get("Optional".toUpperCase().trim());

			if (descMap.containsKey("OPEN DATASET".toUpperCase().trim())) {
				Map<String, Integer> countMap = descMap.get("OPEN DATASET".toUpperCase().trim());

				processedReqMaster.setDistinctOptImpactedObjCountOpenDataset(
						getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT, countMap));

				processedReqMaster.setTotalOptImpactedObjCountOpenDataset(
						getColumnCount(Hana_Profiler_Constant.ERROR_COUNT, countMap));
			}
		}
	}

	private void setErrorObjectCounts(Map<String, Map<String, Integer>> errorCountMap,
			ProcessedRequestMaster processedReqMaster) {
		processedReqMaster.setTotalErrorCount(getTotalObjectCount(errorCountMap));

		processedReqMaster.setErrorUsedCount(getTotalUsedCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap));

		processedReqMaster
				.setErrorCLASCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, errorCountMap.get("CLAS"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("CLAS")));
		processedReqMaster.setErrorUsedCLASCount(
				getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("CLAS")));

		processedReqMaster
				.setErrorBWTRCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, errorCountMap.get("BWTR"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("BWTR")));
		processedReqMaster.setErrorUsedBWTRCount(
				getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("BWTR")));

		processedReqMaster
				.setErrorBWTSCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, errorCountMap.get("BWTS"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("BWTS")));
		processedReqMaster.setErrorUsedBWTSCount(
				getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("BWTS")));

		processedReqMaster
				.setErrorBWURCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, errorCountMap.get("BWUR"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("BWUR")));
		processedReqMaster.setErrorUsedBWURCount(
				getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("BWUR")));

		processedReqMaster
				.setErrorBWIGCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, errorCountMap.get("BWIG"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("BWIG")));
		processedReqMaster.setErrorUsedBWIGCount(
				getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("BWIG")));

		processedReqMaster
				.setErrorCDATCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, errorCountMap.get("CDAT"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("CDAT")));
		processedReqMaster.setErrorUsedCDATCount(
				getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("CDAT")));

		processedReqMaster
				.setErrorTABUCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, errorCountMap.get("TABU"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("TABU")));
		processedReqMaster.setErrorUsedTABUCount(
				getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("TABU")));

		processedReqMaster
				.setErrorPROGCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, errorCountMap.get("PROG"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("PROG")));
		processedReqMaster.setErrorUsedPROGCount(
				getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("PROG")));

		processedReqMaster
				.setErrorSSFOCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, errorCountMap.get("SSFO"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("SSFO")));
		processedReqMaster.setErrorUsedSSFOCount(
				getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("SSFO")));

		processedReqMaster
				.setErrorSFPFCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, errorCountMap.get("SFPF"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("SFPF")));
		processedReqMaster.setErrorUsedSFPFCount(
				getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("SFPF")));

		processedReqMaster
				.setErrorSFPICount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, errorCountMap.get("SFPI"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("SFPI")));
		processedReqMaster.setErrorUsedSFPICount(
				getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("SFPI")));

		processedReqMaster
				.setErrorFUGRCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, errorCountMap.get("FUGR"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("FUGR")));
		processedReqMaster.setErrorUsedFUGRCount(
				getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("FUGR")));

		processedReqMaster
				.setErrorENHOCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, errorCountMap.get("ENHO"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("ENHO")));
		processedReqMaster.setErrorUsedENHOCount(
				getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("ENHO")));

		processedReqMaster
				.setErrorENHSCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, errorCountMap.get("ENHS"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("ENHS")));
		processedReqMaster.setErrorUsedENHSCount(
				getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("ENHS")));

		processedReqMaster
				.setErrorENHCCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, errorCountMap.get("ENHC"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("ENHC")));
		processedReqMaster.setErrorUsedENHCCount(
				getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("ENHC")));

		processedReqMaster
				.setErrorLSMWCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, errorCountMap.get("LSMW"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("LSMW")));
		processedReqMaster.setErrorUsedLSMWCount(
				getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("LSMW")));

		processedReqMaster
				.setErrorUSRECount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, errorCountMap.get("USRE"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("USRE")));
		processedReqMaster.setErrorUsedUSRECount(
				getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("USRE")));

		processedReqMaster
				.setErrorUSRRCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, errorCountMap.get("USRR"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("USRR")));
		processedReqMaster.setErrorUsedUSRRCount(
				getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("USRR")));

		processedReqMaster
				.setErrorWDYNCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, errorCountMap.get("WDYN"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("WDYN")));
		processedReqMaster.setErrorUsedWDYNCount(
				getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("WDYN")));

		processedReqMaster
				.setErrorREPTCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, errorCountMap.get("REPT"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("REPT")));
		processedReqMaster.setErrorUsedREPTCount(
				getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("REPT")));

		processedReqMaster
				.setErrorINDXCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, errorCountMap.get("INDX"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("INDX")));
		processedReqMaster.setErrorUsedINDXCount(
				getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("INDX")));

		processedReqMaster
				.setErrorVIEWCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, errorCountMap.get("VIEW"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("VIEW")));
		processedReqMaster.setErrorUsedVIEWCount(
				getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("VIEW")));

		processedReqMaster
				.setErrorDTELCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, errorCountMap.get("DTEL"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("DTEL")));
		processedReqMaster.setErrorUsedDTELCount(
				getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("DTEL")));

		processedReqMaster
				.setErrorFUGSCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, errorCountMap.get("FUGS"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("FUGS")));
		processedReqMaster.setErrorUsedFUGSCount(
				getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("FUGS")));

		processedReqMaster
				.setErrorAQQUCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, errorCountMap.get("AQQU"))
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("AQQU")));
		processedReqMaster.setErrorUsedAQQUCount(
				getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, errorCountMap.get("AQQU")));
	}

	private void setHANAAutoStatusYCounts(Map<String, Integer> countMap, ProcessedRequestMaster processedReqMaster) {
		processedReqMaster.setDistinctAutomaticCount(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT, countMap));
		processedReqMaster.setErrorAutomaticCount(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT, countMap));
	}

	private void setExtNamespaceMandHANAS4Counts(Map<String, Integer> countMap,
			ProcessedRequestMaster processedReqMaster) {
		processedReqMaster
				.setDistinctExtNamespaceMandCount(getColumnCount(Hana_Profiler_Constant.UNUSED_ALL_COUNT, countMap)
						+ getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, countMap));

		processedReqMaster
				.setDistinctExtNamespaceMandUsedCount(getColumnCount(Hana_Profiler_Constant.USED_ALL_COUNT, countMap));
	}

	private void setS4RemCatIssueCatCounts(Map<String, Map<String, Map<String, Integer>>> countMap,
			ProcessedRequestMaster processedReqMaster) {
		if (countMap.containsKey("Mandatory".toUpperCase().trim())) {
			Map<String, Map<String, Integer>> map = countMap.get("Mandatory".toUpperCase().trim());

			processedReqMaster.setDistinctManIssueCatCustomCodeAdaption(getColumnCount(
					Hana_Profiler_Constant.DISTINCT_COUNT, map.get("CUSTOM CODE ADAPTION".toUpperCase().trim())));

			processedReqMaster.setDistinctManIssueCatDataEleLenExt(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
					map.get("DATA ELEMENT LENGTH EXTENSION".toUpperCase().trim())));

			processedReqMaster
					.setDistinctManIssueCatEliminateOFStatusTables(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
							map.get("ELIMINATION OF STATUS TABLES".toUpperCase().trim())));

			processedReqMaster.setDistinctManIssueCatNewDataModel(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
					map.get("NEW DATA MODEL".toUpperCase().trim())));

			processedReqMaster.setDistinctManIssueCatNewS4Func(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
					map.get("NEW S4 FUNCTIONALITY".toUpperCase().trim())));

			processedReqMaster.setDistinctManIssueCatNewTransaction(getColumnCount(
					Hana_Profiler_Constant.DISTINCT_COUNT, map.get("NEW TRANSACTION".toUpperCase().trim())));

			processedReqMaster
					.setDistinctManIssueCatRemOfOrpObjects(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
							map.get("REMOVAL OF ORPHANED OBJECTS".toUpperCase().trim())));

			processedReqMaster
					.setDistinctManIssueCatReplaceNewFunc(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
							map.get("REPLACED BY NEW FUNCTIONALITY".toUpperCase().trim())));

			processedReqMaster.setDistinctManIssueCatRetFunc(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
					map.get("RETIRED FUNCTIONALITY".toUpperCase().trim())));

			processedReqMaster.setErrorManIssueCatCustomCodeAdaption(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
					map.get("CUSTOM CODE ADAPTION".toUpperCase().trim())));

			processedReqMaster.setErrorManIssueCatDataEleLenExt(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
					map.get("DATA ELEMENT LENGTH EXTENSION".toUpperCase().trim())));

			processedReqMaster.setErrorManIssueCatEliminateOFStatusTables(getColumnCount(
					Hana_Profiler_Constant.ERROR_COUNT, map.get("ELIMINATION OF STATUS TABLES".toUpperCase().trim())));

			processedReqMaster.setErrorManIssueCatNewDataModel(
					getColumnCount(Hana_Profiler_Constant.ERROR_COUNT, map.get("NEW DATA MODEL".toUpperCase().trim())));

			processedReqMaster.setErrorManIssueCatNewS4Func(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
					map.get("NEW S4 FUNCTIONALITY".toUpperCase().trim())));

			processedReqMaster.setErrorManIssueCatNewTransaction(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
					map.get("NEW TRANSACTION".toUpperCase().trim())));

			processedReqMaster.setErrorManIssueCatRemOfOrpObjects(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
					map.get("REMOVAL OF ORPHANED OBJECTS".toUpperCase().trim())));

			processedReqMaster.setErrorManIssueCatReplaceNewFunc(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
					map.get("REPLACED BY NEW FUNCTIONALITY".toUpperCase().trim())));

			processedReqMaster.setErrorManIssueCatRetFunc(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
					map.get("RETIRED FUNCTIONALITY".toUpperCase().trim())));
		}

		if (countMap.containsKey("Optional".toUpperCase().trim())) {
			Map<String, Map<String, Integer>> map = countMap.get("Optional".toUpperCase().trim());

			processedReqMaster.setDistinctOptIssueCatCustomCodeAdaption(getColumnCount(
					Hana_Profiler_Constant.DISTINCT_COUNT, map.get("CUSTOM CODE ADAPTION".toUpperCase().trim())));

			processedReqMaster.setDistinctOptIssueCatDataEleLenExt(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
					map.get("DATA ELEMENT LENGTH EXTENSION".toUpperCase().trim())));

			processedReqMaster
					.setDistinctOptIssueCatEliminateOFStatusTables(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
							map.get("ELIMINATION OF STATUS TABLES".toUpperCase().trim())));

			processedReqMaster.setDistinctOptIssueCatNewDataModel(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
					map.get("NEW DATA MODEL".toUpperCase().trim())));

			processedReqMaster.setDistinctOptIssueCatNewS4Func(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
					map.get("NEW S4 FUNCTIONALITY".toUpperCase().trim())));

			processedReqMaster.setDistinctOptIssueCatNewTransaction(getColumnCount(
					Hana_Profiler_Constant.DISTINCT_COUNT, map.get("NEW TRANSACTION".toUpperCase().trim())));

			processedReqMaster
					.setDistinctOptIssueCatRemOfOrpObjects(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
							map.get("REMOVAL OF ORPHANED OBJECTS".toUpperCase().trim())));

			processedReqMaster
					.setDistinctOptIssueCatReplaceNewFunc(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
							map.get("REPLACED BY NEW FUNCTIONALITY".toUpperCase().trim())));

			processedReqMaster.setDistinctOptIssueCatRetFunc(getColumnCount(Hana_Profiler_Constant.DISTINCT_COUNT,
					map.get("RETIRED FUNCTIONALITY".toUpperCase().trim())));

			processedReqMaster.setErrorOptIssueCatCustomCodeAdaption(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
					map.get("CUSTOM CODE ADAPTION".toUpperCase().trim())));

			processedReqMaster.setErrorOptIssueCatDataEleLenExt(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
					map.get("DATA ELEMENT LENGTH EXTENSION".toUpperCase().trim())));

			processedReqMaster.setErrorOptIssueCatEliminateOFStatusTables(getColumnCount(
					Hana_Profiler_Constant.ERROR_COUNT, map.get("ELIMINATION OF STATUS TABLES".toUpperCase().trim())));

			processedReqMaster.setErrorOptIssueCatNewDataModel(
					getColumnCount(Hana_Profiler_Constant.ERROR_COUNT, map.get("NEW DATA MODEL".toUpperCase().trim())));

			processedReqMaster.setErrorOptIssueCatNewS4Func(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
					map.get("NEW S4 FUNCTIONALITY".toUpperCase().trim())));

			processedReqMaster.setErrorOptIssueCatNewTransaction(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
					map.get("NEW TRANSACTION".toUpperCase().trim())));

			processedReqMaster.setErrorOptIssueCatRemOfOrpObjects(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
					map.get("REMOVAL OF ORPHANED OBJECTS".toUpperCase().trim())));

			processedReqMaster.setErrorOptIssueCatReplaceNewFunc(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
					map.get("REPLACED BY NEW FUNCTIONALITY".toUpperCase().trim())));

			processedReqMaster.setErrorOptIssueCatRetFunc(getColumnCount(Hana_Profiler_Constant.ERROR_COUNT,
					map.get("RETIRED FUNCTIONALITY".toUpperCase().trim())));
		}
	}

	private Integer getColumnCount(String key, Map<String, Integer> map) {
		Integer count = 0;

		if (MapUtils.isNotEmpty(map) && map.containsKey(key))
			count = map.get(key);

		return count;
	}

	private int getTotalSmodilogCount(Map<String, Map<String, Integer>> objMap, String key) {
		int totalCount = 0;

		if (MapUtils.isNotEmpty(objMap)) {
			for (String obj : objMap.keySet()) {
				Map<String, Integer> countMap = objMap.get(obj);
				totalCount += countMap.get(key);
			}
		}

		return totalCount;
	}

	private int getSmodilogObjErrorCount(String key, Map<String, Map<String, Integer>> objMap) {
		int count = 0;

		if (MapUtils.isNotEmpty(objMap) && objMap.containsKey(key))
			count = objMap.get(key).get(Hana_Profiler_Constant.ERROR_COUNT);

		return count;
	}

	private int getSmodilogObjCount(String key, Map<String, Map<String, Integer>> objMap) {
		int count = 0;

		if (MapUtils.isNotEmpty(objMap) && objMap.containsKey(key))
			count = objMap.get(key).get(Hana_Profiler_Constant.DISTINCT_COUNT);

		return count;
	}

	private Integer getTotalUsedCount(String key, Map<String, Map<String, Integer>> resultMap) {
		int count = 0;

		if (MapUtils.isNotEmpty(resultMap)) {
			count = resultMap.values().stream().flatMap(innerMap -> innerMap.entrySet().stream())
					.filter(filterMap -> key.equals(filterMap.getKey())).mapToInt(filterMap -> filterMap.getValue())
					.sum();
		}

		return count;
	}

	private Integer getTotalObjectCount(Map<String, Map<String, Integer>> resultMap) {
		int count = 0;

		if (MapUtils.isNotEmpty(resultMap)) {
			count = resultMap.values().stream().flatMap(innerMap -> innerMap.entrySet().stream())
					.mapToInt(map -> map.getValue()).sum();
		}

		return count;
	}
	
	@Override
	public List<ProcessedRequestMasterModel> getRequestMasterList(){
		List<ProcessedRequestMasterModel> masterList = new LinkedList<>();
		
		List<ProcessedRequestMaster> masterEntity=reqMasterDAO.getReqMasterData();
		for(ProcessedRequestMaster reqEntity : masterEntity){
			ProcessedRequestMasterModel reqMaster = new ProcessedRequestMasterModel();
			BeanUtils.copyProperties(reqEntity, reqMaster);
			masterList.add(reqMaster);
		}
		return masterList;
		
	}
}
