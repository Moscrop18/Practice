package com.act.model.DRL;

import java.util.ArrayList;
import java.util.List;

import com.act.client.model.LsmwDrool;
import com.act.displaygrid.model.HanaProfile;
import com.act.fileprocessing.model.HanaProfilerStepOutput;

public class HanaIntermediate {
	
	
	
	
	/*private String hanaintermed;
	private int abc;
	public String getHanaintermed() {
		return hanaintermed;
	}
	public void setHanaintermed(String hanaintermed) {
		this.hanaintermed = hanaintermed;
	}
	public int getAbc() {
		return abc;
	}
	public void setAbc(int abc) {
		this.abc = abc;
	}*/

	
	
	
	
	
	
	
	/*// working code
	private List<String> hanaProfileList;
	//private List<HanaProfilerStepOutput> hanaProfileStepList;
	
	private List<HanaProfile> listOfHanaProfile;
	
	
	
	public String testRule = "Hi";
		
	public String getTestRule() {
		return testRule;
	}
	public void setTestRule(String testRule) {
		this.testRule = testRule;
	}
	public List<HanaProfile> getListOfHanaProfile() {
		return listOfHanaProfile;
	}
	public void setListOfHanaProfile(List<HanaProfile> listOfHanaProfile) {
		this.listOfHanaProfile = listOfHanaProfile;
	}
	public List<String> getHanaProfileList() {
		return hanaProfileList;
	}
	public void setHanaProfileList(List<String> hanaProfileList) {
		this.hanaProfileList = hanaProfileList;
	}
	//till here working
	*
	*/
	
	
	
	Long execRequestId;

	public Long getExecRequestId() {
		return execRequestId;
	}
	public void setExecRequestId(Long execRequestId) {
		this.execRequestId = execRequestId;
	}

	/*public List<HanaProfilerStepOutput> getHanaProfileStepList() {
		return hanaProfileStepList;
	}
	public void setHanaProfileStepList(List<HanaProfilerStepOutput> hanaProfileStepList) {
		this.hanaProfileStepList = hanaProfileStepList;
	}
*/
	private List<LsmwDrool> LsmwDroolList;
	

	public String testRule = "Hi";
		
	public String getTestRule() {
		return testRule;
	}
	public void setTestRule(String testRule) {
		this.testRule = testRule;
	}

	public List<LsmwDrool> getLsmwDroolList() {
		return LsmwDroolList;
	}

	public void setLsmwDroolList(List<LsmwDrool> lsmwDroolList) {
		LsmwDroolList = lsmwDroolList;
	}

	
	
	
	
	
	
	

}



