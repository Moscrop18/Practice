package com.act.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

import com.act.poc.model.User;

@Entity
@Table(name = "roles_access")
public class RolesAccess {

	private User user;

	@NotEmpty
	@Email
	private String emailId;

	private Boolean r_admin = Boolean.FALSE;
	private Boolean r_poc = Boolean.FALSE;
	private Boolean r_client = Boolean.FALSE;

	@Email
	private String updatedBy;
	private Date updatedOn;

	@Id
	@Column(name = "EMAIL_ID", nullable = false)
	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	@Column(name = "ROLE_ADMIN")
	public Boolean getR_admin() {
		return r_admin;
	}

	public void setR_admin(Boolean r_admin) {
		this.r_admin = r_admin;
	}

	@Column(name = "ROLE_POC")
	public Boolean getR_poc() {
		return r_poc;
	}

	public void setR_poc(Boolean r_poc) {
		this.r_poc = r_poc;
	}

	@Column(name = "ROLE_CLIENT")
	public Boolean getR_client() {
		return r_client;
	}

	public void setR_client(Boolean r_client) {
		this.r_client = r_client;
	}

	@Column(name = "UPDATED_BY")
	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	@Column(name = "UPDATED_ON", nullable = false)
	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "EMAIL_ID", nullable = false)
	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

}
