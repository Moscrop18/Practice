package com.act.model;




import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.act.utility.HANAUtility;

@Entity
@Table(name="STATUS_MASTER")
public class StatusMaster implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2436757320289783435L;
	
	private int id;
	
	public String code;
	
	private String description;
	
	private String typeOfStatus;
	
	private Integer isClientStatus;
	
	
	@Id
	@GeneratedValue
	@Column(name="ID")
	public int getId() {
		return id;
	}
	public void setId(final int id) {
		this.id = id;
	}
	
	@Column(name="CODE",nullable = false)
	public String getCode() {
		return code;
	}
	public void setCode(final String code) {
		this.code = code;
	}
	
	@Column(name="DESCRIPTION")
	public String getDescription() {
		return description;
	}
	public void setDescription(final String description) {
		this.description = description;
	}
	
	@Column(name="TYPE_OF_STATUS")
	public String getTypeOfStatus() {
		return typeOfStatus;
	}
	public void setTypeOfStatus(final String typeOfStatus) {
		this.typeOfStatus = typeOfStatus;
	}
	
	
	public StatusMaster() {
	}
	
	@Column(name="IS_CLIENT_STATUS")
	public Integer getIsClientStatus() {
		return isClientStatus;
	}
	public void setIsClientStatus(final Integer isClientStatus) {
		this.isClientStatus = isClientStatus;
	}
	
}
