package com.act.common.dao;

import java.util.List;

import com.act.model.Notification;

public interface NotificationDao {
	public List<Notification> getUserNotifications(String user);
	public Boolean markNotificationAsRead(String user, Integer notificationId);
	public Boolean markUserAllNotificationsAsRead(String user);
}
