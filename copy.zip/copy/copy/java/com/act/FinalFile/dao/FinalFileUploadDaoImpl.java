package com.act.FinalFile.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.act.POCUtility.models.InventoryListPOC;
import com.act.POCUtility.models.POC_AffectedByCustomFields;
import com.act.POCUtility.models.POC_AppendStructureAnalysis;
import com.act.POCUtility.models.POC_BWCleanUpUtility;
import com.act.POCUtility.models.POC_BWInventory;
import com.act.POCUtility.models.POC_BWStandardExtract;
import com.act.POCUtility.models.POC_CVITROutput;
import com.act.POCUtility.models.POC_DRS4Simplification1;
import com.act.POCUtility.models.POC_DRS4Simplification2;
import com.act.POCUtility.models.POC_DRS4Simplification3;
import com.act.POCUtility.models.POC_DR_DB_Change;
import com.act.POCUtility.models.POC_DR_ExistingErrors;
import com.act.POCUtility.models.POC_DR_FioriOdata;
import com.act.POCUtility.models.POC_DrillDownReport;
import com.act.POCUtility.models.POC_FioriOutput;
import com.act.POCUtility.models.POC_ImpactedBackgroundJob;
import com.act.POCUtility.models.POC_ImpactedCloneAnalysis;
import com.act.POCUtility.models.POC_ImpactedCloneProgramAnalysis;
import com.act.POCUtility.models.POC_ImpactedCustomTable;
import com.act.POCUtility.models.POC_ImpactedEnhancementBadi;
import com.act.POCUtility.models.POC_ImpactedIdoc;
import com.act.POCUtility.models.POC_ImpactedObjectList;
import com.act.POCUtility.models.POC_ImpactedSAPScript;
import com.act.POCUtility.models.POC_ImpactedSearchHelp;
import com.act.POCUtility.models.POC_ImpactedStandardTransaction;
import com.act.POCUtility.models.POC_ImpactedTables;
import com.act.POCUtility.models.POC_Impacted_Variant;
import com.act.POCUtility.models.POC_InactiveObjects;
import com.act.POCUtility.models.POC_InconsistentFUGR;
import com.act.POCUtility.models.POC_NonUnicodeObjects;
import com.act.POCUtility.models.POC_OS_Migration;
import com.act.POCUtility.models.POC_OS_Migration_FilePath;
import com.act.POCUtility.models.POC_OS_Migration_LogicalCMD;
import com.act.POCUtility.models.POC_OutputManagement;
import com.act.POCUtility.models.POC_S4_SID;
import com.act.POCUtility.models.POC_SecAnalyzerTCDReport;
import com.act.POCUtility.models.POC_Smodilog;
import com.act.POCUtility.models.POC_TestingScope;
import com.act.POCUtility.models.POC_Ui5FinalOutput;
import com.act.POCUtility.models.POC_Ui5HighLevelReport;
import com.act.displaygrid.model.DBConfig;

@Repository
public class FinalFileUploadDaoImpl {

	final static Logger logger = LoggerFactory.getLogger(FinalFileUploadDaoImpl.class);

	public String pocInventoryBatchInsertUpdate(List<InventoryListPOC> pocInventoryList, HttpSession session)
			throws SQLException {

		final String INSERT_SQL = "INSERT INTO S4_Inventory_List "
				+ "(OBJ_TYPE, OBJ_NAME, Used, REQUEST_ID, usageCount, External_Namespace, Ricef_Category, Ricef_Sub_Category, Standard_Modification, Count_Lines, Transport_Request) " + "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (InventoryListPOC inventory : pocInventoryList) {
					stmt.setString(1, inventory.getObjType());
					stmt.setString(2, inventory.getObjName());
					stmt.setString(3, inventory.getUsed());
					stmt.setLong(4, inventory.getRequestId());
					stmt.setString(5, inventory.getUsageCount());
					stmt.setString(6, inventory.getExternalNamespace());
					stmt.setString(7, inventory.getRicefwCategory());
					stmt.setString(8, inventory.getRicefwSubCategory());
					stmt.setString(9, inventory.getStandardMod());
					stmt.setString(10, inventory.getLinesOfCode());
					stmt.setString(11, inventory.getTransReq());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");

					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("POCInventory_List::::::::::IN::::::::::S4_Inventory_List Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	public String pocImpactedObjListBatchInsertUpdate(List<POC_ImpactedObjectList> pocImpactedObjList,
			HttpSession session) throws SQLException {

		final String INSERT_SQL = "INSERT INTO Impact_Obj_List "
				+ "(OBJ_TYPE, OBJ_NAME, Used, Errors_In_Existing_System, DB_Impact, S4_Simplification,REQUEST_ID, "
				+ "OS_Migration, Usage_Count, External_Namespace, RICEF_CATEGORY, RICEF_SUB_CATEGORY, Impacted_Mod) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (POC_ImpactedObjectList impacted : pocImpactedObjList) {
					stmt.setString(1, impacted.getObjectType());
					stmt.setString(2, impacted.getObjectName());
					stmt.setString(3, impacted.getUsed());
					stmt.setString(4, impacted.getErrorsInExistingSystem());
					stmt.setString(5, impacted.getDbImpact());
					stmt.setString(6, impacted.getS4Simplification());
					stmt.setLong(7, impacted.getRequestId());
					stmt.setString(8, impacted.getOsMigration());
					stmt.setString(9, impacted.getUsageCount());
					stmt.setString(10, impacted.getExternalNamespace());
					stmt.setString(11, impacted.getRicefwCategory());
					stmt.setString(12, impacted.getRicefwSubCategory());
					stmt.setString(13, impacted.getImpactMod());
					
					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");

					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("POC_ImpactedObjectList Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;
	}

	public String pocFinalOutputBatchInsertUpdate(List<POC_DR_DB_Change> pocFinalOutputList, HttpSession session)
			throws SQLException {

		final String INSERT_SQL = "INSERT INTO FINAL_OUTPUT"
				+ "(Object_Type, Obj_Name, Sub_Type, ReadProgram, OBJ_PACKAGE, Opertaion, "
				+ "Line_Number, code, Category, Subcategory, IssueSecondSubCat, Info, high_lvl_desc, Levels, "
				+ "TABLES_COLUMN, Joins, Table_Type, Where_Condition, Join_Type, impact, automation_status, "
				+ "COMPLEXITY, operation_code, Used_Unused, COMMENT_C, SKIP, Request_ID, OBJ_NAME_TYPE, SEL_LINE, External_Namespace, RICEF_CATEGORY, Ricef_Sub_Category) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);

			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (POC_DR_DB_Change hpro : pocFinalOutputList) {
					stmt.setString(1, hpro.getObjType());
					stmt.setString(2, hpro.getObjName());
					stmt.setString(3, hpro.getSubObjName());
					stmt.setString(4, hpro.getReadProgram());
					stmt.setString(5, hpro.getPkg());
					stmt.setString(6, hpro.getOperation());
					stmt.setInt(7, hpro.getLineNo());
					stmt.setString(8, hpro.getStatement());
					stmt.setString(9, hpro.getRemediationCategory());
					stmt.setString(10, hpro.getIssueCategory());
					stmt.setString(11, hpro.getIssueSubCategory());
					stmt.setString(12, hpro.getDescOfChange());
					stmt.setString(13, hpro.getSolutionSteps());
					stmt.setInt(14, hpro.getLevelOfNesting());
					stmt.setString(15, hpro.getTables());
					stmt.setString(16, hpro.getJoins());
					stmt.setString(17, hpro.getTableType());
					stmt.setString(18, hpro.getWhereCondition());
					stmt.setString(19, hpro.getJoinType());
					stmt.setString(20, hpro.getImpact());
					stmt.setString(21, hpro.getAutomationStatus());
					stmt.setString(22, hpro.getComplexity());
					stmt.setString(23, hpro.getOperationCode());
					stmt.setString(24, hpro.getUsed());
					stmt.setString(25, hpro.getSkipReason());
					stmt.setString(26, hpro.getSkip());
					stmt.setLong(27, hpro.getRequestId());
					stmt.setString(28, hpro.getObjectNameType());
					stmt.setString(29, hpro.getSelectLine());
					stmt.setString(30, hpro.getExternalNamespace());
					stmt.setString(31, hpro.getRicefwCategory());
					stmt.setString(32, hpro.getRicefwSubCategory());
					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");

					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("POC_DR_DB_Change::::::::Final batch executed successfully");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	public String pocS4Simplification1ListBatchInsertUpdate(List<POC_DRS4Simplification1> pocS4FinalOutputList,
			HttpSession session) throws SQLException {

		final String INSERT_SQL = "INSERT INTO s4_final_output"
				+ "(TYPE, OBJ_NAME, METHOD, READ_PROG, PCKG, OPERATIONS, LINE_NO, STMT, IMPACTED_OBJ_TYPE, "
				+ "IMPACT_REASON, DESC_OF_CHANGE, SAP_NOTES, SOLUTION_STEPS, complexity, ISSUE_CATEGORY, ERROR_CATEGORY, "
				+ "TRIGGER_OBJ, Remediation_Category, SAP_SIMP_LIST, APP_COMPONENT, SAP_SIMPL_CATEGORY, ITEM_AREA, "
				+ "USED, REQUEST_ID, OBJ_NAME_TYPE, SELECT_LINE, Correction_ProgName, Correction_LineNo, External_Namespace, "
				+ "RICEF_CATEGORY, RICEF_SUB_CATEGORY, Impact, Automation_Status, TOOL_Version) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);

			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (POC_DRS4Simplification1 hpro : pocS4FinalOutputList) {
					stmt.setString(1, hpro.getObjType());
					stmt.setString(2, hpro.getObjName());
					stmt.setString(3, hpro.getSubObjName());
					stmt.setString(4, hpro.getReadProgram());
					stmt.setString(5, hpro.getPkg());
					stmt.setString(6, hpro.getOperation());
					stmt.setLong(7, hpro.getLineNo());
					stmt.setString(8, hpro.getStatement());
					stmt.setString(9, hpro.getImpactedObj());
					stmt.setString(10, hpro.getImpactReason());
					stmt.setString(11, hpro.getDescOfChange());
					stmt.setString(12, hpro.getSAPNote());
					stmt.setString(13, hpro.getSolutionStep());
					stmt.setString(14, hpro.getComplexity());
					stmt.setString(15, hpro.getIssueCategory());
					stmt.setString(16, hpro.getIssueSubCategory());
					stmt.setString(17, hpro.getTriggerObject());
					stmt.setString(18, hpro.getRemediationCategory());
					stmt.setString(19, hpro.getSAPSimpliListChapter());
					stmt.setString(20, hpro.getAppComponent());
					stmt.setString(21, hpro.getSAPSimpliCategory());
					stmt.setString(22, hpro.getItemArea());
					stmt.setString(23, hpro.getUsed());
					stmt.setLong(24, hpro.getRequestId());
					stmt.setString(25, hpro.getObjectNameType());
					stmt.setString(26, hpro.getSelLine());
					stmt.setString(27, hpro.getCorProgName());
					stmt.setString(28, hpro.getCorLineNo());
					stmt.setString(29, hpro.getExternalNamespace());
					stmt.setString(30, hpro.getRicefwCategory());
					stmt.setString(31, hpro.getRicefwSubCategory());
					stmt.setString(32, hpro.getImpact());
					stmt.setString(33, hpro.getAutomationStatus());
					stmt.setString(34, hpro.getToolVersion());
					
					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");

					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("POC_DRS4Simplification1::::::::::Final batch executed successfully");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	public String pocAUCTBatchInsertUpdate(List<POC_DR_ExistingErrors> pocAUCTList, HttpSession session)
			throws SQLException {

		final String INSERT_SQL = "INSERT INTO Auct_Final_Output"
				+ "(TYPE, OBJ_NAME, SUB_TYPE, READ_PROG, OBJ_PACKAGE, LINE_NUMBER, INFO, AUTOMATION_STATUS, OPCODE, "
				+ "Used_Unused, REQUEST_ID, OBJ_NAME_TYPE, External_Namespace, RICEF_CATEGORY, RICEF_SUB_CATEGORY, OPCODE) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);

			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (POC_DR_ExistingErrors pocAUCT : pocAUCTList) {
					stmt.setString(1, pocAUCT.getObjType());
					stmt.setString(2, pocAUCT.getObjName());
					stmt.setString(3, pocAUCT.getSubObjName());
					stmt.setString(4, pocAUCT.getReadProgram());
					stmt.setString(5, pocAUCT.getPkg());
					stmt.setLong(6, pocAUCT.getLineNo());
					stmt.setString(7, pocAUCT.getDescOfChange());
					stmt.setString(8, pocAUCT.getAutomationStatus());
					stmt.setString(9, pocAUCT.getOpCode());
					stmt.setString(10, pocAUCT.getUsed());
					stmt.setLong(11, pocAUCT.getRequestId());
					stmt.setString(12, pocAUCT.getObjectNameType());
					stmt.setString(13, pocAUCT.getExternalNamespace());
					stmt.setString(14, pocAUCT.getRicefwCategory());
					stmt.setString(15, pocAUCT.getRicefwSubCategory());
					stmt.setString(16, pocAUCT.getOpCode());
					
					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");

					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("POC_DR_ExistingErrors::::::::::Final batch executed successfully");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	public String pocFioriBatchInsertUpdate(List<POC_DR_FioriOdata> pocFioriOdataList, HttpSession session)
			throws SQLException {

		final String INSERT_SQL = "INSERT INTO Inventory_Standard_Fiori "
				+ "(Object,Obj_Name,AppId,SUBTYPE,AppsTypeCombined,PCDCombined,App_Name,REQUEST_ID) values (?, ?, ?, ?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);

			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (POC_DR_FioriOdata pocFioriOdata : pocFioriOdataList) {
					stmt.setString(1, pocFioriOdata.getObjType());
					stmt.setString(2, pocFioriOdata.getObjName());
					stmt.setString(3, pocFioriOdata.getAppId());
					stmt.setString(4, pocFioriOdata.getSubType());
					stmt.setString(5, pocFioriOdata.getAppType());
					stmt.setString(6, pocFioriOdata.getVersAvailable());
					stmt.setString(7, pocFioriOdata.getAppname());
					stmt.setLong(8, pocFioriOdata.getRequestId());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");

					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("POC_DR_FioriOdata:::::::::::::Final batch executed successfully");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	public String pocOutputMngmtListBatchInsertUpdate(List<POC_OutputManagement> pocOutputMngmtList,
			HttpSession session) throws SQLException {

		final String INSERT_SQL = "INSERT INTO s4_output_management" + "(Type,Obj_Name,REQUEST_ID) values (?,?,?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);

			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (POC_OutputManagement pocOutputMngmt : pocOutputMngmtList) {
					stmt.setString(1, pocOutputMngmt.getObjectType());
					stmt.setString(2, pocOutputMngmt.getObjectName());
					stmt.setLong(3, pocOutputMngmt.getRequestId());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");

					}
				}
				stmt.executeBatch();
				conn.commit();
				logger.info("POC_OutputManagement:::::::::::Final batch executed successfully");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}
		return result;
	}

	public String pocAffectedCustomFieldListBatchInsertUpdate(
			List<POC_AffectedByCustomFields> pocAffectedCustomList, HttpSession session) throws SQLException {

		final String INSERT_SQL = "INSERT INTO s4_affect_custom"
				+ "(Type,Obj_Name,Trigger_Obj,REQUEST_ID, Replaced_By_CDS) values (?,?,?,?,?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);

			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (POC_AffectedByCustomFields pocAffectedCustom : pocAffectedCustomList) {
					stmt.setString(1, pocAffectedCustom.getObjectType());
					stmt.setString(2, pocAffectedCustom.getObjectName());
					stmt.setString(3, pocAffectedCustom.getTriggerObject());
					stmt.setLong(4, pocAffectedCustom.getRequestId());
					stmt.setString(5, pocAffectedCustom.getReplacedByCDS());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");

					}
				}
				stmt.executeBatch();
				conn.commit();
				logger.info("POC_AffectedByCustomFields::::::::::::Final batch executed successfully");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}
		return result;
	}

	public String pocImpactedTablesBatchInsertUpdate(List<POC_ImpactedTables> pocImpactedTablesList,
			HttpSession session) throws SQLException {

		final String INSERT_SQL = "INSERT INTO S4_IMPACTED_TABLES"
				+ "(Object,DESCRIPTION,SOLUTION_STEPS,SAP_NOTES,REQUEST_ID) values (?,?,?,?,?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);

			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (POC_ImpactedTables pocImpactedTables : pocImpactedTablesList) {
					stmt.setString(1, pocImpactedTables.getObject());
					stmt.setString(2, pocImpactedTables.getDescription());
					stmt.setString(3, pocImpactedTables.getSolutionSteps());
					stmt.setString(4, pocImpactedTables.getSapNotes());
					stmt.setLong(5, pocImpactedTables.getRequestId());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");

					}
				}
				stmt.executeBatch();
				conn.commit();
				logger.info("POC_ImpactedTables:::::::::::Final batch executed successfully");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}
		return result;
	}

	public String pocImpactedIDOCBatchInsertUpdate(List<POC_ImpactedIdoc> pocImpactedIDOCList,
			HttpSession session) throws SQLException {

		final String INSERT_SQL = "INSERT INTO S4_IMPACTED_IDOC"
				+ "(IDOC_MSG_TYPE, IDOC_BASIC_TYPE, IDOC_SEGMENT, IMPACTED_OBJECT_TYPE, IMPACTED_OBJECT_NAME, "
				+ "DESCRIPTION, NOTE_NUMBER, SOLUTION, REQUEST_ID, TYPE_OF_IDOC) values (?,?,?,?,?,?,?,?,?,?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);

			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (POC_ImpactedIdoc pocImpactedIDOC : pocImpactedIDOCList) {
					stmt.setString(1, pocImpactedIDOC.getIdocMsgType());
					stmt.setString(2, pocImpactedIDOC.getIdocBasicType());
					stmt.setString(3, pocImpactedIDOC.getIdocSegment());
					stmt.setString(4, pocImpactedIDOC.getImpactedObjectType());
					stmt.setString(5, pocImpactedIDOC.getImpactedObjectName());
					stmt.setString(6, pocImpactedIDOC.getDescription());
					stmt.setString(7, pocImpactedIDOC.getSapNote());
					stmt.setString(8, pocImpactedIDOC.getSolutionStep());
					stmt.setLong(9, pocImpactedIDOC.getRequestId());
					stmt.setString(10, pocImpactedIDOC.getTypeOfIDOC());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");

					}
				}
				stmt.executeBatch();
				conn.commit();
				logger.info("POC_ImpactedIdoc::::::::::Final batch executed successfully");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}
		return result;
	}

	public String pocImpactedStandardTransactionBatchInsertUpdate(
			List<POC_ImpactedStandardTransaction> pocImpactedStandardTransactionList, HttpSession session)
			throws SQLException {

		final String INSERT_SQL = "INSERT INTO S4_IMPACTED_TRANSACTION"
				+ "(IMPACTED_TRANSACTION,DESCRIPTION,SAP_NOTES,SOLUTION_STEPS,REQUEST_ID) values (?,?,?,?,?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);

			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (POC_ImpactedStandardTransaction pocImpactedStandardTransaction : pocImpactedStandardTransactionList) {
					stmt.setString(1, pocImpactedStandardTransaction.getImpactedTransaction());
					stmt.setString(2, pocImpactedStandardTransaction.getDescription());
					stmt.setString(3, pocImpactedStandardTransaction.getNoteNo());
					stmt.setString(4, pocImpactedStandardTransaction.getSolutionStep());
					stmt.setLong(5, pocImpactedStandardTransaction.getRequestId());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");

					}
				}
				stmt.executeBatch();
				conn.commit();
				logger.info("POC_ImpactedStandardTransaction::::::::::Final batch executed successfully");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}
		return result;
	}

	public String pocImpactedSearchHelpBatchInsertUpdate(List<POC_ImpactedSearchHelp> pocImpactedSearchHelpList,
			HttpSession session) throws SQLException {

		final String INSERT_SQL = "INSERT INTO S4_Impacted_Search (OBJ_TYPE, CUSTOM_TABLE, IMPACTED_SEARCH_HELP, REQUEST_ID, EXTERNAL_NAMESPACE) values (?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);

			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (POC_ImpactedSearchHelp s4Impacted : pocImpactedSearchHelpList) {
					stmt.setString(1, s4Impacted.getObjectType());
					stmt.setString(2, s4Impacted.getCustomTable());
					stmt.setString(3, s4Impacted.getImpactedSearchHelp());
					stmt.setLong(4, s4Impacted.getRequestId());
					stmt.setString(5, s4Impacted.getExternalNamespace());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");

					}
				}
				stmt.executeBatch();
				conn.commit();
				logger.info("POC_ImpactedSearchHelp::::::::::Final batch executed successfully");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}
		return result;
	}

	public String pocAppendStructureBatchInsertUpdate(List<POC_AppendStructureAnalysis> pocAppendStructureList,
			HttpSession session) throws SQLException {

		final String INSERT_SQL = "INSERT INTO S4_Append_Structure "
				+ "(FIELD_NAME, NAME_OF_INCLUDE, REQUEST_ID, TABLE_NAME) values (?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);

			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (POC_AppendStructureAnalysis s4Append : pocAppendStructureList) {
					stmt.setString(1, s4Append.getFieldName());
					stmt.setString(2, s4Append.getNameOfInclude());
					stmt.setLong(3, s4Append.getRequestId());
					stmt.setString(4, s4Append.getTableName());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");

					}
				}
				stmt.executeBatch();
				conn.commit();
				logger.info("POC_AppendStructureAnalysis::::::::::Final batch executed successfully");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}
		return result;
	}

	public String pocCloneProgBatchInsertUpdate(List<POC_ImpactedCloneProgramAnalysis> pocCloneProgList,
			HttpSession session) throws SQLException {

		final String INSERT_SQL = "INSERT INTO S4_Clone_Prog_Analysis "
				+ "(Impacted_Prog, Clone_prog, Description, Solution_Step, Related_Notes, REQUEST_ID) values (?, ?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (POC_ImpactedCloneProgramAnalysis cloneProg : pocCloneProgList) {
					stmt.setString(1, cloneProg.getImpactedProgram());
					stmt.setString(2, cloneProg.getCloneProgram());
					stmt.setString(3, cloneProg.getDescriptionOfChange());
					stmt.setString(4, cloneProg.getSolutionStep());
					stmt.setString(5, cloneProg.getRelatedNote());
					stmt.setLong(6, cloneProg.getRequestId());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");

					}
				}
				stmt.executeBatch();
				conn.commit();
				logger.info("POC_ImpactedCloneProgramAnalysis::::::::::Final batch executed successfully");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}
		return result;
	}

	public String pocEnhancementBADIBatchInsertUpdate(List<POC_ImpactedEnhancementBadi> pocEnhancementList,
			HttpSession session) throws SQLException {

		final String INSERT_SQL = "INSERT INTO S4_Enhancement "
				+ "(TYPE, OBJECT_NAME, ENHANCEMENT_NAME, IMPLEMENTATION_NAME, REQUEST_ID) values (?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (POC_ImpactedEnhancementBadi s4Enhancement : pocEnhancementList) {
					stmt.setString(1, s4Enhancement.getEnhancementType());
					stmt.setString(2, s4Enhancement.getClassName());
					stmt.setString(3, s4Enhancement.getEnhancemnetName());
					stmt.setString(4, s4Enhancement.getImplementationName());
					stmt.setLong(5, s4Enhancement.getRequestId());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");

					}
				}
				stmt.executeBatch();
				conn.commit();
				logger.info("POC_ImpactedEnhancementBadi:::::::::::Final batch executed successfully");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}
		return result;
	}

	public String pocDRS4Simplification2BatchInsertUpdate(List<POC_DRS4Simplification2> pocS4FinalOutput2List,
			HttpSession session) throws SQLException {

		final String INSERT_SQL = "INSERT INTO s4_Detail_Report "
				+ "(OBJ_TYPE, OBJ_NAME, SUB_OBJ, USED, METHOD, PCKG, IMPACTED_OBJ_TYPE, LINE_NO, STMT, OPERATIONS, IMPACT_REASON, AFFECT_OBJ_DESC, DESC_OF_CHANGE, SAP_NOTES, SOLUTION_STEPS,"
				+ " COMPLEXITY, ISSUE_CATEGORY, ERROR_CATEGORY, TRIGGER_OBJ, Remediation_Category, SAP_SIMP_LIST, APP_COMPONENT, SAP_SIMPL_CATEGORY, ITEM_AREA, REQUEST_ID) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (POC_DRS4Simplification2 pocS4FinalOutput2 : pocS4FinalOutput2List) {
					stmt.setString(1, pocS4FinalOutput2.getType());
					stmt.setString(2, pocS4FinalOutput2.getObject());
					stmt.setString(3, pocS4FinalOutput2.getSubObject());
					stmt.setString(4, pocS4FinalOutput2.getUsed());
					stmt.setString(5, pocS4FinalOutput2.getMethod());
					stmt.setString(6, pocS4FinalOutput2.getPkg());
					stmt.setString(7, pocS4FinalOutput2.getImpactedObjType());
					stmt.setLong(8, pocS4FinalOutput2.getLineNumber());
					stmt.setString(9, pocS4FinalOutput2.getStatement());
					stmt.setString(10, pocS4FinalOutput2.getOperations());
					stmt.setString(11, pocS4FinalOutput2.getImpactReason());
					stmt.setString(12, pocS4FinalOutput2.getAffectedObjectDescription());
					stmt.setString(13, pocS4FinalOutput2.getDescOfChange());
					stmt.setString(14, pocS4FinalOutput2.getSapNotes());
					stmt.setString(15, pocS4FinalOutput2.getSolutionSteps());
					stmt.setString(16, pocS4FinalOutput2.getComplexity());
					stmt.setString(17, pocS4FinalOutput2.getIssueCategory());
					stmt.setString(18, pocS4FinalOutput2.getErrorCategory());
					stmt.setString(19, pocS4FinalOutput2.getTriggerObject());
					stmt.setString(20, pocS4FinalOutput2.getRemediCategory());
					stmt.setString(21, pocS4FinalOutput2.getSapSimpliListChapter());
					stmt.setString(22, pocS4FinalOutput2.getAppComponent());
					stmt.setString(23, pocS4FinalOutput2.getSapSimpliCategory());
					stmt.setString(24, pocS4FinalOutput2.getItemArea());
					stmt.setLong(25, pocS4FinalOutput2.getRequestId());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");

					}
				}
				stmt.executeBatch();
				conn.commit();
				logger.info("POC_DRS4Simplification2::::::::::Final batch executed successfully");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}
		return result;
	}

	public String pocDRS4Simplification3BatchInsertUpdate(List<POC_DRS4Simplification3> pocS4FinalOutput3List,
			HttpSession session) throws SQLException {

		final String INSERT_SQL = "INSERT INTO s4_Detail_Report_Remedi "
				+ "(OBJ_TYPE, OBJ_NAME, SUB_OBJ, USED, METHOD, PCKG, IMPACTED_OBJ_TYPE, LINE_NO, STMT, OPERATIONS, IMPACT_REASON, AFFECT_OBJ_DESC, DESC_OF_CHANGE, SAP_NOTES, SOLUTION_STEPS,"
				+ " COMPLEXITY, ISSUE_CATEGORY, ERROR_CATEGORY, TRIGGER_OBJ, Remediation_Category, SAP_SIMP_LIST, APP_COMPONENT, SAP_SIMPL_CATEGORY, ITEM_AREA, REQUEST_ID) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (POC_DRS4Simplification3 pocS4FinalOutput3 : pocS4FinalOutput3List) {
					stmt.setString(1, pocS4FinalOutput3.getType());
					stmt.setString(2, pocS4FinalOutput3.getObject());
					stmt.setString(3, pocS4FinalOutput3.getSubObject());
					stmt.setString(4, pocS4FinalOutput3.getUsed());
					stmt.setString(5, pocS4FinalOutput3.getMethod());
					stmt.setString(6, pocS4FinalOutput3.getPkg());
					stmt.setString(7, pocS4FinalOutput3.getImpactedObjectType());
					stmt.setLong(8, pocS4FinalOutput3.getLineNumber());
					stmt.setString(9, pocS4FinalOutput3.getStatement());
					stmt.setString(10, pocS4FinalOutput3.getOperations());
					stmt.setString(11, pocS4FinalOutput3.getImpactReason());
					stmt.setString(12, pocS4FinalOutput3.getAffectedObjectDescription());
					stmt.setString(13, pocS4FinalOutput3.getDescriptionOfChange());
					stmt.setString(14, pocS4FinalOutput3.getSapNotes());
					stmt.setString(15, pocS4FinalOutput3.getSolutionSteps());
					stmt.setString(16, pocS4FinalOutput3.getComplexity());
					stmt.setString(17, pocS4FinalOutput3.getIssueCategory());
					stmt.setString(18, pocS4FinalOutput3.getErrorCategory());
					stmt.setString(19, pocS4FinalOutput3.getTriggerObject());
					stmt.setString(20, pocS4FinalOutput3.getRemediationCategory());
					stmt.setString(21, pocS4FinalOutput3.getSapSimplificationListChapter());
					stmt.setString(22, pocS4FinalOutput3.getApplicationComponent());
					stmt.setString(23, pocS4FinalOutput3.getSapSimplCategory());
					stmt.setString(24, pocS4FinalOutput3.getItemArea());
					stmt.setLong(25, pocS4FinalOutput3.getRequestId());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");

					}
				}
				stmt.executeBatch();
				conn.commit();
				logger.info("POC_DRS4Simplification3:::::::::::::Final batch executed successfully");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}
		return result;
	}

	public String pocUI5FinalOutputBatchInsertUpdate(List<POC_Ui5FinalOutput> pocUI5FinalOutputList,
			HttpSession session) throws SQLException {

		final String INSERT_SQL = "INSERT INTO UI5_FINAL_OUTPUT "
				+ "(UI_Element, Attribute, Type, Description, Version, LineNumber, ProjectName, FileName, Status, Message, REQUEST_ID) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (POC_Ui5FinalOutput pocUI5FinalOutput : pocUI5FinalOutputList) {
					stmt.setString(1, pocUI5FinalOutput.getUiElement());
					stmt.setString(2, pocUI5FinalOutput.getAttribute());
					stmt.setString(3, pocUI5FinalOutput.getType());
					stmt.setString(4, pocUI5FinalOutput.getDescription());
					stmt.setString(5, pocUI5FinalOutput.getVersion());
					stmt.setString(6, pocUI5FinalOutput.getLineNumber());
					stmt.setString(7, pocUI5FinalOutput.getProjectName());
					stmt.setString(8, pocUI5FinalOutput.getFileName());
					stmt.setString(9, pocUI5FinalOutput.getStatus());
					stmt.setString(10, pocUI5FinalOutput.getMessage());
					stmt.setLong(11, pocUI5FinalOutput.getRequestId());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");

					}
				}
				stmt.executeBatch();
				conn.commit();
				logger.info("POC_Ui5FinalOutput:::::::::::Final batch executed successfully");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}
		return result;
	}

	public String pocUi5HighLevelReportBatchInsertUpdate(List<POC_Ui5HighLevelReport> pocUi5HighLevelReportList,
			HttpSession session) throws SQLException {

		final String INSERT_SQL = "INSERT INTO UI5_REPORT "
				+ "(ProjectName, Total_API_Counts, Depricated_API_Counts, NonValid_API_Counts, Recommented_Changes_API_Counts, Final_Message, REQUEST_ID) values (?, ?, ?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (POC_Ui5HighLevelReport pocUi5HighLevelReport : pocUi5HighLevelReportList) {
					stmt.setString(1, pocUi5HighLevelReport.getProjectName());
					stmt.setString(2, pocUi5HighLevelReport.getTotalApiCounts());
					stmt.setString(3, pocUi5HighLevelReport.getDepricatedApiCounts());
					stmt.setString(4, pocUi5HighLevelReport.getNonValidApiCounts());
					stmt.setString(5, pocUi5HighLevelReport.getRecommendedChangesApiCounts());
					stmt.setString(6, pocUi5HighLevelReport.getFinalMessage());
					stmt.setLong(7, pocUi5HighLevelReport.getRequestId());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");

					}
				}
				stmt.executeBatch();
				conn.commit();
				logger.info("POC_Ui5HighLevelReport::::::::::Final batch executed successfully");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}
		return result;
	}

	public String pocTestingScopeBatchInsertUpdate(List<POC_TestingScope> pocTestingScopeList,
			HttpSession session) throws SQLException {

		final String INSERT_SQL = "INSERT INTO FinalOutputTestingscope "
				+ "(requestid, objecttype, objectname, process, objectTypeObjectName, applicationComponent, opercd, appCompDesc, transactions, role) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (POC_TestingScope pocTestingScope : pocTestingScopeList) {
					stmt.setLong(1, pocTestingScope.getRequestId());
					stmt.setString(2, pocTestingScope.getObject());
					stmt.setString(3, pocTestingScope.getObjName());
					stmt.setString(4, pocTestingScope.getProcess());
					stmt.setString(5, pocTestingScope.getObject().concat(pocTestingScope.getObjName()));
					stmt.setString(6, pocTestingScope.getApplicationComponent());
					stmt.setString(7, pocTestingScope.getOpercd());
					stmt.setString(8, pocTestingScope.getAppCompDesc());
					stmt.setString(9, pocTestingScope.getTransactions());
					stmt.setString(10, pocTestingScope.getRole());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}
				stmt.executeBatch();
				conn.commit();

				logger.info("POC_TestingScope::::::::::::Final batch executed successfully");
			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}
		return result;
	}

	public String pocImpactedBackgroundJobBatchInsertUpdate(
			List<POC_ImpactedBackgroundJob> pocImpactedBackgroundJobList, HttpSession session) throws SQLException {

		final String INSERT_SQL = "INSERT INTO Impacted_Background_Job "
				+ "(OBJECT,OBJECT_NAME,SUB_TYPE,READ_PROG,OBJ_PACKAGE,ACT_STATUS,Request_Id,External_Namespace) values (?, ?, ?, ?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (POC_ImpactedBackgroundJob pocImpactedBackgroundJob : pocImpactedBackgroundJobList) {
					stmt.setString(1, pocImpactedBackgroundJob.getObject());
					stmt.setString(2, pocImpactedBackgroundJob.getBackgroundJobName());
					stmt.setString(3, pocImpactedBackgroundJob.getProgramName());
					stmt.setString(4, pocImpactedBackgroundJob.getVariant());
					stmt.setString(5, pocImpactedBackgroundJob.getTcode());
					stmt.setString(6, pocImpactedBackgroundJob.getRun());
					stmt.setLong(7, pocImpactedBackgroundJob.getRequestId());
					stmt.setString(8, pocImpactedBackgroundJob.getExternalNamespace());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");

					}
				}
				stmt.executeBatch();
				conn.commit();
				logger.info("POC_ImpactedBackgroundJob::::::::::::Final batch executed successfully");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}
		return result;
	}

	public String pocSmodilogListBatchInsertUpdate(List<POC_Smodilog> pocSmodilogList, HttpSession session)
			throws SQLException {

		final String INSERT_SQL = "INSERT INTO smodilogfunction "
				+ "(OBJ_TYPE, OBJ_NAME, SUB_TYPE, SUB_NAME, INT_TYPE, INT_NAME, MOD_USER, "
				+ "MOD_DATE, MOD_TIME, TRKORR, REQUEST_ID, Obj_Name_Type) " 
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (POC_Smodilog pocSmodilog : pocSmodilogList) {
					stmt.setString(1, pocSmodilog.getObjType());
					stmt.setString(2, pocSmodilog.getObjName());
					stmt.setString(3, pocSmodilog.getSubType());
					stmt.setString(4, pocSmodilog.getSubName());
					stmt.setString(5, pocSmodilog.getIntType());
					stmt.setString(6, pocSmodilog.getIntName());
					stmt.setString(7, pocSmodilog.getModUser());
					stmt.setString(8, pocSmodilog.getModDate());
					stmt.setString(9, pocSmodilog.getModTime());
					stmt.setString(10, pocSmodilog.getTrkorr());
					stmt.setLong(11, pocSmodilog.getRequestId());
					stmt.setString(12, pocSmodilog.getObjType().trim().concat(pocSmodilog.getObjName().trim()));

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");

					}
				}
				stmt.executeBatch();
				conn.commit();
				logger.info("POC_Smodilog:::::::::::Final batch executed successfully");
			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}
		return result;
	}

	public String pocImpactedSAPScriptListBatchInsertUpdate(List<POC_ImpactedSAPScript> pocImpactedSAPScriptList,
			HttpSession session) throws SQLException {
		final String INSERT_SQL = "INSERT INTO impacted_scripts_download"
				+ "(Impacted_SAP_Scripts, DB_Impact, Existing_Errors, PROGRAM, OBJ_NAME_TYPE, OBJ_TYPE, OPERCD, REMEDIATION_CATEGORY, REQUEST_ID, S4_Simplification, EXTERNAL_NAMESPACE)"
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (POC_ImpactedSAPScript pocImpactedSAPScript : pocImpactedSAPScriptList) {
					stmt.setString(1, pocImpactedSAPScript.getImpactedSapScript());
					stmt.setString(2, pocImpactedSAPScript.getDbImpact());
					stmt.setString(3, pocImpactedSAPScript.getExistingError());
					stmt.setString(4, pocImpactedSAPScript.getProgram());
					stmt.setString(5, pocImpactedSAPScript.getObjNameType());
					stmt.setString(6, pocImpactedSAPScript.getObjType());
					stmt.setString(7, pocImpactedSAPScript.getOpCode());
					stmt.setString(8, pocImpactedSAPScript.getRemediationCategory());
					stmt.setLong(9, pocImpactedSAPScript.getRequestId());
					stmt.setString(10, pocImpactedSAPScript.getS4Simplification());
					stmt.setString(11, pocImpactedSAPScript.getExternalNamespace());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");

					}
				}
				stmt.executeBatch();
				conn.commit();
				logger.info("POC_ImpactedSAPScript::::::::::::Final batch executed successfully");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}
		return result;
	}

	public String pocImpactedCloneAnalysisListBatchInsertUpdate(
			List<POC_ImpactedCloneAnalysis> pocImpactedCloneList, HttpSession session) throws SQLException {
		final String INSERT_SQL = "INSERT INTO IMPACTED_CLONE_ANALYSIS "
				+ "(APPLICATION_COMPONENT, CREATION_DATE, INTERFACE, INTERFACE_OBJECT_TYPE, NAMESPACE, OBJECT_NAME, PACKAGE, OBJECT_TYPE,  REFERENCE, REFERENCE_PERCENT, OBJ_TYPE_NAME, INTERFACE_CONCATENATED, YEAR, USED, IMPACTED_DUE_TO_DB_CHANGE, IMPACTED_DUE_TO_SIMPLIFICATION, IMPACTED_DUE_TO_EXISTING_ERRORS, IMPACTED_DUE_TO_OS_MIGRATION, REQUEST_ID, EXTERNAL_NAMESPACE) values ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (POC_ImpactedCloneAnalysis impactedClone : pocImpactedCloneList) {
					stmt.setString(1, impactedClone.getAppComponent());
					stmt.setString(2, impactedClone.getCreationDate());
					stmt.setString(3, impactedClone.getInterfaceObj());
					stmt.setString(4, impactedClone.getInterfaceObjType());
					stmt.setString(5, impactedClone.getNamespace());
					stmt.setString(6, impactedClone.getObjName());
					stmt.setString(7, impactedClone.getObjPackage());
					stmt.setString(8, impactedClone.getObjType());
					stmt.setString(9, impactedClone.getReference());
					stmt.setString(10, impactedClone.getReferencePercent());
					stmt.setString(11, impactedClone.getObjTypeName());
					stmt.setString(12, impactedClone.getInterfaceConcat());
					stmt.setString(13, impactedClone.getYear());
					stmt.setString(14, impactedClone.getUsed());
					stmt.setString(15, impactedClone.getImpactedDB());
					stmt.setString(16, impactedClone.getImpactedSimpl());
					stmt.setString(17, impactedClone.getImpactedExistingError());
					stmt.setString(18, impactedClone.getImpactedOSMigration());
					stmt.setLong(19, impactedClone.getRequestId());
					stmt.setString(20, impactedClone.getExternalNamespace());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("IMPACTED_CLONE_ANALYSIS Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;
	}

	public String pocInconsistentFUGR(List<POC_InconsistentFUGR> inconsistentFUGRList, HttpSession session)
			throws SQLException {
		final String INSERT_SQL = "INSERT INTO Inconsitent_FUGR "
				+ "(request_id, object_type, fugr_name, master_program, External_Namespace) " + "values (?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {
			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;
				for (POC_InconsistentFUGR inconsistentFUGR : inconsistentFUGRList) {
					stmt.setLong(1, inconsistentFUGR.getRequestId());
					stmt.setString(2, inconsistentFUGR.getObjectType());
					stmt.setString(3, inconsistentFUGR.getFugrName());
					stmt.setString(4, inconsistentFUGR.getMasterProgram());
					stmt.setString(5, inconsistentFUGR.getExternalNamespace());
					

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 1000 records
					if (counter % 1000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();

				logger.info("Inconsistent FUGR Data INSERTED SUCCESSFULLY");
			} catch (Exception e) {
				result = "FAILURE in inserting data into Inconsistent FUGR DB";
				logger.error(result + " --- " + e.getMessage());
			}

		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(result + " --- " + e.getMessage());
		} finally {
			stmt.close();
			conn.close();
		}

		return result;
	}

	public String pocS4SIDInsert(List<POC_S4_SID> s4SIDList, HttpSession session) throws SQLException {
		final String INSERT_SQL = "INSERT INTO S4_SID "
				+ "(REQUEST_ID, OBJ_NAME, SUB_OBJ_TYPE, PCKG, USED, TYPE, LINE_NO, STMT, OPERATIONS, IMPACT_REASON, DESC_OF_CHANGE"
				+ ", SOLUTION_STEPS, Complexity, ISSUE_CATEGORY, IDENTIFIER, Total_Scanned_Line, OBJ_NAME_TYPE, READ_PROG"
				+ ", Automation_Status, EXTERNAL_NAMESPACE) " + "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {
			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;
				for (POC_S4_SID s4SID : s4SIDList) {
					stmt.setLong(1, s4SID.getRequestID());
					stmt.setString(2, s4SID.getObjName());
					stmt.setString(3, s4SID.getSubObjType());
					stmt.setString(4, s4SID.getPckg());
					stmt.setString(5, s4SID.getUsed());
					stmt.setString(6, s4SID.getType());
					stmt.setInt(7, s4SID.getLineNo());
					stmt.setString(8, s4SID.getStmt());
					stmt.setString(9, s4SID.getOperations());
					stmt.setString(10, s4SID.getImpactReason());
					stmt.setString(11, s4SID.getDescOfChange());
					stmt.setString(12, s4SID.getSolutionSteps());
					stmt.setString(13, s4SID.getComplexity());
					stmt.setString(14, s4SID.getIssueCategory());
					stmt.setString(15, s4SID.getIdentifier());
					stmt.setInt(16, s4SID.getTotalScannedLine());
					stmt.setString(17, s4SID.getObjNameType());
					stmt.setString(18, s4SID.getReadProgram());
					stmt.setString(19, s4SID.getAutomationStatus());
					stmt.setString(20, s4SID.getExternalNamespace());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 1000 records
					if (counter % 1000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();

				logger.info("S4 SID Data INSERTED SUCCESSFULLY");
			} catch (Exception e) {
				result = "FAILURE in inserting data into S4 SID DB";
				logger.error(result + " --- " + e.getMessage());
			}

		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(result + " --- " + e.getMessage());
		} finally {
			stmt.close();
			conn.close();
		}

		return result;
	}

	public String pocImpactedVariantInsert(List<POC_Impacted_Variant> impactedVariantList, HttpSession session)
			throws SQLException {
		final String INSERT_SQL = "INSERT INTO Impacted_Variant "
				+ "(Request_ID, Report_Name, Variant_Name, Selection_Screen_Field_Name, Kind, Sign, Low, High, Variant_Option, User_Name, Variant_Type"
				+ ", Comments, Variant_Operation, EXTERNAL_NAMESPACE) " + "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {
			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;
				for (POC_Impacted_Variant impactedVariant : impactedVariantList) {
					
					stmt.setLong(1, impactedVariant.getRequestID());
					stmt.setString(2, impactedVariant.getReportName());
					stmt.setString(3, impactedVariant.getVariantName());
					stmt.setString(4, impactedVariant.getSelScreenFieldName());
					stmt.setString(5, impactedVariant.getKind());
					stmt.setString(6, impactedVariant.getSign());
					stmt.setString(7, impactedVariant.getLow());
					stmt.setString(8, impactedVariant.getHigh());
					stmt.setString(9, impactedVariant.getVariantOption());
					stmt.setString(10, impactedVariant.getUserName());
					stmt.setString(11, impactedVariant.getVariantType());
					stmt.setString(12, impactedVariant.getComments());
					stmt.setString(13, impactedVariant.getVariantOperation());
					stmt.setString(14, impactedVariant.getExternalNamespace());


					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 1000 records
					if (counter % 1000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();

				logger.info("Impacted Variant Data INSERTED SUCCESSFULLY");
			} catch (Exception e) {
				result = "FAILURE in inserting data into Impacted Variant DB";
				logger.error(result + " --- " + e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(result + " --- " + e.getMessage());
		} finally {
			stmt.close();
			conn.close();
		}

		return result;
	}

	public String pocOSMigrationBatchInsertUpdate(List<POC_OS_Migration> pocOSMigrationList, HttpSession session)
			throws SQLException {

		final String INSERT_SQL = "INSERT INTO OSMIGRATION_FINAL "
				+ "(REQUEST_ID, OBJ_TYPE, OBJ_NAME, SUB_TYPE, READ_PROGRAM, OBJ_PACKAGE, OPERCD, LINE_NO, STATEMENT, INFO,"
				+ " REM_CATEGORY, ISSUE_CATEGORY, ISSUE_SUBCATEGORY, HIGH_LVL_DESC, IMPACT, "
				+ "AUTOMATION_STATUS, COMPLEXITY, USED, OBJ_TYPE_NAME, EXTERNAL_NAMESPACE, RICEF_CATEGORY, RICEF_SUB_CATEGORY) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {
			conn = DBConfig.getJDBCConnection(session);

			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (POC_OS_Migration osMigration : pocOSMigrationList) {
					stmt.setLong(1, osMigration.getRequestID());
					stmt.setString(2, osMigration.getObjType());
					stmt.setString(3, osMigration.getObjName());
					stmt.setString(4, osMigration.getSubType());
					stmt.setString(5, osMigration.getReadProgram());
					stmt.setString(6, osMigration.getObjPackage());
					stmt.setString(7, osMigration.getOperationCode());
					stmt.setLong(8, osMigration.getLineNo());
					stmt.setString(9, osMigration.getStatement());
					stmt.setString(10, osMigration.getInfo());
					stmt.setString(11, osMigration.getRemCategory());
					stmt.setString(12, osMigration.getIssueCategory());
					stmt.setString(13, osMigration.getIssueSubcategory());
					stmt.setString(14, osMigration.getHighLvlDesc());
					stmt.setString(15, osMigration.getImpact());
					stmt.setString(16, osMigration.getAutomationStatus());
					stmt.setString(17, osMigration.getComplexity());
					stmt.setString(18, osMigration.getUsed());
					stmt.setString(19, osMigration.getObjType().trim().concat(osMigration.getObjName().trim()));
					stmt.setString(20, osMigration.getExternalNamespace());
					stmt.setString(21, osMigration.getRicefwCategory());
					stmt.setString(22, osMigration.getRicefwSubCategory());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");

					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("POC_OS_Migration :::::::: Final batch executed successfully");
			} catch (Exception e) {
				result = "FAILURE in Insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());
		} finally {
			stmt.close();
			conn.close();
		}

		return result;
	}
	public String pocOSMigrationLogCMDBatchInsertUpdate(List<POC_OS_Migration_LogicalCMD> pocOSMigrationList, HttpSession session)
			throws SQLException {

		final String INSERT_SQL_FinalCMD = "INSERT INTO OSMIGRATION_FINAL_LOGICAL_CMD_INTERMEDIATE "
				+ "(REQUEST_ID, READ_PROGRAM, STATEMENT, INFO, REM_CATEGORY, ISSUE_CATEGORY, ISSUE_SUBCATEGORY, HIGH_LVL_DESC, IMPACT, " 
				+ "AUTOMATION_STATUS, COMPLEXITY) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmtCMD = null;
		try {
			conn = DBConfig.getJDBCConnection(session);

			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmtCMD = conn.prepareStatement(INSERT_SQL_FinalCMD);
				int batch = 1;

				for (POC_OS_Migration_LogicalCMD osMigration : pocOSMigrationList) {
					// Opcode 205 OS Migration CMD Logic
					stmtCMD.setLong(1, osMigration.getRequestID());
					stmtCMD.setString(2, osMigration.getReadProgram());
					stmtCMD.setString(3, osMigration.getStatement());
					stmtCMD.setString(4, osMigration.getInfo());
					stmtCMD.setString(5, osMigration.getRemCategory());
					stmtCMD.setString(6, osMigration.getIssueCategory());
					stmtCMD.setString(7, osMigration.getIssueSubcategory());
					stmtCMD.setString(8, osMigration.getHighLvlDesc());
					stmtCMD.setString(9, osMigration.getImpact());
					stmtCMD.setString(10, osMigration.getAutomationStatus());
					stmtCMD.setString(11, osMigration.getComplexity());

					stmtCMD.addBatch();
					counter++;
					if (counter % 10000 == 0) {
						counter = 0;
						stmtCMD.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed Successfully !!!");
					}
				}

				stmtCMD.executeBatch();
				conn.commit();
				logger.info("POC_OS_Migration for LOGICAL CMD:::::::: Final batch executed successfully");
			} catch (Exception e) {
				result = "FAILURE in Insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());
		} finally {
			stmtCMD.close();
			conn.close();
		}

		return result;
	}
	public String pocOSMigrationFilePathBatchInsertUpdate(List<POC_OS_Migration_FilePath> pocOSMigrationList, HttpSession session)
			throws SQLException {

		final String INSERT_SQL_FilePath = "INSERT INTO OSMIGRATION_FINAL_FILE_PATH_INTERMEDIATE "
				+ "(REQUEST_ID, OBJ_NAME, SUB_TYPE, STATEMENT, INFO, SKIP, SKIP_REASON, REM_CATEGORY, HIGH_LVL_DESC, IMPACT)"
				+ " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmtPath = null;
		try {
			conn = DBConfig.getJDBCConnection(session);

			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmtPath = conn.prepareStatement(INSERT_SQL_FilePath);
				int batch = 1;

				for (POC_OS_Migration_FilePath osMigration : pocOSMigrationList) {
					// Opcode 204 OS Migration File Path
					stmtPath.setLong(1, osMigration.getRequestID());
					stmtPath.setString(2, osMigration.getObjName());
					stmtPath.setString(3, osMigration.getSubType());
					stmtPath.setString(4, osMigration.getStatement());
					stmtPath.setString(5, osMigration.getInfo());
					stmtPath.setString(6, osMigration.getSkip());
					stmtPath.setString(7, osMigration.getSkipReason());
					stmtPath.setString(8, osMigration.getRemCategory());
					stmtPath.setString(9, osMigration.getHighLvlDesc());
					stmtPath.setString(10, osMigration.getImpact());

		
					stmtPath.addBatch();
					counter++;
					if (counter % 10000 == 0) {
						counter = 0;
						stmtPath.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + "  executed Successfully !!!");
					}
				}

				stmtPath.executeBatch();
				conn.commit();
				logger.info("POC_OS_Migration File Path :::::::: Final batch executed successfully");
			} catch (Exception e) {
				result = "FAILURE in Insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());
		} finally {
			stmtPath.close();
			conn.close();
		}

		return result;
	}

	public String pocNonUnicodeObjectsInsert(List<POC_NonUnicodeObjects> nonUnicodeList, HttpSession session)
			throws SQLException {
		final String INSERT_SQL = "INSERT INTO UNICODE_Intermediate "
				+ "(Request_Id, Program, Include, Roww, Error_Code, Message, Pack, "
				+ "Used, Application_Component, Object_Type) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {
			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;
				for (POC_NonUnicodeObjects nonUnicode : nonUnicodeList) {
					stmt.setLong(1, nonUnicode.getRequestID());
					stmt.setString(2, nonUnicode.getProg());
					stmt.setString(3, nonUnicode.getInclude());
					stmt.setString(4, nonUnicode.getRoww());
					stmt.setString(5, nonUnicode.getErrCode());
					stmt.setString(6, nonUnicode.getMsg());
					stmt.setString(7, nonUnicode.getPkg());
					stmt.setString(8, nonUnicode.getUsed());
					stmt.setString(9, nonUnicode.getAppComp());
					stmt.setString(10, nonUnicode.getObjType());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 1000 records
					if (counter % 1000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();

				logger.info("Non Unicode Data INSERTED SUCCESSFULLY");
			} catch (Exception e) {
				result = "FAILURE in inserting data into Non Unicode DB";
				logger.error(result + " --- " + e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(result + " --- " + e.getMessage());
		} finally {
			stmt.close();
			conn.close();
		}

		return result;
	}

	public String pocCVITRBatchInsertUpdate(List<POC_CVITROutput> cvitrList, HttpSession session) throws SQLException {

		final String INSERT_SQL = "INSERT INTO s4_cvitr "
				+ "(IDENTIFIER, SELECT_LINE, COMMENT_C, COMMENTS, REQUEST_ID, NEW_LINE, VENDOR_EXTERNAL, CUSTOMER_EXTERNAL) " + "values (?, ?, ?, ?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (POC_CVITROutput cvitr : cvitrList) {
					stmt.setString(1, cvitr.getCustomerNr());
					stmt.setString(2, cvitr.getSubIntervalFrom());
					stmt.setString(3, cvitr.getSubIntervalTo());
					stmt.setString(4, cvitr.getVendorNr());
					stmt.setLong(5, cvitr.getRequestId());
					stmt.setString(6, "");
					stmt.setString(7, cvitr.getVendorExt());
					stmt.setString(8, cvitr.getCustomerExt());


					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");

					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("POC_CVITROutput::::::::::IN::::::::::CVITR Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	public String pocBWInventoryBatchInsertUpdate(List<POC_BWInventory> bwInventoryList, HttpSession session)
			throws SQLException {

		final String INSERT_SQL = "INSERT INTO bw_inventory_list "
				+ "(Obj_Type, Obj_Name, REQUEST_ID) " + "values (?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (POC_BWInventory bwInventory : bwInventoryList) {
					stmt.setString(1, bwInventory.getObjType());
					stmt.setString(2, bwInventory.getObjName());
					stmt.setLong(3, bwInventory.getRequestId());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");

					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("POC_BWInventory::::::::::IN::::::::::POC_BWInventory Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	public String pocFIORIOutputBatchInsertUpdate(List<POC_FioriOutput> pocFioriOutputList, HttpSession session)
			throws SQLException {

		final String INSERT_SQL = "INSERT INTO FIORI_APPS_OUTPUT "
				+ "(TCODE, APP_ID, APP_NAME, APP_TYPE, APPLICATION_COMPONENT, APPLICATION_COMPONENT_TEXT, REQUEST_ID) " + "values (?, ?, ?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (POC_FioriOutput fioriOutput : pocFioriOutputList) {
					stmt.setString(1, fioriOutput.gettCode());
					stmt.setString(2, fioriOutput.getAppId());
					stmt.setString(3, fioriOutput.getAppName());
					stmt.setString(4, fioriOutput.getAppType());
					stmt.setString(5, fioriOutput.getApplicationComponent());
					stmt.setString(6, fioriOutput.getApplicationComponentText());
					stmt.setLong(7, fioriOutput.getRequestId());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");

					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("POC_FioriOutput::::::::::IN::::::::::fiori output Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	public String pocBWClanUpBatchInsertUpdate(List<POC_BWCleanUpUtility> pocBWCleanUpList, HttpSession session)
			throws SQLException {

		final String INSERT_SQL = "INSERT INTO Bw_Cleanup_Util "
				+ "(Object_Type, Object_Name, Last_Used, Elapsed_Time_Year, Status, REQUEST_ID) "
				+ "values (?, ?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (POC_BWCleanUpUtility bwCleanUp : pocBWCleanUpList) {
					stmt.setString(1, bwCleanUp.getObjType());
					stmt.setString(2, bwCleanUp.getObjName());
					stmt.setString(3, bwCleanUp.getLastUsedDate());
					stmt.setString(4, bwCleanUp.getElapsedTypeInYears());
					stmt.setString(5, bwCleanUp.getStatus());
					stmt.setLong(6, bwCleanUp.getRequestId());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");

					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("POC_BWCleanUpUtility::::::::::IN::::::::::BW Cleanup Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	// TODO
	public String pocImpactedCustomTableBatchInsertUpdate(List<POC_ImpactedCustomTable> pocImpactedCusTablList,
			HttpSession session) throws SQLException {

		final String INSERT_SQL = "INSERT INTO S4_Impacted_Custom_download "
				+ "(OBJ_NAME, OBJ_PACKAGE, COMMENTS, DESC_CHANGE, SAP_NOTE, SOLUTION_STEP, COMPLEXITY, ISSUE_CATEGORY, ISSUE_SUB_CATEGORY, TRIGGER_OBJECT, REMEDIATION_CATEGORY, SAP_SIMPLI_LIST, APPLICATION_COMP, SAP_SIMPLI_CATEGORY, ITEM_AREA, REQUEST_ID) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (POC_ImpactedCustomTable impactedCusTabl : pocImpactedCusTablList) {
					stmt.setString(1, impactedCusTabl.getObject());
					stmt.setString(2, impactedCusTabl.getPackg());
					stmt.setString(3, impactedCusTabl.getImpactedFields());
					stmt.setString(4, impactedCusTabl.getDesOfChange());
					stmt.setString(5, impactedCusTabl.getSapNotes());
					stmt.setString(6, impactedCusTabl.getSolStep());
					stmt.setString(7, impactedCusTabl.getComplexity());
					stmt.setString(8, impactedCusTabl.getIssueCategory());
					stmt.setString(9, impactedCusTabl.getIssueSubCategory());
					stmt.setString(10, impactedCusTabl.getTriggerObj());
					stmt.setString(11, impactedCusTabl.getRemediationCat());
					stmt.setString(12, impactedCusTabl.getSapSimListChapter());
					stmt.setString(13, impactedCusTabl.getAppComponent());
					stmt.setString(14, impactedCusTabl.getSapSimCategory());
					stmt.setString(15, impactedCusTabl.getItemArea());
					stmt.setLong(16, impactedCusTabl.getRequestId());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");

					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info(
						"POC_ImpactedCustomTable::::::::::IN::::::::::impacted custom table Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	public String pocBWStandardExBatchInsertUpdate(List<POC_BWStandardExtract> pocBwStandExList, HttpSession session)
			throws SQLException {

		final String INSERT_SQL = "INSERT INTO BW_STANDARD_EXTRACT "
				+ "(obj_name, phase, area_responsibility, data_source, app_component, classification, category, restrictions, related_simplification_item, note, del_1511, del_1610, delta_restrict, comments, Request_Id) "
				+ "values (?, ?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (POC_BWStandardExtract bwStandardEx : pocBwStandExList) {
					stmt.setString(1, bwStandardEx.getExtractorList());
					stmt.setString(2, bwStandardEx.getPhase());
					stmt.setString(3, bwStandardEx.getAreaOfRes());
					stmt.setString(4, bwStandardEx.getDataSource());
					stmt.setString(5, bwStandardEx.getApplcomponent());
					stmt.setString(6, bwStandardEx.getClassification());
					stmt.setString(7, bwStandardEx.getCategory());
					stmt.setString(8, bwStandardEx.getResMandatoryForStatus());
					stmt.setString(9, bwStandardEx.getRelSimItem());
					stmt.setString(10, bwStandardEx.getNote());
					stmt.setString(11, bwStandardEx.getDel1511());
					stmt.setString(12, bwStandardEx.getDel1610());
					stmt.setString(13, bwStandardEx.getDeltaRes());
					stmt.setString(14, bwStandardEx.getComments());
					stmt.setLong(15, bwStandardEx.getRequestId());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");

					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info(
						"POC_BWStandardExtract::::::::::IN::::::::::poc bw standard table Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	public String pocInactiveObjectsBatchInsertUpdate(List<POC_InactiveObjects> pocInactiveList, HttpSession session)
			throws SQLException {

		final String INSERT_SQL = "INSERT INTO Inactive_Objects "
				+ "(OBJECT, OBJ_NAME, UNAME, DELET_FLAG, TAB_CLASS, Request_Id) " + "values (?, ?, ?, ?, ?, ?)";
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (POC_InactiveObjects inactiveObj : pocInactiveList) {
					stmt.setString(1, inactiveObj.getObject());
					stmt.setString(2, inactiveObj.getObjName());
					stmt.setString(3, inactiveObj.getuName());
					stmt.setString(4, inactiveObj.getDeleteFlag());
					stmt.setString(5, inactiveObj.getTabClass());
					stmt.setLong(6, inactiveObj.getRequestId());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");

					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("POC_InactiveObjects::::::::::IN::::::::::inactive objects Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;
	}

	public void pocSecAnalyzerTCDDataInsert(List<POC_SecAnalyzerTCDReport> secAnalyzerTCDList, HttpSession session)
			throws SQLException {
		String insertSQL = "INSERT INTO Sa_Tcd_Report_Download "
				+ "(Request_ID, targetVersion, AGR_NAME, LOW, HIGH, newTcode, functional_area, status) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?)";

		try (Connection conn = DBConfig.getJDBCConnection(session)) {
			conn.setAutoCommit(false);
			try (PreparedStatement stmt = conn.prepareStatement(insertSQL)) {
				int batch = 1, counter = 1;

				for (POC_SecAnalyzerTCDReport tcdObj : secAnalyzerTCDList) {
					stmt.setInt(1, (tcdObj.getRequestID()).intValue());
					stmt.setString(2, tcdObj.getTargetVersion());
					stmt.setString(3, tcdObj.getRoleName());
					stmt.setString(4, tcdObj.getLow());
					stmt.setString(5, tcdObj.getHigh());
					stmt.setString(6, tcdObj.getNewTcode());
					stmt.setString(7, tcdObj.getFunctionalArea());
					stmt.setString(8, tcdObj.getStatus());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 1000 records
					if (counter % 1000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();

						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();

				logger.info("Security Analyzer TCD Report Data INSERTED SUCCESSFULLY ...");
			} catch (Exception e) {
				logger.error("FAILURE in inserting data into Security Analyzer TCD DB --- ", e);
			}
		} catch (Exception e) {
			logger.error("FAILURE in Getting Connection --- ", e);
		}
	}
	
	public void pocDrillDownRprtBatchInsert(List<POC_DrillDownReport> pocDrillDownRprtList, HttpSession session)
			throws SQLException {
		String INSERT_SQL = "INSERT INTO s4_final_output"
				+ "(TYPE, OBJ_NAME, METHOD, READ_PROG, PCKG, OPERATIONS, LINE_NO, STMT, IMPACTED_OBJ_TYPE, IMPACT_REASON, "
				+ "DESC_OF_CHANGE, SAP_NOTES, SOLUTION_STEPS, complexity, ISSUE_CATEGORY, ERROR_CATEGORY, TRIGGER_OBJ, "
				+ "Remediation_Category, SAP_SIMP_LIST, APP_COMPONENT, SAP_SIMPL_CATEGORY, ITEM_AREA, USED, REQUEST_ID, "
				+ "OBJ_NAME_TYPE, SELECT_LINE, Correction_ProgName, Correction_LineNo, Impact, RICEF_CATEGORY, TOOL_Version) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);

			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (POC_DrillDownReport hpro : pocDrillDownRprtList) {
					stmt.setString(1, hpro.getObjType());
					stmt.setString(2, hpro.getObjName());
					stmt.setString(3, hpro.getSubObjName());
					stmt.setString(4, hpro.getReadProgram());
					stmt.setString(5, hpro.getPkg());
					stmt.setString(6, hpro.getOperation());
					stmt.setLong(7, hpro.getLineNo());
					stmt.setString(8, hpro.getStatement());
					stmt.setString(9, hpro.getImpactedObj());
					stmt.setString(10, hpro.getImpactReason());
					stmt.setString(11, hpro.getDescOfChange());
					stmt.setString(12, hpro.getSAPNote());
					stmt.setString(13, hpro.getSolutionStep());
					stmt.setString(14, hpro.getComplexity());
					stmt.setString(15, hpro.getIssueCategory());
					stmt.setString(16, hpro.getIssueSubCategory());
					stmt.setString(17, hpro.getTriggerObject());
					stmt.setString(18, hpro.getRemediationCategory());
					stmt.setString(19, hpro.getSAPSimpliListChapter());
					stmt.setString(20, hpro.getAppComponent());
					stmt.setString(21, hpro.getSAPSimpliCategory());
					stmt.setString(22, hpro.getItemArea());
					stmt.setString(23, hpro.getUsed());
					stmt.setLong(24, hpro.getRequestId());
					stmt.setString(25, hpro.getObjectNameType());
					stmt.setString(26, hpro.getSelLine());
					stmt.setString(27, hpro.getCorProgName());
					stmt.setString(28, hpro.getCorLineNo());
					stmt.setString(29, hpro.getImpact());
					stmt.setString(30, hpro.getRicefCategory());
					stmt.setString(31, hpro.getToolVersion());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("Drill Down Report Inserted Sucessfully !!!");
			} catch (Exception e) {
				logger.error("POC - Error while reading Drill Down Report : ", e);
			}
		} catch (Exception e) {
			logger.error("Error while getting connection : ", e);
		} finally {
			stmt.close();
			conn.close();
		}
	}
}