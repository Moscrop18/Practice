/*CR-No.   Desc   Date    Modified By
 * 
 * CR-9.0:- Manual upload for Estimator & assuptions -17/01/17 -monika.mishra
 * 
 * CR-12.0- Update Master table of request after completion. - 22/02/2017 - monika.mishra
 * 
 * CR-13.0- New Output Sheet implementation - 03/03/2017 - monika.mishra
 * 
 * CR-27.0- Populating Data on Fiori reporting DHL sheet-3/08/17-rohan.a.mehra
 * 
 * CR:56 Change in Hana estimation to get used estimation --rohan.a.mehra
 * 
 * */

package com.act.displaygraph.dao;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.act.S4.models.S4Estimations;
import com.act.UI5.models.UI5GraphCounts;
import com.act.displaygrid.model.HanaAssumption;
import com.act.displaygrid.model.HanaEstimator;
import com.act.master.ExtensionScope;
import com.act.master.FioriRequestMaster;
import com.act.master.ProcessedRequestDetail;
import com.act.master.TestingScope;
import com.google.common.collect.Multimap;
import com.act.impactedBackgroundJob.ImpactedBackgroundCounts;

public interface DisplayGraphDao {

	public int getStatusWiseCount(String status, final String toolName);
	Map<String, Integer> getCountCategory(final Long requestId);
	Map<String, Map<String, Integer>> getCountSubCategory(final Long requestId);
	Map<String, Integer> getCountUsedUnused(final Long requestId);
	Map<String, Integer> getCountImpact(final Long requestId);
	Map<String, Map<String, Integer>> getObjectTypeUsedunusedCount(final Long requestID);
	

	
	Map<String, String> getTotalCountCustomObjets(final Long requestId,String ObjectType);
	//Map<String, String> getHighMediumLowCount(final Long requestId,String ObjectType);
	
	//CR:56 Change in Hana estimation to get used estimation
	Multimap<String, BigInteger> getTotal_UsedDefectObjectCount(Long requestId,String ObjectType);
	
	Multimap<String, BigInteger> getTotal_DefectObjectCount(Long requestId,String ObjectType);
	//Map<String, String> getHighMediumLow_DefectObjectCount(Long requestId,String ObjectType);
	
	
	public int calculateActualCount(int count);
	
	public String getClientNameSpace_Name(Long requestId); 
	
	
	public Map<String, String> getOperation_ErrorMap();
	public Map<String, String> getSecond_SubCat();
	/*CR-9.0*/
	public List<HanaEstimator> getHanaEstimatorObjects(Long requestId);
	public List<HanaAssumption> getHanaAssumptionsObjects(Long requestId);
	
	public ProcessedRequestDetail getRequestMasterCommonColumns(Long requestId);
	/*CR-12.0*/
	public void updateRequestMaster(long requestId,ProcessedRequestDetail requestMasterCommon);
	
	/*CR-13.0*/
	Map<String, Integer> getDistObjNameCountCLAS(Long requestId);
	Map<String, Integer> getDistObjNameCountPROG(Long requestId);
	
	// CR-12.3 Start

	public void updateRequestMasterEstimations(long requestId);
    // CR-12.3 End
	
	
	//CR-27: Populating Data on Fiori reporting DHL sheet
	public Map<String,Integer> getUniqueOdataCount(Long requestId);

	public Map<String, Integer> getYearCount(String ig, String status, final String toolName);
	public Map<String, Integer> getMonthCount(String ig, String status, final String toolName);
	public Map<String, Integer> getQuarterCount(String ig, String status, final String toolName);
	public Map<String, Integer> getDayCount(String ig, String status, final String toolName);
	public Map<String, Integer> getIgCount(String status, final String toolName);
	
	public Map<String, Integer> getYearCountGraph(String ig, String status,String toolName,String dealtype,String unicode, String Source, String target);
	public Map<String, Integer> getMonthCountGraph(String ig, String status,String toolName,String dealtype,String unicode, String Source, String target);

	
	//CR-52 : AIES Tool Integration
	List<ProcessedRequestDetail> getReqMaster(long requestId);
	
	List<S4Estimations> getS4EstimatorObjects(Long requestId);
	Map<String, Integer> getGraphCountCategory(Long requestId);
	Map<String, Integer> getGraphCountImpact(Long requestId);
	Map<String, Integer> getGraphCountUsedUnused(Long requestId);
	Map<String, Integer> getGraphCountSubCategory(Long requestId);
	void testingScopeRequestMaster(Long requestId,HttpSession session);
	void updateTestingScopeMasterData(long requestId, TestingScope master);
	List<TestingScope> getTestingReqMaster(long requestId);
	List<UI5GraphCounts> getUI5Master(long requestId);
	void updateUI5GraphCountApi(long requestId);

	Map<String, String> getTestingScopeProcessTabWithCount(Long requestId);
	Map<String, HashSet<String>> getTestingScopeProcessTabWithoutCount(Long requestId);
	
	//Fiori/Odata Graphs
		List<FioriRequestMaster> getFioriRequestMaster(long requestId);
		Map<String, ArrayList<String>> getProbableFitmentStandardAppsTable(Long requestId);
	
	//Impacted Background Job Graph
		void updateImpatedBackgroundJobCount(long requestId);		
		List<ImpactedBackgroundCounts> getImpactedBackgroundCounts(long requestId);
		
		public void saveGraphDataForExt(ExtensionScope extensionScope,Long requestId, HttpSession session) throws NoSuchMethodException, SecurityException;
		
		public List<ExtensionScope> getExtensionScopeMaster(long requestId);
		
}
