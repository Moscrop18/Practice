package com.act.exceptions;

public class UploadFilesNotValidException extends Exception {

	private static final long serialVersionUID = 1L;

	public UploadFilesNotValidException(String msg) {
		super(msg);
	}
}
