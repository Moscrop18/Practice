package com.act.exceptions;

public class RequestNotValidException extends RuntimeException{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4252093000192311180L;
	/**
	 * 
	 */
	private String errMsg;

	

	public String getErrMsg() {
		return errMsg;
	}

	public void setErrMsg(String errMsg) {
		this.errMsg = errMsg;
	}

	
	public RequestNotValidException()
	{
		
	}
	
	public RequestNotValidException(String errMsg)
	{
		super(errMsg);
		this.errMsg = errMsg;
	}
	
	
}
