package com.act.exceptions;

public class ReqIDNotValidException extends Exception {

	private static final long serialVersionUID = 1L;

	public ReqIDNotValidException(String ex) {
		super(ex);
	}
}
