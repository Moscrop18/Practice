package com.act.exceptions;

public class IDVFailedException extends RuntimeException{	

	private static final long serialVersionUID = 1L;

	private String IDVFailedExceptionMessage;

	public IDVFailedException(String IDVFailedExceptionMessage){
		super(IDVFailedExceptionMessage);
	}

	public String getIDVFailedExceptionMessage() {
		return IDVFailedExceptionMessage;
	}

	public void setIDVFailedExceptionMessage(String iDVFailedExceptionMessage) {
		IDVFailedExceptionMessage = iDVFailedExceptionMessage;
	}



}
