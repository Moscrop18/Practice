package com.act.exceptions;

public class ST03DataAnalysisException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String fileName;
	private int rowNum;
	private int colNum;
	
	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}
	/**
	 * @param fileName the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	/**
	 * @return the rowNum
	 */
	public int getRowNum() {
		return rowNum;
	}
	/**
	 * @param rowNum the rowNum to set
	 */
	public void setRowNum(int rowNum) {
		this.rowNum = rowNum;
	}
	/**
	 * @return the colNum
	 */
	public int getColNum() {
		return colNum;
	}
	/**
	 * @param colNum the colNum to set
	 */
	public void setColNum(int colNum) {
		this.colNum = colNum;
	}
	public ST03DataAnalysisException(String fileName, int rowNum, int colNum) {
		super();
		this.fileName =fileName;
		this.rowNum = rowNum;
		this.colNum = colNum;
	}
	@Override
	public String getMessage() {
		return "Error in file "+this.fileName+" row number "+(this.rowNum)+" column number "+(this.colNum)+". Enter decimal value instead of String. ";
		
	}
}
