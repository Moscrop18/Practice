package com.act.drools.helper;

public class EnumOprdataDbValues {

	public String enumInIf(OperationData opcode) {
		String oprData = null;
		if (opcode == OperationData.LEVEN) {
			oprData = "1,Mandatory,MANDATORY,Very high,convert native statement to open sql,NATIVE SQL CALL,11,Validated syntax error";
			return oprData;
		}
		if (opcode == OperationData.TWELVE) {			
			oprData= "2,Mandatory,MANDATORY,Very high,convert FM used for specific DB to HANA DB,DDIC FUNCTION MODULE CALL,12,Validated syntax error";
			return oprData;
		}
		if (opcode == OperationData.THIRTEEN) {	
			oprData="3,Housekeeping for HANA,MANDATORY,No Impact,No impact statement can be removed,DB HINTS USED,13,Statement ignored by HANA";

			return oprData;
		}
		if (opcode == OperationData.FOURTEEN) {	
			oprData="4,Application level optimization, ,High,Change the logic to avoid load on data,\"USAGE OF SORT - REPLACE BY \"\"ORDER BY \"\"\",14,Keep the result set small";
			return oprData;
		}
		if (opcode == OperationData.FIFTEEN) {			
			oprData= "5,Mandatory,MANDATORY,Very high,convert ADBC call to open sql,ADBC USAGE,15,Potential syntax error";
			return oprData;
		}
		if (opcode == OperationData.SIXTEEN) {			
			oprData= "6,Mandatory,MANDATORY,Very high,To get the sorted result out of select for internal table,Pool/Cluster Table,16,Semantic Error";
			return oprData;
		}
		if (opcode == OperationData.SEVENTEEN) {			
			oprData= "7,Mandatory,MANDATORY,Very High,convert DB operation on dependent table instead of table pool or table cluster,DB operations on Table pool & Table Cluster,17,Semantic Error";
			return oprData;
		}
		if (opcode == OperationData.EIGHTEEN) {			
			oprData= "8,Mandatory,MANDATORY,Very high,sort the internal table to avoid functional data issue,UNSORTED INTERNAL TABLE ACCESSED WITH INDEX,18,HANA Sorting";
			return oprData;
		}
		if (opcode == OperationData.NINTEEN) {			
			oprData= "9,Mandatory,MANDATORY,Very high,sort the internal table to avoid functional data issue,Control statement inside loop (Only when loop is using internal table which is not sorted),19,HANA Sorting";
			return oprData;
		}
		if (opcode == OperationData.THIRTY_ONE) {			
			oprData= "10,Application level optimization,RECOMMENDED ABAP LEVEL HANA OPTIMIZATIONS,High,Select without where degrades the performance,SELECT WITHOUT WHERE CLAUSE,31,Keep the result set small";
			return oprData;
		}
		if (opcode == OperationData.THIRTY_TWO) {			
			oprData= "11,Application level optimization,DB LEVEL HANA OPTIMIZATION,'\\\"LEVEL = 1, LOW; LEVEL = 2- MEDIUM ;LEVEL >2-HIGH\\\"',Loop within loop will degrade the performance,Nested Loops,32,Minimize the amount of transferred data";
			return oprData;
		}
		if (opcode == OperationData.THIRTY_THREE) {			
			oprData= "12,Application level optimization,APPLICATION LEVEL HANA OPTIMIZATION,High,change the logic to avoid select endselect for mutiple iteration,SELECT-ENDSELECT USED,33,Minimize the amount of transferred data";
			return oprData;
		}
		if (opcode == OperationData.THIRTY_FOUR) {			
			oprData= "13,Application level optimization,APPLICATION LEVEL HANA OPTIMIZATION,High,Use field instead of * to improve performance,SELECT SINGLE *,34,Minimize the amount of transferred data";
			return oprData;
		}
		if (opcode == OperationData.THIRTY_FIVE) {
			oprData = "14,Application level optimization,APPLICATION LEVEL HANA OPTIMIZATION,Very high,Use field instead of * to improve performance,SELECT *,35,Minimize the amount of transferred data";
			return oprData;

		}
		if (opcode == OperationData.THIRTY_SIX) {			
			oprData= "15,Application level optimization,APPLICATION LEVEL HANA OPTIMIZATION,Very high,Remove corresponding and ensuring select field & target field are same,Select With Field(S),36,Minimize the amount of transferred data";
			return oprData;
		}
		if (opcode == OperationData.THIRTY_SEVEN) {			
			oprData= "16,Housekeeping for HANA,MANDATORY,No Impact,No impact statement can be removed,BYPASS TABLE BUFFER,37,Keep unnecessary load away from database";
			return oprData;
		}
		if (opcode == OperationData.THIRTY_EIGHT) {			
			oprData= "17,DB Level HANA Optimization,DB LEVEL HANA OPTIMIZATION,Medium,Possibility of creating HANA artifact for performance improvement,Repeated Database Hits On Table,38,Minimize the amount of transferred data";
			return oprData;
		}
		if (opcode == OperationData.THIRTY_NINE) {			
			oprData= "18,DB Level HANA Optimization,'DB LEVEL HANA OPTIMIZATION', '\"JOIN = 3, MEDIUM; IF JOIN > 3 - HIGH\"',Possibility of creating HANA artifact for performance improvement,JOINS ON TABLES IN SELECT STATEMENTS,39,Minimize the amount of transferred data";
			return oprData;
		}
		if (opcode == OperationData.FOURTY) {			
			oprData= "19,DB Level HANA Optimization,DB LEVEL HANA OPTIMIZATION,Medium,Use HANA artifact like CDS AMDP instead of For all entries,For All Entries used,40,Minimize the amount of transferred data";
			return oprData;
		}
		if (opcode == OperationData.FOURTY_ONE) {			
			oprData= "20,Application level optimization, ,NO IMPACT,Initial check recommended for performance improvement.,NO INITIAL CHECK - FOR ALL ENTRIES,41,Keep unnecessary load away from database";
			return oprData;
		}
		if (opcode == OperationData.FOURTY_TWO) {			
			oprData= "21,Application level optimization, , 'LEVEL = 1 - MEDIUM ; IF LEVEL >1 - HIGH',Possibility of avoiding BAPI inside loop to improve performance,BAPI IN LOOP,42,Minimize the amount of transferred data";
			return oprData;
		}
		if (opcode == OperationData.FOURTY_THREE) {			
			oprData= "22,Application level optimization, ,'LEVEL = 1 - MEDIUM ; IF LEVEL >1 - HIGH',Possibility of avoiding FM inside loop to improve performance,FM IN LOOP,43,Minimize the amount of transferred data";
			return oprData;
		}
		if (opcode == OperationData.FOURTY_FOUR) {			
			oprData= "23,DB Level HANA Optimization,DB LEVEL HANA OPTIMIZATION,High, 'Use in built currency conversion FM in select, Instead of using FM',FM USED FOR CURRENCY CONVERSION,44,Minimize the amount of transferred data";
			return oprData;
		}
		if (opcode == OperationData.FOURTY_FIVE) {			
			oprData= "24,'Mandatory, ,Very high,sort the internal table to avoid functional data issue,READ STATEMENT WITH BINARY AND WITHOUT SORTING,45,HANA Sorting";
			return oprData;
		}
		if (opcode == OperationData.FOURTY_SIX) {			
			oprData= "25,Mandatory, ,Very high,sort the internal table to avoid functional data issue',DELETE ADJACENT DUPLICATES IS USED WITHOUT SORTING,46,HANA Sortin";
			return oprData;
		}
		if (opcode == OperationData.FOURTY_SEVEN) {			
			oprData= "26,DB Level HANA Optimization,DB LEVEL HANA OPTIMIZATION,High,Avoid using collect statement to improve performance,AGGREGATION STATEMENT COLLECT,47,Minimize the amount of transferred data";
			return oprData;
		}
		if (opcode == OperationData.FOURTY_EIGHT) {			
			oprData= "27,Application Level Optimization,APPLICATION LEVEL HANA OPTIMIZATION,Medium,Avoid using control statement for performance improvement,CONTROL STATEMENT INSIDE LOOP,48,Minimize the amount of transferred data";
			return oprData;
		}
		if (opcode == OperationData.FOURTY_NINE) {			
			oprData= "28,Application Level Optimization,APPLICATION LEVEL HANA OPTIMIZATION,High,Avoid Update statement inside loop for performance improvement,ARRAY OPERATION UPDATE WITHIN A LOOP,49,Minimize the amount of transferred data";
			return oprData;
		}
		if (opcode == OperationData.FIFTY) {			
			oprData= "29,Application Level Optimization,APPLICATION LEVEL HANA OPTIMIZATION,High,Avoid Insert statement inside loop for performance improvement,ARRAY OPERATION INSERT WITHIN A LOOP,50,Minimize the amount of transferred data";
			return oprData;
		}
		if (opcode == OperationData.FIFTY_ONE) {			
			oprData= "30,Application Level Optimization,APPLICATION LEVEL HANA OPTIMIZATION,High,Avoid Modify statement inside loop for performance improvement,ARRAY OPERATION MODIFY WITHIN A LOOP,51,Minimize the amount of transferred data";
			return oprData;
		}
		if (opcode == OperationData.FIFTY_TWO) {			
			oprData= "31,Application Level Optimization,APPLICATION LEVEL HANA OPTIMIZATION,High,Avoid Delete statement inside loop for performance improvement,ARRAY OPERATION DELETE WITHIN A LOOP,52,Minimize the amount of transferred data";
			return oprData;
		}
		if (opcode == OperationData.FIFTY_THREE) {			
			oprData= "32,Application Level Optimization, ,High,Additional iteration of loop degrades the performance, CHECK/EXIT IN LOOP,53,Keep the result set small";
			return oprData;
		}
		if (opcode == OperationData.FIFTY_FOUR) {			
			oprData= "33,Application Level Optimization,APPLICATION LEVEL HANA OPTIMIZATION,Low,Revisit the logic to improve the performance,LOGICAL DATABASE USED IN AN OBJECT,54,Keep unnecessary load away from database";
			return oprData;
		}
		if (opcode == OperationData.FIFTY_SIX) {			
			oprData= "34,Application Level Optimization,APPLICATION LEVEL HANA OPTIMIZATION,High,Avoid negative operation to improve performance,NEGATIVE OPERATION IN WHERE CLAUSE,56,Keep unnecessary load away from database";
			return oprData;
		}
		if (opcode == OperationData.FIFTY_SEVEN) {			
			oprData= "37,Mandatory,MANDATORY,Very High,To get the sorted result out of select for single record,Select Single without key fields,57,HANA Sorting";
			return oprData;
		}
		if (opcode == OperationData.FIFTY_EIGHT) {			
			oprData= "35,DB Level HANA Optimization,DB LEVEL HANA OPTIMIZATION,High,Possibility of creating HANA artifact for performance improvement,FAE & JOIN,58,Minimize the amount of transferred data";
			return oprData;
		}
		if (opcode == OperationData.FIFTY_NINE) {			
			oprData= "38,Mandatory, NULL,Very high,Service without any active ICF node,Inactive service,59,OData Service Compatability";
			return oprData;
		}
		if (opcode == OperationData.SIXTY) {			
			oprData= "39,Mandatory, NULL,Very high,Appropriate data source not maintained,Missing data source,60,OData Service Compatability";
			return oprData;
		}
		if (opcode == OperationData.SIXTY_ONE) {			
			oprData= "40,Mandatory, NULL,Very high,Hardcoded user crdentials,Anynomous access,61,OData Service Compatability";
			return oprData;
		}
		if (opcode == OperationData.SIXTY_TWO) {			
			oprData= "41,Not-Mandatory, NULL,Medium,Data set should be filtered to avoid sending complete data,Usage of filter options,62,OData Service Compatability";
			return oprData;
		}
		if (opcode == OperationData.SIXTY_THREE) {			
			oprData= "42,Not-Mandatory, NULL,Medium,Data set should be sent in chunks to avoid sending complete data,Usage of client-side paging,63,OData Service Compatability";
			return oprData;
		}
		if (opcode == OperationData.SIXTY_FOUR) {			
			oprData= "43,Not-Mandatory, NULL,Medium,Data set should be sent in chunks to avoid sending complete data,Usage of server side paging,64,OData Service Compatability";
			return oprData;
		}
		if (opcode == OperationData.SIXTY_FIVE) {			
			oprData= "44,Not-Mandatory, NULL,Low,Total count of available records should be provided in case of paging,Indication of total count,65,OData Service Compatability";
			return oprData;
		}
		if (opcode == OperationData.SIXTY_SIX) {			
			oprData= "45,Mandatory, NULL,Very high,Association clause should be maintained,Usage of association,66,OData Service Compatability";
			return oprData;
		}
		if (opcode == OperationData.SIXTY_SEVEN) {			
			oprData= "52,Application level optimization,Application level optimization,High,Avoid Update statement inside loop for performance improvement,ARRAY OPERATION UPDATE WITHIN A LOOP,67,Minimize the amount of transferred data";
			return oprData;
		}
		if (opcode == OperationData.SIXTY_EIGHT) {			
			oprData= "53,Application level optimization,Application level optimization,High,Avoid Update statement inside loop for performance improvement,Delete statement for result of select found,68,Minimize the amount of transferred data";
			return oprData;
		}
		if (opcode == OperationData.SEVENTY_ONE) {			
			oprData= "46,Not-Mandatory, NULL,Low,Number of properties should be relevant to the entity,OData Modeling,71,OData Service Compatability";
			return oprData;
		}
		if (opcode == OperationData.SEVENTY_TWO) {			
			oprData= "47,Not-Mandatory, NULL,Low,Property label not maintained,OData Modeling,72,OData Service Compatability";
			return oprData;
		}
		if (opcode == OperationData.SEVENTY_THREE) {			
			oprData= "48,Not-Mandatory, NULL,Low,Property name not maintained appropriately,OData Modeling,73,OData Service Compatability";
			return oprData;
		}
		if (opcode == OperationData.SEVENTY_FOUR) {			
			oprData= "49,Mandatory, NULL,Very high,ABAP & EDM data type mismatch,OData Modeling,74,OData Service Compatability";
			return oprData;
		}
		if (opcode == OperationData.SEVENTY_FIVE) {			
			oprData= "50,Mandatory, NULL,Very high,Data being cached on server should be assessed,Usage of server side data caching,75,OData Service Compatability";
			return oprData;
		}
		if (opcode == OperationData.SEVENTY_SIX) {			
			oprData= "51,Mandatory, NULL,Very high,CSRF token check disabled,Unauthorized access,76,OData Service Compatability";
			return oprData;
		}
		
		return " , , , , , , , ";
	}

}