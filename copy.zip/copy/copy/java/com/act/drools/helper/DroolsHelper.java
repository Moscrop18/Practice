/*MODIFIED 
*CR: DEF013: update Final Output with Inventory List for Package Column -himani.malhotra -09/01/2019
	
*DEF041: -- Automation status should be 'No' where SKIP= X -01/03/2019 -himani.malhotra

*/
package com.act.drools.helper;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.drools.RuleBase;
import org.drools.RuleBaseFactory;
import org.drools.WorkingMemory;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.compiler.DroolsParserException;
import org.drools.compiler.PackageBuilder;
import org.drools.compiler.PackageBuilderErrors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;

import com.act.S4.models.S4InventoryList;
import com.act.client.model.UserExit;
import com.act.constant.Hana_Profiler_Constant;
import com.act.displaygrid.model.DBConfig;
import com.act.displaygrid.model.HanaProfile;
import com.act.fileprocessing.PopulateHanaTables;
import com.act.fileprocessing.model.UsageAnalysis;
import com.act.model.DRL.CodeAssessmentPayLoad;

/**
 * This Helper class provides necessary inputs to work with rules
 * 
 * @author gunasekaran.ramasamy
 *
 */
@Configuration
public class DroolsHelper {
	private static PackageBuilderErrors errors;
	private static Iterator<KnowledgeBuilderError> iterator;
	private static String message;
	private static String operation_code;
	private static PopulateHanaTables populateHanaTable;
	public static Map<String, String> resultMap;
	public static HttpSession session;

	public static HttpSession getSession() {
		return session;
	}

	public static void setSession(HttpSession session) {
		DroolsHelper.session = session;
	}

	final static Logger logger = LoggerFactory.getLogger(DroolsHelper.class);

	/**
	 * This method returns the rule working memory
	 * 
	 * @return WorkingMemory session to work with rules
	 * @throws DroolsParserException Exception to be thrown when issue in parsing
	 *                               DRL file
	 * @throws IOException           Exception to be thrown when IO Operation fails
	 */

	public WorkingMemory getStatefulSession() throws DroolsParserException, IOException {
		PackageBuilder packageBuilder = new PackageBuilder();
		String ruleFile = "/rules/rules.drl";
		WorkingMemory workingMemory = null;
		try {
			InputStream resourceAsStream = getClass().getResourceAsStream(ruleFile);
			Reader reader = new InputStreamReader(resourceAsStream);
			packageBuilder.addPackageFromDrl(reader);
			org.drools.rule.Package rulesPackage = packageBuilder.getPackage();
			if (packageBuilder.hasErrors()) {
				errors = packageBuilder.getErrors();
				iterator = errors.iterator();
				while (iterator.hasNext()) {
					KnowledgeBuilderError kbe = iterator.next();
					message = kbe.getMessage();
					logger.error("Error :::: " + message);
				}
			}
			RuleBase ruleBase = RuleBaseFactory.newRuleBase();
			ruleBase.addPackage(rulesPackage);
			workingMemory = ruleBase.newStatefulSession();

		} catch (Exception e) {
			logger.error("Error : " + e.getMessage());
		}

		return workingMemory;
	}

	/**
	 * This method copies the objects from one to another
	 * 
	 * @param hm Pay load to the rule engine
	 * @throws SQLException
	 */
	/*
	 * public void setPopulateHanaTable(PopulateHanaTables populateHanaTable) {
	 * DroolsHelper.populateHanaTable = populateHanaTable; }
	 */
	// US-04.1, US-04.2
	/*
	 * public static void addLsmwToInventory(CodeAssessmentPayLoad ca) throws
	 * SQLException { //List<Lsmw> lsmwList = ca.getLsmwList(); List<UsageAnalysis>
	 * usageAnalysisList = ca.getUsageAnalysisList(); List<S4InventoryList>
	 * inventoryList = ca.getInventoryList(); List<UserExit> userExitlist=
	 * ca.getUserExitList(); setSession(ca.getSession()); //List<UserExit>
	 * userExitList = ca.getUserExitList();
	 * 
	 * System.out.println("Inventory size Before execution : " +
	 * inventoryList.size());
	 * 
	 * //System.out.println("lsmwList size Before execution : " + lsmwList.size());
	 * 
	 * long start = System.currentTimeMillis(); logger.
	 * info("start of UserExit for loop:::::::::::: Rule 2 1st for loop start  "
	 * +start);
	 * 
	 * for (UserExit ue : userExitlist) { S4InventoryList s4 = new
	 * S4InventoryList(); s4.setObjName(ue.getObjName()); s4.setObjType("UserExit");
	 * s4.setObjNameType(ue.getObjNameType()); s4.setRequestID(ue.getRequestID());
	 * inventoryList.add(s4); }
	 * 
	 * for(S4InventoryList iv : inventoryList) { for(UsageAnalysis ua :
	 * usageAnalysisList) {
	 * if(iv.getObjNameType().equalsIgnoreCase(ua.getObjNameType())) {
	 * iv.setUsage("Y"); } } } long end = System.currentTimeMillis();
	 * 
	 * logger.info("addLsmwToInventory for loop time :::::::::::::::::::::" +(end -
	 * start)/ 1000 + "s");
	 * 
	 * 
	 * System.out.println("Inventory size After execution : " +
	 * inventoryList.size());
	 * 
	 * DroolsHelper.InventoryListBatchInsertUpdate(inventoryList,getSession());
	 * 
	 * //populateHanaTable.populateDataList(inventoryList); }
	 */

	public static PopulateHanaTables getPopulateHanaTable() {
		return populateHanaTable;
	}

	public static void setPopulateHanaTable(PopulateHanaTables populateHanaTable) {
		DroolsHelper.populateHanaTable = populateHanaTable;
	}

	/**
	 * Processing HANA profile for the rule Process Hanaprofile object
	 * 
	 * @param ca Pay load to the rule
	 */
	EnumOprdataDbValues enumOprValues = new EnumOprdataDbValues();

	public static void processHanaProfile(CodeAssessmentPayLoad ca) throws SQLException {
		List<HanaProfile> listOfHanaProfile = ca.getListOfHanaProfile();
		// List<HanaProfilerStepOutput> hanaProfileStepList =
		// ca.getHanaProfileStepList();
		resultMap = ca.getResultMap();

		setSession(ca.getSession());
		/* 
		 * long start = System.currentTimeMillis(); logger.
		 * info("start of HanaProfilerStepOutput for loop:::::::::::::::: Rule 2 1st for loop start  "
		 * +start); for (HanaProfilerStepOutput step : hanaProfileStepList) {
		 * for(HanaProfile h: listOfHanaProfile){ if(h.getJoinID()== step.getJoinID()){
		 * h.setObj_Name(step.getObjName()); h.setObject_Type(step.getObjectType());
		 * h.setObjNameType(step.getObjNameType());
		 * h.setOperation_code(step.getOperationCode());
		 * h.setTotalLineScanned(step.getTotalLineScanned());
		 * h.setLine_Number(step.getLineNo()); h.setRequestID(step.getRequestID());
		 * //listOfHanaProfile.add(h); } } } long end = System.currentTimeMillis();
		 * logger.
		 * info("end of  HanaProfilerStepOutput for loop:::::::::::::::::::::::: Rule 2 1st for loop end  "
		 * +end);
		 * logger.info("HanaProfilerStepOutput for loop time ::::::::::::::::::::::::"
		 * +(end - start)/ 1000 + "s");
		 */

		Map<String, String> secondSubCat = getSecondSubCat();
		logger.info("Size of Issue Second subCategory .... {} ", secondSubCat.size());

		// setting operation data values
		long start1 = System.currentTimeMillis();
		logger.info("start of setting operation data values::::::::::::::: Rule 2 2nd for loop start  " + start1);
		for (HanaProfile hp : listOfHanaProfile) {
			operation_code = hp.getOperation_code();
			if (operation_code != null && !operation_code.equals("")) {
				String oprdataValues = getOperationValues(operation_code);
				if (oprdataValues != null && !oprdataValues.equals("")) {
					String[] oprValuesArr = oprdataValues.split("\\|");
					String category = oprValuesArr[1];
					String operation = oprValuesArr[5];
					if (category.equalsIgnoreCase(("MANDATORY")) && !category.equals("")) {
						hp.setCOMPLEXITY(oprValuesArr[8]);
						if (hp.getObject_Type().equalsIgnoreCase("SSFO")
								|| hp.getObject_Type().equalsIgnoreCase("SFPI")) {
							hp.setCOMPLEXITY("MEDIUM");
						}

					} else {
						hp.setCOMPLEXITY(oprValuesArr[8]);
					}
					hp.setCategory(category);
					hp.setSubcategory(oprValuesArr[7]);
					hp.setHigh_lvl_desc(oprValuesArr[4]);
					hp.setImpact(oprValuesArr[3]);
					hp.setOpertaion(operation);
					hp.setIssueSecondSubCat(oprValuesArr[2]);
					hp.setAutomation_status(oprValuesArr[9]);
					// DEF040: -- Automation status=No when Type NOT EQUALS PROG, FUGR, FUGS and
					// CLAS
					if (!(hp.getObject_Type().equals("PROG") || hp.getObject_Type().equals("FUGR")
							|| hp.getObject_Type().equals("FUGS") || hp.getObject_Type().equals("CLAS"))) {
						hp.setAutomation_status("No");
					}
					// DEF041: -- Automation status should be 'No' where SKIP= X
					if (hp.getSkip() != null && !hp.getSkip().isEmpty() && hp.getSkip().trim() != ""
							&& hp.getSkip().equals("X")) {
						hp.setAutomation_status("No");
						String skip_Reason = hp.getSkipReason();
						hp.setSkipReason(skip_Reason);
					} else {
						hp.setSkipReason("");
					}
					logger.info("OBJECT TYPE:::" + hp.getObject_Type() + "OBJECT NAME :::::" + hp.getObj_Name()
							+ "USAGE :::::" + hp.getUsed_Unused());
				}

			}
			if(MapUtils.isNotEmpty(ca.getMetaDataMap()) && ca.getMetaDataMap().containsKey(hp.getObjNameType())){
				if(null != ca.getMetaDataMap().get(hp.getObjNameType())){
				hp.setRicefCategory(ca.getMetaDataMap().get(hp.getObjNameType()).getRicefCategory());
				}
				if (null != ca.getMetaDataMap().get(hp.getObjNameType()) && null != ca.getMetaDataMap().get(hp.getObjNameType()).getRicefSubCategory()) {
					hp.setRicefSubCategory(ca.getMetaDataMap().get(hp.getObjNameType()).getRicefSubCategory());
				}
			}
			if (StringUtils.isBlank(hp.getRicefCategory()) && "SSFO".equalsIgnoreCase(hp.getObject_Type())) {
				hp.setRicefCategory("FORMS");
				hp.setRicefSubCategory("Smartforms");
			}
			if (StringUtils.isBlank(hp.getRicefCategory()) && "SFPF".equalsIgnoreCase(hp.getObject_Type())) {
				hp.setRicefCategory("FORMS");
				hp.setRicefSubCategory("Adobe");
			}
			if ("AQQU".equalsIgnoreCase(hp.getObject_Type())) {
				hp.setRicefCategory("Others");
				hp.setRicefSubCategory("Configurable Report");
			}
			
			if (StringUtils.isBlank(hp.getRicefCategory()))
				hp.setRicefCategory(Hana_Profiler_Constant.OTHERS);
		}
		long end1 = System.currentTimeMillis();
		logger.info(
				"end of  setting operation data values for loop:::::::::::::::::: Rule 2 2nd for loop end  " + end1);
		logger.info(
				"setting operation data values for loop time :::::::::::::::::::::::" + (end1 - start1) / 1000 + "s");

		// CR: DEF013
		updatePackageFromInventory(ca, listOfHanaProfile);

		// updateAutomationStatus(listOfHanaProfile);
		// 2 more functions need to be added

		updateJoinTable(listOfHanaProfile);

		updateDetectionUsage(ca, listOfHanaProfile);
		// updateObjectType(ca, listOfHanaProfile);

		logger.info("HanaProfile After execution : " + listOfHanaProfile.size());
		try {
			long start2 = System.currentTimeMillis();
			logger.info("start of populateDataList--> listOfHanaProfile :::::::::::::::::::::   " + start2);

			// populateHanaTable.populateDataList(listOfHanaProfile);
			String result = jDBCBatchInsertUpdate(listOfHanaProfile, getSession());
			if (result.equals("SUCCESS")) {
				logger.info("INSERTED SUCCESSFULLY");
			} else {
				logger.info("Unsuccessful!!!!!!!!!!!!!!!!");
			}

			long end2 = System.currentTimeMillis();
			logger.info("end of  populateDataList--> listOfHanaProfile::::::::::::::::::::::: Rule 2 2nd for loop end  "
					+ end2);
			logger.info(
					"populateDataList--> listOfHanaProfile time :::::::::::::::::::" + (end2 - start2) / 1000 + "s");
		} catch (Exception e) {
			logger.error("Error:::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::", e);
		}
		// updateFrmTables(updateFinalOutput);
		// refineOpCode(listOfHanaProfile);

	}

	private static void updateJoinTable(List<HanaProfile> listOfHanaProfile) {
		String specialCharacters = "[" + "-/@#!*$%^&.'_+={}()" + "]+";
		if (null != listOfHanaProfile && !listOfHanaProfile.isEmpty()) {
			for (HanaProfile hanaProfile : listOfHanaProfile) {

				String code = hanaProfile.getCode().trim();
				if (!code.isEmpty() && null != code && "" != code) {
					String joinType = "";
					String joinS = "";
					String tables = "";
					String whereCondition = "";
					code = code.toUpperCase();
					if (code.startsWith("SELECT")) {
						if (code.contains(" INNER JOIN ")) {
							joinS = "YES";
							joinType = "INNER";
						}
						if (code.contains(" LEFT OUTER JOIN ")) {
							joinS = "YES";
							if (!joinType.trim().equals("") && null != joinType && !joinType.trim().isEmpty())
								joinType = joinType + " | " + "LEFT OUTER";
							else
								joinType = "LEFT OUTER";
						}
						if (code.contains(" RIGHT OUTER JOIN ") && null != joinType && !joinType.trim().isEmpty()) {
							joinS = "YES";
							if (!joinType.trim().equals("") && null != joinType && !joinType.trim().isEmpty())
								joinType = joinType + " | " + "RIGHT OUTER";
							else
								joinType = "RIGHT OUTER";
						}
						if ((code.contains(" JOIN ") && (joinType.trim().equals("")) || null == joinType)) {
							joinS = "YES";
							if (!joinType.trim().equals("") && null != joinType && !joinType.trim().isEmpty())
								joinType = joinType + " | " + "INNER";
							else
								joinType = "INNER";
						}
						if (code.contains(" FROM ")) {
							if (null == joinType || joinType.trim().equals("")) {

								String[] codeArr = code.split(" FROM ");
								codeArr = codeArr[1].split("\\s");
								for (String tableName : codeArr) {
									if (!tableName.matches(specialCharacters)) {
										if (!tableName.trim().equals("")) {
											tables = tableName;
											break;
										}
									}
								}

							} else {
								String[] codeArr = code.split(" FROM ");
								String[] joinSplitArr = codeArr[1].split("JOIN ");
								for (int i = 0; i < joinSplitArr.length; i++) {
									String[] joinSplit = joinSplitArr[i].split("\\s");
									for (String tableName : joinSplit) {
										if (!tableName.matches(specialCharacters)) {
											if (!tableName.trim().equals("")) {
												if (!tables.trim().equals(""))
													tables = tables + "," + tableName;
												else
													tables = tableName;
												break;
											}
										}
									}
								}
							}
						}
						if (code.contains(" WHERE ")) {
							String[] codeArr = code.split("WHERE ");
							whereCondition = ("WHERE" + " " + codeArr[1].trim());
						}
					}
					hanaProfile.setJoins(joinS);
					hanaProfile.setJoin_Type(joinType);
					hanaProfile.setTables(tables);
					hanaProfile.setWhere_Condition(whereCondition);

				}
			}
		}
	}

	// refining on the basis of op-code
	private static void refineOpCode(List<HanaProfile> listOfHanaProfile) {
		if (null != listOfHanaProfile || !listOfHanaProfile.isEmpty()) {
			Iterator<HanaProfile> hpItr = listOfHanaProfile.iterator();
			while (hpItr.hasNext()) {
				HanaProfile hp = hpItr.next();
				if (hp.getOperation_code().equals(Hana_Profiler_Constant.op_Code_99)
						|| hp.getOperation_code().equals(Hana_Profiler_Constant.op_Code_21)
						|| hp.getOperation_code().equals(Hana_Profiler_Constant.op_Code_20)) {
					hpItr.remove();
				}
			}
		}
	}

	// update Automation Status in Final Output
	private static void updateAutomationStatus(List<HanaProfile> listOfHanaProfile) {
		long start = System.currentTimeMillis();
		logger.info("start of updateAutomationStatus:::::::::::::::::::::::::::::::::::::::::::::::::" + start);
		for (HanaProfile hanaProfile : listOfHanaProfile) {
			String operr = "USAGE OF SORT - REPLACE BY \"ORDER BY \"\r\n" + "";
			// String operation=hanaProfile.getOpertaion().trim();
			if (null != hanaProfile.getOpertaion() && !hanaProfile.getOpertaion().isEmpty()
					&& "" != hanaProfile.getOpertaion().trim()) {
				String operation = hanaProfile.getOpertaion().trim();
				operation = operation.toUpperCase();
				switch (operation) {
				case "DDIC FUNCTION MODULE CALL":
					hanaProfile.setAutomation_status("Yes");
					break;
				case "DB HINTS USED":
					hanaProfile.setAutomation_status("Yes");
					break;
				case "POOL/CLUSTER TABLE":
					hanaProfile.setAutomation_status("Yes");
					break;
				case "BYPASS TABLE BUFFER":
					hanaProfile.setAutomation_status("Yes");
					break;
				case "NO INITIAL CHECK - FOR ALL ENTRIES":
					hanaProfile.setAutomation_status("Yes");
					break;
				case "READ STATEMENT WITH BINARY AND WITHOUT SORTING":
					hanaProfile.setAutomation_status("Yes");
					break;
				case "DELETE ADJACENT DUPLICATES IS USED WITHOUT SORTING":
					hanaProfile.setAutomation_status("Yes");
					break;
				case "READ TABLE ITAB ... INDEX X WITH UNSORTED ITAB":
					hanaProfile.setAutomation_status("Yes");
					break;
				case "MODIFY ITAB INDEX I WITH UNSORTED ITAB":
					hanaProfile.setAutomation_status("Yes");
					break;
				case "DELETE ITAB INDEX I WITH UNSORTED ITAB":
					hanaProfile.setAutomation_status("Yes");
					break;
				case "LOOP AT ITAB ... FROM FROM TO TO WITH UNSORTED ITAB":
					hanaProfile.setAutomation_status("Yes");
					break;
				case "DELETE ITAB FROM FROM TO TO WITH UNSORTED ITAB":
					hanaProfile.setAutomation_status("Yes");
					break;
				case "CONTROL STATEMENT INSIDE LOOP (ONLY WHEN LOOP IS USING INTERNAL TABLE WHICH IS NOT SORTED)":
					hanaProfile.setAutomation_status("Yes");
					break;
				case "UNSORTED INTERNAL TABLE ACCESSED WITH INDEX":
					hanaProfile.setAutomation_status("Yes");
					break;
				case "SELECT SINGLE WITHOUT KEY FIELDS":
					hanaProfile.setAutomation_status("Yes");
					break;
				case "NATIVE SQL CALL":
					hanaProfile.setAutomation_status("No");
					break;
				case "USAGE OF SORT - REPLACE BY \"ORDER BY \"":
					hanaProfile.setAutomation_status("No");
					break;
				case "ADBC USAGE":
					hanaProfile.setAutomation_status("No");
					break;
				case "SELECT WITHOUT WHERE CLAUSE":
					hanaProfile.setAutomation_status("No");
					break;
				case "NESTED LOOPS":
					hanaProfile.setAutomation_status("No");
					break;
				case "SELECT-ENDSELECT USED":
					hanaProfile.setAutomation_status("No");
					break;
				case "SELECT SINGLE *":
					hanaProfile.setAutomation_status("No");
					break;
				case "SELECT *":
					hanaProfile.setAutomation_status("No");
					break;
				case "SELECT WITH FIELD(S)":
					hanaProfile.setAutomation_status("No");
					break;
				case "REPEATED DATABASE HITS ON TABLE":
					hanaProfile.setAutomation_status("No");
					break;
				case "JOINS ON TABLES IN SELECT STATEMENTS":
					hanaProfile.setAutomation_status("No");
					break;
				case "FOR ALL ENTRIES USED":
					hanaProfile.setAutomation_status("No");
					break;
				case "BAPI IN LOOP":
					hanaProfile.setAutomation_status("No");
					break;
				case "FM IN LOOP":
					hanaProfile.setAutomation_status("No");
					break;
				case "FM USED FOR CURRENCY CONVERSION":
					hanaProfile.setAutomation_status("No");
					break;
				case "AGGREGATION STATEMENT COLLECT":
					hanaProfile.setAutomation_status("No");
					break;
				case "CONTROL STATEMENT INSIDE LOOP":
					hanaProfile.setAutomation_status("No");
					break;
				case "ARRAY OPERATION UPDATE WITHIN A LOOP":
					hanaProfile.setAutomation_status("No");
					break;
				case "ARRAY OPERATION INSERT WITHIN A LOOP":
					hanaProfile.setAutomation_status("No");
					break;
				case "ARRAY OPERATION MODIFY WITHIN A LOOP":
					hanaProfile.setAutomation_status("No");
					break;
				case "ARRAY OPERATION DELETE WITHIN A LOOP":
					hanaProfile.setAutomation_status("No");
					break;
				case "CHECK/EXIT/LEAVE STATEMENT WITHIN LOOP":
					hanaProfile.setAutomation_status("Yes");
					break;
				case "LOGICAL DATABASE USED IN AN OBJECT":
					hanaProfile.setAutomation_status("No");
					break;
				case "NEGATIVE OPERATION IN WHERE CLAUSE":
					hanaProfile.setAutomation_status("No");
					break;
				case "FAE & JOIN":
					hanaProfile.setAutomation_status("No");
					break;
				case "TABLE SIZE CATEGORY":
					hanaProfile.setAutomation_status("No");
					break;
				case "DB OPERATIONS ON TABLE POOL & TABLE CLUSTER":
					hanaProfile.setAutomation_status("No");
					break;
				case "DELETE STATEMENT FOR RESULT OF SELECT FOUND":
					hanaProfile.setAutomation_status("No");
					break;
				}
			}

		}

		long end = System.currentTimeMillis();
		logger.info("end of updateAutomationStatus::::::::::::::::::::::" + end);
		logger.info("updateAutomationStatus::::::::::::::::::::::::::::::::::::::::" + (end - start) / 1000 + "s");

	}

	// update object Type of Final Output to LSMW & USER Exit
	/*
	 * private static void updateObjectType(CodeAssessmentPayLoad
	 * ca,List<HanaProfile> listOfHanaProfile) { List<UserExit> userExitList =
	 * ca.getUserExitList(); long start = System.currentTimeMillis();
	 * logger.info("start of updateObjectType::::::::::::::::::::::"+start); if(null
	 * !=listOfHanaProfile || !listOfHanaProfile.isEmpty()) { for(HanaProfile hp :
	 * listOfHanaProfile) { if(hp.getObject_Type().equalsIgnoreCase("PROG")) {
	 * if(hp.getObj_Name().startsWith("/1CADMC/SAP_LSMW_CONV_")) {
	 * hp.setObject_Type("LSMW"); }else { for(UserExit ue: userExitList) {
	 * if(hp.getObj_Name().equalsIgnoreCase(ue.getObjName())) {
	 * hp.setObject_Type("USER Exit"); } } } } } } long end =
	 * System.currentTimeMillis();
	 * logger.info("end of updateObjectType::::::::::::::::::::::"+end);
	 * logger.info("updateObjectType:::::::::::::::::::::::::::" +(end - start)/
	 * 1000 + "s");
	 * 
	 * }
	 */

	// update Final Output with Usage
	private static void updateDetectionUsage(CodeAssessmentPayLoad ca, List<HanaProfile> listOfHanaProfile) {
		List<UsageAnalysis> usageAnalysisList = ca.getUsageAnalysisList();
		Set<String> usageAnalysisAQQUList = ca.getUsageAnalysisObjNameTypeReadProg();
		long start = System.currentTimeMillis();
		logger.info("start of updateDetectionUsage::::::::::::::::::::::" + start);
		if (CollectionUtils.isNotEmpty(usageAnalysisList)) {
			if (!listOfHanaProfile.isEmpty() || null != listOfHanaProfile) {
				for (HanaProfile hp : listOfHanaProfile) {
					String hpListObj = hp.getObjNameType();
					hpListObj = (hpListObj.startsWith("USRE") || hpListObj.startsWith("USRR"))
							? hpListObj.replace(hpListObj.substring(0, 4), "PROG")
							: hpListObj;
					if (CollectionUtils.isNotEmpty(usageAnalysisList)) {
						for (UsageAnalysis ua : usageAnalysisList) {
							if (hpListObj.equalsIgnoreCase(ua.getObjNameType())) {
								hp.setUsed_Unused("Y");
								break;
							} else {
								hp.setUsed_Unused("");
							}
						}
					}
					if(hp.getObject_Type().equalsIgnoreCase("AQQU")){
						String objTypeNameReadProg = hp.getObject_Type()+hp.getObj_Name()+hp.getReadProgram();
						if (CollectionUtils.isNotEmpty(usageAnalysisAQQUList)
								&& usageAnalysisAQQUList.contains(objTypeNameReadProg))
							hp.setUsed_Unused("Y");
						else
							hp.setUsed_Unused("");
					}
				}
			}
		}

		long end = System.currentTimeMillis();
		logger.info("end of updateObjectType::::::::::::::::::::::" + end);
		logger.info("updateDetectionUsage:::::::::::::::::::::::::::::::::::::::" + (end - start) / 1000 + "s");

	}

	// update Final Output with Inventory List for Package Column
	private static void updatePackageFromInventory(CodeAssessmentPayLoad ca, List<HanaProfile> listOfHanaProfile) {
		List<S4InventoryList> inventoryList = ca.getInventoryList();
		long start = System.currentTimeMillis();
		logger.info("start of updatePackageFromInventory::::::::" + start);
		if (!inventoryList.isEmpty() || null != inventoryList) {
			if (!listOfHanaProfile.isEmpty() || null != listOfHanaProfile) {
				for (HanaProfile hp : listOfHanaProfile) {
					for (S4InventoryList inv : inventoryList) {
						if (hp.getObjNameType().equalsIgnoreCase(inv.getObjNameType())) {
							hp.setOBJ_PACKAGE(inv.getPckg());
						}
					}
				}
			}
		}

		long end = System.currentTimeMillis();
		logger.info("end of updatePackageFromInventory:::::::" + end);
		logger.info("updatePackageFromInventory:::::::" + (end - start) / 1000 + "s");

	}

	private static String getOperationValues(String operation_code) {
		String oprvalues = "";
		if (resultMap.containsKey(operation_code)) {
			oprvalues = resultMap.get(operation_code);
		}

		return oprvalues;
	}

	public static String jDBCBatchInsertUpdate(List<HanaProfile> listOfHanaProfile, HttpSession session)
			throws SQLException {
		final String INSERT_SQL = "INSERT INTO FINAL_OUTPUT "
				+ "(Category, CHANGE_COLUMN, DB, Info, Join_Type, Joins, KEYS_COLUMN, Levels, Line_Number, Obj_Name, Object_Type, Odata, Opertaion, "
				+ "ReadProgram, Sub_Program, Sub_Type, Subcategory, Table_Type, TABLES_COLUMN, Used_Unused, Where_Condition, automation_status, code, "
				+ "high_lvl_desc, impact, JOIN_ID, LOOP_COLUMN, OBJ_NAME_TYPE, operation_code, Request_ID, SEL_LINE, total_line_scanned , OBJ_PACKAGE, "
				+ "COMPLEXITY, COMMENT_C, IssueSecondSubCat, skip, RICEF_CATEGORY, External_Namespace, Ricef_Sub_Category, Counter) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? , ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);

			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (HanaProfile hpro : listOfHanaProfile) {
					stmt.setString(1, hpro.getCategory());
					stmt.setString(2, hpro.getChange());
					stmt.setString(3, hpro.getDB());
					// stmt.setString(4, hpro.getDialog_Steps());
					stmt.setString(4, hpro.getInfo());
					stmt.setString(5, hpro.getJoin_Type());
					stmt.setString(6, hpro.getJoins());
					stmt.setString(7, hpro.getKeys());
					stmt.setLong(8, hpro.getLevels());
					stmt.setLong(9, hpro.getLine_Number());
					stmt.setString(10, hpro.getObj_Name());
					stmt.setString(11, hpro.getObject_Type());
					stmt.setString(12, hpro.getOdata());
					stmt.setString(13, hpro.getOpertaion());

					stmt.setString(14, hpro.getReadProgram());
					stmt.setString(15, hpro.getSub_Program());
					stmt.setString(16, hpro.getSub_Type());
					stmt.setString(17, hpro.getSubcategory());
					stmt.setString(18, hpro.getTable_Type());
					stmt.setString(19, hpro.getTables());
					stmt.setString(20, hpro.getUsed_Unused());
					stmt.setString(21, hpro.getWhere_Condition());
					stmt.setString(22, hpro.getAutomation_status());
					stmt.setString(23, hpro.getCode());
					stmt.setString(24, hpro.getHigh_lvl_desc());
					stmt.setString(25, hpro.getImpact());
					stmt.setLong(26, hpro.getJoinID());
					stmt.setString(27, hpro.getLoop());
					stmt.setString(28, hpro.getObjNameType());
					stmt.setString(29, hpro.getOperation_code());
					stmt.setLong(30, hpro.getRequestID());
					stmt.setString(31, hpro.getSel_Line());
					stmt.setString(32, hpro.getTotalLineScanned());
					stmt.setString(33, hpro.getOBJ_PACKAGE());
					stmt.setString(34, hpro.getCOMPLEXITY());

					stmt.setString(35, hpro.getSkipReason());
					stmt.setString(36, hpro.getIssueSecondSubCat());
					stmt.setString(37, hpro.getSkip());
					stmt.setString(38, hpro.getRicefCategory());
					stmt.setString(39, hpro.getExtNamespace());
					stmt.setString(40, hpro.getRicefSubCategory());
					stmt.setString(41, hpro.getCounter());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("Final batch executed successfully");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	public static String RefineImpactBatchInsertUpdate(List<HanaProfile> profilerlist, HttpSession session)
			throws SQLException {

		final String UPDATE_SQL = "UPDATE FINAL_OUTPUT set impact=? where Request_ID=?";
		/*
		 * String jdbcUrl = null,username = null,password = null;
		 * 
		 * String jdbcUrl = "jdbc:mysql://localhost:3306/hanadb1"; String username =
		 * "root"; String password = "root"; String result = "SUCCESS";
		 * java.sql.Connection conn= null;; String Filename=GetJdbcProperties(session);
		 * 
		 * try { jdbcUrl = HANAUtility.getPropertyValue(Filename, "jdbcUrl"); username
		 * =HANAUtility.getPropertyValue(Filename, "username"); password
		 * =HANAUtility.getPropertyValue(Filename, "password"); } catch (IOException e1)
		 * { // TODO Auto-generated catch block logger.error("Error !!! " + ex); }
		 */
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);

			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(UPDATE_SQL);
				int batch = 1;

				for (HanaProfile hpro : profilerlist) {
					stmt.setString(26, hpro.getImpact());
					stmt.setLong(31, hpro.getRequestID());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("Final batch executed successfully");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	public static String UserExitBatchInsertUpdate(List<UserExit> listOfUserExit, HttpSession session)
			throws SQLException {

		final String INSERT_SQL = "INSERT INTO USER_EXIT"
				+ "(OBJ_NAME, OBJ_NAME_TYPE, OBJ_TYPE, REQUEST_ID) values (?, ?, ?, ?) ";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);

			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (UserExit hpro : listOfUserExit) {
					stmt.setString(1, hpro.getObjName());
					stmt.setString(2, hpro.getObjNameType());
					stmt.setString(3, hpro.getObjType());
					stmt.setLong(4, hpro.getRequestID());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}
				stmt.executeBatch();
				conn.commit();
				logger.info("Final batch executed successfully");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	public static String InventoryListBatchInsertUpdate(List<S4InventoryList> inventoryList, HttpSession session)
			throws SQLException {
		// Inventory list batch insert
		final String INSERT_SQL = "INSERT INTO S4_Inventory_List"
				+ "(OBJ_NAME, OBJ_NAME_TYPE, OBJ_TYPE, Package, REQUEST_ID, Used, usageCount, "
				+ "Transport_Request, Standard_Modification, Ricef_Category, External_Namespace, Count_Lines, Ricef_Sub_Category, "
				+ "User_Group, ABAP_Query, CREATED_BY, CREATED_ON, CHANGED_BY, CHANGED_ON, TR, TR_STATUS) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);

			int counter = 1;
			conn.setAutoCommit(false);
			try {

				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (S4InventoryList hpro : inventoryList) {
					stmt.setString(1, hpro.getObjName());
					stmt.setString(2, hpro.getObjNameType());
					stmt.setString(3, hpro.getObjType());
					stmt.setString(4, hpro.getPckg());
					stmt.setLong(5, hpro.getRequestID());
					stmt.setString(6, hpro.getUsage());
					stmt.setString(7, hpro.getUsageCount());
					stmt.setString(8, hpro.getTransReq());
					stmt.setString(9, hpro.getStandardMod());
					stmt.setString(10, hpro.getRicefCategory());
					stmt.setString(11, hpro.getExtNamespace());
					stmt.setString(12, hpro.getCountLines());
					stmt.setString(13, hpro.getRicefSubCategory());
					stmt.setString(14, hpro.getUserGroup());
					stmt.setString(15, hpro.getABAPQuery());
					stmt.setString(16, hpro.getCreatedBy());
					stmt.setString(17, hpro.getCreatedOn());
					stmt.setString(18, hpro.getChangedBy());
					stmt.setString(19, hpro.getChangedOn());
					stmt.setString(20, hpro.getTr());
					stmt.setString(21, hpro.getTrStatus());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 500 records
					if (counter % 500 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}
				stmt.executeBatch();
				conn.commit();
				logger.info("Final batch executed successfully");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	private static Map<String, String> getSecondSubCat() throws SQLException {
		logger.info("Start  of getting Issue Second subCategory  ");
		Map<String, String> resultMap = new HashMap<>();
		final String SELECT_SQL = "SELECT Operation, Second_Sub_Cat FROM map_error_type";
		java.sql.Connection conn = null;
		java.sql.Statement stmt = null;
		ResultSet rs = null;
		try {
			conn = DBConfig.getJDBCConnection(session);
			conn.setAutoCommit(false);
			try {
				stmt = conn.createStatement();
				rs = stmt.executeQuery(SELECT_SQL);
				// STEP 5: Extract data from result set
				while (rs.next()) {
					resultMap.put(rs.getString("Operation"), rs.getString("Second_Sub_Cat"));
				}
				logger.info("Statement executed successfully");

			} finally {
				if (rs != null) {
					rs.close();
				}
				if (stmt != null) {
					stmt.close();
				}
			}
		} finally {
			if (conn != null) {
				conn.close();
			}
		}
		logger.info("End  of getting Issue Second subCategory  ");
		return resultMap;

	}

	/*
	 * public static String jDBCBatchS4InsertUpdate(List<S4HanaProfiler>
	 * s4HanaProfilerList ) throws SQLException {
	 * 
	 * final String INSERT_SQL = "INSERT INTO s4_final_output " +
	 * "(Category, CHANGE_COLUMN, DB, Dialog_Steps, Info, Join_Type, Joins, KEYS_COLUMN, Levels, Line_Number, Obj_Name, Object_Type, Odata, Opertaion, ReadProgram, Sub_Program, Sub_Type, Subcategory, Table_Type, TABLES_COLUMN, Used_Unused, Where_Condition, automation_status, code, high_lvl_desc, impact, JOIN_ID, LOOP_COLUMN, OBJ_NAME_TYPE, operation_code, Request_ID, SEL_LINE, total_line_scanned ,OBJ_PACKAGE) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)"
	 * ; String jdbcUrl = "jdbc:mysql://localhost:3306/hanadb1"; String username =
	 * "root"; String password = "root"; String result = "SUCCESS";
	 * java.sql.Connection conn= null; java.sql.PreparedStatement stmt= null; try {
	 * conn = DriverManager.getConnection(jdbcUrl, username, password);
	 * 
	 * int counter=1; conn.setAutoCommit(false); try { stmt =
	 * conn.prepareStatement(INSERT_SQL); int batch = 1;
	 * 
	 * for (HanaProfile hpro : listOfHanaProfile) { stmt.setString(1,
	 * hpro.getCategory()); stmt.setString(2, hpro.getChange()); stmt.setString(3,
	 * hpro.getDB()); stmt.setString(4, hpro.getDialog_Steps()); stmt.setString(5,
	 * hpro.getInfo()); stmt.setString(6, hpro.getJoin_Type()); stmt.setString(7,
	 * hpro.getJoins()); stmt.setString(8, hpro.getKeys()); stmt.setLong(9,
	 * hpro.getLevels()); stmt.setLong(10, hpro.getLine_Number());
	 * stmt.setString(11, hpro.getObj_Name()); stmt.setString(12,
	 * hpro.getObject_Type()); stmt.setString(13, hpro.getOdata());
	 * stmt.setString(14, hpro.getOpertaion());
	 * 
	 * stmt.setString(15, hpro.getReadProgram()); stmt.setString(16,
	 * hpro.getSub_Program()); stmt.setString(17, hpro.getSub_Type());
	 * stmt.setString(18, hpro.getSubcategory()); stmt.setString(19,
	 * hpro.getTable_Type()); stmt.setString(20, hpro.getTables());
	 * stmt.setString(21, hpro.getUsed_Unused()); stmt.setString(22,
	 * hpro.getWhere_Condition()); stmt.setString(23, hpro.getAutomation_status());
	 * stmt.setString(24, hpro.getCode()); stmt.setString(25,
	 * hpro.getHigh_lvl_desc()); stmt.setString(26, hpro.getImpact());
	 * stmt.setLong(27, hpro.getJoinID()); stmt.setString(28, hpro.getLoop());
	 * stmt.setString(29, hpro.getObjNameType()); stmt.setString(30,
	 * hpro.getOperation_code()); stmt.setLong(31, hpro.getRequestID());
	 * stmt.setLong(32, hpro.getSel_Line()); stmt.setString(33,
	 * hpro.getTotalLineScanned()); stmt.setString(34, hpro.getOBJ_PACKAGE()); //Add
	 * statement to batch stmt.addBatch(); counter++; //Execute batch of 1000
	 * records if(counter%1000==0){ counter=0; stmt.executeBatch(); conn.commit();
	 * System.out.println("Batch "+(batch++)+" executed successfully"); } }
	 * 
	 * stmt.executeBatch(); conn.commit();
	 * System.out.println("Final batch executed successfully");
	 * 
	 * }catch(Exception e) { result = "FAILURE in insert";
	 * System.out.println(e.getMessage()); } } catch(Exception e) { result =
	 * "FAILURE in Getting Connection"; System.out.println(e.getMessage());
	 * 
	 * } finally { stmt.close(); conn.close(); }
	 * 
	 * 
	 * return result;
	 * 
	 * }
	 */
	/*
	 * public java.sql.Connection getJDBCConnection() { String jdbcUrl =
	 * "jdbc:mysql://localhost:3306/hanadb1"; String username = "root"; String
	 * password = "root"; java.sql.Connection conn = null;
	 * 
	 */

	/*
	 * public static java.sql.Connection getJDBCConnection() { String jdbcUrl =
	 * null,username = null,password = null;
	 * 
	 * String Filename=GetJdbcProperties(getSession());
	 * 
	 * try { jdbcUrl = HANAUtility.getPropertyValue(Filename, "jdbcUrl"); username
	 * =HANAUtility.getPropertyValue(Filename, "username"); password
	 * =HANAUtility.getPropertyValue(Filename, "password"); } catch (IOException e1)
	 * { // TODO Auto-generated catch block logger.error("Error !!! " + e1); }
	 * java.sql.Connection conn = null; try { conn =
	 * DriverManager.getConnection(jdbcUrl, username, password);
	 * 
	 * } catch (SQLException e) {
	 * System.out.println("SQL Error occured while getting JDBC connection : " +
	 * e.getMessage()); logger.error("Error !!! " + e); } catch (Exception e) {
	 * logger.error("Error !!! " + e); } return conn; }
	 * 
	 * //This function return the file name to the corresponding Enviroment public
	 * static String GetJdbcProperties(HttpSession session) {
	 * 
	 * String FileName=null; String Enviroment=(String)
	 * session.getAttribute("Enviroment"); if
	 
	 * 
	 * return FileName; }
	 */

}
