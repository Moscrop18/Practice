package com.act.service;

import java.util.List;

import com.act.client.model.RequestInventory;

public interface RequestIDValidateService {
	String getCreator(RequestInventory requestInv);
	List<String> getPOCName(RequestInventory requestInv);
	RequestInventory getRequestInv(Long requestID);
}
