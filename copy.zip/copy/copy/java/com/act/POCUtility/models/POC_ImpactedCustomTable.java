package com.act.POCUtility.models;

public class POC_ImpactedCustomTable{

	private long requestId;
	private String object;
	private String desOfChange;
	private String packg;
	private String impactedFields;
	private String impactedDataEle;
	private String sapNotes;
	private String solStep;
	private String complexity;
	private String issueCategory;
	private String issueSubCategory;
	private String triggerObj;
	private String remediationCat;
	private String sapSimListChapter;
	private String appComponent;
	private String sapSimCategory;
	private String itemArea;
	
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getObject() {
		return object;
	}
	public void setObject(String object) {
		this.object = object;
	}
	public String getDesOfChange() {
		return desOfChange;
	}
	public void setDesOfChange(String desOfChange) {
		this.desOfChange = desOfChange;
	}
	public String getPackg() {
		return packg;
	}
	public void setPackg(String packg) {
		this.packg = packg;
	}
	public String getImpactedFields() {
		return impactedFields;
	}
	public void setImpactedFields(String impactedFields) {
		this.impactedFields = impactedFields;
	}
	public String getImpactedDataEle() {
		return impactedDataEle;
	}
	public void setImpactedDataEle(String impactedDataEle) {
		this.impactedDataEle = impactedDataEle;
	}
	public String getSapNotes() {
		return sapNotes;
	}
	public void setSapNotes(String sapNotes) {
		this.sapNotes = sapNotes;
	}
	public String getSolStep() {
		return solStep;
	}
	public void setSolStep(String solStep) {
		this.solStep = solStep;
	}
	public String getComplexity() {
		return complexity;
	}
	public void setComplexity(String complexity) {
		this.complexity = complexity;
	}
	public String getIssueCategory() {
		return issueCategory;
	}
	public void setIssueCategory(String issueCategory) {
		this.issueCategory = issueCategory;
	}
	public String getIssueSubCategory() {
		return issueSubCategory;
	}
	public void setIssueSubCategory(String issueSubCategory) {
		this.issueSubCategory = issueSubCategory;
	}
	public String getTriggerObj() {
		return triggerObj;
	}
	public void setTriggerObj(String triggerObj) {
		this.triggerObj = triggerObj;
	}
	public String getRemediationCat() {
		return remediationCat;
	}
	public void setRemediationCat(String remediationCat) {
		this.remediationCat = remediationCat;
	}
	public String getSapSimListChapter() {
		return sapSimListChapter;
	}
	public void setSapSimListChapter(String sapSimListChapter) {
		this.sapSimListChapter = sapSimListChapter;
	}
	public String getAppComponent() {
		return appComponent;
	}
	public void setAppComponent(String appComponent) {
		this.appComponent = appComponent;
	}
	public String getSapSimCategory() {
		return sapSimCategory;
	}
	public void setSapSimCategory(String sapSimCategory) {
		this.sapSimCategory = sapSimCategory;
	}
	public String getItemArea() {
		return itemArea;
	}
	public void setItemArea(String itemArea) {
		this.itemArea = itemArea;
	}
	
}