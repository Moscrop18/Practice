package com.act.POCUtility.models;

public class POC_AppendStructureAnalysis {
	
	private long requestId;
	private String tableName;
	private String fieldName;
	private String nameOfInclude;
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	public String getNameOfInclude() {
		return nameOfInclude;
	}
	public void setNameOfInclude(String nameOfInclude) {
		this.nameOfInclude = nameOfInclude;
	}
	
	
}
