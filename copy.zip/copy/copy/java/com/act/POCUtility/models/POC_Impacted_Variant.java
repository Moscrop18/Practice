package com.act.POCUtility.models;

public class POC_Impacted_Variant {
	private Long requestID;
	private String reportName;
	private String variantName;
	private String selScreenFieldName;
	private String kind;
	private String sign;
	private String low;
	private String high;
	private String variantOption;
	private String userName;
	private String variantType;
	private String comments;
	private String variantOperation;
	private String externalNamespace;
	
	public String getExternalNamespace() {
		return externalNamespace;
	}
	public void setExternalNamespace(String externalNamespace) {
		this.externalNamespace = externalNamespace;
	}
	public Long getRequestID() {
		return requestID;
	}
	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}
	
	public String getReportName() {
		return reportName;
	}
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}
	
	public String getVariantName() {
		return variantName;
	}
	public void setVariantName(String variantName) {
		this.variantName = variantName;
	}
	
	public String getSelScreenFieldName() {
		return selScreenFieldName;
	}
	public void setSelScreenFieldName(String selScreenFieldName) {
		this.selScreenFieldName = selScreenFieldName;
	}
	
	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}
	
	public String getSign() {
		return sign;
	}
	public void setSign(String sign) {
		this.sign = sign;
	}
	
	public String getLow() {
		return low;
	}
	public void setLow(String low) {
		this.low = low;
	}
	
	public String getHigh() {
		return high;
	}
	public void setHigh(String high) {
		this.high = high;
	}
	
	public String getVariantOption() {
		return variantOption;
	}
	public void setVariantOption(String variantOption) {
		this.variantOption = variantOption;
	}
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public String getVariantType() {
		return variantType;
	}
	public void setVariantType(String variantType) {
		this.variantType = variantType;
	}
	
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	public String getVariantOperation() {
		return variantOperation;
	}
	public void setVariantOperation(String variantOperation) {
		this.variantOperation = variantOperation;
	}
}
