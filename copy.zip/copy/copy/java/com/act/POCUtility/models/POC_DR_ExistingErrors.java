package com.act.POCUtility.models;

public class POC_DR_ExistingErrors {

	private long requestId;
	private String objType;
	private String objName;
	private String subObjName;
	private String readProgram;
	private String pkg;//package
	private Integer lineNo;
	private String descOfChange;
	private String automationStatus;
	private String opCode;
	private String used;
	private String objectNameType;
	private String externalNamespace;
	private String ricefwCategory;
	private String ricefwSubCategory;
	
	
	
	public String getRicefwCategory() {
		return ricefwCategory;
	}
	public void setRicefwCategory(String ricefwCategory) {
		this.ricefwCategory = ricefwCategory;
	}
	public String getRicefwSubCategory() {
		return ricefwSubCategory;
	}
	public void setRicefwSubCategory(String ricefwSubCategory) {
		this.ricefwSubCategory = ricefwSubCategory;
	}
	public String getExternalNamespace() {
		return externalNamespace;
	}
	public void setExternalNamespace(String externalNamespace) {
		this.externalNamespace = externalNamespace;
	}
	
	public String getObjectNameType() {
		return objectNameType;
	}
	public void setObjectNameType(String objectNameType) {
		this.objectNameType = objectNameType;
	}
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getObjType() {
		return objType;
	}
	public void setObjType(String objType) {
		this.objType = objType;
	}
	public String getObjName() {
		return objName;
	}
	public void setObjName(String objName) {
		this.objName = objName;
	}
	public String getSubObjName() {
		return subObjName;
	}
	public void setSubObjName(String subObjName) {
		this.subObjName = subObjName;
	}
	public String getReadProgram() {
		return readProgram;
	}
	public void setReadProgram(String readProgram) {
		this.readProgram = readProgram;
	}
	public String getPkg() {
		return pkg;
	}
	public void setPkg(String pkg) {
		this.pkg = pkg;
	}
	public Integer getLineNo() {
		return lineNo;
	}
	public void setLineNo(Integer lineNo) {
		this.lineNo = lineNo;
	}
	public String getDescOfChange() {
		return descOfChange;
	}
	public void setDescOfChange(String descOfChange) {
		this.descOfChange = descOfChange;
	}
	public String getAutomationStatus() {
		return automationStatus;
	}
	public void setAutomationStatus(String automationStatus) {
		this.automationStatus = automationStatus;
	}
	public String getOpCode() {
		return opCode;
	}
	public void setOpCode(String opCode) {
		this.opCode = opCode;
	}
	public String getUsed() {
		return used;
	}
	public void setUsed(String used) {
		this.used = used;
	}
}
