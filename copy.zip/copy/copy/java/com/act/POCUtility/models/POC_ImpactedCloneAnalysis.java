package com.act.POCUtility.models;

public class POC_ImpactedCloneAnalysis{

	
	private long requestId;
	private String namespace;
	private String objType;
	private String objName;
	private String objTypeName;
	private String objPackage;
	private String year;
	private String creationDate;
	private String interfaceConcat;
	private String interfaceObjType;
	private String interfaceObj;
	private String reference;
	private String referencePercent;
	private String appComponent;
	private String used;
	private String impactedDB;
	private String impactedSimpl;
	private String impactedExistingError;
	private String impactedOSMigration;
	private String externalNamespace;
	public String getExternalNamespace() {
		return externalNamespace;
	}
	public void setExternalNamespace(String externalNamespace) {
		this.externalNamespace = externalNamespace;
	}
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getNamespace() {
		return namespace;
	}
	public void setNamespace(String namespace) {
		this.namespace = namespace;
	}
	public String getObjType() {
		return objType;
	}
	public void setObjType(String objType) {
		this.objType = objType;
	}
	public String getObjName() {
		return objName;
	}
	public void setObjName(String objName) {
		this.objName = objName;
	}
	public String getObjTypeName() {
		return objTypeName;
	}
	public void setObjTypeName(String objTypeName) {
		this.objTypeName = objTypeName;
	}
	public String getObjPackage() {
		return objPackage;
	}
	public void setObjPackage(String objPackage) {
		this.objPackage = objPackage;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}
	public String getInterfaceConcat() {
		return interfaceConcat;
	}
	public void setInterfaceConcat(String interfaceConcat) {
		this.interfaceConcat = interfaceConcat;
	}
	public String getInterfaceObjType() {
		return interfaceObjType;
	}
	public void setInterfaceObjType(String interfaceObjType) {
		this.interfaceObjType = interfaceObjType;
	}
	public String getInterfaceObj() {
		return interfaceObj;
	}
	public void setInterfaceObj(String interfaceObj) {
		this.interfaceObj = interfaceObj;
	}
	public String getReference() {
		return reference;
	}
	public void setReference(String reference) {
		this.reference = reference;
	}
	public String getReferencePercent() {
		return referencePercent;
	}
	public void setReferencePercent(String referencePercent) {
		this.referencePercent = referencePercent;
	}
	public String getAppComponent() {
		return appComponent;
	}
	public void setAppComponent(String appComponent) {
		this.appComponent = appComponent;
	}
	public String getUsed() {
		return used;
	}
	public void setUsed(String used) {
		this.used = used;
	}
	public String getImpactedDB() {
		return impactedDB;
	}
	public void setImpactedDB(String impactedDB) {
		this.impactedDB = impactedDB;
	}
	public String getImpactedSimpl() {
		return impactedSimpl;
	}
	public void setImpactedSimpl(String impactedSimpl) {
		this.impactedSimpl = impactedSimpl;
	}
	public String getImpactedExistingError() {
		return impactedExistingError;
	}
	public void setImpactedExistingError(String impactedExistingError) {
		this.impactedExistingError = impactedExistingError;
	}
	public String getImpactedOSMigration() {
		return impactedOSMigration;
	}
	public void setImpactedOSMigration(String impactedOSMigration) {
		this.impactedOSMigration = impactedOSMigration;
	}



	
}