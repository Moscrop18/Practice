package com.act.POCUtility.models;

public class POC_AffectedByCustomFields {
	
	private long requestId;
	private String objectType;
	private String objectName;
	private String triggerObject;
	private String replacedByCDS;
	
	
	public String getReplacedByCDS() {
		return replacedByCDS;
	}
	public void setReplacedByCDS(String replacedByCDS) {
		this.replacedByCDS = replacedByCDS;
	}
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getObjectType() {
		return objectType;
	}
	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}
	public String getObjectName() {
		return objectName;
	}
	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}
	
	public String getTriggerObject() {
		return triggerObject;
	}
	public void setTriggerObject(String triggerObject) {
		this.triggerObject = triggerObject;
	}
	
	
}
