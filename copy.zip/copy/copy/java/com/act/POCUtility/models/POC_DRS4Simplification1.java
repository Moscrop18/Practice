package com.act.POCUtility.models;

public class POC_DRS4Simplification1 {

	private long requestId;
	private String objType;
	private String objName;
	private String subObjName;
	private String readProgram;
	private String pkg;//package
	private String operation; 
	private int lineNo;
	private String statement;
	private String impactedObj;
	private String impactReason;
	private String descOfChange;
	private String SAPNote;
	private String solutionStep;
	private String complexity;
	private String impact;
	private String issueCategory;
	private String issueSubCategory;
	private String triggerObject;
	private String remediationCategory;
	private String SAPSimpliListChapter;
	private String appComponent;
	private String SAPSimpliCategory;
	private String itemArea;
	private String used;
	private String objectNameType;
	private String selLine;
	private String corProgName;
	private String corLineNo;
	private String externalNamespace;
	private String ricefwCategory;
	private String ricefwSubCategory;
	private String automationStatus;
	public String getAutomationStatus() {
		return automationStatus;
	}
	public void setAutomationStatus(String automationStatus) {
		this.automationStatus = automationStatus;
	}
	public String getToolVersion() {
		return toolVersion;
	}
	public void setToolVersion(String toolVersion) {
		this.toolVersion = toolVersion;
	}
	private String toolVersion;
	
	
	public String getRicefwCategory() {
		return ricefwCategory;
	}
	public void setRicefwCategory(String ricefwCategory) {
		this.ricefwCategory = ricefwCategory;
	}
	public String getRicefwSubCategory() {
		return ricefwSubCategory;
	}
	public void setRicefwSubCategory(String ricefwSubCategory) {
		this.ricefwSubCategory = ricefwSubCategory;
	}

	public String getExternalNamespace() {
		return externalNamespace;
	}
	public void setExternalNamespace(String externalNamespace) {
		this.externalNamespace = externalNamespace;
	}
	
	public String getSelLine() {
		return selLine;
	}
	public void setSelLine(String selLine) {
		this.selLine = selLine;
	}
	public String getObjectNameType() {
		return objectNameType;
	}
	public void setObjectNameType(String objectNameType) {
		this.objectNameType = objectNameType;
	}
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getObjType() {
		return objType;
	}
	public void setObjType(String objType) {
		this.objType = objType;
	}
	public String getObjName() {
		return objName;
	}
	public void setObjName(String objName) {
		this.objName = objName;
	}
	public String getSubObjName() {
		return subObjName;
	}
	public void setSubObjName(String subObjName) {
		this.subObjName = subObjName;
	}
	public String getReadProgram() {
		return readProgram;
	}
	public void setReadProgram(String readProgram) {
		this.readProgram = readProgram;
	}
	public String getPkg() {
		return pkg;
	}
	public void setPkg(String pkg) {
		this.pkg = pkg;
	}
	public String getOperation() {
		return operation;
	}
	public void setOperation(String operation) {
		this.operation = operation;
	}
	public int getLineNo() {
		return lineNo;
	}
	public void setLineNo(int lineNo) {
		this.lineNo = lineNo;
	}
	public String getStatement() {
		return statement;
	}
	public void setStatement(String statement) {
		this.statement = statement;
	}
	
	public String getImpactedObj() {
		return impactedObj;
	}
	public void setImpactedObj(String impactedObj) {
		this.impactedObj = impactedObj;
	}
	public String getImpactReason() {
		return impactReason;
	}
	public void setImpactReason(String impactReason) {
		this.impactReason = impactReason;
	}
	public String getDescOfChange() {
		return descOfChange;
	}
	public void setDescOfChange(String descOfChange) {
		this.descOfChange = descOfChange;
	}
	public String getSAPNote() {
		return SAPNote;
	}
	public void setSAPNote(String sAPNote) {
		SAPNote = sAPNote;
	}
	public String getSolutionStep() {
		return solutionStep;
	}
	public void setSolutionStep(String solutionStep) {
		this.solutionStep = solutionStep;
	}
	public String getComplexity() {
		return complexity;
	}
	public void setComplexity(String complexity) {
		this.complexity = complexity;
	}
	public String getImpact() {
		return impact;
	}
	public void setImpact(String impact) {
		this.impact = impact;
	}
	public String getIssueCategory() {
		return issueCategory;
	}
	public void setIssueCategory(String issueCategory) {
		this.issueCategory = issueCategory;
	}
	public String getIssueSubCategory() {
		return issueSubCategory;
	}
	public void setIssueSubCategory(String issueSubCategory) {
		this.issueSubCategory = issueSubCategory;
	}
	public String getTriggerObject() {
		return triggerObject;
	}
	public void setTriggerObject(String triggerObject) {
		this.triggerObject = triggerObject;
	}
	public String getRemediationCategory() {
		return remediationCategory;
	}
	public void setRemediationCategory(String remediationCategory) {
		this.remediationCategory = remediationCategory;
	}
	public String getSAPSimpliListChapter() {
		return SAPSimpliListChapter;
	}
	public void setSAPSimpliListChapter(String sAPSimpliListChapter) {
		SAPSimpliListChapter = sAPSimpliListChapter;
	}
	public String getAppComponent() {
		return appComponent;
	}
	public void setAppComponent(String appComponent) {
		this.appComponent = appComponent;
	}
	public String getSAPSimpliCategory() {
		return SAPSimpliCategory;
	}
	public void setSAPSimpliCategory(String sAPSimpliCategory) {
		SAPSimpliCategory = sAPSimpliCategory;
	}
	public String getItemArea() {
		return itemArea;
	}
	public void setItemArea(String itemArea) {
		this.itemArea = itemArea;
	}
	public String getUsed() {
		return used;
	}
	public void setUsed(String used) {
		this.used = used;
	}
	public String getCorProgName() {
		return corProgName;
	}
	public void setCorProgName(String corProgName) {
		this.corProgName = corProgName;
	}
	public String getCorLineNo() {
		return corLineNo;
	}
	public void setCorLineNo(String corLineNo) {
		this.corLineNo = corLineNo;
	}
}
