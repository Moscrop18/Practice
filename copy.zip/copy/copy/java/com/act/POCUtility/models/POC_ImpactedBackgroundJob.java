package com.act.POCUtility.models;

public class POC_ImpactedBackgroundJob{

	private long requestId;
	private String object;
	private String backgroundJobName;
	private String programName;
	private String variant;
	private String tcode;
	private String run;
	private String externalNamespace;
	public String getExternalNamespace() {
		return externalNamespace;
	}
	public void setExternalNamespace(String externalNamespace) {
		this.externalNamespace = externalNamespace;
	}
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getObject() {
		return object;
	}
	public void setObject(String object) {
		this.object = object;
	}
	public String getBackgroundJobName() {
		return backgroundJobName;
	}
	public void setBackgroundJobName(String backgroundJobName) {
		this.backgroundJobName = backgroundJobName;
	}
	public String getProgramName() {
		return programName;
	}
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	public String getVariant() {
		return variant;
	}
	public void setVariant(String variant) {
		this.variant = variant;
	}
	public String getTcode() {
		return tcode;
	}
	public void setTcode(String tcode) {
		this.tcode = tcode;
	}
	public String getRun() {
		return run;
	}
	public void setRun(String run) {
		this.run = run;
	}
	
	
}