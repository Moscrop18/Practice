package com.act.POCUtility.models;

public class POC_ImpactedObjectList {

	private long requestId;
	private String objectType;
	private String objectName;
	private String used;
	private String errorsInExistingSystem;
	private String dbImpact;
	private String s4Simplification;
	private String odata;
	private String osMigration;
	private String usageCount;
	private String externalNamespace;
	private String ricefwCategory;
	private String ricefwSubCategory;
	private String impactMod;
	
	
	public String getRicefwCategory() {
		return ricefwCategory;
	}
	public void setRicefwCategory(String ricefwCategory) {
		this.ricefwCategory = ricefwCategory;
	}
	public String getRicefwSubCategory() {
		return ricefwSubCategory;
	}
	public void setRicefwSubCategory(String ricefwSubCategory) {
		this.ricefwSubCategory = ricefwSubCategory;
	}
	public String getImpactMod() {
		return impactMod;
	}
	public void setImpactMod(String impactMod) {
		this.impactMod = impactMod;
	}
	public String getExternalNamespace() {
		return externalNamespace;
	}
	public void setExternalNamespace(String externalNamespace) {
		this.externalNamespace = externalNamespace;
	}
	
	public String getUsageCount() {
		return usageCount;
	}
	public void setUsageCount(String usageCount) {
		this.usageCount = usageCount;
	}
	public String getOsMigration() {
		return osMigration;
	}
	public void setOsMigration(String osMigration) {
		this.osMigration = osMigration;
	}
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getObjectType() {
		return objectType;
	}
	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}
	public String getObjectName() {
		return objectName;
	}
	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}
	public String getUsed() {
		return used;
	}
	public void setUsed(String used) {
		this.used = used;
	}
	public String getErrorsInExistingSystem() {
		return errorsInExistingSystem;
	}
	public void setErrorsInExistingSystem(String errorsInExistingSystem) {
		this.errorsInExistingSystem = errorsInExistingSystem;
	}
	public String getDbImpact() {
		return dbImpact;
	}
	public void setDbImpact(String dbImpact) {
		this.dbImpact = dbImpact;
	}
	public String getS4Simplification() {
		return s4Simplification;
	}
	public void setS4Simplification(String s4Simplification) {
		this.s4Simplification = s4Simplification;
	}
	public String getOdata() {
		return odata;
	}
	public void setOdata(String odata) {
		this.odata = odata;
	}
}
