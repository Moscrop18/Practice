package com.act.POCUtility.models;

public class POC_Ui5HighLevelReport{

	private long requestId;
	private String projectName;
	private String totalApiCounts;
	private String depricatedApiCounts;
	private String nonValidApiCounts;
	private String recommendedChangesApiCounts;
	private String finalMessage;
	
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getTotalApiCounts() {
		return totalApiCounts;
	}
	public void setTotalApiCounts(String totalApiCounts) {
		this.totalApiCounts = totalApiCounts;
	}
	public String getDepricatedApiCounts() {
		return depricatedApiCounts;
	}
	public void setDepricatedApiCounts(String depricatedApiCounts) {
		this.depricatedApiCounts = depricatedApiCounts;
	}
	public String getNonValidApiCounts() {
		return nonValidApiCounts;
	}
	public void setNonValidApiCounts(String nonValidApiCounts) {
		this.nonValidApiCounts = nonValidApiCounts;
	}
	public String getRecommendedChangesApiCounts() {
		return recommendedChangesApiCounts;
	}
	public void setRecommendedChangesApiCounts(String recommendedChangesApiCounts) {
		this.recommendedChangesApiCounts = recommendedChangesApiCounts;
	}
	public String getFinalMessage() {
		return finalMessage;
	}
	public void setFinalMessage(String finalMessage) {
		this.finalMessage = finalMessage;
	}
		
}