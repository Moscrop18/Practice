package com.act.POCUtility.models;

import javax.persistence.Column;

public class POC_FioriOutput {
	private String tCode;
	private String appId;
	private String appType;
	private String comments;
	private String appName;
	private String score;
	private long requestId;
	private String applicationComponent;
	private String applicationComponentText;
	
	public String getApplicationComponent() {
		return applicationComponent;
	}
	public void setApplicationComponent(String applicationComponent) {
		this.applicationComponent = applicationComponent;
	}
	public String getApplicationComponentText() {
		return applicationComponentText;
	}
	public void setApplicationComponentText(String applicationComponentText) {
		this.applicationComponentText = applicationComponentText;
	}
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String gettCode() {
		return tCode;
	}
	public void settCode(String tCode) {
		this.tCode = tCode;
	}
	public String getAppId() {
		return appId;
	}
	public void setAppId(String appId) {
		this.appId = appId;
	}
	public String getAppType() {
		return appType;
	}
	public void setAppType(String appType) {
		this.appType = appType;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getScore() {
		return score;
	}
	public void setScore(String score) {
		this.score = score;
	}
	

}
