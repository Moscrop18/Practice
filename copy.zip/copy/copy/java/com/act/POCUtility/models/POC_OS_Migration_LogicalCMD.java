package com.act.POCUtility.models;

public class POC_OS_Migration_LogicalCMD {
	
	private Long requestID;
	private String objType;
	public String getObjType() {
		return objType;
	}
	public void setObjType(String objType) {
		this.objType = objType;
	}
	private String readProgram;
	private String statement;
	private String remCategory;
	private String issueCategory;
	private String issueSubcategory;
	private String info;
	private String highLvlDesc;
	private String automationStatus;
	private String complexity;
	private String impact;
	
	public Long getRequestID() {
		return requestID;
	}
	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}
	public String getReadProgram() {
		return readProgram;
	}
	public void setReadProgram(String readProgram) {
		this.readProgram = readProgram;
	}
	public String getStatement() {
		return statement;
	}
	public void setStatement(String statement) {
		this.statement = statement;
	}
	public String getRemCategory() {
		return remCategory;
	}
	public void setRemCategory(String remCategory) {
		this.remCategory = remCategory;
	}
	public String getIssueCategory() {
		return issueCategory;
	}
	public void setIssueCategory(String issueCategory) {
		this.issueCategory = issueCategory;
	}
	public String getIssueSubcategory() {
		return issueSubcategory;
	}
	public void setIssueSubcategory(String issueSubcategory) {
		this.issueSubcategory = issueSubcategory;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	public String getHighLvlDesc() {
		return highLvlDesc;
	}
	public void setHighLvlDesc(String highLvlDesc) {
		this.highLvlDesc = highLvlDesc;
	}
	public String getAutomationStatus() {
		return automationStatus;
	}
	public void setAutomationStatus(String automationStatus) {
		this.automationStatus = automationStatus;
	}
	public String getComplexity() {
		return complexity;
	}
	public void setComplexity(String complexity) {
		this.complexity = complexity;
	}
	public String getImpact() {
		return impact;
	}
	public void setImpact(String impact) {
		this.impact = impact;
	}

}
