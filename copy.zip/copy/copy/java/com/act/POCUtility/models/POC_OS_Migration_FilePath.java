package com.act.POCUtility.models;

public class POC_OS_Migration_FilePath {
	
	private Long requestID;
	private String objName;
	private String subType;
	private String statement;
	private String info;
	private String impact;
	private String remCategory;
	private String skip;
	private String skipReason;
	private String highLvlDesc;
	public Long getRequestID() {
		return requestID;
	}
	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}
	public String getObjName() {
		return objName;
	}
	public void setObjName(String objName) {
		this.objName = objName;
	}
	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
	}
	public String getStatement() {
		return statement;
	}
	public void setStatement(String statement) {
		this.statement = statement;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	public String getImpact() {
		return impact;
	}
	public void setImpact(String impact) {
		this.impact = impact;
	}
	public String getRemCategory() {
		return remCategory;
	}
	public void setRemCategory(String remCategory) {
		this.remCategory = remCategory;
	}
	public String getSkip() {
		return skip;
	}
	public void setSkip(String skip) {
		this.skip = skip;
	}
	public String getSkipReason() {
		return skipReason;
	}
	public void setSkipReason(String skipReason) {
		this.skipReason = skipReason;
	}
	public String getHighLvlDesc() {
		return highLvlDesc;
	}
	public void setHighLvlDesc(String highLvlDesc) {
		this.highLvlDesc = highLvlDesc;
	}

	

}
