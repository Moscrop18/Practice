package com.act.POCUtility.models;

import javax.persistence.Column;

public class POC_BWInventory {

	private String objName;
	private String objType;
	private String used;
	private String usageCount;	
	private long requestId;
	private String profilerUsed;
	private String transReq;
	
	public String getUsageCount() {
		return usageCount;
	}
	public void setUsageCount(String usageCount) {
		this.usageCount = usageCount;
	}
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getObjName() {
		return objName;
	}
	public void setObjName(String objName) {
		this.objName = objName;
	}
	public String getObjType() {
		return objType;
	}
	public void setObjType(String objType) {
		this.objType = objType;
	}
	public String getUsed() {
		return used;
	}
	public void setUsed(String used) {
		this.used = used;
	}
	public String getProfilerUsed() {
		return profilerUsed;
	}
	public void setProfilerUsed(String profilerUsed) {
		this.profilerUsed = profilerUsed;
	}
	public String getTransReq() {
		return transReq;
	}
	public void setTransReq(String transReq) {
		this.transReq = transReq;
	} 
}
