package com.act.POCUtility.models;


public class POC_ImpactedSAPScript {

	private long requestId;
	private String program;
	private String impactedSapScript;
	private String remediationCategory;
	private String dbImpact;
	private String s4Simplification;
	private String existingError;
	private String objType;
	private String objNameType;
	private String opCode; 
	private String externalNamespace; 

	
	
	public String getExternalNamespace() {
		return externalNamespace;
	}
	public void setExternalNamespace(String externalNamespace) {
		this.externalNamespace = externalNamespace;
	}
	public String getObjType() {
		return objType;
	}
	public void setObjType(String objType) {
		this.objType = objType;
	}
	public String getObjNameType() {
		return objNameType;
	}
	public void setObjNameType(String objNameType) {
		this.objNameType = objNameType;
	}
	public String getOpCode() {
		return opCode;
	}
	public void setOpCode(String opCode) {
		this.opCode = opCode;
	}
	public String getProgram() {
		return program;
	}
	public void setProgram(String program) {
		this.program = program;
	}
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getImpactedSapScript() {
		return impactedSapScript;
	}
	public void setImpactedSapScript(String impactedSapScript) {
		this.impactedSapScript = impactedSapScript;
	}
	public String getRemediationCategory() {
		return remediationCategory;
	}
	public void setRemediationCategory(String remediationCategory) {
		this.remediationCategory = remediationCategory;
	}
	public String getDbImpact() {
		return dbImpact;
	}
	public void setDbImpact(String dbImpact) {
		this.dbImpact = dbImpact;
	}
	public String getS4Simplification() {
		return s4Simplification;
	}
	public void setS4Simplification(String s4Simplification) {
		this.s4Simplification = s4Simplification;
	}
	public String getExistingError() {
		return existingError;
	}
	public void setExistingError(String existingError) {
		this.existingError = existingError;
	}

	
	
}
