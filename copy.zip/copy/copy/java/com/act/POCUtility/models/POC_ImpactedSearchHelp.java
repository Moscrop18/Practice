package com.act.POCUtility.models;

public class POC_ImpactedSearchHelp{

	private long requestId;
	private String objectType;
	private String customTable;
	private String impactedSearchHelp;
	private String externalNamespace;

	
	public String getExternalNamespace() {
		return externalNamespace;
	}
	public void setExternalNamespace(String externalNamespace) {
		this.externalNamespace = externalNamespace;
	}
	//Delete searchData once TR is released from ABAP end
	private String searchData;
	
	public String getSearchData() {
		return searchData;
	}
	public void setSearchData(String searchData) {
		this.searchData = searchData;
	}
	
	
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getObjectType() {
		return objectType;
	}
	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}
	public String getCustomTable() {
		return customTable;
	}
	public void setCustomTable(String customTable) {
		this.customTable = customTable;
	}
	public String getImpactedSearchHelp() {
		return impactedSearchHelp;
	}
	public void setImpactedSearchHelp(String impactedSearchHelp) {
		this.impactedSearchHelp = impactedSearchHelp;
	}
	
}