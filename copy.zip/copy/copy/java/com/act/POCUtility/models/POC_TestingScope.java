package com.act.POCUtility.models;

public class POC_TestingScope{

	private long requestId;
	private String object;
	private String objName;
	private String objectObjName;
	private String opercd;
	private String applicationComponent;
	private String appCompDesc;
	private String role;
	private String process;
	private String transactions;
	
	public String getAppCompDesc() {
		return appCompDesc;
	}
	public void setAppCompDesc(String appCompDesc) {
		this.appCompDesc = appCompDesc;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getTransactions() {
		return transactions;
	}
	public void setTransactions(String transactions) {
		this.transactions = transactions;
	}
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getObject() {
		return object;
	}
	public void setObject(String object) {
		this.object = object;
	}
	public String getObjName() {
		return objName;
	}
	public void setObjName(String objName) {
		this.objName = objName;
	}
	public String getObjectObjName() {
		return objectObjName;
	}
	public void setObjectObjName(String objectObjName) {
		this.objectObjName = objectObjName;
	}
	public String getOpercd() {
		return opercd;
	}
	public void setOpercd(String opercd) {
		this.opercd = opercd;
	}
	public String getApplicationComponent() {
		return applicationComponent;
	}
	public void setApplicationComponent(String applicationComponent) {
		this.applicationComponent = applicationComponent;
	}
	public String getProcess() {
		return process;
	}
	public void setProcess(String process) {
		this.process = process;
	}
}