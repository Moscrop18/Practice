package com.act.POCUtility.models;

public class POC_ImpactedStandardTransaction{

	private long requestId;
	private String impactedTransaction;
	private String description;
	private String noteNo;
	private String solutionStep;
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getImpactedTransaction() {
		return impactedTransaction;
	}
	public void setImpactedTransaction(String impactedTransaction) {
		this.impactedTransaction = impactedTransaction;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getNoteNo() {
		return noteNo;
	}
	public void setNoteNo(String noteNo) {
		this.noteNo = noteNo;
	}
	public String getSolutionStep() {
		return solutionStep;
	}
	public void setSolutionStep(String solutionStep) {
		this.solutionStep = solutionStep;
	}
	
	
}