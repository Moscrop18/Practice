package com.act.POCUtility.models;

public class POC_NonUnicodeObjects {
	private Long requestID;
	private String objType;
	private String prog;
	private String include;
	private String externalNamespace;
	public String getExternalNamespace() {
		return externalNamespace;
	}
	public void setExternalNamespace(String externalNamespace) {
		this.externalNamespace = externalNamespace;
	}
	public String getInclude() {
		return include;
	}
	public void setInclude(String include) {
		this.include = include;
	}
	private String roww;
	private String errCode;
	private String msg;
	private String pkg;
	private String appComp;
	private String used;
	
	public String getObjType() {
		return objType;
	}
	public void setObjType(String objType) {
		this.objType = objType;
	}
	
	public Long getRequestID() {
		return requestID;
	}
	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}
	
	public String getProg() {
		return prog;
	}
	public void setProg(String prog) {
		this.prog = prog;
	}
	public String getRoww() {
		return roww;
	}
	public void setRoww(String roww) {
		this.roww = roww;
	}
	public String getErrCode() {
		return errCode;
	}
	public void setErrCode(String errCode) {
		this.errCode = errCode;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	public String getPkg() {
		return pkg;
	}
	public void setPkg(String pkg) {
		this.pkg = pkg;
	}
	
	public String getAppComp() {
		return appComp;
	}
	public void setAppComp(String appComp) {
		this.appComp = appComp;
	}
	public String getUsed() {
		return used;
	}
	public void setUsed(String used) {
		this.used = used;
	}
}
