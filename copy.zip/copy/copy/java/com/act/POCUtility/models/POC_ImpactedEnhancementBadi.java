package com.act.POCUtility.models;

public class POC_ImpactedEnhancementBadi{

	private long requestId;
	private String enhancementType;
	private String className;
	private String enhancemnetName;
	private String implementationName;
	
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	public String getEnhancementType() {
		return enhancementType;
	}
	public void setEnhancementType(String enhancementType) {
		this.enhancementType = enhancementType;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getEnhancemnetName() {
		return enhancemnetName;
	}
	public void setEnhancemnetName(String enhancemnetName) {
		this.enhancemnetName = enhancemnetName;
	}
	public String getImplementationName() {
		return implementationName;
	}
	public void setImplementationName(String implementationName) {
		this.implementationName = implementationName;
	}
	
}