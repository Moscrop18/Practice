package com.act.Aadt.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Impacted_Variant_Download")
public class ImpactedVariant_Download {
	
	private Integer id;
	private Long requestID;
	private String reportName;
	private String variantName;
	private String selScreenFieldName;
	private String kind;
	private String sign;
	private String low;
	private String high;
	private String variantOption;
	private String userName;
	private String variantType;
	private String comments;
	private String variantOperation;
	private String externalNamespace ;

	@Id	
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "ID")
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	@Column(name = "EXTERNAL_NAMESPACE")
	public String getExternalNamespace() {
		return externalNamespace;
	}
	public void setExternalNamespace(String externalNamespace) {
		this.externalNamespace = externalNamespace;
	}
	
	@Column(name = "Request_ID")
	public Long getRequestID() {
		return requestID;
	}
	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}
	
	@Column(name = "Report_Name")
	public String getReportName() {
		return reportName;
	}
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}
	
	@Column(name = "Variant_Name")
	public String getVariantName() {
		return variantName;
	}
	public void setVariantName(String variantName) {
		this.variantName = variantName;
	}
	
	@Column(name = "Selection_Screen_Field_Name")
	public String getSelScreenFieldName() {
		return selScreenFieldName;
	}
	public void setSelScreenFieldName(String selScreenFieldName) {
		this.selScreenFieldName = selScreenFieldName;
	}
	
	@Column(name = "Kind")
	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}
	
	@Column(name = "Sign")
	public String getSign() {
		return sign;
	}
	public void setSign(String sign) {
		this.sign = sign;
	}
	
	@Column(name = "Low")
	public String getLow() {
		return low;
	}
	public void setLow(String low) {
		this.low = low;
	}
	
	@Column(name = "High")
	public String getHigh() {
		return high;
	}
	public void setHigh(String high) {
		this.high = high;
	}
	
	@Column(name = "Variant_Option")
	public String getVariantOption() {
		return variantOption;
	}
	public void setVariantOption(String variantOption) {
		this.variantOption = variantOption;
	}
	
	@Column(name = "User_Name")
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	@Column(name = "Variant_Type")
	public String getVariantType() {
		return variantType;
	}
	public void setVariantType(String variantType) {
		this.variantType = variantType;
	}
	
	@Column(name = "Comments")
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	@Column(name = "Variant_Operation")
	public String getVariantOperation() {
		return variantOperation;
	}
	public void setVariantOperation(String variantOperation) {
		this.variantOperation = variantOperation;
	}
}
