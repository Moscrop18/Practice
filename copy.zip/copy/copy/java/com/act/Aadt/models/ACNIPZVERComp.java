package com.act.Aadt.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ACNIP_ZVER_COMP")
public class ACNIPZVERComp {
	
	@Id	
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "ID")
	private Integer Id;
	
	@Column(name = "REQUEST_ID")
	private Long requestID;

	@Column(name = "MANDT")
	private String mandt;
	
	@Column(name="SESSION_ID") 
	private String sessionId;
	
	@Column(name = "SERIAL_NO")
	private String serialNo;
	
	@Column(name = "NAMESPACE")
	private String namespace;
	
	@Column(name = "OBJECT_R3TR")
	private String objectR3TR;
	
	@Column(name = "OBJ_NAME_R3TR")
	private String objNameR3TR;
	
	@Column(name = "OBJECT")
	private String object;
	
	@Column(name = "OBJ_NAME") 
	private String objName;
	
	@Column(name = "CREATE_DATE")
	private String createDate;

	@Column(name = "CHANGE_DATE")
	private String changeDate;
	
	@Column(name = "DEVCLASS")
	private String devClass;
	
	@Column(name = "CODE_SIZE")
	private String codeSize;
	
	@Column(name = "VERSION_COUNT")
	private String versionCount;
	
	@Column(name = "REF_INFOSAP")
	private String refInfosap;
	
	@Column(name = "REF_TYPE_TEXTSAP")
	private String refTypeTextsap;
	
	@Column(name = "LAST_TRANSPORT")
	private String lastTransport;
	
	@Column(name = "LAST_TRANSPORT_RFC")
	private String lastTransportRfc;
	
	@Column(name = "OBJECT1")
	private String object1;
	
	@Column(name = "OBJ_NAME1")
	private String objName1;
	
	@Column(name = "LENGTH1")
	private String length1;
	
	@Column(name = "CNT_VERS1")
	private String cntVers1;
	
	@Column(name = "ICON_COMP")
	private String iconComp;
	
	@Column(name = "OBJECT2")
	private String object2;
	
	@Column(name = "OBJ_NAME2")
	private String objName2;
	
	@Column(name = "LENGTH2")
	private String length2;
	
	@Column(name = "CNT_VERS2")
	private String cntVers2;
	
	@Column(name = "RFCDEST2")
	private String rfcDest2;
	
	@Column(name = "RECORD_DATE")
	private String recordDate;
	
	@Column(name = "RECORD_TIME")
	private String recordTime;

	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
		Id = id;
	}

	public Long getRequestID() {
		return requestID;
	}

	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}

	public String getMandt() {
		return mandt;
	}

	public void setMandt(String mandt) {
		this.mandt = mandt;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getSerialNo() {
		return serialNo;
	}

	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}

	public String getNamespace() {
		return namespace;
	}

	public void setNamespace(String namespace) {
		this.namespace = namespace;
	}

	public String getObjectR3TR() {
		return objectR3TR;
	}

	public void setObjectR3TR(String objectR3TR) {
		this.objectR3TR = objectR3TR;
	}

	public String getObjNameR3TR() {
		return objNameR3TR;
	}

	public void setObjNameR3TR(String objNameR3TR) {
		this.objNameR3TR = objNameR3TR;
	}

	public String getObject() {
		return object;
	}

	public void setObject(String object) {
		this.object = object;
	}

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getChangeDate() {
		return changeDate;
	}

	public void setChangeDate(String changeDate) {
		this.changeDate = changeDate;
	}

	public String getDevClass() {
		return devClass;
	}

	public void setDevClass(String devClass) {
		this.devClass = devClass;
	}

	public String getCodeSize() {
		return codeSize;
	}

	public void setCodeSize(String codeSize) {
		this.codeSize = codeSize;
	}

	public String getVersionCount() {
		return versionCount;
	}

	public void setVersionCount(String versionCount) {
		this.versionCount = versionCount;
	}

	public String getRefInfosap() {
		return refInfosap;
	}

	public void setRefInfosap(String refInfosap) {
		this.refInfosap = refInfosap;
	}

	public String getRefTypeTextsap() {
		return refTypeTextsap;
	}

	public void setRefTypeTextsap(String refTypeTextsap) {
		this.refTypeTextsap = refTypeTextsap;
	}

	public String getLastTransport() {
		return lastTransport;
	}

	public void setLastTransport(String lastTransport) {
		this.lastTransport = lastTransport;
	}

	public String getLastTransportRfc() {
		return lastTransportRfc;
	}

	public void setLastTransportRfc(String lastTransportRfc) {
		this.lastTransportRfc = lastTransportRfc;
	}

	public String getObject1() {
		return object1;
	}

	public void setObject1(String object1) {
		this.object1 = object1;
	}

	public String getObjName1() {
		return objName1;
	}

	public void setObjName1(String objName1) {
		this.objName1 = objName1;
	}

	public String getLength1() {
		return length1;
	}

	public void setLength1(String length1) {
		this.length1 = length1;
	}

	public String getCntVers1() {
		return cntVers1;
	}

	public void setCntVers1(String cntVers1) {
		this.cntVers1 = cntVers1;
	}

	public String getIconComp() {
		return iconComp;
	}

	public void setIconComp(String iconComp) {
		this.iconComp = iconComp;
	}

	public String getObject2() {
		return object2;
	}

	public void setObject2(String object2) {
		this.object2 = object2;
	}

	public String getObjName2() {
		return objName2;
	}

	public void setObjName2(String objName2) {
		this.objName2 = objName2;
	}

	public String getLength2() {
		return length2;
	}

	public void setLength2(String length2) {
		this.length2 = length2;
	}

	public String getCntVers2() {
		return cntVers2;
	}

	public void setCntVers2(String cntVers2) {
		this.cntVers2 = cntVers2;
	}

	public String getRfcDest2() {
		return rfcDest2;
	}

	public void setRfcDest2(String rfcDest2) {
		this.rfcDest2 = rfcDest2;
	}

	public String getRecordDate() {
		return recordDate;
	}

	public void setRecordDate(String recordDate) {
		this.recordDate = recordDate;
	}

	public String getRecordTime() {
		return recordTime;
	}

	public void setRecordTime(String recordTime) {
		this.recordTime = recordTime;
	}
	@Column(name="RICEF_CATEGORY")
	private String ricefCategory;
	
	public String getRicefCategory() {
		return ricefCategory;
	}

	public void setRicefCategory(String ricefCategory) {
		this.ricefCategory = ricefCategory;
	}

	@Column(name="RICEF_SUB_CATEGORY")
	private String ricefSubCategory;

	public String getRicefSubCategory() {
		return ricefSubCategory;
	}

	public void setRicefSubCategory(String ricefSubCategory) {
		this.ricefSubCategory = ricefSubCategory;
	}
}
