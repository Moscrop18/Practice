package com.act.Aadt.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author rohan.a.mehra
 *
 */

@Entity
@Table(name = "Impact_Obj_List_Intermediate")
public class ImpactedObjectListIntermediate {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	private int id;

	@Column(name = "OBJ_TYPE")
	private String OBJ_TYPE;

	@Column(name = "OBJ_NAME")
	private String OBJ_NAME;
	
	@Column(name = "READ_PROG")
	private String readProg;

	@Column(name="OBJECT_TYPE_NAME_READ_PROG")
	private String objTypeNameReadProg;

	public String getReadProg() {
		return readProg;
	}

	public void setReadProg(String readProg) {
		this.readProg = readProg;
	}

	public String getObjTypeNameReadProg() {
		return objTypeNameReadProg;
	}

	public void setObjTypeNameReadProg(String objTypeNameReadProg) {
		this.objTypeNameReadProg = objTypeNameReadProg;
	}

	@Column(name = "OBJ_NAME_TYPE")
	private String OBJ_NAME_TYPE;

	@Column(name = "Used")
	private String Used;

	@Column(name = "REQUEST_ID")
	private long REQUEST_ID;
	
	@Column(name = "External_Namespace")
	private String extNamespace;
	
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getOBJ_TYPE() {
		return OBJ_TYPE;
	}

	public void setOBJ_TYPE(String oBJ_TYPE) {
		OBJ_TYPE = oBJ_TYPE;
	}

	public String getOBJ_NAME() {
		return OBJ_NAME;
	}

	public void setOBJ_NAME(String oBJ_NAME) {
		OBJ_NAME = oBJ_NAME;
	}

	public String getOBJ_NAME_TYPE() {
		return OBJ_NAME_TYPE;
	}

	public void setOBJ_NAME_TYPE(String oBJ_NAME_TYPE) {
		OBJ_NAME_TYPE = oBJ_NAME_TYPE;
	}

	public String getUsed() {
		return Used;
	}

	public void setUsed(String used) {
		Used = used;
	}

	public long getREQUEST_ID() {
		return REQUEST_ID;
	}

	public void setREQUEST_ID(long rEQUEST_ID) {
		REQUEST_ID = rEQUEST_ID;
	}

	@Column(name = "RICEF_CATEGORY")
	private String ricefCategory;

	public String getRicefCategory() {
		return ricefCategory;
	}

	public void setRicefCategory(String ricefCategory) {
		this.ricefCategory = ricefCategory;
	}

	public String getExtNamespace() {
		return extNamespace;
	}

	public void setExtNamespace(String extNamespace) {
		this.extNamespace = extNamespace;
	}
	
	@Column(name = "RICEF_SUB_CATEGORY")
	private String ricefSubCategory;
	
	public String getRicefSubCategory() {
		return ricefSubCategory;
	}

	public void setRicefSubCategory(String ricefSubCategory) {
		this.ricefSubCategory = ricefSubCategory;
	}
}
