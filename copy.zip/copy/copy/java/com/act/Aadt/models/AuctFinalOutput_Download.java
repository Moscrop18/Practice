package com.act.Aadt.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

/**
 * 
 * @author rohan.a.mehra
 *
 */

@Entity
@Table(name = "Auct_Final_Output_Download")
public class AuctFinalOutput_Download {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	private int id;

	@Column(name = "TYPE")
	private String TYPE;

	@Column(name = "OBJ_NAME")
	private String OBJ_NAME;

	@Column(name = "OBJ_NAME_TYPE")
	private String OBJ_NAME_TYPE;

	@Column(name = "SUB_TYPE")
	private String SUB_TYPE;

	@Column(name = "READ_PROG")
	private String READ_PROG;

	@Column(name = "OBJ_PACKAGE")
	private String OBJ_PACKAGE;

	@Column(name = "OPERCD")
	private String OPERCD;

	@Column(name = "OPCODE")
	private String OPCODE;

	@Column(name = "LINE_NUMBER")
	private Integer LINE_NUMBER;

	@Column(name = "TOTAL_LINE_NUMBER")
	private Integer TOTAL_LINE_NUMBER;

	@Column(name = "INFO", columnDefinition = "LONGTEXT")
	private String INFO;

	@Column(name = "AUTOMATION_STATUS")
	private String AUTOMATION_STATUS;

	@Index(name = "Index_Request_id")
	@Column(name = "REQUEST_ID")
	private long REQUEST_ID;

	@Column(name = "Used_Unused")
	private String Used_Unused;
	
	@Column(name = "External_Namespace")
	private String extNamespace;
	
	@Column(name = "CODE", columnDefinition="TEXT")
	private String CODE;
	
	
	public String getUsed_Unused() {
		return Used_Unused;
	}

	public void setUsed_Unused(String used_Unused) {
		Used_Unused = used_Unused;
	}

	public long getREQUEST_ID() {
		return REQUEST_ID;
	}

	public void setREQUEST_ID(long rEQUEST_ID) {
		REQUEST_ID = rEQUEST_ID;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTYPE() {
		return TYPE;
	}

	public void setTYPE(String tYPE) {
		TYPE = tYPE;
	}

	public String getOBJ_NAME() {
		return OBJ_NAME;
	}

	public void setOBJ_NAME(String oBJ_NAME) {
		OBJ_NAME = oBJ_NAME;
	}

	public String getSUB_TYPE() {
		return SUB_TYPE;
	}

	public void setSUB_TYPE(String sUB_TYPE) {
		SUB_TYPE = sUB_TYPE;
	}

	public String getREAD_PROG() {
		return READ_PROG;
	}

	public void setREAD_PROG(String rEAD_PROG) {
		READ_PROG = rEAD_PROG;
	}

	public String getOBJ_PACKAGE() {
		return OBJ_PACKAGE;
	}

	public void setOBJ_PACKAGE(String oBJ_PACKAGE) {
		OBJ_PACKAGE = oBJ_PACKAGE;
	}

	public String getOPERCD() {
		return OPERCD;
	}

	public void setOPERCD(String oPERCD) {
		OPERCD = oPERCD;
	}

	public String getOPCODE() {
		return OPCODE;
	}

	public void setOPCODE(String oPCODE) {
		OPCODE = oPCODE;
	}

	public Integer getLINE_NUMBER() {
		return LINE_NUMBER;
	}

	public void setLINE_NUMBER(Integer lINE_NUMBER) {
		LINE_NUMBER = lINE_NUMBER;
	}

	public Integer getTOTAL_LINE_NUMBER() {
		return TOTAL_LINE_NUMBER;
	}

	public void setTOTAL_LINE_NUMBER(Integer tOTAL_LINE_NUMBER) {
		TOTAL_LINE_NUMBER = tOTAL_LINE_NUMBER;
	}

	public String getINFO() {
		return INFO;
	}

	public void setINFO(String iNFO) {
		INFO = iNFO;
	}

	public String getAUTOMATION_STATUS() {
		return AUTOMATION_STATUS;
	}

	public void setAUTOMATION_STATUS(String aUTOMATION_STATUS) {
		AUTOMATION_STATUS = aUTOMATION_STATUS;
	}

	public String getOBJ_NAME_TYPE() {
		return OBJ_NAME_TYPE;
	}

	public void setOBJ_NAME_TYPE(String oBJ_NAME_TYPE) {
		OBJ_NAME_TYPE = oBJ_NAME_TYPE;
	}

	public String getExtNamespace() {
		return extNamespace;
	}

	public void setExtNamespace(String extNamespace) {
		this.extNamespace = extNamespace;
	}

	@Column(name = "RICEF_CATEGORY")
	private String ricefCategory;

	public String getRicefCategory() {
		return ricefCategory;
	}

	public void setRicefCategory(String ricefCategory) {
		this.ricefCategory = ricefCategory;
	}
	@Column(name = "RICEF_SUB_CATEGORY")
	private String ricefSubCategory;
	
	public String getRicefSubCategory() {
		return ricefSubCategory;
	}

	public void setRicefSubCategory(String ricefSubCategory) {
		this.ricefSubCategory = ricefSubCategory;
	}

	public String getCODE() {
		return CODE;
	}

	public void setCODE(String cODE) {
		CODE = cODE;
	}

	
}
