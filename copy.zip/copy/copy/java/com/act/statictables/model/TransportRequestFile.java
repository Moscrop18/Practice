/**
 * @author rohan.a.mehra
 *
 */
package com.act.statictables.model;



import javax.persistence.*;

import org.hibernate.annotations.Type;




@Entity
@Table(name="TRANSPORT_REQUEST_File")
public class TransportRequestFile implements java.io.Serializable {

	
	private int ID;



		@Id
		@TableGenerator(name="seq",initialValue=1,allocationSize=0)
		@GeneratedValue(strategy=GenerationType.TABLE, generator="seq")
		@Column(name="ID")
		public int getID() {
			return ID;
		}

		public void setID(int iD) {
			ID = iD;
		}
		
		public String trFileName;
		
		

		public byte[] trFile;
	   
		private String trVersion;
		
		private String updatedDate;


		
		@Column(name="TRANSPORT_REQUEST_FILE_NAME")
		public String getTrFileName() {
			return trFileName;
		}

		public void setTrFileName(String trFileName) {
			this.trFileName = trFileName;
		}
		
		
		
		@Column(name="TRANSPORT_REQUEST_FILE")
		@Type(type="org.hibernate.type.MaterializedBlobType")
		public byte[] getTrFile() {
			return trFile;
		}

		public void setTrFile(byte[] trFile) {
			this.trFile = trFile;
		}

		@Column(name="TRANSPORT_REQUEST_FILE_VERSION")
		public String getTrVersion() {
			return trVersion;
		}

		public void setTrVersion(String trVersion) {
			this.trVersion = trVersion;
		}

		@Column(name="UPDATED_DATE")
		public String getUpdatedDate() {
			return updatedDate;
		}

		public void setUpdatedDate(String updatedDate) {
			this.updatedDate = updatedDate;
		}
			
	
}
