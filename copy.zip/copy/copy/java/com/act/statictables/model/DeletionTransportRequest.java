package com.act.statictables.model;
import javax.persistence.Column; 
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.EmbeddedId;
import org.hibernate.annotations.Type;
import org.hibernate.validator.constraints.NotEmpty;

@Entity

@Table(name="DELETION_TRANSPORT_REQUEST")

public class DeletionTransportRequest  implements java.io.Serializable {

	
    private TransportRequestID  transportRequestPK;
	
	//@NotEmpty(message="TRFile Name cannot be empty")
	public String trFileName;
	
	
	public byte[] trFile;
   
	private String toolName;
	


	

	@Column(name="TRANSPORT_REQUEST_FILE_NAME")
	public String getTrFileName() {
		return trFileName;
	}

	public void setTrFileName(String trFileName) {
		this.trFileName = trFileName;
	}

	@Column(name="TRANSPORT_REQUEST_FILE")
	@Type(type="org.hibernate.type.PrimitiveByteArrayBlobType")
	public byte[] getTrFile() {
		return trFile;
	}

	public void setTrFile(byte[] trFile) {
		this.trFile = trFile;
	}
	
	@EmbeddedId
	public TransportRequestID getTransportRequestPK() {
		return transportRequestPK;
	}

	public void setTransportRequestPK(TransportRequestID transportRequestPK) {
		this.transportRequestPK = transportRequestPK;
	}

	@Column(name="TOOL_NAME")
	public String getToolName() {
		return toolName;
	}

	public void setToolName(String toolName) {
		this.toolName = toolName;
	}
}
