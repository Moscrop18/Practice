package com.act.statictables.model;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import org.hibernate.validator.constraints.NotEmpty;

@Embeddable
public class TransportRequestID  implements java.io.Serializable{
	
	public String sourceVersion;
	
	
	public String targetVersion;


	@Column(name="SOURCE_VERSION")
    public String getSourceVersion() {
		return sourceVersion;
	}

	public void setSourceVersion(String sourceVersion) {
		this.sourceVersion = sourceVersion;
	}

	@Column(name="TARGET_VERSION")
	public String getTargetVersion() {
		return targetVersion;
	}

	public void setTargetVersion(String targetVersion) {
		this.targetVersion = targetVersion;
	}
	

	public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        TransportRequestID that = (TransportRequestID) o;

        if (sourceVersion != null ? !sourceVersion.equals(that.sourceVersion) : that.sourceVersion != null) return false;
        if (targetVersion != null ? !targetVersion.equals(that.targetVersion) : that.targetVersion != null)
            return false;

        return true;
    }

    public int hashCode() {
        int result;
        result = (sourceVersion != null ? sourceVersion.hashCode() : 0);
        result = 31 * result + (targetVersion != null ? targetVersion.hashCode() : 0);
        return result;
    }
    
    public TransportRequestID(){}
    
    public TransportRequestID(String sourceVersion,String targetVersion)
    {
    	this.sourceVersion=sourceVersion;
    	this.targetVersion=targetVersion;
    }
    
}
