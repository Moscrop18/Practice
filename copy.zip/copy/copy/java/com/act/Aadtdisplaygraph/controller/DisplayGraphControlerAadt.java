/**
 * 
 * @author rohan.a.mehra
 * 
 * 
 *DEF042: Add Used column in Detail Reports -himani.malhotra
 *
 *DEF075: Impacted IDOC New Requirements -17/05/2019 -himani.malhotra
 */

package com.act.Aadtdisplaygraph.controller;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.DVConstraint;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.util.CellRangeAddressList;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.openxml4j.util.ZipSecureFile;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataValidation;
import org.apache.poi.ss.usermodel.DataValidationConstraint;
import org.apache.poi.ss.usermodel.DataValidationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFDataValidation;
import org.apache.poi.xssf.usermodel.XSSFFormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.act.Aadt.models.ACNIPZVERComp;
import com.act.Aadt.models.AuctFinalOutput_Download;
import com.act.Aadt.models.BWExtractor_Download;
import com.act.Aadt.models.ImpactedCloneAnalysis;
import com.act.Aadt.models.ImpactedCloneAnalysis_Download;
import com.act.Aadt.models.ImpactedObjList_Download;
import com.act.Aadt.models.ImpactedVariant_Download;
import com.act.Aadt.models.OSMigrationFinalFilepath_Download;
import com.act.Aadt.models.OSMigrationFinalLogicalCMD_Download;
import com.act.Aadt.models.OSMigrationFinal_Download;
import com.act.S4.Controller.S4ProcessingController;
import com.act.S4.models.ABAPQueryInventoryDownload;
import com.act.S4.models.BwCleanupUtilDownload;
import com.act.S4.models.CvitCustomisingLogsDownload;
import com.act.S4.models.CvitErrorMessagesDownload;
import com.act.S4.models.DrillDown_Download;
import com.act.S4.models.InactiveObjectsDownload;
import com.act.S4.models.InconsistentFUGR_Download;
import com.act.S4.models.InventoryList_Download;
import com.act.S4.models.ObsoleteFmsDueToUpgrade;
import com.act.S4.models.OperationDataS4;
import com.act.S4.models.S4AffectCustomField_Download;
import com.act.S4.models.S4AppendStructureAnalysis_Download;
import com.act.S4.models.S4CloneProg_Download;
import com.act.S4.models.S4CvitAssessment;
import com.act.S4.models.S4DetailReportComplexity_Download;
import com.act.S4.models.S4DetailReportRemediation_Download;
import com.act.S4.models.S4Enhancement_Download;
import com.act.S4.models.S4HanaProfiler_Download;
import com.act.S4.models.S4ImpactedCustomTblDownload;
import com.act.S4.models.S4ImpactedIDOC_Download;
import com.act.S4.models.S4ImpactedSearchHelp_Download;
import com.act.S4.models.S4ImpactedTables_Download;
import com.act.S4.models.S4ImpactedTransaction_Download;
import com.act.S4.models.S4OutputMgmt_Download;
import com.act.S4.models.S4_SID_Download;
import com.act.S4.models.S4cvitr_Download;
import com.act.S4.models.UnicodeOutput;
import com.act.Scripts.model.ImpactedScripts_Download;
import com.act.UI5.models.UI5FinalOutput;
import com.act.UI5.models.UI5HighLevelReport;
import com.act.bw.model.BwExtractorMaster;
import com.act.bw.model.BwInventoryDownload;
import com.act.bw.model.BwStandardExtractDownload;
import com.act.client.model.RequestForm;
import com.act.client.model.RequestInventory;
import com.act.constant.Hana_Profiler_Constant;
import com.act.constant.ST03HanaConstant;
import com.act.displaygrid.model.HanaProfile_Download;
import com.act.exceptions.ReqIDNotValidException;
import com.act.fileprocessing.model.ExtensionOutput;
import com.act.fiori.models.CustomReportOutput_download;
import com.act.fiori.models.FioriAppsOutput;
import com.act.fiori.models.InventoryStandardFiori;
import com.act.impactedBackgroundJob.ImpactedBackgroundJob_Download;
import com.act.master.IRPATScopeEstimates;
import com.act.master.IRPATScopeRequestMaster;
import com.act.master.ProcessedRequestDetail;
import com.act.service.RequestIDValidateService;
import com.act.smodilog.model.SmodilogFunction_Download;
import com.act.testingscope.model.ExtractedDatapojo;
import com.act.testingscope.model.TestingScopeDownload;
import com.act.utility.HANAUtility;
import com.act.validator.RequestID_Validator_Utility;

@Controller
@SessionAttributes("User")

public class DisplayGraphControlerAadt extends S4ProcessingController {

	@Autowired
	private RequestIDValidateService reqIDValid;

	@RequestMapping(value = "/admin/grph", method = RequestMethod.GET)
	public ModelAndView graphView(ModelAndView model,
			@RequestParam(required = false, defaultValue = "") final String requestId) {
		ModelAndView modenAndView = new ModelAndView("admin/requestGraph");
		if (StringUtils.isBlank(requestId) || Hana_Profiler_Constant.FOUR_ZEROS.equals(requestId))
			return modenAndView;
		final RequestInventory requestInventory = getClientRequestInventoryDAO()
				.getRequestInventory(Long.parseLong(requestId));
		if (requestInventory != null && (StringUtils.equals(requestInventory.getRequestStatus(),
				Hana_Profiler_Constant.HANAREFININGSUCCESS_STATUS)
				|| StringUtils.equals(requestInventory.getRequestStatus(),
						Hana_Profiler_Constant.HANAREFININGCOMPLETED_STATUS))) {
			// For Hana Graphs
			modenAndView.addObject("cateGory", getGraphDao().getGraphCountCategory(Long.parseLong(requestId)));
			modenAndView.addObject("subCateGory", getGraphDao().getGraphCountSubCategory(Long.parseLong(requestId)));
			modenAndView.addObject("usedUnused", getGraphDao().getGraphCountUsedUnused(Long.parseLong(requestId)));
			modenAndView.addObject("impact", getGraphDao().getGraphCountImpact(Long.parseLong(requestId)));
			// For S4 Graphs
			modenAndView.addObject("cateGorys4", getGraphS4DAO().getGraphCountRemediCategry(Long.parseLong(requestId)));
			modenAndView.addObject("subCateGorys4", getGraphS4DAO().getGraphCountErrCategry(Long.parseLong(requestId)));
			modenAndView.addObject("usedUnuseds4", getGraphS4DAO().getGraphCountFinalUsed(Long.parseLong(requestId)));
			modenAndView.addObject("impacts4", getGraphS4DAO().getGraphCountFinalComplexity(Long.parseLong(requestId)));
			modenAndView.addObject("applications4",
					getGraphS4DAO().getMaxApplicationComponent(Long.parseLong(requestId)));
		} else {
			modenAndView.addObject("requestIdNotValidErrMsg", "Please enter valid Request ID");
		}
		modenAndView.addObject("requestId", requestId);
		return modenAndView;
	}

	@RequestMapping(value = "/downloadSummarySheet/{requestID}/{userRole}/{userAccess}", method = RequestMethod.GET)
	public synchronized String downloadTransportRequestFile(@PathVariable("requestID") Long requestID,
			@PathVariable("userAccess") final String userAccess, @PathVariable("userRole") final String userRole,
			Model model, HttpServletResponse response, HttpServletRequest request,
			final RedirectAttributes redirectAttributes, HttpSession session) throws Exception {
		try {
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestID));
			if (userRole.equalsIgnoreCase("CLIENT"))
				RequestID_Validator_Utility.chckReqIdUser(reqIDValid.getCreator(reqIDValid.getRequestInv(requestID)),
						getPrincipal());
			else if (userRole.equalsIgnoreCase("POC"))
				RequestID_Validator_Utility.chckReqIdPOC(reqIDValid.getPOCName(reqIDValid.getRequestInv(requestID)),
						getPrincipal());

			final RequestForm requestForm = getRequestDetails().getRequestObj(requestID);

			String graphTemplete = "";

			graphTemplete = request.getSession().getServletContext()
					.getRealPath("/staticResources/GraphTemplate/Invent_Summary_Temp_Client.xlsx");

			/*
			 * if
			 * (Hana_Profiler_Constant.ACCESS_FALSE.equalsIgnoreCase(userAccess)
			 * ) { graphTemplete = request.getSession().getServletContext()
			 * .getRealPath(
			 * "/staticResources/GraphTemplate/Invent_Summary_Temp_Client.xlsx"
			 * ); } else if
			 * (Hana_Profiler_Constant.ACCESS_TRUE.equalsIgnoreCase(userAccess)
			 * && Hana_Profiler_Constant.CLIENT.equalsIgnoreCase(userRole)) {
			 * graphTemplete = request.getSession().getServletContext()
			 * .getRealPath(
			 * "/staticResources/GraphTemplate/Invent_Complete_Temp_Client.xlsx"
			 * ); } else if
			 * (Hana_Profiler_Constant.POC.equalsIgnoreCase(userRole)) {
			 * graphTemplete = request.getSession().getServletContext()
			 * .getRealPath(
			 * "/staticResources/GraphTemplate/Invent_Summary_Temp_POC.xlsx"); }
			 * else if
			 * (Hana_Profiler_Constant.ACCESS_TRUE.equalsIgnoreCase(userAccess)
			 * && Hana_Profiler_Constant.ADMIN.equalsIgnoreCase(userRole)) {
			 * graphTemplete = request.getSession().getServletContext()
			 * .getRealPath(
			 * "/staticResources/GraphTemplate/Invent_Complete_Temp_admin.xlsx"
			 * ); }
			 */
			boolean scopeHana = requestForm.getSOH();
			boolean scopeS4 = requestForm.getS4Technical();
			boolean scopeUI5 = requestForm.getUI5();
			boolean scopeFiori = requestForm.getFiori();
			boolean scopeAUCT = requestForm.getUPGRADE();
			boolean scopeOSMigration = requestForm.getOsMig();
			boolean scopeBWTech = requestForm.getBwTech();
			boolean scopeCVIT = requestForm.getCVIT();

			ArrayList<String> tabScopeWise = new ArrayList<String>();

			XSSFWorkbook workbook = new XSSFWorkbook(OPCPackage.open(new FileInputStream(graphTemplete)));
			@SuppressWarnings("resource")
			SXSSFWorkbook workbookTemp = new SXSSFWorkbook(workbook);
			workbookTemp.setCompressTempFiles(true);

			// Changing XSSF to SXSSF

			if (scopeAUCT || scopeHana || scopeS4 || scopeOSMigration || scopeBWTech) {
				// Writing Inventory
				int inventoryIndex = workbookTemp.getXSSFWorkbook()
						.getSheetIndex(Hana_Profiler_Constant.INVENTORY_LIST);
				SXSSFSheet inventory = workbookTemp.getSheetAt(inventoryIndex);
				writeInventory(inventory, requestID);
				tabScopeWise.add(Hana_Profiler_Constant.INVENTORY_LIST);
			}

			if (scopeHana || scopeS4) {
				// Writing Abap query Inventory
				int ABAPinventoryIndex = workbookTemp.getXSSFWorkbook()
						.getSheetIndex(Hana_Profiler_Constant.ABAP_INVENTORY_LIST);
				SXSSFSheet ABAPinventory = workbookTemp.getSheetAt(ABAPinventoryIndex);
				writeInventoryABAP(ABAPinventory, requestID);
				tabScopeWise.add(Hana_Profiler_Constant.ABAP_INVENTORY_LIST);
			}

			if (scopeAUCT || scopeHana || scopeS4 || scopeOSMigration || scopeBWTech) {
				// Writing Impacted Object Type
				int impactObjSheetIndex = workbookTemp.getXSSFWorkbook()
						.getSheetIndex(Hana_Profiler_Constant.IMPACTED_OBJECT);
				SXSSFSheet impactObjSheet = workbookTemp.getSheetAt(impactObjSheetIndex);
				writeImpactObjSheet(impactObjSheet, requestID);
				tabScopeWise.add(Hana_Profiler_Constant.IMPACTED_OBJECT);
			}

			if (scopeHana || scopeS4 || scopeBWTech) {
				// Writing DR_DB Change report Sheet
				int DR_DB_ChangeIndex = workbookTemp.getXSSFWorkbook()
						.getSheetIndex(Hana_Profiler_Constant.DR_DB_CHANGE);
				List<HanaProfile_Download> DBChangeList = new ArrayList<HanaProfile_Download>();
				DBChangeList = getDaoIntf().GetList(requestID, 0, 0);
				SXSSFSheet DR_DB_Change = (SXSSFSheet) workbookTemp.getSheetAt(DR_DB_ChangeIndex);
				DR_DB_Change.setRandomAccessWindowSize(100);
				wroteDbChange(DR_DB_Change, DBChangeList);
				tabScopeWise.add(Hana_Profiler_Constant.DR_DB_CHANGE);
			}

			if (scopeS4 || scopeBWTech) {
				// Writing DR_S4 Simplification report Sheet
				int simplificationIndex = workbookTemp.getXSSFWorkbook()
						.getSheetIndex(Hana_Profiler_Constant.IMPACTED_SIMPLIFICATION);
				List<S4HanaProfiler_Download> DR_S4_SimplificationList = new ArrayList<S4HanaProfiler_Download>();
				DR_S4_SimplificationList = getS4DaoIntf().getList(requestID, 0, 0);
				SXSSFSheet DR_S4_SimplificationSheet = (SXSSFSheet) workbookTemp.getSheetAt(simplificationIndex);
				DR_S4_SimplificationSheet.setRandomAccessWindowSize(100);
				wroteS4Simplification(DR_S4_SimplificationSheet, DR_S4_SimplificationList);
				tabScopeWise.add(Hana_Profiler_Constant.IMPACTED_SIMPLIFICATION);
			}

			if (scopeAUCT || scopeHana || scopeS4 || scopeOSMigration || scopeBWTech) {
				// Writing DR_Existing Errors report Sheet
				int errorsIndex = workbookTemp.getXSSFWorkbook().getSheetIndex(Hana_Profiler_Constant.EXISTING_ERRORS);
				List<AuctFinalOutput_Download> DR_Existing_Errors = new ArrayList<AuctFinalOutput_Download>();
				DR_Existing_Errors = getDaoIntf().writeAuctFinalOutputSheet(requestID, 0, 0);
				SXSSFSheet DRExistingErrorsSheet = (SXSSFSheet) workbookTemp.getSheetAt(errorsIndex);
				DRExistingErrorsSheet.setRandomAccessWindowSize(100);
				wroteDR_Existing_Errors(DRExistingErrorsSheet, DR_Existing_Errors);
				tabScopeWise.add(Hana_Profiler_Constant.EXISTING_ERRORS);
			}

			// if (scopeFiori) {
			// // Writing DR_FIORI ODATA report Sheet
			// int fioriOdataIndex = workbookTemp.getXSSFWorkbook()
			// .getSheetIndex(Hana_Profiler_Constant.FIORI_ANALYSIS);
			// List<InventoryStandardFiori> DR_FioriList = new
			// ArrayList<InventoryStandardFiori>();
			// DR_FioriList = getDaoIntf().writeOdataFinalOutputSheet(requestID,
			// 0, 0);
			// XSSFSheet DR_FioriSheet =
			// workbookTemp.getXSSFWorkbook().getSheetAt(fioriOdataIndex);
			// // DR_FioriSheet.setRandomAccessWindowSize(100);
			// wroteDR_Fiori(DR_FioriSheet, DR_FioriList);
			// tabScopeWise.add(Hana_Profiler_Constant.FIORI_ANALYSIS);
			// }

			// change tab name, remove extra sheet, add component field
			if (scopeFiori) {
				// Writing Custom Report Output Sheet
				int fioriCustomIndex = workbookTemp.getXSSFWorkbook()
						.getSheetIndex(Hana_Profiler_Constant.FIORI_CUSTOM_REPORT);
				List<CustomReportOutput_download> DR_FioriCustomList = new ArrayList<CustomReportOutput_download>();
				DR_FioriCustomList = getDaoIntf().writeCustomReportFinalOutputSheet(requestID, 0, 0);
				XSSFSheet DR_FioriCustomSheet = workbookTemp.getXSSFWorkbook().getSheetAt(fioriCustomIndex);
				// DR_FioriSheet.setRandomAccessWindowSize(100);
				wroteCustomReportFiori(DR_FioriCustomSheet, DR_FioriCustomList);
				tabScopeWise.add(Hana_Profiler_Constant.FIORI_CUSTOM_REPORT);
			}

			if (scopeS4 || scopeBWTech) {
				// Writing Output Management Sheet
				int otputManagementIndex = workbookTemp.getXSSFWorkbook()
						.getSheetIndex(Hana_Profiler_Constant.OUTPUT_MANAGEMENT);
				SXSSFSheet outputMgmntSheet = (SXSSFSheet) workbookTemp.getSheetAt(otputManagementIndex);
				outputMgmntSheet.setRandomAccessWindowSize(100);
				writeOutputMgmntSheet(outputMgmntSheet, requestID);
				tabScopeWise.add(Hana_Profiler_Constant.OUTPUT_MANAGEMENT);
			}

			if (scopeS4 || scopeBWTech) {
				// Writing Affect By Custom Sheet
				int customIndex = workbookTemp.getXSSFWorkbook()
						.getSheetIndex(Hana_Profiler_Constant.AFFECTED_CUSTOM_FIELDS);
				SXSSFSheet affectByCustomSheet = (SXSSFSheet) workbookTemp.getSheetAt(customIndex);
				affectByCustomSheet.setRandomAccessWindowSize(100);
				writeAffectCustomSheet(affectByCustomSheet, requestID);
				tabScopeWise.add(Hana_Profiler_Constant.AFFECTED_CUSTOM_FIELDS);
			}

			if (scopeS4 || scopeBWTech) {
				// Writing Impacted Table Sheet
				int impactedTablesIndex = workbookTemp.getXSSFWorkbook()
						.getSheetIndex(Hana_Profiler_Constant.IMPACTED_TABLES);
				XSSFSheet impactedTablesSheet = workbookTemp.getXSSFWorkbook().getSheetAt(impactedTablesIndex);
				// impactedTablesSheet.setRandomAccessWindowSize(100);
				writeImpactedTableSheet(impactedTablesSheet, requestID, requestForm);
				tabScopeWise.add(Hana_Profiler_Constant.IMPACTED_TABLES);
			}

			if (scopeS4 || scopeBWTech) {
				// Writing Impacted IDOC Sheet
				int impactedIDOCIndex = workbookTemp.getXSSFWorkbook()
						.getSheetIndex(Hana_Profiler_Constant.IMPACTED_IDOC);
				SXSSFSheet impactedIDOCSheet = (SXSSFSheet) workbookTemp.getSheetAt(impactedIDOCIndex);
				impactedIDOCSheet.setRandomAccessWindowSize(100);
				writeImpactedIDOCSheet(impactedIDOCSheet, requestID);
				tabScopeWise.add(Hana_Profiler_Constant.IMPACTED_IDOC);
			}

			if (scopeS4 || scopeBWTech) {
				// Writing Impacted Transaction Sheet
				int impactedTransactionIndex = workbookTemp.getXSSFWorkbook()
						.getSheetIndex(Hana_Profiler_Constant.IMPACTED_STANDARD_TRANSACTION);
				XSSFSheet impactedTransactionSheet = workbookTemp.getXSSFWorkbook()
						.getSheetAt(impactedTransactionIndex);
				// impactedTransactionSheet.setRandomAccessWindowSize(100);
				writeImpactedTransactionSheet(impactedTransactionSheet, requestID, requestForm);
				tabScopeWise.add(Hana_Profiler_Constant.IMPACTED_STANDARD_TRANSACTION);
			}

			if (scopeS4 || scopeBWTech) {
				// Writing Impacted Search Help
				int searchHelpIndex = workbookTemp.getXSSFWorkbook().getSheetIndex(Hana_Profiler_Constant.SEARCH_HELP);
				SXSSFSheet searchHelpSheet = workbookTemp.getSheetAt(searchHelpIndex);
				writeImpactedSearchSheet(searchHelpSheet, requestID);
				tabScopeWise.add(Hana_Profiler_Constant.SEARCH_HELP);
			}

			if (scopeS4 || scopeBWTech) {
				// Writing Append Structure Analysis
				int structuredAnalysisIndex = workbookTemp.getXSSFWorkbook()
						.getSheetIndex(Hana_Profiler_Constant.STRUCTURE_ANALYSIS);
				SXSSFSheet appendSheet = workbookTemp.getSheetAt(structuredAnalysisIndex);
				writeAppendStrctrSheet(appendSheet, requestID);
				tabScopeWise.add(Hana_Profiler_Constant.STRUCTURE_ANALYSIS);
			}

			if (scopeS4 || scopeBWTech) {
				// Writing Enhancement Sheet
				int enhancementBADIIndex = workbookTemp.getXSSFWorkbook()
						.getSheetIndex(Hana_Profiler_Constant.ENHANCEMENT_BADI);
				SXSSFSheet enhancementSheet = workbookTemp.getSheetAt(enhancementBADIIndex);
				writeEnhancementSheet(enhancementSheet, requestID);
				tabScopeWise.add(Hana_Profiler_Constant.ENHANCEMENT_BADI);
			}

			if (scopeHana || scopeS4 || scopeAUCT || scopeOSMigration) {
				// Writing ACNIP_ZVER_COMP sheet 1
				int acnipzverIndex = workbookTemp.getXSSFWorkbook()
						.getSheetIndex(Hana_Profiler_Constant.ACNIP_ZVER_COMP);
				SXSSFSheet acnipzverSheet = workbookTemp.getSheetAt(acnipzverIndex);
				writeACNIPZVERCompSheet(acnipzverSheet, requestID);
				tabScopeWise.add(Hana_Profiler_Constant.ACNIP_ZVER_COMP);
			}

			if (scopeUI5) {
				// Writing UI5 sheet 1
				int ui5FinalIndex = workbookTemp.getXSSFWorkbook().getSheetIndex(Hana_Profiler_Constant.UI5_FINAL);
				SXSSFSheet UI5FinalOutputSheet = workbookTemp.getSheetAt(ui5FinalIndex);
				writeUI5FinalOutputSheet(UI5FinalOutputSheet, requestID);
				tabScopeWise.add(Hana_Profiler_Constant.UI5_FINAL);
			}

			if (scopeUI5) {
				// Writing UI5 sheet 2
				int ui5HighLeveltIndex = workbookTemp.getXSSFWorkbook()
						.getSheetIndex(Hana_Profiler_Constant.UI5_HIGH_LEVEL);
				SXSSFSheet UI5HighLevelReportSheet = workbookTemp.getSheetAt(ui5HighLeveltIndex);
				writeUI5HighLevelReportSheet(UI5HighLevelReportSheet, requestID);
				tabScopeWise.add(Hana_Profiler_Constant.UI5_HIGH_LEVEL);
			}

			if (scopeAUCT || scopeHana || scopeS4 || scopeOSMigration || scopeBWTech) {
				// Writing Testing Scope Sheet
				int testingScopeIndex = workbookTemp.getXSSFWorkbook()
						.getSheetIndex(Hana_Profiler_Constant.TESTING_SCOPE);
				Font f1 = workbookTemp.createFont();
				f1.setColor(HSSFColor.DARK_RED.index);
				XSSFCellStyle csr = (XSSFCellStyle) workbookTemp.createCellStyle();
				csr.setFillForegroundColor(new XSSFColor(new java.awt.Color(255, 199, 206)));
				csr.setFillPattern(CellStyle.SOLID_FOREGROUND);
				csr.setFont(f1);
				SXSSFSheet testingScopeReportSheet = workbookTemp.getSheetAt(testingScopeIndex);
				writeTestingScopeReportSheet(testingScopeReportSheet, requestID, csr);
				tabScopeWise.add(Hana_Profiler_Constant.TESTING_SCOPE);
			}

			if (scopeHana || scopeS4 || scopeOSMigration || scopeBWTech) {
				// Writing Impacted Background Job Sheet
				int backgroundIndex = workbookTemp.getXSSFWorkbook()
						.getSheetIndex(Hana_Profiler_Constant.IMPACTED_BACKGROUND);
				SXSSFSheet impactedBackgroundJobSheet = workbookTemp.getSheetAt(backgroundIndex);
				writeImpactedBackgroundJobReportSheet(impactedBackgroundJobSheet, requestID);
				tabScopeWise.add(Hana_Profiler_Constant.IMPACTED_BACKGROUND);
			}

			if (scopeAUCT || scopeHana || scopeS4 || scopeOSMigration || scopeBWTech) {
				// Writing Smodilog Data
				int smodilogIndex = workbookTemp.getXSSFWorkbook().getSheetIndex(Hana_Profiler_Constant.SMODILOG);
				SXSSFSheet smodilogData = workbookTemp.getSheetAt(smodilogIndex);
				writeSmodilogData(smodilogData, requestID);
				tabScopeWise.add(Hana_Profiler_Constant.SMODILOG);
			}

			if (scopeS4 || scopeBWTech) {
				// Writing Impacted Scripts Sheet
				int scriptIndex = workbookTemp.getXSSFWorkbook().getSheetIndex(Hana_Profiler_Constant.SAP_SCRIPT);
				SXSSFSheet impactedScriptsSheet = workbookTemp.getSheetAt(scriptIndex);
				writeImpactedScriptsSheet(impactedScriptsSheet, requestID);
				tabScopeWise.add(Hana_Profiler_Constant.SAP_SCRIPT);
			}

			if (scopeOSMigration) {
				// Writing OS Migration Sheet - Imapcted due to OS Migration
				int osMigrationIndex = workbookTemp.getXSSFWorkbook()
						.getSheetIndex(Hana_Profiler_Constant.IMPACTED_OS_MIGRATION);
				SXSSFSheet impactDueToOSMigrationSheet = workbookTemp.getSheetAt(osMigrationIndex);
				writeOSMigrationSheet(impactDueToOSMigrationSheet, requestID, requestForm, session);
				tabScopeWise.add(Hana_Profiler_Constant.IMPACTED_OS_MIGRATION);
			}

			if (scopeOSMigration) {
				// Writing OS Migration Sheet - Logical CMD impacted by OS Chg
				int cmdOSIndex = workbookTemp.getXSSFWorkbook().getSheetIndex(Hana_Profiler_Constant.LOCIGAL_CMD_OS);
				SXSSFSheet logCmdImpctOSSheet = workbookTemp.getSheetAt(cmdOSIndex);
				writeLogCmdImpactOSSheet(logCmdImpctOSSheet, requestID);
				tabScopeWise.add(Hana_Profiler_Constant.LOCIGAL_CMD_OS);
			}

			if (scopeOSMigration) {
				// Writing OS Migration Sheet - File path impacted by OS Change
				int filepathOSIndex = workbookTemp.getXSSFWorkbook().getSheetIndex(Hana_Profiler_Constant.FILEPATH_OS);
				SXSSFSheet filePathImpactOSSheet = workbookTemp.getSheetAt(filepathOSIndex);
				writeFilePathImpactOSSheet(filePathImpactOSSheet, requestID);
				tabScopeWise.add(Hana_Profiler_Constant.FILEPATH_OS);
			}

			if (scopeAUCT || scopeHana || scopeS4 || scopeOSMigration || scopeBWTech) {
				// Writing Impacted Clone Analysis Sheet
				int impactedCloneIndex = workbookTemp.getXSSFWorkbook()
						.getSheetIndex(Hana_Profiler_Constant.IMPACTED_CLONE);
				SXSSFSheet impactCloneSheet = workbookTemp.getSheetAt(impactedCloneIndex);
				writeImpactedCloneSheet(impactCloneSheet, requestID);
				tabScopeWise.add(Hana_Profiler_Constant.IMPACTED_CLONE);
			}
			if (scopeCVIT) {
				if (scopeS4 || scopeBWTech) {
					// Writing CVITR Sheet
					int cvitrIndex = workbookTemp.getXSSFWorkbook().getSheetIndex(Hana_Profiler_Constant.CVITR);
					XSSFSheet cvitrSheet = workbookTemp.getXSSFWorkbook().getSheetAt(cvitrIndex);
					writeCVITRSheet(cvitrSheet, requestID, workbook);
					tabScopeWise.add(Hana_Profiler_Constant.CVITR);
				}

				if (scopeS4 || scopeBWTech) {
					// Writing CVIT Assessment data
					int cvitIndex = workbookTemp.getXSSFWorkbook().getSheetIndex(Hana_Profiler_Constant.CVIT);
					XSSFSheet s4CvitAssessmentSheet = workbookTemp.getXSSFWorkbook().getSheetAt(cvitIndex);
					writeS4CvitAssessmentData(s4CvitAssessmentSheet, requestID, requestForm);
					tabScopeWise.add(Hana_Profiler_Constant.CVIT);
				}
			}

			// Writing cvit customising logs sheet
			List<CvitCustomisingLogsDownload> cvitCustomLogsList = getDaoIntf().getcvitCustomLogsList(requestID);
			if ((scopeS4 || scopeBWTech) && CollectionUtils.isNotEmpty(cvitCustomLogsList)) {
				SXSSFSheet cvitCustomLogsSheet = workbookTemp.getSheet(Hana_Profiler_Constant.CVIT_CUSTOM_LOGS);
				writeCvitCustomLogs(cvitCustomLogsSheet, requestID, cvitCustomLogsList);
				tabScopeWise.add(Hana_Profiler_Constant.CVIT_CUSTOM_LOGS);
			}

			// Writing cvit error message logs sheet
			List<CvitErrorMessagesDownload> cvitErrorMsgsList = getDaoIntf().getcvitErrorMsgsList(requestID);
			if ((scopeS4 || scopeBWTech) && CollectionUtils.isNotEmpty(cvitErrorMsgsList)) {
				SXSSFSheet cvitErrorMsgsSheet = workbookTemp.getSheet(Hana_Profiler_Constant.CVIT_ERROR_MESSGAES);
				writeCvitErrorMessages(cvitErrorMsgsSheet, requestID, cvitErrorMsgsList);
				tabScopeWise.add(Hana_Profiler_Constant.CVIT_ERROR_MESSGAES);
			}

			String target = requestForm.getTargetVersion();
			if (target.startsWith("S/4")) {
				target = target.replace("/", "");
			}

			if (scopeAUCT || scopeHana || scopeS4 || scopeOSMigration || scopeBWTech) {
				// Writing Unicode Sheet
				int unicodeIndex = workbookTemp.getXSSFWorkbook().getSheetIndex(Hana_Profiler_Constant.NON_UNICODE);
				SXSSFSheet unicodeEnagasSheet = workbookTemp.getSheetAt(unicodeIndex);
				writeUnicodeSheet(unicodeEnagasSheet, requestID);
				tabScopeWise.add(Hana_Profiler_Constant.NON_UNICODE);
			}

			if (scopeS4 || scopeBWTech) {
				// Writing Inconsistent Function Groups Sheet
				int functionGRPsIndex = workbookTemp.getXSSFWorkbook()
						.getSheetIndex(Hana_Profiler_Constant.FUNCTIONAL_GROUPS);
				SXSSFSheet inconsistentFUGRSheet = workbookTemp.getSheetAt(functionGRPsIndex);
				writeInconsistentFUGRSheet(inconsistentFUGRSheet, requestID);
				tabScopeWise.add(Hana_Profiler_Constant.FUNCTIONAL_GROUPS);
			}

			if (scopeHana || scopeS4 || scopeOSMigration || scopeBWTech || scopeAUCT) {
				// Writing Impacted due to Hardcoding Sheet
				int hardcodingIndex = workbookTemp.getXSSFWorkbook().getSheetIndex(Hana_Profiler_Constant.HARDCODINGS);
				SXSSFSheet s4SIDSheet = workbookTemp.getSheetAt(hardcodingIndex);
				writeS4SIDSheet(s4SIDSheet, requestID);
				tabScopeWise.add(Hana_Profiler_Constant.HARDCODINGS);
			}

			if (scopeBWTech) {
				// Writing Bw Inventory Sheet
				int bwInventoryIndex = workbookTemp.getXSSFWorkbook()
						.getSheetIndex(Hana_Profiler_Constant.BW_INVENTORY);
				SXSSFSheet bwInvSheet = workbookTemp.getSheetAt(bwInventoryIndex);
				writeBwInventorySheet(bwInvSheet, requestID);
				tabScopeWise.add(Hana_Profiler_Constant.BW_INVENTORY);
			}

			if (scopeS4 || scopeBWTech) {
				// Writing Fiori Output Sheet
				int fioriIndex = workbookTemp.getXSSFWorkbook().getSheetIndex(Hana_Profiler_Constant.FIORI);
				SXSSFSheet fioriOutputSheet = workbookTemp.getSheetAt(fioriIndex);
				String sheetName = workbookTemp.getSheetName(fioriIndex);
				workbookTemp.setSheetName(fioriIndex, sheetName + "_" + target);
				writeFioriOutputSheet(fioriOutputSheet, requestID, requestForm);
				tabScopeWise.add(Hana_Profiler_Constant.FIORI + "_" + target);
			}

			if (scopeHana || scopeS4 || scopeOSMigration || scopeBWTech) {
				// Writing Impacted Variant Sheet
				int impactedVariantIndex = workbookTemp.getXSSFWorkbook()
						.getSheetIndex(Hana_Profiler_Constant.IMPACTED_VARIANT);
				SXSSFSheet impactedVariantSheet = workbookTemp.getSheetAt(impactedVariantIndex);
				writeImpactedVariantSheet(impactedVariantSheet, requestID);
				tabScopeWise.add(Hana_Profiler_Constant.IMPACTED_VARIANT);
			}

			if (scopeS4 || scopeBWTech) {
				// Writing Bw Cleanup Sheet
				int bwCleanUpIndex = workbookTemp.getXSSFWorkbook().getSheetIndex(Hana_Profiler_Constant.BW_CLEANUP);
				SXSSFSheet bwCleanupUtilSheet = workbookTemp.getSheetAt(bwCleanUpIndex);
				writeBwCleanUpUtilSheet(bwCleanupUtilSheet, requestID);
				tabScopeWise.add(Hana_Profiler_Constant.BW_CLEANUP);
			}

			if (scopeS4 || scopeBWTech) {
				// Writing S4 Impacted Custom Table Sheet
				int customTablesIndex = workbookTemp.getXSSFWorkbook()
						.getSheetIndex(Hana_Profiler_Constant.CUSTOM_TABLES);
				XSSFSheet impCustTableSheet = workbookTemp.getXSSFWorkbook().getSheetAt(customTablesIndex);
				writeS4ImpactedCustomTablesSheet(impCustTableSheet, requestID, requestForm);
				tabScopeWise.add(Hana_Profiler_Constant.CUSTOM_TABLES);
			}

			if (scopeBWTech) {
				// Writing BW Standard Extract Sheet
				int bwStandardIndex = workbookTemp.getXSSFWorkbook().getSheetIndex(Hana_Profiler_Constant.BW_STANDARD);
				SXSSFSheet bwStdExtrSheet = workbookTemp.getSheetAt(bwStandardIndex);
				writeBwSTandardExtractSheet(bwStdExtrSheet, requestID);
				tabScopeWise.add(Hana_Profiler_Constant.BW_STANDARD);
			}

			if (scopeAUCT || scopeHana || scopeS4 || scopeOSMigration || scopeBWTech) {
				// Writing Inactive Objects Sheet
				int inactiveObjectsIndex = workbookTemp.getXSSFWorkbook()
						.getSheetIndex(Hana_Profiler_Constant.INACTIVE_OBJECTS);
				SXSSFSheet inaObjectsSheet = workbookTemp.getSheetAt(inactiveObjectsIndex);
				writeInactiveObjectsSheet(inaObjectsSheet, requestID);
				tabScopeWise.add(Hana_Profiler_Constant.INACTIVE_OBJECTS);
			}

			if (scopeS4) {
				int drillDownReportIndex = workbookTemp.getXSSFWorkbook()
						.getSheetIndex(Hana_Profiler_Constant.DRILL_DOWN_REPORT);

				SXSSFSheet drilldownReport = workbookTemp.getSheetAt(drillDownReportIndex);
				writeDrillDownReport(drilldownReport, requestID);
				tabScopeWise.add(Hana_Profiler_Constant.DRILL_DOWN_REPORT);

				int obsoleteReportIndex = workbookTemp.getXSSFWorkbook()
						.getSheetIndex(Hana_Profiler_Constant.OBSOLETE_FMs);

				SXSSFSheet obsoleteReport = workbookTemp.getSheetAt(obsoleteReportIndex);
				writeObsoleteFmsUpgradeReport(obsoleteReport, requestID);
				tabScopeWise.add(Hana_Profiler_Constant.OBSOLETE_FMs);
			}

			/*
			 * // Writing Estimations Sheets if
			 * (Hana_Profiler_Constant.ACCESS_TRUE.equalsIgnoreCase(userAccess)
			 * && Hana_Profiler_Constant.ADMIN.equalsIgnoreCase(userRole)) {
			 * XSSFSheet hanaEstimatorSheet =
			 * workbookTemp.getXSSFWorkbook().getSheetAt(23);
			 * wroteEstimationsSheetForAdmin(requestID, hanaEstimatorSheet);
			 * 
			 * // Writing DR_S4 Simplification-2 XSSFSheet detailReport2Sheet =
			 * workbookTemp.getXSSFWorkbook().getSheetAt(21);
			 * writedetailReport2Sheet(detailReport2Sheet, requestID);
			 * 
			 * // Writing DR_S4 Simplification-3 XSSFSheet detailReport3Sheet =
			 * workbookTemp.getXSSFWorkbook().getSheetAt(22);
			 * writedetailReport3Sheet(detailReport3Sheet, requestID);
			 * 
			 * } else if
			 * (Hana_Profiler_Constant.ACCESS_TRUE.equalsIgnoreCase(userAccess)
			 * && Hana_Profiler_Constant.CLIENT.equalsIgnoreCase(userRole)) { //
			 * Writing DR_S4 Simplification-2 XSSFSheet detailReport2Sheet =
			 * workbookTemp.getXSSFWorkbook().getSheetAt(21);
			 * writedetailReport2Sheet(detailReport2Sheet, requestID);
			 * 
			 * // Writing DR_S4 Simplification-3 XSSFSheet detailReport3Sheet =
			 * workbookTemp.getXSSFWorkbook().getSheetAt(22);
			 * writedetailReport3Sheet(detailReport3Sheet, requestID);
			 * 
			 * XSSFSheet EstimatorSheet =
			 * workbookTemp.getXSSFWorkbook().getSheetAt(23);
			 * wroteEstimationsSheetForClient(requestID, EstimatorSheet); //
			 * Writing Assumptions Sheets XSSFSheet assumptionSheet =
			 * workbookTemp.getXSSFWorkbook().getSheetAt(24);
			 * wroteAssumptionSheetForClient(requestID, assumptionSheet); }
			 */
			int sheetCount = workbookTemp.getNumberOfSheets();
			for (int i = sheetCount - 1; i >= 0; i--) {
				boolean keep = false;

				for (String tab : tabScopeWise) {
					int indexSheet = workbookTemp.getXSSFWorkbook().getSheetIndex(tab);
					if (i == indexSheet)
						keep = true;
				}
				if (!keep) {
					workbookTemp.removeSheetAt(i);

				}
			}

			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			workbookTemp.write(bos);
			bos.close();

			byte[] bytes = bos.toByteArray();
			getFileDownload().downloadFile(bytes, response,
					HANAUtility.join("_", "AADT Profiler", requestForm.getClientName(), requestForm.getSourceVersion(),
							requestForm.getTargetVersion(), requestID.toString()) + ".xlsx");
			if (Hana_Profiler_Constant.POC.equalsIgnoreCase(userRole)) {
				getRequestInventorydao().updateFinalFileDownloadStatus(requestID, getPrincipal(), true);
				RequestInventory reqInvObj = getRequestInventorydao().getRequestFromRequestId(new Long(requestID));

				/*
				 * if(!requestForm.getSia() && !requestForm.getRFP() &&
				 * reqInvObj.getFinalFileDnldSts()){ logger.
				 * info(":: Inside the scopes and download bits condition :: ");
				 * getRequestInventorydao().updatePOCStatusAndSubStatus(Long.
				 * valueOf(requestID), getPrincipal(), "Final_DOWN_DONE_POC",
				 * Hana_Profiler_Constant.REQ_SS_PROCESSED_FL_DL_SUCC); } if
				 * (requestForm.getSia() && requestForm.getSOH() ||
				 * requestForm.getFiori() || requestForm.getS4Functional() ||
				 * requestForm.getS4Technical() || requestForm.getUI5() ||
				 * requestForm.getUPGRADE()) { if(reqInvObj.getSaFileDnldSts()
				 * && reqInvObj.getFinalFileDnldSts()){
				 * getRequestInventorydao().updatePOCStatusAndSubStatus(Long.
				 * valueOf(requestID), getPrincipal(), "Final_DOWN_DONE_POC",
				 * Hana_Profiler_Constant.REQ_SS_PROCESSED_FL_DL_SUCC); } }
				 */
				setPocStausAfterFileDownload(requestForm, requestID, getPrincipal(), reqInvObj);
			}
		} catch (ReqIDNotValidException ex) {
			model.addAttribute("errorMsg", ex.getMessage());
			return "errors";
		} catch (Exception e) {
			logger.error("Error in Downloading the final file :: ", e);
		}

		return null;
	}

	@RequestMapping(value = "/downloadBWExtractReport/{requestID}/{userRole}/{userAccess}", method = RequestMethod.GET)
	private String downloadBWExtractReport(@PathVariable("requestID") Long requestID,
			@PathVariable("userAccess") final String userAccess, @PathVariable("userRole") final String userRole,
			Model model, HttpServletResponse response, HttpServletRequest request,
			final RedirectAttributes redirectAttributes) throws Exception {
		try {
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestID));
			RequestID_Validator_Utility.chckReqIdUser(reqIDValid.getCreator(reqIDValid.getRequestInv(requestID)),
					getPrincipal());

			final RequestForm requestForm = getRequestDetails().getRequestObj(requestID);

			String target = requestForm.getTargetVersion();

			String graphTemplete = "";

			graphTemplete = request.getSession().getServletContext()
					.getRealPath("/staticResources/GraphTemplate/BW_Extract_Report.xlsx");

			ZipSecureFile.setMinInflateRatio(-1.0d);

			XSSFWorkbook workbook = new XSSFWorkbook(OPCPackage.open(new FileInputStream(graphTemplete)));
			@SuppressWarnings("resource")
			SXSSFWorkbook workbookTemp = new SXSSFWorkbook(workbook);
			workbookTemp.setCompressTempFiles(true);

			// Writing Extensibility sheet
			SXSSFSheet bwExtractTab2Sheet = workbookTemp.getSheetAt(1);
			SXSSFSheet bwExtractTab3Sheet = workbookTemp.getSheetAt(2);

			writeBwExtractTab2Sheet(bwExtractTab2Sheet, bwExtractTab3Sheet, requestID);

			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			workbookTemp.write(bos);
			bos.close();

			byte[] bytes = bos.toByteArray();
			getFileDownload().downloadFile(bytes, response,
					HANAUtility.join("_", "BWExtract_Report", requestForm.getClientName(),
							requestForm.getSourceVersion(), requestForm.getTargetVersion(), requestID.toString())
							+ ".xlsx");

			if (Hana_Profiler_Constant.POC.equalsIgnoreCase(userRole)) {
				getRequestInventorydao().updateFinalFileDownloadStatus(requestID, getPrincipal(), true);
				RequestInventory reqInvObj = getRequestInventorydao().getRequestFromRequestId(new Long(requestID));

				setPocStausAfterFileDownload(requestForm, requestID, getPrincipal(), reqInvObj);
			}
		} catch (ReqIDNotValidException ex) {
			model.addAttribute("errorMsg", ex.getMessage());
			return "errors";
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return null;
	}

	@RequestMapping(value = "/downloadExtReport/{requestID}/{userRole}/{userAccess}", method = RequestMethod.GET)
	private String downloadExtReport(@PathVariable("requestID") Long requestID,
			@PathVariable("userAccess") final String userAccess, @PathVariable("userRole") final String userRole,
			Model model, HttpServletResponse response, HttpServletRequest request,
			final RedirectAttributes redirectAttributes) throws Exception {
		try {
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestID));
			RequestID_Validator_Utility.chckReqIdUser(reqIDValid.getCreator(reqIDValid.getRequestInv(requestID)),
					getPrincipal());

			final RequestForm requestForm = getRequestDetails().getRequestObj(requestID);

			String target = requestForm.getTargetVersion();
			if (target.startsWith("S/4")) {
				target = target.replace("/", "");
			}

			String graphTemplete = "";

			graphTemplete = request.getSession().getServletContext()
					.getRealPath("/staticResources/GraphTemplate/Extensibility_Report.xlsx");

			ZipSecureFile.setMinInflateRatio(-1.0d);

			XSSFWorkbook workbook = new XSSFWorkbook(OPCPackage.open(new FileInputStream(graphTemplete)));
			@SuppressWarnings("resource")
			SXSSFWorkbook workbookTemp = new SXSSFWorkbook(workbook);
			workbookTemp.setCompressTempFiles(true);

			// Writing Extensibility sheet
			SXSSFSheet extensibilitySheet = workbookTemp.getSheetAt(0);
			writeExtensibilitySheet(extensibilitySheet, requestID, workbookTemp);
			SXSSFSheet impactedCloneSheet = workbookTemp.getSheetAt(1);
			writeImpactedCloneSheetForExt(impactedCloneSheet, requestID);
			SXSSFSheet fioriOutputSheet = workbookTemp.getSheetAt(2);
			String sheetName = workbookTemp.getSheetName(2);
			workbookTemp.setSheetName(2, sheetName + "_" + target);
			writeFioriOutputSheet(fioriOutputSheet, requestID, requestForm);

			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			workbookTemp.write(bos);
			bos.close();

			byte[] bytes = bos.toByteArray();
			getFileDownload().downloadFile(bytes, response,
					HANAUtility.join("_", "Extensibility_Report", requestForm.getClientName(),
							requestForm.getSourceVersion(), requestForm.getTargetVersion(), requestID.toString())
							+ ".xlsx");

			if (Hana_Profiler_Constant.POC.equalsIgnoreCase(userRole)) {
				getRequestInventorydao().updateFinalFileDownloadStatus(requestID, getPrincipal(), true);
				RequestInventory reqInvObj = getRequestInventorydao().getRequestFromRequestId(new Long(requestID));

				setPocStausAfterFileDownload(requestForm, requestID, getPrincipal(), reqInvObj);
			}
		} catch (ReqIDNotValidException ex) {
			model.addAttribute("errorMsg", ex.getMessage());
			return "errors";
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return null;
	}

	@RequestMapping(value = "/downloadTestingScopeReport/{requestID}/{userRole}/{userAccess}", method = RequestMethod.GET)
	public String downloadTestingScopeReport(@PathVariable("requestID") Long requestID,
			@PathVariable("userAccess") String userAccess, @PathVariable("userRole") String userRole, Model model,
			HttpServletResponse response, HttpServletRequest request) throws Exception {
		try {
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestID));
			RequestID_Validator_Utility.chckReqIdUser(reqIDValid.getCreator(reqIDValid.getRequestInv(requestID)),
					getPrincipal());

			RequestForm requestForm = getRequestDetails().getRequestObj(requestID);

			String graphTemplete = request.getSession().getServletContext()
					.getRealPath("/staticResources/GraphTemplate/TestingScope_Report.xlsm");

			XSSFWorkbook workbook = new XSSFWorkbook(OPCPackage.open(new FileInputStream(graphTemplete)));
			@SuppressWarnings("resource")
			SXSSFWorkbook workbookTemp = new SXSSFWorkbook(workbook);
			workbookTemp.setCompressTempFiles(true);

			// Writing Input Sheet for Count of Test Scripts
			writeTestScriptCountSheet(requestID, workbookTemp);

			// Writing IRPA Complete Sheet
			writeIRPATScopeReportSheet(requestID, workbookTemp);

			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			workbookTemp.write(bos);
			bos.close();

			byte[] bytes = bos.toByteArray();
			getFileDownload().downloadFile(bytes, response,
					HANAUtility.join("_", "TestingScope_Report", requestForm.getClientName(),
							requestForm.getSourceVersion(), requestForm.getTargetVersion(), requestID.toString())
							+ ".xlsm");
		} catch (ReqIDNotValidException ex) {
			model.addAttribute("errorMsg", ex.getMessage());
			return "errors";
		} catch (Exception e) {
			logger.error("Error while downloading Testing Scope Report ...", e);
			throw new Exception();
		}

		return null;
	}

	// Downloading IRPA TScope Estimates Report
	@RequestMapping(value = "/downloadTestingScopeEstimatesReport/{requestID}", method = RequestMethod.GET)
	public String downloadTScopeEstimates(@PathVariable("requestID") Long requestID, Model model,
			HttpServletResponse response, HttpServletRequest request) throws Exception {
		try {
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestID));
			RequestID_Validator_Utility.chckReqIdUser(reqIDValid.getCreator(reqIDValid.getRequestInv(requestID)),
					getPrincipal());

			RequestForm requestForm = getRequestDetails().getRequestObj(requestID);

			String graphTemplete = request.getSession().getServletContext()
					.getRealPath("/staticResources/GraphTemplate/TestingScope_Estimates_Report.xlsx");

			XSSFWorkbook workbook = new XSSFWorkbook(OPCPackage.open(new FileInputStream(graphTemplete)));
			@SuppressWarnings("resource")
			SXSSFWorkbook workbookTemp = new SXSSFWorkbook(workbook);
			workbookTemp.setCompressTempFiles(true);

			IRPATScopeEstimates estimatesObj = getTestingScopeService().getIRPAEstimates(requestID);

			// Writing Input Sheet for Count of Test Scripts
			writeIRPAInventorySheet(requestID, workbookTemp, estimatesObj);

			// Writing IRPA Complete Sheet
			writeIRPAEstimationSheet(requestID, workbookTemp, estimatesObj);

			// Evaluating all the formulas
			XSSFFormulaEvaluator.evaluateAllFormulaCells(workbook);

			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			workbookTemp.write(bos);
			bos.close();

			byte[] bytes = bos.toByteArray();
			getFileDownload().downloadFile(bytes, response,
					HANAUtility.join("_", "TestingScope_Estimates_Report", requestForm.getClientName(),
							requestForm.getSourceVersion(), requestForm.getTargetVersion(), requestID.toString())
							+ ".xlsx");
		} catch (ReqIDNotValidException ex) {
			model.addAttribute("errorMsg", ex.getMessage());
			return "errors";
		} catch (Exception e) {
			logger.error("Error while downloading Testing Scope Estimates Report ...", e);
			throw new Exception();
		}

		return null;
	}

	// Writing Inventory sheet
	private void writeInventory(SXSSFSheet inventorySheet, Long requestID) {
		int rowIndex = 1;
		List<InventoryList_Download> inventoryList = getGraphS4DAO().getInventory(requestID);
		Boolean trReqHidden = true;
		if (null != inventoryList && !inventoryList.isEmpty()) {
			Iterator<InventoryList_Download> inventoryItr = inventoryList.iterator();
			while (inventoryItr.hasNext()) {

				InventoryList_Download inventory = inventoryItr.next();
				Row inventryRow = inventorySheet.createRow(rowIndex);

				inventryRow.createCell(0).setCellValue(inventory.getRicefCategory());
				inventryRow.createCell(1).setCellValue(inventory.getRicefSubCategory());
				inventryRow.createCell(2).setCellValue(inventory.getObjType());
				inventryRow.createCell(3).setCellValue(inventory.getObjName());
				inventryRow.createCell(4).setCellValue(inventory.getUsage());
				inventryRow.createCell(5).setCellValue(inventory.getUsageCount());
				// inventryRow.createCell(6).setCellValue(inventory.getProfilerUsed());
				inventryRow.createCell(6).setCellValue(inventory.getStandMod());
				inventryRow.createCell(7).setCellValue(inventory.getExtNamespace());
				inventryRow.createCell(8).setCellValue(inventory.getCountLines());
				inventryRow.createCell(9).setCellValue(inventory.getTransReq());
				inventryRow.createCell(10).setCellValue(inventory.getCreatedBy());
				inventryRow.createCell(11).setCellValue(inventory.getCreatedOn());
				inventryRow.createCell(12).setCellValue(inventory.getChangedBy());
				inventryRow.createCell(13).setCellValue(inventory.getChangedOn());
				inventryRow.createCell(14).setCellValue(inventory.getTr());
				inventryRow.createCell(15).setCellValue(inventory.getTrStatus());

				if (inventory.getTransReq() != null
						&& !(inventory.getTransReq().isEmpty() || inventory.getTransReq().equals("")) && trReqHidden)
					trReqHidden = false;
				rowIndex++;
			}
		}
		inventorySheet.setColumnHidden(9, trReqHidden);
		logger.info("Sucessfully Wrote Inventory Sheet:::%%%%%%%");
	}

	// Writing ABAP Inventory sheet
	private void writeInventoryABAP(SXSSFSheet inventorySheet, Long requestID) {
		int rowIndex = 1;
		List<ABAPQueryInventoryDownload> inventoryList = getGraphS4DAO().getInventoryABAP(requestID);
		Boolean trReqHidden = true;
		if (null != inventoryList && !inventoryList.isEmpty()) {
			Iterator<ABAPQueryInventoryDownload> inventoryItr = inventoryList.iterator();
			while (inventoryItr.hasNext()) {

				ABAPQueryInventoryDownload inventory = inventoryItr.next();
				Row inventryRow = inventorySheet.createRow(rowIndex);

				inventryRow.createCell(0).setCellValue(inventory.getRicefCategory());
				inventryRow.createCell(1).setCellValue(inventory.getRicefSubCategory());
				inventryRow.createCell(2).setCellValue(inventory.getObjType());
				inventryRow.createCell(3).setCellValue(inventory.getUserGroup());
				inventryRow.createCell(4).setCellValue(inventory.getABAPQuery());
				// inventryRow.createCell(3).setCellValue(inventory.getObjName());
				inventryRow.createCell(5).setCellValue(inventory.getUsage());
				inventryRow.createCell(6).setCellValue(inventory.getUsageCount());
				inventryRow.createCell(7).setCellValue(inventory.getExtNamespace());
				inventryRow.createCell(8).setCellValue(inventory.getCountLines());
				inventryRow.createCell(9).setCellValue(inventory.getTransReq());

				if (inventory.getTransReq() != null
						&& !(inventory.getTransReq().isEmpty() || inventory.getTransReq().equals("")) && trReqHidden)
					trReqHidden = false;
				rowIndex++;
			}
		}
		inventorySheet.setColumnHidden(9, trReqHidden);
		logger.info("Sucessfully Wrote ABAP Inventory Sheet:::%%%%%%%");
	}

	// Writing ACNIPZVERComp sheet
	private void writeACNIPZVERCompSheet(SXSSFSheet zcnipzverCompSheet, Long requestID) {
		int rowIndex = 1;
		List<ACNIPZVERComp> acnipzverCompList = getGraphS4DAO().getACNIPZVERComp(requestID);

		if (null != acnipzverCompList && !acnipzverCompList.isEmpty()) {
			Iterator<ACNIPZVERComp> ACNIPZVERCompItr = acnipzverCompList.iterator();
			while (ACNIPZVERCompItr.hasNext()) {

				ACNIPZVERComp zcnipzverComp = ACNIPZVERCompItr.next();
				Row zcnipzverCompRow = zcnipzverCompSheet.createRow(rowIndex);

				zcnipzverCompRow.createCell(0).setCellValue(zcnipzverComp.getRicefCategory());
				zcnipzverCompRow.createCell(1).setCellValue(zcnipzverComp.getRicefSubCategory());
				zcnipzverCompRow.createCell(2).setCellValue(zcnipzverComp.getMandt());
				zcnipzverCompRow.createCell(3).setCellValue(zcnipzverComp.getSessionId());
				zcnipzverCompRow.createCell(4).setCellValue(zcnipzverComp.getSerialNo());
				zcnipzverCompRow.createCell(5).setCellValue(zcnipzverComp.getNamespace());
				zcnipzverCompRow.createCell(6).setCellValue(zcnipzverComp.getObjectR3TR());
				zcnipzverCompRow.createCell(7).setCellValue(zcnipzverComp.getObjNameR3TR());
				zcnipzverCompRow.createCell(8).setCellValue(zcnipzverComp.getObject());
				zcnipzverCompRow.createCell(9).setCellValue(zcnipzverComp.getObjName());
				zcnipzverCompRow.createCell(10).setCellValue(zcnipzverComp.getCreateDate());
				zcnipzverCompRow.createCell(11).setCellValue(zcnipzverComp.getChangeDate());
				zcnipzverCompRow.createCell(12).setCellValue(zcnipzverComp.getDevClass());
				zcnipzverCompRow.createCell(13).setCellValue(zcnipzverComp.getCodeSize());
				zcnipzverCompRow.createCell(14).setCellValue(zcnipzverComp.getVersionCount());
				zcnipzverCompRow.createCell(15).setCellValue(zcnipzverComp.getRefInfosap());
				zcnipzverCompRow.createCell(16).setCellValue(zcnipzverComp.getRefTypeTextsap());
				zcnipzverCompRow.createCell(17).setCellValue(zcnipzverComp.getLastTransport());
				zcnipzverCompRow.createCell(18).setCellValue(zcnipzverComp.getLastTransportRfc());
				zcnipzverCompRow.createCell(19).setCellValue(zcnipzverComp.getObject1());
				zcnipzverCompRow.createCell(20).setCellValue(zcnipzverComp.getObjName1());
				zcnipzverCompRow.createCell(21).setCellValue(zcnipzverComp.getLength1());
				zcnipzverCompRow.createCell(22).setCellValue(zcnipzverComp.getCntVers1());
				zcnipzverCompRow.createCell(23).setCellValue(zcnipzverComp.getIconComp());
				zcnipzverCompRow.createCell(24).setCellValue(zcnipzverComp.getObject2());
				zcnipzverCompRow.createCell(25).setCellValue(zcnipzverComp.getObjName2());
				zcnipzverCompRow.createCell(26).setCellValue(zcnipzverComp.getLength2());
				zcnipzverCompRow.createCell(27).setCellValue(zcnipzverComp.getCntVers2());
				zcnipzverCompRow.createCell(28).setCellValue(zcnipzverComp.getRfcDest2());
				zcnipzverCompRow.createCell(29).setCellValue(zcnipzverComp.getRecordDate());
				zcnipzverCompRow.createCell(30).setCellValue(zcnipzverComp.getRecordTime());

				rowIndex++;
			}
		}
		logger.info("Sucessfully Wrote ACNIPZVERComp Sheet:::%%%%%%%");
	}

	// Writing DR_DB_Change Sheet
	private void wroteDbChange(SXSSFSheet inventorySheet, List<HanaProfile_Download> inventoryList) {

		// Map<String, String> errorType =
		// getGraphDao().getOperation_ErrorMap();
		// Map<String, String> secondSubCat = getGraphDao().getSecond_SubCat();
		// for not adding data on inventory sheet for these Opcodes
		int j = 0;
		Row inventoryRow;
		for (int i = 0; i < inventoryList.size(); i++) {

			// for not displaying data,for the required Opertion codes on sheet
			if (!inventoryList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_59)
					&& !inventoryList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_60)
					&& !inventoryList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_61)
					&& !inventoryList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_62)
					&& !inventoryList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_63)
					&& !inventoryList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_64)
					&& !inventoryList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_65)
					&& !inventoryList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_66)
					&& !inventoryList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_72)
					&& !inventoryList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_74)
					&& !inventoryList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_75)
					&& !inventoryList.get(i).getOperation_code().equals(Hana_Profiler_Constant.op_Code_76)) {
				inventoryRow = inventorySheet.createRow(++j);

				inventoryRow.createCell(0).setCellValue(inventoryList.get(i).getRicefCategory());
				inventoryRow.createCell(1).setCellValue(inventoryList.get(i).getRicefSubCategory());
				inventoryRow.createCell(2).setCellValue(inventoryList.get(i).getObject_Type());
				inventoryRow.createCell(3).setCellValue(inventoryList.get(i).getObj_Name());
				inventoryRow.createCell(4).setCellValue(inventoryList.get(i).getSub_Type());
				inventoryRow.createCell(5).setCellValue(inventoryList.get(i).getReadProgram());
				inventoryRow.createCell(6).setCellValue(inventoryList.get(i).getOBJ_PACKAGE());
				inventoryRow.createCell(7).setCellValue(inventoryList.get(i).getOpertaion());
				inventoryRow.createCell(8).setCellValue(inventoryList.get(i).getLine_Number());
				inventoryRow.createCell(9).setCellValue(inventoryList.get(i).getCode());
				inventoryRow.createCell(10).setCellValue(inventoryList.get(i).getCategory());
				inventoryRow.createCell(11).setCellValue(inventoryList.get(i).getSubcategory());
				inventoryRow.createCell(12).setCellValue(inventoryList.get(i).getIssueSecondSubCat());
				inventoryRow.createCell(13).setCellValue(inventoryList.get(i).getInfo());
				inventoryRow.createCell(14).setCellValue(inventoryList.get(i).getHigh_lvl_desc());
				inventoryRow.createCell(15).setCellValue(inventoryList.get(i).getLevels());
				inventoryRow.createCell(16).setCellValue(inventoryList.get(i).getTables());
				inventoryRow.createCell(17).setCellValue(inventoryList.get(i).getJoins());
				inventoryRow.createCell(18).setCellValue(inventoryList.get(i).getTable_Type());
				inventoryRow.createCell(19).setCellValue(inventoryList.get(i).getWhere_Condition());
				inventoryRow.createCell(20).setCellValue(inventoryList.get(i).getJoin_Type());
				inventoryRow.createCell(21).setCellValue(inventoryList.get(i).getImpact());

				if (null != inventoryList.get(i).getAutomation_status()) {
					inventoryRow.createCell(22).setCellValue(inventoryList.get(i).getAutomation_status());
				} else {
					inventoryRow.createCell(22).setCellValue("");
				}
				inventoryRow.createCell(23).setCellValue(inventoryList.get(i).getCOMPLEXITY());
				inventoryRow.createCell(24).setCellValue(inventoryList.get(i).getOperation_code());
				// DEF042
				inventoryRow.createCell(25).setCellValue(inventoryList.get(i).getUsed_Unused());
				// DEF041
				inventoryRow.createCell(26).setCellValue(inventoryList.get(i).getSkipReason());
				inventoryRow.createCell(27).setCellValue(inventoryList.get(i).getSkip());
				inventoryRow.createCell(28).setCellValue(inventoryList.get(i).getSel_Line());
				inventoryRow.createCell(29).setCellValue(inventoryList.get(i).getExtNamespace());
			}
		}

		logger.info("Sucessfully Wrote DR_DB_Change sheet:::%%%%%%%");
	}

	// Writing DR_S4 Simplification Sheet
	private void wroteS4Simplification(SXSSFSheet detailReportSheet, List<S4HanaProfiler_Download> finalOutputList) {
		int j = 0;
		for (int i = 0; i < finalOutputList.size(); i++) {
			Row detailReportRow = detailReportSheet.createRow(++j);

			detailReportRow.createCell(0).setCellValue(finalOutputList.get(i).getRicefCategory());
			detailReportRow.createCell(1).setCellValue(finalOutputList.get(i).getRicefSubCategory());
			detailReportRow.createCell(2).setCellValue(finalOutputList.get(i).getType());
			detailReportRow.createCell(3).setCellValue(finalOutputList.get(i).getObjName());
			detailReportRow.createCell(4).setCellValue(finalOutputList.get(i).getMethod());
			detailReportRow.createCell(5).setCellValue(finalOutputList.get(i).getREAD_PROG());
			detailReportRow.createCell(6).setCellValue(finalOutputList.get(i).getPckg());
			detailReportRow.createCell(7).setCellValue(finalOutputList.get(i).getOperations());
			detailReportRow.createCell(8).setCellValue(finalOutputList.get(i).getLineNo());
			detailReportRow.createCell(9).setCellValue(finalOutputList.get(i).getStmt());
			detailReportRow.createCell(10).setCellValue(finalOutputList.get(i).getImpactedObjType());
			detailReportRow.createCell(11).setCellValue(finalOutputList.get(i).getImpactReason());
			detailReportRow.createCell(12).setCellValue(finalOutputList.get(i).getDescOfChange());
			detailReportRow.createCell(13).setCellValue(finalOutputList.get(i).getSapNotes());
			detailReportRow.createCell(14).setCellValue(finalOutputList.get(i).getSolutionSteps());
			detailReportRow.createCell(15).setCellValue(finalOutputList.get(i).getComplexity());

			detailReportRow.createCell(16).setCellValue(finalOutputList.get(i).getImpact());

			detailReportRow.createCell(17).setCellValue(finalOutputList.get(i).getIssueCategory());

			detailReportRow.createCell(18).setCellValue(finalOutputList.get(i).getErrorCategory());

			detailReportRow.createCell(19).setCellValue(finalOutputList.get(i).getTriggerObj());
			// detailReportRow.createCell(19).setCellValue(finalOutputList.get(i).getTrigger_Object());
			detailReportRow.createCell(20).setCellValue(finalOutputList.get(i).getRemediationCategory());
			detailReportRow.createCell(21).setCellValue(finalOutputList.get(i).getSapSimpListChapter());
			detailReportRow.createCell(22).setCellValue(finalOutputList.get(i).getApplicationComponent());
			detailReportRow.createCell(23).setCellValue(finalOutputList.get(i).getSapSimplCategry());
			detailReportRow.createCell(24).setCellValue(finalOutputList.get(i).getItemArea());
			// DEF042
			detailReportRow.createCell(25).setCellValue(finalOutputList.get(i).getSELECT_LINE());
			detailReportRow.createCell(26).setCellValue(finalOutputList.get(i).getUsed());
			detailReportRow.createCell(27).setCellValue(finalOutputList.get(i).getCorProgName());
			detailReportRow.createCell(28).setCellValue(finalOutputList.get(i).getCorLineNo());
			detailReportRow.createCell(29).setCellValue(finalOutputList.get(i).getAutomationStatus());
			detailReportRow.createCell(30).setCellValue(finalOutputList.get(i).getToolVersion());
			detailReportRow.createCell(31).setCellValue(finalOutputList.get(i).getExtNamespace());
		}
		detailReportSheet.setColumnHidden(16, true);

		logger.info("Sucessfully Wrote DR_S4 Simplification Sheet:::%%%%%%%");
	}

	// Writing DR_Fiori Sheet
	/*
	 * private void wroteDR_Fiori(SXSSFSheet DR_FioriSheet,
	 * List<InventoryStandardFiori> DR_FioriList) { int rowIndex = 1; if (null
	 * != DR_FioriList && !DR_FioriList.isEmpty()) {
	 * Iterator<InventoryStandardFiori> OdataObjItr = DR_FioriList.iterator();
	 * while (OdataObjItr.hasNext()) {
	 * 
	 * InventoryStandardFiori odataObj = OdataObjItr.next(); Row DR_FioriRow =
	 * DR_FioriSheet.createRow(rowIndex);
	 * 
	 * DR_FioriRow.createCell(0).setCellValue(odataObj.getSessioId());
	 * DR_FioriRow.createCell(1).setCellValue(odataObj.getObject());
	 * DR_FioriRow.createCell(2).setCellValue(odataObj.getObjName());
	 * DR_FioriRow.createCell(3).setCellValue(odataObj.getSubtype());
	 * DR_FioriRow.createCell(4).setCellValue(odataObj.getAppId());
	 * DR_FioriRow.createCell(5).setCellValue(odataObj.getAppsTypeCombined());
	 * DR_FioriRow.createCell(6).setCellValue(odataObj.getPcdCombined());
	 * DR_FioriRow.createCell(7).setCellValue(odataObj.getAppName());
	 * rowIndex++; } }
	 * logger.info("Sucessfully Wrote DR_Fiori Sheet:::%%%%%%%"); }
	 */

	private void wroteDR_Fiori(XSSFSheet DR_FioriSheet, List<InventoryStandardFiori> DR_FioriList) {
		int rowIndex = 1;
		if (null != DR_FioriList && !DR_FioriList.isEmpty()) {
			Iterator<InventoryStandardFiori> OdataObjItr = DR_FioriList.iterator();
			while (OdataObjItr.hasNext()) {

				InventoryStandardFiori odataObj = OdataObjItr.next();
				Row DR_FioriRow = DR_FioriSheet.createRow(rowIndex);

				DR_FioriRow.createCell(0).setCellValue(odataObj.getAppId());
				DR_FioriRow.createCell(1).setCellValue(odataObj.getAppName());
				DR_FioriRow.createCell(2).setCellValue(odataObj.getAvailability());
				DR_FioriRow.createCell(3).setCellValue(odataObj.getSuccessorAppId());
				DR_FioriRow.createCell(4).setCellValue(odataObj.getRelatedAppId());
				rowIndex++;
			}
		}
		logger.info("Sucessfully Wrote DR_Fiori Sheet:::%%%%%%%");
	}

	private void wroteCustomReportFiori(XSSFSheet DR_FioriSheet, List<CustomReportOutput_download> DR_FioriList) {
		int rowIndex = 1;
		if (null != DR_FioriList && !DR_FioriList.isEmpty()) {
			Iterator<CustomReportOutput_download> OdataObjItr = DR_FioriList.iterator();
			while (OdataObjItr.hasNext()) {

				CustomReportOutput_download odataObj = OdataObjItr.next();
				Row DR_FioriRow = DR_FioriSheet.createRow(rowIndex);

				DR_FioriRow.createCell(0).setCellValue(odataObj.getFioriId());
				DR_FioriRow.createCell(1).setCellValue(odataObj.getAppName());
				DR_FioriRow.createCell(2).setCellValue(odataObj.getAvailability());
				DR_FioriRow.createCell(3).setCellValue(odataObj.getSuccessorApp());
				DR_FioriRow.createCell(4).setCellValue(odataObj.getRelatedApp());
				DR_FioriRow.createCell(5).setCellValue(odataObj.getTechnicalCatalogId());
				DR_FioriRow.createCell(6).setCellValue(odataObj.getTechnicalcatalogtitle());
				DR_FioriRow.createCell(7).setCellValue(odataObj.getSemanticObjectAction());
				DR_FioriRow.createCell(8).setCellValue(odataObj.getLaunchpadApplicationType());
				DR_FioriRow.createCell(9).setCellValue(odataObj.getLaunchpadApplicationName());
				DR_FioriRow.createCell(10).setCellValue(odataObj.getStatusOfTheApplication());
				DR_FioriRow.createCell(11).setCellValue(odataObj.getFlagForCustomApplication());
				DR_FioriRow.createCell(12).setCellValue(odataObj.getComponent());

				rowIndex++;
			}
		}
		logger.info("Sucessfully Wrote DR_Fiori Sheet:::%%%%%%%");
	}

	// Writing DR_Existing_Errors Sheet
	private void wroteDR_Existing_Errors(SXSSFSheet DR_Existing_ErrorsSheet,
			List<AuctFinalOutput_Download> DR_Existing_ErrorsList) {
		int rowIndex = 1;
		if (null != DR_Existing_ErrorsList && !DR_Existing_ErrorsList.isEmpty()) {
			Iterator<AuctFinalOutput_Download> AuctObjItr = DR_Existing_ErrorsList.iterator();
			while (AuctObjItr.hasNext()) {

				AuctFinalOutput_Download AuctObj = AuctObjItr.next();
				Row DR_Existing_ErrorsRow = DR_Existing_ErrorsSheet.createRow(rowIndex);

				DR_Existing_ErrorsRow.createCell(0).setCellValue(AuctObj.getRicefCategory());
				DR_Existing_ErrorsRow.createCell(1).setCellValue(AuctObj.getRicefSubCategory());
				DR_Existing_ErrorsRow.createCell(2).setCellValue(AuctObj.getTYPE());
				DR_Existing_ErrorsRow.createCell(3).setCellValue(AuctObj.getOBJ_NAME());
				DR_Existing_ErrorsRow.createCell(4).setCellValue(AuctObj.getSUB_TYPE());
				DR_Existing_ErrorsRow.createCell(5).setCellValue(AuctObj.getREAD_PROG());
				DR_Existing_ErrorsRow.createCell(6).setCellValue(AuctObj.getOBJ_PACKAGE());
				DR_Existing_ErrorsRow.createCell(7).setCellValue(AuctObj.getLINE_NUMBER());
				DR_Existing_ErrorsRow.createCell(8).setCellValue(AuctObj.getINFO());
				DR_Existing_ErrorsRow.createCell(9).setCellValue(AuctObj.getAUTOMATION_STATUS());
				DR_Existing_ErrorsRow.createCell(10).setCellValue(AuctObj.getOPCODE());
				DR_Existing_ErrorsRow.createCell(11).setCellValue(AuctObj.getUsed_Unused());
				DR_Existing_ErrorsRow.createCell(12).setCellValue(AuctObj.getExtNamespace());
				//DR_Existing_ErrorsRow.createCell(13).setCellValue(AuctObj.getCODE());
				rowIndex++;

			}
		}

		logger.info("Sucessfully Wrote DR_Existing_Errors Sheet:::%%%%%%%");
	}

	// Writing Output Management Sheet
	private void writeOutputMgmntSheet(SXSSFSheet outputMgmntSheet, Long requestID) {
		int rowIndex = 7;
		Row outputMgmtRow;
		List<S4OutputMgmt_Download> s4OutputMgmtList = getGraphS4DAO().getS4OutputMgmt(requestID);
		if (null != s4OutputMgmtList && !s4OutputMgmtList.isEmpty()) {
			Iterator<S4OutputMgmt_Download> s4OutputMgmtItr = s4OutputMgmtList.iterator();
			while (s4OutputMgmtItr.hasNext()) {

				S4OutputMgmt_Download outputMgmt = s4OutputMgmtItr.next();
				outputMgmtRow = outputMgmntSheet.createRow(rowIndex);
				outputMgmtRow.createCell(0).setCellValue(outputMgmt.getType());
				outputMgmtRow.createCell(1).setCellValue(outputMgmt.getObjName());

				rowIndex++;
			}
		}
		logger.info("Sucessfully Wrote OutputMgmt Sheet:::%%%%%%%");

	}

	// Writing Affect By Custom Sheet
	private void writeAffectCustomSheet(SXSSFSheet affectByCustomSheet, Long requestID) {
		int rowIndex = 8;
		Row affectCustomRow;
		List<S4AffectCustomField_Download> s4AffectCustomList = getGraphS4DAO().getS4AffectCustom(requestID);
		if (null != s4AffectCustomList && !s4AffectCustomList.isEmpty()) {
			Iterator<S4AffectCustomField_Download> s4AffectCustomItr = s4AffectCustomList.iterator();
			while (s4AffectCustomItr.hasNext()) {

				S4AffectCustomField_Download s4AffectCustom = s4AffectCustomItr.next();
				affectCustomRow = affectByCustomSheet.createRow(rowIndex);
				affectCustomRow.createCell(0).setCellValue(s4AffectCustom.getType());
				affectCustomRow.createCell(1).setCellValue(s4AffectCustom.getObjName());
				affectCustomRow.createCell(2).setCellValue(s4AffectCustom.getTriggerObj());
				affectCustomRow.createCell(3).setCellValue(s4AffectCustom.getReplacedByCDS());
				rowIndex++;
			}
		}
		logger.info("Sucessfully Wrote Affect Custom Sheet:::%%%%%%%");

	}

	// Writing Impacted Object Type sheet
	private void writeImpactObjSheet(SXSSFSheet impactObjSheet, Long requestID) {
		int rowIndex = 1;
		List<ImpactedObjList_Download> ImpactedObjList = new ArrayList<ImpactedObjList_Download>();
		ImpactedObjList = getDaoIntf().GetImpactedObjectList(requestID, 0, 0);
		if (null != ImpactedObjList && !ImpactedObjList.isEmpty()) {
			Iterator<ImpactedObjList_Download> impactObjItr = ImpactedObjList.iterator();
			while (impactObjItr.hasNext()) {

				ImpactedObjList_Download impactObj = impactObjItr.next();
				Row impactObjRow = impactObjSheet.createRow(rowIndex);
				impactObjRow.createCell(0).setCellValue(impactObj.getRicefCategory());
				impactObjRow.createCell(1).setCellValue(impactObj.getRicefSubCategory());
				impactObjRow.createCell(2).setCellValue(impactObj.getOBJ_TYPE());
				impactObjRow.createCell(3).setCellValue(impactObj.getOBJ_NAME());
				impactObjRow.createCell(4).setCellValue(impactObj.getUsed());
				impactObjRow.createCell(5).setCellValue(impactObj.getUsageCount());
				impactObjRow.createCell(6).setCellValue(impactObj.getErrors_In_Existing_System());
				impactObjRow.createCell(7).setCellValue(impactObj.getDB_Impact());
				impactObjRow.createCell(8).setCellValue(impactObj.getS4_Simplification());
				impactObjRow.createCell(9).setCellValue(impactObj.getOdata());
				impactObjRow.createCell(10).setCellValue(impactObj.getOsMigration());
				impactObjRow.createCell(11).setCellValue(impactObj.getImpactedMod());
				impactObjRow.createCell(12).setCellValue(impactObj.getExtNamespace());

				rowIndex++;
			}
		}

		logger.info("Sucessfully Wrote Impact Sheet:::%%%%%%%");
	}

	// Writing Impacted Table Sheet
	private void writeImpactedTableSheet(XSSFSheet impactedTablesSheet, Long requestID, RequestForm requestForm) {

		String systemEnvt = requestForm.getSystemEnvt();
		String systemTargetVer = requestForm.getTargetVersion();
		int rowIndex = 4;
		Row impactedTablesRow;
		List<S4ImpactedTables_Download> s4ImpactedTablesList = getGraphS4DAO().getS4ImpactedTables(requestID);

		if (systemTargetVer.startsWith("S/4"))
			impactedTablesSheet.getRow(0).getCell(0).setCellValue(Hana_Profiler_Constant.IMPACT_TABLES_TARGET_VER_1
					+ " " + systemTargetVer.substring(0, 3) + " " + systemTargetVer.substring(3, 7) + " "
					+ systemTargetVer.substring(7, 11) + " " + Hana_Profiler_Constant.IMPACT_TABLES_TARGET_VER_2);
		else
			impactedTablesSheet.getRow(0).getCell(0).setCellValue(Hana_Profiler_Constant.IMPACT_TABLES_TARGET_VER_1
					+ " " + systemTargetVer + " " + Hana_Profiler_Constant.IMPACT_TABLES_TARGET_VER_2);

		if (systemEnvt.equalsIgnoreCase("Production"))
			impactedTablesSheet.getRow(1).getCell(0).setCellType(HSSFCell.CELL_TYPE_BLANK);
		else
			impactedTablesSheet.getRow(1).getCell(0).setCellValue(Hana_Profiler_Constant.IMPACT_TABLES_SYSTEM_ENVT_1
					+ " " + systemEnvt + " " + Hana_Profiler_Constant.IMPACT_TABLES_SYSTEM_ENVT_2);

		if (null != s4ImpactedTablesList && !s4ImpactedTablesList.isEmpty()) {
			Iterator<S4ImpactedTables_Download> s4ImpactedTablesItr = s4ImpactedTablesList.iterator();
			while (s4ImpactedTablesItr.hasNext()) {

				S4ImpactedTables_Download impactedTables = s4ImpactedTablesItr.next();
				impactedTablesRow = impactedTablesSheet.createRow(rowIndex);
				impactedTablesRow.createCell(0).setCellValue(impactedTables.getObject());
				impactedTablesRow.createCell(1).setCellValue(impactedTables.getDescription());
				impactedTablesRow.createCell(2).setCellValue(impactedTables.getSolSteps());
				impactedTablesRow.createCell(3).setCellValue(impactedTables.getSapNotes());
				rowIndex++;
			}
		}
		logger.info("Sucessfully Wrote Impacted Tables Sheet:::%%%%%%%");

	}

	// Writing Impacted IDOC Sheet
	private void writeImpactedIDOCSheet(SXSSFSheet impactedIDOCSheet, Long requestID) {
		int rowIndex = 3;
		Row impactedIDOCRow;
		List<S4ImpactedIDOC_Download> s4ImpactedIDOCList = getGraphS4DAO().getS4ImpactedIDOC(requestID);
		if (null != s4ImpactedIDOCList && !s4ImpactedIDOCList.isEmpty()) {
			Iterator<S4ImpactedIDOC_Download> s4ImpactedIDOCItr = s4ImpactedIDOCList.iterator();
			while (s4ImpactedIDOCItr.hasNext()) {

				S4ImpactedIDOC_Download impactedIDOC = s4ImpactedIDOCItr.next();
				impactedIDOCRow = impactedIDOCSheet.createRow(rowIndex);
				impactedIDOCRow.createCell(0).setCellValue(impactedIDOC.getMsgType());
				impactedIDOCRow.createCell(1).setCellValue(impactedIDOC.getBasicType());
				impactedIDOCRow.createCell(2).setCellValue(impactedIDOC.getSegment());
				impactedIDOCRow.createCell(3).setCellValue(impactedIDOC.getImpactedObjType());
				impactedIDOCRow.createCell(4).setCellValue(impactedIDOC.getImpactedObjName());
				impactedIDOCRow.createCell(5).setCellValue(impactedIDOC.getDescription());
				impactedIDOCRow.createCell(6).setCellValue(impactedIDOC.getSapNote());
				impactedIDOCRow.createCell(7).setCellValue(impactedIDOC.getSolSteps());
				impactedIDOCRow.createCell(8).setCellValue(impactedIDOC.getTypeOfIDOC());
				rowIndex++;
			}
		}
		logger.info("Sucessfully Wrote Impacted IDOC Sheet:::%%%%%%%");
	}

	// Writing Impacted Transaction Sheet
	private void writeImpactedTransactionSheet(XSSFSheet impactedTransactionSheet, Long requestID,
			RequestForm requestForm) {

		String systemTargetVer = requestForm.getTargetVersion();
		int rowIndex = 3;
		Row impactedTransactionRow;
		List<S4ImpactedTransaction_Download> s4ImpactedTransactionList = getGraphS4DAO()
				.getS4ImpactedTransaction(requestID);

		if (systemTargetVer.startsWith("S/4"))
			impactedTransactionSheet.getRow(0).getCell(0).setCellValue(
					Hana_Profiler_Constant.IMPACT_TRANSACTION_TARGET_VER + " " + systemTargetVer.substring(0, 3) + " "
							+ systemTargetVer.substring(3, 7) + " " + systemTargetVer.substring(7, 11));
		else
			impactedTransactionSheet.getRow(0).getCell(0)
					.setCellValue(Hana_Profiler_Constant.IMPACT_TRANSACTION_TARGET_VER + " " + systemTargetVer);

		if (null != s4ImpactedTransactionList && !s4ImpactedTransactionList.isEmpty()) {
			Iterator<S4ImpactedTransaction_Download> s4ImpactedTransactionItr = s4ImpactedTransactionList.iterator();
			while (s4ImpactedTransactionItr.hasNext()) {

				S4ImpactedTransaction_Download impactedTransaction = s4ImpactedTransactionItr.next();
				impactedTransactionRow = impactedTransactionSheet.createRow(rowIndex);
				impactedTransactionRow.createCell(0).setCellValue(impactedTransaction.getImpactedTransaction());
				impactedTransactionRow.createCell(1).setCellValue(impactedTransaction.getDescription());
				impactedTransactionRow.createCell(2).setCellValue(impactedTransaction.getSapNotes());
				impactedTransactionRow.createCell(3).setCellValue(impactedTransaction.getSolSteps());
				rowIndex++;
			}
		}
		logger.info("Sucessfully Wrote Impacted Transaction Sheet:::%%%%%%%");
	}

	// Writing Impacted Search Help
	private void writeImpactedSearchSheet(SXSSFSheet searchHelpSheet, final Long requestID) {
		int rowIndex = 3;
		List<S4ImpactedSearchHelp_Download> s4ImpactedSearchList = getGraphS4DAO().getImpactedSearch(requestID);
		if (null != s4ImpactedSearchList && !s4ImpactedSearchList.isEmpty()) {
			Iterator<S4ImpactedSearchHelp_Download> s4SearchItr = s4ImpactedSearchList.iterator();
			while (s4SearchItr.hasNext()) {
				Row searchHelpRow = searchHelpSheet.createRow(rowIndex);

				S4ImpactedSearchHelp_Download s4ImpactSearchHelp = s4SearchItr.next();
				searchHelpRow.createCell(0).setCellValue(s4ImpactSearchHelp.getObjectType());
				searchHelpRow.createCell(1).setCellValue(s4ImpactSearchHelp.getObjectName());
				searchHelpRow.createCell(2).setCellValue(s4ImpactSearchHelp.getSearchData());
				searchHelpRow.createCell(3).setCellValue(s4ImpactSearchHelp.getExternalNamespace());

				rowIndex++;
			}
		}
		logger.info("Sucessfully Wrote writeImpactedSearchSheet:::%%%%%%%");
	}

	// Writing Append Structure Analysis
	private void writeAppendStrctrSheet(SXSSFSheet appendSheet, Long requestID) {
		int rowIndex = 3;
		List<S4AppendStructureAnalysis_Download> appendStrctrList = getGraphS4DAO().getAppendStrctr(requestID);
		if (null != appendStrctrList && !appendStrctrList.isEmpty()) {
			Iterator<S4AppendStructureAnalysis_Download> appndStrctrItr = appendStrctrList.iterator();
			logger.info("appendStrctrList.size()" + appendStrctrList.size());
			while (appndStrctrItr.hasNext()) {

				S4AppendStructureAnalysis_Download appndStrctr = appndStrctrItr.next();
				Row apendStrctrRow = appendSheet.createRow(rowIndex);
				apendStrctrRow.createCell(0).setCellValue(appndStrctr.getTableName());
				apendStrctrRow.createCell(1).setCellValue(appndStrctr.getFieldName());
				apendStrctrRow.createCell(2).setCellValue(appndStrctr.getNameOfInclude());

				rowIndex++;
			}
		}
		logger.info("Sucessfully Wrote writeAppend Strctr Sheet:::%%%%%%%");
	}

	// Writing Clone Prog Analysis
	private void writeCLoneProgSheet(XSSFSheet cloneSheet, Long requestID) {
		int rowIndex = 3;
		List<S4CloneProg_Download> cloneProgList = getGraphS4DAO().getCloneProg(requestID);
		if (null != cloneProgList && !cloneProgList.isEmpty()) {

			Iterator<S4CloneProg_Download> cloneProgITR = cloneProgList.iterator();
			while (cloneProgITR.hasNext()) {
				S4CloneProg_Download s4CloneProg = cloneProgITR.next();
				Row cloneRow = cloneSheet.createRow(rowIndex);
				cloneRow.createCell(1).setCellValue(s4CloneProg.getImpactedProg());
				cloneRow.createCell(2).setCellValue(s4CloneProg.getCloneProg());
				cloneRow.createCell(3).setCellValue(s4CloneProg.getDesc());
				cloneRow.createCell(4).setCellValue(s4CloneProg.getSolStep());
				cloneRow.createCell(5).setCellValue(s4CloneProg.getRelatedNotes());
				rowIndex++;
			}
		}
		logger.info("Sucessfully Wrote Clone Strctr Sheet:::%%%%%%%");
	}

	// Writing Enhancement Sheet
	private void writeEnhancementSheet(SXSSFSheet enhancementSheet, Long requestID) {
		int rowIndex = 3;
		List<S4Enhancement_Download> enhancementList = getGraphS4DAO().getEnhancement(requestID);
		if (null != enhancementList && !enhancementList.isEmpty()) {

			Iterator<S4Enhancement_Download> enhancementITR = enhancementList.iterator();
			while (enhancementITR.hasNext()) {
				S4Enhancement_Download s4Enhancement = enhancementITR.next();
				Row enhancementRow = enhancementSheet.createRow(rowIndex);
				enhancementRow.createCell(0).setCellValue(s4Enhancement.getEnhancementType());
				enhancementRow.createCell(1).setCellValue(s4Enhancement.getClasName());
				enhancementRow.createCell(2).setCellValue(s4Enhancement.getEnhancementName());
				enhancementRow.createCell(3).setCellValue(s4Enhancement.getImplName());
				rowIndex++;
			}
		}
		logger.info("Sucessfully Wrote Enhancement Sheet:::%%%%%%%");
	}

	// Writing DR_S4 Simplification-2
	private void writedetailReport2Sheet(XSSFSheet detailReport2Sheet, Long requestID) {

		int rowIndex = 1;
		List<S4DetailReportComplexity_Download> detailReport2List = getGraphS4DAO().getDetailReport2List(requestID);
		if (null != detailReport2List && !detailReport2List.isEmpty()) {
			Iterator<S4DetailReportComplexity_Download> detailReportItr = detailReport2List.iterator();
			while (detailReportItr.hasNext()) {
				S4DetailReportComplexity_Download detailReport = detailReportItr.next();

				Row detailReportRow = detailReport2Sheet.createRow(rowIndex);
				detailReportRow.createCell(0).setCellValue(detailReport.getType());
				detailReportRow.createCell(1).setCellValue(detailReport.getObjName());
				detailReportRow.createCell(2).setCellValue(detailReport.getUsed());
				detailReportRow.createCell(3).setCellValue(detailReport.getSubObject());
				detailReportRow.createCell(4).setCellValue(detailReport.getMethod());
				detailReportRow.createCell(5).setCellValue(detailReport.getPckg());
				detailReportRow.createCell(6).setCellValue(detailReport.getImpactedObjType());
				detailReportRow.createCell(7).setCellValue(detailReport.getLineNo());
				detailReportRow.createCell(8).setCellValue(detailReport.getStmt());
				detailReportRow.createCell(9).setCellValue(detailReport.getOperations());
				detailReportRow.createCell(10).setCellValue(detailReport.getImpactReason());
				detailReportRow.createCell(11).setCellValue(detailReport.getAffectObjDesc());
				detailReportRow.createCell(12).setCellValue(detailReport.getDescOfChange());
				detailReportRow.createCell(13).setCellValue(detailReport.getSapNotes());
				detailReportRow.createCell(14).setCellValue(detailReport.getSolutionSteps());
				detailReportRow.createCell(15).setCellValue(detailReport.getComplexity());
				detailReportRow.createCell(16).setCellValue(detailReport.getIssueCategory());
				detailReportRow.createCell(17).setCellValue(detailReport.getErrorCategory());
				detailReportRow.createCell(18).setCellValue(detailReport.getTriggerObj());
				detailReportRow.createCell(19).setCellValue(detailReport.getRemediationCategory());
				detailReportRow.createCell(20).setCellValue(detailReport.getSapSimpListChapter());
				detailReportRow.createCell(21).setCellValue(detailReport.getApplicationComponent());
				detailReportRow.createCell(22).setCellValue(detailReport.getSapSimplCategry());
				detailReportRow.createCell(23).setCellValue(detailReport.getItemArea());
				rowIndex++;
			}
			logger.info("Sucessfully Wrote DR_S4 Simplification-2:::%%%%%%%");
		}
	}

	// Writing DR_S4 Simplification-3
	private void writedetailReport3Sheet(XSSFSheet detailReport3Sheet, Long requestID) {

		int rowIndex = 1;
		Row detailReportRow;
		List<S4DetailReportRemediation_Download> detailReport3List = getGraphS4DAO().getDetailReport3List(requestID);

		if (null != detailReport3List && !detailReport3List.isEmpty()) {
			Iterator<S4DetailReportRemediation_Download> detailReportItr = detailReport3List.iterator();
			while (detailReportItr.hasNext()) {
				S4DetailReportRemediation_Download detailReport = detailReportItr.next();

				detailReportRow = detailReport3Sheet.createRow(rowIndex);

				detailReportRow.createCell(0).setCellValue(detailReport.getType());
				detailReportRow.createCell(1).setCellValue(detailReport.getObjName());
				detailReportRow.createCell(2).setCellValue(detailReport.getUsed());
				detailReportRow.createCell(3).setCellValue(detailReport.getSubObject());
				detailReportRow.createCell(4).setCellValue(detailReport.getMethod());
				detailReportRow.createCell(5).setCellValue(detailReport.getPckg());
				detailReportRow.createCell(6).setCellValue(detailReport.getImpactedObjType());
				detailReportRow.createCell(7).setCellValue(detailReport.getLineNo());
				detailReportRow.createCell(8).setCellValue(detailReport.getStmt());
				detailReportRow.createCell(9).setCellValue(detailReport.getOperations());
				detailReportRow.createCell(10).setCellValue(detailReport.getImpactReason());
				detailReportRow.createCell(11).setCellValue(detailReport.getAffectObjDesc());
				detailReportRow.createCell(12).setCellValue(detailReport.getDescOfChange());
				detailReportRow.createCell(13).setCellValue(detailReport.getSapNotes());
				detailReportRow.createCell(14).setCellValue(detailReport.getSolutionSteps());
				detailReportRow.createCell(15).setCellValue(detailReport.getComplexity());
				detailReportRow.createCell(16).setCellValue(detailReport.getIssueCategory());
				detailReportRow.createCell(17).setCellValue(detailReport.getErrorCategory());
				detailReportRow.createCell(18).setCellValue(detailReport.getTriggerObj());
				detailReportRow.createCell(19).setCellValue(detailReport.getRemediationCategory());
				detailReportRow.createCell(20).setCellValue(detailReport.getSapSimpListChapter());
				detailReportRow.createCell(21).setCellValue(detailReport.getApplicationComponent());
				detailReportRow.createCell(22).setCellValue(detailReport.getSapSimplCategry());
				detailReportRow.createCell(23).setCellValue(detailReport.getItemArea());

				rowIndex++;
			}
			logger.info("Sucessfully Wrote Detail Report3:::%%%%%%%");
		}
	}

	// Writing UI5 Final Output sheet 1
	private void writeUI5FinalOutputSheet(SXSSFSheet UI5FinalOutputSheet, Long requestID) {

		int rowIndex = 1;
		Row UI5FinalOutputRow;
		List<UI5FinalOutput> UI5FinalOutputList = getGraphS4DAO().getUI5FinalOutputList(requestID);

		if (null != UI5FinalOutputList && !UI5FinalOutputList.isEmpty()) {
			Iterator<UI5FinalOutput> UI5FinalOutputItr = UI5FinalOutputList.iterator();
			while (UI5FinalOutputItr.hasNext()) {
				UI5FinalOutput UI5FinalOutputReport = UI5FinalOutputItr.next();

				UI5FinalOutputRow = UI5FinalOutputSheet.createRow(rowIndex);

				UI5FinalOutputRow.createCell(0).setCellValue(UI5FinalOutputReport.getUielemt());
				UI5FinalOutputRow.createCell(1).setCellValue(UI5FinalOutputReport.getAttribute());
				UI5FinalOutputRow.createCell(2).setCellValue(UI5FinalOutputReport.getType());
				UI5FinalOutputRow.createCell(3).setCellValue(UI5FinalOutputReport.getDescription());
				UI5FinalOutputRow.createCell(4).setCellValue(UI5FinalOutputReport.getVersion());
				UI5FinalOutputRow.createCell(5).setCellValue(UI5FinalOutputReport.getLinenumber());
				UI5FinalOutputRow.createCell(6).setCellValue(UI5FinalOutputReport.getProjectName());
				UI5FinalOutputRow.createCell(7).setCellValue(UI5FinalOutputReport.getFilename());
				UI5FinalOutputRow.createCell(8).setCellValue(UI5FinalOutputReport.getStatus());
				UI5FinalOutputRow.createCell(9).setCellValue(UI5FinalOutputReport.getMessage());
				String url = "";
				if (UI5FinalOutputReport.getUielemt() != null) {
					url = url + UI5FinalOutputReport.getUielemt();
				}
				if (UI5FinalOutputReport.getType() != null) {
					url = url + "/" + UI5FinalOutputReport.getType();
				}
				if (UI5FinalOutputReport.getAttribute() != null) {
					url = url + "/" + UI5FinalOutputReport.getAttribute();
				}
				UI5FinalOutputRow.createCell(10).setCellValue(url);

				rowIndex++;
			}
			logger.info("Sucessfully Wrote UI5 Final Output sheet 1 :::%%%%%%%");
		}

	}

	// Writing UI5 Final Output sheet 2
	private void writeUI5HighLevelReportSheet(SXSSFSheet UI5HighLevelReportSheet, Long requestID) {

		int rowIndex = 1;
		Row UI5HighLevelReportRow;
		List<UI5HighLevelReport> UI5HighLevelReportList = getGraphS4DAO().getUI5HighLevelReportList(requestID);

		if (null != UI5HighLevelReportList && !UI5HighLevelReportList.isEmpty()) {
			Iterator<UI5HighLevelReport> UI5HighLevelReportItr = UI5HighLevelReportList.iterator();
			while (UI5HighLevelReportItr.hasNext()) {
				UI5HighLevelReport UI5FinalOutputReport = UI5HighLevelReportItr.next();

				UI5HighLevelReportRow = UI5HighLevelReportSheet.createRow(rowIndex);

				UI5HighLevelReportRow.createCell(0).setCellValue(UI5FinalOutputReport.getProjectName());
				UI5HighLevelReportRow.createCell(1).setCellValue(UI5FinalOutputReport.getTotalApiCounts());
				UI5HighLevelReportRow.createCell(2).setCellValue(UI5FinalOutputReport.getDepricatedApiCounts());
				UI5HighLevelReportRow.createCell(3).setCellValue(UI5FinalOutputReport.getNonValidApiCounts());
				UI5HighLevelReportRow.createCell(4).setCellValue(UI5FinalOutputReport.getRecommendedChangesApiCounts());
				UI5HighLevelReportRow.createCell(5).setCellValue(UI5FinalOutputReport.getFinalMessage());

				rowIndex++;
			}
			logger.info("Sucessfully Wrote UI5 Final Output sheet 2 :::%%%%%%%");
		}

	}

	// Writing Testing Scope sheet data
	private void writeTestingScopeReportSheet(SXSSFSheet testingScopeReportSheet, Long requestID, XSSFCellStyle csr) {
		int rowIndex = 1;
		Row testingRow;
		List<ExtractedDatapojo> TestingScopeList = getDaoIntf().getTestingScope(requestID);
		if (null != TestingScopeList && !TestingScopeList.isEmpty()) {
			Iterator<ExtractedDatapojo> testingScopeItr = TestingScopeList.iterator();
			while (testingScopeItr.hasNext()) {

				ExtractedDatapojo testingScope = testingScopeItr.next();
				testingRow = testingScopeReportSheet.createRow(rowIndex);
				testingRow.createCell(0).setCellValue(testingScope.getProcess());
				testingRow.createCell(1).setCellValue(testingScope.getApplicationComponent());
				testingRow.createCell(2).setCellValue(testingScope.getAppCompDesc());
				if (null != testingScope.getTransactions() && testingScope.getTransactions().length() > 32767) {
					testingRow.createCell(3).setCellValue(testingScope.getTransactions().substring(0,
							Math.min(testingScope.getTransactions().length(), 10)));
					testingRow.getCell(3).setCellStyle(csr);
				} else {
					testingRow.createCell(3).setCellValue(testingScope.getTransactions());
				}
				if (null != testingScope.getRole() && testingScope.getRole().length() > 32767) {
					testingRow.createCell(4).setCellValue(
							testingScope.getRole().substring(0, Math.min(testingScope.getRole().length(), 10)));
					testingRow.getCell(4).setCellStyle(csr);
				} else {
					testingRow.createCell(4).setCellValue(testingScope.getRole());
				}
				testingRow.createCell(5).setCellValue(testingScope.getObjecttype());
				testingRow.createCell(6).setCellValue(testingScope.getObjectname());
				testingRow.createCell(7).setCellValue(testingScope.getOpercd());

				rowIndex++;
			}
		}

		logger.info("Sucessfully Wrote Testing Scope Sheet:::%%%%%%%");
	}

	// Writing Impacted Background Job sheet data
	private void writeImpactedBackgroundJobReportSheet(SXSSFSheet impactedBackgroundJobSheet, Long requestID) {
		int rowIndex = 1;
		Row impactedRow;
		List<ImpactedBackgroundJob_Download> ImpactedBackgroundJobList = getGraphS4DAO()
				.getImpactedBackgroundJob(requestID);
		if (null != ImpactedBackgroundJobList && !ImpactedBackgroundJobList.isEmpty()) {
			Iterator<ImpactedBackgroundJob_Download> impactedBackgroundJobListItr = ImpactedBackgroundJobList
					.iterator();
			while (impactedBackgroundJobListItr.hasNext()) {

				ImpactedBackgroundJob_Download impactedJob = impactedBackgroundJobListItr.next();
				impactedRow = impactedBackgroundJobSheet.createRow(rowIndex);
				impactedRow.createCell(0).setCellValue(impactedJob.getObject());
				impactedRow.createCell(1).setCellValue(impactedJob.getbJobName());
				impactedRow.createCell(2).setCellValue(impactedJob.getProgName());
				impactedRow.createCell(3).setCellValue(impactedJob.getVariant());
				impactedRow.createCell(4).setCellValue(impactedJob.gettCode());
				impactedRow.createCell(5).setCellValue(impactedJob.getRun());
				impactedRow.createCell(6).setCellValue(impactedJob.getExternalNamespace());
				rowIndex++;
			}
		}
		logger.info("Sucessfully Wrote Impacted Background Job Sheet:::%%%%%%%");
	}

	// Writing Impacted Clone Analysis sheet
	private void writeImpactedCloneSheet(SXSSFSheet impactedCloneSheet, Long requestID) {
		int rowIndex = 1;
		List<ImpactedCloneAnalysis_Download> impactedCloneList = new ArrayList<ImpactedCloneAnalysis_Download>();
		impactedCloneList = getDaoIntf().getImpactedCloneList(requestID, 0, 0);
		if (null != impactedCloneList && !impactedCloneList.isEmpty()) {
			Iterator<ImpactedCloneAnalysis_Download> impactedScriptsItr = impactedCloneList.iterator();
			while (impactedScriptsItr.hasNext()) {
				ImpactedCloneAnalysis_Download scriptsSheet = impactedScriptsItr.next();
				Row scriptsSheetRow = impactedCloneSheet.createRow(rowIndex);
				scriptsSheetRow.createCell(0).setCellValue(scriptsSheet.getNamespace());
				scriptsSheetRow.createCell(1).setCellValue(scriptsSheet.getObjType());
				scriptsSheetRow.createCell(2).setCellValue(scriptsSheet.getObjName());
				scriptsSheetRow.createCell(3).setCellValue(scriptsSheet.getObjPackage());
				scriptsSheetRow.createCell(4).setCellValue(scriptsSheet.getCreationDate());
				scriptsSheetRow.createCell(5).setCellValue(scriptsSheet.getYear());
				scriptsSheetRow.createCell(6).setCellValue(scriptsSheet.getInterfaceObjType());
				scriptsSheetRow.createCell(7).setCellValue(scriptsSheet.getInterfaceObj());
				scriptsSheetRow.createCell(8).setCellValue(scriptsSheet.getReference());
				scriptsSheetRow.createCell(9).setCellValue(scriptsSheet.getReferencePercent());
				scriptsSheetRow.createCell(10).setCellValue(scriptsSheet.getAppComponent());
				scriptsSheetRow.createCell(11).setCellValue(scriptsSheet.getUsed());
				scriptsSheetRow.createCell(12).setCellValue(scriptsSheet.getImpactedDB());
				scriptsSheetRow.createCell(13).setCellValue(scriptsSheet.getImpactedSimpl());
				scriptsSheetRow.createCell(14).setCellValue(scriptsSheet.getImpactedExistingError());
				scriptsSheetRow.createCell(15).setCellValue(scriptsSheet.getImpactedOSMigration());
				scriptsSheetRow.createCell(16).setCellValue(scriptsSheet.getExternalNamespace());
				scriptsSheetRow.createCell(17).setCellValue(scriptsSheet.getExecDate());
				scriptsSheetRow.createCell(18).setCellValue(scriptsSheet.getExecTime());
				rowIndex++;
			}
		}
		logger.info("Sucessfully Wrote Impacted Clone Analysis Sheet:::%%%%%%%");
	}

	// Writing unicode enagas sheet
	private void writeUnicodeSheet(SXSSFSheet unicodeEnagasSheet, Long requestID) {
		int rowIndex = 1;
		List<UnicodeOutput> unicodeList = new ArrayList<UnicodeOutput>();
		unicodeList = getDaoIntf().getUnicodeOutput(requestID);
		if (null != unicodeList && !unicodeList.isEmpty()) {
			Iterator<UnicodeOutput> unicodeItr = unicodeList.iterator();
			while (unicodeItr.hasNext()) {
				UnicodeOutput scriptsSheet = unicodeItr.next();
				Row scriptsSheetRow = unicodeEnagasSheet.createRow(rowIndex);
				scriptsSheetRow.createCell(0).setCellValue(scriptsSheet.getObjType());
				scriptsSheetRow.createCell(1).setCellValue(scriptsSheet.getProgram());
				scriptsSheetRow.createCell(2).setCellValue(scriptsSheet.getInclude());
				scriptsSheetRow.createCell(3).setCellValue(scriptsSheet.getRoww());
				scriptsSheetRow.createCell(4).setCellValue(scriptsSheet.getErrorCode());
				scriptsSheetRow.createCell(5).setCellValue(scriptsSheet.getMessage());
				scriptsSheetRow.createCell(6).setCellValue(scriptsSheet.getPack());
				scriptsSheetRow.createCell(7).setCellValue(scriptsSheet.getApplicationComp());
				scriptsSheetRow.createCell(8).setCellValue(scriptsSheet.getUsed());
				scriptsSheetRow.createCell(9).setCellValue(scriptsSheet.getExtNamespace());

				rowIndex++;
			}
		}
		logger.info("Sucessfully Wrote Unicode Sheet:::%%%%%%%");
	}

	// Writing Impacted Scripts sheet
	private void writeImpactedScriptsSheet(SXSSFSheet impactedScriptsSheet, Long requestID) {
		int rowIndex = 1;
		List<ImpactedScripts_Download> ImpactedScriptsList = new ArrayList<ImpactedScripts_Download>();
		ImpactedScriptsList = getDaoIntf().getImpactedScriptsList(requestID, 0, 0);
		if (null != ImpactedScriptsList && !ImpactedScriptsList.isEmpty()) {
			Iterator<ImpactedScripts_Download> impactedScriptsItr = ImpactedScriptsList.iterator();
			while (impactedScriptsItr.hasNext()) {
				ImpactedScripts_Download scriptsSheet = impactedScriptsItr.next();
				Row scriptsSheetRow = impactedScriptsSheet.createRow(rowIndex);
				scriptsSheetRow.createCell(0).setCellValue(scriptsSheet.getObjName());
				scriptsSheetRow.createCell(1).setCellValue(scriptsSheet.getActStatus());
				scriptsSheetRow.createCell(2).setCellValue(scriptsSheet.getRemidiCategory());
				scriptsSheetRow.createCell(3).setCellValue(scriptsSheet.getDbImpact());
				scriptsSheetRow.createCell(4).setCellValue(scriptsSheet.getS4Simplification());
				scriptsSheetRow.createCell(5).setCellValue(scriptsSheet.getExistingErrors());
				scriptsSheetRow.createCell(6).setCellValue(scriptsSheet.getExternalNamespace());

				rowIndex++;
			}
		}
		logger.info("Sucessfully Wrote Impacted Scripts Sheet:::%%%%%%%");
	}

	// Writing CVITR sheet
	private void writeCVITRSheet(XSSFSheet cvitrSheet, Long requestID, XSSFWorkbook wb) {
		int rowIndex = 1;

		List<S4cvitr_Download> cvitrList = new ArrayList<S4cvitr_Download>();
		cvitrList = getDaoIntf().getcvitrList(requestID, 0, 0);

		if (null != cvitrList && !cvitrList.isEmpty()) {
			Iterator<S4cvitr_Download> cvitrItr = cvitrList.iterator();
			while (cvitrItr.hasNext()) {
				S4cvitr_Download s4cvitrSheet = cvitrItr.next();

				XSSFCellStyle styleCellName = wb.createCellStyle();
				styleCellName.setBorderRight(BorderStyle.THIN);
				styleCellName.setRightBorderColor(IndexedColors.BLACK.getIndex());
				styleCellName.setBorderLeft(BorderStyle.THIN);
				styleCellName.setLeftBorderColor(IndexedColors.BLACK.getIndex());
				styleCellName.setBorderTop(BorderStyle.THIN);
				styleCellName.setTopBorderColor(IndexedColors.BLACK.getIndex());
				;
				styleCellName.setBorderBottom(BorderStyle.THIN);
				styleCellName.setBottomBorderColor(IndexedColors.BLACK.getIndex());
				styleCellName.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

				if (s4cvitrSheet.getNewLine().trim().equals("6"))
					styleCellName.setFillForegroundColor(new XSSFColor(new java.awt.Color(180, 64, 255)));
				else if (s4cvitrSheet.getNewLine().trim().equals("5"))
					styleCellName.setFillForegroundColor(new XSSFColor(new java.awt.Color(0, 106, 191)));
				else if (s4cvitrSheet.getNewLine().trim().equals("3"))
					styleCellName.setFillForegroundColor(new XSSFColor(new java.awt.Color(102, 148, 255)));
				else
					styleCellName.setFillForegroundColor(HSSFColor.WHITE.index);

				Row cvitrSheetRow = cvitrSheet.createRow(rowIndex);

				Cell cell = cvitrSheetRow.createCell(0);
				cell.setCellValue(s4cvitrSheet.getIdentifier());
				cell.setCellStyle(styleCellName);

				cell = cvitrSheetRow.createCell(1);
				cell.setCellValue(s4cvitrSheet.getSelectLine());
				cell.setCellStyle(styleCellName);

				cell = cvitrSheetRow.createCell(2);
				cell.setCellValue(s4cvitrSheet.getCommentC());
				cell.setCellStyle(styleCellName);

				cell = cvitrSheetRow.createCell(3);
				cell.setCellValue(s4cvitrSheet.getComments());
				cell.setCellStyle(styleCellName);

				cell = cvitrSheetRow.createCell(4);
				cell.setCellValue(s4cvitrSheet.getCustomerExt());
				cell.setCellStyle(styleCellName);

				cell = cvitrSheetRow.createCell(5);
				cell.setCellValue(s4cvitrSheet.getVendorExt());
				cell.setCellStyle(styleCellName);

				rowIndex++;
			}
		}
		logger.info("Sucessfully Wrote CVITR Sheet:::%%%%%%%");
	}

	// Writing OS Migration Sheet - Impacted due to OS Migration
	private void writeOSMigrationSheet(SXSSFSheet osMigartionSheet, Long requestId, RequestForm requestForm,
			HttpSession session) {
		try {
			int rowIndex = 1;
			List<OSMigrationFinal_Download> osMigrationList = getOsMigrationService().getOSMigrationList(requestId);

			if (null != osMigrationList && !osMigrationList.isEmpty()) {
				Iterator<OSMigrationFinal_Download> osMigrationItr = osMigrationList.iterator();
				int counter = 0;
				while (osMigrationItr.hasNext()) {
					OSMigrationFinal_Download scriptsSheet = osMigrationItr.next();

					Row scriptsSheetRow = osMigartionSheet.createRow(rowIndex);
					scriptsSheetRow.createCell(0).setCellValue(scriptsSheet.getRicefCategory());
					scriptsSheetRow.createCell(1).setCellValue(scriptsSheet.getRicefSubCategory());
					scriptsSheetRow.createCell(2).setCellValue(scriptsSheet.getObjType());
					scriptsSheetRow.createCell(3).setCellValue(scriptsSheet.getObjName());
					if (!StringUtils.isBlank(scriptsSheet.getSubType())) {
						scriptsSheetRow.createCell(4).setCellValue(scriptsSheet.getSubType());
						counter++;
					}
					scriptsSheetRow.createCell(5).setCellValue(scriptsSheet.getReadProgram());
					scriptsSheetRow.createCell(6).setCellValue(scriptsSheet.getObjPackage());
					scriptsSheetRow.createCell(7).setCellValue(scriptsSheet.getOperationCode());
					scriptsSheetRow.createCell(8).setCellValue(scriptsSheet.getLineNo());
					scriptsSheetRow.createCell(9).setCellValue(scriptsSheet.getStatement());
					scriptsSheetRow.createCell(10).setCellValue(scriptsSheet.getRemCategory());
					scriptsSheetRow.createCell(11).setCellValue(scriptsSheet.getIssueCategory());
					scriptsSheetRow.createCell(12).setCellValue(scriptsSheet.getIssueSubcategory());
					scriptsSheetRow.createCell(13).setCellValue(scriptsSheet.getInfo()); // Info(Description
																							// of
																							// Change)
																							// ==
																							// Operation
																							// in
																							// Master
																							// Data
					scriptsSheetRow.createCell(14).setCellValue(scriptsSheet.getHighLvlDesc());
					scriptsSheetRow.createCell(15).setCellValue(scriptsSheet.getAutomationStatus());
					scriptsSheetRow.createCell(16).setCellValue(scriptsSheet.getComplexity());
					scriptsSheetRow.createCell(17).setCellValue(scriptsSheet.getUsed());
					scriptsSheetRow.createCell(18).setCellValue(scriptsSheet.getImpact());
					scriptsSheetRow.createCell(19).setCellValue(scriptsSheet.getExternalNamespace());

					rowIndex++;

					if (counter == 0) {
						logger.info("Counter is zero ");
						osMigartionSheet.setColumnHidden(2, true);
					}
				}
			}
		} catch (Exception e) {
			logger.error("Error in writeOSMigrationSheet :: ", e);
		}
		logger.info("Sucessfully Wrote OS Migration Sheet - Impacted due to OS Migration:::%%%%%%%");
	}

	// Writing OS Migration Sheet - Logical Cmd Impacted by OS Change
	private void writeLogCmdImpactOSSheet(SXSSFSheet osMigartionSheet, Long requestId) {
		int rowIndex = 1;
		List<OSMigrationFinalLogicalCMD_Download> osMigrationList = getOsMigrationService()
				.getOSMigrationLogCMDList(requestId);
		if (null != osMigrationList && !osMigrationList.isEmpty()) {
			Iterator<OSMigrationFinalLogicalCMD_Download> osMigrationItr = osMigrationList.iterator();
			while (osMigrationItr.hasNext()) {
				OSMigrationFinalLogicalCMD_Download scriptsSheet = osMigrationItr.next();
				if (scriptsSheet.getRemCategory().equalsIgnoreCase("Mandatory")) {
					Row scriptsSheetRow = osMigartionSheet.createRow(rowIndex);
					scriptsSheetRow.createCell(0).setCellValue("Logical Command");
					scriptsSheetRow.createCell(1).setCellValue(scriptsSheet.getReadProgram());
					scriptsSheetRow.createCell(2).setCellValue(scriptsSheet.getStatement());
					scriptsSheetRow.createCell(3).setCellValue(scriptsSheet.getRemCategory());
					scriptsSheetRow.createCell(4).setCellValue(scriptsSheet.getIssueCategory());
					scriptsSheetRow.createCell(5).setCellValue(scriptsSheet.getIssueSubcategory());
					scriptsSheetRow.createCell(6).setCellValue(scriptsSheet.getInfo()); // Info(Description
																						// of
																						// Change)
																						// ==
																						// Operation
																						// in
																						// Master
																						// Data
					scriptsSheetRow.createCell(7).setCellValue(scriptsSheet.getHighLvlDesc());
					scriptsSheetRow.createCell(8).setCellValue(scriptsSheet.getAutomationStatus());
					scriptsSheetRow.createCell(9).setCellValue(scriptsSheet.getComplexity());
					scriptsSheetRow.createCell(10).setCellValue(scriptsSheet.getImpact());
					rowIndex++;
				}
			}
		}

		logger.info("Sucessfully Wrote OS Migration Sheet - Logical Cmd Impacted by OS Change:::%%%%%%%");
	}

	// Writing OS Migration Sheet - File Path Impacted by OS Change
	private void writeFilePathImpactOSSheet(SXSSFSheet osMigartionSheet, Long requestId) {
		int rowIndex = 1;
		List<OSMigrationFinalFilepath_Download> osMigrationList = getOsMigrationService()
				.getOSMigrationFilePathList(requestId);
		if (null != osMigrationList && !osMigrationList.isEmpty()) {
			Iterator<OSMigrationFinalFilepath_Download> osMigrationItr = osMigrationList.iterator();
			while (osMigrationItr.hasNext()) {
				OSMigrationFinalFilepath_Download scriptsSheet = osMigrationItr.next();
				Row scriptsSheetRow = osMigartionSheet.createRow(rowIndex);
				scriptsSheetRow.createCell(0).setCellValue(scriptsSheet.getSubType());
				scriptsSheetRow.createCell(1).setCellValue(scriptsSheet.getObjName());
				scriptsSheetRow.createCell(2).setCellValue(scriptsSheet.getStatement());
				scriptsSheetRow.createCell(3).setCellValue(scriptsSheet.getInfo()); // Info
																					// ==
																					// Operation
																					// in
																					// Master
																					// Data
				scriptsSheetRow.createCell(4).setCellValue(scriptsSheet.getImpact());
				scriptsSheetRow.createCell(5).setCellValue(scriptsSheet.getRemCategory());
				scriptsSheetRow.createCell(6).setCellValue(scriptsSheet.getSkip());
				scriptsSheetRow.createCell(7).setCellValue(scriptsSheet.getSkipReason());
				scriptsSheetRow.createCell(8).setCellValue(scriptsSheet.getHighLvlDesc());
				rowIndex++;
			}
		}

		logger.info("Sucessfully Wrote OS Migration Sheet - File Path Impacted by OS Change:::%%%%%%%");
	}

	// Writing Bw Inventory sheet
	private void writeBwInventorySheet(SXSSFSheet bwInventorySheet, Long requestID) {
		int rowIndex = 1;
		List<BwInventoryDownload> bwInvList = new ArrayList<BwInventoryDownload>();
		bwInvList = getDaoIntf().getBwInventoryList(requestID);
		if (null != bwInvList && !bwInvList.isEmpty()) {
			Iterator<BwInventoryDownload> bwInvItr = bwInvList.iterator();
			while (bwInvItr.hasNext()) {
				BwInventoryDownload scriptsSheet = bwInvItr.next();
				Row scriptsSheetRow = bwInventorySheet.createRow(rowIndex);
				scriptsSheetRow.createCell(0).setCellValue(scriptsSheet.getObjType());
				scriptsSheetRow.createCell(1).setCellValue(scriptsSheet.getObjName());

				rowIndex++;
			}
		}
		logger.info("Sucessfully Wrote BwInventory Sheet:::%%%%%%%");
	}

	// Writing Bw Inventory sheet
	private void writeBwExtractTab2Sheet(SXSSFSheet bwTab2Sheet, SXSSFSheet bwTab3Sheet, Long requestID) {
		int rowIndexTab2 = 5, rowIndexTab3 = 1;
		List<BwExtractorMaster> bwMasterList = new ArrayList<BwExtractorMaster>();
		bwMasterList = getDaoIntf().getBwMasterDataList();
		List<BWExtractor_Download> bwExtractorList = new ArrayList<BWExtractor_Download>();
		bwExtractorList = getDaoIntf().getBwExtractorList(requestID);
		List<String> vLookUpList = new ArrayList<String>();

		if (null != bwMasterList && !bwMasterList.isEmpty()) {
			Iterator<BwExtractorMaster> bwMasterItr = bwMasterList.iterator();
			while (bwMasterItr.hasNext()) {
				BwExtractorMaster bwMasterSheet = bwMasterItr.next();
				Row bwMasterSheetRow = bwTab2Sheet.createRow(rowIndexTab2);
				bwMasterSheetRow.createCell(0).setCellValue(bwMasterSheet.getObjName());
				bwMasterSheetRow.createCell(1).setCellValue(bwMasterSheet.getPhase());
				bwMasterSheetRow.createCell(2).setCellValue(bwMasterSheet.getAreaResponsibility());
				bwMasterSheetRow.createCell(3).setCellValue(bwMasterSheet.getDataSrc());
				bwMasterSheetRow.createCell(4).setCellValue(bwMasterSheet.getAppComp());
				bwMasterSheetRow.createCell(5).setCellValue(bwMasterSheet.getClassification());
				bwMasterSheetRow.createCell(6).setCellValue(bwMasterSheet.getCategory());
				bwMasterSheetRow.createCell(7).setCellValue(bwMasterSheet.getRestrictions());
				bwMasterSheetRow.createCell(8).setCellValue(bwMasterSheet.getRelSimpliItem());
				bwMasterSheetRow.createCell(9).setCellValue(bwMasterSheet.getNote());
				bwMasterSheetRow.createCell(10).setCellValue(bwMasterSheet.getDel1511());
				bwMasterSheetRow.createCell(11).setCellValue(bwMasterSheet.getDel1610());
				bwMasterSheetRow.createCell(12).setCellValue(bwMasterSheet.getDelRestrict());
				bwMasterSheetRow.createCell(13).setCellValue(bwMasterSheet.getComments());
				vLookUpList.add(bwMasterSheet.getObjName());
				rowIndexTab2++;
			}
		}
		if (null != bwExtractorList && !bwExtractorList.isEmpty()) {
			Iterator<BWExtractor_Download> bwItr = bwExtractorList.iterator();
			while (bwItr.hasNext()) {
				BWExtractor_Download bwSheet = bwItr.next();
				Boolean status = false;
				BwExtractorMaster masterDataMatch = new BwExtractorMaster();
				for (BwExtractorMaster data : bwMasterList) {
					if (bwSheet.getOltsource().equalsIgnoreCase(data.getObjName())) {
						status = true;
						masterDataMatch = data;
					}
				}
				Row bwSheetRow = bwTab3Sheet.createRow(rowIndexTab3);
				bwSheetRow.createCell(0).setCellValue(bwSheet.getExtractor());
				bwSheetRow.createCell(3).setCellValue(bwSheet.getOltsource());
				writeBWSheet(bwSheetRow, masterDataMatch, status);
				rowIndexTab3++;

			}

		}
		logger.info("Sucessfully Wrote BwInventory Sheet:::%%%%%%%");

	}

	private void writeBWSheet(Row bwSheetRow, BwExtractorMaster data, Boolean status) {
		if (status) {
			bwSheetRow.createCell(1).setCellValue(data.getPhase());
			bwSheetRow.createCell(2).setCellValue(data.getAreaResponsibility());
			// bwSheetRow.createCell(3).setCellValue(data.getDataSrc());
			bwSheetRow.createCell(4).setCellValue(data.getAppComp());
			bwSheetRow.createCell(5).setCellValue(data.getClassification());
			bwSheetRow.createCell(6).setCellValue(data.getCategory());
			bwSheetRow.createCell(7).setCellValue(data.getRestrictions());
			bwSheetRow.createCell(8).setCellValue(data.getRelSimpliItem());
			bwSheetRow.createCell(9).setCellValue(data.getNote());
			bwSheetRow.createCell(10).setCellValue(data.getDel1511());
			bwSheetRow.createCell(11).setCellValue(data.getDel1610());
			bwSheetRow.createCell(12).setCellValue(data.getDelRestrict());
			bwSheetRow.createCell(13).setCellValue(data.getComments());
		} else {
			bwSheetRow.createCell(1).setCellValue("NA");
			bwSheetRow.createCell(2).setCellValue("NA");
			// bwSheetRow.createCell(3).setCellValue("NA");
			bwSheetRow.createCell(4).setCellValue("NA");
			bwSheetRow.createCell(5).setCellValue("NA");
			bwSheetRow.createCell(6).setCellValue("NA");
			bwSheetRow.createCell(7).setCellValue("NA");
			bwSheetRow.createCell(8).setCellValue("NA");
			bwSheetRow.createCell(9).setCellValue("NA");
			bwSheetRow.createCell(10).setCellValue("NA");
			bwSheetRow.createCell(11).setCellValue("NA");
			bwSheetRow.createCell(12).setCellValue("NA");
			bwSheetRow.createCell(13).setCellValue("NA");
		}
	}

	private void writeInconsistentFUGRSheet(SXSSFSheet inconsistentFUGRSheet, Long requestID) {
		int rowIndex = 1;

		List<InconsistentFUGR_Download> inconsistentFUGRList = getDaoIntf().getInconsistentFUGRList(requestID);

		if (null != inconsistentFUGRList && !inconsistentFUGRList.isEmpty()) {
			Iterator<InconsistentFUGR_Download> inconsistentFUGRItr = inconsistentFUGRList.iterator();
			while (inconsistentFUGRItr.hasNext()) {
				InconsistentFUGR_Download inconsistentFUGR = inconsistentFUGRItr.next();
				Row fugrRow = inconsistentFUGRSheet.createRow(rowIndex);
				fugrRow.createCell(0).setCellValue(inconsistentFUGR.getObjectType());
				fugrRow.createCell(1).setCellValue(inconsistentFUGR.getFugrName());
				fugrRow.createCell(2).setCellValue(inconsistentFUGR.getMasterProgram());
				fugrRow.createCell(3).setCellValue(inconsistentFUGR.getExternalNamespace());
				rowIndex++;
			}
		}

		logger.info("Sucessfully Wrote Inconsistent Function Groups Sheet:::%%%%%%%");
	}

	private void writeS4SIDSheet(SXSSFSheet s4SIDSheet, Long requestID) {
		int rowIndex = 1;

		List<S4_SID_Download> s4SIDList = getDaoIntf().getS4SIDList(requestID);

		if (null != s4SIDList && !s4SIDList.isEmpty()) {
			Iterator<S4_SID_Download> s4SIDItr = s4SIDList.iterator();
			while (s4SIDItr.hasNext()) {
				S4_SID_Download s4SID = s4SIDItr.next();
				Row s4SIDRow = s4SIDSheet.createRow(rowIndex);
				s4SIDRow.createCell(0).setCellValue(s4SID.getType());
				s4SIDRow.createCell(1).setCellValue(s4SID.getObjName());
				s4SIDRow.createCell(2).setCellValue(s4SID.getSubObjType());
				s4SIDRow.createCell(3).setCellValue(s4SID.getReadProgram());
				s4SIDRow.createCell(4).setCellValue(s4SID.getPckg());
				s4SIDRow.createCell(5).setCellValue(s4SID.getOperations());
				s4SIDRow.createCell(6).setCellValue(s4SID.getLineNo());
				s4SIDRow.createCell(7).setCellValue(s4SID.getStmt());
				s4SIDRow.createCell(8).setCellValue(s4SID.getImpactReason());
				s4SIDRow.createCell(9).setCellValue(s4SID.getDescOfChange());
				s4SIDRow.createCell(10).setCellValue(s4SID.getSolutionSteps());
				s4SIDRow.createCell(11).setCellValue(s4SID.getComplexity());
				s4SIDRow.createCell(12).setCellValue(s4SID.getIssueCategory());
				s4SIDRow.createCell(13).setCellValue(s4SID.getUsed());
				s4SIDRow.createCell(14).setCellValue(s4SID.getAutomationStatus());
				s4SIDRow.createCell(15).setCellValue(s4SID.getTotalScannedLine());
				s4SIDRow.createCell(16).setCellValue(s4SID.getExternalNamespace());

				rowIndex++;
			}
		}

		logger.info("Sucessfully Wrote Impacted due to Hardcoding Sheet:::%%%%%%%");
	}

	private void writeImpactedVariantSheet(SXSSFSheet impactedVariantSheet, Long requestID) {
		int rowIndex = 1;

		List<ImpactedVariant_Download> impactedVariantList = getDaoIntf().getImpactedVariantList(requestID);

		if (null != impactedVariantList && !impactedVariantList.isEmpty()) {
			Iterator<ImpactedVariant_Download> impactedVariantItr = impactedVariantList.iterator();
			while (impactedVariantItr.hasNext()) {
				ImpactedVariant_Download impactedVariant = impactedVariantItr.next();
				Row impactedVariantRow = impactedVariantSheet.createRow(rowIndex);
				impactedVariantRow.createCell(0).setCellValue(impactedVariant.getReportName());
				impactedVariantRow.createCell(1).setCellValue(impactedVariant.getVariantName());
				impactedVariantRow.createCell(2).setCellValue(impactedVariant.getSelScreenFieldName());
				impactedVariantRow.createCell(3).setCellValue(impactedVariant.getKind());
				impactedVariantRow.createCell(4).setCellValue(impactedVariant.getSign());
				impactedVariantRow.createCell(5).setCellValue(impactedVariant.getVariantOption());
				impactedVariantRow.createCell(6).setCellValue(impactedVariant.getLow());
				impactedVariantRow.createCell(7).setCellValue(impactedVariant.getHigh());
				impactedVariantRow.createCell(8).setCellValue(impactedVariant.getUserName());
				impactedVariantRow.createCell(9).setCellValue(impactedVariant.getVariantType());
				impactedVariantRow.createCell(10).setCellValue(impactedVariant.getVariantOperation());
				impactedVariantRow.createCell(11).setCellValue(impactedVariant.getComments());
				impactedVariantRow.createCell(12).setCellValue(impactedVariant.getExternalNamespace());

				rowIndex++;
			}
		}

		logger.info("Sucessfully Wrote Impacted Variant Sheet:::%%%%%%%");
	}

	private void writeBwCleanUpUtilSheet(SXSSFSheet bwCleanupSheet, Long requestID) {
		int rowIndex = 1;

		List<BwCleanupUtilDownload> bwCleanUtilList = getDaoIntf().getBwCleanupUtilList(requestID);

		if (null != bwCleanUtilList && !bwCleanUtilList.isEmpty()) {
			Iterator<BwCleanupUtilDownload> bwCleanUtilItr = bwCleanUtilList.iterator();
			while (bwCleanUtilItr.hasNext()) {
				BwCleanupUtilDownload bwCleanutil = bwCleanUtilItr.next();
				Row bwCleanutilRow = bwCleanupSheet.createRow(rowIndex);
				bwCleanutilRow.createCell(0).setCellValue(bwCleanutil.getObjectType());
				bwCleanutilRow.createCell(1).setCellValue(bwCleanutil.getObjectName());
				bwCleanutilRow.createCell(2).setCellValue(bwCleanutil.getLastUsedDate());
				bwCleanutilRow.createCell(3).setCellValue(bwCleanutil.getElapsedTimInYrs());
				bwCleanutilRow.createCell(4).setCellValue(bwCleanutil.getStatus());

				rowIndex++;
			}
		}

		logger.info("Sucessfully Wrote Bw clean utility Sheet:::%%%%%%%");
	}

	private void writeS4ImpactedCustomTablesSheet(XSSFSheet impCustTblSheet, Long requestID, RequestForm requestForm) {
		int rowIndex = 4;
		String systemEnvt = requestForm.getSystemEnvt();
		String systemTargetVer = requestForm.getTargetVersion();
		List<S4ImpactedCustomTblDownload> impCustTblList = getDaoIntf().getImpatctedCustTablesList(requestID);
		if (systemTargetVer.startsWith("S/4"))
			impCustTblSheet.getRow(0).getCell(0)
					.setCellValue(Hana_Profiler_Constant.IMPACT_CUSTOM_TABLES_TARGET_VER_1 + " "
							+ systemTargetVer.substring(0, 3) + " " + systemTargetVer.substring(3, 7) + " "
							+ systemTargetVer.substring(7, 11) + " "
							+ Hana_Profiler_Constant.IMPACT_CUSTOM_TABLES_TARGET_VER_2);
		else
			impCustTblSheet.getRow(0).getCell(0).setCellValue(Hana_Profiler_Constant.IMPACT_CUSTOM_TABLES_TARGET_VER_1
					+ " " + systemTargetVer + " " + Hana_Profiler_Constant.IMPACT_CUSTOM_TABLES_TARGET_VER_2);
		if (systemEnvt.equalsIgnoreCase("Production"))
			impCustTblSheet.getRow(1).getCell(0).setCellType(HSSFCell.CELL_TYPE_BLANK);
		else
			impCustTblSheet.getRow(1).getCell(0).setCellValue(Hana_Profiler_Constant.IMPACT_CUSTOM_TABLES_SYSTEM_ENVT_1
					+ " " + systemEnvt + " " + Hana_Profiler_Constant.IMPACT_CUSTOM_TABLES_SYSTEM_ENVT_2);

		if (null != impCustTblList && !impCustTblList.isEmpty()) {
			Iterator<S4ImpactedCustomTblDownload> impCustTblItr = impCustTblList.iterator();
			while (impCustTblItr.hasNext()) {
				S4ImpactedCustomTblDownload impCustTbl = impCustTblItr.next();
				Row impCustTblRow = impCustTblSheet.createRow(rowIndex);
				impCustTblRow.createCell(0).setCellValue(impCustTbl.getObjectName());
				impCustTblRow.createCell(1).setCellValue(impCustTbl.getObjPackage());
				impCustTblRow.createCell(2).setCellValue(impCustTbl.getComments());
				impCustTblRow.createCell(3).setCellValue(impCustTbl.getTriggerObj());
				impCustTblRow.createCell(4).setCellValue(impCustTbl.getDescOfChange());
				impCustTblRow.createCell(5).setCellValue(impCustTbl.getSapNote());
				impCustTblRow.createCell(6).setCellValue(impCustTbl.getSolStep());
				impCustTblRow.createCell(7).setCellValue(impCustTbl.getComplexity());
				impCustTblRow.createCell(8).setCellValue(impCustTbl.getIssueCat());
				impCustTblRow.createCell(9).setCellValue(impCustTbl.getIssueSubCat());
				impCustTblRow.createCell(10).setCellValue(impCustTbl.getTriggerObj());
				impCustTblRow.createCell(11).setCellValue(impCustTbl.getRemediCat());
				impCustTblRow.createCell(12).setCellValue(impCustTbl.getSapSimpliList());
				impCustTblRow.createCell(13).setCellValue(impCustTbl.getAppComp());
				impCustTblRow.createCell(14).setCellValue(impCustTbl.getSapSimpliCat());
				impCustTblRow.createCell(15).setCellValue(impCustTbl.getItemArea());

				rowIndex++;
			}
		}

		logger.info("Sucessfully Wrote S4 Impacted Custom Table Sheet:::%%%%%%%");
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/downloadEstimatorAssumptions/{requestID}", method = RequestMethod.GET)
	public synchronized String downloadEstimatorAssumptions(@PathVariable("requestID") Long requestID, Model model,
			HttpServletResponse response, HttpServletRequest request, final RedirectAttributes redirectAttributes)
			throws Exception {

		String graphTemplete = request.getSession().getServletContext()
				.getRealPath("/staticResources/GraphTemplate/Estimator_Assumption_Client.xlsx");

		final RequestForm requestForm = getRequestDetails().getRequestObj(requestID);

		XSSFWorkbook workbook = new XSSFWorkbook(OPCPackage.open(new FileInputStream(graphTemplete)));
		@SuppressWarnings("resource")
		SXSSFWorkbook workbookTemp = new SXSSFWorkbook(workbook);
		workbookTemp.setCompressTempFiles(true);

		// Logic to be written

		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		workbookTemp.write(bos);
		bos.close();

		byte[] bytes = bos.toByteArray();
		getFileDownload()
				.downloadFile(bytes, response,
						HANAUtility.join("_", "AADT Profiler", requestForm.getClientName(),
								requestForm.getSourceVersion(), requestForm.getTargetVersion(), requestID.toString())
								+ ".xlsx");

		return null;
	}

	// Writing Estimations Sheets for Admin
	/**
	 * Section For Estimator Start
	 * 
	 **/
	private void wroteEstimationsSheetForAdmin(Long requestID, XSSFSheet hanaEstimator) {

		// Logic to be written

	}

	/**
	 * Section For Estimator Close
	 * 
	 **/

	// Writing Estimations Sheets for Client
	private void wroteEstimationsSheetForClient(Long requestID, XSSFSheet Estimator) {

		// Logic to be written

	}

	// Writing Assumptions Sheets
	private void wroteAssumptionSheetForClient(Long requestID, XSSFSheet assumptionSheet) {

		// Logic to be written

	}

	private Integer getUsedUnusedColumnCount(String key, Map<String, Integer> usedUnsedMap) {
		Integer count = 0;
		if (usedUnsedMap != null && usedUnsedMap.containsKey(key)) {
			count = usedUnsedMap.get(key);
		}

		return count;
	}

	@RequestMapping(value = "/view/summary/{requestID}/{viewType}", method = RequestMethod.GET)
	public ModelAndView graphView1(ModelAndView model, @PathVariable("requestID") final String requestId,
			@PathVariable("viewType") final String viewType) {

		Long ReqID = Long.parseLong(requestId);
		String view = "";
		ModelAndView modenAndView = null;
		if ("application".equals(viewType)) {
			view = "/ApplicationComponentTabularViewClientS4";
			modenAndView = new ModelAndView(view);
			modenAndView.addObject("application",
					getGraphS4DAO().getCountApplicationComponent(Long.parseLong(requestId)));
			modenAndView.addObject("sapnote", getGraphS4DAO().getCountSAPNote(ReqID, null));
			modenAndView.addObject("sapnotecode", "ALL");
		} else if (Hana_Profiler_Constant.GRAPHICAL.equals(viewType)) {
			view = "/summaryGraphViewClient";
			modenAndView = new ModelAndView(view);
			modenAndView.addObject("cateGory", getGraphDao().getGraphCountCategory(Long.parseLong(requestId)));
			modenAndView.addObject("subCateGory", getGraphDao().getGraphCountSubCategory(Long.parseLong(requestId)));
			modenAndView.addObject("usedUnused", getGraphDao().getGraphCountUsedUnused(Long.parseLong(requestId)));
			modenAndView.addObject("impact", getGraphDao().getGraphCountImpact(Long.parseLong(requestId)));
			modenAndView.addObject("cateGorys4", getGraphS4DAO().getGraphCountRemediCategry(Long.parseLong(requestId)));
			modenAndView.addObject("subCateGorys4", getGraphS4DAO().getGraphCountErrCategry(Long.parseLong(requestId)));
			modenAndView.addObject("usedUnuseds4", getGraphS4DAO().getGraphCountFinalUsed(Long.parseLong(requestId)));
			modenAndView.addObject("impacts4", getGraphS4DAO().getGraphCountFinalComplexity(Long.parseLong(requestId)));
			modenAndView.addObject("applications4",
					getGraphS4DAO().getMaxApplicationComponent(Long.parseLong(requestId)));
		} else {
			view = "/summaryTabularViewClient";
			modenAndView = new ModelAndView(view);
			modenAndView.addObject("cateGory", getGraphDao().getGraphCountCategory(Long.parseLong(requestId)));
			modenAndView.addObject("subCateGory", getGraphDao().getGraphCountSubCategory(Long.parseLong(requestId)));
			modenAndView.addObject("usedUnused", getGraphDao().getGraphCountUsedUnused(Long.parseLong(requestId)));
			modenAndView.addObject("impact", getGraphDao().getGraphCountImpact(Long.parseLong(requestId)));
			final Map<String, Map<String, Integer>> objectType = getGraphDao()
					.getObjectTypeUsedunusedCount(Long.parseLong(requestId));
			modenAndView.addObject("progUsedCount", getUsedUnusedColumnCount("Used", objectType.get("PROG")));
			modenAndView.addObject("progUnusedCount", getUsedUnusedColumnCount("Unused", objectType.get("PROG")));
			modenAndView.addObject("classUsedCount", getUsedUnusedColumnCount("Used", objectType.get("CLAS")));
			modenAndView.addObject("classUnusedCount", getUsedUnusedColumnCount("Unused", objectType.get("CLAS")));
			modenAndView.addObject("fugrUsedCount", getUsedUnusedColumnCount("Used", objectType.get("FUGR")));
			modenAndView.addObject("fugrUnusedCount", getUsedUnusedColumnCount("Unused", objectType.get("FUGR")));
			modenAndView.addObject("requestID", requestId);
		}
		return modenAndView;
	}

	@RequestMapping(value = "/view/inventory/{requestID}", method = RequestMethod.GET)
	public String finalOutput(@PathVariable("requestID") final long requestId, HttpServletRequest request,
			Model model) {
		model.addAttribute("requestID", requestId);
		request.getSession().setAttribute("requestID", requestId);
		return "client/clientGridDisplay";
	}

	// AIES Tool Integration
	@RequestMapping(value = "/summary/view/{requestID}/{viewType}", method = RequestMethod.GET)
	public ModelAndView graphViewAIES(ModelAndView model, @PathVariable("requestID") final String requestId,
			@PathVariable("viewType") final String viewType, HttpServletRequest request, HttpSession session) {

		String view = "";
		ModelAndView modenAndView = null;
		String toolName = "";

		List<ProcessedRequestDetail> reqMasterList = getGraphDao().getReqMaster(Long.parseLong(requestId));
		if (!reqMasterList.isEmpty() && reqMasterList.size() > 0) {
			ProcessedRequestDetail reqMaster = reqMasterList.get(0);

			toolName = reqMaster.getScope();
			// String clientName=reqMaster.getClientName();
		} else {
			toolName = "s4";
		}
		// session.setAttribute("clientName", clientName);
		if (toolName.equalsIgnoreCase("Hana")) {
			if (Hana_Profiler_Constant.GRAPHICAL.equalsIgnoreCase(viewType)) {
				view = "/summaryGraphViewClientAIES";
				modenAndView = new ModelAndView(view);
				modenAndView.addObject("cateGory", getGraphDao().getGraphCountCategory(Long.parseLong(requestId)));
				modenAndView.addObject("subCateGory",
						getGraphDao().getGraphCountSubCategory(Long.parseLong(requestId)));
				modenAndView.addObject("usedUnused", getGraphDao().getGraphCountUsedUnused(Long.parseLong(requestId)));
				modenAndView.addObject("impact", getGraphDao().getGraphCountImpact(Long.parseLong(requestId)));
				// modenAndView.addObject("clientName",clientName);
			} else {
				view = "/summaryTabularViewClientAIES";
				modenAndView = new ModelAndView(view);
				modenAndView.addObject("cateGory", getGraphDao().getGraphCountCategory(Long.parseLong(requestId)));
				modenAndView.addObject("subCateGory",
						getGraphDao().getGraphCountSubCategory(Long.parseLong(requestId)));
				modenAndView.addObject("usedUnused", getGraphDao().getGraphCountUsedUnused(Long.parseLong(requestId)));
				modenAndView.addObject("impact", getGraphDao().getGraphCountImpact(Long.parseLong(requestId)));
				// modenAndView.addObject("clientName",clientName);

				final Map<String, Map<String, Integer>> objectType = getGraphDao()
						.getObjectTypeUsedunusedCount(Long.parseLong(requestId));
				modenAndView.addObject("progUsedCount", getUsedUnusedColumnCount("Used", objectType.get("PROG")));
				modenAndView.addObject("progUnusedCount", getUsedUnusedColumnCount("Unused", objectType.get("PROG")));
				modenAndView.addObject("classUsedCount", getUsedUnusedColumnCount("Used", objectType.get("CLAS")));
				modenAndView.addObject("classUnusedCount", getUsedUnusedColumnCount("Unused", objectType.get("CLAS")));
				modenAndView.addObject("fugrUsedCount", getUsedUnusedColumnCount("Used", objectType.get("FUGR")));
				modenAndView.addObject("fugrUnusedCount", getUsedUnusedColumnCount("Unused", objectType.get("FUGR")));
				modenAndView.addObject("requestID", requestId);
			}
		} else {
			if (Hana_Profiler_Constant.GRAPHICAL.equalsIgnoreCase(viewType)) {
				view = "/summaryGraphViewS4AIES";
				modenAndView = new ModelAndView(view);
				modenAndView.addObject("cateGory",
						getGraphS4DAO().getGraphCountRemediCategry(Long.parseLong(requestId)));
				modenAndView.addObject("subCateGory",
						getGraphS4DAO().getGraphCountErrCategry(Long.parseLong(requestId)));
				modenAndView.addObject("usedUnused", getGraphS4DAO().getGraphCountFinalUsed(Long.parseLong(requestId)));
				modenAndView.addObject("impact",
						getGraphS4DAO().getGraphCountFinalComplexity(Long.parseLong(requestId)));
				// modenAndView.addObject("clientName",clientName);
			} else {
				view = "/summaryTabularViewS4AIES";
				modenAndView = new ModelAndView(view);
				modenAndView.addObject("cateGory",
						getGraphS4DAO().getGraphCountRemediCategry(Long.parseLong(requestId)));
				modenAndView.addObject("subCateGory",
						getGraphS4DAO().getGraphCountErrCategry(Long.parseLong(requestId)));
				modenAndView.addObject("usedUnused", getGraphS4DAO().getGraphCountFinalUsed(Long.parseLong(requestId)));
				modenAndView.addObject("impact",
						getGraphS4DAO().getGraphCountFinalComplexity(Long.parseLong(requestId)));
				// modenAndView.addObject("clientName",clientName);

				final Map<String, Map<String, Integer>> objectType = getGraphS4DAO()
						.getObjectTypeUsedCount(Long.parseLong(requestId));
				modenAndView.addObject("progUsedCount", getUsedColumnCount("Y", objectType.get("PROG")));

				modenAndView.addObject("classUsedCount", getUsedColumnCount("Y", objectType.get("CLAS")));

				modenAndView.addObject("fugrUsedCount", getUsedColumnCount("Y", objectType.get("FUGR")));

				modenAndView.addObject("enhoUsedCount", getUsedColumnCount("Y", objectType.get("ENHO")));

				modenAndView.addObject("enhcUsedCount", getUsedColumnCount("Y", objectType.get("ENHC")));

				modenAndView.addObject("enhsUsedCount", getUsedColumnCount("Y", objectType.get("ENHS")));
				modenAndView.addObject("indeUsedCount", getUsedColumnCount("Y", objectType.get("INDE")));

				modenAndView.addObject("viewUsedCount", getUsedColumnCount("Y", objectType.get("VIEW")));

				modenAndView.addObject("wdynUsedCount", getUsedColumnCount("Y", objectType.get("WDYN")));

				modenAndView.addObject("ssfoUsedCount", getUsedColumnCount("Y", objectType.get("SSFO")));

				modenAndView.addObject("requestID", requestId);
			}
		}
		return modenAndView;
	}

	private Integer getUsedColumnCount(String key, Map<String, Integer> usedUnsedMap) {
		Integer count = 0;
		if (usedUnsedMap != null && usedUnsedMap.containsKey(key)) {
			count = usedUnsedMap.get(key);
		}

		return count;
	}

	@RequestMapping(value = "/downloadSimplificationFile", method = RequestMethod.GET)
	public synchronized String downloadSimplificationFile(Model model, HttpServletResponse response,
			HttpServletRequest request, final RedirectAttributes redirectAttributes) throws Exception {

		String graphTemplete = request.getSession().getServletContext()
				.getRealPath("/staticResources/GraphTemplate/Simplification To Be Uploaded.xlsx");

		XSSFWorkbook workbook = new XSSFWorkbook(OPCPackage.open(new FileInputStream(graphTemplete)));
		SXSSFWorkbook workbookTemp = new SXSSFWorkbook(workbook);
		workbookTemp.setCompressTempFiles(true);

		// Writing Inventory
		XSSFSheet simplificationSheet = workbookTemp.getXSSFWorkbook().getSheetAt(0);

		int rowIndex = 1;
		List<OperationDataS4> simplificationList = getGraphS4DAO().getS4Simplification();

		if (simplificationList.isEmpty() || null == simplificationList) {
			redirectAttributes.addFlashAttribute("donLoadXlsxError", "No Records Found To Download");
			return "redirect:/admin/simplification";
		}

		else {
			Iterator<OperationDataS4> simplificationItr = simplificationList.iterator();
			while (simplificationItr.hasNext()) {

				OperationDataS4 oprData = simplificationItr.next();
				Row simplificationRow = simplificationSheet.createRow(rowIndex);

				simplificationRow.createCell(0)
						.setCellValue(oprData.getS4_hana_changes() == null || oprData.getS4_hana_changes().isEmpty()
								? "NA" : oprData.getS4_hana_changes());
				simplificationRow.createCell(1).setCellValue(
						oprData.getObject() == null || oprData.getObject().isEmpty() ? "NA" : oprData.getObject());
				simplificationRow.createCell(2)
						.setCellValue(oprData.getObjectType() == null || oprData.getObjectType().isEmpty() ? "NA"
								: oprData.getObjectType());

				simplificationRow.createCell(3)
						.setCellValue(oprData.getObsolete() == null || oprData.getObsolete().isEmpty() ? "NA"
								: oprData.getObsolete());
				simplificationRow.createCell(4)
						.setCellValue(oprData.getDescription() == null || oprData.getDescription().isEmpty() ? "NA"
								: oprData.getDescription());
				simplificationRow.createCell(5)
						.setCellValue(oprData.getAffectedArea() == null || oprData.getAffectedArea().isEmpty() ? "NA"
								: oprData.getAffectedArea());

				simplificationRow.createCell(6)
						.setCellValue(oprData.getRelatedNotes() == null || oprData.getRelatedNotes().isEmpty() ? "NA"
								: oprData.getRelatedNotes());
				simplificationRow.createCell(7)
						.setCellValue(oprData.getSolutionSteps() == null || oprData.getSolutionSteps().isEmpty() ? "NA"
								: oprData.getSolutionSteps());
				simplificationRow.createCell(8).setCellValue(
						oprData.getErrCategoryNumeric() == null || oprData.getErrCategoryNumeric().isEmpty() ? "NA"
								: oprData.getErrCategoryNumeric());

				simplificationRow.createCell(9).setCellValue(
						oprData.getVersion() == null || oprData.getVersion().isEmpty() ? "NA" : oprData.getVersion());
				simplificationRow.createCell(10)
						.setCellValue(oprData.getIdentifier() == null || oprData.getIdentifier().isEmpty() ? "NA"
								: oprData.getIdentifier());
				simplificationRow.createCell(11)
						.setCellValue(oprData.getComplexity() == null || oprData.getComplexity().isEmpty() ? "NA"
								: oprData.getComplexity());

				simplificationRow.createCell(12)
						.setCellValue(oprData.getIssueCatgry() == null || oprData.getIssueCatgry().isEmpty() ? "NA"
								: oprData.getIssueCatgry());
				simplificationRow.createCell(13)
						.setCellValue(oprData.getErrorCatgry() == null || oprData.getErrorCatgry().isEmpty() ? "NA"
								: oprData.getErrorCatgry());
				simplificationRow.createCell(14)
						.setCellValue(oprData.getTriggerObj() == null || oprData.getTriggerObj().isEmpty() ? "NA"
								: oprData.getTriggerObj());

				simplificationRow.createCell(15)
						.setCellValue(oprData.getRemediationCatgry() == null || oprData.getRemediationCatgry().isEmpty()
								? "NA" : oprData.getRemediationCatgry());
				simplificationRow.createCell(16).setCellValue(
						oprData.getSapSimplListChaptr() == null || oprData.getSapSimplListChaptr().isEmpty() ? "NA"
								: oprData.getSapSimplListChaptr());
				simplificationRow.createCell(17)
						.setCellValue(oprData.getAppComponent() == null || oprData.getAppComponent().isEmpty() ? "NA"
								: oprData.getAppComponent());

				simplificationRow.createCell(18)
						.setCellValue(oprData.getSapSimplCatry() == null || oprData.getSapSimplCatry().isEmpty() ? "NA"
								: oprData.getSapSimplCatry());
				simplificationRow.createCell(19)
						.setCellValue(oprData.getItm_Area() == null || oprData.getItm_Area().isEmpty() ? "NA"
								: oprData.getItm_Area());
				rowIndex++;
			}
		}
		logger.info("Sucessfully Wrote Simplification Sheet:::%%%%%%%");

		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		workbookTemp.write(bos);
		bos.close();

		byte[] bytes = bos.toByteArray();
		getFileDownload().downloadFile(bytes, response,
				HANAUtility.join("_", "Simplification To Be Uploaded") + ".xlsx");

		return null;

	}

	// Writing SmodologData sheet
	private void writeSmodilogData(SXSSFSheet smodilogDataSheet, Long requestID) {
		int rowIndex = 1;
		List<SmodilogFunction_Download> smodologDataList = getGraphS4DAO().getSmodilogData(requestID);

		if (null != smodologDataList && !smodologDataList.isEmpty()) {
			Iterator<SmodilogFunction_Download> smodologDataItr = smodologDataList.iterator();
			while (smodologDataItr.hasNext()) {

				SmodilogFunction_Download smodilogData = smodologDataItr.next();
				Row smodilogDataRow = smodilogDataSheet.createRow(rowIndex);

				smodilogDataRow.createCell(0).setCellValue(smodilogData.getObjType());
				smodilogDataRow.createCell(1).setCellValue(smodilogData.getObjName());
				smodilogDataRow.createCell(2).setCellValue(smodilogData.getSubType());
				smodilogDataRow.createCell(3).setCellValue(smodilogData.getSubName());
				smodilogDataRow.createCell(4).setCellValue(smodilogData.getIntType());
				smodilogDataRow.createCell(5).setCellValue(smodilogData.getIntName());
				smodilogDataRow.createCell(6).setCellValue(smodilogData.getModUser());
				smodilogDataRow.createCell(7).setCellValue(smodilogData.getModDate());
				smodilogDataRow.createCell(8).setCellValue(smodilogData.getModTime());
				smodilogDataRow.createCell(9).setCellValue(smodilogData.getTrkorr());
				smodilogDataRow.createCell(10).setCellValue(smodilogData.getSpddObjects());
				smodilogDataRow.createCell(11).setCellValue(smodilogData.getSpauObjects());
				rowIndex++;
			}
		}

		logger.info("Sucessfully Wrote SmodilogData Sheet:::%%%%%%%");
	}

	/*
	 * public void writeS4CvitAssessmentData(XSSFSheet s4CvitAssessmentSheet,
	 * Long requestId, RequestForm requestForm) {
	 * 
	 * List<S4CvitAssessment> s4CvitAssessmentList =
	 * getS4DaoIntf().getS4CvitAssessmentData(requestId); String systemID =
	 * requestForm.getSystemId(); if (s4CvitAssessmentList != null &&
	 * !s4CvitAssessmentList.isEmpty()) { Map<Integer, String>
	 * s4CvitAssessmentMap = getS4ProcessingService()
	 * .getS4CvitAssessmentMap(s4CvitAssessmentList);
	 * 
	 * Row row; Cell col;
	 * 
	 * row = s4CvitAssessmentSheet.getRow(2); col = row.getCell(1); String
	 * cellValue = setCellValue(col.getStringCellValue(), systemID, 8); String
	 * cvitValue = s4CvitAssessmentMap.get(100); if (cvitValue.equals("0")) {
	 * cvitValue = "No"; } col.setCellValue(setCellValue(cellValue, cvitValue,
	 * 1)); col = row.getCell(4); cellValue =
	 * setCellValue(col.getStringCellValue(), systemID, 18); Integer value131 =
	 * Integer.valueOf(s4CvitAssessmentMap.get(131)); Integer value132 =
	 * Integer.valueOf(s4CvitAssessmentMap.get(132)); cvitValue =
	 * String.valueOf(value131 + value132);
	 * col.setCellValue(setCellValue(cellValue, cvitValue, 8));
	 * 
	 * row = s4CvitAssessmentSheet.getRow(3); col = row.getCell(1); cellValue =
	 * setCellValue(col.getStringCellValue(), systemID, 2); cvitValue =
	 * s4CvitAssessmentMap.get(109); col.setCellValue(setCellValue(cellValue,
	 * cvitValue, 10));
	 * 
	 * // Writing from row 5 to 7 - first Block
	 * writeFromRow5To17(s4CvitAssessmentSheet, s4CvitAssessmentMap, row, col,
	 * 101);
	 * 
	 * // Writing from row 5 to 7 - Second block -- Vendor
	 * writeFromRow10To18Vendor(s4CvitAssessmentSheet, s4CvitAssessmentMap, row,
	 * col, 122);
	 * 
	 * // Writing from row 5 to 7 - Second block -- Customer
	 * writeFromRow10To18Customer(s4CvitAssessmentSheet, s4CvitAssessmentMap,
	 * row, col, 144);
	 * 
	 * row = s4CvitAssessmentSheet.getRow(5); col = row.getCell(7);
	 * col.setCellValue(s4CvitAssessmentMap.get(116)); col = row.getCell(8);
	 * col.setCellValue(s4CvitAssessmentMap.get(117));
	 * 
	 * row = s4CvitAssessmentSheet.getRow(7); col = row.getCell(7);
	 * col.setCellValue(s4CvitAssessmentMap.get(118)); col = row.getCell(8);
	 * col.setCellValue(s4CvitAssessmentMap.get(119));
	 * 
	 * row = s4CvitAssessmentSheet.getRow(8); col = row.getCell(7);
	 * col.setCellValue(s4CvitAssessmentMap.get(120)); col = row.getCell(8);
	 * col.setCellValue(s4CvitAssessmentMap.get(121));
	 * 
	 * row = s4CvitAssessmentSheet.getRow(19); col = row.getCell(1); cellValue =
	 * setCellValue(col.getStringCellValue(), systemID, 16);
	 * col.setCellValue(cellValue);
	 * 
	 * row = s4CvitAssessmentSheet.getRow(19); col = row.getCell(7);
	 * col.setCellValue(s4CvitAssessmentMap.get(131)); col = row.getCell(8);
	 * col.setCellValue(s4CvitAssessmentMap.get(132));
	 * 
	 * row = s4CvitAssessmentSheet.getRow(21); col = row.getCell(7);
	 * col.setCellValue(s4CvitAssessmentMap.get(133)); col = row.getCell(8);
	 * col.setCellValue(s4CvitAssessmentMap.get(134));
	 * 
	 * row = s4CvitAssessmentSheet.getRow(22); col = row.getCell(1);
	 * col.setCellValue(s4CvitAssessmentMap.get(114)); col = row.getCell(2);
	 * col.setCellValue(s4CvitAssessmentMap.get(115)); col = row.getCell(7);
	 * col.setCellValue(s4CvitAssessmentMap.get(135)); col = row.getCell(8);
	 * col.setCellValue(s4CvitAssessmentMap.get(136));
	 * 
	 * row = s4CvitAssessmentSheet.getRow(23); col = row.getCell(7);
	 * col.setCellValue(s4CvitAssessmentMap.get(137)); col = row.getCell(8);
	 * col.setCellValue(s4CvitAssessmentMap.get(138));
	 * 
	 * row = s4CvitAssessmentSheet.getRow(24); col = row.getCell(7);
	 * col.setCellValue(s4CvitAssessmentMap.get(141)); col = row.getCell(8);
	 * col.setCellValue(s4CvitAssessmentMap.get(142));
	 * 
	 * row = s4CvitAssessmentSheet.getRow(25); col = row.getCell(7);
	 * col.setCellValue(s4CvitAssessmentMap.get(139)); col = row.getCell(8);
	 * col.setCellValue(s4CvitAssessmentMap.get(140)); } }
	 */

	public void writeS4CvitAssessmentData(XSSFSheet s4CvitAssessmentSheet, Long requestId, RequestForm requestForm) {
		List<S4CvitAssessment> s4CvitAssessmentList = getS4DaoIntf().getS4CvitAssessmentData(requestId);
		String systemID = requestForm.getSystemId();
		if (s4CvitAssessmentList != null && !s4CvitAssessmentList.isEmpty()) {
			Map<Integer, String> s4CvitAssessmentMap = getS4ProcessingService()
					.getS4CvitAssessmentMap(s4CvitAssessmentList);

			Row row;
			Cell col;

			row = s4CvitAssessmentSheet.getRow(3);
			col = row.getCell(1);
			String cellValue = setCellValue(col.getStringCellValue(), systemID, 8);
			String cvitValue = s4CvitAssessmentMap.get(100);
			if (cvitValue.equals("0")) {
				cvitValue = "No";
			}

			col.setCellValue(setCellValue(cellValue, cvitValue, 1));

			row = s4CvitAssessmentSheet.getRow(4);
			col = row.getCell(1);
			cellValue = setCellValue(col.getStringCellValue(), systemID, 2);
			cvitValue = s4CvitAssessmentMap.get(101);
			col.setCellValue(setCellValue(cellValue, cvitValue, 10));

			row = s4CvitAssessmentSheet.getRow(20);
			col = row.getCell(1);
			col.setCellValue(setCellValue(col.getStringCellValue(), systemID, 16));

			// Writing from row 6 to 18 - first Block
			writeFromRow6To19(s4CvitAssessmentSheet, s4CvitAssessmentMap, row, col, 102);

			row = s4CvitAssessmentSheet.getRow(23);
			col = row.getCell(1);
			col.setCellValue(s4CvitAssessmentMap.get(115));
			col = row.getCell(2);
			col.setCellValue(s4CvitAssessmentMap.get(116));

			row = s4CvitAssessmentSheet.getRow(5);
			cvitValue = s4CvitAssessmentMap.get(117);
			int count = 0;
			String cvit[] = cvitValue.split("/");
			if (!Objects.isNull(cvit)) {
				col = row.getCell(8);
				col.setCellValue(cvit[0]);

				col = row.getCell(9);
				col.setCellValue(cvit[1]);

				count = Integer.parseInt(cvit[0]) + Integer.parseInt(cvit[1]);
			}

			int customisingErrorCount = 0;

			// Wrtiing customer data from row 7 to 19
			customisingErrorCount = writeCustomerCounts(s4CvitAssessmentSheet, s4CvitAssessmentMap, row, col, 118, 7,
					19, customisingErrorCount);

			// Writing vendor data from row 20 to 24
			customisingErrorCount = writeVendorCounts(s4CvitAssessmentSheet, s4CvitAssessmentMap, row, col, 131, 20, 24,
					customisingErrorCount);

			// Writing customer data from row 25 to 29
			customisingErrorCount = writeCustomerCounts(s4CvitAssessmentSheet, s4CvitAssessmentMap, row, col, 136, 25,
					29, customisingErrorCount);

			// Writing vendor data from row 30 to 37
			customisingErrorCount = writeVendorCounts(s4CvitAssessmentSheet, s4CvitAssessmentMap, row, col, 141, 30, 37,
					customisingErrorCount);

			row = s4CvitAssessmentSheet.getRow(6);
			col = row.getCell(8);
			col.setCellValue(customisingErrorCount);

			row = s4CvitAssessmentSheet.getRow(2);
			col = row.getCell(6);
			col.setCellValue(
					setCellValue(col.getStringCellValue(), Integer.toString(count + customisingErrorCount), 8));
			col.setCellValue(setCellValue(col.getStringCellValue(), systemID, 18));
		}
	}

	/*
	 * private void writeFromRow5To17(XSSFSheet s4CvitAssessmentSheet,
	 * Map<Integer, String> s4CvitAssessmentMap, Row row, Cell col, int key) {
	 * for (int rn = 5; rn <= 18; rn++) { if (rn == 14) { key++; } else if (rn
	 * == 10) { // Object Type - 143 row = s4CvitAssessmentSheet.getRow(rn); col
	 * = row.getCell(2); col.setCellValue(s4CvitAssessmentMap.get(143)); } else
	 * if (rn == 18) { row = s4CvitAssessmentSheet.getRow(rn); col =
	 * row.getCell(1); String cellValue = col.getStringCellValue(); String
	 * cvitValue = s4CvitAssessmentMap.get(key);
	 * col.setCellValue(setCellValue(cellValue, cvitValue, 0)); } else { row =
	 * s4CvitAssessmentSheet.getRow(rn); col = row.getCell(2);
	 * col.setCellValue(s4CvitAssessmentMap.get(key)); key++; } } }
	 * 
	 * private void writeFromRow10To18Vendor(XSSFSheet s4CvitAssessmentSheet,
	 * Map<Integer, String> s4CvitAssessmentMap, Row row, Cell col, int key) {
	 * for (int rn = 10; rn <= 18; rn++) { row =
	 * s4CvitAssessmentSheet.getRow(rn); col = row.getCell(8);
	 * col.setCellValue(s4CvitAssessmentMap.get(key)); key++; } }
	 * 
	 * private void writeFromRow10To18Customer(XSSFSheet s4CvitAssessmentSheet,
	 * Map<Integer, String> s4CvitAssessmentMap, Row row, Cell col, int key) {
	 * for (int rn = 10; rn <= 18; rn++) { row =
	 * s4CvitAssessmentSheet.getRow(rn); col = row.getCell(7);
	 * col.setCellValue(s4CvitAssessmentMap.get(key)); key++; } }
	 */

	private void writeFromRow6To19(XSSFSheet s4CvitAssessmentSheet, Map<Integer, String> s4CvitAssessmentMap, Row row,
			Cell col, int key) {
		for (int rn = 6; rn <= 19; rn++) {
			if (rn == 15)
				continue;
			else if (rn == 19) {
				row = s4CvitAssessmentSheet.getRow(rn);
				col = row.getCell(1);
				String cellValue = col.getStringCellValue();
				String cvitValue = s4CvitAssessmentMap.get(key);
				col.setCellValue(setCellValue(cellValue, cvitValue, 0));
			} else {
				row = s4CvitAssessmentSheet.getRow(rn);
				col = row.getCell(2);
				col.setCellValue(s4CvitAssessmentMap.get(key));
				key++;
			}
		}
	}

	private int writeVendorCounts(XSSFSheet s4CvitAssessmentSheet, Map<Integer, String> s4CvitAssessmentMap, Row row,
			Cell col, int key, int rowStartIndex, int rowEndIndex, Integer customisingErrorCount) {
		for (int rn = rowStartIndex; rn <= rowEndIndex; rn++) {
			row = s4CvitAssessmentSheet.getRow(rn);
			col = row.getCell(9);
			col.setCellValue(s4CvitAssessmentMap.get(key));
			customisingErrorCount += Integer.parseInt(s4CvitAssessmentMap.get(key));
			key++;
		}

		int count = customisingErrorCount;
		return count;
	}

	private int writeCustomerCounts(XSSFSheet s4CvitAssessmentSheet, Map<Integer, String> s4CvitAssessmentMap, Row row,
			Cell col, int key, int rowStartIndex, int rowEndIndex, Integer customisingErrorCount) {
		for (int rn = rowStartIndex; rn <= rowEndIndex; rn++) {
			row = s4CvitAssessmentSheet.getRow(rn);
			col = row.getCell(8);
			col.setCellValue(s4CvitAssessmentMap.get(key));
			customisingErrorCount += Integer.parseInt(s4CvitAssessmentMap.get(key));
			key++;
		}

		int count = customisingErrorCount;
		return count;
	}

	private String setCellValue(String cellValue, String cvitValue, int index) {
		String strArr[] = cellValue.split(" ");
		strArr[index] = cvitValue;

		StringBuilder sb = new StringBuilder();
		for (String s : strArr) {
			sb.append(s).append(" ");
		}
		return sb.toString();
	}

	public void setPocStausAfterFileDownload(RequestForm requestForm, Long requestID, String userName,
			RequestInventory reqInvObj) {
		boolean sia = requestForm.getSia() || requestForm.getGrc();
		boolean bw = requestForm.getBwUsage();
		boolean mainScp = requestForm.getSOH() || requestForm.getFiori() || requestForm.getS4Functional()
				|| requestForm.getS4Technical() || requestForm.getUI5() || requestForm.getUPGRADE();
		boolean ext = requestForm.getEXT();
		if (bw && sia && mainScp) {
			if (reqInvObj.getBwFileDnldSts() && reqInvObj.getSaFileDnldSts() && reqInvObj.getFinalFileDnldSts()) {
				getRequestInventorydao().updatePOCStatusAndSubStatus(Long.valueOf(requestID), userName,
						"Final_DOWN_DONE_POC", Hana_Profiler_Constant.REQ_SS_PROCESSED_FL_DL_SUCC);
			}
		} else if (sia && bw && !mainScp) {
			if (reqInvObj.getSaFileDnldSts() && reqInvObj.getBwFileDnldSts()) {
				getRequestInventorydao().updatePOCStatusAndSubStatus(Long.valueOf(requestID), userName,
						"Final_DOWN_DONE_POC", Hana_Profiler_Constant.REQ_SS_PROCESSED_FL_DL_SUCC);
			}
		} else if (bw && mainScp && !sia) {
			if (reqInvObj.getBwFileDnldSts() && reqInvObj.getFinalFileDnldSts()) {
				getRequestInventorydao().updatePOCStatusAndSubStatus(Long.valueOf(requestID), userName,
						"Final_DOWN_DONE_POC", Hana_Profiler_Constant.REQ_SS_PROCESSED_FL_DL_SUCC);
			}

		} else if (sia && mainScp && !bw) {
			if (reqInvObj.getFinalFileDnldSts() && reqInvObj.getSaFileDnldSts()) {
				getRequestInventorydao().updatePOCStatusAndSubStatus(Long.valueOf(requestID), userName,
						"Final_DOWN_DONE_POC", Hana_Profiler_Constant.REQ_SS_PROCESSED_FL_DL_SUCC);
			}
		} else if (sia && !bw && !mainScp) {
			if (reqInvObj.getSaFileDnldSts()) {
				getRequestInventorydao().updatePOCStatusAndSubStatus(Long.valueOf(requestID), userName,
						"Final_DOWN_DONE_POC", Hana_Profiler_Constant.REQ_SS_PROCESSED_FL_DL_SUCC);
			}
		} else if (bw && !sia && !mainScp) {
			if (reqInvObj.getBwFileDnldSts()) {
				getRequestInventorydao().updatePOCStatusAndSubStatus(Long.valueOf(requestID), userName,
						"Final_DOWN_DONE_POC", Hana_Profiler_Constant.REQ_SS_PROCESSED_FL_DL_SUCC);
			}
		} else if (mainScp && !sia && !bw) {
			if (reqInvObj.getFinalFileDnldSts()) {
				getRequestInventorydao().updatePOCStatusAndSubStatus(Long.valueOf(requestID), userName,
						"Final_DOWN_DONE_POC", Hana_Profiler_Constant.REQ_SS_PROCESSED_FL_DL_SUCC);
			}
		} else if (ext) {
			if (reqInvObj.getFinalFileDnldSts()) {
				getRequestInventorydao().updatePOCStatusAndSubStatus(Long.valueOf(requestID), userName,
						"Final_DOWN_DONE_POC", Hana_Profiler_Constant.REQ_SS_PROCESSED_FL_DL_SUCC);
			}
		}
	}

	private void deleteSubTypeColumnFromSheet(XSSFSheet osMigartionSheet) {
		logger.info("deleteSubTypeColumnFromSheet started :: ");
		for (Row row : osMigartionSheet) {
			// if(StringUtils.isBlank(row.getCell(2).toString()));
			row.removeCell(row.getCell(2));
			// osMigartionSheet.setColumnHidden(3, true);
		}
		logger.info("deleteSubTypeColumnFromSheet Ended :: ");
	}

	private void writeFioriOutputSheet(SXSSFSheet fioriOutputSheet, Long requestId, RequestForm requestForm) {
		List<FioriAppsOutput> fioriOutputList = getOdataFioriProcessDao().getFioriOutputData(requestId);
		int rowIndex = 1;
		if (fioriOutputList != null && !fioriOutputList.isEmpty()) {
			for (FioriAppsOutput fioriAppsOutput : fioriOutputList) {
				Row row = fioriOutputSheet.createRow(rowIndex);

				row.createCell(0).setCellValue(fioriAppsOutput.gettCode());
				row.createCell(1).setCellValue(fioriAppsOutput.getAppId());
				row.createCell(2).setCellValue(fioriAppsOutput.getAppName());
				row.createCell(3).setCellValue(fioriAppsOutput.getAppType());
				row.createCell(4).setCellValue(fioriAppsOutput.getApplicationComponent());
				row.createCell(5).setCellValue(fioriAppsOutput.getApplicationComponentText());
				/*
				 * Cell cell = row.createCell(4);
				 * cell.setCellValue(fioriAppsOutput.getComments());
				 * row.createCell(5) .setCellValue(fioriAppsOutput.getScore() ==
				 * null ? "" : fioriAppsOutput.getScore().toString());
				 */
				rowIndex++;
			}
		}
		logger.info("Sucessfully Wrote Fiori Output Sheet:::%%%%%%%");
	}

	private void writeExtensibilitySheet(SXSSFSheet extensibilitySheet, Long requestId, SXSSFWorkbook workbookTemp) {
		List<ExtensionOutput> extensionOutputList = getExtensibilityDao().getExtensionOutput(requestId);
		int rowNum = 1;

		CellStyle cellStyleComments = workbookTemp.createCellStyle();
		CellStyle cellStyle = workbookTemp.createCellStyle();
		cellStyleComments.setWrapText(true);
		cellStyleComments.setVerticalAlignment(CellStyle.VERTICAL_TOP);
		cellStyle.setVerticalAlignment(CellStyle.VERTICAL_TOP);

		for (ExtensionOutput extensionOutput : extensionOutputList) {

			Row row = extensibilitySheet.createRow(rowNum);
			Cell cell = row.createCell(0);
			cell.setCellValue(extensionOutput.getObj());
			cell.setCellStyle(cellStyle);

			cell = row.createCell(1);
			cell.setCellValue(extensionOutput.getObjName());
			cell.setCellStyle(cellStyle);

			cell = row.createCell(2);
			cell.setCellValue(extensionOutput.getObjectDesc());
			cell.setCellStyle(cellStyle);

			cell = row.createCell(3);
			cell.setCellValue(extensionOutput.getRicefCategory());
			cell.setCellStyle(cellStyle);

			cell = row.createCell(4);
			cell.setCellValue(extensionOutput.getRicefSubCategory());
			cell.setCellStyle(cellStyle);

			cell = row.createCell(5);
			cell.setCellValue(extensionOutput.getRicefCategory2());
			cell.setCellStyle(cellStyle);

			cell = row.createCell(6);
			cell.setCellValue(extensionOutput.getRicefCategory3());
			cell.setCellStyle(cellStyle);

			cell = row.createCell(7);
			cell.setCellValue(extensionOutput.getComplexity());
			cell.setCellStyle(cellStyle);

			cell = row.createCell(8);
			cell.setCellValue(extensionOutput.getExtensibility());
			cell.setCellStyle(cellStyle);

			cell = row.createCell(9);
			cell.setCellValue(extensionOutput.getLooseCoupling());
			cell.setCellStyle(cellStyle);

			cell = row.createCell(10);
			cell.setCellValue(extensionOutput.getUsage());
			cell.setCellStyle(cellStyle);

			cell = row.createCell(11);
			cell.setCellValue(extensionOutput.getUsageCount());
			cell.setCellStyle(cellStyle);

			cell = row.createCell(12);
			cell.setCellValue(extensionOutput.getCloneobj());
			cell.setCellStyle(cellStyle);

			cell = row.createCell(13);
			cell.setCellValue(extensionOutput.getAppArea());
			cell.setCellStyle(cellStyle);

			cell = row.createCell(14);
			cell.setCellValue(extensionOutput.getAppAreaDesc());
			cell.setCellStyle(cellStyle);

			cell = row.createCell(15);
			cell.setCellValue(extensionOutput.getPackageName());

			cell = row.createCell(16);
			cell.setCellValue(extensionOutput.getPackageDesc());
			cell.setCellStyle(cellStyle);

			cell = row.createCell(17);
			cell.setCellValue(extensionOutput.getCommentedLines());
			cell.setCellStyle(cellStyle);

			cell = row.createCell(18);
			cell.setCellValue(extensionOutput.getExeLines());
			cell.setCellStyle(cellStyle);

			cell = row.createCell(19);
			cell.setCellValue(extensionOutput.getComments());
			cell.setCellStyle(cellStyleComments);

			cell = row.createCell(20);
			cell.setCellValue(extensionOutput.getRicefwComments());
			cell.setCellStyle(cellStyleComments);
			rowNum++;

		}
		/*
		 * for (int i = 0; i <= 16; i++) { extensibilitySheet.autoSizeColumn(i);
		 * }
		 */

		logger.info("Sucessfully Wrote Extensibility Sheet:::%%%%%%%");
	}

	private void writeImpactedCloneSheetForExt(SXSSFSheet impactedCloneSheet, Long requestID) {
		int rowIndex = 1;
		List<ImpactedCloneAnalysis> impactedCloneList = new ArrayList<ImpactedCloneAnalysis>();
		impactedCloneList = getExtensibilityDao().getImpactedCloneList(requestID);
		if (null != impactedCloneList && !impactedCloneList.isEmpty()) {
			Iterator<ImpactedCloneAnalysis> impactedScriptsItr = impactedCloneList.iterator();
			while (impactedScriptsItr.hasNext()) {
				ImpactedCloneAnalysis scriptsSheet = impactedScriptsItr.next();
				Row scriptsSheetRow = impactedCloneSheet.createRow(rowIndex);
				scriptsSheetRow.createCell(0).setCellValue(scriptsSheet.getNamespace());
				scriptsSheetRow.createCell(1).setCellValue(scriptsSheet.getObjType());
				scriptsSheetRow.createCell(2).setCellValue(scriptsSheet.getObjName());
				scriptsSheetRow.createCell(3).setCellValue(scriptsSheet.getObjPackage());
				scriptsSheetRow.createCell(4).setCellValue(scriptsSheet.getCreationDate());
				scriptsSheetRow.createCell(5).setCellValue(scriptsSheet.getInterfaceObjType());
				scriptsSheetRow.createCell(6).setCellValue(scriptsSheet.getInterfaceObj());
				scriptsSheetRow.createCell(7).setCellValue(scriptsSheet.getReference());
				scriptsSheetRow.createCell(8).setCellValue(scriptsSheet.getReferencePercent());
				scriptsSheetRow.createCell(9).setCellValue(scriptsSheet.getAppComponent());

				rowIndex++;
			}
		}
		logger.info("Sucessfully Wrote Impacted Clone Analysis Sheet:::%%%%%%%");
	}

	// Writing IRPA TScope Sheet
	private void writeIRPATScopeReportSheet(Long requestId, SXSSFWorkbook workbookTemp) throws Exception {
		XSSFSheet irpaTScopeSheet = workbookTemp.getXSSFWorkbook().getSheet(ST03HanaConstant.IRPA_TSCOPE_SHEET_NAME);
		XSSFSheet irpaTestScriptCountSheet = workbookTemp.getXSSFWorkbook()
				.getSheet(ST03HanaConstant.IRPA_TESTSCRIPT_COUNT_SHEET_NAME);

		// Creating unprotected cell style to allow modification of some columns
		CellStyle unlockedCellStyle = workbookTemp.createCellStyle();
		unlockedCellStyle.setLocked(false);

		// Applying filter on all the fields present in the sheet
		irpaTScopeSheet.setAutoFilter(CellRangeAddress
				.valueOf("A" + ST03HanaConstant.IRPA_ROWS_START + ":Q" + irpaTScopeSheet.getPhysicalNumberOfRows()));
		irpaTScopeSheet.lockAutoFilter(false);

		// Making the Sheet Password Protected
		irpaTScopeSheet.protectSheet(ST03HanaConstant.IRPA_TSCOPEREPORT_PWD);

		// Writing IRPA TScope Request Master Counts
		IRPATScopeRequestMaster irpaTScopeReqMaster = getTestingScopeService().getIRPATScopeRM(requestId);

		Cell addBusinessScenariosToTest = irpaTScopeSheet.getRow(1).getCell(1);
		addBusinessScenariosToTest.setCellFormula("SUM(B3, B4)");
		addBusinessScenariosToTest.setCellType(Cell.CELL_TYPE_FORMULA);

		for (int i = 2; i <= (ST03HanaConstant.IRPA_ROWS_START - 2); i++) {
			Row testingRow = irpaTScopeSheet.getRow(i);
			Cell cell = testingRow.getCell(1);
			cell.getCellStyle().setLocked(false);

			if (irpaTScopeReqMaster != null) {
				setIRPACellVal(i, cell, irpaTScopeReqMaster);
			}
		}

		// Writing IRPA TScope Data
		int rowIndex = ST03HanaConstant.IRPA_ROWS_START;
		List<TestingScopeDownload> irpaTScopeList = getTestingScopeService().getTScopeList(requestId);

		if (CollectionUtils.isNotEmpty(irpaTScopeList)) {
			Iterator<TestingScopeDownload> testingScopeItr = irpaTScopeList.iterator();
			while (testingScopeItr.hasNext()) {
				TestingScopeDownload testingScope = testingScopeItr.next();

				if (rowIndex >= ST03HanaConstant.IRPA_ROWS_START) {
					Row testingRow = irpaTScopeSheet.createRow(rowIndex);

					testingRow.createCell(0).setCellValue(
							testingScope.getModule() == null ? StringUtils.EMPTY : testingScope.getModule());
					testingRow.createCell(1).setCellValue(
							testingScope.getProcess() == null ? StringUtils.EMPTY : testingScope.getProcess());
					testingRow.createCell(2).setCellValue(testingScope.getAppComponent() == null ? StringUtils.EMPTY
							: testingScope.getAppComponent());
					testingRow.createCell(3).setCellValue(
							testingScope.getAppCompDesc() == null ? StringUtils.EMPTY : testingScope.getAppCompDesc());
					testingRow.createCell(4).setCellValue(
							testingScope.getObjectType() == null ? StringUtils.EMPTY : testingScope.getObjectType());
					testingRow.createCell(5).setCellValue(
							testingScope.getObjectName() == null ? StringUtils.EMPTY : testingScope.getObjectName());
					testingRow.createCell(6).setCellValue(
							testingScope.getOperCd() == null ? StringUtils.EMPTY : testingScope.getOperCd());
					testingRow.createCell(7).setCellValue(testingScope.getTransactions() == null ? StringUtils.EMPTY
							: testingScope.getTransactions());
					testingRow.createCell(8).setCellValue(testingScope.getTargetTransactions() == null
							? StringUtils.EMPTY : testingScope.getTargetTransactions());
					testingRow.createCell(9).setCellValue(testingScope.getBusinessScenarioLevel1() == null
							? StringUtils.EMPTY : testingScope.getBusinessScenarioLevel1());
					testingRow.createCell(10).setCellValue(testingScope.getBusinessScenarioLevel2() == null
							? StringUtils.EMPTY : testingScope.getBusinessScenarioLevel2());
					testingRow.createCell(11).setCellValue(testingScope.getBusinessScenarioLevel3() == null
							? StringUtils.EMPTY : testingScope.getBusinessScenarioLevel3());

					Cell isBusScenarioRelCell = testingRow.createCell(12);
					isBusScenarioRelCell.setCellStyle(unlockedCellStyle);
					isBusScenarioRelCell.setCellValue(testingScope.getIsBusinessScenarioRelevant() == null
							? StringUtils.EMPTY : testingScope.getIsBusinessScenarioRelevant());

					Cell testScriptAvail = testingRow.createCell(13);
					testScriptAvail.setCellStyle(unlockedCellStyle);
					testScriptAvail.setCellValue(testingScope.getTestScriptAvailable() == null ? StringUtils.EMPTY
							: testingScope.getTestScriptAvailable());

					// Applying VLookup from Test_Script_Counts sheet
					Cell countTestScriptsPerScenario = testingRow.createCell(14);
					countTestScriptsPerScenario.setCellFormula(
							"VLOOKUP(L" + (rowIndex + 1) + ", " + ST03HanaConstant.IRPA_TESTSCRIPT_COUNT_SHEET_NAME
									+ "!$A$2:$B$" + irpaTestScriptCountSheet.getPhysicalNumberOfRows() + ", 2, FALSE)");
					countTestScriptsPerScenario.setCellType(Cell.CELL_TYPE_FORMULA);

					// Applying if-else - if Test_Script_Available = NO, then
					// Needs_To_Be_Updated/Created = YES
					// else if Test_Script_Available = YES/'',
					// then Needs_To_Be_Updated/Created = value calculated by
					// application
					Cell needsToBeUpdated = testingRow.createCell(15);
					String needToUpdate = testingScope.getNeedsToBeUpdated() == null ? StringUtils.EMPTY
							: testingScope.getNeedsToBeUpdated();
					needsToBeUpdated.setCellFormula("IF(N" + (rowIndex + 1) + "=\"NO\", \"YES\", " + "IF(N"
							+ (rowIndex + 1) + "=\"\", \"" + needToUpdate + "\", IF(N" + (rowIndex + 1) + "=\"YES\", \""
							+ needToUpdate + "\")))");
					needsToBeUpdated.setCellType(Cell.CELL_TYPE_FORMULA);

					testingRow.createCell(16).setCellValue(
							testingScope.getComments() == null ? StringUtils.EMPTY : testingScope.getComments());
				}

				rowIndex++;
			}

			// Applying validations
			validateIRPASheet(irpaTScopeSheet);
		}

		logger.info("Sucessfully Wrote IRPA TScope Sheet ...");
	}

	// Writing Input Sheet for Count of Test Scripts
	private void writeTestScriptCountSheet(long requestId, SXSSFWorkbook workbookTemp) throws Exception {
		XSSFSheet irpaTScopeSheet = workbookTemp.getXSSFWorkbook()
				.getSheet(ST03HanaConstant.IRPA_TESTSCRIPT_COUNT_SHEET_NAME);
		// Fetching and Writing IRPA Distinct Business Scenarios
		int rowIndex = 1;
		List<TestingScopeDownload> irpaScenarioList = getTestingScopeService().getDistinctBusinessScenarios(requestId);

		if (CollectionUtils.isNotEmpty(irpaScenarioList)) {
			Iterator<TestingScopeDownload> testingScopeItr = irpaScenarioList.iterator();

			while (testingScopeItr.hasNext()) {
				Row irpaTscopeRow = irpaTScopeSheet.createRow(rowIndex);

				TestingScopeDownload tscopeObj = testingScopeItr.next();

				irpaTscopeRow.createCell(0).setCellValue(tscopeObj.getBusinessScenarioLevel3());
				irpaTscopeRow.createCell(1).setCellValue(tscopeObj.getCountOfTestScriptsPerScenario());

				rowIndex++;
			}
		}

		logger.info("Sucessfully Wrote IRPA TScope (Test Script Counts) Sheet ...");
	}

	private void setIRPACellVal(int i, Cell cell, IRPATScopeRequestMaster irpaTScopeRMObj) {
		if (i == 2)
			cell.setCellValue(irpaTScopeRMObj.getAddStandardBusinessScenariosToTest());
		else if (i == 3)
			cell.setCellValue(irpaTScopeRMObj.getAddCustomBusinessScenariosToTest());
		else if (i == 4)
			cell.setCellValue(irpaTScopeRMObj.getAddTestScriptsToTest());
		else if (i == 5)
			cell.setCellValue(irpaTScopeRMObj.getNoTestStepsToTest());
	}

	// Applying validations on IRPA sheet
	public void validateIRPASheet(XSSFSheet irpaTScopeSheet) {
		DataValidationHelper dvHelper = irpaTScopeSheet.getDataValidationHelper();

		// Applying numeric validation
		DataValidationConstraint dvConstraint1 = dvHelper.createNumericConstraint(DVConstraint.ValidationType.INTEGER,
				DVConstraint.OperatorType.BETWEEN, "0", String.valueOf(Integer.MAX_VALUE));

		CellRangeAddressList addressList1 = new CellRangeAddressList(1, ST03HanaConstant.IRPA_ROWS_START - 2, 1, 1);
		DataValidation validation1 = dvHelper.createValidation(dvConstraint1, addressList1);

		if (validation1 instanceof XSSFDataValidation)
			validation1.setShowErrorBox(true);

		// Applying validation on drop-down list
		DataValidationConstraint dvConstraint2 = dvHelper.createExplicitListConstraint(new String[] { "YES", "NO" });

		CellRangeAddressList addressList2 = new CellRangeAddressList(ST03HanaConstant.IRPA_ROWS_START,
				irpaTScopeSheet.getLastRowNum(), 12, 13);
		DataValidation validation2 = dvHelper.createValidation(dvConstraint2, addressList2);
		if (validation2 instanceof XSSFDataValidation) {
			validation2.setSuppressDropDownArrow(true);
			validation2.setShowErrorBox(true);
		}

		irpaTScopeSheet.addValidationData(validation1);
		irpaTScopeSheet.addValidationData(validation2);
	}

	// Writing IRPA Estimates Report - Inventory Sheet
	private void writeIRPAInventorySheet(long requestId, SXSSFWorkbook workbookTemp, IRPATScopeEstimates estimatesObj)
			throws Exception {
		try {
			XSSFSheet sheet = workbookTemp.getXSSFWorkbook().getSheet(ST03HanaConstant.IRPA_INVENTORY_SHEET);

			sheet.getRow(2).getCell(3).setCellValue(estimatesObj.getTestScriptsForEstimationsCount());
			sheet.getRow(7).getCell(2).setCellValue(estimatesObj.getTotalTestScriptsCount());

			sheet.getRow(9).getCell(1).setCellValue((float) estimatesObj.getManualScriptCreationCount() / 100);
			sheet.getRow(10).getCell(1).setCellValue((float) estimatesObj.getManualScriptModificationCount() / 100);
			sheet.getRow(11).getCell(1).setCellValue((float) estimatesObj.getScriptsForSmokeTest() / 100);
			sheet.getRow(12).getCell(1).setCellValue((float) estimatesObj.getScriptsForUnitTest() / 100);
			sheet.getRow(13).getCell(1).setCellValue((float) estimatesObj.getScriptsForSITOne() / 100);
			sheet.getRow(14).getCell(1).setCellValue((float) estimatesObj.getScriptsForSITTwo() / 100);
			sheet.getRow(15).getCell(1).setCellValue((float) estimatesObj.getScriptsForUAT() / 100);
			sheet.getRow(16).getCell(1).setCellValue((float) estimatesObj.getScriptsForRegressionTest() / 100);
		} catch (Exception e) {
			logger.error("Error while writing data in Estimation Sheet of IRPA Estimates Report : ", e);
			throw new Exception();
		}
	}

	// Writing IRPA Estimates Report - Estimation Sheet
	private void writeIRPAEstimationSheet(long requestId, SXSSFWorkbook workbookTemp, IRPATScopeEstimates estimatesObj)
			throws Exception {
		try {
			XSSFSheet sheet = workbookTemp.getXSSFWorkbook().getSheet(ST03HanaConstant.IRPA_ESTIMATIONS_SHEET);

			sheet.getRow(1).getCell(5).setCellValue((float) estimatesObj.getSimpleCompForTestScriptCount() / 100);
			sheet.getRow(1).getCell(6).setCellValue((float) estimatesObj.getMediumCompForTestScriptCount() / 100);
			sheet.getRow(1).getCell(7).setCellValue((float) estimatesObj.getComplexCompForTestScriptCount() / 100);
		} catch (Exception e) {
			logger.error("Error while writing data in Estimation Sheet of IRPA Estimates Report : ", e);
			throw new Exception();
		}
	}

	private void writeBwSTandardExtractSheet(SXSSFSheet bwStdExtrSheet, Long requestID) {
		int rowIndex = 1;

		List<BwStandardExtractDownload> bwStdExtrList = getDaoIntf().getBwStdExtrctList(requestID);

		if (null != bwStdExtrList && !bwStdExtrList.isEmpty()) {
			Iterator<BwStandardExtractDownload> bwStdExtrItr = bwStdExtrList.iterator();
			while (bwStdExtrItr.hasNext()) {
				BwStandardExtractDownload bwStdExtr = bwStdExtrItr.next();
				Row bwStdExtrRow = bwStdExtrSheet.createRow(rowIndex);
				bwStdExtrRow.createCell(0).setCellValue(bwStdExtr.getObjName());
				bwStdExtrRow.createCell(1).setCellValue(bwStdExtr.getPhase());
				bwStdExtrRow.createCell(2).setCellValue(bwStdExtr.getAreaResponsibility());
				bwStdExtrRow.createCell(3).setCellValue(bwStdExtr.getDataSrc());
				bwStdExtrRow.createCell(4).setCellValue(bwStdExtr.getAppComp());
				bwStdExtrRow.createCell(5).setCellValue(bwStdExtr.getClassification());
				bwStdExtrRow.createCell(6).setCellValue(bwStdExtr.getCategory());
				bwStdExtrRow.createCell(7).setCellValue(bwStdExtr.getRestrictions());
				bwStdExtrRow.createCell(8).setCellValue(bwStdExtr.getRelSimpliItem());
				bwStdExtrRow.createCell(9).setCellValue(bwStdExtr.getNote());
				bwStdExtrRow.createCell(10).setCellValue(bwStdExtr.getDel1511());
				bwStdExtrRow.createCell(11).setCellValue(bwStdExtr.getDel1610());
				bwStdExtrRow.createCell(12).setCellValue(bwStdExtr.getDelRestrict());
				bwStdExtrRow.createCell(13).setCellValue(bwStdExtr.getComments());

				rowIndex++;
			}
		}

		logger.info("Sucessfully Wrote Bw Standard Extract Sheet:::%%%%%%%");
	}

	private void writeInactiveObjectsSheet(SXSSFSheet inactiveObjectsSheet, Long requestID) {
		int rowIndex = 1;

		List<InactiveObjectsDownload> inaObjList = getDaoIntf().getInactiveObjectsList(requestID);
		if (null != inaObjList && !inaObjList.isEmpty()) {
			Iterator<InactiveObjectsDownload> inaObjItr = inaObjList.iterator();
			while (inaObjItr.hasNext()) {
				InactiveObjectsDownload inaObj = inaObjItr.next();
				Row inaObjRow = inactiveObjectsSheet.createRow(rowIndex);
				inaObjRow.createCell(0).setCellValue(inaObj.getObject());
				inaObjRow.createCell(1).setCellValue(inaObj.getObjName());
				inaObjRow.createCell(2).setCellValue(inaObj.getUname());
				inaObjRow.createCell(3).setCellValue(inaObj.getDeleteFlag());
				inaObjRow.createCell(4).setCellValue(inaObj.getTabCls());
				rowIndex++;
			}
		}

		logger.info("Sucessfully Wrote Inactive Objects Sheet:::%%%%%%%");
	}

	private void writeDrillDownReport(SXSSFSheet drilldownSheet, Long requestID) {
		List<DrillDown_Download> drillDownReportList = getS4DaoIntf().getDrillDownReportList(requestID);

		int rowIndex = 1;

		if (CollectionUtils.isNotEmpty(drillDownReportList)) {
			Iterator<DrillDown_Download> itr = drillDownReportList.iterator();

			while (itr.hasNext()) {
				DrillDown_Download obj = itr.next();

				Row detailReportRow = drilldownSheet.createRow(rowIndex);

				detailReportRow.createCell(0).setCellValue(obj.getType());
				detailReportRow.createCell(1).setCellValue(obj.getObjName());
				detailReportRow.createCell(2).setCellValue(obj.getMethod());
				detailReportRow.createCell(3).setCellValue(obj.getReadProgram());
				detailReportRow.createCell(4).setCellValue(obj.getPckg());
				detailReportRow.createCell(5).setCellValue(obj.getOperations());
				detailReportRow.createCell(6).setCellValue(obj.getLineNo());
				detailReportRow.createCell(7).setCellValue(obj.getStmt());
				detailReportRow.createCell(8).setCellValue(obj.getImpactedObjType());
				detailReportRow.createCell(9).setCellValue(obj.getImpactReason());
				detailReportRow.createCell(10).setCellValue(obj.getDescOfChange());
				detailReportRow.createCell(11).setCellValue(obj.getSapNotes());
				detailReportRow.createCell(12).setCellValue(obj.getSolutionSteps());
				detailReportRow.createCell(13).setCellValue(obj.getComplexity());
				detailReportRow.createCell(14).setCellValue(obj.getImpact());
				detailReportRow.createCell(15).setCellValue(obj.getIssueCategory());
				detailReportRow.createCell(16).setCellValue(obj.getErrorCategory());
				detailReportRow.createCell(17).setCellValue(obj.getTriggerObj());
				detailReportRow.createCell(18).setCellValue(obj.getRemediationCategory());
				detailReportRow.createCell(19).setCellValue(obj.getSapSimpListChapter());
				detailReportRow.createCell(20).setCellValue(obj.getApplicationComponent());
				detailReportRow.createCell(21).setCellValue(obj.getSapSimplCategry());
				detailReportRow.createCell(22).setCellValue(obj.getItemArea());
				detailReportRow.createCell(23).setCellValue(obj.getSelectLine());
				detailReportRow.createCell(24).setCellValue(obj.getUsed());
				detailReportRow.createCell(25).setCellValue(obj.getCorProgName());
				detailReportRow.createCell(26).setCellValue(obj.getCorLineNo());
				detailReportRow.createCell(27).setCellValue(obj.getRicefCategory());
				detailReportRow.createCell(28).setCellValue(obj.getToolVersion());

				++rowIndex;
			}
		}

		logger.info("Sucessfully Wrote DrillDown Report Tab ...");
	}

	private void writeObsoleteFmsUpgradeReport(SXSSFSheet ObsoleteSheet, Long requestID) {
		List<ObsoleteFmsDueToUpgrade> obsoleteFmsList = getS4DaoIntf().getObsoleteFmsUpgradeReportList(requestID);

		int rowIndex = 1;

		if (CollectionUtils.isNotEmpty(obsoleteFmsList)) {
			Iterator<ObsoleteFmsDueToUpgrade> itr = obsoleteFmsList.iterator();

			while (itr.hasNext()) {
				ObsoleteFmsDueToUpgrade obj = itr.next();

				Row detailReportRow = ObsoleteSheet.createRow(rowIndex);

				detailReportRow.createCell(0).setCellValue(obj.getRicefCategory());
				detailReportRow.createCell(1).setCellValue(obj.getRicefSubCategory());
				detailReportRow.createCell(2).setCellValue(obj.getType());
				detailReportRow.createCell(3).setCellValue(obj.getObjName());
				detailReportRow.createCell(4).setCellValue(obj.getMethod());
				detailReportRow.createCell(5).setCellValue(obj.getReadProgram());
				detailReportRow.createCell(6).setCellValue(obj.getPckg());
				detailReportRow.createCell(7).setCellValue(obj.getOperations());
				detailReportRow.createCell(8).setCellValue(obj.getLineNo());
				detailReportRow.createCell(9).setCellValue(obj.getStmt());
				detailReportRow.createCell(10).setCellValue(obj.getImpactedObjType());
				detailReportRow.createCell(11).setCellValue(obj.getImpactReason());
				detailReportRow.createCell(12).setCellValue(obj.getDescOfChange());
				detailReportRow.createCell(13).setCellValue(obj.getSapNotes());
				detailReportRow.createCell(14).setCellValue(obj.getSolutionSteps());
				detailReportRow.createCell(15).setCellValue(obj.getComplexity());
				detailReportRow.createCell(16).setCellValue(obj.getImpact());
				detailReportRow.createCell(17).setCellValue(obj.getIssueCategory());
				detailReportRow.createCell(18).setCellValue(obj.getErrorCategory());
				detailReportRow.createCell(19).setCellValue(obj.getTriggerObj());
				detailReportRow.createCell(20).setCellValue(obj.getRemediationCategory());
				detailReportRow.createCell(21).setCellValue(obj.getSapSimpListChapter());
				detailReportRow.createCell(22).setCellValue(obj.getApplicationComponent());
				detailReportRow.createCell(23).setCellValue(obj.getSapSimplCategry());
				detailReportRow.createCell(24).setCellValue(obj.getItemArea());
				detailReportRow.createCell(25).setCellValue(obj.getSelectLine());
				detailReportRow.createCell(26).setCellValue(obj.getUsed());
				detailReportRow.createCell(27).setCellValue(obj.getExtNamespace());

				++rowIndex;
			}
		}

		logger.info("Sucessfully Wrote Obsolete Fms Upgrade Tab ...");
	}

	// Writing cvit customising logs sheet
	private void writeCvitCustomLogs(SXSSFSheet cvitCustomLogsSheet, long requestId,
			List<CvitCustomisingLogsDownload> cvitCustomLogsList) {
		int rowIndex = 1;
		Iterator<CvitCustomisingLogsDownload> customLogsItr = cvitCustomLogsList.iterator();

		while (customLogsItr.hasNext()) {
			CvitCustomisingLogsDownload customLogsObj = customLogsItr.next();

			Row row = cvitCustomLogsSheet.createRow(rowIndex);
			row.createCell(0).setCellValue(customLogsObj.getObjectName());
			row.createCell(1).setCellValue(customLogsObj.getCustomisingErrors());
			row.createCell(2).setCellValue(customLogsObj.getText());
			row.createCell(3).setCellValue(
					customLogsObj.getCustomerCount() == 0 ? "" : String.valueOf(customLogsObj.getCustomerCount()));
			row.createCell(4).setCellValue(
					customLogsObj.getVendorCount() == 0 ? "" : String.valueOf(customLogsObj.getVendorCount()));
			row.createCell(5).setCellValue(customLogsObj.getCustomerLogs());
			row.createCell(6).setCellValue(customLogsObj.getVendorLogs());

			rowIndex++;
		}

		logger.info("Sucessfully wrote cvit csutom logs sheet !!!");
	}

	// Writing cvit customising logs sheet
	private void writeCvitErrorMessages(SXSSFSheet cvitErrorMsgsSheet, long requestId,
			List<CvitErrorMessagesDownload> cvitErrorMsgsList) {
		int rowIndex = 1;
		Iterator<CvitErrorMessagesDownload> errorMsgsItr = cvitErrorMsgsList.iterator();

		while (errorMsgsItr.hasNext()) {
			CvitErrorMessagesDownload errorMsgObj = errorMsgsItr.next();

			Row row = cvitErrorMsgsSheet.createRow(rowIndex);
			row.createCell(0).setCellValue(errorMsgObj.getRunId());
			row.createCell(1).setCellValue(errorMsgObj.getIndicator());
			row.createCell(2).setCellValue(errorMsgObj.getCustomerVendor());
			row.createCell(3).setCellValue(errorMsgObj.getFieldName());
			row.createCell(4).setCellValue(errorMsgObj.getErrorLog());

			rowIndex++;
		}

		logger.info("Sucessfully wrote cvit error messages sheet !!!");
	}
}
