package com.act.aadtPoc;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.act.Aadt.models.ImpactedObjList;
import com.act.S4.dao.DisplayGraphS4DAO;
import com.act.S4.models.S4AffectCustomField;
import com.act.S4.models.S4DetailReportComplexity;
import com.act.S4.models.S4DetailReportRemediation;
import com.act.S4.models.S4HanaProfiler;
import com.act.S4.models.S4InventoryList;
import com.act.S4.models.S4OutputMgmt;
import com.act.controller.AbstractBaseController;
import com.act.displaygrid.model.HanaProfile;
import com.act.master.ProcessedRequestDetail;
import com.monitorjbl.xlsx.StreamingReader;

public class ReadtheExcel {
	
	final Logger logger=LoggerFactory.getLogger(ReadtheExcel.class);
	
	String uploadPath;
	String inventoryListObjecttype = null;
	String inventoryListObjectname = null;
	String inventoryListUsed = null;
	S4InventoryList forwardInvList = null;
	List<S4InventoryList> daoinsertinventoryList = new ArrayList<S4InventoryList>();
	ImpactedObjList forwardimpactedObjectList = null;
	List<ImpactedObjList> impactedObjectList = new ArrayList<ImpactedObjList>();
	HanaProfile forwarddrdbchangeList = null;
	List<HanaProfile> drdbchangeList = new ArrayList<HanaProfile>();
	S4HanaProfiler forwarddrs4SimplificationOneList = null;
	List<S4HanaProfiler> drs4SimplificationOneList = new ArrayList<S4HanaProfiler>();
	S4OutputMgmt forwardoutputManagementList = null;
	List<S4OutputMgmt> outputManagementList = null;
	S4AffectCustomField forwardaffectedbyCustomFieldsList = null;
	List<S4AffectCustomField> affectedbyCustomFieldsList = new ArrayList<S4AffectCustomField>();
	S4DetailReportComplexity forwarddrs4SimplificationTwoList = null;
	List<S4DetailReportComplexity> drs4SimplificationTwoList = new ArrayList<S4DetailReportComplexity>();
	S4DetailReportRemediation forwarddrs4SimplificationThreeList = null;
	List<S4DetailReportRemediation> drs4SimplificationThreeList = new ArrayList<S4DetailReportRemediation>();
	RequestMasterCalculatorDao excelSheetList =  new RequestMasterCalculatorDaoImpl();
	DisplayGraphS4DAO graphS4DAO;
	HttpServletRequest request;
	
	public void uploadedFile(String directoryfilename) {
		uploadPath = directoryfilename;
		logger.info("THE directoryfilename FILE IS"+uploadPath);
	}
	
	
	
	public void excelinventoryList(long requestId,HttpSession session) throws Exception {
		
		File file = new File(uploadPath); 
		
		InputStream inputStream = new FileInputStream(file);
		int rowCount = 0;
		@SuppressWarnings("deprecation")
		StreamingReader inventoryListreader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(0)
				.read(inputStream);
		for (Row r : inventoryListreader) {
			
			if (r.getRowNum() > 0) {
				rowCount = rowCount + 1;
				forwardInvList = new S4InventoryList();
				inventoryListObjecttype = r.getCell(0) == null ? "" : r.getCell(0).getStringCellValue();
				inventoryListObjectname = r.getCell(1) == null ? "" : r.getCell(1).getStringCellValue();
				inventoryListUsed = r.getCell(2) == null ? "" : r.getCell(2).getStringCellValue();
		    	forwardInvList.setObjName(inventoryListObjectname);
				forwardInvList.setObjType(inventoryListObjecttype);
				forwardInvList.setUsage(inventoryListUsed.trim());	
				daoinsertinventoryList.add(forwardInvList);
						
	}
		
		}
		excelSheetList.insertS4InventoryList(daoinsertinventoryList, session, requestId);
		}
	
	public void impactedObjectList(long requestId,HttpSession session) throws FileNotFoundException, SQLException {
		
		File file = new File(uploadPath);
		
		InputStream inputStream = new FileInputStream(file);
		int rowCount = 0;
		@SuppressWarnings("deprecation")
		StreamingReader impactedObjectListreader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(1)
				.read(inputStream);
		for (Row r : impactedObjectListreader) {
			
			if (r.getRowNum() > 0) {
				rowCount = rowCount + 1;
				forwardimpactedObjectList = new ImpactedObjList();	
				String impactedObjectListObjecttype = r.getCell(0) == null ? "" : r.getCell(0).getStringCellValue();
				String impactedObjectListObjectname = r.getCell(1) == null ? "" : r.getCell(1).getStringCellValue();
				String impactedObjectListUsed =  r.getCell(2) == null ? "" : r.getCell(2).getStringCellValue();
				//String impactedObjectListDialogSteps =  r.getCell(3) == null ? "" : r.getCell(3).getStringCellValue();
				String impactedObjectListErrorsinexistingsystem = r.getCell(3) == null ? "" : r.getCell(4).getStringCellValue();
				String impactedObjectListDBImpact = r.getCell(4) == null ? "" : r.getCell(5).getStringCellValue();
				String impactedObjectListS4Simplification = r.getCell(5) == null ? "" : r.getCell(6).getStringCellValue();
			    String impactedObjectListOdata = r.getCell(6) == null ? "" : r.getCell(7).getStringCellValue();
		
			    forwardimpactedObjectList.setOBJ_TYPE(impactedObjectListObjecttype.trim());
			    forwardimpactedObjectList.setOBJ_NAME(impactedObjectListObjectname.trim());
			    forwardimpactedObjectList.setUsed(impactedObjectListUsed.toUpperCase().trim());
			    //forwardimpactedObjectList.setDIALOG_STEPS(impactedObjectListDialogSteps.trim());
			    forwardimpactedObjectList.setErrors_In_Existing_System(impactedObjectListErrorsinexistingsystem.trim());
			    forwardimpactedObjectList.setDB_Impact(impactedObjectListDBImpact.trim());
			    forwardimpactedObjectList.setS4_Simplification(impactedObjectListS4Simplification.trim());
			    forwardimpactedObjectList.setOdata(impactedObjectListOdata.trim());
			    impactedObjectList.add(forwardimpactedObjectList);
			 	}				
		    	}
		   excelSheetList.insertimpactedObjectList(impactedObjectList, session, requestId);
	    	}
	
	public void drdbChangeList(long requestId,HttpSession session) throws FileNotFoundException, SQLException {
		
		File file = new File(uploadPath);
		
		InputStream inputStream = new FileInputStream(file);
		int rowCount = 0;
		@SuppressWarnings("deprecation")
		StreamingReader drdbchangeListreader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(2)
				.read(inputStream);
		for (Row r : drdbchangeListreader) {
			
			if (r.getRowNum() > 0) {
				rowCount = rowCount + 1;
				forwarddrdbchangeList = new HanaProfile();
				String drdbchangeListObjecttype = r.getCell(0) == null ? "" : r.getCell(0).getStringCellValue();
				String drdbchangeListObjectname = r.getCell(1) == null ? "" : r.getCell(1).getStringCellValue();
				String drdbchangeListSubobjName =  r.getCell(2) == null ? "" : r.getCell(2).getStringCellValue();
				String drdbchangeListReadProgram =  r.getCell(3) == null ? "" : r.getCell(3).getStringCellValue();
				String drdbchangeListPackage = r.getCell(4) == null ? "" : r.getCell(4).getStringCellValue();
				String drdbchangeListOperation = r.getCell(5) == null ? "" : r.getCell(5).getStringCellValue();
				int drdbchangeListLineNo = Integer.parseInt(r.getCell(6).getStringCellValue());
			    String drdbchangeListStatement = r.getCell(7) == null ? "" : r.getCell(7).getStringCellValue();
				String drdbchangeListRefLineNo = r.getCell(8) == null ? "" : r.getCell(8).getStringCellValue();
				String drdbchangeListRemediationCategory = r.getCell(9) == null ? "" : r.getCell(9).getStringCellValue();
				String drdbchangeListIssueCategory  = r.getCell(10) == null ? "" : r.getCell(10).getStringCellValue();
				String drdbchangeListIssueSubCategory = r.getCell(11) == null ? "" : r.getCell(11).getStringCellValue();
				String drdbchangeListDescriptionofChange = r.getCell(12) == null ? "" : r.getCell(12).getStringCellValue();
				String drdbchangeListSolutionSteps =  r.getCell(13) == null ? "" : r.getCell(13).getStringCellValue();
				String drdbchangeListLevelOfNesting = r.getCell(14) == null ? "" : r.getCell(14).getStringCellValue();
				String drdbchangeListTables = r.getCell(15) == null ? "" : r.getCell(15).getStringCellValue();
				String drdbchangeListJoins = r.getCell(16) == null ? "" : r.getCell(16).getStringCellValue();
				String drdbchangeListTableType = r.getCell(17) == null ? "" : r.getCell(17).getStringCellValue();
				String drdbchangeListWhereCondition = r.getCell(18) == null ? "" : r.getCell(18).getStringCellValue();
				String drdbchangeListJoinType  = r.getCell(19) == null ? "" : r.getCell(19).getStringCellValue();
				String drdbchangeListImpact = r.getCell(20) == null ? "" : r.getCell(20).getStringCellValue();
				String drdbchangeListAutomationStatus = r.getCell(21) == null ? "" : r.getCell(21).getStringCellValue();
				String drdbchangeListComplexity = r.getCell(22) == null ? "" : r.getCell(22).getStringCellValue();
				String drdbchangeListOperationCode  = r.getCell(23) == null ? "" : r.getCell(23).getStringCellValue();
				String drdbchangeListUsed =  r.getCell(24) == null ? "" : r.getCell(24).getStringCellValue();
				String drdbchangeListSkipReason =  r.getCell(25) == null ? "" : r.getCell(25).getStringCellValue();
				String drdbchangeListSkip =  r.getCell(26) == null ? "" : r.getCell(26).getStringCellValue();
				
				forwarddrdbchangeList.setObject_Type(drdbchangeListObjecttype.trim());
				forwarddrdbchangeList.setObj_Name(drdbchangeListObjectname.trim());
				forwarddrdbchangeList.setSub_Type(drdbchangeListSubobjName.trim());
				forwarddrdbchangeList.setReadProgram(drdbchangeListReadProgram.trim());
				forwarddrdbchangeList.setOBJ_PACKAGE(drdbchangeListPackage.trim());
				forwarddrdbchangeList.setOpertaion(drdbchangeListOperation.trim());
				forwarddrdbchangeList.setLine_Number(drdbchangeListLineNo);
				forwarddrdbchangeList.setCode(drdbchangeListStatement.trim());
				forwarddrdbchangeList.setSel_Line(drdbchangeListRefLineNo);
				forwarddrdbchangeList.setCategory(drdbchangeListRemediationCategory.trim());
				forwarddrdbchangeList.setSubcategory(drdbchangeListIssueCategory.trim());
				forwarddrdbchangeList.setIssueSecondSubCat(drdbchangeListIssueSubCategory.trim());
				forwarddrdbchangeList.setInfo(drdbchangeListDescriptionofChange.trim());
				forwarddrdbchangeList.setHigh_lvl_desc(drdbchangeListSolutionSteps.trim());
				forwarddrdbchangeList.setLevels(Integer.parseInt(drdbchangeListLevelOfNesting));
				forwarddrdbchangeList.setTables(drdbchangeListTables.trim());
				forwarddrdbchangeList.setJoins(drdbchangeListJoins.trim());
				forwarddrdbchangeList.setTable_Type(drdbchangeListTableType.trim());
				forwarddrdbchangeList.setWhere_Condition(drdbchangeListWhereCondition.trim());
				forwarddrdbchangeList.setJoin_Type(drdbchangeListJoinType.trim());
				forwarddrdbchangeList.setImpact(drdbchangeListImpact.trim());
				forwarddrdbchangeList.setAutomation_status(drdbchangeListAutomationStatus.trim());
				forwarddrdbchangeList.setCOMPLEXITY(drdbchangeListComplexity.trim());
				forwarddrdbchangeList.setOperation_code(drdbchangeListOperationCode);
				forwarddrdbchangeList.setUsed_Unused(drdbchangeListUsed.trim());
				forwarddrdbchangeList.setSkipReason(drdbchangeListSkipReason);
				forwarddrdbchangeList.setSkip(drdbchangeListSkip);
				drdbchangeList.add(forwarddrdbchangeList);				
					
			}
			
		}
		excelSheetList.insertdrdbchangeList(drdbchangeList, session, requestId);
	}
	
public void drs4SimplificationOneList(long requestId,HttpSession session) throws FileNotFoundException, SQLException {
		
	File file = new File(uploadPath);
		
		InputStream inputStream = new FileInputStream(file);
		int rowCount = 0;
		@SuppressWarnings("deprecation")
		StreamingReader drs4SimplificationOneListreader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(3)
				.read(inputStream);
		for (Row r : drs4SimplificationOneListreader) {
			
			if (r.getRowNum() > 0) {
				rowCount = rowCount + 1;
				forwarddrs4SimplificationOneList = new S4HanaProfiler();				
				forwarddrs4SimplificationOneList.setType(r.getCell(0) == null ? "" : r.getCell(0).getStringCellValue().trim());
				forwarddrs4SimplificationOneList.setObjName(r.getCell(1) == null ? "" : r.getCell(1).getStringCellValue().trim());
				forwarddrs4SimplificationOneList.setMethod(r.getCell(2) == null ? "" : r.getCell(2).getStringCellValue().trim());
				forwarddrs4SimplificationOneList.setREAD_PROG(r.getCell(3) == null ? "" : r.getCell(3).getStringCellValue().trim());
				forwarddrs4SimplificationOneList.setPckg(r.getCell(4) == null ? "" : r.getCell(4).getStringCellValue().trim());
				forwarddrs4SimplificationOneList.setOperations(r.getCell(5) == null ? "" : r.getCell(5).getStringCellValue().trim());
				forwarddrs4SimplificationOneList.setLineNo(Integer.parseInt(r.getCell(6) == null ? "" : r.getCell(6).getStringCellValue().trim()));
				forwarddrs4SimplificationOneList.setStmt(r.getCell(7) == null ? "" : r.getCell(7).getStringCellValue().trim());
				forwarddrs4SimplificationOneList.setSELECT_LINE(r.getCell(8) == null ? "" : r.getCell(8).getStringCellValue().trim());		
				forwarddrs4SimplificationOneList.setImpactedObjType(r.getCell(9) == null ? "" : r.getCell(9).getStringCellValue().trim());
				forwarddrs4SimplificationOneList.setImpactReason(r.getCell(10) == null ? "" : r.getCell(10).getStringCellValue().trim());
				forwarddrs4SimplificationOneList.setDescOfChange(r.getCell(11) == null ? "" : r.getCell(11).getStringCellValue().trim());
				forwarddrs4SimplificationOneList.setSapNotes(r.getCell(12) == null ? "" : r.getCell(12).getStringCellValue().trim());
				forwarddrs4SimplificationOneList.setSolutionSteps(r.getCell(13) == null ? "" : r.getCell(13).getStringCellValue().trim());
				forwarddrs4SimplificationOneList.setComplexity(r.getCell(14) == null ? "" : r.getCell(14).getStringCellValue().trim());
				forwarddrs4SimplificationOneList.setImpact(r.getCell(15) == null ? "" : r.getCell(15).getStringCellValue().trim());
				forwarddrs4SimplificationOneList.setIssueCategory(r.getCell(16) == null ? "" : r.getCell(16).getStringCellValue().trim());
				forwarddrs4SimplificationOneList.setErrorCategory(r.getCell(17) == null ? "" : r.getCell(17).getStringCellValue().trim());
				forwarddrs4SimplificationOneList.setTriggerObj(r.getCell(18) == null ? "" : r.getCell(18).getStringCellValue().trim());
				forwarddrs4SimplificationOneList.setTrigger_Object(r.getCell(19) == null ? "" : r.getCell(19).getStringCellValue().trim());
				forwarddrs4SimplificationOneList.setRemediationCategory(r.getCell(20) == null ? "" : r.getCell(20).getStringCellValue().trim());
				forwarddrs4SimplificationOneList.setSapSimpListChapter(r.getCell(21) == null ? "" : r.getCell(21).getStringCellValue().trim());
				forwarddrs4SimplificationOneList.setApplicationComponent(r.getCell(22) == null ? "" : r.getCell(22).getStringCellValue().trim());
				forwarddrs4SimplificationOneList.setSapSimplCategry(r.getCell(23) == null ? "" : r.getCell(23).getStringCellValue().trim());
				forwarddrs4SimplificationOneList.setItemArea(r.getCell(24) == null ? "" : r.getCell(24).getStringCellValue().trim());
				forwarddrs4SimplificationOneList.setUsed(r.getCell(25) == null ? "" : r.getCell(25).getStringCellValue().trim());
				drs4SimplificationOneList.add(forwarddrs4SimplificationOneList);
			}
			}
		excelSheetList.insertdrs4SimplificationOneList(drs4SimplificationOneList, session, requestId);
		}

public void outputManagementList(long requestId,HttpSession session) throws SQLException, IOException {
	File file = new File(uploadPath);
	outputManagementList = new ArrayList<S4OutputMgmt>(); 

	InputStream inputStream = new FileInputStream(file);
      
           Workbook wb = new XSSFWorkbook(inputStream);
           Sheet sh = wb.getSheetAt(6);
           Row r;
           Integer startFrom = 7; // start from 3rd row change as needed
           for(int i=startFrom ; i<=sh.getLastRowNum(); i++){
        		forwardoutputManagementList = new S4OutputMgmt();
               r = sh.getRow(i);
               String type =  r.getCell(0) == null ? "" : r.getCell(0).getStringCellValue().trim();
               String objName = r.getCell(1) == null ? "" : r.getCell(1).getStringCellValue().trim();
            forwardoutputManagementList.setType(type);
			forwardoutputManagementList.setObjName(objName);
			outputManagementList.add(forwardoutputManagementList);
			
           }
           excelSheetList.insertoutputManagementList(outputManagementList, session, requestId);
          
wb.close();
}

public void affectedbyCustomFieldsList(long requestId,HttpSession session) throws SQLException, IOException {
	File file = new File(uploadPath);
	 
	
	InputStream inputStream = new FileInputStream(file);
	  Workbook wb = new XSSFWorkbook(inputStream);
      Sheet sh = wb.getSheetAt(7);
      Row r;
      Integer startFrom = 8; // start from 5th row change as needed
      for(int i= startFrom ; i<=sh.getLastRowNum(); i++){
          r = sh.getRow(i);
        forwardaffectedbyCustomFieldsList = new S4AffectCustomField();        
        forwardaffectedbyCustomFieldsList.setType(r.getCell(0) == null ? "" : r.getCell(0).getStringCellValue().trim());
		forwardaffectedbyCustomFieldsList.setObjName(r.getCell(1) == null ? "" : r.getCell(1).getStringCellValue().trim());
		forwardaffectedbyCustomFieldsList.setTriggerObj(r.getCell(2) == null ? "" : r.getCell(2).getStringCellValue().trim());
		affectedbyCustomFieldsList.add(forwardaffectedbyCustomFieldsList);
		
      }
      excelSheetList.insertaffectedbyCustomFieldsList(affectedbyCustomFieldsList, session, requestId);
 	wb.close();
}

public void drs4SimplificationTwoList(long requestId,HttpSession session) throws SQLException, IOException {
	File file = new File(uploadPath);
	InputStream inputStream = new FileInputStream(file);
int rowCount = 0;
@SuppressWarnings("deprecation")
StreamingReader drs4SimplificationTwoListreader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(15)
		.read(inputStream);
for (Row r : drs4SimplificationTwoListreader) {
	
	if (r.getRowNum() > 0) {
		rowCount = rowCount + 1;
		forwarddrs4SimplificationTwoList = new S4DetailReportComplexity();
    	forwarddrs4SimplificationTwoList.setType(r.getCell(0) == null ? "" : r.getCell(0).getStringCellValue().trim());
		forwarddrs4SimplificationTwoList.setObjName(r.getCell(1) == null ? "" : r.getCell(1).getStringCellValue().trim());
		forwarddrs4SimplificationTwoList.setUsed(r.getCell(2) == null ? "" : r.getCell(2).getStringCellValue().trim());
		forwarddrs4SimplificationTwoList.setSubObject(r.getCell(3) == null ? "" : r.getCell(3).getStringCellValue().trim());
		forwarddrs4SimplificationTwoList.setMethod(r.getCell(4) == null ? "" : r.getCell(4).getStringCellValue().trim());
		forwarddrs4SimplificationTwoList.setPckg(r.getCell(5) == null ? "" : r.getCell(5).getStringCellValue().trim());
		forwarddrs4SimplificationTwoList.setImpactedObjType(r.getCell(6) == null ? "" : r.getCell(6).getStringCellValue().trim());
		Cell seven = (r.getCell(7));
		if(seven==null) {
			inputStream.close();
			break;
		}
		String lineNo = (r.getCell(7).getStringCellValue().trim());
		if((lineNo.length()>0)&&(lineNo.length()!=0)) {
			forwarddrs4SimplificationTwoList.setLineNo(Integer.parseInt(lineNo));
		}
		
		if((lineNo.length()==0)||(lineNo.equals(""))||(lineNo.equals(null))) {
			inputStream.close();
			break;
		}
		    forwarddrs4SimplificationTwoList.setStmt(r.getCell(8) == null ? "" : r.getCell(8).getStringCellValue().trim());		
			forwarddrs4SimplificationTwoList.setOperations(r.getCell(9) == null ? "" : r.getCell(9).getStringCellValue().trim());
			forwarddrs4SimplificationTwoList.setImpactReason(r.getCell(10) == null ? "" : r.getCell(10).getStringCellValue().trim());
			forwarddrs4SimplificationTwoList.setAffectObjDesc(r.getCell(11) == null ? "" : r.getCell(11).getStringCellValue().trim());
			forwarddrs4SimplificationTwoList.setDescOfChange(r.getCell(12) == null ? "" : r.getCell(12).getStringCellValue().trim());
			forwarddrs4SimplificationTwoList.setSapNotes(r.getCell(13) == null ? "" : r.getCell(13).getStringCellValue().trim());
			forwarddrs4SimplificationTwoList.setSolutionSteps(r.getCell(14) == null ? "" : r.getCell(14).getStringCellValue().trim());
			forwarddrs4SimplificationTwoList.setComplexity(r.getCell(15) == null ? "" : r.getCell(15).getStringCellValue().trim());
			forwarddrs4SimplificationTwoList.setIssueCategory(r.getCell(16) == null ? "" : r.getCell(16).getStringCellValue().trim());
			forwarddrs4SimplificationTwoList.setErrorCategory(r.getCell(17) == null ? "" : r.getCell(17).getStringCellValue().trim());
			forwarddrs4SimplificationTwoList.setTriggerObj(r.getCell(18) == null ? "" : r.getCell(18).getStringCellValue().trim());
			forwarddrs4SimplificationTwoList.setRemediationCategory(r.getCell(19) == null ? "" : r.getCell(19).getStringCellValue().trim());
			forwarddrs4SimplificationTwoList.setSapSimpListChapter(r.getCell(20) == null ? "" : r.getCell(20).getStringCellValue().trim());
			forwarddrs4SimplificationTwoList.setApplicationComponent(r.getCell(21) == null ? "" : r.getCell(21).getStringCellValue().trim());
			forwarddrs4SimplificationTwoList.setSapSimplCategry(r.getCell(22) == null ? "" : r.getCell(22).getStringCellValue().trim());
			forwarddrs4SimplificationTwoList.setItemArea(r.getCell(23) == null ? "" : r.getCell(23).getStringCellValue().trim());
			drs4SimplificationTwoList.add(forwarddrs4SimplificationTwoList);
		}	
  }
  excelSheetList.insertdrs4SimplificationTwoList(drs4SimplificationTwoList, session, requestId);
}

public void drs4SimplificationThreeList(long requestId,HttpSession session) throws SQLException, IOException {
	File file = new File(uploadPath);
	InputStream inputStream = new FileInputStream(file);
int rowCount = 0;
String lineNo = null;
@SuppressWarnings("deprecation")
StreamingReader drs4SimplificationThreeListreader = StreamingReader.builder().rowCacheSize(1002).bufferSize(1024).sheetIndex(16)
		.read(inputStream);
for (Row r : drs4SimplificationThreeListreader) {
	if (r.getRowNum() > 0) {
		rowCount = rowCount + 1;
		forwarddrs4SimplificationThreeList = new S4DetailReportRemediation();
		forwarddrs4SimplificationThreeList.setType(r.getCell(0) == null ? "" : r.getCell(0).getStringCellValue().trim());
		forwarddrs4SimplificationThreeList.setObjName(r.getCell(1) == null ? "" : r.getCell(1).getStringCellValue().trim());
		forwarddrs4SimplificationThreeList.setUsed(r.getCell(2) == null ? "" : r.getCell(2).getStringCellValue().trim());
		forwarddrs4SimplificationThreeList.setSubObject(r.getCell(3) == null ? "" : r.getCell(3).getStringCellValue().trim());
		forwarddrs4SimplificationThreeList.setMethod(r.getCell(4) == null ? "" : r.getCell(4).getStringCellValue().trim());
		forwarddrs4SimplificationThreeList.setPckg(r.getCell(5) == null ? "" : r.getCell(5).getStringCellValue().trim());
		forwarddrs4SimplificationThreeList.setImpactedObjType(r.getCell(6) == null ? "" : r.getCell(6).getStringCellValue().trim());
		Cell seven = (r.getCell(7));
		if(seven==null) {
			inputStream.close();
			break;
		}
		if(!r.getCell(7).getStringCellValue().equalsIgnoreCase(""))
		{
		lineNo = r.getCell(7).getStringCellValue().trim();
		forwarddrs4SimplificationThreeList.setLineNo(Integer.parseInt(lineNo));
		}
		else
		{
			forwarddrs4SimplificationThreeList.setLineNo(0);
		}
		forwarddrs4SimplificationThreeList.setStmt(r.getCell(8) == null ? "" : r.getCell(8).getStringCellValue().trim());
        forwarddrs4SimplificationThreeList.setOperations(r.getCell(9) == null ? "" : r.getCell(9).getStringCellValue().trim());
		forwarddrs4SimplificationThreeList.setImpactReason(r.getCell(10) == null ? "" : r.getCell(10).getStringCellValue().trim());
		forwarddrs4SimplificationThreeList.setAffectObjDesc(r.getCell(11) == null ? "" : r.getCell(11).getStringCellValue().trim());
		forwarddrs4SimplificationThreeList.setDescOfChange(r.getCell(12) == null ? "" : r.getCell(12).getStringCellValue().trim());
		forwarddrs4SimplificationThreeList.setSapNotes(r.getCell(13) == null ? "" : r.getCell(13).getStringCellValue().trim());
		forwarddrs4SimplificationThreeList.setSolutionSteps(r.getCell(14) == null ? "" : r.getCell(14).getStringCellValue().trim());
		forwarddrs4SimplificationThreeList.setComplexity(r.getCell(15) == null ? "" : r.getCell(15).getStringCellValue().trim());
		forwarddrs4SimplificationThreeList.setIssueCategory(r.getCell(16) == null ? "" : r.getCell(16).getStringCellValue().trim());
		forwarddrs4SimplificationThreeList.setErrorCategory(r.getCell(17) == null ? "" : r.getCell(17).getStringCellValue().trim());
		forwarddrs4SimplificationThreeList.setTriggerObj(r.getCell(18) == null ? "" : r.getCell(18).getStringCellValue().trim());
		forwarddrs4SimplificationThreeList.setRemediationCategory(r.getCell(19) == null ? "" : r.getCell(19).getStringCellValue().trim());
		forwarddrs4SimplificationThreeList.setSapSimpListChapter(r.getCell(20) == null ? "" : r.getCell(20).getStringCellValue().trim());
		forwarddrs4SimplificationThreeList.setApplicationComponent(r.getCell(21) == null ? "" : r.getCell(21).getStringCellValue().trim());
		forwarddrs4SimplificationThreeList.setSapSimplCategry(r.getCell(22) == null ? "" : r.getCell(22).getStringCellValue().trim());
		forwarddrs4SimplificationThreeList.setItemArea(r.getCell(23) == null ? "" : r.getCell(23).getStringCellValue().trim());
		drs4SimplificationThreeList.add(forwarddrs4SimplificationThreeList);	
      }
  }
    excelSheetList.insertdrs4SimplificationThreeList(drs4SimplificationThreeList, session, requestId);
 }
}
