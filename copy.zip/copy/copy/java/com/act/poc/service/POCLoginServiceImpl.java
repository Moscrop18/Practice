package com.act.poc.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.act.exceptions.SignUpException;
import com.act.poc.model.User;
import com.act.poc.service.factory.ServiceRegistry;

@Service(value = "pocLoginService")
@Transactional(readOnly = false)
public class POCLoginServiceImpl extends ServiceRegistry implements POCLoginService {
	
	
	@Override
	public void pocSignedup(final User user,String role)
	{
		//final boolean isUserExists = checkUserNameExists(user.getUserName());
		/*if(isUserExists)
		{
			throw new SignUpException(101);
		}*/
		
		getUserdata().saveUserData(user,role);
		
	}

	@Override
	public void assignRequest(final String userName, final String[] requestIdArray) {
		final List<Long> requestIdList = new ArrayList<Long>();
		for(String requestId: requestIdArray)
		{
			requestIdList.add(Long.parseLong(StringUtils.trim(requestId)));
		}
		getPocLoginDao().assignRequest(userName,requestIdList);
		
	}

	

}
