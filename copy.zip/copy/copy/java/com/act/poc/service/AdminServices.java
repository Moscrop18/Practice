package com.act.poc.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.act.admin.UserDetails;
import com.act.poc.dao.POCRequestMappingDAO;
import com.act.poc.dao.UserDAO;
import com.act.poc.dao.UserRoleDao;
import com.act.poc.model.UserRole;


public class AdminServices {

	UserRoleDao userRoleDAO;
	UserDAO userDAO;
	POCRequestMappingDAO pocRequestMappingdao;
	POCLoginService pocLoginService;
	
	public void setPocLoginService(POCLoginService pocLoginService) {
		this.pocLoginService = pocLoginService;
	}

	public void setPocRequestMappingdao(POCRequestMappingDAO pocRequestMappingdao) {
		this.pocRequestMappingdao = pocRequestMappingdao;
	}

	public void setUserDAO(UserDAO userDAO) {
		this.userDAO = userDAO;
	}

	public void setUserRoleDAO(UserRoleDao userRoleDAO) {
		this.userRoleDAO = userRoleDAO;
	}
	
	
	/*
	 * CR-17: Modified the user removal functionality to allow admin to 
	 * soft remove the admin/poc/client, all of them.
	 */
	public String removeUser(String userName) throws Exception
	{
		List<UserRole> userRoles=userRoleDAO.getUserRoles(userName);
		List<String> listOfRoles=new ArrayList<String>();
		for(UserRole userRole:userRoles){listOfRoles.add(userRole.getUserRole());}
		if(userDAO.getUser(userName)!=null )
		{
			//If the user is Admin or POC, then reset the request status.
			if(!(listOfRoles.contains("ROLE_CLIENT")) )
			{
				pocRequestMappingdao.resetStatus(userName);
			}

			if(userDAO.deleteUser(userName))
			{
				return "User account deactivated successfuly";
			}
			else
			{
				return "User account was not deactivated successfuly";
			}
		}
		else
		{
			throw new UsernameNotFoundException("Please enter valid username");
		}
	}
}
