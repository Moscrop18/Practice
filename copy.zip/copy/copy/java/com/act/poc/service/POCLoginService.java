package com.act.poc.service;

import com.act.poc.model.User;

public interface POCLoginService {

	
	void pocSignedup(final User user,String role);

	void assignRequest(final String userName, final String[] requestIdArray);
}
