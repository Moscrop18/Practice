package com.act.poc.service;

import java.util.List;
import java.util.Map;

//import org.apache.log4j.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.act.client.model.RequestFormDetailsBean;
import com.act.model.StatusMaster;
import com.act.poc.dao.POCRequestInventoryDAO;
import com.act.poc.dao.POCRequestMappingDAO;
import com.act.poc.model.POCDetailsBean;

public class DashBoard {

	public POCRequestMappingDAO daoobj;
	public POCRequestInventoryDAO requestInventory;
	final public Logger logger=LoggerFactory.getLogger(DashBoard.class);
	
	public void setRequestInventory(POCRequestInventoryDAO requestInventory) {
		this.requestInventory = requestInventory;
	}

	public void setDaoobj(POCRequestMappingDAO daoobj) {
		this.daoobj = daoobj;
	}

	
	public List<StatusMaster> getStatusList()
	{
		return daoobj.getStatusList();
	}
	
	public List<RequestFormDetailsBean> getUserRequests(final String userName, final String status, final Long requestId, final Integer limit, final Integer start, final String toolName) {

		return daoobj.getRequests(userName, status, requestId, limit, start, toolName);
	
	}
	
	public List<RequestFormDetailsBean> getInitiatedRequests(final int limit, final int start, final String toolName, Long requestId) throws Exception
	{
		logger.info("Entered DashBoard java prog");
		return requestInventory.getInitiatedRequests(limit, start, toolName, requestId);
	}

	public List<RequestFormDetailsBean> getClientRequests(final String userName, final String status, final Long requestId, final Integer limit, final Integer start, final String toolName) {

		return daoobj.getClientRequests(userName, status, requestId, limit, start, toolName);
	
	}

	public List<POCDetailsBean> getPOCRequests(final String userName, final String pocSubStatus, final Long requestId, final Integer limit, final Integer start, final String toolName, final Integer month) {

		return daoobj.getPOCRequests(userName, pocSubStatus, requestId, limit, start, toolName, month);
	
	}
	
	public Integer getTotalPOCRequests(final String userName, final String pocSubStatus, final Long requestId, final String toolName, final Integer month) {

		return daoobj.getTotalPOCRequests(userName, pocSubStatus, requestId, toolName, month);
	
	}
	
	public Integer getTotalClientRequests(final String userName, final String status, final Long requestId, final String toolName) {

		return daoobj.getTotalClientRequests(userName, status, requestId, toolName);
	
	}

	public Integer getTotalUserRequests(String userName, String status, Long requestId, final String toolName) {
		return daoobj.getTotalUserRequests(userName, status, requestId, toolName);
	}

	public Integer getTotalInitiatedRequests(final String toolName) {
		return requestInventory.getTotalInitiatedRequests(toolName);
	}
	
	/**
	 * This method returns the list of all the request in the passed
	 * status per IG wise.
	 * @param status
	 * @return
	 */
	public List<Map<String,String>> getResquestDetailStatusWise(String status, final String toolName) 
	{
		logger.info("Inside DashBoard getReQuestDetailStatusWise");
		return requestInventory.getRequests(status, toolName);
	}
}
 
