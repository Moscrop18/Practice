package com.act.poc.service.factory;

import org.springframework.beans.factory.annotation.Autowired;

import com.act.poc.dao.FetchEmailID;
import com.act.poc.dao.POCLoginDao;
import com.act.poc.dao.UserDAO;
import com.act.poc.model.User;

public class ServiceRegistry {

	private POCLoginDao pocLoginDao;
	
	private UserDAO userdata;
	
	public POCLoginDao getPocLoginDao() {
		return pocLoginDao;
	}

	@Autowired
	public void setPocLoginDao(final POCLoginDao pocLoginDao) {
		this.pocLoginDao = pocLoginDao;
	}
	
	@Autowired
	public void setUserdata(final UserDAO userdata) {
		this.userdata = userdata;
	}
	
	public UserDAO getUserdata() {
		return userdata;
	}

	protected boolean checkUserNameExists(final String userName) {
		final User user = getPocLoginDao().getUser(userName);
		return user != null;
	}	
}
