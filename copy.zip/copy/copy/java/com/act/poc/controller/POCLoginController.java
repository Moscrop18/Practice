/* CR No.			- 	Requirement		- 	Date 		-		Modified By  *
 *CR-3.0:- Remove unused fields(like Customer_namespaces,
				SPECIFIC_NAMING_CONEVNTIONS,NAMESPACE_DETAILS_FILE,NAMESPACE_DETAILS_FILE_NAME,NAMING_CONEVNTIONS_FILE,
				NAMING_CONVENTIONS_FILE_NAME) from create request form. -23/12/16 -monika.mishra 
*CR-6.0:- Give accessibility of View Inventory, Tabular View,Graphical View and Download buttons to admin -5/1/17 -monika.mishra
*
*CR-9.0:- Manual upload for Estimator & assuptions -17/01/17 -monika.mishra
*
*CR-41: Creating Separate Tabs for Active and inactive user for user details page-16/1/2018-rohan.a.mehra 
*
*CR-63: S4 simplification UI-29/3/2018-roah.a.mehra
*
*CR-47: Admin UI change according to the new UI -04/04/2018 -himani.malhotra
*
*CR : FIAT Download File from POC -01/07/2019 -himani.malhotra
*/

package com.act.poc.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.displaytag.tags.TableTagParameters;
import org.displaytag.util.ParamEncoder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.support.ByteArrayMultipartFileEditor;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.act.S4.models.FileStore;
import com.act.admin.UserDetails;
import com.act.client.model.QueryFormModel;
import com.act.client.model.RequestForm;
import com.act.client.model.RequestFormDetailsBean;
import com.act.client.model.RequestInventory;
import com.act.constant.Hana_Profiler_Constant;
import com.act.controller.AbstractBaseController;
import com.act.displaygrid.model.HanaProfile_Download;
import com.act.exceptions.ReqIDNotValidException;
import com.act.exceptions.SignUpException;
import com.act.exceptions.TransportRequestException;
import com.act.model.StatusMaster;
import com.act.poc.model.JqGridResponse;
import com.act.poc.model.User;
import com.act.poc.model.UserModel;
import com.act.poc.service.DashBoard;
import com.act.service.RequestIDValidateService;
import com.act.statictables.model.TransportRequest;
import com.act.statictables.model.TransportRequestFile;
import com.act.statictables.model.TransportRequestFileModel;
import com.act.utility.HANAUtility;
import com.act.utility.SendEmail;
import com.act.validator.RequestID_Validator_Utility;

@Controller
@SessionAttributes("User")


public class POCLoginController extends AbstractBaseController {
	
	@Autowired
	private RequestIDValidateService reqIDValid;

	@ExceptionHandler(value = Exception.class)
	public String handleGenericException(Exception ex) {

		logger.info("Inside Exception handler");
		logger.error("Error !!! " + ex);

		return ex.getMessage();
	}

	/*CR-43: Admin Dashboard UI change	*/
	@RequestMapping(value = "/poc/dashBoard", method = RequestMethod.GET)
	public String dashBoard(Model model, HttpServletRequest request,@RequestParam(value = "action", required = false) String action, final String status, Long requestId, final String  requestIdUi, HttpSession session)
			throws Exception {
		logger.info("User accessing the page" + getPrincipal());
		String userName = getPrincipal();
		String toolName = (String) session.getAttribute("tool");
		model.addAttribute(new DashBoard());
		List<RequestFormDetailsBean> POCRequestsList;
		Integer totalRequest = 0;
		List<RequestFormDetailsBean> CountList;
		int start = 0;
		String page;
		
		if(requestIdUi!= null)
		{
			
			if(requestIdUi.length()!=14)
			{
			model.addAttribute("IdError", "Please enter a valid Request ID.");
			}
			else
			{
				requestId=getRequestDetails().getRequestID(requestIdUi);
			}
		}
		
		if (request.isUserInRole("ADMIN")) {
			final List<StatusMaster> statusList = getDashBoard().getStatusList();
			model.addAttribute("statusList", statusList);
			model.addAttribute("status", status);
			model.addAttribute("requestId", requestId);
			model.addAttribute("requestIdUi", requestIdUi);
			model.addAttribute("userNameList", getUserdata().getUserNameList());
			page = request.getParameter((new ParamEncoder(Hana_Profiler_Constant.CLIENT_DASHBOARD_TABLE_ID)
					.encodeParameterName(TableTagParameters.PARAMETER_PAGE)));
			page = StringUtils.defaultIfEmpty(page, "1");

			start = (Integer.parseInt(page) - 1) * 3;
			int flag=0;
			if(status==null||Hana_Profiler_Constant.REJECTED_STATUS.equals(status)||Hana_Profiler_Constant.APPROVED_STATUS.equals(status)
					||Hana_Profiler_Constant.PENDING_STATUS.equals(status)||Hana_Profiler_Constant.IDVSUCCESS_STATUS_COMMENT.equals(status)
					||Hana_Profiler_Constant.IDVFAILED_STATUS.equals(status)||Hana_Profiler_Constant.COMPLETED_STATUS.equals(status)
					||Hana_Profiler_Constant.NOT_COMPLETED_STATUS.equals(status)||Hana_Profiler_Constant.COMPLETED_PENDING_ESTIMATIONS.equals(status))
			{
					
					POCRequestsList = getDashBoard().getUserRequests(null, status, requestId,
							3, start, toolName);
					totalRequest = getDashBoard().getTotalUserRequests(null, status, requestId, toolName);
					if (POCRequestsList != null && !POCRequestsList.isEmpty()) {
						model.addAttribute("POCRequestsList", POCRequestsList);
						model.addAttribute("totalRecords", totalRequest);
					} else {
							model.addAttribute("NullPOCRequestsListmessage", "No Requests processed by the POC " + userName);
							flag=0;
						}
			}
			else if(status.equals("Initiated"))
			{	
				List<RequestFormDetailsBean> InitiatedRequestsList = getDashBoard()
						.getInitiatedRequests(3, start, toolName, requestId);
				if (InitiatedRequestsList != null && !InitiatedRequestsList.isEmpty()) {
					model.addAttribute("POCRequestsList", InitiatedRequestsList);
					model.addAttribute("totalRecords", getDashBoard().getTotalInitiatedRequests(toolName));
				} else {
					model.addAttribute("NullPOCRequestsListmessage", "No Newly Initiated Requests");
				}		
			}
			
			if(flag==0)
			{
				if(status==null)
				{
				List<RequestFormDetailsBean> InitiatedRequestsList = getDashBoard()
						.getInitiatedRequests(3, start, toolName, requestId);
				if (InitiatedRequestsList != null && !InitiatedRequestsList.isEmpty()) {
						model.addAttribute("POCRequestsList", InitiatedRequestsList);
						model.addAttribute("totalRecords", InitiatedRequestsList.size());
					} else {
						model.addAttribute("NullPOCRequestsListmessage", "No Requests processed by the POC " + userName);
					}
				}
			}

			
			
			
			
			List<RequestFormDetailsBean> InitiatedRequestsList = getDashBoard()
					.getInitiatedRequests(3, 0, toolName,null);
			if (InitiatedRequestsList != null && !InitiatedRequestsList.isEmpty()) {
				model.addAttribute("InitiatedRequestsList", InitiatedRequestsList);
				model.addAttribute("totalIntialRequestRecords", getDashBoard().getTotalInitiatedRequests(toolName));
			} else {
				model.addAttribute("NullInitiatedRequestsList", "No Newly Initiated Requests");
			}
			
			List<RequestFormDetailsBean> Approved_list= new ArrayList<RequestFormDetailsBean>();
			List<RequestFormDetailsBean> Rejected_list= new ArrayList<RequestFormDetailsBean>();
			List<RequestFormDetailsBean> IDVSuccess_list= new ArrayList<RequestFormDetailsBean>();
			List<RequestFormDetailsBean> IDVFailed_list= new ArrayList<RequestFormDetailsBean>();
			List<RequestFormDetailsBean> Pending_list= new ArrayList<RequestFormDetailsBean>();
			List<RequestFormDetailsBean> NotCompleted_list= new ArrayList<RequestFormDetailsBean>();
			List<RequestFormDetailsBean> Pending_Estimations_list= new ArrayList<RequestFormDetailsBean>();
			List<RequestFormDetailsBean> Completed_list= new ArrayList<RequestFormDetailsBean>();
			CountList = getDashBoard().getUserRequests(null, null,null,
					null, 0, toolName);
			if (CountList != null && !CountList.isEmpty()) {
				for (RequestFormDetailsBean listData : CountList) {
					String status_Of = listData.getStatus();
						if(status_Of.compareTo("Approved") == 0) {
							Approved_list.add(listData);
							
						}
						else if(status_Of.compareTo("Rejected") == 0) {
							Rejected_list.add(listData);
							
						}
						else if(status_Of.compareTo("IDVSuccess") == 0) {
							IDVSuccess_list.add(listData);
							
						}
						else if(status_Of.compareTo("IDVFailed") == 0) {
							IDVFailed_list.add(listData);
							
						}
						else if(status_Of.compareTo("Pending") == 0) {
							Pending_list.add(listData);
							
						}
						else if(status_Of.compareTo("Not Completed") == 0) {
							NotCompleted_list.add(listData);
							
						}
						else if(status_Of.compareTo("Completed With Pending Estimations") == 0) {
							Pending_Estimations_list.add(listData);
							
						}
						else if(status_Of.compareTo("Completed") == 0) {
							Completed_list.add(listData);
						
						}
						
				}
			}
			
			if(! Approved_list.isEmpty()) {
				model.addAttribute("Approved_total", Approved_list.size());
			}else {
				model.addAttribute("Approved_total",0);
			}
			
			if(! Rejected_list.isEmpty())
			{
				model.addAttribute("Rejected_total", Rejected_list.size());
			}else {
				model.addAttribute("Rejected_total",0);
			}
			
			if( ! IDVSuccess_list.isEmpty())
			{
				model.addAttribute("IDVSuccess_total", IDVSuccess_list.size());
			}else {
				model.addAttribute("IDVSuccess_total",0);
			}

			if(! IDVFailed_list.isEmpty())
			{
				model.addAttribute("IDVFailed_total", IDVFailed_list.size());
			}else {
				model.addAttribute("IDVFailed_total",0);
			}

			if(!Pending_list.isEmpty())
			{
				model.addAttribute("Pending_total", Pending_list.size());
			}else {
				model.addAttribute("Pending_total",0);
			}

			if(! NotCompleted_list.isEmpty())
			{
				model.addAttribute("NotCompleted_total", NotCompleted_list.size());
			}else {
				model.addAttribute("NotCompleted_total",0);
			}

			if(!Pending_Estimations_list.isEmpty())
			{
				model.addAttribute("Pending_Estimations_total", Pending_Estimations_list.size());
			}else {
				model.addAttribute("Pending_Estimations_total",0);
			}
			
			if(!Completed_list.isEmpty()) {
				model.addAttribute("Completed_total", Completed_list.size());
			}else {
				model.addAttribute("Completed_total",0);
			}	
			
		}//CR 21: User role changed to POC. 
		else if (request.isUserInRole("POC")) {
			POCRequestsList = getDashBoard().getUserRequests(userName, null, null,
					Hana_Profiler_Constant.DASHBOARD_PAGE_SIZE, start, toolName);
			totalRequest = getDashBoard().getTotalUserRequests(userName, status, requestId, toolName);
		} else {
			return "/accessdenied";
		}

		model.addAttribute("UserName", userName);
		logger.info("userName is" + userName);
		return "poc/dashBoard";
	}
		
	@RequestMapping(value = "/admin/statusCountChart", method = RequestMethod.GET)
	public String displayStatusCountChart(Model model, HttpSession session) {

		String toolName = (String) session.getAttribute("tool");
		model.addAttribute("Initiated", getGraphDao().getStatusWiseCount("Initiated", toolName));
		model.addAttribute("Pending", getGraphDao().getStatusWiseCount("Pending", toolName));
		model.addAttribute("Approved", getGraphDao().getStatusWiseCount("Approved", toolName));
		model.addAttribute("IDVSuccess", getGraphDao().getStatusWiseCount("IDVSuccess", toolName));
		model.addAttribute("IDVFailed", getGraphDao().getStatusWiseCount("IDVFailed", toolName));
		model.addAttribute("Rejected", getGraphDao().getStatusWiseCount("Rejected", toolName));
		model.addAttribute("NotCompleted", getGraphDao().getStatusWiseCount("Not Completed", toolName));
		/*CR-9.0*/


		model.addAttribute("CompletedPendingEstimation", getGraphDao().getStatusWiseCount("Completed with Pending Estimations", toolName));
		model.addAttribute("Completed", getGraphDao().getStatusWiseCount("Completed", toolName));


		return "admin/statusCountChart";
	}

	/*CR- 6.0*/
	@RequestMapping(value = "/requestDetails/{requestID}", method = RequestMethod.GET)
	public String showRequestIDDetails(@PathVariable("requestID") long requestID, Model model) throws IOException {

		RequestForm requestForm = getRequestDetails().getRequestObj(requestID);
		RequestInventory requestInventory = (getClientRequestInventoryDAO().getRequestInventory(requestID));

		model.addAttribute("requestForm", requestForm);
		model.addAttribute("requestInventory", requestInventory);
		return "requestFormDisplay";

	}

	@RequestMapping(value = "/poc/pocDecision/{requestID}", method = RequestMethod.POST)
	public String requestApprovalORRejection(@PathVariable("requestID") long requestID,
			@RequestParam(value = "action", required = false) String action, Model model,HttpSession session, HttpServletResponse response,
			RedirectAttributes redirectAttributes) throws Exception {
		
		String toolName = (String) session.getAttribute("tool");
		final String systemStatus = getAutoHANA().getSystemStatus(requestID);
		if (action.equalsIgnoreCase("Approve")) {
			
			int latestTRIdValue=	getTransportRequestService().checkMaxVersionCount();
			TransportRequestFile transportRequest = getTransportRequestDAO().getTransportRequestLatest(latestTRIdValue);
			if (transportRequest != null) {
				model.addAttribute("RequestID", requestID);
				model.addAttribute("TransportRequest", transportRequest);
				return "poc/contentfileUpload";
			} else {
			  logger.info("inside else if block,null obj"); 
			  model.addAttribute("RequestID",requestID); 
			  model.addAttribute("TransportRequestNull","There is no Transport Request File.");
			  getRequestInventorydao().setComments(requestID,Hana_Profiler_Constant.TR_FILE_NOT_FOUND_COMMENTS);
			}
		 return "poc/contentfileUpload";
		} else if (StringUtils.equals(action, Hana_Profiler_Constant.PROCEED_ACTION)) {
			if (StringUtils.equals(systemStatus, Hana_Profiler_Constant.INITIATED_STATUS)) {
				logger.info("Inside if and setting intiated status to pending");
				final String userName = getPrincipal();
				logger.info("Inside if and setting intiated status to pending for the user : " + userName);
				getRequestInventorydao().updateSatus(requestID, "Pending", userName, "workingontheRequest",toolName);
				logger.info("Inside if : Status updated as pending ");
				logger.info("Inside if : trying to add user for the request : " + requestID );
				getPocRequestMappingdao().addUser(userName, requestID);
				logger.info("Inside if : Request id : " + requestID + " Got mapped with user  : " + userName);
			} else {
				logger.info("Inside else : Request is not iniated stage : " + requestID);
				redirectAttributes.addFlashAttribute("donLoadXlsxError", "Request is not in initiated stage");
			}
			/*CR-6.0*/
			return "redirect:/requestDetails/{requestID}";
		} else if (StringUtils.equals(action, Hana_Profiler_Constant.CANCEL_ACTION)) {
			return "redirect:/poc/dashBoard";
		} else if (action.equalsIgnoreCase("Reject")) {
			model.addAttribute("RequestID", requestID);
			return "poc/reject";
		}

		else {

			return "";
		}
	}

	@RequestMapping(value = "/poc/download/{sourceVersion}/{targetVersion}/")
	public String downloadApprovedTRWithVersion(@PathVariable("sourceVersion") String sourceVersion,
			@PathVariable("targetVersion") String targetVersion, HttpServletResponse response) {

		TransportRequest transportRequest = getTransportRequestDAO().getTransportRequest(sourceVersion, targetVersion);

		try {
			byte[] fileBytes = transportRequest.getTrFile();
			String fileName = transportRequest.getTrFileName();
			String errorMessage = getFileDownload().downloadFile(fileBytes, response, fileName);
			if (errorMessage != null) {
				return "requestFormDisplay";
			}
		} catch (IOException e) {
			logger.error("Error !!! " + e);
		}

		return null;
	}

	@RequestMapping(value = "/poc/download/{requestID}")
	public String downloadApprovedTR(@PathVariable("requestID") Long requestID, HttpServletResponse response) {

		try {
			TransportRequest transportRequest = getTransportRequestDAO().getTransportRequestobj(requestID);
			byte[] fileBytes = transportRequest.getTrFile();
			String fileName = transportRequest.getTrFileName();
			String errorMessage = getFileDownload().downloadFile(fileBytes, response, fileName);
			if (errorMessage != null) {
				return "requestFormDisplay";
			}
		} catch (IOException e) {
			logger.error("Error !!! " + e);
		}

		catch (Exception e) {
			logger.error("Error !!! " + e);
		}
		return null;
	}

	@RequestMapping(value = "/poc/approved/{requestID}", method = RequestMethod.POST)
	public String requestApproved(@PathVariable("requestID") long requestID,HttpSession session) throws Exception {
		
		String toolName = (String) session.getAttribute("tool");
		final String systemStatus = getAutoHANA().getSystemStatus(requestID);
		if (StringUtils.equals(systemStatus, Hana_Profiler_Constant.PENDING_STATUS)) {
			getRequestInventorydao().updateSatus(requestID, "Approved", getPrincipal(), "Approved",toolName);
			getRequestInventorydao().addRequestApprovedTRFileName(requestID,
					(getTransportRequestDAO().getTransportRequestobj(requestID)).getTrFileName());
		}
		return "redirect:/poc/dashBoard";
	}

	@RequestMapping(value = "/poc/notapprovedTR/{requestID}", method = RequestMethod.POST)
	public String requestNotApproved(@PathVariable("requestID") long requestID,
			@RequestParam(value = "comments") String comments, final Model model, HttpSession session) throws Exception {
		
		String toolName = (String) session.getAttribute("tool");
		
		if (StringUtils.isEmpty(StringUtils.trimToNull(comments))
				|| StringUtils.isEmpty(comments.toString().replace("\r", "").replace("\n", ""))) {
			model.addAttribute("commentErrMsg", "Please enter comment.");
			model.addAttribute("RequestID", requestID);
			model.addAttribute("TransportRequest", getTransportRequestDAO().getTransportRequestobj(requestID));
			return "poc/approve";
		}

		getRequestInventorydao().updateSatus(requestID, "Pending", getPrincipal(), comments,toolName);
		return "redirect:/poc/dashBoard";
	}

	@RequestMapping(value = "/poc/reject/{requestID}", method = RequestMethod.POST)
	public String requestRejection(@PathVariable("requestID") long requestID,
			@RequestParam(value = "comments") String comments, final Model model,HttpSession session) {
		
		String toolName = (String) session.getAttribute("tool");
		if (StringUtils.isEmpty(StringUtils.trimToNull(comments))
				|| StringUtils.isEmpty(comments.toString().replace("\r", "").replace("\n", ""))) {
			model.addAttribute("commentErrMsg", "Please enter comment.");
			model.addAttribute("RequestID", requestID);
			return "poc/reject";
		}

		final String systemStatus = getAutoHANA().getSystemStatus(requestID);
		if (StringUtils.equals(systemStatus, Hana_Profiler_Constant.PENDING_STATUS))

		{
			logger.info("Inside request Rejection page");
			getRequestInventorydao().updateSatus(requestID, "Rejected", getPrincipal(), comments,toolName);
		}
		return "redirect:/poc/dashBoard";

	}

	@RequestMapping(value = "/admin/addUser", method = RequestMethod.GET)
	public String addUser(Model model) {
		model.addAttribute("user", new User());
		return "admin/addUser";
	}

	@RequestMapping(value = "/admin/removeUser", method = RequestMethod.GET)
	public String removeUser() {
		return "admin/removeUser";
	}

	@RequestMapping(value = "/admin/addnewTransportRequest", method = RequestMethod.GET)
	public String addnewTransportRequest(Model model) {
		model.addAttribute("transportRequest", new TransportRequest());
		return "admin/addTransportRequest";
	}

	
	
	
	@RequestMapping(value = "/admin/deleteTrFile", method = RequestMethod.POST)
	public String deleteTrFile(String[] trFileVersion, RedirectAttributes redirectAttributes) {
		if (!ArrayUtils.isEmpty(trFileVersion)) {
			getTransportRequestDAO().deleteTrFile(trFileVersion);
			redirectAttributes.addFlashAttribute("message", "Files are deleted successfully");
		} else {
			redirectAttributes.addFlashAttribute("errorMessage", "Please select at least one file");
		}
		return "redirect:/admin/deleteTransportRequest";
	}

	@RequestMapping(value = "/admin/deleteTransportRequest", method = RequestMethod.GET)
	public String deleteTransportRequest(Model model, HttpSession session) {
		String toolName = (String) session.getAttribute("tool");
		model.addAttribute("trFileList", getTransportRequestDAO().getAllTransportRequest(toolName));
		return "admin/deleteTransportRequest";
	}

	/**
	 * CR-17: This method adds the user from the admin side..
	 * @param userRole
	 * @param model
	 * @param redirectAttributes
	 * @param user
	 * @param result
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/admin/userAddedViaUD", method=RequestMethod.POST)
	public String userAddedViaUD(@RequestParam("role") String userRole, Model model,
			final RedirectAttributes redirectAttributes, @Valid @ModelAttribute("user") UserModel userModel,
			BindingResult result, HttpServletRequest request,HttpSession session) {
		User user=prepareUserModel(userModel);
		try {
			//Defect added validation check for add user page -rohan.a.mehra
			logger.info("Inside userAddedViaUD method");
				if (StringUtils.isBlank(user.getUserName())) {
					redirectAttributes.addFlashAttribute("userNameErrorMessage", "User Name can't be blank.");
				}
				else if(user.getUserName().length()<=3) {
					redirectAttributes.addFlashAttribute("userNameErrorMessage", "User Name must have min 4 Characters");
				}
				
				boolean isUserRoleEmpty = StringUtils.isBlank(userRole);
				if (isUserRoleEmpty) {
					redirectAttributes.addFlashAttribute("roleEmptyErrorMessage", "User Role can not be empty");
				}
				
				if (!emailIsValid(user.getEmailId())) {
					redirectAttributes.addFlashAttribute("emailIdEmptyErrorMessage", "Enter a valid format of Email Id");
					}
			if (result.hasErrors() || isUserRoleEmpty) {
				logger.info("inside if hasErrors method");
				logger.info("inside if hasErrors method" + result.getFieldErrors());
				return "redirect:/admin/addUser";
			}

			logger.info("Inside user adding method,before pocSignedup call ");
			Calendar calendar = Calendar.getInstance();
			//Current date on which account is created.
			Date createdOn = new Date(calendar.getTimeInMillis());
			user.setCreatedOn(createdOn);
			if(userRole.equalsIgnoreCase(Hana_Profiler_Constant.CLIENT_ROLE))
			{
				//Account valid for 3 Months for client.
				calendar.add(Calendar.MONTH, 3);
			}
			else
			{
				//Account valid for 1 Year for admin.
				calendar.add(Calendar.YEAR, 1);
			}
			Date validTill = new Date(calendar.getTimeInMillis());
			user.setValidTill(validTill);
			getPocLoginService().pocSignedup(user, userRole);
			String userName = user.getUserName();
			redirectAttributes.addFlashAttribute("message", userName +" has been added successfully");
			String emailBody = "\n\n Dear "+userName+". Your account has been created by Admin.";;
			sendEmailToUser(userName , request, emailBody,session);
		} catch (SignUpException exception) {
			redirectAttributes.addFlashAttribute("user", user);
			redirectAttributes.addFlashAttribute("userNameDuplicateErrorMessage", "Username already exists");
			return "redirect:/admin/addUser";
		}
		return "redirect:/admin/userDetails";
	}
	private User prepareUserModel(UserModel um) {
		User u = new User();
		u.setClientName(um.getClientName());
		u.setConfirmPassword(um.getConfirmPassword());
		u.setCreatedOn(um.getCreatedOn());
		u.setCurrentPassword(um.getCurrentPassword());
		u.setEmailId(um.getEmailId());
		u.setPassword(um.getPassword());
		u.setPocRequestMapping(um.getPocRequestMapping());
		u.setProjectName(um.getProjectName());
		u.setReject(um.getReject());
		u.setReset(um.getReset());
		u.setRolesAccess(um.getRolesAccess());
		u.setUserName(um.getUserName());
		u.setUserRole(um.getUserRole());
		u.setUserRoleValue(um.getUserRoleValue());
		u.setValidTill(um.getValidTill());
		
		return u;
	}
	private TransportRequestFile prepareTransportRequestFileModel(TransportRequestFileModel trm) {
		TransportRequestFile tr = new TransportRequestFile();
		tr.setID(trm.getID());
		tr.setTrFile(trm.getTrFile());
		tr.setTrFileName(trm.getTrFileName());
		tr.setTrVersion(trm.getTrVersion());
		tr.setUpdatedDate(trm.getUpdatedDate());
		
		return tr;
	}
	/**
	 * This private method check user email id format from the admin side(add user page).
	 * @return 
	 */
	private Boolean emailIsValid(String email)
	{
	        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+
	                            "[a-zA-Z0-9_+&*-]+)*@" +
	                            "(?:[a-zA-Z0-9-]+\\.)+[a-z" +
	                            "A-Z]{2,7}$";
	                             
	        Pattern pat = Pattern.compile(emailRegex);
	        if (email == null){
	            return false;
	        }   
	        if(pat.matcher(email).matches()){
	        	
	        	if(email.indexOf("", email.length() - "".length()) != -1){
	       	      return true;
	        	}
	        	else
	        		return false;
	     	}
	        else
	        {
	    	 return false;
	        }
	        		
	
	}
	
	
	/**
	 * CR17: This method deactivates the user from admin side.
	 * @param request
	 * @param redirectAttributes
	 * @return
	 */
	@RequestMapping(value = "/admin/userRemovedViaUD", method=RequestMethod.POST)
	public String userRemovedViaUD(HttpServletRequest request, final RedirectAttributes redirectAttributes,HttpSession session) {
		String userNames[] = null;
		try {
			String userName = request.getParameter("userName");
			if (StringUtils.isBlank(userName)) {
				redirectAttributes.addFlashAttribute("message", "User Name can't be blank.");
			}
			else
			{
				userNames=userName.split(",");
			}
			for (String user : userNames) {
				String msg = getAdminServices().removeUser(user);
				redirectAttributes.addFlashAttribute("message", msg);
				String emailBody = "\n\n Dear "+user+". Your account has been deactivated by Admin.";;
				sendEmailToUser(user , request, emailBody,session);
			}
		} catch (UsernameNotFoundException exception) {
			redirectAttributes.addFlashAttribute("message", exception.getMessage());
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return "redirect:/admin/userDetails";
	}
	

	
	@RequestMapping(value = "/admin/transportRequestAddedAdmin", method = RequestMethod.POST)
	public String addedTransportRequest(@Valid @ModelAttribute("TransportRequestFile") TransportRequestFileModel transportRequestFileModel,
			BindingResult result, final RedirectAttributes redirectAttributes, Model model, HttpServletRequest request, HttpSession session) throws IOException {
		TransportRequestFile transportRequestFile=prepareTransportRequestFileModel(transportRequestFileModel);
		try {
			String fieldName="";			
			String fileName="";
			String extension = ".zip";

			File trFile=new File("");
			DiskFileItemFactory factory = new DiskFileItemFactory();
			factory.setSizeThreshold(0);
			ServletFileUpload upload = new ServletFileUpload(factory);
			upload.setFileSizeMax(-1);		
			upload.setSizeMax(-1);
			String toolName = (String) session.getAttribute("tool");
			List<FileItem> multipart = new ServletFileUpload(factory).parseRequest(request);

			for (FileItem item : multipart) {

				if (!item.isFormField()) {
					try {						
						trFile = new File(item.getName());
						fileName=trFile.getName();
						if (!fileName.equals("")) {
							String fileExtension = fileName.substring(fileName.length() - extension.length(),
									fileName.length());
							if (fileExtension.equalsIgnoreCase(".zip")) {
								transportRequestFile.setTrFile(item.get());
								transportRequestFile.setTrFileName(item.getName());
								transportRequestFile.setTrFileName(fileName);
								int maxid=	getTransportRequestService().checkMaxVersionCount();
								String TrVersion="TR"+maxid;	
								transportRequestFile.setTrVersion(TrVersion);
								getTransportRequestService().saveTRData(transportRequestFile);
								model.addAttribute("MessageSuccess", "Transport Request Added Succesfully");
							}
							else
							{
								model.addAttribute("MessageFail", "Transport Request failed upload .zip format.");
								return "admin/addTransportRequest";
							}
						}
					} catch (Exception ex) {
						logger.error("Error !!! " + ex);
					}
				}
			}			
		}

		catch (final FileUploadException exception) {
			logger.error("Inside FileUploadException");
			redirectAttributes.addFlashAttribute("fileException", exception.getMessage());

		}

		catch (TransportRequestException exception) {

			logger.error("Inside TransportRequestException");
			redirectAttributes.addFlashAttribute("fileException", "Transport Request Already Exists");

		} catch (Exception exception) {
			logger.error("Inside exception " + exception);
			redirectAttributes.addFlashAttribute("fileException", exception.getMessage());

		}

		return "admin/addTransportRequest";

	}
	
	
	
	
	@RequestMapping(value = "/admin/transportRequestAdded/{requestID}", method = RequestMethod.POST)
	public String addedTransportRequest(@Valid @ModelAttribute("TransportRequestFile") TransportRequestFileModel transportRequestFileModel,
			BindingResult result,@PathVariable("requestID") long requestID, final RedirectAttributes redirectAttributes, Model model, HttpServletRequest request, HttpSession session) throws IOException {
		TransportRequestFile transportRequestFile=prepareTransportRequestFileModel(transportRequestFileModel);

		try {
			String fieldName="";			
			String fileName="";
			String extension = ".zip";
			String version="";
			model.addAttribute("trMap", getTransportRequestDAO().getAllTransportRequestListPoc());
			File trFile=new File("");
			DiskFileItemFactory factory = new DiskFileItemFactory();
			factory.setSizeThreshold(0);
			ServletFileUpload upload = new ServletFileUpload(factory);
			upload.setFileSizeMax(-1);		
			upload.setSizeMax(-1);
			String toolName = (String) session.getAttribute("tool");
			List<FileItem> multipart = new ServletFileUpload(factory).parseRequest(request);

			for (FileItem item : multipart) {

				if (!item.isFormField()) {
					try {						
						trFile = new File(item.getName());
						fileName=trFile.getName();
						if (!fileName.equals("")) {
							String fileExtension = fileName.substring(fileName.length() - extension.length(),
									fileName.length());
							if (fileExtension.equalsIgnoreCase(".zip")) {
								Boolean existingVersion=getTransportRequestDAO().getTrExistingStatus(fileName);
								if(existingVersion)
								{
									model.addAttribute("MessageFail", "Transport Request with this version already exist, please upload a new version TR /Select from drop down, the existing one");
									return "poc/pocUploadTR";	
								}
								transportRequestFile.setTrFile(item.get());
								//transportRequestFile.setTrFileName(item.getName());
								transportRequestFile.setTrFileName(fileName);
								int maxid=	getTransportRequestService().checkMaxVersionCount();
								String TrVersion="TR"+maxid;	
								transportRequestFile.setTrVersion(TrVersion);
								
								
								getTransportRequestService().saveTRData(transportRequestFile);
								getRequestInventorydao().addRequestApprovedTRFileName(requestID,TrVersion);
								model.addAttribute("MessageSuccess", "Transport Request Added Succesfully");
								model.addAttribute("trUploadStatus",true);
								boolean ContentStatus = false;
								try {
									String contentStatus=getTransportRequestDAO().getContentAttachedStatus(requestID);
									if( contentStatus !=null && !contentStatus.equalsIgnoreCase("Empty")) ContentStatus = true;
								}catch(Exception ex) {
									ContentStatus = false;
								}
								if(ContentStatus) {
									final String systemStatus = getAutoHANA().getSystemStatus(requestID);
									if (StringUtils.equals(systemStatus, Hana_Profiler_Constant.INITIATED_STATUS)|| StringUtils.equals(systemStatus, Hana_Profiler_Constant.PENDING_STATUS)) {
										getRequestInventorydao().updatePOCSatus(requestID, Hana_Profiler_Constant.APPROVED_STATUS, getPrincipal(), "TR_DONE_UPLOAD_POC",toolName, 
												Hana_Profiler_Constant.REQ_SS_MAN_FL_UL_SUCC, Hana_Profiler_Constant.UPLOAD_TR_CR_SUCC);
									}
									return "redirect:/poc/pocDashBoard";
								}else {
									final String systemStatus = getAutoHANA().getSystemStatus(requestID);
									if (StringUtils.equals(systemStatus, Hana_Profiler_Constant.INITIATED_STATUS)|| StringUtils.equals(systemStatus, Hana_Profiler_Constant.PENDING_STATUS) ) {
										getRequestInventorydao().updatePOCSatus(requestID, Hana_Profiler_Constant.PENDING_STATUS, getPrincipal(), "Pending_POC",toolName, 
												Hana_Profiler_Constant.REQ_SS_MAN_FL_UL_FAIL, Hana_Profiler_Constant.UPLOAD_TR_CR_FAIL);
									}
									model.addAttribute("contentUploadStatus", ContentStatus);
									return "poc/pocUploadTR";
								}				
							}
							else
							{
								model.addAttribute("MessageFail", "Transport Request failed upload .zip format.");
								model.addAttribute("TransportRequest", new TransportRequest());
								model.addAttribute("trUploadStatus",false);
								return "poc/pocUploadTR";
							}
						}
					} catch (Exception ex) {
						logger.error("Error !!! " + ex);
					}
				}
				else if (item.isFormField()) {
					if ("version".equalsIgnoreCase(item.getFieldName())) {
						 version = item.getString();
						 getRequestInventorydao().addRequestApprovedTRFileName(requestID,version);
						 model.addAttribute("MessageSuccess", "Transport Request Added Succesfully");
						 model.addAttribute("trUploadStatus",true);
						 return "poc/pocUploadTR";
					}
				}
			}			
		}

		catch (final FileUploadException exception) {
			logger.error("Inside FileUploadException");
			redirectAttributes.addFlashAttribute("MessageFail", exception.getMessage());

		}

		catch (TransportRequestException exception) {

			logger.error("Inside TransportRequestException");
			redirectAttributes.addFlashAttribute("MessageFail", "Transport Request Already Exists");

		} catch (Exception exception) {
			logger.error("Inside exception " + exception);
			redirectAttributes.addFlashAttribute("MessageFail", exception.getMessage());

		}
	
		return "poc/pocUploadTR";

	}

	@InitBinder
	protected void initBinder(ServletRequestDataBinder binder) {
		binder.registerCustomEditor(byte[].class, new ByteArrayMultipartFileEditor());
	}

	@RequestMapping(value = "/poc/clientFilesProcessing/{requestID}", method = RequestMethod.POST)
	public String clientFilesProcessing(@PathVariable("requestID") long requestID, Model model,
			final RedirectAttributes redirectAttributes,HttpServletRequest request, HttpSession session) {
		String toolName = (String) session.getAttribute("tool");
		logger.info("User accessing the page" + getPrincipal());
		try {
			redirectAttributes.addFlashAttribute("message", clientFileProcessingBusinessLogicHana(requestID, request, toolName,session));
		} catch (Exception e) {
			logger.error("Error !!! " + e);
		}
		return "redirect:/poc/dashBoard";
	}

	@RequestMapping(value = "/poc/clientFinalOutput", method = RequestMethod.GET)
	public String finalOutput(@RequestParam("requestID") Long requestID, HttpServletRequest request, Model model) {
		model.addAttribute("requestID", requestID);
		return "poc/gridDisplay";
	}

	@RequestMapping(value = "/poc/downloadExcel", method = RequestMethod.GET)
	public ModelAndView downloadExcel(final Long requestID, HttpServletRequest request, HttpServletResponse response) {
		List<HanaProfile_Download> list = getDaoIntf().GetList(requestID, 0, 0);
		// return a view which will be resolved by an excel view resolver
		response.setHeader("Content-Disposition",
				"attachment; filename=\"HANA Profiler_Client Name_Source_Target.xls\"");
		return new ModelAndView("excelView", "list", list);
	}

	@RequestMapping(value = "/poc/assignRequest", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public Map<String, String> assignRequest(final String userName,
			@RequestParam(value = "requestId[]", required = false) final String[] requestIdArray) {
		final Map<String, String> finalMap = new HashMap<String, String>();
		if (StringUtils.isNotBlank(userName) && requestIdArray != null && requestIdArray.length > 0) {
			getPocLoginService().assignRequest(userName, requestIdArray);
			finalMap.put("success", "true");
			finalMap.put("message", "Requests are assigned successfully.");
		} else {
			finalMap.put("success", "false");
			if (StringUtils.isBlank(userName) && (requestIdArray == null || requestIdArray.length == 0)) {
				finalMap.put("message", "Please select UserName and Request");
			} else if (StringUtils.isBlank(userName)) {
				finalMap.put("message", "Please select UserName.");
			} else {
				finalMap.put("message", "Please select Request.");
			}
		}

		return finalMap;
	}

	@RequestMapping(value = "/client/openQueryForm", method = RequestMethod.GET)
	public String openQueryForm(@ModelAttribute("QueryForm") QueryFormModel queryForm) {
		return "client/queryForm";
	}
	
	 @RequestMapping(value = "/gotoDemoVideo/video", method = {RequestMethod.POST, RequestMethod.GET})
	 public String watchDemo(HttpServletRequest request, HttpSession session) {
		 return "client/watchDemo"; 
	 }
	 
	@RequestMapping(value = "/watchDemoVideo", method = RequestMethod.GET)
    public ResponseEntity<InputStreamResource> download(HttpSession session) throws IOException {
		
		String fileName = "";
		String Enviroment = (String) session.getAttribute("Enviroment");
		
		if (Enviroment.equals("")) {
			fileName="Video_Dev.properties";
		} else if (Enviroment.equals("")) {
			fileName="Video_Prd.properties";
		} else if (Enviroment.equals("")) {
			fileName="Video_Stage.properties";
		} else if (Enviroment.equals("localhost")) {
			fileName="Video_Local.properties";
     	}
		
        String vidLocation = HANAUtility.getPropertyValue(fileName, "vid.location");
        File file = new File(vidLocation);
        InputStreamResource vidRes = new InputStreamResource(new FileInputStream(file));
            
		ResponseEntity<InputStreamResource> response = ResponseEntity.status(HttpStatus.OK)
				.header("Accept-ranges", "bytes").contentLength(file.length())
				.contentType(MediaType.APPLICATION_OCTET_STREAM).body(vidRes);
  				  	 
		return response;	 
    }
	
	
	@RequestMapping(value = "/clientDataDisplay/{requestID}", method = RequestMethod.GET)
	public String requestIdDataDisplay(@PathVariable("requestID") final long requestId, final Model model,
			final RedirectAttributes redirectAttributes) {
		model.addAttribute("requestID", requestId);

		if (model.asMap() == null || model.asMap().get("SucessMsg") == null) {
			RequestInventory requestInventory = getClientRequestInventoryDAO().getRequestInventory(requestId);
			model.addAttribute("role", "admin");
			model.addAttribute("requestInventory", requestInventory);
			model.addAttribute("requestForm", getRequestDetails().getRequestObj(requestId));
		}
		return "clientDataDisplay";
	}
	
	@RequestMapping(value = "/clientDataDisplay/{requestID}/{userRole}", method = RequestMethod.GET)
	public String requestIdDataDisplay(@PathVariable("requestID") final long requestId, 
			@PathVariable("userRole") final String userRole, final Model model,
			final RedirectAttributes redirectAttributes) {
		try {
			RequestID_Validator_Utility.chckReqInvNull(reqIDValid.getRequestInv(requestId));
			if(userRole.equalsIgnoreCase("CLIENT")) {
        		RequestID_Validator_Utility.chckReqIdUser(reqIDValid.getCreator(reqIDValid.getRequestInv(requestId)), getPrincipal());
    			model.addAttribute("role", "client");
			}else if(userRole.equalsIgnoreCase("POC")) {
				RequestID_Validator_Utility.chckReqIdPOC(reqIDValid.getPOCName(reqIDValid.getRequestInv(requestId)), getPrincipal());
				model.addAttribute("role", "poc");
			}model.addAttribute("requestID", requestId);
			
			if (model.asMap() == null || model.asMap().get("SucessMsg") == null) {
				RequestInventory requestInventory = getClientRequestInventoryDAO().getRequestInventory(requestId);
				model.addAttribute("requestInventory", requestInventory);
				model.addAttribute("requestForm", getRequestDetails().getRequestObj(requestId));
			}
		} catch(ReqIDNotValidException ex) {
			model.addAttribute("errorMsg", ex.getMessage());
			return "errors";
		} catch(Exception e) {
			logger.error(e.getMessage());
		}
		return "clientDataDisplay";
	}

	@RequestMapping(value = "/client/queryFormSubmit", method = RequestMethod.POST)
	public String submitClientQuery(@Valid @ModelAttribute("QueryForm") QueryFormModel queryForm,BindingResult result,HttpServletRequest request,RedirectAttributes redirectAttribute,HttpSession session) {

		if (result.hasErrors()) {
			return "client/queryForm";
		} 			

		try{			
			String emailFrom=getEmailIDDao().getEmail(getPrincipal());
			Set<String> queryEmailTo = new HashSet<String>();	
			queryEmailTo.add("");

			Set<String> ackEmailTo = new HashSet<String>();	
			ackEmailTo.add(emailFrom);

			SendEmail queryEmail= new SendEmail();
			queryEmail.setMailFrom(emailFrom);
			queryEmail.setMailTo(queryEmailTo);
			queryEmail.setMailSubject("Query: "+queryForm.getQuerySubject());
			queryEmail.setMailBody(queryForm.getQueryContent());
			queryEmail.sendQueryEmail(queryEmail,request);		

			queryEmail= new SendEmail();

			queryEmail.setMailFrom("");
			queryEmail.setMailTo(ackEmailTo);
			queryEmail.setMailSubject("Query Acknowledgement");
			queryEmail.setMailBody("\n\nDear "+getPrincipal()+",\n\nThank you for contacting to us. We are looking into your query and will "
					+ "get back to you as soon as possible"
					+ "\n\nRegards,\nS/4HANA conversion Team ATCI" );
			queryEmail.emailSend(queryEmail,request,session);	

			queryEmailTo.clear();
			ackEmailTo.clear();

			redirectAttribute.addFlashAttribute("statusmessage", "Query Has Been Submitted Successfully ");
		}
		catch(Exception ex){		
			logger.error(ex.getMessage());
			redirectAttribute.addFlashAttribute("statusmessage", "Error Occured :"+ex.getMessage());
		}
		return "redirect:/client/openQueryForm";

	}
	/**
	 * This method enables the account for the passed userName and also 
	 * extends the validity of the account by 3 months(for Client) 
	 * and 1 year for Administrator or POC.
	 */
	@RequestMapping(value = "/admin/enableUserAccount")
	public String enableUserAccount (HttpServletRequest request, final RedirectAttributes redirectAttributes,HttpSession session)
	{
		try
		{
			logger.info("Inside enableUserAccount method");
			String userNamesConcat = request.getParameter("userName");
			String[] userNames = userNamesConcat.split(",");
			for (String userName : userNames)
			{
				logger.info("Inside enableUserAccount method - userName from list if fetched ");
				User user = getUserdata().getUser(userName);
				
				String email = user.getEmailId();
				logger.info("Inside enableUserAccount method - email for the user is generated " );
				//Commented below line for SSO - need to use email id
				//String userRole = getUserRoledao().getUserRoles(userName).get(0).getUserRole();				
				String userRole = getUserRoledao().getUserRoles(email).get(0).getUserRole();
				Calendar calendar = Calendar.getInstance();
				if(userRole.equalsIgnoreCase(Hana_Profiler_Constant.CLIENT_ROLE))
				{
					logger.info("Inside enableUserAccount method -- if loop for extending client validity");
					//Extend the CLient Account validity for 3 months.
					calendar.add(Calendar.MONTH, 3);
				}
				else
				{
					logger.info("Inside enableUserAccount method -- else loop for extending admin/poc validity");
					//Extend Admin account validity for 1 years. 
					calendar.add(Calendar.YEAR, 1);
				}
				Date validTill = new Date(calendar.getTimeInMillis());
				user.setValidTill(validTill);
				user.setEnabled(true);
				logger.info("Inside enableUserAccount method - calling pocSignedup()");
				getPocLoginService().pocSignedup(user, userRole);
				String emailBody = "\n\n Dear "+userName+". Your account has been activated.";
				sendEmailToUser(userName, request, emailBody,session);
			}
			redirectAttributes.addFlashAttribute("message", "User account activated.");
		}
		catch (Exception e) {
			logger.error(e.getMessage());
		}
		return "redirect:/admin/userDetails";
	}
	
	/**
	 * This method gets the list of all the users.
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/admin/userDetails", method=RequestMethod.GET)
	public String getUserDetails(Model model, HttpServletRequest request, @ModelAttribute("userList") ArrayList<UserModel> userListModel)
	{
		logger.info("Getting User Details");
		List<UserDetails> userDetailsList = new ArrayList<UserDetails>();
		List<UserDetails> userDetailsListinactive = new ArrayList<UserDetails>();
		 ArrayList<User> userList= new ArrayList<User>();
		 for(UserModel umodel:userListModel)
		 {
			 User user=prepareUserModel(umodel);
			 userList.add(user);
		 }
		if(userList.isEmpty())
		{
			userList = new ArrayList<>(getUserdata().getUserList());
		}
		
		/*CR-41: Creating Separate Tabs for Active and inactive user for user details page*/
		for (User user : userList) {
			String userName = user.getUserName();
			String emailId = user.getEmailId();
			logger.info(emailId);
			//Below line is commented out and added new for SSO - should be based on Email.
			//String userRole = getUserRoledao().getUserRoles(userName).get(0).getUserRole();
			String userRole = getUserRoledao().getUserRoles(emailId).get(0).getUserRole();
			logger.info("Role for Email Id:"+emailId+" is:--->"+userRole);
			SimpleDateFormat dt1 = new SimpleDateFormat("dd-MM-yyyy");
			String accountValidTill = dt1.format(user.getValidTill());
			boolean active = user.isEnabled();
			if(active)
			{
			userDetailsList.add(new UserDetails(userName, emailId, userRole, accountValidTill, active));
			}
			else
			{
				userDetailsListinactive.add(new UserDetails(userName, emailId, userRole, accountValidTill, active));
			}
		}
		model.addAttribute("userDetailsListinactive", userDetailsListinactive);
		model.addAttribute("userDetailsList", userDetailsList);
		model.addAttribute("userCountinactive", userDetailsListinactive.size());
		model.addAttribute("userCount", userDetailsList.size());
		return "admin/userDetails";

	}
	
	/**
	 * This method sends an email to the user after reactivation of user account.
	 * @param userName
	 * @param request
	 */
	private void sendEmailToUser(String userName, HttpServletRequest request, String emailBody,HttpSession session)
	{
		logger.info("Inside sendEmailForAccountActivationRequest method");
		String emailContext="https://"+request.getServerName()+":"+request.getServerPort();
		Set<String> emailData = new HashSet<String>();	
		Set<String> emailCc = new HashSet<String>();	
		SendEmail email= new SendEmail();	
		email.setMailFrom("");			
		emailData.add(getEmailIDDao().getEmail(userName));
		emailCc.add("");
		email.setMailTo(emailData);	
		email.setMailCC(emailCc);
		emailBody += " \n\nClick here to login: "
				+"\n<a href="+emailContext+"/hanaprofilerperformance/homepage"+">Login</a>"
				+ "\n\nRegards,\nS/4HANA conversion Team ATCI";
		email.setMailSubject("Account Information for User : "+userName);		
		
		logger.info("Email body is generated");
		email.setMailBody(emailBody);
		
		email.emailSend(email,request,session);
	}
	
	/**
	 * This method gets the list of all the users.
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/admin/searchUserDetails", method=RequestMethod.POST)
	public String searchUserDetails(HttpServletRequest request, final RedirectAttributes redirectAttributes)
	{
		String userName = request.getParameter("userName");
		
		if (userName.equals("ALL") ){
			return "redirect:/admin/userDetails";
			}
		
		if (!emailIsValid(userName)) {
			redirectAttributes.addFlashAttribute("emailIdEmptyErrorMessage", "Enter a valid format of Email Id");
			return "redirect:/admin/userDetails";
			}
		List<User> userList = new ArrayList<User>();
		logger.info("Inside searchUserDetails. Getting User Details for specific userName ");
		try
		{
			User user = getUserdata().getUser(userName);
			if(user == null)
			{
				redirectAttributes.addFlashAttribute("emailIdEmptyErrorMessage", "Please enter a valid User Name");
				
			}
			userList.add(user);
		}
		catch (Exception e) 
		{
			logger.error(e.getMessage());
		}
		redirectAttributes.addFlashAttribute("userList", userList);
		return "redirect:/admin/userDetails";
	}
	
	@RequestMapping(value = "/poc/downloadReviewChcklist", method = RequestMethod.GET)
	public String downloadReviewCheckListFile(Long requestID, Model model,
			HttpServletResponse response, final RedirectAttributes redirectAttributes, final HttpSession session)
			throws Exception {
		String fileNameKey = "'RC'";
		FileStore reviewChkLstFile = getS4ValidDao().getFileFromFileStoreTable(fileNameKey);

		byte[] fileBytes = reviewChkLstFile.getFileContent();
		String fileName = reviewChkLstFile.getFileName();
		try {

			String message = getFileDownload().downloadFile(fileBytes, response, fileName);
			if(null != message || message.isEmpty()) {
				redirectAttributes.addFlashAttribute("fileException", "Something went wrong while downloading"); 
			}
			return "redirect:/poc/pocDashBoard";
		} catch (IOException e) {
			logger.trace(e.getMessage());
			logger.error("downloadReviewCheckListFile :: ",e);
			return "redirect:/poc/pocDashBoard";

		}

	}
	
	
	
	
	
	

}
