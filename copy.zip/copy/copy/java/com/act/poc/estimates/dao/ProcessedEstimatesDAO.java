package com.act.poc.estimates.dao;

import java.util.List;
import java.util.Map;

import com.act.client.model.RequestForm;
import com.act.master.ProcessedEstimates;
import com.act.rfp.models.TADIRInventory;

public interface ProcessedEstimatesDAO {
	void updateEstimatesCountHANA(Long requestId) throws NoSuchMethodException, SecurityException;
	void updateEstimatesCountS4(Long requestId);
	Map<String, Integer> getMandatoryManualCounts(Long requestId);
	Map<String, Map<String, Integer>> getMandatoryManualAutoComplexityCounts(Long requestId);
	Map<String, Integer> getUsedMandatoryManualCounts(Long requestId);
	Map<String, Map<String, Integer>> getUsedMandatoryManualAutoComplexityCounts(Long requestId);
	List<ProcessedEstimates> getEstimatesReqMaster(Long requestId);
	void insertEstimatesData(ProcessedEstimates processedEst);
	public List<TADIRInventory> getRomEstimates(Long requestId);
	public List<RequestForm> getRequestForm(Long requestId);
}
