package com.act.poc.estimates.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.act.client.model.RequestForm;
import com.act.master.ProcessedEstimates;
import com.act.poc.estimates.dao.ProcessedEstimatesDAO;
import com.act.rfp.models.TADIRInventory;

@Service
public class ProcessedEstimatesServiceImpl implements ProcessedEstimatesService {
	private ProcessedEstimatesDAO processedEstimatesDao; 
	
	public ProcessedEstimatesDAO getProcessedEstimates() {
		return processedEstimatesDao;
	}
	
	@Autowired
	public void setProcessedEstimatesDAO(ProcessedEstimatesDAO processedEstimatesDao) {
		this.processedEstimatesDao = processedEstimatesDao;
	}
	
	@Override
	public void updateEstimatesS4(Long requestId) {
		getProcessedEstimates().updateEstimatesCountS4(requestId);
	}
	
	@Override
	public void updateEstimatesHANA(Long requestId) throws NoSuchMethodException, SecurityException  {
		getProcessedEstimates().updateEstimatesCountHANA(requestId);	
	}
	
	@Override
	public List<ProcessedEstimates> getEstimatesReqMaster(Long requestId) {
		return getProcessedEstimates().getEstimatesReqMaster(requestId);
	}
	@Override
	public List<TADIRInventory> getRomEstimates(Long requestId) {
		return getProcessedEstimates().getRomEstimates(requestId);
	}
	@Override
	public List<RequestForm> getRequestForm(Long requestId) {
		return getProcessedEstimates().getRequestForm(requestId);
	}
	
	@Override
	public void insertEstimatesData(ProcessedEstimates processedEst) {
		getProcessedEstimates().insertEstimatesData(processedEst);
	}
}
