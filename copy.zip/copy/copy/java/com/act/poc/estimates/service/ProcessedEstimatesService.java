package com.act.poc.estimates.service;

import java.util.List;

import com.act.client.model.RequestForm;
import com.act.master.ProcessedEstimates;
import com.act.rfp.models.TADIRInventory;

public interface ProcessedEstimatesService {
	void updateEstimatesHANA(Long requestId) throws NoSuchMethodException, SecurityException;
	void updateEstimatesS4(Long requestId);
	List<ProcessedEstimates> getEstimatesReqMaster(Long requestId);
	void insertEstimatesData(ProcessedEstimates processedEst);
	public List<TADIRInventory> getRomEstimates(Long requestId);
	public List<RequestForm> getRequestForm(Long requestId);
}
