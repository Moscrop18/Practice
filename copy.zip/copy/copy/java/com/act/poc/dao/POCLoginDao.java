package com.act.poc.dao;

import java.util.List;

import com.act.poc.model.User;

public interface POCLoginDao {

	User getUser(final String userName);

	void assignRequest(final String userName,final  List<Long> requestIdList);
}
