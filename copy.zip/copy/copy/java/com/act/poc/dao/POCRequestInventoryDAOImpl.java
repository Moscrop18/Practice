package com.act.poc.dao;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.act.client.model.RequestFormDetailsBean;
import com.act.client.model.RequestInventory;
import com.act.client.model.RequestInventoryHistory;
import com.act.constant.Hana_Profiler_Constant;
import com.act.exceptions.HibernateException;

@Transactional
public class POCRequestInventoryDAOImpl implements POCRequestInventoryDAO {

	final public Logger logger = LoggerFactory.getLogger(POCRequestInventoryDAOImpl.class);
	SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<RequestFormDetailsBean> getInitiatedRequests(final int limit, final int start, final String toolName, Long requestId) {
		try {
			final Session session = sessionFactory.getCurrentSession();

			final ProjectionList projection = Projections.projectionList();
			projection.add(Projections.property("requestForm.requestID"), "requestId");
			projection.add(Projections.property("requestForm.REQUEST_ID_UI"), "REQUEST_ID_UI");
			projection.add(Projections.property("requestInventory.requestShortdescription"), "shortDescription");
			projection.add(Projections.property("requestInventory.requestStatus"), "status");
			projection.add(Projections.property("requestInventory.comments"), "comments");
			projection.add(Projections.property("requestInventory.updatedDate"), "updatedDate");

			final Criteria criteria = session.createCriteria(RequestInventory.class, "requestInventory");
			criteria.createAlias("requestInventory.requestForm", "requestForm");
			criteria.add(Restrictions.eq("requestInventory.requestStatus", Hana_Profiler_Constant.INITIATED_STATUS));
			criteria.add(Restrictions.eq("toolName", toolName));
			criteria.setProjection(projection);
			criteria.addOrder(Order.asc("updatedDate"));
			criteria.setFirstResult(start);
			criteria.setMaxResults(limit);
			if (requestId != null) {
				criteria.add(Restrictions.eq("requestInventory.requestID", requestId));
			}
			criteria.setResultTransformer(Transformers.aliasToBean(RequestFormDetailsBean.class));
			return criteria.list();

		} catch (Exception e) {
			logger.error("Error POCRequestInventoryDAOImpl getInitiatedRequests" , e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	private void addRequestInventoryHistory(final RequestInventory requestInventory, final String userName) {
		try {
			Session session = sessionFactory.getCurrentSession();
			RequestInventoryHistory history = new RequestInventoryHistory();
			history.setRequestID(requestInventory.getRequestID());
			history.setREQUEST_ID_UI(requestInventory.getREQUEST_ID_UI());
			history.setRequestShortdescription(requestInventory.getRequestShortdescription());
			history.setRequestStatus(requestInventory.getRequestStatus());
			history.setTrAttachementName(requestInventory.getTrAttachementName());
			history.setDeletionTRAttachementName(requestInventory.getDeletionTRAttachementName());
			history.setComments(requestInventory.getComments());
			history.setTrDownloadStatus(requestInventory.getTrDownloadStatus());
			history.setCreatedDate(requestInventory.getCreatedDate());
			history.setUpdatedDate(requestInventory.getUpdatedDate());
			history.setCreatorUser(requestInventory.getCreatorUser());
			history.setUpdatedUser(requestInventory.getUpdateUser());
			history.setHistoryCreatorUser(userName);
			history.setHistoryCreatedDate(Calendar.getInstance().getTimeInMillis());
			session.save(history);

		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	 
	public void updateRequestIdUI(Long requestID,String requestIdUI,final String userName)
	{
		try {
			Session session = sessionFactory.getCurrentSession();
			RequestInventory obj = (RequestInventory) session.get(RequestInventory.class, requestID);
			addRequestInventoryHistory(obj, userName);
			obj.setREQUEST_ID_UI(requestIdUI);
			session.update(obj);
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void updatePOCSatus(Long requestID, String status, String userName, String pocStatus, String toolName, 
			String pocSubStatus, String comments) {
		try {
			Session session = sessionFactory.getCurrentSession();
			RequestInventory obj = (RequestInventory) session.get(RequestInventory.class, requestID);
			addRequestInventoryHistory(obj, userName);
			obj.setRequestStatus(status);
			obj.setUpdatedDate(new Date().getTime());
			if((obj.getJourneyCategory()).equalsIgnoreCase("FIAT_Only") || (obj.getJourneyCategory()).equalsIgnoreCase("SR_TwoPOC"))
			{
				obj.setPocFiatStatus(pocStatus);
			}
			if(!(obj.getJourneyCategory()).equalsIgnoreCase("FIAT_Only"))
			{
				obj.setPoc_status(pocStatus);
			}
			obj.setUpdateUser(userName);
			obj.setToolName(toolName);
			obj.setPocSubStatus(pocSubStatus);
			obj.setComments(comments);
			session.update(obj);
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void updatePOCFIATSatus(Long requestID,String userName,String pocFIATStatus,String toolName, 
			String pocSubStatus, String comments) {
		try {
			Session session = sessionFactory.getCurrentSession();
			RequestInventory obj = (RequestInventory) session.get(RequestInventory.class, requestID);
			addRequestInventoryHistory(obj, userName);
			
			obj.setUpdatedDate(new Date().getTime());
			obj.setPocFiatStatus(pocFIATStatus);
			obj.setUpdateUser(userName);
			obj.setToolName(toolName);
			obj.setPocSubStatus(pocSubStatus);
			obj.setComments(comments);
			session.update(obj);
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void updateSatus(Long requestID, String status, String userName, String comments,String toolName) {
		try {
			Session session = sessionFactory.getCurrentSession();
			RequestInventory obj = (RequestInventory) session.get(RequestInventory.class, requestID);
			addRequestInventoryHistory(obj, userName);
			obj.setRequestStatus(status);
			obj.setUpdatedDate(new Date().getTime());
			obj.setComments(comments);
			obj.setUpdateUser(userName);
			// Adding tool name:::: Monika
			obj.setToolName(toolName);
			session.update(obj);
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void updateRfpSatus(Long requestID, String status,String userName,String toolName, 
			String pocSubstatus, String comments) {
		try {
			Session session = sessionFactory.getCurrentSession();
			RequestInventory obj = (RequestInventory) session.get(RequestInventory.class, requestID);
			addRequestInventoryHistory(obj, userName);
			obj.setRfpStatus(status);
			obj.setUpdatedDate(new Date().getTime());
			obj.setPocSubStatus(pocSubstatus);
			obj.setToolName(toolName);
			obj.setComments(comments);
			session.update(obj);
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void updateSatusSubStatus(Long requestID, String status, String userName, String comments,String toolName, String SubStatus) {
		try {
			Session session = sessionFactory.getCurrentSession();
			RequestInventory obj = (RequestInventory) session.get(RequestInventory.class, requestID);
			addRequestInventoryHistory(obj, userName);
			obj.setRequestStatus(status);
			obj.setUpdatedDate(new Date().getTime());
			obj.setComments(comments);
			obj.setUpdateUser(userName);
			obj.setToolName(toolName);
			obj.setSUB_STATUS(SubStatus);
			session.update(obj);
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void addRequestApprovedTRFileName(Long requestID, String TRFilename) {
		try {
			Session session = sessionFactory.getCurrentSession();
			RequestInventory obj = (RequestInventory) session.get(RequestInventory.class, requestID);
			obj.setTrAttachementName(TRFilename);
			obj.setComments(Hana_Profiler_Constant.UPLOAD_TR_CR_SUCC);
			session.saveOrUpdate(obj);
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void addRequestDeletionTRFileName(Long requestID, String TRFilename) {
		try {
			Session session = sessionFactory.getCurrentSession();
			RequestInventory obj = (RequestInventory) session.get(RequestInventory.class, requestID);
			obj.setDeletionTRAttachementName(TRFilename);
			obj.setComments(Hana_Profiler_Constant.UPLOAD_TR_CR_SUCC);
			session.saveOrUpdate(obj);
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RequestInventory setComments(Long requestID, String message) {
		try {
			Session session = sessionFactory.getCurrentSession();
			RequestInventory obj = (RequestInventory) session.get(RequestInventory.class, requestID);
			obj.setComments(message);

			session.saveOrUpdate(obj);
			return obj;
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	public void setComments(final List<Long> requestIdList, final String comments) {
		try {
			logger.info("inside updating comments for added transport file");
			final Session session = sessionFactory.getCurrentSession();
			final Query query = session.createQuery(
					"update RequestInventory set comments = :comments where requestID in (:requestIdList)");
			query.setParameter("comments", comments);
			query.setParameterList("requestIdList", requestIdList);
			query.executeUpdate();
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}

	}

	@Override
	public Integer getTotalInitiatedRequests(final String toolName) {
		try {
			final Session session = sessionFactory.getCurrentSession();
			final Criteria criteria = session.createCriteria(RequestInventory.class);
			criteria.add(Restrictions.eq("requestStatus", Hana_Profiler_Constant.INITIATED_STATUS));
			criteria.add(Restrictions.eq("toolName", toolName));
			criteria.setProjection(Projections.rowCount());
			return ((Long) criteria.uniqueResult()).intValue();
		} catch (Exception e) {
			logger.error("Error getTotalInitiatedRequests" , e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	
	/**
	 * CR-12.0 This method returns the list of all Pending/In-Progress requests IG wise. 
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<Map<String,String>> getRequests(String requestStatus, final String toolName) 
	{
		try
		{
			logger.info("Inside getRequest method of POCRequestInventoryDAOImpl ");
			Map<String,String> resultMap = new HashMap<String, String>();
			List<Map<String,String>> requestList= new ArrayList<Map<String,String>>();
			final Session session = sessionFactory.getCurrentSession();
			List<Object[]> result = null;
			String clause = "";
			//This code is not used and hence it is not tested
			if(requestStatus.equals(Hana_Profiler_Constant.COMPLETED_STATUS)) {
				result = new ArrayList<>();
			}
			//If the request is in Pending status.
			else if(requestStatus.equals(Hana_Profiler_Constant.PENDING_STATUS)) {
				clause = "(SELECT requestID FROM RequestInventory WHERE requestStatus=:requestStatus and toolName=:toolName)";
			}
			//If the request is approved but is in waiting queue.
			else if(requestStatus.equals(Hana_Profiler_Constant.INQUEUE))
			{
				clause = "(SELECT requestID FROM QueueExecution WHERE toolName=:toolName)";
			}
			//If the request is in InProgress status.
			else {
				clause = "(SELECT requestID FROM CurrentExecution WHERE toolName=:toolName)";
			}
			String queryString = "SELECT industryGroup, Count(*) FROM RequestForm "
					+ "WHERE request_id in "
					+ clause
					+ "GROUP BY industryGroup";
			final Query query = session.createQuery(queryString);
			query.setParameter("requestStatus",requestStatus); 
			query.setParameter("toolName",toolName); 

			result = query.list();
			Iterator<Object[]> iterator = result.iterator();
			//Add the result into a list one by one.
			while(iterator.hasNext()) {
				Object[] temp= iterator.next();
				String ig = temp[0].toString();
				resultMap = new HashMap<String, String>();
				resultMap .put("ig", ig);
				String count = temp[1].toString();
				resultMap.put("count", count);
				requestList.add(resultMap);
			}
			return requestList;	
		}
		catch (Exception e) 
		{
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void updateSatusPOC(Long requestID, String userName, String toolName,String POCStatus, String POCComment, 
			String pocSubStatus, String comments) {
		try {
			Session session = sessionFactory.getCurrentSession();
			RequestInventory obj = (RequestInventory) session.get(RequestInventory.class, requestID);
			addRequestInventoryHistory(obj, userName);
			
			obj.setUpdatedDate(new Date().getTime());
			obj.setUpdateUser(userName);
			obj.setToolName(toolName);
			obj.setPoc_status(POCStatus);
			obj.setPoc_comments(POCComment);
			obj.setComments(comments);
			obj.setPocSubStatus(pocSubStatus);
			session.update(obj);
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void updatePOCStatusAndSubStatus(Long requestID, String userName, String POCStatus, String pocSubStatus) {
		try {
			Session session = sessionFactory.getCurrentSession();
			RequestInventory obj = (RequestInventory) session.get(RequestInventory.class, requestID);
			addRequestInventoryHistory(obj, userName);
			
			obj.setUpdatedDate(new Date().getTime());
			obj.setUpdateUser(userName);
			obj.setPoc_status(POCStatus);
			obj.setPocSubStatus(pocSubStatus);
			obj.setComments(Hana_Profiler_Constant.POC_DOWNLOAD_SUMM_SUCC);
			session.update(obj);	
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}	
	
	public void updateFinalFileDownloadStatus(Long requestID, String userName, boolean fileDnldSts) {
		try {
			Session session = sessionFactory.getCurrentSession();
			RequestInventory obj = (RequestInventory) session.get(RequestInventory.class, requestID);
			addRequestInventoryHistory(obj, userName);
			obj.setUpdatedDate(new Date().getTime());
			obj.setUpdateUser(userName);
			obj.setFinalFileDnldSts(fileDnldSts);
			session.update(obj);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	
	public void updateSaFileDownloadStatus(Integer requestID, String userName, boolean saDnldSts) {
		try {
			Session session = sessionFactory.getCurrentSession();
			RequestInventory obj = (RequestInventory) session.get(RequestInventory.class, Long.valueOf(requestID));
			addRequestInventoryHistory(obj, userName);
			obj.setUpdatedDate(new Date().getTime());
			obj.setUpdateUser(userName);
			obj.setSaFileDnldSts(saDnldSts);
			session.update(obj);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	
	public void updateBwFileDownloadStatus(Integer requestID, String userName, boolean bwDnldSts) {
		try {
			Session session = sessionFactory.getCurrentSession();
			RequestInventory obj = (RequestInventory) session.get(RequestInventory.class, Long.valueOf(requestID));
			addRequestInventoryHistory(obj, userName);
			obj.setUpdatedDate(new Date().getTime());
			obj.setUpdateUser(userName);
			obj.setBwFileDnldSts(bwDnldSts);
			session.update(obj);
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	@Override
	public RequestInventory getRequestFromRequestId(Long requestId) {
		RequestInventory obj = null;
		try {
		Session session = sessionFactory.getCurrentSession();
		 obj = (RequestInventory) session.get(RequestInventory.class, requestId);
		} catch (Exception e) {
			logger.error("Error in getRequestFromRequestId :: ",e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		return obj;
	}
	
	@Override
	public List<String> getSubReqIdUI(long requestId) {
		StringBuilder getHQL = new StringBuilder("SELECT ri.REQUEST_ID_UI "
				+ "FROM RequestInventory ri, RequestForm rf WHERE ri.requestID = rf.requestID "
				+ "AND ri.mainRequestId =:requestId AND ri.isSubRequest IS TRUE AND rf.sia IS TRUE");
		List<String> resultList = new ArrayList<>();
		Session session = null;
		
		try {
			session = sessionFactory.openSession();
			Query query = session.createQuery(getHQL.toString());
			query.setParameter("requestId", requestId);
			
			resultList = (List<String>) query.list();
		} catch (Exception e) {
			logger.error("Error while fetching SIA Sub Requests : ", e);
		} finally {
			if(session != null)
				session.close();
		}
		
		return resultList;
	}
}
