package com.act.poc.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.transaction.annotation.Transactional;

import com.act.constant.Hana_Profiler_Constant;
import com.act.exceptions.HibernateException;
import com.act.model.Skype;

@Transactional
public class SkypeDaoImpl implements SkypeDao {

	final Logger logger = LoggerFactory.getLogger(SkypeDaoImpl.class);
	SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {

		this.sessionFactory = sessionFactory;
	}

	@Override
	public List<Skype> getActiveIds() {
		try {
			Session session = sessionFactory.getCurrentSession();
			String hql = "select u from Skype u where u.status=(:status)";

			Query query = session.createQuery(hql);
			query.setParameter("status", true);
			return query.list();

		} catch (UsernameNotFoundException e) {
			throw e;
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

}
