package com.act.poc.dao;


import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.act.constant.Hana_Profiler_Constant;
import com.act.exceptions.HibernateException;
import com.act.model.RolesAccess;
import com.act.poc.model.User;
import com.act.poc.model.UserRole;

@Transactional
public class UserDAOImpl implements UserDAO {

	final Logger logger = LoggerFactory.getLogger(UserDAOImpl.class);
	SessionFactory sessionFactory;
	UserRole userRole;
	UserRoleDao userRoledao;

	public void setUserRoledao(UserRoleDao userRoledao) {
		this.userRoledao = userRoledao;
	}

	public void setUserRole(UserRole userRole) {
		this.userRole = userRole;

	}

	public void setSessionFactory(SessionFactory sessionFactory) {

		this.sessionFactory = sessionFactory;
	}

	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void save(User user,String role) {
		/**
		 * It requires two objects 
		 * @see com.act.poc.model.User
		 * and 
		 * @see java.lang.String
		 * It updates the @see com.act.poc.model.User and @see com.act.poc.model.UserRole
		 * if it exists else creates a new one.
		*/

		try {
			Session session = sessionFactory.getCurrentSession();
			user.setUserRoleValue(role);
			Set<UserRole> userRoles = user.getUserRole();
			UserRole userRole=null;
			if( userRoles!=null && userRoles.size()>0){
				userRole = userRoles.iterator().next();
			}
			
			if(userRole == null){
				userRole=new UserRole();
				userRole.setUser(user);
			}
			
			userRole.setUserRole(role);
			
			if(userRoles == null){
				userRoles = new HashSet<UserRole>();
			}
			
			userRoles.add(userRole);
			user.setUserRole(userRoles);
			
			RolesAccess roleAccess =user.getRolesAccess();
			if(roleAccess == null) {
				roleAccess = new RolesAccess();
				roleAccess.setEmailId(user.getEmailId());
				roleAccess.setUser(user);
				
				updateRoleAccess(user.getUserRoleValue(), roleAccess);
				Date updatedOn = new Date( (new java.util.Date()).getTime());
				roleAccess.setUpdatedOn(updatedOn);
				user.setRolesAccess(roleAccess);
			}
			
			session.saveOrUpdate(user);
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void saveUserData(User user, String role) {

		try {
			Session session = sessionFactory.getCurrentSession();
			user.setUserRoleValue(role);
			Set<UserRole> userRoles = user.getUserRole();
			UserRole userRole=null;
			if( userRoles!=null && userRoles.size()>0){
				userRole = userRoles.iterator().next();
			}
			
			if(userRole == null){
				userRole=new UserRole();
				userRole.setUser(user);
			}
			
			userRole.setUserRole(role);
			
			if(userRoles == null){
				userRoles = new HashSet<UserRole>();
			}
			
			userRoles.add(userRole);
			user.setUserRole(userRoles);
			
			
			RolesAccess roleAccess =user.getRolesAccess();
			if(roleAccess == null) {
				roleAccess = new RolesAccess();
				roleAccess.setEmailId(user.getEmailId());
				roleAccess.setUser(user);
				updateRoleAccess(user.getUserRoleValue(), roleAccess);
				Date updatedOn = new Date( (new java.util.Date()).getTime());
				roleAccess.setUpdatedOn(updatedOn);
				user.setRolesAccess(roleAccess);
			}
			
			session.saveOrUpdate(user);
			logger.info("Saving of user for the specified role");
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	private void updateRoleAccess(String uRole, RolesAccess roleAccess) {
		roleAccess.setR_admin(Boolean.FALSE);
		roleAccess.setR_client(Boolean.FALSE);
		roleAccess.setR_client(Boolean.FALSE);
		
		if(uRole.equals(Hana_Profiler_Constant.ADMIN_ROLE)) {
			roleAccess.setR_admin(Boolean.TRUE);
		}else if(uRole.equals(Hana_Profiler_Constant.POC_ROLE)) {
			roleAccess.setR_poc(Boolean.TRUE);
		}else {
			roleAccess.setR_client(Boolean.TRUE);
		}
	}
	
	
	
	
	public User getUser(String userName) {
		try {
			logger.info("Inside get User of userdaoimpl");
			Session session = sessionFactory.getCurrentSession();
			User user = (User) session.get(User.class, userName);
			if (user != null) {
				logger.info("getting name from user obj");
			}
			return user;
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	@Transactional
	public boolean deleteUser(String userName) {
		try {
			Session session = sessionFactory.getCurrentSession();

			User user = (User) session.get(User.class, userName);

			//CR-17: Update the account validity date as of today.
			user.setValidTill(new Date(Calendar.getInstance().getTimeInMillis()));
			user.setEnabled(false);
			session.update(user);
			return true;

			

		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}


	@SuppressWarnings("unchecked")
	public List<String> getUserNameList() {
		try{
		final Session session=sessionFactory.getCurrentSession();
		
		final Criteria criteria = session.createCriteria(User.class,"user");
		criteria.createAlias("user.userRole", "userRole");
		criteria.add(Restrictions.eq("user.enabled", true));
		//CR-21: Changed USER role to POC.
		criteria.add(Restrictions.in("userRole.userRole", new String[]{Hana_Profiler_Constant.POC_ROLE,Hana_Profiler_Constant.ADMIN_ROLE}));
		criteria.setProjection(Projections.distinct(Projections.property("user.userName")));
		criteria.addOrder(Order.asc("user.userName"));
		return criteria.list();
		}catch(Exception e)
		{
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	
	/**
	 * This method returns list of all the users.
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<User> getUserList()
	{
		List<User> userList = new ArrayList<User>();
		try
		{
			Session session=sessionFactory.getCurrentSession();
			String hql = "Select u from User u";
			Query query = session.createQuery(hql);
			userList = (List<User>)query.list();
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
		}
		return userList;
	}
}
