package com.act.poc.dao;

public interface FetchEmailID {
	public String getEmail(final String userName);
}
