package com.act.poc.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.act.constant.Hana_Profiler_Constant;
import com.act.exceptions.HibernateException;
import com.act.poc.controller.POCLoginController;
import com.act.poc.model.User;
import com.act.poc.model.UserRole;

@Transactional
public class UserRoleDaoImpl implements UserRoleDao {

	final Logger logger=LoggerFactory.getLogger(POCLoginController.class);
	public SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	
	@Transactional(propagation=Propagation.REQUIRED,readOnly=false)
	public UserRole updateUserRole(String userName,String userRole)
	{
		try{
			Session session=sessionFactory.getCurrentSession();
			logger.info("Inside update User role "+userName);
			UserRole userRoleobj = null;
			User user=(User)session.get(User.class, userName);
			if(user != null){
				//UserRole userRoleobj=getUserRoleData(userName);
				userRoleobj=user.getUserRole().iterator().next();
			}
			
			if(userRoleobj == null){
				userRoleobj=new UserRole();
				userRoleobj.setUser(user);
			}
			userRoleobj.setUserRole(userRole);
	        logger.info("Inserted the role of user "+userName +"as admin");
			return userRoleobj;
		}catch(Exception e)
		{
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	
	@Transactional(propagation=Propagation.REQUIRED,readOnly=false)
	public UserRole updateUserRoleData(String userName,String userRole)
	{
		try{
		Session session=sessionFactory.getCurrentSession();
		
		
		User user=(User)session.get(User.class, userName);
		UserRole userRoleobj=new UserRole();
		userRoleobj.setUser(user);
		userRoleobj.setUserRole(userRole);
		
        session.saveOrUpdate(userRoleobj);
        logger.info("Inserted the role of user "+userName +"as admin");
		return userRoleobj;
		}catch(Exception e)
		{
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	
	
	
	
	public List<UserRole> getUserRoles(String userName)
	{
		try{
		Session session=sessionFactory.getCurrentSession();
		User user=(User)session.get(User.class,userName);
		if(user == null)
		{
			throw new UsernameNotFoundException("Please enter valid POC username");
		}
		//logger.info(user.getUserName());
		String hql="select u from UserRole u where u.user=(:user)";
		
		Query query=session.createQuery(hql);
		query.setParameter("user",user);
		return query.list();
		
		}catch(UsernameNotFoundException e)
		{
			throw e;
		}catch(Exception e)
		{
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	
	public UserRole getUserRoleData(String userName)
	{
		try{
		Session session=sessionFactory.getCurrentSession();
		User user=(User)session.get(User.class,userName);
		if(user == null)
		{
			throw new UsernameNotFoundException("Please enter valid POC username");
		}
		
		String hql="select userRoleId from UserRole u where u.user=(:user)";
		
		Query query=session.createQuery(hql);
		query.setParameter("user",user);
		Integer id= (Integer)query.uniqueResult();
		
		try {
			logger.info("Inside get User of userdaoimpl" + userName);
			UserRole userRole = (UserRole) session.get(UserRole.class, id);
			if (userRole != null) {
				logger.info("getting Id from user role obj" + userRole.getUserRoleId());
			}
			return userRole;
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		
		}catch(UsernameNotFoundException e)
		{
			throw e;
		}catch(Exception e)
		{
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
}
