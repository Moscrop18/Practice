package com.act.poc.dao;

import java.util.*;

import com.act.client.model.RequestFormDetailsBean;
import com.act.client.model.RequestInventory;

public interface POCRequestInventoryDAO {

	public void updateSatus(Long requestID,String status,String userName,String comments,String toolName);
	public void updatePOCSatus(Long requestID,String status,String userName,String pocStatus,String toolName, String pocSubStatus, String comments);
	public void updatePOCFIATSatus(Long requestID,String userName,String pocFIATStatus,String toolName, String pocSubStatus, String comments);
	public void updateSatusSubStatus(Long requestID, String status, String userName, String comments,String toolName, String SubStatus);
	public void updateRequestIdUI(Long requestID,String requestIdUI, String userName);
	public void addRequestApprovedTRFileName(Long requestID,String TRFilename);
	public RequestInventory setComments(Long requestID,String message);
	public void setComments(final List<Long> requestIdList, final String comments);
	List<RequestFormDetailsBean> getInitiatedRequests(final int limit, final  int start, final String toolName, Long requestId);
	Integer getTotalInitiatedRequests(final String toolName);
	public void updateRfpSatus(Long requestID, String status, String userName, String toolName, String pocSubstatus, String comments);
	/**
	 * CR-12.0. This method will return the list of request based on the request status passed.
	 * @param limit
	 * @param start
	 * @param requestStatus eg- Pending, In Progress.
	 * @return
	 */
	public List<Map<String, String>> getRequests(String requestStatus, final String toolName);
	public void updateSatusPOC(Long requestID, String userName,String toolName,String POCStatus, String POCComment, String pocSubStatus, String comments);
	public void updatePOCStatusAndSubStatus(Long requestID, String userName, String POCStatus, String pocSubStatus);
	public void updateFinalFileDownloadStatus(Long requestID, String userName, boolean fileDnldSts);
	public void updateSaFileDownloadStatus(Integer requestID, String userName, boolean saDnldSts);
	public RequestInventory getRequestFromRequestId(Long requestId);
	public void addRequestDeletionTRFileName(Long requestID, String TRFilename);
	public void updateBwFileDownloadStatus(Integer requestID, String userName, boolean bwDnldSts);
	public List<String> getSubReqIdUI (long requestId);
 
}
