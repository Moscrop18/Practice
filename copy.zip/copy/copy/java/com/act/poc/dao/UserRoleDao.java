package com.act.poc.dao;

import com.act.poc.model.UserRole;
import java.util.*;

public interface UserRoleDao {

	public UserRole updateUserRole(String userName,String userRole);
	public List<UserRole> getUserRoles(String userName);
	
	public UserRole getUserRoleData(String userName);
}
