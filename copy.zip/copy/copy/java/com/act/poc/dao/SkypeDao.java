package com.act.poc.dao;

import java.util.List;

import com.act.model.Skype;

public interface SkypeDao {
	public List<Skype> getActiveIds();
}
