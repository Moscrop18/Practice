package com.act.poc.dao.factory;

import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.orm.hibernate4.HibernateTemplate;


public class AbstractHibernateDao {
	protected final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	
	@Autowired
	@Qualifier("mySessionFactory")
	private SessionFactory sessionFactory;
	
	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}

	public void setSessionFactory(final SessionFactory sessionFactory) 
    {
		
		this.sessionFactory=sessionFactory;
	}
	
	public SessionFactory getSessionFactory()
	{
		return this.sessionFactory;
	}
}
