package com.act.poc.model;

import java.sql.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

import com.act.model.RolesAccess;

@Entity
@Table(name = "USER")

public class User implements java.io.Serializable {

	/* @NotEmpty */
	@Size(min = 4, max = 70)
	private String userName;

	/* @NotEmpty */
	@Size(min = 4, max = 20)
	private String password;

	private String confirmPassword;
	private String currentPassword;
	private boolean enabled = true;
	private boolean newUserFlag;
	private boolean archiveFlag;

	@NotEmpty
	@Email
	private String emailId;

	private String projectName;

	private String clientName;

	private Boolean reset;

	private boolean reject = false;

	private String userRoleValue;

	private Set<UserRole> userRole = new HashSet<UserRole>(0);

	/* Added for CR 17. User account deactivated after three months for clients. */
	private Date createdOn;
	private Date validTill;

	@Column(name = "ACCOUNT_CREATED_ON", nullable = false)
	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	@Column(name = "ACCOUNT_VALID_TILL", nullable = false)
	public Date getValidTill() {
		return validTill;
	}

	public void setValidTill(Date validTill) {
		this.validTill = validTill;
	}

	@Column(name = "USER_NAME")
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	@Column(name = "PASSWORD", nullable = false)
	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Column(name = "ENABLED", nullable = false)
	public boolean isEnabled() {
		return this.enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	@Column(name = "NEW_USER_FLAG", nullable = false)
	public boolean isNewUserFlag() {
		return this.newUserFlag;
	}

	public void setNewUserFlag(boolean newUserFlag) {
		this.newUserFlag = newUserFlag;
	}

	@Column(name = "ARCHIVE_FLAG", nullable = false)
	public boolean isArchiveFlag() {
		return archiveFlag;
	}

	public void setArchiveFlag(boolean archiveFlag) {
		this.archiveFlag = archiveFlag;
	}

	@OneToMany(fetch = FetchType.EAGER, mappedBy = "user", cascade = CascadeType.ALL)
	public Set<UserRole> getUserRole() {
		return this.userRole;
	}

	public void setUserRole(Set<UserRole> userRole) {
		this.userRole = userRole;
	}

	@Transient
	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	@Id
	@Column(name = "EMAIL_ID", nullable = false)
	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	@Column(name = "PROJECT_NAME")
	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	@Column(name = "CLIENT_NAME")
	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public Set<POCRequestMapping> pocRequestMapping;

	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "user", orphanRemoval = true)
	// @OneToMany(fetch = FetchType.LAZY,mappedBy="user",cascade =
	// {CascadeType.PERSIST, CascadeType.MERGE, CascadeType.REFRESH})
	public Set<POCRequestMapping> getPocRequestMapping() {
		return pocRequestMapping;
	}

	public void setPocRequestMapping(Set<POCRequestMapping> pocRequestMapping) {
		this.pocRequestMapping = pocRequestMapping;
	}

	public User() {
	}

	public User(String username, String password, boolean enabled, boolean newUserFlag, boolean archiveFlag,
			Set<UserRole> userRole) {
		this.userName = username;
		this.password = password;
		this.enabled = enabled;
		this.newUserFlag = newUserFlag;
		this.archiveFlag = archiveFlag;
		this.userRole = userRole;
	}

	@Transient
	public String getCurrentPassword() {
		return currentPassword;
	}

	public void setCurrentPassword(String currentPassword) {
		this.currentPassword = currentPassword;
	}

	@Column(name = "IS_RESET", columnDefinition = "boolean default false")
	public Boolean getReset() {
		return reset;
	}

	public void setReset(Boolean reset) {
		this.reset = reset;
	}

	@Column(name = "IS_REJECT", nullable = false)
	public boolean getReject() {
		return reject;
	}

	public void setReject(boolean reject) {
		this.reject = reject;
	}

	@Column(name = "USER_ROLE")
	public String getUserRoleValue() {
		return userRoleValue;
	}

	public void setUserRoleValue(String userRoleValue) {
		this.userRoleValue = userRoleValue;
	}

	private RolesAccess rolesAccess;

	@OneToOne(fetch = FetchType.EAGER, mappedBy = "user", cascade = CascadeType.ALL)
	public RolesAccess getRolesAccess() {
		return rolesAccess;
	}

	public void setRolesAccess(RolesAccess rolesAccess) {
		this.rolesAccess = rolesAccess;
	}

}
