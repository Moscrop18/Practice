package com.act.poc.model;

import javax.persistence.*;
import com.act.client.model.RequestForm;


@Entity
@Table(name="POC_REQUEST_MAPPING")
public class POCRequestMapping implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	User user;
	RequestForm requestForm;
	int POCRequestMapping_ID;
	
	private String REQUEST_ID_UI;
	String userName;
	Long requestId;
	String emailId;
	String clientName;
	User clientUser;
	String toolName;
	
	
	@Column(name="EMAIL_ID")
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	@Id
	@GeneratedValue
	@Column(name="POC_REQUEST_MAPPING_ID")
	public int getPOCRequestMapping_ID()
	{
		return POCRequestMapping_ID;
	}
	public void setPOCRequestMapping_ID(int pOCRequestMapping_ID) {
		POCRequestMapping_ID = pOCRequestMapping_ID;
	}
	
	
	@Column(name="USER_NAME")
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	@Column(name="REQUEST_ID")
	public Long getRequestId() {
		return requestId;
	}
	public void setRequestId(Long requestId) {
		this.requestId = requestId;
	}
	
	@Column(name="CLIENT_NAME")
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	
	@ManyToOne()
	@JoinColumn(name="EMAIL_ID",insertable=false,updatable=false)
	public User getUser() {
		return user;
	}
	
	public void setUser(User user) {
		this.user = user;
	}
	
	@OneToOne()
	@JoinColumn(name="REQUEST_ID",insertable=false,updatable=false)
	public RequestForm getRequestForm() {
		return requestForm;
	}
	public void setRequestForm(RequestForm requestForm) {
		this.requestForm = requestForm;
	}
	
	@ManyToOne()
	@JoinColumn(name="CLIENT_NAME",insertable=false,updatable=false)
	public User getClientUser() {
		return clientUser;
	}
	public void setClientUser(User clientUser) {
		this.clientUser = clientUser;
	}
	
	@Column(name="TOOL_NAME")
	public String getToolName() {
		return toolName;
	}
	public void setToolName(String toolName) {
		this.toolName = toolName;
	}
	
	@Column(name="REQUEST_ID_UI")
	public String getREQUEST_ID_UI() {
		return REQUEST_ID_UI;
	}
	public void setREQUEST_ID_UI(String rEQUEST_ID_UI) {
		REQUEST_ID_UI = rEQUEST_ID_UI;
	}
	
	
	
}
