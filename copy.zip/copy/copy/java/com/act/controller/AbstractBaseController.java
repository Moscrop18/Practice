/*CR-No.    Desc     Date    Modified By
 * 
 * CR-9.0:- Manual upload for Estimator & assuptions -17/01/17 -monika.mishra
 * 
 * CR-12.0- Update Master table of request after completion. - 22/02/2017 - monika.mishra
 * 
 * CR-13.0:- New Output sheet implementation. -03/03/17 -monika.mishra
 * 
 * CR-48:- Consolidated both the tool so that they can executed separately -monika.mishra
 * 
 * CR-52.0 :- AIES Tool Integration-10/11/2017 -monika.mishra
 * 
 *  *Defect: SendEmail msg should be correct. Also, change requestId to requestIdUID -28/02/2019 -himani.malhotra
 *  
 *  DEF043: Remove code related to USEREXIT -28/02/2019 -himani.malhotra
 *  
 *  DEF075: Impacted IDOC New Requirements -17/05/2019 -himani.malhotra
 * */

package com.act.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hibernate.SessionFactory;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.act.Aadt.models.ACNIPZVERComp;
import com.act.Aadt.models.AuctFinalOutput;
import com.act.Aadt.models.ImpactedCloneAnalysis;
import com.act.Aadt.models.OSMigrationFinal;
import com.act.S4.dao.DisplayGraphS4DAO;
import com.act.S4.dao.PopulatingS4FinalOutputInterface;
import com.act.S4.dao.S4ValidationDAO;
import com.act.S4.models.S4HanaProfiler;
import com.act.S4.models.S4InventoryList;
import com.act.S4.models.S4SimplificationDatabase;
import com.act.Scripts.model.ImpactedScripts;
import com.act.UI5.models.UI5FinalOutput;
import com.act.UI5.models.UI5GraphCounts;
import com.act.UI5.models.UI5HighLevelReport;
import com.act.UI5.models.UI5InputExtract;
import com.act.admin.dao.AdminRequestMappingDAO;
import com.act.admin.dao.RolesAccessDAO;
import com.act.admin.service.AdminDashBoard;
import com.act.admin.service.AdminSimplificationService;
import com.act.bw.dao.BwCleanUpDAOImpl;
import com.act.client.dao.ExtensibilityDao;
import com.act.client.dao.RequestFormDAO;
import com.act.client.dao.RequestInventoryDAO;
import com.act.client.model.RequestForm;
import com.act.client.service.ExtensionService;
import com.act.client.service.RequestFormValidation;
import com.act.common.dao.NotificationDao;
import com.act.constant.Hana_Profiler_Constant;
import com.act.constant.ST03HanaConstant;
import com.act.displaygraph.dao.DisplayGraphDao;
import com.act.displaygrid.dao.PopulatingFinalOutputInterface;
import com.act.displaygrid.model.DBConfig;
import com.act.displaygrid.model.HanaAssumption;
import com.act.displaygrid.model.HanaEstimator;
import com.act.displaygrid.model.HanaProfile;
import com.act.drools.helper.DroolsHelper;
import com.act.exceptions.RequestNotValidException;
import com.act.exceptions.ResetPasswordException;
import com.act.exceptions.ST03DataAnalysisException;
import com.act.fileprocesing.dao.FioriProcessingDAO;
import com.act.fileprocesing.dao.FioriProcessingNewDAO;
import com.act.fileprocesing.dao.OdataFioriProcessDao;
import com.act.fileprocessing.AutomateHANA;
import com.act.fileprocessing.GenerateHANAFinalSheet;
import com.act.fileprocessing.ST03DataAnalysis;
import com.act.fileprocessing.VerifyOutputSheet;
import com.act.fileprocessing.model.CurrentExecution;
import com.act.fileprocessing.model.MetaData;
import com.act.fileprocessing.model.UsageAnalysis;
import com.act.fiori.models.CustomReportOutput;
import com.act.fiori.models.OdataFioriApps;
import com.act.master.ExtensionScope;
import com.act.master.ProcessedRequestDetail;
import com.act.model.DRL.CodeAssessmentPayLoad;
import com.act.osmigration.service.OSMigrationService;
import com.act.poc.dao.FetchEmailID;
import com.act.poc.dao.POCRequestInventoryDAO;
import com.act.poc.dao.POCRequestMappingDAO;
import com.act.poc.dao.SkypeDao;
import com.act.poc.dao.UserDAO;
import com.act.poc.dao.UserRoleDao;
import com.act.poc.service.AdminServices;
import com.act.poc.service.DashBoard;
import com.act.poc.service.POCLoginService;
import com.act.reader.xlsx.St03ReaderXlsx;
import com.act.report.ReportDao;
import com.act.rfp.models.TADIRInventory;
import com.act.securityAnalyser.service.SecurityAnalyserService;
import com.act.service.FileDownload;
import com.act.smodilog.model.SmodilogFunction;
import com.act.staticinfo.dao.RequestFormFileDAO;
import com.act.staticinfo.dao.TransportRequestDAO;
import com.act.statictables.model.TransportRequest;
import com.act.statictables.service.TransportRequestServiceImpl;
import com.act.statictables.service.TransportRequestValidation;
import com.act.testingscope.model.ExtractedDatapojo;
import com.act.testingscope.model.Testingscopepojo;
import com.act.testingscope.service.TestingScopeService;
import com.act.utility.AppGenUtility;
import com.act.utility.FileUtility;
import com.act.utility.HANAUtility;
import com.act.utility.SendEmail;
import com.act.utility.odatafiori.AppsType;
import com.act.utility.odatafiori.TCodeStandardizationService;
import com.act.validator.FileUploadValidator;
import com.act.validator.ProcessingFileUploadValidator;
import com.act.validator.SignupFormValidation;
import com.act.validator.TransportFileUploadValidator;
import com.sap.conn.jco.JCoException;

/**
 * Common class for all controller classes. Do not autowired any dependent class
 * in controller class. And add common methods of all controller.
 *
 */
public class AbstractBaseController {

	protected final static Logger logger = LoggerFactory.getLogger(AbstractBaseController.class);

	private UserDAO userdata;
	private DashBoard dashBoard;
	private RequestForm requestForm;
	protected RequestFormDAO requestDetails;
	private POCRequestMappingDAO pocRequestMappingdao;
	private POCRequestInventoryDAO requestInventorydao;
	private SignupFormValidation signupFormValidation;
	private TransportRequestDAO transportRequestDAO;
	private AdminServices adminServices;
	private UserRoleDao userRoledao;
	private TransportRequest transportRequest;
	private FileDownload fileDownload;
	private MessageSourceAccessor messageAccessor;
	private POCLoginService pocLoginService;
	private TransportFileUploadValidator trFileUploadValidator;
	private AutomateHANA autoHANA;
	private ST03DataAnalysis st03DataAnalysis;
	private GenerateHANAFinalSheet generateHANAFinalSheet;
	private PopulatingFinalOutputInterface daoIntf;
	private FileUploadValidator fileUploadValidator;
	private RequestFormValidation requestFormValidation;
	private TransportRequestValidation transportRequestValidation;
	private TransportRequestServiceImpl transportRequestService;
	private RequestInventoryDAO clientRequestInventoryDAO;
	// private ChangePasswordService changePasswordService;
	private DisplayGraphDao graphDao;
	private VerifyOutputSheet verifyOutput;
	private ProcessingFileUploadValidator processingFileUploadValidator;
	// private ChangePasswordDao changePasswordDao;
	public static HttpSession session;
	private UI5GraphCounts uI5GraphCount;

	@Autowired
	private SessionFactory sessionFactory;

	private RequestFormFileDAO requestFormFileData;

	private ReportDao reportDao;
	private PopulatingS4FinalOutputInterface s4daoIntf;
	private OdataFioriProcessDao odataFioriProcessDao;
	private FioriProcessingDAO fioriProcessingDao;
	private FioriProcessingNewDAO fioriProcessingNewDao;

	private CodeAssessmentPayLoad codeAssessmentPayLoad;

	private SkypeDao skypeDao;
	private NotificationDao notificationDao;

	private AdminDashBoard adminDashBoard;
	private AdminRequestMappingDAO adminRequestMappingdao;

	private RolesAccessDAO rolesAccessDAO;

	List<UI5FinalOutput> finalUI5ReportList = new ArrayList<UI5FinalOutput>();
	UI5HighLevelReport highlvlReport;
	static List<UI5HighLevelReport> listOfHighLevelReport;
	private S4ValidationDAO s4ValidDao;
	private AdminSimplificationService adminSimplificationService;
	private SecurityAnalyserService secAnalyseService;
	@Autowired
	private BwCleanUpDAOImpl bwCleanUp;

	private TestingScopeService testingScopeService;

	public TestingScopeService getTestingScopeService() {
		return testingScopeService;
	}

	@Autowired
	public void setTestingScopeService(TestingScopeService testingScopeService) {
		this.testingScopeService = testingScopeService;
	}

	public SecurityAnalyserService getSecAnalyseService() {
		return secAnalyseService;
	}

	@Autowired
	public void setSecAnalyseService(SecurityAnalyserService secAnalyseService) {
		this.secAnalyseService = secAnalyseService;
	}

	private TCodeStandardizationService tcodeStandardizationService;

	public TCodeStandardizationService getTcodeStandardizationService() {
		return tcodeStandardizationService;
	}

	@Autowired
	public void setTcodeStandardizationService(TCodeStandardizationService tcodeStandardizationService) {
		this.tcodeStandardizationService = tcodeStandardizationService;
	}

	private ExtensionService extensionService;

	public ExtensionService getExtensionService() {
		return extensionService;
	}

	@Autowired
	public void setExtensionService(ExtensionService extensionService) {
		this.extensionService = extensionService;
	}

	private ExtensibilityDao extensibilityDao;

	public ExtensibilityDao getExtensibilityDao() {
		return extensibilityDao;
	}

	@Autowired
	public void setExtensibilityDao(ExtensibilityDao extensibilityDao) {
		this.extensibilityDao = extensibilityDao;
	}

	public static HttpSession getSession() {
		return session;
	}

	public static void setSession(HttpSession session) {
		AbstractBaseController.session = session;
	}

	private Object hibernateTemplate;

	private String oldVersion;

	private String newVersion;

	private FetchEmailID fetchEmailID;

	@Autowired
	public void setVerifyOutput(final VerifyOutputSheet verifyOutput) {
		this.verifyOutput = verifyOutput;
	}

	@Autowired
	public void setClientRequestInventoryDAO(RequestInventoryDAO clientRequestInventoryDAO) {
		this.clientRequestInventoryDAO = clientRequestInventoryDAO;
	}

	@Autowired
	public void setTransportRequestService(TransportRequestServiceImpl transportRequestService) {
		this.transportRequestService = transportRequestService;
	}

	@Autowired
	public void setGenerateHANAFinalSheet(final GenerateHANAFinalSheet generateHANAFinalSheet) {
		this.generateHANAFinalSheet = generateHANAFinalSheet;
	}

	@Autowired
	public void setSt03DataAnalysis(final ST03DataAnalysis st03DataAnalysis) {
		this.st03DataAnalysis = st03DataAnalysis;
	}

	@Autowired
	public void setAutoHANA(final AutomateHANA autoHANA) {
		this.autoHANA = autoHANA;
	}

	@Autowired
	public void setDaoIntf(final PopulatingFinalOutputInterface daoIntf) {
		this.daoIntf = daoIntf;
	}

	@Autowired
	public void setMessageAccessor(final MessageSourceAccessor messageAccessor) {
		this.messageAccessor = messageAccessor;
	}

	@Autowired
	public void setFileDownload(final FileDownload fileDownload) {
		this.fileDownload = fileDownload;
	}

	@Autowired
	public void setTransportRequest(final TransportRequest transportRequest) {
		this.transportRequest = transportRequest;
	}

	@Autowired
	public void setUserRoledao(final UserRoleDao userRoledao) {
		this.userRoledao = userRoledao;
	}

	@Autowired
	public void setAdminServices(final AdminServices adminServices) {
		this.adminServices = adminServices;
	}

	@Autowired
	public void setTransportRequestDAO(final TransportRequestDAO transportRequestDAO) {
		this.transportRequestDAO = transportRequestDAO;
	}

	@Autowired
	public void setSignupFormValidation(final SignupFormValidation signupFormValidation) {
		this.signupFormValidation = signupFormValidation;
	}

	@Autowired
	public void setPocRequestMappingdao(final POCRequestMappingDAO pocRequestMappingdao) {
		this.pocRequestMappingdao = pocRequestMappingdao;
	}

	@Autowired
	public void setRequestInventoryUpdate(final POCRequestInventoryDAO requestInventorydao) {
		this.requestInventorydao = requestInventorydao;
	}

	@Autowired
	public void setDashBoard(final DashBoard dashBoard) {
		this.dashBoard = dashBoard;
	}

	@Autowired
	public void setAdminDashBoard(AdminDashBoard adminDashBoard) {
		this.adminDashBoard = adminDashBoard;
	}

	@Autowired
	public void setAdminRequestMappingdao(AdminRequestMappingDAO adminRequestMappingdao) {
		this.adminRequestMappingdao = adminRequestMappingdao;
	}

	@Autowired
	public void setUserdata(final UserDAO userdata) {
		this.userdata = userdata;
	}

	@Autowired
	public void setRequestForm(final RequestForm requestForm) {
		this.requestForm = requestForm;
	}

	@Autowired

	public void setRequestDetails(final RequestFormDAO requestDetails) {
		this.requestDetails = requestDetails;
	}

	@Autowired
	@Qualifier(value = "pocLoginService")
	public void setPocLoginSevice(final POCLoginService pocLoginService) {
		this.pocLoginService = pocLoginService;
	}

	@Autowired
	public void setTrFileUploadValidator(final TransportFileUploadValidator trFileUploadValidator) {
		this.trFileUploadValidator = trFileUploadValidator;
	}

	@Autowired
	public void setRequestFormValidation(final RequestFormValidation requestFormValidation) {
		this.requestFormValidation = requestFormValidation;
	}

	@Autowired
	public void setTransportRequestValidation(final TransportRequestValidation transportRequestValidation) {
		this.transportRequestValidation = transportRequestValidation;
	}

	@Autowired
	public void setGraphDao(final DisplayGraphDao graphDao) {
		this.graphDao = graphDao;
	}

	public OdataFioriProcessDao getOdataFioriProcessDao() {
		return odataFioriProcessDao;
	}

	@Autowired
	public void setOdataFioriProcessDao(OdataFioriProcessDao odataFioriProcessDao) {
		this.odataFioriProcessDao = odataFioriProcessDao;
	}

	public FioriProcessingNewDAO getFioriProcessingNewDao() {
		return fioriProcessingNewDao;
	}

	@Autowired
	public void setFioriProcessingNewDao(FioriProcessingNewDAO fioriProcessingNewDao) {
		this.fioriProcessingNewDao = fioriProcessingNewDao;
	}

	public FioriProcessingDAO getFioriProcessingDao() {
		return fioriProcessingDao;
	}

	@Autowired
	public void setFioriProcessingDao(FioriProcessingDAO fioriProcessingDao) {
		this.fioriProcessingDao = fioriProcessingDao;
	}

	@Autowired
	public void setSkypeDao(SkypeDao skypeDao) {
		this.skypeDao = skypeDao;
	}

	public SkypeDao getSkypeDao() {
		return skypeDao;
	}

	public RolesAccessDAO getRolesAccessDAO() {
		return rolesAccessDAO;
	}

	@Autowired
	public void setRolesAccessDAO(RolesAccessDAO rolesAccessDAO) {
		this.rolesAccessDAO = rolesAccessDAO;
	}

	@Autowired
	public void setAdminSimplificationService(AdminSimplificationService adminSimplificationService) {
		this.adminSimplificationService = adminSimplificationService;
	}

	public AdminSimplificationService getAdminSimplificationService() {
		return adminSimplificationService;
	}

	@Autowired
	public void setS4ValidDao(S4ValidationDAO s4ValidDao) {
		this.s4ValidDao = s4ValidDao;
	}

	public S4ValidationDAO getS4ValidDao() {
		return s4ValidDao;
	}

	@Autowired
	public void setNotificationDao(NotificationDao notificationDao) {
		this.notificationDao = notificationDao;
	}

	public NotificationDao getNotificationDao() {
		return notificationDao;
	}

	public TransportRequestValidation getTransportRequestValidation() {
		return transportRequestValidation;
	}

	public RequestInventoryDAO getClientRequestInventoryDAO() {
		return clientRequestInventoryDAO;
	}

	public RequestFormValidation getRequestFormValidation() {
		return requestFormValidation;
	}

	public TransportRequestServiceImpl getTransportRequestService() {
		return transportRequestService;
	}

	public POCRequestInventoryDAO getRequestInventorydao() {
		return requestInventorydao;
	}

	public void setRequestInventorydao(final POCRequestInventoryDAO requestInventorydao) {
		this.requestInventorydao = requestInventorydao;
	}

	public POCLoginService getPocLoginService() {
		return pocLoginService;
	}

	public void setPocLoginService(final POCLoginService pocLoginService) {
		this.pocLoginService = pocLoginService;
	}

	public UserDAO getUserdata() {
		return userdata;
	}

	public DashBoard getDashBoard() {
		return dashBoard;
	}

	public AdminDashBoard getAdminDashBoard() {
		return adminDashBoard;
	}

	public AdminRequestMappingDAO getAdminRequestMappingdao() {
		return adminRequestMappingdao;
	}

	public RequestForm getRequestForm() {
		return requestForm;
	}

	public RequestFormDAO getRequestDetails() {
		return requestDetails;
	}

	// FIAT FILE DOWNLOAD

	@Autowired
	public void setRequestFormFileData(RequestFormFileDAO requestFormFileData) {
		this.requestFormFileData = requestFormFileData;
	}

	public RequestFormFileDAO getRequestFormFileData() {
		return requestFormFileData;
	}

	public POCRequestMappingDAO getPocRequestMappingdao() {
		return pocRequestMappingdao;
	}

	public SignupFormValidation getSignupFormValidation() {
		return signupFormValidation;
	}

	public TransportRequestDAO getTransportRequestDAO() {
		return transportRequestDAO;
	}

	public AdminServices getAdminServices() {
		return adminServices;
	}

	public UserRoleDao getUserRoledao() {
		return userRoledao;
	}

	public TransportRequest getTransportRequest() {
		return transportRequest;
	}

	public FileDownload getFileDownload() {
		return fileDownload;
	}

	public MessageSourceAccessor getMessageAccessor() {
		return messageAccessor;
	}

	public TransportFileUploadValidator getTrFileUploadValidator() {
		return trFileUploadValidator;
	}

	public AutomateHANA getAutoHANA() {
		return autoHANA;
	}

	public ST03DataAnalysis getSt03DataAnalysis() {
		return st03DataAnalysis;
	}

	public GenerateHANAFinalSheet getGenerateHANAFinalSheet() {
		return generateHANAFinalSheet;
	}

	public PopulatingFinalOutputInterface getDaoIntf() {
		return daoIntf;
	}

	@Autowired
	public void setFileUploadValidator(final FileUploadValidator fileUploadValidator) {
		this.fileUploadValidator = fileUploadValidator;
	}

	public FileUploadValidator getFileUploadValidator() {
		return fileUploadValidator;
	}

	public PopulatingS4FinalOutputInterface getS4DaoIntf() {
		return s4daoIntf;
	}

	@Autowired
	public void setDaoIntf(final PopulatingS4FinalOutputInterface s4daoIntf) {
		this.s4daoIntf = s4daoIntf;
	}

	public CodeAssessmentPayLoad getCodeAssessmentPayLoad() {
		return codeAssessmentPayLoad;
	}

	public void setCodeAssessmentPayLoad(CodeAssessmentPayLoad codeAssessmentPayLoad) {
		this.codeAssessmentPayLoad = codeAssessmentPayLoad;
	}

	private OSMigrationService osMigrationService;

	public OSMigrationService getOsMigrationService() {
		return osMigrationService;
	}

	public void setOsMigrationService(OSMigrationService osMigrationService) {
		this.osMigrationService = osMigrationService;
	}

	@Autowired
	public void setOsMigrationProcessing(OSMigrationService osMigrationService) {
		this.osMigrationService = osMigrationService;
	}

	@Autowired
	private St03ReaderXlsx sto3ReaderXlsx;

	protected String getPrincipal() {
		String userName = null;
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

		if (principal instanceof UserDetails) {
			userName = ((UserDetails) principal).getUsername();
		} else {
			userName = principal.toString();
		}
		return userName;
	}

	protected String inputFileRead(final long requestId, HttpServletRequest request, final String toolName,
			HttpSession session) throws Exception {
		String comments = "";
		String status = "";
		HANAUtility.changeRequestProgressValue(requestId, 2, "Reading is in progress.");
		String systemStatus = getAutoHANA().getSystemStatus(requestId);
		String businessStatus = HANAUtility.getBusinessStatus(systemStatus);
		if (StringUtils.equals(businessStatus, Hana_Profiler_Constant.IDVSUCESS_STATUS)
				|| StringUtils.equals(businessStatus, Hana_Profiler_Constant.NOT_COMPLETED_STATUS)) {
			status = Hana_Profiler_Constant.IDVSUCESS_STATUS;
			comments = Hana_Profiler_Constant.IDVSUCCESS_STATUS_COMMENT;
			try {
				logger.info("Inside input File read ");

				long startTime = 0, endTime = 0, totalTime = 0;
				final RequestForm requestForm = getRequestDetails().getRequestObj(requestId);
				boolean scopeHana = requestForm.getSOH();
				boolean scopeS4 = requestForm.getS4Technical();
				boolean scopeFIAT = requestForm.getS4Functional();
				boolean scopeUI5 = requestForm.getUI5();
				boolean scopeFiori = requestForm.getFiori();
				boolean scopeAUCT = requestForm.getUPGRADE();
				boolean scopeOSMigration = requestForm.getOsMig();
				final String rootPath = HANAUtility.getFilePath(requestForm.getClientName(), requestId);

				boolean st03Status = false;

				getAutoHANA().setRootFilePath(rootPath);
				getSt03DataAnalysis().setRootFolderPath(rootPath);
				// clear data if st03 failed
				if (Hana_Profiler_Constant.IDVSUCESS_STATUS.equalsIgnoreCase(systemStatus)
						|| Hana_Profiler_Constant.ST03FAILED_STATUS.equalsIgnoreCase(systemStatus)) {

					getAutoHANA().clearFioriTable(requestId);
					getAutoHANA().clearACNIPZERTable(requestId);
					// clearing all data from tables for particular request_id +
					// removing data from
					// request Master as well for that id

					if (scopeHana || scopeS4 || scopeAUCT || scopeUI5 || scopeOSMigration || requestForm.getBwTech()) {
						getAutoHANA().clearAllTables(requestId);
						getAutoHANA().clearDownloadTable(requestId);
						getAutoHANA().clearCVITDownloadTables(requestId);
						getAutoHANA().clearRequestMasterTable(requestId);
						getAutoHANA().clearUI5Tables(requestId);
						getAutoHANA().clearTestingScopeTables(requestId);
						getAutoHANA().clearBwTechInventoryTables(requestId);
						getAutoHANA().clearIRPAReqMasterTables(requestId);
						getAutoHANA().clearIRPATScopeDownloadTable(requestId);
						getAutoHANA().clearIRPATScopeIntermediateTable(requestId, session);

						// Impacted Background Job
						try {
							getAutoHANA().clearImpactedBackgroundJobTable(requestId);
						} catch (Exception e) {
							logger.error("Error while clearing Impacted Background Table", e);
						}
						// Impacted Scripts
						try {
							getAutoHANA().clearImpactedScriptsTable(requestId);
						} catch (Exception e) {
							logger.error("Error while clearing Impacted Scripts Table ", e);
						}
					}

					if (scopeFiori) {
						getAutoHANA().clearFioriTables(requestId);
						getAutoHANA().clearFioriRequestMasterTable(requestId);
					}

					if (requestForm.getSia()) {
						getAutoHANA().clearSIATables(requestId);
					}
					if (requestForm.getBwUsage()) {
						getAutoHANA().clearBwInputTables(requestId);
					}

					if (requestForm.getEXT()) {
						getAutoHANA().clearEXTTables(requestId);
					}

					if (Hana_Profiler_Constant.ST03FAILED_STATUS.equalsIgnoreCase(systemStatus)) {
						status = Hana_Profiler_Constant.ST03FAILED_STATUS;
						comments = Hana_Profiler_Constant.ST03FAILED_STATUS_COMMENT;

					}
					startTime = System.currentTimeMillis();

					st03Status = getSt03DataAnalysis().readInputAadtFiles(requestId, toolName, session, requestForm);
					endTime = System.currentTimeMillis();
					totalTime = endTime - startTime;
					logger.info("Total Time in reading input files =" + totalTime);
					if (st03Status) {
						status = Hana_Profiler_Constant.ST03SUCCESS_STATUS;
						comments = Hana_Profiler_Constant.ST03SUCCESS_STATUS_COMMENT;

					} else {
						status = Hana_Profiler_Constant.ST03FAILED_STATUS;
						comments = "HANA:" + Hana_Profiler_Constant.ST03FAILED_STATUS_COMMENT;
						throw new Exception("Exception in reading input files");
					}
				}
			} catch (ST03DataAnalysisException e) {
				status = Hana_Profiler_Constant.ST03FAILED_STATUS;
				comments = e.getMessage();
				HANAUtility.changeRequestProgressValue(requestId, Hana_Profiler_Constant.FAILED_PROCESS_PERCENT_VALUE,
						Hana_Profiler_Constant.ST03FAILED_STATUS_COMMENT);
				logger.error("EError while reading inputreadfile", e);
				logger.error(e.getMessage());
				throw new Exception("Exception in reading input files");

			}

		}

		return status;
	}

	protected void clientFileRFPProcessingBusinessLogic(final long requestId, HttpServletRequest request,
			HttpSession session, DisplayGraphS4DAO graphS4DAO, RequestForm requestForm) {
		String status, comments;
		String toolName = (String) session.getAttribute("tool");
		getDaoIntf().deleteCurrentQueueExecution(CurrentExecution.class);
		getAutoHANA().saveCurrentData(requestId, toolName);
		if ("services".equalsIgnoreCase(toolName)) {
			final String rootPath = HANAUtility.getFilePath(requestForm.getClientName(), requestId);
			logger.info("rootPath=" + rootPath);
			getAutoHANA().setRootFilePath(rootPath);
			getSt03DataAnalysis().setRootFolderPath(rootPath);
			String filePath = getSt03DataAnalysis().getFilePath();
			try {
				FileUtility.checkFileSize(new File(filePath));
			} catch (Exception e1) {
				logger.error("Error in clientFileRFPProcessingBusinessLogic ", e1);
			}

			try {

				TADIRInventory tadir = getSt03DataAnalysis().readFile(filePath, requestId, toolName, session,
						requestForm);
				getRequestDetails().saveTadirForm(tadir);
				status = Hana_Profiler_Constant.ROMREFININGSUCCESS_STATUS;
				comments = Hana_Profiler_Constant.ROMREFININGSUCCESS_STATUS_COMMENT;
				getRequestInventorydao().updateSatus(requestId, status, getPrincipal(), comments, toolName);
				getRequestInventorydao().updateRfpSatus(requestId,
						Hana_Profiler_Constant.RFP_CLIENT_PROC_SUCCESS_STATUS, getPrincipal(), toolName, null,
						Hana_Profiler_Constant.RFP_PROCESS_SUCC);
				HANAUtility.changeRequestProgressValue(requestId, Hana_Profiler_Constant.PROCESS_COMPLETE_PERCENT_VALUE,
						"Processing Completed");

			} catch (Exception e) {
				logger.error("Failed processing TADIR File", e);
				status = Hana_Profiler_Constant.ROMREFININGFAILED_STATUS;
				comments = Hana_Profiler_Constant.ROMREFININGFAILED_STATUS_COMMENT;
				getRequestInventorydao().updateSatus(requestId, status, getPrincipal(), comments, toolName);
				getRequestInventorydao().updateRfpSatus(requestId, Hana_Profiler_Constant.RFP_CLIENT_PROC_FAILED_STATUS,
						getPrincipal(), toolName, null, Hana_Profiler_Constant.RFP_PROCESS_FAIL);
				logger.error("Error in reading file in clientFileRFPProcessingBusinessLogic", e);
				HANAUtility.changeRequestProgressValue(requestId, Hana_Profiler_Constant.FAILED_PROCESS_PERCENT_VALUE,
						"Processing Failed");
			} finally {
				getDaoIntf().deleteCurrentQueueExecution(CurrentExecution.class);
			}
		}
	}

	// Files Processing Logic
	protected void clientFileProcessingBusinessLogic(final long requestId, HttpServletRequest request,
			HttpSession session, DisplayGraphS4DAO graphS4DAO, RequestForm requestForm) {

		logger.info(
				"::::::::::::::::::::Processing Starting:::::::::::::::::::::::(inside clientFileProcessingBusinessLogic())");
		String toolName = (String) session.getAttribute("tool");

		String status, comments, subStatus;
		boolean scopeHana = requestForm.getSOH();
		boolean scopeS4 = requestForm.getS4Technical();
		boolean scopeFIAT = requestForm.getS4Functional();
		boolean scopeUI5 = requestForm.getUI5();
		boolean scopeFiori = requestForm.getFiori();
		boolean scopeAUCT = requestForm.getUPGRADE();
		boolean scopeOSMigration = requestForm.getOsMig();
		String targetVersion = requestForm.getTargetVersion();
		boolean scopeExt = requestForm.getEXT();
		String sourceVersion = requestForm.getSourceVersion();

		List<String> externalNamespaceList = null;

		if (StringUtils.isNotEmpty(requestForm.getExternalNamespace())) {
			externalNamespaceList = new ArrayList<>(Arrays.asList(requestForm.getExternalNamespace().split(",")));
		}

		Map<Integer, String> waitingRequestMap = new HashMap<Integer, String>();
		CodeAssessmentPayLoad CPL = St03ReaderXlsx.getHm();
		List<MetaData> metaDataWithCategory = null;
		ExtensionScope extensionScope = new ExtensionScope();

		try {
			long currExecutingRequestId = getAutoHANA().getCurrentExecutedRequestId();

			if (currExecutingRequestId != 0L) {
				if (currExecutingRequestId == requestId) {
					HANAUtility.changeRequestProgressValue(requestId, 0, "Request is Already in Process ");

				} else {
					getAutoHANA().saveQueueData(requestId, getPrincipal(), getEmailIDDao().getEmail(getPrincipal()),
							toolName);
					waitingRequestMap = getDaoIntf().getWaitingRequest();
					HANAUtility.changeRequestProgressValue(requestId, 0, "Some Other Request is Underprocessing ");
				}
			} else {
				getAutoHANA().saveCurrentData(requestId, toolName);

				if ("services".equalsIgnoreCase(toolName)) {

					logger.info(
							"::::::::::::::::::::Processing Start--Clearing tables for that particular id:::::::::::::::::::::::(inside clientFileProcessingBusinessLogic())");
					try {
						inputFileRead(requestId, request, toolName, session);
					} catch (Exception e) {
						status = Hana_Profiler_Constant.ST03FAILED_STATUS;
						comments = Hana_Profiler_Constant.ST03FAILED_STATUS_EXCEPTION_COMMENT;
						subStatus = "File Reading Failed";
						getRequestInventorydao().updateSatusSubStatus(requestId, status, getPrincipal(),
								Hana_Profiler_Constant.CLIENT_PROCESS_FAIL, toolName, subStatus);
						throw new Exception();
					}
					if (scopeHana || scopeS4 || scopeAUCT || scopeOSMigration || requestForm.getBwTech() || scopeExt) {
						if (CPL.getMetaDataList() != null && !CPL.getMetaDataList().isEmpty()) {
							metaDataWithCategory = getExtensionService().findRicefCategory(CPL, extensionScope);
						}
					}
					if (scopeExt) {
						if (metaDataWithCategory != null && !metaDataWithCategory.isEmpty()) {
							getExtensibilityDao().impactedCloneBatchInsertUpdate(CPL.getImpactedcloneList(), session);
							List<MetaData> metaDataWithComplexity = null;
							List<MetaData> metaDataWithExt = null;
							if (extensionScope.getRicefFlag() != null
									&& extensionScope.getRicefFlag().equalsIgnoreCase(ST03HanaConstant.RICEFW)) {
								getExtensibilityDao().ExtensionOutputBatchInsert(metaDataWithCategory,
										extensionScope.getRicefFlag(), session);
								getGraphDao().saveGraphDataForExt(extensionScope, requestId, session);
							} else {
								metaDataWithComplexity = getExtensionService().calculateComplexity(CPL,
										metaDataWithCategory, extensionScope);

								if (metaDataWithComplexity != null && metaDataWithComplexity.size() > 0) {
									metaDataWithExt = getExtensionService().findExtRecommendation(requestForm, CPL,
											metaDataWithComplexity, extensionScope);
									getExtensionService().setRicefComments(metaDataWithExt);
								}
								if (metaDataWithExt != null && !metaDataWithExt.isEmpty()) {
									getExtensibilityDao().ExtensionOutputBatchInsert(metaDataWithExt,
											extensionScope.getRicefFlag(), session);
								}
								getGraphDao().saveGraphDataForExt(extensionScope, requestId, session);

							}

						}
					}

					if (scopeHana || scopeS4 || scopeAUCT || scopeOSMigration || requestForm.getBwTech()) {
						// storeImpactedCloneAnalysis(CPL,requestId);
						// addLsmwToInventory(CPL);
					}
					if (scopeHana || scopeS4 || scopeAUCT || scopeOSMigration || requestForm.getBwTech()) {
						addAcnipRicefAndSubCategory(CPL);
					}
					if (CPL.getSt03nList() != null && !CPL.getSt03nList().isEmpty()) {
						processST03NData(CPL, targetVersion, requestId, session);
					}

					if (scopeHana) {
						logger.info(
								"::::::::::::::::::::Processing Start--Hana business Logic:::::::::::::::::::::::(inside clientFileProcessingBusinessLogic())");
						try {
							clientFileProcessingBusinessLogicHana(requestId, request, toolName, session);
						} catch (Exception e) {
							status = Hana_Profiler_Constant.ST03FAILED_STATUS;
							comments = Hana_Profiler_Constant.ST03FAILED_STATUS_EXCEPTION_COMMENT;
							subStatus = "Hana Processing Failed";
							getRequestInventorydao().updateSatusSubStatus(requestId, status, getPrincipal(),
									Hana_Profiler_Constant.CLIENT_PROCESS_FAIL, toolName, subStatus);
							throw new Exception();

						}

						logger.info(
								"::::::::::::::::::::End--Hana business Logic:::::::::::::::::::::::(inside clientFileProcessingBusinessLogic())");
					}
					if (scopeS4) {
						logger.info(
								"::::::::::::::::::::Processing Start--S4 business Logic:::::::::::::::::::::::(inside clientFileProcessingBusinessLogic())");
						try {
							clientFileProcessingBusinessLogicS4(requestId, request, toolName, session);
						} catch (Exception e) {
							status = Hana_Profiler_Constant.ST03FAILED_STATUS;
							comments = Hana_Profiler_Constant.ST03FAILED_STATUS_EXCEPTION_COMMENT;
							subStatus = "S4 Processing Failed";
							getRequestInventorydao().updateSatusSubStatus(requestId, status, getPrincipal(),
									Hana_Profiler_Constant.CLIENT_PROCESS_FAIL, toolName, subStatus);
							throw new Exception();

						}
						logger.info(
								"::::::::::::::::::::Processing End--s4 business Logic:::::::::::::::::::::::(inside clientFileProcessingBusinessLogic())");
					}
					if (requestForm.getBwTech()) {
						logger.info(
								"::::::::::::::::::::Processing Start--Bw Technical Logic:::::::::::::::::::::::(inside clientFileProcessingBusinessLogic())");
						try {
							clientFileProcessingBusinessLogicS4(requestId, request, toolName, session);
							bwCleanUp.transferBwInventoryDataIntoDownloadTbl(session, requestId);
							bwCleanUp.bwStandardExtractProcessing(session, requestId);
						} catch (Exception e) {
							status = Hana_Profiler_Constant.ST03FAILED_STATUS;
							comments = Hana_Profiler_Constant.ST03FAILED_STATUS_EXCEPTION_COMMENT;
							subStatus = "S4 Processing Failed";
							getRequestInventorydao().updateSatusSubStatus(requestId, status, getPrincipal(),
									Hana_Profiler_Constant.CLIENT_PROCESS_FAIL, toolName, subStatus);
							throw new Exception();

						}
						logger.info(
								"::::::::::::::::::::Processing End--Bw Technical Logic:::::::::::::::::::::::(inside clientFileProcessingBusinessLogic())");
					}
					if (scopeAUCT) {

						logger.info(
								"::::::::::::::::::::Processing Start--AUCT business Logic:::::::::::::::::::::::(inside clientFileProcessingBusinessLogic())");
						try {
							clientFileProcessingBusinessLogicAUCT(requestId, request, toolName, session);
						} catch (Exception e) {
							status = Hana_Profiler_Constant.ST03FAILED_STATUS;
							comments = Hana_Profiler_Constant.ST03FAILED_STATUS_EXCEPTION_COMMENT;
							subStatus = "AUCT Processing Failed";
							getRequestInventorydao().updateSatusSubStatus(requestId, status, getPrincipal(),
									Hana_Profiler_Constant.CLIENT_PROCESS_FAIL, toolName, subStatus);
							throw new Exception();

						}
						logger.info(
								"::::::::::::::::::::End--AUCT business Logic:::::::::::::::::::::::(inside clientFileProcessingBusinessLogic())");
					}
					if (scopeUI5) {
						logger.info(
								"::::::::::::::::::::Processing Start--UI5 business Logic:::::::::::::::::::::::(inside clientFileProcessingBusinessLogic())");

						try {

							List<UI5InputExtract> UI5InputList = St03ReaderXlsx.getUI5InputList();
							clientFileProcessingBusinessLogicUI5(requestId, request, toolName, session, UI5InputList);
							logger.info("Start of UI5 Graphs/////////////////////////////////////////////");
							getGraphDao().updateUI5GraphCountApi(requestId);
							logger.info("End of UI5 Logic/////////////////////////////////////////////");

						} catch (Exception e) {
							status = Hana_Profiler_Constant.ST03FAILED_STATUS;
							comments = Hana_Profiler_Constant.ST03FAILED_STATUS_EXCEPTION_COMMENT;
							subStatus = "UI5 Processing Failed";
							getRequestInventorydao().updateSatusSubStatus(requestId, status, getPrincipal(),
									Hana_Profiler_Constant.CLIENT_PROCESS_FAIL, toolName, subStatus);
							throw new Exception();

						}

						logger.info(
								"::::::::::::::::::::End--UI5 business Logic:::::::::::::::::::::::(inside clientFileProcessingBusinessLogic())");
					}

					if (scopeFiori) {
						try {
							// List<OdataFioriApps> odataFioriAppsList =
							// St03ReaderXlsx.getOdataFioriAppsList();
							List<CustomReportOutput> customReportOutputList = St03ReaderXlsx
									.getCustomReportOutputList();

							// clientFileProcessingBusinessLogicFiori(requestId,
							// request, toolName, session,
							// odataFioriAppsList, sourceVersion,
							// targetVersion);
							clientFileProcessingBusinessLogicFioriNew(requestId, request, toolName, session,
									customReportOutputList, sourceVersion, targetVersion);
						} catch (Exception e) {
							logger.error("Error  clientFileRFPProcessingBusinessLogic in processing of scopeFiori", e);
							status = Hana_Profiler_Constant.ST03FAILED_STATUS;
							comments = Hana_Profiler_Constant.ST03FAILED_STATUS_EXCEPTION_COMMENT;
							subStatus = "Fiori Processing Failed";
							getRequestInventorydao().updateSatusSubStatus(requestId, status, getPrincipal(),
									Hana_Profiler_Constant.CLIENT_PROCESS_FAIL, toolName, subStatus);
							throw new Exception();
						}
					}

					if (requestForm.getSia()) {
						try {
							clientFileProcessingBusinessLogicSia(requestId, request, toolName, session);
						} catch (Exception e) {
							status = Hana_Profiler_Constant.ST03FAILED_STATUS;
							comments = Hana_Profiler_Constant.ST03FAILED_STATUS_EXCEPTION_COMMENT;
							subStatus = "Security Analyser Processing Failed";
							getRequestInventorydao().updateSatusSubStatus(requestId, status, getPrincipal(),
									Hana_Profiler_Constant.CLIENT_PROCESS_FAIL, toolName, subStatus);
							logger.error("clientFileProcessingBusinessLogicSia :: ", e);
							throw new Exception();
						}
					}

					if (requestForm.getBwUsage()) {
						try {
							clientFileProcessingBusinessLogicBW(requestId, request, toolName, session);
						} catch (Exception e) {
							status = Hana_Profiler_Constant.ST03FAILED_STATUS;
							comments = Hana_Profiler_Constant.ST03FAILED_STATUS_EXCEPTION_COMMENT;
							subStatus = "BW Clean up Processing Failed";
							getRequestInventorydao().updateSatusSubStatus(requestId, status, getPrincipal(),
									Hana_Profiler_Constant.CLIENT_PROCESS_FAIL, toolName, subStatus);
							logger.error("clientFileProcessingBusinessLogicBW :: ", e);
							throw new Exception();
						}
					}

					if (requestForm.getGrc()) {
						try {
							clientFileProcessingBusinessLogicGrc(requestId, request, toolName, session);
						} catch (Exception e) {
							status = Hana_Profiler_Constant.ST03FAILED_STATUS;
							comments = Hana_Profiler_Constant.ST03FAILED_STATUS_EXCEPTION_COMMENT;
							subStatus = "Security Analyser GRC Processing Failed";
							getRequestInventorydao().updateSatusSubStatus(requestId, status, getPrincipal(),
									Hana_Profiler_Constant.CLIENT_PROCESS_FAIL, toolName, subStatus);
							logger.error("clientFileProcessingBusinessLogicGrc :: ", e);
							throw new Exception();
						}
					}
				}
				if (scopeOSMigration && St03ReaderXlsx.getHm().getOsMigrationList() != null
						&& !St03ReaderXlsx.getHm().getOsMigrationList().isEmpty()) {
					logger.info("::::::::::Processing Start--OS Migration Logic:::::::::::");
					try {
						clientFileProcessingBusinessLogicOSMigration(requestId, request, toolName, session);
					} catch (Exception e) {
						status = Hana_Profiler_Constant.ST03FAILED_STATUS;
						comments = Hana_Profiler_Constant.ST03FAILED_STATUS_EXCEPTION_COMMENT;
						subStatus = "OS Migration Processing Failed";
						getRequestInventorydao().updateSatusSubStatus(requestId, status, getPrincipal(),
								Hana_Profiler_Constant.CLIENT_PROCESS_FAIL, toolName, subStatus);
						throw new Exception();
					}

					logger.info(":::::::::End--OS Migartion Logic:::::::::");
				}

				if (scopeHana || scopeS4 || scopeAUCT || requestForm.getBwTech()) {
					logger.info(
							"::::::::::::::::::::Processing Start--Testing scope business Logic:::::::::::::::::::::::(inside clientFileProcessingBusinessLogic())");
					try {
						List<Testingscopepojo> tscope = St03ReaderXlsx.getTscopeList();
						clientProcessingBusinessLogicTestingScope(requestId, request, toolName, session, tscope);
					} catch (Exception e) {
						status = Hana_Profiler_Constant.ST03FAILED_STATUS;
						comments = Hana_Profiler_Constant.ST03FAILED_STATUS_EXCEPTION_COMMENT;
						subStatus = "Tetsing scope Processing Failed";
						getRequestInventorydao().updateSatusSubStatus(requestId, status, getPrincipal(),
								Hana_Profiler_Constant.CLIENT_PROCESS_FAIL, toolName, subStatus);
						throw new Exception();
					}
					try {
						// Testing Scope Request Master Data updation
						getGraphDao().testingScopeRequestMaster(requestId, session);
					} catch (Exception e) {
						status = Hana_Profiler_Constant.ST03FAILED_STATUS;
						comments = Hana_Profiler_Constant.ST03FAILED_STATUS_EXCEPTION_COMMENT;
						subStatus = "Tetsing scope Master Data updation Failed";
						getRequestInventorydao().updateSatusSubStatus(requestId, status, getPrincipal(),
								Hana_Profiler_Constant.CLIENT_PROCESS_FAIL, toolName, subStatus);
						throw new Exception();
					}

					logger.info(
							"::::::::::::::::::::End--Testing scope business Logic:::::::::::::::::::::::(inside clientFileProcessingBusinessLogic())");
					try {
						if ("NO".equalsIgnoreCase(requestForm.getUnicodeCompliant())
								&& "YES".equalsIgnoreCase(requestForm.getEnableUnicode())) {
							daoIntf.unicodeProcessing(session);
						}
					} catch (Exception e) {
						status = Hana_Profiler_Constant.ST03FAILED_STATUS;
						comments = Hana_Profiler_Constant.ST03FAILED_STATUS_EXCEPTION_COMMENT;
						subStatus = "Unicode Enagas Failed";
						getRequestInventorydao().updateSatusSubStatus(requestId, status, getPrincipal(),
								Hana_Profiler_Constant.CLIENT_PROCESS_FAIL, toolName, subStatus);
						throw new Exception();
					}
				} else {
					// Any other tool is implemented
				}

				if (scopeHana || scopeS4 || scopeAUCT || requestForm.getBwTech()) {
					logger.info(
							"::::::::::::::::::::Processing Start--ImpactedBackgroundJob:::::::::::::::::::::::(inside clientFileProcessingBusinessLogic())");
					try {
						clientFileProcessingBusinessLogicImpactedBackgroundJob(requestId, request, session);
					} catch (Exception e) {
						status = Hana_Profiler_Constant.ST03FAILED_STATUS;
						comments = Hana_Profiler_Constant.ST03FAILED_STATUS_EXCEPTION_COMMENT;
						subStatus = "ImpactedBackgroundJob Processing Failed";
						getRequestInventorydao().updateSatusSubStatus(requestId, status, getPrincipal(),
								Hana_Profiler_Constant.CLIENT_PROCESS_FAIL, toolName, subStatus);
						throw new Exception();
					}
					logger.info(
							"::::::::::::::::::::End--ImpactedBackgroundJob:::::::::::::::::::::::(inside clientFileProcessingBusinessLogic())");
				}

				// Data transfer from simplification intermediate table to drill
				// down table
				String s4DrillDownFinalOutput = "INSERT INTO DrillDown_Download (Issue_Sub_Category, READ_PROG, SELECT_LINE, Trigger_Object, AFFECT_OBJ_DESC, "
						+ "Affected_Area, APP_COMPONENT, complexity, DESC_OF_CHANGE, ERROR_CATEGORY, IDENTIFIER, IMPACT_REASON, IMPACTED_OBJ_TYPE, ISSUE_CATEGORY, "
						+ "ITEM_AREA, LINE_NO, METHOD, OBJ_NAME, OBJ_NAME_TYPE, OPERATIONS, PCKG, Remediation_Category, REQUEST_ID, SAP_NOTES, SAP_SIMP_LIST, "
						+ "SAP_SIMPL_CATEGORY, SOLUTION_STEPS, STMT, SUB_OBJ, Total_Scanned_Line, TRIGGER_OBJ, TYPE, USED, Impact, Correction_ProgName, Correction_LineNo, RICEF_CATEGORY, TOOL_VERSION) "
						+ "SELECT DISTINCT Issue_Sub_Category, READ_PROG, SELECT_LINE, Trigger_Object, AFFECT_OBJ_DESC, Affected_Area, APP_COMPONENT, complexity, "
						+ "DESC_OF_CHANGE, ERROR_CATEGORY, IDENTIFIER, IMPACT_REASON, IMPACTED_OBJ_TYPE, ISSUE_CATEGORY, ITEM_AREA, LINE_NO, METHOD, OBJ_NAME, "
						+ "OBJ_NAME_TYPE, OPERATIONS, PCKG, Remediation_Category, REQUEST_ID, SAP_NOTES, SAP_SIMP_LIST, SAP_SIMPL_CATEGORY, SOLUTION_STEPS, "
						+ "STMT, SUB_OBJ, Total_Scanned_Line, TRIGGER_OBJ, TYPE, USED, Impact, Correction_ProgName, Correction_LineNo, RICEF_CATEGORY, TOOL_VERSION from s4_final_output where REQUEST_ID = "
						+ requestId + " AND OPERATIONS = 'DRILLDOWN REPORT'";

				getAutoHANA().dataTransferToDownlaodTables(s4DrillDownFinalOutput);

				// Data transfer from simplification intermediate table to
				// obsolete fms table
				String s4ObsoleteFinalOutput = "INSERT INTO ObsoleteFMs_Download (Issue_Sub_Category, READ_PROG, SELECT_LINE, Trigger_Object, AFFECT_OBJ_DESC, "
						+ "Affected_Area, APP_COMPONENT, complexity, DESC_OF_CHANGE, IDENTIFIER, IMPACT_REASON, IMPACTED_OBJ_TYPE, ISSUE_CATEGORY, "
						+ "ITEM_AREA, LINE_NO, METHOD, OBJ_NAME, OBJ_NAME_TYPE, OPERATIONS, PCKG, Remediation_Category, REQUEST_ID, SAP_NOTES, SAP_SIMP_LIST, "
						+ "SAP_SIMPL_CATEGORY, SOLUTION_STEPS, STMT, SUB_OBJ, Total_Scanned_Line, TRIGGER_OBJ, TYPE, USED, Impact, RICEF_CATEGORY, RICEF_SUB_CATEGORY,External_Namespace,ERROR_CATEGORY) "
						+ "SELECT DISTINCT Issue_Sub_Category, READ_PROG, SELECT_LINE, Trigger_Object, AFFECT_OBJ_DESC, Affected_Area, APP_COMPONENT, complexity, "
						+ "DESC_OF_CHANGE, IDENTIFIER, IMPACT_REASON, IMPACTED_OBJ_TYPE, ISSUE_CATEGORY, ITEM_AREA, LINE_NO, METHOD, OBJ_NAME, "
						+ "OBJ_NAME_TYPE, OPERATIONS, PCKG, Remediation_Category, REQUEST_ID, SAP_NOTES, SAP_SIMP_LIST, SAP_SIMPL_CATEGORY, SOLUTION_STEPS, "
						+ "STMT, SUB_OBJ, Total_Scanned_Line, TRIGGER_OBJ, TYPE, USED, Impact, RICEF_CATEGORY, RICEF_SUB_CATEGORY,External_Namespace,ERROR_CATEGORY from s4_final_output where REQUEST_ID = "
						+ requestId + " AND DESC_OF_CHANGE = 'OBSOLETE FM DUE TO UPGRADE'";

				getAutoHANA().dataTransferToDownlaodTables(s4ObsoleteFinalOutput);

				// Deleting drill down and obselete fms entries from
				// simplification table
				getAutoHANA().deleteFromSimplification(requestId);

				logger.info(
						"::::::::::::::::::::Processing Start--Updating impacted table:::::::::::::::::::::::(inside clientFileProcessingBusinessLogic())");
				try {
					if (scopeHana || scopeS4 || scopeAUCT || scopeOSMigration || requestForm.getBwTech()) {
						getDaoIntf().updateImpactObjType(requestId);
					}
				} catch (Exception e) {
					status = Hana_Profiler_Constant.ST03FAILED_STATUS;
					comments = Hana_Profiler_Constant.ST03FAILED_STATUS_EXCEPTION_COMMENT;
					subStatus = "Failed while Updating Impacted Object Type";
					getRequestInventorydao().updateSatusSubStatus(requestId, status, getPrincipal(),
							Hana_Profiler_Constant.CLIENT_PROCESS_FAIL, toolName, subStatus);
					throw new Exception();

				}
				logger.info(
						"::::::::::::::::::::End--Updating impacted table:::::::::::::::::::::::(inside clientFileProcessingBusinessLogic()) ");

				logger.info(
						"::::::::::::::::::::Processing Start--Updating impacted SCripts:::::::::::::::::::::::(inside clientFileProcessingBusinessLogic())");
				try {
					if (scopeHana || scopeS4 || scopeAUCT || requestForm.getBwTech()) {
						List<ImpactedScripts> impactedScripts = St03ReaderXlsx.getImpactedScriptsList();
						getDaoIntf().clientFileProcessingBusinessLogicScripts(requestId, request, toolName, session,
								impactedScripts);

					}
				} catch (Exception e) {
					status = Hana_Profiler_Constant.ST03FAILED_STATUS;
					comments = Hana_Profiler_Constant.ST03FAILED_STATUS_EXCEPTION_COMMENT;
					subStatus = "Failed while Updating Impacted Scripts";
					getRequestInventorydao().updateSatusSubStatus(requestId, status, getPrincipal(),
							Hana_Profiler_Constant.CLIENT_PROCESS_FAIL, toolName, subStatus);
					throw new Exception();

				}
				logger.info(
						"::::::::::::::::::::End--Updating impacted scripts:::::::::::::::::::::::(inside clientFileProcessingBusinessLogic()) ");

				try {
					if (scopeHana || scopeS4 || scopeAUCT || scopeOSMigration || requestForm.getBwTech()) {
						getDaoIntf().updateInventory(requestId);
						addLsmwToInventory(CPL, requestId);
					}
				} catch (Exception e) {
					status = Hana_Profiler_Constant.ST03FAILED_STATUS;
					comments = Hana_Profiler_Constant.ST03FAILED_STATUS_EXCEPTION_COMMENT;
					subStatus = "Failed while Updating Inventory data";
					getRequestInventorydao().updateSatusSubStatus(requestId, status, getPrincipal(),
							Hana_Profiler_Constant.CLIENT_PROCESS_FAIL, toolName, subStatus);
					throw new Exception();

				}

				// IRPA - TestingScope Logic
				if (scopeHana || scopeS4 || scopeAUCT) {
					if (AppGenUtility.getTScopeVer(sourceVersion, targetVersion))
						clientBusinessProcessingIRPATScope(requestId, request, session, requestForm);
				}

				// Updating Request Master Data
				try {
					// to avoid running of extra code for UI5
					if (scopeHana || scopeS4 || scopeAUCT) {
						ProcessedRequestDetail requestMasterCommon = getGraphDao()
								.getRequestMasterCommonColumns(requestId);
						logger.info(
								"::::::::::::::::::::START======================================Impacted Background Job Counts::::::::::::::::::::::");
						graphDao.updateImpatedBackgroundJobCount(requestId);
						logger.info(
								"::::::::::::::::::::END======================================Impacted Background Job Counts::::::::::::::::::::::::");

						if (scopeHana) {
							logger.info(
									"::::::::::::::::::::Request Master start-Updating hana table:::::::::::::::::::::::(inside clientFileProcessingBusinessLogic())");

							getGraphDao().updateRequestMaster(requestId, requestMasterCommon);

							logger.info(
									"::::::::::::::::::::Request Master End-Updating hana table:::::::::::::::::::::::(inside clientFileProcessingBusinessLogic())");
						}
						if (scopeS4) {
							logger.info(
									"::::::::::::::::::::Request Master Start-Updating S4 table:::::::::::::::::::::::(inside clientFileProcessingBusinessLogic())");

							graphS4DAO.updateRequestMasterS4(requestId, requestMasterCommon);

							logger.info(
									"::::::::::::::::::::Request Master End-Updating S4 table:::::::::::::::::::::::(inside clientFileProcessingBusinessLogic())");
						}
						if (scopeAUCT) {

						}
					}

					if (scopeFiori) {

						logger.info(
								"::::::::::::::::::::Request Master start-Updating Fiori table:::::::::::::::::::::::(inside clientFileProcessingBusinessLogic())");

						getOdataFioriProcessDao().updateRequestMasterFiori(requestId);

						logger.info(
								"::::::::::::::::::::Request Master End-Updating Fiori table:::::::::::::::::::::::(inside clientFileProcessingBusinessLogic())");
					}
				} catch (Exception e) {
					logger.error("Error clientFileRFPProcessingBusinessLogic Updating Request Master Data", e);
					status = Hana_Profiler_Constant.ST03FAILED_STATUS;
					comments = Hana_Profiler_Constant.ST03FAILED_STATUS_EXCEPTION_COMMENT;
					subStatus = "Failed while Updating Request Master Count";
					getRequestInventorydao().updateSatusSubStatus(requestId, status, getPrincipal(),
							Hana_Profiler_Constant.CLIENT_PROCESS_FAIL, toolName, subStatus);
					throw new Exception();
				}

				// -----------------for transactinal tables code
				// ------------------
				try {
					// to avoid running of extra code for UI5
					if (scopeHana || scopeS4 || scopeAUCT || scopeOSMigration || requestForm.getBwTech()) {
						storeImpactedCloneAnalysis(CPL, requestId, externalNamespaceList);
						DataTransfer(requestId, requestForm);
						getAutoHANA().clearAllTables(requestId);
						getAutoHANA().clearIRPATScopeIntermediateTable(requestId, session);
					}
				} catch (Exception e) {
					status = Hana_Profiler_Constant.ST03FAILED_STATUS;
					comments = Hana_Profiler_Constant.ST03FAILED_STATUS_EXCEPTION_COMMENT;
					subStatus = "Failed while clearing all tables";
					getRequestInventorydao().updateSatusSubStatus(requestId, status, getPrincipal(),
							Hana_Profiler_Constant.CLIENT_PROCESS_FAIL, toolName, subStatus);
					throw new Exception();
				}
				HANAUtility.changeRequestProgressValue(requestId, Hana_Profiler_Constant.PROCESS_COMPLETE_PERCENT_VALUE,
						Hana_Profiler_Constant.PROCESS_COMPLETE_MSG);

				getDaoIntf().deleteCurrentQueueExecution(CurrentExecution.class);
				logger.info("Going to send mail::: ");
				status = Hana_Profiler_Constant.HANAREFININGSUCCESS_STATUS;
				comments = Hana_Profiler_Constant.HANAREFININGSUCCESS_STATUS_COMMENT;

				logger.info(
						"::::::::::::::::::::Processing completed change status in request Inventory:::::::::::::::::::::::(inside clientFileProcessingBusinessLogic())");

				getRequestInventorydao().updateSatus(requestId, status, getPrincipal(), comments, toolName);

				try {
					sendEmailForProcessedRequest(status, requestId, request,
							Hana_Profiler_Constant.COMPLETED_PENDING_ESTIMATIONS, session);
				} catch (Exception e) {
					logger.error(e.getMessage());
					logger.info(
							"............Sending Email failed at processing end For:::(request--Completed with pending Estimations) .......");
				}
				getDaoIntf().deleteProcessedRequestFromWaitingQueue(requestId, session);

				// waitingRequestMap = getDaoIntf().getWaitingRequest();
				Map<Integer, String> resMap = getDaoIntf().getWaitingRequestWithOldTime(session);
				if (!resMap.isEmpty()) {

					logger.info("sendEmailToWaitingRequest for resMap");
					try {
						sendEmailToWaitingRequest(resMap, request, session);
					} catch (Exception e) {
						logger.error("sendEmailToWaitingRequest :: ", e);
						logger.info(
								"............Sending Email failed at processing end For:::(sending Mails to users in queue Execution).......");
					}
				}
			}

		} catch (Exception e) {
			logger.error("Error clientFilesProcessing", e);
			logger.error(e.getMessage());
			logger.info("Inside catch clientFilesProcessing ");
			status = Hana_Profiler_Constant.ST03FAILED_STATUS;
			comments = Hana_Profiler_Constant.ST03FAILED_STATUS_EXCEPTION_COMMENT;
			getRequestInventorydao().updateSatus(requestId, status, getPrincipal(), comments, toolName);
			sendEmailForProcessedRequest(status, requestId, request, Hana_Profiler_Constant.Prosess_FAILURE, session);
			HANAUtility.changeRequestProgressValue(requestId, Hana_Profiler_Constant.FAILED_PROCESS_PERCENT_VALUE,
					comments);
			getDaoIntf().deleteCurrentQueueExecution(CurrentExecution.class);

		}
	}

	protected void processST03NData(CodeAssessmentPayLoad cPL, String target, long requestId, HttpSession session)
			throws IOException, JCoException, SQLException {
		logger.info("............ST03N Processing Started.......");

		if (target.startsWith("S/4") && !target.contains("Cloud")) {
			StringBuffer modifiedTarget = new StringBuffer(target);
			modifiedTarget.insert(7, " ");
			target = modifiedTarget.toString();
		} else if (target.contains("Cloud")) {
			target = "S/4HANA Cloud";
		}
		List<AppsType> appsTypeList = getOdataFioriProcessDao().getFioriDataFromDB(session, target);
		List<List<AppsType>> refinedTcodeList = getTcodeStandardizationService().refineTCodes(appsTypeList);
		List<AppsType> processedAppList = getTcodeStandardizationService().processTCodes(cPL.getSt03nList(),
				refinedTcodeList);

		if (processedAppList != null && !processedAppList.isEmpty()) {
			getOdataFioriProcessDao().insertFioriAppsData(processedAppList, session, requestId);
		}

		logger.info("............ST03N Processing Ended.......");

	}

	protected void clientFileProcessingBusinessLogicFiori(final long requestID, HttpServletRequest request,
			final String toolName, HttpSession session, List<OdataFioriApps> odataFioriAppsList, String sourceVersion,
			String targetVersion) throws Exception {
		logger.info("............Started Fiori Processing .......");

		getFioriProcessingDao().processFioriApps(requestID, odataFioriAppsList, sourceVersion, targetVersion, session);
		DataTransferFiori(requestID);
		logger.info("............Ended Fiori Processing .......");
	}

	protected void clientFileProcessingBusinessLogicFioriNew(final long requestID, HttpServletRequest request,
			final String toolName, HttpSession session, List<CustomReportOutput> customReportOutputList,
			String sourceVersion, String targetVersion) throws Exception {
		logger.info("............Started Fiori Processing .......");

		getFioriProcessingNewDao().processFioriApps(requestID, customReportOutputList, sourceVersion, targetVersion,
				session);
		DataTransferFioriNew(requestID);
		logger.info("............Ended Fiori Processing .......");
	}

	protected void clientFileProcessingBusinessLogicSia(final long requestID, HttpServletRequest request,
			final String toolName, HttpSession session) throws Exception {
		logger.info("............Started SIA Processing .......");
		getSecAnalyseService().getSecurityAnalyserReport(session, requestID);
		logger.info("............Ended SIA Processing .......");
	}

	protected void clientFileProcessingBusinessLogicBW(final long requestID, HttpServletRequest request,
			final String toolName, HttpSession session) throws Exception {
		logger.info("............Started BW Processing .......");
		bwCleanUp.getBwObjectInYears(session, requestID);
		logger.info("............Ended BW Processing .......");
	}

	protected void clientFileProcessingBusinessLogicGrc(final long requestID, HttpServletRequest request,
			final String toolName, HttpSession session) throws Exception {
		logger.info("............Started BW Processing .......");
		getSecAnalyseService().getSecurityAnalyserGrcReport(session, requestID);
		logger.info("............Ended BW Processing .......");
	}

	// ************************************************************************************
	protected void clientFileProcessingBusinessLogicImpactedBackgroundJob(final long requestID,
			HttpServletRequest request, HttpSession session) throws Exception {
		logger.info("............Started Background Job Processing .......");

		String impactedBackgroundJobList = "INSERT INTO Impacted_Background_Job_Download (OBJECT,BACKGROUND_JOB_NAME,PROGRAM_NAME,VARIANT,TCODE,RUN,Request_Id,External_Namespace) "
				+ "SELECT OBJECT,OBJECT_NAME,SUB_TYPE,READ_PROG,OBJ_PACKAGE,ACT_STATUS,Request_Id,External_Namespace from Impacted_Background_Job where Request_Id="
				+ requestID;
		// getAutoHANA().dataTransferToDownlaodTables(impactedBackgroundJobList);
		logger.info("............Ended Background Job Processing .......");
	}

	protected void DataTransfer(final long requestId, RequestForm requestForm) throws Exception {
		logger.info("............Started Data transfer from transaction tables to download/Reporting tables.......");

		String inventoryList = "INSERT INTO Inventory_List_Downlaod (OBJ_NAME, OBJ_NAME_TYPE, OBJ_TYPE, REQUEST_ID, Used, Package, "
				+ "usageCount, Transport_Request, Standard_Modification, Ricef_Category, External_Namespace, Ricef_Sub_Category, "
				+ "CREATED_BY, CREATED_ON, CHANGED_BY, CHANGED_ON, TR, TR_STATUS, Count_Lines) "
				+ "SELECT OBJ_NAME, OBJ_NAME_TYPE, OBJ_TYPE, REQUEST_ID, Used, Package, usageCount, "
				+ "Transport_Request, Standard_Modification, Ricef_Category, External_Namespace, Ricef_Sub_Category, "
				+ "CREATED_BY, CREATED_ON, CHANGED_BY, CHANGED_ON, TR, TR_STATUS, Count_Lines from s4_inventory_list "
				+ "where NOT OBJ_TYPE = 'AQQU' AND REQUEST_ID=" + requestId;

		getAutoHANA().dataTransferToDownlaodTables(inventoryList);

		String inventoryListAqqu = "INSERT INTO ABAP_inventory_list_download (OBJ_NAME, OBJ_NAME_TYPE, OBJ_TYPE, REQUEST_ID, Used, Package, usageCount, Transport_Request, Ricef_Category, External_Namespace, Ricef_Sub_Category, Count_Lines , User_Group, ABAP_Query) "
				+ "SELECT OBJ_NAME, OBJ_NAME_TYPE, OBJ_TYPE, REQUEST_ID, Used, Package, usageCount, Transport_Request, Ricef_Category, External_Namespace, Ricef_Sub_Category, Count_Lines, User_Group, ABAP_Query from s4_inventory_list where OBJ_TYPE = 'AQQU' AND REQUEST_ID="
				+ requestId;

		getAutoHANA().dataTransferToDownlaodTables(inventoryListAqqu);

		String impactedObjectList = "INSERT INTO Impact_Obj_List_Downlaod "
				+ "(DB_Impact, Errors_In_Existing_System, OBJ_NAME, OBJ_NAME_TYPE, OBJ_TYPE, Odata, REQUEST_ID, S4_Simplification, Used, OS_Migration, Usage_Count, Impacted_Mod, RICEF_CATEGORY, External_Namespace,RICEF_SUB_CATEGORY, OBJECT_TYPE_NAME_READ_PROG) "
				+ "SELECT  DB_Impact, Errors_In_Existing_System, OBJ_NAME, OBJ_NAME_TYPE, OBJ_TYPE, Odata, REQUEST_ID, S4_Simplification, Used, OS_Migration, Usage_Count, Impacted_Mod, RICEF_CATEGORY, External_Namespace, RICEF_SUB_CATEGORY, OBJECT_TYPE_NAME_READ_PROG "
				+ "from impact_obj_list where REQUEST_ID=" + requestId;

		String bwExtractorList = "INSERT INTO BW_EXTRACTOR_DOWNLOAD (REQUEST_ID, OLTSOURCE, EXTRACTOR) "
				+ "SELECT REQUEST_ID, OLTSOURCE, EXTRACTOR from BW_EXTRACTOR where REQUEST_ID=" + requestId;

		getAutoHANA().dataTransferToDownlaodTables(bwExtractorList);

		getAutoHANA().dataTransferToDownlaodTables(impactedObjectList);

		String finalOutput = "INSERT INTO FINAL_OUTPUT_DOWNLOAD(COMPLEXITY, Category, CHANGE_COLUMN, DB, Info, Join_Type, Joins, "
				+ "KEYS_COLUMN, Levels, Line_Number, OBJ_PACKAGE, Obj_Name, Object_Type, Odata, Opertaion, ReadProgram, Sub_Program, Sub_Type, Subcategory, "
				+ "Table_Type, TABLES_COLUMN, Used_Unused, Where_Condition, automation_status, code, high_lvl_desc, impact, JOIN_ID, LOOP_COLUMN, "
				+ "OBJ_NAME_TYPE, operation_code, Request_ID, SEL_LINE, total_line_scanned, SKIP_REASON, IssueSecondSubCat, SKIP, RICEF_CATEGORY, "
				+ "External_Namespace, Ricef_Sub_Category, Counter) "
				+ "SELECT  COMPLEXITY, Category, CHANGE_COLUMN, DB, Info, Join_Type, Joins, KEYS_COLUMN, Levels, Line_Number, OBJ_PACKAGE, Obj_Name, "
				+ "Object_Type, Odata, Opertaion, ReadProgram, Sub_Program, Sub_Type, Subcategory, Table_Type, TABLES_COLUMN, Used_Unused, "
				+ "Where_Condition, automation_status, code, high_lvl_desc, impact, JOIN_ID, LOOP_COLUMN, OBJ_NAME_TYPE, operation_code, Request_ID, "
				+ "SEL_LINE, total_line_scanned, COMMENT_C, IssueSecondSubCat, SKIP, RICEF_CATEGORY, External_Namespace, Ricef_Sub_Category, Counter "
				+ "from final_output where Request_ID=" + requestId;

		getAutoHANA().dataTransferToDownlaodTables(finalOutput);

		String s4FinalOutput = "INSERT INTO S4_Final_Output_Download (Issue_Sub_Category, READ_PROG, SELECT_LINE, Trigger_Object, AFFECT_OBJ_DESC, "
				+ "Affected_Area, APP_COMPONENT, complexity, DESC_OF_CHANGE, ERROR_CATEGORY, IDENTIFIER, IMPACT_REASON, IMPACTED_OBJ_TYPE, ISSUE_CATEGORY, "
				+ "ITEM_AREA, LINE_NO, METHOD, OBJ_NAME, OBJ_NAME_TYPE, OPERATIONS, PCKG, Remediation_Category, REQUEST_ID, SAP_NOTES, SAP_SIMP_LIST, "
				+ "SAP_SIMPL_CATEGORY, SOLUTION_STEPS, STMT, SUB_OBJ, Total_Scanned_Line, TRIGGER_OBJ, TYPE, USED, Impact, Correction_ProgName, Correction_LineNo, "
				+ "RICEF_CATEGORY, TOOL_VERSION, External_Namespace, Automation_Status, RICEF_SUB_CATEGORY, Counter, Obsolete) "
				+ "SELECT Issue_Sub_Category, READ_PROG, SELECT_LINE, Trigger_Object, AFFECT_OBJ_DESC, Affected_Area, APP_COMPONENT, complexity, "
				+ "DESC_OF_CHANGE, ERROR_CATEGORY, IDENTIFIER, IMPACT_REASON, IMPACTED_OBJ_TYPE, ISSUE_CATEGORY, ITEM_AREA, LINE_NO, METHOD, OBJ_NAME, "
				+ "OBJ_NAME_TYPE, OPERATIONS, PCKG, Remediation_Category, REQUEST_ID, SAP_NOTES, SAP_SIMP_LIST, SAP_SIMPL_CATEGORY, SOLUTION_STEPS, "
				+ "STMT, SUB_OBJ, Total_Scanned_Line, TRIGGER_OBJ, TYPE, USED, Impact, Correction_ProgName, Correction_LineNo, RICEF_CATEGORY, "
				+ "TOOL_VERSION, External_Namespace, Automation_Status, RICEF_SUB_CATEGORY, Counter, Obsolete from s4_final_output where REQUEST_ID = "
				+ requestId;

		getAutoHANA().dataTransferToDownlaodTables(s4FinalOutput);

		StringBuilder auctFinalOutput = new StringBuilder();
		auctFinalOutput
				.append("INSERT INTO Auct_Final_Output_Download (AUTOMATION_STATUS, INFO, LINE_NUMBER, OBJ_NAME, OBJ_NAME_TYPE, OBJ_PACKAGE,OPCODE,"
						+ "OPERCD, READ_PROG, REQUEST_ID, SUB_TYPE, TOTAL_LINE_NUMBER, TYPE, Used_Unused, RICEF_CATEGORY, External_Namespace,RICEF_SUB_CATEGORY, CODE) "
						+ "SELECT AUTOMATION_STATUS, INFO, LINE_NUMBER, OBJ_NAME, OBJ_NAME_TYPE, OBJ_PACKAGE, OPCODE, OPERCD, READ_PROG, REQUEST_ID, SUB_TYPE, "
						+ "TOTAL_LINE_NUMBER, TYPE, Used_Unused, RICEF_CATEGORY, External_Namespace, RICEF_SUB_CATEGORY, CODE from auct_final_output where REQUEST_ID="
						+ requestId);
		if ("No".equalsIgnoreCase(requestForm.getUnicodeCompliant())
				&& "YES".equalsIgnoreCase(requestForm.getEnableUnicode())) {
			auctFinalOutput.append(" AND INFO NOT LIKE '%Unicode%'");
		}
		getAutoHANA().dataTransferToDownlaodTables(auctFinalOutput.toString());

		if ("No".equalsIgnoreCase(requestForm.getUnicodeCompliant())
				&& "YES".equalsIgnoreCase(requestForm.getEnableUnicode())) {
			String unicodeOutput = "INSERT INTO UNICODE_OUTPUT (Object_Type, Program, Include, Roww, Error_Code, Pack, Message, Used, "
					+ "Request_Id, External_Namespace) SELECT TYPE, OBJ_NAME, READ_PROG, LINE_NUMBER, 'UXCE', OBJ_PACKAGE, INFO, "
					+ " Used_Unused, REQUEST_ID, External_Namespace from auct_final_output where REQUEST_ID="
					+ requestId + " AND INFO LIKE '%Unicode%'";

			getAutoHANA().dataTransferToDownlaodTables(unicodeOutput);
		}

		String odataFinalOutput = "INSERT INTO Odata_Final_Output_Download(COMMENTS,COMPLEXITY,COUNTER,DESCRIPTION,FIELDS,IMPACT,LINE_NUMBER,OBJECT_TYPE,OBJ_NAME,"
				+ "OBJ_NAME_TYPE,ODATA,OPERATIONS,PACKAGE,READ_PROGRAM,REF_LINE_NO,REMEDIATION_CATEGORY,REQUEST_ID,STATEMENT,SUB_PROGRAM,SUB_TYPE,TABLES,"
				+ "TABLE_TYPE,Used_Unused) SELECT COMMENTS,COMPLEXITY,COUNTER,DESCRIPTION,FIELDS,IMPACT,LINE_NUMBER,OBJECT_TYPE,OBJ_NAME,OBJ_NAME_TYPE"
				+ ",ODATA,OPERATIONS,PACKAGE,READ_PROGRAM,REF_LINE_NO,REMEDIATION_CATEGORY,REQUEST_ID,STATEMENT,SUB_PROGRAM,SUB_TYPE,TABLES,TABLE_TYPE,"
				+ "Used_Unused from odata_final_output where REQUEST_ID=" + requestId;
		getAutoHANA().dataTransferToDownlaodTables(odataFinalOutput);

		String s4OutputManagement = "INSERT INTO s4_output_management_download(Obj_Name,REQUEST_ID,Type) SELECT Obj_Name,REQUEST_ID,Type from s4_output_management where REQUEST_ID ="
				+ requestId;

		getAutoHANA().dataTransferToDownlaodTables(s4OutputManagement);

		String s4AffectCustom = "INSERT INTO s4_affect_custom_download (Obj_Name, REQUEST_ID, Trigger_Obj, Type, Replaced_By_CDS) SELECT Obj_Name, REQUEST_ID, "
				+ "Trigger_Obj, Type, Replaced_By_CDS from s4_affect_custom where REQUEST_ID =" + requestId;
		getAutoHANA().dataTransferToDownlaodTables(s4AffectCustom);

		String s4ImpactedTables = "INSERT INTO s4_impacted_tables_download(DESCRIPTION,Object,REQUEST_ID,SAP_NOTES,SOLUTION_STEPS) "
				+ "SELECT DESCRIPTION,Object,REQUEST_ID,SAP_NOTES,SOLUTION_STEPS from s4_impacted_tables where REQUEST_ID ="
				+ requestId;

		getAutoHANA().dataTransferToDownlaodTables(s4ImpactedTables);

		String impactedIDOC = "INSERT INTO S4_IMPACTED_IDOC_DOWNLOAD(IDOC_MSG_TYPE, IDOC_BASIC_TYPE, IDOC_SEGMENT, IMPACTED_OBJECT_TYPE, "
				+ "IMPACTED_OBJECT_NAME, DESCRIPTION, NOTE_NUMBER, SOLUTION, TYPE_OF_IDOC, REQUEST_ID) "
				+ "SELECT IDOC_MSG_TYPE, IDOC_BASIC_TYPE, IDOC_SEGMENT, IMPACTED_OBJECT_TYPE, "
				+ "IMPACTED_OBJECT_NAME, DESCRIPTION, NOTE_NUMBER, SOLUTION, TYPE_OF_IDOC, REQUEST_ID FROM S4_IMPACTED_IDOC where REQUEST_ID="
				+ requestId;
		getAutoHANA().dataTransferToDownlaodTables(impactedIDOC);

		String s4ImpactedTransaction = "INSERT INTO s4_impacted_transaction_download(AFFECTED_AREA,DESCRIPTION,IMPACTED_TRANSACTION,REQUEST_ID,SAP_NOTES,SOLUTION_STEPS) "
				+ "SELECT AFFECTED_AREA,DESCRIPTION,IMPACTED_TRANSACTION,REQUEST_ID,SAP_NOTES,SOLUTION_STEPS from s4_impacted_transaction where REQUEST_ID="
				+ requestId;

		getAutoHANA().dataTransferToDownlaodTables(s4ImpactedTransaction);

		String s4ImpactedSearch = "INSERT INTO s4_impacted_search_download(REQUEST_ID,search_data, OBJECT_TYPE, OBJECT_NAME, EXTERNAL_NAMESPACE) SELECT REQUEST_ID,search_data, OBJECT_TYPE, OBJECT_NAME, EXTERNAL_NAMESPACE from s4_impacted_search where REQUEST_ID="
				+ requestId;

		getAutoHANA().dataTransferToDownlaodTables(s4ImpactedSearch);

		String s4AppendStructure = "INSERT INTO s4_append_structure_download(FIELD_NAME,NAME_OF_INCLUDE,REQUEST_ID,TABLE_NAME)  "
				+ "SELECT FIELD_NAME,NAME_OF_INCLUDE,REQUEST_ID,TABLE_NAME from s4_append_structure where REQUEST_ID="
				+ requestId;
		getAutoHANA().dataTransferToDownlaodTables(s4AppendStructure);

		String s4CloneProgAnalysis = "INSERT INTO s4_clone_prog_analysis_download(Clone_prog,Description,Impacted_Prog,Related_Notes,REQUEST_ID,Solution_Step) "
				+ "SELECT Clone_prog,Description,Impacted_Prog,Related_Notes,REQUEST_ID,Solution_Step from s4_clone_prog_analysis where REQUEST_ID="
				+ requestId;
		getAutoHANA().dataTransferToDownlaodTables(s4CloneProgAnalysis);

		// DEF035
		String s4Enhancement = "INSERT INTO S4_Enhancement_Download (CLAS_NAME,ENHANCEMENT_TYPE,ENHANCEMENT_NAME,IMPLEMENTATION_NAME,REQUEST_ID) "
				+ "SELECT OBJECT_NAME,TYPE,ENHANCEMENT_NAME,IMPLEMENTATION_NAME,REQUEST_ID FROM S4_Enhancement where REQUEST_ID="
				+ requestId;
		getAutoHANA().dataTransferToDownlaodTables(s4Enhancement);

		String s4DetailReport = "INSERT INTO s4_detail_report_downlaod(AFFECT_OBJ_DESC,APP_COMPONENT,COMPLEXITY,DESC_OF_CHANGE,ERROR_CATEGORY,IDENTIFIER,IMPACT_REASON,"
				+ "IMPACTED_OBJ_TYPE,ISSUE_CATEGORY,ITEM_AREA,LINE_NO,METHOD,OBJ_NAME,OBJ_NAME_TYPE,OPERATIONS,PCKG,Remediation_Category,REQUEST_ID,"
				+ "SAP_NOTES,SAP_SIMP_LIST,SAP_SIMPL_CATEGORY,SOLUTION_STEPS,STMT,SUB_OBJ,TRIGGER_OBJ,OBJ_TYPE,USED) "
				+ "SELECT AFFECT_OBJ_DESC,APP_COMPONENT,COMPLEXITY,DESC_OF_CHANGE,ERROR_CATEGORY,IDENTIFIER,IMPACT_REASON,IMPACTED_OBJ_TYPE,"
				+ "ISSUE_CATEGORY,ITEM_AREA,LINE_NO,METHOD,OBJ_NAME,OBJ_NAME_TYPE,OPERATIONS,PCKG,Remediation_Category,REQUEST_ID,SAP_NOTES,"
				+ "SAP_SIMP_LIST,SAP_SIMPL_CATEGORY,SOLUTION_STEPS,STMT,SUB_OBJ,TRIGGER_OBJ,OBJ_TYPE,USED from s4_detail_report where REQUEST_ID="
				+ requestId;
		getAutoHANA().dataTransferToDownlaodTables(s4DetailReport);

		String s4DetailReportRemdi = "INSERT INTO s4_detail_report_remedi_download(AFFECT_OBJ_DESC,APP_COMPONENT,COMPLEXITY,DESC_OF_CHANGE,"
				+ "ERROR_CATEGORY,IDENTIFIER,IMPACT_REASON,IMPACTED_OBJ_TYPE,ISSUE_CATEGORY,ITEM_AREA,LINE_NO,METHOD,OBJ_NAME,OPERATIONS,"
				+ "PCKG,Remediation_Category,REQUEST_ID,SAP_NOTES,SAP_SIMP_LIST,SAP_SIMPL_CATEGORY,SOLUTION_STEPS,STMT,SUB_OBJ,TRIGGER_OBJ,OBJ_TYPE,USED)"
				+ "  SELECT AFFECT_OBJ_DESC,APP_COMPONENT,COMPLEXITY,DESC_OF_CHANGE,ERROR_CATEGORY,IDENTIFIER,IMPACT_REASON,IMPACTED_OBJ_TYPE,"
				+ "ISSUE_CATEGORY,ITEM_AREA,LINE_NO,METHOD,OBJ_NAME,OPERATIONS,PCKG,Remediation_Category,REQUEST_ID,SAP_NOTES,SAP_SIMP_LIST,"
				+ "SAP_SIMPL_CATEGORY,SOLUTION_STEPS,STMT,SUB_OBJ,TRIGGER_OBJ,OBJ_TYPE,USED from s4_detail_report_remedi where REQUEST_ID= "
				+ requestId;
		getAutoHANA().dataTransferToDownlaodTables(s4DetailReportRemdi);

		String sModilogFunctionReport = "INSERT INTO smodilogfunction_download(OBJ_TYPE, OBJ_NAME, SUB_TYPE, SUB_NAME, "
				+ "INT_TYPE, INT_NAME, MOD_USER, MOD_DATE, MOD_TIME, TRKORR, SPDD_Objects, SPAU_Objects, Request_Id) "
				+ "SELECT OBJ_TYPE, OBJ_NAME, SUB_TYPE, SUB_NAME, INT_TYPE, INT_NAME, MOD_USER, MOD_DATE, MOD_TIME, "
				+ "TRKORR, SPDD_Objects, SPAU_Objects, Request_Id " + "from smodilogfunction where Request_Id="
				+ requestId + " GROUP BY CONCAT(OBJ_TYPE,OBJ_NAME,SUB_TYPE,SUB_NAME)";
		getAutoHANA().dataTransferToDownlaodTables(sModilogFunctionReport);

		// Impacted Scripts
		String imapctedScriptsDownload = "INSERT INTO Impacted_Scripts_Download "
				+ "(OBJ_TYPE, PROGRAM, Impacted_SAP_Scripts, REMEDIATION_CATEGORY, OPERCD, DB_Impact, S4_Simplification, Existing_Errors, "
				+ "EXTERNAL_NAMESPACE, REQUEST_ID) "
				+ "SELECT DISTINCT OBJ_TYPE, OBJ_NAME, ACT_STATUS, REMEDIATION_CATEGORY, OPERCD, DB_Impact, S4_Simplification, Existing_Errors, "
				+ "EXTERNAL_NAMESPACE, REQUEST_ID " + "FROM Impacted_Scripts WHERE REQUEST_ID = " + requestId;
		getAutoHANA().dataTransferToDownlaodTables(imapctedScriptsDownload);

		// S4 CVITR
		String cvitrDownload = "INSERT INTO S4_CVITR_Download "
				+ "(COMMENTS, COMMENT_C, SELECT_LINE, IDENTIFIER, REQUEST_ID, NEW_LINE, VENDOR_EXTERNAL, CUSTOMER_EXTERNAL) "
				+ "SELECT  COMMENTS, COMMENT_C, SELECT_LINE, IDENTIFIER, REQUEST_ID, NEW_LINE, VENDOR_EXTERNAL, CUSTOMER_EXTERNAL "
				+ "from S4_CVITR where REQUEST_ID=" + requestId;
		getAutoHANA().dataTransferToDownlaodTables(cvitrDownload);

		// OS Migration Data Transfer
		// Opcode 201,202,203
		// OSMIGRATION_FINAL_DOWNLOAD
		String osMigrationDownload = "INSERT INTO  OSMIGRATION_FINAL_DOWNLOAD "
				+ "(REQUEST_ID, OBJ_TYPE, OBJ_NAME, OBJ_TYPE_NAME, SUB_TYPE, READ_PROGRAM, OBJ_PACKAGE, OPERCD, LINE_NO, STATEMENT, INFO, "
				+ "SKIP, SKIP_REASON, SELECT_LINE, REM_CATEGORY, ISSUE_CATEGORY, ISSUE_SUBCATEGORY, HIGH_LVL_DESC, IMPACT, "
				+ "AUTOMATION_STATUS, COMPLEXITY, USED, RICEF_CATEGORY,RICEF_SUB_CATEGORY, EXTERNAL_NAMESPACE) "
				+ "SELECT DISTINCT REQUEST_ID, OBJ_TYPE, OBJ_NAME, OBJ_TYPE_NAME, SUB_TYPE, READ_PROGRAM, OBJ_PACKAGE, OPERCD, LINE_NO, STATEMENT, INFO, "
				+ "SKIP, SKIP_REASON, SELECT_LINE, REM_CATEGORY, ISSUE_CATEGORY, ISSUE_SUBCATEGORY, HIGH_LVL_DESC, IMPACT, "
				+ "AUTOMATION_STATUS, COMPLEXITY, USED, RICEF_CATEGORY,RICEF_SUB_CATEGORY, EXTERNAL_NAMESPACE FROM OSMIGRATION_FINAL WHERE REQUEST_ID="
				+ requestId;
		getAutoHANA().dataTransferToDownlaodTables(osMigrationDownload);

		// Opcode 205
		// OSMIGRATION_FINAL_LOGICAL_CMD_DOWNLOAD
		osMigrationDownload = "INSERT INTO OSMIGRATION_FINAL_LOGICAL_CMD_DOWNLOAD "
				+ "(REQUEST_ID, READ_PROGRAM, STATEMENT, INFO, REM_CATEGORY, ISSUE_CATEGORY, ISSUE_SUBCATEGORY, HIGH_LVL_DESC, IMPACT, "
				+ "AUTOMATION_STATUS, COMPLEXITY) SELECT DISTINCT REQUEST_ID, READ_PROGRAM, STATEMENT, INFO, REM_CATEGORY, ISSUE_CATEGORY, ISSUE_SUBCATEGORY, HIGH_LVL_DESC, IMPACT, "
				+ "AUTOMATION_STATUS, COMPLEXITY FROM OSMIGRATION_FINAL_LOGICAL_CMD_INTERMEDIATE WHERE REQUEST_ID="
				+ requestId;
		getAutoHANA().dataTransferToDownlaodTables(osMigrationDownload);

		// Opcode 204
		// OSMIGRATION_FINAL_FILE_PATH_DOWNLOAD
		osMigrationDownload = "INSERT INTO OSMIGRATION_FINAL_FILE_PATH_DOWNLOAD "
				+ "(REQUEST_ID, OBJ_NAME, SUB_TYPE, STATEMENT, INFO, SKIP, SKIP_REASON, REM_CATEGORY, HIGH_LVL_DESC, IMPACT) "
				+ "SELECT DISTINCT REQUEST_ID, OBJ_NAME, SUB_TYPE, STATEMENT, INFO, SKIP, SKIP_REASON, REM_CATEGORY, HIGH_LVL_DESC, IMPACT "
				+ "FROM OSMIGRATION_FINAL_FILE_PATH_INTERMEDIATE WHERE REQUEST_ID=" + requestId;
		getAutoHANA().dataTransferToDownlaodTables(osMigrationDownload);

		// Impacted Clone Data Transfer
		String impactedCloneDownload = "INSERT INTO IMPACTED_CLONE_ANALYSIS_DOWNLOAD "
				+ "(REQUEST_ID, APPLICATION_COMPONENT, CREATION_DATE, IMPACTED_DUE_TO_DB_CHANGE, IMPACTED_DUE_TO_EXISTING_ERRORS, IMPACTED_DUE_TO_OS_MIGRATION, IMPACTED_DUE_TO_SIMPLIFICATION, INTERFACE, INTERFACE_OBJECT_TYPE, NAMESPACE, OBJECT_NAME, PACKAGE, OBJECT_TYPE, OBJ_TYPE_NAME, REFERENCE, REFERENCE_PERCENT, USED, YEAR, INTERFACE_CONCATENATED, EXTERNAL_NAMESPACE, EXEC_DATE, EXEC_TIME) "
				+ "SELECT REQUEST_ID, APPLICATION_COMPONENT, CREATION_DATE, IMPACTED_DUE_TO_DB_CHANGE, IMPACTED_DUE_TO_EXISTING_ERRORS, IMPACTED_DUE_TO_OS_MIGRATION, IMPACTED_DUE_TO_SIMPLIFICATION, INTERFACE, INTERFACE_OBJECT_TYPE, NAMESPACE, OBJECT_NAME, PACKAGE, OBJECT_TYPE, OBJ_TYPE_NAME, REFERENCE, REFERENCE_PERCENT, USED, YEAR, INTERFACE_CONCATENATED, EXTERNAL_NAMESPACE, EXEC_DATE, EXEC_TIME "
				+ "FROM IMPACTED_CLONE_ANALYSIS WHERE REQUEST_ID=" + requestId;
		getAutoHANA().dataTransferToDownlaodTables(impactedCloneDownload);

		// Inconsistent FUGR
		String inconsistentFUGRDownload = "INSERT INTO Inconsistent_FUGR_Download "
				+ "(Request_ID, Object_Type, FUGR_Name, Master_Program, External_Namespace) SELECT DISTINCT Request_ID, Object_Type, FUGR_Name, Master_Program, External_Namespace"
				+ " FROM Inconsitent_FUGR WHERE Request_ID=" + requestId;
		getAutoHANA().dataTransferToDownlaodTables(inconsistentFUGRDownload);

		// S4 SID
		String s4SIDDownload = "INSERT INTO S4_SID_Download "
				+ "(REQUEST_ID, OBJ_NAME, SUB_OBJ_TYPE, PCKG, USED, TYPE, LINE_NO, STMT, OPERATIONS, IMPACT_REASON, DESC_OF_CHANGE, SOLUTION_STEPS, Complexity, ISSUE_CATEGORY, Total_Scanned_Line, OBJ_NAME_TYPE, READ_PROG"
				+ ", Automation_Status, EXTERNAL_NAMESPACE) SELECT DISTINCT REQUEST_ID, OBJ_NAME, SUB_OBJ_TYPE, PCKG, USED, TYPE, LINE_NO, STMT, OPERATIONS, IMPACT_REASON, DESC_OF_CHANGE, SOLUTION_STEPS, Complexity, ISSUE_CATEGORY, Total_Scanned_Line, OBJ_NAME_TYPE, READ_PROG"
				+ ", Automation_Status, EXTERNAL_NAMESPACE FROM S4_SID WHERE REQUEST_ID=" + requestId;
		getAutoHANA().dataTransferToDownlaodTables(s4SIDDownload);

		// Variant Utility
		String variantUtilityDownload = "INSERT INTO Impacted_Variant_Download "
				+ "(Request_ID, Report_Name, Variant_Name, Selection_Screen_Field_Name, Kind, Sign, Low, High, Variant_Option, User_Name, Variant_Type, "
				+ "Comments, Variant_Operation, EXTERNAL_NAMESPACE) SELECT DISTINCT Request_ID, Report_Name, Variant_Name, Selection_Screen_Field_Name, Kind, Sign, Low, High, Variant_Option, User_Name, Variant_Type, "
				+ "Comments, Variant_Operation, EXTERNAL_NAMESPACE FROM Impacted_Variant WHERE Request_ID=" + requestId;
		getAutoHANA().dataTransferToDownlaodTables(variantUtilityDownload);

		// Bw Clean Up Utility
		String bwCleanUpUtility = "INSERT INTO Bw_Cleanup_Util_Download "
				+ "(Object_Type, Object_Name, Last_Used, Elapsed_Time_Year, Status,Request_ID) SELECT DISTINCT Object_Type, Object_Name, Last_Used, Elapsed_Time_Year, Status,Request_ID"
				+ " FROM Bw_Cleanup_Util WHERE Request_ID=" + requestId;
		getAutoHANA().dataTransferToDownlaodTables(bwCleanUpUtility);

		// Bw standard Extract
		String bwStdExtr = "insert into BW_STD_EXTR_Download (obj_name,phase,area_responsibility,data_source,app_component,classification,category,restrictions,related_simplification_item,note,del_1511,del_1610,delta_restrict,comments,Request_Id) select obj_name,phase,area_responsibility,data_source,app_component,classification,category,restrictions,related_simplification_item,note,del_1511,del_1610,delta_restrict,comments,Request_Id from BW_STANDARD_EXTRACT where Request_Id="
				+ requestId;
		getAutoHANA().dataTransferToDownlaodTables(bwStdExtr);

		// Bw standard Extract
		String inactiveObjs = "insert into Inactive_Objects_Download (OBJECT, OBJ_NAME, UNAME, DELET_FLAG, Request_Id, TAB_CLASS) select OBJECT, OBJ_NAME, UNAME, DELET_FLAG, Request_Id, TAB_CLASS from Inactive_Objects where Request_Id="
				+ requestId;
		getAutoHANA().dataTransferToDownlaodTables(inactiveObjs);

		// Impacted backgroud job
		String impactedBackJob = "INSERT INTO Impacted_Background_Job_Download (OBJECT,BACKGROUND_JOB_NAME,PROGRAM_NAME,VARIANT,TCODE,RUN,Request_Id,External_Namespace) SELECT OBJECT,OBJECT_NAME,SUB_TYPE,READ_PROG,OBJ_PACKAGE,ACT_STATUS,Request_Id,External_Namespace from Impacted_Background_Job where Request_Id="
				+ requestId;
		getAutoHANA().dataTransferToDownlaodTables(impactedBackJob);

		// Unicode data transfer
		if ("No".equalsIgnoreCase(requestForm.getUnicodeCompliant())
				&& "YES".equalsIgnoreCase(requestForm.getEnableUnicode())) {
			String unicodeData = "Insert into UNICODE_OUTPUT(Original_System, Program, Include, Roww, Error_Code, Created_By, Pack, "
					+ "Pack_Per_Resp, Concat_Col, Application_Component, Message, Request_Id, External_Namespace) "
					+ "SELECT Original_System, Program, Include, Roww, Error_Code, Created_By, Pack, Pack_Per_Resp, "
					+ "Concat_Col, Application_Component, Message, Request_Id, External_Namespace "
					+ "from UNICODE_Intermediate where Request_Id=" + requestId;
			getAutoHANA().dataTransferToDownlaodTables(unicodeData);
		}

		// S4 cvit customising logs
		String cvitCustomLogs = "insert into Cvit_CustomisingLogs_Download "
				+ "(Object_Name, Customising_Errors, Text, Customer_Count, Vendor_Count, Customer_Logs, Vendor_Logs, Request_Id) "
				+ "select Object_Name, Customising_Errors, Text, Customer_Count, Vendor_Count, Customer_Logs, Vendor_Logs, Request_Id "
				+ "from Cvit_CustomisingLogs where Request_Id = " + requestId;
		getAutoHANA().dataTransferToDownlaodTables(cvitCustomLogs);

		// S4 cvit customising logs
		String cvitErrorMsgs = "insert into Cvit_ErrorMessages_Download "
				+ "(Run_Id, Indicator, Customer_Vendor, Field_Name, Error_Log, Request_Id) "
				+ "select Run_Id, Indicator, Customer_Vendor, Field_Name, Error_Log, Request_Id "
				+ "from Cvit_ErrorMessages where Request_Id = " + requestId;
		getAutoHANA().dataTransferToDownlaodTables(cvitErrorMsgs);

		logger.info("............Ended Data transfer from transaction tables to download/Reporting tables.......");
	}

	protected void DataTransferFiori(final long requestId) throws Exception {
		logger.info(
				"............Started Data transfer fiori from transaction tables to download/Reporting tables.......");

		String inventoryListFioriOld = "INSERT INTO Inventory_Standard_Fiori (Object, AppId, App_Name, REQUEST_ID, Availability, Obj_Name, Version, Alternate_Name, SuccessorAppId, RelatedAppId) "
				+ "SELECT Object, AppId, App_Name, REQUEST_ID, Availability, Obj_Name, Version, Alternate_Name, SuccessorAppId, RelatedAppId from Inventory_Std_Fiori_Intermediate where REQUEST_ID="
				+ requestId;

		getAutoHANA().dataTransferToDownlaodTables(inventoryListFioriOld);

		logger.info("............Ended Data transfer from transaction tables to download/Reporting tables.......");
	}

	protected void DataTransferFioriNew(final long requestId) throws Exception {
		logger.info(
				"............Started Data transfer fiori from transaction tables to download/Reporting tables.......");

		// add component
		String inventoryListFioriNew = "INSERT INTO Custom_Report_Output_download (Fiori_ID, Availability, REQUEST_ID, Version, Alternate_Name, PVBackendCombined, SuccessorApp, RelatedApp, App_Name, TechnicalCatalogId, Technicalcatalogtitle, SemanticObjectAction, LaunchpadApplicationType, LaunchpadApplicationName, StatusOfTheApplication, FlagForCustomApplication,Component) "
				+ "SELECT Fiori_ID, Availability, REQUEST_ID, Version, Alternate_Name, PVBackendCombined, SuccessorApp, RelatedApp, App_Name, TechnicalCatalogId, Technicalcatalogtitle, SemanticObjectAction, LaunchpadApplicationType, LaunchpadApplicationName, StatusOfTheApplication, FlagForCustomApplication,Component from Custom_Report_Output where REQUEST_ID="
				+ requestId;
		getAutoHANA().dataTransferToDownlaodTables(inventoryListFioriNew);

		logger.info("............Ended Data transfer from transaction tables to download/Reporting tables.......");
	}

	protected String clientFileProcessingBusinessLogicHana(final long requestID, HttpServletRequest request,
			final String toolName, HttpSession session) throws Exception {

		String comments = "";
		String status = "";
		Hana_Profiler_Constant.REQUEST_PROGRESS_MAP.remove(requestID);

		HANAUtility.changeRequestProgressValue(requestID, 0, "Analysis is in progress.");

		String systemStatus = getAutoHANA().getSystemStatus(requestID);
		String businessStatus = HANAUtility.getBusinessStatus(systemStatus);

		status = Hana_Profiler_Constant.IDVSUCESS_STATUS;
		comments = Hana_Profiler_Constant.IDVSUCCESS_STATUS_COMMENT;

		logger.info("Inside Client File Processing method: Hana ");

		long st03StartTime = 0, st03EndTime = 0, HANAStartTime = 0, HANAEndTime = 0;
		long RefineStartTime = 0, RefineEndTime = 0, totalRefineTime = 0;

		boolean st03Status = false;
		boolean genearteHANASheetStatus = false;
		boolean refiningSheetStatus = false;

		if (Hana_Profiler_Constant.IDVSUCESS_STATUS.equalsIgnoreCase(systemStatus)
				|| Hana_Profiler_Constant.ST03FAILED_STATUS.equalsIgnoreCase(systemStatus)) {

			if (Hana_Profiler_Constant.ST03FAILED_STATUS.equalsIgnoreCase(systemStatus)) {
				status = Hana_Profiler_Constant.ST03FAILED_STATUS;
				comments = Hana_Profiler_Constant.ST03FAILED_STATUS_COMMENT;

			}
			st03StartTime = System.currentTimeMillis();

			st03Status = getSt03DataAnalysis().analyseST03Data(requestID, toolName, session);// 16273

			st03EndTime = System.currentTimeMillis();
			if (st03Status) {
				status = Hana_Profiler_Constant.ST03SUCCESS_STATUS;
				comments = Hana_Profiler_Constant.ST03SUCCESS_STATUS_COMMENT;

			} else {
				status = Hana_Profiler_Constant.ST03FAILED_STATUS;
				comments = "HANA:" + Hana_Profiler_Constant.ST03FAILED_STATUS_COMMENT;

			}

		}
		/*
		 * if (st03Status ||
		 * Hana_Profiler_Constant.ST03SUCCESS_STATUS.equalsIgnoreCase(
		 * systemStatus) ||
		 * Hana_Profiler_Constant.HANAQUERYFAILED_STATUS.equalsIgnoreCase(
		 * systemStatus)) {
		 * 
		 * HANAStartTime = System.currentTimeMillis();
		 * 
		 * genearteHANASheetStatus =
		 * getGenerateHANAFinalSheet().executeGenerateHanaFinalSheet(requestID);
		 * // 1226 HANAEndTime = System.currentTimeMillis();
		 * 
		 * if (genearteHANASheetStatus) { status =
		 * Hana_Profiler_Constant.HANAQUERYSUCCESS_STATUS; comments =
		 * Hana_Profiler_Constant.HANAQUERYSUCCESS_STATUS_COMMENT;
		 * 
		 * } else { status = Hana_Profiler_Constant.HANAQUERYFAILED_STATUS;
		 * comments = Hana_Profiler_Constant.HANAQUERYFAILED_STATUS_COMMENT;
		 * 
		 * }
		 * 
		 * }
		 */

		if (st03Status || Hana_Profiler_Constant.ST03SUCCESS_STATUS.equalsIgnoreCase(systemStatus)
				|| Hana_Profiler_Constant.HANAQUERYFAILED_STATUS.equalsIgnoreCase(systemStatus)) {
			RefineStartTime = System.currentTimeMillis();

			refiningSheetStatus = getDaoIntf().getHanaProfilerFinalList(requestID, requestForm.getClientName(),
					session);// 1632

			RefineEndTime = System.currentTimeMillis();
			if (refiningSheetStatus) {
				status = Hana_Profiler_Constant.REFININGSUCCESS_STATUS;
				comments = Hana_Profiler_Constant.REFININGSUCCESS_STATUS_COMMENT;

				Hana_Profiler_Constant.ID_FILE_KEY_VALUE.remove(requestID);

			} else {
				status = Hana_Profiler_Constant.HANAREFININGFAILED_STATUS;
				comments = Hana_Profiler_Constant.HANAREFININGFAILED_STATUS_COMMENT;

			}

		}

		// getRequestInventorydao().updateSatus(requestID, status,
		// getPrincipal(),
		// comments, toolName);
		// getRequestInventorydao().updateSatus(requestID, status,
		// getPrincipal(),
		// comments, toolName);
		/* CR-1.0 Monika */
		if (Hana_Profiler_Constant.REFININGSUCCESS_STATUS.equals(status)) {

			logger.info("In side If Success:::HANAREFININGSUCCESS_STATUS ");

			getDaoIntf().deleteDuplicateRecords(requestID);
			logger.info("Going to send mail::: ");
		} else {
			throw new Exception("Something unexpected happened");
		}

		// HANAUtility.changeRequestProgressValue(requestID, 25, "HANA
		// Processing
		// Done");

		long totalST03Time = st03EndTime - st03StartTime;
		long totalHANATime = HANAEndTime - HANAStartTime;
		totalRefineTime = RefineStartTime - RefineEndTime;

		logger.info("Total time in ST03 ANALYSIS=" + totalST03Time);
		logger.info("Total time in HANA PROFILER STEP=" + totalHANATime);
		logger.info("Total time in refining data ::" + totalRefineTime);

		return status;

	}

	protected String clientFileProcessingBusinessLogicS4(final long requestID, HttpServletRequest request,
			final String toolName, HttpSession session) throws Exception {

		String comments = "";
		Hana_Profiler_Constant.REQUEST_PROGRESS_MAP.remove(requestID);
		String status = "";

		logger.info("Inside Client File Processing method  --S4 ");
		boolean refiningSheetStatus = false;
		long RefineStartTime = 0, RefineEndTime = 0, totalRefineTime = 0;

		RefineStartTime = System.currentTimeMillis();

		refiningSheetStatus = getS4DaoIntf().getS4HanaProfilerFinalList(requestID,
				getRequestDetails().getRequestObj(requestID), session);// 1632

		RefineEndTime = System.currentTimeMillis();
		if (refiningSheetStatus) {
			status = Hana_Profiler_Constant.REFININGSUCCESS_STATUS;
			comments = Hana_Profiler_Constant.REFININGSUCCESS_STATUS_COMMENT;
			Hana_Profiler_Constant.ID_FILE_KEY_VALUE.remove(requestID);

		} else {
			status = Hana_Profiler_Constant.REFININGFAILED_STATUS;
			comments = Hana_Profiler_Constant.REFININGFAILED_STATUS_COMMENT;
			HANAUtility.changeRequestProgressValue(requestID, Hana_Profiler_Constant.FAILED_PROCESS_PERCENT_VALUE,
					"S4:" + Hana_Profiler_Constant.REFINING_PROCESS_FAILED_MSG);
			// getRequestInventorydao().updateSatus(requestID, status,
			// getPrincipal(),
			// comments, toolName);
			throw new Exception("Something unexpected happened");
		}

		// HANAUtility.changeRequestProgressValue(requestID, 50, "S4 Processing
		// Done");

		// getRequestInventorydao().updateSatus(requestID, status,
		// getPrincipal(),
		// comments, toolName);

		totalRefineTime = RefineStartTime - RefineEndTime;

		logger.info("Total time in refining S4 data ::" + totalRefineTime);

		return status;

	}

	public String clientFileProcessingBusinessLogicUI5(Long requestID, HttpServletRequest request, String toolName,
			HttpSession session, List<UI5InputExtract> inputUI5ExtractList) throws Exception {

		List<UI5InputExtract> listByProject = null;
		int totalApisperProject = 0;
		// List<UI5FinalOutput> finalUI5ReportList = new
		// ArrayList<UI5FinalOutput>();
		String statusOne = "";
		String comments = "";
		logger.info("Inside Client File Processing method::::::::: UI5 ");

		String depricated = "This UI5 control is deprecated. There is no compatibility issue but, it is recommended to be rewritten";
		String removed = "This UI5 control is removed from library. Replacement of API is required";
		String warning = "Warning";
		String error = "Error";
		String condition = null;

		final RequestForm requestForm = getRequestDetails().getRequestObj(requestID);
		oldVersion = requestForm.getOldVersion();
		newVersion = requestForm.getNewVersion();
		// String sourceVersion = requestForm.getOldVersion();
		// String targetVersion = requestForm.getNewVersion();
		// String sourceVersion = "1.20";
		// oldVersion = "1.21";
		// newVersion = "1.23";

		try {
			String deperecatedjson = "/rules/deprecated.json";
			InputStream resourceAsStream = getClass().getResourceAsStream(deperecatedjson);
			Reader reader = new InputStreamReader(resourceAsStream);
			JSONParser jsonParser = new JSONParser();
			Object obj = jsonParser.parse(reader);
			JSONObject apiList1 = (JSONObject) obj;

			int depCount = 0;
			int repCount = 0;
			int remCount = 0;
			UI5FinalOutput ui5Out = null;

			// finalUI5ReportList = new ArrayList<UI5FinalOutput>();
			Map<String, List<UI5InputExtract>> listByProjectNameMap = new HashMap<>();
			listByProjectNameMap = inputUI5ExtractList.stream()
					.collect(Collectors.groupingBy(UI5InputExtract::getProjectName));
			Set<String> projectNamekeys = listByProjectNameMap.keySet();
			listOfHighLevelReport = new ArrayList<UI5HighLevelReport>();
			// below array need to have all the versions what SAP is providing
			String[] JsonVerson = { "0.15", "0.17", "1.0", "1.1", "1.3", "1.4", "1.5", "1.6", "1.7", "1.9", "1.1",
					"1.11", "1.12", "1.13", "1.14", "1.15", "1.16", "1.17", "1.18", "1.19", "1.20", "1.21", "1.22",
					"1.23", "1.24", "1.25", "1.26", "1.27", "1.28", "1.29", "1.30", "1.31", "1.32", "1.33", "1.34",
					"1.35", "1.36", "1.37", "1.38", "1.39", "1.40", "1.42", "1.44", "1.45", "1.46", "1.48", "1.50",
					"1.51", "1.52", "1.54", "1.56", "1.57", "1.58", "1.60", "1.61", "1.62", "1.64", "1.65", "1.66",
					"1.67", "1.68", "1.69", "1.70", "1.72", "1.73", "1.74", "1.75", "1.76", "1.77", "1.78", "1.80",
					"1.81", "7.20" };

			int sourceIndex = findIndex(JsonVerson, String.valueOf(oldVersion));
			int targetIndex = findIndex(JsonVerson, String.valueOf(newVersion));
			logger.info("source version index : " + sourceIndex);
			logger.info("Target version index : " + targetIndex);

			// String[] rangeVersion = Arrays.copyOfRange(JsonVerson,
			// sourceIndex,
			// targetIndex+1);

			String[] rangeVersion = Arrays.copyOfRange(JsonVerson, sourceIndex, targetIndex + 1);
			logger.info("version Range Array :" + rangeVersion);
			String status = null;
			for (String key : projectNamekeys) {
				totalApisperProject = 0;
				listByProject = listByProjectNameMap.get(key);
				totalApisperProject = listByProject.size();
				for (UI5InputExtract ue : listByProject) {
					logger.info("UI Element***************** : " + ue.getUielemt() + " for the project : " + key);
					for (String version : rangeVersion) {
						JSONObject api1 = null;
						JSONArray apiArray1 = null;
						api1 = (JSONObject) apiList1.get(String.valueOf(version));
						if (api1 != null && api1.size() > 0) {
							apiArray1 = (JSONArray) api1.get("apis");
							for (int j = 0; j < apiArray1.size(); j++) {
								status = "";
								JSONObject Json = (JSONObject) apiArray1.get(j);
								if (Json.get("control") != null && Json.get("control").toString().trim()
										.equalsIgnoreCase((ue.getUielemt().trim()))) {
									if (Json.get("type").equals("class")) {
										if (Json.get("text").toString().indexOf("will be removed") != -1) {
											remCount++;
											status = error;
											condition = removed;
											populateFinalReportList(ue, Json, status, ui5Out, condition);
										} else {
											status = warning;
											condition = depricated;
											populateFinalReportList(ue, Json, status, ui5Out, condition);
										}

										if ((String.valueOf(Json.get("text")).indexOf("replaced") != -1)
												|| (String.valueOf(Json.get("text")).indexOf("instead") != -1)
												|| (String.valueOf(Json.get("text")).indexOf("Please use") != -1)
												|| (String.valueOf(Json.get("text")).indexOf("recommend") != -1)

										) {
											repCount++;
										}
										depCount++;
									}
									if (ue.getAttribute() != null || !ue.getAttribute().isEmpty()) {
										String[] attributes = null;
										if (ue.getAttribute().indexOf(";") != -1) {
											attributes = ue.getAttribute().toString().trim().split(";");
											for (String i : attributes) {
											}
										} else {
											attributes = new String[1];
											attributes[0] = ue.getAttribute().toString();
										}
										for (String s : attributes) {
											if (Json.get("type").equals("methods")) {
												if (s.equals(Json.get("entityName").toString())) {
													if (Json.get("text").toString().indexOf("will be removed") != -1) {
														remCount++;
														status = error;
														condition = removed;
														populateFinalReportList(ue, Json, status, ui5Out, condition);
													} else {
														status = warning;
														condition = depricated;
														populateFinalReportList(ue, Json, status, ui5Out, condition);
													}
													if ((String.valueOf(Json.get("text")).indexOf("replaced") != -1)
															|| (String.valueOf(Json.get("text"))
																	.indexOf("instead") != -1)
															|| (String.valueOf(Json.get("text"))
																	.indexOf("Please use") != -1)
															|| (String.valueOf(Json.get("text"))
																	.indexOf("recommend") != -1)

													) {
														repCount++;
													}
													depCount++;
												}
											}
											if (Json.get("type").equals("events")) {

												if (s.equals(Json.get("entityName").toString())) {
													if (Json.get("text").toString().indexOf("will be removed") != -1) {
														remCount++;
														status = error;
														condition = depricated;
														populateFinalReportList(ue, Json, status, ui5Out, condition);
													} else {
														status = warning;
														condition = depricated;
														populateFinalReportList(ue, Json, status, ui5Out, condition);
													}
													if ((String.valueOf(Json.get("text")).indexOf("replaced") != -1)
															|| (String.valueOf(Json.get("text"))
																	.indexOf("instead") != -1)
															|| (String.valueOf(Json.get("text"))
																	.indexOf("Please use") != -1)
															|| (String.valueOf(Json.get("text"))
																	.indexOf("recommend") != -1)

													) {
														repCount++;
													}

													depCount++;
												}

											}

										}

									}
								}
							} // Json Array for loop
						} else {
							logger.info("No source version found");
						}
					}
				} // outer for loop for UI5 Extract
				highlvlReport = new UI5HighLevelReport();
				highlvlReport.setProjectName(key);
				highlvlReport.setDepricatedApiCounts(depCount);
				highlvlReport.setNonValidApiCounts(remCount);
				highlvlReport.setRecommendedChangesApiCounts(repCount);
				highlvlReport.setTotalApiCounts(totalApisperProject);
				if (depCount > 1) {
					if (remCount > 0) {
						highlvlReport
								.setFinalMessage("Source code needs changes to be compatible with target UI5 library");
					} else {
						highlvlReport.setFinalMessage(
								"Source code is compatible, however changes are recommended before Migration");
					}
				} else {
					highlvlReport.setFinalMessage("Source code is compatible with target UI5 library");
				}
				listOfHighLevelReport.add(highlvlReport);
				depCount = 0;
				repCount = 0;
				remCount = 0;
			} // outer loop for the Map by project name

			UI5BatchInsertFinalList(finalUI5ReportList, session, requestID);
			UI5BatchInsertFinalHighLevelReportList(listOfHighLevelReport, session, requestID);
		} catch (FileNotFoundException e) {
			logger.error("Error in clientFileProcessingBusinessLogicUI5 :: ", e);
		} catch (IOException e) {
			logger.error("Error in clientFileProcessingBusinessLogicUI5 :: ", e);
		} catch (ParseException e) {
			logger.error("Error in clientFileProcessingBusinessLogicUI5 :: ", e);
		} catch (Exception e) {
			logger.error("Error in clientFileProcessingBusinessLogicUI5 :: ", e);
		}
		// HANAUtility.changeRequestProgressValue(requestID, 85, "UI5 Processing
		// Done");
		// statusOne = Hana_Profiler_Constant.REFININGSUCCESS_STATUS;
		// comments = Hana_Profiler_Constant.REFININGSUCCESS_STATUS_COMMENT;
		// getRequestInventorydao().updateSatus(requestID, statusOne,
		// getPrincipal(),
		// comments, toolName);
		return statusOne;

	}

	/**
	 * This method populates the object for detail Report after iterating on
	 * input extract list
	 * 
	 * @param ue
	 *            Input Extract list
	 * @param json
	 *            Extracted Json based on the matching condition
	 * @param status
	 *            Error or Warning
	 * @param ui5Out
	 *            the object to be populated for Detail report
	 * @param condition
	 *            String indicates whether this control has been deprecated or
	 *            replaced or removed
	 */
	private void populateFinalReportList(UI5InputExtract ue, JSONObject json, String status, UI5FinalOutput ui5Out,
			String condition) {
		ui5Out = new UI5FinalOutput();
		ui5Out.setUielemt(ue.getUielemt());
		ui5Out.setVersion(String.valueOf(json.get("since")));
		ui5Out.setLinenumber(ue.getLinenumber());
		ui5Out.setDescription(String.valueOf(json.get("text")));
		ui5Out.setType(String.valueOf(json.get("type")));
		ui5Out.setProjectName(ue.getProjectName());
		ui5Out.setStatus(status);
		ui5Out.setMessage(condition);
		finalUI5ReportList.add(ui5Out);

	}

	// Function to find the index of an element
	public static int findIndex(String arr[], String item) {

		// int index = Arrays.binarySearch(arr, t);
		// return (index < 0) ? -1 : index;

		for (int i = 0; i < arr.length; i++) {
			if ((item.trim()).equals(arr[i]))
				return i;
		}
		return -1;

	}

	public static String UI5BatchInsertFinalList(List<UI5FinalOutput> finalUI5ReportList, HttpSession session,
			Long requestID) throws SQLException {

		final String INSERT_SQL = "INSERT INTO UI5_FINAL_OUTPUT "
				+ "(UI_Element, REQUEST_ID, Attribute, Type, Description, Version, LineNumber, ProjectName, FileName, Status, Message, Api_Reference) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (UI5FinalOutput ui5 : finalUI5ReportList) {

					stmt.setString(1, ui5.getUielemt());
					stmt.setLong(2, requestID);
					stmt.setString(3, ui5.getAttribute());
					stmt.setString(4, ui5.getType());
					stmt.setString(5, ui5.getDescription());
					stmt.setString(6, ui5.getVersion());
					stmt.setInt(7, ui5.getLinenumber());
					stmt.setString(8, ui5.getProjectName());
					stmt.setString(9, ui5.getFilename());
					stmt.setString(10, ui5.getStatus());
					stmt.setString(11, ui5.getMessage());
					stmt.setString(12, "");

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 1000 records
					if (counter % 1000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("UI5 Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	public static String UI5BatchInsertFinalHighLevelReportList(List<UI5HighLevelReport> listOfHighLevelReport,
			HttpSession session, Long requestID) throws SQLException {

		final String INSERT_SQL = "INSERT INTO UI5_REPORT "
				+ "(ProjectName, REQUEST_ID, Total_API_Counts, Depricated_API_Counts, NonValid_API_Counts, Recommented_Changes_API_Counts, Final_Message) values (?, ?, ?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (UI5HighLevelReport ui5 : listOfHighLevelReport) {

					stmt.setString(1, ui5.getProjectName());
					stmt.setLong(2, requestID);
					stmt.setInt(3, ui5.getTotalApiCounts());
					stmt.setInt(4, ui5.getDepricatedApiCounts());
					stmt.setInt(5, ui5.getNonValidApiCounts());
					stmt.setInt(6, ui5.getRecommendedChangesApiCounts());
					stmt.setString(7, ui5.getFinalMessage());
					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 1000 records
					if (counter % 1000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("UI5 High LEVEL REPORT DATA INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	public void clientProcessingBusinessLogicTestingScope(final long requestID, HttpServletRequest request,
			final String toolName, HttpSession session, List<Testingscopepojo> tscopeList) throws Exception {
		logger.info("Processing of TSCOPE starts ....");

		Map<String, TreeMap<String, String>> testingScopeMasterDataMap = daoIntf.testingScopeMasterDataValues();
		Map<String, String> applicationComponentMap = null;

		List<ExtractedDatapojo> extractedDataPOJOList = new ArrayList<>();

		ExtractedDatapojo extractedDataPOJO = null;

		String applicationComponent = "", process = "", appCompDesc = "";

		try {
			for (Testingscopepojo tscopeValue : tscopeList) {
				extractedDataPOJO = new ExtractedDatapojo();
				extractedDataPOJO.setRequestid(requestID);
				extractedDataPOJO.setObjecttype(tscopeValue.getObjecttype());
				extractedDataPOJO.setObjectname(tscopeValue.getObjectname());
				extractedDataPOJO
						.setObjectTypeObjectName(tscopeValue.getObjecttype().concat(tscopeValue.getObjectname()));
				extractedDataPOJO.setOpercd(tscopeValue.getOpercd());
				extractedDataPOJO.setTransactions(tscopeValue.getComments());
				extractedDataPOJO.setRole(tscopeValue.getCode());

				applicationComponent = tscopeValue.getInfo();

				// Condition 1 - If Application Component is not empty
				if (!applicationComponent.isEmpty()) {
					process = "Others";
					appCompDesc = "Others";

					for (Entry<String, TreeMap<String, String>> entry : testingScopeMasterDataMap.entrySet()) {
						if (applicationComponent.startsWith(entry.getKey())) {
							applicationComponentMap = entry.getValue();
							if (applicationComponentMap.containsKey(applicationComponent.toUpperCase())) {
								process = entry.getKey();
								appCompDesc = applicationComponentMap.get(applicationComponent);
							}

							break;
						}
					}
				} else if (!tscopeValue.getCode().isEmpty()) { // Condition - 2
																// If
																// Application
																// Component is
																// empty and
																// Role is not
																// empty
					String[] roles = tscopeValue.getCode().split("[,]", 0);
					outerloop: for (String rolesData : roles) {
						String[] role = rolesData.split("_");
						for (String roleValue : role) {
							for (Entry<String, TreeMap<String, String>> entry : testingScopeMasterDataMap.entrySet()) {
								process = entry.getKey();
								if (roleValue.equalsIgnoreCase(process)) {
									applicationComponentMap = entry.getValue();
									applicationComponent = ((TreeMap<String, String>) applicationComponentMap)
											.firstKey();
									appCompDesc = applicationComponentMap.get(applicationComponent);
									break outerloop;
								}
							}
						}
					}
				}

				if (applicationComponent.isEmpty()) { // If Application
														// Component is not set
														// in Condition 1 and
														// Condition 2
					applicationComponent = "Others";
					process = "Others";
					appCompDesc = "Others";
				}

				extractedDataPOJO.setApplicationComponent(applicationComponent);
				extractedDataPOJO.setProcess(process);
				extractedDataPOJO.setAppCompDesc(appCompDesc);

				extractedDataPOJOList.add(extractedDataPOJO);
			}

			Collections.sort(extractedDataPOJOList);
			daoIntf.testingScopeFinalInsert(extractedDataPOJOList, session);
			logger.info("Processing of TSCOPE ends ...");
		} catch (Exception e) {
			logger.error("Error while processing Testing Scope ", e.getMessage());
		}
	}

	public void clientBusinessProcessingIRPATScope(long requestID, HttpServletRequest request, HttpSession session,
			RequestForm requestForm) throws Exception {
		logger.info("Processing of TSCOPE starts ....");
		try {
			if (CollectionUtils.isNotEmpty(sto3ReaderXlsx.getCollectionBean().getIrpaTScopeList())) {
				// Processing TestingScope IRPA
				getTestingScopeService().processTScope(requestID,
						sto3ReaderXlsx.getCollectionBean().getIrpaTScopeList(), session, requestForm);

				// Transferring Data From Intermediate To Download Table
				getTestingScopeService().dataTransferToDownload(requestID, session);
			}
			logger.info("Processing of TSCOPE ends ...");
		} catch (Exception e) {
			logger.error("Error while processing Testing Scope ", e);
			throw new Exception("Testing Scope Processing Failed ...");
		}
	}

	public String clientFileProcessingBusinessLogicAUCT(Long requestID, HttpServletRequest request, String toolName,
			HttpSession session) throws Exception {

		String comments = "";
		String status = "";
		boolean processingAUCTStatus = false;

		logger.info("Inside Client File Processing method::::::::: AUCT ");
		processingAUCTStatus = getDaoIntf().getAUCTFinalStatus(requestID, session);
		if (processingAUCTStatus) {

			status = Hana_Profiler_Constant.REFININGSUCCESS_STATUS;
			comments = Hana_Profiler_Constant.REFININGSUCCESS_STATUS_COMMENT;
			// getRequestInventorydao().updateSatus(requestID, status,
			// getPrincipal(),
			// comments, toolName);

		} else {
			// getRequestInventorydao().updateSatus(requestID, status,
			// getPrincipal(),
			// comments, toolName);
			throw new Exception("Exception occured in AUCT processing ");
		}

		return status;
	}

	protected String clientFileProcessingBusinessLogic1(final long requestID, HttpServletRequest request,
			final String toolName, HttpSession session) {

		long currExecutingRequestId = getAutoHANA().getCurrentExecutedRequestId();
		String comments = "";
		Hana_Profiler_Constant.REQUEST_PROGRESS_MAP.remove(requestID);
		Map<Integer, String> waitingRequestMap = new HashMap<Integer, String>();

		if (currExecutingRequestId != 0L) {

			if (currExecutingRequestId == requestID) {
				HANAUtility.changeRequestProgressValue(requestID, 0, "Request is Already in Process ");
			} else {

				getAutoHANA().saveQueueData(requestID, getPrincipal(), getEmailIDDao().getEmail(getPrincipal()),
						toolName);

				waitingRequestMap = getDaoIntf().getWaitingRequest();
				HANAUtility.changeRequestProgressValue(requestID, 0, "Some Other Request is Underprocessing ");
			}
		}

		else {
			getAutoHANA().saveCurrentData(requestID, toolName);

			HANAUtility.changeRequestProgressValue(requestID, 0, "Analysis is in progress.");
			comments = "The Request is not applicable for client processing";
			String systemStatus = getAutoHANA().getSystemStatus(requestID);
			String businessStatus = HANAUtility.getBusinessStatus(systemStatus);
			if (StringUtils.equals(businessStatus, Hana_Profiler_Constant.IDVSUCESS_STATUS)
					|| StringUtils.equals(businessStatus, Hana_Profiler_Constant.NOT_COMPLETED_STATUS)) {
				String status = Hana_Profiler_Constant.IDVSUCESS_STATUS;
				comments = Hana_Profiler_Constant.IDVSUCCESS_STATUS_COMMENT;
				try {
					logger.info("Inside Client File Processing method ");

					long st03StartTime = 0, st03EndTime = 0, HANAStartTime = 0, HANAEndTime = 0;
					long RefineStartTime = 0, RefineEndTime = 0, totalRefineTime = 0;

					final RequestForm requestForm = getRequestDetails().getRequestObj(requestID);
					final String rootPath = HANAUtility.getFilePath(requestForm.getClientName(), requestID);

					boolean st03Status = false;
					boolean genearteHANASheetStatus = false;
					boolean refiningSheetStatus = false;
					getAutoHANA().setRootFilePath(rootPath);
					getSt03DataAnalysis().setRootFolderPath(rootPath);
					// ST03DataAnalysis
					// st03DataAnalysis=autoHANA.getSt03DataAnalysis();
					// Merge Changes start from here::::: Monika
					if (Hana_Profiler_Constant.IDVSUCESS_STATUS.equalsIgnoreCase(systemStatus)
							|| Hana_Profiler_Constant.ST03FAILED_STATUS.equalsIgnoreCase(systemStatus)) {
						getAutoHANA().clearAllTables(requestID);// to
						// clear
						// data
						// if st03
						// failed
						if (Hana_Profiler_Constant.ST03FAILED_STATUS.equalsIgnoreCase(systemStatus)) {
							status = Hana_Profiler_Constant.ST03FAILED_STATUS;
							comments = Hana_Profiler_Constant.ST03FAILED_STATUS_COMMENT;

						}
						st03StartTime = System.currentTimeMillis();
						// st03Status =
						// st03DataAnalysis.analyseST03Data(requestID);//20497
						try {
							// CR-48
							st03Status = getSt03DataAnalysis().analyseST03Data(requestID, toolName, session);// 16273

							st03EndTime = System.currentTimeMillis();
							if (st03Status) {
								status = Hana_Profiler_Constant.ST03SUCCESS_STATUS;
								comments = Hana_Profiler_Constant.ST03SUCCESS_STATUS_COMMENT;
								/*
								 * HANAUtility.changeRequestProgressValue(
								 * requestID, Hana_Profiler_Constant.
								 * ST03_COMPLETE_PROCESS_PERCENT_VALUE,
								 * "HANA:"+Hana_Profiler_Constant.
								 * ST03_SUCCESS_MSG);
								 */
							} else {
								status = Hana_Profiler_Constant.ST03FAILED_STATUS;
								comments = "HANA:" + Hana_Profiler_Constant.ST03FAILED_STATUS_COMMENT;
								/*
								 * HANAUtility.changeRequestProgressValue(
								 * requestID, Hana_Profiler_Constant.
								 * FAILED_PROCESS_PERCENT_VALUE, comments);
								 */
							}

						} catch (ST03DataAnalysisException e) {
							status = Hana_Profiler_Constant.ST03FAILED_STATUS;
							comments = e.getMessage();
							HANAUtility.changeRequestProgressValue(requestID,
									Hana_Profiler_Constant.FAILED_PROCESS_PERCENT_VALUE,
									Hana_Profiler_Constant.ST03FAILED_STATUS_COMMENT);
							logger.error("Error in clientFileProcessingBusinessLogic1", e);
						}
					}

					if (st03Status || Hana_Profiler_Constant.ST03SUCCESS_STATUS.equalsIgnoreCase(systemStatus)
							|| Hana_Profiler_Constant.HANAQUERYFAILED_STATUS.equalsIgnoreCase(systemStatus)) {
						// getAutoHANA().clearAllTables(Hana_Profiler_Constant.HANA,
						// requestID);
						HANAStartTime = System.currentTimeMillis();
						// genearteHANASheetStatus=generateHANAFinalSheet.executeGenerateHanaFinalSheet(requestID,rootPath);//3078
						genearteHANASheetStatus = getGenerateHANAFinalSheet().executeGenerateHanaFinalSheet(requestID);// 1226
						HANAEndTime = System.currentTimeMillis();

						if (genearteHANASheetStatus) {
							status = Hana_Profiler_Constant.HANAQUERYSUCCESS_STATUS;
							comments = Hana_Profiler_Constant.HANAQUERYSUCCESS_STATUS_COMMENT;
							/*
							 * HANAUtility.changeRequestProgressValue(requestID,
							 * Hana_Profiler_Constant.
							 * HANA_QUERY_PROCESS_PERCENT_VALUE,
							 * Hana_Profiler_Constant.HANA_QUERY_SUCESS_MSG);
							 */
						} else {
							status = Hana_Profiler_Constant.HANAQUERYFAILED_STATUS;
							comments = Hana_Profiler_Constant.HANAQUERYFAILED_STATUS_COMMENT;
							/*
							 * HANAUtility.changeRequestProgressValue(requestID,
							 * Hana_Profiler_Constant.
							 * FAILED_PROCESS_PERCENT_VALUE,
							 * Hana_Profiler_Constant.HANA_QUERY_FIALED_MSG);
							 */
						}

					}

					if (genearteHANASheetStatus
							|| Hana_Profiler_Constant.HANAQUERYSUCCESS_STATUS.equalsIgnoreCase(systemStatus)
							|| Hana_Profiler_Constant.HANAREFININGFAILED_STATUS.equalsIgnoreCase(systemStatus)) {
						RefineStartTime = System.currentTimeMillis();

						// refiningSheetStatus=daoIntf.get_List_with_HanaProfiler_Final_Sheet_Data(requestID,requestForm.getClientName());//2601
						refiningSheetStatus = getDaoIntf().getHanaProfilerFinalList(requestID,
								requestForm.getClientName(), session);// 1632

						RefineEndTime = System.currentTimeMillis();
						if (refiningSheetStatus) {
							status = Hana_Profiler_Constant.HANAREFININGSUCCESS_STATUS;
							comments = Hana_Profiler_Constant.HANAREFININGSUCCESS_STATUS_COMMENT;
							/*
							 * HANAUtility.changeRequestProgressValue(requestID,
							 * Hana_Profiler_Constant.
							 * HANA_REFINING_PROCESS_PERCENT_VALUE,
							 * Hana_Profiler_Constant.
							 * HANA_REFINING_PROCESS_IN_PROGRESS_MSG);
							 */
							Hana_Profiler_Constant.ID_FILE_KEY_VALUE.remove(requestID);

						} else {
							status = Hana_Profiler_Constant.HANAREFININGFAILED_STATUS;
							comments = Hana_Profiler_Constant.HANAREFININGFAILED_STATUS_COMMENT;
							/*
							 * HANAUtility.changeRequestProgressValue(requestID,
							 * Hana_Profiler_Constant.
							 * FAILED_PROCESS_PERCENT_VALUE,
							 * Hana_Profiler_Constant.
							 * HANA_REFINING_PROCESS_FAILED_MSG);
							 */
						}

					}

					// getRequestInventorydao().updateSatus(requestID, status,
					// getPrincipal(),
					// comments, toolName);
					/* CR-1.0 Monika */
					if (Hana_Profiler_Constant.HANAREFININGSUCCESS_STATUS.equals(status)) {

						logger.info("In side If Success:::HANAREFININGSUCCESS_STATUS ");

						// HANAUtility.changeRequestProgressValue(requestID, 25,
						// "HANA Processing
						// Done");
						getDaoIntf().deleteDuplicateRecords(requestID);

						// getGraphDao().updateRequestMaster(requestID);

						/*
						 * getDaoIntf().archiveData(requestID,
						 * HANAUtility.getCSVFilePath(requestForm.getClientName(
						 * ), requestID).replace("\\", "\\\\"));
						 */
						// HANAUtility.changeRequestProgressValue(requestID,
						// Hana_Profiler_Constant.PROCESS_COMPLETE_PERCENT_VALUE,
						// Hana_Profiler_Constant.PROCESS_COMPLETE_MSG);
						//
						logger.info("Going to send mail::: ");
						// sendEmailForProcessedRequest(status,requestID,request,Hana_Profiler_Constant.COMPLETED_PENDING_ESTIMATIONS);
					} else {
						sendEmailForProcessedRequest(status, requestID, request, Hana_Profiler_Constant.Prosess_FAILURE,
								session);
					}
					long totalST03Time = st03EndTime - st03StartTime;
					long totalHANATime = HANAEndTime - HANAStartTime;
					totalRefineTime = RefineStartTime - RefineEndTime;

					logger.info("Total time in ST03 ANALYSIS=" + totalST03Time);
					logger.info("Total time in HANA PROFILER STEP=" + totalHANATime);
					logger.info("Total time in refining data ::" + totalRefineTime);

					/**
					 * Block For Delete Request and sending an email to everyone
					 * for initiating request
					 ***/
					// For HANA
					getDaoIntf().deleteCurrentQueueExecution(CurrentExecution.class);
					// waitingRequestMap=getDaoIntf().getWaitingRequest();
					// if(!waitingRequestMap.isEmpty()){
					// sendEmailToWaitingRequest(waitingRequestMap,request);
					// }
					// getDaoIntf().deleteCurrentQueueExecution(QueueExecution.class);

					/** Block For Delete Request and email closed ***/

				} catch (Exception e) {
					logger.error(e.getMessage());
					logger.info("Inside catch");
					if (status.equals(Hana_Profiler_Constant.IDVSUCESS_STATUS)) {
						status = Hana_Profiler_Constant.ST03FAILED_STATUS;
						comments = Hana_Profiler_Constant.ST03FAILED_STATUS_EXCEPTION_COMMENT;
						getRequestInventorydao().updateSatus(requestID, status, getPrincipal(), comments, toolName);

					}
					sendEmailForProcessedRequest(status, requestID, request, Hana_Profiler_Constant.Prosess_FAILURE,
							session);
					HANAUtility.changeRequestProgressValue(requestID,
							Hana_Profiler_Constant.FAILED_PROCESS_PERCENT_VALUE, comments);

					/*
					 * getDaoIntf().deleteCurrentQueueExecution(CurrentExecution
					 * .class);
					 * waitingRequestMap=getDaoIntf().getWaitingRequest();
					 * if(!waitingRequestMap.isEmpty()){
					 * sendEmailToWaitingRequest(waitingRequestMap,request); }
					 * getDaoIntf().deleteCurrentQueueExecution(QueueExecution.
					 * class);
					 */

				}
			}

		}
		return comments;

	}
	/*
	 * protected String clientFileProcessingBusinessLogicAUCT(final long
	 * requestID, HttpServletRequest request, final String toolName) {
	 * 
	 * long currExecutingRequestId =
	 * getAutoHANA().getCurrentExecutedRequestId(); String comments = "";
	 * Hana_Profiler_Constant.REQUEST_PROGRESS_MAP.remove(requestID);
	 * Map<Integer,String> waitingRequestMap=new HashMap<Integer,String>();
	 * 
	 * if(currExecutingRequestId != 0L){ if(currExecutingRequestId==requestID) {
	 * HANAUtility.changeRequestProgressValue(requestID,0,
	 * "Request is Already in Process "); } else {
	 * getAutoHANA().saveQueueData(requestID,
	 * getPrincipal(),getChangePasswordDao().getEmail(getPrincipal()),
	 * toolName); waitingRequestMap=getDaoIntf().getWaitingRequest();
	 * HANAUtility.changeRequestProgressValue(requestID,0,
	 * "Some Other Request is Underprocessing "); } }
	 * 
	 * else{ getAutoHANA().saveCurrentData(requestID, toolName);
	 * 
	 * HANAUtility.changeRequestProgressValue(requestID,
	 * 0,"Analysis is in progress." );
	 * 
	 * String systemStatus = getAutoHANA().getSystemStatus(requestID); String
	 * businessStatus = HANAUtility.getBusinessStatus(systemStatus); if
	 * (StringUtils.equals(businessStatus,
	 * Hana_Profiler_Constant.IDVSUCESS_STATUS) ||
	 * StringUtils.equals(businessStatus,
	 * Hana_Profiler_Constant.NOT_COMPLETED_STATUS)) { String status =
	 * Hana_Profiler_Constant.IDVSUCESS_STATUS; comments =
	 * Hana_Profiler_Constant.IDVSUCCESS_STATUS_COMMENT; try {
	 * logger.info("Inside AUCT Processing method ");
	 * 
	 * final RequestForm requestForm =
	 * getRequestDetails().getRequestObj(requestID); final String rootPath =
	 * HANAUtility.getFilePath(requestForm.getClientName(), requestID);
	 * getAutoHANA().setRootFilePath(rootPath);
	 * getSt03DataAnalysis().setRootFolderPath(rootPath);
	 * 
	 * if
	 * (Hana_Profiler_Constant.IDVSUCESS_STATUS.equalsIgnoreCase(systemStatus)
	 * ||
	 * Hana_Profiler_Constant.ST03FAILED_STATUS.equalsIgnoreCase(systemStatus))
	 * { getAutoHANA().clearAllTables(Hana_Profiler_Constant.ALL, requestID);
	 * 
	 * if
	 * (Hana_Profiler_Constant.ST03FAILED_STATUS.equalsIgnoreCase(systemStatus))
	 * { status = Hana_Profiler_Constant.ST03FAILED_STATUS; comments =
	 * Hana_Profiler_Constant.ST03FAILED_STATUS_COMMENT; }
	 * System.out.println("toolName::::::" + toolName);
	 * getDaoIntf().updateAUCTAutomationLogic(requestID);
	 * HANAUtility.changeRequestProgressValue(requestID,
	 * 75,":::::::::::::::::::::::AUCT Processing Done:::::::::::::::::::::::");
	 * getRequestInventorydao().updateSatus(requestID, status, getPrincipal(),
	 * comments,toolName);
	 * 
	 * if (Hana_Profiler_Constant.HANAREFININGSUCCESS_STATUS.equals(status)) {
	 * logger.info("In side If Success:::AUCT_SUCCESS ");
	 * //getGraphS4DAO().updateRequestMasterS4(requestID);
	 * logger.info("G0ing to send mail::: ");
	 * //sendEmailForProcessedRequest(status,requestID,request,
	 * Hana_Profiler_Constant.COMPLETED_PENDING_ESTIMATIONS); } else{
	 * sendEmailForProcessedRequest(status,requestID,request,
	 * Hana_Profiler_Constant. Prosess_FAILURE); }
	 * getDaoIntf().deleteCurrentQueueExecution(CurrentExecution.class);
	 * 
	 * } } catch (Exception e) { logger.error(e.getMessage());
	 * logger.info("Inside catch"); if
	 * (status.equals(Hana_Profiler_Constant.IDVSUCESS_STATUS)) { status =
	 * Hana_Profiler_Constant.ST03FAILED_STATUS; comments =
	 * Hana_Profiler_Constant.ST03FAILED_STATUS_EXCEPTION_COMMENT;
	 * getRequestInventorydao().updateSatus(requestID, status, getPrincipal(),
	 * comments,toolName); }
	 * sendEmailForProcessedRequest(status,requestID,request,
	 * Hana_Profiler_Constant. Prosess_FAILURE);
	 * HANAUtility.changeRequestProgressValue(requestID,
	 * Hana_Profiler_Constant.FAILED_PROCESS_PERCENT_VALUE, comments); } } }
	 * return comments; }
	 */

	/*
	 * public ChangePasswordService getChangePasswordService() { return
	 * changePasswordService; }
	 * 
	 * @Autowired public void setChangePasswordService(final
	 * ChangePasswordService changePasswordService) { this.changePasswordService
	 * = changePasswordService; }
	 */

	public DisplayGraphDao getGraphDao() {
		return graphDao;
	}

	protected String getRedirectPage(final HttpServletRequest request, HttpSession session) {
		String redirectPage = "";
		/*
		 * CR21: User role changed to POC.
		 */
		/*
		 * if (request.isUserInRole("ADMIN")) {
		 * logger.info("Inside isUserInrole(admin)"); redirectPage =
		 * "redirect:/admin/dashboardAdmin"; }else if
		 * (request.isUserInRole("POC")) {
		 * logger.info("Inside isUserInrole(POC)"); redirectPage =
		 * "redirect:/poc/pocDashBoard"; } else if
		 * (request.isUserInRole("CLIENT")) {
		 * logger.info("Inside isUserInrole(client)"); redirectPage =
		 * "redirect:/client/dashboard"; }
		 */
		if ((request.isUserInRole("ADMIN")) || (request.isUserInRole("POC")) || (request.isUserInRole("CLIENT"))) {
			logger.info("User is valid! navigating to Role selection page");
			session.setAttribute("navFrom", "SSO");
			redirectPage = "redirect:/accessTiles";
		} else {
			redirectPage = "redirect:/accessDenied";
		}
		return redirectPage;
	}

	@ExceptionHandler(value = ResetPasswordException.class)
	public String handleResetPasswordException(HttpServletRequest request) {
		return "redirect:/resetPassword";
	}

	@ExceptionHandler(value = RequestNotValidException.class)
	public String handleRequestNotValidException(HttpServletRequest request, HttpSession session) {
		return getRedirectPage(request, session);
	}

	public VerifyOutputSheet getVerifyOutput() {
		return verifyOutput;
	}

	public ProcessingFileUploadValidator getProcessingFileUploadValidator() {
		return processingFileUploadValidator;
	}

	@Autowired
	public void setProcessingFileUploadValidator(ProcessingFileUploadValidator processingFileUploadValidator) {
		this.processingFileUploadValidator = processingFileUploadValidator;
	}

	public FetchEmailID getEmailIDDao() {
		return fetchEmailID;
	}

	@Autowired
	public void setEmailIDDao(final FetchEmailID fetchEmailID) {
		this.fetchEmailID = fetchEmailID;
	}

	protected void sendEmailForProcessedRequest(String succOrFailureReason, long requestId, HttpServletRequest request,
			String successOrFailure, HttpSession session) {
		String emailContext = "https://" + request.getServerName() + ":" + request.getServerPort();
		Set<String> emailData = new HashSet<String>();
		Set<String> emailCc = new HashSet<String>();
		SendEmail email = new SendEmail();
		email.setMailFrom("");
		emailCc.add("");
		emailData.add(getEmailIDDao().getEmail(getPrincipal()));
		email.setMailTo(emailData);
		email.setMailCC(emailCc);

		final RequestForm requestForm = getRequestDetails().getRequestObj(requestId);
		String requestUID = requestForm.getREQUEST_ID_UI();
		email.setMailSubject("Request ID : " + requestUID + " Processed " + "<" + successOrFailure + ">");
		String body = "\n\nDear " + getPrincipal() + ",\n\nYour Request " + requestUID
				+ "  Has Been Processsed With Status : " + successOrFailure
				+ " .\nNote:-Please Contact To Administrator If Request Is Not Completed.\n\n" + "<a href="
				+ emailContext + "/hanaprofilerperformance/homepage" + ">Client - View Request Detail</a>\n\n";

		if (TCodeStandardizationService.jcoError) {
			body += "\n\nNote: Fiori Output report has been generated with few discrepancies where multiple apps are associated with a Tcode.";
			TCodeStandardizationService.jcoError = false;
		}
		body += "\n\n\nRegards,\nS/4HANA conversion Team ATCI";
		email.setMailBody(body);
		email.emailSend(email, request, session);

	}

	protected void sendEmailToWaitingRequest(Map<Integer, String> waitingRequestMap, HttpServletRequest request,
			HttpSession session) {

		Set<String> emailData = new HashSet<String>();
		for (Map.Entry<Integer, String> entry : waitingRequestMap.entrySet()) {
			emailData.add(entry.getValue());
		}
		Set<String> emailCc = new HashSet<String>();
		SendEmail email = new SendEmail();
		email.setMailFrom("");
		emailCc.add("");

		email.setMailTo(emailData);
		email.setMailCC(emailCc);

		email.setMailSubject("Alert :- Initiate Process");
		email.setMailBody(
				"\n\nDear User\n\nThis is to inform you that the Hana System is available for the processing.\n\n"
						+ "Kindly start your process.\n\n" + "\n\n\nRegards,\nS/4HANA conversion Team ATCI");
		email.emailSend(email, request, session);

	}

	public String readEstimatorData(final String path, final long requestId, HttpServletRequest request,
			String toolName, HttpSession session) {
		String comment = "";
		FileInputStream inputStream;
		try {
			inputStream = new FileInputStream(new File(path));

			Workbook workbook = new XSSFWorkbook(inputStream);
			int noOfSheets = workbook.getNumberOfSheets();

			Sheet estimatorSheet = null;
			Sheet assumptionsSheet = null;
			Sheet staffingSheet = null;
			// CR-13.0 Estimator sheet name changed to Estimations & reading
			// data from
			// Staffing Recommendations sheet
			for (int i = 0; i < noOfSheets; i++) {
				if (workbook.getSheetAt(i) != null
						&& "Estimations".equalsIgnoreCase(workbook.getSheetAt(i).getSheetName().trim())) {
					estimatorSheet = workbook.getSheetAt(i);
				}
				if (workbook.getSheetAt(i) != null
						&& "Assumptions".equalsIgnoreCase(workbook.getSheetAt(i).getSheetName().trim())) {
					assumptionsSheet = workbook.getSheetAt(i);
				}
				if (workbook.getSheetAt(i) != null
						&& "Staffing Recommendations".equalsIgnoreCase(workbook.getSheetAt(i).getSheetName().trim())) {
					staffingSheet = workbook.getSheetAt(i);
				}
			}
			if (estimatorSheet == null) {
				comment = "Upload xlsx file should have Estimations sheet.";
				return comment;
			} else {
				// Reading estimation
				// CR:56-Adding New Estimation sheet
				HanaEstimator hanaEstimator = new HanaEstimator();
				hanaEstimator.setCustFugrCount((int) (estimatorSheet.getRow(3).getCell(2).getNumericCellValue()));
				hanaEstimator.setCustProgCount((int) (estimatorSheet.getRow(3).getCell(5).getNumericCellValue()));
				hanaEstimator.setCustClasCount((int) estimatorSheet.getRow(3).getCell(8).getNumericCellValue());
				hanaEstimator.setCustFormCount((int) (estimatorSheet.getRow(3).getCell(11).getNumericCellValue()));
				hanaEstimator.setCustEnhanCount((int) (estimatorSheet.getRow(3).getCell(14).getNumericCellValue()));
				hanaEstimator.setCustWebCount((int) (estimatorSheet.getRow(3).getCell(17).getNumericCellValue()));
				hanaEstimator.setCustLsmwCount((int) (estimatorSheet.getRow(3).getCell(20).getNumericCellValue()));
				hanaEstimator.setCustExitCount((int) estimatorSheet.getRow(3).getCell(23).getNumericCellValue());

				hanaEstimator.setDefectFugrCount((int) (estimatorSheet.getRow(5).getCell(2).getNumericCellValue()));
				hanaEstimator.setDefectProgCount((int) (estimatorSheet.getRow(5).getCell(5).getNumericCellValue()));
				hanaEstimator.setDefectClasCount((int) (estimatorSheet.getRow(5).getCell(8).getNumericCellValue()));
				hanaEstimator.setDefectFormCount((int) (estimatorSheet.getRow(5).getCell(11).getNumericCellValue()));
				hanaEstimator.setDefectEnhanCount((int) (estimatorSheet.getRow(5).getCell(14).getNumericCellValue()));
				hanaEstimator.setDefectWebCount((int) (estimatorSheet.getRow(5).getCell(17).getNumericCellValue()));
				hanaEstimator.setDefectLsmwCount((int) (estimatorSheet.getRow(5).getCell(20).getNumericCellValue()));
				hanaEstimator.setDefectExitCount((int) (estimatorSheet.getRow(5).getCell(23).getNumericCellValue()));

				// Reading Used estimation
				hanaEstimator.setCustUsedFugrCount((int) (estimatorSheet.getRow(31).getCell(2).getNumericCellValue()));
				hanaEstimator.setCustUsedProgCount((int) (estimatorSheet.getRow(31).getCell(5).getNumericCellValue()));
				hanaEstimator.setCustUsedClasCount((int) estimatorSheet.getRow(31).getCell(8).getNumericCellValue());
				hanaEstimator.setCustUsedFormCount((int) (estimatorSheet.getRow(31).getCell(11).getNumericCellValue()));
				hanaEstimator
						.setCustUsedEnhanCount((int) (estimatorSheet.getRow(31).getCell(14).getNumericCellValue()));
				hanaEstimator.setCustUsedWebCount((int) (estimatorSheet.getRow(31).getCell(17).getNumericCellValue()));
				hanaEstimator.setCustUsedLsmwCount((int) (estimatorSheet.getRow(31).getCell(20).getNumericCellValue()));
				hanaEstimator.setCustUsedExitCount((int) estimatorSheet.getRow(31).getCell(23).getNumericCellValue());

				hanaEstimator
						.setDefectUsedFugrCount((int) (estimatorSheet.getRow(33).getCell(2).getNumericCellValue()));
				hanaEstimator
						.setDefectUsedProgCount((int) (estimatorSheet.getRow(33).getCell(5).getNumericCellValue()));
				hanaEstimator
						.setDefectUsedClasCount((int) (estimatorSheet.getRow(33).getCell(8).getNumericCellValue()));
				hanaEstimator
						.setDefectUsedFormCount((int) (estimatorSheet.getRow(33).getCell(11).getNumericCellValue()));
				hanaEstimator
						.setDefectUsedEnhanCount((int) (estimatorSheet.getRow(33).getCell(14).getNumericCellValue()));
				hanaEstimator
						.setDefectUsedWebCount((int) (estimatorSheet.getRow(33).getCell(17).getNumericCellValue()));
				hanaEstimator
						.setDefectUsedLsmwCount((int) (estimatorSheet.getRow(33).getCell(20).getNumericCellValue()));
				hanaEstimator
						.setDefectUsedExitCount((int) (estimatorSheet.getRow(33).getCell(23).getNumericCellValue()));

				hanaEstimator.setUsed_Migration_Fix_Effort_Manual_Fixing_Count(
						(int) (estimatorSheet.getRow(38).getCell(26).getNumericCellValue()));
				hanaEstimator.setMigration_Fix_Effort_Manual_Fixing_Count(
						(int) (estimatorSheet.getRow(10).getCell(26).getNumericCellValue()));

				hanaEstimator
						.setMigrationManualCount((int) (estimatorSheet.getRow(12).getCell(26).getNumericCellValue()));
				hanaEstimator.setMigrationAutomatedCount(
						(int) (estimatorSheet.getRow(13).getCell(26).getNumericCellValue()));
				hanaEstimator.setDefectCount((int) (estimatorSheet.getRow(14).getCell(26).getNumericCellValue()));
				// CR-13.0 read 2 more cols
				hanaEstimator.setMigration_manualEfforts_hrs(
						(int) (estimatorSheet.getRow(10).getCell(26).getNumericCellValue()));
				hanaEstimator
						.setMgmt_estim_efforts_hrs((int) (estimatorSheet.getRow(22).getCell(17).getNumericCellValue()));
				// CR-13.0 reading data from Staffing Recommendations sheet
				if (staffingSheet != null) {
					hanaEstimator.setRes_TL_SSE((int) (staffingSheet.getRow(1).getCell(2).getNumericCellValue()));
					hanaEstimator.setRes_SSE_SE((int) (staffingSheet.getRow(2).getCell(2).getNumericCellValue()));
				}
				hanaEstimator.setRequestID(requestId);

				comment = getDaoIntf().addEstimatorData(hanaEstimator);
			}
			String textToSave = "";
			StringBuilder finalStringb = new StringBuilder();
			if (assumptionsSheet != null) {
				if (assumptionsSheet.getLastRowNum() > 1) {
					for (int i = 1; i < assumptionsSheet.getLastRowNum(); i++) {
						// CR-13.0
						int cellType = assumptionsSheet.getRow(i).getCell(1).getCellType();
						if (cellType == 1)
							finalStringb.append(assumptionsSheet.getRow(i).getCell(1).getStringCellValue())
									.append("@@@");
						else
							finalStringb.append(assumptionsSheet.getRow(i).getCell(2).getStringCellValue())
									.append("@@@");
					}
				}
				textToSave = finalStringb.toString();
				HanaAssumption hanaAssumption = new HanaAssumption();
				hanaAssumption.setRequestID(requestId);
				hanaAssumption.setAssumptions(textToSave);
				comment = getDaoIntf().addAssumptionsData(hanaAssumption);
			}
			if (comment.equalsIgnoreCase("success")) {
				String status = Hana_Profiler_Constant.HANAREFININGCOMPLETED_STATUS;
				String comments = Hana_Profiler_Constant.HANAREFININGCOMPLETED_STATUS_COMMENT;
				getRequestInventorydao().updateSatus(requestId, status, getPrincipal(), comments, toolName);

				// CR-12.3 Update Request_master table with Estimations
				getGraphDao().updateRequestMasterEstimations(requestId);

				// call mail method from here
				sendEmailForCompletedRequest(status, requestId, request, Hana_Profiler_Constant.COMPLETED_STATUS,
						session);
			}

			return comment;

		} catch (FileNotFoundException e) {
			logger.error("Error while reading estimator data in readEstimatorData", e);
		} catch (IOException e) {
			logger.error("Error while reading estimator data in readEstimatorData", e);
		}
		return comment;
	}

	private void sendEmailForCompletedRequest(String succOrFailureReason, long requestId, HttpServletRequest request,
			String successOrFailure, HttpSession session) {
		logger.info("Coming Inside  sendEmailForProcessedRequest values " + succOrFailureReason + "****" + requestId
				+ "****" + request.getServerName() + "successOrFailure " + successOrFailure);
		String emailContext = "https://" + request.getServerName() + ":" + request.getServerPort();
		Set<String> emailData = new HashSet<String>();
		Set<String> emailCc = new HashSet<String>();
		SendEmail email = new SendEmail();
		email.setMailFrom("");
		emailCc.add("");

		final RequestForm requestForm = getRequestDetails().getRequestObj(requestId);

		emailData.add(requestForm.getClientTeamDetails());
		email.setMailTo(emailData);
		email.setMailCC(emailCc);

		// Defect: SendEmail msg
		email.setMailSubject(
				"Request ID : " + requestForm.getREQUEST_ID_UI() + " Processed " + "<" + successOrFailure + ">");
		email.setMailBody("\n\nDear " + getPrincipal() + ",\n\nYour Request " + requestForm.getREQUEST_ID_UI()
				+ "  Has Been Processsed With Status : " + successOrFailure + " .\n\n"
				+ "Estimator and(or) Assumptions has been uploaded by Administrator(" + requestForm.getPocName()
				+ ").\nYou can download output sheet from \n\n" + "<a href=" + emailContext
				+ "/hanaprofilerperformance/client/requestDetails/" + requestForm.getRequestID()
				+ ">Download Estimator/Assumptions</a>\n\n" +

				"<a href=" + emailContext + "/hanaprofilerperformance/client/requestDetails/"
				+ requestForm.getRequestID() + ">Download Complete Output</a>\n\n" +

				"\nNote:-Please Contact To Administrator (" + requestForm.getPocName()
				+ ") If Request Is Not Completed.\n\n" + "<a href=" + emailContext
				+ "/hanaprofilerperformance/client/requestDetails/" + requestForm.getRequestID()
				+ ">Client - View Request Detail</a>\n\n" + "<a href=" + emailContext
				+ "/hanaprofilerperformance/requestDetails/" + requestForm.getRequestID()
				+ ">Admin/Poc - View Request Detail</a>" + "\n\n\nRegards,\nS/4HANA conversion Team ATCI");
		email.emailSend(email, request, session);

	}

	/**
	 * CR 24: Added a call to Report Dao
	 * 
	 * @return
	 */
	public ReportDao getReportDao() {
		return reportDao;
	}

	@Autowired
	public void setReportDao(final ReportDao reportDao) {
		this.reportDao = reportDao;
	}

	// US-04.1, US-04.2, DEF043
	public void addLsmwToInventory(CodeAssessmentPayLoad ca, long requestId) throws SQLException {
		List<UsageAnalysis> usageAnalysisList = ca.getUsageAnalysisList();
		Set<String> usageListAQQU = ca.getUsageAnalysisObjNameTypeReadProg();
		// List<S4InventoryList> inventoryList = ca.getInventoryList();
		List<S4InventoryList> inventoryList = getClientRequestInventoryDAO().getInventory(requestId);

		setSession(ca.getSession());

		logger.info("Inventory size Before execution : " + inventoryList.size());

		long start = System.currentTimeMillis();
		try {
			for (S4InventoryList iv : inventoryList) {
				String invListObj = iv.getObjNameType();
				invListObj = (invListObj.startsWith("USRE") || invListObj.startsWith("USRR"))
						? invListObj.replace(invListObj.substring(0, 4), "PROG") : invListObj;

				if (iv.getObjType().equalsIgnoreCase("AQQU")) {
					String objTypeNameReadProg = iv.getObjType() + iv.getObjName() + iv.getReadProg();

					if (CollectionUtils.isNotEmpty(usageAnalysisList)) {
						for (UsageAnalysis ua : usageAnalysisList) {

							if (objTypeNameReadProg.equalsIgnoreCase(ua.getObjTypeNameReadProg())) {

								iv.setUsage("Y");
								iv.setUsageCount(ua.getUsageCount());
							}
						}
					}

				} else {
					if (CollectionUtils.isNotEmpty(usageAnalysisList)) {
						for (UsageAnalysis ua : usageAnalysisList) {

							if (invListObj.equalsIgnoreCase(ua.getObjNameType())) {
								iv.setUsage("Y");
								iv.setUsageCount(ua.getUsageCount());
							}
						}
					}
				}
				// smodlog map - check contains and if it found that key in map
				// then remove to
				// from map
				if (null != ca.getSmodilogMapImpMod()) {
					if (ca.getSmodilogMapImpMod().containsKey(invListObj)) {
						ca.getSmodilogMapImpMod().remove(invListObj);
						iv.setStandardMod("X");
					}
				}
				// for (MetaData metaData : metaDataList) {
				// if (invListObj.equalsIgnoreCase(metaData.getObjTypeName())) {
				// iv.setRicefCategory(metaData.getRicefCategory());
				// }
				// }
				updateRicefwCategorySubCategory(ca, iv);
			}
			// iterate map add smod entries from map to the list(check if we can
			// remove
			// entries from map)
			if (null != ca.getSmodilogMapImpMod()) {
				for (Map.Entry<String, SmodilogFunction> entry : ca.getSmodilogMapImpMod().entrySet()) {
					S4InventoryList invlst = new S4InventoryList();
					invlst.setObjType(entry.getValue().getObjType());
					invlst.setObjName(entry.getValue().getObjName());
					invlst.setObjNameType(entry.getValue().getObjNameType());
					invlst.setStandardMod("X");
					;
					invlst.setRequestID(entry.getValue().getRequestId());
					updateRicefwCategorySubCategory(ca, invlst);
					inventoryList.add(invlst);
				}
			}
			long end = System.currentTimeMillis();

			logger.info("addLsmwToInventory for loop time :::::::::::::::::::::" + (end - start) / 1000 + "s");
			logger.info("Inventory size After execution : " + inventoryList.size());
		} catch (Exception e) {
			logger.error("addLSMWToTheInventory :: ", e);
		}
		getAutoHANA().clearInventoryList(requestId);
		DroolsHelper.InventoryListBatchInsertUpdate(inventoryList, getSession());
	}

	private void updateRicefwCategorySubCategory(CodeAssessmentPayLoad ca, S4InventoryList iv) {
		String invListObj = iv.getObjNameType();
		if (null != ca.getMetaDataMap()) {
			if (ca.getMetaDataMap().containsKey(invListObj)) {
				if (null != ca.getMetaDataMap().get(invListObj)) {
					iv.setRicefCategory(ca.getMetaDataMap().get(invListObj).getRicefCategory());
				}
				if (null != ca.getMetaDataMap().get(invListObj)
						&& null != ca.getMetaDataMap().get(invListObj).getRicefSubCategory()) {
					iv.setRicefSubCategory(ca.getMetaDataMap().get(invListObj).getRicefSubCategory());
					logger.info("addLSMW Setting Ricef sub category :: ");
				}
			}
			if (StringUtils.isBlank(iv.getRicefCategory()) && "SSFO".equalsIgnoreCase(iv.getObjType())) {
				iv.setRicefCategory("FORMS");
				iv.setRicefSubCategory("Smartforms");
			}
			if (StringUtils.isBlank(iv.getRicefCategory()) && "SFPF".equalsIgnoreCase(iv.getObjType())) {
				iv.setRicefCategory("FORMS");
				iv.setRicefSubCategory("Adobe");
			}

		}
		if ("AQQU".equalsIgnoreCase(iv.getObjType())) {
			iv.setRicefCategory("Others");
			iv.setRicefSubCategory("Configurable Report");
		}

		if (StringUtils.isBlank(iv.getRicefCategory()))
			iv.setRicefCategory(Hana_Profiler_Constant.OTHERS);
	}

	public void addAcnipRicefAndSubCategory(CodeAssessmentPayLoad ca) throws SQLException {
		List<ACNIPZVERComp> acnipzList = ca.getAcnipList();

		setSession(ca.getSession());

		long start = System.currentTimeMillis();
		try {
			for (ACNIPZVERComp iv : acnipzList) {
				String objTypeName = iv.getObject().trim() + iv.getObjName().trim();
				if (null != ca.getMetaDataMap()) {
					if (ca.getMetaDataMap().containsKey(objTypeName)) {
						if (null != ca.getMetaDataMap().get(objTypeName)) {
							iv.setRicefCategory(ca.getMetaDataMap().get(objTypeName).getRicefCategory());
						}
						if (null != ca.getMetaDataMap().get(objTypeName)
								&& null != ca.getMetaDataMap().get(objTypeName).getRicefSubCategory()) {
							iv.setRicefSubCategory(ca.getMetaDataMap().get(objTypeName).getRicefSubCategory());
							logger.info("addAcnipRicefAndSubCategory Setting Ricef sub category :: ");
						}
						// if(null != ca.getMetaDataMap().get(invListObj) &&
						// StringUtils.isBlank(ca.getMetaDataMap().get(invListObj).getRicefCategory())
						// &&
						// "SSFO".equalsIgnoreCase(ca.getMetaDataMap().get(invListObj).getObj())
						// ||
						// "SFPF".equalsIgnoreCase(ca.getMetaDataMap().get(invListObj).getObj())){
						// iv.setRicefCategory("FORMS");
						// }
					}
				}
				if (StringUtils.isBlank(iv.getRicefCategory()) && "SSFO".equalsIgnoreCase(iv.getObject())) {
					iv.setRicefCategory("FORMS");
					iv.setRicefSubCategory("Smartforms");
				}
				if (StringUtils.isBlank(iv.getRicefCategory()) && "SFPF".equalsIgnoreCase(iv.getObject())) {
					iv.setRicefCategory("FORMS");
					iv.setRicefSubCategory("Adobe");
				}
				if ("AQQU".equalsIgnoreCase(iv.getObject())) {
					iv.setRicefCategory("Others");
					iv.setRicefSubCategory("Configurable Report");
				}

				if (StringUtils.isBlank(iv.getRicefCategory()))
					iv.setRicefCategory(Hana_Profiler_Constant.OTHERS);
			}

			long end = System.currentTimeMillis();

			logger.info("addAcnipRicefAndSubCategory for loop time :::::::::::::::::::::" + (end - start) / 1000 + "s");
		} catch (Exception e) {
			logger.error("addAcnipRicefAndSubCategory :: ", e);
		}
		St03ReaderXlsx.ACNIPZVERCompBatchInsertUpdate(acnipzList, getSession());
	}

	public void storeImpactedCloneAnalysis(CodeAssessmentPayLoad ca, Long requestId, List<String> externalNamespaceList)
			throws SQLException {

		List<ImpactedCloneAnalysis> impactedCloneAnalysisList = new ArrayList<ImpactedCloneAnalysis>();
		List<ImpactedCloneAnalysis> impactedCloneList = ca.getImpactedcloneList();
		Set<String> usageAnalysisList = ca.getUsageAnalysisObjNameType();
		List<S4HanaProfiler> s4DetailReport = getDaoIntf().getS4DetailReport(requestId, 0, 0);
		List<S4SimplificationDatabase> simplificationList = getDaoIntf().getSimplificationListReport(requestId, 0, 0);
		List<HanaProfile> hanaDetailReport = getDaoIntf().getHanaDetailReport(requestId, 0, 0);
		List<AuctFinalOutput> existingErrorDetailReport = getDaoIntf().getExistingErrorReport(requestId, 0, 0);
		List<OSMigrationFinal> osMigrationFinalReportList = getDaoIntf().getOSMigrationFinalReport(requestId, 0, 0);

		setSession(ca.getSession());

		for (ImpactedCloneAnalysis impactedClone : impactedCloneList) {
			boolean flag = false;
			// Usage Analysis for Used column
			impactedClone.setUsed("");
			if (CollectionUtils.isNotEmpty(usageAnalysisList)) {
				for (String usageAnalysis : usageAnalysisList) {
					if (impactedClone.getObjTypeName().equals(usageAnalysis)) {
						impactedClone.setUsed("Y");
					}
					if ("FUGR".equalsIgnoreCase(impactedClone.getObjType())) {
						if (impactedClone.getObjTypeName().split("-")[0].equals(usageAnalysis)) {
							impactedClone.setUsed("Y");
						}
					}
				}
			}

			// Impacted due to Simplification
			impactedClone.setImpactedSimpl("");
			for (S4HanaProfiler dblist : s4DetailReport) {
				if (impactedClone.getObjTypeName().equals(dblist.getObjNameType())) {
					impactedClone.setImpactedSimpl("Y");
				}
				if ("FUGR".equalsIgnoreCase(impactedClone.getObjType())) {
					if (impactedClone.getObjTypeName().split("-")[0].equals(dblist.getObjNameType())) {
						impactedClone.setImpactedSimpl("Y");
					}
				}
			}

			for (S4SimplificationDatabase dblist : simplificationList) {
				if (impactedClone.getObjTypeName().equals(dblist.getObjectType().concat(dblist.getObject()))) {
					impactedClone.setImpactedSimpl("Y");
				}
				if ("FORM".equalsIgnoreCase(impactedClone.getObjType())
						|| "SSFO".equalsIgnoreCase(impactedClone.getObjType())) {
					if (!dblist.getObject().equalsIgnoreCase(impactedClone.getInterfaceObj())) {
						flag = true;
					}
				}
				if ("FUGR".equalsIgnoreCase(impactedClone.getObjType())) {
					if (impactedClone.getObjTypeName().split("-")[0]
							.equals(dblist.getObjectType().concat(dblist.getObject()))) {
						impactedClone.setImpactedSimpl("Y");
					}
				}
			}

			// Impacted due to DB change
			impactedClone.setImpactedDB("");
			for (HanaProfile dblist : hanaDetailReport) {
				if (impactedClone.getObjTypeName().equals(dblist.getObjNameType())) {
					impactedClone.setImpactedDB("Y");
				}
				if ("FUGR".equalsIgnoreCase(impactedClone.getObjType())) {
					if (impactedClone.getObjTypeName().split("-")[0].equals(dblist.getObjNameType())) {
						impactedClone.setImpactedDB("Y");
					}
				}
			}

			// Impacted due to Existing Error
			impactedClone.setImpactedExistingError("");
			for (AuctFinalOutput dblist : existingErrorDetailReport) {
				if (impactedClone.getObjTypeName().equals(dblist.getOBJ_NAME_TYPE())) {
					impactedClone.setImpactedExistingError("Y");
				}
				if ("FUGR".equalsIgnoreCase(impactedClone.getObjType())) {
					if (impactedClone.getObjTypeName().split("-")[0].equals(dblist.getOBJ_NAME_TYPE())) {
						impactedClone.setImpactedExistingError("Y");
					}
				}
			}

			// Impacted due to OS Migration
			impactedClone.setImpactedOSMigration("");
			for (OSMigrationFinal dblist : osMigrationFinalReportList) {
				if (impactedClone.getObjTypeName().equals(dblist.getObjTypeName())) {
					impactedClone.setImpactedOSMigration("Y");
				}
				if ("FUGR".equalsIgnoreCase(impactedClone.getObjType())) {
					if (impactedClone.getObjTypeName().split("-")[0].equals(dblist.getObjTypeName())) {
						impactedClone.setImpactedOSMigration("Y");
					}
				}
			}

			if (!flag) {

				// Setting External Namespace
				if (CollectionUtils.isNotEmpty(externalNamespaceList)
						&& !externalNamespaceList.stream().anyMatch("NA"::equalsIgnoreCase)) {
					if (!impactedClone.getObjName().isEmpty()) {
						for (String externalNamespace : externalNamespaceList) {
							if ((StringUtils.containsIgnoreCase(impactedClone.getObjName().trim(),
									externalNamespace.trim()))) {
								impactedClone.setExternalNamespace("Y");
								;
								break;
							}
						}
					}
				}
				impactedCloneAnalysisList.add(impactedClone);
			}
		}
		St03ReaderXlsx.impactedCloneBatchInsertUpdate(impactedCloneAnalysisList, getSession());

	}

	public String requestIdUIGenerator(RequestForm requestForm) {

		// getting Client Name form request Form first 5 digits
		String RID_ClientName;

		String clientName = requestForm.getClientName();
		clientName = clientName.replaceAll("\\s", "");

		if (clientName.length() < 5) {
			int counter = 5 - clientName.length();
			do {
				counter--;
				clientName = clientName + "0";
			} while (counter != 0);
			RID_ClientName = clientName;
		} else {
			RID_ClientName = clientName.substring(0, 5);
		}

		// Getting scopes values from form submitted by user
		String RID_Scope = "";

		boolean SOH = requestForm.getSOH(), S4Technical = requestForm.getS4Technical(), Fiori = requestForm.getFiori(),
				Odata = false, UI5 = requestForm.getUI5(), UPGRADE = requestForm.getUPGRADE(),
				S4Functional = requestForm.getS4Functional(), EXT = requestForm.getEXT();
		int flag = 0;

		if (UPGRADE) {
			RID_Scope = "UPGR";
			flag = 1;
		}
		if (SOH) {
			RID_Scope = "MIGR";
			flag = 1;
		}
		if (SOH && S4Technical) {
			RID_Scope = "CONV";
			flag = 1;
		}
		if (Fiori || Odata || UI5) {
			RID_Scope = "ODUX";
			flag = 1;
		}

		if (S4Functional) {
			RID_Scope = "FUNC";
			flag = 1;
		}

		if (UPGRADE && SOH) {
			RID_Scope = "UPMG";
			flag = 1;
		}
		if (SOH && S4Technical && Fiori || Odata || UI5) {
			RID_Scope = "COUX";
			flag = 1;
		}
		if (SOH && S4Technical && S4Functional) {
			RID_Scope = "COFN";
			flag = 1;
		}
		if (SOH && S4Technical && S4Functional && Fiori || Odata || UI5) {
			RID_Scope = "CFUX";
			flag = 1;
		}
		if (S4Functional && Fiori || Odata || UI5) {
			RID_Scope = "FNUX";
			flag = 1;
		}
		if (EXT) {
			RID_Scope = "EXTN";
			flag = 1;
		}
		if (flag == 0) {
			RID_Scope = "OTHR";
		}

		// getting scope value from request Form
		String SID = requestForm.getSystemId();
		if (SID.length() < 3) {
			int counter = 3 - SID.length();
			do {
				counter--;
				SID = SID + "0";
			} while (counter != 0);
			SID = SID;
		} else {
			SID = SID.substring(0, 3);
		}

		String RID_UI = RID_ClientName + RID_Scope + SID.toUpperCase();
		RID_UI = RID_UI.toUpperCase();
		;

		int Counter = 1;
		String RequestID_UI = getRequestDetails().ValidateRequestIDGenerator(RID_UI);
		if (RequestID_UI.equals("Blank")) {
			RID_UI = RID_UI + "0" + Counter;
		} else {
			Counter = Integer.parseInt(RequestID_UI.substring(12, 14));
			Counter++;
			if (Counter <= 9) {
				RID_UI = RID_UI + "0" + Counter;
			} else {
				RID_UI = RID_UI + Counter;
			}
		}
		return RID_UI;
	}

	private void clientFileProcessingBusinessLogicOSMigration(final long requestID, HttpServletRequest request,
			final String toolName, HttpSession session) throws Exception {
		String status = "";

		try {
			Hana_Profiler_Constant.REQUEST_PROGRESS_MAP.remove(requestID);

			String systemStatus = getAutoHANA().getSystemStatus(requestID);

			status = Hana_Profiler_Constant.IDVSUCESS_STATUS;

			logger.info("Inside Client File Processing method: OS Migration");

			boolean st03Status = false;

			if (Hana_Profiler_Constant.IDVSUCESS_STATUS.equalsIgnoreCase(systemStatus)
					|| Hana_Profiler_Constant.ST03FAILED_STATUS.equalsIgnoreCase(systemStatus)) {

				if (Hana_Profiler_Constant.ST03FAILED_STATUS.equalsIgnoreCase(systemStatus)) {
					status = Hana_Profiler_Constant.ST03FAILED_STATUS;
				}

				st03Status = osMigrationService.analyseOSMigrationData(requestID, toolName, session);
				if (st03Status)
					status = Hana_Profiler_Constant.ST03SUCCESS_STATUS;
			}
		} catch (Exception e) {
			status = Hana_Profiler_Constant.ST03_FAILURE_MSG;
			throw new Exception(status);
		}
	}

	public String requestIdUIGeneratorForSubRequest(RequestForm requestForm) {

		// getting Client Name form request Form first 5 digits
		String RID_ClientName;

		String clientName = requestForm.getClientName();
		clientName = clientName.replaceAll("\\s", "");

		if (clientName.length() < 5) {
			int counter = 5 - clientName.length();
			do {
				counter--;
				clientName = clientName + "0";
			} while (counter != 0);
			RID_ClientName = clientName;
		} else {
			RID_ClientName = clientName.substring(0, 5);
		}

		// Getting scopes values from form submitted by user
		String RID_Scope = "";

		boolean SOH = requestForm.getSOH(), S4Technical = requestForm.getS4Technical(), Fiori = requestForm.getFiori(),
				Odata = false, UI5 = requestForm.getUI5(), UPGRADE = requestForm.getUPGRADE(),
				S4Functional = requestForm.getS4Functional(), EXT = requestForm.getEXT();
		int flag = 0;

		if (UPGRADE) {
			RID_Scope = "UPGR";
			flag = 1;
		}
		if (SOH) {
			RID_Scope = "MIGR";
			flag = 1;
		}
		if (SOH && S4Technical) {
			RID_Scope = "CONV";
			flag = 1;
		}
		if (Fiori || Odata || UI5) {
			RID_Scope = "ODUX";
			flag = 1;
		}

		if (S4Functional) {
			RID_Scope = "FUNC";
			flag = 1;
		}

		if (UPGRADE && SOH) {
			RID_Scope = "UPMG";
			flag = 1;
		}
		if (SOH && S4Technical && Fiori || Odata || UI5) {
			RID_Scope = "COUX";
			flag = 1;
		}
		if (SOH && S4Technical && S4Functional) {
			RID_Scope = "COFN";
			flag = 1;
		}
		if (SOH && S4Technical && S4Functional && Fiori || Odata || UI5) {
			RID_Scope = "CFUX";
			flag = 1;
		}
		if (S4Functional && Fiori || Odata || UI5) {
			RID_Scope = "FNUX";
			flag = 1;
		}
		if (EXT) {
			RID_Scope = "EXTN";
			flag = 1;
		}
		if (flag == 0) {
			RID_Scope = "OTHR";
		}

		// getting scope value from request Form
		String SID = requestForm.getSystemId();
		if (SID.length() < 3) {
			int counter = 3 - SID.length();
			do {
				counter--;
				SID = SID + "0";
			} while (counter != 0);
			SID = SID;
		} else {
			SID = SID.substring(0, 3);
		}

		String RID_UI = "SUB" + RID_ClientName + RID_Scope + SID.toUpperCase();
		RID_UI = RID_UI.toUpperCase();

		int Counter = 1;
		String RequestID_UI = getRequestDetails().ValidateRequestIDGeneratorSubRequest(RID_UI);
		if (RequestID_UI.equals("Blank")) {
			RID_UI = RID_UI + "0" + Counter;
		} else {

			Counter = Integer.parseInt(RequestID_UI.substring(15, 17));
			Counter++;
			if (Counter <= 9) {
				RID_UI = RID_UI + "0" + Counter;
			} else {
				RID_UI = RID_UI + Counter;
			}

		}
		return RID_UI;
	}

	/*
	 * String uploadPath =null; String filename=""; ReadtheExcel call = null;
	 * 
	 * 
	 * public String inputFileMigrationRead(final long requestId,
	 * HttpServletRequest request, final String toolName, HttpSession
	 * session,DisplayGraphS4DAO graphS4DAO) throws Exception { final
	 * RequestForm requestForm = getRequestDetails().getRequestObj(requestId);
	 * logger.info("Welcome to inputFileMigrationRead for reading the excel");
	 * logger.info("Client Name"+requestForm.getClientName()); call = new
	 * ReadtheExcel(); String status = "";
	 * 
	 * try {
	 * 
	 * String rootPath =
	 * HANAUtility.getFinalFilePath(requestForm.getClientName(), requestId);
	 * File folder = new File(rootPath); File[] listOfFiles =
	 * folder.listFiles();
	 * 
	 * for (File file : listOfFiles) { if (file.isFile()) {
	 * logger.info("USER Uploaded File"+file.getName()); String
	 * retrievedcompleteFilePath = rootPath+"\\"+file.getName();
	 * logger.info("Retrieved complete FilePath "+retrievedcompleteFilePath);
	 * 
	 * try { getAutoHANA().clearAllTablesForUtility(requestId); }
	 * catch(Exception e) { status =
	 * Hana_Profiler_Constant.UTILITY_EXECUTION_STATUS2;
	 * logger.error("Error while deleting POC migration data :: " + e);
	 * logger.error("Error !!! " + e); logger.error(e.getMessage());
	 * logger.trace(e.getMessage()); throw new
	 * Exception("Error while deleting POC migration data"); }
	 * 
	 * call.uploadedFile(retrievedcompleteFilePath);
	 * 
	 * call.excelinventoryList(requestId,session);
	 * call.impactedObjectList(requestId,session);
	 * call.drdbChangeList(requestId,session);
	 * call.drs4SimplificationOneList(requestId,session);
	 * 
	 * 
	 * 
	 * 
	 * 
	 * call.outputManagementList(requestId,session);
	 * call.affectedbyCustomFieldsList(requestId,session);
	 * call.drs4SimplificationTwoList(requestId,session);
	 * call.drs4SimplificationThreeList(requestId,session);
	 * 
	 * try { ProcessedRequestDetail requestMasterCommon = getGraphDao()
	 * .getRequestMasterCommonColumns(requestId);
	 * getGraphDao().getRequestMasterCommonColumns(requestId);
	 * getGraphDao().updateRequestMaster(requestId, requestMasterCommon);
	 * graphS4DAO.updateRequestMasterS4(requestId, requestMasterCommon); }
	 * catch(Exception e) { status =
	 * Hana_Profiler_Constant.UTILITY_EXECUTION_STATUS2; logger.
	 * error("Error while Request Master calculation in POC migration process :: "
	 * + e); logger.error("Error !!! " + e); logger.error(e.getMessage());
	 * logger.trace(e.getMessage()); throw new
	 * Exception("Error while Request Master calculation in POC migration process"
	 * ); }
	 * 
	 * 
	 * try { DataTransfer(requestId); } catch(Exception e) { status =
	 * Hana_Profiler_Constant.UTILITY_EXECUTION_STATUS2;
	 * logger.error("Error while data Transfering POC migration process :: " +
	 * e); logger.error("Error !!! " + e); logger.error(e.getMessage());
	 * logger.trace(e.getMessage()); throw new
	 * Exception("Error while data Transfering POC migration process"); }
	 * 
	 * try {
	 * 
	 * getAutoHANA().clearAllTablesForUtility(requestId);
	 * 
	 * } catch(Exception e) { status =
	 * Hana_Profiler_Constant.UTILITY_EXECUTION_STATUS2; logger.
	 * error("Error while Utility data clearing POC migration process :: " + e);
	 * logger.error("Error !!! " + e); logger.error(e.getMessage());
	 * logger.trace(e.getMessage()); throw new
	 * Exception("Error while Utility data clearing POC migration process"); }
	 * status = Hana_Profiler_Constant.UTILITY_EXECUTION_STATUS1;
	 * 
	 * } }
	 * 
	 * 
	 * } catch (Exception e) { status =
	 * Hana_Profiler_Constant.UTILITY_EXECUTION_STATUS2; logger.
	 * error("Exception in Poc migration---- inputFileMigrationRead()  :: " +
	 * e); logger.error("Error !!! " + e); logger.error(e.getMessage());
	 * logger.trace(e.getMessage()); throw new
	 * Exception("Exception in Poc migration---- inputFileMigrationRead() ");
	 * 
	 * }
	 * 
	 * return status; }
	 * 
	 * 
	 */
}
