package com.act.staticinfo.dao;

import java.util.List;

import com.act.client.model.RequestFormFile;

public interface RequestFormFileDAO {

	List<RequestFormFile> getRequestFormFile(Long requestID);

	public boolean getFiatFile1Status(Long requestID);

	public boolean getFiatFile2Status(long requestID);

	void updateFIATFile1Satus(Long requestID, boolean status);

	void updateFIATFile2Satus(Long requestID, boolean status);

	void updateRequestInventorySatus(Long requestID, String status, String pocSubStatus, String comments);

	public void UpdateRequestFormFile(RequestFormFile requestFormFile);

	public RequestFormFile getRequestFormFileObj(long requestID);
}
