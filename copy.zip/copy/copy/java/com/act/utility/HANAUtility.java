/*CR-No.     Desc        Date        Modified By
 * 
 * CR-9.0:- Manual upload for Estimator & assuptions -17/01/17 -monika.mishra
 * 
 * 
 *CR-29.0:- Shown CDS View on basis of tables column value -5/08/17 -monika.mishra
 *
 *CR-39.0:- Upload Consolidated file for HANA,S4,Consolidated -5/10/17 -monika.mishra
 *
 *US-03.2: Merge Upload Logic of Hana, S4 & AUCT: Upload Input Sheets -02/08/2018 -himani.malhotra
 *
 *DEF075: Impacted IDOC New Requirements -17/05/2019 -himani.malhotra
 **/



package com.act.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.act.S4.constant.S4HanaProfilerConstant;
import com.act.constant.Hana_Profiler_Constant;
import com.act.constant.ST03HanaConstant;
import com.act.constant.Services_Constant;

public class HANAUtility {

	private static final Map<String, Map<String, String>> PROPERTY_FILES_MAP = new HashMap<String, Map<String, String>>();

	private static final Logger logger = LoggerFactory.getLogger(HANAUtility.class);

	public static String getServerRootPath() {
		return System.getProperty("catalina.home");
	}

	public static String getFilePath(String clientName, long requestId){
		final File file = new File(getServerRootPath() + File.separator + "tempFiles" + File.separator + clientName
				+ Hana_Profiler_Constant.FILE_NAME_SEPARATOR + requestId);
		String path = "";
		try {
			if (!file.exists()) {
				file.mkdirs();
			}
			path = file.getCanonicalPath();
		} catch (IOException e) {
			logger.error(e.getMessage());
		}
		
		return path;
	}
	
	public static String getRepositoryTemp(String clientName, long requestId) {
		final File file = new File(getServerRootPath() + File.separator + "tempFiles" + File.separator + "TEMPFILE" + clientName
				+ Hana_Profiler_Constant.FILE_NAME_SEPARATOR + requestId);
		String repoTempPath = "";
		try {
			if (!file.exists()) {
				file.mkdirs();
			}
		    
			repoTempPath = file.getCanonicalPath();
		} catch (IOException e) {
			logger.error(e.getMessage());
		}
		return repoTempPath;
	}

	public static String getFinalFilePath(String clientName, long requestId) {
		final File file = new File(getServerRootPath() + File.separator + "MigrationFiles" + File.separator + clientName
				+ Hana_Profiler_Constant.FILE_NAME_SEPARATOR + requestId);
		String migrationFilePath = "";
		try {
			if (!file.exists()) {
				file.mkdirs();
			}
			
			migrationFilePath = file.getCanonicalPath();
		} catch (IOException e) {
			logger.error(e.getMessage());
		}
		
		return migrationFilePath;
	}
	
	public static String getEstimatesFileUploadPath(String clientName, long requestId) {
		final File file = new File(getServerRootPath() + File.separator + "POC_EstimatesFiles" + File.separator + clientName
				+ Hana_Profiler_Constant.FILE_NAME_SEPARATOR + requestId);
		String estimatesFilePath = "";
		try {
			if (!file.exists()) {
				file.mkdirs();
			}
			estimatesFilePath = file.getCanonicalPath();
		} catch(IOException e) {
			logger.error(e.getMessage());
		}
		
		return estimatesFilePath;
	}
	
	public static String getRomEstimatesFileUploadPath(String clientName, long requestId) {
		final File file = new File(getServerRootPath() + File.separator + "ROM_Estimates_POC" + File.separator + clientName
				+ Hana_Profiler_Constant.FILE_NAME_SEPARATOR + requestId);
		String romEstimatesFilePath = "";
		try {
			if (!file.exists()) {
				file.mkdirs();
			}
			romEstimatesFilePath = file.getCanonicalPath();
		} catch(IOException e) {
			logger.error(e.getMessage());
		}
		
		return romEstimatesFilePath;
	}
	
	public static String getFinalReportFilePath(String clientName, long requestId) {
		final File file = new File(getServerRootPath() + File.separator + "FinalReports" + File.separator + clientName
				+ Hana_Profiler_Constant.FILE_NAME_SEPARATOR + requestId);
		String finalReportFilePath = "";
		try {
			if (!file.exists())
				file.mkdirs();
			
			finalReportFilePath = file.getCanonicalPath();
		} catch (IOException e) {
			logger.error(e.getMessage());
		}
		
		return finalReportFilePath;
	}

	public static void deleteFile(String clientName, long requestId, String fileNameToBeDeleted) 
	{		
		//In case any file buffer is left open, we need to close the same for ensuring the file deletion.
		try 
		{
			System.gc();
			final File directory = new File(getServerRootPath() + File.separator + "tempFiles" + File.separator + clientName
					+ Hana_Profiler_Constant.FILE_NAME_SEPARATOR + requestId);
			if (directory.exists()) {
				File[] files = directory.listFiles();
				if (files != null && files.length > 0) {
					for (File file : files) {
						String fileName = file.getName();
						//This is for upload estimation method.
						if(null==fileNameToBeDeleted) {
							file.delete();
						}
						else
						{
							//If the directory contains a file that has fileNameToBeDeleted, then delete it 
							if(fileName.equalsIgnoreCase(fileNameToBeDeleted))
							{
								file.delete();
							}
						}
					}
				}
			}
		} catch (Exception e) {
			logger.error("Error !!! " + e);
		}
	}

	public static void deleteUploadFile(String clientName, long requestId, String fileNameToBeDeleted) 
	{		
		//In case any file buffer is left open, we need to close the same for ensuring the file deletion.
		try 
		{
			System.gc();
			final File directory = new File(getServerRootPath() + File.separator + "tempFiles" + File.separator + clientName
					+ Hana_Profiler_Constant.FILE_NAME_SEPARATOR + requestId);
			if (directory.exists()) 
			{
				File[] files = directory.listFiles();
				if (files != null && files.length > 0)
				{
					for (File file : files) 
					{
						String fileName = ((file.getName()).split("\\.")[0]);
						//This is for upload estimation method.
						if(null==fileNameToBeDeleted)
						{
							file.delete();
						}
						else
						{
							//If the directory contains a file that has fileNameToBeDeleted, then delete it 
							if(fileName.equalsIgnoreCase(fileNameToBeDeleted))
							{
								file.delete();
							}
						}
					}
				}
			}
		} catch (Exception e)  {
			logger.error("Error !!! " + e);
		}
	}
	
	public static String getPropertyValue(final String fileName, final String key) throws IOException {
		final Map<String, String> propertyFileMap = getAllPropertyValue(fileName);
		return propertyFileMap.get(key);
	}
	
	public static String getPropertyValueEnv(final String fileName, final String key) throws IOException {
		final Map<String, String> propertyFileMap = getAllPropertyValueEnv(fileName);
		return propertyFileMap.get(key);
	}
	
	public static Map<String, String> getAllPropertyValueEnv(final String fileName) throws IOException {
		Map<String, String> propertyFileMap = PROPERTY_FILES_MAP.get(fileName);
		if (propertyFileMap == null) {
			propertyFileMap = new HashMap<String, String>();
			InputStream input = HANAUtility.class.getClassLoader().getResourceAsStream(fileName);
			// logger.info("after fileinput stream");
			Properties prop = new Properties();
			prop.load(input);

			Set<Object> keys = prop.keySet();
			for (Object propertyKey : keys) {
				propertyFileMap.put(propertyKey.toString().trim(), prop.get(propertyKey).toString().trim());
			}
			PROPERTY_FILES_MAP.put(fileName, propertyFileMap);
		}

		return propertyFileMap;
	}
	
	

	public static Map<String, String> getAllPropertyValue(final String fileName) throws IOException {
		Map<String, String> propertyFileMap = PROPERTY_FILES_MAP.get(fileName);
		if (propertyFileMap == null) {
			propertyFileMap = new HashMap<String, String>();
			InputStream input = HANAUtility.class.getClassLoader().getResourceAsStream(fileName);
			Properties prop = new Properties();
			prop.load(input);

			Set<Object> keys = prop.keySet();
			for (Object propertyKey : keys) {
				propertyFileMap.put(propertyKey.toString(), prop.get(propertyKey).toString().toLowerCase());
			}
			PROPERTY_FILES_MAP.put(fileName, propertyFileMap);
		}

		return propertyFileMap;
	}

	public static String join(final String separator, final String... value) {
		final StringBuffer finalString = new StringBuffer();
		for (String s : value) {
			if (s != null) {
				finalString.append(separator);
				finalString.append(s);

			}
		}
		return StringUtils.substring(finalString.toString(), 1);
	}

	public static String checkSubType(String subType) {
		if (Hana_Profiler_Constant.Include.equalsIgnoreCase(subType)) {
			subType = Hana_Profiler_Constant.IP;
		} else if (Hana_Profiler_Constant.Subroutine.equalsIgnoreCase(subType)) {
			subType = Hana_Profiler_Constant.SP;
		} else if (Hana_Profiler_Constant.Module.equalsIgnoreCase(subType)) {
			subType = Hana_Profiler_Constant.MP;
		} else if (Hana_Profiler_Constant.Function.equalsIgnoreCase(subType)) {
			subType = Hana_Profiler_Constant.FG;
		} else if ((Hana_Profiler_Constant.Executable.equalsIgnoreCase(subType.replaceAll("\\.0", "")))) {
			subType = Hana_Profiler_Constant.EP;
		}

		return subType;
	}

	public static String getBlankvalueIfNull(String value) {
		return value == null || value.equals(Hana_Profiler_Constant.NULL) ? StringUtils.EMPTY : value;
	}

	public static String getBusinessStatus(final String status) {
		String businessStatus = status;
		if (Hana_Profiler_Constant.ST03FAILED_STATUS.equalsIgnoreCase(status)
				|| Hana_Profiler_Constant.ST03SUCCESS_STATUS.equalsIgnoreCase(status)
				|| Hana_Profiler_Constant.HANAQUERYSUCCESS_STATUS.equalsIgnoreCase(status)
				|| Hana_Profiler_Constant.HANAQUERYFAILED_STATUS.equalsIgnoreCase(status)
				|| Hana_Profiler_Constant.HANAREFININGFAILED_STATUS.equalsIgnoreCase(status)) {
			businessStatus = Hana_Profiler_Constant.NOT_COMPLETED_STATUS;
		} /*CR-9.0 Monika*/
		else if (Hana_Profiler_Constant.HANAREFININGSUCCESS_STATUS.equalsIgnoreCase(status)) {
			businessStatus = Hana_Profiler_Constant.COMPLETED_PENDING_ESTIMATIONS;
		}else if (Hana_Profiler_Constant.HANAREFININGCOMPLETED_STATUS.equalsIgnoreCase(status)) {
			businessStatus = Hana_Profiler_Constant.COMPLETED_STATUS;
		}
		return businessStatus;

	}

	public static List<String> getApplicationStatus(final String status) {
		final List<String> applicationStatusList = new ArrayList<String>();
		/*CR 9.0 Monika*/
		if (Hana_Profiler_Constant.COMPLETED_PENDING_ESTIMATIONS.equalsIgnoreCase(status)) {
			applicationStatusList.add(Hana_Profiler_Constant.HANAREFININGSUCCESS_STATUS);
		}else if (Hana_Profiler_Constant.COMPLETED_STATUS.equalsIgnoreCase(status)) {
			applicationStatusList.add(Hana_Profiler_Constant.HANAREFININGCOMPLETED_STATUS);
		}else if (Hana_Profiler_Constant.NOT_COMPLETED_STATUS.equalsIgnoreCase(status)) {
			applicationStatusList.add(Hana_Profiler_Constant.ST03FAILED_STATUS);
			applicationStatusList.add(Hana_Profiler_Constant.ST03SUCCESS_STATUS);
			applicationStatusList.add(Hana_Profiler_Constant.HANAQUERYFAILED_STATUS);
			applicationStatusList.add(Hana_Profiler_Constant.HANAQUERYSUCCESS_STATUS);
			applicationStatusList.add(Hana_Profiler_Constant.HANAREFININGFAILED_STATUS);
		} else {
			applicationStatusList.add(status);
		}

		return applicationStatusList;
	}

	public static void changeRequestProgressValue(final Long requestId, final Integer percentValue,
			final String comments) {
		Map<String, String> percentCommentmap = new HashMap<String, String>();
		percentCommentmap.put(Hana_Profiler_Constant.PERCENTAGE_KEY, Integer.toString(percentValue));
		percentCommentmap.put(Hana_Profiler_Constant.COMMENTS_KEY, comments);
		Hana_Profiler_Constant.REQUEST_PROGRESS_MAP.put(requestId, percentCommentmap);
	}

	public static String getRequiredColumnList(String fileName) {

		String reqColumnListString = null;
		if (fileName.indexOf(ST03HanaConstant.HANA_CONSTANT) != -1) {
			reqColumnListString = ST03HanaConstant.HANA_REQUIRED_COLUMN_LIST;
		} else if (fileName.indexOf(ST03HanaConstant.ST03N_CONSTANT) != -1) {
			reqColumnListString = ST03HanaConstant.ST03N_REQUIRED_COLUMN_LIST;
		} else if (fileName.indexOf(ST03HanaConstant.TADIR_CONSTANT) != -1) {
			reqColumnListString =ST03HanaConstant.TADIR_REQUIRED_COLUMNS;;
		} else if (fileName.indexOf(ST03HanaConstant.TSTC_CONSTANT) != -1) {
			reqColumnListString = ST03HanaConstant.TSTC_REQUIRED_COLUMNS;
		} else if (fileName.indexOf(ST03HanaConstant.TSTCP_CONSTANT) != -1) {
			reqColumnListString = ST03HanaConstant.TSTCP_REQUIRED_COLUMNS;
		} else if (fileName.indexOf(ST03HanaConstant.INCLUDE_CONSTANT) != -1) {
			reqColumnListString = ST03HanaConstant.INCLUDE_REQUIRED_COLUMNS;
		} else if ((fileName.toLowerCase().indexOf(ST03HanaConstant.TRD_CONSTANT) != -1)) {
			reqColumnListString = ST03HanaConstant.TRD_REQUIRED_COLUMNS;
		}//CR-29.0
		else if (fileName.indexOf(ST03HanaConstant.CDS_CONSTANT) != -1) {
			reqColumnListString = ST03HanaConstant.CDS_REQUIRED_COLUMN_LIST;
		} //CR-52.0
		else if (fileName.indexOf(ST03HanaConstant.USAGE_CONSTANT) != -1) {
			reqColumnListString = ST03HanaConstant.USAGE_REQUIRED_COLUMN_LIST;
		} else {
			reqColumnListString = ST03HanaConstant.UNEXPECTED_FILE_FOUND_MESSAGE;
		}
		return reqColumnListString;
	}

	public static String getCellData(Cell cell) {
		String data = "";
		if (cell == null) {
			data = "";
		} else {

			switch (cell.getCellType()) {
			case Cell.CELL_TYPE_NUMERIC:
				data = String.valueOf(cell.getNumericCellValue());
				break;
			case Cell.CELL_TYPE_STRING:
				data = cell.getStringCellValue();
				break;
			default:
				data = "Either blank or unknown";

			}
		}
		return data;

	}

	public static String getMonthEntry(String filePath) {

		String fileName = new File(filePath).getName();
		String year = fileName.substring(6, 10);
		String month = fileName.substring(11, 13);
		String monthEntry = month + year;

		return monthEntry;

	}

	public static Map<String, String> getRequiredColumnProperties(String fileName, String toolName) {				

		Map<String, String> propertyFileMap= new HashMap<String,String>();
		try {
			if("CreateSimplification".equalsIgnoreCase(toolName)){
				if (fileName.toUpperCase().indexOf(Services_Constant.ZAICAT_DETECTION) != -1) {
					propertyFileMap = getAllPropertyValue("ZAICAT_Detection.properties");
				} else if (fileName.toUpperCase().indexOf(ST03HanaConstant.SIMPLIFICATION_LATEST_CONSTANT) != -1) {
					propertyFileMap = getAllPropertyValue("Simplification_Latest_Columns.properties");
				} else {
					propertyFileMap.put(ST03HanaConstant.UNEXPECTED_FILE_FOUND_MESSAGE, ST03HanaConstant.UNEXPECTED_FILE_FOUND_MESSAGE);
				}
			}
			
			else if("Simplification".equalsIgnoreCase(toolName)){
				if (fileName.toUpperCase().indexOf((S4HanaProfilerConstant.BIG_SIMPLIFICATION_CONSTANT).toUpperCase()) != -1) {
					propertyFileMap = getAllPropertyValue("Big_Simplification.properties");
				} else {
					propertyFileMap.put(ST03HanaConstant.UNEXPECTED_FILE_FOUND_MESSAGE, ST03HanaConstant.UNEXPECTED_FILE_FOUND_MESSAGE);
				}
			}
			
			else if("TCDSimplification".equalsIgnoreCase(toolName)){
				if (fileName.toUpperCase().indexOf((S4HanaProfilerConstant.TCD_SIMPLIFICATION_CONSTANT).toUpperCase()) != -1) {
					propertyFileMap = getAllPropertyValue("TCD_Simplification.properties");
				} else {
					propertyFileMap.put(ST03HanaConstant.UNEXPECTED_FILE_FOUND_MESSAGE, ST03HanaConstant.UNEXPECTED_FILE_FOUND_MESSAGE);
				}
			}
			
			else if ("Tar_Usobtc".equalsIgnoreCase(toolName)) {
				if (fileName.toUpperCase().indexOf((S4HanaProfilerConstant.TARGET_USOBTC).toUpperCase()) != -1) {
					propertyFileMap = getAllPropertyValue("Tar_Usobtc.properties");
				} else {
					propertyFileMap.put(ST03HanaConstant.UNEXPECTED_FILE_FOUND_MESSAGE,
							ST03HanaConstant.UNEXPECTED_FILE_FOUND_MESSAGE);
				}
			} 
			
			else if ("GRC_STANDARDRULES".equalsIgnoreCase(toolName)) {
				if (fileName.toUpperCase().indexOf((S4HanaProfilerConstant.GRC_STANDARD_RULESET).toUpperCase()) != -1) {
					propertyFileMap = getAllPropertyValue("Grc_Standard_Ruleset.properties");
				} else {
					propertyFileMap.put(ST03HanaConstant.UNEXPECTED_FILE_FOUND_MESSAGE,
							ST03HanaConstant.UNEXPECTED_FILE_FOUND_MESSAGE);
				}
			} 
			
			else if ("BW_EXTRACT_MASTER".equalsIgnoreCase(toolName)) {
				if (fileName.toUpperCase().indexOf((S4HanaProfilerConstant.BW_EXTRACT_MASTER_CONSTANT).toUpperCase()) != -1) {
					propertyFileMap = getAllPropertyValue("BW_EXTRACT_MASTER.properties");
				} else {
					propertyFileMap.put(ST03HanaConstant.UNEXPECTED_FILE_FOUND_MESSAGE,
							ST03HanaConstant.UNEXPECTED_FILE_FOUND_MESSAGE);
				}
			}
			
			else if ("TCODE_SUBPROCESS".equalsIgnoreCase(toolName)) {
				propertyFileMap = getAllPropertyValue("Tcode_SubProcess_Mapping.properties");
			} 
			
			else if ("APPCOMP_SUBPROCESS".equalsIgnoreCase(toolName)) {
				propertyFileMap = getAllPropertyValue("AppComponent_SubProcess_Mapping.properties");
			}
			
			else if ("Testing Scope".equalsIgnoreCase(toolName)) {
				propertyFileMap = getAllPropertyValue("IRPA_TScope_Report.properties");
			}
			else if ("Fiori_Rebuild_Master".equalsIgnoreCase(toolName)) {
				propertyFileMap = getAllPropertyValue("Fiori_Rebuild_Master.properties");
			}
		} catch (IOException e) {
			logger.error("Error !!! " + e);
		}
		return propertyFileMap;
	}
	
	/**
	 * The name of the uploaded file should start with the name of the properties file
	 * If the match is found, the respective properties file is loaded
	 * @param fileName
	 * @return
	 * @throws URISyntaxException
	 * @throws IOException
	 */
	public static Map<String, String> getClientUploadFilesRequiredColumns (String fileName) throws URISyntaxException, IOException {
		Map<String, String> propertyFileMap= new HashMap<String,String>();
		Properties property = new Properties();
		
		Path clientFilesPath = Paths
				.get(UtilityForPoc.class.getClassLoader().getResource("Client_Upload_ManFiles_Cols_Properties").toURI());

		String pocPropertySheetsPath = clientFilesPath.toString();
		File[] propertiesFileList = new File(pocPropertySheetsPath).listFiles();
		for(File propertiesFile : propertiesFileList) {
			if(FilenameUtils.getBaseName(fileName).toUpperCase().
					startsWith(FilenameUtils.getBaseName(propertiesFile.getName()).toUpperCase())) {
				if("RSBKDTPSTAT".equalsIgnoreCase(FilenameUtils.getBaseName(fileName).toUpperCase())) {
					for(File propFile : propertiesFileList) {
						if("RSBKDTPSTAT".equalsIgnoreCase(FilenameUtils.getBaseName(propFile.getName()).toUpperCase())) {
							propertiesFile = propFile;
							break;
						}
					}
				}
				else if("RSZWBTMPDATA".equalsIgnoreCase(FilenameUtils.getBaseName(fileName).toUpperCase())) {
					for(File propFile : propertiesFileList) {
						if("RSZWBTMPDATA".equalsIgnoreCase(FilenameUtils.getBaseName(propFile.getName()).toUpperCase())) {
							propertiesFile = propFile;
							break;
						}
					}
				}
				else if("RSZWTEMPLATE".equalsIgnoreCase(FilenameUtils.getBaseName(fileName).toUpperCase())) {
					for(File propFile : propertiesFileList) {
						if("RSZWTEMPLATE".equalsIgnoreCase(FilenameUtils.getBaseName(propFile.getName()).toUpperCase())) {
							propertiesFile = propFile;
							break;
						}
					}
				}
				else if("RSANT_PROCESSR".equalsIgnoreCase(FilenameUtils.getBaseName(fileName).toUpperCase())) {
					for(File propFile : propertiesFileList) {
						if("RSANT_PROCESSR".equalsIgnoreCase(FilenameUtils.getBaseName(propFile.getName()).toUpperCase())) {
							propertiesFile = propFile;
							break;
						}
					}
				}
				else if("RSRWBINDEXT".equalsIgnoreCase(FilenameUtils.getBaseName(fileName).toUpperCase())) {
					for(File propFile : propertiesFileList) {
						if("RSRWBINDEXT".equalsIgnoreCase(FilenameUtils.getBaseName(propFile.getName()).toUpperCase())) {
							propertiesFile = propFile;
							break;
						}
					}
				}
				else if("RSZWBTMPHEAD".equalsIgnoreCase(FilenameUtils.getBaseName(fileName).toUpperCase())) {
					for(File propFile : propertiesFileList) {
						if("RSZWBTMPHEAD".equalsIgnoreCase(FilenameUtils.getBaseName(propFile.getName()).toUpperCase())) {
							propertiesFile = propFile;
							break;
						}
					}
				}
				else if("RSRWBINDEX".equalsIgnoreCase(FilenameUtils.getBaseName(fileName).toUpperCase())) {
					for(File propFile : propertiesFileList) {
						if("RSRWBINDEX".equalsIgnoreCase(FilenameUtils.getBaseName(propFile.getName()).toUpperCase())) {
							propertiesFile = propFile;
							break;
						}
					}
				}
				else if("RSPCCHAINATTR".equalsIgnoreCase(FilenameUtils.getBaseName(fileName).toUpperCase())) {
					for(File propFile : propertiesFileList) {
						if("RSPCCHAINATTR".equalsIgnoreCase(FilenameUtils.getBaseName(propFile.getName()).toUpperCase())) {
							propertiesFile = propFile;
							break;
						}
					}
				}
				else if("RSLDPIO".equalsIgnoreCase(FilenameUtils.getBaseName(fileName).toUpperCase())) {
					for(File propFile : propertiesFileList) {
						if("RSLDPIO".equalsIgnoreCase(FilenameUtils.getBaseName(propFile.getName()).toUpperCase())) {
							propertiesFile = propFile;
							break;
						}
					}
				}
				else if("RSDS".equalsIgnoreCase(FilenameUtils.getBaseName(fileName).toUpperCase())) {
					for(File propFile : propertiesFileList) {
						if("RSDS".equalsIgnoreCase(FilenameUtils.getBaseName(propFile.getName()).toUpperCase())) {
							propertiesFile = propFile;
							break;
						}
					}
				}
				else if("RSTS".equalsIgnoreCase(FilenameUtils.getBaseName(fileName).toUpperCase())) {
					for(File propFile : propertiesFileList) {
						if("RSTS".equalsIgnoreCase(FilenameUtils.getBaseName(propFile.getName()).toUpperCase())) {
							propertiesFile = propFile;
							break;
						}
					}
				}
				else if("RSUPDINFO".equalsIgnoreCase(FilenameUtils.getBaseName(fileName).toUpperCase())) {
					for(File propFile : propertiesFileList) {
						if("RSUPDINFO".equalsIgnoreCase(FilenameUtils.getBaseName(propFile.getName()).toUpperCase())) {
							propertiesFile = propFile;
							break;
						}
					}
				}
				else if("RSOHCPR".equalsIgnoreCase(FilenameUtils.getBaseName(fileName).toUpperCase())) {
					for(File propFile : propertiesFileList) {
						if("RSOHCPR".equalsIgnoreCase(FilenameUtils.getBaseName(propFile.getName()).toUpperCase())) {
							propertiesFile = propFile;
							break;
						}
					}
				}
				else if("RSQISET".equalsIgnoreCase(FilenameUtils.getBaseName(fileName).toUpperCase())) {
					for(File propFile : propertiesFileList) {
						if("RSQISET".equalsIgnoreCase(FilenameUtils.getBaseName(propFile.getName()).toUpperCase())) {
							propertiesFile = propFile;
							break;
						}
					}
				}
				else if("RSDIOBJ".equalsIgnoreCase(FilenameUtils.getBaseName(fileName).toUpperCase())) {
					for(File propFile : propertiesFileList) {
						if("RSDIOBJ".equalsIgnoreCase(FilenameUtils.getBaseName(propFile.getName()).toUpperCase())) {
							propertiesFile = propFile;
							break;
						}
					}
				}

				InputStream inputStream = new FileInputStream(propertiesFile);
				property.load(inputStream);
				Set<Object> keys = property.keySet();
				for (Object propertyKey : keys) {
					propertyFileMap.put(propertyKey.toString(), property.get(propertyKey).toString().toLowerCase());
				}
				break;
			} 
		}
	   
		return propertyFileMap;
	}
	public static String getHistoricFilePath() {
		final File file = new File(getServerRootPath() + File.separator + "HistoricFiles");
		String migrationFilePath = "";
		try {
			if (!file.exists()) {
				file.mkdirs();
			}
			
			migrationFilePath = file.getCanonicalPath();
		} catch (IOException e) {
			logger.error(e.getMessage());
		}
		
		return migrationFilePath;
	}
}
