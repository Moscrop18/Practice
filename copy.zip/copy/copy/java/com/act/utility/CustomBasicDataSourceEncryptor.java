package com.act.utility;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.dbcp.BasicDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@SuppressWarnings({ "unused"})
public class CustomBasicDataSourceEncryptor extends BasicDataSource {
	
	final public static Logger logger = LoggerFactory.getLogger(CustomBasicDataSourceEncryptor.class);
	
    private static final String key = "aesEncryptionKey";
    private static final String initVector = "encryptionIntVec";
	
	public CustomBasicDataSourceEncryptor() {
        super();
    }

	@Override
	public synchronized void setPassword(String encryptedPwd){
		super.password = decrypt(encryptedPwd);
    }

	@SuppressWarnings("unused")
	public static String encrypt(String value) {
	    try {
	        @SuppressWarnings("unused")
			GCMParameterSpec iv = new GCMParameterSpec(128, initVector.getBytes("UTF-8"));
	        SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"), "AES");
	 
	        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
	        cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);
	 
	        byte[] encrypted = cipher.doFinal(value.getBytes());
	        return Base64.encodeBase64String(encrypted);
	    } catch (Exception ex) {
	    	logger.error("Error !!! " + ex);
	    }
	    return null;
	}
    
    public static String decrypt(String encrypted) {
        try {
            GCMParameterSpec iv = new GCMParameterSpec(128, initVector.getBytes("UTF-8"));
            SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"), "AES");
     
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);
            byte[] original = cipher.doFinal(Base64.decodeBase64(encrypted));
     
            return new String(original);
        } catch (Exception ex) {
        	logger.error("Error !!! " + ex);
        }
     
        return null;
    }

    public static void main(String[] args) {
    	System.out.println(encrypt("root"));
        System.out.println(encrypt("India@1234%"));
    }
}
