package com.act.utility.odatafiori;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonSetter;

public class BadiQuery2 {
	@JsonIgnore
	private Metadata metadata;
	private String releaseGroupText;	
	private String releaseRank;	
	private String releaseGroupId;	
	private String fioriId;	
	private String allReleases;	
	private String externalReleaseName;
	
	public Metadata getMetadata() {
		return metadata;
	}
	 @JsonSetter("__metadata")
	public void setMetadata(Metadata metadata) {
		this.metadata = metadata;
	}

	public String getReleaseGroupText() {
		return releaseGroupText;
	}
	
	@JsonSetter("releaseGroupText")
	public void setReleaseGroupText(String releaseGroupText) {
		this.releaseGroupText = releaseGroupText;
	}
	public String getReleaseRank() {
		return releaseRank;
	}
	
	@JsonSetter("releaseRank")
	public void setReleaseRank(String releaseRank) {
		this.releaseRank = releaseRank;
	}
	public String getReleaseGroupId() {
		return releaseGroupId;
	}
	
	@JsonSetter("releaseGroupId")
	public void setReleaseGroupId(String releaseGroupId) {
		this.releaseGroupId = releaseGroupId;
	}
	public String getFioriId() {
		return fioriId;
	}
	
	@JsonSetter("fioriId")
	public void setFioriId(String fioriId) {
		this.fioriId = fioriId;
	}
	public String getAllReleases() {
		return allReleases;
	}
	
	@JsonSetter("allReleases")
	public void setAllReleases(String allReleases) {
		this.allReleases = allReleases;
	}
	public String getExternalReleaseName() {
		return externalReleaseName;
	}
	
	@JsonSetter("ExternalReleaseName")
	public void setExternalReleaseName(String externalReleaseName) {
		this.externalReleaseName = externalReleaseName;
	}
	
	
	

}
