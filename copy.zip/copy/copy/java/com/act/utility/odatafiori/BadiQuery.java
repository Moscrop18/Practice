package com.act.utility.odatafiori;

public class BadiQuery {
	
	private String releaseGroupId;
	private String fioriId;
	private String allReleases;
	private String type;
	private String name;
	private String file;
	private String description;
	public String getReleaseGroupId() {
		return releaseGroupId;
	}
	public void setReleaseGroupId(String releaseGroupId) {
		this.releaseGroupId = releaseGroupId;
	}
	public String getFioriId() {
		return fioriId;
	}
	public void setFioriId(String fioriId) {
		this.fioriId = fioriId;
	}
	public String getAllReleases() {
		return allReleases;
	}
	public void setAllReleases(String allReleases) {
		this.allReleases = allReleases;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFile() {
		return file;
	}
	public void setFile(String file) {
		this.file = file;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	

}
