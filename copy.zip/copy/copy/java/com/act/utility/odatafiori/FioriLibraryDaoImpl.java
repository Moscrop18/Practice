package com.act.utility.odatafiori;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class FioriLibraryDaoImpl implements FioriLibraryDao{
	
	private HibernateTemplate hibernateTemplate;
	SessionFactory sessionFactory;
	
	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Autowired
	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}
	final Logger logger=LoggerFactory.getLogger(FioriLibraryDaoImpl.class);
	
	/**
	 * Insert data into fiori master sheet
	 */
	public void  insertFioriRecords(List<AppListResultEntity> listOfAppsType, String env) throws SQLException {
		
		
		logger.info("Inside insertFioriRecords Fiori AppListResult");
		 
	      try (Connection conn =DBConfigFiori.getJDBCConnection(env);) {

	         conn.setAutoCommit(false);
	         try (PreparedStatement stmt = conn.prepareStatement(OdataFiori_Constants.SQL_INSERT_FIORI_LIBRARY);) {

	            
	            int counter=1;
	            int batch = 1;
	            for (AppListResultEntity apps :  listOfAppsType) {	            	
	            	
	            	stmt.setString(1,apps.getLocalId());
	            	stmt.setString(2,apps.getFioriId());
	            	stmt.setString(3,apps.getAchLevel2());
	            	stmt.setString(4,apps.getReleaseId());
	            	stmt.setString(5,apps.getBspApplicationURL());
	            	stmt.setString(6,apps.getBspName());
	            	stmt.setString(7,apps.getSemanticObject());
	            	stmt.setString(8,apps.getSemanticAction());
	            	stmt.setString(9,apps.getTechnicalCatalogName());
	            	stmt.setString(10,apps.getTechnicalCatalogDescription());
	            	stmt.setString(11,apps.getBusinessCatalogName());
	            	stmt.setString(12,apps.getBusinessCatalogDescription());
	            	stmt.setString(13,apps.getBusinessGroupName());
	            	stmt.setString(14,apps.getBusinessGroupDescription());
	            	stmt.setString(15,apps.getPrimaryODataServiceName());
	            	stmt.setString(16,apps.getAdditionalODataServices());
	            	stmt.setString(17,apps.getAdditionalODataServicesVersions());
	            	stmt.setString(18,apps.getProductVersionNameBackend());
	            	stmt.setString(19,apps.getPvBackendAll());
	            	stmt.setString(20,apps.getHanaProductVersion());
	            	stmt.setString(21,apps.getProductCategory());
	            	stmt.setString(22,apps.getNoteCollection());
	            	stmt.setString(23,apps.getPrimaryPVOfficialName());
	            	stmt.setString(24,apps.getPvFrontendAll());
	            	stmt.setString(25,apps.getRoleName());
	            	stmt.setString(26,apps.getBusinessRoleOAMName());
	            	stmt.setString(27,apps.getRoleNameBusinessDescCombo());
	            	stmt.setString(28,apps.getAppName());
	            	stmt.setString(29,apps.getExternalReleaseName());
	            	stmt.setString(30,apps.getApplicationType());
	            	stmt.setString(31,apps.getDatabaseApp());
	            	stmt.setString(32,apps.getGtmInnovationName());
	            	stmt.setString(33,apps.getGtmInnovationID());
	            	stmt.setString(34,apps.getPfdbIndustry());
	            	stmt.setString(35,apps.getDescription());
	            	stmt.setString(36,apps.getAch());
	            	stmt.setString(37,apps.getReleaseGroupText());
	            	stmt.setString(38,apps.getBackendMinSP());
	            	stmt.setString(39,apps.getHanaMinSP());
	            	stmt.setString(40,apps.getSolutionsCapabilityID());
	            	stmt.setString(41,apps.getAchL2Text());
	            	stmt.setDouble(42, apps.getReleaseRank());
	            	stmt.setString(43,apps.getTransactionMatch());
	            	stmt.setString(44,apps.getFormFactors());
	            	stmt.setString(45,apps.getPortfolioCategoryIV());
	            	stmt.setString(46,apps.getPortfolioCategoryImp());
	            	stmt.setString(47,apps.getUiTechnology());
	            	stmt.setString(48,apps.getAdditionalIntents());
	            	stmt.setString(49,apps.getSapUI5ComponentId());
	            	stmt.setString(50,apps.getWdaConfiguration());
	            	stmt.setString(51,apps.getGtmLoBName());
	            	stmt.setString(52,apps.getKpiID());
	            	stmt.setString(53,apps.getPrimaryODataServiceVersion());
	            	stmt.setString(54,apps.getPortfolioCategory());
	            	stmt.setString(55,apps.getFrontendProductVersion());
	            	stmt.setString(56,apps.getGtmAppDescription());
	            	stmt.setString(57,apps.getAvailabilityInFaaS());
	            	stmt.setString(58,apps.getSolutionsCapability());
	            	stmt.setString(59,apps.getScopeItemID());
	            	stmt.setString(60,apps.getScopeItemDescription());
	            	stmt.setString(61,apps.getHighlightKey());
	            	stmt.setString(62,apps.getSolutionsCapabilityGUID());
	            	stmt.setString(63,apps.getScopeItemGroup());
	            	stmt.setString(64,apps.getFrontendSoftwareComponent());
	            	stmt.setString(65,apps.getBackendSoftwareComponentVersions());
	            	stmt.setString(66,apps.getHanaSoftwareComponentVersions());
	            	stmt.setString(67,apps.getBexQueryName());
	            	stmt.setString(68,apps.getCombinedTitle());
	            	stmt.setString(69,apps.getScreenshotLinks());
	            	stmt.setString(70,apps.getBusinessRoleName());
	            	stmt.setString(71,apps.getBusinessRoleDescription());
	            	stmt.setString(72,apps.getLeadingBusinessRoleName());
	            	stmt.setString(73,apps.getLeadingBusinessRoleDescription());
	            	stmt.setString(74,apps.getLeadBRAdditionalLanguage());
	            	stmt.setString(75,apps.getLeadBRAdditional());
	            	stmt.setString(76,apps.getBrAdditionalLanguage());
	            	stmt.setString(77,apps.getBrAdditional());
	            	stmt.setString(78,apps.getBcAdditionalLanguage());
	            	stmt.setString(79,apps.getBcAdditional());
	            	stmt.setString(80,apps.getBgAdditionalLanguage());
	            	stmt.setString(81,apps.getBgAdditional());
	            	stmt.setString(82,apps.getCombinedTitleAdditionalLang());
	            	stmt.setString(83,apps.getTcAdditionalLanguage());
	            	stmt.setString(84,apps.getTcAdditional());
	            	stmt.setString(85,apps.getFrontendProductVersionStack());
	            	stmt.setString(86,apps.getFrontendActivatedInstance());
	            	stmt.setString(87,apps.getFrontendMinSP());
	            	stmt.setString(88,apps.getBackendProductVersionStack());
	            	stmt.setString(89,apps.getBackendActivatedInstance());
	            	stmt.setString(90,apps.getHanaProductVersionStack());
	            	stmt.setString(91,apps.getHanaActivatedInstance());

	               //Add statement to batch
	               stmt.addBatch();
	               counter++;
	               //Execute batch of 10000 records
	               if(counter%10000==0){
	                  stmt.executeBatch();
	                  conn.commit();
	                  
	                 
	                  logger.info("Fiori Batch updated  ::{}   ... executed successfully" ,batch );
	                  batch++;
	               }
	            }
	            //execute final batch
	            stmt.executeBatch();
	            conn.commit();
	           
	            logger.info("Final Batch executed successfully");
	         }
		      
	      }catch (Exception e) {
			logger.error("insertFioriRecords :: ",e);
		}
	      /*logger.info("Inside insertFioriRecords ");
			try {
			Session session = hibernateTemplate.getSessionFactory().openSession();	      
				
				session.beginTransaction();
				session.save(listOfAppsType);
				session.getTransaction().commit();
				session.flush();
				session.clear();
		        
		      }catch (Exception e) {
				logger.error("insertFioriLibraryRecords :: ",e);
			}*/

			
	}
	public void truncateMasterSheetTables(String environment) throws SQLException {

		logger.info("Inside truncateMasterSheetTables .....");

		try (Connection conn = DBConfigFiori.getJDBCConnection(environment);) {

			conn.setAutoCommit(false);
			try (Statement stmt = conn.createStatement();) {

				stmt.executeUpdate(OdataFiori_Constants.SQL_TRUNCATE_APPLIST_FIORI);

				conn.commit();
			}

		}catch (Exception e) {
			logger.error("truncateMasterSheetTables :: ",e);
		}
		logger.info("Fiori and Badi mastersheet tables truncated ::   ..  ");
	}
	
	public void truncateMasterSheetBackupTables(String environment) throws SQLException {

		logger.info("Inside truncateMasterSheetBackupTables .....");

		try (Connection conn = DBConfigFiori.getJDBCConnection(environment);) {

			conn.setAutoCommit(false);
			try (Statement stmt = conn.createStatement();) {

				stmt.executeUpdate(OdataFiori_Constants.SQL_TRUNCATE_APPLIST_FIORI_BACKUP);

				conn.commit();
			}

		}catch (Exception e) {
			logger.error("truncateMasterSheetTables :: ",e);
		}
		logger.info("Fiori and Badi mastersheet tables truncated ::   ..  ");
	}
	
	public void updateMasterSheetBackupTables(String environment) throws SQLException {

		logger.info("Inside truncateMasterSheetBackupTables .....");

		try (Connection conn = DBConfigFiori.getJDBCConnection(environment);) {

			conn.setAutoCommit(false);
			try (Statement stmt = conn.createStatement();) {

				stmt.executeUpdate(OdataFiori_Constants.SQL_UPDATE_APPLIST_FIORI_BACKUP);

				conn.commit();
			}

		}catch (Exception e) {
			logger.error("truncateMasterSheetTables :: ",e);
		}
		logger.info("Fiori and Badi mastersheet tables truncated ::   ..  ");
	}
	
	public void upadateProcessOnSucess(String environment) throws SQLException {
		logger.info("Inside upadateProcessOnSucess .....Start");
		try (Connection conn = DBConfigFiori.getJDBCConnection(environment);) {
			conn.setAutoCommit(false);
			try (PreparedStatement stmt = conn.prepareStatement(OdataFiori_Constants.Update_qry);) {
				stmt.setString(1, "Odata_Fiori");
				stmt.setTimestamp(2, new Timestamp(System.currentTimeMillis()));
				stmt.executeUpdate();
				conn.commit();
			}
			logger.info("Query :: "+OdataFiori_Constants.Update_qry);
		}catch (Exception e) {
			logger.error("upadateProcessOnSucess :: ",e);
		}
		logger.info("Inside upadateProcessOnSucess .....End");
	}
}
