package com.act.master;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "IRPATScope_Estimates")
public final class IRPATScopeEstimates {

	private long requestId;
	private int totalTestScriptsCount;
	private int impactedBusinessScenariosCount;
	private int addBusinessScenariosToTestCount;
	private int noTestStepsToTestCount;
	private int testScriptsForEstimationsCount;
	private int simpleCompForTestScriptCount;
	private int mediumCompForTestScriptCount;
	private int complexCompForTestScriptCount;
	private int manualScriptCreationCount;
	private int manualScriptModificationCount;
	private int scriptsForUnitTest;
	private int scriptsForSITOne;
	private int scriptsForSITTwo;
	private int scriptsForRegressionTest;
	private int scriptsForUAT;
	private int scriptsForSmokeTest;
	
	@Id
	@Column(name = "Request_ID")
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	
	@Column(name = "Total_TestScripts_Count")
	public int getTotalTestScriptsCount() {
		return totalTestScriptsCount;
	}
	public void setTotalTestScriptsCount(int totalTestScriptsCount) {
		this.totalTestScriptsCount = totalTestScriptsCount;
	}
	
	@Column(name = "ImpactedBusinessScenarios_Count")
	public int getImpactedBusinessScenariosCount() {
		return impactedBusinessScenariosCount;
	}
	public void setImpactedBusinessScenariosCount(int impactedBusinessScenariosCount) {
		this.impactedBusinessScenariosCount = impactedBusinessScenariosCount;
	}
	
	@Column(name = "AddBusinessScenariosToTest_Count")
	public int getAddBusinessScenariosToTestCount() {
		return addBusinessScenariosToTestCount;
	}
	public void setAddBusinessScenariosToTestCount(int addBusinessScenariosToTestCount) {
		this.addBusinessScenariosToTestCount = addBusinessScenariosToTestCount;
	}
	
	@Column(name = "NoTestStepsToTest_Count")
	public int getNoTestStepsToTestCount() {
		return noTestStepsToTestCount;
	}
	public void setNoTestStepsToTestCount(int noTestStepsToTestCount) {
		this.noTestStepsToTestCount = noTestStepsToTestCount;
	}
	
	@Column(name = "TestScriptsForEstimations_Count")
	public int getTestScriptsForEstimationsCount() {
		return testScriptsForEstimationsCount;
	}
	public void setTestScriptsForEstimationsCount(int testScriptsForEstimationsCount) {
		this.testScriptsForEstimationsCount = testScriptsForEstimationsCount;
	}
	
	@Column(name = "SimplCompForTestScript_Count")
	public int getSimpleCompForTestScriptCount() {
		return simpleCompForTestScriptCount;
	}
	public void setSimpleCompForTestScriptCount(int simpleCompForTestScriptCount) {
		this.simpleCompForTestScriptCount = simpleCompForTestScriptCount;
	}
	
	@Column(name = "getMediumCompForTestScript_Count")
	public int getMediumCompForTestScriptCount() {
		return mediumCompForTestScriptCount;
	}
	public void setMediumCompForTestScriptCount(int mediumCompForTestScriptCount) {
		this.mediumCompForTestScriptCount = mediumCompForTestScriptCount;
	}
	
	@Column(name = "ComplexCompForTestScript_Count")
	public int getComplexCompForTestScriptCount() {
		return complexCompForTestScriptCount;
	}
	public void setComplexCompForTestScriptCount(int complexCompForTestScriptCount) {
		this.complexCompForTestScriptCount = complexCompForTestScriptCount;
	}
	
	@Column(name = "ManualScriptCreation_Count")
	public int getManualScriptCreationCount() {
		return manualScriptCreationCount;
	}
	public void setManualScriptCreationCount(int manualScriptCreationCount) {
		this.manualScriptCreationCount = manualScriptCreationCount;
	}
	
	@Column(name = "ManualScriptModification_Count")
	public int getManualScriptModificationCount() {
		return manualScriptModificationCount;
	}
	public void setManualScriptModificationCount(int manualScriptModificationCount) {
		this.manualScriptModificationCount = manualScriptModificationCount;
	}
	
	@Column(name = "ScriptsForUnitTest_Count")
	public int getScriptsForUnitTest() {
		return scriptsForUnitTest;
	}
	public void setScriptsForUnitTest(int scriptsForUnitTest) {
		this.scriptsForUnitTest = scriptsForUnitTest;
	}
	
	@Column(name = "ScriptsForSIT_1_Count")
	public int getScriptsForSITOne() {
		return scriptsForSITOne;
	}
	public void setScriptsForSITOne(int scriptsForSITOne) {
		this.scriptsForSITOne = scriptsForSITOne;
	}
	
	@Column(name = "ScriptsForSIT_2_Count")
	public int getScriptsForSITTwo() {
		return scriptsForSITTwo;
	}
	public void setScriptsForSITTwo(int scriptsForSITTwo) {
		this.scriptsForSITTwo = scriptsForSITTwo;
	}
	
	@Column(name = "ScriptsForRegressionTest_Count")
	public int getScriptsForRegressionTest() {
		return scriptsForRegressionTest;
	}
	public void setScriptsForRegressionTest(int scriptsForRegressionTest) {
		this.scriptsForRegressionTest = scriptsForRegressionTest;
	}
	
	@Column(name = "ScriptsForUAT_Count")
	public int getScriptsForUAT() {
		return scriptsForUAT;
	}
	public void setScriptsForUAT(int scriptsForUAT) {
		this.scriptsForUAT = scriptsForUAT;
	}
	
	@Column(name = "ScriptsForSmokeTest_Count")
	public int getScriptsForSmokeTest() {
		return scriptsForSmokeTest;
	}
	public void setScriptsForSmokeTest(int scriptsForSmokeTest) {
		this.scriptsForSmokeTest = scriptsForSmokeTest;
	}
}
