package com.act.master;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Processed_RequestMaster")
public class ProcessedRequestMaster {
	// Request Form Fields 
	private int id;
	private long requestId;
	private String scope;
	private String clientName;
	private String indGrp;
	private String srcSystem;
	private String tarSystem;
	private String clientPOCEmail;
	private String projectPOCEmail;
	private String clientType;
	private String marketUnit;
	private String dbSize;
	private String indSubGrp;

	// HANA Counts Based on Remediation Category = 'Application Level Optimization',
	// Issue Sub Category and Issue Category
	private int distinctCodeMaintainHanaSpcKeepUnncecLoadAwayFromDB;
	private int errorCodeMaintainHanaSpcKeepUnncecLoadAwayFromDB;
	private int distinctPerfGenKeepResultSetSmall;
	private int errorPerfGenKeepResultSetSmall;
	private int distinctPerfGenKeepUnnecLoadAwayFromDB;
	private int errorPerfGenKeepUnnecLoadAwayFromDB;
	private int distinctPerfGenMinAmtTranData;
	private int errorPerfGenMinAmtTranData;
	private int distinctPerfGenSelectQueriesInGlobalRoutines;
	private int errorPerfGenSelectQueriesInGlobalRoutines;
	private int distinctPerfHanaSpcMinAmtTranData;
	private int errorPerfHanaSpcMinAmtTranData;
	private int distinctAppLoadOptimizeDB;
	private int errorAppLoadOptimizeDB;

	// HANA Counts Based on Remediation Category = "DB Level HANA Optimization" OR
	// Remediation Category = "Housekeeping For HANA" and Operation
	private int distinctAggrStatCollectCount;
	private int errorAggrStatCollectCount;
	private int distinctFAEAndJoinCount;
	private int errorFAEAndJoinCount;
	private int distinctForAllEntriesUsedCount;
	private int errorForAllEntriesUsedCount;
	private int distinctJoinsOnTablesInSelectStatCount;
	private int errorJoinsOnTablesInSelectStatCount;
	private int distinctRepeatDBHitsOnTableCount;
	private int errorRepeatDBHitsOnTableCount;
	private int distinctFMUsedForCurrConvCount;
	private int errorFMUsedForCurrConvCount;
	private int distinctByPassTableBufferCount;
	private int errorByPassTableBufferCount;
	private int distinctDBHintsUsedCount;
	private int errorDBHintsUsedCount;

	// HANA Counts - Based on Remediation Category and Automation Status
	private int distinctMandManualCount;
	private int errorMandManualCount;
	private int distinctMandAutomaticCount;
	private int errorMandAutomaticCount;
	private int distinctAppLevelAutomaticCount;
	private int errorAppLevelAutomaticCount;
	private int distinctDBLevelAutomaticCount;
	private int errorDBLevelAutomaticCount;
	private int distinctHANAHousekeepAutomaticCount;
	private int errorHANAHousekeepAutomaticCount;

	// HANA Counts - Based on Remediation Category = "Mandatory", Issue Category and
	// Operation
	private int distinctHanaSortChckExitLeaveStatWithLoop;
	private int errorHanaSortChckExitLeaveStatWithLoop;
	private int distinctHanaSortDelAdjDupWithoutSorting;
	private int errorHanaSortDelAdjDupWithoutSorting;
	private int distinctHanaSortReadStatWithBinaryAndWithoutSorting;;
	private int errorHanaSortReadStatWithBinaryAndWithoutSorting;
	private int distinctHanaSortSelectSingleWithoutKeyFields;
	private int errorHanaSortSelectSingleWithoutKeyFields;
	private int distinctHanaSortUnsortedIntTableAccessWithFM;
	private int errorHanaSortUnsortedIntTableAccessWithFM;
	private int distinctHanaSortUnsortedIntTableAccessWithIndex;
	private int errorHanaSortUnsortedIntTableAccessWithIndex;
	private int distinctSemErrorADBCUsage;
	private int errorSemErrorADBCUsage;
	private int distinctSemErrorNativeSQLCall;
	private int errorSemErrorNativeSQLCall;
	private int distinctSemErrorPollClusterTable;
	private int errorSemErrorPollClusterTable;
	private int distinctSemErrorDBOperationOnPollClusterTable;
	private int errorSemErrorDBOperationOnPollClusterTable;
	private int distinctHanaSortControlStmntInsideLoop;
	private int errorHanaSortControlStmntInsideLoop;
	private int distinctSemErrorDDICFuncModCall;
	private int errorSemErrorDDICFuncModCall;
	
	// S4 Counts - Based on SAP Simplification Category
	private int distinctSAPChangeOfExistingFunctionality;
	private int distinctSAPFunNotAvailFuncEquiAvail;
	private int distinctSAPFunNotAvailNoFuncEquiAvail;
	private int distinctSAPNonStrategicFuncEquiAvail;
	private int distinctSAPNonStrategicNoFuncEquiAvail;

	// Impacted Clone Counts
	private int distinctCloneObjCount;
	private int distinctCloneObjCountHANAS4;
	private int distinctUsedCloneObjCount;
	private int identicalSrcCodeCount;
	private int partialSimilarSrcCodeCount;
	private int similarSrcCodeCount;
	private int vrySimilarSrcCodeCount;
	private int distinctIdenticalSrcCodeCount;
	private int distinctPartialSimilarSrcCodeCount;
	private int distinctSimilarSrcCodeCount;
	private int distinctVrySimilarSrcCodeCount;
	private int distinctIdenticalSrcCodeUsedCount;
	private int distinctPartialSimilarSrcCodeUsedCount;
	private int distinctSimilarSrcCodeUsedCount;
	private int distinctVrySimilarSrcCodeUsedCount;

	// Smodilog Counts
	private int distinctStdModObjCount;
	private int errorStdModObjCount;
	private int errorSPDDObjCount;
	private int errorSPAUObjCount;
	private int distinctSmodDTELCount;
	private int distinctSmodDOMACount;
	private int distinctSmodTTYPCount;
	private int distinctSmodTOBJCount;
	private int distinctSmodTABLCount;
	private int distinctSmodCLASCount;
	private int distinctSmodPROGCount;
	private int distinctSmodFUGRCount;
	private int distinctSmodPARACount;
	private int distinctSmodSMIMCount;
	private int distinctSmodSXSDCount;
	private int distinctSmodVIEWCount;
	private int distinctSmodWAPACount;
	private int distinctSmodENHOCount;
	private int distinctSmodINTFCount;
	private int distinctSmodSHLPCount;
	private int distinctSmodSMODCount;
	private int distinctSmodSXCICount;
	private int distinctSmodFUGXCount;
	private int distinctSmodPDTSCount;
	private int distinctSmodLODECount;
	private int distinctSmodDEVCCount;
	private int distinctSmodTRANCount;
	private int distinctSmodENQUCount;
	private int distinctSmodMSAGCount;
	private int distinctSmodSPRXCount;
	private int distinctSmodPDWSCount;
	private int distinctSmodSSFOCount;
	private int distinctSmodSSSTCount;
	private int distinctSmodENHSCount;
	private int distinctSmodSFPICount;
	private int distinctSmodSFPFCount;
	private int distinctSmodPFCSCount;
	private int distinctSmodLOIECount;
	private int distinctSmodLODCCount;
	private int distinctSmodSOBJCount;
	private int distinctSmodSOTRCount;
	private int distinctSmodUSRRCount;
	private int distinctSmodUSRECount;
	private int distinctSmodENHCCount;
	private int distinctSmodLSMWCount;
	private int distinctSmodWDYNCount;
	private int distinctSmodIATUCount;
	private int distinctSmodXSLTCount;
	private int distinctSmodACGRCount;
	private int distinctSmodSCVICount;
	private int distinctSmodPHDECount;
	private int distinctSmodPOCSCount;
	private int distinctSmodFUGSCount;
	private int distinctSmodWEBICount;
	private int distinctSmodBOBFCount;
	private int distinctSmodSUSOCount;
	private int distinctSmodVCLSCount;
	private int distinctSmodINDXCount;
	private int distinctSmodREPTCount;
	private int distinctSmodDIALCount;
	private int distinctSmodSTVICount;
	private int distinctSmodAQSGCount;
	private int distinctSmodAQBGCount;
	private int distinctSmodAQQUCount;

	// AUCT Counts
	private int manPreCheckErrors;
	private int unicodeErrorCount;
	private int syntaxErrorCount;
	private int inactiveObjCount;

	// Fiori Counts
	private int totalFioriAppCount;
	private int customAppsCount;
	private int standardAppsCount;

	// S4 Optional Counts
	private int totalOptionalImpactedObjectCount;
	private int distinctOptionalImpactedObjCount;
	private int totalOptionalImpactedUsedObjCount;
	private int distinctOptionalImpactedUsedObjCount;

	// S4 Counts Based on Remediation Category and Complexity
	private int manHighObjCount;
	private int manMedObjCount;
	private int manLowObjCount;
	private int manTBDObjCount;
	private int manHighUsedObjCount;
	private int manMedUsedObjCount;
	private int manLowUsedObjCount;
	private int manTBDUsedObjCount;
	private int optLowObjCount;
	private int optVryLowObjCount;
	private int optMediumObjCount;
	private int optHighObjCount;
	private int optLowUsedObjCount;
	private int optVryLowUsedObjCount;
	private int optMedUsedObjCount;
	private int optHighUsedObjCount;
	
	// S4 - Impacted Standard Transaction
	private int totalStdTransactionsCount;

	// Impacted Object List Counts
	private int totalImpactedObjCount;
	private int totalImpactedUsedObjCount;
	private int totalImpPROG;
	private int totalImpUsedPROG;
	private int totalImpFUGR;
	private int totalImpUsedFUGR;
	private int totalImpCLAS;
	private int totalImpUsedCLAS;
	private int totalImpENHO;
	private int totalImpUsedENHO;
	private int totalImpENHC;
	private int totalImpUsedENHC;
	private int totalImpLSMW;
	private int totalImpUsedLSMW;
	private int totalImpFUGS;
	private int totalImpUsedFUGS;
	private int totalImpSSFO;
	private int totalImpUsedSSFO;
	private int totalImpDTEL;
	private int totalImpUsedDTEL;
	private int totalImpENHS;
	private int totalImpUsedENHS;
	private int totalImpWDYN;
	private int totalImpUsedWDYN;
	private int totalImpUSRE;
	private int totalImpUsedUSRE;
	private int totalImpUSRR;
	private int totalImpUsedUSRR;
	private int totalImpSFPI;
	private int totalImpUsedSFPI;
	private int totalImpREPT;
	private int totalImpUsedREPT;
	private int totalImpVIEW;
	private int totalImpUsedVIEW;
	private int totalImpINDX;
	private int totalImpUsedINDX;
	private int totalImpCDAT;
	private int totalImpUsedCDAT;
	private int totalImpTABU;
	private int totalImpUsedTABU;
	private int totalImpBWTR;
	private int totalImpUsedBWTR;
	private int totalImpBWTS;
	private int totalImpUsedBWTS;
	private int totalImpBWUR;
	private int totalImpUsedBWUR;
	private int totalImpBWIG;
	private int totalImpUsedBWIG;
	private int totalImpINDE;
	private int totalImpUsedINDE;
	private int totalImpAQQU;
	private int totalImpUsedAQQU;

	// Inventory List Counts
	private int totalInventoryObj;
	private int totalInventoryUsedObj;
	private int totalInventoryUnusedObj;
	private float totalInvenoryUsedObjPercentage;
	private float totalInvenoryUnusedObjPercentage;
	private int totalInvPROG;
	private int totalInvUsedPROG;
	private int totalInvFUGR;
	private int totalInvUsedFUGR;
	private int totalInvCLAS;
	private int totalInvUsedCLAS;
	private int totalInvENHO;
	private int totalInvUsedENHO;
	private int totalInvENHC;
	private int totalInvUsedENHC;
	private int totalInvLSMW;
	private int totalInvUsedLSMW;
	private int totalInvFUGS;
	private int totalInvUsedFUGS;
	private int totalInvSSFO;
	private int totalInvUsedSSFO;
	private int totalInvDTEL;
	private int totalInvUsedDTEL;
	private int totalInvENHS;
	private int totalInvUsedENHS;
	private int totalInvWDYN;
	private int totalInvUsedWDYN;
	private int totalInvUSRE;
	private int totalInvUsedUSRE;
	private int totalInvUSRR;
	private int totalInvUsedUSRR;
	private int totalInvSFPI;
	private int totalInvUsedSFPI;
	private int totalInvREPT;
	private int totalInvUsedREPT;
	private int totalInvVIEW;
	private int totalInvUsedVIEW;
	private int totalInvINDX;
	private int totalInvUsedINDX;
	private int totalInvCDAT;
	private int totalInvUsedCDAT;
	private int totalInvTABU;
	private int totalInvUsedTABU;
	private int totalInvBWTR;
	private int totalInvUsedBWTR;
	private int totalInvBWTS;
	private int totalInvUsedBWTS;
	private int totalInvBWUR;
	private int totalInvUsedBWUR;
	private int totalInvBWIG;
	private int totalInvUsedBWIG;
	private int totalInvINDE;
	private int totalInvUsedINDE;
	private int totalInvAQQU;
	private int totalInvUsedAQQU;

	// HANA Counts Based on Automation Status and Percentage Calculation
	private float manAutoYPercentage;
	private int totalAutoYImpUsedObjCount;
	private float manAutoYUsedPercentage;
	
	// HANA Counts Based on Automation Status
	private int distinctAutomaticCount;
	private int errorAutomaticCount;

	// HANA Counts Based on Remediation Category and Issue Category
	private int manHanSort;
	private int manSemError;
	private int usedManHanaSort;
	private int usedManSemError;
	private int appLevelOptKeepResultSetSmall;
	private int appLevelOptKeepUnnecLoadAwayFromDB;
	private int appLevelMinAmtOfTranData;
	private int appLevelSelectQueriesInGlobalRoutines;
	private int hanaLevelOptMinAmtOfTranData;
	private int hanaHousKeepUnnecLoadAwayFromDB;
	private int hanaHouseKeepStatIgnoreByHana;

	// HANA Counts Based on Remediation Category
	private int totalAppLevelOptImpObjCount;
	private int totalUsedAppLevelOptImpObjCount;
	private int distinctAppLevelOptImpObjCount;
	private int distinctUsedAppLevelOptImpObjCount;
	private int totalHanaLevelOptImpObjCount;
	private int totalUsedHanaLevelOptImpObjCount;
	private int distinctHanaLevelOptImpObjCount;
	private int distinctUsedHanaLevelOptImpObjCount;
	private int totalHanaHouseKeepImpObjCount;
	private int totalUsedHanaHouseKeepImpObjCount;
	private int distinctHanaHouseKeepImpObjCount;
	private int distinctUsedHanaHouseKeepImpObjCount;

	// HANA, S4 and OS Migration Common Counts - From BenchMarking Perspective
	private int totalCommonImpactedObjCountHanaAndS4AndOSMig;
	private int totalCommonImpactedUsedObjCountHanaAndS4AndOSMig;
	private int totalCommonManImpactedObjCountHanaAndS4AndOSMig;
	private int totalCommonManImpactedUsedObjCountHanaAndS4AndOSMig;
	private int distinctMandatoryImpactHanaS4OsMig;
	private int distinctMandatoryImpacUnusedHanaS4OsMig;
	private float manImpacUnusedPercHanaS4OsMigPerc;
	private int distinctImpactHanaS4OsMig;
	private int distinctImpactUsedHanaS4OsMig;
	private float manImpactHanaS4OsMigPerc;
	
	// HANA and S4 Common Counts - From PPT Perspective
	private int totalCommonImpactedObjCountHanaAndS4;
	private int totalCommonImpactedUsedObjCountHanaAndS4;
	private int totalCommonManImpactedObjCountHanaAndS4;
	private int totalCommonManImpactedUsedObjCountHanaAndS4;
	private int distinctMandatoryImpactHanaS4;
	private int distinctMandatoryImpacUnusedHanaS4;
	private float manImpacUnusedPercHanaS4Perc;
	private int distinctImpactHanaS4;
	private int distinctImpactUsedHanaS4;
	private float manImpactHanaS4Perc;
	
	// Counts Based on Scope - HANA, S4 and OS Migration
	private int distinctObjCount;
	private int distinctUsedObjCount;
	private int distinctManImpactedObjCount;
	private int distinctManImpactedUsedObjCount;
	private int totalErrorCount;
	private int totalManImpactedObjectCount;
	private int totalManImpactedUsedObjCount;
	
	// OS Migration Counts - File Path Impacted by OS Change & Logical Command Impacted by OS Change
	private int distinctLogFilePathCountOSMig;
	private int distinctLogCommandCountOSMig;
	
	// OS Migration Counts - Based on Remediation Category and Description
	private int distinctManImpactedObjCountCallSystemID;
	private int distinctManImpactedObjCountSXPGCommandExecute;
	private int totalManImpactedObjectCountCallSystemID;
	private int totalManImpactedObjectCountSXPGCommandExecute;
	private int distinctOptImpactedObjCountOpenDataset;
	private int totalOptImpactedObjCountOpenDataset;

	// Testing Scope Counts
	private int tscopeProcessCount;
	private int tscopeObjCount;
	
	// SIA Counts
	private int securityTotalRoles;
	private int totalRolesImpacted;
	private int secRoleNeedsModification;
	private int secRoleModFiori;
	private int secTcodeObsOrNoReplacement;
	private int secRoleNeedModCleanup;
	private int secSapNewTcodeVersions;
	private float secRoleNeedModPercentage;
	
	// Impacted Background Job Counts
	private int totalImpBackgrounJob;
	private int distinctImpProgramCount;
	
	// HANA and S4 Object Error Counts
	private int errorUsedCount;
	private int errorCLASCount;
	private int errorBWTRCount;
	private int errorBWTSCount;
	private int errorBWURCount;
	private int errorBWIGCount;
	private int errorCDATCount;
	private int errorTABUCount;
	private int errorPROGCount;
	private int errorSSFOCount;
	private int errorSFPFCount;
	private int errorSFPICount;
	private int errorFUGRCount;
	private int errorENHOCount;
	private int errorENHSCount;
	private int errorENHCCount;
	private int errorLSMWCount;
	private int errorUSRECount;
	private int errorUSRRCount;
	private int errorWDYNCount;
	private int errorREPTCount;
	private int errorVIEWCount;
	private int errorINDXCount;
	private int errorDTELCount;
	private int errorFUGSCount;
	private int errorAQQUCount;
	private int errorUsedCLASCount;
	private int errorUsedBWTRCount;
	private int errorUsedBWTSCount;
	private int errorUsedBWURCount;
	private int errorUsedBWIGCount;
	private int errorUsedCDATCount;
	private int errorUsedTABUCount;
	private int errorUsedPROGCount;
	private int errorUsedSSFOCount;
	private int errorUsedSFPFCount;
	private int errorUsedSFPICount;
	private int errorUsedFUGRCount;
	private int errorUsedENHOCount;
	private int errorUsedENHSCount;
	private int errorUsedENHCCount;
	private int errorUsedLSMWCount;
	private int errorUsedUSRECount;
	private int errorUsedUSRRCount;
	private int errorUsedWDYNCount;
	private int errorUsedREPTCount;
	private int errorUsedVIEWCount;
	private int errorUsedINDXCount;
	private int errorUsedDTELCount;
	private int errorUsedFUGSCount;
	private int errorUsedAQQUCount;
	
	// S4 - Distinct Counts Based on Remediation Category and Issue Category
	private int distinctManIssueCatCustomCodeAdaption;
	private int distinctManIssueCatDataEleLenExt;
	private int distinctManIssueCatNewDataModel;
	private int distinctManIssueCatNewS4Func;
	private int distinctManIssueCatRemOfOrpObjects;
	private int distinctManIssueCatRetFunc;
	private int distinctManIssueCatEliminateOFStatusTables;
	private int distinctManIssueCatReplaceNewFunc;
	private int distinctManIssueCatNewTransaction;
	private int distinctOptIssueCatCustomCodeAdaption;
	private int distinctOptIssueCatDataEleLenExt;
	private int distinctOptIssueCatNewDataModel;
	private int distinctOptIssueCatNewS4Func;
	private int distinctOptIssueCatRemOfOrpObjects;
	private int distinctOptIssueCatRetFunc;
	private int distinctOptIssueCatEliminateOFStatusTables;
	private int distinctOptIssueCatReplaceNewFunc;
	private int distinctOptIssueCatNewTransaction;
	
	// S4 - Error Counts Based on Remediation Category and Issue Category
	private int errorManIssueCatCustomCodeAdaption;
	private int errorManIssueCatDataEleLenExt;
	private int errorManIssueCatNewDataModel;
	private int errorManIssueCatNewS4Func;
	private int errorManIssueCatRemOfOrpObjects;
	private int errorManIssueCatRetFunc;
	private int errorManIssueCatEliminateOFStatusTables;
	private int errorManIssueCatReplaceNewFunc;
	private int errorManIssueCatNewTransaction;
	private int errorOptIssueCatCustomCodeAdaption;
	private int errorOptIssueCatDataEleLenExt;
	private int errorOptIssueCatNewDataModel;
	private int errorOptIssueCatNewS4Func;
	private int errorOptIssueCatRemOfOrpObjects;
	private int errorOptIssueCatRetFunc;
	private int errorOptIssueCatEliminateOFStatusTables;
	private int errorOptIssueCatReplaceNewFunc;
	private int errorOptIssueCatNewTransaction;
	
	// S4 - Distinct Counts Based on Issue Category
	private int distinctIssueCatCustomCodeAdaption;
	private int distinctIssueCatDataEleLenExt;
	private int distinctIssueCatNewDataModel;
	private int distinctIssueCatNewS4Func;
	private int distinctIssueCatRemOfOrpObjects;
	private int distinctIssueCatRetFunc;
	private int distinctIssueCatEliminateOFStatusTables;
	private int distinctIssueCatReplaceNewFunc;
	private int distinctIssueCatNewTransaction;

	// S4 - Distinct Used Counts Based on Issue Category
	private int distinctUsedIssueCatCustomCodeAdaption;
	private int distinctUsedIssueCatDataEleLenExt;
	private int distinctUsedIssueCatNewDataModel;
	private int distinctUsedIssueCatNewS4Func;
	private int distinctUsedIssueCatRemOfOrpObjects;
	private int distinctUsedIssueCatRetFunc;
	private int distinctUsedIssueCatEliminateOFStatusTables;
	private int distinctUsedIssueCatReplaceNewFunc;
	private int distinctUsedIssueCatNewTransaction;
	
	// S4 - Error Counts Based on Issue Category
	private int errorIssueCatCustomCodeAdaption;
	private int errorIssueCatDataEleLenExt;
	private int errorIssueCatNewDataModel;
	private int errorIssueCatNewS4Func;
	private int errorIssueCatRemOfOrpObjects;
	private int errorIssueCatRetFunc;
	private int errorIssueCatEliminateOFStatusTables;
	private int errorIssueCatReplaceNewFunc;
	private int errorIssueCatNewTransaction;

	// S4 - Error Used Counts Based on Issue Category
	private int errorUsedIssueCatCustomCodeAdaption;
	private int errorUsedIssueCatDataEleLenExt;
	private int errorUsedIssueCatNewDataModel;
	private int errorUsedIssueCatNewS4Func;
	private int errorUsedIssueCatRemOfOrpObjects;
	private int errorUsedIssueCatRetFunc;
	private int errorUsedIssueCatEliminateOFStatusTables;
	private int errorUsedIssueCatReplaceNewFunc;
	private int errorUsedIssueCatNewTransaction;
	
	// External Namespaces Counts - Inventory List
	private int distinctExtNamespaceInvCount;
	private int distinctExtNamespaceInvUsedCount;
	private float distinctExtNamespaceInvUsedPerc;

	// External Namespaces Counts - HANA/S4
	private int distinctExtNamespaceImpObjCount;
	private int distinctExtNamespaceUsedImpObjCount;
	private int distinctExtNamespaceMandCount;
	private int distinctExtNamespaceMandUsedCount;
	
	// External Namespaces Counts - Common HANA and S4
	private int distinctExtNamespaceCommonImpObjCountHANAS4;
	private int distinctExtNamespaceCommonUsedImpObjCountHANAS4;
	private int distinctExtNamespaceCommonMandCountHANAS4;
	private int distinctExtNamespaceCommonMandUsedCountHANAS4;
	
	// External Namespaces Counts - AUCT
	private int errorExtNamespacePreCheckErrorCount;
	private int errorExtNamespaceUnicodeErrorCount;
	private int errorExtNamespaceSyntaxErrorCount;
		
	// Request Form Fields 
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public long getRequestId() {
		return requestId;
	}

	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	
	public String getScope() {
		return scope;
	}

	public void setScope(String scope) {
		this.scope = scope;
	}
	
	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getIndGrp() {
		return indGrp;
	}

	public void setIndGrp(String indGrp) {
		this.indGrp = indGrp;
	}

	public String getSrcSystem() {
		return srcSystem;
	}

	public void setSrcSystem(String srcSystem) {
		this.srcSystem = srcSystem;
	}

	public String getTarSystem() {
		return tarSystem;
	}

	public void setTarSystem(String tarSystem) {
		this.tarSystem = tarSystem;
	}

	public String getClientPOCEmail() {
		return clientPOCEmail;
	}

	public void setClientPOCEmail(String clientPOCEmail) {
		this.clientPOCEmail = clientPOCEmail;
	}

	public String getProjectPOCEmail() {
		return projectPOCEmail;
	}

	public void setProjectPOCEmail(String projectPOCEmail) {
		this.projectPOCEmail = projectPOCEmail;
	}

	public String getClientType() {
		return clientType;
	}

	public void setClientType(String clientType) {
		this.clientType = clientType;
	}

	public String getMarketUnit() {
		return marketUnit;
	}

	public void setMarketUnit(String marketUnit) {
		this.marketUnit = marketUnit;
	}

	public String getDbSize() {
		return dbSize;
	}

	public void setDbSize(String dbSize) {
		this.dbSize = dbSize;
	}
	
	public String getIndSubGrp() {
		return indSubGrp;
	}

	public void setIndSubGrp(String indSubGrp) {
		this.indSubGrp = indSubGrp;
	}

	// HANA Counts Based on Remediation Category = 'Application Level Optimization',
	// Issue Sub Category and Issue Category
	public int getDistinctCodeMaintainHanaSpcKeepUnncecLoadAwayFromDB() {
		return distinctCodeMaintainHanaSpcKeepUnncecLoadAwayFromDB;
	}

	public void setDistinctCodeMaintainHanaSpcKeepUnncecLoadAwayFromDB(
			int distinctCodeMaintainHanaSpcKeepUnncecLoadAwayFromDB) {
		this.distinctCodeMaintainHanaSpcKeepUnncecLoadAwayFromDB = distinctCodeMaintainHanaSpcKeepUnncecLoadAwayFromDB;
	}

	public int getErrorCodeMaintainHanaSpcKeepUnncecLoadAwayFromDB() {
		return errorCodeMaintainHanaSpcKeepUnncecLoadAwayFromDB;
	}

	public void setErrorCodeMaintainHanaSpcKeepUnncecLoadAwayFromDB(
			int errorCodeMaintainHanaSpcKeepUnncecLoadAwayFromDB) {
		this.errorCodeMaintainHanaSpcKeepUnncecLoadAwayFromDB = errorCodeMaintainHanaSpcKeepUnncecLoadAwayFromDB;
	}

	public int getDistinctPerfGenKeepResultSetSmall() {
		return distinctPerfGenKeepResultSetSmall;
	}

	public void setDistinctPerfGenKeepResultSetSmall(int distinctPerfGenKeepResultSetSmall) {
		this.distinctPerfGenKeepResultSetSmall = distinctPerfGenKeepResultSetSmall;
	}

	public int getErrorPerfGenKeepResultSetSmall() {
		return errorPerfGenKeepResultSetSmall;
	}

	public void setErrorPerfGenKeepResultSetSmall(int errorPerfGenKeepResultSetSmall) {
		this.errorPerfGenKeepResultSetSmall = errorPerfGenKeepResultSetSmall;
	}

	public int getDistinctPerfGenKeepUnnecLoadAwayFromDB() {
		return distinctPerfGenKeepUnnecLoadAwayFromDB;
	}

	public void setDistinctPerfGenKeepUnnecLoadAwayFromDB(int distinctPerfGenKeepUnnecLoadAwayFromDB) {
		this.distinctPerfGenKeepUnnecLoadAwayFromDB = distinctPerfGenKeepUnnecLoadAwayFromDB;
	}

	public int getErrorPerfGenKeepUnnecLoadAwayFromDB() {
		return errorPerfGenKeepUnnecLoadAwayFromDB;
	}

	public void setErrorPerfGenKeepUnnecLoadAwayFromDB(int errorPerfGenKeepUnnecLoadAwayFromDB) {
		this.errorPerfGenKeepUnnecLoadAwayFromDB = errorPerfGenKeepUnnecLoadAwayFromDB;
	}

	public int getDistinctPerfGenMinAmtTranData() {
		return distinctPerfGenMinAmtTranData;
	}

	public void setDistinctPerfGenMinAmtTranData(int distinctPerfGenMinAmtTranData) {
		this.distinctPerfGenMinAmtTranData = distinctPerfGenMinAmtTranData;
	}

	public int getErrorPerfGenMinAmtTranData() {
		return errorPerfGenMinAmtTranData;
	}

	public void setErrorPerfGenMinAmtTranData(int errorPerfGenMinAmtTranData) {
		this.errorPerfGenMinAmtTranData = errorPerfGenMinAmtTranData;
	}
	
	public int getDistinctPerfGenSelectQueriesInGlobalRoutines() {
		return distinctPerfGenSelectQueriesInGlobalRoutines;
	}

	public void setDistinctPerfGenSelectQueriesInGlobalRoutines(int distinctPerfGenSelectQueriesInGlobalRoutines) {
		this.distinctPerfGenSelectQueriesInGlobalRoutines = distinctPerfGenSelectQueriesInGlobalRoutines;
	}

	public int getErrorPerfGenSelectQueriesInGlobalRoutines() {
		return errorPerfGenSelectQueriesInGlobalRoutines;
	}

	public void setErrorPerfGenSelectQueriesInGlobalRoutines(int errorPerfGenSelectQueriesInGlobalRoutines) {
		this.errorPerfGenSelectQueriesInGlobalRoutines = errorPerfGenSelectQueriesInGlobalRoutines;
	}

	public int getDistinctPerfHanaSpcMinAmtTranData() {
		return distinctPerfHanaSpcMinAmtTranData;
	}

	public void setDistinctPerfHanaSpcMinAmtTranData(int distinctPerfHanaSpcMinAmtTranData) {
		this.distinctPerfHanaSpcMinAmtTranData = distinctPerfHanaSpcMinAmtTranData;
	}

	public int getErrorPerfHanaSpcMinAmtTranData() {
		return errorPerfHanaSpcMinAmtTranData;
	}

	public void setErrorPerfHanaSpcMinAmtTranData(int errorPerfHanaSpcMinAmtTranData) {
		this.errorPerfHanaSpcMinAmtTranData = errorPerfHanaSpcMinAmtTranData;
	}

	public int getDistinctAppLoadOptimizeDB() {
		return distinctAppLoadOptimizeDB;
	}

	public void setDistinctAppLoadOptimizeDB(int distinctAppLoadOptimizeDB) {
		this.distinctAppLoadOptimizeDB = distinctAppLoadOptimizeDB;
	}

	public int getErrorAppLoadOptimizeDB() {
		return errorAppLoadOptimizeDB;
	}

	public void setErrorAppLoadOptimizeDB(int errorAppLoadOptimizeDB) {
		this.errorAppLoadOptimizeDB = errorAppLoadOptimizeDB;
	}

	// HANA Counts Based on Remediation Category = "DB Level HANA Optimization" OR
	// Remediation Category = "Housekeeping For HANA" and Operation
	public int getDistinctAggrStatCollectCount() {
		return distinctAggrStatCollectCount;
	}

	public void setDistinctAggrStatCollectCount(int distinctAggrStatCollectCount) {
		this.distinctAggrStatCollectCount = distinctAggrStatCollectCount;
	}

	public int getErrorAggrStatCollectCount() {
		return errorAggrStatCollectCount;
	}

	public void setErrorAggrStatCollectCount(int errorAggrStatCollectCount) {
		this.errorAggrStatCollectCount = errorAggrStatCollectCount;
	}

	public int getDistinctFAEAndJoinCount() {
		return distinctFAEAndJoinCount;
	}

	public void setDistinctFAEAndJoinCount(int distinctFAEAndJoinCount) {
		this.distinctFAEAndJoinCount = distinctFAEAndJoinCount;
	}

	public int getErrorFAEAndJoinCount() {
		return errorFAEAndJoinCount;
	}

	public void setErrorFAEAndJoinCount(int errorFAEAndJoinCount) {
		this.errorFAEAndJoinCount = errorFAEAndJoinCount;
	}

	public int getDistinctForAllEntriesUsedCount() {
		return distinctForAllEntriesUsedCount;
	}

	public void setDistinctForAllEntriesUsedCount(int distinctForAllEntriesUsedCount) {
		this.distinctForAllEntriesUsedCount = distinctForAllEntriesUsedCount;
	}

	public int getErrorForAllEntriesUsedCount() {
		return errorForAllEntriesUsedCount;
	}

	public void setErrorForAllEntriesUsedCount(int errorForAllEntriesUsedCount) {
		this.errorForAllEntriesUsedCount = errorForAllEntriesUsedCount;
	}

	public int getDistinctJoinsOnTablesInSelectStatCount() {
		return distinctJoinsOnTablesInSelectStatCount;
	}

	public void setDistinctJoinsOnTablesInSelectStatCount(int distinctJoinsOnTablesInSelectStatCount) {
		this.distinctJoinsOnTablesInSelectStatCount = distinctJoinsOnTablesInSelectStatCount;
	}

	public int getErrorJoinsOnTablesInSelectStatCount() {
		return errorJoinsOnTablesInSelectStatCount;
	}

	public void setErrorJoinsOnTablesInSelectStatCount(int errorJoinsOnTablesInSelectStatCount) {
		this.errorJoinsOnTablesInSelectStatCount = errorJoinsOnTablesInSelectStatCount;
	}

	public int getDistinctRepeatDBHitsOnTableCount() {
		return distinctRepeatDBHitsOnTableCount;
	}

	public void setDistinctRepeatDBHitsOnTableCount(int distinctRepeatDBHitsOnTableCount) {
		this.distinctRepeatDBHitsOnTableCount = distinctRepeatDBHitsOnTableCount;
	}

	public int getErrorRepeatDBHitsOnTableCount() {
		return errorRepeatDBHitsOnTableCount;
	}

	public void setErrorRepeatDBHitsOnTableCount(int errorRepeatDBHitsOnTableCount) {
		this.errorRepeatDBHitsOnTableCount = errorRepeatDBHitsOnTableCount;
	}

	public int getDistinctFMUsedForCurrConvCount() {
		return distinctFMUsedForCurrConvCount;
	}

	public void setDistinctFMUsedForCurrConvCount(int distinctFMUsedForCurrConvCount) {
		this.distinctFMUsedForCurrConvCount = distinctFMUsedForCurrConvCount;
	}

	public int getErrorFMUsedForCurrConvCount() {
		return errorFMUsedForCurrConvCount;
	}

	public void setErrorFMUsedForCurrConvCount(int errorFMUsedForCurrConvCount) {
		this.errorFMUsedForCurrConvCount = errorFMUsedForCurrConvCount;
	}

	public int getDistinctByPassTableBufferCount() {
		return distinctByPassTableBufferCount;
	}

	public void setDistinctByPassTableBufferCount(int distinctByPassTableBufferCount) {
		this.distinctByPassTableBufferCount = distinctByPassTableBufferCount;
	}

	public int getErrorByPassTableBufferCount() {
		return errorByPassTableBufferCount;
	}

	public void setErrorByPassTableBufferCount(int errorByPassTableBufferCount) {
		this.errorByPassTableBufferCount = errorByPassTableBufferCount;
	}

	public int getDistinctDBHintsUsedCount() {
		return distinctDBHintsUsedCount;
	}

	public void setDistinctDBHintsUsedCount(int distinctDBHintsUsedCount) {
		this.distinctDBHintsUsedCount = distinctDBHintsUsedCount;
	}

	public int getErrorDBHintsUsedCount() {
		return errorDBHintsUsedCount;
	}

	public void setErrorDBHintsUsedCount(int errorDBHintsUsedCount) {
		this.errorDBHintsUsedCount = errorDBHintsUsedCount;
	}

	// HANA Counts - Based on Remediation Category and Automation Status
	public int getDistinctMandManualCount() {
		return distinctMandManualCount;
	}

	public void setDistinctMandManualCount(int distinctMandManualCount) {
		this.distinctMandManualCount = distinctMandManualCount;
	}

	public int getErrorMandManualCount() {
		return errorMandManualCount;
	}

	public void setErrorMandManualCount(int errorMandManualCount) {
		this.errorMandManualCount = errorMandManualCount;
	}

	public int getDistinctMandAutomaticCount() {
		return distinctMandAutomaticCount;
	}

	public void setDistinctMandAutomaticCount(int distinctMandAutomaticCount) {
		this.distinctMandAutomaticCount = distinctMandAutomaticCount;
	}

	public int getErrorMandAutomaticCount() {
		return errorMandAutomaticCount;
	}

	public void setErrorMandAutomaticCount(int errorMandAutomaticCount) {
		this.errorMandAutomaticCount = errorMandAutomaticCount;
	}

	public int getDistinctAppLevelAutomaticCount() {
		return distinctAppLevelAutomaticCount;
	}

	public void setDistinctAppLevelAutomaticCount(int distinctAppLevelAutomaticCount) {
		this.distinctAppLevelAutomaticCount = distinctAppLevelAutomaticCount;
	}

	public int getErrorAppLevelAutomaticCount() {
		return errorAppLevelAutomaticCount;
	}

	public void setErrorAppLevelAutomaticCount(int errorAppLevelAutomaticCount) {
		this.errorAppLevelAutomaticCount = errorAppLevelAutomaticCount;
	}

	public int getDistinctDBLevelAutomaticCount() {
		return distinctDBLevelAutomaticCount;
	}

	public void setDistinctDBLevelAutomaticCount(int distinctDBLevelAutomaticCount) {
		this.distinctDBLevelAutomaticCount = distinctDBLevelAutomaticCount;
	}

	public int getErrorDBLevelAutomaticCount() {
		return errorDBLevelAutomaticCount;
	}

	public void setErrorDBLevelAutomaticCount(int errorDBLevelAutomaticCount) {
		this.errorDBLevelAutomaticCount = errorDBLevelAutomaticCount;
	}

	public int getDistinctHANAHousekeepAutomaticCount() {
		return distinctHANAHousekeepAutomaticCount;
	}

	public void setDistinctHANAHousekeepAutomaticCount(int distinctHANAHousekeepAutomaticCount) {
		this.distinctHANAHousekeepAutomaticCount = distinctHANAHousekeepAutomaticCount;
	}

	public int getErrorHANAHousekeepAutomaticCount() {
		return errorHANAHousekeepAutomaticCount;
	}

	public void setErrorHANAHousekeepAutomaticCount(int errorHANAHousekeepAutomaticCount) {
		this.errorHANAHousekeepAutomaticCount = errorHANAHousekeepAutomaticCount;
	}

	// HANA Counts - Based on Remediation Category = "Mandatory", Issue Category and Operation
	public int getDistinctHanaSortChckExitLeaveStatWithLoop() {
		return distinctHanaSortChckExitLeaveStatWithLoop;
	}

	public void setDistinctHanaSortChckExitLeaveStatWithLoop(int distinctHanaSortChckExitLeaveStatWithLoop) {
		this.distinctHanaSortChckExitLeaveStatWithLoop = distinctHanaSortChckExitLeaveStatWithLoop;
	}

	public int getErrorHanaSortChckExitLeaveStatWithLoop() {
		return errorHanaSortChckExitLeaveStatWithLoop;
	}

	public void setErrorHanaSortChckExitLeaveStatWithLoop(int errorHanaSortChckExitLeaveStatWithLoop) {
		this.errorHanaSortChckExitLeaveStatWithLoop = errorHanaSortChckExitLeaveStatWithLoop;
	}

	public int getDistinctHanaSortDelAdjDupWithoutSorting() {
		return distinctHanaSortDelAdjDupWithoutSorting;
	}

	public void setDistinctHanaSortDelAdjDupWithoutSorting(int distinctHanaSortDelAdjDupWithoutSorting) {
		this.distinctHanaSortDelAdjDupWithoutSorting = distinctHanaSortDelAdjDupWithoutSorting;
	}

	public int getErrorHanaSortDelAdjDupWithoutSorting() {
		return errorHanaSortDelAdjDupWithoutSorting;
	}

	public void setErrorHanaSortDelAdjDupWithoutSorting(int errorHanaSortDelAdjDupWithoutSorting) {
		this.errorHanaSortDelAdjDupWithoutSorting = errorHanaSortDelAdjDupWithoutSorting;
	}

	public int getDistinctHanaSortReadStatWithBinaryAndWithoutSorting() {
		return distinctHanaSortReadStatWithBinaryAndWithoutSorting;
	}

	public void setDistinctHanaSortReadStatWithBinaryAndWithoutSorting(
			int distinctHanaSortReadStatWithBinaryAndWithoutSorting) {
		this.distinctHanaSortReadStatWithBinaryAndWithoutSorting = distinctHanaSortReadStatWithBinaryAndWithoutSorting;
	}

	public int getErrorHanaSortReadStatWithBinaryAndWithoutSorting() {
		return errorHanaSortReadStatWithBinaryAndWithoutSorting;
	}

	public void setErrorHanaSortReadStatWithBinaryAndWithoutSorting(
			int errorHanaSortReadStatWithBinaryAndWithoutSorting) {
		this.errorHanaSortReadStatWithBinaryAndWithoutSorting = errorHanaSortReadStatWithBinaryAndWithoutSorting;
	}

	public int getDistinctHanaSortSelectSingleWithoutKeyFields() {
		return distinctHanaSortSelectSingleWithoutKeyFields;
	}

	public void setDistinctHanaSortSelectSingleWithoutKeyFields(int distinctHanaSortSelectSingleWithoutKeyFields) {
		this.distinctHanaSortSelectSingleWithoutKeyFields = distinctHanaSortSelectSingleWithoutKeyFields;
	}

	public int getErrorHanaSortSelectSingleWithoutKeyFields() {
		return errorHanaSortSelectSingleWithoutKeyFields;
	}

	public void setErrorHanaSortSelectSingleWithoutKeyFields(int errorHanaSortSelectSingleWithoutKeyFields) {
		this.errorHanaSortSelectSingleWithoutKeyFields = errorHanaSortSelectSingleWithoutKeyFields;
	}

	public int getDistinctHanaSortUnsortedIntTableAccessWithFM() {
		return distinctHanaSortUnsortedIntTableAccessWithFM;
	}

	public void setDistinctHanaSortUnsortedIntTableAccessWithFM(int distinctHanaSortUnsortedIntTableAccessWithFM) {
		this.distinctHanaSortUnsortedIntTableAccessWithFM = distinctHanaSortUnsortedIntTableAccessWithFM;
	}

	public int getErrorHanaSortUnsortedIntTableAccessWithFM() {
		return errorHanaSortUnsortedIntTableAccessWithFM;
	}

	public void setErrorHanaSortUnsortedIntTableAccessWithFM(int errorHanaSortUnsortedIntTableAccessWithFM) {
		this.errorHanaSortUnsortedIntTableAccessWithFM = errorHanaSortUnsortedIntTableAccessWithFM;
	}

	public int getDistinctHanaSortUnsortedIntTableAccessWithIndex() {
		return distinctHanaSortUnsortedIntTableAccessWithIndex;
	}

	public void setDistinctHanaSortUnsortedIntTableAccessWithIndex(
			int distinctHanaSortUnsortedIntTableAccessWithIndex) {
		this.distinctHanaSortUnsortedIntTableAccessWithIndex = distinctHanaSortUnsortedIntTableAccessWithIndex;
	}

	public int getErrorHanaSortUnsortedIntTableAccessWithIndex() {
		return errorHanaSortUnsortedIntTableAccessWithIndex;
	}

	public void setErrorHanaSortUnsortedIntTableAccessWithIndex(int errorHanaSortUnsortedIntTableAccessWithIndex) {
		this.errorHanaSortUnsortedIntTableAccessWithIndex = errorHanaSortUnsortedIntTableAccessWithIndex;
	}

	public int getDistinctSemErrorADBCUsage() {
		return distinctSemErrorADBCUsage;
	}

	public void setDistinctSemErrorADBCUsage(int distinctSemErrorADBCUsage) {
		this.distinctSemErrorADBCUsage = distinctSemErrorADBCUsage;
	}

	public int getErrorSemErrorADBCUsage() {
		return errorSemErrorADBCUsage;
	}

	public void setErrorSemErrorADBCUsage(int errorSemErrorADBCUsage) {
		this.errorSemErrorADBCUsage = errorSemErrorADBCUsage;
	}

	public int getDistinctSemErrorNativeSQLCall() {
		return distinctSemErrorNativeSQLCall;
	}

	public void setDistinctSemErrorNativeSQLCall(int distinctSemErrorNativeSQLCall) {
		this.distinctSemErrorNativeSQLCall = distinctSemErrorNativeSQLCall;
	}

	public int getErrorSemErrorNativeSQLCall() {
		return errorSemErrorNativeSQLCall;
	}

	public void setErrorSemErrorNativeSQLCall(int errorSemErrorNativeSQLCall) {
		this.errorSemErrorNativeSQLCall = errorSemErrorNativeSQLCall;
	}

	public int getDistinctSemErrorPollClusterTable() {
		return distinctSemErrorPollClusterTable;
	}

	public void setDistinctSemErrorPollClusterTable(int distinctSemErrorPollClusterTable) {
		this.distinctSemErrorPollClusterTable = distinctSemErrorPollClusterTable;
	}

	public int getErrorSemErrorPollClusterTable() {
		return errorSemErrorPollClusterTable;
	}

	public void setErrorSemErrorPollClusterTable(int errorSemErrorPollClusterTable) {
		this.errorSemErrorPollClusterTable = errorSemErrorPollClusterTable;
	}

	public int getDistinctSemErrorDBOperationOnPollClusterTable() {
		return distinctSemErrorDBOperationOnPollClusterTable;
	}

	public void setDistinctSemErrorDBOperationOnPollClusterTable(int distinctSemErrorDBOperationOnPollClusterTable) {
		this.distinctSemErrorDBOperationOnPollClusterTable = distinctSemErrorDBOperationOnPollClusterTable;
	}

	public int getErrorSemErrorDBOperationOnPollClusterTable() {
		return errorSemErrorDBOperationOnPollClusterTable;
	}

	public void setErrorSemErrorDBOperationOnPollClusterTable(int errorSemErrorDBOperationOnPollClusterTable) {
		this.errorSemErrorDBOperationOnPollClusterTable = errorSemErrorDBOperationOnPollClusterTable;
	}

	public int getDistinctHanaSortControlStmntInsideLoop() {
		return distinctHanaSortControlStmntInsideLoop;
	}

	public void setDistinctHanaSortControlStmntInsideLoop(int distinctHanaSortControlStmntInsideLoop) {
		this.distinctHanaSortControlStmntInsideLoop = distinctHanaSortControlStmntInsideLoop;
	}

	public int getErrorHanaSortControlStmntInsideLoop() {
		return errorHanaSortControlStmntInsideLoop;
	}

	public void setErrorHanaSortControlStmntInsideLoop(int errorHanaSortControlStmntInsideLoop) {
		this.errorHanaSortControlStmntInsideLoop = errorHanaSortControlStmntInsideLoop;
	}
	
	public int getDistinctSemErrorDDICFuncModCall() {
		return distinctSemErrorDDICFuncModCall;
	}

	public void setDistinctSemErrorDDICFuncModCall(int distinctSemErrorDDICFuncModCall) {
		this.distinctSemErrorDDICFuncModCall = distinctSemErrorDDICFuncModCall;
	}

	public int getErrorSemErrorDDICFuncModCall() {
		return errorSemErrorDDICFuncModCall;
	}

	public void setErrorSemErrorDDICFuncModCall(int errorSemErrorDDICFuncModCall) {
		this.errorSemErrorDDICFuncModCall = errorSemErrorDDICFuncModCall;
	}

	// S4 Counts - Based on SAP Simplification Category
	public int getDistinctSAPChangeOfExistingFunctionality() {
		return distinctSAPChangeOfExistingFunctionality;
	}

	public void setDistinctSAPChangeOfExistingFunctionality(int distinctSAPChangeOfExistingFunctionality) {
		this.distinctSAPChangeOfExistingFunctionality = distinctSAPChangeOfExistingFunctionality;
	}

	public int getDistinctSAPFunNotAvailFuncEquiAvail() {
		return distinctSAPFunNotAvailFuncEquiAvail;
	}

	public void setDistinctSAPFunNotAvailFuncEquiAvail(int distinctSAPFunNotAvailFuncEquiAvail) {
		this.distinctSAPFunNotAvailFuncEquiAvail = distinctSAPFunNotAvailFuncEquiAvail;
	}

	public int getDistinctSAPFunNotAvailNoFuncEquiAvail() {
		return distinctSAPFunNotAvailNoFuncEquiAvail;
	}

	public void setDistinctSAPFunNotAvailNoFuncEquiAvail(int distinctSAPFunNotAvailNoFuncEquiAvail) {
		this.distinctSAPFunNotAvailNoFuncEquiAvail = distinctSAPFunNotAvailNoFuncEquiAvail;
	}

	public int getDistinctSAPNonStrategicFuncEquiAvail() {
		return distinctSAPNonStrategicFuncEquiAvail;
	}

	public void setDistinctSAPNonStrategicFuncEquiAvail(int distinctSAPNonStrategicFuncEquiAvail) {
		this.distinctSAPNonStrategicFuncEquiAvail = distinctSAPNonStrategicFuncEquiAvail;
	}

	public int getDistinctSAPNonStrategicNoFuncEquiAvail() {
		return distinctSAPNonStrategicNoFuncEquiAvail;
	}

	public void setDistinctSAPNonStrategicNoFuncEquiAvail(int distinctSAPNonStrategicNoFuncEquiAvail) {
		this.distinctSAPNonStrategicNoFuncEquiAvail = distinctSAPNonStrategicNoFuncEquiAvail;
	}

	// Impacted Clone Counts
	public int getDistinctCloneObjCount() {
		return distinctCloneObjCount;
	}

	public void setDistinctCloneObjCount(int distinctCloneObjCount) {
		this.distinctCloneObjCount = distinctCloneObjCount;
	}

	public int getDistinctCloneObjCountHANAS4() {
		return distinctCloneObjCountHANAS4;
	}

	public void setDistinctCloneObjCountHANAS4(int distinctCloneObjCountHANAS4) {
		this.distinctCloneObjCountHANAS4 = distinctCloneObjCountHANAS4;
	}

	public int getDistinctUsedCloneObjCount() {
		return distinctUsedCloneObjCount;
	}

	public void setDistinctUsedCloneObjCount(int distinctUsedCloneObjCount) {
		this.distinctUsedCloneObjCount = distinctUsedCloneObjCount;
	}

	public int getIdenticalSrcCodeCount() {
		return identicalSrcCodeCount;
	}

	public void setIdenticalSrcCodeCount(int identicalSrcCodeCount) {
		this.identicalSrcCodeCount = identicalSrcCodeCount;
	}

	public int getPartialSimilarSrcCodeCount() {
		return partialSimilarSrcCodeCount;
	}

	public void setPartialSimilarSrcCodeCount(int partialSimilarSrcCodeCount) {
		this.partialSimilarSrcCodeCount = partialSimilarSrcCodeCount;
	}

	public int getSimilarSrcCodeCount() {
		return similarSrcCodeCount;
	}

	public void setSimilarSrcCodeCount(int similarSrcCodeCount) {
		this.similarSrcCodeCount = similarSrcCodeCount;
	}

	public int getVrySimilarSrcCodeCount() {
		return vrySimilarSrcCodeCount;
	}

	public void setVrySimilarSrcCodeCount(int vrySimilarSrcCodeCount) {
		this.vrySimilarSrcCodeCount = vrySimilarSrcCodeCount;
	}

	public int getDistinctIdenticalSrcCodeCount() {
		return distinctIdenticalSrcCodeCount;
	}

	public void setDistinctIdenticalSrcCodeCount(int distinctIdenticalSrcCodeCount) {
		this.distinctIdenticalSrcCodeCount = distinctIdenticalSrcCodeCount;
	}

	public int getDistinctPartialSimilarSrcCodeCount() {
		return distinctPartialSimilarSrcCodeCount;
	}

	public void setDistinctPartialSimilarSrcCodeCount(int distinctPartialSimilarSrcCodeCount) {
		this.distinctPartialSimilarSrcCodeCount = distinctPartialSimilarSrcCodeCount;
	}

	public int getDistinctSimilarSrcCodeCount() {
		return distinctSimilarSrcCodeCount;
	}

	public void setDistinctSimilarSrcCodeCount(int distinctSimilarSrcCodeCount) {
		this.distinctSimilarSrcCodeCount = distinctSimilarSrcCodeCount;
	}

	public int getDistinctVrySimilarSrcCodeCount() {
		return distinctVrySimilarSrcCodeCount;
	}

	public void setDistinctVrySimilarSrcCodeCount(int distinctVrySimilarSrcCodeCount) {
		this.distinctVrySimilarSrcCodeCount = distinctVrySimilarSrcCodeCount;
	}

	public int getDistinctIdenticalSrcCodeUsedCount() {
		return distinctIdenticalSrcCodeUsedCount;
	}

	public void setDistinctIdenticalSrcCodeUsedCount(int distinctIdenticalSrcCodeUsedCount) {
		this.distinctIdenticalSrcCodeUsedCount = distinctIdenticalSrcCodeUsedCount;
	}

	public int getDistinctPartialSimilarSrcCodeUsedCount() {
		return distinctPartialSimilarSrcCodeUsedCount;
	}

	public void setDistinctPartialSimilarSrcCodeUsedCount(int distinctPartialSimilarSrcCodeUsedCount) {
		this.distinctPartialSimilarSrcCodeUsedCount = distinctPartialSimilarSrcCodeUsedCount;
	}

	public int getDistinctSimilarSrcCodeUsedCount() {
		return distinctSimilarSrcCodeUsedCount;
	}

	public void setDistinctSimilarSrcCodeUsedCount(int distinctSimilarSrcCodeUsedCount) {
		this.distinctSimilarSrcCodeUsedCount = distinctSimilarSrcCodeUsedCount;
	}

	public int getDistinctVrySimilarSrcCodeUsedCount() {
		return distinctVrySimilarSrcCodeUsedCount;
	}

	public void setDistinctVrySimilarSrcCodeUsedCount(int distinctVrySimilarSrcCodeUsedCount) {
		this.distinctVrySimilarSrcCodeUsedCount = distinctVrySimilarSrcCodeUsedCount;
	}

	// Smodilog Counts
	public int getDistinctStdModObjCount() {
		return distinctStdModObjCount;
	}

	public void setDistinctStdModObjCount(int distinctStdModObjCount) {
		this.distinctStdModObjCount = distinctStdModObjCount;
	}

	public int getErrorStdModObjCount() {
		return errorStdModObjCount;
	}

	public void setErrorStdModObjCount(int errorStdModObjCount) {
		this.errorStdModObjCount = errorStdModObjCount;
	}

	public int getErrorSPDDObjCount() {
		return errorSPDDObjCount;
	}

	public void setErrorSPDDObjCount(int errorSPDDObjCount) {
		this.errorSPDDObjCount = errorSPDDObjCount;
	}

	public int getErrorSPAUObjCount() {
		return errorSPAUObjCount;
	}

	public void setErrorSPAUObjCount(int errorSPAUObjCount) {
		this.errorSPAUObjCount = errorSPAUObjCount;
	}

	public int getDistinctSmodDTELCount() {
		return distinctSmodDTELCount;
	}

	public void setDistinctSmodDTELCount(int distinctSmodDTELCount) {
		this.distinctSmodDTELCount = distinctSmodDTELCount;
	}

	public int getDistinctSmodDOMACount() {
		return distinctSmodDOMACount;
	}

	public void setDistinctSmodDOMACount(int distinctSmodDOMACount) {
		this.distinctSmodDOMACount = distinctSmodDOMACount;
	}

	public int getDistinctSmodTTYPCount() {
		return distinctSmodTTYPCount;
	}

	public void setDistinctSmodTTYPCount(int distinctSmodTTYPCount) {
		this.distinctSmodTTYPCount = distinctSmodTTYPCount;
	}

	public int getDistinctSmodTOBJCount() {
		return distinctSmodTOBJCount;
	}

	public void setDistinctSmodTOBJCount(int distinctSmodTOBJCount) {
		this.distinctSmodTOBJCount = distinctSmodTOBJCount;
	}

	public int getDistinctSmodTABLCount() {
		return distinctSmodTABLCount;
	}

	public void setDistinctSmodTABLCount(int distinctSmodTABLCount) {
		this.distinctSmodTABLCount = distinctSmodTABLCount;
	}

	public int getDistinctSmodCLASCount() {
		return distinctSmodCLASCount;
	}

	public void setDistinctSmodCLASCount(int distinctSmodCLASCount) {
		this.distinctSmodCLASCount = distinctSmodCLASCount;
	}

	public int getDistinctSmodPROGCount() {
		return distinctSmodPROGCount;
	}

	public void setDistinctSmodPROGCount(int distinctSmodPROGCount) {
		this.distinctSmodPROGCount = distinctSmodPROGCount;
	}

	public int getDistinctSmodFUGRCount() {
		return distinctSmodFUGRCount;
	}

	public void setDistinctSmodFUGRCount(int distinctSmodFUGRCount) {
		this.distinctSmodFUGRCount = distinctSmodFUGRCount;
	}

	public int getDistinctSmodPARACount() {
		return distinctSmodPARACount;
	}

	public void setDistinctSmodPARACount(int distinctSmodPARACount) {
		this.distinctSmodPARACount = distinctSmodPARACount;
	}

	public int getDistinctSmodSMIMCount() {
		return distinctSmodSMIMCount;
	}

	public void setDistinctSmodSMIMCount(int distinctSmodSMIMCount) {
		this.distinctSmodSMIMCount = distinctSmodSMIMCount;
	}

	public int getDistinctSmodSXSDCount() {
		return distinctSmodSXSDCount;
	}

	public void setDistinctSmodSXSDCount(int distinctSmodSXSDCount) {
		this.distinctSmodSXSDCount = distinctSmodSXSDCount;
	}

	public int getDistinctSmodVIEWCount() {
		return distinctSmodVIEWCount;
	}

	public void setDistinctSmodVIEWCount(int distinctSmodVIEWCount) {
		this.distinctSmodVIEWCount = distinctSmodVIEWCount;
	}

	public int getDistinctSmodWAPACount() {
		return distinctSmodWAPACount;
	}

	public void setDistinctSmodWAPACount(int distinctSmodWAPACount) {
		this.distinctSmodWAPACount = distinctSmodWAPACount;
	}

	public int getDistinctSmodENHOCount() {
		return distinctSmodENHOCount;
	}

	public void setDistinctSmodENHOCount(int distinctSmodENHOCount) {
		this.distinctSmodENHOCount = distinctSmodENHOCount;
	}

	public int getDistinctSmodINTFCount() {
		return distinctSmodINTFCount;
	}

	public void setDistinctSmodINTFCount(int distinctSmodINTFCount) {
		this.distinctSmodINTFCount = distinctSmodINTFCount;
	}

	public int getDistinctSmodSHLPCount() {
		return distinctSmodSHLPCount;
	}

	public void setDistinctSmodSHLPCount(int distinctSmodSHLPCount) {
		this.distinctSmodSHLPCount = distinctSmodSHLPCount;
	}

	public int getDistinctSmodSMODCount() {
		return distinctSmodSMODCount;
	}

	public void setDistinctSmodSMODCount(int distinctSmodSMODCount) {
		this.distinctSmodSMODCount = distinctSmodSMODCount;
	}

	public int getDistinctSmodSXCICount() {
		return distinctSmodSXCICount;
	}

	public void setDistinctSmodSXCICount(int distinctSmodSXCICount) {
		this.distinctSmodSXCICount = distinctSmodSXCICount;
	}

	public int getDistinctSmodFUGXCount() {
		return distinctSmodFUGXCount;
	}

	public void setDistinctSmodFUGXCount(int distinctSmodFUGXCount) {
		this.distinctSmodFUGXCount = distinctSmodFUGXCount;
	}

	public int getDistinctSmodPDTSCount() {
		return distinctSmodPDTSCount;
	}

	public void setDistinctSmodPDTSCount(int distinctSmodPDTSCount) {
		this.distinctSmodPDTSCount = distinctSmodPDTSCount;
	}

	public int getDistinctSmodLODECount() {
		return distinctSmodLODECount;
	}

	public void setDistinctSmodLODECount(int distinctSmodLODECount) {
		this.distinctSmodLODECount = distinctSmodLODECount;
	}

	public int getDistinctSmodDEVCCount() {
		return distinctSmodDEVCCount;
	}

	public void setDistinctSmodDEVCCount(int distinctSmodDEVCCount) {
		this.distinctSmodDEVCCount = distinctSmodDEVCCount;
	}

	public int getDistinctSmodTRANCount() {
		return distinctSmodTRANCount;
	}

	public void setDistinctSmodTRANCount(int distinctSmodTRANCount) {
		this.distinctSmodTRANCount = distinctSmodTRANCount;
	}

	public int getDistinctSmodENQUCount() {
		return distinctSmodENQUCount;
	}

	public void setDistinctSmodENQUCount(int distinctSmodENQUCount) {
		this.distinctSmodENQUCount = distinctSmodENQUCount;
	}

	public int getDistinctSmodMSAGCount() {
		return distinctSmodMSAGCount;
	}

	public void setDistinctSmodMSAGCount(int distinctSmodMSAGCount) {
		this.distinctSmodMSAGCount = distinctSmodMSAGCount;
	}

	public int getDistinctSmodSPRXCount() {
		return distinctSmodSPRXCount;
	}

	public void setDistinctSmodSPRXCount(int distinctSmodSPRXCount) {
		this.distinctSmodSPRXCount = distinctSmodSPRXCount;
	}

	public int getDistinctSmodPDWSCount() {
		return distinctSmodPDWSCount;
	}

	public void setDistinctSmodPDWSCount(int distinctSmodPDWSCount) {
		this.distinctSmodPDWSCount = distinctSmodPDWSCount;
	}

	public int getDistinctSmodSSFOCount() {
		return distinctSmodSSFOCount;
	}

	public void setDistinctSmodSSFOCount(int distinctSmodSSFOCount) {
		this.distinctSmodSSFOCount = distinctSmodSSFOCount;
	}

	public int getDistinctSmodSSSTCount() {
		return distinctSmodSSSTCount;
	}

	public void setDistinctSmodSSSTCount(int distinctSmodSSSTCount) {
		this.distinctSmodSSSTCount = distinctSmodSSSTCount;
	}

	public int getDistinctSmodENHSCount() {
		return distinctSmodENHSCount;
	}

	public void setDistinctSmodENHSCount(int distinctSmodENHSCount) {
		this.distinctSmodENHSCount = distinctSmodENHSCount;
	}

	public int getDistinctSmodSFPICount() {
		return distinctSmodSFPICount;
	}

	public void setDistinctSmodSFPICount(int distinctSmodSFPICount) {
		this.distinctSmodSFPICount = distinctSmodSFPICount;
	}

	public int getDistinctSmodSFPFCount() {
		return distinctSmodSFPFCount;
	}

	public void setDistinctSmodSFPFCount(int distinctSmodSFPFCount) {
		this.distinctSmodSFPFCount = distinctSmodSFPFCount;
	}

	public int getDistinctSmodPFCSCount() {
		return distinctSmodPFCSCount;
	}

	public void setDistinctSmodPFCSCount(int distinctSmodPFCSCount) {
		this.distinctSmodPFCSCount = distinctSmodPFCSCount;
	}

	public int getDistinctSmodLOIECount() {
		return distinctSmodLOIECount;
	}

	public void setDistinctSmodLOIECount(int distinctSmodLOIECount) {
		this.distinctSmodLOIECount = distinctSmodLOIECount;
	}

	public int getDistinctSmodLODCCount() {
		return distinctSmodLODCCount;
	}

	public void setDistinctSmodLODCCount(int distinctSmodLODCCount) {
		this.distinctSmodLODCCount = distinctSmodLODCCount;
	}

	public int getDistinctSmodSOBJCount() {
		return distinctSmodSOBJCount;
	}

	public void setDistinctSmodSOBJCount(int distinctSmodSOBJCount) {
		this.distinctSmodSOBJCount = distinctSmodSOBJCount;
	}

	public int getDistinctSmodSOTRCount() {
		return distinctSmodSOTRCount;
	}

	public void setDistinctSmodSOTRCount(int distinctSmodSOTRCount) {
		this.distinctSmodSOTRCount = distinctSmodSOTRCount;
	}

	public int getDistinctSmodUSRRCount() {
		return distinctSmodUSRRCount;
	}

	public void setDistinctSmodUSRRCount(int distinctSmodUSRRCount) {
		this.distinctSmodUSRRCount = distinctSmodUSRRCount;
	}

	public int getDistinctSmodUSRECount() {
		return distinctSmodUSRECount;
	}

	public void setDistinctSmodUSRECount(int distinctSmodUSRECount) {
		this.distinctSmodUSRECount = distinctSmodUSRECount;
	}

	public int getDistinctSmodENHCCount() {
		return distinctSmodENHCCount;
	}

	public void setDistinctSmodENHCCount(int distinctSmodENHCCount) {
		this.distinctSmodENHCCount = distinctSmodENHCCount;
	}

	public int getDistinctSmodLSMWCount() {
		return distinctSmodLSMWCount;
	}

	public void setDistinctSmodLSMWCount(int distinctSmodLSMWCount) {
		this.distinctSmodLSMWCount = distinctSmodLSMWCount;
	}

	public int getDistinctSmodWDYNCount() {
		return distinctSmodWDYNCount;
	}

	public void setDistinctSmodWDYNCount(int distinctSmodWDYNCount) {
		this.distinctSmodWDYNCount = distinctSmodWDYNCount;
	}

	public int getDistinctSmodIATUCount() {
		return distinctSmodIATUCount;
	}

	public void setDistinctSmodIATUCount(int distinctSmodIATUCount) {
		this.distinctSmodIATUCount = distinctSmodIATUCount;
	}

	public int getDistinctSmodXSLTCount() {
		return distinctSmodXSLTCount;
	}

	public void setDistinctSmodXSLTCount(int distinctSmodXSLTCount) {
		this.distinctSmodXSLTCount = distinctSmodXSLTCount;
	}

	public int getDistinctSmodACGRCount() {
		return distinctSmodACGRCount;
	}

	public void setDistinctSmodACGRCount(int distinctSmodACGRCount) {
		this.distinctSmodACGRCount = distinctSmodACGRCount;
	}

	public int getDistinctSmodSCVICount() {
		return distinctSmodSCVICount;
	}

	public void setDistinctSmodSCVICount(int distinctSmodSCVICount) {
		this.distinctSmodSCVICount = distinctSmodSCVICount;
	}

	public int getDistinctSmodPHDECount() {
		return distinctSmodPHDECount;
	}

	public void setDistinctSmodPHDECount(int distinctSmodPHDECount) {
		this.distinctSmodPHDECount = distinctSmodPHDECount;
	}

	public int getDistinctSmodPOCSCount() {
		return distinctSmodPOCSCount;
	}

	public void setDistinctSmodPOCSCount(int distinctSmodPOCSCount) {
		this.distinctSmodPOCSCount = distinctSmodPOCSCount;
	}

	public int getDistinctSmodFUGSCount() {
		return distinctSmodFUGSCount;
	}

	public void setDistinctSmodFUGSCount(int distinctSmodFUGSCount) {
		this.distinctSmodFUGSCount = distinctSmodFUGSCount;
	}

	public int getDistinctSmodWEBICount() {
		return distinctSmodWEBICount;
	}

	public void setDistinctSmodWEBICount(int distinctSmodWEBICount) {
		this.distinctSmodWEBICount = distinctSmodWEBICount;
	}

	public int getDistinctSmodBOBFCount() {
		return distinctSmodBOBFCount;
	}

	public void setDistinctSmodBOBFCount(int distinctSmodBOBFCount) {
		this.distinctSmodBOBFCount = distinctSmodBOBFCount;
	}

	public int getDistinctSmodSUSOCount() {
		return distinctSmodSUSOCount;
	}

	public void setDistinctSmodSUSOCount(int distinctSmodSUSOCount) {
		this.distinctSmodSUSOCount = distinctSmodSUSOCount;
	}

	public int getDistinctSmodVCLSCount() {
		return distinctSmodVCLSCount;
	}

	public void setDistinctSmodVCLSCount(int distinctSmodVCLSCount) {
		this.distinctSmodVCLSCount = distinctSmodVCLSCount;
	}

	public int getDistinctSmodINDXCount() {
		return distinctSmodINDXCount;
	}

	public void setDistinctSmodINDXCount(int distinctSmodINDXCount) {
		this.distinctSmodINDXCount = distinctSmodINDXCount;
	}

	public int getDistinctSmodREPTCount() {
		return distinctSmodREPTCount;
	}

	public void setDistinctSmodREPTCount(int distinctSmodREPTCount) {
		this.distinctSmodREPTCount = distinctSmodREPTCount;
	}

	public int getDistinctSmodDIALCount() {
		return distinctSmodDIALCount;
	}

	public void setDistinctSmodDIALCount(int distinctSmodDIALCount) {
		this.distinctSmodDIALCount = distinctSmodDIALCount;
	}

	public int getDistinctSmodSTVICount() {
		return distinctSmodSTVICount;
	}

	public void setDistinctSmodSTVICount(int distinctSmodSTVICount) {
		this.distinctSmodSTVICount = distinctSmodSTVICount;
	}

	public int getDistinctSmodAQSGCount() {
		return distinctSmodAQSGCount;
	}

	public void setDistinctSmodAQSGCount(int distinctSmodAQSGCount) {
		this.distinctSmodAQSGCount = distinctSmodAQSGCount;
	}

	public int getDistinctSmodAQBGCount() {
		return distinctSmodAQBGCount;
	}

	public void setDistinctSmodAQBGCount(int distinctSmodAQBGCount) {
		this.distinctSmodAQBGCount = distinctSmodAQBGCount;
	}

	public int getDistinctSmodAQQUCount() {
		return distinctSmodAQQUCount;
	}

	public void setDistinctSmodAQQUCount(int distinctSmodAQQUCount) {
		this.distinctSmodAQQUCount = distinctSmodAQQUCount;
	}

	// AUCT Counts
	public int getManPreCheckErrors() {
		return manPreCheckErrors;
	}

	public void setManPreCheckErrors(int manPreCheckErrors) {
		this.manPreCheckErrors = manPreCheckErrors;
	}

	public int getUnicodeErrorCount() {
		return unicodeErrorCount;
	}

	public void setUnicodeErrorCount(int unicodeErrorCount) {
		this.unicodeErrorCount = unicodeErrorCount;
	}

	public int getSyntaxErrorCount() {
		return syntaxErrorCount;
	}

	public void setSyntaxErrorCount(int syntaxErrorCount) {
		this.syntaxErrorCount = syntaxErrorCount;
	}

	public int getInactiveObjCount() {
		return inactiveObjCount;
	}

	public void setInactiveObjCount(int inactiveObjCount) {
		this.inactiveObjCount = inactiveObjCount;
	}

	// Fiori Counts
	public int getTotalFioriAppCount() {
		return totalFioriAppCount;
	}

	public void setTotalFioriAppCount(int totalFioriAppCount) {
		this.totalFioriAppCount = totalFioriAppCount;
	}

	public int getCustomAppsCount() {
		return customAppsCount;
	}

	public void setCustomAppsCount(int customAppsCount) {
		this.customAppsCount = customAppsCount;
	}

	public int getStandardAppsCount() {
		return standardAppsCount;
	}

	public void setStandardAppsCount(int standardAppsCount) {
		this.standardAppsCount = standardAppsCount;
	}

	// S4 Optional Counts
	public int getTotalOptionalImpactedObjectCount() {
		return totalOptionalImpactedObjectCount;
	}

	public void setTotalOptionalImpactedObjectCount(int totalOptionalImpactedObjectCount) {
		this.totalOptionalImpactedObjectCount = totalOptionalImpactedObjectCount;
	}

	public int getDistinctOptionalImpactedObjCount() {
		return distinctOptionalImpactedObjCount;
	}

	public void setDistinctOptionalImpactedObjCount(int distinctOptionalImpactedObjCount) {
		this.distinctOptionalImpactedObjCount = distinctOptionalImpactedObjCount;
	}

	public int getTotalOptionalImpactedUsedObjCount() {
		return totalOptionalImpactedUsedObjCount;
	}

	public void setTotalOptionalImpactedUsedObjCount(int totalOptionalImpactedUsedObjCount) {
		this.totalOptionalImpactedUsedObjCount = totalOptionalImpactedUsedObjCount;
	}

	public int getDistinctOptionalImpactedUsedObjCount() {
		return distinctOptionalImpactedUsedObjCount;
	}

	public void setDistinctOptionalImpactedUsedObjCount(int distinctOptionalImpactedUsedObjCount) {
		this.distinctOptionalImpactedUsedObjCount = distinctOptionalImpactedUsedObjCount;
	}

	// S4 Counts Based on Remediation Category and Complexity
	public int getManHighObjCount() {
		return manHighObjCount;
	}

	public void setManHighObjCount(int manHighObjCount) {
		this.manHighObjCount = manHighObjCount;
	}

	public int getManMedObjCount() {
		return manMedObjCount;
	}

	public void setManMedObjCount(int manMedObjCount) {
		this.manMedObjCount = manMedObjCount;
	}

	public int getManLowObjCount() {
		return manLowObjCount;
	}

	public void setManLowObjCount(int manLowObjCount) {
		this.manLowObjCount = manLowObjCount;
	}

	public int getManTBDObjCount() {
		return manTBDObjCount;
	}

	public void setManTBDObjCount(int manTBDObjCount) {
		this.manTBDObjCount = manTBDObjCount;
	}

	public int getManHighUsedObjCount() {
		return manHighUsedObjCount;
	}

	public void setManHighUsedObjCount(int manHighUsedObjCount) {
		this.manHighUsedObjCount = manHighUsedObjCount;
	}

	public int getManMedUsedObjCount() {
		return manMedUsedObjCount;
	}

	public void setManMedUsedObjCount(int manMedUsedObjCount) {
		this.manMedUsedObjCount = manMedUsedObjCount;
	}

	public int getManLowUsedObjCount() {
		return manLowUsedObjCount;
	}

	public void setManLowUsedObjCount(int manLowUsedObjCount) {
		this.manLowUsedObjCount = manLowUsedObjCount;
	}

	public int getManTBDUsedObjCount() {
		return manTBDUsedObjCount;
	}

	public void setManTBDUsedObjCount(int manTBDUsedObjCount) {
		this.manTBDUsedObjCount = manTBDUsedObjCount;
	}

	public int getOptLowObjCount() {
		return optLowObjCount;
	}

	public void setOptLowObjCount(int optLowObjCount) {
		this.optLowObjCount = optLowObjCount;
	}

	public int getOptVryLowObjCount() {
		return optVryLowObjCount;
	}

	public void setOptVryLowObjCount(int optVryLowObjCount) {
		this.optVryLowObjCount = optVryLowObjCount;
	}

	public int getOptMediumObjCount() {
		return optMediumObjCount;
	}

	public void setOptMediumObjCount(int optMediumObjCount) {
		this.optMediumObjCount = optMediumObjCount;
	}

	public int getOptHighObjCount() {
		return optHighObjCount;
	}

	public void setOptHighObjCount(int optHighObjCount) {
		this.optHighObjCount = optHighObjCount;
	}

	public int getOptLowUsedObjCount() {
		return optLowUsedObjCount;
	}

	public void setOptLowUsedObjCount(int optLowUsedObjCount) {
		this.optLowUsedObjCount = optLowUsedObjCount;
	}

	public int getOptVryLowUsedObjCount() {
		return optVryLowUsedObjCount;
	}

	public void setOptVryLowUsedObjCount(int optVryLowUsedObjCount) {
		this.optVryLowUsedObjCount = optVryLowUsedObjCount;
	}

	public int getOptMedUsedObjCount() {
		return optMedUsedObjCount;
	}

	public void setOptMedUsedObjCount(int optMedUsedObjCount) {
		this.optMedUsedObjCount = optMedUsedObjCount;
	}

	public int getOptHighUsedObjCount() {
		return optHighUsedObjCount;
	}

	public void setOptHighUsedObjCount(int optHighUsedObjCount) {
		this.optHighUsedObjCount = optHighUsedObjCount;
	}
	
	// S4 - Impacted Standard Transaction
	public int getTotalStdTransactionsCount() {
		return totalStdTransactionsCount;
	}

	public void setTotalStdTransactionsCount(int totalStdTransactionsCount) {
		this.totalStdTransactionsCount = totalStdTransactionsCount;
	}

	// Counts Based on Scope - HANA, S4 and OS Migration
	public int getDistinctObjCount() {
		return distinctObjCount;
	}

	public void setDistinctObjCount(int distinctObjCount) {
		this.distinctObjCount = distinctObjCount;
	}

	public int getDistinctUsedObjCount() {
		return distinctUsedObjCount;
	}

	public void setDistinctUsedObjCount(int distinctUsedObjCount) {
		this.distinctUsedObjCount = distinctUsedObjCount;
	}
	
	public int getDistinctManImpactedObjCount() {
		return distinctManImpactedObjCount;
	}

	public void setDistinctManImpactedObjCount(int distinctManImpactedObjCount) {
		this.distinctManImpactedObjCount = distinctManImpactedObjCount;
	}

	public int getDistinctManImpactedUsedObjCount() {
		return distinctManImpactedUsedObjCount;
	}

	public void setDistinctManImpactedUsedObjCount(int distinctManImpactedUsedObjCount) {
		this.distinctManImpactedUsedObjCount = distinctManImpactedUsedObjCount;
	}
	
	public int getTotalErrorCount() {
		return totalErrorCount;
	}

	public void setTotalErrorCount(int totalErrorCount) {
		this.totalErrorCount = totalErrorCount;
	}

	public int getTotalManImpactedObjectCount() {
		return totalManImpactedObjectCount;
	}

	public void setTotalManImpactedObjectCount(int totalManImpactedObjectCount) {
		this.totalManImpactedObjectCount = totalManImpactedObjectCount;
	}

	public int getTotalManImpactedUsedObjCount() {
		return totalManImpactedUsedObjCount;
	}

	public void setTotalManImpactedUsedObjCount(int totalManImpactedUsedObjCount) {
		this.totalManImpactedUsedObjCount = totalManImpactedUsedObjCount;
	}
	
	// OS Migration Counts - File Path Impacted by OS Change & Logical Command Impacted by OS Change
	public int getDistinctLogFilePathCountOSMig() {
		return distinctLogFilePathCountOSMig;
	}

	public void setDistinctLogFilePathCountOSMig(int distinctLogFilePathCountOSMig) {
		this.distinctLogFilePathCountOSMig = distinctLogFilePathCountOSMig;
	}

	public int getDistinctLogCommandCountOSMig() {
		return distinctLogCommandCountOSMig;
	}

	public void setDistinctLogCommandCountOSMig(int distinctLogCommandCountOSMig) {
		this.distinctLogCommandCountOSMig = distinctLogCommandCountOSMig;
	}

	// OS Migration Counts - Based on Remediation Category and Description
	public int getDistinctManImpactedObjCountCallSystemID() {
		return distinctManImpactedObjCountCallSystemID;
	}

	public void setDistinctManImpactedObjCountCallSystemID(int distinctManImpactedObjCountCallSystemID) {
		this.distinctManImpactedObjCountCallSystemID = distinctManImpactedObjCountCallSystemID;
	}

	public int getDistinctManImpactedObjCountSXPGCommandExecute() {
		return distinctManImpactedObjCountSXPGCommandExecute;
	}

	public void setDistinctManImpactedObjCountSXPGCommandExecute(int distinctManImpactedObjCountSXPGCommandExecute) {
		this.distinctManImpactedObjCountSXPGCommandExecute = distinctManImpactedObjCountSXPGCommandExecute;
	}

	public int getTotalManImpactedObjectCountCallSystemID() {
		return totalManImpactedObjectCountCallSystemID;
	}

	public void setTotalManImpactedObjectCountCallSystemID(int totalManImpactedObjectCountCallSystemID) {
		this.totalManImpactedObjectCountCallSystemID = totalManImpactedObjectCountCallSystemID;
	}

	public int getTotalManImpactedObjectCountSXPGCommandExecute() {
		return totalManImpactedObjectCountSXPGCommandExecute;
	}

	public void setTotalManImpactedObjectCountSXPGCommandExecute(int totalManImpactedObjectCountSXPGCommandExecute) {
		this.totalManImpactedObjectCountSXPGCommandExecute = totalManImpactedObjectCountSXPGCommandExecute;
	}

	public int getDistinctOptImpactedObjCountOpenDataset() {
		return distinctOptImpactedObjCountOpenDataset;
	}

	public void setDistinctOptImpactedObjCountOpenDataset(int distinctOptImpactedObjCountOpenDataset) {
		this.distinctOptImpactedObjCountOpenDataset = distinctOptImpactedObjCountOpenDataset;
	}

	public int getTotalOptImpactedObjCountOpenDataset() {
		return totalOptImpactedObjCountOpenDataset;
	}

	public void setTotalOptImpactedObjCountOpenDataset(int totalOptImpactedObjCountOpenDataset) {
		this.totalOptImpactedObjCountOpenDataset = totalOptImpactedObjCountOpenDataset;
	}

	// Impacted Object List Counts
	public int getTotalImpactedObjCount() {
		return totalImpactedObjCount;
	}

	public void setTotalImpactedObjCount(int totalImpactedObjCount) {
		this.totalImpactedObjCount = totalImpactedObjCount;
	}

	public int getTotalImpactedUsedObjCount() {
		return totalImpactedUsedObjCount;
	}

	public void setTotalImpactedUsedObjCount(int totalImpactedUsedObjCount) {
		this.totalImpactedUsedObjCount = totalImpactedUsedObjCount;
	}

	public int getTotalImpPROG() {
		return totalImpPROG;
	}

	public void setTotalImpPROG(int totalImpPROG) {
		this.totalImpPROG = totalImpPROG;
	}

	public int getTotalImpUsedPROG() {
		return totalImpUsedPROG;
	}

	public void setTotalImpUsedPROG(int totalImpUsedPROG) {
		this.totalImpUsedPROG = totalImpUsedPROG;
	}

	public int getTotalImpFUGR() {
		return totalImpFUGR;
	}

	public void setTotalImpFUGR(int totalImpFUGR) {
		this.totalImpFUGR = totalImpFUGR;
	}

	public int getTotalImpUsedFUGR() {
		return totalImpUsedFUGR;
	}

	public void setTotalImpUsedFUGR(int totalImpUsedFUGR) {
		this.totalImpUsedFUGR = totalImpUsedFUGR;
	}

	public int getTotalImpCLAS() {
		return totalImpCLAS;
	}

	public void setTotalImpCLAS(int totalImpCLAS) {
		this.totalImpCLAS = totalImpCLAS;
	}

	public int getTotalImpUsedCLAS() {
		return totalImpUsedCLAS;
	}

	public void setTotalImpUsedCLAS(int totalImpUsedCLAS) {
		this.totalImpUsedCLAS = totalImpUsedCLAS;
	}

	public int getTotalImpENHO() {
		return totalImpENHO;
	}

	public void setTotalImpENHO(int totalImpENHO) {
		this.totalImpENHO = totalImpENHO;
	}

	public int getTotalImpUsedENHO() {
		return totalImpUsedENHO;
	}

	public void setTotalImpUsedENHO(int totalImpUsedENHO) {
		this.totalImpUsedENHO = totalImpUsedENHO;
	}

	public int getTotalImpENHC() {
		return totalImpENHC;
	}

	public void setTotalImpENHC(int totalImpENHC) {
		this.totalImpENHC = totalImpENHC;
	}

	public int getTotalImpUsedENHC() {
		return totalImpUsedENHC;
	}

	public void setTotalImpUsedENHC(int totalImpUsedENHC) {
		this.totalImpUsedENHC = totalImpUsedENHC;
	}

	public int getTotalImpLSMW() {
		return totalImpLSMW;
	}

	public void setTotalImpLSMW(int totalImpLSMW) {
		this.totalImpLSMW = totalImpLSMW;
	}

	public int getTotalImpUsedLSMW() {
		return totalImpUsedLSMW;
	}

	public void setTotalImpUsedLSMW(int totalImpUsedLSMW) {
		this.totalImpUsedLSMW = totalImpUsedLSMW;
	}

	public int getTotalImpFUGS() {
		return totalImpFUGS;
	}

	public void setTotalImpFUGS(int totalImpFUGS) {
		this.totalImpFUGS = totalImpFUGS;
	}

	public int getTotalImpUsedFUGS() {
		return totalImpUsedFUGS;
	}

	public void setTotalImpUsedFUGS(int totalImpUsedFUGS) {
		this.totalImpUsedFUGS = totalImpUsedFUGS;
	}

	public int getTotalImpSSFO() {
		return totalImpSSFO;
	}

	public void setTotalImpSSFO(int totalImpSSFO) {
		this.totalImpSSFO = totalImpSSFO;
	}

	public int getTotalImpUsedSSFO() {
		return totalImpUsedSSFO;
	}

	public void setTotalImpUsedSSFO(int totalImpUsedSSFO) {
		this.totalImpUsedSSFO = totalImpUsedSSFO;
	}

	public int getTotalImpDTEL() {
		return totalImpDTEL;
	}

	public void setTotalImpDTEL(int totalImpDTEL) {
		this.totalImpDTEL = totalImpDTEL;
	}

	public int getTotalImpUsedDTEL() {
		return totalImpUsedDTEL;
	}

	public void setTotalImpUsedDTEL(int totalImpUsedDTEL) {
		this.totalImpUsedDTEL = totalImpUsedDTEL;
	}

	public int getTotalImpENHS() {
		return totalImpENHS;
	}

	public void setTotalImpENHS(int totalImpENHS) {
		this.totalImpENHS = totalImpENHS;
	}

	public int getTotalImpUsedENHS() {
		return totalImpUsedENHS;
	}

	public void setTotalImpUsedENHS(int totalImpUsedENHS) {
		this.totalImpUsedENHS = totalImpUsedENHS;
	}

	public int getTotalImpWDYN() {
		return totalImpWDYN;
	}

	public void setTotalImpWDYN(int totalImpWDYN) {
		this.totalImpWDYN = totalImpWDYN;
	}

	public int getTotalImpUsedWDYN() {
		return totalImpUsedWDYN;
	}

	public void setTotalImpUsedWDYN(int totalImpUsedWDYN) {
		this.totalImpUsedWDYN = totalImpUsedWDYN;
	}

	public int getTotalImpUSRE() {
		return totalImpUSRE;
	}

	public void setTotalImpUSRE(int totalImpUSRE) {
		this.totalImpUSRE = totalImpUSRE;
	}

	public int getTotalImpUsedUSRE() {
		return totalImpUsedUSRE;
	}

	public void setTotalImpUsedUSRE(int totalImpUsedUSRE) {
		this.totalImpUsedUSRE = totalImpUsedUSRE;
	}

	public int getTotalImpUSRR() {
		return totalImpUSRR;
	}

	public void setTotalImpUSRR(int totalImpUSRR) {
		this.totalImpUSRR = totalImpUSRR;
	}

	public int getTotalImpUsedUSRR() {
		return totalImpUsedUSRR;
	}

	public void setTotalImpUsedUSRR(int totalImpUsedUSRR) {
		this.totalImpUsedUSRR = totalImpUsedUSRR;
	}

	public int getTotalImpSFPI() {
		return totalImpSFPI;
	}

	public void setTotalImpSFPI(int totalImpSFPI) {
		this.totalImpSFPI = totalImpSFPI;
	}

	public int getTotalImpUsedSFPI() {
		return totalImpUsedSFPI;
	}

	public void setTotalImpUsedSFPI(int totalImpUsedSFPI) {
		this.totalImpUsedSFPI = totalImpUsedSFPI;
	}

	public int getTotalImpREPT() {
		return totalImpREPT;
	}

	public void setTotalImpREPT(int totalImpREPT) {
		this.totalImpREPT = totalImpREPT;
	}

	public int getTotalImpUsedREPT() {
		return totalImpUsedREPT;
	}

	public void setTotalImpUsedREPT(int totalImpUsedREPT) {
		this.totalImpUsedREPT = totalImpUsedREPT;
	}

	public int getTotalImpVIEW() {
		return totalImpVIEW;
	}

	public void setTotalImpVIEW(int totalImpVIEW) {
		this.totalImpVIEW = totalImpVIEW;
	}

	public int getTotalImpUsedVIEW() {
		return totalImpUsedVIEW;
	}

	public void setTotalImpUsedVIEW(int totalImpUsedVIEW) {
		this.totalImpUsedVIEW = totalImpUsedVIEW;
	}

	public int getTotalImpINDX() {
		return totalImpINDX;
	}

	public void setTotalImpINDX(int totalImpINDX) {
		this.totalImpINDX = totalImpINDX;
	}

	public int getTotalImpUsedINDX() {
		return totalImpUsedINDX;
	}

	public void setTotalImpUsedINDX(int totalImpUsedINDX) {
		this.totalImpUsedINDX = totalImpUsedINDX;
	}

	public int getTotalImpCDAT() {
		return totalImpCDAT;
	}

	public void setTotalImpCDAT(int totalImpCDAT) {
		this.totalImpCDAT = totalImpCDAT;
	}

	public int getTotalImpUsedCDAT() {
		return totalImpUsedCDAT;
	}

	public void setTotalImpUsedCDAT(int totalImpUsedCDAT) {
		this.totalImpUsedCDAT = totalImpUsedCDAT;
	}

	public int getTotalImpTABU() {
		return totalImpTABU;
	}

	public void setTotalImpTABU(int totalImpTABU) {
		this.totalImpTABU = totalImpTABU;
	}

	public int getTotalImpUsedTABU() {
		return totalImpUsedTABU;
	}

	public void setTotalImpUsedTABU(int totalImpUsedTABU) {
		this.totalImpUsedTABU = totalImpUsedTABU;
	}

	public int getTotalImpBWTR() {
		return totalImpBWTR;
	}

	public void setTotalImpBWTR(int totalImpBWTR) {
		this.totalImpBWTR = totalImpBWTR;
	}

	public int getTotalImpUsedBWTR() {
		return totalImpUsedBWTR;
	}

	public void setTotalImpUsedBWTR(int totalImpUsedBWTR) {
		this.totalImpUsedBWTR = totalImpUsedBWTR;
	}

	public int getTotalImpBWTS() {
		return totalImpBWTS;
	}

	public void setTotalImpBWTS(int totalImpBWTS) {
		this.totalImpBWTS = totalImpBWTS;
	}

	public int getTotalImpUsedBWTS() {
		return totalImpUsedBWTS;
	}

	public void setTotalImpUsedBWTS(int totalImpUsedBWTS) {
		this.totalImpUsedBWTS = totalImpUsedBWTS;
	}

	public int getTotalImpBWUR() {
		return totalImpBWUR;
	}

	public void setTotalImpBWUR(int totalImpBWUR) {
		this.totalImpBWUR = totalImpBWUR;
	}

	public int getTotalImpUsedBWUR() {
		return totalImpUsedBWUR;
	}

	public void setTotalImpUsedBWUR(int totalImpUsedBWUR) {
		this.totalImpUsedBWUR = totalImpUsedBWUR;
	}

	public int getTotalImpBWIG() {
		return totalImpBWIG;
	}

	public void setTotalImpBWIG(int totalImpBWIG) {
		this.totalImpBWIG = totalImpBWIG;
	}

	public int getTotalImpUsedBWIG() {
		return totalImpUsedBWIG;
	}

	public void setTotalImpUsedBWIG(int totalImpUsedBWIG) {
		this.totalImpUsedBWIG = totalImpUsedBWIG;
	}
	
	public int getTotalImpINDE() {
		return totalImpINDE;
	}

	public void setTotalImpINDE(int totalImpINDE) {
		this.totalImpINDE = totalImpINDE;
	}

	public int getTotalImpUsedINDE() {
		return totalImpUsedINDE;
	}

	public void setTotalImpUsedINDE(int totalImpUsedINDE) {
		this.totalImpUsedINDE = totalImpUsedINDE;
	}

	public int getTotalImpAQQU() {
		return totalImpAQQU;
	}

	public void setTotalImpAQQU(int totalImpAQQU) {
		this.totalImpAQQU = totalImpAQQU;
	}

	public int getTotalImpUsedAQQU() {
		return totalImpUsedAQQU;
	}

	public void setTotalImpUsedAQQU(int totalImpUsedAQQU) {
		this.totalImpUsedAQQU = totalImpUsedAQQU;
	}

	// Inventory List Counts
	public int getTotalInventoryObj() {
		return totalInventoryObj;
	}

	public void setTotalInventoryObj(int totalInventoryObj) {
		this.totalInventoryObj = totalInventoryObj;
	}

	public int getTotalInventoryUsedObj() {
		return totalInventoryUsedObj;
	}

	public void setTotalInventoryUsedObj(int totalInventoryUsedObj) {
		this.totalInventoryUsedObj = totalInventoryUsedObj;
	}

	public int getTotalInventoryUnusedObj() {
		return totalInventoryUnusedObj;
	}

	public void setTotalInventoryUnusedObj(int totalInventoryUnusedObj) {
		this.totalInventoryUnusedObj = totalInventoryUnusedObj;
	}

	public float getTotalInvenoryUsedObjPercentage() {
		return totalInvenoryUsedObjPercentage;
	}

	public void setTotalInvenoryUsedObjPercentage(float totalInvenoryUsedObjPercentage) {
		this.totalInvenoryUsedObjPercentage = totalInvenoryUsedObjPercentage;
	}

	public float getTotalInvenoryUnusedObjPercentage() {
		return totalInvenoryUnusedObjPercentage;
	}

	public void setTotalInvenoryUnusedObjPercentage(float totalInvenoryUnusedObjPercentage) {
		this.totalInvenoryUnusedObjPercentage = totalInvenoryUnusedObjPercentage;
	}

	public int getTotalInvPROG() {
		return totalInvPROG;
	}

	public void setTotalInvPROG(int totalInvPROG) {
		this.totalInvPROG = totalInvPROG;
	}

	public int getTotalInvUsedPROG() {
		return totalInvUsedPROG;
	}

	public void setTotalInvUsedPROG(int totalInvUsedPROG) {
		this.totalInvUsedPROG = totalInvUsedPROG;
	}

	public int getTotalInvFUGR() {
		return totalInvFUGR;
	}

	public void setTotalInvFUGR(int totalInvFUGR) {
		this.totalInvFUGR = totalInvFUGR;
	}

	public int getTotalInvUsedFUGR() {
		return totalInvUsedFUGR;
	}

	public void setTotalInvUsedFUGR(int totalInvUsedFUGR) {
		this.totalInvUsedFUGR = totalInvUsedFUGR;
	}

	public int getTotalInvCLAS() {
		return totalInvCLAS;
	}

	public void setTotalInvCLAS(int totalInvCLAS) {
		this.totalInvCLAS = totalInvCLAS;
	}

	public int getTotalInvUsedCLAS() {
		return totalInvUsedCLAS;
	}

	public void setTotalInvUsedCLAS(int totalInvUsedCLAS) {
		this.totalInvUsedCLAS = totalInvUsedCLAS;
	}

	public int getTotalInvENHO() {
		return totalInvENHO;
	}

	public void setTotalInvENHO(int totalInvENHO) {
		this.totalInvENHO = totalInvENHO;
	}

	public int getTotalInvUsedENHO() {
		return totalInvUsedENHO;
	}

	public void setTotalInvUsedENHO(int totalInvUsedENHO) {
		this.totalInvUsedENHO = totalInvUsedENHO;
	}

	public int getTotalInvENHC() {
		return totalInvENHC;
	}

	public void setTotalInvENHC(int totalInvENHC) {
		this.totalInvENHC = totalInvENHC;
	}

	public int getTotalInvUsedENHC() {
		return totalInvUsedENHC;
	}

	public void setTotalInvUsedENHC(int totalInvUsedENHC) {
		this.totalInvUsedENHC = totalInvUsedENHC;
	}

	public int getTotalInvLSMW() {
		return totalInvLSMW;
	}

	public void setTotalInvLSMW(int totalInvLSMW) {
		this.totalInvLSMW = totalInvLSMW;
	}

	public int getTotalInvUsedLSMW() {
		return totalInvUsedLSMW;
	}

	public void setTotalInvUsedLSMW(int totalInvUsedLSMW) {
		this.totalInvUsedLSMW = totalInvUsedLSMW;
	}

	public int getTotalInvFUGS() {
		return totalInvFUGS;
	}

	public void setTotalInvFUGS(int totalInvFUGS) {
		this.totalInvFUGS = totalInvFUGS;
	}

	public int getTotalInvUsedFUGS() {
		return totalInvUsedFUGS;
	}

	public void setTotalInvUsedFUGS(int totalInvUsedFUGS) {
		this.totalInvUsedFUGS = totalInvUsedFUGS;
	}

	public int getTotalInvSSFO() {
		return totalInvSSFO;
	}

	public void setTotalInvSSFO(int totalInvSSFO) {
		this.totalInvSSFO = totalInvSSFO;
	}

	public int getTotalInvUsedSSFO() {
		return totalInvUsedSSFO;
	}

	public void setTotalInvUsedSSFO(int totalInvUsedSSFO) {
		this.totalInvUsedSSFO = totalInvUsedSSFO;
	}

	public int getTotalInvDTEL() {
		return totalInvDTEL;
	}

	public void setTotalInvDTEL(int totalInvDTEL) {
		this.totalInvDTEL = totalInvDTEL;
	}

	public int getTotalInvUsedDTEL() {
		return totalInvUsedDTEL;
	}

	public void setTotalInvUsedDTEL(int totalInvUsedDTEL) {
		this.totalInvUsedDTEL = totalInvUsedDTEL;
	}

	public int getTotalInvENHS() {
		return totalInvENHS;
	}

	public void setTotalInvENHS(int totalInvENHS) {
		this.totalInvENHS = totalInvENHS;
	}

	public int getTotalInvUsedENHS() {
		return totalInvUsedENHS;
	}

	public void setTotalInvUsedENHS(int totalInvUsedENHS) {
		this.totalInvUsedENHS = totalInvUsedENHS;
	}

	public int getTotalInvWDYN() {
		return totalInvWDYN;
	}

	public void setTotalInvWDYN(int totalInvWDYN) {
		this.totalInvWDYN = totalInvWDYN;
	}

	public int getTotalInvUsedWDYN() {
		return totalInvUsedWDYN;
	}

	public void setTotalInvUsedWDYN(int totalInvUsedWDYN) {
		this.totalInvUsedWDYN = totalInvUsedWDYN;
	}

	public int getTotalInvUSRE() {
		return totalInvUSRE;
	}

	public void setTotalInvUSRE(int totalInvUSRE) {
		this.totalInvUSRE = totalInvUSRE;
	}

	public int getTotalInvUsedUSRE() {
		return totalInvUsedUSRE;
	}

	public void setTotalInvUsedUSRE(int totalInvUsedUSRE) {
		this.totalInvUsedUSRE = totalInvUsedUSRE;
	}

	public int getTotalInvUSRR() {
		return totalInvUSRR;
	}

	public void setTotalInvUSRR(int totalInvUSRR) {
		this.totalInvUSRR = totalInvUSRR;
	}

	public int getTotalInvUsedUSRR() {
		return totalInvUsedUSRR;
	}

	public void setTotalInvUsedUSRR(int totalInvUsedUSRR) {
		this.totalInvUsedUSRR = totalInvUsedUSRR;
	}

	public int getTotalInvSFPI() {
		return totalInvSFPI;
	}

	public void setTotalInvSFPI(int totalInvSFPI) {
		this.totalInvSFPI = totalInvSFPI;
	}

	public int getTotalInvUsedSFPI() {
		return totalInvUsedSFPI;
	}

	public void setTotalInvUsedSFPI(int totalInvUsedSFPI) {
		this.totalInvUsedSFPI = totalInvUsedSFPI;
	}

	public int getTotalInvREPT() {
		return totalInvREPT;
	}

	public void setTotalInvREPT(int totalInvREPT) {
		this.totalInvREPT = totalInvREPT;
	}

	public int getTotalInvUsedREPT() {
		return totalInvUsedREPT;
	}

	public void setTotalInvUsedREPT(int totalInvUsedREPT) {
		this.totalInvUsedREPT = totalInvUsedREPT;
	}

	public int getTotalInvVIEW() {
		return totalInvVIEW;
	}

	public void setTotalInvVIEW(int totalInvVIEW) {
		this.totalInvVIEW = totalInvVIEW;
	}

	public int getTotalInvUsedVIEW() {
		return totalInvUsedVIEW;
	}

	public void setTotalInvUsedVIEW(int totalInvUsedVIEW) {
		this.totalInvUsedVIEW = totalInvUsedVIEW;
	}

	public int getTotalInvINDX() {
		return totalInvINDX;
	}

	public void setTotalInvINDX(int totalInvINDX) {
		this.totalInvINDX = totalInvINDX;
	}

	public int getTotalInvUsedINDX() {
		return totalInvUsedINDX;
	}

	public void setTotalInvUsedINDX(int totalInvUsedINDX) {
		this.totalInvUsedINDX = totalInvUsedINDX;
	}

	public int getTotalInvCDAT() {
		return totalInvCDAT;
	}

	public void setTotalInvCDAT(int totalInvCDAT) {
		this.totalInvCDAT = totalInvCDAT;
	}

	public int getTotalInvUsedCDAT() {
		return totalInvUsedCDAT;
	}

	public void setTotalInvUsedCDAT(int totalInvUsedCDAT) {
		this.totalInvUsedCDAT = totalInvUsedCDAT;
	}

	public int getTotalInvTABU() {
		return totalInvTABU;
	}

	public void setTotalInvTABU(int totalInvTABU) {
		this.totalInvTABU = totalInvTABU;
	}

	public int getTotalInvUsedTABU() {
		return totalInvUsedTABU;
	}

	public void setTotalInvUsedTABU(int totalInvUsedTABU) {
		this.totalInvUsedTABU = totalInvUsedTABU;
	}

	public int getTotalInvBWTR() {
		return totalInvBWTR;
	}

	public void setTotalInvBWTR(int totalInvBWTR) {
		this.totalInvBWTR = totalInvBWTR;
	}

	public int getTotalInvUsedBWTR() {
		return totalInvUsedBWTR;
	}

	public void setTotalInvUsedBWTR(int totalInvUsedBWTR) {
		this.totalInvUsedBWTR = totalInvUsedBWTR;
	}

	public int getTotalInvBWTS() {
		return totalInvBWTS;
	}

	public void setTotalInvBWTS(int totalInvBWTS) {
		this.totalInvBWTS = totalInvBWTS;
	}

	public int getTotalInvUsedBWTS() {
		return totalInvUsedBWTS;
	}

	public void setTotalInvUsedBWTS(int totalInvUsedBWTS) {
		this.totalInvUsedBWTS = totalInvUsedBWTS;
	}

	public int getTotalInvBWUR() {
		return totalInvBWUR;
	}

	public void setTotalInvBWUR(int totalInvBWUR) {
		this.totalInvBWUR = totalInvBWUR;
	}

	public int getTotalInvUsedBWUR() {
		return totalInvUsedBWUR;
	}

	public void setTotalInvUsedBWUR(int totalInvUsedBWUR) {
		this.totalInvUsedBWUR = totalInvUsedBWUR;
	}

	public int getTotalInvBWIG() {
		return totalInvBWIG;
	}

	public void setTotalInvBWIG(int totalInvBWIG) {
		this.totalInvBWIG = totalInvBWIG;
	}

	public int getTotalInvUsedBWIG() {
		return totalInvUsedBWIG;
	}

	public void setTotalInvUsedBWIG(int totalInvUsedBWIG) {
		this.totalInvUsedBWIG = totalInvUsedBWIG;
	}
	
	public int getTotalInvINDE() {
		return totalInvINDE;
	}

	public void setTotalInvINDE(int totalInvINDE) {
		this.totalInvINDE = totalInvINDE;
	}

	public int getTotalInvUsedINDE() {
		return totalInvUsedINDE;
	}

	public void setTotalInvUsedINDE(int totalInvUsedINDE) {
		this.totalInvUsedINDE = totalInvUsedINDE;
	}

	public int getTotalInvAQQU() {
		return totalInvAQQU;
	}

	public void setTotalInvAQQU(int totalInvAQQU) {
		this.totalInvAQQU = totalInvAQQU;
	}

	public int getTotalInvUsedAQQU() {
		return totalInvUsedAQQU;
	}

	public void setTotalInvUsedAQQU(int totalInvUsedAQQU) {
		this.totalInvUsedAQQU = totalInvUsedAQQU;
	}

	// HANA Counts Based on Automation Status and Percentage Calculation
	public float getManAutoYPercentage() {
		return manAutoYPercentage;
	}

	public void setManAutoYPercentage(float manAutoYPercentage) {
		this.manAutoYPercentage = manAutoYPercentage;
	}

	public int getTotalAutoYImpUsedObjCount() {
		return totalAutoYImpUsedObjCount;
	}

	public void setTotalAutoYImpUsedObjCount(int totalAutoYImpUsedObjCount) {
		this.totalAutoYImpUsedObjCount = totalAutoYImpUsedObjCount;
	}

	public float getManAutoYUsedPercentage() {
		return manAutoYUsedPercentage;
	}

	public void setManAutoYUsedPercentage(float manAutoYUsedPercentage) {
		this.manAutoYUsedPercentage = manAutoYUsedPercentage;
	}
	
	// HANA Counts Based on Automation Status
	public int getDistinctAutomaticCount() {
		return distinctAutomaticCount;
	}

	public void setDistinctAutomaticCount(int distinctAutomaticCount) {
		this.distinctAutomaticCount = distinctAutomaticCount;
	}

	public int getErrorAutomaticCount() {
		return errorAutomaticCount;
	}

	public void setErrorAutomaticCount(int errorAutomaticCount) {
		this.errorAutomaticCount = errorAutomaticCount;
	}

	// HANA Counts Based on Remediation Category and Issue Category
	public int getManHanSort() {
		return manHanSort;
	}

	public void setManHanSort(int manHanSort) {
		this.manHanSort = manHanSort;
	}

	public int getManSemError() {
		return manSemError;
	}

	public void setManSemError(int manSemError) {
		this.manSemError = manSemError;
	}

	public int getUsedManHanaSort() {
		return usedManHanaSort;
	}

	public void setUsedManHanaSort(int usedManHanaSort) {
		this.usedManHanaSort = usedManHanaSort;
	}

	public int getUsedManSemError() {
		return usedManSemError;
	}

	public void setUsedManSemError(int usedManSemError) {
		this.usedManSemError = usedManSemError;
	}

	public int getAppLevelOptKeepResultSetSmall() {
		return appLevelOptKeepResultSetSmall;
	}

	public void setAppLevelOptKeepResultSetSmall(int appLevelOptKeepResultSetSmall) {
		this.appLevelOptKeepResultSetSmall = appLevelOptKeepResultSetSmall;
	}

	public int getAppLevelOptKeepUnnecLoadAwayFromDB() {
		return appLevelOptKeepUnnecLoadAwayFromDB;
	}

	public void setAppLevelOptKeepUnnecLoadAwayFromDB(int appLevelOptKeepUnnecLoadAwayFromDB) {
		this.appLevelOptKeepUnnecLoadAwayFromDB = appLevelOptKeepUnnecLoadAwayFromDB;
	}

	public int getAppLevelMinAmtOfTranData() {
		return appLevelMinAmtOfTranData;
	}

	public void setAppLevelMinAmtOfTranData(int appLevelMinAmtOfTranData) {
		this.appLevelMinAmtOfTranData = appLevelMinAmtOfTranData;
	}

	public int getAppLevelSelectQueriesInGlobalRoutines() {
		return appLevelSelectQueriesInGlobalRoutines;
	}

	public void setAppLevelSelectQueriesInGlobalRoutines(int appLevelSelectQueriesInGlobalRoutines) {
		this.appLevelSelectQueriesInGlobalRoutines = appLevelSelectQueriesInGlobalRoutines;
	}

	public int getHanaLevelOptMinAmtOfTranData() {
		return hanaLevelOptMinAmtOfTranData;
	}

	public void setHanaLevelOptMinAmtOfTranData(int hanaLevelOptMinAmtOfTranData) {
		this.hanaLevelOptMinAmtOfTranData = hanaLevelOptMinAmtOfTranData;
	}

	public int getHanaHousKeepUnnecLoadAwayFromDB() {
		return hanaHousKeepUnnecLoadAwayFromDB;
	}

	public void setHanaHousKeepUnnecLoadAwayFromDB(int hanaHousKeepUnnecLoadAwayFromDB) {
		this.hanaHousKeepUnnecLoadAwayFromDB = hanaHousKeepUnnecLoadAwayFromDB;
	}

	public int getHanaHouseKeepStatIgnoreByHana() {
		return hanaHouseKeepStatIgnoreByHana;
	}

	public void setHanaHouseKeepStatIgnoreByHana(int hanaHouseKeepStatIgnoreByHana) {
		this.hanaHouseKeepStatIgnoreByHana = hanaHouseKeepStatIgnoreByHana;
	}

	// HANA Counts Based on Remediation Category
	public int getTotalAppLevelOptImpObjCount() {
		return totalAppLevelOptImpObjCount;
	}

	public void setTotalAppLevelOptImpObjCount(int totalAppLevelOptImpObjCount) {
		this.totalAppLevelOptImpObjCount = totalAppLevelOptImpObjCount;
	}
	
	public int getTotalUsedAppLevelOptImpObjCount() {
		return totalUsedAppLevelOptImpObjCount;
	}

	public void setTotalUsedAppLevelOptImpObjCount(int totalUsedAppLevelOptImpObjCount) {
		this.totalUsedAppLevelOptImpObjCount = totalUsedAppLevelOptImpObjCount;
	}

	public int getDistinctAppLevelOptImpObjCount() {
		return distinctAppLevelOptImpObjCount;
	}

	public void setDistinctAppLevelOptImpObjCount(int distinctAppLevelOptImpObjCount) {
		this.distinctAppLevelOptImpObjCount = distinctAppLevelOptImpObjCount;
	}
	
	public int getDistinctUsedAppLevelOptImpObjCount() {
		return distinctUsedAppLevelOptImpObjCount;
	}

	public void setDistinctUsedAppLevelOptImpObjCount(int distinctUsedAppLevelOptImpObjCount) {
		this.distinctUsedAppLevelOptImpObjCount = distinctUsedAppLevelOptImpObjCount;
	}

	public int getTotalHanaLevelOptImpObjCount() {
		return totalHanaLevelOptImpObjCount;
	}

	public void setTotalHanaLevelOptImpObjCount(int totalHanaLevelOptImpObjCount) {
		this.totalHanaLevelOptImpObjCount = totalHanaLevelOptImpObjCount;
	}
	
	public int getTotalUsedHanaLevelOptImpObjCount() {
		return totalUsedHanaLevelOptImpObjCount;
	}

	public void setTotalUsedHanaLevelOptImpObjCount(int totalUsedHanaLevelOptImpObjCount) {
		this.totalUsedHanaLevelOptImpObjCount = totalUsedHanaLevelOptImpObjCount;
	}

	public int getDistinctHanaLevelOptImpObjCount() {
		return distinctHanaLevelOptImpObjCount;
	}

	public void setDistinctHanaLevelOptImpObjCount(int distinctHanaLevelOptImpObjCount) {
		this.distinctHanaLevelOptImpObjCount = distinctHanaLevelOptImpObjCount;
	}
	
	public int getDistinctUsedHanaLevelOptImpObjCount() {
		return distinctUsedHanaLevelOptImpObjCount;
	}

	public void setDistinctUsedHanaLevelOptImpObjCount(int distinctUsedHanaLevelOptImpObjCount) {
		this.distinctUsedHanaLevelOptImpObjCount = distinctUsedHanaLevelOptImpObjCount;
	}

	public int getTotalHanaHouseKeepImpObjCount() {
		return totalHanaHouseKeepImpObjCount;
	}

	public void setTotalHanaHouseKeepImpObjCount(int totalHanaHouseKeepImpObjCount) {
		this.totalHanaHouseKeepImpObjCount = totalHanaHouseKeepImpObjCount;
	}
	
	public int getTotalUsedHanaHouseKeepImpObjCount() {
		return totalUsedHanaHouseKeepImpObjCount;
	}

	public void setTotalUsedHanaHouseKeepImpObjCount(int totalUsedHanaHouseKeepImpObjCount) {
		this.totalUsedHanaHouseKeepImpObjCount = totalUsedHanaHouseKeepImpObjCount;
	}

	public int getDistinctHanaHouseKeepImpObjCount() {
		return distinctHanaHouseKeepImpObjCount;
	}

	public void setDistinctHanaHouseKeepImpObjCount(int distinctHanaHouseKeepImpObjCount) {
		this.distinctHanaHouseKeepImpObjCount = distinctHanaHouseKeepImpObjCount;
	}
	
	public int getDistinctUsedHanaHouseKeepImpObjCount() {
		return distinctUsedHanaHouseKeepImpObjCount;
	}

	public void setDistinctUsedHanaHouseKeepImpObjCount(int distinctUsedHanaHouseKeepImpObjCount) {
		this.distinctUsedHanaHouseKeepImpObjCount = distinctUsedHanaHouseKeepImpObjCount;
	}

	// HANA, S4 and OS Migration Common Counts - From BenchMarking Perspective
	public int getTotalCommonImpactedObjCountHanaAndS4AndOSMig() {
		return totalCommonImpactedObjCountHanaAndS4AndOSMig;
	}

	public void setTotalCommonImpactedObjCountHanaAndS4AndOSMig(int totalCommonImpactedObjCountHanaAndS4AndOSMig) {
		this.totalCommonImpactedObjCountHanaAndS4AndOSMig = totalCommonImpactedObjCountHanaAndS4AndOSMig;
	}

	public int getTotalCommonImpactedUsedObjCountHanaAndS4AndOSMig() {
		return totalCommonImpactedUsedObjCountHanaAndS4AndOSMig;
	}

	public void setTotalCommonImpactedUsedObjCountHanaAndS4AndOSMig(
			int totalCommonImpactedUsedObjCountHanaAndS4AndOSMig) {
		this.totalCommonImpactedUsedObjCountHanaAndS4AndOSMig = totalCommonImpactedUsedObjCountHanaAndS4AndOSMig;
	}

	public int getTotalCommonManImpactedObjCountHanaAndS4AndOSMig() {
		return totalCommonManImpactedObjCountHanaAndS4AndOSMig;
	}

	public void setTotalCommonManImpactedObjCountHanaAndS4AndOSMig(
			int totalCommonManImpactedObjCountHanaAndS4AndOSMig) {
		this.totalCommonManImpactedObjCountHanaAndS4AndOSMig = totalCommonManImpactedObjCountHanaAndS4AndOSMig;
	}

	public int getTotalCommonManImpactedUsedObjCountHanaAndS4AndOSMig() {
		return totalCommonManImpactedUsedObjCountHanaAndS4AndOSMig;
	}

	public void setTotalCommonManImpactedUsedObjCountHanaAndS4AndOSMig(
			int totalCommonManImpactedUsedObjCountHanaAndS4AndOSMig) {
		this.totalCommonManImpactedUsedObjCountHanaAndS4AndOSMig = totalCommonManImpactedUsedObjCountHanaAndS4AndOSMig;
	}

	public int getDistinctMandatoryImpactHanaS4OsMig() {
		return distinctMandatoryImpactHanaS4OsMig;
	}

	public void setDistinctMandatoryImpactHanaS4OsMig(int distinctMandatoryImpactHanaS4OsMig) {
		this.distinctMandatoryImpactHanaS4OsMig = distinctMandatoryImpactHanaS4OsMig;
	}

	public int getDistinctMandatoryImpacUnusedHanaS4OsMig() {
		return distinctMandatoryImpacUnusedHanaS4OsMig;
	}

	public void setDistinctMandatoryImpacUnusedHanaS4OsMig(int distinctMandatoryImpacUnusedHanaS4OsMig) {
		this.distinctMandatoryImpacUnusedHanaS4OsMig = distinctMandatoryImpacUnusedHanaS4OsMig;
	}

	public float getManImpacUnusedPercHanaS4OsMigPerc() {
		return manImpacUnusedPercHanaS4OsMigPerc;
	}

	public void setManImpacUnusedPercHanaS4OsMigPerc(float manImpacUnusedPercHanaS4OsMigPerc) {
		this.manImpacUnusedPercHanaS4OsMigPerc = manImpacUnusedPercHanaS4OsMigPerc;
	}

	public int getDistinctImpactHanaS4OsMig() {
		return distinctImpactHanaS4OsMig;
	}

	public void setDistinctImpactHanaS4OsMig(int distinctImpactHanaS4OsMig) {
		this.distinctImpactHanaS4OsMig = distinctImpactHanaS4OsMig;
	}

	public int getDistinctImpactUsedHanaS4OsMig() {
		return distinctImpactUsedHanaS4OsMig;
	}

	public void setDistinctImpactUsedHanaS4OsMig(int distinctImpactUsedHanaS4OsMig) {
		this.distinctImpactUsedHanaS4OsMig = distinctImpactUsedHanaS4OsMig;
	}

	public float getManImpactHanaS4OsMigPerc() {
		return manImpactHanaS4OsMigPerc;
	}

	public void setManImpactHanaS4OsMigPerc(float manImpactHanaS4OsMigPerc) {
		this.manImpactHanaS4OsMigPerc = manImpactHanaS4OsMigPerc;
	}
	
	// HANA and S4 Common Counts - From PPT Perspective
	public int getTotalCommonImpactedObjCountHanaAndS4() {
		return totalCommonImpactedObjCountHanaAndS4;
	}

	public void setTotalCommonImpactedObjCountHanaAndS4(int totalCommonImpactedObjCountHanaAndS4) {
		this.totalCommonImpactedObjCountHanaAndS4 = totalCommonImpactedObjCountHanaAndS4;
	}

	public int getTotalCommonImpactedUsedObjCountHanaAndS4() {
		return totalCommonImpactedUsedObjCountHanaAndS4;
	}

	public void setTotalCommonImpactedUsedObjCountHanaAndS4(int totalCommonImpactedUsedObjCountHanaAndS4) {
		this.totalCommonImpactedUsedObjCountHanaAndS4 = totalCommonImpactedUsedObjCountHanaAndS4;
	}

	public int getTotalCommonManImpactedObjCountHanaAndS4() {
		return totalCommonManImpactedObjCountHanaAndS4;
	}

	public void setTotalCommonManImpactedObjCountHanaAndS4(int totalCommonManImpactedObjCountHanaAndS4) {
		this.totalCommonManImpactedObjCountHanaAndS4 = totalCommonManImpactedObjCountHanaAndS4;
	}

	public int getTotalCommonManImpactedUsedObjCountHanaAndS4() {
		return totalCommonManImpactedUsedObjCountHanaAndS4;
	}

	public void setTotalCommonManImpactedUsedObjCountHanaAndS4(int totalCommonManImpactedUsedObjCountHanaAndS4) {
		this.totalCommonManImpactedUsedObjCountHanaAndS4 = totalCommonManImpactedUsedObjCountHanaAndS4;
	}

	public int getDistinctMandatoryImpactHanaS4() {
		return distinctMandatoryImpactHanaS4;
	}

	public void setDistinctMandatoryImpactHanaS4(int distinctMandatoryImpactHanaS4) {
		this.distinctMandatoryImpactHanaS4 = distinctMandatoryImpactHanaS4;
	}

	public int getDistinctMandatoryImpacUnusedHanaS4() {
		return distinctMandatoryImpacUnusedHanaS4;
	}

	public void setDistinctMandatoryImpacUnusedHanaS4(int distinctMandatoryImpacUnusedHanaS4) {
		this.distinctMandatoryImpacUnusedHanaS4 = distinctMandatoryImpacUnusedHanaS4;
	}

	public float getManImpacUnusedPercHanaS4Perc() {
		return manImpacUnusedPercHanaS4Perc;
	}

	public void setManImpacUnusedPercHanaS4Perc(float manImpacUnusedPercHanaS4Perc) {
		this.manImpacUnusedPercHanaS4Perc = manImpacUnusedPercHanaS4Perc;
	}

	public int getDistinctImpactHanaS4() {
		return distinctImpactHanaS4;
	}

	public void setDistinctImpactHanaS4(int distinctImpactHanaS4) {
		this.distinctImpactHanaS4 = distinctImpactHanaS4;
	}

	public int getDistinctImpactUsedHanaS4() {
		return distinctImpactUsedHanaS4;
	}

	public void setDistinctImpactUsedHanaS4(int distinctImpactUsedHanaS4) {
		this.distinctImpactUsedHanaS4 = distinctImpactUsedHanaS4;
	}

	public float getManImpactHanaS4Perc() {
		return manImpactHanaS4Perc;
	}

	public void setManImpactHanaS4Perc(float manImpactHanaS4Perc) {
		this.manImpactHanaS4Perc = manImpactHanaS4Perc;
	}

	// Testing Scope Counts
	public int getTscopeProcessCount() {
		return tscopeProcessCount;
	}

	public void setTscopeProcessCount(int tscopeProcessCount) {
		this.tscopeProcessCount = tscopeProcessCount;
	}

	public int getTscopeObjCount() {
		return tscopeObjCount;
	}

	public void setTscopeObjCount(int tscopeObjCount) {
		this.tscopeObjCount = tscopeObjCount;
	}
	
	// SIA Counts
	public int getSecurityTotalRoles() {
		return securityTotalRoles;
	}

	public void setSecurityTotalRoles(int securityTotalRoles) {
		this.securityTotalRoles = securityTotalRoles;
	}

	public int getTotalRolesImpacted() {
		return totalRolesImpacted;
	}

	public void setTotalRolesImpacted(int totalRolesImpacted) {
		this.totalRolesImpacted = totalRolesImpacted;
	}

	public int getSecRoleNeedsModification() {
		return secRoleNeedsModification;
	}

	public void setSecRoleNeedsModification(int secRoleNeedsModification) {
		this.secRoleNeedsModification = secRoleNeedsModification;
	}

	public int getSecRoleModFiori() {
		return secRoleModFiori;
	}

	public void setSecRoleModFiori(int secRoleModFiori) {
		this.secRoleModFiori = secRoleModFiori;
	}

	public int getSecTcodeObsOrNoReplacement() {
		return secTcodeObsOrNoReplacement;
	}

	public void setSecTcodeObsOrNoReplacement(int secTcodeObsOrNoReplacement) {
		this.secTcodeObsOrNoReplacement = secTcodeObsOrNoReplacement;
	}

	public int getSecRoleNeedModCleanup() {
		return secRoleNeedModCleanup;
	}

	public void setSecRoleNeedModCleanup(int secRoleNeedModCleanup) {
		this.secRoleNeedModCleanup = secRoleNeedModCleanup;
	}

	public int getSecSapNewTcodeVersions() {
		return secSapNewTcodeVersions;
	}

	public void setSecSapNewTcodeVersions(int secSapNewTcodeVersions) {
		this.secSapNewTcodeVersions = secSapNewTcodeVersions;
	}
	
	public float getSecRoleNeedModPercentage() {
		return secRoleNeedModPercentage;
	}

	public void setSecRoleNeedModPercentage(float secRoleNeedModPercentage) {
		this.secRoleNeedModPercentage = secRoleNeedModPercentage;
	}

	// Impacted Background Job Counts
	public int getTotalImpBackgrounJob() {
		return totalImpBackgrounJob;
	}

	public void setTotalImpBackgrounJob(int totalImpBackgrounJob) {
		this.totalImpBackgrounJob = totalImpBackgrounJob;
	}

	public int getDistinctImpProgramCount() {
		return distinctImpProgramCount;
	}

	public void setDistinctImpProgramCount(int distinctImpProgramCount) {
		this.distinctImpProgramCount = distinctImpProgramCount;
	}

	// HANA and S4 Object Error Counts
	public int getErrorUsedCount() {
		return errorUsedCount;
	}

	public void setErrorUsedCount(int errorUsedCount) {
		this.errorUsedCount = errorUsedCount;
	}

	public int getErrorCLASCount() {
		return errorCLASCount;
	}

	public void setErrorCLASCount(int errorCLASCount) {
		this.errorCLASCount = errorCLASCount;
	}

	public int getErrorBWTRCount() {
		return errorBWTRCount;
	}

	public void setErrorBWTRCount(int errorBWTRCount) {
		this.errorBWTRCount = errorBWTRCount;
	}

	public int getErrorBWTSCount() {
		return errorBWTSCount;
	}

	public void setErrorBWTSCount(int errorBWTSCount) {
		this.errorBWTSCount = errorBWTSCount;
	}

	public int getErrorBWURCount() {
		return errorBWURCount;
	}

	public void setErrorBWURCount(int errorBWURCount) {
		this.errorBWURCount = errorBWURCount;
	}

	public int getErrorBWIGCount() {
		return errorBWIGCount;
	}

	public void setErrorBWIGCount(int errorBWIGCount) {
		this.errorBWIGCount = errorBWIGCount;
	}

	public int getErrorCDATCount() {
		return errorCDATCount;
	}

	public void setErrorCDATCount(int errorCDATCount) {
		this.errorCDATCount = errorCDATCount;
	}

	public int getErrorTABUCount() {
		return errorTABUCount;
	}

	public void setErrorTABUCount(int errorTABUCount) {
		this.errorTABUCount = errorTABUCount;
	}

	public int getErrorPROGCount() {
		return errorPROGCount;
	}

	public void setErrorPROGCount(int errorPROGCount) {
		this.errorPROGCount = errorPROGCount;
	}

	public int getErrorSSFOCount() {
		return errorSSFOCount;
	}

	public void setErrorSSFOCount(int errorSSFOCount) {
		this.errorSSFOCount = errorSSFOCount;
	}
	
	public int getErrorSFPFCount() {
		return errorSFPFCount;
	}

	public void setErrorSFPFCount(int errorSFPFCount) {
		this.errorSFPFCount = errorSFPFCount;
	}

	public int getErrorSFPICount() {
		return errorSFPICount;
	}

	public void setErrorSFPICount(int errorSFPICount) {
		this.errorSFPICount = errorSFPICount;
	}

	public int getErrorFUGRCount() {
		return errorFUGRCount;
	}

	public void setErrorFUGRCount(int errorFUGRCount) {
		this.errorFUGRCount = errorFUGRCount;
	}

	public int getErrorENHOCount() {
		return errorENHOCount;
	}

	public void setErrorENHOCount(int errorENHOCount) {
		this.errorENHOCount = errorENHOCount;
	}

	public int getErrorENHSCount() {
		return errorENHSCount;
	}

	public void setErrorENHSCount(int errorENHSCount) {
		this.errorENHSCount = errorENHSCount;
	}

	public int getErrorENHCCount() {
		return errorENHCCount;
	}

	public void setErrorENHCCount(int errorENHCCount) {
		this.errorENHCCount = errorENHCCount;
	}

	public int getErrorLSMWCount() {
		return errorLSMWCount;
	}

	public void setErrorLSMWCount(int errorLSMWCount) {
		this.errorLSMWCount = errorLSMWCount;
	}

	public int getErrorUSRECount() {
		return errorUSRECount;
	}

	public void setErrorUSRECount(int errorUSRECount) {
		this.errorUSRECount = errorUSRECount;
	}

	public int getErrorUSRRCount() {
		return errorUSRRCount;
	}

	public void setErrorUSRRCount(int errorUSRRCount) {
		this.errorUSRRCount = errorUSRRCount;
	}

	public int getErrorWDYNCount() {
		return errorWDYNCount;
	}

	public void setErrorWDYNCount(int errorWDYNCount) {
		this.errorWDYNCount = errorWDYNCount;
	}

	public int getErrorREPTCount() {
		return errorREPTCount;
	}

	public void setErrorREPTCount(int errorREPTCount) {
		this.errorREPTCount = errorREPTCount;
	}

	public int getErrorVIEWCount() {
		return errorVIEWCount;
	}

	public void setErrorVIEWCount(int errorVIEWCount) {
		this.errorVIEWCount = errorVIEWCount;
	}

	public int getErrorINDXCount() {
		return errorINDXCount;
	}

	public void setErrorINDXCount(int errorINDXCount) {
		this.errorINDXCount = errorINDXCount;
	}

	public int getErrorDTELCount() {
		return errorDTELCount;
	}

	public void setErrorDTELCount(int errorDTELCount) {
		this.errorDTELCount = errorDTELCount;
	}
	
	public int getErrorFUGSCount() {
		return errorFUGSCount;
	}

	public void setErrorFUGSCount(int errorFUGSCount) {
		this.errorFUGSCount = errorFUGSCount;
	}
	
	public int getErrorAQQUCount() {
		return errorAQQUCount;
	}

	public void setErrorAQQUCount(int errorAQQUCount) {
		this.errorAQQUCount = errorAQQUCount;
	}

	public int getErrorUsedCLASCount() {
		return errorUsedCLASCount;
	}

	public void setErrorUsedCLASCount(int errorUsedCLASCount) {
		this.errorUsedCLASCount = errorUsedCLASCount;
	}

	public int getErrorUsedBWTRCount() {
		return errorUsedBWTRCount;
	}

	public void setErrorUsedBWTRCount(int errorUsedBWTRCount) {
		this.errorUsedBWTRCount = errorUsedBWTRCount;
	}

	public int getErrorUsedBWTSCount() {
		return errorUsedBWTSCount;
	}

	public void setErrorUsedBWTSCount(int errorUsedBWTSCount) {
		this.errorUsedBWTSCount = errorUsedBWTSCount;
	}

	public int getErrorUsedBWURCount() {
		return errorUsedBWURCount;
	}

	public void setErrorUsedBWURCount(int errorUsedBWURCount) {
		this.errorUsedBWURCount = errorUsedBWURCount;
	}

	public int getErrorUsedBWIGCount() {
		return errorUsedBWIGCount;
	}

	public void setErrorUsedBWIGCount(int errorUsedBWIGCount) {
		this.errorUsedBWIGCount = errorUsedBWIGCount;
	}

	public int getErrorUsedCDATCount() {
		return errorUsedCDATCount;
	}

	public void setErrorUsedCDATCount(int errorUsedCDATCount) {
		this.errorUsedCDATCount = errorUsedCDATCount;
	}

	public int getErrorUsedTABUCount() {
		return errorUsedTABUCount;
	}

	public void setErrorUsedTABUCount(int errorUsedTABUCount) {
		this.errorUsedTABUCount = errorUsedTABUCount;
	}

	public int getErrorUsedPROGCount() {
		return errorUsedPROGCount;
	}

	public void setErrorUsedPROGCount(int errorUsedPROGCount) {
		this.errorUsedPROGCount = errorUsedPROGCount;
	}

	public int getErrorUsedSSFOCount() {
		return errorUsedSSFOCount;
	}

	public void setErrorUsedSSFOCount(int errorUsedSSFOCount) {
		this.errorUsedSSFOCount = errorUsedSSFOCount;
	}

	public int getErrorUsedSFPFCount() {
		return errorUsedSFPFCount;
	}

	public void setErrorUsedSFPFCount(int errorUsedSFPFCount) {
		this.errorUsedSFPFCount = errorUsedSFPFCount;
	}

	public int getErrorUsedSFPICount() {
		return errorUsedSFPICount;
	}

	public void setErrorUsedSFPICount(int errorUsedSFPICount) {
		this.errorUsedSFPICount = errorUsedSFPICount;
	}

	public int getErrorUsedFUGRCount() {
		return errorUsedFUGRCount;
	}

	public void setErrorUsedFUGRCount(int errorUsedFUGRCount) {
		this.errorUsedFUGRCount = errorUsedFUGRCount;
	}

	public int getErrorUsedENHOCount() {
		return errorUsedENHOCount;
	}

	public void setErrorUsedENHOCount(int errorUsedENHOCount) {
		this.errorUsedENHOCount = errorUsedENHOCount;
	}

	public int getErrorUsedENHSCount() {
		return errorUsedENHSCount;
	}

	public void setErrorUsedENHSCount(int errorUsedENHSCount) {
		this.errorUsedENHSCount = errorUsedENHSCount;
	}

	public int getErrorUsedENHCCount() {
		return errorUsedENHCCount;
	}

	public void setErrorUsedENHCCount(int errorUsedENHCCount) {
		this.errorUsedENHCCount = errorUsedENHCCount;
	}

	public int getErrorUsedLSMWCount() {
		return errorUsedLSMWCount;
	}

	public void setErrorUsedLSMWCount(int errorUsedLSMWCount) {
		this.errorUsedLSMWCount = errorUsedLSMWCount;
	}

	public int getErrorUsedUSRECount() {
		return errorUsedUSRECount;
	}

	public void setErrorUsedUSRECount(int errorUsedUSRECount) {
		this.errorUsedUSRECount = errorUsedUSRECount;
	}

	public int getErrorUsedUSRRCount() {
		return errorUsedUSRRCount;
	}

	public void setErrorUsedUSRRCount(int errorUsedUSRRCount) {
		this.errorUsedUSRRCount = errorUsedUSRRCount;
	}

	public int getErrorUsedWDYNCount() {
		return errorUsedWDYNCount;
	}

	public void setErrorUsedWDYNCount(int errorUsedWDYNCount) {
		this.errorUsedWDYNCount = errorUsedWDYNCount;
	}

	public int getErrorUsedREPTCount() {
		return errorUsedREPTCount;
	}

	public void setErrorUsedREPTCount(int errorUsedREPTCount) {
		this.errorUsedREPTCount = errorUsedREPTCount;
	}

	public int getErrorUsedVIEWCount() {
		return errorUsedVIEWCount;
	}

	public void setErrorUsedVIEWCount(int errorUsedVIEWCount) {
		this.errorUsedVIEWCount = errorUsedVIEWCount;
	}

	public int getErrorUsedINDXCount() {
		return errorUsedINDXCount;
	}

	public void setErrorUsedINDXCount(int errorUsedINDXCount) {
		this.errorUsedINDXCount = errorUsedINDXCount;
	}

	public int getErrorUsedDTELCount() {
		return errorUsedDTELCount;
	}

	public void setErrorUsedDTELCount(int errorUsedDTELCount) {
		this.errorUsedDTELCount = errorUsedDTELCount;
	}
	
	public int getErrorUsedFUGSCount() {
		return errorUsedFUGSCount;
	}

	public void setErrorUsedFUGSCount(int errorUsedFUGSCount) {
		this.errorUsedFUGSCount = errorUsedFUGSCount;
	}
	
	public int getErrorUsedAQQUCount() {
		return errorUsedAQQUCount;
	}

	public void setErrorUsedAQQUCount(int errorUsedAQQUCount) {
		this.errorUsedAQQUCount = errorUsedAQQUCount;
	}

	// S4 - Distinct Counts Based on Remediation Category and Issue Category
	public int getDistinctManIssueCatCustomCodeAdaption() {
		return distinctManIssueCatCustomCodeAdaption;
	}

	public void setDistinctManIssueCatCustomCodeAdaption(int distinctManIssueCatCustomCodeAdaption) {
		this.distinctManIssueCatCustomCodeAdaption = distinctManIssueCatCustomCodeAdaption;
	}

	public int getDistinctManIssueCatDataEleLenExt() {
		return distinctManIssueCatDataEleLenExt;
	}

	public void setDistinctManIssueCatDataEleLenExt(int distinctManIssueCatDataEleLenExt) {
		this.distinctManIssueCatDataEleLenExt = distinctManIssueCatDataEleLenExt;
	}

	public int getDistinctManIssueCatNewDataModel() {
		return distinctManIssueCatNewDataModel;
	}

	public void setDistinctManIssueCatNewDataModel(int distinctManIssueCatNewDataModel) {
		this.distinctManIssueCatNewDataModel = distinctManIssueCatNewDataModel;
	}

	public int getDistinctManIssueCatNewS4Func() {
		return distinctManIssueCatNewS4Func;
	}

	public void setDistinctManIssueCatNewS4Func(int distinctManIssueCatNewS4Func) {
		this.distinctManIssueCatNewS4Func = distinctManIssueCatNewS4Func;
	}

	public int getDistinctManIssueCatRemOfOrpObjects() {
		return distinctManIssueCatRemOfOrpObjects;
	}

	public void setDistinctManIssueCatRemOfOrpObjects(int distinctManIssueCatRemOfOrpObjects) {
		this.distinctManIssueCatRemOfOrpObjects = distinctManIssueCatRemOfOrpObjects;
	}

	public int getDistinctManIssueCatRetFunc() {
		return distinctManIssueCatRetFunc;
	}

	public void setDistinctManIssueCatRetFunc(int distinctManIssueCatRetFunc) {
		this.distinctManIssueCatRetFunc = distinctManIssueCatRetFunc;
	}

	public int getDistinctManIssueCatEliminateOFStatusTables() {
		return distinctManIssueCatEliminateOFStatusTables;
	}

	public void setDistinctManIssueCatEliminateOFStatusTables(int distinctManIssueCatEliminateOFStatusTables) {
		this.distinctManIssueCatEliminateOFStatusTables = distinctManIssueCatEliminateOFStatusTables;
	}

	public int getDistinctManIssueCatReplaceNewFunc() {
		return distinctManIssueCatReplaceNewFunc;
	}

	public void setDistinctManIssueCatReplaceNewFunc(int distinctManIssueCatReplaceNewFunc) {
		this.distinctManIssueCatReplaceNewFunc = distinctManIssueCatReplaceNewFunc;
	}

	public int getDistinctManIssueCatNewTransaction() {
		return distinctManIssueCatNewTransaction;
	}

	public void setDistinctManIssueCatNewTransaction(int distinctManIssueCatNewTransaction) {
		this.distinctManIssueCatNewTransaction = distinctManIssueCatNewTransaction;
	}

	public int getDistinctOptIssueCatCustomCodeAdaption() {
		return distinctOptIssueCatCustomCodeAdaption;
	}

	public void setDistinctOptIssueCatCustomCodeAdaption(int distinctOptIssueCatCustomCodeAdaption) {
		this.distinctOptIssueCatCustomCodeAdaption = distinctOptIssueCatCustomCodeAdaption;
	}

	public int getDistinctOptIssueCatDataEleLenExt() {
		return distinctOptIssueCatDataEleLenExt;
	}

	public void setDistinctOptIssueCatDataEleLenExt(int distinctOptIssueCatDataEleLenExt) {
		this.distinctOptIssueCatDataEleLenExt = distinctOptIssueCatDataEleLenExt;
	}

	public int getDistinctOptIssueCatNewDataModel() {
		return distinctOptIssueCatNewDataModel;
	}

	public void setDistinctOptIssueCatNewDataModel(int distinctOptIssueCatNewDataModel) {
		this.distinctOptIssueCatNewDataModel = distinctOptIssueCatNewDataModel;
	}

	public int getDistinctOptIssueCatNewS4Func() {
		return distinctOptIssueCatNewS4Func;
	}

	public void setDistinctOptIssueCatNewS4Func(int distinctOptIssueCatNewS4Func) {
		this.distinctOptIssueCatNewS4Func = distinctOptIssueCatNewS4Func;
	}

	public int getDistinctOptIssueCatRemOfOrpObjects() {
		return distinctOptIssueCatRemOfOrpObjects;
	}

	public void setDistinctOptIssueCatRemOfOrpObjects(int distinctOptIssueCatRemOfOrpObjects) {
		this.distinctOptIssueCatRemOfOrpObjects = distinctOptIssueCatRemOfOrpObjects;
	}

	public int getDistinctOptIssueCatRetFunc() {
		return distinctOptIssueCatRetFunc;
	}

	public void setDistinctOptIssueCatRetFunc(int distinctOptIssueCatRetFunc) {
		this.distinctOptIssueCatRetFunc = distinctOptIssueCatRetFunc;
	}

	public int getDistinctOptIssueCatEliminateOFStatusTables() {
		return distinctOptIssueCatEliminateOFStatusTables;
	}

	public void setDistinctOptIssueCatEliminateOFStatusTables(int distinctOptIssueCatEliminateOFStatusTables) {
		this.distinctOptIssueCatEliminateOFStatusTables = distinctOptIssueCatEliminateOFStatusTables;
	}

	public int getDistinctOptIssueCatReplaceNewFunc() {
		return distinctOptIssueCatReplaceNewFunc;
	}

	public void setDistinctOptIssueCatReplaceNewFunc(int distinctOptIssueCatReplaceNewFunc) {
		this.distinctOptIssueCatReplaceNewFunc = distinctOptIssueCatReplaceNewFunc;
	}

	public int getDistinctOptIssueCatNewTransaction() {
		return distinctOptIssueCatNewTransaction;
	}

	public void setDistinctOptIssueCatNewTransaction(int distinctOptIssueCatNewTransaction) {
		this.distinctOptIssueCatNewTransaction = distinctOptIssueCatNewTransaction;
	}
	
	// S4 - Error Counts Based on Remediation Category and Issue Category
	public int getErrorManIssueCatCustomCodeAdaption() {
		return errorManIssueCatCustomCodeAdaption;
	}

	public void setErrorManIssueCatCustomCodeAdaption(int errorManIssueCatCustomCodeAdaption) {
		this.errorManIssueCatCustomCodeAdaption = errorManIssueCatCustomCodeAdaption;
	}

	public int getErrorManIssueCatDataEleLenExt() {
		return errorManIssueCatDataEleLenExt;
	}

	public void setErrorManIssueCatDataEleLenExt(int errorManIssueCatDataEleLenExt) {
		this.errorManIssueCatDataEleLenExt = errorManIssueCatDataEleLenExt;
	}

	public int getErrorManIssueCatNewDataModel() {
		return errorManIssueCatNewDataModel;
	}

	public void setErrorManIssueCatNewDataModel(int errorManIssueCatNewDataModel) {
		this.errorManIssueCatNewDataModel = errorManIssueCatNewDataModel;
	}

	public int getErrorManIssueCatNewS4Func() {
		return errorManIssueCatNewS4Func;
	}

	public void setErrorManIssueCatNewS4Func(int errorManIssueCatNewS4Func) {
		this.errorManIssueCatNewS4Func = errorManIssueCatNewS4Func;
	}

	public int getErrorManIssueCatRemOfOrpObjects() {
		return errorManIssueCatRemOfOrpObjects;
	}

	public void setErrorManIssueCatRemOfOrpObjects(int errorManIssueCatRemOfOrpObjects) {
		this.errorManIssueCatRemOfOrpObjects = errorManIssueCatRemOfOrpObjects;
	}

	public int getErrorManIssueCatRetFunc() {
		return errorManIssueCatRetFunc;
	}

	public void setErrorManIssueCatRetFunc(int errorManIssueCatRetFunc) {
		this.errorManIssueCatRetFunc = errorManIssueCatRetFunc;
	}

	public int getErrorManIssueCatEliminateOFStatusTables() {
		return errorManIssueCatEliminateOFStatusTables;
	}

	public void setErrorManIssueCatEliminateOFStatusTables(int errorManIssueCatEliminateOFStatusTables) {
		this.errorManIssueCatEliminateOFStatusTables = errorManIssueCatEliminateOFStatusTables;
	}

	public int getErrorManIssueCatReplaceNewFunc() {
		return errorManIssueCatReplaceNewFunc;
	}

	public void setErrorManIssueCatReplaceNewFunc(int errorManIssueCatReplaceNewFunc) {
		this.errorManIssueCatReplaceNewFunc = errorManIssueCatReplaceNewFunc;
	}

	public int getErrorManIssueCatNewTransaction() {
		return errorManIssueCatNewTransaction;
	}

	public void setErrorManIssueCatNewTransaction(int errorManIssueCatNewTransaction) {
		this.errorManIssueCatNewTransaction = errorManIssueCatNewTransaction;
	}

	public int getErrorOptIssueCatCustomCodeAdaption() {
		return errorOptIssueCatCustomCodeAdaption;
	}

	public void setErrorOptIssueCatCustomCodeAdaption(int errorOptIssueCatCustomCodeAdaption) {
		this.errorOptIssueCatCustomCodeAdaption = errorOptIssueCatCustomCodeAdaption;
	}

	public int getErrorOptIssueCatDataEleLenExt() {
		return errorOptIssueCatDataEleLenExt;
	}

	public void setErrorOptIssueCatDataEleLenExt(int errorOptIssueCatDataEleLenExt) {
		this.errorOptIssueCatDataEleLenExt = errorOptIssueCatDataEleLenExt;
	}

	public int getErrorOptIssueCatNewDataModel() {
		return errorOptIssueCatNewDataModel;
	}

	public void setErrorOptIssueCatNewDataModel(int errorOptIssueCatNewDataModel) {
		this.errorOptIssueCatNewDataModel = errorOptIssueCatNewDataModel;
	}

	public int getErrorOptIssueCatNewS4Func() {
		return errorOptIssueCatNewS4Func;
	}

	public void setErrorOptIssueCatNewS4Func(int errorOptIssueCatNewS4Func) {
		this.errorOptIssueCatNewS4Func = errorOptIssueCatNewS4Func;
	}

	public int getErrorOptIssueCatRemOfOrpObjects() {
		return errorOptIssueCatRemOfOrpObjects;
	}

	public void setErrorOptIssueCatRemOfOrpObjects(int errorOptIssueCatRemOfOrpObjects) {
		this.errorOptIssueCatRemOfOrpObjects = errorOptIssueCatRemOfOrpObjects;
	}

	public int getErrorOptIssueCatRetFunc() {
		return errorOptIssueCatRetFunc;
	}

	public void setErrorOptIssueCatRetFunc(int errorOptIssueCatRetFunc) {
		this.errorOptIssueCatRetFunc = errorOptIssueCatRetFunc;
	}

	public int getErrorOptIssueCatEliminateOFStatusTables() {
		return errorOptIssueCatEliminateOFStatusTables;
	}

	public void setErrorOptIssueCatEliminateOFStatusTables(int errorOptIssueCatEliminateOFStatusTables) {
		this.errorOptIssueCatEliminateOFStatusTables = errorOptIssueCatEliminateOFStatusTables;
	}

	public int getErrorOptIssueCatReplaceNewFunc() {
		return errorOptIssueCatReplaceNewFunc;
	}

	public void setErrorOptIssueCatReplaceNewFunc(int errorOptIssueCatReplaceNewFunc) {
		this.errorOptIssueCatReplaceNewFunc = errorOptIssueCatReplaceNewFunc;
	}

	public int getErrorOptIssueCatNewTransaction() {
		return errorOptIssueCatNewTransaction;
	}

	public void setErrorOptIssueCatNewTransaction(int errorOptIssueCatNewTransaction) {
		this.errorOptIssueCatNewTransaction = errorOptIssueCatNewTransaction;
	}
	
	// S4 - Distinct Counts Based on Issue Category
	public int getDistinctIssueCatCustomCodeAdaption() {
		return distinctIssueCatCustomCodeAdaption;
	}

	public void setDistinctIssueCatCustomCodeAdaption(int distinctIssueCatCustomCodeAdaption) {
		this.distinctIssueCatCustomCodeAdaption = distinctIssueCatCustomCodeAdaption;
	}

	public int getDistinctIssueCatDataEleLenExt() {
		return distinctIssueCatDataEleLenExt;
	}

	public void setDistinctIssueCatDataEleLenExt(int distinctIssueCatDataEleLenExt) {
		this.distinctIssueCatDataEleLenExt = distinctIssueCatDataEleLenExt;
	}

	public int getDistinctIssueCatNewDataModel() {
		return distinctIssueCatNewDataModel;
	}

	public void setDistinctIssueCatNewDataModel(int distinctIssueCatNewDataModel) {
		this.distinctIssueCatNewDataModel = distinctIssueCatNewDataModel;
	}

	public int getDistinctIssueCatNewS4Func() {
		return distinctIssueCatNewS4Func;
	}

	public void setDistinctIssueCatNewS4Func(int distinctIssueCatNewS4Func) {
		this.distinctIssueCatNewS4Func = distinctIssueCatNewS4Func;
	}

	public int getDistinctIssueCatRemOfOrpObjects() {
		return distinctIssueCatRemOfOrpObjects;
	}

	public void setDistinctIssueCatRemOfOrpObjects(int distinctIssueCatRemOfOrpObjects) {
		this.distinctIssueCatRemOfOrpObjects = distinctIssueCatRemOfOrpObjects;
	}

	public int getDistinctIssueCatRetFunc() {
		return distinctIssueCatRetFunc;
	}

	public void setDistinctIssueCatRetFunc(int distinctIssueCatRetFunc) {
		this.distinctIssueCatRetFunc = distinctIssueCatRetFunc;
	}

	public int getDistinctIssueCatEliminateOFStatusTables() {
		return distinctIssueCatEliminateOFStatusTables;
	}

	public void setDistinctIssueCatEliminateOFStatusTables(int distinctIssueCatEliminateOFStatusTables) {
		this.distinctIssueCatEliminateOFStatusTables = distinctIssueCatEliminateOFStatusTables;
	}

	public int getDistinctIssueCatReplaceNewFunc() {
		return distinctIssueCatReplaceNewFunc;
	}

	public void setDistinctIssueCatReplaceNewFunc(int distinctIssueCatReplaceNewFunc) {
		this.distinctIssueCatReplaceNewFunc = distinctIssueCatReplaceNewFunc;
	}

	public int getDistinctIssueCatNewTransaction() {
		return distinctIssueCatNewTransaction;
	}

	public void setDistinctIssueCatNewTransaction(int distinctIssueCatNewTransaction) {
		this.distinctIssueCatNewTransaction = distinctIssueCatNewTransaction;
	}

	// S4 - Distinct Used Counts Based on Issue Category
	public int getDistinctUsedIssueCatCustomCodeAdaption() {
		return distinctUsedIssueCatCustomCodeAdaption;
	}

	public void setDistinctUsedIssueCatCustomCodeAdaption(int distinctUsedIssueCatCustomCodeAdaption) {
		this.distinctUsedIssueCatCustomCodeAdaption = distinctUsedIssueCatCustomCodeAdaption;
	}

	public int getDistinctUsedIssueCatDataEleLenExt() {
		return distinctUsedIssueCatDataEleLenExt;
	}

	public void setDistinctUsedIssueCatDataEleLenExt(int distinctUsedIssueCatDataEleLenExt) {
		this.distinctUsedIssueCatDataEleLenExt = distinctUsedIssueCatDataEleLenExt;
	}

	public int getDistinctUsedIssueCatNewDataModel() {
		return distinctUsedIssueCatNewDataModel;
	}

	public void setDistinctUsedIssueCatNewDataModel(int distinctUsedIssueCatNewDataModel) {
		this.distinctUsedIssueCatNewDataModel = distinctUsedIssueCatNewDataModel;
	}

	public int getDistinctUsedIssueCatNewS4Func() {
		return distinctUsedIssueCatNewS4Func;
	}

	public void setDistinctUsedIssueCatNewS4Func(int distinctUsedIssueCatNewS4Func) {
		this.distinctUsedIssueCatNewS4Func = distinctUsedIssueCatNewS4Func;
	}

	public int getDistinctUsedIssueCatRemOfOrpObjects() {
		return distinctUsedIssueCatRemOfOrpObjects;
	}

	public void setDistinctUsedIssueCatRemOfOrpObjects(int distinctUsedIssueCatRemOfOrpObjects) {
		this.distinctUsedIssueCatRemOfOrpObjects = distinctUsedIssueCatRemOfOrpObjects;
	}

	public int getDistinctUsedIssueCatRetFunc() {
		return distinctUsedIssueCatRetFunc;
	}

	public void setDistinctUsedIssueCatRetFunc(int distinctUsedIssueCatRetFunc) {
		this.distinctUsedIssueCatRetFunc = distinctUsedIssueCatRetFunc;
	}

	public int getDistinctUsedIssueCatEliminateOFStatusTables() {
		return distinctUsedIssueCatEliminateOFStatusTables;
	}

	public void setDistinctUsedIssueCatEliminateOFStatusTables(int distinctUsedIssueCatEliminateOFStatusTables) {
		this.distinctUsedIssueCatEliminateOFStatusTables = distinctUsedIssueCatEliminateOFStatusTables;
	}

	public int getDistinctUsedIssueCatReplaceNewFunc() {
		return distinctUsedIssueCatReplaceNewFunc;
	}

	public void setDistinctUsedIssueCatReplaceNewFunc(int distinctUsedIssueCatReplaceNewFunc) {
		this.distinctUsedIssueCatReplaceNewFunc = distinctUsedIssueCatReplaceNewFunc;
	}

	public int getDistinctUsedIssueCatNewTransaction() {
		return distinctUsedIssueCatNewTransaction;
	}

	public void setDistinctUsedIssueCatNewTransaction(int distinctUsedIssueCatNewTransaction) {
		this.distinctUsedIssueCatNewTransaction = distinctUsedIssueCatNewTransaction;
	} 
	
	// S4 - Error Counts Based on Issue Category
	public int getErrorIssueCatCustomCodeAdaption() {
		return errorIssueCatCustomCodeAdaption;
	}

	public void setErrorIssueCatCustomCodeAdaption(int errorIssueCatCustomCodeAdaption) {
		this.errorIssueCatCustomCodeAdaption = errorIssueCatCustomCodeAdaption;
	}

	public int getErrorIssueCatDataEleLenExt() {
		return errorIssueCatDataEleLenExt;
	}

	public void setErrorIssueCatDataEleLenExt(int errorIssueCatDataEleLenExt) {
		this.errorIssueCatDataEleLenExt = errorIssueCatDataEleLenExt;
	}

	public int getErrorIssueCatNewDataModel() {
		return errorIssueCatNewDataModel;
	}

	public void setErrorIssueCatNewDataModel(int errorIssueCatNewDataModel) {
		this.errorIssueCatNewDataModel = errorIssueCatNewDataModel;
	}

	public int getErrorIssueCatNewS4Func() {
		return errorIssueCatNewS4Func;
	}

	public void setErrorIssueCatNewS4Func(int errorIssueCatNewS4Func) {
		this.errorIssueCatNewS4Func = errorIssueCatNewS4Func;
	}

	public int getErrorIssueCatRemOfOrpObjects() {
		return errorIssueCatRemOfOrpObjects;
	}

	public void setErrorIssueCatRemOfOrpObjects(int errorIssueCatRemOfOrpObjects) {
		this.errorIssueCatRemOfOrpObjects = errorIssueCatRemOfOrpObjects;
	}

	public int getErrorIssueCatRetFunc() {
		return errorIssueCatRetFunc;
	}

	public void setErrorIssueCatRetFunc(int errorIssueCatRetFunc) {
		this.errorIssueCatRetFunc = errorIssueCatRetFunc;
	}

	public int getErrorIssueCatEliminateOFStatusTables() {
		return errorIssueCatEliminateOFStatusTables;
	}

	public void setErrorIssueCatEliminateOFStatusTables(int errorIssueCatEliminateOFStatusTables) {
		this.errorIssueCatEliminateOFStatusTables = errorIssueCatEliminateOFStatusTables;
	}

	public int getErrorIssueCatReplaceNewFunc() {
		return errorIssueCatReplaceNewFunc;
	}

	public void setErrorIssueCatReplaceNewFunc(int errorIssueCatReplaceNewFunc) {
		this.errorIssueCatReplaceNewFunc = errorIssueCatReplaceNewFunc;
	}

	public int getErrorIssueCatNewTransaction() {
		return errorIssueCatNewTransaction;
	}

	public void setErrorIssueCatNewTransaction(int errorIssueCatNewTransaction) {
		this.errorIssueCatNewTransaction = errorIssueCatNewTransaction;
	}

	// S4 - Error Used Counts Based on Issue Category
	public int getErrorUsedIssueCatCustomCodeAdaption() {
		return errorUsedIssueCatCustomCodeAdaption;
	}

	public void setErrorUsedIssueCatCustomCodeAdaption(int errorUsedIssueCatCustomCodeAdaption) {
		this.errorUsedIssueCatCustomCodeAdaption = errorUsedIssueCatCustomCodeAdaption;
	}

	public int getErrorUsedIssueCatDataEleLenExt() {
		return errorUsedIssueCatDataEleLenExt;
	}

	public void setErrorUsedIssueCatDataEleLenExt(int errorUsedIssueCatDataEleLenExt) {
		this.errorUsedIssueCatDataEleLenExt = errorUsedIssueCatDataEleLenExt;
	}

	public int getErrorUsedIssueCatNewDataModel() {
		return errorUsedIssueCatNewDataModel;
	}

	public void setErrorUsedIssueCatNewDataModel(int errorUsedIssueCatNewDataModel) {
		this.errorUsedIssueCatNewDataModel = errorUsedIssueCatNewDataModel;
	}

	public int getErrorUsedIssueCatNewS4Func() {
		return errorUsedIssueCatNewS4Func;
	}

	public void setErrorUsedIssueCatNewS4Func(int errorUsedIssueCatNewS4Func) {
		this.errorUsedIssueCatNewS4Func = errorUsedIssueCatNewS4Func;
	}

	public int getErrorUsedIssueCatRemOfOrpObjects() {
		return errorUsedIssueCatRemOfOrpObjects;
	}

	public void setErrorUsedIssueCatRemOfOrpObjects(int errorUsedIssueCatRemOfOrpObjects) {
		this.errorUsedIssueCatRemOfOrpObjects = errorUsedIssueCatRemOfOrpObjects;
	}

	public int getErrorUsedIssueCatRetFunc() {
		return errorUsedIssueCatRetFunc;
	}

	public void setErrorUsedIssueCatRetFunc(int errorUsedIssueCatRetFunc) {
		this.errorUsedIssueCatRetFunc = errorUsedIssueCatRetFunc;
	}

	public int getErrorUsedIssueCatEliminateOFStatusTables() {
		return errorUsedIssueCatEliminateOFStatusTables;
	}

	public void setErrorUsedIssueCatEliminateOFStatusTables(int errorUsedIssueCatEliminateOFStatusTables) {
		this.errorUsedIssueCatEliminateOFStatusTables = errorUsedIssueCatEliminateOFStatusTables;
	}

	public int getErrorUsedIssueCatReplaceNewFunc() {
		return errorUsedIssueCatReplaceNewFunc;
	}

	public void setErrorUsedIssueCatReplaceNewFunc(int errorUsedIssueCatReplaceNewFunc) {
		this.errorUsedIssueCatReplaceNewFunc = errorUsedIssueCatReplaceNewFunc;
	}

	public int getErrorUsedIssueCatNewTransaction() {
		return errorUsedIssueCatNewTransaction;
	}

	public void setErrorUsedIssueCatNewTransaction(int errorUsedIssueCatNewTransaction) {
		this.errorUsedIssueCatNewTransaction = errorUsedIssueCatNewTransaction;
	}

	// External Namespaces Counts - Inventory List
	public int getDistinctExtNamespaceInvCount() {
		return distinctExtNamespaceInvCount;
	}

	public void setDistinctExtNamespaceInvCount(int distinctExtNamespaceInvCount) {
		this.distinctExtNamespaceInvCount = distinctExtNamespaceInvCount;
	}

	public int getDistinctExtNamespaceInvUsedCount() {
		return distinctExtNamespaceInvUsedCount;
	}

	public void setDistinctExtNamespaceInvUsedCount(int distinctExtNamespaceInvUsedCount) {
		this.distinctExtNamespaceInvUsedCount = distinctExtNamespaceInvUsedCount;
	}

	public float getDistinctExtNamespaceInvUsedPerc() {
		return distinctExtNamespaceInvUsedPerc;
	}

	public void setDistinctExtNamespaceInvUsedPerc(float distinctExtNamespaceInvUsedPerc) {
		this.distinctExtNamespaceInvUsedPerc = distinctExtNamespaceInvUsedPerc;
	}

	// External Namespaces Counts - HANA/S4
	public int getDistinctExtNamespaceImpObjCount() {
		return distinctExtNamespaceImpObjCount;
	}

	public void setDistinctExtNamespaceImpObjCount(int distinctExtNamespaceImpObjCount) {
		this.distinctExtNamespaceImpObjCount = distinctExtNamespaceImpObjCount;
	}

	public int getDistinctExtNamespaceUsedImpObjCount() {
		return distinctExtNamespaceUsedImpObjCount;
	}

	public void setDistinctExtNamespaceUsedImpObjCount(int distinctExtNamespaceUsedImpObjCount) {
		this.distinctExtNamespaceUsedImpObjCount = distinctExtNamespaceUsedImpObjCount;
	}

	public int getDistinctExtNamespaceMandCount() {
		return distinctExtNamespaceMandCount;
	}

	public void setDistinctExtNamespaceMandCount(int distinctExtNamespaceMandCount) {
		this.distinctExtNamespaceMandCount = distinctExtNamespaceMandCount;
	}

	public int getDistinctExtNamespaceMandUsedCount() {
		return distinctExtNamespaceMandUsedCount;
	}

	public void setDistinctExtNamespaceMandUsedCount(int distinctExtNamespaceMandUsedCount) {
		this.distinctExtNamespaceMandUsedCount = distinctExtNamespaceMandUsedCount;
	}

	// External Namespaces Counts - Common HANA and S4
	public int getDistinctExtNamespaceCommonImpObjCountHANAS4() {
		return distinctExtNamespaceCommonImpObjCountHANAS4;
	}

	public void setDistinctExtNamespaceCommonImpObjCountHANAS4(int distinctExtNamespaceCommonImpObjCountHANAS4) {
		this.distinctExtNamespaceCommonImpObjCountHANAS4 = distinctExtNamespaceCommonImpObjCountHANAS4;
	}

	public int getDistinctExtNamespaceCommonUsedImpObjCountHANAS4() {
		return distinctExtNamespaceCommonUsedImpObjCountHANAS4;
	}

	public void setDistinctExtNamespaceCommonUsedImpObjCountHANAS4(int distinctExtNamespaceCommonUsedImpObjCountHANAS4) {
		this.distinctExtNamespaceCommonUsedImpObjCountHANAS4 = distinctExtNamespaceCommonUsedImpObjCountHANAS4;
	}

	public int getDistinctExtNamespaceCommonMandCountHANAS4() {
		return distinctExtNamespaceCommonMandCountHANAS4;
	}

	public void setDistinctExtNamespaceCommonMandCountHANAS4(int distinctExtNamespaceCommonMandCountHANAS4) {
		this.distinctExtNamespaceCommonMandCountHANAS4 = distinctExtNamespaceCommonMandCountHANAS4;
	}

	public int getDistinctExtNamespaceCommonMandUsedCountHANAS4() {
		return distinctExtNamespaceCommonMandUsedCountHANAS4;
	}

	public void setDistinctExtNamespaceCommonMandUsedCountHANAS4(int distinctExtNamespaceCommonMandUsedCountHANAS4) {
		this.distinctExtNamespaceCommonMandUsedCountHANAS4 = distinctExtNamespaceCommonMandUsedCountHANAS4;
	}

	// External Namespaces Counts - AUCT
	public int getErrorExtNamespacePreCheckErrorCount() {
		return errorExtNamespacePreCheckErrorCount;
	}

	public void setErrorExtNamespacePreCheckErrorCount(int errorExtNamespacePreCheckErrorCount) {
		this.errorExtNamespacePreCheckErrorCount = errorExtNamespacePreCheckErrorCount;
	}

	public int getErrorExtNamespaceUnicodeErrorCount() {
		return errorExtNamespaceUnicodeErrorCount;
	}

	public void setErrorExtNamespaceUnicodeErrorCount(int errorExtNamespaceUnicodeErrorCount) {
		this.errorExtNamespaceUnicodeErrorCount = errorExtNamespaceUnicodeErrorCount;
	}

	public int getErrorExtNamespaceSyntaxErrorCount() {
		return errorExtNamespaceSyntaxErrorCount;
	}

	public void setErrorExtNamespaceSyntaxErrorCount(int errorExtNamespaceSyntaxErrorCount) {
		this.errorExtNamespaceSyntaxErrorCount = errorExtNamespaceSyntaxErrorCount;
	}
}
