package com.act.master;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "IRPATScope_RM_Scenarios")
public class IRPATScopeRMScenarios {
	private int id;
	private long requestId;
	private String module;
	private String process;
	private int scenarioCount;
	private int toBeUpdatedNoCount;
	private int toBeUpdatedYesCount;
	private int testScriptsAvailNoCount;
	private int testScriptsAvailYesCount;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Column(name = "Request_Id")
	public long getRequestId() {
		return requestId;
	}

	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}

	@Column(name = "Process")
	public String getProcess() {
		return process;
	}

	public void setProcess(String process) {
		this.process = process;
	}

	@Column(name = "Module")
	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	@Column(name = "Scenario_Count")
	public int getScenarioCount() {
		return scenarioCount;
	}

	public void setScenarioCount(int scenarioCount) {
		this.scenarioCount = scenarioCount;
	}

	@Column(name = "ToBeUpdated_No_Count")
	public int getToBeUpdatedNoCount() {
		return toBeUpdatedNoCount;
	}

	public void setToBeUpdatedNoCount(int toBeUpdatedNoCount) {
		this.toBeUpdatedNoCount = toBeUpdatedNoCount;
	}

	@Column(name = "ToBeUpdated_Yes_Count")
	public int getToBeUpdatedYesCount() {
		return toBeUpdatedYesCount;
	}

	public void setToBeUpdatedYesCount(int toBeUpdatedYesCount) {
		this.toBeUpdatedYesCount = toBeUpdatedYesCount;
	}

	@Column(name = "TestScriptAvail_No_Count")
	public int getTestScriptsAvailNoCount() {
		return testScriptsAvailNoCount;
	}

	public void setTestScriptsAvailNoCount(int testScriptsAvailNoCount) {
		this.testScriptsAvailNoCount = testScriptsAvailNoCount;
	}

	@Column(name = "TestScriptAvail_Yes_Count")
	public int getTestScriptsAvailYesCount() {
		return testScriptsAvailYesCount;
	}

	public void setTestScriptsAvailYesCount(int testScriptsAvailYesCount) {
		this.testScriptsAvailYesCount = testScriptsAvailYesCount;
	}
}
