package com.act.master;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Estimates_Request_Master")
public class ProcessedEstimates {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Integer Id;
	
	@Column(name = "REQUEST_ID", nullable = false)
	private long requestID;
	
	@Column(name = "SCOPE", nullable = false)
	private String	scope;
	
	
	/* Mandatory Manual and Mandatory Automation Counts */	
	@Column(name = "DMACLAS_COUNT", columnDefinition = "int default 0")
	private Integer	dmaCLAS_Count;
	
	@Column(name = "DMAPROG_COUNT", columnDefinition = "int default 0")
	private Integer	dmaPROG_Count;
	
	@Column(name = "DMAFORM_COUNT", columnDefinition = "int default 0")
	private Integer	dmaFORM_Count;
	
	@Column(name = "DMAFUGR_COUNT", columnDefinition = "int default 0")
	private Integer	dmaFUGR_Count;
	
	@Column(name = "DMAENH_COUNT", columnDefinition = "int default 0")
	private Integer	dmaENH_Count;
	
	@Column(name = "DMALSMW_COUNT", columnDefinition = "int default 0")
	private Integer	dmaLSMW_Count;
	
	@Column(name = "DMAUSEREXIT_COUNT", columnDefinition = "int default 0")
	private Integer	dmaUSEREXIT_Count;
	
	@Column(name = "DMAWDYN_COUNT", columnDefinition = "int default 0")
	private Integer	dmaWDYN_Count;
	
	@Column(name = "DMAFUGS_COUNT", columnDefinition = "int default 0")
	private Integer	dmaFUGS_Count;
	
	@Column(name = "DMACLAS_COUNT_N_HIGH", columnDefinition = "int default 0")
	private Integer	dmaCLAS_Count_N_High;
	
	@Column(name = "DMACLAS_COUNT_N_MEDIUM", columnDefinition = "int default 0")
	private Integer	dmaCLAS_Count_N_Medium;
	
	@Column(name = "DMACLAS_COUNT_N_LOW", columnDefinition = "int default 0")
	private Integer	dmaCLAS_Count_N_Low;
	
	@Column(name = "DMAPROG_COUNT_N_HIGH", columnDefinition = "int default 0")
	private Integer	dmaPROG_Count_N_High;
	
	@Column(name = "DMAPROG_COUNT_N_MEDIUM", columnDefinition = "int default 0")
	private Integer	dmaPROG_Count_N_Medium;
	
	@Column(name = "DMAPROG_COUNT_N_LOW", columnDefinition = "int default 0")
	private Integer	dmaPROG_Count_N_Low;
	
	@Column(name = "DMAFORM_COUNT_N_HIGH", columnDefinition = "int default 0")
	private Integer	dmaFORM_Count_N_High;
	
	@Column(name = "DMAFORM_COUNT_N_MEDIUM", columnDefinition = "int default 0")
	private Integer	dmaFORM_Count_N_Medium;
	
	@Column(name = "DMAFORM_COUNT_N_LOW", columnDefinition = "int default 0")
	private Integer	dmaFORM_Count_N_Low;
	
	@Column(name = "DMAFUGR_COUNT_N_HIGH", columnDefinition = "int default 0")
	private Integer	dmaFUGR_Count_N_High;
	
	@Column(name = "DMAFUGR_COUNT_N_MEDIUM", columnDefinition = "int default 0")
	private Integer	dmaFUGR_Count_N_Medium;
	
	@Column(name = "DMAFUGR_COUNT_N_LOW", columnDefinition = "int default 0")
	private Integer	dmaFUGR_Count_N_Low;
	
	@Column(name = "DMAENH_COUNT_N_HIGH", columnDefinition = "int default 0")
	private Integer	dmaENH_Count_N_High;
	
	@Column(name = "DMAENH_COUNT_N_MEDIUM", columnDefinition = "int default 0")
	private Integer	dmaENH_Count_N_Medium;
	
	@Column(name = "DMAENH_COUNT_N_LOW", columnDefinition = "int default 0")
	private Integer	dmaENH_Count_N_Low;
	
	@Column(name = "DMALSMW_COUNT_N_HIGH", columnDefinition = "int default 0")
	private Integer	dmaLSMW_Count_N_High;
	
	@Column(name = "DMALSMW_COUNT_N_MEDIUM", columnDefinition = "int default 0")
	private Integer	dmaLSMW_Count_N_Medium;
	
	@Column(name = "DMALSMW_COUNT_N_LOW", columnDefinition = "int default 0")
	private Integer	dmaLSMW_Count_N_Low;
	
	@Column(name = "DMAUSEREXIT_COUNT_N_HIGH", columnDefinition = "int default 0")
	private Integer	dmaUSEREXIT_Count_N_High;
	
	@Column(name = "DMAUSEREXIT_COUNT_N_MEDIUM", columnDefinition = "int default 0")
	private Integer	dmaUSEREXIT_Count_N_Medium;
	
	@Column(name = "DMAUSEREXIT_COUNT_N_LOW", columnDefinition = "int default 0")
	private Integer	dmaUSEREXIT_Count_N_Low;
	
	@Column(name = "DMAWDYN_COUNT_N_HIGH", columnDefinition = "int default 0")
	private Integer	dmaWDYN_Count_N_High;
	
	@Column(name = "DMAWDYN_COUNT_N_MEDIUM", columnDefinition = "int default 0")
	private Integer	dmaWDYN_Count_N_Medium;
	
	@Column(name = "DMAWDYN_COUNT_N_LOW", columnDefinition = "int default 0")
	private Integer	dmaWDYN_Count_N_Low;
	
	@Column(name = "DMAFUGS_COUNT_N_HIGH", columnDefinition = "int default 0")
	private Integer	dmaFUGS_Count_N_High;
	
	@Column(name = "DMAFUGS_COUNT_N_MEDIUM", columnDefinition = "int default 0")
	private Integer	dmaFUGS_Count_N_Medium;
	
	@Column(name = "DMAFUGS_COUNT_N_LOW", columnDefinition = "int default 0")
	private Integer	dmaFUGS_Count_N_Low;
	
	@Column(name = "DMACLAS_COUNT_Y_LOW", columnDefinition = "int default 0")
	private Integer	dmaCLAS_Count_Y_Low;
	
	@Column(name = "DMAPROG_COUNT_Y_LOW", columnDefinition = "int default 0")
	private Integer	dmaPROG_Count_Y_Low;
	
	@Column(name = "DMAFUGR_COUNT_Y_LOW", columnDefinition = "int default 0")
	private Integer	dmaFUGR_Count_Y_Low;

	@Column(name = "DMAFUGS_COUNT_Y_LOW", columnDefinition = "int default 0")
	private Integer	dmaFUGS_Count_Y_Low;
	
	/* Used Mandatory Manual and Used Mandatory Automation Counts */
	@Column(name = "DUMACLAS_COUNT", columnDefinition = "int default 0")
	private Integer	dumaCLAS_Count;
	
	@Column(name = "DUMAPROG_COUNT", columnDefinition = "int default 0")
	private Integer	dumaPROG_Count;
	
	@Column(name = "DUMAFORM_COUNT", columnDefinition = "int default 0")
	private Integer	dumaFORM_Count;
	
	@Column(name = "DUMAFUGR_COUNT", columnDefinition = "int default 0")
	private Integer	dumaFUGR_Count;
	
	@Column(name = "DUMAENH_COUNT", columnDefinition = "int default 0")
	private Integer	dumaENH_Count;
	
	@Column(name = "DUMALSMW_COUNT", columnDefinition = "int default 0")
	private Integer	dumaLSMW_Count;
	
	@Column(name = "DUMAUSEREXIT_COUNT", columnDefinition = "int default 0")
	private Integer	dumaUSEREXIT_Count;
	
	@Column(name = "DUMAWDYN_COUNT", columnDefinition = "int default 0")
	private Integer	dumaWDYN_Count;
	
	@Column(name = "DUMAFUGS_COUNT", columnDefinition = "int default 0")
	private Integer	dumaFUGS_Count;
	
	@Column(name = "DUMACLAS_COUNT_N_HIGH", columnDefinition = "int default 0")
	private Integer	dumaCLAS_Count_N_High;
	
	@Column(name = "DUMACLAS_COUNT_N_MEDIUM", columnDefinition = "int default 0")
	private Integer	dumaCLAS_Count_N_Medium;
	
	@Column(name = "DUMACLAS_COUNT_N_LOW", columnDefinition = "int default 0")
	private Integer	dumaCLAS_Count_N_Low;
	
	@Column(name = "DUMAPROG_COUNT_N_HIGH", columnDefinition = "int default 0")
	private Integer	dumaPROG_Count_N_High;
	
	@Column(name = "DUMAPROG_COUNT_N_MEDIUM", columnDefinition = "int default 0")
	private Integer	dumaPROG_Count_N_Medium;
	
	@Column(name = "DUMAPROG_COUNT_N_LOW", columnDefinition = "int default 0")
	private Integer	dumaPROG_Count_N_Low;
	
	@Column(name = "DUMAFORM_COUNT_N_HIGH", columnDefinition = "int default 0")
	private Integer	dumaFORM_Count_N_High;
	
	@Column(name = "DUMAFORM_COUNT_N_MEDIUM", columnDefinition = "int default 0")
	private Integer	dumaFORM_Count_N_Medium;
	
	@Column(name = "DUMAFORM_COUNT_N_LOW", columnDefinition = "int default 0")
	private Integer	dumaFORM_Count_N_Low;
	
	@Column(name = "DUMAFUGR_COUNT_N_HIGH", columnDefinition = "int default 0")
	private Integer	dumaFUGR_Count_N_High;
	
	@Column(name = "DUMAFUGR_COUNT_N_MEDIUM", columnDefinition = "int default 0")
	private Integer	dumaFUGR_Count_N_Medium;
	
	@Column(name = "DUMAFUGR_COUNT_N_LOW", columnDefinition = "int default 0")
	private Integer	dumaFUGR_Count_N_Low;
	
	@Column(name = "DUMAENH_COUNT_N_HIGH", columnDefinition = "int default 0")
	private Integer	dumaENH_Count_N_High;
	
	@Column(name = "DUMAENH_COUNT_N_MEDIUM", columnDefinition = "int default 0")
	private Integer	dumaENH_Count_N_Medium;
	
	@Column(name = "DUMAENH_COUNT_N_LOW", columnDefinition = "int default 0")
	private Integer	dumaENH_Count_N_Low;
	
	@Column(name = "DUMALSMW_COUNT_N_HIGH", columnDefinition = "int default 0")
	private Integer	dumaLSMW_Count_N_High;
	
	@Column(name = "DUMALSMW_COUNT_N_MEDIUM", columnDefinition = "int default 0")
	private Integer	dumaLSMW_Count_N_Medium;
	
	@Column(name = "DUMALSMW_COUNT_N_LOW", columnDefinition = "int default 0")
	private Integer	dumaLSMW_Count_N_Low;
	
	@Column(name = "DUMAUSEREXIT_COUNT_N_HIGH", columnDefinition = "int default 0")
	private Integer	dumaUSEREXIT_Count_N_High;
	
	@Column(name = "DUMAUSEREXIT_COUNT_N_MEDIUM", columnDefinition = "int default 0")
	private Integer	dumaUSEREXIT_Count_N_Medium;
	
	@Column(name = "DUMAUSEREXIT_COUNT_N_LOW", columnDefinition = "int default 0")
	private Integer	dumaUSEREXIT_Count_N_Low;
	
	@Column(name = "DUMAWDYN_COUNT_N_HIGH", columnDefinition = "int default 0")
	private Integer	dumaWDYN_Count_N_High;
	
	@Column(name = "DUMAWDYN_COUNT_N_MEDIUM", columnDefinition = "int default 0")
	private Integer	dumaWDYN_Count_N_Medium;
	
	@Column(name = "DUMAWDYN_COUNT_N_LOW", columnDefinition = "int default 0")
	private Integer	dumaWDYN_Count_N_Low;
	
	@Column(name = "DUMAFUGS_COUNT_N_HIGH", columnDefinition = "int default 0")
	private Integer	dumaFUGS_Count_N_High;
	
	@Column(name = "DUMAFUGS_COUNT_N_MEDIUM", columnDefinition = "int default 0")
	private Integer	dumaFUGS_Count_N_Medium;
	
	@Column(name = "DUMAFUGS_COUNT_N_LOW", columnDefinition = "int default 0")
	private Integer	dumaFUGS_Count_N_Low;
	
	@Column(name = "DUMACLAS_COUNT_Y_LOW", columnDefinition = "int default 0")
	private Integer	dumaCLAS_Count_Y_Low;
	
	@Column(name = "DUMAPROG_COUNT_Y_LOW", columnDefinition = "int default 0")
	private Integer	dumaPROG_Count_Y_Low;

	@Column(name = "DUMAFUGR_COUNT_Y_LOW", columnDefinition = "int default 0")
	private Integer	dumaFUGR_Count_Y_Low;

	@Column(name = "DUMAFUGS_COUNT_Y_LOW", columnDefinition = "int default 0")
	private Integer	dumaFUGS_Count_Y_Low;
	
	
	/* Setters and Getters */
	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
		Id = id;
	}

	public long getRequestID() {
		return requestID;
	}

	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}

	public String getScope() {
		return scope;
	}

	public void setScope(String scope) {
		this.scope = scope;
	}

	public Integer getDmaCLAS_Count() {
		return dmaCLAS_Count;
	}

	public void setDmaCLAS_Count(Integer dmaCLAS_Count) {
		this.dmaCLAS_Count = dmaCLAS_Count;
	}

	public Integer getDmaPROG_Count() {
		return dmaPROG_Count;
	}

	public void setDmaPROG_Count(Integer dmaPROG_Count) {
		this.dmaPROG_Count = dmaPROG_Count;
	}

	public Integer getDmaFORM_Count() {
		return dmaFORM_Count;
	}

	public void setDmaFORM_Count(Integer dmaFORM_Count) {
		this.dmaFORM_Count = dmaFORM_Count;
	}

	public Integer getDmaFUGR_Count() {
		return dmaFUGR_Count;
	}

	public void setDmaFUGR_Count(Integer dmaFUGR_Count) {
		this.dmaFUGR_Count = dmaFUGR_Count;
	}

	public Integer getDmaENH_Count() {
		return dmaENH_Count;
	}

	public void setDmaENH_Count(Integer dmaENH_Count) {
		this.dmaENH_Count = dmaENH_Count;
	}

	public Integer getDmaLSMW_Count() {
		return dmaLSMW_Count;
	}

	public void setDmaLSMW_Count(Integer dmaLSMW_Count) {
		this.dmaLSMW_Count = dmaLSMW_Count;
	}

	public Integer getDmaUSEREXIT_Count() {
		return dmaUSEREXIT_Count;
	}

	public void setDmaUSEREXIT_Count(Integer dmaUSEREXIT_Count) {
		this.dmaUSEREXIT_Count = dmaUSEREXIT_Count;
	}

	public Integer getDmaWDYN_Count() {
		return dmaWDYN_Count;
	}

	public void setDmaWDYN_Count(Integer dmaWDYN_Count) {
		this.dmaWDYN_Count = dmaWDYN_Count;
	}

	public Integer getDmaFUGS_Count() {
		return dmaFUGS_Count;
	}

	public void setDmaFUGS_Count(Integer dmaFUGS_Count) {
		this.dmaFUGS_Count = dmaFUGS_Count;
	}

	public Integer getDmaCLAS_Count_N_High() {
		return dmaCLAS_Count_N_High;
	}

	public void setDmaCLAS_Count_N_High(Integer dmaCLAS_Count_N_High) {
		this.dmaCLAS_Count_N_High = dmaCLAS_Count_N_High;
	}

	public Integer getDmaCLAS_Count_N_Medium() {
		return dmaCLAS_Count_N_Medium;
	}

	public void setDmaCLAS_Count_N_Medium(Integer dmaCLAS_Count_N_Medium) {
		this.dmaCLAS_Count_N_Medium = dmaCLAS_Count_N_Medium;
	}

	public Integer getDmaCLAS_Count_N_Low() {
		return dmaCLAS_Count_N_Low;
	}

	public void setDmaCLAS_Count_N_Low(Integer dmaCLAS_Count_N_Low) {
		this.dmaCLAS_Count_N_Low = dmaCLAS_Count_N_Low;
	}

	public Integer getDmaPROG_Count_N_High() {
		return dmaPROG_Count_N_High;
	}

	public void setDmaPROG_Count_N_High(Integer dmaPROG_Count_N_High) {
		this.dmaPROG_Count_N_High = dmaPROG_Count_N_High;
	}

	public Integer getDmaPROG_Count_N_Medium() {
		return dmaPROG_Count_N_Medium;
	}

	public void setDmaPROG_Count_N_Medium(Integer dmaPROG_Count_N_Medium) {
		this.dmaPROG_Count_N_Medium = dmaPROG_Count_N_Medium;
	}

	public Integer getDmaPROG_Count_N_Low() {
		return dmaPROG_Count_N_Low;
	}

	public void setDmaPROG_Count_N_Low(Integer dmaPROG_Count_N_Low) {
		this.dmaPROG_Count_N_Low = dmaPROG_Count_N_Low;
	}

	public Integer getDmaFORM_Count_N_High() {
		return dmaFORM_Count_N_High;
	}

	public void setDmaFORM_Count_N_High(Integer dmaFORM_Count_N_High) {
		this.dmaFORM_Count_N_High = dmaFORM_Count_N_High;
	}

	public Integer getDmaFORM_Count_N_Medium() {
		return dmaFORM_Count_N_Medium;
	}

	public void setDmaFORM_Count_N_Medium(Integer dmaFORM_Count_N_Medium) {
		this.dmaFORM_Count_N_Medium = dmaFORM_Count_N_Medium;
	}

	public Integer getDmaFORM_Count_N_Low() {
		return dmaFORM_Count_N_Low;
	}

	public void setDmaFORM_Count_N_Low(Integer dmaFORM_Count_N_Low) {
		this.dmaFORM_Count_N_Low = dmaFORM_Count_N_Low;
	}

	public Integer getDmaFUGR_Count_N_High() {
		return dmaFUGR_Count_N_High;
	}

	public void setDmaFUGR_Count_N_High(Integer dmaFUGR_Count_N_High) {
		this.dmaFUGR_Count_N_High = dmaFUGR_Count_N_High;
	}

	public Integer getDmaFUGR_Count_N_Medium() {
		return dmaFUGR_Count_N_Medium;
	}

	public void setDmaFUGR_Count_N_Medium(Integer dmaFUGR_Count_N_Medium) {
		this.dmaFUGR_Count_N_Medium = dmaFUGR_Count_N_Medium;
	}

	public Integer getDmaFUGR_Count_N_Low() {
		return dmaFUGR_Count_N_Low;
	}

	public void setDmaFUGR_Count_N_Low(Integer dmaFUGR_Count_N_Low) {
		this.dmaFUGR_Count_N_Low = dmaFUGR_Count_N_Low;
	}

	public Integer getDmaENH_Count_N_High() {
		return dmaENH_Count_N_High;
	}

	public void setDmaENH_Count_N_High(Integer dmaENH_Count_N_High) {
		this.dmaENH_Count_N_High = dmaENH_Count_N_High;
	}

	public Integer getDmaENH_Count_N_Medium() {
		return dmaENH_Count_N_Medium;
	}

	public void setDmaENH_Count_N_Medium(Integer dmaENH_Count_N_Medium) {
		this.dmaENH_Count_N_Medium = dmaENH_Count_N_Medium;
	}

	public Integer getDmaENH_Count_N_Low() {
		return dmaENH_Count_N_Low;
	}

	public void setDmaENH_Count_N_Low(Integer dmaENH_Count_N_Low) {
		this.dmaENH_Count_N_Low = dmaENH_Count_N_Low;
	}

	public Integer getDmaLSMW_Count_N_High() {
		return dmaLSMW_Count_N_High;
	}

	public void setDmaLSMW_Count_N_High(Integer dmaLSMW_Count_N_High) {
		this.dmaLSMW_Count_N_High = dmaLSMW_Count_N_High;
	}

	public Integer getDmaLSMW_Count_N_Medium() {
		return dmaLSMW_Count_N_Medium;
	}

	public void setDmaLSMW_Count_N_Medium(Integer dmaLSMW_Count_N_Medium) {
		this.dmaLSMW_Count_N_Medium = dmaLSMW_Count_N_Medium;
	}

	public Integer getDmaLSMW_Count_N_Low() {
		return dmaLSMW_Count_N_Low;
	}

	public void setDmaLSMW_Count_N_Low(Integer dmaLSMW_Count_N_Low) {
		this.dmaLSMW_Count_N_Low = dmaLSMW_Count_N_Low;
	}

	public Integer getDmaUSEREXIT_Count_N_High() {
		return dmaUSEREXIT_Count_N_High;
	}

	public void setDmaUSEREXIT_Count_N_High(Integer dmaUSEREXIT_Count_N_High) {
		this.dmaUSEREXIT_Count_N_High = dmaUSEREXIT_Count_N_High;
	}

	public Integer getDmaUSEREXIT_Count_N_Medium() {
		return dmaUSEREXIT_Count_N_Medium;
	}

	public void setDmaUSEREXIT_Count_N_Medium(Integer dmaUSEREXIT_Count_N_Medium) {
		this.dmaUSEREXIT_Count_N_Medium = dmaUSEREXIT_Count_N_Medium;
	}

	public Integer getDmaUSEREXIT_Count_N_Low() {
		return dmaUSEREXIT_Count_N_Low;
	}

	public void setDmaUSEREXIT_Count_N_Low(Integer dmaUSEREXIT_Count_N_Low) {
		this.dmaUSEREXIT_Count_N_Low = dmaUSEREXIT_Count_N_Low;
	}

	public Integer getDmaWDYN_Count_N_High() {
		return dmaWDYN_Count_N_High;
	}

	public void setDmaWDYN_Count_N_High(Integer dmaWDYN_Count_N_High) {
		this.dmaWDYN_Count_N_High = dmaWDYN_Count_N_High;
	}

	public Integer getDmaWDYN_Count_N_Medium() {
		return dmaWDYN_Count_N_Medium;
	}

	public void setDmaWDYN_Count_N_Medium(Integer dmaWDYN_Count_N_Medium) {
		this.dmaWDYN_Count_N_Medium = dmaWDYN_Count_N_Medium;
	}

	public Integer getDmaWDYN_Count_N_Low() {
		return dmaWDYN_Count_N_Low;
	}

	public void setDmaWDYN_Count_N_Low(Integer dmaWDYN_Count_N_Low) {
		this.dmaWDYN_Count_N_Low = dmaWDYN_Count_N_Low;
	}

	public Integer getDmaFUGS_Count_N_High() {
		return dmaFUGS_Count_N_High;
	}

	public void setDmaFUGS_Count_N_High(Integer dmaFUGS_Count_N_High) {
		this.dmaFUGS_Count_N_High = dmaFUGS_Count_N_High;
	}

	public Integer getDmaFUGS_Count_N_Medium() {
		return dmaFUGS_Count_N_Medium;
	}

	public void setDmaFUGS_Count_N_Medium(Integer dmaFUGS_Count_N_Medium) {
		this.dmaFUGS_Count_N_Medium = dmaFUGS_Count_N_Medium;
	}

	public Integer getDmaFUGS_Count_N_Low() {
		return dmaFUGS_Count_N_Low;
	}

	public void setDmaFUGS_Count_N_Low(Integer dmaFUGS_Count_N_Low) {
		this.dmaFUGS_Count_N_Low = dmaFUGS_Count_N_Low;
	}

	public Integer getDmaCLAS_Count_Y_Low() {
		return dmaCLAS_Count_Y_Low;
	}

	public void setDmaCLAS_Count_Y_Low(Integer dmaCLAS_Count_Y_Low) {
		this.dmaCLAS_Count_Y_Low = dmaCLAS_Count_Y_Low;
	}

	public Integer getDmaPROG_Count_Y_Low() {
		return dmaPROG_Count_Y_Low;
	}

	public void setDmaPROG_Count_Y_Low(Integer dmaPROG_Count_Y_Low) {
		this.dmaPROG_Count_Y_Low = dmaPROG_Count_Y_Low;
	}
	
	public Integer getDmaFUGR_Count_Y_Low() {
		return dmaFUGR_Count_Y_Low;
	}

	public void setDmaFUGR_Count_Y_Low(Integer dmaFUGR_Count_Y_Low) {
		this.dmaFUGR_Count_Y_Low = dmaFUGR_Count_Y_Low;
	}

	public Integer getDmaFUGS_Count_Y_Low() {
		return dmaFUGS_Count_Y_Low;
	}

	public void setDmaFUGS_Count_Y_Low(Integer dmaFUGS_Count_Y_Low) {
		this.dmaFUGS_Count_Y_Low = dmaFUGS_Count_Y_Low;
	}

	public Integer getDumaCLAS_Count() {
		return dumaCLAS_Count;
	}

	public void setDumaCLAS_Count(Integer dumaCLAS_Count) {
		this.dumaCLAS_Count = dumaCLAS_Count;
	}

	public Integer getDumaPROG_Count() {
		return dumaPROG_Count;
	}

	public void setDumaPROG_Count(Integer dumaPROG_Count) {
		this.dumaPROG_Count = dumaPROG_Count;
	}

	public Integer getDumaFORM_Count() {
		return dumaFORM_Count;
	}

	public void setDumaFORM_Count(Integer dumaFORM_Count) {
		this.dumaFORM_Count = dumaFORM_Count;
	}

	public Integer getDumaFUGR_Count() {
		return dumaFUGR_Count;
	}

	public void setDumaFUGR_Count(Integer dumaFUGR_Count) {
		this.dumaFUGR_Count = dumaFUGR_Count;
	}

	public Integer getDumaENH_Count() {
		return dumaENH_Count;
	}

	public void setDumaENH_Count(Integer dumaENH_Count) {
		this.dumaENH_Count = dumaENH_Count;
	}

	public Integer getDumaLSMW_Count() {
		return dumaLSMW_Count;
	}

	public void setDumaLSMW_Count(Integer dumaLSMW_Count) {
		this.dumaLSMW_Count = dumaLSMW_Count;
	}

	public Integer getDumaUSEREXIT_Count() {
		return dumaUSEREXIT_Count;
	}

	public void setDumaUSEREXIT_Count(Integer dumaUSEREXIT_Count) {
		this.dumaUSEREXIT_Count = dumaUSEREXIT_Count;
	}

	public Integer getDumaWDYN_Count() {
		return dumaWDYN_Count;
	}

	public void setDumaWDYN_Count(Integer dumaWDYN_Count) {
		this.dumaWDYN_Count = dumaWDYN_Count;
	}

	public Integer getDumaFUGS_Count() {
		return dumaFUGS_Count;
	}

	public void setDumaFUGS_Count(Integer dumaFUGS_Count) {
		this.dumaFUGS_Count = dumaFUGS_Count;
	}

	public Integer getDumaCLAS_Count_N_High() {
		return dumaCLAS_Count_N_High;
	}

	public void setDumaCLAS_Count_N_High(Integer dumaCLAS_Count_N_High) {
		this.dumaCLAS_Count_N_High = dumaCLAS_Count_N_High;
	}

	public Integer getDumaCLAS_Count_N_Medium() {
		return dumaCLAS_Count_N_Medium;
	}

	public void setDumaCLAS_Count_N_Medium(Integer dumaCLAS_Count_N_Medium) {
		this.dumaCLAS_Count_N_Medium = dumaCLAS_Count_N_Medium;
	}

	public Integer getDumaCLAS_Count_N_Low() {
		return dumaCLAS_Count_N_Low;
	}

	public void setDumaCLAS_Count_N_Low(Integer dumaCLAS_Count_N_Low) {
		this.dumaCLAS_Count_N_Low = dumaCLAS_Count_N_Low;
	}

	public Integer getDumaPROG_Count_N_High() {
		return dumaPROG_Count_N_High;
	}

	public void setDumaPROG_Count_N_High(Integer dumaPROG_Count_N_High) {
		this.dumaPROG_Count_N_High = dumaPROG_Count_N_High;
	}

	public Integer getDumaPROG_Count_N_Medium() {
		return dumaPROG_Count_N_Medium;
	}

	public void setDumaPROG_Count_N_Medium(Integer dumaPROG_Count_N_Medium) {
		this.dumaPROG_Count_N_Medium = dumaPROG_Count_N_Medium;
	}

	public Integer getDumaPROG_Count_N_Low() {
		return dumaPROG_Count_N_Low;
	}

	public void setDumaPROG_Count_N_Low(Integer dumaPROG_Count_N_Low) {
		this.dumaPROG_Count_N_Low = dumaPROG_Count_N_Low;
	}

	public Integer getDumaFORM_Count_N_High() {
		return dumaFORM_Count_N_High;
	}

	public void setDumaFORM_Count_N_High(Integer dumaFORM_Count_N_High) {
		this.dumaFORM_Count_N_High = dumaFORM_Count_N_High;
	}

	public Integer getDumaFORM_Count_N_Medium() {
		return dumaFORM_Count_N_Medium;
	}

	public void setDumaFORM_Count_N_Medium(Integer dumaFORM_Count_N_Medium) {
		this.dumaFORM_Count_N_Medium = dumaFORM_Count_N_Medium;
	}

	public Integer getDumaFORM_Count_N_Low() {
		return dumaFORM_Count_N_Low;
	}

	public void setDumaFORM_Count_N_Low(Integer dumaFORM_Count_N_Low) {
		this.dumaFORM_Count_N_Low = dumaFORM_Count_N_Low;
	}

	public Integer getDumaFUGR_Count_N_High() {
		return dumaFUGR_Count_N_High;
	}

	public void setDumaFUGR_Count_N_High(Integer dumaFUGR_Count_N_High) {
		this.dumaFUGR_Count_N_High = dumaFUGR_Count_N_High;
	}

	public Integer getDumaFUGR_Count_N_Medium() {
		return dumaFUGR_Count_N_Medium;
	}

	public void setDumaFUGR_Count_N_Medium(Integer dumaFUGR_Count_N_Medium) {
		this.dumaFUGR_Count_N_Medium = dumaFUGR_Count_N_Medium;
	}

	public Integer getDumaFUGR_Count_N_Low() {
		return dumaFUGR_Count_N_Low;
	}

	public void setDumaFUGR_Count_N_Low(Integer dumaFUGR_Count_N_Low) {
		this.dumaFUGR_Count_N_Low = dumaFUGR_Count_N_Low;
	}

	public Integer getDumaENH_Count_N_High() {
		return dumaENH_Count_N_High;
	}

	public void setDumaENH_Count_N_High(Integer dumaENH_Count_N_High) {
		this.dumaENH_Count_N_High = dumaENH_Count_N_High;
	}

	public Integer getDumaENH_Count_N_Medium() {
		return dumaENH_Count_N_Medium;
	}

	public void setDumaENH_Count_N_Medium(Integer dumaENH_Count_N_Medium) {
		this.dumaENH_Count_N_Medium = dumaENH_Count_N_Medium;
	}

	public Integer getDumaENH_Count_N_Low() {
		return dumaENH_Count_N_Low;
	}

	public void setDumaENH_Count_N_Low(Integer dumaENH_Count_N_Low) {
		this.dumaENH_Count_N_Low = dumaENH_Count_N_Low;
	}

	public Integer getDumaLSMW_Count_N_High() {
		return dumaLSMW_Count_N_High;
	}

	public void setDumaLSMW_Count_N_High(Integer dumaLSMW_Count_N_High) {
		this.dumaLSMW_Count_N_High = dumaLSMW_Count_N_High;
	}

	public Integer getDumaLSMW_Count_N_Medium() {
		return dumaLSMW_Count_N_Medium;
	}

	public void setDumaLSMW_Count_N_Medium(Integer dumaLSMW_Count_N_Medium) {
		this.dumaLSMW_Count_N_Medium = dumaLSMW_Count_N_Medium;
	}

	public Integer getDumaLSMW_Count_N_Low() {
		return dumaLSMW_Count_N_Low;
	}

	public void setDumaLSMW_Count_N_Low(Integer dumaLSMW_Count_N_Low) {
		this.dumaLSMW_Count_N_Low = dumaLSMW_Count_N_Low;
	}

	public Integer getDumaUSEREXIT_Count_N_High() {
		return dumaUSEREXIT_Count_N_High;
	}

	public void setDumaUSEREXIT_Count_N_High(Integer dumaUSEREXIT_Count_N_High) {
		this.dumaUSEREXIT_Count_N_High = dumaUSEREXIT_Count_N_High;
	}

	public Integer getDumaUSEREXIT_Count_N_Medium() {
		return dumaUSEREXIT_Count_N_Medium;
	}

	public void setDumaUSEREXIT_Count_N_Medium(Integer dumaUSEREXIT_Count_N_Medium) {
		this.dumaUSEREXIT_Count_N_Medium = dumaUSEREXIT_Count_N_Medium;
	}

	public Integer getDumaUSEREXIT_Count_N_Low() {
		return dumaUSEREXIT_Count_N_Low;
	}

	public void setDumaUSEREXIT_Count_N_Low(Integer dumaUSEREXIT_Count_N_Low) {
		this.dumaUSEREXIT_Count_N_Low = dumaUSEREXIT_Count_N_Low;
	}

	public Integer getDumaWDYN_Count_N_High() {
		return dumaWDYN_Count_N_High;
	}

	public void setDumaWDYN_Count_N_High(Integer dumaWDYN_Count_N_High) {
		this.dumaWDYN_Count_N_High = dumaWDYN_Count_N_High;
	}

	public Integer getDumaWDYN_Count_N_Medium() {
		return dumaWDYN_Count_N_Medium;
	}

	public void setDumaWDYN_Count_N_Medium(Integer dumaWDYN_Count_N_Medium) {
		this.dumaWDYN_Count_N_Medium = dumaWDYN_Count_N_Medium;
	}

	public Integer getDumaWDYN_Count_N_Low() {
		return dumaWDYN_Count_N_Low;
	}

	public void setDumaWDYN_Count_N_Low(Integer dumaWDYN_Count_N_Low) {
		this.dumaWDYN_Count_N_Low = dumaWDYN_Count_N_Low;
	}

	public Integer getDumaFUGS_Count_N_High() {
		return dumaFUGS_Count_N_High;
	}

	public void setDumaFUGS_Count_N_High(Integer dumaFUGS_Count_N_High) {
		this.dumaFUGS_Count_N_High = dumaFUGS_Count_N_High;
	}

	public Integer getDumaFUGS_Count_N_Medium() {
		return dumaFUGS_Count_N_Medium;
	}

	public void setDumaFUGS_Count_N_Medium(Integer dumaFUGS_Count_N_Medium) {
		this.dumaFUGS_Count_N_Medium = dumaFUGS_Count_N_Medium;
	}

	public Integer getDumaFUGS_Count_N_Low() {
		return dumaFUGS_Count_N_Low;
	}

	public void setDumaFUGS_Count_N_Low(Integer dumaFUGS_Count_N_Low) {
		this.dumaFUGS_Count_N_Low = dumaFUGS_Count_N_Low;
	}

	public Integer getDumaCLAS_Count_Y_Low() {
		return dumaCLAS_Count_Y_Low;
	}

	public void setDumaCLAS_Count_Y_Low(Integer dumaCLAS_Count_Y_Low) {
		this.dumaCLAS_Count_Y_Low = dumaCLAS_Count_Y_Low;
	}

	public Integer getDumaPROG_Count_Y_Low() {
		return dumaPROG_Count_Y_Low;
	}

	public void setDumaPROG_Count_Y_Low(Integer dumaPROG_Count_Y_Low) {
		this.dumaPROG_Count_Y_Low = dumaPROG_Count_Y_Low;
	}

	public Integer getDumaFUGR_Count_Y_Low() {
		return dumaFUGR_Count_Y_Low;
	}

	public void setDumaFUGR_Count_Y_Low(Integer dumaFUGR_Count_Y_Low) {
		this.dumaFUGR_Count_Y_Low = dumaFUGR_Count_Y_Low;
	}

	public Integer getDumaFUGS_Count_Y_Low() {
		return dumaFUGS_Count_Y_Low;
	}

	public void setDumaFUGS_Count_Y_Low(Integer dumaFUGS_Count_Y_Low) {
		this.dumaFUGS_Count_Y_Low = dumaFUGS_Count_Y_Low;
	}
}
