package com.act.master;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "EXTENSION_SCOPE_MASTER")
public class ExtensionScope {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private int id;
	
	@Column(name = "Request_ID", nullable = false)
	private long requestId;
	
	@Column(name = "RICEF_COUNT")
	private String totalRicefCount;
	
	@Column(name = "TOTAL_COMP_COUNT")
	private String totalComplexityCount;
	
	@Column(name = "TOTAL_EXT_COUNT")
	private String totalExtensionCount;
	
	@Column(name = "REPORTS_COUNT")
	private String reportsCount;
	
	@Column(name = "REPORTS_COMP_COUNT")
	private String reports_Complexity;
	
	@Column(name = "REPORTS_EXT_COUNT")
	private String reports_Extension;
	
	@Column(name = "FORMS_COMP_COUNT")
	private String forms_Complexity;
	
	@Column(name = "INTERFACE_COMP_COUNT")
	private String interface_Complexity;
	
	@Column(name = "CONVERSION_COMP_COUNT")
	private String conversion_Complexity;
	
	@Column(name = "ENHANCEMENT_COMP_COUNT")
	private String enhancement_Complexity;
	
	@Column(name = "WORKFLOW_COMP_COUNT")
	private String workflow_Complexity;
	
	@Column(name = "ODATA_COMP_COUNT")
	private String odata_Complexity;
	
	@Column(name = "CDS_COMP_COUNT")
	private String cds_Complexity;
	
	@Column(name = "UI5_COMP_COUNT")
	private String ui5_Complexity;
	
	@Column(name = "MP_COMP_COUNT")
	private String classicaldynpro_Complexity;
	
	@Column(name = "FORMS_EXT_COUNT")
	private String forms_Extension;
	
	@Column(name = "INTERFACE_EXT_COUNT")
	private String interface_Extension;
	
	@Column(name = "ENHANCEMENT_EXT_COUNT")
	private String enhancement_Extension;
	
	@Column(name = "CONVERSION_EXT_COUNT")
	private String conversion_Extension;
	
	@Column(name = "WORKFLOW_EXT_COUNT")
	private String workflow_Extension;
	
	@Column(name = "ODATA_EXT_COUNT")
	private String odata_Extension;
	
	@Column(name = "CDS_EXT_COUNT")
	private String cds_Extension;
	
	@Column(name = "UI5_EXT_COUNT")
	private String ui5_Extension;
	
	@Column(name = "MP_EXT_COUNT")
	private String classicaldynpro_Extension;
	
	@Column(name = "OTHERS_RICEF_COUNT")
	private String othersRicefCount;
	
	@Column(name = "TOTAL_OBJS_COUNT")
	private String totalObjsCount;
	
	@Column(name = "STACKED_COMPLEXITY_COUNT", columnDefinition = "LONGTEXT")
	private String stackedComplexityCount;
	
	@Column(name = "STACKED_EXTENSION_COUNT", columnDefinition = "LONGTEXT")
	private String stackedExtensionCount;

	@Transient
	private String ricefFlag;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public long getRequestId() {
		return requestId;
	}

	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}

	public String getTotalRicefCount() {
		return totalRicefCount;
	}

	public void setTotalRicefCount(String totalRicefCount) {
		this.totalRicefCount = totalRicefCount;
	}

	public String getTotalComplexityCount() {
		return totalComplexityCount;
	}

	public void setTotalComplexityCount(String totalComplexityCount) {
		this.totalComplexityCount = totalComplexityCount;
	}

	public String getTotalExtensionCount() {
		return totalExtensionCount;
	}

	public void setTotalExtensionCount(String totalExtensionCount) {
		this.totalExtensionCount = totalExtensionCount;
	}

	public String getReportsCount() {
		return reportsCount;
	}

	public void setReportsCount(String reportsCount) {
		this.reportsCount = reportsCount;
	}

	public String getReports_Complexity() {
		return reports_Complexity;
	}

	public void setReports_Complexity(String reports_Complexity) {
		this.reports_Complexity = reports_Complexity;
	}

	public String getReports_Extension() {
		return reports_Extension;
	}

	public void setReports_Extension(String reports_Extension) {
		this.reports_Extension = reports_Extension;
	}

	public String getForms_Complexity() {
		return forms_Complexity;
	}

	public void setForms_Complexity(String forms_Complexity) {
		this.forms_Complexity = forms_Complexity;
	}

	public String getInterface_Complexity() {
		return interface_Complexity;
	}

	public void setInterface_Complexity(String interface_Complexity) {
		this.interface_Complexity = interface_Complexity;
	}

	public String getConversion_Complexity() {
		return conversion_Complexity;
	}

	public void setConversion_Complexity(String conversion_Complexity) {
		this.conversion_Complexity = conversion_Complexity;
	}

	public String getEnhancement_Complexity() {
		return enhancement_Complexity;
	}

	public void setEnhancement_Complexity(String enhancement_Complexity) {
		this.enhancement_Complexity = enhancement_Complexity;
	}

	public String getWorkflow_Complexity() {
		return workflow_Complexity;
	}

	public void setWorkflow_Complexity(String workflow_Complexity) {
		this.workflow_Complexity = workflow_Complexity;
	}

	public String getForms_Extension() {
		return forms_Extension;
	}

	public void setForms_Extension(String forms_Extension) {
		this.forms_Extension = forms_Extension;
	}

	public String getInterface_Extension() {
		return interface_Extension;
	}

	public void setInterface_Extension(String interface_Extension) {
		this.interface_Extension = interface_Extension;
	}

	public String getEnhancement_Extension() {
		return enhancement_Extension;
	}

	public void setEnhancement_Extension(String enhancement_Extension) {
		this.enhancement_Extension = enhancement_Extension;
	}

	public String getConversion_Extension() {
		return conversion_Extension;
	}

	public void setConversion_Extension(String conversion_Extension) {
		this.conversion_Extension = conversion_Extension;
	}

	public String getWorkflow_Extension() {
		return workflow_Extension;
	}

	public void setWorkflow_Extension(String workflow_Extension) {
		this.workflow_Extension = workflow_Extension;
	}

	public String getOthersRicefCount() {
		return othersRicefCount;
	}

	public void setOthersRicefCount(String othersRicefCount) {
		this.othersRicefCount = othersRicefCount;
	}

	public String getTotalObjsCount() {
		return totalObjsCount;
	}

	public void setTotalObjsCount(String totalObjsCount) {
		this.totalObjsCount = totalObjsCount;
	}

	public String getStackedComplexityCount() {
		return stackedComplexityCount;
	}

	public void setStackedComplexityCount(String stackedComplexityCount) {
		this.stackedComplexityCount = stackedComplexityCount;
	}

	public String getStackedExtensionCount() {
		return stackedExtensionCount;
	}

	public void setStackedExtensionCount(String stackedExtensionCount) {
		this.stackedExtensionCount = stackedExtensionCount;
	}

	public String getRicefFlag() {
		return ricefFlag;
	}

	public void setRicefFlag(String ricefFlag) {
		this.ricefFlag = ricefFlag;
	}

	public String getOdata_Complexity() {
		return odata_Complexity;
	}

	public void setOdata_Complexity(String odata_Complexity) {
		this.odata_Complexity = odata_Complexity;
	}

	public String getOdata_Extension() {
		return odata_Extension;
	}

	public void setOdata_Extension(String odata_Extension) {
		this.odata_Extension = odata_Extension;
	}

	public String getCds_Complexity() {
		return cds_Complexity;
	}

	public void setCds_Complexity(String cds_Complexity) {
		this.cds_Complexity = cds_Complexity;
	}

	public String getCds_Extension() {
		return cds_Extension;
	}

	public void setCds_Extension(String cds_Extension) {
		this.cds_Extension = cds_Extension;
	}

	public String getClassicaldynpro_Complexity() {
		return classicaldynpro_Complexity;
	}

	public void setClassicaldynpro_Complexity(String classicaldynpro_Complexity) {
		this.classicaldynpro_Complexity = classicaldynpro_Complexity;
	}

	public String getClassicaldynpro_Extension() {
		return classicaldynpro_Extension;
	}

	public void setClassicaldynpro_Extension(String classicaldynpro_Extension) {
		this.classicaldynpro_Extension = classicaldynpro_Extension;
	}

	public String getUi5_Complexity() {
		return ui5_Complexity;
	}

	public void setUi5_Complexity(String ui5_Complexity) {
		this.ui5_Complexity = ui5_Complexity;
	}

	public String getUi5_Extension() {
		return ui5_Extension;
	}

	public void setUi5_Extension(String ui5_Extension) {
		this.ui5_Extension = ui5_Extension;
	}

}
