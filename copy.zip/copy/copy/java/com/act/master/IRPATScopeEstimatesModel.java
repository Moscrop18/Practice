package com.act.master;

import javax.validation.constraints.NotNull;

import com.act.constant.ST03HanaConstant;

public class IRPATScopeEstimatesModel {

	private long requestId;

	@NotNull(message = ST03HanaConstant.IRPA_ESTIMATES_BLANK_ERROR_MSG)
	private Integer totalTestScriptsCount;

	@NotNull(message = ST03HanaConstant.IRPA_ESTIMATES_BLANK_ERROR_MSG)
	private Integer impactedBusinessScenariosCount;

	@NotNull(message = ST03HanaConstant.IRPA_ESTIMATES_BLANK_ERROR_MSG)
	private Integer addBusinessScenariosToTestCount;

	@NotNull(message = ST03HanaConstant.IRPA_ESTIMATES_BLANK_ERROR_MSG)
	private Integer noTestStepsToTestCount;

	@NotNull(message = ST03HanaConstant.IRPA_ESTIMATES_BLANK_ERROR_MSG)
	private Integer testScriptsForEstimationsCount;

	@NotNull(message = ST03HanaConstant.IRPA_ESTIMATES_BLANK_ERROR_MSG)
	private Integer simpleCompForTestScriptCount;

	@NotNull(message = ST03HanaConstant.IRPA_ESTIMATES_BLANK_ERROR_MSG)
	private Integer mediumCompForTestScriptCount;

	@NotNull(message = ST03HanaConstant.IRPA_ESTIMATES_BLANK_ERROR_MSG)
	private Integer complexCompForTestScriptCount;

	@NotNull(message = ST03HanaConstant.IRPA_ESTIMATES_BLANK_ERROR_MSG)
	private Integer manualScriptCreationCount;

	@NotNull(message = ST03HanaConstant.IRPA_ESTIMATES_BLANK_ERROR_MSG)
	private Integer manualScriptModificationCount;
	
	@NotNull(message = ST03HanaConstant.IRPA_ESTIMATES_BLANK_ERROR_MSG)
	private Integer scriptsForUnitTest;

	@NotNull(message = ST03HanaConstant.IRPA_ESTIMATES_BLANK_ERROR_MSG)
	private Integer scriptsForSITOne;

	@NotNull(message = ST03HanaConstant.IRPA_ESTIMATES_BLANK_ERROR_MSG)
	private Integer scriptsForSITTwo;

	@NotNull(message = ST03HanaConstant.IRPA_ESTIMATES_BLANK_ERROR_MSG)
	private Integer scriptsForRegressionTest;

	@NotNull(message = ST03HanaConstant.IRPA_ESTIMATES_BLANK_ERROR_MSG)
	private Integer scriptsForUAT;
	
	@NotNull(message = ST03HanaConstant.IRPA_ESTIMATES_BLANK_ERROR_MSG)
	private Integer scriptsForSmokeTest;

	public long getRequestId() {
		return requestId;
	}

	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}

	public Integer getTotalTestScriptsCount() {
		return totalTestScriptsCount;
	}

	public void setTotalTestScriptsCount(Integer totalTestScriptsCount) {
		this.totalTestScriptsCount = totalTestScriptsCount;
	}

	public Integer getImpactedBusinessScenariosCount() {
		return impactedBusinessScenariosCount;
	}

	public void setImpactedBusinessScenariosCount(Integer impactedBusinessScenariosCount) {
		this.impactedBusinessScenariosCount = impactedBusinessScenariosCount;
	}

	public Integer getAddBusinessScenariosToTestCount() {
		return addBusinessScenariosToTestCount;
	}

	public void setAddBusinessScenariosToTestCount(Integer addBusinessScenariosToTestCount) {
		this.addBusinessScenariosToTestCount = addBusinessScenariosToTestCount;
	}

	public Integer getNoTestStepsToTestCount() {
		return noTestStepsToTestCount;
	}

	public void setNoTestStepsToTestCount(Integer noTestStepsToTestCount) {
		this.noTestStepsToTestCount = noTestStepsToTestCount;
	}

	public Integer getTestScriptsForEstimationsCount() {
		return testScriptsForEstimationsCount;
	}

	public void setTestScriptsForEstimationsCount(Integer testScriptsForEstimationsCount) {
		this.testScriptsForEstimationsCount = testScriptsForEstimationsCount;
	}

	public Integer getSimpleCompForTestScriptCount() {
		return simpleCompForTestScriptCount;
	}

	public void setSimpleCompForTestScriptCount(Integer simpleCompForTestScriptCount) {
		this.simpleCompForTestScriptCount = simpleCompForTestScriptCount;
	}

	public Integer getMediumCompForTestScriptCount() {
		return mediumCompForTestScriptCount;
	}

	public void setMediumCompForTestScriptCount(Integer mediumCompForTestScriptCount) {
		this.mediumCompForTestScriptCount = mediumCompForTestScriptCount;
	}

	public Integer getComplexCompForTestScriptCount() {
		return complexCompForTestScriptCount;
	}

	public void setComplexCompForTestScriptCount(Integer complexCompForTestScriptCount) {
		this.complexCompForTestScriptCount = complexCompForTestScriptCount;
	}

	public Integer getManualScriptCreationCount() {
		return manualScriptCreationCount;
	}

	public void setManualScriptCreationCount(Integer manualScriptCreationCount) {
		this.manualScriptCreationCount = manualScriptCreationCount;
	}

	public Integer getManualScriptModificationCount() {
		return manualScriptModificationCount;
	}

	public void setManualScriptModificationCount(Integer manualScriptModificationCount) {
		this.manualScriptModificationCount = manualScriptModificationCount;
	}

	public Integer getScriptsForUnitTest() {
		return scriptsForUnitTest;
	}

	public void setScriptsForUnitTest(Integer scriptsForUnitTest) {
		this.scriptsForUnitTest = scriptsForUnitTest;
	}

	public Integer getScriptsForSITOne() {
		return scriptsForSITOne;
	}

	public void setScriptsForSITOne(Integer scriptsForSITOne) {
		this.scriptsForSITOne = scriptsForSITOne;
	}

	public Integer getScriptsForSITTwo() {
		return scriptsForSITTwo;
	}

	public void setScriptsForSITTwo(Integer scriptsForSITTwo) {
		this.scriptsForSITTwo = scriptsForSITTwo;
	}

	public Integer getScriptsForRegressionTest() {
		return scriptsForRegressionTest;
	}

	public void setScriptsForRegressionTest(Integer scriptsForRegressionTest) {
		this.scriptsForRegressionTest = scriptsForRegressionTest;
	}

	public Integer getScriptsForUAT() {
		return scriptsForUAT;
	}

	public void setScriptsForUAT(Integer scriptsForUAT) {
		this.scriptsForUAT = scriptsForUAT;
	}

	public Integer getScriptsForSmokeTest() {
		return scriptsForSmokeTest;
	}

	public void setScriptsForSmokeTest(Integer scriptsForSmokeTest) {
		this.scriptsForSmokeTest = scriptsForSmokeTest;
	}
}
