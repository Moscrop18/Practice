package com.act.fiori.models;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;

import javax.persistence.Column;

public class St03NData {

	private String tCodeName;

	private String tCodeDescription;

	private int usageCount;

	private String objType;

	private Long requestId;
	
	private String objNameType;

	public String gettCodeName() {
		return tCodeName;
	}

	public void settCodeName(String tCodeName) {
		this.tCodeName = tCodeName;
	}

	public String gettCodeDescription() {
		return tCodeDescription;
	}

	public void settCodeDescription(String tCodeDescription) {
		this.tCodeDescription = tCodeDescription;
	}

	public Long getRequestId() {
		return requestId;
	}

	public void setRequestId(Long requestId) {
		this.requestId = requestId;
	}

	@Column(columnDefinition = "int default 0")
	public int getUsageCount() {
		return usageCount;
	}

	public void setUsageCount(int usageCount) {
		this.usageCount = usageCount;
	}

	public String getObjType() {
		return objType;
	}

	public void setObjType(String objType) {
		this.objType = objType;
	}

	public String getObjNameType() {
		return objNameType;
	}

	public void setObjNameType(String objNameType) {
		this.objNameType = objNameType;
	}
}
