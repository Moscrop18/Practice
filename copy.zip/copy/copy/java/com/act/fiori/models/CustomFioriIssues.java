/**
 * 
 */
package com.act.fiori.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author gunasekaran.ramasamy
 * 
 * Pojo class for custom issues processed
 *
 */

@Entity
@Table(name="Custom_Fiori_Issues")
public class CustomFioriIssues {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID")
	private int id;
	
	
	@Column(name="Object")
	public String object;
	
	@Column(name="Obj_name")
	public String objName;
	
	@Column(name="Oprcd")
	public String opercode;
	
	@Column(name="simplified")
	public String code;
	
	@Column(name="Type")
	public String objType;
	
	@Column(name="SubCategory")
	public String subCategory;
	
	@Column(name="Impact")
	public String impact;
	
	@Column(name="REQUEST_ID")
	private long requestID;
	
	
	
	public long getRequestID() {
		return requestID;
	}

	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}
	
	
	
	public String getObject() {
		return object;
	}
	public void setObject(String object) {
		this.object = object;
	}
	public String getObjName() {
		return objName;
	}
	public void setObjName(String objName) {
		this.objName = objName;
	}
	public String getOpercode() {
		return opercode;
	}
	public void setOpercode(String opercode) {
		this.opercode = opercode;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getObjType() {
		return objType;
	}
	public void setObjType(String objType) {
		this.objType = objType;
	}
	public String getSubCategory() {
		return subCategory;
	}
	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}
	public String getImpact() {
		return impact;
	}
	public void setImpact(String impact) {
		this.impact = impact;
	}

	
	

}
