/**
 * 
 */
package com.act.fiori.models;

/**
 * @author gunasekaran.ramasamy
 * 
 * Pojo for Master data custom issues of Fiori
 *
 */
public class CustomFioriIssuesMaster {
	
	public String code;
	public String objType;
	public String subCategory;
	public String impact;
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getObjType() {
		return objType;
	}
	public void setObjType(String objType) {
		this.objType = objType;
	}
	public String getSubCategory() {
		return subCategory;
	}
	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}
	public String getImpact() {
		return impact;
	}
	public void setImpact(String impact) {
		this.impact = impact;
	}


}
