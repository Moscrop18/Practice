package com.act.fiori.models;



public class OdataFioriMasterData {
	
	private String appId;
	private String bspName;
	private String bspNameCombined;
	private String odataServicesCombined;
	
	private String  pcdCombined;
	private String tcodesCombined;
	private String appTypeCombined;
	private String formFactors;
	
	private String releaseId;
	private String releaseName;
	
	private String successorApp;
	private String relatedApp;
	
	public String getSuccessorApp() {
		return successorApp;
	}
	public void setSuccessorApp(String successorApp) {
		this.successorApp = successorApp;
	}
	public String getRelatedApp() {
		return relatedApp;
	}
	public void setRelatedApp(String relatedApp) {
		this.relatedApp = relatedApp;
	}
	public String getReleaseId() {
		return releaseId;
	}
	public void setReleaseId(String releaseId) {
		this.releaseId = releaseId;
	}
	public String getReleaseName() {
		return releaseName;
	}
	public void setReleaseName(String releaseName) {
		this.releaseName = releaseName;
	}
	private String appName;
	
	public String getBspNameCombined() {
		return bspNameCombined;
	}
	public void setBspNameCombined(String bspNameCombined) {
		this.bspNameCombined = bspNameCombined;
	}
	private String pvBackendCombined;
	
	public String getAppId() {
		return appId;
	}
	public void setAppId(String appId) {
		this.appId = appId;
	}
	public String getBspName() {
		return bspName;
	}
	public void setBspName(String bspName) {
		this.bspName = bspName;
	}
	public String getOdataServicesCombined() {
		return odataServicesCombined;
	}
	public void setOdataServicesCombined(String odataServicesCombined) {
		this.odataServicesCombined = odataServicesCombined;
	}
	
	public String getPcdCombined() {
		return pcdCombined;
	}
	public void setPcdCombined(String pcdCombined) {
		this.pcdCombined = pcdCombined;
	}
	public String getTcodesCombined() {
		return tcodesCombined;
	}
	public void setTcodesCombined(String tcodesCombined) {
		this.tcodesCombined = tcodesCombined;
	}
	public String getAppTypeCombined() {
		return appTypeCombined;
	}
	public void setAppTypeCombined(String appTypeCombined) {
		this.appTypeCombined = appTypeCombined;
	}
	public String getFormFactors() {
		return formFactors;
	}
	public void setFormFactors(String formFactors) {
		this.formFactors = formFactors;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getPvBackendCombined() {
		return pvBackendCombined;
	}
	public void setPvBackendCombined(String pvBackendCombined) {
		this.pvBackendCombined = pvBackendCombined;
	}
	

}
