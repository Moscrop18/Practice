package com.act.fiori.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name="Inventory_Standard_Fiori")
public class InventoryStandardFiori {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID")
	private int id;
	
	@Column(name="REQUEST_ID")
	private long requestID;
	
	@Column(name="Object")
	private String object;
	
	@Column(name="SESSION_ID")
	private String sessioId;
	
	@Column(name="SUBTYPE")
	private String subtype;
	
	@Column(name="SuccessorAppId")
	private String successorAppId;
	
	@Column(name="RelatedAppId")
	private String relatedAppId;
	
	public String getSuccessorAppId() {
		return successorAppId;
	}

	public void setSuccessorAppId(String successorAppId) {
		this.successorAppId = successorAppId;
	}

	public String getRelatedAppId() {
		return relatedAppId;
	}

	public void setRelatedAppId(String relatedAppId) {
		this.relatedAppId = relatedAppId;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSessioId() {
		return sessioId;
	}

	public void setSessioId(String sessioId) {
		this.sessioId = sessioId;
	}

	public String getSubtype() {
		return subtype;
	}

	public void setSubtype(String subtype) {
		this.subtype = subtype;
	}

	@Column(name = "AppId" ,columnDefinition="varchar(500)" )
	@Index(name="INDEX_APP_ID")
	private String appId;
	
	@Column(name="BspName")
	private String bspName;
	
	
	@Column(name="OdataServicesCombined",  columnDefinition="TEXT" )
	private String odataServicesCombined;
	
	@Column(name="AppsTypeCombined", columnDefinition="TEXT")
	private String  appsTypeCombined;
	
	@Column(name="PCDCombined", columnDefinition="TEXT")
	private String  pcdCombined;
	
	@Column(name="App_Name")
	private String appName;
	
	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	@Column(name="Availability")
	private String availability;
	
	@Column(name="Obj_Name")
	private String objName;
	
	@Column(name="Read_Prog")
	private String readProg;
	
	@Column(name = "PVBackendCombined" , columnDefinition="TEXT" )
	private String   pvBackendCombined;

	public String getObject() {
		return object;
	}

	public void setObject(String object) {
		this.object = object;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public String getBspName() {
		return bspName;
	}

	public void setBspName(String bspName) {
		this.bspName = bspName;
	}

	public String getOdataServicesCombined() {
		return odataServicesCombined;
	}

	public void setOdataServicesCombined(String odataServicesCombined) {
		this.odataServicesCombined = odataServicesCombined;
	}

	public String getAppsTypeCombined() {
		return appsTypeCombined;
	}

	public void setAppsTypeCombined(String appsTypeCombined) {
		this.appsTypeCombined = appsTypeCombined;
	}

	public String getPcdCombined() {
		return pcdCombined;
	}

	public void setPcdCombined(String pcdCombined) {
		this.pcdCombined = pcdCombined;
	}

	public String getAvailability() {
		return availability;
	}

	public void setAvailability(String availability) {
		this.availability = availability;
	}
	public long getRequestID() {
		return requestID;
	}

	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}

	public String getReadProg() {
		return readProg;
	}

	public void setReadProg(String readProg) {
		this.readProg = readProg;
	}

	public String getPvBackendCombined() {
		return pvBackendCombined;
	}

	public void setPvBackendCombined(String pvBackendCombined) {
		this.pvBackendCombined = pvBackendCombined;
	}
	
	@Column(name="Version")
	private String version;
	
	@Column(name="Alternate_Name")
	private String altName;

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getAltName() {
		return altName;
	}

	public void setAltName(String altName) {
		this.altName = altName;
	}
}
