package com.act.fiori.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name="Inventory_Std_Fiori_Intermediate")
public class InventoryStandardFioriIntermediate {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID")
	private int id;
	
	@Column(name="REQUEST_ID")
	private long requestID;
	
	@Column(name="Object")
	private String object;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Column(name = "AppId" ,columnDefinition="varchar(500)" )
	@Index(name="INDEX_APP_ID")
	private String appId;
	
	@Column(name="App_Name")
	private String appName;
	
	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	@Column(name="Availability")
	private String availability;
	
	@Column(name="Obj_Name")
	private String objName;
	

	@Column(name="Version")
	private String version;
	
	@Column(name="Alternate_Name")
	private String altName;
	
	@Column(name="BSPName")
	private String bspName;
	
	@Column(name="BSPNameCombined")
	private String bspNameCombined;
	
	@Column(name="SuccessorAppId")
	private String successorAppId;
	
	public String getSuccessorAppId() {
		return successorAppId;
	}

	public void setSuccessorAppId(String successorAppId) {
		this.successorAppId = successorAppId;
	}

	public String getRelatedAppId() {
		return relatedAppId;
	}

	public void setRelatedAppId(String relatedAppId) {
		this.relatedAppId = relatedAppId;
	}

	@Column(name="RelatedAppId")
	private String relatedAppId;
	
	public String getBspNameCombined() {
		return bspNameCombined;
	}

	public void setBspNameCombined(String bspNameCombined) {
		this.bspNameCombined = bspNameCombined;
	}

	@Column(name="OdataServicesCombined", columnDefinition="TEXT")
	private String odataServicesCombined;
	
	public String getBspName() {
		return bspName;
	}

	public void setBspName(String bspName) {
		this.bspName = bspName;
	}

	public String getOdataServicesCombined() {
		return odataServicesCombined;
	}

	public void setOdataServicesCombined(String odataServicesCombined) {
		this.odataServicesCombined = odataServicesCombined;
	}

	public String getAltName() {
		return altName;
	}

	public void setAltName(String altName) {
		this.altName = altName;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getObject() {
		return object;
	}

	public void setObject(String object) {
		this.object = object;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public String getAvailability() {
		return availability;
	}

	public void setAvailability(String availability) {
		this.availability = availability;
	}
	public long getRequestID() {
		return requestID;
	}

	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}
	
	@Override
	public boolean equals(Object o) {
	    if (o == this)
	        return true;
	    if (!(o instanceof InventoryStandardFioriIntermediate))
	        return false;
	    InventoryStandardFioriIntermediate other = (InventoryStandardFioriIntermediate)o;
	    return this.appId == other.appId;
	}
	@Override
	public final int hashCode() {
	    int result = 17;
	    if (appId != null) {
	        result = 31 * result + appId.hashCode();
	    }
	    return result;
	}
}
