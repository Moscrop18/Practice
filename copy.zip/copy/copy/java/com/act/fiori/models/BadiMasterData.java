package com.act.fiori.models;

import javax.persistence.Column;

public class BadiMasterData {
	
	private String queryName;
	
	private String appId;
	
	private String pcdCombined;
	
	
	private String   pvBackendCombined;

	public String getPcdCombined() {
		return pcdCombined;
	}

	public void setPcdCombined(String pcdCombined) {
		this.pcdCombined = pcdCombined;
	}

	public String getQueryName() {
		return queryName;
	}

	public void setQueryName(String queryName) {
		this.queryName = queryName;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public String getPvBackendCombined() {
		return pvBackendCombined;
	}

	public void setPvBackendCombined(String pvBackendCombined) {
		this.pvBackendCombined = pvBackendCombined;
	}

}
