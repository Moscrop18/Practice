package com.act.impactedBackgroundJob;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

/**
 * @author himani.malhotra
 *
 */
@Entity
@Table(name="Impacted_Background_Counts" )
public class ImpactedBackgroundCounts {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Integer Id;
	
	@Column(name = "Request_ID", nullable = false)
	private long	requestID;
	
	@Column(name = "backgroundJobCount",columnDefinition = "int default 0")
	private Integer	backgroundJobCount;
	
	@Column(name = "jobRunCount_Daily",columnDefinition = "int default 0")
	private Integer	jobRunCount_Daily;
	
	@Column(name = "jobRunCount_Weekly",columnDefinition = "int default 0")
	private Integer	jobRunCount_Weekly;
	
	@Column(name = "jobRunCount_Monthly",columnDefinition = "int default 0")
	private Integer	jobRunCount_Monthly;

	@Column(name = "jobRunCount_Others",columnDefinition = "int default 0")
	private Integer	jobRunCount_Others;

	public Integer getJobRunCount_Others() {
		return jobRunCount_Others;
	}

	public void setJobRunCount_Others(Integer jobRunCount_Others) {
		this.jobRunCount_Others = jobRunCount_Others;
	}

	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
		Id = id;
	}

	public long getRequestID() {
		return requestID;
	}

	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}

	public Integer getBackgroundJobCount() {
		return backgroundJobCount;
	}

	public void setBackgroundJobCount(Integer backgroundJobCount) {
		this.backgroundJobCount = backgroundJobCount;
	}

	public Integer getJobRunCount_Daily() {
		return jobRunCount_Daily;
	}

	public void setJobRunCount_Daily(Integer jobRunCount_Daily) {
		this.jobRunCount_Daily = jobRunCount_Daily;
	}

	public Integer getJobRunCount_Weekly() {
		return jobRunCount_Weekly;
	}

	public void setJobRunCount_Weekly(Integer jobRunCount_Weekly) {
		this.jobRunCount_Weekly = jobRunCount_Weekly;
	}

	public Integer getJobRunCount_Monthly() {
		return jobRunCount_Monthly;
	}

	public void setJobRunCount_Monthly(Integer jobRunCount_Monthly) {
		this.jobRunCount_Monthly = jobRunCount_Monthly;
	}
}

