package com.act.admin.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;

import com.act.admin.dao.AdminRequestMappingDAOImpl;
import com.act.constant.Hana_Profiler_Constant;
import com.act.exceptions.HibernateException;
import com.act.model.RolesAccess;
import com.act.poc.model.User;

public class RolesAccessDAOImpl implements RolesAccessDAO {

	final public Logger logger = LoggerFactory.getLogger(RolesAccessDAOImpl.class);
	private HibernateTemplate hibernateTemplate;

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<RolesAccess> getAllRoleAccess(String userId, Integer limit, Integer start) {
		try {
			return (List<RolesAccess>) hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {

					ProjectionList projection = Projections.projectionList();
					projection.add(Projections.property("rolesAccess.emailId"), "emailId");
					projection.add(Projections.property("rolesAccess.r_admin"), "r_admin");
					projection.add(Projections.property("rolesAccess.r_poc"), "r_poc");
					projection.add(Projections.property("rolesAccess.r_client"), "r_client");
					projection.add(Projections.property("rolesAccess.updatedBy"), "updatedBy");
					projection.add(Projections.property("rolesAccess.updatedOn"), "updatedOn");
					final Criteria criteria = session.createCriteria(RolesAccess.class, "rolesAccess");
					criteria.createAlias("rolesAccess.user", "user");
					
					criteria.add(Restrictions.eq("user.enabled", Boolean.TRUE));

					/*
					 * SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd"); Calendar
					 * calendar = Calendar.getInstance(); calendar.add(Calendar.DATE, 7);
					 */
					Date date = new Date();//calendar.getTime();
					java.sql.Date sqlDate = null;
					sqlDate = new java.sql.Date(date.getTime());
					criteria.add(Restrictions.ge("user.validTill", sqlDate));

					if (userId != null && !((userId.trim()).equalsIgnoreCase(""))) {
						criteria.add(Restrictions.eq("emailId", userId));
					}

					if (limit != null) {
						criteria.setMaxResults(limit);
					}
					if (start != null) {
						criteria.setFirstResult(start);
					}
					criteria.setProjection(projection);
					
					criteria.setResultTransformer(Transformers.aliasToBean(RolesAccess.class));
					return criteria.list();
				}
			});
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	@Override
	public Integer getAllRoleAccessCount() {
		try {
			Long count = (Long) hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {

					final Criteria criteria = session.createCriteria(RolesAccess.class, "rolesAccess");
					criteria.createAlias("rolesAccess.user", "user");
					
					criteria.add(Restrictions.eq("user.enabled", Boolean.TRUE));
					
					Date date = new Date();//calendar.getTime();
					java.sql.Date sqlDate = null;
					sqlDate = new java.sql.Date(date.getTime());
					criteria.add(Restrictions.ge("user.validTill", sqlDate));
					
					criteria.setProjection(Projections.rowCount());
					return criteria.uniqueResult();

				}
			});
			return count.intValue();
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
}
