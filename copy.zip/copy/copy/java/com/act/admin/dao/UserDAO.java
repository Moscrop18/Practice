package com.act.admin.dao;

import java.util.*;
import javax.servlet.http.HttpSession;

public interface UserDAO {

	public List<String> getUserNameList();
	public int getTotalInactiveUserCount(HttpSession session);
	public int getTotalExpiringSoonCount(HttpSession session);
	public int getTotalApprovedNewUserCount(HttpSession session);
	public int getTotalRejectedNewUserCount(HttpSession session);
	public int getTotalOverdueCount(HttpSession session);
}
