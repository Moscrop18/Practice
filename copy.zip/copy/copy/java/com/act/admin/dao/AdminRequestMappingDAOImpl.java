package com.act.admin.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.act.admin.model.AdminRequestDetailsBean;
import com.act.admin.model.SummaryAssessmentCount;
import com.act.client.dao.RequestInventoryDAO;
import com.act.client.model.RequestForm;
import com.act.client.model.RequestInventory;
import com.act.constant.Hana_Profiler_Constant;
import com.act.exceptions.HibernateException;
import com.act.model.StatusMaster;
import com.act.poc.dao.UserDAO;
import com.act.poc.model.User;
import com.act.utility.SendEmail;

@Transactional
public class AdminRequestMappingDAOImpl implements AdminRequestMappingDAO {

	final public Logger logger = LoggerFactory.getLogger(AdminRequestMappingDAOImpl.class);
	private HibernateTemplate hibernateTemplate;
	SessionFactory sessionFactory;
	RequestInventoryDAO requestInventoryDao;
	AdminRequestInventoryDAO adminRequestInventorydao;
	private Session session;

	public void setAdminRequestInventorydao(AdminRequestInventoryDAO adminRequestInventorydao) {
		this.adminRequestInventorydao = adminRequestInventorydao;
	}

	public void setRequestInventoryDao(RequestInventoryDAO requestInventoryDao) {
		this.requestInventoryDao = requestInventoryDao;
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@SuppressWarnings("unchecked")
	public List<StatusMaster> getStatusList() {
		try {
			final Session session = sessionFactory.getCurrentSession();
			final Criteria criteria = session.createCriteria(StatusMaster.class);
			criteria.add(Restrictions.eq("isClientStatus", 1));
			return criteria.list();
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	@SuppressWarnings("unchecked")

	public List<AdminRequestDetailsBean> getRequests(final String status, final Integer limit, final Integer start) {
		try {
			return (List<AdminRequestDetailsBean>) hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {

					ProjectionList projection = Projections.projectionList();
					projection.add(Projections.property("requestID"), "requestId");
					projection.add(Projections.property("REQUEST_ID_UI"), "request_id_ui");
					projection.add(Projections.property("requestStatus"), "status");
					projection.add(Projections.property("poc_status"), "poc_status");
					projection.add(Projections.property("poc_comments"), "poc_comments");
					projection.add(Projections.property("updatedDate"), "updatedDate");
					projection.add(Projections.property("assigned_poc_emailId"), "assigned_poc_emailId");

					final Criteria criteria = session.createCriteria(RequestInventory.class);

					if (Hana_Profiler_Constant.COMPLETED_PENDING_ESTIMATIONS.equalsIgnoreCase(status)) {
						criteria.add(Restrictions.and(
								Restrictions.eq("requestStatus", Hana_Profiler_Constant.HANAREFININGSUCCESS_STATUS),
								Restrictions.eq("poc_status", Hana_Profiler_Constant.FINAL_APPROVED_POC)));
					} else if (Hana_Profiler_Constant.COMPLETED_STATUS.equalsIgnoreCase(status)) {

						criteria.add(Restrictions.and(
								Restrictions.eq("requestStatus", Hana_Profiler_Constant.HANAREFININGCOMPLETED_STATUS),
								Restrictions.eq("poc_status", Hana_Profiler_Constant.COMPLETED_POC)));

					}
					if (limit != null) {
						criteria.setMaxResults(limit);
					}
					if (start != null) {
						criteria.setFirstResult(start);
					}

					criteria.setProjection(projection);
					criteria.addOrder(Order.desc("updatedDate"));

					criteria.setResultTransformer(Transformers.aliasToBean(AdminRequestDetailsBean.class));
					return criteria.list();
				}
			});
		} catch (Exception e) {
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AdminRequestDetailsBean> getCompletedWithPendingRequests(final String status, final Integer limit,
			final Integer start) {
		try {
			return (List<AdminRequestDetailsBean>) hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {

					ProjectionList projection = Projections.projectionList();
					projection.add(Projections.property("requestID"), "requestId");
					projection.add(Projections.property("REQUEST_ID_UI"), "request_id_ui");
					projection.add(Projections.property("requestStatus"), "status");
					projection.add(Projections.property("poc_status"), "poc_status");
					projection.add(Projections.property("pocFiatStatus"), "pocFiatStatus");
					projection.add(Projections.property("poc_comments"), "poc_comments");
					projection.add(Projections.property("updatedDate"), "updatedDate");
					projection.add(Projections.property("assigned_poc_emailId"), "assigned_poc_emailId");
					projection.add(Projections.property("assignedFaitEmailId"), "assignedFaitEmailId");
					projection.add(Projections.property("journeyCategory"), "journeyCategory");

					final Criteria criteria = session.createCriteria(RequestInventory.class);

					criteria.add(Restrictions.disjunction()

							.add(Restrictions.conjunction()
									.add(Restrictions.eq("poc_status", Hana_Profiler_Constant.FINAL_APPROVED_POC))
									.add(Restrictions.eq("journeyCategory", "S4_Only")))

							.add(Restrictions.conjunction()
									.add(Restrictions.eq("poc_status", Hana_Profiler_Constant.FINAL_APPROVED_POC))
									.add(Restrictions.eq("journeyCategory", "SR_SinglePOC")))

							.add(Restrictions.conjunction()
									.add(Restrictions.eq("poc_status", Hana_Profiler_Constant.FINAL_APPROVED_POC))
									.add(Restrictions.eq("pocFiatStatus", "FIAT_UPLOAD_DONE_POC"))
									.add(Restrictions.eq("journeyCategory", "SR_TwoPOC")))

					);

					if (limit != null) {
						criteria.setMaxResults(limit);
					}
					if (start != null) {
						criteria.setFirstResult(start);
					}

					criteria.setProjection(projection);
					criteria.addOrder(Order.desc("updatedDate"));

					criteria.setResultTransformer(Transformers.aliasToBean(AdminRequestDetailsBean.class));
					return criteria.list();
				}
			});
		} catch (Exception e) {
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public Integer getCompletedPendingRequestCount() {
		try {
			Long count = (Long) hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {

					final Criteria criteria = session.createCriteria(RequestInventory.class);

					criteria.add(Restrictions.disjunction()

							.add(Restrictions.conjunction()
									.add(Restrictions.eq("poc_status", Hana_Profiler_Constant.FINAL_APPROVED_POC))
									.add(Restrictions.eq("journeyCategory", "S4_Only")))

							.add(Restrictions.conjunction()
									.add(Restrictions.eq("poc_status", Hana_Profiler_Constant.FINAL_APPROVED_POC))
									.add(Restrictions.eq("journeyCategory", "SR_SinglePOC")))

							.add(Restrictions.conjunction()
									.add(Restrictions.eq("poc_status", Hana_Profiler_Constant.FINAL_APPROVED_POC))
									.add(Restrictions.eq("pocFiatStatus", Hana_Profiler_Constant.FIAT_UPLOAD_DONE_POC))
									.add(Restrictions.eq("journeyCategory", "SR_TwoPOC")))

					);

					criteria.setProjection(Projections.countDistinct("requestID"));
					return criteria.uniqueResult();
				}
			});

			return count.intValue();
		} catch (Exception e) {
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AdminRequestDetailsBean> getCompletedRequests(final String status, final Integer limit,
			final Integer start) {
		try {
			return (List<AdminRequestDetailsBean>) hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {

					ProjectionList projection = Projections.projectionList();
					projection.add(Projections.property("requestID"), "requestId");
					projection.add(Projections.property("REQUEST_ID_UI"), "request_id_ui");
					projection.add(Projections.property("requestStatus"), "status");
					projection.add(Projections.property("poc_status"), "poc_status");
					projection.add(Projections.property("pocFiatStatus"), "pocFiatStatus");
					projection.add(Projections.property("poc_comments"), "poc_comments");
					projection.add(Projections.property("updatedDate"), "updatedDate");
					projection.add(Projections.property("assigned_poc_emailId"), "assigned_poc_emailId");
					projection.add(Projections.property("assignedFaitEmailId"), "assignedFaitEmailId");
					projection.add(Projections.property("journeyCategory"), "journeyCategory");

					final Criteria criteria = session.createCriteria(RequestInventory.class);

					criteria.add(Restrictions.disjunction()

							.add(Restrictions.conjunction()
									.add(Restrictions.eq("poc_status", Hana_Profiler_Constant.COMPLETED_POC))
									.add(Restrictions.eq("journeyCategory", "S4_Only")))

							.add(Restrictions.conjunction()
									.add(Restrictions.eq("pocFiatStatus", Hana_Profiler_Constant.FIAT_UPLOAD_DONE_POC))
									.add(Restrictions.eq("journeyCategory", "FIAT_Only")))

							.add(Restrictions.conjunction()
									.add(Restrictions.eq("poc_status", Hana_Profiler_Constant.COMPLETED_POC))
									.add(Restrictions.eq("journeyCategory", "SR_SinglePOC")))

							.add(Restrictions.conjunction()
									.add(Restrictions.eq("poc_status", Hana_Profiler_Constant.COMPLETED_POC))
									.add(Restrictions.eq("pocFiatStatus", Hana_Profiler_Constant.FIAT_UPLOAD_DONE_POC))
									.add(Restrictions.eq("journeyCategory", "SR_TwoPOC")))

					);

					if (limit != null) {
						criteria.setMaxResults(limit);
					}
					if (start != null) {
						criteria.setFirstResult(start);
					}

					criteria.setProjection(projection);
					criteria.addOrder(Order.desc("updatedDate"));

					criteria.setResultTransformer(Transformers.aliasToBean(AdminRequestDetailsBean.class));
					return criteria.list();
				}
			});
		} catch (Exception e) {
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public Integer getCompletedRequestCount() {
		try {
			Long count = (Long) hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {

					final Criteria criteria = session.createCriteria(RequestInventory.class);

					criteria.add(Restrictions.disjunction()

							.add(Restrictions.conjunction()
									.add(Restrictions.eq("poc_status", Hana_Profiler_Constant.COMPLETED_POC))
									.add(Restrictions.eq("journeyCategory", "S4_Only")))

							.add(Restrictions.conjunction()
									.add(Restrictions.eq("pocFiatStatus", Hana_Profiler_Constant.FIAT_UPLOAD_DONE_POC))
									.add(Restrictions.eq("journeyCategory", "FIAT_Only")))

							.add(Restrictions.conjunction()
									.add(Restrictions.eq("poc_status", Hana_Profiler_Constant.COMPLETED_POC))
									.add(Restrictions.eq("journeyCategory", "SR_SinglePOC")))

							.add(Restrictions.conjunction()
									.add(Restrictions.eq("poc_status", Hana_Profiler_Constant.COMPLETED_POC))
									.add(Restrictions.eq("pocFiatStatus", Hana_Profiler_Constant.FIAT_UPLOAD_DONE_POC))
									.add(Restrictions.eq("journeyCategory", "SR_TwoPOC"))));

					criteria.setProjection(Projections.countDistinct("requestID"));
					return criteria.uniqueResult();
				}
			});

			return count.intValue();
		} catch (Exception e) {
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AdminRequestDetailsBean> getOverdueRequests(final String status, final Integer limit,
			final Integer start, final String currentDate) {
		try {

			List<AdminRequestDetailsBean> overDueRequest = new ArrayList<AdminRequestDetailsBean>();

			String hql = "select distinct ri.requestID as requestId,ri.REQUEST_ID_UI as request_id_ui  ,ri.createdDate as createdDate,ri.assigned_poc_emailId as assigned_poc_emailId,"
					+ " ri.assignedFaitEmailId as assignedFaitEmailId,ri.pocFiatStatus as pocFiatStatus,ri.poc_status as poc_status ,"
					+ "ri.journeyCategory  as journeyCategory,ri.updatedDate as updatedDate, rf.endDate as endDate from RequestInventory ri join ri.requestForm rf  "
					+ "where rf.endDate < :currentDate  and ("
					+ " (not ( poc_status in ('Final_APPROVED_POC', 'Completed_POC') ) and ri.journeyCategory='S4_Only') "
					+ "or " + "(not ( POC_FIAT_Status in ('FIAT_UPLOAD_DONE_POC') ) and ri.journeyCategory='FIAT_Only')"
					+ " or "
					+ "(not ( poc_status in ('Final_APPROVED_POC') )  and ri.journeyCategory='SR_SinglePOC')	"
					+ " or  "
					+ "(not ( poc_status in ('Final_APPROVED_POC', 'Completed_POC') and POC_FIAT_Status in( 'FIAT_UPLOAD_DONE_POC')) and ri.journeyCategory='SR_TwoPOC'))  "
					+ " order by updated_date desc";

			session = sessionFactory.openSession();
			Query query = session.createQuery(hql);
			query.setParameter("currentDate", currentDate);

			if (limit != null) {
				query.setMaxResults(limit);

			}
			if (start != null) {
				query.setFirstResult(start);
			}

			overDueRequest = query.setResultTransformer(Transformers.aliasToBean(AdminRequestDetailsBean.class)).list();

			logger.info("overdue list is populated...............");

			return overDueRequest;

		} catch (Exception e) {
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if(null !=session) {
				session.close();
			}
		}
	}

	@SuppressWarnings("unchecked")
	// @Override
	public List<AdminRequestDetailsBean> getOverdueRequests_SQL(final String status, final Integer limit,
			final Integer start, final String currentDate) {
		try {

			Integer limit1 = 3;
			Integer start1 = 0;
			List<AdminRequestDetailsBean> overDueRequest = new ArrayList<AdminRequestDetailsBean>();

			String sql = "select  ri.REQUEST_ID,ri.REQUEST_ID_UI, ri.createdDate,ri.assigned_poc_emailId,ri.assigned_Fait_EmailId,ri.poc_Fiat_Status,ri.POC_STATUS ,"
					+ "ri.journeyCategory,rf.END_DATE ,ri.updated_date from request_inventory ri join request_form rf on ri.REQUEST_ID=rf.REQUEST_ID "
					+ "where rf.END_DATE <  :currentDate  and (not ( poc_status in ('Final_APPROVED_POC', 'Completed_POC') ) and ri.journeyCategory='S4_Only')"
					+ " 	union  "
					+ "select  ri.REQUEST_ID,ri.REQUEST_ID_UI, ri.createdDate,ri.assigned_poc_emailId,ri.assigned_Fait_EmailId,ri.poc_Fiat_Status,ri.POC_STATUS ,"
					+ "ri.journeyCategory, rf.END_DATE ,ri.updated_date from request_inventory ri join request_form rf on ri.REQUEST_ID=rf.REQUEST_ID "
					+ "where rf.END_DATE <  :currentDate  and (not ( POC_FIAT_Status in ('FIAT_UPLOAD_DONE_POC') ) and ri.journeyCategory='FIAT_Only')  "
					+ "union "
					+ " select  ri.REQUEST_ID,ri.REQUEST_ID_UI, ri.createdDate,ri.assigned_poc_emailId,ri.assigned_Fait_EmailId,ri.poc_Fiat_Status,ri.POC_STATUS ,"
					+ "ri.journeyCategory, rf.END_DATE ,ri.updated_date from request_inventory ri join request_form rf on ri.REQUEST_ID=rf.REQUEST_ID "
					+ "where rf.END_DATE <  :currentDate  and (not ( poc_status in ('Final_APPROVED_POC') )  and ri.journeyCategory='SR_SinglePOC')  "
					+ "union  "
					+ "select  ri.REQUEST_ID,ri.REQUEST_ID_UI, ri.createdDate,ri.assigned_poc_emailId,ri.assigned_Fait_EmailId,ri.poc_Fiat_Status,ri.POC_STATUS ,"
					+ "ri.journeyCategory,rf.END_DATE ,ri.updated_date from request_inventory ri join request_form rf on ri.REQUEST_ID=rf.REQUEST_ID "
					+ "	where rf.END_DATE <  :currentDate  "
					+ "and 	not ( poc_status in ('Final_APPROVED_POC', 'Completed_POC') and POC_FIAT_Status  in( 'FIAT_UPLOAD_DONE_POC')) "
					+ "and ri.journeyCategory='SR_TwoPOC' " + "order by updated_date desc  limit :start,:limitValue";

			session = sessionFactory.openSession();
			Query query = session.createSQLQuery(sql);
			query.setParameter("currentDate", currentDate);
			query.setParameter("start", start1);
			query.setParameter("limitValue", limit1);
			overDueRequest = query.setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP).list();


			return overDueRequest;

		} catch (Exception e) {
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if(null != session) {
				session.close();
			}
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AdminRequestDetailsBean> getPendingRequest(final String status, final Integer limit,
			final Integer start) {
		try {
			return (List<AdminRequestDetailsBean>) hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {

					ProjectionList projection = Projections.projectionList();
					projection.add(Projections.property("requestID"), "requestId");
					projection.add(Projections.property("REQUEST_ID_UI"), "request_id_ui");
					projection.add(Projections.property("requestForm.endDate"), "endDate");
					projection.add(Projections.property("requestStatus"), "status");
					projection.add(Projections.property("poc_status"), "poc_status");
					projection.add(Projections.property("pocFiatStatus"), "pocFiatStatus");
					projection.add(Projections.property("poc_comments"), "poc_comments");
					projection.add(Projections.property("updatedDate"), "updatedDate");
					projection.add(Projections.property("assigned_poc_emailId"), "assigned_poc_emailId");
					projection.add(Projections.property("assignedFaitEmailId"), "assignedFaitEmailId");
					projection.add(Projections.property("requestForm.SOH"), "soh");
					projection.add(Projections.property("requestForm.fiori"), "fiori");
					projection.add(Projections.property("requestForm.UPGRADE"), "upgrade");
					projection.add(Projections.property("requestForm.s4Technical"), "s4Technical");
					projection.add(Projections.property("requestForm.s4Functional"), "s4Functional");
					projection.add(Projections.property("requestForm.UI5"), "ui5");
					projection.add(Projections.property("requestForm.RFP"), "rfp");
					projection.add(Projections.property("requestForm.sia"), "sia");
					projection.add(Projections.property("requestForm.osMig"), "osMig");
					projection.add(Projections.property("requestForm.bwUsage"), "bwUsage");
					projection.add(Projections.property("requestForm.bwTech"), "bwTech");
					projection.add(Projections.property("requestForm.grc"), "grc");
					projection.add(Projections.property("requestForm.EXT"), "EXT");
					final Criteria criteria = session.createCriteria(RequestInventory.class, "requestInventory");
					criteria.createAlias("requestInventory.requestForm", "requestForm");

					criteria.add(Restrictions.conjunction()
							.add(Restrictions.eq("requestStatus", Hana_Profiler_Constant.INITIATED_STATUS))
							.add(Restrictions.isNull("poc_status")).add(Restrictions.isNull("pocFiatStatus")));

					if (limit != null) {
						criteria.setMaxResults(limit);
					}
					if (start != null) {
						criteria.setFirstResult(start);
					}

					criteria.setProjection(projection);
					criteria.addOrder(Order.desc("updatedDate"));

					criteria.setResultTransformer(Transformers.aliasToBean(AdminRequestDetailsBean.class));

					return criteria.list();
				}
			});
		} catch (Exception e) {
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public Integer getPendingRequestCount(final String status) {
		try {
			Long count = (Long) hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {

					final Criteria criteria = session.createCriteria(RequestInventory.class, "requestInventory");
					criteria.createAlias("requestInventory.requestForm", "requestForm");
					criteria.add(Restrictions.conjunction()
							.add(Restrictions.eq("requestStatus", Hana_Profiler_Constant.INITIATED_STATUS))
							.add(Restrictions.isNull("poc_status")).add(Restrictions.isNull("pocFiatStatus")));
					criteria.setProjection(Projections.countDistinct("requestForm.requestID"));
					return criteria.uniqueResult();
				}
			});
			return count.intValue();
		} catch (Exception e) {
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);

		}
	}

	/*
	 * @SuppressWarnings("unchecked")
	 * 
	 * @Override public Integer getOverdueRequestCount(final String status, final
	 * String currentDate) { try { Long count = (Long) hibernateTemplate.execute(new
	 * HibernateCallback() { public Object doInHibernate(Session session) throws
	 * HibernateException {
	 * 
	 * final Criteria criteria = session.createCriteria(RequestInventory.class,
	 * "requestInventory"); criteria.createAlias("requestInventory.requestForm",
	 * "requestForm");
	 * 
	 * criteria.add(Restrictions.lt("requestForm.endDate", currentDate));
	 * 
	 * criteria.add(Restrictions.disjunction() .add(Restrictions.ne("poc_status",
	 * Hana_Profiler_Constant.FINAL_APPROVED_POC))
	 * .add(Restrictions.isNull("poc_status")));
	 * criteria.setProjection(Projections.countDistinct("requestForm.requestID"));
	 * return criteria.uniqueResult();
	 * 
	 * } }); return count.intValue(); } catch (Exception e) { 
	 * logger.error(e.getMessage()); logger.trace(e.getMessage()); throw new
	 * HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
	 * 
	 * } }
	 */

	@SuppressWarnings("unchecked")
	@Override
	public Long getOverdueRequestCount(final String status, final String currentDate) {
		Long count = 0L;
		try {
			String hql = "select count(ri.REQUEST_ID_UI) as totalRecords from RequestInventory ri join ri.requestForm rf "
					+ "where rf.endDate < :currentDate  and ("
					+ " (not ( poc_status in ('Final_APPROVED_POC', 'Completed_POC') ) and ri.journeyCategory='S4_Only') "
					+ "or " + "(not ( POC_FIAT_Status in ('FIAT_UPLOAD_DONE_POC') ) and ri.journeyCategory='FIAT_Only')"
					+ " or " + "(not ( poc_status in ('Final_APPROVED_POC') )  and ri.journeyCategory='SR_SinglePOC') "
					+ "or "
					+ "(not ( poc_status in ('Final_APPROVED_POC', 'Completed_POC') and POC_FIAT_Status in( 'FIAT_UPLOAD_DONE_POC')) and ri.journeyCategory='SR_TwoPOC')) "
					+ "order by updated_date desc";

			session = sessionFactory.openSession();
			Query query = session.createQuery(hql);
			query.setParameter("currentDate", currentDate);
			count = (Long) query.uniqueResult();
			return count;

		} catch (Exception e) {
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if(null != session) {
				session.close();
			}
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public Integer getTotalRequestCount(final String status) {
		try {
			Long count = (Long) hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {

					final Criteria criteria = session.createCriteria(RequestInventory.class);

					if (Hana_Profiler_Constant.COMPLETED_PENDING_ESTIMATIONS.equalsIgnoreCase(status)) {
						criteria.add(Restrictions.and(
								Restrictions.eq("requestStatus", Hana_Profiler_Constant.HANAREFININGSUCCESS_STATUS),
								Restrictions.eq("poc_status", Hana_Profiler_Constant.FINAL_APPROVED_POC)));
					} else if (Hana_Profiler_Constant.COMPLETED_STATUS.equalsIgnoreCase(status)) {

						criteria.add(Restrictions.and(
								Restrictions.eq("requestStatus", Hana_Profiler_Constant.HANAREFININGCOMPLETED_STATUS),
								Restrictions.eq("poc_status", Hana_Profiler_Constant.COMPLETED_POC)));

					}
					criteria.setProjection(Projections.countDistinct("requestID"));
					return criteria.uniqueResult();

				}
			});
			return count.intValue();
		} catch (Exception e) {
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<SummaryAssessmentCount> getSummaryAssessmentCount() {
		try {

			return (List<SummaryAssessmentCount>) hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {

					final Criteria criteria = session.createCriteria(RequestInventory.class);
					ProjectionList projection = Projections.projectionList();
					projection.add(Projections.groupProperty("requestStatus"), "requestStatus");
					projection.add(Projections.rowCount(), "countValue");

					criteria.setProjection(projection);
					criteria.setResultTransformer(Transformers.aliasToBean(SummaryAssessmentCount.class));

					return criteria.list();

				}
			});

		} catch (Exception e) {
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public Integer getUserStatusCount(final String userStatus) {
		try {
			Long count = (Long) hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {

					final Criteria criteria = session.createCriteria(User.class);

					if (Hana_Profiler_Constant.INACTIVE_USER.equalsIgnoreCase(userStatus)) {
						criteria.add(Restrictions.eq("enabled", Boolean.FALSE));
						criteria.add(Restrictions.eq("archiveFlag", Boolean.FALSE));
						criteria.add(Restrictions.eq("reject", Boolean.FALSE));
					}

					else if (Hana_Profiler_Constant.NEW_USER.equalsIgnoreCase(userStatus)) {

						criteria.add(Restrictions.eq("newUserFlag", Boolean.TRUE));

					} else if (Hana_Profiler_Constant.ACTIVE_USER.equalsIgnoreCase(userStatus)) {
						criteria.add(Restrictions.eq("enabled", Boolean.TRUE));

						SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
						Calendar calendar = Calendar.getInstance();
						calendar.add(Calendar.DATE, 7);
						Date date = calendar.getTime();
						java.sql.Date sqlDate = null;

						try {
							sqlDate = new java.sql.Date(dateFormat.parse(dateFormat.format(date)).getTime());
						} catch (ParseException e) {
							logger.error("Error !!! " + e);
						}
						criteria.add(Restrictions.le("validTill", sqlDate));
					}

					criteria.setProjection(Projections.rowCount());
					return criteria.uniqueResult();

				}
			});
			return count.intValue();
		} catch (Exception e) {
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	public void AssignPocDataStore(RequestForm form, String userName, String toolName, String valVersion) {
		try {

			// Saving Request Form Data
			hibernateTemplate.saveOrUpdate(form);

			// getting Request Inventory data
			RequestInventory requestInventoryObj = requestInventoryDao
					.saveRequestInventoryDataAssignPOC(form.getRequestID());

			boolean scopeHana = form.getSOH();
			boolean scopeS4 = form.getS4Technical();
			boolean scopeFIAT = form.getS4Functional();
			boolean scopeUI5 = form.getUI5();
			boolean scopeFiori = form.getFiori();
			boolean scopeAUCT = form.getUPGRADE();
			boolean scopeRFP = form.getRFP();
			boolean scopeOSMigration = form.getOsMig();
			boolean scopeExt = form.getEXT();

			String assigned_POC_emailId = form.getAssignedPocEmailId();
			String assignedFaitEmailId = form.getAssignedFaitEmailId();

			requestInventoryObj.setAssigned_poc_emailId(assigned_POC_emailId);
			requestInventoryObj.setAssignedFaitEmailId(assignedFaitEmailId);
			boolean anyScope = false;
			if (scopeHana || scopeS4 || scopeUI5 || scopeFiori || scopeAUCT || form.getSia() || scopeOSMigration || form.getBwUsage() || form.getBwTech() || form.getGrc()||scopeExt) {
				requestInventoryObj.setPoc_status("Initiated_POC");
				anyScope = true;
			}
			if (scopeFIAT) {
				requestInventoryObj.setPocFiatStatus("Initiated_POC");
				anyScope = true;
			}
			if(scopeRFP)
			{
				requestInventoryObj.setPoc_status("Initiated_POC");
				if(form.getValueRFP().equalsIgnoreCase("uploadRFPFile"))
				{
					requestInventoryObj.setRfpStatus(Hana_Profiler_Constant.RFP_CLIENT_PENDING_STATUS);
				}
				else
				{
					requestInventoryObj.setRfpStatus(Hana_Profiler_Constant.RFP_CLIENT_PROC_SUCCESS_STATUS);
				}
			}
			
			if(anyScope) {
				requestInventoryObj.setPocSubStatus(Hana_Profiler_Constant.REQ_SS_INI);
			}

			if (!(assigned_POC_emailId.equals("")) && assignedFaitEmailId.equals("")) {
				requestInventoryObj.setJourneyCategory("S4_Only");
			} else if (assigned_POC_emailId.equals("") && !(assignedFaitEmailId.equals(""))) {
				requestInventoryObj.setJourneyCategory("FIAT_Only");
			} else if (assigned_POC_emailId.equals(assignedFaitEmailId)) {
				requestInventoryObj.setJourneyCategory("SR_SinglePOC");
			} else if (!(assigned_POC_emailId.equals(assignedFaitEmailId))) {
				requestInventoryObj.setJourneyCategory("SR_TwoPOC");
			}
			if(!StringUtils.isNotBlank(requestInventoryObj.getS4ValidationVersion()) && StringUtils.isNotBlank(valVersion)) {
				requestInventoryObj.setS4ValidationVersion(valVersion);
			}
			
			if(form.getRFP()) {
				requestInventoryObj.setComments(Hana_Profiler_Constant.ASSIGN_POC_RFP);
			} else {
				requestInventoryObj.setComments(Hana_Profiler_Constant.ASSIGN_POC);
			}
			
			hibernateTemplate.saveOrUpdate(requestInventoryObj);
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	public void UpdateRejectedStatus(long requestId) {
		try {
			String status = "Rejected";
			// getting Request Inventory data
			RequestInventory requestInventoryObj = requestInventoryDao.saveRequestInventoryDataAssignPOC(requestId);
			requestInventoryObj.setRequestStatus(status);
			requestInventoryObj.setPocSubStatus(Hana_Profiler_Constant.REQ_SS_REJ);
			requestInventoryObj.setComments(Hana_Profiler_Constant.REJECT_REQ);
			hibernateTemplate.saveOrUpdate(requestInventoryObj);
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<User> getNewUserAccount(final Integer limit, final Integer start, String userId, String role,
			String project) {
		try {
			return (List<User>) hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {

					ProjectionList projection = Projections.projectionList();
					projection.add(Projections.property("emailId"), "emailId");
					projection.add(Projections.property("projectName"), "projectName");
					projection.add(Projections.property("userRoleValue"), "userRoleValue");
					projection.add(Projections.property("userRoleValue"), "userRoleValue");

					final Criteria criteria = session.createCriteria(User.class, "User");
					criteria.add(Restrictions.eq("newUserFlag", Boolean.TRUE));
					if (userId != null && !((userId.trim()).equalsIgnoreCase(""))) {
						criteria.add(Restrictions.eq("userName", userId));
					}
					if (role != null && !((role.trim()).equalsIgnoreCase(""))) {
						criteria.add(Restrictions.eq("userRoleValue", role));
					}
					if (project != null && !((project.trim()).equalsIgnoreCase(""))) {
						criteria.add(Restrictions.eq("projectName", project));
					}

					if (limit != null) {
						criteria.setMaxResults(limit);
					}
					if (start != null) {
						criteria.setFirstResult(start);
					}

					criteria.setProjection(projection);

					criteria.setResultTransformer(Transformers.aliasToBean(User.class));
					return criteria.list();
				}
			});
		} catch (Exception e) {
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public void updatePocDataStore(RequestForm form) {
		try {

			// Updating Request Form Data
			hibernateTemplate.saveOrUpdate(form);
			// getting Request Inventory data
			RequestInventory requestInventoryObj = requestInventoryDao
					.saveRequestInventoryDataAssignPOC(form.getRequestID());

			String assigned_POC_emailId = form.getAssignedPocEmailId();
			String assignedFaitEmailId = form.getAssignedFaitEmailId();

			requestInventoryObj.setAssigned_poc_emailId(assigned_POC_emailId);
			requestInventoryObj.setAssignedFaitEmailId(assignedFaitEmailId);
			hibernateTemplate.saveOrUpdate(requestInventoryObj);
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<AdminRequestDetailsBean> getRequestManagementRequests(Integer limit, Integer start) {
		try {

			List<AdminRequestDetailsBean> requestManagementRequests = new ArrayList<AdminRequestDetailsBean>();
			String hql = "select distinct ri.requestID as requestId, ri.REQUEST_ID_UI as request_id_ui, ri.createdDate as createdDate, ri.updatedDate as updatedDate, ri.assigned_poc_emailId as assigned_poc_emailId,"
					+ " ri.assignedFaitEmailId as assignedFaitEmailId, ri.pocFiatStatus as pocFiatStatus, ri.poc_status as poc_status, ri.comments as comments"
					+ " from RequestInventory ri join ri.requestForm rf  " + " order by updatedDate desc";
			session = sessionFactory.openSession();
			Query query = session.createQuery(hql);
			if (limit != null) {
				query.setMaxResults(limit);
			}
			if (start != null) {
				query.setFirstResult(start);
			}
			requestManagementRequests = query.setResultTransformer(Transformers.aliasToBean(AdminRequestDetailsBean.class)).list();
			logger.info("Request Management list is populated...............");
			return requestManagementRequests;

		} catch (Exception e) {
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if (null != session) {
				session.close();
			}
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public Integer getRequestManagementRequestsCount() {
		Long count = 0L;
		try {
			String hql = "select count(ri.REQUEST_ID_UI) as totalRecords from RequestInventory ri join ri.requestForm rf"
					+ " order by ri.createdDate desc";
			session = sessionFactory.openSession();
			Query query = session.createQuery(hql);
			count = (Long) query.uniqueResult();
			return count.intValue();
		} catch (Exception e) {
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if (null != session) {
				session.close();
			}
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<User> getInactiveUsers(final String userStatus, final String uiserId, final String expiresOn,
			final Integer limit, final Integer start) {
		try {
			return (List<User>) hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {
					ProjectionList projection = Projections.projectionList();
					projection.add(Projections.property("emailId"), "emailId");
					/* projection.add(Projections.property("clientName"), "clientName"); */
					projection.add(Projections.property("createdOn"), "createdOn");
					/* projection.add(Projections.property("enabled"), "enabled"); */
					projection.add(Projections.property("projectName"), "projectName");
					projection.add(Projections.property("reset"), "reset");
					projection.add(Projections.property("userName"), "userName");
					projection.add(Projections.property("validTill"), "validTill");
					/*
					 * projection.add(Projections.property("archiveFlag"), "archiveFlag");
					 * projection.add(Projections.property("newUserFlag"), "newUserFlag");
					 * projection.add(Projections.property("reject"), "reject");
					 */

					final Criteria criteria = session.createCriteria(User.class);

					if (Hana_Profiler_Constant.INACTIVE_USER.equalsIgnoreCase(userStatus)) {
						criteria.add(Restrictions.eq("enabled", Boolean.FALSE));
						criteria.add(Restrictions.eq("archiveFlag", Boolean.FALSE));
						criteria.add(Restrictions.eq("reject", Boolean.FALSE));
					}

					else if (Hana_Profiler_Constant.NEW_USER.equalsIgnoreCase(userStatus)) {

						criteria.add(Restrictions.eq("newUserFlag", Boolean.TRUE));

					}

					if (uiserId != null) {
						criteria.add(Restrictions.eq("emailId", uiserId));
					}
					if (expiresOn != null) {
						java.sql.Date sqlDate = java.sql.Date.valueOf(expiresOn);
						criteria.add(Restrictions.eq("validTill", sqlDate));
					}
					if (limit != null) {
						criteria.setMaxResults(limit);
					}
					if (start != null) {
						criteria.setFirstResult(start);
					}

					criteria.setProjection(projection);
					criteria.addOrder(Order.desc("createdOn"));

					criteria.setResultTransformer(Transformers.aliasToBean(User.class));
					return criteria.list();
				}
			});
		} catch (Exception e) {
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<User> getExpireUsers(String userStatus, String uiserId, String expiresOn, Integer limit,
			Integer start) {

		try {
			return (List<User>) hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {
					ProjectionList projection = Projections.projectionList();
					projection.add(Projections.property("emailId"), "emailId");
					projection.add(Projections.property("createdOn"), "createdOn");
					projection.add(Projections.property("validTill"), "validTill");
					projection.add(Projections.property("projectName"), "projectName");
					projection.add(Projections.property("reset"), "reset");
					projection.add(Projections.property("userName"), "userName");

					final Criteria criteria = session.createCriteria(User.class);

					if (Hana_Profiler_Constant.ACTIVE_USER.equalsIgnoreCase(userStatus)) {
						criteria.add(Restrictions.eq("enabled", Boolean.TRUE));

						SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
						Calendar calendar = Calendar.getInstance();
						Date currentDate = calendar.getTime();
						calendar.add(Calendar.DATE, 7);					
						
						Date date = calendar.getTime();
						java.sql.Date sqlDate = null;
						java.sql.Date currenDate = null;

						try {
							sqlDate = new java.sql.Date(dateFormat.parse(dateFormat.format(date)).getTime());
							currenDate = new java.sql.Date(dateFormat.parse(dateFormat.format(currentDate)).getTime());
						} catch (ParseException e) {
							logger.error("Error !!! " + e);
						}
						criteria.add(Restrictions.ge("validTill", currenDate));
						criteria.add(Restrictions.lt("validTill", sqlDate));
					}
					if (uiserId != null) {
						criteria.add(Restrictions.eq("emailId", uiserId));
					}

					if (limit != null) {
						criteria.setMaxResults(limit);
					}

					if (expiresOn != null) {
						java.sql.Date sqlDate = java.sql.Date.valueOf(expiresOn);
						criteria.add(Restrictions.eq("validTill", sqlDate));
					}

					if (start != null) {
						criteria.setFirstResult(start);
					}

					criteria.setProjection(projection);
					criteria.addOrder(Order.desc("createdOn"));

					criteria.setResultTransformer(Transformers.aliasToBean(User.class));
					return criteria.list();
				}
			});
		} catch (Exception e) {
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);

		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<User> getActiveUsers(String userStatus, final String uiserId, final Integer limit, final Integer start) {
		try {
			return (List<User>) hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {
					ProjectionList projection = Projections.projectionList();
					projection.add(Projections.property("emailId"), "emailId");
					projection.add(Projections.property("userRoleValue"), "userRoleValue");

					final Criteria criteria = session.createCriteria(User.class);

					if (Hana_Profiler_Constant.ACTIVE_USER.equalsIgnoreCase(userStatus)) {
						criteria.add(Restrictions.eq("enabled", Boolean.TRUE));
					}
					if (uiserId != null) {
						criteria.add(Restrictions.eq("emailId", uiserId));
					}
					if (limit != null) {
						criteria.setMaxResults(limit);
					}
					if (start != null) {
						criteria.setFirstResult(start);
					}

					criteria.setProjection(projection);
					criteria.addOrder(Order.desc("createdOn"));

					criteria.setResultTransformer(Transformers.aliasToBean(User.class));
					return criteria.list();
				}
			});
		} catch (Exception e) {
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);

		}
	}

	@Override
	public void performActionOnUser(final String userName, final String userAction, String userRole, UserDAO userDao,
			HttpServletRequest request, HttpSession session) throws HibernateException {
		try {

			// getting User data
			User user = userDao.getUser(userName);
			// Activate, Approve, Extend, Reject, Archive

			if (userAction.equals(Hana_Profiler_Constant.USERREQUEST_ACTION_APPROVE)) {
				user.setEnabled(Boolean.TRUE);
				user.setNewUserFlag(Boolean.FALSE);
				user.setUserRoleValue(userRole);
				extendUserValidity(user, request, session);
				userDao.saveUserData(user, userRole);
			} else if (userAction.equals(Hana_Profiler_Constant.USERREQUEST_ACTION_ACTIVATE)) {
				user.setEnabled(Boolean.TRUE);
				user.setArchiveFlag(Boolean.FALSE);
				user.setReject(Boolean.FALSE);
				extendUserValidity(user, request, session);
				hibernateTemplate.saveOrUpdate(user);
			} else if (userAction.equals(Hana_Profiler_Constant.USERREQUEST_ACTION_EXTEND)) {
				user.setEnabled(Boolean.TRUE);
				user.setArchiveFlag(Boolean.FALSE);
				extendUserValidity(user, request, session);
				hibernateTemplate.saveOrUpdate(user);
			} else if (userAction.equals(Hana_Profiler_Constant.USERREQUEST_ACTION_REJECT)) {
				// user.setValidTill(null);
				// endUserValidity(user);
				user.setReject(Boolean.TRUE);
				user.setNewUserFlag(Boolean.FALSE);
				sendEmailForAccountRejection(user, request, session);
				hibernateTemplate.saveOrUpdate(user);
			} else if (userAction.equals(Hana_Profiler_Constant.USERREQUEST_ACTION_ARCHIVE)) {
				user.setArchiveFlag(Boolean.TRUE);
				user.setEnabled(Boolean.FALSE);
				hibernateTemplate.saveOrUpdate(user);
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	
	protected void sendEmailForAccountRejection(User user, HttpServletRequest request,
			HttpSession session) {
		
		String emailId = user.getEmailId();

		Set<String> emailData = new HashSet<String>();
		Set<String> emailCc = new HashSet<String>();
		SendEmail email = new SendEmail();

		email.setMailFrom("");
		emailData.add(emailId);
		emailCc.add("");
		email.setMailTo(emailData);
		email.setMailCC(emailCc);

		email.setMailSubject("Activation Request Rejected - " + emailId.substring(0, emailId.indexOf('@')));
		
		email.setMailBody(
				"\n\nDear " + emailId + ",\n\nYour Account Activation Request"
						+ " has been rejected by the admin." + "\n\nRegards,\nS/4HANA conversion Team ATCI");
		email.emailSend(email, request, session);

	}

	protected void sendEmailForAccountActivation(String emailId, java.sql.Date sqValidTill, HttpServletRequest request,
			HttpSession session) {

		Set<String> emailData = new HashSet<String>();
		Set<String> emailCc = new HashSet<String>();
		SendEmail email = new SendEmail();

		email.setMailFrom("");
		emailData.add(emailId);
		emailCc.add("");
		email.setMailTo(emailData);
		email.setMailCC(emailCc);

		email.setMailSubject("Account Activation Completed - " + emailId.substring(0, emailId.indexOf('@')));

		email.setMailBody("\n\nDear " + emailId.substring(0, emailId.indexOf('@'))
				+ " ,\n\nYour account vailidity has been extended till " + sqValidTill
				+ "\n\nRegards,\nS/4HANA conversion Team ATCI");
		email.emailSend(email, request, session);

	}

	public void extendUserValidity(User user, HttpServletRequest request, HttpSession session) {
		String email = user.getEmailId();
		logger.info("Inside extendUserValidity method - email is being sent for the user");
		String userRole = user.getUserRoleValue();// getUserRoledao().getUserRoles(email).get(0).getUserRole();
		Calendar calendar = Calendar.getInstance();
		if (userRole.equalsIgnoreCase(Hana_Profiler_Constant.CLIENT_ROLE)) {
			logger.info("Inside extendUserValidity method -- if loop for extending client validity");
			// Extend the CLient Account validity for 3 months.
			calendar.add(Calendar.MONTH, 3);
		} else {
			logger.info("Inside extendUserValidity method -- else loop for extending admin/poc validity");
			// Extend Admin account validity for 1 years.
			calendar.add(Calendar.YEAR, 1);
		}
		Date validTill = new Date(calendar.getTimeInMillis());
		java.sql.Date sqValidTill = new java.sql.Date(validTill.getTime());
		user.setValidTill(sqValidTill);

		try {
			sendEmailForAccountActivation(email, sqValidTill, request, session);
		} catch (Exception e) {
			logger.error("Error !!! " + e.getMessage());
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public Integer getActiveUserCount() {
		try {
			Long count = (Long) hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {

					final Criteria criteria = session.createCriteria(User.class);
					criteria.add(Restrictions.eq("enabled", Boolean.TRUE));
					
					criteria.setProjection(Projections.rowCount());
					return criteria.uniqueResult();

				}
			});
			return count.intValue();
		} catch (Exception e) {
			logger.error("Error !!! " + e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);

		}
	}
	
	@Override
	public void changeUserRole(final String userName, String userRole, UserDAO userDao,
			HttpServletRequest request, HttpSession session) throws HibernateException {
		try {

			// getting User data
			User user = userDao.getUser(userName);
				user.setUserRoleValue(userRole);
				userDao.saveUserData(user, userRole);
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	
	@Override
	public void updateClientUser(Long requestId, String user) {
		try {
		RequestInventory requestInventoryObj = requestInventoryDao
				.saveRequestInventoryDataAssignPOC(requestId);
		requestInventoryObj.setCreatorUser(user);
		hibernateTemplate.saveOrUpdate(requestInventoryObj);
		
		adminRequestInventorydao.updateClientUserPocRequestMapping(requestId, user);
		} catch (Exception e) {
			logger.error("updateClientUser :: ",e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
}
