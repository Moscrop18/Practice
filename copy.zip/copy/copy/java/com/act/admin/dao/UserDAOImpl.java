package com.act.admin.dao;


import java.sql.Date;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.act.constant.Hana_Profiler_Constant;
import com.act.displaygrid.model.DBConfig;
import com.act.exceptions.HibernateException;
import com.act.poc.model.User;
import com.act.poc.model.UserRole;

@Transactional
public class UserDAOImpl implements UserDAO {

	final Logger logger = LoggerFactory.getLogger(UserDAOImpl.class);
	SessionFactory sessionFactory;
	UserRole userRole;
	java.sql.Connection conn = null;
	java.sql.PreparedStatement stmt = null;


	public void setUserRole(UserRole userRole) {
		this.userRole = userRole;

	}

	public void setSessionFactory(SessionFactory sessionFactory) {

		this.sessionFactory = sessionFactory;
	}



	@SuppressWarnings("unchecked")
	public List<String> getUserNameList() {
		try{
		final Session session=sessionFactory.getCurrentSession();
		
		final Criteria criteria = session.createCriteria(User.class,"user");
		criteria.createAlias("user.userRole", "userRole");
		criteria.add(Restrictions.eq("user.enabled", true));
		//CR-21: Changed USER role to POC.
		criteria.add(Restrictions.in("userRole.userRole", new String[]{Hana_Profiler_Constant.POC_ROLE,Hana_Profiler_Constant.ADMIN_ROLE}));
		criteria.setProjection(Projections.distinct(Projections.property("user.userName")));
		criteria.addOrder(Order.asc("user.userName"));
		return criteria.list();
		} catch(Exception e) {
			logger.error(e.getMessage());
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}
	
	@Override
	public int getTotalInactiveUserCount(HttpSession session){
		
		int inactivecount=0;
		int enable = 0;
		int archiveflag =0;
		try{
			 String SQL_QUERY = "SELECT COUNT(*) FROM  hanadbjune.user where ENABLED='"+enable+"' and ARCHIVE_FLAG='"+archiveflag+"' and  ACCOUNT_VALID_TILL < CURDATE()";
		conn = DBConfig.getJDBCConnection(session);
		stmt = conn.prepareStatement(SQL_QUERY);
			ResultSet rs=stmt.executeQuery(SQL_QUERY);			
			//Extact result from ResultSet rs
		    	while(rs.next()){
				inactivecount =rs.getInt("COUNT(*)");
			}
			// close ResultSet rs
			rs.close();	
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		return inactivecount;
	}
	
	
@Override	
public int getTotalExpiringSoonCount(HttpSession session){
			
		int expiringsoonount=0;
		int enable = 1;
		int archiveflag =0;		
		try{
			 String SQL_QUERY = "select count(*) from hanadbjune.user where ENABLED='"+enable+"'  and  ACCOUNT_VALID_TILL -7 < CURDATE()";
		conn = DBConfig.getJDBCConnection(session);
		stmt = conn.prepareStatement(SQL_QUERY);
			ResultSet rs=stmt.executeQuery(SQL_QUERY);			
			//Extact result from ResultSet rs
		    	while(rs.next()){
		    		expiringsoonount =rs.getInt("COUNT(*)");
			}
			// close ResultSet rs
			rs.close();	
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		return expiringsoonount;
	}

@Override	
public int getTotalApprovedNewUserCount(HttpSession session){
				
		int approvednewusercount=0;
		int enable = 1;
		int newuserflag =0;
		int archiveflag =0;
		try{
			 String SQL_QUERY = "select count(*) from hanadbjune.user where ENABLED='"+enable+"' and NEW_USER_FLAG='"+newuserflag+"' and  ACCOUNT_VALID_TILL  >= CURDATE()";
		conn = DBConfig.getJDBCConnection(session);
		stmt = conn.prepareStatement(SQL_QUERY);
			ResultSet rs=stmt.executeQuery(SQL_QUERY);			
			//Extact result from ResultSet rs
		    	while(rs.next()){
		    		approvednewusercount =rs.getInt("COUNT(*)");
			}
			// close ResultSet rs
			rs.close();	
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		return approvednewusercount;
	}

@Override	
public int getTotalRejectedNewUserCount(HttpSession session){
				
		int rejectednewusercount=0;
		int enable = 0;
		int newuserflag =0;
		int archiveflag =0;
		try{
			 String SQL_QUERY = "select count(*) from hanadbjune.user where NEW_USER_FLAG='"+newuserflag+"' and  ACCOUNT_VALID_TILL = null";
		conn = DBConfig.getJDBCConnection(session);
		stmt = conn.prepareStatement(SQL_QUERY);
			ResultSet rs=stmt.executeQuery(SQL_QUERY);			
			//Extact result from ResultSet rs
		    	while(rs.next()){
		    		rejectednewusercount =rs.getInt("COUNT(*)");
			}
			// close ResultSet rs
			rs.close();	
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		return rejectednewusercount;
	}

@Override	
public int getTotalOverdueCount(HttpSession session){
				
		int overduecount=0;
		String REQUEST_STATUS ="HANARefiningSuccess";
		String POC_STATUS = "Final_APPROVED_POC";
		int enable = 0;
		int newuserflag =0;
		int archiveflag =0;
		try{
			 String SQL_QUERY = "SELECT  COUNT(*)\r\n" + 
			 		"FROM    request_form a\r\n" + 
			 		"        INNER JOIN request_inventory b\r\n" + 
			 		"            ON a.REQUEST_ID_UI = b.REQUEST_ID_UI \r\n" + 
			 		"WHERE   a.END_DATE < (CURDATE()) and b.REQUEST_STATUS = '"+REQUEST_STATUS+"' and b.POC_STATUS = '"+POC_STATUS+"'";
		conn = DBConfig.getJDBCConnection(session);
		stmt = conn.prepareStatement(SQL_QUERY);
			ResultSet rs=stmt.executeQuery(SQL_QUERY);			
			//Extact result from ResultSet rs
		    	while(rs.next()){
		    		overduecount =rs.getInt("COUNT(*)");
			}
			// close ResultSet rs
			rs.close();	
		} catch(Exception e) {
			logger.error(e.getMessage());
			logger.error("Error !!! " + e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		return overduecount;
	}
}
