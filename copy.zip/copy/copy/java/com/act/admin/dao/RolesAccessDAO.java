package com.act.admin.dao;

import java.util.List;

import com.act.model.RolesAccess;

public interface RolesAccessDAO {
	public List<RolesAccess> getAllRoleAccess(final String userId, final Integer limit, final Integer start);
	public Integer getAllRoleAccessCount();

	// public RolesAccess getUserRoleAccess(String emailId);

	// public Boolean updateUserRoleAccess(String emailId);
}
