package com.act.admin.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.act.S4.models.FileStore;
import com.act.S4.models.S4ValidationFile;

public interface AdminSimplificationService {

	public String adminS4ValidatinUploadList(S4ValidationFile s4ValidationFile,
			final RedirectAttributes redirectAttributes, Model model, final HttpServletRequest request,
			HttpSession session, MultipartFile file) throws Exception;

	public String createZipS4ValidationFile(String filePath, String filename);

	public void addS4ValidationFile(String filePath, String filename, HttpSession session);

	public void addPreRequisiteFile(String filePath, String fileName, HttpSession session, String fileNameKey);

	public String adminPreRequisiteUpload(FileStore fileStore, final RedirectAttributes redirectAttributes, Model model,
			final HttpServletRequest request, HttpSession session, MultipartFile file) throws Exception;

	public String adminReviewChecklistUpload(FileStore fileStore, final RedirectAttributes redirectAttributes,
			Model model, final HttpServletRequest request, HttpSession session, MultipartFile file) throws Exception;

	public void addReviewChecklistFile(String filePath, String fileName, HttpSession session, String fileNameKey);

	public String adminTCDSimplificationUpload(FileStore fileStore, final RedirectAttributes redirectAttributes,
			Model model, final HttpServletRequest request, HttpSession session, MultipartFile file) throws Exception;

	public String adminTargetUsobtcUpload(FileStore fileStore, final RedirectAttributes redirectAttributes, Model model,
			final HttpServletRequest request, HttpSession session, MultipartFile file) throws Exception;

	public String adminGRCMasterdataUpload(FileStore fileStore, final RedirectAttributes redirectAttributes,
			Model model, final HttpServletRequest request, HttpSession session, MultipartFile file) throws Exception;

	public String adminTCodeSubProcessMappingFile(HttpSession session, MultipartFile file) throws Exception;
	
	public String adminAppCompSubProcessMappingFile(HttpSession session, MultipartFile file) throws Exception;
	
	public String adminBwExtractMasterUpload(FileStore fileStore,final RedirectAttributes redirectAttributes,Model model,final HttpServletRequest request, HttpSession session, MultipartFile file)throws Exception;
	public String adminFioriRebuildUpload(FileStore fileStore, RedirectAttributes redirectAttributes, Model model,
			HttpServletRequest request, HttpSession session, MultipartFile file) throws Exception;
}
