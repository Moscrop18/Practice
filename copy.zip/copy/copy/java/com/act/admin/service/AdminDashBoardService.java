package com.act.admin.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;

import com.act.admin.dao.AdminRequestInventoryDAO;
import com.act.admin.dao.AdminRequestMappingDAO;
import com.act.admin.model.AdminRequestDetailsBean;
import com.act.admin.model.SummaryAssessmentCount;
import com.act.client.model.RequestForm;
import com.act.constant.Hana_Profiler_Constant;
import com.act.poc.dao.UserDAO;
import com.act.poc.model.User;

@Transactional
public class AdminDashBoardService implements AdminDashBoard {

	public AdminRequestMappingDAO daoobj;
	public AdminRequestInventoryDAO requestInventory;
	final public Logger logger = LoggerFactory.getLogger(AdminDashBoardService.class);

	public void setRequestInventory(AdminRequestInventoryDAO requestInventory) {
		this.requestInventory = requestInventory;
	}

	public void setDaoobj(AdminRequestMappingDAO daoobj) {
		this.daoobj = daoobj;
	}

	/*
	 * @Override public List<AdminRequestDetailsBean> getClientRequests(final String
	 * status, final Integer limit, final Integer start) {
	 * 
	 * List<AdminRequestDetailsBean> clientRequest = daoobj.getRequests(status,
	 * limit, start);
	 * 
	 * for (AdminRequestDetailsBean clientReq : clientRequest) {
	 * 
	 * if
	 * (Hana_Profiler_Constant.COMPLETED_PENDING_ESTIMATIONS.equalsIgnoreCase(status
	 * )) {
	 * clientReq.setStatus(Hana_Profiler_Constant.COMPLETED_PENDING_ESTIMATIONS); }
	 * else if (Hana_Profiler_Constant.COMPLETED_STATUS.equalsIgnoreCase(status)) {
	 * clientReq.setStatus(Hana_Profiler_Constant.COMPLETED_STATUS); }
	 * 
	 * } return clientRequest;
	 * 
	 * }
	 */

	@Override
	public List<AdminRequestDetailsBean> getCompletedRequests(final String status, final Integer limit,
			final Integer start) {

		List<AdminRequestDetailsBean> completedRequest = daoobj.getCompletedRequests(status, limit, start);

		for (AdminRequestDetailsBean clientReq : completedRequest) {
			clientReq.setStatus(Hana_Profiler_Constant.COMPLETED_STATUS);

		}
		return completedRequest;

	}

	@Override
	public List<AdminRequestDetailsBean> getCompletedwithPendingRequests(final String status, final Integer limit,
			final Integer start) {

		List<AdminRequestDetailsBean> cpeRequest = daoobj.getCompletedWithPendingRequests(status, limit, start);

		for (AdminRequestDetailsBean clientReq : cpeRequest) {
			clientReq.setStatus(Hana_Profiler_Constant.COMPLETED_PENDING_ESTIMATIONS);

		}
		return cpeRequest;

	}

	@Override
	public List<AdminRequestDetailsBean> getPendingRequest(final String status, final Integer limit,
			final Integer start) {
		List<AdminRequestDetailsBean> pendingRequest = daoobj.getPendingRequest(status, limit, start);
		for (AdminRequestDetailsBean pendingReq : pendingRequest) {
			if (pendingReq.getS4Functional()) {
				pendingReq.setFiatScope(Boolean.TRUE);

			} else {
				pendingReq.setFiatScope(Boolean.FALSE);
			}
			if (pendingReq.getSoh() || pendingReq.getS4Technical()
					|| pendingReq.getFiori() || pendingReq.getUi5() || pendingReq.getUpgrade() || pendingReq.getRfp() || 
					pendingReq.getSia() || pendingReq.getOsMig() || pendingReq.getBwTech() || pendingReq.getBwUsage()|| pendingReq.getGrc()||pendingReq.getEXT()) {
				pendingReq.setOtherScope(Boolean.TRUE);
			} else {
				pendingReq.setOtherScope(Boolean.FALSE);
			}

		}

		return pendingRequest;
	}
	
	@Override
	public void requestFormUpdatePoc(RequestForm form) {
		daoobj.updatePocDataStore(form);
	}

	
	@Override
	public List<AdminRequestDetailsBean> getRequestManagementRequests(Integer limit, Integer start) {
		return daoobj.getRequestManagementRequests(limit, start);
	}

	@Override
	public List<AdminRequestDetailsBean> getOverDueRequests(final String status, final Integer limit,
			final Integer start) {
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy");

		String currentDate = now.format(formatter);
		List<AdminRequestDetailsBean> overdueRequest = daoobj.getOverdueRequests(status, limit, start, currentDate);
		for (AdminRequestDetailsBean overdueReq : overdueRequest) {
			overdueReq.setStatus("In-Progress");
		}

		return overdueRequest;

	}

	/*
	 * @Override public Integer getTotalRequestCount(String status) { return
	 * daoobj.getTotalRequestCount(status); }
	 */

	@Override
	public Integer getCompletedRequestCount() {

		return daoobj.getCompletedRequestCount();

	}

	@Override
	public Integer getCompletedPendingRequestCount() {

		return daoobj.getCompletedPendingRequestCount();
	}

	@Override
	public Long getOverdueRequestCount(String status) {
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy");

		String currentDate = now.format(formatter);
		return daoobj.getOverdueRequestCount(status, currentDate);
	}
	
	@Override
	public Integer getRequestManagementRequestsCount() {
		return daoobj.getRequestManagementRequestsCount();
	}

	@Override
	public Integer getPendingRequestCount(String status) {
		return daoobj.getPendingRequestCount(status);
	}

	@Override
	public Map<String, Integer> getAdminDashboardCount() {
		Map<String, Integer> countsMap = new HashMap<String, Integer>();

		List<SummaryAssessmentCount> summaryAssessmentCntList = daoobj.getSummaryAssessmentCount();

		int totalCount = 0;
		if (CollectionUtils.isNotEmpty(summaryAssessmentCntList)) {
			for (SummaryAssessmentCount summaryObj : summaryAssessmentCntList) {

				String requestStatus = summaryObj.getRequestStatus();
				int requestCount = ((Long) summaryObj.getCountValue()).intValue();
				totalCount = totalCount + requestCount;
				if (Hana_Profiler_Constant.INITIATED_STATUS.equalsIgnoreCase(summaryObj.getRequestStatus())) {
					countsMap.put(Hana_Profiler_Constant.INITIATED_STATUS, requestCount);
				} else if (Hana_Profiler_Constant.APPROVED_STATUS.equalsIgnoreCase(requestStatus)) {
					countsMap.put(Hana_Profiler_Constant.APPROVED_STATUS, requestCount);
				} else if (Hana_Profiler_Constant.REJECTED_STATUS.equalsIgnoreCase(requestStatus)) {
					countsMap.put(Hana_Profiler_Constant.REJECTED_STATUS, requestCount);
				}

			}
		}

			if (totalCount > 0) {
				countsMap.put("Total", totalCount);
			}

			Integer newUserCount = 0;
			newUserCount = daoobj.getUserStatusCount(Hana_Profiler_Constant.NEW_USER);
			if (newUserCount != null) {
				countsMap.put(Hana_Profiler_Constant.NEW_USER, newUserCount);
			}
			Integer inactiveUserCount = 0;
			inactiveUserCount = daoobj.getUserStatusCount(Hana_Profiler_Constant.INACTIVE_USER);
			if (newUserCount != null) {
				countsMap.put(Hana_Profiler_Constant.INACTIVE_USER, inactiveUserCount);
			}
			Integer requestManagementCount = 0;
			requestManagementCount = daoobj.getRequestManagementRequestsCount();
			if (requestManagementCount != null) {
				countsMap.put("RequestManagement", requestManagementCount);
			}

		return countsMap;
	}

	public void requestFormAssignPoc(RequestForm form, String userName, final String toolName, String valVer) {
		daoobj.AssignPocDataStore(form, userName, toolName, valVer);
	}

	public void UpdateRejectedStatus(long requestId) {
		daoobj.UpdateRejectedStatus(requestId);
	}

	@Override
	public List<User> getNewUserList(Integer limit, Integer start, String userId, String role, String project) {
		return daoobj.getNewUserAccount(limit, start, userId, role, project);
	}

	@Override
	public List<User> getInactiveUsers(final String userStatus, final String uiserId, final String expiresOn,
			final Integer limit, final Integer start) {
		List<User> users = daoobj.getInactiveUsers(userStatus, uiserId, expiresOn, limit, start);
		return users;
	}
	
	@Override
	public List<User> getActiveUsers(final String userStatus, final String uiserId, final Integer limit, final Integer start) {
		List<User> users = daoobj.getActiveUsers(userStatus, uiserId, limit, start);
		return users;
	}

	@Override
	public List<User> getExpireUsers(final String userStatus, final String uiserId, final String expiresOn,
			final Integer limit, final Integer start) {
		List<User> users = daoobj.getExpireUsers(userStatus, uiserId, expiresOn, limit, start);
		return users;
	}

	@Override
	public Integer getUserStatusCount(String userStatus) {
		return daoobj.getUserStatusCount(userStatus);
	}

	@Override
	public void performActionOnUser(final String userName, final String userAction, final String userRole, UserDAO userDao,
			HttpServletRequest request, HttpSession session) throws Exception {
		daoobj.performActionOnUser(userName, userAction, userRole, userDao, request, session);
	}
	
	@Override
	public Integer getActiveUserCount() {
		return daoobj.getActiveUserCount();
	}

	@Override
	public void changeUserRole(final String userName, final String userRole, UserDAO userDao,
			HttpServletRequest request, HttpSession session) throws Exception {
		daoobj.changeUserRole(userName, userRole, userDao, request, session);
	}
	
	@Override
	public void updateCreatorUser(Long requestId, String user) {
		daoobj.updateClientUser(requestId,user);
		
	}
}
