package com.act.admin.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.act.admin.model.AdminRequestDetailsBean;
import com.act.client.model.RequestForm;
import com.act.poc.dao.UserDAO;
import com.act.poc.model.User;

public interface AdminDashBoard {

	//public List<AdminRequestDetailsBean> getClientRequests(String status, Integer limit, Integer start);

	public List<AdminRequestDetailsBean> getOverDueRequests(String status, Integer limit, Integer start);

	public List<AdminRequestDetailsBean> getPendingRequest(String status, Integer limit, Integer start);

	//public Integer getTotalRequestCount(String status);

	public Long getOverdueRequestCount(String status);
	
	public Integer getRequestManagementRequestsCount();

	public Integer getPendingRequestCount(String status);

	public Map<String, Integer> getAdminDashboardCount();

	public void requestFormAssignPoc(RequestForm form, String userName, final String toolName, String valVersion);
	
	public void requestFormUpdatePoc(RequestForm form);
	
	public List<AdminRequestDetailsBean> getRequestManagementRequests(Integer limit, Integer start);

	public void UpdateRejectedStatus(long requestId);

	public List<User> getNewUserList(Integer limit, Integer start, String userId, String role, String project);

	public List<User> getInactiveUsers(String userStatus, String uiserId, String expiresOn, Integer limit,
			Integer start);
	public List<User> getActiveUsers(String userStatus, String uiserId, Integer limit, Integer start);

	public List<User> getExpireUsers(String userStatus, String uiserId, String expiresOn, Integer limit, Integer start);

	public Integer getUserStatusCount(String userStatus);

	public void performActionOnUser(final String userName, final String userAction, final String userRole, UserDAO userDao,
			HttpServletRequest request, HttpSession session) throws Exception;

	public List<AdminRequestDetailsBean> getCompletedwithPendingRequests(String status, Integer limit, Integer start);
	
	public List<AdminRequestDetailsBean> getCompletedRequests(String status, Integer limit, Integer start);

	public Integer getCompletedRequestCount();

	public Integer getCompletedPendingRequestCount();
	
	public Integer getActiveUserCount();

	public void changeUserRole(final String userName, final String userRole, UserDAO userDao,
				HttpServletRequest request, HttpSession session) throws Exception;
	
	public void updateCreatorUser(Long requestId, String user);
}
