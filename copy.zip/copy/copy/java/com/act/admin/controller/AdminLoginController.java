package com.act.admin.controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.json.simple.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.act.S4.Controller.S4ProcessingController;
import com.act.S4.models.FileStore;
import com.act.S4.models.FileStoreModel;
import com.act.S4.models.S4ValidationFile;
import com.act.S4.models.S4ValidationFileModel;
import com.act.admin.model.AdminRequestDetailsBean;
import com.act.admin.service.AdminDashBoardService;
import com.act.client.model.RequestForm;
import com.act.constant.File_Size_Constant;
import com.act.constant.Hana_Profiler_Constant;
import com.act.exceptions.UploadFilesNotValidException;
import com.act.fileprocessing.CheckFileListStatus;
import com.act.fileprocessing.InitialDataValidation;
import com.act.model.RolesAccess;
import com.act.poc.model.User;
import com.act.utility.FileUtility;
import com.act.utility.HANAUtility;
import com.act.utility.SendEmail;

import net.minidev.json.JSONArray;

@Controller
@SessionAttributes("User")

public class AdminLoginController extends S4ProcessingController {

	@ExceptionHandler(value = Exception.class)
	public String handleGenericException(Exception ex) {

		logger.info("Inside Exception handler");
		logger.error("Error !!! " + ex);

		return ex.getMessage();
	}

	// @RequestMapping(value = "/admin/dashBoard", method = RequestMethod.GET)
	@RequestMapping(value = "/admin/dashboardAdmin", method = RequestMethod.GET)
	public String dashBoardAdmin(Model model, HttpServletRequest request,
			@RequestParam(value = "action", required = false) String action, final String status, Long requestId,
			final String requestIdUi, HttpSession session) throws Exception {
		logger.info("User accessing the page" + getPrincipal());
		String userName = getPrincipal();

		model.addAttribute(new AdminDashBoardService());
		int start = 0;
		List<AdminRequestDetailsBean> overdueList;
		List<AdminRequestDetailsBean> pendingList;
		List<AdminRequestDetailsBean> completedWithPendEstimationList;
		List<AdminRequestDetailsBean> completedList;

		Integer cwpEstimationCount = 0;
		Integer completedCount = 0;
		Integer pendingCount = 0;
		Long overdueCount = 0L;
		Integer limit = 10;

		//////////

		completedWithPendEstimationList = getAdminDashBoard()
				.getCompletedwithPendingRequests(Hana_Profiler_Constant.COMPLETED_PENDING_ESTIMATIONS, limit, start);

		pendingList = getAdminDashBoard().getPendingRequest(Hana_Profiler_Constant.PENDING_STATUS, limit, start);

		overdueList = getAdminDashBoard().getOverDueRequests(Hana_Profiler_Constant.OVERDUE, limit, start);

		completedList = getAdminDashBoard().getCompletedRequests(Hana_Profiler_Constant.COMPLETED_STATUS, limit, start);

		cwpEstimationCount = getAdminDashBoard().getCompletedPendingRequestCount();

		pendingCount = getAdminDashBoard().getPendingRequestCount(Hana_Profiler_Constant.PENDING_STATUS);

		overdueCount = getAdminDashBoard().getOverdueRequestCount(Hana_Profiler_Constant.OVERDUE);
		
		completedCount = getAdminDashBoard().getCompletedRequestCount();

		Map<String, Integer> dashboardCountMap = getAdminDashBoard().getAdminDashboardCount();

		model.addAttribute("pending", pendingList);
		model.addAttribute("overdue", overdueList);
		model.addAttribute("cwpEstimation", completedWithPendEstimationList);
		model.addAttribute("completed", completedList);
		model.addAttribute("pendingCount", pendingCount);
		model.addAttribute("overdueCount", overdueCount);
		model.addAttribute("cwpEstimationCount", cwpEstimationCount);
		model.addAttribute("completedCount", completedCount);
		model.addAttribute("dashboardCountMap", dashboardCountMap);
		model.addAttribute("activeUserCount", getRolesAccessDAO().getAllRoleAccessCount());
		model.addAttribute("numRecords", limit);

		List<RolesAccess> activeUsersPOC = getRolesAccessDAO().getAllRoleAccess(null, null, null);

		Set<String> pocList = new HashSet<String>();

		for (RolesAccess pocActiveUser : activeUsersPOC) {
			if(pocActiveUser.getR_poc()) {
				pocList.add(pocActiveUser.getEmailId());
			}
		}

		model.addAttribute("pocList", pocList);

		return "admin/dashboardAdmin";
	}

	// The Scroll method starts here......
	@RequestMapping(value = "admin/adminDashBoardScroll", method = RequestMethod.GET)
	public void getNextRequestSet(final String status, Long requestId, final Integer sIdx, final Integer numRecords,
			HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
		PrintWriter out = response.getWriter();

		logger.info("Hello Welcome We are in Admin Login Controller method geTNextRequestSet ");

		try {
			String userName = getPrincipal();

			JSONArray jAr = new JSONArray();
			Integer startIndex = sIdx - 1;
			long endIdx = sIdx + numRecords;
			Integer limit = numRecords;// Configure this as per requirement.

			List<AdminRequestDetailsBean> requestList = new ArrayList<AdminRequestDetailsBean>();

			if (Hana_Profiler_Constant.COMPLETED_PENDING_ESTIMATIONS.equals(status)) {
				requestList = getAdminDashBoard().getCompletedwithPendingRequests(
						Hana_Profiler_Constant.COMPLETED_PENDING_ESTIMATIONS, limit, startIndex);
			} else if (Hana_Profiler_Constant.COMPLETED_STATUS.equals(status)) {
				requestList = getAdminDashBoard().getCompletedRequests(Hana_Profiler_Constant.COMPLETED_STATUS, limit,
						startIndex);

			} else if (Hana_Profiler_Constant.PENDING_STATUS.equals(status)) {
				requestList = getAdminDashBoard().getPendingRequest(Hana_Profiler_Constant.PENDING_STATUS, limit,
						startIndex);

			} else if (Hana_Profiler_Constant.OVERDUE.equals(status)) {
				requestList = getAdminDashBoard().getOverDueRequests(Hana_Profiler_Constant.OVERDUE, limit, startIndex);

			}

			for (AdminRequestDetailsBean adminRequest : requestList) {
				JSONObject joBj = new JSONObject();
				joBj.put("requestIdUi", adminRequest.getRequest_id_ui());
				joBj.put("requestId", adminRequest.getRequestId());
				joBj.put("updatedDate", adminRequest.getUpdatedDate());
				joBj.put("status", adminRequest.getStatus());
				joBj.put("poc_Status", adminRequest.getPoc_status());
				joBj.put("fiatScope", adminRequest.getFiatScope());
				joBj.put("OtherScope", adminRequest.getOtherScope());

				jAr.add(joBj);
			}

			out.write(jAr.toJSONString());
		} catch (Exception ex) {
			logger.error(ex.getMessage());
		} finally {
			out.close();
		}

	}

	// The Scroll method ends here......

	@RequestMapping(value = "/admin/assignPoc/{requestId}", method = RequestMethod.POST)
	public String assignPoc(Model model, HttpServletRequest servletRequest,
			@PathVariable("requestId") final long requestId, final RedirectAttributes redirectAttributes,
			HttpServletRequest request, HttpSession session) throws IOException, SQLException {

		String emailId = "";
		String fiatPoc = "";
		String poc = "";

		String toolName = (String) session.getAttribute("tool");

		poc = (request.getParameter("poc") != null) ? (request.getParameter("poc")) : "";
		fiatPoc = (request.getParameter("fiatPoc") != null) ? (request.getParameter("fiatPoc")) : "";

		RequestForm requestForm = getRequestDetails().getRequestObj(requestId);
		
		List<RolesAccess> activeUsersPOC = getRolesAccessDAO().getAllRoleAccess(null, null, null);
		Set<String> pocList = new HashSet<String>();

		for (RolesAccess pocActiveUser : activeUsersPOC) {
			if(pocActiveUser.getR_poc()) {
				pocList.add(pocActiveUser.getEmailId());
			}
		}
		
		if(!poc.equals("") && !fiatPoc.equals("") && !pocList.contains(poc) && !pocList.contains(fiatPoc)) {
			redirectAttributes.addFlashAttribute("msgPOCNotFound", "Select an appropriate POC Name and FIAT POC from the list.");
			redirectAttributes.addFlashAttribute("requestID", requestId);
			return "redirect:/admin/dashboardAdmin";
		} else {
			redirectAttributes.addFlashAttribute("msgPOCNotFound", "");
		}
		
		if(!poc.equals("") && !pocList.contains(poc)) {
			redirectAttributes.addFlashAttribute("msgPOCNotFound", "Select an appropriate POC Name from the list.");
			redirectAttributes.addFlashAttribute("requestID", requestId);
			return "redirect:/admin/dashboardAdmin";
		} else {
			redirectAttributes.addFlashAttribute("msgPOCNotFound", "");
		}
		
		if(!fiatPoc.equals("") && !pocList.contains(fiatPoc)) {
			redirectAttributes.addFlashAttribute("msgFiatPOCNotFound", "Select an appropriate FIAT POC Name from the list.");
			redirectAttributes.addFlashAttribute("requestID", requestId);
			return "redirect:/admin/dashboardAdmin";
		} else {
			redirectAttributes.addFlashAttribute("msgFiatPOCNotFound", "");
		}

		if (!(poc.trim()).equals("")) {
			requestForm.setAssignedPocEmailId(poc);
		} else {
			requestForm.setAssignedPocEmailId("");
		}
		if (!(fiatPoc.trim()).equals("")) {
			requestForm.setAssignedFaitEmailId(fiatPoc);
		} else {
			requestForm.setAssignedFaitEmailId("");
		}

		final String userName = getPrincipal();
		/* get the latest version to update in the request inventory */
		String valVersion = null;
		if (requestForm.getS4Technical()) {
			//valVersion = getS4ValidDao().getS4ValidationLatestVersion(session);
			try { 
                valVersion = getS4ValidDao().getS4ValidationLatestVersion(session);
            } catch(Exception ex){
                return "redirect:/homepage";
            }
		}
		logger.info("Saving Poc assigned data in db");
		getAdminDashBoard().requestFormAssignPoc(requestForm, userName, toolName, valVersion);
		logger.info("saved the Data in DB");

		if (!fiatPoc.isEmpty()) {
			emailId = fiatPoc;
			sendEmailForPocAssign(requestId, request, userName, requestForm, session, emailId);
		}
		if (!poc.isEmpty()) {
			emailId = poc;
			sendEmailForPocAssign(requestId, request, userName, requestForm, session, emailId);
		}
		getPocRequestMappingdao().addUser(userName, requestId);
		// return to admin dashboard controller.
		return "redirect:/admin/dashboardAdmin";
	}

	protected void sendEmailForPocAssign(long requestId, HttpServletRequest request, final String userName,
			RequestForm requestForm, HttpSession session, final String emailId) {

		Set<String> emailData = new HashSet<String>();
		Set<String> emailCc = new HashSet<String>();
		SendEmail email = new SendEmail();
		email.setMailFrom("");

		emailData.add(emailId);
		emailCc.add("");
		email.setMailTo(emailData);
		email.setMailCC(emailCc);
		email.setMailSubject("Request ID : " + requestForm.getREQUEST_ID_UI() + " Assigned");
		email.setMailBody(
				"\n\nDear " + emailId + ",\n\nYou have been assigned a new request successfully by the Admin with ID : "
						+ requestForm.getREQUEST_ID_UI() + " . Kindly Note It For Your Future References.\n\n"
						+ "Regards,\nS/4HANA conversion Team ATCI");
		email.emailSend(email, request, session);

	}

	@RequestMapping(value = "/admin/assignPocRejected/{requestId}", method = RequestMethod.POST)
	public String assignPocRejected(Model model, HttpServletRequest servletRequest,
			@PathVariable("requestId") final long requestId, final RedirectAttributes redirectAttributes,
			HttpServletRequest request, HttpSession session) throws IOException {

		RequestForm requestForm = getRequestDetails().getRequestObj(requestId);

		logger.info("Saving Poc assigned data in db");
		getAdminDashBoard().UpdateRejectedStatus(requestId);
		sendEmailForPocAssignRejected(requestId, request, session, requestForm);
		logger.info("saved the Data in DB");
		return "redirect:/admin/dashboardAdmin";
	}

	protected void sendEmailForPocAssignRejected(long requestId, HttpServletRequest request, HttpSession session,
			RequestForm requestForm) {

		Set<String> emailData = new HashSet<String>();
		Set<String> emailCc = new HashSet<String>();
		SendEmail email = new SendEmail();
		email.setMailFrom("");
		
		final String emailId = requestForm.getClientTeamDetails();
   
		emailData.add(emailId);
		emailCc.add("");
		email.setMailTo(emailData);
		email.setMailCC(emailCc);
		email.setMailSubject("Request ID : " + requestForm.getREQUEST_ID_UI() + " Rejected");
		email.setMailBody(
				"\n\nDear " + emailId + ",\n\nYour Request with Request Id : " + requestForm.getREQUEST_ID_UI()
						+ " has been rejected by the admin." + "\n\nRegards,\nS/4HANA conversion Team ATCI");
		email.emailSend(email, request, session);

	}

	@RequestMapping(value = "/admin/requestManagement/{requestId}", method = RequestMethod.POST)
	public String updatePOC(Model model, HttpServletRequest servletRequest,
			@PathVariable("requestId") final long requestId, final RedirectAttributes redirectAttributes,
			HttpServletRequest request, HttpSession session) throws IOException, SQLException {

		String emailId = "";
		String fiatPoc = "";
		String poc = "";

		String toolName = (String) session.getAttribute("tool");

		poc = (request.getParameter("poc") != null) ? (request.getParameter("poc")) : "";
		fiatPoc = (request.getParameter("fiatPoc") != null) ? (request.getParameter("fiatPoc")) : "";

		RequestForm requestForm = getRequestDetails().getRequestObj(requestId);
		
		List<RolesAccess> activeUsersPOC = getRolesAccessDAO().getAllRoleAccess(null, null, null);
		Set<String> pocList = new HashSet<String>();

		for (RolesAccess pocActiveUser : activeUsersPOC) {
			if(pocActiveUser.getR_poc()) {
				pocList.add(pocActiveUser.getEmailId());
			}
		}
		
		if(!poc.equals("") && !fiatPoc.equals("") && !pocList.contains(poc) && !pocList.contains(fiatPoc)) {
			redirectAttributes.addFlashAttribute("msgPOCNotFound", "Select an appropriate POC Name and FIAT POC from the list.");
			redirectAttributes.addFlashAttribute("requestID", requestId);
			return "redirect:/admin/requestManagement";
		} else {
			redirectAttributes.addFlashAttribute("msgPOCNotFound", "");
		}
		
		if(!poc.equals("") && !pocList.contains(poc)) {
			redirectAttributes.addFlashAttribute("msgPOCNotFound", "Select an appropriate POC Name from the list.");
			redirectAttributes.addFlashAttribute("requestID", requestId);
			return "redirect:/admin/requestManagement";
		} else {
			redirectAttributes.addFlashAttribute("msgPOCNotFound", "");
		}
		
		if(!fiatPoc.equals("") && !pocList.contains(fiatPoc)) {
			redirectAttributes.addFlashAttribute("msgFiatPOCNotFound", "Select an appropriate FIAT POC Name from the list.");
			redirectAttributes.addFlashAttribute("requestID", requestId);
			return "redirect:/admin/requestManagement";
		} else {
			redirectAttributes.addFlashAttribute("msgFiatPOCNotFound", "");
		}

		if (!(poc.trim()).equals("")) {
			requestForm.setAssignedPocEmailId(poc);
		} else {
			requestForm.setAssignedPocEmailId("");
		}
		if (!(fiatPoc.trim()).equals("")) {
			requestForm.setAssignedFaitEmailId(fiatPoc);
		} else {
			requestForm.setAssignedFaitEmailId("");
		}

		final String userName = getPrincipal();
		/* get the latest version to update in the request inventory */
		logger.info("Saving Poc assigned data in db");
		getAdminDashBoard().requestFormUpdatePoc(requestForm);
		logger.info("saved the Data in DB");
		if (!fiatPoc.isEmpty()) {
			emailId = fiatPoc;
			sendEmailForPocAssign(requestId, request, userName, requestForm, session, emailId);
		}
		
		if (!poc.isEmpty()) {
			emailId = poc;
			sendEmailForPocAssign(requestId, request, userName, requestForm, session, emailId);
		}
		
		getPocRequestMappingdao().addUser(userName, requestId);

		return "redirect:/admin/requestManagement";
	}
	
	@RequestMapping(value = "/admin/newUsers", method = RequestMethod.GET)
	public String goToNewUsers(Model model, final String userId, final String role, final String project,
			HttpServletRequest request, HttpSession session) throws Exception {
		String userName = getPrincipal();

		String toolName = (String) session.getAttribute("tool");
		Integer limit = getAdminDashBoard().getUserStatusCount(Hana_Profiler_Constant.NEW_USER);// Configure this as per requirement.
		Integer totalrecords = 0;

		// model.addAttribute("statusList", statusList);
		model.addAttribute("userId", userId);
		model.addAttribute("role", role);
		model.addAttribute("project", project);
		model.addAttribute("UserName", userName);
		model.addAttribute("numRecords", limit);

		List<User> userDetailsList = new ArrayList<User>();
		userDetailsList = getAdminDashBoard().getNewUserList(limit, 0, userId, role, project);

		if (CollectionUtils.isNotEmpty(userDetailsList)) {
			model.addAttribute("userList", userDetailsList);
			totalrecords = getAdminDashBoard().getUserStatusCount(Hana_Profiler_Constant.NEW_USER);
		} else {
			model.addAttribute("requestListEmptyMessage", "No request is created");
		}
		model.addAttribute("totalRecords", totalrecords);

		return "admin/newUsers";

	}

	@RequestMapping(value = "/admin/newUsersScroll", method = RequestMethod.GET)
	public void geTNextNewUsersSet(final String userId, final String role, final String project, final Integer sIdx,
			final Integer numRecords, HttpServletRequest request, HttpServletResponse response, HttpSession session)
			throws Exception {
		PrintWriter out = response.getWriter();

		try {
			String userName = getPrincipal();
			String toolName = (String) session.getAttribute("tool");
			JSONArray jAr = new JSONArray();
			Integer startIndex = sIdx - 1;
			long endIdx = sIdx + numRecords;
			Integer limit = numRecords;// Configure this as per requirement.

			List<User> userDetailsList = new ArrayList<User>();
			userDetailsList = getAdminDashBoard().getNewUserList(limit, startIndex, userId, role, project);

			for (User UserBean : userDetailsList) {
				JSONObject joBj = new JSONObject();
				joBj.put("userId", UserBean.getEmailId());
				joBj.put("email", UserBean.getEmailId());
				// joBj.put("role", UserBean.getUserRoleValue());
				joBj.put("project", UserBean.getProjectName());
				jAr.add(joBj);
			}
			out.write(jAr.toJSONString());
		} catch (Exception ex) {
			logger.error(ex.getMessage());
		} finally {
			out.close();
		}

	}

	@RequestMapping(value = "/admin/inactiveUsers", method = RequestMethod.GET)
	public String goToInactiveUsers(Model model, final String userId, final String expiresOn,
			HttpServletRequest request, HttpSession session) throws Exception {
		String userName = getPrincipal();

		String toolName = (String) session.getAttribute("tool");
		Integer limit = getAdminDashBoard().getUserStatusCount(Hana_Profiler_Constant.INACTIVE_USER);// Configure this as per requirement. InactiveUser
		final List<User> userDetailsList = getAdminDashBoard().getInactiveUsers(Hana_Profiler_Constant.INACTIVE_USER,
				userId, expiresOn, limit, null);

		model.addAttribute("userId", userId);
		model.addAttribute("expiresOn", expiresOn);
		model.addAttribute("UserName", userName);
		model.addAttribute("numRecords", limit);

		if (CollectionUtils.isNotEmpty(userDetailsList)) {
			model.addAttribute("userList", userDetailsList);
			model.addAttribute("totalRecords",
					getAdminDashBoard().getUserStatusCount(Hana_Profiler_Constant.INACTIVE_USER));
		} else {
			model.addAttribute("userListEmptyMessage", "No User found");
		}

		return "admin/inactiveUsers";

	}

	@RequestMapping(value = "/admin/inactiveUsersScroll", method = RequestMethod.GET)
	public void geTNextinactiveUsersSet(final String userId, final String expiresOn, final Integer sIdx,
			final Integer numRecords, HttpServletRequest request, HttpServletResponse response, HttpSession session)
			throws Exception {
		PrintWriter out = response.getWriter();

		try {
			String userName = getPrincipal();
			String toolName = (String) session.getAttribute("tool");
			JSONArray jAr = new JSONArray();
			Integer startIndex = sIdx - 1;
			// long endIdx = sIdx + numRecords;
			Integer limit = 10;// Configure this as per requirement.
			final List<User> userDetailsList = getAdminDashBoard()
					.getInactiveUsers(Hana_Profiler_Constant.INACTIVE_USER, userId, expiresOn, limit, startIndex);

			for (User uBean : userDetailsList) {
				JSONObject joBj = new JSONObject();

				joBj.put("user_name", uBean.getEmailId());
				joBj.put("client_name", uBean.getClientName());
				joBj.put("account_created_on", uBean.getCreatedOn());
				// joBj.put("enabled", uBean.getEnabled());
				joBj.put("status", "Inactive");
				joBj.put("project_name", uBean.getProjectName());
				joBj.put("account_valid_till", uBean.getValidTill());
				jAr.add(joBj);
			}
			out.write(jAr.toJSONString());
		} catch (Exception ex) {
			logger.error(ex.getMessage());
		} finally {
			out.close();
		}

	}

	@RequestMapping(value = "/admin/expiringUsers", method = RequestMethod.GET)
	public String goToExpiringUsers(Model model, final String userId, final String expiresOn,
			HttpServletRequest request, HttpSession session) throws Exception {
		String userName = getPrincipal();

		String toolName = (String) session.getAttribute("tool");
		Integer limit = 10;// Configure this as per requirement. ExpireUser
		final List<User> userDetailsList = getAdminDashBoard().getExpireUsers(Hana_Profiler_Constant.ACTIVE_USER,
				userId, expiresOn, limit, null);

		model.addAttribute("userId", userId);
		model.addAttribute("expiresOn", expiresOn);
		model.addAttribute("UserName", userName);
		model.addAttribute("numRecords", limit);

		if (CollectionUtils.isNotEmpty(userDetailsList)) {
			model.addAttribute("userList", userDetailsList);
			model.addAttribute("totalRecords",
					getAdminDashBoard().getUserStatusCount(Hana_Profiler_Constant.ACTIVE_USER));
		} else {
			model.addAttribute("userListEmptyMessage", "No User found");
		}

		return "admin/expiringUsers";

	}

	@RequestMapping(value = "/admin/expiringUsersScroll", method = RequestMethod.GET)
	public void geTNextExpiringUsersSet(final String userId, final String expiresOn, final Integer sIdx,
			final Integer numRecords, HttpServletRequest request, HttpServletResponse response, HttpSession session)
			throws Exception {
		PrintWriter out = response.getWriter();

		try {
			String userName = getPrincipal();
			String toolName = (String) session.getAttribute("tool");
			JSONArray jAr = new JSONArray();
			Integer startIndex = sIdx - 1;
			// long endIdx = sIdx + numRecords;
			Integer limit = 10;// Configure this as per requirement.
			final List<User> userDetailsList = getAdminDashBoard().getExpireUsers(Hana_Profiler_Constant.ACTIVE_USER,
					userId, expiresOn, limit, startIndex);

			for (User uBean : userDetailsList) {
				JSONObject joBj = new JSONObject();

				joBj.put("user_name", uBean.getEmailId());
				joBj.put("client_name", uBean.getClientName());
				joBj.put("account_created_on", uBean.getCreatedOn());
				joBj.put("status", "Active");
				joBj.put("project_name", uBean.getProjectName());
				joBj.put("account_valid_till", uBean.getValidTill());
				jAr.add(joBj);
			}
			out.write(jAr.toJSONString());
		} catch (Exception ex) {
			logger.error(ex.getMessage());
		} finally {
			out.close();
		}

	}

	@RequestMapping(value = "/admin/userAction/{userName}/{userAction}/{redirectTo}", method = RequestMethod.POST)
	public String administerUser(HttpServletRequest request, HttpSession session,
			@PathVariable("userName") final String userName, @PathVariable("userAction") final String userAction,
			@PathVariable("redirectTo") final String redirectTo, final RedirectAttributes redirectAttributes)
			throws Exception {
		String redirTo = "dashboardAdmin";
		try {
			String userRole = "";
			if ((request.getParameter("userRole") != null) && !(request.getParameter("userRole").isEmpty())) {
				userRole = request.getParameter("userRole");
			}

			if (!userRole.equalsIgnoreCase(Hana_Profiler_Constant.CLIENT_ROLE)
					&& !userRole.equalsIgnoreCase(Hana_Profiler_Constant.POC_ROLE)
					&& !userRole.equalsIgnoreCase(Hana_Profiler_Constant.ADMIN_ROLE)) {
				userRole = Hana_Profiler_Constant.CLIENT_ROLE;
			}

			getAdminDashBoard().performActionOnUser(userName, userAction, userRole, getUserdata(), request, session);
		} catch (Exception ex) {
			logger.error(ex.getMessage());
		}
		
		if(redirectTo != null) {
			//expiringUsers, inactiveUsers, newUsers
			if(redirectTo.equals("expiringUsers") || redirectTo.equals("inactiveUsers") || redirectTo.equals("newUsers")) 
				redirTo = redirectTo;
		} 
		
		return "redirect:/admin/" + redirTo;
	}

	@RequestMapping(value = "admin/overdueRequests", method = RequestMethod.GET)
	public String toOverdueScreen(ModelMap model, HttpServletRequest request, HttpSession session) {

		String view = "admin/overdueRequests";

		Integer limit = (int)(long)getAdminDashBoard().getOverdueRequestCount(Hana_Profiler_Constant.OVERDUE);

		final List<AdminRequestDetailsBean> overdueRequestList = getAdminDashBoard()
				.getOverDueRequests(Hana_Profiler_Constant.OVERDUE, limit, null);

		model.addAttribute("numRecords", limit);
		if (CollectionUtils.isNotEmpty(overdueRequestList)) {
			model.addAttribute("overdueReqList", overdueRequestList);
			model.addAttribute("totalRecords",
					getAdminDashBoard().getOverdueRequestCount(Hana_Profiler_Constant.OVERDUE));
		} else {
			model.addAttribute("overdueReqListEmptyMessage", "No Request Found");
		}

		return view;
	}

	@RequestMapping(value = "admin/overdueRequestsScroll", method = RequestMethod.GET)
	public String toOverdueScreenScrollSet(ModelMap model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session, final Integer sIdx, final Integer numRecords) throws IOException {
		String view = "admin/overdueRequests";

		PrintWriter out = response.getWriter();

		try {
			JSONArray jAr = new JSONArray();
			Integer startIndex = sIdx - 1;

			Integer limit = numRecords; // Configure this as per requirement.
			final List<AdminRequestDetailsBean> overdueRequestList = getAdminDashBoard()
					.getOverDueRequests(Hana_Profiler_Constant.OVERDUE, limit, startIndex);

			for (AdminRequestDetailsBean adminReqBean : overdueRequestList) {
				JSONObject joBj = new JSONObject();

				joBj.put("requestIdUi", adminReqBean.getRequest_id_ui());
				joBj.put("requestId", adminReqBean.getRequestId());
				joBj.put("createdDate", adminReqBean.getCreatedDate());
				joBj.put("overdueDate", adminReqBean.getEndDate());
				joBj.put("poc_Name", adminReqBean.getAssigned_poc_emailId());
				joBj.put("fiatpoc_Name",adminReqBean.getAssignedFaitEmailId());

				jAr.add(joBj);
			}
			out.write(jAr.toJSONString());
		} catch (Exception ex) {
			logger.error(ex.getMessage());
		} finally {
			out.close();
		}

		return view;
	}

	@RequestMapping(value = "admin/requestManagement", method = RequestMethod.GET)
	public String toRequestManagementScreen(ModelMap model, HttpServletRequest request, HttpSession session) {

		String view = "admin/requestManagement";
		Integer limit = getAdminDashBoard().getRequestManagementRequestsCount();
		final List<AdminRequestDetailsBean> requestManagementRequestList = getAdminDashBoard().getRequestManagementRequests(limit, null);
		model.addAttribute("numRecords", limit);
		if (CollectionUtils.isNotEmpty(requestManagementRequestList)) {
			model.addAttribute("requestManagementList", requestManagementRequestList);
			model.addAttribute("totalRecords", getAdminDashBoard().getRequestManagementRequestsCount());
		} else {
			model.addAttribute("requestManagementListEmptyMessage", "No Request Found");
		}
		
		List<RolesAccess> activeUsersPOC = getRolesAccessDAO().getAllRoleAccess(null, null, null);
		Set<String> pocList = new HashSet<String>();
		for (RolesAccess pocActiveUser : activeUsersPOC) {
			if (pocActiveUser.getR_poc()) {
				pocList.add(pocActiveUser.getEmailId());
			}
		}
		
		Set<String> clientList = new HashSet<String>();
		List<User> userLst = getUserdata().getUserList();
		for (User user : userLst) {
			if(user.isEnabled()){
				clientList.add(user.getEmailId());
			}
		}
		
		model.addAttribute("clientList", clientList);
		model.addAttribute("pocList", pocList);
		return view;

	}

	@RequestMapping(value = "admin/requestManagementScroll", method = RequestMethod.GET)
	public String toRequestManagementScreenScroll(ModelMap model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session, final Integer sIdx, final Integer numRecords) throws IOException {

		String view = "admin/requestManagement";
		PrintWriter out = response.getWriter();

		try {
			JSONArray jAr = new JSONArray();
			Integer startIndex = sIdx - 1;
			Integer limit = numRecords; // Configure this as per requirement.
			final List<AdminRequestDetailsBean> requestManagementRequestList = getAdminDashBoard().getRequestManagementRequests(limit,
					startIndex);

			for (AdminRequestDetailsBean adminReqBean : requestManagementRequestList) {
				JSONObject joBj = new JSONObject();
				joBj.put("requestId", adminReqBean.getRequestId());
				joBj.put("createdDate", adminReqBean.getCreatedDate());
				joBj.put("status", adminReqBean.getStatus());
				joBj.put("poc_Name", adminReqBean.getAssigned_poc_emailId());
				joBj.put("fiatpoc_Name", adminReqBean.getAssignedFaitEmailId());
				jAr.add(joBj);
			}
			out.write(jAr.toJSONString());
		} catch (Exception ex) {
			logger.error(ex.getMessage());
		} finally {
			out.close();
		}

		return view;
	}

	@RequestMapping(value = "/admin/requestDetailDisplay/{requestID}", method = RequestMethod.GET)
	public String requestIdDataDisplay(@PathVariable("requestID") final long requestId, final Model model,
			final RedirectAttributes redirectAttributes) {
		model.addAttribute("requestInventory", getClientRequestInventoryDAO().getRequestInventory(requestId));
		model.addAttribute("requestForm", getRequestDetails().getRequestObj(requestId));
		model.addAttribute("requestID", requestId);
		return "admin/requestDetailDisplay";
	}

	@RequestMapping(value = "/admin/simplificationN", method = RequestMethod.GET)
	public String addSimplification(Model model) {
		model.addAttribute("simplificationSize",File_Size_Constant.SIMPLIFCATION_SIZE);
		model.addAttribute("simplificationDBSize",File_Size_Constant.SIMPLIFCATION_DB_SIZE);
		model.addAttribute("validationSize",File_Size_Constant.VALIDATION_SIZE);
		model.addAttribute("uploadPreReqSize",File_Size_Constant.PRE_REQ_SIZE);
		model.addAttribute("reviewCheckListSize",File_Size_Constant.REVIEW_CHECKLIST_SIZE);
		model.addAttribute("TCDSize",File_Size_Constant.TCD_SIZE);
		model.addAttribute("targetUSOBTCSize",File_Size_Constant.TRG_USOBTC_SIZE);
		model.addAttribute("GRCSize", File_Size_Constant.GRT_GRACFUNCACT_SIZE);
		model.addAttribute("tcodeSubProcessSize", File_Size_Constant.TESTSCOPE_TCODE_SUBPROCESS_MAPPING);
		model.addAttribute("appCompSubProcessSize", File_Size_Constant.TESTSCOPE_APPCOMP_SUBPROCESS_MAPPING);
		model.addAttribute("BWSIZE",File_Size_Constant.BW_SIZE);
		model.addAttribute("FioriRebuildSize",File_Size_Constant.Fiori_Rebuild_SIZE);
		return "admin/simplificationN";
	}

	@RequestMapping(value = "/admin/uploadSimplificationN", method = RequestMethod.POST)
	public String uploadSimplification(final RedirectAttributes redirectAttributes, final HttpServletRequest request)
			throws FileUploadException, FileNotFoundException {
		logger.info("Coming inside UploadSimplifiationController");
		String fileName = "Simplification";
		long requestId = 0;

		HANAUtility.deleteFile(fileName, requestId, null);
		final String filePath = HANAUtility.getFilePath(fileName, requestId);
		logger.info("FilePath::::" + filePath);
		DiskFileItemFactory factory = new DiskFileItemFactory();
		factory.setSizeThreshold(0);
		factory.setRepository(new File(HANAUtility.getRepositoryTemp(fileName, requestId)));

		ServletFileUpload upload = new ServletFileUpload(factory);
		upload.setFileSizeMax(-1);
		upload.setSizeMax(-1);

		String filename = "";
		List<FileItem> multipart = new ServletFileUpload(factory).parseRequest(request);

		logger.info("Inside Initial Data validation method");

		final String userName = getPrincipal();

		//File Validation Loop Validation of files
		for (FileItem item : multipart) {
			filename = "";
			if (!item.isFormField()) {
				try {
					filename = new File(item.getName()).getName();
					if (StringUtils.isNotEmpty(filename) && !"".equals(filename)) {
						String extension = Hana_Profiler_Constant.XLSX_EXTENSTION_CONSTANT;
						String fileExtension = filename.substring(filename.length() - extension.length(),
								filename.length());
						if (extension.equalsIgnoreCase(fileExtension)) {
							logger.info("Matched Extension");
							item.write(new File(filePath + File.separator + filename));
							logger.info("Wrote in file path !!!");

						} else {
							redirectAttributes.addFlashAttribute("fileException",
									"Please Upload the file with .xlsx extension only.");
							return "redirect:/admin/simplificationN";
						}

					} else {
						redirectAttributes.addFlashAttribute("fileException", "Please Upload atleast one file.");
						return "redirect:/admin/simplificationN";
					}
				} catch (Exception exception) {
					redirectAttributes.addFlashAttribute("fileException", exception.getMessage());
					return "redirect:/admin/simplificationN";
				}
			} else {
			}
		}

		String comment = uploadSimplificationData((filePath + File.separator + filename), requestId, request);
		if (comment.equalsIgnoreCase("success")) {
			redirectAttributes.addFlashAttribute("message", "File uploaded successfully");
		} else {
			redirectAttributes.addFlashAttribute("fileException", comment);
		}
		return "redirect:/admin/simplificationN";
	}

	@RequestMapping(value = "/admin/uploadFile/createSimplificationN", method = RequestMethod.POST)
	public String uploadFileFrSimpli(Model model, final RedirectAttributes redirectAttributes,
			final HttpServletRequest request, final HttpSession session, @RequestParam("files") MultipartFile file) 
					throws FileUploadException, IOException {
		String fileName = "Simplification Files";
		String comments = "";
		String message = "Analysis is in progress";
		long requestId = 0;
		HANAUtility.deleteFile(fileName, requestId, null);
		HANAUtility.changeRequestProgressValue(requestId, 0, message);
		Map<String, String> fileList = new HashMap<String, String>();
		try {
			final String filePath = HANAUtility.getFilePath(fileName, requestId);
			HANAUtility.changeRequestProgressValue(requestId, 0, "File's Checking Under Process");

			String simpFilename = "";

			/* File Validation Loop Validation of files **/		
			try {
					simpFilename = file.getOriginalFilename();
					FileUtility.chckUploadFilesAlphaNum(simpFilename);
					FileUtility.checkFileSizeByItem(file, "Simplification");
					if (StringUtils.isNotEmpty(simpFilename) && !"".equals(simpFilename)) {
							String extension = Hana_Profiler_Constant.XLSX_EXTENSTION_CONSTANT;
							String fileExtension = simpFilename.substring(simpFilename.length() - extension.length(),
									simpFilename.length());
							if (extension.equalsIgnoreCase(fileExtension)) {
								logger.info("Matched Extension");
								byte[] bytes = file.getBytes();
								Path path = Paths.get(filePath + File.separator + simpFilename);
								Files.write(path, bytes); 
								logger.info("Wrote in file path !!!");
							} else {
								redirectAttributes.addFlashAttribute("fileException",
										"Please Upload the file with .xlsx extension only.");
								return "redirect:/admin/simplificationN";
							}
						} else {
							redirectAttributes.addFlashAttribute("fileException", "Please Upload atleast one file.");
							return "redirect:/admin/simplificationN";
						}
					} catch (UploadFilesNotValidException exception) {
						redirectAttributes.addFlashAttribute("fileException", "The filename is not correct.");
						return "redirect:/admin/simplificationN";
					} catch (Exception exception) {
						redirectAttributes.addFlashAttribute("fileException", exception.getMessage());
						return "redirect:/admin/simplificationN";
					}

			List<String> missingFiles = new ArrayList<String>();
			try {
				InitialDataValidation initialDataValidation = new InitialDataValidation(filePath);
				CheckFileListStatus checkObject = new CheckFileListStatus(filePath);

				boolean checkListStatus = true;

				Map<String, String> filesNameWithStatus = checkObject.validateFiles("CreateSimplification", filePath);
				Iterator<String> listKeysIterator = filesNameWithStatus.keySet().iterator();
				Map<String, String> tempMap = new HashMap<>();
				while (listKeysIterator.hasNext()) {
					String checkListName = listKeysIterator.next();
					// If the files is not present corresponding to checkList.
					if (!(filesNameWithStatus.get(checkListName)).equalsIgnoreCase("VALID")) {
						// If all the required files are not present then, add the missing files.
						checkListStatus = false;
						missingFiles.add(checkListName);
					} else {
						for (Map.Entry<String, String> entry : fileList.entrySet()) {
							if (entry.getKey().startsWith(checkListName.toUpperCase())) {
								tempMap.put(entry.getKey(), "VALID");
							}
						}
					}
				}
				boolean isAnyInvalidFile = false;
				// At the end, make all the files that have unexpected name as invalid.
				for (Map.Entry<String, String> entry : fileList.entrySet()) {
					if (!tempMap.containsKey(entry.getKey())) {
						isAnyInvalidFile = true;
						if (fileList.get(entry.getKey()).equalsIgnoreCase("VALID")) {
							fileList.put(entry.getKey(), "INVALID FILE NAME.");
						}
					}
				}
				logger.info("after checkListStatus");

				// If all required file are present, then proceed for XLSX validation.
				try {
					if (initialDataValidation.validateAllFiles(fileList, "CreateSimplification")) {
						message = HANAUtility.getPropertyValue("testing.properties", "filelistokmessage");
						HANAUtility.changeRequestProgressValue(requestId, 10, message);
					} else {
						// Somehow validation of files have failed and instead of throwing an exception
						// it has returned false.
						logger.info("inside else block ");

						comments = HANAUtility.getPropertyValue("testing.properties", "filelistnotokmessage");
						redirectAttributes.addFlashAttribute("fileException", comments);
						return "redirect:/admin/simplificationN";

					}
					if (!checkListStatus || isAnyInvalidFile) {
						if (!missingFiles.isEmpty()) {
							comments = "Please upload " + missingFiles + " files for processing this request.";
							redirectAttributes.addFlashAttribute("fileException", comments);
							return "redirect:/admin/simplificationN";
						} else {
							comments = "Please upload valid files only";
							redirectAttributes.addFlashAttribute("fileException", comments);
							return "redirect:/admin/simplificationN";
						}

					}
				} catch (Exception e) {
					logger.error("In Exception catch: " + e.getMessage());
					redirectAttributes.addFlashAttribute("message", e.getMessage());
					return "redirect:/admin/simplificationN";
				}
			} finally {
				model.addAttribute("simplificationSize",File_Size_Constant.SIMPLIFCATION_SIZE);
				model.addAttribute("simplificationDBSize",File_Size_Constant.SIMPLIFCATION_DB_SIZE);
				model.addAttribute("validationSize",File_Size_Constant.VALIDATION_SIZE);
				model.addAttribute("uploadPreReqSize",File_Size_Constant.PRE_REQ_SIZE);
				model.addAttribute("reviewCheckListSize",File_Size_Constant.REVIEW_CHECKLIST_SIZE);
				model.addAttribute("TCDSize",File_Size_Constant.TCD_SIZE);
				model.addAttribute("targetUSOBTCSize",File_Size_Constant.TRG_USOBTC_SIZE);
			}
			try {
				HANAUtility.changeRequestProgressValue(requestId, 20, "Files Uploaded Successfully.");
				String comment = readSimplificationData((filePath), requestId, request, session);
				if (comment.equalsIgnoreCase("success")) {
					HANAUtility.changeRequestProgressValue(requestId, 40, "Data Saved Successfully.");
					HANAUtility.changeRequestProgressValue(requestId, 100,
							"Simplification to be uploaded successfully.");
					model.addAttribute("uploaded", "true");
					model.addAttribute("message", "Simplification created successfully");
					return "admin/simplificationN";
				} else {
					redirectAttributes.addFlashAttribute("fileException", comment);
				}
			} catch (Exception e) {
				redirectAttributes.addFlashAttribute("fileException", e.getMessage());
				return "redirect:/admin/simplificationN";
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return "redirect:/admin/simplificationN";
	}

	@RequestMapping(value = "/admin/uploadSimplificationDBN", method = RequestMethod.POST)
	public String uploadSimplificationDB(final RedirectAttributes redirectAttributes, final HttpServletRequest request,
			HttpSession session, @RequestParam("files") MultipartFile file) throws FileUploadException, IOException {
		logger.info("Coming inside UploadSimplifiationDBController");

		String fileName = "Simplification File";
		String comments = "";
		String message = "Analysis is in progress";
		long requestId = 0;
		HANAUtility.deleteFile(fileName, requestId, null);
		HANAUtility.changeRequestProgressValue(requestId, 0, message);
		Map<String, String> fileList = new HashMap<String, String>();

		final String filePath = HANAUtility.getFilePath(fileName, requestId);
		logger.info("FilePath::::" + filePath);

		HANAUtility.changeRequestProgressValue(requestId, 0, "File's Checking Under Process");
		
		String simpDBFilename = "";

		logger.info("Inside Initial Data validation method");

		/* File Validation Loop Validation of files **/
			try {
				simpDBFilename = file.getOriginalFilename();
				FileUtility.chckUploadFilesAlphaNum(simpDBFilename);
				FileUtility.checkFileSizeByItem(file, "Simplification"); 
				 	if (StringUtils.isNotEmpty(simpDBFilename) && !"".equals(simpDBFilename)) {
				 		String extension = Hana_Profiler_Constant.XLSX_EXTENSTION_CONSTANT;
						String fileExtension = simpDBFilename.substring(simpDBFilename.length() - extension.length(),
								simpDBFilename.length());
						if (extension.equalsIgnoreCase(fileExtension)) {
							logger.info("Matched Extension");
							byte[] bytes = file.getBytes();
							Path path = Paths.get(filePath + File.separator + simpDBFilename);
							Files.write(path, bytes);
							logger.info("Wrote in file path !!!");
						} else {
							redirectAttributes.addFlashAttribute("fileException",
									"Please Upload the file with .xlsx extension only.");
							return "redirect:/admin/simplificationN";
						}
					} else {
						redirectAttributes.addFlashAttribute("fileException", "Please Upload atleast one file.");
						return "redirect:/admin/simplificationN";
					}
				} catch (UploadFilesNotValidException exception) {
					redirectAttributes.addFlashAttribute("fileException", "The filename is not correct.");
					return "redirect:/admin/simplificationN";
				} catch (Exception exception) {
					redirectAttributes.addFlashAttribute("fileException", exception.getMessage());
					return "redirect:/admin/simplificationN";
				}
		
		List<String> missingFiles = new ArrayList<String>();
		try {
			InitialDataValidation initialDataValidation = new InitialDataValidation(filePath);
			CheckFileListStatus checkObject = new CheckFileListStatus(filePath);

			boolean checkListStatus = true;

			Map<String, String> filesNameWithStatus = checkObject.validateFiles("Simplification", filePath);
			Iterator<String> listKeysIterator = filesNameWithStatus.keySet().iterator();
			Map<String, String> tempMap = new HashMap<>();
			while (listKeysIterator.hasNext()) {
				String checkListName = listKeysIterator.next();
				// If the file is not present corresponding to checkList.
				if (!(filesNameWithStatus.get(checkListName)).equalsIgnoreCase("VALID")) {
					// If all the required files are not present then, add the missing files.
					checkListStatus = false;
					missingFiles.add(checkListName);
				} else {
					for (Map.Entry<String, String> entry : fileList.entrySet()) {
						if (entry.getKey().startsWith(checkListName.toUpperCase())) {
							tempMap.put(entry.getKey(), "VALID");
						}
					}
				}
			}
			boolean isAnyInvalidFile = false;
			// At the end, make all the files that have unexpected name as invalid.
			for (Map.Entry<String, String> entry : fileList.entrySet()) {
				if (!tempMap.containsKey(entry.getKey())) {
					isAnyInvalidFile = true;
					if (fileList.get(entry.getKey()).equalsIgnoreCase("VALID")) {
						fileList.put(entry.getKey(), "INVALID FILE NAME.");
					}
				}
			}
			logger.info("after checkListStatus");

			// If all required file are present, then proceed for XLSX validation.
			try {
				if (initialDataValidation.validateAllFiles(fileList, "Simplification")) {
					message = HANAUtility.getPropertyValue("testing.properties", "filelistokmessage");
					HANAUtility.changeRequestProgressValue(requestId, 10, message);
				} else {
					// Somehow validation of files have failed and instead of throwing an exception
					// it has returned false.
					logger.info("inside else block ");

					comments = HANAUtility.getPropertyValue("testing.properties", "filelistnotokmessage");
					redirectAttributes.addFlashAttribute("fileException", comments);
					return "redirect:/admin/simplificationN";
				}
				if (!checkListStatus || isAnyInvalidFile) {
					if (!missingFiles.isEmpty()) {
						comments = "Please upload " + missingFiles + " files for processing this request.";
						redirectAttributes.addFlashAttribute("fileException", comments);
						return "redirect:/admin/simplificationN";
					} else {
						comments = "Please upload valid files only";
						redirectAttributes.addFlashAttribute("fileException", comments);
						return "redirect:/admin/simplificationN";
					}
				}
			} catch (Exception e) {
				logger.error("In Exception catch: " + e.getMessage());
				logger.error("Error !!! " + e);
				redirectAttributes.addFlashAttribute("message", e.getMessage());
				return "redirect:/admin/simplificationN";
			}
		} finally {
		}
		try {
			HANAUtility.changeRequestProgressValue(requestId, 20, "Files Uploaded Successfully.");
			readBigSimplificationDBData((filePath), requestId, request, session);
			redirectAttributes.addFlashAttribute("message", "File uploaded successfully");
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return "redirect:/admin/simplificationN";
	}

	@RequestMapping(value = "/admin/activeUsers", method = RequestMethod.GET)
	public String goToActiveUsers(Model model, final String userId, HttpServletRequest request, HttpSession session) throws Exception {
		String userName = getPrincipal();

		String toolName = (String) session.getAttribute("tool");
		Integer limit = getRolesAccessDAO().getAllRoleAccessCount();// Configure this as per requirement. ActiveUser
		// List<User> activeUsersList =
		// getAdminDashBoard().getActiveUsers(Hana_Profiler_Constant.ACTIVE_USER,
		// userId, limit, null);
		List<RolesAccess> uRAList = getRolesAccessDAO().getAllRoleAccess(userId, limit, null);

		model.addAttribute("userId", userId);
		model.addAttribute("UserName", userName);
		model.addAttribute("numRecords", limit);

		if (CollectionUtils.isNotEmpty(uRAList)) {
			model.addAttribute("userList", uRAList);
			model.addAttribute("totalRecords", getRolesAccessDAO().getAllRoleAccessCount());
		} else {
			model.addAttribute("userListEmptyMessage", "No Active User found");
		}

		return "admin/activeUsers";

	}

	@RequestMapping(value = "/admin/activeUsersScroll", method = RequestMethod.GET)
	public void geTNextActiveUsersSet(final String userId, final Integer sIdx,
			final Integer numRecords, HttpServletRequest request, HttpServletResponse response, HttpSession session)
			throws Exception {
		PrintWriter out = response.getWriter();

		try {
			String userName = getPrincipal();
			String toolName = (String) session.getAttribute("tool");
			JSONArray jAr = new JSONArray();
			Integer startIndex = sIdx - 1;
			Integer limit = numRecords;// Configure this as per requirement.
			//List<User> activeUsersList = getAdminDashBoard().getActiveUsers(Hana_Profiler_Constant.ACTIVE_USER, userId, limit, startIndex);
			List<RolesAccess> uRAList = getRolesAccessDAO().getAllRoleAccess(userId, limit, startIndex);

			for (RolesAccess rAccess : uRAList) {
				JSONObject joBj = new JSONObject();
				joBj.put("email_id", rAccess.getEmailId());
				joBj.put("rAdmin", rAccess.getR_admin());
				joBj.put("rPoc", rAccess.getR_poc());
				joBj.put("rClient", rAccess.getR_client());
				jAr.add(joBj);
			}
			out.write(jAr.toJSONString());
		} catch (Exception ex) {
			logger.error(ex.getMessage());
		} finally {
			out.close();
		}
	}
	
	@RequestMapping(value = "/admin/changeRole", method = RequestMethod.POST)
	public String changeUserRole(Model model, HttpServletRequest request, HttpServletResponse response, HttpSession session, final RedirectAttributes redirectAttributes) throws Exception {
		String userEmail = request.getParameter("userEmail");
		try {
			Boolean rAdmin = (request.getParameter("rAdmin")) != null;
			Boolean rPoc = (request.getParameter("rPoc")) != null;
			Boolean rClient = (request.getParameter("rClient")) != null;
			
			User user = getUserdata().getUser(userEmail);
			RolesAccess rolesAccess = user.getRolesAccess();
			rolesAccess.setR_admin(rAdmin);
			rolesAccess.setR_poc(rPoc);
			rolesAccess.setR_client(rClient);
			
			getUserdata().save(user, user.getUserRoleValue());
			logger.info(this.getClass().getName()+": Successfully updated user role access");
			redirectAttributes.addFlashAttribute("MessageSuccess", "Role Access changed for "+userEmail+(rAdmin?" -Admin":"")+(rPoc?" -POC":"")+(rClient?" -Client":""));
		} catch(Exception ex) {
			logger.error(this.getClass().getName()+": Failed to update user role access");
			redirectAttributes.addFlashAttribute("MessageFail", "Failed to change Role of "+userEmail);
		}
		return "redirect:/admin/activeUsers";
	}

	@RequestMapping(value = "/admin/uploadValidation", method = RequestMethod.POST)
	public String uploadS4ValidationList(@Valid @ModelAttribute("S4ValidationFile") S4ValidationFileModel s4ValidationFileModel,
			final RedirectAttributes redirectAttributes, Model model, final HttpServletRequest request,
			HttpSession session, @RequestParam("files") MultipartFile file) throws FileUploadException {
		S4ValidationFile s4ValidationFile=prepareS4ValidationFileModel(s4ValidationFileModel);
		String pageReturn = null;
		try {
			pageReturn = getAdminSimplificationService().adminS4ValidatinUploadList(s4ValidationFile,
					redirectAttributes, model, request, session, file);
		} catch (Exception ex) {
			logger.error("Error In AdminLoginController :: uploadS4ValidationList()", ex);
		}
		return pageReturn;
	}

	private S4ValidationFile prepareS4ValidationFileModel(S4ValidationFileModel s4m) {
		S4ValidationFile s4 = new S4ValidationFile();
		s4.setID(s4m.getID());
		s4.setUpdatedDate(s4m.getUpdatedDate());
		s4.setValidationFile(s4m.getValidationFile());
		s4.setValidationFileName(s4m.getValidationFileName());
		s4.setValidationVersion(s4m.getValidationVersion());

		return s4;
	}
	private FileStore prepareFileStoreModel(FileStoreModel fsm) {
		FileStore fs = new FileStore();
		fs.setFileContent(fsm.getFileContent());
		fs.setFileName(fsm.getFileName());
		fs.setFileNameKey(fsm.getFileNameKey());
		fs.setID(fsm.getID());
		fs.setUpdatedDate(fsm.getUpdatedDate());

		return fs;
	}
	@RequestMapping(value = "/admin/uploadPreRequisite", method = RequestMethod.POST)
	public String uploadAndStorePreRequisite(@Valid @ModelAttribute("FileStore") FileStoreModel fileStoreModel,
			final RedirectAttributes redirectAttributes,Model model,final HttpServletRequest request, 
			HttpSession session, @RequestParam("files") MultipartFile file) throws FileUploadException {
		FileStore fileStore =prepareFileStoreModel(fileStoreModel);
		String pageReturn = null;
		try {
			pageReturn = getAdminSimplificationService().adminPreRequisiteUpload(fileStore, redirectAttributes, model, request, session, file);
		} catch (Exception ex) {
			logger.error("Error In AdminLoginController :: uploadAndStorePreRequisite()",ex);
		}
		return pageReturn;
	}
	
	@RequestMapping(value = "/admin/uploadReviewChecklist", method = RequestMethod.POST)
	public String uploadAndStoreReviewChecklist(@Valid @ModelAttribute("FileStore") FileStoreModel fileStoreModel,final RedirectAttributes redirectAttributes,
			Model model,final HttpServletRequest request, HttpSession session, @RequestParam("files") MultipartFile file) throws FileUploadException {
		FileStore fileStore =prepareFileStoreModel(fileStoreModel);
		String pageReturn = null;
		try {
			pageReturn = getAdminSimplificationService().adminReviewChecklistUpload(fileStore, redirectAttributes, model, request, session, file);
		} catch (Exception ex) {
			logger.error("Error In AdminLoginController :: uploadAndStoreReviewChecklist()",ex);
		}
		return pageReturn;
	}
	@RequestMapping(value = "/admin/uploadTCDSimplificationFile", method = RequestMethod.POST)
	public String uploadTCDSimplification(@Valid @ModelAttribute("FileStore") FileStoreModel fileStoreModel,final RedirectAttributes redirectAttributes,Model model,
			final HttpServletRequest request, HttpSession session, @RequestParam("files") MultipartFile file) throws FileUploadException {
		FileStore fileStore =prepareFileStoreModel(fileStoreModel);
		String pageReturn = null;
		try {
			pageReturn = getAdminSimplificationService().adminTCDSimplificationUpload(fileStore, redirectAttributes, model, request, session, file);
		} catch (Exception ex) {
			logger.error("Error In AdminLoginController :: uploadAndStoreTCDSimplification()",ex);
		}
		finally {
			model.addAttribute("simplificationSize",File_Size_Constant.SIMPLIFCATION_SIZE);
			model.addAttribute("simplificationDBSize",File_Size_Constant.SIMPLIFCATION_DB_SIZE);
			model.addAttribute("validationSize",File_Size_Constant.VALIDATION_SIZE);
			model.addAttribute("uploadPreReqSize",File_Size_Constant.PRE_REQ_SIZE);
			model.addAttribute("reviewCheckListSize",File_Size_Constant.REVIEW_CHECKLIST_SIZE);
			model.addAttribute("TCDSize",File_Size_Constant.TCD_SIZE);
			model.addAttribute("targetUSOBTCSize",File_Size_Constant.TRG_USOBTC_SIZE);
		}
		return pageReturn;
	}

	@RequestMapping(value = "/admin/uploadSIATargetUsobtc", method = RequestMethod.POST)
	public String uploadTargetUsobtc(@Valid @ModelAttribute("FileStore") FileStoreModel fileStoreModel,final RedirectAttributes redirectAttributes,
			Model model,final HttpServletRequest request, HttpSession session, @RequestParam("files") MultipartFile file) throws FileUploadException {
		FileStore fileStore =prepareFileStoreModel(fileStoreModel);
		String pageReturn = null;
		try {
			pageReturn = getAdminSimplificationService().adminTargetUsobtcUpload(fileStore, redirectAttributes, model, request, session, file);
		} catch (Exception ex) {
			logger.error("Error In AdminLoginController :: uploadTargetUsobtc()",ex);
		} finally {
			model.addAttribute("simplificationSize",File_Size_Constant.SIMPLIFCATION_SIZE);
			model.addAttribute("simplificationDBSize",File_Size_Constant.SIMPLIFCATION_DB_SIZE);
			model.addAttribute("validationSize",File_Size_Constant.VALIDATION_SIZE);
			model.addAttribute("uploadPreReqSize",File_Size_Constant.PRE_REQ_SIZE);
			model.addAttribute("reviewCheckListSize",File_Size_Constant.REVIEW_CHECKLIST_SIZE);
			model.addAttribute("TCDSize",File_Size_Constant.TCD_SIZE);
			model.addAttribute("targetUSOBTCSize",File_Size_Constant.TRG_USOBTC_SIZE);
		}
		return pageReturn;
	}
	
	@RequestMapping(value = "/admin/uploadGrcMasterFile", method = RequestMethod.POST)
	public String uploadGRCMasterdata(@Valid @ModelAttribute("FileStore") FileStoreModel fileStoreModel,final RedirectAttributes redirectAttributes,Model model,
			final HttpServletRequest request, HttpSession session, @RequestParam("files") MultipartFile file) throws FileUploadException {
		FileStore fileStore =prepareFileStoreModel(fileStoreModel);
		String pageReturn = null;
		try {
			pageReturn = getAdminSimplificationService().adminGRCMasterdataUpload(fileStore, redirectAttributes, model, request, session, file);
		} catch (Exception ex) {
			logger.error("Error In AdminLoginController :: uploadGRCMasterdata()",ex);
		}
		finally {
			model.addAttribute("simplificationSize",File_Size_Constant.SIMPLIFCATION_SIZE);
			model.addAttribute("simplificationDBSize",File_Size_Constant.SIMPLIFCATION_DB_SIZE);
			model.addAttribute("validationSize",File_Size_Constant.VALIDATION_SIZE);
			model.addAttribute("uploadPreReqSize",File_Size_Constant.PRE_REQ_SIZE);
			model.addAttribute("reviewCheckListSize",File_Size_Constant.REVIEW_CHECKLIST_SIZE);
			model.addAttribute("TCDSize",File_Size_Constant.TCD_SIZE);
			model.addAttribute("targetUSOBTCSize",File_Size_Constant.TRG_USOBTC_SIZE);
			model.addAttribute("GRCSize",File_Size_Constant.GRT_GRACFUNCACT_SIZE);
		}
		return pageReturn;
	}

	@RequestMapping(value = "/admin/uploadTCodeSubProcessMappingFile", method = RequestMethod.POST)
	public String uploadTCodeSubProcessMapping(RedirectAttributes redirectAttributes, 
			Model model, HttpServletRequest request, HttpSession session, 
			@RequestParam("files") MultipartFile file) throws FileUploadException {
		String comments = "";
		String tcodeSubProcessFileName = "";
		String fileExtension = "";
		String extension = Hana_Profiler_Constant.XLSX_EXTENSTION_CONSTANT.substring(1);
		String fileName = "TESTINGSCOPE_TCODE";
		String result = "";

		try {
			tcodeSubProcessFileName = file.getOriginalFilename();
			fileExtension = FilenameUtils.getExtension(tcodeSubProcessFileName);
			if (StringUtils.isNotEmpty(tcodeSubProcessFileName) && !"".equals(tcodeSubProcessFileName)) {
				FileUtility.chckUploadFilesAlphaNum(tcodeSubProcessFileName);
				FileUtility.checkFileSizeByItem(file, fileName); 
				if(extension.equalsIgnoreCase(fileExtension)) {
					comments = "Matched Extension - TCode SubProcess Mapping File.";
					logger.info(comments);
				} else {
					comments = "Extension of file : TCode SubProcess Mapping File does not match. "
							+ "Please upload the file with .xlsx extension only.";
					logger.info(comments);
					redirectAttributes.addFlashAttribute("fileException", comments);
					return "redirect:/admin/simplificationN";
				}
			} else {
				comments = "No file uploaded. Please upload atleast one file.";
				logger.info(comments);
				redirectAttributes.addFlashAttribute("fileException", comments);
				return "redirect:/admin/simplificationN";
			}
					
			result = getAdminSimplificationService().adminTCodeSubProcessMappingFile(session, file);
			if (result.equalsIgnoreCase("Success")) {
				comments = "TCode SubProcess Mapping File Data Saved Successfully ...";
				logger.info(comments);
				redirectAttributes.addFlashAttribute("message", comments);
			}
		} catch (UploadFilesNotValidException ex) {
			logger.error("Error in AdminLoginController :: uploadTCodeSubProcessMapping()", ex);
			redirectAttributes.addFlashAttribute("fileException", ex.getMessage());
		} catch (Exception ex) {
			logger.error("Error in AdminLoginController :: uploadTCodeSubProcessMapping()", ex);
			redirectAttributes.addFlashAttribute("fileException", "TCode SubProcess Mapping File Upload Failed !!!");
		}
		
		return "redirect:/admin/simplificationN";
	}
	
	@RequestMapping(value = "/admin/uploadAppCompSubProcessMappingFile", method = RequestMethod.POST)
	public String uploadAppCompSubProcessMapping(RedirectAttributes redirectAttributes, 
			Model model, HttpServletRequest request, HttpSession session, 
			@RequestParam("files") MultipartFile file) throws FileUploadException {
		String comments = "";
		String tcodeSubProcessFileName = "";
		String fileExtension = "";
		String extension = Hana_Profiler_Constant.XLSX_EXTENSTION_CONSTANT.substring(1);
		String fileName = "TESTINGSCOPE_APPCOMP";
		String result = "";

		try {
			tcodeSubProcessFileName = file.getOriginalFilename();
			fileExtension = FilenameUtils.getExtension(tcodeSubProcessFileName);
			if (StringUtils.isNotEmpty(tcodeSubProcessFileName) && !"".equals(tcodeSubProcessFileName)) {
				FileUtility.chckUploadFilesAlphaNum(tcodeSubProcessFileName);
				FileUtility.checkFileSizeByItem(file, fileName); 
				if(extension.equalsIgnoreCase(fileExtension)) {
					comments = "Matched Extension - Application_Component SubProcess Mapping File.";
					logger.info(comments);
				} else {
					comments = "Extension of file : Application_Component SubProcess Mapping File does not match. "
							+ "Please upload the file with .xlsx extension only.";
					logger.info(comments);
					redirectAttributes.addFlashAttribute("fileException", comments);
					return "redirect:/admin/simplificationN";
				}
			} else {
				comments = "No file uploaded. Please upload atleast one file.";
				logger.info(comments);
				redirectAttributes.addFlashAttribute("fileException", comments);
				return "redirect:/admin/simplificationN";
			}
					
			result = getAdminSimplificationService().adminAppCompSubProcessMappingFile(session, file);
			if (result.equalsIgnoreCase("Success")) {
				comments = "Application_Component SubProcess Mapping File Data Saved Successfully ...";
				logger.info(comments);
				redirectAttributes.addFlashAttribute("message", comments);
			}
		} catch (UploadFilesNotValidException ex) {
			logger.error("Error in AdminLoginController :: uploadAppCompSubProcessMapping()", ex);
			redirectAttributes.addFlashAttribute("fileException", ex.getMessage());
		} catch (Exception ex) {
			logger.error("Error in AdminLoginController :: uploadAppCompSubProcessMapping()", ex);
			redirectAttributes.addFlashAttribute("fileException", "Application_Component SubProcess Mapping File Upload Failed !!!");
		}
		
		return "redirect:/admin/simplificationN";
	}
	
	@RequestMapping(value = "/admin/uploadBwExtractMaster", method = RequestMethod.POST)
	public String uploadBwExtractorMaster(@Valid @ModelAttribute("FileStore") FileStoreModel fileStoreModel,
			final RedirectAttributes redirectAttributes, Model model, final HttpServletRequest request,
			HttpSession session, @RequestParam("files") MultipartFile file) throws FileUploadException {
		FileStore fileStore =prepareFileStoreModel(fileStoreModel);
		String pageReturn = null;
		try {
			pageReturn = getAdminSimplificationService().adminBwExtractMasterUpload(fileStore, redirectAttributes, model, request, session, file);
		} catch (Exception ex) {
			logger.error("Error In AdminLoginController :: uploadBwExtractorMaster()", ex);
		}
		finally {
			model.addAttribute("simplificationSize",File_Size_Constant.SIMPLIFCATION_SIZE);
			model.addAttribute("simplificationDBSize",File_Size_Constant.SIMPLIFCATION_DB_SIZE);
			model.addAttribute("validationSize",File_Size_Constant.VALIDATION_SIZE);
			model.addAttribute("uploadPreReqSize",File_Size_Constant.PRE_REQ_SIZE);
			model.addAttribute("reviewCheckListSize",File_Size_Constant.REVIEW_CHECKLIST_SIZE);
			model.addAttribute("TCDSize",File_Size_Constant.TCD_SIZE);
			model.addAttribute("targetUSOBTCSize",File_Size_Constant.TRG_USOBTC_SIZE);
			model.addAttribute("GRCSize",File_Size_Constant.GRT_GRACFUNCACT_SIZE);
			model.addAttribute("BWSIZE",File_Size_Constant.BW_SIZE);
		}
		return pageReturn;
	}
	
	@RequestMapping(value = "/admin/uploadFioriRebuildMaster", method = RequestMethod.POST)
	public String uploadFioriRebuild(@Valid @ModelAttribute("FileStore") FileStoreModel fileStoreModel,final RedirectAttributes redirectAttributes,
			Model model,final HttpServletRequest request, HttpSession session, @RequestParam("files") MultipartFile file) throws FileUploadException {
		FileStore fileStore =prepareFileStoreModel(fileStoreModel);
		String pageReturn = null;
		try {
			pageReturn = getAdminSimplificationService().adminFioriRebuildUpload(fileStore, redirectAttributes, model, request, session, file);
		} catch (Exception ex) {
			logger.error("Error In AdminLoginController :: uploadFioriRebuild()",ex);
		} finally {
			model.addAttribute("simplificationSize",File_Size_Constant.SIMPLIFCATION_SIZE);
			model.addAttribute("simplificationDBSize",File_Size_Constant.SIMPLIFCATION_DB_SIZE);
			model.addAttribute("validationSize",File_Size_Constant.VALIDATION_SIZE);
			model.addAttribute("uploadPreReqSize",File_Size_Constant.PRE_REQ_SIZE);
			model.addAttribute("reviewCheckListSize",File_Size_Constant.REVIEW_CHECKLIST_SIZE);
			model.addAttribute("TCDSize",File_Size_Constant.TCD_SIZE);
			model.addAttribute("targetUSOBTCSize",File_Size_Constant.TRG_USOBTC_SIZE);
			model.addAttribute("GRCSize",File_Size_Constant.GRT_GRACFUNCACT_SIZE);
			model.addAttribute("BWSIZE",File_Size_Constant.BW_SIZE);
			model.addAttribute("GRCSize",File_Size_Constant.GRT_GRACFUNCACT_SIZE);
			model.addAttribute("FioriRebuildSize",File_Size_Constant.Fiori_Rebuild_SIZE);
		}
		return pageReturn;
	}
	
	@RequestMapping(value = "/admin/requestManagementClient/{requestId}", method = RequestMethod.POST)
	public String updateCreatorUser(Model model, HttpServletRequest servletRequest,
			@PathVariable("requestId") final long requestId, final RedirectAttributes redirectAttributes,
			HttpServletRequest request, HttpSession session) throws IOException, SQLException {
		
		String cUser = (request.getParameter("clie") != null) ? (request.getParameter("clie")) : "";
		
		RequestForm requestForm = getRequestDetails().getRequestObj(requestId);
		
		if(StringUtils.isNotBlank(requestForm.getRequestInventory().getCreatorUser())){
			getAdminDashBoard().updateCreatorUser(requestId,cUser);
		}
		
		return "redirect:/admin/requestManagement";
	}
}
