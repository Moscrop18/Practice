package com.act.constant;

import java.util.HashMap;
import java.util.Map;

/**
 * @author himani.malhotra
 *
 */

public class POC_Upload_Constant {

	public static final Map<Long, Map<String, Map<String, String>>> POC_FILE_KEY_VALUE = new HashMap<Long, Map<String, Map<String, String>>>();

	public static final String POC_INVENTORY_CONSTANT = "Inventory List.properties";
	public static final String POC_DRDB_CONSTANT = "Impacted Due to DB change.properties";

	public static final String POC_IMPACTED_OBJECT_CONSTANT = "Impacted Object List.properties";
	public static final String POC_S4_DETAIL_REPORT1_CONSTANT = "Impacted Due to Simplification.properties";

	public static final String POC_EXISTING_ERRORS_CONSTANT = "Existing Errors.properties";
	public static final String POC_FIORI_ODATA_CONSTANT = "Fiori Impact Analysis.properties";
	public static final String POC_OUTPUT_MANAGEMENT_CONSTANT = "Output Management.properties";

	public static final String POC_AFFECTED_CUSTOM_CONSTANT = "Affected by Custom Fields.properties";
	public static final String POC_IMPACTED_TABLES_CONSTANT = "Impacted Tables.properties";

	public static final String POC_IMPACTED_IDOC_CONSTANT = "Impacted IDOC.properties";

	public static final String POC_IMPACTED_STANDARD_CONSTANT = "Impacted Standard Transaction.properties";
	public static final String POC_IMPACTED_SEARCH_CONSTANT = "Impacted Search Help.properties";

	public static final String POC_APPEND_STRUCTURECONSTANT = "Append Structure Analysis.properties";

	public static final String POC_CLONE_PROG_CONSTANT = "Impacted Clone Program Analysis.properties";

	public static final String POC_ENHANCEMENT_CONSTANT = "Impacted Enhancement BADI.properties";

	public static final String POC_S4_DETAIL_REPORT2_CONSTANT = "DR_S4 Simplification-2.properties";
	public static final String POC_S4_DETAIL_REPORT3_CONSTANT = "DR_S4 Simplification-3.properties";

	public static final String POC_UI5_CONSTANT = "UI5 Final Output.properties";
	public static final String POC_UI5_HIGHLEVEL_CONSTANT = "UI5 High Level Report.properties";
	public static final String POC_TESTING_SCOPE_CONSTANT = "Testing Scope.properties";
	
	public static final String POC_IMPACTED_BACKGROUND_JOB_CONSTANT = "Impacted Background Job.properties";
	public static final String POC_SMODILOG_CONSTANT = "Smodilog.properties";
	
	public static final String POC_IMPACTED_SAP_SCRIPTS = "Impacted SAP Scripts.properties";
	public static final String POC_OS_MIGRATION_1 = "Impacted Due To OS Migration";
	public static final String POC_OS_MIGRATION_2 = "Logical CMD impacted by OS Chg";
	public static final String POC_OS_MIGRATION_3 = "File path impacted by OS Change";
 	
	public static final String POC_IMPACTED_CLONE_ANALYSIS = "Impacted Clone Analysis.properties";
	public static final String POC_INCONSISTENT_FUGR = "Inconsistent Function Groups";
	public static final String POC_IMPACTED_HARDCODING = "Hardcoding";
	public static final String POC_IMPACTED_VARIANT = "Impacted Variant";
	public static final String SCOPE_BASED_FILENAME = "ScopeBased_SheetName";
	public static final String POC_NON_UNICODE = "Non-Unicode Objects";
	
	public static final String POC_CVITR_OUTPUT  = "CVITR Output.properties";
	public static final String POC_CVIT_OUTPUT  = "CVIT OUTPUT.properties";
	public static final String POC_BW_INVENTORY  = "BW Inventory.properties";
	public static final String POC_FIORI_OUTPUT  = "Fiori Output.properties";
	public static final String POC_BW_CLEANUP_UTILITY  = "BW CleanUp Utility.properties";
	public static final String POC_IMPACTED_CUSTOM_TABLE  = "Impacted Custom Table.properties";
	public static final String POC_BW_STANDARD_EXTRACT  = "BW Standard Extract.properties";
	public static final String POC_INACTIVE_OBJECTS = "Inactive Objects.properties";
	public static final String POC_DRILLDOWN_REPORT = "DrillDown Report";
	
	//sheet match
	public static final String POC_INVENTORY_LIST = "Inventory List";
	public static final String POC_DRDB = "Impacted Due to DB change";

	public static final String POC_IMPACTED_OBJECT = "Impacted Object List";
	public static final String POC_S4_DETAIL_REPORT1 = "Impacted Due to Simplification";

	public static final String POC_EXISTING_ERRORS = "Existing Errors";
	public static final String POC_FIORI_ODATA = "Fiori Impact Analysis";
	public static final String POC_OUTPUT_MANAGEMENT = "Output Management";

	public static final String POC_AFFECTED_CUSTOM = "Affected by Custom Fields";
	public static final String POC_IMPACTED_TABLES = "Impacted Tables";

	public static final String POC_IMPACTED_IDOC = "Impacted IDOC";

	public static final String POC_IMPACTED_STANDARD = "Impacted Standard Transaction";
	public static final String POC_IMPACTED_SEARCH = "Impacted Search Help";

	public static final String POC_APPEND_STRUCTURE = "Append Structure Analysis";

	public static final String POC_CLONE_PROG = "Impacted Clone Program Analysis";

	public static final String POC_ENHANCEMENT = "Impacted Enhancement BADI";

	public static final String POC_S4_DETAIL_REPORT2 = "DR_S4 Simplification-2";
	public static final String POC_S4_DETAIL_REPORT3 = "DR_S4 Simplification-3";

	public static final String POC_UI5 = "UI5 Final Output.properties";
	public static final String POC_UI5_HIGHLEVEL = "UI5 High Level Report";
	public static final String POC_TESTING_SCOPE = "Testing Scope";
	
	public static final String POC_IMPACTED_BACKGROUND_JOB = "Impacted Background Job";
	public static final String POC_SMODILOG = "Smodilog";
	
	public static final String POC_IMPACTEDSAP_SCRIPTS = "Impacted SAP Scripts";
	public static final String POC_OS_MIGRATION_1_1 = "Impacted Due To OS Migration";
	public static final String POC_OS_MIGRATION_2_2 = "Logical CMD impacted by OS Chg";
	public static final String POC_OS_MIGRATION_3_3 = "File path impacted by OS Change";
 	
	public static final String POC_IMPACTEDCLONE_ANALYSIS = "Impacted Clone Analysis";
	public static final String POC_INCONSISTENTFUGR = "Inconsistent Function Groups";
	public static final String POC_HARDCODING = "Hardcoding";
	public static final String POC_IMPACTEDVARIANT = "Impacted Variant";
	public static final String POC_NONUNICODE = "Non-Unicode Objects";
	
	public static final String POC_CVITROUTPUT  = "CVITR Output";
	public static final String POC_CVITOUTPUT  = "CVIT OUTPUT";
	public static final String POC_BWINVENTORY  = "BW Inventory";
	public static final String POC_FIORIOUTPUT  = "Fiori Output";
	public static final String POC_BW_CLEANUPUTILITY  = "BW CleanUp Utility";
	public static final String POC_IMPACTEDCUSTOM_TABLE  = "Impacted Custom Table";
	public static final String POC_BWSTANDARD_EXTRACT  = "BW Standard Extract";
	public static final String POC_INACTIVEOBJECTS = "Inactive Objects";
	public static final String POC_DRILLDOWNREPORT = "DrillDown Report";
	
	public static final String POC_SECANALYZER_TCD_REPORT = "Security Analyser TCD Report";
}
