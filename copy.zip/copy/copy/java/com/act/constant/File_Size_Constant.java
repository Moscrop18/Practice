/*MODIFIED 
 *For Enhancement CR-1.0: - Update the automation_Status according to Sel_line -20/12/16 - monika.mishra
 *
 *CR-4.0:- Industry Group field changes from text field to drop-down. -04/01/17 -monika.mishra
 *
 *CR-9.0:- Manual upload for Estimator & assuptions -17/01/17 -monika.mishra
 *
 *CR-13.0:- New Output sheet implementation. -03/03/17 -monika.mishra
 *
 *CR-26.0:-adding 3 New Sheets implementation -25/07/17-rohan.a.mehra
 *
 *CR-39: Change in dashboard page size to 2 -20/12/2017-rohan.a.mehra
 *
 **/

package com.act.constant;


public class File_Size_Constant {
	public static final Long KB=1024L;
	public static final Long MB=1024*KB;
	
	public static final Long ZAICAT_DETECTION_SIZE = 200*MB;
	public static final Long USAGE_ANALYSIS_SIZE = 1*MB;
	public static final Long IMPACTED_CLONE_SIZE = 2*MB;
	public static final Long TRDIR_SIZE = 25*MB;
	public static final Long SEARCH_SIZE = 100*KB;
	public static final Long INVENTORY_SIZE = 5*MB;
	public static final Long IMPACTED_TABLES_SIZE = 2*MB;
	public static final Long IMPACTED_STANDARD_TRANSACTION_SIZE = 25*MB;
	public static final Long IDOC_SIZE = 1000*KB;
	public static final Long ENHANCEMENT_SIZE = 1000*KB;
	public static final Long CLONE_SIZE = 2*MB;
	public static final Long APPEND_SIZE = 500*KB;
	public static final Long SIMPLIFCATION_SIZE = 50*MB;
	public static final Long SIMPLIFCATION_DB_SIZE = 50*MB;
	public static final Long VALIDATION_SIZE =50*MB ;
	public static final Long ROM_SIZE =500*KB ;
	public static final Long FINAL_REPORT_SIZE = 200*MB;
	public static final Long TADIR_SIZE =20*MB;
	public static final Long ESTIMATE_SIZE = 100*KB;
	public static final Long ARG_USER_SIZE = 50*MB;
	public static final Long SRC_ARG1251_SIZE = 100*MB;
	public static final Long SRC_USOBTC_SIZE = 50*MB;
	public static final Long TRG_USOBTC_SIZE = 50*MB;
	public static final Long TR_SIZE =1000*KB;
	public static final Long DEL_TR_SIZE =1000*KB; 
	public static final Long REVIEW_CHECKLIST_SIZE =200*KB;
	public static final Long CR_SIZE =5*MB;
	public static final Long SAMPLE_REPORT_FAQ_SIZE =50*MB;
	public static final Long FIAT_DOC_SIZE =100*KB;
	public static final Long FIAT_TXT_SIZE =100*KB;
	public static final Long FIAT_OTHER_SIZE =20*MB;
	public static final Long TCD_SIZE =50*MB;
	public static final Long SMODILOG_SIZE =5*MB;
	public static final Long PRE_REQ_SIZE =5000*KB;
	public static final Long FIAT_FI_SIZE =1*MB;
	public static final Long RSICCONT_SIZE =50*MB;
	public static final Long RSANT_PROCESSR_SIZE =20*MB;
	public static final Long RSBKREQUEST_SIZE =20*MB;
	public static final Long RSRREPDIR_SIZE =20*MB;
	public static final Long RSBKDTP_SIZE =20*MB;
	public static final Long RSBKDTPSTAT_SIZE =20*MB;
	public static final Long RSTRAN_SIZE =20*MB;
	public static final Long RSPCPROCESSLOG_SIZE =20*MB;
	public static final Long RSDODSO_SIZE =20*MB;
	public static final Long RSDCUBE_SIZE =20*MB;
	public static final Long RSZWBTMPDATA_SIZE =20*MB;
	public static final Long RSZWTEMPLATE_SIZE =20*MB;
	public static final Long BIOAPEARS_SIZE =20*MB;
	public static final Long RSRWBINDEXT_SIZE =20*MB;
	public static final Long RSRWORKBOOK_SIZE =20*MB;
	public static final Long RSPCCHAIN_SIZE =20*MB;
	public static final Long GRT_GRACFUNCACT_SIZE =20*MB;
	public static final Long UNICODE =20*MB;
	public static final Long METADATA_SIZE = 25*MB;
	public static final Long COMPLEXITY_RULES_SIZE = 50*KB;
	public static final Long EXTENSIBILITY_RULES_SIZE = 50*KB;
	public static final Long BwInventory_SIZE = 10*MB;
	public static final Long TESTSCOPE_TCODE_SUBPROCESS_MAPPING = 10*MB;
	public static final Long TESTSCOPE_APPCOMP_SUBPROCESS_MAPPING = 10*MB;
	public static final Long BW_SIZE =20*MB;
	public static final Long INACTIVE_OBJECT_SIZE = 10*MB;
	public static final Long BUSINESS_PROCESS_DETAIL_SIZE = 10*MB;
	public static final int SA_REPORT_MAX_SIZE = 1000000;
	public static final Long ACNIP_ZVER_COMP_SIZE = 20*MB;
	public static final Long Fiori_Rebuild_SIZE = 20*MB;
	public static final Long BW_EXTRACTOR_SIZE = 20*MB;
	public static final Long CUSTOM_REPORT_OUTPUT_SIZE = 100*MB;

}
