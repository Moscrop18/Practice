/*MODIFIED 
 *For Enhancement CR-1.0: - Update the automation_Status according to Sel_line -20/12/16 - monika.mishra
 *
 *CR-4.0:- Industry Group field changes from text field to drop-down. -04/01/17 -monika.mishra
 *
 *CR-9.0:- Manual upload for Estimator & assuptions -17/01/17 -monika.mishra
 *
 *CR-13.0:- New Output sheet implementation. -03/03/17 -monika.mishra
 *
 *CR-26.0:-adding 3 New Sheets implementation -25/07/17-rohan.a.mehra
 *
 *CR-39: Change in dashboard page size to 2 -20/12/2017-rohan.a.mehra
 *
 **/

package com.act.constant;

import java.util.HashMap;
import java.util.Map;

public class Hana_Profiler_Constant {
	public static final int Hana_Column_Width = 99;

	//CR-1.0: -- add constant for op_code=19
	public static final String op_Code_19 = "19";
	public static final String op_Code_99 = "99";
	public static final String op_Code_45 = "45";
	public static final String op_Code_46 = "46";
	public static final String op_Code_20 = "20";
	public static final String op_Code_21 = "21";
	
	public static final String POC_TRANSFER_DATA_FAIL = "Error in Reading and Transfer of Data to Tables from Excel Sheets Failure";
	public static final String POC_REQUESTMASTER_CALC_SUCCESS = "Request Master Count Calculations Successful";
	public static final String POC_REQUESTMASTER_CALC_FAIL = "Error while Request Master Count calculation in POC Detailed Report/File Validation";
    public static final String POC_DATATRANSFER_FAIL = "Error while Transfering Data in POC Detailed Report/File Validation";
    public static final String POC_CLEAR_TABLE_FAIL = "Error while Clearing Data from Tables in POC Detailed Report/File Validation";
	
	public static final String Sub_Type_Val = "N/A";
	public static final String Include = "I";
	public static final String Executable = "1";
	public static final String Subroutine = "S";
	public static final String Module = "M";
	public static final String Function = "F";
	// public static final int tr_dir_prog_Name=1;
	public static final int tr_dir_Subc_Value = 1;
	public static final String IP = "Include Program";
	public static final String EP = "Executable program";
	public static final String SP = "Subroutine Pool";
	public static final String MP = "Module Pool";
	public static final String FG = "Function Group";

	public static final int output_profilr_total_row_count = 0;
	public static final String QUOTES = "\"";

	public static final String UPLOAD_SINGLE_FILE_CONSTANT = "single";

	public static final String UPLOAD_MULTIPL_FILE_CONSTANT = "multiple";

	public static final String ZIP_FILE_EXTENSION = "zip";
	public static final String XLSX_FILE_EXTENSION = "xlsx";
	public static final String XLS_FILE_EXTENSION = "xls";
	public static final String XLSM_FILE_EXTENSION = "xlsm";

	public static final String PROCEED_ACTION = "proceed";
	public static final String CANCEL_ACTION = "cancel";

	public static final String DAO_EXCEPTION_MESSAGE = "Something went wrong. Please try again.";
	public static final String YES = "YES";

	public static final String TR_FILE_NOT_FOUND_COMMENTS = "There is no Transport Request File for the specified Version";
	public static final String TR_FILE_FOUND_COMMENTS = "Transort Request File is Updated.";
	public static final String FILE_NAME_SEPARATOR = "_";
	public static final String COMMA_SEPERATOR = ",";
	public static final String SEMI_COLON_SEPERATOR = ";";

	public static final String ALL = "All";

	public static final String EXCEL_CONVERSION_PROPERTY_FILE_NAME = "ExcelConversitonData.properties";
	public static final String ZIP_EXTENSTION_CONSTANT = ".zip";
	public static final String XLSX_EXTENSTION_CONSTANT = ".xlsx";

	public static final String GREATER_THAN_SIGN = ">";
	public static final String LESS_THAN_SIGN = "<";

	public static final String HIGH = "HIGH";
	public static final String MEDIUM = "MEDIUM";
	public static final String LOW = "LOW";
	public static final String VERY_HIGH = "VERY HIGH";

	public static final int JDBC_BATCH_SIZE = 50000;

	public static final Map<Long, Map<String, String>> REQUEST_PROGRESS_MAP = new HashMap<Long, Map<String, String>>();

	public static final String PERCENTAGE_KEY = "completionPercentage";
	public static final String COMMENTS_KEY = "comments";

	public static final int ST03_INSERT_QUERY_PROCESS_PERCENT_VALUE = 31;
	public static final int ST03_COMPLETE_PROCESS_PERCENT_VALUE = 33;

	public static final int ST03_CUSTOM_QUERY_PROCESS_VALUE = 34;
	public static final int ST03_CUSTOM_DIALOG_PROCESS_PERCENT_VALUE = 35;
	public static final int SQL_19_QUERY_PROCESS_VALUE = 37;
	public static final int SQL_20_QUERY_PROCESS_VALUE = 38;
	public static final int SQL_21_QUERY_PROCESS_VALUE = 40;
	public static final int SQL_22_QUERY_PROCESS_VALUE = 42;
	public static final int SQL_23_QUERY_PROCESS_VALUE = 43;
	public static final int SQL_24_QUERY_PROCESS_VALUE = 44;
	public static final int SQL_25_QUERY_PROCESS_VALUE = 46;
	public static final int SQL_26_QUERY_PROCESS_VALUE = 48;
	public static final int SQL_29_QUERY_PROCESS_VALUE = 49;
	public static final int SQL_30_QUERY_PROCESS_VALUE = 50;
	public static final int SQL_31_QUERY_PROCESS_VALUE = 51;
	public static final int SQL_32_QUERY_PROCESS_VALUE = 52;
	public static final int SQL_35_QUERY_PROCESS_VALUE = 53;
	public static final int SQL_33_QUERY_PROCESS_VALUE = 54;
	public static final int SQL_34_SUB_QUERY_PROCESS_VALUE = 55;
	public static final int SQL_34_QUERY_PROCESS_VALUE = 56;
	public static final int SQL_38_QUERY_PROCESS_VALUE = 57;
	public static final int SQL_39_QUERY_PROCESS_VALUE = 58;
	public static final int SQL_36_QUERY_PROCESS_VALUE = 59;
	public static final int SQL_37_QUERY_PROCESS_VALUE = 60;
	public static final int SQL_40_QUERY_PROCESS_VALUE = 61;
	public static final int SQL_41_QUERY_PROCESS_VALUE = 62;
	public static final int SQL_27_QUERY_PROCESS_VALUE = 64;
	public static final int HANA_QUERY_PROCESS_PERCENT_VALUE = 66;

	public static final int CHECK_SUB_NA_VALUE_PROCESS_PERCENT_VALUE = 68;
	public static final int ADD_TR_DR_FILE_PROCESS_PERCENT_VALUE = 71;
	public static final int MANUAL_UPDATE_PROCESS_PERCENT_VALUE = 76;
	public static final int MANUAL_UPDATE_READ_DATA_PROCESS_PERCENT_VALUE = 73;
	public static final int REFINE_OP_99_PROCESS_PERCENT_VALUE = 81;
	public static final int REFINE_LOOP_COLUMN_PROCESS_PERCENT_VALUE = 86;
	public static final int REFINE_IMPACT_VALUE_CODE_PROCESS_PERCENT_VALUE = 89;
	public static final int REFINE_IMPACT_VALUE_PROCESS_PERCENT_VALUE = 91;
	public static final int REFINE_UNWANTED_CATEGORY_CODE_PROCESS_PERCENT_VALUE = 93;
	public static final int REFINE_UNWANTED_CATEGORY_PROCESS_PERCENT_VALUE = 96;
	public static final int HANA_REFINING_PROCESS_PERCENT_VALUE = 98;
	public static final int PROCESS_COMPLETE_PERCENT_VALUE = 100;

	public static final int FAILED_PROCESS_PERCENT_VALUE = 100;

	public static final String ST03_IN_PROGRESS_MSG = "Analysis is in progress.";
	public static final String ST03_SUCCESS_MSG = "Analysis process has been completed.";

	public static final String ST03_FAILURE_MSG = "Analysis process has been failed. Please contact POC.";

	public static final String HANA_QUERY_SUCESS_MSG = "Hana Query process has been completed";

	public static final String HANA_QUERY_IN_PROGRESS_MSG = "Hana Query process is in progress.";

	public static final String HANA_QUERY_FIALED_MSG = "Hana Query process has been failed. Please contact POC.";

	public static final String PROCESS_COMPLETE_MSG = "Process is completed. Click on dashboard to view your report.";

	public static final String HANA_REFINING_PROCESS_FAILED_MSG = "Hana Refining Proces has been failed. Please contact POC.";
	public static final String REFINING_PROCESS_FAILED_MSG = "Refining Proces has been failed. Please contact POC.";
	
	public static final String HANA_REFINING_PROCESS_IN_PROGRESS_MSG = "Refining process is in progress.";

	public static final String INITIATED_STATUS = "Initiated";
	public static final String APPROVED_STATUS = "Approved";
	public static final String REJECTED_STATUS = "Rejected";
	public static final String IDVFAILED_STATUS = "IDVFailed";
	public static final String PENDING_STATUS = "Pending";
	public static final String IDVSUCESS_STATUS = "IDVSuccess";
	public static final String ST03FAILED_STATUS = "ST03Failed";
	public static final String ST03SUCCESS_STATUS = "ST03Success";
	public static final String HANAQUERYSUCCESS_STATUS = "HANAQuerySuccess";
	public static final String HANAQUERYFAILED_STATUS = "HANAQueryFailed";
	public static final String COMPLETED_STATUS = "Completed";
	public static final String NOT_COMPLETED_STATUS = "Not Completed";
	public static final String HANAREFININGFAILED_STATUS = "HANARefiningFailed";
	public static final String ROMREFININGFAILED_STATUS = "ROMRefiningFailed";
	public static final String REFININGFAILED_STATUS = "HANARefiningFailed";
	public static final String HANAREFININGSUCCESS_STATUS = "HANARefiningSuccess";
	public static final String HANAREFININGCOMPLETED = "HanaRefiningCompleted";
	public static final String ROMREFININGSUCCESS_STATUS = "ROMRefiningSuccess";
	public static final String ROMREFININGCOMPLETED = "RomRefiningCompleted";
	public static final String REFININGSUCCESS_STATUS= "RefiningSuccess";
	//Added for Summary Details implementation
	public static final String INPROGRESS_STATUS = "InProgress";
	public static final String EMPTY = "";
	public static final String INQUEUE = "InQueue";
	
	/*CR-9.0 Monika*/
	public static final String HANAREFININGCOMPLETED_STATUS = "HANARefiningCompleted";
	public static final String Prosess_SUCCESS = "Completed";
	public static final String Prosess_FAILURE = "Not Completed";
	
	/*CR-9.0 Monika*/
	public static final String COMPLETED_PENDING_ESTIMATIONS = "Completed With Pending Estimations";	
	public static final String ACCESS_TRUE = "true";	
	public static final String ACCESS_FALSE = "false";	
	
	/*CR-13.0 Monika*/
	public static final String USER_ROLE_CLIENT = "client";	
	public static final String USER_ROLE_ADMIN = "admin";	

	// TODO: check constant
	public static final String HANA = "HANA";

	public static final String IDVSUCCESS_STATUS_COMMENT = "IDVSuccess";
	public static final String ST03SUCCESS_STATUS_COMMENT = "ST03 Analysis Completed Succesfully";
	public static final String ST03FAILED_STATUS_COMMENT = "ST03 Analysis Failed";
	public static final String HANAQUERYSUCCESS_STATUS_COMMENT = "HANA QueryCompleted Succesfully";
	public static final String HANAQUERYFAILED_STATUS_COMMENT = "HANAQuery Processing Failed";
	
	
	/*CR-9.0 Monika*/
	public static final String REFININGSUCCESS_STATUS_COMMENT= "Process is completed Successfully with Pending Estimations.";
	
	public static final String HANAREFININGCOMPLETED_STATUS_COMMENT = "Process is completed Successfully.";

	public static final String HANAREFININGFAILED_STATUS_COMMENT = "Refining Failed";
	public static final String ROMREFININGFAILED_STATUS_COMMENT = "Refining Failed";

	public static final String  REFININGFAILED_STATUS_COMMENT = "Refining Failed";
	
	public static final String ST03FAILED_STATUS_EXCEPTION_COMMENT = "Exception in ST03 Analysis";

	public static final String FOUR_ZEROS = "0000";
	public static final String GRAPHICAL = "Graphical";

	public static final String ADMIN = "ADMIN";
	public static final String CLIENT = "CLIENT";
    public static final String POC = "POC";

	public static final String NULL = "null";

	public static final String CLIENT_ROLE = "ROLE_CLIENT";
	
	public static final String RFP_CLIENT_PENDING_STATUS = "ClientRFPUlPending";
	public static final String RFP_CLIENT_UL_FAILED_STATUS = "ClientRFPUlFailed";
	public static final String RFP_CLIENT_UL_SUCCESS_STATUS = "ClientRFPUlDone";
	public static final String RFP_CLIENT_PROC_SUCCESS_STATUS = "ClientRFPPrDone";
	public static final String RFP_CLIENT_PROC_FAILED_STATUS = "ClientRFPPrFailed";
	public static final String RFP_POC_DL_SUCCESS_STATUS = "POCRFPDlDone";
	public static final String RFP_POC_UL_SUCCESS_STATUS = "POCRFPUlDone";
	public static final String RFP_POC_UL_FAILED_STATUS = "POCRFPUlFailed";
	

	/**
	 * CR 21: Changes for implementing Admin/ POC/ Client functionality.
	 */
	public static final String POC_ROLE = "ROLE_POC";
	public static final String ADMIN_ROLE = "ROLE_ADMIN";

	public static final String DELETE_TR_FILE_VALUE_SEPARATOR = "##\\$\\$##";

	public static final Integer DASHBOARD_PAGE_SIZE = 2;
	public static final String CLIENT_DASHBOARD_TABLE_ID = "rowId";

	public static final String POC_INITIATED_REQUEST_TABLE_ID = "initiatedRequestTableId";

	public static final String SOURCE_VERSION = "sourceVersion";
	public static final String TARGET_VERSION = "targetVersion";

	public static final Map<Long, Map<String, Map<String, String>>> ID_FILE_KEY_VALUE = new HashMap<Long, Map<String, Map<String, String>>>();
	
	
	//DEF07: added constant for IGList to be displayed in the drop down list.
	public static final String IG_CMT = "Communications, Media & Technology (CMT)";
	public static final String IG_FS = "Financial Services (FS)";
	public static final String IG_HPS = "Health & Public Service (H&PS)";
	public static final String IG_Product = "Product (PRD)";
	public static final String IG_RS = "Resources (RES)";
		
	//DEF07 : added constant for SubIGList to be displayed in the drop down list.
		public static final String Com = "Communications";
		public static final String EHT = "Electronics & High Tech";
		public static final String ME = "Media & Entertainment";
		public static final String BCM = "Banking & Capital Markets";
		public static final String Ins = "Insurance";
		public static final String Health = "Health";
		public static final String PS = "Public Service";
		public static final String CGRTS = "Consumer Goods, Retail & Travel Service";
		public static final String Industrial = "Industrial";
		public static final String LS = "Life Sciences";
		public static final String CNR = "Chemicals & Natural Resources";
		public static final String Energy = "Energy";
		public static final String Utilities = "Utilities";
				
	
	//CR-26:adding 3 New Sheets implementation
	public static final String op_Code_59 = "59";
	public static final String op_Code_60 = "60";
	public static final String op_Code_61 = "61";
	public static final String op_Code_62 = "62";
	public static final String op_Code_63 = "63";
	public static final String op_Code_64 = "64";
	public static final String op_Code_65 = "65";
	public static final String op_Code_66 = "66";
	public static final String op_Code_71 = "71";
	public static final String op_Code_72 = "72";
	public static final String op_Code_73 = "73";
	public static final String op_Code_74 = "74";
	public static final String op_Code_75 = "75";
	public static final String op_Code_76 = "76";
	
	public static final String USED_Y="Y";
	public static final String UNUSED_N="N";
	
	public static final String DISTINCT_COUNT="distinctCount";
	public static final String ERROR_COUNT="errorCount";
	
	public static final String USED_ALL_COUNT="usedAll";
	public static final String UNUSED_ALL_COUNT="unusedAll";
	
	public static final String USED_DISTINCT="usedDistinct";
	public static final String UNUSED_DISTINCT="unusedDistinct";
	
	public static final String FINAL_APPROVED_POC="FINAL_APPROVED_POC";
	public static final String COMPLETED_POC="COMPLETED_POC";
	public static final String OVERDUE="OVERDUE";
	
	public static final String FIAT_UPLOAD_DONE_POC="FIAT_UPLOAD_DONE_POC";
	
	public static final String INACTIVE_USER="InactiveUser";
	public static final String ACTIVE_USER="ActiveUser";
	public static final String NEW_USER="NewUser";
	
	public static final String USERREQUEST_ACTION_APPROVE = "Approve";
	public static final String USERREQUEST_ACTION_ACTIVATE = "Activate";
	public static final String USERREQUEST_ACTION_ARCHIVE = "Archive";
	public static final String USERREQUEST_ACTION_EXTEND = "Extend";
	public static final String USERREQUEST_ACTION_REJECT = "Reject"; 
	
	public static final String REQ_SS_INI = "Initiated";
	public static final String REQ_SS_REJ = "Rejected";
	public static final String REQ_SS_MAN_FL_UL_SUCC = "Mandatory File Upload Successful";
	public static final String REQ_SS_MAN_FL_UL_FAIL = "Mandatory File Upload Failed";
	public static final String REQ_SS_FIAT_FL_DL_SUCC = "FIAT file Download successful";
	public static final String REQ_SS_FIAT_FL_UL_SUCC= "FIAT file Upload successful";
	public static final String REQ_SS_PROCESSED_FL_DL_SUCC = "Processed file Download Successful";
	public static final String REQ_SS_FINAL_FL_APPROVED = "Final File Approved";
	public static final String REQ_SS_FINAL_FL_UL_FAIL = "Final file Upload Failed";
	public static final String REQ_SS_Estimate_FL_DL_SUCC = "Estimate File Download Successful";
	public static final String REQ_SS_ROM_Estimate_FL_DL_SUCC = "ROM Estimate File Download Successful";
	public static final String REQ_SS_ROM_Estimate_FL_UL_SUCC = "ROM Estimate File Uploaded Successful";
	public static final String REQ_SS_ROM_Estimate_FL_UL_FAIL = "ROM Estimate File Uploaded Failed";
	public static final String REQ_SS_COMPLETED = "Completed";
	
	public static final String IMPACT_TABLES_SYSTEM_ENVT_1 = "Analysis have been done in";
	public static final String IMPACT_TABLES_SYSTEM_ENVT_2 = "Environment which might be different from Production Environment";
	public static final String IMPACT_TABLES_TARGET_VER_1 = "Below tables are marked impacted because these are market impacted in Simplification Database of";
	public static final String IMPACT_TABLES_TARGET_VER_2 = "by SAP. These tables are considered as used because one or more record found in the table.";
	public static final String IMPACT_TRANSACTION_TARGET_VER = "Impacted Standard Transaction are used transactions taken from ST03 dump from Production and is part of simplification database for";

    
	/* Comments based on status at different journey points */
	public static final String CREATE_REQ_SUCC = "Request created. Need to assign POC.";
	public static final String REJECT_REQ = "Request Rejected.";
	public static final String ASSIGN_POC = "POC assigned. Need to upload CR/TR.";
	public static final String UPLOAD_TR_CR_SUCC = "TR & CR files uploaded. Need to upload input files.";
	public static final String UPLOAD_TR_CR_FAIL = "Uploading TR & CR files fails.";
	public static final String UPLOAD_INPUT_FILES_SUCC = "Uploading input files completed. Need to initiate client processing.";
	public static final String UPLOAD_INPUT_FILES_FAIL = "Uploading input files fails.";
	public static final String CLIENT_PROCESS_FAIL = "Client Processing of input files fails.";
	public static final String HANAREFININGSUCCESS_STATUS_COMMENT = "Detailed Report without Estimations generated. POC needs to review it.";
	public static final String ROMREFININGSUCCESS_STATUS_COMMENT = "Detailed Report ROM Estimations generated. POC needs to review it.";
	public static final String POC_DOWNLOAD_SUMM_SUCC = "Summary Detailed Report downloaded by POC. POC needs to review it.";
	public static final String POC_UPLOAD_SUMM_SUCC = "Summary Detailed Report reviewed and uploaded by POC.";
	public static final String POC_UPLOAD_SUMM_FAIL = "Uploading of Summary Detailed Report by POC fails.";
	public static final String POC_DOWN_EST_SUCC = "Estimates Sheet generated successfully. POC needs to review it.";
	public static final String POC_UPLOAD_ESTIMATES_SUCC = "Estimates Sheet reviewed by POC. Client can view it.";
	public static final String POC_UPLOAD_ROMESTIMATES_SUCC = "ROM Estimates Sheet reviewed by POC. Client can view it.";
	public static final String POC_FIAT_DOWN_SUCC = "FIAT Files downloaded by POC.";
	public static final String POC_FIAT_UPLOAD_SUCC = "FIAT Output File uploaded by POC. Client can view it.";
	
	/* RFP journey point comments */
	public static final String ASSIGN_POC_RFP = "RFP Request. POC assigned.";
	public static final String DOWN_RFP_SUCC = "RFP Estimates downloaded by POC. POC needs to review it.";
	public static final String RFP_PROCESS_SUCC = "RFP client processing completed successfully.";
	public static final String RFP_PROCESS_FAIL = "RFP client processing fails.";
	public static final String RFP_POC_APPROVE = "RFP Estimates Sheet reviewed by POC. Client can view it.";
	public static final String RFP_POC_APPROVE_FAIL = "RFP Estimates Sheet upload fails.";
	public static final String RFP_UPLOAD_SUCC = "Client successfully uploaded RFP input file.";
	public static final String RFP_UPLOAD_FAIL = "Uploading RFP input file fails.";
	
	public static final String IMPACT_CUSTOM_TABLES_SYSTEM_ENVT_1 = "Analysis have been done in";
	public static final String IMPACT_CUSTOM_TABLES_SYSTEM_ENVT_2 = "Environment which might be different from Production Environment";
	public static final String IMPACT_CUSTOM_TABLES_TARGET_VER_1 = "Below custom tables are marked impacted because fields of these tables are using data elements or domains which are given as impacted in Simplification Database of";
	public static final String IMPACT_CUSTOM_TABLES_TARGET_VER_2 = "by SAP.";
	
	/*Sheet Names scope wise in Report*/
	public static final String INVENTORY_LIST = "Inventory List";
	public static final String ABAP_INVENTORY_LIST = "Abap Query Inventory List";
	public static final String IMPACTED_OBJECT = "Impacted Object List";
	public static final String DR_DB_CHANGE = "Impacted Due to DB change";
	public static final String IMPACTED_SIMPLIFICATION = "Impacted Due to Simplification";
	public static final String EXISTING_ERRORS = "Existing Errors";
	public static final String FIORI_ANALYSIS = "Fiori Impact Analysis";
	public static final String FIORI_CUSTOM_REPORT = "Custom Report Output";
	public static final String OUTPUT_MANAGEMENT = "Output Management";
	public static final String AFFECTED_CUSTOM_FIELDS = "Affected by Custom Fields";
	public static final String IMPACTED_TABLES = "Impacted Tables";
	public static final String IMPACTED_IDOC = "Impacted IDOC";
	public static final String IMPACTED_STANDARD_TRANSACTION = "Impacted Standard Transaction";
	public static final String SEARCH_HELP = "Impacted Search Help";
	public static final String STRUCTURE_ANALYSIS = "Append Structure Analysis";
	public static final String ENHANCEMENT_BADI = "Impacted Enhancement BADI";
	public static final String UI5_FINAL = "UI5 Final Output";
	public static final String UI5_HIGH_LEVEL = "UI5 High Level Report";
	public static final String TESTING_SCOPE = "Testing Scope";
	public static final String IMPACTED_BACKGROUND = "Impacted Background Job";
	public static final String SMODILOG = "Smodilog";
	public static final String SAP_SCRIPT = "Impacted SAP Scripts";
	public static final String IMPACTED_OS_MIGRATION = "Impacted Due To OS Migration";
	public static final String LOCIGAL_CMD_OS = "Logical CMD impacted by OS Chg";
	public static final String FILEPATH_OS = "File path impacted by OS Change";
	public static final String IMPACTED_CLONE = "Impacted Clone Analysis";
	public static final String CVITR = "CVITR Output";
	public static final String CVIT = "CVIT OUTPUT";
	public static final String CVI_MASTER_DATA = "CVI Master data and customizing";	
	public static final String NON_UNICODE = "Non-Unicode Objects";
	public static final String FUNCTIONAL_GROUPS = "Inconsistent Function Groups";
	public static final String HARDCODINGS = "Hardcoding";
	public static final String BW_INVENTORY = "BW Inventory";
	public static final String FIORI = "Fiori Output";
	public static final String IMPACTED_VARIANT = "Impacted Variant";
	public static final String BW_CLEANUP = "BW CleanUp Utility";
	public static final String CUSTOM_TABLES = "Impacted Custom Table";
	public static final String BW_STANDARD = "BW Standard Extract";
	public static final String INACTIVE_OBJECTS = "Inactive Objects";
	public static final String ACNIP_ZVER_COMP = "Mass Version Comparison";
	public static final String DRILL_DOWN_REPORT = "DrillDown Report";
	public static final String OBSOLETE_FMs = "Obsolete FMs due to Upgrade";
	public static final String CVIT_CUSTOM_LOGS = "CVIT Customising Logs";
	public static final String CVIT_ERROR_MESSGAES = "CVIT Error Messages in detail";
	public static final String TR_UPLOAD_DONE_POC = "TR_DONE_UPLOAD_POC";
	public static final String CREATE_SUBREQ_SUCC = "Sub Request created. Proceed with upload.";
	// IRPA Statuses
	public static final String IRPA_FILE_UPLOAD_SUCCESS = "IRPAFileUpload_Success";
	
	public static final String OTHERS = "Others";
}
