package com.act.constant;

public class Services_Constant {
	
	public static final String ZAICAT_DETECTION= "ZAICAT_DETECTION";
	public static final String TADIR_CONSTANT = "TADIR";
	public static final String TRDIR_CONSTANT = "trdir";
	public static final String UI5_CONSTANT = "UI5";
	public static final String SMODILOG_CONSTANT ="SMODILOG";
	public static final String CUSTOM_REPORT_OUTPUT_CONSTANT ="CUSTOM REPORT OUTPUT";
	
	public static final String ENHANCEMENT_CONSTANT= "ENHANCEMENT";
	
	public static final String TRD_CONSTANT = "trd";
	//CR-29.0
	public static final String CDS_CONSTANT = "cds";
	//CR-29.0
	public static final String CDS_REQUIRED_COLUMN_LIST="CDS_View,Table_Name";
	
	
	public static final String CLONE_CONSTANT = "CLONE";
	public static final String IMPACTED_CLONE_ANALYSIS_CONSTANT = "IMPACTED CLONE";
	public static final String USAGE_ANALYSIS_CONSTANT = "USAGE ANALYSIS";
	public static final String SEARCH_CONSTANT = "SEARCH";
	public static final String APPEND_CONSTANT = "APPEND";
	public static final String INVENTORY_CONSTANT = "INVENTORY LIST";
	
	public static final String ENHOBJ_CONSTANT = "ENHOBJ";
	public static final String SXC_CONSTANT = "SXC";
	public static final String V_CONSTANT = "V";
	
	public static final String IMPACTED_TABLES_CONSTANT = "IMPACTED TABLES";
	
	public static final String FUGR_CONSTANT = "FUGR";
	public static final String FUGS_CONSTANT = "FUGS";

	public static final String PROG_CONSTANT = "PROG";
	public static final String CLAS_CONSTANT = "CLAS";
	
	public static final String SSFO_CONSTANT = "SSFO";
	public static final String SFPI_CONSTANT = "SFPI";

	public static final String ENHO_CONSTANT = "ENHO";
	public static final String ENHC_CONSTANT = "ENHC";
	public static final String ENHS_CONSTANT = "ENHS";
	
	public static final String USRR_CONSTANT = "USRR";
	public static final String USRE_CONSTANT = "USRE";

	public static final String LSMW_CONSTANT = "LSMW";
	
	public static final String IDOC_CONSTANT = "IDOC";
	
	public static final String PDTS_CONSTANT = "PDTS";
	public static final String PDWS_CONSTANT = "PDWS";
	public static final String PDAC_CONSTANT = "PDAC";
	public static final String PDTG_CONSTANT = "PDTG";

	public static final String WDYN_CONSTANT = "WDYN";

	public static final String SRC_AGR1251_CONSTANT = "SRC_AGR1251";
	public static final String SRC_USOBTC_CONSTANT = "SRC_USOBTC";
	public static final String SRC_USERS_CONSTANT = "SRC_AGRUSERS";
	
	public static final String RSICCONT_CONSTANT = "RSICCONT";
	public static final String RSANT_PROCESSR_CONSTANT = "RSANT_PROCESSR";
	public static final String RSBKREQUEST_CONSTANT = "RSBKREQUEST";
	public static final String RSRREPDIR_CONSTANT = "RSRREPDIR";
	public static final String RSBKDTP_CONSTANT = "RSBKDTP.XLSX";
	public static final String RSBKDTPSTAT_CONSTANT = "RSBKDTPSTAT.XLSX";
	public static final String RSTRAN_CONSTANT = "RSTRAN";
	public static final String RSPCPROCESSLOG_CONSTANT = "RSPCPROCESSLOG";
	public static final String RSDCUBE_CONSTANT = "RSDCUBE";
	public static final String RSZWBTMPDATA_CONSTANT = "RSZWBTMPDATA";
	public static final String RSDODSO_CONSTANT = "RSDODSO";
	public static final String RSZWTEMPLATE_CONSTANT = "RSZWTEMPLATE";
	public static final String BIOAPEARS_CONSTANT = "BIOAPERS_SOD00";
	public static final String RSRWBINDEXT_CONSTANT = "RSRWBINDEXT";
	public static final String RSRWORKBOOK_CONSTANT = "RSRWORKBOOK";
	public static final String RSPCCHAIN_CONSTANT = "RSPCCHAIN";
	
	public static final String GRT_GRACFUNCACT_CONSTANT = "GRT_GRACFUNCACT_details";

	//newly Added
	public static final String RSRWBINDEX_CONSTANT = "RSRWBINDEX";
	public static final String RSDIOBJ_CONSTANT = "RSDIOBJ";
	public static final String RSQISET_CONSTANT = "RSQISET";
	public static final String RSBOHDEST_CONSTANT = "RSBOHDEST";
	public static final String RSANT_PROCESS_CONSTANT = "RSANT_PROCESS";
	public static final String RSOHCPR_CONSTANT = "RSOHCPR";
	public static final String RSUPDINFO_CONSTANT = "RSUPDINFO";
	public static final String RSTS_CONSTANT = "RSTS";
	public static final String RSDS_CONSTANT = "RSDS";
	public static final String RSLDPIO_CONSTANT = "RSLDPIO";
	public static final String RSZWBTMPHEAD_CONSTANT = "RSZWBTMPHEAD";
	public static final String RSPCCHAINATTR_CONSTANT = "RSPCCHAINATTR";
	public static final String UNICODE_CONSTANT = "UNICODE";
	
	public static final String METADATA_EXT = "METADATA";
	public static final String USAGE_ANALYSIS_EXT = "USAGE_ANALYSIS_EXT";
	public static final String COMPLEXITY_RULES = "COMPLEXITY_RULES";
	public static final String EXTENSIBILITY_RULES = "EXTENSIBILITY_RULES";
	public static final String INACTIVE_OBJECTS = "Inactive_Objects";
	public static final String BUSINESS_PROCESS_DETAIL = "Business Process Detail";
}
