package com.act.fileprocesing.dao;

import java.util.List;

import javax.servlet.http.HttpSession;

import com.act.fiori.models.OdataFioriApps;

public interface FioriProcessingDAO {

	public String processFioriApps(final long requestID,List<OdataFioriApps>odataFioriAppsList ,String sourceVersion, String targetVersion,HttpSession session) throws Exception;
	
}
