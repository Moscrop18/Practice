package com.act.fileprocesing.dao;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpSession;

import com.act.fiori.models.FioriAppsOutput;
import com.act.fiori.models.OdataFioriApps;
import com.act.utility.odatafiori.AppsType;

public interface OdataFioriProcessDao {
	public String processFioriApps(final long requestID,List<OdataFioriApps>odataFioriAppsList , String targetVersion,HttpSession session) throws SQLException, Exception;
	
	public void updateRequestMasterFiori(long requestId) ;
	
	public List<AppsType> getFioriDataFromDB(HttpSession session, String target);
	
	public String insertFioriAppsData(List<AppsType> appsTypeList, HttpSession session,
			Long requestId) throws SQLException;
	
	public List<FioriAppsOutput> getFioriOutputData(long requestId);
	
	public List<AppsType> getFioriMasterData();
}
