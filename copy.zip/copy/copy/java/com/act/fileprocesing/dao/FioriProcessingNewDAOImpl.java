package com.act.fileprocesing.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.act.displaygrid.model.DBConfig;
import com.act.fiori.models.CustomReportOutput;
import com.act.fiori.models.FioriFinalOutputList;
import com.act.fiori.models.OdataFioriMasterData;
import com.act.master.FioriRequestMaster;
import com.act.model.DRL.CodeAssessmentPayLoad;
import com.act.utility.odatafiori.DBConfigFiori;
import com.act.utility.odatafiori.OdataFiori_Constants;

@Transactional
@Repository
public class FioriProcessingNewDAOImpl implements FioriProcessingNewDAO {
	protected final static Logger logger = LoggerFactory.getLogger(FioriProcessingNewDAOImpl.class);
	SessionFactory sessionFactory;

	static FioriFinalOutputList fioriFinalOutputList;

	static CodeAssessmentPayLoad hm = new CodeAssessmentPayLoad();

	public static CodeAssessmentPayLoad getHm() {
		return hm;
	}

	public void setHm(CodeAssessmentPayLoad hm) {
		this.hm = hm;
	}
	public static FioriFinalOutputList getFioriFinalOutputList() {
		return fioriFinalOutputList;
	}

	public static void setFioriFinalOutputList(FioriFinalOutputList fioriFinalOutputList) {
		OdataFioriProcessDaoImpl.fioriFinalOutputList = fioriFinalOutputList;
	}

	private String hql;
	static FioriRequestMaster fioriRequestMaster = new FioriRequestMaster();

	public static FioriRequestMaster getFioriRequestMaster() {
		return fioriRequestMaster;
	}

	public static void setFioriRequestMaster(FioriRequestMaster fioriRequestMaster) {
		OdataFioriProcessDaoImpl.fioriRequestMaster = fioriRequestMaster;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@SuppressWarnings("null")
	@Override
	public String processFioriApps(final long requestID, List<CustomReportOutput> customReportOutputList, String sourceVersion, String targetVersion,
			HttpSession session) throws Exception {
		try {
			logger.info("Inside processFioriApps method ..");
			fioriFinalOutputList = new FioriFinalOutputList();
			List<OdataFioriMasterData> fioriMasterDataList = getFioriFromMasterData(session);
			//call method to capture source, pass (sourceVersion)
			String srcVersion=getSrcVersion(sourceVersion);
			List<Map<String,String>> fioriAppListResultMapList = getFioriAppListLibraryMasterData(session,srcVersion);
			Map<String,String> fioriAppListFioriIdResultMap = fioriAppListResultMapList.get(0);
			Map<String,String> fioriAppListBusinessCatalogNameResultMap = fioriAppListResultMapList.get(1);
			Map<String,String> fioriAppListComponentResultMap = fioriAppListResultMapList.get(2);
			List<CustomReportOutput> customReportOutputNewList = new ArrayList<CustomReportOutput>();

			for (CustomReportOutput customReportOutput : customReportOutputList) {
				if(fioriAppListBusinessCatalogNameResultMap!=null&&!fioriAppListBusinessCatalogNameResultMap.isEmpty()&&!fioriAppListBusinessCatalogNameResultMap.containsKey(customReportOutput.getTechnicalCatalogId().toLowerCase()))
				{
					if (fioriAppListFioriIdResultMap.containsKey(customReportOutput.getConcat().toLowerCase())) {
						customReportOutput.setFioriId(fioriAppListFioriIdResultMap.get(customReportOutput.getConcat().toLowerCase()));
						customReportOutput.setComponent(fioriAppListComponentResultMap.get(customReportOutput.getConcat().toLowerCase()));
					}
					customReportOutputNewList.add(customReportOutput);
				}
			}
			buildFioriFinalOutputUpdate(requestID, customReportOutputNewList, fioriMasterDataList, sourceVersion, targetVersion, session);// comment
			updateAvailabilityAndVersion(requestID, session, targetVersion);
		} catch (Exception e) {
			logger.error("Catching exception stack trace.............. ..", e);
			throw new Exception("Exception in processing Fiori files");
		}
		return "success";
	}
	
	public String getSrcVersion(String sourceVersion) {
		String srcVersion="";
		if(sourceVersion.startsWith("S/4HANA"))
		{
			srcVersion= sourceVersion.split("S/4HANA")[1];
			if(srcVersion.contains("1503"))
			{
				srcVersion="1511";
			}
		}
		else if(sourceVersion.contains("ECC")||sourceVersion.contains("4.6")||sourceVersion.contains("4.7"))
		{
			srcVersion= "ERP";
		}
		return srcVersion;
	}

	protected void buildFioriFinalOutputUpdate(final long requestID, List<CustomReportOutput> customReportOutputNewList,
			List<OdataFioriMasterData> fioriMasterDataList, String sourceVersion, String targetVersion, HttpSession session)
			throws SQLException {
		List<CustomReportOutput> customReportOutputFinalList = new ArrayList<CustomReportOutput>();
		for (CustomReportOutput customReportOutput : customReportOutputNewList) {
			for (OdataFioriMasterData fioriMasterData : fioriMasterDataList) {
				String srcVersion = ""; 
					if (sourceVersion.startsWith("S/4HANA")) {
						srcVersion = sourceVersion.split("S/4HANA")[1];
					} else if (sourceVersion.equalsIgnoreCase("ECC6.0EHP7")) {
						srcVersion = "SAP enhancement package 7";
					} else if (sourceVersion.equalsIgnoreCase("ECC6.0EHP8")) {
						srcVersion = "SAP enhancement package 8";
					}
					String pvBackendCombined = fioriMasterData.getPvBackendCombined();

					//if sourceVersion.contains("ECC"), srcVersion="ERP";
					
				if (fioriMasterData.getAppId().equalsIgnoreCase(customReportOutput.getFioriId())) {
					customReportOutput.setAppName(fioriMasterData.getAppName());
					customReportOutput.setPvBackendCombined(pvBackendCombined);
					
					if (!srcVersion.equalsIgnoreCase("") && pvBackendCombined.contains(srcVersion)) {

						String version = "";
						if (targetVersion.startsWith("S/4HANA"))
							version = targetVersion.split("S/4HANA")[1];
						if (pvBackendCombined.contains(version)) {
							customReportOutput.setAvailability("Available in " + version);
							customReportOutput.setVersion("");
							customReportOutput.setAltName("Activate the application");
						} else {
							customReportOutput.setAvailability("Not Available in " + version);
							customReportOutput = checkSuccessorRelatedFioriApp(fioriMasterData, fioriMasterDataList,
									customReportOutput, targetVersion);
						}

					}
				}
				
			}
			customReportOutputFinalList.add(customReportOutput);

		}
		
		customReportOutputFinalInsert(customReportOutputFinalList, session);
	}
	

	protected CustomReportOutput checkSuccessorRelatedFioriApp(OdataFioriMasterData fioriMasterData,
			List<OdataFioriMasterData> fioriMasterDataList, CustomReportOutput customReportOutput,
			String targetVersion) {

		String appId = "";
	

		if (fioriMasterData != null) {
			if (!fioriMasterData.getSuccessorApp().equalsIgnoreCase("NA")) {
				appId = fioriMasterData.getSuccessorApp();
				for (OdataFioriMasterData app : fioriMasterDataList) {
					if (app.getAppId().equalsIgnoreCase(appId)) {
						String pvBackendCombined = app.getPvBackendCombined();
						String version = "";
						if (targetVersion.startsWith("S/4HANA"))
							version = targetVersion.split("S/4HANA")[1];
						if (pvBackendCombined.contains(version)) {
							customReportOutput.setSuccessorApp(fioriMasterData.getSuccessorApp());
							customReportOutput.setRelatedApp("");
						} else {
							customReportOutput.setSuccessorApp("");
							customReportOutput.setRelatedApp("");
						}
					}
				}
			}
			if (!fioriMasterData.getRelatedApp().equalsIgnoreCase("NA")) {
				appId = fioriMasterData.getRelatedApp();
				for (OdataFioriMasterData app : fioriMasterDataList) {
					if (app.getAppId().equalsIgnoreCase(appId)) {
						String pvBackendCombined = app.getPvBackendCombined();
						String version = "";
						if (targetVersion.startsWith("S/4HANA"))
							version = targetVersion.split("S/4HANA")[1];
						if (pvBackendCombined.contains(version)) {
							customReportOutput.setSuccessorApp("");
							customReportOutput.setRelatedApp(fioriMasterData.getRelatedApp());
						} else {
							customReportOutput.setSuccessorApp("");
							customReportOutput.setRelatedApp("");
						}
					}
				}
			}
		}
		return customReportOutput;
	}
	
	

	protected List<OdataFioriMasterData> getFioriFromMasterData(HttpSession session) throws SQLException {
		
		final String SELECT_SQL = "Select AppId, BspName, BSPNameCombined, ODataServicesCombined,AppName,PVBackendCombined,successorApp,relatedApp from Fiori_MasterData";
		List<OdataFioriMasterData> masterDataList = new ArrayList<OdataFioriMasterData>();
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);

			conn.setAutoCommit(false);

			stmt = conn.prepareStatement(SELECT_SQL);

			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {

				OdataFioriMasterData fioriMasterData = new OdataFioriMasterData();
				fioriMasterData.setAppId(rs.getString("AppId"));
				fioriMasterData.setBspName(rs.getString("BspName"));
				fioriMasterData.setBspNameCombined(rs.getString("BSPNameCombined"));
				fioriMasterData.setOdataServicesCombined(rs.getString("ODataServicesCombined"));
				fioriMasterData.setAppName(rs.getString("AppName"));
				fioriMasterData.setPvBackendCombined(rs.getString("PVBackendCombined"));
				fioriMasterData.setSuccessorApp(rs.getString("successorApp"));
				fioriMasterData.setRelatedApp(rs.getString("relatedApp"));

				masterDataList.add(fioriMasterData);
			}

			logger.info("Fiori Master Sheet  Data selected SUCCESSFULLY");

		} finally {
			if (stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				conn.close();
			}

		}
		return masterDataList;

	}
	
	protected List<Map<String,String>> getFioriAppListLibraryMasterData(HttpSession session,String srcVersion) throws SQLException {
		
		
		List<Map<String,String>> fioriAppListResultMapList= new ArrayList<Map<String,String>>();
		Map<String,String> fioriAppListFioriIdResultMap= new HashMap<String,String>();
		Map<String,String> fioriAppListBusinessCatalogNameResultMap= new HashMap<String,String>();
		Map<String,String> fioriAppListComponentResultMap= new HashMap<String,String>();
		final String SELECT_SQL = "Select ACH,fioriId,TechnicalCatalogName,AdditionalIntents,BusinessCatalogName from fioriapplistresult_masterdata where ProductVersionNameBackend LIKE '%"+srcVersion+"%'";
		final String SELECT_SQL_ERP = "Select ACH,fioriId,TechnicalCatalogName,AdditionalIntents,BusinessCatalogName from fioriapplistresult_masterdata where ProductVersionNameBackend NOT LIKE '%S/4HANA%'";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);

			conn.setAutoCommit(false);

			if(srcVersion.equalsIgnoreCase("ERP"))
			{
				stmt = conn.prepareStatement(SELECT_SQL_ERP);
			}
			else
			{
				stmt = conn.prepareStatement(SELECT_SQL);
			}
			

			ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				String concatString = rs.getString("TechnicalCatalogName")+rs.getString("AdditionalIntents");
				String businessCatalogName=rs.getString("BusinessCatalogName");
				if(businessCatalogName!=null&&!businessCatalogName.isEmpty())
				{
					fioriAppListBusinessCatalogNameResultMap.put(businessCatalogName.toLowerCase(), "");
				}
				fioriAppListFioriIdResultMap.put(concatString.replace(" ", "").toLowerCase(), rs.getString("fioriId"));
				fioriAppListFioriIdResultMap.put(concatString.replace(" ", "").toLowerCase(), rs.getString("ACH"));
			}
			fioriAppListResultMapList.add(0, fioriAppListFioriIdResultMap);
			fioriAppListResultMapList.add(1, fioriAppListBusinessCatalogNameResultMap);
			fioriAppListResultMapList.add(2, fioriAppListComponentResultMap);
			
			logger.info("Fiori Master Sheet  Data selected SUCCESSFULLY");

		} finally {
			if (stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				conn.close();
			}

		}
		return fioriAppListResultMapList;

	}
	
	
	public static String customReportOutputFinalInsert(List<CustomReportOutput> customReportOutput,
			HttpSession session) throws SQLException {

		final String INSERT_SQL = "INSERT INTO Custom_Report_Output "
				+ "(Fiori_ID, Availability, REQUEST_ID, Version, Alternate_Name, PVBackendCombined, SuccessorApp, RelatedApp, App_Name, TechnicalCatalogId, Technicalcatalogtitle, SemanticObjectAction, LaunchpadApplicationType, LaunchpadApplicationName, StatusOfTheApplication, FlagForCustomApplication,Component) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);

			stmt = conn.prepareStatement(INSERT_SQL);
			int batch = 1;

			for (CustomReportOutput fiori : customReportOutput) {
				
				stmt.setString(1, fiori.getFioriId());
				stmt.setString(2, fiori.getAvailability());
				stmt.setLong(3, fiori.getRequestID());
				stmt.setString(4, fiori.getVersion());
				stmt.setString(5, fiori.getAltName());
				stmt.setString(6, fiori.getPvBackendCombined());
				stmt.setString(7, fiori.getSuccessorApp());
				stmt.setString(8, fiori.getRelatedApp());
				stmt.setString(9, fiori.getAppName());
				stmt.setString(10, fiori.getTechnicalCatalogId());
				stmt.setString(11, fiori.getTechnicalcatalogtitle());
				stmt.setString(12, fiori.getSemanticObjectAction());
				stmt.setString(13, fiori.getLaunchpadApplicationType());
				stmt.setString(14, fiori.getLaunchpadApplicationName());
				stmt.setString(15, fiori.getStatusOfTheApplication());
				stmt.setString(16, fiori.getFlagForCustomApplication());
				stmt.setString(16, fiori.getComponent());



				// Add statement to batch
				stmt.addBatch();
				counter++;
				// Execute batch of 10000 records
				if (counter % 10000 == 0) {
					counter = 0;
					stmt.executeBatch();
					conn.commit();
					logger.info("Batch " + (batch++) + " executed successfully");
				}
			}

			stmt.executeBatch();
			conn.commit();
			logger.info("Custom_Report_Output Data INSERTED SUCCESSFULLY");

		} finally {
			if (stmt != null) {
				stmt.close();
			}
			if (conn != null) {
				conn.close();
			}

		}

		return result;

	}

	

	public void updateAvailabilityAndVersion(Long requestId, HttpSession session, String targetVersion) {
		String updateSQL = "UPDATE Inventory_Std_Fiori_Intermediate isfi "
				+ "INNER JOIN "
				+ "Fiori_Rebuild_Master frms "
				+ "ON isfi.AppId = frms.App_Id "
				+ "SET Version = CASE "
					+ "WHEN isfi.Availability LIKE 'Not Available%'"
					+ "THEN "
						+ "CASE "
							+ "WHEN frms.Version_Check LIKE '%" + targetVersion + "%' "
							+ "THEN frms.List_Of_Similar_Applications "
							+ "ELSE  ''"
							+ "END "
					+ "ELSE Version "
					+ "END "
				+ ", "
				+ "Alternate_Name = CASE "
				    + "WHEN isfi.Availability LIKE 'Not Available%' " 
					+ "THEN " 
				    	+ "CASE " 
				    		+ "WHEN frms.Version_Check LIKE '%" + targetVersion + "%' " 
				    		+ "THEN frms.remarks " 
				    		+ "ELSE 'Functional inputs required to generate custom apps' " 
				    		+ "END "
				    + "ELSE Alternate_Name "
					+ "END";

		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {
			conn = DBConfig.getJDBCConnection(session);

			stmt = conn.prepareStatement(updateSQL);
			stmt.executeUpdate();
		} catch (SQLException e) {
			logger.error("updateAvailabilityAndVersion :: ", e);
		}
	}
	
	public void upadateProcessOnSucess(String environment) throws SQLException {
		logger.info("Inside upadateProcessOnSucess .....Start");
		try (Connection conn = DBConfigFiori.getJDBCConnection(environment);) {
			conn.setAutoCommit(false);
			try (PreparedStatement stmt = conn.prepareStatement(OdataFiori_Constants.Update_qry);) {
				stmt.setString(1, "AppLibraryResult_Fiori");
				stmt.setTimestamp(2, new Timestamp(System.currentTimeMillis()));
				stmt.executeUpdate();
				conn.commit();
			}
			logger.info("Query :: "+OdataFiori_Constants.Update_qry);
		}catch (Exception e) {
			logger.error("upadateProcessOnSucess :: ",e);
		}
		logger.info("Inside upadateProcessOnSucess .....End");
	}
	
	
}
