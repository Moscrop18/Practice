package com.act.fileprocesing.dao;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpSession;

import com.act.fiori.models.CustomReportOutput;
import com.act.fiori.models.OdataFioriApps;

public interface FioriProcessingNewDAO {

	public String processFioriApps(final long requestID, List<CustomReportOutput> customReportOutputList, String sourceVersion, String targetVersion,
			HttpSession session) throws Exception;
}
