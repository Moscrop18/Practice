/*MODIFIED 
 *FOR Enhancement 
 * 
 *CR-29.0:- Shown CDS View on basis of tables column value -5/08/17 -monika.mishra*/

package com.act.fileprocessing;

import java.sql.SQLException;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.act.client.dao.RequestInventoryDAO;
import com.act.fileprocesing.dao.ST03HanaDAOImpl;

public class AutomateHANA {
	private String rootFilePath = "";
	private ST03HanaDAOImpl st03Hanadao;
	private RequestInventoryDAO requestInventory;

	public void setSt03Hanadao(ST03HanaDAOImpl st03Hanadao) {
		this.st03Hanadao = st03Hanadao;
	}

	public void setRequestInventory(RequestInventoryDAO requestInventory) {
		this.requestInventory = requestInventory;
	}

	final Logger logger = LoggerFactory.getLogger(AutomateHANA.class);

	public String getRootFilePath() {
		return rootFilePath;
	}

	public void setRootFilePath(String rootFilePath) {
		this.rootFilePath = rootFilePath;
	}

	public AutomateHANA() {
	}

	public String getSystemStatus(long requestID) {
		return requestInventory.getRequestInventory(requestID).getRequestStatus();
	}

	public String getRfpStatus(long requestID) {
		return requestInventory.getRequestInventory(requestID).getRfpStatus();
	}

	public void clearUI5Tables(Long requestID) {
		st03Hanadao.deleteTables(requestID, "UI5InputExtract");
		st03Hanadao.deleteTables(requestID, "UI5FinalOutput");
		st03Hanadao.deleteTables(requestID, "UI5HighLevelReport");
		st03Hanadao.deleteREQUEST_IDTables(requestID, "UI5GraphCounts");
	}

	public void clearTestingScopeTables(Long requestID) {
		st03Hanadao.deleteFromRequestidTable(requestID, "ExtractedDatapojo");
		st03Hanadao.deleteFromTable(requestID, "TestingScope");
	}
	public void clearInventoryList(Long requestID) {
		st03Hanadao.deleteFromTable(requestID, "S4InventoryList");
	}
	public void clearAllTablesForUtility(Long requestID) {
		st03Hanadao.deleteFromTable(requestID, "InventoryList_Download");
		st03Hanadao.deleteTables(requestID, "ImpactedObjList_Download");
		st03Hanadao.deleteFromTable(requestID, "HanaProfile_Download");
		st03Hanadao.deleteFromTable(requestID, "S4HanaProfiler_Download");
		st03Hanadao.deleteTables(requestID, "AuctFinalOutput_Download");
		st03Hanadao.deleteTables(requestID, "OdataFinalOutput_Download");
		st03Hanadao.deleteFromTable(requestID, "S4OutputMgmt_Download");
		st03Hanadao.deleteFromTable(requestID, "S4AffectCustomField_Download");
		st03Hanadao.deleteFromTable(requestID, "S4ImpactedTables_Download");
		st03Hanadao.deleteFromTable(requestID, "S4ImpactedIDOC_Download");
		st03Hanadao.deleteFromTable(requestID, "S4ImpactedTransaction_Download");
		st03Hanadao.deleteFromTable(requestID, "S4ImpactedSearchHelp_Download");
		st03Hanadao.deleteFromTable(requestID, "S4AppendStructureAnalysis_Download");
		st03Hanadao.deleteFromTable(requestID, "S4CloneProg_Download");
		st03Hanadao.deleteFromTable(requestID, "S4DetailReportComplexity_Download");
		st03Hanadao.deleteFromTable(requestID, "S4DetailReportRemediation_Download");
		st03Hanadao.deleteFromTable(requestID, "S4Enhancement_Download");

		st03Hanadao.deleteREQUEST_IDTables(requestID, "ImpactedBackgroundCounts");
		st03Hanadao.deleteREQUEST_IDTables(requestID, "ImpactedBackgroundJob_Download");
		st03Hanadao.deleteFromSmodilogFunctionTable(requestID, "SmodilogFunction_Download");
		// Impacted Scripts
		// st03Hanadao.deleteREQUEST_IDTables(requestID,
		// "ImpactedScripts_Download");
	}

	// Impacted Scripts
	public void clearImpactedScriptsTable(long requestID) {
		st03Hanadao.deleteREQUEST_IDforScripts(requestID, "ImpactedScripts");
	}

	public void clearImpactedBackgroundJobTable(Long requestID) {

		st03Hanadao.deleteREQUEST_IDTables(requestID, "ImpactedBackgroundJob");
	}

	public void clearACNIPZERTable(Long requestID) {

		st03Hanadao.deleteFromTable(requestID, "ACNIPZVERComp");
	}

	public void clearAllTables(Long requestID) {
		st03Hanadao.deleteFromTable(requestID, "TestTab");
		st03Hanadao.deleteFromTable(requestID, "TestTab1");
		st03Hanadao.deleteFromTable(requestID, "HanaProfilerStepOutput");
		st03Hanadao.deleteFromTable(requestID, "HanaProfile");
		st03Hanadao.deleteFromTable(requestID, "ST03Tadir");
		st03Hanadao.deleteFromTable(requestID, "CDSView");
		st03Hanadao.deleteFromTable(requestID, "UsageAnalysis");
		st03Hanadao.deleteFromTable(requestID, "S4ImpactedObjectList");
		st03Hanadao.deleteFromTable(requestID, "S4InventoryList");
		st03Hanadao.deleteFromTable(requestID, "BWExtractor");
		st03Hanadao.deleteTables(requestID, "ImpactedObjectListIntermediate");
		st03Hanadao.deleteTables(requestID, "ImpactedObjList");
		st03Hanadao.deleteTables(requestID, "ImpactedCloneAnalysis");
		st03Hanadao.deleteTables(requestID, "AuctFinalOutput");
		st03Hanadao.deleteTables(requestID, "OdataFinalOutput");
		st03Hanadao.deleteFromTable(requestID, "S4ImpactedIDOC");
		st03Hanadao.deleteFromTable(requestID, "S4ImpactedTables");
		st03Hanadao.deleteFromTable(requestID, "S4ImpactedTransaction");
		st03Hanadao.deleteFromTable(requestID, "S4cvitr");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "InconsistentFUGR", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "S4_SID", "requestID");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "S4ImpactedCustomTables", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "BwCleanupUtil", "requestId");

		st03Hanadao.deleteFromTable(requestID, "S4CloneIntermediate");
		st03Hanadao.deleteFromTable(requestID, "S4ImpactedSearchHelp");
		st03Hanadao.deleteFromTable(requestID, "S4AppendStructureAnalysis");

		st03Hanadao.deleteFromTable(requestID, "S4CloneProg");

		st03Hanadao.deleteFromTable(requestID, "OperationDataS4");

		st03Hanadao.deleteFromTable(requestID, "S4Detection");
		st03Hanadao.deleteFromTable(requestID, "S4HanaProfiler");
		st03Hanadao.deleteFromTable(requestID, "S4UsageAnalysis");
		st03Hanadao.deleteFromTable(requestID, "S4DetailReportComplexity");
		st03Hanadao.deleteFromTable(requestID, "S4DetailReportRemediation");
		st03Hanadao.deleteFromTable(requestID, "S4AffectCustomField");
		st03Hanadao.deleteFromTable(requestID, "S4OutputMgmt");

		// DEF035
		st03Hanadao.deleteFromTable(requestID, "S4EnhancementIntermediate");
		st03Hanadao.deleteFromTable(requestID, "S4Enhancement");

		st03Hanadao.deleteREQUEST_IDTables(requestID, "ImpactedBackgroundJob");

		st03Hanadao.deleteFromSmodilogFunctionTable(requestID, "SmodilogFunction");

		// Impacted Scripts
		st03Hanadao.deleteREQUEST_IDTables(requestID, "ImpactedScripts");
		st03Hanadao.deleteREQUEST_IDTables(requestID, "ImpactedScripts_Intermediate");

		// Clearing OS Migration Table
		st03Hanadao.deleteFromTable(requestID, "OSMigrationFinal");
		st03Hanadao.deleteFromTable(requestID, "OSMigrationFinalLogicalCMD_Intermediate");
		st03Hanadao.deleteFromTable(requestID, "OSMigrationFinalFilepath_Intermediate");

		st03Hanadao.deleteFromTableWithReqIdName(requestID, "ImpactedVariant", "requestID");

		st03Hanadao.deleteFromTableWithReqIdName(requestID, "Unicode", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "Unicode_Intermediate", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "InactiveObjects", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "CvitCustomisingLogs", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "CvitErrorMessages", "requestId");
	}

	public void clearDownloadTable(Long requestID) {
		// clear download tables
		st03Hanadao.deleteFromTable(requestID, "InventoryList_Download");
		st03Hanadao.deleteFromTable(requestID, "BWExtractor_Download");
		st03Hanadao.deleteFromTable(requestID, "ABAPQueryInventoryDownload");
		st03Hanadao.deleteTables(requestID, "ImpactedObjList_Download");
		st03Hanadao.deleteFromTable(requestID, "HanaProfile_Download");
		st03Hanadao.deleteFromTable(requestID, "S4HanaProfiler_Download");
		st03Hanadao.deleteTables(requestID, "AuctFinalOutput_Download");
		st03Hanadao.deleteTables(requestID, "OdataFinalOutput_Download");
		st03Hanadao.deleteFromTable(requestID, "S4OutputMgmt_Download");
		st03Hanadao.deleteFromTable(requestID, "S4AffectCustomField_Download");
		st03Hanadao.deleteFromTable(requestID, "S4ImpactedTables_Download");
		st03Hanadao.deleteFromTable(requestID, "S4ImpactedIDOC_Download");
		st03Hanadao.deleteFromTable(requestID, "S4ImpactedTransaction_Download");
		st03Hanadao.deleteFromTable(requestID, "S4ImpactedSearchHelp_Download");
		st03Hanadao.deleteFromTable(requestID, "S4AppendStructureAnalysis_Download");
		st03Hanadao.deleteFromTable(requestID, "S4CloneProg_Download");
		st03Hanadao.deleteFromTable(requestID, "S4DetailReportComplexity_Download");
		st03Hanadao.deleteFromTable(requestID, "S4DetailReportRemediation_Download");
		st03Hanadao.deleteFromTable(requestID, "S4Enhancement_Download");
		st03Hanadao.deleteREQUEST_IDTables(requestID, "ImpactedBackgroundCounts");
		st03Hanadao.deleteREQUEST_IDTables(requestID, "ImpactedBackgroundJob_Download");
		st03Hanadao.deleteFromSmodilogFunctionTable(requestID, "SmodilogFunction_Download");
		st03Hanadao.deleteREQUEST_IDTables(requestID, "ImpactedScripts_Download");
		st03Hanadao.deleteFromTable(requestID, "OSMigrationFinal_Download");
		st03Hanadao.deleteFromTable(requestID, "OSMigrationFinalLogicalCMD_Download");
		st03Hanadao.deleteFromTable(requestID, "OSMigrationFinalFilepath_Download");
		st03Hanadao.deleteFromTable(requestID, "ImpactedCloneAnalysis_Download");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "InconsistentFUGR_Download", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "S4_SID_Download", "requestID");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "UnicodeOutput", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "ImpactedVariant_Download", "requestID");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "BwCleanupUtilDownload", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "S4ImpactedCustomTblDownload", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "BwStandardExtractDownload", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "InactiveObjectsDownload", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "DrillDown_Download", "requestID");
		st03Hanadao.deleteFromTable(requestID, "ObsoleteFmsDueToUpgrade");
	}

	// CVIT/CVITR - Clear Download Tables
	public void clearCVITDownloadTables(Long requestID) {
		st03Hanadao.deleteREQUEST_IDTables(requestID, "S4cvitr_Download");
		st03Hanadao.deleteFromCvitAssessmentTable(requestID, "S4CvitAssessment");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "CvitCustomisingLogsDownload", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "CvitErrorMessagesDownload", "requestId");
	}

	public void clearFioriTables(Long requestID) {
		st03Hanadao.deleteFromTable(requestID, "InventoryCustomFiori");
		st03Hanadao.deleteFromTable(requestID, "InventoryStandardFiori");
		st03Hanadao.deleteFromTable(requestID, "InventoryExtensionFiori");
		st03Hanadao.deleteFromTable(requestID, "StandardTcodesFiori");
		st03Hanadao.deleteFromTable(requestID, "PortableStandardAppsFiori");
		st03Hanadao.deleteFromTable(requestID, "InventoryStandardFioriIntermediate");
		st03Hanadao.deleteFromTable(requestID, "CustomReportOutput");
		st03Hanadao.deleteFromTable(requestID, "CustomReportOutput_download");
	}

	public void clearSIATables(Long requestID) {
		st03Hanadao.deleteFromTable(requestID, "SrcAgr1251");
		st03Hanadao.deleteFromTable(requestID, "SrcUsobtc");
		st03Hanadao.deleteFromTable(requestID, "SrcAgrUsers");
		st03Hanadao.deleteFromTable(requestID, "SaDistinctRolesintermediate");
		st03Hanadao.deleteFromTable(requestID, "SaTcdReportTrans");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "SaOldValuesIntermediate", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "SaOldObjectsIntermediate", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "SaNewValuesIntermediate", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "SaNewObjectsIntermediate", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "SaObjectReportTrans", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "SecurityAnalyserTCDReportDownload", "requestID");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "SaObjectReportDownload", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "SaFioriReportDownload", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "SaUserAndRoleAssignment", "requestId");
	}

	public void clearSIATCDReport(long requestId) {
		st03Hanadao.deleteFromTableWithReqIdName(requestId, "SecurityAnalyserTCDReportDownload", "requestID");
	}

	public void clearBwInputTables(Long requestID) {
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "Rsbkdtpstat", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "Rsbkdtp", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "Rsrrepdir", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "WebTemplate7", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "WebTemplate3", "requestID");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "Rstran", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "Rspcprocesslog", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "WorkbookIntermediate", "requestID");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "Rspcchain", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "Rsiccont", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "Rsbkrequest", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "RsantProcessr", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "RsbkdtpIntermidiate", "requestID");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "Rsrrworkbook", "requestID");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "RspchainIntermediate", "requestID");
	}

	public void clearBwTechInventoryTables(Long requestID) {
		st03Hanadao.deleteFromTable(requestID, "BwInventoryList");
		st03Hanadao.deleteFromTable(requestID, "BwInventoryDownload");
	}

	public void clearRequestMasterTable(Long requestID) {
		st03Hanadao.deleteFromTable(requestID, "ProcessedRequestDetail");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "ProcessedRequestMaster", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestID, "ProcessedRMCounts", "requestId");
	}

	public void clearIRPATScopeIntermediateTable(Long requestId, HttpSession session) {
		st03Hanadao.truncateTable("TestingScope_Intermediate", session);
		st03Hanadao.truncateTable("TScope_Intermediate", session);
		st03Hanadao.truncateTable("TScope_Final_Intermediate", session);
	}

	public void clearIRPATScopeDownloadTable(Long requestId) {
		st03Hanadao.deleteFromTableWithReqIdName(requestId, "TestingScopeDownload", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestId, "BusinessProcessDetail", "requestId");
	}

	public void clearIRPAReqMasterTables(Long requestId) {
		st03Hanadao.deleteFromTableWithReqIdName(requestId, "IRPATScopeRMScenarios", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestId, "IRPATScopeModuleReqMaster", "requestId");
		st03Hanadao.deleteFromTableWithReqIdName(requestId, "IRPATScopeRequestMaster", "requestId");
	}

	public void clearFioriRequestMasterTable(Long requestID) {
		// Deleting data from request Master if existing for that id
		st03Hanadao.deleteFromTable(requestID, "FioriRequestMaster");
	}

	public void dataTransferToDownlaodTables(String sql) {
		st03Hanadao.transferData(sql);
	}

	public long getCurrentExecutedRequestId() {
		return requestInventory.getCurrentExecution();
	}

	public void saveQueueData(Long requestID, String clientName, String clientEmail, final String toolName) {
		requestInventory.saveQueueExecution(requestID, clientName, clientEmail, toolName);
	}

	public void saveCurrentData(Long requestID, final String toolName) {
		requestInventory.saveCurrentExecution(requestID, toolName);
	}

	public void clearEstimatesTable(Long requestId) throws SQLException {
		st03Hanadao.deleteFromEstimatesTable(requestId, "ProcessedEstimates");
	}

	public void clearRomEstimatesTable(Long requestId) throws SQLException {
		st03Hanadao.deleteFromRomEstimatesTable(requestId, "TADIRInventory");
	}

	public void clearFioriTable(Long requestId) throws SQLException {
		st03Hanadao.deleteFromFioriTable(requestId, "FioriAppsOutput");
	}

	public void clearEXTTables(Long requestID) {
		st03Hanadao.deleteFromExtTable(requestID, "ExtensionOutput");
		st03Hanadao.deleteFromExtTable(requestID, "ExtensionScope");
		st03Hanadao.deleteFromTable(requestID, "ImpactedCloneAnalysis");
		st03Hanadao.deleteFromFioriTable(requestID, "FioriAppsOutput");
	}

	public void deleteFromSimplification(Long requestId) {
		st03Hanadao.deleteFromSimplification(requestId);
	}
}
