package com.act.fileprocessing.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Index;

@Entity
@Table(name="Usage_Analysis")
public class UsageAnalysis {
	
	private int id;
	
	@Column(name="REQUEST_ID")
	private Long requestID;
	
	@Column(name="TYPE")
	private String type;
	
	@Column(name="OBJECT_NAME")
	private String objName;
	
	@Index(name="OBJECT_NAME_TYPE")
	@Column(name="OBJECT_NAME_TYPE")
	private String objNameType;
	
	@Index(name="OBJECT_TYPE_NAME_READ_PROG")
	@Column(name="OBJECT_TYPE_NAME_READ_PROG")
	private String objTypeNameReadProg;
	
	public String getObjTypeNameReadProg() {
		return objTypeNameReadProg;
	}
	public void setObjTypeNameReadProg(String objTypeNameReadProg) {
		this.objTypeNameReadProg = objTypeNameReadProg;
	}
	private String usageCount;
	
	public String getUsageCount() {
		return usageCount;
	}
	public void setUsageCount(String usageCount) {
		this.usageCount = usageCount;
	}
	public String getObjNameType() {
		return objNameType;
	}
	public void setObjNameType(String objNameType) {
		this.objNameType = objNameType;
	}
	public Long getRequestID() {
		return requestID;
	}
	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getObjName() {
		return objName;
	}
	public void setObjName(String objName) {
		this.objName = objName;
	}
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID")
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
}
