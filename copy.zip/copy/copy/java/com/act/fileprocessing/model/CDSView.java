/*MODIFIED 
 *FOR Enhancement 
 * 
 *CR-29.0:- Shown CDS View on basis of tables column value -5/08/17 -monika.mishra*/



package com.act.fileprocessing.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity

@Table(name="CDS_View")


public class CDSView {
	@Id
	@GenericGenerator(name="kaugen" , strategy="increment")
	@GeneratedValue(generator="kaugen")
	@Column(name="ID",nullable = false)
	private int id;
	
	@Column(name="REQUEST_ID")
	private long requestID;
	
	@Column(name="VIEW")
	private String cdsView;
	
	@Column(name="Table_Name",length = 500)
	private String tableName;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public long getRequestID() {
		return requestID;
	}

	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}

	public String getCdsView() {
		return cdsView;
	}

	public void setCdsView(String cdsView) {
		this.cdsView = cdsView;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
}
