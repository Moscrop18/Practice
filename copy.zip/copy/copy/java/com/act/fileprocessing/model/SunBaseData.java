package com.act.fileprocessing.model;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.springframework.stereotype.Component;


@Entity
@Table(name="SUN_BASE_DATA")
public class SunBaseData    {

	private int id;
	private Long requestID;
	private String prog;
	
    private BigDecimal dialog;
    
	private String monthYear;
	
	

	@Id
	@GenericGenerator(name="gen" , strategy="increment")
	@GeneratedValue(generator="gen")
	@Column(name="ID")
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Column(name="REQUEST_ID")
	public Long getRequestID() {
		return requestID;
	}

	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}

	@Column(name="PROG")
	public String getProg() {
		return prog;
	}

	public void setProg(String prog) {
		this.prog = prog;
	}

	@Column(name="DIALOG")
	public BigDecimal getDialog() {
		return dialog;
	}

	public void setDialog(BigDecimal dialog) {
		this.dialog = dialog;
	}

	@Column(name="MONTH_YEAR")
	public String getMonthYear() {
		return monthYear;
	}

	public void setMonthYear(String monthYear) {
		this.monthYear = monthYear;
	}

	
	public SunBaseData()
	{
		
	}
	
	

}



