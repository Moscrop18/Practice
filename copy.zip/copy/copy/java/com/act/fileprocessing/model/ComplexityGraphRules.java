package com.act.fileprocessing.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="COMPLEXITY_GRAPH_RULES")
public class ComplexityGraphRules {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID")
	private Integer id;
	
	@Column(name="CATEGORY")
	private String category;
	
	@Column(name="LOW",columnDefinition = "LONGTEXT")
	private String low;
	
	@Column(name="MEDIUM",columnDefinition = "LONGTEXT")
	private String medium;
	
	@Column(name="HIGH",columnDefinition = "LONGTEXT")
	private String high;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getLow() {
		return low;
	}

	public void setLow(String low) {
		this.low = low;
	}

	public String getMedium() {
		return medium;
	}

	public void setMedium(String medium) {
		this.medium = medium;
	}

	public String getHigh() {
		return high;
	}

	public void setHigh(String high) {
		this.high = high;
	}

}
