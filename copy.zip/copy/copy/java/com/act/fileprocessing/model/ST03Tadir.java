package com.act.fileprocessing.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;


@Entity
@Table(name="ST03_TADIR")
public class ST03Tadir {

	private int id;
	private Long requestID;
	private String objectType;
	private String objectName;

	@Id
	@GenericGenerator(name="gen" , strategy="increment")
	@GeneratedValue(generator="gen")
	@Column(name="ID")
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	@Column(name="REQUEST_ID")
	public Long getRequestID() {
		return requestID;
	}
	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}

	@Column(name="OBJECT_TYPE")
	public String getObjectType() {
		return objectType;
	}
	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}


	@Column(name="OBJECT_NAME")
	public String getObjectName() {
		return objectName;
	}
	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}



}
