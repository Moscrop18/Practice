package com.act.fileprocessing.model;


public class ComplexityRules {

	private String object;
	
	private String category;
	
	private String complexity;
	
	private String fileExt;
	
	private String rfc;
	
	private String tabCust;
	
	private String tabSap;
	
	//sum of tab_sap, tab_cust
	private String sumOfTabs;
	
	//sum of upd_count, ins_count, del_count, bapi_cud
	private String sumOfCrud;
	
	private String drill;
	
	private String tabField;
	
	private String fmSap;
	
	private String fmCust;
	
	private String interfaceValue;
	
	private String entityCount;
	
	private String viewCust;
	
	private String moduleScreen;
	
	private String enhImpl;
	
	private String authObj;
	
	private String dbLinkCount;
	
	private String selCount;
	
	private String dynproUse;
	
	private String sumfmSel;
	
	private String sfileExt;
	
	private String srfc;
	
	private String stabCust;
	
	private String stabSap;
	
	//sum of tab_sap, tab_cust
	private String ssumOfTabs;
	
	//sum of upd_count, ins_count, del_count, bapi_cud
	private String ssumOfCrud;
	
	private String sdrill;
	
	private String stabField;
	
	private String sfmSap;
	
	private String sfmCust;
	
	private String sinterfaceValue;
	
	private String sentityCount;
	
	private String sviewCust;
	
	private String smoduleScreen;
	
	private String senhImpl;
	
	private String sauthObj;
	
	private String sdbLinkCount;
	
	private String sselCount;
	
	private String sdynproUse;
	
	private String ssumfmSel;

	public String getObject() {
		return object;
	}

	public void setObject(String object) {
		this.object = object;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getComplexity() {
		return complexity;
	}

	public void setComplexity(String complexity) {
		this.complexity = complexity;
	}

	public String getFileExt() {
		return fileExt;
	}

	public void setFileExt(String fileExt) {
		this.fileExt = fileExt;
	}
	
	public String getRfc() {
		return rfc;
	}

	public void setRfc(String rfc) {
		this.rfc = rfc;
	}

	public String getTabCust() {
		return tabCust;
	}

	public void setTabCust(String tabCust) {
		this.tabCust = tabCust;
	}

	public String getTabSap() {
		return tabSap;
	}

	public void setTabSap(String tabSap) {
		this.tabSap = tabSap;
	}

	public String getSumOfTabs() {
		return sumOfTabs;
	}

	public void setSumOfTabs(String sumOfTabs) {
		this.sumOfTabs = sumOfTabs;
	}

	public String getSumOfCrud() {
		return sumOfCrud;
	}

	public void setSumOfCrud(String sumOfCrud) {
		this.sumOfCrud = sumOfCrud;
	}

	public String getDrill() {
		return drill;
	}

	public void setDrill(String drill) {
		this.drill = drill;
	}

	public String getTabField() {
		return tabField;
	}

	public void setTabField(String tabField) {
		this.tabField = tabField;
	}

	public String getFmSap() {
		return fmSap;
	}

	public void setFmSap(String fmSap) {
		this.fmSap = fmSap;
	}

	public String getFmCust() {
		return fmCust;
	}

	public void setFmCust(String fmCust) {
		this.fmCust = fmCust;
	}

	public String getInterfaceValue() {
		return interfaceValue;
	}

	public void setInterfaceValue(String interfaceValue) {
		this.interfaceValue = interfaceValue;
	}

	public String getEntityCount() {
		return entityCount;
	}

	public void setEntityCount(String entityCount) {
		this.entityCount = entityCount;
	}

	public String getViewCust() {
		return viewCust;
	}

	public void setViewCust(String viewCust) {
		this.viewCust = viewCust;
	}

	public String getModuleScreen() {
		return moduleScreen;
	}

	public void setModuleScreen(String moduleScreen) {
		this.moduleScreen = moduleScreen;
	}

	public String getEnhImpl() {
		return enhImpl;
	}

	public void setEnhImpl(String enhImpl) {
		this.enhImpl = enhImpl;
	}

	public String getAuthObj() {
		return authObj;
	}

	public void setAuthObj(String authObj) {
		this.authObj = authObj;
	}

	public String getDbLinkCount() {
		return dbLinkCount;
	}

	public void setDbLinkCount(String dbLinkCount) {
		this.dbLinkCount = dbLinkCount;
	}

	public String getSelCount() {
		return selCount;
	}

	public void setSelCount(String selCount) {
		this.selCount = selCount;
	}

	public String getDynproUse() {
		return dynproUse;
	}

	public void setDynproUse(String dynproUse) {
		this.dynproUse = dynproUse;
	}

	public String getSfileExt() {
		return sfileExt;
	}

	public void setSfileExt(String sfileExt) {
		this.sfileExt = sfileExt;
	}

	public String getSrfc() {
		return srfc;
	}

	public void setSrfc(String srfc) {
		this.srfc = srfc;
	}

	public String getStabCust() {
		return stabCust;
	}

	public void setStabCust(String stabCust) {
		this.stabCust = stabCust;
	}

	public String getStabSap() {
		return stabSap;
	}

	public void setStabSap(String stabSap) {
		this.stabSap = stabSap;
	}

	public String getSsumOfTabs() {
		return ssumOfTabs;
	}

	public void setSsumOfTabs(String ssumOfTabs) {
		this.ssumOfTabs = ssumOfTabs;
	}

	public String getSsumOfCrud() {
		return ssumOfCrud;
	}

	public void setSsumOfCrud(String ssumOfCrud) {
		this.ssumOfCrud = ssumOfCrud;
	}

	public String getSdrill() {
		return sdrill;
	}

	public void setSdrill(String sdrill) {
		this.sdrill = sdrill;
	}

	public String getStabField() {
		return stabField;
	}

	public void setStabField(String stabField) {
		this.stabField = stabField;
	}

	public String getSfmSap() {
		return sfmSap;
	}

	public void setSfmSap(String sfmSap) {
		this.sfmSap = sfmSap;
	}

	public String getSfmCust() {
		return sfmCust;
	}

	public void setSfmCust(String sfmCust) {
		this.sfmCust = sfmCust;
	}

	public String getSinterfaceValue() {
		return sinterfaceValue;
	}

	public void setSinterfaceValue(String sinterfaceValue) {
		this.sinterfaceValue = sinterfaceValue;
	}

	public String getSentityCount() {
		return sentityCount;
	}

	public void setSentityCount(String sentityCount) {
		this.sentityCount = sentityCount;
	}

	public String getSviewCust() {
		return sviewCust;
	}

	public void setSviewCust(String sviewCust) {
		this.sviewCust = sviewCust;
	}

	public String getSmoduleScreen() {
		return smoduleScreen;
	}

	public void setSmoduleScreen(String smoduleScreen) {
		this.smoduleScreen = smoduleScreen;
	}

	public String getSenhImpl() {
		return senhImpl;
	}

	public void setSenhImpl(String senhImpl) {
		this.senhImpl = senhImpl;
	}

	public String getSauthObj() {
		return sauthObj;
	}

	public void setSauthObj(String sauthObj) {
		this.sauthObj = sauthObj;
	}

	public String getSdbLinkCount() {
		return sdbLinkCount;
	}

	public void setSdbLinkCount(String sdbLinkCount) {
		this.sdbLinkCount = sdbLinkCount;
	}

	public String getSselCount() {
		return sselCount;
	}

	public void setSselCount(String sselCount) {
		this.sselCount = sselCount;
	}

	public String getSdynproUse() {
		return sdynproUse;
	}

	public void setSdynproUse(String sdynproUse) {
		this.sdynproUse = sdynproUse;
	}

	public String getSumfmSel() {
		return sumfmSel;
	}

	public void setSumfmSel(String sumfmSel) {
		this.sumfmSel = sumfmSel;
	}

	public String getSsumfmSel() {
		return ssumfmSel;
	}

	public void setSsumfmSel(String ssumfmSel) {
		this.ssumfmSel = ssumfmSel;
	}
	
}
