package com.act.fileprocessing.model;


public class ExtensionRules {

	private String object;
	
	private String ricefCategory;
	
	private String extensibility;
	
	private Integer volume;
	
	private Integer frequency;
	
	private Integer fileExt;
	
	//sum of upd_count, ins_count, del_count, bapi_cud
	private Integer sumOfCrud;
	
	//sum of z_upd_count, z_ins_count, z_del_count
	private Integer sumOfZCRUD;
			
	private Integer drill;
	
	private Integer tabSap;
	
	private Integer tabCust;
	
	private Integer nativeIntf;
	
	private Integer dynproUse;
	
	private Integer ricefDepd;
	
	private String subcatDtl;
	
	private String subcatF;
	
	private String subcatI;
	
	private Integer viewCust;
	
	private Integer viewSap;
	
	private Integer fmSap;
	
	private Integer fmCust;
	
	private Integer bapiRead;
	
	private String  fileExtComments;
	
	private String  volumeComments;
	
	private String  frequencyComments;
	
	private String sumComments;
	
	private String ricefDepdComments;
	
	private String tabComments;
	
	private String nativeIntfComments;
	
	private String dynproUseComments;
	
	private String bapiReadComments;

	public String getObject() {
		return object;
	}

	public void setObject(String object) {
		this.object = object;
	}

	public String getRicefCategory() {
		return ricefCategory;
	}

	public void setRicefCategory(String ricefCategory) {
		this.ricefCategory = ricefCategory;
	}

	public String getExtensibility() {
		return extensibility;
	}

	public void setExtensibility(String extensibility) {
		this.extensibility = extensibility;
	}

	public Integer getVolume() {
		return volume;
	}

	public void setVolume(Integer volume) {
		this.volume = volume;
	}

	public Integer getFrequency() {
		return frequency;
	}

	public void setFrequency(Integer frequency) {
		this.frequency = frequency;
	}

	public Integer getFileExt() {
		return fileExt;
	}

	public void setFileExt(Integer fileExt) {
		this.fileExt = fileExt;
	}

	public Integer getSumOfZCRUD() {
		return sumOfZCRUD;
	}

	public void setSumOfZCRUD(Integer sumOfZCRUD) {
		this.sumOfZCRUD = sumOfZCRUD;
	}

	public Integer getSumOfCrud() {
		return sumOfCrud;
	}

	public void setSumOfCrud(Integer sumOfCrud) {
		this.sumOfCrud = sumOfCrud;
	}

	public Integer getDrill() {
		return drill;
	}

	public void setDrill(Integer drill) {
		this.drill = drill;
	}

	public Integer getTabSap() {
		return tabSap;
	}

	public void setTabSap(Integer tabSap) {
		this.tabSap = tabSap;
	}

	public Integer getTabCust() {
		return tabCust;
	}

	public void setTabCust(Integer tabCust) {
		this.tabCust = tabCust;
	}

	public Integer getNativeIntf() {
		return nativeIntf;
	}

	public void setNativeIntf(Integer nativeIntf) {
		this.nativeIntf = nativeIntf;
	}

	public Integer getDynproUse() {
		return dynproUse;
	}

	public void setDynproUse(Integer dynproUse) {
		this.dynproUse = dynproUse;
	}

	public Integer getRicefDepd() {
		return ricefDepd;
	}

	public void setRicefDepd(Integer ricefDepd) {
		this.ricefDepd = ricefDepd;
	}
	
	public String getSubcatDtl() {
		return subcatDtl;
	}

	public void setSubcatDtl(String subcatDtl) {
		this.subcatDtl = subcatDtl;
	}

	public String getSubcatF() {
		return subcatF;
	}

	public void setSubcatF(String subcatF) {
		this.subcatF = subcatF;
	}
	
	public String getSubcatI() {
		return subcatI;
	}

	public void setSubcatI(String subcatI) {
		this.subcatI = subcatI;
	}

	public Integer getViewCust() {
		return viewCust;
	}

	public void setViewCust(Integer viewCust) {
		this.viewCust = viewCust;
	}

	public Integer getViewSap() {
		return viewSap;
	}

	public void setViewSap(Integer viewSap) {
		this.viewSap = viewSap;
	}

	public String getFileExtComments() {
		return fileExtComments;
	}

	public void setFileExtComments(String fileExtComments) {
		this.fileExtComments = fileExtComments;
	}

	public String getVolumeComments() {
		return volumeComments;
	}

	public void setVolumeComments(String volumeComments) {
		this.volumeComments = volumeComments;
	}

	public String getSumComments() {
		return sumComments;
	}

	public void setSumComments(String sumComments) {
		this.sumComments = sumComments;
	}

	public String getRicefDepdComments() {
		return ricefDepdComments;
	}

	public void setRicefDepdComments(String ricefDepdComments) {
		this.ricefDepdComments = ricefDepdComments;
	}

	public String getTabComments() {
		return tabComments;
	}

	public void setTabComments(String tabComments) {
		this.tabComments = tabComments;
	}

	public String getFrequencyComments() {
		return frequencyComments;
	}

	public void setFrequencyComments(String frequencyComments) {
		this.frequencyComments = frequencyComments;
	}

	public String getNativeIntfComments() {
		return nativeIntfComments;
	}

	public void setNativeIntfComments(String nativeIntfComments) {
		this.nativeIntfComments = nativeIntfComments;
	}

	public String getDynproUseComments() {
		return dynproUseComments;
	}

	public void setDynproUseComments(String dynproUseComments) {
		this.dynproUseComments = dynproUseComments;
	}

	public Integer getFmSap() {
		return fmSap;
	}

	public void setFmSap(Integer fmSap) {
		this.fmSap = fmSap;
	}

	public Integer getFmCust() {
		return fmCust;
	}

	public void setFmCust(Integer fmCust) {
		this.fmCust = fmCust;
	}

	public Integer getBapiRead() {
		return bapiRead;
	}

	public void setBapiRead(Integer bapiRead) {
		this.bapiRead = bapiRead;
	}

	public String getBapiReadComments() {
		return bapiReadComments;
	}

	public void setBapiReadComments(String bapiReadComments) {
		this.bapiReadComments = bapiReadComments;
	}

}
