package com.act.fileprocessing.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="EXTENSIBILITY_GRAPH_RULES")
public class ExtensibilityGraphRules {
	
		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		@Column(name="ID")
		private Integer id;
		
		@Column(name="CATEGORY")
		private String category;
		
		@Column(name="SIDE_BY_SIDE",columnDefinition = "LONGTEXT")
		private String sideBySide;
		
		@Column(name="IN_APP",columnDefinition = "LONGTEXT")
		private String inApp;
		
		@Column(name="CLASSICAL",columnDefinition = "LONGTEXT")
		private String classical;

		public Integer getId() {
			return id;
		}

		public void setId(Integer id) {
			this.id = id;
		}

		public String getCategory() {
			return category;
		}

		public void setCategory(String category) {
			this.category = category;
		}

		public String getSideBySide() {
			return sideBySide;
		}

		public void setSideBySide(String sideBySide) {
			this.sideBySide = sideBySide;
		}

		public String getInApp() {
			return inApp;
		}

		public void setInApp(String inApp) {
			this.inApp = inApp;
		}

		public String getClassical() {
			return classical;
		}

		public void setClassical(String classical) {
			this.classical = classical;
		}

}
