/**
 * 
 */
package com.act.fileprocessing.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.GenericGenerator;


/**
 * @author abhishek.sahu
 *
 */

@Entity
@Table(name="Current_Execution")
public class CurrentExecution {

	private int id;
	private Long requestID;
    private String toolName;
	
	@Id
	@GenericGenerator(name="gen" , strategy="increment")
	@GeneratedValue(generator="gen")
	@Column(name="ID")
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	@Column(name="REQUEST_ID")
	public Long getRequestID() {
		return requestID;
	}
	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}
	
	@Column(name="TOOL_NAME")
	public String getToolName() {
		return toolName;
	}
	public void setToolName(String toolName) {
		this.toolName = toolName;
	}


}
