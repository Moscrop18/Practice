package com.act.fileprocessing.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "OS_MIGRATION_DATA")
public class OsMigrationMasterData {
	private int id;
	private String opcode;
	private String remediCat;
	private String issueCat;
	private String issueSubcat;
	private String operation;
	private String solution;
	private String impact;
	private String complexity;
	private String automationStatus;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID")
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Column(name = "Opcode")
	public String getOpcode() {
		return opcode;
	}

	public void setOpcode(String opcode) {
		this.opcode = opcode;
	}

	@Column(name = "Remediation_Category")
	public String getRemediCat() {
		return remediCat;
	}

	public void setRemediCat(String remediCat) {
		this.remediCat = remediCat;
	}

	@Column(name = "Issue_Category")
	public String getIssueCat() {
		return issueCat;
	}

	public void setIssueCat(String issueCat) {
		this.issueCat = issueCat;
	}

	@Column(name = "Issue_Sub_Category")
	public String getIssueSubcat() {
		return issueSubcat;
	}

	public void setIssueSubcat(String issueSubcat) {
		this.issueSubcat = issueSubcat;
	}

	@Column(name = "Operation")
	public String getOperation() {
		return operation;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}

	@Column(name = "Solution")
	public String getSolution() {
		return solution;
	}

	public void setSolution(String solution) {
		this.solution = solution;
	}

	@Column(name = "Impact")
	public String getImpact() {
		return impact;
	}

	public void setImpact(String impact) {
		this.impact = impact;
	}

	@Column(name = "Complexity")
	public String getComplexity() {
		return complexity;
	}

	public void setComplexity(String complexity) {
		this.complexity = complexity;
	}

	@Column(name = "Automation_Status")
	public String getAutomationStatus() {
		return automationStatus;
	}

	public void setAutomationStatus(String automationStatus) {
		this.automationStatus = automationStatus;
	}
}
