/*CREATED
 *FOR Enhancements
 * 
 *US-0: Enhancement Sheet -14/08/18 -himani.malhotra*/



package com.act.fileprocessing.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity

@Table(name="Impacted_Enhancements")


public class ImpactedEnhancements {
	@Id
	@GenericGenerator(name="kaugen" , strategy="increment")
	@GeneratedValue(generator="kaugen")
	@Column(name="ID",nullable = false)
	private int id;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Column(name="TCODE")
	private String tcode;
	
	@Column(name="Program_Name")
	private String progName;
	
	@Column(name="CLASS_NAME")
	private String clasName;
	
	@Column(name="Enhancement_Type")
	private String enhancementType;

	@Column(name="Enhancement_Name")
	private String enhancementName;

	@Column(name="OBJECT_TEXT")
	private String objText;
	
	@Column(name="IMPLEMENTATION_NAME")
	private String implName;
	
	@Column(name="PACKAGE")
	private String pckg;
	
	@Column(name="AREA")
	private String area;
	
	@Column(name="FILTER")
	private String filter;
	
	@Column(name="MULTIPLE_SINGLE_USE")
	private String multiSingleUse;

	public String getTcode() {
		return tcode;
	}

	public void setTcode(String tcode) {
		this.tcode = tcode;
	}

	public String getProgName() {
		return progName;
	}

	public void setProgName(String progName) {
		this.progName = progName;
	}

	public String getClasName() {
		return clasName;
	}

	public void setClasName(String clasName) {
		this.clasName = clasName;
	}

	public String getEnhancementType() {
		return enhancementType;
	}

	public void setEnhancementType(String enhancementType) {
		this.enhancementType = enhancementType;
	}

	public String getEnhancementName() {
		return enhancementName;
	}

	public void setEnhancementName(String enhancementName) {
		this.enhancementName = enhancementName;
	}

	public String getObjText() {
		return objText;
	}

	public void setObjText(String objText) {
		this.objText = objText;
	}

	public String getImplName() {
		return implName;
	}

	public void setImplName(String implName) {
		this.implName = implName;
	}

	public String getPckg() {
		return pckg;
	}

	public void setPckg(String pckg) {
		this.pckg = pckg;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getFilter() {
		return filter;
	}

	public void setFilter(String filter) {
		this.filter = filter;
	}

	public String getMultiSingleUse() {
		return multiSingleUse;
	}

	public void setMultiSingleUse(String multiSingleUse) {
		this.multiSingleUse = multiSingleUse;
	}

	
	
	
	
}
