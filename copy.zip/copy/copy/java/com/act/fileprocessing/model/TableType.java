/*CR-25.0- Few fields which will be moved to JAVA tool in HANA Profiler - 10/07/2017 - monika.mishra
 * 
 * */
package com.act.fileprocessing.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Table_Type")
public class TableType implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id	
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "ID")
	private Integer Id;
	@Column(name = "CLUSTER_TABLE")
	private String cluster;
	@Column(name = "POOL_TABLE")
	private String pool;
	
	public Integer getId() {
		return Id;
	}
	public void setId(Integer id) {
		Id = id;
	}
	public String getCluster() {
		return cluster;
	}
	public void setCluster(String cluster) {
		this.cluster = cluster;
	}
	public String getPool() {
		return pool;
	}
	public void setPool(String pool) {
		this.pool = pool;
	}
}
