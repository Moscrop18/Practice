package com.act.fileprocessing.model;



import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.springframework.stereotype.Component;


@Entity
@Table(name="TEST_TAB")
public class TestTab    {

	private int id;
	private Long requestID;
	private String tCode;
    private String dbPercent;
	private String changePercent;
	
	

	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	
	@Column(name="ID")
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Column(name="REQUEST_ID")
	public Long getRequestID() {
		return requestID;
	}

	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}

	@Column(name="TCODE")
	public String gettCode() {
		return tCode;
	}

	public void settCode(String tCode) {
		this.tCode = tCode;
	}

	@Column(name="DB_PER_CENT")
	public String getDbPercent() {
		return dbPercent;
	}

	public void setDbPercent(String dbPercent) {
		this.dbPercent = dbPercent;
	}

	@Column(name="CHANGE_PER_CENT")
	public String getChangePercent() {
		return changePercent;
	}

	public void setChangePercent(String changePercent) {
		this.changePercent = changePercent;
	}


	
	public TestTab()
	{
		
	}
	
	

}




