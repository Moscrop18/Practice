package com.act.fileprocessing.model;



import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.springframework.stereotype.Component;


@Entity
@Table(name="ST03_MONTH_DATA")
public class ST03MonthData  {

	private int id;
	private Long requestID;
	private String progName;
	private BigDecimal responseTime;
	private String dbTime;
	private String modificationTime;
	private String  dbPercent;
	private String   changePercent;


	@Id
	@GenericGenerator(name="gen" , strategy="increment")
	@GeneratedValue(generator="gen")
	@Column(name="ID")
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Column(name="REQUEST_ID")
	public Long getRequestID() {
		return requestID;
	}

	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}

	@Column(name="PROG_NAME")
	public String getProgName() {
		return progName;
	}

	public void setProgName(String progName) {
		this.progName = progName;
	}

	@Column(name="RESPONSE_TIME")
	public BigDecimal getResponseTime() {
		return responseTime;
	}

	public void setResponseTime(BigDecimal responseTime) {
		this.responseTime = responseTime;
	}

	@Column(name="DB_TIME")
	public String getDbTime() {
		return dbTime;
	}

	public void setDbTime(String dbTime) {
		this.dbTime = dbTime;
	}

	@Column(name="MODIFCATION_TIME")
	public String getModificationTime() {
		return modificationTime;
	}

	public void setModificationTime(String modificationTime) {
		this.modificationTime = modificationTime;
	}

	@Column(name="DB_PERCENT")
	public String   getDbPercent() {
		return dbPercent;
	}

	public void setDbPercent(String   dbPercent) {
		this.dbPercent = dbPercent;
	}

	@Column(name="CHANGE_PERCENT")
	public String   getChangePercent() {
		return changePercent;
	}

	public void setChangePercent(String   changePercent) {
		this.changePercent = changePercent;
	}

	
	public ST03MonthData()
	{
		
	}
	
	

}


