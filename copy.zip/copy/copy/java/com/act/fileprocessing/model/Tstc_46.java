package com.act.fileprocessing.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.springframework.stereotype.Component;


@Entity
@Table(name="TSTC_46")
public class Tstc_46  {

			
	private int id;
	
	private String tCode;
	private String pgmna;
	private String description;

	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID")
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	
	@Column(name="TCODE")
	public String gettCode() {
		return tCode;
	}

	public void settCode(String tCode) {
		this.tCode = tCode;
	}

	
	@Column(name="PGMNA")
	public String getPgmna() {
		return pgmna;
	}

	public void setPgmna(String pgmna) {
		this.pgmna = pgmna;
	}

	@Column(name="DESCRIPTION")
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Tstc_46()
	{
		
	}
	
	

}



