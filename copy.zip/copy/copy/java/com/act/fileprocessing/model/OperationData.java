/*MODIFIED 
 *
 *CR-13.0- New Output Sheet implementation - 03/03/2017 - monika.mishra
 *
 *CR-25.0- Few fields which will be moved to JAVA tool in HANA Profiler - 10/07/2017 - monika.mishra
 **/


package com.act.fileprocessing.model;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.springframework.stereotype.Component;


@Entity
@Table(name="OPERATION_DATA")
public class OperationData  {

	private int id;
	//private Long requestID;
	private String operationCode;
	private String operation;
	private String actStatus;
	private String subCategory;
	private String critical;
	private String secondSubCategory;
	
	@Column(name = "ISSUE_SUB_CATEGORY")
	public String getSecondSubCategory() {
		return secondSubCategory;
	}

	public void setSecondSubCategory(String secondSubCategory) {
		this.secondSubCategory = secondSubCategory;
	}

	//CR-13.0
	@Column(name = "high_lvl_desc")
	private String high_lvl_desc;

		
	private String automationStatus;
	
	@Column(name = "Automation_Status")
	public String getAutomationStatus() {
		return automationStatus;
	}

	public void setAutomationStatus(String automationStatus) {
		this.automationStatus = automationStatus;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID")
	public int getId() {
		return id;
	}

	
	
	
	public void setId(int id) {
		this.id = id;
	}

	/*@Column(name="REQUEST_ID")
	public Long getRequestID() {
		return requestID;
	}

	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}*/

	@Column(name="OPERAION_CODE")
	public String getOperationCode() {
		return operationCode;
	}

	public void setOperationCode(String operationCode) {
		this.operationCode = operationCode;
	}

	@Column(name="ACT_STATUS")
	public String getActStatus() {
		return actStatus;
	}

	public void setActStatus(String actStatus) {
		this.actStatus = actStatus;
	}

	@Column(name="SUB_CATEGORY")
	public String getSubCategory() {
		return subCategory;
	}

	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}

	@Column(name="OPERAION")
	public String getOperation() {
		return operation;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}
	
	@Column(name="CRTICAL")
	public String getCritical() {
		return critical;
	}

	public void setCritical(String critical) {
		this.critical = critical;
	}
	
	
	public OperationData()
	{
		
	}




	public String getHigh_lvl_desc() {
		return high_lvl_desc;
	}




	public void setHigh_lvl_desc(String high_lvl_desc) {
		this.high_lvl_desc = high_lvl_desc;
	}



	
	//AADT code
	
	@Column(name = "COMPLEXITY")
	private String COMPLEXITY;

	public String getCOMPLEXITY() {
		return COMPLEXITY;
	}

	public void setCOMPLEXITY(String cOMPLEXITY) {
		COMPLEXITY = cOMPLEXITY;
	}
	
	
	

}


