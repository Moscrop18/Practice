/*MODIFIED 
 *
 *CR-13.0- New Output Sheet implementation - 03/03/2017 - monika.mishra
 *
 *CR-25.0- Few fields which will be moved to JAVA tool in HANA Profiler - 10/07/2017 - monika.mishra
 *
 *CR-28.0:- Add col Total Line Scanned -24/07/17 -monika.mishra
 **/


package com.act.fileprocessing.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.*;
import org.hibernate.annotations.*;
import org.hibernate.annotations.Parameter;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;




@Entity

@Table(name="HANA_PROFILER_STEP_OUTPUT")


public class HanaProfilerStepOutput  {

	
	private int id;
	private long requestID;
	private String objectType;
	private String objName;
	private String usedUnused;
	
	private String  dialogSteps;
	
	private String operation;
	private String actST;
	private String subCategory;
	private String impact;
	
	private String dbPercent;
	private String changePercent;
	
	private String operationCode;
	private int joinID;
	
	//CR-13.0 add col high_lvl_desc
	private String high_lvl_desc; 
	
	//CR-25.0 add col active Status
	private String activeStatus;

	//CR-28.0 add col Total no.of line scanned
	private String totalLineScanned;
	

	//CR-34.0 add col line no
		private Integer lineNo;
		
		//CR-52.0
		private String objNameType;
		
		@Column(name="OBJ_NAME_TYPE")
		public String getObjNameType() {
			return objNameType;
		}


		public void setObjNameType(String objNameType) {
			this.objNameType = objNameType;
		}


		@Column(name="Line_No")
	public Integer getLineNo() {
			return lineNo;
		}


		public void setLineNo(Integer lineNo) {
			this.lineNo = lineNo;
		}


	public HanaProfilerStepOutput() {
	}
   
	
	@Id
	@GenericGenerator(name="kaugen" , strategy="increment")
	@GeneratedValue(generator="kaugen")
	@Column(name="ID",nullable = false)
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}

	@Column(name="REQUEST_ID")
	public long getRequestID() {
		return requestID;
	}

	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}
	
	@Column(name="OBJECT_TYPE")
	public String getObjectType() {
		return objectType;
	}

	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}

	
	@Column(name="OBJ_NAME")
	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}

	@Column(name="USED_UNUSED")
	public String getUsedUnused() {
		return usedUnused;
	}

	public void setUsedUnused(String usedUnused) {
		this.usedUnused = usedUnused;
	}

	@Column(name="DIALOGSTEPS")
	public String getDialogSteps() {
		return dialogSteps;
	}

	public void setDialogSteps(String dialogSteps) {
		this.dialogSteps = dialogSteps;
	}

	@Column(name="OPERATION")
	public String getOperation() {
		return operation;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}

	@Column(name="ACTST")
	public String getActST() {
		return actST;
	}

	public void setActST(String actST) {
		this.actST = actST;
	}

	@Column(name="SUB_CATEGORY")
	public String getSubCategory() {
		return subCategory;
	}

	public void setSubCategory(String subCategory) {
		this.subCategory = subCategory;
	}

	@Column(name="IMPACT")
	public String getImpact() {
		return impact;
	}

	public void setImpact(String impact) {
		this.impact = impact;
	}

	@Column(name="DB_PERCENT")
	public String getDbPercent() {
		return dbPercent;
	}

	public void setDbPercent(String dbPercent) {
		this.dbPercent = dbPercent;
	}

	@Column(name="CHANGE_PERCENT")
	public String getChangePercent() {
		return changePercent;
	}

	public void setChangePercent(String changePercent) {
		this.changePercent = changePercent;
	}

	@Column(name="OPERATION_CODE")
	public String getOperationCode() {
		return operationCode;
	}

	public void setOperationCode(String operationCode) {
		this.operationCode = operationCode;
	}
	
	@Column(name="JOIN_ID")
	public int getJoinID() {
		return joinID;
	}


	public void setJoinID(int joinID) {
		this.joinID = joinID;
	}

	@Column(name = "high_lvl_desc")
	public String getHigh_lvl_desc() {
		return high_lvl_desc;
	}


	public void setHigh_lvl_desc(String high_lvl_desc) {
		this.high_lvl_desc = high_lvl_desc;
	}

	@Column(name = "active_Status")
	public String getActiveStatus() {
		return activeStatus;
	}


	public void setActiveStatus(String activeStatus) {
		this.activeStatus = activeStatus;
	}

	@Column(name = "total_line_scanned")
	public String getTotalLineScanned() {
		return totalLineScanned;
	}


	public void setTotalLineScanned(String totalLineScanned) {
		this.totalLineScanned = totalLineScanned;
	}

	

	
}


