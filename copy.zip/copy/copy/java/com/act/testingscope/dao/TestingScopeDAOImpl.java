package com.act.testingscope.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.hibernate.type.LongType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.act.client.model.RequestStatusMaster;
import com.act.constant.Hana_Profiler_Constant;
import com.act.displaygrid.model.DBConfig;
import com.act.master.IRPATScopeEstimates;
import com.act.master.IRPATScopeRequestMaster;
import com.act.testingscope.model.BusinessProcessDetail;
import com.act.testingscope.model.TScopeFinalIntermediate;
import com.act.testingscope.model.TestingScopeDownload;
import com.act.testingscope.model.TestingScopeIntermediate;

@Repository
public class TestingScopeDAOImpl implements TestingScopeDAO {
	@Autowired
	private SessionFactory sessionFactory;

	private final Logger logger = LoggerFactory.getLogger(TestingScopeDAOImpl.class);

	@Override
	public void testingScopeIntermediateInsert(HttpSession session,
			List<TestingScopeIntermediate> finalTestingScopeReportList) throws Exception {
		StringBuilder insertSQL = new StringBuilder("INSERT INTO TestingScope_Intermediate "
				+ "(requestid, objecttype, objectname, process, objectTypeObjectName, applicationComponent, opercd, "
				+ "appCompDesc, transactions) " 
				+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");

		try (Connection conn = DBConfig.getJDBCConnection(session)) {
			int counter = 1;
			conn.setAutoCommit(false);
			try (PreparedStatement stmt = conn.prepareStatement(insertSQL.toString())) {
				int batch = 1;
				for (TestingScopeIntermediate testingscope : finalTestingScopeReportList) {
					stmt.setLong(1, testingscope.getRequestid());
					stmt.setString(2, testingscope.getObjecttype());
					stmt.setString(3, testingscope.getObjectname());
					stmt.setString(4, testingscope.getProcess());
					stmt.setString(5, testingscope.getObjectTypeObjectName());
					stmt.setString(6, testingscope.getApplicationComponent());
					stmt.setString(7, testingscope.getOpercd());
					stmt.setString(8, testingscope.getAppCompDesc());
					stmt.setString(9, testingscope.getTransactions());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 1000 records
					if (counter % 1000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();

				logger.info("Testing Scope Data INSERTED SUCCESSFULLY into TestingScope_Intermediate DB.");
			} catch (Exception e) {
				logger.error("FAILURE in inserting data into TestingScope_Intermediate DB --- ", e);
				throw new Exception();
			}
		} catch (Exception e) {
			logger.error(
					"FAILURE in Getting Connection while inserting data into " + "TestingScope_Intermediate DB --- ",
					e);
			throw new Exception();
		}
	}

	@Override
	public void tscopeAppnComponenetProcessing(HttpSession session, long requestId, String customerNamespaces)
			throws SQLException, Exception {
		logger.info("Testing Scope -- Application Compnent Mapping Insertion Starts ...");

		String sql = "{CALL irpa_tscope_appcomp_process (?, ?)}";

		try (Connection conn = DBConfig.getJDBCConnection(session)) {
			try (CallableStatement stmt = conn.prepareCall(sql.toString())) {
				stmt.setLong(1, requestId);
				stmt.setString(2, customerNamespaces);
				stmt.execute();
				logger.info("Testing Scope --- Application Component Mapping Data INSERTED SUCCESSFULLY");
			} catch (Exception e) {
				logger.error("FAILURE in inserting Application Component data into TestingScope DB --- ", e);
				throw new Exception();
			}
		} catch (Exception e) {
			logger.error("FAILURE in Getting Connection while inserting Application Component data into TestingScope DB --- ", e);
			throw new Exception();
		}
	}

	public int rowCount(long requestId) {
		Session session = null;
		Query query = null;
		int count = 0;
		String sql = "";

		try {
			sql = "SELECT COUNT(*) from TestingScopeDownload WHERE requestId = :requestId";
			session = sessionFactory.openSession();
			query = session.createQuery(sql);
			query.setParameter("requestId", requestId);
			if (query.uniqueResult() != null)
				count = ((Long) query.uniqueResult()).intValue();
		} catch (Exception e) {
			logger.error("Error while getting IRPA TScope row count ", e);
		} finally {
			if (session != null)
				session.close();
		}

		return count;
	}

	@Override
	public void tscopeTCodeProcessing(HttpSession session, long requestId, String srcColName, String tarColName,
			String customerNamespaces) throws Exception {
		logger.info("Testing Scope -- TCode Mapping Insertion Starts ...");

		String sql = "{CALL irpa_tscope_tcode_process (?, ?, ?, ?)}";

		try (Connection conn = DBConfig.getJDBCConnection(session)) {
			try (CallableStatement stmt = conn.prepareCall(sql.toString())) {
				stmt.setLong(1, requestId);
				stmt.setString(2, srcColName);
				stmt.setString(3, tarColName);
				stmt.setString(4, customerNamespaces);
				stmt.execute();
				logger.info("Testing Scope --- TCode Mapping Data INSERTED SUCCESSFULLY");
			} catch (Exception e) {
				logger.error("FAILURE in inserting TCode data into TestingScope DB --- ", e);
				throw new Exception();
			}
		} catch (Exception e) {
			logger.error("FAILURE in Getting Connection while inserting TCode data into TestingScope DB --- ", e);
			throw new Exception();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TestingScopeDownload> getIRPATScope(long requestId) throws Exception {
		logger.info("Fetching IRPA TScope Data ...");

		Session session = null;
		List<TestingScopeDownload> testingScopeList = null;

		try {
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(TestingScopeDownload.class);

			ProjectionList projectionList = Projections.projectionList();
			projectionList.add(Projections.property("objectType"), "objectType");
			projectionList.add(Projections.property("objectName"), "objectName");
			projectionList.add(Projections.property("module"), "module");
			projectionList.add(Projections.property("process"), "process");
			projectionList.add(Projections.property("appComponent"), "appComponent");
			projectionList.add(Projections.property("operCd"), "operCd");
			projectionList.add(Projections.property("appCompDesc"), "appCompDesc");
			projectionList.add(Projections.property("transactions"), "transactions");
			projectionList.add(Projections.property("comments"), "comments");
			projectionList.add(Projections.property("targetTransactions"), "targetTransactions");
			projectionList.add(Projections.property("needsToBeUpdated"), "needsToBeUpdated");
			projectionList.add(Projections.property("businessScenarioLevel1"), "businessScenarioLevel1");
			projectionList.add(Projections.property("businessScenarioLevel2"), "businessScenarioLevel2");
			projectionList.add(Projections.property("businessScenarioLevel3"), "businessScenarioLevel3");
			projectionList.add(Projections.property("isBusinessScenarioRelevant"), "isBusinessScenarioRelevant");
			projectionList.add(Projections.property("testScriptAvailable"), "testScriptAvailable");

			criteria.add(Restrictions.eq("requestId", requestId));
			criteria.setProjection(Projections.distinct(projectionList));
			criteria.setResultTransformer(Transformers.aliasToBean(TestingScopeDownload.class));
			testingScopeList = criteria.list();
		} catch (Exception e) {
			logger.error("Error while retrieving Testing Scope List : ", e);
			throw new Exception();
		} finally {
			if (null != session) {
				session.close();
			}
		}

		return testingScopeList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TestingScopeDownload> getDistinctBusinessScenarios(long requestId) throws Exception {
		logger.info("Fetching IRPA - Distinct Business Scenarios ...");

		Session session = null;
		List<TestingScopeDownload> businessScenariosList = null;

		try {
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(TestingScopeDownload.class);

			ProjectionList projectionList = Projections.projectionList();
			projectionList.add(Projections.property("businessScenarioLevel3"), "businessScenarioLevel3");
			projectionList.add(Projections.property("countOfTestScriptsPerScenario"), "countOfTestScriptsPerScenario");

			criteria.add(Restrictions.eq("requestId", requestId));
			criteria.setProjection(Projections.distinct(projectionList));
			criteria.setResultTransformer(Transformers.aliasToBean(TestingScopeDownload.class));

			businessScenariosList = criteria.list();
		} catch (Exception e) {
			logger.error("Error while retrieving IRPA - Distinct Business Scenarios List : ", e);
			throw new Exception();
		} finally {
			if (null != session) {
				session.close();
			}
		}

		return businessScenariosList;
	}

	@Override
	public IRPATScopeRequestMaster getIRPATScopeRM(long requestId) throws Exception {
		Session session = null;
		IRPATScopeRequestMaster irpaTScopeRMObj = null;
		try {
			session = sessionFactory.openSession();

			irpaTScopeRMObj = (IRPATScopeRequestMaster) session.get(IRPATScopeRequestMaster.class, requestId);

			return irpaTScopeRMObj;
		} catch (Exception e) {
			logger.error("Error while retrieving IRPA TScope Request Master Data : ", e);
			throw new Exception();
		} finally {
			if (null != session) {
				session.close();
			}
		}
	}

	@Override
	public void businessPrcessDetInsert(HttpSession session, List<BusinessProcessDetail> businessProcessDetList)
			throws Exception {
		StringBuilder insertSQL = new StringBuilder(
				"INSERT INTO Business_Process_Detail " + "(Request_ID, Object_Type, Object_Name, Object_Name_Type, "
						+ "Final_Business_Process_Category, RTR, OTC, S2D, HTR, PTP, Others) "
						+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {
			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(insertSQL.toString());
				int batch = 1;
				for (BusinessProcessDetail businessProcessDetail : businessProcessDetList) {
					stmt.setLong(1, businessProcessDetail.getRequestId());
					stmt.setString(2, businessProcessDetail.getObjectType().trim());
					stmt.setString(3, businessProcessDetail.getObjectName().trim());
					stmt.setString(4, businessProcessDetail.getObjNameType());
					stmt.setString(5, businessProcessDetail.getFinalBusinessProcessCat());
					stmt.setString(6, businessProcessDetail.getRtr());
					stmt.setString(7, businessProcessDetail.getOtc());
					stmt.setString(8, businessProcessDetail.getS2d());
					stmt.setString(9, businessProcessDetail.getHtr());
					stmt.setString(10, businessProcessDetail.getPtp());
					stmt.setString(11, businessProcessDetail.getOthers());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 1000 records
					if (counter % 1000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();

				logger.info("Business Process Detail Data INSERTED SUCCESSFULLY");
			} catch (Exception e) {
				logger.error("FAILURE in inserting data into Business Process Detail DB --- ", e);
				throw new Exception("FAILURE in inserting data into Business Process Detail DB");
			}
		} catch (Exception e) {
			logger.error("FAILURE in Getting Connection while inserting data into Testing Scope DB --- ", e);
			throw new Exception("FAILURE in Getting Connection while inserting data into Testing Scope DB");
		} finally {
			stmt.close();
			conn.close();
		}
	}

	@Override
	public void tscopeIntermediateInsert(HttpSession session, List<TScopeFinalIntermediate> tscopeList) throws Exception {
		StringBuilder insertSQL = new StringBuilder("INSERT INTO TScope_Final_Intermediate "
				+ "(Request_Id, Object_Type, Object_Name, Process, ObjectType_ObjectName, Application_Component, OperCode, "
				+ "Application_Component_Description, Transactions, BusinessScenario_Level1, BusinessScenario_Level2, BusinessScenario_Level3, "
				+ "Comments, Target_Transactions, Needs_To_Be_Updated, Is_Business_Scenario_Relevant, Test_Script_Available, Module, Count_TestScripts_PerScenario) "
				+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

		try (Connection conn = DBConfig.getJDBCConnection(session);) {
			int counter = 1;
			conn.setAutoCommit(false);

			try (PreparedStatement stmt = conn.prepareStatement(insertSQL.toString())) {
				int batch = 1;
				for (TScopeFinalIntermediate testingscope : tscopeList) {
					stmt.setLong(1, testingscope.getRequestId());
					stmt.setString(2, testingscope.getObjectType());
					stmt.setString(3, testingscope.getObjectName());
					stmt.setString(4, testingscope.getProcess());
					stmt.setString(5, testingscope.getObjTypeObjName());
					stmt.setString(6, testingscope.getAppComponent());
					stmt.setString(7, testingscope.getOperCd());
					stmt.setString(8, testingscope.getAppCompDesc());
					stmt.setString(9, testingscope.getTransactions());
					stmt.setString(10, testingscope.getBusinessScenarioLevel1());
					stmt.setString(11, testingscope.getBusinessScenarioLevel2());
					stmt.setString(12, testingscope.getBusinessScenarioLevel3());
					stmt.setString(13, testingscope.getComments());
					stmt.setString(14, testingscope.getTargetTransactions());
					stmt.setString(15, testingscope.getNeedsToBeUpdated());
					stmt.setString(16, testingscope.getIsBusinessScenarioRelevant());
					stmt.setString(17, testingscope.getTestScriptAvailable());
					stmt.setString(18, testingscope.getModule());
					stmt.setInt(19, testingscope.getCountOfTestScriptsPerScenario());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 1000 records
					if (counter % 1000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();

				logger.info("Testing Scope Data inserted successfully(After Uploading Final Report).");
			} catch (Exception e) {
				logger.error("Failure in inserting data into Testing Scope DB(After Uploading Final Report) --- ", e);
				throw new Exception();
			}
		} catch (Exception e) {
			logger.error(
					"FAILURE in Getting Connection while inserting data into Testing Scope DB(After Uploading Final Report) --- ",
					e);
			throw new Exception();
		}
	}

	@Override
	public void insertIRPATScopeReqMasterScenarios(HttpSession session, long requestId) throws Exception {
		logger.info("Inserting and calculating 'IRPA TScope Scenarios' request master counts -- Start");

		StringBuilder insertSQL = new StringBuilder("INSERT INTO IRPATScope_RM_Scenarios "
				+ "(Request_Id, Module, Process, Scenario_Count, ToBeUpdated_Yes_Count, "
				+ "ToBeUpdated_No_Count, TestScriptAvail_Yes_Count, TestScriptAvail_No_Count) " 
				+ "SELECT "
				+ "Request_Id, Module, Process, COUNT(scenario), "
				+ "COUNT(CASE WHEN toBeUpdate LIKE '%YES%' THEN 1 END), "
				+ "COUNT(CASE WHEN toBeUpdate NOT LIKE '%YES%' THEN 1 END), "
				+ "COUNT(CASE WHEN testScriptAvail LIKE '%YES%' THEN 1 END), "
				+ "COUNT(CASE WHEN testScriptAvail LIKE '%NO%' THEN 1 END) " 
				+ "FROM " 
				+ "(SELECT "
				+ "Request_Id, Module, Process, BusinessScenario_Level3 AS scenario, "
				+ "Test_Script_Available AS testScriptAvail, GROUP_CONCAT(DISTINCT Needs_To_Be_Updated) AS toBeUpdate "
				+ "FROM TScope_Final_Intermediate WHERE Request_Id = ? AND " 
				+ "Is_Business_Scenario_Relevant = 'YES' AND "
				+ "Module IS NOT NULL AND Module <> '' AND Process IS NOT NULL AND Process <> '' "
				+ "AND BusinessScenario_Level3 IS NOT NULL AND BusinessScenario_Level3 <> '' "
				+ "AND BusinessScenario_Level3 <> 'Others' "
				+ "GROUP BY Module, Process, BusinessScenario_Level3) AS a GROUP BY Module, Process");

		try (Connection conn = DBConfig.getJDBCConnection(session)) {
			try (PreparedStatement stmt = conn.prepareStatement(insertSQL.toString())) {
				stmt.setLong(1, requestId);
				stmt.execute();

				logger.info("Inserting and calculating 'IRPA TScope Scenarios' request master counts -- End");
			} catch (Exception e) {
				logger.error("Failure while calculating 'IRPA TScope Scenarios' request master counts ...", e);
				throw new Exception();
			}
		} catch (Exception e) {
			logger.error(
					"Failure in getting connection while calculating 'IRPA TScope Scenarios' request master counts ...",
					e);
			throw new Exception();
		}
	}

	@Override
	public void insertIRPATScopeReqMaster(long requestId, IRPATScopeRequestMaster irpaTScopeRMObj) throws Exception {
		logger.info("Inserting and calculating 'IRPA TScope' request master counts -- Start");

		Session session = null;
		Transaction tx = null;

		try {
			session = sessionFactory.openSession();
			tx = session.beginTransaction();

			session.merge("IRPATScopeRequestMaster", irpaTScopeRMObj);

			tx.commit();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();

			logger.error("Error while inserting and calculating 'IRPA TScope' request master counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}
	}

	public void insertIRPATScopeModuleReqMaster(HttpSession session, long requestId) throws Exception {
		logger.info("Inserting and calculating 'IRPA TScope Module' request master counts -- Start");

		StringBuilder insertSQL = new StringBuilder("INSERT INTO IRPATScope_Module_ReqMaster "
				+ "(Request_Id, Module, Scenario_Count) " 
				+ "SELECT "
				+ "Request_Id, Module, COUNT(DISTINCT (CASE WHEN BusinessScenario_Level3 IS NOT NULL AND "
				+ "BusinessScenario_Level3 <> '' AND BusinessScenario_Level3 <> 'Others' "
				+ "THEN BusinessScenario_Level3 END)) " 
				+ "FROM TScope_Final_Intermediate WHERE Request_Id = ? AND "
				+ "Is_Business_Scenario_Relevant = 'YES' AND " 
				+ "Module IS NOT NULL AND Module <> '' GROUP BY Module");

		try (Connection conn = DBConfig.getJDBCConnection(session)) {
			try (PreparedStatement stmt = conn.prepareStatement(insertSQL.toString())) {
				stmt.setLong(1, requestId);
				stmt.execute();

				logger.info("Inserting and calculating 'IRPA TScope Module' request master counts -- End");
			} catch (Exception e) {
				logger.error("Failure while calculating 'IRPA TScope Module' request master counts ...", e);
				throw new Exception();
			}
		} catch (Exception e) {
			logger.error(
					"Failure in getting connection while calculating 'IRPA TScope Module' request master counts ...",
					e);
			throw new Exception();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Integer> getModulesCount(long requestId) throws Exception {
		logger.info("Getting module counts - IRPA TScope Request Master -- Start");

		StringBuilder getCountHQL = new StringBuilder(
				"SELECT module, scenarioCount FROM IRPATScopeModuleReqMaster "
						+ "WHERE requestId = :requestId");

		Session session = null;
		Map<String, Integer> moduleCountMap = new LinkedHashMap<>();

		try {
			session = sessionFactory.openSession();
			Query query = session.createQuery(getCountHQL.toString());
			query.setParameter("requestId", requestId);
			List<Object[]> countList = query.list();

			for (Object[] obj : countList)
				moduleCountMap.put((String) obj[0], ((Integer) obj[1]));
		} catch (Exception e) {
			logger.error("Error while getting Module Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return moduleCountMap;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Map<String, Map<String, List<Integer>>> getProcessCount(long requestId) throws Exception {
		logger.info("Getting scenario counts - IRPA TScope Request Master -- Start");

		StringBuilder getCountHQL = new StringBuilder("SELECT module, process, scenarioCount, "
				+ "testScriptsAvailYesCount, testScriptsAvailNoCount, "
				+ "toBeUpdatedYesCount, toBeUpdatedNoCount FROM IRPATScopeRMScenarios "
				+ "WHERE requestId = :requestId");

		Session session = null;
		Map<String, Map<String, List<Integer>>> processScenarioMap = new LinkedHashMap<>();
		Map<String, List<Integer>> scenarioMap = null;
		List<Integer> countList = null;

		try {
			session = sessionFactory.openSession();
			Query query = session.createQuery(getCountHQL.toString());
			query.setParameter("requestId", requestId);
			List<Object[]> processList = query.list();

			for (Object[] obj : processList) {
				if (processScenarioMap.containsKey((String) obj[0]))
					scenarioMap = processScenarioMap.get((String) obj[0]);
				else
					scenarioMap = new LinkedHashMap<>();

				countList = new LinkedList<>();
				countList = Arrays.asList((Integer) obj[2], (Integer) obj[3], (Integer) obj[4], (Integer) obj[5],
						(Integer) obj[6]);
				scenarioMap.put((String) obj[1], countList);

				processScenarioMap.put((String) obj[0], scenarioMap);
			}
		} catch (Exception e) {
			logger.error("Error while getting Business Scenarios Counts : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}

		return processScenarioMap;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getImpactedNonImpactedCounts(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder("SELECT "
				+ "COUNT(DISTINCT (CASE WHEN OperCode LIKE :impactedMostUsed "
				+ "AND Opercode NOT LIKE :nonImpactedMostUsed "
				+ "THEN BusinessScenario_Level3 END)) AS impactedMostUsed, "
				+ "COUNT(DISTINCT (CASE WHEN OperCode LIKE  :nonImpactedMostUsed "
				+ "THEN BusinessScenario_Level3 END)) AS nonImpactedMostUsed, "
				+ "COUNT(DISTINCT (CASE WHEN OperCode LIKE :impacted THEN BusinessScenario_Level3 END)) AS impacted "
				+ "FROM TScope_Final_Intermediate WHERE Request_Id = :requestId AND Is_Business_Scenario_Relevant = :isScenarioRelevant "
				+ "AND BusinessScenario_Level3 IS NOT NULL AND BusinessScenario_Level3 <> :emptyScenario "
				+ "AND BusinessScenario_Level3 <> :othersScenario");

		Session session = null;
		List<Object[]> countList = null;

		try {
			session = sessionFactory.openSession();

			SQLQuery query = session.createSQLQuery(getSQL.toString());
			query.addScalar("impactedMostUsed", new LongType());
			query.addScalar("nonImpactedMostUsed", new LongType());
			query.addScalar("impacted", new LongType());
			query.setParameter("requestId", requestId);
			query.setParameter("isScenarioRelevant", "Yes");
			query.setParameter("impactedMostUsed", "%Impacted Most Used");
			query.setParameter("nonImpactedMostUsed", "%Non Impacted Most Used");
			query.setParameter("impacted", "%Impacted");
			query.setParameter("emptyScenario", StringUtils.EMPTY);
			query.setParameter("othersScenario", "Others");

			countList = query.list();
		} catch (Exception e) {
			logger.error("Error while getting Standard and Custom Counts : ", e);
		} finally {
			if (session != null)
				session.close();
		}

		return countList;
	}

	@Override
	public IRPATScopeEstimates getIRPAEstimates(long requestId) throws Exception {
		Session session = null;

		try {
			session = sessionFactory.openSession();

			IRPATScopeEstimates estimatesObj = (IRPATScopeEstimates) session.get(IRPATScopeEstimates.class, requestId);

			return estimatesObj;
		} catch (Exception e) {
			logger.error("Error while fetching the IRPA Estimates Data : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}
	}

	@Override
	public void saveIRPAEstimates(IRPATScopeEstimates estimatorObj) throws Exception {
		Session session = null;
		Transaction tx = null;

		try {
			session = sessionFactory.openSession();
			tx = session.beginTransaction();

			session.merge("IRPATScopeEstimates", estimatorObj);
			tx.commit();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();

			logger.error("Error while saving the IRPA Estimator Data : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}
	}

	@Override
	public void dataTransaferIntToDownload(long requestId) throws Exception {
		logger.info("Transferring Testing Scope Data From Intermediate to Download Table ...");

		StringBuilder getInsertHQL = new StringBuilder("INSERT INTO TestingScopeDownload "
				+ "(requestId, objectType, objectName, module, process, objTypeObjName, appComponent, operCd, "
				+ "appCompDesc, transactions, businessScenarioLevel1, businessScenarioLevel2, businessScenarioLevel3, "
				+ "comments, targetTransactions, needsToBeUpdated, isBusinessScenarioRelevant, testScriptAvailable, countOfTestScriptsPerScenario) "
				+ "SELECT DISTINCT "
				+ "requestId, objectType, objectName, module, process, objTypeObjName, appComponent, operCd, "
				+ "appCompDesc, transactions, businessScenarioLevel1, businessScenarioLevel2, businessScenarioLevel3, "
				+ "comments, targetTransactions, needsToBeUpdated, isBusinessScenarioRelevant, testScriptAvailable, countOfTestScriptsPerScenario "
				+ "FROM TScopeFinalIntermediate WHERE requestId = :requestId");

		Session session = null;
		Transaction tx = null;

		try {
			session = sessionFactory.openSession();
			tx = session.beginTransaction();
			Query query = session.createQuery(getInsertHQL.toString());
			query.setParameter("requestId", requestId);

			query.executeUpdate();

			tx.commit();
		} catch (Exception e) {
			logger.error("Error while transferring testing scope data from intermediate to download table : ", e);

			if (tx != null)
				tx.rollback();
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}
	}

	@Override
	public void updateIRPAStatus(long requestId) throws Exception {
		Session session = null;
		Transaction tx = null;

		try {
			session = sessionFactory.openSession();
			tx = session.beginTransaction();

			RequestStatusMaster reqStatusObj = (RequestStatusMaster) session.get(RequestStatusMaster.class, requestId);
			reqStatusObj.setIrpaStatus(Hana_Profiler_Constant.IRPA_FILE_UPLOAD_SUCCESS);

			session.update("RequestStatusMaster", reqStatusObj);
			tx.commit();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();

			logger.error("Error while updating the IRPA Status Data : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getS4AppCompMap(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder("SELECT OBJ_NAME_TYPE, GROUP_CONCAT(DISTINCT APP_COMPONENT) "
				+ "FROM S4_Final_Output WHERE REQUEST_ID = :requestId AND APP_COMPONENT <> '' AND "
				+ "APP_COMPONENT <> 'NA' GROUP BY OBJ_NAME_TYPE");

		Session session = null;

		try {
			session = sessionFactory.openSession();
			SQLQuery query = session.createSQLQuery(getSQL.toString());
			query.setParameter("requestId", requestId);

			List<Object[]> resultList = query.list();

			return resultList;
		} catch (Exception e) {
			logger.error("Error while fetching S4 application components : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getBusinessProcessDetailList(long requestId) throws Exception {
		StringBuilder getSQL = new StringBuilder("SELECT Object_Name_Type, "
				+ "GROUP_CONCAT(CONCAT_WS(',', RTR, OTC, S2D, PTP, HTR)) FROM Business_Process_Detail WHERE "
				+ "Request_ID = :requestId GROUP BY Object_Name_Type");

		Session session = null;

		try {
			session = sessionFactory.openSession();
			SQLQuery query = session.createSQLQuery(getSQL.toString());
			query.setParameter("requestId", requestId);

			List<Object[]> resultList = query.list();

			return resultList;
		} catch (Exception e) {
			logger.error("Error while fetching Business Process Detail list : ", e);
			throw new Exception();
		} finally {
			if (session != null)
				session.close();
		}
	}
}