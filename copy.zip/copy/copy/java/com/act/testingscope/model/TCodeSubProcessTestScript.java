package com.act.testingscope.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "TCode_SubProcessTestScript")
public class TCodeSubProcessTestScript {
	private int id;
	private String scenarioLevelOne;
	private String mainProcessLevelTwo;
	private String subProcessLevelThree;
	private String testScriptLevelFour;
	private String tcodesECC;
	private String tcodesS41610;
	private String tcodesS41709;
	private String tcodesS41809;
	private String tcodesS41909;
	private String applicationComponent;
	private String fioriAppID;
	private String fioriAppName;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID")
	@Index(name = "ID_Index")
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	@Column(name = "Scenario_Level1", columnDefinition = "TEXT")
	public String getScenarioLevelOne() {
		return scenarioLevelOne;
	}
	public void setScenarioLevelOne(String scenarioLevelOne) {
		this.scenarioLevelOne = scenarioLevelOne;
	}
	
	@Column(name = "Main_Process_Level2", columnDefinition = "TEXT")
	public String getMainProcessLevelTwo() {
		return mainProcessLevelTwo;
	}
	public void setMainProcessLevelTwo(String mainProcessLevelTwo) {
		this.mainProcessLevelTwo = mainProcessLevelTwo;
	}
	
	@Column(name = "Sub_Process_Level3", columnDefinition = "TEXT")
	public String getSubProcessLevelThree() {
		return subProcessLevelThree;
	}
	public void setSubProcessLevelThree(String subProcessLevelThree) {
		this.subProcessLevelThree = subProcessLevelThree;
	}
	
	@Column(name = "Test_Script_Level4", columnDefinition = "TEXT")
	public String getTestScriptLevelFour() {
		return testScriptLevelFour;
	}
	public void setTestScriptLevelFour(String testScriptLevelFour) {
		this.testScriptLevelFour = testScriptLevelFour;
	}
	
	@Column(name = "TCodes_ECC", columnDefinition = "TEXT")
	public String getTcodesECC() {
		return tcodesECC;
	}
	public void setTcodesECC(String tcodesECC) {
		this.tcodesECC = tcodesECC;
	}
	
	@Column(name = "TCodes_S4_1610", columnDefinition = "TEXT")
	public String getTcodesS41610() {
		return tcodesS41610;
	}
	public void setTcodesS41610(String tcodesS41610) {
		this.tcodesS41610 = tcodesS41610;
	}
	
	@Column(name = "TCodes_S4_1709", columnDefinition = "TEXT")
	public String getTcodesS41709() {
		return tcodesS41709;
	}
	public void setTcodesS41709(String tcodesS41709) {
		this.tcodesS41709 = tcodesS41709;
	}
	
	@Column(name = "TCodes_S4_1809", columnDefinition = "TEXT")
	public String getTcodesS41809() {
		return tcodesS41809;
	}
	public void setTcodesS41809(String tcodesS41809) {
		this.tcodesS41809 = tcodesS41809;
	}
	
	@Column(name = "TCodes_S4_1909", columnDefinition = "TEXT")
	public String getTcodesS41909() {
		return tcodesS41909;
	}
	public void setTcodesS41909(String tcodesS41909) {
		this.tcodesS41909 = tcodesS41909;
	}
	
	@Column(name = "Application_Component")
	public String getApplicationComponent() {
		return applicationComponent;
	}
	public void setApplicationComponent(String applicationComponent) {
		this.applicationComponent = applicationComponent;
	}
	
	@Column(name = "Fiori_AppID")
	public String getFioriAppID() {
		return fioriAppID;
	}
	public void setFioriAppID(String fioriAppID) {
		this.fioriAppID = fioriAppID;
	}
	
	@Column(name = "Fiori_AppName")
	public String getFioriAppName() {
		return fioriAppName;
	}
	public void setFioriAppName(String fioriAppName) {
		this.fioriAppName = fioriAppName;
	}
}
