package com.act.testingscope.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Business_Process_Detail")
public class BusinessProcessDetail {

	private int id;
	private long requestId;
	private String objectType;
	private String objectName;
	private String objNameType;
	private String rtr;
	private String otc;
	private String ptp;
	private String htr;
	private String s2d;
	private String others;
	private String finalBusinessProcessCat;
	
	@Id	
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "ID")
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	@Column(name = "Request_ID")
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	
	@Column(name = "Object_Type")
	public String getObjectType() {
		return objectType;
	}
	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}
	
	@Column(name = "Object_Name")
	public String getObjectName() {
		return objectName;
	}
	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}
	
	@Column(name = "Object_Name_Type")
	public String getObjNameType() {
		return objNameType;
	}
	public void setObjNameType(String objNameType) {
		this.objNameType = objNameType;
	}
	
	@Column(name = "RTR")
	public String getRtr() {
		return rtr;
	}
	public void setRtr(String rtr) {
		this.rtr = rtr;
	}
	
	@Column(name = "OTC")
	public String getOtc() {
		return otc;
	}
	public void setOtc(String otc) {
		this.otc = otc;
	}
	
	@Column(name = "PTP")
	public String getPtp() {
		return ptp;
	}
	public void setPtp(String ptp) {
		this.ptp = ptp;
	}
	
	@Column(name = "HTR")
	public String getHtr() {
		return htr;
	}
	public void setHtr(String htr) {
		this.htr = htr;
	}
	
	@Column(name = "S2D")
	public String getS2d() {
		return s2d;
	}
	public void setS2d(String s2d) {
		this.s2d = s2d;
	}
	
	@Column(name = "Others")
	public String getOthers() {
		return others;
	}
	public void setOthers(String others) {
		this.others = others;
	}
	@Column(name = "Final_Business_Process_Category")
	public String getFinalBusinessProcessCat() {
		return finalBusinessProcessCat;
	}
	public void setFinalBusinessProcessCat(String finalBusinessProcessCat) {
		this.finalBusinessProcessCat = finalBusinessProcessCat;
	}
}
