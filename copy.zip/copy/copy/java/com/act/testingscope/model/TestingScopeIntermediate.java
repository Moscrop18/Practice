package com.act.testingscope.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TestingScope_Intermediate")
public class TestingScopeIntermediate implements Serializable {

	private static final long serialVersionUID = -5294188737237640015L;

	@Id	
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "ID")
	private Integer Id;	

	@Column(name = "requestid")
	private long requestid;

	@Column(name = "objecttype")
	private String objecttype;

	@Column(name = "objectname")
	private String objectname;

	@Column(name = "process")
	private String process;
	
	@Column(name = "objectTypeObjectName")
	private String objectTypeObjectName;
	
	@Column(name = "applicationComponent" , columnDefinition = "TEXT")
	private String applicationComponent;
	
	@Column(name = "opercd")
	private String opercd;
	
	@Column(name = "appCompDesc" , columnDefinition = "TEXT")
	private String appCompDesc;
	
	@Column(name = "transactions" , columnDefinition = "TEXT")
	private String transactions;
	
	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
	}
	
	public long getRequestid() {
		return requestid;
	}

	public void setRequestid(long requestid) {
		this.requestid = requestid;
	}
	
	public String getObjectname() {
		return objectname;
	}

	public void setObjectname(String objectname) {
		this.objectname = objectname;
	}

	public String getObjectTypeObjectName() {
		return objectTypeObjectName;
	}

	public void setObjectTypeObjectName(String objectTypeObjectName) {
		this.objectTypeObjectName = objectTypeObjectName;
	}
	
	public String getProcess() {
		return process;
	}

	public void setProcess(String process) {
		this.process = process;
	}

	public String getApplicationComponent() {
		return applicationComponent;
	}

	public void setApplicationComponent(String applicationComponent) {
		this.applicationComponent = applicationComponent;
	}
	
	public String getObjecttype() {
		return objecttype;
	}

	public void setObjecttype(String objecttype) {
		this.objecttype = objecttype;
	}

	public String getOpercd() {
		return opercd;
	}

	public void setOpercd(String opercd) {
		this.opercd = opercd;
	}

	public String getAppCompDesc() {
		return appCompDesc;
	}

	public void setAppCompDesc(String appCompDesc) {
		this.appCompDesc = appCompDesc;
	}

	public String getTransactions() {
		return transactions;
	}

	public void setTransactions(String transactions) {
		this.transactions = transactions;
	}
}
