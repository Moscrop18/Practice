package com.act.testingscope.model;

public class Testingscopepojo {
	
	private String opercd;
	private String comments;
	private String objecttype;
	private String objectname;
	private String info;
	private String code;
	
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getOpercd() {
		return opercd;
	}
	public void setOpercd(String opercd) {
		this.opercd = opercd;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getObjecttype() {
		return objecttype;
	}
	public void setObjecttype(String objecttype) {
		this.objecttype = objecttype;
	}
	public String getObjectname() {
		return objectname;
	}
	public void setObjectname(String objectname) {
		this.objectname = objectname;
	}

}
