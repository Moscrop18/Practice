package com.act.testingscope.model;

public class Tscopese95 {
	
	private String tscopese95opcode;
	private String tscopese95comments;
	private String tscopese95objecttype;
	private String tscopese95objectname;
	private String tscopese95description;
	
	public String getTscopese95opcode() {
		return tscopese95opcode;
	}
	public void setTscopese95opcode(String tscopese95opcode) {
		this.tscopese95opcode = tscopese95opcode;
	}
	public String getTscopese95comments() {
		return tscopese95comments;
	}
	public void setTscopese95comments(String tscopese95comments) {
		this.tscopese95comments = tscopese95comments;
	}
	public String getTscopese95objecttype() {
		return tscopese95objecttype;
	}
	public void setTscopese95objecttype(String tscopese95objecttype) {
		this.tscopese95objecttype = tscopese95objecttype;
	}
	public String getTscopese95objectname() {
		return tscopese95objectname;
	}
	public void setTscopese95objectname(String tscopese95objectname) {
		this.tscopese95objectname = tscopese95objectname;
	}
	public String getTscopese95description() {
		return tscopese95description;
	}
	public void setTscopese95description(String tscopese95description) {
		this.tscopese95description = tscopese95description;
	}
	

}
