package com.act.testingscope.model;

import java.util.HashSet;

public class StandardTcodeTable {
	
	private String description;
	private String process;
	private HashSet<String> standardtcode;
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getProcess() {
		return process;
	}
	public void setProcess(String process) {
		this.process = process;
	}
	public HashSet<String> getStandardtcode() {
		return standardtcode;
	}
	public void setStandardtcode(HashSet<String> standardtcode) {
		this.standardtcode = standardtcode;
	}
	
	
	

}
