package com.act.testingscope.model;

public class CustomTcodeTable {
	
	private String customtcode;
	public String getCustomtcode() {
		return customtcode;
	}
	public void setCustomtcode(String customtcode) {
		this.customtcode = customtcode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	private String description;
	

}
