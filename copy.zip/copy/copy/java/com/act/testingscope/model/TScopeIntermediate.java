package com.act.testingscope.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "TScope_Intermediate")
public class TScopeIntermediate {
	private int id;
	private long requestId;
	private String objectType;
	private String objectName;
	private String module;
	private String process;
	private String objTypeObjName;
	private String appComponent;
	private String operCd;
	private String appCompDesc;
	private String transactions;
	private String businessScenarioLevel1;
	private String businessScenarioLevel2;
	private String businessScenarioLevel3;
	private String comments;
	private String targetTransactions;
	private String needsToBeUpdated;
	private String isBusinessScenarioRelevant;
	private String testScriptAvailable;
	private int countOfTestScriptsPerScenario;
	private int appCompID;
		
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	@Column(name = "Request_Id")
	public long getRequestId() {
		return requestId;
	}
	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}
	
	@Column(name = "BusinessScenario_Level1", columnDefinition = "TEXT")
	public String getBusinessScenarioLevel1() {
		return businessScenarioLevel1;
	}
	public void setBusinessScenarioLevel1(String businessScenarioLevel1) {
		this.businessScenarioLevel1 = businessScenarioLevel1;
	}
	
	@Column(name = "BusinessScenario_Level2", columnDefinition = "TEXT")
	public String getBusinessScenarioLevel2() {
		return businessScenarioLevel2;
	}
	public void setBusinessScenarioLevel2(String businessScenarioLevel2) {
		this.businessScenarioLevel2 = businessScenarioLevel2;
	}
	
	@Column(name = "BusinessScenario_Level3", columnDefinition = "TEXT")
	public String getBusinessScenarioLevel3() {
		return businessScenarioLevel3;
	}
	public void setBusinessScenarioLevel3(String businessScenarioLevel3) {
		this.businessScenarioLevel3 = businessScenarioLevel3;
	}
	
	@Column(name = "Object_Type")
	public String getObjectType() {
		return objectType;
	}
	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}
	
	@Column(name = "Object_Name")
	public String getObjectName() {
		return objectName;
	}
	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}
	
	@Column(name = "Module")
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	
	@Column(name = "Process")
	public String getProcess() {
		return process;
	}
	public void setProcess(String process) {
		this.process = process;
	}
	
	@Column(name = "ObjectType_ObjectName")
	public String getObjTypeObjName() {
		return objTypeObjName;
	}
	public void setObjTypeObjName(String objTypeObjName) {
		this.objTypeObjName = objTypeObjName;
	}
	
	@Column(name = "Application_Component", columnDefinition = "TEXT")
	public String getAppComponent() {
		return appComponent;
	}
	public void setAppComponent(String appComponent) {
		this.appComponent = appComponent;
	}
	
	@Column(name = "OperCode")
	public String getOperCd() {
		return operCd;
	}
	public void setOperCd(String operCd) {
		this.operCd = operCd;
	}
	
	@Column(name = "Application_Component_Description", columnDefinition = "TEXT")
	public String getAppCompDesc() {
		return appCompDesc;
	}
	public void setAppCompDesc(String appCompDesc) {
		this.appCompDesc = appCompDesc;
	}
	
	@Column(name = "Transactions", columnDefinition = "TEXT")
	public String getTransactions() {
		return transactions;
	}
	public void setTransactions(String transactions) {
		this.transactions = transactions;
	}
	
	@Column(name = "Comments")
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	@Column(name = "Target_Transactions")
	public String getTargetTransactions() {
		return targetTransactions;
	}
	public void setTargetTransactions(String targetTransactions) {
		this.targetTransactions = targetTransactions;
	}
	
	@Column(name = "Needs_To_Be_Updated")
	public String getNeedsToBeUpdated() {
		return needsToBeUpdated;
	}
	public void setNeedsToBeUpdated(String needsToBeUpdated) {
		this.needsToBeUpdated = needsToBeUpdated;
	}
	
	@Column(name = "Is_Business_Scenario_Relevant")
	public String getIsBusinessScenarioRelevant() {
		return isBusinessScenarioRelevant;
	}
	public void setIsBusinessScenarioRelevant(String isBusinessScenarioRelevant) {
		this.isBusinessScenarioRelevant = isBusinessScenarioRelevant;
	}
	
	@Column(name = "Test_Script_Available")
	public String getTestScriptAvailable() {
		return testScriptAvailable;
	}
	public void setTestScriptAvailable(String testScriptAvailable) {
		this.testScriptAvailable = testScriptAvailable;
	}
	
	@Column(name = "Count_TestScripts_PerScenario", columnDefinition = "int default 1")
	public int getCountOfTestScriptsPerScenario() {
		return countOfTestScriptsPerScenario;
	}
	public void setCountOfTestScriptsPerScenario(int countOfTestScriptsPerScenario) {
		this.countOfTestScriptsPerScenario = countOfTestScriptsPerScenario;
	}
	
	@Column(name = "AppComp_ID")
	@Index(name = "ID_Index")
	public int getAppCompID() {
		return appCompID;
	}
	public void setAppCompID(int appCompID) {
		this.appCompID = appCompID;
	}
}
