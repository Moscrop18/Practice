package com.act.testingscope.model;

public class Tscope {
	
	private String tscopeopcode;
	private String tscopecomments;
	private String tscopedescription;
	
	private String tscopeobjecttype;
	private String tscopeobjectname;

	public String getTscopeopcode() {
		return tscopeopcode;
	}
	public void setTscopeopcode(String tscopeopcode) {
		this.tscopeopcode = tscopeopcode;
	}
	public String getTscopecomments() {
		return tscopecomments;
	}
	public void setTscopecomments(String tscopecomments) {
		this.tscopecomments = tscopecomments;
	}
	public String getTscopedescription() {
		return tscopedescription;
	}
	public void setTscopedescription(String tscopedescription) {
		this.tscopedescription = tscopedescription;
	}
	public String getTscopeobjecttype() {
		return tscopeobjecttype;
	}
	public void setTscopeobjecttype(String tscopeobjecttype) {
		this.tscopeobjecttype = tscopeobjecttype;
	}
	public String getTscopeobjectname() {
		return tscopeobjectname;
	}
	public void setTscopeobjectname(String tscopeobjectname) {
		this.tscopeobjectname = tscopeobjectname;
	}

}
