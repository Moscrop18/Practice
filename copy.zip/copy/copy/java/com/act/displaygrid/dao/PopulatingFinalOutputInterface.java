/*CR-No. 	Desc		  Date  			Modified By
 * 
 * CR-9.0:- Manual upload for Estimator & assuptions -17/01/17 -monika.mishra*/

package com.act.displaygrid.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.act.Aadt.models.AuctFinalOutput;
import com.act.Aadt.models.AuctFinalOutput_Download;
import com.act.Aadt.models.BWExtractor_Download;
import com.act.Aadt.models.ImpactedCloneAnalysis_Download;
import com.act.Aadt.models.ImpactedObjList_Download;
import com.act.Aadt.models.ImpactedVariant_Download;
import com.act.Aadt.models.OSMigrationFinal;
import com.act.S4.models.BwCleanupUtilDownload;
import com.act.S4.models.CvitCustomisingLogsDownload;
import com.act.S4.models.CvitErrorMessagesDownload;
import com.act.S4.models.InactiveObjectsDownload;
import com.act.S4.models.InconsistentFUGR_Download;
import com.act.S4.models.S4HanaProfiler;
import com.act.S4.models.S4ImpactedCustomTblDownload;
import com.act.S4.models.S4SimplificationDatabase;
import com.act.S4.models.S4_SID_Download;
import com.act.S4.models.S4cvitr_Download;
import com.act.S4.models.UnicodeOutput;
import com.act.Scripts.model.ImpactedScripts;
import com.act.Scripts.model.ImpactedScripts_Download;
import com.act.bw.model.BwExtractorMaster;
import com.act.bw.model.BwInventoryDownload;
import com.act.bw.model.BwStandardExtractDownload;
import com.act.displaygrid.model.HanaAssumption;
import com.act.displaygrid.model.HanaEstimator;
import com.act.displaygrid.model.HanaProfile;
import com.act.displaygrid.model.HanaProfile_Download;
import com.act.fiori.models.CustomReportOutput_download;
import com.act.fiori.models.InventoryStandardFiori;
import com.act.testingscope.model.ExtractedDatapojo;

public interface PopulatingFinalOutputInterface {

	public List<HanaProfile_Download> GetList(Long requestID, final int from, final int limit);

	boolean getHanaProfilerFinalList(final long requestId, final String clientName,HttpSession session);

	void archiveData(final long requestID, final String pathName);
	void deleteDuplicateRecords(final long requestID);
	
	void deleteCurrentQueueExecution(Class className);
	public Map<Integer,String> getWaitingRequest();
	
	public void updateSubTypeValues(final long requestID);
	
	/*CR-9.0*/
	public String addEstimatorData(final HanaEstimator hanaEstimator);

	public String addAssumptionsData(final HanaAssumption hanaAssumption);

	public void updateImpactObjType(long requestID);

	public List<ImpactedObjList_Download> GetImpactedObjectList(Long REQUEST_ID, final int from, final int limit);
	
	public List<AuctFinalOutput_Download> writeAuctFinalOutputSheet(Long requestID, final int from, final int limit);

	public List<InventoryStandardFiori> writeOdataFinalOutputSheet(Long requestID, final int from, final int limit);

	public boolean getAUCTFinalStatus(long requestID, HttpSession session);

	public void updateAUCTAutomationLogic(long requestID);
	
	public void updateAUCTPackageFromInventory(long requestId, HttpSession session) throws SQLException;
	
	public void updateInventory(long requestId);

	public Map<String, String> getTestingscopeValuesdb();
	
	public List<S4cvitr_Download> getcvitrList(Long REQUEST_ID, final int from, final int limit);
	
	public void clientFileProcessingBusinessLogicScripts(long requestId, HttpServletRequest request, String toolName,
			HttpSession session, List<ImpactedScripts> impactedScripts)throws Exception ;

	public List<ImpactedScripts_Download> getImpactedScriptsList(Long requestID, int i, int j);
	
	public List<ImpactedCloneAnalysis_Download> getImpactedCloneList(Long REQUEST_ID, final int from, final int limit);
	
	public List<HanaProfile> getHanaDetailReport(Long requestID, final int from, final int limit);
	
	public List<S4HanaProfiler> getS4DetailReport(Long requestID, final int from, final int limit);
	
	public List<S4SimplificationDatabase> getSimplificationListReport(Long requestID, final int from, final int limit);
	
	public List<AuctFinalOutput> getExistingErrorReport(Long requestID, final int from, final int limit);

	public List<OSMigrationFinal> getOSMigrationFinalReport(Long requestID, final int from, final int limit);

	public Map<String, TreeMap<String, String>> testingScopeMasterDataValues();
	
	public String testingScopeFinalInsert(List<ExtractedDatapojo> finalTestingScopeReportList,
			HttpSession session) throws SQLException;
	
	public void unicodeProcessing(HttpSession session) throws SQLException;
	
	public List<UnicodeOutput> getUnicodeOutput(Long requestId);
	
	public void deleteProcessedRequestFromWaitingQueue(Long requestId, HttpSession session)throws SQLException;
	
	public Map<Integer, String> getWaitingRequestWithOldTime(HttpSession session);
	
	public List<InconsistentFUGR_Download> getInconsistentFUGRList(Long requestId);
	
	public List<S4_SID_Download> getS4SIDList(Long requestId);
	
	public List<ImpactedVariant_Download> getImpactedVariantList(Long requestId);
	
	List<ExtractedDatapojo> getTestingScope(long requestID);
	
	public List<BwInventoryDownload> getBwInventoryList(Long requestId);
	
	public List<BwCleanupUtilDownload> getBwCleanupUtilList(Long requestId);
	
	public List<S4ImpactedCustomTblDownload> getImpatctedCustTablesList(Long requestId);
	
	public List<BwStandardExtractDownload> getBwStdExtrctList(Long requestId);
	
	public List<InactiveObjectsDownload> getInactiveObjectsList(Long requestId);
	
	public List<BwExtractorMaster> getBwMasterDataList();
	public List<BWExtractor_Download> getBwExtractorList(Long requestId);
	public List<CustomReportOutput_download> writeCustomReportFinalOutputSheet(Long REQUEST_ID, int from, int limit);

	public List<CvitCustomisingLogsDownload> getcvitCustomLogsList(long requestId);
	
	public List<CvitErrorMessagesDownload> getcvitErrorMsgsList(long requestId);
}
