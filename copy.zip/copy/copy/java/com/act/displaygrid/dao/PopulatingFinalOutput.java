/*MODIFIED 
 *FOR Enhancement CR-1.0:-Update the automation_Status according to Sel_line-20/12/16 -monika.mishra
 *
 *CR-9.0:- Manual upload for Estimator & assumptions -17/01/17 -monika.mishra
 *
 *CR-13.0- New Output Sheet implementation - 03/03/2017 - monika.mishra
 *
 *CR-25.0- Few fields which will be moved to JAVA tool in HANA Profiler - 10/07/2017 - monika.mishra
 *
 *CR-28.0:- Add col Total Line Scanned -24/07/17 -monika.mishra
 *
 *CR-29.0:- Shown CDS View on basis of tables column value -5/08/17 -monika.mishra
 *
 *CR-32.0: Adding operation to update automation status -23/8/2017-monika.mishra
 *
 *CR-39.0: Adding Statement Col in final output sheet-3/1/2018-rohan.a.mehra
 *
 *
 *US-04: Change in Inventory List Logic:-
 *		4.1: Remove LSMW related code -07/08/2018 -himani.malhotra
 *		4.2: Update object type as USERExit & combine data of both inventory & userexit -06/08/2018 -himani.malhotra
 *
 *US:05 Impacted Object list tab CR for AADT -rohan.a.mehra
 *
 *DEF042: Add Used column in Detail Reports -himani.malhotra
 **/

package com.act.displaygrid.dao;

import java.io.File;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.CacheMode;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.ScrollMode;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.act.Aadt.models.AuctFinalOutput;
import com.act.Aadt.models.AuctFinalOutput_Download;
import com.act.Aadt.models.BWExtractor_Download;
import com.act.Aadt.models.ImpactedCloneAnalysis_Download;
import com.act.Aadt.models.ImpactedObjList_Download;
import com.act.Aadt.models.ImpactedVariant_Download;
import com.act.Aadt.models.OSMigrationFinal;
import com.act.S4.models.BwCleanupUtilDownload;
import com.act.S4.models.CvitCustomisingLogsDownload;
import com.act.S4.models.CvitErrorMessagesDownload;
import com.act.S4.models.InactiveObjectsDownload;
import com.act.S4.models.InconsistentFUGR_Download;
import com.act.S4.models.S4HanaProfiler;
import com.act.S4.models.S4ImpactedCustomTblDownload;
import com.act.S4.models.S4InventoryList;
import com.act.S4.models.S4SimplificationDatabase;
import com.act.S4.models.S4_SID_Download;
import com.act.S4.models.S4cvitr_Download;
import com.act.S4.models.UnicodeOutput;
import com.act.Scripts.model.ImpactedScripts;
import com.act.Scripts.model.ImpactedScripts_Download;
import com.act.Scripts.model.ImpactedScripts_Intermediate;
import com.act.bw.model.BwExtractorMaster;
import com.act.bw.model.BwInventoryDownload;
import com.act.bw.model.BwStandardExtractDownload;
import com.act.constant.Hana_Profiler_Constant;
import com.act.constant.ST03HanaConstant;
import com.act.displaygrid.model.DBConfig;
import com.act.displaygrid.model.HanaAssumption;
import com.act.displaygrid.model.HanaEstimator;
import com.act.displaygrid.model.HanaProfile;
import com.act.displaygrid.model.HanaProfile_Download;
import com.act.exceptions.HibernateException;
import com.act.fileprocessing.AutomateHANA;
import com.act.fileprocessing.PopulateHanaTables;
import com.act.fileprocessing.model.CDSView;
import com.act.fileprocessing.model.HanaProfilerStepOutput;
import com.act.fiori.models.CustomReportOutput_download;
import com.act.fiori.models.InventoryStandardFiori;
import com.act.reader.xlsx.St03ReaderXlsx;
import com.act.testingscope.model.ExtractedDatapojo;
import com.act.utility.HANAUtility;

public class PopulatingFinalOutput implements PopulatingFinalOutputInterface {

	private PopulateHanaTables populateHanaTable;
	SessionFactory sessionFactory;
	private St03ReaderXlsx st03ReaderXlsx;
	private AutomateHANA automateHANA;

	public AutomateHANA getAutomateHANA() {
		return automateHANA;
	}

	@Autowired
	public void setAutomateHANA(AutomateHANA automateHANA) {
		this.automateHANA = automateHANA;
	}

	public void setPopulateHanaTable(PopulateHanaTables populateHanaTable) {
		this.populateHanaTable = populateHanaTable;
	}

	public void setSt03ReaderXlsx(St03ReaderXlsx st03ReaderXlsx) {
		this.st03ReaderXlsx = st03ReaderXlsx;
	}

	private HibernateTemplate hibernateTemplate;
	final static Logger logger = LoggerFactory.getLogger(PopulatingFinalOutput.class);

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

	public PopulatingFinalOutput() {

	}

	private void getListWithValue(final Long requestId, final boolean isNAValueExists, HttpSession session)
			throws SQLException {
		logger.info("Successfully get Sission From SessionFactory");
		logger.info("create Criteria for get all records from DB");

		logger.info("Before refining with 99 ");
		refineOP99(requestId);

		// Op-code 45 & 46 is required so commenting the refining for op-code 45
		// & 46.
		// refineLoopColumn(requestId);

		logger.info("Before refining impact value ");
		long refineImpactColumnStartTime = System.currentTimeMillis();
		refineImpactValue(requestId, session);
		long refineImpactColumnEndTime = System.currentTimeMillis();
		long refineImpactColumnTime = refineImpactColumnEndTime - refineImpactColumnStartTime;
		logger.info("Total time in refining Impact Column= " + refineImpactColumnTime);
		long refineUnwantedCategoryStartTime = System.currentTimeMillis();
		refineUnwantedCategory(requestId);
		long refineUnwantedCategoryEndTime = System.currentTimeMillis();
		long refineUnwantedCategoryTotalTime = refineUnwantedCategoryEndTime - refineUnwantedCategoryStartTime;
		logger.info("Total time in refining Unwanted Category= " + refineUnwantedCategoryTotalTime);

		/**
		 * Merge code of refineUnwantadCategory and
		 * refineUnwantadCategoryForJoinType
		 */

		if (isNAValueExists) {
			logger.info("Before refining subtype ");

			refineSubType(requestId);
			logger.info("Return refining subtype ");
		}
		logger.info("Going to update subtype value ");
		updateSubTypeValues(requestId);

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private boolean checkSubCNAValue(final long requestId) {
		final Long count = (Long) hibernateTemplate.execute(new HibernateCallback() {
			public Object doInHibernate(Session session) throws HibernateException {
				final Criteria criteria = session.createCriteria(HanaProfile.class);
				criteria.add(Restrictions.eq("requestID", requestId));
				criteria.add(Restrictions.eq("Sub_Type", Hana_Profiler_Constant.Sub_Type_Val));
				criteria.setProjection(Projections.rowCount());
				return criteria.uniqueResult();
			}
		});

		return count > 0;

	}

	public boolean getHanaProfilerFinalList(final long requestId, final String clientName, HttpSession session) {

		Boolean refiningStatus = false;
		try {
			long checkNAStartTime = System.currentTimeMillis();
			final boolean isNAValueExists = checkSubCNAValue(requestId);
			long checkNAEndTime = System.currentTimeMillis();
			long checkNATime = checkNAEndTime - checkNAStartTime;
			logger.info("Total time to check NA=" + checkNATime);

			long insertTRDRStartTime = System.currentTimeMillis();

			if (isNAValueExists) {
				delete_TR_DIR_Records(requestId);
				addTRDRList(requestId, clientName, session);
			}
			long insertTRDREndTime = System.currentTimeMillis();
			long insertTRDRTime = insertTRDREndTime - insertTRDRStartTime;
			logger.info("Total time to check NA=" + insertTRDRTime);

			long startTime = System.currentTimeMillis();
			// manualUpdate(requestId);

			long endTime = System.currentTimeMillis();
			long netTime = endTime - startTime;
			logger.info("Total time in Manual Update: " + netTime);

			// CR-1.0::update Automation Status in DB...
			// updateAutomationStatus(requestId);
			logger.info("getHanaProfilerFinalList:: Automation Status got updated in DB ::");

			// CR-25.0:: Update Join Type manually...
			updateJoinTable(requestId);

			updateTableType(requestId);

			// CR-29.0:: Update CDS VIEW Info....
			updateCDSViewInfo(requestId);

			// updateInventoryData(requestId);

			// CR-52.0
			// updateUsageAnalysis(requestId);

			// updateInventoryUsage(requestId);

			// updateObjType(requestId);

			getListWithValue(requestId, isNAValueExists, session);

			long netTimeFetchingOutput = endTime - startTime;
			logger.info("Total time in fetching Final Output: " + netTimeFetchingOutput);
			refiningStatus = true;
		} catch (Exception e) {
			logger.error("Exception in get_List_with_HanaProfiler_Final_Sheet_Data method" + e.getStackTrace());
			refiningStatus = false;
		}
		return refiningStatus;

	}

	/**
	 * Update Inventory for object types View, Inde and Rept object types that
	 * are impacted.
	 * 
	 * @param requestId
	 */

	public void updateInventory(long requestId) {
		logger.info("Process Start ------ Update Inventory ");
		String inventoryUpdate = "INSERT INTO s4_inventory_list(OBJ_NAME,OBJ_NAME_TYPE,OBJ_TYPE,Used,REQUEST_ID, usageCount)  "
				+ "SELECT OBJ_NAME,OBJ_NAME_TYPE,OBJ_TYPE,Used,REQUEST_ID, Usage_Count FROM Impact_Obj_List where OBJ_TYPE in ('VIEW','INDE','REPT','IDOC','DTEL','PDTS','PDWS', 'CDAT', 'TABU', 'VARX', 'KES1') and REQUEST_ID="
				+ requestId;

		updateFrmTables(inventoryUpdate);
		logger.info("Process End -------- Inventory updated for VIEW , INDE and REPT object types ");
	}

	// US:05
	public void updateImpactObjType(long requestId) {

		// US:05 Impacted Object list tab CR for AADT-rohan.a.mehra

		// Getting data from HANA
		String ImpactedObjectListFrmHanaDR = "INSERT INTO Impact_Obj_List_Intermediate (OBJ_TYPE, OBJ_NAME, REQUEST_ID, Used, OBJ_NAME_TYPE, RICEF_CATEGORY, External_Namespace, RICEF_SUB_CATEGORY, READ_PROG) SELECT Object_Type, Obj_Name, REQUEST_ID, Used_Unused, OBJ_NAME_TYPE, RICEF_CATEGORY, External_Namespace, Ricef_Sub_Category, ReadProgram FROM final_output where Request_ID= "
				+ requestId;
		updateFrmTables(ImpactedObjectListFrmHanaDR);

		// Getting data from S4
		String ImpactedObjectListFrmS4DR = "INSERT INTO Impact_Obj_List_Intermediate (OBJ_TYPE, OBJ_NAME, REQUEST_ID, Used, OBJ_NAME_TYPE, RICEF_CATEGORY, External_Namespace, RICEF_SUB_CATEGORY, READ_PROG) SELECT TYPE, OBJ_NAME, REQUEST_ID, USED, OBJ_NAME_TYPE, RICEF_CATEGORY, External_Namespace,RICEF_SUB_CATEGORY, READ_PROG FROM S4_Final_Output where REQUEST_ID= "
				+ requestId;
		updateFrmTables(ImpactedObjectListFrmS4DR);

		// Getting data from AUCT
		String ImpactedObjectListFrmAuctDR = "INSERT INTO Impact_Obj_List_Intermediate (OBJ_TYPE, OBJ_NAME, REQUEST_ID, Used, OBJ_NAME_TYPE,RICEF_CATEGORY, External_Namespace, RICEF_SUB_CATEGORY, READ_PROG) SELECT TYPE, OBJ_NAME, REQUEST_ID, Used_Unused, OBJ_NAME_TYPE, RICEF_CATEGORY, External_Namespace,RICEF_SUB_CATEGORY, READ_PROG FROM Auct_Final_Output where REQUEST_ID= "
				+ requestId;
		updateFrmTables(ImpactedObjectListFrmAuctDR);

		// Getting data from OS MIGRATION
		String impactedObjectListFrmOSMigrationDR = "INSERT INTO Impact_Obj_List_Intermediate (OBJ_TYPE, OBJ_NAME, REQUEST_ID, Used, OBJ_NAME_TYPE, RICEF_CATEGORY,RICEF_SUB_CATEGORY, READ_PROG) SELECT OBJ_TYPE, OBJ_NAME, REQUEST_ID, USED, OBJ_TYPE_NAME, RICEF_CATEGORY,RICEF_SUB_CATEGORY, READ_PROGRAM  FROM OSMIGRATION_FINAL where REQUEST_ID = "
				+ requestId;
		updateFrmTables(impactedObjectListFrmOSMigrationDR);

		// Getting data from ODATA
		String ImpactedObjectListFrmOdataDR = "INSERT INTO Impact_Obj_List_Intermediate (OBJ_TYPE, OBJ_NAME,REQUEST_ID,Used,OBJ_NAME_TYPE, READ_PROG) SELECT OBJECT_TYPE, OBJ_NAME,REQUEST_ID,Used_Unused,OBJ_NAME_TYPE, READ_PROGRAM FROM Odata_Final_Output where REQUEST_ID= "
				+ requestId;
		updateFrmTables(ImpactedObjectListFrmOdataDR);

		// generate OBJECT_TYPE_NAME_READ_PROG combination of the objType ,
		// ObjName, and ReadProg
		String updateImpactedObjListIntermediate = "UPDATE Impact_Obj_List_Intermediate SET OBJECT_TYPE_NAME_READ_PROG = CONCAT(OBJ_TYPE,OBJ_NAME,READ_PROG) where REQUEST_ID="
				+ requestId;
		updateFrmTables(updateImpactedObjListIntermediate);

		String ImpactedObjectList = "INSERT INTO Impact_Obj_List (OBJ_NAME_TYPE, OBJ_TYPE, OBJ_NAME, REQUEST_ID, Used, RICEF_CATEGORY, External_Namespace,RICEF_SUB_CATEGORY, OBJECT_TYPE_NAME_READ_PROG) SELECT Distinct OBJ_NAME_TYPE, OBJ_TYPE, OBJ_NAME, REQUEST_ID, Used, RICEF_CATEGORY, External_Namespace,RICEF_SUB_CATEGORY, OBJECT_TYPE_NAME_READ_PROG FROM Impact_Obj_List_Intermediate where REQUEST_ID= "
				+ requestId + " group by OBJ_NAME_TYPE";
		updateFrmTables(ImpactedObjectList);

		// Updating hana col(DB_Impact) with X if present in hana detail report
		String ImpactedObjectListHanaUpdate = "update Impact_Obj_List Impact_Obj_List inner join final_output final_output on Impact_Obj_List.OBJ_NAME_TYPE=final_output.OBJ_NAME_TYPE set DB_Impact='X' where final_output.Request_ID= "
				+ requestId + " and Impact_Obj_List.REQUEST_ID= " + requestId;
		updateFrmTables(ImpactedObjectListHanaUpdate);

		// Updating S4 col with X if present in s4 detail report
		String ImpactedObjectListS4Update = "update Impact_Obj_List Impact_Obj_List inner join S4_Final_Output S4_Final_Output on Impact_Obj_List.OBJ_NAME_TYPE=S4_Final_Output.OBJ_NAME_TYPE set S4_Simplification='X' where S4_Final_Output.REQUEST_ID= "
				+ requestId + " and Impact_Obj_List.REQUEST_ID= " + requestId;
		updateFrmTables(ImpactedObjectListS4Update);

		// Updating AUCT col with X if present in AUCT detail report
		String ImpactedObjectListFrmAuctpdate = "update Impact_Obj_List Impact_Obj_List inner join Auct_Final_Output Auct_Final_Output on Impact_Obj_List.OBJ_NAME_TYPE=Auct_Final_Output.OBJ_NAME_TYPE set Errors_In_Existing_System='X' where Auct_Final_Output.REQUEST_ID= "
				+ requestId + " and Impact_Obj_List.REQUEST_ID= " + requestId;
		updateFrmTables(ImpactedObjectListFrmAuctpdate);

		// Updating Odata col with X if present in ODATA detail report
		String ImpactedObjectListOdataUpdate = "update Impact_Obj_List Impact_Obj_List inner join Odata_Final_Output Odata_Final_Output on Impact_Obj_List.OBJ_NAME_TYPE=Odata_Final_Output.OBJ_NAME_TYPE set Impact_Obj_List.Odata='X' where Odata_Final_Output.REQUEST_ID= "
				+ requestId + " and Impact_Obj_List.REQUEST_ID= " + requestId;
		updateFrmTables(ImpactedObjectListOdataUpdate);

		// Updating Odata col with X if present in OS Migration detail report
		String impactedObjectListOSMigrationUpdate = "update Impact_Obj_List Impact_Obj_List inner join OSMIGRATION_FINAL osmigration_final on Impact_Obj_List.OBJ_NAME_TYPE=osmigration_final.OBJ_TYPE_NAME set Impact_Obj_List.OS_Migration='X' where osmigration_final.REQUEST_ID = "
				+ requestId + " and Impact_Obj_List.REQUEST_ID = " + requestId;
		updateFrmTables(impactedObjectListOSMigrationUpdate);

		// Updating UsageCount from Usage Analysis
		String impactObjListUsageAnalysisUpdate = "update Impact_Obj_List Impact_Obj_List inner join Usage_Analysis usageAnalysis on Impact_Obj_List.OBJ_NAME_TYPE=usageAnalysis.objNameType set Impact_Obj_List.Usage_Count=usageAnalysis.usageCount where Impact_Obj_List.OBJ_TYPE not in ('AQQU') and usageAnalysis.requestID = "
				+ requestId + " and Impact_Obj_List.REQUEST_ID = " + requestId;
		updateFrmTables(impactObjListUsageAnalysisUpdate);

		// Updating UsageCount from Usage Analysis for AQQU
		String impactObjListUsageAnalysisUpdateAQQU = "update Impact_Obj_List Impact_Obj_List "
				+ "inner join (select objNameType,requestID,sum(usageCount) as tcount from Usage_Analysis where requestID="
				+ requestId + " group by objNameType) usageAnalysis "
				+ "on Impact_Obj_List.OBJ_NAME_TYPE=usageAnalysis.objNameType "
				+ "set Impact_Obj_List.Usage_Count=usageAnalysis.tcount, Impact_Obj_List.Used='Y'"
				+ "where Impact_Obj_List.OBJ_TYPE in ('AQQU') and usageAnalysis.requestID = " + requestId
				+ " and Impact_Obj_List.REQUEST_ID = " + requestId;
		updateFrmTables(impactObjListUsageAnalysisUpdateAQQU);

		// Updating Odata col with X if present in OS Migration detail report
		String impactedObjectListImpModUpdate = "update Impact_Obj_List Impact_Obj_List inner join S4_Inventory_List inv on Impact_Obj_List.OBJ_NAME_TYPE=inv.OBJ_NAME_TYPE set Impact_Obj_List.Impacted_Mod='X' where inv.REQUEST_ID = "
				+ requestId + " and Impact_Obj_List.REQUEST_ID = " + requestId + " and inv.Standard_Modification='X'";
		updateFrmTables(impactedObjectListImpModUpdate);

	}

	// *****************************Impacted_Scripts-----Logic*******************************************************
	public void clientFileProcessingBusinessLogicScripts(final long requestId, HttpServletRequest request,
			final String toolName, HttpSession session, List<ImpactedScripts> impactedScripts) throws Exception {
		logger.info("............Started Impacted_Scripts Processing .......");

		try {
			// Getting data from HANA
			String updateFrmHana = "UPDATE Impacted_Scripts a " + "INNER JOIN "
					+ "(SELECT Obj_Name, CASE WHEN remCat LIKE '%MANDATORY%' THEN 'MANDATORY' ELSE 'OPTIONAL' END AS remCategory "
					+ "FROM (SELECT Obj_Name, GROUP_CONCAT(DISTINCT Category) AS remCat FROM Final_Output "
					+ "WHERE Request_ID = " + requestId + " GROUP BY Obj_Name) sub1) b " + "ON a.OBJ_NAME = b.Obj_Name "
					+ "SET a.DB_Impact = 'X', a.REMEDIATION_CATEGORY = b.remCategory WHERE a.REQUEST_ID = " + requestId;
			updateFrmTables(updateFrmHana);

			// Getting data from S4
			String updateFrmS4 = "UPDATE Impacted_Scripts a " + "INNER JOIN "
					+ "(SELECT Obj_Name, CASE WHEN remCat LIKE '%MANDATORY%' THEN 'MANDATORY' ELSE 'OPTIONAL' END AS remCategory "
					+ "FROM (SELECT OBJ_NAME, GROUP_CONCAT(DISTINCT REMEDIATION_CATEGORY) AS remCat FROM S4_Final_Output "
					+ "WHERE REQUEST_ID = " + requestId + " GROUP BY OBJ_NAME) sub1) b " + "ON a.OBJ_NAME = b.OBJ_NAME "
					+ "SET a.S4_Simplification = 'X', "
					+ "a.REMEDIATION_CATEGORY = CASE WHEN a.REMEDIATION_CATEGORY = 'MANDATORY' THEN a.REMEDIATION_CATEGORY ELSE b.remCategory END "
					+ "WHERE a.REQUEST_ID = " + requestId;
			updateFrmTables(updateFrmS4);

			// Getting data from AUCT
			String updateFrmUpgrade = "UPDATE Impacted_Scripts a " + "INNER JOIN " + "Auct_Final_Output b "
					+ "ON a.OBJ_NAME = b.OBJ_NAME "
					+ "SET a.Existing_Errors = 'X', a.REMEDIATION_CATEGORY = 'MANDATORY' " + "WHERE a.REQUEST_ID = "
					+ requestId + " AND b.REQUEST_ID = " + requestId;
			updateFrmTables(updateFrmUpgrade);
		} catch (Exception e) {
			logger.error("Error while processing Impacted SAP Scripts : ", e);
			throw new Exception();
		}
	}

	public Map<String, ImpactedScripts_Intermediate> remediationCatForScripts(long requestId) {
		Map<String, ImpactedScripts_Intermediate> remediScriptMap = new HashMap<>();

		List<ImpactedScripts_Intermediate> impactedScriptsIntermediateList = getImpactedScriptsIntermediateForRequestId(
				requestId);

		for (ImpactedScripts_Intermediate scriptsList : impactedScriptsIntermediateList) {
			ImpactedScripts_Intermediate scriptsObj = null;

			if (scriptsList.getObjNameTypeStatus() != null) {
				if (remediScriptMap.containsKey(scriptsList.getObjNameTypeStatus())) {
					scriptsObj = remediScriptMap.get(scriptsList.getObjNameTypeStatus());

					if (scriptsObj.getRemidiCategory() != null
							&& "Mandatory".equalsIgnoreCase(scriptsObj.getRemidiCategory())
							&& !scriptsObj.getRemidiCategory().isEmpty()) {
						// DO nothing as we have the correct
						// value::::::::::::::::::::::::::::::::::::::::::::::::
					} else {
						if (scriptsObj.getRemidiCategory() != null
								&& scriptsObj.getRemidiCategory().equalsIgnoreCase("Mandatory")
								&& !scriptsObj.getRemidiCategory().isEmpty()) {

							remediScriptMap.put(scriptsObj.getObjNameTypeStatus(), scriptsObj);
						} else {
							scriptsObj.setRemidiCategory("Optional");
							remediScriptMap.put(scriptsObj.getObjNameTypeStatus(), scriptsObj);
						}
					}
				} else {
					if (scriptsList.getRemidiCategory() != null
							&& scriptsList.getRemidiCategory().equalsIgnoreCase("Mandatory")
							&& !scriptsList.getRemidiCategory().isEmpty()) {
						remediScriptMap.put(scriptsList.getObjNameTypeStatus(), scriptsList);
					} else {
						scriptsList.setRemidiCategory("Optional");
						remediScriptMap.put(scriptsList.getObjNameTypeStatus(), scriptsList);
					}

				}
			}
		}
		return remediScriptMap;
	}

	@SuppressWarnings("unchecked")
	private List<ImpactedScripts_Intermediate> getImpactedScriptsIntermediateForRequestId(long requestId) {

		final Session session = sessionFactory.openSession();
		try {
			final Criteria criteria = session.createCriteria(ImpactedScripts_Intermediate.class);
			criteria.add(Restrictions.eq("requestId", requestId));
			return criteria.list();
		} catch (Exception e) {
			logger.error("Error PopulatingFinalOutput getImpactedScriptsIntermediateForRequestId ", e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	public static String impactedScriptsFinalBatchInsertUpdate(
			Map<String, ImpactedScripts_Intermediate> remediationCatForScripts, long requestId, HttpSession session)
			throws SQLException {

		final String INSERT_SQL = "INSERT INTO Impacted_Scripts "
				+ "(OBJ_TYPE, OBJ_NAME, OBJ_NAME_TYPE, OBJ_NAME_TYPE_STATUS, READ_PROG, ACT_STATUS, REMEDIATION_CATEGORY, OPERCD, Existing_Errors, DB_Impact, S4_Simplification,EXTERNAL_NAMESPACE, REQUEST_ID) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {
			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;

				for (ImpactedScripts_Intermediate impactedScripts : remediationCatForScripts.values()) {
					stmt.setString(1, impactedScripts.getObjType());
					stmt.setString(2, impactedScripts.getObjName());
					stmt.setString(3, impactedScripts.getObjNameType());
					stmt.setString(4, impactedScripts.getObjNameTypeStatus());
					stmt.setString(5, impactedScripts.getReadProg());
					stmt.setString(6, impactedScripts.getActStaus());
					stmt.setString(7, impactedScripts.getRemidiCategory());
					stmt.setString(8, impactedScripts.getOpCode());
					stmt.setString(9, impactedScripts.getExistingErrors());
					stmt.setString(10, impactedScripts.getDbImpact());
					stmt.setString(11, impactedScripts.getS4Simplification());
					stmt.setString(12, impactedScripts.getExternalNamespace());
					stmt.setLong(13, impactedScripts.getRequestId());
					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}
				stmt.executeBatch();
				conn.commit();
				logger.info("Impacted_Scripts Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	private void updateInventoryUsage(long requestId) {
		String sql = "update s4_inventory_list il Left outer JOIN usage_analysis ua ON il.OBJ_NAME_TYPE=ua.OBJNAMETYPE set used='Y' where il.REQUEST_ID= "
				+ requestId + " and ua.requestID= " + requestId;
		updateFrmTables(sql);

	}

	private void updateInventoryData(long requestId) {
		// US-04
		// String frmLSMW="INSERT INTO S4_Inventory_List (OBJ_TYPE,
		// OBJ_NAME,OBJ_NAME_TYPE,REQUEST_ID) SELECT OBJ_TYPE,
		// OBJ_NAME,OBJ_NAME_TYPE,REQUEST_ID FROM LSMW where REQUEST_ID=
		// "+requestId;
		// DEF042
		// String frmUserExit="INSERT INTO S4_Inventory_List (OBJ_TYPE,
		// OBJ_NAME,OBJ_NAME_TYPE,REQUEST_ID) SELECT OBJ_TYPE,
		// OBJ_NAME,OBJ_NAME_TYPE,REQUEST_ID FROM USER_EXIT where REQUEST_ID=
		// "+requestId;
		// updateFrmTables(frmLSMW);
		// updateFrmTables(frmUserExit);

	}

	private void updateObjType(long requestId) {
		String updateFinalOutput = "update FINAL_OUTPUT set Object_Type= 'LSMW' where Object_Type = 'PROG' and Obj_Name like ('/1CADMC/SAP_LSMW_CONV_%')  and request_id= "
				+ requestId;
		// String updateInventory="update S4_Inventory_List set OBJ_TYPE= 'LSMW'
		// where
		// OBJ_TYPE = 'PROG' and OBJ_NAME like ('/%') and REQUEST_ID=
		// "+requestId;
		// String updateFinalOutputUserExit="update FINAL_OUTPUT s4FinalOutput
		// INNER
		// JOIN USER_EXIT userExit on s4FinalOutput.Obj_Name=userExit.OBJ_NAME
		// set
		// s4FinalOutput.Object_Type='USER Exit' where s4FinalOutput.REQUEST_ID=
		// "
		// +requestId;
		// String updateInventoryUserExit="update S4_Inventory_List
		// s4InventoryList
		// INNER JOIN USER_EXIT userExit on
		// s4InventoryList.OBJ_NAME=userExit.OBJ_NAME
		// set s4InventoryList.OBJ_TYPE='USER Exit' where
		// s4InventoryList.REQUEST_ID=
		// "+requestId;
		updateFrmTables(updateFinalOutput);
		// updateFrmTables(updateInventory);
		// updateFrmTables(updateFinalOutputUserExit);
		// updateFrmTables(updateInventoryUserExit);
	}

	private void updateFrmTables(String sql) {
		Session session = this.hibernateTemplate.getSessionFactory().openSession();
		Query query = session.createSQLQuery(sql);
		query.executeUpdate();

	}

	// CR-52.0
	private void updateUsageAnalysis(long requestId) {
		Session session = this.hibernateTemplate.getSessionFactory().openSession();

		String sql = "update final_output finalOutput inner join usage_analysis usge on finalOutput.OBJ_NAME_TYPE=usge.OBJNAMETYPE set Used_Unused='Used' where finalOutput.Request_ID= :requestId and usge.requestID= :requestID";

		Query query = session.createSQLQuery(sql);
		query.setParameter("requestId", requestId);
		query.setParameter("requestID", requestId);
		query.executeUpdate();

	}

	// CR-29.0
	private void updateCDSViewInfo(long requestId) {
		String tablesfrmHana = "";
		String tablefrmCDS = "";

		Session session = this.hibernateTemplate.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		final int batchSize = Hana_Profiler_Constant.JDBC_BATCH_SIZE;
		int count = 0;

		List<HanaProfile> hanaProfileList = getTableColForRequestID(requestId);
		logger.info("GOT HANAPRofiler List's TableCol:::" + hanaProfileList.size());

		List<CDSView> cdsViewList = getCDSViewForRequestId(requestId);
		logger.info("GOT CDSView List:::" + cdsViewList.size());

		if (null != hanaProfileList && null != cdsViewList) {
			for (HanaProfile hanaProfile : hanaProfileList) {
				String view = "";
				tablesfrmHana = hanaProfile.getTables();
				if (tablesfrmHana.trim().length() != 0 && tablesfrmHana != "") {
					for (CDSView cdsView : cdsViewList) {
						tablefrmCDS = cdsView.getTableName();
						if (tablefrmCDS.trim().length() != 0 && tablefrmCDS != ""
								&& tablesfrmHana.length() >= tablefrmCDS.length()) {
							String[] hanaTableArr = tablesfrmHana.split(",");
							String[] cdsTableArr = tablefrmCDS.split(",");
							if (hanaTableArr.length >= cdsTableArr.length) {
								int matchesTable = 0;
								for (int j = 0; j < hanaTableArr.length; j++) {
									for (int i = 0; i < cdsTableArr.length; i++) {
										if (hanaTableArr[j].equalsIgnoreCase(cdsTableArr[i])) {
											matchesTable++;
											logger.info("Inside Matching Codition:: CDS TABLE");
											if (matchesTable == hanaTableArr.length) {
												view = cdsView.getCdsView();
												logger.info("GOT VIEW AS HANA TABLE GET FINISHED::");
											}
											if (matchesTable == cdsTableArr.length) {
												view = cdsView.getCdsView();
												logger.info("GOT VIEW AS CDS TABLE GET FINISHED::");
											}
										}

									}

								}
							}
						}
					}
				}

				String info = hanaProfile.getInfo();

				if (info != null && info.trim() != "" && view != null && view.trim() != "")
					hanaProfile.setInfo(info + " CAN USE this CDS VIEW " + view);
				if ((view != null && view.trim() != "") && (info == null || info.trim() == ""))
					hanaProfile.setInfo(" CAN USE this CDS VIEW " + view);
				count++;
				session.saveOrUpdate(hanaProfile);
				if (count % batchSize == 0) {
					session.flush();
					session.clear();
				}

			}
		}
		tx.commit();
		session.flush();
		session.clear();
		if (session != null) {
			session.close();
		}

	}

	private List<CDSView> getCDSViewForRequestId(long requestId) {

		Session session = this.hibernateTemplate.getSessionFactory().openSession();

		try {
			final Criteria criteria = session.createCriteria(CDSView.class);
			criteria.add(Restrictions.eq("requestID", requestId));
			return criteria.list();

		} catch (Exception e) {
			logger.error("Error PopulatingFinalOutput getCDSViewForRequestId ", e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);

		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

	// CR-25.0 Update table type on the basis of table Col values.
	private void updateTableType(long requestId) {

		List<String> clusterTypeList = getClusterTypeList();
		List<String> poolTypeList = getPoolTypeList();

		String tablesCol = "";
		Session session = this.hibernateTemplate.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		final int batchSize = Hana_Profiler_Constant.JDBC_BATCH_SIZE;
		int count = 0;

		List<HanaProfile> hanaProfileList = getTableColForRequestID(requestId);
		if (null != hanaProfileList) {

			for (HanaProfile hanaprofile : hanaProfileList) {
				tablesCol = hanaprofile.getTables();
				if ((null != tablesCol) || (!tablesCol.trim().equals(""))) {

					String tableType = "";
					if (tablesCol.contains(",")) {
						String[] tableNameArr = tablesCol.split(",");
						for (int i = 0; i < tableNameArr.length; i++) {
							if (null != clusterTypeList && clusterTypeList.contains(tableNameArr[i])) {
								if (tableType.equals("")) {
									tableType = "CLUSTER";
								} else {
									tableType = tableType + "|" + "CLUSTER";
								}
							} else if (null != poolTypeList && poolTypeList.contains(tableNameArr[i])) {
								if (tableType.equals("")) {
									tableType = "POOL";
								} else {
									tableType = tableType + "|" + "POOL";
								}

							} else {
								if (tableType.equals("")) {
									tableType = "TRANSP";
								} else {
									tableType = tableType + "|" + "TRANSP";
								}
							}
						}
					} else {
						if (null != clusterTypeList && clusterTypeList.contains(tablesCol)) {
							tableType = "CLUSTER";
						} else if (null != poolTypeList && poolTypeList.contains(tablesCol)) {
							tableType = "POOL";
						} else {
							tableType = "TRANSP";
						}
					}
					hanaprofile.setTable_Type(tableType);
					count++;
					session.saveOrUpdate(hanaprofile);
					if (count % batchSize == 0) {
						session.flush();
						session.clear();
					}
				}

			}
		}
		tx.commit();
		session.flush();
		session.clear();
		if (session != null) {
			session.close();
		}
	}

	// CR-25.0 Getting the cluster type
	@SuppressWarnings("unchecked")
	private List<String> getClusterTypeList() {
		Session session = this.hibernateTemplate.getSessionFactory().openSession();
		try {
			Query query = session.createQuery("select cluster from TableType ");
			List<String> clusterList = (List<String>) query.list();
			return clusterList;
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			logger.trace(ex.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

	// CR-25.0 Getting the POOL type
	@SuppressWarnings("unchecked")
	private List<String> getPoolTypeList() {
		Session session = this.hibernateTemplate.getSessionFactory().openSession();
		try {
			Query query = session.createQuery("select pool from TableType ");
			List<String> poolList = (List<String>) query.list();
			return poolList;
		} catch (Exception ex) {
			logger.error(ex.getMessage());
			logger.trace(ex.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

	// CR-25.0 Get the data of tableCole From HanaProfile on the basis of
	// requestId
	@SuppressWarnings("unchecked")
	private List<HanaProfile> getTableColForRequestID(final long requestId) {
		logger.info("Inside getTableTypeForRequestID()");

		final List<HanaProfile> tables = (List<HanaProfile>) hibernateTemplate.execute(new HibernateCallback() {
			public Object doInHibernate(Session session) throws HibernateException {
				final Query query = session.createQuery("from HanaProfile where requestID=:requestID");
				query.setParameter("requestID", requestId);
				return query.list();
			}
		});
		return (List<HanaProfile>) (tables == null ? "" : tables);

	}

	// CR-25.0 Updating Join,JOInS,Table,WhereCondition.
	private void updateJoinTable(long requestId) {

		Session session = this.hibernateTemplate.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		final int batchSize = Hana_Profiler_Constant.JDBC_BATCH_SIZE;
		int count = 0;
		ScrollableResults hanaProfiler = session.createQuery("FROM HanaProfile where request_id=" + requestId)
				.setCacheMode(CacheMode.IGNORE).scroll(ScrollMode.FORWARD_ONLY);

		while (hanaProfiler.next()) {

			String specialCharacters = "[" + "-/@#!*$%^&.'_+={}()" + "]+";
			HanaProfile hanaProfile = (HanaProfile) hanaProfiler.get(0);
			String code = hanaProfile.getCode().trim();
			String joinType = "";
			String joinS = "";
			String tables = "";
			String whereCondition = "";
			if (!code.isEmpty() && null != code && "" != code) {
				code = code.toUpperCase();
				if (code.startsWith("SELECT")) {
					if (code.contains(" INNER JOIN ")) {
						joinS = "YES";
						joinType = "INNER";
					}
					if (code.contains(" LEFT OUTER JOIN ")) {
						joinS = "YES";
						if (!joinType.trim().equals("") && null != joinType && !joinType.trim().isEmpty())
							joinType = joinType + " | " + "LEFT OUTER";
						else
							joinType = "LEFT OUTER";
					}
					if (code.contains(" RIGHT OUTER JOIN ") && null != joinType && !joinType.trim().isEmpty()) {
						joinS = "YES";
						if (!joinType.trim().equals("") && null != joinType && !joinType.trim().isEmpty())
							joinType = joinType + " | " + "RIGHT OUTER";
						else
							joinType = "RIGHT OUTER";
					}
					if ((code.contains(" JOIN ") && (joinType.trim().equals("")) || null == joinType)) {
						joinS = "YES";
						if (!joinType.trim().equals("") && null != joinType && !joinType.trim().isEmpty())
							joinType = joinType + " | " + "INNER";
						else
							joinType = "INNER";
					}
					if (code.contains(" FROM ")) {
						if (null == joinType || joinType.trim().equals("")) {

							String[] codeArr = code.split(" FROM ");
							codeArr = codeArr[1].split("\\s");
							for (String tableName : codeArr) {
								if (!tableName.matches(specialCharacters)) {
									if (!tableName.trim().equals("")) {
										tables = tableName;
										break;
									}
								}
							}

						} else {
							String[] codeArr = code.split(" FROM ");
							String[] joinSplitArr = codeArr[1].split("JOIN ");
							for (int i = 0; i < joinSplitArr.length; i++) {
								String[] joinSplit = joinSplitArr[i].split("\\s");
								for (String tableName : joinSplit) {
									if (!tableName.matches(specialCharacters)) {
										if (!tableName.trim().equals("")) {
											if (!tables.trim().equals(""))
												tables = tables + "," + tableName;
											else
												tables = tableName;
											break;
										}
									}
								}
							}
						}
					}
					if (code.contains(" WHERE ")) {
						String[] codeArr = code.split("WHERE ");
						whereCondition = ("WHERE" + " " + codeArr[1].trim());
					}
				}
			}
			count++;
			hanaProfile.setJoins(joinS);
			hanaProfile.setJoin_Type(joinType);
			hanaProfile.setTables(tables);
			hanaProfile.setWhere_Condition(whereCondition);

			session.saveOrUpdate(hanaProfile);
			if (count % batchSize == 0) {
				session.flush();
				session.clear();
			}
		}
		tx.commit();
		session.flush();
		session.clear();
		if (session != null) {
			session.close();
		}

	}

	/*
	 * //CR-1.0:col25 updating automation_status in DB.... //CR-32.0: Adding
	 * operation to update automation status private void
	 * updateAutomationStatus(final Long requestId) {
	 * 
	 * Session session=this.hibernateTemplate.getSessionFactory().openSession();
	 * Transaction tx=session.beginTransaction(); final int batchSize =
	 * Hana_Profiler_Constant.JDBC_BATCH_SIZE; int count=0;
	 * 
	 * ScrollableResults hanaprofiler =
	 * session.createQuery("FROM HanaProfile where request_id="+
	 * requestId).setCacheMode(CacheMode.IGNORE).scroll(ScrollMode.FORWARD_ONLY)
	 * ;
	 * 
	 * while ( hanaprofiler.next() ) { HanaProfile hanaProfile = (HanaProfile)
	 * hanaprofiler.get(0); String operation=hanaProfile.getOpertaion().trim();
	 * if( !operation.isEmpty() && null != operation && "" != operation){
	 * switch(operation){ case "DDIC FUNCTION MODULE CALL":
	 * hanaProfile.setAutomation_status("Yes"); break; case "DB HINTS USED":
	 * hanaProfile.setAutomation_status("Yes"); break; case
	 * "Pool/Cluster Table": hanaProfile.setAutomation_status("Yes"); break;
	 * case "BYPASS TABLE BUFFER": hanaProfile.setAutomation_status("Yes");
	 * break; case "NO INITIAL CHECK - FOR ALL ENTRIES":
	 * hanaProfile.setAutomation_status("Yes"); break; case
	 * "READ STATEMENT WITH BINARY AND WITHOUT SORTING":
	 * hanaProfile.setAutomation_status("Yes"); break; case
	 * "DELETE ADJACENT DUPLICATES IS USED WITHOUT SORTING":
	 * hanaProfile.setAutomation_status("Yes"); break; case
	 * "Read Table itab ... INDEX x with unsorted itab":
	 * hanaProfile.setAutomation_status("Yes"); break; case
	 * "Modify itab INDEX I with unsorted itab":
	 * hanaProfile.setAutomation_status("Yes"); break; case
	 * "DELETE itab INDEX I with unsorted itab":
	 * hanaProfile.setAutomation_status("Yes"); break; case
	 * "LOOP AT itab ... FROM from TO to with unsorted itab":
	 * hanaProfile.setAutomation_status("Yes"); break; case
	 * "DELETE itab FROM from TO to with unsorted itab":
	 * hanaProfile.setAutomation_status("Yes"); break; case
	 * "Control statement inside loop (Only when loop is using internal table which is not sorted)"
	 * : hanaProfile.setAutomation_status("Yes"); break; case
	 * "UNSORTED INTERNAL TABLE ACCESSED WITH INDEX":
	 * hanaProfile.setAutomation_status("Yes"); break; case
	 * "Select Single without key fields":
	 * hanaProfile.setAutomation_status("Yes"); break; case "NATIVE SQL CALL":
	 * hanaProfile.setAutomation_status("No"); break; case
	 * "USAGE OF SORT - REPLACE BY ORDER BY":
	 * hanaProfile.setAutomation_status("No"); break; case "ADBC USAGE":
	 * hanaProfile.setAutomation_status("No"); break; case
	 * "SELECT WITHOUT WHERE CLAUSE": hanaProfile.setAutomation_status("No");
	 * break; case "Nested Loops": hanaProfile.setAutomation_status("No");
	 * break; case "SELECT-ENDSELECT USED":
	 * hanaProfile.setAutomation_status("No"); break; case "SELECT SINGLE *":
	 * hanaProfile.setAutomation_status("No"); break; case "SELECT *":
	 * hanaProfile.setAutomation_status("No"); break; case
	 * "Select With Field(S)": hanaProfile.setAutomation_status("No"); break;
	 * case "Repeated Database Hits On Table":
	 * hanaProfile.setAutomation_status("No"); break; case
	 * "JOINS ON TABLES IN SELECT STATEMENTS":
	 * hanaProfile.setAutomation_status("No"); break; case
	 * "For All Entries used": hanaProfile.setAutomation_status("No"); break;
	 * case "BAPI IN LOOP": hanaProfile.setAutomation_status("No"); break; case
	 * "FM IN LOOP": hanaProfile.setAutomation_status("No"); break; case
	 * "FM USED FOR CURRENCY CONVERSION":
	 * hanaProfile.setAutomation_status("No"); break; case
	 * "AGGREGATION STATEMENT COLLECT": hanaProfile.setAutomation_status("No");
	 * break; case "CONTROL STATEMENT INSIDE LOOP":
	 * hanaProfile.setAutomation_status("No"); break; case
	 * "ARRAY OPERATION UPDATE WITHIN A LOOP":
	 * hanaProfile.setAutomation_status("No"); break; case
	 * "ARRAY OPERATION INSERT WITHIN A LOOP":
	 * hanaProfile.setAutomation_status("No"); break; case
	 * "ARRAY OPERATION MODIFY WITHIN A LOOP":
	 * hanaProfile.setAutomation_status("No"); break; case
	 * "ARRAY OPERATION DELETE WITHIN A LOOP":
	 * hanaProfile.setAutomation_status("No"); break; case "CHECK/EXIT IN LOOP":
	 * hanaProfile.setAutomation_status("No"); break; case
	 * "LOGICAL DATABASE USED IN AN OBJECT":
	 * hanaProfile.setAutomation_status("No"); break; case
	 * "NEGATIVE OPERATION IN WHERE CLAUSE":
	 * hanaProfile.setAutomation_status("No"); break; case "FAE & JOIN":
	 * hanaProfile.setAutomation_status("No"); break; case
	 * "TABLE SIZE CATEGORY": hanaProfile.setAutomation_status("No"); break;
	 * case "DB operations on Table pool & Table Cluster":
	 * hanaProfile.setAutomation_status("No"); break; case
	 * "Delete statement for result of select found":
	 * hanaProfile.setAutomation_status("No"); break; }count++;
	 * session.saveOrUpdate(hanaProfile); if (count % batchSize == 0) {
	 * session.flush(); session.clear(); } } }
	 * 
	 * tx.commit(); session.flush(); session.clear(); if (session != null) {
	 * session.close(); }
	 * 
	 * updateAutomationStatForOpCode(requestId); }
	 */

	// CR-1.0:col25 updating automation_status for Operation code 19 in DB
	// according
	// to the sel_Line....
	private void updateAutomationStatForOpCode(Long requestId) {
		List<Integer> selLineList = getSelLineList(requestId);

		Session session = this.hibernateTemplate.getSessionFactory().openSession();
		logger.info("GOING TO UPDATE WITH IN CLAUSE SELLINE LIST::::::");

		if (null != selLineList && !selLineList.isEmpty()) {
			/*
			 * Iterator<Integer> selLineIterator=selLineList.iterator();
			 * while(selLineIterator.hasNext()){
			 */
			Transaction tx = session.beginTransaction();
			/* int selLine=(int)selLineIterator.next(); */
			Query query = session.createQuery(
					"update HanaProfile set automation_status=:automation_status where sel_Line in (:sel_line) and operation_code=:operationCode and Opertaion=:operation and requestID=:requestID");
			query.setParameter("automation_status", "No");
			query.setParameterList("sel_line", selLineList);
			query.setParameter("operationCode", Hana_Profiler_Constant.op_Code_19);
			query.setParameter("operation",
					"Control statement inside loop (Only when loop is using internal table which is not sorted)");
			query.setParameter("requestID", requestId);
			query.executeUpdate();
			tx.commit();
		}
		/* } */

		session.close();

	}

	// CR-1.0:col25 getting all operations for the given requestId ....
	@SuppressWarnings("unchecked")
	private List<String> getOperartionsForRequestId(final Long requestId) {
		logger.info("Inside getOperartionsForRequestId()");

		final List<String> operations = (List<String>) hibernateTemplate.execute(new HibernateCallback() {
			public Object doInHibernate(Session session) throws HibernateException {
				final Query query = session.createQuery("Select Opertaion from HanaProfile where requestID=:requestID");
				query.setParameter("requestID", requestId);
				return query.list();
			}
		});
		return operations;

	}

	// CR-1.0:col25 return list of selLine for which automation_status will be
	// updated for op_code 19
	private List<Integer> getSelLineList(final Long requestId) {
		// CR-1.0:get SEL_LINE for operation_code=19
		List<Integer> selLineList = getSelLineForOpCode(requestId);
		logger.info("getSelLineList():: selLineList::" + selLineList.size());

		// CR-1.0:get JoinS for operation code=21 & Line_No.=Sel_Line
		List<Integer> selLineForStatus = getSelLineForJoinS(requestId, selLineList);
		logger.info("getSelLineList():: selLineForStatus::" + selLineForStatus.size());
		return selLineForStatus;
	}

	// CR-1.0:get sel_Line list for operation code=21 & Line_No.=Sel_Line
	@SuppressWarnings("unchecked")
	private List<Integer> getSelLineForJoinS(Long requestId, List<Integer> selLineList) {
		logger.info("Inside getJoinSForSelLine()");
		List<Integer> newSelLineList = new ArrayList<Integer>();
		Session session = this.hibernateTemplate.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		logger.info("Begin Transaction in getJoinS");

		if (CollectionUtils.isNotEmpty(selLineList)) {
			/*
			 * Iterator<Integer> selLineIterator=selLineList.iterator();
			 * while(selLineIterator.hasNext()){
			 * 
			 * int selLine=(int)selLineIterator.next();
			 */

			Query query = session.createQuery(
					"SELECT Line_Number FROM HanaProfile where Line_Number in (:selLine) and operation_code=:operationCode and requestID=:requestID and Joins=:Joins");
			query.setParameterList("selLine", selLineList);
			query.setParameter("operationCode", Hana_Profiler_Constant.op_Code_21);
			query.setParameter("requestID", requestId);
			query.setParameter("Joins", "YES");
			newSelLineList = query.list();
			/*
			 * if(!(query.list().isEmpty())){ newSelLineList.add(selLine); }
			 */

		}
		/* } */
		/*
		 * tx.commit(); session.close();
		 */
		return newSelLineList;
	}

	// CR-1.0:get SEL_LINE for operation_code=19
	@SuppressWarnings("unchecked")
	private List<Integer> getSelLineForOpCode(final Long requestId) {
		logger.info("inside getSelLineForOpCode");
		final List<Integer> selLine = (List<Integer>) hibernateTemplate.execute(new HibernateCallback() {
			public Object doInHibernate(Session session) throws HibernateException {
				final Query query = session.createQuery(
						"SELECT sel_Line FROM HanaProfile where operation_code=:operationCode and sel_Line!=0 and requestID=:requestID");
				query.setParameter("operationCode", Hana_Profiler_Constant.op_Code_19);
				query.setParameter("requestID", requestId);
				return query.list();
			}
		});

		return selLine;
	}

	// Op-code 45 & 46 is required so commenting the refining for op-code 45 &
	// 46.
	/*
	 * @SuppressWarnings({ "unchecked", "rawtypes" }) private void
	 * refineLoopColumn(final Long requestId) {
	 * logger.info("Steps For refineLoopColumn"); final int count = (int)
	 * hibernateTemplate.execute(new HibernateCallback() { public Object
	 * doInHibernate(Session session) throws HibernateException { final Query
	 * query = session.createQuery(
	 * "delete from HanaProfile where (operation_code=:operationCode or operation_code=:operationCode1) and (loop = ' ' and requestID=:requestID)"
	 * ); query.setParameter("operationCode",
	 * Hana_Profiler_Constant.op_Code_45); query.setParameter("operationCode1",
	 * Hana_Profiler_Constant.op_Code_46); query.setParameter("requestID",
	 * requestId); return query.executeUpdate(); }
	 * 
	 * }); logger.debug("count value...." + count);
	 * 
	 * }
	 */

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void refineOP99(final Long requestId) {
		final int count = (int) hibernateTemplate.execute(new HibernateCallback() {
			public Object doInHibernate(Session session) throws HibernateException {
				final Query query = session.createQuery(
						"delete from HanaProfile where operation_code in (:operationCode) and requestID = :requestID");
				query.setParameterList("operationCode",
						new String[] { Hana_Profiler_Constant.op_Code_99, Hana_Profiler_Constant.op_Code_20,
								Hana_Profiler_Constant.op_Code_21, Hana_Profiler_Constant.op_Code_73 });

				query.setParameter("requestID", requestId);
				return query.executeUpdate();
			}
		});
		logger.info("count value op_code99...." + count);

	}

	private void refineImpactValue(final Long requestId, HttpSession session) throws SQLException {
		List<HanaProfile> profilerlist = null;
		logger.info("Steps For refineImpactValue");
		// profilerlist = GetList(requestId);
		// CR-2.0
		String hql = "select h from HanaProfile h where h.requestID=:requestID and impact not in('HIGH','LOW','MEDIUM','VERY HIGH','VERYHIGH','NO IMPACT')";
		profilerlist = select(hql, requestId);
		if (CollectionUtils.isNotEmpty(profilerlist)) {
			String impact = null;
			String[] impactSplit = null;
			String newImpactValue = null;
			String levelchar;
			int commaLastIndex;

			for (final HanaProfile hanaProfile : profilerlist) {
				int levelval = 0;
				int countIF = 0;
				int leastval = 10;// to set least value among the condition
				int level = 0; // we got
				String leastvalChar = null;
				int greatestval = 0;// to set greatest value among the
				// condition we got
				String greatestvalChar = null;
				String levelSign = null;

				level = hanaProfile.getLevels();
				impact = hanaProfile.getImpact();
				if (StringUtils.isNotBlank(impact)) {
					impact = impact.replace('-', ',');
					impact = impact.replaceAll("\\s", StringUtils.EMPTY);
					impact = impact.replaceAll(Hana_Profiler_Constant.QUOTES, "");
					impactSplit = impact.split(Hana_Profiler_Constant.SEMI_COLON_SEPERATOR);
					if (impactSplit.length <= 1) {
						newImpactValue = impactSplit[0];
					} else {
						for (String impactSplitValue : impactSplit) {
							commaLastIndex = impactSplitValue.lastIndexOf(Hana_Profiler_Constant.COMMA_SEPERATOR);
							levelchar = impactSplitValue.substring(commaLastIndex + 1).trim();
							levelval = Integer.parseInt(impactSplitValue.substring(commaLastIndex - 1, commaLastIndex));
							levelSign = impactSplitValue.substring(commaLastIndex - 2, commaLastIndex - 1);
							logger.debug("Level value from QueryResult in Impact column:-  " + levelval);

							if (Hana_Profiler_Constant.GREATER_THAN_SIGN.equals(levelSign)) {

								if (level > levelval) {
									countIF++;
									newImpactValue = levelchar;
									break;
								}
								levelval = levelval + 1;
							} else if (Hana_Profiler_Constant.LESS_THAN_SIGN.equals(levelSign)) {

								if (level < levelval) {
									countIF++;
									newImpactValue = levelchar;
									break;
								}
								levelval = levelval - 1;
							}

							if (leastval >= levelval) {
								leastval = levelval;// to set least value
								// among
								// the condition we got
								leastvalChar = levelchar;
							}
							if (greatestval <= levelval) {
								greatestval = levelval;// to set least value
								// among the
								// condition
								// we got
								greatestvalChar = levelchar;
							}
							if (level == levelval) {
								countIF++;
								newImpactValue = levelchar;
								break;
							}
						}

						if (countIF == 0) {

							if (level < leastval) {
								if (Hana_Profiler_Constant.LOW.equalsIgnoreCase(leastvalChar)
										|| Hana_Profiler_Constant.MEDIUM.equalsIgnoreCase(leastvalChar)) {
									newImpactValue = Hana_Profiler_Constant.LOW;
								} else if (Hana_Profiler_Constant.HIGH.equalsIgnoreCase(leastvalChar)) {
									newImpactValue = Hana_Profiler_Constant.MEDIUM;
								} else if (Hana_Profiler_Constant.VERY_HIGH.equalsIgnoreCase(leastvalChar)) {
									newImpactValue = Hana_Profiler_Constant.HIGH;
								}
							} else if (level > greatestval) {
								// TODO : should be greatestvalchar
								if (Hana_Profiler_Constant.LOW.equalsIgnoreCase(leastvalChar)) {
									newImpactValue = Hana_Profiler_Constant.MEDIUM;
								}

								else if (Hana_Profiler_Constant.MEDIUM.equalsIgnoreCase(leastvalChar)) {
									newImpactValue = Hana_Profiler_Constant.HIGH;
								} else if (Hana_Profiler_Constant.HIGH.equalsIgnoreCase(leastvalChar)) {
									newImpactValue = Hana_Profiler_Constant.VERY_HIGH;
								}

							}

						}
					}
					hanaProfile.setImpact(newImpactValue);
					// updateListWithLoopColumn(hanaProfile);

				}
			}
			// populateHanaTable.populateDataList(profilerlist);
			RefineImpactBatchInsertUpdate(profilerlist, session);

		}
	}

	public String RefineImpactBatchInsertUpdate(List<HanaProfile> profilerlist, HttpSession session)
			throws SQLException {

		final String UPDATE_SQL = "UPDATE FINAL_OUTPUT set impact=? where Request_ID=?";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);

			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(UPDATE_SQL);
				int batch = 1;

				for (HanaProfile hpro : profilerlist) {
					stmt.setString(26, hpro.getImpact());
					stmt.setLong(31, hpro.getRequestID());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("Final batch executed successfully");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	@SuppressWarnings("unchecked")
	private void refineSubType(final long requestId) {
		logger.info("Steps For refineSubType");
		logger.info("Open the Session From SessionFactory");
		try {
			hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {
					final StringBuffer queryString = new StringBuffer();
					queryString.append("update HanaProfile h set Sub_Type");
					queryString.append(" = ");
					queryString.append("(select case when subc = '");
					queryString.append(Hana_Profiler_Constant.Include);
					queryString.append("' then '");
					queryString.append(Hana_Profiler_Constant.IP);
					queryString.append("' when subc='");
					queryString.append(Hana_Profiler_Constant.Executable);
					queryString.append("' then '");
					queryString.append(Hana_Profiler_Constant.EP);
					queryString.append("' when subc='");
					queryString.append(Hana_Profiler_Constant.Subroutine);
					queryString.append("' then '");
					queryString.append(Hana_Profiler_Constant.SP);
					queryString.append("' when subc='");
					queryString.append(Hana_Profiler_Constant.Module);
					queryString.append("' then '");
					queryString.append(Hana_Profiler_Constant.MP);
					queryString.append("' when subc='");
					queryString.append(Hana_Profiler_Constant.Function);
					queryString.append("' then '");
					queryString.append(Hana_Profiler_Constant.FG);
					queryString.append("' else '");
					queryString.append(Hana_Profiler_Constant.Sub_Type_Val);
					queryString.append("' end from TRDR_DATA where requestID=h.requestID and name=h.Obj_Name)");

					queryString.append(" where h.requestID=:requestId and h.Sub_Type=:subTypeVal");
					final Query query = session.createQuery(queryString.toString());
					query.setParameter("requestId", requestId);
					query.setParameter("subTypeVal", Hana_Profiler_Constant.Sub_Type_Val);
					return query.executeUpdate();
				}

			});
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	/**
	 * @author j.patidar * @see
	 *         com.act.displaygrid.dao.JqGridDaoIntf#delete(com.act.
	 *         displaygrid.model.HanaProfile)
	 * @param profilemodel
	 *            delete the selected records
	 */

	private List<HanaProfilerStepOutput> getHanaProfilerOutputList(final Long requestId) {

		final Session session = sessionFactory.openSession();
		try {
			final Criteria criteria = session.createCriteria(HanaProfilerStepOutput.class);
			criteria.add(Restrictions.eq("requestID", requestId));
			criteria.addOrder(Order.asc("joinID"));
			return criteria.list();

		} catch (Exception e) {
			logger.error("Error PopulatingFinalOutput getHanaProfilerOutputList ", e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);

		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

	private List<HanaProfile> getHanaProfileList(final Long requestId, final Set<Integer> joinIdSet) {
		final Session session = sessionFactory.openSession();
		try {
			final Criteria criteria = session.createCriteria(HanaProfile.class);
			criteria.add(Restrictions.eq("requestID", requestId));
			criteria.add(Restrictions.in("joinID", joinIdSet));
			criteria.addOrder(Order.asc("joinID"));
			return criteria.list();

		} catch (Exception e) {
			logger.error("Error PopulatingFinalOutput getHanaProfileList  ", e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);

		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

	private Map<Integer, HanaProfilerStepOutput> convertHanaProfilerListToMap(
			final List<HanaProfilerStepOutput> hanaProfilerStepOutputList) {
		final Map<Integer, HanaProfilerStepOutput> finalMap = new HashMap<Integer, HanaProfilerStepOutput>();
		for (HanaProfilerStepOutput hanaProfilerStepOutput : hanaProfilerStepOutputList) {
			finalMap.put(hanaProfilerStepOutput.getJoinID(), hanaProfilerStepOutput);
		}
		return finalMap;
	}

	private void manualUpdate(final Long requestId) {

		final List<HanaProfilerStepOutput> hanaProfilerStepOutputList = getHanaProfilerOutputList(requestId);
		if (CollectionUtils.isNotEmpty(hanaProfilerStepOutputList)) {
			HanaProfilerStepOutput hanaProfilerStepOutput;
			final Map<Integer, HanaProfilerStepOutput> hanaProfilerStepOutputMap = convertHanaProfilerListToMap(
					hanaProfilerStepOutputList);
			final List<HanaProfile> hanaProfileList = getHanaProfileList(requestId, hanaProfilerStepOutputMap.keySet());
			if (CollectionUtils.isNotEmpty(hanaProfileList)) {
				String dialogSteps;
				for (final HanaProfile hanaProfile : hanaProfileList) {
					hanaProfilerStepOutput = hanaProfilerStepOutputMap.get(hanaProfile.getJoinID());
					dialogSteps = (String.valueOf(hanaProfilerStepOutput.getDialogSteps()).replaceAll("\\.0*$", ""));
					hanaProfile.setObj_Name(HANAUtility.getBlankvalueIfNull(hanaProfilerStepOutput.getObjName()));
					// hanaProfile.setDialog_Steps(HANAUtility.getBlankvalueIfNull(dialogSteps));
					hanaProfile.setOpertaion(HANAUtility.getBlankvalueIfNull(hanaProfilerStepOutput.getOperation()));
					hanaProfile.setCategory(HANAUtility.getBlankvalueIfNull(hanaProfilerStepOutput.getActST()));
					hanaProfile
							.setSubcategory(HANAUtility.getBlankvalueIfNull(hanaProfilerStepOutput.getSubCategory()));
					hanaProfile.setImpact(
							HANAUtility.getBlankvalueIfNull(hanaProfilerStepOutput.getImpact()).toUpperCase());
					hanaProfile.setDB(
							HANAUtility.getBlankvalueIfNull((String.valueOf(hanaProfilerStepOutput.getDbPercent()))));
					hanaProfile.setChange(HANAUtility
							.getBlankvalueIfNull((String.valueOf(hanaProfilerStepOutput.getChangePercent()))));
					hanaProfile.setOperation_code(
							HANAUtility.getBlankvalueIfNull(hanaProfilerStepOutput.getOperationCode()));
					hanaProfile.setObject_Type(
							HANAUtility.getBlankvalueIfNull((String) hanaProfilerStepOutput.getObjectType()));
					hanaProfile.setUsed_Unused(
							HANAUtility.getBlankvalueIfNull((String) hanaProfilerStepOutput.getUsedUnused()));

					// CR-13.0 adding data of High level Description
					hanaProfile.setHigh_lvl_desc(
							HANAUtility.getBlankvalueIfNull(hanaProfilerStepOutput.getHigh_lvl_desc()));

					// CR-28.0 adding Total lines Scanned
					hanaProfile.setTotalLineScanned(
							HANAUtility.getBlankvalueIfNull(hanaProfilerStepOutput.getTotalLineScanned()));

					// CR-34.0 adding Total lines Scanned
					hanaProfile.setLine_Number(hanaProfilerStepOutput.getLineNo());

					// CR-52.0
					hanaProfile.setObjNameType(hanaProfilerStepOutput.getObjNameType());

				}

				populateHanaTable.populateDataList(hanaProfileList);
			}
		}

	}

	private void addTRDRList(final Long requestId, final String clientName, HttpSession session) throws Exception {
		logger.info("Steps for Add the ExcelSheet Data in DataBase");
		final File file = new File(HANAUtility.getFilePath(clientName, requestId));
		try {
			final File[] fi = file.listFiles();
			String fileName;
			for (final File trdrFile : fi) {
				fileName = trdrFile.getName();
				if (fileName.toLowerCase().indexOf(ST03HanaConstant.TRDIR_CONSTANT) != -1) {
					st03ReaderXlsx.addTRDIRData(trdrFile.getCanonicalPath(), requestId, session);
				}
			}
		} catch (IOException e) {
			logger.error(e.getMessage());
		}
	}

	/**
	 * @author j.patidar * @see
	 *         com.act.displaygrid.dao.JqGridDaoIntf#delete_TR_DIR_Records
	 *         () delete the all temp TR/DIR table records
	 */
	// @Override
	@Transactional(readOnly = false)
	private void delete_TR_DIR_Records(final long requestId) throws Exception {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		final Session session = sessionFactory.openSession();
		try {
			final String hql = "delete  from TRDR_DATA where requestID=:requestID";
			final Query query = session.createQuery(hql);
			query.setParameter("requestID", requestId);
			query.executeUpdate();
		} catch (Exception e) {
			logger.error(e.getMessage());
			logger.trace(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

	/**
	 * @author rohan.a.mehra
	 * 
	 */
	public List<ImpactedObjList_Download> GetImpactedObjectList(Long REQUEST_ID, final int from, final int limit) {
		logger.info("Successfully get Sission From SessionFactory");
		Session session = this.hibernateTemplate.getSessionFactory().openSession();
		logger.info("create Criteria for get all records from DB");
		Criteria criteria = session.createCriteria(ImpactedObjList_Download.class);
		ProjectionList projection = Projections.projectionList();
		projection.add(Projections.property("OBJ_TYPE"), "OBJ_TYPE");
		projection.add(Projections.property("OBJ_NAME"), "OBJ_NAME");
		projection.add(Projections.property("Used"), "Used");
		projection.add(Projections.property("Errors_In_Existing_System"), "Errors_In_Existing_System");
		projection.add(Projections.property("DB_Impact"), "DB_Impact");
		projection.add(Projections.property("S4_Simplification"), "S4_Simplification");
		projection.add(Projections.property("Odata"), "Odata");
		projection.add(Projections.property("osMigration"), "osMigration");
		projection.add(Projections.property("usageCount"), "usageCount");
		projection.add(Projections.property("impactedMod"), "impactedMod");
		projection.add(Projections.property("ricefCategory"), "ricefCategory");
		projection.add(Projections.property("extNamespace"), "extNamespace");
		projection.add(Projections.property("ricefSubCategory"), "ricefSubCategory");

		if (limit != 0) {
			criteria.setMaxResults(limit);
		}
		if (from != 0) {
			criteria.setFirstResult(from);
		}
		criteria.add(Restrictions.eq("REQUEST_ID", REQUEST_ID));
		criteria.setProjection(Projections.distinct(projection));
		criteria.setResultTransformer(Transformers.aliasToBean(ImpactedObjList_Download.class));
		List<ImpactedObjList_Download> l = criteria.list();
		logger.info("List Size " + l.size());

		session.close();

		return l;
	}

	/**
	 * @author rohan.a.mehra
	 * 
	 */
	public List<AuctFinalOutput_Download> writeAuctFinalOutputSheet(Long REQUEST_ID, int from, int limit) {
		logger.info("Successfully get Sission From SessionFactory");
		Session session = this.hibernateTemplate.getSessionFactory().openSession();
		logger.info("create Criteria for get all records from DB");
		Criteria criteria = session.createCriteria(AuctFinalOutput_Download.class);
		ProjectionList projection = Projections.projectionList();
		projection.add(Projections.property("TYPE"), "TYPE");
		projection.add(Projections.property("OBJ_NAME"), "OBJ_NAME");
		projection.add(Projections.property("SUB_TYPE"), "SUB_TYPE");
		projection.add(Projections.property("READ_PROG"), "READ_PROG");
		projection.add(Projections.property("OBJ_PACKAGE"), "OBJ_PACKAGE");
		projection.add(Projections.property("LINE_NUMBER"), "LINE_NUMBER");
		projection.add(Projections.property("INFO"), "INFO");
		projection.add(Projections.property("AUTOMATION_STATUS"), "AUTOMATION_STATUS");
		projection.add(Projections.property("OPCODE"), "OPCODE");
		projection.add(Projections.property("Used_Unused"), "Used_Unused");
		projection.add(Projections.property("ricefCategory"), "ricefCategory");
		projection.add(Projections.property("extNamespace"), "extNamespace");
		projection.add(Projections.property("ricefSubCategory"), "ricefSubCategory");
		projection.add(Projections.property("CODE"), "CODE");

		if (limit != 0) {
			criteria.setMaxResults(limit);
		}
		if (from != 0) {
			criteria.setFirstResult(from);
		}
		criteria.add(Restrictions.eq("REQUEST_ID", REQUEST_ID));
		criteria.setProjection(Projections.distinct(projection));
		criteria.setResultTransformer(Transformers.aliasToBean(AuctFinalOutput_Download.class));
		@SuppressWarnings("unchecked")
		List<AuctFinalOutput_Download> l = criteria.list();
		logger.info("List Size " + l.size());
		session.close();
		return l;
	}

	/**
	 * @author rohan.a.mehra
	 * 
	 */
	public List<InventoryStandardFiori> writeOdataFinalOutputSheet(Long REQUEST_ID, int from, int limit) {
		logger.info("Successfully get Sission From SessionFactory");
		Session session = this.hibernateTemplate.getSessionFactory().openSession();
		logger.info("create Criteria for get all records from DB");
		Criteria criteria = session.createCriteria(InventoryStandardFiori.class);
		ProjectionList projection = Projections.projectionList();
		projection.add(Projections.property("availability"), "availability");
		projection.add(Projections.property("version"), "version");
		projection.add(Projections.property("altName"), "altName");
		projection.add(Projections.property("appId"), "appId");
		projection.add(Projections.property("appName"), "appName");
		projection.add(Projections.property("successorAppId"), "successorAppId");
		projection.add(Projections.property("relatedAppId"), "relatedAppId");

		if (limit != 0) {
			criteria.setMaxResults(limit);
		}
		if (from != 0) {
			criteria.setFirstResult(from);
		}
		criteria.add(Restrictions.eq("requestID", REQUEST_ID));
		criteria.setProjection(Projections.distinct(projection));
		criteria.setResultTransformer(Transformers.aliasToBean(InventoryStandardFiori.class));
		@SuppressWarnings("unchecked")
		List<InventoryStandardFiori> l = criteria.list();
		logger.info("List Size " + l.size());
		session.close();
		return l;
	}

	public List<CustomReportOutput_download> writeCustomReportFinalOutputSheet(Long REQUEST_ID, int from, int limit) {
		logger.info("Successfully get Sission From SessionFactory");
		Session session = this.hibernateTemplate.getSessionFactory().openSession();
		logger.info("create Criteria for get all records from DB");
		Criteria criteria = session.createCriteria(CustomReportOutput_download.class);
		ProjectionList projection = Projections.projectionList();
		projection.add(Projections.property("availability"), "availability");
		projection.add(Projections.property("version"), "version");
		projection.add(Projections.property("altName"), "altName");
		projection.add(Projections.property("fioriId"), "fioriId");
		projection.add(Projections.property("appName"), "appName");
		projection.add(Projections.property("successorApp"), "successorApp");
		projection.add(Projections.property("relatedApp"), "relatedApp");
		projection.add(Projections.property("technicalCatalogId"), "technicalCatalogId");
		projection.add(Projections.property("technicalcatalogtitle"), "technicalcatalogtitle");
		projection.add(Projections.property("semanticObjectAction"), "semanticObjectAction");
		projection.add(Projections.property("launchpadApplicationType"), "launchpadApplicationType");
		projection.add(Projections.property("launchpadApplicationName"), "launchpadApplicationName");
		projection.add(Projections.property("statusOfTheApplication"), "statusOfTheApplication");
		projection.add(Projections.property("flagForCustomApplication"), "flagForCustomApplication");
		projection.add(Projections.property("component"), "component");
		if (limit != 0) {
			criteria.setMaxResults(limit);
		}
		if (from != 0) {
			criteria.setFirstResult(from);
		}
		criteria.add(Restrictions.eq("requestID", REQUEST_ID));
		criteria.setProjection(Projections.distinct(projection));
		criteria.setResultTransformer(Transformers.aliasToBean(CustomReportOutput_download.class));
		@SuppressWarnings("unchecked")
		List<CustomReportOutput_download> l = criteria.list();
		logger.info("List Size " + l.size());
		session.close();
		return l;
	}

	/**
	 * @author j.patidar
	 * @see com.act.displaygrid.dao.JqGridDaoIntf#GetListwithLoopValue()
	 *      Fetch all the Data in List From Data Base and Apply Filter For All
	 *      Steps
	 */
	public List<HanaProfile_Download> GetList(Long requestID, final int from, final int limit) {
		logger.info("Successfully get Sission From SessionFactory");
		Session session = this.hibernateTemplate.getSessionFactory().openSession();
		logger.info("create Criteria for get all records from DB");
		Criteria criteria = session.createCriteria(HanaProfile_Download.class);
		ProjectionList projection = Projections.projectionList();
		projection.add(Projections.property("Object_Type"), "Object_Type");
		projection.add(Projections.property("Obj_Name"), "Obj_Name");
		projection.add(Projections.property("Sub_Program"), "Sub_Program");
		projection.add(Projections.property("Used_Unused"), "Used_Unused");
		// projection.add(Projections.property("Dialog_Steps"),"Dialog_Steps");
		projection.add(Projections.property("Sub_Type"), "Sub_Type");
		projection.add(Projections.property("Line_Number"), "Line_Number");
		projection.add(Projections.property("operation_code"), "operation_code");
		projection.add(Projections.property("Category"), "Category");
		projection.add(Projections.property("Subcategory"), "Subcategory");
		projection.add(Projections.property("issueSecondSubCat"), "issueSecondSubCat");
		projection.add(Projections.property("Opertaion"), "Opertaion");
		projection.add(Projections.property("Levels"), "Levels");
		projection.add(Projections.property("Tables"), "Tables");
		projection.add(Projections.property("Joins"), "Joins");
		projection.add(Projections.property("Table_Type"), "Table_Type");
		projection.add(Projections.property("Keys"), "Keys");
		projection.add(Projections.property("Where_Condition"), "Where_Condition");
		projection.add(Projections.property("Info"), "Info");
		projection.add(Projections.property("impact"), "impact");
		projection.add(Projections.property("DB"), "DB");
		projection.add(Projections.property("Change"), "Change");
		projection.add(Projections.property("loop"), "loop");
		projection.add(Projections.property("ReadProgram"), "ReadProgram");
		projection.add(Projections.property("Join_Type"), "Join_Type");
		// CR: DEF013
		projection.add(Projections.property("OBJ_PACKAGE"), "OBJ_PACKAGE");

		// col25
		projection.add(Projections.property("sel_Line"), "sel_Line");
		projection.add(Projections.property("automation_status"), "automation_status");
		// CR-13.0 adding data of High level Description
		projection.add(Projections.property("high_lvl_desc"), "high_lvl_desc");
		// CR-26: //col26
		projection.add(Projections.property("Odata"), "Odata");
		// CR-28.0 adding data of Total Lines Scanned
		projection.add(Projections.property("totalLineScanned"), "totalLineScanned");
		// CR-39.0 adding Statement Col
		projection.add(Projections.property("code"), "code");

		projection.add(Projections.property("COMPLEXITY"), "COMPLEXITY");

		// DEF041: Add data of Skip_Reason
		projection.add(Projections.property("skipReason"), "skipReason");
		projection.add(Projections.property("skip"), "skip");
		projection.add(Projections.property("ricefCategory"), "ricefCategory");
		projection.add(Projections.property("extNamespace"), "extNamespace");
		projection.add(Projections.property("ricefSubCategory"), "ricefSubCategory");

		if (limit != 0) {
			criteria.setMaxResults(limit);
		}
		if (from != 0) {
			criteria.setFirstResult(from);
		}
		criteria.add(Restrictions.eq("requestID", requestID));
		criteria.setProjection(Projections.distinct(projection));
		criteria.setResultTransformer(Transformers.aliasToBean(HanaProfile_Download.class));
		List<HanaProfile_Download> l = criteria.list();
		logger.info("List Size " + l.size());
		session.close();

		return l;
	}

	/**
	 * @author sankhamala.a.pal
	 * 
	 */
	public List<HanaProfile> getHanaDetailReport(Long requestID, final int from, final int limit) {
		logger.info("Successfully get Sission From SessionFactory");
		Session session = this.hibernateTemplate.getSessionFactory().openSession();
		logger.info("create Criteria for get all records from DB");
		Criteria criteria = session.createCriteria(HanaProfile.class);
		ProjectionList projection = Projections.projectionList();
		projection.add(Projections.property("objNameType"), "objNameType");
		projection.add(Projections.property("Obj_Name"), "Obj_Name");
		if (limit != 0) {
			criteria.setMaxResults(limit);
		}
		if (from != 0) {
			criteria.setFirstResult(from);
		}
		criteria.add(Restrictions.eq("requestID", requestID));
		criteria.setProjection(Projections.distinct(projection));
		criteria.setResultTransformer(Transformers.aliasToBean(HanaProfile.class));
		List<HanaProfile> l = criteria.list();
		logger.info("List Size " + l.size());
		session.close();
		return l;
	}

	public List<S4HanaProfiler> getS4DetailReport(Long requestID, final int from, final int limit) {
		logger.info("Successfully get Sission From SessionFactory");
		Session session = this.hibernateTemplate.getSessionFactory().openSession();
		logger.info("create Criteria for get all records from DB");
		Criteria criteria = session.createCriteria(S4HanaProfiler.class);
		ProjectionList projection = Projections.projectionList();
		projection.add(Projections.property("objNameType"), "objNameType");
		if (limit != 0) {
			criteria.setMaxResults(limit);
		}
		if (from != 0) {
			criteria.setFirstResult(from);
		}
		criteria.add(Restrictions.eq("requestID", requestID));
		criteria.setProjection(Projections.distinct(projection));
		criteria.setResultTransformer(Transformers.aliasToBean(S4HanaProfiler.class));
		List<S4HanaProfiler> l = criteria.list();
		logger.info("List Size " + l.size());
		session.close();
		return l;
	}

	public List<S4SimplificationDatabase> getSimplificationListReport(Long requestID, final int from, final int limit) {
		logger.info("Successfully get Sission From SessionFactory");
		Session session = this.hibernateTemplate.getSessionFactory().openSession();
		logger.info("create Criteria for get all records from DB");
		Criteria criteria = session.createCriteria(S4SimplificationDatabase.class);
		ProjectionList projection = Projections.projectionList();
		projection.add(Projections.property("object"), "object");
		projection.add(Projections.property("objectType"), "objectType");
		if (limit != 0) {
			criteria.setMaxResults(limit);
		}
		if (from != 0) {
			criteria.setFirstResult(from);
		}
		criteria.setProjection(Projections.distinct(projection));
		criteria.setResultTransformer(Transformers.aliasToBean(S4SimplificationDatabase.class));
		List<S4SimplificationDatabase> l = criteria.list();
		logger.info("List Size " + l.size());
		session.close();
		return l;
	}

	public List<AuctFinalOutput> getExistingErrorReport(Long requestID, final int from, final int limit) {
		logger.info("Successfully get Sission From SessionFactory");
		Session session = this.hibernateTemplate.getSessionFactory().openSession();
		logger.info("create Criteria for get all records from DB");
		Criteria criteria = session.createCriteria(AuctFinalOutput.class);
		ProjectionList projection = Projections.projectionList();
		projection.add(Projections.property("OBJ_NAME_TYPE"), "OBJ_NAME_TYPE");
		if (limit != 0) {
			criteria.setMaxResults(limit);
		}
		if (from != 0) {
			criteria.setFirstResult(from);
		}
		criteria.add(Restrictions.eq("REQUEST_ID", requestID));
		criteria.setProjection(Projections.distinct(projection));
		criteria.setResultTransformer(Transformers.aliasToBean(AuctFinalOutput.class));
		List<AuctFinalOutput> l = criteria.list();
		logger.info("List Size " + l.size());
		session.close();
		return l;
	}

	public List<OSMigrationFinal> getOSMigrationFinalReport(Long requestID, final int from, final int limit) {
		logger.info("Successfully get Session From SessionFactory");
		Session session = this.hibernateTemplate.getSessionFactory().openSession();
		logger.info("Create Criteria for get all records from DB");
		Criteria criteria = session.createCriteria(OSMigrationFinal.class);
		ProjectionList projection = Projections.projectionList();
		projection.add(Projections.property("objTypeName"), "objTypeName");
		if (limit != 0) {
			criteria.setMaxResults(limit);
		}
		if (from != 0) {
			criteria.setFirstResult(from);
		}
		criteria.add(Restrictions.eq("requestID", requestID));
		criteria.setProjection(Projections.distinct(projection));
		criteria.setResultTransformer(Transformers.aliasToBean(OSMigrationFinal.class));
		List<OSMigrationFinal> l = criteria.list();
		logger.info("List Size " + l.size());
		session.close();
		return l;
	}

	/**
	 * @author himani.malhotra
	 * 
	 */
	public List<ImpactedScripts_Download> getImpactedScriptsList(Long REQUEST_ID, final int from, final int limit) {
		logger.info("Successfully get Sission From SessionFactory");
		Session session = this.hibernateTemplate.getSessionFactory().openSession();
		logger.info("create Criteria for get all records from DB");
		Criteria criteria = session.createCriteria(ImpactedScripts_Download.class);
		ProjectionList projection = Projections.projectionList();
		projection.add(Projections.property("objType"), "objType");
		projection.add(Projections.property("objName"), "objName");
		projection.add(Projections.property("actStatus"), "actStatus");
		projection.add(Projections.property("remidiCategory"), "remidiCategory");
		projection.add(Projections.property("dbImpact"), "dbImpact");
		projection.add(Projections.property("s4Simplification"), "s4Simplification");
		projection.add(Projections.property("existingErrors"), "existingErrors");
		projection.add(Projections.property("opCode"), "opCode");
		projection.add(Projections.property("externalNamespace"), "externalNamespace");

		if (limit != 0) {
			criteria.setMaxResults(limit);
		}
		if (from != 0) {
			criteria.setFirstResult(from);
		}
		criteria.add(Restrictions.eq("requestId", REQUEST_ID));
		criteria.setProjection(Projections.distinct(projection));
		criteria.setResultTransformer(Transformers.aliasToBean(ImpactedScripts_Download.class));
		List<ImpactedScripts_Download> l = criteria.list();
		logger.info("List Size " + l.size());
		session.close();
		return l;
	}

	/**
	 * @author sankhamala.a.pal
	 * 
	 */
	public List<ImpactedCloneAnalysis_Download> getImpactedCloneList(Long REQUEST_ID, final int from, final int limit) {
		logger.info("Successfully get Session From SessionFactory");
		Session session = this.hibernateTemplate.getSessionFactory().openSession();
		logger.info("create Criteria for get all records from DB");
		Criteria criteria = session.createCriteria(ImpactedCloneAnalysis_Download.class);
		ProjectionList projection = Projections.projectionList();
		projection.add(Projections.property("namespace"), "namespace");
		projection.add(Projections.property("objType"), "objType");
		projection.add(Projections.property("objName"), "objName");
		projection.add(Projections.property("objTypeName"), "objTypeName");
		projection.add(Projections.property("objPackage"), "objPackage");
		projection.add(Projections.property("year"), "year");
		projection.add(Projections.property("creationDate"), "creationDate");
		projection.add(Projections.property("interfaceObjType"), "interfaceObjType");
		projection.add(Projections.property("interfaceObj"), "interfaceObj");
		projection.add(Projections.property("reference"), "reference");
		projection.add(Projections.property("referencePercent"), "referencePercent");
		projection.add(Projections.property("appComponent"), "appComponent");
		projection.add(Projections.property("used"), "used");
		projection.add(Projections.property("impactedDB"), "impactedDB");
		projection.add(Projections.property("impactedSimpl"), "impactedSimpl");
		projection.add(Projections.property("impactedExistingError"), "impactedExistingError");
		projection.add(Projections.property("impactedOSMigration"), "impactedOSMigration");
		projection.add(Projections.property("externalNamespace"), "externalNamespace");
		projection.add(Projections.property("execDate"), "execDate");
		projection.add(Projections.property("execTime"), "execTime");

		if (limit != 0) {
			criteria.setMaxResults(limit);
		}
		if (from != 0) {
			criteria.setFirstResult(from);
		}
		criteria.add(Restrictions.eq("requestID", REQUEST_ID));
		criteria.setProjection(Projections.distinct(projection));
		criteria.setResultTransformer(Transformers.aliasToBean(ImpactedCloneAnalysis_Download.class));
		List<ImpactedCloneAnalysis_Download> l = criteria.list();
		logger.info("List Size " + l.size());
		session.close();
		return l;
	}

	/**
	 * @author sankhamala.a.pal
	 * 
	 */
	public List<S4cvitr_Download> getcvitrList(Long REQUEST_ID, final int from, final int limit) {
		logger.info("Successfully get Sission From SessionFactory");
		Session session = this.hibernateTemplate.getSessionFactory().openSession();
		logger.info("create Criteria for get all records from DB");
		Criteria criteria = session.createCriteria(S4cvitr_Download.class);
		ProjectionList projection = Projections.projectionList();
		projection.add(Projections.property("requestID"), "requestID");
		projection.add(Projections.property("identifier"), "identifier");
		projection.add(Projections.property("selectLine"), "selectLine");
		projection.add(Projections.property("commentC"), "commentC");
		projection.add(Projections.property("comments"), "comments");
		projection.add(Projections.property("newLine"), "newLine");
		projection.add(Projections.property("vendorExt"), "vendorExt");
		projection.add(Projections.property("customerExt"), "customerExt");
		if (limit != 0) {
			criteria.setMaxResults(limit);
		}
		if (from != 0) {
			criteria.setFirstResult(from);
		}
		criteria.add(Restrictions.eq("requestID", REQUEST_ID));
		criteria.setProjection(Projections.distinct(projection));
		criteria.setResultTransformer(Transformers.aliasToBean(S4cvitr_Download.class));
		List<S4cvitr_Download> l = criteria.list();
		logger.info("List Size " + l.size());
		session.close();
		return l;
	}

	private List select(String sql, Long requestID) {

		Session session = this.hibernateTemplate.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();

		Query query = session.createQuery(sql);
		query.setParameter("requestID", requestID);

		List list = query.list();
		tx.commit();
		session.close();
		return list;
	}

	private void refineUnwantedCategory(final Long requestId) {

		logger.info("Steps For refineUnwantadCategory");
		String hql = "select h from HanaProfile h where h.requestID=:requestID and ((Table_Type like '%|' or Table_Type like '|%' or Join_Type like '%|' or Join_Type like '|%')  or (Table_Type not like '%|TRANSP' and table_type not like '%|POOL' and table_type not like '%|VIEW' and table_type not like '%|CLUSTER'  and table_type not in('TRANSP','VIEW','CLUSTER','' )))";
		final List<HanaProfile> hanaPrfileList = select(hql, requestId);
		logger.info("********** Got the result with size  *********** " + hanaPrfileList.size());
		if (CollectionUtils.isNotEmpty(hanaPrfileList)) {
			final List<HanaProfile> hanaProfileUpdatedList = new ArrayList<HanaProfile>();
			Iterator<HanaProfile> iterator = hanaPrfileList.iterator();
			HanaProfile hanaProfile = null;
			String tableType = null;
			String joinType = null;

			while (iterator.hasNext()) {

				hanaProfile = iterator.next();
				tableType = hanaProfile.getTable_Type();
				joinType = hanaProfile.getJoin_Type();
				iterator.remove();
				if (tableType.startsWith("|")) {
					tableType = tableType.substring(1);
				}
				if (tableType.endsWith("|")) {
					tableType = tableType.substring(0, tableType.length() - 1);
				}
				if (tableType.substring((tableType.lastIndexOf("|") + 1)).matches("[TVPC][a-zA-Z]*$")) {
					String tableType_sub = tableType.substring(tableType.lastIndexOf("|") + 1);
					if (tableType_sub.matches("T[a-zA-Z]*$")) {
						tableType = tableType.substring(0, tableType.lastIndexOf("|") + 1) + "TRANSP";
					} else if (tableType_sub.matches("V[a-zA-Z]*$")) {
						tableType = tableType.substring(0, tableType.lastIndexOf("|") + 1) + "VIEW";
					} else if (tableType_sub.matches("P[a-zA-Z]*$")) {
						tableType = tableType.substring(0, tableType.lastIndexOf("|") + 1) + "POOL";
					} else if (tableType_sub.matches("C[a-zA-Z]*$")) {
						tableType = tableType.substring(0, tableType.lastIndexOf("|") + 1) + "CLUSTER";
					}

				}

				if (joinType.startsWith("|")) {
					joinType = joinType.substring(1);
				}
				if (joinType.endsWith("|")) {
					joinType = joinType.substring(0, joinType.length() - 1);
				}

				/*
				 * while (iterator.hasNext()) { isTableTypeUpdate = false;
				 * isJoinTypeUpdate = false; nextHanaProfile = iterator.next();
				 * tableTypeNextValue = nextHanaProfile.getTable_Type();
				 * joinTypeNextValue = nextHanaProfile.getJoin_Type(); if
				 * (tableTypeNextValue.startsWith("|")) { tableTypeNextValue =
				 * tableTypeNextValue.substring(1); } if
				 * (tableTypeNextValue.endsWith("|")) { tableTypeNextValue =
				 * tableTypeNextValue.substring(0, tableTypeNextValue.length() -
				 * 1); } if
				 * (tableTypeNextValue.substring((tableTypeNextValue.lastIndexOf
				 * ("|") + 1)) .matches("[TVPC][a-zA-Z]*$")) { String
				 * tableType_sub =
				 * tableTypeNextValue.substring(tableTypeNextValue.lastIndexOf(
				 * "|") + 1); if (tableType_sub.matches("T[a-zA-Z]*$")) {
				 * tableTypeNextValue = tableTypeNextValue.substring(0,
				 * tableTypeNextValue.lastIndexOf("|") + 1) + "TRANSP"; } else
				 * if (tableType_sub.matches("V[a-zA-Z]*$")) {
				 * tableTypeNextValue = tableTypeNextValue.substring(0,
				 * tableTypeNextValue.lastIndexOf("|") + 1) + "VIEW"; } else if
				 * (tableType_sub.matches("P[a-zA-Z]*$")) { tableTypeNextValue =
				 * tableTypeNextValue.substring(0,
				 * tableTypeNextValue.lastIndexOf("|") + 1) + "POOL"; } else if
				 * (tableType_sub.matches("C[a-zA-Z]*$")) { tableTypeNextValue =
				 * tableTypeNextValue.substring(0,
				 * tableTypeNextValue.lastIndexOf("|") + 1) + "CLUSTER"; }
				 * 
				 * }
				 * 
				 * if (joinTypeNextValue.startsWith("|")) { joinTypeNextValue =
				 * joinTypeNextValue.substring(1); } if
				 * (joinTypeNextValue.endsWith("|")) { joinTypeNextValue =
				 * joinTypeNextValue.substring(0, joinTypeNextValue.length() -
				 * 1); }
				 * 
				 * if (tableType.equals(tableTypeNextValue)) {
				 * 
				 * isTableTypeUpdate = true;
				 * 
				 * nextHanaProfile.setTable_Type(tableType); }
				 * 
				 * if (joinType.equals(joinTypeNextValue)) {
				 * 
				 * isJoinTypeUpdate = true;
				 * 
				 * nextHanaProfile.setJoin_Type(joinType); } if
				 * (isTableTypeUpdate && isJoinTypeUpdate) { iterator.remove();
				 * } if (isTableTypeUpdate || isJoinTypeUpdate) {
				 * hanaProfileUpdatedList.add(nextHanaProfile); }
				 * 
				 * if(hanaProfileUpdatedList.size()>50000){
				 * populateHanaTable.populateDataList(hanaProfileUpdatedList);
				 * System.out.
				 * println("********** Commit Result With  **********"
				 * +hanaProfileUpdatedList.size());
				 * hanaProfileUpdatedList.clear();
				 * System.out.println("********** Cleared  **********"); }
				 * 
				 * }
				 */

				hanaProfile.setTable_Type(tableType);
				hanaProfile.setJoin_Type(joinType);
				hanaProfileUpdatedList.add(hanaProfile);

				if (hanaProfileUpdatedList.size() > 50000) {
					populateHanaTable.populateDataList(hanaProfileUpdatedList);
					logger.info("********** Commit Result With  **********" + hanaProfileUpdatedList.size());
					hanaProfileUpdatedList.clear();
					logger.info("********** Cleared  **********");
				}
			}

			populateHanaTable.populateDataList(hanaProfileUpdatedList);
		}
		logger.info("********** finally Done Everything *********** " + hanaPrfileList.size());
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void archiveData(final long requestID, final String pathName) {
		logger.info("Steps For archiveData");
		try {
			hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {
					final Query query = session.createSQLQuery("call archive_data(:requestId,:path)");
					query.setParameter("requestId", requestID);
					query.setParameter("path", pathName);
					return query.executeUpdate();
				}

			});

		} catch (Exception e) {
			logger.error("Error PopulatingFinalOutput archiveData ", e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	// CR-25
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void deleteDuplicateRecords(final long requestID) {

		try {
			// col25
			logger.info("Creting Dynamic table");
			hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {
					String SqlQuery = "CREATE TABLE OUTPUT_" + requestID + "  AS SELECT "
							+ "Category, CHANGE_COLUMN, DB, Info, Join_Type, Joins, KEYS_COLUMN, Levels, Line_Number, Obj_Name, Object_Type, Opertaion, "
							+ "ReadProgram, Sub_Program, Sub_Type, Subcategory, Table_Type, TABLES_COLUMN, Used_Unused, Where_Condition, impact, "
							+ "LOOP_COLUMN, operation_code, SEL_LINE, automation_status, high_lvl_desc, code, total_line_scanned, OBJ_NAME_TYPE, "
							+ "OBJ_PACKAGE, COMPLEXITY, COMMENT_C, IssueSecondSubCat, SKIP, RICEF_CATEGORY, External_Namespace, Ricef_Sub_Category, Counter "
							+ "FROM FINAL_OUTPUT WHERE Request_ID=" + requestID;
					logger.info("Creating" + SqlQuery);
					final Query query = session.createSQLQuery(SqlQuery);
					return query.executeUpdate();
				}
			});

			/*
			 * logger.info("Creting Dynamic table");
			 * hibernateTemplate.execute(new HibernateCallback() { public Object
			 * doInHibernate(Session session) throws HibernateException { String
			 * SqlQuery="CREATE TABLE OUTPUT_ORIGINAL_"+requestID+
			 * "  AS SELECT  *  "+
			 * " FROM FINAL_OUTPUT WHERE Request_ID="+requestID;
			 * logger.info("Creating"+SqlQuery); final Query query =
			 * session.createSQLQuery(SqlQuery); return query.executeUpdate(); }
			 * });
			 */

			logger.info("Deleting Records From Final Output");
			hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {
					String SqlQuery = "DELETE FROM  FINAL_OUTPUT WHERE Request_ID=" + requestID;
					final Query query = session.createSQLQuery(SqlQuery);
					logger.info("Deleting" + SqlQuery);
					return query.executeUpdate();
				}
			});

			// col25
			logger.info("Inserting Records From Final Output");
			hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {
					String SqlQuery = "INSERT INTO FINAL_OUTPUT(Category, CHANGE_COLUMN, DB,Info, Join_Type, Joins, KEYS_COLUMN, Levels, Line_Number, "
							+ "Obj_Name, Object_Type, Opertaion, ReadProgram, Sub_Program, Sub_Type, Subcategory, Table_Type, TABLES_COLUMN, Used_Unused, "
							+ "Where_Condition, impact, LOOP_COLUMN, operation_code, SEL_LINE, automation_status, high_lvl_desc, code, total_line_scanned, "
							+ "OBJ_NAME_TYPE, OBJ_PACKAGE, COMPLEXITY, COMMENT_C, IssueSecondSubCat, SKIP, Request_ID, RICEF_CATEGORY, External_Namespace, Ricef_Sub_Category, Counter)"
							+ "SELECT DISTINCT Category, CHANGE_COLUMN, DB, Info, Join_Type, Joins, KEYS_COLUMN, Levels, Line_Number, Obj_Name, Object_Type, Opertaion, "
							+ "ReadProgram, Sub_Program, Sub_Type, Subcategory, Table_Type, TABLES_COLUMN, Used_Unused, Where_Condition, impact, "
							+ "LOOP_COLUMN, operation_code, SEL_LINE, automation_status, high_lvl_desc, code, total_line_scanned, OBJ_NAME_TYPE, OBJ_PACKAGE, "
							+ "COMPLEXITY, COMMENT_C, IssueSecondSubCat, SKIP, " + requestID
							+ "  AS REQUEST_ID, RICEF_CATEGORY, External_Namespace, Ricef_Sub_Category, Counter FROM OUTPUT_"
							+ requestID;
					final Query query = session.createSQLQuery(SqlQuery);
					logger.info("Copying " + SqlQuery);
					return query.executeUpdate();
				}
			});

			logger.info("Deleting Duplicate Records Has Been Done..");

			hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {
					String SqlQuery = "DROP TABLE OUTPUT_" + requestID;
					final Query query = session.createSQLQuery(SqlQuery);
					logger.info("Drop" + SqlQuery);
					return query.executeUpdate();
				}
			});

		} catch (Exception e) {
			logger.error("Error PopulatingFinalOutput doInHibernate ", e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public void deleteCurrentQueueExecution(final Class className) {
		try {

			hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {
					String SqlQuery = "DELETE FROM " + className.getName();
					final Query query = session.createQuery(SqlQuery);

					return query.executeUpdate();
				}
			});
		}

		catch (Exception ex) {
			logger.error(ex.getMessage());
			logger.trace(ex.getMessage());
			logger.error("");
		}
	}

	@Override
	public Map<Integer, String> getWaitingRequest() {
		final Map<Integer, String> resultMap = new HashMap<Integer, String>();
		Session session = sessionFactory.openSession();
		String hql = "Select requestID,emailId from QueueExecution";
		Query query = session.createQuery(hql);
		List<Object[]> resultList = query.list();
		if (CollectionUtils.isNotEmpty(resultList)) {
			for (Object[] object : resultList) {
				resultMap.put(((Long) object[0]).intValue(), (String) object[1]);
			}
		}
		session.close();
		return resultMap;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void updateSubTypeValues(final long requestID) {

		logger.info("Updating the subtype values");
		try {
			hibernateTemplate.execute(new HibernateCallback() {
				public Object doInHibernate(Session session) throws HibernateException {
					String sqlQuery = "UPDATE final_output SET Sub_Type = ("
							+ "CASE  Sub_Type WHEN 'I' THEN 'Include Program' " + "WHEN '1' THEN 'Executable program' "
							+ "WHEN 'S' THEN 'Subroutine Pool' " + "WHEN 'F' THEN 'Function Group' "
							+ "WHEN 'M' THEN 'Module Pool'  else Sub_Type  END ) WHERE Request_ID =" + requestID;
					final Query query = session.createSQLQuery(sqlQuery);
					return query.executeUpdate();
				}
			});
		} catch (Exception e) {
			logger.error("Error PopulatingFinalOutput updateSubTypeValues", e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
	}

	/* CR-9.0 */
	public String addEstimatorData(final HanaEstimator hanaEstimator) {

		Query query = null;
		String comment;
		String hql = "delete from HanaEstimator where request_id=" + hanaEstimator.getRequestID();
		String hql1 = "select count(*) from HanaEstimator where request_id=" + hanaEstimator.getRequestID();

		Session session = sessionFactory.openSession();
		try {
			query = session.createQuery(hql1);
			int count = ((Long) query.uniqueResult()).intValue();

			if (count != 0) {
				query = session.createQuery(hql);
				query.executeUpdate();
			}
			// Session session=sessionFactory.openSession();
			session.saveOrUpdate(hanaEstimator);

			session.close();
			comment = "success";
		} catch (Exception e) {
			comment = "Failed due to::" + e.getMessage();
			logger.error("Error PopulatingFinalOutput addEstimatorData ", e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		return comment;
	}

	public String addAssumptionsData(final HanaAssumption hanaAssumption) {

		Query query = null;
		String comment;
		String hql = "delete from HanaAssumption where request_id=" + hanaAssumption.getRequestID();
		String hql1 = "select count(*) from HanaAssumption where request_id=" + hanaAssumption.getRequestID();

		Session session = sessionFactory.openSession();
		try {
			query = session.createQuery(hql1);
			int count = ((Long) query.uniqueResult()).intValue();

			if (count != 0) {
				query = session.createQuery(hql);
				query.executeUpdate();
			}
			session.saveOrUpdate(hanaAssumption);

			session.close();
			comment = "success";
		} catch (Exception e) {
			comment = "Failed due to::" + e.getMessage();
			logger.error("Error PopulatingFinalOutput addAssumptionsData ", e);
			logger.error(e.getMessage());
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}
		return comment;
	}

	// AUCT Processing logic
	// ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

	public boolean getAUCTFinalStatus(long requestID, HttpSession session) {

		Boolean finalStatus = false;
		try {

			updateAUCTPackageFromInventory(requestID, session);
			logger.info("Package values got updated in AUCT Final Output%%%%%%%%%%%%%%%%%%%%%%%");

			updateAUCTAutomationLogic(requestID);
			logger.info("Automation Status values got updated in AUCT Final Output%%%%%%%%%%%%%%%%%%%%%%%");

			finalStatus = true;

		} catch (Exception e) {
			logger.error("Exception in getAUCTFinalStatus method" + e.getStackTrace());
			finalStatus = false;
		}
		return finalStatus;
	}

	// AUCT Automation Status Logic
	public void updateAUCTAutomationLogic(long requestId) {
		try {
			String AUCTAutomationStatus = "UPDATE auct_final_output auct JOIN operation_data_auct odata ON auct.OPCODE = odata.OPCODE"
					+ " SET auct.AUTOMATION_STATUS= odata.Automation_Status , auct.INFO= IF( auct.INFO IS NULL OR LENGTH(auct.INFO)=0,odata.DESCRIPTION_OF_CHANGE,auct.INFO) "
					+ "where REQUEST_ID=" + requestId;
			updateFrmTables(AUCTAutomationStatus);
		} catch (Exception e) {
			logger.error("Exception in updateAUCTAutomationLogic method" + e.getStackTrace());
		}
	}

	// DEF091
	// update AUCT Final Output with Inventory List for Package Column
	public void updateAUCTPackageFromInventory(long requestId, HttpSession session) throws SQLException {
		List<AuctFinalOutput> auctFinalOutputFinalList = new ArrayList<AuctFinalOutput>();
		List<S4InventoryList> inventoryList = getS4InventoryList(requestId);

		List<AuctFinalOutput> auctFinalOutputList = getAuctFinalOutput(requestId);

		if (!auctFinalOutputList.isEmpty() || null != auctFinalOutputList) {
			for (AuctFinalOutput auctFinalOutput : auctFinalOutputList) {
				if (MapUtils.isNotEmpty(st03ReaderXlsx.getHm().getMetaDataMap())) {
					if (null != st03ReaderXlsx.getHm().getMetaDataMap().get(auctFinalOutput.getOBJ_NAME_TYPE())) {
						auctFinalOutput.setRicefCategory(st03ReaderXlsx.getHm().getMetaDataMap()
								.get(auctFinalOutput.getOBJ_NAME_TYPE()).getRicefCategory());
					}
					if (null != st03ReaderXlsx.getHm().getMetaDataMap().get(auctFinalOutput.getOBJ_NAME_TYPE())
							&& null != st03ReaderXlsx.getHm().getMetaDataMap().get(auctFinalOutput.getOBJ_NAME_TYPE())
									.getRicefSubCategory()) {
						auctFinalOutput.setRicefSubCategory(st03ReaderXlsx.getHm().getMetaDataMap()
								.get(auctFinalOutput.getOBJ_NAME_TYPE()).getRicefSubCategory());
					}
				}
				if (StringUtils.isBlank(auctFinalOutput.getRicefCategory())
						&& "SSFO".equalsIgnoreCase(auctFinalOutput.getTYPE())) {
					auctFinalOutput.setRicefCategory("FORMS");
					auctFinalOutput.setRicefSubCategory("Smartforms");
				}
				if (StringUtils.isBlank(auctFinalOutput.getRicefCategory())
						&& "SFPF".equalsIgnoreCase(auctFinalOutput.getTYPE())) {
					auctFinalOutput.setRicefCategory("FORMS");
					auctFinalOutput.setRicefSubCategory("Adobe");
				}
				if ("AQQU".equalsIgnoreCase(auctFinalOutput.getTYPE())) {
					auctFinalOutput.setRicefCategory("Others");
					auctFinalOutput.setRicefSubCategory("Configurable Report");
				}

				if (StringUtils.isBlank(auctFinalOutput.getRicefCategory()))
					auctFinalOutput.setRicefCategory(Hana_Profiler_Constant.OTHERS);

				if (!inventoryList.isEmpty() || null != inventoryList) {
					if (auctFinalOutput.getOBJ_PACKAGE().isEmpty() || auctFinalOutput.getOBJ_PACKAGE() == null) {
						logger.info("Package is null::::::::::::::::::: for " + auctFinalOutput.getOBJ_NAME());
						for (S4InventoryList inv : inventoryList) {
							if (auctFinalOutput.getOBJ_NAME_TYPE().equalsIgnoreCase(inv.getObjNameType())) {
								auctFinalOutput.setOBJ_PACKAGE(inv.getPckg());
								logger.info("Object Name: " + auctFinalOutput.getOBJ_NAME() + " obj type: "
										+ auctFinalOutput.getOBJ_NAME_TYPE() + " obj package: "
										+ auctFinalOutput.getOBJ_PACKAGE());

							}
						}
					}

				}
				auctFinalOutputFinalList.add(auctFinalOutput);
			}
		}
		AUCTPackageBatchInsertUpdate(auctFinalOutputFinalList, session);

		logger.info("********************Updated PackageFromInventory for AUCT********************************");
	}

	public static String AUCTPackageBatchInsertUpdate(List<AuctFinalOutput> auctProfilerlist, HttpSession session)
			throws SQLException {

		final String UPDATE_SQL = "UPDATE auct_final_output set OBJ_PACKAGE=? , RICEF_CATEGORY=?, RICEF_SUB_CATEGORY=? where ID=?";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);

			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(UPDATE_SQL);
				int batch = 1;

				for (AuctFinalOutput auctFinal : auctProfilerlist) {
					stmt.setString(1, auctFinal.getOBJ_PACKAGE());
					stmt.setString(2, auctFinal.getRicefCategory());
					stmt.setString(3, auctFinal.getRicefSubCategory());
					stmt.setLong(4, auctFinal.getId());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " for AUCT Package executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("Final batch for AUCT Package executed successfully");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error(e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(e.getMessage());

		} finally {
			stmt.close();
			conn.close();
		}

		return result;

	}

	@SuppressWarnings("unchecked")
	private List<S4InventoryList> getS4InventoryList(long requestId) {
		logger.info("Steps For S4InventoryList****************");
		Session session = this.hibernateTemplate.getSessionFactory().openSession();

		String sql = "Select * from S4_Inventory_List where request_id=:requestID";

		Query query = session.createSQLQuery(sql).addEntity(S4InventoryList.class);
		query.setParameter("requestID", requestId);

		logger.info("******************" + query.getQueryString());
		return query.list();
	}

	@SuppressWarnings("unchecked")
	private List<AuctFinalOutput> getAuctFinalOutput(long requestId) {
		logger.info("Steps For getAuctFinalOutput****************");
		Session session = this.hibernateTemplate.getSessionFactory().openSession();

		String sql = "Select * from Auct_Final_Output where request_id=:requestID";

		Query query = session.createSQLQuery(sql).addEntity(AuctFinalOutput.class);
		query.setParameter("requestID", requestId);

		logger.info("******************" + query.getQueryString());
		return query.list();
	}

	// ***************************************************************************************************************

	public Map<String, String> getTestingscopeValuesdb() {
		Session session = null;
		final Map<String, String> resultMap = new HashMap<String, String>();
		session = sessionFactory.openSession();
		String hql = "select componentid,applcompdescription,moduleorprocess,standardtcodes from testingscope";
		Query query = session.createSQLQuery(hql);
		List<Object[]> resultList = query.list();

		if (CollectionUtils.isNotEmpty(resultList)) {
			for (Object[] object : resultList) {
				String componentid = "&%";
				String applcompdescription = "&%";
				String moduleorprocess = "&%";
				String standardtcodes = "&%";
				String Data = "";

				if (!((String) object[0]).equals("")) {
					componentid = (String) object[0];
					Data = Data + componentid;
				} else if (object[0].equals("")) {
					Data = Data + componentid;
				}
				if (!((String) object[1]).equals("")) {
					applcompdescription = (String) object[1];
					Data = Data + "*%" + applcompdescription;
				} else if (object[1].equals("")) {
					Data = Data + "*%" + applcompdescription;
				}
				if (!((String) object[2]).equals("")) {
					moduleorprocess = (String) object[2];
					Data = Data + "*%" + moduleorprocess;
				} else if (object[2].equals("")) {
					Data = Data + "*%" + moduleorprocess;
				}
				if (!((String) object[3]).equals("")) {
					standardtcodes = (String) object[3];
					Data = Data + "*%" + standardtcodes;
				} else if (object[3].equals("")) {
					Data = Data + "*%" + standardtcodes;
				}

				resultMap.put(componentid, Data);

			}
		}
		session.close();
		return resultMap;
	}

	@Override
	public Map<String, TreeMap<String, String>> testingScopeMasterDataValues() {
		Session session = sessionFactory.openSession();

		final Map<String, TreeMap<String, String>> processResultMap = new TreeMap<>();
		TreeMap<String, String> compIDMap = null;
		Set<String> processSet = new TreeSet<>();
		String hql = "select componentid, applcompdescription, moduleorprocess from testingscope";
		Query query = session.createSQLQuery(hql);
		List<Object[]> resultList = query.list();

		String componentId = "";

		if (CollectionUtils.isNotEmpty(resultList)) {
			for (Object[] processData : resultList) {
				processSet.add((String) processData[2]);
			}

			for (String processSetData : processSet) {
				compIDMap = new TreeMap<>();
				for (Object[] componentIDData : resultList) {
					componentId = (String) componentIDData[0];
					if (componentId.startsWith(processSetData))
						compIDMap.put((String) componentIDData[0], (String) componentIDData[1]);
				}

				processResultMap.put(processSetData, compIDMap);
			}
		}

		session.close();
		return processResultMap;
	}

	public String testingScopeFinalInsert(List<ExtractedDatapojo> finalTestingScopeReportList, HttpSession session)
			throws SQLException {
		final String INSERT_SQL = "INSERT INTO FinalOutputTestingscope "
				+ "(requestid, objecttype, objectname, process, objectTypeObjectName, applicationComponent, opercd, appCompDesc, transactions, role) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {
			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;
				for (ExtractedDatapojo testingscope : finalTestingScopeReportList) {
					stmt.setLong(1, testingscope.getRequestid());
					stmt.setString(2, testingscope.getObjecttype());
					stmt.setString(3, testingscope.getObjectname());
					stmt.setString(4, testingscope.getProcess());
					stmt.setString(5, testingscope.getObjectTypeObjectName());
					stmt.setString(6, testingscope.getApplicationComponent());
					stmt.setString(7, testingscope.getOpercd());
					stmt.setString(8, testingscope.getAppCompDesc());
					stmt.setString(9, testingscope.getTransactions());
					stmt.setString(10, testingscope.getRole());

					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 1000 records
					if (counter % 1000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();

				logger.info("Testing Scope Data INSERTED SUCCESSFULLY");
			} catch (Exception e) {
				result = "FAILURE in inserting data into Testing Scope DB";
				logger.error(result + " --- " + e.getMessage());
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error(result + " --- " + e.getMessage());
		} finally {
			stmt.close();
			conn.close();
		}

		return result;
	}

	@Override
	public void unicodeProcessing(HttpSession session) throws SQLException {
		logger.info("unicodeProcessing Started ");
		String insert_sql = "Insert into UNICODE_OUTPUT(Object_Type,Program, Include, Roww, Error_Code, Created_By, Pack, Pack_Per_Resp,Concat_Col,Application_Component,Message,Request_Id) select Object_Type,Program, Include, Roww, Error_Code, Created_By, Pack, Pack_Per_Resp,Concat_Col,Application_Component,group_concat(distinct Message ORDER BY ID ASC) as Message,Request_Id from UNICODE_Tbl group by Concat_Col";

		java.sql.Connection conn = null;
		Statement stmt = null;

		try {

			conn = DBConfig.getJDBCConnection(session);
			stmt = conn.createStatement();

			stmt.executeUpdate(insert_sql);

			String update_sql = "update UNICODE_OUTPUT u Inner join s4_inventory_list s on u.Program = s.OBJ_NAME set u.Used='Y'";

			stmt.executeUpdate(update_sql);

		} catch (Exception e) {
			logger.error("Error in unicodeProcessing :: ", e);
		} finally {
			stmt.close();
			conn.close();
		}

		logger.info("unicodeProcessing End ");

	}

	public List<UnicodeOutput> getUnicodeOutput(Long requestId) {
		logger.info("getUnicodeOutput Started :: ");
		Session session = sessionFactory.openSession();

		try {
			final Criteria criteria = session.createCriteria(UnicodeOutput.class);
			criteria.add(Restrictions.eq("requestId", requestId));
			return criteria.list();
		} catch (Exception e) {
			logger.error("getUnicodeOutput :: ", e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if (null != session)
				session.close();
		}
	}

	public List<BwInventoryDownload> getBwInventoryList(Long requestId) {
		logger.info("getBwInventoryList Started :: ");
		Session session = sessionFactory.openSession();

		try {
			final Criteria criteria = session.createCriteria(BwInventoryDownload.class);
			criteria.add(Restrictions.eq("requestID", requestId));
			return criteria.list();
		} catch (Exception e) {
			logger.error("getBwInventoryList :: ", e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if (null != session)
				session.close();
		}
	}

	public List<BwExtractorMaster> getBwMasterDataList() {
		logger.info("getBwInventoryList Started :: ");
		Session session = sessionFactory.openSession();

		try {
			final Criteria criteria = session.createCriteria(BwExtractorMaster.class);
			return criteria.list();
		} catch (Exception e) {
			logger.error("getBwInventoryList :: ", e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if (null != session)
				session.close();
		}
	}

	public List<BWExtractor_Download> getBwExtractorList(Long requestId) {
		logger.info("getBwInventoryList Started :: ");
		Session session = sessionFactory.openSession();

		try {
			final Criteria criteria = session.createCriteria(BWExtractor_Download.class);
			ProjectionList projectionList = Projections.projectionList();
			projectionList.add(Projections.property("oltsource"), "oltsource");
			criteria.add(Restrictions.eq("requestID", requestId));
			return criteria.list();
		} catch (Exception e) {
			logger.error("getBwInventoryList :: ", e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if (null != session)
				session.close();
		}
	}

	@Override
	public void deleteProcessedRequestFromWaitingQueue(Long requestId, HttpSession session) throws SQLException {
		logger.info("deleteProcessedRequestFromWaitingQueue Started :: ");
		java.sql.Connection conn = null;
		conn = DBConfig.getJDBCConnection(session);
		try {
			String query = "delete from  Queue_Execution where REQUEST_ID=" + requestId;
			PreparedStatement preparedStmt = conn.prepareStatement(query);

			// execute the preparedstatement
			preparedStmt.execute();
		} catch (Exception ex) {
			logger.error("Error in deleteProcessedRequestFromWaitingQueue :: ", ex);
		} finally {
			conn.close();
		}
		logger.info("deleteProcessedRequestFromWaitingQueue Ended :: ");
	}

	@Override
	public Map<Integer, String> getWaitingRequestWithOldTime(HttpSession session) {
		logger.info("getWaitingRequestWithOldTime Started :: ");
		final Map<Integer, String> resultMap = new HashMap<Integer, String>();
		java.sql.Connection conn = null;
		java.sql.Statement stmt = null;
		conn = DBConfig.getJDBCConnection(session);
		try {
			stmt = conn.createStatement();
			String query = "Select * from queue_execution order by timeStamp asc limit 1";
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {

				resultMap.put(rs.getInt("REQUEST_ID"), rs.getString("EMAIL_ID"));
			}

		} catch (Exception e) {
			logger.error("Error in getWaitingRequestWithOldTime :: ", e);
			return null;
		}
		logger.info("getWaitingRequestWithOldTime End :: ");
		return resultMap;
	}

	@Override
	public List<InconsistentFUGR_Download> getInconsistentFUGRList(Long requestId) {
		List<InconsistentFUGR_Download> inconsistentFUGRList = null;
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(InconsistentFUGR_Download.class);
			criteria.add(Restrictions.eq("requestId", requestId));
			inconsistentFUGRList = criteria.list();
		} catch (Exception e) {
			logger.error("Error while fetching from Inconsistent FUGR table : ", e);
		} finally {
			if (session != null)
				session.close();
		}

		return inconsistentFUGRList;
	}

	@Override
	public List<ExtractedDatapojo> getTestingScope(long requestID) {
		Session session = null;
		List<ExtractedDatapojo> testingScopeList = null;
		try {
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(ExtractedDatapojo.class);

			ProjectionList projectionList = Projections.projectionList();
			projectionList.add(Projections.property("objecttype"), "objecttype");
			projectionList.add(Projections.property("objectname"), "objectname");
			projectionList.add(Projections.property("process"), "process");
			projectionList.add(Projections.property("applicationComponent"), "applicationComponent");
			projectionList.add(Projections.property("opercd"), "opercd");
			projectionList.add(Projections.property("appCompDesc"), "appCompDesc");
			projectionList.add(Projections.property("transactions"), "transactions");
			projectionList.add(Projections.property("role"), "role");

			criteria.add(Restrictions.eq("requestid", requestID));
			criteria.setProjection(Projections.distinct(projectionList));
			criteria.setResultTransformer(Transformers.aliasToBean(ExtractedDatapojo.class));
			testingScopeList = criteria.list();
		} catch (Exception e) {
			logger.error("Error while retrieving Testing Scope List !!! ", e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		} finally {
			if (null != session) {
				session.close();
			}
		}

		return testingScopeList;
	}

	@Override
	public List<S4_SID_Download> getS4SIDList(Long requestId) {
		List<S4_SID_Download> s4SIDList = null;
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(S4_SID_Download.class);
			criteria.add(Restrictions.eq("requestID", requestId));
			s4SIDList = criteria.list();
		} catch (Exception e) {
			logger.error("Error while fetching from S4 SID table : ", e);
		} finally {
			if (session != null)
				session.close();
		}

		return s4SIDList;
	}

	@Override
	public List<ImpactedVariant_Download> getImpactedVariantList(Long requestId) {
		List<ImpactedVariant_Download> impactedVariantList = null;
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(ImpactedVariant_Download.class);
			criteria.add(Restrictions.eq("requestID", requestId));
			impactedVariantList = criteria.list();
		} catch (Exception e) {
			logger.error("Error while fetching from Impacted Variant table : ", e);
		} finally {
			if (session != null)
				session.close();
		}

		return impactedVariantList;
	}

	@Override
	public List<S4ImpactedCustomTblDownload> getImpatctedCustTablesList(Long requestId) {
		List<S4ImpactedCustomTblDownload> impactCustTblList = null;
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(S4ImpactedCustomTblDownload.class);
			criteria.add(Restrictions.eq("requestId", requestId));
			impactCustTblList = criteria.list();
		} catch (Exception e) {
			logger.error("Error while fetching from S4 Impacted custom table download table : ", e);
		} finally {
			if (session != null)
				session.close();
		}

		return impactCustTblList;
	}

	@Override
	public List<BwCleanupUtilDownload> getBwCleanupUtilList(Long requestId) {
		List<BwCleanupUtilDownload> bwCleanUpList = null;
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(BwCleanupUtilDownload.class);
			criteria.add(Restrictions.eq("requestId", requestId));
			bwCleanUpList = criteria.list();
		} catch (Exception e) {
			logger.error("Error while fetching from Bw Clean up util download table : ", e);
		} finally {
			if (session != null)
				session.close();
		}

		return bwCleanUpList;
	}

	@Override
	public List<BwStandardExtractDownload> getBwStdExtrctList(Long requestId) {
		List<BwStandardExtractDownload> bwStdExtrList = null;
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(BwStandardExtractDownload.class);
			criteria.add(Restrictions.eq("requestId", requestId));
			bwStdExtrList = criteria.list();
		} catch (Exception e) {
			logger.error("Error while fetching from Bw Standard Extract download table : ", e);
		} finally {
			if (session != null)
				session.close();
		}

		return bwStdExtrList;
	}

	@Override
	public List<InactiveObjectsDownload> getInactiveObjectsList(Long requestId) {
		List<InactiveObjectsDownload> inaObjList = null;
		Session session = null;
		try {
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(InactiveObjectsDownload.class);
			criteria.add(Restrictions.eq("requestId", requestId));
			inaObjList = criteria.list();
		} catch (Exception e) {
			logger.error("Error while fetching from Inactive Objects download table : ", e);
		} finally {
			if (session != null)
				session.close();
		}

		return inaObjList;
	}

	@Override
	public List<CvitCustomisingLogsDownload> getcvitCustomLogsList(long requestId) {
		List<CvitCustomisingLogsDownload> cvitCustomLogsList = null;
		Session session = null;

		try {
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(CvitCustomisingLogsDownload.class);
			criteria.add(Restrictions.eq("requestId", requestId));
			cvitCustomLogsList = criteria.list();
		} catch (Exception e) {
			logger.error("Error while fetching data from cvit customising logs table : ", e);
		} finally {
			if (session != null)
				session.close();
		}

		return cvitCustomLogsList;
	}

	@Override
	public List<CvitErrorMessagesDownload> getcvitErrorMsgsList(long requestId) {
		List<CvitErrorMessagesDownload> cvitErrorMsgsList = null;
		Session session = null;

		try {
			session = sessionFactory.openSession();
			Criteria criteria = session.createCriteria(CvitErrorMessagesDownload.class);
			criteria.add(Restrictions.eq("requestId", requestId));
			cvitErrorMsgsList = criteria.list();
		} catch (Exception e) {
			logger.error("Error while fetching data from cvit error messages table : ", e);
		} finally {
			if (session != null)
				session.close();
		}

		return cvitErrorMsgsList;
	}
}