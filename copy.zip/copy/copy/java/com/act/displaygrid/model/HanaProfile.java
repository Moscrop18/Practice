/*MODIFIED 
 *FOR Enhancement CR-1.0:-Update the automation_Status according to Sel_line-20/12/16 -monika.mishra
 *
 *CR-13.0- New Output Sheet implementation - 03/03/2017 - monika.mishra
 *
 *CR-25.0- Few fields which will be moved to JAVA tool in HANA Profiler - 10/07/2017 - monika.mishra
 *
 *CR-26.0:-adding 3 New Sheets implementation -25/07/17-rohan.a.mehra
 *
 *CR-28.0:- Add col Total Line Scanned -24/07/17 -monika.mishra
 *
 *DEF041: -- Automation status should be 'No' where SKIP= X -01/03/2019 -himani.malhotra
 **/

package com.act.displaygrid.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang.StringUtils;
import org.hibernate.annotations.Index;

@Entity
@Table(name = "FINAL_OUTPUT")
public class HanaProfile implements Serializable {
	private static final long serialVersionUID = -1664086921273798940L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Integer Id;
	
	@Column(name = "Object_Type")
	private String Object_Type;

	@Index(name = "Obj_Name")
	@Column(name = "Obj_Name")
	private String Obj_Name;
	
	@Column(name = "Sub_Program")
	private String Sub_Program;
	
	@Column(name = "Used_Unused")
	private String Used_Unused;
	
	@Column(name = "Sub_Type")
	private String Sub_Type;
	
	@Column(name = "Line_Number")
	private Integer Line_Number;
	
	@Column(name = "operation_code")
	private String operation_code;
	
	@Index(name = "Index_Category")
	@Column(name = "Category")
	private String Category;
	
	@Column(name = "Subcategory")
	private String Subcategory;
	
	@Index(name = "Index_Opertaion")
	@Column(name = "Opertaion")
	private String Opertaion;
	
	@Column(name = "Levels")
	private Integer Levels;
	
	@Column(name = "TABLES_COLUMN")
	private String Tables;
	
	@Column(name = "Joins")
	private String Joins;
	
	@Column(name = "Table_Type")
	private String Table_Type;
	
	@Column(name = "KEYS_COLUMN", columnDefinition = "Text")
	private String Keys;
	
	@Column(name = "Where_Condition", columnDefinition = "Text")
	private String Where_Condition;
	
	@Column(name = "Join_Type")
	private String Join_Type;
	
	@Column(name = "Info", columnDefinition = "Text")
	private String Info;
	
	@Column(name = "impact")
	private String impact;
	
	@Column(name = "DB")
	private String DB;
	
	@Column(name = "CHANGE_COLUMN")
	private String Change;
	
	@Column(name = "LOOP_COLUMN")
	private String loop;
	
	@Column(name = "ReadProgram")
	private String ReadProgram;
	
	@Column(name = "JOIN_ID")
	private int joinID;
	
	@Column(name = "COMMENT_C")
	private String skipReason;
	
	@Column(name = "SKIP")
	private String skip;

	@Column(name = "IssueSecondSubCat")
	private String issueSecondSubCat;
	
	@Column(name = "External_Namespace")
	private String extNamespace = StringUtils.EMPTY;
	
	@Column(name = "Counter")
	private String counter;

	public String getIssueSecondSubCat() {
		return issueSecondSubCat;
	}

	public void setIssueSecondSubCat(String issueSecondSubCat) {
		this.issueSecondSubCat = issueSecondSubCat;
	}

	// DEF041: -- Automation status should be 'No' where SKIP= X
	public String getSkipReason() {
		return skipReason;
	}

	public void setSkipReason(String skipReason) {
		this.skipReason = skipReason;
	}

	public String getSkip() {
		return skip;
	}

	public void setSkip(String skip) {
		this.skip = skip;
	}

	// CR-1.0: -- add column Sel_line
	@Column(name = "SEL_LINE", columnDefinition = "Text")
	private String sel_Line;

	// CR-1.0: -- add column automation_status
	@Column(name = "automation_status")
	private String automation_status;

	// CR-13.0: -- add column high_lvl_desc
	@Column(name = "high_lvl_desc")
	private String high_lvl_desc;

	// CR-25.0 add col Code
	@Column(name = "code", columnDefinition = "Text")
	private String code;

	// CR-26.0: -- add column Odata
	@Column(name = "Odata")
	private String Odata;

	// CR-52.0
	@Index(name = "OBJ_NAME_TYPE")
	@Column(name = "OBJ_NAME_TYPE")
	private String objNameType;

	public String getObjNameType() {
		return objNameType;
	}

	public void setObjNameType(String objNameType) {
		this.objNameType = objNameType;
	}

	// CR-28.0 add col Total no.of line scanned
	@Column(name = "total_line_scanned")
	private String totalLineScanned;

	// AADT addition
	@Column(name = "OBJ_PACKAGE")
	private String OBJ_PACKAGE;

	@Column(name = "COMPLEXITY")
	private String COMPLEXITY;

	public String getCOMPLEXITY() {
		return COMPLEXITY;
	}

	public void setCOMPLEXITY(String cOMPLEXITY) {
		COMPLEXITY = cOMPLEXITY;
	}

	public String getOBJ_PACKAGE() {
		return OBJ_PACKAGE;
	}

	public void setOBJ_PACKAGE(String oBJ_PACKAGE) {
		OBJ_PACKAGE = oBJ_PACKAGE;
	}

	@Column(name = "Request_ID")
	@Index(name = "Index_Request_id")
	private Long requestID;

	public Long getRequestID() {
		return requestID;
	}

	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}

	public String getReadProgram() {
		return ReadProgram;
	}

	public void setReadProgram(String readProgram) {
		ReadProgram = readProgram;
	}

	public String getLoop() {
		return loop;
	}

	public void setLoop(String loop) {
		this.loop = loop;
	}

	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
		Id = id;
	}

	public String getObject_Type() {
		return Object_Type;
	}

	public void setObject_Type(String object_Type) {
		Object_Type = object_Type;
	}

	public String getObj_Name() {
		return Obj_Name;
	}

	public void setObj_Name(String obj_Name) {
		Obj_Name = obj_Name;
	}

	public String getSub_Program() {
		return Sub_Program;
	}

	public void setSub_Program(String sub_Program) {
		Sub_Program = sub_Program;
	}

	public String getUsed_Unused() {
		return Used_Unused;
	}

	public void setUsed_Unused(String used_Unused) {
		Used_Unused = used_Unused;
	}

	/*
	 * public String getDialog_Steps() { return Dialog_Steps; }
	 * 
	 * public void setDialog_Steps(String dialog_Steps) { Dialog_Steps =
	 * dialog_Steps; }
	 */
	public String getSub_Type() {
		return Sub_Type;
	}

	public void setSub_Type(String sub_Type) {
		Sub_Type = sub_Type;
	}

	public Integer getLine_Number() {
		return Line_Number;
	}

	public void setLine_Number(Integer line_Number) {
		Line_Number = line_Number;
	}

	public String getOperation_code() {
		return operation_code;
	}

	public void setOperation_code(String operation_code) {
		this.operation_code = operation_code;
	}

	public String getCategory() {
		return Category;
	}

	public void setCategory(String category) {
		Category = category;
	}

	public String getSubcategory() {
		return Subcategory;
	}

	public void setSubcategory(String subcategory) {
		Subcategory = subcategory;
	}

	public String getOpertaion() {
		return Opertaion;
	}

	public void setOpertaion(String opertaion) {
		Opertaion = opertaion;
	}

	public Integer getLevels() {
		return Levels;
	}

	public void setLevels(Integer levels) {
		Levels = levels;
	}

	public String getTables() {
		return Tables;
	}

	public void setTables(String tables) {
		Tables = tables;
	}

	public String getJoins() {
		return Joins;
	}

	public void setJoins(String joins) {
		Joins = joins;
	}

	public String getTable_Type() {
		return Table_Type;
	}

	public void setTable_Type(String table_Type) {
		Table_Type = table_Type;
	}

	public String getKeys() {
		return Keys;
	}

	public void setKeys(String keys) {
		Keys = keys;
	}

	public String getWhere_Condition() {
		return Where_Condition;
	}

	public void setWhere_Condition(String where_Condition) {
		Where_Condition = where_Condition;
	}

	public String getJoin_Type() {
		return Join_Type;
	}

	public void setJoin_Type(String join_Type) {
		Join_Type = join_Type;
	}

	public String getInfo() {
		return Info;
	}

	public void setInfo(String info) {
		Info = info;
	}

	public String getImpact() {
		return impact;
	}

	public void setImpact(String impact) {
		this.impact = impact;
	}

	public String getDB() {
		return DB;
	}

	public void setDB(String dB) {
		DB = dB;
	}

	public String getChange() {
		return Change;
	}

	public void setChange(String change) {
		Change = change;
	}

	public int getJoinID() {
		return joinID;
	}

	public void setJoinID(int joinID) {
		this.joinID = joinID;
	}
	// CR-1.0:

	public String getSel_Line() {
		return sel_Line;
	}

	public void setSel_Line(String sel_Line) {
		this.sel_Line = sel_Line;
	}

	public String getAutomation_status() {
		return automation_status;
	}

	public void setAutomation_status(String automation_status) {
		this.automation_status = automation_status;
	}

	public String getHigh_lvl_desc() {
		return high_lvl_desc;
	}

	public void setHigh_lvl_desc(String high_lvl_desc) {
		this.high_lvl_desc = high_lvl_desc;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	// CR-26:

	public String getOdata() {
		return Odata;
	}

	public void setOdata(String Odata) {
		this.Odata = Odata;
	}

	public String getTotalLineScanned() {
		return totalLineScanned;
	}

	public void setTotalLineScanned(String totalLineScanned) {
		this.totalLineScanned = totalLineScanned;
	}
	
	public String getExtNamespace() {
		return extNamespace;
	}

	public void setExtNamespace(String extNamespace) {
		this.extNamespace = extNamespace;
	}

	public String getCounter() {
		return counter;
	}

	public void setCounter(String counter) {
		this.counter = counter;
	}

	@Column(name = "RICEF_CATEGORY")
	private String ricefCategory;

	public String getRicefCategory() {
		return ricefCategory;
	}

	public void setRicefCategory(String ricefCategory) {
		this.ricefCategory = ricefCategory;
	}
	
	@Column(name="Ricef_Sub_Category")
	private String ricefSubCategory;

	public String getRicefSubCategory() {
		return ricefSubCategory;
	}

	public void setRicefSubCategory(String ricefSubCategory) {
		this.ricefSubCategory = ricefSubCategory;
	}
}
