/**
 * 
 * @author rohan.a.mehra
 * 
 */

package com.act.displaygrid.model;
import java.io.IOException;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.act.S4.dao.DisplayGraphS4DAOImpl;
import com.act.utility.CustomBasicDataSourceEncryptor;
import com.act.utility.HANAUtility;


public class DBConfig {

	 final public static Logger logger = LoggerFactory.getLogger(DisplayGraphS4DAOImpl.class);
	 // For all the class Generic code
	 public static java.sql.Connection getJDBCConnection(HttpSession session) {
			String jdbcUrl = null,username = null,password = null;
			
			String Filename=GetJdbcProperties(session);

			try {
				jdbcUrl  = HANAUtility.getPropertyValueEnv(Filename, "jdbcUrl");
				username = HANAUtility.getPropertyValueEnv(Filename, "username");
			    password = CustomBasicDataSourceEncryptor.decrypt(HANAUtility.getPropertyValueEnv(Filename, "password"));
			} catch (IOException e1) {
				logger.error("Error !!! " + e1);
			}
			java.sql.Connection conn = null;
			try {
				conn = DriverManager.getConnection(jdbcUrl, username, password);

			} catch (SQLException e) {
				logger.error("SQL Error occured while getting JDBC connection : " , e);
			} catch (Exception e) {
				logger.error("Error !!! " + e);
			}
			return conn;
		}
		
		//This function return the file name to the corresponding Environment
			public static String GetJdbcProperties(HttpSession session)  {
				
				String FileName=null;
				String Enviroment=(String) session.getAttribute("Enviroment");
				logger.info("::::::::::::::Enviroment--"+Enviroment);
				if (Enviroment.equals(""))
				{
					FileName="DB_Dev.properties";
		     	}
				else if (Enviroment.equals(""))
				{
					FileName="DB_Prd.properties";
				}
				else if (Enviroment.equals(""))
				{
					FileName="DB_Stage.properties";
				}
				else if (Enviroment.equals(""))
				{
					FileName="DB_Localhost.properties";
		     	}
				logger.info("::::::::::::::File Name--"+FileName);		
				return FileName;	
			}
			
} 