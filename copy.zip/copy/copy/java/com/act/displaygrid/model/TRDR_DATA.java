package com.act.displaygrid.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="TR_DR_RECORDS")
public class TRDR_DATA {
	
	@Id
	@GenericGenerator(name="kaugen" , strategy="increment")
	@GeneratedValue(generator="kaugen")
	@Column(name="ID")
	private Integer id;
	@Column(name="NAME")
	private String name;
	

	@Column(name="Request_ID")
	private Long requestID;
	
	public Long getRequestID() {
		return requestID;
	}
	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getSubc() {
		return subc;
	}
	public void setSubc(String subc) {
		this.subc = subc;
	}

	@Column(name="SUBC")
	private String subc;
	
	

}
