/*
 * CR-9.0:- Manual upload for Estimator & assuptions(Created New Table in DB) -17/01/17 -monika.mishra*/

package com.act.displaygrid.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="HANA_ASSUMPTION")
public class HanaAssumption {
	
	@Id	
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "ID")
	private Integer Id;
	
	@Column(columnDefinition="TEXT", name="ASSUMPTIONS")
	private String assumptions;
	
	@Column(name = "Request_ID",nullable=false,unique=true)
	private Long requestID;

	

	public String getAssumptions() {
		return assumptions;
	}

	public void setAssumptions(String assumptions) {
		this.assumptions = assumptions;
	}

	public Long getRequestID() {
		return requestID;
	}

	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}

}
