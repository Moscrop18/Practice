package com.act.smodilog.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "smodilogfunction")
public class SmodilogFunction {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Id")
	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getObjType() {
		return objType;
	}

	public void setObjType(String objType) {
		this.objType = objType;
	}

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public String getSubName() {
		return subName;
	}

	public void setSubName(String subName) {
		this.subName = subName;
	}

	public String getIntType() {
		return intType;
	}

	public void setIntType(String intType) {
		this.intType = intType;
	}

	public String getIntName() {
		return intName;
	}

	public void setIntName(String intName) {
		this.intName = intName;
	}

	public String getModUser() {
		return modUser;
	}

	public void setModUser(String modUser) {
		this.modUser = modUser;
	}

	public String getModDate() {
		return modDate;
	}

	public void setModDate(String modDate) {
		this.modDate = modDate;
	}

	public String getModTime() {
		return modTime;
	}

	public void setModTime(String modTime) {
		this.modTime = modTime;
	}

	public String getTrkorr() {
		return trkorr;
	}

	public void setTrkorr(String trkorr) {
		this.trkorr = trkorr;
	}

	public Long getRequestId() {
		return requestId;
	}

	public void setRequestId(Long requestId) {
		this.requestId = requestId;
	}

	@Column(name = "OBJ_TYPE")
	private String objType;

	@Column(name = "OBJ_NAME")
	private String objName;

	@Column(name = "SUB_TYPE")
	private String subType;

	@Column(name = "SUB_NAME")
	private String subName;

	@Column(name = "INT_TYPE")
	private String intType;

	@Column(name = "INT_NAME")
	private String intName;

	@Column(name = "MOD_USER")
	private String modUser;

	@Column(name = "MOD_DATE")
	private String modDate;

	@Column(name = "MOD_TIME")
	private String modTime;

	@Column(name = "TRKORR")
	private String trkorr;

	@Column(name = "Request_Id")
	@Index(name = "Index_Request_id")
	private Long requestId;
	
	@Column(name = "Obj_Name_Type")
	private String objNameType;
	
	@Column(name = "SPDD_Objects")
	private String spddObjects;
	
	@Column(name = "SPAU_Objects")
	private String spauObjects;

	public String getObjNameType() {
		return objNameType;
	}

	public void setObjNameType(String objNameType) {
		this.objNameType = objNameType;
	}

	public String getSpddObjects() {
		return spddObjects;
	}

	public void setSpddObjects(String spddObjects) {
		this.spddObjects = spddObjects;
	}

	public String getSpauObjects() {
		return spauObjects;
	}

	public void setSpauObjects(String spauObjects) {
		this.spauObjects = spauObjects;
	}

}
