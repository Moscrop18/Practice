package com.act.securityAnalyser.dao;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.act.S4.models.GrtGracfuncact;
import com.act.S4.models.InventoryList_Download;
import com.act.S4.models.SaFioriReportDownload;
import com.act.S4.models.SaGrcReportDownload;
import com.act.S4.models.SaObjectReportDownload;
import com.act.S4.models.SaUserAndRoleAssignment;
import com.act.S4.models.SecurityAnalyserTCDReportDownload;
import com.act.S4.models.SrcAgr1251;
import com.act.S4.models.SrcAgrUsers;
import com.act.S4.models.SrcUsobtc;
import com.act.constant.File_Size_Constant;
import com.act.constant.Hana_Profiler_Constant;
import com.act.displaygrid.model.DBConfig;
import com.act.exceptions.HibernateException;

public class SecurityAnalyserDAOimpl implements SecurityAnalyserDAO {

	final static Logger logger = LoggerFactory.getLogger(SecurityAnalyserDAOimpl.class);
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory){
		this.sessionFactory=sessionFactory;
	}
	

	
	@Override
	public String securityAnalyserSrcAgrBatchInsertUpdate(List<SrcAgr1251> srcAgr1251List, HttpSession session)
			throws SQLException {
		logger.debug("securityAnalyserSrcAgrBatchInsertUpdate() Started ");

		final String INSERT_SQL = "INSERT INTO Src_Agr1251 (MANDT,AGR_NAME,OBJECT,FIELD,LOW,HIGH,MODIFIED,DELETED,COPIED,Request_Id) values (?, ?, ?, ?, ?, ?, ?, ? , ?, ? )";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		//deleteSiaTableData(session, "Src_Agr1251");
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;
				
				for (SrcAgr1251 srcAgr1251 : srcAgr1251List) {
					if(srcAgr1251.getLow().length() > 255) {
						continue;
					}
					stmt.setString(1, srcAgr1251.getMandt());
					stmt.setString(2, srcAgr1251.getAgrName());
					stmt.setString(3, srcAgr1251.getObject());
					stmt.setString(4, srcAgr1251.getField());
					stmt.setString(5, srcAgr1251.getLow());
					stmt.setString(6, srcAgr1251.getHigh());
					stmt.setString(7, srcAgr1251.getModified());
					stmt.setString(8, srcAgr1251.getDeleted());
					stmt.setString(9, srcAgr1251.getCopied());
					stmt.setInt(10, srcAgr1251.getRequestID());
										
					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("Security Analyser Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error("Error in securityAnalyserSrcAgrBatchInsertUpdate() - ",e);
				throw e;
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error("Error in securityAnalyserSrcAgrBatchInsertUpdate() - ",e);
			throw e;

		} finally {
			stmt.close();
			conn.close();
		}

		logger.debug("securityAnalyserSrcAgrBatchInsertUpdate() End ");
		return result;

	}

	@Override
	public String securityAnalyserSourceUSOBTCBatchInsertUpdate(List<SrcUsobtc> srcUsobtcList, HttpSession session)
			throws SQLException {
		logger.debug(":: securityAnalyserSourceUSOBTCBatchInsertUpdate() Start :: ");

		final String INSERT_SQL = "INSERT INTO Src_Usobtc (NAME,OBJECT,FIELD,LOW,HIGH,requestId) values (?, ?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		//deleteSiaTableData(session, "Src_Usobtc");
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;
				
				for (SrcUsobtc srcUsobtc : srcUsobtcList) {
					stmt.setString(1, srcUsobtc.getName());
					stmt.setString(2, srcUsobtc.getObject());
					stmt.setString(3, srcUsobtc.getField());
					stmt.setString(4, srcUsobtc.getLow());
					stmt.setString(5, srcUsobtc.getHigh());
					stmt.setInt(6, srcUsobtc.getRequestID());
										
					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("Security Analyser source USOBTC Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error("Error in securityAnalyserSourceUSOBTCBatchInsertUpdate - ",e);
				throw e;
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error("Error in securityAnalyserSourceUSOBTCBatchInsertUpdate - ",e);
			throw e;

		} finally {
			stmt.close();
			conn.close();
		}
		logger.debug(":: securityAnalyserSourceUSOBTCBatchInsertUpdate() End :: ");
		return result;

	}

	@Override
	public void deleteSiaTableData(HttpSession session, String tableName) {
		logger.debug(":: deleteSiaTableData() Start :: ");

		final String DELETE_SQL = "truncate table "+tableName;

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.Statement stmt = null;
		

			conn = DBConfig.getJDBCConnection(session);
			try {
				conn.setAutoCommit(false);
			
			
				stmt =  conn.createStatement();
				stmt.executeUpdate(DELETE_SQL);
				
			} catch (SQLException e) {
				logger.error("deleteSiaTableData :: ",e);
			}
			
		logger.debug(":: deleteSiaTableData() End :: ");
		
	}

	@Override
	public String securityAnalyserAgrUsersBatchInsertUpdate(List<SrcAgrUsers> SrcAgrUsersList, HttpSession session)
			throws SQLException {
		logger.debug(":: securityAnalyserAgrUsersBatchInsertUpdate() Start :: ");

		final String INSERT_SQL = "INSERT INTO Src_AgrUsers (Role,User_Name,Request_Id) values (?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		//deleteSiaTableData(session, "Src_Usobtc");
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;
				
				for (SrcAgrUsers srcAgrUser : SrcAgrUsersList) {
					stmt.setString(1, srcAgrUser.getRole());
					stmt.setString(2, srcAgrUser.getUserName());
					stmt.setInt(3, srcAgrUser.getRequestID());
										
					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("Security Analyser Agr Users Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error("Error in securityAnalyserAgrUsersBatchInsertUpdate - ",e);
				throw e;
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error("Error in securityAnalyserAgrUsersBatchInsertUpdate - ",e);
			throw e;

		} finally {
			stmt.close();
			conn.close();
		}
		logger.debug(":: securityAnalyserAgrUsersBatchInsertUpdate() End :: ");
		return result;

	}

	@Override
	public void getSecurityAnalyserReportsFromSP(HttpSession session, Long requestID) throws Exception {
		logger.info("getSecurityAnalyserReportsFromSP Started :: ");
		java.sql.Connection conn = DBConfig.getJDBCConnection(session);
		try {
			String tarVer = "";
			//String sqlTcd = "delete from Sa_Tcd_Report_Trans where Request_ID="+requestID;
			//String sqlObj = "delete from Sa_Object_Report_Trans where Request_ID="+requestID;
			tarVer = getSecurityTargetVersion(requestID, tarVer, conn);
			
			//deleteTcdReportData(sqlTcd, conn);
			deleteReportData("Sa_Tcd_Report_Trans",requestID, conn);
			      logger.info("TCD Report Sp execution start at  :: "+new Timestamp(System.currentTimeMillis()));
			      logger.info("Request ID :: "+requestID);
			CallableStatement cStmtTcd = conn.prepareCall("{call sa_tcd_report_prd(?,?)}");
			cStmtTcd.setLong(1, requestID);
			cStmtTcd.setString(2, tarVer);
			boolean hadResultsTcd = cStmtTcd.execute();
			if (!cStmtTcd.isClosed()) {
				cStmtTcd.close();
			}
			logger.info("TCD Report Sp execution End at  :: "+new Timestamp(System.currentTimeMillis()));
			if(!hadResultsTcd) {
				logger.info("TCD Report Sp executed successfully :: ");
			}
			//deleteObjectReportData(sqlObj, conn);
			deleteReportData("Sa_Object_Report_Trans",requestID, conn);
		      logger.info("Object Report Sp execution start at  :: "+new Timestamp(System.currentTimeMillis()));
			CallableStatement cStmtObject = conn.prepareCall("{call sa_object_report_prd(?,?)}");
			cStmtObject.setLong(1, requestID);
			cStmtObject.setString(2, tarVer);
			boolean hadResultsObject = cStmtObject.execute();
			logger.info("Object Report Sp execution End at  :: "+new Timestamp(System.currentTimeMillis()));
			if(!hadResultsObject) {
				logger.info("Object Report Sp executed successfully :: ");
			}
			
			deleteReportData("sa_fiori_report_trans",requestID, conn);
		      logger.info("fiori report Sp execution start at  :: "+new Timestamp(System.currentTimeMillis()));
			CallableStatement cStmtFiori = conn.prepareCall("{call sa_Fiori_report(?,?)}");
			cStmtFiori.setLong(1, requestID);
			cStmtFiori.setString(2, tarVer);
			boolean hadResultsFiori = cStmtFiori.execute();
			logger.info("fiori report Sp execution End at  :: "+new Timestamp(System.currentTimeMillis()));
			if(!hadResultsFiori) {
				logger.info("fiori Report Sp executed successfully :: ");
			}
			getUserAndRoleAssignmentReport(conn,requestID);
			transferDataFromTransToTcdDwnldTbl(session);
			transferDataFromTransToObjDwnldTbl(session);
			transferDataFromTransToFioriDwnldTbl(session);
			//deleteTcdReportData(sqlTcd, conn);
			deleteReportData("Sa_Tcd_Report_Trans",requestID, conn);
			//deleteObjectReportData(sqlObj, conn);
			deleteReportData("Sa_Object_Report_Trans",requestID, conn);
			deleteReportData("sa_fiori_report_trans",requestID, conn);
			clearSaInputTablesAfterSpProcess(requestID, conn);
			calculateNumberOutputFiles(session, requestID);
		}catch (Exception e) {
			logger.error("getSecurityAnalyserReportsFromSP :: ",e);
			throw e;
		}finally {
			conn.close();
		}
		logger.info("getSecurityAnalyserReportsFromSP Ended :: ");
	}
	private void deleteReportData(String table,Long requestID, java.sql.Connection conn) throws SQLException {
		String stmt="delete from "+table+"  where Request_ID= ?";
		PreparedStatement stmtData = conn.prepareStatement(stmt);
		stmtData.setLong(1, requestID);
		stmtData.executeUpdate();
		if (!stmtData.isClosed()) {
			stmtData.close();
		}
		      logger.info(table+" table data deleted successfully");
	}

	private void deleteObjectReportData(String sqlObj, java.sql.Connection conn) throws SQLException {
		Statement stmtObj = conn.createStatement();
		stmtObj.executeUpdate(sqlObj);
		  logger.info("Sa_Object_Report_Download data deleted successfully");
	}


	private void deleteTcdReportData(String sqlTcd, java.sql.Connection conn) throws SQLException {
		Statement stmtTcd = conn.createStatement();
		stmtTcd.executeUpdate(sqlTcd);
		if (!stmtTcd.isClosed()) {
			stmtTcd.close();
		}
		      logger.info("Sa_Tcd_Report_Download data deleted successfully");
	}


	private String getSecurityTargetVersion(Long requestID, String tarVer, java.sql.Connection conn)
			throws SQLException {
		String queryStr = "select Security_Version from request_form where Request_ID= ?";
		PreparedStatement stmtSecVer = conn.prepareStatement(queryStr);
		stmtSecVer.setLong(1, requestID);
		ResultSet rs = stmtSecVer.executeQuery();
		while (rs.next()) {
			tarVer = rs.getString("Security_Version");
		}
		return tarVer;
	}


	private void getUserAndRoleAssignmentReport(java.sql.Connection conn, Long requestId) throws SQLException {
		try{
		logger.info("getUserAndRoleAssignmentReport execution start at  :: "+new Timestamp(System.currentTimeMillis()));
		logger.info(":: getUserAndRoleAssignmentReport Started ::");
		StringBuilder queryStr = new StringBuilder("Insert into sa_user_role_download (Role_Name,User_name,Request_Id) select distinct Role,User_Name as UserID,sa.Request_Id  from src_agrusers sa inner join sa_tcd_report_trans st on st.AGR_NAME = sa.Role and st.Request_ID=sa.Request_Id where st.Request_ID="+requestId+" order by sa.User_name,sa.Role");
		Statement stmtAgrUsers = conn.createStatement();
		stmtAgrUsers.executeUpdate(queryStr.toString());
		logger.info(":: Sa_User_And_Role_Assignment data inserted succcessfully ::");
		logger.info(":: getUserAndRoleAssignmentReport Ended ::");
		logger.info("getUserAndRoleAssignmentReport execution End at  :: "+new Timestamp(System.currentTimeMillis()));
		}catch (Exception e) {
			logger.error("getUserAndRoleAssignmentReport :: ",e);
			throw e;
		}

	}


	private void clearSaInputTablesAfterSpProcess(Long requestID, java.sql.Connection conn) throws SQLException {
		try{
		logger.info("clearSaInputTablesAfterSpProcess Started :: ");
		String sqlSrcAgr1251 = "delete from Src_Agr1251 where Request_ID= ?";
		String sqlSrcAgrUsers = "delete from Src_AgrUsers where Request_Id= ?";
		String sqlSrcUsobtc = "delete from Src_Usobtc where requestID= ?";
		
		PreparedStatement stmtSrcAgr1251 = conn.prepareStatement(sqlSrcAgr1251);
		stmtSrcAgr1251.setLong(1, requestID);
		stmtSrcAgr1251.executeUpdate();
		logger.info("Src_Agr1251 data deleted successfully after Sp processing");

		PreparedStatement stmtSrcAgrUsers = conn.prepareStatement(sqlSrcAgrUsers);
		stmtSrcAgrUsers.setLong(1, requestID);
		stmtSrcAgrUsers.executeUpdate();
		logger.info("Src_AgrUsers data deleted successfully after Sp processing");

		PreparedStatement stmtSrcUsobtc = conn.prepareStatement(sqlSrcUsobtc);
		stmtSrcUsobtc.setLong(1, requestID);
		stmtSrcUsobtc.executeUpdate();
		logger.info("Src_Usobtc data deleted successfully after Sp processing");
		}catch (Exception e) {
			logger.error("Error in clearSaInputTablesAfterSpProcess :: ",e);
			throw e;
		}
		logger.info("clearSaInputTablesAfterSpProcess Ended :: ");
	}
	
	private void clearGrcInputTablesAfterSpProcess(Long requestID, java.sql.Connection conn) throws SQLException {
		try{
		logger.info("clearSaInputTablesAfterSpProcess Started :: ");
		String sqlGrcClient = "delete from grc_clientdata where Request_ID= ?";
		
		
		PreparedStatement stmtGrcClient = conn.prepareStatement(sqlGrcClient);
		stmtGrcClient.setLong(1, requestID);
		stmtGrcClient.executeUpdate();
		logger.info("grc_clientdata data deleted successfully after Sp processing");

		}catch (Exception e) {
			logger.error("Error in clearGrcInputTablesAfterSpProcess :: ",e);
			throw e;
		}
		logger.info("clearGrcInputTablesAfterSpProcess Ended :: ");
	}


	@Override
	public List<SecurityAnalyserTCDReportDownload> getSaTcdReport(Integer requestId, int count) {
		Session session=sessionFactory.openSession();
		int maxResult = File_Size_Constant.SA_REPORT_MAX_SIZE;//keep this const file
		int offset = maxResult*count-maxResult;
		try{
			final Criteria criteria=session.createCriteria(SecurityAnalyserTCDReportDownload.class);
			criteria.add(Restrictions.eq("requestID", requestId));
			criteria.setFirstResult(offset);
			criteria.setMaxResults(maxResult);
			return criteria.list();
		}catch(Exception e){
			logger.error("getSaTcdReport :: ",e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}finally{
			if(null != session)
				session.close();
		}
	}
@Override
public List<SaObjectReportDownload> getSaObjReport(Integer requestId,int count) {
	Session session=sessionFactory.openSession();
	int maxResult = File_Size_Constant.SA_REPORT_MAX_SIZE;//keep this const file
	int offset = maxResult*count-maxResult;
	try{
		final Criteria criteria=session.createCriteria(SaObjectReportDownload.class);
		criteria.add(Restrictions.eq("requestId", requestId));
		criteria.setFirstResult(offset);
		criteria.setMaxResults(maxResult);
		return criteria.list();
	}catch(Exception e){
		logger.error("getSaObjReport :: ",e);
		throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
	}finally{
		if(null != session)
			session.close();
	}
}


@Override
public List<SaUserAndRoleAssignment> getSaUserAndRoleReportDownload(Integer requestId) {
	Session session=sessionFactory.openSession();

	try{
		final Criteria criteria=session.createCriteria(SaUserAndRoleAssignment.class);
		criteria.add(Restrictions.eq("requestId", requestId));
		return criteria.list();
	}catch(Exception e){
		logger.error("getSaUserAndRoleReportDownload :: ",e);
		throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
	}finally{
		if(null != session)
			session.close();
	}
}


	@Override
	public void transferDataFromTransToTcdDwnldTbl(HttpSession session) throws SQLException {
		StringBuilder qryStr = new StringBuilder();
		qryStr.append("Insert into Sa_Tcd_Report_Download (targetVersion,AGR_NAME,LOW,HIGH,newTcode,functional_area,status,Request_ID) select targetVersion,AGR_NAME,LOW,HIGH,newTcode,functional_area,status,Request_ID from Sa_Tcd_Report_Trans");
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		//deleteSiaTableData(session, "Src_Usobtc");
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(qryStr.toString());
				stmt.execute();
				conn.commit();
				logger.info("TCD Report Data from trans to download table INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error("Error in transferDataFromTransToDwnldTbl - ",e);
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error("Error in transferDataFromTransToDwnldTbl - ",e);

		} finally {
			stmt.close();
			conn.close();
		}
	}


	@Override
	public void transferDataFromTransToObjDwnldTbl(HttpSession session) throws SQLException {
		StringBuilder qryStr = new StringBuilder();
		qryStr.append("Insert into Sa_Object_Report_Download (Request_ID,Targetversion,functional_area,Agr_name,OldTCode,OldObj,OldField,OldLow,OldHigh,OldOBjValues,NewTCode,NewObj,NewField,NewLow,NewHigh,Proposed) select Request_ID,Targetversion,functional_area,Agr_name,OldTCode,OldObj,OldField,OldLow,OldHigh,OldOBjValues,NewTCode,NewObj,NewField,NewLow,NewHigh,Proposed from Sa_Object_Report_Trans");
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		//deleteSiaTableData(session, "Src_Usobtc");
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(qryStr.toString());
				stmt.execute();
				conn.commit();
				logger.info("Object Report Data from trans to download table INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error("Error in transferDataFromTransToObjDwnldTbl - ",e);
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error("Error in transferDataFromTransToObjDwnldTbl - ",e);

		} finally {
			stmt.close();
			conn.close();
		}
	}


	@Override
	public void transferDataFromTransToFioriDwnldTbl(HttpSession session) throws SQLException {
		StringBuilder qryStr = new StringBuilder();
		qryStr.append("Insert into sa_fiori_report_download (AGR_NAME,AppName_NewTcode,AppName_OldTcode,ApplicationType_NewTcode,ApplicationType_OldTcode,FioriID_NewTcode,FioriID_OldTcode,FrontendProductVersion_OldTcode,FrontendProductVersion_NewTcode,functional_area,HIGH,LOW,NewTcode,ProductVersionNameBackend_NewTcode,ProductVersionNameBackend_OldTcode,Request_ID,Status,targetVersion) select AGR_NAME,AppName_NewTcode,AppName_OldTcode,ApplicationType_NewTcode,ApplicationType_OldTcode,FioriID_NewTcode,FioriID_OldTcode,FrontendProductVersion_OldTcode,FrontendProductVersion_NewTcode,functional_area,HIGH,LOW,NewTcode,ProductVersionNameBackend_NewTcode,ProductVersionNameBackend_OldTcode,Request_ID,Status,targetVersion from sa_fiori_report_trans");
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		//deleteSiaTableData(session, "Src_Usobtc");
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(qryStr.toString());
				stmt.execute();
				conn.commit();
				logger.info("Fiori Report Data from trans to download table INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error("Error in transferDataFromTransToFioriDwnldTbl - ",e);
				throw e;
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error("Error in transferDataFromTransToFioriDwnldTbl - ",e);
			throw e;

		} finally {
			stmt.close();
			conn.close();
		}
		
	}


	@Override
	public List<SaFioriReportDownload> getSaFioriReportDownload(Integer requestId, int count) {
		Session session=sessionFactory.openSession();
		int maxResult = File_Size_Constant.SA_REPORT_MAX_SIZE;//keep this const file
		int offset = maxResult*count-maxResult;
		try{
			final Criteria criteria=session.createCriteria(SaFioriReportDownload.class);
			criteria.add(Restrictions.eq("requestId", Long.valueOf(requestId)));
			criteria.setFirstResult(offset);
			criteria.setMaxResults(maxResult);
			return criteria.list();
		}catch(Exception e){
			logger.error("getSaFioriReportDownload :: ",e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}finally{
			if(null != session)
				session.close();
		}
	}


	@Override
	public String securityAnalyserGrcDetailsBatchInsertUpdate(List<GrtGracfuncact> grcList, HttpSession session)
			throws SQLException {
		logger.debug("securityAnalyserGrcDetailsBatchInsertUpdate() Started ");

		final String INSERT_SQL = "INSERT INTO grc_clientdata (Mandt,Functid,action,connector,active,Request_Id) values (?, ?, ?, ?, ?, ?)";

		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		//deleteSiaTableData(session, "Src_Agr1251");
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(INSERT_SQL);
				int batch = 1;
				
				for (GrtGracfuncact grc : grcList) {
					stmt.setString(1, grc.getMandt());
					stmt.setString(2, grc.getFunc());
					stmt.setString(3, grc.getAction());
					stmt.setString(4, grc.getConnector());
					stmt.setString(5, grc.getActive());
					stmt.setLong(6,grc.getRequestId());
										
					// Add statement to batch
					stmt.addBatch();
					counter++;
					// Execute batch of 10000 records
					if (counter % 10000 == 0) {
						counter = 0;
						stmt.executeBatch();
						conn.commit();
						logger.info("Batch " + (batch++) + " executed successfully");
					}
				}

				stmt.executeBatch();
				conn.commit();
				logger.info("Security Analyser GRC Data INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error("Error in securityAnalyserGrcDetailsBatchInsertUpdate() - ",e);
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error("Error in securityAnalyserGrcDetailsBatchInsertUpdate() - ",e);

		} finally {
			stmt.close();
			conn.close();
		}

		logger.debug("securityAnalyserGrcDetailsBatchInsertUpdate() End ");
		return result;

	}
	
	@Override
	public void getSecurityAnalyserGrcReportFromSP(HttpSession session, Long requestID) throws Exception {
		logger.info("getSecurityAnalyserGrcReportFromSP GRC Started :: ");
		java.sql.Connection conn = DBConfig.getJDBCConnection(session);
		try {
			
			deleteReportData("sa_grc_report_trans",requestID, conn);
			      logger.info("GRC Report Sp execution start at  :: "+new Timestamp(System.currentTimeMillis()));
			      logger.info("Request ID :: "+requestID);
			CallableStatement cStmtTcd = conn.prepareCall("{call sa_grc_report(?)}");
			cStmtTcd.setLong(1, requestID);
			boolean hadResultsTcd = cStmtTcd.execute();
			if (!cStmtTcd.isClosed()) {
				cStmtTcd.close();
			}
			logger.info("GRC Report Sp execution End at  :: "+new Timestamp(System.currentTimeMillis()));
			if(!hadResultsTcd) {
				logger.info("GRC Report Sp executed successfully :: ");
			}
			
			transferDataFromTransToGrcDwnldTbl(session,requestID);
			deleteReportData("sa_grc_report_trans",requestID, conn);
			
			clearGrcInputTablesAfterSpProcess(requestID, conn);
		}catch (Exception e) {
			logger.error("getSecurityAnalyserGrcReportFromSP :: ",e);
			throw e;
		}finally {
			conn.close();
		}
		logger.info("getSecurityAnalyserGrcReportFromSP GRC Ended :: ");
		
	}


	@Override
	public void transferDataFromTransToGrcDwnldTbl(HttpSession session, Long requestId) throws SQLException {
		StringBuilder qryStr = new StringBuilder();
		qryStr.append("Insert into sa_grc_report_download (Cli_Mandt,Cli_FunctId,Cli_Action,Cli_Connector,Mast_FunctId,Mast_Action,Mast_Connector,New_Proposed_Actions_for_CF,Status,Connector_Name,Request_Id) select Cli_Mandt,Cli_FunctId,Cli_Action,Cli_Connector,Mast_FunctId,Mast_Action,Mast_Connector,New_Proposed_Actions_for_CF,Status,Connector_Name,Request_Id from sa_grc_report_trans where Request_Id=?");
		String result = "SUCCESS";
		java.sql.Connection conn = null;
		java.sql.PreparedStatement stmt = null;
		try {

			conn = DBConfig.getJDBCConnection(session);
			int counter = 1;
			conn.setAutoCommit(false);
			try {
				stmt = conn.prepareStatement(qryStr.toString());
				stmt.setLong(1, requestId);
				stmt.execute();
				conn.commit();
				logger.info("GRC Report Data from trans to download table INSERTED SUCCESSFULLY");

			} catch (Exception e) {
				result = "FAILURE in insert";
				logger.error("Error in transferDataFromTransToGrcDwnldTbl - ",e);
			}
		} catch (Exception e) {
			result = "FAILURE in Getting Connection";
			logger.error("Error in transferDataFromTransToGrcDwnldTbl - ",e);

		} finally {
			stmt.close();
			conn.close();
		}
		
	}
	
	@Override
	public List<SaGrcReportDownload> getSaGrcReportDownload(Integer requestId) {
		Session session=sessionFactory.openSession();

		try{
			final Criteria criteria=session.createCriteria(SaGrcReportDownload.class);
			criteria.add(Restrictions.eq("requestID", Long.valueOf(requestId)));
			return criteria.list();
		}catch(Exception e){
			logger.error("getSaGrcReportDownload :: ",e);
			throw new HibernateException(Hana_Profiler_Constant.DAO_EXCEPTION_MESSAGE);
		}finally{
			if(null != session)
				session.close();
		}
	}
	
	public void calculateNumberOutputFiles(HttpSession session, Long requestId) throws SQLException {
		String query = "select count(*) as cntCol from sa_object_report_download where Request_Id = "+requestId;
		java.sql.Connection conn = null;
		Statement stmt = null;
		//get the object download table count and devide then by 1000000
		//get the count and then update in upload number files table
		try {

			conn = DBConfig.getJDBCConnection(session);
			stmt = conn.createStatement();
			try {
				ResultSet rs = stmt.executeQuery(query);
				double count = 0;
				while(rs.next()){
			          count  = rs.getInt("cntCol");
			         
			      }
				
				// Count change
				int newCnt = 0;
				if (count == 0)
					newCnt = 1;
				else {
					count = count / 1000000;
					newCnt=(int) count;
					if(count > newCnt){
						newCnt++;
					}
				}
			      rs.close();
			      storeOutputFileCount(session, requestId, newCnt);

			} catch (Exception e) {
				logger.error("Error in calculateNumberOutputFiles - ",e);
			}
		} catch (Exception e) {
			logger.error("Error in calculateNumberOutputFiles - ",e);

		} finally {
			stmt.close();
			conn.close();
		}
	}
	
	public void storeOutputFileCount(HttpSession session, Long requestId, int count) throws SQLException {
		String query = "update uploadfiles_number set out_File_Cnt="+count+" where requestId = "+requestId;
		java.sql.Connection conn = null;
		Statement stmt = null;
		//get the object download table count and devide then by 1000000
		//get the count and then update in upload number files table
		try {

			conn = DBConfig.getJDBCConnection(session);
			//conn.setAutoCommit(false);
			try {
				
				stmt = conn.createStatement();
				stmt.executeUpdate(query);

			} catch (Exception e) {
				logger.error("Error in storeOutputFileCount - ",e);
			}
		} catch (Exception e) {
			logger.error("Error in storeOutputFileCount - ",e);

		} finally {
			stmt.close();
			conn.close();
		}
	}
}

