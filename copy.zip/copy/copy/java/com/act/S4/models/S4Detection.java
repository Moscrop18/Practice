/*CR-No.    Desc     Date    Modified By
 * 
 * CR-26.0:- Make changes for Op-Code & show total scanned lines -05/09/17 -monika.mishra
 * 
 * 
 * */

package com.act.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang.StringUtils;
import org.hibernate.annotations.Index;

/**
 * @author monika.mishra
 *
 */
@Entity
@Table(name="S4_DETECTION")
public class S4Detection {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="Id")
	private int id;
	
	@Column(name="SESSION_ID")
	private int sessionId;
	
	@Column(name="IDENTIFIER")
	@Index(name="Index_Composite")
	private String identifier;
	
	@Column(name="UNIQUE_KEY")
	private String uniqueKey;
	
	public String getUniqueKey() {
		return uniqueKey;
	}

	public void setUniqueKey(String uniqueKey) {
		this.uniqueKey = uniqueKey;
	}

	@Column(name="TYPE")
	private String type;
	
	@Column(name="OBJ_NAME")
	private String objectName;
	
	@Column(name="SUB_PROGRAM")
	private String subProgram;
	
	@Column(name="SUB_TYPE")
	private String subType;
	
	@Column(name="OBJ_PACKAGE")
	private String objPackage;
	
	@Column(name="OBJ_TYPE")
	private String objType;
	
	@Column(name="COUNTER")
	private String counter;
	
	@Column(name="LINE_NO")
	private int lineNo;
	
	@Column(name="STATEMENT" ,length=500)
	private String statement;
	
	@Column(name="OPERATIONS")
	private String operations;
	
	@Column(name="COMMENTS",length=500)
	private String comments;
	
	@Column(name="DESCRIPTION" ,columnDefinition = "LONGTEXT")
	private String description;
	
	@Column(name="EXEC_DATE")
	private String execDate;
	
	@Column(name="EXEC_TIME")
	private String execTime;
	
	@Column(name="EXEC_BY")
	private String execBy;
	
	@Column(name="TOOL_VERSION")
	private int toolVersion;
	
	
	//CR-26.0
	@Column(name="Total_Scanned_Line")
	private int totalScannedLine;
	
	@Column(name="OBJ_NAME_TYPE")
	private String objNameType;
	
	@Column(name="READ_PROG")
	private String READ_PROG;
	
	@Column(name="USED")
	private String used;
	
	@Column(name="CUSTOM_FIELDS")
	private String customFields;
	
	@Column(name="SELECT_LINE")
	private String selectLine;
	
	@Column(name="Correction_ProgName")
	private String corProgName;
	
	@Column(name="Correction_LineNo")
	private String corLineNo;
	
	@Column(name = "External_Namespace")
	private String extNamespace = StringUtils.EMPTY;
	
	@Column(name="Automation_Status")
	private String automationStatus;
	
	public String getSelectLine() {
		return selectLine;
	}

	public String getAutomationStatus() {
		return automationStatus;
	}

	public void setAutomationStatus(String automationStatus) {
		this.automationStatus = automationStatus;
	}

	public void setSelectLine(String selectLine) {
		this.selectLine = selectLine;
	}

	public String getCustomFields() {
		return customFields;
	}

	public void setCustomFields(String customFields) {
		this.customFields = customFields;
	}

	public String getREAD_PROG() {
		return READ_PROG;
	}

	public void setREAD_PROG(String rEAD_PROG) {
		READ_PROG = rEAD_PROG;
	}

	public String getObjNameType() {
		return objNameType;
	}

	public void setObjNameType(String objNameType) {
		this.objNameType = objNameType;
	}

	@Column(name="REQUEST_ID")
	@Index(name="Index_Composite")
	private long requestID;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getSessionId() {
		return sessionId;
	}

	public void setSessionId(int sessionId) {
		this.sessionId = sessionId;
	}

	public String getIdentifier() {
		return identifier;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getObjectName() {
		return objectName;
	}

	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}

	public String getSubProgram() {
		return subProgram;
	}

	public void setSubProgram(String subProgram) {
		this.subProgram = subProgram;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public String getObjPackage() {
		return objPackage;
	}

	public void setObjPackage(String objPackage) {
		this.objPackage = objPackage;
	}

	public String getObjType() {
		return objType;
	}

	public void setObjType(String objType) {
		this.objType = objType;
	}

	public String getStatement() {
		return statement;
	}

	public void setStatement(String statement) {
		this.statement = statement;
	}

	public String getOperations() {
		return operations;
	}

	public void setOperations(String operations) {
		this.operations = operations;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getExecDate() {
		return execDate;
	}

	public void setExecDate(String execDate) {
		this.execDate = execDate;
	}

	public String getExecTime() {
		return execTime;
	}

	public void setExecTime(String execTime) {
		this.execTime = execTime;
	}

	public String getExecBy() {
		return execBy;
	}

	public void setExecBy(String execBy) {
		this.execBy = execBy;
	}

	public int getToolVersion() {
		return toolVersion;
	}

	public void setToolVersion(int toolVersion) {
		this.toolVersion = toolVersion;
	}

	public String getCounter() {
		return counter;
	}

	public void setCounter(String counter) {
		this.counter = counter;
	}

	public int getLineNo() {
		return lineNo;
	}

	public void setLineNo(int lineNo) {
		this.lineNo = lineNo;
	}

	public long getRequestId() {
		return requestID;
	}

	public void setRequestId(long requestId) {
		this.requestID = requestId;
	}

	public int getTotalScannedLine() {
		return totalScannedLine;
	}

	public void setTotalScannedLine(int totalScannedLine) {
		this.totalScannedLine = totalScannedLine;
	}

	public String getUsed() {
		return used;
	}

	public void setUsed(String used) {
		this.used = used;
	}
	public String getCorProgName() {
		return corProgName;
	}

	public void setCorProgName(String corProgName) {
		this.corProgName = corProgName;
	}

	public String getCorLineNo() {
		return corLineNo;
	}

	public void setCorLineNo(String corLineNo) {
		this.corLineNo = corLineNo;
	}

	public String getExtNamespace() {
		return extNamespace;
	}

	public void setExtNamespace(String extNamespace) {
		this.extNamespace = extNamespace;
	}
}
