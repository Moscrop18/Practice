package com.act.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Inactive_Objects")
public class InactiveObjects {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID")
	private int id;
	
	@Column(name="OBJECT")
	private String object;
	
	@Column(name="OBJ_NAME")
	private String objName;
	
	@Column(name="UNAME")
	private String uname;
	
	@Column(name="DELET_FLAG")
	private String deleteFlag;
	
	@Column(name="TAB_CLASS")
	private String tabCls;
	
	public String getTabCls() {
		return tabCls;
	}

	public void setTabCls(String tabCls) {
		this.tabCls = tabCls;
	}

	@Column(name="Request_Id")
	private Long requestId;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getObject() {
		return object;
	}

	public void setObject(String object) {
		this.object = object;
	}

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	public Long getRequestId() {
		return requestId;
	}

	public void setRequestId(Long requestId) {
		this.requestId = requestId;
	}
	
}
