package com.act.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author monika.mishra
 *
 */
@Entity
@Table(name="S4_ASSUMPTION")
public class S4Assumptions {
	
	@Id	
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "ID")
	private Integer Id;
	
	@Column(columnDefinition="TEXT", name="ASSUMPTIONS")
	private String assumptions;
	
	@Column(name = "Request_ID",nullable=false,unique=true)
	private Long requestID;
	

	public String getAssumptions() {
		return assumptions;
	}

	public void setAssumptions(String assumptions) {
		this.assumptions = assumptions;
	}

	public Long getRequestID() {
		return requestID;
	}

	public void setRequestID(Long requestID) {
		this.requestID = requestID;
	}

}
