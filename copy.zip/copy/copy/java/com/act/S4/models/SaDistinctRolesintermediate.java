package com.act.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "sa_distinct_roles_intermediate")
public class SaDistinctRolesintermediate implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2647762518773990548L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Id")
	private int id;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Column(name = "row_num")
	private String rowNum;
	
	@Column(name = "Agr_name")
	private String agrName;
	
	@Index(name="Index_Request_id")
	@Column(name = "Request_ID")
	private String requestID;
	
	public String getAgrName() {
		return agrName;
	}
	public void setAgrName(String agrName) {
		this.agrName = agrName;
	}
	public String getRowNum() {
		return rowNum;
	}
	public void setRowNum(String rowNum) {
		this.rowNum = rowNum;
	}
	public String getRequestID() {
		return requestID;
	}
	public void setRequestID(String requestID) {
		this.requestID = requestID;
	}
	
}
