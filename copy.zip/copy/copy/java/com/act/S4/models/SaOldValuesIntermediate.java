package com.act.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "Sa_Old_Values_Intermediate")
public class SaOldValuesIntermediate {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Id")
	private int id;
	
	@Index(name="Index_Request_id")
	@Column(name = "Request_ID")
	private Integer requestId;
	
	@Column(name = "Targetversion")
	private String targetVersion;
	
	@Column(name = "functional_area")
	private String functionalArea;
	
	@Column(name = "AGR_NAME")
	private String agrName;
	
	@Column(name = "TCD")
	private String tcd;
	
	@Column(name = "OBJ")
	private String obj;
	
	@Column(name = "newTcode")
	private String newTcode;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Integer getRequestId() {
		return requestId;
	}
	public void setRequestId(Integer requestId) {
		this.requestId = requestId;
	}
	public String getTargetVersion() {
		return targetVersion;
	}
	public void setTargetVersion(String targetVersion) {
		this.targetVersion = targetVersion;
	}
	public String getFunctionalArea() {
		return functionalArea;
	}
	public void setFunctionalArea(String functionalArea) {
		this.functionalArea = functionalArea;
	}
	public String getAgrName() {
		return agrName;
	}
	public void setAgrName(String agrName) {
		this.agrName = agrName;
	}
	public String getTcd() {
		return tcd;
	}
	public void setTcd(String tcd) {
		this.tcd = tcd;
	}
	public String getObj() {
		return obj;
	}
	public void setObj(String obj) {
		this.obj = obj;
	}
	public String getNewTcode() {
		return newTcode;
	}
	public void setNewTcode(String newTcode) {
		this.newTcode = newTcode;
	}
}
