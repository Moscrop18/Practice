package com.act.S4.models;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

/**
 * @author himani.malhotra
 *
 */
@Entity
@Table(name="S4_Enhancement_Download")
public class S4Enhancement_Download {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ID")
	private int id;
	
	@Column(name="ENHANCEMENT_TYPE")
	private String enhancementType;
	
	@Column(name="CLAS_NAME")
	private String clasName;
	
	@Column(name="ENHANCEMENT_NAME")
	private String enhancementName; 
		
	@Column(name="IMPLEMENTATION_NAME")
	private String implName;

	@Index(name="Index_Request_id")
	@Column(name="REQUEST_ID")
	private long requestID;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public String getEnhancementType() {
		return enhancementType;
	}

	public void setEnhancementType(String enhancementType) {
		this.enhancementType = enhancementType;
	}

	public String getClasName() {
		return clasName;
	}

	public void setClasName(String clasName) {
		this.clasName = clasName;
	}

		public String getEnhancementName() {
		return enhancementName;
	}

	public void setEnhancementName(String enhancementName) {
		this.enhancementName = enhancementName;
	}

	public String getImplName() {
		return implName;
	}

	public void setImplName(String implName) {
		this.implName = implName;
	}

	public long getRequestID() {
		return requestID;
	}

	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}

}
