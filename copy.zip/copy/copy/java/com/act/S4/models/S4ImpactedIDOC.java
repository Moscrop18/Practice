/*CR-No.    Desc     Date    Modified By
	 * 
	 * CR-2.0:- Make changes for Op-Code & show total scanned lines -05/09/17 -monika.mishra
	 * 
	 * 
* */
package com.act.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

/**
 * @author himani.malhotra
 *
 */
@Entity
@Table(name="S4_IMPACTED_IDOC")
public class S4ImpactedIDOC {
	
		@Id
		@GeneratedValue(strategy=GenerationType.AUTO)
		@Column(name="ID")
		private int id;

		@Column(name="Identifier")
		@Index(name="Identifier")
		private String identifier;

		@Column(name="IDOC_MSG_TYPE")
		private String msgType;

		@Column(name="IDOC_BASIC_TYPE")
		private String basicType;

		@Column(name="IDOC_SEGMENT")
		private String segment;
		
		@Column(name="IMPACTED_OBJECT_TYPE")
		private String impactedObjType;

		@Column(name="IMPACTED_OBJECT_NAME")
		private String impactedObjName;

		@Column(name="DESCRIPTION",length=500)
		private String description;

		@Column(name="NOTE_NUMBER",length=500)
		private String sapNote;

		@Column(name="SOLUTION",length=500)
		private String solSteps;
		
		@Column(name="REQUEST_ID")
		@Index(name="Index_Request_id")
		private long requestID;
		
		@Column(name = "TYPE_OF_IDOC")
		private String typeOfIDOC;

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getIdentifier() {
			return identifier;
		}

		public void setIdentifier(String identifier) {
			this.identifier = identifier;
		}

		public String getMsgType() {
			return msgType;
		}

		public void setMsgType(String msgType) {
			this.msgType = msgType;
		}

		public String getBasicType() {
			return basicType;
		}

		public void setBasicType(String basicType) {
			this.basicType = basicType;
		}

		public String getSegment() {
			return segment;
		}

		public void setSegment(String segment) {
			this.segment = segment;
		}

		public String getImpactedObjType() {
			return impactedObjType;
		}

		public void setImpactedObjType(String impactedObjType) {
			this.impactedObjType = impactedObjType;
		}

		public String getImpactedObjName() {
			return impactedObjName;
		}

		public void setImpactedObjName(String impactedObjName) {
			this.impactedObjName = impactedObjName;
		}

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}

		public String getSapNote() {
			return sapNote;
		}

		public void setSapNote(String sapNote) {
			this.sapNote = sapNote;
		}

		public String getSolSteps() {
			return solSteps;
		}

		public void setSolSteps(String solSteps) {
			this.solSteps = solSteps;
		}

		public long getRequestID() {
			return requestID;
		}

		public void setRequestID(long requestID) {
			this.requestID = requestID;
		}

		public String getTypeOfIDOC() {
			return typeOfIDOC;
		}

		public void setTypeOfIDOC(String typeOfIDOC) {
			this.typeOfIDOC = typeOfIDOC;
		}
}



