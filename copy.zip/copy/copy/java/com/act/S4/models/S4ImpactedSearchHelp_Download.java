package com.act.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

/**
 * @author rohan.a.mehra
 *
 */
@Entity
@Table(name="S4_Impacted_Search_Download")
public class S4ImpactedSearchHelp_Download {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ID")
	private int id;
	
	@Column(name="search_data")
	private String searchData;
	
	@Index(name="Index_Request_id")
	@Column(name="REQUEST_ID")
	private long requestID;
	
	@Column(name="OBJECT_TYPE")
	private String objectType;
	
	@Column(name="OBJECT_NAME")
	private String objectName;
	
	@Column(name = "EXTERNAL_NAMESPACE")
	private String externalNamespace ;

	public String getExternalNamespace() {
		return externalNamespace;
	}

	public void setExternalNamespace(String externalNamespace) {
		this.externalNamespace = externalNamespace;
	}

	public String getObjectType() {
		return objectType;
	}

	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}

	public String getObjectName() {
		return objectName;
	}

	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public long getRequestId() {
		return requestID;
	}

	public void setRequestId(long requestId) {
		this.requestID = requestId;
	}

	public String getSearchData() {
		return searchData;
	}

	public void setSearchData(String searchData) {
		this.searchData = searchData;
	}
}
