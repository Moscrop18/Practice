package com.act.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

/**
 * @author rohan.a.mehra
 *
 */
@Entity
@Table(name="S4_Output_Management_Download")
public class S4OutputMgmt_Download {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ID")
	private int id;

	@Column(name="Type")
	private String type;

	@Column(name="Obj_Name",length=500)
	private String ObjName;
	
	@Column(name="Used")
	private String used;
	
	@Column(name="Obj_Name_Type")
	private String objNameType;

	@Index(name="Index_Request_id")
	@Column(name="REQUEST_ID")
	private long requestID;


	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getObjName() {
		return ObjName;
	}

	public void setObjName(String objName) {
		ObjName = objName;
	}

	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	

	public long getRequestID() {
		return requestID;
	}

	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}

}
