package com.act.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "sa_fiori_report_download")
public class SaFioriReportDownload {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Id")
	private int id;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	@Column(name = "targetVersion")
	private String targetVersion;
	
	@Column(name = "functional_area")
	private String functionalArea;
	
	@Column(name = "AGR_NAME")
	private String agrname;
	
	@Column(name = "LOW")
	private String low;
	
	@Column(name = "HIGH")
	private String high;
	
	@Column(name = "NewTcode")
	private String newTcode;
	
	@Column(name = "Request_ID")
	private Long requestId;
	
	@Column(name = "FioriID_OldTcode")
	private String fioriIdOldTcode;
	
	@Column(name = "AppName_OldTcode")
	private String appNameOldTcode;
	
	@Column(name = "ApplicationType_OldTcode")
	private String appTypeOldTcode;
	
	@Column(name = "FrontendProductVersion_OldTcode")
	private String frntPrdVersionOldTcode;
	
	@Column(name = "ProductVersionNameBackend_OldTcode")
	private String prdVerNameBckEndOldTcode;
	
	@Column(name = "FioriID_NewTcode")
	private String fioriIdNewTcode;
	
	@Column(name = "AppName_NewTcode")
	private String appNameNewTcode;
	
	@Column(name = "ApplicationType_NewTcode")
	private String appTypeNewTcode;
	
	@Column(name = "FrontendProductVersion_NewTcode")
	private String frntPrdverNewTcode;
	
	@Column(name = "ProductVersionNameBackend_NewTcode")
	private String prdVerNameBckEndNewTcode;
	
	@Column(name = "Status")
	private String status;

	public String getTargetVersion() {
		return targetVersion;
	}
	public void setTargetVersion(String targetVersion) {
		this.targetVersion = targetVersion;
	}
	public String getFunctionalArea() {
		return functionalArea;
	}
	public void setFunctionalArea(String functionalArea) {
		this.functionalArea = functionalArea;
	}
	public String getAgrname() {
		return agrname;
	}
	public void setAgrname(String agrname) {
		this.agrname = agrname;
	}
	public String getLow() {
		return low;
	}
	public void setLow(String low) {
		this.low = low;
	}
	public String getHigh() {
		return high;
	}
	public void setHigh(String high) {
		this.high = high;
	}
	public String getNewTcode() {
		return newTcode;
	}
	public void setNewTcode(String newTcode) {
		this.newTcode = newTcode;
	}
	public Long getRequestId() {
		return requestId;
	}
	public void setRequestId(Long requestId) {
		this.requestId = requestId;
	}
	public String getFioriIdOldTcode() {
		return fioriIdOldTcode;
	}
	public void setFioriIdOldTcode(String fioriIdOldTcode) {
		this.fioriIdOldTcode = fioriIdOldTcode;
	}
	public String getAppNameOldTcode() {
		return appNameOldTcode;
	}
	public void setAppNameOldTcode(String appNameOldTcode) {
		this.appNameOldTcode = appNameOldTcode;
	}
	public String getAppTypeOldTcode() {
		return appTypeOldTcode;
	}
	public void setAppTypeOldTcode(String appTypeOldTcode) {
		this.appTypeOldTcode = appTypeOldTcode;
	}
	public String getFrntPrdVersionOldTcode() {
		return frntPrdVersionOldTcode;
	}
	public void setFrntPrdVersionOldTcode(String frntPrdVersionOldTcode) {
		this.frntPrdVersionOldTcode = frntPrdVersionOldTcode;
	}
	public String getPrdVerNameBckEndOldTcode() {
		return prdVerNameBckEndOldTcode;
	}
	public void setPrdVerNameBckEndOldTcode(String prdVerNameBckEndOldTcode) {
		this.prdVerNameBckEndOldTcode = prdVerNameBckEndOldTcode;
	}
	public String getFioriIdNewTcode() {
		return fioriIdNewTcode;
	}
	public void setFioriIdNewTcode(String fioriIdNewTcode) {
		this.fioriIdNewTcode = fioriIdNewTcode;
	}
	public String getAppNameNewTcode() {
		return appNameNewTcode;
	}
	public void setAppNameNewTcode(String appNameNewTcode) {
		this.appNameNewTcode = appNameNewTcode;
	}
	public String getAppTypeNewTcode() {
		return appTypeNewTcode;
	}
	public void setAppTypeNewTcode(String appTypeNewTcode) {
		this.appTypeNewTcode = appTypeNewTcode;
	}
	public String getFrntPrdverNewTcode() {
		return frntPrdverNewTcode;
	}
	public void setFrntPrdverNewTcode(String frntPrdverNewTcode) {
		this.frntPrdverNewTcode = frntPrdverNewTcode;
	}
	public String getPrdVerNameBckEndNewTcode() {
		return prdVerNameBckEndNewTcode;
	}
	public void setPrdVerNameBckEndNewTcode(String prdVerNameBckEndNewTcode) {
		this.prdVerNameBckEndNewTcode = prdVerNameBckEndNewTcode;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}
