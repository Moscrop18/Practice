package com.act.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Fiori_Rebuild_Master")
public class FioriRebuildMaster {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Id")
	private int Id;

	@Column(name = "App_Id")
	private String appId;

	@Column(name = "App_Name")
	private String appName;

	@Column(name = "Available_Version")
	private String availableVersion;

	@Column(name = "List_Of_Similar_Applications")
	private String list_of_similar_aplications;

	@Column(name = "Remarks")
	private String remarks;
	
	@Column(name = "Version_Check")
	private String versionCheck;

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getAvailableVersion() {
		return availableVersion;
	}

	public void setAvailableVersion(String availableVersion) {
		this.availableVersion = availableVersion;
	}

	public String getList_of_similar_aplications() {
		return list_of_similar_aplications;
	}

	public void setList_of_similar_aplications(String list_of_similar_aplications) {
		this.list_of_similar_aplications = list_of_similar_aplications;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getVersionCheck() {
		return versionCheck;
	}

	public void setVersionCheck(String versionCheck) {
		this.versionCheck = versionCheck;
	}
}
