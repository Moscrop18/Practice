package com.act.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Cvit_ErrorMessages_Download")
public class CvitErrorMessagesDownload {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Id")
	private int id;
	
	@Column(name = "Request_Id")
	private long requestId;
	
	@Column(name = "Run_Id")
	private String runId;
	
	@Column(name = "Indicator")
	private String indicator;
	
	@Column(name = "Customer_Vendor")
	private String customerVendor;
	
	@Column(name = "Field_Name")
	private String fieldName;
	
	@Column(name = "Error_Log")
	private String errorLog;

	public int getId() {
		return id;
	}

	public long getRequestId() {
		return requestId;
	}

	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getRunId() {
		return runId;
	}

	public void setRunId(String runId) {
		this.runId = runId;
	}

	public String getIndicator() {
		return indicator;
	}

	public void setIndicator(String indicator) {
		this.indicator = indicator;
	}

	public String getCustomerVendor() {
		return customerVendor;
	}

	public void setCustomerVendor(String customerVendor) {
		this.customerVendor = customerVendor;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getErrorLog() {
		return errorLog;
	}

	public void setErrorLog(String errorLog) {
		this.errorLog = errorLog;
	}
}
