package com.act.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang.StringUtils;

@Entity
@Table(name = "UNICODE_Intermediate")
public class Unicode_Intermediate {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID")
	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Column(name = "Program")
	private String program;

	@Column(name = "Include")
	private String include;

	@Column(name = "Roww")
	private String roww;

	@Column(name = "Error_Code")
	private String errorCode;

	@Column(name = "Message")
	private String message;

	@Column(name = "Created_By")
	private String createdBy;

	@Column(name = "Pack")
	private String pack;

	@Column(name = "Pack_Per_Resp")
	private String packPerResp;
	
	@Column(name = "Request_Id")
	private long requestId;
	
	@Column(name = "Concat_Col")
	private String concatCol;
	
	@Column(name = "Original_System")
	private String originalSystem;
	
	@Column(name = "Object_Type")
	private String objType;
	
	@Column(name = "External_Namespace")
	private String extNamespace = StringUtils.EMPTY;
	
	@Column(name = "Used")
	private String used;

	public String getExtNamespace() {
		return extNamespace;
	}

	public void setExtNamespace(String extNamespace) {
		this.extNamespace = extNamespace;
	}
	
	public String getUsed() {
		return used;
	}

	public void setUsed(String used) {
		this.used = used;
	}
	
	public String getObjType() {
		return objType;
	}

	public void setObjType(String objType) {
		this.objType = objType;
	}
	
	@Column(name = "Application_Component")
	private String applicationComp;

	public String getOriginalSystem() {
		return originalSystem;
	}

	public void setOriginalSystem(String originalSystem) {
		this.originalSystem = originalSystem;
	}

	public String getApplicationComp() {
		return applicationComp;
	}

	public void setApplicationComp(String applicationComp) {
		this.applicationComp = applicationComp;
	}

	public String getConcatCol() {
		return concatCol;
	}

	public void setConcatCol(String concatCol) {
		this.concatCol = concatCol;
	}

	public long getRequestId() {
		return requestId;
	}

	public void setRequestId(long requestId) {
		this.requestId = requestId;
	}

	public String getProgram() {
		return program;
	}

	public void setProgram(String program) {
		this.program = program;
	}

	public String getInclude() {
		return include;
	}

	public void setInclude(String include) {
		this.include = include;
	}

	public String getRoww() {
		return roww;
	}

	public void setRoww(String roww) {
		this.roww = roww;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getPack() {
		return pack;
	}

	public void setPack(String pack) {
		this.pack = pack;
	}

	public String getPackPerResp() {
		return packPerResp;
	}

	public void setPackPerResp(String packPerResp) {
		this.packPerResp = packPerResp;
	}

}
