package com.act.S4.models;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang.StringUtils;
import org.hibernate.annotations.Index;

/**
 * @author monika.mishra
 *
 */
@Entity
@Table(name = "S4_Inventory_List")
public class S4InventoryList {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	private int id;

	@Column(name = "OBJ_TYPE")
	private String objType;

	public String getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}

	public String getChangedOn() {
		return changedOn;
	}

	public void setChangedOn(String changedOn) {
		this.changedOn = changedOn;
	}

	@Column(name = "OBJ_NAME")
	private String objName;

	@Column(name = "Used")
	private String used;

	@Column(name = "Transport_Request")
	private String transReq;

	private String usageCount;

	@Index(name = "OBJ_NAME_TYPE")
	@Column(name = "OBJ_NAME_TYPE")
	private String objNameType;

	@Column(name = "Package")
	private String pckg;

	@Column(name = "REQUEST_ID")
	@Index(name = "Index_Request_id")
	private long requestID;

	@Column(name = "Standard_Modification")
	private String standardMod;

	@Column(name = "Ricef_Category")
	private String ricefCategory;

	@Column(name = "Count_Lines")
	private String countLines;

	@Column(name = "User_Group")
	private String userGroup;

	@Column(name = "ABAP_Query")
	private String ABAPQuery;

	@Column(name = "Read_Prog")
	private String readProg;

	@Column(name = "CREATED_BY")
	private String createdBy;

	@Column(name = "CREATED_ON")
	private String createdOn;

	@Column(name = "CHANGED_BY")
	private String changedBy;

	
	@Column(name = "CHANGED_ON")
	private String changedOn;
	
	@Column(name = "TR")
	private String tr;
	
	public String getTrStatus() {
		return trStatus;
	}

	public void setTrStatus(String trStatus) {
		this.trStatus = trStatus;
	}

	@Column(name = "TR_STATUS")
	private String trStatus;

	public String getReadProg() {
		return readProg;
	}

	public void setReadProg(String readProg) {
		this.readProg = readProg;
	}

	public String getCountLines() {
		return countLines;
	}

	public void setCountLines(String countLines) {
		this.countLines = countLines;
	}

	@Column(name = "External_Namespace")
	private String extNamespace = StringUtils.EMPTY;

	public String getRicefCategory() {
		return ricefCategory;
	}

	public void setRicefCategory(String ricefCategory) {
		this.ricefCategory = ricefCategory;
	}

	@Column(name = "Ricef_Sub_Category")
	private String ricefSubCategory;

	public String getRicefSubCategory() {
		return ricefSubCategory;
	}

	public void setRicefSubCategory(String ricefSubCategory) {
		this.ricefSubCategory = ricefSubCategory;
	}

	public String getObjNameType() {
		return objNameType;
	}

	public void setObjNameType(String objNameType) {
		this.objNameType = objNameType;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getObjType() {
		return objType;
	}

	public void setObjType(String objType) {
		this.objType = objType;
	}

	public String getObjName() {
		return objName;
	}

	public void setObjName(String objName) {
		this.objName = objName;
	}

	public String getPckg() {
		return pckg;
	}

	public String getStandardMod() {
		return standardMod;
	}

	public void setStandardMod(String standardMod) {
		this.standardMod = standardMod;
	}

	public void setPckg(String pckg) {
		this.pckg = pckg;
	}

	public String getUsage() {
		return used;
	}

	public void setUsage(String usage) {
		this.used = usage;
	}

	public long getRequestID() {
		return requestID;
	}

	public void setRequestID(long requestID) {
		this.requestID = requestID;
	}

	public String getTransReq() {
		return transReq;
	}

	public void setTransReq(String transReq) {
		this.transReq = transReq;
	}

	public String getUsageCount() {
		return usageCount;
	}

	public void setUsageCount(String usageCount) {
		this.usageCount = usageCount;
	}

	public String getExtNamespace() {
		return extNamespace;
	}

	public void setExtNamespace(String extNamespace) {
		this.extNamespace = extNamespace;
	}

	public String getUserGroup() {
		return userGroup;
	}

	public void setUserGroup(String userGroup) {
		this.userGroup = userGroup;
	}

	public String getABAPQuery() {
		return ABAPQuery;
	}

	public void setABAPQuery(String ABAPQuery) {
		this.ABAPQuery = ABAPQuery;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}


	public String getChangedBy() {
		return changedBy;
	}

	public void setChangedBy(String changedBy) {
		this.changedBy = changedBy;
	}

	public String getTr() {
		return tr;
	}

	public void setTr(String tr) {
		this.tr = tr;
	}


	@Override
	public boolean equals(Object obj) {
		if (obj instanceof S4InventoryList) {
			return ((S4InventoryList) obj).objNameType == objNameType;
		}

		return false;
	}

	@Override
	public int hashCode() {
		return this.id;
	}
}
