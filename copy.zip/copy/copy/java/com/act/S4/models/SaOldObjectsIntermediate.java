package com.act.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "Sa_Old_Objects_Intermediate")
public class SaOldObjectsIntermediate {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Id")
	private int id;
	
	@Index(name="Index_Request_id")
	@Column(name = "Request_ID")
	private Integer requestId;
	
	@Column(name = "Targetversion")
	private String targetVersion;
	
	@Column(name = "functional_area")
	private String functionalArea;
	
	@Column(name = "AGR_NAME")
	private String agrName;
	
	@Column(name = "TCD")
	private String tcd;
	
	@Column(name = "Object")
	private String object;
	
	@Column(name = "Field")
	private String field;
	
	@Column(name = "Low")
	private String low;
	
	@Column(name = "High")
	private String high;
	
	@Column(name = "Modified")
	private String modified;
	
	@Column(name = "deleted")
	private String deleted;
	
	@Column(name = "copied")
	private String copied;
	
	@Column(name = "newTcode")
	private String newTcode;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Integer getRequestId() {
		return requestId;
	}
	public void setRequestId(Integer requestId) {
		this.requestId = requestId;
	}
	public String getTargetVersion() {
		return targetVersion;
	}
	public void setTargetVersion(String targetVersion) {
		this.targetVersion = targetVersion;
	}
	public String getFunctionalArea() {
		return functionalArea;
	}
	public void setFunctionalArea(String functionalArea) {
		this.functionalArea = functionalArea;
	}
	public String getAgrName() {
		return agrName;
	}
	public void setAgrName(String agrName) {
		this.agrName = agrName;
	}
	public String getTcd() {
		return tcd;
	}
	public void setTcd(String tcd) {
		this.tcd = tcd;
	}
	public String getObject() {
		return object;
	}
	public void setObject(String object) {
		this.object = object;
	}
	public String getField() {
		return field;
	}
	public void setField(String field) {
		this.field = field;
	}
	public String getLow() {
		return low;
	}
	public void setLow(String low) {
		this.low = low;
	}
	public String getHigh() {
		return high;
	}
	public void setHigh(String high) {
		this.high = high;
	}
	public String getModified() {
		return modified;
	}
	public void setModified(String modified) {
		this.modified = modified;
	}
	public String getDeleted() {
		return deleted;
	}
	public void setDeleted(String deleted) {
		this.deleted = deleted;
	}
	public String getCopied() {
		return copied;
	}
	public void setCopied(String copied) {
		this.copied = copied;
	}
	public String getNewTcode() {
		return newTcode;
	}
	public void setNewTcode(String newTcode) {
		this.newTcode = newTcode;
	}
	
}
