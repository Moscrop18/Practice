package com.act.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import org.hibernate.annotations.Type;

@Entity
@Table(name="S4_VALIDATION_FILE")
public class S4ValidationFile implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;



	private int ID;



	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID")
	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}
	
	public String validationFileName;
	
	

	public byte[] validationFile;
   
	private String validationVersion;
	
	private String updatedDate;


	
	@Column(name="S4_VALIDATION_FILE_NAME")
	public String getValidationFileName() {
		return validationFileName;
	}

	public void setValidationFileName(String validationFileName) {
		this.validationFileName = validationFileName;
	}
	
	
	
	@Column(name="S4_VALIDATION_FILE")
	@Type(type="org.hibernate.type.MaterializedBlobType")
	public byte[] getValidationFile() {
		return validationFile;
	}

	public void setValidationFile(byte[] validationFile) {
		this.validationFile = validationFile;
	}

	@Column(name="S4_VALIDATION_FILE_VERSION")
	public String getValidationVersion() {
		return validationVersion;
	}

	public void setValidationVersion(String validationVersion) {
		this.validationVersion = validationVersion;
	}

	@Column(name="")
	public String getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}
		
}
