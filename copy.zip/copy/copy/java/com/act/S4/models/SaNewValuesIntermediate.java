package com.act.S4.models;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "Sa_New_Values_Intermediate")
public class SaNewValuesIntermediate {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Id")
	private int id;
	
	@Index(name="Index_Request_id")
	@Column(name = "Request_ID")
	private Integer requestId;
	
	@Index(name="Index_Concat")
	@Column(name = "Concat")
	private String concat;
	
	@Column(name = "Targetversion")
	private String targetVersion;
	
	@Column(name = "functional_area")
	private String functionalArea;
	
	@Column(name = "AGR_NAME")
	private String agrName;
	
	@Column(name = "OldTCode")
	private String oldTcode;
	
	
	@Column(name = "newTcode")
	private String newTcode;
	
	@Column(name = "TCD")
	private String tcd;
	
	@Column(name = "Object")
	private String object;
	
	@Column(name = "Field")
	private String field;
	
	@Column(name = "NewLow")
	private String newLow;
	
	@Column(name = "NewHigh")
	private String newHigh;
	
	@Column(name = "Proposed", columnDefinition="LONGTEXT")
	private String proposed;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Integer getRequestId() {
		return requestId;
	}
	public void setRequestId(Integer requestId) {
		this.requestId = requestId;
	}
	public String getConcat() {
		return concat;
	}
	public void setConcat(String concat) {
		this.concat = concat;
	}
	public String getTargetVersion() {
		return targetVersion;
	}
	public void setTargetVersion(String targetVersion) {
		this.targetVersion = targetVersion;
	}
	public String getFunctionalArea() {
		return functionalArea;
	}
	public void setFunctionalArea(String functionalArea) {
		this.functionalArea = functionalArea;
	}
	public String getAgrName() {
		return agrName;
	}
	public void setAgrName(String agrName) {
		this.agrName = agrName;
	}
	public String getOldTcode() {
		return oldTcode;
	}
	public void setOldTcode(String oldTcode) {
		this.oldTcode = oldTcode;
	}
	public String getNewTcode() {
		return newTcode;
	}
	public void setNewTcode(String newTcode) {
		this.newTcode = newTcode;
	}
	public String getTcd() {
		return tcd;
	}
	public void setTcd(String tcd) {
		this.tcd = tcd;
	}
	public String getObject() {
		return object;
	}
	public void setObject(String object) {
		this.object = object;
	}
	public String getField() {
		return field;
	}
	public void setField(String field) {
		this.field = field;
	}
	public String getNewLow() {
		return newLow;
	}
	public void setNewLow(String newLow) {
		this.newLow = newLow;
	}
	public String getNewHigh() {
		return newHigh;
	}
	public void setNewHigh(String newHigh) {
		this.newHigh = newHigh;
	}
	public String getProposed() {
		return proposed;
	}
	public void setProposed(String proposed) {
		this.proposed = proposed;
	}
	
}
