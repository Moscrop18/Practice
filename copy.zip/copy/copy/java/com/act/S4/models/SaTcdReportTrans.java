package com.act.S4.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

@Entity
@Table(name = "Sa_Tcd_Report_Trans")
public class SaTcdReportTrans {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Id")
	private int id;
	
	@Column(name="targetVersion")
	private String targetVersion;
	
	@Column(name="AGR_NAME")
	private String roleName;
	
	@Column(name="LOW")
	private String low;
	
	@Column(name="HIGH")
	private String high;
	
	@Column(name="newTcode")
	private String newTcode;
	
	@Column(name="functional_area")
	private String functionalArea;
	
	@Column(name="status")
	private String status;
	
	@Index(name="Index_Request_id")
	@Column(name="Request_ID")
	private Integer requestID;

	public Integer getRequestID() {
		return requestID;
	}

	public void setRequestID(Integer requestID) {
		this.requestID = requestID;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTargetVersion() {
		return targetVersion;
	}

	public void setTargetVersion(String targetVersion) {
		this.targetVersion = targetVersion;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getLow() {
		return low;
	}

	public void setLow(String low) {
		this.low = low;
	}

	public String getHigh() {
		return high;
	}

	public void setHigh(String high) {
		this.high = high;
	}

	public String getNewTcode() {
		return newTcode;
	}

	public void setNewTcode(String newTcode) {
		this.newTcode = newTcode;
	}

	public String getFunctionalArea() {
		return functionalArea;
	}

	public void setFunctionalArea(String functionalArea) {
		this.functionalArea = functionalArea;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}
