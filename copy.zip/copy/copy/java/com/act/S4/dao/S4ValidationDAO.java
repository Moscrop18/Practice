package com.act.S4.dao;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpSession;

import com.act.S4.models.FileStore;
import com.act.S4.models.FioriRebuildMaster;
import com.act.S4.models.GrcMasterdata;
import com.act.S4.models.S4ValidationFile;
import com.act.S4.models.S4ValidationList;
import com.act.S4.models.TCDSimplification;
import com.act.S4.models.TarUsobtc;
import com.act.bw.model.BwExtractorMaster;
import com.act.client.model.RequestInventory;
import com.act.testingscope.model.AppComponentSubProcessTestScript;
import com.act.testingscope.model.TCodeSubProcessTestScript;

public interface S4ValidationDAO {
	public Boolean getS4ValidationExistingStatus(String fileVersion);

	public Integer getS4ValidationMaxID();

	public void saveS4ValidationFile(S4ValidationFile s4ValidationFile) throws SQLException;

	public String getS4ValidationLatestVersion(HttpSession session) throws SQLException;

	public Integer getPreRequisiteMaxID();

	public void saveFiles(FileStore fileStore, byte[] prZipContent, String fileName, String fileNameKey)
			throws SQLException;

	public String validationFileDataBatchInsertUpdate(List<S4ValidationList> validationDataS4List, HttpSession session)
			throws SQLException;

	public void deleteS4ValidateData();

	public void deleteTCDSimplificationData();

	public void deleteGRCMasterdataData();

	public S4ValidationFile getNewValidationobj(Long requestID) throws Exception;

	public S4ValidationFile getValidationFile(String valVersion);

	public boolean getFileDownloadStatus(Long requestID, String fileName);

	public RequestInventory setValidationDownloadStatus(Long requestID, boolean validationDownloadStatus);

	public RequestInventory setPreRequisiteDownloadStatus(Long requestID, boolean preRequisiteDownloadStatus);

	public FileStore getFileFromFileStoreTable(String fileNameKey);

	public String tcdSimplificationDataBatchInsertUpdate(List<TCDSimplification> tcdsimpliList, HttpSession session)
			throws SQLException;

	public String grcMasterdataDataBatchInsertUpdate(List<GrcMasterdata> grcMasterList, HttpSession session)
			throws SQLException;

	public String targetUsobtcDataBatchInsertUpdate(List<TarUsobtc> tarUsobtcList, HttpSession session)
			throws SQLException;

	public String deleteTableData(String tableName);

	public String tcodeSubProcessInsertData(List<TCodeSubProcessTestScript> tcodeSubProcessList, HttpSession session)
			throws SQLException;
	
	public String appCompSubProcessInsertData(List<AppComponentSubProcessTestScript> appCompSubProcessList, HttpSession session) 
			throws SQLException;
	
	public void truncateTable(String tableName, HttpSession session);
	
	public String bwExtractMasterdataDataBatchInsertUpdate(List<BwExtractorMaster>bwMasterList, HttpSession session) throws SQLException;
	public String fioriRebuildDataBatchInsertUpdate(List<FioriRebuildMaster> fioriRebuildMasterList, HttpSession session)
			throws SQLException;
}
