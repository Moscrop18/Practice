package com.act.S4.constant;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class S4HanaProfilerConstant {

	public static final String DETECTION_CONSTANT = "DETECTION";
	public static final String CLONE_CONSTANT = "CLONE";
	public static final String IMPACTED_CLONE_CONSTANT = "IMPACTED CLONE";
	public static final String ACNIP_ZVER_COMP_CONSTANT = "ACNIP_ZVER_COMP";
	public static final String BW_EXTRACTOR_CONSTANT = "BW_EXTRACTOR";
	public static final String USAGE_CONSTANT = "USAGE";
	public static final String SEARCH_CONSTANT = "SEARCH";
	public static final String APPEND_CONSTANT = "APPEND";
	public static final String INVENTORY_CONSTANT = "INVENTORY";
	public static final String ENHANCEMENT_CONSTANT = "ENHANCEMENT";
	public static final Map<Long, Map<String, Map<String, ArrayList<String>>>> S4_FILE_KEY_VALUE = new HashMap<Long, Map<String, Map<String, ArrayList<String>>>>();
	
	public static final String ENHOBJ_CONSTANT = "ENHOBJ";
	public static final String SXC_CONSTANT = "SXC";
	public static final String V_CONSTANT = "V";
	public static final String ZS4_CONSTANT = "ZS4";
	public static final String IDOC_CONSTANT = "IDOC";
	public static final String IMPACTED_TABLES_CONSTANT = "IMPACTED TABLES";
	public static final String IMPACTED_STANDARD_TRANSACTION_CONSTANT = "IMPACTED STANDARD TRANSACTION";
	public static final String LSMW_CONSTANT="LSMW";
	public static final String USER_EXIT_CONSTANT="USEREXIT";
	
	public static final String BIG_SIMPLIFICATION_CONSTANT = "Simplification";
	public static final String TCD_SIMPLIFICATION_CONSTANT = "TCD";
	public static final String TARGET_USOBTC = "Tar_Usobtc";
	public static final String GRC_STANDARD_RULESET = "GRC_STANDARDRULES";
	public static final String BWINVENTORY_CONSTANT = "BW_INVENTORY.XLSX";
	public static final String TSCOPE_CONSTANT = "TSCOPE";
	public static final String BW_EXTRACT_MASTER_CONSTANT = "BW_EXTRACT_MASTER";
}
