package com.act.S4.Controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.act.S4.dao.S4ValidationDAOImpl;
import com.act.S4.models.S4ValidationFile;
import com.act.admin.controller.AdminLoginController;
import com.act.client.model.RequestForm;
import com.act.constant.Hana_Profiler_Constant;
import com.act.exceptions.IDVFailedException;
import com.act.fileprocessing.CheckFileListStatus;
import com.act.fileprocessing.InitialDataValidation;
import com.act.statictables.model.TransportRequest;
import com.act.statictables.model.TransportRequestFile;
import com.act.utility.HANAUtility;

/**
 * @author monika.mishra
 *
 */
@Controller
@SessionAttributes("User")

public class RequestFormInputControllerS4 extends S4ProcessingController{
	
	@RequestMapping(value = "/client/clientFilesProcessing/S4", method = RequestMethod.GET)
	public @ResponseBody void clientFilesProcessing(final Long requestId, final HttpServletRequest request, HttpSession session) {
		String toolName = (String) session.getAttribute("tool");
		//clientFileProcessingBusinessLogicS4(requestId, request,toolName);
	}
	
	@RequestMapping(value = "/poc/uploadSimplification", method = RequestMethod.POST)
	public String uploadSimplification(final RedirectAttributes redirectAttributes,final HttpServletRequest request) throws FileUploadException, FileNotFoundException {
		logger.info("Coming inside UploadSimplifiationController");
		String fileName="Simplification";
		long requestId=0;
		
		HANAUtility.deleteFile(fileName, requestId,null);
		final String filePath = HANAUtility.getFilePath(fileName, requestId);
		logger.info("FilePath::::" +filePath);
		DiskFileItemFactory factory = new DiskFileItemFactory();
		factory.setSizeThreshold(0);
		factory.setRepository(new File(HANAUtility.getRepositoryTemp(fileName, requestId)));

		ServletFileUpload upload = new ServletFileUpload(factory);
		upload.setFileSizeMax(-1);		
		upload.setSizeMax(-1);

		String    filename="";
		List<FileItem> multipart = new ServletFileUpload(factory).parseRequest(request);

		logger.info("Inside Initial Data validation method");

		final String userName = getPrincipal();
		
		// File Validation Loop  Validation of files *	

		for (FileItem item : multipart) {
			filename="";
			if (!item.isFormField()) {
				try {
				
					filename = new File(item.getName()).getName();
					if (StringUtils.isNotEmpty(filename) && !"".equals(filename)) {
						String extension=Hana_Profiler_Constant.XLSX_EXTENSTION_CONSTANT;
						String fileExtension = filename.substring(filename.length() - extension.length(),filename.length());
						if (extension.equalsIgnoreCase(fileExtension)) {
							logger.info("Matched Extension");
							item.write(new File(filePath + File.separator + filename));
							logger.info("Wrote in file path **");

						}else{
							redirectAttributes.addFlashAttribute("fileException", "Please Upload the file with .xlsx extension only.");
							return "redirect:/admin/simplification";
						}

					}else{
						redirectAttributes.addFlashAttribute("fileException", "Please Upload atleast one file.");
						return "redirect:/admin/simplification";
					}
				} catch (Exception exception) {
					redirectAttributes.addFlashAttribute("fileException", exception.getMessage());
					return "redirect:/admin/simplification";
				}
			}
			else{}
		}

		String comment= uploadSimplificationData((filePath + File.separator + filename),requestId,request);
		if(comment.equalsIgnoreCase("success")){
			redirectAttributes.addFlashAttribute("message", "File uploaded successfully");
		}else{
			redirectAttributes.addFlashAttribute("fileException", comment);
		}
		return "redirect:/admin/simplification";
	}
	
	//Monika : Create
	
	
	@RequestMapping(value = "/admin/simplification", method = RequestMethod.GET)
	public String addSimplification(Model model) {
		
		return "admin/simplification";
	}
	
	@RequestMapping(value = "/admin/uploadFile/createSimplification", method = RequestMethod.POST)
	public String uploadFileFrSimpli(Model model,final RedirectAttributes redirectAttributes,final HttpServletRequest request, final HttpSession session) throws FileUploadException, IOException
	{
		String fileName="Simplification Files";
		String comments = "";
		String message="Analysis is in progress";
		long requestId=0;
		HANAUtility.deleteFile(fileName, requestId,null);
		HANAUtility.changeRequestProgressValue(requestId,0,message);	
		Map<String,String> fileList = new HashMap<String,String>();
		try 
		{
			final String filePath = HANAUtility.getFilePath(fileName, requestId);
			HANAUtility.changeRequestProgressValue(requestId,0,"File's Checking Under Process");
			DiskFileItemFactory factory = new DiskFileItemFactory();
			factory.setSizeThreshold(0);
			factory.setRepository(new File(HANAUtility.getRepositoryTemp(fileName, requestId)));

			ServletFileUpload upload = new ServletFileUpload(factory);
			upload.setFileSizeMax(-1);		
			upload.setSizeMax(-1);

			List<FileItem> multipart = new ServletFileUpload(factory).parseRequest(request);
			
			String filename="";
	
			
			/* File Validation Loop  Validation of files **/	

			for (FileItem item : multipart) {
				filename="";
				if (!item.isFormField()) {
					try {
					
						filename = new File(item.getName()).getName();
						if (StringUtils.isNotEmpty(filename) && !"".equals(filename)) {
							String extension=Hana_Profiler_Constant.XLSX_EXTENSTION_CONSTANT;
							String fileExtension = filename.substring(filename.length() - extension.length(),filename.length());
							if (extension.equalsIgnoreCase(fileExtension)) {
								logger.info("Matched Extension");
								item.write(new File(filePath + File.separator + filename));
								logger.info("Wrote in file path **");

							}else{
								redirectAttributes.addFlashAttribute("fileException", "Please Upload the file with .xlsx extension only.");
								return "redirect:/admin/simplification";
							}

						}else{
							redirectAttributes.addFlashAttribute("fileException", "Please Upload atleast one file.");
							return "redirect:/admin/simplification";
						}
					} catch (Exception exception) {
						redirectAttributes.addFlashAttribute("fileException", exception.getMessage());
						return "redirect:/admin/simplification";
					}
				}
				else{}
			}
			
			List<String> missingFiles = new ArrayList<String>();
			try 
			{
				InitialDataValidation initialDataValidation = new InitialDataValidation(filePath);
				CheckFileListStatus checkObject = new CheckFileListStatus(filePath);

				boolean checkListStatus = true;
				
				Map<String,String> filesNameWithStatus = checkObject.validateFiles("CreateSimplification",filePath);
				Iterator<String> listKeysIterator = filesNameWithStatus.keySet().iterator();
				Map<String,String> tempMap = new HashMap<>();
				while(listKeysIterator.hasNext())
				{
					String checkListName = listKeysIterator.next();
					//If the files is not present corresponding to checkList.
					if(!(filesNameWithStatus.get(checkListName)).equalsIgnoreCase("VALID"))
					{
						//If all the required files are not present then, add the missing files. 
						checkListStatus = false;
						missingFiles.add(checkListName);
					}
					else
					{
						for (Map.Entry<String, String> entry : fileList.entrySet()) 
						{
							if(entry.getKey().startsWith(checkListName.toUpperCase()))
							{
								tempMap.put(entry.getKey(), "VALID");
							}
						}
					}
				}
				boolean isAnyInvalidFile = false;
				//At the end, make all the files that have unexpected name as invalid.
				for (Map.Entry<String, String> entry : fileList.entrySet())
				{
					if(!tempMap.containsKey(entry.getKey()))
					{
						isAnyInvalidFile = true;
						if(fileList.get(entry.getKey()).equalsIgnoreCase("VALID"))
						{
							fileList.put(entry.getKey(), "INVALID FILE NAME.");
						}
					}
				}
				logger.info("after checkListStatus");

				//If all required file are present, then proceed for XLSX validation.
				try
				{
					if (initialDataValidation.validateAllFiles(fileList, "CreateSimplification")) 
					{
						 message = HANAUtility.getPropertyValue("testing.properties", "filelistokmessage");
						 HANAUtility.changeRequestProgressValue(requestId,10,message);		
					}
					else
					{
						//Somehow validation of files have failed and instead of throwing an exception 
						// it has returned false.
						logger.info("inside else block ");
						
						comments = HANAUtility.getPropertyValue("testing.properties", "filelistnotokmessage");
						redirectAttributes.addFlashAttribute("fileException", comments);
						return "redirect:/admin/simplification";
						
					}
					if (!checkListStatus || isAnyInvalidFile)
					{
						if(!missingFiles.isEmpty())
						{
							comments = "Please upload "+missingFiles+" files for processing this request.";
							redirectAttributes.addFlashAttribute("fileException", comments);
							return "redirect:/admin/simplification";
						}
						else
						{
							comments = "Please upload valid files only";
							redirectAttributes.addFlashAttribute("fileException", comments);
							return "redirect:/admin/simplification";
						}
						
					}
				}
				
				catch (Exception e) 
				{
					logger.error("In Exception catch: " + e.getMessage());
					logger.error("Error !!! " + e);
					redirectAttributes.addFlashAttribute("message", e.getMessage());
					return "redirect:/admin/simplification";
				}

			}finally{}
			try
			{
			 HANAUtility.changeRequestProgressValue(requestId,20,"Files Uploaded Successfully.");	
			String comment= readSimplificationData((filePath),requestId,request,session);
			if(comment.equalsIgnoreCase("success")){
				HANAUtility.changeRequestProgressValue(requestId,40,"Data Saved Successfully.");	
				//redirectAttributes.addFlashAttribute("message", "File uploaded successfully, creation under process.");
			//	comment=createSimplification(requestId);
			//	if(comment.equalsIgnoreCase("success")){
					HANAUtility.changeRequestProgressValue(requestId,100,"Simplification to be uploaded successfully.");
					model.addAttribute("uploaded","true");
					model.addAttribute("message","Simplification created successfully");
					return "admin/simplification";
			/*	}else{
					redirectAttributes.addFlashAttribute("fileException", comment);
				}*/
			}else{
				redirectAttributes.addFlashAttribute("fileException", comment);
			}
			
			}catch (Exception e) {
				redirectAttributes.addFlashAttribute("fileException", e.getMessage());
				return "redirect:/admin/simplification";
			}
	}catch(Exception e){
		logger.error(e.getMessage());
	}
		return "redirect:/admin/simplification";
	}
	
	@RequestMapping(value = "/poc/uploadSimplificationDB", method = RequestMethod.POST)
	public String uploadSimplificationDB(final RedirectAttributes redirectAttributes,final HttpServletRequest request, HttpSession session) throws FileUploadException, IOException {
		logger.info("Coming inside UploadSimplifiationDBController");

		String fileName="Big Simplification File";
		String comments = "";
		String message="Analysis is in progress";
		long requestId=0;
		HANAUtility.deleteFile(fileName, requestId,null);
		HANAUtility.changeRequestProgressValue(requestId,0,message);	
		Map<String,String> fileList = new HashMap<String,String>();

		final String filePath = HANAUtility.getFilePath(fileName, requestId);
		logger.info("FilePath::::" +filePath);

			HANAUtility.changeRequestProgressValue(requestId,0,"File's Checking Under Process");
		DiskFileItemFactory factory = new DiskFileItemFactory();
		factory.setSizeThreshold(0);
		factory.setRepository(new File(HANAUtility.getRepositoryTemp(fileName, requestId)));

		ServletFileUpload upload = new ServletFileUpload(factory);
		upload.setFileSizeMax(-1);		
		upload.setSizeMax(-1);
		String    filename="";

		List<FileItem> multipart = new ServletFileUpload(factory).parseRequest(request);
		logger.info("Inside Initial Data validation method");

		final String userName = getPrincipal();
		boolean isFileExists = false;

		
		/* File Validation Loop  Validation of files **/	

		for (FileItem item : multipart) {
			filename="";
			if (!item.isFormField()) {
				try {
					isFileExists = true;
					filename = new File(item.getName()).getName();
					if (StringUtils.isNotEmpty(filename) && !"".equals(filename)) {
						String extension=Hana_Profiler_Constant.XLSX_EXTENSTION_CONSTANT;
						String fileExtension = filename.substring(filename.length() - extension.length(),filename.length());
						if (extension.equalsIgnoreCase(fileExtension)) {
							logger.info("Matched Extension");
							item.write(new File(filePath + File.separator + filename));
							logger.info("Wrote in file path **");

						}else{
							redirectAttributes.addFlashAttribute("fileException", "Please Upload the file with .xlsx extension only.");
							return "redirect:/admin/simplification";
						}

					}else{
						redirectAttributes.addFlashAttribute("fileException", "Please Upload atleast one file.");
						return "redirect:/admin/simplification";
					}
				} catch (Exception exception) {
					redirectAttributes.addFlashAttribute("fileException", exception.getMessage());
					return "redirect:/admin/simplification";
				}
			}
			else{}
		}
			
		List<String> missingFiles = new ArrayList<String>();
			try 
			{
				InitialDataValidation initialDataValidation = new InitialDataValidation(filePath);
				CheckFileListStatus checkObject = new CheckFileListStatus(filePath);

				boolean checkListStatus = true;
				
				Map<String,String> filesNameWithStatus = checkObject.validateFiles("BigSimplification",filePath);
				Iterator<String> listKeysIterator = filesNameWithStatus.keySet().iterator();
				Map<String,String> tempMap = new HashMap<>();
				while(listKeysIterator.hasNext())
				{
				String checkListName = listKeysIterator.next();
				//If the file is not present corresponding to checkList.
				if(!(filesNameWithStatus.get(checkListName)).equalsIgnoreCase("VALID"))
					{
					//If all the required files are not present then, add the missing files. 
					checkListStatus = false;
					missingFiles.add(checkListName);
				}
				else
				{
					for (Map.Entry<String, String> entry : fileList.entrySet()) 
					{
					if(entry.getKey().startsWith(checkListName.toUpperCase()))
						{
						tempMap.put(entry.getKey(), "VALID");
						}
					}
				}
			}
				boolean isAnyInvalidFile = false;
				//At the end, make all the files that have unexpected name as invalid.
				for (Map.Entry<String, String> entry : fileList.entrySet())
				{
					if(!tempMap.containsKey(entry.getKey()))
					{
						isAnyInvalidFile = true;
						if(fileList.get(entry.getKey()).equalsIgnoreCase("VALID"))
						{
							fileList.put(entry.getKey(), "INVALID FILE NAME.");
						}
					}
				}
				logger.info("after checkListStatus");

				//If all required file are present, then proceed for XLSX validation.
				try
				{
					if (initialDataValidation.validateAllFiles(fileList, "BigSimplification")) 
					{
						 message = HANAUtility.getPropertyValue("testing.properties", "filelistokmessage");
						 HANAUtility.changeRequestProgressValue(requestId,10,message);		
					}
					else
					{
						//Somehow validation of files have failed and instead of throwing an exception 
						// it has returned false.
						logger.info("inside else block ");
						
						comments = HANAUtility.getPropertyValue("testing.properties", "filelistnotokmessage");
						redirectAttributes.addFlashAttribute("fileException", comments);
						return "redirect:/admin/simplification";
						
					}
					if (!checkListStatus || isAnyInvalidFile)
					{
						if(!missingFiles.isEmpty())
						{
							comments = "Please upload "+missingFiles+" files for processing this request.";
							redirectAttributes.addFlashAttribute("fileException", comments);
							return "redirect:/admin/simplification";
						}
						else
						{
							comments = "Please upload valid files only";
							redirectAttributes.addFlashAttribute("fileException", comments);
							return "redirect:/admin/simplification";
						}
						
					}
				}
				
				catch (Exception e) 
				{
					logger.error("In Exception catch: " + e.getMessage());
					logger.error("Error !!! " + e);
					redirectAttributes.addFlashAttribute("message", e.getMessage());
					return "redirect:/admin/simplification";
				}

			}finally{}
			try
			{
			 HANAUtility.changeRequestProgressValue(requestId,20,"Files Uploaded Successfully.");	
			readBigSimplificationDBData((filePath),requestId,request,session);
			redirectAttributes.addFlashAttribute("message", "File uploaded successfully");
			/*if(comment.equalsIgnoreCase("success")){
				HANAUtility.changeRequestProgressValue(requestId,100,"Data Saved Successfully.");	
			}else{
				redirectAttributes.addFlashAttribute("fileException", comment);
			}*/
			
	}catch(Exception e){
		logger.error(e.getMessage());
	}
		return "redirect:/admin/simplification";
	
	}
	

	@RequestMapping(value = "/poc/uploadEstimations/{requestID}/S4", method = RequestMethod.POST)
	public String uploadEstimations(@PathVariable("requestID") final long requestID,
			final RedirectAttributes redirectAttributes,final HttpServletRequest request,HttpSession session) throws FileUploadException {

		final RequestForm reuquestForm = getRequestDetails().getRequestObj(requestID);
		final String clientName = reuquestForm.getClientName();
		HANAUtility.deleteFile(clientName, requestID,null);
		final String filePath = HANAUtility.getFilePath(clientName, requestID);

		String toolName = (String) session.getAttribute("tool");
		
		DiskFileItemFactory factory = new DiskFileItemFactory();
		factory.setSizeThreshold(0);
		factory.setRepository(new File(HANAUtility.getRepositoryTemp(clientName, requestID)));

		ServletFileUpload upload = new ServletFileUpload(factory);
		upload.setFileSizeMax(-1);		
		upload.setSizeMax(-1);

		String    filename="";
		List<FileItem> multipart = new ServletFileUpload(factory).parseRequest(request);

		logger.info("Inside Initial Data validation method");

		final String userName = getPrincipal();
		boolean isFileExists = false;

		/* File Validation Loop  Validation of files **/	

		for (FileItem item : multipart) {
			filename="";
			if (!item.isFormField()) {
				try {
					isFileExists = true;
					filename = new File(item.getName()).getName();
					if (StringUtils.isNotEmpty(filename) && !"".equals(filename)) {
						String extension=Hana_Profiler_Constant.XLSX_EXTENSTION_CONSTANT;
						String fileExtension = filename.substring(filename.length() - extension.length(),filename.length());
						if (extension.equalsIgnoreCase(fileExtension)) {
							logger.info("Matched Extension");
							item.write(new File(filePath + File.separator + filename));
							logger.info("Wrote in file path");

						}else{
							redirectAttributes.addFlashAttribute("donLoadXlsxError", "Please Upload the file with .xlsx extension only.");
							return "redirect:/requestDetails/{requestID}";
						}

					}else{
						redirectAttributes.addFlashAttribute("donLoadXlsxError", "Please Upload atleast one file.");
						return "redirect:/requestDetails/{requestID}";
					}
				} catch (Exception exception) {
					redirectAttributes.addFlashAttribute("donLoadXlsxError", exception.getMessage());
					return "redirect:/requestDetails/{requestID}";
				}
			}
			else{}
		}

		String comment= readEstimationData((filePath + File.separator + filename),requestID,request,toolName,session);
		if(comment.equalsIgnoreCase("success")){
			redirectAttributes.addFlashAttribute("SucessMsg", "File uploaded successfully");
		}else{
			redirectAttributes.addFlashAttribute("donLoadXlsxError", comment);
		}
		return "redirect:/requestDetails/{requestID}";
	}
	
	@RequestMapping(value = "/poc/uploadValidation", method = RequestMethod.POST)
	public String uploadValidationList(final RedirectAttributes redirectAttributes,final HttpServletRequest request, HttpSession session) throws FileUploadException {
		logger.info("Coming inside uploadValidationController");
		String fileName="Validation";
		long requestId=0;
		
		HANAUtility.deleteFile(fileName, requestId,null);
		final String filePath = HANAUtility.getFilePath(fileName, requestId);
		logger.info("FilePath::::" +filePath);
		DiskFileItemFactory factory = new DiskFileItemFactory();
		factory.setSizeThreshold(0);
		factory.setRepository(new File(HANAUtility.getRepositoryTemp(fileName, requestId)));

		ServletFileUpload upload = new ServletFileUpload(factory);
		upload.setFileSizeMax(-1);		
		upload.setSizeMax(-1);

		String    filename="";
		List<FileItem> multipart = new ServletFileUpload(factory).parseRequest(request);

		logger.info("Inside Initial Data validation method");

		final String userName = getPrincipal();
		boolean isFileExists = false;

		/* File Validation Loop  Validation of files **/	

		for (FileItem item : multipart) {
			filename="";
			if (!item.isFormField()) {
				try {
					isFileExists = true;
					filename = new File(item.getName()).getName();
					if (StringUtils.isNotEmpty(filename) && !"".equals(filename)) {
						String extension=Hana_Profiler_Constant.XLSX_EXTENSTION_CONSTANT;
						String fileExtension = filename.substring(filename.length() - extension.length(),filename.length());
						if (extension.equalsIgnoreCase(fileExtension)) {
							logger.info("Matched Extension");
							item.write(new File(filePath + File.separator + filename));
							logger.info("Wrote in file path **");

						}else{
							redirectAttributes.addFlashAttribute("fileException", "Please Upload the file with .xlsx extension only.");
							return "redirect:/admin/simplification";
						}

					}else{
						redirectAttributes.addFlashAttribute("fileException", "Please Upload atleast one file.");
						return "redirect:/admin/simplification";
					}
				} catch (Exception exception) {
					redirectAttributes.addFlashAttribute("fileException", exception.getMessage());
					return "redirect:/admin/simplification";
				}
			}
			else{}
		}

		String comment= readValidationData((filePath + File.separator + filename),requestId,request);
		if(comment.equalsIgnoreCase("success")){
			redirectAttributes.addFlashAttribute("message", "File uploaded successfully");
		}else{
			redirectAttributes.addFlashAttribute("fileException", comment);
		}
		return "redirect:/admin/simplification";
	}
	
	
	//CR-40.0
	/*@RequestMapping(value = "/poc/uploadSimplificationDB", method = RequestMethod.POST)
	public String uploadSimplificationDB1(final RedirectAttributes redirectAttributes,final HttpServletRequest request) throws FileUploadException {
		System.out.println("Coming inside UploadSimplifiationDBController");
		String fileName="Simplification_identifier";
		long requestId=0;
		
		HANAUtility.deleteFile(fileName, requestId,null);
		final String filePath = HANAUtility.getFilePath(fileName, requestId);
		System.out.println("FilePath::::" +filePath);
		DiskFileItemFactory factory = new DiskFileItemFactory();
		factory.setSizeThreshold(0);
		factory.setRepository(new File(HANAUtility.getRepositoryTemp(fileName, requestId)));

		ServletFileUpload upload = new ServletFileUpload(factory);
		upload.setFileSizeMax(-1);		
		upload.setSizeMax(-1);

		String    filename="";
		List<FileItem> multipart = new ServletFileUpload(factory).parseRequest(request);

		logger.info("Inside Initial Data validation method");

		final String userName = getPrincipal();
		boolean isFileExists = false;

		 File Validation Loop  Validation of files *	

		for (FileItem item : multipart) {
			filename="";
			if (!item.isFormField()) {
				try {
					isFileExists = true;
					filename = new File(item.getName()).getName();
					if (StringUtils.isNotEmpty(filename) && !"".equals(filename)) {
						String extension=Hana_Profiler_Constant.XLSX_EXTENSTION_CONSTANT;
						String fileExtension = filename.substring(filename.length() - extension.length(),filename.length());
						if (extension.equalsIgnoreCase(fileExtension)) {
							logger.info("Matched Extension");
							item.write(new File(filePath + File.separator + filename));
							logger.info("Wrote in file path **");

						}else{
							redirectAttributes.addFlashAttribute("fileException", "Please Upload the file with .xlsx extension only.");
							return "redirect:/admin/simplification";
						}

					}else{
						redirectAttributes.addFlashAttribute("fileException", "Please Upload atleast one file.");
						return "redirect:/admin/simplification";
					}
				} catch (Exception exception) {
					redirectAttributes.addFlashAttribute("fileException", exception.getMessage());
					return "redirect:/admin/simplification";
				}
			}
			else{}
		}

		String comment= readSimplificationDBData((filePath + File.separator + filename),requestId,request);
		if(comment.equalsIgnoreCase("success")){
			redirectAttributes.addFlashAttribute("message", "File uploaded successfully");
		}else{
			redirectAttributes.addFlashAttribute("fileException", comment);
		}
		return "redirect:/admin/simplification";
	}
*/
}
