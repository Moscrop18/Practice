 /**CR-48:- Consolidated both the tool so that they can executed separately -monika.mishra
 **/

package com.act.S4.fileProcessing;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.act.fileprocesing.dao.ST03HanaDAOImpl;
import com.act.fileprocessing.PopulateHanaTables;
import com.act.fileprocessing.ST03DataAnalysis;

/**
 * @author monika.mishra
 *
 */
public class S4DataAnalysis {
	
	private ST03HanaDAOImpl st03Hanadao;

	private S4ReaderXlsx s4ReaderXlsx;
	private PopulateHanaTables populateHanaTables;

	public void setPopulateHanaTables(PopulateHanaTables populateHanaTables) {
		this.populateHanaTables = populateHanaTables;
	}

/*	public void setSt03ReaderXlsx(St03ReaderXlsx st03ReaderXlsx) {
		this.st03ReaderXlsx = st03ReaderXlsx;
	}*/

	public void setS4ReaderXlsx(S4ReaderXlsx s4ReaderXlsx) {
		this.s4ReaderXlsx = s4ReaderXlsx;
	}

	public void setSt03Hanadao(ST03HanaDAOImpl st03Hanadao) {
		this.st03Hanadao = st03Hanadao;
	}

	final Logger logger = LoggerFactory.getLogger(ST03DataAnalysis.class);
	private String rootFolderPath;

	public S4DataAnalysis(String rootFolderPath) {
		super();
		this.rootFolderPath = rootFolderPath;
	}

	public S4DataAnalysis() {

	}

	public String getRootFolderPath() {
		return rootFolderPath;
	}

	public void setRootFolderPath(String rootFolderPath) {
		this.rootFolderPath = rootFolderPath;
	}
}
