package com.act.S4.fileProcessing;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.act.client.dao.RequestInventoryDAO;
import com.act.constant.Hana_Profiler_Constant;
import com.act.fileprocesing.dao.ST03HanaDAOImpl;
import com.act.fileprocessing.AutomateHANA;

/**
 * @author monika.mishra
 *
 */
public class AutomateS4 {
	
	final Logger logger = LoggerFactory.getLogger(AutomateHANA.class);

	public AutomateS4() {
	}

	private ST03HanaDAOImpl st03Hanadao;

	public void setSt03Hanadao(ST03HanaDAOImpl st03Hanadao) {
		this.st03Hanadao = st03Hanadao;
	}


	
	public void clearAllTables(String token, Long requestID) {

		logger.info("Coming inside Clear all tables:::");
		if (Hana_Profiler_Constant.ALL.equals(token)) {
			
			logger.info("Coming inside Clear all tables: IF   ::");
			st03Hanadao.deleteFromTable(requestID, "S4CloneProg");
			st03Hanadao.deleteFromTable(requestID, "S4CloneIntermediate");
			st03Hanadao.deleteFromTable(requestID, "S4AppendStructureAnalysis");
			st03Hanadao.deleteFromTable(requestID, "S4Detection");
			st03Hanadao.deleteFromTable(requestID, "S4HanaProfiler");
			st03Hanadao.deleteFromTable(requestID, "S4ImpactedSearchHelp");
			st03Hanadao.deleteFromTable(requestID, "S4UsageAnalysis");
			st03Hanadao.deleteFromTable(requestID, "S4InventoryList");
			st03Hanadao.deleteFromTable(requestID, "S4DetailReportComplexity");
			st03Hanadao.deleteFromTable(requestID, "S4DetailReportRemediation");
			//CR-21.0
			st03Hanadao.deleteFromTable(requestID, "S4ImpactedIDOC");
			st03Hanadao.deleteFromTable(requestID, "S4ImpactedTables");
			st03Hanadao.deleteFromTable(requestID, "S4AffectCustomField");
			st03Hanadao.deleteFromTable(requestID, "S4OutputMgmt");
			st03Hanadao.deleteFromTable(requestID, "S4ImpactedTransaction");
			st03Hanadao.deleteFromTable(requestID, "Lsmw");
			st03Hanadao.deleteFromTable(requestID, "UserExit");
			st03Hanadao.deleteFromTable(requestID, "S4ImpactedObjectList");
			
		}

		
	}

	


}
