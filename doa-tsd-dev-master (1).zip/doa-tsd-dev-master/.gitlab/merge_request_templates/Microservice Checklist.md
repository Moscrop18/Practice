## Description
>  write (of paste from Jira) a small 1 or 2 scentances description of this change. This text will be used in the release notes
## Status
- [ ] Implemented
- [ ] Unit tested 
- [ ] FAT scenario 
- [ ] FAT automation
- [ ] Exploratory Testing
- [ ] Approved for merge 

## Developer checklist
 This is the Technical analysis Detail section, to be checked either here or in the corresponding JIRA ticket. 
* [ ] Is a user story or use case taken as input and was it up to date and approved ?
* [ ] Is the Software Architecture Document (SAD) taken as input and was it up to date?
  * [ ] Are all interfaces between systems (internal and external) documented correctly ?
* [ ] Are the DB level changes documented and scripted with Flyway?
  * [ ] Do all DB changes support [Zero Downtime Deployments](https://cicd.finbel.intra/doa/foundation/doc-codingguidelines.dev/blob/master/doc/DevOps.md#database-migrations)
* [ ] If the design is impacted, have the changes been described?
* [ ] Is the Helm chart documentation updated to reflect new installation instructions or environment variables.

## Maintainer checklist
Approving a merge request means that the reviewer has validated the questions below:
* [ ] [Have the coding guidelines](https://cicd.finbel.intra/doa/foundation/doc-codingguidelines.dev) been reviewed ? 
  * [ ] Has an inline comment been provided for complex logic? Does it explain "WHY" the code was written?    
  * [ ] Has all the code been tested using unit test, integration tests, contract and functional testing
* [ ] Has approval for any new open source software or utility used been given by IN/BE Lead Architect.
* [ ] Has FodFin standard audit logging been applied correctly, using the correct transaction as input?
* [ ] Are secure coding principles applied
  * [ ] All Sonar Vulnerabilities are reviewed and handled.
  * [ ] Are parameterized queries (with named parameters instead of
         concatenating strings with user-controlled variables to build sql)
         used for all database access ?
* [ ] Does the 'new code' pass the Sonar Quality Gate?
  * [ ] Rules compliance should be more than 90% and there should be no critical or blocker issues
* [ ] Was code written with performance in mind
  * [ ] Are all database Queries & ddl statements reviewed by Lead/DBA?   
  * [ ] Was the code reviewed for unwanted queries (N+1 problems etc.)
  * [ ] Was the necessary caching applied




 



