**Merge Request Review Questions**

## Developer checklist
 This is the Technical analysis Detail section, to be checked either here or in the corresponding JIRA ticket. 
* [ ] Is a user story or use case taken as input and was it up to date and approved ?
* [ ] Is the Software Architecture Document (SAD) taken as input and was it up to date?
* [ ] If the design is impacted, have the changes been described?
* [ ] Is the Helm chart documentation updated to reflect new installation instructions or environment variables.

## Maintainer checklist
Approving a merge request means that the reviewer has validated the questions below:
* [ ] [Have the coding guidelines](https://cicd.finbel.intra/doa/foundation/doc-codingguidelines.dev) been reviewed ? 
  * [ ] Has an inline comment been provided for complex logic? Does it explain "WHY" the code was written?    
  * [ ] Has all the code been tested using unit test, integration tests, contract and functional testing
* [ ] Has approval for any new open source software or utility used been given by IN/BE Lead Architect.
* [ ] Have the GUI changes been tested in all supported browsers listed in the NFR? 
* [ ] Is the code validated against the UI design (by ux designer) and is the [visual identity](https://minfin.atlassian.net/wiki/spaces/CWC/pages/1799651390/Visual+Identity) respected?
* [ ] Are secure coding principles applied
  * [ ] All Sonar Vulnerabilities are reviewed and handled.
  * [ ] Are protections against XSS and [CORS](https://portswigger.net/web-security/cors) been applied? see [Angular Security](https://angular.io/guide/security) and [XSS Prevention](https://cheatsheetseries.owasp.org/cheatsheets/Cross_Site_Scripting_Prevention_Cheat_Sheet.html) 
* [ ] Does the 'new code' pass the Sonar Quality Gate?
  * [ ] Rules compliance should be more than 90% and there should be no critical or blocker issues
* [ ] Was code written with performance in mind
  * [ ] Was the necessary caching applied




 



