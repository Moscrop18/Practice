# TSD Microservice application

This chart deploys the TSD Microservice in a k8s cluster.

TODO:
 * This is work in-progress so, subject to change.

## Chart Details

This chart will do the following:

- Deploy the TSD Microservice
- Deploy a Rabbit MQ cluster
- Expose an ingress

## Pre-requisites

list all the pre-requisites here

## Installing the Chart

```shell
$ helm repo add harbor https://finvmharbord01.finbel.intra/chartrepo/masp
$ helm repo update
```

```shell
$ helm upgrade ${RELEASE_NAME} tsd --version ${VERSION}
        --install --atomic --wait
        --kube-context $ENV_NAME
        --namespace $K8S_NAMESPACE
        --set image.repository="${IMAGE_REPO}/${REGISTRY_PROJECT}/${IMAGE_NAME}"
        --set image.tag="${VERSION}${IMAGE_SHA:+@}${IMAGE_SHA}"
        --set ingress.hosts[0].host="${ENV_HOST}"
        --username=$REGISTRY_USER
        --password=$REGISTRY_PASSWORD
$ helm repo update
```

## Secret Management

Two options are supported for configuring secrets, one is using kubernetes secrets the other is using HashiCorp Vault. Both options could be used together.

The most secure option and the FodFin Standard is to use HashiCorp vault.

### Kubernetes Secrets

All the configuration properties from the section below, prefixed with `config.` can be used in a kubernetes secret by using the prefix `secrets` instead.
The full set of settings starting with `secrets` will be converted in a single kubernetes secret which is then passed on as a secretRef to the container.

### Vault secrets

When specifying the variable `vault.enabled` as true, HashiCorp vault will be used to retrieve the secrets.
One or more Vault secrets can be specified. Those will be loaded using the vault sidecar agent mechanism as explained here.
https://learn.hashicorp.com/vault/getting-started-k8s/sidecar

It is assumed that the Kubernetes mutating admission webhook for the vault agent is configured correctly on the cluster to be used.

#### Configuration required in vault

You can store any configuration setting prefixed with `config` from the table below in vault. To do so you first need to create a key value store following the FodFin naming conventions `secret/apps/<pillar>/<project>/<environment>`.
Then you need to fill in the fields(key value pairs) for this secret. One secret can hold multiple key value pairs and it is recommended to group most passwords in a single secret.

The fields names should correspond to the configuration setting without the `config.` prefix from the table below and you should replace the `.` in variable names with an `_` underscore. So for instance `config.database.owner.user` will become `database_owner_user` in vault.

The vault secrets are loaded with an init containers and made available as environment variable to the container.
To do so each secret defined in `vault.secrets` like `vault.secrets.abc` will be written to an `abc.env` file and 'sourced' at the start of the container.
If multiple secrets have the same field the last one defined will win. The order in which the files are sourced is alphabetically.

If a config map or secret exists for the same variable, the vault configured values will take precedence.

An example on how to create a secret in vault for the maps-demo review environment is shown below:

```shell
$ vault kv put secret/apps/doa/masp-demo/review database_password=pass database_owner_password=pass queues_rabbitmq_password=rabbit
```

Then you need to create a vault policy to allow the read access to this secret

```shell
$ vault policy write doa-masp-demo-review - <<EOF
path "secret/data/apps/doa/masp-demo/review" {
  capabilities = ["read"]
}
EOF
```

Please make sure you used the `/data/` part of the path as for kv-v2 the path is secret/data/apps... not secret/apps like you might expect.

Finally add a kubernetes authentication role where you link the service account that will be used to run this application see `serviceAccount.name`
and the namespace to the correct vault policy.

```shell
$ vault write auth/kubernetes/role/doa-masp-demo-review \
        bound_service_account_names=sa-app-doa-masp-demo \
        bound_service_account_namespaces=doa-masp-review \
        policies=doa-masp-demo-review \
        ttl=24h
```

## RabbitMQ ha cluster
There's an option to install a RabbitMQ-ha cluster (see configuration `rabbitmq-ha.enabled`).
By default it will use mirror queues and persistent volumes. A default of exactly 2 queue replicas is chosen for performance reasons.

Please adjust the persistence volume claim size based on the foreseen message volumes.

Note: For setting the rabbitmq hostname in for the app, you can include the release name through a variable:
  config.rabbitmq.host: {{ include "app.fullname" . }}-rabbitmq-ha.yournamespace.svc.cluster.local

## Configuration

The following table lists the configurable parameters of the pn microservice chart and their default values.

TODO: update this table

| Parameter                            | Description                                                                                  | Default                                      |
| ------------------------------------ | -------------------------------------------------------------------------------------------- | -------------------------------------------- |
| `imagePullSecrets`                   | Docker registry pull secret                                                                  |                                              |
| `serviceAccount.name`                | The name of the ServiceAccount for running the application                                   | `sa-app-doa-tsd`                             |
| `serviceAccount.create`              | Specifies whether a ServiceAccount should be created                                         | `true`                                       |
| `nameOverride`                       | The name of the chart                                                                        | Generated using the name template            |
| `fullname`                           | The fully qualified app name                                                                 | Generated using the fullname template        |
| `podSecurityContext`                 | Specify pod security context                                                                 |                                              |
| `securityContext`                    | Specify container security context                                                           | `runAsUser: 1000  runAsGroup: 3000`          |
| `image.pullPolicy`                   | Container pull policy                                                                        | `IfNotPresent`                               |
| `image.repository`                   | Container image                                                                              | `finvmharbord01.finbel.intra/masp/pn`        |
| `image.tag`                          | Container image tag                                                                          |                                              |
| `service.type`                       | The service type to create                                                                   | `ClusterIP`                                  |
| `service.port`                       | The port on which to expose the service                                                      | `8080`                                       |
| `containerPort.http`                 | The exposed port on the container for the standard http service                              | `8888`                                       |
| `containerPort.management`           | The exposed port on the container for the management services                                | `9999`                                       |
| `podAnnotations`                     | Additional pod annotations                                                                   | `{}`                                         |
| `livenessProbe.enabled`              | Enable liveness probe                                                                        | `true`                                       |
| `livenessProbe.path`                 | liveness probe HTTP Get path                                                                 | `/health`                                    |
| `livenessProbe.port`                 | liveness probe HTTP port                                                                     | Defaults to `containerPort.management` value |
| `livenessProbe.initialDelaySeconds`  | Delay before liveness probe is initiated                                                     | 180                                          |
| `livenessProbe.periodSeconds`        | How often to perform the probe                                                               | 10                                           |
| `livenessProbe.timeoutSeconds`       | When the probe times out                                                                     | 10                                           |
| `livenessProbe.successThreshold`     | Minimum consecutive successes for the probe to be considered successful after having failed. | 1                                            |
| `livenessProbe.failureThreshold`     | Minimum consecutive failures for the probe to be considered failed after having succeeded.   | 3                                            |
| `readinessProbe.enabled`             | Enable liveness probe                                                                        | `true`                                       |
| `readinessProbe.path`                | liveness probe HTTP Get path                                                                 | `/health`                                    |
| `readinessProbe.port`                | liveness probe HTTP port                                                                     | Defaults to `containerPort.management` value |
| `readinessProbe.initialDelaySeconds` | Delay before liveness probe is initiated                                                     | 180                                          |
| `readinessProbe.periodSeconds`       | How often to perform the probe                                                               | 10                                           |
| `readinessProbe.timeoutSeconds`      | When the probe times out                                                                     | 10                                           |
| `readinessProbe.successThreshold`    | Minimum consecutive successes for the probe to be considered successful after having failed. | 1                                            |
| `readinessProbe.failureThreshold`    | Minimum consecutive failures for the probe to be considered failed after having succeeded.   | 3                                            |
| `replicaCount`                       | Number of replicas which will be deployed                                                    | `1`                                          |
| `resources.requests.memory`          | PN container initial memory request                                                          | `200Mi`                                      |
| `resources.requests.cpu`             | PN container initial cpu request                                                             | `100m`                                       |
| `resources.limits.memory`            | PN container memory limit                                                                    | `512Mi`                                      |
| `resources.limits.cpu`               | PN container cpu limit                                                                       |                                              |
| `ingress.enabled`                    | If true an Ingress will be created                                                           | `true`                                       |
| `ingress.annotations`                | Ingress annotations                                                                          | `{}`                                         |
| `ingress.hosts`                      | Ingress hostnames                                                                            | `[]`                                         |
| `ingress.path`                       | Ingress path                                                                                 |                                              |
| `metrics.enabled`                    | If true annotate the pod with prometheus scraping annotations                                | `true`                                       |
| `nodeSelector`                       | Configure on which nodes the pods must run based on labels                                   | `{}`                                         |
| `affinity`                           | Configure affinity and anti-affinity of pods                                                 | `{}`                                         |
| `tolerations`                        | Configure Taints and Tolerations                                                             | `{}`                                         |
| `vault.enabled`                      | Use HashiCorp Vault to retrieve secrets                                                      | false                                        |
| `vault.role`                         | The vault role to use for accessing the secrets. eg. doa-masp-demo-test                      |                                              |
| `vault.secrets.'name.env'`           | The 'name' of the kv secret from vault to load.                                              |                                              |
| `vault.secrets.'name.env'.vaultPath` | Path to the key value store in vault where the secrets are stored                            |                                              |
| `database.type`                      | Database type (`db2`)                                                                        | `db2`                                        |
| `active.profiles`                    | Profiles for the application to activate. Options are: (production,management)               | `production,management`                      |
| `rabbitmq-ha.enabled`                | Setup a RabbitMQ ha cluster. Only overridden values by this chart are mentioned below. For setting any other value, see [rabbitmq-ha](https://hub.helm.sh/charts/stable/rabbitmq-ha), and prefix them with "rabbitmq-ha". | `false` |
| `rabbitmq-ha.image.repository`                | RabbitMQ container image repository. Note: only alpine images are supported. | `finvmharbord01.finbel.intra/base/rabbitmq` |
| `rabbitmq-ha.image.tag`                | RabbitMQ container image tag.| `3.8.4-management-alpine` |
| `rabbitmq-ha.busyboxImage.repository`                | Busybox initContainer image repo | `finvmharbord01.finbel.intra/library/busybox` |
| `rabbitmq-ha.busyboxImage.tag`                | Busybox initContainer image tag | `1.24` |
| `rabbitmq-ha.definitions.policies`                | HA policies to add to definitions.json. By default a high availablity of exactly 2 queue replicas is set. | `{"name": "ha-exactly2", "pattern": ".*", "vhost": "/", "definition": "ha-mode": "exactly", ha-params": 2", "ha-sync-mode": "automatic", ha-sync-batch-size": 1 } }` |
| `rabbitmq-ha.persistentVolume.enabled`  | If true, persistent volume claims are created.                        | `true`                                               |
| `rabbitmq-ha.persistentVolume.annotations`  | Persistent volume annotations. | `volume.beta.kubernetes.io/storage-class: vspherestorage`                                               |
| `rabbitmq-ha.persistentVolume.size`  | Persistent volume size.                        | `5Gi`                                               |
| `rabbitmq-ha.rabbitmqErlangCookie`   | Erlang cookie. (required for upgrading rabbitmq-ha releases)            | `doa-masp-demo-rabbitmq-ha-cookie`                    |
| `rabbitmq-ha.prometheus.operator.enabled`   | Prometheus Operator. Not used by default. | `false`                    |
| `rabbitmq-ha.rabbitmqPrometheusPlugin.enabled`   | Enable native RabbitMQ prometheus plugin. | `true`                    |
| `rabbitmq-ha.rabbitmqPrometheusPlugin.config`   | RabbitMQ prometheus plugin additional configuration. By default metrics per queue are enabled. | `"prometheus.return_per_object_metrics = true"`                    |
| `rabbitmq-bitnami.enabled`                | Setup a RabbitMQ bitnami cluster (cannot be used for high available options like mirror queues). For setting any value, see [rabbitmq-bitnami](https://github.com/bitnami/charts/tree/master/bitnami/rabbitmq), and prefix them with "rabbitmq-bitnami". | `false` |
| `rabbitmq-ha.serviceAccount.name`   | Service account name to use. | `sa-app-masp-demo-rabbitmq-ha`                    |
| `rabbitmq-ha.serviceAccount.create`   | Create service account. | `false`                    |
| `mock.enabled`             | Enable WireMock mock server & GUI for mocking external dependencies   | `false`                                                      |
| `mock.image.repository`    | Wiremock GUI container repository                                     | `finvmharborp01.finbel.intra/trv-base/holomekc/wiremock-gui` |
| `mock.image.tag`           | WireMock GUI container tag                                            | `tag`                                                        |
| `mock.image.pullPolicy`    | Mock Container pull policy                                            | `IfNotPresent`                                               |
| `mock.podSecurityContext`  | Specify mock pod security context                                     |                                                              |
| `mock.securityContext`     | Specify mock container security context                               | `runAsUser: 1000  runAsGroup: 3000`                          |
| `mock.containerPort.http`  | The exposed port on the mock container for the standard http service  | `8089`                                                       |
| `mock.containerPort.https` | The exposed port on the mock container for the standard https service | `8090`                                                       |
| `mock.service.type`        | The mock service type to create                                       | `ClusterIP`                                                  |
| `mock.service.port`        | The port on which to expose the mock service                          | `80`                                                         |
| `mock.ingress.enabled`     | Enabled the mock Ingress                                              | `false`                                                      |
| `mock.ingress.annotations` | Mock Ingress annotations                                              | `{kubernetes.io/ingress.class: "nsx"}`                       |
| `mock.ingress.hosts`       | Mock Ingress hostnames                                                | `[]`                                                         |
| `mock.ingress.path`        | Mock Ingress path                                                     |                                                              |
| `mock.wiremockOptions`     | Value for WIREMOCK_OPTIONS environment variable see                   |  --port=8089, --max-request-journal=10000, --local-response-templating, --async-response-enabled=true, --root-dir=/home/wiremock/data                                                            |
| `mock.mapping.enabled`     | Enable loading of WireMock Mapping files                              | `false`                                                      |
| `mock.mapping.files`       | Array of file paths to load, must be part of the chart                | `[]` e.g `mock/mappings/*.json`                              |
| `mock.mapping.data`        | Mapping data to add, defined inline                                   | `[]` e.g `filename.json: |-`                                 |
| `timerExpirationSa.cronJob.name`        | Timer Expiration cron job name                                       | `timer-expiration-cron`                                                  |
| `timerExpirationSa.cronJob.schedule`        | Scheduling of timer expiration cron job                                    | `Every Minute`                                                  |
| `timerExpirationSa.cronJob.concurrencyPolicy`        | Specifies how to treat concurrent executions of a job that is created by this cron job, default is Forbid, other options are Allow(The cron job allows concurrently running jobs) and Replace(If it is time for a new job run and the previous job run hasn't finished yet, the cron job replaces the currently running job run with a new job run)                                     | `Forbid`                                                  |
| `timerExpirationSa.cronJob.successfulJobsHistoryLimit`        | configure the number of successful CronJob executions that are saved, by specifying values for successfulJobsHistoryLimit                                       | `1`                                                  |
| `timerExpirationSa.cronJob.failedJobsHistoryLimit`        | configure the number of failed CronJob executions that are saved, by specifying values for failedJobsHistoryLimit.                                       | `1`                                                  |
| `timerExpirationSa.cronJob.ttlSecondsAfterFinished`        | A cluster operator can use this feature to clean up finished Jobs (either Complete or Failed) automatically by specifying the ttlSecondsAfterFinished field of a Job                                       | `0`                                                  |
| `timerExpirationSa.cronJob.url`        | URL of the cron job                                       | `/api/v1/tsd/checkExpirations`                                                  |
| `timerExpirationSa.cronJob.restartPolicy`        | Parameter to decide whether a cron job is supposed to restart itself, default value is Never, other options are setting its value to onFailure                                       | `Never`                                                  |
| `csrd2.cronJob.name`        | Cumada Reference Data referesh cron job name                                       | `csrd2-refresh`                                                  |
| `csrd2.cronJob.schedule`        | Scheduling of Cumada Reference Data referesh job                                    | `Every Midnight`                                                  |
| `csrd2.cronJob.concurrencyPolicy`        | Specifies how to treat concurrent executions of a job that is created by this cron job, default is Forbid, other options are Allow(The cron job allows concurrently running jobs) and Replace(If it is time for a new job run and the previous job run hasn't finished yet, the cron job replaces the currently running job run with a new job run)                                     | `Forbid`                                                  |
| `csrd2.cronJob.successfulJobsHistoryLimit`        | configure the number of successful CronJob executions that are saved, by specifying values for successfulJobsHistoryLimit                                       | `1`                                                  |
| `csrd2.cronJob.failedJobsHistoryLimit`        | configure the number of failed CronJob executions that are saved, by specifying values for failedJobsHistoryLimit.                                       | `1`                                                  |
| `csrd2.cronJob.ttlSecondsAfterFinished`        | A cluster operator can use this feature to clean up finished Jobs (either Complete or Failed) automatically by specifying the ttlSecondsAfterFinished field of a Job                                       | `0`                                                  |
| `csrd2.cronJob.url`        | URL of the cron job                                       | `/api/v1/refreshReferenceData`                                                  |
| `csrd2.cronJob.restartPolicy`        | Parameter to decide whether a cron job is supposed to restart itself, default value is Never, other options are setting its value to onFailure                                       | `Never`                                                  |


The following chart settings with prefix `config` are, when specified, used to create a config map.
These settings will be passed as environment variables to the `pn` container. For this to work the config prefix will be stripped, and the `.` will be replaced by an `_` (underscore).
 
When using `secret` instead of config the variable will be stored in a kubernetes secret instead.

| Parameter                            | Description                                                                                       | Default |
| ------------------------------------ | ------------------------------------------------------------------------------------------------- | ------- |
| `config.database.url`                | Database connection URL                                                                           | `jdbc:h2:mem:test;DB_CLOSE_ON_EXIT=TRUE;DB_CLOSE_DELAY=5` |
| `config.database.user`               | Database username for application to connect                                                      | `tsd`    |
| `config.database.password`           | Database password                                                                                 | `pass`  |
| `config.database.owner.user`         | Database migration specific username to connect to the database should be the owner of the schema | `tsd`    |
| `config.database.owner.password`     | Database password                                                                                 | `pass`  |
| `config.queues.rabbitmq.host`        | Rabbit MQ,containing the application queues, hostname                                             |         |
| `config.queues.rabbitmq.port`        | Rabbit MQ instance port                                                                           | `5672`  |
| `config.queues.rabbitmq.username`    | Rabbit MQ username                                                                                | `rabbit`|
| `config.queues.rabbitmq.password`    | Rabbit MQ password                                                                                | `rabbit`|
| `config.logging.level.root`          | Root log level configuration (debug,info,warn,error)                                              | `warn`  |
| `config.logging.be.fgov.minfin`      | Other log level configuration can be added like this.                                             | `debug` |
| `config.gateway.eo.registerRetryQueueListener`| Config parameter to weather to register retry queue listener used for retry with multiple delays                                                                                      | `"true"` |
| `config.gateway.eo.defaultplugin.url`| URL of EONGW                                                                                      | `"http://localhost:8889/api/v1/b2b/eoNotifications"` |
| `config.gateway.eo.defaultplugin.connectTimeout`| Timeout limit for connecting to EONGW                                                  | `1000`  |
| `config.tsd.accessControlAllowOrigin`                        | header value in response to allow request access from specific header                                      | `"*"`  |
| `config.tsd.accessControlAllowOrigin`                        | header value in response to client to read headers in case request orginated from diffrent origin                                      | `"*"`  |
| `config.tsd.countryCode`                        | System parameter to define Default country Code                                        | `"BE"`  |
| `config.tsd.timer.expiration.batchSize`        | System parameter to define batch size for fetching and deletion/expiration of timers   | `100`  |
| `config.events.registerRetryQueueListener`| Config parameter to weather to register retry queue listener used for retry with multiple delays                                                                                      | `"true"` |
| `config.gateway.pn.defaultplugin.url`           | URL of PN                                                                              | `"http://localhost:8889/api/v2/b2b/presentationNotifications"` |
| `config.gateway.pn.registerRetryQueueListener`| Config parameter to weather to register retry queue listener used for retry with multiple delays                                                                                      | `"true"` |
| `config.gateway.risk.defaultplugin.baseUrl`           | Base URL of Risk Analysis System                                                                              | `"http://localhost:8089/api/v1/TSD/riskAnalysis"` |
|  URL for sending IETS435 to Risk Analysis System                                                                              | `"http://localhost:8089/api/v1/TSD/riskAnalysis/{CRN}/riskAnalysisRequests"` |
|  URL for sending IETS417 to Risk Analysis System                                                                              | `"http://localhost:8089/api/v1/TSD/riskAnalysis/riskInvalidationRequests"` |
| `config.gateway.risk.registerRetryQueueListener`| Config parameter to weather to register retry queue listener used for retry with multiple delays                                                                                      | `"true"` |
| `config.gateway.risk.defaultplugin.connectTimeout`| Timeout limit for connecting to Risk Analysis                                                     | `30000`  |
| `config.gateway.risk.defaultplugin.requestTimeout`| Timeout limit for connecting to RGW                                                  | `30000`  |
| `config.gateway.control.defaultplugin.baseUrl`           | Base URL of Risk Analysis System (Control)                                                                             | `"http://localhost:8089/api/v1/TSD/control"` |
|  URL for sending IETS440 to Risk Analysis System  (Control)                                                                            | `"http://localhost:8089/api/v1/TSD/control/{CRN}/controlRecommendations"` |
| `config.gateway.control.registerRetryQueueListener`| Config parameter to weather to register retry queue listener used for retry with multiple delays                                                                                      | `"true"` |
| `config.gateway.control.defaultplugin.connectTimeout`| Timeout limit for connecting to RGW (Control)                                                 | `30000`  |
| `config.gateway.control.defaultplugin.requestTimeout`| Timeout limit for connecting to RGW (Control)                                                | `30000`  |
| `config.client.goodsaccounting.url`           | URL of GA System                                                                              | `"http://localhost:8089/api/v1"` |
| `config.client.goodsaccounting.offwritableDocumentClientEnabled`| Status for Client Enabled                                              | `true` |
| `config.client.goodsaccounting.connectTimeout`| Timeout limit for connecting to GA System                                                  | `30000`  |
| `config.client.goodsaccounting.requestTimeout`| Timeout limit for connecting to GA System                                                  | `30000`  |
| `config.gateway.enabledDefaultPlugins`| enabledDefaultPlugins for enable the default plugin based on condition                             | `EO, PN, ENS, RISK, CONTROL, GA` |
| `config.gateway.ga.registerRetryQueueListener`| Config parameter to weather to register retry queue listener used for retry with multiple delays                                                                                      | `"true"` |
| `config.gateway.pn.defaultplugin.connectTimeout`| Timeout limit for connecting to PN                                                     | `1000`  |
| `config.presentationOfGoodsDateExpiryInHours`| Presentation of Goods Expiry duration in hours                                            | `48`  |
| `config.declarationDateExpiryInHours`| Declaration Expiry duration in hours                                                              | `24`  |
| `config.nationalEnsSystemName`| National ENS System Name                                                                                 | `ENS`  |
| `config.gateway.eo.concurrency`| Number of listerners for sending message to EONGW                                                       | `1-10`  |
| `config.gateway.pn.activation-concurrency`| Number of listerners for sending activation message to PN                                    | `1-10`  |
| `config.gateway.pn.link-concurrency`| Number of listerners for sending linking message to PN                                             | `1-10`  |
 | `config.tracing.enabled`              | Feature flag to enable tracing in pn application using traced annotation                                                 | `true`  |
  | `config.tsd.draftTSDRemovalPeriod`              | Time period after which draft TSd become eligible for removal                                                 | 30  |
    | `config.tsd.awaitingRiskResultHours`              | Time period in hours in which risk analysis result is expected                                                 | 4  |
| `gateway.enabledDefaultPlugins`| All Enabled default plugins                                | `EO, PN, ENS, RISK, CONTROL, GA`  |    
| `gateway.ga.maxAttempts`| Max retry attempt for GA                                   | `2`  |
| `gateway.ga.backOffDelay`| Time delay limit for request to GA                                    | `1000`  |
| `client.goodsaccounting.url`| URL of GA                                   | `http://localhost:8089/api/v1`  |
| `client.goodsaccounting.requestTimeout`| Timeout limit for request to GA                                    | `30000`  |
| `client.goodsaccounting.connectTimeout`| Timeout limit for connecting to GA                                             | `30000`  |    