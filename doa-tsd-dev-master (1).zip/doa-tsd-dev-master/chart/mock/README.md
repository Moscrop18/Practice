	
# Mocking configuration for pn service
These mocking files cen used to run the pn service without one or more of its dependencies. 

TODO complete

Start wiremock make sure you are in the dev/mock directory

$ docker-compose up -d

Open the UI at the following url
http://localhost:8089/__admin/webapp/mappings

Stop wiremock and remove all containers
$ docker-compose down