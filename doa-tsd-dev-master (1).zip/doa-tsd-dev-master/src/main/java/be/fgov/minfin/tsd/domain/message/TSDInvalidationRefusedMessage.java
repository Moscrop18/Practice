/*
 * @(#)be.fgov.minfin.tsd.domain.message.TSDInvalidationRejectMessage.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.message;

import be.fgov.minfin.tsd.domain.model.BusinessValidationType;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.party.Party;
import be.fgov.minfin.tsd.domain.model.party.Representative;
import java.util.List;
import lombok.Builder;
import lombok.Value;

/**
 * @author MohdSalim
 */
@Value
@Builder
public class TSDInvalidationRefusedMessage {
  private MessageHeader messageHeader;
  private String crn;
  private String notificationDate;
  private BusinessValidationType businessValidationType;
  private List<Error> error;
  private Party declarant;
  private Representative representative;
  private TemporaryStorageDeclaration declaration;
}
