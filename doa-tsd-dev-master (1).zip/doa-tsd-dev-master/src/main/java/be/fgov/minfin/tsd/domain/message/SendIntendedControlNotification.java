/*
 * @(#) be.fgov.minfin.tsd.domain.message.SendIntendedControlNotification.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.message;

import be.fgov.minfin.tsd.domain.model.ReceiveRiskAnalysisResult;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import lombok.Builder;
import lombok.Value;

@Value
@Builder(toBuilder = true)
public class SendIntendedControlNotification {

  private MessageHeader messageHeader;
  private TemporaryStorageDeclaration declaration;
  private String notificationDate;
  private String scheduledControlDate;
  private Boolean isTransferMessageSender;
  private Boolean isDeconsolidationMessageSender;
  private ReceiveRiskAnalysisResult receiveRiskAnalysisResult;
}
