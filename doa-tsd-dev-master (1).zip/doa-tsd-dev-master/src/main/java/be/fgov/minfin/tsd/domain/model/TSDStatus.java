/*
 * @(#)be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclarationStatus.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model;

import com.fasterxml.jackson.annotation.JsonValue;

public enum TSDStatus {
  DRAFT("00"),
  PRELODGED("01"),
  ACCEPTED("02"),
  INVALIDATED("03"),
  IRREGULARITY_UNDER_INVESTIGATION("06"),
  MEASURES_REQUIRED("09"),
  AMENDMENT_REQUIRED("11"),
  UNDER_CONTROL("08"),
  TEMPORARY_STORAGE_ENDED("10");

  private String value;
  private Integer code;

  TSDStatus(String newValue) {
    value = newValue;
    code = Integer.parseInt(newValue);
  }

  @JsonValue
  public String getValue() {
    return value;
  }

  public Integer getCode() {
    return code;
  }

  public static TSDStatus enumOf(Integer dbData) {
    for (TSDStatus nodeType : TSDStatus.values()) {
      if (nodeType.getCode().equals(dbData)) {
        return nodeType;
      }
    }
    return null;
  }
}
