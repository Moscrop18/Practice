/*
 * @(#) be.fgov.minfin.tsd.domain.repository.CustomTSDRepositoryImpl
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.repository;

import be.fgov.minfin.tsd.domain.model.CRN;
import be.fgov.minfin.tsd.domain.model.MRN;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import java.util.Optional;
import javax.persistence.EntityGraph;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * This class is custom TSD repository to fetch tsd with consignment
 *
 * @author 0345D8744
 */
public class CustomTSDRepositoryImpl implements CustomTSDRepository {
  @Autowired private EntityManager entityManager;
  private static final String GET_TSD_CONSIGNMENT_ENTITY_GRAPH = "get-tsd-Consignment-entity-graph";
  private static final String LOAD_GRAPH = "javax.persistence.loadgraph";

  @Override
  public Optional<TemporaryStorageDeclaration> findDeclarationwithConsignment(CRN crn) {
    try {
      EntityGraph<?> entityGraph = entityManager.getEntityGraph(GET_TSD_CONSIGNMENT_ENTITY_GRAPH);
      TemporaryStorageDeclaration tsd =
          entityManager
              .createQuery(
                  "select tsd from TemporaryStorageDeclaration tsd join ReferenceNumber rn on "
                      + "tsd.id = rn.declaration.id left join fetch tsd.consignmentHeader.decalaredlocationOfGoods dloc left join fetch tsd.consignmentHeader.presentedlocationOfGoods ploc  "
                      + "  where rn.crn=:crn",
                  TemporaryStorageDeclaration.class)
              .setHint(LOAD_GRAPH, entityGraph)
              .setParameter("crn", crn)
              .getSingleResult();
      return Optional.of(tsd);
    } catch (NoResultException e) {
      return Optional.empty();
    }
  }

  @Override
  public Optional<TemporaryStorageDeclaration> findDeclarationwithConsignment(MRN mrn) {
    try {
      EntityGraph<?> entityGraph = entityManager.getEntityGraph(GET_TSD_CONSIGNMENT_ENTITY_GRAPH);
      TemporaryStorageDeclaration tsd =
          entityManager
              .createQuery(
                  "select tsd from TemporaryStorageDeclaration tsd join ReferenceNumber rn on "
                      + "tsd.id = rn.declaration.id left join fetch tsd.consignmentHeader.decalaredlocationOfGoods dloc left join fetch tsd.consignmentHeader.presentedlocationOfGoods ploc  "
                      + "  where rn.mrn=:mrn",
                  TemporaryStorageDeclaration.class)
              .setHint(LOAD_GRAPH, entityGraph)
              .setParameter("mrn", mrn)
              .getSingleResult();
      return Optional.of(tsd);
    } catch (NoResultException e) {
      return Optional.empty();
    }
  }

  @Override
  public Optional<TemporaryStorageDeclaration> findDeclarationwithConsignment(Long tsdId) {
    try {
      EntityGraph<?> entityGraph = entityManager.getEntityGraph(GET_TSD_CONSIGNMENT_ENTITY_GRAPH);
      TemporaryStorageDeclaration tsd =
          entityManager
              .createQuery(
                  "select tsd from TemporaryStorageDeclaration tsd  "
                      + "left join fetch tsd.consignmentHeader.decalaredlocationOfGoods dloc left join fetch tsd.consignmentHeader.presentedlocationOfGoods ploc  "
                      + "  where tsd.id=:id",
                  TemporaryStorageDeclaration.class)
              .setHint(LOAD_GRAPH, entityGraph)
              .setParameter("id", tsdId)
              .getSingleResult();
      return Optional.of(tsd);
    } catch (NoResultException e) {
      return Optional.empty();
    }
  }
}
