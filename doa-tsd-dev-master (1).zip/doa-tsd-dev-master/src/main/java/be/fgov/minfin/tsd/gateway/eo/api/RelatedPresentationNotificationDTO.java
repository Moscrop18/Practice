package be.fgov.minfin.tsd.gateway.eo.api;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonRootName("relatedPN")
@JsonInclude(Include.NON_NULL)
public class RelatedPresentationNotificationDTO {

  private String frn;
  private String dateAndTimeOfPresentationOfTheGoods;
  private CustomsOfficeOfPresentationDTO customsOfficeOfPresentation;
}
