/*
 * @(#) be.fgov.minfin.tsd.domain.model.ConsignmentLocationOfGoods.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties
 * or made public without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model;

import be.fgov.minfin.tsd.domain.model.consignment.LocationOfGoods;
import be.fgov.minfin.tsd.domain.model.consignment.Warehouse;
import be.fgov.minfin.tsd.domain.validation.annotation.CodeList;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import be.fgov.minfin.tsd.domain.validation.annotation.group.TransferNotificationValidatorGroup;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import be.fgov.minfin.tsd.domain.validation.codelist.TSDCodeLists;
import com.fasterxml.jackson.annotation.JsonBackReference;
import javax.persistence.AttributeOverride;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.groups.Default;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.LazyToOne;
import org.hibernate.annotations.LazyToOneOption;

@Getter
@Setter
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@ValidateBusinessRules(groups = {Default.class, TransferNotificationValidatorGroup.class})
@EqualsAndHashCode
@Entity
@Table(name = "CONSIGNMENT_LOCATION_OF_GOODS")
public class ConsignmentLocationOfGoods {

  @Id
  @GeneratedValue(generator = "CONSIGNMENT_LOCATION_OF_GOODS_SEQ")
  @SequenceGenerator(
      name = "CONSIGNMENT_LOCATION_OF_GOODS_SEQ",
      sequenceName = "CONSIGNMENT_LOCATION_OF_GOODS_SEQ")
  private Long id;

  @Valid
  @CodeList(
      value = TSDCodeLists.CL141,
      errorCode = ErrorCode.TSPNESXXC0020,
      groups = {Default.class, TransferNotificationValidatorGroup.class})
  @Embedded
  @AttributeOverride(
      name = "referenceNumber",
      column = @Column(name = "SUPERV_CUSTOMS_OFFICE_REF_NUM"))
  private CustomsOffice supervisingCustomsOffice;

  @Valid
  @ToString.Exclude
  @OneToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "TRANSFERRED_LOC_GOODS_ID")
  private LocationOfGoods transferredLocationOfGoods;

  @Valid @Embedded private Warehouse warehouse;

  @OneToOne(mappedBy = "consignmentLocationOfGoods", fetch = FetchType.LAZY)
  @LazyToOne(value = LazyToOneOption.PROXY)
  @JsonBackReference(value = "transferNotification")
  private TransferNotification transferNotification;
}
