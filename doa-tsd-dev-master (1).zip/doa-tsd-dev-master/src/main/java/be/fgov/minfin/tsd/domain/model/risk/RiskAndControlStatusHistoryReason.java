/*
 * @(#)be.fgov.minfin.tsd.domain.model.risk.RiskAndControlStatusHistoryReason.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model.risk;

import com.fasterxml.jackson.annotation.JsonValue;

public enum RiskAndControlStatusHistoryReason {
  RISK_ANALYSIS_RESULT("01"),
  RISK_ANALYSIS_RESULT_TIMER("02"),
  RISK_ANALYSIS_FALLBACK("03"),
  CONTROL_RESULT("04"),
  CONTROL_RESULT_FALLBACK("05");
  private final Integer value;
  private final String code;

  RiskAndControlStatusHistoryReason(String code) {
    this.value = Integer.parseInt(code);
    this.code = code;
  }

  @JsonValue
  public String getCode() {
    return code;
  }

  public Integer getValue() {
    return value;
  }
}
