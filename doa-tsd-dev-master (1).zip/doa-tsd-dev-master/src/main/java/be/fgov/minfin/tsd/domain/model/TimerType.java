/*
 * @(#)bbe.fgov.minfin.tsd.domain.model.TimerType.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * {@link TimerType.TSD_EXPIRATION} is used when Prelodged TSD is submitted, and usually the Timer
 * Gets Deleted when Prelodged tsd is activated/invalidated.
 *
 * <p>{@link TimerType.TSD_DRAFT_EXPIRATION} is used for automatically deleting the draft TSD if it
 * is not submitted within the stipulated timeframe. It is mainly used from the UI.
 *
 * <p>{@link TimerType.RISK_ANALYSIS_RESULT} is used where the TSD component is waiting for the
 * reception of risk result, else this timer is also deleted automatically.
 *
 * @author MohdSalim
 */
public enum TimerType {
  TSD_EXPIRATION("01"),
  TSD_DRAFT_EXPIRATION("02"),
  RISK_ANALYSIS_RESULT("03");

  private String value;
  private Integer code;

  TimerType(String newValue) {
    value = newValue;
    code = Integer.parseInt(newValue);
  }

  @JsonValue
  public String getValue() {
    return value;
  }

  public Integer getCode() {
    return code;
  }
}
