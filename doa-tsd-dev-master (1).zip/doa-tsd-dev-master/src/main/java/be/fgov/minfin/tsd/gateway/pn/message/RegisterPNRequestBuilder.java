/*
 * @(#) be.fgov.minfin.tsd.gateway.pn.message.RegisterPNRequestBuilder.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.pn.message;

import static be.fgov.minfin.tsd.util.DateFormatUtil.MESSAGE_DATE_TIME_FORMAT;
import static be.fgov.minfin.tsd.util.DateFormatUtil.MESSAGE_TIMESTAMP_FORMAT;

import be.fgov.minfin.libdoa.commons.lang.Now;
import be.fgov.minfin.tsd.config.TSDConfig;
import be.fgov.minfin.tsd.domain.model.MessageInformation;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.consignment.Consignment;
import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentItem;
import be.fgov.minfin.tsd.domain.model.consignment.HouseConsignment;
import be.fgov.minfin.tsd.domain.model.consignment.PreviousDocument;
import be.fgov.minfin.tsd.domain.model.consignment.TransportEquipment;
import be.fgov.minfin.tsd.resource.generator.CorrelationIdGenerator;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

/**
 * This class is to build RegisterPNRequest
 *
 * @author NamrataGupta
 */
@Component
@RequiredArgsConstructor
public class RegisterPNRequestBuilder {

  private final TSDConfig tsdConfig;
  private final CorrelationIdGenerator correlationIdGenerator;

  public RegisterPNRequest buildRegisterPNRequest(TemporaryStorageDeclaration tsd) {
    return RegisterPNRequest.builder()
        .declaration(tsd)
        .messageHeader(buildMessageHeader(tsd.getMessageInformation()))
        .receptionTimestamp(
            DateTimeFormatter.ofPattern(MESSAGE_DATE_TIME_FORMAT)
                .format(Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime()))
        .previousDocument(getPreviousDocument(tsd.getMasterConsignment()))
        .transportEquipmentList(getTransportEquipment(tsd))
        .build();
  }

  private MessageHeader buildMessageHeader(MessageInformation message) {
    return MessageHeader.builder()
        .sender(tsdConfig.getTsdSystemName())
        .correlationId(null != message ? message.getCorrelationID() : null)
        .originalSender(null != message ? message.getSender() : null)
        .recipient(tsdConfig.getPnSystemName())
        .messageTimestamp(
            DateTimeFormatter.ofPattern(MESSAGE_TIMESTAMP_FORMAT)
                .format(Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime()))
        .refToMessageId(null != message ? message.getMessageId() : null)
        .messageId(correlationIdGenerator.generateCorrelationID())
        .languageCode(null != message ? message.getLanguageCode() : null)
        .build();
  }

  private PreviousDocument getPreviousDocument(Consignment consignment) {
    if (null == consignment) return null;
    PreviousDocument previousDocument = null;
    if (null != consignment.getPreviousDocument()) {
      previousDocument = consignment.getPreviousDocument();
    } else if (consignment.getConsignmentItem() != null) {
      Optional<ConsignmentItem> consignmentItem =
          consignment.getConsignmentItem().stream()
              .filter(x -> null != x.getPreviousDocument())
              .findAny();
      if (consignmentItem.isPresent()) {
        previousDocument = consignmentItem.get().getPreviousDocument();
      }
    }
    return previousDocument;
  }

  private List<TransportEquipment> getTransportEquipment(TemporaryStorageDeclaration tsd) {
    List<TransportEquipment> transportEquipmentList = null;
    Optional<HouseConsignment> houseConsignmentWithTransEquipment = Optional.empty();
    if (!CollectionUtils.isEmpty(tsd.getHouseConsignments())) {
      houseConsignmentWithTransEquipment =
          tsd.getHouseConsignments().stream()
              .filter(c -> getTransportEquipmentForConsignment(c) != null)
              .findAny();
    }

    if (houseConsignmentWithTransEquipment.isEmpty()) {
      transportEquipmentList = getTransportEquipmentForConsignment(tsd.getMasterConsignment());
    }
    return transportEquipmentList;
  }

  private List<TransportEquipment> getTransportEquipmentForConsignment(Consignment consignment) {
    if (null == consignment) return Collections.emptyList();
    List<TransportEquipment> transportEquiment = null;
    if (null != consignment.getTransportEquipment()) {
      transportEquiment = consignment.getTransportEquipment();
    } else if (!CollectionUtils.isEmpty(consignment.getConsignmentItem())) {
      Optional<ConsignmentItem> consignmentItem =
          consignment.getConsignmentItem().stream()
              .filter(x -> null != x.getTransportEquipment())
              .findAny();
      if (consignmentItem.isPresent()) {
        transportEquiment = consignmentItem.get().getTransportEquipment();
      }
    }
    return transportEquiment;
  }
}
