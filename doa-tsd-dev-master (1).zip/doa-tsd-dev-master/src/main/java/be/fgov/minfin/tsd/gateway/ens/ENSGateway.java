/*
 * @(#)be.fgov.minfin.tsd.gateway.ens.gateway.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.ens;

import be.fgov.minfin.libdoa.exception.TechnicalException;
import be.fgov.minfin.shared.tracing.Traced;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.gateway.ens.plugin.ENSGatewayPlugin;
import lombok.RequiredArgsConstructor;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;
import wco.datamodel.wco.cis._1.IE4R05Type;

/**
 * @author MohammadFaiz
 */
@Component
@RequiredArgsConstructor
public class ENSGateway {

  private final ENSGatewayPlugin plugin;

  /**
   * @param tsd
   * @return
   */
  @Traced
  @Retryable(
      include = {TechnicalException.class},
      maxAttemptsExpression = "#{${gateway.ens.maxAttempts}}",
      backoff = @Backoff(delayExpression = "#{${gateway.ens.backOffDelay}}"))
  public IE4R05Type getENS(TemporaryStorageDeclaration tsd) {

    return plugin.getENS(tsd);
  }
}
