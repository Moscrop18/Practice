/*
 * @(#)be.fgov.minfin.tsd.domain.model.InvalidationRequest.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model;

import be.fgov.minfin.libdoa.entities.BaseEntity;
import be.fgov.minfin.tsd.domain.converter.InvalidationRequestStatusConverter;
import be.fgov.minfin.tsd.domain.model.party.Party;
import be.fgov.minfin.tsd.domain.model.party.Representative;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import java.time.LocalDateTime;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "INVALIDATION_REQUEST")
@ValidateBusinessRules
public class InvalidationRequest extends BaseEntity<Long> {

  @GeneratedValue(generator = "invalidation_request_seq")
  @SequenceGenerator(name = "invalidation_request_seq", sequenceName = "invalidation_request_seq")
  @Id
  private Long id;

  private String invalidationReason;
  private LocalDateTime registrationDate;

  @Convert(converter = InvalidationRequestStatusConverter.class)
  private InvalidationRequestStatus status;

  @Valid
  @OneToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "DECLARANT_ID")
  @ToString.Exclude
  @JsonManagedReference(value = "invalidationRequest")
  private Party declarant;

  @Valid
  @OneToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "REPRESENTATIVE_ID")
  @ToString.Exclude
  @JsonManagedReference
  private Representative representative;

  @OneToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "MESSAGE_INFORMATION_ID")
  @ToString.Exclude
  @JsonManagedReference
  private MessageInformation messageInformation;

  @OneToMany(
      mappedBy = "invalidationRequest",
      cascade = {CascadeType.PERSIST, CascadeType.MERGE},
      orphanRemoval = true)
  @ToString.Exclude
  @JsonManagedReference(value = "invalidationRequest")
  private List<ValidationError> validationErrors;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "TSD_ID")
  private TemporaryStorageDeclaration declaration;
}
