/*
 * @(#) be.fgov.minfin.tsd.resource.api.ConsignmentHeaderMasterLevelTransferDTO.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties
 * or made public without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.resource.api;

import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.Builder;
import lombok.Value;

@Value
@Builder(toBuilder = true)
@JsonRootName("consignmentHeaderMasterLevel")
public class ConsignmentHeaderMasterLevelTransferDTO {

  @Valid private ConsignmentMasterOrHouseLevelTransferDTO consignmentMasterLevel;

  @JacksonXmlElementWrapper(useWrapping = false)
  @Size(max = 99999)
  private List<@Valid ConsignmentMasterOrHouseLevelTransferDTO> consignmentHouseLevel;

  @NotNull @Valid private LocationOfGoodsDTO locationOfGoods;

  @NotNull @Valid private WarehouseDTO warehouse;
}
