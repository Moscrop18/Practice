package be.fgov.minfin.tsd.gateway.eo.api;

import be.fgov.minfin.tsd.domain.model.TSDStatus;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import java.util.List;
import lombok.Builder;
import lombok.Value;

@Builder
@Value
@JsonPropertyOrder({
  "messageHeader",
  "crn",
  "mrn",
  "notificationDate",
  "status",
  "timerForTemporaryStorage",
  "remarks",
  "activationError",
  "relatedPN",
  "customsOfficeOfPresentation"
})
@JsonInclude(Include.NON_NULL)
@JsonRootName("IETS029")
public class ActivationNotificationDTO {
  private MessageHeaderDTO messageHeader;
  private String crn;
  private String mrn;
  private String notificationDate;
  private TSDStatus status;
  private String timerForTemporaryStorage;
  private String remarks;

  @JacksonXmlElementWrapper(useWrapping = false)
  private List<ActivationErrorDTO> activationError;

  private RelatedPresentationNotificationDTO relatedPN;
}
