/*
 * @(#)be.fgov.minfin.tsd.resource.RiskAnalysisCallbackResource.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.resource;

import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.service.RiskAnalysisService;
import be.fgov.minfin.tsd.resource.api.ReceiveRiskAnalysisResultDTO;
import be.fgov.minfin.tsd.resource.api.ReceiveRiskHitNotificationDTO;
import be.fgov.minfin.tsd.resource.exception.ReceiveRiskExceptionHandling;
import be.fgov.minfin.tsd.resource.mapper.TSDMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
@RequiredArgsConstructor
@ReceiveRiskExceptionHandling
@Path("/riskAnalysisCallback")
@Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
public class RiskAnalysisCallbackResource {

  private final RiskAnalysisService service;
  private final TSDMapper mapper;

  /**
   *
   *
   * <h1>Validates &amp; create {@link TemporaryStorageDeclaration}</h1>
   *
   * <p>Receive a risk hit notification (IETS403) from the risk analysis system which informs the
   * TSD system that a manual risk assessment is ongoing for a specific TSD for which a risk
   * analysis request was submitted. A risk analysis result can be expected once the refinement is
   * completed.
   *
   * @param declarationDTO
   * @param uriInfo
   * @return the response (@link Response.Status.OK) if xsd validation succeeds or (@link
   *     Response.Status.BAD_REQUEST) if xsd validation fails
   */
  @POST
  @Path("/riskHitNotifications")
  @ApiResponse(responseCode = "200", description = "OK")
  @ApiResponse(responseCode = "400", description = "Bad Request")
  @Operation(summary = "Receive risk hit notification IETS403")
  public Response receiveRiskHitNotification(
      @Valid ReceiveRiskHitNotificationDTO riskHitNotificationDTO, @Context UriInfo uriInfo) {

    service.receiveRiskHitNotification(
        riskHitNotificationDTO.getFunctionalReference(),
        riskHitNotificationDTO.getMessageHeader().getMessageId(),
        riskHitNotificationDTO.getRiskAnalysis().getRiskAnalysisRequestReference());
    return Response.ok().build();
  }

  /**
   * Receive a risk analysis result (IETS436) from the risk analysis system which informs the TSD
   * about the results of the risk analysis for a Temporary Storage Declaration.
   *
   * @param receiveRiskAnalysisResultDTO
   * @param uriInfo
   * @returnthe response (@link Response.Status.OK) if xsd validation succeeds or (@link
   *     Response.Status.BAD_REQUEST) if xsd validation fails
   */
  @POST
  @Path("/riskAnalysisResults")
  @ApiResponse(responseCode = "200", description = "OK")
  @ApiResponse(responseCode = "400", description = "Bad Request")
  @Operation(summary = "Receive Risk Analysis Result IETS436")
  public Response receiveRiskAnalysisResult(
      @Valid ReceiveRiskAnalysisResultDTO receiveRiskAnalysisResultDTO, @Context UriInfo uriInfo) {

    service.receiveRiskAnalysisResult(
        receiveRiskAnalysisResultDTO.getFunctionalReference(),
        receiveRiskAnalysisResultDTO.getMessageHeader().getMessageId(),
        mapper.map(receiveRiskAnalysisResultDTO));
    return Response.ok().build();
  }
}
