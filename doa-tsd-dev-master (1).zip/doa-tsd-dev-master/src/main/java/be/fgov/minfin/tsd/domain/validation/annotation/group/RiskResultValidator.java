package be.fgov.minfin.tsd.domain.validation.annotation.group;

public interface RiskResultValidator {}
