package be.fgov.minfin.tsd.domain.repository;

import be.fgov.minfin.tsd.domain.model.Timer;
import be.fgov.minfin.tsd.domain.model.TimerType;
import java.time.LocalDateTime;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

public interface TimerRepository extends JpaRepository<Timer, Long> {

  /**
   * Delete Timer based reference and type
   *
   * @param refrence
   * @param type
   */
  public void deleteByReferenceAndType(String reference, TimerType type);

  /**
   * Returns a Slice<Timer> of expired timers on the requested page
   *
   * @param dateTime
   * @param pageRequest
   * @return Slice<Timer>
   */
  public Slice<Timer> findByExpirationTimestampLessThan(
      LocalDateTime dateTime, Pageable pageRequest);

  @Query(
      value =
          "Update Timer t "
              + "set t.expirationTimestamp = :expirationTimestamp "
              + "where t.reference = :reference")
  @Modifying
  public void updateExpirationTimestamp(String reference, LocalDateTime expirationTimestamp);
}
