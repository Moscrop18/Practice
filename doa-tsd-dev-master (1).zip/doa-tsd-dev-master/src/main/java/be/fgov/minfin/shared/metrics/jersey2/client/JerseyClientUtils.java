/*
 * @(#)be.fgov.minfin.shared.metrics.jersey2.client.JerseyClientMetricsExchangeTagsProvider.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.shared.metrics.jersey2.client;

import be.fgov.minfin.metrics.jersey2.client.DefaultJerseyClientMetricsExchangeTagsProvider;
import be.fgov.minfin.metrics.jersey2.client.JerseyClientInstrumentedFilter;
import com.fasterxml.jackson.jaxrs.json.JacksonJsonProvider;
import com.fasterxml.jackson.jaxrs.xml.JacksonXMLProvider;
import io.micrometer.core.instrument.MeterRegistry;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import lombok.RequiredArgsConstructor;
import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.client.ClientProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.metrics.AutoTimer;
import org.springframework.stereotype.Component;

/**
 * This class is to create Jersey client
 *
 * @author NamrataGupta
 */
@Component
@RequiredArgsConstructor
public class JerseyClientUtils {
  @Autowired private MeterRegistry meterRegistry;
  private static final String METRICS_CLIENT_NAME = "javax_ws_rs_client";

  public WebTarget createClient(String url, Integer connectTimeout, Integer readTimeout) {

    // create client using configuration
    Client client = ClientBuilder.newClient(createDefaultConfig(connectTimeout, readTimeout));

    return client.target(url);
  }

  public ClientConfig createDefaultConfig(Integer connectTimeout, Integer readTimeout) {
    ClientConfig configuration = new ClientConfig();
    configuration.register(JacksonJsonProvider.class);
    configuration.register(JacksonXMLProvider.class);
    configuration.property(ClientProperties.CONNECT_TIMEOUT, connectTimeout);
    configuration.property(ClientProperties.READ_TIMEOUT, readTimeout);
    if (this.meterRegistry != null) {
      configuration.register(
          new JerseyClientInstrumentedFilter(
              METRICS_CLIENT_NAME,
              meterRegistry,
              new DefaultJerseyClientMetricsExchangeTagsProvider(),
              AutoTimer.ENABLED));
    }

    return configuration;
  }
}
