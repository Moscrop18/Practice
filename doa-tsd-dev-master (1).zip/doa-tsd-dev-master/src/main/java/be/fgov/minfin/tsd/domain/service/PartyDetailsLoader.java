/*
 * @(#)be.fgov.minfin.tsd.domain.service.PartyDetailsLoader
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.service;

import be.fgov.minfin.libdoa.commons.lang.Now;
import be.fgov.minfin.shared.tracing.Traced;
import be.fgov.minfin.tsd.domain.model.party.Party;
import be.fgov.minfin.tsd.gateway.crs.CRSGateway;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * This is service class to load party details.
 *
 * @author GauravMitra
 */
@Service
@RequiredArgsConstructor
public class PartyDetailsLoader {
  private final CRSGateway crsGateway;

  /**
   * This method load the party details from CRS
   *
   * @param party
   */
  @Traced
  public void loadPartyDetails(Party party) {
    // TO DO  Throw custom exception from CRS gateway and handle it once final implementation of CRS
    // gateway done.
    crsGateway.getPartyInfo(party);
  }

  @Traced
  public Optional<Party> loadPartyDetails(String identificationNumber) {
    return crsGateway.getPartyInfo(identificationNumber, Now.localDateTime(), false, false);
  }
}
