package be.fgov.minfin.tsd.domain.model;

import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentHeader;
import be.fgov.minfin.tsd.domain.model.consignment.TSDActivationRequestHouseConsignment;
import be.fgov.minfin.tsd.domain.model.consignment.TSDActivationRequestMasterConsignment;
import be.fgov.minfin.tsd.domain.model.party.Party;
import be.fgov.minfin.tsd.domain.model.party.Representative;
import java.time.LocalDateTime;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Model class for activate TSD request
 *
 * @author GauravMitra
 */
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Data
public class TSDActivationRequest {
  private String lrn;

  private String frn;
  private String crn;

  private LocalDateTime receptionTimestamp;

  private LocalDateTime dateAndTimeOfPresentationOfTheGoods;

  private LocalDateTime declarationDate;

  private CustomsOffice customsOfficeOfPresentation;

  private Party declarant;

  private Representative representative;

  private Party personPresentingTheGoods;

  private TSDActivationRequestMasterConsignment masterConsignment;
  private ConsignmentHeader consignmentHeader;
  private List<TSDActivationRequestHouseConsignment> houseConsignments;
  private MessageInformation messageInformation;
}
