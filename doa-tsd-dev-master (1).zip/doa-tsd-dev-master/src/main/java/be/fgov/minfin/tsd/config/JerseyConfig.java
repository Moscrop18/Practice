/*
 * @(#)be.fgov.minfin.tsd.config.JerseyConfig.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.config;

import be.fgov.minfin.libdoa.csrd2.resource.ReferenceDataGatewayJobResource;
import be.fgov.minfin.libdoa.exception.mapper.BusinessExceptionMapper;
import be.fgov.minfin.libdoa.exception.mapper.DefaultProblemMixIn;
import be.fgov.minfin.libdoa.exception.mapper.GenericExceptionMapper;
import be.fgov.minfin.libdoa.exception.mapper.OptimisticLockingFailureExceptionMapper;
import be.fgov.minfin.libdoa.jaxrs.RequireIfMatchInterceptor;
import be.fgov.minfin.libdoa.jaxrs.datetime.LocalDateTimeParamConverterProvider;
import be.fgov.minfin.libdoa.pagination.resource.DateIdCursorParamConvertorProvider;
import be.fgov.minfin.shared.metrics.jersey2.client.JerseyClientUtils;
import be.fgov.minfin.tsd.resource.ControlCallbackResource;
import be.fgov.minfin.tsd.resource.RiskAnalysisCallbackResource;
import be.fgov.minfin.tsd.resource.TSDActivationResource;
import be.fgov.minfin.tsd.resource.TSDB2BResource;
import be.fgov.minfin.tsd.resource.TSDResource;
import be.fgov.minfin.tsd.resource.exception.TSDConstraintViolationExceptionMapper;
import be.fgov.minfin.tsd.resource.exception.TSDJsonMappingExceptionMapper;
import be.fgov.minfin.tsd.resource.exception.TSDJsonParseExceptionMapper;
import be.fgov.minfin.tsd.resource.filter.CorsFilter;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.jaxrs.xml.JacksonXMLProvider;
import io.opentracing.Tracer;
import io.opentracing.contrib.jaxrs2.server.ServerTracingDynamicFeature;
import io.opentracing.contrib.jaxrs2.server.SpanFinishingFilter;
import io.swagger.v3.jaxrs2.integration.resources.OpenApiResource;
import javax.inject.Inject;
import org.glassfish.jersey.linking.DeclarativeLinkingFeature;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.server.ServerProperties;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.zalando.problem.DefaultProblem;
import org.zalando.problem.ProblemModule;
import org.zalando.problem.violations.ConstraintViolationProblemModule;

@Configuration
public class JerseyConfig extends ResourceConfig {
  private static final String SPAN_FINISHING_FILTER = "SpanFinishingFilter";
  private static final String API_URL_IDENTIFIER = "/api/*";

  @Inject
  public JerseyConfig(ObjectMapper objectMapper, Tracer tracer) {
    configureObjectMapper(objectMapper);
    registerEndpoints();
    registerHelperClasses();
    registerExceptionHandlers();
    register(DeclarativeLinkingFeature.class);
    register(new ServerTracingDynamicFeature.Builder(tracer).build()); // jaxrs opentracing
  }

  /**
   * Method to configure object mappers
   *
   * @param objectMapper instance of ObjectMapper required to register modules
   */
  private void configureObjectMapper(ObjectMapper objectMapper) {
    objectMapper.registerModule(new ProblemModule());
    objectMapper.registerModule(new ConstraintViolationProblemModule());
    objectMapper.registerModule(new JavaTimeModule());
    objectMapper.addMixIn(DefaultProblem.class, DefaultProblemMixIn.class);
    objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
    objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, true);
    objectMapper.setSerializationInclusion(Include.NON_NULL);
  }

  private void registerHelperClasses() {
    XmlMapper xmlMapper = new XmlMapper(); // TODO find a way to get this from spring boot
    configureObjectMapper(xmlMapper);
    register(new JacksonXMLProvider(xmlMapper));
    register(LocalDateTimeParamConverterProvider.class);
    register(DateIdCursorParamConvertorProvider.class);
    register(RequireIfMatchInterceptor.class);
    register(CorsFilter.class);
  }

  private void registerEndpoints() {
    register(OpenApiResource.class);
    register(TSDB2BResource.class);
    register(TSDActivationResource.class);
    register(TSDResource.class);
    register(RiskAnalysisCallbackResource.class);
    register(ControlCallbackResource.class);
    register(ReferenceDataGatewayJobResource.class);
  }

  private void registerExceptionHandlers() {
    register(TSDJsonParseExceptionMapper.class);
    register(TSDJsonMappingExceptionMapper.class);
    register(TSDConstraintViolationExceptionMapper.class);
    register(be.fgov.minfin.tsd.resource.exception.BusinessExceptionMapper.class);

    register(OptimisticLockingFailureExceptionMapper.class);
    register(BusinessExceptionMapper.class);
    register(GenericExceptionMapper.class);
    // don't use tomcat error pages
    property(ServerProperties.RESPONSE_SET_STATUS_OVER_SEND_ERROR, true);
  }

  // servlet filter required for jax-rs opentracing
  @Bean
  public FilterRegistrationBean<SpanFinishingFilter> spanFinishingFilter() {
    FilterRegistrationBean<SpanFinishingFilter> registration = new FilterRegistrationBean<>();
    registration.setFilter(new SpanFinishingFilter());
    registration.addUrlPatterns(API_URL_IDENTIFIER);
    registration.setName(SPAN_FINISHING_FILTER);
    registration.setOrder(1);
    return registration;
  }

  @Bean
  public JerseyClientUtils createClient() {
    return new JerseyClientUtils();
  }
}
