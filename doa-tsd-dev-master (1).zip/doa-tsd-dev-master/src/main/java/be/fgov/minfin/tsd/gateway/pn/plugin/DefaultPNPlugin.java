/*
 * @(#) be.fgov.minfin.tsd.gateway.pn.plugin.DefaultPNPlugin
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.pn.plugin;

import static javax.ws.rs.core.Response.Status.BAD_REQUEST;
import static javax.ws.rs.core.Response.Status.CREATED;
import static javax.ws.rs.core.Response.Status.NO_CONTENT;

import be.fgov.minfin.libdoa.exception.TechnicalException;
import be.fgov.minfin.pn.client.PNRestClient;
import be.fgov.minfin.pn.client.api.ActivationResultDTO;
import be.fgov.minfin.pn.client.api.LinkingRequestDTO;
import be.fgov.minfin.pn.client.api.RegistrationApprovedDTO;
import be.fgov.minfin.pn.client.api.RegistrationRequestDTO;
import be.fgov.minfin.tsd.gateway.pn.exception.RegisterPNRejectException;
import be.fgov.minfin.tsd.gateway.pn.message.RegisterPNRequest;
import be.fgov.minfin.tsd.gateway.pn.message.mapper.PNMapper;
import javax.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Component;

/**
 * Default client implementation of Pn Gateway. This class will call PN System and retrieve
 * IETS924DTO with valid frn.
 *
 * @author NamrataGupta
 */
@Component
@Slf4j
@RequiredArgsConstructor
@ConditionalOnExpression(
    "#{T(java.util.Arrays).asList('${gateway.enabledDefaultPlugins}').contains('PN')}")
public class DefaultPNPlugin implements PNGatewayPlugin {

  private static final String AND_RESPONSE_BODY = "and response body ";

  private static final String FAILED_WITH_STATUS_CODE = "failed with status code ";

  private final PNRestClient pnClient;

  private final PNMapper mapper;

  public String registerPN(RegisterPNRequest request) throws RegisterPNRejectException {

    log.info("Inside PNClient message {}", request);

    RegistrationApprovedDTO approvedDto = null;
    RegistrationRequestDTO pnDto = mapper.map(request);

    Response response = pnClient.registerPN(pnDto);

    if (response.getStatus() == CREATED.getStatusCode()) {

      approvedDto = response.readEntity(RegistrationApprovedDTO.class);

      return approvedDto.getFrn();

    } else if (response.getStatus() == BAD_REQUEST.getStatusCode()) {
      throw new RegisterPNRejectException(
          "Register PN Request '"
              + request
              + FAILED_WITH_STATUS_CODE
              + response.getStatus()
              + AND_RESPONSE_BODY
              + response.readEntity(String.class));
    } else {

      throw new TechnicalException(
          "Register PN Request '"
              + request
              + FAILED_WITH_STATUS_CODE
              + response.getStatus()
              + AND_RESPONSE_BODY
              + response.readEntity(String.class));
    }
  }

  @Override
  public void linkPN(LinkingRequestDTO linkRequest) {

    Response response = pnClient.linkPN(linkRequest);

    if (response.getStatus() == NO_CONTENT.getStatusCode()) {
      log.debug(
          "lnking request submitted succesfully pn gateway with frn {}", linkRequest.getFrn());
    } else {

      throw new TechnicalException(
          "linkPN '"
              + linkRequest
              + FAILED_WITH_STATUS_CODE
              + response.getStatus()
              + AND_RESPONSE_BODY
              + response.readEntity(String.class));
    }
  }

  @Override
  public void sendTSDActivationResult(ActivationResultDTO activationRequest) {

    Response response = pnClient.sendTSDActivationResult(activationRequest);

    if (response.getStatus() == NO_CONTENT.getStatusCode()) {
      log.debug(
          "activation request submitted succesfully pn gateway with frn {}",
          activationRequest.getFrn());
    } else {

      throw new TechnicalException(
          "sendTSDActivationResult '"
              + activationRequest
              + FAILED_WITH_STATUS_CODE
              + response.getStatus()
              + AND_RESPONSE_BODY
              + response.readEntity(String.class));
    }
  }
}
