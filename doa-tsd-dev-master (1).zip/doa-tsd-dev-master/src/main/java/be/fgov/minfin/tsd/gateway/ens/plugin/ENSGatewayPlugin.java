/*
 * @(#) be.fgov.minfin.tsd.gateway.pn.plugin.ENSGatewayPlugin
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.ens.plugin;

import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import org.springframework.stereotype.Component;
import wco.datamodel.wco.cis._1.IE4R05Type;

/**
 * @author MohammadFaiz
 */
@Component
public interface ENSGatewayPlugin {
  public IE4R05Type getENS(TemporaryStorageDeclaration tsd);
}
