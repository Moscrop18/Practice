/*
 * @(#)be.fgov.minfin.tsd.domain.model.risk.RiskAndControlStatus.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model.risk;

import com.fasterxml.jackson.annotation.JsonValue;

public enum RiskAndControlStatus {
  AWAITING_RISK_ANALYSIS_RESULT("01"),
  AWAITING_RISK_HIT_CONFIRMATION("02"),
  NO_RISK("03"),
  UNDER_CONTROL("04"),
  CONTROL_RESULT_REGISTERED("05"),
  PRE_ARRIVAL_RISK_ANALYSIS_COMPLETED("06"),
  PRE_ARRIVAL_RISK_ANALYSIS_CANCELLED("07");

  private String value;
  private Integer code;

  RiskAndControlStatus(String newValue) {
    value = newValue;
    code = Integer.parseInt(newValue);
  }

  @JsonValue
  public String getValue() {
    return value;
  }

  public Integer getCode() {
    return code;
  }

  public static RiskAndControlStatus enumOf(Integer dbData) {
    for (RiskAndControlStatus nodeType : RiskAndControlStatus.values()) {
      if (nodeType.getCode().equals(dbData)) {
        return nodeType;
      }
    }
    return null;
  }
}
