/*
 * @(#)be.fgov.minfin.tsd.resource.api.DeclarantDTO.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.resource.api;

import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.Builder;
import lombok.Value;

/** Declarant */
@Value
@Builder(toBuilder = true)
@JsonRootName("declarant")
public class DeclarantDTO {
  @NotNull
  @Size(min = 1, max = 17)
  @Schema(example = "BE0123456789")
  private String identificationNumber;

  @NotNull
  @Size(min = 1, max = 70)
  @Schema(example = "Acme Corporation")
  private String name;

  @JacksonXmlElementWrapper(useWrapping = false)
  @Size(max = 9)
  private List<@Valid CommunicationDTO> communication;
}
