/*
 * @(#) be.fgov.minfin.tsd.domain.model.party.PartyAddress
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model.party;

import be.fgov.minfin.tsd.domain.validation.annotation.CodeList;
import be.fgov.minfin.tsd.domain.validation.annotation.group.DeconsolidationNotificationValidatorGroup;
import be.fgov.minfin.tsd.domain.validation.codelist.TSDCodeLists;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.groups.Default;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Embeddable
public class PartyAddress {

  private String street;

  private String streetAdditionalLine;

  private String number;

  private String poBox;

  private String subDivision;

  private @CodeList(
      value = TSDCodeLists.CL718,
      groups = {Default.class, DeconsolidationNotificationValidatorGroup.class}) String country;

  @Column(name = "POSTCODE")
  private String postCode;

  private String city;
  private String streetAndNumber;
}
