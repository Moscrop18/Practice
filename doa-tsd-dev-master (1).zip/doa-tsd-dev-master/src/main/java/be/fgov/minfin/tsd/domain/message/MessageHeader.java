/*
 * @(#)be.fgov.minfin.tsd.domain.message.MessageHeader.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.message;

import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class MessageHeader {
  private String sender;

  private String recipient;

  private LocalDateTime messageTimestamp;

  private String messageId;

  private String refToMessageId;

  private String correlationId;

  private String languageCode;
}
