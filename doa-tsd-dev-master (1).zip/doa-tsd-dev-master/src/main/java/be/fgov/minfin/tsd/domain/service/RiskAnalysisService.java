/*
 * @(#) be.fgov.minfin.tsd.domain.service.RiskAnalysisService.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.service;

import static be.fgov.minfin.tsd.domain.model.TimerType.RISK_ANALYSIS_RESULT;

import be.fgov.minfin.libdoa.commons.lang.Now;
import be.fgov.minfin.tsd.constant.MessageNameConstant;
import be.fgov.minfin.tsd.domain.model.CRN;
import be.fgov.minfin.tsd.domain.model.DeconsolidationNotification;
import be.fgov.minfin.tsd.domain.model.MessageExchange;
import be.fgov.minfin.tsd.domain.model.MessageInformationSource;
import be.fgov.minfin.tsd.domain.model.ReceiveRiskAnalysisResult;
import be.fgov.minfin.tsd.domain.model.TSDStatus;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.TimerType;
import be.fgov.minfin.tsd.domain.model.consignment.AEOAuthorisation;
import be.fgov.minfin.tsd.domain.model.consignment.Consignment;
import be.fgov.minfin.tsd.domain.model.consignment.HouseConsignment;
import be.fgov.minfin.tsd.domain.model.risk.ControlRecommendation;
import be.fgov.minfin.tsd.domain.model.risk.RiskAnalysisRequest;
import be.fgov.minfin.tsd.domain.model.risk.RiskAnalysisResponse;
import be.fgov.minfin.tsd.domain.model.risk.RiskAnalysisResult;
import be.fgov.minfin.tsd.domain.model.risk.RiskAndControlStatus;
import be.fgov.minfin.tsd.domain.model.risk.RiskAndControlStatusHistoryReason;
import be.fgov.minfin.tsd.domain.repository.AEOAuthorisationRepository;
import be.fgov.minfin.tsd.domain.repository.ConsignmentRepository;
import be.fgov.minfin.tsd.domain.repository.ControlRecommendationRepository;
import be.fgov.minfin.tsd.domain.repository.DeconsolidationNotificationRepository;
import be.fgov.minfin.tsd.domain.repository.MessageExchangeRepository;
import be.fgov.minfin.tsd.domain.repository.RiskAnalysisRequestRepository;
import be.fgov.minfin.tsd.domain.repository.RiskAnalysisResultRepository;
import be.fgov.minfin.tsd.domain.repository.TSDRepository;
import be.fgov.minfin.tsd.domain.sender.TSDResponseSender;
import be.fgov.minfin.tsd.domain.validation.message.MessageType;
import be.fgov.minfin.tsd.domain.validation.plugin.RiskAnalysisValidatorPlugin;
import be.fgov.minfin.tsd.event.TSDEventBroker;
import be.fgov.minfin.tsd.event.api.RiskAnalysisResultReceivedEvent;
import be.fgov.minfin.tsd.event.api.RiskHitNotificationReceivedEvent;
import be.fgov.minfin.tsd.gateway.control.ControlGateway;
import be.fgov.minfin.tsd.gateway.crs.CRSGateway;
import be.fgov.minfin.tsd.util.DateUtil;
import be.fgov.minfin.tsd.util.MessageTemplateUtil;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;
import javax.validation.ConstraintViolation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

/**
 * This is service layer for functionality related to Risk Analysis
 *
 * @author MohdSalim
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class RiskAnalysisService {

  private final TSDEventBroker eventBroker;
  private final TSDService tsdService;
  private final TSDTimerService tsdTimerService;
  private final TSDRepository tsdRepository;
  private final DateUtil dateUtil;

  private final RiskAnalysisValidatorPlugin riskAnalysisValidatorPlugin;

  private final MessageTemplateUtil messageTemplateUtil;
  private final TSDResponseSender tsdResponseSender;

  private final MessageExchangeRepository messageExchangeRepository;
  private final RiskAnalysisRequestRepository riskAnalysisRequestRepository;
  private final RiskAnalysisResultRepository riskAnalysisResultRepository;
  private final ConsignmentRepository consignmentRepository;
  private final ControlRecommendationRepository controlRecommendationRepository;
  private final DeconsolidationNotificationRepository deconsolidationNotificationRepository;
  private final ControlGateway controlGateway;
  private final CRSGateway crsgateway;

  private final AEOAuthorisationRepository aeoAuthorisationRepository;

  public static final String AEOC_CERT = "AEOC";
  public static final String AEOF_CERT = "AEOF";
  public static final String CTR = "CTR";

  public void receiveRiskHitNotification(
      String functionalReference, String messageId, String riskAnalysisRequestReference) {
    log.info(
        "riskHitNotification received in service with functionalReference {}", functionalReference);
    RiskHitNotificationReceivedEvent riskHitNotificationReceivedEvent =
        RiskHitNotificationReceivedEvent.builder()
            .functionalReference(functionalReference)
            .messageId(messageId)
            .riskAnalysisRequestReference(riskAnalysisRequestReference)
            .build();
    eventBroker.publishRiskHitNotificationReceivedEvent(riskHitNotificationReceivedEvent);
  }

  public void processRiskHitNotification(
      String functionalReference, String messageId, String riskAnalysisRequestReference) {
    log.info("processRiskHitNotification with functionalReference {}", functionalReference);
    Optional<TemporaryStorageDeclaration> tsd =
        tsdRepository.findCurrentVersion(CRN.of(functionalReference));
    Optional<RiskAnalysisRequest> latestReference = Optional.empty();
    if (tsd.isPresent()) {
      latestReference =
          riskAnalysisRequestRepository.findFirstByDeclarationOrderByTimestampDesc(tsd.get());
    }
    Set<ConstraintViolation<TemporaryStorageDeclaration>> violations =
        riskAnalysisValidatorPlugin.validateRiskHitNotification(
            tsd, riskAnalysisRequestReference, latestReference);
    if (!violations.isEmpty()) {
      log.error(
          "Invalid Risk hit notification message (IETS403) received with messageId: {},"
              + " following errors were detected: {} ",
          messageId,
          messageTemplateUtil.getAllErrorCodes(violations, false));
    } else processRiskHitNotification(tsd, messageId);
  }

  public void receiveRiskAnalysisResult(
      String functionalReference,
      String messageId,
      ReceiveRiskAnalysisResult receiveRiskAnalysisResult) {
    log.info(
        "receiveRiskAnalysisResult in service with functionalReference {}", functionalReference);
    RiskAnalysisResultReceivedEvent riskAnalysisResultReceivedEvent =
        RiskAnalysisResultReceivedEvent.builder()
            .functionalReference(functionalReference)
            .messageId(messageId)
            .receiveRiskAnalysisResult(receiveRiskAnalysisResult)
            .build();
    eventBroker.publishRiskAnalysisResultReceived(riskAnalysisResultReceivedEvent);
  }

  public void processRiskAnalysisResult(
      String functionalReference,
      String messageId,
      ReceiveRiskAnalysisResult receiveRiskAnalysisResult) {
    log.info("processRiskAnalysisResult with functionalReference {}", functionalReference);
    Optional<TemporaryStorageDeclaration> tsd =
        tsdRepository.findCurrentVersion(CRN.of(functionalReference));
    List<RiskAnalysisRequest> allRiskRequests = new ArrayList<>();
    if (tsd.isPresent()) {
      allRiskRequests =
          riskAnalysisRequestRepository.findByReferenceContaining(functionalReference);
    }
    Set<ConstraintViolation<ReceiveRiskAnalysisResult>> violations =
        riskAnalysisValidatorPlugin.validateRiskAnalysisResult(
            tsd, receiveRiskAnalysisResult, allRiskRequests, MessageType.RISK_ANALYSIS_MESSAGE);
    if (violations.isEmpty() && tsd.isPresent()) {
      registerRiskAnalysisResult(messageId, receiveRiskAnalysisResult, tsd.get());
    } else {
      log.error(
          "Invalid Risk analysis result message (IETS436) received with messageId: {},"
              + " following errors were detected: {} ",
          messageId,
          messageTemplateUtil.getAllErrorCodes(violations, true));
    }
  }

  /**
   * this method is used to register the risk analysis result
   *
   * @param messageId
   * @param receiveRiskAnalysisResult
   * @param tsd
   */
  private void registerRiskAnalysisResult(
      String messageId,
      ReceiveRiskAnalysisResult receiveRiskAnalysisResult,
      TemporaryStorageDeclaration tsd) {

    List<RiskAnalysisRequest> tsdRiskAnalysisRequests =
        riskAnalysisRequestRepository.findByReferenceOrderByTimestamp(
            receiveRiskAnalysisResult.getRiskAnalysisRequestReference());

    if (CollectionUtils.isNotEmpty(tsdRiskAnalysisRequests)) {

      RiskAnalysisResponse riskAnalysisResponse =
          receiveRiskAnalysisResult.getRiskAnalysisResponse();
      List<ControlRecommendation> controlRecommendations =
          receiveRiskAnalysisResult.getControlRecommendations();
      RiskAnalysisRequest tsdRiskAnalysisRequest = tsdRiskAnalysisRequests.get(0);
      saveMessageExchange(tsd, MessageNameConstant.SEND_RISK_ANALYSIS_RESULT, messageId);
      registerRiskAnalysisResult(
          receiveRiskAnalysisResult.getRiskAnalysisResult(), tsdRiskAnalysisRequest);
      tsdRiskAnalysisRequest.updateNotificationAllowed(
          riskAnalysisResponse.getNotificationAllowed());
      tsdRiskAnalysisRequest.updateTimestamp(
          Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime());
      if (tsd.getCurrentStatus().equals(TSDStatus.PRELODGED)) {
        // implementation of US 40.08 AND US 40.07
        processPrelodgedTsd(
            receiveRiskAnalysisResult, tsd, riskAnalysisResponse, tsdRiskAnalysisRequest);
      } else if (CollectionUtils.isNotEmpty(controlRecommendations)) {
        tsdTimerService.stopExpirationTimer(
            tsd.getReferenceNumber().getCrn().getCrnNumber(), RISK_ANALYSIS_RESULT);
        registerControlRecommendation(receiveRiskAnalysisResult, tsd, tsdRiskAnalysisRequest);
        tsdService.registerValidatedRiskAnalysisResult(
            tsd,
            RiskAndControlStatus.UNDER_CONTROL,
            RiskAndControlStatusHistoryReason.RISK_ANALYSIS_RESULT);
        tsdRiskAnalysisRequest.updateIntendedControlNotified(true);

        if (tsd.getCurrentStatus().equals(TSDStatus.ACCEPTED)) {
          tsd.setCurrentStatus(TSDStatus.UNDER_CONTROL);
          tsd.trackHistory(
              null, null, Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime());
        }

        DeconsolidationNotification deconsolidationNotificationHeader =
            getDeconsolidationNotificationHeader(tsd);

        controlGateway.sendControlRecommendationNotification(
            tsd, receiveRiskAnalysisResult, deconsolidationNotificationHeader);
        // implementation of US 40.10
        sendIntendedControlNotification(
            tsd, receiveRiskAnalysisResult, tsdRiskAnalysisRequest, controlRecommendations);

      } else {
        // implementation of 40.09
        tsdTimerService.stopExpirationTimer(
            tsd.getReferenceNumber().getCrn().getCrnNumber(), RISK_ANALYSIS_RESULT);
        tsdService.registerValidatedRiskAnalysisResult(
            tsd,
            RiskAndControlStatus.NO_RISK,
            RiskAndControlStatusHistoryReason.RISK_ANALYSIS_RESULT);
      }
    }
  }

  private void sendIntendedControlNotification(
      TemporaryStorageDeclaration tsd,
      ReceiveRiskAnalysisResult receiveRiskAnalysisResult,
      RiskAnalysisRequest tsdRiskAnalysisRequest,
      List<ControlRecommendation> controlRecommendations) {
    if (tsd.getMessageInformation().getSource() == MessageInformationSource.B2B) {
      if (null != tsd.getTransferNotification()) {
        if (isControlRecommLinkedWithTransferConsignment(tsd, controlRecommendations)) {
          if (!tsd.getMessageInformation()
              .getSender()
              .equals(tsd.getTransferNotification().getMessageInformation().getSender())) {
            tsdResponseSender.sendAEOIntendedControlNotification(
                tsd, receiveRiskAnalysisResult, false, false); // --TSD mesg sender
            tsdResponseSender.sendAEOIntendedControlNotification(
                tsd, receiveRiskAnalysisResult, true, false); // --TSD transfer mesg sender
          } else {
            tsdResponseSender.sendAEOIntendedControlNotification(
                tsd, receiveRiskAnalysisResult, false, false); // --TSD msg sender
          }
        } else {
          tsdResponseSender.sendAEOIntendedControlNotification(
              tsd, receiveRiskAnalysisResult, false, false); // --TSD msg sender
        }
      } else if (null != tsd.getDeconsolidationNotification()) {
        sendIntendedControlNotificationForDeconsolidation(
            tsd, receiveRiskAnalysisResult, tsdRiskAnalysisRequest);
      } else {
        tsdResponseSender.sendAEOIntendedControlNotification(
            tsd, receiveRiskAnalysisResult, false, false); // --TSD msg sender
      }
    }
    if (tsd.getMessageInformation().getSource() == MessageInformationSource.UI) {
      sendIntendedControllNotificationForUI(
          tsd, controlRecommendations, receiveRiskAnalysisResult, tsdRiskAnalysisRequest);
    }
  }

  private void sendIntendedControllNotificationForUI(
      TemporaryStorageDeclaration tsd,
      List<ControlRecommendation> controlRecommendations,
      ReceiveRiskAnalysisResult receiveRiskAnalysisResult,
      RiskAnalysisRequest tsdRiskAnalysisRequest) {
    if (isControlRecommLinkedWithTransferConsignment(tsd, controlRecommendations)
        && null != tsd.getTransferNotification()) {
      tsdResponseSender.sendAEOIntendedControlNotification(
          tsd, receiveRiskAnalysisResult, true, false); // --TSD transfer notif sender
    }
    if (null != tsd.getDeconsolidationNotification()) {
      tsdResponseSender.sendAEOIntendedControlNotification(
          tsd, receiveRiskAnalysisResult, false, true); // deconsolidation msg sender
    }
    tsdRiskAnalysisRequest.updateIntendedControlNotified(false);
  }

  private void sendIntendedControlNotificationForDeconsolidation(
      TemporaryStorageDeclaration tsd,
      ReceiveRiskAnalysisResult receiveRiskAnalysisResult,
      RiskAnalysisRequest tsdRiskAnalysisRequest) {
    if (!tsd.getMessageInformation()
        .getSender()
        .equals(tsd.getDeconsolidationNotification().getMessageInformation().getSender())) {
      tsdResponseSender.sendAEOIntendedControlNotification(
          tsd, receiveRiskAnalysisResult, false, false); // TSD msg sender
      tsdResponseSender.sendAEOIntendedControlNotification(
          tsd, receiveRiskAnalysisResult, false, true); // deconsolidation msg sender
    } else {
      tsdResponseSender.sendAEOIntendedControlNotification(
          tsd, receiveRiskAnalysisResult, false, false); // TSD msg sender
    }
    tsdRiskAnalysisRequest.updateIntendedControlNotified(true);
  }

  private boolean isControlRecommLinkedWithTransferConsignment(
      TemporaryStorageDeclaration tsd, List<ControlRecommendation> controlRecommendations) {

    List<Consignment> allControlConsignments =
        controlRecommendations.stream()
            .filter(cr -> CollectionUtils.isNotEmpty(cr.getConsignments()))
            .flatMap(cr -> Stream.of(cr.getConsignments()))
            .filter(Objects::nonNull)
            .flatMap(Collection::stream)
            .distinct()
            .toList();

    if (tsd.getTransferNotification() == null) {
      return false;
    }
    return allControlConsignments.stream()
        .anyMatch(
            x ->
                Objects.equals(
                    x.getCurrentConsignmentLocationOfGoods(),
                    tsd.getTransferNotification().getConsignmentLocationOfGoods()));
  }

  /**
   * this method is used for process risk analysis result with prelodged tsd
   *
   * @param receiveRiskAnalysisResult
   * @param tsd
   * @param riskAnalysisResponse
   * @param riskAnalysisRequest
   */
  private void processPrelodgedTsd(
      ReceiveRiskAnalysisResult receiveRiskAnalysisResult,
      TemporaryStorageDeclaration tsd,
      RiskAnalysisResponse riskAnalysisResponse,
      RiskAnalysisRequest tsdRiskAnalysisRequest) {

    tsdService.registerValidatedRiskAnalysisResult(
        tsd, RiskAndControlStatus.PRE_ARRIVAL_RISK_ANALYSIS_COMPLETED, null);
    if (!CollectionUtils.isEmpty(receiveRiskAnalysisResult.getControlRecommendations())) {
      registerControlRecommendation(receiveRiskAnalysisResult, tsd, tsdRiskAnalysisRequest);
      if (Boolean.TRUE.equals(riskAnalysisResponse.getNotificationAllowed())) {
        List<AEOAuthorisation> aeoAuthorisations =
            crsgateway.getAEOCertificate(
                tsd.getDeclarant().getIdentificationNumber(), Now.localDateTime());
        aeoAuthorisations =
            aeoAuthorisations != null
                ? aeoAuthorisations.stream()
                    .filter(aeo -> isInFutureOrEmpty(aeo.getEndDate()))
                    .toList()
                : List.of();
        if (!aeoAuthorisations.isEmpty()) {
          // implement US06.08 Send intended control notification,
          // IETS460
          if (tsd.getMessageInformation().getSource() == MessageInformationSource.B2B)
            tsdResponseSender.sendAEOIntendedControlNotification(
                tsd, receiveRiskAnalysisResult, false, false);

          aeoAuthorisations.forEach(aeo -> aeo.setParty(tsd.getDeclarant()));
          aeoAuthorisationRepository.saveAll(aeoAuthorisations);
          tsdRiskAnalysisRequest.updateIntendedControlNotified(true);
        } else {
          tsdRiskAnalysisRequest.updateIntendedControlNotified(false);
        }
      } else {
        tsdRiskAnalysisRequest.updateIntendedControlNotified(false);
      }
    }
  }

  /**
   * this method used to persist data into ControlRecommendation table by generating unique
   * functional reference and mapping with respective consignments
   *
   * @param receiveRiskAnalysisResult
   * @param tsd
   * @param riskAnalysisRequest
   */
  private void registerControlRecommendation(
      ReceiveRiskAnalysisResult receiveRiskAnalysisResult,
      TemporaryStorageDeclaration tsd,
      RiskAnalysisRequest tsdRiskAnalysisRequest) {
    List<ControlRecommendation> controlRecommendationList =
        receiveRiskAnalysisResult.getControlRecommendations();
    AtomicInteger counter = new AtomicInteger(1);
    for (ControlRecommendation controlRecommendation : controlRecommendationList) {
      DecimalFormat decimalFormat = new DecimalFormat("00000");
      String functionalReference =
          receiveRiskAnalysisResult.getRiskAnalysisRequestReference()
              + CTR
              + decimalFormat.format(counter.getAndIncrement());
      controlRecommendation.setFunctionalReference(functionalReference);
      controlRecommendation.setRiskAnalysisRequest(tsdRiskAnalysisRequest);
      linkConsignments(controlRecommendation, tsd);
    }
    controlRecommendationRepository.saveAll(controlRecommendationList);
    counter.set(1);
  }

  /**
   * this method is used to map control recommendation with respective consignments
   *
   * @param controlRecommendation
   * @param tsd
   */
  private void linkConsignments(
      ControlRecommendation controlRecommendation, TemporaryStorageDeclaration tsd) {
    if (!CollectionUtils.isEmpty(controlRecommendation.getConsignments())) {
      List<Consignment> consignments = new ArrayList<>();
      for (Consignment consignment : controlRecommendation.getConsignments()) {
        HouseConsignment houseConsignment =
            consignment instanceof HouseConsignment ? (HouseConsignment) consignment : null;
        if (houseConsignment != null) {
          Consignment dbonsignment =
              consignmentRepository.findByTransportDocumentAndType(
                  houseConsignment.getTransportDocument().getReferenceNumber(),
                  houseConsignment.getTransportDocument().getType(),
                  tsd.getId());
          if (dbonsignment != null) {
            consignments.add(dbonsignment);
          }
        }
      }
      controlRecommendation.setConsignments(
          CollectionUtils.isEmpty(consignments)
              ? List.of(tsd.getMasterConsignment())
              : consignments);
    }
  }

  /**
   * this method is used to persist data into RiskAnalysisResult table
   *
   * @param riskAnalysisResponse
   * @param riskAnalysisRequest
   */
  private void registerRiskAnalysisResult(
      List<RiskAnalysisResult> riskResults, RiskAnalysisRequest riskAnalysisRequest) {
    riskResults.stream().forEach(result -> result.setRiskAnalysisRequest(riskAnalysisRequest));
    riskAnalysisResultRepository.saveAll(riskResults);
  }

  private boolean isInFutureOrEmpty(LocalDateTime endDate) {
    if (null == endDate) return true;
    return endDate.isAfter(LocalDateTime.now());
  }

  public void processRiskHitNotification(
      Optional<TemporaryStorageDeclaration> declaration, String messageId) {
    if (declaration.isPresent()) acceptRiskHitNotification(declaration.get(), messageId);
  }

  public void acceptRiskHitNotification(TemporaryStorageDeclaration tsd, String messageId) {
    tsd.setCurrentRiskControlStatus(RiskAndControlStatus.AWAITING_RISK_HIT_CONFIRMATION);
    tsd.trackRiskAndControlStatusHistory(
        null, Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime());
    if (tsd.getCurrentStatus() != TSDStatus.PRELODGED) {
      // remove timer
      tsdRepository.deleteTimerLinkedToTsd(
          tsd.getReferenceNumber().getCrn().getCrnNumber(), TimerType.RISK_ANALYSIS_RESULT);
    }
    tsd = tsdRepository.save(tsd);
    saveMessageExchange(tsd, MessageNameConstant.RECEIVE_RISK_HIT_NOTIFICATION, messageId);
  }

  private void saveMessageExchange(
      TemporaryStorageDeclaration declaration, String type, String messageId) {
    MessageExchange messageExchange =
        MessageExchange.builder()
            .messageId(messageId)
            .messageTimestamp(dateUtil.getCurentSystemDate())
            .messageType(type)
            .declaration(declaration)
            .build();
    messageExchangeRepository.save(messageExchange);
  }

  private DeconsolidationNotification getDeconsolidationNotificationHeader(
      TemporaryStorageDeclaration tsd) {
    DeconsolidationNotification deconsolidationNotificationHeader = null;
    if (null == tsd.getDeconsolidationNotification()) {
      if (null != tsd.getReferenceNumber().getDeconsolidatedTSDId()) {

        Optional<DeconsolidationNotification> optDecon =
            deconsolidationNotificationRepository.fetchDeconsolidationNotification(
                tsd.getReferenceNumber().getDeconsolidatedTSDId());
        if (optDecon.isPresent()) {
          deconsolidationNotificationHeader = optDecon.get();
        }
      }
    } else {
      deconsolidationNotificationHeader = tsd.getDeconsolidationNotification();
    }

    return deconsolidationNotificationHeader;
  }
}
