/*
 * @(#) be.fgov.minfin.tsd.resource.TSDResource.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.resource;

import static be.fgov.minfin.libdoa.jaxrs.EtagUtils.eTag;
import static be.fgov.minfin.libdoa.jaxrs.LocationUtil.getLocation;
import static be.fgov.minfin.tsd.domain.model.TSDStatus.DRAFT;
import static org.apache.commons.collections4.CollectionUtils.isEmpty;
import static org.apache.commons.lang3.StringUtils.isNumeric;

import be.fgov.minfin.libdoa.commons.lang.Now;
import be.fgov.minfin.libdoa.jaxrs.RequireIfMatch;
import be.fgov.minfin.libdoa.pagination.resource.pagination.SliceDTO;
import be.fgov.minfin.tsd.domain.model.InvalidationRequest;
import be.fgov.minfin.tsd.domain.model.StatusHistory;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclarationFilter;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclarationProjection;
import be.fgov.minfin.tsd.domain.service.AmendmentService;
import be.fgov.minfin.tsd.domain.service.DeatachDeclarationService;
import be.fgov.minfin.tsd.domain.service.InvalidationService;
import be.fgov.minfin.tsd.domain.service.TSDService;
import be.fgov.minfin.tsd.domain.service.TSDTimerService;
import be.fgov.minfin.tsd.resource.api.ui.InvalidationRequestDTO;
import be.fgov.minfin.tsd.resource.api.ui.RiskAnalysisRequestResponseDTO;
import be.fgov.minfin.tsd.resource.api.ui.RiskAndControlStatusHistoryResponseDTO;
import be.fgov.minfin.tsd.resource.api.ui.StatusHistoryResponse;
import be.fgov.minfin.tsd.resource.api.ui.TemporaryStorageDeclarationDTO;
import be.fgov.minfin.tsd.resource.api.ui.TemporaryStorageDeclarationFilterDTO;
import be.fgov.minfin.tsd.resource.api.ui.TemporaryStorageDeclarationProjectionDTO;
import be.fgov.minfin.tsd.resource.api.ui.TemporaryStorageDeclarationVersionSearchResponseDTO;
import be.fgov.minfin.tsd.resource.exception.UIExceptionHandling;
import be.fgov.minfin.tsd.resource.mapper.TSDMapper;
import be.fgov.minfin.tsd.resource.validation.SubmitUIOnly;
import be.fgov.minfin.tsd.shared.swagger.ApiResponseCreate;
import be.fgov.minfin.tsd.shared.swagger.ApiResponseDefaultErrors;
import be.fgov.minfin.tsd.shared.swagger.ApiResponseDelete;
import be.fgov.minfin.tsd.shared.swagger.ApiResponseGet;
import be.fgov.minfin.tsd.shared.swagger.ApiResponseModify;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Valid;
import javax.validation.groups.ConvertGroup;
import javax.validation.groups.Default;
import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.UriInfo;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Slice;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 *
 * <h1>Resource for UI/Internal communications</h1>
 *
 * <h3>Invalidation of expired PRELODGED TSD</h3>
 *
 * Exposes API for kubernetes JOB.
 *
 * <p>A kubernetes JOB uses this rest end point for invalidating expired PRELODGED TSD and for
 * deleting expired timers irrespective of tsd status.
 *
 * <p>This REST resource is a Jersey implementation which produces and consumes {@link
 * MediaType#APPLICATION_JSON application/json} &amp; {@link MediaType#APPLICATION_XHTML_XML
 * application/xml} both.
 *
 * <p>Responsibilities of a Resource
 *
 * <ul>
 *   <li>Exposing REST API
 *   <li>Authorization of operations
 *   <li>Mapping of XML/JSON &lt;-&gt; {@link }
 *   <li>validating input on PresentationNotificationDTO
 *       <ul>
 *         <li>using constraints
 *         <li>using business validators
 *       </ul>
 *   <li>Mapping of {@link } &lt;-&gt; {@link TemporaryStorageDeclaration} Domain object
 *   <li>process of referenced domain object
 * </ul>
 *
 * @author MohdSalim
 * @version 1.0
 */
@Component
@Path("/temporaryStorageDeclarations")
@Produces({MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_JSON})
@RequiredArgsConstructor
@Transactional
@Slf4j
@UIExceptionHandling
public class TSDResource {

  private final TSDTimerService timerService;
  private final TSDMapper mapper;
  private final TSDService tsdService;
  private final ConsignmentResource consignmentResource;
  private final InvalidationService invalidationService;
  private final DeatachDeclarationService deatachService;
  private final AmendmentService amendmentServivce;

  /**
   * @return the response having acknowledgement message with (@link Response.Status.Accepted)
   */
  @GET
  @ApiResponse(responseCode = "202", description = "Accepted")
  @Path("/checkExpirations")
  @Operation(summary = "invalidate expired PRELODGED TSD")
  @Transactional(propagation = Propagation.NOT_SUPPORTED)
  public Response checkExpirationTiumers() {
    log.debug(
        "timer expiration cron job started at: {}",
        Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime());
    timerService.checkTimers();
    tsdService.updateExpirationTimestampForDraftTSD();
    return Response.accepted().build();
  }

  @POST
  @ApiResponseCreate
  @ApiResponseDefaultErrors
  public Response createDeclaration(
      @Valid @ConvertGroup(from = Default.class, to = SubmitUIOnly.class)
          TemporaryStorageDeclarationDTO declarationDTO,
      @Context UriInfo uriInfo) {

    TemporaryStorageDeclaration createdDeclaration =
        tsdService.createDeclaration(mapper.map(declarationDTO));
    Long id = createdDeclaration.getId();
    return Response.created(getLocation(uriInfo, id)).build();
  }

  @POST
  @Path("{tsdId}/validate")
  @ApiResponse(responseCode = "200", description = "Ok")
  @ApiResponse(responseCode = "400", description = "Bad Request")
  @ApiResponse(responseCode = "404", description = "Not Found")
  @ApiResponseDefaultErrors
  public Response validateDeclaration(
      @PathParam("tsdId") String tsdId, final @Context Request req) {
    TemporaryStorageDeclaration tsd =
        tsdService.getDeclarationWithConsignments(tsdId).orElseThrow(NotFoundException::new);
    if (tsd.getCurrentStatus() != DRAFT) {
      throw new NotFoundException();
    }
    tsdService.validateAndPrefillDeclaration(tsd);
    deatachService.clearAllManagedEntity();
    return Response.ok().build();
  }

  @POST
  @Path("{tsdId}/submit")
  @ApiResponse(responseCode = "200", description = "Ok")
  @ApiResponse(responseCode = "400", description = "Bad Request")
  @ApiResponse(responseCode = "404", description = "Not Found")
  @ApiResponseDefaultErrors
  public Response submitDeclaration(@PathParam("tsdId") String tsdId, final @Context Request req) {
    TemporaryStorageDeclaration tsd =
        tsdService.getDeclarationWithConsignments(tsdId).orElseThrow(NotFoundException::new);
    if (tsd.getCurrentStatus() != DRAFT) {
      throw new NotFoundException();
    }
    tsdService.sumbitDraftDeclaration(tsd);
    return Response.ok().build();
  }

  @POST
  @Path("{tsdId}/amend")
  @ApiResponse(responseCode = "200", description = "Ok")
  @ApiResponse(responseCode = "400", description = "Bad Request")
  @ApiResponse(responseCode = "404", description = "Not Found")
  @ApiResponseDefaultErrors
  public Response createDraftAmendment(
      @PathParam("tsdId") String tsdId, final @Context Request req, @Context UriInfo uriInfo) {
    if (isNumeric(tsdId)) {
      throw new NotFoundException();
    }
    TemporaryStorageDeclaration tsd =
        tsdService.getDeclarationWithConsignments(tsdId).orElseThrow(NotFoundException::new);

    TemporaryStorageDeclaration draftDeclaration = amendmentServivce.createAmendment(tsd);
    Long id = draftDeclaration.getId();
    return Response.created(getLocation(uriInfo, id)).build();
  }

  @PUT
  @Path("{tsdId}")
  @ApiResponseModify
  @RequireIfMatch
  public Response updateDeclaration(
      @PathParam("tsdId") String tsdID,
      @Valid TemporaryStorageDeclarationDTO declarationDTO,
      @Context Request req) {
    TemporaryStorageDeclaration tsd =
        tsdService.getDeclaration(tsdID).orElseThrow(NotFoundException::new);
    Integer recordVersion = tsd.getVersion();
    // check if-match header
    ResponseBuilder response = req.evaluatePreconditions(eTag(tsd));
    if (response != null) {
      return response.build();
    }

    // map all fields which are not read only.
    mapper.mapIgnoreReadOnly(declarationDTO, tsd);
    mapper.setBackReference(tsd, declarationDTO);

    TemporaryStorageDeclaration updatedDeclaration = tsdService.modifyDeclaration(tsd);
    if (!recordVersion.equals(updatedDeclaration.getVersion())) {

      return Response.ok().tag(eTag(updatedDeclaration)).build();
    }
    return Response.ok().build();
  }

  @GET
  @Path("{tsdId}/statusHistory")
  @ApiResponse(
      responseCode = "200",
      description = "Ok",
      content = @Content(schema = @Schema(implementation = StatusHistoryResponse.class)))
  @ApiResponseGet
  public Response findStatusHistory(@PathParam("tsdId") String id, final @Context Request req) {
    TemporaryStorageDeclaration tsd =
        tsdService.getDeclaration(id).orElseThrow(NotFoundException::new);
    List<StatusHistory> history = tsd.getReferenceNumber().getOrderedStatusHistory();
    return Response.ok(mapper.mapStatusHistory(tsd, history)).build();
  }

  @GET
  @Path("{tsdId}/riskAndControlStatusHistory")
  @ApiResponse(
      responseCode = "200",
      description = "Ok",
      content =
          @Content(schema = @Schema(implementation = RiskAndControlStatusHistoryResponseDTO.class)))
  @ApiResponse(responseCode = "404", description = "Not Found")
  @ApiResponseDefaultErrors
  public Response findRiskAndControlStatusHistory(
      @PathParam("tsdId") String tsdId, final @Context Request req) {
    TemporaryStorageDeclaration tsd =
        tsdService.getDeclaration(tsdId).orElseThrow(NotFoundException::new);
    return Response.ok(mapper.mapRacHistory(tsd)).build();
  }

  @POST
  @Path("{crn}/invalidate")
  @ApiResponse(responseCode = "200", description = "Ok")
  @ApiResponse(responseCode = "400", description = "Bad Request")
  @ApiResponse(responseCode = "404", description = "Not Found")
  @ApiResponseDefaultErrors
  public Response invalidateDeclaration(
      @PathParam("crn") String crn,
      @Valid InvalidationRequestDTO invalidationDTO,
      final @Context Request req) {
    TemporaryStorageDeclaration tsd =
        tsdService.getDeclaration(crn).orElseThrow(NotFoundException::new);
    InvalidationRequest invalidationRequest = mapper.map(invalidationDTO);
    Set<ConstraintViolation<InvalidationRequest>> violations =
        invalidationService.invalidateDelarationUI(invalidationRequest, tsd);
    if (!violations.isEmpty()) {
      throw new ConstraintViolationException(violations);
    }

    return Response.ok().build();
  }

  @GET
  @Path("{tsdId}")
  @ApiResponse(
      responseCode = "200",
      description = "Ok",
      content = @Content(schema = @Schema(implementation = TemporaryStorageDeclarationDTO.class)))
  @ApiResponseGet
  public Response getDeclaration(@PathParam("tsdId") String id, final @Context Request req) {
    Long draftAmendmentId = null;
    boolean currentTSDTransferred = false;
    TemporaryStorageDeclaration tsd =
        tsdService.getDeclarationWithUIAttributes(id).orElseThrow(NotFoundException::new);
    if (null != tsd.getReferenceNumber()) {
      if (null != tsd.getReferenceNumber().getCrn()) {
        Optional<Long> optionalId =
            tsdService.getDraftAmendmentId(tsd.getReferenceNumber().getCrn());
        if (optionalId.isPresent()) {
          draftAmendmentId = optionalId.get();
        }
      }

      currentTSDTransferred =
          tsdService.checkIfCurrentTSDisTransferred(tsd.getReferenceNumber().getId());
    }

    return Response.ok(mapper.map(tsd, draftAmendmentId, currentTSDTransferred))
        .tag(eTag(tsd))
        .build();
  }

  @GET
  @Path("{tsdId}/versions")
  @ApiResponse(
      responseCode = "200",
      description = "Ok",
      content =
          @Content(
              schema =
                  @Schema(
                      implementation = TemporaryStorageDeclarationVersionSearchResponseDTO.class)))
  @ApiResponseGet
  public Response findDeclarationVersions(
      @PathParam("tsdId") String tsdSearchParam, final @Context Request req) {
    List<TemporaryStorageDeclaration> tsdlist = tsdService.findDeclarationVersions(tsdSearchParam);

    if (isEmpty(tsdlist)) {
      throw new NotFoundException();
    }
    return Response.ok(mapper.mapToDto(tsdlist)).build();
  }

  // sub resource!
  @Path("{tsdId}/consignments")
  @Hidden // need to hide nested resources from swagger
  public ConsignmentResource getConsignmentResource() {
    return consignmentResource;
  }

  @DELETE
  @Path("{tsdId}")
  @ApiResponseDelete
  public Response removeDeclaration(@PathParam("tsdId") String tsdId) {
    TemporaryStorageDeclaration tsd =
        tsdService.getDeclaration(tsdId).orElseThrow(NotFoundException::new);
    tsd.checkCanDelete();
    tsdService.removeDeclaration(tsd);

    return Response.ok().build();
  }

  @GET
  @Operation(
      description = "Returns a cursor based list of TSDs. Only the summary info is returned.")
  @ApiResponse(
      responseCode = "200",
      description = "Ok",
      content =
          @Content(
              schema =
                  @Schema(implementation = TemporaryStorageDeclarationProjectionDTO.Page.class)))
  public TemporaryStorageDeclarationProjectionDTO.Page findDeclarations(
      @Valid @BeanParam TemporaryStorageDeclarationFilterDTO declarationFilter,
      @Context UriInfo uriInfo) {

    log.info("filter {}", declarationFilter);
    TemporaryStorageDeclarationFilter filter = mapper.map(declarationFilter);
    log.info("filter {}", filter);

    Slice<TemporaryStorageDeclarationProjection> page =
        tsdService.findTemporaryStorageDeclarationProjections(
            filter, declarationFilter.getPageable());
    return SliceDTO.of(
        page.map(mapper::map), uriInfo, TemporaryStorageDeclarationProjectionDTO.Page.class);
  }

  @GET
  @Path("{tsdId}/riskAnalysisRequests")
  @Operation(
      description =
          "Return risk analysis request and related information for Temporary Storage Declaration. "
              + "The available Risk Analysis Request, Risk Analysis Results, Control Recommendations and "
              + "Control Results are returned")
  @ApiResponse(
      responseCode = "200",
      description = "Ok",
      content = @Content(schema = @Schema(implementation = RiskAnalysisRequestResponseDTO.class)))
  @ApiResponseGet
  public Response getRiskAnalysisRequests(
      @PathParam("tsdId") String tsdId, final @Context Request request) {

    TemporaryStorageDeclaration tsd =
        tsdService.getDeclaration(tsdId).orElseThrow(NotFoundException::new);

    return Response.ok(mapper.map(tsd.getCurrentRiskControlStatus(), tsd.getRiskAnalysisRequest()))
        .build();
  }
}
