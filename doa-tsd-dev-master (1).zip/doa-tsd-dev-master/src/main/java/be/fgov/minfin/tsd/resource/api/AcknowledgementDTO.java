/*
 * @(#)be.fgov.minfin.tsd.resource.api.AcknowledgementDTO.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */

package be.fgov.minfin.tsd.resource.api;

import com.fasterxml.jackson.annotation.JsonRootName;
import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Value;

/**
 * @author GauravMitra
 */
@Value
@Builder(toBuilder = true)
@JsonRootName("IETS928")
public class AcknowledgementDTO {
  @Schema(example = "00783eca-a434-11ea-bb37-0242ac130002")
  @NotNull
  private String correlationId;
}
