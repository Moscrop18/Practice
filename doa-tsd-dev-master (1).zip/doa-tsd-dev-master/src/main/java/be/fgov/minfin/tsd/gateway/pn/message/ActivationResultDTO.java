/*
 * @(#) be.fgov.minfin.tsd.gateway.pn.message.IETS024Request
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.pn.message;

import be.fgov.minfin.libdoa.amqp.BaseEvent;
import be.fgov.minfin.pn.client.api.LinkingStatus;
import be.fgov.minfin.pn.client.api.MessageHeaderDTO;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import java.util.List;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

/**
 * This class is request for PN client to send the activation result message
 *
 * @author NamrataGupta
 */
@Getter
@Setter
@JsonPropertyOrder({"messageHeader", "frn", "linkingStatus", "relatedTSD", "mrn", "linkingError"})
@JsonInclude(Include.NON_NULL)
@JsonRootName("IETS024")
@Builder
public class ActivationResultDTO extends BaseEvent {
  private MessageHeaderDTO messageHeader;
  private String frn;
  private LinkingStatus linkingStatus;
  private RelatedTSDDTO relatedTSD;

  @JacksonXmlElementWrapper(useWrapping = false)
  private List<ErrorDTO> linkingError;
}
