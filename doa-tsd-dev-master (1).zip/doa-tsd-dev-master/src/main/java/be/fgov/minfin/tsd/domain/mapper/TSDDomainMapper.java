/*
 * @(#) be.fgov.minfin.tsd.domain.mapper.TSDDomainMapper.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.mapper;

import be.fgov.minfin.tsd.domain.model.ConsignmentInformationType;
import be.fgov.minfin.tsd.domain.model.MessageInformation;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.consignment.AEOAuthorisation;
import be.fgov.minfin.tsd.domain.model.consignment.AdditionalInformation;
import be.fgov.minfin.tsd.domain.model.consignment.AdditionalReference;
import be.fgov.minfin.tsd.domain.model.consignment.AdditionalSupplyChainActor;
import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentHeader;
import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentItem;
import be.fgov.minfin.tsd.domain.model.consignment.HouseConsignment;
import be.fgov.minfin.tsd.domain.model.consignment.LocationOfGoods;
import be.fgov.minfin.tsd.domain.model.consignment.MasterConsignment;
import be.fgov.minfin.tsd.domain.model.consignment.Packaging;
import be.fgov.minfin.tsd.domain.model.consignment.PreviousDocument;
import be.fgov.minfin.tsd.domain.model.consignment.Receptacle;
import be.fgov.minfin.tsd.domain.model.consignment.Seal;
import be.fgov.minfin.tsd.domain.model.consignment.SupportingDocument;
import be.fgov.minfin.tsd.domain.model.consignment.TransportDocument;
import be.fgov.minfin.tsd.domain.model.consignment.TransportEquipment;
import be.fgov.minfin.tsd.domain.model.party.Communication;
import be.fgov.minfin.tsd.domain.model.party.Party;
import be.fgov.minfin.tsd.domain.model.party.Person;
import be.fgov.minfin.tsd.domain.model.party.Representative;
import java.util.List;
import java.util.stream.Collectors;
import org.apache.commons.collections4.CollectionUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.control.DeepClone;

/**
 * This mapper class is to clone Declaration object
 *
 * @author Gaurav Mitra
 */
@Mapper(mappingControl = DeepClone.class)
public interface TSDDomainMapper {

  @Mapping(target = "referenceNumber", ignore = true)
  @Mapping(target = "id", ignore = true)
  @Mapping(target = "messageInformation", ignore = true)
  @Mapping(target = "consignmentHeader.presentedlocationOfGoods", ignore = true)
  @Mapping(target = "amendmentRequest", ignore = true)
  @Mapping(target = "amendmentRequests", ignore = true)
  @Mapping(target = "messageExchange", ignore = true)
  @Mapping(target = "invalidationRequests", ignore = true)
  @Mapping(target = "draftError", ignore = true)
  @Mapping(target = "registrationDate", ignore = true)
  @Mapping(target = "currentStatus", ignore = true)
  @Mapping(target = "riskAndControlHistory", ignore = true)
  @Mapping(target = "riskAnalysisRequest", ignore = true)
  @Mapping(target = "currentRiskControlStatus", ignore = true)
  @Mapping(target = "transferNotification", ignore = true)
  @Mapping(target = "transferNotifications", ignore = true)
  @Mapping(target = "deconsolidationNotification", ignore = true)
  TemporaryStorageDeclaration clone(TemporaryStorageDeclaration tsd);

  @Mapping(target = "referenceNumber", ignore = true)
  @Mapping(target = "id", ignore = true)
  @Mapping(target = "amendmentRequest", ignore = true)
  @Mapping(target = "amendmentRequests", ignore = true)
  @Mapping(target = "messageExchange", ignore = true)
  @Mapping(target = "invalidationRequests", ignore = true)
  @Mapping(target = "draftError", ignore = true)
  @Mapping(target = "riskAndControlHistory", ignore = true)
  @Mapping(target = "riskAnalysisRequest", ignore = true)
  @Mapping(target = "currentRiskControlStatus", ignore = true)
  @Mapping(target = "transferNotification", ignore = true)
  @Mapping(target = "transferNotifications", ignore = true)
  @Mapping(target = "deconsolidationNotification", ignore = true)
  TemporaryStorageDeclaration cloneForTransferNotification(TemporaryStorageDeclaration tsd);

  @Mapping(target = "id", ignore = true)
  LocationOfGoods cloneWithoutId(LocationOfGoods locationOfgoods);

  @Mapping(target = "id", ignore = true)
  @Mapping(target = "generalInformationDraftError", ignore = true)
  @Mapping(target = "partiesDraftError", ignore = true)
  @Mapping(target = "currentConsignmentLocationOfGoods", ignore = true)
  MasterConsignment cloneWithoutId(MasterConsignment masterConsignment);

  @Mapping(target = "id", ignore = true)
  @Mapping(target = "generalInformationDraftError", ignore = true)
  @Mapping(target = "partiesDraftError", ignore = true)
  @Mapping(target = "currentConsignmentLocationOfGoods", ignore = true)
  HouseConsignment cloneWithoutId(HouseConsignment houseConsignment);

  @Mapping(target = "id", ignore = true)
  Party cloneWithoutId(Party party);

  @Mapping(target = "id", ignore = true)
  Person cloneWithoutId(Person party);

  @Mapping(target = "id", ignore = true)
  Representative cloneWithoutId(Representative party);

  @Mapping(target = "id", ignore = true)
  @Mapping(target = "party", ignore = true)
  Communication cloneWithoutId(Communication party);

  @Mapping(target = "id", ignore = true)
  @Mapping(target = "draftError", ignore = true)
  @Mapping(target = "consignment", ignore = true)
  ConsignmentItem cloneWithoutId(ConsignmentItem item);

  @Mapping(target = "id", ignore = true)
  @Mapping(target = "consignment", ignore = true)
  @Mapping(target = "consignmentItem", ignore = true)
  TransportEquipment cloneWithoutId(TransportEquipment equipment);

  @Mapping(target = "id", ignore = true)
  @Mapping(target = "consignment", ignore = true)
  @Mapping(target = "consignmentItem", ignore = true)
  AdditionalInformation cloneWithoutId(AdditionalInformation domain);

  @Mapping(target = "id", ignore = true)
  @Mapping(target = "consignment", ignore = true)
  @Mapping(target = "consignmentItem", ignore = true)
  SupportingDocument cloneWithoutId(SupportingDocument domain);

  @Mapping(target = "id", ignore = true)
  @Mapping(target = "consignment", ignore = true)
  @Mapping(target = "consignmentItem", ignore = true)
  AdditionalSupplyChainActor cloneWithoutId(AdditionalSupplyChainActor information);

  @Mapping(target = "id", ignore = true)
  @Mapping(target = "consignment", ignore = true)
  @Mapping(target = "consignmentItem", ignore = true)
  AdditionalReference cloneWithoutId(AdditionalReference domain);

  @Mapping(target = "id", ignore = true)
  @Mapping(target = "consignmentItem", ignore = true)
  Packaging cloneWithoutId(Packaging domain);

  @Mapping(target = "id", ignore = true)
  @Mapping(target = "transportEquipment", ignore = true)
  Seal cloneWithoutId(Seal domain);

  @Mapping(target = "id", ignore = true)
  @Mapping(target = "chainActor", ignore = true)
  AEOAuthorisation cloneWithoutId(AEOAuthorisation domain);

  @Mapping(target = "id", ignore = true)
  @Mapping(target = "consignment", ignore = true)
  Receptacle cloneWithoutId(Receptacle domain);

  @Mapping(target = "referenceNumber", ignore = true)
  @Mapping(target = "id", ignore = true)
  @Mapping(target = "messageInformation", ignore = true)
  @Mapping(target = "consignmentHeader.presentedlocationOfGoods", ignore = true)
  @Mapping(target = "amendmentRequest", ignore = true)
  @Mapping(target = "amendmentRequests", ignore = true)
  @Mapping(target = "messageExchange", ignore = true)
  @Mapping(target = "invalidationRequests", ignore = true)
  @Mapping(target = "draftError", ignore = true)
  @Mapping(target = "registrationDate", ignore = true)
  @Mapping(target = "currentStatus", ignore = true)
  @Mapping(target = "houseConsignments", ignore = true)
  @Mapping(target = "masterConsignment", ignore = true)
  @Mapping(target = "riskAndControlHistory", ignore = true)
  @Mapping(target = "riskAnalysisRequest", ignore = true)
  @Mapping(target = "currentRiskControlStatus", ignore = true)
  @Mapping(target = "transferNotification", ignore = true)
  @Mapping(target = "transferNotifications", ignore = true)
  @Mapping(target = "deconsolidationNotification", ignore = true)
  TemporaryStorageDeclaration cloneWithoutConsignment(TemporaryStorageDeclaration tsd);

  @Mapping(target = "id", ignore = true)
  MessageInformation cloneWithoutId(MessageInformation messageInformation);

  default TemporaryStorageDeclaration cloneTSDWihENSReuse(TemporaryStorageDeclaration currentTSD) {
    TemporaryStorageDeclaration draftDeclaration = cloneWithoutConsignment(currentTSD);
    draftDeclaration.updateConsignmentTypeAndItemType(currentTSD);
    if (!CollectionUtils.isEmpty(currentTSD.getHouseConsignments())
        && (draftDeclaration.getConsignmentType() == ConsignmentInformationType.HOUSE
            || draftDeclaration.getConsignmentType()
                == ConsignmentInformationType.MASTERANDHOUSE)) {
      List<HouseConsignment> houseConsignments =
          currentTSD.getHouseConsignments().stream()
              .map(
                  (hc) ->
                      HouseConsignment.houseConsignmentBuilder()
                          .sequenceNumber(hc.getSequenceNumber())
                          .transportDocument(
                              TransportDocument.builder()
                                  .referenceNumber(hc.getTransportDocument().getReferenceNumber())
                                  .type(hc.getTransportDocument().getType())
                                  .build())
                          .previousDocument(
                              null != hc.getPreviousDocument()
                                  ? PreviousDocument.builder()
                                      .type(hc.getPreviousDocument().getType())
                                      .referenceNumber(
                                          hc.getPreviousDocument().getReferenceNumber())
                                      .goodsItemIdentifier(
                                          hc.getPreviousDocument().getGoodsItemIdentifier())
                                      .build()
                                  : null)
                          .build())
              .collect(Collectors.toList());

      draftDeclaration.setHouseConsignments(houseConsignments);
    }

    if (null != currentTSD.getMasterConsignment()
        && (draftDeclaration.getConsignmentType() == ConsignmentInformationType.MASTER
            || draftDeclaration.getConsignmentType()
                == ConsignmentInformationType.MASTERANDHOUSE)) {
      MasterConsignment mc = currentTSD.getMasterConsignment();
      MasterConsignment consignment =
          MasterConsignment.masterConsignmentBuilder()
              .sequenceNumber(mc.getSequenceNumber())
              .transportDocument(
                  TransportDocument.builder()
                      .referenceNumber(mc.getTransportDocument().getReferenceNumber())
                      .type(mc.getTransportDocument().getType())
                      .build())
              .previousDocument(
                  null != mc.getPreviousDocument()
                      ? PreviousDocument.builder()
                          .type(mc.getPreviousDocument().getType())
                          .referenceNumber(mc.getPreviousDocument().getReferenceNumber())
                          .goodsItemIdentifier(mc.getPreviousDocument().getGoodsItemIdentifier())
                          .build()
                      : null)
              .build();
      draftDeclaration.setMasterConsignment(consignment);
    }
    return draftDeclaration;
  }

  default void setConsignmentAndItemType(
      TemporaryStorageDeclaration declaration, TemporaryStorageDeclaration currentDeclaration) {
    declaration.updateConsignmentTypeAndItemType(currentDeclaration);
  }

  default void mapDeconsolidationTSD(
      TemporaryStorageDeclaration deconTSD, TemporaryStorageDeclaration currentTSD) {

    deconTSD.setMessageInformation(cloneWithoutId(currentTSD.getMessageInformation()));
    deconTSD.setDeclarant(cloneWithoutId(currentTSD.getDeclarant()));
    deconTSD.setRepresentative(cloneWithoutId(currentTSD.getRepresentative()));
    deconTSD.setConsignmentHeader(mapConsignmentHeader(currentTSD.getConsignmentHeader()));
    mapMasterConsignmentForDeconsolidation(
        deconTSD.getMasterConsignment(), currentTSD.getMasterConsignment());
  }

  ConsignmentHeader mapConsignmentHeader(ConsignmentHeader consignmentHeader);

  @Mapping(target = "id", ignore = true)
  @Mapping(target = "declaration", ignore = true)
  @Mapping(target = "generalInformationDraftError", ignore = true)
  @Mapping(target = "partiesDraftError", ignore = true)
  @Mapping(target = "currentConsignmentLocationOfGoods", ignore = true)
  @Mapping(target = "transportDocument", ignore = true)
  @Mapping(target = "createdAt", ignore = true)
  @Mapping(target = "createdBy", ignore = true)
  @Mapping(target = "updatedAt", ignore = true)
  @Mapping(target = "updatedBy", ignore = true)
  @Mapping(target = "version", ignore = true)
  void mapMasterConsignmentForDeconsolidation(
      @MappingTarget MasterConsignment deconMasterConsignment,
      MasterConsignment currentMasterConsignment);
}
