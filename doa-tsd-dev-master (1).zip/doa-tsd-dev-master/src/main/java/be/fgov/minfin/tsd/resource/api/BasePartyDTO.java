package be.fgov.minfin.tsd.resource.api;

import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/** BasePartyDTO */
@SuperBuilder(toBuilder = true)
@EqualsAndHashCode
@Getter
@AllArgsConstructor(access = AccessLevel.PROTECTED)
@NoArgsConstructor
@JsonRootName(value = "baseParty")
public class BasePartyDTO {

  @NotNull
  @Size(min = 1, max = 70)
  @Schema(example = "Acme Corporation")
  private String name;

  @JacksonXmlElementWrapper(useWrapping = false)
  @Size(max = 9)
  private List<@Valid CommunicationDTO> communication;
}
