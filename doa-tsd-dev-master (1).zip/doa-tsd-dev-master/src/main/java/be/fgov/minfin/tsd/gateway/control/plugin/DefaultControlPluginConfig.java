/*
 * @(#)be.fgov.minfin.tsd.gateway.control.plugin.DefaultControlPluginConfig.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.control.plugin;

import static be.fgov.minfin.tsd.gateway.GatewayConfig.DEFAULT_CONNECT_TIMEOUT;
import static be.fgov.minfin.tsd.gateway.GatewayConfig.DEFAULT_REQUEST_TIMEOUT;

import be.fgov.minfin.control.client.TSDControlRestClient;
import be.fgov.minfin.shared.metrics.jersey2.client.JerseyClientUtils;
import javax.ws.rs.client.WebTarget;
import lombok.Getter;
import lombok.Setter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;

/**
 * config file for default contrl gateway client
 *
 * @author GauravMitra
 */
@Validated
@Getter
@Setter
@Configuration
public class DefaultControlPluginConfig {
  private String baseUrl;
  private Integer connectTimeout = DEFAULT_CONNECT_TIMEOUT;
  private Integer requestTimeout = DEFAULT_REQUEST_TIMEOUT;

  @Bean
  public TSDControlRestClient createControlClient(JerseyClientUtils clientUtils) {
    WebTarget target =
        clientUtils.createClient(this.getBaseUrl(), getConnectTimeout(), getRequestTimeout());
    return new TSDControlRestClient(target);
  }
}
