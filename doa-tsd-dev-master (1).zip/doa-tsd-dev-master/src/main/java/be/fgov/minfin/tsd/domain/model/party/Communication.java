/*
 * @(#) be.fgov.minfin.tsd.domain.model.party.Communication
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model.party;

import be.fgov.minfin.tsd.domain.validation.annotation.CodeList;
import be.fgov.minfin.tsd.domain.validation.annotation.group.DeconsolidationNotificationValidatorGroup;
import be.fgov.minfin.tsd.domain.validation.annotation.group.NonDraftTSD;
import be.fgov.minfin.tsd.domain.validation.annotation.group.RiskResultValidator;
import be.fgov.minfin.tsd.domain.validation.annotation.group.TransferNotificationValidatorGroup;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import be.fgov.minfin.tsd.domain.validation.codelist.TSDCodeLists;
import com.fasterxml.jackson.annotation.JsonBackReference;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.groups.Default;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "COMMUNICATION")
@EqualsAndHashCode(exclude = {"party"})
public class Communication {
  @GeneratedValue(generator = "communication_seq")
  @SequenceGenerator(name = "communication_seq", sequenceName = "communication_seq")
  @Id
  private Long id;

  @NotNull(groups = NonDraftTSD.class)
  private String identifier;

  @NotNull(groups = NonDraftTSD.class)
  @CodeList(
      value = TSDCodeLists.CL707,
      groups = {
        Default.class,
        TransferNotificationValidatorGroup.class,
        DeconsolidationNotificationValidatorGroup.class
      })
  @CodeList(
      value = TSDCodeLists.CL707,
      errorCode = ErrorCode.TSPNESXXC0409,
      groups = RiskResultValidator.class)
  private String type;

  private String fullName;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "party_id")
  @JsonBackReference
  private Party party;
}
