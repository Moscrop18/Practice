/*
 * @(#)be.fgov.minfin.tsd.domain.exception.BusinessException.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.exception;

import java.util.Set;
import javax.validation.ConstraintViolation;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class BusinessException extends RuntimeException {

  private static final long serialVersionUID = -6136438839049006396L;

  private final transient Set<ConstraintViolation<?>> violations;
}
