/*
 * @(#)be.fgov.minfin.tsd.resource.api.GnssDTO.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.resource.api;

import be.fgov.minfin.tsd.resource.validation.B2BOnly;
import com.fasterxml.jackson.annotation.JsonRootName;
import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import lombok.Builder;
import lombok.Value;

/** GnssDTO */
@Value
@Builder(toBuilder = true)
@JsonRootName("gnss")
public class GnssDTO {
  @NotNull(groups = B2BOnly.class)
  @Pattern(
      regexp = "[+-]?((0?[0-9]?|1[0-7])[0-9]\\.[0-9]{5,7}|180.000000?0?)",
      message = "{error.TSPNESXXR0059}")
  @Schema(example = "50.85045")
  private String longitude;

  @NotNull(groups = B2BOnly.class)
  @Pattern(
      regexp = "[+-]?([0-8]?[0-9]\\.[0-9]{5,7}|90.000000?0?)",
      message = "{error.TSPNESXXR0059}")
  @Schema(example = "4.34878")
  private String latitude;
}
