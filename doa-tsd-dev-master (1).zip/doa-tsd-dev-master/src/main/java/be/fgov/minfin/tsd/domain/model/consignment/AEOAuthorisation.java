/*
 * @(#)be.fgov.minfin.tsd.domain.model.consignment.AEOAuthorisation
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model.consignment;

import be.fgov.minfin.tsd.domain.model.party.Party;
import com.fasterxml.jackson.annotation.JsonBackReference;
import java.time.LocalDateTime;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "AEO_AUTHORISATION")
public class AEOAuthorisation {
  @GeneratedValue(generator = "AEO_AUTHORISATION_SEQ")
  @SequenceGenerator(name = "AEO_AUTHORISATION_SEQ", sequenceName = "AEO_AUTHORISATION_SEQ")
  @Id
  private Long id;

  private String status;
  private LocalDateTime endDate;

  @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
  @JoinColumn(name = "ADD_SUPPLY_CHAIN_ACTOR_ID")
  @ToString.Exclude
  @JsonBackReference
  @Valid
  private AdditionalSupplyChainActor chainActor;

  @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
  @JoinColumn(name = "PARTY_ID")
  @ToString.Exclude
  @Valid
  private Party party;
}
