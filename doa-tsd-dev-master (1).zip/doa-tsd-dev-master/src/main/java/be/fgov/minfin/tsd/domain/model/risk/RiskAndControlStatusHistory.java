/*
 * @(#)be.fgov.minfin.tsd.domain.model.risk.RiskAndControlStatusHistory.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model.risk;

import be.fgov.minfin.libdoa.commons.lang.Now;
import be.fgov.minfin.tsd.domain.converter.RiskAndControlStatusConverter;
import be.fgov.minfin.tsd.domain.converter.RiskAndControlStatusHistoryReasonConverter;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString(callSuper = true)
@Table(name = "RISK_AND_CONTROL_STATUS_HISTORY")
@EqualsAndHashCode(exclude = "declaration")
public class RiskAndControlStatusHistory {

  @Id
  @GeneratedValue(generator = "risk_and_co_seq")
  @SequenceGenerator(name = "risk_and_co_seq", sequenceName = "risk_and_co_seq")
  private Long id;

  private LocalDateTime timestamp;

  @Convert(converter = RiskAndControlStatusHistoryReasonConverter.class)
  private RiskAndControlStatusHistoryReason reason;

  @Convert(converter = RiskAndControlStatusConverter.class)
  private RiskAndControlStatus status;

  @JoinColumn(name = "TSD_ID")
  @ManyToOne(fetch = FetchType.LAZY)
  private TemporaryStorageDeclaration declaration;

  public RiskAndControlStatusHistory(
      TemporaryStorageDeclaration declaration,
      RiskAndControlStatusHistoryReason reason,
      LocalDateTime timestamp) {
    this.declaration = declaration;
    this.status = declaration.getCurrentRiskControlStatus();
    if (timestamp != null) {
      this.timestamp = timestamp;
    } else {
      this.timestamp = Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime();
    }
    this.reason = reason;
  }
}
