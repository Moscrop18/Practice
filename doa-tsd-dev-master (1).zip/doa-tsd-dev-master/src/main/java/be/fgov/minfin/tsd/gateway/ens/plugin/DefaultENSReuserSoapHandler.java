/*
 * @(#)be.fgov.minfin.pn.gateway.ens.plugin.DefaultENSCommonRepositorySoapHandler.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.ens.plugin;

import be.fgov.minfin.libdoa.exception.TechnicalException;
import java.util.Set;
import java.util.TreeSet;
import java.util.UUID;
import javax.xml.namespace.QName;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * This is handler class to add wsa element in outgoing ENS Messsage
 *
 * @author GauravMitra
 */
@Slf4j
@RequiredArgsConstructor
public class DefaultENSReuserSoapHandler implements SOAPHandler<SOAPMessageContext> {
  public static final String PREFIX = "wsa";

  public static final String URI = "http://www.w3.org/2005/08/addressing";

  public static final String ACTION_HEADER =
      "CCN2.Service.Customs.EU.ICS.ENSConsultationDS/QueryENS";

  public static final String MESSAGE_ID = "MessageID";
  public static final String MESSAGE_TYPE = "MessageType";

  public static final String ACTION = "Action";

  @Override
  public boolean handleMessage(SOAPMessageContext messageContext) {
    Boolean outboundProperty =
        (Boolean) messageContext.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);
    if (outboundProperty.booleanValue()) {
      try {
        SOAPMessage message = messageContext.getMessage();

        if (message.getSOAPPart().getEnvelope().getHeader() == null) {
          message.getSOAPPart().getEnvelope().addHeader();
        }

        SOAPHeader header = message.getSOAPPart().getEnvelope().getHeader();
        header.addNamespaceDeclaration(PREFIX, URI);

        // Action header element addition
        SOAPHeaderElement actionElement = header.addHeaderElement(new QName(URI, ACTION, PREFIX));
        actionElement.addTextNode(ACTION_HEADER);

        // Message ID addition
        header
            .addHeaderElement(new QName(URI, MESSAGE_ID, PREFIX))
            .addTextNode("uuid:" + UUID.randomUUID().toString());

      } catch (SOAPException e) {

        throw new TechnicalException(e.getMessage());
      }
    }
    return true;
  }

  @Override
  public boolean handleFault(SOAPMessageContext context) {

    log.error(context.getMessage().toString());
    throw new TechnicalException("Fault in handler");
  }

  @Override
  public void close(MessageContext context) {
    log.debug("Close Method");
  }

  @Override
  public Set<QName> getHeaders() {

    return new TreeSet<QName>();
  }
}
