/*
 * @(#)be.fgov.minfin.tsd.resource.api.ConsignmentItemDTO.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.resource.api;

import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.Builder;
import lombok.Value;

@Value
@Builder(toBuilder = true)
@JsonRootName("consignmentItem")
public class ConsignmentItemDTO {
  @NotNull
  @Digits(integer = 5, fraction = 0)
  @Schema(example = "2")
  private Integer goodsItemNumber;

  @JacksonXmlElementWrapper(useWrapping = false)
  @Size(min = 1, max = 99)
  @NotNull
  private List<@Valid PackagingDTO> packaging;

  @NotNull @Valid private CommodityDTO commodity;

  @Valid private WeightDTO weight;

  @Valid private PreviousDocumentDTO previousDocument;

  @JacksonXmlElementWrapper(useWrapping = false)
  @Size(max = 9999)
  private List<TransportEquipmentDTO> transportEquipment;

  @JacksonXmlElementWrapper(useWrapping = false)
  @Size(max = 99)
  private List<AdditionalInformationDTO> additionalInformation;

  @JacksonXmlElementWrapper(useWrapping = false)
  @Size(max = 99)
  private List<AdditionalSupplyChainActorDTO> additionalSupplyChainActor;

  @JacksonXmlElementWrapper(useWrapping = false)
  @Size(max = 99)
  private List<SupportingDocumentDTO> supportingDocument;

  @JacksonXmlElementWrapper(useWrapping = false)
  @Size(max = 99)
  private List<AdditionalReferenceDTO> additionalReference;
}
