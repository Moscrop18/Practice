/*
 * @(#) be.fgov.minfin.tsd.gateway.ga.message.LockOffwritableDocumentRequest.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.ga.message;

import be.fgov.minfin.libdoa.goods.accounting.client.api.owd.LockOffwritableDocumentStatusReason;
import be.fgov.minfin.tsd.domain.model.TransferNotification;
import lombok.Builder;
import lombok.Value;

@Value
@Builder(toBuilder = true)
public class LockOffwritableDocumentRequest {

  private LockOffwritableDocumentStatusReason reason;
  private String mrn;
  private TransferNotification transferNotification;
}
