/*
 * @(#) be.fgov.minfin.tsd.domain.validation.validator.TSDFormatValidator.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation.validator;

import static be.fgov.minfin.tsd.domain.model.ConsignmentInformationType.HOUSE;
import static be.fgov.minfin.tsd.domain.model.ConsignmentInformationType.MASTER;
import static be.fgov.minfin.tsd.domain.model.ConsignmentInformationType.MASTERANDHOUSE;
import static org.apache.commons.collections4.CollectionUtils.isEmpty;

import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.consignment.HouseConsignment;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateTSDFormat;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class TSDFormatValidator extends BaseConstraintValidator
    implements ConstraintValidator<ValidateTSDFormat, TemporaryStorageDeclaration> {
  private static final String CONSIGNMENT_TYPE = "consignmentType";
  private static final String CONSIGNMENT_ITEM_TYPE = "consignmentItemType";

  @Override
  public boolean isValid(TemporaryStorageDeclaration tsd, ConstraintValidatorContext context) {
    AtomicBoolean isValid = new AtomicBoolean(true);

    validateConsignment(tsd, context, isValid);

    if (null == tsd.getEnsReUseIndicator()
        || (tsd.getEnsReUseIndicator() != null && !tsd.getEnsReUseIndicator().equals("1"))) {
      validateConsignmentItem(tsd, context, isValid);
    }

    return isValid.get();
  }

  /**
   * Validate mandatory element on the basis of consignment type
   *
   * @param tsd
   * @param context
   * @param isValid
   */
  private void validateConsignment(
      TemporaryStorageDeclaration tsd, ConstraintValidatorContext context, AtomicBoolean isValid) {
    if (null == tsd.getConsignmentType()) return;
    if (tsd.getConsignmentType() == MASTER) {
      if (null == tsd.getMasterConsignment()) {
        addVoilationConsignmentType(isValid, context);
      }
    } else if (tsd.getConsignmentType() == HOUSE) {

      if (isEmpty(tsd.getHouseConsignments()) || null != tsd.getMasterConsignment()) {
        addVoilationConsignmentType(isValid, context);
      }

    } else if (tsd.getConsignmentType() == MASTERANDHOUSE
        && (isEmpty(tsd.getHouseConsignments()) || null == tsd.getMasterConsignment())) {

      addVoilationConsignmentType(isValid, context);
    }
  }

  private void addVoilationConsignmentType(
      AtomicBoolean isValid, ConstraintValidatorContext context) {
    isValid.set(false);
    addViolation(context, ErrorCode.TSPNESXXC0200, CONSIGNMENT_TYPE);
  }

  /**
   * Validate mandatory element on the basis of item type
   *
   * @param tsd
   * @param context
   * @param isValid
   */
  private void validateConsignmentItem(
      TemporaryStorageDeclaration tsd, ConstraintValidatorContext context, AtomicBoolean isValid) {
    if (null == tsd.getConsignmentItemType()) return;
    if (tsd.getConsignmentItemType() == MASTER) {
      validateItemTypeMaster(tsd, context, isValid);

    } else if (tsd.getConsignmentItemType() == HOUSE) {
      validateItemTypeHouse(tsd, context, isValid);
    } else if (tsd.getConsignmentType() == MASTERANDHOUSE) {

      validateItemTypeHouseAndMaster(tsd, context, isValid);
    }
  }

  private void validateItemTypeMaster(
      TemporaryStorageDeclaration tsd, ConstraintValidatorContext context, AtomicBoolean isValid) {
    if (null == tsd.getMasterConsignment()) return;

    if (isEmpty(tsd.getMasterConsignment().getConsignmentItem())) {
      addVoilationConsignmentItemType(isValid, context);
    }
  }

  private void validateItemTypeHouse(
      TemporaryStorageDeclaration tsd, ConstraintValidatorContext context, AtomicBoolean isValid) {
    if (isEmpty(tsd.getHouseConsignments())) return;

    List<HouseConsignment> houseConsignmentWithoutItem =
        getHouseConsignmentWithoutItem(tsd.getHouseConsignments());
    if (!isEmpty(houseConsignmentWithoutItem)) {
      addVoilationConsignmentItemType(isValid, context);
    }
  }

  private void validateItemTypeHouseAndMaster(
      TemporaryStorageDeclaration tsd, ConstraintValidatorContext context, AtomicBoolean isValid) {
    if (isEmpty(tsd.getHouseConsignments()) || null == tsd.getMasterConsignment()) return;
    List<HouseConsignment> houseConsignmentWithoutItem =
        getHouseConsignmentWithoutItem(tsd.getHouseConsignments());

    if (!isEmpty(houseConsignmentWithoutItem)
        || isEmpty(tsd.getMasterConsignment().getConsignmentItem())) {
      addVoilationConsignmentItemType(isValid, context);
    }
  }

  private void addVoilationConsignmentItemType(
      AtomicBoolean isValid, ConstraintValidatorContext context) {
    isValid.set(false);
    addViolation(context, ErrorCode.TSPNESXXC0200, CONSIGNMENT_ITEM_TYPE);
  }

  private List<HouseConsignment> getHouseConsignmentWithoutItem(
      List<HouseConsignment> houseConsignment) {
    return houseConsignment.stream()
        .filter((c) -> isEmpty(c.getConsignmentItem()))
        .collect(Collectors.toList());
  }
}
