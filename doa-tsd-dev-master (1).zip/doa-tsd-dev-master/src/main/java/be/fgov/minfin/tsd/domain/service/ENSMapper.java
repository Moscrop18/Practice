package be.fgov.minfin.tsd.domain.service;

import be.fgov.minfin.tsd.domain.model.TSDStatus;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.consignment.AdditionalSupplyChainActor;
import be.fgov.minfin.tsd.domain.model.consignment.Consignment;
import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentItem;
import be.fgov.minfin.tsd.domain.model.consignment.HouseConsignment;
import be.fgov.minfin.tsd.domain.model.consignment.MasterConsignment;
import be.fgov.minfin.tsd.domain.model.consignment.Receptacle;
import be.fgov.minfin.tsd.domain.model.consignment.TransportDocument;
import be.fgov.minfin.tsd.domain.model.party.PartyAddress;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import org.apache.commons.collections4.CollectionUtils;
import org.mapstruct.AfterMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import wco.datamodel.wco.cis._1.AddressType02;
import wco.datamodel.wco.cis._1.ConsignmentHouseLevelType12;
import wco.datamodel.wco.cis._1.ConsignmentMasterLevelType12;
import wco.datamodel.wco.cis._1.GoodsItemType10;
import wco.datamodel.wco.cis._1.GoodsItemType11;
import wco.datamodel.wco.cis._1.IE4R05Type;
import wco.datamodel.wco.cis._1.ReceptacleType;
import wco.datamodel.wco.cis._1.TransportDocumentHouseLevelType03;

@Mapper
public interface ENSMapper {

  @Mapping(
      target = "masterConsignment",
      expression =
          "java(mapOnlyMC(declaration.getMasterConsignment(), ens.getRelatedENS().getConsignmentMasterLevel()))")
  @Mapping(
      target = "houseConsignments",
      expression =
          "java(map(declaration.getHouseConsignments(), ens.getRelatedENS().getConsignmentMasterLevel().getConsignmentHouseLevel()))")
  TemporaryStorageDeclaration mapENSToTSDWhenBothHCAndMC(
      @MappingTarget TemporaryStorageDeclaration declaration, IE4R05Type ens);

  @Mapping(target = "supportingDocument", source = "supportingDocuments")
  @Mapping(target = "referenceNumberUCR", source = "referenceNumberUCR.referenceNumberUCR")
  MasterConsignment mapOnlyMC(
      @MappingTarget MasterConsignment masterConsignment,
      ConsignmentMasterLevelType12 masterConsignmentENS);

  @Mapping(target = "identificationNumber", source = "receptacleIdentificationNumber")
  Receptacle map(ReceptacleType receptacleENS);

  @Mapping(target = "street", source = "streetNameLine1")
  @Mapping(target = "streetAdditionalLine", source = "streetNameLine2")
  PartyAddress map(AddressType02 addressENS);

  @Mapping(target = "grossMass", source = "weight.grossMass")
  ConsignmentItem map(GoodsItemType10 consignmentItemENS);

  @Mapping(target = "sequenceNumber", ignore = true)
  @Mapping(target = "supportingDocument", source = "supportingDocuments")
  @Mapping(target = "consignmentItem", source = "goodsItem")
  @Mapping(target = "referenceNumberUCR", source = "referenceNumberUCR.referenceNumberUCR")
  HouseConsignment map(
      @MappingTarget HouseConsignment houseConsignment,
      ConsignmentHouseLevelType12 houseConsignmentENS);

  @Mapping(target = "grossMass", source = "weight.grossMass")
  ConsignmentItem map(GoodsItemType11 consignmentItemENS);

  default List<HouseConsignment> map(
      List<HouseConsignment> houseConsignmentsTSD,
      List<ConsignmentHouseLevelType12> houseConsignmentsENS) {

    for (HouseConsignment houseConsignmentTSD : houseConsignmentsTSD) {
      for (ConsignmentHouseLevelType12 houseConsignmentENS : houseConsignmentsENS) {
        if (houseConsignmentENS.getTransportDocumentHouseLevel() != null
            && houseConsignmentTSD
                .getTransportDocument()
                .getType()
                .equalsIgnoreCase(houseConsignmentENS.getTransportDocumentHouseLevel().getType())
            && houseConsignmentTSD
                .getTransportDocument()
                .getReferenceNumber()
                .equalsIgnoreCase(
                    houseConsignmentENS.getTransportDocumentHouseLevel().getDocumentNumber())) {
          map(houseConsignmentTSD, houseConsignmentENS);
          break;
        }
      }
    }
    return houseConsignmentsTSD;
  }

  @Mapping(
      target = "houseConsignments",
      expression =
          "java(map(declaration.getHouseConsignments(), ens.getRelatedENS().getConsignmentMasterLevel().getConsignmentHouseLevel()))")
  TemporaryStorageDeclaration mapENSToTSDWhenOnlyHC(
      @MappingTarget TemporaryStorageDeclaration declaration, IE4R05Type ens);

  @Mapping(
      target = "masterConsignment",
      expression =
          "java(mapMCAndCI(declaration.getMasterConsignment(), ens.getRelatedENS().getConsignmentMasterLevel()))")
  TemporaryStorageDeclaration mapENSToTSDWhenOnlyMC(
      @MappingTarget TemporaryStorageDeclaration declaration, IE4R05Type ens);

  @Mapping(target = "supportingDocument", source = "supportingDocuments")
  @Mapping(target = "consignmentItem", source = "goodsItem")
  @Mapping(target = "referenceNumberUCR", source = "referenceNumberUCR.referenceNumberUCR")
  MasterConsignment mapMCAndCI(
      @MappingTarget MasterConsignment masterConsignment,
      ConsignmentMasterLevelType12 masterConsignmentENS);

  default List<HouseConsignment> map(List<ConsignmentHouseLevelType12> houseConsignmentsENS) {
    if (houseConsignmentsENS == null) {
      return Collections.emptyList();
    }
    List<HouseConsignment> houseConsignments = new ArrayList<>(houseConsignmentsENS.size());
    AtomicInteger sequence = new AtomicInteger(0);
    for (ConsignmentHouseLevelType12 ensConsignmentHouseLevelDTO : houseConsignmentsENS) {
      HouseConsignment houseConsignment = map(ensConsignmentHouseLevelDTO);
      houseConsignment.setSequenceNumber(sequence.incrementAndGet());
      houseConsignments.add(houseConsignment);
    }
    return houseConsignments;
  }

  @Mapping(target = "sequenceNumber", ignore = true)
  @Mapping(target = "supportingDocument", source = "supportingDocuments")
  @Mapping(target = "consignmentItem", source = "goodsItem")
  @Mapping(target = "referenceNumberUCR", source = "referenceNumberUCR.referenceNumberUCR")
  @Mapping(target = "transportDocument", source = "transportDocumentHouseLevel")
  HouseConsignment map(ConsignmentHouseLevelType12 houseConsignmentENS);

  @Mapping(target = "referenceNumber", source = "documentNumber")
  TransportDocument map(TransportDocumentHouseLevelType03 consignmentItemENS);

  @AfterMapping
  default void performDataTransformations(
      @MappingTarget TemporaryStorageDeclaration declaration, IE4R05Type ens) {
    if (CollectionUtils.isEmpty(declaration.getHouseConsignments())) {
      if (null != declaration.getCurrentStatus()
          && declaration.getCurrentStatus() == TSDStatus.DRAFT) {
        declaration
            .getHouseConsignments()
            .addAll(
                map(ens.getRelatedENS().getConsignmentMasterLevel().getConsignmentHouseLevel()));
      } else {
        declaration.setHouseConsignments(
            map(ens.getRelatedENS().getConsignmentMasterLevel().getConsignmentHouseLevel()));
      }
    }

    removeAdditionalSupplyChainActorsMC(declaration);
    removeAdditionalSupplyChainActorsHC(declaration);

    if ("F10".equals(ens.getRelatedENS().getSpecificCircumstanceIndicator())
        || "F13".equals(ens.getRelatedENS().getSpecificCircumstanceIndicator())) {
      removeMasterConsignmentItems(declaration.getMasterConsignment());
      transferConsignmentItems(
          declaration.getMasterConsignment(), declaration.getHouseConsignments());
      removeHouseConsignments(declaration.getHouseConsignments());
    }

    dataTransformationTypeOfPackagesHC(declaration);
    if (declaration.getMasterConsignment() != null) {
      dataTransformationTypeOfPackages(declaration.getMasterConsignment().getConsignmentItem());
    }
  }

  private void dataTransformationTypeOfPackages(List<ConsignmentItem> consignmentItems) {
    if (!CollectionUtils.isEmpty(consignmentItems)) {
      consignmentItems.stream()
          .forEach(
              x -> {
                if (!CollectionUtils.isEmpty(x.getPackaging())) {
                  x.getPackaging().stream()
                      .forEach(
                          p -> {
                            if (p.getTypeOfPackages() == null) {
                              p.setTypeOfPackages("NA");
                            }
                          });
                }
              });
    }
  }

  private void dataTransformationTypeOfPackagesHC(TemporaryStorageDeclaration declaration) {
    List<HouseConsignment> houseConsignments = declaration.getHouseConsignments();
    if (!CollectionUtils.isEmpty(houseConsignments)) {
      houseConsignments.stream()
          .forEach(a -> dataTransformationTypeOfPackages(a.getConsignmentItem()));
    }
  }

  private void removeHouseConsignments(List<HouseConsignment> houseConsignments) {
    List<HouseConsignment> hCsToRemove = new ArrayList<>();
    if (!CollectionUtils.isEmpty(houseConsignments)) {
      houseConsignments.stream()
          .forEach(
              x -> {
                if (CollectionUtils.isEmpty(x.getConsignmentItem())) {
                  hCsToRemove.add(x);
                }
              });
    }
    houseConsignments.removeAll(hCsToRemove);
  }

  private void transferConsignmentItems(
      MasterConsignment masterConsignment, List<HouseConsignment> houseConsignments) {
    if (Objects.nonNull(masterConsignment) && !CollectionUtils.isEmpty(houseConsignments)) {
      houseConsignments.stream()
          .forEach(
              x -> {
                masterConsignment.getConsignmentItem().addAll(x.getConsignmentItem());
                x.setConsignmentItem(null);
              });
      masterConsignment.getConsignmentItem().stream()
          .forEach(x -> x.setConsignment(masterConsignment));
    }
  }

  private void removeMasterConsignmentItems(MasterConsignment masterConsignment) {
    List<ConsignmentItem> list = new ArrayList<>();
    if (Objects.nonNull(masterConsignment)) {
      masterConsignment.setConsignmentItem(list);
    }
  }

  private void removeAdditionalSupplyChainActorsHC(TemporaryStorageDeclaration declaration) {
    if (!CollectionUtils.isEmpty(declaration.getHouseConsignments())) {
      declaration.getHouseConsignments().stream()
          .forEach(
              x -> {
                if (x.getAdditionalSupplyChainActor() != null) {
                  List<AdditionalSupplyChainActor> actorsToRemove = new ArrayList<>();
                  x.getAdditionalSupplyChainActor().stream()
                      .forEach(
                          y -> {
                            if (Objects.isNull(y.getIdentificationNumber())
                                || Objects.isNull(y.getRole())) {
                              actorsToRemove.add(y);
                            }
                          });
                  x.getAdditionalSupplyChainActor().removeAll(actorsToRemove);
                }
                removeSupplyChainActorsCIHouseLvl(x);
              });
    }
  }

  private void removeSupplyChainActorsCIHouseLvl(HouseConsignment x) {
    if (Objects.nonNull(x.getConsignmentItem())) {
      x.getConsignmentItem().stream()
          .forEach(
              y -> {
                if (y.getAdditionalSupplyChainActor() != null) {
                  List<AdditionalSupplyChainActor> actorsToRemove = new ArrayList<>();

                  y.getAdditionalSupplyChainActor().stream()
                      .forEach(
                          z -> {
                            if (Objects.isNull(z.getIdentificationNumber())
                                || Objects.isNull(z.getRole())) {
                              actorsToRemove.add(z);
                            }
                          });
                  y.getAdditionalSupplyChainActor().removeAll(actorsToRemove);
                }
              });
    }
  }

  private void removeAdditionalSupplyChainActorsMC(TemporaryStorageDeclaration declaration) {
    if (Objects.nonNull(declaration.getMasterConsignment())
        && Objects.nonNull(declaration.getMasterConsignment().getAdditionalSupplyChainActor())) {
      List<AdditionalSupplyChainActor> actorsToRemove = new ArrayList<>();
      declaration.getMasterConsignment().getAdditionalSupplyChainActor().stream()
          .forEach(
              x -> {
                if (Objects.isNull(x.getIdentificationNumber()) || Objects.isNull(x.getRole())) {
                  actorsToRemove.add(x);
                }
              });
      declaration.getMasterConsignment().getAdditionalSupplyChainActor().removeAll(actorsToRemove);
    }
    removeSupplyChainActorsCIMasterLvl(declaration);
  }

  private void removeSupplyChainActorsCIMasterLvl(TemporaryStorageDeclaration declaration) {
    if (Objects.nonNull(declaration.getMasterConsignment())
        && Objects.nonNull(declaration.getMasterConsignment().getConsignmentItem())) {
      declaration.getMasterConsignment().getConsignmentItem().stream()
          .forEach(
              x -> {
                if (x.getAdditionalSupplyChainActor() != null) {
                  List<AdditionalSupplyChainActor> actorsToRemove = new ArrayList<>();

                  x.getAdditionalSupplyChainActor().stream()
                      .forEach(
                          y -> {
                            if (Objects.isNull(y.getIdentificationNumber())
                                || Objects.isNull(y.getRole())) {
                              actorsToRemove.add(y);
                            }
                          });
                  x.getAdditionalSupplyChainActor().removeAll(actorsToRemove);
                }
              });
    }
  }

  default void setBackReference(TemporaryStorageDeclaration tsd) {
    if (null != tsd.getMasterConsignment()) {

      if (CollectionUtils.isNotEmpty(tsd.getMasterConsignment().getConsignmentItem())) {
        tsd.getMasterConsignment().getConsignmentItem().stream()
            .filter(x -> x.getConsignment() == null)
            .forEach(x -> x.setConsignment(tsd.getMasterConsignment()));
      }

      if (CollectionUtils.isNotEmpty(tsd.getMasterConsignment().getTransportEquipment())) {
        tsd.getMasterConsignment().getTransportEquipment().stream()
            .filter(x -> x.getConsignment() == null)
            .forEach(x -> x.setConsignment(tsd.getMasterConsignment()));
      }
      if (CollectionUtils.isNotEmpty(tsd.getMasterConsignment().getAdditionalInformation())) {
        tsd.getMasterConsignment().getAdditionalInformation().stream()
            .filter(x -> x.getConsignment() == null)
            .forEach(x -> x.setConsignment(tsd.getMasterConsignment()));
      }
      if (CollectionUtils.isNotEmpty(tsd.getMasterConsignment().getSupportingDocument())) {
        tsd.getMasterConsignment().getSupportingDocument().stream()
            .filter(x -> x.getConsignment() == null)
            .forEach(x -> x.setConsignment(tsd.getMasterConsignment()));
      }
      if (CollectionUtils.isNotEmpty(tsd.getMasterConsignment().getAdditionalSupplyChainActor())) {
        tsd.getMasterConsignment().getAdditionalSupplyChainActor().stream()
            .filter(x -> x.getConsignment() == null)
            .forEach(x -> x.setConsignment(tsd.getMasterConsignment()));
      }
      if (CollectionUtils.isNotEmpty(tsd.getMasterConsignment().getReceptacle())) {
        tsd.getMasterConsignment().getReceptacle().stream()
            .filter(x -> x.getConsignment() == null)
            .forEach(x -> x.setConsignment(tsd.getMasterConsignment()));
      }
    }
    if (CollectionUtils.isNotEmpty(tsd.getHouseConsignments())) {
      tsd.getHouseConsignments().stream()
          .filter(x -> x.getDeclaration() == null)
          .forEach(x -> x.setDeclaration(tsd));
    }
    if (CollectionUtils.isNotEmpty(tsd.getHouseConsignments())) {
      tsd.getHouseConsignments().forEach((hc) -> setBackRefConsignment(hc));
    }
  }

  private void setBackRefConsignment(Consignment consignment) {
    if (!CollectionUtils.isEmpty(consignment.getConsignmentItem())) {
      consignment.getConsignmentItem().stream()
          .filter(x -> x.getConsignment() == null)
          .forEach(x -> x.setConsignment(consignment));
    }
  }
}
