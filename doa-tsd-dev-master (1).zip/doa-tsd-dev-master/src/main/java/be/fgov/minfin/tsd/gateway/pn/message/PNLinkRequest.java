package be.fgov.minfin.tsd.gateway.pn.message;

import be.fgov.minfin.libdoa.amqp.BaseEvent;
import be.fgov.minfin.pn.client.api.MessageHeaderDTO;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonPropertyOrder({"messageHeader", "frn", "mrn"})
@JsonInclude(Include.NON_NULL)
@JsonRootName("IETS908")
@Builder
public class PNLinkRequest extends BaseEvent {
  private MessageHeaderDTO messageHeader;
  private String frn;
  private String mrn;
}
