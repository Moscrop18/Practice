/*
 * @(#)be.fgov.minfin.tsd.domain.model.ReceiveRiskAnalysisResult.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model;

import be.fgov.minfin.tsd.domain.message.MessageHeader;
import be.fgov.minfin.tsd.domain.model.risk.ControlNotification;
import be.fgov.minfin.tsd.domain.model.risk.ControlRecommendation;
import be.fgov.minfin.tsd.domain.model.risk.CustomsOfficeOfControl;
import be.fgov.minfin.tsd.domain.model.risk.RequestedDocument;
import be.fgov.minfin.tsd.domain.model.risk.RiskAnalysisResponse;
import be.fgov.minfin.tsd.domain.model.risk.RiskAnalysisResult;
import be.fgov.minfin.tsd.domain.model.risk.RiskAnalyst;
import be.fgov.minfin.tsd.domain.model.risk.TypeOfControls;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import be.fgov.minfin.tsd.domain.validation.annotation.group.RiskResultValidator;
import java.util.List;
import javax.validation.Valid;
import lombok.Builder;
import lombok.Value;
import org.apache.commons.collections4.CollectionUtils;

@Value
@Builder(toBuilder = true)
@ValidateBusinessRules(groups = RiskResultValidator.class)
public class ReceiveRiskAnalysisResult {

  private MessageHeader messageHeader;

  private @Valid RiskAnalyst riskAnalyst;

  private String riskAnalysisRequestCategory;

  private String riskAnalysisRequestReference;

  private List<@Valid RiskAnalysisResult> riskAnalysisResult;

  private List<@Valid ControlRecommendation> controlRecommendations;

  private @Valid RiskAnalysisResponse riskAnalysisResponse;

  private @Valid ControlNotification controlNotification;

  private List<@Valid TypeOfControls> typeOfControls;

  private List<@Valid RequestedDocument> requestedDocument;

  private @Valid CustomsOfficeOfControl customsOfficeOfControl;

  public boolean hasControlRecommendations() {
    return CollectionUtils.isNotEmpty(controlRecommendations);
  }
}
