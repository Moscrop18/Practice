/*
 * @(#) be.fgov.minfin.tsd.gateway.pn.plugin.PNGatewayPlugin
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.pn.plugin;

import be.fgov.minfin.pn.client.api.ActivationResultDTO;
import be.fgov.minfin.pn.client.api.LinkingRequestDTO;
import be.fgov.minfin.tsd.gateway.pn.exception.RegisterPNRejectException;
import be.fgov.minfin.tsd.gateway.pn.message.RegisterPNRequest;
import org.springframework.stereotype.Component;

/**
 * @author NamrataGupta
 */
@Component
public interface PNGatewayPlugin {

  public String registerPN(RegisterPNRequest request) throws RegisterPNRejectException;

  public void linkPN(LinkingRequestDTO linkRequest);

  public void sendTSDActivationResult(ActivationResultDTO activationRequest);
}
