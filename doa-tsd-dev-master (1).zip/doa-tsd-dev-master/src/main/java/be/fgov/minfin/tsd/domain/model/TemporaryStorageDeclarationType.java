/*
 * @(#)be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclarationType.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model;

public enum TemporaryStorageDeclarationType {
  PRELODGED(1),
  COMBINED(2);
  private final Integer value;

  private TemporaryStorageDeclarationType(Integer value) {
    this.value = value;
  }

  public Integer getValue() {
    return value;
  }
}
