/*
 * @(#)be.fgov.minfin.tsd.config.TracingConfig.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.config;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/** TracingConfig */
@ConditionalOnProperty(
    value = "opentracing.jaeger.enabled",
    havingValue = "false",
    matchIfMissing = false)
@Configuration
public class TracingConfig {
  @Bean
  public io.opentracing.Tracer jaegerTracer() {
    return io.opentracing.noop.NoopTracerFactory.create();
  }
}
