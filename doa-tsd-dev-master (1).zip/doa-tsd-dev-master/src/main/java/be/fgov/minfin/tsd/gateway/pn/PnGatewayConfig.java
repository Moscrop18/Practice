/*
 * @(#) be.fgov.minfin.tsd.gateway.pn.PNGatewayConfig
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.pn;

import static be.fgov.minfin.tsd.config.RabbitConfig.ENABLE_QUORUM_QUEUE;
import static be.fgov.minfin.tsd.config.RabbitConfig.RABBIT_LISTENER_CONTAINER_FACTORY;

import be.fgov.minfin.libdoa.amqp.ExchangeConfig;
import be.fgov.minfin.libdoa.amqp.transactional.QueueConfig;
import be.fgov.minfin.tsd.gateway.pn.plugin.DefaultPNGatewayPluginConfig;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.boot.context.properties.NestedConfigurationProperty;
import org.springframework.context.annotation.Configuration;

/**
 * @author NamrataGupta
 */
@Slf4j
@Setter
@Getter
@Configuration("pnGatewayConfig")
public class PnGatewayConfig {
  public static final String PN_LINK_QUEUE = "#{pnLinkQueue}";
  public static final String ACTIVATION_RESULT_QUEUE = "#{pnActivationResultQueue}";

  public static final String LINK_CONCURRENCY_SETTING =
      "#{pnGatewayConfig.pnLinkQueue.concurrentConsumers}";
  public static final String ACTIVATION_CONCURRENCY_SETTING =
      "#{pnGatewayConfig.pnActivationResultQueue.concurrentConsumers}";

  @NestedConfigurationProperty private final DefaultPNGatewayPluginConfig defaultplugin;

  private ExchangeConfig exchange;
  private ConfigurableBeanFactory beanFactory;
  private QueueConfig pnLinkQueue;
  private QueueConfig pnActivationResultQueue;
  private RabbitTemplate rabbitTemplate;
  private boolean registerRetryQueueListener;
  private Integer maxAttempts;
  private Integer backOffDelay;

  public PnGatewayConfig(
      ConfigurableBeanFactory beanFactory,
      DefaultPNGatewayPluginConfig defaultplugin,
      RabbitTemplate rabbitTemplate) {
    this.beanFactory = beanFactory;
    this.defaultplugin = defaultplugin;
    this.rabbitTemplate = rabbitTemplate;
    exchange = new ExchangeConfig("tsd.pn.gateway");
    pnLinkQueue =
        new QueueConfig(
            exchange, "tsd_out_link_pn", "send.tsd.link.pn", "pnLinkQueue", ENABLE_QUORUM_QUEUE);
    pnActivationResultQueue =
        new QueueConfig(
            exchange,
            "tsd_out_activation_result",
            "send.tsd.activation.result",
            "pnActivationResultQueue",
            ENABLE_QUORUM_QUEUE);
  }

  public void init() {
    // can this be done more elegantly?
    exchange.registerBeanDefinitions(beanFactory);
    if (registerRetryQueueListener) {
      pnLinkQueue.registerBeanDefinitions(
          beanFactory, RABBIT_LISTENER_CONTAINER_FACTORY, rabbitTemplate, false);
      pnActivationResultQueue.registerBeanDefinitions(
          beanFactory, RABBIT_LISTENER_CONTAINER_FACTORY, rabbitTemplate, false);
    } else {
      log.warn("RetryRoutingListener is not enabled for PnGateway");
      pnLinkQueue.registerBeanDefinitions(beanFactory);
      pnActivationResultQueue.registerBeanDefinitions(beanFactory);
    }
  }
}
