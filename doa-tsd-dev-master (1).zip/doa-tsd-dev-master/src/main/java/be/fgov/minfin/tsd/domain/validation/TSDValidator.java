/*
 * @(#)be.fgov.minfin.tsd.domain.validation.TSDValidator
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation;

import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclarationType;
import be.fgov.minfin.tsd.domain.validation.annotation.group.CombinedTSDValidatorGroup;
import be.fgov.minfin.tsd.domain.validation.annotation.group.NonDraftTSD;
import be.fgov.minfin.tsd.domain.validation.message.MessageType;
import be.fgov.minfin.tsd.domain.validation.plugin.TSDValidatorPlugin;
import be.fgov.minfin.tsd.domain.validation.resolver.CustomTraversableResolver;
import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import javax.validation.groups.Default;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.validator.HibernateValidatorFactory;
import org.hibernate.validator.internal.engine.resolver.JPATraversableResolver;
import org.springframework.stereotype.Component;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;

/**
 * @author GauravMitra
 */
@RequiredArgsConstructor
@Slf4j
@Component
public class TSDValidator implements TSDValidatorPlugin {

  private final LocalValidatorFactoryBean factory;
  private final CustomTraversableResolver resolver;

  public Set<ConstraintViolation<TemporaryStorageDeclaration>> validateTSD(
      final TemporaryStorageDeclaration declaration) {
    return validateTSD(declaration, MessageType.TSD_SUBMISSION);
  }

  public Set<ConstraintViolation<TemporaryStorageDeclaration>> validateTSD(
      final TemporaryStorageDeclaration declaration, MessageType messageType) {
    new JPATraversableResolver();
    Validator validator =
        factory
            .unwrap(HibernateValidatorFactory.class)
            .usingContext()
            .constraintValidatorPayload(messageType)
            // Validation skiping in case of loaded entitys thata why added
            .traversableResolver(resolver)
            .getValidator();
    Set<ConstraintViolation<TemporaryStorageDeclaration>> violation =
        validator.validate(declaration, Default.class);

    if (log.isDebugEnabled()) {
      violation.stream()
          .forEach(
              v ->
                  log.info(
                      "violation with message {} and path {}",
                      v.getMessage(),
                      v.getPropertyPath()));
    }
    return violation;
  }

  /** This method is used to perform mandatory check on Draft TSD */
  public Set<ConstraintViolation<TemporaryStorageDeclaration>> validateTSDFormat(
      final TemporaryStorageDeclaration declaration) {
    Validator validator =
        factory
            .unwrap(HibernateValidatorFactory.class)
            .usingContext()
            .traversableResolver(resolver)
            .getValidator();

    if (declaration.getType() == TemporaryStorageDeclarationType.COMBINED) {
      return validator.validate(declaration, CombinedTSDValidatorGroup.class);
    } else {
      return validator.validate(declaration, NonDraftTSD.class);
    }
  }
}
