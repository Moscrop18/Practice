package be.fgov.minfin.tsd.gateway.ens.exception;

import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.validation.ConstraintViolation;
import lombok.Getter;

@Getter
public class ReuseFailedException extends RuntimeException {

  /** */
  private static final long serialVersionUID = -3208522027768369014L;

  public enum ReuseFailedType {
    MINIMAL_DATASET_FAILED("Minimal Data Set Validation Failed ... "),
    FETCH_ENS_FAILED("Fetching Data from ENS encountered a problem ... "),
    ENS_DATA_VALIDATION_FAILED("ENS data validation and transformation failed ... ");

    private final String value;

    ReuseFailedType(final String newValue) {
      value = newValue;
    }

    public String getValue() {
      return value;
    }
  }

  private final transient Object[] parameters;

  public ReuseFailedException(ReuseFailedType message) {
    super(message.getValue());
    this.parameters = null;
  }

  public ReuseFailedException(ReuseFailedType message, Object[] parameters) {
    super(message.getValue());
    this.parameters = parameters;
  }

  public ReuseFailedException(ReuseFailedType message, Throwable cause) {
    super(message.getValue(), cause);
    this.parameters = null;
  }

  public ReuseFailedException(ReuseFailedType message, Object[] parameters, Throwable cause) {
    super(message.getValue(), cause);
    this.parameters = parameters;
  }

  public Set<ConstraintViolation<TemporaryStorageDeclaration>> toConstraintViolation() {
    List<Object> violations = Arrays.asList(this.getParameters());
    @SuppressWarnings("unchecked")
    List<ConstraintViolation<TemporaryStorageDeclaration>> violationsList =
        (List<ConstraintViolation<TemporaryStorageDeclaration>>) (Object) violations;
    return new HashSet<>(violationsList);
  }
}
