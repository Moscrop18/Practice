/*
 * @(#) be.fgov.minfin.tsd.domain.model.consignment.LocationOfGoods.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model.consignment;

import be.fgov.minfin.tsd.domain.model.CustomsOffice;
import be.fgov.minfin.tsd.domain.validation.annotation.CodeList;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import be.fgov.minfin.tsd.domain.validation.annotation.group.NonDraftTSD;
import be.fgov.minfin.tsd.domain.validation.annotation.group.TransferNotificationValidatorGroup;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import be.fgov.minfin.tsd.domain.validation.codelist.TSDCodeLists;
import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.groups.Default;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "LOCATION_OF_GOODS")
@EqualsAndHashCode()
@ValidateBusinessRules(groups = {Default.class, TransferNotificationValidatorGroup.class})
public class LocationOfGoods {
  @Id
  @GeneratedValue(generator = "LOCATION_SEQ")
  @SequenceGenerator(name = "LOCATION_SEQ", sequenceName = "LOCATION_SEQ")
  private Long id;

  @Column(name = "IDENTIFICATION_QUALIFIER")
  @CodeList(
      value = TSDCodeLists.CL326,
      groups = {Default.class, TransferNotificationValidatorGroup.class})
  @NotNull(groups = NonDraftTSD.class)
  private String qualifierOfIdentification;

  @Column(name = "LOCATION_TYPE")
  @CodeList(
      value = TSDCodeLists.CL347,
      groups = {Default.class, TransferNotificationValidatorGroup.class})
  @NotNull(groups = NonDraftTSD.class)
  private String typeOfLocation;

  @CodeList(
      value = TSDCodeLists.CL144,
      errorCode = ErrorCode.TSPNESXXC0081,
      groups = {Default.class, TransferNotificationValidatorGroup.class})
  private String unLoCode;

  private @Valid @Embedded GNSS gnss;
  private @Valid @Embedded EconomicOperator economicOperator;
  private @Valid @Embedded Address address;

  private String authorisationNumber;

  private String additionalIdentifier;

  @AttributeOverride(name = "referenceNumber", column = @Column(name = "CUSTOMS_OFFICE_REF_NUMBER"))
  @CodeList(
      value = TSDCodeLists.CL141,
      errorCode = ErrorCode.TSPNESXXC0095,
      groups = {Default.class, TransferNotificationValidatorGroup.class})
  @Embedded
  private CustomsOffice customsOffice;

  public LocationOfGoods(LocationOfGoods locOfGoods) {

    this.qualifierOfIdentification = locOfGoods.getQualifierOfIdentification();
    this.typeOfLocation = locOfGoods.getTypeOfLocation();
    this.unLoCode = locOfGoods.getUnLoCode();
    this.gnss = locOfGoods.getGnss();
    this.economicOperator = locOfGoods.getEconomicOperator();
    this.address = locOfGoods.getAddress();
    this.authorisationNumber = locOfGoods.getAuthorisationNumber();
    this.additionalIdentifier = locOfGoods.getAdditionalIdentifier();
    this.customsOffice = locOfGoods.getCustomsOffice();
  }
}
