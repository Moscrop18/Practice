/*
 * @(#) be.fgov.minfin.tsd.domain.converter.RiskAndControlStatusConverter.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.converter;

import be.fgov.minfin.tsd.domain.model.risk.RiskAndControlStatus;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter(autoApply = true)
public class RiskAndControlStatusConverter
    implements AttributeConverter<RiskAndControlStatus, Integer> {

  @Override
  public Integer convertToDatabaseColumn(RiskAndControlStatus status) {
    if (status != null) {
      return status.getCode();
    }
    return null;
  }

  @Override
  public RiskAndControlStatus convertToEntityAttribute(Integer dbData) {
    if (dbData == null) {
      return null;
    }
    for (RiskAndControlStatus nodeType : RiskAndControlStatus.values()) {
      if (nodeType.getCode().equals(dbData)) {
        return nodeType;
      }
    }
    throw new IllegalArgumentException("Unknown database value:" + dbData);
  }
}
