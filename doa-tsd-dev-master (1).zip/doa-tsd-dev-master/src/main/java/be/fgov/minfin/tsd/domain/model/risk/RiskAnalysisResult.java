/*
 * @(#)be.fgov.minfin.tsd.domain.model.risk.RiskAnalysisResult.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model.risk;

import be.fgov.minfin.tsd.domain.validation.annotation.CodeList;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import be.fgov.minfin.tsd.domain.validation.annotation.group.RiskResultValidator;
import be.fgov.minfin.tsd.domain.validation.codelist.TSDCodeLists;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@Builder
@NoArgsConstructor
@ValidateBusinessRules(groups = RiskResultValidator.class)
@AllArgsConstructor
@ToString(callSuper = true)
@Table(name = "RISK_ANALYSIS_RESULT")
@EqualsAndHashCode(exclude = "riskAnalysisRequest")
public class RiskAnalysisResult {
  @Id
  @GeneratedValue(generator = "risk_analysis_result_seq")
  @SequenceGenerator(name = "risk_analysis_result_seq", sequenceName = "risk_analysis_result_seq")
  private Long id;

  @Column(columnDefinition = "char")
  @CodeList(value = TSDCodeLists.CL739, groups = RiskResultValidator.class)
  private String type;

  @CodeList(value = TSDCodeLists.CL740, groups = RiskResultValidator.class)
  @Transient
  private String riskAreaCode; // for business Validation

  @Column(name = "RESULT_CODE", columnDefinition = "SMALLINT")
  @CodeList(value = TSDCodeLists.CL737, groups = RiskResultValidator.class)
  private String resultCode;

  @Transient private String riskCriteriaIdentifier; // for business Validation

  @Column(name = "RISK_LEVEL", columnDefinition = "char")
  @CodeList(value = TSDCodeLists.CL758, groups = RiskResultValidator.class)
  private String riskLevel;

  @Column(name = "description")
  private String resultDescription;

  @Transient String dateAndTimeOfCompletion; // for business Validation

  @JoinColumn(name = "RISK_ANALYSIS_REQUEST_ID")
  @ManyToOne(fetch = FetchType.LAZY)
  private RiskAnalysisRequest riskAnalysisRequest;

  @Transient private List<Pointer> pointer; // for business Validation
}
