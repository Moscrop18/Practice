/*
 * @(#) be.fgov.minfin.tsd.domain.validation.IsoTimestampValidator.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties
 * or made public without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation;

import be.fgov.minfin.tsd.domain.validation.annotation.IsoTimestamp;
import be.fgov.minfin.tsd.util.IsoTimestampFormatterUtil;
import java.time.format.DateTimeParseException;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class IsoTimestampValidator implements ConstraintValidator<IsoTimestamp, String> {

  @Override
  public boolean isValid(String value, ConstraintValidatorContext context) {
    boolean isValid = true;
    if (null != value) {
      try {
        IsoTimestampFormatterUtil.parse(value);
      } catch (DateTimeParseException dateTimeParseException) {
        isValid = false;
      }
    }
    return isValid;
  }
}
