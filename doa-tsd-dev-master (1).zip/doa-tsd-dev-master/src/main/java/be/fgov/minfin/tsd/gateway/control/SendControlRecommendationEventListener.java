/*
 * @(#) be.fgov.minfin.tsd.gateway.control.SendControlRecommendationEventListener.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.control;

import static be.fgov.minfin.tsd.gateway.control.ControlGatewayConfig.CONCURRENCY_RECC_VALUE;
import static be.fgov.minfin.tsd.gateway.control.ControlGatewayConfig.CONTROL_RECC_QUEUE;

import be.fgov.minfin.libdoa.amqp.transactional.AbstractRetryingQueueListener;
import be.fgov.minfin.tsd.gateway.control.message.SendControlRecommendation;
import be.fgov.minfin.tsd.gateway.control.plugin.ControlGatewayPlugin;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

@Service
public class SendControlRecommendationEventListener extends AbstractRetryingQueueListener {

  static final String LISTENER_ID = "send-control-recommendation-request";

  private final ControlGatewayPlugin plugin;

  public SendControlRecommendationEventListener(
      ControlGatewayConfig controlGatewayConfig, ControlGatewayPlugin plugin) {
    super(controlGatewayConfig.getControlRecommendationQueue());
    this.plugin = plugin;
  }

  /** Receives message from queue for sending message for risk analysis */
  @RabbitListener(
      id = LISTENER_ID,
      queues = CONTROL_RECC_QUEUE,
      concurrency = CONCURRENCY_RECC_VALUE)
  public void processSendRecommendationRequest(
      @Payload SendControlRecommendation sendControlRecommendation, Message message) {
    plugin.sendControlRecommendation(sendControlRecommendation);
  }
}
