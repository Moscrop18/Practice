package be.fgov.minfin.tsd.domain.converter;

import be.fgov.minfin.tsd.domain.model.BusinessValidationType;
import javax.persistence.AttributeConverter;

public class BusinessValidationTypeConverter
    implements AttributeConverter<BusinessValidationType, String> {

  @Override
  public String convertToDatabaseColumn(BusinessValidationType type) {
    if (type != null) {
      return type.getValue();
    }
    return null;
  }

  @Override
  public BusinessValidationType convertToEntityAttribute(String dbData) {

    if (dbData == null) {
      return null;
    }
    for (BusinessValidationType nodeType : BusinessValidationType.values()) {
      if (nodeType.getValue().equals(dbData)) {
        return nodeType;
      }
    }
    throw new IllegalArgumentException("Unknown database value:" + dbData);
  }
}
