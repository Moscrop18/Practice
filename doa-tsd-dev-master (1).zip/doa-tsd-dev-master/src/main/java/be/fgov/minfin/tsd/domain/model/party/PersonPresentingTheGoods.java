/*
 * @(#) be.fgov.minfin.tsd.domain.model.party.PersonPresentingTheGoods
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model.party;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@Embeddable
public class PersonPresentingTheGoods {

  @Column(name = "PERSON_PRESENTING_GOODS_ID_NR")
  private String identificationNumber;

  @Column(name = "PERSON_PRESENTING_GOODS_NAME")
  private String name;
}
