/*
 * @(#) be.fgov.minfin.tsd.gateway.ga.GoodsAccountingGatewayConfig.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.ga;

import static be.fgov.minfin.tsd.config.RabbitConfig.ENABLE_QUORUM_QUEUE;
import static be.fgov.minfin.tsd.config.RabbitConfig.RABBIT_LISTENER_CONTAINER_FACTORY;

import be.fgov.minfin.libdoa.amqp.ExchangeConfig;
import be.fgov.minfin.libdoa.amqp.transactional.QueueConfig;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;

@Slf4j
@Setter
@Getter
@Validated
@Configuration("gaGatewayConfig")
public class GoodsAccountingGatewayConfig {

  public static final String OFFWRITABLE_DOCUMENT_QUEUE = "#{sendGaOffWritableQueue}";
  public static final String OFFWRITABLE_CONCURRENCY_SETTING =
      "#{gaGatewayConfig.sendGaOffWritableQueue.concurrentConsumers}";

  public static final String SEND_GA_OWD_TRANSFER_NOTIFICATION_QUEUE =
      "#{sendGaOWDTransferNotificationQueue}";
  public static final String SEND_GA_OWD_TRANSFER_NOTIFICATION_CONCURRENCY =
      "#{gaGatewayConfig.sendGaOWDTransferNotificationQueue.concurrentConsumers}";

  public static final String DECONSOLIDATE_OFFWRITABLE_DOCUMENT_QUEUE =
      "#{deconsolidateGaOffwritableQueue}";
  public static final String DECONSOLIDATE_OFFWRITABLE_CONCURRENCY_SETTING =
      "#{gaGatewayConfig.deconsolidateGaOffwritableQueue.concurrentConsumers}";

  private ExchangeConfig exchange;
  private ConfigurableBeanFactory beanFactory;

  private QueueConfig sendGaOffWritableQueue;
  private QueueConfig sendGaOWDTransferNotificationQueue;
  private QueueConfig deconsolidateGaOffwritableQueue;

  private RabbitTemplate rabbitTemplate;
  private boolean registerRetryQueueListener;
  private Integer maxAttempts;
  private Integer backOffDelay;

  public GoodsAccountingGatewayConfig(
      ConfigurableBeanFactory beanFactory, RabbitTemplate rabbitTemplate) {

    this.beanFactory = beanFactory;
    this.rabbitTemplate = rabbitTemplate;

    exchange = new ExchangeConfig("tsd.ga.gateway");

    sendGaOffWritableQueue =
        new QueueConfig(
            exchange,
            "tsd_out_ga_offwritable",
            "send.tsd.ga.offwritable",
            "sendGaOffWritableQueue",
            ENABLE_QUORUM_QUEUE);
    sendGaOWDTransferNotificationQueue =
        new QueueConfig(
            exchange,
            "tsd_out_ga_owd_transfer",
            "send.tsd.ga.owd.transfer",
            "sendGaOWDTransferNotificationQueue",
            ENABLE_QUORUM_QUEUE);
    deconsolidateGaOffwritableQueue =
        new QueueConfig(
            exchange,
            "tsd_out_ga_owd_deconsolidate",
            "send.tsd.ga.owd.deconsolidate",
            "deconsolidateGaOffwritableQueue",
            ENABLE_QUORUM_QUEUE);
  }

  public void init() {
    exchange.registerBeanDefinitions(beanFactory);
    if (registerRetryQueueListener) {
      sendGaOffWritableQueue.registerBeanDefinitions(
          beanFactory, RABBIT_LISTENER_CONTAINER_FACTORY, rabbitTemplate, false);
      sendGaOWDTransferNotificationQueue.registerBeanDefinitions(
          beanFactory, RABBIT_LISTENER_CONTAINER_FACTORY, rabbitTemplate, false);
      deconsolidateGaOffwritableQueue.registerBeanDefinitions(
          beanFactory, RABBIT_LISTENER_CONTAINER_FACTORY, rabbitTemplate, false);
    } else {
      log.warn("RetryRoutingListener is not enabled for GoodsAccountingGateway");
      sendGaOffWritableQueue.registerBeanDefinitions(beanFactory);
      sendGaOWDTransferNotificationQueue.registerBeanDefinitions(beanFactory);
      deconsolidateGaOffwritableQueue.registerBeanDefinitions(beanFactory);
    }
  }
}
