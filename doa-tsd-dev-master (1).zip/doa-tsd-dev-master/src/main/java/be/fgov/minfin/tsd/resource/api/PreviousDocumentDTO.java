/*
 * @(#)be.fgov.minfin.tsd.resource.api.PreviousDocumentDTO.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */

package be.fgov.minfin.tsd.resource.api;

import be.fgov.minfin.tsd.domain.validation.annotation.ValidateFormat;
import be.fgov.minfin.tsd.resource.validation.B2BOnly;
import be.fgov.minfin.tsd.resource.validation.UIOnly;
import com.fasterxml.jackson.annotation.JsonRootName;
import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.Builder;
import lombok.Value;

/** PreviousDocumentDTO */
@Builder(toBuilder = true)
@Value
@JsonRootName("previousDocument")
@ValidateFormat(groups = B2BOnly.class)
public class PreviousDocumentDTO {
  @NotNull(groups = B2BOnly.class)
  @Size(min = 0, max = 70)
  @Schema(example = "20BE00000889012AT4")
  private String referenceNumber;

  @NotNull(groups = B2BOnly.class)
  @Size(min = 4, max = 4, groups = B2BOnly.class)
  @Size(max = 4, groups = UIOnly.class)
  @Schema(example = "N355", description = "Previous Document Type (CL214)")
  private String type;

  @Digits(integer = 5, fraction = 0)
  @Schema(example = "123")
  private Integer goodsItemIdentifier;
}
