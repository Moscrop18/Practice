/*
 * @(#)be.fgov.minfin.tsd.domain.validation.codelist.PNCodeLists
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation.resolver;

import java.lang.annotation.ElementType;
import javax.validation.Path;
import javax.validation.Path.Node;
import javax.validation.TraversableResolver;
import org.hibernate.Hibernate;
import org.springframework.stereotype.Component;

/**
 * @author Resolver added to get validation on lazy loaded list elements after fetch
 */
@Component
public class CustomTraversableResolver implements TraversableResolver {

  @Override
  public boolean isReachable(
      Object traversableObject,
      Node traversableProperty,
      Class<?> rootBeanType,
      Path pathToTraversableObject,
      ElementType elementType) {

    return traversableObject == null || Hibernate.isInitialized(traversableObject);
  }

  @Override
  public boolean isCascadable(
      Object traversableObject,
      Node traversableProperty,
      Class<?> rootBeanType,
      Path pathToTraversableObject,
      ElementType elementType) {

    return true;
  }
}
