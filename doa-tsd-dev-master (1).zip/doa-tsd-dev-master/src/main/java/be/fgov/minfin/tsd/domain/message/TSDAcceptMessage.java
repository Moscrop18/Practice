/*
 * @(#)be.fgov.minfin.tsd.domain.message.TSDAcceptMessage.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.message;

import be.fgov.minfin.tsd.domain.model.BusinessValidationType;
import be.fgov.minfin.tsd.domain.model.TSDStatus;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Value;

@Value
@Builder(toBuilder = true)
public class TSDAcceptMessage {
  private MessageHeader messageHeader;
  private LocalDateTime notificationDate;
  private BusinessValidationType businessValidationType;
  private TSDStatus status;
  private String remarks;
  private LocalDateTime expirationDate;
  private TemporaryStorageDeclaration declaration;
}
