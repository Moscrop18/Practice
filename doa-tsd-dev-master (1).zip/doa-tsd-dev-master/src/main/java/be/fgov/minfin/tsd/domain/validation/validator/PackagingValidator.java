/* @(#) be.fgov.minfin.tsd.domain.validation.validator.PackagingValidator.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 */
package be.fgov.minfin.tsd.domain.validation.validator;

import be.fgov.minfin.libdoa.csrd2.gateway.ReferenceDataGateway;
import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentItem;
import be.fgov.minfin.tsd.domain.model.consignment.Packaging;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class PackagingValidator extends BaseConstraintValidator
    implements ConstraintValidator<ValidateBusinessRules, ConsignmentItem> {

  @Autowired private ReferenceDataGateway referenceDataGateway;
  public static final String PACKAGING = "Packaging";
  public static final String CONSIGNMENT_ITEM = "ConsignmentItem";

  @Override
  public boolean isValid(ConsignmentItem item, ConstraintValidatorContext context) {
    AtomicBoolean isValid = new AtomicBoolean(true);
    boolean validCL181andCL182Value = false;
    boolean notValidCL181andCL182Value = false;
    if (item != null && item.getPackaging() != null) {
      Integer index = 0;
      for (Packaging packaging : item.getPackaging()) {
        validatePackage(context, isValid, packaging, index);
        boolean isTypeOfPackageExistsInCL182andCL182 =
            typeOfPackageExists(packaging.getTypeOfPackages());
        if (isTypeOfPackageExistsInCL182andCL182) {
          validCL181andCL182Value = true;
        } else {
          notValidCL181andCL182Value = true;
        }
        index++;
      }
      validateConsignmentItemPackage(
          context, isValid, validCL181andCL182Value, notValidCL181andCL182Value);
    }
    return isValid.get();
  }

  private void validatePackage(
      ConstraintValidatorContext context,
      AtomicBoolean isValid,
      Packaging packaging,
      Integer index) {
    if (packaging.getShippingMarks() != null
        && typeOfPackageExists(packaging.getTypeOfPackages())) {
      addViolation(context, ErrorCode.TSPNESXXC0036, PACKAGING + "[" + index + "]");
      isValid.set(false);
    }
    if ((typeOfPackageExists(packaging.getTypeOfPackages())
            && packaging.getNumberOfPackages() != null)
        || (!typeOfPackageExists(packaging.getTypeOfPackages())
            && packaging.getNumberOfPackages() == null)) {
      addViolation(context, ErrorCode.TSPNESXXC0037, PACKAGING + "[" + index + "]");
      isValid.set(false);
    }
    if (!typeOfPackageExists(packaging.getTypeOfPackages())
        && packaging.getNumberOfPackages() != null
        && packaging.getNumberOfPackages() <= 0) {

      addViolation(
          context, ErrorCode.TSPNESXXR0038, PACKAGING + "[" + index + "]", "numberOfPackages");
      isValid.set(false);
    }
  }

  private void validateConsignmentItemPackage(
      ConstraintValidatorContext context,
      AtomicBoolean isValid,
      boolean validCL181andCL182Value,
      boolean notValidCL181andCL182Value) {
    if (validCL181andCL182Value && notValidCL181andCL182Value) {
      addViolation(context, ErrorCode.TSPNESXXR0151, PACKAGING);
      isValid.set(false);
    }
  }

  private boolean typeOfPackageExists(String packageString) {
    boolean isValidTypeOfPackage = false;
    if (referenceDataGateway.getKindOfPackagesBulk().contains(packageString)
        || referenceDataGateway.getKindOfPackagesUnpacked().contains(packageString)) {
      isValidTypeOfPackage = true;
    }

    return isValidTypeOfPackage;
  }
}
