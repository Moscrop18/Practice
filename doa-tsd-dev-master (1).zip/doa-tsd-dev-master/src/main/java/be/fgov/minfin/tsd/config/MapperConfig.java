/*
 * @(#)be.fgov.minfin.tsd.config.MapperConfig.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.config;

import be.fgov.minfin.tsd.shared.mapping.ReferenceDTOResolver;
import javax.persistence.EntityManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MapperConfig {
  @Bean
  public ReferenceDTOResolver entityResolver(EntityManager em) {
    return new ReferenceDTOResolver(em);
  }
}
