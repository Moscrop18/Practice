/*
 * @(#)be.fgov.minfin.tsd.gateway.eo.api.RequestedDocumentDTO.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.eo.api;

import com.fasterxml.jackson.annotation.JsonRootName;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.Builder;
import lombok.Value;

@Value
@Builder(toBuilder = true)
@JsonRootName("requestedDocument")
public class RequestedDocumentDTO {

  @NotNull
  @Size(min = 4, max = 4)
  // @Schema(example = "", description = "Role for the document type (CL215)")
  private String documentType;

  @Size(min = 1, max = 512)
  private String description;
}
