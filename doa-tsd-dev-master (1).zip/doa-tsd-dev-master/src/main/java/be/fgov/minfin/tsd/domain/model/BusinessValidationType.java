/*
 * @(#) be.fgov.minfin.tsd.domain.model.BusinessValidationType.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Enum for BusinessValidationType
 *
 * @author GauravMitra
 */
public enum BusinessValidationType {
  PRELODGED_TSD("015"),

  COMBINED_TSD("115"),

  TSD_TRANSFER_NOTIFICATION("207"),

  TSD_DECONSOLIDATION_NOTIFICATION("215"),

  TSD_AMENDMENT_REQUEST("413"),

  TSD_INVALIDATION_REQUEST("414");

  private final String value;

  BusinessValidationType(final String newValue) {
    value = newValue;
  }

  @JsonValue
  public String getValue() {
    return value;
  }
}
