package be.fgov.minfin.tsd.domain.model.consignment;

public interface HasPreviousDocument {
  PreviousDocument getPreviousDocument();
}
