/*
 * @(#)be.fgov.minfin.tsd.resource.api.CommodityCodeDTO.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */

package be.fgov.minfin.tsd.resource.api;

import be.fgov.minfin.tsd.resource.validation.B2BOnly;
import com.fasterxml.jackson.annotation.JsonRootName;
import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.Builder;
import lombok.Value;

/** CommodityCode */
@Value
@Builder(toBuilder = true)
@JsonRootName("commodityCode")
public class CommodityCodeDTO {
  @Size(min = 6, max = 6)
  @NotNull(groups = B2BOnly.class)
  @Schema(example = "291712", description = "Harmonized system sub heading code (CL706)")
  private String harmonizedSystemSubHeadingCode;

  @Size(min = 2, max = 2)
  @Schema(example = "00", description = "Combined nomenclature code (CL706)")
  private String combinedNomenclatureCode;
}
