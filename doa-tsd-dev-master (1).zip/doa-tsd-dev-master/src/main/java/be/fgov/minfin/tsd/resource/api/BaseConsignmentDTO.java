/*
 * @(#)be.fgov.minfin.tsd.resource.api.BaseConsignmentDTO.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */

package be.fgov.minfin.tsd.resource.api;

import be.fgov.minfin.tsd.shared.validation.annotation.BigDecimalPrecisionAndScale;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class BaseConsignmentDTO {
  @Valid private ReferenceNumberUCRDTO referenceNumberUCR;

  @BigDecimalPrecisionAndScale(precision = 16, scale = 6)
  @Schema(example = "333555999.888888")
  private BigDecimal totalGrossMass;

  @Valid private PartyDTO consignor;

  @Valid private PartyDTO consignee;

  @Valid private PartyDTO notifyParty;

  @NotNull @Valid private TransportDocumentDTO transportDocument;

  @Valid private PreviousDocumentDTO previousDocument;

  @JacksonXmlElementWrapper(useWrapping = false)
  @Size(max = 9999)
  private List<@Valid TransportEquipmentDTO> transportEquipment;

  @JacksonXmlElementWrapper(useWrapping = false)
  @Size(max = 99)
  private List<@Valid AdditionalInformationDTO> additionalInformation;

  @JacksonXmlElementWrapper(useWrapping = false)
  @Size(max = 99)
  private List<@Valid AdditionalSupplyChainActorDTO> additionalSupplyChainActor;

  @JacksonXmlElementWrapper(useWrapping = false)
  @Size(max = 99)
  private List<@Valid SupportingDocumentDTO> supportingDocument;
}
