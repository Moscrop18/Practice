/*
 * @(#)be.fgov.minfin.tsd.resource.api.ReferenceNumberUCRDTO.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */

package be.fgov.minfin.tsd.resource.api;

import com.fasterxml.jackson.annotation.JsonRootName;
import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** ReferenceNumberUCRDTO */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@JsonRootName("referenceNumberUCR")
public class ReferenceNumberUCRDTO {
  @NotNull
  @Size(min = 1, max = 35)
  @Schema(example = "REF123456789")
  private String referenceNumberUCR;
}
