/*
 * @(#) be.fgov.minfin.tsd.gateway.crs.CRSGateway
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.crs;

import be.fgov.minfin.libdoa.commons.lang.Now;
import be.fgov.minfin.shared.tracing.Traced;
import be.fgov.minfin.tsd.domain.model.consignment.AEOAuthorisation;
import be.fgov.minfin.tsd.domain.model.party.Communication;
import be.fgov.minfin.tsd.domain.model.party.Party;
import be.fgov.minfin.tsd.domain.model.party.PartyAddress;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import javax.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

/**
 * @author GauravMitra
 */
@Component
@RequiredArgsConstructor
public class CRSGateway {
  private Map<String, List<Communication>> communicationMap;
  private Map<String, PartyAddress> partyMap;
  private Map<String, List<AEOAuthorisation>> aeoCertificateMap;
  private Map<String, String> nameMap;

  public static final String EMAIL_CONTACT_NAME = "Email contact name";
  public static final String TELEPHONE_CONTACT_NAME = "Telephone contact name";
  public static final String ANTWERPEN = "ANTWERPEN";
  public static final String ZAVENTEM = "ZAVENTEM";
  public static final String BE0404754472 = "BE0404754472";
  public static final String BE0404778426 = "BE0404778426";
  public static final String BE0424188423 = "BE0424188423";
  public static final String BE0446536134 = "BE0446536134";
  public static final String BE0861301897 = "BE0861301897";
  public static final String BE0214596464 = "BE0214596464";
  public static final String BE0436501681 = "BE0436501681";
  public static final String BE0427599358 = "BE0427599358";
  public static final String BE0458858302 = "BE0458858302";
  public static final String BE0812191490 = "BE0812191490";
  public static final String BE0404529392 = "BE0404529392";
  public static final String BE0404531966 = "BE0404531966";
  public static final String BE0218843678 = "BE0218843678";
  public static final String BE0806153934 = "BE0806153934";
  public static final String BE0806155122 = "BE0806155122";
  public static final String BE0806154033 = "BE0806154033";

  @PostConstruct
  public void initData() {
    communicationMap = initCommunicationData();
    partyMap = initPartyAddressData();
    aeoCertificateMap = initAeoCertificateData();
    nameMap = initPartyName();
  }

  /**
   * @param party This is just mock implementation of CRS gateway.
   */
  @Traced
  public void getPartyInfo(Party party) {
    Optional<Party> partyOptional =
        getPartyInfo(
            party.getIdentificationNumber(),
            Now.localDateTime(),
            true,
            CollectionUtils.isEmpty(party.getCommunication()));
    if (partyOptional.isPresent()) {
      Party partyFromCRS = partyOptional.get();
      if (null == party.getName()) {
        party.setName(partyFromCRS.getName());
      }
      party.setAddress(partyFromCRS.getAddress());
      if (CollectionUtils.isNotEmpty(partyFromCRS.getCommunication())) {
        List<Communication> lstCommunication = new ArrayList<>();
        partyFromCRS
            .getCommunication()
            .forEach(
                c ->
                    lstCommunication.add(
                        Communication.builder()
                            .fullName(c.getFullName())
                            .identifier(c.getIdentifier())
                            .type(c.getType())
                            .party(party)
                            .build()));
        party.setCommunication(lstCommunication);
      }
    }
  }

  @Traced
  public Optional<Party> getPartyInfo(
      String identificationNumber,
      LocalDateTime dueDate,
      boolean isAddressReq,
      boolean isCommunicationReq) { // This is just a mock implementation
    if (partyMap.containsKey(identificationNumber)) {
      Party party = Party.builder().name(nameMap.get(identificationNumber)).build();
      if (isAddressReq) {
        party.setAddress(partyMap.get(identificationNumber));
      }
      if (isCommunicationReq) {

        party.setCommunication(communicationMap.get(identificationNumber));
      }
      return Optional.of(party);
    } else {
      return Optional.empty();
    }
  }

  private AEOAuthorisation getAuthorisation(String status, LocalDateTime endDate) {
    return AEOAuthorisation.builder().endDate(endDate).status(status).build();
  }

  @Traced
  public List<AEOAuthorisation> getAEOCertificate(String eoriNumber, LocalDateTime dueDate) {

    return aeoCertificateMap.get(eoriNumber);
  }

  private PartyAddress getAddress(
      String country, String city, String postCode, String streetandNumber) {
    return PartyAddress.builder()
        .country(country)
        .city(city)
        .postCode(postCode)
        .streetAndNumber(streetandNumber)
        .build();
  }

  private Communication getCommunication(String fullName, String identifier, String type) {

    return Communication.builder().fullName(fullName).identifier(identifier).type(type).build();
  }

  private Map<String, List<Communication>> initCommunicationData() {
    List<Communication> lstCommunicationEO6464 = new ArrayList<>();
    Map<String, List<Communication>> mapCommunicationData = new HashMap<>();
    lstCommunicationEO6464.add(getCommunication(EMAIL_CONTACT_NAME, "info@bpost.be", "EM"));
    lstCommunicationEO6464.add(getCommunication(TELEPHONE_CONTACT_NAME, "003222012345", "TE"));
    mapCommunicationData.put(BE0214596464, lstCommunicationEO6464);

    List<Communication> lstCommunicationEO1681 = new ArrayList<>();
    lstCommunicationEO1681.add(getCommunication(EMAIL_CONTACT_NAME, "info@ipc.be", "EM"));
    mapCommunicationData.put(BE0436501681, lstCommunicationEO1681);

    List<Communication> lstCommunicationEO9358 = new ArrayList<>();
    lstCommunicationEO9358.add(getCommunication(TELEPHONE_CONTACT_NAME, "003227216517", "TE"));
    mapCommunicationData.put(BE0427599358, lstCommunicationEO9358);

    List<Communication> lstCommunicationEO8302 = new ArrayList<>();
    lstCommunicationEO8302.add(getCommunication(TELEPHONE_CONTACT_NAME, "003242395000", "TE"));
    lstCommunicationEO8302.add(getCommunication(EMAIL_CONTACT_NAME, "infotntliege@tnt.com", "EM"));
    mapCommunicationData.put(BE0458858302, lstCommunicationEO8302);

    List<Communication> lstCommunicationEO1490 = new ArrayList<>();
    lstCommunicationEO1490.add(getCommunication(TELEPHONE_CONTACT_NAME, "003222521005", "TE"));
    mapCommunicationData.put(BE0812191490, lstCommunicationEO1490);

    List<Communication> lstCommunicationEO9392 = new ArrayList<>();
    lstCommunicationEO9392.add(getCommunication(TELEPHONE_CONTACT_NAME, "003227230311", "TE"));
    mapCommunicationData.put(BE0404529392, lstCommunicationEO9392);

    List<Communication> lstCommunicationEO1966 = new ArrayList<>();
    lstCommunicationEO1966.add(getCommunication(TELEPHONE_CONTACT_NAME, "003232206311", "TE"));
    lstCommunicationEO1966.add(
        getCommunication(EMAIL_CONTACT_NAME, "info.antwerpen@kuehne-nagel.com", "EM"));
    mapCommunicationData.put(BE0404531966, lstCommunicationEO1966);

    List<Communication> lstCommunicationEO3678 = new ArrayList<>();
    lstCommunicationEO3678.add(getCommunication(TELEPHONE_CONTACT_NAME, "003292510550", "TE"));
    mapCommunicationData.put(BE0218843678, lstCommunicationEO3678);

    List<Communication> lstCommunicationE4472 = new ArrayList<>();
    lstCommunicationE4472.add(getCommunication(TELEPHONE_CONTACT_NAME, "003235612111", "TE"));
    mapCommunicationData.put(BE0404754472, lstCommunicationE4472);

    List<Communication> lstCommunicationEO8423 = new ArrayList<>();
    lstCommunicationEO8423.add(getCommunication(TELEPHONE_CONTACT_NAME, "003227530202", "TE"));
    mapCommunicationData.put(BE0424188423, lstCommunicationEO8423);

    List<Communication> lstCommunicationEO6134 = new ArrayList<>();
    lstCommunicationEO6134.add(getCommunication(TELEPHONE_CONTACT_NAME, "003227529520", "TE"));
    mapCommunicationData.put(BE0446536134, lstCommunicationEO6134);

    List<Communication> lstCommunicationEO8426 = new ArrayList<>();
    lstCommunicationEO8426.add(getCommunication(TELEPHONE_CONTACT_NAME, "003232216811", "TE"));
    mapCommunicationData.put(BE0404778426, lstCommunicationEO8426);

    List<Communication> lstCommunicationEO1897 = new ArrayList<>();
    lstCommunicationEO1897.add(getCommunication(TELEPHONE_CONTACT_NAME, "003235604248", "TE"));
    mapCommunicationData.put(BE0861301897, lstCommunicationEO1897);

    List<Communication> lstCommunicationEO3934 = new ArrayList<>();
    lstCommunicationEO3934.add(getCommunication(EMAIL_CONTACT_NAME, "info@hdz.be", "EM"));
    mapCommunicationData.put(BE0806153934, lstCommunicationEO3934);

    List<Communication> lstCommunicationEO5122 = new ArrayList<>();
    lstCommunicationEO5122.add(getCommunication(TELEPHONE_CONTACT_NAME, "003251623841", "TE"));
    lstCommunicationEO5122.add(getCommunication(EMAIL_CONTACT_NAME, "info@m-level.be", "EM"));
    mapCommunicationData.put(BE0806155122, lstCommunicationEO5122);

    List<Communication> lstCommunicationEO4033 = new ArrayList<>();
    lstCommunicationEO4033.add(getCommunication(EMAIL_CONTACT_NAME, "info@barocy.be", "EM"));
    mapCommunicationData.put(BE0806154033, lstCommunicationEO4033);

    return mapCommunicationData;
  }

  private Map<String, PartyAddress> initPartyAddressData() {
    Map<String, PartyAddress> mapAddress = new HashMap<>();
    mapAddress.put(BE0214596464, getAddress("BE", "BRUSSEL", "1000", "MUNT"));
    mapAddress.put(BE0436501681, getAddress("BE", "BRUSSEL", "1130", "AVENUE DU BOURGET"));
    mapAddress.put(BE0427599358, getAddress("BE", ZAVENTEM, "1930", "LUCHTHAVEN LOODS 3"));
    mapAddress.put(BE0458858302, getAddress("BE", "GRACE-HOLLOGNE", "4460", "AEROPORT DE LIEGE"));
    mapAddress.put(BE0812191490, getAddress("BE", ZAVENTEM, "1931", "BRUCARGO 751"));
    mapAddress.put(BE0404529392, getAddress("BE", ZAVENTEM, "1930", " HEIDESTRAAT 34"));
    mapAddress.put(BE0404531966, getAddress("BE", ANTWERPEN, "2000", "FRANKRIJKLEI 115"));
    mapAddress.put(BE0218843678, getAddress("BE", "GENT", "9042", "JOHN KENNEDYLAAN 32"));
    mapAddress.put(BE0404754472, getAddress("BE", ANTWERPEN, "2040", "SCHELDELAAN 600"));
    mapAddress.put(BE0424188423, getAddress("BE", ZAVENTEM, "1931", "BRUCARGO BOUW 723"));
    mapAddress.put(BE0446536134, getAddress("BE", ZAVENTEM, "1931", "BRUCARGO BUILDING 751"));
    mapAddress.put(BE0404778426, getAddress("BE", ANTWERPEN, "2000", "VAN AERDTSTRAAT 33"));
    mapAddress.put(BE0861301897, getAddress("BE", " ANTWERPEN", "2000", "NAPELSSTRAAT 79"));
    mapAddress.put(BE0806153934, getAddress("BE", "GENT", "9050", "EDMOND VAN HOOREBEKESTRAAT 4"));
    mapAddress.put(BE0806155122, getAddress("BE", "RUISELEDEN", "8755", "KAPELLESTRAAT 13"));
    mapAddress.put(BE0806154033, getAddress("BE", "MERELBEKE", "9820", "FLORASTRAAT 30"));

    return mapAddress;
  }

  private Map<String, String> initPartyName() {
    Map<String, String> map = new HashMap<>();
    map.put(BE0214596464, "LA POSTE DIR GEN FIN C.SUC L1050");
    map.put(BE0436501681, "INTERNATIONAL POST CORPORATION");
    map.put(BE0427599358, "DHL AVIATION");
    map.put(BE0458858302, "TNT EXPRESS WORLDWIDE (EURO HUB)");
    map.put(BE0812191490, "FEDEX TRADE NETWORKS TRANSPORT");
    map.put(BE0404529392, "AVIAPARTNER BELGIUM");
    map.put(BE0404531966, "KUEHNE + NAGEL");
    map.put(BE0218843678, "HAVENBEDRIJF GENT");
    map.put(BE0404754472, "B A S F ANTWERPEN");
    map.put(BE0424188423, "NIPPON EXPRESS (BELGIUM)");
    map.put(BE0446536134, "ALL FREIGHT LOGISTICS");
    map.put(BE0404778426, "KATOEN NATIE");
    map.put(BE0861301897, "MSC HOME TERMINAL NV");
    map.put(BE0806153934, "HDZ");
    map.put(BE0806155122, "M-LEVEL");
    map.put(BE0806154033, "BAROCY");

    return map;
  }

  private Map<String, List<AEOAuthorisation>> initAeoCertificateData() {
    Map<String, List<AEOAuthorisation>> mapAeoCertificate = new HashMap<>();
    List<AEOAuthorisation> lstAeoAuth4472 = new ArrayList<>();
    lstAeoAuth4472.add(getAuthorisation("AEOF", null));
    mapAeoCertificate.put(BE0404754472, lstAeoAuth4472);

    List<AEOAuthorisation> lstAeoAuth8426 = new ArrayList<>();
    lstAeoAuth8426.add(getAuthorisation("AEOC", LocalDateTime.of(2050, Month.DECEMBER, 31, 0, 0)));
    lstAeoAuth8426.add(getAuthorisation("AEOS", LocalDateTime.of(2050, Month.DECEMBER, 31, 0, 0)));
    mapAeoCertificate.put(BE0404778426, lstAeoAuth8426);

    List<AEOAuthorisation> lstAeoAuth1897 = new ArrayList<>();
    lstAeoAuth1897.add(getAuthorisation("AEOC", LocalDateTime.of(2019, Month.DECEMBER, 31, 0, 0)));
    mapAeoCertificate.put(BE0861301897, lstAeoAuth1897);

    List<AEOAuthorisation> lstAeoAuth6134 = new ArrayList<>();
    lstAeoAuth6134.add(getAuthorisation("AEOS", null));
    mapAeoCertificate.put(BE0446536134, lstAeoAuth6134);

    List<AEOAuthorisation> lstAeoAuth5122 = new ArrayList<>();
    lstAeoAuth5122.add(getAuthorisation("AEOF", null));
    mapAeoCertificate.put(BE0806155122, lstAeoAuth5122);

    return mapAeoCertificate;
  }
}
