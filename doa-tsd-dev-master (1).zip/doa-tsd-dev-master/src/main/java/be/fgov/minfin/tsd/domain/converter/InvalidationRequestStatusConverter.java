/*
 * @(#)be.fgov.minfin.tsd.domain.converter.InvalidationRequestStatusConverter.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.converter;

import be.fgov.minfin.tsd.domain.model.InvalidationRequestStatus;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter(autoApply = true)
public class InvalidationRequestStatusConverter
    implements AttributeConverter<InvalidationRequestStatus, Integer> {

  @Override
  public Integer convertToDatabaseColumn(InvalidationRequestStatus type) {
    return type.getCode();
  }

  @Override
  public InvalidationRequestStatus convertToEntityAttribute(Integer dbData) {
    for (InvalidationRequestStatus nodeType : InvalidationRequestStatus.values()) {
      if (nodeType.getCode().equals(dbData)) {
        return nodeType;
      }
    }
    throw new IllegalArgumentException("Unknown database value:" + dbData);
  }
}
