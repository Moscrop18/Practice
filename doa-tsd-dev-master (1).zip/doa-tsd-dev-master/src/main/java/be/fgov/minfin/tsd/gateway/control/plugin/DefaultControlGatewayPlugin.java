/*
 * @(#) be.fgov.minfin.tsd.gateway.control.plugin.DefaultControlGatewayPlugin.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.control.plugin;

import static javax.ws.rs.core.Response.Status.ACCEPTED;

import be.fgov.minfin.control.client.TSDControlRestClient;
import be.fgov.minfin.control.client.api.SendControlRecommendationDTO;
import be.fgov.minfin.libdoa.exception.TechnicalException;
import be.fgov.minfin.tsd.gateway.control.message.SendControlInvalidationNotification;
import be.fgov.minfin.tsd.gateway.control.message.SendControlRecommendation;
import be.fgov.minfin.tsd.gateway.control.message.mapper.ControlMapper;
import javax.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
@ConditionalOnExpression(
    "#{T(java.util.Arrays).asList('${gateway.enabledDefaultPlugins}').contains('CONTROL')}")
public class DefaultControlGatewayPlugin implements ControlGatewayPlugin {

  private static final String AND_RESPONSE_BODY = "and response body ";

  private static final String FAILED_WITH_STATUS_CODE = "failed with status code ";

  private final TSDControlRestClient controlClient;

  private final ControlMapper mapper;

  public void sendTSDControlData(SendControlInvalidationNotification sendInvalidationNotification) {
    // message not called, done by Risk Analysis gateway
  }

  @Override
  public void sendControlRecommendation(SendControlRecommendation sendControlRecommendation) {
    SendControlRecommendationDTO sendControlRecommednationDTO =
        mapper.controlReccMap(sendControlRecommendation);
    log.info("Inside sendControlRecommendationRequest message {}", sendControlRecommednationDTO);
    Response response = controlClient.sendControlRecommendation(sendControlRecommednationDTO);

    if (response.getStatus() == ACCEPTED.getStatusCode()) {
      log.debug(
          "tsd control recommendation request submitted succesfully with functional Reference {}",
          sendControlRecommednationDTO.getFunctionalReference());
    } else {

      throw new TechnicalException(
          "sendControlRecommendationRequest '"
              + sendControlRecommednationDTO
              + FAILED_WITH_STATUS_CODE
              + response.getStatus()
              + AND_RESPONSE_BODY
              + response.readEntity(String.class));
    }
  }
}
