/*
 * @(#) be.fgov.minfin.tsd.gateway.risk.RiskAnalysisGateway.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.risk;

import static be.fgov.minfin.tsd.constant.MessageNameConstant.INVALIDATION_NOTIFICATION_TO_RISK_AND_CONTROL;
import static be.fgov.minfin.tsd.constant.MessageNameConstant.SEND_RISK_ANAYSIS_REQUEST;
import static be.fgov.minfin.tsd.util.DateFormatUtil.MESSAGE_DATE_TIME_FORMAT;
import static be.fgov.minfin.tsd.util.DateFormatUtil.MESSAGE_TIMESTAMP_FORMAT;

import be.fgov.minfin.libdoa.amqp.transactional.QueueSender;
import be.fgov.minfin.libdoa.commons.lang.Now;
import be.fgov.minfin.tsd.config.TSDConfig;
import be.fgov.minfin.tsd.domain.model.DeconsolidationNotification;
import be.fgov.minfin.tsd.domain.model.MessageExchange;
import be.fgov.minfin.tsd.domain.model.MessageInformation;
import be.fgov.minfin.tsd.domain.model.TSDStatus;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.risk.RiskAnalysisRequest;
import be.fgov.minfin.tsd.domain.repository.DeconsolidationNotificationRepository;
import be.fgov.minfin.tsd.domain.repository.MessageExchangeRepository;
import be.fgov.minfin.tsd.domain.repository.RiskAnalysisRequestRepository;
import be.fgov.minfin.tsd.domain.repository.StatusHistoryRepository;
import be.fgov.minfin.tsd.gateway.risk.message.CurrentRiskAnalysis;
import be.fgov.minfin.tsd.gateway.risk.message.DeconsolidationNotificationHeader;
import be.fgov.minfin.tsd.gateway.risk.message.MessageHeader;
import be.fgov.minfin.tsd.gateway.risk.message.PreviousRiskAnalysis;
import be.fgov.minfin.tsd.gateway.risk.message.RiskAnalysis;
import be.fgov.minfin.tsd.gateway.risk.message.SendInvalidationNotification;
import be.fgov.minfin.tsd.gateway.risk.message.SendTSDRiskAnalysis;
import be.fgov.minfin.tsd.gateway.risk.message.TimeOfCompletion;
import be.fgov.minfin.tsd.resource.generator.CorrelationIdGenerator;
import be.fgov.minfin.tsd.util.DateUtil;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

/**
 * This class is used as gateway component for integrating with the Risk Analysis systems.
 *
 * @author MohdSalim
 */
@Component
@RequiredArgsConstructor
public class RiskAnalysisGateway {

  private final DateUtil dateUtil;
  private final TSDConfig tsdConfig;
  private final QueueSender queueSender;
  private final RiskAnalysisGatewayConfig riskAnalysisGatewayConfig;
  private final CorrelationIdGenerator correlationIdGenerator;

  private final MessageExchangeRepository messageExchangeRepository;
  private final RiskAnalysisRequestRepository riskAnalysisRepository;
  private final DeconsolidationNotificationRepository deconsolidationNotificationRepository;
  private final StatusHistoryRepository statusHistoryRepository;

  public void sendTSDToRiskAnalysis(
      TemporaryStorageDeclaration tsd, boolean isAmendmentFlow, boolean isActivationFlow) {

    List<PreviousRiskAnalysis> previousRisks = null;

    if (isAmendmentFlow || isActivationFlow) {
      previousRisks = getPreviousRisks(tsd);
    }

    DeconsolidationNotification deconsolidationNotification = null;
    if (tsd.getReferenceNumber().getDeconsolidatedTSDId() != null) {
      Optional<DeconsolidationNotification> optDeconsolidationNotification =
          deconsolidationNotificationRepository.fetchDeconsolidationNotification(
              tsd.getReferenceNumber().getDeconsolidatedTSDId());

      if (optDeconsolidationNotification.isPresent()) {
        deconsolidationNotification = optDeconsolidationNotification.get();
      }
    }

    SendTSDRiskAnalysis riskAnalysisRequest =
        SendTSDRiskAnalysis.builder()
            .messageHeader(buildMessageHeader(tsd.getMessageInformation()))
            .messageFunction(buildMessageFunction(isAmendmentFlow, isActivationFlow))
            .functionalReference(tsd.getReferenceNumber().getCrn().getCrnNumber())
            .documentIssueDate(
                DateTimeFormatter.ofPattern(MESSAGE_DATE_TIME_FORMAT)
                    .format(Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime()))
            .previousRiskAnalysis(previousRisks)
            .riskAnalysis(
                buildCurrentRiskAnalysis(
                    tsd.getCurrentStatus() == TSDStatus.PRELODGED,
                    tsd.getRiskAnalysisRequest().get(tsd.getRiskAnalysisRequest().size() - 1)))
            .declaration(tsd)
            .deconsolidationNotificationHeader(
                buildDeconsolidationNotificationHeader(deconsolidationNotification))
            .build();
    saveMessageExchange(
        riskAnalysisRequest.getMessageHeader().getMessageId(), SEND_RISK_ANAYSIS_REQUEST, tsd);
    queueSender.publishMessage(
        riskAnalysisGatewayConfig.getSendRiskAnalysisQueue(), riskAnalysisRequest);
  }

  public void sendInvalidationNotification(TemporaryStorageDeclaration tsd) {
    List<PreviousRiskAnalysis> previousRisks = getPreviousRisksResults(tsd);
    String completionDate =
        statusHistoryRepository
            .findByStatusAndReferenceNumberId(
                TSDStatus.INVALIDATED, tsd.getReferenceNumber().getId())
            .get(0)
            .getTimestamp()
            .format(DateTimeFormatter.ofPattern(MESSAGE_DATE_TIME_FORMAT))
            .toString();
    SendInvalidationNotification sendInvalidationNotification =
        SendInvalidationNotification.builder()
            .messageHeader(buildMessageHeader(tsd.getMessageInformation()))
            .crn(tsd.getReferenceNumber().getCrn().getCrnNumber())
            .relatedRiskAnalysisRequest(previousRisks)
            .completionDate(completionDate)
            .build();
    saveMessageExchange(
        sendInvalidationNotification.getMessageHeader().getMessageId(),
        INVALIDATION_NOTIFICATION_TO_RISK_AND_CONTROL,
        tsd);
    queueSender.publishMessage(
        riskAnalysisGatewayConfig.getSendRiskInvalidationQueue(), sendInvalidationNotification);
  }

  private void saveMessageExchange(
      String messageId, String type, TemporaryStorageDeclaration declaration) {
    MessageExchange messageExchange =
        MessageExchange.builder()
            .messageId(messageId)
            .messageTimestamp(dateUtil.getCurentSystemDate())
            .messageType(type)
            .declaration(declaration)
            .build();
    messageExchangeRepository.save(messageExchange);
  }

  private CurrentRiskAnalysis buildCurrentRiskAnalysis(
      boolean isPrelodged, RiskAnalysisRequest currentRiskAnalysis) {

    return CurrentRiskAnalysis.builder()
        .riskAnalysisRequestReference(currentRiskAnalysis.getReference())
        .category(currentRiskAnalysis.getCategory())
        .riskAnalysisRequest(
            !isPrelodged
                ? RiskAnalysis.builder()
                    .timerForCompletion(
                        TimeOfCompletion.builder()
                            .dateAndTime(getDateAndTime(currentRiskAnalysis))
                            .type("RA")
                            .build())
                    .build()
                : null)
        .build();
  }

  private String getDateAndTime(RiskAnalysisRequest currentRiskAnalysis) {
    if (currentRiskAnalysis.getExpirationTimestamp() != null)
      return currentRiskAnalysis
          .getExpirationTimestamp()
          .atOffset(ZoneOffset.UTC)
          .toLocalDateTime()
          .format(DateTimeFormatter.ofPattern(MESSAGE_DATE_TIME_FORMAT));
    return null;
  }

  private List<PreviousRiskAnalysis> buildPreviousRiskRequests(
      List<RiskAnalysisRequest> sortedRiskAnalysisList) {

    List<PreviousRiskAnalysis> previousRisks = new ArrayList<>();

    // only populate previous RiskAnalyisRequest, hence size() - 1
    IntStream.range(0, sortedRiskAnalysisList.size() - 1)
        .forEach(
            raIndex -> {
              RiskAnalysisRequest ra = sortedRiskAnalysisList.get(raIndex);
              PreviousRiskAnalysis previousRiskAnalysis =
                  PreviousRiskAnalysis.builder()
                      .riskAnalysisRequestReference(ra.getReference())
                      .riskAssessmentType("RA")
                      .category(ra.getCategory())
                      .build();
              previousRisks.add(previousRiskAnalysis);
            });
    return previousRisks;
  }

  private Integer buildMessageFunction(boolean isAmendmentFlow, boolean isActivationFlow) {
    if (isAmendmentFlow && !isActivationFlow) {
      return Integer.valueOf(18);
    } else if (isActivationFlow && !isAmendmentFlow) {
      return Integer.valueOf(4);
    } else {
      return Integer.valueOf(9);
    }
  }

  private MessageHeader buildMessageHeader(MessageInformation message) {
    return MessageHeader.builder()
        .sender(tsdConfig.getTsdSystemName())
        .recipient(tsdConfig.getRaiSystemName())
        .messageTimestamp(
            DateTimeFormatter.ofPattern(MESSAGE_TIMESTAMP_FORMAT)
                .format(Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime()))
        .messageId(correlationIdGenerator.generateCorrelationID())
        .correlationId(null != message ? message.getCorrelationID() : null)
        .build();
  }

  private List<PreviousRiskAnalysis> getPreviousRisks(TemporaryStorageDeclaration tsd) {
    List<RiskAnalysisRequest> sortedRiskAnalysisList = null;
    List<PreviousRiskAnalysis> previousRisks = null;
    List<RiskAnalysisRequest> previousRiskRequests =
        riskAnalysisRepository.findByReferenceContaining(
            tsd.getReferenceNumber().getCrn().getCrnNumber());

    if (!CollectionUtils.isEmpty(previousRiskRequests)) {
      sortedRiskAnalysisList =
          previousRiskRequests.stream()
              .sorted(Comparator.comparing(RiskAnalysisRequest::getTimestamp))
              .collect(Collectors.toList());
      previousRisks = buildPreviousRiskRequests(sortedRiskAnalysisList);
    }
    return previousRisks;
  }

  private List<PreviousRiskAnalysis> getPreviousRisksResults(TemporaryStorageDeclaration tsd) {
    List<RiskAnalysisRequest> sortedRiskAnalysisList = null;
    List<PreviousRiskAnalysis> previousRisks = null;
    List<RiskAnalysisRequest> previousRiskRequests =
        riskAnalysisRepository.findByReferenceContaining(
            tsd.getReferenceNumber().getCrn().getCrnNumber());

    if (!CollectionUtils.isEmpty(previousRiskRequests)) {
      sortedRiskAnalysisList =
          previousRiskRequests.stream()
              .sorted(Comparator.comparing(RiskAnalysisRequest::getTimestamp))
              .collect(Collectors.toList());
      previousRisks = buildPreviousRiskResultsRequests(sortedRiskAnalysisList);
    }
    return previousRisks;
  }

  private List<PreviousRiskAnalysis> buildPreviousRiskResultsRequests(
      List<RiskAnalysisRequest> sortedRiskAnalysisList) {

    List<PreviousRiskAnalysis> previousRisks = new ArrayList<>();

    for (RiskAnalysisRequest ra : sortedRiskAnalysisList) {
      PreviousRiskAnalysis previousRiskAnalysis =
          PreviousRiskAnalysis.builder()
              .riskAnalysisRequestReference(ra.getReference())
              .riskAssessmentType("RA")
              .category(ra.getCategory())
              .build();
      previousRisks.add(previousRiskAnalysis);
    }
    return previousRisks;
  }

  private DeconsolidationNotificationHeader buildDeconsolidationNotificationHeader(
      DeconsolidationNotification deconsolidationNotification) {

    if (deconsolidationNotification == null) {
      return null;
    }

    return DeconsolidationNotificationHeader.builder()
        .lrn(deconsolidationNotification.getLrn())
        .registrationDate(
            DateTimeFormatter.ofPattern(MESSAGE_DATE_TIME_FORMAT)
                .format(deconsolidationNotification.getRegistrationDate()))
        .declarant(deconsolidationNotification.getDeclarant())
        .representative(deconsolidationNotification.getRepresentative())
        .build();
  }
}
