/*
 * @(#)be.fgov.minfin.tsd.event.api.api.PNReceivedEvent.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.eo.api;

import be.fgov.minfin.eogw.client.api.EONotificationRequestDTO;
import be.fgov.minfin.libdoa.amqp.BaseEvent;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Value;

/**
 * This Class wraps EONotification message. Additional
 *
 * @author ArunJewaria
 */
@Value
@Builder
public class EONotificationEvent extends BaseEvent {
  private EONotificationRequestDTO eoNotificationDTO;
  private LocalDateTime businessDecisionTime;
  private String messageType;
}
