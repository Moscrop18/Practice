/*
 * @(#) be.fgov.minfin.tsd.domain.validation.validator.TSDDeconsolidationNotificationValidator.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties
 * or made public without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation.validator;

import be.fgov.minfin.tsd.domain.model.DeconsolidationNotification;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.springframework.beans.factory.annotation.Autowired;

public class TSDDeconsolidationNotificationValidator extends BaseConstraintValidator
    implements ConstraintValidator<ValidateBusinessRules, DeconsolidationNotification> {

  @Autowired private PartyValidator partyValidator;

  @Override
  public boolean isValid(
      DeconsolidationNotification deconsolidationNotification, ConstraintValidatorContext context) {

    AtomicBoolean hasError = new AtomicBoolean(false);

    partyValidator.validateDeclarantIdentificationNumber(
        deconsolidationNotification.getDeclarant(), hasError, context);
    partyValidator.validateRepresentativeIdentificationNumber(
        deconsolidationNotification.getRepresentative(), hasError, context);
    partyValidator.validateSameEoriNumber(
        deconsolidationNotification.getDeclarant(),
        deconsolidationNotification.getRepresentative(),
        hasError,
        context);
    return !hasError.get();
  }
}
