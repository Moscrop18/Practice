/*
 * @(#) be.fgov.minfin.tsd.domain.validation.validator.ReceiveControlResultValidator.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation.validator;

import be.fgov.minfin.tsd.domain.model.ReceiveControlResult;
import be.fgov.minfin.tsd.domain.model.risk.ControlRecommendation;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.apache.commons.collections4.CollectionUtils;

public class ReceiveControlResultValidator extends BaseConstraintValidator
    implements ConstraintValidator<ValidateBusinessRules, ReceiveControlResult> {

  public static final String CONTROL_RESULTS = "controlResults";
  public static final String CONTROL_DECISION = "controlDecision.reasonCode";

  @Override
  public boolean isValid(ReceiveControlResult controlResult, ConstraintValidatorContext context) {

    AtomicBoolean isValid = new AtomicBoolean(true);
    validateControlDecision(controlResult, isValid, context);
    validateUniqueControlRecommendationReference(controlResult, isValid, context);
    return isValid.get();
  }

  private void validateControlDecision(
      ReceiveControlResult controlResult,
      AtomicBoolean isValid,
      ConstraintValidatorContext context) {

    if (null != controlResult.getControlDecision()) {
      if ((controlResult.getControlDecision().getControlDecision().equals("1")
              && CollectionUtils.isEmpty(controlResult.getControlRecommendations()))
          || (!controlResult.getControlDecision().getControlDecision().equals("1")
              && CollectionUtils.isNotEmpty(controlResult.getControlRecommendations()))) {
        addViolation(context, ErrorCode.TSPNESXXC0448, CONTROL_RESULTS);
        isValid.set(false);
      }

      if (controlResult.getControlDecision().getControlDecision().equals("0")
          && null == controlResult.getControlDecision().getReasonCode()) {
        addViolation(context, ErrorCode.TSPNESXXC0447, CONTROL_DECISION);
        isValid.set(false);
      }
    }
  }

  private void validateUniqueControlRecommendationReference(
      ReceiveControlResult controlResult,
      AtomicBoolean isValid,
      ConstraintValidatorContext context) {
    List<String> requestControlRecommReferences = new ArrayList<>();
    if (CollectionUtils.isNotEmpty(controlResult.getControlRecommendations())) {
      for (ControlRecommendation reference : controlResult.getControlRecommendations()) {
        requestControlRecommReferences.add(reference.getFunctionalReference());
      }

      List<String> uniqueReferences =
          requestControlRecommReferences.stream().distinct().collect(Collectors.toList());

      if (requestControlRecommReferences.size() != uniqueReferences.size()) {
        addViolation(context, ErrorCode.TSPNESXXR0456, CONTROL_RESULTS);
        isValid.set(false);
      }
    }
  }
}
