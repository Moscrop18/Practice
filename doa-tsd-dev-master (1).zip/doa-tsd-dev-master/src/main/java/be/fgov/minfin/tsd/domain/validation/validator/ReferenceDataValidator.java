/*
 * @(#) be.fgov.minfin.tsd.domain.validation.validator.ReferenceDataValidator.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation.validator;

import be.fgov.minfin.libdoa.csrd2.gateway.ReferenceDataGateway;
import be.fgov.minfin.tsd.domain.model.CustomsOffice;
import be.fgov.minfin.tsd.domain.model.consignment.CommodityCode;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import be.fgov.minfin.tsd.domain.validation.codelist.TSDCodeLists;
import java.util.Collections;
import java.util.Set;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * This is generic Validator to validate different code list
 *
 * @author GauravMitra
 */
@Component
@RequiredArgsConstructor
public class ReferenceDataValidator extends BaseConstraintValidator
    implements ConstraintValidator<
        be.fgov.minfin.tsd.domain.validation.annotation.CodeList, Object> {

  private volatile String codeListType;
  private Enum<ErrorCode> errorCode;

  private final ReferenceDataGateway referenceDataGateway;

  @Override
  public void initialize(be.fgov.minfin.tsd.domain.validation.annotation.CodeList validCodeList) {
    codeListType = validCodeList.value().name();
    errorCode = validCodeList.errorCode();
  }
  /*
   * (non-Javadoc)
   *
   * @see javax.validation.ConstraintValidator#isValid(java.lang.Object,
   * javax.validation.ConstraintValidatorContext)
   */
  @Override
  public boolean isValid(Object value, ConstraintValidatorContext context) {
    boolean isValid = true;
    String appendNode = null;
    if (value instanceof CommodityCode) {
      CommodityCode code = (CommodityCode) value;
      value = code.getHarmonizedSystemSubHeadingCode() + code.getCombinedNomenclatureCode();
    }
    if (value instanceof CustomsOffice) {
      CustomsOffice customsOffice = (CustomsOffice) value;
      value = customsOffice.getReferenceNumber();
      appendNode = "referenceNumber";
    }
    TSDCodeLists codeList = TSDCodeLists.valueOf(codeListType);
    Set<String> referenceDataList = getReferenceDataValues(codeListType);
    if (null != value) {
      isValid = referenceDataList.contains(value.toString());
    }
    if (!isValid) {
      errorCode = errorCode == ErrorCode.DEFAULTERRORCODE ? codeList.getErrorCode() : errorCode;
      addViolation(context, errorCode, appendNode);
    }
    return isValid;
  }

  public Set<String> getReferenceDataValues(String codeList) {

    switch (TSDCodeLists.valueOf(codeList)) {
      case CL099:
        return referenceDataGateway.getWarehouseTypes();
      case CL718:
        return referenceDataGateway.getCountry();
      case CL213:
        return referenceDataGateway.getSupportingDocumentType();
      case CL016:
        return referenceDataGateway.getCusCodes();
      case CL027:
        return referenceDataGateway.getFlag();
      case CL094:
        return referenceDataGateway.getRepresentativeStatusCodes();
      case CL141:
        return referenceDataGateway.getCustomsOffices();
      case CL144:
        return referenceDataGateway.getUnLocationCodes();
      case CL380:
        return referenceDataGateway.getAdditionalReferences();
      case CL701:
        return referenceDataGateway.getAdditionalInformationCodes();
      case CL706:
        return referenceDataGateway.getCommodityCode();
      case CL707:
        return referenceDataGateway.getCommunicationMeansTypes();
      case CL709:
        return referenceDataGateway.getContainerPackedStatuses();
      case CL729:
        return referenceDataGateway.getPartyIdentifierTypes();
      case CL347:
        return referenceDataGateway.getTypesOfLocations();
      case CL326:
        return referenceDataGateway.getQualifiersOfIdentification();
      case CL750:
        return referenceDataGateway.getTypesOfIdentificationOfMeansOfTransport();
      case CL017:
        return referenceDataGateway.getKindOfPackages();
      case CL754:
        return referenceDataGateway.getTransportDocumentTypes();

      case CL704:
        return referenceDataGateway.getAdditionalSupplyChainActorRoleCodes();

      case CL214:
        return referenceDataGateway.getPreviousDocumentType();

      case CL736:
        return referenceDataGateway.getRiskAnalysisCategory();
      case CL758:
        return referenceDataGateway.getRiskLevel();
      case CL737:
        return referenceDataGateway.getRiskAnalysisResult();
      case CL739:
        return referenceDataGateway.getRiskAnalysisType();
      case CL215:
        return referenceDataGateway.getRequestedDocumentType();
      case CL740:
        return referenceDataGateway.getRiskAreaCode();
      case CL716:
        return referenceDataGateway.getControlType();
      case CL712:
        return referenceDataGateway.getControlDecision();
      case CL713:
        return referenceDataGateway.getControlDecisionReasonCode();
      case CL714:
        return referenceDataGateway.getControlResultCode();
      case CL715:
        return referenceDataGateway.getControlTrigger();

      default:
        return Collections.emptySet();
    }
  }
}
