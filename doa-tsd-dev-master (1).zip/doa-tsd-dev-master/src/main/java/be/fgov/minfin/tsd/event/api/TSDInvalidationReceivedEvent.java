/*
 * @(#)be.fgov.minfin.tsd.event.api.TSDInvalidationReceivedEvent.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.event.api;

import be.fgov.minfin.libdoa.amqp.BaseEvent;
import be.fgov.minfin.tsd.domain.model.InvalidationRequest;
import lombok.Builder;
import lombok.Value;

/**
 * This class wraps TSD Invalidation Message
 *
 * @author MohdSalim
 */
@Value
@Builder
public class TSDInvalidationReceivedEvent extends BaseEvent {
  private String crn;
  private InvalidationRequest invalidationRequest;
}
