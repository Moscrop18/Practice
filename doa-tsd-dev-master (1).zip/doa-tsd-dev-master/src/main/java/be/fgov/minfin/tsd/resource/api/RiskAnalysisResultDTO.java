/*
 * @(#)be.fgov.minfin.tsd.resource.api.RiskAnalysisResultDTO.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.resource.api;

import static be.fgov.minfin.tsd.util.DateFormatUtil.MESSAGE_DATE_TIME_FORMAT;

import be.fgov.minfin.tsd.domain.validation.annotation.Timestamp;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.Builder;
import lombok.Value;

@Value
@Builder(toBuilder = true)
@JsonRootName("riskAnalysisResult")
public class RiskAnalysisResultDTO {

  @NotNull
  @Size(min = 1, max = 1)
  private String riskAnalysisType;

  @Size(min = 1, max = 17)
  private String riskAreaCode;

  @Size(min = 1, max = 3)
  private String riskLevel;

  @Size(min = 1, max = 17)
  private String riskCriteriaIdentifier;

  @Digits(integer = 1, fraction = 0)
  private Integer resultCode;

  @Size(min = 1, max = 512)
  private String resultText;

  @Schema(example = "2020-06-01T18:44:22Z")
  @Timestamp(formatter = MESSAGE_DATE_TIME_FORMAT)
  private String dateAndTimeOfCompletion;

  @JacksonXmlElementWrapper(useWrapping = false)
  @Size(max = 9)
  private List<@Valid PointerDTO> pointer;
}
