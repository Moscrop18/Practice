/*
 * @(#)be.fgov.minfin.tsd.domain.model.consignment.Carrier
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model.consignment;

import be.fgov.minfin.tsd.domain.validation.annotation.group.NonDraftTSD;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Embeddable
public class Carrier {

  @Column(name = "CARRIER_ID_NUM")
  @NotNull(groups = NonDraftTSD.class)
  private String identificationNumber;

  @Column(name = "CARRIER_NAME")
  @NotNull(groups = NonDraftTSD.class)
  private String name;
}
