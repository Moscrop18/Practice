/*
 * @(#)be.fgov.minfin.tsd.domain.validation.codelist.PNCodeLists
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation.codelist;

import lombok.Getter;

/**
 * List For PNL Codes
 *
 * @author GauravMitra
 */
@Getter
public enum TSDCodeLists {
  TSD01(null),

  /** This CodeList is to validate Warehouse Type */
  CL099(ErrorCode.TSPNESXXC0087),

  /** This CodeList is to validate Country */
  CL718(ErrorCode.TSPNESXXC0089),

  /** This CodeList is to validate Customs office reference number */
  CL141(ErrorCode.TSPNESXXC0020),

  /** This CodeList is to validate Supporting Document type */
  CL213(ErrorCode.TSPNESXXC0094),

  /** This CodeList is to validate UNLOCODE */
  CL144(ErrorCode.TSPNESXXC0029),

  /** This CodeList is to validate Additional reference type */
  CL380(ErrorCode.TSPNESXXC0093),

  /** This CodeList is to validate Type of identification of means of transport */
  CL750(ErrorCode.TSPNESXXC0086),

  /** This CodeList is to validate Commodity CUS code */
  CL016(ErrorCode.TSPNESXXC0092),

  /** This CodeList is to validate Commodity code */
  CL706(ErrorCode.TSPNESXXC0091),

  /** This CodeList is to validate Flag ENS re-use indicator */
  CL027(ErrorCode.TSPNESXXC0085),

  /** This CodeList is to validate ADDITIONAL INFORMATION/Code */
  CL701(ErrorCode.TSPNESXXC0088),

  /** This CodeList is to validate TRANSPORT EQUIPMENT/Container packed status */
  CL709(ErrorCode.TSPNESXXC0090),

  /** This CodeList is to validate COMMUNICATION/Type */
  CL707(ErrorCode.TSPNESXXC0075),

  /** This CodeList is to validate REPRESENTATIVE/Status */
  CL094(ErrorCode.TSPNESXXC0076),

  /** This CodeList is to validate Type of person */
  CL729(ErrorCode.TSPNESXXC0084),

  /** This CodeList is to validate Type of Location */
  CL347(ErrorCode.TSPNESXXC0079),

  /** This CodeList is to validate Qualifier of Identification */
  CL326(ErrorCode.TSPNESXXC0080),

  /** This CodeList is to validate Packaging/Types of packages */
  CL017(ErrorCode.TSPNESXXC0082),

  /** This CodeList is to validate TRANSPORT DOCUMENT/Type */
  CL754(ErrorCode.TSPNESXXC0077),

  /** This CodeList is to validate AdditionalSupplyChainActor/role */
  CL704(ErrorCode.TSPNESXXC0083),

  /** This CodeList is to validate PREVIOUS DOCUMENT/Type */
  CL214(ErrorCode.TSPNESXXC0078),

  /** This CodeList is to validate category */
  CL736(ErrorCode.TSPNESXXC0410),

  /** This code is to validate Risk analysis result / Risk analysis Type */
  CL739(ErrorCode.TSPNESXXC0411),

  /** This Code is to validate Risk analysis result / Risk area */
  CL740(ErrorCode.TSPNESXXC0412),

  /** This Code is to validate Risk analysis result / Risk level */
  CL758(ErrorCode.TSPNESXXC0413),

  /** This Code is to validate Risk analysis result / Risk code */
  CL737(ErrorCode.TSPNESXXC0414),

  /** This Code is to validate Request document/ Document type */
  CL215(ErrorCode.TSPNESXXC0451),

  /** This Code is to validate Types of controls/type */
  CL716(ErrorCode.TSPNESXXC0418),

  /** This code is validate control decision/control decision */
  CL712(ErrorCode.TSPNESXXC0440),

  /** This code is validate control decision/ reason code */
  CL713(ErrorCode.TSPNESXXC0441),

  /** This code is validate control results / control result /code */
  CL714(ErrorCode.TSPNESXXC0442),

  /** This code is validate control decision/control trigger /control trigger */
  CL715(ErrorCode.TSPNESXXC0443);

  private Enum<ErrorCode> errorCode;

  private TSDCodeLists(Enum<ErrorCode> errorCode) {
    this.errorCode = errorCode;
  }
}
