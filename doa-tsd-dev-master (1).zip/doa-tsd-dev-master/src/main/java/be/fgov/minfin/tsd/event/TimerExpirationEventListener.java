/*
 * @(#)be.fgov.minfin.tsd.event.TimerExpirationEventListener.java
 * =========================================================================== This source code is
 * exclusive propriety of the SPF Finances. In no case are the contents allowed to be distributed to
 * third parties or made public without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.event;

import static be.fgov.minfin.tsd.domain.model.TimerType.RISK_ANALYSIS_RESULT;
import static be.fgov.minfin.tsd.domain.model.TimerType.TSD_DRAFT_EXPIRATION;
import static be.fgov.minfin.tsd.domain.model.TimerType.TSD_EXPIRATION;
import static be.fgov.minfin.tsd.event.TSDEventConfig.TSD_TIMER_EXPIRATION_CONCURRENCY;
import static be.fgov.minfin.tsd.event.TSDEventConfig.TSD_TIMER_EXPIRATION_QUEUE;

import be.fgov.minfin.libdoa.amqp.transactional.AbstractRetryingQueueListener;
import be.fgov.minfin.tsd.domain.service.TSDService;
import be.fgov.minfin.tsd.event.api.TSDTimerExpirationEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * event listener for expired timers
 *
 * @author MohdSalim
 */
@Slf4j
@Component
@Transactional
public class TimerExpirationEventListener extends AbstractRetryingQueueListener {
  public static final String LISTENER_ID = "processTSDTimerExpiration";
  private TSDService tsdService;

  public TimerExpirationEventListener(TSDEventConfig config, TSDService tsdService) {
    super(config.getTsdTimerExpirationQueue());
    this.tsdService = tsdService;
  }

  @RabbitListener(
      id = LISTENER_ID,
      queues = TSD_TIMER_EXPIRATION_QUEUE,
      concurrency = TSD_TIMER_EXPIRATION_CONCURRENCY)
  public void processTSDTimerExpirationEvent(
      @Payload TSDTimerExpirationEvent event, Message message) {
    log.info("Message Received on Listener with following Timer {}", event.getExpiredTimer());
    if (event.getExpiredTimer().getType() == TSD_EXPIRATION) {
      tsdService.invalidateDeclaration(event.getExpiredTimer());
    } else if (event.getExpiredTimer().getType() == TSD_DRAFT_EXPIRATION) {
      tsdService.deleteDraftDeclaration(event.getExpiredTimer());
    } else if (event.getExpiredTimer().getType() == RISK_ANALYSIS_RESULT) {
      tsdService.processExpiredRiskAnalysisResultTimer(event.getExpiredTimer());
    } else {
      log.error("unsupported timer type ... {}", event.getExpiredTimer().getType());
    }
  }
}
