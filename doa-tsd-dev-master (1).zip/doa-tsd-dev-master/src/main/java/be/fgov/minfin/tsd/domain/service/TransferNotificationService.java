/*
 * @(#) be.fgov.minfin.tsd.domain.service.TransferNotificationService.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties
 * or made public without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.service;

import static be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclarationType.COMBINED;
import static be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclarationType.PRELODGED;
import static be.fgov.minfin.tsd.domain.model.TimerType.RISK_ANALYSIS_RESULT;
import static be.fgov.minfin.tsd.domain.model.TimerType.TSD_DRAFT_EXPIRATION;
import static be.fgov.minfin.tsd.domain.model.TimerType.TSD_EXPIRATION;

import be.fgov.minfin.libdoa.commons.lang.Now;
import be.fgov.minfin.libdoa.goods.accounting.client.api.owd.LockOffwritableDocumentStatusReason;
import be.fgov.minfin.tsd.config.TSDConfig;
import be.fgov.minfin.tsd.domain.mapper.TSDDomainMapper;
import be.fgov.minfin.tsd.domain.message.Error;
import be.fgov.minfin.tsd.domain.model.MRN;
import be.fgov.minfin.tsd.domain.model.TSDStatus;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.TimerType;
import be.fgov.minfin.tsd.domain.model.TransferNotification;
import be.fgov.minfin.tsd.domain.model.party.Party;
import be.fgov.minfin.tsd.domain.model.risk.RiskAndControlStatus;
import be.fgov.minfin.tsd.domain.repository.TSDRepository;
import be.fgov.minfin.tsd.domain.sender.TSDResponseSender;
import be.fgov.minfin.tsd.domain.validation.message.MessageType;
import be.fgov.minfin.tsd.domain.validation.plugin.TransferNotificationValidatorPlugin;
import be.fgov.minfin.tsd.event.TSDEventBroker;
import be.fgov.minfin.tsd.event.api.TSDTransferNotificationReceivedEvent;
import be.fgov.minfin.tsd.gateway.ga.GoodsAccountingGateway;
import be.fgov.minfin.tsd.gateway.risk.RiskAnalysisGateway;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import javax.validation.ConstraintViolation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class TransferNotificationService {

  private final TSDEventBroker tsdEventBroker;

  private final TransferNotificationValidatorPlugin transferNotificationValidatorPlugin;

  private final TSDRepository tsdRepository;

  private final PartyDetailsLoader partyLoader;

  private final TSDConfig tsdConfig;

  private final TSDResponseSender tsdResponseSender;

  private final TSDTimerService timerService;

  private final TSDDomainMapper tsdDomainMapper;

  private final RiskAnalysisGateway riskAnalysisGateway;

  private final GoodsAccountingGateway gaGateway;
  /**
   * This method will send TransferNotification event to Queue
   *
   * @param mrn
   * @param transferNotification
   */
  public void receiveTransferNotification(String mrn, TransferNotification transferNotification) {
    TSDTransferNotificationReceivedEvent tsdTransferNotificationReceivedEvent =
        TSDTransferNotificationReceivedEvent.builder()
            .mrn(mrn)
            .transferNotification(transferNotification)
            .build();
    tsdEventBroker.publishTransferNotificationReceivedEvent(tsdTransferNotificationReceivedEvent);
  }

  public void processTransferNotification(String mrn, TransferNotification transferNotification) {

    log.info("TransferNotification received in TransferNotificationService with mrn {}", mrn);

    Optional<TemporaryStorageDeclaration> optionalTSD =
        tsdRepository.findCurrentVersion(MRN.of(mrn));

    TemporaryStorageDeclaration currentTSD = optionalTSD.isPresent() ? optionalTSD.get() : null;

    Set<ConstraintViolation<TransferNotification>> violations =
        transferNotificationValidatorPlugin.validateTransferNotificationCanBeProcessed(
            transferNotification, currentTSD);

    if (!violations.isEmpty()) {
      List<Error> errors =
          tsdResponseSender.buildErrors(
              violations,
              transferNotification.getMessageInformation().getLanguageCode(),
              false,
              false);

      if (canRegisterMessageExchange(errors)) {
        tsdResponseSender.sendTransferNotificationRefusedMessage(
            mrn, transferNotification, errors, currentTSD);
      } else {
        tsdResponseSender.sendTransferNotificationRefusedMessage(
            mrn, transferNotification, errors, null);
      }

      return;
    }

    loadDeclarantAndRepresentativeDetails(transferNotification);
    prefillName(transferNotification);

    violations =
        transferNotificationValidatorPlugin.validateTransferNotification(
            transferNotification, MessageType.TRANSFER_NOTIFICATION_MESSAGE, currentTSD);

    List<Error> errors = null;

    if (!violations.isEmpty()) {
      errors =
          tsdResponseSender.buildErrors(
              violations,
              transferNotification.getMessageInformation().getLanguageCode(),
              false,
              false);
    }

    if (currentTSD != null) {
      registerClonedTSDAndTransferNotification(mrn, transferNotification, currentTSD, errors);
    }
  }

  /**
   * @param party
   */
  private void loadDeclarantAndRepresentativeDetails(TransferNotification tn) {
    partyLoader.loadPartyDetails(tn.getDeclarant());
    if (null != tn.getRepresentative()) {
      partyLoader.loadPartyDetails(tn.getRepresentative());
    }
  }

  /**
   * Prefill name of party on the basis of crs data
   *
   * @param declaration
   */
  private void prefillName(TransferNotification transferNotification) {
    if (null != transferNotification.getPersonNotifyingTheArrivalAfterMovement()
        && null == transferNotification.getPersonNotifyingTheArrivalAfterMovement().getName()) {
      transferNotification
          .getPersonNotifyingTheArrivalAfterMovement()
          .setName(
              getNameFromCrs(
                  transferNotification
                      .getPersonNotifyingTheArrivalAfterMovement()
                      .getIdentificationNumber()));
    }
  }

  /**
   * get name for person and carrier
   *
   * @param identificationNumber
   * @return
   */
  private String getNameFromCrs(String identificationNumber) {
    Optional<Party> party = partyLoader.loadPartyDetails(identificationNumber);
    return party.isPresent() ? party.get().getName() : null;
  }

  /**
   * This method creates new TSD row that needs to be inserted for transfer notification and inserts
   * new Transfer notification and sends accepted or refused message to EO Notification Gateway
   *
   * @param mrn
   * @param transferNotification
   * @param currentTSD
   * @param violations
   */
  private void registerClonedTSDAndTransferNotification(
      String mrn,
      TransferNotification transferNotification,
      TemporaryStorageDeclaration currentTSD,
      List<Error> errors) {

    Integer maxVersion =
        tsdRepository.findMaxVersionTSD(currentTSD.getReferenceNumber().getCrn(), TSDStatus.DRAFT);

    TemporaryStorageDeclaration clonedTSD =
        tsdDomainMapper.cloneForTransferNotification(currentTSD);

    if (CollectionUtils.isEmpty(errors)) {

      transferNotification.setClonedTSDConsignments(clonedTSD);

      Set<ConstraintViolation<Object>> violations =
          gaGateway.lockOffwritableDocument(
              transferNotification,
              currentTSD.getReferenceNumber().getMrn().getMrnNumber(),
              LockOffwritableDocumentStatusReason.TRANSFER);

      if (CollectionUtils.isNotEmpty(violations)) {

        errors =
            tsdResponseSender.buildErrors(
                violations,
                transferNotification.getMessageInformation().getLanguageCode(),
                false,
                false);
      }
    }

    transferNotification.completeTransferNotification(currentTSD, errors);

    clonedTSD.appendTranferNotificationDetails(
        maxVersion, currentTSD, transferNotification, errors);

    tsdRepository.save(clonedTSD);

    if (CollectionUtils.isEmpty(errors)) {

      LocalDateTime awaitingRiskResultHours =
          calculateExpirationTimestamp(TimerType.RISK_ANALYSIS_RESULT);
      if ((clonedTSD.getType() == COMBINED
              || (clonedTSD.getType() == PRELODGED
                  && clonedTSD.getCurrentStatus() == TSDStatus.ACCEPTED))
          && awaitingRiskResultHours != null) {
        timerService.stopExpirationTimer(
            currentTSD.getReferenceNumber().getCrn().getCrnNumber(),
            TimerType.RISK_ANALYSIS_RESULT);
        timerService.createRiskAnalysisResultTimer(
            awaitingRiskResultHours,
            clonedTSD.getReferenceNumber().getCrn().getCrnNumber(),
            TimerType.RISK_ANALYSIS_RESULT);
      }
      clonedTSD.addRiskAnalysisAndHistory(
          awaitingRiskResultHours, RiskAndControlStatus.AWAITING_RISK_ANALYSIS_RESULT);
      riskAnalysisGateway.sendTSDToRiskAnalysis(clonedTSD, true, false);

      gaGateway.sendGaOWDTransferNotification(transferNotification, clonedTSD);

      tsdResponseSender.sendTransferNotificationAcceptedMessage(
          mrn, transferNotification, clonedTSD);
    } else {
      tsdResponseSender.sendTransferNotificationRefusedMessage(
          mrn, transferNotification, errors, clonedTSD);
    }
  }

  // message Exchange should be registered only when errorcode <> TSPNESXXR0135
  private boolean canRegisterMessageExchange(List<Error> errors) {
    return errors.stream().anyMatch((error -> !error.getErrorReason().equals("BER0135")));
  }

  public LocalDateTime calculateExpirationTimestamp(TimerType type) {
    if (type == TSD_EXPIRATION) {
      return Now.localDateTime()
          .plusDays(tsdConfig.getExpirationTimestampPeriod())
          .atOffset(ZoneOffset.UTC)
          .toLocalDateTime();
    } else if (type == TSD_DRAFT_EXPIRATION) {
      return Now.localDateTime()
          .plusDays(tsdConfig.getDraftTSDRemovalPeriod())
          .atOffset(ZoneOffset.UTC)
          .toLocalDateTime();
    } else if (type == RISK_ANALYSIS_RESULT
        && tsdConfig.getAwaitingRiskResultHours() != null
        && tsdConfig.getAwaitingRiskResultHours() > 0) {
      return Now.localDateTime()
          .plusHours(tsdConfig.getAwaitingRiskResultHours())
          .atOffset(ZoneOffset.UTC)
          .toLocalDateTime();
    }
    return null;
  }
}
