package be.fgov.minfin.tsd.domain.model.consignment;

import be.fgov.minfin.tsd.domain.model.ConsignmentLocationOfGoods;
import java.math.BigDecimal;

public interface ConsignmentProjection {

  Long getId();

  Integer getSequenceNumber();

  BigDecimal getTotalGrossMass();

  Party getConsignee();

  Party getConsignor();

  ConsignmentLocationOfGoods getCurrentConsignmentLocationOfGoods();

  interface Party {
    String getIdentificationNumber();

    String getName();
  }

  interface ConsignmentLocationOfGoods {
    Long getId();
  }

  TransportDocument getTransportDocument();

  interface TransportDocument {
    String getReferenceNumber();

    String getType();
  }

  ConsignmentGeneralInformationDraftError getGeneralInformationDraftError();

  ConsignmentPartiesDraftError getPartiesDraftError();
}
