/*
 * @(#)be.fgov.minfin.tsd.config.RabbitConfig.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.config;

import be.fgov.minfin.libdoa.amqp.DefaultConditionalRejectingErrorHandler;
import be.fgov.minfin.libdoa.amqp.transactional.QueueSender;
import be.fgov.minfin.libdoa.amqp.util.HeaderUtil;
import be.fgov.minfin.libdoa.exception.BusinessException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.amqp.core.AmqpAdmin;
import org.springframework.amqp.rabbit.config.RetryInterceptorBuilder;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.listener.ConditionalRejectingErrorHandler;
import org.springframework.amqp.rabbit.listener.FatalExceptionStrategy;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.Jackson2XmlMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.annotation.Order;
import org.springframework.retry.interceptor.StatefulRetryOperationsInterceptor;
import org.springframework.util.ErrorHandler;
import org.springframework.validation.annotation.Validated;

/** Base RabbitMQ Configuration */
@Validated
@Configuration
public class RabbitConfig {

  public static final String JSON_RABBIT_TEMPLATE = "JsonRabbitTemplate";
  public static final String XML_RABBIT_TEMPLATE = "XmlRabbitTemplate";

  /** Enable quorum queue creation <code>ENABLE_QUORUM_QUEUE</code> */
  public static final boolean ENABLE_QUORUM_QUEUE = true;

  /** Constant for bean name<code>RABBIT_LISTENER_CONTAINER_FACTORY</code> */
  public static final String RABBIT_LISTENER_CONTAINER_FACTORY = "rabbitListenerContainerFactory";

  @Bean(name = JSON_RABBIT_TEMPLATE)
  @Primary
  public RabbitTemplate defaultTemplate(
      final ConnectionFactory connectionFactory, MessageConverter messageConverter) {
    final RabbitTemplate rabbitTemplate = new RabbitTemplate(connectionFactory);
    rabbitTemplate.setMessageConverter(messageConverter);
    rabbitTemplate.setChannelTransacted(true);
    return rabbitTemplate;
  }

  //
  // factory with properties specific settings
  @Bean(name = XML_RABBIT_TEMPLATE)
  public RabbitTemplate accountingSystemQueuesTemplate(ConnectionFactory connectionFactory) {
    final RabbitTemplate rabbitTemplate = new RabbitTemplate(connectionFactory);
    rabbitTemplate.setMessageConverter(xmlMessageConvertor());
    rabbitTemplate.setChannelTransacted(true);
    return rabbitTemplate;
  }

  /** For automatically creating queue and bindings */
  @Bean
  public AmqpAdmin defaultAmqpAdmin(final ConnectionFactory connectionFactory) {
    return new RabbitAdmin(connectionFactory);
  }

  /** default json message converter */
  @Bean
  @Primary
  public MessageConverter jsonMessageConverter(ObjectMapper objectMapper) {
    Jackson2JsonMessageConverter converter = new Jackson2JsonMessageConverter(objectMapper);
    // automatically add a message Id to the message
    converter.setCreateMessageIds(true);
    return converter;
  }

  /** default xml message converter */
  @Bean
  public MessageConverter xmlMessageConvertor() {
    Jackson2XmlMessageConverter converter = new Jackson2XmlMessageConverter();
    // automatically add a message Id to the message
    converter.setCreateMessageIds(true);
    return converter;
  }

  @Bean
  StatefulRetryOperationsInterceptor interceptor() {
    return RetryInterceptorBuilder.stateful().maxAttempts(5).build();
  }

  @Bean(name = RABBIT_LISTENER_CONTAINER_FACTORY)
  @Primary
  @ConfigurationProperties(prefix = "spring.rabbitmq.listener.simple")
  // don't change the name of the bean !!
  public SimpleRabbitListenerContainerFactory rabbitListenerContainerFactory(
      ConnectionFactory connectionFactory, ObjectMapper objectMapper) {
    SimpleRabbitListenerContainerFactory factory = new SimpleRabbitListenerContainerFactory();
    factory.setConnectionFactory(connectionFactory);
    factory.setMessageConverter(jsonMessageConverter(objectMapper));
    factory.setChannelTransacted(true);
    factory.setDefaultRequeueRejected(false);
    factory.setErrorHandler(errorHandler());
    return factory;
  }

  @Bean
  public ErrorHandler errorHandler() {
    return new DefaultConditionalRejectingErrorHandler(customExceptionStrategy());
  }

  @Bean
  public QueueSender queueSender(RabbitTemplate template) {
    return new QueueSender(template);
  }

  @Bean
  @Order(-10)
  FatalExceptionStrategy customExceptionStrategy() {
    return new TSDFatalExceptionStrategy();
  }

  @Bean
  @Primary
  HeaderUtil headerUtil() {
    return new HeaderUtil();
  }

  public static class TSDFatalExceptionStrategy
      extends ConditionalRejectingErrorHandler.DefaultExceptionStrategy {
    @Override
    public boolean isUserCauseFatal(Throwable t) {
      // business exceptions are assumed to be fatal, no point in retrying them
      // TODO up to the project to define its own strategy
      // TODO maybe add retryable annotation or flag to business exceptions
      return t.getCause() instanceof BusinessException;
    }
  }
}
