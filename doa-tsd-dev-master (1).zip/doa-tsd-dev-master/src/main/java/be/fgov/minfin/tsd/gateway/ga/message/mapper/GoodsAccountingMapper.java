/*
 * @(#) be.fgov.minfin.tsd.gateway.ga.message.mapper.GoodsAccountingMapper.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.ga.message.mapper;

import static be.fgov.minfin.tsd.util.DateFormatUtil.MESSAGE_DATE_TIME_FORMAT;

import be.fgov.minfin.libdoa.goods.accounting.client.api.common.CustomsOfficeRole;
import be.fgov.minfin.libdoa.goods.accounting.client.api.common.CustomsOfficeWithRoleDTO;
import be.fgov.minfin.libdoa.goods.accounting.client.api.common.WeightDTO;
import be.fgov.minfin.libdoa.goods.accounting.client.api.owd.DeconsolidateOffwritableDocumentDTO;
import be.fgov.minfin.libdoa.goods.accounting.client.api.owd.LockOffwritableDocumentDTO;
import be.fgov.minfin.libdoa.goods.accounting.client.api.owd.LockOffwritableGoodsItemGroupingDTO;
import be.fgov.minfin.libdoa.goods.accounting.client.api.owd.OffwritableDocumentDTO;
import be.fgov.minfin.libdoa.goods.accounting.client.api.owd.OffwritableDocumentStatus;
import be.fgov.minfin.libdoa.goods.accounting.client.api.owd.OffwritableDocumentStatusReason;
import be.fgov.minfin.libdoa.goods.accounting.client.api.owd.OffwritableGoodsItemDTO;
import be.fgov.minfin.libdoa.goods.accounting.client.api.owd.OffwritableGoodsItemGroupingDTO;
import be.fgov.minfin.libdoa.goods.accounting.client.api.owd.TransportMeansDTO;
import be.fgov.minfin.libdoa.goods.accounting.client.api.owd.TransportStage;
import be.fgov.minfin.libdoa.goods.accounting.client.api.transfer.OffwritableDocumentTransferNotificationDTO;
import be.fgov.minfin.libdoa.goods.accounting.client.api.transfer.OffwritableGoodsItemGroupingTransferDTO;
import be.fgov.minfin.tsd.domain.model.CustomsOffice;
import be.fgov.minfin.tsd.domain.model.StatusHistoryReason;
import be.fgov.minfin.tsd.domain.model.TSDStatus;
import be.fgov.minfin.tsd.domain.model.TransferNotification;
import be.fgov.minfin.tsd.domain.model.TransferNotificationHouseConsignment;
import be.fgov.minfin.tsd.domain.model.TransferNotificationMasterConsignment;
import be.fgov.minfin.tsd.domain.model.consignment.ArrivalTransportMeans;
import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentItem;
import be.fgov.minfin.tsd.domain.model.consignment.HouseConsignment;
import be.fgov.minfin.tsd.domain.model.consignment.MasterConsignment;
import be.fgov.minfin.tsd.domain.model.risk.RiskAndControlStatus;
import be.fgov.minfin.tsd.gateway.ga.message.GaOWDTransferNotificationMessage;
import be.fgov.minfin.tsd.gateway.ga.message.LockOffwritableDocumentRequest;
import be.fgov.minfin.tsd.gateway.ga.message.OffwritableDocument;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.collections4.CollectionUtils;
import org.mapstruct.InjectionStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/** This class is to map DTO */
@Mapper(injectionStrategy = InjectionStrategy.CONSTRUCTOR)
public interface GoodsAccountingMapper {

  @Mapping(target = "lrn", source = "declaration.lrn")
  @Mapping(target = "crn", source = "declaration.referenceNumber.crn.crnNumber")
  @Mapping(
      target = "startDate",
      source = "declaration.dateAndTimeOfPresentationOfTheGoods",
      dateFormat = MESSAGE_DATE_TIME_FORMAT)
  @Mapping(
      target = "foreseenEndDate",
      source = "declaration.temporaryStorageExpirationTimestamp",
      dateFormat = MESSAGE_DATE_TIME_FORMAT)
  @Mapping(
      target = "status",
      expression = "java(mapStatus(offwritableDocument.getDeclaration().getCurrentStatus()))")
  @Mapping(
      target = "statusReason",
      expression =
          "java(mapStatusReason(offwritableDocument.getDeclaration().getReferenceNumber().getOrderedStatusHistory().get(0).getReason()))")
  @Mapping(
      target = "riskAndControlStatus",
      expression =
          "java(mapRiskAndControlStatus(offwritableDocument.getDeclaration().getCurrentRiskControlStatus()))")
  @Mapping(target = "version", source = "declaration.currentVersion")
  @Mapping(
      target = "customsOffice",
      expression =
          "java(mapCustomOffice(offwritableDocument.getDeclaration().getCustomsOfficeOfPresentation(), offwritableDocument.getDeclaration().getSupervisingCustomsOffice()))")
  @Mapping(target = "declarant", source = "declaration.declarant")
  @Mapping(target = "representative", source = "declaration.representative")
  @Mapping(
      target = "locationOfGoods",
      source = "declaration.consignmentHeader.presentedlocationOfGoods")
  @Mapping(target = "warehouse", source = "declaration.consignmentHeader.warehouse")
  @Mapping(
      target = "transportMeans",
      expression =
          "java(mapTransportMeans(offwritableDocument.getDeclaration().getConsignmentHeader().getArrivalTransportMeans()))")
  @Mapping(
      target = "offwritableGoodsItemGrouping",
      expression =
          "java(mapGrouping(offwritableDocument.getDeclaration().getHouseConsignments(), offwritableDocument.getDeclaration().getMasterConsignment()))")
  OffwritableDocumentDTO map(OffwritableDocument offwritableDocument);

  default List<OffwritableGoodsItemGroupingDTO> mapGrouping(
      List<HouseConsignment> houseConsignmentList, MasterConsignment masterConsignment) {
    List<OffwritableGoodsItemGroupingDTO> goodsItemGroupings = new ArrayList<>();
    OffwritableGoodsItemGroupingDTO goodsItemGroupingForMaster = map(masterConsignment);
    goodsItemGroupings.add(goodsItemGroupingForMaster);
    for (HouseConsignment houseConsignment : houseConsignmentList) {
      OffwritableGoodsItemGroupingDTO goodsItemGrouping = map(houseConsignment);
      goodsItemGroupings.add(goodsItemGrouping);
    }

    return goodsItemGroupings;
  }

  default TransportMeansDTO mapTransportMeans(ArrivalTransportMeans arrivalTransportMeans) {
    return TransportMeansDTO.builder()
        .identificationNumber(arrivalTransportMeans.getIdentificationNumber())
        .typeOfIdentification(arrivalTransportMeans.getTypeOfIdentification())
        .transportStage(TransportStage.ARRIVAL_TRANSPORT_MEANS)
        .build();
  }

  default List<CustomsOfficeWithRoleDTO> mapCustomOffice(
      CustomsOffice customOfficePresentation, CustomsOffice supervisingCustomsOffice) {
    List<CustomsOfficeWithRoleDTO> customsOfficeWithRoleDTO = new ArrayList<>();
    CustomsOfficeWithRoleDTO customOfficeWithRole = new CustomsOfficeWithRoleDTO();
    customOfficeWithRole.setReferenceNumber(customOfficePresentation.getReferenceNumber());
    customOfficeWithRole.setRole(CustomsOfficeRole.CUSTOMS_OFFICE_OF_PRESENTATION);
    CustomsOfficeWithRoleDTO supervisingCustomsWithRole = new CustomsOfficeWithRoleDTO();
    supervisingCustomsWithRole.setReferenceNumber(supervisingCustomsOffice.getReferenceNumber());
    supervisingCustomsWithRole.setRole(CustomsOfficeRole.SUPERVISING_CUSTOMS_OFFICE);
    customsOfficeWithRoleDTO.add(customOfficeWithRole);
    customsOfficeWithRoleDTO.add(supervisingCustomsWithRole);
    return customsOfficeWithRoleDTO;
  }

  default OffwritableDocumentStatus mapStatus(TSDStatus tsdStatus) {
    if (tsdStatus == TSDStatus.ACCEPTED) {
      return OffwritableDocumentStatus.AVAILABLE_FOR_WRITE_OFF;
    } else {
      return OffwritableDocumentStatus.NOT_AVAILABLE_FOR_WRITE_OFF;
    }
  }

  default be.fgov.minfin.libdoa.goods.accounting.client.api.owd.RiskAndControlStatus
      mapRiskAndControlStatus(RiskAndControlStatus riskAndControlStatus) {
    if (riskAndControlStatus == RiskAndControlStatus.AWAITING_RISK_ANALYSIS_RESULT) {
      return be.fgov.minfin.libdoa.goods.accounting.client.api.owd.RiskAndControlStatus
          .AWAITING_RISK_ANALYSIS_RESULT;
    }
    return null;
  }

  default OffwritableDocumentStatusReason mapStatusReason(StatusHistoryReason statusHistoryReason) {
    if (statusHistoryReason == StatusHistoryReason.LOCATION_OF_GOODS_TYPE_D) {
      return OffwritableDocumentStatusReason.GOODS_LOCATION;
    } else if (statusHistoryReason == StatusHistoryReason.AMENDMENT_IRREGULARITY) {
      return OffwritableDocumentStatusReason.AMENDMENT;
    }
    return null;
  }

  @Mapping(target = "type", constant = "MASTER_CONSIGNMENT")
  @Mapping(target = "offwritableGoodsItem", source = "consignmentItem")
  OffwritableGoodsItemGroupingDTO map(MasterConsignment masterConsignment);

  @Mapping(target = "type", constant = "HOUSE_CONSIGNMENT")
  @Mapping(target = "offwritableGoodsItem", source = "consignmentItem")
  OffwritableGoodsItemGroupingDTO map(HouseConsignment houseConsignment);

  @Mapping(target = "weight", expression = "java(mapWeight(consignmentItem.getGrossMass()))")
  OffwritableGoodsItemDTO map(ConsignmentItem consignmentItem);

  default WeightDTO mapWeight(BigDecimal grossMass) {
    if (grossMass == null) return null;
    else return WeightDTO.builder().grossMass(grossMass).build();
  }

  @Mapping(target = "reason", source = "reason")
  @Mapping(
      target = "offwritableGoodsItemGrouping",
      expression = "java(mapSequence(lockOwd.getTransferNotification()))")
  LockOffwritableDocumentDTO map(LockOffwritableDocumentRequest lockOwd);

  default List<LockOffwritableGoodsItemGroupingDTO> mapSequence(TransferNotification tn) {
    List<LockOffwritableGoodsItemGroupingDTO> lockOffwritableGoodsItemGroupingDTOList =
        new ArrayList<>();
    if (tn != null) {
      TransferNotificationMasterConsignment masterConsignment = tn.getMasterConsignment();
      if (masterConsignment != null && masterConsignment.getConsignment() != null) {
        LockOffwritableGoodsItemGroupingDTO lockOGItem =
            LockOffwritableGoodsItemGroupingDTO.builder()
                .sequenceNumber(masterConsignment.getConsignment().getSequenceNumber())
                .build();
        lockOffwritableGoodsItemGroupingDTOList.add(lockOGItem);
      }
      List<TransferNotificationHouseConsignment> houseConsignments = tn.getHouseConsignments();
      if (CollectionUtils.isNotEmpty(houseConsignments)) {
        for (TransferNotificationHouseConsignment hc : houseConsignments) {
          if (hc.getConsignment() != null) {
            LockOffwritableGoodsItemGroupingDTO lockOGItem =
                LockOffwritableGoodsItemGroupingDTO.builder()
                    .sequenceNumber(hc.getConsignment().getSequenceNumber())
                    .build();
            lockOffwritableGoodsItemGroupingDTOList.add(lockOGItem);
          }
        }
      }
    }
    return lockOffwritableGoodsItemGroupingDTOList;
  }

  @Mapping(
      target = "registrationDate",
      source = "transferNotification.registrationDate",
      dateFormat = MESSAGE_DATE_TIME_FORMAT)
  @Mapping(
      target = "customsOffice",
      expression =
          "java(mapCustomsOffice(gaOWDTransferNotificationMessage.getTransferNotification()))")
  @Mapping(target = "declarant", source = "transferNotification.declarant")
  @Mapping(target = "representative", source = "transferNotification.representative")
  @Mapping(
      target = "personNotifyingTheArrivalAfterMovement",
      source = "transferNotification.personNotifyingTheArrivalAfterMovement")
  @Mapping(
      target = "locationOfGoods",
      source = "transferNotification.consignmentLocationOfGoods.transferredLocationOfGoods")
  @Mapping(
      target = "warehouse",
      source = "transferNotification.consignmentLocationOfGoods.warehouse")
  @Mapping(
      target = "offwritableGoodsItemGrouping",
      expression =
          "java(mapOffwritableGoodsItemGroupingTransferList(gaOWDTransferNotificationMessage.getTransferNotification()))")
  OffwritableDocumentTransferNotificationDTO map(
      GaOWDTransferNotificationMessage gaOWDTransferNotificationMessage);

  default CustomsOfficeWithRoleDTO mapCustomsOffice(TransferNotification transferNotification) {

    CustomsOfficeWithRoleDTO customsOfficeWithRoleDTO = new CustomsOfficeWithRoleDTO();

    customsOfficeWithRoleDTO.setReferenceNumber(
        transferNotification
            .getConsignmentLocationOfGoods()
            .getSupervisingCustomsOffice()
            .getReferenceNumber());

    customsOfficeWithRoleDTO.setRole(CustomsOfficeRole.SUPERVISING_CUSTOMS_OFFICE);

    return customsOfficeWithRoleDTO;
  }

  default List<OffwritableGoodsItemGroupingTransferDTO> mapOffwritableGoodsItemGroupingTransferList(
      TransferNotification transferNotification) {

    List<OffwritableGoodsItemGroupingTransferDTO> offwritableGoodsItemGroupingTransferList =
        new ArrayList<>();

    if (transferNotification.getMasterConsignment() != null) {

      offwritableGoodsItemGroupingTransferList.add(
          OffwritableGoodsItemGroupingTransferDTO.builder()
              .sequenceNumber(0)
              .totalGrossMass(transferNotification.getMasterConsignment().getTotalGrossMass())
              .totalNumberOfPackages(
                  transferNotification.getMasterConsignment().getTotalNumberOfPackages())
              .build());
    }

    if (CollectionUtils.isNotEmpty(transferNotification.getHouseConsignments())) {
      for (int i = 0; i < transferNotification.getHouseConsignments().size(); i++) {

        offwritableGoodsItemGroupingTransferList.add(
            OffwritableGoodsItemGroupingTransferDTO.builder()
                .sequenceNumber(i + 1)
                .totalGrossMass(
                    transferNotification.getHouseConsignments().get(i).getTotalGrossMass())
                .totalNumberOfPackages(
                    transferNotification.getHouseConsignments().get(i).getTotalNumberOfPackages())
                .build());
      }
    }

    return offwritableGoodsItemGroupingTransferList;
  }

  @Mapping(
      target = "registrationDate",
      source = "declaration.registrationDate",
      dateFormat = MESSAGE_DATE_TIME_FORMAT)
  @Mapping(
      target = "status",
      expression = "java(mapStatus(offwritableDocument.getDeclaration().getCurrentStatus()))")
  @Mapping(
      target = "statusReason",
      expression =
          "java(mapStatusReason(offwritableDocument.getDeclaration().getReferenceNumber().getOrderedStatusHistory().get(0).getReason()))")
  @Mapping(
      target = "riskAndControlStatus",
      expression =
          "java(mapRiskAndControlStatus(offwritableDocument.getDeclaration().getCurrentRiskControlStatus()))")
  @Mapping(target = "version", source = "declaration.currentVersion")
  @Mapping(target = "declarant", source = "declaration.declarant")
  @Mapping(target = "representative", source = "declaration.representative")
  @Mapping(
      target = "offwritableGoodsItemGrouping",
      expression =
          "java(mapDeconsolidateOffwritableGrouping(offwritableDocument.getDeclaration().getHouseConsignments()))")
  DeconsolidateOffwritableDocumentDTO mapDOwd(OffwritableDocument offwritableDocument);

  default List<OffwritableGoodsItemGroupingDTO> mapDeconsolidateOffwritableGrouping(
      List<HouseConsignment> houseConsignmentList) {
    List<OffwritableGoodsItemGroupingDTO> goodsItemGroupings = new ArrayList<>();
    for (HouseConsignment houseConsignment : houseConsignmentList) {
      OffwritableGoodsItemGroupingDTO goodsItemGrouping = map(houseConsignment);
      goodsItemGroupings.add(goodsItemGrouping);
    }

    return goodsItemGroupings;
  }
}
