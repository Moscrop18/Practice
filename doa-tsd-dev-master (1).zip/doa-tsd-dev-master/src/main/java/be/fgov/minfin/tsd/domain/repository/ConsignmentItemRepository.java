/*
 * @(#) be.fgov.minfin.tsd.domain.repository.ConsignmentItemRepository
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.repository;

import be.fgov.minfin.tsd.domain.model.CRN;
import be.fgov.minfin.tsd.domain.model.MRN;
import be.fgov.minfin.tsd.domain.model.consignment.AllowedSectionsDetail;
import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentItem;
import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentItemProjection;
import java.util.Optional;
import javax.persistence.LockModeType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

public interface ConsignmentItemRepository extends JpaRepository<ConsignmentItem, Long> {

  @Lock(LockModeType.OPTIMISTIC_FORCE_INCREMENT)
  @Query(
      value =
          "select ci from ConsignmentItem ci "
              + "where ci.goodsItemNumber=:goodsItemNumber and ci.consignment.id=:consignmentId")
  Optional<ConsignmentItem> getConsignmentItemWithOptimisticForceIncrement(
      Integer goodsItemNumber, Long consignmentId);

  Optional<ConsignmentItem> findByGoodsItemNumberAndConsignmentId(
      Integer goodsItemNumber, Long consignmentId);

  @Query(
      value =
          "select ci from ConsignmentItem ci "
              + "join Consignment cons on ci.consignment.id = cons.id "
              + "join TemporaryStorageDeclaration tsd on cons.declaration.id = tsd.id "
              + "left join ReferenceNumber rn on tsd.id = rn.declaration.id "
              + "where ci.goodsItemNumber=:goodsItemNumber and cons.sequenceNumber=:sequenceNumber and (tsd.id=:tsdId or rn.crn=:crn or rn.mrn=:mrn)")
  Optional<ConsignmentItem> getConsignmentItem(
      Integer goodsItemNumber, Integer sequenceNumber, Long tsdId, CRN crn, MRN mrn);

  @Query(
      value =
          "select "
              + "exists ( select 1 from Consignment c "
              + "where c.id = ci.consignment.id "
              + "and (tsd.ensReUseIndicator is null or tsd.ensReUseIndicator != '1') and c.previousDocument is null ) as previousDocument, "
              + "exists ( select 1 from Consignment c "
              + "left join TransportEquipment te on te.consignment.id = c.id "
              + "where c.id = ci.consignment.id and (tsd.ensReUseIndicator is null or tsd.ensReUseIndicator != '1') and te.consignment.id is null) as transportEquipment, "
              + "exists ( select 1 from Consignment c "
              + "left join AdditionalSupplyChainActor asca on asca.consignment.id = c.id "
              + "where c.id = ci.consignment.id and (tsd.ensReUseIndicator is null or tsd.ensReUseIndicator != '1') and asca.consignment.id is null) as additionalSupplyChainActor, "
              + "exists ( select 1 from Consignment c "
              + "left join AdditionalInformation ai on ai.consignment.id = c.id "
              + "where c.id = ci.consignment.id and (tsd.ensReUseIndicator is null or tsd.ensReUseIndicator != '1') and ai.consignment.id is null) as additionalInformation, "
              + "exists ( select 1 from Consignment c "
              + "left join SupportingDocument sd on sd.consignment.id = c.id "
              + "where c.id = ci.consignment.id and (tsd.ensReUseIndicator is null or tsd.ensReUseIndicator != '1') and sd.consignment.id is null) as supportingDocument, "
              + "exists ( select 1 from ConsignmentItem innerCi "
              + "where innerCi.id=ci.id and (tsd.ensReUseIndicator is null or tsd.ensReUseIndicator != '1')) as additionalReference, "
              + "exists ( select 1 from ConsignmentItem innerCi "
              + "where innerCi.id=ci.id and tsd.ensReUseIndicator ='2') as receptacle "
              + "from ConsignmentItem ci "
              + "join Consignment cons on ci.consignment.id = cons.id "
              + "join TemporaryStorageDeclaration tsd on cons.declaration.id = tsd.id "
              + "left join ReferenceNumber rn on tsd.id = rn.declaration.id "
              + "where ci.goodsItemNumber=:goodsItemNumber and cons.sequenceNumber=:sequenceNumber and (tsd.id=:tsdId or rn.crn=:crn or rn.mrn=:mrn)")
  AllowedSectionsDetail listSectionsOfItemsForConsignmentItem(
      Integer goodsItemNumber, Integer sequenceNumber, Long tsdId, CRN crn, MRN mrn);

  @Query(
      value =
          "delete from SupportingDocument where id in "
              + "( select distinct sd.id "
              + "from SupportingDocument sd "
              + "inner join ConsignmentItem item on sd.consignmentItem.id = item.id "
              + "where item.id=:consignmentItemId "
              + ")")
  @Modifying
  void deleteSupportingDocumentsOfConsignmentItem(Long consignmentItemId);

  @Query(
      value =
          "delete from AdditionalReference where id in "
              + "( select distinct ar.id "
              + "from AdditionalReference ar "
              + "inner join ConsignmentItem item on ar.consignmentItem.id = item.id "
              + "where item.id=:consignmentItemId "
              + ")")
  @Modifying
  void deleteAdditionalReferencesOfConsignmentItem(Long consignmentItemId);

  @Query(
      value =
          "delete from AEOAuthorisation where id in "
              + "( select distinct auth.id "
              + "from AEOAuthorisation auth "
              + "inner join AdditionalSupplyChainActor chainActor on auth.chainActor.id=chainActor.id "
              + "inner join ConsignmentItem item on chainActor.consignmentItem.id = item.id "
              + "where item.id=:consignmentItemId "
              + ")")
  @Modifying
  void deleteAeoAuthOfConsignmentItem(Long consignmentItemId);

  @Query(
      value =
          "delete from AdditionalSupplyChainActor where id in "
              + "( select distinct chainActor.id "
              + "from AdditionalSupplyChainActor chainActor "
              + "inner join ConsignmentItem item on chainActor.consignmentItem.id = item.id "
              + "where item.id=:consignmentItemId "
              + ")")
  @Modifying
  void deleteSupplyChainActorsOfConsignmentItem(Long consignmentItemId);

  @Query(
      value =
          "delete from AdditionalInformation where id in "
              + "( select distinct ai.id "
              + "from AdditionalInformation ai "
              + "inner join ConsignmentItem item on ai.consignmentItem.id = item.id "
              + "where item.id=:consignmentItemId "
              + ")")
  @Modifying
  void deleteAdditionalInformationsOfConsignmentItem(Long consignmentItemId);

  @Query(
      value =
          "delete from Seal where id in "
              + "( select distinct s.id "
              + "from Seal s "
              + "inner join TransportEquipment te on s.transportEquipment.id=te.id "
              + "inner join ConsignmentItem item on te.consignmentItem.id = item.id "
              + "where item.id=:consignmentItemId "
              + ")")
  @Modifying
  void deleteSealsOfConsignmentItem(Long consignmentItemId);

  @Query(
      value =
          "delete from TransportEquipment where id in "
              + "( select distinct te.id "
              + "from TransportEquipment te "
              + "inner join ConsignmentItem item on te.consignmentItem.id = item.id "
              + "where item.id=:consignmentItemId "
              + ")")
  @Modifying
  void deleteTransportEquipmentsOfConsignmentItem(Long consignmentItemId);

  @Query(
      value =
          "delete from Packaging where id in "
              + "( select distinct p.id "
              + "from Packaging p "
              + "inner join ConsignmentItem item on p.consignmentItem.id = item.id "
              + "where item.id=:consignmentItemId "
              + ")")
  @Modifying
  void deletePackagingsOfConsignmentItem(Long consignmentItemId);

  @Query(value = "delete from ConsignmentItem where id =:consignmentItemId")
  @Modifying
  void deleteConsignmentItem(Long consignmentItemId);

  @Query(
      value = "select count(ci) from ConsignmentItem ci where ci.consignment.id = :consignmentId")
  long countByConsignmentId(Long consignmentId);

  @Query(
      value =
          "Update ConsignmentItem ci "
              + "set ci.goodsItemNumber = ci.goodsItemNumber - 1 "
              + "where ci.consignment.id=:consignmentId and ci.goodsItemNumber > :goodsItemNumber")
  @Modifying
  int updateGoodsItemNumberOfConsignmentItems(Long consignmentId, Integer goodsItemNumber);

  @Query(
      value =
          "select ci from ConsignmentItem ci "
              + "join Consignment c on ci.consignment.id = c.id "
              + "where c.id = :consignmentId")
  Page<ConsignmentItemProjection> findConsignmentItems(Long consignmentId, Pageable pageable);

  @Query(
      value =
          "select max(goodsItemNumber) from ConsignmentItem ci where ci.consignment.id = :consignmentId")
  Integer findMaxGoodsItemNumberByConsignmentId(Long consignmentId);
}
