/*
 * @(#)be.fgov.minfin.tsd.event.api.RiskAnalysisResultReceivedEvent.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.event.api;

import be.fgov.minfin.tsd.domain.model.ReceiveRiskAnalysisResult;
import lombok.Builder;
import lombok.Value;

/**
 * @author AnuragSachan
 */
@Value
@Builder
public class RiskAnalysisResultReceivedEvent {

  private String functionalReference;
  private String messageId;
  private ReceiveRiskAnalysisResult receiveRiskAnalysisResult;
}
