/*
 * @(#)be.fgov.minfin.tsd.domain.serive.ControlService.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.service;

import static be.fgov.minfin.tsd.constant.MessageNameConstant.SEND_VALIDATED_CONTROL_RESULT;

import be.fgov.minfin.libdoa.commons.lang.Now;
import be.fgov.minfin.tsd.domain.model.MessageExchange;
import be.fgov.minfin.tsd.domain.model.ReceiveControlResult;
import be.fgov.minfin.tsd.domain.model.StatusHistoryReason;
import be.fgov.minfin.tsd.domain.model.TSDStatus;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.risk.ControlRecommendation;
import be.fgov.minfin.tsd.domain.model.risk.ControlResult;
import be.fgov.minfin.tsd.domain.model.risk.RiskAnalysisRequest;
import be.fgov.minfin.tsd.domain.model.risk.RiskAndControlStatus;
import be.fgov.minfin.tsd.domain.model.risk.RiskAndControlStatusHistoryReason;
import be.fgov.minfin.tsd.domain.repository.ControlRecommendationRepository;
import be.fgov.minfin.tsd.domain.repository.MessageExchangeRepository;
import be.fgov.minfin.tsd.domain.repository.RiskAnalysisRequestRepository;
import be.fgov.minfin.tsd.domain.validation.message.MessageType;
import be.fgov.minfin.tsd.domain.validation.plugin.ControlResultValidatorPlugin;
import be.fgov.minfin.tsd.event.TSDEventBroker;
import be.fgov.minfin.tsd.event.api.ControlResultReceivedEvent;
import be.fgov.minfin.tsd.util.DateUtil;
import be.fgov.minfin.tsd.util.MessageTemplateUtil;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import javax.validation.ConstraintViolation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class ControlService {

  private final TSDEventBroker eventBroker;
  private final RiskAnalysisRequestRepository riskAnalysisRequestRepository;
  private final ControlRecommendationRepository controlRecommendationRepository;
  private final ControlResultValidatorPlugin controlResultValidator;
  private final MessageTemplateUtil messageTemplateUtil;
  private final DateUtil dateUtil;

  private final MessageExchangeRepository messageExchangeRepository;

  public void receiveControlResult(ReceiveControlResult receiveControlResult) {
    ControlResultReceivedEvent controlResultRecievedEvent =
        ControlResultReceivedEvent.builder().receiveControlResult(receiveControlResult).build();
    eventBroker.publishControlResultReceived(controlResultRecievedEvent);
  }

  public void processControlResult(
      ReceiveControlResult receiveControlResult, Optional<TemporaryStorageDeclaration> tsd) {
    log.info(
        "processControlResult with functionalReference {}",
        receiveControlResult.getFunctionalReference());

    List<ControlRecommendation> tsdControlRecommendations = null;
    if (tsd.isPresent()) {
      Optional<RiskAnalysisRequest> latestRiskAnalysisRequest =
          riskAnalysisRequestRepository.findFirstByDeclarationAndCategoryOrderByTimestampDesc(
              tsd.get(), "F");
      if (latestRiskAnalysisRequest.isPresent()) {
        tsdControlRecommendations = latestRiskAnalysisRequest.get().getControlRecommendations();
      }
    }
    // Trigger business validation
    Set<ConstraintViolation<ReceiveControlResult>> violations =
        controlResultValidator.validateControlResult(
            receiveControlResult,
            tsdControlRecommendations,
            tsd,
            MessageType.CONTROL_RESULT_MESSAGE);
    if (violations.isEmpty()) {
      // US 42.03 Register validated control result
      if (tsd.isPresent())
        registerControlResult(tsd.get(), receiveControlResult, tsdControlRecommendations);

    } else {
      // US 41.01b Send business validation refused message (IETS918)
      log.error(
          "Invalid Control result message (IETS444) received with messageId: {},"
              + " following errors were detected: {} .",
          receiveControlResult.getMessageHeader().getMessageId(),
          messageTemplateUtil.getAllErrorCodes(violations, true));
    }
  }

  private void registerControlResult(
      TemporaryStorageDeclaration tsd,
      ReceiveControlResult receiveControlResult,
      List<ControlRecommendation> tsdControlRecommendations) {

    saveMessageExchange(tsd, receiveControlResult.getMessageHeader().getMessageId());

    if (CollectionUtils.isNotEmpty(receiveControlResult.getControlRecommendations())) {
      populateControlResults(
          receiveControlResult.getControlRecommendations(),
          receiveControlResult.getControlDecision().getControlDecision(),
          true);

    } else {
      populateControlResults(
          tsdControlRecommendations,
          receiveControlResult.getControlDecision().getControlDecision(),
          false);
    }
    List<ControlRecommendation> registeredControlRecommendations =
        getRegisteredControlRecommendations(tsdControlRecommendations);

    List<ControlRecommendation> nonStatisfactoryResult =
        getNonSatisfactoryResults(tsdControlRecommendations);
    if (registeredControlRecommendations.size() == tsdControlRecommendations.size()) {
      updateTsdStatusforAllRecommendationsRegistered(tsd, nonStatisfactoryResult);

    } else {

      updateTsdStatusforPartialRecommendationsRegistered(tsd, nonStatisfactoryResult);
    }
  }

  /**
   * This method is used to register the control Recommendations for TSD if received from the
   * request, else updates the values to default.
   *
   * @param controlRecommendations
   * @param controlDecision
   * @param isRecommendationRecieved
   */
  private void populateControlResults(
      List<ControlRecommendation> controlRecommendations,
      String controlDecision,
      boolean isRequestRecommendations) {

    for (ControlRecommendation controlRecommendation : controlRecommendations) {
      if (isRequestRecommendations) {
        ControlRecommendation tsdControlRecommendation =
            controlRecommendationRepository.findByFunctionalReference(
                controlRecommendation.getFunctionalReference());
        tsdControlRecommendation.setControlResult(
            controlRecommendation.getControlResult().toBuilder()
                .controlDecision(controlDecision)
                .build());
      } else {
        if (controlRecommendation.getControlResult() == null
            || controlRecommendation.getControlResult().getControlDecision() == null)
          controlRecommendation.setControlResult(
              ControlResult.builder()
                  .controlDecision(controlDecision)
                  .timestamp(Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime())
                  .build());
      }
    }
  }

  /**
   * This method is used to Update the status for TSD when only few of the Control Recommendations
   * are received and registered.
   *
   * @param tsd
   * @param nonStatisfactoryResult
   */
  private void updateTsdStatusforPartialRecommendationsRegistered(
      TemporaryStorageDeclaration tsd, List<ControlRecommendation> nonStatisfactoryResult) {
    if (CollectionUtils.isNotEmpty(nonStatisfactoryResult)
        && tsd.getCurrentStatus() == TSDStatus.UNDER_CONTROL) {
      tsd.setCurrentStatus(TSDStatus.IRREGULARITY_UNDER_INVESTIGATION);
      tsd.trackHistory(
          TSDStatus.IRREGULARITY_UNDER_INVESTIGATION,
          StatusHistoryReason.NON_SATISFACTORY_CONTROL_RESULT,
          Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime());
      // Trigger US 46.02 Send GA offwritable document - status update
    }
  }

  /**
   * This method is used to update Status of TSD when all control recommendations for TSd are
   * already received and registered.
   *
   * @param tsd
   * @param nonStatisfactoryResult
   */
  private void updateTsdStatusforAllRecommendationsRegistered(
      TemporaryStorageDeclaration tsd, List<ControlRecommendation> nonStatisfactoryResult) {
    LocalDateTime currentDateAndTime =
        Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime();
    tsd.setCurrentRiskControlStatus(RiskAndControlStatus.CONTROL_RESULT_REGISTERED);
    tsd.trackRiskAndControlStatusHistory(
        RiskAndControlStatusHistoryReason.CONTROL_RESULT, currentDateAndTime);
    if (tsd.getCurrentStatus() == TSDStatus.UNDER_CONTROL) {

      if (CollectionUtils.isEmpty(nonStatisfactoryResult)) {
        tsd.setCurrentStatus(TSDStatus.ACCEPTED);
        tsd.trackHistory(TSDStatus.ACCEPTED, null, currentDateAndTime);

      } else {

        tsd.setCurrentStatus(TSDStatus.IRREGULARITY_UNDER_INVESTIGATION);
        tsd.trackHistory(
            TSDStatus.IRREGULARITY_UNDER_INVESTIGATION,
            StatusHistoryReason.NON_SATISFACTORY_CONTROL_RESULT,
            currentDateAndTime);
      }
    }
    // Trigger US 46.02 Send GA offwritable document - status update

  }

  /**
   * This method is used to get list of all Control Recommendations which are registered.
   *
   * @param controlRecommendations
   * @return
   */
  private List<ControlRecommendation> getRegisteredControlRecommendations(
      List<ControlRecommendation> controlRecommendations) {
    return controlRecommendations.stream()
        .filter(
            cr ->
                cr.getControlResult() != null
                    && cr.getControlResult().getControlDecision() != null
                    && cr.getControlResult().getTimestamp() != null)
        .collect(Collectors.toList());
  }

  /**
   * This method is used to get list of all registered recommendations which have non staisfactory
   * results.
   *
   * @param tsdControlRecommendations
   * @return
   */
  private List<ControlRecommendation> getNonSatisfactoryResults(
      List<ControlRecommendation> tsdControlRecommendations) {
    return tsdControlRecommendations.stream()
        .filter(
            cr ->
                cr.getControlResult() != null
                    && (Arrays.asList("0", "2", "3").contains(cr.getControlResult().getCode())))
        .collect(Collectors.toList());
  }

  private void saveMessageExchange(TemporaryStorageDeclaration declaration, String messageId) {
    MessageExchange messageExchange =
        MessageExchange.builder()
            .messageId(messageId)
            .messageTimestamp(dateUtil.getCurentSystemDate())
            .messageType(SEND_VALIDATED_CONTROL_RESULT)
            .declaration(declaration)
            .build();
    messageExchangeRepository.save(messageExchange);
  }
}
