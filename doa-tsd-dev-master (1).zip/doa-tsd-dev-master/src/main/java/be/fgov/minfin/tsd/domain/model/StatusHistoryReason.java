/*
 * @(#)be.fgov.minfin.tsd.domain.model.StatusHistoryReason.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model;

import com.fasterxml.jackson.annotation.JsonValue;

public enum StatusHistoryReason {
  EXPIRED("01"),
  REQUEST("02"),
  AMENDMENT_IRREGULARITY("03"),
  LOCATION_OF_GOODS_TYPE_D("04"),
  NON_SATISFACTORY_CONTROL_RESULT("05");

  private String value;
  private Integer code;

  StatusHistoryReason(String newValue) {
    value = newValue;
    code = Integer.parseInt(newValue);
  }

  @JsonValue
  public String getValue() {
    return value;
  }

  public Integer getCode() {
    return code;
  }
}
