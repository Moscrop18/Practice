/*
 * @(#) be.fgov.minfin.tsd.gateway.risk.plugin.DefaultRiskAnalysisGatewayPlugin.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.risk.plugin;

import static javax.ws.rs.core.Response.Status.ACCEPTED;
import static javax.ws.rs.core.Response.Status.NO_CONTENT;

import be.fgov.minfin.libdoa.exception.TechnicalException;
import be.fgov.minfin.risk.client.TSDRiskRestClient;
import be.fgov.minfin.risk.client.api.InvalidationNotificationDTO;
import be.fgov.minfin.risk.client.api.SendRiskAnalysisRequestDTO;
import be.fgov.minfin.tsd.gateway.risk.message.SendInvalidationNotification;
import be.fgov.minfin.tsd.gateway.risk.message.SendTSDRiskAnalysis;
import be.fgov.minfin.tsd.gateway.risk.message.mapper.RiskAnalysisMapper;
import javax.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Component;

/**
 * Default client implementation of Risk Analysis Gateway. This class will call Risk Systems for
 * analyzing the risks
 *
 * @author MohdSalim
 */
@Slf4j
@Component
@RequiredArgsConstructor
@ConditionalOnExpression(
    "#{T(java.util.Arrays).asList('${gateway.enabledDefaultPlugins}').contains('RISK')}")
public class DefaultRiskAnalysisGatewayPlugin implements RiskAnalysisGatewayPlugin {

  private static final String AND_RESPONSE_BODY = "and response body ";

  private static final String FAILED_WITH_STATUS_CODE = "failed with status code ";

  private final TSDRiskRestClient riskAnalysisClient;

  private final RiskAnalysisMapper mapper;

  @Override
  public void sendRiskAnalysisRequest(SendTSDRiskAnalysis riskAnalysisRequest) {
    SendRiskAnalysisRequestDTO riskAnalysisDTO = mapper.map(riskAnalysisRequest);

    Response response = riskAnalysisClient.sendRiskAnalysisRequest(riskAnalysisDTO);
    if (response.getStatus() == ACCEPTED.getStatusCode()) {
      log.debug(
          "tsd risk analysis request submitted succesfully with crn {}",
          riskAnalysisDTO.getFunctionalReference());
    } else {

      throw new TechnicalException(
          "sendTSDToRiskAnalysis '"
              + riskAnalysisDTO
              + FAILED_WITH_STATUS_CODE
              + response.getStatus()
              + AND_RESPONSE_BODY
              + response.readEntity(String.class));
    }
  }

  @Override
  public void processSendInvalidationNotification(
      SendInvalidationNotification sendInvalidationNotification) {
    InvalidationNotificationDTO invalidationNotificationDTO =
        mapper.invalidationMapper(sendInvalidationNotification);

    Response response =
        riskAnalysisClient.processSendInvalidationNotification(invalidationNotificationDTO);

    if (response.getStatus() == NO_CONTENT.getStatusCode()) {
      log.debug(
          "tsd invalidation request submitted succesfully with crn {}",
          invalidationNotificationDTO.getCrn());
    } else {

      throw new TechnicalException(
          "sendTSDToRiskAnalysis '"
              + invalidationNotificationDTO
              + FAILED_WITH_STATUS_CODE
              + response.getStatus()
              + AND_RESPONSE_BODY
              + response.readEntity(String.class));
    }
  }
}
