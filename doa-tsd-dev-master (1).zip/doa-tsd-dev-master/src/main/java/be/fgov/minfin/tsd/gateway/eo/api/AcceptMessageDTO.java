/*
 * @(#)be.fgov.minfin.tsd.gateway.eo.api.AcceptMessageDTO.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.eo.api;

import be.fgov.minfin.tsd.domain.model.BusinessValidationType;
import be.fgov.minfin.tsd.domain.model.TSDStatus;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Builder;
import lombok.Value;

@Builder
@Value
@JsonPropertyOrder({
  "messageHeader",
  "lrn",
  "frn",
  "crn",
  "mrn",
  "notificationDate",
  "businessValidationType",
  "status",
  "expirationDate",
  "remarks",
  "declarant",
  "representative",
  "personPresentingTheGoods",
  "supervisingCustomsOffice",
  "customsOfficeOfPresentation"
})
@JsonInclude(Include.NON_NULL)
@JsonRootName("IETS028")
public class AcceptMessageDTO {
  private MessageHeaderDTO messageHeader;

  private String lrn;
  private String frn;
  private String crn;
  private String mrn;
  private BusinessValidationType businessValidationType;
  private TSDStatus status;
  private String expirationDate;

  private String timerForTemporaryStorage;

  private String notificationDate;

  private DeclarantDTO declarant;

  private RepresentativeDTO representative;
  private CustomsOfficeOfPresentationDTO customsOfficeOfPresentation;
  private SupervisingCustomsOfficeDTO supervisingCustomsOffice;

  private PersonPresentingTheGoodsDTO personPresentingTheGoods;
}
