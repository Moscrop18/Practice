package be.fgov.minfin.tsd.domain.repository;

import be.fgov.minfin.tsd.domain.model.consignment.AEOAuthorisation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AEOAuthorisationRepository extends JpaRepository<AEOAuthorisation, Long> {}
