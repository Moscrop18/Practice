/*
 * @(#)be.fgov.minfin.tsd.resource.ConsignmentItemResource.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.resource;

import static be.fgov.minfin.libdoa.jaxrs.EtagUtils.eTag;
import static be.fgov.minfin.libdoa.jaxrs.LocationUtil.getLocation;

import be.fgov.minfin.libdoa.jaxrs.RequireIfMatch;
import be.fgov.minfin.libdoa.pagination.resource.pagination.PageDTO;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.consignment.AllowedSectionsDetail;
import be.fgov.minfin.tsd.domain.model.consignment.Consignment;
import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentItem;
import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentItemProjection;
import be.fgov.minfin.tsd.domain.service.ConsignmentItemService;
import be.fgov.minfin.tsd.domain.service.ConsignmentService;
import be.fgov.minfin.tsd.domain.service.TSDService;
import be.fgov.minfin.tsd.resource.api.ui.ConsignmentItemDTO;
import be.fgov.minfin.tsd.resource.api.ui.ConsignmentItemFilterDTO;
import be.fgov.minfin.tsd.resource.api.ui.ConsignmentItemProjectionDTO;
import be.fgov.minfin.tsd.resource.api.ui.RequiredField;
import be.fgov.minfin.tsd.resource.builder.ConsignmentBuilder;
import be.fgov.minfin.tsd.resource.exception.UIExceptionHandling;
import be.fgov.minfin.tsd.resource.mapper.ConsignmentItemMapper;
import be.fgov.minfin.tsd.resource.validation.SubmitUIOnly;
import be.fgov.minfin.tsd.shared.swagger.ApiResponseCreate;
import be.fgov.minfin.tsd.shared.swagger.ApiResponseDefaultErrors;
import be.fgov.minfin.tsd.shared.swagger.ApiResponseDelete;
import be.fgov.minfin.tsd.shared.swagger.ApiResponseGet;
import be.fgov.minfin.tsd.shared.swagger.ApiResponseModify;
import be.fgov.minfin.tsd.shared.swagger.ApiResponseOk;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.ArrayList;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.groups.ConvertGroup;
import javax.validation.groups.Default;
import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.UriInfo;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 *
 * <h1>Resource for UI/Internal communications</h1>
 *
 * <p>Responsibilities of a Resource
 *
 * <ul>
 *   <li>Exposing REST API
 *   <li>Authorization of operations
 *   <li>Mapping of XML/JSON &lt;-&gt; {@link }
 *   <li>validating input on ConsignmentDTO
 *       <ul>
 *         <li>using constraints
 *         <li>using business validators
 *       </ul>
 *   <li>Mapping of {@link ConsignmentItem} &lt;-&gt; Domain object
 *   <li>process of referenced domain object
 * </ul>
 *
 * @author MohdSalim
 * @version 1.0
 */
@Slf4j
@Component
@Transactional
@RequiredArgsConstructor
@Consumes({MediaType.APPLICATION_JSON})
@Produces({MediaType.APPLICATION_JSON})
@Tag(name = "Consignment Items")
@ApiResponseDefaultErrors
@UIExceptionHandling
// ignored by jersey but needed for swagger
@Path("/temporaryStorageDeclarations/${tsdId}/consignments/${consignmentNbr}/items")
public class ConsignmentItemResource {

  private final ConsignmentItemService service;
  private final TSDService tsdService;
  private final ConsignmentItemMapper mapper;
  private final ConsignmentService consignmentService;
  private final ConsignmentBuilder consignmentBuilder;

  /**
   *
   *
   * <h3>Creation of Consignment Item</h3>
   *
   * Exposes API for creation of consignment item for a draft TSD. Creation of consignment item and
   * linking it to existing consignment.
   *
   * <p>Created (201) is synchronously sent back to the sender upon successful creation of
   * consignment item and its linking with existing consignment.
   *
   * <p>Not Found (404) is synchronously sent back to the sender when the TSD or Consignment is not
   * found in the system.
   *
   * <p>Bad Request (400) along with ValidationErrorProblem DTO is synchronously sent back to the
   * sender if the ConsignmentItemDTO is not compliant with the defined schema.
   */
  // TODO Add Security -> When user role is EO we also need to check the if the declarant of the
  // declaration matches before proceeding
  @POST
  @ApiResponseCreate
  @ApiResponse(responseCode = "404", description = "Not Found")
  public Response createConsignmentItem(
      @PathParam("tsdId") String tsdId,
      @PathParam("consignmentNbr") Integer consignmentSequenceNumber,
      @Valid @NotNull @ConvertGroup(from = Default.class, to = SubmitUIOnly.class)
          ConsignmentItemDTO consignmentItemDTO,
      @Context UriInfo uriInfo) {
    log.info(
        "createConsignmentItem for tsdId/MRN/CRN {} and consignmentSequenceNumber {}",
        tsdId,
        consignmentSequenceNumber);
    TemporaryStorageDeclaration declaration =
        tsdService.getDeclaration(tsdId).orElseThrow(NotFoundException::new);
    declaration.checkCanModify();
    Consignment consignment =
        consignmentService
            .getConsignment(tsdId, consignmentSequenceNumber)
            .orElseThrow(NotFoundException::new);
    ConsignmentItem createdConsignmentItem =
        service.createConsignmentItem(mapper.map(consignmentItemDTO), consignment);

    declaration.updateRegistrationDate();
    Long goodsItemNumber = Long.valueOf(createdConsignmentItem.getGoodsItemNumber());
    return Response.created(getLocation(uriInfo, goodsItemNumber)).build();
  }

  /**
   *
   *
   * <h3>Update of Consignment Item</h3>
   *
   * Exposes API for updating consignment item for a draft TSD. Updating of draft consignment item.
   *
   * <p>Ok (200) is synchronously sent back to the sender upon successful update of consignment
   * item.
   *
   * <p>Not Found (404) is synchronously sent back to the sender when the TSD or consignment or
   * consignment item is not found in the system.
   *
   * <p>Bad Request (400) along with ValidationErrorProblem DTO is synchronously sent back to the
   * sender if the ConsignmentItemDTO is not compliant with the defined schema.
   *
   * <p>This REST resource is a Jersey implementation which produces and consumes {@link
   * MediaType#APPLICATION_JSON application/json} &amp; {@link MediaType#APPLICATION_XHTML_XML
   * application/xml} both.
   */
  @PUT
  @Path("{goodsItemNbr}")
  @ApiResponseModify
  @RequireIfMatch
  public Response updateConsignmentItem(
      @PathParam("tsdId") String tsdId,
      @PathParam("consignmentNbr") Integer consignmentSequenceNumber,
      @PathParam("goodsItemNbr") Integer goodsItemNumber,
      @Valid @NotNull ConsignmentItemDTO consignmentItemDTO,
      @Context Request request) {
    log.info(
        "updateConsignmentItem for tsdId/MRN/CRN {}, consignmentSequenceNumber {} and goodsItemNumber {}",
        tsdId,
        consignmentSequenceNumber,
        goodsItemNumber);
    TemporaryStorageDeclaration declaration =
        tsdService.getDeclaration(tsdId).orElseThrow(NotFoundException::new);
    declaration.checkCanModify();
    ConsignmentItem consignmentItem =
        service
            .getConsignmentItemForUpdate(
                declaration.getId(), consignmentSequenceNumber, goodsItemNumber)
            .orElseThrow(NotFoundException::new);
    Integer recordVersion = consignmentItem.getVersion();
    // check if-match header
    ResponseBuilder response = request.evaluatePreconditions(eTag(consignmentItem));
    if (response != null) {
      return response.build();
    }

    // map all fields which are not read only.
    mapper.mapIgnoreReadOnly(consignmentItemDTO, consignmentItem);
    mapper.setBackReference(consignmentItemDTO, consignmentItem);

    ConsignmentItem updatedItem = service.modifyConsignmentItem(consignmentItem);
    declaration.updateRegistrationDate();

    if (!recordVersion.equals(updatedItem.getVersion())) {
      return Response.ok().tag(eTag(updatedItem)).build();
    }
    return Response.ok().build();
  }

  @GET
  @Path("{goodsItemNbr}")
  @ApiResponse(
      responseCode = "200",
      description = "Ok",
      content = @Content(schema = @Schema(implementation = ConsignmentItemDTO.class)))
  @ApiResponseGet
  public Response getConsignmentItem(
      @PathParam("tsdId") String tsdId,
      @PathParam("consignmentNbr") Integer consignmentSequenceNumber,
      @PathParam("goodsItemNbr") Integer goodsItemNumber,
      @DefaultValue("DEFAULT") @QueryParam("fields") List<RequiredField> requiredFields,
      final @Context Request req) {
    log.info(
        "fetchConsignmentItem for tsdId/MRN/CRN {}, consignmentSequenceNumber {} and goodsItemNumber {}",
        tsdId,
        consignmentSequenceNumber,
        goodsItemNumber);
    ConsignmentItem consignmentItem =
        service
            .getConsignmentItem(tsdId, consignmentSequenceNumber, goodsItemNumber)
            .orElseThrow(NotFoundException::new);

    ConsignmentItemDTO dto = mapper.map(consignmentItem);
    AllowedSectionsDetail allowedSectionsDetail =
        service.calculateAllowedSections(
            tsdId, consignmentSequenceNumber, goodsItemNumber, requiredFields);
    dto =
        dto.toBuilder()
            .allowedSections(consignmentBuilder.buildAllowedSections(allowedSectionsDetail))
            .tsdId(tsdId)
            .consignmentSequenceNumber(consignmentSequenceNumber)
            .build(); // returning the same params back in self and links

    return Response.ok(dto).tag(eTag(consignmentItem)).build();
  }

  @DELETE
  @Path("{goodsItemNbr}")
  @ApiResponseDelete
  public Response removeConsignmentItem(
      @PathParam("tsdId") String tsdId,
      @PathParam("consignmentNbr") Integer consignmentSequenceNumber,
      @PathParam("goodsItemNbr") Integer goodsItemNumber) {
    log.info(
        "deleteConsignmentItem for tsdId/MRN/CRN {}, consignmentSequenceNumber {} and goodsItemNumber {}",
        tsdId,
        consignmentSequenceNumber,
        goodsItemNumber);
    ConsignmentItem consignmentItem =
        service
            .getConsignmentItem(tsdId, consignmentSequenceNumber, goodsItemNumber)
            .orElseThrow(NotFoundException::new);
    service.removeConsignmentItem(consignmentItem);

    return Response.ok().build();
  }

  @GET
  // Find consignment items: projection, filtered with criteria, offset based paged
  @ApiResponse(responseCode = "404", description = "Not Found")
  @ApiResponseOk
  public ConsignmentItemProjectionDTO.Page findConsignmentItems(
      @PathParam("tsdId") String tsdId,
      @PathParam("consignmentNbr") Integer consignmentSequenceNumber,
      @Valid @BeanParam ConsignmentItemFilterDTO filter,
      @Context UriInfo uriInfo) {

    Consignment consignment =
        consignmentService
            .getConsignment(tsdId, consignmentSequenceNumber)
            .orElseThrow(NotFoundException::new);
    Page<ConsignmentItemProjection> page =
        service.findConsignmentItems(consignment.getId(), filter.getPageable());

    Page<ConsignmentItemProjectionDTO> pageDTO = page.map(mapper::map);

    List<ConsignmentItemProjectionDTO> newPageDTOs = new ArrayList<>();
    pageDTO
        .getContent()
        .forEach(
            dto -> {
              dto = dto.toBuilder().tsdId(tsdId).sequenceNumber(consignmentSequenceNumber).build();
              newPageDTOs.add(dto);
            });

    return PageDTO.of(
        new PageImpl<>(newPageDTOs, pageDTO.getPageable(), pageDTO.getTotalElements()),
        uriInfo,
        ConsignmentItemProjectionDTO.Page.class);
  }
}
