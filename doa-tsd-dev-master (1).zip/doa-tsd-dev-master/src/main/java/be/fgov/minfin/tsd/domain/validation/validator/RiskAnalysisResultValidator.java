/*
 * @(#) be.fgov.minfin.tsd.domain.validation.validator.RiskAnalysisResultValidator.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties
 * or made public without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation.validator;

import be.fgov.minfin.tsd.domain.model.risk.RiskAnalysisResult;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class RiskAnalysisResultValidator extends BaseConstraintValidator
    implements ConstraintValidator<ValidateBusinessRules, RiskAnalysisResult> {

  private static final String RISK_ANALYSIS_RESULT_CODE = "Risk analysis result / Result code";

  @Override
  public boolean isValid(
      RiskAnalysisResult riskAnalysisResult, ConstraintValidatorContext context) {
    AtomicBoolean hasError = new AtomicBoolean(false);
    validateRiskAnalysisType(riskAnalysisResult, hasError, context);

    return !hasError.get();
  }

  private void validateRiskAnalysisType(
      RiskAnalysisResult riskAnalysisResult,
      AtomicBoolean hasError,
      ConstraintValidatorContext context) {
    if (riskAnalysisResult.getType().equalsIgnoreCase("Z")) return;
    if (!riskAnalysisResult.getType().equalsIgnoreCase("Z")
        && riskAnalysisResult.getResultCode() == null) {
      addViolation(context, ErrorCode.TSPNESXXC0454, RISK_ANALYSIS_RESULT_CODE);
      hasError.set(true);
    }
  }
}
