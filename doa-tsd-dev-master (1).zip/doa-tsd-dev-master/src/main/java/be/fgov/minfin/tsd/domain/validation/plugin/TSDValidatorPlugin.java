/*
 * @(#)be.fgov.minfin.tsd.domain.validation.TSDValidatorPlugin
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation.plugin;

import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.validation.message.MessageType;
import java.util.Set;
import javax.validation.ConstraintViolation;

public interface TSDValidatorPlugin {
  public Set<ConstraintViolation<TemporaryStorageDeclaration>> validateTSD(
      final TemporaryStorageDeclaration declaration, MessageType messageType);

  public Set<ConstraintViolation<TemporaryStorageDeclaration>> validateTSD(
      final TemporaryStorageDeclaration declaration);

  public Set<ConstraintViolation<TemporaryStorageDeclaration>> validateTSDFormat(
      final TemporaryStorageDeclaration declaration);
}
