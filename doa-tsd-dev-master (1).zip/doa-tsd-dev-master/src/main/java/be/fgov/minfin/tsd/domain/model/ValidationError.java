package be.fgov.minfin.tsd.domain.model;

import be.fgov.minfin.libdoa.entities.BaseEntity;
import be.fgov.minfin.tsd.domain.message.Error;
import com.fasterxml.jackson.annotation.JsonBackReference;
import java.util.List;
import java.util.stream.Collectors;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "VALIDATION_ERROR")
public class ValidationError extends BaseEntity<Long> {

  @GeneratedValue(generator = "validation_error_seq")
  @SequenceGenerator(name = "validation_error_seq", sequenceName = "validation_error_seq")
  @Id
  private Long id;

  private Integer sequenceNumber;
  private String pointer;
  private String code;
  private String reason;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "INVALIDATION_REQUEST_ID")
  @JsonBackReference(value = "invalidationRequest")
  private InvalidationRequest invalidationRequest;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "AMENDMENT_REQUEST_ID")
  @JsonBackReference(value = "amendmentRequest")
  private AmendmentRequest amendmentRequest;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "TRANSFER_NOTIFICATION_ID")
  @JsonBackReference(value = "transferNotification")
  private TransferNotification transferNotification;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "DECONSOLIDATION_NOTIFICAT_ID")
  @JsonBackReference(value = "deconsolidationNotification")
  private DeconsolidationNotification deconsolidationNotification;

  public static List<ValidationError> buildValidationErrors(List<Error> errors) {

    return errors.stream()
        .map(
            (Error error) ->
                ValidationError.builder()
                    .code(error.getErrorCode().toString())
                    .pointer(error.getErrorPointer())
                    .sequenceNumber(error.getSequenceNumber())
                    .reason(error.getErrorReason())
                    .build())
        .collect(Collectors.toList());
  }
}
