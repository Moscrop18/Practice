/*
 * @(#)be.fgov.minfin.tsd.gateway.control.ControlGatewayConfig.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.control;

import static be.fgov.minfin.tsd.config.RabbitConfig.ENABLE_QUORUM_QUEUE;
import static be.fgov.minfin.tsd.config.RabbitConfig.RABBIT_LISTENER_CONTAINER_FACTORY;

import be.fgov.minfin.libdoa.amqp.ExchangeConfig;
import be.fgov.minfin.libdoa.amqp.transactional.QueueConfig;
import be.fgov.minfin.tsd.gateway.control.plugin.DefaultControlPluginConfig;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.boot.context.properties.NestedConfigurationProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;

/**
 * It is config class which contain Configuration of queues and exchanges for control gateway
 * component
 *
 * @author GauravMitra
 */
@Slf4j
@Setter
@Getter
@Validated
@Configuration("controlGatewayConfig")
public class ControlGatewayConfig {

  public static final String CONTROL_INV_QUEUE = "#{controlInvalidationQueue}";
  public static final String CONCURRENCY_INV_VALUE =
      "#{controlGatewayConfig.controlInvalidationQueue.concurrentConsumers}";
  public static final String CONTROL_RECC_QUEUE = "#{controlRecommendationQueue}";
  public static final String CONCURRENCY_RECC_VALUE =
      "#{controlGatewayConfig.controlRecommendationQueue.concurrentConsumers}";

  @NestedConfigurationProperty private final DefaultControlPluginConfig defaultplugin;

  private ExchangeConfig exchange;
  private QueueConfig controlInvalidationQueue;
  private QueueConfig controlRecommendationQueue;
  private boolean registerRetryQueueListener;

  private ConfigurableBeanFactory beanFactory;
  private RabbitTemplate rabbitTemplate;

  public ControlGatewayConfig(
      ConfigurableBeanFactory beanFactory,
      DefaultControlPluginConfig defaultplugin,
      RabbitTemplate rabbitTemplate) {
    this.rabbitTemplate = rabbitTemplate;
    this.defaultplugin = defaultplugin;
    this.beanFactory = beanFactory;
    exchange = new ExchangeConfig("tsd.control.gateway");
    controlInvalidationQueue =
        new QueueConfig(
            exchange,
            "tsd_out_control_inval",
            "send.tsd.control.inval",
            "controlInvalidationQueue",
            ENABLE_QUORUM_QUEUE);
    controlRecommendationQueue =
        new QueueConfig(
            exchange,
            "tsd_out_control_recc",
            "send.tsd.control.recomm",
            "controlRecommendationQueue",
            ENABLE_QUORUM_QUEUE);
  }

  public void init() {
    // can this be done more elegantly?
    exchange.registerBeanDefinitions(beanFactory);
    if (registerRetryQueueListener) {
      controlInvalidationQueue.registerBeanDefinitions(
          beanFactory, RABBIT_LISTENER_CONTAINER_FACTORY, rabbitTemplate, false);
      controlRecommendationQueue.registerBeanDefinitions(
          beanFactory, RABBIT_LISTENER_CONTAINER_FACTORY, rabbitTemplate, false);
    } else {
      log.warn("RetryRoutingListener is not enabled for ControlGateway");
      controlInvalidationQueue.registerBeanDefinitions(beanFactory);
      controlRecommendationQueue.registerBeanDefinitions(beanFactory);
    }
  }
}
