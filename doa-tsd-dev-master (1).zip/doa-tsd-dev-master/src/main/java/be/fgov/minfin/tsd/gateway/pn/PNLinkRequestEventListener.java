package be.fgov.minfin.tsd.gateway.pn;

import static be.fgov.minfin.tsd.gateway.pn.PnGatewayConfig.LINK_CONCURRENCY_SETTING;
import static be.fgov.minfin.tsd.gateway.pn.PnGatewayConfig.PN_LINK_QUEUE;

import be.fgov.minfin.libdoa.amqp.transactional.AbstractRetryingQueueListener;
import be.fgov.minfin.pn.client.api.LinkingRequestDTO;
import be.fgov.minfin.tsd.gateway.pn.plugin.PNGatewayPlugin;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

@Component
public class PNLinkRequestEventListener extends AbstractRetryingQueueListener {
  static final String LISTENER_ID = "process-pn-link";

  private final PNGatewayPlugin plugin;

  public PNLinkRequestEventListener(PnGatewayConfig linkConfig, PNGatewayPlugin plugin) {

    super(linkConfig.getPnLinkQueue());
    this.plugin = plugin;
  }

  /** Receives message from queue for sending to PN */
  @RabbitListener(id = LISTENER_ID, queues = PN_LINK_QUEUE, concurrency = LINK_CONCURRENCY_SETTING)
  public void processSendPNLinkRequest(@Payload LinkingRequestDTO pnLinkRequest, Message message) {
    plugin.linkPN(pnLinkRequest);
  }
}
