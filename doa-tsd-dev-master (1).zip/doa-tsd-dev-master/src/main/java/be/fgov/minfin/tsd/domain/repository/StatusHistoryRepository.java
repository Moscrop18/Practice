/*
 * @(#) be.fgov.minfin.tsd.domain.repository.StatusHistoryRepository.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties
 * or made public without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.repository;

import be.fgov.minfin.tsd.domain.model.StatusHistory;
import be.fgov.minfin.tsd.domain.model.TSDStatus;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StatusHistoryRepository extends JpaRepository<StatusHistory, Long> {

  public List<StatusHistory> findByStatusAndReferenceNumberId(
      TSDStatus status, Long referenceNumberId);

  public StatusHistory findTopByReferenceNumberIdOrderByTimestampDesc(Long referenceNumberId);
}
