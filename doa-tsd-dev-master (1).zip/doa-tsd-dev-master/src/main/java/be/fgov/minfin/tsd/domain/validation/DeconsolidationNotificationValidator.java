/*
 * @(#) be.fgov.minfin.tsd.domain.validation.DeconsolidationNotificationValidator.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties
 * or made public without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation;

import be.fgov.minfin.tsd.domain.model.DeconsolidationNotification;
import be.fgov.minfin.tsd.domain.model.TSDStatus;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.consignment.TransportDocument;
import be.fgov.minfin.tsd.domain.validation.annotation.group.DeconsolidationNotificationValidatorGroup;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import be.fgov.minfin.tsd.domain.validation.message.MessageType;
import be.fgov.minfin.tsd.domain.validation.plugin.DeconsolidationNotificationValidatorPlugin;
import be.fgov.minfin.tsd.domain.validation.resolver.CustomTraversableResolver;
import java.util.HashSet;
import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.hibernate.validator.HibernateValidatorFactory;
import org.springframework.stereotype.Component;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;

@RequiredArgsConstructor
@Slf4j
@Component
public class DeconsolidationNotificationValidator
    implements DeconsolidationNotificationValidatorPlugin {

  private final LocalValidatorFactoryBean localValidatorFactoryBean;

  private final CustomTraversableResolver customTraversableResolver;

  private static final String MRN = "mrn";

  @Override
  public Set<ConstraintViolation<DeconsolidationNotification>>
      validateDeconsolidationNotificationCanBeProcessed(
          DeconsolidationNotification deconsolidationNotification,
          TemporaryStorageDeclaration currentTSD) {
    Set<ConstraintViolation<DeconsolidationNotification>> violations = new HashSet<>();
    if (currentTSD != null) {
      validateTSDCurrentStatus(currentTSD, violations);
    } else {
      violations.add(new CustomViolation<>(ErrorCode.TSPNESXXR0135, MRN));
    }
    return violations;
  }

  /**
   * Temporary Storage Declaration (current version) has a different current status than 'ACCEPTED'.
   */
  private void validateTSDCurrentStatus(
      TemporaryStorageDeclaration tsd,
      Set<ConstraintViolation<DeconsolidationNotification>> violations) {
    if (tsd.getCurrentStatus() != TSDStatus.ACCEPTED) {
      violations.add(new CustomViolation<>(ErrorCode.TSPNESXXR0146, MRN));
    }
  }

  @Override
  public Set<ConstraintViolation<DeconsolidationNotification>> validateDeconsolidationNotification(
      DeconsolidationNotification deconsolidationNotification,
      MessageType messageType,
      TemporaryStorageDeclaration currentTSD) {

    Validator validator =
        localValidatorFactoryBean
            .unwrap(HibernateValidatorFactory.class)
            .usingContext()
            .constraintValidatorPayload(messageType)
            .traversableResolver(customTraversableResolver)
            .getValidator();

    Set<ConstraintViolation<DeconsolidationNotification>> violations =
        validator.validate(
            deconsolidationNotification, DeconsolidationNotificationValidatorGroup.class);

    if (log.isDebugEnabled()) {
      violations.stream()
          .forEach(
              violation ->
                  log.info(
                      "Violation with message {} and path {}",
                      violation.getMessage(),
                      violation.getPropertyPath()));
    }

    if (violations.isEmpty()) {
      violations = new HashSet<>();
    }

    validateNoHouseConsignment(currentTSD, violations);
    validateTransportDocument(deconsolidationNotification, currentTSD, violations);

    return violations;
  }

  private void validateNoHouseConsignment(
      TemporaryStorageDeclaration currentTSD,
      Set<ConstraintViolation<DeconsolidationNotification>> violations) {
    if (CollectionUtils.isNotEmpty(currentTSD.getHouseConsignments())) {
      violations.add(new CustomViolation<>(ErrorCode.TSPNESXXR0149, MRN));
    }
  }

  private void validateTransportDocument(
      DeconsolidationNotification deconsolidationNotification,
      TemporaryStorageDeclaration currentTSD,
      Set<ConstraintViolation<DeconsolidationNotification>> violations) {

    if (null != deconsolidationNotification.getDeclaration().getMasterConsignment()) {
      TransportDocument deconsolidationNotificationMasterTD =
          deconsolidationNotification
              .getDeclaration()
              .getMasterConsignment()
              .getTransportDocument();

      if (null != currentTSD.getMasterConsignment()
          && null != currentTSD.getMasterConsignment().getTransportDocument()) {
        if (!currentTSD
            .getMasterConsignment()
            .getTransportDocument()
            .equals(deconsolidationNotificationMasterTD)) {
          violations.add(
              new CustomViolation<>(
                  ErrorCode.TSPNESXXR0143, "masterConsignment.transportDocument"));
        }
      } else {
        violations.add(
            new CustomViolation<>(ErrorCode.TSPNESXXR0143, "masterConsignment.transportDocument"));
      }
    }
  }
}
