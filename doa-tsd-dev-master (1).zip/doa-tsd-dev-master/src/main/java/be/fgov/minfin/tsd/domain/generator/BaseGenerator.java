/*
 * @(#)be.fgov.minfin.tsd.domain.generator.BaseGenerator.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.generator;

public class BaseGenerator {
  private static int[] map = {
    10, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 34, 35, 36,
    37, 38
  };
  /**
   * Get Check Digit
   *
   * @return
   */
  protected Integer getCheckDigit(String frn) {
    int total = 0;
    try {
      for (int i = 0; i < frn.length(); i++) {
        total += getNumber(frn.charAt(i)) * (1 << i);
      }
    } catch (Exception e) {
      return -1;
    }

    int remainder = total % 11;
    if (remainder == 10) {
      return 0;
    }
    return remainder;
  }

  /**
   * Gets the number.
   *
   * @param c the c
   * @return the number
   */
  private int getNumber(char c) {
    if (!Character.isDigit(c)) {
      return map[Character.getNumericValue(c) - 10];
    }
    return Character.getNumericValue(c);
  }
}
