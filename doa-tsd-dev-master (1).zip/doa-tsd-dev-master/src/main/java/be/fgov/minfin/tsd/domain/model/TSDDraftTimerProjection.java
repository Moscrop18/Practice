package be.fgov.minfin.tsd.domain.model;

import java.time.LocalDateTime;

public interface TSDDraftTimerProjection {

  Long getId();

  LocalDateTime getRegistrationDate();
}
