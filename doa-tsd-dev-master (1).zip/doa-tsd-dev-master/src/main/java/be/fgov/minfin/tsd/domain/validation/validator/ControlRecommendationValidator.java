/*
 * @(#) be.fgov.minfin.tsd.domain.validation.validator.ControlRecommendationValidator.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation.validator;

import be.fgov.minfin.tsd.domain.model.consignment.Consignment;
import be.fgov.minfin.tsd.domain.model.consignment.MasterConsignment;
import be.fgov.minfin.tsd.domain.model.risk.ControlRecommendation;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.apache.commons.collections4.CollectionUtils;

public class ControlRecommendationValidator extends BaseConstraintValidator
    implements ConstraintValidator<ValidateBusinessRules, ControlRecommendation> {

  @Override
  public boolean isValid(
      ControlRecommendation controlRecommendation, ConstraintValidatorContext context) {

    AtomicBoolean isValid = new AtomicBoolean(true);

    if (CollectionUtils.isEmpty(controlRecommendation.getConsignments())) {
      return isValid.get();
    }

    MasterConsignment masterConsignment =
        findMasterConsignment(controlRecommendation.getConsignments());

    if (masterConsignment != null
        && controlRecommendation.getConsignments().size() == 1
        && masterConsignment.getTransportDocument() == null
        && CollectionUtils.isEmpty(masterConsignment.getTransportEquipment())
        && CollectionUtils.isEmpty(masterConsignment.getReceptacle())
        && CollectionUtils.isEmpty(masterConsignment.getConsignmentItem())) {
      addViolation(context, ErrorCode.TSPNESXXR0421);
      isValid.set(false);
    }

    if ((masterConsignment != null
            && (masterConsignment.getTransportDocument() != null
                || CollectionUtils.isNotEmpty(masterConsignment.getTransportEquipment())
                || CollectionUtils.isNotEmpty(masterConsignment.getReceptacle())
                || CollectionUtils.isNotEmpty(masterConsignment.getConsignmentItem())))
        && controlRecommendation.getConsignments().size() > 1) {
      addViolation(context, ErrorCode.TSPNESXXR0449);
      isValid.set(false);
    }

    return isValid.get();
  }

  private MasterConsignment findMasterConsignment(List<Consignment> consignments) {
    Optional<Consignment> masterConsignment =
        consignments.stream().filter(c -> c instanceof MasterConsignment).findAny();
    if (masterConsignment.isPresent()) {
      return (MasterConsignment) masterConsignment.get();
    } else {
      return null;
    }
  }
}
