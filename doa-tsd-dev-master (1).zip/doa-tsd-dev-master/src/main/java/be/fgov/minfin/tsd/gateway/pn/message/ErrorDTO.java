package be.fgov.minfin.tsd.gateway.pn.message;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Builder;
import lombok.Value;

@Builder(toBuilder = true)
@Value
@JsonRootName("linkingError")
@JsonInclude(Include.NON_NULL)
public class ErrorDTO {
  private Integer sequenceNumber;
  private String errorReason;
}
