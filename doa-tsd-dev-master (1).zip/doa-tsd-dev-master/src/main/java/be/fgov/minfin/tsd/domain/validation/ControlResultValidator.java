/*
 * @(#)be.fgov.minfin.tsd.domain.validation.ControlResultValidator.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation;

import be.fgov.minfin.tsd.domain.model.ReceiveControlResult;
import be.fgov.minfin.tsd.domain.model.TSDStatus;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.risk.ControlRecommendation;
import be.fgov.minfin.tsd.domain.model.risk.RiskAndControlStatus;
import be.fgov.minfin.tsd.domain.validation.annotation.group.ReceiveControlResultValidator;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import be.fgov.minfin.tsd.domain.validation.message.MessageType;
import be.fgov.minfin.tsd.domain.validation.plugin.ControlResultValidatorPlugin;
import be.fgov.minfin.tsd.domain.validation.resolver.CustomTraversableResolver;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import lombok.RequiredArgsConstructor;
import org.hibernate.validator.HibernateValidatorFactory;
import org.hibernate.validator.internal.engine.resolver.JPATraversableResolver;
import org.springframework.stereotype.Component;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;

@RequiredArgsConstructor
@Component
public class ControlResultValidator implements ControlResultValidatorPlugin {

  public static final String MRN = "mrn";
  public static final String CONTROL_DECISION = "controlDecision";
  public static final String CONTROL_REFERENCE = "controlResults.controlRecommendationReference";

  private final LocalValidatorFactoryBean factory;
  private final CustomTraversableResolver resolver;

  @Override
  public Set<ConstraintViolation<ReceiveControlResult>> validateControlResult(
      ReceiveControlResult controlResult,
      List<ControlRecommendation> tsdControlRecommendations,
      Optional<TemporaryStorageDeclaration> temporaryStorageDeclaration,
      MessageType messageType) {

    new JPATraversableResolver();
    Validator validator =
        factory
            .unwrap(HibernateValidatorFactory.class)
            .usingContext()
            .constraintValidatorPayload(messageType)
            .traversableResolver(resolver)
            .getValidator();

    Set<ConstraintViolation<ReceiveControlResult>> violation =
        validator.validate(controlResult, ReceiveControlResultValidator.class);

    if (violation.isEmpty()) {
      violation = new HashSet<>();
    }

    if (temporaryStorageDeclaration.isPresent()) {

      validateTSDCurrentStatus(temporaryStorageDeclaration.get(), violation);
      validateTSDCurrentRiskAndControlStatus(temporaryStorageDeclaration.get(), violation);
      validateControlRecommendation(tsdControlRecommendations, violation);
      if (null != controlResult.getControlRecommendations()
          && !controlResult.getControlRecommendations().isEmpty()) {
        validateControlRecommendationReference(tsdControlRecommendations, controlResult, violation);
      }
    } else {
      ConstraintViolation<ReceiveControlResult> customViolation =
          new CustomViolation<>(ErrorCode.TSPNESXXR0446, MRN);
      violation.add(customViolation);
    }
    return violation;
  }

  private void validateControlRecommendationReference(
      List<ControlRecommendation> controlRecommendations,
      ReceiveControlResult controlResult,
      Set<ConstraintViolation<ReceiveControlResult>> violation) {

    List<String> requestControlRecommReferences =
        controlResult.getControlRecommendations().stream()
            .map(ControlRecommendation::getFunctionalReference)
            .collect(Collectors.toList());

    List<String> tsdControlRecommReferences =
        controlRecommendations.stream()
            .map(ControlRecommendation::getFunctionalReference)
            .collect(Collectors.toList());

    if (!tsdControlRecommReferences.containsAll(requestControlRecommReferences)) {
      ConstraintViolation<ReceiveControlResult> customViolation =
          new CustomViolation<>(ErrorCode.TSPNESXXR0455, CONTROL_REFERENCE);
      violation.add(customViolation);
    }
  }

  private void validateTSDCurrentStatus(
      TemporaryStorageDeclaration tsd, Set<ConstraintViolation<ReceiveControlResult>> violation) {
    if (tsd.getCurrentStatus() != TSDStatus.UNDER_CONTROL
        && tsd.getCurrentStatus() != TSDStatus.IRREGULARITY_UNDER_INVESTIGATION
        && tsd.getCurrentStatus() != TSDStatus.MEASURES_REQUIRED
        && tsd.getCurrentStatus() != TSDStatus.AMENDMENT_REQUIRED
        && tsd.getCurrentStatus() != TSDStatus.TEMPORARY_STORAGE_ENDED) {
      ConstraintViolation<ReceiveControlResult> customViolation =
          new CustomViolation<>(ErrorCode.TSPNESXXR0428, MRN);
      violation.add(customViolation);
    }
  }

  private void validateTSDCurrentRiskAndControlStatus(
      TemporaryStorageDeclaration tsd, Set<ConstraintViolation<ReceiveControlResult>> violation) {
    if (tsd.getCurrentRiskControlStatus() != RiskAndControlStatus.UNDER_CONTROL) {
      ConstraintViolation<ReceiveControlResult> customViolation =
          new CustomViolation<>(ErrorCode.TSPNESXXR0429, MRN);
      violation.add(customViolation);
    }
  }

  private void validateControlRecommendation(
      List<ControlRecommendation> tsdControlRecommendations,
      Set<ConstraintViolation<ReceiveControlResult>> violation) {
    boolean allMatch =
        tsdControlRecommendations.stream()
            .allMatch(
                controlRecommendation ->
                    controlRecommendation.getControlResult() != null
                        && controlRecommendation.getControlResult().getControlDecision() != null);
    if (allMatch) {
      ConstraintViolation<ReceiveControlResult> customViolation =
          new CustomViolation<>(ErrorCode.TSPNESXXR0457, CONTROL_DECISION);
      violation.add(customViolation);
    }
  }
}
