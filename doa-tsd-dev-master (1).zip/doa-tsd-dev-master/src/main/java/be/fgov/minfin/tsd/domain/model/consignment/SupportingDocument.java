/*
 * @(#)be.fgov.minfin.tsd.domain.model.consignment.SupportingDocument
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model.consignment;

import be.fgov.minfin.tsd.domain.validation.annotation.CodeList;
import be.fgov.minfin.tsd.domain.validation.annotation.group.DeconsolidationNotificationValidatorGroup;
import be.fgov.minfin.tsd.domain.validation.annotation.group.NonDraftTSD;
import be.fgov.minfin.tsd.domain.validation.codelist.TSDCodeLists;
import com.fasterxml.jackson.annotation.JsonBackReference;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.groups.Default;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "SUPPORTING_DOCUMENT")
@EqualsAndHashCode(exclude = {"consignmentItem", "consignment"})
public class SupportingDocument {
  @GeneratedValue(generator = "SUPPORTING_DOCUMENT_SEQ")
  @SequenceGenerator(name = "SUPPORTING_DOCUMENT_SEQ", sequenceName = "SUPPORTING_DOCUMENT_SEQ")
  @Id
  private Long id;

  @NotNull(groups = NonDraftTSD.class)
  private String referenceNumber;

  @CodeList(
      value = TSDCodeLists.CL213,
      groups = {Default.class, DeconsolidationNotificationValidatorGroup.class})
  @NotNull(groups = NonDraftTSD.class)
  private String type;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "CONSIGNMENT_ID")
  @JsonBackReference(value = "consignment")
  private Consignment consignment;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "CONSIGNMENT_ITEM_ID")
  @JsonBackReference(value = "consignmentItem")
  private ConsignmentItem consignmentItem;
}
