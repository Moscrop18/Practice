/*
 * @(#) be.fgov.minfin.tsd.event.DeconsolidationNotificationReceivedEventListener.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.event;

import static be.fgov.minfin.tsd.event.TSDEventConfig.TSD_DECONSOLIDATION_NOTIFICATION_RECEIVED_CONCURRENCY;
import static be.fgov.minfin.tsd.event.TSDEventConfig.TSD_DECONSOLIDATION_NOTIFICATION_RECEIVED_QUEUE;

import be.fgov.minfin.libdoa.amqp.transactional.AbstractRetryingQueueListener;
import be.fgov.minfin.tsd.domain.service.DeconsolidationNotificationService;
import be.fgov.minfin.tsd.event.api.TSDDeconsolidationNotificationRecievedEvent;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class DeconsolidationNotificationReceivedEventListener
    extends AbstractRetryingQueueListener {

  public static final String LISTENER_ID = "processDeconsolidationNotification";

  private final DeconsolidationNotificationService deconsolidationNotificationService;

  public DeconsolidationNotificationReceivedEventListener(
      TSDEventConfig tsdEventConfig,
      DeconsolidationNotificationService deconsolidationNotificationService) {

    super(tsdEventConfig.getTsdTransferNotificationReceivedQueue());
    this.deconsolidationNotificationService = deconsolidationNotificationService;
  }

  @RabbitListener(
      id = LISTENER_ID,
      queues = TSD_DECONSOLIDATION_NOTIFICATION_RECEIVED_QUEUE,
      concurrency = TSD_DECONSOLIDATION_NOTIFICATION_RECEIVED_CONCURRENCY)
  public void processDeconsolidationNotificationEvent(
      @Payload
          TSDDeconsolidationNotificationRecievedEvent tsdDeconsolidationNotificationRecievedEvent,
      Message message) {

    deconsolidationNotificationService.processDeconsolidationNotification(
        tsdDeconsolidationNotificationRecievedEvent.getMrn(),
        tsdDeconsolidationNotificationRecievedEvent.getDeconsolidationNotification());
  }
}
