/*
 * @(#) be.fgov.minfin.tsd.domain.model.consignment.ConsignmentItem.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model.consignment;

import be.fgov.minfin.libdoa.entities.VersionedAuditableEntity;
import be.fgov.minfin.tsd.domain.converter.ConsignmentItemDraftErrorConverter;
import be.fgov.minfin.tsd.domain.validation.annotation.NumberCompare;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import be.fgov.minfin.tsd.domain.validation.annotation.group.DeconsolidationNotificationValidatorGroup;
import be.fgov.minfin.tsd.domain.validation.annotation.group.NonDraftTSD;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import be.fgov.minfin.tsd.util.NumberCompareType;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import java.math.BigDecimal;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Convert;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.groups.Default;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "CONSIGNMENT_ITEM")
@EqualsAndHashCode(
    exclude = {
      "packaging",
      "transportEquipment",
      "additionalInformation",
      "supportingDocument",
      "additionalSupplyChainActor",
      "additionalReference",
      "consignment"
    })
@ValidateBusinessRules(groups = {Default.class, DeconsolidationNotificationValidatorGroup.class})
public class ConsignmentItem extends VersionedAuditableEntity<Long> implements HasPreviousDocument {
  @GeneratedValue(generator = "CONSIGNMENT_ITEM_SEQ")
  @SequenceGenerator(name = "CONSIGNMENT_ITEM_SEQ", sequenceName = "CONSIGNMENT_ITEM_SEQ")
  @Id
  private Long id;

  @NotNull(groups = NonDraftTSD.class)
  private Integer goodsItemNumber;

  @NumberCompare(
      numberCompareType = NumberCompareType.GREATER_THAN,
      value = 0,
      groups = {Default.class, DeconsolidationNotificationValidatorGroup.class},
      errorCode = ErrorCode.TSPNESXXR0055)
  private BigDecimal grossMass;

  @Convert(converter = ConsignmentItemDraftErrorConverter.class)
  private ConsignmentItemDraftError draftError;

  @Valid @Embedded private PreviousDocument previousDocument;

  @OneToMany(
      cascade = {CascadeType.PERSIST, CascadeType.MERGE},
      orphanRemoval = true,
      mappedBy = "consignmentItem")
  @ToString.Exclude
  @JsonManagedReference(value = "consignmentItem")
  private List<@Valid Packaging> packaging;

  @NotNull(groups = NonDraftTSD.class)
  @Valid
  @Embedded
  private Commodity commodity;

  @OneToMany(
      cascade = {CascadeType.PERSIST, CascadeType.MERGE},
      orphanRemoval = true,
      mappedBy = "consignmentItem")
  @ToString.Exclude
  @JsonManagedReference(value = "consignmentItem")
  private List<@Valid TransportEquipment> transportEquipment;

  @OneToMany(
      cascade = {CascadeType.PERSIST, CascadeType.MERGE},
      orphanRemoval = true,
      mappedBy = "consignmentItem")
  @ToString.Exclude
  @JsonManagedReference(value = "consignmentItem")
  private List<@Valid AdditionalInformation> additionalInformation;

  @OneToMany(
      cascade = {CascadeType.PERSIST, CascadeType.MERGE},
      orphanRemoval = true,
      mappedBy = "consignmentItem")
  @ToString.Exclude
  @JsonManagedReference(value = "consignmentItem")
  private List<@Valid SupportingDocument> supportingDocument;

  @OneToMany(
      cascade = {CascadeType.PERSIST, CascadeType.MERGE},
      orphanRemoval = true,
      mappedBy = "consignmentItem")
  @ToString.Exclude
  @JsonManagedReference(value = "consignmentItem")
  private List<@Valid AdditionalSupplyChainActor> additionalSupplyChainActor;

  @OneToMany(
      cascade = {CascadeType.PERSIST, CascadeType.MERGE},
      orphanRemoval = true,
      mappedBy = "consignmentItem")
  @ToString.Exclude
  @JsonManagedReference(value = "consignmentItem")
  private List<@Valid AdditionalReference> additionalReference;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "CONSIGNMENT_ID")
  @JsonBackReference(value = "consignment")
  private Consignment consignment;
}
