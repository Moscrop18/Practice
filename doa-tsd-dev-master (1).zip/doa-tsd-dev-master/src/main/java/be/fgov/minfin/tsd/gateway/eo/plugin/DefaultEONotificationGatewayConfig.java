/*
 * @(#)be.fgov.minfin.tsd.gateway.eo.plugin.DefaultEONotificationGatewayClient.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.eo.plugin;

import static be.fgov.minfin.tsd.gateway.GatewayConfig.DEFAULT_CONNECT_TIMEOUT;
import static be.fgov.minfin.tsd.gateway.GatewayConfig.DEFAULT_REQUEST_TIMEOUT;

import be.fgov.minfin.eogw.client.EONotificationRestClient;
import be.fgov.minfin.shared.metrics.jersey2.client.JerseyClientUtils;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;

@Validated
@Getter
@Setter
@Configuration
public class DefaultEONotificationGatewayConfig {
  private String url;
  private Integer connectTimeout = DEFAULT_CONNECT_TIMEOUT;
  private Integer requestTimeout = DEFAULT_REQUEST_TIMEOUT;

  @Bean
  @Qualifier("eoClient")
  public EONotificationRestClient createEOClient(JerseyClientUtils clientUtils) {
    return new EONotificationRestClient(
        clientUtils.createDefaultConfig(connectTimeout, requestTimeout), url);
  }
}
