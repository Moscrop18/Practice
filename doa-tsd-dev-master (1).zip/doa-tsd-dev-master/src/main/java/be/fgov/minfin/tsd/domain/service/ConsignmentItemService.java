/*
 * @(#)be.fgov.minfin.tsd.domain.service.ConsignmentItemService.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.service;

import static be.fgov.minfin.tsd.domain.model.ConsignmentInformationType.HOUSE;
import static be.fgov.minfin.tsd.domain.model.ConsignmentInformationType.MASTER;
import static be.fgov.minfin.tsd.domain.model.ConsignmentInformationType.MASTERANDHOUSE;

import be.fgov.minfin.tsd.domain.model.CRN;
import be.fgov.minfin.tsd.domain.model.MRN;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.consignment.AllowedSectionsDetail;
import be.fgov.minfin.tsd.domain.model.consignment.Consignment;
import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentItem;
import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentItemProjection;
import be.fgov.minfin.tsd.domain.model.consignment.HouseConsignment;
import be.fgov.minfin.tsd.domain.model.consignment.MasterConsignment;
import be.fgov.minfin.tsd.domain.repository.ConsignmentItemRepository;
import be.fgov.minfin.tsd.domain.validation.CustomViolation;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import be.fgov.minfin.tsd.resource.api.ui.RequiredField;
import java.util.List;
import java.util.Optional;
import javax.ws.rs.NotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

/**
 * This is service layer for functionality related to ConsignmentItem
 *
 * @author MohdSalim
 */
@Service
@RequiredArgsConstructor
public class ConsignmentItemService {

  private static final String GOODS_ITEM_NUMBER = "goodsItemNumber";

  private final ConsignmentItemRepository repository;
  private final ConsignmentService consignmentService;

  public ConsignmentItem createConsignmentItem(
      ConsignmentItem consignmentItem, Consignment consignment) {
    // custom query instead of loading all the house consignments for sequenceNumber
    Integer maxGoodsItemNumber =
        repository.findMaxGoodsItemNumberByConsignmentId(consignment.getId());
    if (maxGoodsItemNumber == null) {
      consignmentItem.setGoodsItemNumber(Integer.valueOf(1));
    } else {
      consignmentItem.setGoodsItemNumber(maxGoodsItemNumber + 1);
    }
    consignmentItem.setConsignment(consignment);
    consignmentItem = repository.save(consignmentItem);
    return consignmentItem;
  }

  public Optional<ConsignmentItem> getConsignmentItemForUpdate(
      Long tsdId, Integer consignmentSequenceNumber, Integer goodsItemNumber) {
    Consignment consignment =
        consignmentService
            .getConsignmentForUpdate(tsdId, consignmentSequenceNumber)
            .orElseThrow(NotFoundException::new);
    return repository.getConsignmentItemWithOptimisticForceIncrement(
        goodsItemNumber, consignment.getId());
  }

  public ConsignmentItem modifyConsignmentItem(ConsignmentItem consignmentItem) {
    return repository.saveAndFlush(consignmentItem);
  }

  public Optional<ConsignmentItem> getConsignmentItem(
      String tsdId, Integer consignmentSequenceNumber, Integer goodsItemNumber) {
    if (CRN.isValidCrn(tsdId)) {
      return repository.getConsignmentItem(
          goodsItemNumber, consignmentSequenceNumber, null, CRN.of(tsdId), null);
    } else if (MRN.isValidMrn(tsdId)) {
      return repository.getConsignmentItem(
          goodsItemNumber, consignmentSequenceNumber, null, null, MRN.of(tsdId));
    } else {
      return repository.getConsignmentItem(
          goodsItemNumber, consignmentSequenceNumber, Long.valueOf(tsdId), null, null);
    }
  }

  public AllowedSectionsDetail calculateAllowedSections(
      String tsdId,
      Integer consignmentSequenceNumber,
      Integer goodsItemNumber,
      List<RequiredField> requiredfields) {
    AllowedSectionsDetail allowedSectionsDetail = null;
    if (!requiredfields.contains(RequiredField.ALLOWED_SECTIONS)) {
      return allowedSectionsDetail;
    }
    if (CRN.isValidCrn(tsdId)) {
      allowedSectionsDetail =
          repository.listSectionsOfItemsForConsignmentItem(
              goodsItemNumber, consignmentSequenceNumber, null, CRN.of(tsdId), null);
    } else if (MRN.isValidMrn(tsdId)) {
      allowedSectionsDetail =
          repository.listSectionsOfItemsForConsignmentItem(
              goodsItemNumber, consignmentSequenceNumber, null, null, MRN.of(tsdId));
    } else {
      allowedSectionsDetail =
          repository.listSectionsOfItemsForConsignmentItem(
              goodsItemNumber, consignmentSequenceNumber, Long.valueOf(tsdId), null, null);
    }
    return allowedSectionsDetail;
  }

  public void removeConsignmentItem(ConsignmentItem consignmentItem) {
    Consignment consignment = consignmentItem.getConsignment();
    TemporaryStorageDeclaration declaration = consignment.getDeclaration();
    declaration.checkCanDelete();

    if (declaration.getConsignmentItemType() == MASTER) {
      if (consignment instanceof HouseConsignment
          || repository.countByConsignmentId(consignment.getId()) == 1) {
        CustomViolation.doThrow(ErrorCode.TSPNESXXR0322, GOODS_ITEM_NUMBER);
      } else {
        // delete consignmentItem only if there are more than 1 items
        repository.updateGoodsItemNumberOfConsignmentItems(
            consignment.getId(), consignmentItem.getGoodsItemNumber());
        deleteConsignmentItem(consignmentItem);
      }
    } else if (declaration.getConsignmentItemType() == HOUSE) {
      if (consignment instanceof MasterConsignment
          || repository.countByConsignmentId(consignment.getId()) == 1) {
        CustomViolation.doThrow(ErrorCode.TSPNESXXR0322, GOODS_ITEM_NUMBER);
      } else {
        // delete consignmentItem only if there are more than 1 items
        repository.updateGoodsItemNumberOfConsignmentItems(
            consignment.getId(), consignmentItem.getGoodsItemNumber());
        deleteConsignmentItem(consignmentItem);
      }
    } else if (declaration.getConsignmentItemType() == MASTERANDHOUSE) {
      if (repository.countByConsignmentId(consignment.getId()) == 1) {
        CustomViolation.doThrow(ErrorCode.TSPNESXXR0322, GOODS_ITEM_NUMBER);
      } else {
        // delete consignmentItem only if there are more than 1 items
        repository.updateGoodsItemNumberOfConsignmentItems(
            consignment.getId(), consignmentItem.getGoodsItemNumber());
        deleteConsignmentItem(consignmentItem);
      }
    }
    declaration.updateRegistrationDate();
  }

  private void deleteConsignmentItem(ConsignmentItem consignmentItem) {
    repository.deleteSupportingDocumentsOfConsignmentItem(consignmentItem.getId());
    repository.deleteAdditionalReferencesOfConsignmentItem(consignmentItem.getId());
    repository.deleteAeoAuthOfConsignmentItem(consignmentItem.getId());
    repository.deleteSupplyChainActorsOfConsignmentItem(consignmentItem.getId());
    repository.deleteAdditionalInformationsOfConsignmentItem(consignmentItem.getId());
    repository.deleteSealsOfConsignmentItem(consignmentItem.getId());
    repository.deleteTransportEquipmentsOfConsignmentItem(consignmentItem.getId());
    repository.deletePackagingsOfConsignmentItem(consignmentItem.getId());
    repository.deleteConsignmentItem(consignmentItem.getId());
  }

  public Page<ConsignmentItemProjection> findConsignmentItems(Long consId, Pageable pageable) {
    return repository.findConsignmentItems(consId, pageable);
  }
}
