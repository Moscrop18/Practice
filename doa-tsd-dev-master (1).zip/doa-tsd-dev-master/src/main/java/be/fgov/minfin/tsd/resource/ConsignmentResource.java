/*
 * @(#)be.fgov.minfin.tsd.resource.ConsignmentResource.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.resource;

import static be.fgov.minfin.libdoa.jaxrs.EtagUtils.eTag;
import static be.fgov.minfin.libdoa.jaxrs.LocationUtil.getLocation;

import be.fgov.minfin.libdoa.jaxrs.RequireIfMatch;
import be.fgov.minfin.libdoa.pagination.resource.pagination.PageDTO;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.consignment.AllowedSectionsDetail;
import be.fgov.minfin.tsd.domain.model.consignment.Consignment;
import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentFilter;
import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentProjection;
import be.fgov.minfin.tsd.domain.model.consignment.HouseConsignment;
import be.fgov.minfin.tsd.domain.model.consignment.ItemDraftError;
import be.fgov.minfin.tsd.domain.model.consignment.MasterConsignment;
import be.fgov.minfin.tsd.domain.service.ConsignmentService;
import be.fgov.minfin.tsd.domain.service.TSDService;
import be.fgov.minfin.tsd.resource.api.ui.ConsignmentDTO;
import be.fgov.minfin.tsd.resource.api.ui.ConsignmentFilterDTO;
import be.fgov.minfin.tsd.resource.api.ui.ConsignmentProjectionDTO;
import be.fgov.minfin.tsd.resource.api.ui.RequiredField;
import be.fgov.minfin.tsd.resource.builder.ConsignmentBuilder;
import be.fgov.minfin.tsd.resource.exception.UIExceptionHandling;
import be.fgov.minfin.tsd.resource.mapper.ConsignmentMapper;
import be.fgov.minfin.tsd.resource.validation.SubmitUIOnly;
import be.fgov.minfin.tsd.resource.validation.UIOnly;
import be.fgov.minfin.tsd.shared.swagger.ApiResponseCreate;
import be.fgov.minfin.tsd.shared.swagger.ApiResponseDefaultErrors;
import be.fgov.minfin.tsd.shared.swagger.ApiResponseDelete;
import be.fgov.minfin.tsd.shared.swagger.ApiResponseGet;
import be.fgov.minfin.tsd.shared.swagger.ApiResponseModify;
import be.fgov.minfin.tsd.shared.swagger.ApiResponseOk;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.groups.ConvertGroup;
import javax.validation.groups.Default;
import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.UriInfo;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 *
 * <h1>Resource for UI/Internal communications</h1>
 *
 * <p>Responsibilities of a Resource
 *
 * <ul>
 *   <li>Exposing REST API
 *   <li>Authorization of operations
 *   <li>Mapping of XML/JSON &lt;-&gt; {@link }
 *   <li>validating input on ConsignmentDTO
 *       <ul>
 *         <li>using constraints
 *         <li>using business validators
 *       </ul>
 *   <li>Mapping of {@link HouseConsignment} &lt;-&gt; {@link MasterConsignment} Domain object
 *   <li>process of referenced domain object
 * </ul>
 *
 * @author MohdSalim
 * @version 1.0
 */
@Component
// ignored by jersey but needed for swagger
@Path("/temporaryStorageDeclarations/${tsdId}/consignments")
@Produces({MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_JSON})
@RequiredArgsConstructor
@Transactional
@Slf4j
@UIExceptionHandling
@ApiResponseDefaultErrors
@Tag(name = "Consignment")
public class ConsignmentResource {

  private final ConsignmentService service;
  private final ConsignmentMapper mapper;
  private final TSDService tsdService;
  private final ConsignmentItemResource consignmentItemResource;
  private final ConsignmentBuilder consignmentBuilder;

  /**
   *
   *
   * <h3>Creation of Consignment</h3>
   *
   * Exposes API for creation of consignment for a draft TSD. Creation of consignment (Master/House)
   * and linking it to existing Draft TSD.
   *
   * <p>Created (201) is synchronously sent back to the sender upon successful creation of
   * consignment and its linking with existing draft TSD
   *
   * <p>Not Found (404) is synchronously sent back to the sender when the TSD is not found in the
   * system.
   *
   * <p>Bad Request (400) along with ValidationErrorProblem DTO is synchronously sent back to the
   * sender if the ConsignmentDTO is not compliant with the defined schema.
   */
  @POST
  @ApiResponseCreate
  @ApiResponse(responseCode = "404", description = "Not Found")
  public Response createConsignment(
      @PathParam("tsdId") String tsdId,
      @Valid @NotNull @ConvertGroup(from = Default.class, to = SubmitUIOnly.class)
          ConsignmentDTO consignmentDTO,
      @Context UriInfo uriInfo) {
    log.info("createConsignment for tsdId/MRN/CRN {}", tsdId);
    TemporaryStorageDeclaration declaration =
        tsdService.getDeclaration(tsdId).orElseThrow(NotFoundException::new);
    Consignment createdConsignment =
        service.createConsignment(mapper.map(consignmentDTO), declaration);
    Long sequenceNumber = Long.valueOf(createdConsignment.getSequenceNumber());
    return Response.created(getLocation(uriInfo, sequenceNumber)).build();
  }

  /**
   *
   *
   * <h3>Update of existing Consignment</h3>
   *
   * Exposes API for updating of consignment for a draft TSD. Updating of consignment
   * (Master/House).
   *
   * <p>Ok (200) is synchronously sent back to the sender upon successful update of consignment.
   *
   * <p>Not Found (404) is synchronously sent back to the sender when the TSD or consignment is not
   * found in the system.
   *
   * <p>Bad Request (400) along with ValidationErrorProblem DTO is synchronously sent back to the
   * sender if the ConsignmentDTO is not compliant with the defined schema.
   *
   * <p>This REST resource is a Jersey implementation which produces and consumes {@link
   * MediaType#APPLICATION_JSON application/json} &amp; {@link MediaType#APPLICATION_XHTML_XML
   * application/xml} both.
   */
  @PUT
  @Path("{consignmentNbr}")
  @ApiResponseModify
  @RequireIfMatch
  public Response updateConsignment(
      @PathParam("tsdId") String tsdId,
      @PathParam("consignmentNbr") Integer consignmentSequenceNumber,
      @ConvertGroup(from = Default.class, to = UIOnly.class) @Valid @NotNull
          ConsignmentDTO consignmentDTO,
      @Context Request request) {
    log.info(
        "updateConsignment for tsdId/MRN/CRN {} and consignmentSequenceNumber {}",
        tsdId,
        consignmentSequenceNumber);
    TemporaryStorageDeclaration declaration =
        tsdService.getDeclaration(tsdId).orElseThrow(NotFoundException::new);
    declaration.checkCanModify();
    Consignment consignment =
        service
            .getConsignmentForUpdate(declaration.getId(), consignmentSequenceNumber)
            .orElseThrow(NotFoundException::new);
    Integer recordVersion = consignment.getVersion();
    // check if-match header
    ResponseBuilder response = request.evaluatePreconditions(eTag(consignment));
    if (response != null) {
      return response.build();
    }

    // map all fields which are not read only.
    mapper.mapIgnoreReadOnly(consignmentDTO, consignment);
    mapper.setBackReference(consignmentDTO, consignment);

    Consignment updatedConsignment = service.modifyConsignment(consignment);
    declaration.updateRegistrationDate();

    if (!recordVersion.equals(updatedConsignment.getVersion())) {
      return Response.ok().tag(eTag(updatedConsignment)).build();
    }

    return Response.ok().build();
  }

  @GET
  @Path("{consignmentNbr}")
  @ApiResponse(
      responseCode = "200",
      description = "Ok",
      content = @Content(schema = @Schema(implementation = ConsignmentDTO.class)))
  @ApiResponseGet
  public Response getConsignment(
      @PathParam("tsdId") String tsdId,
      @PathParam("consignmentNbr") Integer consignmentSequenceNumber,
      @DefaultValue("default") @QueryParam("fields") List<RequiredField> requiredFields,
      final @Context Request req) {
    log.info(
        "retrieveConsignment for tsdId/MRN/CRN {} and consignmentSequenceNumber {}",
        tsdId,
        consignmentSequenceNumber);
    Consignment consignment =
        service
            .getConsignment(tsdId, consignmentSequenceNumber)
            .orElseThrow(NotFoundException::new);

    ConsignmentDTO dto = mapper.map(consignment);

    AllowedSectionsDetail allowedSectionsDetail =
        service.calculateAllowedSections(tsdId, consignmentSequenceNumber, requiredFields);
    dto =
        dto.toBuilder()
            .allowedSections(consignmentBuilder.buildAllowedSections(allowedSectionsDetail))
            .tsdId(tsdId)
            .build(); // returning the same param back in self and links

    return Response.ok(dto).tag(eTag(consignment)).build();
  }

  @DELETE
  @Path("{consignmentNbr}")
  @ApiResponseDelete
  public Response removeConsignment(
      @PathParam("tsdId") String tsdId,
      @PathParam("consignmentNbr") Integer consignmentSequenceNumber) {
    log.info(
        "deleteConsignment for tsdId/MRN/CRN {} and consignmentSequenceNumber {}",
        tsdId,
        consignmentSequenceNumber);
    Consignment consignment =
        service
            .getConsignment(tsdId, consignmentSequenceNumber)
            .orElseThrow(NotFoundException::new);
    service.removeConsignment(consignment);

    return Response.ok().build();
  }

  @GET
  // Find consignments: projection, offset based paged
  @ApiResponse(responseCode = "404", description = "Not Found")
  @ApiResponseOk
  public ConsignmentProjectionDTO.Page findConsignments(
      @PathParam("tsdId") String tsdId,
      @Valid @BeanParam ConsignmentFilterDTO filter,
      @Context UriInfo uriInfo) {
    TemporaryStorageDeclaration declaration =
        tsdService.getDeclaration(tsdId).orElseThrow(NotFoundException::new);
    ConsignmentFilter consignmentFilter = mapper.map(filter);
    Page<ConsignmentProjection> page =
        service.findConsignments(declaration.getId(), consignmentFilter, filter.getPageable());
    List<ItemDraftError> itemDraftErrors =
        service.calculateItemDraftError(page.getContent(), consignmentFilter);
    Page<ConsignmentProjectionDTO> pageDTO = page.map(mapper::map);
    List<ConsignmentProjectionDTO> updatedContent =
        consignmentBuilder.buildItemDraftError(
            itemDraftErrors, pageDTO.getContent(), declaration.getId());
    return PageDTO.of(
        new PageImpl<>(updatedContent, pageDTO.getPageable(), pageDTO.getTotalElements()),
        uriInfo,
        ConsignmentProjectionDTO.Page.class);
  }

  // sub resource!
  @Path("{consignmentNbr}/items")
  @Hidden // need to hide nested resources from swagger
  public ConsignmentItemResource getConsignmentResource() {
    return consignmentItemResource;
  }
}
