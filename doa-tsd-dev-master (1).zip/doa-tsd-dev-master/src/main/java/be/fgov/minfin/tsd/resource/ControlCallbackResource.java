/*
 * @(#)be.fgov.minfin.tsd.resource.ControlCallbackResource.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */

package be.fgov.minfin.tsd.resource;

import be.fgov.minfin.tsd.domain.service.ControlService;
import be.fgov.minfin.tsd.resource.api.ReceiveControlResultDTO;
import be.fgov.minfin.tsd.resource.exception.ReceiveControlResultExceptionHandling;
import be.fgov.minfin.tsd.resource.mapper.TSDMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
@RequiredArgsConstructor
@ReceiveControlResultExceptionHandling
@Path("/controlCallback")
@Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
public class ControlCallbackResource {

  private final ControlService service;
  private final TSDMapper mapper;

  @POST
  @Path("/controlResults")
  @ApiResponse(responseCode = "200", description = "OK")
  @ApiResponse(responseCode = "400", description = "Bad Request")
  @Operation(summary = "Receive control result IETS444")
  public Response receiveControlResult(
      @NotNull @Valid ReceiveControlResultDTO receiveControlResult, @Context UriInfo uriInfo) {

    service.receiveControlResult(mapper.map(receiveControlResult));
    return Response.ok().build();
  }
}
