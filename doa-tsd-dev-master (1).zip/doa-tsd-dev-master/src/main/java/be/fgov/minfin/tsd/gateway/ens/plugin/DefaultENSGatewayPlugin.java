/*
 * @(#) be.fgov.minfin.tsd.gateway.ens.plugin.DefaultENSGatewayPlugin
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.ens.plugin;

import be.fgov.minfin.libdoa.commons.lang.Now;
import be.fgov.minfin.libdoa.exception.TechnicalException;
import be.fgov.minfin.tsd.config.ExpirationConfig;
import be.fgov.minfin.tsd.config.TSDConfig;
import be.fgov.minfin.tsd.config.TimerConfig;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.validation.CustomViolation;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import be.fgov.minfin.tsd.gateway.ens.exception.ReuseFailedException;
import be.fgov.minfin.tsd.gateway.ens.exception.ReuseFailedException.ReuseFailedType;
import be.fgov.minfin.tsd.resource.generator.CorrelationIdGenerator;
import eu.ec.xmlns.dataservice.ics.ensconsultationds.v1.CcnFault;
import eu.ec.xmlns.dataservice.ics.ensconsultationds.v1.ENSConsultationDS;
import eu.ec.xmlns.dataservice.ics.ensconsultationds.v1.ServiceFault;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.ws.WebServiceException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.annotation.DependsOn;
import org.springframework.stereotype.Component;
import wco.datamodel.wco.cis._1.ENSQueryParametersType;
import wco.datamodel.wco.cis._1.IE4Q10RequestType;
import wco.datamodel.wco.cis._1.IE4Q10Type;
import wco.datamodel.wco.cis._1.IE4R05ResponseType;
import wco.datamodel.wco.cis._1.IE4R05Type;
import wco.datamodel.wco.cis._1.MessageHeaderType;

/**
 * @author MohammadFaiz
 */
@Component
@Slf4j
@RequiredArgsConstructor
@DependsOn({"gatewayConfig"})
@ConditionalOnExpression(
    "#{T(java.util.Arrays).asList('${gateway.enabledDefaultPlugins}').contains('ENS')}")
public class DefaultENSGatewayPlugin implements ENSGatewayPlugin {

  private final ENSConsultationDS ensServiceClient;
  private final CorrelationIdGenerator correlationIdGenerator;

  private static final String ENS_REUSE_INDICATOR = "ensReuseIndicator";

  /** send IE4Q10 message */
  @Override
  public IE4R05Type getENS(TemporaryStorageDeclaration tsd) {
    IE4Q10Type request = prepareIE4Q10TypeRequest(tsd);
    log.info("Inside ensServiceClient message {}", request);

    IE4Q10RequestType requestType = new IE4Q10RequestType();
    IE4R05ResponseType reponse = new IE4R05ResponseType();
    requestType.setIE4Q10(request);
    try {
      reponse = ensServiceClient.queryENS(requestType);
      if (null == reponse.getIE4R05().getRelatedENS()) {
        Set<ConstraintViolation<TemporaryStorageDeclaration>> violations = new HashSet<>();
        violations.add(new CustomViolation<>(ErrorCode.TSPNESXXC0304, ENS_REUSE_INDICATOR));
        throw new ReuseFailedException(ReuseFailedType.FETCH_ENS_FAILED, violations.toArray());
      }
      return reponse.getIE4R05();
    } catch (CcnFault | ServiceFault | WebServiceException e) {
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations = new HashSet<>();
      violations.add(new CustomViolation<>(ErrorCode.TSPNESXXT0002, ENS_REUSE_INDICATOR));
      throw new ReuseFailedException(ReuseFailedType.FETCH_ENS_FAILED, violations.toArray(), e);
    }
  }

  public IE4Q10Type prepareIE4Q10TypeRequest(TemporaryStorageDeclaration tsd) {
    IE4Q10Type request = new IE4Q10Type();
    TSDConfig config = new TSDConfig(new TimerConfig(new ExpirationConfig()));

    MessageHeaderType messageHeader = new MessageHeaderType();
    messageHeader.setMessageId(correlationIdGenerator.generateCorrelationID());
    messageHeader.setCorrelationId(
        null != tsd.getMessageInformation()
            ? tsd.getMessageInformation().getCorrelationID()
            : null);
    messageHeader.setMessageSender(config.getTsdSystemName());
    messageHeader.setMessageRecipient(config.getRaiSystemName());
    messageHeader.setMessageTimestamp(
        convert(Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime()));
    request.setMessageHeader(messageHeader);

    request.setFunctionalReference(tsd.getLrn());
    if (null != tsd.getMasterConsignment()) {
      request.setMRN(tsd.getMasterConsignment().getPreviousDocument().getReferenceNumber());
    } else {
      request.setMRN(tsd.getHouseConsignments().get(0).getPreviousDocument().getReferenceNumber());
    }
    List<ENSQueryParametersType> ensQueryParameters = new ArrayList<>();
    ENSQueryParametersType queryParameter = new ENSQueryParametersType();
    queryParameter.setParameter("ENSC");
    ensQueryParameters.add(queryParameter);
    request.getENSQueryParameters().addAll(ensQueryParameters);
    return request;
  }

  /** Convert a LocalDateTime to an XMLGregorianCalendar using UTC zone */
  private XMLGregorianCalendar convert(LocalDateTime dateTime) {
    try {
      ZonedDateTime zoneDateTime = ZonedDateTime.of(dateTime, ZoneOffset.UTC);
      GregorianCalendar gregorianCalendar = GregorianCalendar.from(zoneDateTime);

      return DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalendar);
    } catch (DatatypeConfigurationException e) {
      throw new TechnicalException("Cannot convert localdateTime to XMLGregorianCalendar", e);
    }
  }
}
