/*
 * @(#) be.fgov.minfin.tsd.domain.validation.validator.ENSReuseValidator.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation.validator;

import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.consignment.HouseConsignment;
import be.fgov.minfin.tsd.domain.model.consignment.MasterConsignment;
import be.fgov.minfin.tsd.domain.model.consignment.PreviousDocument;
import be.fgov.minfin.tsd.domain.validation.CustomViolation;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import be.fgov.minfin.tsd.gateway.ens.exception.ReuseFailedException;
import be.fgov.minfin.tsd.gateway.ens.exception.ReuseFailedException.ReuseFailedType;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import javax.validation.ConstraintViolation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;
import wco.datamodel.wco.cis._1.ConsignmentHouseLevelType12;
import wco.datamodel.wco.cis._1.ConsignmentMasterLevelType12;

/**
 * This class is used to validate TSD minimal data set before ENS retrieval
 *
 * @author MohdSalim
 */
@Component
@Slf4j
@RequiredArgsConstructor
public class ENSReuseValidator {

  private static final String DOC_TYPE_N355 = "N355";
  public static final int NUMERIC_ZERO = 0;
  private static final String MASTER_CONSIGNMENT = "masterConsignment";
  private static final String HOUSE_CONSIGNMENT = "houseConsignments[";
  private static final String TOTAL_GROSS_MASS = ".totalGrossMass";
  private static final String CONSIGNOR = ".consignor";
  private static final String CONSIGNEE = ".consignee";
  private static final String REFERENCE_NUMBER_UCR = ".referenceNumberUCR";
  private static final String NOTIFY_PARTY = ".notifyParty";
  private static final String TRANSPORT_EQUIPMENT = ".transportEquipment[";
  private static final String RECEPTACLE = ".receptacle[";
  private static final String ADDITIONAL_INFORMATION = ".additionalInformation[";
  private static final String ADDI_SUPPLY_CHAIN_ACTOR = ".additionalSupplyChainActor[";
  private static final String SUPPORTING_DOCUMENT = ".supportingDocument[";
  private static final String ADDITIONAL_REFERENCE = ".additionalReference[";
  private static final String CONSIGNMENT_ITEM = ".consignmentItem[";
  private static final String ENS_REUSE_INDICATOR = "ensReuseIndicator";

  public void validateMinDataForReuse(final TemporaryStorageDeclaration tsd) {
    Set<ConstraintViolation<TemporaryStorageDeclaration>> violations = new HashSet<>();

    validateTotalGrossMass(tsd, violations);
    validateConsignor(tsd, violations);
    validateConsignee(tsd, violations);
    validateReferenceNumberUCR(tsd, violations);
    validateNotifyParty(tsd, violations);
    validateTransportEquipment(tsd, violations);
    validateReceptacle(tsd, violations);
    validateAdditionalInformation(tsd, violations);
    validateAdditionalSupplyChainActor(tsd, violations);
    validateSupportingDocument(tsd, violations);
    validateAdditionalReference(tsd, violations);
    validateConsignmentItem(tsd, violations);
    validatePreviousDocument(tsd, violations);

    if (log.isDebugEnabled()) {
      violations.stream()
          .forEach(
              v ->
                  log.info(
                      "violation with message {} and path {}",
                      v.getMessageTemplate(),
                      ((CustomViolation<TemporaryStorageDeclaration>) v).getPath()));
    }

    if (!violations.isEmpty()) {
      throw new ReuseFailedException(ReuseFailedType.MINIMAL_DATASET_FAILED, violations.toArray());
    }
  }

  /**
   * No Total Gross Mass is provided for the Consignment (Master Consignment or House Consignment)
   *
   * @param tsd
   * @param violations
   */
  private void validateTotalGrossMass(
      TemporaryStorageDeclaration tsd,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {

    AtomicInteger indexOfHouseConsignment = new AtomicInteger(NUMERIC_ZERO);

    if (Objects.nonNull(tsd.getMasterConsignment())
        && Objects.nonNull(tsd.getMasterConsignment().getTotalGrossMass())) {
      violations.add(
          new CustomViolation<>(ErrorCode.TSPNESXXC0098, MASTER_CONSIGNMENT + TOTAL_GROSS_MASS));
    }

    if (!CollectionUtils.isEmpty(tsd.getHouseConsignments())) {
      tsd.getHouseConsignments().stream()
          .forEach(
              x -> {
                if (x.getTotalGrossMass() != null) {
                  violations.add(
                      new CustomViolation<>(
                          ErrorCode.TSPNESXXC0098,
                          HOUSE_CONSIGNMENT
                              + indexOfHouseConsignment.getAndIncrement()
                              + "]"
                              + TOTAL_GROSS_MASS));
                } else {
                  indexOfHouseConsignment.getAndIncrement();
                }
              });
    }
  }

  /**
   * No Consigner class provided for the Consignment (Master Consignment or House Consignment)
   *
   * @param tsd
   * @param violations
   */
  private void validateConsignor(
      TemporaryStorageDeclaration tsd,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {

    AtomicInteger indexOfHouseConsignment = new AtomicInteger(NUMERIC_ZERO);

    if (Objects.nonNull(tsd.getMasterConsignment())
        && Objects.nonNull(tsd.getMasterConsignment().getConsignor())) {
      violations.add(
          new CustomViolation<>(ErrorCode.TSPNESXXC0098, MASTER_CONSIGNMENT + CONSIGNOR));
    }

    if (!CollectionUtils.isEmpty(tsd.getHouseConsignments())) {
      tsd.getHouseConsignments().stream()
          .forEach(
              x -> {
                if (x.getConsignor() != null) {
                  violations.add(
                      new CustomViolation<>(
                          ErrorCode.TSPNESXXC0098,
                          HOUSE_CONSIGNMENT
                              + indexOfHouseConsignment.getAndIncrement()
                              + "]"
                              + CONSIGNOR));
                } else {
                  indexOfHouseConsignment.getAndIncrement();
                }
              });
    }
  }

  /**
   * No Consignee class provided for the Consignment (Master Consignment or House Consignment)
   *
   * @param tsd
   * @param violations
   */
  private void validateConsignee(
      TemporaryStorageDeclaration tsd,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {

    AtomicInteger indexOfHouseConsignment = new AtomicInteger(NUMERIC_ZERO);

    if (Objects.nonNull(tsd.getMasterConsignment())
        && Objects.nonNull(tsd.getMasterConsignment().getConsignee())) {
      violations.add(
          new CustomViolation<>(ErrorCode.TSPNESXXC0098, MASTER_CONSIGNMENT + CONSIGNEE));
    }

    if (!CollectionUtils.isEmpty(tsd.getHouseConsignments())) {
      tsd.getHouseConsignments().stream()
          .forEach(
              x -> {
                if (x.getConsignee() != null) {
                  violations.add(
                      new CustomViolation<>(
                          ErrorCode.TSPNESXXC0098,
                          HOUSE_CONSIGNMENT
                              + indexOfHouseConsignment.getAndIncrement()
                              + "]"
                              + CONSIGNEE));
                } else {
                  indexOfHouseConsignment.getAndIncrement();
                }
              });
    }
  }

  /**
   * No Reference Number UCR is provided for the Consignment (Master Consignment or House
   * Consignment)
   *
   * @param tsd
   * @param violations
   */
  private void validateReferenceNumberUCR(
      TemporaryStorageDeclaration tsd,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {

    AtomicInteger indexOfHouseConsignment = new AtomicInteger(NUMERIC_ZERO);

    if (Objects.nonNull(tsd.getMasterConsignment())
        && Objects.nonNull(tsd.getMasterConsignment().getReferenceNumberUCR())) {
      violations.add(
          new CustomViolation<>(
              ErrorCode.TSPNESXXR0099, MASTER_CONSIGNMENT + REFERENCE_NUMBER_UCR));
    }

    if (!CollectionUtils.isEmpty(tsd.getHouseConsignments())) {
      tsd.getHouseConsignments().stream()
          .forEach(
              x -> {
                if (x.getReferenceNumberUCR() != null) {
                  violations.add(
                      new CustomViolation<>(
                          ErrorCode.TSPNESXXR0099,
                          HOUSE_CONSIGNMENT
                              + indexOfHouseConsignment.getAndIncrement()
                              + "]"
                              + REFERENCE_NUMBER_UCR));
                } else {
                  indexOfHouseConsignment.getAndIncrement();
                }
              });
    }
  }

  /**
   * No Notify Party class provided for the Consignment (Master Consignment or House Consignment)
   *
   * @param tsd
   * @param violations
   */
  private void validateNotifyParty(
      TemporaryStorageDeclaration tsd,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {

    AtomicInteger indexOfHouseConsignment = new AtomicInteger(NUMERIC_ZERO);
    if (Objects.nonNull(tsd.getMasterConsignment())
        && Objects.nonNull(tsd.getMasterConsignment().getNotifyParty())) {
      violations.add(
          new CustomViolation<>(ErrorCode.TSPNESXXR0099, MASTER_CONSIGNMENT + NOTIFY_PARTY));
    }

    if (!CollectionUtils.isEmpty(tsd.getHouseConsignments())) {
      tsd.getHouseConsignments().stream()
          .forEach(
              x -> {
                if (x.getNotifyParty() != null) {
                  violations.add(
                      new CustomViolation<>(
                          ErrorCode.TSPNESXXR0099,
                          HOUSE_CONSIGNMENT
                              + indexOfHouseConsignment.getAndIncrement()
                              + "]"
                              + NOTIFY_PARTY));
                } else {
                  indexOfHouseConsignment.getAndIncrement();
                }
              });
    }
  }

  /**
   * No Transport Equipment class provided for the Consignment (Master Consignment or House
   * Consignment)
   *
   * @param tsd
   * @param violations
   */
  private void validateTransportEquipment(
      TemporaryStorageDeclaration tsd,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {

    AtomicInteger indexOfHouseConsignment = new AtomicInteger(NUMERIC_ZERO);

    if (Objects.nonNull(tsd.getMasterConsignment())
        && !CollectionUtils.isEmpty(tsd.getMasterConsignment().getTransportEquipment())) {
      AtomicInteger transportConsignmentIndex = new AtomicInteger(NUMERIC_ZERO);
      tsd.getMasterConsignment().getTransportEquipment().stream()
          .forEach(
              x ->
                  violations.add(
                      new CustomViolation<>(
                          ErrorCode.TSPNESXXR0099,
                          MASTER_CONSIGNMENT
                              + TRANSPORT_EQUIPMENT
                              + transportConsignmentIndex.getAndIncrement()
                              + "]")));
    }

    if (!CollectionUtils.isEmpty(tsd.getHouseConsignments())) {
      tsd.getHouseConsignments().stream()
          .forEach(
              x -> {
                if (!CollectionUtils.isEmpty(x.getTransportEquipment())) {
                  AtomicInteger transportIndex = new AtomicInteger(NUMERIC_ZERO);
                  x.getTransportEquipment().stream()
                      .forEach(
                          y ->
                              violations.add(
                                  new CustomViolation<>(
                                      ErrorCode.TSPNESXXR0099,
                                      HOUSE_CONSIGNMENT
                                          + indexOfHouseConsignment.get()
                                          + "]"
                                          + TRANSPORT_EQUIPMENT
                                          + transportIndex.getAndIncrement()
                                          + "]")));
                }
                indexOfHouseConsignment.getAndIncrement();
              });
    }
  }

  /**
   * No Receptacle class provided for the Consignment (Master Consignment)
   *
   * @param tsd
   * @param violations
   */
  private void validateReceptacle(
      TemporaryStorageDeclaration tsd,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    if (Objects.nonNull(tsd.getMasterConsignment())
        && !CollectionUtils.isEmpty(tsd.getMasterConsignment().getReceptacle())) {
      AtomicInteger receptacleIndex = new AtomicInteger(NUMERIC_ZERO);
      tsd.getMasterConsignment().getReceptacle().stream()
          .forEach(
              x ->
                  violations.add(
                      new CustomViolation<>(
                          ErrorCode.TSPNESXXR0099,
                          MASTER_CONSIGNMENT
                              + RECEPTACLE
                              + receptacleIndex.getAndIncrement()
                              + "]")));
    }
  }

  /**
   * No Additional Information class provided for the Consignment (Master Consignment or House
   * Consignment)
   *
   * @param tsd
   * @param violations
   */
  private void validateAdditionalInformation(
      TemporaryStorageDeclaration tsd,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {

    AtomicInteger indexOfHouseConsignment = new AtomicInteger(NUMERIC_ZERO);

    if (Objects.nonNull(tsd.getMasterConsignment())
        && !CollectionUtils.isEmpty(tsd.getMasterConsignment().getAdditionalInformation())) {
      AtomicInteger additionalInformationIndex = new AtomicInteger(NUMERIC_ZERO);
      tsd.getMasterConsignment().getAdditionalInformation().stream()
          .forEach(
              x ->
                  violations.add(
                      new CustomViolation<>(
                          ErrorCode.TSPNESXXR0099,
                          MASTER_CONSIGNMENT
                              + ADDITIONAL_INFORMATION
                              + additionalInformationIndex.getAndIncrement()
                              + "]")));
    }

    if (!CollectionUtils.isEmpty(tsd.getHouseConsignments())) {
      tsd.getHouseConsignments().stream()
          .forEach(
              x -> {
                if (!CollectionUtils.isEmpty(x.getAdditionalInformation())) {
                  AtomicInteger additionalInformationIndex = new AtomicInteger(NUMERIC_ZERO);
                  x.getAdditionalInformation().stream()
                      .forEach(
                          y ->
                              violations.add(
                                  new CustomViolation<>(
                                      ErrorCode.TSPNESXXR0099,
                                      HOUSE_CONSIGNMENT
                                          + indexOfHouseConsignment.get()
                                          + "]"
                                          + ADDITIONAL_INFORMATION
                                          + additionalInformationIndex.getAndIncrement()
                                          + "]")));
                }
                indexOfHouseConsignment.getAndIncrement();
              });
    }
  }

  /**
   * No Additional Supply Chain Actor class provided for the Consignment (Master Consignment or
   * House Consignment)
   *
   * @param tsd
   * @param violations
   */
  private void validateAdditionalSupplyChainActor(
      TemporaryStorageDeclaration tsd,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {

    AtomicInteger indexOfHouseConsignment = new AtomicInteger(NUMERIC_ZERO);

    if (Objects.nonNull(tsd.getMasterConsignment())
        && !CollectionUtils.isEmpty(tsd.getMasterConsignment().getAdditionalSupplyChainActor())) {
      AtomicInteger additionalSupplyChainActorIndex = new AtomicInteger(NUMERIC_ZERO);
      tsd.getMasterConsignment().getAdditionalSupplyChainActor().stream()
          .forEach(
              x ->
                  violations.add(
                      new CustomViolation<>(
                          ErrorCode.TSPNESXXR0099,
                          MASTER_CONSIGNMENT
                              + ADDI_SUPPLY_CHAIN_ACTOR
                              + additionalSupplyChainActorIndex.getAndIncrement()
                              + "]")));
    }

    if (!CollectionUtils.isEmpty(tsd.getHouseConsignments())) {
      tsd.getHouseConsignments().stream()
          .forEach(
              x -> {
                if (!CollectionUtils.isEmpty(x.getAdditionalSupplyChainActor())) {
                  AtomicInteger additionalSupplyChainActorIndex = new AtomicInteger(NUMERIC_ZERO);
                  x.getAdditionalSupplyChainActor().stream()
                      .forEach(
                          y ->
                              violations.add(
                                  new CustomViolation<>(
                                      ErrorCode.TSPNESXXR0099,
                                      HOUSE_CONSIGNMENT
                                          + indexOfHouseConsignment.get()
                                          + "]"
                                          + ADDI_SUPPLY_CHAIN_ACTOR
                                          + additionalSupplyChainActorIndex.getAndIncrement()
                                          + "]")));
                }
                indexOfHouseConsignment.getAndIncrement();
              });
    }
  }

  /**
   * No Supporting Document class provided for the Consignment (Master Consignment or House
   * Consignment)
   *
   * @param tsd
   * @param violations
   */
  private void validateSupportingDocument(
      TemporaryStorageDeclaration tsd,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {

    AtomicInteger indexOfHouseConsignment = new AtomicInteger(NUMERIC_ZERO);

    if (Objects.nonNull(tsd.getMasterConsignment())
        && !CollectionUtils.isEmpty(tsd.getMasterConsignment().getSupportingDocument())) {
      AtomicInteger supportingDocumentIndex = new AtomicInteger(NUMERIC_ZERO);
      tsd.getMasterConsignment().getSupportingDocument().stream()
          .forEach(
              x ->
                  violations.add(
                      new CustomViolation<>(
                          ErrorCode.TSPNESXXR0099,
                          MASTER_CONSIGNMENT
                              + SUPPORTING_DOCUMENT
                              + supportingDocumentIndex.getAndIncrement()
                              + "]")));
    }

    if (!CollectionUtils.isEmpty(tsd.getHouseConsignments())) {
      tsd.getHouseConsignments().stream()
          .forEach(
              x -> {
                if (!CollectionUtils.isEmpty(x.getSupportingDocument())) {
                  AtomicInteger supportingDocumentIndex = new AtomicInteger(NUMERIC_ZERO);
                  x.getSupportingDocument().stream()
                      .forEach(
                          y ->
                              violations.add(
                                  new CustomViolation<>(
                                      ErrorCode.TSPNESXXR0099,
                                      HOUSE_CONSIGNMENT
                                          + indexOfHouseConsignment.get()
                                          + "]"
                                          + SUPPORTING_DOCUMENT
                                          + supportingDocumentIndex.getAndIncrement()
                                          + "]")));
                }
                indexOfHouseConsignment.getAndIncrement();
              });
    }
  }

  /**
   * No Additional Reference class provided for the Consignment (Master Consignment or House
   * Consignment)
   *
   * @param tsd
   * @param violations
   */
  private void validateAdditionalReference(
      TemporaryStorageDeclaration tsd,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {

    AtomicInteger indexOfHouseConsignment = new AtomicInteger(NUMERIC_ZERO);

    if (!CollectionUtils.isEmpty(tsd.getHouseConsignments())) {
      tsd.getHouseConsignments().stream()
          .forEach(
              x -> {
                if (!CollectionUtils.isEmpty(x.getAdditionalReference())) {
                  AtomicInteger addtionalReferenceIndex = new AtomicInteger(NUMERIC_ZERO);
                  x.getAdditionalReference().stream()
                      .forEach(
                          y ->
                              violations.add(
                                  new CustomViolation<>(
                                      ErrorCode.TSPNESXXR0099,
                                      HOUSE_CONSIGNMENT
                                          + indexOfHouseConsignment.get()
                                          + "]"
                                          + ADDITIONAL_REFERENCE
                                          + addtionalReferenceIndex.getAndIncrement()
                                          + "]")));
                }
                indexOfHouseConsignment.getAndIncrement();
              });
    }
  }

  /**
   * No Consignment item class provided for the Consignment (Master Consignment or House
   * Consignment)
   *
   * @param tsd
   * @param violations
   */
  private void validateConsignmentItem(
      TemporaryStorageDeclaration tsd,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {

    AtomicInteger indexOfHouseConsignment = new AtomicInteger(NUMERIC_ZERO);

    if (Objects.nonNull(tsd.getMasterConsignment())
        && !CollectionUtils.isEmpty(tsd.getMasterConsignment().getConsignmentItem())) {
      AtomicInteger consignmentItemIndex = new AtomicInteger(NUMERIC_ZERO);
      tsd.getMasterConsignment().getConsignmentItem().stream()
          .forEach(
              x ->
                  violations.add(
                      new CustomViolation<>(
                          ErrorCode.TSPNESXXR0099,
                          MASTER_CONSIGNMENT
                              + CONSIGNMENT_ITEM
                              + consignmentItemIndex.getAndIncrement()
                              + "]")));
    }

    if (!CollectionUtils.isEmpty(tsd.getHouseConsignments())) {
      tsd.getHouseConsignments().stream()
          .forEach(
              x -> {
                if (!CollectionUtils.isEmpty(x.getConsignmentItem())) {
                  AtomicInteger consignmentItemIndex = new AtomicInteger(NUMERIC_ZERO);
                  x.getConsignmentItem().stream()
                      .forEach(
                          y ->
                              violations.add(
                                  new CustomViolation<>(
                                      ErrorCode.TSPNESXXR0099,
                                      HOUSE_CONSIGNMENT
                                          + indexOfHouseConsignment.get()
                                          + "]"
                                          + CONSIGNMENT_ITEM
                                          + consignmentItemIndex.getAndIncrement()
                                          + "]")));
                }
                indexOfHouseConsignment.getAndIncrement();
              });
    }
  }

  /**
   * Exactly 1 PREVIOUS DOCUMENT of type ‘N355’ is required for each CONSIGNMENT. Additionally, the
   * PREVIOUS DOCUMENT (identified by ‘PREVIOUS DOCUMENT / Reference number’ and ‘PREVIOUS DOCUMENT
   * / Type’) needs to be unique throughout all CONSIGNMENTs.
   *
   * @param tsd
   * @param violations
   */
  private void validatePreviousDocument(
      TemporaryStorageDeclaration tsd,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {

    List<String> allReferences = new ArrayList<>();

    if (Objects.nonNull(tsd.getMasterConsignment())) {

      PreviousDocument previousDocumentMasterLvl = tsd.getMasterConsignment().getPreviousDocument();
      if (previousDocumentMasterLvl != null)
        allReferences.add(previousDocumentMasterLvl.getReferenceNumber());

      if (Objects.isNull(previousDocumentMasterLvl)
          || !previousDocumentMasterLvl.getType().equalsIgnoreCase(DOC_TYPE_N355)) {
        violations.add(new CustomViolation<>(ErrorCode.TSPNESXXR0100, ENS_REUSE_INDICATOR));
        return;
      }
    }

    if (!CollectionUtils.isEmpty(tsd.getHouseConsignments())) {
      tsd.getHouseConsignments().stream()
          .map(HouseConsignment::getPreviousDocument)
          .filter(Objects::nonNull)
          .forEach(x -> allReferences.add(x.getReferenceNumber()));
      List<HouseConsignment> houseConsItems =
          tsd.getHouseConsignments().stream()
              .filter(
                  x ->
                      Objects.isNull(x.getPreviousDocument())
                          || !x.getPreviousDocument().getType().equalsIgnoreCase(DOC_TYPE_N355))
              .collect(Collectors.toList());
      if (!CollectionUtils.isEmpty(houseConsItems)) {
        violations.add(new CustomViolation<>(ErrorCode.TSPNESXXR0100, ENS_REUSE_INDICATOR));
        return;
      }
    }

    boolean allEqual = allReferences.stream().distinct().count() == 1;

    if (!allEqual) {
      violations.add(new CustomViolation<>(ErrorCode.TSPNESXXR0100, ENS_REUSE_INDICATOR));
    }
  }

  public void businessValidationOnTransformedData(
      TemporaryStorageDeclaration declaration,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {

    checkAllConsignmentsHaveConsignor(declaration, violations);
    checkAllHouseConsigmentsHaveConsignee(declaration, violations);
  }

  private void checkAllHouseConsigmentsHaveConsignee(
      TemporaryStorageDeclaration declaration,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    if (!CollectionUtils.isEmpty(declaration.getHouseConsignments())) {
      List<HouseConsignment> list =
          declaration.getHouseConsignments().stream()
              .filter(x -> Objects.isNull(x.getConsignee()))
              .collect(Collectors.toList());
      if (!list.isEmpty()) {
        violations.add(new CustomViolation<>(ErrorCode.TSPNESXXR0102, ENS_REUSE_INDICATOR));
      }
      boolean isAnyHCMatch =
          declaration.getHouseConsignments().stream().anyMatch(x -> x.getTotalGrossMass() == null);
      if (isAnyHCMatch) {
        violations.add(new CustomViolation<>(ErrorCode.TSPNESXXR0152, ENS_REUSE_INDICATOR));
      }
    }
  }

  private void checkAllConsignmentsHaveConsignor(
      TemporaryStorageDeclaration declaration,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    if (declaration.getMasterConsignment() != null
        && declaration.getMasterConsignment().getConsignor() == null) {
      violations.add(new CustomViolation<>(ErrorCode.TSPNESXXR0101, ENS_REUSE_INDICATOR));
      if (declaration.getMasterConsignment().getTotalGrossMass() == null) {
        violations.add(new CustomViolation<>(ErrorCode.TSPNESXXR0152, ENS_REUSE_INDICATOR));
      }
      return;
    }
    if (!CollectionUtils.isEmpty(declaration.getHouseConsignments())) {
      List<HouseConsignment> list =
          declaration.getHouseConsignments().stream()
              .filter(x -> Objects.isNull(x.getConsignor()))
              .collect(Collectors.toList());
      if (!list.isEmpty()) {
        violations.add(new CustomViolation<>(ErrorCode.TSPNESXXR0101, ENS_REUSE_INDICATOR));
      }
    }
  }

  public void checkForHouseLevelViolations(
      List<HouseConsignment> houseConsignments,
      ConsignmentMasterLevelType12 masterConsignmentENS,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    if (Objects.isNull(masterConsignmentENS)
        || CollectionUtils.isEmpty(masterConsignmentENS.getConsignmentHouseLevel())) {
      violations.add(new CustomViolation<>(ErrorCode.TSPNESXXR0306, ENS_REUSE_INDICATOR));
      return;
    }

    for (HouseConsignment houseConsignment : houseConsignments) {
      boolean transportDocFound = false;
      for (ConsignmentHouseLevelType12 houseConsignmentENS :
          masterConsignmentENS.getConsignmentHouseLevel()) {
        if (houseConsignmentENS.getTransportDocumentHouseLevel() != null
            && houseConsignment
                .getTransportDocument()
                .getType()
                .equalsIgnoreCase(houseConsignmentENS.getTransportDocumentHouseLevel().getType())
            && houseConsignment
                .getTransportDocument()
                .getReferenceNumber()
                .equalsIgnoreCase(
                    houseConsignmentENS.getTransportDocumentHouseLevel().getDocumentNumber())) {
          transportDocFound = true;
          break;
        }
      }
      if (!transportDocFound) {
        violations.add(new CustomViolation<>(ErrorCode.TSPNESXXR0306, ENS_REUSE_INDICATOR));
        break;
      }
    }
  }

  public void checkForMasterLevelViolations(
      MasterConsignment masterConsignmentTSD,
      ConsignmentMasterLevelType12 masterConsignmentENS,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {

    if (Objects.isNull(masterConsignmentENS)
        || Objects.isNull(masterConsignmentENS.getTransportDocumentMasterLevel())) {
      violations.add(new CustomViolation<>(ErrorCode.TSPNESXXR0305, ENS_REUSE_INDICATOR));
      return;
    }

    if (!masterConsignmentTSD
            .getTransportDocument()
            .getType()
            .equalsIgnoreCase(masterConsignmentENS.getTransportDocumentMasterLevel().getType())
        || !masterConsignmentTSD
            .getTransportDocument()
            .getReferenceNumber()
            .equalsIgnoreCase(
                masterConsignmentENS.getTransportDocumentMasterLevel().getDocumentNumber())) {
      violations.add(new CustomViolation<>(ErrorCode.TSPNESXXR0305, ENS_REUSE_INDICATOR));
    }
  }
}
