/*
 * @(#)be.fgov.minfin.tsd.domain.converter.MRNConverter.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.converter;

import be.fgov.minfin.tsd.domain.generator.MRNGenerator;
import be.fgov.minfin.tsd.domain.model.MRN;
import java.util.Optional;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * Class to convert reference number to String to persist in DB
 *
 * @author GauravMitra
 */
@Converter(autoApply = true)
@RequiredArgsConstructor
@Component
public class MRNConverter implements AttributeConverter<MRN, String> {
  private final MRNGenerator mrnGenerator;

  @Override
  public String convertToDatabaseColumn(MRN refnumber) {

    if (Optional.ofNullable(refnumber).isEmpty()) {
      return null;
    } else if (Optional.ofNullable(refnumber).isPresent()
        && StringUtils.isNotBlank(refnumber.getMrnNumber())) {
      return refnumber.getMrnNumber();
    } else if (Optional.ofNullable(refnumber.getReferenceNumberMetadata()).isEmpty()) {
      throw new IllegalArgumentException(
          "refmetadata cannot be null while generating  Reference Number");
    } else {
      ReferenceNumberMetadataDTO metdataDTO =
          refnumber.getReferenceNumberMetadata().setReferenceNumberMetadata();
      String mrn = mrnGenerator.generateMRN(metdataDTO);
      refnumber.setMrnNumber(mrn);
      return mrn;
    }
  }

  @Override
  public MRN convertToEntityAttribute(String dbData) {
    if (dbData == null) {
      return null;
    }
    MRN mrn = new MRN();
    mrn.setMrnNumber(dbData);
    return mrn;
  }
}
