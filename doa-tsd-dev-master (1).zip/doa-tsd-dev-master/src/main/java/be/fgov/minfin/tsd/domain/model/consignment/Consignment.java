/*
 * @(#) be.fgov.minfin.tsd.domain.model.consignment.Consignment.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model.consignment;

import be.fgov.minfin.libdoa.entities.VersionedAuditableEntity;
import be.fgov.minfin.tsd.domain.converter.ConsignmentGeneralInformationDraftErrorConverter;
import be.fgov.minfin.tsd.domain.converter.ConsignmentPartiesDraftErrorConverter;
import be.fgov.minfin.tsd.domain.model.ConsignmentLocationOfGoods;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.party.Person;
import be.fgov.minfin.tsd.domain.validation.annotation.NumberCompare;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import be.fgov.minfin.tsd.domain.validation.annotation.group.DeconsolidationNotificationValidatorGroup;
import be.fgov.minfin.tsd.domain.validation.annotation.group.NonDraftTSD;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import be.fgov.minfin.tsd.util.NumberCompareType;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonSubTypes.Type;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import java.math.BigDecimal;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.groups.Default;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.LazyToOne;
import org.hibernate.annotations.LazyToOneOption;

@Getter
@Setter
@ToString(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Builder
@Table(name = "CONSIGNMENT")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "CONSIGNMENT_TYPE")
@ValidateBusinessRules(groups = {Default.class, DeconsolidationNotificationValidatorGroup.class})
@EqualsAndHashCode(
    exclude = {
      "transportEquipment",
      "additionalInformation",
      "supportingDocument",
      "additionalSupplyChainActor",
      "consignmentItem"
    })
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "type")
@JsonSubTypes({
  @Type(value = MasterConsignment.class, name = "masterConsignment"),
  @Type(value = HouseConsignment.class, name = "houseConsignment")
})
@org.hibernate.annotations.DiscriminatorOptions(force = true)
public class Consignment extends VersionedAuditableEntity<Long> implements HasPreviousDocument {
  @GeneratedValue(generator = "CONSIGNMENT_SEQ")
  @SequenceGenerator(name = "CONSIGNMENT_SEQ", sequenceName = "CONSIGNMENT_SEQ")
  @Id
  private Long id;

  private Integer sequenceNumber;

  @Convert(converter = ConsignmentGeneralInformationDraftErrorConverter.class)
  private ConsignmentGeneralInformationDraftError generalInformationDraftError;

  @Convert(converter = ConsignmentPartiesDraftErrorConverter.class)
  private ConsignmentPartiesDraftError partiesDraftError;

  @Valid @Embedded private PreviousDocument previousDocument;

  @NotNull(groups = NonDraftTSD.class)
  @Valid
  @Embedded
  private TransportDocument transportDocument;

  @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "CONSIGNOR_ID")
  @ToString.Exclude
  private @Valid Person consignor;

  @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "CONSIGNEE_ID")
  @ToString.Exclude
  private @Valid Person consignee;

  @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "NOTIFY_PARTY_ID")
  @ToString.Exclude
  private @Valid Person notifyParty;

  @NumberCompare(
      numberCompareType = NumberCompareType.GREATER_THAN,
      value = 0,
      groups = {Default.class, DeconsolidationNotificationValidatorGroup.class},
      errorCode = ErrorCode.TSPNESXXR0054)
  private BigDecimal totalGrossMass;

  @Column(name = "REFERENCE_NUMBER_UCR")
  private String referenceNumberUCR;

  @OneToMany(
      cascade = {CascadeType.PERSIST, CascadeType.MERGE},
      orphanRemoval = true,
      mappedBy = "consignment")
  @ToString.Exclude
  @JsonManagedReference(value = "consignment")
  private List<@Valid TransportEquipment> transportEquipment;

  @OneToMany(
      cascade = {CascadeType.PERSIST, CascadeType.MERGE},
      orphanRemoval = true,
      mappedBy = "consignment")
  @ToString.Exclude
  @JsonManagedReference(value = "consignment")
  private List<@Valid AdditionalInformation> additionalInformation;

  @OneToMany(
      cascade = {CascadeType.PERSIST, CascadeType.MERGE},
      orphanRemoval = true,
      mappedBy = "consignment")
  @ToString.Exclude
  @JsonManagedReference(value = "consignment")
  private List<@Valid SupportingDocument> supportingDocument;

  @OneToMany(
      cascade = {CascadeType.PERSIST, CascadeType.MERGE},
      orphanRemoval = true,
      mappedBy = "consignment")
  @ToString.Exclude
  @JsonManagedReference(value = "consignment")
  private List<@Valid AdditionalSupplyChainActor> additionalSupplyChainActor;

  @OneToMany(
      cascade = {CascadeType.PERSIST, CascadeType.MERGE},
      orphanRemoval = true,
      mappedBy = "consignment")
  @ToString.Exclude
  @JsonManagedReference(value = "consignment")
  private List<@Valid ConsignmentItem> consignmentItem;

  @ToString.Exclude
  @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
  @LazyToOne(LazyToOneOption.PROXY)
  @JoinColumn(name = "CURRENT_CON_LOC_GOODS_ID")
  private ConsignmentLocationOfGoods currentConsignmentLocationOfGoods;

  @JsonIgnore
  public TemporaryStorageDeclaration getDeclaration() {
    throw new UnsupportedOperationException();
  }
}
