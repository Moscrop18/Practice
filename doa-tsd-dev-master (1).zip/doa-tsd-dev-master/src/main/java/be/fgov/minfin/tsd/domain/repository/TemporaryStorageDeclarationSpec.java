/*
 * @(#) be.fgov.minfin.tsd.domain.repository.TSDepository
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.repository;

import static org.apache.commons.lang3.StringUtils.isEmpty;
import static org.springframework.data.jpa.domain.Specification.where;

import be.fgov.minfin.libdoa.pagination.CursorSpecification;
import be.fgov.minfin.libdoa.pagination.types.DateIdCursor;
import be.fgov.minfin.tsd.domain.model.ConsignmentLocationOfGoods;
import be.fgov.minfin.tsd.domain.model.ConsignmentLocationOfGoods_;
import be.fgov.minfin.tsd.domain.model.CustomsOffice_;
import be.fgov.minfin.tsd.domain.model.ReferenceNumber;
import be.fgov.minfin.tsd.domain.model.ReferenceNumber_;
import be.fgov.minfin.tsd.domain.model.TSDStatus;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclarationFilter;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration_;
import be.fgov.minfin.tsd.domain.model.consignment.ArrivalTransportMeans_;
import be.fgov.minfin.tsd.domain.model.consignment.Carrier_;
import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentHeader;
import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentHeader_;
import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentItem;
import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentItem_;
import be.fgov.minfin.tsd.domain.model.consignment.Consignment_;
import be.fgov.minfin.tsd.domain.model.consignment.HouseConsignment;
import be.fgov.minfin.tsd.domain.model.consignment.LocationOfGoods;
import be.fgov.minfin.tsd.domain.model.consignment.LocationOfGoods_;
import be.fgov.minfin.tsd.domain.model.consignment.MasterConsignment;
import be.fgov.minfin.tsd.domain.model.consignment.MasterConsignment_;
import be.fgov.minfin.tsd.domain.model.consignment.Receptacle;
import be.fgov.minfin.tsd.domain.model.consignment.Receptacle_;
import be.fgov.minfin.tsd.domain.model.consignment.TransportDocument_;
import be.fgov.minfin.tsd.domain.model.consignment.TransportEquipment;
import be.fgov.minfin.tsd.domain.model.consignment.TransportEquipment_;
import be.fgov.minfin.tsd.domain.model.consignment.Warehouse_;
import be.fgov.minfin.tsd.domain.model.party.Party;
import be.fgov.minfin.tsd.domain.model.party.Party_;
import be.fgov.minfin.tsd.domain.model.party.PersonPresentingTheGoods_;
import be.fgov.minfin.tsd.domain.model.party.Representative;
import be.fgov.minfin.tsd.domain.model.risk.RiskAndControlStatus;
import java.time.LocalDateTime;
import java.util.List;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import org.springframework.data.jpa.domain.Specification;

/**
 * Class containing all specifications which are used to query TemporaryStorageDeclaration Objects.
 *
 * @author MohdSalim
 */
public class TemporaryStorageDeclarationSpec {

  private TemporaryStorageDeclarationSpec() {}

  private static Specification<TemporaryStorageDeclaration> lrnEquals(String lrn) {
    if (isEmpty(lrn)) {
      return null;
    }
    return (root, query, cb) -> cb.equal(root.get(TemporaryStorageDeclaration_.lrn), lrn);
  }

  public static Specification<TemporaryStorageDeclaration> cursorAfter(DateIdCursor cursor) {
    if (cursor == null) {
      return null;
    }

    return (root, query, cb) ->
        cb.or(
            cb.greaterThan(
                root.get(TemporaryStorageDeclaration_.registrationDate), cursor.getDate()),
            cb.and(
                cb.equal(root.get(TemporaryStorageDeclaration_.registrationDate), cursor.getDate()),
                cb.greaterThan(root.get(TemporaryStorageDeclaration_.id), cursor.getId())));
  }

  public static Specification<TemporaryStorageDeclaration> cursorBefore(DateIdCursor cursor) {
    if (cursor == null) {
      return null;
    }
    return (root, query, cb) ->
        cb.or(
            cb.lessThan(root.get(TemporaryStorageDeclaration_.registrationDate), cursor.getDate()),
            cb.and(
                cb.equal(root.get(TemporaryStorageDeclaration_.registrationDate), cursor.getDate()),
                cb.lessThan(root.get(TemporaryStorageDeclaration_.id), cursor.getId())));
  }

  private static Specification<TemporaryStorageDeclaration> registrationDateAfter(
      LocalDateTime date) {
    if (date == null) {
      return null;
    }
    return (root, query, cb) ->
        cb.greaterThanOrEqualTo(root.get(TemporaryStorageDeclaration_.registrationDate), date);
  }

  private static Specification<TemporaryStorageDeclaration> registrationDateBefore(
      LocalDateTime date) {
    if (date == null) {
      return null;
    }
    return (root, query, cb) ->
        cb.lessThanOrEqualTo(root.get(TemporaryStorageDeclaration_.registrationDate), date);
  }

  private static Specification<TemporaryStorageDeclaration> presentationDateAfter(
      LocalDateTime date) {
    if (date == null) {
      return null;
    }
    return (root, query, cb) ->
        cb.greaterThanOrEqualTo(
            root.get(TemporaryStorageDeclaration_.dateAndTimeOfPresentationOfTheGoods), date);
  }

  private static Specification<TemporaryStorageDeclaration> presentationDateBefore(
      LocalDateTime date) {
    if (date == null) {
      return null;
    }
    return (root, query, cb) ->
        cb.lessThanOrEqualTo(
            root.get(TemporaryStorageDeclaration_.dateAndTimeOfPresentationOfTheGoods), date);
  }

  private static Specification<TemporaryStorageDeclaration> arrivalTransportMeansEquals(
      String arrivalTransportMeans) {
    if (isEmpty(arrivalTransportMeans)) {
      return null;
    }
    return (root, query, cb) ->
        cb.equal(
            root.get(TemporaryStorageDeclaration_.consignmentHeader)
                .get(ConsignmentHeader_.arrivalTransportMeans)
                .get(ArrivalTransportMeans_.identificationNumber),
            arrivalTransportMeans);
  }

  private static Specification<TemporaryStorageDeclaration> eoriDeclarantEquals(
      Join<TemporaryStorageDeclaration, Party> declarantJoin, String declarant) {
    if (isEmpty(declarant)) {
      return null;
    }
    return (root, query, cb) -> cb.equal(declarantJoin.get(Party_.identificationNumber), declarant);
  }

  private static Specification<TemporaryStorageDeclaration> eoriRepresentativeEquals(
      Join<TemporaryStorageDeclaration, Representative> representativeJoin, String representative) {
    if (isEmpty(representative)) {
      return null;
    }
    return (root, query, cb) ->
        cb.equal(representativeJoin.get(Party_.identificationNumber), representative);
  }

  private static Specification<TemporaryStorageDeclaration> eoriPresonPresentingTheGoodsEquals(
      String presonPresentingTheGoods) {
    if (isEmpty(presonPresentingTheGoods)) {
      return null;
    }
    return (root, query, cb) ->
        cb.equal(
            root.get(TemporaryStorageDeclaration_.personPresentingTheGoods)
                .get(PersonPresentingTheGoods_.identificationNumber),
            presonPresentingTheGoods);
  }

  private static Specification<TemporaryStorageDeclaration> eoriCarrierEquals(String carrier) {
    if (isEmpty(carrier)) {
      return null;
    }
    return (root, query, cb) ->
        cb.equal(
            root.get(TemporaryStorageDeclaration_.consignmentHeader)
                .get(ConsignmentHeader_.carrier)
                .get(Carrier_.identificationNumber),
            carrier);
  }

  private static Join<ConsignmentHeader, LocationOfGoods> declaredLocationOfGoodsJoin(
      Root<TemporaryStorageDeclaration> root) {
    return root.join(TemporaryStorageDeclaration_.consignmentHeader)
        .join(ConsignmentHeader_.decalaredlocationOfGoods, JoinType.LEFT);
  }

  private static Specification<TemporaryStorageDeclaration> eoriPartyEquals(
      Join<TemporaryStorageDeclaration, Party> declarantJoin,
      Join<TemporaryStorageDeclaration, Representative> representativeJoin,
      String declarant,
      String representative,
      String presonPresentingTheGoods,
      String carrier) {
    return Specification.where(eoriDeclarantEquals(declarantJoin, declarant))
        .or(eoriRepresentativeEquals(representativeJoin, representative))
        .or(eoriPresonPresentingTheGoodsEquals(presonPresentingTheGoods))
        .or(eoriCarrierEquals(carrier));
  }

  private static Specification<TemporaryStorageDeclaration> otherConsignmentRelatedFieldEquals(
      TemporaryStorageDeclarationFilter filter) {
    return (root, query, cb) -> {
      if (isEmpty(filter.getTransportDocument())
          && isEmpty(filter.getContainerOrReceptacle())
          && isEmpty(filter.getSupervisingOfficeRefNum())
          && isEmpty(filter.getLocationOfGoodsUnLoCode())
          && isEmpty(filter.getWarehouseIdentifier())) {
        return null;
      }

      Join<TemporaryStorageDeclaration, MasterConsignment> masterConsJoin =
          root.join(TemporaryStorageDeclaration_.masterConsignment, JoinType.LEFT);
      Join<TemporaryStorageDeclaration, HouseConsignment> houseConsJoin =
          root.join(TemporaryStorageDeclaration_.houseConsignments, JoinType.LEFT);

      Predicate transportDocumentPredicate =
          transportDocumentPredicate(
              cb, masterConsJoin, houseConsJoin, filter.getTransportDocument());

      Predicate containerOrRecepPred =
          containerOrReceptaclePredicate(
              filter.getContainerOrReceptacle(), query, cb, masterConsJoin, houseConsJoin);

      Predicate supervisingAndUnlocodeAndWarehousePred =
          supervisingAndUnlocodeAndWarehousePredicate(
              root, cb, masterConsJoin, houseConsJoin, filter);

      return allPossibleCobinationOfPreds(
          cb,
          query,
          transportDocumentPredicate,
          containerOrRecepPred,
          supervisingAndUnlocodeAndWarehousePred);
    };
  }

  /***
   * if current status of the TSD = 'Draft'
   * Supervising customs office reference number → Supervising customs office (TSD (version) level)
   * Location of goods unlocode → Declared location of goods unlocode (TSD (version) level)
   * Warehouse identifier → Warehouse identifier (TSD (version) level)
   *
   *
   * if "current status of the TSD" <> 'Draft' (different value(s) or empty)
   * Supervising customs office reference number → Supervising customs office (TSD (current version) level) OR Consignment location of goods supervising customs office for the TSD (current version) consignment
   * Location of goods unlocode → Declared location of goods unlocode (TSD (current version) level) OR Consignment location of goods unlocode of the TSD (current version) consignment
   * Warehouse identifier → Warehouse identifier (TSD (current version) level) OR Consignment location of goods Warehouse identifier of the TSD (current version) consignment
   *
   * @param root
   * @param cb
   * @param masterConsJoin
   * @param houseConsJoin
   * @param f - filters
   *
   * @return predicate
   */

  private static Predicate supervisingAndUnlocodeAndWarehousePredicate(
      Root<TemporaryStorageDeclaration> root,
      CriteriaBuilder cb,
      Join<TemporaryStorageDeclaration, MasterConsignment> masterConsJoin,
      Join<TemporaryStorageDeclaration, HouseConsignment> houseConsJoin,
      TemporaryStorageDeclarationFilter f) {

    if (isEmpty(f.getSupervisingOfficeRefNum())
        && isEmpty(f.getLocationOfGoodsUnLoCode())
        && isEmpty(f.getWarehouseIdentifier())
        && isEmpty(f.getPresentationOfficeRefNum())) {
      return null;
    }

    if (!f.getStatus().isEmpty() && f.getStatus().contains(TSDStatus.DRAFT)) {

      Predicate warehousePred = wareHouseTDSPredicate(root, cb, f.getWarehouseIdentifier());

      Predicate superviseOfficePred =
          supervisingOfficeTSDPredicate(root, cb, f.getSupervisingOfficeRefNum());

      Predicate presentationOfficeRefNumPred =
          tsdPresentationOfficeRefNumPredicate(root, cb, f.getPresentationOfficeRefNum());

      Predicate supervisingOrPresentationPred =
          supervisingOrPresentationPred(cb, superviseOfficePred, presentationOfficeRefNumPred);

      Predicate locationUnloCodePred =
          declaredLocationTSDPredicate(cb, root, f.getLocationOfGoodsUnLoCode());

      return possibleCobinationOfPreds(
          cb, locationUnloCodePred, supervisingOrPresentationPred, warehousePred);

    } else if (f.getStatus().isEmpty() || !f.getStatus().contains(TSDStatus.DRAFT)) {

      Join<MasterConsignment, ConsignmentLocationOfGoods> masterConsignmentLocationJoin =
          masterConsJoin.join(Consignment_.currentConsignmentLocationOfGoods, JoinType.LEFT);

      Join<HouseConsignment, ConsignmentLocationOfGoods> houseConsignmentLocationJoin =
          houseConsJoin.join(Consignment_.currentConsignmentLocationOfGoods, JoinType.LEFT);

      // Supervising customs office reference number at consignment level

      Predicate supervisingPred =
          supervisingCustomsOfficeConsPredicate(
              root,
              cb,
              masterConsignmentLocationJoin,
              houseConsignmentLocationJoin,
              f.getSupervisingOfficeRefNum());

      Predicate presentationOfficeRefNumPre =
          tsdPresentationOfficeRefNumPredicate(root, cb, f.getPresentationOfficeRefNum());
      Predicate supervisingOrPresentationPred =
          supervisingOrPresentationPred(cb, supervisingPred, presentationOfficeRefNumPre);

      // Location of goods unlocode at consignment level

      Predicate locationUnloCodePred =
          locationOfGoodsUnlocodeConsPredicate(
              root,
              cb,
              masterConsignmentLocationJoin,
              houseConsignmentLocationJoin,
              f.getLocationOfGoodsUnLoCode());

      // Warehouse identifier at consignment level

      Predicate warehousePred =
          warehouseIdentifierConsPredicate(
              root,
              cb,
              masterConsignmentLocationJoin,
              houseConsignmentLocationJoin,
              f.getWarehouseIdentifier());

      return possibleCobinationOfPreds(
          cb, locationUnloCodePred, supervisingOrPresentationPred, warehousePred);
    }
    return null;
  }

  private static Predicate declaredLocationTSDPredicate(
      CriteriaBuilder cb, Root<TemporaryStorageDeclaration> root, String locationOfGoodsUnLoCode) {
    if (isEmpty(locationOfGoodsUnLoCode)) {
      return null;
    }

    Join<ConsignmentHeader, LocationOfGoods> declaredLocationJoin =
        declaredLocationOfGoodsJoin(root);

    Predicate locationUnloCodePred;
    locationUnloCodePred =
        cb.equal(declaredLocationJoin.get(LocationOfGoods_.unLoCode), locationOfGoodsUnLoCode);
    return locationUnloCodePred;
  }

  private static Predicate supervisingOfficeTSDPredicate(
      Root<TemporaryStorageDeclaration> root, CriteriaBuilder cb, String supervisingOfficeRefNum) {
    if (isEmpty(supervisingOfficeRefNum)) {
      return null;
    }
    Predicate superviseOfficePred;
    superviseOfficePred =
        cb.equal(
            root.get(TemporaryStorageDeclaration_.supervisingCustomsOffice)
                .get(CustomsOffice_.referenceNumber),
            supervisingOfficeRefNum);
    return superviseOfficePred;
  }

  private static Predicate wareHouseTDSPredicate(
      Root<TemporaryStorageDeclaration> root, CriteriaBuilder cb, String warehouseIdentifier) {

    if (isEmpty(warehouseIdentifier)) {
      return null;
    }

    Predicate warehousePred;
    warehousePred =
        cb.equal(
            root.get(TemporaryStorageDeclaration_.consignmentHeader)
                .get(ConsignmentHeader_.warehouse)
                .get(Warehouse_.identifier),
            warehouseIdentifier);
    return warehousePred;
  }

  /***
   *  Adding all the predicates in and condition of the select query
   *
   * @param cb
   * @param query
   * @param transportDocumentPredicate
   * @param containerOrRecepPred
   * @param supervisingAndUnlocodeAndWarehousePred
   * @return
   */
  private static Predicate allPossibleCobinationOfPreds(
      CriteriaBuilder cb,
      CriteriaQuery<?> query,
      Predicate transportDocumentPredicate,
      Predicate containerOrRecepPred,
      Predicate supervisingAndUnlocodeAndWarehousePred) {

    query.distinct(true);
    if (transportDocumentPredicate != null
        && containerOrRecepPred != null
        && supervisingAndUnlocodeAndWarehousePred != null) {
      return cb.and(
          transportDocumentPredicate, containerOrRecepPred, supervisingAndUnlocodeAndWarehousePred);
    } else if (containerOrRecepPred != null && supervisingAndUnlocodeAndWarehousePred != null) {
      return cb.and(containerOrRecepPred, supervisingAndUnlocodeAndWarehousePred);
    } else if (transportDocumentPredicate != null && containerOrRecepPred != null) {
      return cb.and(transportDocumentPredicate, containerOrRecepPred);
    } else if (transportDocumentPredicate != null
        && supervisingAndUnlocodeAndWarehousePred != null) {
      return cb.and(transportDocumentPredicate, supervisingAndUnlocodeAndWarehousePred);
    } else if (transportDocumentPredicate != null) {
      return cb.and(transportDocumentPredicate);
    } else if (containerOrRecepPred != null) {
      return cb.and(containerOrRecepPred);
    } else {
      return cb.and(supervisingAndUnlocodeAndWarehousePred);
    }
  }

  private static Predicate transportDocumentPredicate(
      CriteriaBuilder cb,
      Join<TemporaryStorageDeclaration, MasterConsignment> masterConsJoin,
      Join<TemporaryStorageDeclaration, HouseConsignment> houseConsJoin,
      String transportDocument) {

    if (isEmpty(transportDocument)) {
      return null;
    }

    Predicate masterTransportDocPred =
        cb.equal(
            masterConsJoin
                .get(Consignment_.transportDocument)
                .get(TransportDocument_.referenceNumber),
            transportDocument);
    Predicate houseTransportDocPred =
        cb.equal(
            houseConsJoin
                .get(Consignment_.transportDocument)
                .get(TransportDocument_.referenceNumber),
            transportDocument);
    return cb.or(masterTransportDocPred, houseTransportDocPred);
  }

  private static Predicate supervisingOrPresentationPred(
      CriteriaBuilder cb, Predicate superviseOfficePred, Predicate presentationOfficeRefNumPred) {
    if (superviseOfficePred != null && presentationOfficeRefNumPred != null) {
      return cb.or(superviseOfficePred, presentationOfficeRefNumPred);
    } else if (presentationOfficeRefNumPred != null) {
      return cb.or(presentationOfficeRefNumPred);
    } else if (superviseOfficePred != null) {
      return cb.or(superviseOfficePred);
    } else {
      return null;
    }
  }

  private static Predicate possibleCobinationOfPreds(
      CriteriaBuilder cb,
      Predicate unlocodePred,
      Predicate supervisingPred,
      Predicate warehousePred) {
    if (unlocodePred != null && supervisingPred != null && warehousePred != null) {
      return cb.and(unlocodePred, supervisingPred, warehousePred);
    } else if (supervisingPred != null && warehousePred != null) {
      return cb.and(supervisingPred, warehousePred);
    } else if (unlocodePred != null && supervisingPred != null) {
      return cb.and(unlocodePred, supervisingPred);
    } else if (unlocodePred != null && warehousePred != null) {
      return cb.and(unlocodePred, warehousePred);
    } else if (unlocodePred != null) {
      return cb.and(unlocodePred);
    } else if (supervisingPred != null) {
      return cb.and(supervisingPred);
    } else {
      return cb.and(warehousePred);
    }
  }

  /***
   *
   * added filter of warehouse Identifier predicate with tsd or master/ house Consignment level
   *
   * @param root
   * @param cb
   * @param masterConsignmentLocationJoin
   * @param houseConsignmentLocationJoin
   * @param warehouseIdentifier
   * @return
   */
  private static Predicate warehouseIdentifierConsPredicate(
      Root<TemporaryStorageDeclaration> root,
      CriteriaBuilder cb,
      Join<MasterConsignment, ConsignmentLocationOfGoods> masterConsignmentLocationJoin,
      Join<HouseConsignment, ConsignmentLocationOfGoods> houseConsignmentLocationJoin,
      String warehouseIdentifier) {

    if (isEmpty(warehouseIdentifier)) {
      return null;
    }
    Predicate warehouseTSDPred = wareHouseTDSPredicate(root, cb, warehouseIdentifier);

    Predicate warehouseMasterPred =
        cb.equal(
            masterConsignmentLocationJoin
                .get(ConsignmentLocationOfGoods_.warehouse)
                .get(Warehouse_.identifier),
            warehouseIdentifier);

    Predicate warehouseHousePred =
        cb.equal(
            houseConsignmentLocationJoin
                .get(ConsignmentLocationOfGoods_.warehouse)
                .get(Warehouse_.identifier),
            warehouseIdentifier);

    return cb.or(warehouseTSDPred, warehouseMasterPred, warehouseHousePred);
  }

  /***
   * added filter of locationOfGoods Unlocode predicate with tsd or master/ house Consignment level
   * with declaredLocationOfGoodsJoin
   *
   * @param root
   * @param cb
   * @param masterConsignmentLocationJoin
   * @param houseConsignmentLocationJoin
   * @param locationOfGoodsUnLoCode
   * @return
   */
  private static Predicate locationOfGoodsUnlocodeConsPredicate(
      Root<TemporaryStorageDeclaration> root,
      CriteriaBuilder cb,
      Join<MasterConsignment, ConsignmentLocationOfGoods> masterConsignmentLocationJoin,
      Join<HouseConsignment, ConsignmentLocationOfGoods> houseConsignmentLocationJoin,
      String locationOfGoodsUnLoCode) {

    if (isEmpty(locationOfGoodsUnLoCode)) {
      return null;
    }

    Predicate declaredLocationPred =
        declaredLocationTSDPredicate(cb, root, locationOfGoodsUnLoCode);

    Join<ConsignmentLocationOfGoods, LocationOfGoods> masterConsLocationOfGoodsJoin =
        masterConsignmentLocationJoin.join(
            ConsignmentLocationOfGoods_.transferredLocationOfGoods, JoinType.LEFT);

    Join<ConsignmentLocationOfGoods, LocationOfGoods> houseConsLocationOfGoodsJoin =
        houseConsignmentLocationJoin.join(
            ConsignmentLocationOfGoods_.transferredLocationOfGoods, JoinType.LEFT);

    Predicate unLoCodeMasterPred =
        cb.equal(
            masterConsLocationOfGoodsJoin.get(LocationOfGoods_.unLoCode), locationOfGoodsUnLoCode);

    Predicate unLoCodeHousePred =
        cb.equal(
            houseConsLocationOfGoodsJoin.get(LocationOfGoods_.unLoCode), locationOfGoodsUnLoCode);

    return cb.or(declaredLocationPred, unLoCodeMasterPred, unLoCodeHousePred);
  }

  /***
   * added filter of supervisingCustomsOffice predicate with tsd or master/ house Consignment level
   *
   * @param root
   * @param cb
   * @param masterConsignmentLocationJoin
   * @param houseConsignmentLocationJoin
   * @param supervisingOfficeRefNum
   * @return
   */

  private static Predicate supervisingCustomsOfficeConsPredicate(
      Root<TemporaryStorageDeclaration> root,
      CriteriaBuilder cb,
      Join<MasterConsignment, ConsignmentLocationOfGoods> masterConsignmentLocationJoin,
      Join<HouseConsignment, ConsignmentLocationOfGoods> houseConsignmentLocationJoin,
      String supervisingOfficeRefNum) {

    if (isEmpty(supervisingOfficeRefNum)) {
      return null;
    }
    Predicate superviseOfficePred =
        supervisingOfficeTSDPredicate(root, cb, supervisingOfficeRefNum);

    Predicate masterSupervisingOfficePred =
        cb.equal(
            masterConsignmentLocationJoin
                .get(ConsignmentLocationOfGoods_.supervisingCustomsOffice)
                .get(CustomsOffice_.referenceNumber),
            supervisingOfficeRefNum);

    Predicate houseSupervisingOfficePred =
        cb.equal(
            houseConsignmentLocationJoin
                .get(ConsignmentLocationOfGoods_.supervisingCustomsOffice)
                .get(CustomsOffice_.referenceNumber),
            supervisingOfficeRefNum);

    return cb.or(superviseOfficePred, masterSupervisingOfficePred, houseSupervisingOfficePred);
  }

  private static Predicate tsdPresentationOfficeRefNumPredicate(
      Root<TemporaryStorageDeclaration> root, CriteriaBuilder cb, String presentationOfficeRefNum) {
    if (isEmpty(presentationOfficeRefNum)) {
      return null;
    }

    return cb.equal(
        root.get(TemporaryStorageDeclaration_.customsOfficeOfPresentation)
            .get(CustomsOffice_.referenceNumber),
        presentationOfficeRefNum);
  }

  private static Predicate containerOrReceptaclePredicate(
      String containerOrReceptacle,
      CriteriaQuery<?> query,
      CriteriaBuilder cb,
      Join<TemporaryStorageDeclaration, MasterConsignment> masterConsJoin,
      Join<TemporaryStorageDeclaration, HouseConsignment> houseConsJoin) {

    if (isEmpty(containerOrReceptacle)) {
      return null;
    }

    Join<MasterConsignment, Receptacle> receptacleJoin =
        masterConsJoin.join(MasterConsignment_.receptacle, JoinType.LEFT);
    Join<MasterConsignment, TransportEquipment> mastertransEquipJoin =
        masterConsJoin.join(Consignment_.transportEquipment, JoinType.LEFT);

    Join<ConsignmentItem, TransportEquipment> masterConsItemTransEquipJoin =
        masterConsJoin
            .join(Consignment_.consignmentItem, JoinType.LEFT)
            .join(ConsignmentItem_.transportEquipment, JoinType.LEFT);

    Join<HouseConsignment, TransportEquipment> houseTransEquipJoin =
        houseConsJoin.join(Consignment_.transportEquipment, JoinType.LEFT);
    Join<ConsignmentItem, TransportEquipment> houseConsItemTransEquipJoin =
        houseConsJoin
            .join(Consignment_.consignmentItem, JoinType.LEFT)
            .join(ConsignmentItem_.transportEquipment, JoinType.LEFT);

    Predicate receptaclePred =
        cb.equal(receptacleJoin.get(Receptacle_.identificationNumber), containerOrReceptacle);
    Predicate masterContainerPred =
        cb.equal(
            mastertransEquipJoin.get(TransportEquipment_.containerIdentificationNumber),
            containerOrReceptacle);
    Predicate masterItemContainerPred =
        cb.equal(
            masterConsItemTransEquipJoin.get(TransportEquipment_.containerIdentificationNumber),
            containerOrReceptacle);
    Predicate houseContainerPred =
        cb.equal(
            houseTransEquipJoin.get(TransportEquipment_.containerIdentificationNumber),
            containerOrReceptacle);
    Predicate houseItemContainerPred =
        cb.equal(
            houseConsItemTransEquipJoin.get(TransportEquipment_.containerIdentificationNumber),
            containerOrReceptacle);
    query.distinct(true);

    return cb.or(
        receptaclePred,
        masterContainerPred,
        masterItemContainerPred,
        houseContainerPred,
        houseItemContainerPred);
  }

  private static Specification<TemporaryStorageDeclaration> statusIn(List<TSDStatus> statuses) {
    if (statuses == null || statuses.isEmpty()) {
      return null;
    }

    return (root, query, cb) ->
        root.get(TemporaryStorageDeclaration_.currentStatus)
            .in(
                (Object[])
                    statuses.stream()
                        .map(s -> TSDStatus.enumOf(s.getCode()))
                        .toArray(TSDStatus[]::new));
  }

  private static Specification<TemporaryStorageDeclaration> riskAndControlStatusIn(
      List<RiskAndControlStatus> statuses) {
    if (statuses == null || statuses.isEmpty()) {
      return null;
    }
    return (root, query, cb) ->
        root.get(TemporaryStorageDeclaration_.CURRENT_RISK_CONTROL_STATUS)
            .in(
                (Object[])
                    statuses.stream()
                        .map(s -> RiskAndControlStatus.enumOf(s.getCode()))
                        .toArray(RiskAndControlStatus[]::new));
  }

  /**
   * Converts an TemporaryStorageDeclarationFilter into a specification.
   *
   * <p>You can combine and / or depending on the requirements as shown in the example below.
   *
   * <pre>
   * return (root, query, cb) -> {
   *   return where(where(firstNameContains(filter.search())).or(lastNameContains(filter.search()))
   *       .or(emailContains(filter.search()))).and(streetContains(filter.street()))
   *           .and(cityContains(filter.city())).toPredicate(root, query, cb);
   * };
   * </pre>
   *
   * This specification is a cursor specification which is just a normal specification but with an
   * additional direction parameter as input. The direction is the sort direction and is needed to
   * know if we need to inverse the order of the before / after constraints. in case of descending
   * order the constraint needs to be reversed.
   */
  public static CursorSpecification<TemporaryStorageDeclaration> of(
      TemporaryStorageDeclarationFilter f) {
    return (root, query, cb, direction) -> {

      // return the current version of tsd's if the requested status is not draft
      if (f.getStatus().isEmpty() || !f.getStatus().contains(TSDStatus.DRAFT)) {
        Join<TemporaryStorageDeclaration, ReferenceNumber> referenceNumJoin =
            root.join(TemporaryStorageDeclaration_.referenceNumber, JoinType.INNER);
        referenceNumJoin.on(
            cb.equal(
                referenceNumJoin.get(ReferenceNumber_.declaration),
                root.get(TemporaryStorageDeclaration_.id)));
      }

      Join<TemporaryStorageDeclaration, Party> declarantJoin =
          root.join(TemporaryStorageDeclaration_.declarant, JoinType.LEFT);
      Join<TemporaryStorageDeclaration, Representative> representativeJoin =
          root.join(TemporaryStorageDeclaration_.representative, JoinType.LEFT);

      root.join(TemporaryStorageDeclaration_.transferNotification, JoinType.LEFT);

      return where(lrnEquals(f.getLrn()))
          // after
          .and(direction.isAscending() ? cursorAfter(f.getAfter()) : cursorBefore(f.getAfter()))
          // before
          .and(direction.isAscending() ? cursorBefore(f.getBefore()) : cursorAfter(f.getBefore()))
          .and(registrationDateAfter(f.getRegistrationDateAfter()))
          .and(registrationDateBefore(f.getRegistrationDateBefore()))
          .and(presentationDateAfter(f.getPresentationDateAfter()))
          .and(presentationDateBefore(f.getPresentationDateBefore()))
          .and(arrivalTransportMeansEquals(f.getArrivalTransportMeans()))
          .and(
              eoriPartyEquals(
                  declarantJoin,
                  representativeJoin,
                  f.getDeclarant(),
                  f.getRepresentative(),
                  f.getPresonPresentingTheGoods(),
                  f.getCarrier()))
          .and(otherConsignmentRelatedFieldEquals(f))
          .and(statusIn(f.getStatus()))
          .and(riskAndControlStatusIn(f.getRiskAndControlStatus()))
          .toPredicate(root, query, cb);
    };
  }
}
