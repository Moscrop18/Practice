/*
 * @(#)be.fgov.minfin.tsd.domain.model.consignment.Packaging
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model.consignment;

import be.fgov.minfin.tsd.domain.validation.annotation.CodeList;
import be.fgov.minfin.tsd.domain.validation.annotation.group.DeconsolidationNotificationValidatorGroup;
import be.fgov.minfin.tsd.domain.validation.annotation.group.RiskResultValidator;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import be.fgov.minfin.tsd.domain.validation.codelist.TSDCodeLists;
import com.fasterxml.jackson.annotation.JsonBackReference;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.groups.Default;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "PACKAGING")
@EqualsAndHashCode(exclude = {"consignmentItem"})
public class Packaging {
  @GeneratedValue(generator = "PACKAGING_SEQ")
  @SequenceGenerator(name = "PACKAGING_SEQ", sequenceName = "PACKAGING_SEQ")
  @Id
  private Long id;

  @Column(name = "TYPES_OF_PACKAGES")
  @CodeList(
      value = TSDCodeLists.CL017,
      groups = {Default.class, DeconsolidationNotificationValidatorGroup.class})
  @CodeList(
      value = TSDCodeLists.CL017,
      errorCode = ErrorCode.TSPNESXXC0415,
      groups = RiskResultValidator.class)
  private String typeOfPackages;

  private Integer numberOfPackages;

  private String shippingMarks;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "CONSIGNMENT_ITEM_ID")
  @JsonBackReference
  private ConsignmentItem consignmentItem;
}
