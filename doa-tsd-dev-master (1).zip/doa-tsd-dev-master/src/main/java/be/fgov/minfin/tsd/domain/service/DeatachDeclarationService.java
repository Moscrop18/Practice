/*
 * @(#) be.fgov.minfin.tsd.domain.repository.DeatachDeclarationService
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.service;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class DeatachDeclarationService {
  private final EntityManager em;

  public void clearAllManagedEntity() {
    em.clear();
  }

  public void deatchEntity(Entity e) {
    em.detach(e);
  }
}
