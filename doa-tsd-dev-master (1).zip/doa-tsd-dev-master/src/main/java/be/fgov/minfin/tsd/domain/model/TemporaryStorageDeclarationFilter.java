/*
 * @(#)be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclarationFilter.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model;

import be.fgov.minfin.libdoa.pagination.types.DateIdCursor;
import be.fgov.minfin.tsd.domain.model.risk.RiskAndControlStatus;
import java.time.LocalDateTime;
import java.util.List;
import lombok.Builder;
import lombok.Value;

@Value
@Builder(toBuilder = true)
public class TemporaryStorageDeclarationFilter {

  private String lrn;

  private LocalDateTime registrationDateAfter;

  private LocalDateTime registrationDateBefore;

  private LocalDateTime presentationDateAfter;

  private LocalDateTime presentationDateBefore;

  private String supervisingOfficeRefNum;

  private String presentationOfficeRefNum;

  private String arrivalTransportMeans;

  private String declarant;

  private String representative;

  private String presonPresentingTheGoods;

  private String carrier;

  private String transportDocument;

  private String containerOrReceptacle;

  private String locationOfGoodsUnLoCode;

  private String warehouseIdentifier;

  private List<TSDStatus> status;

  private List<RiskAndControlStatus> riskAndControlStatus;

  private DateIdCursor before;
  private DateIdCursor after;
}
