/*
 * @(#) be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation.codelist;

import lombok.Getter;

/**
 * Enum for Error Codes
 *
 * @author GauravMitra
 */
@Getter
public enum ErrorCode {

  /** ErrorCode used for invalid Warehouse Type. */
  TSPNESXXC0087,

  /** ErrorCode used for invalid Warehouse Type. */
  TSPNESXXR0128,

  /** ErrorCode used for invalid Presenting Custom Office Reference Number. */
  TSPNESXXC0021,

  /** ErrorCode used for invalid Country. */
  TSPNESXXC0089,

  /** ErrorCode used for invalid PoBox. */
  TSPNESXXC0006,

  /** ErrorCode used for invalid Post Code. */
  TSPNESXXC0007,

  DEFAULTERRORCODE,

  /**
   * ErrorCode used if the Warehouse is not used and the Location of goods Type of location = 'B'.
   */
  TSPNESXXC0108,

  /** ErrorCode used if Supporting Document is used */
  TSPNESXXR0025,

  /** ErrorCode used for invalid Presentation date and time */
  TSPNESXXR0069,

  /** ErrorCode used for invalid Presentation date and time */
  TSPNESXXC0070,

  /** ErrorCode used for invalid Presentation date and time */
  TSPNESXXR0071,

  /** ErrorCode used if Supporting Document Type is not valid */
  TSPNESXXC0094,

  /** ErrorCode used for invalid ENS re-use indicator */
  TSPNESXXC0085,

  /** ErrorCode used for invalid Additional reference Type. */
  TSPNESXXC0093,

  /** ErrorCode used for invalid Supervising customs office Reference number. */
  TSPNESXXC0020,

  /** ErrorCode used for invalid Place of unloading UNLOCODE. */
  TSPNESXXC0029,

  /** ErrorCode used for invalid Arrival transport means Type of identification */
  TSPNESXXC0086,

  /**
   * ErrorCode used if Arrival transport means Identification number is not a valid IMO ship
   * identification number.
   */
  TSPNESXXR0010,

  /** ErrorCode used if The Location of goods and Place of unloading both are not used. */
  TSPNESXXC0058,

  /**
   * ErrorCode used if The Location of goods UNLOCODE must be used if the Location of goods
   * Qualifier of identification 'U'.
   */
  TSPNESXXC0061,

  /**
   * ErrorCode used if The Location of goods Customs office must be used if the Location of goods
   * Qualifier of identification 'V'.
   */
  TSPNESXXC0062,

  /**
   * ErrorCode used if The Location of goods GNSS must be used if the Location of goods Qualifier of
   * identification 'W'.
   */
  TSPNESXXC0063,

  /**
   * ErrorCode used if The Location of goods Economic operator and Address must be used if the
   * Location of goods Qualifier of identification 'X'
   */
  TSPNESXXC0064,

  /**
   * ErrorCode used if The Location of goods Authorisation number and Address must be used if the
   * Location of goods Qualifier of identification 'Y'
   */
  TSPNESXXC0065,

  /**
   * ErrorCode used if The Location of the goods Qualifier of identification is not in line with the
   * Location of the goods Type of location used
   */
  TSPNESXXR0067,

  /** ErrorCode used for an invalid Type of location */
  TSPNESXXC0079,

  /** ErrorCode used for an invalid Qualifier of Identification */
  TSPNESXXC0080,

  /** ErrorCode used for an invalid Location of goods UNLOCODE. */
  TSPNESXXC0081,

  /** ErrorCode used for an invalid Location of goods Customs office Reference number. */
  TSPNESXXC0095,

  /**
   * ErrorCode used if The Location of goods Economic operator Identification number is not a valid
   * EORI number.
   */
  TSPNESXXR0109,

  /** ErrorCode used if The Carrier Identification number is not a valid EORI number. */
  TSPNESXXR0103,

  /**
   * ErrorCode used for an invalid Type of location for a pre-lodged Temporary Storage Declaration.
   */
  TSPNESXXR0120,

  /**
   * ErrorCode used if Arrival transport means Identification number is not a valid European Vessel
   * Identification Number.
   */
  TSPNESXXR0011,

  /** ErrorCode used if Consignment Total gross mass is smaller than zero */
  TSPNESXXR0054,

  /** ErrorCode used if Consignment does not contain at least one Consignment item */
  TSPNESXXC0057,

  /**
   * ErrorCode used if Master consignment header is not linked to a Master consignment or House
   * consignment
   */
  TSPNESXXR0044,

  /** ErrorCode used if Consignment item Goods item number is not unique or sequential */
  TSPNESXXR0023,

  /** ErrorCode used for invalid Commodity CUS code. */
  TSPNESXXC0092,

  /** ErrorCode used for invalid Commodity code */
  TSPNESXXC0091,

  /** ErrorCode used if Consignment item Commodity code is empty */
  TSPNESXXC0049,

  /** ErrorCode used if Consignment item Gross mass is smaller than zero */
  TSPNESXXR0055,

  /** ErrorCode used if Consignment item Weight is empty */
  TSPNESXXC0097,

  /**
   * ErrorCode used when the class or attribute must not be used if the ENS-reuse indicator = '1'.
   * In all other cases, the class or attribute is mandatory.
   */
  TSPNESXXC0098,

  /**
   * ErrorCode used if Commodity code Harmonized system sub heading code is not unique for all
   * Consignment items in the Consignment.
   */
  TSPNESXXR0132,

  /**
   * ErrorCode used if Consignment item Goods item number is not unique or sequential starting at 1
   * for the House consignment.
   */
  TSPNESXXR0024,

  /**
   * ErrorCode used if The Transport equipment is provided both at Consignment and Consignment item
   * level.
   */
  TSPNESXXR0026,

  /** ErrorCode used for invalid Transport equipment Container packed status */
  TSPNESXXC0090,

  /** ErrorCode used for invalid Additional Information Code */
  TSPNESXXC0088,

  /** ErrorCode used if The Additional Information is not provided with both the text and code */
  TSPNESXXR0033,

  /** ErrorCode used if The Additional Information text is empty and code is equal to 10600 */
  TSPNESXXC0035,

  /**
   * ErrorCode used if The Additional information is provided both at Consignment and Consignment
   * item level
   */
  TSPNESXXR0050,

  /** ErrorCode used for invalid Communication Type */

  /**
   * ErrorCode used if the Person Presenting The Goods Identification number is not a valid EORI
   * number
   */
  TSPNESXXR0017,

  TSPNESXXC0075,

  /** ErrorCode used for invalid Representative Status */
  TSPNESXXC0076,

  /** ErrorCode used if the Declarant Identification number is not a valid EORI number */
  TSPNESXXR0001,

  /** ErrorCode used if the Representative Identification number is not a valid EORI number */
  TSPNESXXR0002,

  /**
   * ErrorCode used if the Representative Identification number is same as the Declarant
   * Identification number
   */
  TSPNESXXC0003,

  /** ErrorCode used for invalid Type of person */
  TSPNESXXC0084,

  /** ErrorCode used for invalid Type of packages */
  TSPNESXXC0082,

  /**
   * ErrorCode used if both The Packaging Shipping marks and Packaging Number of packages are
   * provided.
   */
  TSPNESXXC0037,

  /** ErrorCode used for invalid Number of packages */
  TSPNESXXR0038,

  /** ErrorCode used for invalid TRANSPORT EQUIPMENT/Number of seals */
  TSPNESXXR0041,

  /**
   * ErrorCode used if The Transport equipment Seal is not used if the Transport equipment Number of
   * seals is used
   */
  TSPNESXXR0042,

  /** ErrorCode used for an invalid Transport document Type */
  TSPNESXXC0077,
  /** ErrorCode used for invalid role in Additional Supply Chain Actor */
  TSPNESXXC0083,
  /** ErrorCode used for invalid identification Additional Supply Chain Actor */
  TSPNESXXR0014,
  /**
   * ErrorCode used if The Additional Supply Chain Actor is provided both at Consignment and
   * Consignment item level
   */
  TSPNESXXR0051,
  /**
   * ErrorCode used if The Transport document is not unique for all used Master and House
   * consignments
   */
  TSPNESXXR0048,

  /** ErrorCode used if The aeo certificate not valid for Additional Supply Chain Actor */
  TSPNESXXR0074,

  /**
   * ErrorCode used if The Previous document is provided both at Consignment and Consignment item
   * level
   */
  TSPNESXXR0053,

  /** ErrorCode used if The Previous document is not unique for all House consignments */
  TSPNESXXR0068,

  /**
   * ErrorCode used if The Previous document is not unique for all Consignment items in the
   * Consignment
   */
  TSPNESXXR0040,

  /** ErrorCode used for an invalid Previous document Type */
  TSPNESXXC0078,

  /** ErrorCode used for an invalid Previous document Type for Pre-lodged TSD */
  TSPNESXXR0130,

  /** ErrorCode used for an invalid Previous document Type for Combined TSD */
  TSPNESXXR0131,
  /**
   * ErrorCode used when the class or attribute must not be used if the ENS-reuse indicator = '1'.
   * In all other cases, the class or attribute is optional.
   */
  TSPNESXXR0099,
  /**
   * ErrorCode used for One Previous document of Type = 'N355' must be used for each Consignment if
   * the ENS re-use indicator = '1'.
   */
  TSPNESXXR0100,

  /**
   * ErrorCode used if The system cannot register the PN data elements for the combined Temporary
   * Storage Declaration due to a technical error.
   */
  TSPNESXXT0004,

  /**
   * ErrorCode used if The Presentation Notification House Consignment Previous document does not
   * refer to one Temporary Storage Declaration.
   */
  TSPNESXXR0312,

  /**
   * ErrorCode used if The Temporary Storage Declaration contain other Transport documents as part
   * of the Presentation Notification.
   */
  TSPNESXXR0314,

  /**
   * ErrorCode used if all Presentation Notification House Consignments Previous document refer to
   * exactly one Temporary Storage Declaration.
   */
  TSPNESXXR0313,

  /**
   * ErrorCode used if all Temporary Storage Declaration House consignment Consignment items refer
   * to a Transport equipment.
   */
  TSPNESXXR0310,

  /**
   * ErrorCode used if all Temporary Storage Declaration Master consignment Consignment items refer
   * to a Transport equipment or Receptacle.
   */
  TSPNESXXR0309,

  /**
   * ErrorCode used if The Temporary Storage Declaration contain other Transport equipments or
   * Receptacles as part of the Presentation Notification.
   */
  TSPNESXXR0311,

  /**
   * ErrorCode used if The Temporary Storage Declaration does not exist and have the correct status
   * for activation.
   */
  TSPNESXXR0308,

  /**
   * ErrorCode used if The Presentation Notification Master Consignment Previous document does not
   * refer to exactly one Temporary Storage Declaration.
   */
  TSPNESXXR0307,
  /**
   * Error code used when The Temporary Storage Declaration Master consignment Transport document is
   * not in line with the retrieved Entry Summary Declaration Master Consignment Transport document.
   */
  TSPNESXXR0305,
  /**
   * Error code used when The Temporary Storage Declaration House consignment Transport document is
   * not in line with the retrieved Entry Summary Declaration House Consignment Transport document.
   */
  TSPNESXXR0306,
  /**
   * Error code used when The Temporary Storage Declaration House consignments does not contain
   * consignee after retrieval and transformation of data from ens.
   */
  TSPNESXXR0102,

  TSPNESXXC0304,

  TSPNESXXT0002,
  /**
   * Error code used when The Temporary Storage Declarations any consignment does not contain
   * consignor after retrieval and transformation of data from ens
   */
  TSPNESXXR0101,
  /** Error code used when the crn from request does not correspond to a valid TSD */
  TSPNESXXR0104,
  /**
   * Error code used when the invalidation request tries to invalidate a tsd whose current status is
   * not prelodged.
   */
  TSPNESXXR0105,
  /**
   * Error code used when the invalidation request declarant/identificationNumber is not the same as
   * tsd/declarant/identification number.
   */
  TSPNESXXR0106,
  /**
   * Error code used when the either ‘CRN’or ‘MRN’ is not provided for the amendment of a Temporary
   * Storage Declaration. .
   */
  TSPNESXXR0136,
  /** Error code used when the mrn from the request does not correspond to a valid TSD */
  TSPNESXXR0135,
  /**
   * Error code used when TSD amendment request, the current status of the TSD needs is not
   * ‘PRE-LODGED’ or ‘ACCEPTED’.
   */
  TSPNESXXR0112,
  /**
   * Error code used when the ENS re-use indicator in the amendment request has a compatible value
   * for the ENS re-use indicator in the current TSD.
   */
  TSPNESXXR0115,
  /**
   * Error code used when the message reception date and time of the amendment request < message
   * reception date and time of the current version of the TSD (which is either the original TSD or
   * an amended version).
   */
  TSPNESXXR0119,
  /**
   * Error code used for a pre-lodged Temporary Storage Declaration, this class/attribute cannot be
   * provided. In all other cases this class/attribute is mandatory.
   */
  TSPNESXXC0113,
  /**
   * Error code used for a pre-lodged Temporary Storage Declaration, this class/attribute cannot be
   * provided. In all other cases this class/attribute is conditional.
   */
  TSPNESXXR0114,
  /**
   * Error code used when the value of the class or attribute is not the same as in the presented
   * Temporary Storage Declaration.
   */
  TSPNESXXR0116,
  /**
   * Error code used when this class or attribute is not present for a presented Temporary Storage
   * Declaration.
   */
  TSPNESXXR0117,
  /** Error code in case format validation failed */
  TSPNESXXC0200,
  /**
   * Error code used when the Consignment item Goods item number is not unique for the Master
   * consignment.
   */
  TSPNESXXR0121,
  /** Error code used when the declaration is in invalid status */
  TSPNESXXR0318,
  /** Error code used when the master consignment is already present */
  TSPNESXXR0319,
  /** Error code used when the consignment item is already present */
  TSPNESXXR0320,
  /** Error code used when the consignment cannot be deleted */
  TSPNESXXR0321,
  /** Error code used when the consignment item cannot be deleted */
  TSPNESXXR0322,
  /** Error code used when the status draft is combined with any other statuses */
  TSPNESXXR0329,

  /**
   * Error code used when the Consignment item Goods item number is not unique for all the House
   * consignment.
   */
  TSPNESXXR0122,

  /** Error code used when the draft tsd version is less the equal to any other version TSD */
  TSPNESXXR0325,

  /**
   * Error code used when the for draft amended tsd linkedPnfrm not equal to current linked pn frn
   */
  TSPNESXXR0326,
  /** Error code used when draft amendment request already present for TSD */
  TSPNESXXR0327,
  /**
   * Error code used when current tSD which is to be amended contain more then 100 house consignment
   * or item per consignment
   */
  TSPNESXXR0328,
  /** The functional refrence does not refer to an existing Temporary Storage Declaration. */
  TSPNESXXR0400,
  /**
   * The Temporary Storage Declaration does not have the correct status to process the risk hit
   * notification.
   */
  TSPNESXXR0401,
  /**
   * The Temporary Storage Declaration does not have the correct Risk & Control status to process
   * the risk hit notification.
   */
  TSPNESXXR0402,
  /**
   * The ‘Risk analysis request reference’ does not refer to the request reference of the most
   * recent requested risk analysis request for the Temporary Storage Declaration (current version).
   */
  TSPNESXXR0403,
  /**
   * When tTSPNESXXR0433he ‘Control subject / Consignment (Master level) / Transport equipment /
   * Container identification number’ is not part of the 'Transport equipment / Container
   * identification number' of the TSD Consignment (Master level).
   */
  TSPNESXXR0432,
  /**
   * The ‘Control subject / Consignment (Master level) / Receptacle / Identification number’ is not
   * part of the 'Receptacle / Identification number' of the TSD Consignment (Master level).
   */
  TSPNESXXR0433,
  /**
   * When None of the following classes 'Receptacle’, ‘Goods item’, ‘Transport document’, ‘Transport
   * equipment’, ‘Consignment (house level) is used for the ‘Control subject / Consignment (Master
   * level)’
   */
  TSPNESXXR0421,
  /**
   * When the ‘Control subject / Consignment (Master level) / Goods item / Goods item number’
   * doesn't exist for the TSD Consignment (Master level)
   */
  TSPNESXXR0434,
  /**
   * When the ‘Control subject / Consignment (Master level) / Consignment (House level) / Transport
   * document’ doesn't match the Transport document (reference number and type) of the TSD
   * Consignment (House level)
   */
  TSPNESXXR0423,
  /**
   * The ‘Control subject / Consignment (Master level) / Consignment (House level) / Goods item /
   * Goods item number’ doesn't exist for the TSD Consignment (Master level).
   */
  TSPNESXXR0437,
  /**
   * The ‘Control subject / Consignment (Master level) / Consignment (House level) / Transport
   * equipment / Container identification number’ is not part of the 'Transport equipment /
   * Container identification number' of the TSD Consignment (House level).
   */
  TSPNESXXR0436,
  /**
   * The ‘Control subject / Consignment (Master level) / Goods item / Transport equipment /
   * Container identification number’ is not part of the 'Transport equipment / Container
   * identification number' of the TSD Consignment Item (Master level).
   */
  TSPNESXXR0435,
  /**
   * For a Temporary Storage Declaration Risk analysis result, the Control recommendations / Control
   * subjects refers to both Master Consignment and House Consignment level
   */
  TSPNESXXR0449,
  /**
   * The ‘Control subject / Consignment (Master level) / Consignment (House level) / Goods item /
   * Transport equipment / Container identification number’ is not part of the 'Transport equipment
   * / Container identification number' of the TSD Consignment Item (House level).
   */
  TSPNESXXR0438,
  /**
   * For a Temporary Storage Declaration Risk analysis result, the Control subjects of all Control
   * recommendations refers both to Master Consignment and to House Consignment level
   */
  TSPNESXXR0453,
  /**
   * When ‘Control subject / Consignment (Master level) / Transport document’ doesn't match the
   * Transport document (reference number and type) of the TSD Consignment (Master level).
   */
  TSPNESXXR0422,
  /**
   * The Temporary Storage Declaration does not have the correct status to process the Risk Analysis
   * Result
   */
  TSPNESXXR0404,
  /**
   * The Temporary Storage Declaration does not have the correct Risk & Control status to process
   * Risk Analysis Result.
   */
  TSPNESXXR0405,
  /**
   * The Temporary Storage Declaration does not have the correct Risk analysis result / Result code
   */
  TSPNESXXC0454,

  /** Error code uses for the risk/category */
  TSPNESXXC0410,
  /** Error code used for the Risk analysis result / Risk analysis Type */
  TSPNESXXC0411,
  /** Error code used for the Risk analysis result / Risk area */
  TSPNESXXC0412,
  /** Error code used for the Risk analysis result / Risk level */
  TSPNESXXC0413,
  /** Error code used for the Risk analysis result / Result code */
  TSPNESXXC0414,
  /** Error code used for the Packaging / Type of packages */
  TSPNESXXC0415,
  /** Error code used for the Transport document / Type */
  TSPNESXXC0416,
  /** Error code used for the Control notification / Notification allowed */
  TSPNESXXC0417,
  /** Error code used for the Type of controls / Type */
  TSPNESXXC0418,
  /** Error code used for the Customs office of control / Reference number */
  TSPNESXXC0445,
  /** Error code used for the Requested document/ Document type */
  TSPNESXXC0451,
  /** Error code used for the Communication/Type */
  TSPNESXXC0409,

  /** Error code used for the invalid tsd control and risk status */
  TSPNESXXR0425,
  /** Error code used for the invalid tsd status of expired risk analysis result */
  TSPNESXXR0424,
  /** Error code used for the tsd not found for expired risk analysis result */
  TSPNESXXR0459,

  /**
   * The Temporary Storage Declaration does not have the correct Risk analysis result / Result
   * analyst
   */
  TSPNESXXC0406(13),

  /**
   * The Temporary Storage Declaration does not have the correct Risk analysis result / Type of
   * controls / text
   */
  TSPNESXXC0458(13),

  /**
   * The Temporary Storage Declaration does not have the correct Risk analysis result / Type of
   * controls
   */
  TSPNESXXC0408(13),

  /**
   * The Temporary Storage Declaration does not have the correct Risk analysis result / Control
   * Notification
   */
  TSPNESXXC0407(13),

  /**
   * The Temporary Storage Declaration does not have the correct Risk analysis result / Customs
   * Office Of Control
   */
  TSPNESXXC0450(13),

  /**
   * The Temporary Storage Declaration does not have the correct Risk analysis result / Requested
   * document
   */
  TSPNESXXC0452(13),

  /*
   * The control Result not having control Results for control decision = 1 OR The
   * control Result having control Results for control decision <> 1
   */
  TSPNESXXC0448(13),

  /* Control decision / Reason Code not provided for contril decison =0 */
  TSPNESXXC0447(13),

  /*
   * The Control recommendation reference doesn't refer to an existing Control
   * recommendation for the Temporary Storage Declaration (current version) for
   * which no control result is registered.
   */
  TSPNESXXR0455(97),

  /*
   * Control recommendation reference values present in the Control Result are not
   * unique.
   */
  TSPNESXXR0456(99),

  /** Error code used for Control decision/control decision */
  TSPNESXXC0440(12),

  /** Error code used for Control decision / reason code */
  TSPNESXXC0441(12),

  /** Error code used for Control trigger / control trigger */
  TSPNESXXC0443(12),

  /** Error code used for control results/ control result /code */
  TSPNESXXC0442(12),

  /** Error code used for control results/control result /type */
  TSPNESXXC0444(12),

  /** The Temporary Storage Declaration does not have the correct current version */
  TSPNESXXR0446(97),

  /** The Temporary Storage Declaration does not have the correct current status */
  TSPNESXXR0428(97),

  /** The Temporary Storage Declaration does not have the correct Risk And Control Status */
  TSPNESXXR0429(97),

  /** The Temporary Storage Declaration does not have the control decision empty */
  TSPNESXXR0457(99),

  /**
   * Total gross mass attribute not provided for all of the consignment(s) (Master / House
   * Consignment)
   */
  TSPNESXXR0152(99),

  /**
   * ErrorCode used if both The PACKAGING/Type of packages and PACKAGING/Shipping marks are
   * provided.
   */
  TSPNESXXC0036(99),

  /** ErrorCode used if The CONSIGNMENT ITEM/PACKAGING/Type of packages are provided. */
  TSPNESXXR0151(99),

  /**
   * ErrorCode used to validate The ‘Type of controls’ is not present when at least no 'Control
   * recommendations' is provided.
   */
  TSPNESXXR0408(13),

  /** The Transfer Notification does not have current status Accepted */
  TSPNESXXR0144(99),

  /** The TSD (current version) for Transfer Notification does not have correct type of location */
  TSPNESXXR0157(99),

  /**
   * The Transfer Notification reception timestamp > reception timestamp of the TSD (current
   * version)
   */
  TSPNESXXR0148(99),
  /** Total Number of Packages is less than 0 */
  TSPNESXXR0141,
  /**
   * Only value 'B' is valid for 'LOCATION OF GOODS/Type of location' for TransferNotification
   * request.
   */
  TSPNESXXR0142,
  /**
   * TransportDocument in transfer Notification request does not exits in current Temporary Storage
   * Declaration
   */
  TSPNESXXR0143,
  /** personNotifyingTheArrivalAfterMovement identification number is not a valid EORI number */
  TSPNESXXR0138,
  /**
   * The Master consignment header is not linked to one Master consignment or one or more House
   * consignments.
   */
  TSPNESXXR0140,
  /** Temporary Storage Declaration (current version) has not current status 'ACCEPTED' */
  TSPNESXXR0146(99),
  /**
   * The Temporary Storage Declaration (current version) contains at least one consignment of type
   * 'House consignment'.
   */
  TSPNESXXR0149(99),
  /** Not all House Consignments are present at the current Master Consignment location of goods. */
  TSPNESXXR0150(99),
  /**
   * The system cannot retrieve Goods Accounting data for the Temporary Storage Declaration due to a
   * technical error.
   */
  TSPNESXXT0005(99),
  /** The goods are no longer available in Temporary Storage upon processing of the TSD request. */
  TSPNESXXR0137(99),
  /**
   * The TSD current version is deconsolidated (approved deconsolidation in current or previous
   * version) or transferred (approved transfer notification in current or previous version)
   */
  TSPNESXXR0333(99),
  /** MC is not deconsolidated into one or more HCs, then the presented TSD can be amended */
  TSPNESXXR0155(99),
  /**
   * no Consignments are transferred to another LOG for temporary storage of goods, then the
   * presented TSD can be amended
   */
  TSPNESXXR0156(99),
  /**
   * The goods are no longer available in Temporary Storage upon processing of the TSD
   * deconsolidation notification.
   */
  TSPNESXXR0147(99),

  TSPNESXXR0153(99),

  TSPNESXXR0145(99),

  /**
   * The MC items are no longer available in TSD upon processing of the TSD deconsolidation
   * notification.
   */
  TSPNESXXR0154(99),
  /**
   * If at least 1 CONSIGNMENT in the Temporary Storage Declaration contains a PREVIOUS DOCUMENT of
   * Type = 'N821', then exactly 1 PREVIOUS DOCUMENT of Type = ‘N821’ is required for each
   * CONSIGNMENT. Additionally, the PREVIOUS DOCUMENT (identified by ‘PREVIOUS DOCUMENT/Reference
   * number’ and ‘PREVIOUS DOCUMENT/Type’) needs to be unique throughout all CONSIGNMENTs. *
   */
  TSPNESXXR0162,
  /** Maximum 1 ‘PREVIOUS DOCUMENT/Type’ is allowed throughout all CONSIGNMENTs. * */
  TSPNESXXR0163;

  private Integer code;

  private ErrorCode(Integer code) {
    this.code = code;
  }

  private ErrorCode() {}

  public static ErrorCode enumOf(String name) {
    for (ErrorCode errorCode : ErrorCode.values()) {
      if (name.equals(errorCode.name())) {
        return errorCode;
      }
    }
    return null;
  }
}
