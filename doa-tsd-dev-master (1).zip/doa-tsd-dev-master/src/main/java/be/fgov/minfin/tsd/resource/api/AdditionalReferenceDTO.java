/*
 * @(#)be.fgov.minfin.tsd.resource.api.AdditionalReferenceDTO.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */

package be.fgov.minfin.tsd.resource.api;

import be.fgov.minfin.tsd.resource.validation.B2BOnly;
import com.fasterxml.jackson.annotation.JsonRootName;
import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.Builder;
import lombok.Value;

/** AdditionalReferenceDTO */
@Value
@Builder(toBuilder = true)
@JsonRootName("additionalReference")
public class AdditionalReferenceDTO {
  @Size(min = 1, max = 70)
  @Schema(example = "REF123456789")
  private String referenceNumber;

  @Size(min = 4, max = 4)
  @NotNull(groups = B2BOnly.class)
  @Schema(example = "Y003", description = "Additional Reference Type (CL380)")
  private String type;
}
