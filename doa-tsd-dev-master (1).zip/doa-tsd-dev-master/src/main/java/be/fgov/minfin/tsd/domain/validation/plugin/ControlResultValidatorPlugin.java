/*
 * @(#)be.fgov.minfin.tsd.domain.validation.plugin.ControlResultValidatorPlugin
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation.plugin;

import be.fgov.minfin.tsd.domain.model.ReceiveControlResult;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.risk.ControlRecommendation;
import be.fgov.minfin.tsd.domain.validation.message.MessageType;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import javax.validation.ConstraintViolation;

public interface ControlResultValidatorPlugin {
  public Set<ConstraintViolation<ReceiveControlResult>> validateControlResult(
      final ReceiveControlResult controlResult,
      List<ControlRecommendation> tsdControlRecommendations,
      Optional<TemporaryStorageDeclaration> temporaryStorageDeclaration,
      MessageType messageType);
}
