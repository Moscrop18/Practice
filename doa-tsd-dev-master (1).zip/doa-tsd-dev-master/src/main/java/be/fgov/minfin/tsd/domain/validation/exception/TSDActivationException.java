/*
 * @(#) be.fgov.minfin.tsd.domain.validation.exception.ActivationRequestEventListener.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation.exception;

import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import java.util.Set;
import javax.validation.ConstraintViolation;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * This is custom exception thrown in case of validation failure while TSD Activation
 *
 * @author GauravMitra
 */
@Getter
@RequiredArgsConstructor
public class TSDActivationException extends Exception {

  /** */
  private static final long serialVersionUID = -6223670302823913817L;

  private final transient Set<ConstraintViolation<TemporaryStorageDeclaration>> violations;

  private final transient TemporaryStorageDeclaration tsd;
}
