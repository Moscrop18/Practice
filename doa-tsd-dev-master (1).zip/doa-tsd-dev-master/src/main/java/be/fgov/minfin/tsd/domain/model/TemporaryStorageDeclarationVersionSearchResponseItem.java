package be.fgov.minfin.tsd.domain.model;

import java.time.LocalDateTime;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Getter
@Setter
public class TemporaryStorageDeclarationVersionSearchResponseItem {
  private Long id;

  private Integer version;

  private String category;

  private LocalDateTime dateTime;

  private String requestStatus;

  private Boolean currentVersion;

  private TSDStatus tsdStatus;

  private List<InvalidationRequest> invalidationRequests;

  private AmendmentRequest amendmentRequest;
}
