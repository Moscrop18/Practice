/*
 * @(#)be.fgov.minfin.tsd.domain.model.risk.RiskAnalysisRequest.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model.risk;

import be.fgov.minfin.libdoa.commons.lang.Now;
import be.fgov.minfin.libdoa.entities.VersionedEntity;
import be.fgov.minfin.tsd.domain.model.TSDStatus;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.validation.annotation.CodeList;
import be.fgov.minfin.tsd.domain.validation.annotation.group.RiskResultValidator;
import be.fgov.minfin.tsd.domain.validation.codelist.TSDCodeLists;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Entity
@Setter
@Builder
@NoArgsConstructor
@ToString(callSuper = true)
@AllArgsConstructor
@Table(name = "RISK_ANALYIS_REQUEST")
@EqualsAndHashCode(exclude = "declaration")
public class RiskAnalysisRequest extends VersionedEntity<Long> {

  @Id
  @GeneratedValue(generator = "risk_analysis_seq")
  @SequenceGenerator(name = "risk_analysis_seq", sequenceName = "risk_analysis_seq")
  private Long id;

  private String reference;

  @Column(columnDefinition = "char")
  @CodeList(value = TSDCodeLists.CL736, groups = RiskResultValidator.class)
  private String category;

  private LocalDateTime timestamp;

  private LocalDateTime expirationTimestamp;

  @Embedded @Valid private RiskAnalysisResponse riskAnalysisResponse;

  @OneToMany(
      mappedBy = "riskAnalysisRequest",
      cascade = {},
      orphanRemoval = true)
  @ToString.Exclude
  @JsonIgnoreProperties("riskAnalysisRequest")
  private List<@Valid RiskAnalysisResult> riskAnalysisResult;

  @OneToMany(
      mappedBy = "riskAnalysisRequest",
      cascade = {},
      orphanRemoval = true)
  @ToString.Exclude
  @JsonIgnoreProperties("riskAnalysisRequest")
  private List<@Valid ControlRecommendation> controlRecommendations;

  @JoinColumn(name = "TSD_ID")
  @ManyToOne(fetch = FetchType.LAZY)
  private TemporaryStorageDeclaration declaration;

  public RiskAnalysisRequest(
      TemporaryStorageDeclaration declaration,
      LocalDateTime timestamp,
      LocalDateTime expirationTimestamp) {
    this.declaration = declaration;
    this.category = declaration.getCurrentStatus() == TSDStatus.PRELODGED ? "P" : "F";
    this.reference =
        declaration.getReferenceNumber().getCrn().getCrnNumber()
            + declaration.getCurrentVersion()
            + this.category;
    if (timestamp != null) {
      this.timestamp = timestamp;
    } else {
      this.timestamp = Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime();
    }
    this.expirationTimestamp =
        declaration.getCurrentStatus() == TSDStatus.PRELODGED ? null : expirationTimestamp;
  }

  public void updateIntendedControlNotified(boolean value) {
    if (this.riskAnalysisResponse == null) {
      this.riskAnalysisResponse =
          RiskAnalysisResponse.builder().intendedControlNotified(value).build();
    } else {
      this.riskAnalysisResponse.setIntendedControlNotified(value);
    }
  }

  public void updateNotificationAllowed(boolean value) {
    if (this.riskAnalysisResponse == null) {
      this.riskAnalysisResponse = RiskAnalysisResponse.builder().notificationAllowed(value).build();
    } else {
      this.riskAnalysisResponse.setNotificationAllowed(value);
    }
  }

  public void updateTimestamp(LocalDateTime value) {
    if (this.riskAnalysisResponse == null) {
      this.riskAnalysisResponse = RiskAnalysisResponse.builder().timestamp(value).build();
    } else {
      this.riskAnalysisResponse.setTimestamp(value);
    }
  }
}
