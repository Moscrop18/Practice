/*
 * @(#)be.fgov.minfin.tsd.domain.service.AmendmentService.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.service;

import static be.fgov.minfin.tsd.domain.model.TSDStatus.IRREGULARITY_UNDER_INVESTIGATION;
import static be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclarationType.COMBINED;
import static be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclarationType.PRELODGED;
import static be.fgov.minfin.tsd.domain.model.TimerType.RISK_ANALYSIS_RESULT;
import static be.fgov.minfin.tsd.domain.model.TimerType.TSD_DRAFT_EXPIRATION;
import static be.fgov.minfin.tsd.domain.model.TimerType.TSD_EXPIRATION;
import static org.apache.commons.collections4.CollectionUtils.isEmpty;

import be.fgov.minfin.libdoa.commons.lang.Now;
import be.fgov.minfin.libdoa.goods.accounting.client.api.owd.LockOffwritableDocumentStatusReason;
import be.fgov.minfin.tsd.config.TSDConfig;
import be.fgov.minfin.tsd.domain.mapper.TSDDomainMapper;
import be.fgov.minfin.tsd.domain.message.Error;
import be.fgov.minfin.tsd.domain.model.AmendmentRequest;
import be.fgov.minfin.tsd.domain.model.BusinessValidationType;
import be.fgov.minfin.tsd.domain.model.DeconsolidationNotificationStatus;
import be.fgov.minfin.tsd.domain.model.ReferenceNumber;
import be.fgov.minfin.tsd.domain.model.TSDStatus;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.TimerType;
import be.fgov.minfin.tsd.domain.model.TransferNotificationStatus;
import be.fgov.minfin.tsd.domain.model.party.Party;
import be.fgov.minfin.tsd.domain.model.risk.RiskAndControlStatus;
import be.fgov.minfin.tsd.domain.repository.TSDRepository;
import be.fgov.minfin.tsd.domain.sender.TSDResponseSender;
import be.fgov.minfin.tsd.domain.validation.CustomViolation;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import be.fgov.minfin.tsd.domain.validation.plugin.AmendmentValidatorPlugin;
import be.fgov.minfin.tsd.event.TSDEventBroker;
import be.fgov.minfin.tsd.event.api.TSDAmendmentReceivedEvent;
import be.fgov.minfin.tsd.gateway.ens.exception.ReuseFailedException;
import be.fgov.minfin.tsd.gateway.ga.GoodsAccountingGateway;
import be.fgov.minfin.tsd.gateway.risk.RiskAnalysisGateway;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import javax.validation.ConstraintViolation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * This service layer is for amendment of a pre-lodged TSD
 *
 * @author MohdSalim
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class AmendmentService {

  private final TSDEventBroker eventBroker;
  private final AmendmentValidatorPlugin amendmentValidator;
  private final ENSReuser ensReuser;
  private final TSDResponseSender tsdResponseSender;
  private final PartyDetailsLoader partyLoader;
  private final TSDRepository repository;
  private final TSDDomainMapper mapper;
  private final TSDTimerService timerService;
  private final TSDConfig tsdConfig;
  private final RiskAnalysisGateway riskAnalysisGateway;
  private final GoodsAccountingGateway gaGateway;
  private static final String TSD_ID = "tsdId";

  /**
   * This method will send amendment request event to Queue
   *
   * @param amendmentRequest
   */
  public void receiveAmendmentRequest(AmendmentRequest amendmentRequest) {
    TSDAmendmentReceivedEvent tsdAmendmentReceivedEvent =
        TSDAmendmentReceivedEvent.builder().amendmentRequest(amendmentRequest).build();
    eventBroker.publishTSDAmendmentEvent(tsdAmendmentReceivedEvent);
  }

  /**
   * @param amendmentRequest
   */
  public void processAmendmentRequest(AmendmentRequest amendmentRequest) {

    TemporaryStorageDeclaration tsdFromRequest = amendmentRequest.getDeclaration();

    // validate if either crn or mrn is present in the amendmentRequest
    Set<ConstraintViolation<TemporaryStorageDeclaration>> violations =
        amendmentValidator.validateInitialProcessing(tsdFromRequest);

    if (!violations.isEmpty()) {
      rejectAmendment(tsdFromRequest, null, violations, false);
      return;
    }

    Optional<TemporaryStorageDeclaration> tsd = findCurrentTSDVersion(tsdFromRequest);

    TemporaryStorageDeclaration currentTSD = tsd.isPresent() ? tsd.get() : null;
    violations =
        amendmentValidator.validateAmendmentRequestCanBeProcessed(tsdFromRequest, currentTSD);

    if (!violations.isEmpty()) {
      if (containsR0104OrR135(violations)) rejectAmendment(tsdFromRequest, null, violations, false);
      else
        // reject amendment and save message exchange on currentTSD
        rejectAmendment(tsdFromRequest, currentTSD, violations, true);
      return;
    }
    // Added to send MRN and CRN both in reject message
    if (null != currentTSD) {
      ReferenceNumber refNumber = currentTSD.getReferenceNumber();
      tsdFromRequest.setReferenceNumber(refNumber);
    }
    if (tsdFromRequest.isEnsReuseRequested()) {
      log.info(
          "In method processAmendmentRequest EnsReuseIndicator on with value of {}",
          tsdFromRequest.getEnsReUseIndicator());
      tsdFromRequest.setLrn(null != currentTSD ? currentTSD.getLrn() : null);
      try {
        ensReuser.prefillTSDFromENSes(tsdFromRequest);
      } catch (ReuseFailedException e) {
        log.debug(e.getMessage());
        violations = e.toConstraintViolation();
        // reject amendment and save message exchange on currentTSD
        rejectAmendment(tsdFromRequest, currentTSD, violations, true);
        return;
      }
    }

    loadDeclarantAndRepresentativeDetails(tsdFromRequest);
    prefillName(tsdFromRequest);

    violations = amendmentValidator.validateAmendment(tsdFromRequest, currentTSD);

    violations = validateAndSendLockOffwritableDocumentRequest(violations, currentTSD);

    boolean isManualProcessReq =
        amendmentValidator.doesAmendmentRequireManualApproval(tsdFromRequest, currentTSD);

    saveAmendmentAndSendMessagesToOtherSystems(
        tsdFromRequest, violations, currentTSD, isManualProcessReq);
  }

  private boolean containsR0104OrR135(
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    return violations.stream()
        .anyMatch(
            violation ->
                null != violation.getMessageTemplate()
                    && (violation.getMessageTemplate().contains(ErrorCode.TSPNESXXR0104.toString())
                        || violation
                            .getMessageTemplate()
                            .contains(ErrorCode.TSPNESXXR0135.toString())));
  }

  private void saveAmendmentAndSendMessagesToOtherSystems(
      TemporaryStorageDeclaration tsdFromRequest,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations,
      TemporaryStorageDeclaration currentTSD,
      boolean isManualProcessReq) {
    List<Error> errors = new ArrayList<>();
    if (!violations.isEmpty()) {
      // reject amendment and save message exchange on currentTSD
      if (containsDuplicateGoodsItemNumberViolation(violations))
        rejectAmendment(tsdFromRequest, currentTSD, violations, true);
      else {
        // save and reject amendment, also save message exchange on requestTSD
        errors =
            tsdResponseSender.buildErrors(
                violations, tsdFromRequest.getMessageInformation().getLanguageCode(), false, false);
        tsdFromRequest = saveAmendment(tsdFromRequest, currentTSD, errors);
        rejectAmendment(tsdFromRequest, null, violations, true);
      }
      return;

    } else {
      if (isManualProcessReq) tsdFromRequest.setCurrentStatus(IRREGULARITY_UNDER_INVESTIGATION);
      tsdFromRequest = saveAmendment(tsdFromRequest, currentTSD, errors);
    }

    if (errors.isEmpty() && currentTSD != null) {
      tsdResponseSender.sendAcceptMessage(
          tsdFromRequest, BusinessValidationType.TSD_AMENDMENT_REQUEST);
      LocalDateTime awaitingRiskResultHours =
          calculateExpirationTimestamp(TimerType.RISK_ANALYSIS_RESULT);
      if ((tsdFromRequest.getType() == COMBINED
              || (tsdFromRequest.getType() == PRELODGED
                  && tsdFromRequest.getCurrentStatus() == TSDStatus.ACCEPTED))
          && awaitingRiskResultHours != null) {
        timerService.stopExpirationTimer(
            currentTSD.getReferenceNumber().getCrn().getCrnNumber(),
            TimerType.RISK_ANALYSIS_RESULT);
        timerService.createExpirationTimer(
            awaitingRiskResultHours,
            tsdFromRequest.getReferenceNumber().getCrn().getCrnNumber(),
            TimerType.RISK_ANALYSIS_RESULT);
      }
      tsdFromRequest.addRiskAnalysisAndHistory(
          awaitingRiskResultHours, RiskAndControlStatus.AWAITING_RISK_ANALYSIS_RESULT);
      riskAnalysisGateway.sendTSDToRiskAnalysis(tsdFromRequest, true, false);
      // Trigger IEGA115
      if (tsdFromRequest.getCurrentStatus() != TSDStatus.PRELODGED)
        gaGateway.sendOffWritableDocument(tsdFromRequest);
    }
  }

  private Set<ConstraintViolation<TemporaryStorageDeclaration>>
      validateAndSendLockOffwritableDocumentRequest(
          Set<ConstraintViolation<TemporaryStorageDeclaration>> violations,
          TemporaryStorageDeclaration currentTSD) {
    if (currentTSD != null && currentTSD.getLinkedPnFrn() != null && violations.isEmpty()) {
      // send request for IEGA904 lockOffwritableDocumentForAmendment
      violations =
          gaGateway.lockOffwritableDocument(
              currentTSD.getTransferNotification(),
              currentTSD.getReferenceNumber().getMrn().getMrnNumber(),
              LockOffwritableDocumentStatusReason.AMENDMENT);
    }
    return violations;
  }

  /**
   * This method is use to create draft amendment
   *
   * @param declaration
   */
  public TemporaryStorageDeclaration createAmendment(TemporaryStorageDeclaration declaration) {
    if (!(declaration.getCurrentStatus() == TSDStatus.ACCEPTED
        || declaration.getCurrentStatus() == TSDStatus.PRELODGED)) {
      CustomViolation.doThrow(ErrorCode.TSPNESXXR0318, TSD_ID);
    }
    Optional<Long> draftAmendmentId =
        repository.getDraftAmendmentID(declaration.getReferenceNumber().getCrn(), TSDStatus.DRAFT);
    if (draftAmendmentId.isPresent()) {
      CustomViolation.doThrow(ErrorCode.TSPNESXXR0327, TSD_ID);
    }
    validateAmendmentSizeBig(declaration);
    validateAmendDeconsolidationAndTransferNotification(declaration);

    TemporaryStorageDeclaration draftDeclaration = null;
    if (!declaration.isEnsReuseRequested()) {
      draftDeclaration = mapper.clone(declaration);
      // Setting consignment and item type
      mapper.setConsignmentAndItemType(draftDeclaration, declaration);
    } else {
      draftDeclaration = mapper.cloneTSDWihENSReuse(declaration);
    }

    Integer maxVersion =
        repository.findMaxVersionTSD(declaration.getReferenceNumber().getCrn(), TSDStatus.DRAFT);
    draftDeclaration.setCurrentVersion(maxVersion + 1);
    draftDeclaration.setRegistrationDate(Now.localDateTime());
    draftDeclaration.setReferenceNumber(declaration.getReferenceNumber());
    draftDeclaration.completeDraftAmendment();
    repository.save(draftDeclaration);
    draftDeclaration.getReferenceNumber().setDraftAmendmentId(draftDeclaration.getId());
    LocalDateTime expirationTimestamp =
        calculateExpirationTimestamp(TimerType.TSD_DRAFT_EXPIRATION);
    // creation of draft removal timer
    timerService.createExpirationTimer(
        expirationTimestamp, draftDeclaration.getId().toString(), TimerType.TSD_DRAFT_EXPIRATION);
    return draftDeclaration;
  }

  private Optional<TemporaryStorageDeclaration> findCurrentTSDVersion(
      TemporaryStorageDeclaration tsdFromRequest) {
    Optional<TemporaryStorageDeclaration> tsd;
    if (!tsdFromRequest.getReferenceNumber().isMrnBlank()) {
      tsd = repository.findCurrentVersion(tsdFromRequest.getReferenceNumber().getMrn());
    } else {
      tsd = repository.findCurrentVersion(tsdFromRequest.getReferenceNumber().getCrn());
    }
    return tsd;
  }

  private boolean containsDuplicateGoodsItemNumberViolation(
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    return violations.stream()
        .anyMatch(
            violation ->
                null != violation.getMessageTemplate()
                    && (violation.getMessageTemplate().contains(ErrorCode.TSPNESXXR0122.toString())
                        || violation
                            .getMessageTemplate()
                            .contains(ErrorCode.TSPNESXXR0121.toString())));
  }

  private void rejectAmendment(
      TemporaryStorageDeclaration amendedDeclaration,
      TemporaryStorageDeclaration currentDeclaration,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations,
      boolean registerMessageExchange) {
    tsdResponseSender.sendAmendmentRejectMessage(
        amendedDeclaration,
        currentDeclaration,
        violations,
        BusinessValidationType.TSD_AMENDMENT_REQUEST,
        registerMessageExchange);
  }

  private void loadDeclarantAndRepresentativeDetails(TemporaryStorageDeclaration tsd) {
    partyLoader.loadPartyDetails(tsd.getDeclarant());
    if (null != tsd.getRepresentative()) {
      partyLoader.loadPartyDetails(tsd.getRepresentative());
    }
  }

  private TemporaryStorageDeclaration saveAmendment(
      TemporaryStorageDeclaration tsdFromRequest,
      TemporaryStorageDeclaration currentTSD,
      List<Error> errors) {
    if (null != currentTSD) {
      Integer maxVersion =
          repository.findMaxVersionTSD(currentTSD.getReferenceNumber().getCrn(), TSDStatus.DRAFT);
      tsdFromRequest.copyAmendmentAttributes(currentTSD, errors);
      tsdFromRequest.setCurrentVersion(maxVersion + 1);
      if (errors.isEmpty()) {
        // Update reference number link
        tsdFromRequest.getReferenceNumber().setDeclaration(tsdFromRequest);
      }
      tsdFromRequest.updateConsignmentTypeAndItemType();
      tsdFromRequest = repository.save(tsdFromRequest);
    }
    return tsdFromRequest;
  }

  /**
   * This method is used to create Timer
   *
   * @return LocalDateTime
   */
  public LocalDateTime calculateExpirationTimestamp(TimerType type) {
    if (type == TSD_EXPIRATION) {
      return Now.localDateTime()
          .plusDays(tsdConfig.getExpirationTimestampPeriod())
          .atOffset(ZoneOffset.UTC)
          .toLocalDateTime();
    } else if (type == TSD_DRAFT_EXPIRATION) {
      return Now.localDateTime()
          .plusDays(tsdConfig.getDraftTSDRemovalPeriod())
          .atOffset(ZoneOffset.UTC)
          .toLocalDateTime();
    } else if (type == RISK_ANALYSIS_RESULT
        && tsdConfig.getAwaitingRiskResultHours() != null
        && tsdConfig.getAwaitingRiskResultHours() > 0) {
      return Now.localDateTime()
          .plusHours(tsdConfig.getAwaitingRiskResultHours())
          .atOffset(ZoneOffset.UTC)
          .toLocalDateTime();
    }
    return null;
  }

  /**
   * To validate if current tsd which is amended is too big
   *
   * @param tsd
   */
  private void validateAmendmentSizeBig(TemporaryStorageDeclaration tsd) {
    if (null != tsd.getMasterConsignment()
        && isListSizeMoreThenHundred(tsd.getMasterConsignment().getConsignmentItem())) {
      CustomViolation.doThrow(ErrorCode.TSPNESXXR0328, TSD_ID);
    }
    if (isListSizeMoreThenHundred(tsd.getHouseConsignments())) {
      CustomViolation.doThrow(ErrorCode.TSPNESXXR0328, TSD_ID);
    }
    if (!isEmpty(tsd.getHouseConsignments())) {
      boolean result =
          tsd.getHouseConsignments().stream()
              .anyMatch((hc) -> isListSizeMoreThenHundred(hc.getConsignmentItem()));
      if (result) {
        CustomViolation.doThrow(ErrorCode.TSPNESXXR0328, TSD_ID);
        ;
      }
    }
  }

  private boolean isListSizeMoreThenHundred(Collection<?> c) {
    if (isEmpty(c)) return false;
    return c.size() > 100;
  }

  private void validateAmendDeconsolidationAndTransferNotification(
      TemporaryStorageDeclaration currentTSD) {
    if ((currentTSD.getDeconsolidationNotification() != null
            && currentTSD.getDeconsolidationNotification().getStatus()
                == DeconsolidationNotificationStatus.APPROVED)
        || (currentTSD.getTransferNotification() != null
            && currentTSD.getTransferNotification().getStatus()
                == TransferNotificationStatus.APPROVED)) {
      CustomViolation.doThrow(ErrorCode.TSPNESXXR0333, TSD_ID);
    }
  }

  /**
   * Prefill name of party on the basis of crs data
   *
   * @param declaration
   */
  private void prefillName(TemporaryStorageDeclaration declaration) {
    if (null != declaration.getPersonPresentingTheGoods()
        && null == declaration.getPersonPresentingTheGoods().getName()) {
      declaration
          .getPersonPresentingTheGoods()
          .setName(
              getNameFromCrs(declaration.getPersonPresentingTheGoods().getIdentificationNumber()));
    }
    if (null != declaration.getConsignmentHeader().getCarrier()
        && null == declaration.getConsignmentHeader().getCarrier().getName()) {
      declaration
          .getConsignmentHeader()
          .getCarrier()
          .setName(
              getNameFromCrs(
                  declaration.getConsignmentHeader().getCarrier().getIdentificationNumber()));
    }
  }

  /**
   * get name for person and carrier
   *
   * @param identificationNumber
   * @return
   */
  private String getNameFromCrs(String identificationNumber) {
    Optional<Party> party = partyLoader.loadPartyDetails(identificationNumber);
    return party.isPresent() ? party.get().getName() : null;
  }
}
