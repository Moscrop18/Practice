package be.fgov.minfin.tsd.domain.validation;

import static be.fgov.minfin.tsd.domain.model.TSDStatus.ACCEPTED;
import static be.fgov.minfin.tsd.domain.model.TSDStatus.PRELODGED;

import be.fgov.minfin.tsd.domain.model.DeconsolidationNotificationStatus;
import be.fgov.minfin.tsd.domain.model.ReferenceNumber;
import be.fgov.minfin.tsd.domain.model.TSDStatus;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.TransferNotificationStatus;
import be.fgov.minfin.tsd.domain.model.consignment.Commodity;
import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentHeader;
import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentItem;
import be.fgov.minfin.tsd.domain.model.consignment.HouseConsignment;
import be.fgov.minfin.tsd.domain.model.consignment.LocationOfGoods;
import be.fgov.minfin.tsd.domain.model.consignment.MasterConsignment;
import be.fgov.minfin.tsd.domain.model.consignment.Packaging;
import be.fgov.minfin.tsd.domain.model.consignment.Receptacle;
import be.fgov.minfin.tsd.domain.model.consignment.Seal;
import be.fgov.minfin.tsd.domain.model.consignment.TransportDocument;
import be.fgov.minfin.tsd.domain.model.consignment.TransportEquipment;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import be.fgov.minfin.tsd.domain.validation.message.MessageType;
import be.fgov.minfin.tsd.domain.validation.plugin.AmendmentValidatorPlugin;
import be.fgov.minfin.tsd.domain.validation.plugin.TSDValidatorPlugin;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import javax.validation.ConstraintViolation;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

/**
 * This class is used to validate business rules corresponding to amendment of declaration
 *
 * @author Gaurav Mitra
 */
@Component
@RequiredArgsConstructor
public class AmendmentValidator implements AmendmentValidatorPlugin {
  private final TSDValidatorPlugin tsdValidator;

  private static final String CRN = "crn";
  private static final String MRN = "mrn";
  private static final String ENS = "ensReUseIndicator";
  private static final String DATE_AND_TIME_OF_PRESEN_OF_GOODS =
      "dateAndTimeOfPresentationOfTheGoods";
  private static final String CUSTOMS_OFFICE_OF_PRESEN = "customsOfficeOfPresentation";
  private static final String SUPERVISING_CUSTOMS_OFFICE = "supervisingCustomsOffice";
  private static final String REFERENCE_NUMBER = "referenceNumber";
  private static final String PERSON_PRESEN_GOODS = "personPresentingTheGoods";
  private static final String CARRIER = "carrier";
  private static final String DECLARATION_DATE = "declarationDate";
  private static final String DECLARANT = "declarant";
  private static final String IDENTIFICATION_NUMBER = "identificationNumber";
  private static final String TRANSPORT_DOCUMENT = "transportDocument";
  private static final String DOT = ".";
  private static final String CONSIGNMENT_ITEM_MASTER_LEVEL = "consignmentItemMasterLevel[";
  private static final String CONSIGNMENT_ITEM_HOUSE_LEVEL = "consignmentItemHouseLevel[";
  private static final String CONSIGNMENT_HOUSE_LEVEL = "consignmentHouseLevel[";
  private static final String CONSIGNMENT_MASTER_LEVEL = "consignmentMasterLevel";
  private static final String PREVIOUS_DOCUMENT = "previousDocument";
  private static final String LOCATION_OF_GOODS = "decalaredlocationOfGoods";
  private static final String MASTER_CONSIGNMENT = "masterConsignment";
  private static final String HEADER_MASTER_LEVEL = "consignmentHeader";

  public Set<ConstraintViolation<TemporaryStorageDeclaration>> validateAmendment(
      TemporaryStorageDeclaration requestTSD, TemporaryStorageDeclaration currentTSD) {
    requestTSD.setType(currentTSD.getType());
    Set<ConstraintViolation<TemporaryStorageDeclaration>> allViolations = new HashSet<>();
    Set<ConstraintViolation<TemporaryStorageDeclaration>> violations = validateTSD(requestTSD);

    if (!violations.isEmpty()) {
      allViolations.addAll(violations);
    }

    validateTSPNESXXC0113(requestTSD, currentTSD, allViolations);
    validateTSPNESXXR0114(requestTSD, currentTSD, allViolations);
    validateTSPNESXXR0115(requestTSD, currentTSD, allViolations);
    validateTSPNESXXR0116(requestTSD, currentTSD, allViolations);
    validateTSPNESXXR0117(requestTSD, currentTSD, allViolations);
    validateTSPNESXXR0121(requestTSD, allViolations);
    validateTSPNESXXR0122(requestTSD, allViolations);
    validateTSPNESXXR0155(currentTSD, allViolations);
    validateTSPNESXXR0156(currentTSD, allViolations);

    return allViolations;
  }

  private Set<ConstraintViolation<TemporaryStorageDeclaration>> validateTSD(
      TemporaryStorageDeclaration requestTSD) {
    return tsdValidator.validateTSD(requestTSD, MessageType.TSD_AMENDMENT_MESSAGE);
  }

  public Set<ConstraintViolation<TemporaryStorageDeclaration>> validateInitialProcessing(
      TemporaryStorageDeclaration requestTSD) {
    Set<ConstraintViolation<TemporaryStorageDeclaration>> violations = new HashSet<>();

    ReferenceNumber referenceNumber = requestTSD.getReferenceNumber();

    // violated if both are null/empty or if both are provided
    if (referenceNumber == null
        || (!referenceNumber.isCrnBlank() && !referenceNumber.isMrnBlank())
        || (referenceNumber.isCrnBlank() && referenceNumber.isMrnBlank())) {
      CustomViolation<TemporaryStorageDeclaration> violation =
          new CustomViolation<>(ErrorCode.TSPNESXXR0136, MRN);
      violations.add(violation);
      return violations;
    }

    return violations;
  }

  public Set<ConstraintViolation<TemporaryStorageDeclaration>>
      validateAmendmentRequestCanBeProcessed(
          TemporaryStorageDeclaration requestTSD, TemporaryStorageDeclaration currentTSD) {
    Set<ConstraintViolation<TemporaryStorageDeclaration>> violations = new HashSet<>();
    boolean isDraftAmend =
        null != requestTSD.getCurrentStatus() && requestTSD.getCurrentStatus() == TSDStatus.DRAFT;
    if (!isDraftAmend) {
      voilateIfCurrentTSDNotFoundForGivenCrn(requestTSD, currentTSD, violations);
      voilateIfCurrentTSDNotFoundForGivenMrn(requestTSD, currentTSD, violations);
      voilateIfCurrentTSDIsFoundAndRecepTimestampIsBad(requestTSD, currentTSD, violations);
    }
    voilateIfCurrentTSDIsFoundAndTSDStatusIsBad(requestTSD, currentTSD, violations);
    voilateIfCurrentTSDIsFoundAndEnsReUseIsBad(requestTSD, currentTSD, violations);

    return violations;
  }

  protected void voilateIfCurrentTSDNotFoundForGivenCrn(
      TemporaryStorageDeclaration requestTSD,
      TemporaryStorageDeclaration currentTSD,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    if (!requestTSD.getReferenceNumber().isCrnBlank() && currentTSD == null) {
      CustomViolation<TemporaryStorageDeclaration> violation =
          new CustomViolation<>(ErrorCode.TSPNESXXR0104, CRN);
      violations.add(violation);
    }
  }

  protected void voilateIfCurrentTSDNotFoundForGivenMrn(
      TemporaryStorageDeclaration requestTSD,
      TemporaryStorageDeclaration currentTSD,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    if (!requestTSD.getReferenceNumber().isMrnBlank() && currentTSD == null) {
      CustomViolation<TemporaryStorageDeclaration> violation =
          new CustomViolation<>(ErrorCode.TSPNESXXR0135, MRN);
      violations.add(violation);
    }
  }

  protected void voilateIfCurrentTSDIsFoundAndTSDStatusIsBad(
      TemporaryStorageDeclaration requestTSD,
      TemporaryStorageDeclaration currentTSD,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    if (currentTSD != null
        && !(currentTSD.getCurrentStatus() == PRELODGED
            || currentTSD.getCurrentStatus() == ACCEPTED)) {
      CustomViolation<TemporaryStorageDeclaration> violation =
          new CustomViolation<>(
              ErrorCode.TSPNESXXR0112, requestTSD.getReferenceNumber().isMrnBlank() ? CRN : MRN);
      violations.add(violation);
    }
  }

  protected void voilateIfCurrentTSDIsFoundAndEnsReUseIsBad(
      TemporaryStorageDeclaration requestTSD,
      TemporaryStorageDeclaration currentTSD,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    if (currentTSD != null
        && (("1".equals(requestTSD.getEnsReUseIndicator())
                && currentTSD.getEnsReUseIndicator() == null)
            || (requestTSD.getEnsReUseIndicator() == null
                && "1".equals(currentTSD.getEnsReUseIndicator()))
            || (requestTSD.getEnsReUseIndicator() != null
                && !requestTSD.getEnsReUseIndicator().equals(currentTSD.getEnsReUseIndicator())))) {
      CustomViolation<TemporaryStorageDeclaration> violation =
          new CustomViolation<>(ErrorCode.TSPNESXXR0115, ENS);
      violations.add(violation);
    }
  }

  protected void voilateIfCurrentTSDIsFoundAndRecepTimestampIsBad(
      TemporaryStorageDeclaration requestTSD,
      TemporaryStorageDeclaration currentTSD,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    if (currentTSD != null
        && requestTSD.getMessageInformation().getReceptionTimestamp() != null
        && currentTSD.getMessageInformation().getReceptionTimestamp() != null
        && !requestTSD
            .getMessageInformation()
            .getReceptionTimestamp()
            .isAfter(currentTSD.getMessageInformation().getReceptionTimestamp())) {
      CustomViolation<TemporaryStorageDeclaration> violation =
          new CustomViolation<>(
              ErrorCode.TSPNESXXR0119, requestTSD.getReferenceNumber().isMrnBlank() ? CRN : MRN);
      violations.add(violation);
    }
  }

  private void validateTSPNESXXC0113(
      TemporaryStorageDeclaration requestTSD,
      TemporaryStorageDeclaration currentTSD,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {

    validateTSPNESXXC0113ForDateAndTimePresGoods(requestTSD, currentTSD, violations);
    validateTSPNESXXC0113ForCustomsOffc(requestTSD, currentTSD, violations);
    validateTSPNESXXC0113ForPersonPresenGoods(requestTSD, currentTSD, violations);
    validateTSPNESXXC0113ForCarrier(requestTSD, currentTSD, violations);
  }

  private void validateTSPNESXXC0113ForDateAndTimePresGoods(
      TemporaryStorageDeclaration requestTSD,
      TemporaryStorageDeclaration currentTSD,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    if ((currentTSD.getCurrentStatus() == PRELODGED
            && requestTSD.getDateAndTimeOfPresentationOfTheGoods() != null)
        || (currentTSD.getCurrentStatus() != PRELODGED
            && requestTSD.getDateAndTimeOfPresentationOfTheGoods() == null)) {
      CustomViolation<TemporaryStorageDeclaration> violation =
          new CustomViolation<>(ErrorCode.TSPNESXXC0113, DATE_AND_TIME_OF_PRESEN_OF_GOODS);
      violations.add(violation);
    }
  }

  private void validateTSPNESXXC0113ForCustomsOffc(
      TemporaryStorageDeclaration requestTSD,
      TemporaryStorageDeclaration currentTSD,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    if ((currentTSD.getCurrentStatus() == PRELODGED
            && requestTSD.getCustomsOfficeOfPresentation() != null)
        || (currentTSD.getCurrentStatus() != PRELODGED
            && requestTSD.getCustomsOfficeOfPresentation() == null)) {
      CustomViolation<TemporaryStorageDeclaration> violation =
          new CustomViolation<>(ErrorCode.TSPNESXXC0113, CUSTOMS_OFFICE_OF_PRESEN);
      violations.add(violation);
    }
  }

  private void validateTSPNESXXC0113ForPersonPresenGoods(
      TemporaryStorageDeclaration requestTSD,
      TemporaryStorageDeclaration currentTSD,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    if ((currentTSD.getCurrentStatus() == PRELODGED
            && requestTSD.getPersonPresentingTheGoods() != null)
        || (currentTSD.getCurrentStatus() != PRELODGED
            && requestTSD.getPersonPresentingTheGoods() == null)) {
      CustomViolation<TemporaryStorageDeclaration> violation =
          new CustomViolation<>(ErrorCode.TSPNESXXC0113, PERSON_PRESEN_GOODS);
      violations.add(violation);
    }
  }

  private void validateTSPNESXXC0113ForCarrier(
      TemporaryStorageDeclaration requestTSD,
      TemporaryStorageDeclaration currentTSD,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    if ((currentTSD.getCurrentStatus() == PRELODGED
            && requestTSD.getConsignmentHeader() != null
            && requestTSD.getConsignmentHeader().getCarrier() != null)
        || (currentTSD.getCurrentStatus() != PRELODGED
            && requestTSD.getConsignmentHeader() != null
            && requestTSD.getConsignmentHeader().getCarrier() == null)) {
      CustomViolation<TemporaryStorageDeclaration> violation =
          new CustomViolation<>(ErrorCode.TSPNESXXC0113, HEADER_MASTER_LEVEL + DOT + CARRIER);
      violations.add(violation);
    }
  }

  private void validateTSPNESXXR0114(
      TemporaryStorageDeclaration requestTSD,
      TemporaryStorageDeclaration currentTSD,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    if (currentTSD.getCurrentStatus() == PRELODGED && requestTSD.getDeclarationDate() != null) {
      CustomViolation<TemporaryStorageDeclaration> violation =
          new CustomViolation<>(ErrorCode.TSPNESXXR0114, DECLARATION_DATE);
      violations.add(violation);
    }
  }

  private void validateTSPNESXXR0115(
      TemporaryStorageDeclaration requestTSD,
      TemporaryStorageDeclaration currentTSD,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {

    validateTSPNESXXR0115ForDeclarationDate(requestTSD, currentTSD, violations);
    validateTSPNESXXR0115ForPresenOfGoodsDate(requestTSD, currentTSD, violations);
    validateTSPNESXXR0115ForCustomsOffice(requestTSD, currentTSD, violations);
    validateTSPNESXXR0115ForDeclarant(requestTSD, currentTSD, violations);

    validateTSPNESXXR0115ForMCTransportDoc(requestTSD, currentTSD, violations);
    validateTSPNESXXR0115ForPreviousDocument(requestTSD, currentTSD, violations);
    validateTSPNESXXR0115ForCarrier(requestTSD, currentTSD, violations);
  }

  private void validateTSPNESXXR0115ForDeclarationDate(
      TemporaryStorageDeclaration requestTSD,
      TemporaryStorageDeclaration currentTSD,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    if (twoTimestampsAreUnequal(requestTSD.getDeclarationDate(), currentTSD.getDeclarationDate())) {
      CustomViolation<TemporaryStorageDeclaration> violation =
          new CustomViolation<>(ErrorCode.TSPNESXXR0115, DECLARATION_DATE);
      violations.add(violation);
    }
  }

  private void validateTSPNESXXR0115ForPresenOfGoodsDate(
      TemporaryStorageDeclaration requestTSD,
      TemporaryStorageDeclaration currentTSD,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    if (twoTimestampsAreUnequal(
        requestTSD.getDateAndTimeOfPresentationOfTheGoods(),
        currentTSD.getDateAndTimeOfPresentationOfTheGoods())) {
      CustomViolation<TemporaryStorageDeclaration> violation =
          new CustomViolation<>(ErrorCode.TSPNESXXR0115, DATE_AND_TIME_OF_PRESEN_OF_GOODS);
      violations.add(violation);
    }
  }

  private void validateTSPNESXXR0115ForCustomsOffice(
      TemporaryStorageDeclaration requestTSD,
      TemporaryStorageDeclaration currentTSD,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    if ((requestTSD.getCustomsOfficeOfPresentation() == null
            && currentTSD.getCustomsOfficeOfPresentation() != null)
        || (requestTSD.getCustomsOfficeOfPresentation() != null
            && currentTSD.getCustomsOfficeOfPresentation() == null)
        || (requestTSD.getCustomsOfficeOfPresentation() != null
            && currentTSD.getCustomsOfficeOfPresentation() != null
            && !requestTSD
                .getCustomsOfficeOfPresentation()
                .getReferenceNumber()
                .equals(currentTSD.getCustomsOfficeOfPresentation().getReferenceNumber()))) {
      CustomViolation<TemporaryStorageDeclaration> violation =
          new CustomViolation<>(ErrorCode.TSPNESXXR0115, CUSTOMS_OFFICE_OF_PRESEN);
      violations.add(violation);
    }
  }

  private void validateTSPNESXXR0115ForDeclarant(
      TemporaryStorageDeclaration requestTSD,
      TemporaryStorageDeclaration currentTSD,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {

    if (currentTSD.getDeclarant() == null
        || (currentTSD.getDeclarant() != null
            && !requestTSD
                .getDeclarant()
                .getIdentificationNumber()
                .equals(currentTSD.getDeclarant().getIdentificationNumber()))) {
      CustomViolation<TemporaryStorageDeclaration> violation =
          new CustomViolation<>(ErrorCode.TSPNESXXR0115, DECLARANT + DOT + IDENTIFICATION_NUMBER);
      violations.add(violation);
    }
  }

  private void validateTSPNESXXR0115ForMCTransportDoc(
      TemporaryStorageDeclaration requestTSD,
      TemporaryStorageDeclaration currentTSD,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {

    if (requestTSD.getMasterConsignment() == null
        && currentTSD.getMasterConsignment() != null
        && currentTSD.getMasterConsignment().getTransportDocument() != null) {
      CustomViolation<TemporaryStorageDeclaration> violation =
          new CustomViolation<>(
              ErrorCode.TSPNESXXR0115, MASTER_CONSIGNMENT + DOT + TRANSPORT_DOCUMENT);
      violations.add(violation);
      return;
    }

    if (requestTSD.getMasterConsignment() != null
        && (currentTSD.getMasterConsignment() == null
            || currentTSD.getMasterConsignment().getTransportDocument() == null)) {
      CustomViolation<TemporaryStorageDeclaration> violation =
          new CustomViolation<>(
              ErrorCode.TSPNESXXR0115, MASTER_CONSIGNMENT + DOT + TRANSPORT_DOCUMENT);
      violations.add(violation);
      return;
    }

    if (requestTSD.getMasterConsignment() != null
        && currentTSD.getMasterConsignment() != null
        && currentTSD.getMasterConsignment().getTransportDocument() != null) {

      TransportDocument currentTransportDocument =
          currentTSD.getMasterConsignment().getTransportDocument();
      TransportDocument requesttransportDocument =
          requestTSD.getMasterConsignment().getTransportDocument();
      String currentTransportDoc =
          currentTransportDocument.getReferenceNumber().toLowerCase()
              + currentTransportDocument.getType().toLowerCase();
      String requestTransportDoc =
          requesttransportDocument.getReferenceNumber().toLowerCase()
              + requesttransportDocument.getType().toLowerCase();
      if (!currentTransportDoc.equals(requestTransportDoc)) {
        CustomViolation<TemporaryStorageDeclaration> violation =
            new CustomViolation<>(
                ErrorCode.TSPNESXXR0115, MASTER_CONSIGNMENT + DOT + TRANSPORT_DOCUMENT);
        violations.add(violation);
      }
    }
  }

  protected void validateTSPNESXXR0115ForPreviousDocument(
      TemporaryStorageDeclaration requestTSD,
      TemporaryStorageDeclaration currentTSD,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {

    Set<String> currentPreviousDocuments = new HashSet<>();
    getAllCurrentPreviousDocsFromMCAndTheirItems(currentTSD, currentPreviousDocuments);
    getAllCurrentPreviousDocsFromHCAndTheirItems(currentTSD, currentPreviousDocuments);
    validatePreviousDocsForMCAndTheirItems(requestTSD, currentPreviousDocuments, violations);
    validatePreviousDocsForHCAndTheirItems(requestTSD, currentPreviousDocuments, violations);
  }

  private void getAllCurrentPreviousDocsFromMCAndTheirItems(
      TemporaryStorageDeclaration currentTSD, Set<String> currentPreviousDocuments) {
    if (currentTSD.getMasterConsignment() != null) {
      MasterConsignment currentMasterConsignment = currentTSD.getMasterConsignment();
      if (currentMasterConsignment.getPreviousDocument() != null) {
        currentPreviousDocuments.add(
            currentMasterConsignment.getPreviousDocument().getReferenceNumber().toLowerCase()
                + currentMasterConsignment.getPreviousDocument().getType().toLowerCase());
      }

      if (null != currentMasterConsignment.getConsignmentItem()) {
        getAllCurrentPreviousDocumentsFromCI(
            currentMasterConsignment.getConsignmentItem(), currentPreviousDocuments);
      }
    }
  }

  private void getAllCurrentPreviousDocumentsFromCI(
      List<ConsignmentItem> currentConsignmentItems, Set<String> currentPreviousDocuments) {
    for (ConsignmentItem item : currentConsignmentItems) {
      if (item.getPreviousDocument() != null) {
        currentPreviousDocuments.add(
            item.getPreviousDocument().getReferenceNumber().toLowerCase()
                + item.getPreviousDocument().getType().toLowerCase());
      }
    }
  }

  private void getAllCurrentPreviousDocsFromHCAndTheirItems(
      TemporaryStorageDeclaration currentTSD, Set<String> currentPreviousDocuments) {
    if (!CollectionUtils.isEmpty(currentTSD.getHouseConsignments())) {
      for (HouseConsignment currentHouseConsignment : currentTSD.getHouseConsignments()) {
        if (null != currentHouseConsignment.getPreviousDocument()) {
          currentPreviousDocuments.add(
              currentHouseConsignment.getPreviousDocument().getReferenceNumber().toLowerCase()
                  + currentHouseConsignment.getPreviousDocument().getType().toLowerCase());
        }

        if (null != currentHouseConsignment.getConsignmentItem()) {
          getAllCurrentPreviousDocumentsFromCI(
              currentHouseConsignment.getConsignmentItem(), currentPreviousDocuments);
        }
      }
    }
  }

  private void validatePreviousDocsForMCAndTheirItems(
      TemporaryStorageDeclaration requestTSD,
      Set<String> currentPreviousDocuments,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {

    if (requestTSD.getMasterConsignment() != null) {
      MasterConsignment requestMasterConsignment = requestTSD.getMasterConsignment();
      if (requestMasterConsignment.getPreviousDocument() != null) {
        String previousDocumentRequest =
            requestMasterConsignment.getPreviousDocument().getReferenceNumber().toLowerCase()
                + requestMasterConsignment.getPreviousDocument().getType().toLowerCase();
        if (!currentPreviousDocuments.contains(previousDocumentRequest)) {
          CustomViolation<TemporaryStorageDeclaration> violation =
              new CustomViolation<>(
                  ErrorCode.TSPNESXXR0115,
                  HEADER_MASTER_LEVEL + DOT + CONSIGNMENT_MASTER_LEVEL + DOT + PREVIOUS_DOCUMENT);
          violations.add(violation);
        }
      }

      if (null != requestMasterConsignment.getConsignmentItem()) {
        validatePreviousDocsForCI(
            requestMasterConsignment.getConsignmentItem(),
            currentPreviousDocuments,
            violations,
            null);
      }
    }
  }

  private void validatePreviousDocsForCI(
      List<ConsignmentItem> requestConsignmentItems,
      Set<String> currentPreviousDocuments,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations,
      Integer indexOfHouseConsignment) {

    int indexOfConsignmentItem = 0;
    for (ConsignmentItem item : requestConsignmentItems) {
      if (item.getPreviousDocument() != null) {
        String requestPreviousDocument =
            item.getPreviousDocument().getReferenceNumber().toLowerCase()
                + item.getPreviousDocument().getType().toLowerCase();
        if (!currentPreviousDocuments.contains(requestPreviousDocument)) {

          if (indexOfHouseConsignment == null) {
            CustomViolation<TemporaryStorageDeclaration> violation =
                new CustomViolation<>(
                    ErrorCode.TSPNESXXR0115,
                    HEADER_MASTER_LEVEL
                        + DOT
                        + CONSIGNMENT_MASTER_LEVEL
                        + DOT
                        + CONSIGNMENT_ITEM_MASTER_LEVEL
                        + indexOfConsignmentItem
                        + "]"
                        + DOT
                        + PREVIOUS_DOCUMENT);
            violations.add(violation);
          } else {
            CustomViolation<TemporaryStorageDeclaration> violation =
                new CustomViolation<>(
                    ErrorCode.TSPNESXXR0115,
                    HEADER_MASTER_LEVEL
                        + DOT
                        + CONSIGNMENT_HOUSE_LEVEL
                        + indexOfHouseConsignment
                        + "]"
                        + DOT
                        + CONSIGNMENT_ITEM_HOUSE_LEVEL
                        + indexOfConsignmentItem
                        + "]"
                        + DOT
                        + PREVIOUS_DOCUMENT);
            violations.add(violation);
          }
        }
      }
      indexOfConsignmentItem++;
    }
  }

  private void validatePreviousDocsForHCAndTheirItems(
      TemporaryStorageDeclaration requestTSD,
      Set<String> currentPreviousDocuments,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    if (!CollectionUtils.isEmpty(requestTSD.getHouseConsignments())) {
      Integer indexOfHouseConsignment = 0;
      for (HouseConsignment houseConsignment : requestTSD.getHouseConsignments()) {
        if (null != houseConsignment.getPreviousDocument()) {
          String previousDocumentRequest =
              houseConsignment.getPreviousDocument().getReferenceNumber().toLowerCase()
                  + houseConsignment.getPreviousDocument().getType().toLowerCase();
          if (!currentPreviousDocuments.contains(previousDocumentRequest)) {
            CustomViolation<TemporaryStorageDeclaration> violation =
                new CustomViolation<>(
                    ErrorCode.TSPNESXXR0115,
                    HEADER_MASTER_LEVEL
                        + DOT
                        + CONSIGNMENT_HOUSE_LEVEL
                        + indexOfHouseConsignment
                        + "]"
                        + DOT
                        + PREVIOUS_DOCUMENT);
            violations.add(violation);
          }
        }

        if (null != houseConsignment.getConsignmentItem()) {
          validatePreviousDocsForCI(
              houseConsignment.getConsignmentItem(),
              currentPreviousDocuments,
              violations,
              indexOfHouseConsignment);
        }

        indexOfHouseConsignment++;
      }
    }
  }

  private void validateTSPNESXXR0115ForCarrier(
      TemporaryStorageDeclaration requestTSD,
      TemporaryStorageDeclaration currentTSD,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {

    if ((requestTSD.getConsignmentHeader() == null
            || requestTSD.getConsignmentHeader().getCarrier() == null)
        && (currentTSD.getConsignmentHeader() != null
            && currentTSD.getConsignmentHeader().getCarrier() != null)) {
      CustomViolation<TemporaryStorageDeclaration> violation =
          new CustomViolation<>(ErrorCode.TSPNESXXR0115, HEADER_MASTER_LEVEL + DOT + CARRIER);
      violations.add(violation);
      return;
    }

    if (requestTSD.getConsignmentHeader() != null
        && requestTSD.getConsignmentHeader().getCarrier() != null
        && (currentTSD.getConsignmentHeader() == null
            || currentTSD.getConsignmentHeader().getCarrier() == null)) {
      CustomViolation<TemporaryStorageDeclaration> violation =
          new CustomViolation<>(ErrorCode.TSPNESXXR0115, HEADER_MASTER_LEVEL + DOT + CARRIER);
      violations.add(violation);
      return;
    }

    if (requestTSD.getConsignmentHeader() != null
        && requestTSD.getConsignmentHeader().getCarrier() != null
        && currentTSD.getConsignmentHeader() != null
        && currentTSD.getConsignmentHeader().getCarrier() != null) {
      String currentCarrier =
          currentTSD.getConsignmentHeader().getCarrier().getName()
              + currentTSD.getConsignmentHeader().getCarrier().getIdentificationNumber();
      String requestCarrier =
          requestTSD.getConsignmentHeader().getCarrier().getName()
              + requestTSD.getConsignmentHeader().getCarrier().getIdentificationNumber();

      if (!currentCarrier.equals(requestCarrier)) {
        CustomViolation<TemporaryStorageDeclaration> violation =
            new CustomViolation<>(ErrorCode.TSPNESXXR0115, HEADER_MASTER_LEVEL + DOT + CARRIER);
        violations.add(violation);
      }
    }
  }

  private void validateTSPNESXXR0116(
      TemporaryStorageDeclaration requestTSD,
      TemporaryStorageDeclaration currentTSD,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    if (currentTSD.getCurrentStatus() == ACCEPTED
        && ((requestTSD.getSupervisingCustomsOffice() == null
                && currentTSD.getSupervisingCustomsOffice() != null)
            || (requestTSD.getSupervisingCustomsOffice() != null
                && currentTSD.getSupervisingCustomsOffice() == null)
            || (requestTSD.getSupervisingCustomsOffice() != null
                && currentTSD.getSupervisingCustomsOffice() != null
                && !requestTSD
                    .getSupervisingCustomsOffice()
                    .getReferenceNumber()
                    .equals(currentTSD.getSupervisingCustomsOffice().getReferenceNumber())))) {
      CustomViolation<TemporaryStorageDeclaration> violation =
          new CustomViolation<>(
              ErrorCode.TSPNESXXR0116, SUPERVISING_CUSTOMS_OFFICE + DOT + REFERENCE_NUMBER);
      violations.add(violation);
    }
    if (currentTSD.getCurrentStatus() == ACCEPTED
        && ((requestTSD.getMasterConsignment() == null && currentTSD.getMasterConsignment() != null)
            || (requestTSD.getMasterConsignment() != null
                && currentTSD.getMasterConsignment() == null))) {
      CustomViolation<TemporaryStorageDeclaration> violation =
          new CustomViolation<>(ErrorCode.TSPNESXXR0116, MASTER_CONSIGNMENT);
      violations.add(violation);
    }
  }

  private void validateTSPNESXXR0117(
      TemporaryStorageDeclaration requestTSD,
      TemporaryStorageDeclaration currentTSD,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    if (currentTSD.getCurrentStatus() != PRELODGED
        && (requestTSD.getConsignmentHeader() == null
            || requestTSD.getConsignmentHeader().getDecalaredlocationOfGoods() == null)) {
      CustomViolation<TemporaryStorageDeclaration> violation =
          new CustomViolation<>(
              ErrorCode.TSPNESXXR0117, HEADER_MASTER_LEVEL + DOT + LOCATION_OF_GOODS);
      violations.add(violation);
    }
  }

  private void validateTSPNESXXR0121(
      TemporaryStorageDeclaration requestTSD,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    if (null == requestTSD.getMasterConsignment()) return;
    List<Integer> goodsItemList = new ArrayList<>();
    MasterConsignment masterConsignment = requestTSD.getMasterConsignment();
    if (null != masterConsignment.getConsignmentItem()) {
      for (ConsignmentItem item : masterConsignment.getConsignmentItem()) {
        if (item.getGoodsItemNumber() != null) {
          goodsItemList.add(item.getGoodsItemNumber());
        }
      }
    }

    boolean allUnique = goodsItemList.stream().distinct().count() == goodsItemList.size();

    if (!allUnique) {
      CustomViolation<TemporaryStorageDeclaration> violation =
          new CustomViolation<>(ErrorCode.TSPNESXXR0121, MASTER_CONSIGNMENT);
      violations.add(violation);
    }
  }

  private void validateTSPNESXXR0122(
      TemporaryStorageDeclaration requestTSD,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    if (CollectionUtils.isEmpty(requestTSD.getHouseConsignments())) return;
    int indexOfHouseConsignment = 0;
    for (HouseConsignment houseConsignment : requestTSD.getHouseConsignments()) {
      List<Integer> goodsItemList = new ArrayList<>();
      if (null != houseConsignment.getConsignmentItem()) {
        for (ConsignmentItem item : houseConsignment.getConsignmentItem()) {
          if (item.getGoodsItemNumber() != null) {
            goodsItemList.add(item.getGoodsItemNumber());
          }
        }
        boolean allUnique = goodsItemList.stream().distinct().count() == goodsItemList.size();

        if (!allUnique) {
          CustomViolation<TemporaryStorageDeclaration> violation =
              new CustomViolation<>(
                  ErrorCode.TSPNESXXR0122,
                  HEADER_MASTER_LEVEL
                      + DOT
                      + CONSIGNMENT_HOUSE_LEVEL
                      + indexOfHouseConsignment
                      + "]");
          violations.add(violation);
          return;
        }
      }
      indexOfHouseConsignment++;
    }
  }

  public boolean doesAmendmentRequireManualApproval(
      TemporaryStorageDeclaration requestTSD, TemporaryStorageDeclaration currentTSD) {

    if (currentTSD.getCurrentStatus() == PRELODGED) return false;

    return checkManualApprRequiredForMasterConsignmentAndItems(requestTSD, currentTSD)
        || checkManualApprRequiredForHouseConsignmentAndItems(requestTSD, currentTSD)
        || checkManualApprRequiredForDeclaredLocationOfGoods(requestTSD, currentTSD)
        || checkManualApprRequiredForWarehouse(requestTSD, currentTSD);
  }

  protected boolean checkManualApprRequiredForMasterConsignmentAndItems(
      TemporaryStorageDeclaration requestTSD, TemporaryStorageDeclaration currentTSD) {

    if (currentTSD.getCurrentStatus() == ACCEPTED
        && requestTSD.getMasterConsignment() != null
        && currentTSD.getMasterConsignment() != null) {

      MasterConsignment requestMasterConsignment = requestTSD.getMasterConsignment();
      MasterConsignment currentMasterConsignment = currentTSD.getMasterConsignment();

      if (twoStringsAreUnequal(
              requestMasterConsignment.getReferenceNumberUCR(),
              currentMasterConsignment.getReferenceNumberUCR())
          || twoBigDecimalsAreUnequal(
              requestMasterConsignment.getTotalGrossMass(),
              currentMasterConsignment.getTotalGrossMass())
          || checkManualApprovalForTransportEquip(
              requestMasterConsignment.getTransportEquipment(),
              currentMasterConsignment.getTransportEquipment())
          || checkManualApprovalForReceptacle(
              requestMasterConsignment.getReceptacle(), currentMasterConsignment.getReceptacle())
          || checkManualApprRequiredForConsignmentItems(
              requestMasterConsignment.getConsignmentItem(),
              currentMasterConsignment.getConsignmentItem())) {

        return true;
      }
    }
    return false;
  }

  protected boolean checkManualApprovalForTransportEquip(
      List<TransportEquipment> requestTransportEquipment,
      List<TransportEquipment> currentTransportEquipment) {

    if (twoCollectionsAreUnEqual(requestTransportEquipment, currentTransportEquipment)) {
      return true;
    }

    if (!CollectionUtils.isEmpty(requestTransportEquipment)
        && !CollectionUtils.isEmpty(currentTransportEquipment)) {
      int requestTranEquiOrigSize = requestTransportEquipment.size();
      List<TransportEquipment> filteredRequestTransEquipment =
          requestTransportEquipment.stream()
              .filter(
                  requestTranEqui ->
                      currentTransportEquipment.stream()
                          .anyMatch(
                              currentTranEqui ->
                                  twoStringsAreEqual(
                                          requestTranEqui.getContainerIdentificationNumber(),
                                          currentTranEqui.getContainerIdentificationNumber())
                                      && twoStringsAreEqual(
                                          requestTranEqui.getContainerPackedStatus(),
                                          currentTranEqui.getContainerPackedStatus())
                                      && twoIntegersAreEqual(
                                          requestTranEqui.getNumberOfSeals(),
                                          currentTranEqui.getNumberOfSeals())
                                      && (checkIfSealsAreMatching(
                                          requestTranEqui, currentTranEqui))))
              .collect(Collectors.toList());
      return requestTranEquiOrigSize != filteredRequestTransEquipment.size();
    }
    return false;
  }

  private boolean checkIfSealsAreMatching(
      TransportEquipment requestTranEqui, TransportEquipment currentTranEqui) {

    if (CollectionUtils.isEmpty(requestTranEqui.getSeal())
        && CollectionUtils.isEmpty(currentTranEqui.getSeal())) {
      return true;
    }

    if (!CollectionUtils.isEmpty(requestTranEqui.getSeal())
        && !CollectionUtils.isEmpty(currentTranEqui.getSeal())
        && requestTranEqui.getSeal().size() == currentTranEqui.getSeal().size()) {
      int requestSealOrigSize = requestTranEqui.getSeal().size();
      List<Seal> filteredSeal =
          requestTranEqui.getSeal().stream()
              .filter(
                  requestSeal ->
                      currentTranEqui.getSeal().stream()
                          .anyMatch(
                              currentSeal ->
                                  requestSeal.getIdentifier().equals(currentSeal.getIdentifier())))
              .collect(Collectors.toList());
      if (requestSealOrigSize == filteredSeal.size()) {
        return true;
      }
    }
    return false;
  }

  private boolean checkManualApprovalForReceptacle(
      List<Receptacle> requestReceptacle, List<Receptacle> currentReceptacle) {
    if (twoCollectionsAreUnEqual(requestReceptacle, currentReceptacle)) {
      return true;
    }

    if (!CollectionUtils.isEmpty(requestReceptacle)
        && !CollectionUtils.isEmpty(currentReceptacle)) {
      int requestReceptacleOrigSize = requestReceptacle.size();

      List<Receptacle> filteredReceptacle =
          requestReceptacle.stream()
              .filter(
                  requestRecep ->
                      currentReceptacle.stream()
                          .anyMatch(
                              currentRecep ->
                                  (requestRecep
                                      .getIdentificationNumber()
                                      .equals(currentRecep.getIdentificationNumber()))))
              .collect(Collectors.toList());
      return requestReceptacleOrigSize != filteredReceptacle.size();
    }
    return false;
  }

  protected boolean checkManualApprRequiredForConsignmentItems(
      List<ConsignmentItem> requestConsignmentItems,
      List<ConsignmentItem> currentConsignmentItems) {

    if (twoCollectionsAreUnEqual(requestConsignmentItems, currentConsignmentItems)) {
      return true;
    }

    if (!CollectionUtils.isEmpty(requestConsignmentItems)
        && !CollectionUtils.isEmpty(currentConsignmentItems)) {
      Map<Integer, ConsignmentItem> currentConsignmentItemMap =
          currentConsignmentItems.stream()
              .filter(t -> t.getGoodsItemNumber() != null)
              .collect(Collectors.toMap(ConsignmentItem::getGoodsItemNumber, Function.identity()));
      for (ConsignmentItem requestConsignmentItem : requestConsignmentItems) {
        ConsignmentItem currentConsignmentItem =
            currentConsignmentItemMap.get(requestConsignmentItem.getGoodsItemNumber());
        if (currentConsignmentItem == null
            || checkManualApprovalForCIPackaging(
                requestConsignmentItem.getPackaging(), currentConsignmentItem.getPackaging())
            || checkManualApprovalForCICommodity(
                requestConsignmentItem.getCommodity(), currentConsignmentItem.getCommodity())
            || twoBigDecimalsAreUnequal(
                requestConsignmentItem.getGrossMass(), currentConsignmentItem.getGrossMass())
            || checkManualApprovalForTransportEquip(
                requestConsignmentItem.getTransportEquipment(),
                currentConsignmentItem.getTransportEquipment())) {
          return true;
        }
      }
    }
    return false;
  }

  protected boolean checkManualApprovalForCIPackaging(
      List<Packaging> requestPackaging, List<Packaging> currentPackaging) {
    if (twoCollectionsAreUnEqual(requestPackaging, currentPackaging)) {
      return true;
    }

    if (!CollectionUtils.isEmpty(requestPackaging) && !CollectionUtils.isEmpty(currentPackaging)) {
      int requestPackagingOrigSize = requestPackaging.size();

      List<Packaging> filteredPackaging =
          requestPackaging.stream()
              .filter(
                  requestPack ->
                      currentPackaging.stream()
                          .anyMatch(
                              currentPack ->
                                  twoStringsAreEqual(
                                          requestPack.getTypeOfPackages(),
                                          currentPack.getTypeOfPackages())
                                      && twoIntegersAreEqual(
                                          requestPack.getNumberOfPackages(),
                                          currentPack.getNumberOfPackages())
                                      && twoStringsAreEqual(
                                          requestPack.getShippingMarks(),
                                          currentPack.getShippingMarks())))
              .collect(Collectors.toList());
      return requestPackagingOrigSize != filteredPackaging.size();
    }
    return false;
  }

  protected boolean checkManualApprovalForCICommodity(
      Commodity requestCommodity, Commodity currentCommodity) {
    return !Objects.equals(requestCommodity, currentCommodity);
  }

  protected boolean checkManualApprRequiredForHouseConsignmentAndItems(
      TemporaryStorageDeclaration requestTSD, TemporaryStorageDeclaration currentTSD) {
    if (currentTSD.getCurrentStatus() == ACCEPTED) {

      List<HouseConsignment> requestHouseConsignments = requestTSD.getHouseConsignments();
      List<HouseConsignment> currentHouseConsignments = currentTSD.getHouseConsignments();

      if (twoCollectionsAreUnEqual(requestHouseConsignments, currentHouseConsignments)) {
        return true;
      }

      if (!CollectionUtils.isEmpty(requestHouseConsignments)
          && !CollectionUtils.isEmpty(currentHouseConsignments)) {
        Map<String, HouseConsignment> currentHouseConsignmentMap =
            currentHouseConsignments.stream()
                .filter(t -> t.getTransportDocument() != null)
                .collect(
                    Collectors.toMap(
                        x ->
                            x.getTransportDocument().getReferenceNumber().toLowerCase()
                                + x.getTransportDocument().getType().toLowerCase(),
                        Function.identity()));
        for (HouseConsignment requestHouseConsignment : requestHouseConsignments) {
          HouseConsignment currentHouseConsignment =
              currentHouseConsignmentMap.get(
                  requestHouseConsignment.getTransportDocument().getReferenceNumber().toLowerCase()
                      + requestHouseConsignment.getTransportDocument().getType().toLowerCase());
          if (currentHouseConsignment == null
              || twoStringsAreUnequal(
                  requestHouseConsignment.getReferenceNumberUCR(),
                  currentHouseConsignment.getReferenceNumberUCR())
              || twoBigDecimalsAreUnequal(
                  requestHouseConsignment.getTotalGrossMass(),
                  currentHouseConsignment.getTotalGrossMass())
              || checkManualApprovalForTransportEquip(
                  requestHouseConsignment.getTransportEquipment(),
                  currentHouseConsignment.getTransportEquipment())
              || checkManualApprRequiredForConsignmentItems(
                  requestHouseConsignment.getConsignmentItem(),
                  currentHouseConsignment.getConsignmentItem())) {
            return true;
          }
        }
      }
    }
    return false;
  }

  protected boolean checkManualApprRequiredForDeclaredLocationOfGoods(
      TemporaryStorageDeclaration requestTSD, TemporaryStorageDeclaration currentTSD) {
    if (currentTSD.getCurrentStatus() == ACCEPTED) {
      ConsignmentHeader requestConsignmentHeader = requestTSD.getConsignmentHeader();
      ConsignmentHeader currentConsignmentHeader = currentTSD.getConsignmentHeader();

      if (((requestConsignmentHeader == null
                  || requestConsignmentHeader.getDecalaredlocationOfGoods() == null)
              && (currentConsignmentHeader != null
                  && currentConsignmentHeader.getDecalaredlocationOfGoods() != null))
          || ((requestConsignmentHeader != null
                  && requestConsignmentHeader.getDecalaredlocationOfGoods() != null)
              && (currentConsignmentHeader == null
                  || currentConsignmentHeader.getDecalaredlocationOfGoods() == null))) {

        return true;
      }

      if (requestConsignmentHeader != null
          && requestConsignmentHeader.getDecalaredlocationOfGoods() != null
          && currentConsignmentHeader != null
          && currentConsignmentHeader.getDecalaredlocationOfGoods() != null) {
        return compareDeclaredLocationOfGoods(
            requestConsignmentHeader.getDecalaredlocationOfGoods(),
            currentConsignmentHeader.getDecalaredlocationOfGoods());
      }
    }
    return false;
  }

  private boolean compareDeclaredLocationOfGoods(
      LocationOfGoods requestlocationOfGoods, LocationOfGoods currentlocationOfGoods) {
    return twoStringsAreUnequal(
            requestlocationOfGoods.getTypeOfLocation(), currentlocationOfGoods.getTypeOfLocation())
        || twoStringsAreUnequal(
            requestlocationOfGoods.getQualifierOfIdentification(),
            currentlocationOfGoods.getQualifierOfIdentification())
        || twoStringsAreUnequal(
            requestlocationOfGoods.getUnLoCode(), currentlocationOfGoods.getUnLoCode())
        || twoStringsAreUnequal(
            requestlocationOfGoods.getAuthorisationNumber(),
            currentlocationOfGoods.getAuthorisationNumber())
        || twoStringsAreUnequal(
            requestlocationOfGoods.getAdditionalIdentifier(),
            currentlocationOfGoods.getAdditionalIdentifier())
        || !Objects.equals(
            requestlocationOfGoods.getCustomsOffice(), currentlocationOfGoods.getCustomsOffice())
        || !Objects.equals(requestlocationOfGoods.getGnss(), currentlocationOfGoods.getGnss())
        || !Objects.equals(
            requestlocationOfGoods.getEconomicOperator(),
            currentlocationOfGoods.getEconomicOperator())
        || !Objects.equals(
            requestlocationOfGoods.getAddress(), currentlocationOfGoods.getAddress());
  }

  protected boolean checkManualApprRequiredForWarehouse(
      TemporaryStorageDeclaration requestTSD, TemporaryStorageDeclaration currentTSD) {
    if (currentTSD.getCurrentStatus() == ACCEPTED) {
      ConsignmentHeader requestConsignmentHeader = requestTSD.getConsignmentHeader();
      ConsignmentHeader currentConsignmentHeader = currentTSD.getConsignmentHeader();

      if (((requestConsignmentHeader == null || requestConsignmentHeader.getWarehouse() == null)
              && (currentConsignmentHeader != null
                  && currentConsignmentHeader.getWarehouse() != null))
          || ((requestConsignmentHeader != null && requestConsignmentHeader.getWarehouse() != null)
              && (currentConsignmentHeader == null
                  || currentConsignmentHeader.getWarehouse() == null))) {

        return true;
      }

      if (requestConsignmentHeader != null
          && requestConsignmentHeader.getWarehouse() != null
          && currentConsignmentHeader != null
          && currentConsignmentHeader.getWarehouse() != null) {
        return !Objects.equals(
            requestConsignmentHeader.getWarehouse(), currentConsignmentHeader.getWarehouse());
      }
    }
    return false;
  }

  private boolean twoCollectionsAreUnEqual(Collection<?> first, Collection<?> second) {
    return (CollectionUtils.isEmpty(first) && !CollectionUtils.isEmpty(second))
        || (!CollectionUtils.isEmpty(first) && CollectionUtils.isEmpty(second))
        || (!CollectionUtils.isEmpty(first)
            && !CollectionUtils.isEmpty(second)
            && first.size() != second.size());
  }

  private boolean twoStringsAreEqual(String first, String second) {
    return (first == null ? second == null : first.equals(second));
  }

  private boolean twoStringsAreUnequal(String first, String second) {
    return (first == null ? second != null : !first.equals(second));
  }

  private boolean twoIntegersAreEqual(Integer first, Integer second) {
    return (first == null ? second == null : first.equals(second));
  }

  private boolean twoBigDecimalsAreUnequal(BigDecimal first, BigDecimal second) {
    return (first == null && second != null)
        || (first != null && second == null)
        || (first != null && second != null && first.compareTo(second) != 0);
  }

  private boolean twoTimestampsAreUnequal(LocalDateTime first, LocalDateTime second) {
    return (first == null && second != null)
        || (first != null && second == null)
        || (first != null && second != null && !first.isEqual(second));
  }

  protected void validateTSPNESXXR0155(
      TemporaryStorageDeclaration currentTSD,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    if (currentTSD != null
        && currentTSD.getDeconsolidationNotification() != null
        && currentTSD.getDeconsolidationNotification().getStatus()
            == DeconsolidationNotificationStatus.APPROVED) {
      CustomViolation<TemporaryStorageDeclaration> violation =
          new CustomViolation<>(ErrorCode.TSPNESXXR0155, MRN);
      violations.add(violation);
    }
  }

  protected void validateTSPNESXXR0156(
      TemporaryStorageDeclaration currentTSD,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    if (currentTSD != null
        && currentTSD.getTransferNotification() != null
        && currentTSD.getTransferNotification().getStatus()
            == TransferNotificationStatus.APPROVED) {
      CustomViolation<TemporaryStorageDeclaration> violation =
          new CustomViolation<>(ErrorCode.TSPNESXXR0156, MRN);
      violations.add(violation);
    }
  }
}
