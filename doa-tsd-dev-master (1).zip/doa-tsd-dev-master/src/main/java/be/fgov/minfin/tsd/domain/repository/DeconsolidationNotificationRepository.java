/*
 * @(#) be.fgov.minfin.tsd.domain.repository.DeconsolidationNotificationRepository.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.repository;

import be.fgov.minfin.tsd.domain.model.DeconsolidationNotification;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface DeconsolidationNotificationRepository
    extends JpaRepository<DeconsolidationNotification, Long> {

  @Query(
      value =
          "select decon from DeconsolidationNotification decon join TemporaryStorageDeclaration tsd on "
              + "decon.id = tsd.deconsolidationNotification.id where tsd.id = :tsdId")
  Optional<DeconsolidationNotification> fetchDeconsolidationNotification(Long tsdId);
}
