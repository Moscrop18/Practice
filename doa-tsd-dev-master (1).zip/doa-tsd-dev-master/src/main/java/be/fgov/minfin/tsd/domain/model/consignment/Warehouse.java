/*
 * @(#) be.fgov.minfin.tsd.domain.model.consignment.Warehouse.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model.consignment;

import be.fgov.minfin.tsd.domain.validation.annotation.CodeList;
import be.fgov.minfin.tsd.domain.validation.annotation.group.NonDraftTSD;
import be.fgov.minfin.tsd.domain.validation.annotation.group.TransferNotificationValidatorGroup;
import be.fgov.minfin.tsd.domain.validation.codelist.TSDCodeLists;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.groups.Default;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode // do not exclude any field
@Embeddable
public class Warehouse {
  @Column(name = "WAREHOUSE_IDENTIFIER")
  @NotNull(groups = NonDraftTSD.class)
  private String identifier;

  @Column(name = "WAREHOUSE_TYPE")
  @CodeList(
      value = TSDCodeLists.CL099,
      groups = {Default.class, TransferNotificationValidatorGroup.class})
  @NotNull(groups = NonDraftTSD.class)
  private String type;
}
