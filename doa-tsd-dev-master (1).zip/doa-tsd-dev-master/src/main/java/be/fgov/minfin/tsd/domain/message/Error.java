/*
 * @(#)be.fgov.minfin.tsd.domain.message.ErrorRejectMessage.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.message;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Value;

@Value
@Builder(toBuilder = true)
@EqualsAndHashCode(exclude = "sequenceNumber")
public class Error {
  private Integer sequenceNumber;

  private String errorPointer;

  private Integer errorCode;

  private String errorReason;

  private String remarks;
}
