/*
 * @(#)bbe.fgov.minfin.tsd.domain.model.consignment.ConsignmentItemDraftError.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model.consignment;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * Enum for Draft error consignment item
 *
 * @author MohdSalim
 */
public enum ConsignmentItemDraftError {
  ERROR("01"),
  EMPTY("02");

  private final Integer value;
  private final String code;

  private ConsignmentItemDraftError(String code) {
    this.value = Integer.parseInt(code);
    this.code = code;
  }

  @JsonValue
  public String getCode() {
    return code;
  }

  public Integer getValue() {
    return value;
  }
}
