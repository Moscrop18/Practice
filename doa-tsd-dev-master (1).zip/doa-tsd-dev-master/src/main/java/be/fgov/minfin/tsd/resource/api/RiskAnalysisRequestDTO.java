package be.fgov.minfin.tsd.resource.api;

import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.Builder;
import lombok.Value;

@Value
@Builder(toBuilder = true)
@JsonRootName("riskAnalysis")
public class RiskAnalysisRequestDTO extends BaseRiskAnalysisRequestDTO {

  @NotNull
  @Size(min = 1, max = 1)
  private String category;

  @NotNull
  @JacksonXmlElementWrapper(useWrapping = false)
  @Size(max = 99999)
  private List<@Valid RiskAnalysisResultDTO> riskAnalysisResult;
}
