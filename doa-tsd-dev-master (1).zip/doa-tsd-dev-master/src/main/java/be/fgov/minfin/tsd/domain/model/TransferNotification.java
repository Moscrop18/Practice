/*
 * @(#) be.fgov.minfin.tsd.domain.model.TransferNotification.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties
 * or made public without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model;

import be.fgov.minfin.libdoa.commons.lang.Now;
import be.fgov.minfin.libdoa.entities.VersionedAuditableEntity;
import be.fgov.minfin.tsd.domain.converter.TransferNotificationStatusConverter;
import be.fgov.minfin.tsd.domain.message.Error;
import be.fgov.minfin.tsd.domain.model.party.Party;
import be.fgov.minfin.tsd.domain.model.party.Representative;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import be.fgov.minfin.tsd.domain.validation.annotation.group.TransferNotificationValidatorGroup;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.apache.commons.collections4.CollectionUtils;
import org.hibernate.annotations.LazyToOne;
import org.hibernate.annotations.LazyToOneOption;

@Getter
@Setter
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(
    exclude = {
      "declarant",
      "representative",
      "consignmentLocationOfGoods",
      "masterConsignment",
      "houseConsignments",
      "validationErrors",
      "declaration"
    })
@ValidateBusinessRules(groups = TransferNotificationValidatorGroup.class)
@Entity
@Table(name = "TRANSFER_NOTIFICATION")
public class TransferNotification extends VersionedAuditableEntity<Long> {

  @Id
  @GeneratedValue(generator = "TRANSFER_NOTIFICATION_SEQ")
  @SequenceGenerator(name = "TRANSFER_NOTIFICATION_SEQ", sequenceName = "TRANSFER_NOTIFICATION_SEQ")
  private Long id;

  @Valid
  @ToString.Exclude
  @OneToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "MESSAGE_INFORMATION_ID")
  private MessageInformation messageInformation;

  @Column(name = "REGISTRATION_DATE")
  private LocalDateTime registrationDate;

  private String lrn;

  @Convert(converter = TransferNotificationStatusConverter.class)
  private TransferNotificationStatus status;

  @Embedded private PersonNotifyingTheArrivalAfterMovement personNotifyingTheArrivalAfterMovement;

  @Valid
  @OneToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "DECLARANT_ID")
  @ToString.Exclude
  private Party declarant;

  @Valid
  @OneToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "REPRESENTATIVE_ID")
  @ToString.Exclude
  private Representative representative;

  @Valid
  @ToString.Exclude
  @OneToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "CON_LOCATION_OF_GOODS_ID")
  @JsonManagedReference(value = "transferNotification")
  private ConsignmentLocationOfGoods consignmentLocationOfGoods;

  @OneToOne(cascade = CascadeType.ALL, mappedBy = "transferNotification", fetch = FetchType.LAZY)
  @LazyToOne(value = LazyToOneOption.PROXY)
  @ToString.Exclude
  @Valid
  @JsonIgnoreProperties("transferNotification")
  private TransferNotificationMasterConsignment masterConsignment;

  @OneToMany(
      mappedBy = "transferNotification",
      cascade = {CascadeType.PERSIST, CascadeType.MERGE},
      orphanRemoval = true)
  @ToString.Exclude
  @JsonIgnoreProperties("transferNotification")
  private List<@Valid TransferNotificationHouseConsignment> houseConsignments;

  @OneToMany(
      mappedBy = "transferNotification",
      cascade = {CascadeType.PERSIST, CascadeType.MERGE},
      orphanRemoval = true)
  @ToString.Exclude
  @JsonManagedReference(value = "transferNotification")
  private List<ValidationError> validationErrors;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "TRANSFERRED_TSD_ID")
  private TemporaryStorageDeclaration declaration;

  public void completeTransferNotification(
      TemporaryStorageDeclaration currentTSD, List<Error> errors) {

    if (CollectionUtils.isEmpty(errors)) {
      this.status = TransferNotificationStatus.APPROVED;
    } else {
      this.status = TransferNotificationStatus.REFUSED;
      this.validationErrors = ValidationError.buildValidationErrors(errors);
      this.removeClonedTSDConsignments();
    }

    this.registrationDate = Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime();
    this.declaration = currentTSD;
  }

  public void setClonedTSDConsignments(TemporaryStorageDeclaration clonedTSD) {
    if (null != this.masterConsignment) {
      this.masterConsignment.setConsignment(clonedTSD.getMasterConsignment());
    }

    if (!CollectionUtils.isEmpty(this.houseConsignments)) {
      for (TransferNotificationHouseConsignment transferNotificationHouseConsignment :
          this.houseConsignments) {
        transferNotificationHouseConsignment.setConsignment(
            clonedTSD.getMatchingHouseConsignment(
                transferNotificationHouseConsignment.getTransportDocument()));
      }
    }
  }

  private void removeClonedTSDConsignments() {
    if (null != this.masterConsignment) {
      this.masterConsignment.setConsignment(null);
    }

    if (CollectionUtils.isNotEmpty(this.houseConsignments)) {
      for (TransferNotificationHouseConsignment transferNotificationHouseConsignment :
          this.houseConsignments) {
        transferNotificationHouseConsignment.setConsignment(null);
      }
    }
  }
}
