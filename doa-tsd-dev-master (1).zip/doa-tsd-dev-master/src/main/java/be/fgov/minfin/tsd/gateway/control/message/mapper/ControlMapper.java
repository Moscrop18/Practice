/*
 * @(#) be.fgov.minfin.tsd.gateway.control.message.mapper.ControlMapper.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.control.message.mapper;

import static be.fgov.minfin.tsd.util.DateFormatUtil.MESSAGE_DATE_TIME_FORMAT;
import static be.fgov.minfin.tsd.util.DateFormatUtil.MESSAGE_TIMESTAMP_FORMAT;

import be.fgov.minfin.control.client.api.AdditionalSupplyChainActorDTO;
import be.fgov.minfin.control.client.api.ConsignmentHeaderMasterLevelDTO;
import be.fgov.minfin.control.client.api.ConsignmentHouseLevelDTO;
import be.fgov.minfin.control.client.api.ConsignmentItemDTO;
import be.fgov.minfin.control.client.api.ConsignmentLocationOfGoodsDTO;
import be.fgov.minfin.control.client.api.ConsignmentMasterLevelDTO;
import be.fgov.minfin.control.client.api.ControlRecommendationsDTO;
import be.fgov.minfin.control.client.api.ControlSubjectDTO;
import be.fgov.minfin.control.client.api.DeconsolidationNotificationHeaderDTO;
import be.fgov.minfin.control.client.api.RelatedTSDDTO;
import be.fgov.minfin.control.client.api.RiskAnalysisDTO;
import be.fgov.minfin.control.client.api.RiskAnalysisResultDTO;
import be.fgov.minfin.control.client.api.SendControlRecommendationDTO;
import be.fgov.minfin.tsd.domain.model.ConsignmentLocationOfGoods;
import be.fgov.minfin.tsd.domain.model.DeconsolidationNotification;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.consignment.AdditionalSupplyChainActor;
import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentHeader;
import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentItem;
import be.fgov.minfin.tsd.domain.model.consignment.HouseConsignment;
import be.fgov.minfin.tsd.domain.model.consignment.MasterConsignment;
import be.fgov.minfin.tsd.domain.model.risk.ControlRecommendation;
import be.fgov.minfin.tsd.domain.model.risk.RiskAnalysisResult;
import be.fgov.minfin.tsd.gateway.control.message.SendControlRecommendation;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import org.mapstruct.InjectionStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

/**
 * This class is to map DTO
 *
 * @author MohdSalim
 */
@Mapper(injectionStrategy = InjectionStrategy.CONSTRUCTOR)
public interface ControlMapper {

  @Mapping(
      target = "documentIssueDate",
      source = "messageHeader.messageTimestamp",
      qualifiedByName = "documentIssueDate")
  @Mapping(target = "messageHeader.languageCode", ignore = true)
  @Mapping(target = "messageHeader.refToMessageId", ignore = true)
  @Mapping(target = "messageHeader.messageTimestamp", dateFormat = MESSAGE_DATE_TIME_FORMAT)
  @Mapping(target = "functionalReference", source = "declaration.referenceNumber.crn.crnNumber")
  @Mapping(
      target = "riskAnalysis",
      expression =
          "java(map(sendControlRecommendation.getReceiveRiskAnalysisResult().getRiskAnalysisRequestReference(), sendControlRecommendation.getReceiveRiskAnalysisResult().getRiskAnalysisRequestCategory(), sendControlRecommendation.getReceiveRiskAnalysisResult().getRiskAnalysisResult()))")
  @Mapping(
      target = "controlRecommendations",
      source = "receiveRiskAnalysisResult.controlRecommendations")
  @Mapping(
      target = "scheduledControlDate",
      source = "receiveRiskAnalysisResult.controlNotification.scheduledControlDate")
  @Mapping(target = "typeOfControls", source = "receiveRiskAnalysisResult.typeOfControls")
  @Mapping(
      target = "customsOfficeOfControl",
      source = "receiveRiskAnalysisResult.customsOfficeOfControl")
  @Mapping(target = "requestedDocument", source = "receiveRiskAnalysisResult.requestedDocument")
  @Mapping(
      target = "relatedTSD",
      expression =
          "java(map(sendControlRecommendation.getDeclaration(), sendControlRecommendation.getDeconsolidationNotificationHeader()))")
  SendControlRecommendationDTO controlReccMap(SendControlRecommendation sendControlRecommendation);

  @Mapping(target = "riskAnalysisRequestReference", source = "reference")
  @Mapping(target = "category", source = "category")
  @Mapping(target = "riskAnalysisResult", source = "rar")
  RiskAnalysisDTO map(String reference, String category, List<RiskAnalysisResult> rar);

  @Mapping(target = "controlRecommendationReference", source = "functionalReference")
  ControlRecommendationsDTO map(ControlRecommendation cr);

  @Mapping(target = "riskAnalysisType", source = "rar.type")
  @Mapping(target = "resultText", source = "rar.resultDescription")
  RiskAnalysisResultDTO map(RiskAnalysisResult rar);

  default ControlSubjectDTO map(String controlSubject) throws JsonProcessingException {
    ObjectMapper mapper = new ObjectMapper();
    return mapper.readValue(controlSubject, ControlSubjectDTO.class);
  }

  @Mapping(target = "weight.grossMass", source = "grossMass")
  ConsignmentItemDTO map(ConsignmentItem item);

  @Mapping(target = "crn", source = "declaration.referenceNumber.crn.crnNumber")
  @Mapping(target = "mrn", source = "declaration.referenceNumber.mrn.mrnNumber")
  @Mapping(target = "dateAndTimeOfPresentationOfTheGoods", dateFormat = MESSAGE_DATE_TIME_FORMAT)
  @Mapping(target = "declarationDate", dateFormat = MESSAGE_DATE_TIME_FORMAT)
  @Mapping(
      target = "consignmentHeaderMasterLevel",
      expression =
          "java(map(declaration.getMasterConsignment(), declaration.getHouseConsignments(), declaration.getConsignmentHeader()))")
  @Mapping(target = "declarant", source = "declaration.declarant")
  @Mapping(target = "representative", source = "declaration.representative")
  @Mapping(
      target = "deconsolidationNotificationHeader",
      source = "deconsolidationNotificationHeader")
  RelatedTSDDTO map(
      TemporaryStorageDeclaration declaration,
      DeconsolidationNotification deconsolidationNotificationHeader);

  @Mapping(source = "masterConsignment", target = "consignmentMasterLevel")
  @Mapping(source = "houseConsignments", target = "consignmentHouseLevel")
  @Mapping(
      source = "consignmentHeader.decalaredlocationOfGoods",
      target = "locationOfGoodsDeclared")
  @Mapping(
      source = "consignmentHeader.presentedlocationOfGoods",
      target = "locationOfGoodsPresented")
  @Mapping(source = "consignmentHeader.arrivalTransportMeans", target = "arrivalTransportMeans")
  @Mapping(source = "consignmentHeader.warehouse", target = "warehouse")
  @Mapping(source = "consignmentHeader.placeOfUnloading", target = "placeOfUnloading")
  @Mapping(source = "consignmentHeader.carrier", target = "carrier")
  ConsignmentHeaderMasterLevelDTO map(
      MasterConsignment masterConsignment,
      List<HouseConsignment> houseConsignments,
      ConsignmentHeader consignmentHeader);

  @Mapping(target = "aeoAuthorisation", source = "aeoAuthorisations")
  AdditionalSupplyChainActorDTO map(AdditionalSupplyChainActor actor);

  @Mapping(target = "referenceNumberUCR.referenceNumberUCR", source = "referenceNumberUCR")
  @Mapping(target = "consignmentItemMasterLevel", source = "consignmentItem")
  @Mapping(target = "locationOfGoodsCurrent", source = "currentConsignmentLocationOfGoods")
  ConsignmentMasterLevelDTO map(MasterConsignment masterConsignment);

  @Mapping(target = "referenceNumberUCR.referenceNumberUCR", source = "referenceNumberUCR")
  @Mapping(target = "consignmentItemHouseLevel", source = "consignmentItem")
  @Mapping(target = "locationOfGoodsCurrent", source = "currentConsignmentLocationOfGoods")
  ConsignmentHouseLevelDTO map(HouseConsignment houseConsignment);

  @Mapping(target = "registrationDate", dateFormat = MESSAGE_DATE_TIME_FORMAT)
  DeconsolidationNotificationHeaderDTO map(DeconsolidationNotification deconsolidationNotification);

  @Mapping(target = "locationOfGoods", source = "transferredLocationOfGoods")
  ConsignmentLocationOfGoodsDTO map(ConsignmentLocationOfGoods consignmentLocationOfGoods);

  @Named("documentIssueDate")
  default String maptoDate(String date) {
    if (date == null) {
      return null;
    }
    DateTimeFormatter oldPattern = DateTimeFormatter.ofPattern(MESSAGE_TIMESTAMP_FORMAT);
    DateTimeFormatter newPattern = DateTimeFormatter.ofPattern(MESSAGE_DATE_TIME_FORMAT);
    LocalDateTime datetime = LocalDateTime.parse(date, oldPattern);
    return datetime.format(newPattern);
  }
}
