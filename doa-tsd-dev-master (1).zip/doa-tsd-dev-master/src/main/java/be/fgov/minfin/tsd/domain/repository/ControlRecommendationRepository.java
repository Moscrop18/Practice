package be.fgov.minfin.tsd.domain.repository;

import be.fgov.minfin.tsd.domain.model.risk.ControlRecommendation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ControlRecommendationRepository
    extends JpaRepository<ControlRecommendation, Long> {

  public ControlRecommendation findByFunctionalReference(String functionalReference);
}
