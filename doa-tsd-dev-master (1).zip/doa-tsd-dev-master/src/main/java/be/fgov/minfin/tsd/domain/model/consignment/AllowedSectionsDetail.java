package be.fgov.minfin.tsd.domain.model.consignment;

public interface AllowedSectionsDetail {

  Boolean getItemPresent();

  Boolean getPreviousDocument();

  Boolean getTransportEquipment();

  Boolean getAdditionalSupplyChainActor();

  Boolean getAdditionalInformation();

  Boolean getSupportingDocument();

  Boolean getAdditionalReference();

  Boolean getReceptacle();
}
