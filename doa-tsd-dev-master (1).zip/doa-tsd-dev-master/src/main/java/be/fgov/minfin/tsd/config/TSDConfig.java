/*
 * @(#)be.fgov.minfin.tsd.config.TSDConfig.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.config;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.NestedConfigurationProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.validation.annotation.Validated;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;

@Validated
@Getter
@Setter
@ConfigurationProperties(prefix = "tsd")
@RequiredArgsConstructor
public class TSDConfig {

  private boolean showStracktraces = false;

  private boolean swaggerUi = false;
  private String countryCode;
  private String declarationTypeIndentifierPreLodged = "TP";
  private String declarationTypeIndentifierCombined = "PT";
  private String procedureIdentifier = "U";
  private String tsdSystemName = "TSD";
  private Integer expirationTimestampPeriod = 30;
  private Integer draftTSDRemovalPeriod = 30;
  private Integer awaitingRiskResultHours = 4;
  private String pnSystemName = "PN";
  private String gaSystemName = "GA";
  private String nationalEnsSystemName = "ENS";
  private String raiSystemName = "RAI";
  private String gaCallbackUrl;

  private String declartionTypeIndentifierCrn = "TS";
  private String accessControlAllowOrigin;
  private String accessControlExposeHeaders;
  @NestedConfigurationProperty private final TimerConfig timer;

  @Bean
  public LocalValidatorFactoryBean getValidator() {

    return new LocalValidatorFactoryBean();
  }
}
