/*
 * @(#)be.fgov.minfin.tsd.domain.converter.CRNConverter.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.converter;

import be.fgov.minfin.tsd.domain.generator.CRNGenerator;
import be.fgov.minfin.tsd.domain.model.CRN;
import java.util.Optional;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * Class to convert CRN number to String to persist in DB
 *
 * @author GauravMitra
 */
@Converter(autoApply = true)
@RequiredArgsConstructor
@Component
public class CRNConverter implements AttributeConverter<CRN, String> {
  private final CRNGenerator crnGenerator;

  @Override
  public String convertToDatabaseColumn(CRN crn) {

    if (Optional.ofNullable(crn).isEmpty()) {
      return null;
    } else if (Optional.ofNullable(crn).isPresent() && StringUtils.isNotBlank(crn.getCrnNumber())) {
      return crn.getCrnNumber();
    } else if (Optional.ofNullable(crn.getReferenceNumberMetadata()).isEmpty()) {
      throw new IllegalArgumentException(
          "refmetadata cannot be null while generating  Reference Number");
    } else {
      ReferenceNumberMetadataDTO metdataDTO =
          crn.getReferenceNumberMetadata().setReferenceNumberMetadata();
      String crnNumber = crnGenerator.generateCRN(metdataDTO);
      crn.setCrnNumber(crnNumber);
      return crnNumber;
    }
  }

  @Override
  public CRN convertToEntityAttribute(String dbData) {
    if (dbData == null) {
      return null;
    }
    CRN crn = new CRN();
    crn.setCrnNumber(dbData);
    return crn;
  }
}
