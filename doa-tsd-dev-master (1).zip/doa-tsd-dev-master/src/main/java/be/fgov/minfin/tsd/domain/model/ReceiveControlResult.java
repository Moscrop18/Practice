/*
 * @(#)be.fgov.minfin.tsd.domain.model.ReceiveControlResult.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model;

import be.fgov.minfin.tsd.domain.message.MessageHeader;
import be.fgov.minfin.tsd.domain.model.risk.ControlRecommendation;
import be.fgov.minfin.tsd.domain.model.risk.ControlResultDecision;
import be.fgov.minfin.tsd.domain.model.risk.CustomsOfficeOfControl;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import be.fgov.minfin.tsd.domain.validation.annotation.group.ReceiveControlResultValidator;
import java.util.List;
import javax.validation.Valid;
import lombok.Builder;
import lombok.Value;

@Value
@Builder(toBuilder = true)
@ValidateBusinessRules(groups = ReceiveControlResultValidator.class)
public class ReceiveControlResult {

  private MessageHeader messageHeader;

  private String functionalReference;

  private String documentIssueDate;

  private String mrn;

  private String controlResultDate;

  private @Valid ControlResultDecision controlDecision;

  private @Valid CustomsOfficeOfControl customsOfficeOfControl;

  private List<@Valid ControlRecommendation> controlRecommendations;
}
