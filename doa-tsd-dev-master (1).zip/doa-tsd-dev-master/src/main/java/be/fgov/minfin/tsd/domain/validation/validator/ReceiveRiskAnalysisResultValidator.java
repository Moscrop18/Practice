/*
 * @(#) be.fgov.minfin.tsd.domain.validation.validator.ReceiveRiskAnalysisResultValidator.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation.validator;

import be.fgov.minfin.tsd.domain.model.ReceiveRiskAnalysisResult;
import be.fgov.minfin.tsd.domain.model.consignment.Consignment;
import be.fgov.minfin.tsd.domain.model.consignment.MasterConsignment;
import be.fgov.minfin.tsd.domain.model.risk.ControlRecommendation;
import be.fgov.minfin.tsd.domain.model.risk.RiskAnalysisResult;
import be.fgov.minfin.tsd.domain.model.risk.TypeOfControls;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

public class ReceiveRiskAnalysisResultValidator extends BaseConstraintValidator
    implements ConstraintValidator<ValidateBusinessRules, ReceiveRiskAnalysisResult> {

  private static final String RISK_ANALYST = "RiskAnalyst";
  private static final String TYPE_OF_CONTROL_TEXT = "Text";
  private static final String TYPE_OF_CONTROL = "TypeOfControls";
  private static final String CONTROL_NOTIFICATION = "ControlNotification";
  private static final String CUSTOMS_OFFICE_OF_CONTROL = "CustomsOfficeOfControl";
  private static final String REQUESTED_DOCUMENT = "requestedDocument";

  @Override
  public boolean isValid(
      ReceiveRiskAnalysisResult receiveRiskAnalysisResult, ConstraintValidatorContext context) {
    AtomicBoolean isValid = new AtomicBoolean(true);
    validateRiskAnalysisType(receiveRiskAnalysisResult, isValid, context);
    validateTypeOfControlText(receiveRiskAnalysisResult, isValid, context);
    validateControlRecommendation(receiveRiskAnalysisResult, isValid, context);
    if (CollectionUtils.isEmpty(receiveRiskAnalysisResult.getControlRecommendations())) {
      return isValid.get();
    }

    ControlRecommendation firstControlRecom =
        receiveRiskAnalysisResult.getControlRecommendations().get(0);

    MasterConsignment masterConsignment =
        findMasterConsignment(firstControlRecom.getConsignments());

    boolean hasOnlyMaster = false;
    boolean hasOnlyHouse = false;
    // it means that first cr has only master consignment(valid)
    if ((masterConsignment != null
            && (masterConsignment.getTransportDocument() != null
                || CollectionUtils.isNotEmpty(masterConsignment.getTransportEquipment())
                || CollectionUtils.isNotEmpty(masterConsignment.getReceptacle())
                || CollectionUtils.isNotEmpty(masterConsignment.getConsignmentItem())))
        && firstControlRecom.getConsignments().size() == 1) {
      hasOnlyMaster = true;
    }

    // it means that first cr has empty master and only house consignment(valid)
    if (masterConsignment != null
        && masterConsignment.getTransportDocument() == null
        && CollectionUtils.isEmpty(masterConsignment.getTransportEquipment())
        && CollectionUtils.isEmpty(masterConsignment.getReceptacle())
        && CollectionUtils.isEmpty(masterConsignment.getConsignmentItem())
        && firstControlRecom.getConsignments().size() > 1) {
      hasOnlyHouse = true;
    }

    checkFormatOfRemainingControlRecommendations(
        receiveRiskAnalysisResult, context, isValid, hasOnlyMaster, hasOnlyHouse);
    return isValid.get();
  }

  private void validateControlRecommendation(
      ReceiveRiskAnalysisResult analysisResult,
      AtomicBoolean hasError,
      ConstraintValidatorContext context) {
    if (analysisResult.hasControlRecommendations()) {
      if (analysisResult.getCustomsOfficeOfControl() == null) {
        addViolation(context, ErrorCode.TSPNESXXC0450, CUSTOMS_OFFICE_OF_CONTROL);
        hasError.set(false);
      }
      if (analysisResult.getControlNotification() == null) {
        addViolation(context, ErrorCode.TSPNESXXC0407, CONTROL_NOTIFICATION);
        hasError.set(false);
      }

    } else {
      if (analysisResult.getRequestedDocument() != null) {
        addViolation(context, ErrorCode.TSPNESXXC0452, REQUESTED_DOCUMENT);
        hasError.set(false);
      }
      if (analysisResult.getTypeOfControls() != null) {
        addViolation(context, ErrorCode.TSPNESXXR0408, TYPE_OF_CONTROL);
        hasError.set(false);
      }
    }
  }

  private void validateTypeOfControlText(
      ReceiveRiskAnalysisResult analysisResult,
      AtomicBoolean hasError,
      ConstraintValidatorContext context) {
    if (null != analysisResult.getTypeOfControls()) {
      for (TypeOfControls type : analysisResult.getTypeOfControls()) {
        if (type.getType().equals("50") && StringUtils.isEmpty(type.getText())) {
          addViolation(context, ErrorCode.TSPNESXXC0458, TYPE_OF_CONTROL, TYPE_OF_CONTROL_TEXT);
          hasError.set(false);
        }
      }
    }
  }

  private void validateRiskAnalysisType(
      ReceiveRiskAnalysisResult analysisResult,
      AtomicBoolean hasError,
      ConstraintValidatorContext context) {
    List<RiskAnalysisResult> result = analysisResult.getRiskAnalysisResult();
    if (null != result && !result.isEmpty()) {
      for (RiskAnalysisResult val : result) {
        if (null != val.getType()
            && !val.getType().equalsIgnoreCase("Z")
            && null != val.getResultCode()
            && !List.of("2", "3", "4").contains(val.getResultCode())
            && analysisResult.getRiskAnalyst() == null) {
          addViolation(context, ErrorCode.TSPNESXXC0406, RISK_ANALYST);
          hasError.set(false);
        }
      }
    }
  }

  private void checkFormatOfRemainingControlRecommendations(
      ReceiveRiskAnalysisResult receiveRiskAnalysisResult,
      ConstraintValidatorContext context,
      AtomicBoolean isValid,
      boolean hasOnlyMaster,
      boolean hasOnlyHouse) {

    boolean isViolated = false;
    // check on remaining control recommendations
    for (int i = 1; i < receiveRiskAnalysisResult.getControlRecommendations().size(); i++) {

      ControlRecommendation cr = receiveRiskAnalysisResult.getControlRecommendations().get(i);

      MasterConsignment mc = findMasterConsignment(cr.getConsignments());

      if (hasOnlyMaster
          && !((mc != null
                  && (mc.getTransportDocument() != null
                      || CollectionUtils.isNotEmpty(mc.getTransportEquipment())
                      || CollectionUtils.isNotEmpty(mc.getReceptacle())
                      || CollectionUtils.isNotEmpty(mc.getConsignmentItem())))
              && cr.getConsignments().size() == 1)) {
        addViolation(context, ErrorCode.TSPNESXXR0453);
        isValid.set(false);
        isViolated = true;
      }

      if (hasOnlyHouse
          && !(mc != null
              && mc.getTransportDocument() == null
              && CollectionUtils.isEmpty(mc.getTransportEquipment())
              && CollectionUtils.isEmpty(mc.getReceptacle())
              && CollectionUtils.isEmpty(mc.getConsignmentItem())
              && cr.getConsignments().size() > 1)) {
        addViolation(context, ErrorCode.TSPNESXXR0453);
        isValid.set(false);
        isViolated = true;
      }

      if (isViolated) {
        break;
      }
    }
  }

  private MasterConsignment findMasterConsignment(List<Consignment> consignments) {
    Optional<Consignment> masterConsignment =
        consignments.stream().filter(c -> c instanceof MasterConsignment).findAny();
    if (masterConsignment.isPresent()) {
      return (MasterConsignment) masterConsignment.get();
    } else {
      return null;
    }
  }
}
