/*
 * @(#)be.fgov.minfin.tsd.domain.model.risk.ControlRecommendation.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model.risk;

import be.fgov.minfin.tsd.domain.model.consignment.AdditionalInformation;
import be.fgov.minfin.tsd.domain.model.consignment.Consignment;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import be.fgov.minfin.tsd.domain.validation.annotation.group.RiskResultValidator;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Lob;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString(callSuper = true)
@Table(name = "CONTROL_RECOMMENDATION")
@EqualsAndHashCode(exclude = "riskAnalysisRequest")
@ValidateBusinessRules(groups = RiskResultValidator.class)
public class ControlRecommendation {

  @Id
  @GeneratedValue(generator = "control_recommendation_seq")
  @SequenceGenerator(
      name = "control_recommendation_seq",
      sequenceName = "control_recommendation_seq")
  private Long id;

  @Column(name = "FUNCTIONAL_REFERENCE")
  private String functionalReference;

  @Column(name = "CONTROL_SUBJECT", columnDefinition = "CLOB NOT NULL")
  @Lob
  private String controlSubject;

  @Embedded private @Valid ControlResult controlResult;

  @JoinColumn(name = "RISK_ANALYSIS_REQUEST_ID")
  @ManyToOne(fetch = FetchType.LAZY)
  private RiskAnalysisRequest riskAnalysisRequest;

  @ManyToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
  @JoinTable(
      name = "CONSIGNMENT_CONTROL_RECOMMENDATION",
      joinColumns = @JoinColumn(name = "CONTROL_RECOMMENDATION_ID", referencedColumnName = "id"),
      inverseJoinColumns = @JoinColumn(name = "CONSIGNMENT_ID", referencedColumnName = "id"))
  private List<@Valid Consignment> consignments;

  @Transient private List<AdditionalInformation> additionalInformation; // for business Validation
}
