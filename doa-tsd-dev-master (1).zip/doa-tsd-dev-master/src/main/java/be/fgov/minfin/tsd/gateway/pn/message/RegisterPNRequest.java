/*
 * @(#) be.fgov.minfin.tsd.gateway.pn.message.RegisterPNRequest
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.pn.message;

import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.consignment.PreviousDocument;
import be.fgov.minfin.tsd.domain.model.consignment.TransportEquipment;
import java.util.List;
import lombok.Builder;
import lombok.Value;

/**
 * This class is to build message to register PN request
 *
 * @author NamrataGupta
 */
@Builder(toBuilder = true)
@Value
public class RegisterPNRequest {
  private MessageHeader messageHeader;
  private String receptionTimestamp;
  private TemporaryStorageDeclaration declaration;
  private PreviousDocument previousDocument;
  private List<TransportEquipment> transportEquipmentList;
}
