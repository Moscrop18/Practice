/*
 * @(#) be.fgov.minfin.tsd.domain.model.party.Representative
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model.party;

import be.fgov.minfin.tsd.domain.validation.annotation.CodeList;
import be.fgov.minfin.tsd.domain.validation.annotation.group.DeconsolidationNotificationValidatorGroup;
import be.fgov.minfin.tsd.domain.validation.annotation.group.NonDraftTSD;
import be.fgov.minfin.tsd.domain.validation.annotation.group.TransferNotificationValidatorGroup;
import be.fgov.minfin.tsd.domain.validation.codelist.TSDCodeLists;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.validation.constraints.NotNull;
import javax.validation.groups.Default;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@Entity
@DiscriminatorValue("Representative")
public class Representative extends Party {

  @Column(name = "representative_status", columnDefinition = "SMALLINT")
  @NotNull(groups = NonDraftTSD.class)
  private @CodeList(
      value = TSDCodeLists.CL094,
      groups = {
        Default.class,
        TransferNotificationValidatorGroup.class,
        DeconsolidationNotificationValidatorGroup.class
      }) String status;
  // To use builder pattern in  both child class and parent we added custom builder for this class
  @Builder(builderMethodName = "representativeBuilder")
  private Representative(
      Long id,
      List<Communication> communication,
      String name,
      String identificationNumber,
      String status,
      PartyAddress address) {
    super(id, communication, name, identificationNumber, address);
    this.status = status;
  }
}
