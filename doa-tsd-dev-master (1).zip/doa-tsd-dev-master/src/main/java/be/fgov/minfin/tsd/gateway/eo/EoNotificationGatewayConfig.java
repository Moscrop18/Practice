/*
 * @(#)be.fgov.minfin.tsd.gateway.eo.EONotificationGatewayConfig.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.eo;

import static be.fgov.minfin.tsd.config.RabbitConfig.ENABLE_QUORUM_QUEUE;
import static be.fgov.minfin.tsd.config.RabbitConfig.RABBIT_LISTENER_CONTAINER_FACTORY;

import be.fgov.minfin.libdoa.amqp.ExchangeConfig;
import be.fgov.minfin.libdoa.amqp.transactional.QueueConfig;
import be.fgov.minfin.tsd.gateway.eo.plugin.DefaultEONotificationGatewayConfig;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.boot.context.properties.NestedConfigurationProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;

/**
 * This is config class of EOGateway
 *
 * @author GauravMitra
 */
@Slf4j
@Setter
@Getter
@Validated
@Configuration
public class EoNotificationGatewayConfig {

  public static final String EO_NOTIFICATION_QUEUE = "#{eoNotificationQueue}";

  public static final String CONCURRENCY_SETTING =
      "#{eoNotificationGatewayConfig.eoNotificationQueue.concurrentConsumers}";

  @NestedConfigurationProperty private final DefaultEONotificationGatewayConfig defaultplugin;

  private ExchangeConfig exchange;
  private QueueConfig eoNotificationQueue;
  private RabbitTemplate rabbitTemplate;
  private boolean registerRetryQueueListener;

  private ConfigurableBeanFactory beanFactory;

  public EoNotificationGatewayConfig(
      ConfigurableBeanFactory beanFactory,
      DefaultEONotificationGatewayConfig defaultplugin,
      RabbitTemplate rabbitTemplate) {
    this.beanFactory = beanFactory;
    this.defaultplugin = defaultplugin;
    this.rabbitTemplate = rabbitTemplate;
    exchange = new ExchangeConfig("tsd.eonotification.gateway");
    eoNotificationQueue =
        new QueueConfig(
            exchange,
            "tsd_out_eo_notification",
            "send.tsd.eo.notification",
            "eoNotificationQueue",
            ENABLE_QUORUM_QUEUE);
  }

  public void init() {
    // can this be done more elegantly?
    exchange.registerBeanDefinitions(beanFactory);
    if (registerRetryQueueListener) {
      eoNotificationQueue.registerBeanDefinitions(
          beanFactory, RABBIT_LISTENER_CONTAINER_FACTORY, rabbitTemplate, false);
    } else {
      log.warn("RetryRoutingListener is not enabled for EoNotificationGateway");
      eoNotificationQueue.registerBeanDefinitions(beanFactory);
    }
  }
}
