/*
 * @(#) be.fgov.minfin.tsd.domain.validation.validator.WarehouseValidator.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation.validator;

import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentHeader;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class WarehouseValidator extends BaseConstraintValidator
    implements ConstraintValidator<ValidateBusinessRules, ConsignmentHeader> {

  private static final String TYPE = "type";
  private static final String WAREHOUSE = "warehouse";

  @Override
  public boolean isValid(ConsignmentHeader consignmentHeader, ConstraintValidatorContext context) {
    boolean isValid = true;
    if (null != consignmentHeader
        && null != consignmentHeader.getDecalaredlocationOfGoods()
        && null != consignmentHeader.getDecalaredlocationOfGoods().getTypeOfLocation()
        && consignmentHeader.getDecalaredlocationOfGoods().getTypeOfLocation().equals("B")
        && consignmentHeader.getWarehouse() == null) {
      isValid = false;
      addViolation(context, ErrorCode.TSPNESXXC0108, WAREHOUSE);
    }

    if (null != consignmentHeader
        && null != consignmentHeader.getWarehouse()
        && null != consignmentHeader.getWarehouse().getType()
        && !consignmentHeader.getWarehouse().getType().equals("V")) {
      isValid = false;
      addViolation(context, ErrorCode.TSPNESXXR0128, WAREHOUSE, TYPE);
    }

    return isValid;
  }
}
