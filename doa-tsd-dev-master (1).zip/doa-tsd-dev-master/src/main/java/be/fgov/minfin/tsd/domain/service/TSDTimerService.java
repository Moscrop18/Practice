/*
 * @(#)be.fgov.minfin.tsd.domain.service.TSDTimerService.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.service;

import be.fgov.minfin.libdoa.commons.lang.Now;
import be.fgov.minfin.shared.tracing.Traced;
import be.fgov.minfin.tsd.config.TSDConfig;
import be.fgov.minfin.tsd.domain.model.TSDDraftTimerProjection;
import be.fgov.minfin.tsd.domain.model.Timer;
import be.fgov.minfin.tsd.domain.model.TimerType;
import be.fgov.minfin.tsd.domain.repository.TimerRepository;
import be.fgov.minfin.tsd.event.TSDEventBroker;
import be.fgov.minfin.tsd.event.api.TSDTimerExpirationEvent;
import be.fgov.minfin.tsd.shared.TransactionHandler;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * This is service layer for functionality related to Timer in TSD
 *
 * @author GauravMitra
 */
@Service
@RequiredArgsConstructor
public class TSDTimerService {
  private final TimerRepository repository;
  private final TSDConfig tsdConfig;
  private final TSDEventBroker tsdEventBroker;
  private final TransactionHandler transactionHandler;

  @Traced
  public void createExpirationTimer(
      LocalDateTime expirationTimestamp, String reference, TimerType type) {
    Timer timer =
        Timer.builder()
            .expirationTimestamp(expirationTimestamp)
            .reference(reference)
            .type(type)
            .build();
    repository.save(timer);
  }

  /**
   * This Method is to Stop Timer
   *
   * @param refrence
   * @param type
   */
  @Traced
  public void stopExpirationTimer(String reference, TimerType type) {

    repository.deleteByReferenceAndType(reference, type);
  }

  /**
   * Retrieve expired timers in batches having batch size of default 100, and is configurable. It
   * then sends the expired timers on the rabbitmq in a new transaction for further processing and
   * finally deletes the timers in batches.
   */
  @Transactional(propagation = Propagation.NOT_SUPPORTED)
  public void checkTimers() {
    Integer batchSize = tsdConfig.getTimer().getExpiration().getBatchSize();
    Pageable pageRequest = PageRequest.of(0, batchSize);
    boolean hasMore = false;
    do {
      Slice<Timer> slice =
          repository.findByExpirationTimestampLessThan(
              Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime(), pageRequest);
      List<Timer> timers = slice.getContent();
      transactionHandler.runInNewTransaction(() -> this.processExpiredTimersBatch(timers));
      hasMore = timers.size() >= batchSize;
    } while (hasMore);
  }

  private void processExpiredTimersBatch(List<Timer> expiredTimers) {
    expiredTimers.forEach(this::publishTSDTimerExpirationEvent);
    repository.deleteInBatch(expiredTimers);
  }

  private void publishTSDTimerExpirationEvent(Timer timer) {
    tsdEventBroker.publishTSDExpirationTimersExpired(
        TSDTimerExpirationEvent.builder().expiredTimer(timer).build());
  }

  public void updateExpirationTimerForDraftTSD(
      List<TSDDraftTimerProjection> draftTimerProjections) {
    for (TSDDraftTimerProjection projection : draftTimerProjections) {
      if (projection.getRegistrationDate() != null && checkExpirationCanBeUpdated(projection)) {
        repository.updateExpirationTimestamp(
            projection.getId().toString(), projection.getRegistrationDate().plusDays(30));
      }
    }
  }

  private boolean checkExpirationCanBeUpdated(TSDDraftTimerProjection projection) {
    LocalDateTime time =
        projection.getRegistrationDate().plusDays(tsdConfig.getDraftTSDRemovalPeriod());
    return time.isAfter(Now.localDateTime());
  }

  public void createRiskAnalysisResultTimer(
      LocalDateTime riskAnalysisResultTimestamp, String reference, TimerType type) {
    createExpirationTimer(riskAnalysisResultTimestamp, reference, type);
  }
}
