/*
 * @(#) be.fgov.minfin.tsd.domain.validation.validator.TransportEquipmentValidator.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation.validator;

import be.fgov.minfin.tsd.domain.model.consignment.TransportEquipment;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.springframework.stereotype.Component;

/**
 * This class is used to validate Transport Equipment
 *
 * @author NamrataGupta
 */
@Component
public class TransportEquipmentValidator extends BaseConstraintValidator
    implements ConstraintValidator<ValidateBusinessRules, TransportEquipment> {

  @Override
  public boolean isValid(TransportEquipment equipment, ConstraintValidatorContext context) {
    boolean isValid = true;

    if (equipment != null) {

      if ((equipment.getNumberOfSeals() != null && equipment.getNumberOfSeals() != 0)
          && (equipment.getSeal() == null || equipment.getSeal().size() == 0)) {
        isValid = false;
      }

      if (equipment.getNumberOfSeals() == null
          && (equipment.getSeal() != null && equipment.getSeal().size() > 0)) {
        isValid = false;
      }

      if (!isValid) {
        addViolation(context, ErrorCode.TSPNESXXR0042);
      }
    }

    return isValid;
  }
}
