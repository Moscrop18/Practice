/*
 * @(#) be.fgov.minfin.tsd.domain.validation.validator.LocationOfGoodsValidator.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation.validator;

import static org.apache.commons.lang3.StringUtils.isBlank;

import be.fgov.minfin.libdoa.commons.lang.Now;
import be.fgov.minfin.tsd.domain.model.consignment.LocationOfGoods;
import be.fgov.minfin.tsd.domain.model.party.Party;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import be.fgov.minfin.tsd.domain.validation.message.MessageType;
import be.fgov.minfin.tsd.gateway.crs.CRSGateway;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.hibernate.validator.constraintvalidation.HibernateConstraintValidatorContext;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * This is class level validator to validate location of goods.
 *
 * @author NamrataGupta
 */
public class LocationOfGoodsValidator extends BaseConstraintValidator
    implements ConstraintValidator<ValidateBusinessRules, LocationOfGoods> {
  private static final String AUTHORISATION_NUMBER = "authorisationNumber";
  private static final String ECONOMIC_OPERATOR = "economicOperator";
  private static final String GNSS = "gnss";
  private static final String CUSTOMS_OFFICE = "customsOffice";
  public static final String QUAL_OF_IDENTIFICATION = "qualifierOfIdentification";
  public static final String UNLOCODE = "unLoCode";
  public static final String LOC_TYPE_A = "A";
  public static final String LOC_TYPE_B = "B";
  public static final String LOC_TYPE_C = "C";
  public static final String LOC_TYPE_D = "D";
  public static final String QUAL_IDEN_U = "U";
  public static final String QUAL_IDEN_V = "V";
  static Set<String> typeAValidQualIdentification;
  static Set<String> typeBValidQualIdentification;
  static Set<String> typeCValidQualIdentification;
  static Set<String> typeDValidQualIdentification;
  private static final String QUAL_IDEN_W = "W";
  private static final String QUAL_IDEN_Y = "Y";
  private static final String QUAL_IDEN_X = "X";
  public static final String IND_NUMBER = "identificationNumber";
  public static final String TYPE_OF_LOCATION = "typeOfLocation";

  @Autowired private CRSGateway crsGateway;

  static {
    typeAValidQualIdentification = Stream.of("U", "V").collect(Collectors.toSet());
    typeBValidQualIdentification = Stream.of("U").collect(Collectors.toSet());
    typeCValidQualIdentification = Stream.of("U").collect(Collectors.toSet());
    typeDValidQualIdentification = Stream.of("U", "V", "W", "X", "Y").collect(Collectors.toSet());
  }

  @Override
  public boolean isValid(LocationOfGoods value, ConstraintValidatorContext context) {
    AtomicBoolean hasError = new AtomicBoolean(false);

    MessageType messageType =
        context
            .unwrap(HibernateConstraintValidatorContext.class)
            .getConstraintValidatorPayload(MessageType.class);

    if (null != value.getQualifierOfIdentification()) {
      validateQualifierOfIdentification(value, context, hasError);
      validateUnlocode(value, context, hasError);
      validateCustomsOffice(value, context, hasError);
      validateGNSS(value, context, hasError);
      validateAddressAndEconomicOperator(value, context, hasError);
      validateAddressAndEconomicOperator(value, context, hasError);
      validateAddressAndAuthorizationNumber(value, context, hasError);
    }
    validateEconomicOperatorIdentificationNumber(value, context, hasError);

    if (messageType == MessageType.TRANSFER_NOTIFICATION_MESSAGE) {
      validateLocationOfGoodsType(value, hasError, context);
    }

    return !hasError.get();
  }

  /**
   * Validate qual of indentification
   *
   * @param value
   * @param context
   */
  private void validateQualifierOfIdentification(
      LocationOfGoods value, ConstraintValidatorContext context, AtomicBoolean hasError) {
    if (null == value.getTypeOfLocation()) return;
    if ((value.getTypeOfLocation().equalsIgnoreCase(LOC_TYPE_A)
            && !typeAValidQualIdentification.contains(value.getQualifierOfIdentification()))
        || (value.getTypeOfLocation().equalsIgnoreCase(LOC_TYPE_B)
            && !typeBValidQualIdentification.contains(value.getQualifierOfIdentification()))
        || (value.getTypeOfLocation().equalsIgnoreCase(LOC_TYPE_C)
            && !typeCValidQualIdentification.contains(value.getQualifierOfIdentification()))
        || (value.getTypeOfLocation().equalsIgnoreCase(LOC_TYPE_D)
            && !typeDValidQualIdentification.contains(value.getQualifierOfIdentification()))) {
      addViolation(context, ErrorCode.TSPNESXXR0067, QUAL_OF_IDENTIFICATION);
      hasError.set(true);
    }
  }

  /**
   * Validate UNLO Code
   *
   * @param value
   * @param context
   */
  private void validateUnlocode(
      LocationOfGoods value, ConstraintValidatorContext context, AtomicBoolean hasError) {
    if ((value.getQualifierOfIdentification().equalsIgnoreCase(QUAL_IDEN_U)
            && isBlank(value.getUnLoCode()))
        || (!value.getQualifierOfIdentification().equalsIgnoreCase(QUAL_IDEN_U)
            && !isBlank(value.getUnLoCode()))) {
      addViolation(context, ErrorCode.TSPNESXXC0061, UNLOCODE);
      hasError.set(true);
    }
  }

  /**
   * Validate Customs Office
   *
   * @param value
   * @param context
   */
  private void validateCustomsOffice(
      LocationOfGoods value, ConstraintValidatorContext context, AtomicBoolean hasError) {
    if ((value.getQualifierOfIdentification().equalsIgnoreCase(QUAL_IDEN_V)
            && null == value.getCustomsOffice())
        || (!value.getQualifierOfIdentification().equalsIgnoreCase(QUAL_IDEN_V)
            && null != value.getCustomsOffice())) {
      addViolation(context, ErrorCode.TSPNESXXC0062, CUSTOMS_OFFICE);
      hasError.set(true);
    }
  }

  /**
   * Validate GNSS
   *
   * @param value
   * @param context
   */
  private void validateGNSS(
      LocationOfGoods value, ConstraintValidatorContext context, AtomicBoolean hasError) {
    if ((value.getQualifierOfIdentification().equalsIgnoreCase(QUAL_IDEN_W)
            && null == value.getGnss())
        || (!value.getQualifierOfIdentification().equalsIgnoreCase(QUAL_IDEN_W)
            && null != value.getGnss())) {
      addViolation(context, ErrorCode.TSPNESXXC0063, GNSS);
      hasError.set(true);
    }
  }

  /**
   * Validate Address and Economic Operator
   *
   * @param value
   * @param context
   */
  private void validateAddressAndEconomicOperator(
      LocationOfGoods value, ConstraintValidatorContext context, AtomicBoolean hasError) {
    if ((value.getQualifierOfIdentification().equalsIgnoreCase(QUAL_IDEN_X)
            && (null == value.getAddress() || null == value.getEconomicOperator()))
        || (!value.getQualifierOfIdentification().equalsIgnoreCase(QUAL_IDEN_X)
            && null != value.getEconomicOperator())
        || (!(value.getQualifierOfIdentification().equalsIgnoreCase(QUAL_IDEN_X)
                || value.getQualifierOfIdentification().equalsIgnoreCase(QUAL_IDEN_Y))
            && value.getAddress() != null)) {
      addViolation(context, ErrorCode.TSPNESXXC0064, ECONOMIC_OPERATOR);
      hasError.set(true);
    }
  }

  /**
   * Validate Address and Authorization Number
   *
   * @param value
   * @param context
   */
  private void validateAddressAndAuthorizationNumber(
      LocationOfGoods value, ConstraintValidatorContext context, AtomicBoolean hasError) {
    if ((value.getQualifierOfIdentification().equalsIgnoreCase(QUAL_IDEN_Y)
            && (null == value.getAddress() || (isBlank(value.getAuthorisationNumber()))))
        || (!value.getQualifierOfIdentification().equalsIgnoreCase(QUAL_IDEN_Y)
            && !isBlank(value.getAuthorisationNumber()))) {
      addViolation(context, ErrorCode.TSPNESXXC0065, AUTHORISATION_NUMBER);
      hasError.set(true);
    }
  }

  /**
   * This is method is to check Economic Operator identification number is valid EORI number
   *
   * @param value
   * @param context
   * @param hasError
   */
  private void validateEconomicOperatorIdentificationNumber(
      LocationOfGoods value, ConstraintValidatorContext context, AtomicBoolean hasError) {
    if (null == value.getEconomicOperator()) return;
    AtomicBoolean isValid =
        checkValidEoriNumber(value.getEconomicOperator().getIdentificationNumber());

    if (!isValid.get()) {
      hasError.set(true);
      addViolation(context, ErrorCode.TSPNESXXR0109, ECONOMIC_OPERATOR, IND_NUMBER);
    }
  }

  private void validateLocationOfGoodsType(
      LocationOfGoods locationOfGoods, AtomicBoolean hasError, ConstraintValidatorContext context) {

    if (locationOfGoods.getTypeOfLocation() == null
        || !locationOfGoods.getTypeOfLocation().equals("B")) {
      hasError.set(true);
      addViolation(context, ErrorCode.TSPNESXXR0142, TYPE_OF_LOCATION);
    }
  }

  private AtomicBoolean checkValidEoriNumber(String identificationNumber) {
    AtomicBoolean isValid = new AtomicBoolean(true);
    Optional<Party> party =
        crsGateway.getPartyInfo(identificationNumber, Now.localDateTime(), false, false);

    if (party.isEmpty()) {
      isValid.set(false);
    }

    return isValid;
  }
}
