/*
 * @(#)be.fgov.minfin.tsd.domain.converter.StatusHistoryReasonConverter.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.converter;

import be.fgov.minfin.tsd.domain.model.StatusHistoryReason;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter(autoApply = true)
public class StatusHistoryReasonConverter
    implements AttributeConverter<StatusHistoryReason, Integer> {

  @Override
  public Integer convertToDatabaseColumn(StatusHistoryReason reason) {
    if (reason != null) {
      return reason.getCode();
    }
    return null;
  }

  @Override
  public StatusHistoryReason convertToEntityAttribute(Integer dbData) {
    for (StatusHistoryReason nodeType : StatusHistoryReason.values()) {
      if (nodeType.getCode().equals(dbData)) {
        return nodeType;
      }
    }
    if (dbData != null) {
      throw new IllegalArgumentException("Unknown database value:" + dbData);
    } else {
      return null;
    }
  }
}
