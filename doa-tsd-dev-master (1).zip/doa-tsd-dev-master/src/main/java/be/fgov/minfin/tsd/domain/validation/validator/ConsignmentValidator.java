/*
 * @(#) be.fgov.minfin.tsd.domain.validation.validator.ConsignmentValidator.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation.validator;

import static org.apache.commons.collections4.CollectionUtils.isEmpty;
import static org.apache.commons.collections4.CollectionUtils.isNotEmpty;

import be.fgov.minfin.tsd.domain.model.consignment.Consignment;
import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentItem;
import be.fgov.minfin.tsd.domain.model.consignment.Packaging;
import be.fgov.minfin.tsd.domain.model.consignment.PreviousDocument;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.apache.commons.collections4.CollectionUtils;

public class ConsignmentValidator extends BaseConstraintValidator
    implements ConstraintValidator<ValidateBusinessRules, Consignment> {
  private static final String CONSIGNMENT_ITEM = "consignmentItem[";
  private static final String COMMODITY = "commodity";
  private static final String COMMODITY_CODE = "commodityCode";
  private static final String NATURAL_PERSON = "1";
  private static final String WEIGHT = "weight";

  @Override
  public boolean isValid(Consignment consignment, ConstraintValidatorContext context) {
    AtomicBoolean isValid = new AtomicBoolean(true);
    if (consignment.getConsignmentItem() != null) {

      validateCommodityCode(consignment, isValid, context);

      validatePackagingNumber(consignment, context, isValid);

      validateHarmonizedSystemSubHeadingCode(consignment, context, isValid);
      validatePreviousDocument(consignment, context, isValid);
    }
    validateTransportEquipment(consignment, context, isValid);
    validateAdditionalInformationExistence(consignment, context, isValid);
    validateConsignmentItemPreviousDocument(consignment, context, isValid);
    validateSupportingDocument(consignment, context, isValid);
    validateAdditionalSupplyChainActorExistence(consignment, context, isValid);
    return isValid.get();
  }

  private void validateAdditionalSupplyChainActorExistence(
      Consignment consignment, ConstraintValidatorContext context, AtomicBoolean isValid) {
    List<ConsignmentItem> consignmentItems = null;
    if (null == consignment) return;
    if (isNotEmpty(consignment.getConsignmentItem())) {
      consignmentItems =
          consignment.getConsignmentItem().stream()
              .filter(x -> CollectionUtils.isNotEmpty(x.getAdditionalSupplyChainActor()))
              .collect(Collectors.toList());
    }

    if (isNotEmpty(consignment.getAdditionalSupplyChainActor()) && isNotEmpty(consignmentItems)) {
      addViolation(context, ErrorCode.TSPNESXXR0051);
      isValid.set(false);
    }
  }

  private void validateSupportingDocument(
      Consignment consignment, ConstraintValidatorContext context, AtomicBoolean isValid) {
    if (null != consignment
        && !CollectionUtils.isEmpty(consignment.getSupportingDocument())
        && !CollectionUtils.isEmpty(consignment.getConsignmentItem())
        && consignment.getConsignmentItem().stream()
            .anyMatch(item -> !CollectionUtils.isEmpty(item.getSupportingDocument()))) {
      addViolation(context, ErrorCode.TSPNESXXR0025);
      isValid.set(false);
    }
  }

  private void validateAdditionalInformationExistence(
      Consignment consignment, ConstraintValidatorContext context, AtomicBoolean isValid) {
    List<ConsignmentItem> consignmentItems = null;
    if (isEmpty(consignment.getConsignmentItem())) return;
    consignmentItems =
        consignment.getConsignmentItem().stream()
            .filter(x -> CollectionUtils.isEmpty(x.getAdditionalInformation()))
            .collect(Collectors.toList());

    if (!CollectionUtils.isEmpty(consignment.getAdditionalInformation())
        && CollectionUtils.isEmpty(consignmentItems)) {
      addViolation(context, ErrorCode.TSPNESXXR0050);
      isValid.set(false);
    }
  }

  private void validateTransportEquipment(
      Consignment consignment, ConstraintValidatorContext context, AtomicBoolean isValid) {
    List<ConsignmentItem> consignmentItems = null;
    if (isEmpty(consignment.getConsignmentItem())) return;
    consignmentItems =
        consignment.getConsignmentItem().stream()
            .filter(x -> CollectionUtils.isEmpty(x.getTransportEquipment()))
            .collect(Collectors.toList());

    if (!CollectionUtils.isEmpty(consignment.getTransportEquipment())
        && (CollectionUtils.isEmpty(consignmentItems))) {
      addViolation(context, ErrorCode.TSPNESXXR0026);
      isValid.set(false);
    }
  }

  private void validatePackagingNumber(
      Consignment consignment, ConstraintValidatorContext context, AtomicBoolean isValid) {
    int currentIndex = 0;
    for (ConsignmentItem item : consignment.getConsignmentItem()) {
      List<Packaging> packagingList = null;
      if (item.getPackaging() != null) {
        packagingList =
            item.getPackaging().stream()
                .filter(x -> x.getNumberOfPackages() == null)
                .collect(Collectors.toList());

        if (!packagingList.isEmpty()
            && (item.getGrossMass() == null || item.getGrossMass().equals(new BigDecimal(0)))) {
          addViolation(
              context, ErrorCode.TSPNESXXC0097, CONSIGNMENT_ITEM + currentIndex + "]", WEIGHT);
          isValid.set(false);
        }
      }
      if ((item.getPackaging() == null || (!CollectionUtils.isEmpty(packagingList)))
          && (item.getGrossMass() == null || item.getGrossMass().equals(BigDecimal.valueOf(0)))) {
        addViolation(
            context, ErrorCode.TSPNESXXC0097, CONSIGNMENT_ITEM + currentIndex + "]", WEIGHT);
        isValid.set(false);
      }
      currentIndex++;
    }
  }

  private void validateCommodityCode(
      Consignment consignment, AtomicBoolean isValid, ConstraintValidatorContext context) {

    String consigneeType = getConsigneeType(consignment);
    String consignorType = getConsignorType(consignment);

    if (!NATURAL_PERSON.equals(consigneeType) || !NATURAL_PERSON.equals(consignorType)) {
      int index = 0;
      for (ConsignmentItem item : consignment.getConsignmentItem()) {
        if (item.getCommodity() != null && item.getCommodity().getCommodityCode() == null) {
          isValid.set(false);
          addViolation(
              context,
              ErrorCode.TSPNESXXC0049,
              CONSIGNMENT_ITEM + index + "]",
              COMMODITY,
              COMMODITY_CODE);
        }
        index++;
      }
    }
  }

  private String getConsignorType(Consignment consignment) {
    return consignment.getConsignor() != null ? consignment.getConsignor().getTypeOfPerson() : null;
  }

  private String getConsigneeType(Consignment consignment) {
    return consignment.getConsignee() != null ? consignment.getConsignee().getTypeOfPerson() : null;
  }

  private void validateHarmonizedSystemSubHeadingCode(
      Consignment consignment, ConstraintValidatorContext context, AtomicBoolean isValid) {
    Set<String> setOfHarmonizedCode = new HashSet<>();
    for (ConsignmentItem item : consignment.getConsignmentItem()) {
      if (null == item.getCommodity()) return;
      if (null == item.getCommodity().getCommodityCode()) return;
      if (!setOfHarmonizedCode.add(
          item.getCommodity().getCommodityCode().getHarmonizedSystemSubHeadingCode())) {
        isValid.set(false);
        addViolation(context, ErrorCode.TSPNESXXR0132);
      }
    }
  }

  /**
   * The 'PREVIOUS DOCUMENT' class should exists at 'CONSIGNMENT' level or 'CONSIGNMENTITEM' level
   *
   * @param consignment
   * @param context
   * @param isValid
   */
  private void validatePreviousDocument(
      Consignment consignment, ConstraintValidatorContext context, AtomicBoolean isValid) {
    List<ConsignmentItem> consignmentItems =
        consignment.getConsignmentItem().stream()
            .filter(x -> x.getPreviousDocument() != null)
            .collect(Collectors.toList());

    if (consignment.getPreviousDocument() != null && (!CollectionUtils.isEmpty(consignmentItems))) {
      addViolation(context, ErrorCode.TSPNESXXR0053);
      isValid.set(false);
    }
  }

  /**
   * For each 'CONSIGNMENT/CONSIGNMENT ITEM' per 'CONSIGNMENT', maximum 1 previous document is
   * allowed
   *
   * @param tsd
   * @param context
   * @param isValid
   */
  private void validateConsignmentItemPreviousDocument(
      Consignment consignment, ConstraintValidatorContext context, AtomicBoolean isValid) {
    if (null == consignment) return;
    PreviousDocument masterPreviousDocument = consignment.getPreviousDocument();
    List<String> listOfPreviousDocument = new ArrayList<>();

    if (masterPreviousDocument == null) {
      if (null == consignment.getConsignmentItem()) return;
      for (ConsignmentItem item : consignment.getConsignmentItem()) {
        addSetString(listOfPreviousDocument, item);
      }
    } else {
      listOfPreviousDocument.add(
          masterPreviousDocument.getReferenceNumber().toLowerCase()
              + masterPreviousDocument.getType().toLowerCase());

      if (null == consignment.getConsignmentItem()) return;
      for (ConsignmentItem item : consignment.getConsignmentItem()) {
        if (item.getPreviousDocument() != null) {
          listOfPreviousDocument.add(
              item.getPreviousDocument().getReferenceNumber().toLowerCase()
                  + item.getPreviousDocument().getType().toLowerCase());
        }
      }
    }

    boolean allEqual = listOfPreviousDocument.stream().distinct().count() == 1;

    if (!allEqual) {
      isValid.set(false);
      addViolation(context, ErrorCode.TSPNESXXR0040);
    }
  }

  private void addSetString(List<String> listOfPreviousDocument, ConsignmentItem item) {
    if (item.getPreviousDocument() == null) {
      listOfPreviousDocument.add("BlankConsignmentItem");
    } else {
      listOfPreviousDocument.add(
          item.getPreviousDocument().getReferenceNumber().toLowerCase()
              + item.getPreviousDocument().getType().toLowerCase());
    }
  }
}
