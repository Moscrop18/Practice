/*
 * @(#)be.fgov.minfin.tsd.resource.api.ReceiveRiskHitNotificationDTO.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.resource.api;

import static be.fgov.minfin.tsd.util.DateFormatUtil.MESSAGE_DATE_TIME_FORMAT;

import be.fgov.minfin.tsd.constant.MessageNameConstant;
import be.fgov.minfin.tsd.domain.validation.annotation.Timestamp;
import com.fasterxml.jackson.annotation.JsonRootName;
import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.Builder;
import lombok.Value;

/** IETS403 */
@Value
@Builder(toBuilder = true)
@JsonRootName(MessageNameConstant.RECEIVE_RISK_HIT_NOTIFICATION)
public class ReceiveRiskHitNotificationDTO {
  @NotNull @Valid private MessageHeaderDTO messageHeader;

  @NotNull
  @Size(min = 1, max = 35)
  private String functionalReference;

  @NotNull
  @Schema(example = "2020-06-01T18:44:22Z")
  @Timestamp(formatter = MESSAGE_DATE_TIME_FORMAT)
  private String documentIssueDate;

  @NotNull @Valid private BaseRiskAnalysisRequestDTO riskAnalysis;
}
