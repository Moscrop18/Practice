/*
 * @(#)be.fgov.minfin.tsd.gateway.GatewayConfig.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway;

import be.fgov.minfin.tsd.gateway.control.ControlGatewayConfig;
import be.fgov.minfin.tsd.gateway.ens.ENSGatewayConfig;
import be.fgov.minfin.tsd.gateway.eo.EoNotificationGatewayConfig;
import be.fgov.minfin.tsd.gateway.ga.GoodsAccountingGatewayConfig;
import be.fgov.minfin.tsd.gateway.pn.PnGatewayConfig;
import be.fgov.minfin.tsd.gateway.risk.RiskAnalysisGatewayConfig;
import javax.annotation.PostConstruct;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.NestedConfigurationProperty;
import org.springframework.context.annotation.Configuration;

/**
 * root class for gateway configuration
 *
 * @author GauravMitra
 */
@Setter
@Getter
@Configuration
@ConfigurationProperties(prefix = "gateway", ignoreUnknownFields = true)
@RequiredArgsConstructor
public class GatewayConfig {
  public static final int DEFAULT_CONNECT_TIMEOUT = 30000;
  public static final int DEFAULT_REQUEST_TIMEOUT = 30000;
  @NestedConfigurationProperty private final EoNotificationGatewayConfig eo;
  @NestedConfigurationProperty private final PnGatewayConfig pn;
  @NestedConfigurationProperty private final ENSGatewayConfig ens;
  @NestedConfigurationProperty private final RiskAnalysisGatewayConfig risk;
  @NestedConfigurationProperty private final ControlGatewayConfig control;
  @NestedConfigurationProperty private final GoodsAccountingGatewayConfig ga;

  /**
   * application properties inside a @NestedConfigurationProperty are only initialized after
   * the @PostConstruct method gets executed, hence using @PostConstruct here, instead of their
   * respective GatewayConfig's like EoNotificationGatewayConfig, PnGatewayConfig etc.
   */
  @PostConstruct
  public void initializeAllGateways() {
    eo.init();
    pn.init();
    risk.init();
    control.init();
    ga.init();
  }
}
