/*
 * @(#)be.fgov.minfin.tsd.gateway.eo.SendEONotificationListener.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.eo;

import static be.fgov.minfin.tsd.gateway.eo.EoNotificationGatewayConfig.CONCURRENCY_SETTING;
import static be.fgov.minfin.tsd.gateway.eo.EoNotificationGatewayConfig.EO_NOTIFICATION_QUEUE;

import be.fgov.minfin.libdoa.amqp.transactional.AbstractRetryingQueueListener;
import be.fgov.minfin.tsd.gateway.eo.api.EONotificationEvent;
import be.fgov.minfin.tsd.gateway.eo.plugin.EONotificationGatewayPlugin;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

@Component
public class SendEONotificationListener extends AbstractRetryingQueueListener {
  static final String LISTENER_ID = "process-eo-notication";

  private EONotificationGatewayPlugin plugin;

  public SendEONotificationListener(
      EoNotificationGatewayConfig notConfig, EONotificationGatewayPlugin plugin) {

    super(notConfig.getEoNotificationQueue());
    this.plugin = plugin;
  }

  /** Receives message from queue for sending to EO Gateway */
  @RabbitListener(
      id = LISTENER_ID,
      queues = EO_NOTIFICATION_QUEUE,
      concurrency = CONCURRENCY_SETTING)
  public void onReceiveSendNotification(
      @Payload EONotificationEvent eoNotificationEvent, Message message) {
    plugin.sendNotification(eoNotificationEvent);
  }
}
