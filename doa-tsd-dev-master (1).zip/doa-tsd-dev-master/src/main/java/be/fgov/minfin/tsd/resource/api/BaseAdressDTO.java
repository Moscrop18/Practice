package be.fgov.minfin.tsd.resource.api;

import be.fgov.minfin.tsd.resource.validation.B2BOnly;
import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@SuperBuilder(toBuilder = true)
@EqualsAndHashCode
@Getter
@AllArgsConstructor(access = AccessLevel.PROTECTED)
@NoArgsConstructor
public class BaseAdressDTO {
  @NotNull(groups = B2BOnly.class)
  @Pattern(regexp = "[a-zA-Z]{2}")
  @Schema(example = "BE", description = "Country code (CL718)")
  private String country;

  @Size(min = 1, max = 17)
  @Schema(example = "4800")
  private String postCode;

  @NotNull(groups = B2BOnly.class)
  @Size(min = 1, max = 35)
  @Schema(example = "Verviers")
  private String city;
}
