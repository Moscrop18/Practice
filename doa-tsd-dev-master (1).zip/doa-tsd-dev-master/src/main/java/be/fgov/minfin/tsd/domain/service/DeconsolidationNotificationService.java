/*
 * @(#) be.fgov.minfin.tsd.domain.service.DeconsolidationNotificationService.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.service;

import static be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclarationType.COMBINED;
import static be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclarationType.PRELODGED;
import static be.fgov.minfin.tsd.domain.model.TimerType.RISK_ANALYSIS_RESULT;
import static be.fgov.minfin.tsd.domain.model.TimerType.TSD_DRAFT_EXPIRATION;
import static be.fgov.minfin.tsd.domain.model.TimerType.TSD_EXPIRATION;

import be.fgov.minfin.libdoa.commons.lang.Now;
import be.fgov.minfin.libdoa.goods.accounting.client.api.owd.LockOffwritableDocumentStatusReason;
import be.fgov.minfin.tsd.config.TSDConfig;
import be.fgov.minfin.tsd.domain.mapper.TSDDomainMapper;
import be.fgov.minfin.tsd.domain.message.Error;
import be.fgov.minfin.tsd.domain.model.DeconsolidationNotification;
import be.fgov.minfin.tsd.domain.model.MRN;
import be.fgov.minfin.tsd.domain.model.TSDStatus;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.TimerType;
import be.fgov.minfin.tsd.domain.model.party.Party;
import be.fgov.minfin.tsd.domain.model.risk.RiskAndControlStatus;
import be.fgov.minfin.tsd.domain.repository.TSDRepository;
import be.fgov.minfin.tsd.domain.sender.TSDResponseSender;
import be.fgov.minfin.tsd.domain.validation.message.MessageType;
import be.fgov.minfin.tsd.domain.validation.plugin.DeconsolidationNotificationValidatorPlugin;
import be.fgov.minfin.tsd.event.TSDEventBroker;
import be.fgov.minfin.tsd.event.api.TSDDeconsolidationNotificationRecievedEvent;
import be.fgov.minfin.tsd.gateway.ga.GoodsAccountingGateway;
import be.fgov.minfin.tsd.gateway.risk.RiskAnalysisGateway;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import javax.validation.ConstraintViolation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class DeconsolidationNotificationService {

  private final TSDEventBroker tsdEventBroker;
  private final TSDRepository tsdRepository;
  private final DeconsolidationNotificationValidatorPlugin deconsolidationNotificationValidator;
  private final PartyDetailsLoader partyLoader;
  private final TSDResponseSender tsdResponseSender;
  private final TSDDomainMapper tsdDomainMapper;
  private final TSDTimerService timerService;
  private final TSDConfig tsdConfig;
  private final RiskAnalysisGateway riskAnalysisGateway;
  private final GoodsAccountingGateway goodsAccountingGateway;

  public void receiveDeconsolidationNotification(
      String mrn, DeconsolidationNotification deconsolidationNotification) {
    TSDDeconsolidationNotificationRecievedEvent tsdDeconsolidationNotificationRecievedEvent =
        TSDDeconsolidationNotificationRecievedEvent.builder()
            .mrn(mrn)
            .deconsolidationNotification(deconsolidationNotification)
            .build();
    tsdEventBroker.publishDeconsolidationNotificationReceivedEvent(
        tsdDeconsolidationNotificationRecievedEvent);
  }

  public void processDeconsolidationNotification(
      String mrn, DeconsolidationNotification deconsolidationNotification) {

    log.info(
        "DeconsolidationNotification received in DeconsolidationNotificationService with mrn {}",
        mrn);

    Optional<TemporaryStorageDeclaration> optionalTSD =
        tsdRepository.findCurrentVersion(MRN.of(mrn));

    TemporaryStorageDeclaration currentTSD = optionalTSD.isPresent() ? optionalTSD.get() : null;

    Set<ConstraintViolation<DeconsolidationNotification>> violations =
        deconsolidationNotificationValidator.validateDeconsolidationNotificationCanBeProcessed(
            deconsolidationNotification, currentTSD);

    if (!violations.isEmpty()) {

      List<Error> errors =
          tsdResponseSender.buildErrors(
              violations,
              deconsolidationNotification.getMessageInformation().getLanguageCode(),
              false,
              true);

      if (canRegisterMessageExchange(errors)) {
        tsdResponseSender.sendDeconsolidationNotificationRefusedMessage(
            mrn, deconsolidationNotification, errors, currentTSD);
      } else {
        tsdResponseSender.sendDeconsolidationNotificationRefusedMessage(
            mrn, deconsolidationNotification, errors, null);
      }

      return;
    }

    loadDeclarantAndRepresentativeDetails(deconsolidationNotification);
    prefillName(deconsolidationNotification);

    violations =
        deconsolidationNotificationValidator.validateDeconsolidationNotification(
            deconsolidationNotification,
            MessageType.DECONSOLIDATION_NOTIFICATION_MESSAGE,
            currentTSD);

    if (violations.isEmpty() && currentTSD != null && currentTSD.getLinkedPnFrn() != null) {
      violations =
          goodsAccountingGateway.lockOffwritableDocument(
              currentTSD.getTransferNotification(),
              currentTSD.getReferenceNumber().getMrn().getMrnNumber(),
              LockOffwritableDocumentStatusReason.DECONSOLIDATION);
    }

    List<Error> errors = null;

    if (!violations.isEmpty()) {
      errors =
          tsdResponseSender.buildErrors(
              violations,
              deconsolidationNotification.getMessageInformation().getLanguageCode(),
              false,
              true);

      if (cannotRegisterDeconsolidationNotification(errors)) {
        tsdResponseSender.sendDeconsolidationNotificationRefusedMessage(
            mrn, deconsolidationNotification, errors, currentTSD);
        return;
      }
    }

    if (currentTSD != null) {
      registerClonedTSDAndDeconsolidationNotification(
          mrn, deconsolidationNotification, currentTSD, errors);
    }
  }

  /**
   * Prefill name of party on the basis of crs data
   *
   * @param declaration
   */
  private void prefillName(DeconsolidationNotification deconsolidationNotification) {
    if (null != deconsolidationNotification.getDeclarant()
        && null == deconsolidationNotification.getDeclarant().getName()) {
      deconsolidationNotification
          .getDeclarant()
          .setName(
              getNameFromCrs(deconsolidationNotification.getDeclarant().getIdentificationNumber()));
    }
    if (null != deconsolidationNotification.getRepresentative()
        && null == deconsolidationNotification.getRepresentative().getName()) {
      deconsolidationNotification
          .getRepresentative()
          .setName(
              getNameFromCrs(
                  deconsolidationNotification.getRepresentative().getIdentificationNumber()));
    }
  }

  /**
   * get name for person and carrier
   *
   * @param identificationNumber
   * @return
   */
  private String getNameFromCrs(String identificationNumber) {
    Optional<Party> party = partyLoader.loadPartyDetails(identificationNumber);
    return party.isPresent() ? party.get().getName() : null;
  }

  /**
   * @param party
   */
  private void loadDeclarantAndRepresentativeDetails(DeconsolidationNotification dn) {
    partyLoader.loadPartyDetails(dn.getDeclarant());
    if (null != dn.getRepresentative()) {
      partyLoader.loadPartyDetails(dn.getRepresentative());
    }
  }

  private void registerClonedTSDAndDeconsolidationNotification(
      String mrn,
      DeconsolidationNotification deconsolidationNotification,
      TemporaryStorageDeclaration currentTSD,
      List<Error> errors) {

    Integer maxVersion =
        tsdRepository.findMaxVersionTSD(currentTSD.getReferenceNumber().getCrn(), TSDStatus.DRAFT);

    TemporaryStorageDeclaration deconTSD = deconsolidationNotification.getDeclaration();

    tsdDomainMapper.mapDeconsolidationTSD(deconTSD, currentTSD);

    deconsolidationNotification.completeDeconsolidationNotification(currentTSD, errors);

    deconTSD.appendDeconsolidationNotificationDetails(
        maxVersion, currentTSD, deconsolidationNotification, errors);

    tsdRepository.save(deconTSD);

    if (CollectionUtils.isEmpty(errors)) {
      deconTSD.getReferenceNumber().setDeconsolidatedTSDId(deconTSD.getId());

      LocalDateTime awaitingRiskResultHours =
          calculateExpirationTimestamp(TimerType.RISK_ANALYSIS_RESULT);
      if ((deconTSD.getType() == COMBINED
              || (deconTSD.getType() == PRELODGED
                  && deconTSD.getCurrentStatus() == TSDStatus.ACCEPTED))
          && awaitingRiskResultHours != null) {
        timerService.stopExpirationTimer(
            currentTSD.getReferenceNumber().getCrn().getCrnNumber(),
            TimerType.RISK_ANALYSIS_RESULT);
        timerService.createRiskAnalysisResultTimer(
            awaitingRiskResultHours,
            deconTSD.getReferenceNumber().getCrn().getCrnNumber(),
            TimerType.RISK_ANALYSIS_RESULT);
      }

      deconTSD.addRiskAnalysisAndHistory(
          awaitingRiskResultHours, RiskAndControlStatus.AWAITING_RISK_ANALYSIS_RESULT);
      riskAnalysisGateway.sendTSDToRiskAnalysis(deconTSD, true, false);
      goodsAccountingGateway.sendDeconsolidationOffwritableDocument(deconTSD);

      tsdResponseSender.sendDeconsolidationNotificationAcceptedMessage(
          mrn, deconsolidationNotification, deconTSD);
    } else {
      tsdResponseSender.sendDeconsolidationNotificationRefusedMessage(
          mrn, deconsolidationNotification, errors, deconTSD);
    }
  }

  // message Exchange should be registered only when errorcode <> TSPNESXXR0135
  private boolean canRegisterMessageExchange(List<Error> errors) {
    return errors.stream().anyMatch((error -> !error.getErrorReason().equals("BER0135")));
  }

  // DeconsolidationNotification should not be registered when errorcode == TSPNESXXR0024 or
  // TSPNESXXR0149
  private boolean cannotRegisterDeconsolidationNotification(List<Error> errors) {

    return errors.stream()
        .anyMatch(
            (error ->
                error.getErrorReason().equals("BER0024")
                    || error.getErrorReason().equals("BER0149")));
  }

  public LocalDateTime calculateExpirationTimestamp(TimerType type) {
    if (type == TSD_EXPIRATION) {
      return Now.localDateTime()
          .plusDays(tsdConfig.getExpirationTimestampPeriod())
          .atOffset(ZoneOffset.UTC)
          .toLocalDateTime();
    } else if (type == TSD_DRAFT_EXPIRATION) {
      return Now.localDateTime()
          .plusDays(tsdConfig.getDraftTSDRemovalPeriod())
          .atOffset(ZoneOffset.UTC)
          .toLocalDateTime();
    } else if (type == RISK_ANALYSIS_RESULT
        && tsdConfig.getAwaitingRiskResultHours() != null
        && tsdConfig.getAwaitingRiskResultHours() > 0) {
      return Now.localDateTime()
          .plusHours(tsdConfig.getAwaitingRiskResultHours())
          .atOffset(ZoneOffset.UTC)
          .toLocalDateTime();
    }
    return null;
  }
}
