/*
 * @(#) be.fgov.minfin.tsd.gateway.pn.PNGateway.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.pn;

import static be.fgov.minfin.tsd.constant.MessageNameConstant.ACTIVATION_RESULT_MESSAGE;
import static be.fgov.minfin.tsd.util.DateFormatUtil.MESSAGE_TIMESTAMP_FORMAT;

import be.fgov.minfin.libdoa.amqp.transactional.QueueSender;
import be.fgov.minfin.libdoa.commons.lang.Now;
import be.fgov.minfin.libdoa.exception.TechnicalException;
import be.fgov.minfin.pn.client.api.MessageHeaderDTO;
import be.fgov.minfin.shared.tracing.Traced;
import be.fgov.minfin.tsd.config.TSDConfig;
import be.fgov.minfin.tsd.domain.model.MessageExchange;
import be.fgov.minfin.tsd.domain.model.TSDActivationRequest;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.repository.MessageExchangeRepository;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import be.fgov.minfin.tsd.gateway.pn.exception.RegisterPNRejectException;
import be.fgov.minfin.tsd.gateway.pn.message.ActivationResultDTO;
import be.fgov.minfin.tsd.gateway.pn.message.ActivationResultRequestBuilder;
import be.fgov.minfin.tsd.gateway.pn.message.PNLinkRequest;
import be.fgov.minfin.tsd.gateway.pn.message.RegisterPNRequestBuilder;
import be.fgov.minfin.tsd.gateway.pn.plugin.DefaultPNPlugin;
import be.fgov.minfin.tsd.resource.generator.CorrelationIdGenerator;
import be.fgov.minfin.tsd.util.DateUtil;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.Set;
import javax.validation.ConstraintViolation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;

/**
 * This class is used as gateway component for integrating with the PN system.
 *
 * @author NamrataGupta
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class PNGateway {

  private final DefaultPNPlugin plugin;
  private final RegisterPNRequestBuilder pnRequestBuilder;
  private final TSDConfig tsdConfig;
  private final QueueSender queueSender;
  private final PnGatewayConfig pnGatewayConfig;
  private final DateUtil dateUtil;
  private final CorrelationIdGenerator correlationIdGenerator;

  private final ActivationResultRequestBuilder activationResultBuilder;
  private final MessageExchangeRepository messageExchangeRepository;

  /**
   * Synchronous operation to registers a PN, this operation is used to create a PN for a combined
   * TSD. However, the TSD will only be linked once it could be processed
   *
   * @param tsd
   */
  @Traced
  @Retryable(
      exclude = {RegisterPNRejectException.class},
      include = {TechnicalException.class},
      maxAttemptsExpression = "#{${gateway.pn.maxAttempts}}",
      backoff = @Backoff(delayExpression = "#{${gateway.pn.backOffDelay}}"))
  public void registerPN(TemporaryStorageDeclaration tsd) {
    try {
      String frn = plugin.registerPN(pnRequestBuilder.buildRegisterPNRequest(tsd));
      tsd.setLinkedPnFrn(frn);
    } catch (RegisterPNRejectException ex) {
      log.debug(ex.getMessage());
    }
  }

  @Recover
  public void registerPnFallbackMethod(Exception exception, TemporaryStorageDeclaration tsd) {
    log.debug(exception.getMessage());
    tsd.setLinkedPnFrn(null);
  }

  @Traced
  public void linkPN(TemporaryStorageDeclaration tsd) {
    PNLinkRequest pnLinkRequest =
        PNLinkRequest.builder()
            .messageHeader(buildHeader(tsd))
            .frn(tsd.getLinkedPnFrn())
            .mrn(tsd.getReferenceNumber().getMrn().getMrnNumber())
            .build();
    queueSender.publishMessage(pnGatewayConfig.getPnLinkQueue(), pnLinkRequest);
  }

  @Traced
  public void sendActivationResult(
      TemporaryStorageDeclaration tsd,
      TSDActivationRequest activateRequest,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    ActivationResultDTO messageDTO =
        activationResultBuilder.buildActivationResultRequest(activateRequest, tsd, violations);
    if (tsd != null && (violations == null || !hasErrorCodes(getErrorCode(violations)))) {
      saveMessageExchange(messageDTO, ACTIVATION_RESULT_MESSAGE, tsd);
    }
    queueSender.publishMessage(pnGatewayConfig.getPnActivationResultQueue(), messageDTO);
  }

  private MessageHeaderDTO buildHeader(TemporaryStorageDeclaration tsd) {
    return MessageHeaderDTO.builder()
        .sender(tsdConfig.getTsdSystemName())
        .correlationId(
            null != tsd.getMessageInformation()
                ? tsd.getMessageInformation().getCorrelationID()
                : null)
        .originalSender(
            null != tsd.getMessageInformation() ? tsd.getMessageInformation().getSender() : null)
        .recipient(tsdConfig.getPnSystemName())
        .messageTimestamp(
            DateTimeFormatter.ofPattern(MESSAGE_TIMESTAMP_FORMAT)
                .format(Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime()))
        .refToMessageId(
            null != tsd.getMessageInformation()
                ? (tsd.getMessageInformation().getMessageId())
                : null)
        .messageId(correlationIdGenerator.generateCorrelationID())
        .languageCode(
            null != tsd.getMessageInformation()
                ? tsd.getMessageInformation().getLanguageCode()
                : null)
        .build();
  }

  private void saveMessageExchange(
      ActivationResultDTO message, String type, TemporaryStorageDeclaration declaration) {
    MessageExchange messageExchange =
        MessageExchange.builder()
            .messageId(message.getMessageHeader().getMessageId())
            .messageTimestamp(dateUtil.getCurentSystemDate())
            .messageType(type)
            .declaration(declaration)
            .build();
    messageExchangeRepository.save(messageExchange);
  }

  private String getErrorCode(Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    Optional<ConstraintViolation<TemporaryStorageDeclaration>> violation =
        violations.stream().filter(x -> null != x.getMessageTemplate()).findAny();

    if (violation.isPresent()) {
      return violation.get().getMessageTemplate();
    }
    return null;
  }

  /**
   * This method return boolean if ErrorCode contains TSPNESXXR0307, TSPNESXXR0308. We only register
   * message exchange if tsd activation contains errors different from these.
   *
   * @param error
   * @return
   */
  private boolean hasErrorCodes(String error) {
    return error != null
        && (error.contains(ErrorCode.TSPNESXXR0307.name())
            || error.contains(ErrorCode.TSPNESXXR0308.name()));
  }
}
