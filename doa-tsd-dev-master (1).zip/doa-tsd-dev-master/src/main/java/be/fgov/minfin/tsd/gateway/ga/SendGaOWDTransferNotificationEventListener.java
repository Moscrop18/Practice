/*
 * @(#) be.fgov.minfin.tsd.gateway.ga.SendGaOWDTransferNotificationEventListener.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties
 * or made public without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.ga;

import static be.fgov.minfin.tsd.gateway.ga.GoodsAccountingGatewayConfig.SEND_GA_OWD_TRANSFER_NOTIFICATION_CONCURRENCY;
import static be.fgov.minfin.tsd.gateway.ga.GoodsAccountingGatewayConfig.SEND_GA_OWD_TRANSFER_NOTIFICATION_QUEUE;

import be.fgov.minfin.libdoa.amqp.transactional.AbstractRetryingQueueListener;
import be.fgov.minfin.tsd.gateway.ga.message.GaOWDTransferNotificationMessage;
import be.fgov.minfin.tsd.gateway.ga.plugin.GoodsAccountingGatewayPlugin;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

/**
 * This class will act as listener for GAOffwritableDocumentQueue. It will Asynchronously respond to
 * the GA system
 */
@Component
public class SendGaOWDTransferNotificationEventListener extends AbstractRetryingQueueListener {

  static final String LISTENER_ID = "send-ga-owd-transfer-notification-request";

  private final GoodsAccountingGatewayPlugin gaGatewayPlugin;

  public SendGaOWDTransferNotificationEventListener(
      GoodsAccountingGatewayConfig gaGatewayConfig, GoodsAccountingGatewayPlugin gaGatewayPlugin) {

    super(gaGatewayConfig.getSendGaOWDTransferNotificationQueue());
    this.gaGatewayPlugin = gaGatewayPlugin;
  }

  /** Receives message from queue for sending to GA */
  @RabbitListener(
      id = LISTENER_ID,
      queues = SEND_GA_OWD_TRANSFER_NOTIFICATION_QUEUE,
      concurrency = SEND_GA_OWD_TRANSFER_NOTIFICATION_CONCURRENCY)
  public void processSendGaOWDTransferNotificationRequest(
      @Payload GaOWDTransferNotificationMessage gaOWDTransferNotificationMessage, Message message) {

    gaGatewayPlugin.sendGaOWDTransferNotification(gaOWDTransferNotificationMessage);
  }
}
