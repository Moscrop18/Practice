/*
 * @(#) be.fgov.minfin.tsd.domain.repository.RiskAnalysisRequestRepository.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.repository;

import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.risk.RiskAnalysisRequest;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface RiskAnalysisRequestRepository extends JpaRepository<RiskAnalysisRequest, Long> {

  Optional<RiskAnalysisRequest> findFirstByDeclarationOrderByTimestampDesc(
      TemporaryStorageDeclaration tsd);

  List<RiskAnalysisRequest> findByReferenceContaining(String crnNumber);

  @Query(
      value =
          "select rar from RiskAnalysisRequest rar where rar.reference=:reference order by rar.timestamp desc")
  List<RiskAnalysisRequest> findByReferenceOrderByTimestamp(String reference);

  Optional<RiskAnalysisRequest> findFirstByDeclarationAndCategoryOrderByTimestampDesc(
      TemporaryStorageDeclaration tsd, String category);
}
