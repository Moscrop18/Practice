/*
 * @(#) be.fgov.minfin.tsd.domain.validation.validator.ArrivalTransportMeansValidator.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation.validator;

import be.fgov.minfin.tsd.domain.model.consignment.ArrivalTransportMeans;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.springframework.stereotype.Component;

@Component
public class ArrivalTransportMeansValidator extends BaseConstraintValidator
    implements ConstraintValidator<ValidateBusinessRules, ArrivalTransportMeans> {
  private static final String INDENTIFICATION_NUMBER = "identificationNumber";

  @Override
  public boolean isValid(ArrivalTransportMeans tsd, ConstraintValidatorContext context) {
    if (null != tsd) {
      Integer typeOfIdentiofication = tsd.getTypeOfIdentification();
      String imoNumber = tsd.getIdentificationNumber();
      if (typeOfIdentiofication == 10) {
        return checkDigit(imoNumber, context);
      } else if (typeOfIdentiofication == 80) {
        return checkImoNumberLength(imoNumber, context);
      }
    }
    return true;
  }

  private boolean checkDigit(String imoNumber, ConstraintValidatorContext context) {
    boolean isValid = false;
    String substringImo = imoNumber.substring(0, 3);
    if (substringImo.equals("IMO")) {
      String imoDigits = imoNumber.substring(3, imoNumber.length());
      int sum = 0;
      for (int i = 1; i < imoDigits.length() + 1; i++) {
        int j = Character.digit(imoDigits.charAt(i - 1), 10);
        sum += sum(i, j);
      }
      String sumString = String.valueOf(sum);
      String sumLastDigit = sumString.substring(sumString.length() - 1);
      if (imoNumber.endsWith(sumLastDigit)) {
        isValid = true;
      }
    }
    if (!isValid) {
      addViolation(
          context,
          be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode.TSPNESXXR0010,
          INDENTIFICATION_NUMBER);
    }
    return isValid;
  }

  private int sum(int position, int digit) {
    if (position < 1 || position > 6) return 0;
    else return (8 - position) * digit;
  }

  private boolean checkImoNumberLength(String imoNumber, ConstraintValidatorContext context) {
    boolean isValid = true;
    if (imoNumber.length() != 8) {
      isValid = false;
    }

    if (!isValid) {
      addViolation(
          context,
          be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode.TSPNESXXR0011,
          INDENTIFICATION_NUMBER);
    }
    return isValid;
  }
}
