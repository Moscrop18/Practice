/*
 * @(#)be.fgov.minfin.tsd.domain.model.consignment.AdditionalReference
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model.consignment;

import be.fgov.minfin.tsd.domain.validation.annotation.CodeList;
import be.fgov.minfin.tsd.domain.validation.annotation.group.DeconsolidationNotificationValidatorGroup;
import be.fgov.minfin.tsd.domain.validation.annotation.group.NonDraftTSD;
import be.fgov.minfin.tsd.domain.validation.codelist.TSDCodeLists;
import com.fasterxml.jackson.annotation.JsonBackReference;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.groups.Default;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "ADDITIONAL_REFERENCE")
@EqualsAndHashCode(exclude = {"consignmentItem", "consignment"})
public class AdditionalReference {
  @GeneratedValue(generator = "ADDITIONAL_REFERENCE_SEQ")
  @SequenceGenerator(name = "ADDITIONAL_REFERENCE_SEQ", sequenceName = "ADDITIONAL_REFERENCE_SEQ")
  @Id
  private Long id;

  private String referenceNumber;

  @Column(columnDefinition = "char")
  @NotNull(groups = NonDraftTSD.class)
  private @CodeList(
      value = TSDCodeLists.CL380,
      groups = {Default.class, DeconsolidationNotificationValidatorGroup.class}) String type;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "CONSIGNMENT_ID")
  @JsonBackReference(value = "consignment")
  private Consignment consignment;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "CONSIGNMENT_ITEM_ID")
  @JsonBackReference(value = "consignmentItem")
  private ConsignmentItem consignmentItem;
}
