/*
 * @(#)be.fgov.minfin.tsd.domain.model.MessageInformation.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model;

import be.fgov.minfin.libdoa.commons.lang.Now;
import be.fgov.minfin.tsd.domain.converter.MessageInformationSourceConverter;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author GauravMitra
 */
// TO Do this class will be finalize when enity model will be finalize
@Getter
@Setter
@ToString(callSuper = true)
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "MESSAGE_INFORMATION")
@EqualsAndHashCode(exclude = {"declaration"})
public class MessageInformation {
  @GeneratedValue(generator = "MI_SEQ")
  @SequenceGenerator(name = "MI_SEQ", sequenceName = "MI_SEQ")
  @Id
  private Long id;

  private String sender;

  @Column(name = "CORRELATION_ID")
  private String correlationID;

  private String languageCode;
  private LocalDateTime receptionTimestamp;
  private LocalDateTime messageTimestamp;
  private String originalSender;
  private String refToMessageId;
  private String messageId;

  @Column(name = "SOURCE", columnDefinition = "SMALLINT")
  @Convert(converter = MessageInformationSourceConverter.class)
  private MessageInformationSource source;

  /**
   * this method is used for building message information for UI flow
   *
   * @param correlationID
   * @return
   */
  public static MessageInformation buildMessageInformation(String correlationID) {
    return MessageInformation.builder()
        .source(MessageInformationSource.UI)
        .correlationID(correlationID)
        .receptionTimestamp(Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime())
        .build();
  }
}
