package be.fgov.minfin.tsd.gateway.eo.api;

import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonRootName("activationError")
public class ActivationErrorDTO {

  private Integer sequenceNumber;

  private String errorReason;

  private String remarks;
}
