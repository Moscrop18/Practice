/*
 * @(#)be.fgov.minfin.tsd.domain.model.consignment.Consignment
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model.consignment;

import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import be.fgov.minfin.tsd.domain.validation.annotation.group.CombinedTSDValidatorGroup;
import be.fgov.minfin.tsd.domain.validation.annotation.group.NonDraftTSD;
import javax.persistence.CascadeType;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@Embeddable
@ValidateBusinessRules
public class ConsignmentHeader {
  @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "DECLARED_LOCATION_OF_GOODS_ID")
  @Valid
  @NotNull(groups = CombinedTSDValidatorGroup.class)
  private LocationOfGoods decalaredlocationOfGoods;

  @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "PRESENTED_LOCATION_OF_GOODS_ID")
  private LocationOfGoods presentedlocationOfGoods;

  private @Valid @Embedded Warehouse warehouse;
  private @Valid @Embedded Location placeOfUnloading;

  @NotNull(groups = NonDraftTSD.class)
  private @Valid @Embedded ArrivalTransportMeans arrivalTransportMeans;

  @NotNull(groups = CombinedTSDValidatorGroup.class)
  private @Valid @Embedded Carrier carrier;
}
