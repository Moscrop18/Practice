/*
 * @(#) be.fgov.minfin.tsd.gateway.ga.GoodsAccountingGateway.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.ga;

import static be.fgov.minfin.tsd.constant.MessageNameConstant.DECONSOLIDATE_OFFWRITABLE_DOCUMENT;
import static be.fgov.minfin.tsd.constant.MessageNameConstant.SEND_GA_OWD_TRANSFER_NOTIFICATION;
import static be.fgov.minfin.tsd.constant.MessageNameConstant.SEND_OFFWRITABLE_DOCUMENT;
import static be.fgov.minfin.tsd.util.DateFormatUtil.MESSAGE_DATE_TIME_FORMAT;

import be.fgov.minfin.libdoa.amqp.transactional.QueueSender;
import be.fgov.minfin.libdoa.commons.lang.Now;
import be.fgov.minfin.libdoa.exception.TechnicalException;
import be.fgov.minfin.libdoa.goods.accounting.client.api.owd.LockOffwritableDocumentStatusReason;
import be.fgov.minfin.shared.tracing.Traced;
import be.fgov.minfin.tsd.config.TSDConfig;
import be.fgov.minfin.tsd.domain.model.MessageExchange;
import be.fgov.minfin.tsd.domain.model.MessageInformation;
import be.fgov.minfin.tsd.domain.model.StatusHistory;
import be.fgov.minfin.tsd.domain.model.StatusHistoryReason;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.TransferNotification;
import be.fgov.minfin.tsd.domain.repository.MessageExchangeRepository;
import be.fgov.minfin.tsd.domain.repository.StatusHistoryRepository;
import be.fgov.minfin.tsd.domain.validation.CustomViolation;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import be.fgov.minfin.tsd.gateway.ga.exception.LockOffwritableDocumentException;
import be.fgov.minfin.tsd.gateway.ga.message.GaOWDTransferNotificationMessage;
import be.fgov.minfin.tsd.gateway.ga.message.LockOffwritableDocumentRequest;
import be.fgov.minfin.tsd.gateway.ga.message.MessageHeader;
import be.fgov.minfin.tsd.gateway.ga.message.OffwritableDocument;
import be.fgov.minfin.tsd.gateway.ga.plugin.GoodsAccountingGatewayPlugin;
import be.fgov.minfin.tsd.resource.api.ui.ValidationErrorDTO;
import be.fgov.minfin.tsd.resource.generator.CorrelationIdGenerator;
import be.fgov.minfin.tsd.util.DateUtil;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.validation.ConstraintViolation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;

/** This class is used as gateway component for integrating with the GA system. */
@Component
@Slf4j
@RequiredArgsConstructor
public class GoodsAccountingGateway {

  private final TSDConfig tsdConfig;
  private final QueueSender queueSender;
  private final GoodsAccountingGatewayConfig gaGatewayConfig;
  private final DateUtil dateUtil;
  private final CorrelationIdGenerator correlationIdGenerator;

  private static final String MASTER_CONSIGNMENT = "masterConsignment";
  private static final String OFFWRITABLE_GOODS_ITEM_GROUPING = "offwritableGoodsItemGrouping";
  private final MessageExchangeRepository messageExchangeRepository;
  private final StatusHistoryRepository statusHistoryRepository;

  private final GoodsAccountingGatewayPlugin gaGatewayPlugin;
  private static final String MRN = "mrn";

  public void sendOffWritableDocument(TemporaryStorageDeclaration tsd) {
    OffwritableDocument offwritableDocument =
        OffwritableDocument.builder()
            .declaration(tsd)
            .messageHeader(buildMessageHeader(tsd.getMessageInformation()))
            .build();
    saveMessageExchange(
        SEND_OFFWRITABLE_DOCUMENT, tsd, offwritableDocument.getMessageHeader().getMessageId());
    queueSender.publishMessage(gaGatewayConfig.getSendGaOffWritableQueue(), offwritableDocument);
  }

  public void sendDeconsolidationOffwritableDocument(TemporaryStorageDeclaration deconTSD) {
    OffwritableDocument offwritableDocument =
        OffwritableDocument.builder()
            .declaration(deconTSD)
            .messageHeader(buildMessageHeader(deconTSD.getMessageInformation()))
            .build();
    saveMessageExchange(
        DECONSOLIDATE_OFFWRITABLE_DOCUMENT,
        deconTSD,
        offwritableDocument.getMessageHeader().getMessageId());
    queueSender.publishMessage(
        gaGatewayConfig.getDeconsolidateGaOffwritableQueue(), offwritableDocument);
  }

  private MessageHeader buildMessageHeader(MessageInformation messageInformation) {
    return MessageHeader.builder()
        .callbackUrl(tsdConfig.getGaCallbackUrl())
        .sender(tsdConfig.getTsdSystemName())
        .recipient(tsdConfig.getGaSystemName())
        .messageTimestamp(
            DateTimeFormatter.ofPattern(MESSAGE_DATE_TIME_FORMAT)
                .format(Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime()))
        .messageId(correlationIdGenerator.generateCorrelationID())
        .correlationId(null != messageInformation ? messageInformation.getCorrelationID() : null)
        .build();
  }

  private void saveMessageExchange(
      String messageType, TemporaryStorageDeclaration declaration, String messageId) {
    MessageExchange messageExchange =
        MessageExchange.builder()
            .messageId(messageId)
            .messageTimestamp(dateUtil.getCurentSystemDate())
            .messageType(messageType)
            .declaration(declaration)
            .build();
    messageExchangeRepository.save(messageExchange);
  }

  public void sendGaOWDTransferNotification(
      TransferNotification transferNotification, TemporaryStorageDeclaration clonedTSD) {

    GaOWDTransferNotificationMessage gaOWDTransferNotificationMessage =
        GaOWDTransferNotificationMessage.builder()
            .messageHeader(buildMessageHeader(clonedTSD.getMessageInformation()))
            .mrn(clonedTSD.getReferenceNumber().getMrn().getMrnNumber())
            .source("G4")
            .status(clonedTSD.getCurrentStatus())
            .statusReason(getGaOWDTransferNotiStatusReason(clonedTSD.getReferenceNumber().getId()))
            .riskAndControlStatus(clonedTSD.getCurrentRiskControlStatus())
            .version(clonedTSD.getCurrentVersion())
            .transferNotification(transferNotification)
            .build();

    saveMessageExchange(
        SEND_GA_OWD_TRANSFER_NOTIFICATION,
        clonedTSD,
        correlationIdGenerator.generateCorrelationID());

    queueSender.publishMessage(
        gaGatewayConfig.getSendGaOWDTransferNotificationQueue(), gaOWDTransferNotificationMessage);
  }

  private StatusHistoryReason getGaOWDTransferNotiStatusReason(Long referenceNumberId) {

    StatusHistory statusHistory =
        statusHistoryRepository.findTopByReferenceNumberIdOrderByTimestampDesc(referenceNumberId);

    if (statusHistory == null) {
      return null;
    } else {
      return statusHistory.getReason();
    }
  }

  @Traced
  @Retryable(
      exclude = {LockOffwritableDocumentException.class},
      include = {TechnicalException.class},
      maxAttemptsExpression = "#{${gateway.ga.maxAttempts}}",
      backoff = @Backoff(delayExpression = "#{${gateway.ga.backOffDelay}}"))
  public <T> Set<ConstraintViolation<T>> lockOffwritableDocument(
      TransferNotification transferNotification,
      String mrn,
      LockOffwritableDocumentStatusReason reason) {

    LockOffwritableDocumentRequest lockOffwritableDocumentRequest =
        LockOffwritableDocumentRequest.builder()
            .reason(reason)
            .mrn(mrn)
            .transferNotification(transferNotification)
            .build();

    Set<ConstraintViolation<T>> violations = new HashSet<>();
    try {
      List<ValidationErrorDTO> validationErrors =
          gaGatewayPlugin.lockOffwritableDocument(lockOffwritableDocumentRequest);
      if (CollectionUtils.isEmpty(validationErrors)) {
        return violations;
      } else {
        getViolationFromResponse(
            lockOffwritableDocumentRequest, violations, validationErrors, transferNotification);
      }
    } catch (LockOffwritableDocumentException e) {
      log.debug(
          "LockOffwritableDocumentException during lock offwritable document GA Request "
              + e.getMessage());
    }
    return violations;
  }

  private <T> void getViolationFromResponse(
      LockOffwritableDocumentRequest lockoffDocument,
      Set<ConstraintViolation<T>> violations,
      List<ValidationErrorDTO> errors,
      TransferNotification tn) {

    if (errors.stream()
        .anyMatch(error -> error.getReason().contains("T0005"))) { // In case of no response.
      violations.add(new CustomViolation<>(ErrorCode.TSPNESXXT0005, MRN));
    }

    if (errors.stream().anyMatch(error -> error.getReason().contains("0009"))) {

      violations.add(new CustomViolation<>(ErrorCode.TSPNESXXT0005, MRN));
    } else {
      if (lockoffDocument.getReason() == LockOffwritableDocumentStatusReason.AMENDMENT) {
        violations.add(new CustomViolation<>(ErrorCode.TSPNESXXR0137, MRN));
      } else if (lockoffDocument.getReason() == LockOffwritableDocumentStatusReason.TRANSFER) {
        checkViolationsForTransferNotification(errors, tn, violations);
      } else if (lockoffDocument.getReason()
          == LockOffwritableDocumentStatusReason.DECONSOLIDATION) {
        checkValidationErrorsForDeconsolidation(violations, errors);
      }
    }
  }

  private <T> void checkViolationsForTransferNotification(
      List<ValidationErrorDTO> errors,
      TransferNotification tn,
      Set<ConstraintViolation<T>> violations) {
    for (ValidationErrorDTO error : errors) {
      if (error.getReason().contains("R0353") || error.getReason().contains("R0355")) {
        violations.add(
            new CustomViolation<>(ErrorCode.TSPNESXXR0153, getConsignmentPath(tn, error)));
      } else {
        violations.add(new CustomViolation<>(ErrorCode.TSPNESXXR0145, MRN));
      }
    }
  }

  private <T> void checkValidationErrorsForDeconsolidation(
      Set<ConstraintViolation<T>> violations, List<ValidationErrorDTO> errors) {
    boolean isR0356Exist = false;
    boolean isR0356NotExist = false;
    for (ValidationErrorDTO er : errors) {
      if (isR0356Exist && isR0356NotExist) {
        break;
      }
      if (er.getReason().contains("R0356") && !isR0356Exist) {
        violations.add(new CustomViolation<>(ErrorCode.TSPNESXXR0154, MASTER_CONSIGNMENT));
        isR0356Exist = true;
      } else if (!er.getReason().contains("R0356") && !isR0356NotExist) {
        violations.add(new CustomViolation<>(ErrorCode.TSPNESXXR0147, MRN));
        isR0356NotExist = true;
      }
    }
  }

  @Recover
  public Set<ConstraintViolation<TemporaryStorageDeclaration>>
      lockOffwritableDocumentFallbackMethod(
          Exception exception, TransferNotification transferNotification) {
    log.debug(exception.getMessage());
    return new HashSet<>();
  }

  private char getTheIndexFromPointer(ValidationErrorDTO error) {
    char index = 0;
    if (error.getPointer().contains(OFFWRITABLE_GOODS_ITEM_GROUPING)) {
      index = error.getPointer().charAt(29);
    }
    return index;
  }

  private String getConsignmentPath(TransferNotification tn, ValidationErrorDTO error) {
    String consignment = "consignment";

    if (null != tn.getMasterConsignment()) {
      consignment = MASTER_CONSIGNMENT;
    } else if (CollectionUtils.isNotEmpty(tn.getHouseConsignments())) {
      consignment = "houseConsignment" + "[" + getTheIndexFromPointer(error) + "]";
    }
    return consignment;
  }
}
