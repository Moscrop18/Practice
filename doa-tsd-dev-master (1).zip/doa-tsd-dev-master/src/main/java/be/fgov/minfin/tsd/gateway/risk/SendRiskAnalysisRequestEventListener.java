/*
 * @(#) be.fgov.minfin.tsd.gateway.risk.SendRiskAnalysisRequestEventListener.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.risk;

import static be.fgov.minfin.tsd.gateway.risk.RiskAnalysisGatewayConfig.SEND_RISK_ANALYSIS_CONCURRENCY_VALUE;
import static be.fgov.minfin.tsd.gateway.risk.RiskAnalysisGatewayConfig.SEND_RISK_ANALYSIS_QUEUE;

import be.fgov.minfin.libdoa.amqp.transactional.AbstractRetryingQueueListener;
import be.fgov.minfin.tsd.gateway.risk.message.SendTSDRiskAnalysis;
import be.fgov.minfin.tsd.gateway.risk.plugin.RiskAnalysisGatewayPlugin;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

@Component
public class SendRiskAnalysisRequestEventListener extends AbstractRetryingQueueListener {

  static final String LISTENER_ID = "send-risk-analysis-request";

  private final RiskAnalysisGatewayPlugin plugin;

  public SendRiskAnalysisRequestEventListener(
      RiskAnalysisGatewayConfig riskAnalysisConfig, RiskAnalysisGatewayPlugin plugin) {
    super(riskAnalysisConfig.getSendRiskAnalysisQueue());
    this.plugin = plugin;
  }

  /** Receives message from queue for sending message for risk analysis */
  @RabbitListener(
      id = LISTENER_ID,
      queues = SEND_RISK_ANALYSIS_QUEUE,
      concurrency = SEND_RISK_ANALYSIS_CONCURRENCY_VALUE)
  public void processSendRiskAnalysisRequest(
      @Payload SendTSDRiskAnalysis riskAnalysisRequest, Message message) {
    plugin.sendRiskAnalysisRequest(riskAnalysisRequest);
  }
}
