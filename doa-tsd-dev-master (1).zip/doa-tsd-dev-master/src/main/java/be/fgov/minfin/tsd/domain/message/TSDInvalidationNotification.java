package be.fgov.minfin.tsd.domain.message;

import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.party.Party;
import be.fgov.minfin.tsd.domain.model.party.Representative;
import lombok.Builder;
import lombok.Value;

@Value
@Builder(toBuilder = true)
public class TSDInvalidationNotification {
  private MessageHeader messageHeader;
  private String crn;
  private Integer invalidationInitiatedByCustoms;
  private String notificationDate;
  private String remarks;
  private Party declarant;
  private Representative representative;
  private TemporaryStorageDeclaration declaration;
}
