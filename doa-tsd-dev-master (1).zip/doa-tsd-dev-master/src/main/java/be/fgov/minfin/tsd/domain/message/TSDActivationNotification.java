package be.fgov.minfin.tsd.domain.message;

import be.fgov.minfin.tsd.domain.model.CustomsOffice;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import java.time.LocalDateTime;
import java.util.List;
import lombok.Builder;
import lombok.Value;

@Value
@Builder(toBuilder = true)
public class TSDActivationNotification {
  private MessageHeader messageHeader;
  private List<Error> activationError;
  private TemporaryStorageDeclaration declaration;
  private LocalDateTime notificationDate;

  private String linkedPnFrn;

  private CustomsOffice customsOfficeOfPresentation;
  private LocalDateTime dateAndTimeOfPresentationOfTheGoods;
}
