/*
 * @(#)be.fgov.minfin.tsd.domain.validation.ActivationValidator
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation;

import be.fgov.minfin.tsd.domain.model.TSDActivationRequest;
import be.fgov.minfin.tsd.domain.model.TSDStatus;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.consignment.Receptacle;
import be.fgov.minfin.tsd.domain.model.consignment.TSDActivationRequestHouseConsignment;
import be.fgov.minfin.tsd.domain.model.consignment.TSDActivationRequestMasterConsignment;
import be.fgov.minfin.tsd.domain.model.consignment.TransportDocument;
import be.fgov.minfin.tsd.domain.model.consignment.TransportEquipment;
import be.fgov.minfin.tsd.domain.repository.TSDRepository;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import be.fgov.minfin.tsd.domain.validation.exception.TSDActivationException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import javax.validation.ConstraintViolation;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

/**
 * This class validates if one TSD can be activated based on consignment / previous document and
 * location of goods data present in the PN
 *
 * @author NamrataGupta
 */
@Component
@RequiredArgsConstructor
public class ActivationValidator {

  private final TSDRepository tsdRepository;

  /**
   * This method is to validate that TSD contains similar TransportDocument, Receptacles and
   * TransportEquipments
   *
   * @param activateRequest
   * @param tsd
   * @throws TSDActivationException
   */
  public void validateTSDActivationForMasterConsignment(
      TSDActivationRequest activateRequest, TemporaryStorageDeclaration tsd)
      throws TSDActivationException {
    Set<ConstraintViolation<TemporaryStorageDeclaration>> violations = new HashSet<>();

    TSDActivationRequestMasterConsignment activateMasterCons =
        activateRequest.getMasterConsignment();

    validateTransDocReferenceNumber(activateRequest, tsd, violations, activateMasterCons);

    validateTransportEquipments(tsd, violations, activateMasterCons);

    validateReceptacles(tsd, violations, activateMasterCons);
  }

  /**
   * This method is to validate that TSD contains similar TransportDocument, Receptacles and
   * TransportEquipments
   *
   * @param activateRequest
   * @param tsd
   * @throws TSDActivationException
   */
  public void validateTSDActivationForHouseConsignment(
      TSDActivationRequest activateRequest, TemporaryStorageDeclaration tsd)
      throws TSDActivationException {
    Set<ConstraintViolation<TemporaryStorageDeclaration>> violations = new HashSet<>();
    if (tsd.getCurrentStatus() != TSDStatus.PRELODGED
        || tsd.getExpirationTimestamp().isBefore(activateRequest.getReceptionTimestamp())
        || tsd.getExpirationTimestamp().isEqual(activateRequest.getReceptionTimestamp())) {
      addViolation(violations, ErrorCode.TSPNESXXR0308);
      throw new TSDActivationException(violations, tsd);
    }

    List<String> referenceNumberList =
        tsdRepository.getReferenceNumberOfTransportDocumentLinkedWithHouseConsignments(tsd.getId());

    List<String> transportDocList =
        activateRequest.getHouseConsignments().stream()
            .filter(x -> null != x.getTransportDocument())
            .map(TSDActivationRequestHouseConsignment::getTransportDocument)
            .map(TransportDocument::getReferenceNumber)
            .collect(Collectors.toList());

    if ((CollectionUtils.isEmpty(referenceNumberList) && !CollectionUtils.isEmpty(transportDocList))
        || !referenceNumberList.equals(transportDocList)) {
      addViolation(violations, ErrorCode.TSPNESXXR0314);
      throw new TSDActivationException(violations, tsd);
    }
  }

  /**
   * This method whether TSD contain other Receptacles as part of the Presentation Notification.
   *
   * @param tsd
   * @param violations
   * @param activateMasterCons
   * @throws TSDActivationException
   */
  private void validateReceptacles(
      TemporaryStorageDeclaration tsd,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations,
      TSDActivationRequestMasterConsignment activateMasterCons)
      throws TSDActivationException {
    if (!CollectionUtils.isEmpty(activateMasterCons.getReceptacle())) {
      List<Long> receptacleList =
          tsdRepository.getMasterConsignmentItemsLinkedWithReceptacle(tsd.getId());
      if (CollectionUtils.isEmpty(receptacleList)) {
        addViolation(violations, ErrorCode.TSPNESXXR0309);
        throw new TSDActivationException(violations, tsd);
      }

      List<String> idenfNumber = tsdRepository.getIdentificationNumbersOfReceptacles(tsd.getId());

      Set<String> activationReceptacleIndfnNumber =
          activateMasterCons.getReceptacle().stream()
              .map(Receptacle::getIdentificationNumber)
              .collect(Collectors.toSet());

      if (CollectionUtils.isEmpty(idenfNumber)
          || !(CollectionUtils.containsAny(idenfNumber, activationReceptacleIndfnNumber))) {
        addViolation(violations, ErrorCode.TSPNESXXR0311);
        throw new TSDActivationException(violations, tsd);
      }
    }
  }

  /**
   * This method validate if TSD TransportEquipment is not empty
   *
   * @param tsd
   * @param violations
   * @param activateMasterCons
   * @throws TSDActivationException
   */
  private void validateTransportEquipments(
      TemporaryStorageDeclaration tsd,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations,
      TSDActivationRequestMasterConsignment activateMasterCons)
      throws TSDActivationException {
    if (!CollectionUtils.isEmpty(activateMasterCons.getTransportEquipment())) {
      List<Long> masterTransEquipmentList =
          tsdRepository.getMasterConsignmentItemsLinkedWithTransportEquipment(tsd.getId());

      if (!CollectionUtils.isEmpty(masterTransEquipmentList)) {
        addViolation(violations, ErrorCode.TSPNESXXR0309);
        throw new TSDActivationException(violations, tsd);
      }

      List<Long> houseTransEquipmentList =
          tsdRepository.getHouseConsignmentItemsLinkedWithTransportEquipment(tsd.getId());

      if (!CollectionUtils.isEmpty(houseTransEquipmentList)) {
        addViolation(violations, ErrorCode.TSPNESXXR0310);
        throw new TSDActivationException(violations, tsd);
      }

      validateTransEquipContainerNumber(violations, activateMasterCons, tsd);
    }
  }

  /**
   * This method validates whether TSD contain other Transport equipments as part of the
   * Presentation Notification.
   *
   * @param violations
   * @param activateMasterCons
   * @param masterTransEquipmentList
   * @throws TSDActivationException
   */
  private void validateTransEquipContainerNumber(
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations,
      TSDActivationRequestMasterConsignment activateMasterCons,
      TemporaryStorageDeclaration tsd)
      throws TSDActivationException {
    Set<String> activationContainerNumber =
        activateMasterCons.getTransportEquipment().stream()
            .map(TransportEquipment::getContainerIdentificationNumber)
            .collect(Collectors.toSet());

    List<String> containerNumber = tsdRepository.getContainerIDsOfTransportEquipments(tsd.getId());

    if (CollectionUtils.isEmpty(containerNumber)
        || !(CollectionUtils.containsAny(activationContainerNumber, containerNumber))) {
      addViolation(violations, ErrorCode.TSPNESXXR0311);
      throw new TSDActivationException(violations, tsd);
    }
  }

  /**
   * This method validates whether TSD contain other Transport documents as part of the Presentation
   * Notification
   *
   * @param activateRequest
   * @param tsd
   * @param violations
   * @param activateMasterCons
   * @throws TSDActivationException
   */
  private void validateTransDocReferenceNumber(
      TSDActivationRequest activateRequest,
      TemporaryStorageDeclaration tsd,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations,
      TSDActivationRequestMasterConsignment activateMasterCons)
      throws TSDActivationException {
    if (activateMasterCons != null
        && activateMasterCons.getTransportDocument() != null
        && (!activateMasterCons
                .getTransportDocument()
                .getReferenceNumber()
                .equals(tsd.getMasterConsignment().getTransportDocument().getReferenceNumber())
            || tsd.getCurrentStatus() != TSDStatus.PRELODGED
            || tsd.getExpirationTimestamp().isBefore(activateRequest.getReceptionTimestamp())
            || tsd.getExpirationTimestamp().isEqual(activateRequest.getReceptionTimestamp()))) {
      addViolation(violations, ErrorCode.TSPNESXXR0308);
      throw new TSDActivationException(violations, tsd);
    }
  }

  private void addViolation(
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations, ErrorCode errorCode) {
    CustomViolation<TemporaryStorageDeclaration> violation = new CustomViolation<>(errorCode, null);
    violations.add(violation);
  }
}
