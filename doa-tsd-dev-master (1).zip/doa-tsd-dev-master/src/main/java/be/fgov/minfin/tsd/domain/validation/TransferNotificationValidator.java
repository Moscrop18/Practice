/*
 * @(#) be.fgov.minfin.tsd.domain.validation.TransferNotificationValidator.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties
 * or made public without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation;

import be.fgov.minfin.tsd.domain.model.TSDStatus;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.TransferNotification;
import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentHeader;
import be.fgov.minfin.tsd.domain.model.consignment.LocationOfGoods;
import be.fgov.minfin.tsd.domain.model.consignment.TransportDocument;
import be.fgov.minfin.tsd.domain.validation.annotation.group.TransferNotificationValidatorGroup;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import be.fgov.minfin.tsd.domain.validation.message.MessageType;
import be.fgov.minfin.tsd.domain.validation.plugin.TransferNotificationValidatorPlugin;
import be.fgov.minfin.tsd.domain.validation.resolver.CustomTraversableResolver;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.hibernate.validator.HibernateValidatorFactory;
import org.springframework.stereotype.Component;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;

@RequiredArgsConstructor
@Slf4j
@Component
public class TransferNotificationValidator implements TransferNotificationValidatorPlugin {

  private final LocalValidatorFactoryBean localValidatorFactoryBean;

  private final CustomTraversableResolver customTraversableResolver;

  private static final String MRN = "mrn";

  private static final String CONSIGNMENT_HEADER = "consignmentHeader";

  private static final String CONSIGNMENT_MASTER = "masterConsignment";

  @Override
  public Set<ConstraintViolation<TransferNotification>> validateTransferNotification(
      TransferNotification transferNotification,
      MessageType messageType,
      TemporaryStorageDeclaration currentTSD) {

    Validator validator =
        localValidatorFactoryBean
            .unwrap(HibernateValidatorFactory.class)
            .usingContext()
            .constraintValidatorPayload(messageType)
            .traversableResolver(customTraversableResolver)
            .getValidator();

    Set<ConstraintViolation<TransferNotification>> violations =
        validator.validate(transferNotification, TransferNotificationValidatorGroup.class);

    if (log.isDebugEnabled()) {
      violations.stream()
          .forEach(
              violation ->
                  log.info(
                      "Violation with message {} and path {}",
                      violation.getMessage(),
                      violation.getPropertyPath()));
    }

    if (violations.isEmpty()) {
      violations = new HashSet<>();
    }

    validateTransportDocument(transferNotification, currentTSD, violations);
    validateCurrentTsdTypeOfLocation(currentTSD, violations);
    validateMasterConsignmentTransfer(transferNotification, currentTSD, violations);
    return violations;
  }

  @Override
  public Set<ConstraintViolation<TransferNotification>> validateTransferNotificationCanBeProcessed(
      TransferNotification transferNotification, TemporaryStorageDeclaration currentTSD) {
    Set<ConstraintViolation<TransferNotification>> violations = new HashSet<>();
    if (currentTSD != null) {
      validateTSDCurrentStatus(currentTSD, violations);
      validateMessageReceptionTimestamp(transferNotification, currentTSD, violations);
    } else {
      violations.add(new CustomViolation<>(ErrorCode.TSPNESXXR0135, MRN));
    }
    return violations;
  }

  /**
   * Temporary Storage Declaration (current version) has a different current status than 'ACCEPTED'.
   * has a different Presented Location of Goods/ type of location other than 'B'
   */
  private void validateTSDCurrentStatus(
      TemporaryStorageDeclaration currentTSD,
      Set<ConstraintViolation<TransferNotification>> violations) {
    if (!currentTSD.getCurrentStatus().equals(TSDStatus.ACCEPTED)) {
      violations.add(new CustomViolation<>(ErrorCode.TSPNESXXR0144, MRN));
    }
  }

  /**
   * The Transfer Notification reception timestamp > reception timestamp of the TSD (current version
   * transfer notification)
   */
  private void validateMessageReceptionTimestamp(
      TransferNotification transferNotification,
      TemporaryStorageDeclaration currentTSD,
      Set<ConstraintViolation<TransferNotification>> violations) {
    if (currentTSD.getTransferNotification() != null
        && transferNotification
            .getMessageInformation()
            .getReceptionTimestamp()
            .isBefore(
                currentTSD
                    .getTransferNotification()
                    .getMessageInformation()
                    .getReceptionTimestamp())) {
      violations.add(new CustomViolation<>(ErrorCode.TSPNESXXR0148, MRN));
    }
  }

  private void validateTransportDocument(
      TransferNotification transferNotification,
      TemporaryStorageDeclaration currentTSD,
      Set<ConstraintViolation<TransferNotification>> violations) {

    List<TransportDocument> documentList = new ArrayList<>();

    if (null != transferNotification.getMasterConsignment()) {
      TransportDocument transferNotificationMasterTD =
          transferNotification.getMasterConsignment().getTransportDocument();

      documentList.add(transferNotificationMasterTD);

      if (null != currentTSD.getMasterConsignment()
          && null != currentTSD.getMasterConsignment().getTransportDocument()) {
        if (!currentTSD
            .getMasterConsignment()
            .getTransportDocument()
            .equals(transferNotificationMasterTD)) {
          violations.add(
              new CustomViolation<>(
                  ErrorCode.TSPNESXXR0143, "masterConsignment.transportDocument"));
        }
      } else {
        violations.add(
            new CustomViolation<>(ErrorCode.TSPNESXXR0143, "masterConsignment.transportDocument"));
      }
    }

    if (!CollectionUtils.isEmpty(transferNotification.getHouseConsignments())) {

      Set<TransportDocument> currentTSDHouseTransportDocumentSet = new HashSet<>();

      if (!CollectionUtils.isEmpty(currentTSD.getHouseConsignments())) {
        currentTSD
            .getHouseConsignments()
            .forEach(
                houseConsignment ->
                    currentTSDHouseTransportDocumentSet.add(
                        houseConsignment.getTransportDocument()));
      } else {
        violations.add(
            new CustomViolation<>(ErrorCode.TSPNESXXR0143, "houseConsignments.transportDocument"));
      }

      for (int i = 0; i < transferNotification.getHouseConsignments().size(); i++) {
        TransportDocument transportDocument =
            transferNotification.getHouseConsignments().get(i).getTransportDocument();
        addDocumentToList(
            i, documentList, transportDocument, currentTSDHouseTransportDocumentSet, violations);
      }
    }

    Set<TransportDocument> documentSet = new HashSet<>(documentList);

    if (documentSet.size() < documentList.size()) {
      violations.add(new CustomViolation<>(ErrorCode.TSPNESXXR0048, CONSIGNMENT_HEADER));
    }
  }

  private void validateCurrentTsdTypeOfLocation(
      TemporaryStorageDeclaration currentTSD,
      Set<ConstraintViolation<TransferNotification>> violations) {

    String typeOfLocation =
        Optional.ofNullable(currentTSD.getConsignmentHeader())
            .map(ConsignmentHeader::getPresentedlocationOfGoods)
            .map(LocationOfGoods::getTypeOfLocation)
            .orElse("");
    if (!typeOfLocation.equals("B")) {
      violations.add(new CustomViolation<>(ErrorCode.TSPNESXXR0157, MRN));
    }
  }

  private void addDocumentToList(
      int i,
      List<TransportDocument> documentList,
      TransportDocument transportDocument,
      Set<TransportDocument> currentTSDTransportDocumentSet,
      Set<ConstraintViolation<TransferNotification>> violations) {

    if (null != transportDocument) {

      documentList.add(transportDocument);

      if (!CollectionUtils.isEmpty(currentTSDTransportDocumentSet)
          && !currentTSDTransportDocumentSet.contains(transportDocument)) {
        violations.add(
            new CustomViolation<>(
                ErrorCode.TSPNESXXR0143, "houseConsignments[" + i + "].transportDocument"));
      }
    }
  }

  /**
   * This method is to validate all House Consignments are present at the current Master Consignment
   * location of goods.
   *
   * @param transferNotification
   * @param currentTSD
   * @param violations
   */
  private void validateMasterConsignmentTransfer(
      TransferNotification transferNotification,
      TemporaryStorageDeclaration currentTSD,
      Set<ConstraintViolation<TransferNotification>> violations) {
    if (transferNotification.getMasterConsignment() != null
        && currentTSD.getMasterConsignment() != null
        && CollectionUtils.isNotEmpty(currentTSD.getHouseConsignments())) {
      boolean mismatchHCConLocOfGoodsPresent =
          currentTSD.getHouseConsignments().stream()
              .anyMatch(
                  houseConsignment ->
                      ((houseConsignment.getCurrentConsignmentLocationOfGoods() != null)
                          && ((!Objects.equals(
                                  houseConsignment
                                      .getCurrentConsignmentLocationOfGoods()
                                      .getTransferredLocationOfGoods()
                                      .getTypeOfLocation(),
                                  currentTSD
                                      .getMasterConsignment()
                                      .getCurrentConsignmentLocationOfGoods()
                                      .getTransferredLocationOfGoods()
                                      .getTypeOfLocation()))
                              || (!Objects.equals(
                                  houseConsignment
                                      .getCurrentConsignmentLocationOfGoods()
                                      .getTransferredLocationOfGoods()
                                      .getQualifierOfIdentification(),
                                  currentTSD
                                      .getMasterConsignment()
                                      .getCurrentConsignmentLocationOfGoods()
                                      .getTransferredLocationOfGoods()
                                      .getQualifierOfIdentification()))
                              || (houseConsignment
                                          .getCurrentConsignmentLocationOfGoods()
                                          .getTransferredLocationOfGoods()
                                          .getUnLoCode()
                                      != null
                                  && !Objects.equals(
                                      houseConsignment
                                          .getCurrentConsignmentLocationOfGoods()
                                          .getTransferredLocationOfGoods()
                                          .getUnLoCode(),
                                      currentTSD
                                          .getMasterConsignment()
                                          .getCurrentConsignmentLocationOfGoods()
                                          .getTransferredLocationOfGoods()
                                          .getUnLoCode()))
                              || (!Objects.equals(
                                  houseConsignment
                                      .getCurrentConsignmentLocationOfGoods()
                                      .getWarehouse()
                                      .getType(),
                                  currentTSD
                                      .getMasterConsignment()
                                      .getCurrentConsignmentLocationOfGoods()
                                      .getWarehouse()
                                      .getType()))
                              || (!Objects.equals(
                                  houseConsignment
                                      .getCurrentConsignmentLocationOfGoods()
                                      .getWarehouse()
                                      .getIdentifier(),
                                  currentTSD
                                      .getMasterConsignment()
                                      .getCurrentConsignmentLocationOfGoods()
                                      .getWarehouse()
                                      .getIdentifier())))));
      if (mismatchHCConLocOfGoodsPresent) {
        violations.add(new CustomViolation<>(ErrorCode.TSPNESXXR0150, CONSIGNMENT_MASTER));
      }
    }
  }
}
