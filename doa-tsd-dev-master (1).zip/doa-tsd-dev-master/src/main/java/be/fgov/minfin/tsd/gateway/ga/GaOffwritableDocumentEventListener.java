/*
 * @(#) be.fgov.minfin.tsd.gateway.ga.GaOffwritableDocumentEventListener.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.ga;

import static be.fgov.minfin.tsd.gateway.ga.GoodsAccountingGatewayConfig.OFFWRITABLE_CONCURRENCY_SETTING;
import static be.fgov.minfin.tsd.gateway.ga.GoodsAccountingGatewayConfig.OFFWRITABLE_DOCUMENT_QUEUE;

import be.fgov.minfin.libdoa.amqp.transactional.AbstractRetryingQueueListener;
import be.fgov.minfin.tsd.gateway.ga.message.OffwritableDocument;
import be.fgov.minfin.tsd.gateway.ga.plugin.GoodsAccountingGatewayPlugin;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

/**
 * This class will act as listener for GAOffwritableDocumentQueue. It will Asynchronously respond to
 * the GA system
 */
@Component
public class GaOffwritableDocumentEventListener extends AbstractRetryingQueueListener {
  static final String LISTENER_ID = "process-gaoffwritable-document";

  private final GoodsAccountingGatewayPlugin gaGatewayPlugin;

  public GaOffwritableDocumentEventListener(
      GoodsAccountingGatewayConfig gaGatewayConfig, GoodsAccountingGatewayPlugin gaGatewayPlugin) {

    super(gaGatewayConfig.getSendGaOffWritableQueue());
    this.gaGatewayPlugin = gaGatewayPlugin;
  }

  /** Receives message from queue for sending to GA */
  @RabbitListener(
      id = LISTENER_ID,
      queues = OFFWRITABLE_DOCUMENT_QUEUE,
      concurrency = OFFWRITABLE_CONCURRENCY_SETTING)
  public void processSendGaOffwritableDocument(
      @Payload OffwritableDocument offwritableDocument, Message message) {
    gaGatewayPlugin.sendGAOffwritableDocument(offwritableDocument);
  }
}
