/*
 * @(#) be.fgov.minfin.tsd.domain.message.TSDDeconsolidationNotificationRefusedMessage.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.message;

import be.fgov.minfin.tsd.domain.model.BusinessValidationType;
import be.fgov.minfin.tsd.domain.model.CustomsOffice;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.party.Party;
import be.fgov.minfin.tsd.domain.model.party.Representative;
import java.time.LocalDateTime;
import java.util.List;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class TSDDeconsolidationNotificationRefusedMessage {

  private MessageHeader messageHeader;

  private String lrn;

  private String mrn;

  private String remarks;

  private Party declarant;

  private LocalDateTime notificationDate;

  private BusinessValidationType businessValidationType;

  private Representative representative;

  private CustomsOffice supervisingCustomsOffice;

  private List<Error> error;

  private TemporaryStorageDeclaration declaration;
}
