package be.fgov.minfin.tsd.domain.model;

import be.fgov.minfin.tsd.domain.converter.ReferenceNumberMetadata;
import javax.persistence.Transient;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@EqualsAndHashCode(exclude = {"referenceNumberMetadata"})
public class CRN {

  private String crnNumber;

  /**
   * The received import declaration wrapped inside this class instance so as to get the id (primary
   * key) of the declaration during persist time which is used to generate MRN <code>declaration
   * </code>
   */
  @ToString.Exclude @Transient private ReferenceNumberMetadata referenceNumberMetadata;

  public static CRN of(String crnNumber) {
    CRN crn = new CRN();
    crn.setCrnNumber(crnNumber);
    return crn;
  }

  public static boolean isValidCrn(String param) {
    return param.startsWith("CRN");
  }
}
