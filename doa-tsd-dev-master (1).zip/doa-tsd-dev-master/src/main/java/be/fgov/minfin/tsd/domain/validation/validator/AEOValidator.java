/*
 * @(#) be.fgov.minfin.tsd.domain.validation.validator.AEOValidator.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation.validator;

import be.fgov.minfin.libdoa.commons.lang.Now;
import be.fgov.minfin.tsd.domain.model.consignment.AEOAuthorisation;
import be.fgov.minfin.tsd.domain.model.consignment.AdditionalSupplyChainActor;
import be.fgov.minfin.tsd.domain.model.party.Party;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import be.fgov.minfin.tsd.gateway.crs.CRSGateway;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * This class will perform validation of Additonal Supply Chain Actor
 *
 * @author GauravMitra
 */
@Component
@RequiredArgsConstructor
public class AEOValidator extends BaseConstraintValidator
    implements ConstraintValidator<ValidateBusinessRules, AdditionalSupplyChainActor> {
  private final CRSGateway crsgateway;
  public static final String IND_NUMBER = "identificationNumber";
  public static final String AEOC_CERT = "AEOC";
  public static final String AEOF_CERT = "AEOF";

  @Override
  public boolean isValid(AdditionalSupplyChainActor value, ConstraintValidatorContext context) {

    AtomicBoolean hasError = new AtomicBoolean(false);

    validateAdditionalSupplyChainIdentificationNumber(value, hasError, context);
    validateAeoCertificate(value, hasError, context);
    return !hasError.get();
  }

  private void validateAdditionalSupplyChainIdentificationNumber(
      AdditionalSupplyChainActor additionalSupplyChainActor,
      AtomicBoolean hasError,
      ConstraintValidatorContext context) {
    Optional<Party> party =
        crsgateway.getPartyInfo(
            additionalSupplyChainActor.getIdentificationNumber(),
            Now.localDateTime(),
            false,
            false);
    if (party.isEmpty()) {
      hasError.set(true);
      addViolation(context, ErrorCode.TSPNESXXR0014, IND_NUMBER);
    } else if (StringUtils.isEmpty(additionalSupplyChainActor.getName())) {
      additionalSupplyChainActor.setName(party.get().getName());
    }
  }

  private void validateAeoCertificate(
      AdditionalSupplyChainActor additionalSupplyChainActor,
      AtomicBoolean hasError,
      ConstraintValidatorContext context) {
    List<AEOAuthorisation> aeoAuthorisations =
        crsgateway.getAEOCertificate(
            additionalSupplyChainActor.getIdentificationNumber(), Now.localDateTime());
    List<AEOAuthorisation> validAeoAuthrisations = new ArrayList<>();
    if (!CollectionUtils.isEmpty(aeoAuthorisations)) {
      validAeoAuthrisations =
          aeoAuthorisations.stream()
              .filter(
                  a ->
                      (a.getStatus().equalsIgnoreCase(AEOC_CERT)
                              || a.getStatus().equalsIgnoreCase(AEOF_CERT))
                          && isInFutureOrEmpty(a.getEndDate()))
              .collect(Collectors.toList());
    }
    if (!validAeoAuthrisations
        .isEmpty()) { // TODO to  confirm weather this is right place to do it or in gateway
      setAEOAuth(additionalSupplyChainActor, validAeoAuthrisations);
    } else {
      hasError.set(true);
      addViolation(context, ErrorCode.TSPNESXXR0074);
    }
  }

  private boolean isInFutureOrEmpty(LocalDateTime endDate) {
    if (null == endDate) return true;
    return endDate.isAfter(LocalDateTime.now());
  }

  private void setAEOAuth(AdditionalSupplyChainActor actor, List<AEOAuthorisation> authorisations) {
    List<AEOAuthorisation> lstAuth =
        authorisations.stream()
            .map(
                a ->
                    AEOAuthorisation.builder()
                        .endDate(a.getEndDate())
                        .status(a.getStatus())
                        .chainActor(actor)
                        .build())
            .collect(Collectors.toList());
    if (null != actor.getAeoAuthorisations()) {
      actor.getAeoAuthorisations().clear();
      actor.getAeoAuthorisations().addAll(lstAuth);
    } else {
      actor.setAeoAuthorisations(lstAuth);
    }
  }
}
