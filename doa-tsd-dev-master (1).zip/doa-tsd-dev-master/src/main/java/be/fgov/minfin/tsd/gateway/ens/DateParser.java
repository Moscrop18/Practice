/*
 * @(#) be.fgov.minfin.tsd.gateway.ens.DateParser.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties
 * or made public without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.ens;

import static be.fgov.minfin.tsd.util.DateFormatUtil.MESSAGE_DATE_TIME_FORMAT;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import lombok.extern.slf4j.Slf4j;

/**
 * To format date that is sent to ccn
 *
 * @author GauravMitra
 */
@Slf4j
public class DateParser {
  public static final DateTimeFormatter formatter =
      DateTimeFormatter.ofPattern(MESSAGE_DATE_TIME_FORMAT);

  private DateParser() {
    log.info("Private constructor");
  }

  /**
   * Prints the date.
   *
   * @param date the date
   * @return the string
   */
  public static String printDateTime(XMLGregorianCalendar date) {
    if (date == null) {
      return "";
    }

    Date xmlDate = date.toGregorianCalendar().getTime();
    LocalDateTime ldt = LocalDateTime.ofInstant(xmlDate.toInstant(), ZoneId.systemDefault());
    String formatedDate = formatter.format(ldt);
    log.info("In date format formatted date is {}", formatedDate);
    return formatedDate;
  }

  /**
   * Parses the date time.
   *
   * @param dateTime the date time
   * @return the XML gregorian calendar
   */
  public static XMLGregorianCalendar parseDateTime(String dateTime) {
    try {
      log.info("In date parse ");

      return DatatypeFactory.newInstance().newXMLGregorianCalendar(dateTime);
    } catch (Exception pe) {

      return null;
    }
  }
}
