/*
 * @(#)be.fgov.minfin.tsd.domain.model.StatusHistory.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model;

import be.fgov.minfin.libdoa.commons.lang.Now;
import be.fgov.minfin.tsd.domain.converter.StatusHistoryReasonConverter;
import be.fgov.minfin.tsd.domain.converter.TSDStatusConverter;
import com.fasterxml.jackson.annotation.JsonBackReference;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "STATUS_HISTORY")
public class StatusHistory implements Comparable<StatusHistory> {
  @GeneratedValue(generator = "status_history_seq")
  @SequenceGenerator(name = "status_history_seq", sequenceName = "status_history_seq")
  @Id
  private Long id;

  private LocalDateTime timestamp;

  @Convert(converter = StatusHistoryReasonConverter.class)
  private StatusHistoryReason reason;

  @Convert(converter = TSDStatusConverter.class)
  private TSDStatus status;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "REFERENCE_NUMBER_ID")
  @JsonBackReference
  private ReferenceNumber referenceNumber;

  public StatusHistory(
      TemporaryStorageDeclaration declaration,
      TSDStatus tsdStatus,
      StatusHistoryReason reason,
      LocalDateTime registrationDate) {
    this.referenceNumber = declaration.getReferenceNumber();
    this.status = tsdStatus == null ? declaration.getCurrentStatus() : tsdStatus;
    if (registrationDate != null) {
      this.timestamp = registrationDate;
    } else {
      this.timestamp = Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime();
    }
    this.reason = reason;
  }

  @Override
  public int compareTo(StatusHistory o) {
    if (this.timestamp.isAfter(timestamp)) {
      return 1;
    }
    return -1;
  }
}
