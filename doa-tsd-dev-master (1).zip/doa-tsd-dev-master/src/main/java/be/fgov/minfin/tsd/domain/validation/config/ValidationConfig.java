/*
 * @(#)be.fgov.minfin.tsd.domain.validation.config.ValidationConfig
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.validation.annotation.Validated;

/**
 * Validation Config
 *
 * @author GauravMitra
 */
@Validated
@Getter
@Setter
@ConfigurationProperties(prefix = "validation")
public class ValidationConfig {
  private String eoriNumbers;
  private String unloList;
  private String refNumList;
  private int presentationOfGoodsDateExpiryInHours = 48;
  private int declarationDateExpiryInHours = 24;

  @Bean
  public MessageSourceAccessor messageSourceAccessor() {
    ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
    messageSource.addBasenames("ValidationMessages");
    return new MessageSourceAccessor(messageSource);
  }
}
