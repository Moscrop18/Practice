package be.fgov.minfin.tsd.gateway.eo.api;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Builder;
import lombok.Value;

@Builder
@Value
@JsonPropertyOrder({
  "messageHeader",
  "crn",
  "invalidationInitiatedByCustoms",
  "notificationDate",
  "remarks",
  "declarant",
  "representative"
})
@JsonInclude(Include.NON_NULL)
@JsonRootName("IETS410")
public class InvalidationNotificationDTO {

  private MessageHeaderDTO messageHeader;
  private String crn;
  private String invalidationInitiatedByCustoms;
  private String notificationDate;
  private String remarks;
  private DeclarantDTO declarant;
  private RepresentativeDTO representative;
}
