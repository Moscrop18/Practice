/*
 * @(#) be.fgov.minfin.tsd.domain.model.TransferNotificationMasterConsignment.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties
 * or made public without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model;

import be.fgov.minfin.tsd.domain.model.consignment.Consignment;
import be.fgov.minfin.tsd.domain.model.consignment.TransportDocument;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.math.BigDecimal;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.LazyToOne;
import org.hibernate.annotations.LazyToOneOption;

@Getter
@Setter
@NoArgsConstructor
@Entity
@DiscriminatorValue("Master")
@EqualsAndHashCode(exclude = {"transferNotification"})
public class TransferNotificationMasterConsignment extends TransferNotificationConsignment {

  @OneToOne(fetch = FetchType.LAZY)
  @LazyToOne(value = LazyToOneOption.NO_PROXY)
  @JoinColumn(name = "TRANSFER_NOTIFICATION_ID")
  private TransferNotification transferNotification;

  @Builder(builderMethodName = "transferNotificationMasterConsignmentBuilder")
  public TransferNotificationMasterConsignment(
      Long id,
      BigDecimal totalGrossMass,
      Long totalNumberOfPackages,
      TransportDocument transportDocument,
      Consignment consignment) {
    super(id, totalGrossMass, totalNumberOfPackages, transportDocument, consignment);
  }

  @Override
  @JsonIgnore
  public TransferNotification getTransferNotification() {
    return this.transferNotification;
  }
}
