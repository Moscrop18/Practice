/*
 * @(#)be.fgov.minfin.tsd.resource.api.CombinedTemporaryStorageDeclarationDTO.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */

package be.fgov.minfin.tsd.resource.api;

import static be.fgov.minfin.tsd.util.DateFormatUtil.MESSAGE_DATE_TIME_FORMAT;

import be.fgov.minfin.tsd.domain.validation.annotation.Timestamp;
import com.fasterxml.jackson.annotation.JsonRootName;
import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.Builder;
import lombok.Value;

/**
 * @author GauravMitra
 */
@Value
@Builder(toBuilder = true)
@JsonRootName("IETS115")
public class CombinedTemporaryStorageDeclarationDTO {
  @NotNull @Valid private MessageHeaderDTO messageHeader;

  @NotNull
  @Size(min = 1, max = 22)
  @Schema(example = "REF123456781", description = "Local reference number ")
  private String lrn;

  @Digits(integer = 1, fraction = 0)
  @Schema(
      example = "1",
      description =
          "ENS re-use indicator, specify whether you provide the full data set or want to re-use"
              + " ENS data to complement the minimal TSD data set. (CL027)")
  private Integer ensReUseIndicator;

  @NotNull @Valid private SupervisingCustomsOfficeDTO supervisingCustomsOffice;

  @NotNull @Valid private DeclarantDTO declarant;

  @Valid private RepresentativeDTO representative;

  @Schema(example = "2020-06-01T18:44:22Z")
  @Timestamp(formatter = MESSAGE_DATE_TIME_FORMAT)
  private String declarationDate;

  @NotNull
  @Schema(example = "2020-06-02T18:44:22Z")
  @Timestamp(formatter = MESSAGE_DATE_TIME_FORMAT)
  private String dateAndTimeOfPresentationOfTheGoods;

  @NotNull @Valid private CustomsOfficeOfPresentationDTO customsOfficeOfPresentation;
  @Valid @NotNull private PersonPresentingTheGoodsDTO personPresentingTheGoods;

  @NotNull @Valid private ConsignmentHeaderMasterLevelCombinedDTO consignmentHeaderMasterLevel;
}
