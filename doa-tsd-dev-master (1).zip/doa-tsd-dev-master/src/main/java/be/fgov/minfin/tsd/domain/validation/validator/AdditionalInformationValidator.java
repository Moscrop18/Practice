/*
 * @(#) be.fgov.minfin.tsd.domain.validation.validator.AdditionalInformationValidator.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation.validator;

import be.fgov.minfin.tsd.domain.model.consignment.AdditionalInformation;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * This class is to validate Additional Information
 *
 * @author NamrataGupta
 */
public class AdditionalInformationValidator extends BaseConstraintValidator
    implements ConstraintValidator<ValidateBusinessRules, AdditionalInformation> {
  private static final String CODE_10600 = "10600";
  private static final String TEXT = "text";

  @Override
  public boolean isValid(AdditionalInformation information, ConstraintValidatorContext context) {
    AtomicBoolean isValid = new AtomicBoolean(true);
    if (information != null) {
      validateAdditionalInformationTextAndCode(information, context, isValid);
      validateTextIsNotNullIfCodeIs10600(information, context, isValid);
    }
    return isValid.get();
  }

  private void validateAdditionalInformationTextAndCode(
      AdditionalInformation information,
      ConstraintValidatorContext context,
      AtomicBoolean isValid) {

    if (information.getCode() == null && information.getText() == null) {
      addViolation(context, ErrorCode.TSPNESXXR0033);
      isValid.set(false);
    }
  }

  private void validateTextIsNotNullIfCodeIs10600(
      AdditionalInformation information,
      ConstraintValidatorContext context,
      AtomicBoolean isValid) {
    if (information.getCode() != null
        && information.getCode().equals(CODE_10600)
        && information.getText() == null) {
      addViolation(context, ErrorCode.TSPNESXXC0035, TEXT);
      isValid.set(false);
    }
  }
}
