package be.fgov.minfin.tsd;

import be.fgov.minfin.libdoa.pagination.repository.JpaSpecificationProjectionRepositoryImpl;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.retry.annotation.EnableRetry;

@EnableCaching
@SpringBootApplication
@ConfigurationPropertiesScan
@EnableJpaRepositories(repositoryBaseClass = JpaSpecificationProjectionRepositoryImpl.class)
@EnableRetry(proxyTargetClass = true)
public class TSDApplication {

  public static void main(final String[] args) {
    SpringApplication.run(TSDApplication.class, args);
  }
}
