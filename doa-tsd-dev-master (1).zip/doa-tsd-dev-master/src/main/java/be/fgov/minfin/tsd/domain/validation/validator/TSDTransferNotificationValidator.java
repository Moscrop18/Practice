/*
 * @(#) be.fgov.minfin.tsd.domain.validation.validator.TSDTransferNotificationValidator.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties
 * or made public without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation.validator;

import be.fgov.minfin.libdoa.commons.lang.Now;
import be.fgov.minfin.tsd.domain.model.TransferNotification;
import be.fgov.minfin.tsd.domain.model.party.Party;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import be.fgov.minfin.tsd.gateway.crs.CRSGateway;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

public class TSDTransferNotificationValidator extends BaseConstraintValidator
    implements ConstraintValidator<ValidateBusinessRules, TransferNotification> {

  private static final String DECLARANT = "declarant";

  private static final String REPRESENTATIVE = "representative";

  private static final String IDENTIFICATION_NUMBER = "identificationNumber";

  private static final String PERSON_NOTIFYING_ARRIVAL = "personNotifyingTheArrivalAfterMovement";

  private static final String CONSIGNMENT_HEADER = "consignmentHeader";

  @Autowired private CRSGateway crsGateway;

  @Override
  public boolean isValid(
      TransferNotification transferNotification, ConstraintValidatorContext context) {

    AtomicBoolean isValid = new AtomicBoolean(true);

    validateDeclarantIdentificationNumber(transferNotification, isValid, context);
    validateRepresentativeIdentificationNumber(transferNotification, isValid, context);
    validateSameEoriNumber(transferNotification, isValid, context);
    validatePersonNotifyingTheArrivalIdNum(transferNotification, isValid, context);
    validateTransferNotificationConsignment(transferNotification, isValid, context);

    return isValid.get();
  }

  private void validateDeclarantIdentificationNumber(
      TransferNotification transferNotification,
      AtomicBoolean isValid,
      ConstraintValidatorContext context) {

    if (transferNotification.getDeclarant() == null) return;

    boolean validEORINumber =
        checkValidEORINumber(
            transferNotification.getDeclarant().getIdentificationNumber(), isValid);

    if (!validEORINumber) {
      addViolation(context, ErrorCode.TSPNESXXR0001, DECLARANT, IDENTIFICATION_NUMBER);
    }
  }

  private void validateRepresentativeIdentificationNumber(
      TransferNotification transferNotification,
      AtomicBoolean isValid,
      ConstraintValidatorContext context) {

    if (null == transferNotification.getRepresentative()) return;

    boolean validEORINumber =
        checkValidEORINumber(
            transferNotification.getRepresentative().getIdentificationNumber(), isValid);

    if (!validEORINumber) {
      addViolation(context, ErrorCode.TSPNESXXR0002, REPRESENTATIVE, IDENTIFICATION_NUMBER);
    }
  }

  private void validatePersonNotifyingTheArrivalIdNum(
      TransferNotification transferNotification,
      AtomicBoolean isValid,
      ConstraintValidatorContext context) {

    if (transferNotification.getPersonNotifyingTheArrivalAfterMovement() == null) return;

    boolean validEORINumber =
        checkValidEORINumber(
            transferNotification
                .getPersonNotifyingTheArrivalAfterMovement()
                .getIdentificationNumber(),
            isValid);

    if (!validEORINumber) {
      addViolation(
          context, ErrorCode.TSPNESXXR0138, PERSON_NOTIFYING_ARRIVAL, IDENTIFICATION_NUMBER);
    }
  }

  private void validateTransferNotificationConsignment(
      TransferNotification transferNotification,
      AtomicBoolean isValid,
      ConstraintValidatorContext context) {

    if ((transferNotification.getMasterConsignment() == null
            && CollectionUtils.isEmpty(transferNotification.getHouseConsignments()))
        || (transferNotification.getMasterConsignment() != null
            && !CollectionUtils.isEmpty(transferNotification.getHouseConsignments()))) {
      isValid.set(false);
      addViolation(context, ErrorCode.TSPNESXXR0140, CONSIGNMENT_HEADER);
    }
  }

  private boolean checkValidEORINumber(String identificationNumber, AtomicBoolean isValid) {

    Optional<Party> party =
        crsGateway.getPartyInfo(identificationNumber, Now.localDateTime(), false, false);

    if (party.isEmpty()) {
      // Invalid EORI Number
      isValid.set(false);
      return false;
    }

    return true;
  }

  private void validateSameEoriNumber(
      TransferNotification transferNotification,
      AtomicBoolean isValid,
      ConstraintValidatorContext context) {

    if (transferNotification.getDeclarant() == null
        || transferNotification.getRepresentative() == null) return;

    if (transferNotification
        .getRepresentative()
        .getIdentificationNumber()
        .equalsIgnoreCase(transferNotification.getDeclarant().getIdentificationNumber())) {
      isValid.set(false);
      addViolation(context, ErrorCode.TSPNESXXC0003, REPRESENTATIVE, IDENTIFICATION_NUMBER);
    }
  }
}
