/*
 * @(#)be.fgov.minfin.tsd.resource.api.ConsignmentHeaderMasterLevelCombinedDTO.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.resource.api;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Value;

@Value
@JsonRootName("consignmentHeaderMasterLevel")
@EqualsAndHashCode(callSuper = true)
public class ConsignmentHeaderMasterLevelCombinedDTO extends BaseHeaderMasterLevelDTO {
  @Builder
  public ConsignmentHeaderMasterLevelCombinedDTO(
      @JsonProperty("consignmentMasterLevel") ConsignmentMasterLevelDTO consignmentMasterLevel,
      @JsonProperty("consignmentHouseLevel")
          List<@Valid ConsignmentHouseLevelDTO> consignmentHouseLevel,
      @JsonProperty("arrivalTransportMeans") ArrivalTransportMeansDTO arrivalTransportMeans,
      @JsonProperty("warehouse") WarehouseDTO warehouse,
      @JsonProperty("placeOfUnloading") PlaceOfUnloadingDTO placeOfUnloading,
      @JsonProperty("locationOfGoods") @Valid LocationOfGoodsDTO locationOfGoods,
      @JsonProperty("carrier") @Valid CarrierDTO carrier) {
    super(
        consignmentMasterLevel,
        consignmentHouseLevel,
        arrivalTransportMeans,
        warehouse,
        placeOfUnloading);
    this.locationOfGoods = locationOfGoods;
    this.carrier = carrier;
  }

  @NotNull @Valid private LocationOfGoodsDTO locationOfGoods;
  @NotNull @Valid private CarrierDTO carrier;
}
