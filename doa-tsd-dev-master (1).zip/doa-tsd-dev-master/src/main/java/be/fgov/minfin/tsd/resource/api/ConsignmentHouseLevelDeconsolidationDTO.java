/*
 * @(#) be.fgov.minfin.tsd.resource.api.ConsignmentHouseLevelDeconsolidationDTO.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.resource.api;

import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.Builder;
import lombok.Value;

@Value
@Builder(toBuilder = true)
@JsonRootName("consignmentHouseLevel")
public class ConsignmentHouseLevelDeconsolidationDTO {

  @Valid private ReferenceNumberUCRDTO referenceNumberUCR;

  @Digits(integer = 16, fraction = 6)
  @Schema(example = "0.42")
  @NotNull
  private BigDecimal totalGrossMass;

  @NotNull @Valid private PartyDTO consignor;

  @NotNull @Valid private PartyDTO consignee;

  @Valid private PartyDTO notifyParty;

  @NotNull @Valid private TransportDocumentDTO transportDocument;

  @Size(max = 99)
  @JacksonXmlElementWrapper(useWrapping = false)
  private List<@Valid AdditionalInformationDTO> additionalInformation;

  @Size(max = 99)
  @JacksonXmlElementWrapper(useWrapping = false)
  private List<@Valid AdditionalReferenceDTO> additionalReference;

  @Size(max = 9999)
  @JacksonXmlElementWrapper(useWrapping = false)
  private List<@Valid TransportEquipmentDTO> transportEquipment;

  @Size(max = 99)
  @JacksonXmlElementWrapper(useWrapping = false)
  private List<@Valid SupportingDocumentDTO> supportingDocument;

  @Size(max = 99)
  @JacksonXmlElementWrapper(useWrapping = false)
  private List<@Valid AdditionalSupplyChainActorDTO> additionalSupplyChainActor;

  @Size(min = 1, max = 9999)
  @JacksonXmlElementWrapper(useWrapping = false)
  private List<@Valid ConsignmentItemHouseLevelDeconsolidationDTO> consignmentItemHouseLevel;
}
