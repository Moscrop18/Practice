/*
 * @(#) be.fgov.minfin.tsd.event.TSDEventBroker.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.event;

import be.fgov.minfin.libdoa.amqp.transactional.QueueSender;
import be.fgov.minfin.tsd.event.api.ControlResultReceivedEvent;
import be.fgov.minfin.tsd.event.api.RiskAnalysisResultReceivedEvent;
import be.fgov.minfin.tsd.event.api.RiskHitNotificationReceivedEvent;
import be.fgov.minfin.tsd.event.api.TSDActivationReceivedEvent;
import be.fgov.minfin.tsd.event.api.TSDAmendmentReceivedEvent;
import be.fgov.minfin.tsd.event.api.TSDDeconsolidationNotificationRecievedEvent;
import be.fgov.minfin.tsd.event.api.TSDInvalidationReceivedEvent;
import be.fgov.minfin.tsd.event.api.TSDReceivedEvent;
import be.fgov.minfin.tsd.event.api.TSDTimerExpirationEvent;
import be.fgov.minfin.tsd.event.api.TSDTransferNotificationReceivedEvent;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * This class is used to send TSD message to queue
 *
 * @author GauravMitra
 */
@Component
@RequiredArgsConstructor
public class TSDEventBroker {

  private final QueueSender queueSender;

  private final TSDEventConfig tsdEventConfig;

  /**
   * send TSD message on queue
   *
   * @param TSDReceivedEvent
   */
  public void publishTSDReceivedEvent(final TSDReceivedEvent tsdReceivedEvent) {
    queueSender.publishMessage(tsdEventConfig.getTsdReceivedQueue(), tsdReceivedEvent);
  }

  /**
   * Send activation event on Queue
   *
   * @param tSDActivationReceivedEvent
   */
  public void publishActivateTSDEvent(final TSDActivationReceivedEvent tSDActivationReceivedEvent) {
    queueSender.publishMessage(tsdEventConfig.getTsdActivateQueue(), tSDActivationReceivedEvent);
  }

  /**
   * Send invalidation event on Queue
   *
   * @param tsdInvalidationReceivedEvent
   */
  public void publishInvalidateTSDEvent(TSDInvalidationReceivedEvent tsdInvalidationReceivedEvent) {
    queueSender.publishMessage(
        tsdEventConfig.getTsdInvalidateQueue(), tsdInvalidationReceivedEvent);
  }

  /**
   * Send timer expiration event on Queue
   *
   * @param tsdTimerExpirationEvent
   */
  public void publishTSDExpirationTimersExpired(TSDTimerExpirationEvent tsdTimerExpirationEvent) {
    queueSender.publishMessage(
        tsdEventConfig.getTsdTimerExpirationQueue(), tsdTimerExpirationEvent);
  }

  /**
   * Send amendment event on Queue
   *
   * @param tsdAmendmentReceivedEvent
   */
  public void publishTSDAmendmentEvent(TSDAmendmentReceivedEvent tsdAmendmentReceivedEvent) {
    queueSender.publishMessage(tsdEventConfig.getTsdAmendmentQueue(), tsdAmendmentReceivedEvent);
  }

  /**
   * Send risk hit event on Queue
   *
   * @param riskHitNotificationReceivedEvent
   */
  public void publishRiskHitNotificationReceivedEvent(
      RiskHitNotificationReceivedEvent riskHitNotificationReceivedEvent) {
    queueSender.publishMessage(
        tsdEventConfig.getTsdRiskHitNotificationQueue(), riskHitNotificationReceivedEvent);
  }

  public void publishRiskAnalysisResultReceived(
      RiskAnalysisResultReceivedEvent riskAnalysisResultReceivedEvent) {
    queueSender.publishMessage(
        tsdEventConfig.getTsdRiskAnalysisResultReceivedQueue(), riskAnalysisResultReceivedEvent);
  }

  public void publishControlResultReceived(ControlResultReceivedEvent controlResultReceivedEvent) {
    queueSender.publishMessage(
        tsdEventConfig.getTsdControlResultReceivedQueue(), controlResultReceivedEvent);
  }

  public void publishTransferNotificationReceivedEvent(
      TSDTransferNotificationReceivedEvent tsdTransferNotificationReceivedEvent) {
    queueSender.publishMessage(
        tsdEventConfig.getTsdTransferNotificationReceivedQueue(),
        tsdTransferNotificationReceivedEvent);
  }

  public void publishDeconsolidationNotificationReceivedEvent(
      TSDDeconsolidationNotificationRecievedEvent tsdDeconsolidationNotificationRecievedEvent) {
    queueSender.publishMessage(
        tsdEventConfig.getTsdDeconsolidationNotificationReceivedQueue(),
        tsdDeconsolidationNotificationRecievedEvent);
  }
}
