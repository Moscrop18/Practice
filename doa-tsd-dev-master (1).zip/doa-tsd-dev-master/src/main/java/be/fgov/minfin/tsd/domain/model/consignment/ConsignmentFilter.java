/*
 * @(#)be.fgov.minfin.tsd.domain.model.consignment.ConsignmentFilter.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model.consignment;

import be.fgov.minfin.tsd.resource.api.ui.ConsignmentField;
import be.fgov.minfin.tsd.resource.api.ui.ConsignmentType;
import java.util.ArrayList;
import java.util.List;
import lombok.Builder;
import lombok.Value;

@Value
@Builder(toBuilder = true)
public class ConsignmentFilter {
  private ConsignmentType type;
  private List<ConsignmentField> fields;

  public List<Class<?>> getRequiredConsignmentTypes() {
    List<Class<?>> classes = new ArrayList<>();
    if (type == ConsignmentType.MASTER) {
      classes.add(MasterConsignment.class);
    } else if (type == ConsignmentType.HOUSE) {
      classes.add(HouseConsignment.class);
    } else {
      classes.add(MasterConsignment.class);
      classes.add(HouseConsignment.class);
    }
    return classes;
  }
}
