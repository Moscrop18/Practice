/*
 * @(#) be.fgov.minfin.tsd.domain.service.ENSReuser.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties
 * or made public without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.service;

import be.fgov.minfin.shared.tracing.Traced;
import be.fgov.minfin.tsd.domain.model.ConsignmentInformationType;
import be.fgov.minfin.tsd.domain.model.TSDStatus;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.consignment.PreviousDocument;
import be.fgov.minfin.tsd.domain.validation.validator.ENSReuseValidator;
import be.fgov.minfin.tsd.gateway.ens.ENSGateway;
import be.fgov.minfin.tsd.gateway.ens.exception.ReuseFailedException;
import be.fgov.minfin.tsd.gateway.ens.exception.ReuseFailedException.ReuseFailedType;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import javax.validation.ConstraintViolation;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;
import wco.datamodel.wco.cis._1.ConsignmentMasterLevelType12;
import wco.datamodel.wco.cis._1.IE4R05Type;

/**
 * @author MohammadFaiz
 */
@Service
@RequiredArgsConstructor
public class ENSReuser {

  private final ENSReuseValidator ensReuseValidator;

  private final ENSGateway ensGateway;

  private final ENSMapper ensMapper;

  @Traced
  public void prefillTSDFromENSes(TemporaryStorageDeclaration declaration) {
    if (declaration.getCurrentStatus() == TSDStatus.DRAFT) {
      prepareDataForENSReuse(declaration);
    }
    ensReuseValidator.validateMinDataForReuse(declaration);
    IE4R05Type ie4r05Type = ensGateway.getENS(declaration);
    Set<ConstraintViolation<TemporaryStorageDeclaration>> violations =
        validateENSForReuse(declaration, ie4r05Type);
    if (!violations.isEmpty()) {
      throw new ReuseFailedException(
          ReuseFailedType.ENS_DATA_VALIDATION_FAILED, violations.toArray());
    }
  }

  private Set<ConstraintViolation<TemporaryStorageDeclaration>> validateENSForReuse(
      TemporaryStorageDeclaration declaration, IE4R05Type ie4r05) {
    Set<ConstraintViolation<TemporaryStorageDeclaration>> violations = new HashSet<>();
    ConsignmentMasterLevelType12 masterConsignmentENS =
        ie4r05.getRelatedENS().getConsignmentMasterLevel();

    if (Objects.nonNull(declaration.getMasterConsignment())
        && CollectionUtils.isEmpty(declaration.getHouseConsignments())) {

      ensReuseValidator.checkForMasterLevelViolations(
          declaration.getMasterConsignment(), masterConsignmentENS, violations);
      if (!violations.isEmpty()) {
        return violations;
      }
      ensMapper.mapENSToTSDWhenOnlyMC(declaration, ie4r05);
      createPreviousDocumentForHCsFromMC(declaration);
    } else if (Objects.isNull(declaration.getMasterConsignment())
        && !CollectionUtils.isEmpty(declaration.getHouseConsignments())) {
      ensReuseValidator.checkForHouseLevelViolations(
          declaration.getHouseConsignments(), masterConsignmentENS, violations);
      if (!violations.isEmpty()) {
        return violations;
      }
      ensMapper.mapENSToTSDWhenOnlyHC(declaration, ie4r05);
    } else if (Objects.nonNull(declaration.getMasterConsignment())
        && !CollectionUtils.isEmpty(declaration.getHouseConsignments())) {
      ensReuseValidator.checkForMasterLevelViolations(
          declaration.getMasterConsignment(), masterConsignmentENS, violations);
      ensReuseValidator.checkForHouseLevelViolations(
          declaration.getHouseConsignments(), masterConsignmentENS, violations);
      if (!violations.isEmpty()) {
        return violations;
      }
      ensMapper.mapENSToTSDWhenBothHCAndMC(declaration, ie4r05);
    }
    ensMapper.setBackReference(declaration);
    ensReuseValidator.businessValidationOnTransformedData(declaration, violations);
    return violations;
  }

  private void createPreviousDocumentForHCsFromMC(TemporaryStorageDeclaration declaration) {
    PreviousDocument previousDocumentMC = declaration.getMasterConsignment().getPreviousDocument();
    if (Objects.nonNull(previousDocumentMC)
        && !CollectionUtils.isEmpty(declaration.getHouseConsignments())) {
      declaration.getHouseConsignments().stream()
          .forEach(
              hc -> {
                PreviousDocument previousDocumentHC =
                    PreviousDocument.builder()
                        .referenceNumber(previousDocumentMC.getReferenceNumber())
                        .type(previousDocumentMC.getType())
                        .build();
                hc.setPreviousDocument(previousDocumentHC);
              });
    }
  }

  private void prepareDataForENSReuse(TemporaryStorageDeclaration tsd) {
    if (tsd.getConsignmentType() == ConsignmentInformationType.MASTERANDHOUSE) {
      PreviousDocument previousDocumentMaster = tsd.getMasterConsignment().getPreviousDocument();
      tsd.getHouseConsignments()
          .forEach(
              (c) ->
                  c.setPreviousDocument(
                      PreviousDocument.builder()
                          .referenceNumber(previousDocumentMaster.getReferenceNumber())
                          .type(previousDocumentMaster.getType())
                          .build()));
    } else if (tsd.getConsignmentType() == ConsignmentInformationType.HOUSE) {
      PreviousDocument previousDocumentHouse =
          tsd.getHouseConsignments().get(0).getPreviousDocument();
      tsd.getHouseConsignments()
          .forEach(
              (c) ->
                  c.setPreviousDocument(
                      PreviousDocument.builder()
                          .referenceNumber(previousDocumentHouse.getReferenceNumber())
                          .type(previousDocumentHouse.getType())
                          .build()));
    }
  }
}
