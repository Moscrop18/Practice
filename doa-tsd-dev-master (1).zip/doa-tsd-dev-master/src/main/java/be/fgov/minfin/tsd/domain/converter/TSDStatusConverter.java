/*
 * @(#)be.fgov.minfin.tsd.domain.converter.TSDTypeConverter.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.converter;

import be.fgov.minfin.tsd.domain.model.TSDStatus;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter(autoApply = true)
public class TSDStatusConverter implements AttributeConverter<TSDStatus, Integer> {

  @Override
  public Integer convertToDatabaseColumn(TSDStatus type) {
    return type.getCode();
  }

  @Override
  public TSDStatus convertToEntityAttribute(Integer dbData) {
    for (TSDStatus nodeType : TSDStatus.values()) {
      if (nodeType.getCode().equals(dbData)) {
        return nodeType;
      }
    }
    throw new IllegalArgumentException("Unknown database value:" + dbData);
  }
}
