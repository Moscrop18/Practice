package be.fgov.minfin.tsd.domain.validation.plugin;

/*
 * @(#)be.fgov.minfin.tsd.domain.validation.InvalidationRequestValidatorPlugin
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
import be.fgov.minfin.tsd.domain.model.InvalidationRequest;
import java.util.Set;
import javax.validation.ConstraintViolation;

public interface InvalidationRequestValidatorPlugin {
  public Set<ConstraintViolation<InvalidationRequest>> validateInvalidationRequest(
      final InvalidationRequest invalidationRequest);
}
