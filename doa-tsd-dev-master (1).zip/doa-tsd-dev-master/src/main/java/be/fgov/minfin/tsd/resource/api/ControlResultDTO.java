/*
 * @(#)be.fgov.minfin.tsd.resource.api.ControlResultDTO.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */

package be.fgov.minfin.tsd.resource.api;

import static be.fgov.minfin.tsd.util.DateFormatUtil.MESSAGE_DATE_TIME_FORMAT;

import be.fgov.minfin.tsd.domain.validation.annotation.Timestamp;
import com.fasterxml.jackson.annotation.JsonRootName;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.Builder;
import lombok.Value;

@Value
@Builder(toBuilder = true)
@JsonRootName("controlResult")
public class ControlResultDTO {

  @NotNull
  @Size(min = 1, max = 3)
  private String type;

  @NotNull
  @Timestamp(formatter = MESSAGE_DATE_TIME_FORMAT)
  private String controlEndDateAndTime;

  @NotNull
  @Size(min = 1, max = 3)
  private String code;

  @Size(min = 1, max = 512)
  private String description;
}
