/*
 * @(#)be.fgov.minfin.tsd.domain.validation.InvalidationRequestValidator
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation;

import be.fgov.minfin.tsd.domain.model.InvalidationRequest;
import be.fgov.minfin.tsd.domain.validation.plugin.InvalidationRequestValidatorPlugin;
import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @author MohdSalim
 */
@RequiredArgsConstructor
@Slf4j
@Component
public class InvalidationRequestValidator implements InvalidationRequestValidatorPlugin {

  private final Validator validator;

  public Set<ConstraintViolation<InvalidationRequest>> validateInvalidationRequest(
      final InvalidationRequest invalidationRequest) {

    Set<ConstraintViolation<InvalidationRequest>> violation =
        validator.validate(invalidationRequest);
    if (log.isDebugEnabled()) {
      violation.stream()
          .forEach(
              v ->
                  log.info(
                      "violation with message {} and path {}",
                      v.getMessage(),
                      v.getPropertyPath()));
    }
    return violation;
  }
}
