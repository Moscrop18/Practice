/*
 * @(#) be.fgov.minfin.tsd.domain.model.DeconsolidationNotification.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model;

import be.fgov.minfin.libdoa.commons.lang.Now;
import be.fgov.minfin.libdoa.entities.VersionedAuditableEntity;
import be.fgov.minfin.tsd.domain.converter.DeconsolidationNotificationStatusConverter;
import be.fgov.minfin.tsd.domain.message.Error;
import be.fgov.minfin.tsd.domain.model.party.Party;
import be.fgov.minfin.tsd.domain.model.party.Representative;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import be.fgov.minfin.tsd.domain.validation.annotation.group.DeconsolidationNotificationValidatorGroup;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.apache.commons.collections4.CollectionUtils;

@Getter
@Setter
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(exclude = {"declarant", "representative", "validationErrors", "declaration"})
@Entity
@Table(name = "DECONSOLIDATION_NOTIFICATION")
@ValidateBusinessRules(groups = DeconsolidationNotificationValidatorGroup.class)
public class DeconsolidationNotification extends VersionedAuditableEntity<Long> {

  @Id
  @GeneratedValue(generator = "DECONSOLIDATION_NOTIFICATION_SEQ")
  @SequenceGenerator(
      name = "DECONSOLIDATION_NOTIFICATION_SEQ",
      sequenceName = "DECONSOLIDATION_NOTIFICATION_SEQ")
  private Long id;

  private String lrn;

  @Column(name = "REGISTRATION_DATE")
  private LocalDateTime registrationDate;

  @Valid
  @ToString.Exclude
  @OneToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "MESSAGE_INFORMATION_ID")
  private MessageInformation messageInformation;

  @Convert(converter = DeconsolidationNotificationStatusConverter.class)
  private DeconsolidationNotificationStatus status;

  @OneToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "DECLARANT_ID")
  @ToString.Exclude
  @Valid
  private Party declarant;

  @OneToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "REPRESENTATIVE_ID")
  @ToString.Exclude
  @Valid
  private Representative representative;

  @OneToMany(
      mappedBy = "deconsolidationNotification",
      cascade = {CascadeType.PERSIST, CascadeType.MERGE},
      orphanRemoval = true)
  @ToString.Exclude
  @JsonManagedReference(value = "deconsolidationNotification")
  private List<ValidationError> validationErrors;

  @OneToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "DECONSOLIDATED_TSD_ID")
  @Valid
  private TemporaryStorageDeclaration declaration;

  public void completeDeconsolidationNotification(
      TemporaryStorageDeclaration currentTSD, List<Error> errors) {

    if (CollectionUtils.isEmpty(errors)) {
      this.status = DeconsolidationNotificationStatus.APPROVED;
    } else {
      this.status = DeconsolidationNotificationStatus.REFUSED;
      this.validationErrors = ValidationError.buildValidationErrors(errors);
    }

    this.registrationDate = Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime();
    this.declaration = currentTSD;
  }
}
