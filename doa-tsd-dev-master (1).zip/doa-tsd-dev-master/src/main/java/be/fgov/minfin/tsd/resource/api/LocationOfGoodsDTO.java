/*
 * @(#)be.fgov.minfin.tsd.resource.api.LocationOfGoodsDTO.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */

package be.fgov.minfin.tsd.resource.api;

import be.fgov.minfin.tsd.resource.validation.B2BOnly;
import com.fasterxml.jackson.annotation.JsonRootName;
import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import lombok.Builder;
import lombok.Value;

/** LocationOfGoodsDTO */
@Value
@Builder(toBuilder = true)
@JsonRootName("locationOfGoods")
public class LocationOfGoodsDTO {
  @NotNull(groups = B2BOnly.class)
  @Pattern(regexp = "[a-zA-Z]{1}")
  @Schema(example = "D", description = "Type of location (CL347)")
  private String typeOfLocation;

  @NotNull(groups = B2BOnly.class)
  @Pattern(regexp = "[a-zA-Z]{1}")
  @Schema(example = "W", description = "Qualifier of Identification (CL326)")
  private String qualifierOfIdentification;

  @Size(min = 0, max = 17)
  @Schema(example = "BEZAVA00710", description = "UNLOCODE for the location of goods (CL144)")
  private String unLoCode;

  @Size(min = 0, max = 35)
  @Schema(example = "REF123456789")
  private String authorisationNumber;

  @Size(min = 0, max = 4)
  @Schema(example = "REF123456789")
  private String additionalIdentifier;

  @Valid private CustomsOfficeDTO customsOffice;
  @Valid private GnssDTO gnss;

  @Valid private EconomicOperatorDTO economicOperator;
  @Valid private AddressEODTO address;
}
