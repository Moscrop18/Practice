/*
 * @(#) be.fgov.minfin.tsd.gateway.risk.message.RiskAnaylsisRequest.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.risk.message;

import be.fgov.minfin.libdoa.amqp.BaseEvent;
import java.util.List;
import lombok.Builder;
import lombok.Value;

@Value
@Builder(toBuilder = true)
public class SendInvalidationNotification extends BaseEvent {

  private MessageHeader messageHeader;
  private String crn;
  private String completionDate;
  private List<PreviousRiskAnalysis> relatedRiskAnalysisRequest;
}
