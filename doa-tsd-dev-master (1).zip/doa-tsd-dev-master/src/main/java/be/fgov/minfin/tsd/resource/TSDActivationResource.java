/*
 * @(#)be.fgov.minfin.tsd.resource.TSDActivationResource.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.resource;

import be.fgov.minfin.tsd.domain.model.TSDActivationRequest;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.service.ActivationService;
import be.fgov.minfin.tsd.resource.api.activation.TSDActivationRequestDTO;
import be.fgov.minfin.tsd.resource.exception.TSDActivationExceptionHandling;
import be.fgov.minfin.tsd.resource.mapper.TSDActivationRequestMapper;
import be.fgov.minfin.tsd.resource.validation.B2BOnly;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import javax.validation.Valid;
import javax.validation.groups.ConvertGroup;
import javax.validation.groups.Default;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 *
 * <h1>Processes a TSD Activation Request</h1>
 *
 * Exposes API for submitting a {@link Activation Request} .
 *
 * <p>TSD Activation Request(TSD Activation) message is sent by the PN System as trigger to start
 * the process of a TSD Activation.
 *
 * <p>A positive acknowledgment is synchronously returned to the message sender to inform him that
 * the message is well received.
 *
 * <p>If the message is not compliant with the defined message schema, a negative acknowledgement
 * message is synchronously sent to the message sender
 *
 * <p>This REST resource is a Jersey implementation which produces and consumes {@link
 * MediaType#APPLICATION_JSON application/json} &amp; {@link MediaType#APPLICATION_XHTML_XML
 * application/xml} both.
 *
 * <p>Responsibilities of a Resource
 *
 * <ul>
 *   <li>Exposing REST API
 *   <li>Authorization of operations
 *   <li>Mapping of XML/JSON &lt;-&gt; {@link }
 *   <li>validating input on PresentationNotificationDTO
 *       <ul>
 *         <li>using constraints
 *         <li>using business validators
 *       </ul>
 *   <li>Mapping of {@link } &lt;-&gt; {@link TemporaryStorageDeclaration} Domain object
 *   <li>process of referenced domain object
 * </ul>
 *
 * @author GauravMitra
 * @version 1.0.1
 */
@Component
@Path("/temporaryStorageDeclarations/activate")
@TSDActivationExceptionHandling
@Produces({MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_JSON})
@RequiredArgsConstructor
@Transactional
public class TSDActivationResource {
  private final TSDActivationRequestMapper tSDActivationRequestMapper;

  private final ActivationService activationService;

  /**
   *
   *
   * <h1>Validates &amp; create {@link TSDActivationRequestDTO}</h1>
   *
   * @param TSDActivationRequestDTO
   * @return the response having acknowledgement message with (@link Response.Status.Accepted) if
   *     xsd validation succeeds or negative acknowledgement message with (@link
   *     Response.Status.BAD_REQUEST) if xsd validation fails
   */
  @POST
  @ApiResponse(responseCode = "202", description = "Accepted")
  @ApiResponse(responseCode = "400", description = "Bad Request")
  @Operation(summary = "Activate a Temporary Storage Declaration")
  public Response submitActivationRequest(
      @ConvertGroup(from = Default.class, to = B2BOnly.class) @Valid
          TSDActivationRequestDTO activationRequestDTO) {

    TSDActivationRequest activateTSDRequest = tSDActivationRequestMapper.map(activationRequestDTO);
    activationService.receiveActivationRequest(activateTSDRequest);

    return Response.accepted().build();
  }
}
