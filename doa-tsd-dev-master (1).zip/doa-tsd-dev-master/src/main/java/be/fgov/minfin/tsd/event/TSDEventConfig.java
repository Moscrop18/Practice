/*
 * @(#) be.fgov.minfin.tsd.event.TSDEventConfig.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.event;

import static be.fgov.minfin.tsd.config.RabbitConfig.ENABLE_QUORUM_QUEUE;
import static be.fgov.minfin.tsd.config.RabbitConfig.RABBIT_LISTENER_CONTAINER_FACTORY;

import be.fgov.minfin.libdoa.amqp.ExchangeConfig;
import be.fgov.minfin.libdoa.amqp.transactional.QueueConfig;
import javax.annotation.PostConstruct;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * config class for pn event
 *
 * @author GauravMitra
 */
@Slf4j
@Getter
@Setter
@Configuration("tSDEventConfig")
@ConfigurationProperties(prefix = "events", ignoreUnknownFields = false)
public class TSDEventConfig {

  public static final String TSD_RECEIVED_QUEUE = "#{tsdReceivedQueue}";
  public static final String TSD_RECEIVED_CONCURRENCY =
      "#{tSDEventConfig.tsdReceivedQueue.concurrentConsumers}";

  public static final String TSD_ACTIVATE_QUEUE = "#{tsdActivateQueue}";
  public static final String TSD_ACTIVATE_CONCURRENCY =
      "#{tSDEventConfig.tsdActivateQueue.concurrentConsumers}";

  public static final String TSD_INVALIDATE_QUEUE = "#{tsdInvalidateQueue}";
  public static final String TSD_INVALIDATE_CONCURRENCY =
      "#{tSDEventConfig.tsdInvalidateQueue.concurrentConsumers}";

  public static final String TSD_TIMER_EXPIRATION_QUEUE = "#{tsdTimerExpirationQueue}";
  public static final String TSD_TIMER_EXPIRATION_CONCURRENCY =
      "#{tSDEventConfig.tsdTimerExpirationQueue.concurrentConsumers}";

  public static final String TSD_AMENDMENT_QUEUE = "#{tsdAmendmentQueue}";
  public static final String TSD_AMENDMENT_CONCURRENCY =
      "#{tSDEventConfig.tsdAmendmentQueue.concurrentConsumers}";

  public static final String TSD_RISK_HIT_NOTIFICATION_QUEUE = "#{tsdRiskHitNotificationQueue}";
  public static final String TSD_RISK_HIT_NOTIFICATION_CONCURRENCY =
      "#{tSDEventConfig.tsdRiskHitNotificationQueue.concurrentConsumers}";

  public static final String TSD_RISK_ANALYSIS_RESULT_RECEIVED_QUEUE =
      "#{tsdRiskAnalysisResultReceivedQueue}";
  public static final String TSD_RISK_ANALYSIS_RESULT_RECEIVED_CONCURRENCY =
      "#{tSDEventConfig.tsdRiskAnalysisResultReceivedQueue.concurrentConsumers}";

  public static final String TSD_CONTROL_RESULT_RECEIVED_QUEUE = "#{tsdControlResultReceivedQueue}";
  public static final String TSD_CONTROL_RESULT_RECEIVED_CONCURRENCY =
      "#{tSDEventConfig.tsdControlResultReceivedQueue.concurrentConsumers}";

  public static final String TSD_TRANSFER_NOTIFICATION_RECEIVED_QUEUE =
      "#{tsdTransferNotificationReceivedQueue}";
  public static final String TSD_TRANSFER_NOTIFICATION_RECEIVED_CONCURRENCY =
      "#{tSDEventConfig.tsdTransferNotificationReceivedQueue.concurrentConsumers}";

  public static final String TSD_DECONSOLIDATION_NOTIFICATION_RECEIVED_QUEUE =
      "#{tsdDeconsolidationNotificationReceivedQueue}";
  public static final String TSD_DECONSOLIDATION_NOTIFICATION_RECEIVED_CONCURRENCY =
      "#{tSDEventConfig.tsdDeconsolidationNotificationReceivedQueue.concurrentConsumers}";

  private ExchangeConfig exchangeConfig;

  private QueueConfig tsdReceivedQueue;
  private QueueConfig tsdActivateQueue;
  private QueueConfig tsdInvalidateQueue;
  private QueueConfig tsdTimerExpirationQueue;
  private QueueConfig tsdAmendmentQueue;
  private QueueConfig tsdRiskHitNotificationQueue;
  private QueueConfig tsdRiskAnalysisResultReceivedQueue;
  private QueueConfig tsdControlResultReceivedQueue;
  private QueueConfig tsdTransferNotificationReceivedQueue;
  private QueueConfig tsdDeconsolidationNotificationReceivedQueue;

  private RabbitTemplate rabbitTemplate;
  private boolean registerRetryQueueListener;
  private ConfigurableBeanFactory beanFactory;

  public TSDEventConfig(ConfigurableBeanFactory beanFactory, RabbitTemplate rabbitTemplate) {

    this.beanFactory = beanFactory;
    this.rabbitTemplate = rabbitTemplate;

    exchangeConfig = new ExchangeConfig("tsd.events");

    tsdReceivedQueue =
        new QueueConfig(
            exchangeConfig,
            "tsd_received",
            "tsd.received.event",
            "tsdReceivedQueue",
            ENABLE_QUORUM_QUEUE);
    tsdActivateQueue =
        new QueueConfig(
            exchangeConfig,
            "tsd_activate",
            "tsd.activate.event",
            "tsdActivateQueue",
            ENABLE_QUORUM_QUEUE);
    tsdInvalidateQueue =
        new QueueConfig(
            exchangeConfig,
            "tsd_invalidate",
            "tsd.invalidate.event",
            "tsdInvalidateQueue",
            ENABLE_QUORUM_QUEUE);
    tsdTimerExpirationQueue =
        new QueueConfig(
            exchangeConfig,
            "tsd_timer_expiration",
            "tsd.timer.expiration.event",
            "tsdTimerExpirationQueue",
            ENABLE_QUORUM_QUEUE);
    tsdAmendmentQueue =
        new QueueConfig(
            exchangeConfig,
            "tsd_amendment",
            "tsd.amendment.event",
            "tsdAmendmentQueue",
            ENABLE_QUORUM_QUEUE);
    tsdRiskHitNotificationQueue =
        new QueueConfig(
            exchangeConfig,
            "tsd_risk_hit_notification",
            "tsd.risk.hit.notification.event",
            "tsdRiskHitNotificationQueue",
            ENABLE_QUORUM_QUEUE);
    tsdRiskAnalysisResultReceivedQueue =
        new QueueConfig(
            exchangeConfig,
            "tsd_risk_analysis_result",
            "tsd.risk.analysis.result.event",
            "tsdRiskAnalysisResultReceivedQueue",
            ENABLE_QUORUM_QUEUE);
    tsdControlResultReceivedQueue =
        new QueueConfig(
            exchangeConfig,
            "tsd_control_result",
            "tsd.control.result.event",
            "tsdControlResultReceivedQueue",
            ENABLE_QUORUM_QUEUE);
    tsdTransferNotificationReceivedQueue =
        new QueueConfig(
            exchangeConfig,
            "tsd_transfer_notification",
            "tsd.transfer.notification.event",
            "tsdTransferNotificationReceivedQueue",
            ENABLE_QUORUM_QUEUE);
    tsdDeconsolidationNotificationReceivedQueue =
        new QueueConfig(
            exchangeConfig,
            "tsd_deconsolidation_notification",
            "tsd.deconsolidation.notification.event",
            "tsdDeconsolidationNotificationReceivedQueue",
            ENABLE_QUORUM_QUEUE);
  }

  @PostConstruct
  public void init() {
    // can this be done more elegantly?
    exchangeConfig.registerBeanDefinitions(beanFactory);

    if (registerRetryQueueListener) {
      tsdReceivedQueue.registerBeanDefinitions(
          beanFactory, RABBIT_LISTENER_CONTAINER_FACTORY, rabbitTemplate, false);
      tsdActivateQueue.registerBeanDefinitions(
          beanFactory, RABBIT_LISTENER_CONTAINER_FACTORY, rabbitTemplate, false);
      tsdInvalidateQueue.registerBeanDefinitions(
          beanFactory, RABBIT_LISTENER_CONTAINER_FACTORY, rabbitTemplate, false);
      tsdTimerExpirationQueue.registerBeanDefinitions(
          beanFactory, RABBIT_LISTENER_CONTAINER_FACTORY, rabbitTemplate, false);
      tsdAmendmentQueue.registerBeanDefinitions(
          beanFactory, RABBIT_LISTENER_CONTAINER_FACTORY, rabbitTemplate, false);
      tsdRiskHitNotificationQueue.registerBeanDefinitions(
          beanFactory, RABBIT_LISTENER_CONTAINER_FACTORY, rabbitTemplate, false);
      tsdRiskAnalysisResultReceivedQueue.registerBeanDefinitions(
          beanFactory, RABBIT_LISTENER_CONTAINER_FACTORY, rabbitTemplate, false);
      tsdControlResultReceivedQueue.registerBeanDefinitions(
          beanFactory, RABBIT_LISTENER_CONTAINER_FACTORY, rabbitTemplate, false);
      tsdTransferNotificationReceivedQueue.registerBeanDefinitions(
          beanFactory, RABBIT_LISTENER_CONTAINER_FACTORY, rabbitTemplate, false);
      tsdDeconsolidationNotificationReceivedQueue.registerBeanDefinitions(
          beanFactory, RABBIT_LISTENER_CONTAINER_FACTORY, rabbitTemplate, false);
    } else {
      log.warn("RetryRoutingListener is not enabled for TsdEvents");
      tsdReceivedQueue.registerBeanDefinitions(beanFactory);
      tsdActivateQueue.registerBeanDefinitions(beanFactory);
      tsdInvalidateQueue.registerBeanDefinitions(beanFactory);
      tsdTimerExpirationQueue.registerBeanDefinitions(beanFactory);
      tsdAmendmentQueue.registerBeanDefinitions(beanFactory);
      tsdRiskHitNotificationQueue.registerBeanDefinitions(beanFactory);
      tsdRiskAnalysisResultReceivedQueue.registerBeanDefinitions(beanFactory);
      tsdControlResultReceivedQueue.registerBeanDefinitions(beanFactory);
      tsdTransferNotificationReceivedQueue.registerBeanDefinitions(beanFactory);
      tsdDeconsolidationNotificationReceivedQueue.registerBeanDefinitions(beanFactory);
    }
  }
}
