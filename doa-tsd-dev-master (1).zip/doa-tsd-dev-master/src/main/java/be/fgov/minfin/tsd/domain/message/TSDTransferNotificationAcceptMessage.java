/*
 * @(#) be.fgov.minfin.tsd.domain.message.TSDTransferNotificationAcceptMessage.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties
 * or made public without prior and written consent of SPF Finances.
 * ===========================================================================
 */
package be.fgov.minfin.tsd.domain.message;

import be.fgov.minfin.tsd.domain.model.BusinessValidationType;
import be.fgov.minfin.tsd.domain.model.CustomsOffice;
import be.fgov.minfin.tsd.domain.model.TSDStatus;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.party.Party;
import be.fgov.minfin.tsd.domain.model.party.PersonPresentingTheGoods;
import be.fgov.minfin.tsd.domain.model.party.Representative;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Value;

@Builder
@Value
public class TSDTransferNotificationAcceptMessage {

  private MessageHeader messageHeader;

  private String lrn;

  private String mrn;

  private LocalDateTime notificationDate;

  private TSDStatus status;

  private BusinessValidationType businessValidationType;

  private Party declarant;

  private Representative representative;

  private PersonPresentingTheGoods personPresentingTheGoods;

  private CustomsOffice supervisingCustomsOffice;

  private TemporaryStorageDeclaration declaration;
}
