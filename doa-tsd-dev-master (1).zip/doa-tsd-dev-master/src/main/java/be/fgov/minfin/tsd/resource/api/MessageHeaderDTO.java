/*
 * @(#) be.fgov.minfin.tsd.resource.api.MessageHeaderDTO.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */

package be.fgov.minfin.tsd.resource.api;

import be.fgov.minfin.tsd.domain.validation.annotation.IsoTimestamp;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonRootName;
import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import lombok.Builder;
import lombok.Value;

/** MessageHeader */
@Value
@Builder(toBuilder = true)
@JsonRootName("messageHeader")
@JsonInclude(Include.NON_EMPTY)
public class MessageHeaderDTO {
  @NotNull
  @Size(min = 1, max = 35)
  @Schema(example = "system@REF123456789")
  private String sender;

  @NotNull
  @Size(min = 1, max = 35)
  @Schema(example = "TSD")
  private String recipient;

  @IsoTimestamp
  @NotNull
  @Schema(example = "2020-06-01T18:44:22.010203000Z")
  private String messageTimestamp;

  @NotNull
  @Size(min = 1, max = 291)
  @Schema(example = "e3b63602-a433-11ea-bb37-0242ac130002.acme-corp.com")
  private String messageId;

  @Size(min = 1, max = 291)
  @Schema(example = "f8251e32-a433-11ea-bb37-0242ac130002.acme-corp.com")
  private String refToMessageId;

  @Size(min = 0, max = 36)
  @Schema(example = "00783ecaa434-11ea-bb37-0242ac130002")
  private String correlationId;

  @Pattern(regexp = ".{2}")
  @Schema(example = "EN")
  private String languageCode;
}
