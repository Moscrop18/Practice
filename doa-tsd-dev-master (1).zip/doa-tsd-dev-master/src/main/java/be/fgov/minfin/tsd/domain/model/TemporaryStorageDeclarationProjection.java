package be.fgov.minfin.tsd.domain.model;

import java.time.LocalDateTime;

// A advanced tsd search projection.

public interface TemporaryStorageDeclarationProjection {

  Long getId();

  String getLrn();

  ReferenceNumber getReferenceNumber();

  interface ReferenceNumber {
    MRN getMrn();

    CRN getCrn();

    Long getDraftAmendmentId();

    Long getDeconsolidatedTSDId();

    interface MRN {
      String getMrnNumber();
    }

    interface CRN {
      String getCrnNumber();
    }
  }

  TemporaryStorageDeclarationType getType();

  TSDStatus getCurrentStatus();

  Integer getCurrentVersion();

  LocalDateTime getRegistrationDate();

  Party getDeclarant();

  interface Party {
    String getIdentificationNumber();

    String getName();
  }

  Representative getRepresentative();

  interface Representative {
    String getIdentificationNumber();

    String getName();
  }

  String getLinkedPnFrn();

  TransferNotification getTransferNotification();

  interface TransferNotification {
    Long getId();
  }
}
