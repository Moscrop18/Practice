/*
 * @(#) be.fgov.minfin.tsd.domain.model.consignment.TransportEquipment.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model.consignment;

import be.fgov.minfin.tsd.domain.validation.annotation.CodeList;
import be.fgov.minfin.tsd.domain.validation.annotation.NumberCompare;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import be.fgov.minfin.tsd.domain.validation.annotation.group.DeconsolidationNotificationValidatorGroup;
import be.fgov.minfin.tsd.domain.validation.annotation.group.NonDraftTSD;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import be.fgov.minfin.tsd.domain.validation.codelist.TSDCodeLists;
import be.fgov.minfin.tsd.util.NumberCompareType;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.groups.Default;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "TRANSPORT_EQUIPMENT")
@EqualsAndHashCode(exclude = {"consignmentItem", "consignment"})
@ValidateBusinessRules(groups = {Default.class, DeconsolidationNotificationValidatorGroup.class})
public class TransportEquipment {
  @GeneratedValue(generator = "TRANSPORT_EQUIPMENT_SEQ")
  @SequenceGenerator(name = "TRANSPORT_EQUIPMENT_SEQ", sequenceName = "TRANSPORT_EQUIPMENT_SEQ")
  @Id
  private Long id;

  @Column(name = "CONTAINER_ID_NUMBER")
  @NotNull(groups = NonDraftTSD.class)
  private String containerIdentificationNumber;

  private @CodeList(
      value = TSDCodeLists.CL709,
      groups = {Default.class, DeconsolidationNotificationValidatorGroup.class}) String
      containerPackedStatus;

  @NumberCompare(
      numberCompareType = NumberCompareType.GREATER_THAN,
      value = 0,
      groups = {Default.class, DeconsolidationNotificationValidatorGroup.class},
      errorCode = ErrorCode.TSPNESXXR0041)
  private Integer numberOfSeals;

  @OneToMany(
      cascade = {CascadeType.PERSIST, CascadeType.MERGE},
      orphanRemoval = true,
      mappedBy = "transportEquipment")
  @ToString.Exclude
  @JsonManagedReference
  private List<@Valid Seal> seal;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "CONSIGNMENT_ID")
  @JsonBackReference(value = "consignment")
  private Consignment consignment;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "CONSIGNMENT_ITEM_ID")
  @JsonBackReference(value = "consignmentItem")
  private ConsignmentItem consignmentItem;
}
