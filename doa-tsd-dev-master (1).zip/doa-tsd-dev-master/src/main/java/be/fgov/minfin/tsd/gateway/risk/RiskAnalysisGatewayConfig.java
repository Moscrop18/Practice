/*
 * @(#)be.fgov.minfin.tsd.gateway.risk.RiskAnalysisGatewayConfig.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.risk;

import static be.fgov.minfin.tsd.config.RabbitConfig.ENABLE_QUORUM_QUEUE;
import static be.fgov.minfin.tsd.config.RabbitConfig.RABBIT_LISTENER_CONTAINER_FACTORY;

import be.fgov.minfin.libdoa.amqp.ExchangeConfig;
import be.fgov.minfin.libdoa.amqp.transactional.QueueConfig;
import be.fgov.minfin.tsd.gateway.risk.plugin.DefaultRiskAnalysisPluginConfig;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.boot.context.properties.NestedConfigurationProperty;
import org.springframework.context.annotation.Configuration;

@Slf4j
@Setter
@Getter
@Configuration("riskAnalysisGatewayConfig")
public class RiskAnalysisGatewayConfig {

  public static final String SEND_RISK_ANALYSIS_QUEUE = "#{sendRiskAnalysisQueue}";
  public static final String SEND_RISK_ANALYSIS_CONCURRENCY_VALUE =
      "#{riskAnalysisGatewayConfig.sendRiskAnalysisQueue.concurrentConsumers}";

  public static final String SEND_INVALIDATION_QUEUE = "#{sendRiskInvalidationQueue}";
  public static final String SEND_INVALIDATION_CONCURRENCY_VALUE =
      "#{riskAnalysisGatewayConfig.sendRiskInvalidationQueue.concurrentConsumers}";

  @NestedConfigurationProperty private final DefaultRiskAnalysisPluginConfig defaultplugin;

  private ExchangeConfig exchange;
  private QueueConfig sendRiskAnalysisQueue;
  private QueueConfig sendRiskInvalidationQueue;

  private ConfigurableBeanFactory beanFactory;
  private RabbitTemplate rabbitTemplate;
  private boolean registerRetryQueueListener;

  public RiskAnalysisGatewayConfig(
      ConfigurableBeanFactory beanFactory,
      DefaultRiskAnalysisPluginConfig defaultplugin,
      RabbitTemplate rabbitTemplate) {
    this.beanFactory = beanFactory;
    this.defaultplugin = defaultplugin;
    this.rabbitTemplate = rabbitTemplate;
    exchange = new ExchangeConfig("tsd.risk.gateway");
    sendRiskAnalysisQueue =
        new QueueConfig(
            exchange,
            "tsd_out_send_risk_analysis",
            "send.tsd.risk.analysis",
            "sendRiskAnalysisQueue",
            ENABLE_QUORUM_QUEUE);
    sendRiskInvalidationQueue =
        new QueueConfig(
            exchange,
            "tsd_out_send_risk_invalidation",
            "send.tsd.risk.invalidation",
            "sendRiskInvalidationQueue",
            ENABLE_QUORUM_QUEUE);
  }

  public void init() {
    // can this be done more elegantly?
    exchange.registerBeanDefinitions(beanFactory);
    if (registerRetryQueueListener) {
      sendRiskAnalysisQueue.registerBeanDefinitions(
          beanFactory, RABBIT_LISTENER_CONTAINER_FACTORY, rabbitTemplate, false);
      sendRiskInvalidationQueue.registerBeanDefinitions(
          beanFactory, RABBIT_LISTENER_CONTAINER_FACTORY, rabbitTemplate, false);
    } else {
      log.warn("RetryRoutingListener is not enabled for RiskAnalysisGateway");
      sendRiskAnalysisQueue.registerBeanDefinitions(beanFactory);
      sendRiskInvalidationQueue.registerBeanDefinitions(beanFactory);
    }
  }
}
