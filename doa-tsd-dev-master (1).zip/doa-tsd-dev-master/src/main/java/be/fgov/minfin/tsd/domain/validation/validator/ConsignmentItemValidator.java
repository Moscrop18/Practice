/*
 * @(#) be.fgov.minfin.tsd.domain.validation.validator.ConsignmentItemValidator.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation.validator;

import static be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclarationType.COMBINED;
import static be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclarationType.PRELODGED;
import static be.fgov.minfin.tsd.util.StreamUtil.areAllSame;

import be.fgov.minfin.libdoa.commons.lang.Now;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.consignment.Consignment;
import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentHeader;
import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentItem;
import be.fgov.minfin.tsd.domain.model.consignment.HasPreviousDocument;
import be.fgov.minfin.tsd.domain.model.consignment.HouseConsignment;
import be.fgov.minfin.tsd.domain.model.consignment.PreviousDocument;
import be.fgov.minfin.tsd.domain.model.consignment.TransportDocument;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import be.fgov.minfin.tsd.domain.validation.config.ValidationConfig;
import be.fgov.minfin.tsd.domain.validation.message.MessageType;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.validator.constraintvalidation.HibernateConstraintValidatorContext;
import org.springframework.stereotype.Component;

/**
 * This class is used to validate TSD ConsignmentItem
 *
 * @author NamrataGupta
 */
@Component
public class ConsignmentItemValidator extends BaseConstraintValidator
    implements ConstraintValidator<ValidateBusinessRules, TemporaryStorageDeclaration> {
  private static final String CONSIGNMENT_ITEM_MASTER_LEVEL = "consignmentItemMasterLevel[";
  private static final String CONSIGNMENT_ITEM_HOUSE_LEVEL = "consignmentItemHouseLevel[";
  private static final String CONSIGNMENT_HOUSE_LEVEL = "consignmentHouseLevel[";
  private static final String CONSIGNMENT_MASTER_LEVEL = "consignmentMasterLevel";
  private static final String TYPE = "type";
  private static final String PREVIOUS_DOCUMENT = "previousDocument";
  private static final String TYPE_OF_LOCATION = "typeOfLocation";
  private static final String LOCATION_OF_GOODS = "locationOfGoods";
  private static final String MASTER_CONSIGNMENT = "masterConsignment";
  private static final String HOUSE_CONSIGNMENT = "houseConsignments";
  private static final String CONSIGNOR = "consignor";
  private static final String CONSIGNEE = "consignee";
  private static final String TOTAL_GROSS_MASS = "totalGrossMass";
  private static final String HEADER_MASTER_LEVEL = "consignmentHeader";
  private static final String DOC_TYPE_N355 = "N355";
  private static final String N821 = "N821";
  private static final String PRESENTATION_DATETIME = "dateAndTimeOfPresentationOfTheGoods";
  private static final String DECLARATION_DATE = "declarationDate";

  @Override
  public boolean isValid(TemporaryStorageDeclaration tsd, ConstraintValidatorContext context) {
    AtomicBoolean isValid = new AtomicBoolean(true);
    MessageType messageType =
        context
            .unwrap(HibernateConstraintValidatorContext.class)
            .getConstraintValidatorPayload(MessageType.class);

    if (messageType != MessageType.DECONSOLIDATION_NOTIFICATION_MESSAGE
        && (null == tsd.getEnsReUseIndicator()
            || (tsd.getEnsReUseIndicator() != null && !tsd.getEnsReUseIndicator().equals("1")))) {
      validateConsignmentItem(tsd, context, isValid);

      validateTotalGrossMass(tsd, context, isValid);

      validateConsignor(tsd, context, isValid);

      validateConsignee(tsd, context, isValid);
    }

    // TO DO discuss witrh
    validateTSDdateAndTimeOfPresentation(tsd, context, isValid, messageType);
    if (messageType != MessageType.TSD_AMENDMENT_MESSAGE) {
      if (messageType != MessageType.DECONSOLIDATION_NOTIFICATION_MESSAGE) {
        validateMasterConsignmentGoodsNumber(tsd, context, isValid);
      }

      validateHouseConsignmentGoodsNumber(tsd, context, isValid);
    }

    validateHouseTransportDocumnetUniqueness(tsd, context, isValid);

    validateConsignmentPreviousDocument(tsd, context, isValid);

    if (tsd.getType() == PRELODGED) {
      if (messageType != MessageType.TSD_AMENDMENT_MESSAGE) {
        validatePreLodgeTSDMasterConsPrevDocTypeValues(tsd, context, isValid);
        validatePreLodgeTSDHouseConsPrevDocTypeValues(tsd, context, isValid);
      }
      validatePlaceOfUnloadingOrLocOfGoodsExist(tsd, context, isValid);
      validateTypeOfLocationForPreLodgeTSD(tsd, context, isValid);

    } else if (tsd.getType() == COMBINED && messageType != MessageType.TSD_AMENDMENT_MESSAGE) {
      validateCombinedTSDMasterConsPrevDocTypeValues(tsd, context, isValid);
      validateCombinedTSDHouseConsPrevDocTypeValues(tsd, context, isValid);
    }

    if (tsd.getType() == PRELODGED || messageType == MessageType.TSD_AMENDMENT_MESSAGE) {
      validateUniquePreviousDocument(tsd, context, isValid);
      validateMax1PreviousDocumentType(tsd, context, isValid);
    }

    return isValid.get();
  }

  /***
   * This method is used to validate for PRELODGED and AMENDMENT TSD, if at least
   * 1 CONSIGNMENT in the Temporary Storage Declaration contains a PREVIOUS
   * DOCUMENT of Type = 'N821', then exactly 1 PREVIOUS DOCUMENT of Type = ‘N821’
   * is required for each CONSIGNMENT. Additionally, the PREVIOUS DOCUMENT
   * (identified by ‘PREVIOUS DOCUMENT/Reference number’ and ‘PREVIOUS
   * DOCUMENT/Type’) needs to be unique throughout all CONSIGNMENTs.
   *
   * @param tsd
   * @param context
   * @param isValid
   */
  private void validateUniquePreviousDocument(
      TemporaryStorageDeclaration tsd, ConstraintValidatorContext context, AtomicBoolean isValid) {

    List<Consignment> consignments = tsd.getConsignments();
    if (consignments.isEmpty()) return; // return if no consignments

    List<ConsignmentItem> consignmentItems =
        consignments.stream()
            .map(Consignment::getConsignmentItem)
            .filter(Objects::nonNull)
            .flatMap(Collection::stream)
            .toList();
    if (consignmentItems.isEmpty()) return; // return if no consignmentItems

    Supplier<Stream<PreviousDocument>> previousDocuments =
        () ->
            Stream.<HasPreviousDocument>concat(consignments.stream(), consignmentItems.stream())
                .map(HasPreviousDocument::getPreviousDocument)
                .filter(Objects::nonNull);
    if (previousDocuments.get() == null) return; // return if no previousDocuments

    // at least one consignment /cons item in entire tsd contains a N821
    boolean isN821used = previousDocuments.get().anyMatch(pd -> N821.equals(pd.getType()));

    if (isN821used
        &&
        // not each consignment (or its items) has one prev doc of type N821
        (!consignments.stream().allMatch(allItemsHavePreviousDocumentOfType(N821))
            || !allPreviousDocumentRefNumAndTypeCombinationsAreSame(previousDocuments.get()))) {
      isValid.set(false);
      addViolation(context, ErrorCode.TSPNESXXR0162, HEADER_MASTER_LEVEL);
    }
  }

  /** each previous Document + type combination is same */
  private boolean allPreviousDocumentRefNumAndTypeCombinationsAreSame(
      Stream<PreviousDocument> previousDocumentStreamSupplier) {
    return areAllSame(
        previousDocumentStreamSupplier.map(pd -> pd.getReferenceNumber() + pd.getType()));
  }

  /**
   * Check if the CONSIGNMENT has a given previousDocument type. When the previous document is not
   * provided at CONSIGNMENT level, then it needs to be provided for each item (at item level)
   * within the CONSIGNMENT.
   *
   * @return
   */
  private Predicate<? super Consignment> allItemsHavePreviousDocumentOfType(final String type) {
    return consignment ->
        consignment.getPreviousDocument() != null
            ? type.equals(consignment.getPreviousDocument().getType())
            : getPreviousDocumentType(type, consignment);
  }

  /***
   * This method is used to get the 'CONSIGNMENT ITEM/PREVIOUS DOCUMENT/TYPE' when
   * the CONSIGNMENT ITEM is not NULL
   *
   * @param type
   * @param consignment
   * @return
   */
  private boolean getPreviousDocumentType(final String type, Consignment consignment) {
    return consignment.getConsignmentItem() != null
        && consignment.getConsignmentItem().stream()
            .map(ConsignmentItem::getPreviousDocument)
            .allMatch(pd -> pd != null && type.equals(pd.getType()));
  }

  /***
   * This method is used to validate for PRELODGED and AMENDMENT TSD, maximum 1
   * ‘PREVIOUS DOCUMENT/Type’ is allowed throughout all CONSIGNMENTs.
   *
   * @param tsd
   * @param context
   * @param isValid
   */
  private void validateMax1PreviousDocumentType(
      TemporaryStorageDeclaration tsd, ConstraintValidatorContext context, AtomicBoolean isValid) {

    List<Consignment> consignments = tsd.getConsignments();
    if (consignments.isEmpty()) return; // return if no consignments

    List<ConsignmentItem> consignmentItems =
        consignments.stream()
            .map(Consignment::getConsignmentItem)
            .filter(Objects::nonNull)
            .flatMap(Collection::stream)
            .toList();
    if (consignmentItems.isEmpty()) return; // return if no consignments

    long distinctPreviousDocumentTypes =
        Stream.<HasPreviousDocument>concat(consignments.stream(), consignmentItems.stream())
            .map(HasPreviousDocument::getPreviousDocument)
            .filter(Objects::nonNull)
            .map(PreviousDocument::getType)
            .distinct()
            .count();

    // only 0 (no prev doc type) and 1 (one same prev doc type) are allowed
    if (distinctPreviousDocumentTypes > 1) {
      isValid.set(false);
      addViolation(context, ErrorCode.TSPNESXXR0163, HEADER_MASTER_LEVEL);
    }
  }

  private void validateTSDdateAndTimeOfPresentation(
      TemporaryStorageDeclaration tsd,
      ConstraintValidatorContext context,
      AtomicBoolean isValid,
      MessageType messageType) {
    ValidationConfig validationConfig = new ValidationConfig();
    if (messageType != MessageType.TSD_AMENDMENT_MESSAGE) {
      LocalDateTime receptionTimestamp = Now.localDateTime();
      if (null != tsd.getMessageInformation()) {
        receptionTimestamp = tsd.getMessageInformation().getReceptionTimestamp();
      }
      if (null != tsd.getDateAndTimeOfPresentationOfTheGoods()
          && (tsd.getDateAndTimeOfPresentationOfTheGoods().isAfter(receptionTimestamp)
              || tsd.getDateAndTimeOfPresentationOfTheGoods()
                  .isBefore(
                      receptionTimestamp
                          .minusHours(validationConfig.getPresentationOfGoodsDateExpiryInHours())
                          .plusSeconds(1)))) {
        isValid.set(false);
        addViolation(context, ErrorCode.TSPNESXXR0069, PRESENTATION_DATETIME);
      }
      if (null != tsd.getDeclarationDate()
          && (tsd.getDeclarationDate().isAfter(receptionTimestamp)
              || tsd.getDeclarationDate()
                  .isBefore(
                      receptionTimestamp
                          .minusHours(validationConfig.getDeclarationDateExpiryInHours())
                          .plusSeconds(1)))) {
        isValid.set(false);
        addViolation(context, ErrorCode.TSPNESXXR0071, DECLARATION_DATE);
      }
    }
    if (null != tsd.getDeclarationDate()
        && null != tsd.getDateAndTimeOfPresentationOfTheGoods()
        && tsd.getDeclarationDate().compareTo(tsd.getDateAndTimeOfPresentationOfTheGoods()) == 0) {
      isValid.set(false);
      addViolation(context, ErrorCode.TSPNESXXC0070, DECLARATION_DATE);
    }
  }

  /**
   * This method is to validate that for Pre-lodged TSD only N335, N821 can be used as Previous
   * document Type at Master Consignment level.
   *
   * @param tsd
   * @param context
   * @param isValid
   */
  private void validatePreLodgeTSDMasterConsPrevDocTypeValues(
      TemporaryStorageDeclaration tsd, ConstraintValidatorContext context, AtomicBoolean isValid) {
    List<String> documentTypeList = List.of("N355", "N821");
    if (null == tsd.getMasterConsignment()) return;
    if (null != tsd.getMasterConsignment().getPreviousDocument()) {
      PreviousDocument document = tsd.getMasterConsignment().getPreviousDocument();
      if (!documentTypeList.contains(document.getType())) {
        isValid.set(false);
        addViolation(
            context,
            ErrorCode.TSPNESXXR0130,
            HEADER_MASTER_LEVEL,
            CONSIGNMENT_MASTER_LEVEL,
            PREVIOUS_DOCUMENT,
            TYPE);
      }
    }
    validateConsignmentItemPrevDoc(
        tsd.getMasterConsignment(),
        context,
        isValid,
        documentTypeList,
        -1,
        ErrorCode.TSPNESXXR0130);
  }

  /**
   * This method is to validate that for combined TSD only N355 can be used as Previous document
   * Type at Master Consignment level.
   *
   * @param tsd
   * @param context
   * @param isValid
   */
  private void validateCombinedTSDMasterConsPrevDocTypeValues(
      TemporaryStorageDeclaration tsd, ConstraintValidatorContext context, AtomicBoolean isValid) {
    if (null == tsd.getMasterConsignment()) return;
    if (null != tsd.getMasterConsignment().getPreviousDocument()) {
      PreviousDocument document = tsd.getMasterConsignment().getPreviousDocument();
      if (!document.getType().equalsIgnoreCase(DOC_TYPE_N355)) {
        isValid.set(false);
        addViolation(
            context,
            ErrorCode.TSPNESXXR0131,
            HEADER_MASTER_LEVEL,
            CONSIGNMENT_MASTER_LEVEL,
            PREVIOUS_DOCUMENT,
            TYPE);
      }
    }
    validateConsignmentItemPrevDoc(
        tsd.getMasterConsignment(),
        context,
        isValid,
        List.of(DOC_TYPE_N355),
        -1,
        ErrorCode.TSPNESXXR0131);
  }

  /**
   * This method is to validate that for Pre-lodged TSD only N335, N821 can be used as Previous
   * document Type at Master and House Consignment level.
   *
   * @param consignment
   * @param context
   * @param isValid
   * @param documentTypeList
   * @param indexOfConsignment
   */
  private void validateConsignmentItemPrevDoc(
      Consignment consignment,
      ConstraintValidatorContext context,
      AtomicBoolean isValid,
      List<String> documentTypeList,
      int indexOfConsignment,
      ErrorCode errorCode) {
    if (null == consignment.getConsignmentItem()) return;
    int currentIndexOfConsignmentItem = 0;
    for (ConsignmentItem consItem : consignment.getConsignmentItem()) {
      if (consItem.getPreviousDocument() != null
          && !documentTypeList.contains(consItem.getPreviousDocument().getType())) {
        isValid.set(false);
        addViolationAsPerConsignmentLevel(
            context, indexOfConsignment, currentIndexOfConsignmentItem, errorCode);
      }
      currentIndexOfConsignmentItem++;
    }
  }

  /**
   * This method is used to add violation as per the value of indexOfConsignment variable. if
   * indexOfConsignment is -1 than it belongs to Master Consignment Item level. Else it belongs to
   * House Consignment Item level.
   *
   * @param context
   * @param indexOfConsignment
   * @param indexOfConsignmentItem
   */
  private void addViolationAsPerConsignmentLevel(
      ConstraintValidatorContext context,
      int indexOfConsignment,
      int indexOfConsignmentItem,
      ErrorCode errorCode) {
    if (indexOfConsignment == -1) {
      addViolation(
          context,
          errorCode,
          HEADER_MASTER_LEVEL,
          CONSIGNMENT_MASTER_LEVEL,
          CONSIGNMENT_ITEM_MASTER_LEVEL + indexOfConsignmentItem + "]",
          PREVIOUS_DOCUMENT,
          TYPE);
    } else {
      addViolation(
          context,
          errorCode,
          HEADER_MASTER_LEVEL,
          CONSIGNMENT_HOUSE_LEVEL + indexOfConsignment + "]",
          CONSIGNMENT_ITEM_HOUSE_LEVEL + indexOfConsignmentItem + "]",
          PREVIOUS_DOCUMENT,
          TYPE);
    }
  }

  /**
   * This method is to validate that for Pre-lodged TSD only N335, N821 can be used as Previous
   * document Type at House Consignment level.
   *
   * @param tsd
   * @param context
   * @param isValid
   */
  private void validatePreLodgeTSDHouseConsPrevDocTypeValues(
      TemporaryStorageDeclaration tsd, ConstraintValidatorContext context, AtomicBoolean isValid) {
    if (CollectionUtils.isEmpty(tsd.getHouseConsignments())) return;
    List<String> documentTypeList = List.of("N355", "N821");
    int currentIndexHouse = 0;
    for (HouseConsignment houseConsignment : tsd.getHouseConsignments()) {
      if (null != houseConsignment.getPreviousDocument()) {
        if (!documentTypeList.contains(houseConsignment.getPreviousDocument().getType())) {
          isValid.set(false);
          addViolation(
              context,
              ErrorCode.TSPNESXXR0130,
              HEADER_MASTER_LEVEL,
              CONSIGNMENT_HOUSE_LEVEL + currentIndexHouse + "]",
              PREVIOUS_DOCUMENT,
              TYPE);
        }
        validateConsignmentItemPrevDoc(
            houseConsignment,
            context,
            isValid,
            documentTypeList,
            currentIndexHouse,
            ErrorCode.TSPNESXXR0130);
      }
      currentIndexHouse++;
    }
  }

  /**
   * This method is to validate that for combined TSD only N335 can be used as Previous document
   * Type at House Consignment level.
   *
   * @param tsd
   * @param context
   * @param isValid
   */
  private void validateCombinedTSDHouseConsPrevDocTypeValues(
      TemporaryStorageDeclaration tsd, ConstraintValidatorContext context, AtomicBoolean isValid) {

    if (CollectionUtils.isEmpty(tsd.getHouseConsignments())) return;
    int currentIndexHouse = 0;
    for (HouseConsignment houseConsignment : tsd.getHouseConsignments()) {

      if (null != houseConsignment.getPreviousDocument()) {
        if (!houseConsignment.getPreviousDocument().getType().equalsIgnoreCase(DOC_TYPE_N355)) {
          isValid.set(false);
          addViolation(
              context,
              ErrorCode.TSPNESXXR0131,
              HEADER_MASTER_LEVEL,
              CONSIGNMENT_HOUSE_LEVEL + currentIndexHouse + "]",
              PREVIOUS_DOCUMENT,
              TYPE);
        }
        validateConsignmentItemPrevDoc(
            houseConsignment,
            context,
            isValid,
            List.of(DOC_TYPE_N355),
            currentIndexHouse,
            ErrorCode.TSPNESXXR0131);
      }
      currentIndexHouse++;
    }
  }

  private void validateHouseTransportDocumnetUniqueness(
      TemporaryStorageDeclaration tsd, ConstraintValidatorContext context, AtomicBoolean isValid) {
    List<String> documentList = new ArrayList<>();

    if (null != tsd.getMasterConsignment()) {
      TransportDocument document = tsd.getMasterConsignment().getTransportDocument();
      addDocumentToList(documentList, document);
    }

    if (!CollectionUtils.isEmpty(tsd.getHouseConsignments())) {
      for (HouseConsignment item : tsd.getHouseConsignments()) {
        TransportDocument document = item.getTransportDocument();
        addDocumentToList(documentList, document);
      }
    }
    countFrequencies(documentList, context, isValid);
  }

  private void countFrequencies(
      List<String> list, ConstraintValidatorContext context, AtomicBoolean isValid) {
    Set<String> documentSet = new HashSet<>(list);
    for (String s : documentSet) {
      if (Collections.frequency(list, s) > 1) {
        isValid.set(false);
        addViolation(context, ErrorCode.TSPNESXXR0048, HEADER_MASTER_LEVEL);
      }
    }
  }

  private void addDocumentToList(List<String> documentList, TransportDocument document) {
    if (null != document && null != document.getReferenceNumber() && null != document.getType()) {
      documentList.add(
          document.getReferenceNumber().toLowerCase() + document.getType().toLowerCase());
    }
  }

  /**
   * This method is to check if PlaceOfUnloading and LocationOfGoods both have been used or not
   *
   * @param tsd
   * @param context
   * @param isValid
   */
  private void validatePlaceOfUnloadingOrLocOfGoodsExist(
      TemporaryStorageDeclaration tsd, ConstraintValidatorContext context, AtomicBoolean isValid) {
    ConsignmentHeader consHeader = tsd.getConsignmentHeader();
    if (null == consHeader) return;
    if (null == consHeader.getDecalaredlocationOfGoods()
        && null == consHeader.getPlaceOfUnloading()) {
      isValid.set(false);
      addViolation(context, ErrorCode.TSPNESXXC0058, HEADER_MASTER_LEVEL, LOCATION_OF_GOODS);
    }
  }

  private void validateTypeOfLocationForPreLodgeTSD(
      TemporaryStorageDeclaration tsd, ConstraintValidatorContext context, AtomicBoolean isValid) {
    ConsignmentHeader consHeader = tsd.getConsignmentHeader();
    if (null == consHeader) return;
    if (null == consHeader.getDecalaredlocationOfGoods()) return;

    String typeOfLocation = consHeader.getDecalaredlocationOfGoods().getTypeOfLocation();
    List<String> preLodgeTsdTypeOfLocationList = List.of("A", "B", "C");
    if (!StringUtils.isEmpty(typeOfLocation)
        && !preLodgeTsdTypeOfLocationList.contains(typeOfLocation)) {
      isValid.set(false);
      addViolation(
          context,
          ErrorCode.TSPNESXXR0120,
          HEADER_MASTER_LEVEL,
          LOCATION_OF_GOODS,
          TYPE_OF_LOCATION);
    }
  }

  private void validateHouseConsignmentGoodsNumber(
      TemporaryStorageDeclaration tsd, ConstraintValidatorContext context, AtomicBoolean isValid) {
    if (!CollectionUtils.isEmpty(tsd.getHouseConsignments())) {
      int currentIndexHouse = 0;
      for (HouseConsignment item : tsd.getHouseConsignments()) {
        List<ConsignmentItem> itemsList = item.getConsignmentItem();
        checkSequenceOfGoodsNumber(context, isValid, currentIndexHouse, itemsList);
        currentIndexHouse++;
      }
    }
  }

  private void checkSequenceOfGoodsNumber(
      ConstraintValidatorContext context,
      AtomicBoolean isValid,
      int currentIndexHouse,
      List<ConsignmentItem> itemsList) {
    if (CollectionUtils.isEmpty(itemsList)) return;
    for (int i = 0; i < itemsList.size(); i++) {
      if (itemsList.get(i).getGoodsItemNumber() != null
          && itemsList.get(i).getGoodsItemNumber() != i + 1) {
        addViolation(
            context,
            ErrorCode.TSPNESXXR0024,
            HEADER_MASTER_LEVEL,
            CONSIGNMENT_HOUSE_LEVEL + currentIndexHouse + "]");
        isValid.set(false);
      }
    }
  }

  private void validateMasterConsignmentGoodsNumber(
      TemporaryStorageDeclaration tsd, ConstraintValidatorContext context, AtomicBoolean isValid) {
    if (null != tsd.getMasterConsignment()
        && null != tsd.getMasterConsignment().getConsignmentItem()
        && !tsd.getMasterConsignment().getConsignmentItem().isEmpty()) {
      List<ConsignmentItem> itemsList = tsd.getMasterConsignment().getConsignmentItem();
      for (int i = 0; i < itemsList.size(); i++) {
        if (itemsList.get(i).getGoodsItemNumber() != null
            && itemsList.get(i).getGoodsItemNumber() != i + 1) {
          addViolation(context, ErrorCode.TSPNESXXR0023, MASTER_CONSIGNMENT);
          isValid.set(false);
        }
      }
    }
  }

  private void validateConsignor(
      TemporaryStorageDeclaration tsd, ConstraintValidatorContext context, AtomicBoolean isValid) {
    if (null != tsd.getMasterConsignment() && null == tsd.getMasterConsignment().getConsignor()) {
      isValid.set(false);
      addViolation(context, ErrorCode.TSPNESXXC0098, MASTER_CONSIGNMENT, CONSIGNOR);
    }

    if (!CollectionUtils.isEmpty(tsd.getHouseConsignments())) {
      List<HouseConsignment> houseConsItems =
          tsd.getHouseConsignments().stream()
              .filter(x -> x.getConsignor() == null)
              .collect(Collectors.toList());
      if (!CollectionUtils.isEmpty(houseConsItems)) {
        isValid.set(false);
        addViolation(context, ErrorCode.TSPNESXXC0098, HOUSE_CONSIGNMENT, CONSIGNOR);
      }
    }
  }

  private void validateConsignee(
      TemporaryStorageDeclaration tsd, ConstraintValidatorContext context, AtomicBoolean isValid) {
    if (null != tsd.getMasterConsignment() && null == tsd.getMasterConsignment().getConsignee()) {
      isValid.set(false);
      addViolation(context, ErrorCode.TSPNESXXC0098, MASTER_CONSIGNMENT, CONSIGNEE);
    }

    if (!CollectionUtils.isEmpty(tsd.getHouseConsignments())) {
      List<HouseConsignment> houseConsItems =
          tsd.getHouseConsignments().stream()
              .filter(x -> x.getConsignee() == null)
              .collect(Collectors.toList());
      if (!CollectionUtils.isEmpty(houseConsItems)) {
        isValid.set(false);
        addViolation(context, ErrorCode.TSPNESXXC0098, HOUSE_CONSIGNMENT, CONSIGNEE);
      }
    }
  }

  private void validateTotalGrossMass(
      TemporaryStorageDeclaration tsd, ConstraintValidatorContext context, AtomicBoolean isValid) {
    if (null != tsd.getMasterConsignment()
        && null == tsd.getMasterConsignment().getTotalGrossMass()) {
      isValid.set(false);
      addViolation(context, ErrorCode.TSPNESXXC0098, MASTER_CONSIGNMENT, TOTAL_GROSS_MASS);
    }

    if (!CollectionUtils.isEmpty(tsd.getHouseConsignments())) {
      List<HouseConsignment> houseConsItems =
          tsd.getHouseConsignments().stream()
              .filter(x -> (x.getTotalGrossMass() == null))
              .collect(Collectors.toList());
      if (!CollectionUtils.isEmpty(houseConsItems)) {
        isValid.set(false);
        addViolation(context, ErrorCode.TSPNESXXC0098, HOUSE_CONSIGNMENT, TOTAL_GROSS_MASS);
      }
    }
  }

  private void validateConsignmentItem(
      TemporaryStorageDeclaration tsd, ConstraintValidatorContext context, AtomicBoolean isValid) {

    if (null == tsd.getMasterConsignment() && CollectionUtils.isEmpty(tsd.getHouseConsignments())) {
      isValid.set(false);
      addViolation(context, ErrorCode.TSPNESXXR0044, HEADER_MASTER_LEVEL);
    }
    boolean isCiFoundOnMaster = false;
    boolean isCiFoundOnAllHouse = false;
    if (null != tsd.getMasterConsignment()
        && !CollectionUtils.isEmpty(tsd.getMasterConsignment().getConsignmentItem())) {
      isCiFoundOnMaster = true;
    }
    if (!CollectionUtils.isEmpty(tsd.getHouseConsignments())) {
      List<HouseConsignment> houseConsItems =
          tsd.getHouseConsignments().stream()
              .filter(x -> CollectionUtils.isEmpty(x.getConsignmentItem()))
              .collect(Collectors.toList());
      if (CollectionUtils.isEmpty(houseConsItems)) {
        isCiFoundOnAllHouse = true;
      }
    }
    if ((CollectionUtils.isEmpty(tsd.getHouseConsignments())
            && (null != tsd.getMasterConsignment() && !isCiFoundOnMaster))
        || (CollectionUtils.isNotEmpty(tsd.getHouseConsignments()) && !isCiFoundOnAllHouse)) {
      addViolation(context, ErrorCode.TSPNESXXC0057, HEADER_MASTER_LEVEL);
      isValid.set(false);
    }
  }

  /**
   * For all 'CONSIGNMENT (HOUSE)' classes part of a 'MASTER CONSIGNMENT HEADER', maximum 1 previous
   * document is allowed
   *
   * @param tsd
   * @param context
   * @param isValid
   */
  private void validateConsignmentPreviousDocument(
      TemporaryStorageDeclaration tsd, ConstraintValidatorContext context, AtomicBoolean isValid) {
    if (CollectionUtils.isEmpty(tsd.getHouseConsignments())) return;
    if (null == tsd.getMasterConsignment()) return;
    Set<String> setString = new HashSet<>();
    for (HouseConsignment houseConsignment : tsd.getHouseConsignments()) {
      if (null != houseConsignment.getPreviousDocument()) {
        setString.add(
            houseConsignment.getPreviousDocument().getReferenceNumber().toLowerCase()
                + houseConsignment.getPreviousDocument().getType().toLowerCase());
      }

      if (null != houseConsignment.getConsignmentItem()) {
        for (ConsignmentItem item : houseConsignment.getConsignmentItem()) {
          if (item.getPreviousDocument() != null) {
            setString.add(
                item.getPreviousDocument().getReferenceNumber().toLowerCase()
                    + item.getPreviousDocument().getType().toLowerCase());
          }
        }
      }
    }

    if (setString.size() > 1) {
      isValid.set(false);
      addViolation(context, ErrorCode.TSPNESXXR0068, HEADER_MASTER_LEVEL);
    }
  }
}
