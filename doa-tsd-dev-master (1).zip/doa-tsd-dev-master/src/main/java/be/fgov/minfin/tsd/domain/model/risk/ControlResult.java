package be.fgov.minfin.tsd.domain.model.risk;

import be.fgov.minfin.tsd.domain.validation.annotation.CodeList;
import be.fgov.minfin.tsd.domain.validation.annotation.group.ReceiveControlResultValidator;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import be.fgov.minfin.tsd.domain.validation.codelist.TSDCodeLists;
import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Embeddable
@Builder(toBuilder = true)
public class ControlResult {

  @Column(name = "CONTROL_RESULT_DECISION")
  private String controlDecision;

  @Column(name = "CONTROL_RESULT_TYPE", columnDefinition = "char")
  @CodeList(
      value = TSDCodeLists.CL716,
      errorCode = ErrorCode.TSPNESXXC0444,
      groups = ReceiveControlResultValidator.class)
  private String type;

  @Column(name = "CONTROL_RESULT_CODE", columnDefinition = "char")
  @CodeList(value = TSDCodeLists.CL714, groups = ReceiveControlResultValidator.class)
  private String code;

  @Column(name = "DESCRIPTION")
  private String description;

  @Column(name = "CONTROL_END_DATE")
  private LocalDateTime controlEndDate;

  private LocalDateTime timestamp;
}
