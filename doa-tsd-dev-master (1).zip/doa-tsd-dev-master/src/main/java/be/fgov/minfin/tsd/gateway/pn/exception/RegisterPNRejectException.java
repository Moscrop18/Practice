package be.fgov.minfin.tsd.gateway.pn.exception;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public class RegisterPNRejectException extends Exception {
  /** */
  private static final long serialVersionUID = 1L;

  private final transient String message;
}
