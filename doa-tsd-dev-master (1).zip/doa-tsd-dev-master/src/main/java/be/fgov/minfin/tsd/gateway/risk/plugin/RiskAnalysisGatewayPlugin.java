/*
 * @(#) be.fgov.minfin.tsd.gateway.risk.plugin.RiskAnalysisGatewayPlugin.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.risk.plugin;

import be.fgov.minfin.tsd.gateway.risk.message.SendInvalidationNotification;
import be.fgov.minfin.tsd.gateway.risk.message.SendTSDRiskAnalysis;

/**
 * plugin to send request to risk analysis gateway
 *
 * @author MohdSalim
 */
public interface RiskAnalysisGatewayPlugin {
  public void sendRiskAnalysisRequest(SendTSDRiskAnalysis riskAnalysisRequest);

  public void processSendInvalidationNotification(
      SendInvalidationNotification sendInvalidationNotification);
}
