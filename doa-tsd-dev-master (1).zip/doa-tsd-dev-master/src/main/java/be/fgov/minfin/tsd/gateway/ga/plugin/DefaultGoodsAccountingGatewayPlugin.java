/*
 * @(#) be.fgov.minfin.tsd.gateway.ga.plugin.DefaultGoodsAccountingGatewayPlugin.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.ga.plugin;

import static javax.ws.rs.core.Response.Status.BAD_REQUEST;
import static javax.ws.rs.core.Response.Status.NO_CONTENT;
import static javax.ws.rs.core.Response.Status.OK;

import be.fgov.minfin.libdoa.exception.TechnicalException;
import be.fgov.minfin.libdoa.goods.accounting.client.OffwritableDocumentClient;
import be.fgov.minfin.libdoa.goods.accounting.client.api.owd.DeconsolidateOffwritableDocumentDTO;
import be.fgov.minfin.libdoa.goods.accounting.client.api.owd.LockOffwritableDocumentDTO;
import be.fgov.minfin.libdoa.goods.accounting.client.api.owd.OffwritableDocumentDTO;
import be.fgov.minfin.libdoa.goods.accounting.client.api.owd.OffwritableDocumentSource;
import be.fgov.minfin.libdoa.goods.accounting.client.api.transfer.OffwritableDocumentTransferNotificationDTO;
import be.fgov.minfin.tsd.gateway.ga.exception.LockOffwritableDocumentException;
import be.fgov.minfin.tsd.gateway.ga.message.GaOWDTransferNotificationMessage;
import be.fgov.minfin.tsd.gateway.ga.message.LockOffwritableDocumentRequest;
import be.fgov.minfin.tsd.gateway.ga.message.OffwritableDocument;
import be.fgov.minfin.tsd.gateway.ga.message.mapper.GoodsAccountingMapper;
import be.fgov.minfin.tsd.resource.api.ui.ValidationErrorDTO;
import be.fgov.minfin.tsd.resource.api.ui.ValidationErrorProblem;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.core.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Component;

/**
 * Default client implementation of Ga Gateway. This class will call GA System and retrieve
 * IETS924DTO with valid frn.
 */
@Component
@Slf4j
@RequiredArgsConstructor
@ConditionalOnExpression(
    "#{T(java.util.Arrays).asList('${gateway.enabledDefaultPlugins}').contains('GA')}")
public class DefaultGoodsAccountingGatewayPlugin implements GoodsAccountingGatewayPlugin {

  private static final String AND_RESPONSE_BODY = "and response body ";

  private static final String FAILED_WITH_STATUS_CODE = "failed with status code ";

  private final OffwritableDocumentClient offwritableDocumentClient;

  private final GoodsAccountingMapper gaMapper;

  @Override
  public void sendGAOffwritableDocument(OffwritableDocument offwritableDocument) {

    OffwritableDocumentDTO ieGA115 = gaMapper.map(offwritableDocument);

    log.info("Inside sendGAOffwritableDocument message {}", ieGA115);

    OffwritableDocumentSource source = OffwritableDocumentSource.G4;
    String mrn = offwritableDocument.getDeclaration().getReferenceNumber().getMrn().getMrnNumber();
    String language = offwritableDocument.getMessageHeader().getLanguageCode();

    try (Response response =
        offwritableDocumentClient.createOffwritableDocument(source, mrn, ieGA115, language); ) {

      if (response.getStatus() == 202) {
        log.debug("GA offwritable document submitted succesfully with mrn {}", mrn);
      } else {
        throw new TechnicalException(
            "sendGAOffwritableDocument '"
                + ieGA115
                + FAILED_WITH_STATUS_CODE
                + response.getStatus()
                + AND_RESPONSE_BODY
                + response.readEntity(String.class));
      }
    }
  }

  public List<ValidationErrorDTO> lockOffwritableDocument(
      LockOffwritableDocumentRequest lockOffwritableDocumentRequest)
      throws LockOffwritableDocumentException {
    log.info(
        "Inside gaClient lockOffwritableDocument with message {}", lockOffwritableDocumentRequest);
    LockOffwritableDocumentDTO lockOffwritableDocument =
        gaMapper.map(lockOffwritableDocumentRequest);

    Response response =
        offwritableDocumentClient.lockOffwritableDocument(
            OffwritableDocumentSource.G4,
            lockOffwritableDocumentRequest.getMrn(),
            lockOffwritableDocument,
            "en");

    List<ValidationErrorDTO> errors = new ArrayList<>();
    if (response.getStatus() == OK.getStatusCode()) {
      return errors;
    } else if (response.getStatus() == BAD_REQUEST.getStatusCode()) {
      ValidationErrorProblem readEntity = response.readEntity(ValidationErrorProblem.class);
      errors = readEntity.getViolations();
      return errors;
    } else if (response.getStatus()
        == NO_CONTENT.getStatusCode()) { // In case of no response added error reason XXT0005
      ValidationErrorDTO validationError = ValidationErrorDTO.builder().reason("T0005").build();
      errors.add(validationError);
      return errors;
    } else {
      throw new TechnicalException(
          "Lock Offwritable document GA Request '"
              + lockOffwritableDocument
              + FAILED_WITH_STATUS_CODE
              + AND_RESPONSE_BODY
              + response.readEntity(String.class));
    }
  }

  @Override
  public void sendGaOWDTransferNotification(
      GaOWDTransferNotificationMessage gaOWDTransferNotificationMessage) {

    OffwritableDocumentTransferNotificationDTO ieGA207 =
        gaMapper.map(gaOWDTransferNotificationMessage);

    String source = gaOWDTransferNotificationMessage.getSource();
    String mrn = gaOWDTransferNotificationMessage.getMrn();
    String languageCode = gaOWDTransferNotificationMessage.getMessageHeader().getLanguageCode();

    try {

      Response response =
          offwritableDocumentClient.sendGaOffwritableDocumentTransferNotification(
              ieGA207, source, mrn, languageCode);

      if (response != null) {
        if (response.getStatus() == 202) {
          log.debug(
              "GA OffwritableDocument TransferNotification request IEGA207 submitted successfully with source {} and mrn {}",
              source,
              mrn);
        } else {
          throw new TechnicalException(
              "GA OffwritableDocument TransferNotification request IEGA207: '"
                  + ieGA207
                  + FAILED_WITH_STATUS_CODE
                  + response.getStatus()
                  + AND_RESPONSE_BODY
                  + response.readEntity(String.class));
        }
      } else {
        throw new TechnicalException(
            "No response received for GA OffwritableDocument TransferNotification request IEGA207: '"
                + ieGA207);
      }
    } catch (TechnicalException technicalException) {
      throw technicalException;
    } catch (Exception exception) {
      throw new TechnicalException(
          exception
              + " for GA OffwritableDocument TransferNotification request IEGA207: '"
              + ieGA207);
    }
  }

  @Override
  public void deconsolidateOffwritableDocument(OffwritableDocument offwritableDocument) {
    DeconsolidateOffwritableDocumentDTO ieGA215 = gaMapper.mapDOwd(offwritableDocument);
    log.info("Inside Deconsolidate OffwritableDocument message {}", ieGA215);
    String mrn = offwritableDocument.getDeclaration().getReferenceNumber().getMrn().getMrnNumber();
    OffwritableDocumentSource source = OffwritableDocumentSource.G4;
    String language = offwritableDocument.getMessageHeader().getLanguageCode();
    try (Response response =
        offwritableDocumentClient.deconsolidateOffwritableDocument(
            source, mrn, ieGA215, language); ) {
      if (response.getStatus() == 202) {
        log.debug("Deconsolidation offwritable document submitted succesfully with mrn {}", mrn);
      } else {
        throw new TechnicalException(
            "deconsolidateOffwritableDocument '"
                + ieGA215
                + FAILED_WITH_STATUS_CODE
                + response.getStatus()
                + AND_RESPONSE_BODY
                + response.readEntity(String.class));
      }
    }
  }
}
