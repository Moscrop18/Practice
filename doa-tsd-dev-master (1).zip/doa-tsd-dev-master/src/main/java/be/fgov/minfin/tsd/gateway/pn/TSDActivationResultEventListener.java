/*
 * @(#) be.fgov.minfin.tsd.gateway.pn.TSDActivationResultEventListener
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.pn;

import static be.fgov.minfin.tsd.gateway.pn.PnGatewayConfig.ACTIVATION_CONCURRENCY_SETTING;
import static be.fgov.minfin.tsd.gateway.pn.PnGatewayConfig.ACTIVATION_RESULT_QUEUE;

import be.fgov.minfin.libdoa.amqp.transactional.AbstractRetryingQueueListener;
import be.fgov.minfin.pn.client.api.ActivationResultDTO;
import be.fgov.minfin.tsd.gateway.pn.plugin.PNGatewayPlugin;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

/**
 * This class will act as listener for TSDActivationResultQueue. It will Asynchronously respond to
 * the PN system
 *
 * @author NamrataGupta
 */
@Component
public class TSDActivationResultEventListener extends AbstractRetryingQueueListener {
  static final String LISTENER_ID = "process-activation-result";

  private final PNGatewayPlugin plugin;

  public TSDActivationResultEventListener(
      PnGatewayConfig activationResultConfig, PNGatewayPlugin plugin) {

    super(activationResultConfig.getPnActivationResultQueue());
    this.plugin = plugin;
  }

  /** Receives message from queue for sending to PN */
  @RabbitListener(
      id = LISTENER_ID,
      queues = ACTIVATION_RESULT_QUEUE,
      concurrency = ACTIVATION_CONCURRENCY_SETTING)
  public void processSendTSDActivationResult(
      @Payload ActivationResultDTO activationResultRequest, Message message) {
    plugin.sendTSDActivationResult(activationResultRequest);
  }
}
