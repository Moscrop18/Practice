/*
 * @(#) be.fgov.minfin.tsd.domain.repository.TSDRepository.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.repository;

import be.fgov.minfin.libdoa.pagination.CursorPageable;
import be.fgov.minfin.libdoa.pagination.repository.JpaSpecificationProjectionRepository;
import be.fgov.minfin.libdoa.pagination.types.DateIdCursor;
import be.fgov.minfin.tsd.domain.model.CRN;
import be.fgov.minfin.tsd.domain.model.MRN;
import be.fgov.minfin.tsd.domain.model.TSDDraftTimerProjection;
import be.fgov.minfin.tsd.domain.model.TSDStatus;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclarationFilter;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclarationProjection;
import be.fgov.minfin.tsd.domain.model.TimerType;
import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Slice;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.EntityGraph.EntityGraphType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface TSDRepository
    extends CustomTSDRepository,
        JpaRepository<TemporaryStorageDeclaration, Long>,
        JpaSpecificationExecutor<TemporaryStorageDeclaration>,
        JpaSpecificationProjectionRepository<TemporaryStorageDeclaration> {

  @EntityGraph(value = "get-tsd-version-entity-graph", type = EntityGraphType.LOAD)
  @Query(
      value =
          "select tsd from TemporaryStorageDeclaration tsd left join fetch tsd.consignmentHeader.decalaredlocationOfGoods dloc left join fetch tsd.consignmentHeader.presentedlocationOfGoods ploc where tsd.referenceNumber.mrn=:mrn and tsd.currentStatus!=:status order by tsd.currentVersion Desc")
  List<TemporaryStorageDeclaration> findByReferenceNumberMrn(MRN mrn, TSDStatus status);

  @EntityGraph(value = "get-tsd-version-entity-graph", type = EntityGraphType.LOAD)
  @Query(
      value =
          "select tsd from TemporaryStorageDeclaration tsd left join fetch tsd.consignmentHeader.decalaredlocationOfGoods dloc left join fetch tsd.consignmentHeader.presentedlocationOfGoods ploc where tsd.referenceNumber.crn=:crn and tsd.currentStatus!=:status order by tsd.currentVersion Desc")
  List<TemporaryStorageDeclaration> findByReferenceNumberCrn(CRN crn, TSDStatus status);

  @Query(
      value =
          "select tsd from TemporaryStorageDeclaration tsd join ReferenceNumber rn on "
              + "tsd.id = rn.declaration.id where rn.crn=:crn")
  Optional<TemporaryStorageDeclaration> findCurrentVersion(CRN crn);

  @Query(
      value =
          "select tsd from TemporaryStorageDeclaration tsd join ReferenceNumber rn on "
              + "tsd.id = rn.declaration.id where rn.mrn=:mrn")
  Optional<TemporaryStorageDeclaration> findCurrentVersion(MRN mrn);

  @Query(
      value =
          "select tsd from TemporaryStorageDeclaration tsd join ReferenceNumber rn on "
              + "tsd.id = rn.declaration.id left join fetch tsd.consignmentHeader.decalaredlocationOfGoods dloc left join fetch tsd.consignmentHeader.presentedlocationOfGoods ploc where rn.crn=:crn")
  @EntityGraph(value = "get-ui-entity-graph", type = EntityGraphType.LOAD)
  Optional<TemporaryStorageDeclaration> findCurrentVersionWithAmendmentAndExchange(CRN crn);

  @Query(
      value =
          "select tsd from TemporaryStorageDeclaration tsd join ReferenceNumber rn on "
              + "tsd.id = rn.declaration.id left join fetch tsd.consignmentHeader.decalaredlocationOfGoods dloc left join fetch tsd.consignmentHeader.presentedlocationOfGoods ploc where rn.mrn=:mrn")
  @EntityGraph(value = "get-ui-entity-graph", type = EntityGraphType.LOAD)
  Optional<TemporaryStorageDeclaration> findCurrentVersionWithAmendmentAndExchange(MRN mrn);

  @Query(
      value =
          "select tsd from TemporaryStorageDeclaration tsd  left join fetch tsd.consignmentHeader.decalaredlocationOfGoods dloc left join fetch tsd.consignmentHeader.presentedlocationOfGoods ploc where tsd.id=:id")
  @EntityGraph(value = "get-ui-entity-graph", type = EntityGraphType.LOAD)
  Optional<TemporaryStorageDeclaration> getDeclarationById(Long id);

  @Query(
      value =
          "select tsd.id from TemporaryStorageDeclaration tsd where tsd.referenceNumber.crn=:crn and tsd.currentStatus=:status")
  Optional<Long> getDraftAmendmentID(@Param("crn") CRN crn, @Param("status") TSDStatus status);

  @Query(
      value =
          "select max(currentVersion) from TemporaryStorageDeclaration tsd where tsd.referenceNumber.crn=:crn and  tsd.currentStatus!=:status")
  Integer findMaxVersionTSD(@Param("crn") CRN crn, @Param("status") TSDStatus tsdStatus);

  @Query(
      value =
          "select currentVersion from TemporaryStorageDeclaration tsd where tsd.referenceNumber.crn=:crn and  tsd.currentStatus!=:status")
  List<Integer> listVersionsTSD(@Param("crn") CRN crn, @Param("status") TSDStatus tsdStatus);

  @Query(
      value =
          "select tsd.linkedPnFrn from TemporaryStorageDeclaration tsd join ReferenceNumber rn on "
              + "tsd.id = rn.declaration.id where rn.crn=:crn")
  String getLinkedPnFrnCurrentVersion(CRN crn);

  @Query(
      value =
          "select distinct cons.id "
              + "from MasterConsignment cons "
              + "join TemporaryStorageDeclaration tsd on cons.declaration.id = tsd.id "
              + "join ConsignmentItem item on item.consignment.id = cons.id "
              + "left join TransportEquipment te on (te.consignment.id = cons.id "
              + "OR te.consignmentItem.id = item.id) "
              + "where tsd.id = :tsdId and te.id is null")
  List<Long> getMasterConsignmentItemsLinkedWithTransportEquipment(@Param("tsdId") Long tsdId);

  @Query(
      value =
          "select distinct cons.id "
              + "from Consignment cons, TemporaryStorageDeclaration tsd, Receptacle rc "
              + "where (tsd.id = cons.declaration.id) "
              + "and rc.consignment.id = cons.id "
              + "and tsd.id = :tsdId")
  List<Long> getMasterConsignmentItemsLinkedWithReceptacle(@Param("tsdId") Long tsdId);

  @Query(
      value =
          "select distinct cons.id "
              + "from HouseConsignment cons "
              + "inner join TemporaryStorageDeclaration tsd on tsd.id = cons.declaration.id "
              + "inner join ConsignmentItem item on item.consignment.id = cons.id "
              + "left join TransportEquipment te on (te.consignment.id = cons.id "
              + "OR te.consignmentItem.id = item.id) "
              + "where tsd.id = :tsdId and te.id is null")
  List<Long> getHouseConsignmentItemsLinkedWithTransportEquipment(@Param("tsdId") Long tsdId);

  @Query(
      value =
          "select rc.identificationNumber "
              + "from Consignment cons, TemporaryStorageDeclaration tsd, Receptacle rc "
              + "where (tsd.id = cons.declaration.id) "
              + "and rc.consignment.id = cons.id "
              + "and tsd.id = :tsdId "
              + "group by rc.id, rc.identificationNumber")
  List<String> getIdentificationNumbersOfReceptacles(@Param("tsdId") Long tsdId);

  @Query(
      value =
          "select distinct te.containerIdentificationNumber "
              + "from TransportEquipment te, ConsignmentItem item, Consignment c "
              + "where (te.consignment.id = c.id "
              + "or te.consignmentItem.id = item.id) "
              + "and (item.consignment.id = c.id) "
              + "and (c.declaration.id = :tsdId) "
              + "group by te.id, te.containerIdentificationNumber")
  List<String> getContainerIDsOfTransportEquipments(@Param("tsdId") Long tsdId);

  @Query(
      value =
          "select hc.transportDocument.referenceNumber "
              + "from HouseConsignment hc, TemporaryStorageDeclaration tsd "
              + "where hc.declaration.id = tsd.id "
              + "and tsd.id = :tsdId "
              + "group by hc.id, hc.transportDocument.referenceNumber")
  List<String> getReferenceNumberOfTransportDocumentLinkedWithHouseConsignments(
      @Param("tsdId") Long tsdId);

  @Query(
      value =
          "delete  from SupportingDocument where  id in "
              + "( select distinct sd.id   "
              + "from SupportingDocument sd "
              + "left join Consignment c on (c.id = sd.consignment.id or sd.consignmentItem.consignment.id=c.id) and c.declaration.id = :tsdId "
              + "left join ConsignmentItem item on item.id = sd.consignmentItem.id and item.consignment.id = c.id "
              + "inner join TemporaryStorageDeclaration d on d.id = :tsdId and c.declaration.id = d.id "
              + ")")
  @Modifying
  void deleteSupportingDocumentLinkedWithTSD(@Param("tsdId") Long tsdId);

  @Query(
      value =
          "delete  from AdditionalInformation where  id in "
              + "( select distinct ai.id   "
              + "from AdditionalInformation ai "
              + "left join Consignment c on (c.id = ai.consignment.id or ai.consignmentItem.consignment.id=c.id) and c.declaration.id = :tsdId "
              + "left join ConsignmentItem item on item.id = ai.consignmentItem.id and item.consignment.id = c.id "
              + "inner join TemporaryStorageDeclaration d on d.id = :tsdId and c.declaration.id = d.id "
              + ")")
  @Modifying
  void deleteAdditionalInformationLinkedWithTSD(@Param("tsdId") Long tsdId);

  @Query(
      value =
          "delete  from AdditionalReference where  id in "
              + "( select distinct ar.id   "
              + "from AdditionalReference ar "
              + "left join Consignment c on (c.id = ar.consignment.id or ar.consignmentItem.consignment.id=c.id) and c.declaration.id = :tsdId "
              + "left join ConsignmentItem item on item.id = ar.consignmentItem.id and item.consignment.id = c.id "
              + "inner join TemporaryStorageDeclaration d on d.id = :tsdId and c.declaration.id = d.id "
              + ")")
  @Modifying
  void deleteAdditionalReferenceLinkedWithTSD(@Param("tsdId") Long tsdId);

  @Query(
      value =
          "delete  from AEOAuthorisation where  id in "
              + "( select distinct auth.id   "
              + "from AEOAuthorisation auth "
              + "inner join AdditionalSupplyChainActor chainActor on auth.chainActor.id=chainActor.id "
              + "left join Consignment c on (c.id = chainActor.consignment.id or chainActor.consignmentItem.consignment.id=c.id) and c.declaration.id = :tsdId "
              + "left join ConsignmentItem item on item.id = chainActor.consignmentItem.id and item.consignment.id = c.id "
              + "inner join TemporaryStorageDeclaration d on d.id = :tsdId and c.declaration.id = d.id "
              + ")")
  @Modifying
  void deleteAeoAuthLinkedWithTSD(@Param("tsdId") Long tsdId);

  @Query(
      value =
          "delete  from AdditionalSupplyChainActor where  id in "
              + "( select distinct chainActor.id   "
              + "from AdditionalSupplyChainActor chainActor  "
              + "left join Consignment c on (c.id = chainActor.consignment.id or chainActor.consignmentItem.consignment.id=c.id) and c.declaration.id = :tsdId "
              + "left join ConsignmentItem item on item.id = chainActor.consignmentItem.id and item.consignment.id = c.id "
              + "inner join TemporaryStorageDeclaration d on d.id = :tsdId and c.declaration.id = d.id "
              + ")")
  @Modifying
  void deleteSupplyChainActorLinkedWithTSD(@Param("tsdId") Long tsdId);

  @Query(
      value =
          "delete  from Seal where  id in "
              + "( select distinct s.id   "
              + "from Seal s "
              + "inner join TransportEquipment te on s.transportEquipment.id=te.id "
              + "left join Consignment c on (c.id = te.consignment.id or te.consignmentItem.consignment.id=c.id) and c.declaration.id = :tsdId "
              + "left join ConsignmentItem item on item.id = te.consignmentItem.id and item.consignment.id = c.id "
              + "inner join TemporaryStorageDeclaration d on d.id = :tsdId and c.declaration.id = d.id "
              + ")")
  @Modifying
  void deleteSealLinkedWithTSD(@Param("tsdId") Long tsdId);

  @Query(
      value =
          "delete  from TransportEquipment where  id in "
              + "( select distinct te.id   "
              + "from TransportEquipment te "
              + "left join Consignment c on (c.id = te.consignment.id or te.consignmentItem.consignment.id=c.id) and c.declaration.id = :tsdId "
              + "left join ConsignmentItem item on item.id = te.consignmentItem.id and item.consignment.id = c.id "
              + "inner join TemporaryStorageDeclaration d on d.id = :tsdId and c.declaration.id = d.id "
              + ")")
  @Modifying
  void deleteTransportEquipmentLinkedWithTSD(@Param("tsdId") Long tsdId);

  @Query(
      value =
          "delete  from Packaging where  id in "
              + "( select distinct p.id   "
              + "from Packaging p "
              + "inner  join  ConsignmentItem item on item.id = p.consignmentItem.id  "
              + "inner join Consignment c on c.id = p.consignmentItem.consignment.id and c.declaration.id = :tsdId "
              + "inner join TemporaryStorageDeclaration d on d.id = :tsdId and c.declaration.id = d.id "
              + ")")
  @Modifying
  void deletePackagingLinkedWithTSD(@Param("tsdId") Long tsdId);

  @Query(
      value =
          "delete  from Receptacle where  id in "
              + "( select distinct r.id   "
              + "from Receptacle r "
              + "inner join MasterConsignment c on c.id = r.consignment.id "
              + "inner join TemporaryStorageDeclaration d on d.id = :tsdId and c.declaration.id = d.id "
              + ")")
  @Modifying
  void deleteReceptacleLinkedWithTSD(@Param("tsdId") Long tsdId);

  @Query(
      value =
          "delete  from ConsignmentItem where  id in "
              + "( select distinct item.id   "
              + "from ConsignmentItem item "
              + "inner join Consignment c on c.id = item.consignment.id and c.declaration.id = :tsdId "
              + "inner join TemporaryStorageDeclaration d on d.id = :tsdId and c.declaration.id = d.id "
              + ")")
  @Modifying
  void deleteConsignmentIteminkedWithTSD(@Param("tsdId") Long tsdId);

  @Query(
      value =
          "select distinct c.consignor.id from  Consignment c  "
              + "inner join TemporaryStorageDeclaration d on d.id = :tsdId and c.declaration.id = d.id ")
  List<Long> getConsignorLinkedWithTSD(@Param("tsdId") Long tsdId);

  @Query(
      value =
          "select distinct c.consignee.id from  Consignment c  "
              + "inner join TemporaryStorageDeclaration d on d.id = :tsdId and c.declaration.id = d.id ")
  @Modifying
  List<Long> getConsigneeLinkedWithTSD(@Param("tsdId") Long tsdId);

  @Query(
      value =
          "select distinct c.notifyParty.id from  Consignment c  "
              + "inner join TemporaryStorageDeclaration d on d.id = :tsdId and c.declaration.id = d.id ")
  @Modifying
  List<Long> getNotifyPartyLinkedWithTSD(@Param("tsdId") Long tsdId);

  @Query(
      value =
          "delete from Consignment where  id in "
              + "( select distinct c.id   "
              + "from Consignment c "
              + "inner join TemporaryStorageDeclaration d on d.id = :tsdId and c.declaration.id = d.id ) ")
  @Modifying
  void deleteConsignmentLinkedWithTSD(@Param("tsdId") Long tsdId);

  @Query(value = "delete  from TemporaryStorageDeclaration where  id =:tsdId")
  @Modifying
  void deleteTSD(@Param("tsdId") Long tsdId);

  @Query(value = "delete  from Communication com where  com.party.id in (:partysID)")
  @Modifying
  void deleteAllCommunication(@Param("partysID") List<Long> partysID);

  @Query(value = "delete  from Party p where  p.id in (:partysID)")
  @Modifying
  void deleteAllPartys(@Param("partysID") List<Long> partysID);

  @Query(value = "delete  from StatusHistory h where  h.referenceNumber.id=:id")
  @Modifying
  void deleteStatusHistory(@Param("id") Long referenceNumberID);

  @Query(value = "delete  from ReferenceNumber r where  r.id=:id")
  @Modifying
  void deleteReferenceNumber(@Param("id") Long referenceNumberID);

  @Query(value = "delete  from LocationOfGoods goods where  goods.id=:id")
  @Modifying
  void deleteLocationOfgoods(@Param("id") Long id);

  @Query(value = "delete  from Timer timer where  timer.reference=:ref and timer.type=:type")
  @Modifying
  void deleteTimerLinkedToTsd(@Param("ref") String ref, @Param("type") TimerType type);

  @Query(
      value =
          "update ReferenceNumber ref "
              + "set ref.draftAmendmentId = null "
              + "where ref.id=:refId")
  @Modifying
  void deleteDraftAmendmentId(Long refId);

  @Query(
      value =
          "select tsd.id as id, tsd.registrationDate as registrationDate from TemporaryStorageDeclaration tsd "
              + "where tsd.currentStatus = 0")
  List<TSDDraftTimerProjection> getTSDDraftTimerProjection();

  default Slice<TemporaryStorageDeclarationProjection> findTemporaryStorageDeclarationProjections(
      TemporaryStorageDeclarationFilter filter, CursorPageable<DateIdCursor> pageable) {
    return findAll(
        TemporaryStorageDeclarationSpec.of(filter),
        TemporaryStorageDeclarationProjection.class,
        pageable);
  }

  @Query(
      value =
          "select case when (count(1) > 0) then true else false end from Consignment cons "
              + "join ReferenceNumber rn on cons.declaration.id = rn.declaration.id "
              + "where rn.id = :referenceNumberId and cons.currentConsignmentLocationOfGoods is not null")
  boolean checkIfCurrentTSDisTransferred(Long referenceNumberId);
}
