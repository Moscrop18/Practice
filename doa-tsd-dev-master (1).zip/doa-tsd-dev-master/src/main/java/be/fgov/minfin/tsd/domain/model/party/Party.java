/*
 * @(#) be.fgov.minfin.tsd.domain.model.party.Party
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model.party;

import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import be.fgov.minfin.tsd.domain.validation.annotation.group.DeconsolidationNotificationValidatorGroup;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.groups.Default;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
@Entity
@Table(name = "PARTY")
@EqualsAndHashCode
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "party_type")
@DiscriminatorValue("Declarant")
@ValidateBusinessRules(groups = {Default.class, DeconsolidationNotificationValidatorGroup.class})
public class Party {
  @GeneratedValue(generator = "party_seq")
  @SequenceGenerator(name = "party_seq", sequenceName = "party_seq")
  @Id
  private Long id;

  @OneToMany(
      cascade = {CascadeType.PERSIST, CascadeType.MERGE},
      orphanRemoval = true,
      mappedBy = "party")
  @ToString.Exclude
  @JsonManagedReference
  private List<@Valid Communication> communication;

  private String name;
  private String identificationNumber;

  private @Valid @Embedded PartyAddress address;
}
