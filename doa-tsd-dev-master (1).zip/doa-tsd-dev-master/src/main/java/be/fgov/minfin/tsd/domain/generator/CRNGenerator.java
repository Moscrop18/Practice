/*
 * @(#)be.fgov.minfin.tsd.domain.generator.CRNGenerator.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.generator;

import be.fgov.minfin.tsd.config.TSDConfig;
import be.fgov.minfin.tsd.domain.converter.ReferenceNumberMetadataDTO;
import java.math.BigInteger;
import java.time.format.DateTimeFormatter;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * This Class is used to generate CRN for declaration
 *
 * @author GauravMitra
 */
@Component
@RequiredArgsConstructor
public class CRNGenerator extends BaseGenerator {
  private final TSDConfig cfg;
  public static final String CRN_PREFIX = "CRN";

  public String generateCRN(ReferenceNumberMetadataDTO metadata) {
    String base36 =
        StringUtils.leftPad(
            new BigInteger(String.valueOf(metadata.getId())).toString(36).toUpperCase(), 10, "0");

    StringBuilder builder = new StringBuilder();
    Integer checkDigit =
        getCheckDigit(
            builder
                .append(CRN_PREFIX)
                .append(DateTimeFormatter.ofPattern("yy").format(metadata.getReceptionTimestamp()))
                .append(cfg.getCountryCode())
                .append(cfg.getDeclartionTypeIndentifierCrn())
                .append(base36)
                .append(cfg.getProcedureIdentifier())
                .toString());

    return builder.append(checkDigit.toString()).toString();
  }
}
