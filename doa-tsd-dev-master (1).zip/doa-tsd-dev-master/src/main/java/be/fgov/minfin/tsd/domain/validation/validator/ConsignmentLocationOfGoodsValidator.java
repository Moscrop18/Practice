/*
 * @(#) be.fgov.minfin.tsd.domain.validation.validator.ConsignmentLocationOfGoodsValidator.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties
 * or made public without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation.validator;

import be.fgov.minfin.tsd.domain.model.ConsignmentLocationOfGoods;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class ConsignmentLocationOfGoodsValidator extends BaseConstraintValidator
    implements ConstraintValidator<ValidateBusinessRules, ConsignmentLocationOfGoods> {

  private static final String TYPE = "type";

  private static final String WAREHOUSE = "warehouse";

  @Override
  public boolean isValid(
      ConsignmentLocationOfGoods consignmentLocationOfGoods, ConstraintValidatorContext context) {

    AtomicBoolean isValid = new AtomicBoolean(true);

    validateWarehouse(consignmentLocationOfGoods, isValid, context);

    return isValid.get();
  }

  private void validateWarehouse(
      ConsignmentLocationOfGoods consignmentLocationOfGoods,
      AtomicBoolean isValid,
      ConstraintValidatorContext context) {

    if (null != consignmentLocationOfGoods
        && null != consignmentLocationOfGoods.getWarehouse()
        && null != consignmentLocationOfGoods.getWarehouse().getType()
        && !consignmentLocationOfGoods.getWarehouse().getType().equals("V")) {
      isValid.set(false);
      addViolation(context, ErrorCode.TSPNESXXR0128, WAREHOUSE, TYPE);
    }
  }
}
