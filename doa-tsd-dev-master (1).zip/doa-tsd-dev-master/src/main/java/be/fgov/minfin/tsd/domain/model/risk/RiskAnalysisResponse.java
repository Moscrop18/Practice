/*
 * ===========================================================================
 * @(#)be.fgov.minfin.tsd.domain.model.risk.Result.java
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model.risk;

import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@Embeddable
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class RiskAnalysisResponse {

  @Column(name = "RESULT_NOTIFICATION_ALLOWED", columnDefinition = "SMALLINT")
  private Boolean notificationAllowed;

  @Column(name = "RESULT_TIMESTAMP")
  private LocalDateTime timestamp;

  @Column(name = "INTENDED_CONTROL_NOTIFIED", columnDefinition = "SMALLINT")
  private Boolean intendedControlNotified;

  @Transient private Boolean isValidNotificationAllowed;
}
