/*
 * @(#) be.fgov.minfin.tsd.gateway.risk.message.SendTSDRiskAnalysis.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.risk.message;

import be.fgov.minfin.libdoa.amqp.BaseEvent;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import java.util.List;
import lombok.Builder;
import lombok.Value;

@Value
@Builder(toBuilder = true)
public class SendTSDRiskAnalysis extends BaseEvent {

  private MessageHeader messageHeader;
  private Integer messageFunction;
  private String functionalReference;
  private String documentIssueDate;
  private List<PreviousRiskAnalysis> previousRiskAnalysis;
  private CurrentRiskAnalysis riskAnalysis;
  private TemporaryStorageDeclaration declaration;
  private DeconsolidationNotificationHeader deconsolidationNotificationHeader;
}
