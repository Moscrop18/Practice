package be.fgov.minfin.tsd.event.api;

import be.fgov.minfin.libdoa.amqp.BaseEvent;
import be.fgov.minfin.tsd.domain.model.TSDActivationRequest;
import lombok.Builder;
import lombok.Value;

/**
 * This class wraps Activation Message
 *
 * @author GauravMitra
 */
@Value
@Builder
public class TSDActivationReceivedEvent extends BaseEvent {
  private TSDActivationRequest activateTSDRequest;
}
