/*
 * @(#)be.fgov.minfin.tsd.resource.api.ErrorDTO.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */

package be.fgov.minfin.tsd.resource.api;

import com.fasterxml.jackson.annotation.JsonRootName;
import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.Builder;
import lombok.Value;

/** Error */
@Value
@Builder(toBuilder = true)
@JsonRootName("error")
public class ErrorDTO {
  @NotNull
  @Digits(integer = 5, fraction = 0)
  @Schema(example = "1")
  private Integer sequenceNumber;

  @Size(min = 1, max = 512)
  @Schema(
      example =
          "consignmentHeaderMasterLevel.consignmentMasterLevel.transportEquipment[0].containerIdentificationNumber")
  private String errorPointer;

  @NotNull
  @Digits(integer = 2, fraction = 0)
  @Schema(example = "99")
  private Integer errorCode;

  @NotNull
  @Size(min = 1, max = 10)
  @Schema(example = "BER0028")
  private String errorReason;

  @NotNull
  @Size(min = 1, max = 512)
  @Schema(example = "ABCD12345678")
  private String originalAttributeValue;

  private String remarks;
}
