/*
 * @(#)be.fgov.minfin.tsd.gateway.eo.plugin.DefaultEONotificationGatewayClient.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.eo.plugin;

import be.fgov.minfin.eogw.client.EONotificationRestClient;
import be.fgov.minfin.eogw.client.api.EONotificationResponseDTO;
import be.fgov.minfin.libdoa.exception.TechnicalException;
import be.fgov.minfin.tsd.gateway.eo.api.EONotificationEvent;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Component;

/**
 * Default EO gateway plugin implementation which will call to eo service through rest client
 *
 * @author GauravMitra
 */
@Component
@RequiredArgsConstructor
@Slf4j
@ConditionalOnExpression(
    "#{T(java.util.Arrays).asList('${gateway.enabledDefaultPlugins}').contains('EO')}")
public class DefaultEONotificationGatewayClient implements EONotificationGatewayPlugin {

  @Qualifier("eoClient")
  private final EONotificationRestClient eoClient;
  /** send notification to eo service */
  public void sendNotification(EONotificationEvent notificationEvent) {
    log.info(
        "Inside DefaultEONotificationGatewayClient message {}",
        notificationEvent.getEoNotificationDTO().getMessageContent());
    EONotificationResponseDTO notificationResponse =
        eoClient.sendRequest(notificationEvent.getEoNotificationDTO());
    if (notificationResponse.getResponseCode() == 201) {
      log.info("request submitted eo gateway");
    } else {
      log.error(
          "request not submitted to gateway status code" + notificationResponse.getResponseCode());
      throw new TechnicalException("request not submitted to eo gateway ");
    }
  }
}
