/*
 * @(#) be.fgov.minfin.tsd.resource.TSDB2BResource.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.resource;

import be.fgov.minfin.tsd.domain.model.AmendmentRequest;
import be.fgov.minfin.tsd.domain.model.DeconsolidationNotification;
import be.fgov.minfin.tsd.domain.model.InvalidationRequest;
import be.fgov.minfin.tsd.domain.model.MessageInformationSource;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclarationType;
import be.fgov.minfin.tsd.domain.model.TransferNotification;
import be.fgov.minfin.tsd.domain.service.AmendmentService;
import be.fgov.minfin.tsd.domain.service.DeconsolidationNotificationService;
import be.fgov.minfin.tsd.domain.service.InvalidationService;
import be.fgov.minfin.tsd.domain.service.TSDService;
import be.fgov.minfin.tsd.domain.service.TransferNotificationService;
import be.fgov.minfin.tsd.resource.api.AcknowledgementDTO;
import be.fgov.minfin.tsd.resource.api.CombinedTemporaryStorageDeclarationDTO;
import be.fgov.minfin.tsd.resource.api.DeconsolidationNotificationDTO;
import be.fgov.minfin.tsd.resource.api.NegativeAcknowledgementDTO;
import be.fgov.minfin.tsd.resource.api.TSDAmendmentRequestDTO;
import be.fgov.minfin.tsd.resource.api.TSDInvalidationRequestDTO;
import be.fgov.minfin.tsd.resource.api.TemporaryStorageDeclarationDTO;
import be.fgov.minfin.tsd.resource.api.TransferNotificationDTO;
import be.fgov.minfin.tsd.resource.builder.TSDMessageBuilder;
import be.fgov.minfin.tsd.resource.exception.B2BExceptionHandling;
import be.fgov.minfin.tsd.resource.generator.CorrelationIdGenerator;
import be.fgov.minfin.tsd.resource.mapper.TSDMapper;
import be.fgov.minfin.tsd.resource.validation.B2BOnly;
import be.fgov.minfin.tsd.util.LanguageUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.validation.groups.ConvertGroup;
import javax.validation.groups.Default;
import javax.ws.rs.Consumes;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 *
 * <h1>Processes a TSD resource</h1>
 *
 * Exposes API for submitting a {@link TemporaryStorageDeclaration} domain model for B2B only.
 *
 * <p>TemporaryStorageDeclaration(TSD) message is sent by the declarant, representative or third
 * party (generalized as Sender) as trigger to start the submission process of a TSD.
 *
 * <p>A positive acknowledgment is synchronously returned to the message sender to inform him that
 * the message is well received, and an acceptance is returned to the message sender to inform him
 * that his TSD has been validated and accepted.
 *
 * <p>If the declaration message is not compliant with the defined message schema, a negative
 * acknowledgement message is synchronously sent to the message sender and the TSD is not registered
 * in the system.
 *
 * <p>This REST resource is a Jersey implementation which produces and consumes {@link
 * MediaType#APPLICATION_JSON application/json} &amp; {@link MediaType#APPLICATION_XHTML_XML
 * application/xml} both.
 *
 * <h1>Processes a TSD invalidation request message</h1>
 *
 * <p>Exposes API for processing TSD invalidation request {@link TemporaryStorageDeclaration} by
 * sending a IETS414 message.
 *
 * <p>Invalidation request message is sent by the economic operator(b2b) as trigger to start the
 * invalidation of a TSD.
 *
 * <p>A positive acknowledgment is synchronously returned to the message sender to inform him that
 * the message is well received, and an acceptance is returned to the message sender to inform him
 * that his TSD invalidation request has been validated and accepted and the invalidation request
 * message is then processed asynchronously.
 *
 * <p>If the invalidation request message is not compliant with the defined message schema, a
 * negative acknowledgement message is synchronously sent to the message sender.
 *
 * <p>This REST resource is a Jersey implementation which produces and consumes {@link
 * MediaType#APPLICATION_JSON application/json} &amp; {@link MediaType#APPLICATION_XHTML_XML
 * application/xml} both.
 *
 * <h1>Processes a TSD amendment request message</h1>
 *
 * <p>Exposes API for processing TSD amendment request {@link TemporaryStorageDeclaration} by
 * sending a IETS413 message.
 *
 * <p>Amendment request message is sent by the economic operator(b2b) as trigger to start the
 * amendment of a TSD.
 *
 * <p>A positive acknowledgment is synchronously returned to the message sender to inform him that
 * the message is well received, and an acceptance is returned to the message sender to inform him
 * that his TSD amendment request has been validated and accepted and the amendment request message
 * is then processed asynchronously.
 *
 * <p>If the amendment request message is not compliant with the defined message schema, a negative
 * acknowledgement message is synchronously sent to the message sender.
 *
 * <p>This REST resource is a Jersey implementation which produces and consumes {@link
 * MediaType#APPLICATION_JSON application/json} &amp; {@link MediaType#APPLICATION_XHTML_XML
 * application/xml} both.
 *
 * <p>Responsibilities of a Resource
 *
 * <ul>
 *   <li>Exposing REST API
 *   <li>Authorization of operations
 *   <li>Mapping of XML/JSON &lt;-&gt; {@link }
 *   <li>validating input on PresentationNotificationDTO
 *       <ul>
 *         <li>using constraints
 *         <li>using business validators
 *       </ul>
 *   <li>Mapping of {@link } &lt;-&gt; {@link TemporaryStorageDeclaration} Domain object
 *   <li>process of referenced domain object
 * </ul>
 *
 * @author GauravMitra
 * @version 1.0.1
 */
@Component
@Path("/b2b/temporaryStorageDeclarations")
@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
@Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
@Slf4j
@RequiredArgsConstructor
@Transactional
@B2BExceptionHandling
public class TSDB2BResource {
  private final CorrelationIdGenerator correlationIdGenerator;
  private final TSDMapper tsdMapper;
  private final TSDMessageBuilder messageBuilder;
  private final TSDService tsdService;
  private final LanguageUtil languageUtil;
  private final InvalidationService invalidationService;
  private final AmendmentService amendmentService;
  private final TransferNotificationService transferNotificationService;
  private final DeconsolidationNotificationService deconsolidationNotificationService;

  /**
   *
   *
   * <h1>Validates &amp; create {@link TemporaryStorageDeclaration}</h1>
   *
   * @param declarationDTO
   * @param uriInfo
   * @param language
   * @return the response having acknowledgement message with (@link Response.Status.ACCEPTED) if
   *     sxd validation succeeds or negative acknowledgement message with (@link
   *     Response.Status.BAD_REQUEST) if sxd validation fails
   */
  @POST
  @ApiResponse(
      responseCode = "202",
      description = "Accepted",
      content = @Content(schema = @Schema(implementation = AcknowledgementDTO.class)))
  @ApiResponse(
      responseCode = "400",
      description = "Bad Request",
      content = @Content(schema = @Schema(implementation = NegativeAcknowledgementDTO.class)))
  @Path("/preLodged")
  @Operation(summary = "Submit a Pre-Lodged Temporary Storage Declaration IETS015")
  public Response submitPreLodgedDeclaration(
      @ConvertGroup(from = Default.class, to = B2BOnly.class) @Valid
          TemporaryStorageDeclarationDTO declarationDTO,
      @Context UriInfo uriInfo,
      @HeaderParam("accept-language") String language) {

    String correlationID = correlationIdGenerator.generateCorrelationID();
    String languageCode =
        languageUtil.determineLanguage(declarationDTO.getMessageHeader(), language);

    log.info(
        "correlation id,LanguageCode For this message with LRN {} is {},{}",
        declarationDTO.getLrn(),
        correlationID,
        languageCode);
    TemporaryStorageDeclaration declaration =
        tsdMapper.map(
            declarationDTO,
            correlationID,
            null == languageCode ? "" : languageCode,
            TemporaryStorageDeclarationType.PRELODGED.name(),
            MessageInformationSource.B2B);
    tsdService.receiveDeclaration(declaration);
    AcknowledgementDTO acknowledgementDTO = messageBuilder.buildAckMessage(correlationID);
    return Response.accepted(acknowledgementDTO).build();
  }

  @POST
  @ApiResponse(
      responseCode = "202",
      description = "Accepted",
      content = @Content(schema = @Schema(implementation = AcknowledgementDTO.class)))
  @ApiResponse(
      responseCode = "400",
      description = "Bad Request",
      content = @Content(schema = @Schema(implementation = NegativeAcknowledgementDTO.class)))
  @Path("/combined")
  @Operation(summary = "Submit a Combined Temporary Storage Declaration IETS115")
  public Response submitCombined(
      @ConvertGroup(from = Default.class, to = B2BOnly.class) @Valid
          CombinedTemporaryStorageDeclarationDTO declarationDTO,
      @Context UriInfo uriInfo,
      @HeaderParam("accept-language") String language) {

    String correlationID = correlationIdGenerator.generateCorrelationID();
    String languageCode =
        languageUtil.determineLanguage(declarationDTO.getMessageHeader(), language);

    log.info(
        "correlation id,LanguageCode For this message with LRN {} is {},{}",
        declarationDTO.getLrn(),
        correlationID,
        languageCode);
    TemporaryStorageDeclaration declaration =
        tsdMapper.map(
            declarationDTO,
            correlationID,
            null == languageCode ? "" : languageCode,
            TemporaryStorageDeclarationType.COMBINED.name(),
            MessageInformationSource.B2B);
    tsdService.receiveDeclaration(declaration);
    AcknowledgementDTO acknowledgementDTO = messageBuilder.buildAckMessage(correlationID);
    return Response.accepted(acknowledgementDTO).build();
  }

  /**
   *
   *
   * <h1>Validates &amp; invalidates {@link TemporaryStorageDeclaration}</h1>
   *
   * @param invalidationRequestDTO
   * @param uriInfo
   * @param language
   * @return the response having acknowledgement message with (@link Response.Status.ACCEPTED) if
   *     sxd validation succeeds or negative acknowledgement message with (@link
   *     Response.Status.BAD_REQUEST) if xsd validation fails
   */
  @POST
  @ApiResponse(
      responseCode = "202",
      description = "Accepted",
      content = @Content(schema = @Schema(implementation = AcknowledgementDTO.class)))
  @ApiResponse(
      responseCode = "400",
      description = "Bad Request",
      content = @Content(schema = @Schema(implementation = NegativeAcknowledgementDTO.class)))
  @Path("{crn}/invalidate")
  @Operation(summary = "Submit a TSD invalidation request message IETS414")
  public Response submitInvalidationRequest(
      @Valid @NotNull @PathParam("crn") String crn,
      @ConvertGroup(from = Default.class, to = B2BOnly.class) @Valid
          TSDInvalidationRequestDTO invalidationRequestDTO,
      @Context UriInfo uriInfo,
      @HeaderParam("accept-language") String language) {

    if (!crn.equals(invalidationRequestDTO.getCrn())) {
      log.debug(
          "Path CRN {} and invalidation request body CRN {} are not matching",
          crn,
          invalidationRequestDTO.getCrn());

      return Response.status(Response.Status.BAD_REQUEST)
          .entity(
              "The CRN provided in the path does not match the CRN provided in the body of the message")
          .build();
    }

    String correlationID = correlationIdGenerator.generateCorrelationID();
    String languageCode =
        languageUtil.determineLanguage(invalidationRequestDTO.getMessageHeader(), language);

    log.info(
        "correlation id,LanguageCode For this message with MRN {} is {},{}",
        invalidationRequestDTO.getCrn(),
        correlationID,
        languageCode);
    InvalidationRequest invalidationRequest =
        tsdMapper.mapToDomain(
            invalidationRequestDTO,
            correlationID,
            null == languageCode ? "" : languageCode,
            MessageInformationSource.B2B);
    invalidationService.receiveInvalidationRequest(crn, invalidationRequest);
    AcknowledgementDTO acknowledgementDTO = messageBuilder.buildAckMessage(correlationID);
    return Response.accepted(acknowledgementDTO).build();
  }

  @POST
  @ApiResponse(
      responseCode = "202",
      description = "Accepted",
      content = @Content(schema = @Schema(implementation = AcknowledgementDTO.class)))
  @ApiResponse(
      responseCode = "400",
      description = "Bad Request",
      content = @Content(schema = @Schema(implementation = NegativeAcknowledgementDTO.class)))
  @Path("/amend")
  @Operation(summary = "Submit a amendment request for a Temporary Storage Declaration IETS413")
  public Response submitAmendmentRequest(
      @ConvertGroup(from = Default.class, to = B2BOnly.class) @Valid
          TSDAmendmentRequestDTO amendmentRequestDTO,
      @Context UriInfo uriInfo,
      @HeaderParam("accept-language") String language) {

    String correlationID = correlationIdGenerator.generateCorrelationID();
    String languageCode =
        languageUtil.determineLanguage(amendmentRequestDTO.getMessageHeader(), language);

    log.info(
        "correlation id,LanguageCode For this message with CRN {} and MRN {} is {},{}",
        amendmentRequestDTO.getCrn(),
        amendmentRequestDTO.getMrn(),
        correlationID,
        languageCode);
    AmendmentRequest amendmentRequest =
        tsdMapper.mapToDomain(
            amendmentRequestDTO,
            correlationID,
            null == languageCode ? "" : languageCode,
            MessageInformationSource.B2B);
    amendmentService.receiveAmendmentRequest(amendmentRequest);
    AcknowledgementDTO acknowledgementDTO = messageBuilder.buildAckMessage(correlationID);
    return Response.accepted(acknowledgementDTO).build();
  }

  @POST
  @ApiResponse(
      responseCode = "202",
      description = "Accepted",
      content = @Content(schema = @Schema(implementation = AcknowledgementDTO.class)))
  @ApiResponse(
      responseCode = "400",
      description = "Bad Request",
      content = @Content(schema = @Schema(implementation = NegativeAcknowledgementDTO.class)))
  @Path("{mrn}/transfer")
  @Operation(
      summary =
          "Submit a TSD transfer notification message (IETS207) in order to "
              + "notify the transfer for one or more consignments of an accepted TSD "
              + "under temporary storage procedure")
  public Response submitTransferNotification(
      @NotNull @Size(min = 18, max = 18) @PathParam("mrn") String mrn,
      @ConvertGroup(from = Default.class, to = B2BOnly.class) @Valid
          TransferNotificationDTO transferNotificationDTO,
      @Context UriInfo uriInfo,
      @HeaderParam("accept-language") String language) {

    if (!mrn.equals(transferNotificationDTO.getMrn())) {
      log.debug(
          "Path MRN {} and transfer notification request body MRN {} are not matching",
          mrn,
          transferNotificationDTO.getMrn());

      return Response.status(Response.Status.BAD_REQUEST)
          .entity(
              "The MRN provided in the path does not match the MRN provided in the body of the message")
          .build();
    }

    String correlationID = correlationIdGenerator.generateCorrelationID();
    String languageCode =
        languageUtil.determineLanguage(transferNotificationDTO.getMessageHeader(), language);

    log.info(
        "Submit TransferNotification request received with MRN {}, LRN {} and LanguageCode {}. "
            + "Correlation id generated for this message is {}",
        transferNotificationDTO.getLrn(),
        mrn,
        languageCode,
        correlationID);

    TransferNotification transferNotification =
        tsdMapper.mapToDomain(
            transferNotificationDTO,
            correlationID,
            null == languageCode ? "" : languageCode,
            MessageInformationSource.B2B);

    transferNotificationService.receiveTransferNotification(mrn, transferNotification);

    AcknowledgementDTO acknowledgementDTO = messageBuilder.buildAckMessage(correlationID);
    return Response.accepted(acknowledgementDTO).build();
  }

  /**
   * Temporary Storage Declarations Submit Deconsolidation Notification
   *
   * @param mrn Movement Reference Number of the Temporary Storage Declaration. (required)
   * @return the response having acknowledgement message with (@link Response.Status.ACCEPTED) if
   *     sxd validation succeeds or negative acknowledgement message with (@link
   *     Response.Status.BAD_REQUEST) if xsd validation fails
   */
  @POST
  @ApiResponse(
      responseCode = "202",
      description = "Accepted",
      content = @Content(schema = @Schema(implementation = AcknowledgementDTO.class)))
  @ApiResponse(
      responseCode = "400",
      description = "Bad Request",
      content = @Content(schema = @Schema(implementation = NegativeAcknowledgementDTO.class)))
  @Path("{mrn}/deconsolidate")
  @Operation(
      summary =
          "Submit a TSD Deconsolidation Notification message (IETS215) in order to notify"
              + "deconsolidation for a MC of an accepted Temporary Storage Declaration"
              + "under temporary storage procedure")
  public Response submitDeconsolidationNotification(
      @NotNull @Size(min = 18, max = 18) @PathParam("mrn") String mrn,
      @ConvertGroup(from = Default.class, to = B2BOnly.class) @Valid
          DeconsolidationNotificationDTO deconsolidationNotificationDTO,
      @Context UriInfo uriInfo,
      @HeaderParam("accept-language") String language) {

    if (!mrn.equals(deconsolidationNotificationDTO.getMrn())) {
      log.debug(
          "Path MRN {} and Deconsolidation notification request body MRN {} are not matching",
          mrn,
          deconsolidationNotificationDTO.getMrn());
      return Response.status(Response.Status.BAD_REQUEST)
          .entity(
              "The MRN provided in the path does not match the MRN provided in the body of the message")
          .build();
    }

    String correlationID = correlationIdGenerator.generateCorrelationID();
    String languageCode =
        languageUtil.determineLanguage(deconsolidationNotificationDTO.getMessageHeader(), language);

    log.info(
        "Submit Deconsolidation Notification request received with MRN {}, LRN {} and LanguageCode {}. "
            + "Correlation id generated for this message is {}",
        mrn,
        deconsolidationNotificationDTO.getLrn(),
        languageCode,
        correlationID);

    DeconsolidationNotification deconsolidationNotification =
        tsdMapper.mapToDomain(
            deconsolidationNotificationDTO,
            correlationID,
            null == languageCode ? "" : languageCode,
            MessageInformationSource.B2B);

    deconsolidationNotificationService.receiveDeconsolidationNotification(
        mrn, deconsolidationNotification);

    AcknowledgementDTO acknowledgementDTO = messageBuilder.buildAckMessage(correlationID);
    return Response.accepted(acknowledgementDTO).build();
  }
}
