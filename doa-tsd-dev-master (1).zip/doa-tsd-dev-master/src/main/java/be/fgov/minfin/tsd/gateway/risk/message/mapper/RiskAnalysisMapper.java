/*
 * @(#) be.fgov.minfin.tsd.gateway.risk.message.mapper.RiskAnalysisMapper.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.risk.message.mapper;

import static be.fgov.minfin.tsd.util.DateFormatUtil.MESSAGE_DATE_TIME_FORMAT;

import be.fgov.minfin.risk.client.api.AdditionalSupplyChainActorDTO;
import be.fgov.minfin.risk.client.api.ConsignmentHeaderMasterLevelDTO;
import be.fgov.minfin.risk.client.api.ConsignmentHeaderMasterLevelTransferDTO;
import be.fgov.minfin.risk.client.api.ConsignmentHouseLevelDTO;
import be.fgov.minfin.risk.client.api.ConsignmentItemDTO;
import be.fgov.minfin.risk.client.api.ConsignmentMasterLevelDTO;
import be.fgov.minfin.risk.client.api.ConsignmentMasterOrHouseLevelTransferDTO;
import be.fgov.minfin.risk.client.api.CurrentLocationOfGoodsDTO;
import be.fgov.minfin.risk.client.api.InvalidationNotificationDTO;
import be.fgov.minfin.risk.client.api.RelatedTSDDTO;
import be.fgov.minfin.risk.client.api.RelatedTransferNotificationDTO;
import be.fgov.minfin.risk.client.api.SendRiskAnalysisRequestDTO;
import be.fgov.minfin.tsd.domain.model.ConsignmentLocationOfGoods;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.TransferNotification;
import be.fgov.minfin.tsd.domain.model.TransferNotificationHouseConsignment;
import be.fgov.minfin.tsd.domain.model.TransferNotificationMasterConsignment;
import be.fgov.minfin.tsd.domain.model.consignment.AdditionalSupplyChainActor;
import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentHeader;
import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentItem;
import be.fgov.minfin.tsd.domain.model.consignment.HouseConsignment;
import be.fgov.minfin.tsd.domain.model.consignment.MasterConsignment;
import be.fgov.minfin.tsd.gateway.risk.message.DeconsolidationNotificationHeader;
import be.fgov.minfin.tsd.gateway.risk.message.SendInvalidationNotification;
import be.fgov.minfin.tsd.gateway.risk.message.SendTSDRiskAnalysis;
import java.util.List;
import org.mapstruct.InjectionStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * This class is to map DTO
 *
 * @author MohdSalim
 */
@Mapper(injectionStrategy = InjectionStrategy.CONSTRUCTOR)
public interface RiskAnalysisMapper {

  @Mapping(
      target = "relatedTSD",
      expression =
          "java(map(message.getDeclaration(),message.getDeconsolidationNotificationHeader()))")
  @Mapping(target = "relatedTransferNotification", source = "declaration.transferNotification")
  SendRiskAnalysisRequestDTO map(SendTSDRiskAnalysis message);

  @Mapping(source = "tsd.referenceNumber.crn.crnNumber", target = "crn")
  @Mapping(source = "tsd.referenceNumber.mrn.mrnNumber", target = "mrn")
  @Mapping(
      target = "declarationDate",
      source = "tsd.declarationDate",
      dateFormat = MESSAGE_DATE_TIME_FORMAT)
  @Mapping(
      target = "dateAndTimeOfPresentationOfTheGoods",
      source = "tsd.dateAndTimeOfPresentationOfTheGoods",
      dateFormat = MESSAGE_DATE_TIME_FORMAT)
  @Mapping(
      target = "consignmentHeaderMasterLevel",
      expression =
          "java(map(tsd.getMasterConsignment(), tsd.getHouseConsignments(), tsd.getConsignmentHeader()))")
  @Mapping(target = "declarant", source = "tsd.declarant")
  @Mapping(target = "representative", source = "tsd.representative")
  RelatedTSDDTO map(
      TemporaryStorageDeclaration tsd,
      DeconsolidationNotificationHeader deconsolidationNotificationHeader);

  @Mapping(source = "masterConsignment", target = "consignmentMasterLevel")
  @Mapping(source = "houseConsignments", target = "consignmentHouseLevel")
  @Mapping(
      source = "consignmentHeader.decalaredlocationOfGoods",
      target = "locationOfGoodsDeclared")
  @Mapping(
      source = "consignmentHeader.presentedlocationOfGoods",
      target = "locationOfGoodsPresented")
  @Mapping(source = "consignmentHeader.arrivalTransportMeans", target = "arrivalTransportMeans")
  @Mapping(source = "consignmentHeader.warehouse", target = "warehouse")
  @Mapping(source = "consignmentHeader.placeOfUnloading", target = "placeOfUnloading")
  @Mapping(source = "consignmentHeader.carrier", target = "carrier")
  ConsignmentHeaderMasterLevelDTO map(
      MasterConsignment masterConsignment,
      List<HouseConsignment> houseConsignments,
      ConsignmentHeader consignmentHeader);

  @Mapping(target = "referenceNumberUCR.referenceNumberUCR", source = "referenceNumberUCR")
  @Mapping(target = "consignmentItemMasterLevel", source = "consignmentItem")
  @Mapping(target = "locationOfGoodsCurrent", source = "currentConsignmentLocationOfGoods")
  ConsignmentMasterLevelDTO map(MasterConsignment masterConsignment);

  @Mapping(target = "referenceNumberUCR.referenceNumberUCR", source = "referenceNumberUCR")
  @Mapping(target = "consignmentItemHouseLevel", source = "consignmentItem")
  @Mapping(target = "locationOfGoodsCurrent", source = "currentConsignmentLocationOfGoods")
  ConsignmentHouseLevelDTO map(HouseConsignment houseConsignment);

  @Mapping(target = "locationOfGoods", source = "transferredLocationOfGoods")
  CurrentLocationOfGoodsDTO map(ConsignmentLocationOfGoods consignmentLocationOfGoods);

  @Mapping(
      target = "supervisingCustomsOffice",
      source = "consignmentLocationOfGoods.supervisingCustomsOffice")
  @Mapping(
      target = "locationOfGoods",
      source = "consignmentLocationOfGoods.transferredLocationOfGoods")
  @Mapping(target = "warehouse", source = "consignmentLocationOfGoods.warehouse")
  @Mapping(
      target = "consignmentHeaderMasterLevel",
      expression =
          "java(map(transferNotification.getMasterConsignment(), transferNotification.getHouseConsignments()))")
  @Mapping(target = "registrationDate", dateFormat = MESSAGE_DATE_TIME_FORMAT)
  RelatedTransferNotificationDTO map(TransferNotification transferNotification);

  @Mapping(target = "consignmentMasterLevel", source = "masterConsignment")
  @Mapping(target = "consignmentHouseLevel", source = "houseConsignments")
  ConsignmentHeaderMasterLevelTransferDTO map(
      TransferNotificationMasterConsignment masterConsignment,
      List<TransferNotificationHouseConsignment> houseConsignments);

  @Mapping(target = "sequenceNumber", source = "consignment.sequenceNumber")
  ConsignmentMasterOrHouseLevelTransferDTO map(
      TransferNotificationHouseConsignment houseConsignment);

  @Mapping(target = "aeoAuthorisation", source = "aeoAuthorisations")
  AdditionalSupplyChainActorDTO map(AdditionalSupplyChainActor actor);

  @Mapping(target = "weight.grossMass", source = "grossMass")
  ConsignmentItemDTO map(ConsignmentItem item);

  InvalidationNotificationDTO invalidationMapper(SendInvalidationNotification message);
}
