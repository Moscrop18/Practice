/*
 * @(#) be.fgov.minfin.tsd.gateway.pn.message.mapper.PNMapper
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.pn.message.mapper;

import static be.fgov.minfin.tsd.util.DateFormatUtil.MESSAGE_DATE_TIME_FORMAT;

import be.fgov.minfin.pn.client.api.ConsignmentHeaderMasterLevelDTO;
import be.fgov.minfin.pn.client.api.ConsignmentHouseLevelDTO;
import be.fgov.minfin.pn.client.api.ConsignmentMasterLevelDTO;
import be.fgov.minfin.pn.client.api.PreviousDocumentDTO;
import be.fgov.minfin.pn.client.api.RegistrationRequestDTO;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentItem;
import be.fgov.minfin.tsd.domain.model.consignment.HouseConsignment;
import be.fgov.minfin.tsd.domain.model.consignment.MasterConsignment;
import be.fgov.minfin.tsd.domain.model.consignment.PreviousDocument;
import be.fgov.minfin.tsd.domain.model.consignment.TransportEquipment;
import be.fgov.minfin.tsd.gateway.pn.message.RegisterPNRequest;
import java.util.List;
import java.util.Optional;
import org.mapstruct.AfterMapping;
import org.mapstruct.InjectionStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

/**
 * This class is to map DTO
 *
 * @author NamrataGupta
 */
@Mapper(injectionStrategy = InjectionStrategy.CONSTRUCTOR)
public interface PNMapper {
  @Mapping(target = "lrn", source = "registerPNRequest.declaration.lrn")
  @Mapping(
      target = "customsOfficeOfPresentation",
      source = "registerPNRequest.declaration.customsOfficeOfPresentation")
  @Mapping(
      target = "personPresentingTheGoods",
      source = "registerPNRequest.declaration.personPresentingTheGoods")
  @Mapping(target = "declarant", source = "registerPNRequest.declaration.declarant")
  @Mapping(target = "representative", source = "registerPNRequest.declaration.representative")
  @Mapping(
      target = "dateAndTimeOfPresentationOfTheGoods",
      source = "registerPNRequest.declaration.dateAndTimeOfPresentationOfTheGoods",
      dateFormat = MESSAGE_DATE_TIME_FORMAT)
  @Mapping(
      target = "declarationDate",
      source = "registerPNRequest.declaration.declarationDate",
      dateFormat = MESSAGE_DATE_TIME_FORMAT)
  @Mapping(
      target = "consignmentHeaderMasterLevel",
      expression =
          "java(map( registerPNRequest.getDeclaration(), registerPNRequest.getPreviousDocument(), registerPNRequest.getTransportEquipmentList()))")
  RegistrationRequestDTO map(RegisterPNRequest registerPNRequest);

  PreviousDocumentDTO map(PreviousDocument previousDocument);

  @Mapping(
      target = "consignmentMasterLevel",
      expression =
          "java(map( tsd.getMasterConsignment(), masterPreviousDocument, transportEquipment))")
  @Mapping(target = "consignmentHouseLevel", expression = "java(map( tsd.getHouseConsignments()))")
  @Mapping(target = "locationOfGoods", source = "tsd.consignmentHeader.decalaredlocationOfGoods")
  @Mapping(target = "carrier", source = "tsd.consignmentHeader.carrier")
  ConsignmentHeaderMasterLevelDTO map(
      TemporaryStorageDeclaration tsd,
      PreviousDocument masterPreviousDocument,
      List<TransportEquipment> transportEquipment);

  ConsignmentHouseLevelDTO map(HouseConsignment dto);

  @Mapping(target = "previousDocument", source = "masterPreviousDocument")
  @Mapping(target = "transportEquipment", source = "transportEquipment")
  ConsignmentMasterLevelDTO map(
      MasterConsignment dto,
      PreviousDocument masterPreviousDocument,
      List<TransportEquipment> transportEquipment);

  List<ConsignmentHouseLevelDTO> map(List<HouseConsignment> lstDTO);

  @AfterMapping
  default void setPreviousDocument(
      List<HouseConsignment> dto, @MappingTarget List<ConsignmentHouseLevelDTO> consignment) {
    PreviousDocument previousDocument = null;
    for (HouseConsignment cons : dto) {
      if (null == cons) return;
      if (null != cons.getPreviousDocument()) {
        previousDocument = cons.getPreviousDocument();
      } else {
        Optional<ConsignmentItem> consignmentItem =
            cons.getConsignmentItem().stream()
                .filter(x -> null != x.getPreviousDocument())
                .findAny();
        if (consignmentItem.isPresent()) {
          previousDocument = consignmentItem.get().getPreviousDocument();
        }
      }
      if (null != previousDocument) break;
    }
    for (ConsignmentHouseLevelDTO houseDto : consignment) {
      PreviousDocumentDTO preDoc = map(previousDocument);
      houseDto.setPreviousDocument(preDoc);
    }
  }
}
