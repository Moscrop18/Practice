package be.fgov.minfin.tsd.domain.model;

public enum ConsignmentInformationType {
  MASTER(1),
  HOUSE(2),
  MASTERANDHOUSE(3);

  private final Integer value;

  private ConsignmentInformationType(Integer value) {
    this.value = value;
  }

  public Integer getValue() {
    return value;
  }
}
