/*
 * @(#)be.fgov.minfin.tsd.domain.model.consignment.AdditionalInformation
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model.consignment;

import be.fgov.minfin.tsd.domain.validation.annotation.CodeList;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import be.fgov.minfin.tsd.domain.validation.annotation.group.DeconsolidationNotificationValidatorGroup;
import be.fgov.minfin.tsd.domain.validation.codelist.TSDCodeLists;
import com.fasterxml.jackson.annotation.JsonBackReference;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.groups.Default;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "ADDITIONAL_INFORMATION")
@EqualsAndHashCode(exclude = {"consignmentItem", "consignment"})
@ValidateBusinessRules(groups = {Default.class, DeconsolidationNotificationValidatorGroup.class})
public class AdditionalInformation {
  @GeneratedValue(generator = "ADDITIONAL_INFORMATION_SEQ")
  @SequenceGenerator(
      name = "ADDITIONAL_INFORMATION_SEQ",
      sequenceName = "ADDITIONAL_INFORMATION_SEQ")
  @Id
  private Long id;

  private String text;

  @Column(columnDefinition = "char")
  @CodeList(
      value = TSDCodeLists.CL701,
      groups = {Default.class, DeconsolidationNotificationValidatorGroup.class})
  private String code;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "CONSIGNMENT_ID")
  @JsonBackReference(value = "consignment")
  private Consignment consignment;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "CONSIGNMENT_ITEM_ID")
  @JsonBackReference(value = "consignmentItem")
  private ConsignmentItem consignmentItem;
}
