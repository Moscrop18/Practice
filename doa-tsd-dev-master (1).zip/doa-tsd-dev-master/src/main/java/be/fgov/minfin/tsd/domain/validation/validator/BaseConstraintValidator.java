/*
 * @(#) be.fgov.minfin.tsd.domain.validation.validator.BaseConstraintValidator.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation.validator;

import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import javax.validation.ConstraintValidatorContext;
import javax.validation.ConstraintValidatorContext.ConstraintViolationBuilder;
import javax.validation.ConstraintValidatorContext.ConstraintViolationBuilder.NodeBuilderCustomizableContext;

/**
 * This is base constrain validator which contains generic methods for all validators
 *
 * @author GauravMitra
 */
public class BaseConstraintValidator {
  public static final String ERROR_CODE_PREFIX = "{error.";
  public static final String ERROR_CODE_SUFFIX = "}";

  /**
   * This method is used to add custom voilation with message templates and help to create custom
   * path
   *
   * @param context
   * @param errorCode
   * @param nodes
   */
  protected void addViolation(
      ConstraintValidatorContext context, Enum<ErrorCode> errorCode, String... nodes) {

    context.disableDefaultConstraintViolation();
    ConstraintViolationBuilder builder =
        context.buildConstraintViolationWithTemplate(createMessageTemplate(errorCode.name()));

    if (nodes.length > 0) {
      NodeBuilderCustomizableContext builderContext = null;
      for (String beanNode : nodes) {
        if (null == builderContext) {
          builderContext = builder.addPropertyNode(beanNode);
        } else {
          builderContext = builderContext.addPropertyNode(beanNode);
        }
      }
      if (null != builderContext) {
        builderContext.addConstraintViolation();
      }
    } else {
      builder.addConstraintViolation();
    }
  }

  /**
   * create message template
   *
   * @param code
   * @return
   */
  private String createMessageTemplate(String code) {
    StringBuilder builder = new StringBuilder();
    return builder.append(ERROR_CODE_PREFIX).append(code).append(ERROR_CODE_SUFFIX).toString();
  }
}
