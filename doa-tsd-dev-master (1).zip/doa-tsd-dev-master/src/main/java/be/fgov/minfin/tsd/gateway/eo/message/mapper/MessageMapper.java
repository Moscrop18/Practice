/*
 * @(#) be.fgov.minfin.tsd.gateway.eo.message.mapper.MessageMapper.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties
 * or made public without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.eo.message.mapper;

import static be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclarationType.PRELODGED;
import static be.fgov.minfin.tsd.util.DateFormatUtil.MESSAGE_DATE_TIME_FORMAT;
import static be.fgov.minfin.tsd.util.DateFormatUtil.MESSAGE_TIMESTAMP_FORMAT;

import be.fgov.minfin.tsd.domain.message.Error;
import be.fgov.minfin.tsd.domain.message.MessageHeader;
import be.fgov.minfin.tsd.domain.message.SendIntendedControlNotification;
import be.fgov.minfin.tsd.domain.message.TSDAcceptMessage;
import be.fgov.minfin.tsd.domain.message.TSDActivationNotification;
import be.fgov.minfin.tsd.domain.message.TSDAmendmentRejectMessage;
import be.fgov.minfin.tsd.domain.message.TSDDeconsolidationNotificationAcceptMessage;
import be.fgov.minfin.tsd.domain.message.TSDDeconsolidationNotificationRefusedMessage;
import be.fgov.minfin.tsd.domain.message.TSDInvalidationNotification;
import be.fgov.minfin.tsd.domain.message.TSDInvalidationRefusedMessage;
import be.fgov.minfin.tsd.domain.message.TSDRejectMessage;
import be.fgov.minfin.tsd.domain.message.TSDTransferNotificationAcceptMessage;
import be.fgov.minfin.tsd.domain.message.TSDTransferNotificationRefusedMessage;
import be.fgov.minfin.tsd.domain.model.BusinessValidationType;
import be.fgov.minfin.tsd.domain.model.party.Party;
import be.fgov.minfin.tsd.domain.model.party.PersonPresentingTheGoods;
import be.fgov.minfin.tsd.domain.model.party.Representative;
import be.fgov.minfin.tsd.gateway.eo.api.AcceptMessageDTO;
import be.fgov.minfin.tsd.gateway.eo.api.ActivationNotificationDTO;
import be.fgov.minfin.tsd.gateway.eo.api.DeclarantControlIntendedDTO;
import be.fgov.minfin.tsd.gateway.eo.api.ErrorDTO;
import be.fgov.minfin.tsd.gateway.eo.api.InvalidationNotificationDTO;
import be.fgov.minfin.tsd.gateway.eo.api.MessageHeaderDTO;
import be.fgov.minfin.tsd.gateway.eo.api.PersonPresentingTheGoodsICDTO;
import be.fgov.minfin.tsd.gateway.eo.api.RejectMessageDTO;
import be.fgov.minfin.tsd.gateway.eo.api.RepresentativeIntendedControlDTO;
import be.fgov.minfin.tsd.gateway.eo.api.SendIntendedControlDTO;
import be.fgov.minfin.tsd.resource.api.ControlSubjectDTO;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import org.mapstruct.AfterMapping;
import org.mapstruct.InjectionStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

/**
 * @author GauravMitra
 */
@Mapper(injectionStrategy = InjectionStrategy.CONSTRUCTOR)
public interface MessageMapper {

  @Mapping(target = "mrn", source = "declaration.referenceNumber.mrn.mrnNumber")
  @Mapping(
      target = "lrn",
      expression =
          "java(message.getBusinessValidationType()==be.fgov.minfin.tsd.domain.model.BusinessValidationType.TSD_AMENDMENT_REQUEST?null:message.getDeclaration().getLrn())")
  @Mapping(target = ".", source = "declaration")
  @Mapping(target = "notificationDate", dateFormat = MESSAGE_DATE_TIME_FORMAT)
  @Mapping(target = "expirationDate", dateFormat = MESSAGE_DATE_TIME_FORMAT)
  @Mapping(
      target = "timerForTemporaryStorage",
      source = "declaration.temporaryStorageExpirationTimestamp",
      dateFormat = MESSAGE_DATE_TIME_FORMAT)
  AcceptMessageDTO map(TSDAcceptMessage message);

  @Mapping(target = "crn", source = "declaration.referenceNumber.crn.crnNumber")
  @Mapping(target = "mrn", source = "declaration.referenceNumber.mrn.mrnNumber")
  @Mapping(target = ".", source = "declaration")
  @Mapping(target = "notificationDate", dateFormat = MESSAGE_DATE_TIME_FORMAT)
  RejectMessageDTO map(TSDRejectMessage message);

  @Mapping(target = ".", source = "declaration")
  @Mapping(target = "mrn", source = "declaration.referenceNumber.mrn.mrnNumber")
  @Mapping(target = "crn", source = "declaration.referenceNumber.crn.crnNumber")
  @Mapping(target = "status", source = "declaration.currentStatus")
  @Mapping(
      target = "timerForTemporaryStorage",
      source = "declaration.temporaryStorageExpirationTimestamp",
      dateFormat = MESSAGE_DATE_TIME_FORMAT)
  @Mapping(target = "relatedPN.frn", source = "linkedPnFrn")
  @Mapping(target = "relatedPN.customsOfficeOfPresentation", source = "customsOfficeOfPresentation")
  @Mapping(
      target = "relatedPN.dateAndTimeOfPresentationOfTheGoods",
      source = "dateAndTimeOfPresentationOfTheGoods",
      dateFormat = MESSAGE_DATE_TIME_FORMAT)
  @Mapping(target = "notificationDate", dateFormat = MESSAGE_DATE_TIME_FORMAT)
  ActivationNotificationDTO map(TSDActivationNotification notification);

  @Mapping(target = "messageTimestamp", dateFormat = MESSAGE_TIMESTAMP_FORMAT)
  MessageHeaderDTO map(MessageHeader header);

  ErrorDTO map(Error error);

  List<ErrorDTO> map(List<Error> errors);

  RejectMessageDTO map(TSDInvalidationRefusedMessage message);

  InvalidationNotificationDTO map(TSDInvalidationNotification notification);

  @AfterMapping
  default void setReferenceAttributes(
      TSDAcceptMessage dto,
      @MappingTarget AcceptMessageDTO.AcceptMessageDTOBuilder acceptMessageBuilder) {
    if (dto.getDeclaration().getType() == PRELODGED) {
      acceptMessageBuilder
          .crn(dto.getDeclaration().getReferenceNumber().getCrn().getCrnNumber())
          .build();
    }
    if (dto.getBusinessValidationType() == BusinessValidationType.TSD_AMENDMENT_REQUEST) {
      acceptMessageBuilder.lrn(null);
    }
  }

  // INtendedControl
  @Mapping(
      target = "crn",
      source = "sendIntendedControlNotification.declaration.referenceNumber.crn.crnNumber")
  @Mapping(target = "mrn", source = "declaration.referenceNumber.mrn.mrnNumber")
  @Mapping(
      target = "declarant",
      expression =
          "java(mapDeclarant( sendIntendedControlNotification.getIsTransferMessageSender(), sendIntendedControlNotification.getIsDeconsolidationMessageSender(), sendIntendedControlNotification.getDeclaration().getDeclarant()))")
  @Mapping(
      target = "personPresentingTheGoods",
      expression =
          "java(mapPersonPresentingTheGoods( sendIntendedControlNotification.getIsTransferMessageSender(),sendIntendedControlNotification.getIsDeconsolidationMessageSender(),sendIntendedControlNotification.getDeclaration().getPersonPresentingTheGoods()))")
  @Mapping(
      target = "representative",
      expression =
          "java(mapRepresentative(sendIntendedControlNotification.getIsTransferMessageSender(), sendIntendedControlNotification.getIsDeconsolidationMessageSender(), sendIntendedControlNotification.getDeclaration().getRepresentative()))")
  @Mapping(
      target = "customsOfficeOfControl",
      source = "receiveRiskAnalysisResult.customsOfficeOfControl")
  @Mapping(target = "typeOfControls", source = "receiveRiskAnalysisResult.typeOfControls")
  @Mapping(target = "messageHeader.messageTimestamp", dateFormat = MESSAGE_DATE_TIME_FORMAT)
  @Mapping(target = "requestedDocument", source = "receiveRiskAnalysisResult.requestedDocument")
  @Mapping(target = "control", source = "receiveRiskAnalysisResult.controlRecommendations")
  SendIntendedControlDTO intendedControlmap(
      SendIntendedControlNotification sendIntendedControlNotification);

  default DeclarantControlIntendedDTO mapDeclarant(
      boolean isTransferSender, boolean isDeconsolidationSender, Party declarant) {
    if (isTransferSender || isDeconsolidationSender) {
      return null;
    }
    return mapDeclarantControlIntendedDTO(declarant);
  }

  DeclarantControlIntendedDTO mapDeclarantControlIntendedDTO(Party declarant);

  default RepresentativeIntendedControlDTO mapRepresentative(
      boolean isTransferSender, boolean isDeconsolidationSender, Representative representative) {
    if (isTransferSender || isDeconsolidationSender) {
      return null;
    }
    return mapRepresentativeIntendedControlDTO(representative);
  }

  RepresentativeIntendedControlDTO mapRepresentativeIntendedControlDTO(
      Representative representative);

  default PersonPresentingTheGoodsICDTO mapPersonPresentingTheGoods(
      boolean isTransferSender,
      boolean isDeconsolidationSender,
      PersonPresentingTheGoods personPresentingTheGoods) {
    if (isTransferSender || isDeconsolidationSender) {
      return null;
    }
    return mapPersonPresentingTheGoodsICDTO(personPresentingTheGoods);
  }

  PersonPresentingTheGoodsICDTO mapPersonPresentingTheGoodsICDTO(
      PersonPresentingTheGoods personPresentingTheGoods);

  default ControlSubjectDTO mapControlSubject(String controlSubject)
      throws JsonProcessingException {
    ObjectMapper mapper = new ObjectMapper();
    return mapper.readValue(controlSubject, ControlSubjectDTO.class);
  }

  @Mapping(target = "notificationDate", dateFormat = MESSAGE_DATE_TIME_FORMAT)
  RejectMessageDTO map(TSDTransferNotificationRefusedMessage message);

  @Mapping(target = "notificationDate", dateFormat = MESSAGE_DATE_TIME_FORMAT)
  @Mapping(
      target = "timerForTemporaryStorage",
      source = "declaration.temporaryStorageExpirationTimestamp",
      dateFormat = MESSAGE_DATE_TIME_FORMAT)
  AcceptMessageDTO map(TSDTransferNotificationAcceptMessage tsdTransferNotificationAcceptMessage);

  @Mapping(
      target = "timerForTemporaryStorage",
      source = "temporaryStorageExpirationTimestamp",
      dateFormat = MESSAGE_DATE_TIME_FORMAT)
  @Mapping(target = "notificationDate", dateFormat = MESSAGE_DATE_TIME_FORMAT)
  AcceptMessageDTO map(
      TSDDeconsolidationNotificationAcceptMessage tsdDeconsolidationNotificationAcceptMessage);

  @Mapping(target = "notificationDate", dateFormat = MESSAGE_DATE_TIME_FORMAT)
  RejectMessageDTO map(TSDDeconsolidationNotificationRefusedMessage message);

  @Mapping(target = "crn", source = "amendedDeclaration.referenceNumber.crn.crnNumber")
  @Mapping(target = "mrn", source = "amendedDeclaration.referenceNumber.mrn.mrnNumber")
  @Mapping(target = ".", source = "amendedDeclaration")
  @Mapping(target = "notificationDate", dateFormat = MESSAGE_DATE_TIME_FORMAT)
  RejectMessageDTO map(TSDAmendmentRejectMessage message);
}
