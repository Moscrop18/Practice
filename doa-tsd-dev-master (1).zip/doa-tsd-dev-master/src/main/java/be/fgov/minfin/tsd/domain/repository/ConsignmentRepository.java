/*
 * @(#) be.fgov.minfin.tsd.domain.repository.ConsignmentRepository
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.repository;

import be.fgov.minfin.libdoa.pagination.repository.JpaSpecificationProjectionRepository;
import be.fgov.minfin.tsd.domain.model.CRN;
import be.fgov.minfin.tsd.domain.model.MRN;
import be.fgov.minfin.tsd.domain.model.consignment.AllowedSectionsDetail;
import be.fgov.minfin.tsd.domain.model.consignment.Consignment;
import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentProjection;
import be.fgov.minfin.tsd.domain.model.consignment.ItemDraftError;
import java.util.List;
import java.util.Optional;
import javax.persistence.LockModeType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

public interface ConsignmentRepository
    extends JpaRepository<Consignment, Long>,
        JpaSpecificationExecutor<Consignment>,
        JpaSpecificationProjectionRepository<Consignment> {
  @Query(value = "select max(sequenceNumber) from Consignment c where c.declaration.id = :tsdId")
  Integer findMaxSequenceNumberByDeclarationId(Long tsdId);

  @Lock(LockModeType.OPTIMISTIC_FORCE_INCREMENT)
  @Query(
      value =
          "select cons from Consignment cons "
              + "where cons.declaration.id=:tsdId and cons.sequenceNumber=:sequenceNumber")
  Optional<Consignment> getConsignmentWithOptimisticForceIncrement(
      Integer sequenceNumber, Long tsdId);

  @Query(
      value =
          "select cons from Consignment cons "
              + "join TemporaryStorageDeclaration tsd on cons.declaration.id = tsd.id "
              + "left join ReferenceNumber rn on tsd.id = rn.declaration.id "
              + "where cons.sequenceNumber=:sequenceNumber and (tsd.id=:tsdId or rn.crn=:crn or rn.mrn=:mrn)")
  Optional<Consignment> getConsignment(Integer sequenceNumber, Long tsdId, CRN crn, MRN mrn);

  @Query(
      value =
          "select "
              + "exists ( select 1 from ConsignmentItem ci "
              + "where ci.consignment.id = cons.id ) as itemPresent, "
              + "exists ( select 1 from ConsignmentItem ci "
              + "where ci.consignment.id = cons.id "
              + "and ((tsd.ensReUseIndicator is null or tsd.ensReUseIndicator != '1') and ci.previousDocument is null) "
              + "or (tsd.ensReUseIndicator = '1' and (cons.sequenceNumber = 0 or cons.sequenceNumber = 1))) as previousDocument, "
              + "exists ( select 1 from ConsignmentItem ci "
              + "left join TransportEquipment te on te.consignmentItem.id = ci.id "
              + "where ci.consignment.id = cons.id and (tsd.ensReUseIndicator is null or tsd.ensReUseIndicator != '1') and te.consignmentItem.id is null) as transportEquipment, "
              + "exists ( select 1 from ConsignmentItem ci "
              + "left join AdditionalSupplyChainActor asca on asca.consignmentItem.id = ci.id "
              + "where ci.consignment.id = cons.id and (tsd.ensReUseIndicator is null or tsd.ensReUseIndicator != '1') and asca.consignmentItem.id is null) as additionalSupplyChainActor, "
              + "exists ( select 1 from ConsignmentItem ci "
              + "left join AdditionalInformation ai on ai.consignmentItem.id = ci.id "
              + "where ci.consignment.id = cons.id and (tsd.ensReUseIndicator is null or tsd.ensReUseIndicator != '1') and ai.consignmentItem.id is null) as additionalInformation, "
              + "exists ( select 1 from ConsignmentItem ci "
              + "left join SupportingDocument sd on sd.consignmentItem.id = ci.id "
              + "where ci.consignment.id = cons.id and (tsd.ensReUseIndicator is null or tsd.ensReUseIndicator != '1') and sd.consignmentItem.id is null) as supportingDocument, "
              + "exists ( select 1 from Consignment c "
              + "where c.id=cons.id and (tsd.ensReUseIndicator is null or tsd.ensReUseIndicator != '1') and c.sequenceNumber != 0) as additionalReference, "
              + "exists ( select 1 from Consignment c "
              + "where c.id=cons.id and (tsd.ensReUseIndicator is null or tsd.ensReUseIndicator != '1') and c.sequenceNumber = 0) as receptacle "
              + "from Consignment cons "
              + "join TemporaryStorageDeclaration tsd on cons.declaration.id = tsd.id "
              + "left join ReferenceNumber rn on tsd.id = rn.declaration.id "
              + "where cons.sequenceNumber=:sequenceNumber and (tsd.id=:tsdId or rn.crn=:crn or rn.mrn=:mrn)")
  AllowedSectionsDetail listSectionsOfItemsForConsignment(
      Integer sequenceNumber, Long tsdId, CRN crn, MRN mrn);

  @Query(
      value =
          "delete from SupportingDocument where id in "
              + "( select distinct sd.id "
              + "from SupportingDocument sd "
              + "left join Consignment c on (c.id = sd.consignment.id or c.id=sd.consignmentItem.consignment.id) "
              + "left join ConsignmentItem item on item.id = sd.consignmentItem.id and item.consignment.id = c.id "
              + "where c.id=:consignmentId "
              + ")")
  @Modifying
  void deleteSupportingDocumentLinkedWithConsignmentId(Long consignmentId);

  @Query(
      value =
          "delete from AdditionalReference where id in "
              + "( select distinct ar.id "
              + "from AdditionalReference ar "
              + "left join Consignment c on (c.id = ar.consignment.id or c.id=ar.consignmentItem.consignment.id) "
              + "left join ConsignmentItem item on item.id = ar.consignmentItem.id and item.consignment.id = c.id "
              + "where c.id=:consignmentId "
              + ")")
  @Modifying
  void deleteAdditionalReferenceLinkedWithConsignmentId(Long consignmentId);

  @Query(
      value =
          "delete from AEOAuthorisation where id in "
              + "( select distinct auth.id "
              + "from AEOAuthorisation auth "
              + "inner join AdditionalSupplyChainActor chainActor on auth.chainActor.id=chainActor.id "
              + "left join Consignment c on (c.id = chainActor.consignment.id or c.id=chainActor.consignmentItem.consignment.id) "
              + "left join ConsignmentItem item on item.id = chainActor.consignmentItem.id and item.consignment.id = c.id "
              + "where c.id=:consignmentId "
              + ")")
  @Modifying
  void deleteAeoAuthLinkedWithConsignmentId(Long consignmentId);

  @Query(
      value =
          "delete from AdditionalSupplyChainActor where id in "
              + "( select distinct chainActor.id "
              + "from AdditionalSupplyChainActor chainActor "
              + "left join Consignment c on (c.id = chainActor.consignment.id or c.id=chainActor.consignmentItem.consignment.id) "
              + "left join ConsignmentItem item on item.id = chainActor.consignmentItem.id and item.consignment.id = c.id "
              + "where c.id=:consignmentId "
              + ")")
  @Modifying
  void deleteSupplyChainActorLinkedWithConsignmentId(Long consignmentId);

  @Query(
      value =
          "delete from AdditionalInformation where id in "
              + "( select distinct ai.id "
              + "from AdditionalInformation ai "
              + "left join Consignment c on (c.id = ai.consignment.id or c.id=ai.consignmentItem.consignment.id) "
              + "left join ConsignmentItem item on item.id = ai.consignmentItem.id and item.consignment.id = c.id "
              + "where c.id=:consignmentId "
              + ")")
  @Modifying
  void deleteAdditionalInformationLinkedWithConsignmentId(Long consignmentId);

  @Query(
      value =
          "delete from Seal where id in "
              + "( select distinct s.id "
              + "from Seal s "
              + "inner join TransportEquipment te on s.transportEquipment.id=te.id "
              + "left join Consignment c on (c.id = te.consignment.id or c.id=te.consignmentItem.consignment.id) "
              + "left join ConsignmentItem item on item.id = te.consignmentItem.id and item.consignment.id = c.id "
              + "where c.id=:consignmentId "
              + ")")
  @Modifying
  void deleteSealLinkedWithConsignmentId(Long consignmentId);

  @Query(
      value =
          "delete from TransportEquipment where id in "
              + "( select distinct te.id "
              + "from TransportEquipment te "
              + "left join Consignment c on (c.id = te.consignment.id or c.id=te.consignmentItem.consignment.id) "
              + "left join ConsignmentItem item on item.id = te.consignmentItem.id and item.consignment.id = c.id "
              + "where c.id=:consignmentId "
              + ")")
  @Modifying
  void deleteTransportEquipmentLinkedWithConsignmentId(Long consignmentId);

  @Query(
      value =
          "delete from Packaging where id in "
              + "( select distinct p.id   "
              + "from Packaging p "
              + "inner join  ConsignmentItem item on item.id = p.consignmentItem.id  "
              + "inner join Consignment c on (c.id = p.consignmentItem.consignment.id ) "
              + "where c.id=:consignmentId "
              + ")")
  @Modifying
  void deletePackagingLinkedWithConsignmentId(Long consignmentId);

  @Query(
      value =
          "delete from Receptacle where id in "
              + "( select distinct r.id "
              + "from Receptacle r "
              + "inner join Consignment c on c.id = r.consignment.id "
              + "where c.id=:consignmentId "
              + ")")
  @Modifying
  void deleteReceptacleLinkedWithConsignmentId(Long consignmentId);

  @Query(
      value =
          "delete from ConsignmentItem where id in "
              + "( select distinct item.id "
              + "from ConsignmentItem item "
              + "inner join Consignment c on (c.id = item.consignment.id ) "
              + "where c.id=:consignmentId "
              + ")")
  @Modifying
  void deleteConsignmentItemLinkedWithConsignmentId(Long consignmentId);

  @Query(value = "select c.consignor.id from Consignment c " + "where c.id=:consignmentId")
  List<Long> getConsignorLinkedWithConsignmentId(Long consignmentId);

  @Query(value = "select c.consignee.id from Consignment c  " + "where c.id=:consignmentId")
  List<Long> getConsigneeLinkedWithConsignmentId(Long consignmentId);

  @Query(value = "select c.notifyParty.id from Consignment c  " + "where c.id=:consignmentId")
  List<Long> getNotifyPartyLinkedWithConsignmentId(Long consignmentId);

  @Query(value = "delete from Communication com where  com.party.id in (:partysId)")
  @Modifying
  void deleteAllCommunication(List<Long> partysId);

  @Query(value = "delete from Party p where  p.id in (:partysId)")
  @Modifying
  void deleteAllPartys(List<Long> partysId);

  @Query(value = "delete from Consignment where id =:consignmentId")
  @Modifying
  void deleteConsignment(Long consignmentId);

  @Query(value = "select count(c) from HouseConsignment c where c.declaration.id = :tsdId")
  long countHouseConsignments(Long tsdId);

  @Query(
      value =
          "Update HouseConsignment c "
              + "set c.sequenceNumber = c.sequenceNumber - 1 "
              + "where c.declaration.id=:tsdId and c.sequenceNumber > :sequenceNumber")
  @Modifying
  int updateSequenceOfHouseConsignments(Long tsdId, Integer sequenceNumber);

  @Query(
      value =
          "select c from Consignment c "
              + "where c.declaration.id = :tsdId and TYPE(c) in :requiredTypes")
  Page<ConsignmentProjection> findConsignments(
      Long tsdId, List<Class<?>> requiredTypes, Pageable pageable);

  @Query(
      value =
          "select cons.sequenceNumber as sequenceNumber, "
              + "exists (select 1 from ConsignmentItem ci "
              + "where ci.consignment.id = cons.id and ci.draftError is 1 ) as hasErrorItem, "
              + "exists (select 1 from ConsignmentItem ci "
              + "where ci.consignment.id = cons.id and ci.draftError is 2 ) as hasEmptyItem "
              + "from Consignment cons "
              + "where cons.id in :consignmentIds")
  List<ItemDraftError> calculateItemDraftError(List<Long> consignmentIds);

  @Query(
      value =
          "select cons from Consignment cons "
              + "where cons.transportDocument.referenceNumber =:referenceNumber AND cons.transportDocument.type =:type"
              + " AND cons.declaration.id =:tsdId")
  Consignment findByTransportDocumentAndType(String referenceNumber, String type, Long tsdId);
}
