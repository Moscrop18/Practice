/*
 * @(#) be.fgov.minfin.tsd.domain.validation.RiskAnalysisValidator.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation;

import be.fgov.minfin.tsd.domain.model.ReceiveRiskAnalysisResult;
import be.fgov.minfin.tsd.domain.model.TSDStatus;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.consignment.Consignment;
import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentItem;
import be.fgov.minfin.tsd.domain.model.consignment.HouseConsignment;
import be.fgov.minfin.tsd.domain.model.consignment.MasterConsignment;
import be.fgov.minfin.tsd.domain.model.consignment.Receptacle;
import be.fgov.minfin.tsd.domain.model.consignment.TransportDocument;
import be.fgov.minfin.tsd.domain.model.consignment.TransportEquipment;
import be.fgov.minfin.tsd.domain.model.risk.ControlRecommendation;
import be.fgov.minfin.tsd.domain.model.risk.RiskAnalysisRequest;
import be.fgov.minfin.tsd.domain.model.risk.RiskAndControlStatus;
import be.fgov.minfin.tsd.domain.validation.annotation.group.RiskResultValidator;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import be.fgov.minfin.tsd.domain.validation.message.MessageType;
import be.fgov.minfin.tsd.domain.validation.plugin.RiskAnalysisValidatorPlugin;
import be.fgov.minfin.tsd.domain.validation.resolver.CustomTraversableResolver;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.hibernate.validator.HibernateValidatorFactory;
import org.hibernate.validator.internal.engine.resolver.JPATraversableResolver;
import org.springframework.stereotype.Component;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;

/**
 * @author GauravMitra
 */
@Slf4j
@RequiredArgsConstructor
@Component
public class RiskAnalysisValidator implements RiskAnalysisValidatorPlugin {

  private static final String FUNCTIONAL_REFERENCE = "Functional reference";
  private static final String RISK_REFERENCE = "Risk analysis / Risk analysis request reference";
  private final LocalValidatorFactoryBean factory;
  private final CustomTraversableResolver resolver;

  private static final String CONTROL_RECOMMENDATION = "controlRecommendations.";
  private static final String CONTROL_SUBJECT = "controlSubject.";
  private static final String MASTER_CONSIGNMENT = "masterConsignment.";
  private static final String HOUSE_CONSIGNMENT = "houseConsignment.";
  private static final String TRANSPORT_EQUIPMENT = "transportEquipment.";
  private static final String CONTAINER_INDENTIFICATION_NUMBER = "containerIndentificationNumber";
  private static final String RECEPTACLE = "receptacle";
  private static final String INDENTIFICATION_NUMBER = "indentificationNumber";
  private static final String GOODSITEM = "goodsItem";
  private static final String GOODSITEM_NUMBER = "goodsItemNumber";

  public Set<ConstraintViolation<TemporaryStorageDeclaration>> validateRiskHitNotification(
      final Optional<TemporaryStorageDeclaration> declaration,
      String riskAnalysisRequestReference,
      Optional<RiskAnalysisRequest> latestReference) {
    Set<ConstraintViolation<TemporaryStorageDeclaration>> allViolations = new HashSet<>();
    if (declaration.isPresent()) {
      validateCurrentStatus(declaration.get(), allViolations);
      validateRacStatus(declaration.get(), allViolations);
      if (latestReference.isPresent())
        validateRiskAnalysisRequestReference(
            latestReference.get().getReference(), riskAnalysisRequestReference, allViolations);
    } else {
      CustomViolation<TemporaryStorageDeclaration> violation = null;
      violation = new CustomViolation<>(ErrorCode.TSPNESXXR0400, FUNCTIONAL_REFERENCE);
      allViolations.add(violation);
    }
    return allViolations;
  }

  private void validateCurrentStatus(
      TemporaryStorageDeclaration requestTSD,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    if (requestTSD.getCurrentStatus() != TSDStatus.PRELODGED
        && requestTSD.getCurrentStatus() != TSDStatus.ACCEPTED
        && requestTSD.getCurrentStatus() != TSDStatus.IRREGULARITY_UNDER_INVESTIGATION
        && requestTSD.getCurrentStatus() != TSDStatus.AMENDMENT_REQUIRED
        && requestTSD.getCurrentStatus() != TSDStatus.MEASURES_REQUIRED) {
      CustomViolation<TemporaryStorageDeclaration> violation =
          new CustomViolation<>(ErrorCode.TSPNESXXR0401, FUNCTIONAL_REFERENCE);
      violations.add(violation);
    }
  }

  private void validateRacStatus(
      TemporaryStorageDeclaration requestTSD,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    if (requestTSD.getCurrentRiskControlStatus()
        != RiskAndControlStatus.AWAITING_RISK_ANALYSIS_RESULT) {
      CustomViolation<TemporaryStorageDeclaration> violation =
          new CustomViolation<>(ErrorCode.TSPNESXXR0402, FUNCTIONAL_REFERENCE);
      violations.add(violation);
    }
  }

  private void validateRiskAnalysisRequestReference(
      String latestReference,
      String riskAnalysisRequestReference,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    if (!latestReference.equals(riskAnalysisRequestReference)) {
      CustomViolation<TemporaryStorageDeclaration> violation =
          new CustomViolation<>(ErrorCode.TSPNESXXR0403, RISK_REFERENCE);
      violations.add(violation);
    }
  }

  @Override
  public Set<ConstraintViolation<ReceiveRiskAnalysisResult>> validateRiskAnalysisResult(
      Optional<TemporaryStorageDeclaration> optDeclaration,
      ReceiveRiskAnalysisResult receiveRiskAnalysisResult,
      List<RiskAnalysisRequest> allRiskRequests,
      MessageType messageType) {

    new JPATraversableResolver();
    Validator validator =
        factory
            .unwrap(HibernateValidatorFactory.class)
            .usingContext()
            .constraintValidatorPayload(messageType)
            // Validation skiping in case of loaded entity's thats why added
            .traversableResolver(resolver)
            .getValidator();

    Set<ConstraintViolation<ReceiveRiskAnalysisResult>> allViolations =
        validator.validate(receiveRiskAnalysisResult, RiskResultValidator.class);

    if (log.isDebugEnabled()) {
      allViolations.stream()
          .forEach(
              v ->
                  log.info(
                      "violation with message {} and path {}",
                      v.getMessage(),
                      v.getPropertyPath()));
    }
    if (allViolations.isEmpty()) {
      allViolations = new HashSet<>();
    }
    String riskAnalysisRequestReference =
        receiveRiskAnalysisResult.getRiskAnalysisRequestReference();
    if (optDeclaration.isPresent()) {
      TemporaryStorageDeclaration declaration = optDeclaration.get();
      validateRulesForControlRecommendation(receiveRiskAnalysisResult, allViolations, declaration);
      validateTSDCurrentStatus(declaration, allViolations);
      validateRiskAnalysisControlStatus(declaration, allViolations);
      List<RiskAnalysisRequest> sortedRiskAnalysisList = null;
      if (!CollectionUtils.isEmpty(allRiskRequests)) {
        sortedRiskAnalysisList =
            allRiskRequests.stream()
                .sorted(Comparator.comparing(RiskAnalysisRequest::getTimestamp).reversed())
                .toList();
        validateLatestRiskAnalysisRequestReference(
            sortedRiskAnalysisList.get(0).getReference(),
            riskAnalysisRequestReference,
            allViolations);
      }

    } else {
      ConstraintViolation<ReceiveRiskAnalysisResult> violation = null;
      violation = new CustomViolation<>(ErrorCode.TSPNESXXR0400, FUNCTIONAL_REFERENCE);
      allViolations.add(violation);
    }
    validateNotificationAllowed(receiveRiskAnalysisResult, allViolations);
    return allViolations;
  }

  private void validateNotificationAllowed(
      ReceiveRiskAnalysisResult receiveRiskAnalysisResult,
      Set<ConstraintViolation<ReceiveRiskAnalysisResult>> violations) {
    if (Boolean.FALSE.equals(
        receiveRiskAnalysisResult.getRiskAnalysisResponse().getIsValidNotificationAllowed())) {
      CustomViolation<ReceiveRiskAnalysisResult> violation =
          new CustomViolation<>(ErrorCode.TSPNESXXC0417, RISK_REFERENCE);
      violations.add(violation);
    }
  }

  private void validateTSDCurrentStatus(
      TemporaryStorageDeclaration requestTSD,
      Set<ConstraintViolation<ReceiveRiskAnalysisResult>> allViolations) {

    if (requestTSD.getCurrentStatus() != TSDStatus.PRELODGED
        && requestTSD.getCurrentStatus() != TSDStatus.ACCEPTED
        && requestTSD.getCurrentStatus() != TSDStatus.IRREGULARITY_UNDER_INVESTIGATION
        && requestTSD.getCurrentStatus() != TSDStatus.AMENDMENT_REQUIRED
        && requestTSD.getCurrentStatus() != TSDStatus.MEASURES_REQUIRED) {

      CustomViolation<ReceiveRiskAnalysisResult> violation =
          new CustomViolation<>(ErrorCode.TSPNESXXR0404, FUNCTIONAL_REFERENCE);
      allViolations.add(violation);
    }
  }

  private void validateRiskAnalysisControlStatus(
      TemporaryStorageDeclaration requestTSD,
      Set<ConstraintViolation<ReceiveRiskAnalysisResult>> allViolations) {
    if ((requestTSD.getCurrentRiskControlStatus()
            != RiskAndControlStatus.AWAITING_RISK_ANALYSIS_RESULT)
        && (requestTSD.getCurrentRiskControlStatus()
            != RiskAndControlStatus.AWAITING_RISK_HIT_CONFIRMATION)) {
      CustomViolation<ReceiveRiskAnalysisResult> violation =
          new CustomViolation<>(ErrorCode.TSPNESXXR0405, FUNCTIONAL_REFERENCE);
      allViolations.add(violation);
    }
  }

  private void validateLatestRiskAnalysisRequestReference(
      String latestReference,
      String riskAnalysisRequestReference,
      Set<ConstraintViolation<ReceiveRiskAnalysisResult>> allViolations) {
    if (!latestReference.equals(riskAnalysisRequestReference)) {
      ConstraintViolation<ReceiveRiskAnalysisResult> violation =
          new CustomViolation<>(ErrorCode.TSPNESXXR0403, RISK_REFERENCE);
      allViolations.add(violation);
    }
  }

  /**
   * validate business validations with respect to controlRecommendations
   *
   * @param receiveRiskAnalysisResult
   * @param allViolations
   * @param declaration
   */
  private void validateRulesForControlRecommendation(
      ReceiveRiskAnalysisResult receiveRiskAnalysisResult,
      Set<ConstraintViolation<ReceiveRiskAnalysisResult>> allViolations,
      TemporaryStorageDeclaration declaration) {

    List<ControlRecommendation> controlRecommendations =
        receiveRiskAnalysisResult.getControlRecommendations();
    if (CollectionUtils.isEmpty(controlRecommendations)) {
      return;
    }

    validateR0422(controlRecommendations, declaration, allViolations);
    validateR0423(controlRecommendations, declaration, allViolations);
    validateR0432(controlRecommendations, declaration, allViolations);
    validateR0433(controlRecommendations, declaration, allViolations);
    validateR0434(controlRecommendations, declaration, allViolations);
  }

  /**
   * this method is validating if the master consignment items with goods item number of the request
   * is found the the declaration's master consignment items. If it is not found this method also
   * triggers for validation of R0435.
   *
   * @param controlRecommendations
   * @param declaration
   * @param allViolations
   */
  private void validateR0434(
      List<ControlRecommendation> controlRecommendations,
      TemporaryStorageDeclaration declaration,
      Set<ConstraintViolation<ReceiveRiskAnalysisResult>> allViolations) {

    for (ControlRecommendation cr : controlRecommendations) {

      MasterConsignment reqMasterConsignment = findMasterConsignment(cr.getConsignments());
      if (reqMasterConsignment == null
          || CollectionUtils.isEmpty(reqMasterConsignment.getConsignmentItem())) {
        continue;
      }

      for (ConsignmentItem requestMasterConsItem : reqMasterConsignment.getConsignmentItem()) {

        Optional<ConsignmentItem> tsdMasterConsItem =
            findDeclarationConsignmentItem(
                declaration.getMasterConsignment(), requestMasterConsItem.getGoodsItemNumber());

        if (tsdMasterConsItem.isEmpty()) {
          CustomViolation<ReceiveRiskAnalysisResult> violation =
              new CustomViolation<>(
                  ErrorCode.TSPNESXXR0434,
                  CONTROL_RECOMMENDATION
                      + CONTROL_SUBJECT
                      + MASTER_CONSIGNMENT
                      + GOODSITEM
                      + GOODSITEM_NUMBER);
          allViolations.add(violation);
        }

        if (tsdMasterConsItem.isPresent()) {
          validateR0435(requestMasterConsItem, tsdMasterConsItem, allViolations);
        }
      }
    }
  }

  /**
   * helper method to filter the consignment item based on goods item number
   *
   * @param consignment
   * @param goodsItemNumber
   * @return
   */
  private Optional<ConsignmentItem> findDeclarationConsignmentItem(
      Consignment consignment, Integer goodsItemNumber) {

    Optional<ConsignmentItem> tsdConsItem = Optional.empty();
    if (consignment == null || CollectionUtils.isEmpty(consignment.getConsignmentItem())) {
      return tsdConsItem;
    }

    return consignment.getConsignmentItem().stream()
        .filter(ci -> goodsItemNumber.equals(ci.getGoodsItemNumber()))
        .findAny();
  }

  /**
   * this method is validating if the master consignment items transport equipments/containerIdNums
   * of the request is found in the declaration's master consignment items/transportEquipments.
   *
   * @param requestMasterConsItem
   * @param tsdMasterConsItem
   * @param allViolations
   */
  private void validateR0435(
      ConsignmentItem requestMasterConsItem,
      Optional<ConsignmentItem> tsdMasterConsItem,
      Set<ConstraintViolation<ReceiveRiskAnalysisResult>> allViolations) {

    List<String> requestMasterItemTransportEquipNums = null;
    if (CollectionUtils.isNotEmpty(requestMasterConsItem.getTransportEquipment())) {
      requestMasterItemTransportEquipNums =
          requestMasterConsItem.getTransportEquipment().stream()
              .map(TransportEquipment::getContainerIdentificationNumber)
              .toList();
    }

    List<String> tsdMasterItemTransportEquipNums = null;
    if (tsdMasterConsItem.isPresent()
        && CollectionUtils.isNotEmpty(tsdMasterConsItem.get().getTransportEquipment())) {
      tsdMasterItemTransportEquipNums =
          tsdMasterConsItem.get().getTransportEquipment().stream()
              .map(TransportEquipment::getContainerIdentificationNumber)
              .toList();
    }

    if ((requestMasterItemTransportEquipNums != null && tsdMasterItemTransportEquipNums == null)
        || (tsdMasterItemTransportEquipNums != null
            && requestMasterItemTransportEquipNums != null
            && !tsdMasterItemTransportEquipNums.containsAll(requestMasterItemTransportEquipNums))) {
      CustomViolation<ReceiveRiskAnalysisResult> violation =
          new CustomViolation<>(
              ErrorCode.TSPNESXXR0435,
              CONTROL_RECOMMENDATION
                  + CONTROL_SUBJECT
                  + MASTER_CONSIGNMENT
                  + GOODSITEM
                  + TRANSPORT_EQUIPMENT
                  + CONTAINER_INDENTIFICATION_NUMBER);
      allViolations.add(violation);
    }
  }

  /**
   * this method is validating if the master consignment receptacles/idenNums of the request is
   * found in the declaration's master consignment items/receptacles.
   *
   * @param controlRecommendations
   * @param declaration
   * @param allViolations
   */
  private void validateR0433(
      List<ControlRecommendation> controlRecommendations,
      TemporaryStorageDeclaration declaration,
      Set<ConstraintViolation<ReceiveRiskAnalysisResult>> allViolations) {
    List<String> tsdReceptacleIdNums = null;
    if (declaration.getMasterConsignment() != null
        && CollectionUtils.isNotEmpty(declaration.getMasterConsignment().getReceptacle())) {

      tsdReceptacleIdNums =
          declaration.getMasterConsignment().getReceptacle().stream()
              .map(Receptacle::getIdentificationNumber)
              .toList();
    }

    for (ControlRecommendation cr : controlRecommendations) {
      MasterConsignment reqMasterConsignment = findMasterConsignment(cr.getConsignments());

      if (reqMasterConsignment != null
          && CollectionUtils.isNotEmpty(reqMasterConsignment.getReceptacle())) {
        List<String> requestReceptacleIdNums =
            reqMasterConsignment.getReceptacle().stream()
                .map(Receptacle::getIdentificationNumber)
                .toList();

        if (CollectionUtils.isEmpty(tsdReceptacleIdNums)
            || !tsdReceptacleIdNums.containsAll(requestReceptacleIdNums)) {
          CustomViolation<ReceiveRiskAnalysisResult> violation =
              new CustomViolation<>(
                  ErrorCode.TSPNESXXR0433,
                  CONTROL_RECOMMENDATION
                      + CONTROL_SUBJECT
                      + MASTER_CONSIGNMENT
                      + RECEPTACLE
                      + INDENTIFICATION_NUMBER);
          allViolations.add(violation);
        }
      }
    }
  }

  /**
   * this method is validating if the master consignment/transport equipments/containerIdNums of the
   * request is found in the declaration's master consignment/transportEquipments.
   *
   * @param controlRecommendations
   * @param declaration
   * @param allViolations
   */
  private void validateR0432(
      List<ControlRecommendation> controlRecommendations,
      TemporaryStorageDeclaration declaration,
      Set<ConstraintViolation<ReceiveRiskAnalysisResult>> allViolations) {

    List<String> tsdContainorIdNums = null;
    if (declaration.getMasterConsignment() != null
        && CollectionUtils.isNotEmpty(declaration.getMasterConsignment().getTransportEquipment())) {
      tsdContainorIdNums =
          declaration.getMasterConsignment().getTransportEquipment().stream()
              .map(TransportEquipment::getContainerIdentificationNumber)
              .toList();
    }

    for (ControlRecommendation cr : controlRecommendations) {
      MasterConsignment reqMasterConsignment = findMasterConsignment(cr.getConsignments());

      if (reqMasterConsignment != null
          && CollectionUtils.isNotEmpty(reqMasterConsignment.getTransportEquipment())) {
        List<String> requestContainorIdNums =
            reqMasterConsignment.getTransportEquipment().stream()
                .map(TransportEquipment::getContainerIdentificationNumber)
                .toList();

        if (CollectionUtils.isEmpty(tsdContainorIdNums)
            || !tsdContainorIdNums.containsAll(requestContainorIdNums)) {
          CustomViolation<ReceiveRiskAnalysisResult> violation =
              new CustomViolation<>(
                  ErrorCode.TSPNESXXR0432,
                  CONTROL_RECOMMENDATION
                      + CONTROL_SUBJECT
                      + MASTER_CONSIGNMENT
                      + TRANSPORT_EQUIPMENT
                      + CONTAINER_INDENTIFICATION_NUMBER);
          allViolations.add(violation);
        }
      }
    }
  }

  /**
   * this method is validating if the master consignment transport document of the request matches
   * the declaration's master consignment / transport document.
   *
   * @param controlRecommendations
   * @param declaration
   * @param allViolations
   */
  private void validateR0422(
      List<ControlRecommendation> controlRecommendations,
      TemporaryStorageDeclaration declaration,
      Set<ConstraintViolation<ReceiveRiskAnalysisResult>> allViolations) {

    TransportDocument decTransportDoc = null;
    if (declaration.getMasterConsignment() != null
        && declaration.getMasterConsignment().getTransportDocument() != null) {
      decTransportDoc = declaration.getMasterConsignment().getTransportDocument();
    }

    for (ControlRecommendation cr : controlRecommendations) {
      MasterConsignment reqMasterConsignment = findMasterConsignment(cr.getConsignments());

      if ((decTransportDoc == null
              && reqMasterConsignment != null
              && reqMasterConsignment.getTransportDocument() != null)
          || (decTransportDoc != null
              && reqMasterConsignment != null
              && reqMasterConsignment.getTransportDocument() != null
              && !Objects.equals(reqMasterConsignment.getTransportDocument(), decTransportDoc))) {
        CustomViolation<ReceiveRiskAnalysisResult> violation =
            new CustomViolation<>(
                ErrorCode.TSPNESXXR0422,
                CONTROL_RECOMMENDATION + CONTROL_SUBJECT + MASTER_CONSIGNMENT);
        allViolations.add(violation);
      }
    }
  }

  /**
   * this method is validating if the house consignments/ transport document of the request matches
   * the declaration's house consignments / transport document. This method also triggers validation
   * R0436
   *
   * @param controlRecommendations
   * @param declaration
   * @param allViolations
   */
  private void validateR0423(
      List<ControlRecommendation> controlRecommendations,
      TemporaryStorageDeclaration declaration,
      Set<ConstraintViolation<ReceiveRiskAnalysisResult>> allViolations) {

    List<HouseConsignment> tsdHouseConsignments = null;
    if (CollectionUtils.isNotEmpty(declaration.getHouseConsignments())) {
      tsdHouseConsignments = declaration.getHouseConsignments();
    }

    for (ControlRecommendation cr : controlRecommendations) {
      if (cr.getConsignments().size() == 1) { // it means cr only has a master consignment
        continue;
      }

      boolean is23Violated = false;
      for (Consignment requestConsignment : cr.getConsignments()) {
        if (requestConsignment instanceof HouseConsignment) {

          Optional<HouseConsignment> tsdHouseCons = Optional.empty();
          if (tsdHouseConsignments != null) {
            tsdHouseCons =
                tsdHouseConsignments.stream()
                    .filter(
                        tsdCons ->
                            requestConsignment
                                .getSequenceNumber()
                                .equals(tsdCons.getSequenceNumber()))
                    .findAny();
          }

          is23Violated =
              addViolationR0423(allViolations, is23Violated, requestConsignment, tsdHouseCons);

          validateR0436(is23Violated, requestConsignment, tsdHouseCons, allViolations);
        }
        is23Violated = false;
      }
    }
  }

  /**
   * helper method to throw the violation
   *
   * @param allViolations
   * @param is23Violated
   * @param requestConsignment
   * @param tsdHouseCons
   * @return is23Violated
   */
  private boolean addViolationR0423(
      Set<ConstraintViolation<ReceiveRiskAnalysisResult>> allViolations,
      boolean is23Violated,
      Consignment requestConsignment,
      Optional<HouseConsignment> tsdHouseCons) {
    if ((tsdHouseCons.isEmpty() && requestConsignment.getTransportDocument() != null)
        || (tsdHouseCons.isPresent()
            && !Objects.equals(
                requestConsignment.getTransportDocument(),
                tsdHouseCons.get().getTransportDocument()))) {
      CustomViolation<ReceiveRiskAnalysisResult> violation =
          new CustomViolation<>(
              ErrorCode.TSPNESXXR0423,
              CONTROL_RECOMMENDATION + CONTROL_SUBJECT + MASTER_CONSIGNMENT);
      allViolations.add(violation);
      is23Violated = true;
    }
    return is23Violated;
  }

  /**
   * this method is validating if the house consignments/transport equipments of the request matches
   * the declaration's house consignments/ transport equipments.
   *
   * @param isRule23Violated
   * @param requestHouseConsignment
   * @param tsdHouseCons
   * @param tsdMasterCons
   * @param allViolations
   */
  private void validateR0436(
      boolean isRule23Violated,
      Consignment requestHouseConsignment,
      Optional<HouseConsignment> tsdHouseCons,
      Set<ConstraintViolation<ReceiveRiskAnalysisResult>> allViolations) {

    if (!isRule23Violated
        && (tsdHouseCons.isEmpty()
            || CollectionUtils.isEmpty(tsdHouseCons.get().getTransportEquipment()))
        && CollectionUtils.isNotEmpty(requestHouseConsignment.getTransportEquipment())) {
      CustomViolation<ReceiveRiskAnalysisResult> violation =
          new CustomViolation<>(
              ErrorCode.TSPNESXXR0436,
              CONTROL_RECOMMENDATION
                  + CONTROL_SUBJECT
                  + MASTER_CONSIGNMENT
                  + HOUSE_CONSIGNMENT
                  + TRANSPORT_EQUIPMENT
                  + CONTAINER_INDENTIFICATION_NUMBER);
      allViolations.add(violation);
    } else if (!isRule23Violated
        && tsdHouseCons.isPresent()
        && CollectionUtils.isNotEmpty(tsdHouseCons.get().getTransportEquipment())
        && CollectionUtils.isNotEmpty(requestHouseConsignment.getTransportEquipment())) {
      List<String> tsdHouseContainorIdNums =
          tsdHouseCons.get().getTransportEquipment().stream()
              .map(TransportEquipment::getContainerIdentificationNumber)
              .toList();
      List<String> requestHouseContainorIdNums =
          requestHouseConsignment.getTransportEquipment().stream()
              .map(TransportEquipment::getContainerIdentificationNumber)
              .toList();
      if (!tsdHouseContainorIdNums.containsAll(requestHouseContainorIdNums)) {
        CustomViolation<ReceiveRiskAnalysisResult> violation =
            new CustomViolation<>(
                ErrorCode.TSPNESXXR0436,
                CONTROL_RECOMMENDATION
                    + CONTROL_SUBJECT
                    + MASTER_CONSIGNMENT
                    + HOUSE_CONSIGNMENT
                    + TRANSPORT_EQUIPMENT
                    + CONTAINER_INDENTIFICATION_NUMBER);
        allViolations.add(violation);
      }
    }

    validateR0437(isRule23Violated, requestHouseConsignment, tsdHouseCons, allViolations);
  }

  /**
   * this method is validating if the house consignments/consignment items/goodsItemNumber of the
   * request matches the declaration's master consignment/consignment items/goodsItemNumber.
   *
   * @param isRule23Violated
   * @param requestHouseConsignment
   * @param tsdHouseCons
   * @param tsdMasterCons
   * @param allViolations
   */
  private void validateR0437(
      boolean isRule23Violated,
      Consignment requestHouseConsignment,
      Optional<HouseConsignment> optionalTSDHouseConsignment,
      Set<ConstraintViolation<ReceiveRiskAnalysisResult>> allViolations) {

    if (!isRule23Violated
        && optionalTSDHouseConsignment.isPresent()
        && CollectionUtils.isNotEmpty(requestHouseConsignment.getConsignmentItem())) {

      for (ConsignmentItem requestHouseConsignmentItem :
          requestHouseConsignment.getConsignmentItem()) {

        Optional<ConsignmentItem> optionalTSDConsignmentItem =
            findDeclarationConsignmentItem(
                optionalTSDHouseConsignment.get(),
                requestHouseConsignmentItem.getGoodsItemNumber());

        if (optionalTSDConsignmentItem.isEmpty()) {
          CustomViolation<ReceiveRiskAnalysisResult> violation =
              new CustomViolation<>(
                  ErrorCode.TSPNESXXR0437,
                  CONTROL_RECOMMENDATION
                      + CONTROL_SUBJECT
                      + MASTER_CONSIGNMENT
                      + HOUSE_CONSIGNMENT
                      + GOODSITEM
                      + GOODSITEM_NUMBER);
          allViolations.add(violation);
        } else {
          validateR0438(
              requestHouseConsignmentItem, optionalTSDConsignmentItem.get(), allViolations);
        }
      }
    }
  }

  /**
   * this method is validating if the house consignments/consignmentitems/transport equipments of
   * the request matches the declaration's house consignments/ consignmentitems/ transport
   * equipments.
   *
   * @param requestHouseConsignmentItem
   * @param optionalTSDConsignmentItem
   * @param allViolations
   */
  private void validateR0438(
      ConsignmentItem requestHouseConsignmentItem,
      ConsignmentItem tsdHouseConsignmentItem,
      Set<ConstraintViolation<ReceiveRiskAnalysisResult>> allViolations) {

    List<String> requestHouseItemTransportEquipNums = null;
    if (requestHouseConsignmentItem != null
        && CollectionUtils.isNotEmpty(requestHouseConsignmentItem.getTransportEquipment())) {
      requestHouseItemTransportEquipNums =
          requestHouseConsignmentItem.getTransportEquipment().stream()
              .map(TransportEquipment::getContainerIdentificationNumber)
              .toList();
    }

    List<String> tsdHouseItemTransportEquipNums = null;
    if (tsdHouseConsignmentItem != null
        && CollectionUtils.isNotEmpty(tsdHouseConsignmentItem.getTransportEquipment())) {
      tsdHouseItemTransportEquipNums =
          tsdHouseConsignmentItem.getTransportEquipment().stream()
              .map(TransportEquipment::getContainerIdentificationNumber)
              .toList();
    }

    if ((requestHouseItemTransportEquipNums != null && tsdHouseItemTransportEquipNums == null)
        || (tsdHouseItemTransportEquipNums != null
            && requestHouseItemTransportEquipNums != null
            && !tsdHouseItemTransportEquipNums.containsAll(requestHouseItemTransportEquipNums))) {
      CustomViolation<ReceiveRiskAnalysisResult> violation =
          new CustomViolation<>(
              ErrorCode.TSPNESXXR0438,
              CONTROL_RECOMMENDATION
                  + CONTROL_SUBJECT
                  + MASTER_CONSIGNMENT
                  + HOUSE_CONSIGNMENT
                  + GOODSITEM
                  + TRANSPORT_EQUIPMENT
                  + CONTAINER_INDENTIFICATION_NUMBER);
      allViolations.add(violation);
    }
  }

  /**
   * helper method to return the master cosignment from the list of consignments
   *
   * @param consignments
   * @return
   */
  private MasterConsignment findMasterConsignment(List<Consignment> consignments) {
    Optional<Consignment> masterConsignment =
        consignments.stream().filter(MasterConsignment.class::isInstance).findAny();
    if (masterConsignment.isPresent()) {
      return (MasterConsignment) masterConsignment.get();
    } else {
      return null;
    }
  }
}
