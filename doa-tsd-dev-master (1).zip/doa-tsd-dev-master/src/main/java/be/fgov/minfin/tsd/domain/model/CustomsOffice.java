/*
 * @(#)be.fgov.minfin.tsd.domain.model.CustomsOffice.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model;

import be.fgov.minfin.tsd.domain.validation.annotation.group.NonDraftTSD;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
@Builder // builder pattern
@NoArgsConstructor // needed for JPA in combination with @builder
@AllArgsConstructor
@EqualsAndHashCode // do not exclude any field
@Embeddable
public class CustomsOffice {
  @NotNull(groups = NonDraftTSD.class)
  private String referenceNumber;
}
