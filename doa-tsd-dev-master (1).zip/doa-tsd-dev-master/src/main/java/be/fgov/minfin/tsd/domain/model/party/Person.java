/*
 * @(#) be.fgov.minfin.tsd.domain.model.party.Person
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model.party;

import be.fgov.minfin.tsd.domain.validation.annotation.CodeList;
import be.fgov.minfin.tsd.domain.validation.annotation.group.DeconsolidationNotificationValidatorGroup;
import be.fgov.minfin.tsd.domain.validation.annotation.group.NonDraftTSD;
import be.fgov.minfin.tsd.domain.validation.codelist.TSDCodeLists;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.validation.constraints.NotNull;
import javax.validation.groups.Default;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
@Entity
@DiscriminatorValue("Person")
public class Person extends Party {

  @Builder(builderMethodName = "personBuilder")
  private Person(
      Long id,
      List<Communication> communication,
      String name,
      String identificationNumber,
      String typeOfPerson,
      PartyAddress address) {
    super(id, communication, name, identificationNumber, address);
    this.typeOfPerson = typeOfPerson;
  }

  @CodeList(
      value = TSDCodeLists.CL729,
      groups = {Default.class, DeconsolidationNotificationValidatorGroup.class})
  @Column(columnDefinition = "INTEGER")
  @NotNull(groups = NonDraftTSD.class)
  private String typeOfPerson;
}
