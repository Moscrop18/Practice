/*
 * @(#) be.fgov.minfin.tsd.gateway.eo.EONotificationGateway.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.eo;

import static be.fgov.minfin.tsd.constant.MessageNameConstant.ACCEPT_MESSAGE;
import static be.fgov.minfin.tsd.constant.MessageNameConstant.ACTIVATION_NOTIFICATION;
import static be.fgov.minfin.tsd.constant.MessageNameConstant.INVALIDATION_NOTIFICATION;
import static be.fgov.minfin.tsd.constant.MessageNameConstant.REFUSAL_MESSAGE;
import static be.fgov.minfin.tsd.constant.MessageNameConstant.SEND_INTENDED_CONTROL_NOTIFICATION;

import be.fgov.minfin.eogw.client.api.EONotificationRequestDTO;
import be.fgov.minfin.eogw.client.api.MessageHeaderNotificationDTO;
import be.fgov.minfin.libdoa.amqp.transactional.QueueSender;
import be.fgov.minfin.shared.tracing.Traced;
import be.fgov.minfin.tsd.domain.message.SendIntendedControlNotification;
import be.fgov.minfin.tsd.domain.message.TSDAcceptMessage;
import be.fgov.minfin.tsd.domain.message.TSDActivationNotification;
import be.fgov.minfin.tsd.domain.message.TSDAmendmentRejectMessage;
import be.fgov.minfin.tsd.domain.message.TSDDeconsolidationNotificationAcceptMessage;
import be.fgov.minfin.tsd.domain.message.TSDDeconsolidationNotificationRefusedMessage;
import be.fgov.minfin.tsd.domain.message.TSDInvalidationNotification;
import be.fgov.minfin.tsd.domain.message.TSDInvalidationRefusedMessage;
import be.fgov.minfin.tsd.domain.message.TSDRejectMessage;
import be.fgov.minfin.tsd.domain.message.TSDTransferNotificationAcceptMessage;
import be.fgov.minfin.tsd.domain.message.TSDTransferNotificationRefusedMessage;
import be.fgov.minfin.tsd.domain.model.BusinessValidationType;
import be.fgov.minfin.tsd.domain.model.MessageExchange;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.repository.MessageExchangeRepository;
import be.fgov.minfin.tsd.gateway.eo.api.AcceptMessageDTO;
import be.fgov.minfin.tsd.gateway.eo.api.ActivationNotificationDTO;
import be.fgov.minfin.tsd.gateway.eo.api.EONotificationEvent;
import be.fgov.minfin.tsd.gateway.eo.api.InvalidationNotificationDTO;
import be.fgov.minfin.tsd.gateway.eo.api.MessageHeaderDTO;
import be.fgov.minfin.tsd.gateway.eo.api.RejectMessageDTO;
import be.fgov.minfin.tsd.gateway.eo.api.SendIntendedControlDTO;
import be.fgov.minfin.tsd.gateway.eo.message.converter.MessageConverter;
import be.fgov.minfin.tsd.gateway.eo.message.mapper.MessageMapper;
import be.fgov.minfin.tsd.util.DateUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * This class handles eo notification send accept and reject message to queue which will further
 * call rest eo service
 *
 * @author GauravMitra
 */
@Component
@RequiredArgsConstructor
public class EONotificationGateway {

  public static final String ACCEPT_MESSAGE_VERSION = "IETS028.1.0";
  public static final String ACCEPT_INTENDED_CONTROL_MESSAGE_VERSION = "IETS460.1.0";
  public static final String REJECT_MESSAGE_VERSION = "IETS016.1.0";
  public static final String ACTIVATION_NOTIFICATION_VERSION = "IETS029.1.0";
  public static final String INVALIDATION_NOTIFICATION_VERSION = "IETS410.1.0";

  private final QueueSender eoNotificationEventSender;

  private final MessageMapper messageMapper;
  private final MessageConverter converter;
  private final DateUtil dateUtil;
  private final EoNotificationGatewayConfig eoNotificationGatewayConfig;

  private final MessageExchangeRepository messageExchangeRepository;

  @Traced
  public void sendMessage(TSDAcceptMessage message) {
    AcceptMessageDTO messageDTO = messageMapper.map(message);
    saveMessageExchange(
        messageDTO.getMessageHeader(),
        ACCEPT_MESSAGE,
        message.getDeclaration(),
        messageDTO.getBusinessValidationType());
    String xml = converter.toXML(messageDTO);
    EONotificationRequestDTO notification =
        buildNotification(xml, messageDTO.getMessageHeader(), ACCEPT_MESSAGE_VERSION);

    EONotificationEvent eoNotificationEvent =
        EONotificationEvent.builder()
            .eoNotificationDTO(notification)
            .businessDecisionTime(dateUtil.getCurentSystemDate())
            .messageType(ACCEPT_MESSAGE)
            .build();
    sendNotification(eoNotificationEvent);
  }

  public void sendMessage(TSDRejectMessage message) {
    RejectMessageDTO messageDTO = messageMapper.map(message);
    String xml = converter.toXML(messageDTO);
    EONotificationRequestDTO notification =
        buildNotification(xml, messageDTO.getMessageHeader(), REJECT_MESSAGE_VERSION);

    EONotificationEvent eoNotificationEvent =
        EONotificationEvent.builder()
            .eoNotificationDTO(notification)
            .businessDecisionTime(dateUtil.getCurentSystemDate())
            .messageType(REFUSAL_MESSAGE)
            .build();
    sendNotification(eoNotificationEvent);
  }

  public void sendMessage(TSDActivationNotification tsdActivationNotification) {
    ActivationNotificationDTO notificationDTO = messageMapper.map(tsdActivationNotification);
    saveMessageExchange(
        notificationDTO.getMessageHeader(),
        ACTIVATION_NOTIFICATION,
        tsdActivationNotification.getDeclaration(),
        null);
    String xml = converter.toXML(notificationDTO);
    EONotificationRequestDTO notification =
        buildNotification(xml, notificationDTO.getMessageHeader(), ACTIVATION_NOTIFICATION_VERSION);
    EONotificationEvent eoNotificationEvent =
        EONotificationEvent.builder()
            .eoNotificationDTO(notification)
            .businessDecisionTime(dateUtil.getCurentSystemDate())
            .messageType(ACTIVATION_NOTIFICATION)
            .build();
    sendNotification(eoNotificationEvent);
  }

  private void saveMessageExchange(
      MessageHeaderDTO messageHeader,
      String type,
      TemporaryStorageDeclaration declaration,
      BusinessValidationType businessValidationType) {
    MessageExchange messageExchange =
        MessageExchange.builder()
            .messageId(messageHeader.getMessageId())
            .messageTimestamp(dateUtil.getCurentSystemDate())
            .messageType(type)
            .businessValidationType(businessValidationType)
            .declaration(declaration)
            .build();
    messageExchangeRepository.save(messageExchange);
  }

  private EONotificationRequestDTO buildNotification(
      String xml, MessageHeaderDTO header, String type) {
    MessageHeaderNotificationDTO headerDTO =
        MessageHeaderNotificationDTO.builder()
            .correlationId(header.getCorrelationId())
            .destination(header.getRecipient())
            .sender("TSD")
            .messageType(type)
            .messageId(header.getMessageId())
            .build();
    return EONotificationRequestDTO.builder().messageContent(xml).messageHeader(headerDTO).build();
  }

  private void sendNotification(EONotificationEvent eoNotificationEvent) {
    eoNotificationEventSender.publishMessage(
        eoNotificationGatewayConfig.getEoNotificationQueue(), eoNotificationEvent);
  }

  /**
   * sends the invalidation refused message, and also saves the message exchange if errorR0104Found
   * is not true
   *
   * @param message
   * @param errorR0104Found
   */
  public void sendMessage(TSDInvalidationRefusedMessage message, boolean tsdPresent) {
    RejectMessageDTO messageDTO = messageMapper.map(message);
    if (tsdPresent) {
      saveMessageExchange(
          messageDTO.getMessageHeader(),
          REFUSAL_MESSAGE,
          message.getDeclaration(),
          messageDTO.getBusinessValidationType());
    }
    String xml = converter.toXML(messageDTO);
    EONotificationRequestDTO notification =
        buildNotification(xml, messageDTO.getMessageHeader(), REJECT_MESSAGE_VERSION);

    EONotificationEvent eoNotificationEvent =
        EONotificationEvent.builder()
            .eoNotificationDTO(notification)
            .businessDecisionTime(dateUtil.getCurentSystemDate())
            .messageType(REFUSAL_MESSAGE)
            .build();
    sendNotification(eoNotificationEvent);
  }

  /**
   * sends the invalidation notification, and also saves the corresponding message exchange
   *
   * @param tsdInvalidationNotification
   */
  public void sendMessage(TSDInvalidationNotification tsdInvalidationNotification) {
    InvalidationNotificationDTO notificationDTO = messageMapper.map(tsdInvalidationNotification);
    saveMessageExchange(
        notificationDTO.getMessageHeader(),
        INVALIDATION_NOTIFICATION,
        tsdInvalidationNotification.getDeclaration(),
        null);
    String xml = converter.toXML(notificationDTO);
    EONotificationRequestDTO notification =
        buildNotification(
            xml, notificationDTO.getMessageHeader(), INVALIDATION_NOTIFICATION_VERSION);
    EONotificationEvent eoNotificationEvent =
        EONotificationEvent.builder()
            .eoNotificationDTO(notification)
            .businessDecisionTime(dateUtil.getCurentSystemDate())
            .messageType(INVALIDATION_NOTIFICATION)
            .build();
    sendNotification(eoNotificationEvent);
  }

  public void sendMessage(SendIntendedControlNotification sendIntendedControlNotification) {
    SendIntendedControlDTO messageDTO =
        messageMapper.intendedControlmap(sendIntendedControlNotification);
    saveMessageExchange(
        messageDTO.getMessageHeader(),
        SEND_INTENDED_CONTROL_NOTIFICATION,
        sendIntendedControlNotification.getDeclaration(),
        null);
    String xml = converter.toXML(messageDTO);
    EONotificationRequestDTO notification =
        buildNotification(
            xml, messageDTO.getMessageHeader(), ACCEPT_INTENDED_CONTROL_MESSAGE_VERSION);

    EONotificationEvent eoNotificationEvent =
        EONotificationEvent.builder()
            .eoNotificationDTO(notification)
            .businessDecisionTime(dateUtil.getCurentSystemDate())
            .messageType(ACCEPT_MESSAGE)
            .build();
    sendNotification(eoNotificationEvent);
  }

  public void sendMessage(
      TSDTransferNotificationAcceptMessage tsdTransferNotificationAcceptMessage) {

    AcceptMessageDTO acceptMessageDTO = messageMapper.map(tsdTransferNotificationAcceptMessage);

    if (null != tsdTransferNotificationAcceptMessage.getDeclaration()) {
      saveMessageExchange(
          acceptMessageDTO.getMessageHeader(),
          ACCEPT_MESSAGE,
          tsdTransferNotificationAcceptMessage.getDeclaration(),
          acceptMessageDTO.getBusinessValidationType());
    }

    String xml = converter.toXML(acceptMessageDTO);
    EONotificationRequestDTO eoNotificationRequestDTO =
        buildNotification(xml, acceptMessageDTO.getMessageHeader(), ACCEPT_MESSAGE_VERSION);

    EONotificationEvent eoNotificationEvent =
        EONotificationEvent.builder()
            .eoNotificationDTO(eoNotificationRequestDTO)
            .businessDecisionTime(dateUtil.getCurentSystemDate())
            .messageType(ACCEPT_MESSAGE)
            .build();
    sendNotification(eoNotificationEvent);
  }

  public void sendMessage(
      TSDTransferNotificationRefusedMessage tsdTransferNotificationRefusedMessage) {

    RejectMessageDTO rejectMessageDTO = messageMapper.map(tsdTransferNotificationRefusedMessage);

    if (null != tsdTransferNotificationRefusedMessage.getDeclaration()) {
      saveMessageExchange(
          rejectMessageDTO.getMessageHeader(),
          REFUSAL_MESSAGE,
          tsdTransferNotificationRefusedMessage.getDeclaration(),
          rejectMessageDTO.getBusinessValidationType());
    }

    String xml = converter.toXML(rejectMessageDTO);
    EONotificationRequestDTO eoNotificationRequestDTO =
        buildNotification(xml, rejectMessageDTO.getMessageHeader(), REJECT_MESSAGE_VERSION);

    EONotificationEvent eoNotificationEvent =
        EONotificationEvent.builder()
            .eoNotificationDTO(eoNotificationRequestDTO)
            .businessDecisionTime(dateUtil.getCurentSystemDate())
            .messageType(REFUSAL_MESSAGE)
            .build();
    sendNotification(eoNotificationEvent);
  }

  public void sendMessage(TSDDeconsolidationNotificationRefusedMessage refusedMessage) {
    RejectMessageDTO rejectMessageDTO = messageMapper.map(refusedMessage);

    if (null != refusedMessage.getDeclaration()) {
      saveMessageExchange(
          rejectMessageDTO.getMessageHeader(),
          REFUSAL_MESSAGE,
          refusedMessage.getDeclaration(),
          rejectMessageDTO.getBusinessValidationType());
    }
    String xml = converter.toXML(rejectMessageDTO);
    EONotificationRequestDTO eoNotificationRequestDTO =
        buildNotification(xml, rejectMessageDTO.getMessageHeader(), REJECT_MESSAGE_VERSION);

    EONotificationEvent eoNotificationEvent =
        EONotificationEvent.builder()
            .eoNotificationDTO(eoNotificationRequestDTO)
            .businessDecisionTime(dateUtil.getCurentSystemDate())
            .messageType(REFUSAL_MESSAGE)
            .build();
    sendNotification(eoNotificationEvent);
  }

  public void sendMessage(
      TSDDeconsolidationNotificationAcceptMessage tsdDeconsolidationNotificationAcceptMessage) {

    AcceptMessageDTO acceptMessageDTO =
        messageMapper.map(tsdDeconsolidationNotificationAcceptMessage);

    if (null != tsdDeconsolidationNotificationAcceptMessage.getDeclaration()) {
      saveMessageExchange(
          acceptMessageDTO.getMessageHeader(),
          ACCEPT_MESSAGE,
          tsdDeconsolidationNotificationAcceptMessage.getDeclaration(),
          acceptMessageDTO.getBusinessValidationType());
    }
    String xml = converter.toXML(acceptMessageDTO);
    EONotificationRequestDTO eoNotificationRequestDTO =
        buildNotification(xml, acceptMessageDTO.getMessageHeader(), ACCEPT_MESSAGE_VERSION);

    EONotificationEvent eoNotificationEvent =
        EONotificationEvent.builder()
            .eoNotificationDTO(eoNotificationRequestDTO)
            .businessDecisionTime(dateUtil.getCurentSystemDate())
            .messageType(ACCEPT_MESSAGE)
            .build();
    sendNotification(eoNotificationEvent);
  }

  public void sendMessage(TSDAmendmentRejectMessage message, boolean registerMessageExchange) {
    RejectMessageDTO messageDTO = messageMapper.map(message);
    String xml = converter.toXML(messageDTO);
    EONotificationRequestDTO notification =
        buildNotification(xml, messageDTO.getMessageHeader(), REJECT_MESSAGE_VERSION);
    if (registerMessageExchange) {
      saveMessageExchange(
          messageDTO.getMessageHeader(),
          REFUSAL_MESSAGE,
          message.getCurrentDeclaraton() != null
              ? message.getCurrentDeclaraton()
              : message.getAmendedDeclaration(),
          null);
    }

    EONotificationEvent eoNotificationEvent =
        EONotificationEvent.builder()
            .eoNotificationDTO(notification)
            .businessDecisionTime(dateUtil.getCurentSystemDate())
            .messageType(REFUSAL_MESSAGE)
            .build();
    sendNotification(eoNotificationEvent);
  }
}
