/*
 * @(#) be.fgov.minfin.tsd.domain.model.TransferNotificationConsignment.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties
 * or made public without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model;

import be.fgov.minfin.tsd.domain.model.consignment.Consignment;
import be.fgov.minfin.tsd.domain.model.consignment.TransportDocument;
import be.fgov.minfin.tsd.domain.validation.annotation.NumberCompare;
import be.fgov.minfin.tsd.domain.validation.annotation.group.TransferNotificationValidatorGroup;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import be.fgov.minfin.tsd.util.NumberCompareType;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonSubTypes.Type;
import java.math.BigDecimal;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.groups.Default;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "CONSIGNMENT_TYPE")
@JsonSubTypes({
  @Type(
      value = TransferNotificationMasterConsignment.class,
      name = "transferNotificationMasterConsignment"),
  @Type(
      value = TransferNotificationHouseConsignment.class,
      name = "transferNotificationHouseConsignment")
})
@org.hibernate.annotations.DiscriminatorOptions(force = true)
@Entity
@Table(name = "TRANSFER_NOTIFICATION_CONSIGNMENT")
public class TransferNotificationConsignment {

  @Id
  @GeneratedValue(generator = "TRANSFER_NOTIFICATION_CONSIGNMENT_SEQ")
  @SequenceGenerator(
      name = "TRANSFER_NOTIFICATION_CONSIGNMENT_SEQ",
      sequenceName = "TRANSFER_NOTIFICATION_CONSIGNMENT_SEQ")
  private Long id;

  @NumberCompare(
      errorCode = ErrorCode.TSPNESXXR0054,
      value = 0,
      groups = {Default.class, TransferNotificationValidatorGroup.class},
      numberCompareType = NumberCompareType.GREATER_THAN)
  @Column(name = "TOTAL_GROSS_MASS")
  private BigDecimal totalGrossMass;

  @NumberCompare(
      numberCompareType = NumberCompareType.GREATER_THAN_OR_EQUAL_TO,
      value = 0,
      errorCode = ErrorCode.TSPNESXXR0141,
      groups = {Default.class, TransferNotificationValidatorGroup.class})
  @Column(name = "TOTAL_NUMBER_OF_PACKAGES")
  private Long totalNumberOfPackages;

  @Valid @Embedded private TransportDocument transportDocument;

  @ToString.Exclude
  @OneToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "CONSIGNMENT_ID")
  private Consignment consignment;

  @JsonIgnore
  public TransferNotification getTransferNotification() {
    throw new UnsupportedOperationException();
  }
}
