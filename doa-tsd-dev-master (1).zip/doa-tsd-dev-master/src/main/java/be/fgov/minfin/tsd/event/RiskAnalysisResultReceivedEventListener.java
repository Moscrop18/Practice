/*
 * @(#)be.fgov.minfin.tsd.event.RiskAnalysisResultReceivedEventListener.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.event;

import static be.fgov.minfin.tsd.event.TSDEventConfig.TSD_RISK_ANALYSIS_RESULT_RECEIVED_CONCURRENCY;
import static be.fgov.minfin.tsd.event.TSDEventConfig.TSD_RISK_ANALYSIS_RESULT_RECEIVED_QUEUE;

import be.fgov.minfin.libdoa.amqp.transactional.AbstractRetryingQueueListener;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.service.RiskAnalysisService;
import be.fgov.minfin.tsd.event.api.RiskAnalysisResultReceivedEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * event listener for RiskAnalysisResultReceivedEventListener
 *
 * @author AnuragSachan
 */
@Slf4j
@Component
@Transactional
public class RiskAnalysisResultReceivedEventListener extends AbstractRetryingQueueListener {

  public static final String LISTENER_ID = "processRiskAnalysisResultReceived";
  private RiskAnalysisService riskAnalysisService;

  public RiskAnalysisResultReceivedEventListener(
      TSDEventConfig cfg, RiskAnalysisService riskAnalysisService) {
    super(cfg.getTsdReceivedQueue());
    this.riskAnalysisService = riskAnalysisService;
  }

  @RabbitListener(
      id = LISTENER_ID,
      queues = TSD_RISK_ANALYSIS_RESULT_RECEIVED_QUEUE,
      concurrency = TSD_RISK_ANALYSIS_RESULT_RECEIVED_CONCURRENCY)
  public void processRiskAnalysisResultReceivedEvent(
      @Payload RiskAnalysisResultReceivedEvent event, Message message) {
    log.info(
        "RiskAnalysisResultReceivedEvent received in listener with functionalReference {}",
        event.getFunctionalReference());
    // TODO findDeclaration
    TemporaryStorageDeclaration tsd = null;
    riskAnalysisService.processRiskAnalysisResult(
        event.getFunctionalReference(), event.getMessageId(), event.getReceiveRiskAnalysisResult());
  }
}
