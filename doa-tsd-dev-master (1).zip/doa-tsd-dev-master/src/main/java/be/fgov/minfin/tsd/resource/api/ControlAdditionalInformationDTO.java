package be.fgov.minfin.tsd.resource.api;

import com.fasterxml.jackson.annotation.JsonRootName;
import javax.validation.constraints.Size;
import lombok.Builder;
import lombok.Value;

@Value
@Builder(toBuilder = true)
@JsonRootName("additionalInformation")
public class ControlAdditionalInformationDTO {

  @Size(min = 0, max = 512)
  private String text;
}
