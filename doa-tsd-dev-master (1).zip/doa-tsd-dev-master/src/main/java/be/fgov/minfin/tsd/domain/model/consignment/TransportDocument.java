/*
 * @(#) be.fgov.minfin.tsd.domain.model.consignment.TransportDocument
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model.consignment;

import be.fgov.minfin.tsd.domain.validation.annotation.CodeList;
import be.fgov.minfin.tsd.domain.validation.annotation.group.DeconsolidationNotificationValidatorGroup;
import be.fgov.minfin.tsd.domain.validation.annotation.group.NonDraftTSD;
import be.fgov.minfin.tsd.domain.validation.annotation.group.RiskResultValidator;
import be.fgov.minfin.tsd.domain.validation.annotation.group.TransferNotificationValidatorGroup;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import be.fgov.minfin.tsd.domain.validation.codelist.TSDCodeLists;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.groups.Default;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Embeddable
@EqualsAndHashCode // do not exclude any field
public class TransportDocument {
  @Column(name = "transport_document_ref_num")
  @NotNull(groups = NonDraftTSD.class)
  private String referenceNumber;

  @Column(name = "transport_document_type", columnDefinition = "char")
  @NotNull(groups = NonDraftTSD.class)
  @CodeList(
      value = TSDCodeLists.CL754,
      groups = {
        Default.class,
        TransferNotificationValidatorGroup.class,
        DeconsolidationNotificationValidatorGroup.class
      })
  @CodeList(
      value = TSDCodeLists.CL754,
      errorCode = ErrorCode.TSPNESXXC0416,
      groups = RiskResultValidator.class)
  private String type;
}
