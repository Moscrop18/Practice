/*
 * @(#)be.fgov.minfin.tsd.domain.service.ActivationService.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.service;

import static be.fgov.minfin.tsd.domain.model.TSDStatus.PRELODGED;
import static be.fgov.minfin.tsd.domain.model.TimerType.RISK_ANALYSIS_RESULT;
import static be.fgov.minfin.tsd.domain.model.TimerType.TSD_DRAFT_EXPIRATION;
import static be.fgov.minfin.tsd.domain.model.TimerType.TSD_EXPIRATION;

import be.fgov.minfin.libdoa.commons.lang.Now;
import be.fgov.minfin.shared.tracing.Traced;
import be.fgov.minfin.tsd.config.TSDConfig;
import be.fgov.minfin.tsd.domain.model.CRN;
import be.fgov.minfin.tsd.domain.model.MessageInformationSource;
import be.fgov.minfin.tsd.domain.model.TSDActivationRequest;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.TimerType;
import be.fgov.minfin.tsd.domain.model.risk.RiskAndControlStatus;
import be.fgov.minfin.tsd.domain.repository.TSDRepository;
import be.fgov.minfin.tsd.domain.sender.TSDResponseSender;
import be.fgov.minfin.tsd.domain.validation.ActivationValidator;
import be.fgov.minfin.tsd.domain.validation.CustomViolation;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import be.fgov.minfin.tsd.domain.validation.exception.TSDActivationException;
import be.fgov.minfin.tsd.event.TSDEventBroker;
import be.fgov.minfin.tsd.event.api.TSDActivationReceivedEvent;
import be.fgov.minfin.tsd.gateway.ga.GoodsAccountingGateway;
import be.fgov.minfin.tsd.gateway.pn.PNGateway;
import be.fgov.minfin.tsd.gateway.risk.RiskAnalysisGateway;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import javax.validation.ConstraintViolation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.context.annotation.DependsOn;
import org.springframework.stereotype.Service;

/**
 * This service layer for activation of prelodged TSd
 *
 * @author GauravMitra
 */
@Service
@RequiredArgsConstructor
@Slf4j
@DependsOn({"gatewayConfig"})
public class ActivationService {
  private final TSDEventBroker eventBroker;
  public static final String XX = "XX";
  private final ActivationValidator validator;
  private final PNGateway pnGateway;
  private final TSDRepository tsdRepository;
  private final TSDTimerService tsdTimerService;
  private final TSDResponseSender tsdResponseSender;
  private final TSDConfig tsdConfig;
  private final GoodsAccountingGateway gaGateway;
  private final RiskAnalysisGateway riskAnalysisGateway;

  /**
   * This method will send activation request event to Queue
   *
   * @param activateTSDRequest
   */
  @Traced
  public void receiveActivationRequest(final TSDActivationRequest activateTSDRequest) {
    TSDActivationReceivedEvent tSDActivationReceivedEvent =
        TSDActivationReceivedEvent.builder().activateTSDRequest(activateTSDRequest).build();
    eventBroker.publishActivateTSDEvent(tSDActivationReceivedEvent);
  }

  /**
   * This method is for activation of TSD
   *
   * @param activationRequest
   */
  @Traced
  public void doActivation(final TSDActivationRequest activationRequest) {
    log.debug("inside activate TSD request");
    TemporaryStorageDeclaration tsd = null;
    try {
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations = new HashSet<>();
      tsd = activateByConsignmentDetails(activationRequest);

      if (tsd != null) {
        tsd.addTSDActivationValues(activationRequest);
        tsd = tsdRepository.save(tsd);
        // Without Flushing mrn is not reflecting in entity so not going in notification
        tsdRepository.flush();
        tsd.maximumExpirationTimestamp();
        if (tsd.getMessageInformation().getSource() == MessageInformationSource.B2B) {
          tsdResponseSender.sendActivationNotification(tsd, null, violations);
        }
        // Stop the timer
        tsdTimerService.stopExpirationTimer(
            tsd.getReferenceNumber().getCrn().getCrnNumber(), TSD_EXPIRATION);

        LocalDateTime awaitingRiskResultHours =
            calculateExpirationTimestamp(TimerType.RISK_ANALYSIS_RESULT);
        if (tsd.getCurrentStatus() != PRELODGED && awaitingRiskResultHours != null) {
          tsdTimerService.createExpirationTimer(
              awaitingRiskResultHours,
              tsd.getReferenceNumber().getCrn().getCrnNumber(),
              TimerType.RISK_ANALYSIS_RESULT);
        }
        tsd.addRiskAnalysisAndHistory(
            awaitingRiskResultHours, RiskAndControlStatus.AWAITING_RISK_ANALYSIS_RESULT);
        riskAnalysisGateway.sendTSDToRiskAnalysis(tsd, false, true);
        // trigger IEGA115
        gaGateway.sendOffWritableDocument(tsd);
      }
      // Sending Positive Activation Request
      pnGateway.sendActivationResult(tsd, activationRequest, null);

    } catch (TSDActivationException e) {
      if (hasTSDFoundErrorCodes(getErrorCode(e))
          && e.getTsd() != null
          && e.getTsd().getMessageInformation().getSource() == MessageInformationSource.B2B) {
        TemporaryStorageDeclaration declaration = e.getTsd();
        // populate relatedPN from ActivationRequest
        tsdResponseSender.sendActivationNotification(
            declaration, activationRequest, e.getViolations());
      }
      pnGateway.sendActivationResult(e.getTsd(), activationRequest, e.getViolations());
    }
  }

  /**
   * This method return boolean if ErrorCode contains TSPNESXXR0309, TSPNESXXR0310, TSPNESXXR0311,
   * TSPNESXXR0314. These errorCode are being used if TSD found in repository but either Transport
   * Equipment or Receptacle does not match with Presentation Notification.
   *
   * @param error
   * @return
   */
  private boolean hasTSDFoundErrorCodes(String error) {
    return error != null
        && (error.contains(ErrorCode.TSPNESXXR0309.name())
            || error.contains(ErrorCode.TSPNESXXR0310.name())
            || error.contains(ErrorCode.TSPNESXXR0311.name())
            || error.contains(ErrorCode.TSPNESXXR0314.name()));
  }

  private String getErrorCode(TSDActivationException exception) {
    Optional<ConstraintViolation<TemporaryStorageDeclaration>> violation =
        exception.getViolations().stream().filter(x -> null != x.getMessageTemplate()).findAny();

    if (violation.isPresent()) {
      return violation.get().getMessageTemplate();
    }
    return null;
  }

  private TemporaryStorageDeclaration activateByConsignmentDetails(
      TSDActivationRequest activateRequest) throws TSDActivationException {
    Set<ConstraintViolation<TemporaryStorageDeclaration>> violations = new HashSet<>();
    if (CollectionUtils.isEmpty(activateRequest.getHouseConsignments())
        && activateRequest.getMasterConsignment() != null) {
      return activateByMasterConsignmentDetails(activateRequest, violations);
    } else {
      return activateByHouseConsignmentDetails(activateRequest, violations);
    }
  }

  private TemporaryStorageDeclaration activateByMasterConsignmentDetails(
      TSDActivationRequest activateRequest,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations)
      throws TSDActivationException {
    if (null == activateRequest.getCrn()) {
      addViolation(violations, ErrorCode.TSPNESXXR0307);
      throw new TSDActivationException(violations, null);
    }
    CRN crn = new CRN();
    crn.setCrnNumber(activateRequest.getCrn());

    Optional<TemporaryStorageDeclaration> tsd = tsdRepository.findCurrentVersion(crn);

    if (tsd.isPresent()) {
      validator.validateTSDActivationForMasterConsignment(activateRequest, tsd.get());
      return tsd.get();
    } else {
      addViolation(violations, ErrorCode.TSPNESXXR0308);
      throw new TSDActivationException(violations, null);
    }
  }

  private TemporaryStorageDeclaration activateByHouseConsignmentDetails(
      TSDActivationRequest activateRequest,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations)
      throws TSDActivationException {
    if (null == activateRequest.getCrn()) {
      addViolation(violations, ErrorCode.TSPNESXXR0307);
      throw new TSDActivationException(violations, null);
    }
    CRN crn = new CRN();
    crn.setCrnNumber(activateRequest.getCrn());

    Optional<TemporaryStorageDeclaration> tsd = tsdRepository.findCurrentVersion(crn);

    if (tsd.isPresent()) {
      validator.validateTSDActivationForHouseConsignment(activateRequest, tsd.get());
      return tsd.get();
    } else {
      addViolation(violations, ErrorCode.TSPNESXXR0308);
      throw new TSDActivationException(violations, null);
    }
  }

  private void addViolation(
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations, ErrorCode errorCode) {
    CustomViolation<TemporaryStorageDeclaration> violation = new CustomViolation<>(errorCode, null);
    violations.add(violation);
  }

  /**
   * This method is used to create Timer
   *
   * @return LocalDateTime
   */
  public LocalDateTime calculateExpirationTimestamp(TimerType type) {
    if (type == TSD_EXPIRATION) {
      return Now.localDateTime()
          .plusDays(tsdConfig.getExpirationTimestampPeriod())
          .atOffset(ZoneOffset.UTC)
          .toLocalDateTime();
    } else if (type == TSD_DRAFT_EXPIRATION) {
      return Now.localDateTime()
          .plusDays(tsdConfig.getDraftTSDRemovalPeriod())
          .atOffset(ZoneOffset.UTC)
          .toLocalDateTime();
    } else if (type == RISK_ANALYSIS_RESULT
        && tsdConfig.getAwaitingRiskResultHours() != null
        && tsdConfig.getAwaitingRiskResultHours() > 0) {
      return Now.localDateTime()
          .plusHours(tsdConfig.getAwaitingRiskResultHours())
          .atOffset(ZoneOffset.UTC)
          .toLocalDateTime();
    }
    return null;
  }
}
