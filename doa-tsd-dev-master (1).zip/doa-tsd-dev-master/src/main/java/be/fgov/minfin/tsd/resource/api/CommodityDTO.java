/*
 * @(#)be.fgov.minfin.tsd.resource.api.CommodityDTO.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.resource.api;

import be.fgov.minfin.tsd.resource.validation.B2BOnly;
import com.fasterxml.jackson.annotation.JsonRootName;
import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import lombok.Builder;
import lombok.Value;

/** CommodityDTO */
@Value
@Builder(toBuilder = true)
@JsonRootName("commodity")
public class CommodityDTO {
  @Size(min = 1, max = 512)
  @NotNull(groups = B2BOnly.class)
  private String descriptionOfGoods;

  @Pattern(regexp = "^[0-9 \\-]{9}", message = "{error.TSPNESXXR0045}")
  @Schema(example = "0023277-9", description = "CUS code for the commodity (CL016)")
  private String cusCode;

  @Valid private CommodityCodeDTO commodityCode;
}
