/* @(#) be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model;

import static be.fgov.minfin.tsd.domain.model.InvalidationRequestStatus.APPROVED;
import static be.fgov.minfin.tsd.domain.model.InvalidationRequestStatus.REFUSED;
import static be.fgov.minfin.tsd.domain.model.StatusHistoryReason.LOCATION_OF_GOODS_TYPE_D;
import static be.fgov.minfin.tsd.domain.model.TSDStatus.ACCEPTED;
import static be.fgov.minfin.tsd.domain.model.TSDStatus.IRREGULARITY_UNDER_INVESTIGATION;
import static be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclarationType.COMBINED;
import static be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclarationType.PRELODGED;
import static org.apache.commons.collections4.CollectionUtils.isEmpty;

import be.fgov.minfin.libdoa.commons.lang.Now;
import be.fgov.minfin.libdoa.entities.VersionedAuditableEntity;
import be.fgov.minfin.tsd.domain.converter.ConsignmentInformationTypeConverter;
import be.fgov.minfin.tsd.domain.converter.ReferenceNumberMetadata;
import be.fgov.minfin.tsd.domain.converter.ReferenceNumberMetadataDTO;
import be.fgov.minfin.tsd.domain.converter.RiskAndControlStatusConverter;
import be.fgov.minfin.tsd.domain.converter.TSDDraftErrorConverter;
import be.fgov.minfin.tsd.domain.converter.TSDStatusConverter;
import be.fgov.minfin.tsd.domain.converter.TSDTypeConverter;
import be.fgov.minfin.tsd.domain.message.Error;
import be.fgov.minfin.tsd.domain.model.consignment.Consignment;
import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentHeader;
import be.fgov.minfin.tsd.domain.model.consignment.HouseConsignment;
import be.fgov.minfin.tsd.domain.model.consignment.MasterConsignment;
import be.fgov.minfin.tsd.domain.model.consignment.TransportDocument;
import be.fgov.minfin.tsd.domain.model.party.Party;
import be.fgov.minfin.tsd.domain.model.party.PersonPresentingTheGoods;
import be.fgov.minfin.tsd.domain.model.party.Representative;
import be.fgov.minfin.tsd.domain.model.risk.RiskAnalysisRequest;
import be.fgov.minfin.tsd.domain.model.risk.RiskAndControlStatus;
import be.fgov.minfin.tsd.domain.model.risk.RiskAndControlStatusHistory;
import be.fgov.minfin.tsd.domain.model.risk.RiskAndControlStatusHistoryReason;
import be.fgov.minfin.tsd.domain.validation.CustomViolation;
import be.fgov.minfin.tsd.domain.validation.annotation.CodeList;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidatePartyRules;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateTSDFormat;
import be.fgov.minfin.tsd.domain.validation.annotation.group.CombinedTSDValidatorGroup;
import be.fgov.minfin.tsd.domain.validation.annotation.group.DeconsolidationNotificationValidatorGroup;
import be.fgov.minfin.tsd.domain.validation.annotation.group.NonDraftTSD;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import be.fgov.minfin.tsd.domain.validation.codelist.TSDCodeLists;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import javax.persistence.AttributeOverride;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedAttributeNode;
import javax.persistence.NamedEntityGraph;
import javax.persistence.NamedSubgraph;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.groups.Default;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.apache.commons.collections4.CollectionUtils;
import org.hibernate.annotations.LazyToOne;
import org.hibernate.annotations.LazyToOneOption;

@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Getter
@Setter
@Table(name = "TSD")
@ValidateBusinessRules(groups = {Default.class, DeconsolidationNotificationValidatorGroup.class})
@ValidatePartyRules
@ValidateTSDFormat(groups = {NonDraftTSD.class})
@NamedEntityGraph(
    name = "get-tsd-version-entity-graph",
    attributeNodes = {
      @NamedAttributeNode("amendmentRequest"),
      @NamedAttributeNode("referenceNumber"),
      @NamedAttributeNode("messageInformation"),
      @NamedAttributeNode("declarant"),
      @NamedAttributeNode("representative"),
      @NamedAttributeNode("personPresentingTheGoods"),
      @NamedAttributeNode("transferNotification"),
      @NamedAttributeNode("deconsolidationNotification"),
      @NamedAttributeNode(
          value = "invalidationRequests",
          subgraph = "subgraph.invalidationRequests")
    },
    subgraphs = {
      @NamedSubgraph(
          name = "subgraph.invalidationRequests",
          attributeNodes = {
            @NamedAttributeNode("declarant"),
            @NamedAttributeNode("representative"),
            @NamedAttributeNode("messageInformation")
          })
    })
@NamedEntityGraph(
    name = "get-ui-entity-graph",
    attributeNodes = {
      @NamedAttributeNode("amendmentRequest"),
      @NamedAttributeNode("messageExchange"),
      @NamedAttributeNode("messageInformation"),
      @NamedAttributeNode("declarant"),
      @NamedAttributeNode("representative"),
      @NamedAttributeNode("personPresentingTheGoods"),
      @NamedAttributeNode("referenceNumber"),
      @NamedAttributeNode("transferNotification"),
      @NamedAttributeNode("deconsolidationNotification")
    })
@NamedEntityGraph(
    name = "get-tsd-Consignment-entity-graph",
    attributeNodes = {
      @NamedAttributeNode("referenceNumber"),
      @NamedAttributeNode("messageInformation"),
      @NamedAttributeNode("declarant"),
      @NamedAttributeNode("representative"),
      @NamedAttributeNode("personPresentingTheGoods"),
      @NamedAttributeNode(value = "masterConsignment", subgraph = "subgraph.masterConsignment"),
      @NamedAttributeNode(value = "houseConsignments", subgraph = "subgraph.houseConsignments"),
      @NamedAttributeNode("transferNotification"),
      @NamedAttributeNode("deconsolidationNotification")
    },
    subgraphs = {
      @NamedSubgraph(
          name = "subgraph.masterConsignment",
          attributeNodes = {
            @NamedAttributeNode("consignor"),
            @NamedAttributeNode("consignee"),
            @NamedAttributeNode("notifyParty")
          }),
      @NamedSubgraph(
          name = "subgraph.houseConsignments",
          attributeNodes = {
            @NamedAttributeNode("consignor"),
            @NamedAttributeNode("consignee"),
            @NamedAttributeNode("notifyParty")
          })
    })
public class TemporaryStorageDeclaration extends VersionedAuditableEntity<Long>
    implements ReferenceNumberMetadata {

  @Id
  @GeneratedValue(generator = "TSD_SEQ")
  @SequenceGenerator(name = "TSD_SEQ", sequenceName = "TSD_SEQ")
  private Long id;

  @NotNull(groups = NonDraftTSD.class)
  private String lrn;

  @CodeList(TSDCodeLists.CL027)
  @Column(name = "ENS_REUSE_INDICATOR")
  private String ensReUseIndicator;

  private LocalDateTime expirationTimestamp;

  @Column(name = "TS_EXPIRATION_TIMESTAMP")
  private LocalDateTime temporaryStorageExpirationTimestamp;

  private String linkedPnFrn;

  @Convert(converter = TSDTypeConverter.class)
  private TemporaryStorageDeclarationType type;

  @Convert(converter = ConsignmentInformationTypeConverter.class)
  @Column(name = "CONSIGNMENT_TYPE")
  private ConsignmentInformationType consignmentType;

  @Convert(converter = ConsignmentInformationTypeConverter.class)
  @Column(name = "CONSIGNMENT_ITEM_TYPE")
  private ConsignmentInformationType consignmentItemType;

  @Column(name = "DATE_AND_TIME_OF_PRESENTATION")
  @NotNull(groups = CombinedTSDValidatorGroup.class)
  private LocalDateTime dateAndTimeOfPresentationOfTheGoods;

  @Column(name = "DECLARATION_DATE")
  private LocalDateTime declarationDate;

  @Column(name = "REGISTRATION_DATE")
  private LocalDateTime registrationDate;

  @Convert(converter = TSDStatusConverter.class)
  private TSDStatus currentStatus;

  @Column(name = "VERSION")
  private Integer currentVersion;

  @Convert(converter = TSDDraftErrorConverter.class)
  private TSDDraftError draftError;

  @OneToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "REFERENCE_NUMBER_ID")
  @ToString.Exclude
  @JsonIgnoreProperties("declaration")
  private ReferenceNumber referenceNumber;

  @OneToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "MESSAGE_INFORMATION_ID")
  @ToString.Exclude
  @Valid
  private MessageInformation messageInformation;

  @AttributeOverride(
      name = "referenceNumber",
      column = @Column(name = "CUSTOMS_OFFICE_OF_PRE_REF_NUM"))
  @Valid
  @Embedded
  @CodeList(value = TSDCodeLists.CL141, errorCode = ErrorCode.TSPNESXXC0021)
  private CustomsOffice customsOfficeOfPresentation;

  @AttributeOverride(
      name = "referenceNumber",
      column = @Column(name = "SUPERV_CUSTOMS_OFFICE_REF_NUM"))
  @Valid
  @Embedded
  @CodeList(value = TSDCodeLists.CL141, errorCode = ErrorCode.TSPNESXXC0020)
  @NotNull(groups = NonDraftTSD.class)
  private CustomsOffice supervisingCustomsOffice;

  @Valid
  @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "DECLARANT_ID")
  @ToString.Exclude
  @NotNull(groups = NonDraftTSD.class)
  private Party declarant;

  @OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "REPRESENTATIVE_ID")
  @ToString.Exclude
  @Valid
  private Representative representative;

  @Valid
  @Embedded
  @NotNull(groups = CombinedTSDValidatorGroup.class)
  private PersonPresentingTheGoods personPresentingTheGoods;

  @OneToOne(cascade = CascadeType.ALL, mappedBy = "declaration", fetch = FetchType.LAZY)
  @LazyToOne(value = LazyToOneOption.NO_PROXY)
  @ToString.Exclude
  @Valid
  @JsonIgnoreProperties("declaration")
  private MasterConsignment masterConsignment;

  @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
  @LazyToOne(value = LazyToOneOption.PROXY)
  @JoinColumn(name = "AMENDMENT_REQUEST_ID")
  @ToString.Exclude
  @Valid
  @JsonIgnoreProperties("declaration")
  private AmendmentRequest amendmentRequest;

  @OneToMany(
      mappedBy = "declaration",
      cascade = {},
      orphanRemoval = true)
  @ToString.Exclude
  @JsonIgnoreProperties("declaration")
  private List<MessageExchange> messageExchange;

  @OneToMany(
      mappedBy = "declaration",
      cascade = {CascadeType.PERSIST, CascadeType.MERGE},
      orphanRemoval = true)
  @ToString.Exclude
  @JsonIgnoreProperties("declaration")
  private List<@Valid HouseConsignment> houseConsignments;

  @OneToMany(
      mappedBy = "declaration",
      cascade = {CascadeType.PERSIST, CascadeType.MERGE},
      orphanRemoval = true)
  @ToString.Exclude
  @JsonIgnoreProperties("declaration")
  private List<InvalidationRequest> invalidationRequests;

  @OneToMany(
      mappedBy = "declaration",
      cascade = {CascadeType.PERSIST, CascadeType.MERGE},
      orphanRemoval = true)
  @ToString.Exclude
  @JsonIgnoreProperties("declaration")
  private List<AmendmentRequest> amendmentRequests;

  @OneToMany(
      mappedBy = "declaration",
      cascade = {CascadeType.PERSIST, CascadeType.MERGE},
      orphanRemoval = true)
  @ToString.Exclude
  @JsonIgnoreProperties("declaration")
  private List<TransferNotification> transferNotifications;

  @ToString.Exclude
  @JsonIgnoreProperties("declaration")
  @OneToMany(
      mappedBy = "declaration",
      cascade = {CascadeType.PERSIST, CascadeType.MERGE},
      orphanRemoval = true)
  private List<RiskAndControlStatusHistory> riskAndControlHistory;

  @ToString.Exclude
  @JsonIgnoreProperties("declaration")
  @OneToMany(
      mappedBy = "declaration",
      cascade = {CascadeType.PERSIST, CascadeType.MERGE},
      orphanRemoval = true)
  private List<RiskAnalysisRequest> riskAnalysisRequest;

  @Convert(converter = RiskAndControlStatusConverter.class)
  private RiskAndControlStatus currentRiskControlStatus;

  @Embedded @Valid private ConsignmentHeader consignmentHeader;

  @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
  @LazyToOne(value = LazyToOneOption.PROXY)
  @JoinColumn(name = "TRANSFER_NOTIFICATION_ID")
  @ToString.Exclude
  @Valid
  private TransferNotification transferNotification;

  @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
  @LazyToOne(value = LazyToOneOption.PROXY)
  @JoinColumn(name = "DECONSOLIDATION_NOTIFICAT_ID")
  @ToString.Exclude
  @Valid
  @JsonIgnoreProperties("declaration")
  private DeconsolidationNotification deconsolidationNotification;

  public void trackHistory(
      TSDStatus tsdStatus, StatusHistoryReason reason, LocalDateTime dateAndTime) {
    if (this.referenceNumber.getHistory() == null) {
      this.referenceNumber.setHistory(new ArrayList<>());
    }
    this.referenceNumber.getHistory().add(new StatusHistory(this, tsdStatus, reason, dateAndTime));
  }

  public void completeNewDeclaration() {

    this.currentVersion = 1;
    this.registrationDate = Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime();

    if (null == referenceNumber) {
      this.referenceNumber = new ReferenceNumber(this);
    } else {
      this.referenceNumber.setReferenceNumberAttributes(this);
    }

    if (this.type == PRELODGED) {

      this.currentStatus = TSDStatus.PRELODGED;

    } else if (this.type == COMBINED) {
      if (!this.consignmentHeader
          .getDecalaredlocationOfGoods()
          .getTypeOfLocation()
          .equalsIgnoreCase("D")) {
        this.currentStatus = ACCEPTED;
      } else {
        this.currentStatus = IRREGULARITY_UNDER_INVESTIGATION;
        // Also insert a status history record with current status ACCEPTED
        trackHistory(TSDStatus.ACCEPTED, null, registrationDate.minusNanos(800));
      }
    }

    trackHistory(
        null,
        this.currentStatus == IRREGULARITY_UNDER_INVESTIGATION ? LOCATION_OF_GOODS_TYPE_D : null,
        registrationDate);
  }

  public void addRiskAnalysisAndHistory(
      LocalDateTime expirationTimestamp, RiskAndControlStatus racStatus) {
    LocalDateTime systemDateAndTime =
        Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime();
    this.currentRiskControlStatus = racStatus;

    trackRiskAndControlStatusHistory(null, systemDateAndTime);
    if (this.riskAnalysisRequest == null) {
      this.setRiskAnalysisRequest(new ArrayList<>());
    }
    this.getRiskAnalysisRequest()
        .add(new RiskAnalysisRequest(this, systemDateAndTime, expirationTimestamp));
  }

  public void trackRiskAndControlStatusHistory(
      RiskAndControlStatusHistoryReason reason, LocalDateTime timeStamp) {
    if (this.riskAndControlHistory == null) {
      this.setRiskAndControlHistory(new ArrayList<>());
    }
    this.getRiskAndControlHistory().add(new RiskAndControlStatusHistory(this, reason, timeStamp));
  }

  public void addTSDActivationValues(TSDActivationRequest activateTSDRequest) {
    this.setDateAndTimeOfPresentationOfTheGoods(
        activateTSDRequest.getDateAndTimeOfPresentationOfTheGoods());
    this.setLinkedPnFrn(activateTSDRequest.getFrn());
    this.getConsignmentHeader().setCarrier(activateTSDRequest.getConsignmentHeader().getCarrier());
    this.getConsignmentHeader()
        .setPresentedlocationOfGoods(
            activateTSDRequest.getConsignmentHeader().getPresentedlocationOfGoods());
    this.setCustomsOfficeOfPresentation(activateTSDRequest.getCustomsOfficeOfPresentation());
    this.setPersonPresentingTheGoods(
        PersonPresentingTheGoods.builder()
            .identificationNumber(
                activateTSDRequest.getPersonPresentingTheGoods().getIdentificationNumber())
            .build());
    this.setExpirationTimestamp(null);
    if (!activateTSDRequest
        .getConsignmentHeader()
        .getPresentedlocationOfGoods()
        .getTypeOfLocation()
        .equalsIgnoreCase("D")) {
      this.currentStatus = ACCEPTED;
    } else {
      this.currentStatus = IRREGULARITY_UNDER_INVESTIGATION;
      // Also insert a status history record with current status ACCEPTED
      trackHistory(TSDStatus.ACCEPTED, null, registrationDate.minusNanos(800));
    }

    // Generation of MRN
    if (null == referenceNumber.getMrn()) {
      MRN mrn = new MRN();
      mrn.setReferenceNumberMetadata(this);
      this.referenceNumber.setMrn(mrn);
    }

    trackHistory(
        null,
        this.currentStatus == IRREGULARITY_UNDER_INVESTIGATION ? LOCATION_OF_GOODS_TYPE_D : null,
        null);
  }

  @Override
  public ReferenceNumberMetadataDTO setReferenceNumberMetadata() {
    return ReferenceNumberMetadataDTO.builder()
        .id(this.id)
        .receptionTimestamp(this.getRegistrationDate())
        .type(this.type)
        .build();
  }

  @JsonIgnore
  public boolean isEnsReuseRequested() {
    return "1".equals(this.ensReUseIndicator);
  }

  public void addInvalidationRequest(
      InvalidationRequest invalidationRequest, List<ValidationError> validationErrors) {

    if (CollectionUtils.isEmpty(validationErrors)) {
      invalidationRequest =
          invalidationRequest.toBuilder()
              .status(APPROVED)
              .registrationDate(Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime())
              .build();
    } else {
      invalidationRequest =
          invalidationRequest.toBuilder()
              .status(REFUSED)
              .registrationDate(Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime())
              .validationErrors(validationErrors)
              .build();
    }

    if (invalidationRequests == null) {
      invalidationRequests = new ArrayList<>();
    }
    invalidationRequests.add(invalidationRequest);
  }

  public void copyAmendmentAttributes(TemporaryStorageDeclaration tsd, List<Error> errors) {
    this.setExpirationTimestamp(tsd.getExpirationTimestamp());
    this.setTemporaryStorageExpirationTimestamp(tsd.getTemporaryStorageExpirationTimestamp());
    this.setLrn(tsd.getLrn());
    this.setLinkedPnFrn(tsd.getLinkedPnFrn());
    this.getConsignmentHeader()
        .setPresentedlocationOfGoods(tsd.getConsignmentHeader().getPresentedlocationOfGoods());
    this.registrationDate = tsd.getRegistrationDate();
    this.setType(tsd.getType());
    if (null == this.currentStatus || this.currentStatus == TSDStatus.DRAFT) {
      this.setCurrentStatus(tsd.getCurrentStatus());
    }
    if (amendmentRequests == null) {
      amendmentRequests = new ArrayList<>();
    }
    if (CollectionUtils.isEmpty(errors)) {

      AmendmentRequest amendmentReq =
          AmendmentRequest.builder()
              .status(AmendmentRequestStatus.APPROVED)
              .registrationDate(Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime())
              .declaration(tsd)
              .build();
      amendmentRequests.add(amendmentReq);
      this.setAmendmentRequest(amendmentReq);
    } else {
      List<ValidationError> validationErrors =
          errors.stream()
              .map(
                  (Error e) ->
                      ValidationError.builder()
                          .code(e.getErrorCode().toString())
                          .pointer(e.getErrorPointer())
                          .sequenceNumber(e.getSequenceNumber())
                          .reason(e.getErrorReason())
                          .build())
              .collect(Collectors.toList());
      AmendmentRequest amendmentReq =
          AmendmentRequest.builder()
              .status(AmendmentRequestStatus.REFUSED)
              .registrationDate(Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime())
              .declaration(tsd)
              .validationErrors(validationErrors)
              .build();

      amendmentRequests.add(amendmentReq);
      this.setAmendmentRequest(amendmentReq);
    }
    if (tsd.getCurrentStatus() != IRREGULARITY_UNDER_INVESTIGATION
        && this.currentStatus == IRREGULARITY_UNDER_INVESTIGATION) {
      trackHistory(null, StatusHistoryReason.AMENDMENT_IRREGULARITY, null);
    }
  }

  public void completeDraftDeclaration() {
    this.currentStatus = TSDStatus.DRAFT;
    this.currentVersion = 1;
    this.setReferenceNumber(new ReferenceNumber(this));
    this.registrationDate = Now.localDateTime();
  }

  public void checkCanModify() {
    if (this.getCurrentStatus() != TSDStatus.DRAFT) {
      CustomViolation.doThrow(ErrorCode.TSPNESXXR0318, "tsdId");
    }
  }

  public void checkCanDelete() {
    checkCanModify();
  }

  public void checkDraftAmendmentStillValid(
      TemporaryStorageDeclaration currentTSD, List<Integer> versions) {
    final String TSD_ID = "tsdId";
    List<Integer> lstTSDVersions =
        versions.stream().filter((v) -> this.currentVersion <= v).collect(Collectors.toList());
    if (!CollectionUtils.isEmpty(lstTSDVersions)) {
      CustomViolation.doThrow(ErrorCode.TSPNESXXR0325, TSD_ID);
    }
    if (null == this.linkedPnFrn && null != currentTSD.getLinkedPnFrn()) {
      CustomViolation.doThrow(ErrorCode.TSPNESXXR0326, TSD_ID);
    }
  }

  public void completeDraftAmendment() {
    this.currentStatus = TSDStatus.DRAFT;
  }

  public void completeValidatedRiskAnalysisResult(
      RiskAndControlStatus riskAndControlStatus, RiskAndControlStatusHistoryReason reason) {
    this.currentRiskControlStatus = riskAndControlStatus;
    LocalDateTime systemDateAndTime =
        Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime();
    this.trackRiskAndControlStatusHistory(reason, systemDateAndTime);
  }

  public void updateRegistrationDate() {
    this.registrationDate = Now.localDateTime();
  }

  /**
   * This method is used to calculate consignment item and consignment type while registration of
   * tsd and cration of draft amendment.normally all the consignment and item are already present in
   * memory before system reaches this method
   *
   * @param currentTSD
   * @param ensReuse
   */
  public void updateConsignmentTypeAndItemType() {
    updateConsignmentTypeAndItemType(null);
  }

  /**
   * This method is used to calculate consignment item and consignment type while registration of
   * tsd and cration of draft amendment.normally all the consignment and item are already present in
   * memory before system reaches this method
   *
   * @param currentTSD
   * @param ensReuse
   */
  public void updateConsignmentTypeAndItemType(TemporaryStorageDeclaration currentTSD) {
    if (null == currentTSD) {
      if (null != this.getMasterConsignment() && isEmpty(this.getHouseConsignments())) {
        this.setConsignmentType(ConsignmentInformationType.MASTER);

      } else if (null == this.getMasterConsignment() && !isEmpty(this.getHouseConsignments())) {
        this.setConsignmentType(ConsignmentInformationType.HOUSE);

      } else if (null != this.getMasterConsignment() && !isEmpty(this.getHouseConsignments())) {
        this.setConsignmentType(ConsignmentInformationType.MASTERANDHOUSE);
      }
      setConsignmentItemType();
    } else {
      if (this.isEnsReuseRequested()) {
        setConsignmentTypeForEnsReuseAllowed(currentTSD);
      } else {
        setConsignmentAndItemTypeForEnsReuseNotAllowed(currentTSD);
      }
    }
  }

  private void setConsignmentItemType() {

    boolean isMasterItemPresent =
        (null != this.getMasterConsignment()
                && !isEmpty(this.getMasterConsignment().getConsignmentItem()))
            ? true
            : false;
    boolean isHouseItemPresent =
        (!isEmpty(this.getHouseConsignments())
                && !isEmpty(this.getHouseConsignments().get(0).getConsignmentItem()))
            ? true
            : false;
    if (isMasterItemPresent && isHouseItemPresent) {
      this.setConsignmentItemType(ConsignmentInformationType.MASTERANDHOUSE);
    } else if (isHouseItemPresent) {
      this.setConsignmentItemType(ConsignmentInformationType.HOUSE);
    } else if (isMasterItemPresent) {
      this.setConsignmentItemType(ConsignmentInformationType.MASTER);
    }
  }

  private void setConsignmentAndItemTypeForEnsReuseNotAllowed(
      TemporaryStorageDeclaration currentDeclaration) {

    if (!isEmpty(currentDeclaration.getHouseConsignments())
        && null != currentDeclaration.getMasterConsignment()) {
      this.setConsignmentType(ConsignmentInformationType.MASTERANDHOUSE);
    } else if (isEmpty(currentDeclaration.getHouseConsignments())
        && null != currentDeclaration.getMasterConsignment()) {
      this.setConsignmentType(ConsignmentInformationType.MASTER);
    } else if (null == currentDeclaration.getMasterConsignment()
        && !isEmpty(currentDeclaration.getHouseConsignments())) {
      this.setConsignmentType(ConsignmentInformationType.HOUSE);
    }

    if (this.getConsignmentType() == ConsignmentInformationType.MASTERANDHOUSE) {
      setConsignmentItemTypeForDraftAmendment(currentDeclaration);
    }
  }

  private void setConsignmentItemTypeForDraftAmendment(
      TemporaryStorageDeclaration currentDeclaration) {
    List<HouseConsignment> hcWithoutItem =
        getHouseConsignmentWithoutItem(currentDeclaration.getHouseConsignments());
    if (!isEmpty(hcWithoutItem)
        && !isEmpty(currentDeclaration.getMasterConsignment().getConsignmentItem())) {
      this.setConsignmentItemType(ConsignmentInformationType.MASTER);
    } else if (isEmpty(hcWithoutItem)
        && !isEmpty(currentDeclaration.getMasterConsignment().getConsignmentItem())) {
      this.setConsignmentItemType(ConsignmentInformationType.MASTERANDHOUSE);
    } else if (isEmpty(hcWithoutItem)
        && isEmpty(this.getMasterConsignment().getConsignmentItem())) {
      this.setConsignmentItemType(ConsignmentInformationType.HOUSE);
    }
  }

  private List<HouseConsignment> getHouseConsignmentWithoutItem(
      List<HouseConsignment> houseConsignment) {
    return houseConsignment.stream()
        .filter((c) -> isEmpty(c.getConsignmentItem()))
        .collect(Collectors.toList());
  }

  private void setConsignmentTypeForEnsReuseAllowed(
      TemporaryStorageDeclaration currentDeclaration) {

    if (!isEmpty(currentDeclaration.getHouseConsignments())
        && null != currentDeclaration.getMasterConsignment()) {
      if (isEmpty(currentDeclaration.getMasterConsignment().getConsignmentItem())) {
        this.setConsignmentType(ConsignmentInformationType.MASTERANDHOUSE);
      } else {
        this.setConsignmentType(ConsignmentInformationType.MASTER);
      }
    } else if (null == currentDeclaration.getMasterConsignment()
        && !isEmpty(currentDeclaration.getHouseConsignments())) {
      this.setConsignmentType(ConsignmentInformationType.HOUSE);
    }
    this.setConsignmentItemType(null);
  }

  /**
   * Adds a risk analysis request/ risk and control status history whenever a TSD is send for Risk
   * Analysis. It also sets the currentRiskControlStatus of the TSD to AWAITING_RISK_ANALYSIS_RESULT
   *
   * @param expirationTimestamp
   */
  public void addRiskAnalysisAndHistory(LocalDateTime expirationTimestamp) {
    LocalDateTime systemDateAndTime =
        Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime();
    this.currentRiskControlStatus = RiskAndControlStatus.AWAITING_RISK_ANALYSIS_RESULT;

    trackRiskAndControlStatusHistory(null, systemDateAndTime);
    if (this.riskAnalysisRequest == null) {
      this.setRiskAnalysisRequest(new ArrayList<>());
    }
    this.getRiskAnalysisRequest()
        .add(new RiskAnalysisRequest(this, systemDateAndTime, expirationTimestamp));
  }

  public void maximumExpirationTimestamp() {
    String typeOfLocation =
        this.getConsignmentHeader().getPresentedlocationOfGoods().getTypeOfLocation();
    if (this.dateAndTimeOfPresentationOfTheGoods != null
        && (this.getCurrentStatus() == TSDStatus.ACCEPTED
            || this.getCurrentStatus() == TSDStatus.IRREGULARITY_UNDER_INVESTIGATION)) {
      if (typeOfLocation.equals("C")) {
        this.setTemporaryStorageExpirationTimestamp(
            this.dateAndTimeOfPresentationOfTheGoods
                .plusDays(3)
                .with(LocalTime.MAX)
                .truncatedTo(ChronoUnit.SECONDS)
                .atOffset(ZoneOffset.UTC)
                .toLocalDateTime());
      } else
        this.setTemporaryStorageExpirationTimestamp(
            this.dateAndTimeOfPresentationOfTheGoods
                .plusDays(90)
                .with(LocalTime.MAX)
                .truncatedTo(ChronoUnit.SECONDS)
                .atOffset(ZoneOffset.UTC)
                .toLocalDateTime());
    }
  }

  public Consignment getMatchingHouseConsignment(TransportDocument transportDocument) {

    Optional<HouseConsignment> houseConsignmentOpt =
        this.houseConsignments.stream()
            .filter(house -> house.getTransportDocument().equals(transportDocument))
            .findFirst();

    if (houseConsignmentOpt.isPresent()) {
      return houseConsignmentOpt.get();
    } else {
      return null;
    }
  }

  public void appendTranferNotificationDetails(
      Integer maxVersion,
      TemporaryStorageDeclaration currentTSD,
      TransferNotification transferNotification,
      List<Error> errors) {

    this.referenceNumber = currentTSD.getReferenceNumber();
    this.currentVersion = maxVersion + 1;

    if (CollectionUtils.isEmpty(errors)) {
      // Set cloned TSD as current version in case of approved transfer
      // notification
      this.referenceNumber.setDeclaration(this);
      setTransferNotificationConsignmentLocOfGoods(currentTSD, transferNotification);
    }

    this.transferNotification = transferNotification;
    if (this.transferNotifications == null) {
      this.transferNotifications = new ArrayList<>();
    }
    this.transferNotifications.add(transferNotification);
  }

  private void setTransferNotificationConsignmentLocOfGoods(
      TemporaryStorageDeclaration currentTSD, TransferNotification transferNotification) {

    if (null != transferNotification.getMasterConsignment()) {
      this.masterConsignment.setCurrentConsignmentLocationOfGoods(
          transferNotification.getConsignmentLocationOfGoods());

      if (CollectionUtils.isNotEmpty(this.houseConsignments)) {
        this.houseConsignments.forEach(
            houseConsignment ->
                houseConsignment.setCurrentConsignmentLocationOfGoods(
                    transferNotification.getConsignmentLocationOfGoods()));
      }
    } else if (currentTSD.getMasterConsignment() != null) {
      this.masterConsignment.setCurrentConsignmentLocationOfGoods(
          currentTSD.getMasterConsignment().getCurrentConsignmentLocationOfGoods());
    }

    if (CollectionUtils.isNotEmpty(transferNotification.getHouseConsignments())) {

      Map<TransportDocument, HouseConsignment> currentTDHouseConsignmentMap =
          currentTSD.getHouseConsignments().stream()
              .collect(
                  Collectors.toMap(HouseConsignment::getTransportDocument, Function.identity()));

      List<TransportDocument> transferNotificationTransDocList =
          transferNotification.getHouseConsignments().stream()
              .map(TransferNotificationConsignment::getTransportDocument)
              .toList();

      this.houseConsignments.forEach(
          houseConsignment ->
              setTNHouseConsignmentLocationOfGoods(
                  houseConsignment,
                  transferNotification,
                  currentTDHouseConsignmentMap,
                  transferNotificationTransDocList));
    }
  }

  private void setTNHouseConsignmentLocationOfGoods(
      HouseConsignment houseConsignment,
      TransferNotification transferNotification,
      Map<TransportDocument, HouseConsignment> currentTDHouseConsignmentMap,
      List<TransportDocument> transferNotificationTransDocList) {

    if (transferNotificationTransDocList.contains(houseConsignment.getTransportDocument())) {
      houseConsignment.setCurrentConsignmentLocationOfGoods(
          transferNotification.getConsignmentLocationOfGoods());
    } else {
      houseConsignment.setCurrentConsignmentLocationOfGoods(
          currentTDHouseConsignmentMap
              .get(houseConsignment.getTransportDocument())
              .getCurrentConsignmentLocationOfGoods());
    }
  }

  public void appendDeconsolidationNotificationDetails(
      Integer maxVersion,
      TemporaryStorageDeclaration currentTSD,
      DeconsolidationNotification deconNotification,
      List<Error> errors) {

    this.lrn = currentTSD.getLrn();
    this.ensReUseIndicator = currentTSD.getEnsReUseIndicator();
    this.expirationTimestamp = currentTSD.getExpirationTimestamp();
    this.temporaryStorageExpirationTimestamp = currentTSD.getTemporaryStorageExpirationTimestamp();
    this.linkedPnFrn = currentTSD.getLinkedPnFrn();
    this.type = currentTSD.getType();
    this.dateAndTimeOfPresentationOfTheGoods = currentTSD.getDateAndTimeOfPresentationOfTheGoods();
    this.declarationDate = currentTSD.getDeclarationDate();
    this.registrationDate = currentTSD.getRegistrationDate();
    this.currentStatus = currentTSD.getCurrentStatus();
    this.customsOfficeOfPresentation = currentTSD.getCustomsOfficeOfPresentation();
    this.supervisingCustomsOffice = currentTSD.getSupervisingCustomsOffice();
    this.personPresentingTheGoods = currentTSD.getPersonPresentingTheGoods();

    this.currentVersion = maxVersion + 1;
    this.consignmentType = ConsignmentInformationType.MASTERANDHOUSE;
    this.consignmentItemType = ConsignmentInformationType.MASTERANDHOUSE;
    this.referenceNumber = currentTSD.getReferenceNumber();

    if (CollectionUtils.isEmpty(errors)) {
      // Set clonedTSD as current version in case of approved deconsolidation notification
      this.referenceNumber.setDeclaration(this);
      setDeconNotificationConsignmentLocOfGoods(currentTSD);
    }

    this.deconsolidationNotification = deconNotification;
  }

  private void setDeconNotificationConsignmentLocOfGoods(TemporaryStorageDeclaration currentTSD) {

    if (null != currentTSD.getMasterConsignment().getCurrentConsignmentLocationOfGoods()) {
      this.masterConsignment.setCurrentConsignmentLocationOfGoods(
          currentTSD.getMasterConsignment().getCurrentConsignmentLocationOfGoods());
      this.houseConsignments.forEach(
          houseConsignment ->
              houseConsignment.setCurrentConsignmentLocationOfGoods(
                  currentTSD.getMasterConsignment().getCurrentConsignmentLocationOfGoods()));
    }
  }

  @JsonIgnore
  public List<Consignment> getConsignments() {
    List<Consignment> result = new ArrayList<>();
    if (masterConsignment != null) {
      result.add(masterConsignment);
    }
    if (houseConsignments != null) {
      result.addAll(houseConsignments);
    }
    return result;
  }
}
