/*
 * @(#) be.fgov.minfin.tsd.domain.validation.validator.PartyAddressValidator.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation.validator;

import be.fgov.minfin.libdoa.csrd2.gateway.ReferenceDataGateway;
import be.fgov.minfin.tsd.domain.model.party.Party;
import be.fgov.minfin.tsd.domain.model.party.Person;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;

public class PartyAddressValidator extends BaseConstraintValidator
    implements ConstraintValidator<ValidateBusinessRules, Party> {
  private static final String ADDRESS = "address";
  private static final String POBOX = "poBox";
  private static final String POST_CODE = "postCode";
  @Autowired private ReferenceDataGateway referenceDataGateway;

  @Override
  public boolean isValid(Party party, ConstraintValidatorContext context) {
    boolean isValid = true;
    if (party instanceof Person) {
      String country = party.getAddress().getCountry();
      String postCodeDataLevel =
          null != country
              ? referenceDataGateway.getPostCodeDatalevelForCountryCode().get(country)
              : null;
      if (!StringUtils.hasText(party.getAddress().getPoBox())
          && (!StringUtils.hasText(party.getAddress().getStreet())
              || !StringUtils.hasText(party.getAddress().getNumber()))) {
        addViolation(context, ErrorCode.TSPNESXXC0006, ADDRESS, POBOX);
        isValid = false;
      }

      if ((!StringUtils.hasText(country)
              || null == postCodeDataLevel
              || !postCodeDataLevel.equals("C"))
          && !StringUtils.hasText(party.getAddress().getPostCode())) {
        addViolation(context, ErrorCode.TSPNESXXC0007, ADDRESS, POST_CODE);
        isValid = false;
      }
    }
    return isValid;
  }
}
