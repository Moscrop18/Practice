/*
 * @(#) be.fgov.minfin.tsd.domain.validation.validator.NumberCompareValidator.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation.validator;

import be.fgov.minfin.tsd.domain.validation.annotation.NumberCompare;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import be.fgov.minfin.tsd.util.NumberCompareType;
import java.math.BigDecimal;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * This class is to validate minimum decimal number
 *
 * @author NamrataGupta
 */
public class NumberCompareValidator extends BaseConstraintValidator
    implements ConstraintValidator<NumberCompare, Number> {

  private volatile ErrorCode errorCode;

  private volatile BigDecimal valueInAnnotation;

  private volatile NumberCompareType numberCompareType;

  @Override
  public void initialize(NumberCompare data) {
    this.errorCode = data.errorCode();
    this.valueInAnnotation = BigDecimal.valueOf(data.value());
    this.numberCompareType = data.numberCompareType();
  }

  @Override
  public boolean isValid(Number number, ConstraintValidatorContext context) {

    boolean isvalid = true;

    if (number != null) {

      BigDecimal actualValue = new BigDecimal(number.toString());

      int compareToResult = actualValue.compareTo(this.valueInAnnotation);

      switch (this.numberCompareType) {
        case GREATER_THAN:
          isvalid = compareToResult > 0;
          break;
        case GREATER_THAN_OR_EQUAL_TO:
          isvalid = compareToResult >= 0;
          break;
        case EQUAL_TO:
          isvalid = compareToResult == 0;
          break;
        case NOT_EQUAL_TO:
          isvalid = compareToResult != 0;
          break;
        case LESS_THAN:
          isvalid = compareToResult < 0;
          break;
        case LESS_THAN_OR_EQUAL_TO:
          isvalid = compareToResult <= 0;
          break;
      }
    }

    if (!isvalid) {
      addViolation(context, this.errorCode);
    }

    return isvalid;
  }
}
