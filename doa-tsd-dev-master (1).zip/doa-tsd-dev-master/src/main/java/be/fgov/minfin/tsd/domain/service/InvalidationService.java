/*
 * @(#)be.fgov.minfin.tsd.domain.service.InvalidationService.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.service;

import static be.fgov.minfin.tsd.domain.model.StatusHistoryReason.REQUEST;
import static be.fgov.minfin.tsd.domain.model.TSDStatus.INVALIDATED;
import static be.fgov.minfin.tsd.domain.model.TimerType.TSD_EXPIRATION;

import be.fgov.minfin.libdoa.commons.lang.Now;
import be.fgov.minfin.tsd.domain.model.CRN;
import be.fgov.minfin.tsd.domain.model.InvalidationRequest;
import be.fgov.minfin.tsd.domain.model.MessageInformation;
import be.fgov.minfin.tsd.domain.model.MessageInformationSource;
import be.fgov.minfin.tsd.domain.model.StatusHistory;
import be.fgov.minfin.tsd.domain.model.StatusHistoryReason;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.ValidationError;
import be.fgov.minfin.tsd.domain.model.party.Party;
import be.fgov.minfin.tsd.domain.model.party.Representative;
import be.fgov.minfin.tsd.domain.model.risk.RiskAndControlStatus;
import be.fgov.minfin.tsd.domain.repository.TSDRepository;
import be.fgov.minfin.tsd.domain.sender.TSDResponseSender;
import be.fgov.minfin.tsd.domain.validation.plugin.InvalidationRequestValidatorPlugin;
import be.fgov.minfin.tsd.event.TSDEventBroker;
import be.fgov.minfin.tsd.event.api.TSDInvalidationReceivedEvent;
import be.fgov.minfin.tsd.gateway.control.ControlGateway;
import be.fgov.minfin.tsd.gateway.risk.RiskAnalysisGateway;
import be.fgov.minfin.tsd.resource.generator.CorrelationIdGenerator;
import be.fgov.minfin.tsd.util.MessageTemplateUtil;
import java.time.ZoneOffset;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import javax.validation.ConstraintViolation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * This service layer is for invalidation of a pre-lodged TSD
 *
 * @author MohdSalim
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class InvalidationService {

  private final TSDEventBroker eventBroker;
  private final InvalidationRequestValidatorPlugin invalidationRequestValidator;
  private final TSDRepository tsdRepository;
  private final TSDResponseSender tsdResponseSender;
  private final TSDTimerService tsdTimerService;
  private final MessageTemplateUtil messageTemplate;
  private final RiskAnalysisGateway riskAnalysisGateway;
  private final ControlGateway controlGateway;
  private final CorrelationIdGenerator correlationIdGenerator;
  /** constant value for <code>NUMERIC_ZERO</code> */
  public static final int NUMERIC_ZERO = 0;

  public static final String ERROR_CODE = "99";

  /**
   * This method will send invalidation request event to Queue
   *
   * @param invalidationRequest
   */
  public void receiveInvalidationRequest(String crn, InvalidationRequest invalidationRequest) {

    TSDInvalidationReceivedEvent tsdInvalidationReceivedEvent =
        TSDInvalidationReceivedEvent.builder()
            .crn(crn)
            .invalidationRequest(invalidationRequest)
            .build();
    eventBroker.publishInvalidateTSDEvent(tsdInvalidationReceivedEvent);
  }

  /**
   * This method will trigger the business validations and upon failure of business validations it
   * triggers the sending of validation refused message on the eo notification gateway, if there are
   * no business validation failures, it proceeds to invalidate the TSD.
   *
   * @param crn
   * @param invalidationRequest
   */
  public void processInvalidationRequest(
      final String crn, InvalidationRequest invalidationRequest) {
    log.debug("inside process invalidation request");
    CRN refNumber = CRN.of(crn);
    Optional<TemporaryStorageDeclaration> tsd = tsdRepository.findCurrentVersion(refNumber);
    invalidationRequest =
        invalidationRequest.toBuilder().declaration(tsd.isPresent() ? tsd.get() : null).build();
    // Trigger business validation
    Set<ConstraintViolation<InvalidationRequest>> violations =
        invalidationRequestValidator.validateInvalidationRequest(invalidationRequest);
    if (violations.isEmpty()) {
      invalidateDeclaration(crn, invalidationRequest, tsd.isPresent() ? tsd.get() : null, REQUEST);
    } else {
      // send TSD invalidation refused message IETS016
      tsdResponseSender.sendInvalidationRefusedMessage(
          crn, invalidationRequest, violations, tsd.isPresent());
      if (tsd.isPresent()) { // register invalidated Invalidation Request
        tsd.get().addInvalidationRequest(invalidationRequest, getValidationErrors(violations));
      }
    }
  }

  /**
   * This method is triggered when invalidation request is received or during automatic invalidation
   * of TSD when the timers expire. It registers validated InvalidationRequest and deletes the
   * corresponding TSD timer if the status history reason is REQUEST, sets the TSDStatus to
   * INVALIDATED and also sends the invalidation notification on the EO notification gateway
   *
   * @param mrn
   * @param invalidationRequest
   * @param declaration
   * @param reason
   */
  public void invalidateDeclaration(
      String crn,
      InvalidationRequest invalidationRequest,
      TemporaryStorageDeclaration declaration,
      StatusHistoryReason reason) {

    if (reason == REQUEST) {
      tsdTimerService.stopExpirationTimer(
          declaration.getReferenceNumber().getCrn().getCrnNumber(), TSD_EXPIRATION);
      declaration.addInvalidationRequest(invalidationRequest, null);
    }
    declaration.setCurrentStatus(INVALIDATED);
    declaration.trackHistory(null, reason, null);
    declaration.setCurrentRiskControlStatus(
        RiskAndControlStatus.PRE_ARRIVAL_RISK_ANALYSIS_CANCELLED);
    declaration.trackRiskAndControlStatusHistory(
        null, Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime());
    // send TSD invalidation notification IETS410
    StatusHistory history =
        declaration.getReferenceNumber().getHistory().stream()
            .filter(x -> x.getStatus() == INVALIDATED)
            .findFirst()
            .orElse(null);
    if (reason == REQUEST
        || declaration.getMessageInformation().getSource() == MessageInformationSource.B2B) {
      tsdResponseSender.sendInvalidationNotification(
          crn, invalidationRequest, declaration, history, reason);
    }
    riskAnalysisGateway.sendInvalidationNotification(declaration);
    controlGateway.sendInvalidationNotification(declaration);
  }

  /**
   * This Method will Trigger from Front end API. It registers validated InvalidationRequest and
   * deletes the corresponding TSD timer if the status history reason is REQUEST, sets the TSDStatus
   * to INVALIDATED
   *
   * @param invalidationRequest
   * @param tsd
   * @return
   */
  public Set<ConstraintViolation<InvalidationRequest>> invalidateDelarationUI(
      InvalidationRequest invalidationRequest, TemporaryStorageDeclaration tsd) {
    invalidationRequest =
        invalidationRequest.toBuilder()
            .declaration(tsd)
            .declarant(
                Party.builder()
                    .name(tsd.getDeclarant().getName())
                    .identificationNumber(tsd.getDeclarant().getIdentificationNumber())
                    .build())
            .representative(
                null == tsd.getRepresentative()
                    ? null
                    : Representative.representativeBuilder()
                        .identificationNumber(tsd.getRepresentative().getIdentificationNumber())
                        .name(tsd.getRepresentative().getName())
                        .build())
            .build();
    // Trigger business validation
    Set<ConstraintViolation<InvalidationRequest>> violations =
        invalidationRequestValidator.validateInvalidationRequest(invalidationRequest);
    invalidationRequest.setMessageInformation(
        MessageInformation.buildMessageInformation(correlationIdGenerator.generateCorrelationID()));
    if (violations.isEmpty()) {
      tsdTimerService.stopExpirationTimer(
          tsd.getReferenceNumber().getCrn().getCrnNumber(), TSD_EXPIRATION);
      tsd.addInvalidationRequest(invalidationRequest, null);
      tsd.setCurrentStatus(INVALIDATED);
      tsd.trackHistory(null, StatusHistoryReason.REQUEST, null);
      tsd.setCurrentRiskControlStatus(RiskAndControlStatus.PRE_ARRIVAL_RISK_ANALYSIS_CANCELLED);
      tsd.trackRiskAndControlStatusHistory(
          null, Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime());
      riskAnalysisGateway.sendInvalidationNotification(tsd);
      controlGateway.sendInvalidationNotification(tsd);

    } else {

      tsd.addInvalidationRequest(invalidationRequest, getValidationErrors(violations));
    }
    return violations;
  }

  private List<ValidationError> getValidationErrors(
      Set<ConstraintViolation<InvalidationRequest>> violations) {
    AtomicInteger violationSequenceNumber = new AtomicInteger(NUMERIC_ZERO);
    return violations.stream()
        .sorted(
            Comparator.<ConstraintViolation<?>, String>comparing(
                v ->
                    v.getPropertyPath().toString()
                        + v.getConstraintDescriptor().getAnnotation().getClass().getName(),
                Comparator.nullsLast(Comparator.naturalOrder())))
        .map(v -> createValidationError(v, violationSequenceNumber.incrementAndGet()))
        .collect(Collectors.toList());
  }

  private ValidationError createValidationError(
      final ConstraintViolation<?> violation, int violationSequenceNumber) {
    return ValidationError.builder()
        .sequenceNumber(violationSequenceNumber)
        .pointer(
            null != violation.getPropertyPath() ? violation.getPropertyPath().toString() : null)
        .code(ERROR_CODE)
        .reason(messageTemplate.getReasonFromMessageTemplate(violation.getMessageTemplate(), false))
        .build();
  }
}
