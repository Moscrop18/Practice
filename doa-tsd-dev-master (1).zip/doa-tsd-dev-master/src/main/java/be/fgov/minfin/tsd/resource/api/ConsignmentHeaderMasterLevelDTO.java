/*
 * @(#)be.fgov.minfin.tsd.resource.api.ConsignmentHeaderMasterLevelDTO.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */

package be.fgov.minfin.tsd.resource.api;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import java.util.List;
import javax.validation.Valid;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Value;

@Value
@JsonRootName("consignmentHeaderMasterLevel")
@EqualsAndHashCode(callSuper = true)
public class ConsignmentHeaderMasterLevelDTO extends BaseHeaderMasterLevelDTO {
  @Builder
  public ConsignmentHeaderMasterLevelDTO(
      @JsonProperty("consignmentMasterLevel") ConsignmentMasterLevelDTO consignmentMasterLevel,
      @JsonProperty("consignmentHouseLevel")
          List<@Valid ConsignmentHouseLevelDTO> consignmentHouseLevel,
      @JsonProperty("arrivalTransportMeans") ArrivalTransportMeansDTO arrivalTransportMeans,
      @JsonProperty("warehouse") WarehouseDTO warehouse,
      @JsonProperty("placeOfUnloading") PlaceOfUnloadingDTO placeOfUnloading,
      @JsonProperty("locationOfGoods") @Valid LocationOfGoodsDTO locationOfGoods) {
    super(
        consignmentMasterLevel,
        consignmentHouseLevel,
        arrivalTransportMeans,
        warehouse,
        placeOfUnloading);
    this.locationOfGoods = locationOfGoods;
  }

  @Valid private LocationOfGoodsDTO locationOfGoods;
}
