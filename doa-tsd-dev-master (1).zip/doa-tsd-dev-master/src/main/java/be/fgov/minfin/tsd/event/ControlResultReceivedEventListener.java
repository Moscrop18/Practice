/*
 * @(#)be.fgov.minfin.tsd.event.ControlResultReceivedEventListener.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.event;

import static be.fgov.minfin.tsd.event.TSDEventConfig.TSD_CONTROL_RESULT_RECEIVED_CONCURRENCY;
import static be.fgov.minfin.tsd.event.TSDEventConfig.TSD_CONTROL_RESULT_RECEIVED_QUEUE;

import be.fgov.minfin.libdoa.amqp.transactional.AbstractRetryingQueueListener;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.service.ControlService;
import be.fgov.minfin.tsd.domain.service.TSDService;
import be.fgov.minfin.tsd.event.api.ControlResultReceivedEvent;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Component
@Transactional
public class ControlResultReceivedEventListener extends AbstractRetryingQueueListener {

  public static final String LISTENER_ID = "processControlResult";
  private final ControlService controlService;

  private final TSDService tsdService;

  public ControlResultReceivedEventListener(
      TSDEventConfig cfg, ControlService controlService, TSDService tsdService) {
    super(cfg.getTsdReceivedQueue());
    this.controlService = controlService;
    this.tsdService = tsdService;
  }

  @RabbitListener(
      id = LISTENER_ID,
      queues = TSD_CONTROL_RESULT_RECEIVED_QUEUE,
      concurrency = TSD_CONTROL_RESULT_RECEIVED_CONCURRENCY)
  public void processRiskAnalysisResultReceivedEvent(
      @Payload ControlResultReceivedEvent event, Message message) {
    log.info(
        "ControlResultReceivedEvent received in listener with functionalReference {}",
        event.getReceiveControlResult().getFunctionalReference());

    Optional<TemporaryStorageDeclaration> tsd =
        tsdService.getDeclaration(event.getReceiveControlResult().getMrn());
    controlService.processControlResult(event.getReceiveControlResult(), tsd);
  }
}
