/*
 * @(#)be.fgov.minfin.tsd.domain.model.consignment.Commodity
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model.consignment;

import be.fgov.minfin.tsd.domain.validation.annotation.CodeList;
import be.fgov.minfin.tsd.domain.validation.annotation.group.DeconsolidationNotificationValidatorGroup;
import be.fgov.minfin.tsd.domain.validation.annotation.group.NonDraftTSD;
import be.fgov.minfin.tsd.domain.validation.codelist.TSDCodeLists;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import javax.validation.constraints.NotNull;
import javax.validation.groups.Default;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode // do not exclude any field
@Embeddable
public class Commodity {
  @Column(name = "COMMODITY_DESCRIPTION_OF_GOODS")
  @NotNull(groups = NonDraftTSD.class)
  private String descriptionOfGoods;

  @Column(name = "COMMODITY_CUS_CODE", columnDefinition = "char")
  private @CodeList(
      value = TSDCodeLists.CL016,
      groups = {Default.class, DeconsolidationNotificationValidatorGroup.class}) String cusCode;

  @Embedded
  private @CodeList(
      value = TSDCodeLists.CL706,
      groups = {Default.class, DeconsolidationNotificationValidatorGroup.class}) CommodityCode
      commodityCode;
}
