/*
 * @(#)be.fgov.minfin.tsd.domain.model.consignment.ArrivalTransportMeans
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model.consignment;

import be.fgov.minfin.tsd.domain.validation.annotation.CodeList;
import be.fgov.minfin.tsd.domain.validation.annotation.group.NonDraftTSD;
import be.fgov.minfin.tsd.domain.validation.codelist.TSDCodeLists;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules
@Embeddable
public class ArrivalTransportMeans {
  @Column(name = "ARRIVAL_TRANS_MEAN_ID_NUM")
  @NotNull(groups = NonDraftTSD.class)
  private String identificationNumber;

  @Column(name = "ARRIVAL_TRANS_MEAN_TYPE_ID")
  @NotNull(groups = NonDraftTSD.class)
  private @CodeList(TSDCodeLists.CL750) Integer typeOfIdentification;
}
