/*
 * @(#)be.fgov.minfin.tsd.event.TSDReceivedEventListener.java
 * =========================================================================== This source code is
 * exclusive propriety of the SPF Finances. In no case are the contents allowed to be distributed to
 * third parties or made public without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.event;

import static be.fgov.minfin.tsd.event.TSDEventConfig.TSD_RECEIVED_CONCURRENCY;
import static be.fgov.minfin.tsd.event.TSDEventConfig.TSD_RECEIVED_QUEUE;

import be.fgov.minfin.libdoa.amqp.transactional.AbstractRetryingQueueListener;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.service.TSDService;
import be.fgov.minfin.tsd.event.api.TSDReceivedEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * event listener for pn
 *
 * @author GauravMitra
 */
@Slf4j
@Component
@Transactional
public class TSDReceivedEventListener extends AbstractRetryingQueueListener {
  public static final String LISTENER_ID = "processTSDReceived";
  private TSDService tsdService;

  public TSDReceivedEventListener(TSDEventConfig cfg, TSDService tsdService) {
    super(cfg.getTsdReceivedQueue());
    this.tsdService = tsdService;
  }

  @RabbitListener(
      id = LISTENER_ID,
      queues = TSD_RECEIVED_QUEUE,
      concurrency = TSD_RECEIVED_CONCURRENCY)
  public void processTSDReceivedEvent(@Payload TSDReceivedEvent event, Message message) {
    log.info(
        "Message Received on Listener with Following Message information Details {}",
        event.getDeclaration().getMessageInformation());
    TemporaryStorageDeclaration declaration = event.getDeclaration();
    tsdService.processDeclaration(declaration);
  }
}
