/*
 * @(#)be.fgov.minfin.tsd.domain.message.TSDRejectMessage.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.message;

import be.fgov.minfin.tsd.domain.model.BusinessValidationType;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import java.time.LocalDateTime;
import java.util.List;
import lombok.Builder;
import lombok.Value;

/**
 * @author GauravMitra
 */
@Value
@Builder
public class TSDRejectMessage {
  private MessageHeader messageHeader;
  private LocalDateTime notificationDate;
  private BusinessValidationType businessValidationType;
  private String remarks;
  private List<Error> error;
  private TemporaryStorageDeclaration declaration;
}
