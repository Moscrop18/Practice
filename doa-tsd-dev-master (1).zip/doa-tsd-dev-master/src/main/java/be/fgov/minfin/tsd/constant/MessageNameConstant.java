/*
 * @(#) be.fgov.minfin.tsd.constant.MessageNameConstant.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.constant;

/**
 * @author GauravMitra
 */
public final class MessageNameConstant {

  private MessageNameConstant() {
    super();
  }

  public static final String REFUSAL_MESSAGE = "IETS016";

  public static final String ACTIVATION_RESULT_MESSAGE = "IETS024";

  public static final String ACCEPT_MESSAGE = "IETS028";

  public static final String ACTIVATION_NOTIFICATION = "IETS029";

  public static final String RECEIVE_RISK_HIT_NOTIFICATION = "IETS403";

  public static final String INVALIDATION_NOTIFICATION = "IETS410";

  public static final String INVALIDATION_NOTIFICATION_TO_RISK_AND_CONTROL = "IETS417";

  public static final String SEND_RISK_ANAYSIS_REQUEST = "IETS435";

  public static final String SEND_RISK_ANALYSIS_RESULT = "IETS436";

  public static final String SEND_CONTROL_RECOMMENDATION_NOTIFICATION = "IETS440";

  public static final String SEND_VALIDATED_CONTROL_RESULT = "IETS444";

  public static final String SEND_INTENDED_CONTROL_NOTIFICATION = "IETS460";

  public static final String NEGATIVE_ACK = "IETS906";

  public static final String POSTIVE_ACK = "IETS928";

  public static final String SEND_OFFWRITABLE_DOCUMENT = "IEGA115";

  public static final String SEND_GA_OWD_TRANSFER_NOTIFICATION = "IEGA207";

  public static final String DECONSOLIDATE_OFFWRITABLE_DOCUMENT = "IEGA215";
}
