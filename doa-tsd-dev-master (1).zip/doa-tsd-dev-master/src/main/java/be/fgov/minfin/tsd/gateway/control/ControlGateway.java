/*
 * @(#) be.fgov.minfin.tsd.gateway.control.ControlGateway.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.control;

import static be.fgov.minfin.tsd.constant.MessageNameConstant.SEND_CONTROL_RECOMMENDATION_NOTIFICATION;
import static be.fgov.minfin.tsd.util.DateFormatUtil.MESSAGE_TIMESTAMP_FORMAT;

import be.fgov.minfin.libdoa.amqp.transactional.QueueSender;
import be.fgov.minfin.libdoa.commons.lang.Now;
import be.fgov.minfin.tsd.config.TSDConfig;
import be.fgov.minfin.tsd.domain.model.DeconsolidationNotification;
import be.fgov.minfin.tsd.domain.model.MessageExchange;
import be.fgov.minfin.tsd.domain.model.MessageInformation;
import be.fgov.minfin.tsd.domain.model.ReceiveRiskAnalysisResult;
import be.fgov.minfin.tsd.domain.model.TSDStatus;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.repository.MessageExchangeRepository;
import be.fgov.minfin.tsd.domain.repository.StatusHistoryRepository;
import be.fgov.minfin.tsd.gateway.control.message.MessageHeader;
import be.fgov.minfin.tsd.gateway.control.message.SendControlInvalidationNotification;
import be.fgov.minfin.tsd.gateway.control.message.SendControlRecommendation;
import be.fgov.minfin.tsd.resource.generator.CorrelationIdGenerator;
import be.fgov.minfin.tsd.util.DateUtil;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * This is class send tsdcontrolrequest event in the queue and save in message exchange
 *
 * @author GauravMitra
 */
@Component
@RequiredArgsConstructor
public class ControlGateway {
  private final ControlGatewayConfig cfg;
  private final QueueSender queueSender;
  private final StatusHistoryRepository statusHistoryRepository;
  private final TSDConfig tsdCfg;
  private final MessageExchangeRepository messageExchangeRepository;
  private final CorrelationIdGenerator correlationIdGenerator;
  private final DateUtil dateUtil;

  public void sendInvalidationNotification(TemporaryStorageDeclaration tsd) {
    String completionDate =
        statusHistoryRepository
            .findByStatusAndReferenceNumberId(
                TSDStatus.INVALIDATED, tsd.getReferenceNumber().getId())
            .get(0)
            .getTimestamp()
            .toString();

    String uniqueMessageId = correlationIdGenerator.generateCorrelationID();

    SendControlInvalidationNotification riskAnalysisRequest =
        SendControlInvalidationNotification.builder()
            .messageHeader(buildMessageHeader(uniqueMessageId, tsd.getMessageInformation()))
            .completionDate(completionDate)
            .build();
    queueSender.publishMessage(cfg.getControlInvalidationQueue(), riskAnalysisRequest);
  }

  private MessageHeader buildMessageHeader(
      String uniqueMessageId, MessageInformation messageInformation) {
    return MessageHeader.builder()
        .sender(tsdCfg.getTsdSystemName())
        .recipient(tsdCfg.getRaiSystemName())
        .messageId(uniqueMessageId)
        .messageTimestamp(
            DateTimeFormatter.ofPattern(MESSAGE_TIMESTAMP_FORMAT)
                .format(Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime()))
        .refToMessageId(null != messageInformation ? messageInformation.getRefToMessageId() : null)
        .languageCode(null != messageInformation ? messageInformation.getLanguageCode() : null)
        .correlationId(null != messageInformation ? messageInformation.getCorrelationID() : null)
        .build();
  }

  private void saveMessageExchange(
      String messageId, String type, TemporaryStorageDeclaration declaration) {

    MessageExchange messageExchange =
        MessageExchange.builder()
            .messageId(messageId)
            .messageTimestamp(dateUtil.getCurentSystemDate())
            .messageType(type)
            .declaration(declaration)
            .build();

    messageExchangeRepository.save(messageExchange);
  }

  public void sendControlRecommendationNotification(
      TemporaryStorageDeclaration declaration,
      ReceiveRiskAnalysisResult receiveRiskAnalysisResult,
      DeconsolidationNotification deconsolidationNotificationHeader) {

    String uniqueMessageId = correlationIdGenerator.generateCorrelationID();

    saveMessageExchange(uniqueMessageId, SEND_CONTROL_RECOMMENDATION_NOTIFICATION, declaration);

    SendControlRecommendation sendControlRecommendation =
        SendControlRecommendation.builder()
            .messageHeader(buildMessageHeader(uniqueMessageId, declaration.getMessageInformation()))
            .declaration(declaration)
            .receiveRiskAnalysisResult(receiveRiskAnalysisResult)
            .deconsolidationNotificationHeader(deconsolidationNotificationHeader)
            .build();

    queueSender.publishMessage(cfg.getControlRecommendationQueue(), sendControlRecommendation);
  }
}
