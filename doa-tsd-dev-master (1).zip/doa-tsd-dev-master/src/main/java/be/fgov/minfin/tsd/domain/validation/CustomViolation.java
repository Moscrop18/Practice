/*
 * @(#)be.fgov.minfin.tsd.domain.validation.CustomViolation
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation;

import be.fgov.minfin.tsd.domain.exception.BusinessException;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import java.util.HashSet;
import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.Path;
import javax.validation.metadata.ConstraintDescriptor;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * This class is to set custom violations, these violations are handy when annotation based business
 * validation is not required.
 *
 * @author NamrataGupta
 */
@Getter
@Setter
@AllArgsConstructor
public class CustomViolation<T> implements ConstraintViolation<T> {

  private ErrorCode errorCode;
  private String path;

  @Override
  public ConstraintDescriptor<?> getConstraintDescriptor() {
    return null;
  }

  @Override
  public Object[] getExecutableParameters() {
    return new Object[0];
  }

  @Override
  public Object getExecutableReturnValue() {
    return null;
  }

  @Override
  public Object getInvalidValue() {
    return null;
  }

  @Override
  public Object getLeafBean() {
    return null;
  }

  @Override
  public String getMessage() {
    return null;
  }

  @Override
  public String getMessageTemplate() {
    return "{error." + this.errorCode.name() + "}";
  }

  @Override
  public Path getPropertyPath() {
    return null;
  }

  @Override
  public T getRootBean() {
    return null;
  }

  @Override
  public Class<T> getRootBeanClass() {
    return null;
  }

  @Override
  public <U> U unwrap(Class<U> arg0) {
    return null;
  }

  public String getPath() {
    return this.path;
  }

  public void setPath(String... errors) {
    StringBuilder sb = new StringBuilder();
    for (String error : errors) {
      sb = sb.append(error);
    }
    if (this.path != null) {
      this.path = this.path + sb.toString();
    } else {
      this.path = sb.toString();
    }
  }

  public static void doThrow(ErrorCode code, String pointer) {
    Set<ConstraintViolation<?>> violations = new HashSet<>();
    violations.add(new CustomViolation<>(code, pointer));
    throw new BusinessException(violations);
  }
}
