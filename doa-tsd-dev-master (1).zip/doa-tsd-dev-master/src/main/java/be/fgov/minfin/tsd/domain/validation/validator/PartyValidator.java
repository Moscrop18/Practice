/*
 * @(#) be.fgov.minfin.pn.domain.validation.validator.PartyValidator.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation.validator;

import be.fgov.minfin.libdoa.commons.lang.Now;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.party.Party;
import be.fgov.minfin.tsd.domain.model.party.Representative;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidatePartyRules;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import be.fgov.minfin.tsd.gateway.crs.CRSGateway;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * This class is to validate declarant of TSD
 *
 * @author NamrataGupta
 */
@Component
public class PartyValidator extends BaseConstraintValidator
    implements ConstraintValidator<ValidatePartyRules, TemporaryStorageDeclaration> {
  public static final String DECLARANT = "declarant";
  public static final String IND_NUMBER = "identificationNumber";
  public static final String REPRESENTATIVE = "representative";
  private static final String CARRIER = "carrier";
  private static final String CONSIGNMENT_HEADER_MASTER_LEVEL = "consignmentHeader";
  public static final String PERSON_PRESENTING_THE_GOODS = "personPresentingTheGoods";

  @Autowired private CRSGateway crsGateway;

  @Override
  public boolean isValid(TemporaryStorageDeclaration value, ConstraintValidatorContext context) {

    AtomicBoolean hasError = new AtomicBoolean(false);

    validateDeclarantIdentificationNumber(value.getDeclarant(), hasError, context);
    validateCarrierIdentificationNumber(value, hasError, context);
    validateRepresentativeIdentificationNumber(value.getRepresentative(), hasError, context);
    validateSameEoriNumber(value.getDeclarant(), value.getRepresentative(), hasError, context);
    validatePersonPresentingGoodsIdentificationNumber(value, hasError, context);
    return !hasError.get();
  }

  public void validateCarrierIdentificationNumber(
      TemporaryStorageDeclaration tsd, AtomicBoolean hasError, ConstraintValidatorContext context) {
    if (null == tsd.getConsignmentHeader() || null == tsd.getConsignmentHeader().getCarrier())
      return;
    AtomicBoolean isValid =
        checkValidEoriNumber(tsd.getConsignmentHeader().getCarrier().getIdentificationNumber());
    if (!isValid.get()) {
      hasError.set(true);
      addViolation(
          context, ErrorCode.TSPNESXXR0103, CONSIGNMENT_HEADER_MASTER_LEVEL, CARRIER, IND_NUMBER);
    }
  }

  public void validatePersonPresentingGoodsIdentificationNumber(
      TemporaryStorageDeclaration tsd, AtomicBoolean hasError, ConstraintValidatorContext context) {
    if (null == tsd.getPersonPresentingTheGoods()) return;
    AtomicBoolean isValid =
        checkValidEoriNumber(tsd.getPersonPresentingTheGoods().getIdentificationNumber());
    if (!isValid.get()) {
      hasError.set(true);
      addViolation(context, ErrorCode.TSPNESXXR0017, PERSON_PRESENTING_THE_GOODS, IND_NUMBER);
    }
  }

  public void validateDeclarantIdentificationNumber(
      Party declarant, AtomicBoolean hasError, ConstraintValidatorContext context) {
    if (null == declarant) return;
    AtomicBoolean isValid = checkValidEoriNumber(declarant.getIdentificationNumber());

    if (!isValid.get()) {
      hasError.set(true);
      addViolation(context, ErrorCode.TSPNESXXR0001, DECLARANT, IND_NUMBER);
    }
  }

  public void validateRepresentativeIdentificationNumber(
      Representative representative, AtomicBoolean hasError, ConstraintValidatorContext context) {
    if (null == representative) return;
    AtomicBoolean isValid = checkValidEoriNumber(representative.getIdentificationNumber());

    if (!isValid.get()) {
      hasError.set(true);
      addViolation(context, ErrorCode.TSPNESXXR0002, REPRESENTATIVE, IND_NUMBER);
    }
  }

  public void validateSameEoriNumber(
      Party declarant,
      Representative representative,
      AtomicBoolean hasError,
      ConstraintValidatorContext context) {
    if (declarant == null) return;
    if (representative == null) return;
    if (representative
        .getIdentificationNumber()
        .equalsIgnoreCase(declarant.getIdentificationNumber())) {
      addViolation(context, ErrorCode.TSPNESXXC0003, REPRESENTATIVE, IND_NUMBER);
      hasError.set(true);
    }
  }

  private AtomicBoolean checkValidEoriNumber(String identificationNumber) {
    AtomicBoolean isValid = new AtomicBoolean(true);
    Optional<Party> party =
        crsGateway.getPartyInfo(identificationNumber, Now.localDateTime(), false, false);

    if (party.isEmpty()) {
      isValid.set(false);
    }

    return isValid;
  }
}
