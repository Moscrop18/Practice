/*
 * @(#) be.fgov.minfin.tsd.domain.validation.validator.TSDInvalidationValidator.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation.validator;

import be.fgov.minfin.libdoa.commons.lang.Now;
import be.fgov.minfin.tsd.domain.model.InvalidationRequest;
import be.fgov.minfin.tsd.domain.model.TSDStatus;
import be.fgov.minfin.tsd.domain.model.party.Party;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import be.fgov.minfin.tsd.gateway.crs.CRSGateway;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * This class performs the business validation on Invalidation Request.
 *
 * @author MohdSalim
 */
@Component
public class TSDInvalidationValidator extends BaseConstraintValidator
    implements ConstraintValidator<ValidateBusinessRules, InvalidationRequest> {

  public static final String IND_NUMBER = "identificationNumber";
  public static final String REPRESENTATIVE = "representative";
  public static final String DECLARANT = "declarant";
  public static final String CRN = "crn";

  @Autowired private CRSGateway crsGateway;

  @Override
  public boolean isValid(InvalidationRequest request, ConstraintValidatorContext context) {

    AtomicBoolean hasError = new AtomicBoolean(false);
    validateRepresentativeIdentificationNumber(request, hasError, context);
    validateSameEoriNumber(request, hasError, context);
    validateValidMRN(request, hasError, context);
    validateTSDStatus(request, hasError, context);
    validateDeclarantIdentificationNumber(request, hasError, context);
    return !hasError.get();
  }

  private void validateValidMRN(
      InvalidationRequest request, AtomicBoolean hasError, ConstraintValidatorContext context) {
    if (request.getDeclaration() == null) {
      addViolation(context, ErrorCode.TSPNESXXR0104, CRN);
      hasError.set(true);
    }
  }

  private void validateTSDStatus(
      InvalidationRequest request, AtomicBoolean hasError, ConstraintValidatorContext context) {
    if (request.getDeclaration() == null) return;
    if (request.getDeclaration() != null
        && request.getDeclaration().getCurrentStatus() != TSDStatus.PRELODGED) {
      hasError.set(true);
      addViolation(context, ErrorCode.TSPNESXXR0105, CRN);
    }
  }

  private void validateDeclarantIdentificationNumber(
      InvalidationRequest request, AtomicBoolean hasError, ConstraintValidatorContext context) {
    if (request.getDeclaration() == null) return;
    if (request.getDeclaration() != null) {
      Party declarant = request.getDeclaration().getDeclarant();
      if (declarant == null
          || request.getDeclarant() == null
          || request.getDeclarant().getIdentificationNumber() == null
          || !request
              .getDeclarant()
              .getIdentificationNumber()
              .equals(declarant.getIdentificationNumber())) {
        hasError.set(true);
        addViolation(context, ErrorCode.TSPNESXXR0106, DECLARANT, IND_NUMBER);
      }
    }
  }

  private void validateRepresentativeIdentificationNumber(
      InvalidationRequest request, AtomicBoolean hasError, ConstraintValidatorContext context) {
    if (null == request.getRepresentative()) return;
    AtomicBoolean isValid =
        checkValidEoriNumber(request.getRepresentative().getIdentificationNumber());

    if (!isValid.get()) {
      hasError.set(true);
      addViolation(context, ErrorCode.TSPNESXXR0002, REPRESENTATIVE, IND_NUMBER);
    }
  }

  private void validateSameEoriNumber(
      InvalidationRequest request, AtomicBoolean hasError, ConstraintValidatorContext context) {
    if (request.getDeclarant() == null) return;
    if (request.getRepresentative() == null) return;
    if (request
        .getRepresentative()
        .getIdentificationNumber()
        .equalsIgnoreCase(request.getDeclarant().getIdentificationNumber())) {
      addViolation(context, ErrorCode.TSPNESXXC0003, REPRESENTATIVE, IND_NUMBER);
      hasError.set(true);
    }
  }

  private AtomicBoolean checkValidEoriNumber(String identificationNumber) {
    AtomicBoolean isValid = new AtomicBoolean(true);
    Optional<Party> party =
        crsGateway.getPartyInfo(identificationNumber, Now.localDateTime(), false, false);

    if (party.isEmpty()) {
      isValid.set(false);
    }

    return isValid;
  }
}
