/*
 * @(#) be.fgov.minfin.tsd.domain.sender.TSDResponseSender.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties
 * or made public without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.sender;

import static be.fgov.minfin.tsd.domain.model.StatusHistoryReason.REQUEST;
import static be.fgov.minfin.tsd.util.DateFormatUtil.MESSAGE_DATE_TIME_FORMAT;

import be.fgov.minfin.libdoa.commons.lang.Now;
import be.fgov.minfin.tsd.config.TSDConfig;
import be.fgov.minfin.tsd.domain.message.Error;
import be.fgov.minfin.tsd.domain.message.MessageHeader;
import be.fgov.minfin.tsd.domain.message.SendIntendedControlNotification;
import be.fgov.minfin.tsd.domain.message.TSDAcceptMessage;
import be.fgov.minfin.tsd.domain.message.TSDActivationNotification;
import be.fgov.minfin.tsd.domain.message.TSDAmendmentRejectMessage;
import be.fgov.minfin.tsd.domain.message.TSDDeconsolidationNotificationAcceptMessage;
import be.fgov.minfin.tsd.domain.message.TSDDeconsolidationNotificationRefusedMessage;
import be.fgov.minfin.tsd.domain.message.TSDInvalidationNotification;
import be.fgov.minfin.tsd.domain.message.TSDInvalidationRefusedMessage;
import be.fgov.minfin.tsd.domain.message.TSDRejectMessage;
import be.fgov.minfin.tsd.domain.message.TSDTransferNotificationAcceptMessage;
import be.fgov.minfin.tsd.domain.message.TSDTransferNotificationRefusedMessage;
import be.fgov.minfin.tsd.domain.model.BusinessValidationType;
import be.fgov.minfin.tsd.domain.model.ConsignmentLocationOfGoods;
import be.fgov.minfin.tsd.domain.model.CustomsOffice;
import be.fgov.minfin.tsd.domain.model.DeconsolidationNotification;
import be.fgov.minfin.tsd.domain.model.InvalidationRequest;
import be.fgov.minfin.tsd.domain.model.MessageInformation;
import be.fgov.minfin.tsd.domain.model.ReceiveRiskAnalysisResult;
import be.fgov.minfin.tsd.domain.model.StatusHistory;
import be.fgov.minfin.tsd.domain.model.StatusHistoryReason;
import be.fgov.minfin.tsd.domain.model.TSDActivationRequest;
import be.fgov.minfin.tsd.domain.model.TSDStatus;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.TransferNotification;
import be.fgov.minfin.tsd.domain.model.consignment.MasterConsignment;
import be.fgov.minfin.tsd.domain.validation.CustomViolation;
import be.fgov.minfin.tsd.gateway.eo.EONotificationGateway;
import be.fgov.minfin.tsd.resource.generator.CorrelationIdGenerator;
import be.fgov.minfin.tsd.util.DateUtil;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import javax.validation.ConstraintViolation;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.stereotype.Component;

/**
 * This is class is used to build accept and reject message and send it to EONotification Gateway
 *
 * @author GauravMitra
 */
@Component
@RequiredArgsConstructor
public class TSDResponseSender {

  /** constant value for <code>DOT_CHARACTER</code> */
  public static final String DOT_CHARACTER = ".";

  /** constant value for <code>NUMERIC_ZERO</code> */
  public static final int NUMERIC_ZERO = 0;

  /** constant value for <code>NUMERIC_ZERO</code> */
  public static final String EMPTY_STRING = "";

  public static final int ERROR_CODE = 99;
  public static final String XX = "XX";

  public static final String CONSIGNMENT_ITEM = "consignmentItem";
  public static final String GROSS_MASS = "grossMass";
  private static final String CONSIGNMENT_LOCATION_OF_GOODS = "consignmentLocationOfGoods";
  private static final String LOCATION_OF_GOODS = "locationOfGoods";

  private final EONotificationGateway eoNotificationGateway;
  private final TSDConfig tsdCfg;
  private final MessageSourceAccessor messageSourceAccessor;
  private final DateUtil dateUtil;
  private final CorrelationIdGenerator correlationIdGenerator;

  public void sendAcceptMessage(
      TemporaryStorageDeclaration declaration, BusinessValidationType businessValidationType) {
    TSDAcceptMessage acceptMessage =
        TSDAcceptMessage.builder()
            .messageHeader(buildHeader(declaration.getMessageInformation()))
            .declaration(declaration)
            .notificationDate(declaration.getMessageInformation().getReceptionTimestamp())
            .businessValidationType(businessValidationType)
            .status(declaration.getCurrentStatus())
            .expirationDate(declaration.getExpirationTimestamp())
            .build();
    eoNotificationGateway.sendMessage(acceptMessage);
  }

  public void sendAEOIntendedControlNotification(
      TemporaryStorageDeclaration tsd,
      ReceiveRiskAnalysisResult receiveRiskAnalysisResult,
      boolean isTransferSender,
      boolean isDeconsolidationSender) {
    SendIntendedControlNotification sendIntendedControlNotification =
        SendIntendedControlNotification.builder()
            .messageHeader(
                buildHeader(
                    selectMessageInformation(isTransferSender, isDeconsolidationSender, tsd)))
            .declaration(tsd)
            .receiveRiskAnalysisResult(receiveRiskAnalysisResult)
            .scheduledControlDate(
                receiveRiskAnalysisResult.getControlNotification().getScheduledControlDate())
            .notificationDate(
                DateTimeFormatter.ofPattern(MESSAGE_DATE_TIME_FORMAT)
                    .format(Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime()))
            .isTransferMessageSender(isTransferSender)
            .isDeconsolidationMessageSender(isDeconsolidationSender)
            .build();
    eoNotificationGateway.sendMessage(sendIntendedControlNotification);
  }

  private MessageInformation selectMessageInformation(
      boolean isTransferSender, boolean isDeconsolidationSender, TemporaryStorageDeclaration tsd) {
    if (isDeconsolidationSender) {
      return tsd.getDeconsolidationNotification().getMessageInformation();
    }
    return isTransferSender
        ? tsd.getTransferNotification().getMessageInformation()
        : tsd.getMessageInformation();
  }

  public void sendRejectMessage(
      TemporaryStorageDeclaration declaration,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations,
      BusinessValidationType busValidationType) {
    TSDRejectMessage rejectMessage =
        TSDRejectMessage.builder()
            .messageHeader(buildHeader(declaration.getMessageInformation()))
            .declaration(declaration)
            .businessValidationType(busValidationType)
            .notificationDate(Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime())
            .error(
                buildErrors(
                    violations,
                    declaration.getMessageInformation().getLanguageCode(),
                    false,
                    false))
            .build();
    eoNotificationGateway.sendMessage(rejectMessage);
  }

  public void sendActivationNotification(
      TemporaryStorageDeclaration declaration,
      TSDActivationRequest activationRequest,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    TSDActivationNotification activationNotification =
        TSDActivationNotification.builder()
            .notificationDate(dateUtil.getCurentSystemDate())
            .messageHeader(buildHeader(declaration.getMessageInformation()))
            .declaration(declaration)
            .linkedPnFrn(
                activationRequest == null
                    ? declaration.getLinkedPnFrn()
                    : activationRequest.getFrn())
            .customsOfficeOfPresentation(
                activationRequest == null
                    ? declaration.getCustomsOfficeOfPresentation()
                    : activationRequest.getCustomsOfficeOfPresentation())
            .dateAndTimeOfPresentationOfTheGoods(
                activationRequest == null
                    ? declaration.getDateAndTimeOfPresentationOfTheGoods()
                    : activationRequest.getDateAndTimeOfPresentationOfTheGoods())
            .activationError(
                (violations != null
                        && !violations.isEmpty()
                        && declaration.getCurrentStatus() == TSDStatus.PRELODGED)
                    ? buildErrors(
                        violations,
                        declaration.getMessageInformation().getLanguageCode(),
                        true,
                        false)
                    : null)
            .build();
    eoNotificationGateway.sendMessage(activationNotification);
  }

  public <T> List<Error> buildErrors(
      Set<ConstraintViolation<T>> violations,
      String languageCode,
      boolean isActivationError,
      boolean isDeconsolidationError) {
    AtomicInteger violationSequenceNumber = new AtomicInteger(NUMERIC_ZERO);
    List<Error> errors = new ArrayList<>();
    if (null != violations) {
      errors =
          violations.stream() // we sort to be deterministic
              .sorted(
                  Comparator.<ConstraintViolation<?>, String>comparing(
                      v ->
                          v instanceof CustomViolation
                              ? ((CustomViolation<?>) v).getPath()
                                  + ((CustomViolation<?>) v).getErrorCode()
                              : v.getPropertyPath().toString()
                                  + getReasonFromMessageTemplate(v.getMessageTemplate())
                                  + v.getConstraintDescriptor()
                                      .getAnnotation()
                                      .getClass()
                                      .getName(),
                      Comparator.nullsLast(Comparator.naturalOrder())))
              .map(
                  v ->
                      createError(
                          v,
                          violationSequenceNumber.incrementAndGet(),
                          languageCode,
                          isActivationError,
                          isDeconsolidationError))
              .toList();
    }
    Set<Error> setError = new LinkedHashSet<>(errors);
    return new ArrayList<>(resetErrorSequenceNumber(setError));
  }

  private Set<Error> resetErrorSequenceNumber(Set<Error> setError) {

    Set<Error> setError1 = new LinkedHashSet<>();

    AtomicInteger counter = new AtomicInteger(1);

    for (Error error : setError) {
      Error error1 = error.toBuilder().sequenceNumber(counter.getAndIncrement()).build();
      setError1.add(error1);
    }

    return setError1;
  }

  private MessageHeader buildHeader(MessageInformation messageInformation) {
    return MessageHeader.builder()
        .sender(tsdCfg.getTsdSystemName())
        .correlationId(messageInformation.getCorrelationID())
        .recipient(messageInformation.getSender())
        .messageTimestamp(Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime())
        .refToMessageId(messageInformation.getMessageId())
        .messageId(correlationIdGenerator.generateCorrelationID())
        .languageCode(messageInformation.getLanguageCode())
        .build();
  }

  /**
   * This method is used to create ErrorRejectMessage corresponding to the provided constraint
   * violation
   *
   * @param violation instance of ConstraintViolation
   * @param violationSequenceNumber variable to store the sequence number of occurred violation
   * @return
   */
  private Error createError(
      final ConstraintViolation<?> violation,
      int violationSequenceNumber,
      String languageCode,
      boolean isActivationError,
      boolean isDeconsolidationError) {
    String path =
        violation instanceof CustomViolation
            ? returnCustomViolationPath(violation)
            : returnViolationPath(violation);
    return Error.builder()
        .sequenceNumber(violationSequenceNumber)
        .errorPointer(isActivationError ? null : formatFieldName(path, isDeconsolidationError))
        .errorCode(isActivationError ? null : ERROR_CODE)
        .errorReason(getReasonFromMessageTemplate(violation.getMessageTemplate()))
        .remarks(
            getMessage(
                getErrorCodeFromMessageTemplate(violation.getMessageTemplate()), languageCode))
        .build();
  }

  private String returnViolationPath(ConstraintViolation<?> violation) {
    return violation.getPropertyPath().toString() == null
        ? null
        : violation.getPropertyPath().toString();
  }

  private String returnCustomViolationPath(ConstraintViolation<?> violation) {
    return ((CustomViolation<?>) violation).getPath() == null
        ? null
        : ((CustomViolation<?>) violation).getPath();
  }

  /**
   * Method to format the field name to return the required property path
   *
   * @param fieldName field name that requires formatting
   * @return formatted field name
   */
  private String formatFieldName(final String fieldName, boolean isDeconsolidationError) {
    if (fieldName == null) return null;
    String formattedField = fieldName;
    if (isDeconsolidationError && formattedField.contains("declaration")) {
      formattedField = formattedField.replace("declaration.", "");
    }

    if (formattedField.contains("consignmentHeader")) {
      formattedField = formatConsignmentHeader(formattedField);
    } else if (formattedField.contains("houseConsignments")) {
      formattedField = formatHouseConsignment(formattedField);
    } else if (formattedField.contains("masterConsignment")) {
      formattedField = formatMasterConsignment(formattedField);
    } else if (formattedField.contains(CONSIGNMENT_LOCATION_OF_GOODS)) {
      formattedField = formatConsignmentLocationOfGoods(formattedField);
    }

    return formattedField;
  }

  private String formatMasterConsignment(String formattedField) {
    formattedField =
        formattedField.replace(
            "masterConsignment", "consignmentHeaderMasterLevel.consignmentMasterLevel");
    if (formattedField.contains(CONSIGNMENT_ITEM)) {
      formattedField = formattedField.replace(CONSIGNMENT_ITEM, "consignmentItemMasterLevel");
    }

    if (formattedField.contains(GROSS_MASS)) {
      formattedField = formattedField.replace(GROSS_MASS, "weight.grossMass");
    }
    return formattedField;
  }

  private String formatHouseConsignment(String formattedField) {
    formattedField =
        formattedField.replace(
            "houseConsignments", "consignmentHeaderMasterLevel.consignmentHouseLevel");
    if (formattedField.contains(CONSIGNMENT_ITEM)) {
      formattedField = formattedField.replace(CONSIGNMENT_ITEM, "consignmentItemHouseLevel");
    }

    if (formattedField.contains(GROSS_MASS)) {
      formattedField = formattedField.replace(GROSS_MASS, "weight.grossMass");
    }
    return formattedField;
  }

  private String formatConsignmentHeader(String formattedField) {
    formattedField = formattedField.replace("consignmentHeader", "consignmentHeaderMasterLevel");
    if (formattedField.contains("decalaredlocationOfGoods")) {
      formattedField = formattedField.replace("decalaredlocationOfGoods", LOCATION_OF_GOODS);
    }
    if (formattedField.contains("presentedlocationOfGoods")) {
      formattedField = formattedField.replace("presentedlocationOfGoods", LOCATION_OF_GOODS);
    }
    return formattedField;
  }

  private String formatConsignmentLocationOfGoods(String formattedField) {
    if (formattedField.contains("supervisingCustomsOffice")) {
      formattedField = formattedField.replace("consignmentLocationOfGoods.", "");
    }
    if (formattedField.contains(CONSIGNMENT_LOCATION_OF_GOODS)) {
      formattedField =
          formattedField.replace(CONSIGNMENT_LOCATION_OF_GOODS, "consignmentHeaderMasterLevel");
    }
    if (formattedField.contains("transferredLocationOfGoods")) {
      formattedField = formattedField.replace("transferredLocationOfGoods", LOCATION_OF_GOODS);
    }
    return formattedField;
  }

  /**
   * @param messageTemplate
   * @return
   */
  private String getReasonFromMessageTemplate(String messageTemplate) {
    String errorCode = messageTemplate.replace("{error.", "");
    errorCode = errorCode.replace("}", "");
    errorCode = errorCode.replace(XX, tsdCfg.getCountryCode());
    return errorCode.substring(errorCode.length() - 7);
  }

  /**
   * @param messageTemplate
   * @return
   */
  private String getErrorCodeFromMessageTemplate(String messageTemplate) {
    String errorCode = messageTemplate.replace("{", "");
    errorCode = errorCode.replace("}", "");
    return errorCode;
  }

  private String getMessage(String code, String languageCode) {

    if (StringUtils.isNotEmpty(languageCode))
      return messageSourceAccessor.getMessage(code, new Locale(languageCode.toLowerCase()));
    else return messageSourceAccessor.getMessage(code, "en");
  }

  /**
   * builds the invalidation refused message and sends the message on the EO Notification Gateway
   *
   * @param mrn
   * @param invalidationRequest
   * @param violations
   * @param tsdPresent
   */
  public void sendInvalidationRefusedMessage(
      String crn,
      InvalidationRequest invalidationRequest,
      Set<ConstraintViolation<InvalidationRequest>> violations,
      boolean tsdPresent) {
    TSDInvalidationRefusedMessage rejectMessage =
        TSDInvalidationRefusedMessage.builder()
            .messageHeader(buildHeader(invalidationRequest.getMessageInformation()))
            .crn(crn)
            .notificationDate(
                DateTimeFormatter.ofPattern(MESSAGE_DATE_TIME_FORMAT)
                    .format(Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime()))
            .businessValidationType(BusinessValidationType.TSD_INVALIDATION_REQUEST)
            .declarant(invalidationRequest.getDeclarant())
            .representative(invalidationRequest.getRepresentative())
            .declaration(invalidationRequest.getDeclaration())
            .error(
                buildErrors(
                    violations,
                    invalidationRequest.getMessageInformation().getLanguageCode(),
                    false,
                    false))
            .build();
    eoNotificationGateway.sendMessage(rejectMessage, tsdPresent);
  }

  /**
   * builds the invalidation notification and sends the notification on the EO Notification Gateway
   *
   * @param mrn
   * @param invalidationRequest
   * @param declaration
   * @param statusHistory
   * @param reason
   */
  public void sendInvalidationNotification(
      String crn,
      InvalidationRequest invalidationRequest,
      TemporaryStorageDeclaration declaration,
      StatusHistory statusHistory,
      StatusHistoryReason reason) {

    TSDInvalidationNotification invalidationNotification =
        TSDInvalidationNotification.builder()
            .messageHeader(
                buildHeader(
                    reason == REQUEST
                        ? invalidationRequest.getMessageInformation()
                        : declaration.getMessageInformation()))
            .crn(crn)
            .invalidationInitiatedByCustoms(reason == REQUEST ? 0 : 1)
            .notificationDate(
                DateTimeFormatter.ofPattern(MESSAGE_DATE_TIME_FORMAT)
                    .format(statusHistory.getTimestamp()))
            .declarant(
                reason == REQUEST ? invalidationRequest.getDeclarant() : declaration.getDeclarant())
            .representative(
                reason == REQUEST
                    ? invalidationRequest.getRepresentative()
                    : declaration.getRepresentative())
            .declaration(declaration)
            .build();
    eoNotificationGateway.sendMessage(invalidationNotification);
  }

  public void sendTransferNotificationAcceptedMessage(
      String mrn,
      TransferNotification transferNotification,
      TemporaryStorageDeclaration declaration) {
    TSDTransferNotificationAcceptMessage tsdTransferNotificationAcceptMessage =
        TSDTransferNotificationAcceptMessage.builder()
            .messageHeader(buildHeader(transferNotification.getMessageInformation()))
            .lrn(transferNotification.getLrn())
            .mrn(mrn)
            .notificationDate(Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime())
            .businessValidationType(BusinessValidationType.TSD_TRANSFER_NOTIFICATION)
            .status(TSDStatus.ACCEPTED)
            .declarant(transferNotification.getDeclarant())
            .representative(transferNotification.getRepresentative())
            .supervisingCustomsOffice(
                transferNotification.getConsignmentLocationOfGoods().getSupervisingCustomsOffice())
            .declaration(declaration)
            .build();
    eoNotificationGateway.sendMessage(tsdTransferNotificationAcceptMessage);
  }

  public void sendTransferNotificationRefusedMessage(
      String mrn,
      TransferNotification transferNotification,
      List<Error> errors,
      TemporaryStorageDeclaration declaration) {

    TSDTransferNotificationRefusedMessage tsdTransferNotificationRefusedMessage =
        TSDTransferNotificationRefusedMessage.builder()
            .messageHeader(buildHeader(transferNotification.getMessageInformation()))
            .lrn(transferNotification.getLrn())
            .mrn(mrn)
            .notificationDate(Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime())
            .businessValidationType(BusinessValidationType.TSD_TRANSFER_NOTIFICATION)
            .declarant(transferNotification.getDeclarant())
            .representative(transferNotification.getRepresentative())
            .supervisingCustomsOffice(
                transferNotification.getConsignmentLocationOfGoods().getSupervisingCustomsOffice())
            .error(errors)
            .declaration(declaration)
            .build();

    eoNotificationGateway.sendMessage(tsdTransferNotificationRefusedMessage);
  }

  public void sendDeconsolidationNotificationRefusedMessage(
      String mrn,
      DeconsolidationNotification deconsolidationNotification,
      List<Error> errors,
      TemporaryStorageDeclaration currentTSD) {

    TSDDeconsolidationNotificationRefusedMessage tsdDeconsolidationNotificationRefusedMessage =
        TSDDeconsolidationNotificationRefusedMessage.builder()
            .messageHeader(buildHeader(deconsolidationNotification.getMessageInformation()))
            .mrn(mrn)
            .lrn(deconsolidationNotification.getLrn())
            .declarant(deconsolidationNotification.getDeclarant())
            .representative(deconsolidationNotification.getRepresentative())
            .notificationDate(Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime())
            .supervisingCustomsOffice(buildSupervisingCustomsOffice(currentTSD))
            .error(errors)
            .declaration(currentTSD)
            .businessValidationType(BusinessValidationType.TSD_DECONSOLIDATION_NOTIFICATION)
            .build();

    eoNotificationGateway.sendMessage(tsdDeconsolidationNotificationRefusedMessage);
  }

  public void sendDeconsolidationNotificationAcceptedMessage(
      String mrn,
      DeconsolidationNotification deconsolidationNotification,
      TemporaryStorageDeclaration declaration) {

    TSDDeconsolidationNotificationAcceptMessage tsdDeconsolidaionNotificationAcceptMessage =
        TSDDeconsolidationNotificationAcceptMessage.builder()
            .messageHeader(buildHeader(deconsolidationNotification.getMessageInformation()))
            .lrn(deconsolidationNotification.getLrn())
            .mrn(mrn)
            .notificationDate(Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime())
            .businessValidationType(BusinessValidationType.TSD_DECONSOLIDATION_NOTIFICATION)
            .status(TSDStatus.ACCEPTED)
            .temporaryStorageExpirationTimestamp(
                declaration.getTemporaryStorageExpirationTimestamp())
            .declarant(deconsolidationNotification.getDeclarant())
            .representative(deconsolidationNotification.getRepresentative())
            .supervisingCustomsOffice(buildSupervisingCustomsOffice(declaration))
            .declaration(declaration)
            .build();

    eoNotificationGateway.sendMessage(tsdDeconsolidaionNotificationAcceptMessage);
  }

  private CustomsOffice buildSupervisingCustomsOffice(TemporaryStorageDeclaration declaration) {

    if (null == declaration) {
      return null;
    }

    return Optional.ofNullable(declaration)
        .map(TemporaryStorageDeclaration::getMasterConsignment)
        .map(MasterConsignment::getCurrentConsignmentLocationOfGoods)
        .map(ConsignmentLocationOfGoods::getSupervisingCustomsOffice)
        .orElse(declaration.getSupervisingCustomsOffice());
  }

  public void sendAmendmentRejectMessage(
      TemporaryStorageDeclaration amendedDeclaration,
      TemporaryStorageDeclaration currentDeclaration,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations,
      BusinessValidationType busValidationType,
      boolean registerMessageExchange) {
    TSDAmendmentRejectMessage rejectMessage =
        TSDAmendmentRejectMessage.builder()
            .messageHeader(buildHeader(amendedDeclaration.getMessageInformation()))
            .amendedDeclaration(amendedDeclaration)
            .currentDeclaraton(currentDeclaration)
            .businessValidationType(busValidationType)
            .notificationDate(Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime())
            .error(
                buildErrors(
                    violations,
                    amendedDeclaration.getMessageInformation().getLanguageCode(),
                    false,
                    false))
            .build();
    eoNotificationGateway.sendMessage(rejectMessage, registerMessageExchange);
  }
}
