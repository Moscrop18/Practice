/*
 * @(#)be.fgov.minfin.tsd.domain.converter.RiskAndControlStatusHistoryReasonConverter.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.converter;

import be.fgov.minfin.tsd.domain.model.risk.RiskAndControlStatusHistoryReason;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter(autoApply = true)
public class RiskAndControlStatusHistoryReasonConverter
    implements AttributeConverter<RiskAndControlStatusHistoryReason, Integer> {

  @Override
  public Integer convertToDatabaseColumn(RiskAndControlStatusHistoryReason status) {
    if (status != null) {
      return status.getValue();
    }
    return null;
  }

  @Override
  public RiskAndControlStatusHistoryReason convertToEntityAttribute(Integer dbData) {

    if (dbData == null) {
      return null;
    }
    for (RiskAndControlStatusHistoryReason nodeType : RiskAndControlStatusHistoryReason.values()) {
      if (nodeType.getValue().equals(dbData)) {
        return nodeType;
      }
    }
    throw new IllegalArgumentException("Unknown database value:" + dbData);
  }
}
