/*
 * @(#) be.fgov.minfin.tsd.domain.validation.validator.AddressValidator.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation.validator;

import be.fgov.minfin.libdoa.csrd2.gateway.ReferenceDataGateway;
import be.fgov.minfin.tsd.domain.model.consignment.Address;
import be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;

public class AddressValidator extends BaseConstraintValidator
    implements ConstraintValidator<ValidateBusinessRules, Address> {

  private static final String POST_CODE = "postCode";
  @Autowired private ReferenceDataGateway referenceDataGateway;

  @Override
  public boolean isValid(Address address, ConstraintValidatorContext context) {
    boolean isValid = true;
    if ((!StringUtils.hasText(address.getCountry())
            || null
                == referenceDataGateway
                    .getPostCodeDatalevelForCountryCode()
                    .get(address.getCountry())
            || !referenceDataGateway
                .getPostCodeDatalevelForCountryCode()
                .get(address.getCountry())
                .equals("C"))
        && !StringUtils.hasText(address.getPostCode())) {
      addViolation(context, ErrorCode.TSPNESXXC0007, POST_CODE);
      isValid = false;
    }
    return isValid;
  }
}
