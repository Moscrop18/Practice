/*
 * @(#)be.fgov.minfin.tsd.domain.model.AmendmentRequestStatus.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model;

import com.fasterxml.jackson.annotation.JsonValue;

public enum AmendmentRequestStatus {
  APPROVED("01"),
  REFUSED("02");
  private String value;
  private Integer code;

  AmendmentRequestStatus(String newValue) {
    value = newValue;
    code = Integer.parseInt(newValue);
  }

  @JsonValue
  public String getValue() {
    return value;
  }

  public Integer getCode() {
    return code;
  }
}
