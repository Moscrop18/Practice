package be.fgov.minfin.tsd.domain.model;

import be.fgov.minfin.tsd.domain.converter.ReferenceNumberMetadata;
import javax.persistence.Transient;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@EqualsAndHashCode(exclude = {"referenceNumberMetadata"})
public class MRN {

  private String mrnNumber;

  /**
   * The received import declaration wrapped inside this class instance so as to get the id (primary
   * key) of the declaration during persist time which is used to generate MRN <code>declaration
   * </code>
   */
  @ToString.Exclude @Transient private ReferenceNumberMetadata referenceNumberMetadata;

  public static MRN of(String mrn) {
    MRN referNumber = new MRN();
    referNumber.setMrnNumber(mrn);
    return referNumber;
  }

  public static boolean isValidMrn(String param) {
    return param.length() == 18 && param.matches("[A-Za-z0-9]+");
  }
}
