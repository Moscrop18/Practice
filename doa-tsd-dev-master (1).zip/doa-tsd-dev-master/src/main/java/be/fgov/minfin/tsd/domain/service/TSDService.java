/*
 * @(#) be.fgov.minfin.tsd.domain.service.TSDService.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.service;

import static be.fgov.minfin.tsd.domain.model.StatusHistoryReason.EXPIRED;
import static be.fgov.minfin.tsd.domain.model.TSDStatus.IRREGULARITY_UNDER_INVESTIGATION;
import static be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclarationType.COMBINED;
import static be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclarationType.PRELODGED;
import static be.fgov.minfin.tsd.domain.model.TimerType.RISK_ANALYSIS_RESULT;
import static be.fgov.minfin.tsd.domain.model.TimerType.TSD_DRAFT_EXPIRATION;
import static be.fgov.minfin.tsd.domain.model.TimerType.TSD_EXPIRATION;
import static org.apache.commons.collections4.CollectionUtils.isEmpty;
import static org.apache.commons.lang3.StringUtils.isNumeric;

import be.fgov.minfin.libdoa.commons.lang.Now;
import be.fgov.minfin.libdoa.goods.accounting.client.api.owd.LockOffwritableDocumentStatusReason;
import be.fgov.minfin.libdoa.pagination.CursorPageable;
import be.fgov.minfin.libdoa.pagination.types.DateIdCursor;
import be.fgov.minfin.shared.tracing.Traced;
import be.fgov.minfin.tsd.config.TSDConfig;
import be.fgov.minfin.tsd.domain.model.BusinessValidationType;
import be.fgov.minfin.tsd.domain.model.CRN;
import be.fgov.minfin.tsd.domain.model.MRN;
import be.fgov.minfin.tsd.domain.model.MessageInformation;
import be.fgov.minfin.tsd.domain.model.ReferenceNumber;
import be.fgov.minfin.tsd.domain.model.TSDDraftTimerProjection;
import be.fgov.minfin.tsd.domain.model.TSDStatus;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclarationFilter;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclarationProjection;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclarationType;
import be.fgov.minfin.tsd.domain.model.Timer;
import be.fgov.minfin.tsd.domain.model.TimerType;
import be.fgov.minfin.tsd.domain.model.consignment.LocationOfGoods;
import be.fgov.minfin.tsd.domain.model.party.Party;
import be.fgov.minfin.tsd.domain.model.risk.RiskAndControlStatus;
import be.fgov.minfin.tsd.domain.model.risk.RiskAndControlStatusHistoryReason;
import be.fgov.minfin.tsd.domain.repository.TSDRepository;
import be.fgov.minfin.tsd.domain.sender.TSDResponseSender;
import be.fgov.minfin.tsd.domain.validation.CustomViolation;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import be.fgov.minfin.tsd.domain.validation.plugin.AmendmentValidatorPlugin;
import be.fgov.minfin.tsd.domain.validation.plugin.TSDValidatorPlugin;
import be.fgov.minfin.tsd.event.TSDEventBroker;
import be.fgov.minfin.tsd.event.api.TSDReceivedEvent;
import be.fgov.minfin.tsd.gateway.ens.exception.ReuseFailedException;
import be.fgov.minfin.tsd.gateway.ga.GoodsAccountingGateway;
import be.fgov.minfin.tsd.gateway.pn.PNGateway;
import be.fgov.minfin.tsd.gateway.risk.RiskAnalysisGateway;
import be.fgov.minfin.tsd.resource.builder.ConsignmentBuilder;
import be.fgov.minfin.tsd.resource.generator.CorrelationIdGenerator;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.ws.rs.NotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.context.annotation.DependsOn;
import org.springframework.data.domain.Slice;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * This is service layer for functionality related to TSD
 *
 * @author GauravMitra
 */
@Service
@RequiredArgsConstructor
@Slf4j
@DependsOn({"gatewayConfig"})
public class TSDService {

  private final ENSReuser ensReuser;
  private final TSDTimerService timerService;
  private final InvalidationService invalidationService;

  private final TSDRepository repository;

  private final TSDConfig tsdConfig;
  private final TSDEventBroker eventBroker;
  private final TSDResponseSender tsdResponseSender;
  private final PNGateway pnGateway;
  private final RiskAnalysisGateway riskAnalysisGateway;
  private final TSDValidatorPlugin tsdValidator;
  private final AmendmentValidatorPlugin amendmentValidator;
  private final CorrelationIdGenerator correlationIdGenerator;

  private final PartyDetailsLoader partyLoader;
  private final ConsignmentBuilder consignmentBuilder;
  private final TSDConfig tsdCfg;
  private final GoodsAccountingGateway gaGateway;
  public static final String XX = "XX";
  public static final String ERROR_LOG =
      "Processing of invalid Risk analysis result timer with reference: {} . Following errors were detected: {}";

  /**
   * This method is used to send TSDReceived event in a queue for further processing
   *
   * @param declaration
   */
  @Traced
  public void receiveDeclaration(final TemporaryStorageDeclaration declaration) {
    TSDReceivedEvent tsdReceivedEvent = TSDReceivedEvent.builder().declaration(declaration).build();
    log.info(
        "declaration  received in service with lrn and correlation id {} {}",
        declaration.getLrn(),
        declaration.getMessageInformation().getCorrelationID());
    eventBroker.publishTSDReceivedEvent(tsdReceivedEvent);
  }

  /**
   * @param declaration
   */
  @Traced
  public void processDeclaration(TemporaryStorageDeclaration declaration) {
    log.info("Declaration rcieved in service with lrn {}", declaration.getLrn());

    if (declaration.isEnsReuseRequested()) {
      log.info(
          "In method Process Declaration EnsReuseIndicatoron on with value of {}",
          declaration.getEnsReUseIndicator());

      try {
        ensReuser.prefillTSDFromENSes(declaration);
      } catch (ReuseFailedException e) {
        log.debug(e.getMessage());
        Set<ConstraintViolation<TemporaryStorageDeclaration>> violations =
            e.toConstraintViolation();
        rejectDeclaration(declaration, violations);
        return;
      }
    }
    loadDeclarantAndRepresentativeDetails(declaration);
    prefillName(declaration);
    // Trigger business validation
    Set<ConstraintViolation<TemporaryStorageDeclaration>> violations =
        tsdValidator.validateTSD(declaration);
    if (violations.isEmpty()) {
      acceptDeclaration(declaration);
    } else {
      rejectDeclaration(declaration, violations);
    }
  }

  /**
   * This method is for validation of Draft tsd both current and amended version
   *
   * @param tsd
   */
  public Optional<TemporaryStorageDeclaration> validateAndPrefillDeclaration(
      TemporaryStorageDeclaration tsd) {

    Set<ConstraintViolation<TemporaryStorageDeclaration>> violations =
        tsdValidator.validateTSDFormat(tsd);
    if (!violations.isEmpty()) {
      throw new ConstraintViolationException(violations);
    }

    loadDeclarantAndRepresentativeDetails(tsd);
    prefillName(tsd);

    if (tsd.isEnsReuseRequested()) {

      fillENSReuse(tsd);
    }
    if (tsd.getCurrentVersion() == 1) {

      Set<ConstraintViolation<TemporaryStorageDeclaration>> violationsBus =
          tsdValidator.validateTSD(tsd);
      if (!violationsBus.isEmpty()) {
        throw new ConstraintViolationException(violationsBus);
      }
    } else {
      return Optional.of(validateDraftAmendment(tsd));
    }
    return Optional.empty();
  }

  /**
   * Call to amendment validator to validate draft amendment
   *
   * @param tsd
   * @param currentTSD
   */
  private TemporaryStorageDeclaration validateDraftAmendment(TemporaryStorageDeclaration tsd) {
    TemporaryStorageDeclaration currentTSD = getCurrentVersionTSD(tsd);
    if (null != currentTSD) {
      List<Integer> versions =
          repository.listVersionsTSD(currentTSD.getReferenceNumber().getCrn(), TSDStatus.DRAFT);
      tsd.checkDraftAmendmentStillValid(currentTSD, versions);
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violationsDraft =
          amendmentValidator.validateAmendmentRequestCanBeProcessed(tsd, currentTSD);
      if (!violationsDraft.isEmpty()) {
        throw new ConstraintViolationException(violationsDraft);
      }
      violationsDraft = amendmentValidator.validateAmendment(tsd, currentTSD);
      if (!violationsDraft.isEmpty()) {
        throw new ConstraintViolationException(violationsDraft);
      } else {
        sendLockOffwritableDocumentRequest(violationsDraft, currentTSD);
      }

      boolean isManualProcessReq =
          amendmentValidator.doesAmendmentRequireManualApproval(tsd, currentTSD);
      if (isManualProcessReq) {
        tsd.setCurrentStatus(IRREGULARITY_UNDER_INVESTIGATION);
      }
    }

    return currentTSD;
  }

  private void sendLockOffwritableDocumentRequest(
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations,
      TemporaryStorageDeclaration currentTSD) {
    if (currentTSD != null && currentTSD.getLinkedPnFrn() != null) {
      // send request for IEGA904 lockOffwritableDocumentForAmendment
      violations =
          gaGateway.lockOffwritableDocument(
              currentTSD.getTransferNotification(),
              currentTSD.getReferenceNumber().getMrn().getMrnNumber(),
              LockOffwritableDocumentStatusReason.AMENDMENT);
    }

    if (!violations.isEmpty()) {
      throw new ConstraintViolationException(violations);
    }
  }

  /**
   * Fill Ens REUSE and in case of exception throw constrain violation
   *
   * @param tsd
   */
  private void fillENSReuse(TemporaryStorageDeclaration tsd) {
    log.info(
        "In method fillENSReuse  Declaration EnsReuseIndicatoron on with value of {}",
        tsd.getEnsReUseIndicator());

    try {

      ensReuser.prefillTSDFromENSes(tsd);
    } catch (ReuseFailedException e) {
      log.debug(e.getMessage());
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violationEns =
          e.toConstraintViolation();

      throw new ConstraintViolationException(violationEns);
    }
  }

  /**
   * This method is for Submit Draft tsd both current and amended version
   *
   * @param tsd
   */
  public void sumbitDraftDeclaration(TemporaryStorageDeclaration tsd) {

    Optional<TemporaryStorageDeclaration> currentTSDOptional = validateAndPrefillDeclaration(tsd);
    if (tsd.getCurrentVersion() == 1) {
      // Submit combined and PreLodge
      saveCombinedAndPrelodgeDeclaration(tsd);

    } else { // Submit draft amendment
      saveAmendment(tsd, currentTSDOptional);
    }
    // Setting consignment type and item type
    tsd.updateConsignmentTypeAndItemType();
    tsd.setMessageInformation(
        MessageInformation.buildMessageInformation(correlationIdGenerator.generateCorrelationID()));
    if (tsd.getCurrentStatus() != TSDStatus.PRELODGED) gaGateway.sendOffWritableDocument(tsd);
    // Removal of draft removal timer
    timerService.stopExpirationTimer(tsd.getId().toString(), TSD_DRAFT_EXPIRATION);
  }

  private void saveCombinedAndPrelodgeDeclaration(TemporaryStorageDeclaration tsd) {

    if (null != tsd.getType() && tsd.getType() == COMBINED) {
      pnGateway.registerPN(tsd);
      if (tsd.getLinkedPnFrn() == null) {
        CustomViolation<TemporaryStorageDeclaration> violation =
            new CustomViolation<>(ErrorCode.TSPNESXXT0004, null);
        Set<ConstraintViolation<TemporaryStorageDeclaration>> violations = new HashSet<>();
        violations.add(violation);
        throw new ConstraintViolationException(violations);
      }
      tsd.getConsignmentHeader()
          .setPresentedlocationOfGoods(
              new LocationOfGoods(tsd.getConsignmentHeader().getDecalaredlocationOfGoods()));
    }
    tsd.completeNewDeclaration();

    if (tsd.getType() == PRELODGED) {

      // creation of timer
      LocalDateTime expirationTimestamp = calculateExpirationTimestamp(TimerType.TSD_EXPIRATION);
      tsd.setExpirationTimestamp(expirationTimestamp);
    }
    tsd = repository.save(tsd);
    // Without flush crn is not generating which is required in latest step.
    repository.flush();
    if (tsd.getType() == PRELODGED) {

      timerService.createExpirationTimer(
          tsd.getExpirationTimestamp(),
          tsd.getReferenceNumber().getCrn().getCrnNumber(),
          TimerType.TSD_EXPIRATION);
    }
    if (tsd.getType() == COMBINED) {
      tsd.maximumExpirationTimestamp();
      pnGateway.linkPN(tsd);
    }

    LocalDateTime awaitingRiskResultHours =
        calculateExpirationTimestamp(TimerType.RISK_ANALYSIS_RESULT);
    if (tsd.getType() == COMBINED && awaitingRiskResultHours != null) {
      timerService.createExpirationTimer(
          awaitingRiskResultHours,
          tsd.getReferenceNumber().getCrn().getCrnNumber(),
          TimerType.RISK_ANALYSIS_RESULT);
    }

    tsd.addRiskAnalysisAndHistory(
        awaitingRiskResultHours, RiskAndControlStatus.AWAITING_RISK_ANALYSIS_RESULT);
    riskAnalysisGateway.sendTSDToRiskAnalysis(tsd, false, false);
  }

  /**
   * Call To save amendment in DB
   *
   * @param tsd
   */
  private void saveAmendment(
      TemporaryStorageDeclaration tsd, Optional<TemporaryStorageDeclaration> currentTSD) {
    if (currentTSD.isPresent()) {
      tsd.copyAmendmentAttributes(currentTSD.get(), new ArrayList<>());
    }
    tsd.getReferenceNumber().setDeclaration(tsd);
    tsd.getReferenceNumber().setDraftAmendmentId(null);
    tsd = repository.save(tsd);
    LocalDateTime awaitingRiskResultHours =
        calculateExpirationTimestamp(TimerType.RISK_ANALYSIS_RESULT);
    if ((tsd.getType() == COMBINED
            || (tsd.getType() == PRELODGED && tsd.getCurrentStatus() == TSDStatus.ACCEPTED))
        && awaitingRiskResultHours != null
        && currentTSD.isPresent()) {
      timerService.stopExpirationTimer(
          currentTSD.get().getReferenceNumber().getCrn().getCrnNumber(),
          TimerType.RISK_ANALYSIS_RESULT);
      timerService.createExpirationTimer(
          awaitingRiskResultHours,
          tsd.getReferenceNumber().getCrn().getCrnNumber(),
          TimerType.RISK_ANALYSIS_RESULT);
    }

    tsd.addRiskAnalysisAndHistory(
        awaitingRiskResultHours, RiskAndControlStatus.AWAITING_RISK_ANALYSIS_RESULT);
    riskAnalysisGateway.sendTSDToRiskAnalysis(tsd, true, false);
  }

  /**
   * Get Curent version of TSD
   *
   * @param tsd
   * @return
   */
  private TemporaryStorageDeclaration getCurrentVersionTSD(TemporaryStorageDeclaration tsd) {

    Optional<TemporaryStorageDeclaration> optionalTsd = Optional.empty();
    if (tsd.getCurrentVersion() != 1) {
      if (!tsd.getReferenceNumber().isMrnBlank()) {
        optionalTsd = repository.findCurrentVersion(tsd.getReferenceNumber().getMrn());
      } else {
        optionalTsd = repository.findCurrentVersion(tsd.getReferenceNumber().getCrn());
      }
    }

    return optionalTsd.isPresent() ? optionalTsd.get() : null;
  }

  /**
   * This method handle accept declaration
   *
   * @param tsd
   */
  @Traced
  public void acceptDeclaration(TemporaryStorageDeclaration tsd) {
    if (null != tsd.getType() && tsd.getType() == COMBINED) {
      pnGateway.registerPN(tsd);
      if (tsd.getLinkedPnFrn() == null) {
        CustomViolation<TemporaryStorageDeclaration> violation =
            new CustomViolation<>(ErrorCode.TSPNESXXT0004, null);
        Set<ConstraintViolation<TemporaryStorageDeclaration>> violations = new HashSet<>();
        violations.add(violation);
        tsdResponseSender.sendRejectMessage(tsd, violations, BusinessValidationType.COMBINED_TSD);
        return;
      }
    }
    tsd.completeNewDeclaration();

    if (tsd.getType() == PRELODGED) {

      // creation of timer
      LocalDateTime expirationTimestamp = calculateExpirationTimestamp(TimerType.TSD_EXPIRATION);
      tsd.setExpirationTimestamp(expirationTimestamp);
    }
    // Setting consignment type and item type
    tsd.updateConsignmentTypeAndItemType();
    tsd = repository.save(tsd);

    if (tsd.getType() == PRELODGED) {
      // TODO to find a better way to do it
      timerService.createExpirationTimer(
          tsd.getExpirationTimestamp(),
          tsd.getReferenceNumber().getCrn().getCrnNumber(),
          TimerType.TSD_EXPIRATION);
    }
    if (tsd.getType() == COMBINED) {
      tsd.maximumExpirationTimestamp();
    }

    // Sending of acceptance message

    tsdResponseSender.sendAcceptMessage(
        tsd,
        tsd.getType() == TemporaryStorageDeclarationType.COMBINED
            ? BusinessValidationType.COMBINED_TSD
            : BusinessValidationType.PRELODGED_TSD);

    LocalDateTime awaitingRiskResultHours =
        calculateExpirationTimestamp(TimerType.RISK_ANALYSIS_RESULT);
    if (tsd.getType() == COMBINED && awaitingRiskResultHours != null) {
      timerService.createRiskAnalysisResultTimer(
          awaitingRiskResultHours,
          tsd.getReferenceNumber().getCrn().getCrnNumber(),
          TimerType.RISK_ANALYSIS_RESULT);
    }

    tsd.addRiskAnalysisAndHistory(
        awaitingRiskResultHours, RiskAndControlStatus.AWAITING_RISK_ANALYSIS_RESULT);
    riskAnalysisGateway.sendTSDToRiskAnalysis(tsd, false, false);
    if (tsd.getType() == COMBINED) {
      pnGateway.linkPN(tsd);
      // trigger IEGA115
      gaGateway.sendOffWritableDocument(tsd);
    }
  }

  /**
   * This method handle reject declaration
   *
   * @param declaration
   */
  @Traced
  public void rejectDeclaration(
      TemporaryStorageDeclaration declaration,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    tsdResponseSender.sendRejectMessage(
        declaration,
        violations,
        declaration.getType() == TemporaryStorageDeclarationType.COMBINED
            ? BusinessValidationType.COMBINED_TSD
            : BusinessValidationType.PRELODGED_TSD);
  }

  /**
   * @param party
   */
  private void loadDeclarantAndRepresentativeDetails(TemporaryStorageDeclaration tsd) {
    partyLoader.loadPartyDetails(tsd.getDeclarant());
    if (null != tsd.getRepresentative()) {
      partyLoader.loadPartyDetails(tsd.getRepresentative());
    }
  }

  public void invalidateDeclaration(Timer timer) {
    CRN crn = CRN.of(timer.getReference());
    Optional<TemporaryStorageDeclaration> tsd = repository.findCurrentVersion(crn);
    if (tsd.isPresent() && tsd.get().getCurrentStatus() == TSDStatus.PRELODGED) {
      invalidationService.invalidateDeclaration(timer.getReference(), null, tsd.get(), EXPIRED);
    }
  }

  public void registerValidatedRiskAnalysisResult(
      TemporaryStorageDeclaration tsd,
      RiskAndControlStatus riskAndControlStatus,
      RiskAndControlStatusHistoryReason reason) {
    tsd.completeValidatedRiskAnalysisResult(riskAndControlStatus, reason);
  }

  public void deleteDraftDeclaration(Timer timer) {

    Optional<TemporaryStorageDeclaration> tsd = getDeclaration(timer.getReference());
    if (tsd.isPresent()) {
      boolean draftCanBeDeleted = checkDraftCanBeDeleted(tsd.get());
      if (draftCanBeDeleted && tsd.get().getCurrentStatus() == TSDStatus.DRAFT) {
        removeDeclaration(tsd.get()); // delete draft tsd
      } else { // add the timer back
        timerService.createExpirationTimer(
            tsd.get().getRegistrationDate(),
            tsd.get().getId().toString(),
            TimerType.TSD_DRAFT_EXPIRATION);
      }
    }
  }
  /**
   * this method is used to process expired risk analysis result timers
   *
   * @param timer
   */
  public void processExpiredRiskAnalysisResultTimer(Timer timer) {

    Optional<TemporaryStorageDeclaration> tsd = getDeclaration(timer.getReference());
    if (tsd.isPresent()) {
      TemporaryStorageDeclaration temporaryStorageDeclaration = tsd.get();
      List<TSDStatus> validRiskAnalysisResultStatus =
          List.of(
              TSDStatus.ACCEPTED,
              TSDStatus.IRREGULARITY_UNDER_INVESTIGATION,
              TSDStatus.MEASURES_REQUIRED,
              TSDStatus.AMENDMENT_REQUIRED);
      if (validRiskAnalysisResultStatus.contains(temporaryStorageDeclaration.getCurrentStatus())
          && RiskAndControlStatus.AWAITING_RISK_ANALYSIS_RESULT.equals(
              temporaryStorageDeclaration.getCurrentRiskControlStatus())) {

        temporaryStorageDeclaration.completeValidatedRiskAnalysisResult(
            RiskAndControlStatus.NO_RISK,
            RiskAndControlStatusHistoryReason.RISK_ANALYSIS_RESULT_TIMER);
        // implementation of US 46.02 Send GA offwritable document - status update

      } else {
        List<String> errorCodes = new ArrayList<>();
        if (!RiskAndControlStatus.AWAITING_RISK_ANALYSIS_RESULT.equals(
            temporaryStorageDeclaration.getCurrentRiskControlStatus())) {
          errorCodes.add(ErrorCode.TSPNESXXR0425.toString().replace("XX", tsdCfg.getCountryCode()));
        }
        if (!validRiskAnalysisResultStatus.contains(
            temporaryStorageDeclaration.getCurrentStatus())) {
          errorCodes.add(ErrorCode.TSPNESXXR0424.toString().replace("XX", tsdCfg.getCountryCode()));
        }

        if (CollectionUtils.isNotEmpty(errorCodes)) {
          log.error(ERROR_LOG, timer.getReference(), String.join(", ", errorCodes));
        }
      }
    } else {
      log.error(
          ERROR_LOG,
          timer.getReference(),
          ErrorCode.TSPNESXXR0459.toString().replace("XX", tsdCfg.getCountryCode()));
    }
  }

  /**
   * This method is called from resource to save DRaft tsd in DB with current version 1 and status
   * draft
   *
   * @param tsd
   * @return TemporaryStorageDeclaration
   */
  public TemporaryStorageDeclaration createDeclaration(TemporaryStorageDeclaration tsd) {
    tsd.completeDraftDeclaration();
    // TODO to change when security is implemented
    if (null == tsd.getDeclarant()) {
      tsd.setDeclarant(Party.builder().identificationNumber("BE0404529392").build());
    }
    LocalDateTime expirationTimestamp =
        calculateExpirationTimestamp(TimerType.TSD_DRAFT_EXPIRATION);
    consignmentBuilder.createDummyConsignments(tsd);
    tsd = repository.save(tsd);
    timerService.createExpirationTimer(
        expirationTimestamp, tsd.getId().toString(), TimerType.TSD_DRAFT_EXPIRATION);
    return tsd;
  }

  /**
   * This method is used to get declaration based on path parameter(tsd Id which is dynamic
   * parameter can be LRN,MRN,TSDID) provided in resourc.
   *
   * @param tsdSearchParam
   * @return
   */
  public Optional<TemporaryStorageDeclaration> getDeclaration(String tsdSearchParam) {
    if (CRN.isValidCrn(tsdSearchParam)) {
      return repository.findCurrentVersion(CRN.of(tsdSearchParam));
    } else if (MRN.isValidMrn(tsdSearchParam)) {
      return repository.findCurrentVersion(MRN.of(tsdSearchParam));
    } else {
      return repository.findById(Long.valueOf(tsdSearchParam));
    }
  }

  /**
   * This method is used to get declaration based on path parameter(tsd Id which is dynamic
   * parameter can be LRN,MRN,TSDID) provided in resourc.
   *
   * @param tsdSearchParam
   * @return
   */
  public Optional<TemporaryStorageDeclaration> getDeclarationWithUIAttributes(
      String tsdSearchParam) {
    if (CRN.isValidCrn(tsdSearchParam)) {
      return repository.findCurrentVersionWithAmendmentAndExchange(CRN.of(tsdSearchParam));
    } else if (MRN.isValidMrn(tsdSearchParam)) {
      return repository.findCurrentVersionWithAmendmentAndExchange(MRN.of(tsdSearchParam));
    } else if (isNumeric(tsdSearchParam)) {
      Optional<TemporaryStorageDeclaration> tsd =
          repository.getDeclarationById(Long.valueOf(tsdSearchParam));
      if (tsd.isPresent()) {
        TemporaryStorageDeclaration declaration = tsd.get();
        if (declaration.getCurrentStatus() == TSDStatus.DRAFT
            && declaration.getCurrentVersion() > 1) {

          List<Integer> versions =
              repository.listVersionsTSD(
                  declaration.getReferenceNumber().getCrn(), TSDStatus.DRAFT);
          String linkedPNFrn =
              repository.getLinkedPnFrnCurrentVersion(declaration.getReferenceNumber().getCrn());
          declaration.checkDraftAmendmentStillValid(
              TemporaryStorageDeclaration.builder().linkedPnFrn(linkedPNFrn).build(), versions);
        }
      }
      return tsd;
    } else {
      throw new NotFoundException();
    }
  }

  public boolean checkIfCurrentTSDisTransferred(Long referenceNumberId) {
    return repository.checkIfCurrentTSDisTransferred(referenceNumberId);
  }

  /**
   * This method is used to get declaration with consignments based on path parameter(tsd Id which
   * is dynamic parameter can be LRN,MRN,TSDID) provided in resourc.
   *
   * @param tsdSearchParam
   * @return
   */
  public Optional<TemporaryStorageDeclaration> getDeclarationWithConsignments(
      String tsdSearchParam) {
    if (CRN.isValidCrn(tsdSearchParam)) {
      return repository.findDeclarationwithConsignment(CRN.of(tsdSearchParam));
    } else if (MRN.isValidMrn(tsdSearchParam)) {
      return repository.findDeclarationwithConsignment(MRN.of(tsdSearchParam));
    } else if (isNumeric(tsdSearchParam)) {
      return repository.findDeclarationwithConsignment(Long.valueOf(tsdSearchParam));
    } else {
      throw new NotFoundException();
    }
  }

  /**
   * Get id of TSD with status draft having amendmentrequest
   *
   * @param crn
   * @return
   */
  public Optional<Long> getDraftAmendmentId(CRN crn) {
    return repository.getDraftAmendmentID(crn, TSDStatus.DRAFT);
  }

  /**
   * This method is used from resource to update existing declaration
   *
   * @param declaration
   * @return TemporaryStorageDeclaration
   */
  public TemporaryStorageDeclaration modifyDeclaration(TemporaryStorageDeclaration declaration) {
    declaration.checkCanModify();
    declaration.updateRegistrationDate();
    return repository.saveAndFlush(declaration);
  }

  /**
   * Find list of tsd versions based on tsd Param
   *
   * @param tsdParam
   * @return
   */
  public List<TemporaryStorageDeclaration> findDeclarationVersions(String tsdParam) {

    if (CRN.isValidCrn(tsdParam)) {
      return repository.findByReferenceNumberCrn(CRN.of(tsdParam), TSDStatus.DRAFT);
    } else if (MRN.isValidMrn(tsdParam)) {
      return repository.findByReferenceNumberMrn(MRN.of(tsdParam), TSDStatus.DRAFT);
    } else {
      throw new NotFoundException();
    }
  }

  /**
   * This method to remove declaration
   *
   * @param declaration
   */
  public void removeDeclaration(TemporaryStorageDeclaration declaration) {
    List<Long> partysId = deleteConsignmentAndConsignmentItemLinkedToTSD(declaration.getId());
    if (null != declaration.getDeclarant()) {
      partysId.add(declaration.getDeclarant().getId());
    }
    if (null != declaration.getRepresentative()) {
      partysId.add(declaration.getRepresentative().getId());
    }
    ReferenceNumber number = declaration.getReferenceNumber();
    Long declId = declaration.getId();

    repository.deleteTimerLinkedToTsd(
        declaration.getId().toString(), TimerType.TSD_DRAFT_EXPIRATION);

    repository.deleteTSD(declaration.getId());
    repository.deleteAllCommunication(partysId);
    repository.deleteAllPartys(partysId);
    if (declaration.getCurrentVersion() == 1) {
      repository.deleteStatusHistory(number.getId());
      repository.deleteReferenceNumber(number.getId());
    } else if (declId.equals(number.getDraftAmendmentId())) {
      repository.deleteDraftAmendmentId(number.getId());
    }
    if (null != declaration.getConsignmentHeader().getDecalaredlocationOfGoods()) {
      repository.deleteLocationOfgoods(
          declaration.getConsignmentHeader().getDecalaredlocationOfGoods().getId());
    }
  }

  private List<Long> deleteConsignmentAndConsignmentItemLinkedToTSD(Long tsdId) {
    List<Long> lstPartyID = new ArrayList<>();
    repository.deleteSupportingDocumentLinkedWithTSD(tsdId);
    repository.deleteAdditionalReferenceLinkedWithTSD(tsdId);
    repository.deleteAeoAuthLinkedWithTSD(tsdId);
    repository.deleteSupplyChainActorLinkedWithTSD(tsdId);
    repository.deleteAdditionalInformationLinkedWithTSD(tsdId);
    repository.deleteSealLinkedWithTSD(tsdId);
    repository.deleteTransportEquipmentLinkedWithTSD(tsdId);
    repository.deletePackagingLinkedWithTSD(tsdId);
    repository.deleteReceptacleLinkedWithTSD(tsdId);
    repository.deleteConsignmentIteminkedWithTSD(tsdId);
    List<Long> consignors = repository.getConsignorLinkedWithTSD(tsdId);
    List<Long> consignees = repository.getConsigneeLinkedWithTSD(tsdId);
    List<Long> notifyPartys = repository.getNotifyPartyLinkedWithTSD(tsdId);
    if (!isEmpty(consignors)) {
      lstPartyID.addAll(consignors);
    }
    if (!isEmpty(consignees)) {
      lstPartyID.addAll(consignees);
    }
    if (!isEmpty(notifyPartys)) {
      lstPartyID.addAll(notifyPartys);
    }
    repository.deleteConsignmentLinkedWithTSD(tsdId);
    return lstPartyID;
  }

  /**
   * This method is used to create Timer
   *
   * @return LocalDateTime
   */
  public LocalDateTime calculateExpirationTimestamp(TimerType type) {
    if (type == TSD_EXPIRATION) {
      return Now.localDateTime()
          .plusDays(tsdConfig.getExpirationTimestampPeriod())
          .atOffset(ZoneOffset.UTC)
          .toLocalDateTime();
    } else if (type == TSD_DRAFT_EXPIRATION) {
      return Now.localDateTime()
          .plusDays(tsdConfig.getDraftTSDRemovalPeriod())
          .atOffset(ZoneOffset.UTC)
          .toLocalDateTime();
    } else if (type == RISK_ANALYSIS_RESULT
        && tsdConfig.getAwaitingRiskResultHours() != null
        && tsdConfig.getAwaitingRiskResultHours() > 0) {
      return Now.localDateTime()
          .plusHours(tsdConfig.getAwaitingRiskResultHours())
          .atOffset(ZoneOffset.UTC)
          .toLocalDateTime();
    }
    return null;
  }

  @Transactional(propagation = Propagation.REQUIRES_NEW)
  public void updateExpirationTimestampForDraftTSD() {
    List<TSDDraftTimerProjection> draftTimerProjections = repository.getTSDDraftTimerProjection();
    timerService.updateExpirationTimerForDraftTSD(draftTimerProjections);
  }

  private boolean checkDraftCanBeDeleted(TemporaryStorageDeclaration declaration) {
    LocalDateTime time =
        declaration.getRegistrationDate().plusDays(tsdConfig.getDraftTSDRemovalPeriod());
    return (time.isBefore(Now.localDateTime()) || time.isEqual(Now.localDateTime()));
  }

  // uses a filter class to return a page of
  // TemporaryStorageDeclarationProjections
  public Slice<TemporaryStorageDeclarationProjection> findTemporaryStorageDeclarationProjections(
      TemporaryStorageDeclarationFilter filter, CursorPageable<DateIdCursor> pageable) {
    if (filter.getStatus().size() > 1 && filter.getStatus().contains(TSDStatus.DRAFT)) {
      CustomViolation.doThrow(ErrorCode.TSPNESXXR0329, "status");
    }
    return repository.findTemporaryStorageDeclarationProjections(filter, pageable);
  }

  /**
   * Prefill name of party on the basis of crs data
   *
   * @param declaration
   */
  private void prefillName(TemporaryStorageDeclaration declaration) {
    if (null != declaration.getPersonPresentingTheGoods()
        && null == declaration.getPersonPresentingTheGoods().getName()) {
      declaration
          .getPersonPresentingTheGoods()
          .setName(
              getNameFromCrs(declaration.getPersonPresentingTheGoods().getIdentificationNumber()));
    }
    if (null != declaration.getConsignmentHeader().getCarrier()
        && null == declaration.getConsignmentHeader().getCarrier().getName()) {
      declaration
          .getConsignmentHeader()
          .getCarrier()
          .setName(
              getNameFromCrs(
                  declaration.getConsignmentHeader().getCarrier().getIdentificationNumber()));
    }
  }

  /**
   * get name for person and carrier
   *
   * @param identificationNumber
   * @return
   */
  private String getNameFromCrs(String identificationNumber) {
    Optional<Party> party = partyLoader.loadPartyDetails(identificationNumber);
    return party.isPresent() ? party.get().getName() : null;
  }
}
