/*
 * @(#)be.fgov.minfin.tsd.domain.service.ConsignmentService.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.service;

import static be.fgov.minfin.tsd.domain.model.ConsignmentInformationType.HOUSE;
import static be.fgov.minfin.tsd.domain.model.ConsignmentInformationType.MASTER;
import static be.fgov.minfin.tsd.domain.model.ConsignmentInformationType.MASTERANDHOUSE;
import static org.apache.commons.collections4.CollectionUtils.isEmpty;

import be.fgov.minfin.tsd.domain.model.CRN;
import be.fgov.minfin.tsd.domain.model.MRN;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.consignment.AllowedSectionsDetail;
import be.fgov.minfin.tsd.domain.model.consignment.Consignment;
import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentFilter;
import be.fgov.minfin.tsd.domain.model.consignment.ConsignmentProjection;
import be.fgov.minfin.tsd.domain.model.consignment.HouseConsignment;
import be.fgov.minfin.tsd.domain.model.consignment.ItemDraftError;
import be.fgov.minfin.tsd.domain.model.consignment.MasterConsignment;
import be.fgov.minfin.tsd.domain.repository.ConsignmentRepository;
import be.fgov.minfin.tsd.domain.repository.TSDRepository;
import be.fgov.minfin.tsd.domain.validation.CustomViolation;
import be.fgov.minfin.tsd.domain.validation.codelist.ErrorCode;
import be.fgov.minfin.tsd.resource.api.ui.ConsignmentField;
import be.fgov.minfin.tsd.resource.api.ui.RequiredField;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

/**
 * This is service layer for functionality related to Consignment
 *
 * @author MohdSalim
 */
@Service
@RequiredArgsConstructor
public class ConsignmentService {

  private static final String SEQUENCE_NUMBER = "sequenceNumber";

  private final ConsignmentRepository repository;
  private final TSDRepository tsdRepository;

  public Consignment createConsignment(
      Consignment consignment, TemporaryStorageDeclaration declaration) {
    declaration.checkCanModify();

    if (consignment instanceof MasterConsignment
        && declaration.getMasterConsignment()
            != null) { // TODO Is there a way to not load entire MasterConsignment?
      CustomViolation.doThrow(ErrorCode.TSPNESXXR0319, "type");
    }

    if (consignment instanceof MasterConsignment) {
      // linking consignment to tsd from tsd side because it is the owner of the relationship
      declaration.setMasterConsignment((MasterConsignment) consignment);
    } else {
      // custom query instead of loading all the house consignments for sequenceNumber
      Integer maxSequenceNumber =
          repository.findMaxSequenceNumberByDeclarationId(declaration.getId());
      if (maxSequenceNumber == null) {
        consignment.setSequenceNumber(Integer.valueOf(1));
      } else {
        consignment.setSequenceNumber(maxSequenceNumber + 1);
      }
      ((HouseConsignment) consignment).setDeclaration(declaration);
    }
    consignment = repository.save(consignment);
    declaration.updateRegistrationDate();
    return consignment;
  }

  public Optional<Consignment> getConsignmentForUpdate(
      Long tsdId, Integer consignmentSequenceNumber) {
    return repository.getConsignmentWithOptimisticForceIncrement(consignmentSequenceNumber, tsdId);
  }

  public Consignment modifyConsignment(Consignment consignment) {
    return repository.saveAndFlush(consignment);
  }

  public Optional<Consignment> getConsignment(String tsdId, Integer consignmentSequenceNumber) {
    if (CRN.isValidCrn(tsdId)) {
      return repository.getConsignment(consignmentSequenceNumber, null, CRN.of(tsdId), null);
    } else if (MRN.isValidMrn(tsdId)) {
      return repository.getConsignment(consignmentSequenceNumber, null, null, MRN.of(tsdId));
    } else {
      return repository.getConsignment(consignmentSequenceNumber, Long.valueOf(tsdId), null, null);
    }
  }

  public AllowedSectionsDetail calculateAllowedSections(
      String tsdId, Integer consignmentSequenceNumber, List<RequiredField> requiredfields) {
    AllowedSectionsDetail allowedSectionsDetail = null;
    if (!requiredfields.contains(RequiredField.ALLOWED_SECTIONS)) {
      return allowedSectionsDetail;
    }

    if (CRN.isValidCrn(tsdId)) {
      allowedSectionsDetail =
          repository.listSectionsOfItemsForConsignment(
              consignmentSequenceNumber, null, CRN.of(tsdId), null);
    } else if (MRN.isValidMrn(tsdId)) {
      allowedSectionsDetail =
          repository.listSectionsOfItemsForConsignment(
              consignmentSequenceNumber, null, null, MRN.of(tsdId));
    } else {
      allowedSectionsDetail =
          repository.listSectionsOfItemsForConsignment(
              consignmentSequenceNumber, Long.valueOf(tsdId), null, null);
    }
    return allowedSectionsDetail;
  }

  public void removeConsignment(Consignment consignment) {
    TemporaryStorageDeclaration declaration = consignment.getDeclaration();
    declaration.checkCanDelete();

    if (declaration.getConsignmentType() == MASTER) {
      if (consignment instanceof MasterConsignment) {
        CustomViolation.doThrow(ErrorCode.TSPNESXXR0321, SEQUENCE_NUMBER);
      } else {
        // delete house consignment without caring if it is the last house consignment
        deleteConsignment(consignment);
        repository.updateSequenceOfHouseConsignments(
            declaration.getId(), consignment.getSequenceNumber());
      }
    } else if (declaration.getConsignmentType() == HOUSE) {
      if (consignment instanceof MasterConsignment) {
        // delete master consignment
        deleteConsignment(consignment);
      } else if (repository.countHouseConsignments(declaration.getId()) == 1) {
        CustomViolation.doThrow(ErrorCode.TSPNESXXR0321, SEQUENCE_NUMBER);
      } else {
        // delete house consignment only if there are more than 1 house consignments
        deleteConsignment(consignment);
        repository.updateSequenceOfHouseConsignments(
            declaration.getId(), consignment.getSequenceNumber());
      }
    } else if (declaration.getConsignmentType() == MASTERANDHOUSE) {
      if (consignment instanceof MasterConsignment
          || repository.countHouseConsignments(declaration.getId()) == 1) {
        CustomViolation.doThrow(ErrorCode.TSPNESXXR0321, SEQUENCE_NUMBER);
      } else {
        deleteConsignment(consignment);
        // delete house consignment only if there are more than 1 house consignments
        repository.updateSequenceOfHouseConsignments(
            declaration.getId(), consignment.getSequenceNumber());
      }
    }
    declaration.updateRegistrationDate();
  }

  private void deleteConsignment(Consignment consignment) {
    repository.deleteSupportingDocumentLinkedWithConsignmentId(consignment.getId());
    repository.deleteAdditionalReferenceLinkedWithConsignmentId(consignment.getId());
    repository.deleteAeoAuthLinkedWithConsignmentId(consignment.getId());
    repository.deleteSupplyChainActorLinkedWithConsignmentId(consignment.getId());
    repository.deleteAdditionalInformationLinkedWithConsignmentId(consignment.getId());
    repository.deleteSealLinkedWithConsignmentId(consignment.getId());
    repository.deleteTransportEquipmentLinkedWithConsignmentId(consignment.getId());
    repository.deletePackagingLinkedWithConsignmentId(consignment.getId());
    repository.deleteReceptacleLinkedWithConsignmentId(consignment.getId());
    repository.deleteConsignmentItemLinkedWithConsignmentId(consignment.getId());
    List<Long> lstPartyID = new ArrayList<>();
    List<Long> consignors = repository.getConsignorLinkedWithConsignmentId(consignment.getId());
    List<Long> consignees = repository.getConsigneeLinkedWithConsignmentId(consignment.getId());
    List<Long> notifyPartys = repository.getNotifyPartyLinkedWithConsignmentId(consignment.getId());
    if (!isEmpty(consignors)) {
      lstPartyID.addAll(consignors);
    }
    if (!isEmpty(consignees)) {
      lstPartyID.addAll(consignees);
    }
    if (!isEmpty(notifyPartys)) {
      lstPartyID.addAll(notifyPartys);
    }
    repository.deleteConsignment(consignment.getId());
    repository.deleteAllCommunication(lstPartyID);
    repository.deleteAllPartys(lstPartyID);
  }

  public Page<ConsignmentProjection> findConsignments(
      Long tsdId, ConsignmentFilter filter, Pageable pageable) {
    List<Class<?>> requiredConsignmentTypes = filter.getRequiredConsignmentTypes();
    return repository.findConsignments(tsdId, requiredConsignmentTypes, pageable);
  }

  public List<ItemDraftError> calculateItemDraftError(
      List<ConsignmentProjection> pageData, ConsignmentFilter filter) {
    if (!filter.getFields().contains(ConsignmentField.DRAFT_ERRORS) || pageData.isEmpty()) {
      return Collections.emptyList();
    }
    List<Long> consignmentIds =
        pageData.stream().map(ConsignmentProjection::getId).collect(Collectors.toList());

    return repository.calculateItemDraftError(consignmentIds);
  }
}
