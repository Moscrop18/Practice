/*
 * @(#) be.fgov.minfin.tsd.gateway.eo.api.SendIntendedControlDTO.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.eo.api;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import java.util.List;
import lombok.Builder;
import lombok.Value;

/**
 * This class is DTO for IETS435 message
 *
 * @author MohdSalim
 */
@Value
@Builder
@JsonRootName("IETS460")
@JsonInclude(Include.NON_NULL)
public class SendIntendedControlDTO {

  private MessageHeaderDTO messageHeader;
  private String crn;
  private String mrn;
  private String notificationDate;
  private String scheduledControlDate;
  private DeclarantControlIntendedDTO declarant;
  private RepresentativeIntendedControlDTO representative;
  private PersonPresentingTheGoodsICDTO personPresentingTheGoods;
  private CustomsOfficeOfControlDTO customsOfficeOfControl;

  @JacksonXmlElementWrapper(useWrapping = false)
  private List<TypeofControlsDTO> typeOfControls;

  @JacksonXmlElementWrapper(useWrapping = false)
  private List<RequestedDocumentDTO> requestedDocument;

  @JacksonXmlElementWrapper(useWrapping = false)
  private List<ControlDTO> control;
}
