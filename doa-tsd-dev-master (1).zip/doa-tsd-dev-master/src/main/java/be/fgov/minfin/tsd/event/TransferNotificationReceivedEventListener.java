/*
 * @(#) be.fgov.minfin.tsd.event.TransferNotificationReceivedEventListener.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties
 * or made public without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.event;

import static be.fgov.minfin.tsd.event.TSDEventConfig.TSD_TRANSFER_NOTIFICATION_RECEIVED_CONCURRENCY;
import static be.fgov.minfin.tsd.event.TSDEventConfig.TSD_TRANSFER_NOTIFICATION_RECEIVED_QUEUE;

import be.fgov.minfin.libdoa.amqp.transactional.AbstractRetryingQueueListener;
import be.fgov.minfin.tsd.domain.service.TransferNotificationService;
import be.fgov.minfin.tsd.event.api.TSDTransferNotificationReceivedEvent;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Transactional
public class TransferNotificationReceivedEventListener extends AbstractRetryingQueueListener {

  public static final String LISTENER_ID = "processTransferNotification";

  private final TransferNotificationService transferNotificationService;

  public TransferNotificationReceivedEventListener(
      TSDEventConfig tsdEventConfig, TransferNotificationService transferNotificationService) {

    super(tsdEventConfig.getTsdTransferNotificationReceivedQueue());
    this.transferNotificationService = transferNotificationService;
  }

  @RabbitListener(
      id = LISTENER_ID,
      queues = TSD_TRANSFER_NOTIFICATION_RECEIVED_QUEUE,
      concurrency = TSD_TRANSFER_NOTIFICATION_RECEIVED_CONCURRENCY)
  public void processTransferNotificationEvent(
      @Payload TSDTransferNotificationReceivedEvent tsdTransferNotificationReceivedEvent,
      Message message) {

    transferNotificationService.processTransferNotification(
        tsdTransferNotificationReceivedEvent.getMrn(),
        tsdTransferNotificationReceivedEvent.getTransferNotification());
  }
}
