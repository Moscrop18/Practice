/*
 * @(#) be.fgov.minfin.tsd.domain.model.consignment.HouseConsignment
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.model.consignment;

import be.fgov.minfin.tsd.domain.model.ConsignmentLocationOfGoods;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.domain.model.party.Person;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import java.math.BigDecimal;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.Valid;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@Entity
@DiscriminatorValue("House")
public class HouseConsignment extends Consignment {
  @Builder(builderMethodName = "houseConsignmentBuilder")
  public HouseConsignment(
      Long id,
      Integer sequenceNumber,
      ConsignmentGeneralInformationDraftError generalInformationDraftError,
      ConsignmentPartiesDraftError partiesDraftError,
      PreviousDocument previousDocument,
      TransportDocument transportDocument,
      Person consignor,
      Person consignee,
      Person notifyParty,
      BigDecimal totalGrossMass,
      String referenceNumberUCR,
      List<@Valid TransportEquipment> transportEquipment,
      List<@Valid AdditionalInformation> additionalInformation,
      List<@Valid SupportingDocument> supportingDocument,
      List<@Valid AdditionalSupplyChainActor> additionalSupplyChainActor,
      List<@Valid ConsignmentItem> consignmentItem,
      List<AdditionalReference> additionalReference,
      ConsignmentLocationOfGoods currentConsignmentLocationOfGoods) {
    super(
        id,
        sequenceNumber,
        generalInformationDraftError,
        partiesDraftError,
        previousDocument,
        transportDocument,
        consignor,
        consignee,
        notifyParty,
        totalGrossMass,
        referenceNumberUCR,
        transportEquipment,
        additionalInformation,
        supportingDocument,
        additionalSupplyChainActor,
        consignmentItem,
        currentConsignmentLocationOfGoods);
    this.additionalReference = additionalReference;
  }

  @OneToMany(
      cascade = {CascadeType.PERSIST, CascadeType.MERGE},
      orphanRemoval = true,
      mappedBy = "consignment")
  @ToString.Exclude
  @JsonManagedReference(value = "consignment")
  private List<@Valid AdditionalReference> additionalReference;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "TSD_ID")
  private TemporaryStorageDeclaration declaration;

  @Override
  @JsonIgnore
  public TemporaryStorageDeclaration getDeclaration() {
    return this.declaration;
  }
}
