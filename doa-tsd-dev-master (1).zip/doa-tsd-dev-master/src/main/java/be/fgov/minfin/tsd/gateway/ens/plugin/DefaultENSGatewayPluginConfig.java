/*
 * @(#) be.fgov.minfin.tsd.gateway.pn.plugin.DefaultENSGatewayPluginConfig
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.ens.plugin;

import static be.fgov.minfin.tsd.gateway.GatewayConfig.DEFAULT_CONNECT_TIMEOUT;
import static be.fgov.minfin.tsd.gateway.GatewayConfig.DEFAULT_REQUEST_TIMEOUT;

import eu.ec.xmlns.dataservice.ics.ensconsultationds.v1.CCN2ServiceCustomsEUICSENSConsultationDS;
import eu.ec.xmlns.dataservice.ics.ensconsultationds.v1.ENSConsultationDS;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.Handler;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;

/**
 * @author MohammadFaiz
 */
@Validated
@Getter
@Setter
@Configuration
public class DefaultENSGatewayPluginConfig {
  private String url;
  private Integer connectTimeout = DEFAULT_CONNECT_TIMEOUT;
  private Integer requestTimeout = DEFAULT_REQUEST_TIMEOUT;
  private String ensWebserviceUser;
  private String ensWebservicePassword;
  private String ccnEnv;
  private String ccnFromCountry;
  private static final String REQUEST_TIMEOUT = "com.sun.xml.ws.request.timeout";
  private static final String CONNECT_TIMEOUT = "com.sun.xml.ws.connect.timeout";

  @Bean
  public ENSConsultationDS ensServiceClient() {

    URL wsdl =
        DefaultENSGatewayPluginConfig.class.getResource(
            "/wsdl/DataService/ICS/ENSConsultationDS/V1/CCN2.Service.Customs.Default.ICS.ENSConsultationDS_1.0.0_CCN2_1.0.0.wsdl");

    CCN2ServiceCustomsEUICSENSConsultationDS ccn2ServiceCustomsEUICSENSConsultationDS =
        new CCN2ServiceCustomsEUICSENSConsultationDS(wsdl);
    ENSConsultationDS ensConsultationDS =
        ccn2ServiceCustomsEUICSENSConsultationDS.getENSConsultationDS();

    Map<String, Object> requestContext = ((BindingProvider) ensConsultationDS).getRequestContext();
    requestContext.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, this.url);
    requestContext.put(CONNECT_TIMEOUT, this.connectTimeout);
    requestContext.put(REQUEST_TIMEOUT, this.requestTimeout);
    if (StringUtils.isNotEmpty(ensWebservicePassword)
        && StringUtils.isNotEmpty(ensWebserviceUser)) {
      requestContext.put(BindingProvider.USERNAME_PROPERTY, this.ensWebserviceUser);
      requestContext.put(BindingProvider.PASSWORD_PROPERTY, this.ensWebservicePassword);
    }

    @SuppressWarnings("rawtypes")
    List<Handler> handlerChain = new ArrayList<>();

    handlerChain.add(new DefaultENSReuserSoapHandler());
    ((BindingProvider) ensConsultationDS).getBinding().setHandlerChain(handlerChain);
    return ensConsultationDS;
  }
}
