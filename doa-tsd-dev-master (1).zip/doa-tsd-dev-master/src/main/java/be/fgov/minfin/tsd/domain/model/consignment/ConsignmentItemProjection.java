package be.fgov.minfin.tsd.domain.model.consignment;

import java.math.BigDecimal;

public interface ConsignmentItemProjection {

  String getGoodsItemNumber();

  BigDecimal getGrossMass();

  Commodity getCommodity();

  interface Commodity {
    String getDescriptionOfGoods();

    String getCusCode();

    CommodityCode getCommodityCode();
  }

  interface CommodityCode {
    String getHarmonizedSystemSubHeadingCode();

    String getCombinedNomenclatureCode();
  }

  ConsignmentItemDraftError getDraftError();
}
