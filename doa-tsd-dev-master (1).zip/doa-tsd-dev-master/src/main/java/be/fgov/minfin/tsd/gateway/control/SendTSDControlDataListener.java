/*
 * @(#) be.fgov.minfin.tsd.gateway.control.SendTSDControlDataListener
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.control;

import static be.fgov.minfin.tsd.gateway.control.ControlGatewayConfig.CONCURRENCY_INV_VALUE;
import static be.fgov.minfin.tsd.gateway.control.ControlGatewayConfig.CONTROL_INV_QUEUE;

import be.fgov.minfin.libdoa.amqp.transactional.AbstractRetryingQueueListener;
import be.fgov.minfin.shared.tracing.Traced;
import be.fgov.minfin.tsd.gateway.control.message.SendControlInvalidationNotification;
import be.fgov.minfin.tsd.gateway.control.plugin.ControlGatewayPlugin;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

/**
 * It is listener class which will receive control request event and send it to client
 *
 * @author GauravMitra
 */
@Service
public class SendTSDControlDataListener extends AbstractRetryingQueueListener {
  static final String LISTENER_ID = "process-control-request";
  private final ControlGatewayPlugin plugin;

  public SendTSDControlDataListener(
      ControlGatewayConfig controlConfig, ControlGatewayPlugin plugin) {
    super(controlConfig.getControlInvalidationQueue());
    this.plugin = plugin;
  }

  /** Receives message from queue for sending to control */
  @RabbitListener(id = LISTENER_ID, queues = CONTROL_INV_QUEUE, concurrency = CONCURRENCY_INV_VALUE)
  @Traced
  public void onReceiveSendTSDControlData(
      @Payload SendControlInvalidationNotification controlRequest, Message message) {
    plugin.sendTSDControlData(controlRequest);
  }
}
