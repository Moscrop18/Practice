/*
 * @(#) be.fgov.minfin.tsd.gateway.pn.message.ActivationResultRequestBuilder.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.gateway.pn.message;

import static be.fgov.minfin.tsd.util.DateFormatUtil.MESSAGE_TIMESTAMP_FORMAT;

import be.fgov.minfin.libdoa.commons.lang.Now;
import be.fgov.minfin.pn.client.api.LinkingStatus;
import be.fgov.minfin.pn.client.api.MessageHeaderDTO;
import be.fgov.minfin.tsd.config.TSDConfig;
import be.fgov.minfin.tsd.domain.model.TSDActivationRequest;
import be.fgov.minfin.tsd.domain.model.TemporaryStorageDeclaration;
import be.fgov.minfin.tsd.resource.generator.CorrelationIdGenerator;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import javax.validation.ConstraintViolation;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class ActivationResultRequestBuilder {
  private final TSDConfig tsdConfig;
  private final CorrelationIdGenerator correlationIdGenerator;
  public static final String XX = "XX";

  public ActivationResultDTO buildActivationResultRequest(
      TSDActivationRequest request,
      TemporaryStorageDeclaration tsd,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    return buildMessage(request, tsd, violations);
  }

  private ActivationResultDTO buildMessage(
      TSDActivationRequest request,
      TemporaryStorageDeclaration tsd,
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {

    return ActivationResultDTO.builder()
        .messageHeader(buildHeader(request))
        .frn(request.getFrn())
        .linkingStatus(
            (null == violations || violations.isEmpty())
                ? LinkingStatus.LINKED
                : LinkingStatus.NOTLINKED)
        .relatedTSD(
            (null == tsd) ? null : RelatedTSDDTO.builder().mrn(isMrnAlreadyGenerated(tsd)).build())
        .linkingError((null == violations || violations.isEmpty()) ? null : buildErrors(violations))
        .build();
  }

  private String isMrnAlreadyGenerated(TemporaryStorageDeclaration tsd) {
    return tsd.getReferenceNumber().getMrn() != null
        ? tsd.getReferenceNumber().getMrn().getMrnNumber()
        : null;
  }

  private MessageHeaderDTO buildHeader(TSDActivationRequest request) {
    return MessageHeaderDTO.builder()
        .sender(tsdConfig.getTsdSystemName())
        .correlationId(request.getMessageInformation().getCorrelationID())
        .recipient(tsdConfig.getPnSystemName())
        .messageTimestamp(
            DateTimeFormatter.ofPattern(MESSAGE_TIMESTAMP_FORMAT)
                .format(Now.localDateTime().atOffset(ZoneOffset.UTC).toLocalDateTime()))
        .refToMessageId(request.getMessageInformation().getMessageId())
        .messageId(correlationIdGenerator.generateCorrelationID())
        .build();
  }

  public List<ErrorDTO> buildErrors(
      Set<ConstraintViolation<TemporaryStorageDeclaration>> violations) {
    AtomicInteger violationSequenceNumber = new AtomicInteger(0);
    List<ErrorDTO> errors = new ArrayList<>();
    if (null != violations) {
      errors =
          violations.stream() // we sort to be deterministic
              .sorted(
                  Comparator.<ConstraintViolation<?>, String>comparing(
                      v ->
                          v.getPropertyPath().toString()
                              + v.getConstraintDescriptor().getAnnotation().getClass().getName()))
              .map(v -> createError(v, violationSequenceNumber.incrementAndGet()))
              .collect(Collectors.toList());
    }

    return errors;
  }

  /**
   * This method is used to create ErrorRejectMessage corresponding to the provided constraint
   * violation
   *
   * @param violation instance of ConstraintViolation
   * @param violationSequenceNumber variable to store the sequence number of occurred violation
   * @return
   */
  private ErrorDTO createError(
      final ConstraintViolation<?> violation, int violationSequenceNumber) {
    return ErrorDTO.builder()
        .sequenceNumber(violationSequenceNumber)
        .errorReason(getReasonFromMessageTemplate(violation.getMessageTemplate()))
        .build();
  }

  /**
   * @param messageTemplate
   * @return
   */
  private String getReasonFromMessageTemplate(String messageTemplate) {
    String errorCode = messageTemplate.replace("{error.", "");
    errorCode = errorCode.replace("}", "");
    errorCode = errorCode.replace(XX, tsdConfig.getCountryCode());
    return errorCode.substring(errorCode.length() - 7);
  }
}
