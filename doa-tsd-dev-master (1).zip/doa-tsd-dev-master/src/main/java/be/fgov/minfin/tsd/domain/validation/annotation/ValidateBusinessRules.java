/*
 * @(#) be.fgov.minfin.tsd.domain.validation.annotation.ValidateBusinessRules.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.domain.validation.annotation;

import static java.lang.annotation.ElementType.ANNOTATION_TYPE;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import be.fgov.minfin.tsd.domain.validation.validator.AEOValidator;
import be.fgov.minfin.tsd.domain.validation.validator.AdditionalInformationValidator;
import be.fgov.minfin.tsd.domain.validation.validator.AddressValidator;
import be.fgov.minfin.tsd.domain.validation.validator.ArrivalTransportMeansValidator;
import be.fgov.minfin.tsd.domain.validation.validator.ConsignmentItemValidator;
import be.fgov.minfin.tsd.domain.validation.validator.ConsignmentLocationOfGoodsValidator;
import be.fgov.minfin.tsd.domain.validation.validator.ConsignmentValidator;
import be.fgov.minfin.tsd.domain.validation.validator.ControlRecommendationValidator;
import be.fgov.minfin.tsd.domain.validation.validator.LocationOfGoodsValidator;
import be.fgov.minfin.tsd.domain.validation.validator.PackagingValidator;
import be.fgov.minfin.tsd.domain.validation.validator.PartyAddressValidator;
import be.fgov.minfin.tsd.domain.validation.validator.ReceiveControlResultValidator;
import be.fgov.minfin.tsd.domain.validation.validator.ReceiveRiskAnalysisResultValidator;
import be.fgov.minfin.tsd.domain.validation.validator.RiskAnalysisResultValidator;
import be.fgov.minfin.tsd.domain.validation.validator.TSDDeconsolidationNotificationValidator;
import be.fgov.minfin.tsd.domain.validation.validator.TSDInvalidationValidator;
import be.fgov.minfin.tsd.domain.validation.validator.TSDTransferNotificationValidator;
import be.fgov.minfin.tsd.domain.validation.validator.TransportEquipmentValidator;
import be.fgov.minfin.tsd.domain.validation.validator.WarehouseValidator;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import javax.validation.Constraint;
import javax.validation.Payload;

@Documented
@Retention(RUNTIME)
@Target({FIELD, PARAMETER, ANNOTATION_TYPE, TYPE})
@Constraint(
    validatedBy = {
      AdditionalInformationValidator.class,
      ArrivalTransportMeansValidator.class,
      ConsignmentItemValidator.class,
      ConsignmentValidator.class,
      PackagingValidator.class,
      LocationOfGoodsValidator.class,
      TransportEquipmentValidator.class,
      AEOValidator.class,
      WarehouseValidator.class,
      PartyAddressValidator.class,
      AddressValidator.class,
      TSDInvalidationValidator.class,
      ControlRecommendationValidator.class,
      RiskAnalysisResultValidator.class,
      ReceiveRiskAnalysisResultValidator.class,
      ReceiveControlResultValidator.class,
      TSDTransferNotificationValidator.class,
      ConsignmentLocationOfGoodsValidator.class,
      TSDDeconsolidationNotificationValidator.class
    })
public @interface ValidateBusinessRules {
  String message() default "Invalid Document";

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};
}
