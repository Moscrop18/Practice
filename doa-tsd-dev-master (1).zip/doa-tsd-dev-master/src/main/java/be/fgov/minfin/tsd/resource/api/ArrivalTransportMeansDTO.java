/*
 * @(#)be.fgov.minfin.tsd.resource.api.ArrivalTransportMeansDTO.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */

package be.fgov.minfin.tsd.resource.api;

import be.fgov.minfin.tsd.resource.validation.B2BOnly;
import com.fasterxml.jackson.annotation.JsonRootName;
import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.Builder;
import lombok.Value;

/** ArrivalTransportMeansDTO */
@Value
@Builder(toBuilder = true)
@JsonRootName("arrivalTransportMeans")
public class ArrivalTransportMeansDTO {
  @Size(min = 1, max = 35)
  @NotNull(groups = B2BOnly.class)
  @Schema(example = "IMO1924100")
  private String identificationNumber;

  @Digits(integer = 2, fraction = 0)
  @Min(2)
  @NotNull(groups = B2BOnly.class)
  @Schema(example = "10", description = "Type of identification (CL750)")
  private Integer typeOfIdentification;
}
