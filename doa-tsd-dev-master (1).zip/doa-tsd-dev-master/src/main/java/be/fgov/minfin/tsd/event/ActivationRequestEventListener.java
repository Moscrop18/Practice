/*
 * @(#) be.fgov.minfin.tsd.event.ActivationRequestEventListener.java
 * ===========================================================================
 * This source code is exclusive propriety of the SPF Finances.
 * In no case are the contents allowed to be distributed to third parties or made public
 * without prior and written consent of SPF Finances.
 * ===========================================================================
 *
 */
package be.fgov.minfin.tsd.event;

import static be.fgov.minfin.tsd.event.TSDEventConfig.TSD_ACTIVATE_CONCURRENCY;
import static be.fgov.minfin.tsd.event.TSDEventConfig.TSD_ACTIVATE_QUEUE;

import be.fgov.minfin.libdoa.amqp.transactional.AbstractRetryingQueueListener;
import be.fgov.minfin.tsd.domain.service.ActivationService;
import be.fgov.minfin.tsd.event.api.TSDActivationReceivedEvent;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * event listener for Activate TSD
 *
 * @author GauravMitra
 */
@Component
@Transactional
public class ActivationRequestEventListener extends AbstractRetryingQueueListener {

  public static final String LISTENER_ID = "processTSDActivation";

  public ActivationRequestEventListener(TSDEventConfig cfg, ActivationService activationService) {
    super(cfg.getTsdActivateQueue());
    this.activationService = activationService;
  }

  private ActivationService activationService;

  @RabbitListener(
      id = LISTENER_ID,
      queues = TSD_ACTIVATE_QUEUE,
      concurrency = TSD_ACTIVATE_CONCURRENCY)
  public void processActivateTSDEvent(@Payload TSDActivationReceivedEvent event, Message message) {
    activationService.doActivation(event.getActivateTSDRequest());
  }
}
