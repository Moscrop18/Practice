# Environment Configuration

## Introduction
This directory contains values.yaml for all the different environments.

See the readme of the helm chart for a list of configuration options and the descriptions

Values which are the same for all environments should not be defined here, but should be defined in the values.yaml of the chart. 

If you can, please uses 'smart' dns resolution to avoid too many config settings.

## Layout:

env
├── README.md
├── production
│   │   values.yaml         < environment specific values>
├── acceptance
│   └── values.yaml