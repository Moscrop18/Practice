/*
-- Query: select * from responsible_team
-- Date: 2021-05-12 16:27
*/
INSERT INTO responsible_team (`responsible_team_id`,`responsible_team_name`) VALUES (1,'Assessment Lead');
INSERT INTO responsible_team (`responsible_team_id`,`responsible_team_name`) VALUES (2,'S4 Profiler Team');
INSERT INTO responsible_team (`responsible_team_id`,`responsible_team_name`) VALUES (3,'S4 Technical Team');
INSERT INTO responsible_team (`responsible_team_id`,`responsible_team_name`) VALUES (4,'Functional Team');
INSERT INTO responsible_team (`responsible_team_id`,`responsible_team_name`) VALUES (5,'Tech Arc Team');
INSERT INTO responsible_team (`responsible_team_id`,`responsible_team_name`) VALUES (6,'Client');
