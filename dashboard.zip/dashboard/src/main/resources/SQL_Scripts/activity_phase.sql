/*
-- Query: select * from activity_phase
-- Date: 2021-05-12 09:57
*/
INSERT INTO activity_phase (`activity_id`,`activity_name`,`phase_name`,`task_name`) VALUES (1,'Kick Off Meeting','Discover','Assessment');
INSERT INTO activity_phase (`activity_id`,`activity_name`,`phase_name`,`task_name`) VALUES (2,'Team Mobilization','Discover','Assessment');
INSERT INTO activity_phase (`activity_id`,`activity_name`,`phase_name`,`task_name`) VALUES (3,'Arrange for the Team\'s Access','Discover','Assessment');
INSERT INTO activity_phase (`activity_id`,`activity_name`,`phase_name`,`task_name`) VALUES (4,'Share the Credentials','Discover','Assessment');
INSERT INTO activity_phase (`activity_id`,`activity_name`,`phase_name`,`task_name`) VALUES (5,'Send the S4 Profiler, Functional, Technical and Tech Arc Questionnaires','Discover','Assessment');
INSERT INTO activity_phase (`activity_id`,`activity_name`,`phase_name`,`task_name`) VALUES (6,'Receive the Response from Client on Questionnaires','Discover','Assessment');
INSERT INTO activity_phase (`activity_id`,`activity_name`,`phase_name`,`task_name`) VALUES (7,'Generate TR to Import','Discover','Assessment');
INSERT INTO activity_phase (`activity_id`,`activity_name`,`phase_name`,`task_name`) VALUES (8,'Generate Content File for Tool Installation','Discover','Assessment');
INSERT INTO activity_phase (`activity_id`,`activity_name`,`phase_name`,`task_name`) VALUES (9,'Schedule the Background Jobs','Discover','Assessment');
INSERT INTO activity_phase (`activity_id`,`activity_name`,`phase_name`,`task_name`) VALUES (10,'Get the Output of the Backgound Jobs and Start Analysis ','Discover','Assessment');
INSERT INTO activity_phase (`activity_id`,`activity_name`,`phase_name`,`task_name`) VALUES (11,'Publish the Final Report of S4 Profiler','Discover','Assessment');
INSERT INTO activity_phase (`activity_id`,`activity_name`,`phase_name`,`task_name`) VALUES (12,'Installation of Notes','Discover','Assessment');
INSERT INTO activity_phase (`activity_id`,`activity_name`,`phase_name`,`task_name`) VALUES (13,'Execute CVI Report','Discover','Assessment');
INSERT INTO activity_phase (`activity_id`,`activity_name`,`phase_name`,`task_name`) VALUES (14,'Publish the Final Report','Discover','Assessment');
INSERT INTO activity_phase (`activity_id`,`activity_name`,`phase_name`,`task_name`) VALUES (15,'Installation of Notes for RC2.0','Discover','Assessment');
INSERT INTO activity_phase (`activity_id`,`activity_name`,`phase_name`,`task_name`) VALUES (16,'Tech Arc Analysis','Discover','Assessment');
INSERT INTO activity_phase (`activity_id`,`activity_name`,`phase_name`,`task_name`) VALUES (17,'Client Read Out','Discover','Assessment');
INSERT INTO activity_phase (`activity_id`,`activity_name`,`phase_name`,`task_name`) VALUES (18,'Review of Report with CoE Leads','Discover','Assessment');
INSERT INTO activity_phase (`activity_id`,`activity_name`,`phase_name`,`task_name`) VALUES (19,'Tool Execution for S/4 Readiness Check2.0 and Complete it','Discover','Assessment');
INSERT INTO activity_phase (`activity_id`,`activity_name`,`phase_name`,`task_name`) VALUES (20,'Pre-Conversion','Describe','Pre-Conversion');
INSERT INTO activity_phase (`activity_id`,`activity_name`,`phase_name`,`task_name`) VALUES (21,'Code Remediation','Co-Create','Code Remediation');
INSERT INTO activity_phase (`activity_id`,`activity_name`,`phase_name`,`task_name`) VALUES (22,'Dual Maintenance','Scale','Dual Maintenance');