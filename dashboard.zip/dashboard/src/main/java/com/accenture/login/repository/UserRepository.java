package com.accenture.login.repository;

import com.accenture.base.repository.BaseRepository;
import com.accenture.login.entities.UserEntity;

public interface UserRepository extends BaseRepository<UserEntity , String> {
	public UserEntity findByUserEmailId(String userEmailId);
}
