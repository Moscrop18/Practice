package com.accenture.login.service;

import com.accenture.login.beans.Project;

public interface ProjectService {
	public Project getProjectDetails(Integer projectId) throws Exception;
	
	public Project getProjectDetails(String userEmailId) throws Exception;

	public Project saveProjectDetails(Project project) throws Exception;
}
