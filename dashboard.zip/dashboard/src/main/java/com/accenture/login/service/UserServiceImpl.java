package com.accenture.login.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.accenture.login.beans.User;
import com.accenture.login.entities.UserEntity;
import com.accenture.login.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {
	final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

	@Autowired
	private UserRepository userRepository;

	@Override
	public User getUserDetails(String userEmailId) throws Exception {
		logger.info("Fetching the user - Start !!!");
		
		User user = null;
		
		try {
			// Fetching the user
			UserEntity userEntity = userRepository.findByUserEmailId(userEmailId);

			// Checking if user exists or not 
			if (userEntity != null) {
				// Copying the user dao to project dto
				user = new User();
				BeanUtils.copyProperties(userEntity, user);
			}
			
			logger.info("Fetching the user - End !!!");
		} catch (Exception e) {
			logger.error("Error while fetching the user details : ", e);
			throw new Exception();
		}
		
		return user;
	}

	@Override
	public void saveUserDetails(User user) throws Exception {
		try {
			logger.info("Saving the user - Start !!!");
			
			// Copying the properties from user dto to user dao
			UserEntity userEntity = new UserEntity();
			BeanUtils.copyProperties(user, userEntity);

			// Saving the user entity object in the db
			userRepository.save(userEntity);
			
			logger.info("Saving the user - End !!!");
		} catch (Exception e) {
			logger.error("Error while saving the user details : ", e);
			throw new Exception();
		}
	}
}
