package com.accenture.login.service;

import com.accenture.login.beans.User;

public interface UserService {
	public User getUserDetails(String userEmailId) throws Exception;
	
	public void saveUserDetails(User user) throws Exception;
}
