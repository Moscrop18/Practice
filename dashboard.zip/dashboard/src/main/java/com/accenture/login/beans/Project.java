package com.accenture.login.beans;

public class Project {
	private String userEmailId;
	private Integer projectId;
	private String projectName;
	private String clientName;
	private String marketUnit;
	private String industry;
	private String sourceSystem;
	private String targetSystem;
	private String onShoreDelUnitLead;
	private String offShoreDelUnitLead;
	private String clientAccountLead;
	private String smartFieldUsecase;
	private String innovation;
	private String customization;
	private String customInvSize;
	private String dbSize;
	
	public String getUserEmailId() {
		return userEmailId;
	}
	public void setUserEmailId(String userEmailId) {
		this.userEmailId = userEmailId;
	}
	
	public Integer getProjectId() {
		return projectId;
	}
	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}
	
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	
	public String getMarketUnit() {
		return marketUnit;
	}
	public void setMarketUnit(String marketUnit) {
		this.marketUnit = marketUnit;
	}
	
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	
	public String getSourceSystem() {
		return sourceSystem;
	}
	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}
	
	public String getTargetSystem() {
		return targetSystem;
	}
	public void setTargetSystem(String targetSystem) {
		this.targetSystem = targetSystem;
	}
	
	public String getOnShoreDelUnitLead() {
		return onShoreDelUnitLead;
	}
	public void setOnShoreDelUnitLead(String onShoreDelUnitLead) {
		this.onShoreDelUnitLead = onShoreDelUnitLead;
	}
	
	public String getOffShoreDelUnitLead() {
		return offShoreDelUnitLead;
	}
	public void setOffShoreDelUnitLead(String offShoreDelUnitLead) {
		this.offShoreDelUnitLead = offShoreDelUnitLead;
	}
	
	public String getClientAccountLead() {
		return clientAccountLead;
	}
	public void setClientAccountLead(String clientAccountLead) {
		this.clientAccountLead = clientAccountLead;
	}
	
	public String getSmartFieldUsecase() {
		return smartFieldUsecase;
	}
	public void setSmartFieldUsecase(String smartFieldUsecase) {
		this.smartFieldUsecase = smartFieldUsecase;
	}
	
	public String getInnovation() {
		return innovation;
	}
	public void setInnovation(String innovation) {
		this.innovation = innovation;
	}
	
	public String getCustomization() {
		return customization;
	}
	public void setCustomization(String customization) {
		this.customization = customization;
	}
	
	public String getCustomInvSize() {
		return customInvSize;
	}
	public void setCustomInvSize(String customInvSize) {
		this.customInvSize = customInvSize;
	}
	
	public String getDbSize() {
		return dbSize;
	}
	public void setDbSize(String dbSize) {
		this.dbSize = dbSize;
	}
}
