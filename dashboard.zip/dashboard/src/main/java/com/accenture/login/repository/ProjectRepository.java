package com.accenture.login.repository;

import com.accenture.base.repository.BaseRepository;
import com.accenture.login.entities.ProjectEntity;

public interface ProjectRepository extends BaseRepository<ProjectEntity, Integer> {
	public ProjectEntity findByUserEmailId(String userEmailId);
}
