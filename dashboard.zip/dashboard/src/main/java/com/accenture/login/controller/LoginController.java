package com.accenture.login.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.accenture.login.beans.Project;
import com.accenture.login.beans.User;
import com.accenture.login.service.ProjectService;
import com.accenture.login.service.UserService;

@RestController
@RequestMapping("/api")
public class LoginController {
	final Logger logger = LoggerFactory.getLogger(LoginController.class);

	@Autowired
	UserService userService;

	@Autowired
	private ProjectService projectService;

	@PostMapping(value = "/checkUser", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> checkUserDetails(@RequestBody User userBody) {
		try {
			logger.info("Entering checkUser to check if a user exists or not !!!");
			
			User user = userService.getUserDetails(userBody.getUserEmailId());
			Project project = projectService.getProjectDetails(userBody.getUserEmailId());

			// Checking if user exists or not
			if (user != null) {
				// Checking if project exists or not
				if (project != null) {
					logger.info("User and project found !!!");
					return new ResponseEntity<Project>(project, HttpStatus.OK);
				} else {
					logger.info("Project not found !!!");
					return new ResponseEntity<>(HttpStatus.NOT_FOUND);
				}
			} else {
				logger.info("User not found !!!");
				
				// Saving user details
				userService.saveUserDetails(userBody);
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping(value = "/getProject/{projectId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getProjectDetailsByProjectId(@PathVariable Integer projectId) {
		try {
			logger.info("Entering getProject to get the project details specific to a client !!!");
			
			Project project = projectService.getProjectDetails(projectId);

			// Checking if project exists or not
			if (project != null) {
				logger.info("Project found !!!");
				return new ResponseEntity<Project>(project, HttpStatus.OK);
			} else {
				logger.info("Project not found !!!");
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}

	@PostMapping(value = "/saveProject", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> addUserProject(@RequestBody Project projectBody) throws Exception {
		try {
			logger.info("Entering saveProject to save the project details !!!");

			// Saving the project details
			Project project = projectService.saveProjectDetails(projectBody);
			return new ResponseEntity<Project>(project, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}
}
