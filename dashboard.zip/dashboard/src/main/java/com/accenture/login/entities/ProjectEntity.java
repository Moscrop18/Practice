package com.accenture.login.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "Project")
public class ProjectEntity {
	private Integer projectId;
	private String projectName;
	private String userEmailId;
	private String clientName;
	private String marketUnit;
	private String industry;
	private String sourceSystem;
	private String targetSystem;
	private String onShoreDelUnitLead;
	private String offShoreDelUnitLead;
	private String clientAccountLead;
	private String smartFieldUsecase;
	private String innovation;
	private String customization;
	private String customInvSize;
	private String dbSize;
	
	@Id
	@GenericGenerator(name = "project_id" , strategy = "increment")
	@GeneratedValue(generator = "project_id")
	@Column(name = "Project_ID")
	public Integer getProjectId() {
		return projectId;
	}
	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}
	
	@Column(name = "Project_Name")
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	
	@Column(name = "User_EmailID")
	public String getUserEmailId() {
		return userEmailId;
	}
	public void setUserEmailId(String userEmailId) {
		this.userEmailId = userEmailId;
	}
	
	@Column(name = "Client_Name")
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}
	
	@Column(name = "Market_Unit")
	public String getMarketUnit() {
		return marketUnit;
	}
	public void setMarketUnit(String marketUnit) {
		this.marketUnit = marketUnit;
	}
	
	@Column(name = "Industry")
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	
	@Column(name = "Source_System")
	public String getSourceSystem() {
		return sourceSystem;
	}
	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}
	
	@Column(name = "Target_System")
	public String getTargetSystem() {
		return targetSystem;
	}
	public void setTargetSystem(String targetSystem) {
		this.targetSystem = targetSystem;
	}
	
	@Column(name = "OnShore_DelUnitLead")
	public String getOnShoreDelUnitLead() {
		return onShoreDelUnitLead;
	}
	public void setOnShoreDelUnitLead(String onShoreDelUnitLead) {
		this.onShoreDelUnitLead = onShoreDelUnitLead;
	}
	
	@Column(name = "OffShore_DelUnitLead")
	public String getOffShoreDelUnitLead() {
		return offShoreDelUnitLead;
	}
	public void setOffShoreDelUnitLead(String offShoreDelUnitLead) {
		this.offShoreDelUnitLead = offShoreDelUnitLead;
	}
	
	@Column(name = "Client_AccountLead")
	public String getClientAccountLead() {
		return clientAccountLead;
	}
	public void setClientAccountLead(String clientAccountLead) {
		this.clientAccountLead = clientAccountLead;
	}
	
	@Column(name = "SmartField_UseCase")
	public String getSmartFieldUsecase() {
		return smartFieldUsecase;
	}
	public void setSmartFieldUsecase(String smartFieldUsecase) {
		this.smartFieldUsecase = smartFieldUsecase;
	}
	
	@Column(name = "Innovation")
	public String getInnovation() {
		return innovation;
	}
	public void setInnovation(String innovation) {
		this.innovation = innovation;
	}
	
	@Column(name = "Customization")
	public String getCustomization() {
		return customization;
	}
	public void setCustomization(String customization) {
		this.customization = customization;
	}
	
	@Column(name = "CustomInventory_Size")
	public String getCustomInvSize() {
		return customInvSize;
	}
	public void setCustomInvSize(String customInvSize) {
		this.customInvSize = customInvSize;
	}
	
	@Column(name = "DB_Size")
	public String getDbSize() {
		return dbSize;
	}
	public void setDbSize(String dbSize) {
		this.dbSize = dbSize;
	}
}
