package com.accenture.login.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.accenture.login.beans.Project;
import com.accenture.login.entities.ProjectEntity;
import com.accenture.login.repository.ProjectRepository;
import com.accenture.utilities.AppGenUtility;
import com.accenture.utilities.UniqueIDGeneratorUtility;

@Service
public class ProjectServiceImpl implements ProjectService {
	final Logger logger = LoggerFactory.getLogger(ProjectServiceImpl.class);

	@Autowired
	private ProjectRepository projectRepository;

	@Override
	public Project getProjectDetails(Integer projectId) throws Exception {
		logger.info("Fetching the project specific to a client - Start !!!");

		Project project = null;

		try {
			// Fetching the project
			ProjectEntity projectEntity = projectRepository.findById(projectId).get();
			
			// Getting the project details
			project = getClientProjectDetails(projectEntity);

			logger.info("Fetching the project specific to a client - End !!!");
		} catch (Exception e) {
			logger.error("Error while fetching the project details : ", e);
			throw new Exception();
		}

		return project;
	}
	
	@Override
	public Project getProjectDetails(String userEmailId) throws Exception {
		logger.info("Fetching the project specific to a client - Start !!!");
		
		Project project = null;

		try {
			// Fetching the project
			ProjectEntity projectEntity = projectRepository.findByUserEmailId(userEmailId);
			
			// Getting the project details
			project = getClientProjectDetails(projectEntity);
			
			logger.info("Fetching the project specific to a client - End !!!");
		} catch (Exception e) {
			logger.error("Error while fetching the project details : ", e);
			throw new Exception();
		}

		return project;
	}

	@Override
	public Project saveProjectDetails(Project project) throws Exception {
		try {
			logger.info("Saving the project - Start !!!");

			// Copying the properties from project dto to project dao
			ProjectEntity projectEntity = new ProjectEntity();
			BeanUtils.copyProperties(project, projectEntity, AppGenUtility.getNullPropertyNames(project));

			// Generating unique project ui id
			projectEntity.setProjectName(UniqueIDGeneratorUtility.projectIdGenerator(project.getClientName()));

			// Saving the project entity object in the db
			ProjectEntity projectEntityObj = projectRepository.save(projectEntity);

			// Copying the properties from project dao to project dto
			Project projObj = new Project();
			BeanUtils.copyProperties(projectEntityObj, projObj);

			logger.info("Saving the project - End !!!");

			return projObj;
		} catch (Exception e) {
			logger.error("Error while saving the project details : ", e);
			throw new Exception();
		}
	}

	private Project getClientProjectDetails(ProjectEntity projectEntity) {
		Project project = null;
		// Checking if project exists or not
		if (projectEntity != null) {
			// Copying the project dao to project dto
			project = new Project();
			BeanUtils.copyProperties(projectEntity, project);
		}
		
		return project;
	}
}
