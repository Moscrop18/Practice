package com.accenture.utilities;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Date;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;

import com.accenture.dualmaintenancedashboard.beans.PhaseRetrofit;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import net.minidev.json.JSONObject;

public class AppGenUtility {
	public static String[] getNullPropertyNames(Object source) {
		final BeanWrapper src = new BeanWrapperImpl(source);
		java.beans.PropertyDescriptor[] pds = src.getPropertyDescriptors();

		Set<String> emptyNames = new HashSet<String>();
		for (java.beans.PropertyDescriptor pd : pds) {
			Object srcValue = src.getPropertyValue(pd.getName());

			if (srcValue != null) {
				if (srcValue instanceof String && ((String) srcValue).isEmpty())
					emptyNames.add(pd.getName());
				else if (srcValue instanceof Integer && (Integer) srcValue == 0)
					emptyNames.add(pd.getName());
				else if (srcValue instanceof Long && (Long) srcValue == 0L)
					emptyNames.add(pd.getName());
				else if (srcValue instanceof Float && (Float) srcValue == 0.0F)
					emptyNames.add(pd.getName());
			} else
				emptyNames.add(pd.getName());
		}

		String[] result = new String[emptyNames.size()];
		return emptyNames.toArray(result);
	}
	

	public static byte[] writeExcelFile(List<PhaseRetrofit> phaseRetrofitList) throws Exception {
		ByteArrayOutputStream bos = null;
		Workbook workbook = null;

		try {
			InputStream stream = ClassLoader.getSystemResourceAsStream("templates/Phase_Retrofit.xlsx");
			workbook = new XSSFWorkbook(stream);
			Sheet sheet = workbook.getSheetAt(0);

			int rowIndex = 1;

			if (!CollectionUtils.isEmpty(phaseRetrofitList)) {
				for (PhaseRetrofit phaseRetrofitObj : phaseRetrofitList) {
					Row row = sheet.createRow(rowIndex);
					row.createCell(0).setCellValue(Objects.isNull(phaseRetrofitObj.getRetrofitPhase()) ? ""
							: phaseRetrofitObj.getRetrofitPhase());

					row.createCell(1).setCellValue(Objects.isNull(phaseRetrofitObj.getRetrofitTransportRequest()) ? ""
							: phaseRetrofitObj.getRetrofitTransportRequest());

					row.createCell(2).setCellValue(
							Objects.isNull(phaseRetrofitObj.getObjectType()) ? "" : phaseRetrofitObj.getObjectType());

					row.createCell(3).setCellValue(
							Objects.isNull(phaseRetrofitObj.getObjectName()) ? "" : phaseRetrofitObj.getObjectName());

					row.createCell(4).setCellValue(Objects.isNull(phaseRetrofitObj.getTypeOfObject()) ? ""
							: phaseRetrofitObj.getTypeOfObject());

					row.createCell(6).setCellValue(Objects.isNull(phaseRetrofitObj.getAutomationStatus()) ? ""
							: phaseRetrofitObj.getAutomationStatus());

					row.createCell(7).setCellValue(Objects.isNull(phaseRetrofitObj.getObjectCompletionStatus()) ? ""
							: phaseRetrofitObj.getObjectCompletionStatus());

					row.createCell(8).setCellValue(Objects.isNull(phaseRetrofitObj.getNewTransportRequest()) ? ""
							: phaseRetrofitObj.getNewTransportRequest());

					row.createCell(9).setCellValue(Objects.isNull(phaseRetrofitObj.getRetrofittedBy()) ? ""
							: phaseRetrofitObj.getRetrofittedBy());

					row.createCell(10).setCellValue(Objects.isNull(phaseRetrofitObj.getRetrofittedOn()) ? ""
							: phaseRetrofitObj.getRetrofittedOn().toString());

					rowIndex++;
				}
			}

			bos = new ByteArrayOutputStream();
			workbook.write(bos);

			return bos.toByteArray();
		} catch (IOException e) {
			throw new IOException();
		} catch (Exception e) {
			throw new Exception();
		} finally {
			if (bos != null)
				bos.close();

			if (workbook != null)
				workbook.close();
		}
	}

	public static Map<String, Map<String, List<JSONObject>>> getJSONMap(String url, String userName, String password)
			throws Exception {
		try {
			HttpHeaders headers = new HttpHeaders();
			String base64Creds = new String(Base64.encodeBase64((userName + ":" + password).getBytes()));

			headers.add("Authorization", "Basic " + base64Creds);
			HttpEntity<String> request = new HttpEntity<>(headers);

			RestTemplate restTemplate = new RestTemplate();

			JSONObject jsonObject = restTemplate.exchange(url, HttpMethod.GET, request, JSONObject.class).getBody();

			Map<String, Map<String, List<JSONObject>>> resultMap = new ObjectMapper().readValue(
					jsonObject.toJSONString(), new TypeReference<Map<String, Map<String, List<JSONObject>>>>() {
					});

			return resultMap;
		} catch (Exception e) {
			throw new Exception();
		}
	}

	public static <T> Predicate<T> distinctByKeys(
			@SuppressWarnings("unchecked") Function<? super T, ?>... keyExtractors) {
		final Map<List<?>, Boolean> seen = new ConcurrentHashMap<>();

		return t -> {
			final List<?> keys = Arrays.stream(keyExtractors).map(ke -> ke.apply(t)).collect(Collectors.toList());

			return seen.putIfAbsent(keys, Boolean.TRUE) == null;
		};
	}
	
	public static Date getPredictedEndDate(Date actualEndDate, Date actualStartDate, Date plannedEndDate,
			Date plannedStartDate) {
		Date predictedEndDate = null;

		if (Objects.isNull(actualEndDate)) {
			if (!Objects.isNull(plannedStartDate) && !Objects.isNull(plannedEndDate)
					&& !Objects.isNull(actualStartDate)) {
				long diffInDays = TimeUnit.MILLISECONDS.toDays(plannedEndDate.getTime() - plannedStartDate.getTime());

				predictedEndDate = Date.valueOf(LocalDate.parse(actualStartDate.toString()).plusDays(diffInDays));
			}
		} else
			predictedEndDate = actualEndDate;

		return predictedEndDate;
	}
}
