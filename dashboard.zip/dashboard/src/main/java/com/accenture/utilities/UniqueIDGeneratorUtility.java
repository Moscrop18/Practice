package com.accenture.utilities;

import java.util.UUID;

public class UniqueIDGeneratorUtility {
	public static String projectIdGenerator(String clientName) {
		String projectId = clientName.replaceAll("[^a-zA-Z0-9]", "").substring(0, 2) + "_"
				+ UUID.randomUUID().toString().toUpperCase().substring(0, 8);
		
		return projectId;
	}
}
