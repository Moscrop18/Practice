package com.accenture.dashboard.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "Responsible_Team")
public class ResponsibleTeamEntity {
	private Integer responsibleTeamId;
	private String responsibleTeamName;
	private String responsibleTeamType;

	@Id
	@GenericGenerator(name = "team_id" , strategy = "increment")
	@GeneratedValue(generator = "team_id")
	@Column(name = "Responsible_Team_Id")
	public Integer getResponsibleTeamId() {
		return responsibleTeamId;
	}

	public void setResponsibleTeamId(Integer responsibleTeamId) {
		this.responsibleTeamId = responsibleTeamId;
	}

	@Column(name = "Responsible_Team_Name")
	public String getResponsibleTeamName() {
		return responsibleTeamName;
	}

	public void setResponsibleTeamName(String responsibleTeamName) {
		this.responsibleTeamName = responsibleTeamName;
	}

	@Column(name = "Responsible_Team_Type", columnDefinition = "VARCHAR(255) DEFAULT 'NA'")
	public String getResponsibleTeamType() {
		return responsibleTeamType;
	}

	public void setResponsibleTeamType(String responsibleTeamType) {
		this.responsibleTeamType = responsibleTeamType;
	}
}
