package com.accenture.dashboard.repository;

import java.util.List;

import com.accenture.base.repository.BaseRepository;
import com.accenture.dashboard.entities.ActivityPhaseEntity;

public interface ActivityPhaseRepository extends BaseRepository<ActivityPhaseEntity, Integer> {
	public List<ActivityPhaseEntity> findByPhaseNameAndActivityTypeNot(String phaseName, String activityType);
	
	public ActivityPhaseEntity findByActivityId(Integer activityId);
}
