package com.accenture.dashboard.controller;

import java.io.InputStream;
import java.util.List;

import javax.servlet.ServletContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.accenture.dashboard.beans.ActivityPhase;
import com.accenture.dashboard.beans.ResponsibleTeam;
import com.accenture.dashboard.service.ActivityPhaseService;
import com.accenture.dashboard.service.ResponsibleTeamService;

@RestController
@RequestMapping("/api")
public class DashboardController {
	final Logger logger = LoggerFactory.getLogger(DashboardController.class);
	
	@Autowired
	private ServletContext servletContext;

	@Autowired
	private ResponsibleTeamService respTeamService;

	@Autowired
	private ActivityPhaseService activityPhaseService;

	@GetMapping(value = "/getResponsibleTeams", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getResponsibleTeamDetails() {
		try {
			logger.info("Entering getResponsibleTeams to fetch the available responsible teams !!!");

			// Getting the list of available responsible teams
			List<ResponsibleTeam> respTeamList = respTeamService.getResponsibleTeams();

			// Checking if the responsible teams exist or not
			if (!CollectionUtils.isEmpty(respTeamList))
				return new ResponseEntity<List<ResponsibleTeam>>(respTeamList, HttpStatus.OK);
			else
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping(value = "/getActivityPhases/{phaseName}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getActivityDetails(@PathVariable String phaseName) {
		try {
			logger.info("Entering getActivityPhases to fetch the available activities !!!");

			// Getting the list of available activities
			List<ActivityPhase> activityPhaseList = activityPhaseService.getActivityPhases(phaseName);

			// Checking if the activities exist or not
			if (!CollectionUtils.isEmpty(activityPhaseList))
				return new ResponseEntity<List<ActivityPhase>>(activityPhaseList, HttpStatus.OK);
			else
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}

	@PostMapping(value = "/saveActivity/{activityType}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> saveActivityOthers(@RequestBody ActivityPhase activityPhaseBody,
			@PathVariable String activityType) {
		try {
			logger.info("Entering the saveActivity to save an activity !!!");

			if (activityType.equalsIgnoreCase("Others")) {
				// Saving the activity
				ActivityPhase activityPhase = activityPhaseService.saveActivityPhaseOthers(activityPhaseBody);

				return new ResponseEntity<ActivityPhase>(activityPhase, HttpStatus.OK);
			} else {
				return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}

	@DeleteMapping(value = "/deleteActivity/{activityId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> deleteActivityOthers(@PathVariable Integer activityId) {
		try {
			logger.info("Entering deleteActivity to delete an activity !!!");

			// Deleting the activity
			activityPhaseService.deleteActivityPhaseOthers(activityId);

			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}

	@PostMapping(value = "/saveResponsibleTeam/{responsibleTeamType}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> saveResponsibleTeamOthers(@RequestBody ResponsibleTeam respTeamBody,
			@PathVariable String responsibleTeamType) {
		try {
			logger.info("Entering the saveResponsibleTeam to save a responsible team !!!");

			if (responsibleTeamType.equalsIgnoreCase("Others")) {
				// Saving the responsible team
				ResponsibleTeam respTeam = respTeamService.saveResponsibleTeamOthers(respTeamBody);

				return new ResponseEntity<ResponsibleTeam>(respTeam, HttpStatus.OK);
			} else {
				return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}

	@DeleteMapping(value = "/deleteResponsibleTeam/{responsibleTeamId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> deleteResponsibleTeamOthers(@PathVariable Integer responsibleTeamId) {
		try {
			logger.info("Entering deleteResponsibleTeam to delete a responsible team !!!");

			// Deleting the responsible team
			respTeamService.deleteResponsibleTeamOthers(responsibleTeamId);

			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping(value = "/downloadTransportRequest", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity<?> downloadTransportRequestFile() {
		try {
			logger.info("Entering downloadTransportRequestFile to download the transport request file.");

			InputStream stream = ClassLoader.getSystemResourceAsStream("templates/Transport_Request.zip");
			Resource resource = new InputStreamResource(stream);

			return ResponseEntity.ok()
					// Content-Disposition
					.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + "Transport_Request.zip")
					// Content-Type
					.contentType(getMediaTypeForFileName(this.servletContext, "Transport_Request"))
					.body(resource);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value = "/downloadContentRequest", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity<?> downloadContentRequestFile() {
		try {
			logger.info("Entering downloadContentRequestFile to download the content request file.");

			InputStream stream = ClassLoader.getSystemResourceAsStream("templates/Content_Request.zip");
			Resource resource = new InputStreamResource(stream);

			return ResponseEntity.ok()
					// Content-Disposition
					.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + "Content_Request.zip")
					// Content-Type
					.contentType(getMediaTypeForFileName(this.servletContext, "Content_Request"))
					.body(resource);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}
	
	private MediaType getMediaTypeForFileName (ServletContext servletContext, String fileName) {
        String mineType = servletContext.getMimeType(fileName);
        try {
            MediaType mediaType = MediaType.parseMediaType(mineType);
            return mediaType;
        } catch (Exception e) {
            return MediaType.APPLICATION_OCTET_STREAM;
        }
    }
}
