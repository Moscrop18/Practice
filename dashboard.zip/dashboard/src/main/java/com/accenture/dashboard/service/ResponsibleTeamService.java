package com.accenture.dashboard.service;

import java.util.List;

import com.accenture.dashboard.beans.ResponsibleTeam;

public interface ResponsibleTeamService {
	public List<ResponsibleTeam> getResponsibleTeams() throws Exception;
	
	public ResponsibleTeam saveResponsibleTeamOthers(ResponsibleTeam respTeam) throws Exception;
	
	public void deleteResponsibleTeamOthers(Integer responsibleTeamId) throws Exception;
}
