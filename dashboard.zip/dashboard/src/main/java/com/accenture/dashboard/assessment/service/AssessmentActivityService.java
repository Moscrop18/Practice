package com.accenture.dashboard.assessment.service;

import java.util.List;

import com.accenture.dashboard.assessment.beans.AssessmentActivity;

import net.minidev.json.JSONArray;

public interface AssessmentActivityService {
	public List<AssessmentActivity> getAssessmentActivityDetails(String phaseName, String taskName, Integer projectId) throws Exception;

	public AssessmentActivity saveAssessmentActivityDetails(AssessmentActivity assessActivity) throws Exception;

	public void updateAssessmentActivityDetails(AssessmentActivity assessActivity, Integer clientActivityId) throws Exception;

	public void deleteAssessmentActivityDetails(Integer clientActivityId) throws Exception;
	
	public JSONArray getClientActivitiesDetails(Integer projectId) throws Exception;
	
	public void updateActualStartDate(Integer activityId, Integer projectId) throws Exception;
	
	public void updateActualEndDate(Integer activityId, Integer projectId) throws Exception;
}
