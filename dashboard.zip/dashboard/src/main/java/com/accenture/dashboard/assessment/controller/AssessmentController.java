package com.accenture.dashboard.assessment.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.accenture.constants.AppGenConstants;
import com.accenture.dashboard.assessment.beans.AssessmentActivity;
import com.accenture.dashboard.assessment.service.AssessmentActivityService;

import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;

@RestController
@RequestMapping("/api/assessment")
public class AssessmentController {
	final Logger logger = LoggerFactory.getLogger(AssessmentController.class);

	@Autowired
	private AssessmentActivityService assessActivityService;

	@GetMapping(value = "/getClientActivities/{phaseName}/{taskName}/{projectId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getActivityDetails(@PathVariable String phaseName, @PathVariable String taskName,
			@PathVariable Integer projectId) {
		try {
			logger.info("Entering the getClientActivities to fetch the client activities !!!");

			// Getting the list of client activities specific to a project
			List<AssessmentActivity> assessActivityList = assessActivityService.getAssessmentActivityDetails(phaseName,
					taskName, projectId);

			// Checking if the client activities specific to a project exist or not
			if (!CollectionUtils.isEmpty(assessActivityList)) {
				logger.info("List of client activities specific to a project is not empty !!!");
				return new ResponseEntity<List<AssessmentActivity>>(assessActivityList, HttpStatus.OK);
			} else {
				logger.info("List of client activities specific to a project is empty !!!");
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}

	@PostMapping(value = "/saveClientActivities", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> saveActivity(@RequestBody AssessmentActivity assessActivityBody) {
		try {
			logger.info("Entering the saveClientActivities to save a client activity !!!");

			// Saving the client activity specific to a project
			AssessmentActivity assessActivity = assessActivityService.saveAssessmentActivityDetails(assessActivityBody);

			return new ResponseEntity<AssessmentActivity>(assessActivity, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}

	@PutMapping(value = "/updateClientActivities/{clientActivityId}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> updateActivity(@RequestBody AssessmentActivity assessActivityBody,
			@PathVariable Integer clientActivityId) {
		JSONObject jsonObj = new JSONObject();

		try {
			logger.info("Entering updateClientActivities to update a client activity !!!");

			// Updating a specific client activity specific to a project
			assessActivityService.updateAssessmentActivityDetails(assessActivityBody, clientActivityId);

			jsonObj.put(AppGenConstants.STATUS, AppGenConstants.SUCCESS);
			return new ResponseEntity<>(jsonObj, HttpStatus.OK);
		} catch (Exception e) {
			jsonObj.put(AppGenConstants.STATUS, AppGenConstants.FAILURE);
			return new ResponseEntity<>(jsonObj, HttpStatus.BAD_REQUEST);
		}
	}

	@DeleteMapping(value = "/deleteClientActivities/{clientActivityId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> deleteActivity(@PathVariable Integer clientActivityId) {
		JSONObject jsonObj = new JSONObject();

		try {
			logger.info("Entering deleteClientActivities to delete a client activity !!!");

			// Deleting a specific client activity specific to a project
			assessActivityService.deleteAssessmentActivityDetails(clientActivityId);

			jsonObj.put(AppGenConstants.STATUS, AppGenConstants.SUCCESS);
			return new ResponseEntity<>(jsonObj, HttpStatus.OK);
		} catch (Exception e) {
			jsonObj.put(AppGenConstants.STATUS, AppGenConstants.FAILURE);
			return new ResponseEntity<>(jsonObj, HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping(value = "/chart/getActivities/{projectId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getClientActivitiesDetails(@PathVariable Integer projectId) {
		try {
			logger.info("Entering the getClientActivitiesDetails to fetch the client activities !!!");

			// Getting the json object of client activities specific to a project
			JSONArray jsonArray = assessActivityService.getClientActivitiesDetails(projectId);

			// Checking if the client activities specific to a project exist or not
			if (!CollectionUtils.isEmpty(jsonArray)) {
				logger.info("List of client activities specific to a project is not empty !!!");
				return new ResponseEntity<JSONArray>(jsonArray, HttpStatus.OK);
			} else {
				logger.info("List of client activities specific to a project is empty !!!");
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}

	@PutMapping(value = "/updateStartActualDate/{activityId}/{projectId}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> updateActualStartDate(@PathVariable Integer activityId, @PathVariable Integer projectId) {
		JSONObject jsonObj = new JSONObject();
		
		try {
			logger.info("Entering updateActualStartDate to update the actual start bit !!!");
			
			assessActivityService.updateActualStartDate(activityId, projectId);
			
			jsonObj.put(AppGenConstants.STATUS, AppGenConstants.SUCCESS);
			return new ResponseEntity<>(jsonObj, HttpStatus.OK);
		} catch (Exception e) {
			jsonObj.put(AppGenConstants.STATUS, AppGenConstants.FAILURE);
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}
	
	@PutMapping(value = "/updateEndActualDate/{activityId}/{projectId}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> updateActualEndDate(@PathVariable Integer activityId, @PathVariable Integer projectId) {
		JSONObject jsonObj = new JSONObject();
		
		try {
			logger.info("Entering updateActualStartDate to update the actual start bit !!!");
			
			assessActivityService.updateActualEndDate(activityId, projectId);
			
			jsonObj.put(AppGenConstants.STATUS, AppGenConstants.SUCCESS);
			return new ResponseEntity<>(jsonObj, HttpStatus.OK);
		} catch (Exception e) {
			jsonObj.put(AppGenConstants.STATUS, AppGenConstants.FAILURE);
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}
}
