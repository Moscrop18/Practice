package com.accenture.dashboard.assessment.entities;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "Assessment_Activity")
public class AssessmentActivityEntity {
	private Integer id;
	private Integer activityId;
	private String activityName;
	private Integer responsibleTeamId;
	private String responsibleTeamName;
	private Date plannedStartDate;
	private Date plannedEndDate;
	private Date actualStartDate;
	private Date actualEndDate;
	private String completionStatus;
	private String comments;
	private Integer projectId;
	private Date predictedEndDate;
	private Boolean actualStartBit = Boolean.FALSE;
	private Boolean actualEndBit = Boolean.FALSE;

	public AssessmentActivityEntity() {

	}

	public AssessmentActivityEntity(int id, int activityId, String activityName, int responsibleTeamId,
			String responsibleTeamName, java.util.Date plannedStartDate, java.util.Date plannedEndDate,
			java.util.Date actualStartDate, java.util.Date actualEndDate, String completionStatus, String comments,
			int projectId, java.util.Date predictedEndDate) {
		super();
		this.id = id;
		this.activityId = activityId;
		this.activityName = activityName;
		this.responsibleTeamId = responsibleTeamId;
		this.responsibleTeamName = responsibleTeamName;
		this.plannedStartDate = (Date) plannedStartDate;
		this.plannedEndDate = (Date) plannedEndDate;
		this.actualStartDate = (Date) actualStartDate;
		this.actualEndDate = (Date) actualEndDate;
		this.completionStatus = completionStatus;
		this.comments = comments;
		this.projectId = projectId;
		this.predictedEndDate = (Date) predictedEndDate;
	}

	@Id
	@GenericGenerator(name = "id", strategy = "increment")
	@GeneratedValue(generator = "id")
	@Column(name = "Id")
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Column(name = "Activity_Id")
	public Integer getActivityId() {
		return activityId;
	}

	public void setActivityId(Integer activityId) {
		this.activityId = activityId;
	}

	@Transient
	public String getActivityName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	@Column(name = "Responsible_Team_Id")
	public Integer getResponsibleTeamId() {
		return responsibleTeamId;
	}

	public void setResponsibleTeamId(Integer responsibleTeamId) {
		this.responsibleTeamId = responsibleTeamId;
	}

	@Transient
	public String getResponsibleTeamName() {
		return responsibleTeamName;
	}

	public void setResponsibleTeamName(String responsibleTeamName) {
		this.responsibleTeamName = responsibleTeamName;
	}

	@Column(name = "Planned_Start_Date")
	public Date getPlannedStartDate() {
		return plannedStartDate;
	}

	public void setPlannedStartDate(Date plannedStartDate) {
		this.plannedStartDate = plannedStartDate;
	}

	@Column(name = "Planned_End_Date")
	public Date getPlannedEndDate() {
		return plannedEndDate;
	}

	public void setPlannedEndDate(Date plannedEndDate) {
		this.plannedEndDate = plannedEndDate;
	}

	@Column(name = "Actual_Start_Date")
	public Date getActualStartDate() {
		return actualStartDate;
	}

	public void setActualStartDate(Date actualStartDate) {
		this.actualStartDate = actualStartDate;
	}

	@Column(name = "Actual_End_Date")
	public Date getActualEndDate() {
		return actualEndDate;
	}

	public void setActualEndDate(Date actualEndDate) {
		this.actualEndDate = actualEndDate;
	}

	@Column(name = "Completion_Status")
	public String getCompletionStatus() {
		return completionStatus;
	}

	public void setCompletionStatus(String completionStatus) {
		this.completionStatus = completionStatus;
	}

	@Column(name = "Comments")
	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	@Column(name = "Project_Id")
	public Integer getProjectId() {
		return projectId;
	}

	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

	@Column(name = "Predicted_End_Date")
	public Date getPredictedEndDate() {
		return predictedEndDate;
	}

	public void setPredictedEndDate(Date predictedEndDate) {
		this.predictedEndDate = predictedEndDate;
	}

	@Column(name = "Actual_Start_Bit")
	public Boolean getActualStartBit() {
		return actualStartBit;
	}

	public void setActualStartBit(Boolean actualStartBit) {
		this.actualStartBit = actualStartBit;
	}

	@Column(name = "Actual_End_Bit")
	public Boolean getActualEndBit() {
		return actualEndBit;
	}

	public void setActualEndBit(Boolean actualEndBit) {
		this.actualEndBit = actualEndBit;
	}
}
