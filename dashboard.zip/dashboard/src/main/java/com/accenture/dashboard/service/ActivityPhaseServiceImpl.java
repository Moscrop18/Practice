package com.accenture.dashboard.service;

import java.util.LinkedList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.accenture.dashboard.beans.ActivityPhase;
import com.accenture.dashboard.entities.ActivityPhaseEntity;
import com.accenture.dashboard.repository.ActivityPhaseRepository;
import com.accenture.utilities.AppGenUtility;

@Service
public class ActivityPhaseServiceImpl implements ActivityPhaseService {
	final Logger logger = LoggerFactory.getLogger(ActivityPhaseServiceImpl.class);

	@Autowired
	private ActivityPhaseRepository activityPhaseRepository;

	@Override
	public List<ActivityPhase> getActivityPhases(String phaseName) throws Exception {
		logger.info("Fetching the list of activities - Start !!!");
		
		List<ActivityPhase> activityPhaseList = null;

		try {
			// Fetching the list of activities 
			List<ActivityPhaseEntity> activityPhaseEntityList = activityPhaseRepository
					.findByPhaseNameAndActivityTypeNot(phaseName, "Others");

			// Checking if there are activities present or not
			if (!CollectionUtils.isEmpty(activityPhaseEntityList)) {
				activityPhaseList = new LinkedList<>();

				// Copying the list of activity phase dao to activiy phase dto
				for (ActivityPhaseEntity activityPhaseEntity : activityPhaseEntityList) {
					ActivityPhase activityPhase = new ActivityPhase();
					BeanUtils.copyProperties(activityPhaseEntity, activityPhase);

					// Adding each activity phase dto to a list
					activityPhaseList.add(activityPhase);
				}
			}
			
			logger.info("Fetching the list of activities - End !!!");
		} catch (Exception e) {
			logger.error("Error while fetching the activity phases details : ", e);
			throw new Exception();
		}

		return activityPhaseList;
	}

	@Override
	public ActivityPhase saveActivityPhaseOthers(ActivityPhase activityPhase) throws Exception {
		try {
			logger.info("Saving the activity where activity type is 'Others' - Start !!!");
			
			// Copying the activity phase dto to activity phase dao
			ActivityPhaseEntity activityPhaseEntity = new ActivityPhaseEntity();
			BeanUtils.copyProperties(activityPhase, activityPhaseEntity, AppGenUtility.getNullPropertyNames(activityPhase));

			// Saving the activity where activity type is 'Others'
			ActivityPhaseEntity activityPhaseEntityObj = activityPhaseRepository.save(activityPhaseEntity);
			
			// Copying the activity phase dao to activity phase dto
			ActivityPhase activityPhaseObj = new ActivityPhase();
			BeanUtils.copyProperties(activityPhaseEntityObj, activityPhaseObj);
			
			logger.info("Saving the activity where activity type is 'Others' - End !!!");
			
			return activityPhaseObj;
		} catch (Exception e) {
			logger.error("Error while saving the activity where activity type is 'Others' : ", e);
			throw new Exception();
		}
	}

	@Override
	public void deleteActivityPhaseOthers(Integer activityId) throws Exception {
		try {
			logger.info("Deleting the activity where activity type is 'Others' - Start !!!");
			
			// Fetching an activity based on activity id
			ActivityPhaseEntity activityPhaseEntity = activityPhaseRepository.findByActivityId(activityId);

			// Deleting the fetched activity
			activityPhaseRepository.delete(activityPhaseEntity);
			
			logger.info("Deleting the activity where activity type is 'Others' - End !!!");
		} catch (Exception e) {
			logger.error("Error while deleting the activity where activity type is 'Others' : ", e);
			throw new Exception();
		}
	}
}
