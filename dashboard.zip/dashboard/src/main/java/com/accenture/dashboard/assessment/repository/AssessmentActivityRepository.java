package com.accenture.dashboard.assessment.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.accenture.base.repository.BaseRepository;
import com.accenture.dashboard.assessment.entities.AssessmentActivityEntity;

public interface AssessmentActivityRepository extends BaseRepository<AssessmentActivityEntity, Integer> {
	@Query(value = "SELECT new AssessmentActivityEntity(a.id, a.activityId, b.activityName, "
			+ "a.responsibleTeamId, c.responsibleTeamName, a.plannedStartDate, a.plannedEndDate, "
			+ "a.actualStartDate, a.actualEndDate, a.completionStatus, a.comments, a.projectId, a.predictedEndDate) "
			+ "FROM AssessmentActivityEntity a JOIN ActivityPhaseEntity b ON a.activityId = b.activityId "
			+ "JOIN ResponsibleTeamEntity c ON a.responsibleTeamId = c.responsibleTeamId "
			+ "WHERE a.projectId = :projectId AND b.phaseName = :phaseName AND b.taskName = :taskName")
	public List<AssessmentActivityEntity> findByProjectIdPhaseTask(@Param("projectId") Integer projectId,
			@Param("phaseName") String phaseName, @Param("taskName") String taskName);
	
	@Query(value = "SELECT new AssessmentActivityEntity(a.id, a.activityId, b.activityName, "
			+ "a.responsibleTeamId, c.responsibleTeamName, a.plannedStartDate, a.plannedEndDate, "
			+ "a.actualStartDate, a.actualEndDate, a.completionStatus, a.comments, a.projectId, a.predictedEndDate) "
			+ "FROM AssessmentActivityEntity a JOIN ActivityPhaseEntity b ON a.activityId = b.activityId "
			+ "JOIN ResponsibleTeamEntity c ON a.responsibleTeamId = c.responsibleTeamId "
			+ "WHERE a.projectId = :projectId")
	public List<AssessmentActivityEntity> findByProjectId(@Param("projectId") Integer projectId);
	
	public List<AssessmentActivityEntity> findByProjectIdAndActivityId(Integer projectId, Integer activityId);
}
