package com.accenture.dashboard.service;

import java.util.LinkedList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.accenture.dashboard.beans.ResponsibleTeam;
import com.accenture.dashboard.entities.ResponsibleTeamEntity;
import com.accenture.dashboard.repository.ResponsibleTeamRepository;
import com.accenture.utilities.AppGenUtility;

@Service
public class ResponsibleTeamServiceImpl implements ResponsibleTeamService {
	final Logger logger = LoggerFactory.getLogger(ResponsibleTeamServiceImpl.class);

	@Autowired
	private ResponsibleTeamRepository respTeamRepository;

	@Override
	public List<ResponsibleTeam> getResponsibleTeams() throws Exception {
		logger.info("Fetching the list of responsible teams - Start !!!");

		List<ResponsibleTeam> respTeamList = null;

		try {
			// Fetching the list of responsible teams
			List<ResponsibleTeamEntity> respTeamEntityList = respTeamRepository.findByResponsibleTeamTypeNot("Others");

			// Checking if there are responsible teams present or not
			if (!CollectionUtils.isEmpty(respTeamEntityList)) {
				respTeamList = new LinkedList<>();

				// Copying the list of responsibel team dao to responsibel team dto
				for (ResponsibleTeamEntity respTeamEntity : respTeamEntityList) {
					ResponsibleTeam respTeam = new ResponsibleTeam();
					BeanUtils.copyProperties(respTeamEntity, respTeam);

					// Adding each activity phase dto to a list
					respTeamList.add(respTeam);
				}
			}

			logger.info("Fetching the list of responsible teams - End !!!");
		} catch (Exception e) {
			logger.error("Error while fetching responsible team details : ", e);
			throw new Exception();
		}

		return respTeamList;
	}

	@Override
	public ResponsibleTeam saveResponsibleTeamOthers(ResponsibleTeam respTeam) throws Exception {
		try {
			logger.info("Saving the responsible team where responsible team type is 'Others' - Start !!!");

			// Copying the responsible team dto to responsible team dao
			ResponsibleTeamEntity respTeamEntity = new ResponsibleTeamEntity();
			BeanUtils.copyProperties(respTeam, respTeamEntity, AppGenUtility.getNullPropertyNames(respTeam));

			// Saving the responsible team where responsible team type is 'Others'
			ResponsibleTeamEntity respTeamEntityObj = respTeamRepository.save(respTeamEntity);

			// Copying the responsible team dao to responsible team dto
			ResponsibleTeam respTeamObj = new ResponsibleTeam();
			BeanUtils.copyProperties(respTeamEntityObj, respTeamObj);
			
			logger.info("Saving the responsible team where responsible team type is 'Others' - End !!!");

			return respTeamObj;
		} catch (Exception e) {
			logger.error("Error while saving the responsible team where responsible team type is 'Others' : ", e);
			throw new Exception();
		}
	}

	@Override
	public void deleteResponsibleTeamOthers(Integer responsibleTeamId) throws Exception {
		try {
			logger.info("Deleting the responsible team where responsible team type is 'Others' - Start !!!");
			
			// Fetching a responsible team based on responsible team id
			ResponsibleTeamEntity respTeamEntity = respTeamRepository.findByResponsibleTeamId(responsibleTeamId);

			// Deleting the fetched responsible team
			respTeamRepository.delete(respTeamEntity);
			
			logger.info("Deleting the responsible team where responsible team type is 'Others' - End !!!");
		} catch (Exception e) {
			logger.error("Error while deleting the responsible team where responsible team type is 'Others' : ", e);
			throw new Exception();
		}
	}
}
