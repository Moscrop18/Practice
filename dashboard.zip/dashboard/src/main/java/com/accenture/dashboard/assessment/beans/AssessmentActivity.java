package com.accenture.dashboard.assessment.beans;

import java.sql.Date;

public class AssessmentActivity {
	private Integer id;
	private Integer activityId;
	private String activityName;
	private Integer responsibleTeamId;
	private String responsibleTeamName;
	private Date plannedStartDate;
	private Date plannedEndDate;
	private Date actualStartDate;
	private Date actualEndDate;
	private String completionStatus;
	private String comments;
	private Integer projectId;
	private Date predictedEndDate;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getActivityId() {
		return activityId;
	}

	public void setActivityId(Integer activityId) {
		this.activityId = activityId;
	}

	public String getActivityName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public Integer getResponsibleTeamId() {
		return responsibleTeamId;
	}

	public void setResponsibleTeamId(Integer responsibleTeamId) {
		this.responsibleTeamId = responsibleTeamId;
	}

	public String getResponsibleTeamName() {
		return responsibleTeamName;
	}

	public void setResponsibleTeamName(String responsibleTeamName) {
		this.responsibleTeamName = responsibleTeamName;
	}

	public Date getPlannedStartDate() {
		return plannedStartDate;
	}

	public void setPlannedStartDate(Date plannedStartDate) {
		this.plannedStartDate = plannedStartDate;
	}

	public Date getPlannedEndDate() {
		return plannedEndDate;
	}

	public void setPlannedEndDate(Date plannedEndDate) {
		this.plannedEndDate = plannedEndDate;
	}

	public Date getActualStartDate() {
		return actualStartDate;
	}

	public void setActualStartDate(Date actualStartDate) {
		this.actualStartDate = actualStartDate;
	}

	public Date getActualEndDate() {
		return actualEndDate;
	}

	public void setActualEndDate(Date actualEndDate) {
		this.actualEndDate = actualEndDate;
	}

	public String getCompletionStatus() {
		return completionStatus;
	}

	public void setCompletionStatus(String completionStatus) {
		this.completionStatus = completionStatus;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Integer getProjectId() {
		return projectId;
	}

	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

	public Date getPredictedEndDate() {
		return predictedEndDate;
	}

	public void setPredictedEndDate(Date predictedEndDate) {
		this.predictedEndDate = predictedEndDate;
	}
}
