package com.accenture.dashboard.assessment.service;

import java.sql.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

import javax.json.Json;
import javax.json.JsonBuilderFactory;
import javax.json.JsonObject;

import org.apache.logging.log4j.util.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.accenture.constants.AppGenConstants;
import com.accenture.dashboard.assessment.beans.AssessmentActivity;
import com.accenture.dashboard.assessment.entities.AssessmentActivityEntity;
import com.accenture.dashboard.assessment.repository.AssessmentActivityRepository;
import com.accenture.dashboard.repository.ActivityPhaseRepository;
import com.accenture.dashboard.repository.ResponsibleTeamRepository;
import com.accenture.utilities.AppGenUtility;

import net.minidev.json.JSONArray;
import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;

@Service
public class AssessmentActivityServiceImpl implements AssessmentActivityService {
	final Logger logger = LoggerFactory.getLogger(AssessmentActivityServiceImpl.class);

	@Autowired
	private AssessmentActivityRepository assessActivityRepository;

	@Autowired
	private ActivityPhaseRepository activityPhaseRepository;

	@Autowired
	private ResponsibleTeamRepository respTeamRepository;

	@Override
	public List<AssessmentActivity> getAssessmentActivityDetails(String phaseName, String taskName, Integer projectId)
			throws Exception {
		logger.info("Fetching the list of client activities specific to a project - Start !!!");

		List<AssessmentActivity> assessActivityList = null;

		try {
			// Fetching the list of client activities specific to a project
			List<AssessmentActivityEntity> assessActivityEntityList = assessActivityRepository
					.findByProjectIdPhaseTask(projectId, phaseName, taskName);

			// Checking if there are client activities specific to a project or not
			if (!CollectionUtils.isEmpty(assessActivityEntityList)) {
				assessActivityList = new LinkedList<>();

				// Copying the list of assessment activity dao to assessment activiy dto
				for (AssessmentActivityEntity assessActivityEntity : assessActivityEntityList) {
					AssessmentActivity assessActivity = new AssessmentActivity();
					BeanUtils.copyProperties(assessActivityEntity, assessActivity);

					// Adding each assessment activity dto to a list
					assessActivityList.add(assessActivity);
				}
			}

			logger.info("Fetching the list of client activities specific to a project - End !!!");
		} catch (Exception e) {
			logger.error("Error while fetching the list of client activities related to a project : ", e);
			throw new Exception();
		}

		return assessActivityList;
	}

	@Override
	public AssessmentActivity saveAssessmentActivityDetails(AssessmentActivity assessActivity) throws Exception {
		try {
			logger.info("Saving the client activity - Start !!!");

			// Copying the assessment activity dto to assessment activity dao
			AssessmentActivityEntity assessActivityEntity = new AssessmentActivityEntity();
			BeanUtils.copyProperties(assessActivity, assessActivityEntity,
					AppGenUtility.getNullPropertyNames(assessActivity));

			// Setting the predicted end date
			assessActivityEntity.setPredictedEndDate(AppGenUtility.getPredictedEndDate(
					assessActivityEntity.getActualEndDate(), assessActivityEntity.getActualStartDate(),
					assessActivityEntity.getPlannedEndDate(), assessActivityEntity.getPlannedStartDate()));

			// Saving the client activity specific to a project
			AssessmentActivityEntity assessActivityEntityObj = assessActivityRepository.save(assessActivityEntity);

			// Copying the assessment activity dao to assessment activity dto
			AssessmentActivity assessActivityObj = new AssessmentActivity();
			BeanUtils.copyProperties(assessActivityEntityObj, assessActivityObj);

			// Setting the activity name in the activity dto based on the activity id
			activityPhaseRepository.findAll().forEach(activityPhaseObj -> {
				if (assessActivityEntity.getActivityId() == activityPhaseObj.getActivityId())
					assessActivity.setActivityName(activityPhaseObj.getActivityName());
			});

			// Setting the responsible team name in the activity dto based on the
			// responsible team id
			respTeamRepository.findAll().forEach(respTeamObj -> {
				if (assessActivityEntity.getResponsibleTeamId() == respTeamObj.getResponsibleTeamId())
					assessActivity.setResponsibleTeamName(respTeamObj.getResponsibleTeamName());
			});

			logger.info("Saving the client activity - End !!!");

			return assessActivityObj;
		} catch (Exception e) {
			logger.error("Error while saving the client activity details specific to a project : ", e);
			throw new Exception();
		}
	}

	@Override
	public void updateAssessmentActivityDetails(AssessmentActivity assessActivity, Integer clientActivityId)
			throws Exception {
		try {
			logger.info("Updating the client activity - Start !!!");

			// Fetching a client activity based on project id and activity id
			AssessmentActivityEntity assessActivityEntity = assessActivityRepository.findById(clientActivityId).get();

			// Updating the fetched client activity
			if (assessActivityEntity != null) {
				BeanUtils.copyProperties(assessActivity, assessActivityEntity,
						AppGenUtility.getNullPropertyNames(assessActivity));

				// Setting the predicted end date
				assessActivityEntity.setPredictedEndDate(AppGenUtility.getPredictedEndDate(
						assessActivityEntity.getActualEndDate(), assessActivityEntity.getActualStartDate(),
						assessActivityEntity.getPlannedEndDate(), assessActivityEntity.getPlannedStartDate()));

				assessActivityRepository.save(assessActivityEntity);
			}

			logger.info("Updating the client activity - End !!!");
		} catch (Exception e) {
			logger.error("Error while updating the client activity details specific to a project : ", e);
			throw new Exception();
		}
	}

	@Override
	public void deleteAssessmentActivityDetails(Integer clientActivityId) throws Exception {
		try {
			logger.info("Deleting the client activity - Start !!!");

			// Deleting the client activity
			assessActivityRepository.deleteById(clientActivityId);

			logger.info("Deleting the client activity - End !!!");
		} catch (Exception e) {
			logger.error("Error while deleting the client activity details specific to a project : ", e);
			throw new Exception();
		}
	}

	@Override
	public JSONArray getClientActivitiesDetails(Integer projectId) throws Exception {
		logger.info("Fetching the json object of client activities specific to a project - Start !!!");

		try {
			JSONArray assessActivityJsonArray = null;

			// Fetching the list of client activities specific to a project
			List<AssessmentActivityEntity> assessActivityEntityList = assessActivityRepository
					.findByProjectId(projectId);

			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(AppGenConstants.DATE_FORMAT);

			// Checking if there are client activities specific to a project or not
			if (!CollectionUtils.isEmpty(assessActivityEntityList)) {
				assessActivityJsonArray = new JSONArray();

				for (AssessmentActivityEntity assessActivityEntity : assessActivityEntityList) {
					Date start = null;
					Date end = null;
					String color = Strings.EMPTY;

					if (Objects.isNull(assessActivityEntity.getActualStartDate())
							&& Objects.isNull(assessActivityEntity.getActualEndDate())) {
						start = assessActivityEntity.getPlannedStartDate();
						end = assessActivityEntity.getPlannedEndDate();
						color = AppGenConstants.BLUE_COLOR;
					} else if (!Objects.isNull(assessActivityEntity.getActualStartDate())) {
						if (Objects.isNull(assessActivityEntity.getActualEndDate())) {
							start = assessActivityEntity.getActualStartDate();
							end = assessActivityEntity.getPredictedEndDate();
							color = AppGenConstants.ORANGE_COLOR;
						} else {
							start = assessActivityEntity.getActualStartDate();
							end = assessActivityEntity.getActualEndDate();
							color = AppGenConstants.GREEN_COLOR;
						}
					}

					JsonBuilderFactory factory = Json.createBuilderFactory(null);
					JsonObject jsonObject = factory.createObjectBuilder()
							.add("name",
									assessActivityEntity.getActivityName() == null ? ""
											: assessActivityEntity.getActivityName())
							.add("start",
									start == null ? 0L : Timestamp.valueOf(simpleDateFormat.format(start)).getTime())
							.add("end", end == null ? 0L : Timestamp.valueOf(simpleDateFormat.format(end)).getTime())
							.add("color", color).add("completed", factory.createObjectBuilder().add("amount", 0))
							.add("custom", factory.createArrayBuilder().add(factory.createObjectBuilder()
									.add("actualStartDate", assessActivityEntity.getActualStartDate() == null ? 0L
											: Timestamp
													.valueOf(simpleDateFormat
															.format(assessActivityEntity.getActualStartDate()))
													.getTime())
									.add("actualEndDate", assessActivityEntity.getActualEndDate() == null ? 0L
											: Timestamp.valueOf(
													simpleDateFormat.format(assessActivityEntity.getActualEndDate()))
													.getTime())
									.add("predictedEndDate",
											assessActivityEntity.getPredictedEndDate() == null ? 0L
													: Timestamp
															.valueOf(simpleDateFormat
																	.format(assessActivityEntity.getPredictedEndDate()))
															.getTime())))
							.build();

					assessActivityJsonArray
							.add((JSONObject) new JSONParser(JSONParser.MODE_JSON_SIMPLE).parse(jsonObject.toString()));
				}
			}

			logger.info("Fetching the json object of client activities specific to a project - End !!!");

			return assessActivityJsonArray;
		} catch (Exception e) {
			logger.error("Error while fetching the json object of client activities related to a project : ", e);
			throw new Exception();
		}
	}

	@Override
	public void updateActualStartDate(Integer activityId, Integer projectId) throws Exception {
		logger.info("Updating the actual start bit -- Start !!!");

		try {
			// Checking if the client activity exists or not for a specific activity id and
			// project id
			List<AssessmentActivityEntity> assessActivityEntityList = assessActivityRepository
					.findByProjectIdAndActivityId(projectId, activityId);

			if (!CollectionUtils.isEmpty(assessActivityEntityList)) {
				assessActivityEntityList.stream().forEach(assessActivityEntity -> {
					// Updating the actual start bit if it's 0
					if (!Objects.isNull(assessActivityEntity.getActualStartBit())
							&& !assessActivityEntity.getActualStartBit()) {
						assessActivityEntity.setActualStartBit(Boolean.TRUE);

						// Calculating the actual start date and predicted end date
						assessActivityEntity.setActualStartDate(new Date(Calendar.getInstance().getTime().getTime()));
						assessActivityEntity.setPredictedEndDate(AppGenUtility.getPredictedEndDate(
								assessActivityEntity.getActualEndDate(), assessActivityEntity.getActualStartDate(),
								assessActivityEntity.getPlannedEndDate(), assessActivityEntity.getPlannedStartDate()));

						assessActivityRepository.save(assessActivityEntity);
					}
				});
			}

			logger.info("Updating the actual start bit -- End !!!");
		} catch (Exception e) {
			logger.error("Error while updating the actual start bit : ", e);
		}
	}

	public void updateActualEndDate(Integer activityId, Integer projectId) throws Exception {
		logger.info("Updating the actual end bit -- Start !!!");

		try {
			// Checking if the client activity exists or not for a specific activity id and
			// project id
			List<AssessmentActivityEntity> assessActivityEntityList = assessActivityRepository
					.findByProjectIdAndActivityId(projectId, activityId);

			if (!CollectionUtils.isEmpty(assessActivityEntityList)) {
				assessActivityEntityList.stream().forEach(assessActivityEntity -> {
					// Updating the actual start bit if it's 0
					if (!Objects.isNull(assessActivityEntity.getActualEndBit())
							&& !assessActivityEntity.getActualEndBit()) {
						assessActivityEntity.setActualEndBit(Boolean.TRUE);

						// Calculating the actual start date and predicted end date
						assessActivityEntity.setActualEndDate(new Date(Calendar.getInstance().getTime().getTime()));
						assessActivityEntity.setPredictedEndDate(AppGenUtility.getPredictedEndDate(
								assessActivityEntity.getActualEndDate(), assessActivityEntity.getActualStartDate(),
								assessActivityEntity.getPlannedEndDate(), assessActivityEntity.getPlannedStartDate()));

						assessActivityRepository.save(assessActivityEntity);
					}
				});
			}

			logger.info("Updating the actual end bit -- End !!!");
		} catch (Exception e) {
			logger.error("Error while updating the actual end bit : ", e);
		}
	}
}
