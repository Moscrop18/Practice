package com.accenture.dashboard.repository;

import java.util.List;

import com.accenture.base.repository.BaseRepository;
import com.accenture.dashboard.entities.ResponsibleTeamEntity;

public interface ResponsibleTeamRepository extends BaseRepository<ResponsibleTeamEntity, Integer> {
	public List<ResponsibleTeamEntity> findByResponsibleTeamTypeNot(String responsibleTeamType); 
	
	public ResponsibleTeamEntity findByResponsibleTeamId(Integer responsibleTeamId);
}
