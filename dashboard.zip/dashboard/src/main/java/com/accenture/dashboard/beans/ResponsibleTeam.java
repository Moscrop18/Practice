package com.accenture.dashboard.beans;

public class ResponsibleTeam {
	private Integer responsibleTeamId;
	private String responsibleTeamName;
	private String responsibleTeamType;

	public Integer getResponsibleTeamId() {
		return responsibleTeamId;
	}

	public void setResponsibleTeamId(Integer responsibleTeamId) {
		this.responsibleTeamId = responsibleTeamId;
	}

	public String getResponsibleTeamName() {
		return responsibleTeamName;
	}

	public void setResponsibleTeamName(String responsibleTeamName) {
		this.responsibleTeamName = responsibleTeamName;
	}

	public String getResponsibleTeamType() {
		return responsibleTeamType;
	}

	public void setResponsibleTeamType(String responsibleTeamType) {
		this.responsibleTeamType = responsibleTeamType;
	}
}
