package com.accenture.dashboard.service;

import java.util.List;

import com.accenture.dashboard.beans.ActivityPhase;

public interface ActivityPhaseService {
	public List<ActivityPhase> getActivityPhases(String phaseName) throws Exception;
	
	public ActivityPhase saveActivityPhaseOthers(ActivityPhase activityPhase) throws Exception;
	
	public void deleteActivityPhaseOthers(Integer activityId) throws Exception;
}
