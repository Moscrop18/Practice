package com.accenture.dashboard.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "Activity_Phase")
public class ActivityPhaseEntity {
	private Integer activityId;
	private String activityName;
	private String activityType;
	private String taskName;
	private String phaseName;

	@Id
	@GenericGenerator(name = "activity_id" , strategy = "increment")
	@GeneratedValue(generator = "activity_id")
	@Column(name = "Activity_Id")
	public Integer getActivityId() {
		return activityId;
	}

	public void setActivityId(Integer activityId) {
		this.activityId = activityId;
	}

	@Column(name = "Activity_Name")
	public String getActivityName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	@Column(name = "Activity_Type", columnDefinition = "VARCHAR(255) DEFAULT 'NA'")
	public String getActivityType() {
		return activityType;
	}

	public void setActivityType(String activityType) {
		this.activityType = activityType;
	}

	@Column(name = "Task_Name")
	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	@Column(name = "Phase_Name")
	public String getPhaseName() {
		return phaseName;
	}

	public void setPhaseName(String phaseName) {
		this.phaseName = phaseName;
	}
}
