package com.accenture.dualmaintenancedashboard.service;

import java.util.List;

import javax.json.JsonObject;

import org.springframework.web.multipart.MultipartFile;

import com.accenture.dualmaintenancedashboard.beans.CurrentPhaseDetails;

public interface DualDashboardService {
	public byte[] getFileBytes(String phaseValue) throws Exception;
	
	public JsonObject getGraphsData() throws Exception;
	
	public void saveFileData(MultipartFile file) throws Exception;
	
	public List<CurrentPhaseDetails> getCurrentPhaseDetails(Integer projectId) throws Exception;
}
