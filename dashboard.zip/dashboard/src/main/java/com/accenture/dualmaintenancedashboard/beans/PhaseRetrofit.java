package com.accenture.dualmaintenancedashboard.beans;

import java.util.Date;

import com.accenture.constants.AppGenConstants;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PhaseRetrofit {
	@JsonProperty(value = AppGenConstants.PHASE)
	private String retrofitPhase;
	
	@JsonProperty(value = AppGenConstants.RETROFIT_TRANSPORT)
	private String retrofitTransportRequest;
	
	@JsonProperty(value = AppGenConstants.OBJECT_TYPE)
	private String objectType;
	
	@JsonProperty(value = AppGenConstants.OBJECT_NAME)
	private String objectName;
	
	String objTypeName;
	
	@JsonProperty(value = AppGenConstants.NEW_CONFLICT)
	private String typeOfObject;

	private String automationStatus;
	private String objectCompletionStatus;
	private String phaseCompletionStatus;
	
	@JsonProperty(value = AppGenConstants.NEW_TRANSPORT)
	private String newTransportRequest;
	
	@JsonProperty(value = AppGenConstants.RETROFITTED_BY)
	private String retrofittedBy;

	private Date retrofittedOn;

	public String getRetrofitPhase() {
		return retrofitPhase;
	}

	public void setRetrofitPhase(String retrofitPhase) {
		this.retrofitPhase = retrofitPhase;
	}

	public String getRetrofitTransportRequest() {
		return retrofitTransportRequest;
	}

	public void setRetrofitTransportRequest(String retrofitTransportRequest) {
		this.retrofitTransportRequest = retrofitTransportRequest;
	}

	public String getObjectType() {
		return objectType;
	}

	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}

	public String getObjectName() {
		return objectName;
	}

	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}

	public String getObjTypeName() {
		return objTypeName;
	}

	public void setObjTypeName(String objTypeName) {
		this.objTypeName = objTypeName;
	}

	public String getTypeOfObject() {
		return typeOfObject;
	}

	public void setTypeOfObject(String typeOfObject) {
		this.typeOfObject = typeOfObject;
	}

	public String getAutomationStatus() {
		return automationStatus;
	}

	public void setAutomationStatus(String automationStatus) {
		this.automationStatus = automationStatus;
	}

	public String getObjectCompletionStatus() {
		return objectCompletionStatus;
	}

	public void setObjectCompletionStatus(String objectCompletionStatus) {
		this.objectCompletionStatus = objectCompletionStatus;
	}

	public String getPhaseCompletionStatus() {
		return phaseCompletionStatus;
	}

	public void setPhaseCompletionStatus(String phaseCompletionStatus) {
		this.phaseCompletionStatus = phaseCompletionStatus;
	}

	public String getNewTransportRequest() {
		return newTransportRequest;
	}

	public void setNewTransportRequest(String newTransportRequest) {
		this.newTransportRequest = newTransportRequest;
	}

	public String getRetrofittedBy() {
		return retrofittedBy;
	}

	public void setRetrofittedBy(String retrofittedBy) {
		this.retrofittedBy = retrofittedBy;
	}

	public Date getRetrofittedOn() {
		return retrofittedOn;
	}

	public void setRetrofittedOn(Date retrofittedOn) {
		this.retrofittedOn = retrofittedOn;
	}
}
