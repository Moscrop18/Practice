package com.accenture.dualmaintenancedashboard.service;

import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.json.Json;
import javax.json.JsonBuilderFactory;
import javax.json.JsonObject;

import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.util.Strings;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import com.accenture.dualmaintenancedashboard.beans.CurrentPhaseDetails;
import com.accenture.dualmaintenancedashboard.beans.PhaseRetrofit;
import com.accenture.constants.AppGenConstants;
import com.accenture.dashboard.assessment.entities.AssessmentActivityEntity;
import com.accenture.dashboard.assessment.repository.AssessmentActivityRepository;
import com.accenture.dualmaintenancedashboard.entities.CurrentPhaseDetailsEntity;
import com.accenture.dualmaintenancedashboard.repository.DualDashboardRepository;
import com.accenture.utilities.AppGenUtility;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;
import net.minidev.json.parser.ParseException;

@Service
public class DualDashboardServiceImpl implements DualDashboardService {
	final Logger logger = LoggerFactory.getLogger(DualDashboardServiceImpl.class);

	@Autowired
	private DualDashboardRepository dualDashboardRepository;

	@Autowired
	private AssessmentActivityRepository assessActivityRepository;

	public byte[] getFileBytes(String phaseValue) throws Exception {
		try {
			logger.info("Writing the excel file and getting the bytes for the file.");

			if (Strings.isEmpty(phaseValue))
				return AppGenUtility.writeExcelFile(getPhaseRetrofitList(AppGenConstants.ODATA_SERVICES_URL));
			else
				return AppGenUtility.writeExcelFile(getPhaseRetrofitList(AppGenConstants.ODATA_SERVICES_FILTER_URL
						.concat("'" + phaseValue.toUpperCase().replaceAll("\\s", Strings.EMPTY).trim() + "'"
								+ "&format=json")));
		} catch (Exception e) {
			logger.error("Error while getting the bytes of excel file : ", e);
			throw new Exception();
		}
	}

	@SuppressWarnings("serial")
	public JsonObject getGraphsData() throws Exception {
		JsonObject jsonObj = null;

		try {
			logger.info("Getting the graphs data - Start !!!");

			JsonBuilderFactory factory = Json.createBuilderFactory(null);
			List<JSONObject> seriesDataList = new LinkedList<>();
			List<JSONObject> drilldownDataList = new LinkedList<>();

			Map<String, Map<String, Object>> resultMap = getCounts();

			if (!CollectionUtils.isEmpty(resultMap)) {
				resultMap.entrySet().stream().forEach(entry -> {
					// Creating the series data
					JSONObject seriesDataJsonObj = new JSONObject() {
						{
							put(AppGenConstants.NAME, entry.getKey());
							put(AppGenConstants.Y_NAME, (Integer) entry.getValue().get(AppGenConstants.OBJ_COUNT));
							put(AppGenConstants.COLOR, (String) entry.getValue().get(AppGenConstants.COLOR));
							put(AppGenConstants.DRILLDOWN,
									entry.getKey().toLowerCase().concat(AppGenConstants.ID_CONST));
						}
					};

					seriesDataList.add(seriesDataJsonObj);

					// Creating the drilldown data
					JsonObject drilldownConflictNewDataJsonObj = factory.createObjectBuilder()
							.add(AppGenConstants.ID, entry.getKey().toLowerCase().concat(AppGenConstants.ID_CONST))
							.add(AppGenConstants.COLOR_BY_POINT, AppGenConstants.TRUE)
							.add(AppGenConstants.NAME, AppGenConstants.GRAPH_2_HEADING)
							.add(AppGenConstants.DATA, factory.createArrayBuilder()
									.add(factory.createArrayBuilder(new LinkedList<Object>(Arrays.asList(
											AppGenConstants.NEW_STR, entry.getValue().get(AppGenConstants.NEW_COUNT),
											entry.getKey().toLowerCase()
													.concat(AppGenConstants.NEW_STR.toLowerCase()
															.concat(AppGenConstants.ID_CONST)),
											entry.getValue().get(AppGenConstants.NEW_COLOR)))))
									.add(factory.createArrayBuilder(
											new LinkedList<Object>(Arrays.asList(AppGenConstants.CONFLICT_STR,
													entry.getValue().get(AppGenConstants.CONFLICT_COUNT),
													entry.getKey().toLowerCase()
															.concat(AppGenConstants.CONFLICT_STR.toLowerCase()
																	.concat(AppGenConstants.ID_CONST)),
													entry.getValue().get(AppGenConstants.CONFLICT_COLOR))))))
							.add(AppGenConstants.KEYS,
									factory.createArrayBuilder(new LinkedList<String>(
											Arrays.asList(AppGenConstants.NAME, AppGenConstants.Y_NAME,
													AppGenConstants.DRILLDOWN, AppGenConstants.COLOR))))
							.build();

					try {
						drilldownDataList.add((JSONObject) new JSONParser(JSONParser.MODE_JSON_SIMPLE)
								.parse(drilldownConflictNewDataJsonObj.toString()));

						drilldownDataList
								.add(getJsonObject(
										entry.getKey().toLowerCase()
												.concat(AppGenConstants.CONFLICT_STR.toLowerCase()
														.concat(AppGenConstants.ID_CONST)),
										(Integer) entry.getValue().get(AppGenConstants.AUTOMATIC_CONFLICT_COUNT),
										(Integer) entry.getValue().get(AppGenConstants.SEMI_AUTOMATIC_CONFLICT_COUNT),
										(Integer) entry.getValue().get(AppGenConstants.MANUAL_CONFLICT_COUNT)));
					} catch (ParseException e) {
						logger.error("Error while parsing the json object : ", e);
					}
				});

				// Building the json object for graphs
				jsonObj = factory.createObjectBuilder().add(AppGenConstants.SERIES, factory.createArrayBuilder()
						.add(factory.createObjectBuilder().add(AppGenConstants.NAME, AppGenConstants.GRAPH_1_HEADING)
								.add(AppGenConstants.COLOR_BY_POINT, AppGenConstants.TRUE)
								.add(AppGenConstants.DATA, factory.createArrayBuilder(seriesDataList))))
						.add(AppGenConstants.DRILLDOWN, factory.createObjectBuilder().add(AppGenConstants.SERIES,
								factory.createArrayBuilder(drilldownDataList)))
						.build();
			}

			logger.info("Getting the graphs data - End !!!");
			return jsonObj;
		} catch (Exception e) {
			logger.error("Error while fetching the graphs data : ", e);
			throw new Exception();
		}
	}

	private List<PhaseRetrofit> getPhaseRetrofitList(String url) throws Exception {
		try {
			List<PhaseRetrofit> phaseRetrofitList = new LinkedList<>();
			Map<String, String> phaseStatusMap = new LinkedHashMap<>();

			AppGenUtility.getJSONMap(url, AppGenConstants.USERNAME, AppGenConstants.PASSWORD).values().stream()
					.forEach(map -> map.values().stream().forEach(list -> list.stream().forEach(jsonObj -> {
						PhaseRetrofit phaseRetrofitObj = null;

						try {
							// Mapping the json object to phase retrofit object
							phaseRetrofitObj = new ObjectMapper().readValue(jsonObj.toJSONString(),
									PhaseRetrofit.class);

							// Object type and name concatenation
							phaseRetrofitObj.setObjTypeName(phaseRetrofitObj.getObjectType().trim()
									.concat(phaseRetrofitObj.getObjectName().trim()));

							// Calculating and setting object completion status
							String status = Strings.isEmpty((String) jsonObj.get(AppGenConstants.STATUS_KEY)) ? ""
									: ((String) jsonObj.get(AppGenConstants.STATUS_KEY)).trim();
							
							if (status.equals(AppGenConstants.PARTIAL_RETROFITTED_SYMBOL))
								phaseRetrofitObj.setObjectCompletionStatus(AppGenConstants.PARTIAL_RETROFITTED);
							else if (status.equals(AppGenConstants.RETROFITTED_SYMBOL))
								phaseRetrofitObj.setObjectCompletionStatus(AppGenConstants.RETROFITTED);
							else if (status.equalsIgnoreCase(AppGenConstants.YET_TO_RETROFIT))
								phaseRetrofitObj.setObjectCompletionStatus(AppGenConstants.YET_TO_RETROFIT);
							else if (Strings.isEmpty(status))
								phaseRetrofitObj.setObjectCompletionStatus(AppGenConstants.NO_ACTION_REQUIRED);

							// Calculating and setting automation status
							String automationStatus = Strings
									.isEmpty((String) jsonObj.get(AppGenConstants.AUTOMATIC_KEY)) ? ""
											: ((String) jsonObj.get(AppGenConstants.AUTOMATIC_KEY));

							if (automationStatus.equals(AppGenConstants.AUTOMATION_SYMBOL))
								phaseRetrofitObj.setAutomationStatus(AppGenConstants.AUTOMATIC);
							else if (automationStatus.equals(AppGenConstants.SEMI_AUTOMATION_SYMBOL))
								phaseRetrofitObj.setAutomationStatus(AppGenConstants.SEMI_AUTOMATIC);
							else if (automationStatus.equals(AppGenConstants.MANUAL_SYMBOL))
								phaseRetrofitObj.setAutomationStatus(AppGenConstants.MANUAL);

							// Calculating phase completion status
							if (!phaseRetrofitObj.getObjectCompletionStatus()
									.equals(AppGenConstants.NO_ACTION_REQUIRED)) {
								String statusVal = phaseStatusMap.get(phaseRetrofitObj.getRetrofitPhase());

								if ((phaseStatusMap.containsKey(phaseRetrofitObj.getRetrofitPhase())
										&& !statusVal.equals(AppGenConstants.YET_TO_RETROFIT))
										|| (!phaseStatusMap.containsKey(phaseRetrofitObj.getRetrofitPhase()))) {
									if (phaseRetrofitObj.getObjectCompletionStatus()
											.equals(AppGenConstants.PARTIAL_RETROFITTED))
										phaseStatusMap.put(phaseRetrofitObj.getRetrofitPhase(),
												AppGenConstants.YET_TO_RETROFIT);
									else
										phaseStatusMap.put(phaseRetrofitObj.getRetrofitPhase(),
												phaseRetrofitObj.getObjectCompletionStatus());
								}
							}

							// Converting unix time stamp to date
							if (Strings.isNotEmpty((String) jsonObj.get(AppGenConstants.RETROFITTED_ON_KEY)))
								phaseRetrofitObj.setRetrofittedOn(new Date(
										Long.parseLong(((String) jsonObj.get(AppGenConstants.RETROFITTED_ON_KEY))
												.replaceAll("[^0-9]", Strings.EMPTY)) * 1000));
						} catch (JsonProcessingException e) {
							logger.error("Error while processing the json : ", e);
						}

						if (phaseRetrofitObj != null)
							phaseRetrofitList.add(phaseRetrofitObj);
					})));

			// Setting the phase completion status
			phaseRetrofitList.stream().forEach(phaseRetrofitObj -> {
				phaseStatusMap.entrySet().stream().forEach(entry -> {
					if (phaseRetrofitObj.getRetrofitPhase().equals(entry.getKey())) {
						phaseRetrofitObj.setPhaseCompletionStatus(entry.getValue());
					}
				});
			});

			return phaseRetrofitList;
		} catch (Exception e) {
			throw new Exception();
		}
	}

	@Override
	public void saveFileData(MultipartFile file) throws Exception {
		XSSFWorkbook workbook = null;

		try {
			logger.info("Saving the excel into database --- Start !!!");

			// Validation for extension
			if (!FilenameUtils.getExtension(file.getOriginalFilename())
					.equalsIgnoreCase(AppGenConstants.XLSX_EXTENSION))
				throw new Exception();

			// Reading and writing the excel file to db
			workbook = new XSSFWorkbook(file.getInputStream());
			XSSFSheet worksheet = workbook.getSheetAt(0);

			List<CurrentPhaseDetailsEntity> phaseDetailsList = new LinkedList<>();

			int rowIndex = 1;

			while (rowIndex < worksheet.getPhysicalNumberOfRows()) {
				CurrentPhaseDetailsEntity phaseDetailsObj = new CurrentPhaseDetailsEntity();

				XSSFRow row = worksheet.getRow(rowIndex);

				phaseDetailsObj.setRetrofitPhase(Strings.isEmpty(row.getCell(0).getStringCellValue().trim()) ? ""
						: row.getCell(0).getStringCellValue().trim());
				phaseDetailsObj
						.setRetrofitTransportRequest(Strings.isEmpty(row.getCell(1).getStringCellValue().trim()) ? ""
								: row.getCell(1).getStringCellValue().trim());
				phaseDetailsObj.setTransportType(Strings.isEmpty(row.getCell(2).getStringCellValue().trim()) ? ""
						: row.getCell(2).getStringCellValue().trim());

				phaseDetailsList.add(phaseDetailsObj);

				++rowIndex;
			}

			// Clearing the table
			dualDashboardRepository.deleteAll();

			// Saving the data to the table
			dualDashboardRepository.saveAll(phaseDetailsList);

			logger.info("Saving the excel into database --- End !!!");
		} catch (Exception e) {
			logger.error("Error while saving the excel file : ", e);
			throw new Exception();
		} finally {
			if (workbook != null)
				workbook.close();
		}
	}

	@Override
	public List<CurrentPhaseDetails> getCurrentPhaseDetails(Integer projectId) throws Exception {
		try {
			int totalObjCount = 0, retrofittedObjCount = 0;

			logger.info("Getting the current phase details --- Start !!!");

			// Fetching the retrofit transport data from db
			List<CurrentPhaseDetailsEntity> currentPhaseEntityList = dualDashboardRepository.findAll();

			// Getting the current phase value for which retrofit transport is uploaded
			String phaseValue = currentPhaseEntityList.stream().distinct().findFirst().get().getRetrofitPhase();

			// Getting the current phase data from odata service
			List<PhaseRetrofit> phaseRetrofitList = getPhaseRetrofitList(
					AppGenConstants.ODATA_SERVICES_FILTER_URL.concat("'"
							+ phaseValue.toUpperCase().replaceAll("\\s", Strings.EMPTY).trim() + "'" + "&format=json"));
			List<CurrentPhaseDetails> currentPhaseList = new LinkedList<>();

			if (!CollectionUtils.isEmpty(currentPhaseEntityList) && !CollectionUtils.isEmpty(phaseRetrofitList)) {
				// Calculating status and completion percentage for each retrofit transport for
				// the current phase
				for (CurrentPhaseDetailsEntity currentPhaseEntityObj : currentPhaseEntityList) {
					List<PhaseRetrofit> list = phaseRetrofitList.stream()
							.filter(obj -> Strings.isNotEmpty(obj.getRetrofitPhase().trim())
									&& obj.getRetrofitPhase().trim()
											.equalsIgnoreCase(currentPhaseEntityObj.getRetrofitPhase().toUpperCase()
													.replaceAll("\\s", Strings.EMPTY).trim())
									&& Strings.isNotEmpty(obj.getRetrofitTransportRequest().trim())
									&& obj.getRetrofitTransportRequest()
											.equalsIgnoreCase(currentPhaseEntityObj.getRetrofitTransportRequest())
									&& Strings.isNotEmpty(obj.getTypeOfObject().trim())
									&& obj.getTypeOfObject().trim().equalsIgnoreCase(AppGenConstants.CONFLICT_STR))
							.collect(Collectors.toList());

					if (!CollectionUtils.isEmpty(list)) {
						totalObjCount = (int) list.stream().map(PhaseRetrofit::getObjTypeName).distinct().count();
						retrofittedObjCount = (int) list.stream()
								.filter(obj -> Strings.isNotEmpty(obj.getObjectCompletionStatus().trim())
										&& (obj.getObjectCompletionStatus().trim()
												.equalsIgnoreCase(AppGenConstants.RETROFITTED)))
								.map(PhaseRetrofit::getObjTypeName).distinct().count();

						CurrentPhaseDetails currentPhaseObj = new CurrentPhaseDetails();
						BeanUtils.copyProperties(currentPhaseEntityObj, currentPhaseObj);

						if (totalObjCount == retrofittedObjCount) {
							currentPhaseObj.setStatus(AppGenConstants.COMPLETED);
							currentPhaseObj.setCompletionPerc(AppGenConstants.COMPLETION_PERCENTAGE);
						} else {
							currentPhaseObj.setStatus(AppGenConstants.IN_PROGRESS);

							if (totalObjCount != 0)
								currentPhaseObj.setCompletionPerc(
										Float.toString((((float) retrofittedObjCount) / (float) totalObjCount) * 100)
												.concat("%"));
						}

						currentPhaseList.add(currentPhaseObj);
					}
				}
			}

			// Updating the actual end date if the phase 1 of dual maintenance is completed
			updateDualMaintenanceActualEndDate(currentPhaseList, projectId);

			logger.info("Getting the current phase details --- End !!!");

			return currentPhaseList;
		} catch (Exception e) {
			logger.error("Error while fetching the current phase details : ", e);
			throw new Exception();
		}
	}

	private void updateDualMaintenanceActualEndDate(List<CurrentPhaseDetails> currentPhaseList, Integer projectId) {
		if (!CollectionUtils.isEmpty(currentPhaseList)) {
			String phaseVal = currentPhaseList.stream().distinct().findFirst().get().getRetrofitPhase().trim()
					.replaceAll("\\s", Strings.EMPTY);

			if (phaseVal.equals(AppGenConstants.PHASE_1_VAL) && currentPhaseList.stream()
					.allMatch(obj -> obj.getStatus().equals(AppGenConstants.COMPLETED))) {
				List<AssessmentActivityEntity> assessActivityEntityList = assessActivityRepository
						.findByProjectIdAndActivityId(projectId, AppGenConstants.ACTIVITY_ID);

				if (!CollectionUtils.isEmpty(assessActivityEntityList)) {
					assessActivityEntityList.stream().forEach(assessActivityEntity -> {
						// Updating the actual start bit if it's 0
						if (!Objects.isNull(assessActivityEntity.getActualEndBit())
								&& !assessActivityEntity.getActualEndBit()) {
							assessActivityEntity.setActualEndBit(Boolean.TRUE);

							// Calculating the actual start date and predicted end date
							assessActivityEntity
									.setActualEndDate(new java.sql.Date(Calendar.getInstance().getTime().getTime()));
							assessActivityEntity.setPredictedEndDate(AppGenUtility.getPredictedEndDate(
									assessActivityEntity.getActualEndDate(), assessActivityEntity.getActualStartDate(),
									assessActivityEntity.getPlannedEndDate(),
									assessActivityEntity.getPlannedStartDate()));

							assessActivityRepository.save(assessActivityEntity);
						}
					});
				}
			}
		}
	}

	private Map<String, Map<String, Object>> getCounts() throws Exception {
		int objCount = 0, conflictCount = 0, newCount = 0, automaticConflictCount = 0, semiAutomaticConflictCount = 0,
				manualConflictCount = 0;
		String color = "", newColor = "", conflictColor = "";
		Map<String, Map<String, Object>> resultMap = new LinkedHashMap<>();
		Map<String, Object> countMap = null;

		try {
			List<PhaseRetrofit> phaseRetrofitList = getPhaseRetrofitList(AppGenConstants.ODATA_SERVICES_URL);

			// Creating a list of distinct phases
			List<String> distinctPhasesList = phaseRetrofitList.stream()
					.filter(obj -> Strings.isNotEmpty(obj.getRetrofitPhase())).map(obj -> obj.getRetrofitPhase())
					.distinct().collect(Collectors.toList());

			for (String phaseVal : distinctPhasesList) {
				List<PhaseRetrofit> phaseList = new LinkedList<>((phaseRetrofitList.stream()
						.filter(obj -> Strings.isNotEmpty(obj.getRetrofitPhase())
								&& obj.getRetrofitPhase().trim().equalsIgnoreCase(phaseVal)
								&& Strings.isNotEmpty(obj.getObjTypeName()))
						.distinct().collect(Collectors.toList()))
								.stream()
								.sorted(Comparator
										.comparing(PhaseRetrofit::getAutomationStatus,
												Comparator.comparing(AppGenConstants.SEMI_AUTOMATIC::equals))
										.reversed())
								.collect(Collectors.toMap(PhaseRetrofit::getObjTypeName, Function.identity(),
										(u1, u2) -> u1))
								.values());

				conflictCount = (int) phaseList.stream().filter(obj -> Strings.isNotEmpty(obj.getTypeOfObject())
						&& obj.getTypeOfObject().trim().equalsIgnoreCase(AppGenConstants.CONFLICT_STR)).count();

				newCount = (int) phaseList.stream().filter(obj -> Strings.isNotEmpty(obj.getTypeOfObject())
						&& obj.getTypeOfObject().trim().equalsIgnoreCase(AppGenConstants.NEW_STR)).count();

				automaticConflictCount = (int) phaseList.stream()
						.filter(obj -> Strings.isNotEmpty(obj.getTypeOfObject())
								&& obj.getTypeOfObject().trim().equalsIgnoreCase(AppGenConstants.CONFLICT_STR)
								&& Strings.isNotEmpty(obj.getAutomationStatus())
								&& obj.getAutomationStatus().trim().equalsIgnoreCase(AppGenConstants.AUTOMATIC))
						.count();

				semiAutomaticConflictCount = (int) phaseList.stream()
						.filter(obj -> Strings.isNotEmpty(obj.getTypeOfObject())
								&& obj.getTypeOfObject().trim().equalsIgnoreCase(AppGenConstants.CONFLICT_STR)
								&& Strings.isNotEmpty(obj.getAutomationStatus())
								&& obj.getAutomationStatus().trim().equalsIgnoreCase(AppGenConstants.SEMI_AUTOMATIC))
						.count();

				manualConflictCount = (int) phaseList.stream()
						.filter(obj -> Strings.isNotEmpty(obj.getTypeOfObject())
								&& obj.getTypeOfObject().trim().equalsIgnoreCase(AppGenConstants.CONFLICT_STR)
								&& Strings.isNotEmpty(obj.getAutomationStatus())
								&& obj.getAutomationStatus().trim().equalsIgnoreCase(AppGenConstants.MANUAL))
						.count();

				color = (phaseList.stream().filter(obj -> Strings.isNotEmpty(obj.getPhaseCompletionStatus()))
						.findFirst().get()).getPhaseCompletionStatus().trim()
								.equalsIgnoreCase(AppGenConstants.RETROFITTED) ? AppGenConstants.COMPLETED_COLOR
										: AppGenConstants.IN_PROGRESS_COLOR;

				newColor = color.equals(AppGenConstants.COMPLETED_COLOR) ? AppGenConstants.NEW_COMPLETED_COLOR
						: AppGenConstants.NEW_IN_PROGRESS_COLOR;

				conflictColor = color.equals(AppGenConstants.COMPLETED_COLOR) ? AppGenConstants.CONFLICT_COMPLETED_COLOR
						: AppGenConstants.CONFLICT_IN_PROGRESS_COLOR;

				newColor = color.equals(AppGenConstants.COMPLETED_COLOR) ? AppGenConstants.NEW_COMPLETED_COLOR
						: AppGenConstants.NEW_IN_PROGRESS_COLOR;

				objCount = (int) phaseRetrofitList.stream()
						.filter(obj -> Strings.isNotEmpty(obj.getRetrofitPhase())
								&& obj.getRetrofitPhase().trim().equalsIgnoreCase(phaseVal)
								&& Strings.isNotEmpty(obj.getRetrofitTransportRequest()))
						.map(obj -> obj.getRetrofitTransportRequest()).distinct().count();

				countMap = new LinkedHashMap<>();

				countMap.put(AppGenConstants.OBJ_COUNT, objCount);
				countMap.put(AppGenConstants.CONFLICT_COUNT, conflictCount);
				countMap.put(AppGenConstants.NEW_COUNT, newCount);
				countMap.put(AppGenConstants.AUTOMATIC_CONFLICT_COUNT, automaticConflictCount);
				countMap.put(AppGenConstants.SEMI_AUTOMATIC_CONFLICT_COUNT, semiAutomaticConflictCount);
				countMap.put(AppGenConstants.MANUAL_CONFLICT_COUNT, manualConflictCount);
				countMap.put(AppGenConstants.COLOR, color);
				countMap.put(AppGenConstants.NEW_COLOR, newColor);
				countMap.put(AppGenConstants.CONFLICT_COLOR, conflictColor);

				resultMap.put(phaseVal, countMap);
			}
		} catch (Exception e) {
			logger.error("Error while calculating the counts for kpis : ", e);
			throw new Exception();
		}

		return resultMap;
	}

	private JSONObject getJsonObject(String id, Integer automaticCount, Integer semiAutomaticCount, Integer manualCount)
			throws ParseException {
		JsonBuilderFactory factory = Json.createBuilderFactory(null);
		JsonObject jsonObject = factory.createObjectBuilder().add(AppGenConstants.ID, id)
				.add(AppGenConstants.NAME, AppGenConstants.GRAPH_3_HEADING)
				.add(AppGenConstants.DATA, factory.createArrayBuilder()
						.add(factory.createArrayBuilder(new LinkedList<Object>(
								Arrays.asList(AppGenConstants.AUTOMATIC.toLowerCase(), automaticCount))))
						.add(factory.createArrayBuilder(new LinkedList<Object>(
								Arrays.asList(AppGenConstants.SEMI_AUTOMATIC.toLowerCase(), semiAutomaticCount))))
						.add(factory.createArrayBuilder(new LinkedList<Object>(
								Arrays.asList(AppGenConstants.MANUAL.toLowerCase(), manualCount)))))
				.build();

		return (JSONObject) new JSONParser(JSONParser.MODE_JSON_SIMPLE).parse(jsonObject.toString());
	}
}
