package com.accenture.dualmaintenancedashboard.repository;

import com.accenture.base.repository.BaseRepository;
import com.accenture.dualmaintenancedashboard.entities.CurrentPhaseDetailsEntity;

public interface DualDashboardRepository extends BaseRepository<CurrentPhaseDetailsEntity, Integer> {

}
