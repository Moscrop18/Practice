package com.accenture.dualmaintenancedashboard.controller;

import java.util.List;

import javax.json.JsonObject;
import javax.servlet.ServletContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.accenture.dualmaintenancedashboard.beans.CurrentPhaseDetails;
import com.accenture.dualmaintenancedashboard.service.DualDashboardService;
import com.accenture.utilities.MediaTypeUtility;

import net.minidev.json.JSONObject;
import net.minidev.json.parser.JSONParser;

@RestController
@RequestMapping("/api")
public class DualDashboardController {
	final Logger logger = LoggerFactory.getLogger(DualDashboardController.class);

	@Autowired
	private ServletContext servletContext;

	@Autowired
	private DualDashboardService dualDashboardService;

	@GetMapping(value = {"/downloadPhaseRetrofit", "/downloadPhaseRetrofit/{phaseValue}"}, produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity<?> downloadFile(@PathVariable(required = false) String phaseValue) {
		try {
			logger.info("Entering downloadFile to download the phase retrofit file.");

			// Writing the file
			byte[] dataBytes = dualDashboardService.getFileBytes(phaseValue);

			return ResponseEntity.ok()
					// Content-Disposition
					.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + "Phase_Retrofit.xlsx")
					// Content-Type
					.contentType(MediaTypeUtility.getMediaTypeForFileName(this.servletContext, "Phase_Retrofit"))
					// Content-Length
					.contentLength(dataBytes.length).body(new ByteArrayResource(dataBytes));
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}

	@PostMapping(value = "/uploadFile")
	public ResponseEntity<?> uploadFile(@RequestParam("file") MultipartFile file) {
		try {
			logger.info("Entering uploadFile to upload the transport request file.");
			
			dualDashboardService.saveFileData(file);

			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping(value = "/getCurrentPhaseDetails/{projectId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getCurrentPhaseDetails(@PathVariable Integer projectId) {
		try {
			logger.info("Entering getCurrentPhaseDetails to get the details of the current phase.");
			
			List<CurrentPhaseDetails> currentDetailsList = dualDashboardService.getCurrentPhaseDetails(projectId);

			if (!CollectionUtils.isEmpty(currentDetailsList))
				return new ResponseEntity<List<CurrentPhaseDetails>>(currentDetailsList, HttpStatus.OK);
			else
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping(value = "/getkpisdata", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> getGraphsData() {
		JsonObject jsonObj = null;

		try {
			logger.info("Entering getGraphsData to build the json to get the graph data.");
			jsonObj = dualDashboardService.getGraphsData();

			if (jsonObj != null)
				return new ResponseEntity<JSONObject>(
						(JSONObject) new JSONParser(JSONParser.MODE_JSON_SIMPLE).parse(jsonObj.toString()),
						HttpStatus.OK);
			else
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}
}
