package com.accenture.dualmaintenancedashboard.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "CurrentPhase_Details")
public class CurrentPhaseDetailsEntity {
	private Integer id;
	private String retrofitPhase;
	private String retrofitTransportRequest;
	private String transportType;

	@Id
	@GenericGenerator(name = "id", strategy = "increment")
	@GeneratedValue(generator = "id")
	@Column(name = "Id")
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Column(name = "Retrofit_Phase")
	public String getRetrofitPhase() {
		return retrofitPhase;
	}

	public void setRetrofitPhase(String retrofitPhase) {
		this.retrofitPhase = retrofitPhase;
	}

	@Column(name = "Retrofit_TransportRequest")
	public String getRetrofitTransportRequest() {
		return retrofitTransportRequest;
	}

	public void setRetrofitTransportRequest(String retrofitTransportRequest) {
		this.retrofitTransportRequest = retrofitTransportRequest;
	}

	@Column(name = "Transport_Type")
	public String getTransportType() {
		return transportType;
	}

	public void setTransportType(String transportType) {
		this.transportType = transportType;
	}
}
