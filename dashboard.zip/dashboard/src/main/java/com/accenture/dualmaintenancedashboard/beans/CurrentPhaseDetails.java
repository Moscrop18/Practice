package com.accenture.dualmaintenancedashboard.beans;

public class CurrentPhaseDetails {
	private String retrofitPhase;
	private String retrofitTransportRequest;
	private String transportType;
	private String status;
	private String completionPerc;

	public String getRetrofitPhase() {
		return retrofitPhase;
	}

	public void setRetrofitPhase(String retrofitPhase) {
		this.retrofitPhase = retrofitPhase;
	}

	public String getRetrofitTransportRequest() {
		return retrofitTransportRequest;
	}

	public void setRetrofitTransportRequest(String retrofitTransportRequest) {
		this.retrofitTransportRequest = retrofitTransportRequest;
	}

	public String getTransportType() {
		return transportType;
	}

	public void setTransportType(String transportType) {
		this.transportType = transportType;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCompletionPerc() {
		return completionPerc;
	}

	public void setCompletionPerc(String completionPerc) {
		this.completionPerc = completionPerc;
	}
}
