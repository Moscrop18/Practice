package com.accenture.constants;

public class AppGenConstants {
	// Gantt chart color constants
	public static final String BLUE_COLOR = "blue";
	public static final String ORANGE_COLOR = "orange";
	public static final String GREEN_COLOR = "green";
	
	// Date format constant
	public static final String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
	
	// Status constants
	public static final String STATUS = "status";
	public static final String SUCCESS = "Success";
	public static final String FAILURE = "Failure";
	
	// OData credentials constants
	public static final String ODATA_SERVICES_URL = "http://devptsaptechnology.accenture.com/sap/opu/odata/sap/ZRETROFIT_ODATA_SRV/entity_ty_ZRETROFITSet?$format=json";
	public static final String ODATA_SERVICES_FILTER_URL = "http://devptsaptechnology.accenture.com/sap/opu/odata/sap/ZRETROFIT_ODATA_SRV/entity_ty_ZRETROFITSet?$filter=Phase eq ";
	public static final String USERNAME = "DEVTKPP";
	public static final String PASSWORD = "Welcome1";
	
	// Color constants
	public static final String COMPLETED_COLOR = "#77bf37";
	public static final String IN_PROGRESS_COLOR = "#5390e0";
	public static final String CONFLICT_COMPLETED_COLOR = "#caf2a7";
	public static final String CONFLICT_IN_PROGRESS_COLOR = "#a1bcf7";
	public static final String NEW_COMPLETED_COLOR = "#abf06e";
	public static final String NEW_IN_PROGRESS_COLOR = "#6d9ced";
	
	// Extension constants
	public static final String XLSX_EXTENSION = "xlsx"; 
	
	// JSON key constants
	public static final String PHASE = "Phase";
	public static final String RETROFIT_TRANSPORT = "RetrofitTransport";
	public static final String OBJECT_TYPE = "ObjectType";
	public static final String OBJECT_NAME = "ObjectName";
	public static final String NEW_CONFLICT = "NewConflict";
	public static final String NEW_TRANSPORT = "NewTransport";
	public static final String RETROFITTED_BY = "RetrofittedBy";
	public static final String RETROFITTED_ON_KEY = "RetrofittedOn";
	public static final String STATUS_KEY = "Status";
	public static final String AUTOMATIC_KEY = "Automatic";
	
	// Symbol constants
	public static final String PARTIAL_RETROFITTED_SYMBOL = "@02@";
	public static final String RETROFITTED_SYMBOL = "@01@";
	public static final String AUTOMATION_SYMBOL = "@08@";
	public static final String SEMI_AUTOMATION_SYMBOL = "@09@";
	public static final String MANUAL_SYMBOL = "@0A@";
	
	// Status constants
	public static final String PARTIAL_RETROFITTED = "Partially Retrofitted";
	public static final String RETROFITTED = "Retrofitted";
	public static final String YET_TO_RETROFIT = "Yet To Retrofit";
	public static final String NO_ACTION_REQUIRED = "No Action Required";
	public static final String AUTOMATIC = "Automatic";
	public static final String SEMI_AUTOMATIC = "Semi-Automatic";
	public static final String MANUAL = "Manual";
	public static final String NEW_STR = "New";
	public static final String CONFLICT_STR = "Conflict";
	public static final String COMPLETED = "Completed";
	public static final String IN_PROGRESS = "In-Progress";
	
	// Map key constants
	public static final String OBJ_COUNT = "objectCount";
	public static final String CONFLICT_COUNT = "conflictCount";
	public static final String NEW_COUNT = "newCount";
	public static final String AUTOMATIC_CONFLICT_COUNT = "automaticConflictCount";
	public static final String SEMI_AUTOMATIC_CONFLICT_COUNT = "semiAutomaticConflictCount";
	public static final String MANUAL_CONFLICT_COUNT = "manualConflictCount";
	public static final String AUTOMATIC_NEW_COUNT = "automaticNewCount";
	public static final String SEMI_AUTOMATIC_NEW_COUNT = "semiAutomaticNewCount";
	public static final String MANUAL_NEW_COUNT = "manualNewCount";
	public static final String COLOR = "color";
	public static final String NEW_COLOR = "newColor";
	public static final String CONFLICT_COLOR = "conflictColor";
	
	// Json key constants
	public static final String NAME = "name";
	public static final String Y_NAME = "y";
	public static final String DRILLDOWN = "drilldown";
	public static final String SERIES = "series";
	public static final String COLOR_BY_POINT = "colorByPoint";
	public static final String DATA = "data";
	public static final String ID = "id";
	public static final String KEYS = "keys";
	
	// Dual maintenance activity id
	public static final Integer ACTIVITY_ID = 22;	
	public static final String PHASE_1_VAL = "Phase1";
	public static final String COMPLETION_PERCENTAGE = "100%";
	
	// Json value constants
	public static final String ID_CONST = "_id";
	public static final String GRAPH_1_HEADING = "Retrofit Transport Phase-Wise Overview";
	public static final String GRAPH_2_HEADING = "Object New/Conflict Status";
	public static final String GRAPH_3_HEADING = "Object Automation Status";
	public static final boolean TRUE = true;
}
