package com.accenture.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S4ConversionDashboardApplicationTests {

	@Test
	void contextLoads() {
	}

}
