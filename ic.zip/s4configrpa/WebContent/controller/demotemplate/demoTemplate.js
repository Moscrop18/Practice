angular.module('yapp').controller('DemoCtrls', ["ngDialog","$filter","Upload","$scope","$rootScope","$http","$mdDialog","$mdMedia", "$location", "$timeout", "$window","$ocLazyLoad", function(ngDialog,$filter,Upload,$scope,$rootScope,$http,$mdDialog,$mdMedia, $location, $timeout, $window,$ocLazyLoad) {
	$ocLazyLoad.load(controllerName+'/demotemplate/demoTemplate.js?ver='+version);
	var noAuth = "false";
/*	var cookie = document.cookie;
		var cookieAuthParams = cookie.split(';');
		for (var cp1 = 0,arrLen = cookieAuthParams.length; cp1 < arrLen ; cp1++) {*/
			/*if (cookieAuthParams[cp1].split('=')[0].trim() == "adminAuth" && cookieAuthParams[cp1].split('=')[1].trim() == "true") {
				noAuth = "true"
			}*/
			if ($rootScope.adminAuth == "true") {
				noAuth = "true"
			}
	/*		if($rootScope.appValidity == undefined){
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userDetails") {
					$rootScope.userValidation = cookieAuthParams[cp1].split('=')[1];
					console.log($rootScope.userValidation.role);
					
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userRole") {
					$rootScope.userRole = cookieAuthParams[cp1].split('=')[1];
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "roleId") {
					$rootScope.roleId = cookieAuthParams[cp1].split('=')[1];
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userName") {
					$rootScope.username = cookieAuthParams[cp1].split('=')[1];
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userFirstName") {
					 $rootScope.userFirstName = cookieAuthParams[cp1].split('=')[1];
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userLastName") {
					$rootScope.userLastName = cookieAuthParams[cp1].split('=')[1];
				}
		  }
		}*/
	if (noAuth == "false") {
			$location.path('/loginPage');
		}
	$rootScope.selectedTreeviewData=[];  
	 if($rootScope.selectedScopeData == undefined)
     {
            $rootScope.selectedScopeData = [];
     } 
	  angular.copy($rootScope.selectedScopeData,$rootScope.selectedTreeviewData);


		var stuff =[]; 
		 $http.post("/" + servicePrefix + "/rest/configSrv/getTargetSystemDetails", $rootScope.sessionInputObj).then(function mySucces(response) {
			 
		        if (response.data.dataList !=null) {
		        	 if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
		       	      		$rootScope.checkAuthorization();
		       	      	}else{
		            var source = response.data.dataList;
		            var result = []; 
		            	 for (var i = 0,arrLen = source.length; i < arrLen ; i++) {
		            		var downloadFilesPath = {
		                         "destinationName": source[i]+"-"+"S4 HANA"
		                
		                     };
		                    	result.push(downloadFilesPath);
		                     
		                 }
		            	 
		            	 $rootScope.sourceSystem = result; 
		       	      	}
		        }
		 	   
		 	   
		    }, function myError(response) {
		        //            $scope.userValidation = response.statusText;
		    });  
    
	
    $http({
    	method: 'POST',
    	url:"/" + servicePrefix + "/rest/imgHierarchySrv/viewImgHierarchy",
    	data : $rootScope.sessionInputObj
    }).then(function(response) {
	    if(response.status === 200){
	    	
	    	  if(response.data != null){
	    		  if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
	       	      		$rootScope.checkAuthorization();
	       	      	}else{
	    	var responsedata=[];
	        responsedata.push(response.data);
	        $rootScope.listData = responsedata;	
	        stuff.push(response.data);
	       	      	}
	    	  }else{
	    	      ngDialog.openConfirm({
	                    template: '<p>' +"No records found!"+ '</p>',
	                    plain: true,
	                    scope: $scope,
	                    closeByDocument: true,
	                    closeByEscape: true,
	                    showClose: true,
	                    height:120,
	                    width: 350,
	                    className:'ngdialog-theme-default CLASS_2'
	                });  
	    	  }
	    } else {
	        ngDialog.openConfirm({
                template: '<p>' +"No records found!"+ '</p>',
                plain: true,
                scope: $scope,
                closeByDocument: true,
                closeByEscape: true,
                showClose: true,
                height:120,
                width: 350,
                className:'ngdialog-theme-default CLASS_2'
            }); 
	    }
	}); 
    

    $scope.itemsByPage=15;
	 $scope.arrayImg =[];
	 $scope.fileNameList =[];
	 $scope.currentPage = 1;
	 var downloadCount = 0;
		
		$scope.articlesPerPage = 6;
	$scope.startDemo = function(){
    	$rootScope.isclientspecific = false;
    	ngDialog.openConfirm({
            template: 'popupcreateTmpl.html?ver='+version,
            preCloseCallback:function(){            
            	if($rootScope.validClose == undefined){ 
            		$rootScope.selectedScopeData = $rootScope.selectedTreeviewData;	 
	   	       		$rootScope.scopevalueArray=[];
	   	       		 for(var x = 0,arrLen = $rootScope.selectedScopeData.length; x < arrLen ; x++){
	   	          		  if($rootScope.selectedScopeData[x].enabled === 1){
	   	          		  if(x == 0)
	   	          		  { 	
	   	          			
	   	          			  $rootScope.scopevalueArray.push($rootScope.selectedScopeData[x].imgId);
	   	          		}
	   	          		  else{
	   	          			
	   	          			  $rootScope.scopevalueArray.push($rootScope.selectedScopeData[x].imgId);
	   	          			  }
	   	          	  }
	   	          	  }
   	       		 
            	}else{
            		$rootScope.validClose = undefined;
            	}
            	
            },
            controller:'DemoCtrl',
            scope: $scope,
            closeByDocument: false,
            closeByEscape: false,
            showClose: true,
            height: "auto",
            width: 800
        });
    };

    var self = this;
    
    self.stuff = stuff;
  
  self.changeCallback = function(node) {
	    self.lastChangedNode = node;
		
		
        $scope.selectedMethod(node,node.selected); 

        $rootScope.scopevalue = "";
        $rootScope.scopevalueArrayData=[];
        $rootScope.downloadScopeList = [];	
        var scopeArray1 = {};
        $rootScope.selectedScopeData.sort(function(a, b) {
                 return parseInt(a.sequence) - parseFloat(b.sequence);
             });
        
     for(var x = 0,arrLen = $rootScope.selectedScopeData.length; x < arrLen ; x++){
               if($rootScope.selectedScopeData[x].enabled =="1"){
               if(x == 0){
                     $rootScope.scopevalue = $rootScope.selectedScopeData[x].imgId;
                     $rootScope.scopevalueArray.push($rootScope.selectedScopeData[x].imgId);
                     if(node.children !== null && node.children.length > 0)
                 	{
                 	 	$rootScope.selectedimg.push(node.id);
                 	}
                    scopeArray1.imgId = $rootScope.selectedScopeData[x].imgId;
     				scopeArray1.imgDesc = $rootScope.selectedScopeData[x].imgDescription;
     				scopeArray1.seqNumber =  $rootScope.selectedScopeData[x].sequence;
     				scopeArray1.bytes = null;
     				scopeArray1.resError = "Download Not yet Started";
     				scopeArray1.scopeAvilableIcon = "glyphicon glyphicon-remove";
     				scopeArray1.downloadStatusIcon = "glyphicon glyphicon-remove";
     				 $rootScope.downloadScopeList.push(scopeArray1);	 
     				scopeArray1={};
               }
               else{
               
                     $rootScope.scopevalue = $rootScope.scopevalue.concat(";",$rootScope.selectedScopeData[x].imgId);
                     $rootScope.scopevalueArray.push($rootScope.selectedScopeData[x].imgId); 
                     if(node.children !== null && node.children.length > 0)
                 	{
                 	 	$rootScope.selectedimg.push(node.id);
                 	}
                     scopeArray1.imgId = $rootScope.selectedScopeData[x].imgId;
     				scopeArray1.imgDesc = $rootScope.selectedScopeData[x].imgDescription;
     				scopeArray1.seqNumber =  $rootScope.selectedScopeData[x].sequence;
     				scopeArray1.bytes = null;
     				scopeArray1.resError = "Download Not yet Started";
     				scopeArray1.scopeAvilableIcon = "glyphicon glyphicon-remove";
     				scopeArray1.downloadStatusIcon = "glyphicon glyphicon-remove";
     				 $rootScope.downloadScopeList.push(scopeArray1);	 
     				scopeArray1={};
               }
              
                       
        }
        }

       if (node.children != null) {
         $scope.$broadcast('changeChildren', node);
       }
	  };
	  $scope.save=function(){  	  
    	  $rootScope.validClose = true;
	  		ngDialog.close();
	  		
	  	};
	  	$scope.onCancel=function(){
	  	
	  		ngDialog.close();
	  		
	  	};
	  	
	    $scope.$on('changeChildren', function(event, parentItem) {
            var child, i, len, ref, results;
            ref = parentItem.children;
            results = [];
            for (i = 0, len = ref.length; i < len; i++) {
              child = ref[i];
              if(child.enabled== "1"){
              child.selected = parentItem.selected;
              }
              if (child.children != null) {
                results.push($scope.$broadcast('changeChildren', child));
              } else {
                results.push(void 0);
              }
            }
            return results;
          });
		   $scope.selectedMethod = function(item,selectedValue){
            var bData = {};
            if(item.imgId.length > 0){
                   bData.id = item.id;
                   bData.imgId = item.imgId;
                   bData.imgDescription = item.imgDescription.split("_")[1];
                   bData.sequence = item.sequence;
                   bData.enabled = item.enabled;
                   bData.fileName = "";
                   bData.filepath = "";
                   bData.isMasterData = item.isMasterData;
                   bData.logs = [];
                   bData.status = "status-pending";
                   if(selectedValue === true){


                          index = -1;
                          for(var a= 0,arrLen = $rootScope.selectedScopeData.length;a< arrLen ;a++){
                               if($rootScope.selectedScopeData[a].imgId == bData.imgId){
                                      index = a;
                                      break;
                               }
                          }
                          
                          if (index == -1) {
                                if(bData.enabled=="1"){
                                $rootScope.selectedScopeData.push(bData);
                                
                                }

                              }
                          
                   }
                  
                   else if(selectedValue === false){

                          index = -1;
                          for(var a= 0,arrLen = $rootScope.selectedScopeData.length;a< arrLen ;a++){
                               if($rootScope.selectedScopeData[a].imgId == bData.imgId){
                                      index = a;
                                      break;
                               }
                          }
                          

                          if (index > -1) {
                                $rootScope.selectedScopeData.splice(index, 1);
                      
                              }
                   }
            }else {
                   for(var x = 0,arrLen = item.children.length;x < arrLen ; x++){
                   $scope.selectedMethod(item.children[x],selectedValue);
                   }
            }
            
            
         };
        
         $scope.initCheckbox = function(item, parentItem) {
             
               item.selected=$scope.validatecheck(item);
               
               if(item.selected)
            {
             var allChecks = true;
             for (var i in parentItem.children) 
             {
                          if (!parentItem.children[i].selected) {
                                        allChecks = false;
                                        break;
                                 }
             }
                          if (allChecks) {
                                                             parentItem.selected = true;
                                                      }
                                 else {
                                                      parentItem.selected = false;
                                        }

            }
               return item.selected;
             
            };
            $scope.validatecheck=function(item)
            {
               
               var selectedValue=true;
               var aIndex = $rootScope.scopevalueArray.indexOf(item.imgId);
               if(aIndex>-1)
                      { 
                      
                      var bData = {};
                      if(item.imgId.length > 0){
                             
                             bData.imgId = item.imgId;
                             bData.imgDescription = item.imgDescription;
                             bData.sequence = item.sequence;
                             bData.enabled = item.enabled;
                             bData.fileName = "";
                             bData.filepath = "";
                             bData.isMasterData = item.isMasterData;
                             bData.logs = [];
                             bData.status = "status-pending";
                             if(selectedValue === true){


                                    index = -1;
                                    for(var a= 0,arrLen = $rootScope.selectedScopeData.length;a< arrLen ;a++){
                                         if($rootScope.selectedScopeData[a].imgId == bData.imgId){
                                                index = a;
                                                break;
                                         }
                                    }
                                    
                                    if (index == -1) {
                                          if(bData.enabled=="1"){
                                          $rootScope.selectedScopeData.push(bData);
                                          }

                                        }
                                    
                             }
                            
                             else if(selectedValue === false){

                                    
                                    index = -1;
                                    for(var a= 0,arrLen = $rootScope.selectedScopeData.length;a< arrLen ;a++){
                                         if($rootScope.selectedScopeData[a].imgId == bData.imgId){
                                                index = a;
                                                break;
                                         }
                                    }
                                    

                                    if (index > -1) {
                                          $rootScope.selectedScopeData.splice(index, 1);
                                        }
                             }
                      }else {
                             for(var x = 0,arrLen = item.children.length;x < arrLen ; x++){
                             $scope.selectedMethod(item.children[x],selectedValue);
                             }
                      }
                      
                      return true
                      }
               else
               return false;
               
            };
            $scope.createTemplate = function(){
   	    	 if($scope.selectedSysId == null || $scope.selectedSysId ==undefined){
           		 
           		 $scope.validMeaggse = "Please select system"; 
           		 $timeout(function () { $scope.validMeaggse = ""; }, 2000); 
           		 
           		 
           		 
           		 
           	 }else{
           		 
           		 $scope.validMeaggse="";
           		    $rootScope.downloadIndMsg = "Downloading "+(downloadCount+1)+" out of "+$rootScope.selectedScopeData.length;
                       $scope.arrayImg=[];
                       $scope.fileNameList =[];
                       $scope.count=0;
                                      var url = "/" + servicePrefix + "/rest/autoConfigSrv/emptyTemplateDownload";
                      var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
                  var targetData= $scope.selectedSysId;
                  var res = targetData.destinationName.split("-");
                  var srcSystem =res[0];
                  var systemType =res[1];
                  
                      var params = {"imgHierarchyCustomDto":{"imgId":"","imgDesc":"","seqNumber":""},
                                     "srcSystem":"","systemType":""};
//                      var params = {};
                      params.imgHierarchyCustomDto.imgDesc =  $rootScope.selectedScopeData[downloadCount].imgDescription;
                      params.imgHierarchyCustomDto.seqNumber = $rootScope.selectedScopeData[downloadCount].sequence;
                      params.imgHierarchyCustomDto.imgId = $rootScope.selectedScopeData[downloadCount].imgId;
                      params.imgHierarchyCustomDto.isMasterData = $rootScope.selectedScopeData[downloadCount].isMasterData;
                      params.srcSystem = srcSystem;
                      params.systemType = systemType;
                      params.sessionInputDTO = $rootScope.sessionInputObj;	

                      
                      $rootScope.downloadScopeList[downloadCount].resError = "Download Started";//Message Change while click download - 29-June-2017
                      
                      $mdDialog.show({
                          controller: function($scope, $mdDialog){
                          $scope.isLoading = true;
                          $scope.indicatorMsg = $rootScope.downloadIndMsg;
                          },
                          templateUrl: 'view/config/DwnloadBusyInd.html?ver='+version,
                          parent: angular.element(document.body),
                          clickOutsideToClose: false,
                          fullscreen: useFullScreen,
                          escapeToClose: false,
                      })
                      .then(function(answer) {
                      }, function() {
                      });
                      $http.post(url,params).then(function(responseData){
                    	  if(responseData.data.resMessageDto != null && responseData.data.resMessageDto.message == serviceMessage){
                 	      		$rootScope.checkAuthorization();
                 	      	}else{
                                     var responseData = responseData.data;
                                     $rootScope.downloadScopeList[downloadCount].targetFilePath = responseData.targetFilePath;
                                     $rootScope.downloadScopeList[downloadCount].bytes = responseData.bytes;
                                     $rootScope.downloadScopeList[downloadCount].resError = responseData.resError;
//                                     $rootScope.downloadScopeList[downloadCount].scopeAvilable = responseData.scopeAvilable;
                                     $rootScope.downloadScopeList[downloadCount].scopeAvilableIcon = responseData.scopeAvilableIcon;
//                                     $rootScope.downloadScopeList[downloadCount].downloadStatus = responseData.downloadStatus;
                                     $rootScope.downloadScopeList[downloadCount].downloadStatusIcon = responseData.downloadStatusIcon;
                                     
                                     /*if(!responseData.downloadStatus){
                                           $rootScope.downloadButtondisabled  = false;     
                                     }*/
                                      
                                     $mdDialog.cancel();
                                     downloadCount++;
                                      if( downloadCount < $rootScope.selectedRootScopeDatas1.length){
                                          if((downloadCount/$scope.articlesPerPage)> 0){
                                                  $scope.currentPage = Math.floor(downloadCount/$scope.articlesPerPage)+1;
                                          }
                                          $scope.createTemplate();
                                      }else{
                                        $scope.isZipFile=true;
                                        for(var i =0,arrLen = $rootScope.downloadScopeList.length; i< arrLen ;i++){
                                             if($rootScope.downloadScopeList[i].bytes !=  null){
                                           	   var fileName =  $rootScope.downloadScopeList[i].imgDesc;
                                                  var seqNumber =  $rootScope.downloadScopeList[i].seqNumber;
                                                  var byteData =  $rootScope.downloadScopeList[i].bytes;
                                                  var isMasterData = $rootScope.downloadScopeList[i].isMasterData;
                                                  var fileBytes = base64ToArrayBuffer(byteData);
                                                  if(isMasterData != null && isMasterData == "Y"){
                                               	   $scope.fileNameList.push(fileName + ".xlsx");
                                                      saveByteArray([fileBytes], fileName+".xlsx");
                                                  }else{
                                               	   $scope.fileNameList.push(seqNumber + "_" + fileName + ".xlsx");
                                                      saveByteArray([fileBytes], seqNumber+"_"+fileName+".xlsx");
                                                  }    
                                              }
                                         }
                                         $scope.generateZipFile();
                                      }
                      			}
                      }) ,(function(data){
//                       $scope.errorResponse(data);
                                     $rootScope.downloadScopeList[downloadCount].resError = "Download Failed due to service failure.."
//                                  console.log("ERROR");
                                     $mdDialog.cancel();
                                     downloadCount++;
                                     
                       if(downloadCount < $rootScope.selectedScopeData.length){
                                     if((downloadCount/$scope.articlesPerPage)> 0){
                                         $scope.currentPage = Math.floor(downloadCount/$scope.articlesPerPage)+1;
                                     }
                                     $scope.createTemplate();
                          }
                      else{
                                                     $scope.isZipFile=true;
                                     for(var i =0,arrLen = $rootScope.downloadScopeList.length; i< arrLen ;i++){
                                   	  if($rootScope.downloadScopeList[i].bytes !=  null){
                                                      var fileName =  $rootScope.downloadScopeList[i].imgDesc;
                                                      var seqNumber =  $rootScope.downloadScopeList[i].seqNumber;
                                                      var byteData =  $rootScope.downloadScopeList[i].bytes;
                                                      var isMasterData = $rootScope.downloadScopeList[i].isMasterData;
                                                      var fileBytes = base64ToArrayBuffer(byteData);
                                                      if(isMasterData != null && isMasterData == "Y"){
                                                   	   $scope.fileNameList.push(fileName + ".xlsx");
                                                          saveByteArray([fileBytes], fileName+".xlsx");
                                                      }else{
                                                   	   $scope.fileNameList.push(seqNumber + "_" + fileName + ".xlsx");
                                                          saveByteArray([fileBytes], seqNumber+"_"+fileName+".xlsx");
                                                      }
                                                                
                                                     }
                                      }
                                     $scope.generateZipFile();
                                      
                       }
                      });
           	 }
           
               
            };
            $scope.generateZipFile=function(){
              	 var zip = new JSZip();
              	 var count = 0;
              	 var count1 = 0;
   			 $scope.arrayImg.forEach(function(url){
              		 //console.log(url)
              		 
              		  var filename =  $scope.fileNameList[count];
              		  //i++;
              		  count++;
              		  // loading a file and add it in a zip file
              		  JSZipUtils.getBinaryContent(url, function (err, data) {
              		     if(err) {
              		        throw err; // or handle the error
              		     }
              		     zip.file(filename, data, {binary:true});
              		     if (count == $scope.arrayImg.length) {
              		       /*var zipFile = zip.generate({type: "blob"});
              		       saveAs(zipFile, "examples.zip");*/
              		       
              		    zip.generateAsync({type:"blob"}).then(function(content) {
              		     // see FileSaver.js
              		    count1++;
             		     if (count1 == $scope.arrayImg.length) 
             		    	 saveAs(content, "BaseTemplates.zip");
              		 });
              		     }
              		  });
              		});
   		  		
   		        };
}]);