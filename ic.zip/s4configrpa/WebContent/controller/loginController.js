angular.module('yapp').controller('LoginPageController', [ '$scope', '$rootScope', '$state', '$stateParams', '$location', '$http', '$mdDialog', '$mdMedia','ngDialog', function($scope, $rootScope, $state, $stateParams, $location, $http, $mdDialog, $mdMedia,ngDialog) {
	
	$rootScope.login_disabled = false;
	
	if(showBrowserMsg == 'true'){
		document.getElementById("browserAlert").style.display = "inline-block";
	}
	else{
		document.getElementById("browserAlert").style.display = "none";
	}
	if($rootScope.showLogsExportData){
        $location.path("/ConfigHeader/configExecute");
	    //$rootScope.reportData = [];
     }

	 $http.post("/" + servicePrefix + "/rest/adminSrv/getVersion").then(function(response){
		 version = response.data.version;
		   $http.post("/" + servicePrefix + "/rest/adminSrv/getSecurityQuestions/").then(function executeSuccess(response) {
   	    	if( response.data.resMessageDto.msgType == "Success"){
   	    	$rootScope.securityQAList = response.data.quesListDto;
   	    	}
   	    	/*else{
   	    		ngDialog.openConfirm({
                       template: '<p>' + "Something went wrong. Please try again after sometime." +'</p>',
                       plain: true,
                       scope: $scope,
                       closeByDocument: true,
                       closeByEscape: true,
                       showClose: true,
                       height:120,
                       width: 350,
                       className:'ngdialog-theme-default CLASS_2'
                   });
   	    	}*/
   	    });		   
    });
    	
	$rootScope.appValidity = true;//Browser Refresh 
    $rootScope.sourcesystemEnabled = true;
    $rootScope.targetsystemEnabled = false;
    $rootScope.modOptionsEnabled = true;
    $rootScope.scopevalue = "";
    $rootScope.myFile = undefined;
    $rootScope.filePathList = undefined;
    $rootScope.executionLogData = undefined;
    $rootScope.scopeList = undefined;
    $rootScope.scopevalueArrays=[];
    $rootScope.scopevalueArrays1=[];
    $rootScope.selectedScopeData = [];
    $rootScope.selectedBPData = [];
    if( $rootScope.selectedimg == undefined)
    $rootScope.selectedimg = [];
    $rootScope.FileList = [];
    $rootScope.dependencyResponse = [];
    $rootScope.initServiceFlag = true;
	$rootScope.scopevalues = "";
	$rootScope.scopevaluesData1 = "";
	$rootScope.scopevaluesData = "";
	$rootScope.userFirstName = "";
	$rootScope.userLastName = "";
	$rootScope.roleId ="";
	$rootScope.tableContent="";
	$rootScope.tableClientContent="";
	$rootScope.tableUserContent="";
	 $rootScope.mastertree = false;
	 $rootScope.clientimghierarchy = true;
		//////added by sarfaraz  rootscope array/
	$rootScope.clienthierarchy = false;
	$rootScope.isclientspecific = false;
	$rootScope.OmId = "";
	$rootScope.scopevalueArray=[];
	$rootScope.scopeDataArray=[];
	$rootScope.list=[];
	$rootScope.scopevalueArrayid = [];
	$rootScope.scopevalueArrayData=[];
	$rootScope.clienthierarchydiv = false;
	$rootScope.clienthierarchymsg = "";
	  if(!$rootScope.showLogsExportData)
			$rootScope.executionLogsData = [];
	 $rootScope.isclienthierarchyexists = false;
	// $rootScope.showLogsExportData = false;
	$rootScope.showExportLogs = true;
	$rootScope.retryExecution = false;
	$scope.manageProject = "USER DETAILS";
	$scope.manageUser = "Manage User";
	$rootScope.createTemplateUser = false;
	$rootScope.importtempUser = false;
	$rootScope.downloadtempUser = false;
	$rootScope.mappedtargetSystem = false;
	if($rootScope.selectedIds == undefined)
	$rootScope.selectedIds = [];
	$rootScope.treeData = [];
	$rootScope.DownloadFileData = [];
	$rootScope.treeDataPath = [];
	$rootScope.downloadDataList = [];
	$rootScope.downloadScopeList = [];
	$rootScope.selectedRootScopeData = [];
	$rootScope.selectedRootScopeDatas = [];
	$rootScope.selectedRootScopeDatas1 = [];
	$rootScope.implType = 1;
	$rootScope.viewExecutionData = [];
	$rootScope.reExecutionData = [];
	$rootScope.viewScopeData = [];
	$rootScope.systemID = "";
	//$rootScope.sapUserID = "";
	$rootScope.sapDestination = "";
	/*Added for reportng*/
	$rootScope.reportingTile = false;
	$rootScope.configDownloadTemplate = false;
	$rootScope.logsEnablement = false;
	$rootScope.executionSummary = [];   
	$rootScope.sourceValue = null;
	$scope.exportDetailLogs = [];
	$scope.bytesData = null;
	$rootScope.createimg = false;
	//$rootScope.eSapUserId = null;
	$rootScope.eSapPassword = null;
	$rootScope.sessionInputObj = {};
	//adding for showing proper message when TR overide option is not selected in PA
	$rootScope.trOverrideEnable = false;
	$rootScope.trOverrideEn = false;
	//Clearing the SAP credentials on Logout
	$rootScope.sapUserID = "";
	$rootScope.sapPassword = "";
	$rootScope.customDestFlagFrDwnld=""; // Added by Veena
	/*Defining count to track the number of invalid attempts.*/
	var countofInvalidAttempts = 0;
	/*Account is unlocked at securityQA stage*/
	 $scope.isAccLocked = false;  
	 	$rootScope.helpDocArr = [];
	 	
	 	
	 $rootScope.download = false;
	 $rootScope.securityQA = {};
	 $rootScope.securityQA.oldpassword = "";
	 $rootScope.securityQA.newpassword = "";
	 if($rootScope.securityQA.answer1 == undefined){
		 $rootScope.securityQA.answer1 = "";
		 $rootScope.securityQA.answer2 = "";
	 }
	 //$rootScope.forgotPassword = true;
	// $rootScope.SecQAUpdated = false;
	 $rootScope.SecQAUpadtedObj = {};
	 if($rootScope.SecQAUpadtedObj.Done == undefined)
	 $rootScope.SecQAUpadtedObj.isDone = false;
	 if($rootScope.attempts == undefined){
	 $rootScope.attempts = 0;
	 }
	 $rootScope.isLoginAgain = true;
	 $scope.error = "Invalid credentails!! Please enter correct username and/or password.";
    $rootScope.sourceSystem = {
        "values": []
    };

    $rootScope.targetSystem = {
        "values": []
    };
    
    $rootScope.modOptions = {
    		 "value": "Download", 
    	     "values": ['Download','Upload'] 
        };
	$rootScope.modTypes = {
	   		 "value": "Automated with intervention", 
	   	     "values": ['Automated without intervention','Automated with intervention'] 
	       };
	$rootScope.hierarchyTypes = {
	   		 "value": "", 
	   	     "values": ['Business Process','IMG'] 
	       };
    $rootScope.hvessourceSystem = {
            "values": []
        };
    $rootScope.message = "Success";
    $scope.loginerror = false;
    $rootScope.blnMockData = false;
	$rootScope.sourceSysData = [];
	$rootScope.targetSysData = [];
    var login_user = $rootScope.username;
    var login_pwd = $rootScope.password;
    $rootScope.logsExportOptions = {};
    $scope.hideErrorMsg = function() {
        $scope.loginerror = false;
    }
    $rootScope.reportData = [];
	$rootScope.fileUploadMultipleStatus = false;
	$rootScope.selectedTab = null;
	$rootScope.previouslySelectedTab = null;
	$rootScope.scopeListError = [];
    //Adding code to close dialog and infinite progress bar
	$rootScope.isManagetemplate = false;
	$rootScope.masterTreeResponse = [];
	$scope.expandNodes = false;
	$rootScope.exeReqCount = 0; 
	//For New Business Process Hierarhy
	$rootScope.hierarchyTypeEnabled = true;
	$rootScope.scopevalue = "";
	
	$rootScope.uploadedScopes = [];
	$scope.formSubmit = function() {    
		$rootScope.login_disabled = true;
        $rootScope.username = $scope.username;
        $rootScope.password = $scope.password;

        var empty = "";
        var myDate = new Date();
        myDate.setHours(myDate.getHours() + 1);
        $rootScope.adminAuth = "false";
        $rootScope.configAuth = "false";
      
        if($rootScope.attempts <=5)	 {

   		 var overlay = document.getElementById("overlay");
   	     var popup = document.getElementById("busy");
   	     overlay.style.display = "block";
   	     popup.style.display = "inline-block";
   	     $http.post("/" + servicePrefix + "/rest/adminSrv/getSaltValue").then(function(response){
   		 $scope.saltValue = response.data.salt;
   		      
   		 var params = {
         		userId : $rootScope.username,
         		toolPwd : sha256(sha256($rootScope.password) + $scope.saltValue),
         		browserId : (Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15))
         }
   		
   		//$rootScope.password = sha3_512(sha3_512($rootScope.password)+saltValue);
       
        $http.post("/" + servicePrefix + "/rest/adminSrv/validateRole/",params
        ).then(function executeSuccess(response) {

       	 var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
		 var overlay = document.getElementById("overlay");
	     var popup = document.getElementById("busy");
	     overlay.style.display = "none";
	        busy.style.display = "none";
        	$rootScope.login_disabled = false;
            $rootScope.userValidation = response.data;
            $rootScope.sessionInputObj = response.data.sessionInputDTO;
            $scope.userValidation = $rootScope.userValidation;
            $rootScope.secQAUpdated = response.data.secQAUpdated;
            $rootScope.attempts = response.data.attempts;
         
            $scope.validateRole();
       }, function executeError(response) {
//        	$mdDialog.cancel();
//        	$mdDialog.hide();
        	//ngDialog.close();
        	 var overlay = document.getElementById("overlay");
    	     var popup = document.getElementById("busy");
    	     overlay.style.display = "none";
    	        busy.style.display = "none";
        	$rootScope.login_disabled = false;
            $scope.userValidation = response.statusText;
        });
        });
        }
    $scope.validateRole = function(){
        
            if ($scope.userValidation.credentialValidation == "true") {
                $scope.loginerror = false;
                $scope.error = $scope.userValidation.message;
                $rootScope.userRole = $scope.userValidation.role;
                $rootScope.roleId =  $rootScope.userRole;
                if($rootScope.userValidation.validatyDays <= 15 ){
                	ngDialog.openConfirm({
                        template: '<p>' + "User validity will expire in " +$rootScope.userValidation.validatyDays  + "day(s) , please contact Tool Administrator to extend the validity period" +'</p>',
                        plain: true,
                        scope: $scope,
                        closeByDocument: true,
                        closeByEscape: true,
                        showClose: true,
                        height:120,
                        width: 350,
                        className:'ngdialog-theme-default CLASS_2'
                    });
                	
                }
               
                if ($scope.userValidation.role == "TAdmin") {
                    $rootScope.adminAuth = "true";
                    $rootScope.configAuth = "false";
                    $rootScope.createTemplateUser = true;
      			  	$rootScope.importtempUser = true;
      			  	$rootScope.downloadtempUser = true;
                 
                    $rootScope.userFirstName = $rootScope.userValidation.firstName;
                	$rootScope.userLastName = $rootScope.userValidation.lastName;
                	 $rootScope.roleId =  $rootScope.userRole;
                   
                    $location.path("/mainPage/tableClient");
                }else if ($scope.userValidation.role == "Config") {
                    $rootScope.adminAuth = "false";
                    $rootScope.configAuth = "true";
                    $rootScope.createTemplateUser = false;
      			  	$rootScope.importtempUser = false;
                    $rootScope.downloadtempUser = true;
                  $rootScope.userFirstName = $rootScope.userValidation.firstName;
                	$rootScope.userLastName = $rootScope.userValidation.lastName;
                	$location.path("/IndustryType");
                }else if ($scope.userValidation.role == "PAdmin") {
                	 $rootScope.adminAuth = "true";
                     $rootScope.configAuth = "false";
                     $rootScope.userFirstName = $rootScope.userValidation.firstName;
                 	 $rootScope.userLastName = $rootScope.userValidation.lastName;
                     $location.path("/mainPage/tableClient");
                }else if ($scope.userValidation.role == "TempAd") {
               	 	$rootScope.adminAuth = "true";
                    $rootScope.configAuth = "false";                    
                    $rootScope.createTemplateUser = true;
      			  	$rootScope.importtempUser = false;
                    $rootScope.downloadtempUser = false;                    
                    $rootScope.userFirstName = $rootScope.userValidation.firstName;
                	 $rootScope.userLastName = $rootScope.userValidation.lastName;
                    $location.path("/mainPage/manageTemplate");
               }
                else if ($scope.userValidation.role == "TempCr") {
               	 	$rootScope.adminAuth = "true";
                    $rootScope.configAuth = "false";                    
                    $rootScope.createTemplateUser = true;
      			  	$rootScope.importtempUser = false;
                    $rootScope.downloadtempUser = false;                    
                    $rootScope.userFirstName = $rootScope.userValidation.firstName;
                	 $rootScope.userLastName = $rootScope.userValidation.lastName;
                    $location.path("/mainPage/manageTemplate");
               }else {
                    $scope.loginerror = true;
                    $scope.error = $scope.userValidation.message;
                }
            } else if ($scope.userValidation.credentialValidation == "false") {
                $scope.loginerror = true;
                $scope.error = $scope.userValidation.message;
                countofInvalidAttempts++;
                
            } else if ($scope.userValidation.status == "DBError") {
                $scope.loginerror = true;
                $scope.error = $scope.userValidation.message;
            }
        }     
    };
    
    $rootScope.logoutSrv = function(){
		ngDialog.close();
		var input = {
    			sessionInputDTO : $rootScope.sessionInputObj,
    			userID : $rootScope.username,

    	}
    	$http.post("/" + servicePrefix + "/rest/adminSrv/logOutSrv",input).then(function(response){
       });
		 $state.go('loginPage');
		
    	//$state.transitionTo('loginPage');
		$rootScope.initalCheck = undefined;
		$rootScope.username = "";
        $rootScope.password = "";
        $rootScope.showLogsExportData = false;
        $rootScope.adminAuth  = "";
        $rootScope.fileUploadAuth = "";
        $rootScope.executeAuth = "";
        $rootScope.configAuth = "";
        $rootScope.fileDownloadAuth = "";
        $rootScope.sapUserID = "";
    	$rootScope.sapPassword = "";
    };
    $rootScope.checkAuthorization = function(){
    	ngDialog.close();
		  $location.path("/loginPage");
		  ngDialog.openConfirm({
             template: '<p>' +"Your session has expired/Invalid Request. <br> Please Login again"+ '</p>',
             plain: true,
             scope: $scope,
             closeByDocument: true,
             closeByEscape: true,
             showClose: true,
             height:120,
             width: 350
         });
   	  $rootScope.username = "";
         $rootScope.password = "";
         $rootScope.showLogsExportData = false;
         $rootScope.adminAuth  = "";
         $rootScope.fileUploadAuth = "";
         $rootScope.executeAuth = "";
         $rootScope.configAuth = "";
         $rootScope.fileDownloadAuth = "";
         $rootScope.sapUserID = "";
     	 $rootScope.sapPassword = "";
     	 $rootScope.sapLanguage = "";

		
	}
    
	/*Universal method for cancel button for Popups*/
	 $scope.cancelHome = function(){
		 ngDialog.close();
		 if($scope.showErrorAlert != null)
		 $scope.showErrorAlert = {   
	    		   		"color" : "red", "display":"none"
	  				};
	};
  	
  	$scope.setupSecurityQA = function(){
  		
  		var input = {
  				userId : $rootScope.securityQA.userid,
  				emailId : $rootScope.securityQA.emailid
  		}
  		$http.post("/" + servicePrefix + "/rest/adminSrv/userIdValidation",input).then(function(response){
       if(response.data.resMessageDto.msgType == "Success")
  		{
    	   $rootScope.sessionMgmtDTO = response.data.sessionInputDTO;
    	   if(response.data.securityQuestionDto != null){
    	   for(var i = 0;i<response.data.securityQuestionDto.length;i++){
    		   if(i==0)
    	   $rootScope.UserQuestion1 = response.data.securityQuestionDto[i];
    		   if(i==1)
    		$rootScope.UserQuestion2 = response.data.securityQuestionDto[i];		   
    	   }
    	   }
    	   ngDialog.close();
  		/*if(document.getElementById("upArrow") != null)
  		{
  		document.getElementById("upArrow").style.display = "none";
  		document.getElementById("downArrow").style.display = "inline-block";
  	    document.getElementById("mySidenav").style.display = "none";
  	    }*/
  		if(response.data.secQAUpdated == true){
  		ngDialog.openConfirm({
	            template: 'view/managePassword/securityQuestions.html?ver='+version,
	            scope: $scope,
	            closeByDocument: false,
	            closeByEscape: false,
	            showClose: true,
	            height: 445,
	            width: 500,
	           className:'ngdialog-theme-default CLASS_projName'
	        	}); 
  			}
  		else{
  			 ngDialog.openConfirm({
                 template: '<p>' + "You have not set the Security Questions. Please contact Tool Administrator." +'</p>',
                 plain: true,
                 scope: $scope,
                 closeByDocument: true,
                 closeByEscape: true,
                 showClose: true,
                 height:120,
                 width: 350,
                 className:'ngdialog-theme-default CLASS_2'
             });
  			}
  			}
       	else if(response.data.resMessageDto.message == "Incorrect Email Id")
    	   		$scope.showAlert2 = {   
    		   		"color" : "red", "display":"inline-block"
  				};
       	else 
    	   		$scope.showAlert1 = {   
		   			"color" : "red", "display":"inline-block"
					};
  		 });
  	};
	$scope.forgotPassword = function(){
		
		ngDialog.openConfirm({
            template: 'view/managePassword/forgotPassword.html?ver='+version,
            scope: $scope,
            closeByDocument: false,
            closeByEscape: false,
            showClose: true,
            height: 340,
            width: 460,
           className:'ngdialog-theme-default CLASS_Frgtpwd'
        });
		
  	};
$scope.submitSecQuestions = function(){
  		var listOfQuestions = [$rootScope.UserQuestion1.questionId,$rootScope.UserQuestion2.questionId];
  		var listOfAnswers = [sha256($rootScope.securityQA.answer1),sha256($rootScope.securityQA.answer2)];
  	    var comparray = [];
       for(i=0;i<listOfAnswers.length;i++){
    	   var obj ={};
               obj.questionId = listOfQuestions[i];
               obj.ans = listOfAnswers[i];
               
           comparray.push(obj);
       }
  		var input = {
  				ansListDto : comparray,
  				userId: $rootScope.securityQA.userid,
  				sessionInputDTO :   $rootScope.sessionMgmtDTO
  		}
  		
  			$http.post("/" + servicePrefix + "/rest/adminSrv/securityQAvalidation",input).then(function(response){
  	  	       if(response.data.resMessageDto.msgType == "Success")
  	  	  		{
  	  	    	 ngDialog.close();
  	  	    	$scope.showErrorAlert = {   
  	    		   		"color" : "red", "display":"none"
  	  				};
  	  	    	 ngDialog.openConfirm({
  	  	            template: 'view/managePassword/resetPassword.html?ver='+version,
  	  	            scope: $scope,
  	  	            closeByDocument: false,
  	  	            closeByEscape: false,
  	  	            showClose: true,
  	  	            height: 375,
  	  	            width: 480,
  	  	           className:'ngdialog-theme-default CLASS_projName'
  	  	        });
  	  	    	}
  	  	       else {
  	  	    	$scope.showErrorAlert = {   
  	    		   		"color" : "red", "display":"inline-block"
  	  				};
  	  	    	/* ngDialog.close();
  	  	    	 ngDialog.openConfirm({
  	                 template: '<p>' + "Something went wrong. Please try again with correct details" +'</p>',
  	                 plain: true,
  	                 scope: $scope,
  	                 closeByDocument: true,
  	                 closeByEscape: true,
  	                 showClose: true,
  	                 height:120,
  	                 width: 350,
  	                 className:'ngdialog-theme-default CLASS_2'
  	             })*/
  	  	       }
  	  			});
  		
  	};
  	$scope.newLoginPassword = function(){
  		 for(var i=0;(i+2)<$rootScope.securityQA.userid.length;i++){
  			 if(($rootScope.securityQA.newpassword).includes($rootScope.securityQA.userid.substring(i,i+3))){
 	        	$('#messageAlert').html('Password should not contain UserId').css('color', 'red');
 	        	$rootScope.validPassword =  false;
 	     }
 	     else {
 	    	$rootScope.validPassword =  true;
 	     	}
  		 }
 	     if($rootScope.validPassword)
 	     { 	         
  		 var params = {
           		userId : $rootScope.securityQA.userid,
           		newPassword : $rootScope.securityQA.newpassword,
           		sessionInputDTO :   $rootScope.sessionMgmtDTO
           		//browserId : (Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15))
           }
  		$http.post("/" + servicePrefix + "/rest/adminSrv/resetPassword",params).then(function(response){
        if(response.data.msgType == "Success")
  		{
        	ngDialog.close();       
  
        	ngDialog.openConfirm({
        		   template: '<p>' + "Password saved successfully. " +'</p>',
                   plain: true,
	            closeByDocument: false,
	            closeByEscape: false,
	            showClose: true,
	            height: 100,
	            width: 275,
	           className:'ngdialog-theme-default CLASS_projName'
	        	});
          	$location.path("/loginPage");
  		}
        else {
        	ngDialog.openConfirm({
                template: '<p>' + "Something went wrong." +'</p>',
                plain: true,
                scope: $scope,
                closeByDocument: true,
                closeByEscape: true,
                showClose: true,
                height:120,
                width: 350,
                className:'ngdialog-theme-default CLASS_2'
            })
        }
  		});
 	   }
  	};
  /*	$scope.isValid = function ()
  	{
  	    for(var i=0;(i+2)<$rootScope.securityQA.newpassword.length;i++)
  	          if(($rootScope.securityQA.newpassword).indexof($rootScope.securityQA.userid.substring(i,i+3))!=-1)
  	        	$('#messageAlert').html('Password should not contain UserId').css('color', 'red');
  	         
  	}*/
/*$rootScope.checkDuplicateQ =  function(){
	if($rootScope.securityQA.question1 == $rootScope.securityQA.question2){
		$('#messageAlertDuplicate').html('Please select some different question').css('color', 'red');
	}
	
}*/
  }]);