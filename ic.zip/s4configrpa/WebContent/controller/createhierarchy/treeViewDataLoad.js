var app = angular.module('yapp');

app.controller('DemoCtrl', DemoCtrl);

/*//setup  expanded and collapse icos
app.config(function (ivhTreeviewOptionsProvider) {
    ivhTreeviewOptionsProvider.set({
        twistieCollapsedTpl: '<leaf><span class="fa fa-plus"></span></leaf> ',
        twistieExpandedTpl: '<leaf><span class="fa fa-minus"></span></leaf>',
        twistieLeafTpl: '<leaf></leaf>',
        labelAttribute: 'imgDescription',
        childrenAttribute: 'children',
        idAttribute:'imgId',
        selectedAttribute: 'selected',
       defaultSelectedState: false,
       expandToDepth: 2,
       validate: true

    });
});
*/
DemoCtrl.$inject = ['$scope', 'apiService','$window','tree','$rootScope','ivhTreeviewMgr', 'ivhTreeviewBfs', 'ivhTreeviewOptions','$http','$location','$mdMedia'];

function DemoCtrl($scope,apiService,$window,tree,$rootScope,ivhTreeviewMgr, ivhTreeviewBfs, ivhTreeviewOptions,$http,$location,$mdMedia) {
  var self = this;
  self.data = []; 
  $rootScope.parent ="";
  $scope.result =[];
  var numcount=0;
  var ng = angular;
  var count = 0;
  var children = 0;
  $rootScope.savingManualConfig = [];
 
/*  self.imgSearch = function(node) {
	    return self.showSelectedOnly ?
	      node.selected :
	      true;
	  };*/
	  
	  
  //Simulate parameter needed to pass to server
  var config = {
      params: {
          id: 0
      }
  }; 
  
  //Call server to get data
  // apiService.get('api/YOUR URL/', config,
   //  CategoryLoadCompleted,
   //  CategoryLoadFailed);  
  
  
function CategoryLoadCompleted(result) {
	var parentarray =[];
	//$location.path("/mainPage/createTemplate");
	if($rootScope.overlay_admin != null){
	$rootScope.overlay_admin.style.display = "none";
	$rootScope.popup_admin.style.display = "none";
	}
	self.data = tree.genNode(result,null,true);
	
	
}
	
  function CategoryLoadFailed(result) {
	  $rootScope.overlay_admin.style.display = "none";
	  $rootScope.popup_admin.style.display = "none";
    $window.alert('Category loaded failed'); 
  }
  function normalizeMixedDataValue( value ) {
	  
      var padding = "000000";
      // Loop over all numeric values in the string and        // replace them with a value of a fixed-width for
      // both leading (integer) and trailing (decimal)      // padded zeroes.
      value = value.replace(
          /(\d+)((\.\d+)+)?/g,
          function($0, integer, decimal, $3) {

              // If this numeric value has "multiple"              // decimal portions, then the complexity
              // is too high for this simple approach -              // just return the padded integer.
              
        	  if ( decimal !== $3 ) {
        		  
                  return(
                      padding.slice( integer.length ) +
                      integer +
                      decimal
                  );

              }

              decimal = ( decimal || ".0" );

              return(
                  padding.slice( integer.length ) +
                  integer +
                  decimal +
                  padding.slice( decimal.length )
              );

          }
      );
      return( value );

  }
function sortFiles() {

      $rootScope.selectedScopeData.sort(
          function( a, b ) {

              // Normalize the file names with fixed-
              // width numeric data.
              var aMixed = normalizeMixedDataValue( a.sequence);
              var bMixed = normalizeMixedDataValue( b.sequence);

              return( aMixed < bMixed ? -1 : 1 );
          }
      );
}

function sortFilesForIndustry() {

    $rootScope.selectedScopeData.sort(
        function( a, b ) {

            // Normalize the file names with fixed-
            // width numeric data.
            var aMixed = normalizeMixedDataValue( a.indSeq);
            var bMixed = normalizeMixedDataValue( b.indSeq);

            return( aMixed < bMixed ? -1 : 1 );
        }
    );
}

function sortFilesForIndustryBP() {

    $rootScope.selectedBPData.sort(
        function( a, b ) {

            // Normalize the file names with fixed-
            // width numeric data.
            var aMixed = normalizeMixedDataValue( a.indSeq);
            var bMixed = normalizeMixedDataValue( b.indSeq);

            return( aMixed < bMixed ? -1 : 1 );
        }
    );
}

  self.changeCallback = function(node) {
		self.lastChangedNode = node;
		
		//if($rootScope.hierarchyTypes.value == "IMG")
         $scope.selectedMethod(node,node.selected); 
		//else
		// $scope.savingManualConfig(node,node.selected); 
		
         $rootScope.scopevalue = "";
         $rootScope.scopevalueArray=[];
        
         if($rootScope.industryFlag && !$rootScope.copy &&  !$rootScope.consolidate){
        	 
        	 if($rootScope.hierarchyTypes.value == "Business Process"){
        		 sortFilesForIndustryBP(); 
        	 }else{
        		 sortFilesForIndustry();   
        	 }
        		     	 
         }else{
        	 sortFiles();
         }
      
        /* $rootScope.selectedScopeData.sort(function(a, b) {
                  return a.sequence - b.sequence;
              });*/
         if($rootScope.copy == true && $rootScope.hierarchyTypes.value == "Business Process"){
         for(var x = 0,arrLen = $rootScope.selectedBPData.length; x < arrLen ; x++){
                if($rootScope.selectedBPData[x].enabled =="1"){
                if(x == 0){
                			$rootScope.scopevalue = $rootScope.selectedBPData[x].imgId;
                            $rootScope.scopevalueArray.push($rootScope.selectedBPData[x].imgId);
                }
                else{
                      $rootScope.scopevalue = $rootScope.scopevalue.concat(";",$rootScope.selectedBPData[x].imgId);
                      $rootScope.scopevalueArray.push($rootScope.selectedBPData[x].imgId);
                }
                      
                }
         	}
         }
         else{
        	 
             for(var x = 0,arrLen = $rootScope.selectedScopeData.length; x < arrLen ; x++){
                    if($rootScope.selectedScopeData[x].enabled =="1"){
                    if(x == 0){
                    	if($rootScope.consolidate == true){
                            $rootScope.scopevalue = $rootScope.selectedScopeData[x].imgId;
                            $rootScope.scopevalueArray.push($rootScope.selectedScopeData[x].imgId);
                    		
                      	}else if($rootScope.copy == true){
                            $rootScope.scopevalue = $rootScope.selectedScopeData[x].imgId;
                            $rootScope.scopevalueArray.push($rootScope.selectedScopeData[x].imgId);
                    		
                      	}
                    	else{
                    	if($rootScope.hierarchyTypes.value == "IMG"){
                          $rootScope.scopevalue = $rootScope.selectedScopeData[x].imgId;
                          $rootScope.scopevalueArray.push($rootScope.selectedScopeData[x].imgId);
                    	}
                    	else
                    		$rootScope.scopevalue = "";
                          $rootScope.scopevalueArray.push($rootScope.selectedScopeData[x].imgId);
                    }
                          
                    }
                    else{
                    	/*if(node.children !== null && node.children.length > 0)
                    	{
                    		if($rootScope.selectedimg.indexOf(node.id) == -1)
                    	 	$rootScope.selectedimg.push(node.id);
                    	}*/
                    	if($rootScope.consolidate == true){
                    		 $rootScope.scopevalue = $rootScope.scopevalue.concat(";",$rootScope.selectedScopeData[x].imgId);
                    		 $rootScope.scopevalueArray.push($rootScope.selectedScopeData[x].imgId); 
                    		
                      	}else if($rootScope.copy == true){
                     		if($rootScope.hierarchyTypes.value == "IMG"){
                        		 $rootScope.scopevalue = $rootScope.scopevalue.concat(";",$rootScope.selectedScopeData[x].imgId);
                        		}else{
                        			$rootScope.scopevalue = $rootScope.scopevalue.concat(";",$rootScope.selectedBPData[x].imgId);	
                        		}
                        	}
                    	else{
                    	if($rootScope.hierarchyTypes.value == "IMG")
                          $rootScope.scopevalue = $rootScope.scopevalue.concat(";",$rootScope.selectedScopeData[x].imgId);
                    	else
                    		 $rootScope.scopevalue = "";
                          $rootScope.scopevalueArray.push($rootScope.selectedScopeData[x].imgId); 
                    }
                    }
                          
             }
             }
      }
    /*     for(var x = 0; x < $rootScope.selectedimg.length; x++){
        		  { 	
        			  //$rootScope.scopevalue = $rootScope.selectedimg[x].id;
        			  $rootScope.selectedIds.push($rootScope.selectedimg[x]);
        		  }
        		 }*/

        if (node.children != null) {
          $scope.$broadcast('changeChildren', node);
        }
       /* if (parentScope.item != null) {
          return $scope.$emit('changeParent', parentScope);
        }*/
        
		   };
		   $scope.$on('changeChildren', function(event, parentItem) {
               var child, i, len, ref, results;
               ref = parentItem.children;
               results = [];
               for (i = 0, len = ref.length; i < len; i++) {
                 child = ref[i];
                 if(child.enabled== "1"){
                 child.selected = parentItem.selected;
                 }
                 if (child.children != null) {
                   results.push($scope.$broadcast('changeChildren', child));
                 } else {
                   results.push(void 0);
                 }
               }
               return results;
             });
		   $scope.selectedMethod = function(item,selectedValue){
               var recentSelectedScope = {};
               var fileUploadStatusMsgArr = [];
               fileUploadStatusMsgArr.push("Config Template Not yet uploaded..");
               if(item.imgId != undefined  && item.imgId != null && item.imgId.length > 0){
            	   recentSelectedScope.id = item.id;
            	   recentSelectedScope.imgId = item.imgId;
            	   recentSelectedScope.imgDescription = (item.sequence == "" ? item.imgDescription : item.imgDescription.split(/_(.+)/)[1]);
            	   recentSelectedScope.sequence = item.sequence;
            	   recentSelectedScope.indSeq = item.indSeq;
            	   recentSelectedScope.enabled = item.enabled;
            	   recentSelectedScope.fileName = "";
            	   recentSelectedScope.filepath = "";
            	   recentSelectedScope.isMasterData = item.isMasterData;
            	   recentSelectedScope.logs = [];
            	   recentSelectedScope.status = "status-pending";
            	   recentSelectedScope.fileUploadStatusMsg = fileUploadStatusMsgArr;
            	   recentSelectedScope.fileUploadedIcon = "glyphicon glyphicon-remove";
            	   recentSelectedScope.trType = item.trType;
            	   recentSelectedScope.customizingTr = "";
            	   recentSelectedScope.workbenchTr = "";
            	   recentSelectedScope.customizingTr_readOnly = true;
            	   recentSelectedScope.workbenchTr_readOnly = true;
            	   recentSelectedScope.customizingTr_mode = "";
            	   recentSelectedScope.workbenchTr_mode = "";
            	   recentSelectedScope.tranId = 0;
            	   recentSelectedScope.scopeExists = false;
            	   recentSelectedScope.configType = item.configType;
                      if(selectedValue === true){
//                           index = $scope.selectedTreeviewData.findIndex(x => x.imgId == bData.imgId);
//                           console.log($scope.selectedTreeviewData);
                    	   count++;
                             index = -1;
                             if(recentSelectedScope.enabled=="1" && $rootScope.copy == true){
                            	 if($rootScope.hierarchyTypes.value == "IMG"){
                            	 for(var a= 0, arrLen = $rootScope.selectedScopeData.length;a< arrLen ;a++){
                                  if($rootScope.selectedScopeData[a].imgId == recentSelectedScope.imgId){
                                         index = a;
                                         break;
                                  }
                            	 }
                             
                             if (index == -1) {
                            
                                	   if($rootScope.selectedScopeData.indexOf(recentSelectedScope) == -1)
                                		   $rootScope.selectedScopeData.push(recentSelectedScope);
                                	   var output = [], 
                                       keys = [];
                       	    			var collection =  $rootScope.selectedScopeData;
                       	    			var keyname = "imgId";
                       	    			angular.forEach(collection, function(item) {
                                       var key = item[keyname];
                                       if(keys.indexOf(key) === -1) {
                                           keys.push(key);
                                           output.push(item);

                       	    			}
                                       $rootScope.selectedScopeData = output;
                       	    			});
                                   }
                            	 }else{
                            		 for(var a= 0, arrLen = $rootScope.selectedBPData.length;a< arrLen ;a++){
                                         if($rootScope.selectedBPData[a].imgId == recentSelectedScope.imgId){
                                                index = a;
                                                break;
                                         }
                                   	 }
                                    
                                    if (index == -1) {
                                   
                                       	   if($rootScope.selectedBPData.indexOf(recentSelectedScope) == -1)
                                       		   $rootScope.selectedBPData.push(recentSelectedScope);
                                       	   var output = [], 
                                              keys = [];
                              	    			var collection =  $rootScope.selectedBPData;
                              	    			var keyname = "imgId";
                              	    			angular.forEach(collection, function(item) {
                                              var key = item[keyname];
                                              if(keys.indexOf(key) === -1) {
                                                  keys.push(key);
                                                  output.push(item);

                              	    			}
                                              $rootScope.selectedBPData = output;
                              	    			});
                                          }
                            	 }
                             }
                             else if(recentSelectedScope.enabled=="1" && $rootScope.hierarchyTypes.value == "IMG"){
                            	 for(var a= 0, arrLen = $rootScope.selectedScopeData.length;a< arrLen ;a++){
                                  if($rootScope.selectedScopeData[a].imgId == recentSelectedScope.imgId){
                                         index = a;
                                         break;
                                  }
                            	 }
                             
                             if (index == -1) {
                            
                                	   if($rootScope.selectedScopeData.indexOf(recentSelectedScope) == -1)
                                		   $rootScope.selectedScopeData.push(recentSelectedScope);
                                	   var output = [], 
                                       keys = [];
                       	    			var collection =  $rootScope.selectedScopeData;
                       	    			var keyname = "imgId";
                       	    			angular.forEach(collection, function(item) {
                                       var key = item[keyname];
                                       if(keys.indexOf(key) === -1) {
                                           keys.push(key);
                                           output.push(item);

                       	    			}
                                       $rootScope.selectedScopeData = output;
                       	    			});
                                   }
                             }
                            else if(recentSelectedScope.enabled=="1" && $rootScope.hierarchyTypes.value == "Business Process"){
                                	   
                                	   if($rootScope.selectedBPData.indexOf(recentSelectedScope) == -1)
                                		   $rootScope.selectedBPData.push(recentSelectedScope);
                                	  
                                	   if(keys == undefined)
                                		   {
                                		   var output = [], 
                                		   keys = [];
                                		   }
                       	    			var collection =  $rootScope.selectedBPData;
                       	    			var keyname = "imgId";
                       	    			angular.forEach(collection, function(item) {
                       	    			var key = item[keyname];
                                       if(keys.indexOf(key) === -1) {
                                           keys.push(key);
                                           output.push(item);

                       	    			}
                                       $rootScope.selectedBPData = output;
                       	    			});
                                   }
                            else{
                         	   if(recentSelectedScope.enabled=="1"){
                         	   for(var a= 0, arrLen = $rootScope.selectedScopeData.length;a< arrLen ;a++){
                                    if($rootScope.selectedScopeData[a].imgId == recentSelectedScope.imgId){
                                           index = a;
                                           break;
                                    }
                              	 }
                               
                               if (index == -1) {
                              
                                  	   if($rootScope.selectedScopeData.indexOf(recentSelectedScope) == -1)
                                  		   $rootScope.selectedScopeData.push(recentSelectedScope);
                                  	   var output = [], 
                                         keys = [];
                         	    			var collection =  $rootScope.selectedScopeData;
                         	    			var keyname = "imgId";
                         	    			angular.forEach(collection, function(item) {
                                         var key = item[keyname];
                                         if(keys.indexOf(key) === -1) {
                                             keys.push(key);
                                             output.push(item);

                         	    			}
                                         $rootScope.selectedScopeData = output;
                         	    			});
                                     }  
                            }
                            }
//                                 $scope.selectedTreeviewData.splice(index, 1);
                                 
                       }
                     
                      else if(selectedValue === false){
                    	  if($rootScope.copy == true){
                    		  if($rootScope.hierarchyTypes.value == "IMG"){
                    		  index = -1;
                              for(var a= 0,arrLen = $rootScope.selectedScopeData.length;a< arrLen ;a++){
                                   if($rootScope.selectedScopeData[a].imgId == recentSelectedScope.imgId){
                                          index = a;
                                          break;
                                   }
                              }
                              if (index > -1) {
                                    $rootScope.selectedScopeData.splice(index, 1);
                                   
                                  }
                    		  }
                    		  else{
                    			  index = -1;
                                  for(var a= 0,arrLen = $rootScope.selectedBPData.length;a< arrLen ;a++){
                                       if($rootScope.selectedBPData[a].imgId == recentSelectedScope.imgId){
                                              index = a;
                                              break;
                                       }
                                  }
                               
//                              
                                  if (index > -1) {
                                        $rootScope.selectedBPData.splice(index, 1);
                                       
                                      } 
                    		  }
                              
                    	  }
 
                    	  else if($rootScope.hierarchyTypes.value == "Business Process"){
                    		  index = -1;
                              for(var a= 0,arrLen = $rootScope.selectedBPData.length;a< arrLen ;a++){
                                   if($rootScope.selectedBPData[a].imgId == recentSelectedScope.imgId){
                                          index = a;
                                          break;
                                   }
                              }
                           
                              if (index > -1) {
                                    $rootScope.selectedBPData.splice(index, 1);
                               }
                          }else{
                             index = -1;
                             for(var a= 0,arrLen = $rootScope.selectedScopeData.length;a< arrLen ;a++){
                                  if($rootScope.selectedScopeData[a].imgId == recentSelectedScope.imgId){
                                         index = a;
                                         break;
                                  }
                             }
                          
//                           console.log($scope.selectedTreeviewData);
                             if (index > -1) {
                                   $rootScope.selectedScopeData.splice(index, 1);
                                   //$rootScope.selectedimg.splice(index, 1);
                                 //  $rootScope.scopevalueArrayid.splice(index, 1)
                                 }
                    	  }    
                      }
               }else {
            	   		/*if(selectedValue === true){
            	   		  $rootScope.selectedimg.push(bData.id);
            	   		if($rootScope.scopevalueArrayid.indexOf(bData.id) == -1)
               	    	{		
               	    	$rootScope.scopevalueArrayid.push(bData.id);
               	    	}
            	   		}*/
            	   		/*else{
            	   		  index = -1;
                          for(var a= 0;a<$rootScope.selectedScopeData.length;a++){
                               if($rootScope.selectedScopeData[a].imgId == bData.imgId){
                                      index = a;
                                      break;
                               }
                          }
                          
//                        console.log($scope.selectedTreeviewData);
                          if (index > -1) {
                        	  $rootScope.selectedimg.splice(index, 1);
                                
                              }
            	   		}*/
            	  /* if(selectedValue === true){
            		   children = item.children.length;
            		   if($rootScope.selectedimg.indexOf(item.id) == -1)
            			   $rootScope.selectedimg.push(item.id);
            	   }*/
            	   /*else
            		   {
            		   		index1 = -1
                       		for(var i= 0;i<$rootScope.selectedIds.length;i++){
                           if($rootScope.selectedIds[i].id == bData.id){
                                  index1 = i;
                                  break;
                           		}
                       		}
            		   		if (index1 > -1) {
            		   			$rootScope.selectedIds.splice(index1, 1);
                         
            		   		}
            		   }*/
                      for(var x = 0,childrenLen = item.children.length;x < childrenLen ; x++){
                    	  
            	   			/*for(var i= 0;i<item.children.length; i++)
            	   			$rootScope.selectedimg.push(item.children[i].id);*/
            	   			
                      $scope.selectedMethod(item.children[x],selectedValue);
                      }
               }
            /*   if(children == count){
            	   if($rootScope.selectedimg.indexOf(item.id) == -1)
          			   $rootScope.selectedimg.push(item.id);  
               }*/
               
            };
           
            $scope.initCheckbox = function(item, parentItem) {
                
                  item.selected=$scope.validatecheck(item);
                  
                  if(item.selected)
               {
                var allChecks = true;
                for (var i in parentItem.children) 
                {
                             if (!parentItem.children[i].selected) {
                                           allChecks = false;
                                           break;
                                    }
                }
                             if (allChecks) {
                                                                parentItem.selected = true;
                                                         }
                                    else {
                                                         parentItem.selected = false;
                                           }

               }
                  return item.selected;
                
               };
               $scope.validatecheck=function(item)
               {
                  
                  var selectedValue=true;
                  var aIndex = $rootScope.scopevalueArray.indexOf(item.imgId);
                  if(aIndex>-1)
                         { 
                         
                         var bData = {};
                         var fileUploadStatusMsgArr = [];
                         fileUploadStatusMsgArr.push("Config Template Not yet uploaded..")
                         if(item.imgId.length > 0){
                                
                                bData.imgId = item.imgId;
                                bData.imgDescription = item.imgDescription;
                                bData.sequence = item.sequence;
                                bData.enabled = item.enabled;
                                bData.fileName = "";
                                bData.filepath = "";
                                bData.isMasterData = item.isMasterData;
                                bData.logs = [];
                                bData.status = "status-pending";
                                bData.fileUploadStatusMsg = fileUploadStatusMsgArr;
                                bData.fileUploadedIcon = "glyphicon glyphicon-remove";
                                bData.trType = item.trType;
                                bData.customizingTr = "";
                                bData.workbenchTr = "";
                                bData.customizingTr_readOnly = true;
                                bData.workbenchTr_readOnly = true;
                                bData.customizingTr_mode = "";
                                bData.workbenchTr_mode = "";
                                bData.tranId = 0;
                                bData.scopeExists = false;
                                bData.configType = item.configType;
                                if(selectedValue === true){
//                                    index = $scope.selectedTreeviewData.findIndex(x => x.imgId == bData.imgId);
//                                    console.log($scope.selectedTreeviewData);

                                       index = -1;
                                       for(var a= 0,arrLen = $rootScope.selectedScopeData.length;a< arrLen ;a++){
                                            if($rootScope.selectedScopeData[a].imgId == bData.imgId){
                                                   index = a;
                                                   break;
                                            }
                                       }
                                       
                                       if (index == -1) {
                                             if(bData.enabled=="1"){
                                            	 if($rootScope.hierarchyTypes.value == "IMG")
                                            		{ 
                                            		 if($rootScope.selectedScopeData.indexOf(bData) == -1)
                                            		 $rootScope.selectedScopeData.push(bData);
                                            		}
                                            	 else{
                                            		 if($rootScope.selectedScopeData.indexOf(bData) == -1)
                                            			 $rootScope.selectedBPData.push(bData); 
                                            	 }
                                            		
                                             }
//                                          $scope.selectedTreeviewData.splice(index, 1);
                                           }
                                       
                                }
                               
                                else if(selectedValue === false){
//                                    index = $scope.selectedTreeviewData.findIndex(x => x.imgId == bData.imgId);
                                       
                                       index = -1;
                                       for(var a= 0,arrLen = $rootScope.selectedScopeData.length;a< arrLen ;a++){
                                            if($rootScope.selectedScopeData[a].imgId == bData.imgId){
                                                   index = a;
                                                   break;
                                            }
                                       }
                                       
//                                    console.log($scope.selectedTreeviewData);
                                       if (index > -1) {
                                             $rootScope.selectedScopeData.splice(index, 1);
                                           }
                                }
                         }else {
                                for(var x = 0,childLen = item.children.length;x < childLen ; x++){
                                $scope.selectedMethod(item.children[x],selectedValue);
                                }
                         }
                         
                         return true
                         }
                  else
                  return true;
                  
               };
             /*  $scope.expandall = function() {
               var selItem = $treeService.selectedItem(result);
               selItem.expanded = true;
               }*/

           	$scope.RetreiveScope = function(){
           		
           		var input = {
        				userId : $rootScope.username,
        				omId : $rootScope.projOmId,
        				implementationType : $rootScope.implType,
        				sessionInputDTO : $rootScope.sessionInputObj	

        		}
        		
           		$http({
        	        method: "POST",
        	        url: "/" + servicePrefix + "/rest/scopeState/retriever",
        	        data : input
        		}).then(function(response) {
       			 if(response.status === 200){
       				 if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
            	      		$rootScope.checkAuthorization();
            	      	}
       			 else{	 
       			$rootScope.scopevalue="";
       			var responsedata=[];
       			var fileUploadStatusMsgArr = [];
       			fileUploadStatusMsgArr.push("Config Template Not yet uploaded..");
       			if(response.data.scopeSessionDto != null){
       	    	for (var i = 0,arrLen = response.data.scopeSessionDto.imgScopeDto.length; i < arrLen ; i++) {
       	    		var scopeData ={
       	    				"id":response.data.scopeSessionDto.imgScopeDto[i].id,
       	    		       	"imgId":response.data.scopeSessionDto.imgScopeDto[i].imgId,
       	    		        "imgDescription":response.data.scopeSessionDto.imgScopeDto[i].imgDescription,
       	    		        "sequence":response.data.scopeSessionDto.imgScopeDto[i].seqNo,
       	    		        "enabled":response.data.scopeSessionDto.imgScopeDto[i].enabled,
       	    		        "fileName":"",
       	    		        "filepath":"",
       	    		        "isMasterData":response.data.scopeSessionDto.imgScopeDto[i].isMasterData,
       	    		        "status":"status-pending",
       	    		        "implementationType":response.data.scopeSessionDto.implementationType,
       	    		        "fileUploadStatusMsg" : fileUploadStatusMsgArr,
       	    		        "fileUploadedIcon" : "glyphicon glyphicon-remove",
       	    		        "trType" : response.data.scopeSessionDto.imgScopeDto[i].trType,
       	    		        "customizingTr" : "",
       	    		        "workbenchTr" : "",
       	    		        "customizingTr_readOnly":true,
    	    		        "workbenchTr_readOnly":true,
    	    		        "customizingTr_mode":"",
       	    		        "workbenchTr_mode":"",
       	    		        "tranId":0,
       	    		        "scopeExists":false,
       	    		        "fileBytes":null
       		    		 } ;
       	    		
       	    		if($rootScope.hierarchyTypes.value == "IMG"){
       	    		responsedata.push(scopeData);
       	    		$rootScope.selectedScopeData.push(scopeData);
       	    	}
//       	    		console.log($rootScope.selectedScopeData.length);
       	    		return $rootScope.selectedScopeData;
       	    		scopeData={};
       	    	}
       	    
       			}}
       			 }else {
//       			        console.log("Error");
       			    }
       		});
       	
       	};
       	
        self.showTree = true;
        
        
       
        
$rootScope.onFilterChange = function(str) {
	  /*var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
		 var overlay = document.getElementById("overlay");
	     var popup = document.getElementById("busy");
	     overlay.style.display = "block";
	        busy.style.display = "inline-block";*/
	        
				if($scope.expandNodes){
	       	      ivhTreeviewMgr.expandRecursive(self.data,self.data);
				}
				else
				  ivhTreeviewMgr.collapseRecursive(self.data,self.data);

	       	      
	       	  // $scope.completeLoading();
	

	     		 
	       	  };
	       	  
	       	  $scope.completeLoading = function(){
	       		var overlay = document.getElementById("overlay");
	     	     var popup = document.getElementById("busy");
	     	     overlay.style.display = "none";
	     	        busy.style.display = "none";
	       		  
	       	  };
	       	if($rootScope.createimg == true && $rootScope.hierarchyTypes.value == "IMG" && $rootScope.copy == true)
			  {
				$rootScope.copyListData =[];	     		 
	    		  var imgPreviewInputDto = {
	    				  selectedOmid:$rootScope.projOmId,
	    				  sessionInputDTO: $rootScope.sessionInputObj
	                };
	    		   $http.post("/" + servicePrefix + "/rest/clientImgHierarchySrv/viewClientImgHierarchyCopyFuntionality",imgPreviewInputDto).then(function(response) {
	    			   if($rootScope.overlay != null){
	    			 	$rootScope.overlay.style.display = "none";
	    			 	$rootScope.popup.style.display = "none";
	    			   }
	    			   if($rootScope.overlay_admin != null){
	    			    	$rootScope.overlay_admin.style.display = "none";
	    					$rootScope.popup_admin.style.display = "none";
	    			    	}
	    	        if (response.status === 200) {
	    	        	
	    	        	 if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
	    	       	      		$rootScope.checkAuthorization();
	    	       	      	}
	    	        	 else{ var responseData=[];
	    	        	responseData.push(JSON.parse(response.data.resMessageDto.message));
	    	            $rootScope.copyListData = responseData;
	    	            var responseData2 = responseData;
	    	            $rootScope.hierarchyData = responseData;
	    	        	 }
	    	            }});
	    		  }
	       	else if($rootScope.createimg == true && $rootScope.hierarchyTypes.value == "IMG" && $rootScope.industryFlag==true)
			  {
				$rootScope.listData =[];	     		 
	    		  var imgPreviewInputDto = {
	    				  selectedOmid:$rootScope.projOmId,
	    				  sessionInputDTO: $rootScope.sessionInputObj,
	    				  industry:$rootScope.selectedIndustry,
	    				  subIndustry:$rootScope.selectedsubIndustry
	                };
	    		   $http.post("/" + servicePrefix + "/rest/clientImgHierarchySrv/viewClientImgHierarchyForIndustry",imgPreviewInputDto).then(function(response) {
	    			   if($rootScope.overlay != null){
	    			 	$rootScope.overlay.style.display = "none";
	    			 	$rootScope.popup.style.display = "none";
	    			   }
	    			   if($rootScope.overlay_admin != null){
	    			    	$rootScope.overlay_admin.style.display = "none";
	    					$rootScope.popup_admin.style.display = "none";
	    			    	}
	    	        if (response.status === 200) {
	    	        	
	    	        	 if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
	    	       	      		$rootScope.checkAuthorization();
	    	       	      	}
	    	        	 else{ var responseData=[];
	    	        	responseData.push(JSON.parse(response.data.resMessageDto.message));
	    	            $rootScope.listData = responseData;
	    	            var responseData2 = responseData;
	    	            $rootScope.hierarchyData = responseData;
	    	        	 }
	    	            }});
	    		  }
	       	else if($rootScope.createimg == true && $rootScope.hierarchyTypes.value == "IMG")
			  {
				$rootScope.listData =[];	     		 
	    		  var imgPreviewInputDto = {
	    				  selectedOmid:$rootScope.projOmId,
	    				  sessionInputDTO: $rootScope.sessionInputObj
	                };
	    		   $http.post("/" + servicePrefix + "/rest/clientImgHierarchySrv/viewClientImgHierarchy",imgPreviewInputDto).then(function(response) {
	    			   if($rootScope.overlay != null){
	    			 	$rootScope.overlay.style.display = "none";
	    			 	$rootScope.popup.style.display = "none";
	    			   }
	    			   if($rootScope.overlay_admin != null){
	    			    	$rootScope.overlay_admin.style.display = "none";
	    					$rootScope.popup_admin.style.display = "none";
	    			    	}
	    	        if (response.status === 200) {
	    	        	
	    	        	 if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
	    	       	      		$rootScope.checkAuthorization();
	    	       	      	}
	    	        	 else{ var responseData=[];
	    	        	responseData.push(JSON.parse(response.data.resMessageDto.message));
	    	            $rootScope.listData = responseData;
	    	            var responseData2 = responseData;
	    	            $rootScope.hierarchyData = responseData;
	    	        	 }
	    	            }});
	    		  }
			else if($rootScope.createimg == true && $rootScope.hierarchyTypes.value == "Business Process" && $rootScope.copy == true)
	    	  {
				$rootScope.copyListData =[];	     		 
	    		  var imgPreviewInputDto = {
	    				  selectedOmid:$rootScope.projOmId,
	    				  sessionInputDTO: $rootScope.sessionInputObj
	                };
	    		   $http.post("/" + servicePrefix + "/rest/clientImgHierarchySrv/viewClientBPHierarchyCopyFuntionality",imgPreviewInputDto).then(function(response) {
	    			   if($rootScope.overlay != null){
	    			 	$rootScope.overlay.style.display = "none";
	    			 	$rootScope.popup.style.display = "none";
	    			   }
	    			   if($rootScope.overlay_admin != null){
	    			    	$rootScope.overlay_admin.style.display = "none";
	    					$rootScope.popup_admin.style.display = "none";
	    			    	}
	    	        if (response.status === 200) {
	    	        	
	    	        	 if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
	    	       	      		$rootScope.checkAuthorization();
	    	       	      	}
	    	        	 else{ var responseData=[];
	    	        	responseData.push(JSON.parse(response.data.resMessageDto.message));
	    	            $rootScope.copyListData = responseData;
	    	            var responseData2 = responseData;
	    	            $rootScope.hierarchyData = responseData;
	    	        		/* var responseData=[];
	    		            	responseData.push(response.data);
	    		                $rootScope.copyListData = responseData;
	    		                var responseData2 = responseData;
	    		                $rootScope.hierarchyData = responseData;*/
	    	        	 }
	    	            }});
	    	  }
			else if($rootScope.createimg == true && $rootScope.hierarchyTypes.value == "Business Process" && $rootScope.industryFlag==true )
	    	  {
				$rootScope.listData =[];	
				var imgPreviewInputDto = {
	    			  selectedOmid:$rootScope.projOmId,
	    			  sessionInputDTO: $rootScope.sessionInputObj,
	    			  industry:$rootScope.selectedIndustry,
  				  subIndustry:$rootScope.selectedsubIndustry
	            };
	    	   $http.post("/" + servicePrefix + "/rest/imgHierarchySrv/viewBPHierarchyforindustry",imgPreviewInputDto).then(function(response) {
	    		   if($rootScope.overlay != null){
	    		 	$rootScope.overlay.style.display = "none";
	    		 	$rootScope.popup.style.display = "none";
	    		   }
	    		   if($rootScope.overlay_admin != null){
	    		    	$rootScope.overlay_admin.style.display = "none";
	    				$rootScope.popup_admin.style.display = "none";
	    		    	}
	            if (response.status === 200) {
	            	 /*if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
	           	      		$rootScope.checkAuthorization();
	           	      	}*/
	            	 {
	            		 var responseData=[];
	            	responseData.push(response.data);
	                $rootScope.listData = responseData;
	                var responseData2 = responseData;
	                $rootScope.hierarchyData = responseData;
	            	 }
	                }});
	    	  }else if($rootScope.createimg == true && $rootScope.hierarchyTypes.value == "Business Process")
	    	  {
				$rootScope.listData =[];	
				var imgPreviewInputDto = {
	    			  selectedOmid:$rootScope.projOmId,
	    			  sessionInputDTO: $rootScope.sessionInputObj
	            };
	    	   $http.post("/" + servicePrefix + "/rest/imgHierarchySrv/viewBPHierarchy",$rootScope.sessionInputObj).then(function(response) {
	    		   if($rootScope.overlay != null){
	    		 	$rootScope.overlay.style.display = "none";
	    		 	$rootScope.popup.style.display = "none";
	    		   }
	    		   if($rootScope.overlay_admin != null){
	    		    	$rootScope.overlay_admin.style.display = "none";
	    				$rootScope.popup_admin.style.display = "none";
	    		    	}
	            if (response.status === 200) {
	            	 /*if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
	           	      		$rootScope.checkAuthorization();
	           	      	}*/
	            	 {
	            		 var responseData=[];
	            	responseData.push(response.data);
	                $rootScope.listData = responseData;
	                var responseData2 = responseData;
	                $rootScope.hierarchyData = responseData;
	            	 }
	                }});
	    	   
	    	  }
			else if($rootScope.createimg == true && $rootScope.consolidate == true)
	    	  {
					$rootScope.listData =[];	     		 
		    		  var imgPreviewInputDto = {
		    				  selectedOmid:$rootScope.projOmId,
		    				  sessionInputDTO: $rootScope.sessionInputObj
		                };
		    		   $http.post("/" + servicePrefix + "/rest/clientImgHierarchySrv/viewClientImgHierarchyConsolidation",imgPreviewInputDto).then(function(response) {
		    			   if($rootScope.overlay != null){
		    			 	$rootScope.overlay.style.display = "none";
		    			 	$rootScope.popup.style.display = "none";
		    			   }
		    			   if($rootScope.overlay_admin != null){
		    			    	$rootScope.overlay_admin.style.display = "none";
		    					$rootScope.popup_admin.style.display = "none";
		    			    	}
		    	        if (response.status === 200) {
		    	        	
		    	        	 if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
		    	       	      		$rootScope.checkAuthorization();
		    	       	      	}
		    	        	 else{ var responseData=[];
		    	        	responseData.push(JSON.parse(response.data.resMessageDto.message));
		    	            $rootScope.listData = responseData;
		    	            var responseData2 = responseData;
		    	            $rootScope.hierarchyData = responseData;
		    	        	 }
		    	            }});
		    		  }
	       	
			else if($rootScope.createimg == true && $rootScope.create.templateType == "4"){
				$rootScope.listData =[];	     		 
	    		  var imgPreviewInputDto = {
	    				  selectedOmid:$rootScope.projOmId,
	    				  sessionInputDTO: $rootScope.sessionInputObj,
	    				  industry:$rootScope.selectedIndustry,
	    				  subIndustry:$rootScope.selectedsubIndustry,
	    				  downloadTemplate:true
	                };
	    		   $http.post("/" + servicePrefix + "/rest/clientImgHierarchySrv/viewClientImgHierarchyForIndustry",imgPreviewInputDto).then(function(response) {
	    			   if($rootScope.overlay != null){
	    			 	$rootScope.overlay.style.display = "none";
	    			 	$rootScope.popup.style.display = "none";
	    			   }
	    			   if($rootScope.overlay_admin != null){
	    			    	$rootScope.overlay_admin.style.display = "none";
	    					$rootScope.popup_admin.style.display = "none";
	    			    	}
	    	        if (response.status === 200) {
	    	        	
	    	        	 if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
	    	       	      		$rootScope.checkAuthorization();
	    	       	      	}
	    	        	 else{ var responseData=[];
	    	        	responseData.push(JSON.parse(response.data.resMessageDto.message));
	    	            $rootScope.listData = responseData;
	    	            var responseData2 = responseData;
	    	            $rootScope.hierarchyData = responseData;
	    	        	 }
	    	            }});
			}
			else if($rootScope.createimg == true && $rootScope.create.templateType == "3" )
	    	  {
					$rootScope.listData =[];	     		 
		    		  var imgPreviewInputDto = {
		    				  selectedOmid:$rootScope.projOmId,
		    				  sessionInputDTO: $rootScope.sessionInputObj
		                };
		    		   $http.post("/" + servicePrefix + "/rest/clientImgHierarchySrv/viewClientBPHierarchyCopyFuntionality",imgPreviewInputDto).then(function(response) {
		    			   if($rootScope.overlay != null){
		    			 	$rootScope.overlay.style.display = "none";
		    			 	$rootScope.popup.style.display = "none";
		    			   }
		    			   if($rootScope.overlay_admin != null){
		    			    	$rootScope.overlay_admin.style.display = "none";
		    					$rootScope.popup_admin.style.display = "none";
		    			    	}
		    	        if (response.status === 200) {
		    	        	
		    	        	 if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
		    	       	      		$rootScope.checkAuthorization();
		    	       	      	}
		    	        	 else{ var responseData=[];
		    	        	responseData.push(JSON.parse(response.data.resMessageDto.message));
		    	            $rootScope.listData = responseData;
		    	            var responseData2 = responseData;
		    	            $rootScope.hierarchyData = responseData;
		    	        	 }
		    	            }});
		    		  }
			else if($rootScope.createimg == true )
	    	  {
					$rootScope.listData =[];	
					
					  
		    		  var imgPreviewInputDto = {
		    				  selectedOmid:$rootScope.projOmId,
		    				  sessionInputDTO: $rootScope.sessionInputObj
		                };
	    			
		    		   $http.post("/" + servicePrefix + "/rest/clientImgHierarchySrv/viewClientImgHierarchy",imgPreviewInputDto).then(function(response) {
		    			   if($rootScope.overlay != null){
		    			 	$rootScope.overlay.style.display = "none";
		    			 	$rootScope.popup.style.display = "none";
		    			   }
		    			   if($rootScope.overlay_admin != null){
		    			    	$rootScope.overlay_admin.style.display = "none";
		    					$rootScope.popup_admin.style.display = "none";
		    			    	}
		    	        if (response.status === 200) {
		    	        	
		    	        	 if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
		    	       	      		$rootScope.checkAuthorization();
		    	       	      	}
		    	        	 else{ var responseData=[];
		    	        	responseData.push(JSON.parse(response.data.resMessageDto.message));
		    	            $rootScope.listData = responseData;
		    	            var responseData2 = responseData;
		    	            $rootScope.hierarchyData = responseData;
		    	        	 }
		    	            }});
		    		  }
			else if($rootScope.selectedTab == "copyTab1" || $rootScope.create.templateType == "3"){
					$rootScope.listData =[];	   
		    			  $http.post("/" + servicePrefix + "/rest/imgHierarchySrv/viewImgHierarchyCopyFunctionality",$rootScope.sessionInputObj).then(function(response) {
		    				   if($rootScope.overlay != null){
		    				 	$rootScope.overlay.style.display = "none";
		    				 	$rootScope.popup.style.display = "none";
		    				   }
		    				   if($rootScope.overlay_admin != null){
		    				    	$rootScope.overlay_admin.style.display = "none";
		    						$rootScope.popup_admin.style.display = "none";
		    				    	}
		    		        if (response.status === 200) {
		    		        	 if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
		    		       	      		$rootScope.checkAuthorization();
		    		       	      	}
		    		        	 {
		    		        		 var responseData=[];
		    		        	responseData.push(response.data);
		    		            $rootScope.listData = responseData;
		    		            var responseData2 = responseData;
		    		            $rootScope.hierarchyData = responseData;
		    		        	 }
		    		            }});
		    		  }
			else if($rootScope.create.templateType == "4"){
				$rootScope.listData =[];	  
  			 
  				  var imgPreviewInputDto = {
	    					  industry:$rootScope.selectedIndustry,
		    				  subIndustry:$rootScope.selectedsubIndustry,
		    				  sessionInputDTO: $rootScope.sessionInputObj
		                };
  			
  			   $http.post("/" + servicePrefix + "/rest/imgHierarchySrv/viewImgHierarchyForIndustry",imgPreviewInputDto).then(function(response) {
  			 
  				   if($rootScope.overlay != null){
  				 	$rootScope.overlay.style.display = "none";
  				 	$rootScope.popup.style.display = "none";
  				   }
  				   if($rootScope.overlay_admin != null){
  				    	$rootScope.overlay_admin.style.display = "none";
  						$rootScope.popup_admin.style.display = "none";
  				    	}
  		        if (response.status === 200) {
  		        	 if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
  		       	      		$rootScope.checkAuthorization();
  		       	      	}
  		        	 {
  		        		 var responseData=[];
  		        	responseData.push(response.data);
  		            $rootScope.listData = responseData;
  		            var responseData2 = responseData;
  		            $rootScope.hierarchyData = responseData;
  		        	 }
  		            }});
			}
			else
		    		  {
		    			  $rootScope.listData =[];	  
		    			  if($rootScope.create.templateType == "1" || $rootScope.create.templateType == "2"){
		    				  var imgPreviewInputDto = {
			    					  selectedArea:"Cross Industry",
				    				  sessionInputDTO: $rootScope.sessionInputObj
				                };
		    			  }
		    			  else{
			    			  var imgPreviewInputDto = {
			    					  selectedArea:$rootScope.selectedArea.value,
				    				  sessionInputDTO: $rootScope.sessionInputObj
				                };
		    			  }
		    			   $http.post("/" + servicePrefix + "/rest/imgHierarchySrv/viewImgHierarchy",imgPreviewInputDto).then(function(response) {
		    			 
		    				   if($rootScope.overlay != null){
		    				 	$rootScope.overlay.style.display = "none";
		    				 	$rootScope.popup.style.display = "none";
		    				   }
		    				   if($rootScope.overlay_admin != null){
		    				    	$rootScope.overlay_admin.style.display = "none";
		    						$rootScope.popup_admin.style.display = "none";
		    				    	}
		    		        if (response.status === 200) {
		    		        	 if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
		    		       	      		$rootScope.checkAuthorization();
		    		       	      	}
		    		        	 {
		    		        		 var responseData=[];
		    		        	responseData.push(response.data);
		    		            $rootScope.listData = responseData;
		    		            var responseData2 = responseData;
		    		            $rootScope.hierarchyData = responseData;
		    		        	 }
		    		            }});
		    			  }

$scope.savingManualConfig = function(item,selectedValue){
    var recentSelectedScope = {};
    //$rootScope.savingManualConfig = [];

    if(item.nodetype == 'IMG'){
 	   recentSelectedScope.id = item.id;
 	   recentSelectedScope.imgId = item.imgId;
 	   recentSelectedScope.imgDescription = (item.sequence == "" ? item.imgDescription : item.imgDescription.split(/_(.+)/)[1]);
 	   recentSelectedScope.sequence = item.sequence;
 	   recentSelectedScope.enabled = item.enabled;
 	  
 	   recentSelectedScope.isMasterData = item.isMasterData;
 	  
 	   recentSelectedScope.trType = item.trType;
 	   recentSelectedScope.customizingTr = "";
 	   recentSelectedScope.workbenchTr = "";
 	   recentSelectedScope.customizingTr_readOnly = true;
 	   recentSelectedScope.workbenchTr_readOnly = true;
 	   recentSelectedScope.customizingTr_mode = "";
 	   recentSelectedScope.workbenchTr_mode = "";
 	   recentSelectedScope.tranId = 0;
 	   recentSelectedScope.scopeExists = false;
           if(selectedValue === true){
        	   	count++;
                  index = -1;
                  for(var a= 0, arrLen = $rootScope.selectedScopeData.length;a< arrLen ;a++){
                       if($rootScope.selectedScopeData[a].imgId == recentSelectedScope.imgId){
                              index = a;
                              break;
                       }
                  }
                  
                  if (index == -1) {
                	  if(recentSelectedScope.enabled == "1" && $rootScope.hierarchyTypes.value == "Business Process"){   
                     	   if($rootScope.savingManualConfig.indexOf(recentSelectedScope) == -1)
                     		   $rootScope.savingManualConfig.push(recentSelectedScope);
                     	  
                	  }
                  }
                	  if(keys == undefined)
                     		   {
                     		   var output = [], 
                     		   keys = [];
                     		   }
            	    			var collection =  $rootScope.savingManualConfig;
            	    			var keyname = "imgId";
            	    			angular.forEach(collection, function(item) {
            	    			var key = item[keyname];
                            if(keys.indexOf(key) === -1) {
                                keys.push(key);
                                output.push(item);

            	    			}
                            $rootScope.savingManualConfig = output;
            	    			});
            }
          
           else if(selectedValue === false){

         	 
         		  index = -1;
                   for(var a= 0,arrLen = $rootScope.savingManualConfig.length;a< arrLen ;a++){
                        if($rootScope.savingManualConfig[a].imgId == recentSelectedScope.imgId){
                               index = a;
                               break;
                        }
                   }
                
                   if (index > -1) {
                         $rootScope.savingManualConfig.splice(index, 1);
                    }
                 
           }
    }else {
           for(var x = 0,childrenLen = item.children.length;x < childrenLen ; x++){
         	
           $scope.savingManualConfig(item.children[x],selectedValue);
           }
    }
    console.log($rootScope.savingManualConfig);
 };
}