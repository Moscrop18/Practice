var app = angular.module('yapp').factory('apiService',['$http','$rootScope','ngDialog',function apiService($http,$rootScope,ngDialog){

/*app.factory('apiService', apiService);
apiService.$inject = ['$http','$rootScope','ngDialog'];

function apiService($http,$rootScope,ngDialog)*/ 
     var self = this;
     var result = [];
   
  self.get= function(url, config, success, failure) {
	 /* if($rootScope.createimg == false){
		  $http.get("/" + servicePrefix + "/rest/imgHierarchySrv/viewImgHierarchy")
		  .then(function(response) {
        if (response.status === 200) {
        	var responseData=[];
        	responseData.push(response.data);
            $rootScope.listData = responseData;
           
            }});

	 }
	  else */

	 /* if($rootScope.createimg == true && $rootScope.hierarchyTypes.value == "IMG")
		  {
		 
		  var imgPreviewInputDto = {
				  selectedOmid:$rootScope.projOmId,
				  sessionInputDTO: $rootScope.sessionInputObj
            };
		   $http.post("/" + servicePrefix + "/rest/clientImgHierarchySrv/viewClientImgHierarchy",imgPreviewInputDto).then(function(response) {
			   if($rootScope.overlay != null){
			 	$rootScope.overlay.style.display = "none";
			 	$rootScope.popup.style.display = "none";
			   }
			   if($rootScope.overlay_admin != null){
			    	$rootScope.overlay_admin.style.display = "none";
					$rootScope.popup_admin.style.display = "none";
			    	}
	        if (response.status === 200) {
	        	 if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
	       	      		$rootScope.checkAuthorization();
	       	      	}
	        	 else{ var responseData=[];
	        	responseData.push(JSON.parse(response.data.resMessageDto.message));
	            $rootScope.listData = responseData;
	            var responseData2 = responseData;
	            $rootScope.hierarchyData = responseData;
	        	 }
	            }});
		  }else	  if($rootScope.createimg == true && $rootScope.hierarchyTypes.value == "Business Process")
	  {
	 
	  var imgPreviewInputDto = {
			  selectedOmid:$rootScope.projOmId,
			  sessionInputDTO: $rootScope.sessionInputObj
        };
	   $http.post("/" + servicePrefix + "/rest/imgHierarchySrv/viewImgHierarchy",$rootScope.sessionInputObj).then(function(response) {
		   if($rootScope.overlay != null){
		 	$rootScope.overlay.style.display = "none";
		 	$rootScope.popup.style.display = "none";
		   }
		   if($rootScope.overlay_admin != null){
		    	$rootScope.overlay_admin.style.display = "none";
				$rootScope.popup_admin.style.display = "none";
		    	}
        if (response.status === 200) {
        	 if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
       	      		$rootScope.checkAuthorization();
       	      	}
        	 {
        		 var responseData=[];
        	responseData.push(response.data);
            $rootScope.listData = responseData;
            var responseData2 = responseData;
            $rootScope.hierarchyData = responseData;
        	 }
            }});
	  } else*/
	  {
		  
		  if($rootScope.masterTreeResponse != null && $rootScope.masterTreeResponse.length == 0){
		  $http({
	        	method: 'POST',
	        	url:"/" + servicePrefix + "/rest/imgHierarchySrv/viewImgHierarchy",
	        	data : $rootScope.sessionInputObj
	        }).then(function(response) {
			    if(response.status === 200){
			    	if($rootScope.overlay_admin != null){
			    	$rootScope.overlay_admin.style.display = "none";
					$rootScope.popup_admin.style.display = "none";
			    	}
			    	if(response.data != null){
			    		 if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
			       	      		$rootScope.checkAuthorization();
			       	      	}else
			       	      		{
			    	var responsedata=[];
			    	$rootScope.hierarchyData = [];
			        responsedata.push(response.data);
			        $rootScope.listData = responsedata;	
			        //return responsedata;
			        $rootScope.hierarchyData.push(response.data);
			       	      		}
			        //console.log($rootScope.hierarchyData);
			    	  }
			    	}
			    else{
			    	if($rootScope.overlay_admin != null){
			    	$rootScope.overlay_admin.style.display = "none";
					$rootScope.popup_admin.style.display = "none";
			    	}
			    	}
		  });
		  }
		  else{
			  angular.copy($rootScope.masterTreeResponse,$rootScope.listData);

		 }
	  }
   
	  	var result = $rootScope.listData;
    

       if(result != null && result[0] != null && result[0] != ""){
    	  
       return success(result);
       }
   
 }

  return self;
}]);