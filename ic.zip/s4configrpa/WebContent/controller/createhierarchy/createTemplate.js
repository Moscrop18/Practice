
var app = angular.module('yapp').controller('createTemplatePage', ["ngDialog","$filter","Upload","$scope","$rootScope","$http","$mdDialog","$mdMedia","$location","$timeout","$window","apiService","ivhTreeviewMgr","ivhTreeviewBfs","ivhTreeviewOptions","tree","$ocLazyLoad", function(ngDialog,$filter,Upload,$scope,$rootScope,$http,$mdDialog,$mdMedia,$location,$timeout,$window,apiService,ivhTreeviewMgr,ivhTreeviewBfs,ivhTreeviewOptions,tree,$ocLazyLoad) {	
	$ocLazyLoad.load(controllerName+'/createhierarchy/createTemplate.js?ver='+version);
	var noAuth = "false";
/*	var cookie = document.cookie;
		var cookieAuthParams = cookie.split(';');
		for (var cp1 = 0,arrLen = cookieAuthParams.length; cp1 < arrLen ; cp1++) {*/
			/*if (cookieAuthParams[cp1].split('=')[0].trim() == "adminAuth" && cookieAuthParams[cp1].split('=')[1].trim() == "true") {
				noAuth = "true"
			}*/
			if ($rootScope.adminAuth == "true") {
				noAuth = "true"
			}
			/*if($rootScope.appValidityupdateManageTrTable == undefined){
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userDetails") {
					$rootScope.userValidation = cookieAuthParams[cp1].split('=')[1];
					console.log($rootScope.userValidation.role);
					
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userRole") {
					$rootScope.userRole = cookieAuthParams[cp1].split('=')[1];
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "roleId") {
					$rootScope.roleId = cookieAuthParams[cp1].split('=')[1];
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userName") {
					$rootScope.username = cookieAuthParams[cp1].split('=')[1];
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userFirstName") {
					 $rootScope.userFirstName = cookieAuthParams[cp1].split('=')[1];
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userLastName") {
					$rootScope.userLastName = cookieAuthParams[cp1].split('=')[1];
				}
		  }
		}*/
	if (noAuth == "false") {
			$location.path('/loginPage');
		}
	 $scope.trDataSearch = "";
	 $rootScope.stuff = [];
	 $rootScope.stuff1 = [];
	 $rootScope.stuff2 = [];
	 $rootScope.tree = [];
	 // Code to hide the Hamburger Menu 
	 document.getElementById("mySidenav").style.width = "0px";
	 if(document.getElementById("showSubMenu") != null)
			document.getElementById("showSubMenu").style.display = "none";
	 document.getElementById("hambrgrCloseMenu").style.display = "none";
	 document.getElementById("hambrgrMenu").style.display = "inline-block";
	 
	 $rootScope.isclientimgexists = false;
	 $rootScope.clientimghierarchy = false;
	 if($rootScope.allOmId == undefined)
		 $rootScope.allOmId = [];
	 if($rootScope.selectedid == undefined)
		 $rootScope.selectedid = [];
	 if($rootScope.selectedid[0] == undefined)
		 $rootScope.selectedid[0] = [];
	 if($rootScope.selectedimg == undefined)
		 $rootScope.selectedimg = [];
	 if($rootScope.scopevalueArray == undefined)
		 $rootScope.scopevalueArray =[];
	 if($rootScope.scopevalueArrays == undefined)
		 $rootScope.scopevalueArrays =[];
	 if($rootScope.scopevalueArrays1 == undefined)
		 $rootScope.scopevalueArrays1 =[];

			$rootScope.scopevalueArrays1 =[];
			$rootScope.scopevalueArray = [];
			$rootScope.scopevalueArrays = [];
	// if($rootScope.scopevalueArrayid == undefined)
		 $rootScope.scopevalueArrayid =[];

			$rootScope.scopevalueArrays1 =[];
			$rootScope.scopevalueArray = [];
			$rootScope.scopevalueArrays = [];
				 $rootScope.clienthierarchyok = false;
				 //added for new TR Approach
				 $rootScope.trData = [];
				 $rootScope.troverride = false;
				 $rootScope.editTR = true;
				$rootScope.selectedProjTROveride = "";
				 $scope.systemIdTrVal = null;
				 $rootScope.selectedSystemid=undefined;
				//$rootScope.tempselectedProjTROveride = "";
				$rootScope.trObject = {};
				$rootScope.trObject.tempselectedProjTROveride ="";
				$rootScope.trObject.checkbox_status = "";
				 //$rootScope.trtype = "trtype";
				
				$rootScope.selectedOmId = undefined;
				$rootScope.previewtab1=true;
				
				$rootScope.selectedArea = {
				   		 "value": "Cross Industry", 
				   	     "values": ['Cross Industry','Industry'] 
				       };
				
	 $scope.myClickTab1 = function(){
		
		 $rootScope.previewtab1 =true;
			$rootScope.selectedTab = "tab1";
			$rootScope.IMGHierarchyMsg="CREATE IMG HIERARCHY";
		 $rootScope.troverride = false;
		 if($rootScope.selectedOmId != undefined && $rootScope.selectedOmId != null && $rootScope.selectedOmId != ""
			 && $rootScope.selectedArea.value != null && $rootScope.selectedArea.value != "") {
			 	$rootScope.createimg =false;
			 	
			 /*var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
		        $mdDialog.show({
		            controller: function($scope, $mdDialog){
		            $rootScope.isLoading = true;
		            },
		            templateUrl: 'view/busy.html?ver='+version,
		            parent: angular.element(document.body),
		            clickOutsideToClose: false,
		            fullscreen: useFullScreen,
		            escapeToClose: false,
		        })
		        .then(function(answer) {
		        }, function() {
		        });*/
		        
		 //$scope.getScopeData($rootScope.selectedOmId);
		        $scope.projectSpecificTree();
		 }
	 }
	 $scope.myClickTab2 = function(){
		 $rootScope.previewtab1 =true;
		// $rootScope.trData = [];
		 $rootScope.selectedTab = "tab2";	
		 $rootScope.troverride = true;
		 $rootScope.modifyTR = "Edit";
		 $rootScope.tempTrData = [];
		 $rootScope.createimg = true;
		 $rootScope.trData=[];
		 if($rootScope.selectedSystemid == "" || $rootScope.selectedSystemid== undefined)
			 $rootScope.isSysSelected = true;
		 //service call
		 var arrLen = 0;
		 if($rootScope.selectedOmId != ""){

		        /*var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
		        $mdDialog.show({
		            controller: function($scope, $mdDialog){
		            $scope.isLoading = true;
		            },
		            templateUrl: 'view/busy.html?ver='+version,
		            parent: angular.element(document.body),
		            clickOutsideToClose: false,
		            fullscreen: useFullScreen,
		            escapeToClose: false,
		        })
		        .then(function(answer) {
		        }, function() {
		        });*/
		  			
			 if( $rootScope.targetSysData != null &&  $rootScope.targetSysData.length == 0){
				 var inputParam ={
						  systemType: "target",
						  omID: $rootScope.selectedOmId,
						  sessionInputDTO: $rootScope.sessionInputObj
				  }
				 /*$http({
		               method: "GET",
		               url: "/" + servicePrefix + "/rest/configSrv/getSourceTargetDetails/target/"+$rootScope.selectedOmId+"/"+$rootScope.username,
		               headers:{
				            'authorization' :  $rootScope.userValidation.userToken
				            }
		           })*/$http.post("/" + servicePrefix + "/rest/configSrv/getSourceTargetDetails", inputParam).then(function mySucces(response) {
		               if (response.data.resMessageDto.message == "Success") {
		            	   $scope.target = [];
		                //   var target = response.data.resSapSystemList;
		            	   for (var i = 0; i < $rootScope.targetSysData.length; i++) {
		       				if( $rootScope.targetSysData[i].id==$rootScope.selectedSystemid){
		       					$scope.systemIdTrVal = $rootScope.targetSysData[i].systemId;
		       					break;
		       				}
		       			}
		                 /*  for(var i=0;i<response.data.resSapSystemList.length;i++){
		                	   $scope.target.push(response.data.resSapSystemList[i].destinationName);
		                	   
		                	   }*/
		                   
		                   $rootScope.targetSysData = response.data.systemList;
		                //   console.log($scope.target);
		                   //var result = [];
		               }});
			 }
			 var inputParam = {
					 systemType:$rootScope.selectedSystemid,
					 omID:$rootScope.selectedOmId,
					 selectedArea:$rootScope.selectedArea.value,
					 sessionInputDTO:$rootScope.sessionInputObj
			 }
			 
			 if(  $rootScope.selectedSystemid != undefined && $rootScope.selectedSystemid != "" && ($rootScope.trData == null || $rootScope.trData.length == 0)){
				   $http.post("/" + servicePrefix + "/rest/manageTR/displayManageTrTable",inputParam).then(function(response) {
			
			 //console.log($rootScope.OmId);
			    if(response.status === 200 && response.data.trResponseDto != null){
			    	 $mdDialog.cancel()
			    	$rootScope.trData = response.data.trResponseDto;	
			    	 arrLen = response.data.trListDto.trResponseDto.length;
			    	for(var i=0;i<arrLen;i++){
			    	
			    	$rootScope.trData[i].trtype1="trtype";
			    	$rootScope.trData[i].trtype2="trtype";
			    	
			    	
			    	}
			    	angular.copy($rootScope.trData,$rootScope.tempTrData);
			    	
			    	//console.log($rootScope.trData);
			    	 if($rootScope.trObject.tempselectedProjTROveride != ""){
			    		 $rootScope.trObject.checkbox_status = true;
			    		 $rootScope.tempcheckbox_status =  $rootScope.trObject.checkbox_status;
			    	 	}else{
			    	 		$rootScope.trObject.tempselectedProjTROveride = "P";
			    	 	}
			   }
		 });
		 }
		  else{
			  $mdDialog.cancel()
		    	//$rootScope.trData = response.data;	
		    
		    	
		    	angular.copy($rootScope.trData,$rootScope.tempTrData);
		    	
		    	//console.log($rootScope.trData);
		    	 if($rootScope.trObject.tempselectedProjTROveride != ""){
		    		 $rootScope.trObject.checkbox_status = true;
		    		 $rootScope.tempcheckbox_status =  $rootScope.trObject.checkbox_status;
		    	 	}else{
		    	 		$rootScope.trObject.tempselectedProjTROveride = "P";
		    	 	}
		  }
		 }
		 else{
			 console.log("please select Project");
		 }
	 };
	 
	 $scope.myClickCopyTab2 = function(){
		 $rootScope.previewtab1 =false;
			// $rootScope.trData = [];
			 $rootScope.selectedTab = "copyTab2";	
			 $rootScope.troverride = true;
			 $rootScope.modifyTR = "Edit";
			 $rootScope.tempTrData = [];
			 $rootScope.createimg = true;
			 $rootScope.trData=[];
			 if($rootScope.selectedSystemid == "" || $rootScope.selectedSystemid== undefined)
				 $rootScope.isSysSelected = true;
			 //service call
			 var arrLen = 0;
			 if($rootScope.selectedOmId != ""){

			        /*var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
			        $mdDialog.show({
			            controller: function($scope, $mdDialog){
			            $scope.isLoading = true;
			            },
			            templateUrl: 'view/busy.html?ver='+version,
			            parent: angular.element(document.body),
			            clickOutsideToClose: false,
			            fullscreen: useFullScreen,
			            escapeToClose: false,
			        })
			        .then(function(answer) {
			        }, function() {
			        });*/
			  			
				 if( $rootScope.targetSysData != null &&  $rootScope.targetSysData.length == 0){
					 var inputParam ={
							  systemType: "target",
							  omID: $rootScope.selectedOmId,
							  sessionInputDTO: $rootScope.sessionInputObj
					  }
					 /*$http({
			               method: "GET",
			               url: "/" + servicePrefix + "/rest/configSrv/getSourceTargetDetails/target/"+$rootScope.selectedOmId+"/"+$rootScope.username,
			               headers:{
					            'authorization' :  $rootScope.userValidation.userToken
					            }
			           })*/$http.post("/" + servicePrefix + "/rest/configSrv/getSourceTargetDetails", inputParam).then(function mySucces(response) {
			               if (response.data.resMessageDto.message == "Success") {
			            	   $scope.target = [];
			                //   var target = response.data.resSapSystemList;
			            	   for (var i = 0; i < $rootScope.targetSysData.length; i++) {
			       				if( $rootScope.targetSysData[i].id==$rootScope.selectedSystemid){
			       					$scope.systemIdTrVal = $rootScope.targetSysData[i].systemId;
			       					break;
			       				}
			       			}
			                 /*  for(var i=0;i<response.data.resSapSystemList.length;i++){
			                	   $scope.target.push(response.data.resSapSystemList[i].destinationName);
			                	   
			                	   }*/
			                   
			                   $rootScope.targetSysData = response.data.systemList;
			                //   console.log($scope.target);
			                   //var result = [];
			               }});
				 }
				 var inputParam = {
						 systemType:$rootScope.selectedSystemid,
						 omID:$rootScope.selectedOmId,
						 sessionInputDTO:$rootScope.sessionInputObj
				 }
				 
				 if(  $rootScope.selectedSystemid != undefined && $rootScope.selectedSystemid != "" && ($rootScope.trData == null || $rootScope.trData.length == 0)){
					   $http.post("/" + servicePrefix + "/rest/manageTR/displayManageTrTableCopyFunctionality",inputParam).then(function(response) {
				
				 //console.log($rootScope.OmId);
				    if(response.status === 200 && response.data.trResponseDto != null){
				    	 $mdDialog.cancel()
				    	$rootScope.trData = response.data.trResponseDto;	
				    	 arrLen = response.data.trListDto.trResponseDto.length;
				    	for(var i=0;i<arrLen;i++){
				    	
				    	$rootScope.trData[i].trtype1="trtype";
				    	$rootScope.trData[i].trtype2="trtype";
				    	
				    	
				    	}
				    	angular.copy($rootScope.trData,$rootScope.tempTrData);
				    	
				    	//console.log($rootScope.trData);
				    	 if($rootScope.trObject.tempselectedProjTROveride != ""){
				    		 $rootScope.trObject.checkbox_status = true;
				    		 $rootScope.tempcheckbox_status =  $rootScope.trObject.checkbox_status;
				    	 	}else{
				    	 		$rootScope.trObject.tempselectedProjTROveride = "P";
				    	 	}
				   }
			 });
			 }
			  else{
				  $mdDialog.cancel()
			    	//$rootScope.trData = response.data;	
			    
			    	
			    	angular.copy($rootScope.trData,$rootScope.tempTrData);
			    	
			    	//console.log($rootScope.trData);
			    	 if($rootScope.trObject.tempselectedProjTROveride != ""){
			    		 $rootScope.trObject.checkbox_status = true;
			    		 $rootScope.tempcheckbox_status =  $rootScope.trObject.checkbox_status;
			    	 	}else{
			    	 		$rootScope.trObject.tempselectedProjTROveride = "P";
			    	 	}
			  }
			 }
			 else{
				 console.log("please select Project");
			 }
		 };
	 
	 $scope.myClickCopyTab1 = function(){
		 $rootScope.previewtab1 =false;
			$rootScope.selectedTab = "copyTab1";
			$rootScope.IMGHierarchyMsg="CREATE COPY IMG HIERARCHY";
		 $rootScope.troverride = false;
		 if($rootScope.selectedOmId != undefined && $rootScope.selectedOmId != null && $rootScope.selectedOmId != "") {
			 	$rootScope.createimg =false;
			
		        $scope.projectSpecificTreeForCopy();
		 }
	 }
	 
	 
	//$rootScope.clienthierarchy = false;
	
	//$rootScope.show = false;
	 $scope.yes ="true"
	 $scope.ok ="true"
		 $rootScope.selectedTreeviewData=[];     
		 if($rootScope.selectedScopeData == undefined)
	       {
	              $rootScope.selectedScopeData = [];
	       } 
	        angular.copy($rootScope.selectedScopeData,$rootScope.selectedTreeviewData);
	       
	        var params={
		            userID: $rootScope.username,
		            userRole: $rootScope.userRole,
		            sessionInputDTO: $rootScope.sessionInputObj 
		        };        
	       
	        
    //$scope.init = function () {
    	$rootScope.createimg = true;
    	$rootScope.clienthierarchydiv = true;
    	$rootScope.IMGHierarchyMsg = "CREATE IMG HIERARCHY";
    	
    	$rootScope.isManagetemplate = false;
    	var omIdArr = 0;
    	if($rootScope.masterTreeResponse == undefined)
    		$rootScope.masterTreeResponse = [];

    	 $http.post("/" + servicePrefix + "/rest/clientImgHierarchySrv/getCustomerId",params).then(function(response) {
		    
    		 if(response.status === 200){
		    	  if(response.data != null){
		    		  	  $rootScope.allOmId = []; 
		    		  	  $rootScope.OmId = [];
		    		  	  omIdArr = response.data.projDetails.length;
			    		  $rootScope.allOmId = response.data.projDetails;
			    	  }else{
		    		  	 $rootScope.allOmId = []; 
		    		  	 $rootScope.OmId = [];
		    	  }
		    }
		}); 
    	 
    	 var imgPreviewInputDto = {
				  selectedArea:$rootScope.selectedArea.value,
				  sessionInputDTO: $rootScope.sessionInputObj
           };

		    $http({
	        	method: 'POST',
	        	url:"/" + servicePrefix + "/rest/imgHierarchySrv/viewImgHierarchy",
	        	data : imgPreviewInputDto
	        }).then(function(response) {
		    if(response.status === 200){	    	
		    
			 if(response.data != null){
				 if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
       	      		$rootScope.checkAuthorization();
       	      	}
				 else{
				var responsedata=[];
				 
		        responsedata.push(response.data);
		        $rootScope.listData = responsedata;
		        $rootScope.tree.push(responsedata);
		        $rootScope.masterTreeResponse = responsedata.slice();
		        $scope.mastertree = true;
				 }
		    }else{
		    		  
		    	  }
		    } else {
		    
		    }
		}); 

	
$scope.getScopeData = function(omId,selectedArea){
	
	$rootScope.selectedSystemid=undefined;
		
	$rootScope.selectedOmId=undefined;
	$scope.trDataSearch = "";
	$rootScope.createimg = false;
	$rootScope.clienthierarchyok = false;
	$rootScope.stuff = [];
	$rootScope.stuff1 = [];
	$rootScope.trData = [];
	$rootScope.stuff2 = [];
	$rootScope.targetSysData = [];
	var arrLen = 0;
	//$rootScope.tempselectedProjTROveride = "";
	arrLen = $rootScope.allOmId.length;
	for(var i=0;i<arrLen;i++){
		if(omId != null && omId == $rootScope.allOmId[i].omId)
			{
			$rootScope.selectedOmId = $rootScope.allOmId[i].omId;
			$rootScope.selectedProjId = $rootScope.allOmId[i].projectName;
			$rootScope.selectedProjTROveride = $rootScope.allOmId[i].trOverride == null?"":$rootScope.allOmId[i].trOverride;
			break;
			
			}
	}
	if($rootScope.selectedProjTROveride != $rootScope.trObject.tempselectedProjTROveride)
		$rootScope.trObject.tempselectedProjTROveride = $rootScope.selectedProjTROveride;
	//angular.copy($rootScope.selectedProjTROveride,$rootScope.trObject.tempselectedProjTROveride);
	
	$rootScope.selectedid = [];
	$rootScope.trObject.checkbox_status = false;
	$rootScope.ischecked = false;
	if($rootScope.selectedOmId !== null)
		{
		
		$rootScope.isclientspecific = true;
		}
	 $rootScope.scopevalueArray=[];
	 
	 if( $rootScope.selectedTab == "tab1" && $rootScope.selectedOmId != undefined && $rootScope.selectedOmId != null && $rootScope.selectedOmId != "" &&
			 $rootScope.selectedArea.value != null && $rootScope.selectedArea.value != ""){
	
		 $scope.projectSpecificTree();
	}	
	 
	 if( $rootScope.selectedTab == "tab2" || $rootScope.selectedTab== "copyTab2" ){
		 //$rootScope.trData = [];
		 var inputParam ={
				  systemType: "target",
				  omID: $rootScope.selectedOmId,
				  sessionInputDTO: $rootScope.sessionInputObj
		  }
		 /*$http({
             method: "GET",
             url: "/" + servicePrefix + "/rest/configSrv/getSourceTargetDetails/target/"+$rootScope.selectedOmId+"/"+$rootScope.username,
             headers:{
		            'authorization' :  $rootScope.userValidation.userToken
		            }
         })*/$http.post("/" + servicePrefix + "/rest/configSrv/getSourceTargetDetails", inputParam).then(function mySucces(response) {
         	 $rootScope.targetSysData =[];
             if (response.data.resMessageDto.message == "Success") {
            	 if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
        	      		$rootScope.checkAuthorization();
        	      	}
            	 else{
            	 $scope.target = [];
            	 $scope.targetId =[];
          	   
                 /*for(var i=0;i<response.data.resSapSystemList.length;i++){
              	   $scope.target.push(response.data.resSapSystemList[i].destinationName);
              	   $scope.targetId.push(response.data.resSapSystemList[i].id);
              	   }*/
                  $rootScope.targetSysData = response.data.systemList;
            	 }
             }});
		 
		 $rootScope.createimg = true;
	
}
	 if( $rootScope.selectedTab == "copyTab1"){
			
		 $scope.projectSpecificTreeForCopy();
	}	
};

$scope.getSystemData = function(selectedSystemid) {
	
if($rootScope.selectedOmId != "" && selectedSystemid!=null && selectedSystemid!=undefined && selectedSystemid!=""){
	 var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
	 var overlay = document.getElementById("overlay");
     var popup = document.getElementById("busy");
     overlay.style.display = "block";
        busy.style.display = "inline-block";
	
					/* var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
				     $mdDialog.show({
				         controller: function($scope, $mdDialog){
				         $scope.isLoading = true;
				         },
				         templateUrl: 'view/busy.html?ver='+version,
				         parent: angular.element(document.body),
				         clickOutsideToClose: false,
				         fullscreen: useFullScreen,
				         escapeToClose: false,
				     })
				     .then(function(answer) {
				     }, function() {
				     });
				     */
				//     for(var i=0;i<$scope.target.length;i++){
				//    	 if($scope.target.indexOf(selectedSystem)!= -1){
				//    		 $scope.selectedTargetId = $rootScope.targetSysData[i].id;
				//    	 }
				//    		 
				//     }
$rootScope.selectedSystemid = selectedSystemid;
for (var i = 0,arrlen = $rootScope.targetSysData.length; i < arrlen; i++) {
	if( $rootScope.targetSysData[i].id==$rootScope.selectedSystemid){
		$scope.systemIdTrVal = $rootScope.targetSysData[i].systemId;
		break;
	}
}
	 $rootScope.tempTrData = [];
	 var inputParam = {
			 systemType:selectedSystemid,
			 omID:$rootScope.selectedOmId,
			 selectedArea:$rootScope.selectedArea.value,
			 sessionInputDTO:$rootScope.sessionInputObj
	 }
	 if( $rootScope.selectedTab == "tab2"){
	
	 $http.post("/" + servicePrefix + "/rest/manageTR/displayManageTrTable",inputParam).then(function(response) {
		 $mdDialog.cancel();  
		 $rootScope.isSysSelected = false;
		 var overlay = document.getElementById("overlay");
	     var popup = document.getElementById("busy");
	     overlay.style.display = "none";
	        busy.style.display = "none";
		 if(response.status === 200 && response.data != null){
			 if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
    	      		$rootScope.checkAuthorization();
    	      	}else{
		    	$rootScope.trData = response.data.trResponseDto;
		    	
		    	 angular.copy($rootScope.trData,$rootScope.tempTrData);
		    	 if($rootScope.trObject.tempselectedProjTROveride != ""){
		    		 $rootScope.trObject.checkbox_status = true;
		    		 $rootScope.tempcheckbox_status =  $rootScope.trObject.checkbox_status;
		    	 	}else{
		    	 		$rootScope.trObject.tempselectedProjTROveride = "P";
		    	 	}
    	      		}
		    	  }
		
	 });
	 }
	 if( $rootScope.selectedTab == "copyTab2"){
			
		 $http.post("/" + servicePrefix + "/rest/manageTR/displayManageTrTableCopyFunctionality",inputParam).then(function(response) {
			 $mdDialog.cancel();  
			 $rootScope.isSysSelected = false;
			 var overlay = document.getElementById("overlay");
		     var popup = document.getElementById("busy");
		     overlay.style.display = "none";
		        busy.style.display = "none";
			 if(response.status === 200 && response.data != null){
				 if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
	    	      		$rootScope.checkAuthorization();
	    	      	}else{
			    	$rootScope.trData = response.data.trResponseDto;
			    	
			    	 angular.copy($rootScope.trData,$rootScope.tempTrData);
			    	 if($rootScope.trObject.tempselectedProjTROveride != ""){
			    		 $rootScope.trObject.checkbox_status = true;
			    		 $rootScope.tempcheckbox_status =  $rootScope.trObject.checkbox_status;
			    	 	}else{
			    	 		$rootScope.trObject.tempselectedProjTROveride = "P";
			    	 	}
	    	      		}
			    	  }
			
		 });
		 }
	 }
	 else{
		// $mdDialog.cancel();
		 //$scope.isLoading = false;
		 $rootScope.isSysSelected = true;
		 console.log("please select Project");
		 $rootScope.trData =[];
	 }
	
};

$scope.projectSpecificTree = function(){
	
	/* var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
	 	$mdDialog.show({
      controller: function($scope, $mdDialog){
      $scope.isLoading = true;
      },
      templateUrl: 'view/busy.html?ver='+version,
      parent: angular.element(document.body),
      clickOutsideToClose: false,
      fullscreen: useFullScreen,
      escapeToClose: false,
  })
  .then(function(answer) {
  }, function() {
  });*/
	 	var overlay = document.getElementById("overlay");
	    var popup = document.getElementById("busy");
	    overlay.style.display = "block";
	    popup.style.display = "inline-block";
	    
	    var imgPreviewInputDto = {
	    		selectedArea:$rootScope.selectedArea.value,
				  selectedOmid:$rootScope.selectedOmId,
      		  sessionInputDTO: $rootScope.sessionInputObj
            };
	// if( $rootScope.selectedTab =="tab1"){
		 if($rootScope.selectedOmId !== null && ($rootScope.stuff1 == null || $rootScope.stuff1.length == 0)) {
			// $rootScope.stuff1 = [];
		/*$http({
	        method: "GET",
	        url: "/" + servicePrefix + "/rest/clientImgHierarchySrv/viewClientImgHierarchy/"+$rootScope.selectedOmId+"/"+$rootScope.username,
	        headers:{
	            'authorization' :  $rootScope.userValidation.userToken
	            }
			}*/$http.post("/" + servicePrefix + "/rest/clientImgHierarchySrv/viewClientImgHierarchy",imgPreviewInputDto).then(function(response) {
			    if(response.status === 200){
			    	  if(response.data.resMessageDto.message != null && response.data.resMessageDto.message !== ""){
			    		 /* cLOSING THE NEW BUSY iNIDICATOR*/
			    		  if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
			       	      		$rootScope.checkAuthorization();
			       	      	}  
			    		  else{   
			    		  $rootScope.createimg = false;
			    		  $rootScope.isclientimgexists = true;
			    		  $rootScope.clientimghierarchy = false;
			    		  $rootScope.IMGHierarchyMsg = "MODIFY IMG HIERARCHY";
					    	var responsedata=[];
					        responsedata.push(JSON.parse(response.data.resMessageDto.message));
					        
					        $rootScope.stuff1.push(JSON.parse(response.data.resMessageDto.message));
					        //$rootScope.trData = response.data.outputDataList;
					   	 	if(response.data.imgId != null){
					   	 		$rootScope.selectedid=response.data.imgId;
					   	 		$rootScope.scopevalueArrayid = response.data.imgId;
					   	 		}		
			      //  if($rootScope.selectedOmId !== null)
					//{
					$scope.clienthierarchy = true;
					$rootScope.isclientspecific = true;
					var overlay = document.getElementById("overlay");
	    		     var popup = document.getElementById("busy");
	    		     overlay.style.display = "none";
	    		     popup.style.display = "none";
					//}
					
			    	//$mdDialog.cancel();
			    	  }
			    	  }else{
			    		  	 var overlay = document.getElementById("overlay");
			    		     var popup = document.getElementById("busy");
			    		     overlay.style.display = "none";
			    		     popup.style.display = "none";
			    		     
			    		  $rootScope.createimg = false;
			    		  $rootScope.isclientimgexists = false;
			    		  $rootScope.IMGHierarchyMsg =  "CREATE IMG HIERARCHY";
			    		  $rootScope.clientimghierarchy = true;
			    		  
					    	//$mdDialog.cancel();

			    		 // $rootScope.clientimghierarchymsg = "No IMG Hierarchy is configured for project " + $rootScope.selectedOmId.split(" - ")[1];
			    	      ngDialog.openConfirm({
			                    template: '<p>' +"No IMG Hierarchy is configured for project"+" "+ 	$rootScope.selectedProjId + '</p>',
			                    plain: true,
			                    scope: $scope,
			                    closeByDocument: true,
			                    closeByEscape: true,
			                    showClose: true,
			                    height:120,
			                    width: 350,
			                    className:'ngdialog-theme-default CLASS_2'
			                });  
			    	  }
			    } else {
			    	 var overlay = document.getElementById("overlay");
		   		     var popup = document.getElementById("busy");
		   		     overlay.style.display = "none";
		   		     popup.style.display = "none";
			    	
		   		     $rootScope.isclientimgexists = false;
			        ngDialog.openConfirm({
		                template: '<p>' +"No records found!"+ '</p>',
		                plain: true,
		                scope: $scope,
		                closeByDocument: true,
		                closeByEscape: true,
		                showClose: true,
		                height:120,
		                width: 350,
		                className:'ngdialog-theme-default CLASS_2'
		            }); 
			    }
			});
		 			/*var self = this;self.stuff = $rootScope.stuff;*/
		 }
		 
		 else{
			 var overlay = document.getElementById("overlay");
   		     var popup = document.getElementById("busy");
   		     overlay.style.display = "none";
   		     popup.style.display = "none";
   		     
   		        $rootScope.IMGHierarchyMsg = "MODIFY IMG HIERARCHY";
   		        $rootScope.createimg = false;
			// $mdDialog.cancel();
			 //$scope.isLoading = false;

	           /* $rootScope.isLoading = false;
		    	$mdDialog.cancel();
*/
}
		/*$http.get("/" + servicePrefix + "/rest/clientImgHierarchySrv/previewClientImgHierarchy/"+$rootScope.selectedOmId).then(function(response) {
		       if(response.status === 200){
		       	
		       	if(response.data != null && response.data !== ""){
			    		 var responsedata=[];
			    		$rootScope.scopevalueArrayid =[];
			    		 responsedata.push(response.data);
			    		// if(response.data.clientId !=null)
			    			 //for(var i=0; i<response.data.clientId.length;i++)
			    		 if(response.data.imgId != null)
			    		 $rootScope.selectedid=response.data.imgId;
			    		 if(response.data.imgId != null)
			    		 $rootScope.scopevalueArrayid = response.data.imgId;
			    		 
		       	}
		       }
		   });*/
		// }
};

$scope.projectSpecificTreeForCopy = function(){
	 	var overlay = document.getElementById("overlay");
	    var popup = document.getElementById("busy");
	    overlay.style.display = "block";
	    popup.style.display = "inline-block";
	    
	    var imgPreviewInputDto = {
				  selectedOmid:$rootScope.selectedOmId,
      		  sessionInputDTO: $rootScope.sessionInputObj
            };
	// if( $rootScope.selectedTab =="tab1"){
		 if($rootScope.selectedOmId !== null && ($rootScope.stuff2 == null || $rootScope.stuff2.length == 0)) {
			$http.post("/" + servicePrefix + "/rest/clientImgHierarchySrv/viewClientBPHierarchyCopyFuntionality",imgPreviewInputDto).then(function(response) {
			    if(response.status === 200){
			    	  if(response.data.resMessageDto.message != null && response.data.resMessageDto.message !== ""){
			    		 /* cLOSING THE NEW BUSY iNIDICATOR*/
			    		  if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
			       	      		$rootScope.checkAuthorization();
			       	      	}  
			    		  else{   
			    		  $rootScope.createimg = false;
			    		  $rootScope.isclientimgexists = true;
			    		  $rootScope.clientimghierarchy = false;
			    		  $rootScope.IMGHierarchyMsg = "MODIFY COPY IMG HIERARCHY";
					    	var responsedata=[];
					        responsedata.push(JSON.parse(response.data.resMessageDto.message));
					        
					        $rootScope.stuff2.push(JSON.parse(response.data.resMessageDto.message));
					        //$rootScope.trData = response.data.outputDataList;
					   	 	if(response.data.imgId != null){
					   	 		$rootScope.selectedid=response.data.imgId;
					   	 		$rootScope.scopevalueArrayid = response.data.imgId;
					   	 		}		
			      //  if($rootScope.selectedOmId !== null)
					//{
					$scope.clienthierarchy = true;
					$rootScope.isclientspecific = true;
					var overlay = document.getElementById("overlay");
	    		     var popup = document.getElementById("busy");
	    		     overlay.style.display = "none";
	    		     popup.style.display = "none";
					//}
					
			    	//$mdDialog.cancel();
			    	  }
			    	  }else{
			    		  	 var overlay = document.getElementById("overlay");
			    		     var popup = document.getElementById("busy");
			    		     overlay.style.display = "none";
			    		     popup.style.display = "none";
			    		     
			    		  $rootScope.createimg = false;
			    		  $rootScope.isclientimgexists = false;
			    		  $rootScope.IMGHierarchyMsg =  "CREATE COPY IMG HIERARCHY";
			    		  $rootScope.clientimghierarchy = true;
			    		  
					    	//$mdDialog.cancel();

			    		 // $rootScope.clientimghierarchymsg = "No IMG Hierarchy is configured for project " + $rootScope.selectedOmId.split(" - ")[1];
			    	      ngDialog.openConfirm({
			                    template: '<p>' +"No IMG Hierarchy is configured for project"+" "+ 	$rootScope.selectedProjId + '</p>',
			                    plain: true,
			                    scope: $scope,
			                    closeByDocument: true,
			                    closeByEscape: true,
			                    showClose: true,
			                    height:120,
			                    width: 350,
			                    className:'ngdialog-theme-default CLASS_2'
			                });  
			    	  }
			    } else {
			    	 var overlay = document.getElementById("overlay");
		   		     var popup = document.getElementById("busy");
		   		     overlay.style.display = "none";
		   		     popup.style.display = "none";
			    	
		   		     $rootScope.isclientimgexists = false;
			        ngDialog.openConfirm({
		                template: '<p>' +"No records found!"+ '</p>',
		                plain: true,
		                scope: $scope,
		                closeByDocument: true,
		                closeByEscape: true,
		                showClose: true,
		                height:120,
		                width: 350,
		                className:'ngdialog-theme-default CLASS_2'
		            }); 
			    }
			});
		 }
		 
		 else{
			 var overlay = document.getElementById("overlay");
   		     var popup = document.getElementById("busy");
   		     overlay.style.display = "none";
   		     popup.style.display = "none";
   		     
   		        $rootScope.IMGHierarchyMsg = "MODIFY COPY IMG HIERARCHY";
   		        $rootScope.createimg = false;
}

};


$scope.trOverrideEnable = function(){
	
	
	if($rootScope.trObject.checkbox_status){
		$rootScope.trObject.tempselectedProjTROveride = "P";
	}else{
		$rootScope.trObject.tempselectedProjTROveride = "";
	}
	
	 /*if($rootScope.trObject.tempselectedProjTROveride != ""){
		 $rootScope.trObject.checkbox_status = true;
		// $rootScope.tempcheckbox_status =  $rootScope.trObject.checkbox_status;
	 	}else{
	 		$rootScope.trObject.tempselectedProjTROveride = "P";
	 	}*/
};
$scope.startImport = function(){
	    	$rootScope.isclientspecific = false;
	    	$rootScope.selectedScopeData = [];
	    	$rootScope.create={};
	    	$rootScope.create.templateType="";
	    	$rootScope.overlay_admin = document.getElementById("overlay");
			$rootScope.popup_admin = document.getElementById("busy");
			$rootScope.overlay_admin.style.display = "block";
			$rootScope.popup_admin.style.display = "inline-block";
		if($rootScope.isclientimgexists){	
			 var imgPreviewInputDto = {
					 selectedArea:$rootScope.selectedArea.value,
					  selectedOmid:$rootScope.selectedOmId,
	        		  sessionInputDTO: $rootScope.sessionInputObj
	              };
		 $http.post("/" + servicePrefix + "/rest/clientImgHierarchySrv/previewClientImgHierarchy", imgPreviewInputDto).then(function(response) {
	 	       if(response.status === 200){
	 	       	
	 	       	if(response.data != null && response.data !== ""){
	 	       	 if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
	       	      		$rootScope.checkAuthorization();
	       	      	}
	 	       	else { 		var responsedata = [];
	 		    			$rootScope.scopevalueArrayid =[];
	 		    			responsedata.push(response.data);
	 		    			if(response.data.imgId != null){
	 		    			$rootScope.selectedid = response.data.imgId;
		 		    		$rootScope.scopevalueArrayid = response.data.imgId;	 
	 		    		 }
	 	       		}
	 	       	 }
	 	       }
	 	   });
}
	    	ngDialog.openConfirm({
	            template: 'view/createhierarchy/createTreeView.html?ver='+version,
	            preCloseCallback:function(){
	            	$mdDialog.cancel();
	            	if($rootScope.validClose == undefined){
	            		//$rootScope.selectedScopeData = $rootScope.selectedTreeviewData;
	   	       		 
		   	       		$rootScope.scopevalueArray=[];
		   	       		//$rootScope.selectedid=[];
		   	       		 for(var x = 0; x < $rootScope.selectedScopeData.length; x++){
		   	          		  if($rootScope.selectedScopeData[x].enabled === 1){
		   	          		  if(x == 0)
		   	          		  { 	
		   	          			
		   	          			 $rootScope.scopevalueArray.push($rootScope.selectedScopeData[x].imgId);
		   	          			  //$rootScope.selectedid.push($rootScope.selectedScopeData[x].imgId);
		   	          		}
		   	          		  else{
		   	          			 // $rootScope.selectedid.push($rootScope.selectedScopeData[x].imgId);
		   	          			 $rootScope.scopevalueArray.push($rootScope.selectedScopeData[x].imgId);
		   	          			  }
		   	          	  }
		   	          	  }
	   	       		 
	            	}else{
	            		$rootScope.validClose = undefined;
	            	}
	            	
	            },
	           // controller:'createTemplatePage',
	            scope: $scope,
	            closeByDocument: false,
	            closeByEscape: false,
	            showClose: true,
	            height: 560,
	            width: 1146,
	            className:'ngdialog-theme-default CLASS_projHierarchy'
	            
	        });
	    	$mdDialog.cancel();
	    	 $rootScope.createimg = false;
	    };
	    
	    $scope.startImportForCopy = function(){
	    	$rootScope.isclientspecific = false;
	    	$rootScope.selectedScopeData = [];
	    	$rootScope.create={};
	    	$rootScope.create.templateType="";
	    	$rootScope.overlay_admin = document.getElementById("overlay");
			$rootScope.popup_admin = document.getElementById("busy");
			$rootScope.overlay_admin.style.display = "block";
			$rootScope.popup_admin.style.display = "inline-block";
		if($rootScope.isclientimgexists){	
			 var imgPreviewInputDto = {
					  selectedOmid:$rootScope.selectedOmId,
	        		  sessionInputDTO: $rootScope.sessionInputObj
	              };
		 $http.post("/" + servicePrefix + "/rest/clientImgHierarchySrv/previewClientImgHierarchyCopyFuctionality", imgPreviewInputDto).then(function(response) {
	 	       if(response.status === 200){
	 	       	
	 	       	if(response.data != null && response.data !== ""){
	 	       	 if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
	       	      		$rootScope.checkAuthorization();
	       	      	}
	 	       	else { 		var responsedata = [];
	 		    			$rootScope.scopevalueArrayid =[];
	 		    			responsedata.push(response.data);
	 		    			if(response.data.imgId != null){
	 		    			$rootScope.selectedid = response.data.imgId;
		 		    		$rootScope.scopevalueArrayid = response.data.imgId;	 
	 		    		 }
	 	       		}
	 	       	 }
	 	       }
	 	   });
}
	    	ngDialog.openConfirm({
	            template: 'view/createhierarchy/createCopyTreeView.html?ver='+version,
	            preCloseCallback:function(){
	            	$mdDialog.cancel();
	            	if($rootScope.validClose == undefined){
	            		//$rootScope.selectedScopeData = $rootScope.selectedTreeviewData;
	   	       		 
		   	       		$rootScope.scopevalueArray=[];
		   	       		//$rootScope.selectedid=[];
		   	       		 for(var x = 0; x < $rootScope.selectedScopeData.length; x++){
		   	          		  if($rootScope.selectedScopeData[x].enabled === 1){
		   	          		  if(x == 0)
		   	          		  { 	
		   	          			
		   	          			 $rootScope.scopevalueArray.push($rootScope.selectedScopeData[x].imgId);
		   	          			  //$rootScope.selectedid.push($rootScope.selectedScopeData[x].imgId);
		   	          		}
		   	          		  else{
		   	          			 // $rootScope.selectedid.push($rootScope.selectedScopeData[x].imgId);
		   	          			 $rootScope.scopevalueArray.push($rootScope.selectedScopeData[x].imgId);
		   	          			  }
		   	          	  }
		   	          	  }
	   	       		 
	            	}else{
	            		$rootScope.validClose = undefined;
	            	}
	            	
	            },
	           // controller:'createTemplatePage',
	            scope: $scope,
	            closeByDocument: false,
	            closeByEscape: false,
	            showClose: true,
	            height: 560,
	            width: 1146,
	            className:'ngdialog-theme-default CLASS_projHierarchy'
	            
	        });
	    	$mdDialog.cancel();
	    	 $rootScope.createimg = false;
	    };
	  
	      $scope.save = function(){
	    
	    	  $rootScope.trData = [];
	    	  $rootScope.validClose = true;
	    	  var selectedData = {
	        		  clientImgHierarchyList:$rootScope.scopevalueArrayid,
	        		  selectedArea:$rootScope.selectedArea.value,
	        		  omId:$rootScope.selectedOmId,
	        		  sessionInputDTO: $rootScope.sessionInputObj
	              };
	    	  
	    	
	    	  $http.post("/" + servicePrefix + "/rest/clientImgHierarchySrv/clientImgHierarchy",selectedData).then(function(response) {
	    		  if(response.status === 200 && response.data.resMessageDto.msgType == "true"){
	    			  $rootScope.stuff1 = [];
	    			  
	    			  var imgPreviewInputDto = {
	    					  selectedArea:$rootScope.selectedArea.value,
	    					  selectedOmid:$rootScope.selectedOmId,
	    	      		  sessionInputDTO: $rootScope.sessionInputObj
	    	            };
	    			  
	    			 /* $http({
	    			        method: "GET",
	    			        url: "/" + servicePrefix + "/rest/clientImgHierarchySrv/viewClientImgHierarchy/"+$rootScope.selectedOmId+"/"+$rootScope.username,
	    			        headers:{
	    			            'authorization' :  $rootScope.userValidation.userToken
	    			            }
	    					}*/$http.post("/" + servicePrefix + "/rest/clientImgHierarchySrv/viewClientImgHierarchy",imgPreviewInputDto).then(function(response) {
	  		  		    if(response.status === 200){
	  		  		    if(response.data.resMessageDto.message != null && response.data.resMessageDto.message !== ""){
	  		  		    	$rootScope.trData = [];
	  		    		  $rootScope.createimg = false;
	  		    		  $rootScope.isclientimgexists = true;
	  		    		  $rootScope.clientimghierarchy = false;
	  		    		  $rootScope.IMGHierarchyMsg = "MODIFY IMG HIERARCHY";
	  		    		  $rootScope.clienthierarchyok = true;
	  		    		  var responsedata=[];
	  		    		  responsedata.push(JSON.parse(response.data.resMessageDto.message));
	  		    		  $rootScope.stuff1.push(JSON.parse(response.data.resMessageDto.message));
	  		  		      
	  		  		    	  }
	  		  		    }
	  		    	  });
	    			
	    			 }else  if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
	        	      		$rootScope.checkAuthorization();
	        	      	} 
	    		  else {
	  		    		  $rootScope.IMGHierarchyMsg =  "CREATE IMG HIERARCHY";
	  		    		  $rootScope.isclientimgexists = false;

		 		    }
		 		});
	    	
		  		ngDialog.close();
		  		ngDialog.openConfirm({
                   template: '<p>' +"IMG Hierarchy saved successfully for project"+" "+ $rootScope.selectedProjId + '</p>',
                   plain: true,
                   scope: $scope,
                   closeByDocument: true,
                   closeByEscape: true,
                   showClose: true,
                   height:120,
                   width: 350,
                   className:'ngdialog-theme-default CLASS_2'
               }); 
		  		
		  	};
		  	
		      $scope.copySave = function(){
		  	    
		    	  $rootScope.trData = [];
		    	  $rootScope.validClose = true;
		    	  var selectedData = {
		        		  clientImgHierarchyList:$rootScope.scopevalueArrayid,
		        		  omId:$rootScope.selectedOmId,
		        		  sessionInputDTO: $rootScope.sessionInputObj
		              };
		    	  
		    	
		    	  $http.post("/" + servicePrefix + "/rest/clientImgHierarchySrv/clientImgHierarchy",selectedData).then(function(response) {
		    		  if(response.status === 200 && response.data.resMessageDto.msgType == "true"){
		    			  $rootScope.stuff2 = [];
		    			  
		    			  var imgPreviewInputDto = {
		    					  selectedOmid:$rootScope.selectedOmId,
		    	      		  sessionInputDTO: $rootScope.sessionInputObj
		    	            };
		    			  
		    			 /* $http({
		    			        method: "GET",
		    			        url: "/" + servicePrefix + "/rest/clientImgHierarchySrv/viewClientImgHierarchy/"+$rootScope.selectedOmId+"/"+$rootScope.username,
		    			        headers:{
		    			            'authorization' :  $rootScope.userValidation.userToken
		    			            }
		    					}*/$http.post("/" + servicePrefix + "/rest/clientImgHierarchySrv/viewClientBPHierarchyCopyFuntionality",imgPreviewInputDto).then(function(response) {
		  		  		    if(response.status === 200){
		  		  		    if(response.data.resMessageDto.message != null && response.data.resMessageDto.message !== ""){
		  		  		    	$rootScope.trData = [];
		  		    		  $rootScope.createimg = false;
		  		    		  $rootScope.isclientimgexists = true;
		  		    		  $rootScope.clientimghierarchy = false;
		  		    		  $rootScope.IMGHierarchyMsg = "MODIFY COPY IMG HIERARCHY";
		  		    		  $rootScope.clienthierarchyok = true;
		  		    		  var responsedata=[];
		  		    		  responsedata.push(JSON.parse(response.data.resMessageDto.message));
		  		    		  $rootScope.stuff2.push(JSON.parse(response.data.resMessageDto.message));
		  		  		      
		  		  		    	  }
		  		  		    }
		  		    	  });
		    			
		    			 }else  if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
		        	      		$rootScope.checkAuthorization();
		        	      	} 
		    		  else {
		  		    		  $rootScope.IMGHierarchyMsg =  "CREATE COPY IMG HIERARCHY";
		  		    		  $rootScope.isclientimgexists = false;

			 		    }
			 		});
		    	
			  		ngDialog.close();
			  		ngDialog.openConfirm({
	                   template: '<p>' +"IMG Hierarchy saved successfully for project"+" "+ $rootScope.selectedProjId + '</p>',
	                   plain: true,
	                   scope: $scope,
	                   closeByDocument: true,
	                   closeByEscape: true,
	                   showClose: true,
	                   height:120,
	                   width: 350,
	                   className:'ngdialog-theme-default CLASS_2'
	               }); 
			  		
			  	};
			  	
		  	$scope.onCancel=function(){
		  	
		  		ngDialog.close();
		  		
		  	};
		  	$scope.$on('changeChildren', function(event, parentItem) {
	            var child, i, len, ref, results;
	            ref = parentItem.children;
	            results = [];
	            for (i = 0, len = ref.length; i < len; i++) {
	              child = ref[i];
	              if(child.enabled== "1"){
	              child.selected = parentItem.selected;
	              }
	              if (child.children != null) {
	                results.push($scope.$broadcast('changeChildren', child));
	              } else {
	                results.push(void 0);
	              }
	            }
	            return results;
	          });
		  	
		  	 $scope.selectedMethod = function(item,selectedValue){
		            var bData = {};
		            if(item.imgId.length > 0){
		                   bData.id = item.id;
		                   bData.imgId = item.imgId;
		                   bData.imgDescription = item.imgDescription.split("_")[1];
		                   bData.sequence = item.sequence;
		                   bData.enabled = item.enabled;
		                   bData.fileName = "";
		                   bData.filepath = "";
		                   bData.isMasterData = item.isMasterData;
		                   bData.logs = [];
		                   bData.status = "status-pending";
		                   if(selectedValue === true){


		                          index = -1;
		                          for(var a= 0,arrLen = $rootScope.selectedScopeData.length;a< arrLen ;a++){
		                               if($rootScope.selectedScopeData[a].imgId == bData.imgId){
		                                      index = a;
		                                      break;
		                               }
		                          }
		                          
		                          if (index == -1) {
		                                if(bData.enabled=="1"){
		                                $rootScope.selectedScopeData.push(bData);
		                                
		                                }

		                              }
		                          
		                   }
		                  
		                   else if(selectedValue === false){

		                          index = -1;
		                          for(var a= 0,arrLen = $rootScope.selectedScopeData.length;a< arrLen ;a++){
		                               if($rootScope.selectedScopeData[a].imgId == bData.imgId){
		                                      index = a;
		                                      break;
		                               }
		                          }
		                          

		                          if (index > -1) {
		                                $rootScope.selectedScopeData.splice(index, 1);
		                      
		                              }
		                   }
		            }else {
		                   for(var x = 0,arrLen = item.children.length;x < arrLen ; x++){
		                   $scope.selectedMethod(item.children[x],selectedValue);
		                   }
		            }
		            
		            
		         };
		         $scope.initCheckbox = function(item, parentItem) {
		             
		               item.selected=$scope.validatecheck(item);
		               
		               if(item.selected)
		            {
		             var allChecks = true;
		             for (var i in parentItem.children) 
		             {
		                          if (!parentItem.children[i].selected) {
		                                        allChecks = false;
		                                        break;
		                                 }
		             }
		                          if (allChecks) {
		                                                             parentItem.selected = true;
		                                                      }
		                                 else {
		                                                      parentItem.selected = false;
		                                        }

		            }
		               return item.selected;
		             
		            };
		            $scope.validatecheck=function(item)
		            {
		               
		               var selectedValue=true;
		               var aIndex = $rootScope.scopevalueArray.indexOf(item.imgId);
		               if(aIndex>-1)
		                      { 
		                      
		                      var bData = {};
		                      if(item.imgId.length > 0){
		                             
		                             bData.imgId = item.imgId;
		                             bData.imgDescription = item.imgDescription;
		                             bData.sequence = item.sequence;
		                             bData.enabled = item.enabled;
		                             bData.fileName = "";
		                             bData.filepath = "";
		                             bData.isMasterData = item.isMasterData;
		                             bData.logs = [];
		                             bData.status = "status-pending";
		                             if(selectedValue === true){


		                                    index = -1;
		                                    for(var a= 0,arrLen = $rootScope.selectedScopeData.length;a< arrLen ;a++){
		                                         if($rootScope.selectedScopeData[a].imgId == bData.imgId){
		                                                index = a;
		                                                break;
		                                         }
		                                    }
		                                    
		                                    if (index == -1) {
		                                          if(bData.enabled=="1"){
		                                          $rootScope.selectedScopeData.push(bData);
		                                          }

		                                        }
		                                    
		                             }
		                            
		                             else if(selectedValue === false){

		                                    
		                                    index = -1;
		                                    for(var a= 0,arrLen = $rootScope.selectedScopeData.length;a< arrLen ;a++){
		                                         if($rootScope.selectedScopeData[a].imgId == bData.imgId){
		                                                index = a;
		                                                break;
		                                         }
		                                    }
		                                    

		                                    if (index > -1) {
		                                          $rootScope.selectedScopeData.splice(index, 1);
		                                        }
		                             }
		                      }else {
		                             for(var x = 0,arrLen = item.children.length;x < arrLen ; x++){
		                             $scope.selectedMethod(item.children[x],selectedValue);
		                             }
		                      }
		                      
		                      return true
		                      }
		               else
		               return false;
		               
		            };

		            $scope.saveTRDetails = function(checkbox_status,accesstype){
		       		
		       		var count = 0;
		           	var customTRcount = 0;
		           	var workbenchTRcount = 0;
		           	var TRcount = 0;
		           	var customTotal = 0;
		           	var workbenchTotal = 0;
		           	var arrLen = 0;
//		       		$rootScope.accesstype = accesstype;
		       		if($rootScope.selectedOmId != ""){
		          		
		       						arrLen = $rootScope.trData.length;
		          			    	for(var i=0; i < arrLen ; i++){
		          			    		         	if($rootScope.trData[i].trType == "W")		    	
		          			    		         		customTRcount++;
		          			    		         	else if($rootScope.trData[i].trType == "K")
		          			    		         		workbenchTRcount++;
		          			    		         	else if($rootScope.trData[i].trType == "WK"){
		          			    		         		customTRcount++;
		          			    		         		workbenchTRcount++;
		          			    		         	}
//		          			    		         		TRcount++;
		          			    		         	if($rootScope.trData[i].customizingTr != null && $rootScope.trData[i].customizingTr != "")
		          			    		         		customTotal++;
		          			    		         	if($rootScope.trData[i].workbenchTr != null && $rootScope.trData[i].workbenchTr != "" )
		          			    		         		workbenchTotal++;
		          			    		         	
//		          			    		   $rootScope.trData.imgId =$rootScope.tempTrData[i].imgId;
//		          			    		   $rootScope.trData.customizingTr =  $rootScope.tempTrData[i].customizingTr;
//		          			    		   $rootScope.trData.workbenchTr =  $rootScope.tempTrData[i].workbenchTr;
//		          			    		   $rootScope.trData.trUpdated =  $rootScope.tempTrData[i].trUpdated;
//		          			    		   $rootScope.trData.sno = $rootScope.tempTrData[i].sno;

		            	
		          			    	}
		          			    	
		          			    	if(checkbox_status == undefined || checkbox_status == false){
		          			    		
		          			    		if(workbenchTRcount != workbenchTotal || customTRcount != customTotal){
		          			    			
		          			    			   $rootScope.trOverrideEnable = true;
		          			    			 
		          			    		 ngDialog.openConfirm({
    				 		                    template: 'view/createhierarchy/trOverride.html?ver='+version,
    				 		                
    				 		                    scope: $scope,
    				 		                    closeByDocument: true,
    				 		                    closeByEscape: true,
    				 		                    showClose: true,
    				 		                    height: 143,
    				 		                    width: 665,
    				 		                    className:'ngdialog-theme-default CLASS_2'
    				 		                });
		          			    		}
		          			    		else{
		          			    			
		          			    			$rootScope.trOverrideEn = true;
		          			    			
		          			    			 ngDialog.openConfirm({
	    				 		                    template: 'view/createhierarchy/trOverride2.html?ver='+version,
	    				 		                    scope: $scope,
	    				 		                    closeByDocument: true,
	    				 		                    closeByEscape: true,
	    				 		                    showClose: true,
	    				 		                    height: 143,
	    				 		                    width: 665,
	    				 		                    className:'ngdialog-theme-default CLASS_2'
	    				 		                });
		          			    		}
		          			    	}else if(workbenchTRcount != workbenchTotal || customTRcount != customTotal){
		          			    		 ngDialog.openConfirm({
			       	 		                    template: 'view/createhierarchy/checkTRCount.html?ver='+version,
			       	 		                
			       	 		                    scope: $scope,
			       	 		                    closeByDocument: false,
			       	 		                    closeByEscape: false,
			       	 		                    showClose: true,
			       	 		                    height: 143,
			       	 		                    width: 665,
			       	 		                    className:'ngdialog-theme-default CLASS_2'
			       	 		                });	
		          			    	}else{
		          			    		$scope.saverdata();
		          			    	}
		          			}
		            };	 
		       		/*$scope.saveTRoverrideData = function(){
		       			
		       			var params = {
		           				omid : $rootScope.selectedOmId,
		           				trOverrideFLag : $rootScope.trObject.tempselectedProjTROveride
		           		}
		       			ngDialog.close();
		       			 var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
		       		        $mdDialog.show({
		       		            controller: function($scope, $mdDialog){
		       		            $scope.isLoading = true;
		       		            },
		       		            templateUrl: 'view/busy.html?ver='+version,
		       		            parent: angular.element(document.body),
		       		            clickOutsideToClose: false,
		       		            fullscreen: useFullScreen,
		       		            escapeToClose: false,
		       		        })
		       		        .then(function(answer) {
		       		        }, function() {
		       		        });
		           	$http.post("/" + servicePrefix + "/rest/updateProject/updateProjectTR",params).then(function(response) {
		           		 if(response.data != null && response.status == 200){
		           			 	$mdDialog.cancel();
		           				$scope.saverdata();
		           				
		           		
		           			 console.log("TR Overide data is saved");
		           		 }else{
		           			 $mdDialog.cancel();
		           			 $scope.saverdata();
		           		 }
		           	});
		       		
		       		};*/
		            
		       		$scope.cancelTRoverrideData = function(){
		       			ngDialog.close();
		       		    	 $mdDialog.cancel();
		       		};
		       		
		       		 $scope.saverdata = function(){
		   	    	//  $rootScope.validClose = true;

		       				ngDialog.close();
		       				var arrLen = 0;
		       				arrLen = $rootScope.allOmId.length;
		       			 for(var i=0;i<arrLen;i++){
		       				 

//		       					if($rootScope.selectedOmId != null && $rootScope.selectedOmId.indexOf($rootScope.allOmId[i].omId) == 0)
		       				 		if($rootScope.selectedOmId != null && $rootScope.selectedOmId == $rootScope.allOmId[i].omId) //Engie issue Fix - Feb 09
		       						{
		       						
		       						/*$rootScope.selectedProjTROveride = $rootScope.allOmId[i].trOverride == null?"":$rootScope.allOmId[i].trOverride;*/
		       					if($rootScope.allOmId[i].trOverride != $rootScope.trObject.tempselectedProjTROveride)
		       						 {
		       						    $rootScope.allOmId[i].trOverride = $rootScope.trObject.tempselectedProjTROveride;//Engie issue Fix - Feb 09 	
		       							break;
		       						 }
		       						}
		       				}
		       		
			       			 var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
			       			 var overlay = document.getElementById("overlay");
			       		     var popup = document.getElementById("busy");
			       		     overlay.style.display = "block";
			       		        busy.style.display = "inline-block";

		                	var params={
		               				updateTrValues : $rootScope.trData,
		               				omid : $rootScope.selectedOmId,
		               				trOverrideFLag : $rootScope.trObject.tempselectedProjTROveride,
		               				selectedSystemId : $rootScope.selectedSystemid,
		               				sessionInputDTO: $rootScope.sessionInputObj

		                			}
		                	 $http.post("/" + servicePrefix + "/rest/manageTR/updateManageTrTable",params).then(function(response) {
		             		    if(response.data != null && response.status === 200){
		             		    	 angular.copy($rootScope.trData,$rootScope.tempTrData);
		             		    	 var overlay = document.getElementById("overlay");
		             			     var popup = document.getElementById("busy");
		             			     overlay.style.display = "none";
		             			        busy.style.display = "none";

		             		    	ngDialog.openConfirm({
		       		                    template: '<p style="margin-top:1%">'+" TR Data is saved Successfully "+'</p>',
		       		                    plain: true,
		       		                    scope: $scope,
		       		                    closeByDocument: false,
		       		                    closeByEscape: false,
		       		                    showClose: true,
		       		                    height: 90,
		       		                    width: 355,
		       		                    className:'ngdialog-theme-default CLASS_2'
		       		                });
		             		    	}else{
		             		    		 var overlay = document.getElementById("overlay");
			             			     var popup = document.getElementById("busy");
			             			     overlay.style.display = "none";
			             			        busy.style.display = "none";

		             		    		/*$mdDialog.cancel();*/
		             		    	}
		                	 	});
		       		 };          	
 $scope.okTROveride = function (){
	    	 var params = {
     				omid : $rootScope.selectedOmId,
     				trOverrideFLag : $rootScope.trObject.tempselectedProjTROveride,
     				sessionInputDTO : $rootScope.sessionInputObj 
     		}
     		
     	$http.post("/" + servicePrefix + "/rest/updateProject/updateProjectTR",params).then(function(response) {
     		 if(response.status === 200 && response.data != null){
     			$scope.saverdata();
     			 ngDialog.close();
     			 /*ngDialog.openConfirm({
		                    template: '<p style="margin-top:1%">' +"TR Data is saved Successfully"+'</p>',
		                    plain: true,
		                    scope: $scope,
		                    closeByDocument: true,
		                    closeByEscape: true,
		                    showClose: true,
		                    height: 120,
		                    width: 315,
		                    className:'ngdialog-theme-default CLASS_2'
		                });*/ 
     		 		}
     			});
	     }
	     $scope.cancelTROveride = function (){
	    	 ngDialog.close();
	     }
	     $scope.cancelTRDetails = function(){
	    	 ngDialog.openConfirm({
                  template: 'view/createhierarchy/cancelTREdit.html?ver='+version,
                  
                  scope: $scope,
                  closeByDocument: true,
                  closeByEscape: true,
                  showClose: true,
                  height: 150,
                  width: 610,
                  className:'ngdialog-theme-default CLASS_2'
              });
	     }
	     $scope.cancelTREdit = function(){
	    	 
	    	 ngDialog.close();
	    	 
	     }
	     $scope.okTREdit = function(){
	    	 if($rootScope.selectedProjTROveride != $rootScope.trObject.tempselectedProjTROveride)
	    		 $rootScope.trObject.tempselectedProjTROveride = $rootScope.selectedProjTROveride;
	    	 
	    	 $rootScope.trObject.checkbox_status = $rootScope.tempcheckbox_status;
	    	// angular.copy($rootScope.selectedProjTROveride,$rootScope.trObject.tempselectedProjTROveride);
	    	 angular.copy($rootScope.tempTrData,$rootScope.trData);
	    	 ngDialog.close();
	    	/* $http.get("/" + servicePrefix + "/rest/manageTR/displayManageTrTable/"+$rootScope.selectedOmId).then(function(response) {
				 //$mdDialog.cancel();
				 //console.log($rootScope.OmId);
				    if(response.status === 200 && response.data != null){
				    	
				    	$rootScope.trData = response.data;	
				    
				    	for(var i=0;i<response.data.length;i++){
				    	$rootScope.trData[i].ctrStatus="Edit";
				    	$rootScope.trData[i].ktrStatus="Edit";
				    	$rootScope.trData[i].trtype1="trtype";
				    	$rootScope.trData[i].trtype2="trtype";
				    	
				    	}
				    	//console.log($rootScope.trData);
				     }
			 });*/
	    	 
	     }
	    $scope.blurFunction = function(customizingTr,imgDesc,idx){
	    	
	    	if(customizingTr == null || customizingTr.length == 0 ){
	    		$rootScope.trData[idx].trUpdated = true;

	    	}
	    	else if (customizingTr != null && customizingTr.length == 10){
	    		if($scope.systemIdTrVal != null && customizingTr.slice(0,3).toUpperCase() == $scope.systemIdTrVal.toUpperCase() &&  (customizingTr.slice(3,4) == "K" || customizingTr.slice(3,4) == "k") && customizingTr.slice(4,10).match(/^[a-zA-Z0-9]+$/) ){
		    		$rootScope.trData[idx].trUpdated = true;

	    		}
	    		else{
	    			$rootScope.trData[idx].customizingTr = null;
	    		ngDialog.openConfirm({
                    template: '<p style="margin-top:3%">' +"Please enter TR Number in correct format for "+ imgDesc+'</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:100,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                });
	    		}
	    	
	    	}
	    	else if(customizingTr!= null && customizingTr.length != 10){
    			$rootScope.trData[idx].customizingTr = null;

	    		ngDialog.openConfirm({
                    template: '<p style="margin-top:3%">' +"TR number should be 10 characters in length for "+imgDesc+'</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:100,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                });
	    	}
	    	else{
	    		$rootScope.trData[idx].trUpdated = true;
	    		
	    	}
	    }
   $scope.blurFunction2 = function(workbenchTr,imgDesc,idx){
	    	
	    	if( workbenchTr == null  || workbenchTr.length == 0 ){
	    		$rootScope.trData[idx].trUpdated = true;

	    	}
	    	else if (workbenchTr != null && workbenchTr.length == 10){
	    		if($scope.systemIdTrVal != null && workbenchTr.slice(0,3) == $scope.systemIdTrVal && (workbenchTr.slice(3,4) == "K" || workbenchTr.slice(3,4) == "k") && workbenchTr.slice(4,10).match(/^[a-zA-Z0-9]+$/)){
	    		    
		    		$rootScope.trData[idx].trUpdated = true;

	    		}
	    		else{
	    			$rootScope.trData[idx].workbenchTr = null;
	    		ngDialog.openConfirm({
                    template: '<p style="margin-top:3%">' +"Please enter TR Number in correct format for "+ imgDesc+'</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:100,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                });
	    		}
	    	
	    	}
	    	else if(workbenchTr != null && workbenchTr.length != 10){
	    		$rootScope.trData[idx].workbenchTr = null;
	    		ngDialog.openConfirm({
                    template: '<p style="margin-top:3%">' +"TR number should be 10 characters in length for "+imgDesc+'</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:100,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                });
	    	}
	    	else{
	    		$rootScope.trData[idx].trUpdated = true;
	    		
	    	}
	    }
	   /*  saveAll(){
	    	 
	    	 for(var i=0; i<response.data.length;i++){)
	     }*/
}]) ;



