    var app = angular.module('yapp');
     
    app.factory('tree', tree);
    function tree($rootScope) {
 
        var self =this;
     
        var makeNode = function (label, hasFakechild) {
            var node;
            if(label.sequence == 0)
            { 
            	node ={
            	imgDescription: label.imgDescription,
                id: label.id,
                type: label.Type,
                imgId:label.imgId,
                parentNode:label.parentNode,
                children: label.children
            };
            }
            else{
                node ={
                		
                		//0:object,
                		id: label.id,
                		imgId: label.imgId,
                		enabled:label.enabled,
                		type: label.Type,
                		children: [],
                		imgDescription: label.sequence+"_"+label.imgDescription
                };
            }
           return node;
        };

        var makeChild = function (node) {
            return {
                label: label.sequence+"_"+label.imgDescription,
                id: label.id,
                type: label.Type,
                children: label.children
            };
        };
      
        self.genNode =  function (list, parent, hasFakechild) {

            var node = [],
                key='',
                nodeChild = [],
                i=0,
                temp = [],
                nodes = [];
          while (list !== null && list.length) {
                 
                node = makeNode(list.shift(), hasFakechild);
                
                node.selected = parent === null ? node.selected : parent.selected;
              
                if (parent !== null) {                    
                    if (parent.children[0].type == 'DEL') {//Remove the dummy node
                        parent.children.splice(0); 
                    }
                    parent.children.push(node);
                } else {
                    nodes.push(node);
                	}
                i++;
            } 
  
           if (parent !== null) {
                return parent;
            } else {
                return nodes;
            }
        } 
        
    return self;
}
    
  
  