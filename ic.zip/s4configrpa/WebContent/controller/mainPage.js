 angular.module('yapp').controller('mainPage',["ngDialog","Upload","$scope","$rootScope","$http","$mdDialog","$mdMedia","$location","$filter","$state", "$timeout","Idle","$ocLazyLoad",function(ngDialog,Upload,$scope,$rootScope,$http,$mdDialog,$mdMedia,$location,$filter,$state, $timeout,Idle,$ocLazyLoad) {
	 $ocLazyLoad.load(controllerName+'/mainPage.js?ver='+version);
	 
	 $scope.manageUser = "Manage User";
	 if($rootScope.appValidity == undefined){
			
		 $rootScope.username = "";
		    $rootScope.password = "";
		 
		    $location.path('/loginPage');
	}
	
	Idle.watch();
	//Idle Time out Logic - End
	 /********8 Logout ********/
   /* $scope.logout = function(){
        $state.transitionTo('loginPage');
        $rootScope.username = "";
        $rootScope.password = "";
        $rootScope.adminAuth  = "";

        $rootScope.fileUploadAuth = "";
        $rootScope.executeAuth = "";
        $rootScope.configAuth = "";
        $rootScope.fileDownloadAuth = "";
    }*/
	$scope.isSubMenu = false;

$scope.openNav = function() {
	document.getElementById("hambrgrCloseMenu").style.display = "inline-block";
	document.getElementById("mySidenav").style.display = "inline-block";
    document.getElementById("mySidenav").style.width = "230px";
    document.getElementById("hambrgrMenu").style.display = "none";
}

$scope.closeNav = function(){
	document.getElementById("hambrgrCloseMenu").style.display = "none";
	document.getElementById("hambrgrMenu").style.display = "inline-block";
    document.getElementById("mySidenav").style.display = "none";
}
$scope.openRightNav = function() {
	document.getElementById("upArrow").style.display = "inline-block";
	document.getElementById("adminSidenav").style.display = "inline-block";
    document.getElementById("adminSidenav").style.width = "230px";
    document.getElementById("downArrow").style.display = "none";
}

$scope.closeRightNav = function() {
	document.getElementById("upArrow").style.display = "none";
	document.getElementById("downArrow").style.display = "inline-block";
    document.getElementById("adminSidenav").style.display = "none";
};
$scope.showSubMenu = function(){
	
	document.getElementById("showSubMenu").style.display = "inline-block";
}

	  $scope.changeAdminPassword = function(){
	  		if(document.getElementById("upArrow") !=  null){
	  		document.getElementById("upArrow").style.display = "none";
	  		document.getElementById("downArrow").style.display = "inline-block";
	  	    document.getElementById("adminSidenav").style.display = "none";
	  		}
	  		ngDialog.openConfirm({
		            template: 'view/managePassword/changePassword.html?ver='+version,
		            scope: $scope,
		            closeByDocument: false,
		            closeByEscape: false,
		            showClose: false,
		            height: 400,
		            width: 560,
		           className:'ngdialog-theme-default CLASS_projName'
		        });  		
	  	};
	if( $rootScope.userValidation != undefined && $rootScope.userValidation.default_p == 'Y'){
		 $scope.changeAdminPassword();
	}
	else if($rootScope.secQAUpdated == false &&  $rootScope.isLoginAgain == true) {
		 $rootScope.isLoginAgain = false;
		ngDialog.openConfirm({
	        template: 'view/managePassword/setUpSecurityQA.html?ver='+version,
	     // controller : 'LoginPageController',
	        scope: $scope,
	        closeByDocument: false,
	        closeByEscape: false,
	        showClose: true,
	        height: 445,
	        width: 500,
	       className:'ngdialog-theme-default CLASS_projName'
	    	});
	    }
    $scope.skipSecQA = function()
	{
	 ngDialog.close();
	}
	$scope.saveSecQuestions = function(){
		var listOfQuestions = [$rootScope.securityQA.question1,$rootScope.securityQA.question2];
		var listOfAnswers = [sha256($rootScope.securityQA.answer1),sha256($rootScope.securityQA.answer2)];
	    var comparray = [];
   for(i=0;i<listOfAnswers.length;i++){
	   var obj ={};
           obj.questionId = listOfQuestions[i];
           obj.ans = listOfAnswers[i];
           
       comparray.push(obj);
   }
		var input = {
				ansListDto : comparray,
				userId: $rootScope.username,
				sessionInputDTO :  $rootScope.sessionInputObj
		}
		if($rootScope.securityQA.question1 != $rootScope.securityQA.question2){
		$http.post("/" + servicePrefix + "/rest/adminSrv/updateSecurityAnswers",input).then(function(response){
	       if(response.data.msgType == "Success")
	  		{
	    	 ngDialog.close();
	    	 $scope.showAlert1 = {   "color" : "red", "display":"none"};	    	
	    	$rootScope.secQAUpdated = true;
	    	
	    	 ngDialog.openConfirm({
            template: '<p>' + "Your Details are saved succeessfully" +'</p>',
            plain: true,
            scope: $scope,
            closeByDocument: true,
            closeByEscape: true,
            showClose: true,
            height:120,
            width: 350,
            className:'ngdialog-theme-default CLASS_2'
        });
	    	}
	       else {
	    	 ngDialog.close();
	    	 ngDialog.openConfirm({
             template: '<p>' + "Something went wrong. Please try again with correct details" +'</p>',
             plain: true,
             scope: $scope,
             closeByDocument: true,
             closeByEscape: true,
             showClose: true,
             height:120,
             width: 350,
             className:'ngdialog-theme-default CLASS_2'
         });
	       }
			});
	}
		else {
			$scope.showAlert1 = {   "color" : "red", "display":"inline-block"};
			//$('#messageAlertDuplicate').html('Please select some different question').css('color', 'red');
		}
	};

 	$scope.newPassword =  function(){
  		//$scope.validateRole($rootScope.securityQA.newpassword);
  	/*	service call to store the new password*/
  		if( $rootScope.securityQA.oldpassword == $rootScope.password){
  			if($rootScope.securityQA.oldpassword != $rootScope.securityQA.newpassword){
  			$scope.showAlert = {"display":"none"};
  			var params = {
           		userId : $rootScope.username,
           		oldPassword : $rootScope.securityQA.oldpassword,
           		newPassword : $rootScope.securityQA.newpassword,
           		sessionInputDTO : $rootScope.sessionInputObj
           }
  		$http.post("/" + servicePrefix + "/rest/adminSrv/updatePassword",params).then(function(response){
        if(response.data.msgType == "Success")
  		{
        	ngDialog.close();       
        	$rootScope.userValidation.default_p = 'N';
        	if($rootScope.secQAUpdated == false) {
        		ngDialog.openConfirm({
        	        template: 'view/managePassword/setUpSecurityQA.html?ver='+version,
        	     
        	        scope: $scope,
        	        closeByDocument: false,
        	        closeByEscape: false,
        	        showClose: true,
        	        height: 445,
        	        width: 500,
        	       className:'ngdialog-theme-default CLASS_projName'
        	    	});
        	}
        	else{
        		ngDialog.openConfirm({
                    template: '<p>' + "Your new Password is saved successfully" +'</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                })
        	}
        }else if(response.data.message == "Invalid input received"){
          	ngDialog.openConfirm({
                template: '<p>' + "Invalid input received" +'</p>',
                plain: true,
                scope: $scope,
                closeByDocument: true,
                closeByEscape: true,
                showClose: true,
                height:120,
                width: 350,
                className:'ngdialog-theme-default CLASS_2'
            })
        }
        else {
        	ngDialog.openConfirm({
                template: '<p>' + "Something went wrong." +'</p>',
                plain: true,
                scope: $scope,
                closeByDocument: true,
                closeByEscape: true,
                showClose: true,
                height:120,
                width: 350,
                className:'ngdialog-theme-default CLASS_2'
            })
        }
  		});
  			}else{
  				$scope.showAlertforNewPwd = {   "color" : "red", "display":"inline-block"};
  			}
  		}
  		else{
  			$scope.showAlert = {   "color" : "red", "display":"inline-block"};
  		
  		}
  	};
  	$scope.setOnlySecurityQuestions = function (){
  		ngDialog.openConfirm({
            template: 'view/managePassword/setUpSecurityQA.html?ver='+version,
         // controller : 'LoginPageController',
            scope: $scope,
            closeByDocument: false,
            closeByEscape: false,
            showClose: true,
            height: 445,
            width: 500,
           className:'ngdialog-theme-default CLASS_projName'
        	});
  	};
    function make_base_auth(user, password) {
		  var tok = user + ':' + password;
		  var hash = btoa(tok);
		  return "Basic " + hash;
		};
		$scope.showSubMenu = function (){
			$scope.isSubMenu = true;
		};
		$scope.showActiveProjects = function(){
			 
			var inputParam = {		      		
		      		sessionInputDTO: $rootScope.sessionInputObj
		          };
		  $http.post("/" + servicePrefix + "/rest/userSrv/displayActiveUsers",inputParam).then(function(response) {
		        if(response.status === 200){
		        	 if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
		            	  $rootScope.checkAuthorization();
		              }else{
		            	  $rootScope.activeProjectData = response.data.userList;
		              }
		        }
		  });
		  //$location.path("/report/ActiveUserReport");
		};
 }]);
	