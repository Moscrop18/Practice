var app = angular.module('yapp').controller('importHelpDoc',["ngDialog","$filter","Upload","$scope","$rootScope","$http","$mdDialog","$mdMedia", "$location", "$timeout","$window","$ocLazyLoad",function(ngDialog,$filter,Upload,$scope,$rootScope,$http,$mdDialog,$mdMedia, $location, $timeout, $window,$ocLazyLoad) {	
	$ocLazyLoad.load(controllerName+'/helpDoc/importHelpDoc.js?ver='+version);
	var noAuth = "false";
	$scope.upload = {};
	/*var cookie = document.cookie;
		var cookieAuthParams = cookie.split(';');
		for (var cp1 = 0,arrLen = cookieAuthParams.length; cp1 < arrLen ; cp1++) {*/
			/*if (cookieAuthParams[cp1].split('=')[0].trim() == "adminAuth" || cookieAuthParams[cp1].split('=')[0].trim() == "configAuth" && cookieAuthParams[cp1].split('=')[1].trim() == "true") {
				noAuth = "true"
			}*/
			if ($rootScope.adminAuth == "true" || $rootScope.configAuth == "true") {
				noAuth = "true"
			}
			/*if($rootScope.appValidityupdateManageTrTable == undefined){
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userDetails") {
					$rootScope.userValidation = cookieAuthParams[cp1].split('=')[1];
					console.log($rootScope.userValidation.role);
					
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userRole") {
					$rootScope.userRole = cookieAuthParams[cp1].split('=')[1];
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "roleId") {
					$rootScope.roleId = cookieAuthParams[cp1].split('=')[1];
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userName") {
					$rootScope.username = cookieAuthParams[cp1].split('=')[1];
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userFirstName") {
					 $rootScope.userFirstName = cookieAuthParams[cp1].split('=')[1];
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userLastName") {
					$rootScope.userLastName = cookieAuthParams[cp1].split('=')[1];
				}
		  }
		}*/
	if (noAuth == "false") {
			$location.path('/loginPage');
		}

	// Code to hide the Hamburger Menu 
	
	if($rootScope.userRole == "TAdmin" || $rootScope.userRole == "PAdmin"){
		document.getElementById("mySidenav").style.width = "0px";
		if(document.getElementById("showSubMenu") != null)
			document.getElementById("showSubMenu").style.display = "none";
		document.getElementById("hambrgrCloseMenu").style.display = "none";
		document.getElementById("hambrgrMenu").style.display = "inline-block";
	}
	 
	 $rootScope.helpPage = "true";
	 $rootScope.userRoles = {
	   		 "value": "All Users", 
	   	     "values": ['Project & Tool Admin','All Users','Tool Admin'] 
	       };
	 
$scope.init = function () {
	 $rootScope.uploadButtondisabled = true;
    $rootScope.overlay_helpDoc = document.getElementById("overlay");
    $rootScope.popup_helpDoc = document.getElementById("busy");
    $rootScope.overlay_helpDoc.style.display = "block";
    $rootScope.popup_helpDoc.style.display = "inline-block";
    var params={
            userId: $rootScope.username,
            role: $rootScope.userRole
          
        };
    $http({
        method: "POST",
        url: "/" + servicePrefix + "/rest/helpDocumentsSrv/retrieveHelpDocuments",
        data : params
    }).then(function mySucces(response) {
 
        if (response.data.responseList !=null) {
        	if(response.data.message != null && response.data.message == serviceMessage){
    	      		$rootScope.checkAuthorization();
    	      	}
    		else{
            $rootScope.overlay_helpDoc.style.display = "none";
            $rootScope.popup_helpDoc.style.display = "none";
        	$rootScope.helpDocArr = response.data.responseList;
            var arrLength =  $rootScope.helpDocArr.length;
        	for(var i =0; i<arrLength; i++){
        		var fileName;
        		   var a = $rootScope.helpDocArr[i].fileName.lastIndexOf('.');
						if (a > 0) {
						     fileName = $rootScope.helpDocArr[i].fileName.substring(a+1);
						}
						if(fileName == "pdf"){
  	           		 $rootScope.helpDocArr[i].fileType = "pdf";	
  	       			 }
  	       			 else if(fileName == "mp4"){
  	           		 $rootScope.helpDocArr[i].fileType = "mp4";	
  	       			 }
        	}}
        	
        }else{
        	$rootScope.overlay_helpDoc.style.display = "none";
        	$rootScope.popup_helpDoc.style.display = "none";
        	}
 	   
 	   
    }, function myError(response) {
    	$rootScope.overlay_helpDoc.style.display = "none";
    	$rootScope.popup_helpDoc.style.display = "none";
        //            $scope.userValidation = response.statusText;
    }); 
};


$scope.importDocument = function(){
//	console.log(val);
	ngDialog.openConfirm({
        template: 'view/helpDoc/importDocument.html?ver='+version,
        controller:'importHelpDoc',
        scope: $scope,
        closeByDocument: false,
        closeByEscape: false,
        showClose: true,
        height: 200,
        width: 800
    });

	//$rootScope.selectedFileRow = val;
	
};



//Call service and upload files in Server 
$rootScope.uploadHelpDocument = function(file){
	console.log(document.getElementById("File2"));
	file = document.getElementById("File2").files;
	var role = '';
	if($scope.userRoles.value == 'All Users'){
		role = 'Config';
	}
	else if($scope.userRoles.value == 'Tool Admin'){
		role = 'TAdmin';
	}
	else{
		role = 'PAdmin';
	}
   var uploadUrl = "/" + servicePrefix + "/rest/helpDocumentsSrv/uploadHelpDocuments/"+role;
   /*var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
   var overlay = document.getElementById("overlay");
   var popup = document.getElementById("busy");
   overlay.style.display = "block";
   busy.style.display = "inline-block";*/
   $rootScope.overlay_helpDoc = document.getElementById("overlay");
   $rootScope.popup_helpDoc = document.getElementById("busy");
   $rootScope.overlay_helpDoc.style.display = "block";
   $rootScope.popup_helpDoc.style.display = "inline-block";
       file.upload = Upload.upload({
           method: 'POST',
           url:         uploadUrl,
           data:      {files: file[0]}
       });
	
       
       file.upload.then(function(responseData) {
    	   $rootScope.overlay_helpDoc.style.display = "none";
    	   $rootScope.popup_helpDoc.style.display = "none";
    	   ngDialog.close();
    	   ngDialog.openConfirm({
               template: '<p> '+ responseData.data.message + ' </p>',
               plain: true,
               scope: $scope,
               closeByDocument: true,
               closeByEscape: true,
               showClose: true,
               height:120,
               width: 350,
               className:'ngdialog-theme-default CLASS_2'
           });
    	   
    	   var params={
    	              userId: $rootScope.username,
    	              role: $rootScope.userRole
    	            
    	          };
    	   
    	   $rootScope.overlay_helpDoc = document.getElementById("overlay");
    	    $rootScope.popup_helpDoc = document.getElementById("busy");
    	    $rootScope.overlay_helpDoc.style.display = "block";
    	    $rootScope.popup_helpDoc.style.display = "inline-block";
    	   $http({
    	        method: "POST",
    	        url: "/" + servicePrefix + "/rest/helpDocumentsSrv/retrieveHelpDocuments",
    	        data : params
    	    }).then(function mySucces(response) {
    	    	
    	        if (response.data.responseList !=null) {
    	        	if(response.data.message != null && response.data.message == serviceMessage){
  	      	      		$rootScope.checkAuthorization();
  	      	      	}
            		else{
    	            $rootScope.overlay_helpDoc.style.display = "none";
    	            $rootScope.popup_helpDoc.style.display = "none";
    	        	$rootScope.helpDocArr = response.data.responseList;
    	            var arrLength =  $rootScope.helpDocArr.length;
    	            var fileName;
    	        	for(var i =0; i<arrLength; i++){
    	        		   var a = $rootScope.helpDocArr[i].fileName.lastIndexOf('.');
   						if (a > 0) {
   						     fileName = $rootScope.helpDocArr[i].fileName.substring(a+1);
   						}
   						if(fileName == "pdf"){
       	           		 $rootScope.helpDocArr[i].fileType = "pdf";	
       	       			 }
       	       			 else if(fileName == "mp4"){
       	           		 $rootScope.helpDocArr[i].fileType = "mp4";	
       	       			 }
    	        	}
    	        	$rootScope.overlay_helpDoc.style.display = "none";
    	     	   $rootScope.popup_helpDoc.style.display = "none";
            		}
    	        }else{
    	        	$rootScope.overlay_helpDoc.style.display = "none";
    	        	$rootScope.popup_helpDoc.style.display = "none";
    	        	}
    	 	   
    	 	   
    	    }, function myError(response) {
    	    	$rootScope.overlay_helpDoc.style.display = "none";
    	    	$rootScope.popup_helpDoc.style.display = "none";
    	        //            $scope.userValidation = response.statusText;
    	    }); 
    	   
       }, function (data) {
    	   $rootScope.overlay_helpDoc.style.display = "none";
    	   $rootScope.popup_helpDoc.style.display = "none";
    	   ngDialog.openConfirm({
               template: '<p> Exception occured, please contact Administrator </p>',
               plain: true,
               scope: $scope,
               closeByDocument: true,
               closeByEscape: true,
               showClose: true,
               height:120,
               width: 350,
               className:'ngdialog-theme-default CLASS_2'
           });
       });

};

$rootScope.getPdf = function(fileName,docId){
	 $rootScope.overlay_helpDoc = document.getElementById("overlay");
     $rootScope.popup_helpDoc = document.getElementById("busy");
     $rootScope.overlay_helpDoc.style.display = "block";
     $rootScope.popup_helpDoc.style.display = "inline-block";
	 var input = {
			 
			 id : docId
	 }
	 $http({
	        method: "POST",
	        url: "/" + servicePrefix + "/rest/helpDocumentsSrv/retriveDocumentBytes",
	        data : input
	    }).then(function mySucces(response) {
	    	 if (response.data.status == "Success") {
	    		 var bytes = response.data.docBytes;
	    		 var sampleArr = base64ToArrayBuffer(bytes);
	    		 saveByteArrayPdf(fileName, sampleArr);
	    	 }if(response.data.message != null && response.data.message == serviceMessage){
     	      		$rootScope.checkAuthorization();
     	      	}     		
	    }, function myError(response) {
	    	$rootScope.overlay_helpDoc.style.display = "none";
	    	$rootScope.popup_helpDoc.style.display = "none";
    //            $scope.userValidation = response.statusText;
	    });  
		 
		  
		  
	  };
	  
	  $rootScope.getVideo = function(fileName,docId){
		  	$rootScope.overlay_helpDoc = document.getElementById("overlay");
		     $rootScope.popup_helpDoc = document.getElementById("busy");
		     $rootScope.overlay_helpDoc.style.display = "block";
		     $rootScope.popup_helpDoc.style.display = "inline-block";
			 var input = {
					 
					 id : docId
			 }
			 $http({
			        method: "POST",
			        url: "/" + servicePrefix + "/rest/helpDocumentsSrv/retriveDocumentBytes",
			        data : input
			    }).then(function mySucces(response) {
			    	 if (response.data.status == "Success") {
			    		 var bytes = response.data.docBytes;
			    		 var sampleArr = base64ToArrayBuffer(bytes);
			    		 saveByteArrayVideo(fileName, sampleArr);
			    	 }if(response.data.message != null && response.data.message == serviceMessage){
	  	      	      		$rootScope.checkAuthorization();
	  	      	      	}
	            		
			    }, function myError(response) {
			    	$rootScope.overlay_helpDoc.style.display = "none";
			    	$rootScope.popup_helpDoc.style.display = "none";
		    //            $scope.userValidation = response.statusText;
			    });  
				
				  
				  
			  };
	  
	  function base64ToArrayBuffer(base64) {
		    var binaryString = window.atob(base64);
		    var binaryLen = binaryString.length;
		    var bytes = new Uint8Array(binaryLen);
		    for (var i = 0; i < binaryLen; i++) {
		       var ascii = binaryString.charCodeAt(i);
		       bytes[i] = ascii;
		    }
		    return bytes;
		 };
		 
	  
	  
		 function saveByteArrayPdf(reportName, byte) {
			    var blob = new Blob([byte],{type: 'application/pdf'}); //video/mp4
			    var link = document.createElement('a');
			    link.href = window.URL.createObjectURL(blob);
			   // var fileName = reportName + ".pdf";
			    link.download = reportName;
			    link.click();
			    $rootScope.overlay_helpDoc.style.display = "none";
		    	$rootScope.popup_helpDoc.style.display = "none";
			};
			
			 function saveByteArrayVideo(reportName, byte) {
				    var blob = new Blob([byte],{type: 'video/mp4'}); //video/mp4
				    var link = document.createElement('a');
				    link.href = window.URL.createObjectURL(blob);
				    //var fileName = reportName + ".";
				    link.download = reportName;
				    link.click();
				    $rootScope.overlay_helpDoc.style.display = "none";
			    	$rootScope.popup_helpDoc.style.display = "none";
				};
			
				 $rootScope.deleteHelpDoc = function(docId){
					 $scope.input = {							 
							 id : docId
					 		}					 
							ngDialog.openConfirm({
				                //template: '<p> Are you Sure, want to proceed with delete. </p>',
				                template: 'view/helpDoc/confirmDelete.html?ver='+version,
				                scope: $scope,
				                closeByDocument: true,
				                closeByEscape: true,
				                showClose: true,
				                height:200,
				                width: 488,
				                className:'ngdialog-theme-default CLASS_2'
				            });
					  
						  };	
						  $rootScope.okDelete = function(){
							  ngDialog.close();
								 $http({
								        method: "POST",
								        url: "/" + servicePrefix + "/rest/helpDocumentsSrv/deleteHelpDocument",
								        data : $scope.input
								    }).then(function mySucces(response) {
								 
								        if (response.data.status !=null) {
								        	if(response.data.message == serviceMessage){
						  	      	      		$rootScope.checkAuthorization();
						  	      	      	}
						            		else
								        	ngDialog.openConfirm({
								                template: '<p> Document succesfully deleted </p>',
								                plain: true,
								                scope: $scope,
								                closeByDocument: true,
								                closeByEscape: true,
								                showClose: true,
								                height:120,
								                width: 350,
								                className:'ngdialog-theme-default CLASS_2'
								            });
								        }
								 	   
								        $rootScope.overlay_helpDoc = document.getElementById("overlay");
								        $rootScope.popup_helpDoc = document.getElementById("busy");
								        $rootScope.overlay_helpDoc.style.display = "block";
								        $rootScope.popup_helpDoc.style.display = "inline-block";
								        var params={
							    	              userId: $rootScope.username,
							    	              role: $rootScope.userRole
							    	            
							    	          };
								        $http({
								            method: "POST",
								            url: "/" + servicePrefix + "/rest/helpDocumentsSrv/retrieveHelpDocuments",
								            data : params
								        }).then(function mySucces(response) {
								     
								            if (response.data.responseList !=null) {
								            	if(response.data.message != null && response.data.message == serviceMessage){
							  	      	      		$rootScope.checkAuthorization();
							  	      	      	}
							            		else{
								                $rootScope.overlay_helpDoc.style.display = "none";
								                $rootScope.popup_helpDoc.style.display = "none";
								            	$rootScope.helpDocArr = response.data.responseList;
								                var arrLength =  $rootScope.helpDocArr.length;
								            	for(var i =0; i<arrLength; i++){
								            	
								                if($rootScope.helpDocArr[i].fileName.split(".")[1] == "pdf"){
								               		 $rootScope.helpDocArr[i].fileType = "pdf";	
								           			 }
								           			 else if($rootScope.helpDocArr[i].fileName.split(".")[1] == "mp4"){
								               		 $rootScope.helpDocArr[i].fileType = "mp4";	
								           			 }
								            	}}
								            	//console.log($rootScope.helpDocArr);
								            }else{
								            	$rootScope.overlay_helpDoc.style.display = "none";
								            	$rootScope.popup_helpDoc.style.display = "none";
								            	}
								     	   
								     	   
								        }, function myError(response) {
								        	$rootScope.overlay_helpDoc.style.display = "none";
								        	$rootScope.popup_helpDoc.style.display = "none";
								            //            $scope.userValidation = response.statusText;
								        }); 
								 	   
								    }, function myError(response) {
								        //            $scope.userValidation = response.statusText;
								    });
						};
				$rootScope.cancelDelete = function(){
					ngDialog.close();					
				};
}]) ;