angular.module('yapp').controller('configReports',["ngDialog","Upload","$scope","$rootScope","$http","$mdDialog","$mdMedia","$location","$filter","$state","Idle","$timeout","$ocLazyLoad",function(ngDialog,Upload,$scope,$rootScope,$http,$mdDialog,$mdMedia,$location,$filter,$state,Idle,$timeout,$ocLazyLoad) {
	//$ocLazyLoad.load(controllerName+'/config/trgSysSelection.js?ver='+version);
	//Browser Refresh - 13 Nov 2017
	if($rootScope.appValidity == undefined){
		   $rootScope.username = "";
		    $rootScope.password = "";
		   /* var cookies = document.cookie.split(";");
		    for (var i = 0,arrLen = cookies.length; i < arrLen ; i++) {
		        var cookie = cookies[i];
		        var eqPos = cookie.indexOf("=");
		        var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
		        document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
		    }*/
		    $location.path('/loginPage');
	    
	}   
	var myDate = new Date();
	myDate.setHours(myDate.getHours() + 1);
	
	var noAuth = "false";
	var homeAuth="false";
	var resetAuth="false"
	$rootScope.helpPage = "true";	
	/*var cookie = document.cookie;
	var cookieAuthParams = cookie.split(';');
	for (var cp1 = 0; cp1 < cookieAuthParams.length; cp1++) {*/
	/*	if (cookieAuthParams[cp1].split('=')[0].trim() == "configAuth" && cookieAuthParams[cp1].split('=')[1].trim() == "true") {
			noAuth = "true"
		}*/
		if ($rootScope.configAuth == "true") {
			noAuth = "true"
		}
		if ($rootScope.configInitial == "true") {
			homeAuth = "true";
		}
/*		if (cookieAuthParams[cp1].split('=')[0].trim() == "configInitial" && cookieAuthParams[cp1].split('=')[1].trim() == "true") {
//			document.cookie = "configInitial=" + resetAuth + ";expires=" + myDate.toUTCString();
			 homeAuth = "true";
		}*/
	/*}*/
	//console.log(document.getElementById("#executionsummaryHead"));
	if($rootScope.appValidity != undefined){
		if (noAuth == "false") {
			$location.path('/loginPage');
		}else if(homeAuth=="false"){
			$location.path('/configTilesPage');
		}
	}
$scope.barLimit1 = 10;
$scope.increaseLimit1 = function() {
      $scope.barLimit1 += 20;
    
    };
/*$scope.logout = function(){
	ngDialog.close();
		$rootScope.initalCheck = undefined;
        $state.transitionTo('loginPage');
        $rootScope.username = "";
        $rootScope.password = "";
        //$scope.deleteAllCookies();
        $rootScope.adminAuth  = "";

        $rootScope.fileUploadAuth = "";
        $rootScope.executeAuth = "";
        $rootScope.configAuth = "";
        $rootScope.fileDownloadAuth = "";
        $rootScope.showLogsExportData = false;
    };*/
    
/* Data Initialization  */
    if(document.getElementById("form-container") != null)
    	document.getElementById("form-container").style.display="none";  
    $rootScope.collapseInnerTable = false;
    $rootScope.expandInnerTable = true;
    $rootScope.executionLogsSummary = [];
	$rootScope.dynamicRows = [20,30,40];
	$rootScope.dynamicRow ={};
	$rootScope.dynamicRow.selectedNumber = "";
	$rootScope.imgDescr = "";
	$rootScope.executionSummaryExport = false;
	$rootScope.configDownloadData = [];
	$rootScope.systemData = [];
	$rootScope.downlodlogs = false;
	$rootScope.enableExport = true;
/*Closing the Hamburger Menu when Report page is opened*/
	/*document.getElementById("mySidenav").style.display = "none";
	document.getElementById("hambrgrReportCloseMenu").style.display = "none";
	document.getElementById("hambrgrReportOpenMenu").style.display = "inline-block";*/
	

/*	This method is used to display the Execution log on the scope level in the pop up. Below details are present 
	IMG Descr, CTR, KTR and Module.*/
$scope.viewExecutionReport = function(reportTransaction){
	  $rootScope.report_overlay = document.getElementById("overlay");
	   $rootScope.report_popup = document.getElementById("busy");
 	   
	   $rootScope.report_overlay.style.display = "inline-block";
	   $rootScope.report_popup.style.display = "inline-block";
	
	   var paramsData={}
	   paramsData.implType= reportTransaction.implType;
	   paramsData.sapUserID= reportTransaction.sapUserID;
	   paramsData.targetDestinationname= reportTransaction.targetDestinationname;
	   paramsData.count= reportTransaction.count;
	   paramsData.sourceDestinationname= reportTransaction.sourceDestinationname;
	   paramsData.transID= reportTransaction.transID;
	   paramsData.sessionInputDTO = $rootScope.sessionInputObj;
	   paramsData.industryFlag=$rootScope.industryFlag;
	   if($rootScope.industryFlag){
		   paramsData.industry=$rootScope.selectedIndustry;
		   paramsData.subIndustry=$rootScope.selectedsubIndustry;
		}
		
	
	 $rootScope.executionSummaryExport = true;
	 $rootScope.transID = reportTransaction.transID;
	 var configArrayLen = $rootScope.configTransactionData.length;
		$scope.exportDetailLogs = [];
		for(var i=0;i<configArrayLen;i++){
			if( $rootScope.transID == $rootScope.configTransactionData[i].transID)
			{
				$scope.exportDetailLogs.push($rootScope.configTransactionData[i]);
			}
		}
	$http.post("/" + servicePrefix + "/rest/configReportService/getConfigUploadTransaction",paramsData ).then(function(response) {
		
	        if (response.status === 200) {
	        	if(response.data != null){
	        		if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
	      	      		$rootScope.checkAuthorization();
	      	      	}else{
	        		   $rootScope.report_overlay.style.display = "none";
	        		   $rootScope.report_popup.style.display = "none";
	        		   $rootScope.executionSummary = response.data.configUploadTransList;
	        		
	        		$scope.executionDetailLogs = [];
	        		$scope.executionsAllLogSummary = [];
	        		$scope.executionsAllLogSummary = response.data.executionsAllLogSummary;
	        		$scope.bytesData = response.data.bytes;
	        		//console.log($scope.executionsAllLogSummary);
	        		var responseLength = $rootScope.executionSummary.length;
	        		for(var i=0;i<responseLength;i++){	
	        			
	        			if($rootScope.executionSummary[i].status == "S")
        				{
	        				$rootScope.executionSummary[i].iconType = "fa fa-check-circle";
        				}
        				else if($rootScope.executionSummary[i].status == "I")
        				{
        				$rootScope.executionSummary[i].iconType = "fa fa-info";
        				}
        				else if($rootScope.executionSummary[i].status == "E")
    					{
    					$rootScope.executionSummary[i].iconType = "fa fa-times-circle";
    					}
        				else if($rootScope.executionSummary[i].status == "W")
    					{
    					$rootScope.executionSummary[i].iconType = "fa fa-warning";
    					}
        			}
	        			ngDialog.openConfirm({
			    		        template: 'view/report/executionReport.html?ver='+version,
			    		        preCloseCallback:function(){
			    		
			    		        	if($rootScope.validClose == undefined){
			    		        		 $rootScope.logsEnablement = false;
			    		        	}
			    		        },        
			    		        scope: $scope,
			    		        closeByDocument: false,
			    		        closeByEscape: false,
			    		        showClose: true,
			    		        height: 565,
			    		        width: 1190
			    		    });
	        	}}
	        	else{
	        		   $rootScope.report_overlay.style.display = "none";
	        		   $rootScope.report_popup.style.display = "none";
		        	  ngDialog.openConfirm({
	                      template: '<p>' +"No Results Found"+ '</p>',
	                      plain: true,
	                      scope: $scope,
	                      closeByDocument: true,
	                      closeByEscape: true,
	                      showClose: true,
	                      height:120,
	                      width: 350
	                  });
	        	}
	        	}
	        else {
	        	  $rootScope.report_overlay.style.display = "none";
      		      $rootScope.report_popup.style.display = "none";
	        	  ngDialog.openConfirm({
                      template: '<p>' +"No Results Found"+ '</p>',
                      plain: true,
                      scope: $scope,
                      closeByDocument: true,
                      closeByEscape: true,
                      showClose: true,
                      height:120,
                      width: 350
                  });
	        }
		});
};
   
$scope.viewErrors =  function(iMGDesc){
   $rootScope.imgDescr = iMGDesc;
   $rootScope.executionSummaryExport = false;
   
   var arrayLength = $rootScope.executionSummary.length;
   for(var i=0;i<arrayLength;i++){
	   if($rootScope.executionSummary[i].iMGDesc == iMGDesc)
		   $rootScope.executionLogsSummary = $rootScope.executionSummary[i].executionsLogSummary;
   }
   var arrayLength1 = $rootScope.executionLogsSummary.length;
	for(var i=0;i<arrayLength1;i++)
		{
			if($rootScope.executionLogsSummary[i].icon == "S")
				$rootScope.executionLogsSummary[i].iconType = "fa fa-check-circle";
			else if($rootScope.executionLogsSummary[i].icon == "I")
				{
				$rootScope.executionLogsSummary[i].iconType = "fa fa-info";
				}
			else if($rootScope.executionLogsSummary[i].icon == "E")
			{
			$rootScope.executionLogsSummary[i].iconType = "fa fa-times-circle";
			}
			else if($rootScope.executionLogsSummary[i].icon == "W")
			{
			$rootScope.executionLogsSummary[i].iconType = "fa fa-warning";
			}
		}
   $rootScope.logsEnablement = true;
   document.getElementById("exportTableDiv").style.width = "68%";
  };
$scope.logDisable =  function(){
	
	 $rootScope.logsEnablement = false;
	 document.getElementById("exportTableDiv").style.width = "100%";
};

$scope.exportAction = function (option) {
		var d = new Date();
				
		var fileName = "ConfigLogsExport"+d.getDate()+""+d.getMonth()+""+d.getYear()+""+d.getTime();
	
		alasql('SELECT imgDesc as IMGDesc, icon as Status, message as MessageType INTO XLSX("'+ fileName +'.xlsx",{headers:true}) FROM ?',[$rootScope.executionLogsSummary]);
};

$scope.exportToExcel = function(tableId){
var d = new Date();
	
var fileName = "ConfigLogsExport"+d.getDate()+""+d.getMonth()+""+d.getYear()+""+d.getTime();// ex: '#my-table'
Excel.tableToExcel(tableId,fileName);

};
$scope.exportData = function () {
    var blob = new Blob([document.getElementById('exportDataInExcel').innerHTML], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8"
    });
    window.navigator.msSaveOrOpenBlob(blob,'fileName'+'.xls');
   // FileSaver.saveAs(blob, "Leads "+new Date()+".xls");
  };
  var mystyle = {
	      headers:true, 
	      column: {style:{Font:{Bold:"1"}}},
	      rows: {1:{style:{Font:{Color:"#FF0077"}}}},
	      cells: {1:{1:{
	        style: {Font:{Color:"#00FFFF"}}
	      }}}
	    };

  $scope.exportCSV = function(){
	  	var fileBytes = base64ToArrayBuffer($scope.bytesData);
		saveByteArray([fileBytes], "ConfigLogsReport.xlsx");
};
  
  function base64ToArrayBuffer(base64) {
      var binaryString = window.atob(base64);
      var binaryLen = binaryString.length;
      var bytes = new Uint8Array(binaryLen);
      for (var i = 0; i < binaryLen; i++) {
          var ascii = binaryString.charCodeAt(i);
          bytes[i] = ascii;
      }
      return bytes;
  }
  
  
  var saveByteArray = (function () {
	    var a = document.createElement("a");
	    document.body.appendChild(a);
	    a.style = "display: none";
	    return function (data, name) {
	        var blob = new Blob(data, {type: "octet/stream"}),
	            url = window.URL.createObjectURL(blob);
	        	if (navigator.appVersion.toString().indexOf('.NET') > 0) { // for IE browser
	           window.navigator.msSaveBlob(blob, name);
	        	} else { // for other browsers
	        		a.href = url;
	        		a.download = name;
	        		a.click();
	        		window.URL.revokeObjectURL(url);    
	        	}
	       };
	}());
 

/*  $scope.timelogData = function (){
  	$http.post("https://systemp109966trial.hanatrial.ondemand.com/public/ictool/odata/Configuration.xsodata/Configurations",{
  	    username: "p109966",
  	    password: "Srinidhi16$"
  	}, {
  	    withCredentials: true}).then(function(response) {
      
          		console.log(response);
          	
  	});
  }*/
  /*Report 3 - Config TR Report*/	
  $scope.trConfigSystemData = function(){
	  $rootScope.systemData = [];
	  $rootScope.configTRData = [];
  if( $rootScope.systemData == null &&  $rootScope.systemData.length == 0){
	  var inputParam ={
			  systemType: "target",
			  omID: $rootScope.projOmId,
			  sessionInputDTO: $rootScope.sessionInputObj
	  }
		/* $http({
            method: "GET",
            url: "/" + servicePrefix + "/rest/configSrv/getSourceTargetDetails/target/" + $rootScope.projOmId
        })*/
	  $http.post("/" + servicePrefix + "/rest/configSrv/getSourceTargetDetails", inputParam).then(function mySucces(response) {
            if (response.data.resMessageDto.message == "Success") {
         	               $rootScope.systemData = response.data.systemList;
            
            }
            else if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
  	      		$rootScope.checkAuthorization();
  	      	}});
	 }
  };
  $scope.trConfigReport = function(selectedSysname){
	  
	  if(selectedSysname != "" && selectedSysname != null){
	   $rootScope.enableExport = false;// Enabling the Export option after System selection
	   $rootScope.report_overlay = document.getElementById("overlay");
  	   $rootScope.report_popup = document.getElementById("busy");
  	   
  	   $rootScope.report_overlay.style.display = "inline-block";
  	   $rootScope.report_popup.style.display = "inline-block";
  	   var params ={
  			projectName : 	$rootScope.projectName,
  			destinationName : selectedSysname,
  			sessionInputDTO : $rootScope.sessionInputObj	

  				}
  	$http.post("/" + servicePrefix + "/rest/configTRReportService/getConfigTR",params).then(function(response) {
  		
          if (response.status === 200) {
          	if(response.data != null){
          		if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
      	      		$rootScope.checkAuthorization();
      	      	}else{
          		  $rootScope.report_overlay.style.display = "none";
          		   $rootScope.report_popup.style.display = "none";
          		   $rootScope.configTRData =  response.data;
          	}}
          	else {
          	     ngDialog.openConfirm({
	                    template: '<p>' +"No Records Found" + '</p>',
	                    plain: true,
	                    scope: $scope,
	                    closeByDocument: true,
	                    closeByEscape: true,
	                    showClose: true,
	                    height:120,
	                    width: 350,
	                    className:'ngdialog-theme-default CLASS_2'
	                });
          		}
          	}
  	});
}else{
		$rootScope.enableExport = true;
		$rootScope.configTRData =  [];
	}
  };
  
  /*Report 4 - Config Download Report*/	
  $scope.downloadReport = function(){
  	  $rootScope.report_overlay = document.getElementById("overlay");
  	   $rootScope.report_popup = document.getElementById("busy");
  	   
  	   $rootScope.report_overlay.style.display = "inline-block";
  	   $rootScope.report_popup.style.display = "inline-block";
  	   var params ={
  				omID : $rootScope.projOmId,
  				sessionInputDTO : $rootScope.sessionInputObj,
  				userID : $rootScope.username
  			
  				}
  	$http.post("/" + servicePrefix + "/rest/configReportService/getConfigDownloadTransaction",params).then(function(response) {
  		
          if (response.status === 200) {
          	if(response.data != null ){
          		  		$rootScope.report_overlay.style.display = "none";
          		  		$rootScope.report_popup.style.display = "none";
          		 //  if($rootScope.configDownloadData.indexOf(response.data.transid) == -1)
          			   $rootScope.configDownloadData =  response.data.listConfigDownloadResponseDTO;
          	}
          	else{
          		$rootScope.report_overlay.style.display = "none";
       		   $rootScope.report_popup.style.display = "none";
          	}
          	}
      	else{
      			$rootScope.report_overlay.style.display = "none";
      			$rootScope.report_popup.style.display = "none";
      	}
  	});
  };
  $scope.viewDownloadReport = function(transid){
	  $rootScope.downlodlogs = true;
	  $rootScope.report_overlay = document.getElementById("overlay");
 	   $rootScope.report_popup = document.getElementById("busy");
 	   
 	   $rootScope.report_overlay.style.display = "inline-block";
 	   $rootScope.report_popup.style.display = "inline-block";
 	   
 	   var params ={
 			  transID : transid, 
 			  sessionInputDTO : $rootScope.sessionInputObj	

 				}
 	$http.post("/" + servicePrefix + "/rest/configReportService/getConfigDownloadTransactionLogs",params).then(function(response) {
 		
         if (response.status === 200) {
         	if(response.data != null){
         		  $rootScope.report_overlay.style.display = "none";
         		   $rootScope.report_popup.style.display = "none";
         		  $rootScope.configDownloadLogsData =  response.data;
         		  var downloadArrayLen = response.data.length;
         		 for(var i=0;i<downloadArrayLen;i++){
	        		 if(response.data[i].status == "S"){
	        			 $rootScope.configDownloadLogsData[i].statusIcon = "fa fa-check-circle";
                    	}
                    	else if(response.data[i].status == "E"){
                    		$rootScope.configDownloadLogsData[i].statusIcon = "fa fa-times-circle";
                    	}
	        		 }
         		  ngDialog.openConfirm({
	    		        template: 'view/report/configDownldLogs.html?ver='+version,
	    		               
	    		        scope: $scope,
	    		        closeByDocument: false,
	    		        closeByEscape: false,
	    		        showClose: true,
	    		        height: 565,
	    		        width: 1190
	    		    });
         		  	
         	}
         	}
 	});
	  
  };
  //Exporting Report 4 -Config Download Report
  $scope.exportDownloadReport = function (option) {
		var d = new Date();
				
		var fileName = "ConfigDownloadLogsExport"+d.getDate()+"_"+d.getMonth()+"_"+d.getYear();
	
		alasql('SELECT imgDesc as IMGDesc, module as Module, status as Status, message as MessageType INTO XLSX("'+ fileName +'.xlsx",{headers:true}) FROM ?',[$rootScope.configDownloadLogsData]);
};
//Exporting Report 4 -Config Download Report
	$scope.exportTRLogs = function(){
		var d = new Date();
		
		var fileName = "ConfigTRLogsExport"+d.getDate()+"_"+d.getMonth()+"_"+d.getYear();
	
		alasql('SELECT imgDescr as IMGDesc, ctr as Customizing_TR, ktr as Workbench_TR, sapUserId as SAPUserId INTO XLSX("'+ fileName +'.xlsx",{headers:true}) FROM ?',[$rootScope.configTRData]);
	};

}]);
