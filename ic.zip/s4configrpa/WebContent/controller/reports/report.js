angular.module('yapp', ['chart.js']).controller('reportController', ["ngDialog","Upload","$scope","$rootScope","$http","$mdDialog","$mdMedia","$location","$filter","$state","Idle","$timeout","$ocLazyLoad",function(ngDialog,Upload,$scope,$rootScope,$http,$mdDialog,$mdMedia,$location,$filter,$state,Idle,$timeout,$ocLazyLoad) {
       //$ocLazyLoad.load(controllerName+'/reports/report.js?ver='+version);
       if($rootScope.appValidity == undefined){
              $rootScope.username = "";
                  $rootScope.password = "";
              /*    var cookies = document.cookie.split(";");
              
                  for (var i = 0,arrLen = cookies.length; i < arrLen; i++) {
                      var cookie = cookies[i];
                      var eqPos = cookie.indexOf("=");
                      var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
                      document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
                  }*/
                  $location.path('/loginPage');
       }    
       

     /*  cookie = document.cookie;
              var cookieAuthParams = cookie.split(';');
              for (var cp1 = 0,arrLen = cookieAuthParams.length; cp1 < arrLen; cp1++) {*/
                    /* if (cookieAuthParams[cp1].split('=')[0].trim() === "adminAuth" && cookieAuthParams[cp1].split('=')[1].trim() === "true") {
                           noAuth = "true"
                     }*/
                     if ($rootScope.adminAuth == "true") {
             			noAuth = "true"
             		}
                    /* if($rootScope.appValidity === undefined){
                           if (cookieAuthParams[cp1].split('=')[0].trim() === "userDetails") {
                                  $rootScope.userValidation = cookieAuthParams[cp1].split('=')[1];
                                  //console.log($rootScope.userValidation.role);
                           }
                           if (cookieAuthParams[cp1].split('=')[0].trim() === "userRole") {
                                  $rootScope.userRole = cookieAuthParams[cp1].split('=')[1];
                           }
                           if (cookieAuthParams[cp1].split('=')[0].trim() === "roleId") {
                                  $rootScope.roleId = cookieAuthParams[cp1].split('=')[1];
                           }
                           if (cookieAuthParams[cp1].split('=')[0].trim() === "userName") {
                                  $rootScope.username = cookieAuthParams[cp1].split('=')[1];
                           }
                           if (cookieAuthParams[cp1].split('=')[0].trim() === "userFirstName") {
                                  $rootScope.userFirstName = cookieAuthParams[cp1].split('=')[1];
                           }
                           if (cookieAuthParams[cp1].split('=')[0].trim() === "userLastName") {
                                  $rootScope.userLastName = cookieAuthParams[cp1].split('=')[1];
                           }
                }
              }*/
       if (noAuth === "false") {
                     $location.path('/loginPage');
       }
       /********8 Logout ********/
      /* $scope.logout = function(){
        ngDialog.close();
        $rootScope.initalCheck = undefined;
        $state.transitionTo('loginPage');
        $rootScope.username = "";
        $rootScope.password = "";
       // $scope.deleteAllCookies();
        $rootScope.adminAuth  = "";

        $rootScope.fileUploadAuth = "";
        $rootScope.executeAuth = "";
        $rootScope.configAuth = "";
        $rootScope.fileDownloadAuth = "";
        $rootScope.showLogsExportData = false;
        ngDialog.close(); 
 };*/
       $rootScope.isDataAvailable = false;
       $rootScope.effortSaveData = [];
       //Idle Time out Logic - Start    
       $scope.$on('IdleTimeout', function() {
       $location.path('/loginPage');
          $mdDialog.show(
                   $mdDialog.alert()
                   .parent(angular.element(document.body))
                   .clickOutsideToClose(true) 
                   .title('Automatic log off')
                   .textContent('successfully logged off')
                   .ariaLabel('Alert Dialog Demo')
                   .ok('Ok')
    );
    });
    $scope.$on('IdleStart', function(ev) {
       ngDialog.close();
       $location.path('/loginPage');
           $mdDialog.show(
                            $mdDialog.alert()
                            .parent(angular.element(document.body))
                            .clickOutsideToClose(true)
                            .title('Automatic log off')
                            .textContent('Session has expired. Please logon again')
                            .ariaLabel('Alert Dialog Demo')
                            .ok('Ok')
                            .targetEvent(ev)
            );
    });
       Idle.watch();
       var noAuth = "false";
       
    //Idle Time out Logic - End 
       document.getElementById("mySidenav").style.display = "none";
   		if(document.getElementById("showSubMenu") != null)
       document.getElementById("showSubMenu").style.display = "none";
       document.getElementById("hambrgrCloseMenu").style.display = "none";
       document.getElementById("hambrgrMenu").style.display = "inline-block";
       $rootScope.timeLogData = [];
       //var ctrl = this;
       /*For TreeMap chart*/
       $rootScope.projectDetails = [];
       $rootScope.avgRecord = [];
       $rootScope.avgTime = [];
       $rootScope.avgExecutions = [];
       $rootScope.IMGDescription = '';
       $rootScope.projectSpecificData = []; // Storing project specific data to display in graph
  
     //```````````````````````````````````````````````
 
       var inputParams = {
   				
   			 	userID:$rootScope.username,
   				sessionInputDTO : $rootScope.sessionInputObj	
   			}
      	$http.post("/" + servicePrefix + "/rest/selectCustomer/projectList",inputParams).then(function(response) {
        	 
             if (response.status === 200) {
             	if(response.data != null){
             		if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
         	      		$rootScope.checkAuthorization();
         	      	}else{
             		 
             		   $rootScope.porjectlistData =  response.data.projectList;
             	}
             	}
             }
        	});
       
       	var fromDate ="";
	        if(document.getElementById("fromDate") != null){
	       	   var newdate = document.getElementById("fromDate").placeholder;
	       	   fromDate = newdate.split("/").reverse().join("-"); 
	       	   var inputParams = {
	       				
	       				fromDate : fromDate,
	       				sessionInputDTO : $rootScope.sessionInputObj	
	       			}
	       		    $http.post("/" + servicePrefix + "/rest/userSrv/displayActiveUsers" ,inputParams).then(function(response) { 
	       		        //$http.get(odataUrl ).then(function(response) {
	       		               if(response.status === 200){
	       		                     if(response.data != null){  
	       		                     	if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
	       		               	      		$rootScope.checkAuthorization();
	       		               	      	}else{
	       		               	      		for(var i=0;i<response.data.userList.length;i++){
	       		                   	      		var newCreatedDate = response.data.userList[i].createdDate.split(" ")[0];
	       		                   	      		newCreatedDate = newCreatedDate.split("-").reverse().join("-");
	       		                   	      	
	       		                   	      		response.data.userList[i].createdDate = newCreatedDate;
	       		                   	      		}
	       		               	      		$rootScope.activeProjectData = response.data.userList;
	       		               	      	}
	       		                     }
	       		               }
	       		    });
	          	};
      

    // Displaying data in Tree Map chart as per selected IMG      

$scope.exportProjectReport = function(){
	var d = new Date();
	m=d.getMonth()+1;
	var fileName = "ActiveProjects"+d.getDate()+"_"+m+"_"+d.getYear();

	alasql('SELECT userId as UserID, firstName as FirstName, lastName as LastName, projectName as ProjectName, validto as UserValidity, createdDate as Last_Transaction INTO XLSX("'+ fileName +'.xlsx",{headers:true}) FROM ?',[$rootScope.activeProjectData]);
};

$scope.refreshData = function(){
	
	if(document.getElementById("fromDate").value != ""){
	var newdate = document.getElementById("fromDate").value;
	}
	else{
		var newdate = document.getElementById("fromDate").placeholder;
	}
	fromDate = newdate.split("/").reverse().join("-");
	var inputParams = {
			
		fromDate : fromDate,
		sessionInputDTO : $rootScope.sessionInputObj	
	}
    $http.post("/" + servicePrefix + "/rest/userSrv/displayActiveUsers" ,inputParams).then(function(response) { 
        //$http.get(odataUrl ).then(function(response) {
               if(response.status === 200){
                     if(response.data != null){  
                     	if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
               	      		$rootScope.checkAuthorization();
               	      	}else{
               	      		for(var i=0;i<response.data.userList.length;i++){
                   	      		var newCreatedDate = response.data.userList[i].createdDate.split(" ")[0];
                   	      		newCreatedDate = newCreatedDate.split("-").reverse().join("-");
                   	      		
                   	      		//response.data.userList[i].createdDate = d + "-" + m + "-" + y;
                   	      		response.data.userList[i].createdDate = newCreatedDate;
                   	      		}
               	      		$rootScope.activeProjectData = response.data.userList;
               	      	}
                     }
               }
    });
}
$scope.viewPadminDownloadReport = function(transid){
	  $rootScope.downlodlogs = true;
	  
 	   
 	   var params ={
 			  transID : transid, 
 			  sessionInputDTO : $rootScope.sessionInputObj	

 				}
 	$http.post("/" + servicePrefix + "/rest/configReportService/getConfigDownloadTransactionLogs",params).then(function(response) {
 		
         if (response.status === 200) {
         	if(response.data != null){
         		
         		  $rootScope.configDownloadLogsData =  response.data;
         		  var downloadArrayLen = response.data.length;
         		 for(var i=0;i<downloadArrayLen;i++){
	        		 if(response.data[i].status == "S"){
	        			 $rootScope.configDownloadLogsData[i].statusIcon = "fa fa-check-circle";
                    	}
                    	else if(response.data[i].status == "E"){
                    		$rootScope.configDownloadLogsData[i].statusIcon = "fa fa-times-circle";
                    	}
	        		 }
         		  ngDialog.openConfirm({
	    		        template: 'view/report/configDownldLogs.html?ver='+version,
	    		               
	    		        scope: $scope,
	    		        closeByDocument: false,
	    		        closeByEscape: false,
	    		        showClose: true,
	    		        height: 565,
	    		        width: 1190
	    		    });
         		  	
         	}
         	}
 	});
}
$scope.exportDownloadReport = function (option) {
	var d = new Date();
			
	var fileName = "ConfigDownloadLogsExport"+d.getDate()+"_"+d.getMonth()+"_"+d.getYear();

	alasql('SELECT imgDesc as IMGDesc, module as Module, status as Status, message as MessageType INTO XLSX("'+ fileName +'.xlsx",{headers:true}) FROM ?',[$rootScope.configDownloadLogsData]);
};

$scope.downloadReport = function(selectedOmid){
	  
    var params = {
				
   				omID:selectedOmid,
				sessionInputDTO : $rootScope.sessionInputObj	
			}
	$http.post("/" + servicePrefix + "/rest/selectCustomer/DownloadReport",params).then(function(response) {
	  
     if (response.status === 200) {
     	if(response.data != null){
     		if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
 	      		$rootScope.checkAuthorization();
 	      	}else{
     		  
     		   $rootScope.PadminTRData =  response.data.downloadReportList;
     	}
     	}
     }
	});
};
$scope.uploadReportPadmin = function(selectedOmid){
 $rootScope.configTransactionData = [];	  
 var params = {				
				omID:selectedOmid,
				sessionInputDTO : $rootScope.sessionInputObj
				}
	$http.post("/" + servicePrefix + "/rest/configReportService/getConfigTransaction",params).then(function(response) {
	  
  if (response.status === 200) {
  	if(response.data != null){
  		if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
	      		$rootScope.checkAuthorization();
	      	}else if(response.data.message != null && response.data.message == "No Results Found! "){
	      	  ngDialog.openConfirm({
                  template: '<p>' +"No records found!"+ '</p>',
                  plain: true,
                  scope: $scope,
                  closeByDocument: true,
                  closeByEscape: true,
                  showClose: true,
                  height:120,
                  width: 350,
                  className:'ngdialog-theme-default CLASS_2'
              });
	      	}
	      	else
	      	{
  		  
 	      		$rootScope.configTransactionData =  response.data;
	      	}
  	}
  }
	});
};
$scope.viewExecutionReport = function(reportTransaction){
	  $rootScope.report_overlay = document.getElementById("overlay");
	   $rootScope.report_popup = document.getElementById("busy");
	   
	   $rootScope.report_overlay.style.display = "inline-block";
	   $rootScope.report_popup.style.display = "inline-block";
	var paramsData={
			implType: reportTransaction.implType,
			sapUserID: reportTransaction.sapUserID,
			targetDestinationname: reportTransaction.targetDestinationname,
			count: reportTransaction.count,
			sourceDestinationname: reportTransaction.sourceDestinationname,
			transID: reportTransaction.transID,
			sessionInputDTO : $rootScope.sessionInputObj
          };
	
	 $rootScope.executionSummaryExport = true;
	 $rootScope.transID = reportTransaction.transID;
	 var configArrayLen = $rootScope.configTransactionData.length;
		$scope.exportDetailLogs = [];
		for(var i=0;i<configArrayLen;i++){
			if( $rootScope.transID == $rootScope.configTransactionData[i].transID)
			{
				$scope.exportDetailLogs.push($rootScope.configTransactionData[i]);
			}
		}
	$http.post("/" + servicePrefix + "/rest/configReportService/getConfigUploadTransaction",paramsData ).then(function(response) {
		
	        if (response.status === 200) {
	        	if(response.data != null){
	        		if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
	      	      		$rootScope.checkAuthorization();
	      	      	}else{
	        		   $rootScope.report_overlay.style.display = "none";
	        		   $rootScope.report_popup.style.display = "none";
	        		   $rootScope.executionSummary = response.data.configUploadTransList;
	        		
	        		$scope.executionDetailLogs = [];
	        		$scope.executionsAllLogSummary = [];
	        		$scope.executionsAllLogSummary = response.data.executionsAllLogSummary;
	        		$scope.bytesData = response.data.bytes;
	        		//console.log($scope.executionsAllLogSummary);
	        		var responseLength = $rootScope.executionSummary.length;
	        		for(var i=0;i<responseLength;i++){	
	        			
	        			if($rootScope.executionSummary[i].status == "S")
      				{
	        				$rootScope.executionSummary[i].iconType = "fa fa-check-circle";
      				}
      				else if($rootScope.executionSummary[i].status == "I")
      				{
      				$rootScope.executionSummary[i].iconType = "fa fa-info";
      				}
      				else if($rootScope.executionSummary[i].status == "E")
  					{
  					$rootScope.executionSummary[i].iconType = "fa fa-times-circle";
  					}
      				else if($rootScope.executionSummary[i].status == "W")
  					{
  					$rootScope.executionSummary[i].iconType = "fa fa-warning";
  					}
      			}
	        			ngDialog.openConfirm({
			    		        template: 'view/report/executionReport.html?ver='+version,
			    		        preCloseCallback:function(){
			    		
			    		        	if($rootScope.validClose == undefined){
			    		        		 $rootScope.logsEnablement = false;
			    		        	}
			    		        },        
			    		        scope: $scope,
			    		        closeByDocument: false,
			    		        closeByEscape: false,
			    		        showClose: true,
			    		        height: 565,
			    		        width: 1190
			    		    });
	        	}}
	        	else{
	        		   $rootScope.report_overlay.style.display = "none";
	        		   $rootScope.report_popup.style.display = "none";
		        	  ngDialog.openConfirm({
	                      template: '<p>' +"No Results Found"+ '</p>',
	                      plain: true,
	                      scope: $scope,
	                      closeByDocument: true,
	                      closeByEscape: true,
	                      showClose: true,
	                      height:120,
	                      width: 350
	                  });
	        	}
	        	}
	        else {
	        	  $rootScope.report_overlay.style.display = "none";
    		      $rootScope.report_popup.style.display = "none";
	        	  ngDialog.openConfirm({
                    template: '<p>' +"No Results Found"+ '</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350
                });
	        }
		});
};
 
$scope.viewErrors =  function(iMGDesc){
 $rootScope.imgDescr = iMGDesc;
 $rootScope.executionSummaryExport = false;
 
 var arrayLength = $rootScope.executionSummary.length;
 for(var i=0;i<arrayLength;i++){
	   if($rootScope.executionSummary[i].iMGDesc == iMGDesc)
		   $rootScope.executionLogsSummary = $rootScope.executionSummary[i].executionsLogSummary;
 }
 var arrayLength1 = $rootScope.executionLogsSummary.length;
	for(var i=0;i<arrayLength1;i++)
		{
			if($rootScope.executionLogsSummary[i].icon == "S")
				$rootScope.executionLogsSummary[i].iconType = "fa fa-check-circle";
			else if($rootScope.executionLogsSummary[i].icon == "I")
				{
				$rootScope.executionLogsSummary[i].iconType = "fa fa-info";
				}
			else if($rootScope.executionLogsSummary[i].icon == "E")
			{
			$rootScope.executionLogsSummary[i].iconType = "fa fa-times-circle";
			}
			else if($rootScope.executionLogsSummary[i].icon == "W")
			{
			$rootScope.executionLogsSummary[i].iconType = "fa fa-warning";
			}
		}
 $rootScope.logsEnablement = true;
 document.getElementById("exportTableDiv").style.width = "68%";
};
$scope.logDisable =  function(){
	
	 $rootScope.logsEnablement = false;
	 document.getElementById("exportTableDiv").style.width = "100%";
};

$scope.exportAction = function (option) {
		var d = new Date();
				
		var fileName = "ConfigLogsExport"+d.getDate()+""+d.getMonth()+""+d.getYear()+""+d.getTime();
	
		alasql('SELECT imgDesc as IMGDesc, icon as Status, message as MessageType INTO XLSX("'+ fileName +'.xlsx",{headers:true}) FROM ?',[$rootScope.executionLogsSummary]);
};
$scope.exportCSV = function(){
  	var fileBytes = base64ToArrayBuffer($scope.bytesData);
	saveByteArray([fileBytes], "ConfigLogsReport.xlsx");
};

function base64ToArrayBuffer(base64) {
  var binaryString = window.atob(base64);
  var binaryLen = binaryString.length;
  var bytes = new Uint8Array(binaryLen);
  for (var i = 0; i < binaryLen; i++) {
      var ascii = binaryString.charCodeAt(i);
      bytes[i] = ascii;
  }
  return bytes;
};

var saveByteArray = (function () {
    var a = document.createElement("a");
    document.body.appendChild(a);
    a.style = "display: none";
    return function (data, name) {
        var blob = new Blob(data, {type: "octet/stream"}),
            url = window.URL.createObjectURL(blob);
        	if (navigator.appVersion.toString().indexOf('.NET') > 0) { // for IE browser
           window.navigator.msSaveBlob(blob, name);
        	} else { // for other browsers
        		a.href = url;
        		a.download = name;
        		a.click();
        		window.URL.revokeObjectURL(url);    
        	}
       };
}());

var params ={
		 userID: $rootScope.username,
         userRole: $rootScope.userRole,
		sessionInputDTO : $rootScope.sessionInputObj
}
$http.post("/" + servicePrefix + "/rest/clientImgHierarchySrv/getCustomerId",params).then(function(response) {
    
	 if(response.status === 200){
   	  if(response.data != null){
   		  	  $rootScope.allOmId = []; 
   		  	  //$rootScope.OmId = [];
   		  	  
   		  	  $rootScope.allOmId = response.data.projDetails;
	    	  }else{
   		  	 $rootScope.allOmId = []; 
   		  	 //$rootScope.OmId = [];
   	  }
   }
}); 
$scope.getProjectData =  function(selectedOmId){
	
	var params ={
			omID :selectedOmId,
			sessionInputDTO : $rootScope.sessionInputObj
	}
	$http.post("/" + servicePrefix + "/rest/customerSrv/getEffortSavingData",params).then(function(response) {
	    
		 if(response.status === 200){
	   	  if(response.data != null){
	   		  	 // $rootScope.allOmId = []; 
	   		  	  //$rootScope.OmId = [];
	   		  	  if(response.data.configExecutionLogList.length > 0)
	   		  	  {
	   		  		  $rootScope.isDataAvailable = true;
	   		  		  $rootScope.effortSaveData = response.data.configExecutionLogList;
	   		  		  $rootScope.allProjectData = response.data.effortSaveDataAllProj;
	   		  		  $rootScope.build_Time = response.data.build_Time;
	   		  		  
	   		  		  var sum = 0;
	   		  		  for( var el in $rootScope.effortSaveData ) {
	   		  			  if( $rootScope.effortSaveData.hasOwnProperty( el ) ) {
	   		  				  sum += parseFloat($rootScope.effortSaveData[el].totalTime);
	   		  			  }
	   		  		  }
	   		  		  $rootScope.grandTotal = sum;
	   		  		  //for(var i=0;i< $rootScope.effortSaveData.length;i++){
	   		  			//$rootScope.effortSaveData[i].totalTime = $rootScope.effortSaveData[i].totalTime + $rootScope.effortSaveData[i-1].totalTime; 
	   		  		  //}
	   		  		  
	   		  		  $rootScope.effortSaved = ((($rootScope.build_Time - sum)/$rootScope.build_Time) * 100).toPrecision(2);
	   		  	  
/*
	   		  		var visualization = d3plus.viz()
	   		  		.container("#viz")
	   		  		.data($rootScope.allProjectData)
	   		  		.type("bar")
	   		  		.id("projectName")
	   		  		.x("projectName")
	   		  		.y("totalTime")
	   		  		
	   		  		.draw()*/
	   		  	  }else{
	   		  		$rootScope.isDataAvailable = false;
	   		  		  $rootScope.effortSaveData = [];
         		  ngDialog.openConfirm({
	    		        template: '<p>' + "No records found" + '</p>',
	    		        scope: $scope, 
	    		        plain:true,
	    		        closeByDocument: false,
	    		        closeByEscape: false,
	    		        showClose: true,
	    		        height: 85,
	    		        width: 250
	    		    }); 
	   		  	  }
		    }
	   }
	}); 
};

}]);

