angular.module('yapp', ['chart.js']).controller('timeLogreportController', ["ngDialog","Upload","$scope","$rootScope","$http","$mdDialog","$mdMedia","$location","$filter","$state","Idle","$timeout","$ocLazyLoad",function(ngDialog,Upload,$scope,$rootScope,$http,$mdDialog,$mdMedia,$location,$filter,$state,Idle,$timeout,$ocLazyLoad) {
       //$ocLazyLoad.load(controllerName+'/reports/report.js?ver='+version);
       if($rootScope.appValidity == undefined){
              $rootScope.username = "";
                  $rootScope.password = "";
          
                  $location.path('/loginPage');
       }    
         if ($rootScope.adminAuth == "true") {
             			noAuth = "true"
             		}
           
       if (noAuth === "false") {
                     $location.path('/loginPage');
       }
   
       //Idle Time out Logic - Start    
       $scope.$on('IdleTimeout', function() {
       $location.path('/loginPage');
          $mdDialog.show(
                   $mdDialog.alert()
                   .parent(angular.element(document.body))
                   .clickOutsideToClose(true) 
                   .title('Automatic log off')
                   .textContent('successfully logged off')
                   .ariaLabel('Alert Dialog Demo')
                   .ok('Ok')
    );
    });
    $scope.$on('IdleStart', function(ev) {
       ngDialog.close();
       $location.path('/loginPage');
           $mdDialog.show(
                            $mdDialog.alert()
                            .parent(angular.element(document.body))
                            .clickOutsideToClose(true)
                            .title('Automatic log off')
                            .textContent('Session has expired. Please logon again')
                            .ariaLabel('Alert Dialog Demo')
                            .ok('Ok')
                            .targetEvent(ev)
            );
    });
       Idle.watch();
       var noAuth = "false";
       
    //Idle Time out Logic - End 
       document.getElementById("mySidenav").style.display = "none";
   		if(document.getElementById("showSubMenu") != null)
       document.getElementById("showSubMenu").style.display = "none";
       document.getElementById("hambrgrCloseMenu").style.display = "none";
       document.getElementById("hambrgrMenu").style.display = "inline-block";
       $rootScope.timeLogData = [];
       //var ctrl = this;
       /*For TreeMap chart*/
       $rootScope.projectDetails = [];
       $rootScope.avgRecord = [];
       $rootScope.avgTime = [];
       $rootScope.avgExecutions = [];
       $rootScope.IMGDescription = '';
       $rootScope.projectSpecificData = []; // Storing project specific data to display in graph
  
           var overlay_TimeReport = document.getElementById("overlay");
           var popup_timeReport = document.getElementById("busy");
           overlay_TimeReport.style.display = "inline-block";
           popup_timeReport.style.display = "inline-block";
             
       
       /*Calling Odata service http destination*/
       var input = {
    		   destinationName : "ODataSrviceReport2QA",
    		   sessionInputDTO : $rootScope.sessionInputObj	
       }
        $http.post("/" + servicePrefix + "/rest/configReportService/getTimeLogReport" ,input).then(function(response) { 
       //$http.get(odataUrl ).then(function(response) {
              if(response.status === 200){
                    if(response.data != null){  
                    	if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
              	      		$rootScope.checkAuthorization();
              	      	}else{
                                  	overlay_TimeReport.style.display = "none";
                                  	popup_timeReport.style.display = "none";
                                  	$rootScope.timeLogData = [];
                                  	var responseLength = response.data.d.results.length;
                                  	for(var i=0; i<responseLength;i++)
                                  	{
                                  		/*Removing the records with ING Descr as null*/
                                  		if(response.data.d.results[i].IMGDESCR != null)
                                  		{
                                  			$rootScope.timeLogData.push(response.data.d.results[i]);
                                  		}
                                  	}
                                  	//$rootScope.timeLogData = response.data.d.results;
                    		}
                    }else{
                                  		overlay_TimeReport.style.display = "none";
                                        popup_timeReport.style.display = "none";
                    }
              }else{
                                  overlay_TimeReport.style.display = "none";
                                  popup_timeReport.style.display = "none";
              }
       });

    // Displaying data in Tree Map chart as per selected IMG      
$scope.timeTreeGraph =  function (IMGID){
       var overlay_Graph = document.getElementById("overlay");
           var popup_Graph = document.getElementById("busy");
             overlay_Graph.style.display = "inline-block";
             popup_Graph.style.display = "inline-block";
    	 //$rootScope.IMGDescription = IMGID; 
             var input = {
          		   destinationName : "ProjSpecificDataQA",
          		   sessionInputDTO : $rootScope.sessionInputObj	
             }
    	if( $rootScope.projectSpecificData.length == 0){
     	$http.post("/" + servicePrefix + "/rest/configReportService/getTimeLogReport",input ).then(function(response) { 
                 //$http.get(odataUrl ).then(function(response) {
                         if(response.status === 200){
                              if(response.data.d.results.length > 0){
                            		if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
                          	      		$rootScope.checkAuthorization();
                          	      	}else{
                          	      		overlay_Graph.style.display = "none";
                          	      		popup_Graph.style.display = "none";
                          	      		$rootScope.projectSpecificData = response.data.d.results;
        
      /*    Setting div to null so that data is replaced instead of appeneding*/
                                        document.getElementById("viz").innerHTML = "";
                                 
                                        $rootScope.avgRecord = [];
                                        $rootScope.avgTime = [];
                                        $rootScope.avgExecutions = [];
                                        $rootScope.projectDetails = [];
                                        var arrayLeng = $rootScope.projectSpecificData.length;
                                               for(i=0;i<arrayLeng;i++){ 
                                                 if(IMGID ===  $rootScope.projectSpecificData[i].IMGID){
                                                 $rootScope.IMGDescription =$rootScope.projectSpecificData[i].SEQUENCING + "_"+ $rootScope.projectSpecificData[i].IMGDESCR; // To display IMG Descr for the graph
                                                 $rootScope.projectDetails.push($rootScope.projectSpecificData[i].PROJECTNAME);
                                                 $rootScope.avgRecord.push($rootScope.projectSpecificData[i].RECORDCOUNT);
                                                 $rootScope.avgTime.push($rootScope.projectSpecificData[i].SECONDS_EXECUTION);
                                                 $rootScope.avgExecutions.push($rootScope.projectSpecificData[i].COUNT_RECORDCOUNT);
                                                 }
                                               }

                              var comparray = [];
                                for(i=0;i<$rootScope.projectDetails.length;i++){
                                 if($rootScope.avgRecord[i] !== undefined){
                                 var obj ={};
                                        obj.name = $rootScope.projectDetails[i];
                                        obj.Average_Record= $rootScope.avgRecord[i];
                                        obj.Average_Time = $rootScope.avgTime[i];
                                        obj.Execution_Count = $rootScope.avgExecutions[i];
                                        comparray.push(obj);
                                 }
                                }
                              var attrs = { "Average_Time":comparray,"Execution_Count":comparray};
                            // instantiate d3plus
                              
                              var visualization = d3plus.viz()
                              .container("#viz") 
                              .depth(1) //container DIV to hold the visualization
                              .data(comparray)  // data to use with the visualization
                              .type("tree_map")   // visualization type
                              .id("name") 
                              //.id(["name,AvgTimeTaken"])// key for which our data is unique on
                              .size("Average_Record") // sizing of blocks
                              .attrs(attrs)
                              .text({"name":"name","Average_Time":"Average_Time"})
                              .tooltip({"share":false,"font":{"size":20}})
                              .tooltip({"  ":["Average_Time"]," ":["Execution_Count"],"share":false})
                              .labels({"resize": false, "font": {"size": 14}})
                              .history(true)
                              .draw();
                            	}
                         	}
                         }
     		});
     	}else{
     		  overlay_Graph.style.display = "none";
              popup_Graph.style.display = "none";
			        document.getElementById("viz").innerHTML = "";
			        
			        $rootScope.avgRecord = [];
			        $rootScope.avgTime = [];
			        $rootScope.avgExecutions = [];
			        $rootScope.projectDetails = [];
			        var arrayLeng = $rootScope.projectSpecificData.length;
			               for(i=0;i<arrayLeng;i++){ 
			                     if(IMGID ===  $rootScope.projectSpecificData[i].IMGID && $rootScope.projectSpecificData[i].IMGDESCR != null){
			                    	 $rootScope.IMGDescription =$rootScope.projectSpecificData[i].SEQUENCING + "_"+ $rootScope.projectSpecificData[i].IMGDESCR; // To display IMG Descr for the graph
			                $rootScope.projectDetails.push($rootScope.projectSpecificData[i].PROJECTNAME);
			                $rootScope.avgRecord.push($rootScope.projectSpecificData[i].RECORDCOUNT);
			                $rootScope.avgTime.push($rootScope.projectSpecificData[i].SECONDS_EXECUTION);
			                $rootScope.avgExecutions.push($rootScope.projectSpecificData[i].COUNT_RECORDCOUNT);
			               }
			               }

				var comparray = [];
				for(i=0;i<$rootScope.projectDetails.length;i++){
				 if($rootScope.avgRecord[i] !== undefined){
				 var obj ={};
				        obj.name = $rootScope.projectDetails[i];
				        obj.Average_Record= $rootScope.avgRecord[i];
				        obj.Average_Time = $rootScope.avgTime[i];
				    obj.Execution_Count = $rootScope.avgExecutions[i];
				comparray.push(obj);
				}
				}
				// instantiate d3plus
				var attrs = { "Average_Time":comparray,"Execution_Count":comparray};
				 var visualization = d3plus.viz()
				.container("#viz") 
				.depth(1) //container DIV to hold the visualization
				.data(comparray)  // data to use with the visualization
				.type("tree_map")   // visualization type
				.id("name") 
				//.id(["name,AvgTimeTaken"])// key for which our data is unique on
				.size("Average_Record") // sizing of blocks
				.attrs(attrs)
				.text({"name":"name","Average_Time":"Average_Time"})
				.tooltip({"share":false,"font":{"size":20}})
				.tooltip({"  ":["Average_Time"]," ":["Execution_Count"],"share":false})
				.labels({"resize": false, "font": {"size": 14}})
				.history(true)
				.draw();
     	}   
};
}]);