
var app = angular.module('yapp', ['ui.router', 'ngAnimate', 'ui.bootstrap', 'ngMaterial','angularUtils.directives.dirPagination','ngFileUpload','ngDialog','ngTouch','ui.grid','ui.grid.selection', 'ui.grid.exporter','smart-table','autocomplete','ngIdle','ivh.treeview','ngTable','infinite-scroll','oc.lazyLoad','ngPatternRestrict'])

var servicePrefix = "S4ConfigRPA";
var controllerName = "controller";
var serviceMessage = "Unauthorzied service Request. Please connect with Administrator.";
var showBrowserMsg = "";
var sessionTimeout = false;
if( window.navigator.userAgent.toLowerCase().indexOf('chrome') > -1 ){
	// Do something in Chrome
	showBrowserMsg = "false";
}else if (window.navigator.userAgent.indexOf("Edge") > -1){
	showBrowserMsg = "true";
}
else{
	showBrowserMsg = "true";
}

if(version == undefined)
var version = 5.00;
//var version = 1;
app.config(function($ocLazyLoadProvider, $locationProvider, $stateProvider, $urlRouterProvider,IdleProvider,$httpProvider) {

	//$ocLazyLoad.load(controllerName+'/loginController.js?ver='+version);
	
    if (!$httpProvider.defaults.headers.get) {
        $httpProvider.defaults.headers.get = {};
      }
      // disable IE ajax request caching
      $httpProvider.defaults.headers.get['If-Modified-Since'] = '0';
    
      $httpProvider.defaults.useXDomain = true;
      $httpProvider.defaults.withCredentials = true;
      delete $httpProvider.defaults.headers.common["X-Requested-With"];
      $httpProvider.defaults.headers.common["Accept"] = "application/json";
      $httpProvider.defaults.headers.common["Content-Type"] = "application/json ";
      $httpProvider.defaults.headers.common["Cache-Control"] = "No-cache";
      $httpProvider.defaults.headers.common["X-FRAME-OPTIONS"] = "Deny";
      $httpProvider.defaults.headers.common["Content-Security-Policy"] = "frame-ancestors 'none'";
    //Idle time 25mins  
    IdleProvider.idle(6900);
    IdleProvider.timeout(7200);
    //Config For ocLazyLoading
 
    $ocLazyLoadProvider.config({
        'debug': true, // For debugging 'true/false'
        'events': true, // For Event 'true/false'
        'modules': [{ // Set modules initially
            name : 'admin', // Admin module
            files: [controllerName+'/admin/createClientController.js?ver='+version]
        },
        {
            name : 'controller', 
            files: [controllerName+'/mainPage.js?ver='+version]
        },
        {
            name : 'controller', 
            files: [controllerName+'/admin/adminPage.js?ver='+version]
        },
        
        {
            name : 'admin', 
            files: [controllerName+'/admin/tableClientController.js?ver='+version]
        },       
        {
            name : 'admin', 
            files: [controllerName+'/admin/tableUserController.js?ver='+version]
        },       
        {
            name : 'processhierarchy', 
            files: [controllerName+'/processhierarchy/maintainProcess.js?ver='+version]
        },
        {
            name : 'managetemplate', 
            files: [controllerName+'/managetemplate/importTemplate.js?ver='+version]
        },
        {
            name : 'admin', 
            files: [controllerName+'/admin/tableSystemController.js?ver='+version]
        },      
        {
            name : 'reports', 
            files: [controllerName+'/reports/report.js?ver='+version]
        },
        {
            name : 'reports', 
            files: [controllerName+'/reports/timeLogReport.js?ver='+version]
        },
        {
            name : 'download', 
            files: [controllerName+'/download/DownloadTemplatePage.js?ver='+version]
        },      
        {
            name : 'createhierarchy', 
            files: [controllerName+'/createhierarchy/createTemplate.js?ver='+version]
        },
        {
            name : 'config', 
            files: [controllerName+'/config/ConfigPage.js?ver='+version]
        },
        {
            name : 'config', 
            files: [controllerName+'/config/ConfigFileUpload.js?ver='+version]
        },{
            name : 'config', 
            files: [controllerName+'/config/ConfigFileDownload.js?ver='+version]
        },{
            name : 'config', 
            files: [controllerName+'/config/copyFunctionalityfileDownload.js?ver='+version]
        },
        {
            name : 'config', 
            files: [controllerName+'/config/ConfigExecute.js?ver='+version]
        },
        {
            name : 'config', 
            files: [controllerName+'/config/CopyConfigExecute.js?ver='+version]
        },
        {
            name : 'config', 
            files: [controllerName+'/config/ConfigHomePage.js?ver='+version]
        },
        {
            name : 'config', 
            files: [controllerName+'/config/ScopeView.js?ver='+version]
        },
        {
            name : 'config', 
            files: [controllerName+'/config/CopyScopeView.js?ver='+version]
        },
        {
            name : 'config', 
            files: [controllerName+'/config/HomeView.js?ver='+version]
        },
        {
            name : 'config', 
            files: [controllerName+'/config/DependencyLogs.js?ver='+version]
        },{
            name : 'config', 
            files: [controllerName+'/config/ScopeLogs.js?ver='+version]
        },{
            name : 'config', 
            files: [controllerName+'/config/ConfigDwldStatus.js?ver='+version]
        },{
            name : 'config', 
            files: [controllerName+'/config/configTilesPage.js?ver='+version]
        },{
            name : 'config', 
            files: [controllerName+'/config/trgSysSelection.js?ver='+version]
        },{
            name : 'createhierarchy', 
            files: [controllerName+'/createhierarchy/ivhTreeView.js?ver='+version]
        },{
            name : 'createhierarchy', 
            files: [controllerName+'/createhierarchy/treeViewDataLoad.js?ver='+version]
        },{
            name : 'createhierarchy', 
            files: [controllerName+'/createhierarchy/treeViewDataService.js?ver='+version]
        },{
            name : 'createhierarchy', 
            files: [controllerName+'/createhierarchy/tree.js?ver='+version]
        },{
            name : 'demotemplate', 
            files: [controllerName+'/demotemplate/demoTemplate.js?ver='+version]
        },
        {
            name : 'helpDoc', 
            files: [controllerName+'/helpDoc/importHelpDoc.js?ver='+version]
        },
        {
           name : 'config',
           files: [controllerName+'/config/selectIndustry.js?ver='+version]
        },
           {
        	   name:'config',
        	   files: [controllerName+'/config/IndustryType.js?ver='+version]
           }
        ]
    });
   

   
    $urlRouterProvider.otherwise('/loginPage');
    $locationProvider.hashPrefix('!');
    $stateProvider
        .state('loginPage', {
            url: '/loginPage',
            templateUrl: 'view/loginPage.html?ver='+version,
            controller: 'LoginPageController'
            
        })

        .state('HomeView', {
            url: '/HomeView',
            templateUrl: 'view/config/HomeView.html?ver='+version,
            controller: 'HomeCtrl',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/config/HomeView.js?ver='+version); // Resolve promise and load before view 
                }]
            }
        }) 
        
        .state('IndustryType', {
            url: '/IndustryType',
            templateUrl: 'view/config/IndustryType.html?ver='+version,
            controller: 'IndustryType',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/config/IndustryType.js?ver='+version); // Resolve promise and load before view 
                }]
            }
        }) 
        
        .state('selectIndustry', {
            url: '/selectIndustry',
            templateUrl: 'view/config/selectIndustry.html?ver='+version,
            controller: 'selectIndustry',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/config/selectIndustry.js?ver='+version); // Resolve promise and load before view 
                }]
            }
        }) 

        .state('ConfigHeader', {
            url: '/ConfigHeader',
            templateUrl: 'view/config/ConfigHeaderPage.html?ver='+version,
            controller: 'ConfigHomePage',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/config/ConfigHomePage.js?ver='+version); // Resolve promise and load before view 
                }]
            }
        })
        .state('ConfigHeader.fileUpload', {
            url: '/fileUpload',
            templateUrl: 'view/config/FileUpload.html?ver='+version,
            controller: 'ConfigFileUploadPage',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/config/ConfigFileUpload.js?ver='+version); // Resolve promise and load before view 
                }]
            }
        })
         .state('ConfigHeader.CopyFileUpload', {
            url: '/CopyFileUpload',
            templateUrl: 'view/config/CopyFileUpload.html?ver='+version,
            controller: 'CopyFileUploadPage',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/config/CopyFileUpload.js?ver='+version); // Resolve promise and load before view 
                }]
            }
        })

        .state('ConfigHeader.configPage', {
            url: '/configPage',
            templateUrl: 'view/config/ConfigPage.html?ver='+version,
            controller: 'ConfigInitialPage',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/config/ConfigPage.js?ver='+version); // Resolve promise and load before view 
                }]
            }
        })
        
         .state('ConfigHeader.copyFunctionality', {
            url: '/copyFunctionality',
            templateUrl: 'view/config/CopyFunctionality.html?ver='+version,
            controller: 'CopyFunctionalityPage',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/config/CopyFunctionality.js?ver='+version); // Resolve promise and load before view 
                }]
            }
        })
                
        .state('ConfigHeader.consolidationPage', {
            url: '/consolidationPage',
            templateUrl: 'view/config/ConsolidationPage.html?ver='+version,
            controller: 'ConsolidationInitialPage',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/config/ConsolidationPage.js?ver='+version); // Resolve promise and load before view 
                }]
            }
        })

       .state('DownloadTemplate', {
            url: '/DownloadTemplate',
            templateUrl: 'view/download/DownloadTemplatePage.html?ver='+version,
            controller: 'DownloadTemplatePage',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/download/DownloadTemplatePage.js?ver='+version); // Resolve promise and load before view 
                }]
            }
        })

        .state('ConfigHeader.fileDownload', {
            url: '/fileDownload',
            templateUrl: 'view/config/FileDownload.html?ver='+version,
            controller: 'ConfigFileDownloadPage',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/config/ConfigFileDownload.js?ver='+version); // Resolve promise and load before view 
                }]
            }
        })
        .state('ConfigHeader.CopyFileDownload', {
            url: '/CopyFileDownload',
            templateUrl: 'view/config/CopyFileDownload.html?ver='+version,
            controller: 'copyFunctionalityFileDownloadPage',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/config/copyFunctionalityfileDownload.js?ver='+version); // Resolve promise and load before view 
                }]
            }
        })
        .state('ConfigHeader.configExecute', {
            url: '/configExecute',
            templateUrl: 'view/config/ConfigExecute.html?ver='+version,
            controller: 'ConfigExecutePage',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/config/ConfigExecute.js?ver='+version,''); // Resolve promise and load before view 
                }]
            }
        })
         .state('ConfigHeader.CopyConfigExecute', {
            url: '/CopyConfigExecute',
            templateUrl: 'view/config/CopyConfigExecute.html?ver='+version,
            controller: 'CopyConfigExecutePage',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/config/CopyConfigExecute.js?ver='+version,''); // Resolve promise and load before view 
                }]
            }
        })
        .state('adminPage', {
            url: '/adminPage',
            templateUrl: 'view/admin/adminPage.html?ver='+version,
            controller: 'adminPageController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/admin/adminPage.js?ver='+version); // Resolve promise and load before view 
                }]
            }
        })

        .state('createClient', {
            url: '/createClient',
            templateUrl: 'view/admin/createClient.html?ver='+version,
            controller: 'createClientController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/admin/createClientController.js?ver='+version); // Resolve promise and load before view 
                }]
            }
        })
       .state('assignProjectsToUser', {
            url: '/assignProjectsToUser',
            templateUrl: 'view/admin/assignProjectsToUser.html?ver='+version,
            controller: 'assignProjectsToUserController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/admin/assignProjectsToUserController.js?ver='+version); // Resolve promise and load before view 
                }]
            }
        })
        .state('assignUsersToProject', {
            url: '/assignUsersToProject',
            templateUrl: 'view/admin/assignUsersToProject.html?ver='+version,
            controller: 'assignUsersToProjectController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/admin/assignUsersToProjectController.js?ver='+version); // Resolve promise and load before view 
                }]
            }
        })
        .state('createUser', {
            url: '/createUser',
            templateUrl: 'view/admin/createUser.html?ver='+version,
            controller: 'createUserController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/admin/createUserController.js?ver='+version); // Resolve promise and load before view 
                }]
            }
        })

        .state('mainPage.tableClient', {
            url: '/tableClient',
            templateUrl: 'view/admin/tableClient.html?ver='+version,
            controller: 'tableClientController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/admin/tableClientController.js?ver='+version); // Resolve promise and load before view 
                }]
            }
        })

        .state('mainPage.tableUser', {
            url: '/tableUser',
            templateUrl: 'view/admin/tableUser.html?ver='+version,
            controller: 'tableUserController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/admin/tableUserController.js?ver='+version); // Resolve promise and load before view 
                }]
            }
        })
        
         .state('mainPage.tableSystem', {
            url: '/tableSystem',
            templateUrl: 'view/admin/tableSystem.html?ver='+version,
            controller: 'tableSystemController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/admin/tableSystemController.js?ver='+version); // Resolve promise and load before view 
                }]
            }
        })

        .state('editClient', {
            url: '/editClient',
            templateUrl: 'view/admin/editClient.html?ver='+version,
            controller: 'editClientController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/admin/editClientController.js?ver='+version); // Resolve promise and load before view 
                }]
            }
        })

        .state('editUser', {
            url: '/editUser',
            templateUrl: 'view/admin/editUser.html?ver='+version,
            controller: 'editUserController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/admin/editUserController.js?ver='+version); // Resolve promise and load before view 
                }]
            }
        })

        .state('treeView', {
            url: '/treeView',
            templateUrl: 'view/treeView.html?ver='+version,
            controller: 'treeViewController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/admin/tableViewController.js?ver='+version); // Resolve promise and load before view 
                }]
            }
        })

        .state('mainPage', {
            url: '/mainPage',
            templateUrl: 'view/mainPage.html?ver='+version,
            controller: 'mainPage',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/mainPage.js?ver='+version); // Resolve promise and load before view 
                }]
            }
        })
		  .state('mainPage.maintainProcess', {
            url: '/maintainProcess',
            templateUrl: 'view/processhierarchy/maintainProcess.html?ver='+version,
            controller: 'maintainProcessController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/processhierarchy/maintainProcess.js?ver='+version); // Resolve promise and load before view 
                }]
            }
        })
        .state('mainPage.manageTemplate', {
            url: '/manageTemplate',
            templateUrl: 'view/managetemplate/manageTemplate.html?ver='+version,
            controller: 'importTemplatePage',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/managetemplate/importTemplate.js?ver='+version); // Resolve promise and load before view 
                }]
            }
        })
	    .state('ConfigHeader.manageTemplate', {
            url: '/manageTemplate',
            templateUrl: 'view/managetemplate/manageTemplate.html?ver='+version,
            controller: 'importTemplatePage',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/managetemplate/importTemplate.js?ver='+version); // Resolve promise and load before view 
                }]
            }
        })
	.state('createSystem', {
            url: '/createSystem',
            templateUrl: 'view/admin/createSystem1.html?ver='+version,
            controller: 'createSystemController',
            
        })
    .state('toolAdminPage', {
            url: '/toolAdminPage',
            templateUrl: 'view/admin/toolAdminPage.html?ver='+version,
            controller: 'toolAdminPageController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/admin/toolAdminPage.js?ver='+version); // Resolve promise and load before view 
                }]
            }
        })
     .state('mainPage.timeLogReport', {
            url: '/timeLogReport',
            templateUrl: 'view/report/timeLogReport.html?ver='+version,
            controller: 'timeLogreportController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/reports/timeLogReport.js?ver='+version); // Resolve promise and load before view 
                }]
            }
      })
        .state('mainPage.importHelpDoc', {
            url: '/importHelpDoc',
            templateUrl: 'view/helpDoc/importHelpDoc.html?ver='+version,
            controller: 'importHelpDoc',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/helpDoc/importHelpDoc.js?ver='+version); // Resolve promise and load before view 
                }]
            }
      })
          .state('ConfigHeader.importHelpDoc', {
            url: '/importHelpDoc',
            templateUrl: 'view/helpDoc/importHelpDoc.html?ver='+version,
            controller: 'importHelpDoc',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/helpDoc/importHelpDoc.js?ver='+version); // Resolve promise and load before view 
                }]
            }
      })
       .state('configTilesPage', {
            url: '/configTilesPage',
            templateUrl: 'view/config/configTilesPage.html?ver='+version,
            controller: 'configTilesController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/config/configTilesPage.js?ver='+version); // Resolve promise and load before view 
                }]
            }
      })
      .state('confirm', {
            url: '/confirm',
            templateUrl: 'view/config/confirm.html?ver='+version,
            controller: 'ConfigInitialPage',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/config/ConfigPage.js?ver='+version); // Resolve promise and load before view 
                }]
            }
      })
        .state('mainPage.createTemplate', {
            url: '/createTemplate',
            templateUrl: 'view/createhierarchy/createTemplate.html?ver='+version,
            controller: 'createTemplatePage',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/createhierarchy/createTemplate.js?ver='+version); // Resolve promise and load before view 
                }]
            }
      })
          .state('mainPage.demoTemplate', {
            url: '/demoTemplate',
            templateUrl: 'view/demotemplate/demoTemplate.html?ver='+version,
            controller: 'DemoCtrls',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/demotemplate/demoTemplate.js?ver='+version); // Resolve promise and load before view 
                }]
            }
      })
          .state('mainPage.createGoldenTemplate', {
            url: '/createGoldenTemplate',
            templateUrl: 'view/managetemplate/createGoldenTemplate.html?ver='+version,
            controller: 'importTemplatePage',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/managetemplate/importTemplate.js?ver='+version); // Resolve promise and load before view 
                }]
            }
      })
/*      For Admin Landing Page*/
      .state('adminLandingPage', {
            url: '/adminLandingPage',
            templateUrl: 'view/admin/adminLandingPage.html?ver='+version,
            controller: 'mainPage',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/mainPage.js?ver='+version); // Resolve promise and load before view 
                }]
            }
      })
     /* Reporting Page in Config Module*/
        .state('ConfigHeader.configReports', {
            url: '/configReports',
            templateUrl: 'view/report/configReports.html?ver='+version,
            controller: 'configReports',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/reports/configReports.js?ver='+version); // Resolve promise and load before view 
                }]
            }
      })
     /* Config Download Report*/
          .state('ConfigHeader.configDwnLdReport', {
            url: '/configDwnLdReport',
            templateUrl: 'view/report/configDwnLdReport.html?ver='+version,
            controller: 'configReports',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/reports/configReports.js?ver='+version); // Resolve promise and load before view 
                }]
            }
      })
/*      Config TR Report*/
            .state('ConfigHeader.trConfigReport', {
            url: '/trConfigReport',
            templateUrl: 'view/report/trConfigReport.html?ver='+version,
            controller: 'configReports',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/reports/configReports.js?ver='+version); // Resolve promise and load before view 
                }]
            }
      })
        .state('executionReport', {
            url: '/executionReport',
            templateUrl: 'view/report/executionReport.html?ver='+version,
            controller: 'configReports',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/reports/configReports.js?ver='+version); // Resolve promise and load before view 
                }]
            }
      })
      //List of Reports for Config user
         .state('ConfigHeader.reportsList', {
            url: '/reportsList',
            templateUrl: 'view/report/reportsList.html?ver='+version,
            controller: 'configReports',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/reports/configReports.js?ver='+version); // Resolve promise and load before view 
                }]
            }
      })
         .state('configDownldLogs', {
            url: '/configDownldLogs',
            templateUrl: 'view/report/configDownldLogs.html?ver='+version,
            controller: 'configReports',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/reports/configReports.js?ver='+version); // Resolve promise and load before view 
                }]
            }
      })
      //New html page to show the pop up containing Golden Temp info and deployment info
      .state('templateUpdate', {
            url: '/templateUpdate',
            templateUrl: 'view/templateUpdate.html?ver='+version,
            controller: 'configTilesController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/config/configTilesController.js?ver='+version); // Resolve promise and load before view 
                }]
            }
      })
  /*    Adding new HTMLs for managing Config User password*/
    
              .state('securityQuestions', {
            url: '/securityQuestions',
            templateUrl: 'view/managePassword/securityQuestions.html?ver='+version,
            controller: 'LoginPageController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/LoginPageController.js?ver='+version); // Resolve promise and load before view 
                }]
            }
      })
                .state('forgotPassword', {
            url: '/forgotPassword',
            templateUrl: 'view/managePassword/forgotPassword.html?ver='+version,
            controller: 'LoginPageController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/LoginPageController.js?ver='+version); // Resolve promise and load before view 
                }]
            }
      })
                 .state('resetPassword', {
            url: '/resetPassword',
            templateUrl: 'view/managePassword/resetPassword.html?ver='+version,
            controller: 'LoginPageController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/LoginPageController.js?ver='+version); // Resolve promise and load before view 
                }]
            }
      })
              .state('changePassword', {
            url: '/changePassword',
            templateUrl: 'view/managePassword/changePassword.html?ver='+version,
            controller: 'configTilesController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/config/configTilesController.js?ver='+version); // Resolve promise and load before view 
                }]
            }
      })
                 .state('setUpSecurityQA', {
            url: '/setUpSecurityQA',
            templateUrl: 'view/managePassword/setUpSecurityQA.html?ver='+version,
            controller: 'configTilesController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/config/configTilesController.js?ver='+version); // Resolve promise and load before view 
                }]
            }
      }) .state('mainPage.addAndDeleteAction', {
          url: '/addAndDeleteAction',
          templateUrl: 'view/admin/addAndDeleteAction.html?ver='+version,
          controller: 'addAndDeleteAction',
          resolve: {
              loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                  return $ocLazyLoad.load(controllerName+'/admin/addAndDeleteAction.js?ver='+version); // Resolve promise and load before view 
              }]
          }
    })
      .state('mainPage.ActiveUserReport', {
            url: '/ActiveUserReport',
            templateUrl: 'view/report/ActiveUserReport.html?ver='+version,
            controller: 'reportController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/reports/report.js?ver='+version); // Resolve promise and load before view 
                }]
            }
      })
        .state('mainPage.EffortSavingReport', {
            url: '/EffortSavingReport',
            templateUrl: 'view/report/EffortSavingReport.html?ver='+version,
            controller: 'reportController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/reports/report.js?ver='+version); // Resolve promise and load before view 
                }]
            }
      })
      .state('mainPage.DownloadReportPadmin', {
            url: '/DownloadReportPadmin',
            templateUrl: 'view/report/DownloadReportPadmin.html?ver='+version,
            controller: 'reportController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/reports/report.js?ver='+version); // Resolve promise and load before view 
                }]
            }
      })
        .state('mainPage.uploadReportPAdmin', {
            url: '/uploadReportPAdmin',
            templateUrl: 'view/report/uploadReportPAdmin.html?ver='+version,
            controller: 'reportController',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/reports/report.js?ver='+version); // Resolve promise and load before view 
                }]
            }
      })
      .state('alertManualConfig', {
            url: '/alertManualConfig',
            templateUrl: 'view/config/alertManualConfig.html?ver='+version,
            controller: 'ConfigExecutePage',
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load(controllerName+'/config/ConfigExecute.js?ver='+version); // Resolve promise and load before view 
                }]
            }
      })
    $locationProvider.html5Mode(false);
})
/*
app.run(['Idle', function(Idle) {
	      Idle.watch();
       }])*/
app.run(function($rootScope, Idle,$mdDialog,$http,ngDialog,$location) {
  Idle.watch();
  $rootScope.$on('IdleStart', function(ev) {
	  
	  /* Display modal warning or sth */ 
	  if($rootScope.download == false){
	  var confirm = $mdDialog.confirm()
	     .title('Warning')
	     .textContent('Your session is going to expire in 5mins, Do you want to extend it')
	     .ariaLabel('Alert Dialog Demo')
	     .targetEvent(ev)
	     .ok('OK')
	     .cancel('CANCEL');
		
		$mdDialog.show(confirm).then(function() {
		  	var inputParam = {
		  			sessionId : $rootScope.sessionInputObj.sessionId,
		  			csrfToken : $rootScope.sessionInputObj.csrfToken
		  	}
		  	$http.post("/" + servicePrefix + "/rest/adminSrv/resetSessionTime", inputParam).then(function(response) {
				  if(response.status === 200){
					if(response.data.dataStatus == true){
					   $mdDialog.show(
			               	        $mdDialog.alert()
			                        .parent(angular.element(document.body))
			                        .clickOutsideToClose(true)
			                        .title('Alert Dialog')
			                        .textContent('Your session is extended. Thank you')
			                        .ariaLabel('Alert Dialog Demo')
			                        .ok('OK') 
			                        .targetEvent(ev)
				    	   			)
					}/*else if(sessionTimeout != true){
					  $mdDialog.show(
			               	        $mdDialog.alert()
			                        .parent(angular.element(document.body))
			                        .clickOutsideToClose(true)
			                        .title('Alert Dialog')
			                        .textContent('Something went wrong, Please login again.')
			                        .ariaLabel('Alert Dialog Demo')
			                        .ok('OK') 
			                        .targetEvent(ev)
				    	   			)
					}*/
				  	}
		  	});
		  }, function() {
		  	$mdDialog.hide();
		  });
	  }
  });
  $rootScope.$on('IdleTimeout', function() { /* Logout user */
	  if($rootScope.download == false){
	  sessionTimeout = true;
	  $mdDialog.hide();
	  ngDialog.close();
	  $location.path('/loginPage');
	  $mdDialog.show(
           $mdDialog.alert()
           .parent(angular.element(document.body))
           .clickOutsideToClose(true) 
           .title('Automatic log off')
           .textContent('Your Session has expired. Please logon again')
           .ariaLabel('Alert Dialog Demo')
           .ok('Ok')
);	  
	  }
  });
});
app.config(function(ivhTreeviewOptionsProvider) {
		 ivhTreeviewOptionsProvider.set({
		       twistieCollapsedTpl: '<leaf><span class="fa fa-plus"></span></leaf> ',
				        twistieExpandedTpl: '<leaf><span class="fa fa-minus"></span></leaf>',
				        twistieLeafTpl: '<leaf></leaf>',
				        labelAttribute: 'imgDescription',
				        childrenAttribute: 'children',
				        idAttribute:'imgId',
				        selectedAttribute: 'selected',
				       defaultSelectedState: false,
				       expandToDepth: 3,
				       validate: true

		 });
		});
app.filter('selected', [
    '$filter',
    function($filter) {
        return function(files) {
            return $filter('filter')(files, {
                selected: true
            });
        };
    }
])

app.directive('fileModel', ['$parse', function($parse) {
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;

            element.bind('change', function() {
                scope.$apply(function() {
                    modelSetter(scope, element[0].files[0]);
                });
            });
        }
    };
}])


            	//if(!$rootScope.previewHierarchy){

app.directive('leafconfig', function (tree, ivhTreeviewMgr,$window,apiService,$rootScope,$http) {
	
        return { 
            restrict: 'AE', 
            link: function (scope, element, attrs) {
            if($rootScope.userRole == "Config" && $rootScope.downloadtempUser == false){
            	var text = document.getElementById('style-4');
            	if($rootScope.copy == true){
            		text.classList.remove('Scenario');
            	}
            	else if($rootScope.hierarchyTypes.value =="Business Process"||$rootScope.consolidate==true)
    			{
    				
    			text.classList.add('Scenario');
    			}
    			else{
    			text.classList.remove('Scenario');
    			}
              		var count = 0;
          	  if(scope.node.children.length > 0){
            		

          		  for( var i=0,arrLen = scope.node.children.length;i < arrLen;i++)
          			  {
          			  		if($rootScope.scopevalueArray.indexOf(scope.node.children[i].imgId) !== -1){
          			  		//scope.node.selected = true;
          			  			count = count + 1;
          			  		}
          			  }
          		  if(scope.node.children.length == count)
          			scope.node.selected = true; 
          	  		}
          	  	if($rootScope.scopevalueArray.indexOf(scope.node.imgId) !== -1)
          	  		scope.node.selected = true;
          	}
        	   
            if(scope.node.nodetype != null && scope.node.nodetype == "IMG"){
            	//scope.node.imgDescription = "";
            	}
            }
            
        };
	
    });

app.directive('templeaf', function (tree, ivhTreeviewMgr,$window,apiService,$rootScope,$http) {
	
    return { 
        restrict: 'AE', 
        link: function (scope, element, attrs) {

            
    	  if($rootScope.userRole != "Config" 
    		    &&  ($rootScope.scopevalueArrays1.indexOf(scope.node.imgId) !== -1
    	    		 || $rootScope.scopevalueArray.indexOf(scope.node.imgId) !== -1 
    	    		 || $rootScope.scopevalueArrays.indexOf(scope.node.imgId) !== -1)
    	    		 ){
    		  var arrLen = 0;
    		  if($rootScope.selectedTab == "tab1" && $rootScope.scopevalueArrays1.indexOf(scope.node.imgId) !== -1){
        	    	  scope.node.selected = true;  
        	    
    		  }
    		  else if($rootScope.selectedTab == "tab2" && $rootScope.scopevalueArray.indexOf(scope.node.imgId) !== -1){
        	    	  scope.node.selected = true;
        	
    		  }
    		  else if($rootScope.selectedTab == "tab3" && $rootScope.scopevalueArrays.indexOf(scope.node.imgId) !== -1){
        	    	  scope.node.selected = true;
        	    	  
        	    	  
    		  	}
    		  if($rootScope.selectedTab == "tab1"){
    			var count = 0;
              	  if(scope.node.children.length > 0){
                	for( var i=0,arrLen = scope.node.children.length; i < arrLen;i++)
              			  {
              			  		if($rootScope.scopevalueArrays1.indexOf(scope.node.children[i].imgId) !== -1){
              			  		//scope.node.selected = true;
              			  			count = count + 1;
              			  		}
              			  }
              		  if(scope.node.children.length == count)
              			scope.node.selected = true; 
              	  		} 
    		  }
    		  if($rootScope.selectedTab == "tab2"){
    			  var count = 0;
              	  if(scope.node.children.length > 0){
                	for( var i=0,arrLen = scope.node.children.length; i < arrLen;i++)
              			  {
              			  		if($rootScope.scopevalueArray.indexOf(scope.node.children[i].imgId) !== -1){
              			  		//scope.node.selected = true;
              			  			count = count + 1;
              			  		}
              			  }
              		  if(scope.node.children.length == count)
              			scope.node.selected = true; 
              	  		} 
    		  }
    		  if($rootScope.selectedTab == "tab3"){
    			  var count = 0;
              	  if(scope.node.children.length > 0){
                	for( var i=0,arrLen = scope.node.children.length; i < arrLen;i++)
              			  {
              			  		if($rootScope.scopevalueArrays.indexOf(scope.node.children[i].imgId) !== -1){
              			  		//scope.node.selected = true;
              			  			count = count + 1;
              			  		}
              			  }
              		  if(scope.node.children.length == count)
              			scope.node.selected = true; 
              	  		} 
    		  }
    		  
    	  	} 
    	  else if($rootScope.isManagetemplate){
    		  
	    	  scope.node.selected = false;

    	  }
    		 if($rootScope.userRole == "Config" && $rootScope.downloadtempUser == true ){
       			 // if(  || $rootScope.scopevalueArrays1.indexOf(scope.node.imgId) !== -1 || $rootScope.scopevalueArrays.indexOf(scope.node.imgId) !== -1){
       			if($rootScope.scopevalueArrays.indexOf(scope.node.imgId) !== -1)  
       					  scope.node.selected = true;
       				var count = 0;
                	  if(scope.node.children.length > 0){
                  		

                		  for( var i=0,arrLen = scope.node.children.length; i < arrLen;i++)
                			  {
                			  		if($rootScope.scopevalueArrays.indexOf(scope.node.children[i].imgId) !== -1){
                			  		//scope.node.selected = true;
                			  			count = count + 1;
                			  		}
                			  }
                		  if(scope.node.children.length == count)
                			scope.node.selected = true; 
                	  		}} }
            
        };
	
    });
app.directive('leafadmin', function (tree, ivhTreeviewMgr,$window,apiService,$rootScope,$http) {
	
    return { 
        restrict: 'AE', 
        link: function (scope, element, attrs) {

     
      			  if($rootScope.selectedid != null && $rootScope.selectedid.length > 0){
      				  if($rootScope.selectedid.indexOf(scope.node.imgId) !== -1)
      				  {
      					// if(scope.node.enabled == 1)
      						  scope.node.selected = true;
      				  	}
      				var count = 0;
      				var arrLen = 0;
                	  if(scope.node.children.length > 0){
                		  
                		  for( var i=0,arrLen = scope.node.children.length; i < arrLen;i++)
                			  {
                			  		if($rootScope.selectedid.indexOf(scope.node.children[i].imgId) !== -1){
                			  		//scope.node.selected = true;
                			  			count = count + 1;
                			  		}
                			  		
                			  }
                		  if(scope.node.children.length == count)
                			scope.node.selected = true; 
                	  		}
      			  }
      	}
        
    };

});

app.config(['$provide', function ($provide) {
    $provide.decorator("$exceptionHandler", ['$delegate', '$injector', function ($delegate, $injector) {
        return function (exception, cause) {
            var exceptionsToIgnore = ['Possibly unhandled rejection: $closeButton','Possibly unhandled rejection: undefined']
            if (exceptionsToIgnore.indexOf(exception) >= 0) {
                return;
            }
            $delegate(exception, cause);                    
        };
    }]);
}]);

app.service('fileUpload', ['$http', '$mdDialog', function($http, $mdDialog) {

}]);
app.value('THROTTLE_MILLISECONDS', null);

app.directive('infiniteScroll', [
  '$rootScope', '$window', '$interval', 'THROTTLE_MILLISECONDS',
  function($rootScope, $window, $interval, THROTTLE_MILLISECONDS) {
    return {
      scope: {
        infiniteScroll: '&',
        infiniteScrollContainer: '=',
        infiniteScrollDistance: '=',
        infiniteScrollDisabled: '=',
        infiniteScrollUseDocumentBottom: '=',
        infiniteScrollListenForEvent: '@'
      },
      link: function(scope, elem, attrs) {
        var changeContainer, checkWhenEnabled, container, handleInfiniteScrollContainer, handleInfiniteScrollDisabled, handleInfiniteScrollDistance, handleInfiniteScrollUseDocumentBottom, handler, height, immediateCheck, offsetTop, pageYOffset, scrollDistance, scrollEnabled, throttle, unregisterEventListener, useDocumentBottom, windowElement;
        windowElement = angular.element($window);
        scrollDistance = null;
        scrollEnabled = null;
        checkWhenEnabled = null;
        container = null;
        immediateCheck = true;
        useDocumentBottom = false;
        unregisterEventListener = null;
        height = function(elem) {
          elem = elem[0] || elem;
          if (isNaN(elem.offsetHeight)) {
            return elem.document.documentElement.clientHeight;
          } else {
            return elem.offsetHeight;
          }
        };
        offsetTop = function(elem) {
          if (!elem[0].getBoundingClientRect || elem.css('none')) {
            return;
          }
          return elem[0].getBoundingClientRect().top + pageYOffset(elem);
        };
        pageYOffset = function(elem) {
          elem = elem[0] || elem;
          if (isNaN(window.pageYOffset)) {
            return elem.document.documentElement.scrollTop;
          } else {
            return elem.ownerDocument.defaultView.pageYOffset;
          }
        };
        handler = function() {
          var containerBottom, containerTopOffset, elementBottom, remaining, shouldScroll;
          if (container === windowElement) {
            containerBottom = height(container) + pageYOffset(container[0].document.documentElement);
            elementBottom = offsetTop(elem) + height(elem);
          } else {
            containerBottom = height(container);
            containerTopOffset = 0;
            if (offsetTop(container) !== void 0) {
              containerTopOffset = offsetTop(container);
            }
            elementBottom = offsetTop(elem) - containerTopOffset + height(elem);
          }
          if (useDocumentBottom) {
            elementBottom = height((elem[0].ownerDocument || elem[0].document).documentElement);
          }
          remaining = elementBottom - containerBottom;
          shouldScroll = remaining <= height(container) * scrollDistance + 1;
          if (shouldScroll) {
            checkWhenEnabled = true;
            if (scrollEnabled) {
              if (scope.$$phase || $rootScope.$$phase) {
                return scope.infiniteScroll();
              } else {
                return scope.$apply(scope.infiniteScroll);
              }
            }
          } else {
            return checkWhenEnabled = false;
          }
        };
        throttle = function(func, wait) {
          var later, previous, timeout;
          timeout = null;
          previous = 0;
          later = function() {
            var context;
            previous = new Date().getTime();
            $interval.cancel(timeout);
            timeout = null;
            func.call();
            return context = null;
          };
          return function() {
            var now, remaining;
            now = new Date().getTime();
            remaining = wait - (now - previous);
            if (remaining <= 0) {
              clearTimeout(timeout);
              $interval.cancel(timeout);
              timeout = null;
              previous = now;
              return func.call();
            } else {
              if (!timeout) {
                return timeout = $interval(later, remaining, 1);
              }
            }
          };
        };
        if (THROTTLE_MILLISECONDS != null) {
          handler = throttle(handler, THROTTLE_MILLISECONDS);
        }
        scope.$on('$destroy', function() {
          container.unbind('scroll', handler);
          if (unregisterEventListener != null) {
            unregisterEventListener();
            return unregisterEventListener = null;
          }
        });
        handleInfiniteScrollDistance = function(v) {
          return scrollDistance = parseFloat(v) || 0;
        };
        scope.$watch('infiniteScrollDistance', handleInfiniteScrollDistance);
        handleInfiniteScrollDistance(scope.infiniteScrollDistance);
        handleInfiniteScrollDisabled = function(v) {
          scrollEnabled = !v;
          if (scrollEnabled && checkWhenEnabled) {
            checkWhenEnabled = false;
            return handler();
          }
        };
        scope.$watch('infiniteScrollDisabled', handleInfiniteScrollDisabled);
        handleInfiniteScrollDisabled(scope.infiniteScrollDisabled);
        handleInfiniteScrollUseDocumentBottom = function(v) {
          return useDocumentBottom = v;
        };
        scope.$watch('infiniteScrollUseDocumentBottom', handleInfiniteScrollUseDocumentBottom);
        handleInfiniteScrollUseDocumentBottom(scope.infiniteScrollUseDocumentBottom);
        changeContainer = function(newContainer) {
          if (container != null) {
            container.unbind('scroll', handler);
          }
          container = newContainer;
          if (newContainer != null) {
            return container.bind('scroll', handler);
          }
        };
        changeContainer(windowElement);
        if (scope.infiniteScrollListenForEvent) {
          unregisterEventListener = $rootScope.$on(scope.infiniteScrollListenForEvent, handler);
        }
        handleInfiniteScrollContainer = function(newContainer) {
          if ((newContainer == null) || newContainer.length === 0) {
            return;
          }
          if (newContainer instanceof HTMLElement) {
            newContainer = angular.element(newContainer);
          } else if (typeof newContainer.append === 'function') {
            newContainer = angular.element(newContainer[newContainer.length - 1]);
          } else if (typeof newContainer === 'string') {
            newContainer = angular.element(document.querySelector(newContainer));
          }
          if (newContainer != null) {
            return changeContainer(newContainer);
          } else {
            throw new Exception("invalid infinite-scroll-container attribute.");
          }
        };
        scope.$watch('infiniteScrollContainer', handleInfiniteScrollContainer);
        handleInfiniteScrollContainer(scope.infiniteScrollContainer || []);
        if (attrs.infiniteScrollParent != null) {
          changeContainer(angular.element(elem.parent()));
        }
        if (attrs.infiniteScrollImmediateCheck != null) {
          immediateCheck = scope.$eval(attrs.infiniteScrollImmediateCheck);
        }
        return $interval((function() {
          if (immediateCheck) {
            return handler();
          }
        }), 0, 1);
      }
    };
  }
]);

angular
.module('OData', [])
.factory('ODataService', function($http) {
  return {
    load: function(resourceUrl, queryParams) {
      return $http.get(resourceUrl, {params: queryParams})
        .then(function(response) {
          return response.data.value;
        });
    }
  }
});

app.directive('validfile', function (ngDialog,$rootScope) {

    var validFormats = ['xlsx', 'xls'];
    return {
        require: 'ngModel',
        
        link: function (scope, elem, attrs, ctrl,ngModel) {
            /*ctrl.$validators.validFile = function() {*/
                elem.on('change', function (e) {
                	 var files = elem[0].files;
             
                    
                   var value = elem.val(),
                       ext = value.substring(value.lastIndexOf('.') + 1).toLowerCase();   
                   		
                   if( validFormats.indexOf(ext) == -1){
                	 
                	   $rootScope.uploadButtondisabled = true;
                		ngDialog.openConfirm({
                            template: '<p margin-top:7%>'+"Please choose File format with .xlsx and .xls only"+'</p>',
                            plain: true,
                            scope: $rootScope,
                            closeByDocument: false,
                            closeByEscape: false,
                            showClose: true,
                            height: 110,
                            width: 350,
                            className:'ngdialog-theme-default CLASS_projName'
                        });
                	}  
                   else if( validFormats.indexOf(ext) != -1){
                	   	if($rootScope.singleUpload){
                	   		$rootScope.uploadSingleFile(files);
                	   	}else if($rootScope.importtempUser == true){
                	   		$rootScope.uploadExcelFiles(files);
                	   	}else{
                	   		$rootScope.uploadfiles(files);
                	   	}
                	
                   }
                });
          /* };*/
        }
    };
});
app.directive('validhelpdoc', function (ngDialog,$rootScope) {
 var validFormats = ['pdf', 'mp4'];
    return {
        require: 'ngModel',        
        link: function (scope, elem, attrs, ctrl,ngModel) {
             elem.on('change', function (e) {
                	 var helpdoc = elem[0].files;
                	  scope.$apply(function () {
                    })
                   var value = elem.val(),
                       ext = value.substring(value.lastIndexOf('.') + 1).toLowerCase();   
                   		
                   if( validFormats.indexOf(ext) == -1){
                	// $rootScope.uploadButtondisabled = true;
                		ngDialog.openConfirm({
                            template: '<p margin-top:7%>'+"Please choose File format with .mp4 and .pdf only"+'</p>',
                            plain: true,
                            scope: $rootScope,
                            closeByDocument: false,
                            closeByEscape: false,
                            showClose: true,
                            height: 110,
                            width: 350,
                            className:'ngdialog-theme-default CLASS_projName'
                        });
                	}  
                   else if( validFormats.indexOf(ext) != -1){ 
                	   $rootScope.uploadHelpDocument(helpdoc);
                	  // $rootScope.uploadButtondisabled = false;
                	  // $rootScope.uploadExcelFiles(files);
                	}
                });}
    };
});
