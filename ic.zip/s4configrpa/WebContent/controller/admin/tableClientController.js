angular.module('yapp').controller('tableClientController',["$scope", "$state", "$rootScope", "$http", "$mdDialog", "$mdMedia", "ngDialog", "$location", "$timeout","$ocLazyLoad", function($scope, $state, $rootScope, $http, $mdDialog, $mdMedia, ngDialog, $location, $timeout,$ocLazyLoad) {
	$ocLazyLoad.load(controllerName+'/admin/tableClientController.js?ver='+version);
	var noAuth = "false";
	if($scope.custDestReq == undefined  ){
	$scope.custDestReq="";//Added by Veena
	$scope.omId=""; 
	}
/*	var cookie = document.cookie;
		var cookieAuthParams = cookie.split(';');
		
		for (var cp1 = 0,arrLen = cookieAuthParams.length; cp1 < arrLen; cp1++) {*/
			if ($rootScope.adminAuth == "true") {
				noAuth = "true"
			}
	/*		if($rootScope.appValidity == undefined){
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userDetails") {
					$rootScope.userValidation = cookieAuthParams[cp1].split('=')[1];
					//console.log($rootScope.userValidation.role);
					
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userRole") {
					$rootScope.userRole = cookieAuthParams[cp1].split('=')[1];
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "roleId") {
					$rootScope.roleId = cookieAuthParams[cp1].split('=')[1];
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userName") {
					$rootScope.username = cookieAuthParams[cp1].split('=')[1];
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userFirstName") {
					 $rootScope.userFirstName = cookieAuthParams[cp1].split('=')[1];
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userLastName") {
					$rootScope.userLastName = cookieAuthParams[cp1].split('=')[1];
				}
		  }
		}*/
	if (noAuth == "false") {
			$location.path('/loginPage');
		} 
	if($rootScope.userRole === "TAdmin" || $rootScope.userRole === "PAdmin"){
		document.getElementById("mySidenav").style.display = "none";
		if(document.getElementById("showSubMenu") != null)
		document.getElementById("showSubMenu").style.display = "none";
		document.getElementById("hambrgrCloseMenu").style.display = "none";
		document.getElementById("hambrgrMenu").style.display = "inline-block";
		}
	/*Defining the Patterns for proper input from user*/
	$rootScope.namePattern = "^[a-zA-Z._]+$";
	//$rootScope.projNamePattern = "^[A-Za-z]+(?:[ _-][A-Za-z]+)*$";
	$rootScope.projNamePattern = "[a-zA-Z0-9\\s._&-,]+"; 
	if($scope.showPagination == undefined)
	$scope.showPagination = "false";
	  var params={
              userId: $rootScope.username,
              role: $rootScope.userRole
            
          };

	 $scope.init = function () {
	
		 if($rootScope.scopevalueArrayid == undefined)
			 $rootScope.scopevalueArrayid =[];
		  $scope.isCreateTemplateEnabled = false; 
		 //$rootScope.adminRole == true;

		 if($rootScope.userRole === "PAdmin"){
			 $scope.AddPro_enabled = false;
			  $scope.AssignPro_enabled = false;
			  $scope.DelePro_enabled = false;
			  $scope.modify_enabled = false;
			  $scope.UnAssignPro_enabled = false;   
			  $scope.isCustDestReqEabled=true;//Added by Veena
			  $scope.isCustDestReqb=true;//Added by Veena
			 // $scope.isCustDestReqc=true;//Added by Veena
			  //$scope.isEditPro=false;
			  
		 var paramsData1={		            
				roleId: $rootScope.userRole,
				 sessionInputDTO : $rootScope.sessionInputObj
		        };		 
			 $http.post("/" + servicePrefix + "/rest/authorizationSrv/getAuthorizationIds", paramsData1).then(function(response) {
		        if(response.status === 200){
		        	if(response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
		            	  $rootScope.checkAuthorization();
		              }
		        	else if(response.data.actionIdList != null){
		        		  for (var i = 0,arrLen = response.data.actionIdList.length; i < arrLen; i++) {	
		        		  if(response.data.actionIdList[i]==="AddProject"){
		        				 
		        				 $scope.AddPro_enabled = true;
		        		  }else if(response.data.actionIdList[i]==="DeleteProject"){
		        			  $scope.DelePro_enabled = true;  
		        		  }else if(response.data.actionIdList[i]==="EditProject"){
		        			  $scope.modify_enabled = true;  
		        			 
		        		  } else if(response.data.actionIdList[i]==="AssignProjects"){
		        			   
		        			   $scope.AssignPro_enabled = true;   
			        			
			        	}else if(response.data.actionIdList[i]==="UnAssignProjects"){
		        			   
		        			   $scope.UnAssignPro_enabled = true;   
			        			
			        	}
		        		 /* else if(response.data.actionIdList[i]==="EnableCustomer"){
		        			  $scope.modify_enabled = true;  
		        			  $scope.AddPro_enabled = true;
		        			  $scope.DelePro_enabled = true; 
		        		  }*/
		        		  
		        		 }
		           }
		        } 
		    });
			
			  var inputParam ={
              		userID: $rootScope.username,
              		userRole: $rootScope.userRole,
              		sessionInputDTO: $rootScope.sessionInputObj
                  };
			/* $http.post("/" + servicePrefix + "/rest/customerSrv/displayCustomers",
			            params,  {headers:{
				            'authorization' :  $rootScope.userValidation.userToken
			            }})*/
			  var inputParam ={
	              		userID: $rootScope.username,
	              		userRole: $rootScope.userRole,
	              		sessionInputDTO: $rootScope.sessionInputObj
	                  };
			  $http.post("/" + servicePrefix + "/rest/customerSrv/displayCustomers",inputParam).then(function(response) {
			        if(response.status === 200){
			        	 if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
			            	  $rootScope.checkAuthorization();
			              }
			        	 else if(response.data.customerList != null){
			        		   for(var i=0,arrLen = response.data.customerList.length;i<arrLen;i++){
		                        	if(response.data.customerList[i].trOverride == "F"){
		                        		response.data.customerList[i].trOverride = "Full";
		                        	}else if(response.data.customerList[i].trOverride == "P"){
		                        		response.data.customerList[i].trOverride = "Partial";
		                        	}
		                        	
		                        	if(response.data.customerList[i].status == "Active"){
		                        		response.data.customerList[i].status = "fa fa-check-circle";
		                        	}
		                        	else if(response.data.customerList[i].status == "In Active"){
		                        		response.data.customerList[i].status = "fa fa-times-circle";
		                        	}
		                        	
		                        }
			        		   /////////////////
			        		   
			        		 //Added by Veena
			        		   for(var i=0,arrLen = response.data.customerList.length;i<arrLen;i++){
			        			  
	                        	 if(response.data.customerList[i].custDestReq == "Y")
	                        	 {
	                        		
	                        		 response.data.customerList[i].custDestReq=true;
	                        	} 
	                        	 else 
	                        		 response.data.customerList[i].custDestReq=false;
			        		   }
	                        	//Ended by Veena
			        		   
			        		   /////////////////
			        		   $rootScope.tableClientContent = response.data.customerList;
			        		   $rootScope.temptableClientContent = response.data.customerList;//Added by Veena
			            
			        	  }else{
			        	      ngDialog.openConfirm({
			                      template: '<p>' +"No records found!"+ '</p>',
			                      plain: true,
			                      scope: $scope,
			                      closeByDocument: true,
			                      closeByEscape: true,
			                      showClose: true,
			                      height:120,
			                      width: 350,
			                      className:'ngdialog-theme-default CLASS_2'
			                  });  
			        		  
			        	  }
			        } else {
			        	 $rootScope.tableClientContent="";
			            ngDialog.openConfirm({
		                    template: '<p>' +"No records found!"+ '</p>',
		                    plain: true,
		                    scope: $scope,
		                    closeByDocument: true,
		                    closeByEscape: true,
		                    showClose: true,
		                    height:120,
		                    width: 350,
		                    className:'ngdialog-theme-default CLASS_2'
		                }); 
			        }
			  
			    });
			
		 } 
		 if($rootScope.userRole === "TAdmin"){		
			  $scope.AddPro_enabled = true;
			  $scope.AssignPro_enabled = true;
			  $scope.DelePro_enabled = true;
			  $scope.modify_enabled = true;
			  $scope.UnAssignPro_enabled = true; 
			  
			  $rootScope.createTemplateUser = true;
			  $rootScope.importtempUser = true;
			  $rootScope.downloadtempUser = true;
			 /* $http.post("/" + servicePrefix + "/rest/customerSrv/displayCustomers",
			            params,  {headers:{
				            'authorization' :  $rootScope.userValidation.userToken
			            }})*/
			            
			  var inputParam ={
	              		userID: $rootScope.username,
	              		userRole: $rootScope.userRole,
	              		sessionInputDTO: $rootScope.sessionInputObj
	                  };
			             $http.post("/" + servicePrefix + "/rest/customerSrv/displayCustomers",inputParam).then(function(response) {
			        if(response.status === 200){
			        	if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
			            	  $rootScope.checkAuthorization();
			              }
			        	else if(response.data.customerList != null){
			        		   for(var i=0,arrLen = response.data.customerList.length;i<arrLen;i++){
		                        	if(response.data.customerList[i].trOverride == "F"){
		                        		response.data.customerList[i].trOverride = "Full";
		                        	}else if(response.data.customerList[i].trOverride == "P"){
		                        		response.data.customerList[i].trOverride = "Partial";
		                        	}
		                        	if(response.data.customerList[i].status == "Active"){
		                        		response.data.customerList[i].status = "fa fa-check-circle";
		                        	}
		                        	else if(response.data.customerList[i].status == "In Active"){
		                        		response.data.customerList[i].status = "fa fa-times-circle";
		                        	}
		                        }
			            $rootScope.tableClientContent = response.data.customerList;
			        	  }else{
			        		  $rootScope.tableClientContent="";
			        	      ngDialog.openConfirm({
			                      template: '<p>' +"No records found!"+ '</p>',
			                      plain: true,
			                      scope: $scope,
			                      closeByDocument: true,
			                      closeByEscape: true,
			                      showClose: true,
			                      height:120,
			                      width: 350,
			                      className:'ngdialog-theme-default CLASS_2'
			                  }); 
			        		  
			        	  }
			        } else {
			        	$rootScope.tableClientContent="";
			            ngDialog.openConfirm({
		                    template: '<p>' +"No records found!"+ '</p>',
		                    plain: true,
		                    scope: $scope,
		                    closeByDocument: true,
		                    closeByEscape: true,
		                    showClose: true,
		                    height:120,
		                    width: 350,
		                    className:'ngdialog-theme-default CLASS_2'
		                }); 
			        }
			        if (!$scope.$phase) {

			        //$scope.$apply();
			    }
			    }); 
			 
		 }
    
    
	};

    /********8 Logout ********/
   /* $scope.logout = function(){
        $state.transitionTo('loginPage');
        $rootScope.username = "";
        $rootScope.password = "";
        $rootScope.adminAuth  = "";

        $rootScope.fileUploadAuth = "";
        $rootScope.executeAuth = "";
        $rootScope.configAuth = "";
        $rootScope.fileDownloadAuth = "";
        ngDialog.close();
    }*/


    /*********Add Part********/    
    $scope.openAddDialog = function()
    {
        ngDialog.openConfirm({
            template: 'view/admin/createClient.html?ver='+version,
            controller:'tableClientController',
            scope: $scope,
            closeByDocument: false,
            closeByEscape: false,
            showClose: true,
            height: 480,
            width: 1100
        }).then(function() {
            $scope.createClient();
        });
    };
    $scope.createClient = function(){
        $rootScope.username = $scope.username;
        $rootScope.password = $scope.password;
        $scope.submitted = true;
        var paramsData2={
            customerName: $scope.customerName,
            industryVertical: $scope.industryVertical,
            geographicRegion: $scope.geographicRegion,
            deliveryUnit: $scope.deliveryUnit,
            customerType: $scope.customerType,
            igPoc:$scope.igPoc,
            gdn_ogLead: $scope.gdn_ogLead,
            omId: $scope.omId,
            projectName:$scope.projectName,
            buildtime:$scope.buildtime,
            sessionInputDTO : $rootScope.sessionInputObj	

        };

        $http.post("/" + servicePrefix + "/rest/customerSrv/createCustomer", paramsData2).then(function(response) {
            if(response.status === 200 && response.data.msgType === "Success"){
                ngDialog.close();
                ngDialog.openConfirm({
                    template: '<p>' + response.data.message + '</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                });             
              /*  $http.post("/" + servicePrefix + "/rest/customerSrv/displayCustomers",
			            params,  {headers:{
				            'authorization' :  $rootScope.userValidation.userToken
			            }}).*/
                
                var inputParam ={
                  		userID: $rootScope.username,
                  		userRole: $rootScope.userRole,
                  		sessionInputDTO: $rootScope.sessionInputObj
                      };
                $http.post("/" + servicePrefix + "/rest/customerSrv/displayCustomers",inputParam).then(function(response){
                    if(response.status === 200){
                    	 if(response.data.customerList != null){
                        
                        for(var i=0;i<response.data.customerList.length;i++){
                        	if(response.data.customerList[i].trOverride == "F"){
                        		response.data.customerList[i].trOverride = "Full";
                        	}else if(response.data.customerList[i].trOverride == "P"){
                        		response.data.customerList[i].trOverride = "Partial";
                        	}
                        	if(response.data.customerList[i].status == "Active"){
                        		response.data.customerList[i].status = "fa fa-check-circle";
                        	}
                        	else if(response.data.customerList[i].status == "In Active"){
                        		response.data.customerList[i].status = "fa fa-times-circle";
                        	}
                        }
                        $rootScope.tableClientContent = response.data.customerList;
                      
                    	 }else{
                    	      ngDialog.openConfirm({
                                  template: '<p>' +"No records found!"+ '</p>',
                                  plain: true,
                                  scope: $scope,
                                  closeByDocument: true,
                                  closeByEscape: true,
                                  showClose: true,
                                  height:120,
                                  width: 350,
                                  className:'ngdialog-theme-default CLASS_2'
                              }); 
                    		 
                    	 }
                    } else {
                    	$rootScope.tableClientContent="";
                        ngDialog.openConfirm({
                            template: '<p>' +"No records found!"+ '</p>',
                            plain: true,
                            scope: $scope,
                            closeByDocument: true,
                            closeByEscape: true,
                            showClose: true,
                            height:120,
                            width: 350,
                            className:'ngdialog-theme-default CLASS_2'
                        }); 
                    }
                });
            } else if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
          	  $rootScope.checkAuthorization();
            }
      	 else if(response.status === 200 && response.data.msgType === "Error") {
            	$rootScope.tableClientContent="";
                ngDialog.openConfirm({
                    template: '<p>' + response.data.message + '</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                });
            }
        });
    }


    /*********Edit Part********/
    $scope.modify = function(x){   
     /*   $scope.editClientData.implementationType=x.implementationType;*/
        if($rootScope.userRole === "PAdmin"){ 
        if($scope.modify_enabled===true){
        	   $scope.editClientData = x;
               $scope.editClientData.status=x.status;
              
        $scope.openEditDialog();
        }} 
        if($rootScope.userRole === "TAdmin"){ 
        	   $scope.editClientData = x;
               $scope.editClientData.status=x.status;
               $scope.openEditDialog();	
        	
        }
    };

    $scope.openEditDialog = function()
    {
    	
    	var systemListLength = $rootScope.tableClientContent.length;
    	for(i=0;i<systemListLength;i++){
    	if($rootScope.tableClientContent[i].omId ==  $scope.editClientData.omId)
    	if($rootScope.tableClientContent[i].status == "fa fa-check-circle")
    		$scope.statusEnable = true;
    	else $scope.statusEnable = false;
    	}
        ngDialog.openConfirm({
            template: 'view/admin/editClient.html?ver='+version,
            controller:'tableClientController',
            scope: $scope,
            closeByDocument: false,
            closeByEscape: false,
            showClose: true,
            height: 480,
            width: 1100
        }).then(function() {
            $scope.Update();
        });
        
      /*  if($scope.editClientData.status == "Active"){
        	if(document.getElementById("stsField") != null)
     	   document.getElementById("stsField").checked = true;
     	   }
        
        else {
        	if(document.getElementById("stsField") != null)
        	document.getElementById("stsField").checked = false;
        }*/
    }

    $scope.Update = function(){
        $rootScope.username = $scope.username;
        $rootScope.password = $scope.password;
        $scope.submitted = true;
        var status ="Active";
        if(document.getElementById('stsField').checked)
        	status ="Active"
        else
        	status ="In Active";
       // console.log(status);
        var paramsData3={
            customerName: document.getElementById('custId').value,
            industryVertical: document.getElementById('indusVertical').value,
            geographicRegion: document.getElementById('geoRegion').value,
            deliveryUnit: document.getElementById('geoUnit').value,
            customerType: document.getElementById('cliType').value,
            igPoc: document.getElementById('igPoField').value,
            gdn_ogLead: document.getElementById('gdLead').value,
            omId: document.getElementById('omIdField').value,
            projectName:document.getElementById('projField').value,
            status: status,
            omIdOld: $scope.editClientData.omId,
           buildtime:$scope.editClientData.buildtime,
           /* buildtime:document.getElementById('buildtime').value,*/
            sessionInputDTO: $rootScope.sessionInputObj
        };
        
        $http.put("/" + servicePrefix + "/rest/customerSrv/modifyCustomer",paramsData3).then(function(response) {
            if(response.status===200){
                ngDialog.close();
                ngDialog.open({
                    template: '<p>'+ response.data.message +'',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                });
                /*$http.post("/" + servicePrefix + "/rest/customerSrv/displayCustomers",
			            params,  {headers:{
				            'authorization' :  $rootScope.userValidation.userToken
			            }}).*/
                
                var inputParam ={
                  		userID: $rootScope.username,
                  		userRole: $rootScope.userRole,
                  		sessionInputDTO: $rootScope.sessionInputObj
                      };
			            $http.post("/" + servicePrefix + "/rest/customerSrv/displayCustomers",inputParam).then(function(response){
                    if(response.status === 200){
                    	if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
			            	  $rootScope.checkAuthorization();
			              }
			        	 else if(response.data.customerList != null){
                    		   for(var i=0,arrLen = response.data.customerList.length;i<arrLen;i++){
                               	if(response.data.customerList[i].trOverride == "F"){
                               		response.data.customerList[i].trOverride = "Full";
                               	}else if(response.data.customerList[i].trOverride == "P"){
                               		response.data.customerList[i].trOverride = "Partial";
                               	}
                               	if(response.data.customerList[i].status == "Active"){
	                        		response.data.customerList[i].status = "fa fa-check-circle";
	                        	}
	                        	else if(response.data.customerList[i].status == "In Active"){
	                        		response.data.customerList[i].status = "fa fa-times-circle";
	                        	}
                               }
                        $rootScope.tableClientContent = response.data.customerList;
                    	}else{
                    		$rootScope.tableClientContent="";
                    	      ngDialog.openConfirm({
                                  template: '<p>' +"No records found!"+ '</p>',
                                  plain: true,
                                  scope: $scope,
                                  closeByDocument: true,
                                  closeByEscape: true,
                                  showClose: true,
                                  height:120,
                                  width: 350,
                                  className:'ngdialog-theme-default CLASS_2'
                              }); 
                    	}
                    } else {
                    	$rootScope.tableClientContent="";
                        ngDialog.openConfirm({
                            template: '<p>' +"No records found!"+ '</p>',
                            plain: true,
                            scope: $scope,
                            closeByDocument: true,
                            closeByEscape: true,
                            showClose: true,
                            height:120,
                            width: 350,
                            className:'ngdialog-theme-default CLASS_2'
                        }); 
                    }
                });
            }
            else {
            	$rootScope.tableClientContent="";
            	   ngDialog.openConfirm({
                       template: '<p>' +"No Data found!"+ '</p>',
                       plain: true,
                       scope: $scope,
                       closeByDocument: true,
                       closeByEscape: true,
                       showClose: true,
                       height:120,
                       width: 350,
                       className:'ngdialog-theme-default CLASS_2'
                   }); 
          }
        });
    }

    /*********Delete Part********/

    $scope.isAll = false;
    $scope.selectAllFriends = function () {
        if ($scope.isAll === false) {
            angular.forEach($scope.tableClientContent, function (x) {
                x.checked = true;
            });
            $scope.isAll = true;
        } else {
            angular.forEach($scope.tableClientContent, function (x) {
                x.checked = false;
            });
            $scope.isAll = false;
        }
    };
    
    //Added by Veena
    
    $scope.openDiaFrCustDest = function(customDestReq,omId)
    {
    	$scope.custDestReq = customDestReq;
    	$scope.omId = omId;
    		 ngDialog.openConfirm({
    			 template: 'view/admin/customDestination.html?ver='+version,
    	            controller:'tableClientController',
    	            scope: $scope,
    	            closeByDocument: false,
    	            closeByEscape: false,
    	            showClose: true,
    	            height:160,
                    width: 480,
                    className:'ngdialog-theme-default CLASS_projName'
    	        })
       
    };
    $scope.closeWindow = function()
    {
    	ngDialog.close();
    	 $rootScope.tableClientContent= $rootScope.temptableClientContent;
    	 console.log($rootScope.temptableClientContent);
    	
    }
    
    //
    $scope.custDestDialog = function()
    {
    	 
    	var newCustDestReqList = [];
    	var custDestReqYN="";
    	ngDialog.close();
	        	if ($scope.custDestReq ) {
	        		
	            	newCustDestReqList.push($scope.omId);
	            	custDestReqYN="Y";
	            }
	        	else
	        		{
	        		newCustDestReqList.push($scope.omId);
	            	custDestReqYN="N";
	        		}

    	
    	if(newCustDestReqList.length === 0){
  	   ngDialog.openConfirm({
             template: '<p>' +"Please select atleast One OmId"+ '</p>',
             plain: true,
             scope: $scope,
             closeByDocument: false,
             closeByEscape: true,
             showClose: true,
             height:120,
             width: 350,
             className:'ngdialog-theme-default CLASS_2'
         });
    } 
    	else{
    
    	 var inputParam ={
    			 omidList : newCustDestReqList,
    			 sessionInputDTO: $rootScope.sessionInputObj,
 	    		 custDestReq:custDestReqYN
 	      }
    	
    	$http.post("/" + servicePrefix + "/rest/customerSrv/custDestReg",inputParam).then(function(response){
            if(response.status === 200){
            	if(response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
	            	  $rootScope.checkAuthorization();
	              }
	        	 else{
            		 if(response.data.msgType=="Success"){
            			 ngDialog.openConfirm({
          		             template: '<p>' +response.data.message+ '</p>',
          		             plain: true,
          		             scope: $scope,
          		             closeByDocument: false,
          		             closeByEscape: true,
          		             showClose: true,
          		             height:120,
          		             width: 350,
          		             className:'ngdialog-theme-default CLASS_2'
          		         });
            			 
            		 }
            		 else
            			 {
            			   ngDialog.openConfirm({
          		             template: '<p>' +"Something went wrong.Please try after some time"+ '</p>',
          		             plain: true,
          		             scope: $scope,
          		             closeByDocument: false,
          		             closeByEscape: true,
          		             showClose: true,
          		             height:120,
          		             width: 350,
          		             className:'ngdialog-theme-default CLASS_2'
          		         });
            			 }
            	 }           	
            	
            } 
        });
    	
    }
    	
    }
    //Ended by Veena

    $scope.openDeleteDialog = function()
    {
    	var newDataList = [];
        $scope.selectedAll = false;
        
        angular.forEach($rootScope.tableClientContent, function (checked) {
            if (checked.checked) {
            	
                newDataList.push(checked.omId);
                newDataList.push(checked.status);
            
            }
        });
        if (newDataList.length > 0){       
        	if(newDataList.length === 2){
        	
        	if(newDataList[1]==="In Active"){
     		   ngDialog.openConfirm({
                    template: '<p>' +"Seleted Project Status Already In Active."+ '</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                }); 
        	}else{
        		 ngDialog.openConfirm({
       	            template: 'view/admin/deleteClient.html?ver='+version,
       	            controller:'tableClientController',
       	            scope: $scope,
       	            closeByDocument: false,
       	            closeByEscape: false,
       	            showClose: true,
       	            height: 180,
       	            width: 400,
       	            className:'ngdialog-theme-default CLASS_2'
       	        }).then(function() {
       	            $scope.remove();
       	        }); 
        		
        	}
        	
        	
        	}
        	else if(newDataList.length > 2){      		   
          		   ngDialog.openConfirm({
          	            template: 'view/admin/deleteClient.html?ver='+version,
          	            controller:'tableClientController',
          	            scope: $scope,
          	            closeByDocument: false,
          	            closeByEscape: false,
          	            showClose: true,
          	            height: 150,
          	            width: 350,
          	            className:'ngdialog-theme-default CLASS_2'
          	        }).then(function() {
          	            $scope.remove();
          	        }); 
          		   
          	   }        	
        	
            }   else{
       		ngDialog.openConfirm({
                template: '<p>' +"Please select atleast One OmId"+ '</p>',
                plain: true,
                scope: $scope,
                closeByDocument: true,
                closeByEscape: true,
                showClose: true,
                height:120,
                width: 350,
                className:'ngdialog-theme-default CLASS_2'
            });
    	}
   };
   $scope.openUserProjectsDialog = function()
    {
	   $http.post("/" + servicePrefix + "/rest/userSrv/displayUserIds", $rootScope.sessionInputObj).then(function(response){
           if(response.status === 200){
        	   if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
	            	  $rootScope.checkAuthorization();
	              }
	        	else if(response.data.dataList != null){
               $rootScope.selectUserId = response.data.dataList;
        		}
           } else {
        	   $rootScope.selectUserId="";
        	      ngDialog.openConfirm({
                      template: '<p>' +"No records found!"+ '</p>',
                      plain: true,
                      scope: $scope,
                      closeByDocument: true,
                      closeByEscape: true,
                      showClose: true,
                      height:120,
                      width: 350,
                      className:'ngdialog-theme-default CLASS_2'
                  }); 
           }
       });
	   var newDataList = [];
       $scope.selectedAll = false;
       angular.forEach($rootScope.tableClientContent, function (checked) {
           if (checked.checked) {     	   
               newDataList.push(checked.omId);
              
           }
       });
       if (newDataList.length > 0){
    	   ngDialog.openConfirm({
               template: 'view/admin/assignProjectsToUser.html?ver='+version,
               controller:'tableClientController',
               scope: $scope,
               closeByDocument: true,
               closeByEscape: false,
               showClose: true,
               height: 300,
               width: 800,
               className:'ngdialog-theme-default CLASS_trgSys'
           }).then(function() {
               $scope.createProjectsToUser();
           });
       }
       	else{
       		ngDialog.openConfirm({
                   template: '<p>' +"Please select atleast One OmId"+ '</p>',
                   plain: true,
                   scope: $scope,
                   closeByDocument: false,
                   closeByEscape: true,
                   showClose: true,
                   height:120,
                   width: 350,
                   className:'ngdialog-theme-default CLASS_2'
               });
       	}
       
	   
       
    };
    
    $scope.unAssignUserProjectsDialog = function()
    {
	   $http.post("/" + servicePrefix + "/rest/userSrv/displayUserIds", $rootScope.sessionInputObj).then(function(response){
           if(response.status === 200){
        	   if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
	            	  $rootScope.checkAuthorization();
	              }
        	   else if(response.data.dataList != null){
               $rootScope.selectUserId = response.data.dataList;
        		}
           } else {
        	   $rootScope.selectUserId="";
        	      ngDialog.openConfirm({
                      template: '<p>' +"No records found!"+ '</p>',
                      plain: true,
                      scope: $scope,
                      closeByDocument: true,
                      closeByEscape: true,
                      showClose: true,
                      height:120,
                      width: 350,
                      className:'ngdialog-theme-default CLASS_2'
                  }); 
           }
       });
	   var newDataList = [];
       $scope.selectedAll = false;
       angular.forEach($rootScope.tableClientContent, function (checked) {
           if (checked.checked) {     	   
               newDataList.push(checked.omId);
              
           }
       });
       if (newDataList.length > 0){
    	   ngDialog.openConfirm({
               template: 'view/admin/unAssignProjectsToUser.html?ver='+version,
               controller:'tableClientController',
               scope: $scope,
               closeByDocument: true,
               closeByEscape: false,
               showClose: true,
               height: 300,
               width: 800
           }).then(function() {
               $scope.createProjectsToUser();
           });
       }
       	else{
       		ngDialog.openConfirm({
                   template: '<p>' +"Please select atleast One OmId"+ '</p>',
                   plain: true,
                   scope: $scope,
                   closeByDocument: false,
                   closeByEscape: true,
                   showClose: true,
                   height:120,
                   width: 350,
                   className:'ngdialog-theme-default CLASS_2'
               });
       	}
       
	   
       
    };
    
    $scope.updateUserID = function(typed){
    	if($rootScope.selectUserId != null){
    	  for (var i = 0,arrLen = $rootScope.selectUserId.length; i < arrLen ; i++) {	
    		  if($rootScope.selectUserId[i] === typed){		
	    $scope.newData = $rootScope.selectUserId[i];
	    $scope.newData.then(function(data){
	    	$rootScope.selectUserId = data;
	      
	    });
    		  }
    }
    	}else{
    		$rootScope.selectUserId="";
    	      ngDialog.openConfirm({
                  template: '<p>' +"No records found!"+ '</p>',
                  plain: true,
                  scope: $scope,
                  closeByDocument: true,
                  closeByEscape: true,
                  showClose: true,
                  height:120,
                  width: 350,
                  className:'ngdialog-theme-default CLASS_2'
              }); 
    	}
	};
	  
	 $scope.validate = function(name) {

		 var inputParam = {
				 selectedOmid :  name,
				 sessionInputDTO: $rootScope.sessionInputObj
		 }
		 
	  	  $http.post("/" + servicePrefix + "/rest/customerSrv/validateCustomerId", inputParam).then(function(response){
	            if(response.status === 200){
	            	if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
		            	  $rootScope.checkAuthorization();
		              }
		        	 else if(response.data.dataStatus===true){
	            		  $scope.validMeaggse = "OmId Exists! Please choose another OmId";  
	            		  $timeout(function () { $scope.validMeaggse = ""; }, 2000);   
	            	 }else{
	            		 
	            		 $scope.validMeaggse=""; 
	            	 }           	
	            	
	            } else {
	               
	            }
	        });
	  	
	    };
	    
	    $scope.validate1 = function(name) {    	
	    if($scope.editClientData.omId != document.getElementById('omIdField').value){
	  	  

			 var inputParam = {
					 selectedOmid :  document.getElementById('omIdField').value,
					 sessionInputDTO: $rootScope.sessionInputObj
			 }
	    	$http.post("/" + servicePrefix + "/rest/customerSrv/validateCustomerId",inputParam).then(function(response){
	            if(response.status === 200){
	            	if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
		            	  $rootScope.checkAuthorization();
		              }
		        	 else if(response.data.dataStatus===true  ){
	            		  $scope.validMeaggse = "OmId Exists! Please choose another OmId";  
	            		  $timeout(function () { $scope.validMeaggse = ""; }, 2000);   
	            	 }else{
	            		 
	            		 $scope.validMeaggse=""; 
	            	 }           	
	            	
	            } else {
	               
	            }
	        });
	    }
	  	
	    else{
   		 
   		 $scope.validMeaggse=""; 
   	 	} 
	    
	    };
	    $scope.checkProjectUsers = function(omId)
	    {
	    	  
	    	var inputParam = {
	    			selectedOmid :omId,
	    			sessionInputDTO: $rootScope.sessionInputObj
	    	}
	    	
	    	   $http.post("/" + servicePrefix + "/rest/selectCustomer/projectUsers",inputParam).then(function(response){
                   if(response.status === 200){
                	   if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
			            	  $rootScope.checkAuthorization();
			              }
			        	 else if(response.data.userList != null){
                	   $scope.projectUserData = [];
                       for (var i = 0,arrLen = response.data.userList.length; i < arrLen ; i++) {
       		    		var projectUser ={
       		    			"userId":response.data.userList[i].userId,
       		    			"customerName":response.data.customerName,
       		    			"projectName":response.data.projectName
       		    		 } ;	    		
       		    		 $scope.projectUserData.push(projectUser);
       		    		projectUser={};
       		    	 }
                       
                       if ($scope.projectUserData.length > 0){
                    	   if($scope.projectUserData.length > 5)
                    		   $scope.showPagination = "true";
                    	   else $scope.showPagination = "false";
                    	   ngDialog.openConfirm({
                               template: 'view/admin/viewUserAssignedProjects.html?ver='+version,
                               controller:'tableClientController',
                               scope: $scope,
                               closeByDocument: true,
                               closeByEscape: false,
                               showClose: true,
                               className:'ngdialog-theme-default CLASS_trgSys',
                               height: "auto",
                               width: 500
                           }).then(function() {
                             
                           });
                       }
                      }
                	   else{
                		      ngDialog.openConfirm({
                                  template: '<p>' +"No records found!"+ '</p>',
                                  plain: true,
                                  scope: $scope,
                                  closeByDocument: true,
                                  closeByEscape: true,
                                  showClose: true,
                                  height:120,
                                  width: 350,
                                  className:'ngdialog-theme-default CLASS_2'
                              }); 
                		   
                	   }
                   } else {
                	      ngDialog.openConfirm({
                              template: '<p>' +"No records found!"+ '</p>',
                              plain: true,
                              scope: $scope,
                              closeByDocument: true,
                              closeByEscape: true,
                              showClose: true,
                              height:120,
                              width: 350,
                              className:'ngdialog-theme-default CLASS_2'
                          }); 
                   }
               });
	    	
	
	    };
		 $scope.createProjectsToUser=function(uproj) {
		        var newDataList1 = [];
		        $scope.selectedAll = false;
		        if (uproj != undefined ){
		        	 if (uproj != "" ){
		        	
		        			 var aIndex = $rootScope.selectUserId.indexOf(uproj);	        			
		                     if(aIndex>-1){        	    			  
		      if($rootScope.tableClientContent != null){
		        angular.forEach($rootScope.tableClientContent, function (checked) {
		            if (checked.checked) {
		            	var selectedData = {
		            			"omId":checked.omId,
		            			"projectName":checked.projectName,
		            			"userId":uproj
		                    }; 
		            	 newDataList1.push(selectedData);
		           
		                 selectedData = {};
		            }           
		        });
		        }
		           
		      var inputParam ={
	   	    		  manageProjects : newDataList1,
	   	    		  sessionInputDTO: $rootScope.sessionInputObj
	   	      }
		            $http.post("/" + servicePrefix + "/rest/manageProjectsSrv/assignProjectsToUser",inputParam).then(function(response) {
		          	  
		          	  if(response.status === 200 && response.data.msgType === "Success"){
		                      ngDialog.close();
		                      ngDialog.openConfirm({
		                          template: '<p>' + response.data.message + '</p>',
		                          plain: true,
		                          scope: $scope,
		                          closeByDocument: true,
		                          closeByEscape: true,
		                          showClose: true,
		                          height:120,
		                          width: 350
		                      });
		                    
		                  }else if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
			            	  $rootScope.checkAuthorization();
			              }			        	         	
		                  else if(response.status === 200 && response.data.msgType === "Error"){
		                  	 ngDialog.close();
		                      ngDialog.openConfirm({
		                          template: '<p>' + response.data.message + '</p>',
		                          plain: true,
		                          scope: $scope,
		                          closeByDocument: true,
		                          closeByEscape: true,
		                          showClose: true,
		                          height:120,
		                          width: 350
		                      });
		                  }
		              });
		        	    			  
		        	   }else{
		        	    			  
		        	    	ngDialog.openConfirm({
		        	    	                template: '<p>' + "Please select UserID" + '</p>',
		        	    	                plain: true,
		        	    	                scope: $scope,
		        	    	                closeByDocument: true,
		        	    	                closeByEscape: true,
		        	    	                showClose: true,
		        	    	                height:120,
		        	    	                width: 350
		        	    	            }); 
		        	    			  
		        	    		  }
		        			  
		        		
		        		 
		     	
		        }else{
		            ngDialog.openConfirm({
		                template: '<p>' + "Please select UserID" + '</p>',
		                plain: true,
		                scope: $scope,
		                closeByDocument: true,
		                closeByEscape: true,
		                showClose: true,
		                height:120,
		                width: 350
		            });
		        	
		        }
		       }else{
		    	
		         ngDialog.openConfirm({
		             template: '<p>' + "Please select UserID" + '</p>',
		             plain: true,
		             scope: $scope,
		             closeByDocument: true,
		             closeByEscape: true,
		             showClose: true,
		             height:120,
		             width: 350
		         });
		    	
		    }
		    
		    };
		    
		    $scope.unAssignProjectsToUser=function(uproj) {
		        var newDataList1 = [];
		        $scope.selectedAll = false;
		        if (uproj != undefined ){
		        	 if (uproj != "" ){
		        	
		        			 var aIndex = $rootScope.selectUserId.indexOf(uproj);	        			
		                     if(aIndex>-1){        	    			  
		      if($rootScope.tableClientContent != null){
		        angular.forEach($rootScope.tableClientContent, function (checked) {
		            if (checked.checked) {
		            	var selectedData = {
		            			"omId":checked.omId,
		            			"projectName":checked.projectName,
		            			"userId":uproj
		                    }; 
		            	 newDataList1.push(selectedData);
		           
		                 selectedData = {};
		            }           
		        });
		        }
		         
		      var inputParam ={
	   	    		  manageProjects : newDataList1,
	   	    		  sessionInputDTO: $rootScope.sessionInputObj
	   	      }
		            $http.post("/" + servicePrefix + "/rest/manageProjectsSrv/unAssignProjectsToUser",inputParam).then(function(response) {
		          	  
		          	  if(response.status === 200 && response.data.msgType === "Success"){
		                      ngDialog.close();
		                      ngDialog.openConfirm({
		                          template: '<p>' + response.data.message + '</p>',
		                          plain: true,
		                          scope: $scope,
		                          closeByDocument: true,
		                          closeByEscape: true,
		                          showClose: true,
		                          height:120,
		                          width: 350
		                      });
		                    
		                  }else if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
			            	  $rootScope.checkAuthorization();
			              }
			        	  else if(response.status === 200 && response.data.msgType === "Error"){
		                  	 ngDialog.close();
		                      ngDialog.openConfirm({
		                          template: '<p>' + response.data.message + '</p>',
		                          plain: true,
		                          scope: $scope,
		                          closeByDocument: true,
		                          closeByEscape: true,
		                          showClose: true,
		                          height:120,
		                          width: 350
		                      });
		                  }
		              });
		        	    			  
		        	   }else{
		        	    			  
		        	    	ngDialog.openConfirm({
		        	    	                template: '<p>' + "Please select UserID" + '</p>',
		        	    	                plain: true,
		        	    	                scope: $scope,
		        	    	                closeByDocument: true,
		        	    	                closeByEscape: true,
		        	    	                showClose: true,
		        	    	                height:120,
		        	    	                width: 350
		        	    	            }); 
		        	    			  
		        	    		  }
		        			  
		        		
		        		 
		     	
		        }else{
		            ngDialog.openConfirm({
		                template: '<p>' + "Please select UserID" + '</p>',
		                plain: true,
		                scope: $scope,
		                closeByDocument: true,
		                closeByEscape: true,
		                showClose: true,
		                height:120,
		                width: 350
		            });
		        	
		        }
		       }else{
		    	
		         ngDialog.openConfirm({
		             template: '<p>' + "Please select UserID" + '</p>',
		             plain: true,
		             scope: $scope,
		             closeByDocument: true,
		             closeByEscape: true,
		             showClose: true,
		             height:120,
		             width: 350
		         });
		    	
		    }
		    
		    };
		    
		    
		    $scope.remove = function () {
		        var newDataList = [];
		        $scope.selectedAll = false;
		        angular.forEach($scope.tableClientContent, function (checked) {
		            if (checked.checked) {
		           
		            		   newDataList.push(checked.omId);
		            		   //newDataList.push(checked.status);
		            		   
		            	   }
		            
		        });
		        var selectedData = {
		        		dataList:newDataList,
		        		sessionInputDTO: $rootScope.sessionInputObj
		        }; 
		      
		        $http.put("/" + servicePrefix + "/rest/customerSrv/deleteCustomer",selectedData).then(function(response) {
		            if(response.status === 200 && response.data.msgType === "Success"){
		                ngDialog.close();
		                ngDialog.openConfirm({
		                    template: '<p>' + response.data.message + '</p>',
		                    plain: true,
		                    scope: $scope,
		                    closeByDocument: true,
		                    closeByEscape: true,
		                    showClose: true,
		                    height:120,
		                    width: 350,
		                    className:'ngdialog-theme-default CLASS_2'
		                });
		                var params={
		                        userId: $rootScope.username,
		                        role: $rootScope.userRole,
		                        headers:{
						            'authorization' :  $rootScope.userValidation.userToken
						            }
		                    };
		                /*$http.post("/" + servicePrefix + "/rest/customerSrv/displayCustomers",
					            params,  {headers:{
						            'authorization' :  $rootScope.userValidation.userToken
					            }}).*/
		                var inputParam ={
		                  		userID: $rootScope.username,
		                  		userRole: $rootScope.userRole,
		                  		sessionInputDTO: $rootScope.sessionInputObj
		                      };
		                $http.post("/" + servicePrefix + "/rest/customerSrv/displayCustomers",inputParam).then(function(response){
		                    if(response.status === 200){
		                    	   for(var i=0,arrLen = response.data.customerList.length;i< arrLen ;i++){
		                           	if(response.data.customerList[i].trOverride == "F"){
		                           		response.data.customerList[i].trOverride = "Full";
		                           	}else if(response.data.customerList[i].trOverride == "P"){
		                           		response.data.customerList[i].trOverride = "Partial";
		                           	}
		                           	if(response.data.customerList[i].status == "Active"){
		                        		response.data.customerList[i].status = "fa fa-check-circle";
		                        	}
		                        	else if(response.data.customerList[i].status == "In Active"){
		                        		response.data.customerList[i].status = "fa fa-times-circle";
		                        	}
		                           }
		                    	 
		                        $rootScope.tableClientContent = response.data.customerList;
		                    } else {
		                        ngDialog.openConfirm({
		                            template: '<p>' +"No records found!"+ '</p>',
		                            plain: true,
		                            scope: $scope,
		                            closeByDocument: true,
		                            closeByEscape: true,
		                            showClose: true,
		                            height:120,
		                            width: 350,
		                            className:'ngdialog-theme-default CLASS_2'
		                        }); 
		                    }
		                });
		            }else if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
		            	  $rootScope.checkAuthorization();
		              }
		        	else if(response.status === 200 && response.data.msgType === "Error"){
		                ngDialog.openConfirm({
		                    template: '<p>' + response.data.message + '</p>',
		                    plain: true,
		                    scope: $scope,
		                    closeByDocument: true,
		                    closeByEscape: true,
		                    showClose: true,
		                    height:120,
		                    width: 350,
		                    className:'ngdialog-theme-default CLASS_2'
		                });
		            }
		        });
		        
		 
		    };
		    
		    $scope.toggleStatus = function(status){
		    	console.log(status);
		    };
		    /*$( ".cross" ).hide();
		    $( ".menu" ).hide();
		    $( ".hamburger" ).click(function() {
		    $( ".menu" ).slideToggle( "slow", function() {
		    $( ".hamburger" ).hide();
		    $( ".cross" ).show();
		    });
		    });

		    $( ".cross" ).click(function() {
		    $( ".menu" ).slideToggle( "slow", function() {
		    $( ".cross" ).hide();
		    $( ".hamburger" ).show();
		    });
		    });*/
		   /* $scope.skipSecQA = function()
			{
			 ngDialog.close();
			}*/
		/*	$scope.saveSecQuestions = function(){
				var listOfQuestions = [$rootScope.securityQA.question1,$rootScope.securityQA.question2];
				console.log(listOfQuestions);
				var listOfAnswers = [sha256($rootScope.securityQA.answer1),sha256($rootScope.securityQA.answer2)];
			    var comparray = [];
		   for(i=0;i<listOfAnswers.length;i++){
			   var obj ={};
		           obj.questionId = listOfQuestions[i];
		           obj.ans = listOfAnswers[i];
		           
		       comparray.push(obj);
		   }
				var input = {
						ansListDto : comparray,
						userId: $rootScope.username,
						sessionInputDTO :  $rootScope.sessionInputObj
				}
			
				$http.post("/" + servicePrefix + "/rest/adminSrv/updateSecurityAnswers",input).then(function(response){
			       if(response.data.msgType == "Success")
			  		{
			    	 ngDialog.close();
			    	 	    	
			    	$rootScope.secQAUpdated = true;
			    	
			    	 ngDialog.openConfirm({
		            template: '<p>' + "Your Details are saved succeessfully" +'</p>',
		            plain: true,
		            scope: $scope,
		            closeByDocument: true,
		            closeByEscape: true,
		            showClose: true,
		            height:120,
		            width: 350,
		            className:'ngdialog-theme-default CLASS_2'
		        });
			    	}
			       else {
			    	 ngDialog.close();
			    	 ngDialog.openConfirm({
		             template: '<p>' + "Something went wrong. Please try again with correct details" +'</p>',
		             plain: true,
		             scope: $scope,
		             closeByDocument: true,
		             closeByEscape: true,
		             showClose: true,
		             height:120,
		             width: 350,
		             className:'ngdialog-theme-default CLASS_2'
		         });
			       }
					});
				
			};
*/
		
}]);
