angular.module('yapp').controller('assignUsersToProjectController', ["$scope", "$rootScope", "$state"," $stateParams"," $location","$http", "ngDialog","$ocLazyLoad", function($scope, $rootScope, $state, $stateParams, $location,$http, ngDialog,$ocLazyLoad)  
{
	$ocLazyLoad.load(controllerName+'/admin/assignUsersToProjectController.js?ver='+version);
	var noAuth = "false";
/*
	var cookie = document.cookie;
		var cookieAuthParams = cookie.split(';');*/

			/*if (cookieAuthParams[cp1].split('=')[0].trim() == "adminAuth" && cookieAuthParams[cp1].split('=')[1].trim() == "true") {
				noAuth = "true"
			}*/
			if ($rootScope.adminAuth == "true") {
				noAuth = "true"
			}
	
	if (noAuth == "false") {
			$location.path('/loginPage');
		}
    $scope.createUsertoProjects = function (projUser) {   	
        var newDataList1 = [];
        $scope.selectedAll = false;
        if (projUser != undefined ){
        	   if (projUser != "" ){ 
        		   var aIndex = $rootScope.selectProjects.indexOf(projUser);	        			
                   if(aIndex>-1){

        		var fields = projUser.split('-');
        	    var omId = fields[0];
        	    var projectName = fields[1];
        	    
        	if($rootScope.tableClientContent != null){
        angular.forEach($rootScope.tableUserContent, function (checked) {
            if (checked.checked) {
            	var selectedData = {
            			"userId":checked.userId,
            			"projectName":projectName,
            			"omId":omId
                    }; 
            	 newDataList1.push(selectedData);
           
                 selectedData = {};
            }          
        });
        }    
        	 var inputParam ={
   	    		  manageProjects : newDataList1,
   	    		  sessionInputDTO: $rootScope.sessionInputObj
   	      }
             $http.post("/" + servicePrefix + "/rest/manageProjectsSrv/assignProjectsToUser",inputParam).then(function(response) {
           	 
           	   if(response.status === 200 && response.data.resMessageDto.msgType === "Success"){
                       ngDialog.close();
                       ngDialog.openConfirm({
                           template: '<p>' + response.data.resMessageDto.message + '</p>',
                           plain: true,
                           scope: $scope,
                           closeByDocument: true,
                           closeByEscape: true,
                           showClose: true,
                           height:120,
                           width: 350
                       });
                     
                   }else if(response.status === 200 && response.data.resMessageDto.message === serviceMessage){
	                	  $rootScope.checkAuthorization();
	                  }
                   else if(response.status === 200 && response.data.resMessageDto.msgType === "Error"){
                       ngDialog.openConfirm({
                           template: '<p>'+ response.data.resMessageDto.message +'</p>',
                           plain: true,
                           scope: $scope,
                           closeByDocument: true,
                           closeByEscape: true,
                           showClose: true,
                           height:120,
                           width: 350
                       });
                   }
               });
             
        	   }else{
        		   
        		   ngDialog.openConfirm({
                       template: '<p>' + "Please select Project" + '</p>',
                       plain: true,
                       scope: $scope,
                       closeByDocument: true,
                       closeByEscape: true,
                       showClose: true,
                       height:120,
                       width: 350
                   });
        	   }
             
        }else{
        	  ngDialog.openConfirm({
                  template: '<p>' + "Please select Project" + '</p>',
                  plain: true,
                  scope: $scope,
                  closeByDocument: true,
                  closeByEscape: true,
                  showClose: true,
                  height:120,
                  width: 350
              });
         	
        	
        }
        }else{
    	
         ngDialog.openConfirm({
             template: '<p>' + "Please select Project" + '</p>',
             plain: true,
             scope: $scope,
             closeByDocument: true,
             closeByEscape: true,
             showClose: true,
             height:120,
             width: 350
         });
    	
    }
       
    };
}]);