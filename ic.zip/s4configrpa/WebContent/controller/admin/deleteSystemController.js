angular.module('yapp').controller('deleteSystemController', ["$scope", "$rootScope", "$state"," $stateParams"," $location","$http", "ngDialog","$ocLazyLoad", function($scope, $rootScope, $state, $stateParams, $location,$http, ngDialog,$ocLazyLoad)  
{
	var noAuth = "false"; 
/*
	var cookie = document.cookie;
		var cookieAuthParams = cookie.split(';');*/
		
			/*if (cookieAuthParams[cp1].split('=')[0].trim() == "adminAuth" && cookieAuthParams[cp1].split('=')[1].trim() == "true") {
				noAuth = "true"
			}*/
			if ($rootScope.adminAuth == "true") {
				noAuth = "true"
			}
		
	if (noAuth == "false") {
			$location.path('/loginPage');
		}
	
    $scope.remove = function () {
        var newDataList = [];
        $scope.selectedAll = false;
        angular.forEach($scope.tableContent, function (checked) {
            if (checked.checked) {
                newDataList.push(checked.id);
            }
        });
        var selectedData = {
        	systemIds:newDataList
        }; 
        $http.put("/" + servicePrefix + "/rest/configSrv/delete",selectedData).then(function(response) {
            if(response.status === 200 ){
                ngDialog.close();
                ngDialog.openConfirm({
                    template: '<p>' + response.data.message + '</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                });
                
                var params={
                		userID: $rootScope.username,
                		userRole: $rootScope.userRole,
                		sessionInputDTO: $rootScope.sessionInputObj
        	        };
                
                
                $http.post("/" + servicePrefix + "/rest/configSrv/displayAll",params).then(function(response){
                    if(response.status === 200){
                        $rootScope.tableContent = response.data.systemList;
                    } else {
                        ngDialog.openConfirm({
                            template: '<p>' +"No records found!"+ '</p>',
                            plain: true,
                            scope: $scope,
                            closeByDocument: true,
                            closeByEscape: true,
                            showClose: true,
                            height:120,
                            width: 350,
                            className:'ngdialog-theme-default CLASS_2'
                        }); 
                    }
                });
            }else if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
          	  $rootScope.checkAuthorization();
            }
            else if(response.status === 200 && response.data.status === "Error"){
                ngDialog.openConfirm({
                    template: '<p>' + response.data.message + '</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                });
            }
        });
    };
}]);