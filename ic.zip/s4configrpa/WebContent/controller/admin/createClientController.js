angular.module('yapp').controller('createClientController',["$scope", "$rootScope", "$state"," $stateParams"," $location","$http","$ocLazyLoad", function($scope, $rootScope, $state, $stateParams, $location,$http,$ocLazyLoad)  
{
	$ocLazyLoad.load(controllerName+'/admin/createClientController.js?ver='+version);
    $scope.remove = function(){


        $http.delete("/" + servicePrefix + "/rest/customerSrv/deleteCustomer/"+$scope.tableContent.omId).then(function(response) {
            if(response.status===200){
                $http.get("/" + servicePrefix + "/rest/customerSrv/displayCustomers").then(function(response){
                    if(response.status === 200){
                    	if(response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
                    		  $rootScope.checkAuthorization();
                    	    }
                    	else $scope.tableContent = response.data;
                    } else {
                    	 ngDialog.openConfirm({
                             template: '<p>' + "Something went wrong" + '</p>',
                             plain: true,
                             scope: $scope,
                             closeByDocument: true,
                             closeByEscape: true,
                             showClose: true,
                             height:120,
                             width: 350
                         });
                        //console.log("Error");
                    }
                });
            }
            else {
            //console.log("Error",response);
          }
        });
    }
}]);
