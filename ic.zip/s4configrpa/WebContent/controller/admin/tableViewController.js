/*angular.module('yapp').controller('tableViewController', function($scope, $rootScope, $http, $mdDialog, $mdMedia,$ocLazyLoad) {
	$ocLazyLoad.load(controllerName+'/admin/tableViewController.js?ver='+version);
        $http.get("/" + servicePrefix + "/rest/userSrv/displayAll").then(function(response) {
            if(response.status === 200){
                $scope.tableContent = response.data;
            } else {
                console.log("Error");
            }
            if (!$scope.$$phase) {

            $scope.$apply();
        }
        });
});*/