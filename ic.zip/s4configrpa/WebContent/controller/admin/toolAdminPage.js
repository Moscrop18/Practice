/*angular.module('yapp').controller('toolAdminPageController',function($scope,$rootScope,$http,$mdDialog,$mdMedia,$ocLazyLoad) {
 
	$ocLazyLoad.load(controllerName+'/admin/toolAdminPage.js?ver='+version);


	
	
});*/