/*var app = angular.module('actionApp', []);*/
angular.module('yapp').controller('addAndDeleteAction',["$scope", "$state", "$rootScope", "$http", "$mdDialog", "$mdMedia", "ngDialog", "$location", "$timeout","$ocLazyLoad", function($scope, $state, $rootScope, $http, $mdDialog, $mdMedia, ngDialog, $location, $timeout,$ocLazyLoad) {
	if ($rootScope.adminAuth == "true") {
		noAuth = "true"
	} 
if (noAuth == "false") {
	$location.path('/loginPage');
} 

document.getElementById("hambrgrCloseMenu").style.display = "none";
if(document.getElementById("showSubMenu") != null)
	document.getElementById("showSubMenu").style.display = "none";
document.getElementById("hambrgrMenu").style.display = "inline-block";
document.getElementById("mySidenav").style.display = "none";
$scope.tempAssignedRoles = [];
$scope.tempUnAssignedRoles = [];
$scope.tempRemovedItems = [];
$scope.originalAssignedRoles = [];
$scope.originalUnassignedRoles = [];
$scope.allUnAssignedRoles = [];
$scope.allAssignedRoles = [];
$scope.count = 0;
$scope.count2 = 0;
$scope.disableAll = true;
$scope.enableAll = true;
$scope.counter = 0;
$scope.counter1 = 0;
$scope.selectedRole = "";
$rootScope.unasignedActionid = [];
$rootScope.asignedActionid = [];

$scope.selectRole = function (){
$rootScope.selectedRole = document.getElementById("roles").value;
	var param={
			roleId:$rootScope.selectedRole,
			sessionInputDTO:$rootScope.sessionInputObj
	};
	var paramsData1={		            
			 roleId: $rootScope.selectedRole,
			 sessionInputDTO : $rootScope.sessionInputObj
	       };

	$http.post("/" + servicePrefix + "/rest/authorizationActionSrv/getActionIds",param).then(function(response){
		
		$rootScope.unasignedActionid = response.data.actionIdList;
		if($rootScope.unasignedActionid != null)
		 $scope.counter = $rootScope.unasignedActionid.length;
		//$scope.unAsign1=response.data.actionIdList;
		angular.copy($rootScope.unasignedActionid,$scope.tempUnAssignedRoles);
		angular.copy($rootScope.unasignedActionid,$scope.originalUnassignedRoles);
		
	});
	
     $http.post("/" + servicePrefix + "/rest/authorizationSrv/getAuthorizationIds",paramsData1).then(function(response){
		
		$rootScope.asignedActionid  = response.data.actionIdList;
		if($rootScope.asignedActionid != null)
		 $scope.counter1 = $rootScope.asignedActionid.length;
		//$scope.asign1=response.data.actionIdList;
		angular.copy($rootScope.asignedActionid,$scope.tempAssignedRoles);
		angular.copy($rootScope.asignedActionid,$scope.originalAssignedRoles); 
	});
}; 

     $scope.addActionId = function()
     {
    	if($scope.available == true){
    	 $rootScope.asignedActionid = [];
    	 angular.copy($scope.tempAssignedRoles,$rootScope.asignedActionid);
    	 angular.copy($scope.tempUnAssignedRoles,$rootScope.unasignedActionid);
    	 $scope.selectedAll = false;
    	 $scope.counter = $rootScope.unasignedActionid.length;
    	 $scope.counter1 = $rootScope.asignedActionid.length;
    	}
     };
     
     $scope.removeActionId = function(){
    	 if($scope.available == false){
    	 $rootScope.unasignedActionid = [];
    	 //$rootScope.unasignedActionid = $scope.tempUnAssignedRoles;
    	 angular.copy($scope.tempUnAssignedRoles,$rootScope.unasignedActionid);
    	 angular.copy($scope.tempAssignedRoles,$rootScope.asignedActionid);
    	 $scope.removedAll = false;
    	 $scope.counter = $rootScope.unasignedActionid.length;
    	 $scope.counter1 = $rootScope.asignedActionid.length;
    	 }
     };
    
     $scope.getcheckedValues = function(selectedValue,item){
    	 $scope.available = true;
    	
    	  if (selectedValue) {
    		  $scope.enableAll = false;
    		  $scope.disableAll = true;

	            angular.forEach($rootScope.asignedActionid, function (x) {
	            	//$scope.selected.x = true;
	            	if(document.getElementById(x).checked == true){
	            		if($scope.tempAssignedRoles.indexOf(x) == -1){
	            		$scope.tempAssignedRoles.push(x);
	            		var index = $scope.tempUnAssignedRoles.indexOf(x);
	            		$scope.tempUnAssignedRoles.splice(index,1);
	            		}
	            	}
	            	document.getElementById(x).checked = false;	            	
	            });
    		  //$scope.tempAssignedRoles=[];
    		  for(var a= 0,arrLen = $rootScope.unasignedActionid.length;a< arrLen ;a++){
                  if( $scope.tempUnAssignedRoles[a] == item){
                	  $scope.tempAssignedRoles.push(item);
                	  $scope.tempUnAssignedRoles.splice(a,1);
                	  $scope.count++;
                 }
             }
    		 
    	  }else{
    		  for(var a= 0,arrLen = $rootScope.unasignedActionid.length;a< arrLen ;a++){
                  if( $scope.tempAssignedRoles[a] == item){
                	  $scope.tempUnAssignedRoles.push(item);
                	  $scope.tempAssignedRoles.splice(a,1);                	 
                 }
             }
    	  }    	
     };
     $scope.getcheckedValue = function(selectedValue,item){
    	 $scope.available=false;
    	
   	  if (selectedValue) {
   		 $scope.disableAll = false;
   		 $scope.enableAll = true;
   		 angular.forEach($rootScope.unasignedActionid, function (x) {
          	//$scope.selected.x = true;
   			if(document.getElementById(x).checked == true){
   				if($scope.tempUnAssignedRoles.indexOf(x) == -1){
        		$scope.tempUnAssignedRoles.push(x);
        		var index = $scope.tempAssignedRoles.indexOf(x);
        		$scope.tempAssignedRoles.splice(index,1);
   				}
        	}
   			
          	document.getElementById(x).checked = false;
          });
   		
   		  for(var a= 0,arrLen = $rootScope.asignedActionid.length;a< arrLen ;a++){
                 if($scope.tempAssignedRoles[a] == item){
               	  $scope.tempUnAssignedRoles.push(item);
               	  $scope.tempAssignedRoles.splice(a,1);
               	  $scope.tempRemovedItems.push(item);
               	  $scope.count2++;
                }
            }   		
   	  }  
   	else{
		  for(var a= 0,arrLen = $rootScope.asignedActionid.length;a< arrLen ;a++){
            if( $scope.tempUnAssignedRoles[a] == item){
          	  $scope.tempAssignedRoles.push(item);
          	  $scope.tempUnAssignedRoles.splice(a,1);
          }
       }
	  }  
    };

 $scope.finish = function()
 {
	 var param1 = {
	    		roleId:$rootScope.selectedRole,
	    		actionIds:$rootScope.asignedActionid,
	    		sessionInputDTO:$rootScope.sessionInputObj
	    };
	 $http.post("/" + servicePrefix + "/rest/authorizationActionSrv/addActionIds",param1).then(function(response){
			if(response.status == 200 && response.data.resMessageDto.msgType == 'Success'){
				ngDialog.openConfirm({
             template: '<p>' +"User roles saved sucessfully"+ '</p>',
             plain: true,
             scope: $scope,
             closeByDocument: true,
             closeByEscape: true,
             showClose: true,
             height:120,
             width: 350,
             className:'ngdialog-theme-default CLASS_2'
         });  
				$scope.disableAll = true;
				$scope.enableAll = true;
			}else{
				if(response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
          		  $rootScope.checkAuthorization();
          	    }				
			}
		});
	     
 };
 $scope.cancel = function(){
	 angular.copy($scope.originalAssignedRoles,$rootScope.asignedActionid);
	 angular.copy($scope.originalUnassignedRoles,$rootScope.unasignedActionid);
	
	 angular.copy($rootScope.unasignedActionid,$scope.tempUnAssignedRoles);
	 angular.copy($rootScope.asignedActionid,$scope.tempAssignedRoles);
	 
	 $scope.counter = $rootScope.unasignedActionid.length;
	 $scope.counter1 = $rootScope.asignedActionid.length;
	 $scope.disableAll = true;
	 $scope.enableAll = true;
	
 };
$scope.getValues=function(){
	 $scope.available = true;
		    if ($scope.selectedAll === true) {
			    	 $scope.enableAll=false;
			    	 $scope.disableAll=true;
			    	// $scope.tempAssignedRoles=[];
			            angular.forEach($rootScope.unasignedActionid, function (x) {
			            	
			            	document.getElementById(x).checked=true;		            	
			            });
			            angular.forEach($rootScope.asignedActionid, function (x) {
			            	//$scope.selected.x = true;
			            	document.getElementById(x).checked=false;
			            	
			            });
			          
			            $scope.removedAll=false;
			            for(var a= 0,arrLen = $rootScope.unasignedActionid.length;a< arrLen ;a++){
			                if($scope.tempAssignedRoles.indexOf($rootScope.unasignedActionid[a]) == -1)
			              	  
			                	{
			                	$scope.tempAssignedRoles.push($rootScope.unasignedActionid[a]);
			                	}
			           }
					    $scope.tempUnAssignedRoles=[];
		        } 
		    else {
		            angular.forEach($rootScope.unasignedActionid, function (x) {
		            	document.getElementById(x).checked=false;
		            });
		           angular.copy($rootScope.asignedActionid, $scope.tempAssignedRoles);
		           angular.copy($rootScope.unasignedActionid,$scope.tempUnAssignedRoles);
		      
		        } 
};
 $scope.getValue = function(){
	 $scope.available = false;
	
	
	 if ($scope.removedAll === true) {
				 $scope.disableAll = false;
				 $scope.enableAll = true;
				 //$scope.tempUnAssignedRoles=[];
		         angular.forEach($rootScope.asignedActionid, function (x) {
		         	//$scope.selected.x = true;
		         	document.getElementById(x).checked=true;
		         });
		         angular.forEach($rootScope.unasignedActionid, function (x) {
		          	//$scope.selected.x = true;
		          	document.getElementById(x).checked=false;
		          });
		         $scope.selectedAll = false;
		         for(var a= 0,arrLen = $rootScope.asignedActionid.length;a< arrLen ;a++){
		        	 if($scope.tempUnAssignedRoles.indexOf($rootScope.asignedActionid[a]) == -1)
		             	  {
		          	  $scope.tempUnAssignedRoles.push($rootScope.asignedActionid[a]);
		         	}
		          	 
		       }
		   	 $scope.tempAssignedRoles=[];
     } 
	 else {
	         angular.forEach($rootScope.asignedActionid, function (x) {
	         	document.getElementById(x).checked=false;
	         });
	         angular.copy($rootScope.asignedActionid, $scope.tempAssignedRoles);
	         angular.copy($rootScope.unasignedActionid,$scope.tempUnAssignedRoles);
	         //$scope.selectedAll = false;
     } 
};
}]);