angular.module('yapp').controller('tableSystemController', ["$scope", "$state", "$rootScope", "$http", "$mdDialog", "$mdMedia", "ngDialog", "$location","$ocLazyLoad", function($scope, $state, $rootScope, $http, $mdDialog, $mdMedia, ngDialog, $location,$ocLazyLoad) {
	$ocLazyLoad.load(controllerName+'/admin/tableSystemController.js?ver='+version);
	var noAuth = "false"; 
/*	var cookie = document.cookie;
		var cookieAuthParams = cookie.split(';');
		for (var cp1 = 0,arrLen = cookieAuthParams.length; cp1 < arrLen ; cp1++) {*/
			/*if (cookieAuthParams[cp1].split('=')[0].trim() == "adminAuth" && cookieAuthParams[cp1].split('=')[1].trim() == "true") {
				noAuth = "true"
			}*/
			if ($rootScope.adminAuth == "true") {
				noAuth = "true"
			}
			/*if($rootScope.appValidity == undefined){
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userDetails") {
					$rootScope.userValidation = cookieAuthParams[cp1].split('=')[1];
					console.log($rootScope.userValidation.role);
					
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userRole") {
					$rootScope.userRole = cookieAuthParams[cp1].split('=')[1];
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "roleId") {
					$rootScope.roleId = cookieAuthParams[cp1].split('=')[1];
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userName") {
					$rootScope.username = cookieAuthParams[cp1].split('=')[1];
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userFirstName") {
					 $rootScope.userFirstName = cookieAuthParams[cp1].split('=')[1];
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userLastName") {
					$rootScope.userLastName = cookieAuthParams[cp1].split('=')[1];
				}
		  }
		}*/
	if (noAuth == "false") {
			$location.path('/loginPage');
		}
	
	$scope.editData = {};
	//$scope.statusEnable = true;
	if($rootScope.userRole == "TAdmin" || $rootScope.userRole === "PAdmin"){
		document.getElementById("mySidenav").style.display = "none";
		if(document.getElementById("showSubMenu") != null)
		document.getElementById("showSubMenu").style.display = "none";
		document.getElementById("hambrgrCloseMenu").style.display = "none";
		document.getElementById("hambrgrMenu").style.display = "inline-block";
		}
	 var params={
	            userId: $rootScope.username,
	            userRole: $rootScope.userRole,
	            sessionInputDTO : $rootScope.sessionInputObj
	        };
	 var systemListLength = 0;
	 $scope.init = function () { 
		
		 if($rootScope.userRole === "PAdmin"){
			 
			 $scope.isAddSys = false;		        			
			  $scope.isDelSys = false;
			  $scope.isEditsys = false;
			  $scope.isCloneSys = false;
			  
			  
		 var paramsData1={
				 userID: $rootScope.username,  
				roleId: $rootScope.userRole,
				 sessionInputDTO : $rootScope.sessionInputObj
		           
		        };		 
			 $http.post("/" + servicePrefix + "/rest/authorizationSrv/getAuthorizationIds", paramsData1).then(function(response) {
		        if(response.status === 200){
		        	 if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
		            	  $rootScope.checkAuthorization();
		              }
		        	 else if(response.data.actionIdList != null){
		        		  for (var i = 0,arrLen = response.data.actionIdList.length; i < arrLen ; i++) {	
		        		  if(response.data.actionIdList[i]==="SystemAdd"){
		        			  $scope.isAddSys = true;
		        			  }
		        		  else if(response.data.actionIdList[i]==="SystemDelete"){
		        			  $scope.isDelSys = true;
		        		  }
		        		  else if(response.data.actionIdList[i]==="EditSystem"){
		        			  $scope.isEditsys = true;			        		
		        		  }
		        		  else if(response.data.actionIdList[i]==="CloneSystem"){
		        			  $scope.isCloneSys = true;			        		
		        		  }
		        		  /*else if(response.data.actionIdList[i]==="EnableSystem"){
		        			  $scope.isAddSys = true;
		        			  $scope.isEditsys = true;
		        			  $scope.isDelSys = true;  	        			
		        		  }*/
		        		  }
		           
		        	  }/*else{
		        	      ngDialog.openConfirm({
		                      template: '<p>' +"No records found!"+ '</p>',
		                      plain: true,
		                      scope: $scope,
		                      closeByDocument: true,
		                      closeByEscape: true,
		                      showClose: true,
		                      height:120,
		                      width: 350,
		                      className:'ngdialog-theme-default CLASS_2'
		                  });   
		        		  
		        	  }*/
		        }/* else {
		            ngDialog.openConfirm({
	                    template: '<p>' +"No records found!"+ '</p>',
	                    plain: true,
	                    scope: $scope,
	                    closeByDocument: true,
	                    closeByEscape: true,
	                    showClose: true,
	                    height:120,
	                    width: 350,
	                    className:'ngdialog-theme-default CLASS_2'
	                }); 
		        }*/
		 
		    });
			 var params={
			            userID: $rootScope.username,
			            userRole: $rootScope.userRole,
			            sessionInputDTO : $rootScope.sessionInputObj
			        };
			    $http.post("/" + servicePrefix + "/rest/configSrv/displayAll",params).then(function(response) {
			        if(response.status === 200){
			        	 if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
			            	  $rootScope.checkAuthorization();
			              }
			        	 else if(response.data.systemList != null){
			        		systemListLength = response.data.systemList.length;
			        		 for(var i=0;i<systemListLength;i++){
			        		 if(response.data.systemList[i].status == "Active"){
	                        		response.data.systemList[i].status = "fa fa-check-circle";
	                        	}
	                        	else if(response.data.systemList[i].status == "In Active"){
	                        		response.data.systemList[i].status = "fa fa-times-circle";
	                        	}
			        		 }
			            $rootScope.tableContent = response.data.systemList;
			            for(var i=0,arrLen = $rootScope.tableContent.length; i<arrLen ;i++){
			            	if($rootScope.tableContent[i].isSourceSystem){
			            		$rootScope.tableContent[i].SourceSystem = "glyphicon glyphicon-ok";
			            	}else{
			            		$rootScope.tableContent[i].SourceSystem = "glyphicon glyphicon-remove";
			            	}
			            	
			            	if($rootScope.tableContent[i].isTargetSystem){
			            		$rootScope.tableContent[i].TargetSystem = "glyphicon glyphicon-ok";
			            	}else{
			            		$rootScope.tableContent[i].TargetSystem = "glyphicon glyphicon-remove";
			            	}
			            	if($rootScope.tableContent[i].isHVESSystem){
			            		$rootScope.tableContent[i].HVESSystem = "glyphicon glyphicon-ok";
			            	}else{
			            		$rootScope.tableContent[i].HVESSystem = "glyphicon glyphicon-remove";
			            	}
			            	
			            }
			        	}else{
			        		$rootScope.tableContent="";
			        	      ngDialog.openConfirm({
			                      template: '<p>' +"No records found!"+ '</p>',
			                      plain: true,
			                      scope: $scope,
			                      closeByDocument: true,
			                      closeByEscape: true,
			                      showClose: true,
			                      height:120,
			                      width: 350,
			                      className:'ngdialog-theme-default CLASS_2'
			                  }); 
			        	}
			        } else {
			        	$rootScope.tableContent="";
			            ngDialog.openConfirm({
		                    template: '<p>' +"No records found!"+ '</p>',
		                    plain: true,
		                    scope: $scope,
		                    closeByDocument: true,
		                    closeByEscape: true,
		                    showClose: true,
		                    height:120,
		                    width: 350,
		                    className:'ngdialog-theme-default CLASS_2'
		                }); 
			        }
			   
			    });
		 }if($rootScope.userRole === "TAdmin"){	 
			  $scope.isAddSys = true;		        			
			  $scope.isDelSys = true;
			  $scope.isEditsys = true;
			  $scope.isCloneSys = true;
			  
				 var params={
						 userID: $rootScope.username,
						 userRole: $rootScope.userRole,
						 sessionInputDTO : $rootScope.sessionInputObj
				           
				        };
			    $http.post("/" + servicePrefix + "/rest/configSrv/displayAll",params).then(function(response) {
			        if(response.status === 200){
			        	 if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
			            	  $rootScope.checkAuthorization();
			              }
			        	 else if(response.data.systemList != null){
			        		systemListLength = response.data.systemList.length;
			        		 for(var i=0;i<systemListLength;i++){
			        		 if(response.data.systemList[i].status == "Active"){
	                        		response.data.systemList[i].status = "fa fa-check-circle";
	                        	}
	                        	else if(response.data.systemList[i].status == "In Active"){
	                        		response.data.systemList[i].status = "fa fa-times-circle";
	                        	}
			        		 }
			            $rootScope.tableContent = response.data.systemList;
			            for(var i=0,arrLen = $rootScope.tableContent.length;i< arrLen ;i++){
			            	if($rootScope.tableContent[i].isSourceSystem){
			            		$rootScope.tableContent[i].SourceSystem = "glyphicon glyphicon-ok";
			            	}else{
			            		$rootScope.tableContent[i].SourceSystem = "glyphicon glyphicon-remove";
			            	}
			            	
			            	if($rootScope.tableContent[i].isTargetSystem){
			            		$rootScope.tableContent[i].TargetSystem = "glyphicon glyphicon-ok";
			            	}else{
			            		$rootScope.tableContent[i].TargetSystem = "glyphicon glyphicon-remove";
			            	}
			            	if($rootScope.tableContent[i].isHVESSystem){
			            		$rootScope.tableContent[i].HVESSystem = "glyphicon glyphicon-ok";
			            	}else{
			            		$rootScope.tableContent[i].HVESSystem = "glyphicon glyphicon-remove";
			            	}
			            	
			            }
			        	}else{
			        		$rootScope.tableContent="";
			        	      ngDialog.openConfirm({
			                      template: '<p>' +"No records found!"+ '</p>',
			                      plain: true,
			                      scope: $scope,
			                      closeByDocument: true,
			                      closeByEscape: true,
			                      showClose: true,
			                      height:120,
			                      width: 350,
			                      className:'ngdialog-theme-default CLASS_2'
			                  }); 
			        	}
			        } else {
			        	$rootScope.tableContent="";
			            ngDialog.openConfirm({
		                    template: '<p>' +"No records found!"+ '</p>',
		                    plain: true,
		                    scope: $scope,
		                    closeByDocument: true,
		                    closeByEscape: true,
		                    showClose: true,
		                    height:120,
		                    width: 350,
		                    className:'ngdialog-theme-default CLASS_2'
		                }); 
			        }
			   
			    });	 
			 
			 
		 }

	 };

	  $scope.getMappedTargetSystems = function(){
		  
		/*  if($scope.isHVESSystem == 1){
		  		$scope.system = "source";
		  		$scope.trgDisable = true;
		  	}
		  	else{
		  		$scope.trgDisable = false;
		  		$scope.system = "";
		  	} */
		  
		  var params={
		           /* userId: $rootScope.username,
		            role: $rootScope.userRole,*/
		            //isHvesSystem: $scope.isHVESSystem==undefined?0:$scope.isHVESSystem,
		            omID : $scope.selectedCustomerId,
		            sessionInputDTO : $rootScope.sessionInputObj
		            		
		        };
	$http.post("/" + servicePrefix + "/rest/configSrv/displayTargetSystems",params).then(function(response) {
      $scope.TargetSystems=response.data.dataList;
		});
		 
	 };
	 
	  $scope.setMappedTargetSystemFlag = function(){
		  
		
		
		  if($rootScope.editSystemData.system == "source"){
			  $scope.getMappedTargetSystems();
			  $rootScope.mappedtargetSystem = true;

		  }
		  else
			  $rootScope.mappedtargetSystem = false;

	 };
	 
	 
    $scope.editingData = {};

    $scope.modify = function(x){ 
    	
    	$scope.getMappedTargetSystems();
    	
        if($rootScope.userRole === "PAdmin"){ 
       if($scope.isEditsys === true){
    	   
    	   $rootScope.editSystemData = x;
    	   
           $rootScope.editSystemData.systemType=x.systemType;
           $rootScope.editSystemData.isSourceSystem=x.isSourceSystem;
           $rootScope.editSystemData.isHVESSystem = x.isHVESSystem;
           
           if($rootScope.editSystemData.isSourceSystem == 1){
  			  $rootScope.mappedtargetSystem = true;
  			  $rootScope.editSystemData.system="source";
           }
  		  else{
  			  $rootScope.mappedtargetSystem = false;
  			  $rootScope.editSystemData.system="target"	;
  		  }

           if($rootScope.editSystemData.isHVESSystem == 1)
       	{
       	
       	$rootScope.editSystemData.isHVESSystem = 1;
       	}else{
       		$rootScope.editSystemData.isHVESSystem = 0;
       		
       	}
          
           $rootScope.editSystemData.status=x.status;
        $scope.openEditDialog();
        
       }}else{
    	   $rootScope.editSystemData = x;
           $rootScope.editSystemData.systemType=x.systemType;
           $rootScope.editSystemData.isSourceSystem=x.isSourceSystem;
           $rootScope.editSystemData.isHVESSystem = x.isHVESSystem;
           
           if($rootScope.editSystemData.isSourceSystem == 1){
   			  $rootScope.mappedtargetSystem = true;
   			  $rootScope.editSystemData.system="source";
            }
   		  else{
   			  $rootScope.mappedtargetSystem = false;
   			  $rootScope.editSystemData.system="target"	;
   		  }
           if($rootScope.editSystemData.isHVESSystem === 1)
       	{
       	
       	$rootScope.editSystemData.isHVESSystem = 1;
       	}else{
       		$rootScope.editSystemData.isHVESSystem = 0;	
       		
       	}     
           $rootScope.editSystemData.status=x.status;
    	   $scope.openEditDialog();
       }
    };
    
$scope.cloneSystem = function(x){ 
    	
    	$scope.getMappedTargetSystems();
    	
        if($rootScope.userRole === "PAdmin"){ 
       if($scope.isCloneSys === true){
    	   $rootScope.editSystemData = x;
    	   $rootScope.editSystemData.systemType=x.systemType;
           $rootScope.editSystemData.isSourceSystem=x.isSourceSystem;
           $rootScope.editSystemData.isHVESSystem = x.isHVESSystem;
           $rootScope.editSystemData.systemNo=x.systemNo;
           
           if($rootScope.editSystemData.isSourceSystem == 1){
  			  $rootScope.mappedtargetSystem = true;
  			  $rootScope.editSystemData.system="source";
           }
  		  else{
  			  $rootScope.mappedtargetSystem = false;
  			  $rootScope.editSystemData.system="target"	;
  		  }

           if($rootScope.editSystemData.isHVESSystem == 1)
       	{
       	
       	$rootScope.editSystemData.isHVESSystem = 1;
       	}else{
       		$rootScope.editSystemData.isHVESSystem = 0;
       		
       	}
          
           $rootScope.editSystemData.status=x.status;
        /*$scope.openEditDialog();*/
           $scope.openSystemCloneDialog();
       }}else{
    	   $rootScope.editSystemData = x;
           $rootScope.editSystemData.systemType=x.systemType;
           $rootScope.editSystemData.isSourceSystem=x.isSourceSystem;
           $rootScope.editSystemData.isHVESSystem = x.isHVESSystem;
           $rootScope.editSystemData.systemNo=x.systemNo;
           
           if($rootScope.editSystemData.isSourceSystem == 1){
   			  $rootScope.mappedtargetSystem = true;
   			  $rootScope.editSystemData.system="source";
            }
   		  else{
   			  $rootScope.mappedtargetSystem = false;
   			  $rootScope.editSystemData.system="target"	;
   		  }
           if($rootScope.editSystemData.isHVESSystem === 1)
       	{
       	
       	$rootScope.editSystemData.isHVESSystem = 1;
       	}else{
       		$rootScope.editSystemData.isHVESSystem = 0;	
       		
       	}     
           $rootScope.editSystemData.status=x.status;
    	   $scope.openSystemCloneDialog();
       }
    };
    
    $scope.openAddDialog = function()
    {
    	$scope.getMappedTargetSystems();
    	$http.post("/" + servicePrefix + "/rest/customerSrv/displayClientIds", $rootScope.sessionInputObj).then(function(response) {
    	$scope.CustomerId=response.data.dataList;
    	
        ngDialog.openConfirm({
            template: 'view/admin/createSystem1.html?ver='+version,
            controller:'tableSystemController',
            scope: $scope,
            closeByDocument: false,
            closeByEscape: false,
            showClose: true,
            height: 700,
            width: 1100
        }).then(function() {
            $scope.createSystem();
        });
    	});
    	//});
    }
    
    $scope.createSystem = function(){
    	 var ids = $scope.selectedCustomerId;
         var idData = ids.split('-');
         
     	var omId = idData[1];
     	  var iv = CryptoJS.lib.WordArray.random(128/8).toString(CryptoJS.enc.Hex);
          var salt = CryptoJS.lib.WordArray.random(128/8).toString(CryptoJS.enc.Hex);

          var aesUtil = new AesUtil(128, 1000);
          var encryptedSapPassword = aesUtil.encrypt(salt, iv, $scope.destinationName, $scope.password);
          var aesSapPassword = (iv + "::" + salt + "::" + encryptedSapPassword);
          $scope.encryptedSapPassword = btoa(aesSapPassword);
          if($scope.systemType==undefined)
          {
        	  $scope.systemType="S4 HANA"; 
          }
        var paramsData2={
        		omId: $scope.selectedCustomerId,
        		hostName: $scope.hostName,
        		systemNo: $scope.systemNo,
        		systemId: $scope.systemId,
        		sapClientNo: $scope.sapClientNo,
        		isHVESSystem: $scope.isHVESSystem,
        		sncEnabled: $scope.sncEnabled,
        		sncName: $scope.sncName,
        		sncPartnerName: $scope.sncPartnerName,
        		sapRouter: $scope.sapRouter,
        		sncProtectionLevel: $scope.sncProtectionLevel,
        		language: $scope.language,
        		systemType: $scope.systemType,
        		system: $scope.system,
//        		mappedTargetSystem: ($scope.system) == "source" ?$scope.selectedMappedTargetSystem:0,
        		status: $scope.status,
        		destinationName: $scope.destinationName,
        		userId:$scope.userId,
        		password:$scope.encryptedSapPassword,
        		description:$scope.description,
        		id : 0,
        		sessionInputDTO : $rootScope.sessionInputObj
            };

       
        
        $http.post("/" + servicePrefix + "/rest/configSrv/add", paramsData2).then(function(response) {
            if(response.status===200 && response.data.msgType != "DBERROR"){
            	  ngDialog.close();
                ngDialog.open({
                    template: '<p>'+ response.data.message +'',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true
                });
                
                var params={
			            
						 userRole: $rootScope.userRole,
						 sessionInputDTO : $rootScope.sessionInputObj
				           
				        };
                $http.post("/" + servicePrefix + "/rest/configSrv/displayAll",params).then(function(response) {
                    if(response.status === 200){
                    	if(response.data.systemList != null){
                    		systemListLength = response.data.systemList.length;
			        		 for(var i=0;i<systemListLength;i++){
                    		 if(response.data.systemList[i].status == "Active"){
	                        		response.data.systemList[i].status = "fa fa-check-circle";
	                        	}
	                        	else if(response.data.systemList[i].status == "In Active"){
	                        		response.data.systemList[i].status = "fa fa-times-circle";
	                        	}
			        		 }
                        $rootScope.tableContent = response.data.systemList;
                        for(var i=0,arrLen = $rootScope.tableContent.length;i< arrLen ;i++){
                        	if($rootScope.tableContent[i].isSourceSystem){
                        		$rootScope.tableContent[i].SourceSystem = "glyphicon glyphicon-ok";
                        	}else{
                        		$rootScope.tableContent[i].SourceSystem = "glyphicon glyphicon-remove";
                        	}
                        	
                        	if($rootScope.tableContent[i].isTargetSystem){
                        		$rootScope.tableContent[i].TargetSystem = "glyphicon glyphicon-ok";
                        	}else{
                        		$rootScope.tableContent[i].TargetSystem = "glyphicon glyphicon-remove";
                        	}
                        	if($rootScope.tableContent[i].isHVESSystem){
                        		$rootScope.tableContent[i].HVESSystem = "glyphicon glyphicon-ok";
                        	}else{
                        		$rootScope.tableContent[i].HVESSystem = "glyphicon glyphicon-remove";
                        	}
                        } 
                        
                    	}else
                    			
                    	{
                    		$rootScope.tableContent="";
                    	      ngDialog.openConfirm({
                                  template: '<p>' +"No records found!"+ '</p>',
                                  plain: true,
                                  scope: $scope,
                                  closeByDocument: true,
                                  closeByEscape: true,
                                  showClose: true,
                                  height:120,
                                  width: 350,
                                  className:'ngdialog-theme-default CLASS_2'
                              }); 
                    	}
                    } else {
                    	$rootScope.tableContent="";
                        ngDialog.openConfirm({
                            template: '<p>' +"No records found!"+ '</p>',
                            plain: true,
                            scope: $scope,
                            closeByDocument: true,
                            closeByEscape: true,
                            showClose: true,
                            height:120,
                            width: 350,
                            className:'ngdialog-theme-default CLASS_2'
                        }); 
                    }
              
                });
            }else if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
          	  $rootScope.checkAuthorization();
            }      	
            else if(response.status===200 && response.data.status == "DBERROR"){
            	$rootScope.tableContent="";
          	  ngDialog.close();
              ngDialog.open({
                  template: '<p>'+ response.data.message +'',
                  plain: true,
                  scope: $scope,
                  closeByDocument: true,
                  closeByEscape: true,
                  showClose: true,
                  height:120,
                  width: 350,
                  className:'ngdialog-theme-default CLASS_2'
              });
          }
            else {
            	$rootScope.tableContent="";
                ngDialog.openConfirm({
                    template: '<p>' +"No records found!"+ '</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                }); 
          }
            
        
        },function (data, status, headers, config, statusText)  // renamed "error" to "data" based on documentation
                {

                    deferred.reject(status);
                });
        
    }
    $scope.openEditDialog = function()
    {
    	$http.post("/" + servicePrefix + "/rest/customerSrv/displayClientIds", $rootScope.sessionInputObj).then(function(response) {
    	$scope.CustomerId=response.data.dataList;
    	
    	systemListLength = $rootScope.tableContent.length;
    	for(i=0;i<systemListLength;i++){
    	if($rootScope.tableContent[i].omId ==  $rootScope.editSystemData.omId/* && $rootScope.tableContent[i].hostName == $rootScope.editSystemData.hostName*/)
    	if($rootScope.tableContent[i].status == "fa fa-check-circle")
    		$scope.statusEnable = true;
    	else $scope.statusEnable = false;
    	}
    		/* var params={
 		            userId: $rootScope.username,
 		            role: $rootScope.userRole,
 		        };
    	$http.post("/" + servicePrefix + "/rest/configSrv/displayTargetSystems",params).then(function(response) {*/
        // $scope.TargetSystems=response.data.targetSystems;
        ngDialog.openConfirm({
            template: 'view/admin/editSystem.html?ver='+version,
            controller:'tableSystemController',
            scope: $scope,
            closeByDocument: false,
            closeByEscape: false,
            showClose: true,
            height: 450,
            width: 1100
        }).then(function() {
            $scope.Update();
        });
    	 });
    	 //});
    };
    
    $scope.openSystemCloneDialog = function()
    {
    	$http.post("/" + servicePrefix + "/rest/customerSrv/displayClientIds", $rootScope.sessionInputObj).then(function(response) {
    	$scope.CustomerId=response.data.dataList;
    	
    	systemListLength = $rootScope.tableContent.length;
    	for(i=0;i<systemListLength;i++){
    		if($rootScope.tableContent[i].omId ==  $rootScope.editSystemData.omId /*&& $rootScope.tableContent[i].hostName == $rootScope.editSystemData.hostName*/)
    			if($rootScope.tableContent[i].status == "fa fa-check-circle")
    				$scope.statusEnable = true;
    			else $scope.statusEnable = false;
    	}
    		/* var params={
 		            userId: $rootScope.username,
 		            role: $rootScope.userRole,
 		        };
    	$http.post("/" + servicePrefix + "/rest/configSrv/displayTargetSystems",params).then(function(response) {*/
        // $scope.TargetSystems=response.data.targetSystems;
        ngDialog.openConfirm({
            template: 'view/admin/cloneSystem.html?ver='+version,
            controller:'tableSystemController',
            scope: $scope,
            closeByDocument: false,
            closeByEscape: false,
            showClose: true,
            height: 450,
            width: 1100
        }).then(function() {
            $scope.cloneSystemSave();
        });
    	 });
    	 //});
    };
    
    $scope.Update = function(){
        $rootScope.username = $scope.username;
        $rootScope.password = $scope.password;
        $scope.submitted = true;
        var ids = document.getElementById('clntId').value;
        var idData = ids.split('-');
        
    	var omId = idData[1];
    	  var status ="Active";
          if(document.getElementById('stsField').checked)
          	status ="Active"
          else
          	status ="In Active";
          
        var paramsData4={
        	description: document.getElementById('description').value,
        	omId: document.getElementById('clntId').value,
//        	hostName: document.getElementById('hostName').value,
        	systemId: document.getElementById('systemId').value,
//    		systemNo: document.getElementById('systemNo').value,
    		sapClientNo: document.getElementById('sapClientNo').value,
//    		language: document.getElementById('language').value,
    		systemType: $rootScope.editSystemData.systemType,
    		isHVESSystem: $rootScope.editSystemData.isHVESSystem,
    		system: $rootScope.editSystemData.system,
//    		mappedTargetSystem: ($rootScope.editSystemData.system) == "source" ?document.getElementById('mappedTargetSystem').value == "" ? $rootScope.editSystemData.mappedTargetSystem:document.getElementById('mappedTargetSystem').value :0,
    		status: status,
    		destinationName: document.getElementById('destinationName').value,
    		id :$rootScope.editSystemData.id,
    		sessionInputDTO : $rootScope.sessionInputObj
        };// values to be replaced
        $http.put("/" + servicePrefix + "/rest/configSrv/update", paramsData4).then(function(response) {
        	   if(response.status===200){
                   ngDialog.close();
                   ngDialog.openConfirm({
                       template:  '<p>' + response.data.message + '</p>',
                       plain: true,
                       scope: $scope,
                       closeByDocument: true,
                       closeByEscape: true,
                       showClose: true,
                       height:120,
                       width: 350,
                       className:'ngdialog-theme-default CLASS_2'
                   });
                    
                   var params={
				            
  						 userRole: $rootScope.userRole,
  						 sessionInputDTO : $rootScope.sessionInputObj
  				           
  				        };
                   $http.post("/" + servicePrefix + "/rest/configSrv/displayAll",params).then(function(response) {
                       if(response.status === 200){
                    	   if(response.data.systemList != null){
                    			systemListLength = response.data.systemList.length;
   			        		 for(var i=0;i<systemListLength;i++){
                    		   if(response.data.systemList[i].status == "Active"){
	                        		response.data.systemList[i].status = "fa fa-check-circle";
	                        	}
	                        	else if(response.data.systemList[i].status == "In Active"){
	                        		response.data.systemList[i].status = "fa fa-times-circle";
	                        	}
   			        		 }
                           $rootScope.tableContent = response.data.systemList;
                           for(var i=0,arrLen = $rootScope.tableContent.length;i< arrLen ;i++){
                           	if($rootScope.tableContent[i].isSourceSystem){
                           		$rootScope.tableContent[i].SourceSystem = "glyphicon glyphicon-ok";
                           	}else{
                           		$rootScope.tableContent[i].SourceSystem = "glyphicon glyphicon-remove";
                           	}
                           	
                           	if($rootScope.tableContent[i].isTargetSystem){
                           		$rootScope.tableContent[i].TargetSystem = "glyphicon glyphicon-ok";
                           	}else{
                           		$rootScope.tableContent[i].TargetSystem = "glyphicon glyphicon-remove";
                           	}
                           	if($rootScope.tableContent[i].isHVESSystem){
                           		$rootScope.tableContent[i].HVESSystem = "glyphicon glyphicon-ok";
                           	}else{
                           		$rootScope.tableContent[i].HVESSystem = "glyphicon glyphicon-remove";
                           	}
                           	
                           } 
                    	   }else{
                    		   $rootScope.tableContent="";
                    		      ngDialog.openConfirm({
                                      template: '<p>' +"No records found!"+ '</p>',
                                      plain: true,
                                      scope: $scope,
                                      closeByDocument: true,
                                      closeByEscape: true,
                                      showClose: true,
                                      height:120,
                                      width: 350,
                                      className:'ngdialog-theme-default CLASS_2'
                                  }); 
                    	   }
                       } else {
                    	   $rootScope.tableContent="";
                    	      ngDialog.openConfirm({
                                  template: '<p>' +"No records found!"+ '</p>',
                                  plain: true,
                                  scope: $scope,
                                  closeByDocument: true,
                                  closeByEscape: true,
                                  showClose: true,
                                  height:120,
                                  width: 350,
                                  className:'ngdialog-theme-default CLASS_2'
                              }); 
                       }
                  
                   });
               }else if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
	            	  $rootScope.checkAuthorization();
	              }
	        	else {
            	   $rootScope.tableContent="";
            	     ngDialog.openConfirm({
                         template: '<p>' +"No Data found!"+ '</p>',
                         plain: true,
                         scope: $scope,
                         closeByDocument: true,
                         closeByEscape: true,
                         showClose: true,
                         height:120,
                         width: 350,
                         className:'ngdialog-theme-default CLASS_2'
                     }); 
             }
        });
    };
    
  /*  $rootScope.clearDestinationName = function(){
    	document.getElementById('destinationName').value = '';
    };*/
    
    $scope.cloneSystemSave = function(){
        $rootScope.username = $scope.username;
        $rootScope.password = $scope.password;
        $scope.submitted = true;
        var status ="Active";
        if(document.getElementById('stsField').checked)
        	status ="Active"
        else
        	status ="In Active";
        
    	var omId = $scope.selectedCustomerId;
    	/*if($rootScope.editSystemData.omId == $scope.selectedCustomerId){
    		ngDialog.openConfirm({
                template:  '<p> Destination already exists for the selected client </p>',
                plain: true,
                scope: $scope,
                closeByDocument: true,
                closeByEscape: true,
                showClose: true,
                height:120,
                width: 350,
                className:'ngdialog-theme-default CLASS_2'
            });
    	}*/
    	//else{
    	
          
        var paramsData4={
        	description: document.getElementById('description').value,
        	omId: $scope.selectedCustomerId,
        	systemId: $rootScope.editSystemData.systemId,
    		sapClientNo: $rootScope.editSystemData.sapClientNo,
    		systemType: $rootScope.editSystemData.systemType,
    		isHVESSystem: $rootScope.editSystemData.isHVESSystem,
    		system: $rootScope.editSystemData.system,
    		systemNo:$rootScope.editSystemData.systemNo,
    		status: status,
    		destinationName: document.getElementById('destinationName').value,
    		sessionInputDTO : $rootScope.sessionInputObj
    		//id :$rootScope.editSystemData.id
        };// values to be replaced
        $http.post("/" + servicePrefix + "/rest/configSrv/cloneSystem", paramsData4).then(function(response) {
        	   if(response.status===200){
                   ngDialog.close();
                   ngDialog.openConfirm({
                       template:  '<p>' + response.data.message + '</p>',
                       plain: true,
                       scope: $scope,
                       closeByDocument: true,
                       closeByEscape: true,
                       showClose: true,
                       height:120,
                       width: 350,
                       className:'ngdialog-theme-default CLASS_2'
                   });
                    
                   var params={
                		  userID: $rootScope.username,
  						 userRole: $rootScope.userRole,
  						 sessionInputDTO : $rootScope.sessionInputObj
  				           
  				        };
                   $http.post("/" + servicePrefix + "/rest/configSrv/displayAll",params).then(function(response) {
                       if(response.status === 200){
                    	   if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
     		            	  $rootScope.checkAuthorization();
     		              }
     		        	 else if(response.data.systemList != null){
                    			systemListLength = response.data.systemList.length;
   			        		 for(var i=0;i<systemListLength;i++){
                    		   if(response.data.systemList[i].status == "Active"){
	                        		response.data.systemList[i].status = "fa fa-check-circle";
	                        	}
	                        	else if(response.data.systemList[i].status == "In Active"){
	                        		response.data.systemList[i].status = "fa fa-times-circle";
	                        	}
   			        		 }
                           $rootScope.tableContent = response.data.systemList;
                           for(var i=0,arrLen = $rootScope.tableContent.length;i< arrLen ;i++){
                           	if($rootScope.tableContent[i].isSourceSystem){
                           		$rootScope.tableContent[i].SourceSystem = "glyphicon glyphicon-ok";
                           	}else{
                           		$rootScope.tableContent[i].SourceSystem = "glyphicon glyphicon-remove";
                           	}
                           	
                           	if($rootScope.tableContent[i].isTargetSystem){
                           		$rootScope.tableContent[i].TargetSystem = "glyphicon glyphicon-ok";
                           	}else{
                           		$rootScope.tableContent[i].TargetSystem = "glyphicon glyphicon-remove";
                           	}
                           	if($rootScope.tableContent[i].isHVESSystem){
                           		$rootScope.tableContent[i].HVESSystem = "glyphicon glyphicon-ok";
                           	}else{
                           		$rootScope.tableContent[i].HVESSystem = "glyphicon glyphicon-remove";
                           	}
                           	
                           } 
                    	   }else{
                    		   $rootScope.tableContent="";
                    		      ngDialog.openConfirm({
                                      template: '<p>' +"No records found!"+ '</p>',
                                      plain: true,
                                      scope: $scope,
                                      closeByDocument: true,
                                      closeByEscape: true,
                                      showClose: true,
                                      height:120,
                                      width: 350,
                                      className:'ngdialog-theme-default CLASS_2'
                                  }); 
                    	   }
                       } else {
                    	   $rootScope.tableContent="";
                    	      ngDialog.openConfirm({
                                  template: '<p>' +"No records found!"+ '</p>',
                                  plain: true,
                                  scope: $scope,
                                  closeByDocument: true,
                                  closeByEscape: true,
                                  showClose: true,
                                  height:120,
                                  width: 350,
                                  className:'ngdialog-theme-default CLASS_2'
                              }); 
                       }
                 
                   });
               }
               else {
            	   $rootScope.tableContent="";
            	     ngDialog.openConfirm({
                         template: '<p>' +"No Data found!"+ '</p>',
                         plain: true,
                         scope: $scope,
                         closeByDocument: true,
                         closeByEscape: true,
                         showClose: true,
                         height:120,
                         width: 350,
                         className:'ngdialog-theme-default CLASS_2'
                     }); 
             }
        });
        
    	//}
    }

    /*********Delete Part********/

    $scope.isAll = false;
    $scope.selectAllFriends = function () {
        if ($scope.isAll === false) {
            angular.forEach($scope.tableContent, function (x) {
                x.checked = true;
            });
            $scope.isAll = true;
        } else {
            angular.forEach($scope.tableContent, function (x) {
                x.checked = false;
            });
            $scope.isAll = false;
        }
    };

    $scope.openDeleteDialog = function()
    {
    	
    	var newDataList = [];
        $scope.selectedAll = false;
        angular.forEach($rootScope.tableContent, function (checked) {
            if (checked.checked) {
            	
                newDataList.push(checked.omId);
                newDataList.push(checked.status);
            
            }
        });
        if (newDataList.length > 0){       
        	if(newDataList.length === 2){
        	
        	if(newDataList[1]==="In Active"){
     		   ngDialog.openConfirm({
                    template: '<p>' +"Seleted System Status Already In Active."+ '</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                }); 
        	}else{
        		 ngDialog.openConfirm({
       	            template: 'view/admin/deleteSystem.html?ver='+version,
       	            controller:'tableSystemController',
       	            scope: $scope,
       	            closeByDocument: false,
       	            closeByEscape: false,
       	            showClose: true,
       	            height: 180,
       	            width: 400,
       	            className:'ngdialog-theme-default CLASS_2'
       	        }).then(function() {
       	            $scope.remove();
       	        }); 
        		
        	}
        	
        	
        	}
        	else if(newDataList.length > 2){      		   
          		   ngDialog.openConfirm({
          	            template: 'view/admin/deleteSystem.html?ver='+version,
          	            controller:'tableSystemController',
          	            scope: $scope,
          	            closeByDocument: false,
          	            closeByEscape: false,
          	            showClose: true,
          	            height: 150,
          	            width: 350,
          	            className:'ngdialog-theme-default CLASS_2'
          	        }).then(function() {
          	            $scope.remove();
          	        }); 
          		   
          	   }        	
        	
            }   
     	   
     
        	else{
       		ngDialog.openConfirm({
                template: '<p>' +"Please select atleast One OmId"+ '</p>',
                plain: true,
                scope: $scope,
                closeByDocument: true,
                closeByEscape: true,
                showClose: true,
                height:120,
                width: 350,
                className:'ngdialog-theme-default CLASS_2'
            });
    	}
    
  
    };
    
    $scope.remove = function () {
        var newDataList = [];
        $scope.selectedAll = false;
        angular.forEach($scope.tableContent, function (checked) {
            if (checked.checked) {
                newDataList.push(checked.id);
            }
        });
        var selectedData = {
        		dataList:newDataList,
        		sessionInputDTO: $rootScope.sessionInputObj
        }; 
        $http.put("/" + servicePrefix + "/rest/configSrv/delete",selectedData).then(function(response) {
            if(response.status === 200 ){
                ngDialog.close();
                ngDialog.openConfirm({
                    template: '<p>' + response.data.message + '</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                });
                
                var params={
			            
						 userRole: $rootScope.userRole,
						 sessionInputDTO : $rootScope.sessionInputObj
				           
				        };
                
                
                $http.post("/" + servicePrefix + "/rest/configSrv/displayAll",params).then(function(response){
                    if(response.status === 200){
                    	 if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
   		            	  $rootScope.checkAuthorization();
   		              }
   		        	 else $rootScope.tableContent = response.data.systemList;
                        for(var i=0,arrLen = $rootScope.tableContent.length;i< arrLen ;i++){
			        		 if($rootScope.tableContent[i].status == "Active"){
			        			 $rootScope.tableContent[i].status = "fa fa-check-circle";
	                        	}
	                        	else if($rootScope.tableContent[i].status == "In Active"){
	                        		$rootScope.tableContent[i].status = "fa fa-times-circle";
	                        	}
			        		 }
			          
			            for(var i=0,arrLen = $rootScope.tableContent.length; i<arrLen ;i++){
			            	if($rootScope.tableContent[i].isSourceSystem){
			            		$rootScope.tableContent[i].SourceSystem = "glyphicon glyphicon-ok";
			            	}else{
			            		$rootScope.tableContent[i].SourceSystem = "glyphicon glyphicon-remove";
			            	}
			            	
			            	if($rootScope.tableContent[i].isTargetSystem){
			            		$rootScope.tableContent[i].TargetSystem = "glyphicon glyphicon-ok";
			            	}else{
			            		$rootScope.tableContent[i].TargetSystem = "glyphicon glyphicon-remove";
			            	}
			            	if($rootScope.tableContent[i].isHVESSystem){
			            		$rootScope.tableContent[i].HVESSystem = "glyphicon glyphicon-ok";
			            	}else{
			            		$rootScope.tableContent[i].HVESSystem = "glyphicon glyphicon-remove";
			            	}
			            	
			            }
                    } else {
                        ngDialog.openConfirm({
                            template: '<p>' +"No records found!"+ '</p>',
                            plain: true,
                            scope: $scope,
                            closeByDocument: true,
                            closeByEscape: true,
                            showClose: true,
                            height:120,
                            width: 350,
                            className:'ngdialog-theme-default CLASS_2'
                        }); 
                    }
                });
            }
            else if(response.status === 200 && response.data.status === "Error"){
                ngDialog.openConfirm({
                    template: '<p>' + response.data.message + '</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                });
            }
        });
    };
    
  
}]);