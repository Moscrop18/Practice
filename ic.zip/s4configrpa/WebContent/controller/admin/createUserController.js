/*angular.module('yapp').controller('createUserController',["$scope", "$rootScope", "$state"," $stateParams"," $location","$ocLazyLoad", function($scope, $rootScope, $state, $stateParams, $location,$ocLazyLoad)  
{
	$ocLazyLoad.load(controllerName+'/admin/createUserController.js?ver='+version);
    $scope.createUser = function(){
        $rootScope.username = $scope.username;
        $rootScope.password = $scope.password;
        $scope.submitted = true;

        var params={
            firstName: $scope.firstName,
            lastName: $scope.lastName,
            email: $scope.email,
            userId: $scope.userId,
            status: $scope.status,
            omId: $scope.omId,
            role: $scope.role
        };



        $http.post("/" + servicePrefix + "/rest/userSrv/add", params).then(function(response) {
            if(response.data.status===0){
               // console.log("Success",response);
            }
            else {
            //console.log("Error",response);
          }
        });
        
       
    };
    
   
}]);*/