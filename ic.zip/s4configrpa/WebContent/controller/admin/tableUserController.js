angular.module('yapp').controller('tableUserController', ["$scope", "$state", "$rootScope", "$http", "$mdDialog", "$mdMedia", "ngDialog", "$location", "$timeout","$ocLazyLoad", function($scope, $state, $rootScope, $http, $mdDialog, $mdMedia, ngDialog, $location, $timeout,$ocLazyLoad) {
	$ocLazyLoad.load(controllerName+'/admin/tableUserController.js?ver='+version);
	var noAuth = "false";

	/*var cookie = document.cookie;
		var cookieAuthParams = cookie.split(';');
		for (var cp1 = 0,arrLen = cookieAuthParams.length; cp1 < arrLen ; cp1++) {*/
			/*if (cookieAuthParams[cp1].split('=')[0].trim() == "adminAuth" && cookieAuthParams[cp1].split('=')[1].trim() == "true") {
				noAuth = "true"
			}*/
			if ($rootScope.adminAuth == "true") {
				noAuth = "true"
			}
		/*	if($rootScope.appValidity == undefined){
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userDetails") {
					$rootScope.userValidation = cookieAuthParams[cp1].split('=')[1];
					console.log($rootScope.userValidation.role);
					
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userRole") {
					$rootScope.userRole = cookieAuthParams[cp1].split('=')[1];
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "roleId") {
					$rootScope.roleId = cookieAuthParams[cp1].split('=')[1];
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userName") {
					$rootScope.username = cookieAuthParams[cp1].split('=')[1];
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userFirstName") {
					 $rootScope.userFirstName = cookieAuthParams[cp1].split('=')[1];
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userLastName") {
					$rootScope.userLastName = cookieAuthParams[cp1].split('=')[1];
				}
		  }
		}*/
	if (noAuth == "false") {
			$location.path('/loginPage');
	}	
	document.getElementById("mySidenav").style.display = "none";
	if(document.getElementById("showSubMenu") != null)
	document.getElementById("showSubMenu").style.display = "none";
	document.getElementById("hambrgrCloseMenu").style.display = "none";
	document.getElementById("hambrgrMenu").style.display = "inline-block";
	
	   
    var params={
    		userID: $rootScope.username,
    		userRole: $rootScope.userRole,
    		sessionInputDTO: $rootScope.sessionInputObj
        };
    $scope.init = function () {	
	    	$scope.manageProject = "USER DETAILS";
	    	$scope.manageUser = "User Details";
    	 if($rootScope.userRole === "PAdmin"){
    		  $scope.isAssignPro = false;
			  $scope.isAddUser = false;
			  $scope.isDeleUser = false;
			  $scope.isEditUser = false;
			  $scope.isAssignUser = false;
			  $scope.isUnAssignUser = false;
    	 var paramsData={    
				 roleId: $rootScope.userRole,
				 sessionInputDTO : $rootScope.sessionInputObj           
		        };		 
			 $http.post("/" + servicePrefix + "/rest/authorizationSrv/getAuthorizationIds", paramsData).then(function(response) {
		        if(response.status === 200){
		        	if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
		            	  $rootScope.checkAuthorization();
		              }
		        	else if(response.data.actionIdList != null){
		        		  for (var i = 0,arrLen = response.data.actionIdList.length; i < arrLen; i++) {	
		        		  if(response.data.actionIdList[i]==="AddUser"){		        				
		        			  $scope.isAddUser = true;        			  
		        		  }else if(response.data.actionIdList[i]==="DeleteUser"){
		        			  $scope.isDeleUser = true;
		        		  }else if(response.data.actionIdList[i]==="EditUser"){
		        			  $scope.isEditUser = true;
		        		
		        		  }
		        		  else if(response.data.actionIdList[i]==="AssignUsers"){
		        			  $scope.isAssignUser = true;
		        		
		        		  } else if(response.data.actionIdList[i]==="UnAssignUsers"){
		        			  $scope.isUnAssignUser = true;
		        		
		        		  }
		        		  
		        		  
		        		  /*if(response.data.actionIdList[i]==="EnableUser"){
		        			  $scope.isAddUser = true;
		        			  $scope.isAssignUser = true;
		        			  $scope.isDeleUser = true; 
		        			  $scope.isEditUser = false;
		        		  }*/

		        		   if(response.data.actionIdList[i]==="AssignProjects"){
		        			   $scope.manageProject = "MANAGE USER";
		        			   $scope.manageUser = "Manage User";
		        			   $scope.isAssignPro = true;   
			        			
			        			 
			        		  }
		        		  }
		           
		        	  }/*else{
	        		  ngDialog.openConfirm({
                          template: '<p>' +"No records found!"+ '</p>',
                          plain: true,
                          scope: $scope,
                          closeByDocument: true,
                          closeByEscape: true,
                          showClose: true,
                          height:120,
                          width: 350,
                          className:'ngdialog-theme-default CLASS_2'
                      }); 
		        		  
		        	  }*/
		        } /*else {
		              ngDialog.openConfirm({
                    template: '<p>' +"No records found!"+ '</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                }); 
		        }*/
		  /*      if (!$scope.$phase) {

		        //$scope.$apply();
		    }*/
		    });	
			  $http.post("/" + servicePrefix + "/rest/userSrv/displayAll/",params).then(function(response) {
			        if(response.status === 200){
			        	if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
			            	  $rootScope.checkAuthorization();
			              }
			        	else if(response.data.userList != null){
			        		 var userListLength = response.data.userList.length;
	                    	  for(var i=0;i<userListLength;i++){
			        		 if(response.data.userList[i].status == "Active"){
	                        		response.data.userList[i].status = "fa fa-check-circle";
	                        	}
	                        	else if(response.data.userList[i].status == "In Active"){
	                        		response.data.userList[i].status = "fa fa-times-circle";
	                        	}
	                    	  }
			            $rootScope.tableUserContent = response.data.userList;
			            $scope.acclocked = $rootScope.tableUserContent.acclocked;
			            $scope.invalidAttempt = $rootScope.tableUserContent.invalidAttempt;	
			            for(var i=0,arrLen = $rootScope.tableUserContent.length;i< arrLen ;i++){
			            	if($rootScope.tableUserContent[i].validFrom){
			            		$rootScope.tableUserContent[i].validFrom = $rootScope.tableUserContent[i].validFrom.substr(0, 10);
			            	}
			            	if($rootScope.tableUserContent[i].validTo){
			            		$rootScope.tableUserContent[i].validTo = $rootScope.tableUserContent[i].validTo.substr(0, 10);
			            	}    
			            }
			        	 }else{
			        		 $rootScope.tableUserContent="";
			        	      ngDialog.openConfirm({
			                      template: '<p>' +"No records found!"+ '</p>',
			                      plain: true,
			                      scope: $scope,
			                      closeByDocument: true,
			                      closeByEscape: true,
			                      showClose: true,
			                      height:120,
			                      width: 350,
			                      className:'ngdialog-theme-default CLASS_2'
			                  }); 
			        		 
			        	 }
			            
			        } else {
			        	$rootScope.tableUserContent="";
			            ngDialog.openConfirm({
		                    template: '<p>' +"No records found!"+ '</p>',
		                    plain: true,
		                    scope: $scope,
		                    closeByDocument: true,
		                    closeByEscape: true,
		                    showClose: true,
		                    height:120,
		                    width: 350,
		                    className:'ngdialog-theme-default CLASS_2'
		                }); 
			        }
			        if (!$scope.$$phase) {
			        //$scope.$apply();
			    }
			    });	 
    	 }if($rootScope.userRole === "TAdmin"){
    		  $scope.isAddUser = true;
			  $scope.isAssignUser = true;
			  $scope.isDeleUser = true;
			  $scope.isEditUser = true;
			  $scope.isUnAssignUser = true;
			  $scope.manageProject = "MANAGE USER";
    		  $http.post("/" + servicePrefix + "/rest/userSrv/displayAll/",params).then(function(response) {
			        if(response.status === 200){
			        	if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
			            	  $rootScope.checkAuthorization();
			              }
			        	else if(response.data.userList != null){
			        		 var userListLength = response.data.userList.length;
	                    	  for(var i=0;i<userListLength;i++){

	                        	if(response.data.userList[i].status == "Active"){
	                        		response.data.userList[i].status = "fa fa-check-circle";
	                        	}
	                        	else if(response.data.userList[i].status == "In Active"){
	                        		response.data.userList[i].status = "fa fa-times-circle";
	                        	}
	                        	
	                    	  }
			            $rootScope.tableUserContent = response.data.userList;
			            $scope.acclocked = $rootScope.tableUserContent.acclocked;
			            $scope.invalidAttempt = $rootScope.tableUserContent.invalidAttempt;			           
			            
			            for(var i=0,arrLen = $rootScope.tableUserContent.length;i< arrLen ;i++){
			            	if($rootScope.tableUserContent[i].validFrom){
			            		$rootScope.tableUserContent[i].validFrom = $rootScope.tableUserContent[i].validFrom.substr(0, 10);
			            	}
			            	if($rootScope.tableUserContent[i].validTo){
			            		$rootScope.tableUserContent[i].validTo = $rootScope.tableUserContent[i].validTo.substr(0, 10);
			            	
			            	
			                }    
			            	
			            }
			        	 }else{
			        		 $rootScope.tableUserContent="";
			        	      ngDialog.openConfirm({
			                      template: '<p>' +"No records found!"+ '</p>',
			                      plain: true,
			                      scope: $scope,
			                      closeByDocument: true,
			                      closeByEscape: true,
			                      showClose: true,
			                      height:120,
			                      width: 350,
			                      className:'ngdialog-theme-default CLASS_2'
			                  }); 
			        		 
			        	 }
			            
			        } else {
			        	$rootScope.tableUserContent="";
			            ngDialog.openConfirm({
		                    template: '<p>' +"No records found!"+ '</p>',
		                    plain: true,
		                    scope: $scope,
		                    closeByDocument: true,
		                    closeByEscape: true,
		                    showClose: true,
		                    height:120,
		                    width: 350,
		                    className:'ngdialog-theme-default CLASS_2'
		                }); 
			        }
			        if (!$scope.$$phase) {
			        //$scope.$apply();
			    }
			    });	 
    		 
    	 }
   
    };
    /*********Add Part********/    
    $scope.openAddDialog = function()
    {
    	$scope.password="";
    	
    	$http.post("/" + servicePrefix + "/rest/adminSrv/displayRoles", $rootScope.sessionInputObj).then(function(response) {
    		 if(response.data.roles != null){
    			 if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
	            	  $rootScope.checkAuthorization();
	              }
	        	else $scope.Roles=response.data.roles;
    		 }else{
    		      ngDialog.openConfirm({
                      template: '<p>' +"No records found!"+ '</p>',
                      plain: true,
                      scope: $scope,
                      closeByDocument: true,
                      closeByEscape: true,
                      showClose: true,
                      height:120,
                      width: 350,
                      className:'ngdialog-theme-default CLASS_2'
                  }); 
    			 
    		 }
    	$http.post("/" + servicePrefix + "/rest/customerSrv/displayClientIds",$rootScope.sessionInputObj).then(function(response) {
    		 if(response.data.dataList != null){
        		$scope.CustomerId=response.data.dataList;
    		 }else{
    		      ngDialog.openConfirm({
                      template: '<p>' +"No records found!"+ '</p>',
                      plain: true,
                      scope: $scope,
                      closeByDocument: true,
                      closeByEscape: true,
                      showClose: true,
                      height:120,
                      width: 350,
                      className:'ngdialog-theme-default CLASS_2'
                  }); 
    			 
    		 }  		 
    		ngDialog.openConfirm({
            template: 'view/admin/createUser.html?ver='+version,
            controller:'tableUserController',
            scope: $scope,
            closeByDocument: false,
            closeByEscape: false,
            showClose: true,
            height: 405,
            width: 1100
        }).then(function() {
            $scope.createUser();
        });
    	});
    	});
    };
    $scope.validate = function(name) {
    	 var inputParam ={
	    		  userID: name,
	    		  sessionInputDTO: $rootScope.sessionInputObj
	      }
  	  $http.post("/" + servicePrefix + "/rest/userSrv/validateUser", inputParam).then(function(response){
            if(response.status === 200){
            	if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
	            	  $rootScope.checkAuthorization();
	              }
	        	else if(response.data.dataStatus===true){
            		 
            		 $scope.validMeaggse = "UserId Exists! Please choose another UserId  "; 
            		 $timeout(function () { $scope.validMeaggse = ""; }, 2000);   
            	 }else{
            		 
            		 $scope.validMeaggse=""; 
            	 }
            	
            } else {
                ngDialog.openConfirm({
                    template: '<p>' +"No records found!"+ '</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                }); 
            }
        });
  	
    };
    $scope.createUser = function(){
        $rootScope.username = $scope.username;
        $rootScope.password = sha256($scope.user_password);
        $scope.submitted = true;
        

        
        if(new Date($scope.validFromDate) > new Date($scope.validToDate)){
        	ngDialog.openConfirm({
                template: '<p>' + "End Date should be greater than the From Date" + '</p>',
                plain: true,
                scope: $scope,
                closeByDocument: true,
                closeByEscape: true,
                showClose: true,
                height:120,
                width: 350,
                className:'ngdialog-theme-default CLASS_2'
            });
        	return ;
        }
        var oneDay = 24*60*60*1000; // hours*minutes*seconds*milliseconds    
        var diffDays = Math.round(Math.abs((new Date().getTime() - $scope.validToDate.getTime())/(oneDay)));
        
        if(diffDays > 90){
        	ngDialog.openConfirm({
                template: '<p>' + "Date Range should be with in 90 days " + '</p>',
                plain: true,
                scope: $scope,
                closeByDocument: true,
                closeByEscape: true,
                showClose: true,
                height:120,
                width: 350,
                className:'ngdialog-theme-default CLASS_2'
            });
            return ;
        }
    
        
           var paramsData1={
            firstName: $scope.firstName,
            lastName: $scope.lastName,
            email: $scope.email,
            userId: $scope.userId,
            status: $scope.status,
            role: $scope.selectedRole,
            password: $scope.user_password,
            validFrom: $scope.convertDate($scope.validFromDate),
            validTo: $scope.convertDate($scope.validToDate),
            sessionInputDTO: $rootScope.sessionInputObj
        };

        $http.post("/" + servicePrefix + "/rest/userSrv/add", paramsData1).then(function(response) {
            if(response.status === 200 && response.data.msgType === "Success"){
                ngDialog.close();
                ngDialog.openConfirm({
                    template: '<p>' + response.data.message + '</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                });
                $http.post("/" + servicePrefix + "/rest/userSrv/displayAll/",params).then(function(response) {
                    if(response.status === 200){
                    	 if(response.data.userList != null){
                    	  var userListLength = response.data.userList.length;
                    	  for(var i=0;i<userListLength;i++){
                    		 if(response.data.userList[i].status == "Active"){
	                        		response.data.userList[i].status = "fa fa-check-circle";
	                        	}
	                        	else if(response.data.userList[i].status == "In Active"){
	                        		response.data.userList[i].status = "fa fa-times-circle";
	                        	}
                    	  }
                    		 $rootScope.tableUserContent = response.data.userList;
                             for(var i=0,arrLen = $rootScope.tableUserContent.length;i< arrLen ;i++){
                             	if($rootScope.tableUserContent[i].validFrom){
                             		$rootScope.tableUserContent[i].validFrom = $rootScope.tableUserContent[i].validFrom.substr(0, 10);
                             	}
                             	if($rootScope.tableUserContent[i].validTo){
                             		$rootScope.tableUserContent[i].validTo = $rootScope.tableUserContent[i].validTo.substr(0, 10);
                             	
                             	
                                 }    
                            	
                             }
                    	 }else{
                    		 $rootScope.tableUserContent="";
                    	      ngDialog.openConfirm({
                                  template: '<p>' +"No records found!"+ '</p>',
                                  plain: true,
                                  scope: $scope,
                                  closeByDocument: true,
                                  closeByEscape: true,
                                  showClose: true,
                                  height:120,
                                  width: 350,
                                  className:'ngdialog-theme-default CLASS_2'
                              }); 
                    		 
                    	 }
                    	 
                    	 
                    	 
                    	 
                    	 
                    } else {
                    	$rootScope.tableUserContent="";
                        ngDialog.openConfirm({
                            template: '<p>' +"No records found!"+ '</p>',
                            plain: true,
                            scope: $scope,
                            closeByDocument: true,
                            closeByEscape: true,
                            showClose: true,
                            height:120,
                            width: 350,
                            className:'ngdialog-theme-default CLASS_2'
                        }); 
                    }
                });
            }else if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
          	  $rootScope.checkAuthorization();
            }
      	 else if(response.status === 200 && response.data.msgType === "Error") {
            	ngDialog.close();
                ngDialog.openConfirm({
                    template: '<p>' + response.data.message + '</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                });
            }
        });
    }

    /*********Edit Part********/
    $scope.modify = function(x){
    	 
        if($rootScope.userRole === "PAdmin"){ 
        if($scope.isEditUser ===true){	
        	  $scope.editUserData = x;
              $scope.editUserData.status=x.status;
              $scope.editUserData.role=x.role;      
              $scope.editUserData.validFrom=x.validFrom;
              $scope.editUserData.validTo=x.validTo; 
              $scope.editUserData.validFrom1=new Date(x.validFrom);
              $scope.editUserData.validTo1=new Date(x.validTo);      
              $scope.openEditDialog();
        
        }        
        }else{
        	
        	  $scope.editUserData = x;
              $scope.editUserData.status=x.status;
              $scope.editUserData.role=x.role;
              $scope.editUserData.validFrom=x.validFrom;
              $scope.editUserData.validTo=x.validTo;
              $scope.editUserData.validFrom1=new Date(x.validFrom);
              $scope.editUserData.validTo1=new Date(x.validTo); 
        	  $scope.openEditDialog();
        }
    };

    $scope.openEditDialog = function()
    {
    	$http.post("/" + servicePrefix + "/rest/customerSrv/displayClientIds",$rootScope.sessionInputObj).then(function(response) {
    		 if(response.data.dataList != null){
    			 if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
	            	  $rootScope.checkAuthorization();
	              }
	        	else $scope.CustomerId=response.data.dataList;
    		 }else{
    		      ngDialog.openConfirm({
                      template: '<p>' +"No records found!"+ '</p>',
                      plain: true,
                      scope: $scope,
                      closeByDocument: true,
                      closeByEscape: true,
                      showClose: true,
                      height:120,
                      width: 350,
                      className:'ngdialog-theme-default CLASS_2'
                  }); 
    		 }
        $http.post("/" + servicePrefix + "/rest/adminSrv/displayRoles", $rootScope.sessionInputObj).then(function(response) {
        	 if(response.data.roles != null){
        		$scope.Roles = response.data.roles;
        	 }else{
        	      ngDialog.openConfirm({
                      template: '<p>' +"No records found!"+ '</p>',
                      plain: true,
                      scope: $scope,
                      closeByDocument: true,
                      closeByEscape: true,
                      showClose: true,
                      height:120,
                      width: 350,
                      className:'ngdialog-theme-default CLASS_2'
                  }); 
        		 
        	 }
        	 var systemListLength = $rootScope.tableUserContent.length;
         	for(i=0;i<systemListLength;i++){
         	if($rootScope.tableUserContent[i].userId ==  $scope.editUserData.userId)
         	if($rootScope.tableUserContent[i].status == "fa fa-check-circle")
         		$scope.statusUserEnable = true;
         	else $scope.statusUserEnable = false;
         	}
        ngDialog.openConfirm({
            template: 'view/admin/editUser.html?ver='+version,
            controller:'tableUserController',
            scope: $scope,
            closeByDocument: false,
            closeByEscape: false,
            showClose: true,
            height: 430,
            width: 1100
        }).then(function() {
            $scope.Update();
        });
    	});
    	});
    }
    $scope.updateAttempts = function(){
    	var defaultPwdField = document.getElementById("defaultPwd");
    
    	if(document.getElementById('stsField3').checked)
     	{ 
    		defaultPwdField.style.display = "inline-block";
    		document.getElementById("defaultPwd1").style.display = "inline-block";
    		
     	}
    	else {    		
    		defaultPwdField.style.display = "none";
     		document.getElementById("defaultPwd1").style.display = "none";
    	   
    	}
    };
    $scope.Update = function(){
        $rootScope.username = $scope.username;
        $rootScope.password = sha256($scope.password);
        $scope.submitted = true;
       
        if(new Date($scope.editUserData.validFrom1) > new Date($scope.editUserData.validTo1)){
        	ngDialog.openConfirm({
                template: '<p>' + "End Date should be greater than the From Date" + '</p>',
                plain: true,
                scope: $scope,
                closeByDocument: true,
                closeByEscape: true,
                showClose: true,
                height:120,
                width: 350,
                className:'ngdialog-theme-default CLASS_2'
            });
        	return ;
        }
        
  
        var oneDay = 24*60*60*1000; // hours*minutes*seconds*milliseconds    
        var diffDays = Math.round(Math.abs((new Date().getTime() - $scope.editUserData.validTo1.getTime())/(oneDay)));
        
        if(diffDays > 90){
        	ngDialog.openConfirm({
                template: '<p>' + "Date Range should be with in 90 days " + '</p>',
                plain: true,
                scope: $scope,
                closeByDocument: true,
                closeByEscape: true,
                showClose: true,
                height:120,
                width: 350,
                className:'ngdialog-theme-default CLASS_2'
            });
        	 return ;
        }
              
        
        var status ="Active";
        if(document.getElementById('stsField').checked)
        	status ="Active"
        else
        	status ="In Active";
        var defaultPwdField = document.getElementById("defaultPwd");
    	$scope.acclocked = 'Y';
    	if(document.getElementById('stsField2').checked)
     	{ 
    		$scope.acclocked ='N';
    		$scope.invalidAttempts = 0;
     	}
    	else {
    		$scope.acclocked = $scope.editUserData.acclocked;
    		$scope.invalidAttempts = $scope.editUserData.invalidAttempt;
    	}
    	if(document.getElementById('stsField3').checked)
     	{ 
    		$scope.invalidAttempts = 0;
        	$scope.default_p = 'Y';
        	$scope.password = $scope.editUserData.setdefaultPassowrd;
        	
     	}
    	else {   		
    		
    	    $scope.default_p = 'N';
    	    $scope.invalidAttempts = $scope.editUserData.invalidAttempt;
    	    $scope.password = null;
    	}
        var paramsData4={
            firstName: document.getElementById('fstName').value,
            lastName: document.getElementById('lstName').value,
            email: document.getElementById('emlId').value,
            userId: document.getElementById('usrId').value,
            //password: sha256(document.getElementById('password').value),
            status: status,
            role: $scope.editUserData.role,
            validFrom: $scope.convertDate($scope.editUserData.validFrom1),
            validTo: $scope.convertDate($scope.editUserData.validTo1),
            accLocked : $scope.acclocked,
            invalidAttempt : $scope.invalidAttempts,
            default_p : $scope.default_p,
            password :$scope.password,
            sessionInputDTO: $rootScope.sessionInputObj
            };

        $http.put("/" + servicePrefix + "/rest/userSrv/update",paramsData4).then(function(response) {
            if(response.status===200){
            	if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
	            	  $rootScope.checkAuthorization();
	              }
	        	else{
                ngDialog.close();
                ngDialog.openConfirm({
                    template:  '<p>' + response.data.message + '</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                });
                $http.post("/" + servicePrefix + "/rest/userSrv/displayAll/",params).then(function(response) {
                    if(response.status === 200){
                    	 if(response.data.userList != null){
                    		 var userListLength = response.data.userList.length;
                       	  for(var i=0;i<userListLength;i++){
                    		 if(response.data.userList[i].status == "Active"){
	                        		response.data.userList[i].status = "fa fa-check-circle";
	                        	}
	                        	else if(response.data.userList[i].status == "In Active"){
	                        		response.data.userList[i].status = "fa fa-times-circle";
	                        	}
                    		 
                       	  }
                    		 $rootScope.tableUserContent = response.data.userList;
                             for(var i=0,arrLen = $rootScope.tableUserContent.length;i< arrLen ;i++){
                             	if($rootScope.tableUserContent[i].validFrom){
                             		$rootScope.tableUserContent[i].validFrom = $rootScope.tableUserContent[i].validFrom.substr(0, 10);
                             	}
                             	if($rootScope.tableUserContent[i].validTo){
                             		$rootScope.tableUserContent[i].validTo = $rootScope.tableUserContent[i].validTo.substr(0, 10);
                             	
                             	
                                 }    
                            	
	                        	
                             }
                    	 }else{
                    		 $rootScope.tableUserContent="";
                    	      ngDialog.openConfirm({
                                  template: '<p>' +"No records found!"+ '</p>',
                                  plain: true,
                                  scope: $scope,
                                  closeByDocument: true,
                                  closeByEscape: true,
                                  showClose: true,
                                  height:120,
                                  width: 350,
                                  className:'ngdialog-theme-default CLASS_2'
                              }); 
                    	 }
                    } else {
                    	$rootScope.tableUserContent="";
                        ngDialog.openConfirm({
                            template: '<p>' +"No records found!"+ '</p>',
                            plain: true,
                            scope: $scope,
                            closeByDocument: true,
                            closeByEscape: true,
                            showClose: true,
                            height:120,
                            width: 350,
                            className:'ngdialog-theme-default CLASS_2'
                        }); 
                    }
                });
	        	}
            }
            else {
            	$rootScope.tableUserContent="";
            	   ngDialog.openConfirm({
                       template: '<p>' +"No Data found!"+ '</p>',
                       plain: true,
                       scope: $scope,
                       closeByDocument: true,
                       closeByEscape: true,
                       showClose: true,
                       height:120,
                       width: 350,
                       className:'ngdialog-theme-default CLASS_2'
                   });
          }
        });
    }   
    $scope.unAssignUserProjectsDialog = function()
    {
    	var params={
    			userID: $rootScope.username,
    			userRole: $rootScope.userRole,
    			sessionInputDTO: $rootScope.sessionInputObj
            };
	   $http.post("/" + servicePrefix + "/rest/customerSrv/displayProjectNames",params).then(function(response){
           if(response.status === 200){
        		if(response.data.dataList != null){
        			if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
		            	  $rootScope.checkAuthorization();
		              }
		        	else $rootScope.selectProjects = response.data.dataList;
        		}
           } else {
        	      ngDialog.openConfirm({
                      template: '<p>' +"No records found!"+ '</p>',
                      plain: true,
                      scope: $scope,
                      closeByDocument: true,
                      closeByEscape: true,
                      showClose: true,
                      height:120,
                      width: 350,
                      className:'ngdialog-theme-default CLASS_2'
                  }); 
           }
       });
	   var newDataList = [];
       $scope.selectedAll = false;
       angular.forEach($rootScope.tableUserContent, function (checked) {
           if (checked.checked) {
               newDataList.push(checked.userId);
              
           }
       });
       if (newDataList.length > 0){
    	   ngDialog.openConfirm({
               template: 'view/admin/unAssignUsersToProject.html?ver='+version,
               controller:'tableUserController',
               scope: $scope,
               closeByDocument: false,
               closeByEscape: false,
               showClose: true,
               height: 300,
               width: 800,
               className:'ngdialog-theme-default CLASS_trgSys'
           }).then(function() {
               $scope.unAssignUsertoProjects();
           });
       }
       	else{
       		ngDialog.openConfirm({
                   template: '<p>' +"Please select at least One UserId"+ '</p>',
                   plain: true,
                   scope: $scope,
                   closeByDocument: true,
                   closeByEscape: true,
                   showClose: true,
                   height:120,
                   width: 350,
                   className:'ngdialog-theme-default CLASS_2'
               });
       	}
       
	   
       
    };
    
    $scope.openProjectUsersDialog = function()
    {
    	var params={
    			userID: $rootScope.username,
    			userRole: $rootScope.userRole,
    			sessionInputDTO: $rootScope.sessionInputObj
            };
    	
	   $http.post("/" + servicePrefix + "/rest/customerSrv/displayProjectNames",params).then(function(response){
           if(response.status === 200){
        		if(response.data.dataList != null){
        			if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
		            	  $rootScope.checkAuthorization();
		              }
		        	else $rootScope.selectProjects = response.data.dataList;
        		}
           } else {
        	      ngDialog.openConfirm({
                      template: '<p>' +"No records found!"+ '</p>',
                      plain: true,
                      scope: $scope,
                      closeByDocument: true,
                      closeByEscape: true,
                      showClose: true,
                      height:120,
                      width: 350,
                      className:'ngdialog-theme-default CLASS_2'
                  }); 
           }
       });
	   var newDataList = [];
       $scope.selectedAll = false;
       angular.forEach($rootScope.tableUserContent, function (checked) {
           if (checked.checked) {
               newDataList.push(checked.userId);
              
           }
       });
       if (newDataList.length > 0){
    	   ngDialog.openConfirm({
               template: 'view/admin/assignUsersToProject.html?ver='+version,
               controller:'tableUserController',
               scope: $scope,
               closeByDocument: false,
               closeByEscape: false,
               showClose: true,
               height: 300,
               width: 800,
               className:'ngdialog-theme-default CLASS_trgSys'
           }).then(function() {
               $scope.createUsertoProjects();
           });
       }
       	else{
       		ngDialog.openConfirm({
                   template: '<p>' +"Please select at least One UserId"+ '</p>',
                   plain: true,
                   scope: $scope,
                   closeByDocument: true,
                   closeByEscape: true,
                   showClose: true,
                   height:120,
                   width: 350,
                   className:'ngdialog-theme-default CLASS_2'
               });
       	}
       
	   
       
    };
    
    $scope.updateProjects = function(typed){
    	if($rootScope.selectProjects != null){
    	  for (var i = 0,arrLen = $rootScope.selectProjects.length; i < arrLen ; i++) {	
    		  if($rootScope.selectProjects[i] === typed){		
	    $scope.newProjects = $rootScope.selectProjects[i];
	    $scope.newProjects.then(function(data){
	    	
	    	$rootScope.selectProjects = data;
	      
	    });
    		  }
    }
    	}else{
    		
    	      ngDialog.openConfirm({
                  template: '<p>' +"No records found!"+ '</p>',
                  plain: true,
                  scope: $scope,
                  closeByDocument: true,
                  closeByEscape: true,
                  showClose: true,
                  height:120,
                  width: 350,
                  className:'ngdialog-theme-default CLASS_2'
              }); 
    	}
	};
    $scope.formatDate = function (date) {
        var d = new Date(date),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

        if (month.length < 2) month = '0' + month;
        if (day.length < 2) day = '0' + day;

        return [year, month, day].join('-');
    }
    $scope.convertDateModify = function(dt){
       var dd,mm,yy,hh,mm1,ss;
       dd = dt.getDate();
       mm = dt.getMonth();
       yy = dt.getFullYear();
       hh = dt.getHours();
       mm1 = dt.getMinutes();
       ss = dt.getSeconds();
       var formattedDate = yy +'-'+mm +'-'+dd +' '+hh+':'+mm1+':'+ss+'.000';
       return formattedDate;
    }

    $scope.convertDate = function(dt1){
    	
        var dt=dt1.toISOString();
        var a = dt.split("Z");
        var b = a[0].split('T');
        var c = b[0] +' '+b[1];
        return c;
    }

    /*********Delete Part********/

    $scope.isAll = false;
    $scope.selectAllFriends = function () {
        if ($scope.isAll === false) {
            angular.forEach($scope.tableUserContent, function (x) {
                x.checked = true;
            });
            $scope.isAll = true;
        } else {
            angular.forEach($scope.tableUserContent, function (x) {
                x.checked = false;
            });
            $scope.isAll = false;
        }
    };
    $scope.openDeleteDialog = function()
    {
    	var newDataList = [];
        $scope.selectedAll = false;
        angular.forEach($rootScope.tableUserContent, function (checked) {
            if (checked.checked) {
            	
                newDataList.push(checked.userId);
                newDataList.push(checked.status);
            
            }
        });
        if (newDataList.length > 0){       
        	if(newDataList.length === 2){
        	
        	if(newDataList[1]==="In Active"){
     		   ngDialog.openConfirm({
                    template: '<p>' +"Seleted User Status Already In Active."+ '</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                }); 
        	}else{
        		 ngDialog.openConfirm({
        		    template: 'view/admin/deleteUser.html?ver='+version,
        	        controller:'tableUserController',
       	            scope: $scope,
       	            closeByDocument: false,
       	            closeByEscape: false,
       	            showClose: true,
       	            height: 180,
       	            width: 400,
       	            className:'ngdialog-theme-default CLASS_2'
       	            
       	        }).then(function() {
       	            $scope.remove();
       	        }); 
        		
        	}
        	
        	
        	}
        	else if(newDataList.length > 2){      		   
          		   ngDialog.openConfirm({
          			   template: 'view/admin/deleteUser.html?ver='+version,
         	           controller:'tableUserController',
          	            scope: $scope,
          	            closeByDocument: false,
          	            closeByEscape: false,
          	            showClose: true,
          	            height: 150,
          	            width: 350,
          	            className:'ngdialog-theme-default CLASS_2'
          	        }).then(function() {
          	            $scope.remove();
          	        }); 
          		   
          	   }        	
        	
            }   
     	   
     
        	else{
       		ngDialog.openConfirm({
                template: '<p>' +"Please select at least One UserId"+ '</p>',
                plain: true,
                scope: $scope,
                closeByDocument: true,
                closeByEscape: true,
                showClose: true,
                height:120,
                width: 350,
                className:'ngdialog-theme-default CLASS_2'
            });
    	}
    
    };
    
    $scope.checkUserProjects = function(userId)
    {
    	
    	var inputParam = {
    			userID : userId,
    			sessionInputDTO: $rootScope.sessionInputObj
    	}
    	   $http.post("/" + servicePrefix + "/rest/selectCustomer/userProjects", inputParam).then(function(response){
               if(response.status === 200){
            	   $rootScope.projectUserData = [];
            	   if(response.data.customerList != null){
            	   
                   for (var i = 0,arrLen = response.data.customerList.length; i < arrLen ; i++) {
   		    		var projectUser ={
   		    			"userId":userId,
   		    			"customerName":response.data.customerList[i].customerName,
   		    			"projectName":response.data.customerList[i].projectName
   		    		 } ;	    		
   		    		 $rootScope.projectUserData.push(projectUser);
   		    		projectUser={};
   		    	 }
                   
                   if ($scope.projectUserData.length > 0){
                	   ngDialog.openConfirm({
                           template: 'view/admin/viewProjectAssignedUsers.html?ver='+version,
                           controller:'tableUserController',
                           scope: $scope,
                           closeByDocument: true,
                           closeByEscape: false,
                           showClose: true,
                           className:'ngdialog-theme-default CLASS_trgSys',
                           height: "auto",
                           width: 500
                       }).then(function() {
                         
                       });
                   } else{
                	   
                		ngDialog.openConfirm({
                            template: '<p>' +"No records found!"+ '</p>',
                            plain: true,
                            scope: $scope,
                            closeByDocument: true,
                            closeByEscape: true,
                            showClose: true,
                            height:120,
                            width: 350,
                            className:'ngdialog-theme-default CLASS_2'
                        }); 
                	   
                   }
                   
                   }else if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
		            	  $rootScope.checkAuthorization();
		              }
                   else {
             	      ngDialog.openConfirm({
                           template: '<p>' +"No records found!"+ '</p>',
                           plain: true,
                           scope: $scope,
                           closeByDocument: true,
                           closeByEscape: true,
                           showClose: true,
                           height:120,
                           width: 350,
                           className:'ngdialog-theme-default CLASS_2'
                       });
                   }
             	      
		       } else {
            	      ngDialog.openConfirm({
                          template: '<p>' +"No records found!"+ '</p>',
                          plain: true,
                          scope: $scope,
                          closeByDocument: true,
                          closeByEscape: true,
                          showClose: true,
                          height:120,
                          width: 350,
                          className:'ngdialog-theme-default CLASS_2'
                      }); 
               }
           });
    	
   
    };
    $scope.createUsertoProjects = function (projUser) {   	
        var newDataList1 = [];
        $scope.selectedAll = false;
        if (projUser != undefined ){
        	   if (projUser != "" ){ 
        		   var aIndex = $rootScope.selectProjects.indexOf(projUser);	        			
                   if(aIndex>-1){

        		var fields = projUser.split('-');
        	    var omId = fields[0];
        	    var projectName = fields[1];
        	    
        	if($rootScope.tableClientContent != null){
        angular.forEach($rootScope.tableUserContent, function (checked) {
            if (checked.checked) {
            	var selectedData = {
            			"userId":checked.userId,
            			"projectName":projectName,
            			"omId":omId
                    }; 
            	 newDataList1.push(selectedData);
           
                 selectedData = {};
            }          
        });
        }   
        	 var inputParam ={
      	    		  manageProjects : newDataList1,
      	    		  sessionInputDTO: $rootScope.sessionInputObj
      	      }
             $http.post("/" + servicePrefix + "/rest/manageProjectsSrv/assignProjectsToUser",inputParam).then(function(response) {
           	 
           	   if(response.status === 200 && response.data.msgType === "Success"){
                       ngDialog.close();
                       ngDialog.openConfirm({
                           template: '<p>' + response.data.message + '</p>',
                           plain: true,
                           scope: $scope,
                           closeByDocument: true,
                           closeByEscape: true,
                           showClose: true,
                           height:120,
                           width: 350
                       });
                     
                   }else if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
		            	  $rootScope.checkAuthorization();
		              }
		        	
                 else if(response.status === 200 && response.data.msgType === "Error"){
                       ngDialog.openConfirm({
                           template: '<p>'+ response.data.message +'</p>',
                           plain: true,
                           scope: $scope,
                           closeByDocument: true,
                           closeByEscape: true,
                           showClose: true,
                           height:120,
                           width: 350
                       });
                   }
               });
             
        	   }else{
        		   
        		   ngDialog.openConfirm({
                       template: '<p>' + "Please select Project" + '</p>',
                       plain: true,
                       scope: $scope,
                       closeByDocument: true,
                       closeByEscape: true,
                       showClose: true,
                       height:120,
                       width: 350
                   });
        	   }
             
        }else{
        	  ngDialog.openConfirm({
                  template: '<p>' + "Please select Project" + '</p>',
                  plain: true,
                  scope: $scope,
                  closeByDocument: true,
                  closeByEscape: true,
                  showClose: true,
                  height:120,
                  width: 350
              });
         	
        	
        }
        }else{
    	
         ngDialog.openConfirm({
             template: '<p>' + "Please select Project" + '</p>',
             plain: true,
             scope: $scope,
             closeByDocument: true,
             closeByEscape: true,
             showClose: true,
             height:120,
             width: 350
         });
    	
    }
       
    };
    
    $scope.unAssignUsertoProjects = function (projUser) {   	
        var newDataList1 = [];
        $scope.selectedAll = false;
        if (projUser != undefined ){
        	   if (projUser != "" ){ 
        		   var aIndex = $rootScope.selectProjects.indexOf(projUser);	        			
                   if(aIndex>-1){

        		var fields = projUser.split('-');
        	    var omId = fields[0];
        	    var projectName = fields[1];
        	    
        	if($rootScope.tableClientContent != null){
        angular.forEach($rootScope.tableUserContent, function (checked) {
            if (checked.checked) {
            	var selectedData = {
            			"userId":checked.userId,
            			"projectName":projectName,
            			"omId":omId
                    }; 
            	 newDataList1.push(selectedData);
           
                 selectedData = {};
            }          
        });
        }      	
        	var inputParam ={
    	    		  manageProjects : newDataList1,
    	    		  sessionInputDTO: $rootScope.sessionInputObj
    	      }
             $http.post("/" + servicePrefix + "/rest/manageProjectsSrv/unAssignProjectsToUser",inputParam).then(function(response) {
           	 
           	   if(response.status === 200 && response.data.msgType === "Success"){
                       ngDialog.close();
                       ngDialog.openConfirm({
                           template: '<p>' + response.data.message + '</p>',
                           plain: true,
                           scope: $scope,
                           closeByDocument: true,
                           closeByEscape: true,
                           showClose: true,
                           height:120,
                           width: 350
                       });
                     
                   }else if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
		            	  $rootScope.checkAuthorization();
		              }
		        else if(response.status === 200 && response.data.msgType === "Error"){
                       ngDialog.openConfirm({
                           template: '<p>'+ response.data.message +'</p>',
                           plain: true,
                           scope: $scope,
                           closeByDocument: true,
                           closeByEscape: true,
                           showClose: true,
                           height:120,
                           width: 350
                       });
                   }
               });
             
        	   }else{
        		   
        		   ngDialog.openConfirm({
                       template: '<p>' + "Please select Project" + '</p>',
                       plain: true,
                       scope: $scope,
                       closeByDocument: true,
                       closeByEscape: true,
                       showClose: true,
                       height:120,
                       width: 350
                   });
        	   }
             
        }else{
        	  ngDialog.openConfirm({
                  template: '<p>' + "Please select Project" + '</p>',
                  plain: true,
                  scope: $scope,
                  closeByDocument: true,
                  closeByEscape: true,
                  showClose: true,
                  height:120,
                  width: 350
              });
         	
        	
        }
        }else{
    	
         ngDialog.openConfirm({
             template: '<p>' + "Please select Project" + '</p>',
             plain: true,
             scope: $scope,
             closeByDocument: true,
             closeByEscape: true,
             showClose: true,
             height:120,
             width: 350
         });
    	
    }
       
    };
    
    
    $scope.remove = function () {
        var newDataList = [];
        $scope.selectedAll = false;
        angular.forEach($scope.tableUserContent, function (checked) {
            if (checked.checked) {
                newDataList.push(checked.userId);
            }
        });
        var selectedData = {
        		dataList:newDataList,
        		sessionInputDTO: $rootScope.sessionInputObj
        }; 
        $http.put("/" + servicePrefix + "/rest/userSrv/delete",selectedData).then(function(response) {
            if(response.status === 200 && response.data.msgType === "Success"){
                ngDialog.close();
                ngDialog.openConfirm({
                    template: '<p>' + response.data.message + '</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                });
                
                
                var params={
                		userID: $rootScope.username,
                		userRole: $rootScope.userRole,
                		sessionInputDTO: $rootScope.sessionInputObj
                    };
                
                
                $http.post("/" + servicePrefix + "/rest/userSrv/displayAll",params).then(function(response){
                    if(response.status === 200){
                    	 if(response.data.userList != null){
                    		 var userListLength = response.data.userList.length;
                       	  for(var i=0;i<userListLength;i++){
                    		 if(response.data.userList[i].status == "Active"){
	                        		response.data.userList[i].status = "fa fa-check-circle";
	                        	}
	                        	else if(response.data.userList[i].status == "In Active"){
	                        		response.data.userList[i].status = "fa fa-times-circle";
	                        	}
                       	  }
                    		 $rootScope.tableUserContent = response.data.userList;
                             for(var i=0,arrLen = $rootScope.tableUserContent.length;i< arrLen ;i++){
                             	if($rootScope.tableUserContent[i].validFrom){
                             		$rootScope.tableUserContent[i].validFrom = $rootScope.tableUserContent[i].validFrom.substr(0, 10);
                             	}
                             	if($rootScope.tableUserContent[i].validTo){
                             		$rootScope.tableUserContent[i].validTo = $rootScope.tableUserContent[i].validTo.substr(0, 10);
                             	
                             	
                                 }    
                            	
	                        	
                             }
                    	 }                    } else {
                    	      ngDialog.openConfirm({
                                  template: '<p>' +"No records found!"+ '</p>',
                                  plain: true,
                                  scope: $scope,
                                  closeByDocument: true,
                                  closeByEscape: true,
                                  showClose: true,
                                  height:120,
                                  width: 350,
                                  className:'ngdialog-theme-default CLASS_2'
                              }); 
                    }
                });
            }else if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
          	  $rootScope.checkAuthorization();
            }
      	else if(response.status === 200 && response.data.msgType === "Error"){
                ngDialog.openConfirm({
                    template: '<p>' + response.data.message + '</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                });
            }
        });
    };
    
    $scope.validateDateRange = function(startDate,endDate) {
    	 if(new Date(startDate) > new Date(endDate)){
        	ngDialog.openConfirm({
                template: '<p>' + "End Date should be greater than the From Date" + '</p>',
                plain: true,
                scope: $scope,
                closeByDocument: true,
                closeByEscape: true,
                showClose: true,
                height:120,
                width: 350,
                className:'ngdialog-theme-default CLASS_2'
            });
        }
        
        else{
        var oneDay = 24*60*60*1000; // hours*minutes*seconds*milliseconds    
        var diffDays = Math.round(Math.abs((new Date().getTime() - endDate.getTime())/(oneDay)));
        
        console.log(diffDays)
        if(diffDays > 90){
        	ngDialog.openConfirm({
                template: '<p>' + "Date Range should be with in 90 days " + '</p>',
                plain: true,
                scope: $scope,
                closeByDocument: true,
                closeByEscape: true,
                showClose: true,
                height:120,
                width: 350,
                className:'ngdialog-theme-default CLASS_2'
            });
        }
        }
    };
    $scope.setDefault = function(){
    	//Set default password in db and default_p y and attempts to 0
    	//sec qa to null 
    	if(document.getElementById('stsField3').checked)
     	{ 
    		$scope.invalidAttempts = 0;
        	$scope.default_p = 'Y';
     	}
    	else {
    		$scope.default_p = 'N';
    		$scope.invalidAttempts = $scope.editUserData.invalidAttempt;
    	}
    	
       
    };
}]);