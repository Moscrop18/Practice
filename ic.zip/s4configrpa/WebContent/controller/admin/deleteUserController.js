angular.module('yapp').controller('deleteUserController',["$scope", "$rootScope", "$state"," $stateParams"," $location","$http", "ngDialog","$ocLazyLoad", function($scope, $rootScope, $state, $stateParams, $location,$http, ngDialog,$ocLazyLoad)  
{
	var noAuth = "false";
/*
	var cookie = document.cookie;
		var cookieAuthParams = cookie.split(';');*/
	
		/*	if (cookieAuthParams[cp1].split('=')[0].trim() == "adminAuth" && cookieAuthParams[cp1].split('=')[1].trim() == "true") {
				noAuth = "true"
			}*/
			if ($rootScope.adminAuth == "true") {
				noAuth = "true"
			}
		
	if (noAuth == "false") {
			$location.path('/loginPage');
		}
	
    $scope.remove = function () {
        var newDataList = [];
        $scope.selectedAll = false;
        angular.forEach($scope.tableUserContent, function (checked) {
            if (checked.checked) {
                newDataList.push(checked.userId);
            }
        });
        var selectedData = {
        		userIds:newDataList,
        		sessionInputDTO: $rootScope.sessionInputObj	
        }; 
        $http.put("/" + servicePrefix + "/rest/userSrv/delete",selectedData).then(function(response) {
            if(response.status === 200 && response.data.msgType === "Success"){
                ngDialog.close();
                ngDialog.openConfirm({
                    template: '<p>' + response.data.message + '</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                });
                
                var params={
                		userID: $rootScope.username,
                		userRole: $rootScope.userRole,
                		sessionInputDTO: $rootScope.sessionInputObj
                    };
                
                
                $http.post("/" + servicePrefix + "/rest/userSrv/displayAll",params).then(function(response){
                    if(response.status === 200){
                    	 if(response.data.userList != null){
                    		 $rootScope.tableUserContent = response.data.userList;
                             for(var i=0,arrLen = $rootScope.tableUserContent.length;i<arrLen;i++){
                             	if($rootScope.tableUserContent[i].validFrom){
                             		$rootScope.tableUserContent[i].validFrom = $rootScope.tableUserContent[i].validFrom.substr(0, 10);
                             	}
                             	if($rootScope.tableUserContent[i].validTo){
                             		$rootScope.tableUserContent[i].validTo = $rootScope.tableUserContent[i].validTo.substr(0, 10);
                             	
                             	
                                 }    
                             
                             }
                    	 } 
                    } else {
                    	      ngDialog.openConfirm({
                                  template: '<p>' +"No records found!"+ '</p>',
                                  plain: true,
                                  scope: $scope,
                                  closeByDocument: true,
                                  closeByEscape: true,
                                  showClose: true,
                                  height:120,
                                  width: 350,
                                  className:'ngdialog-theme-default CLASS_2'
                              }); 
                    }
                });
            }else if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
          	  $rootScope.checkAuthorization();
            }
            else if(response.status === 200 && response.data.msgType === "Error"){
                ngDialog.openConfirm({
                    template: '<p>' + response.data.message + '</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                });
            }
        });
    };
}]);