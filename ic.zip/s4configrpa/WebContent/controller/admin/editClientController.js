/*angular.module('yapp').controller('editClientController', ["$scope", "$rootScope", "$state"," $stateParams"," $location","$http","$ocLazyLoad", function($scope, $rootScope, $state, $stateParams, $location,$http,$ocLazyLoad)  
{
	$ocLazyLoad.load(controllerName+'/admin/editClientController.js?ver='+version);
        $scope.createClient = function(){
            $rootScope.username = $scope.username;
            $rootScope.password = $scope.password;
            $scope.submitted = true;

            var params={
                customerName: $scope.clientName,
                industryVertical: $scope.industryVertical,
                geographicRegion: $scope.geographicRegion,
                deliveryUnit: $scope.geographicUnit,
                operationalGroup: $scope.operationalGroup,
                implementationType: "",
                customerType: $scope.clientType,
                igPoc:$scope.igPoc,
                gdn_ogLead: $scope.gdnLead,
                omId: $scope.omID,
                status: ""
            };


            $http.post("/" + servicePrefix + "/rest/createClientService/createClient",params).then(function(response) {
                if(response.data.status===0){
                   // console.log("Success",response);
                }
                else {
               // console.log("Error",response);
              }
            });
        }
}]);*/