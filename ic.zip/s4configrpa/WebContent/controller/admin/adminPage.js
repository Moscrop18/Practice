/*angular.module('yapp').controller('adminPageController',["$scope", "$state", "$rootScope", "$http", "$mdDialog", "$mdMedia", "ngDialog", "$location", "$timeout","$ocLazyLoad", function($scope, $state, $rootScope, $http, $mdDialog, $mdMedia, ngDialog, $location, $timeout,$ocLazyLoad) {
$ocLazyLoad.load(controllerName+'/admin/adminPage.js?ver='+version);
var noAuth = "false";

var cookie = document.cookie;
	var cookieAuthParams = cookie.split(';');

		if (cookieAuthParams[cp1].split('=')[0].trim() == "adminAuth" && cookieAuthParams[cp1].split('=')[1].trim() == "true") {
			noAuth = "true"
		}
		if ($rootScope.adminAuth == "true") {
			noAuth = "true"
		}
	
if (noAuth == "false") {
		$location.path('/loginPage');
	}
$scope.logout = function(){
	ngDialog.close();
		$rootScope.initalCheck = undefined;
        $state.transitionTo('loginPage');
        $rootScope.username = "";
        $rootScope.password = "";
        $scope.deleteAllCookies();
        $rootScope.showLogsExportData = false;
    };
	//Idle Time out Logic - Start 	
	$scope.$on('IdleTimeout', function() {
	$location.path('/loginPage');
	   $mdDialog.show(
               $mdDialog.alert()
               .parent(angular.element(document.body))
               .clickOutsideToClose(true) 
               .title('Automatic log off')
               .textContent('successfully logged off')
               .ariaLabel('Alert Dialog Demo')
               .ok('Ok')
);
});
$scope.$on('IdleStart', function(ev) {
	ngDialog.close();
	$location.path('/loginPage');
       $mdDialog.show(
                        $mdDialog.alert()
                        .parent(angular.element(document.body))
                        .clickOutsideToClose(true)
                        .title('Automatic log off')
                        .textContent('Session has expired. Please logon again')
                        .ariaLabel('Alert Dialog Demo')
                        .ok('Ok')
                        .targetEvent(ev)
        );
});

Idle.watch();
//Idle Time out Logic - End 
	
}]);*/