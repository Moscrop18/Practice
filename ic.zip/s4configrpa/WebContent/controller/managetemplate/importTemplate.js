angular.module('yapp').controller('importTemplatePage',["ngDialog","$filter","Upload","$scope","$rootScope","$http","$mdDialog","$mdMedia","$location","$timeout","$window","ivhTreeviewMgr","ivhTreeviewBfs","ivhTreeviewOptions","tree","$ocLazyLoad", function(ngDialog,$filter,Upload,$scope,$rootScope,$http,$mdDialog,$mdMedia, $location, $timeout, $window,ivhTreeviewMgr, ivhTreeviewBfs, ivhTreeviewOptions,tree,$ocLazyLoad) {
	$ocLazyLoad.load(controllerName+'/managetemplate/importTemplate.js?ver='+version);
	if($rootScope.appValidity == undefined){
		
		 	$rootScope.username = "";
		    $rootScope.password = "";
		   /* var cookies = document.cookie.split(";");
		    for (var i = 0,arrLen = cookies.length; i < arrLen ; i++) {
		        var cookie = cookies[i];
		        var eqPos = cookie.indexOf("=");
		        var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
		        document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
		    }*/
		    $location.path('/loginPage');
	}
	var noAuth = "false";
//	var cookie = document.cookie;
//	
//		var cookieAuthParams = cookie.split(';');
//		for (var cp1 = 0,arrLen = cookieAuthParams.length; cp1 < arrLen ; cp1++) {
			/*if (cookieAuthParams[cp1].split('=')[0].trim() == "adminAuth" || cookieAuthParams[cp1].split('=')[0].trim() == "configAuth" && cookieAuthParams[cp1].split('=')[1].trim() == "true") {
				noAuth = "true"
			}*/
			 if ($rootScope.adminAuth == "true" || $rootScope.configAuth == "true") {
					noAuth = "true"
				}
	/*		if($rootScope.appValidity == undefined){
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userDetails") {
					$rootScope.userValidation = cookieAuthParams[cp1].split('=')[1];
					console.log($rootScope.userValidation.role);
					
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userRole") {
					$rootScope.userRole = cookieAuthParams[cp1].split('=')[1];
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "roleId") {
					$rootScope.roleId = cookieAuthParams[cp1].split('=')[1];
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userName") {
					$rootScope.username = cookieAuthParams[cp1].split('=')[1];
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userFirstName") {
					 $rootScope.userFirstName = cookieAuthParams[cp1].split('=')[1];
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userLastName") {
					$rootScope.userLastName = cookieAuthParams[cp1].split('=')[1];
				}
		  }
		}*/
	if (noAuth == "false") {
			$location.path('/loginPage');
		}
	if(document.getElementById("form-container") != null)
	document.getElementById("form-container").style.display="none";
	if($rootScope.userRole == "TAdmin"){
	document.getElementById("mySidenav").style.display = "none";
	if(document.getElementById("showSubMenu") != null)
		document.getElementById("showSubMenu").style.display = "none";
	document.getElementById("hambrgrCloseMenu").style.display = "none";
	document.getElementById("hambrgrMenu").style.display = "inline-block";
	}
	$scope.create ={};
	$scope.create.templateType  ="1";
	 if($rootScope.industryFlag){
		 $scope.create.templateType  ="4";
	 }
	
	$scope.yes ="true"
	$rootScope.show = false;
	$scope.yes ="true"
	$scope.no ="true"
	$rootScope.helpPage = "true";
	$scope.inputMessage = "";
	$rootScope.clientimghierarchy = true;
	var downloadCount = 0;
	$scope.currentPage = 1;
	$scope.articlesPerPage = 6;
	if($rootScope.userRole == "TAdmin" ||$rootScope.userRole == "PAdmin" ||$rootScope.userRole == "TempAd" ){
		$rootScope.allindustry=undefined;
		$rootScope.allSubindustry=undefined;
	}
	if($rootScope.adminAuth == "true"){
		
		$rootScope.importtempUser = true;
		$rootScope.createTemplateUser = true;
		$rootScope.downloadtempUser = true;
	}
	//$rootScope.createimg = false;
	$rootScope.previewHierarchy = false;

	if($rootScope.scopevalueArrays1 == undefined)
	$rootScope.scopevalueArrays1 =[];
	if($rootScope.scopevalueArrays == undefined)
	$rootScope.scopevalueArrays = [];
	if($rootScope.selectedScopeData == undefined)
		$rootScope.selectedScopeData = [];
	if($rootScope.selectedid == undefined)	
		$rootScope.selectedid= [];
	if($rootScope.selectedid[0] == undefined)	
		$rootScope.selectedid[0] = [];
	$rootScope.selectedTreeviewData=[];	 
	$rootScope.selectedTreeviewDatas=[];
	$rootScope.selectedTreeviewDatas1=[];
	$rootScope.invaliduploadedlist = [];
	$scope.createtemplate = {};
	$scope.createTempDone = true;
	$scope.downloadTempDone = true;
	$scope.imgId={};
	
	
	
	if($rootScope.selectedRootScopeData == undefined)
	       {
	              $rootScope.selectedRootScopeData = [];
	       } 
	        angular.copy($rootScope.selectedRootScopeData,$rootScope.selectedTreeviewData);
	       
	        
	      if($rootScope.selectedRootScopeDatas == undefined)
		       {
		              $rootScope.selectedRootScopeDatas = [];
		       } 
		     angular.copy($rootScope.selectedRootScopeDatas,$rootScope.selectedTreeviewDatas);
	        
		        
		        
		   if($rootScope.selectedRootScopeDatas1 == undefined)
			       {
			              $rootScope.selectedRootScopeDatas1 = [];
			       } 
		  
		   
			  angular.copy($rootScope.selectedRootScopeDatas1,$rootScope.selectedTreeviewDatas1);
				var list;
				$scope.itemsByPage=15;
				 $scope.arrayImg =[];
				 $scope.fileNameList =[];
				 $scope.currentPage = 1;
				$scope.isAll = false;
			    $scope.selectAllFriends = function () {
			        if ($scope.isAll === false) {
			            angular.forEach($rootScope.selectedRootScopeDatas, function (x) {
			                x.checked = true;
			            });
			            $scope.isAll = true;
			        } else {
			            angular.forEach($rootScope.selectedRootScopeDatas, function (x) {
			                x.checked = false;
			            });
			            $scope.isAll = false;
			        }
			    };
			    $scope.myClickTab1 = function(){
			    	$rootScope.allindustry=undefined;
					$rootScope.allSubindustry=undefined;
			    	$rootScope.isManagetemplate = true;
			    	$rootScope.scopevalues="";
			    	$rootScope.scopevaluesData="";
			    	$rootScope.scopevaluesData1="";
			        $rootScope.treeDataPath =[];
			    	$rootScope.scopevalueArrays=[];
			    	$rootScope.scopevalueArray=[];
			    	$rootScope.selectedRootScopeDatas=[];
			    	$rootScope.selectedRootScopeData=[];
			    	$rootScope.previouslySelectedTab = $rootScope.selectedTab;
			    	$rootScope.scopevalueArray = [];
			    	$rootScope.scopevalueArrays = [];
			    	$rootScope.selectedTab = "tab1";	
			    	$scope.createtemplate.selectedSysId ="";
			    	angular.element("input[type='file']").val(null);
			    	$rootScope.downloadScopeList=[];
			    	$scope.getIndustry();
			    };
			    $scope.myClickTab2 = function(){ 
			    	$rootScope.allindustry=undefined;
					$rootScope.allSubindustry=undefined;
			    	$rootScope.isManagetemplate = true;
			    	$rootScope.scopevalues="";
			    	$rootScope.scopevaluesData1="";
			    	$rootScope.downloadScopeList=[];
			    	$rootScope.scopevalueArrays1=[];
			    	$rootScope.scopevalueArray=[];
			    	$rootScope.selectedRootScopeDatas1=[];
			    	$rootScope.selectedRootScopeDatas=[];
			    	$rootScope.previouslySelectedTab = $rootScope.selectedTab;
			    	$rootScope.selectedTab = "tab2";	
			    	$rootScope.selectedTreeviewData = [];
			    	$rootScope.selectedRootScopeData = [];
			    	$rootScope.scopevalueArrays1 = [];
			    	$rootScope.scopevalueArrays = [];
			    	angular.element("input[type='file']").val(null);
			    	$rootScope.scopevaluesData="";
			    	$scope.getIndustry();
			    	
			    };
			    
			    $scope.myClickTab3 = function(){
			    	$rootScope.isManagetemplate = true;
			    	$rootScope.scopevaluesData1="";
				    $rootScope.scopevaluesData="";
				    $rootScope.treeDataPath =[];
			    	$rootScope.scopevalueArrays1=[];
			    	$rootScope.scopevalueArrays=[];
				    $rootScope.selectedRootScopeDatas1=[];
			    	$rootScope.selectedRootScopeData=[];
				    $rootScope.downloadScopeList=[];
			    	$rootScope.previouslySelectedTab = $rootScope.selectedTab;
			    	$rootScope.selectedTab = "tab3";
			    	$rootScope.scopevalueArrays1 = [];
			    	$rootScope.scopevalueArray = []
			    	angular.element("input[type='file']").val(null);
			    	if($rootScope.userRole == "TAdmin" ||$rootScope.userRole == "PAdmin" ||$rootScope.userRole == "TempAd" ){
			    		$rootScope.allindustry=undefined;
			    		$rootScope.allSubindustry=undefined;
			    		$scope.getIndustry();
			    	}
			     
			    };
			    
			    
		var hierarchyData =[];
		
		
	    /*$http.get("/" + servicePrefix + "/rest/imgHierarchySrv/viewImgHierarchy").then(function(response) {
		    if(response.status === 200){
		    	
		    	  if(response.data != null){
		    	var responsedata=[];
		    	$rootScope.hierarchyData = [];
		        responsedata.push(response.data);
		        $rootScope.listData = responsedata;	
		        $rootScope.hierarchyData.push(response.data);
		        console.log($rootScope.hierarchyData);
		    	  }else{
		    	      ngDialog.openConfirm({
		                    template: '<p>' +"No records found!"+ '</p>',
		                    plain: true,
		                    scope: $scope,
		                    closeByDocument: true,
		                    closeByEscape: true,
		                    showClose: true,
		                    height:120,
		                    width: 350,
		                    className:'ngdialog-theme-default CLASS_2'
		                });  
		    	  }
		    } else {
		        ngDialog.openConfirm({
	                template: '<p>' +"No records found!"+ '</p>',
	                plain: true,
	                scope: $scope,
	                closeByDocument: true,
	                closeByEscape: true,
	                showClose: true,
	                height:120,
	                width: 350,
	                className:'ngdialog-theme-default CLASS_2'
	            }); 
		    }
		});*/
		$scope.init = function(){
			
			
		if($rootScope.userRole == "Config")
			{
	    	$rootScope.previouslySelectedTab = $rootScope.selectedTab;

		    	$rootScope.selectedTab = "tab3";
		    	//document.getElementById("tab1").style.display="none";
		    	//document.getElementById("tab2").style.display="none";
			}
			
		if($rootScope.userRole == "TempAd"){
			if($rootScope.importtempUser == undefined){
			$rootScope.importtempUser = false;
			$rootScope.createTemplateUser = false;
			$rootScope.downloadtempUser = false;
			}
	    	$rootScope.selectedTab = "tab1";
	    	$rootScope.previouslySelectedTab = $rootScope.selectedTab;
	    	var paramsData={    
					 roleId: $rootScope.userRole,
					 sessionInputDTO : $rootScope.sessionInputObj           
			        };
	    	 $http.post("/" + servicePrefix + "/rest/authorizationSrv/getAuthorizationIds", paramsData).then(function(response) {
	    		 if(response.status === 200){
	    			 if(response.status === 200 && response.data.resMessageDto != null && response.data.resMessageDto.message === serviceMessage){
		            	  $rootScope.checkAuthorization();
		              }else if(response.data.actionIdList != null){
		        		  for (var i = 0,arrLen = response.data.actionIdList.length; i < arrLen; i++) {	
		        		  
		        			  if(response.data.actionIdList[i]==="CreateTemplate"){		        				
		        				 $scope.createTemplateUser = true;  
		        				
		        				 /* $scope.importtempUser = false;
		        				  $scope.downloadtempUser = false;*/
			        		  }else if(response.data.actionIdList[i]==="ImportTemplate"){
			        			  $scope.importtempUser = true;
			        			
			        			 /* $rootScope.createTemplateUser = false;
			        			  $scope.downloadtempUser = false;*/
			        		  }else if(response.data.actionIdList[i]==="DownloadTemplate"){
			        			  $scope.downloadtempUser = true;
			        			 
			        			 /* $rootScope.createTemplateUser = false;
			        			  $scope.importtempUser = false;*/
			        		
			        		  }
		        		  }
		        		  }
	    		 }
	    	 });
	    	

		}
		if($rootScope.userRole == "TempCr"){
	    	$rootScope.importtempUser = false;

		}
		
	/*$http({
        method: "GET",
        url: "/" + servicePrefix + "/rest/configSrv/getTargetSystemDetails/"+$rootScope.username,
        headers:{
            'authorization' :  $rootScope.userValidation.userToken
            }
    }*/ $http.post("/" + servicePrefix + "/rest/configSrv/getTargetSystemDetails", $rootScope.sessionInputObj).then(function mySucces(response) {
 
        if (response.data.dataList !=null) {
        	 if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
    	      		$rootScope.checkAuthorization();
    	      	}
        	 else {
        		 var source = response.data.dataList;
        		 var result = []; 
            	 for (var i = 0,arrLen = source.length; i < arrLen ; i++) {
            		var downloadFilesPath = {
                         "destinationName": source[i]+"-"+"S4 HANA"
                
                     };
                    	result.push(downloadFilesPath);
                     
                 }
            	 
            	 $rootScope.sourceSystem = result; 
        	}
        }
 	   
 	   
    }, function myError(response) {
        //            $scope.userValidation = response.statusText;
    });   
	/*$http.get("/" + servicePrefix + "/rest/imgHierarchySrv/viewImgHierarchy").then(function(response) {
	    if(response.status === 200){
	    	
	    	  if(response.data != null){
	    	var responsedata=[];
	    	$rootScope.hierarchyData = [];
	        responsedata.push(response.data);
	        $rootScope.listData = responsedata;	
	        $rootScope.hierarchyData.push(response.data);
	        console.log($rootScope.hierarchyData);
	    	  }else{
	    	      ngDialog.openConfirm({
	                    template: '<p>' +"No records found!"+ '</p>',
	                    plain: true,
	                    scope: $scope,
	                    closeByDocument: true,
	                    closeByEscape: true,
	                    showClose: true,
	                    height:120,
	                    width: 350,
	                    className:'ngdialog-theme-default CLASS_2'
	                });  
	    	  }
	    } else {
	        ngDialog.openConfirm({
                template: '<p>' +"No records found!"+ '</p>',
                plain: true,
                scope: $scope,
                closeByDocument: true,
                closeByEscape: true,
                showClose: true,
                height:120,
                width: 350,
                className:'ngdialog-theme-default CLASS_2'
            }); 
	    }
	});*/
    
 };
	
 
	
 $scope.treeData = function(){

	 var imgPreviewInputDto = {
			  selectedArea:"Cross Industry",
			  sessionInputDTO: $rootScope.sessionInputObj
      };

	$scope.myPromise = $http({
   	method: 'POST',
   	url:"/" + servicePrefix + "/rest/imgHierarchySrv/viewImgHierarchy",
   	data : imgPreviewInputDto
    }).then(function(response) {
			    if(response.status === 200){
			    	
			    	  if(response.data != null){
			    		  if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
			       	      		$rootScope.checkAuthorization();
			       	      	}
			    	else{
			    	var responsedata=[];
			    	$rootScope.hierarchyData = [];
			    	$rootScope.hierarchyData1 = [];
			        responsedata.push(response.data);
			        $rootScope.listData = responsedata;	
			        //return responsedata;
			        $rootScope.hierarchyData.push(response.data);
			        $rootScope.hierarchyData1.push(response.data);
			    	  }
			       // console.log($rootScope.hierarchyData);
			    	  }else{
			    	      ngDialog.openConfirm({
			                    template: '<p>' +"No records found!"+ '</p>',
			                    plain: true,
			                    scope: $scope,
			                    closeByDocument: true,
			                    closeByEscape: true,
			                    showClose: true,
			                    height:120,
			                    width: 350,
			                    className:'ngdialog-theme-default CLASS_2'
			                });  
			    	  }
			    } else {
			        ngDialog.openConfirm({
		                template: '<p>' +"No records found!"+ '</p>',
		                plain: true,
		                scope: $scope,
		                closeByDocument: true,
		                closeByEscape: true,
		                showClose: true,
		                height:120,
		                width: 350,
		                className:'ngdialog-theme-default CLASS_2'
		            }); 
			    }
			});
 
 };

 if(!$rootScope.configDownloadTemplate)
 $rootScope.hierarchyData = $scope.treeData();
		
    $scope.itemsByPage=15;
	 $scope.arrayImg =[];
	 $scope.fileNameList =[];
	 $scope.currentPage = 1;
	 var downloadCount = 0;
		
		$scope.articlesPerPage = 6;
	$scope.startCreate = function(){
		

    	$rootScope.overlay_admin = document.getElementById("overlay");
		$rootScope.popup_admin = document.getElementById("busy");
		$rootScope.overlay_admin.style.display = "block";
		$rootScope.popup_admin.style.display = "inline-block";
		$scope.expandNodes = false;
		$rootScope.create={};
		$rootScope.create.templateType="1";
		$rootScope.industry = false;
		$rootScope.createimg = false;
		/*$rootScope.selectedRootScopeDatas1=[];*/
    	ngDialog.openConfirm({
    		// template: 'popupcreateTmpl.html?ver='+version,
    		template: 'view/managetemplate/viewTreeUI.html?ver='+version,
            preCloseCallback:function(){   
            	$mdDialog.cancel();
            	if($rootScope.validClose == undefined){ 
            		$rootScope.selectedRootScopeDatas1 = $rootScope.selectedTreeviewDatas1;	 
	   	       		$rootScope.scopevalueArrays1=[];
	   	       		 for(var x = 0,arrLen = $rootScope.selectedRootScopeDatas1.length; x < arrLen ; x++){
	   	          		  if($rootScope.selectedRootScopeDatas1[x].enabled === 1){
	   	          		  if(x == 0)
	   	          		  { 	
	   	          			
	   	          			  $rootScope.scopevalueArrays1.push($rootScope.selectedRootScopeDatas1[x].imgId);
	   	          		}
	   	          		  else{
	   	          			
	   	          			  $rootScope.scopevalueArrays1.push($rootScope.selectedRootScopeDatas1[x].imgId);
	   	          			  }
	   	          	  }
	   	          	  }
   	       		 
            	}else{
            		$rootScope.validClose = undefined;
            		//$scope.createtableValues
            	}
            	
            },
//            controller:'importTemplatePage',
            scope: $scope,
            closeByDocument: false,
            closeByEscape: false,
            showClose: true,
            height: 550,
            width: 1146
        });
    };
	$scope.startCreateForCopy = function(){
		

    	$rootScope.overlay_admin = document.getElementById("overlay");
		$rootScope.popup_admin = document.getElementById("busy");
		$rootScope.overlay_admin.style.display = "block";
		$rootScope.popup_admin.style.display = "inline-block";
		$scope.expandNodes = false;
		$rootScope.create={};
		$rootScope.create.templateType="3";
		$rootScope.industry = false;
		$rootScope.createimg = false;
		/*$rootScope.selectedRootScopeDatas1=[];*/
    	ngDialog.openConfirm({
    		// template: 'popupcreateTmpl.html?ver='+version,
    		template: 'view/managetemplate/viewTreeUI.html?ver='+version,
            preCloseCallback:function(){   
            	$mdDialog.cancel();
            	if($rootScope.validClose == undefined){ 
            		$rootScope.selectedRootScopeDatas1 = $rootScope.selectedTreeviewDatas1;	 
	   	       		$rootScope.scopevalueArrays1=[];
	   	       		 for(var x = 0,arrLen = $rootScope.selectedRootScopeDatas1.length; x < arrLen ; x++){
	   	          		  if($rootScope.selectedRootScopeDatas1[x].enabled === 1){
	   	          		  if(x == 0)
	   	          		  { 	
	   	          			
	   	          			  $rootScope.scopevalueArrays1.push($rootScope.selectedRootScopeDatas1[x].imgId);
	   	          		}
	   	          		  else{
	   	          			
	   	          			  $rootScope.scopevalueArrays1.push($rootScope.selectedRootScopeDatas1[x].imgId);
	   	          			  }
	   	          	  }
	   	          	  }
   	       		 
            	}else{
            		$rootScope.validClose = undefined;
            		//$scope.createtableValues
            	}
            	
            },
//            controller:'importTemplatePage',
            scope: $scope,
            closeByDocument: false,
            closeByEscape: false,
            showClose: true,
            height: 550,
            width: 1146
        });
    };
	$scope.startCreateForIndustry = function(selectedIndustry,selectedsubIndustry){
		
    	$rootScope.overlay_admin = document.getElementById("overlay");
		$rootScope.popup_admin = document.getElementById("busy");
		$rootScope.overlay_admin.style.display = "block";
		$rootScope.popup_admin.style.display = "inline-block";
		$scope.expandNodes = false;
		$rootScope.create={};
		$rootScope.create.templateType="4";
		$rootScope.industry = true;
		$rootScope.selectedIndustry=selectedIndustry;
		$rootScope.selectedsubIndustry=selectedsubIndustry;
		$scope.getIndustryAlias();
		$rootScope.createimg = false;
		/*$rootScope.selectedRootScopeDatas1=[];*/
    	ngDialog.openConfirm({
    		// template: 'popupcreateTmpl.html?ver='+version,
    		template: 'view/managetemplate/viewTreeUI.html?ver='+version,
    		
            preCloseCallback:function(){   
            	$mdDialog.cancel();
            	if($rootScope.validClose == undefined){ 
            		$rootScope.selectedRootScopeDatas1 = $rootScope.selectedTreeviewDatas1;	 
	   	       		$rootScope.scopevalueArrays1=[];
	   	       		 for(var x = 0,arrLen = $rootScope.selectedRootScopeDatas1.length; x < arrLen ; x++){
	   	          		  if($rootScope.selectedRootScopeDatas1[x].enabled === 1){
	   	          		  if(x == 0)
	   	          		  { 	
	   	          			
	   	          			  $rootScope.scopevalueArrays1.push($rootScope.selectedRootScopeDatas1[x].imgId);
	   	          		}
	   	          		  else{
	   	          			
	   	          			  $rootScope.scopevalueArrays1.push($rootScope.selectedRootScopeDatas1[x].imgId);
	   	          			  }
	   	          	  }
	   	          	  }
   	       		 
            	}else{
            		$rootScope.validClose = undefined;
            		//$scope.createtableValues
            	}
            	
            },
//            controller:'importTemplatePage',
            scope: $scope,
            closeByDocument: false,
            closeByEscape: false,
            showClose: true,
            height: 550,
            width: 1146
        });
    };
    $scope.startImport = function(){
    	
    	$rootScope.overlay_admin = document.getElementById("overlay");
		$rootScope.popup_admin = document.getElementById("busy");
		$rootScope.overlay_admin.style.display = "block";
		$rootScope.popup_admin.style.display = "inline-block";
		$scope.expandNodes = false;
		$rootScope.create={};
		$rootScope.create.templateType="1";
		$rootScope.industry = false;
		$rootScope.createimg = false;
		/*$rootScope.selectedRootScopeData=[];*/
    	ngDialog.openConfirm({
    		
    		// template: 'popupcreateTmpl.html?ver='+version,
    		 template: 'view/managetemplate/viewTreeUI.html?ver='+version,
            preCloseCallback:function(){

            	if($rootScope.validClose == undefined){
            		$rootScope.selectedRootScopeData = $rootScope.selectedTreeviewData;
   	       		 	/*$rootScope.scopevalues = "";*/
	   	       		 $rootScope.scopevalueArray=[];
	   	       		 for(var x = 0; x < $rootScope.selectedRootScopeData.length; x++){
	   	          		  if($rootScope.selectedRootScopeData[x].enabled === 1){
	   	          		  if(x == 0)
	   	          		  { 	
	   	          			  $rootScope.scopevalues = $rootScope.selectedRootScopeData[x].imgId;
	   	          			  $rootScope.scopevalueArray.push($rootScope.selectedRootScopeData[x].imgId);
	   	          		}
	   	          		  else{
	   	          			  $rootScope.scopevalues = $rootScope.scopevalues.concat(";",$rootScope.selectedRootScopeData[x].imgId);
	   	          			  $rootScope.scopevalueArray.push($rootScope.selectedRootScopeData[x].imgId);
	   	          			  }
	   	          	  }
	   	          	  }
   	       		 
            	}else{
            		$rootScope.validClose = undefined;
            	}
            	
            },
//            controller:'importTemplatePage',
            scope: $scope,
            closeByDocument: false,
            closeByEscape: false,
            showClose: true,
            height:550,
            width: 1146
        });
    };
    
    $scope.startImportForCopy = function(){
    	
    	$rootScope.overlay_admin = document.getElementById("overlay");
		$rootScope.popup_admin = document.getElementById("busy");
		$rootScope.overlay_admin.style.display = "block";
		$rootScope.popup_admin.style.display = "inline-block";
		$scope.expandNodes = false;
		$rootScope.create={};
		$rootScope.create.templateType="3";
		$rootScope.industry = false;
		$rootScope.createimg = false;
		/*$rootScope.selectedRootScopeData=[];*/
    	ngDialog.openConfirm({
    		
    		// template: 'popupcreateTmpl.html?ver='+version,
    		 template: 'view/managetemplate/viewTreeUI.html?ver='+version,
            preCloseCallback:function(){

            	if($rootScope.validClose == undefined){
            		$rootScope.selectedRootScopeData = $rootScope.selectedTreeviewData;
   	       		 	/*$rootScope.scopevalues = "";*/
	   	       		 $rootScope.scopevalueArray=[];
	   	       		 for(var x = 0; x < $rootScope.selectedRootScopeData.length; x++){
	   	          		  if($rootScope.selectedRootScopeData[x].enabled === 1){
	   	          		  if(x == 0)
	   	          		  { 	
	   	          			  $rootScope.scopevalues = $rootScope.selectedRootScopeData[x].imgId;
	   	          			  $rootScope.scopevalueArray.push($rootScope.selectedRootScopeData[x].imgId);
	   	          		}
	   	          		  else{
	   	          			  $rootScope.scopevalues = $rootScope.scopevalues.concat(";",$rootScope.selectedRootScopeData[x].imgId);
	   	          			  $rootScope.scopevalueArray.push($rootScope.selectedRootScopeData[x].imgId);
	   	          			  }
	   	          	  }
	   	          	  }
   	       		 
            	}else{
            		$rootScope.validClose = undefined;
            	}
            	
            },
//            controller:'importTemplatePage',
            scope: $scope,
            closeByDocument: false,
            closeByEscape: false,
            showClose: true,
            height:550,
            width: 1146
        });
    };
 $scope.startImportForIndustry = function(selectedIndustry,selectedsubIndustry){
    	
    	$rootScope.overlay_admin = document.getElementById("overlay");
		$rootScope.popup_admin = document.getElementById("busy");
		$rootScope.overlay_admin.style.display = "block";
		$rootScope.popup_admin.style.display = "inline-block";
		$scope.expandNodes = false;
		$rootScope.create={};
		$rootScope.create.templateType="4";
		$rootScope.industry = true;
		$rootScope.selectedIndustry=selectedIndustry;
		$rootScope.selectedsubIndustry=selectedsubIndustry;
		$rootScope.createimg = false;
			$scope.getIndustryAlias();
		
		/*$rootScope.selectedRootScopeData=[];*/
    	ngDialog.openConfirm({
    		
    		// template: 'popupcreateTmpl.html?ver='+version,
    		 template: 'view/managetemplate/viewTreeUI.html?ver='+version,
            preCloseCallback:function(){

            	if($rootScope.validClose == undefined){
            		$rootScope.selectedRootScopeData = $rootScope.selectedTreeviewData;
   	       		 	/*$rootScope.scopevalues = "";*/
	   	       		 $rootScope.scopevalueArray=[];
	   	       		 for(var x = 0; x < $rootScope.selectedRootScopeData.length; x++){
	   	          		  if($rootScope.selectedRootScopeData[x].enabled === 1){
	   	          		  if(x == 0)
	   	          		  { 	
	   	          			  $rootScope.scopevalues = $rootScope.selectedRootScopeData[x].imgId;
	   	          			  $rootScope.scopevalueArray.push($rootScope.selectedRootScopeData[x].imgId);
	   	          		}
	   	          		  else{
	   	          			  $rootScope.scopevalues = $rootScope.scopevalues.concat(";",$rootScope.selectedRootScopeData[x].imgId);
	   	          			  $rootScope.scopevalueArray.push($rootScope.selectedRootScopeData[x].imgId);
	   	          			  }
	   	          	  }
	   	          	  }
   	       		 
            	}else{
            		$rootScope.validClose = undefined;
            	}
            	
            },
//            controller:'importTemplatePage',
            scope: $scope,
            closeByDocument: false,
            closeByEscape: false,
            showClose: true,
            height:550,
            width: 1146
        });
    };
    
    $scope.startDownload = function(){
    	
    	$rootScope.overlay_admin = document.getElementById("overlay");
		$rootScope.popup_admin = document.getElementById("busy");
		$rootScope.overlay_admin.style.display = "block";
		$rootScope.popup_admin.style.display = "inline-block";
		$scope.expandNodes = false;
		$rootScope.create={};
		$rootScope.create.templateType="1";
		$rootScope.copy=false;
		$rootScope.industry = false;
		
		if($rootScope.userRole == "Config"){
			$rootScope.createimg = true;
		}else{
			$rootScope.createimg = false;
		}
			
		/*$rootScope.selectedRootScopeDatas=[];*/
    	ngDialog.openConfirm({
   		 
    	
    		// template: 'popupcreateTmpl.html?ver='+version,
    		
    			template: 'view/managetemplate/viewTreeUI.html?ver='+version ,
            preCloseCallback:function(){
                var bDatas={};
            	if($rootScope.validClose == undefined){
            		$rootScope.selectedRootScopeDatas = $rootScope.selectedTreeviewDatas;
            		
   	       		 	/*$rootScope.scopevaluesData = "";*/
	   	       		 $rootScope.scopevalueArrays=[];
	   	       		 for(var x = 0,arrLen = $rootScope.selectedRootScopeDatas.length; x < arrLen ; x++){
	   	          		  if($rootScope.selectedRootScopeDatas[x].enabled === 1){
	   	          		  if(x == 0)
	   	          		  { 	
	   	          			  $rootScope.scopevaluesData = $rootScope.selectedRootScopeDatas[x].imgId;
	   	          			  $rootScope.scopevalueArrays.push($rootScope.selectedRootScopeDatas[x].imgId);
	   	          		}
	   	          		  else{
	   	          			  $rootScope.scopevaluesData = $rootScope.scopevaluesData.concat(";",$rootScope.selectedRootScopeDatas[x].imgId);
	   	          			  $rootScope.scopevalueArrays.push($rootScope.selectedRootScopeDatas[x].imgId);
	   	    
	   	          			  }
	   	          	  }
	   	          	  }
   	       		 
            	}else{
            		$rootScope.validClose = undefined;
            	}
            	
            }, 
//            controller:'importTemplatePage',
            scope: $scope,
            closeByDocument: false,
            closeByEscape: false,
            showClose: true,
            height: 550,
            width: 1146
        });
    };
    
    $scope.startDownloadForCopy = function(){
    	
    	$rootScope.overlay_admin = document.getElementById("overlay");
		$rootScope.popup_admin = document.getElementById("busy");
		$rootScope.overlay_admin.style.display = "block";
		$rootScope.popup_admin.style.display = "inline-block";
		$scope.expandNodes = false;
		$rootScope.create={};
		$rootScope.create.templateType="3";
		$rootScope.copy=true;
		$rootScope.industry = false;
		if($rootScope.userRole == "Config"){
			$rootScope.createimg = true;
		}else{
			$rootScope.createimg = false;
		}
		/*$rootScope.selectedRootScopeDatas=[];*/
    	ngDialog.openConfirm({
    		
    			template: 'view/managetemplate/viewTreeUI.html?ver='+version ,
            preCloseCallback:function(){
                var bDatas={};
            	if($rootScope.validClose == undefined){
            		$rootScope.selectedRootScopeDatas = $rootScope.selectedTreeviewDatas;
            		
   	       		 	/*$rootScope.scopevaluesData = "";*/
	   	       		 $rootScope.scopevalueArrays=[];
	   	       		 for(var x = 0,arrLen = $rootScope.selectedRootScopeDatas.length; x < arrLen ; x++){
	   	          		  if($rootScope.selectedRootScopeDatas[x].enabled === 1){
	   	          		  if(x == 0)
	   	          		  { 	
	   	          			  $rootScope.scopevaluesData = $rootScope.selectedRootScopeDatas[x].imgId;
	   	          			  $rootScope.scopevalueArrays.push($rootScope.selectedRootScopeDatas[x].imgId);
	   	          		}
	   	          		  else{
	   	          			  $rootScope.scopevaluesData = $rootScope.scopevaluesData.concat(";",$rootScope.selectedRootScopeDatas[x].imgId);
	   	          			  $rootScope.scopevalueArrays.push($rootScope.selectedRootScopeDatas[x].imgId);
	   	    
	   	          			  }
	   	          	  }
	   	          	  }
   	       		 
            	}else{
            		$rootScope.validClose = undefined;
            	}
            	
            }, 
            scope: $scope,
            closeByDocument: false,
            closeByEscape: false,
            showClose: true,
            height: 550,
            width: 1146
        });
    };
$scope.startDownloadForIndustry = function(selectedIndustry,selectedsubIndustry){
    	
    	$rootScope.overlay_admin = document.getElementById("overlay");
		$rootScope.popup_admin = document.getElementById("busy");
		$rootScope.overlay_admin.style.display = "block";
		$rootScope.popup_admin.style.display = "inline-block";
		$scope.expandNodes = false;
		$rootScope.create={};
		$rootScope.create.templateType="4";
		$rootScope.copy=false;
		$rootScope.industry = true;
	
		if($rootScope.userRole == "TAdmin" ||$rootScope.userRole == "PAdmin" ||$rootScope.userRole == "TempAd" ){
			$rootScope.selectedIndustry=selectedIndustry;
			$rootScope.selectedsubIndustry=selectedsubIndustry;
			
		}
		$scope.getIndustryAlias();
		if($rootScope.userRole == "Config"){
			$rootScope.createimg = true;
		}else{
			$rootScope.createimg = false;
		}
		
		/*$rootScope.selectedRootScopeDatas=[];*/
    	ngDialog.openConfirm({
    		
    			template: 'view/managetemplate/viewTreeUI.html?ver='+version ,
            preCloseCallback:function(){
                var bDatas={};
            	if($rootScope.validClose == undefined){
            		$rootScope.selectedRootScopeDatas = $rootScope.selectedTreeviewDatas;
            		
   	       		 	/*$rootScope.scopevaluesData = "";*/
	   	       		 $rootScope.scopevalueArrays=[];
	   	       		 for(var x = 0,arrLen = $rootScope.selectedRootScopeDatas.length; x < arrLen ; x++){
	   	          		  if($rootScope.selectedRootScopeDatas[x].enabled === 1){
	   	          		  if(x == 0)
	   	          		  { 	
	   	          			  $rootScope.scopevaluesData = $rootScope.selectedRootScopeDatas[x].imgId;
	   	          			  $rootScope.scopevalueArrays.push($rootScope.selectedRootScopeDatas[x].imgId);
	   	          		}
	   	          		  else{
	   	          			  $rootScope.scopevaluesData = $rootScope.scopevaluesData.concat(";",$rootScope.selectedRootScopeDatas[x].imgId);
	   	          			  $rootScope.scopevalueArrays.push($rootScope.selectedRootScopeDatas[x].imgId);
	   	    
	   	          			  }
	   	          	  }
	   	          	  }
   	       		 
            	}else{
            		$rootScope.validClose = undefined;
            	}
            	
            }, 
            scope: $scope,
            closeByDocument: false,
            closeByEscape: false,
            showClose: true,
            height: 550,
            width: 1146
        });
    };
/*    var self = this;
    
    self.hierarchyData = $rootScope.hierarchyData;
  
  self.changeCallback = function(node) {*/
	  
	  $scope.changeCallback = function(node) {
	    self.lastChangedNode = node;
	    $rootScope.scopevalues = "";
  	  $rootScope.scopevaluesData ="";
  	  $rootScope.treeData = [];
  	  $rootScope.scopevalueArray=[];
  	  $rootScope.scopevalueArrays=[];
  	  $rootScope.scopevalueArrays1=[];
  	 $rootScope.downloadScopeList = [];	
	    var selectedTabsData = $rootScope.selectedTab;	 
  	  if(selectedTabsData ==="tab1"){ 
  		
  		 $scope.selectedMethod(node,node.selected);  
  	        var scopeArray1 = {};
  	        $rootScope.selectedScopeData.sort(function(a, b) {
  	                 return parseInt(a.sequence) - parseFloat(b.sequence);
  	             });
  	     for(var x = 0,arrLen = $rootScope.selectedRootScopeDatas1.length; x < arrLen ; x++){
  	               if($rootScope.selectedRootScopeDatas1[x].enabled =="1"){
  	               if(x == 0){
  	                     $rootScope.scopevaluesData1 = $rootScope.selectedRootScopeDatas1[x].imgId;
  	                     $rootScope.scopevalueArrays1.push($rootScope.selectedRootScopeDatas1[x].imgId);
  	                     if(node.children !== null && node.children.length > 0)
  	                 	{
  	                 	 	$rootScope.selectedimg.push(node.id);
  	                 	}
  	                    scopeArray1.imgId = $rootScope.selectedRootScopeDatas1[x].imgId;
  	     				scopeArray1.imgDesc = $rootScope.selectedRootScopeDatas1[x].imgDescription;
  	     				scopeArray1.seqNumber =  $rootScope.selectedRootScopeDatas1[x].sequence;
  	     				scopeArray1.bytes = null;
  	     				scopeArray1.resError = "Download Not yet Started";
  	     				scopeArray1.scopeAvilableIcon = "glyphicon glyphicon-remove";
  	     				scopeArray1.downloadStatusIcon = "glyphicon glyphicon-remove";
  	     				 $rootScope.downloadScopeList.push(scopeArray1);	 
  	     				scopeArray1={};
  	               }
  	               else{
  	               
  	                     $rootScope.scopevaluesData1 = $rootScope.scopevaluesData1.concat(";",$rootScope.selectedRootScopeDatas1[x].imgId);
  	                     $rootScope.scopevalueArrays1.push($rootScope.selectedRootScopeDatas1[x].imgId); 
  	                     if(node.children !== null && node.children.length > 0)
  	                 	{
  	                 	 	$rootScope.selectedimg.push(node.id);
  	                 	}
  	                     scopeArray1.imgId = $rootScope.selectedRootScopeDatas1[x].imgId;
  	     				scopeArray1.imgDesc = $rootScope.selectedRootScopeDatas1[x].imgDescription;
  	     				scopeArray1.seqNumber =  $rootScope.selectedRootScopeDatas1[x].sequence;
  	     				scopeArray1.bytes = null;
  	     				scopeArray1.resError = "Download Not yet Started";
  	     				scopeArray1.scopeAvilableIcon = "glyphicon glyphicon-remove";
  	     				scopeArray1.downloadStatusIcon = "glyphicon glyphicon-remove";
  	     				 $rootScope.downloadScopeList.push(scopeArray1);	 
  	     				scopeArray1={};
  	     				

  	               }
  	              
  	                       
  	        }
  	        }
	 
  	  
  	  }
  	  if(selectedTabsData ==="tab2"){
  		
		 
		  $scope.selectedMethod(node,node.selected); 
    	  $rootScope.selectedRootScopeData.sort(function(a, b) {
    		    return parseInt(a.sequence) - parseFloat(b.sequence);
    		});
	  for(var x = 0,arrLen = $scope.selectedRootScopeData.length; x < arrLen ; x++){
		  if($scope.selectedRootScopeData[x].enabled === 1){
			  
		  if(x == 0)
			 		{		  
				  $rootScope.scopevalues = $scope.selectedRootScopeData[x].imgId;
		          $rootScope.scopevalueArray.push($rootScope.selectedRootScopeData[x].imgId);
			 		}
		  else{
				  
			  $rootScope.scopevalues = $rootScope.scopevalues.concat(";",$scope.selectedRootScopeData[x].imgId);
		           $rootScope.scopevalueArray.push($rootScope.selectedRootScopeData[x].imgId);
		  }
	  }
	  }
  		  
  	  }
  	if(selectedTabsData ==="tab3"){
  		 $scope.selectedMethod(node,node.selected); 
		 
  	  $rootScope.selectedRootScopeDatas.sort(function(a, b) {
  		    return parseInt(a.sequence) - parseFloat(b.sequence);
  		});
		  for(var y = 0,arrLen = $scope.selectedRootScopeDatas.length; y < arrLen ; y++){
  		  if($scope.selectedRootScopeDatas[y].enabled === 1){
  			  
  		  if(y == 0){
  				    				 
  		   $rootScope.scopevaluesData = $scope.selectedRootScopeDatas[y].imgId;  		    				 		    			 
  		   $rootScope.scopevalueArrays.push($rootScope.selectedRootScopeDatas[y].imgId);
  		  }
  		  else{   			    
  				  $rootScope.scopevaluesData = $rootScope.scopevaluesData.concat(";",$scope.selectedRootScopeDatas[y].imgId);
  				  $rootScope.scopevalueArrays.push($rootScope.selectedRootScopeDatas[y].imgId);
  		  	}
  		  }
  	  }  
	}
     if (node.children != null) {
         $scope.$broadcast('changeChildren', node);
       }
	  };
	  $scope.save=function(){  	  
    	  $rootScope.validClose = true;
    	  $scope.isAll = false;
    	  $scope.selectAllFriends();
	  		ngDialog.close();
	  		
	  	};
	  	$scope.onCancel=function(){
	  	
	  		ngDialog.close();
	  		
	  	};
	  	
	    $scope.$on('changeChildren', function(event, parentItem) {
            var child, i, len, ref, results;
            ref = parentItem.children;
            results = [];
            for (i = 0, len = ref.length; i < len; i++) {
              child = ref[i];
              if(child.enabled== "1"){
              child.selected = parentItem.selected;
              }
              if (child.children != null) {
                results.push($scope.$broadcast('changeChildren', child));
              } else {
                results.push(void 0);
              }
            }
            return results;
          });
	    $scope.selectedMethod = function(item,selectedValue){
	    	  
	    	  var selectedTabsData = $rootScope.selectedTab;
	    	  if(selectedTabsData ==="tab2"){ 
	    	  var bData = {};
	    	 
	    	  if(item.imgId != undefined && item.imgId != null && item.imgId.length > 0){
	    		  bData.imgId = item.imgId;
		    	  bData.imgDescription = item.imgDescription;
		    	  bData.sequence = item.sequence;
		    	  bData.enabled = item.enabled;
		    	  bData.fileName = "";
		    	  bData.filepath = "";
		    	  bData.isMasterData = item.isMasterData;
		    	  if(selectedValue === true){


                    index = -1;
                    for(var a= 0,arrLen = $rootScope.selectedRootScopeData.length;a< arrLen ;a++){
                         if($rootScope.selectedRootScopeData[a].imgId == bData.imgId){
                                index = a;
                                break;
                         }
                    }
                    
                    if (index == -1) {
                          if(bData.enabled === 1){
                          $rootScope.selectedRootScopeData.push(bData);
                          }

                        }
                    
             }
            
             else if(selectedValue === false){

                    
                    index = -1;
                    for(var a= 0,arrLen = $rootScope.selectedRootScopeData.length;a< arrLen ;a++){
                         if($rootScope.selectedRootScopeData[a].imgId == bData.imgId){
                                index = a;
                                break;
                         }
                    }
                    

                    if (index > -1) {
                          $rootScope.selectedRootScopeData.splice(index, 1);
                        }
             }
	    	  }else {
	    		  for(var x = 0,arrLen = item.children.length;x < arrLen ; x++){
	    		  $scope.selectedMethod(item.children[x],selectedValue);
	    		  }
	    	  }
	    	  
	    	  }  if(selectedTabsData ==="tab3"){
	    		  var bData = {};
	 	    	 
		    	  if(item.imgId != undefined && item.imgId != null && item.imgId.length > 0){
		    		  bData.imgId = item.imgId;
			    	  bData.imgDescription = item.imgDescription;
			    	  bData.sequence = item.sequence;
			    	  bData.enabled = item.enabled;
			    	  bData.fileName = "";
			    	  bData.filepath = "";
			    	  bData.isMasterData = item.isMasterData;
			    	  
			    	  if(selectedValue === true){
			    		  index = -1;
                        for(var a= 0,arrLen = $rootScope.selectedRootScopeDatas.length;a< arrLen ;a++){
                             if($rootScope.selectedRootScopeDatas[a].imgId == bData.imgId){
                                    index = a;
                                    break;
                             }
                        }
                        
                        if (index == -1) {
                              if(bData.enabled=== 1){
                              $rootScope.selectedRootScopeDatas.push(bData);
                              }

                            }
                        
                 }
                
                 else if(selectedValue === false){
                       
                        index = -1;
                        for(var a= 0,arrLen = $rootScope.selectedRootScopeDatas.length;a< arrLen ;a++){
                             if($rootScope.selectedRootScopeDatas[a].imgId == bData.imgId){
                                    index = a;
                                    break;
                             }
                        }

                        if (index > -1) {
                              $rootScope.selectedRootScopeDatas.splice(index, 1);
                            }
                 }
		    	  }else {
		    		  for(var x = 0,arrLen = item.children.length;x < arrLen; x++){
		    		  $scope.selectedMethod(item.children[x],selectedValue);
		    		  }
		    	  } 
	    		  
	    	  }if(selectedTabsData ==="tab1"){
	    		  var bData = {};
	 	    	 
		    	  if(item.imgId != undefined && item.imgId != null && item.imgId.length > 0){
		    		  bData.imgId = item.imgId;
			    	  bData.imgDescription = item.imgDescription;
			    	  bData.sequence = item.sequence;
			    	  bData.enabled = item.enabled;
			    	  bData.fileName = "";
			    	  bData.filepath = "";
			    	  bData.isMasterData = item.isMasterData;
			    	  
			    	  if(selectedValue === true){


                        index = -1;
                        for(var a= 0,arrLen = $rootScope.selectedRootScopeDatas1.length ;a< arrLen ;a++){
                             if($rootScope.selectedRootScopeDatas1[a].imgId == bData.imgId){
                                    index = a;
                                    break;
                             }
                        }
                        
                        if (index == -1) {
                              if(bData.enabled=== 1){
                              $rootScope.selectedRootScopeDatas1.push(bData);
                              }

                            }
                        
                 }
                
                 else if(selectedValue === false){
                       
                        index = -1;
                        for(var a= 0,arrLen = $rootScope.selectedRootScopeDatas1.length;a< arrLen ;a++){
                             if($rootScope.selectedRootScopeDatas1[a].imgId == bData.imgId){
                                    index = a;
                                    break;
                             }
                        }

                        if (index > -1) {
                              $rootScope.selectedRootScopeDatas1.splice(index, 1);
                            }
                 }
		    	  }else {
		    		  for(var x = 0,arrLen = item.children.length;x < arrLen; x++){
		    		  $scope.selectedMethod(item.children[x],selectedValue);
		    		  }
		    	  } 
	    		  
	    	  }
	      };
        
         $scope.initCheckbox = function(item, parentItem) {
        	   
             
             item.selected=$scope.validatecheck(item);
           
             if(item.selected)
          {
           var allChecks = true;
           for (var i in parentItem.children) 
           {
                        if (!parentItem.children[i].selected) {
                                      allChecks = false;
                                      break;
                               }
           }
                        if (allChecks) {
                                                           parentItem.selected = true;
                                                    }
                               else {
                                                    parentItem.selected = false;
                                      }

          }
             return item.selected;
           
          };
          $scope.validatecheck=function(item)
          {
          	  var selectedTabsData = $rootScope.selectedTab;
  	    	  if(selectedTabsData ==="tab2"){
             var selectedValue=true;
          
             var aIndex1 = $rootScope.scopevalueArray.indexOf(item.imgId);
             if(aIndex1>-1)
                    { 
                    
                    var bData = {};
                    if(item.imgId.length > 0){
                           
                           bData.imgId = item.imgId;
                           bData.imgDescription = item.imgDescription;
                           bData.sequence = item.sequence;
                           bData.enabled = item.enabled;
                           bData.fileName = "";
                           bData.filepath = "";
                           bData.isMasterData = item.isMasterData;
                          
                           if(selectedValue === true){


                                  index = -1;
                                  for(var a= 0,arrLen = $rootScope.selectedRootScopeData.length;a< arrLen ;a++){
                                       if($rootScope.selectedRootScopeData[a].imgId == bData.imgId){
                                              index = a;
                                              break;
                                       }
                                  }
                                  
                                  if (index == -1) {
                                        if(bData.enabled === 1){
                                        $rootScope.selectedRootScopeData.push(bData);
                                        }

                                      }
                                  
                           }
                          
                           else if(selectedValue === false){

                                  
                                  index = -1;
                                  for(var a= 0,arrLen = $rootScope.selectedRootScopeData.length;a< arrLen ;a++){
                                       if($rootScope.selectedRootScopeData[a].imgId == bData.imgId){
                                              index = a;
                                              break;
                                       }
                                  }
                                  

                                  if (index > -1) {
                                        $rootScope.selectedRootScopeData.splice(index, 1);
                                      }
                           }
                    }else {
                           for(var x = 0,arrLen = item.children.length;x < arrLen; x++){
                           $scope.selectedMethod(item.children[x],selectedValue);
                           }
                    }
                    
                    return true;
                    }
             else
             return false
  	    	
          } if(selectedTabsData ==="tab3"){
              var selectedValue=true;
            
              var aIndex2 = $rootScope.scopevalueArrays.indexOf(item.imgId);
              if(aIndex2>-1)
                     { 
                     
                     var bData = {};
                     if(item.imgId.length > 0){
                            
                            bData.imgId = item.imgId;
                            bData.imgDescription = item.imgDescription;
                            bData.sequence = item.sequence;
                            bData.enabled = item.enabled;
                            bData.fileName = "";
                            bData.filepath = "";
                            bData.isMasterData = item.isMasterData;
                           
                            if(selectedValue === true){


                                   index = -1;
                                   for(var a= 0,arrLen = $rootScope.selectedRootScopeDatas.length ;a< arrLen ;a++){
                                        if($rootScope.selectedRootScopeDatas[a].imgId == bData.imgId){
                                               index = a;
                                               break;
                                        }
                                   }
                                   
                                   if (index == -1) {
                                         if(bData.enabled=== 1){
                                         $rootScope.selectedRootScopeDatas.push(bData);
                                         }

                                       }
                                   
                            }
                           
                            else if(selectedValue === false){

                                   
                                   index = -1;
                                   for(var a= 0,arrLen = $rootScope.selectedRootScopeDatas.length;a< arrLen ;a++){
                                        if($rootScope.selectedRootScopeDatas[a].imgId == bData.imgId){
                                               index = a;
                                               break;
                                        }
                                   }
                                   
//                                console.log($scope.selectedTreeviewData);
                                   if (index > -1) {
                                         $rootScope.selectedRootScopeDatas.splice(index, 1);
                                       }
                            }
                     }else {
                            for(var x = 0,arrLen = item.children.length;x < arrLen; x++){
                            $scope.selectedMethod(item.children[x],selectedValue);
                            }
                     }
                     
                     return true
                     }
              else
              return false;
              
           }if(selectedTabsData ==="tab1"){
               var selectedValue=true;
           
               var aIndex3 = $rootScope.scopevalueArrays1.indexOf(item.imgId);
               if(aIndex3>-1)
                      { 
                      
                      var bData = {};
                      if(item.imgId.length > 0){
                             
                             bData.imgId = item.imgId;
                             bData.imgDescription = item.imgDescription;
                             bData.sequence = item.sequence;
                             bData.enabled = item.enabled;
                             bData.fileName = "";
                             bData.filepath = "";
                             bData.isMasterData = item.isMasterData;
                            
                             if(selectedValue === true){


                                    index = -1;
                                    for(var a= 0,arrLen = $rootScope.selectedRootScopeDatas1.length ;a< arrLen ;a++){
                                         if($rootScope.selectedRootScopeDatas1[a].imgId == bData.imgId){
                                                index = a;
                                                break;
                                         }
                                    }
                                    
                                    if (index == -1) {
                                          if(bData.enabled === 1){
                                          $rootScope.selectedRootScopeDatas1.push(bData);
                                          }

                                        }
                                    
                             }
                            
                             else if(selectedValue === false){

                                    
                                    index = -1;
                                    for(var a= 0,arrLen = $rootScope.selectedRootScopeDatas1.length;a< arrLen ;a++){
                                         if($rootScope.selectedRootScopeDatas1[a].imgId == bData.imgId){
                                                index = a;
                                                break;
                                         }
                                    }
                                    

                                    if (index > -1) {
                                          $rootScope.selectedRootScopeDatas1.splice(index, 1);
                                        }
                             }
                      }else {
                             for(var x = 0,arrLen = item.children.length;x < arrLen; x++){
                             $scope.selectedMethod(item.children[x],selectedValue);
                             }
                      }
                      
                      return true
                      }
               else
               return false;
            
           }  
          };
          $scope.selectedImpScope = function(){
        	 // $scope.templateType  = selectedValue;
        	  
        	  if ($scope.create.templateType == "1" || $scope.create.templateType == "3" || $scope.create.templateType == "4"){
        		  $scope.inputMessage = "";
        		  $rootScope.scopevaluesData1 ="";
        		  $rootScope.scopevalues ="";
        		  $rootScope.downloadScopeList = [];	       		 
         		  $scope.createtemplate.selectedSysId = "";
         		  $rootScope.scopevaluesData ="";
         		  angular.element("input[type='file']").val(null);
         		  $rootScope.selectedRootScopeDatas=[];
         		  $rootScope.treeDataPath =[];
         		  $rootScope.selectedRootScopeData=[];
         		  $rootScope.selectedRootScopeDatas1=[];
         		

        	  }
        	  else if ($scope.create.templateType  == "2"){
        		  $scope.inputMessage = "If you entering multiple IMG Scope's,Please seperate each IMG Scope with "+"(,) coma seperator."; 
        		  $rootScope.downloadScopeList = [];	       		 
         		 $scope.createtemplate.selectedSysId ="";
         		 $rootScope.selectedRootScopeData=[];
         		 $rootScope.selectedRootScopeDatas1=[];
         		 $rootScope.selectedRootScopeDatas=[];
         		 
         		
        	  }
        	  
          };
   $scope.getSourceData = function(){
        	  if( $scope.createtemplate.selectedSysId != undefined || $scope.createtemplate.selectedSysId != null || $scope.createtemplate.selectedSysId != "Select System")
	     	    		
	        	  $scope.createTempDone = false;
          }
          
   $scope.validateFields = function(){
            	
            if($scope.create.templateType  == "1" || $scope.create.templateType== "3" ||$scope.create.templateType== "4"){
            	$scope.inputMessage="";
   	    	 if( $scope.createtemplate.selectedSysId.destinationName == undefined || $scope.createtemplate.selectedSysId.destinationName == null || $scope.createtemplate.selectedSysId.destinationName == "Select System"){ 
   	    		
          		// $scope.validMessage = "Please select system"; 
          	   ngDialog.openConfirm({
                   template: '<p>' +"Please select System"+ '</p>',
                   plain: true,
                   scope: $scope,
                   closeByDocument: true,
                   closeByEscape: true,
                   showClose: true,
                   height:120,
                   width: 350,
                   className:'ngdialog-theme-default CLASS_2'
               });
  		   
          		 $timeout(function () { $scope.validMessage = ""; }, 2000);        		 
   	       	 }else if($rootScope.selectedRootScopeDatas1 == undefined || $rootScope.selectedRootScopeDatas1 == null ||  $rootScope.selectedRootScopeDatas1.length == 0){
   	       		 
   	       	 ngDialog.openConfirm({
                 template: '<p>' +"Please Select IMG ID"+ '</p>',
                 plain: true,
                 scope: $scope,
                 closeByDocument: true,
                 closeByEscape: true,
                 showClose: true,
                 height:120,
                 width: 350,
                 className:'ngdialog-theme-default CLASS_2'
             });
		   
   	       	 }else{
   	       		 
   	       		 	$scope.validMessage="";
   	       		 	//$scope. = true;
   	       		 	downloadCount = 0;
   	       		 	$scope.createNewTemplate();
   	       		 	//$scope.checkExistTemplates(); 
   	       	  }
   	    	 
            	}else if ($scope.create.templateType  == "2"){
            		var data =  $scope.imgId.newScopeValues;
            		var systemName = $scope.createtemplate.selectedSysId.destinationName;
            		if(data == undefined ||data == null|| data.length == 0){
          	       		 
          	   	       	 ngDialog.openConfirm({
          	                 template: '<p>' +"Please Enter IMG ID"+ '</p>',
          	                 plain: true,
          	                 scope: $scope,
          	                 closeByDocument: true,
          	                 closeByEscape: true,
          	                 showClose: true,
          	                 height:120,
          	                 width: 350,
          	                 className:'ngdialog-theme-default CLASS_2'
          	             });
          			   
          	   	       	 }/*else {
				            			$rootScope.downloadScopeList = [];	
				            		
				           		    $rootScope.selectedRootScopeDatas1 =[];
				        		 
				        			//var data = document.getElementById('scopeId').value;
				        			
				        			//var enteredImgId = $rootScope.newScopeValues;
				        			var res = data.split(",");
				            			
				                    for(var x = 0; x < res.length; x++){  
				      				  var bData = {};
				      				  bData.imgId = res[x];
				      		    	  bData.imgDescription = res[x];
				      		    	  bData.sequence = "";
				      		    	  bData.enabled = "";
				      		    	  bData.fileName = "";
				      		    	  bData.filepath = "";
				      		    	  bData.isMasterData = "";
				      				  $rootScope.selectedRootScopeDatas1.push(bData);
				                    }  
				            			  var scopeArray1 = {};
				                			 for(var x = 0; x < $rootScope.selectedRootScopeDatas1.length; x++){
				                				scopeArray1.imgId = $rootScope.selectedRootScopeDatas1[x].imgId;
				                				scopeArray1.imgDesc = $rootScope.selectedRootScopeDatas1[x].imgDescription;
				                				scopeArray1.seqNumber =  $rootScope.selectedRootScopeDatas1[x].sequence;
				                				scopeArray1.bytes = null;
				                				scopeArray1.resError = "Create Template is not yet Started";
				                				scopeArray1.scopeAvilableIcon = "glyphicon glyphicon-remove";
				                				scopeArray1.downloadStatusIcon = "glyphicon glyphicon-remove";					
				                				$rootScope.downloadScopeList.push(scopeArray1); 
				                				scopeArray1 = {};            				
				        			        }
				          	   	       	 }
				            		*/
            		else if( systemName == undefined ||systemName == null || systemName =="Select System" ){ 
          	    		
                 		 //$scope.validMessage = ""; 
                 		   ngDialog.openConfirm({
			                      template: '<p>' +"Please select System"+ '</p>',
			                      plain: true,
			                      scope: $scope,
			                      closeByDocument: true,
			                      closeByEscape: true,
			                      showClose: true,
			                      height:120,
			                      width: 350,
			                      className:'ngdialog-theme-default CLASS_2'
			                  });
                 		   
                 		 $timeout(function () { $scope.validMessage = ""; }, 2000);
          	    	 }
                 	else{
          	        	
	          	       		$scope.validMessage="";
	          	       		//$scope.createTempDone=true;
	          	       		downloadCount = 0;
	          	       	    $scope.inputMessage="";
	          	       		//$scope.checkExistTemplates(); 
	          	       	    $rootScope.downloadScopeList = [];	
	          	       	    $rootScope.selectedRootScopeDatas1 =[];       		 
	        		//		var data = document.getElementById('scopeId').value;
	          	       	    var data = $scope.imgId.newScopeValues;
	          	       	    var res = data.split(",");           			
	          	       	    for(var x = 0; x < res.length; x++){  
	          	       	    	var bData = {};
	          	       	    	bData.imgId = res[x];
	          	       	    	bData.imgDescription = res[x];
	          	       	    	bData.sequence = "";
	          	       	    	bData.enabled = "";
	          	       	    	bData.fileName = "";
	          	       	    	bData.filepath = "";
	          	       	    	bData.isMasterData = "";
	      				  
	      				 
	                                $rootScope.selectedRootScopeDatas1.push(bData);
	            			  } 
	            			  var scopeArray1 = {};
	                			 for(var x = 0; x < $rootScope.selectedRootScopeDatas1.length; x++){
	                				scopeArray1.imgId = $rootScope.selectedRootScopeDatas1[x].imgId;
	                				scopeArray1.imgDesc = $rootScope.selectedRootScopeDatas1[x].imgDescription;
	                				scopeArray1.seqNumber =  $rootScope.selectedRootScopeDatas1[x].sequence;
	                				scopeArray1.bytes = null;
	                				scopeArray1.resError = "Create Template is not yet Started";
	                				scopeArray1.scopeAvilableIcon = "glyphicon glyphicon-remove";
	                				scopeArray1.downloadStatusIcon = "glyphicon glyphicon-remove";					
	                				$rootScope.downloadScopeList.push(scopeArray1); 
	                				scopeArray1 = {};            				
	        			        }
	          	       	  } $scope.createNewTemplate();
	            		          			
	            		}
           };
       /*     $scope.createtableValues = function(){
    	    	$scope.disableCreate  = false;
    	   	 $rootScope.downloadScopeList = [];	
    		  var scopeArray1 = {};
    			 for(var x = 0; x < $rootScope.selectedRootScopeDatas1.length; x++){
    				scopeArray1.imgId = $rootScope.selectedRootScopeDatas1[x].imgId;
    				scopeArray1.imgDesc = $rootScope.selectedRootScopeDatas1[x].imgDescription;
    				scopeArray1.seqNumber =  $rootScope.selectedRootScopeDatas1[x].sequence;
    				scopeArray1.bytes = null;
    				scopeArray1.resError = "Create Template is not yet Started";
    				scopeArray1.scopeAvilableIcon = "glyphicon glyphicon-remove";
    				scopeArray1.downloadStatusIcon = "glyphicon glyphicon-remove";					
    				$rootScope.downloadScopeList.push(scopeArray1); 
    				scopeArray1 = {};
    			 }
    	    }*/
    	    $scope.checkExistTemplates = function(){
    	    	         $scope.arrayImg =[];// Clear existing files.
    	        		 $rootScope.uploadScopeDetails =[];
    	        		
    	        		 var selectedScopeListData1=[];
    	        		 for(var x = 0,arrLen = $rootScope.selectedRootScopeDatas1.length; x < arrLen ; x++){
    	        			 selectedScopeListData1.push($rootScope.selectedRootScopeDatas1[x].sequence+"_"+$rootScope.selectedRootScopeDatas1[x].imgDescription); 
    	        		 }
    	        			var selectedDataTemplate = {
    	        	                selectedScopes:selectedScopeListData1,
    	        	                sessionInputDTO:$rootScope.sessionInputObj	

    	        	            }; 
    	        	    
    	        	    	 $http.post("/" + servicePrefix + "/rest/imgTemplateUploadSrv/checkTemplatesExists",selectedDataTemplate).then(function(response) {
    	        	    		 if(response.status === 200 ){  			 
    	        	    			 if(response.data.status === false ){
    	        	    				  for(var a= 0,arrLen = response.data.imgIds.length;a< arrLen ;a++){	
    	        	    					  
    	        	    					 var uploadScopeData1 = {
    	        	     	    		    		 "fileName": response.data.imgIds[a]	     			                     		                     
    	        	     		                  
    	        	     		                };
    	        	    					  $rootScope.uploadScopeDetails.push(uploadScopeData1);
    	        	         			 uploadScopeData1 = {};
    	        	    					  
    	        	    				  }  		    				 
    	        	    				 ngDialog.openConfirm({
    	        	    	       	            template: 'view/managetemplate/createStatus.html?ver='+version,
//    	        	    	       	            controller:'importTemplatePage',
    	        	    	       	            scope: $scope,
    	        	    	       	            closeByDocument: false,
    	        	    	       	            closeByEscape: false,
    	        	    	       	            showClose: false,
    	        	    	       	            height: "auto",
    	        	    	       	            width: 600,
    	        	    	       	            className:'ngdialog-theme-default CLASS_2'
    	        	    	       	        }); 
    	        	    				 	    				 
    	        	    			 }else{
    	        	    				
    	        	    				 $scope.createNewTemplate();
    	        	    			 }
    	        	    			 
    	        	    			 
    	        	    		 }else{
    	    	    				 
    	        	    			  ngDialog.openConfirm({
    	    		                      template: '<p>' +"No records found!"+ '</p>',
    	    		                      plain: true,
    	    		                      scope: $scope,
    	    		                      closeByDocument: true,
    	    		                      closeByEscape: true,
    	    		                      showClose: true,
    	    		                      height:120,
    	    		                      width: 350,
    	    		                      className:'ngdialog-theme-default CLASS_2'
    	    		                  });  
    	     					  
    	    	    				 
    	    	    			 }
    	        	    		 
    	        	    			 });
    	    }
    	    
    	    $rootScope.createExistingTemplate = function(){
    	    	ngDialog.close();
    		
         			$scope.createNewTemplate();
    	    }
            $rootScope.excludeExistTemplate = function(){
            	
            	ngDialog.close();
      			 $rootScope.downloadScopeList = [];	
            		  var scopeArray1 = {};     	               
         			 for(var x = 0,arrLen = $rootScope.selectedRootScopeDatas1.length; x < arrLen; x++){
         				 index = -1;
         				 for(var y = 0,arLen = $rootScope.uploadScopeDetails.length; y < arLen ; y++){	
         					if($rootScope.selectedRootScopeDatas1[x].imgDescription == $rootScope.uploadScopeDetails[y].fileName.split("_")[1]){
         						index = y;
         						break;
                       } 
         				 }	 
         					
         			if(index == -1)	 {
         				scopeArray1 = {};
    					scopeArray1.imgId = $rootScope.selectedRootScopeDatas1[x].imgId;
    					scopeArray1.imgDesc = $rootScope.selectedRootScopeDatas1[x].imgDescription;
    					scopeArray1.seqNumber =  $rootScope.selectedRootScopeDatas1[x].sequence;
    					scopeArray1.isMasterData =  $rootScope.selectedRootScopeDatas1[x].isMasterData;
    					scopeArray1.bytes = null;
    					scopeArray1.resError = "Create Template is not yet Started";
    					scopeArray1.scopeAvilableIcon = "glyphicon glyphicon-remove";
    					scopeArray1.downloadStatusIcon = "glyphicon glyphicon-remove";					
    					$rootScope.downloadScopeList.push(scopeArray1);					
         			}	
         		 }
         			$scope.createNewTemplate();
    	    }
    	    
          $scope.createNewTemplate =  function(){
        	  $rootScope.downloadIndMsg = "Creating Template "+(downloadCount+1)+" out of "+$rootScope.downloadScopeList.length;
              $scope.fileNameList =[];
              $scope.arrayImg=[];
              
              
              var url = "/" + servicePrefix + "/rest/autoConfigSrv/emptyTemplateDownload";
             var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
    	     var targetData= $scope.createtemplate.selectedSysId;
    	     var res = targetData.destinationName.split("-");
    	     var srcSystem =res[0];
    	     var systemType =res[1];
         
    	     var inputParam ={
    	       		 destinationName: srcSystem,					 
    	    			  sessionInputDTO: $rootScope.sessionInputObj
    	    	  }
    	        $http.post("/" + servicePrefix + "/rest/configSrv/getSystemDetails", inputParam).then(function mySucces(response) {
    	            if (response.data[0].resMessageDTO.msgType == "Success") {
    	                $scope.target = response.data[0];
    	               
    	            }else if(response.data.systemdetails.resMessageDto.message == serviceMessage){
    	        		$rootScope.checkAuthorization();
    	        	}
    	     
		
             var params = {"imgHierarchyCustomDto":{"imgId":"","imgDesc":"","seqNumber":""},
                            "srcSystem":"","systemType":""};
             params.imgHierarchyCustomDto.imgDesc =  $rootScope.selectedRootScopeDatas1[downloadCount].imgDescription;
             params.imgHierarchyCustomDto.seqNumber = $rootScope.selectedRootScopeDatas1[downloadCount].sequence;
             params.imgHierarchyCustomDto.imgId = $rootScope.selectedRootScopeDatas1[downloadCount].imgId;
             params.imgHierarchyCustomDto.isMasterData = $rootScope.selectedRootScopeDatas1[downloadCount].isMasterData;
             params.srcSystem = srcSystem;
             params.systemType = systemType;
             params.hostName=$scope.target.hostName;
             params.systemId=$scope.target.systemId;
             params.clientNo=$scope.target.sapClientNo;
             params.sapUserId=$scope.target.userId;
             params.destPasswrd=$scope.target.password;
             params.language=$scope.target.language;
             params.sysNo=$scope.target.systemNo;
             params.sncEnabled=$scope.target.sncEnabled;
             params.sncName=$scope.target.sncName;
             params.sncPartnerName=$scope.target.sncPartnerName;
             params.sapRouter=$scope.target.sapRouter;
             params.sncProtectionLevel=$scope.target.sncProtectionLevel;
             params.industryFlag = $rootScope.industry;
             params.industry=$scope.selectedIndustry;
             params.subIndustry=$scope.selectedsubIndustry;
             if( $rootScope.selectedTab == "tab1" && $rootScope.create.templateType=="3"){
            	 params.copyFlag=true;
             }
             else{
	    			$rootScope.copyFlag=false;
	    		}
             
             params.sessionInputDTO = $rootScope.sessionInputObj;	

             $rootScope.downloadScopeList[downloadCount].resError = "Template Creation Started";//Message Change while click download - 29-June-2017
             
           /*  $mdDialog.show({
                 controller: function($scope, $mdDialog){
                 $scope.isLoading = true;
                 $scope.indicatorMsg = $rootScope.downloadIndMsg;
                 },
                 templateUrl: 'view/config/DwnloadBusyInd.html?ver='+version,
                 parent: angular.element(document.body),
                 clickOutsideToClose: false,
                 fullscreen: useFullScreen,
                 escapeToClose: false,
             })*/
               ngDialog.openConfirm({
            	   
            	   controller: function($scope, ngDialog){
                       $scope.isLoading = true;
                       $scope.indicatorMsg = $rootScope.downloadIndMsg;
                       },
    	    		                      template: 'view/config/DwnloadBusyInd.html?ver='+version,
    	    	
    	    		                      scope: $scope,
    	    		                      closeByDocument: false,
    	    		                      closeByEscape: false,
    	    		                      showClose: false,
    	    		                      height:120,
    	    		                      width: 350,
    	    		                      className:'ngdialog-theme-default CLASS_2'
    	    		                  })
             .then(function(answer) {
             }, function() {
             });
               
              
     	         
             $http.post(url,params).then(function(responseData){
            	 if(responseData.data.resMessageDto != null && responseData.data.resMessageDto.message == serviceMessage){
        	      		$rootScope.checkAuthorization();
        	      	}
            	 else{
            	 			var responseData = responseData.data;
//                            $rootScope.downloadScopeList[downloadCount].targetFilePath = responseData.targetFilePath;
                            $rootScope.downloadScopeList[downloadCount].bytes = responseData.bytes;
                            $rootScope.downloadScopeList[downloadCount].resError = responseData.resError;
                            $rootScope.downloadScopeList[downloadCount].scopeAvilableIcon = responseData.scopeAvilableIcon;
                            $rootScope.downloadScopeList[downloadCount].downloadStatusIcon = responseData.downloadStatusIcon;
                            $rootScope.downloadScopeList[downloadCount].imgDesc = responseData.imgDesc;//Remove special character in Java Service 
                            $scope.isLoading = false;
                           // $mdDialog.cancel();
                            ngDialog.close();
                            downloadCount++;
                             if( downloadCount < $rootScope.downloadScopeList.length){
                                 if((downloadCount/$scope.articlesPerPage)> 0){
                                         $scope.currentPage = Math.floor(downloadCount/$scope.articlesPerPage)+1;
                                 }
                                 $scope.createNewTemplate();
                             }else{
                               $scope.isZipFile=true;
                               for(var i =0, arrLen = $rootScope.downloadScopeList.length; i< arrLen ;i++){
                                    if($rootScope.downloadScopeList[i].bytes !=  null){
                                    	
                                    	if($rootScope.industry){
                                    		 var fileName =  $rootScope.downloadScopeList[i].imgDesc.replace(/[/]/g, '~')+"_"+$scope.aliasIndustry+"_"+$scope.aliasSubIndustry;
                                    	}
                                    	else{
                                    		 var fileName =  $rootScope.downloadScopeList[i].imgDesc.replace(/[/]/g, '~');
                                    	}
                                  	  
                                         var seqNumber =  $rootScope.downloadScopeList[i].seqNumber;
                                         var byteData =  $rootScope.downloadScopeList[i].bytes;
                                         var isMasterData = $rootScope.downloadScopeList[i].isMasterData;
                                         var fileBytes = base64ToArrayBuffer(byteData);
                                         if(isMasterData != null && isMasterData == "Y"){
                                      	   $scope.fileNameList.push(fileName + ".xlsx");
                                             saveByteArray([fileBytes], fileName+".xlsx");
                                         }else{
                                      	 //  $scope.fileNameList.push(seqNumber + "_" + fileName + ".xlsx");
                                         //    saveByteArray([fileBytes], seqNumber+"_"+fileName+".xlsx");
                                             
                                      	   $scope.fileNameList.push(fileName + ".xlsx");
                                           saveByteArray([fileBytes], fileName+".xlsx");
                                         }    
                                     }
                                }
                                $scope.generateZipFile();
                             }
             			}
             }) ,(function(data){

                            $rootScope.downloadScopeList[downloadCount].resError = "Download Failed due to service failure.."

                            $scope.isLoading = false;
                            //$mdDialog.cancel();
                            ngDialog.close();
                            downloadCount++;
                            
              if(downloadCount < $rootScope.downloadScopeList.length){
                            if((downloadCount/$scope.articlesPerPage)> 0){
                                $scope.currentPage = Math.floor(downloadCount/$scope.articlesPerPage)+1;
                            }
                            $scope.createNewTemplate();
                 }
             else{
            	 $scope.isZipFile=true;
            	 for(var i =0, arrLen = $rootScope.downloadScopeList.length; i< arrLen ;i++){
            		 if($rootScope.downloadScopeList[i].bytes !=  null){
                        var fileName =  $rootScope.downloadScopeList[i].imgDesc;
                        var seqNumber =  $rootScope.downloadScopeList[i].seqNumber;
                        var byteData =  $rootScope.downloadScopeList[i].bytes;
                        var isMasterData = $rootScope.downloadScopeList[i].isMasterData;
                        var fileBytes = base64ToArrayBuffer(byteData);
                        if(isMasterData != null && isMasterData == "Y"){
                              $scope.fileNameList.push(fileName + ".xlsx");
                                     saveByteArray([fileBytes], fileName+".xlsx");
                         }else{
                           //  $scope.fileNameList.push(seqNumber + "_" + fileName + ".xlsx");
                           //  saveByteArray([fileBytes], seqNumber+"_"+fileName+".xlsx");
                             $scope.fileNameList.push(fileName + ".xlsx");
                             saveByteArray([fileBytes], fileName+".xlsx");
                         }
                    }
                 }
               $scope.generateZipFile();
                             
              }
             });
    	        }, function myError(response) {
    	        });
    	   
          }
            $scope.generateZipFile=function(){
              	 var zip = new JSZip();
              	 var count = 0;
              	 var count1 = 0;
   			 $scope.arrayImg.forEach(function(url){
              		 //console.log(url)
              		 
              		  var filename =  $scope.fileNameList[count];
              		  //i++;
              		  count++;
              		  // loading a file and add it in a zip file
              		  JSZipUtils.getBinaryContent(url, function (err, data) {
              		     if(err) {
              		        throw err; // or handle the error
              		     }
              		     zip.file(filename, data, {binary:true});
              		     if (count == $scope.arrayImg.length) {
              		       /*var zipFile = zip.generate({type: "blob"});
              		       saveAs(zipFile, "examples.zip");*/
              		       
              		    zip.generateAsync({type:"blob"}).then(function(content) {
              		     // see FileSaver.js
              		    count1++;
             		     if (count1 == $scope.arrayImg.length) {
             		    	 saveAs(content, "BaseTemplates.zip");
             		    //$mdDialog.cancel();
             		    	$scope.isLoading = false;
             		    	ngDialog.close();
             		     }
              		 });
              		     }
              		  });
              		});
   		  		
   		        };
   		        
   		 	$scope.downloadTemplates = function () {
   		 	if($rootScope.adminAuth == "true"){
   				$rootScope.importtempUser = true;
   				$rootScope.createTemplateUser = true;
   				$rootScope.downloadtempUser = true;
   			}
   		        var selectedScopeList = [];
   		        $scope.selectedAll = false;
   		        $rootScope.DownloadStatus = [];
   		        angular.forEach($rootScope.selectedRootScopeDatas, function (checked) {
   		            if (checked.checked) {
   		            
   		            //added by Kamal for industry solution
   		            	var imgdesc;
   		            	
   		            	if($rootScope.industry){
   		            		imgdesc = checked.imgDescription+$scope.aliasIndustry+$scope.aliasSubIndustry;
   		            	}else{
   		            		imgdesc =checked.imgDescription;
   		            	}
   		           	 selectedScopeList.push(imgdesc.replace(/[^a-zA-Z0-9]/ig, "").toLowerCase());
   		             //selectedScopeList.push(checked.imgDescription);
   		            }
   		        });
   		        var selectedData = {
   		            selectedScopes:selectedScopeList,
   		            industry:$rootScope.industry,
   		            sessionInputDTO : $rootScope.sessionInputObj	

   		        }; 
   		        if (selectedScopeList.length > 0)  {
   		        $http.post("/" + servicePrefix + "/rest/imgTemplateUploadSrv/getIMGTemplatesPath", selectedData).then(function(response) {
   		            if (response.status === 200 && response.data.listImgHierarchyDto!= null) {
   		            	  if(response.data.listImgHierarchyDto.length > 0){
   		            		 if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
   		         	      		$rootScope.checkAuthorization();
   		         	      	}	  
   		            		 else{
   		            			 for (var i = 0, arrLen = response.data.listImgHierarchyDto.length; i < arrLen ; i++) {
   		            				 var downloadFilesPath = {
   		                        "fileName": response.data.listImgHierarchyDto[i].imgDescription
   		                       
   		                    };
   		                    $rootScope.DownloadStatus.push(downloadFilesPath);
   		                    downloadFilesPath = {};
   		                    
   		                    
   		                }
   		                
   		                ngDialog.openConfirm({
   		       	            template: 'view/managetemplate/downloadStatus.html?ver='+version,
//   		       	            controller:'importTemplatePage',
   		       	            scope: $scope,
   		       	            closeByDocument: false,
   		       	            closeByEscape: false,
   		       	            showClose: true,
   		       	            height: 400,
   		       	            width: 600,
   		       	            className:'ngdialog-theme-default CLASS_2'
   		       	        }).then(function() {       	        	
   		       	            $scope.okDownload();
   		       	        });
   		            	  }        
   		            	  }else{
   		            	      ngDialog.openConfirm({
   		                          template: '<p>' +"Selected Templates are not available!!"+ '</p>',
   		                          plain: true,
   		                          scope: $scope,
   		                          closeByDocument: true,
   		                          closeByEscape: true,
   		                          showClose: true,
   		                          height:120,
   		                          width: 350,
   		                          className:'ngdialog-theme-default CLASS_2'
   		                      });   
   		            	  }
   		               

   		                $scope.okDownload = function (ok) {
   		              	  ngDialog.close();
   		               $rootScope.overlay_download = document.getElementById("overlay");
   	                 $rootScope.popup_download = document.getElementById("busy");
   	                 $rootScope.overlay_download.style.display = "block";
   	                 $rootScope.popup_download.style.display = "inline-block";
   		                	  $http.post("/" + servicePrefix + "/rest/imgTemplateUploadSrv/downloadTemplates",selectedData).then(function(response) {
   		                          if(response.status === 200 ){
   		                        
   		                 	      	var zip = new JSZip();
   		                 	      	$scope.arrayImg=[];
   		                 	      	$scope.fileNameList =[];
   		                      	
   		                      	 var count =0;
   		                      	 var count1 =0;
   		                      	  if(response.data != null){
   		                      	 if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
		                 	      		$rootScope.checkAuthorization();
		                 	      	}else{
		                 	      		
   		                         	 for (var i = 0, arrLen = response.data.listImgHierarchyDto.length; i < arrLen; i++) {
   		                                  var downloadFilesPath = {
   		                                     // "sequence": response.data[i].sequence,
   		                                      "imgDescription": response.data.listImgHierarchyDto[i].imgDescription,
   		                                      "filePath": response.data.listImgHierarchyDto[i].bytes
   		                                  };
   		                                  $rootScope.DownloadFileData.push(downloadFilesPath);
   		                                  $scope.downloadFile(response.data.listImgHierarchyDto[i].bytes,response.data.listImgHierarchyDto[i].imgDescription);
   		                                  
   		                                  downloadFilesPath = {};
   		                         	 		}
   		                      	  		}
   		                         	 }else{
   		                         	 
   		                         	      ngDialog.openConfirm({
   		                                      template: '<p>' +"No records found!"+ '</p>',
   		                                      plain: true,
   		                                      scope: $scope,
   		                                      closeByDocument: true,
   		                                      closeByEscape: true,
   		                                      showClose: true,
   		                                      height:120,
   		                                      width: 350,
   		                                      className:'ngdialog-theme-default CLASS_2'
   		                                  });   
   		                              }
   		                         	// var i=0;
   		                         	 $scope.arrayImg.forEach(function(url){
   		                         		 //console.log(url)
   		                         		 
   		                         		  var filename =  $scope.fileNameList[count];
   		                         		  //i++;
   		                      		     count++;

   		                         		  // loading a file and add it in a zip file
   		                         		  JSZipUtils.getBinaryContent(url, function (err, data) {
   		                         		     if(err) {
   		                         		        throw err; // or handle the error
   		                         		     }
   		                         		     zip.file(filename, data, {binary:true});
   		                         		     if (count == $scope.arrayImg.length) {
   		                         		       /*var zipFile = zip.generate({type: "blob"});
   		                         		       saveAs(zipFile, "examples.zip");*/
   		                         		      zip.generateAsync({type:"blob"}).then(function(content) {
   		                              		     // see FileSaver.js
   		                                   	 	count1++;
   		                                   	 if(count1 == $scope.arrayImg.length){
   		                                   	
   		                                   		 saveAs(content, "BaseTemplatesDownload.zip");
   		                                   	$rootScope.overlay_download.style.display = "none";
     				                          $rootScope.popup_download.style.display = "none";
   		                         		      }
   		                              		 });
   		                         		      
   		                         		 
   		                         		     }
   		                         		  });
   		                         		});
   		                         }
   		                  
   		                      });
   		                	
   		                 }
   		            } else {
   		            	$rootScope.overlay_download.style.display = "none";
	                          $rootScope.popup_download.style.display = "none";
   		            	ngDialog.openConfirm({
   		                    template: '<p>' +"Templates are not available."+ '</p>',
   		                    plain: true,
   		                    scope: $scope,
   		                    closeByDocument: true,
   		                    closeByEscape: true,
   		                    showClose: true,
   		                    height:120,
   		                    width: 350,
   		                    className:'ngdialog-theme-default CLASS_2'
   		                });            }
   		        });
   		        
   		  	}else{
   		  
   		  		ngDialog.openConfirm({
   		            template: '<p>' +"Please select atleast One Template"+ '</p>',
   		            plain: true,
   		            scope: $scope,
   		            closeByDocument: true,
   		            closeByEscape: true,
   		            showClose: true,
   		            height:120,
   		            width: 350,
   		            className:'ngdialog-theme-default CLASS_2'
   		        });
   		  		
   		  	}
   		    };
   		    
   			$scope.openProgress = function() {
   		        ngDialog.openConfirm({
   		            template: 'view/ProgressDialog.html?ver='+version,
//   		            controller: 'importTemplatePage',
   		            scope: $scope,
   		            closeByDocument: false,
   		            closeByEscape: false,
   		            showClose: true,
   		            height: 200,
   		            width: 300
   		        }).then(function() {
   		            $scope.callUpload(allfiles,files);
   		        });
   		    };
   			
   		    $rootScope.uploadExcelFiles = function (files) {
   		    	
   		     
   				 $scope.FileMessage = ''; 
   				 $scope.isValid = true;
   				 
   				
   				 
   				 if(files === undefined || files === null || files.length === 0) {
   					 $scope.FileMessage = 'Please select a File, File extension should be .xlsx';
   			      } 
   				 else{		 
   			    	    $scope.fieldError = false;
   			    	    $scope.isSuccess = false;
   				        $scope.noTextVisibility=false;
   				        var allfiles=[];	     
   				        $rootScope.fileListError=[];
   				        $rootScope.scopeListError = [];
   				        var count = 0;
   				        if (files && files.length) {
   				            for (var i = 0,fileLen = files.length; i < fileLen; i++) {	            	
   				            	  index = -1;
   				            	  var ext = files[i].name.substr(files[i].name.lastIndexOf('.')+1);
   				            	  if(ext === "xlsx" || ext === "XLSX"){		            	 		            		
   				        		  for(var a= 0,arLen = $rootScope.selectedRootScopeData.length;a< arLen ;a++){
   				        			  var validFileName;
   				        			  
   				        			  //added by Kamal for industry solution
   				        			 if($rootScope.industry){
   				        				validFileName = $rootScope.selectedRootScopeData[a].imgDescription+"_"+$scope.aliasIndustry+"_"+$scope.aliasSubIndustry;
   				        			 }
   				        			 else{
   				        				validFileName = $rootScope.selectedRootScopeData[a].imgDescription; 
   				        			 }
   				        			
   				        				 
   				        		  	if(validFileName.replace(/[^a-zA-Z0-9]/ig, "").toLowerCase() == files[i].name.split(".xlsx")[0].replace(/[^a-zA-Z0-9]/ig, "").toLowerCase()){
   				        		  		index = a;
   				        		  		count++;
   				        		  		break;
   				        		  	}
   				        		  	else if(validFileName.replace(/[^a-zA-Z0-9]/ig, "").toLowerCase() == files[i].name.split(".XLSX")[0].replace(/[^a-zA-Z0-9]/ig, "").toLowerCase()){
   				        		  		index = a;
   				        		  		count++;
   				        		  		break;
   				        		  	}
   				        		  	
   				        		
   				        		  }	
   				        		
   				        		  
   				        		  if(index > -1){
   				        			$rootScope.selectedRootScopeData[index].fileName = files[i].name;
   					             	$rootScope.selectedRootScopeData[index].seq = count++; 
   					            	$rootScope.selectedRootScopeData[index].fileUploadedIcon = "glyphicon glyphicon-ok";//Added for File Upload Icon 
   			        			    allfiles.push(files[i]); 
   				  	            	}
   				        		  else
   				            		{	        			  
   				            		$scope.errorheading = "Missing Scopes";
   				            		$scope.uploaderrormsg = "Below Scopes are missing for the selected files";
   				            		var fileerror = [];
   				            		fileerror.sequence = i+1;
   				            		fileerror.fileNameFormat = files[i].name;
   				            		fileerror.fileName = files[i].name;
   				            		fileerror.seq = i+1;
   				            		fileerror.fileUploadedIcon = "glyphicon glyphicon-remove";
   				            		
   				            		$rootScope.fileListError.push(fileerror);
   					            		
   				            		}
   				        		  	               
   				               $rootScope.myFile = allfiles;
   				              
   				               
   				            } else{
   				            	 $scope.FileMessage = 'Please Upload a file and file extension should be .xlsx or XLSX';
   				            }
   				            }
   				        }
   				        
   				     for (var i = 0,arrLen = $rootScope.selectedRootScopeData.length; i < arrLen; i++) {
//   		    			console.log( $rootScope.FileList[i].fileName);
   		    			if( $rootScope.selectedRootScopeData[i].fileName == "" )
   		    				{
   		    				$scope.isValid = false;
   		    				var scopeData = $rootScope.selectedRootScopeData[i];
   		    				
   		    				 var validFileName;
   		    				 //added by Kamal for industry solution
   		    				 if($rootScope.industry){
   		    					
   		    					
   		    					validFileName = $rootScope.selectedRootScopeData[i].imgDescription+"_"+$scope.aliasIndustry+"_"+$scope.aliasSubIndustry;;
   		    				 }else{
   		    					 if($rootScope.selectedRootScopeData[i].isMasterData == "Y")
   	   		    					 validFileName =  $rootScope.selectedRootScopeData[i].imgDescription;
   	   		    				 else
   	   		    					 validFileName =  $rootScope.selectedRootScopeData[i].imgDescription;
   		    				 }
   		    				
   		    				 
   		    				 scopeData.fileNameFormat=validFileName;
   		    				$rootScope.scopeListError.push(scopeData);
   		    				}
   		    				//alert($scope.fileListError[i]);
   		    				//console.log(fileListError[i]);
   		    				}
   				        	if($rootScope.fileListError != null && $rootScope.fileListError.length > 0){
   				        		ngDialog.openConfirm({
   			   			            template: 'view/managetemplate/goldenTemError.html?ver='+version,
   			   			            //controller:'importTemplatePage',
   			   			            scope: $scope,
   			   			            closeByDocument: false,
   			   			            closeByEscape: false,
   			   			            showClose: true,
   			   			            height: 200,
   			   			            width: 515
   			   			        });
   				        	}
   				        	else if($rootScope.scopeListError != null && $rootScope.scopeListError.length>0){
   				    			$scope.errorheading = "Required Files";
   			            		$scope.uploaderrormsg = "Choose correct File Name Format as like below for missing scope";
   				    			ngDialog.openConfirm({
   				    	            template: 'view/managetemplate/scopeListError.html?ver='+version,
   				    	            //controller:'ConfigInitialPage',
   				    	            scope: $scope,
   				    	            closeByDocument: false,
   				    	            closeByEscape: false,
   				    	            showClose: true,
   				    	            height: 500,
   				    	            width: 650
   				    	        });
   			    			}
   				        	else{
   				        		$scope.callUpload(allfiles,files); 
   				        	}
   				 }
   			            
   			    }; 
   			    
   			    //Added by Dileep
   			 $rootScope.goldenTempUpload = function(allfiles,files){
   		        var uploadUrl = "/" + servicePrefix + "/rest/files/multipleUpload/S4IMGGoldenTemplates";
   		        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
   		        var overlay = document.getElementById("overlay");
   		        var popup = document.getElementById("busy");
   		        overlay.style.display = "block";
   		        popup.style.display = "inline-block";
   		     
   		            files.upload = Upload.upload({
   		                method: 'POST',
   		                url:         uploadUrl,
   		                data:      {files: allfiles}
   		            });
   		            files.upload.then(function(responseData) {
   		                $scope.fileSuccess(responseData);
   		            }, function (data) {
   		                $scope.fileUploaderror(data);
   		            });
   		        
   		    };
   			    
   		    
   		  //File upload Success Message
   		    $scope.fileSuccess = function(responseData){
   		        //$mdDialog.cancel();
   		    	var overlay = document.getElementById("overlay");
   		    	var popup = document.getElementById("busy");
   		    	overlay.style.display = "none";
   		    	popup.style.display = "none";
   		        var data;
   		        var filePath = [];
   		        data = responseData.data.fileNameList;
   		        $rootScope.FileList = [];
   		        var imgDesc;
   		        if(data != undefined && data != null){
   		        	
   		        for(var i=0;i<data.length;i++){
   	          	  index = -1;
   	    		  for(var a = 0,arrLen = $rootScope.selectedRootScopeData.length;a < arrLen ;a++){
   	    			//added by Kamal for industry solution
   	    			  if($rootScope.industry){
   	    				imgDesc = $rootScope.selectedRootScopeData[a].imgDescription+"_"+$scope.aliasIndustry+"_"+$scope.aliasSubIndustry;
   	    			  }
   	    			  else{
   	    				imgDesc=$rootScope.selectedRootScopeData[a].imgDescription;
   	    			  }
   	    			
   	    			  if(data[i].replace(/[^a-zA-Z0-9]/ig, "").toLowerCase().indexOf(imgDesc.replace(/[^a-zA-Z0-9]/ig, "").toLowerCase()) >= 0){
   	    		  		index = a;
   	    		  		break;
   	    		  	}
   	    		  }
   	        	
   	            	if(index > -1){
   	            	$rootScope.selectedRootScopeData[index].fileBytes = responseData.data.fileBytesList[i];
   	            	}
   		        }
   		        }
   		        $scope.goldenTempValidate();
   		    
   		    }
   		    
   		    
   		 //Golden Template Validation
   		    $scope.goldenTempValidate = function(){
   		    	
   		    	  var  uploadUrl;
   	     	         uploadUrl = "/" + servicePrefix + "/rest/imgTemplateUploadSrv/goldenTempalteValidation";

   		        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
   		        var overlay = document.getElementById("overlay");
		        var popup = document.getElementById("busy");
		        overlay.style.display = "block";
		        popup.style.display = "inline-block";
   		     
   		        var uploadArray = {};
   		        uploadArray.docUpdate = $rootScope.docUpdate;
   		        uploadArray.copyFlag = $rootScope.copyFlag;
   		        uploadArray.selectedScopeList = $rootScope.selectedRootScopeData;
   		        uploadArray.sessionInputDTO = $rootScope.sessionInputObj;
   		        //added by Kamal for industry solution	
   		        uploadArray.industryFlag = $rootScope.industry;
   		        uploadArray.industry=$scope.selectedIndustry;
   		        uploadArray.subIndustry=$rootScope.selectedsubIndustry;
   		        uploadArray.aliasIndustry=$scope.aliasIndustry;
   		        uploadArray.aliasSubIndustry=$scope.aliasSubIndustry;
   		        
   		        $http.post(uploadUrl,uploadArray).then(function(responseData){
   		        	overlay.style.display = "none";
   		        	popup.style.display = "none";
   		        	 //console.log(responseData);
//   		        	$rootScope.selectedRootScopeData = responseData;
   		    	 if(responseData.data.resMessageDto != null && responseData.data.resMessageDto.message == serviceMessage){
         	      		$rootScope.checkAuthorization();
         	      	}else{
         	      		
   		        	$rootScope.invaliduploadedlist = [];
   		        	if(!responseData.data.uploadStatus){
		        		/*var output = [];
			        	for(var a = 0;a < responseData.configTemplateDto.length;a++){
			        		output.push(responseData.configTemplateDto[a].selectedScopeDto);
			        	}
//			        	console.log(output);
			        	$rootScope.selectedScopeData = output;*/
			        	//console.log($rootScope.selectedScopeData);
			        	//$rootScope.invalidfile = true;
		        		//$rootScope.wrongformat = false;
		        		$scope.invalidheading1 = "WRONG TEMPLATE UPLOADED";
		        		$scope.uploadinvalidmsg1 = "Please upload template with below corrections";
		        	var invaliduploaded = {};
		        	var errLogArr = [];
		        	for(var a = 0,arrLen = responseData.data.configTemplateDto.length;a < arrLen ;a++){
		        		if(responseData.data.configTemplateDto[a].status == false){
		        			var invaliduploaded ={
		       	    				"imgdesc":responseData.data.configTemplateDto[a].selectedScopeDto.imgDescription,
		       	    		       	"errLogArr":responseData.data.configTemplateDto[a].selectedScopeDto.fileUploadStatusMsg
		       		    		 } ;
		        		/*	invaliduploaded = {};
		        			invaliduploaded.imgdesc =  responseData.configTemplateDto[a].selectedScopeDto.imgDescription;
		        			errLogArr = responseData.configTemplateDto[a].fileUploadStatusMsg;
		        			invaliduploaded.msg = errLogArr;*/
		        		
		        			$rootScope.invaliduploadedlist.push(invaliduploaded);
		        			}
		        		}
		        	//console.log($rootScope.invaliduploadedlist);
		        	}
   		        	
   		        	$scope.fileUploadSuccess(responseData);
   		        }
//   		           $scope.docUploadReq();
//   		        	$scope.listError();
   	            }) ,(function(data){

   	            	// $mdDialog.cancel();
   	            	//Remove all file name and path
   	          		  for(var a = 0;a < $rootScope.selectedRootScopeData.length;a++){
   		          			$rootScope.selectedScopeData[a].fileName = "";
   		          			$rootScope.selectedScopeData[a].filepath = "";
   	          		  }
   	            });
   		    };
   		    
   		    
   			    $scope.callUpload = function(allfiles,files){
   			    	//console.log($rootScope.selectedRootScopeData);
   			    	/*$rootScope.overlay_import.style.display = "none";
   	   		        $rootScope.popup_import.style.display = "none";*/
   			    	var selectedScopeListData=[];
   			    	  $rootScope.uploadScope =[];
   			    	  var uploadScopeData;
   			    	  for(var a= 0,fileLen = files.length;a< fileLen ;a++){
   			    		  
   			    		  selectedScopeListData.push(files[a].name.split(".xlsx")[0].replace(/[^a-zA-Z0-9]/ig, "").toLowerCase());
   			    		  
   			    	  }
   			    	var selectedDataTemplate = {
   			                selectedScopes:selectedScopeListData,
   			                industry:$rootScope.industry
   			            }; 
   			    
   			    	 $http.post("/" + servicePrefix + "/rest/imgTemplateUploadSrv/checkTemplatesExists",selectedDataTemplate).then(function(response) 
   			    			 
   			    			 {
   			    		 if(response.status === 200 ){  			 
   			    			 if(response.data.status === false ){
   			    				  for(var a= 0,arrLen = response.data.imgIds.length;a< arrLen ;a++){	
   			    					  
   			    					  uploadScopeData = {
   			     	    		    		 "fileName": response.data.imgIds[a]	     			                     		                     
   			     		                  
   			     		                };
   			    					  $rootScope.uploadScope.push(uploadScopeData);
   			         			 uploadScopeData = {};
   			    					  
   			    				  }  		    				 
   			    				 ngDialog.openConfirm({
   			    	       	            template: 'view/managetemplate/uploadStatus.html?ver='+version,
//   			    	       	            controller:'importTemplatePage',
   			    	       	            scope: $scope,
   			    	       	            closeByDocument: false,
   			    	       	            closeByEscape: false,
   			    	       	            showClose: true,
   			    	       	            height: "auto",
   			    	       	            width: 600,
   			    	       	          //  className:'ngdialog-theme-default CLASS_2'
   			    	       	        }).then(function() {
   			    	       	            $scope.uploadAgain();
   			    	       	             
		   			    	       	      /*ngDialog.close();
		   		   			    		  $rootScope.docUpdate = true;
		   		   			    		  $rootScope.goldenTempUpload(allfiles,files);*/ 
   			    	       	        }); 
   			    				 	    				 
   			    			 }else{
   			    				$rootScope.docUpdate = false;
   			    				if( $rootScope.selectedTab == "tab2" && $rootScope.create.templateType=="3"){
   			    					$rootScope.copyFlag=true;
   			    			 	}
   			    				else{
   		   			    			$rootScope.copyFlag=false;
   		   			    		}
   			    				
   			    				$rootScope.goldenTempUpload(allfiles,files); 
   			    				
   			    				 
   			    			 }
   			    			 
   			    			 
   			    		 }
   			    		 
   			    			 });
 $scope.uploadAgain = function (ok) {
   						  
   			    		ngDialog.close();
   			    		$rootScope.docUpdate = true;
   			    		if( $rootScope.selectedTab == "tab2" && $rootScope.create.templateType=="3"){
		    					$rootScope.copyFlag=true;
		    			 	}
   			    		else{
   			    			$rootScope.copyFlag=false;
   			    		}
   			    		
   	       	            $rootScope.goldenTempUpload(allfiles,files);
   			    		/*$rootScope.docUpdate = true;
   			    		$rootScope.goldenTempUpload(allfiles,files); */
   			    		
   			    		
   						   /* var uploadUrl = "/" + servicePrefix + "/rest/imgTemplateUploadSrv/multiple/"+true;

   					        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
   					        $mdDialog.show({
   					            controller: function($scope, $mdDialog){
   					            $scope.isLoading = true;
   					            },
   					            templateUrl: 'view/busy.html?ver='+version,
   					            parent: angular.element(document.body),
   					            clickOutsideToClose: false,
   					            fullscreen: useFullScreen,
   					            escapeToClose: false,
   					        })
   					        .then(function(answer) {
   					        }, function() {
   					        });
   					     
   					            files.upload = Upload.upload({
   					                method: 'POST',
   					                url:         uploadUrl,
   					                data:      {files: allfiles}

   					            });
   					            files.upload.then(function(responseData) {
   					                $scope.fileUploadSuccess(responseData);
   					            
   					            }, function (data) {
   					                $scope.fileUploaderror(data);
   					            
   					            }); */
   						  
   						 
   					  };
   					 
   			    
   			        
   			    };	    
   			    $scope.fileUploadSuccess = function(responseData){
   			    // $scope.isLoading = false;
                 //$mdDialog.cancel();
   			        var data;
   			        var bDatas ={};
   			        var filePath = [];
   			        data = responseData.data.listHCPDocServiceResDto;     
   			        $rootScope.treeDataPath =[];
   			        var fileName;
   			 if(data != undefined && data != null){
   			        for(var i=0,arrLen = data.length;i< arrLen;i++){
//   			          	  index = -1;
   			    		  for(var a= 0,arLen = $rootScope.selectedRootScopeData.length;a< arLen ;a++){		  	
   			    	
//   			 					 validFileName = $rootScope.selectedRootScopeData[a].sequence+"_"+$rootScope.selectedRootScopeData[a].imgId+"_"+ $rootScope.selectedRootScopeData[a].imgDescription;
   			    			//added by Kamal for industry solution
   			    			if($rootScope.industry){
   			    				fileName = $scope.selectedRootScopeData[a].imgDescription+"_"+$scope.aliasIndustry+"_"+$scope.aliasSubIndustry;
   			    			}else{
   			    				fileName = $scope.selectedRootScopeData[a].imgDescription;
   			    			}
   			            	if(fileName.replace(/[^a-zA-Z0-9]/ig, "") == data[i].imgDesc.replace(/[^a-zA-Z0-9]/ig, "")){
   			            		bDatas = {
   			    	    		    		 "sequence": $scope.selectedRootScopeData[a].sequence,
   			    			                 "imgId": $scope.selectedRootScopeData[a].imgId,
   			    		                     "imgDescription": fileName,
   			    		                     "status":"glyphicon glyphicon-ok"
   			    		                    	 
   			    		                };
   			        			  $rootScope.treeDataPath.push(bDatas);
   			        			  bDatas = {};
   			        			
   			        		     }
   			                 			  
   			        		  }
   			    		  /*if(index > -1){
   				            	$rootScope.selectedRootScopeData[index].filepath = data[i];
   				            	
   				            	}*/
   				        
   				        	

   				        }
   			 }
   			     if($rootScope.invaliduploadedlist.length > 0){
   			    	$rootScope.invalidfile = true;
   			    }
   			    else{
   			    	$rootScope.invalidfile = false;
   			    	}
   			    if($rootScope.fileListError.length > 0){
   			    	$rootScope.wrongformat = true;
   			    }
   			    else
   			    {
   			    	$rootScope.wrongformat = false;
   			    }
   			    if($rootScope.invalidfile || $rootScope.wrongformat){
   		        	ngDialog.openConfirm({
   			            template: 'view/managetemplate/errorlist.html?ver='+version,
   			            //controller:'importTemplatePage',
   			            scope: $scope,
   			            closeByDocument: false,
   			            closeByEscape: false,
   			            showClose: true,
   			            height: 500,
   			            width: 732
   			        });
   			    } 
   			       /* if($rootScope.fileListError.length>0){
   			        	ngDialog.openConfirm({
   		    	            template: 'view/managetemplate/uploadErrorList.html?ver='+version,
   		    	            scope: $scope,
   		    	            closeByDocument: false,
   		    	            closeByEscape: false,
   		    	            showClose: true,
   		    	            height: "auto",
   		    	            width: 650
   		    	        });
   		        		
   			        }*/
   			        $rootScope.FileList = $rootScope.selectedRootScopeData;
   			      
   			    };	    
   			    $scope.fileUploaderror = function(data){
   			     $scope.isLoading = false;
                 $mdDialog.cancel();
   			       
   			    };
   			    /*$scope.fileUploadValidation = function () {
   		    		if($rootScope.FileList.length > 0 ){
   		    		$scope.isValid = true;
   		    		$rootScope.fileListError = [];
   		    		for (var i = 0; i < $rootScope.FileList.length; i++) {

   		    			if( $rootScope.FileList[i].fileName == "" ||  $rootScope.FileList[i].filepath == "")
   		    				{
   		    				$scope.isValid = false;
   		    				var scopeData = $rootScope.selectedRootScopeData[i];
   		    				
   		    				 var validFileName;
   		    				
   		    					 validFileName = $rootScope.selectedRootScopeData[i].sequence+"_"+ $rootScope.selectedRootScopeData[i].imgDescription;
   		    				 
   		    				 scopeData.fileNameFormat=validFileName;
   		    				$rootScope.fileListError.push(scopeData);
   		    				
   		    				}
   		    				
   		    				}
   		    			

   		    		 	
   		    		if($scope.isValid === true){
   		    		$scope.fieldError = false;
   		    	
   		    		}else{

   		    			$scope.errorheading = "Required Files";
   		        		$scope.uploaderrormsg = "Choose correct File Name Format as like below for missing scope";
   		    			ngDialog.openConfirm({
   		    	            template: 'view/config/filelistError.html?ver='+version,
   		    	            scope: $scope,
   		    	            closeByDocument: false,
   		    	            closeByEscape: false,
   		    	            showClose: true,
   		    	            height: 500,
   		    	            width: 650
   		    	        });
   		    	    	
   		    		}
   		    }else{

   		    	$scope.fieldError = true;
   		    	document.getElementById("fileUploadError").style.display="inline-block";
   		    	$scope.isSuccess = false;
   		    	
   		    	
   		    }
   		    	
   		    	
   		    };*/
   		    
   			function base64ToArrayBuffer(base64) {
		         var binaryString = window.atob(base64);
		         var binaryLen = binaryString.length;
		         var bytes = new Uint8Array(binaryLen);
		         for (var i = 0; i < binaryLen; i++) {
		             var ascii = binaryString.charCodeAt(i);
		             bytes[i] = ascii;
		         }
		         return bytes;
		     }

		  	var saveByteArray = (function() {
		    	  
		         var a = document.createElement("a");
		         document.body.appendChild(a);
		         a.style = "display: none";
		      
		         return function(data, name) {
		             var blob = new Blob(data, {
		                     type: "octet/stream"
		                 }),
		                 url = window.URL.createObjectURL(blob);
		             	$scope.arrayImg.push(url);
		           /*  if (navigator.appVersion.toString().indexOf('.NET') > 0) { // for IE browser
		                 window.navigator.msSaveBlob(blob, name);
		             } else { // for other browsers
		                 a.href = url;
		                 a.download = name;
		                 a.click();
		                 window.URL.revokeObjectURL(url);
		             }*/

		         };
		     }());
		  	$scope.downloadFile = function(exportHref, filename) {
		    
		         var sampleBytes = base64ToArrayBuffer(exportHref);
		         saveByteArray([sampleBytes],  filename + ".xlsx");
		         $scope.fileNameList.push(filename + ".xlsx");
		     };
		     $scope.viewErrors = function(logs,imgDescription){
			    	//$scope.logsExportOptions.data = [];
			    	/* if($rootScope.implType != "1" && $rootScope.modTypes.value == "Automated without intervention")
						 $rootScope.executionLogsData = $rootScope.executeScopeList;
					 else
						 $rootScope.executionLogsData = $rootScope.selectedScopeData;*/
			    	 
			    	$scope.errorLogData =[];

			    	$scope.scopeDescription = imgDescription;
			
		  		
			    	for(var k=0 ,arrLen = logs.length; k < arrLen ;k++){
		    			//if(logs[k].imgDesc === imgDescription){
		    	    		var bData1 = {
		    		    		 "SNO": k+1,
		    	                 "Description": logs[k]
		                    
		                     
		                    
		                  };  
			    			$scope.errorLogData.push(bData1);
			    			 bData1 = {};
		    	    	//}
		    			
		    			
		    		}
					 ngDialog.openConfirm({
			            template: 'view/admin/goldenTemErr.html?ver='+version,
			            //controller:'ConfigExecutePage',
			            scope: $scope,
			            closeByDocument: false,
			            closeByEscape: false,
			            showClose: true,
			            height: 500,
			            width: 732
			        });
		  		
			    	
			    };
			    
			    $scope.okfileupld = function(){
			    	$scope.callUpload($rootScope.myFile,$rootScope.myFile); 
			    	ngDialog.close();
				 }
				 $scope.cancelupload = function(){
					 ngDialog.close();
					 
				};
				$scope.downloadEnable = function(){
					$scope.downloadTempDone = false;
				}
				
				//added by Kamal for industry solution
				$scope.getIndustryAlias = function(){

		            	   
	            	    var params={
	            	    		industry:$rootScope.selectedIndustry,
	            	             subIndustry:$rootScope.selectedsubIndustry,
	            	             userRole : $rootScope.userRole,
	        		            sessionInputDTO: $rootScope.sessionInputObj 
	        		        }; 
	               
		               $http.post("/" + servicePrefix + "/rest/autoConfigSrv/getIndustryAlias",params).then(function(response) {
		       		    
		          		 if(response.status === 200){
		      		    	  if(response.data != null){
		      		    		  
		      		    		  	  $scope.aliasIndustry = response.data.aliasIndustry;
		      			    		  $scope.aliasSubIndustry = response.data.aliasSubIndustry;
		      			    	  }
		      		    }
		      		}); 
	               
				}
				$scope.getIndustry = function(){
				var params = {
						userID : $rootScope.username,
						userRole : $rootScope.userRole,
						sessionInputDTO : $rootScope.sessionInputObj
					};
				$http.post("/" + servicePrefix + "/rest/clientImgHierarchySrv/getIndustry",params).then(function(response) {
				    
					 if(response.status === 200){
				    	  if(response.data!= null){
				    		  	  $rootScope.allindustry = []; 
				    		  	  
					    		  $rootScope.allindustry = response.data.indDetails;
					    		  
					    	  }else
				    		  	 $rootScope.allindustry = []; 
				    		  	 $rootScope.Industry = [];
				    	  }
					
				    
					}); 
				}
				 
				 $scope.getScopeData = function(selectedIndustry){
					 
					 var params1={
							 industry:selectedIndustry,
							 userRole: $rootScope.userRole,
						     sessionInputDTO: $rootScope.sessionInputObj 
						};
					
					 $http.post("/" + servicePrefix + "/rest/clientImgHierarchySrv/getSubIndustry",params1).then(function(response) {
						 
						    
						 if(response.status === 200){
					    	  if(response.data!= null){
					    		  	  $rootScope.allSubindustry = []; 
						    		  $rootScope.allSubindustry = response.data.indDetails;
						    		  
						    	  }else{
					    		  	 $rootScope.allSubindustry = []; 
					    		  	 
					    	  }
					    }
						 
					 
					}); 
					 
					 }
}]);
