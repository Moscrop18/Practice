  angular.module('yapp').controller('ConfigHomePage',["ngDialog","Upload","$scope","$rootScope","$http","$mdDialog","$mdMedia","$location","$filter","$state", "$timeout","Idle","$ocLazyLoad",function(ngDialog,Upload,$scope,$rootScope,$http,$mdDialog,$mdMedia,$location,$filter,$state, $timeout,Idle,$ocLazyLoad) {
		$ocLazyLoad.load(controllerName+'/config/ConfigHomePage.js?ver='+version);
		
		//Browser Refresh - 13 Nov 2017
		if($rootScope.appValidity == undefined){
			   $rootScope.username = "";
			    $rootScope.password = "";
			  /*  var cookies = document.cookie.split(";");
			    for (var i = 0,arrLen = cookies.length; i < arrLen ; i++) {
			        var cookie = cookies[i];
			        var eqPos = cookie.indexOf("=");
			        var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
			        document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
			    }*/
			    $location.path('/loginPage');
		    
		    
		}
	//Idle Time out Logic - Start 	
/*		$scope.$on('IdleTimeout', function() {
			 $mdDialog.hide();
			  ngDialog.close();
		$location.path('/loginPage');
		   $mdDialog.show(
	               $mdDialog.alert()
	               .parent(angular.element(document.body))
	               .clickOutsideToClose(true) 
	               .title('Automatic log off')
	               .textContent('successfully logged off')
	               .ariaLabel('Alert Dialog Demo')
	               .ok('Ok')
	);
	});*/
/*	$scope.$on('IdleStart', function(ev) {
		ngDialog.close();
		$rootScope.initalCheck = undefined;
		$location.path('/loginPage');
	       $mdDialog.show(
	                        $mdDialog.alert()
	                        .parent(angular.element(document.body))
	                        .clickOutsideToClose(true)
	                        .title('Automatic log off')
	                        .textContent('Session has expired. Please logon again')
	                        .ariaLabel('Alert Dialog Demo')
	                        .ok('Ok')
	                        .targetEvent(ev)
	        );
	});*/
		/*$rootScope.$on('IdleStart', function(ev) {
			
			   var confirm = $mdDialog.confirm()
		     .title('Warning')
		     .parent(angular.element(document.body))
		     .textContent('Your session is going to expire in 5mins, Do you want to continue')
		     .ariaLabel('Alert Dialog Demo')
		     .targetEvent(ev)
		     .ok('OK')
		     .cancel('CANCEL');
		  $mdDialog.show(confirm).then(function() {
		  	var inputParam = {
		  			sessionId : $rootScope.sessionInputObj.sessionId,
		  			csrfToken : $rootScope.sessionInputObj.csrfToken
		  	}
		  	$http.post("/" + servicePrefix + "/rest/adminSrv/resetSessionTime", inputParam).then(function(response) {
				  if(response.status === 200){
					if(response.data.resDto == true){
					   $mdDialog.show(
			               	        $mdDialog.alert()
			                        .parent(angular.element(document.body))
			                        .clickOutsideToClose(true)
			                        .title('Alert Dialog')
			                        .textContent('Your session is extended. Thank you')
			                        .ariaLabel('Alert Dialog Demo')
			                        .ok('OK') 
			                        .targetEvent(ev)
				    	   			)
					}else{
					  $mdDialog.show(
			               	        $mdDialog.alert()
			                        .parent(angular.element(document.body))
			                        .clickOutsideToClose(true)
			                        .title('Alert Dialog')
			                        .textContent('Something went wrong, Please login again.')
			                        .ariaLabel('Alert Dialog Demo')
			                        .ok('OK') 
			                        .targetEvent(ev)
				    	   			)
					}
				  	}
		  	});
		  }, function() {
		  	$mdDialog.hide();
		  });
		});*/
	Idle.watch();
	//Idle Time out Logic - End
		
	  var noAuth = "false";

	/*$scope.logout = function(){
		ngDialog.close();
		$rootScope.initalCheck = undefined;
        $state.transitionTo('loginPage');
        $rootScope.username = "";
        $rootScope.password = "";
       // $scope.deleteAllCookies();
        $rootScope.adminAuth  = "";
        $rootScope.fileUploadAuth = "";
        $rootScope.executeAuth = "";
        $rootScope.configAuth = "";
        $rootScope.fileDownloadAuth = "";
        $rootScope.showLogsExportData = false;
        $rootScope.sapUserID = "";
    	$rootScope.sapPassword = "";
        ngDialog.close(); 

    }*/

/*	$scope.deleteAllCookies=function() {
	    var cookies = document.cookie.split(";");
	    for (var i = 0,arrLen = cookies.length; i < arrLen ; i++) {
	        var cookie = cookies[i];
	        var eqPos = cookie.indexOf("=");
	        var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
	        document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
	    }
	}*/
/*	
	var cookie = document.cookie;
	var cookieAuthParams = cookie.split(';');
	for (var cp1 = 0,arrLen = cookieAuthParams.length; cp1 < arrLen ; cp1++) {*/
		/*if (cookieAuthParams[cp1].split('=')[0].trim() == "configAuth" && cookieAuthParams[cp1].split('=')[1].trim() == "true") {
			noAuth = "true"
		}*/
		if ($rootScope.configAuth == "true") {
			noAuth = "true"
		}
	/*}*/
	if (noAuth == "false") {
		$location.path('/loginPage');
	}

/*Hiding Page2(Deployment Info) initially on Notification pop up*/
	$rootScope.page2 = false;
	/*Displaying the content of Page 2 on click on next button	*/
	$rootScope.nextpage = function(){
				$rootScope.page2 =  true;
				$rootScope.activePage = "previous";
				$rootScope.nonactivePage = "next";
			}
	$rootScope.previouspage = function(){
		$rootScope.page2 =  false;
		$rootScope.activePage = "next";
		$rootScope.nonactivePage = "previous";
	}
/*Two pages - dynamic classes on notification Pop up*/
$rootScope.activePage = "next";
$rootScope.nonactivePage = "previous";

	$scope.homePage= function(){
		 if($rootScope.overlay != null){
		 	   $rootScope.overlay.style.display = "none";
		 	   $rootScope.popup.style.display = "none";
		  	   }
		 
		ngDialog.openConfirm({
            template: 'view/config/confirm.html?ver='+version,		           
            //controller:'configTilesController',
            scope: $scope,
            closeByDocument: false,
            closeByEscape: false,
           showClose: false,
           height: 200,
            width: 527,
            className:'ngdialog-theme-default CLASS_projName'
        });
		
		
	};
	 $scope.okHomepage = function(){
		 $rootScope.tempValue =  undefined;
		 $rootScope.transactionID = 0;
		 $rootScope.scopeTranId = 0;
		 $rootScope.initalCheck = undefined;
		 $rootScope.impTypeChanged = true;
		 $rootScope.downloadButtondisabled = true;
		 noAuth="true";
		 $rootScope.targetSystem=[];
		 $rootScope.sourceSystem=[];
		 $rootScope.trgSystemDetails = [];
		 $rootScope.hvesTargetSystemDetails = [];
		 $rootScope.selectedTargetSystem = undefined;
		 $rootScope.targetClientNo = "";
		 $rootScope.hvessourceSystem = {
		            "values": []
		        };
		$rootScope.implType=2;
		$rootScope.scopevalue = "";
		$rootScope.targetsystemEnabled = false;
		$rootScope.modification = false;
		$rootScope.list=[];
		$rootScope.ScopeIMGList = [];
		$rootScope.allfiles = [];
		$rootScope.FileList = [];
		$rootScope.files = [];
		$scope.executionFileSize = 0;
		$rootScope.downloadScopeList = [];
    	$rootScope.scopevalueArray=[];
    	$rootScope.scopevalueArrayid=[];
        $rootScope.reportData = [];
        
        $rootScope.scopevalueArrays=[];
        $rootScope.scopevalueArrays1=[];
        if( $rootScope.selectedimg == undefined)
        $rootScope.selectedimg = [];
        if( $rootScope.Tempselectedimg == undefined)
	        $rootScope.Tempselectedimg = [];
        
        $rootScope.OmId= "";
 		$rootScope.showLogsExportData = false;

        //added by reshma for changing execute button color
        $rootScope.disable = "enable";
		$location.path("/configTilesPage");
		 ngDialog.close();
	};
	$scope.cancelHome = function(){
		 ngDialog.close();
		 
	};
	// Adding pop up for showing Golden Templates update - Alert for Golden Template prior to 15days
	$rootScope.showUpdates = function(){
			$rootScope.overlay_alert = document.getElementById("overlay");
			$rootScope.popup_alert = document.getElementById("busy");
			$rootScope.overlay_alert.style.display = "block";
			$rootScope.popup_alert.style.display = "inline-block";
		
	    	 if ($rootScope.templateUpdateInfo != undefined && $rootScope.templateUpdateInfo != []) {
	    		 $rootScope.overlay_alert.style.display = "none";
	    		 $rootScope.popup_alert.style.display = "none";
	        		 ngDialog.openConfirm({
	        	         template: 'view/templateUpdate.html?ver='+version,
	        	         //controller: 'configTilesController',
	        	         scope: $scope,
	        	         closeByDocument: false,
	        	         closeByEscape: false,
	        	         showClose: true,
	        	         height:500,
	        	         width: 1022
	        	       
	        	     }).then(function() {
	        	        
	        	     });
	        	}
	        	else {
	        		$http({
	        	        method: "POST",
	        	        url: "/" + servicePrefix + "/rest/HCPDocService/templateUpdateInfo",
	        	        data : $rootScope.sessionInputObj
	        	   	}).then(function(response) {
	        	        if (response.status === 200) {
	        	        	if(response.data != null){
	        	        		if(response.data.resMessageDto.message == serviceMessage){
	        	      	      		$rootScope.checkAuthorization();
	        	      	      	}else{
	        	        		$rootScope.overlay_alert.style.display = "none";
	        	        		$rootScope.popup_alert.style.display = "none";
	        	        		$rootScope.templateUpdateInfo = response.data.templateList;
	        	        		 ngDialog.openConfirm({
	        	        	         template: 'view/templateUpdate.html?ver='+version,
	        	        	         //controller: 'configTilesController',
	        	        	         scope: $scope,
	        	        	         closeByDocument: false,
	        	        	         closeByEscape: false,
	        	        	         showClose: true,
	        	        	         height:500,
	        	        	         width: 1022
	        	        	       
	        	        	     }).then(function(){});
	        	        		}
	        	        	}
	        	        	else {
	        	        		$rootScope.overlay_alert.style.display = "none";
	        	        		$rootScope.popup_alert.style.display = "none";
	        	        	  ngDialog.openConfirm({
	        	                template: '<p>' +"No Results Found"+ '</p>',
	        	                plain: true,
	        	                scope: $scope,
	        	                closeByDocument: true,
	        	                closeByEscape: true,
	        	                showClose: true,
	        	                height:120,
	        	                width: 350
	        	            });
	        	        	}
	        	        }
	        	      else {
	        	    	  $rootScope.overlay_alert.style.display = "none";
	        	    	  $rootScope.popup_alert.style.display = "none";
	        	          ngDialog.openConfirm({
	        	          template: '<p>' +"No Results Found"+ '</p>',
	        	          plain: true,
	        	          scope: $scope,
	        	          closeByDocument: true,
	        	          closeByEscape: true,
	        	          showClose: true,
	        	          height:120,
	        	          width:350
	        	          });
	        	        }
	        	   	})
	        	}
	   };
		$scope.downloadSingleTmeplate = function(seqID){
			$scope.fileNameList = [];
			for(var i =0,arrLen = $rootScope.templateUpdateInfo.length; i< arrLen ;i++){
				if($rootScope.templateUpdateInfo[i].seqID == seqID){
				var fileName =  $rootScope.templateUpdateInfo[i].imgDescr;
				var seqNumber =  $rootScope.templateUpdateInfo[i].seqID;
				var byteData =  $rootScope.templateUpdateInfo[i].bytes;
				
				var fileBytes = base64ToArrayBuffer(byteData);
		         $scope.fileNameList.push(seqNumber + "_" + fileName + ".xlsx");
		         saveByteArray([fileBytes], seqNumber+"_"+fileName+".xlsx");	
				}
				}
			};
			function base64ToArrayBuffer(base64) {
		  	    var binaryString =  window.atob(base64);
		  	    var binaryLen = binaryString.length;
		  	    var bytes = new Uint8Array(binaryLen);
		  	    for (var i = 0; i < binaryLen; i++)        {
		  	        var ascii = binaryString.charCodeAt(i);
		  	        bytes[i] = ascii;
		  	    }
		  	    return bytes;
		  	};

		  	var saveByteArray = (function () {
		  	    var a = document.createElement("a");
		  	    document.body.appendChild(a);
		  	    a.style = "display: none";
		  	    return function (data, name) {
		  	        var blob = new Blob(data, {type: "octet/stream"}),
		  	            url = window.URL.createObjectURL(blob);
		  	        if(!$scope.isZipFile){
		  	        	if (navigator.appVersion.toString().indexOf('.NET') > 0) { // for IE browser
		  	           window.navigator.msSaveBlob(blob, name);
		  	        	} else { // for other browsers
		  	        		a.href = url;
		  	        		a.download = name;
		  	        		a.click();
		  	        		window.URL.revokeObjectURL(url);    
		  	        	}
		  	        }
		  	        else{
		             	$scope.arrayImg.push(url);

		  	        }
		  	        
		  	    };
		  	}());
}]);

