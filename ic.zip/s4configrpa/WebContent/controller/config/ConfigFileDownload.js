  angular.module('yapp').controller('ConfigFileDownloadPage',["ngDialog","Upload","$scope","$rootScope","$http","$mdDialog","$mdMedia","$location","$filter","$ocLazyLoad","Idle",function(ngDialog,Upload,$scope,$rootScope,$http,$mdDialog,$mdMedia,$location,$filter,$ocLazyLoad,Idle) {
	  $ocLazyLoad.load(controllerName+'/config/ConfigFileDownload.js?ver='+version);
		
	  var idleTime = 0;
	 
	      //Increment the idle time counter every minute.
	      //var idleInterval = setInterval(timerIncrement, 60000); // 1 minute
	  
	  //Browser Refresh - 13 Nov 2017
		if($rootScope.appValidity == undefined){
			 
			 	$rootScope.username = "";
			    $rootScope.password = "";
			   /* var cookies = document.cookie.split(";");
			    for (var i = 0,arrLen = cookies.length; i < arrLen ; i++) {
			        var cookie = cookies[i];
			        var eqPos = cookie.indexOf("=");
			        var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
			        document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
			    }*/
			    $location.path('/loginPage');
		}
    $rootScope.downloadIndMsg = "";
	var noAuth = "false";
	var homeAuth="false";
	var resetAuth="false"
	var downloadCount = 0;
	$scope.currentPage = 1;
	var zipfilecount = 500;
	//$rootScope.selectedScopeData=[];
	/*if($rootScope.hierarchyTypes.value == "Business Process"){
		$rootScope.selectedScopeData = $rootScope.selectedBPData;
	}else{
		$rootScope.selectedScopeData = $rootScope.selectedScopeData;
	}*/
	$rootScope.download = false;
	var twentyMinutesBefore = new Date();
	 
	var currentCount = 1; 
	$scope.articlesPerPage = 4;
	var myDate = new Date();
	 $rootScope.downloadButtondisabled = true;
	if($rootScope.downloadButtondisabled == undefined){
		$rootScope.downloadButtondisabled = true;
		
	}
	
	if($rootScope.tempValue ==  undefined){
		$rootScope.tempValue = "";
	}
		
		 $scope.arrayImg =[];
		 $scope.fileNameList =[];

/*    myDate.setHours(myDate.getHours() + 1);
	
	var cookie = document.cookie;
	var cookieAuthParams = cookie.split(';');
	for (var cp1 = 0,arrLen = cookieAuthParams.length; cp1 < arrLen; cp1++) {*/
		
		/*if (cookieAuthParams[cp1].split('=')[0].trim() == "configAuth" && cookieAuthParams[cp1].split('=')[1].trim() == "true") {
			noAuth = "true"
		}*/
		if ($rootScope.configAuth == "true") {
			noAuth = "true"
		}
		if ($rootScope.fileDownloadAuth == "true") {
			homeAuth="true";
			$rootScope.fileDownloadAuth = resetAuth;
			//document.cookie = "fileDownloadAuth=" + resetAuth + ";expires=" + myDate.toUTCString();
		}
/*			
	}*/
	$rootScope.name2 = "not-active";  
	$rootScope.name1 = "active"; 
	$rootScope.name3 = "not-active";
	$rootScope.name = "not-active";
	
	$rootScope.tempDownload = true; //  Adding to reuse Sap Logon Page to display nly source system for download part.
	//Browser Refresh - 13 Nov 2017
	if($rootScope.appValidity != undefined){
	
		if (noAuth == "false") {
			$location.path('/loginPage');
		}else if(homeAuth=="false"){
			$location.path('/configTilesPage');
		}
	}
	/*Adding for dynamically loading rows in table*/
	$scope.barLimit1 = 10;
    $scope.increaseLimit1 = function() {
      $scope.barLimit1 += 20;
    
    }
    $rootScope.enableExport = true;
    $rootScope.disableDownload = false;
    $rootScope.disableSkip = false;
    
   	/*if($rootScope.tempValue != undefined && $rootScope.tempValue != $rootScope.scopevalue && $rootScope.hierarchyTypes.value == "IMG"){
		$rootScope.downloadButtondisabled = false;
	}*/
   	$rootScope.downloadButtondisabled = true;

//	if($rootScope.downloadScopeList == undefined){
	if($rootScope.tempValue != $rootScope.scopevalue){
		$rootScope.tempValue = $rootScope.scopevalue;
		$rootScope.downloadScopeList = [];	
		$rootScope.tempValue = $rootScope.scopevalue;
		if($rootScope.hierarchyTypes.value == "IMG"){
		for(var i =0; i< $rootScope.selectedScopeData.length;i++){
			var scopeArray = {};
			scopeArray.imgId = $rootScope.selectedScopeData[i].imgId;
			scopeArray.imgDesc = $rootScope.selectedScopeData[i].imgDescription;
			scopeArray.seqNumber =  $rootScope.selectedScopeData[i].sequence;
			scopeArray.targetFilePath = "";
			scopeArray.bytes = null;
			scopeArray.resError = "Download Not yet Started";
			scopeArray.scopeAvilable = false;
			scopeArray.scopeAvilableIcon = "glyphicon glyphicon-remove";
			scopeArray.downloadStatus = true;
			scopeArray.downloadStatusIcon = "glyphicon glyphicon-remove";
			
			
			$rootScope.downloadScopeList.push(scopeArray);
			}
		}
	}
	 if($rootScope.hierarchyTypes.value == "Business Process"){
			$rootScope.downloadScopeList = [];		
		 for(var i =0; i< $rootScope.selectedScopeData.length;i++){
				var scopeArray = {};
			
				scopeArray.imgId = $rootScope.selectedScopeData[i].imgId;
				scopeArray.imgDesc = $rootScope.selectedScopeData[i].imgDescription;
				scopeArray.seqNumber =  $rootScope.selectedScopeData[i].sequence;
				scopeArray.targetFilePath = "";
				scopeArray.bytes = null;
				scopeArray.resError = "Download Not yet Started";
				scopeArray.scopeAvilable = false;
				scopeArray.scopeAvilableIcon = "glyphicon glyphicon-remove";
				scopeArray.downloadStatus = true;
				scopeArray.downloadStatusIcon = "glyphicon glyphicon-remove";
				
				$rootScope.downloadScopeList.push(scopeArray);
			/*	var output = [], 
                keys = [];
	    		var collection = $rootScope.downloadScopeList;
	    		var keyname = "imgDescription";
	    		angular.forEach(collection, function(item) {
                var key = item[keyname];
                if(keys.indexOf(key) === -1) {
                    keys.push(key);
                    output.push(item);

	    		}
            	$rootScope.downloadScopeList= output;
	    		});*/
				
			}
		}
 	for (var i = 0,arrLen = $rootScope.sourceSysData.length; i < arrLen ; i++) {
 		 if($rootScope.implType == "2"  && $rootScope.sourceSysData[i].isHVESSystem == 0 && $rootScope.sourceSysData[i].destinationName == $rootScope.sourceSystem.value){
 			$rootScope.sourceSysID = $rootScope.sourceSysData[i].systemId;
 			$rootScope.sourceSystemType = $rootScope.sourceSysData[i].systemType;
 			break;
 		 }else if($rootScope.implType == "3" && $rootScope.sourceSysData[i].isHVESSystem == 1 && $rootScope.sourceSysData[i].destinationName == $rootScope.sourceSystem.value){
 			$rootScope.sourceSysID = $rootScope.sourceSysData[i].systemId;
 			$rootScope.sourceSystemType = $rootScope.sourceSysData[i].systemType;
 			break;
 		 }else{
 			$rootScope.sourceSysID = "";
 		 }
  }
	
	/*else if($rootScope.downloadScopeList.length > $rootScope.selectedScopeData.length ){
		$rootScope.downloadScopeList = [];	
		
		for(var i =0; i< $rootScope.selectedScopeData.length;i++){
			var scopeArray = {};
			scopeArray.imgId = $rootScope.selectedScopeData[i].imgId;
			scopeArray.imgDesc = $rootScope.selectedScopeData[i].imgDescription;
			scopeArray.seqNumber =  $rootScope.selectedScopeData[i].sequence;
			scopeArray.targetFilePath = "";
			scopeArray.bytes = null;
			scopeArray.resError = "Download Not yet Started";
			scopeArray.scopeAvilable = false;
			scopeArray.scopeAvilableIcon = "glyphicon glyphicon-remove";
			scopeArray.downloadStatus = true;
			
			$rootScope.downloadScopeList.push(scopeArray);
		}
	}else if($rootScope.downloadScopeList.length < $rootScope.selectedScopeData.length ){
//		$rootScope.downloadScopeList = [];	
		
		for(var i = $rootScope.downloadScopeList.length-1; i < $rootScope.selectedScopeData.length;i++){
			var scopeArray = {};
			scopeArray.imgId = $rootScope.selectedScopeData[i].imgId;
			scopeArray.imgDesc = $rootScope.selectedScopeData[i].imgDescription;
			scopeArray.seqNumber =  $rootScope.selectedScopeData[i].sequence;
			scopeArray.targetFilePath = "";
			scopeArray.bytes = null;
			scopeArray.resError = "Download Not yet Started";
			scopeArray.scopeAvilable = false;
			scopeArray.scopeAvilableIcon = "glyphicon glyphicon-remove";
			scopeArray.downloadStatus = true;
			
			$rootScope.downloadScopeList.push(scopeArray);
		}
	}*/
	

	function base64ToArrayBuffer(base64) {
  	    var binaryString =  window.atob(base64);
  	    var binaryLen = binaryString.length;
  	    var bytes = new Uint8Array(binaryLen);
  	    for (var i = 0; i < binaryLen; i++)        {
  	        var ascii = binaryString.charCodeAt(i);
  	        bytes[i] = ascii;
  	    }
  	    return bytes;
  	}

  	var saveByteArray = (function () {
  	    var a = document.createElement("a");
  	    document.body.appendChild(a);
  	    a.style = "display: none";
  	    return function (data, name) {
  	        var blob = new Blob(data, {type: "octet/stream"}),
  	            url = window.URL.createObjectURL(blob);
  	        if(!$scope.isZipFile){
  	        	if (navigator.appVersion.toString().indexOf('.NET') > 0) { // for IE browser
  	           window.navigator.msSaveBlob(blob, name);
  	        	} else { // for other browsers
  	        		a.href = url;
  	        		a.download = name;
  	        		a.click();
  	        		window.URL.revokeObjectURL(url);    
  	        	}
  	        }
  	        else{
             	$scope.arrayImg.push(url);

  	        }
  	        
  	    };
  	}());
  	
  	 $scope.downloadFile=function(byteData,sequence,filename){
  		$scope.isZipFile=false;
  		var fileBytes = base64ToArrayBuffer(byteData);
  		saveByteArray([fileBytes], sequence+"_"+filename+".xlsx");	
  		
        };
	
      
       $scope.downloadAllFiles =function(){
        	for(var i =0,arrLen = $rootScope.downloadScopeList.length; i< arrLen ;i++){
        		if($rootScope.downloadScopeList[i].downloadStatus == false){
    			var fileName =  $rootScope.downloadScopeList[i].imgDesc;
    			var seqNumber =  $rootScope.downloadScopeList[i].seqNumber;
    			var byteData =  $rootScope.downloadScopeList[i].bytes;
    			
    			var fileBytes = base64ToArrayBuffer(byteData);
          		saveByteArray([fileBytes], seqNumber+"_"+fileName+".xlsx");	
        		}
    		}
            };
        
        
        $rootScope.singleFileDownload = function(){
        	
        // if(!$scope.downloadButtondisabled){
        	var twentyMinutesLater = new Date();
        	$rootScope.downloadIndMsg = "Downloading "+(downloadCount+1)+" out of "+$rootScope.selectedScopeData.length;
        	 $scope.arrayImg=[];
        	 $scope.fileNameList =[];
        	 $scope.count=0;
        	 var url ="";
     		
        	 if($rootScope.selectedScopeData[downloadCount].isMasterData !=  null && $rootScope.selectedScopeData[downloadCount].isMasterData == "Y")
     			url = "/" + servicePrefix + "/rest/fiMasterDataService/DwldMasterDataForBrwnMod";
     		else
     			url = "/" + servicePrefix + "/rest/autoConfigSrv/getDwldScopeForBrwnMod";
     		
            var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
            var inputParam ={
   	       		 
            		destinationName: $rootScope.sourceSystem.value,					 
   	    			  sessionInputDTO: $rootScope.sessionInputObj
   	    	  }
   	        $http.post("/" + servicePrefix + "/rest/configSrv/getSystemDetails", inputParam).then(function mySucces(response) {
   	            if (response.data[0].resMessageDTO.msgType == "Success") {
   	                $scope.target = response.data[0];
   	               
   	            }else if(response.data.systemdetails.resMessageDto.message == serviceMessage){
   	        		$rootScope.checkAuthorization();
   	        	}
            var params = {"imgHierarchyCustomDto":{"imgId":"","imgDesc":"","seqNumber":""},
                   	"srcSystem":"","systemType":"","hostName":"","clientNo":"","sysNo":""};
//            var params = {};
            params.imgHierarchyCustomDto.imgDesc =  $rootScope.selectedScopeData[downloadCount].imgDescription;
            params.imgHierarchyCustomDto.seqNumber = $rootScope.selectedScopeData[downloadCount].sequence;
            params.imgHierarchyCustomDto.imgId = $rootScope.selectedScopeData[downloadCount].imgId;
            params.imgHierarchyCustomDto.isMasterData = $rootScope.selectedScopeData[downloadCount].isMasterData;
            params.systemType = $rootScope.sourceSystemType;
            params.hostName=$scope.target.hostName;
            params.systemId=$scope.target.systemId;
            params.clientNo=$scope.target.sapClientNo;
            params.sapUserId=$scope.target.userId;
            params.destPasswrd=$scope.target.password;
            params.language=$scope.target.language;
            params.sysNo=$scope.target.systemNo;
            params.sncEnabled=$scope.target.sncEnabled;
            params.sncName=$scope.target.sncName;
            params.sncPartnerName=$scope.target.sncPartnerName;
            params.sapRouter=$scope.target.sapRouter;
            params.sncProtectionLevel=$scope.target.sncProtectionLevel;
            params.srcSystem = $rootScope.sourceSystem.value;
            params.industryFlag=$rootScope.industryFlag;
            if($rootScope.industryFlag){
            	params.industryAlias = $rootScope.aliasIndustry;
            	params.subIndustryAlias = $rootScope.aliasSubIndustry;
            	params.industry=$rootScope.selectedIndustry;
            	params.subIndustry=$rootScope.selectedsubIndustry;
            }
            
//            if(params.srcSystem=="EUT333System"){
//            	params.hostName="sapveutsb.vceaa.root";
//            	params.clientNo="333";
//            	params.sysNo="00";
//            	
//            }else if(params.srcSystem=="MET600System"){
//            	params.hostName="sapvmetsb.vceaa.root";
//            	params.clientNo="600";
//            	params.sysNo="00";
//            }else if(params.srcSystem=="MET700System"){
//            	params.hostName="sapvmetsb.vceaa.root";
//            	params.clientNo="700";
//            	params.sysNo="00";
//            }else if(params.srcSystem=="MET500System"){
//            	params.hostName="sapvmetsb.vceaa.root";
//            	params.clientNo="500";
//            	params.sysNo="00";	
//            }
            if($rootScope.customDestFlagFrDwnld=='Y')
            	{
                params.sapUserId = $rootScope.sapUserID;                
                params.destPasswrd = $rootScope.eSapPassword;      
                params.language=$rootScope.sapLang;
            	}
         
            params.custDestReq = $rootScope.customDestFlagFrDwnld;
//            if(params.srcSystem=="EUT333System" && $rootScope.customDestFlagFrDwnld=='N'){
//            	 params.sapUserId = "E_JRUBIO";
//                 params.destPasswrd = "jrubio";
//            	
//            }else if(params.srcSystem=="MET600System" && $rootScope.customDestFlagFrDwnld=='N'){
//            	 params.sapUserId = "E_PREMOLI";
//                 params.destPasswrd = "Accenture02";
//            }else if(params.srcSystem=="MET700System" && $rootScope.customDestFlagFrDwnld=='N'){
//            	 params.sapUserId ="E_JRUBIO";
//                 params.destPasswrd = "jrubio1";
//            }else if(params.srcSystem=="MET500System" && $rootScope.customDestFlagFrDwnld=='N'){
//            	 params.sapUserId = "E_PREMOLI";
//                 params.destPasswrd = "Accenture01";	
//            }
            //Added for Logging 
            params.transactionID = $rootScope.transactionID;
            //Ended for Logging 
            params.sessionInputDTO = $rootScope.sessionInputObj;	
            params.copyFlag = false;
           
            //params.language = "EN";

            $rootScope.downloadScopeList[downloadCount].resError = "Download Started";//Message Change while click download - 29-June-2017
            $rootScope.downloadScopeList[downloadCount].imgId = $rootScope.selectedScopeData[downloadCount].imgId;
            $rootScope.downloadScopeList[downloadCount].imgDescription = $rootScope.selectedScopeData[downloadCount].imgDescription;

            $rootScope.overlay_download = document.getElementById("overlay_execute");
            $rootScope.popup_download = document.getElementById("busy_execute");
            $rootScope.overlay_download.style.display = "block";
            $rootScope.popup_download.style.display = "inline-block";
            
            $http.post(url,params).then(function(responseData){
            	if(responseData.data.resMessageDto != null && responseData.data.resMessageDto.message == serviceMessage){
      	      		$rootScope.checkAuthorization();
      	      	}
            	else{
            	var responseData = responseData.data;
            	$rootScope.downloadScopeList[downloadCount].targetFilePath = responseData.targetFilePath;
            	$rootScope.downloadScopeList[downloadCount].bytes = responseData.bytes;
            	$rootScope.downloadScopeList[downloadCount].resError = responseData.resError;
            	$rootScope.downloadScopeList[downloadCount].scopeAvilable = responseData.scopeAvilable;
            	$rootScope.downloadScopeList[downloadCount].scopeAvilableIcon = responseData.scopeAvilableIcon;
            	$rootScope.downloadScopeList[downloadCount].downloadStatus = responseData.downloadStatus;
            	$rootScope.downloadScopeList[downloadCount].downloadStatusIcon = responseData.downloadStatusIcon;
            	
            	
            	if(!responseData.downloadStatus){
            		$rootScope.downloadButtondisabled  = false;	
            	}
                $rootScope.overlay_download.style.display = "none";
                $rootScope.popup_download.style.display = "none";

            	downloadCount++;
            	if( downloadCount < $rootScope.selectedScopeData.length && currentCount < zipfilecount ){
            		 if(twentyMinutesLater.getMinutes() - twentyMinutesBefore.getMinutes() == 24){
            			 var inputParam = {
            			  			sessionId : $rootScope.sessionInputObj.sessionId,
            			  			csrfToken : $rootScope.sessionInputObj.csrfToken
            			  	}
            			  $http.post("/" + servicePrefix + "/rest/adminSrv/resetSessionTime", inputParam).then(function(response) {
            				  if(response.status == 200){
            					if(response.data.dataStatus == true){
            						//Idle.setIdle();
            						twentyMinutesBefore = new Date();
            						console.log("Session extended");
            					}
            					}
            			  });
            		 }
            		 $rootScope.download = true; 
           		 currentCount++;
           		 if((downloadCount/$scope.articlesPerPage)> 0)
                  			$scope.currentPage = Math.floor(downloadCount/$scope.articlesPerPage)+1;
                    $scope.singleFileDownload();
                }
           	 else{
           		 if(downloadCount == $rootScope.selectedScopeData.length)
           			 $rootScope.download = false;
           		 	$scope.isZipFile=true;
           			for(var i = (downloadCount-currentCount); i< downloadCount ;i++){
                   		if($rootScope.downloadScopeList[i].downloadStatus == false){
                   			var fileName ;
                   			if($rootScope.industryFlag && !$rootScope.copy){
                   				
                   				var desc = ($rootScope.downloadScopeList[i].imgDesc)+"_"+$rootScope.aliasIndustry+"_"+$rootScope.aliasSubIndustry;
                   				 fileName =  desc.replace(/[><:"/\\|?*]/g, " ").trim().replace(/\s\s+/g, ' ');	
                   			}else{
                   				 fileName =  ($rootScope.downloadScopeList[i].imgDesc).replace(/[><:"/\\|?*]/g, " ").trim().replace(/\s\s+/g, ' ');
                   			}
               			
               			var seqNumber =  $rootScope.downloadScopeList[i].seqNumber;
               			var byteData =  $rootScope.downloadScopeList[i].bytes;

               			var fileBytes = base64ToArrayBuffer(byteData);
               			$scope.fileNameList.push(seqNumber + "_" + fileName + ".xlsx");

                     		saveByteArray([fileBytes], seqNumber+"_"+fileName+".xlsx");	
                   		}
               		}
           			
           			$scope.generateZipFile(); 
            	 }
            	}
            }) ,(function(data){
//             $scope.errorResponse(data);
            	$rootScope.downloadScopeList[downloadCount].resError = "Download Failed due to service failure.."
//            	console.log("ERROR");
//            	$mdDialog.cancel();
                $rootScope.overlay_download.style.display = "none";
                $rootScope.popup_download.style.display = "none";

            	downloadCount++;
            	
            	if( downloadCount < $rootScope.selectedScopeData.length && currentCount < zipfilecount ){
           		 if(twentyMinutesLater.getMinutes() - twentyMinutesBefore.getMinutes() == 24){
           			 var inputParam = {
           			  			sessionId : $rootScope.sessionInputObj.sessionId,
           			  			csrfToken : $rootScope.sessionInputObj.csrfToken
           			  	}
           			  $http.post("/" + servicePrefix + "/rest/adminSrv/resetSessionTime", inputParam).then(function(response) {
           				  if(response.status == 200){
           					if(response.data.dataStatus == true){
           						//Idle.setIdle();
           						twentyMinutesBefore = new Date();
           						console.log("Session extended");
           					}
           					}
           			  });
           		 }
           		 $rootScope.download = true; 
          		 currentCount++;
          		 if((downloadCount/$scope.articlesPerPage)> 0)
                 			$scope.currentPage = Math.floor(downloadCount/$scope.articlesPerPage)+1;
                   $scope.singleFileDownload();
               }
           	 else{
     		 	$scope.isZipFile=true;
           		for(var i =0,arrLen = $rootScope.downloadScopeList.length; i< arrLen ;i++){
            		if($rootScope.downloadScopeList[i].downloadStatus == false){
            			var fileName ;
            			if($rootScope.industryFlag && !$rootScope.copy){
               				
               				var desc = ($rootScope.downloadScopeList[i].imgDesc)+"_"+$rootScope.aliasIndustry+"_"+$rootScope.aliasSubIndustry;
               				 fileName =  desc.replace(/[><:"/\\|?*]/g, " ").trim().replace(/\s\s+/g, ' ');	
               			}else{
               				 fileName =  ($rootScope.downloadScopeList[i].imgDesc).replace(/[><:"/\\|?*]/g, " ").trim().replace(/\s\s+/g, ' ');
               			}
            	
        			var seqNumber =  $rootScope.downloadScopeList[i].seqNumber;
        			var byteData =  $rootScope.downloadScopeList[i].bytes;
        			
        			var fileBytes = base64ToArrayBuffer(byteData);
        	         $scope.fileNameList.push(seqNumber + "_" + fileName + ".xlsx");
        	         saveByteArray([fileBytes], seqNumber+"_"+fileName+".xlsx");	
            		}
        		}
           		$scope.generateZipFile();
           		 
           	 }
            });
   	     }, function myError(response) {
	        });
            
        //}
        	/*else{
        		
        		
        	}*/
    	}
	
	/*$scope.singleFileDownload = function(val){
		var url = "/" + servicePrefix + "/rest/autoConfigSrv/getDwldScopeForBrwnMod";
        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
        
        var params = {"imgHierarchyCustomDto":[{"imgId":"","imgDesc":"","seqNumber":""}],
        	"srcSystem":"","systemType":"SAP ECC"};
        
        params.imgHierarchyCustomDto[0].imgDesc =  $rootScope.selectedScopeData[val].imgDescription;
        params.imgHierarchyCustomDto[0].seqNumber = $rootScope.selectedScopeData[val].sequence;
        params.imgHierarchyCustomDto[0].imgId = $rootScope.selectedScopeData[val].imgId;
        params.srcSystem = $rootScope.sourceSystem.value;
        
        console.log(params.srcSystem);
        console.log(params.imgHierarchyCustomDto[0].imgDesc);
        
        $mdDialog.show({
            controller: function($scope, $mdDialog){
            $scope.isLoading = true;
            },
            templateUrl: 'view/busy.html?ver='+version,
            parent: angular.element(document.body),
            clickOutsideToClose: false,
            fullscreen: useFullScreen,
            escapeToClose: false,
        })
        .then(function(answer) {
        }, function() {
        });
        $http.post(url,params).success(function(responseData){
        	console.log("SUCCESS" +responseData);
        	console.log("SUCCESS" +responseData.imgId);
        	console.log("SUCCESS" +responseData.imgDesc);
        	console.log("SUCCESS" +responseData.seqNumber);
        	console.log("SUCCESS" +responseData.targetFilePath);
        	console.log("SUCCESS" +responseData.bytes);
        	console.log("SUCCESS" +responseData.resError);
        	
        	if(responseData.bytes == null){
        		ngDialog.openConfirm({
    	            template: responseData.resError,
    	            plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350
    	        });
        	}else{
        		$scope.downloadFile(responseData.bytes,responseData.seqNumber,responseData.imgDesc);
        	}
        	 
        	$mdDialog.cancel();
        	
        }) .error(function(data){
//         $scope.errorResponse(data);
        	console.log("ERROR");
        	$mdDialog.cancel();
        });
	}
	*/
	
	
	    //Validate Mandatory fields before execute 
	    $scope.fileDownloadValidation = function () {
	    		if($rootScope.FileList.length > 0 ){
	    		$scope.isValid = true;
	    		for (var i = 0,arrLen = $rootScope.selectedScopeData.length; i < arrLen ; i++) {
//	    			console.log( $rootScope.selectedScopeData[i].fileName);
	    			if( $rootScope.FileList[i].fileName == "" ||  $rootScope.FileList[i].filepath == "")
	    				$scope.isValid = false;
	    		}
	    		if($scope.isValid === true){
	    		$scope.fieldError = false;
	    		var myDate = new Date();
	            myDate.setHours(myDate.getHours() + 1);
	            $rootScope.executeAuth = "true";
	            //$rootScope.configAuth = "false";
	           // document.cookie = "executeAuth=" + $rootScope.executeAuth + ";expires=" + myDate.toUTCString();
	            //document.cookie = "configAuth=" + $rootScope.configAuth + ";expires=" + myDate.toUTCString();
	    		$location.path("/ConfigHeader/configExecute");
	    		}else{
//	    			$scope.fieldErrorMsg = "File is not saved in server";
	    	    	$scope.fieldError = true;
	    	    	$scope.isSuccess = false;
	    		}
	    }else{
//	    	$scope.fieldErrorMsg = "Upload Configuration file to proceed";
	    	$scope.fieldError = true;
	    	$scope.isSuccess = false;
	    }
	    	
	    	
	    }
	    
		$scope.downloadPrevious = function(){
			if($rootScope.implType == "2" ){
			 	$rootScope.implTypelabel = "defaultImplType";
				$rootScope.implTypelabel2 = "secondImplType";
				$rootScope.implTypelabel3 = "defaultImplType";
				
			}else if($rootScope.implType == "3" ){
			 	$rootScope.implTypelabel = "defaultImplType";
				$rootScope.implTypelabel2 = "defaultImplType";
				$rootScope.implTypelabel3 = "secondImplType";
			}
    		if(($rootScope.implType == "2"  || $rootScope.implType == "3") && $rootScope.modTypes.value == "Automated with intervention"){
    			 
    			  	$rootScope.name  = "active";
	 	    		$rootScope.name1 = "not-active";
	 	    		$rootScope.name2 = "not-active";  
	 	    		$rootScope.name3 = "not-active";
	 	    		
	 	    		$rootScope.wizard1  = "activewizard";
					$rootScope.wizard2  = "applicablewizard";
					$rootScope.wizard3  = "applicablewizard";
					$rootScope.wizard4  = "applicablewizard";
					 
    			  $rootScope.configInital = "true";
    			  //document.cookie = "configInitial=" + $rootScope.configInital + ";expires=" + myDate.toUTCString();
    			  $location.path('/ConfigHeader/configPage');
    		}
    	}
		
		$scope.configUpload = function(){
			
			/*  if($rootScope.hierarchyTypes.value == "IMG"){
		 	 		 $rootScope.selectedScopes = $rootScope.selectedScopeData;
		 	 		 $rootScope.uploadedScopes = $rootScope.selectedScopeData;
		 	 	  }else{
		 	 		 $rootScope.selectedScopes = $rootScope.selectedBPData; 
		 	 		 $rootScope.uploadedScopes = $rootScope.selectedBPData;
		 	 	}*/
	    		$rootScope.targetsystemEnabled = false;
	    		$rootScope.fileUploadAuth = "true";
	    		
	    		$rootScope.name = "not-active";
 	    		$rootScope.name1 = "not-active";
 	    		$rootScope.name2 = "active";  
 	    		$rootScope.name3 = "not-active";
 	    		
 	    		 $rootScope.wizard1  = "donewizard";
				 $rootScope.wizard2  = "donewizard";
				 $rootScope.wizard3  = "activewizard";
				 $rootScope.wizard4  = "applicablewizard";
				 
	    		var myDate = new Date();
	            myDate.setHours(myDate.getHours() + 1);
	           $rootScope.selectedScopes = $rootScope.downloadScopeList;
	          // document.cookie = "fileUploadAuth=" + $rootScope.fileUploadAuth + ";expires=" + myDate.toUTCString();
	    		$location.path("/ConfigHeader/fileUpload");
	    		
	    		
	    	}
	    		$scope.directUpload = function(){
	    			ngDialog.openConfirm({
	            template: 'view/config/directUpload.html?ver='+version,		           
	            //controller:'ConfigFileUploadPage',
	            scope: $scope,
	            closeByDocument: false,
	            closeByEscape: false,
	           showClose: false,
	           height: 140,
	            width: 500,
	            className:'ngdialog-theme-default CLASS_projHierarchy'
	        });
			
		}
	    		$scope.cancelUpload = function(){
	   			 ngDialog.close();
	   		}
	   		
	   		$scope.okUpload = function(){
	   		 /* if($rootScope.hierarchyTypes.value == "IMG"){
		 	 		 $rootScope.selectedScopes = $rootScope.selectedScopeData;
		 	 		 $rootScope.uploadedScopes = $rootScope.selectedScopeData;
		 	 	  }else{
		 	 		 $rootScope.selectedScopes = $rootScope.selectedBPData; 
		 	 		 $rootScope.uploadedScopes = $rootScope.selectedBPData;
		 	 		 	  }*/
	   			$rootScope.name = "not-active";
 	    		$rootScope.name1 = "not-active";
 	    		$rootScope.name2 = "active";  
 	    		$rootScope.name3 = "not-active";
 	    		
 	    		 $rootScope.wizard1  = "donewizard";
				 $rootScope.wizard2  = "donewizard";
				 $rootScope.wizard3  = "activewizard";
				 $rootScope.wizard4  = "applicablewizard";
	   			
	   			if(saveByteArray!=null){
	   			$rootScope.fileUploadAuth = "true";
	       		var myDate = new Date();
	               myDate.setHours(myDate.getHours() + 1);
		           $rootScope.selectedScopes = $rootScope.downloadScopeList;
	              //document.cookie = "fileUploadAuth=" + $rootScope.fileUploadAuth + ";expires=" + myDate.toUTCString();
	       		$location.path("/ConfigHeader/fileUpload");
	       		ngDialog.close();
	   			}
	   		}
		 $scope.generateZipFile = function(){
           	 var zip = new JSZip();
           	 var count = 0;
           	 var count1 = 0;
			 $scope.arrayImg.forEach(function(url){
           		 //console.log(url)
           		 
           		  var filename =  $scope.fileNameList[count];
           		  //i++;
           		  count++;
           		  // loading a file and add it in a zip file
           		  JSZipUtils.getBinaryContent(url, function (err, data) {
           		     if(err) {
           		        throw err; // or handle the error
           		     }
           		     zip.file(filename, data, {binary:true});
           		     if (count == $scope.arrayImg.length) {
           		       /*var zipFile = zip.generate({type: "blob"});
           		       saveAs(zipFile, "examples.zip");*/
           		       
           		    zip.generateAsync({type:"blob"}).then(function(content) {
           		     // see FileSaver.js
           		    count1++;
          		     if (count1 == $scope.arrayImg.length) {
          		    	 saveAs(content, $rootScope.sourceSystem.value+".zip");
          		     if(downloadCount < $rootScope.selectedScopeData.length){
          		    	 currentCount = 1;
          		    	 $scope.arrayImg = [];
          		    	 $scope.singleFileDownload();
          		     }
          		     }
           		 });
           		     }
           		  });
           		});
		  		
		        };
		        
		        
		        //Create config transaction before Execute
			    $scope.createConfigTransaction = function(){
			    	
			    	if($rootScope.customDestFlagFrDwnld == "Y"){ // if added by Veena
			    		ngDialog.openConfirm({
			  	  			template: 'view/config/sapLoginDetails.html?ver='+version,
			  	  			scope: $scope,
			  	  			//controller: "ConfigFileDownloadPage",
			  	  			closeByDocument: false,
			  	  			closeByEscape: false,
			  	  			showClose: true,
			  	  			height: 500,
			  	  			width: 527
			        });
			    	}
			    	else{
			    		$rootScope.configDowld();
			    }
			 	};
			 	$rootScope.configDowld = function(){
			 		$rootScope.enableExport = false;
			    	$rootScope.disableDownload = true;
			    	$rootScope.disableSkip = true;//newly added for disabling skip and proceed
			    	$rootScope.downloadButtondisabled = false;
			    	var ConfigTransactionDto = {};
			    	ConfigTransactionDto.omgID  = $rootScope.projOmId;
			    	ConfigTransactionDto.userID = $rootScope.username;
			    	
			    	ConfigTransactionDto.sourceValue = $rootScope.sourceValue;
			    	ConfigTransactionDto.scenario = $rootScope.scenario;

			    	ConfigTransactionDto.sapUserID = "";
			    	ConfigTransactionDto.scenario = $rootScope.scenario;
			    	ConfigTransactionDto.sourceValue = $rootScope.sourceValue;
			    	ConfigTransactionDto.sessionInputDTO = $rootScope.sessionInputObj;	
			    	var  configTranUrl = "/" + servicePrefix + "/rest/configAuditService/createConfigTransaction";

				        $http.post(configTranUrl,ConfigTransactionDto).then(function(transactionData){
				        	if(transactionData.data.resMessageDto != null && transactionData.data.resMessageDto.message == serviceMessage){
			      	      		$rootScope.checkAuthorization();
			      	      	}else{
				        	$rootScope.transactionID = transactionData.data.message;
				        	if($rootScope.transactionID  > 0){
				        		$scope.singleFileDownload();
					         
				        		}
				        	}
				        	}) ,(function(data){
				            });
			 	}
			 	$scope.downloadConfigLogs = function(){
			 		var d = new Date();
			 		var fileName = "ConfigDwdLogsExport"+d.getDate()+""+d.getMonth()+""+d.getYear()+""+d.getTime();
			 		alasql('SELECT imgId as ScopeName,imgDescription as ImgDescription,resError as DownloadStatus INTO XLSX("'+fileName+'.xlsx",{headers:true}) FROM ?',[$rootScope.downloadScopeList]);
			 	};
		        
			 /*	$scope.checkSAPCredentials = function(){
			 		$scope.sapUserID = document.getElementById("sapLoginId").value;
			 		$scope.sapPassword = document.getElementById("sapPassword").value;
			 		$scope.lang = document.getElementById("sapLanguage").value;
			 		$rootScope.selectedSystem = document.getElementById("sapSysId").textContent;
			 		
			 		$rootScope.validateSapDetails($scope.sapUserID,$scope.sapPassword,$scope.lang,$scope.tempDownload);
			 		$scope.msgErrorDisplay =  $rootScope.msgError;
			 		//$scope.systemMsg = $rootScope.systemStatusMsg;
			 		//$scope.systemStatus = $rootScope.systemup;
			 	};*/
			 $scope.cancelsapDetails = function(){
					$rootScope.sapUserID = "";
					$rootScope.sapPassword = "";
					ngDialog.close();		
					$mdDialog.cancel();
					};
}]);