var app = angular.module('yapp').controller('ConfigExecutePage',["ngDialog","Upload","$scope","$rootScope","$http","$mdDialog","$mdMedia","$location","$filter","$ocLazyLoad", function(ngDialog,Upload,$scope,$rootScope,$http,$mdDialog,$mdMedia,$location,$filter,$ocLazyLoad) {
	$ocLazyLoad.load(controllerName+'/config/DependencyLogs.js?ver='+version);
	$ocLazyLoad.load(controllerName+'/config/ScopeLogs.js?ver='+version);
	$ocLazyLoad.load(controllerName+'/config/configTilesPage.js?ver='+version);
	$scope.isLoading = false;
	//Browser Refresh - 13 Nov 2017
	if($rootScope.appValidity == undefined){
		 $rootScope.username = "";
		    $rootScope.password = "";
		   /* var cookies = document.cookie.split(";");
		    for (var i = 0, arrLen = cookies.length; i < arrLen ; i++) {
		        var cookie = cookies[i];
		        var eqPos = cookie.indexOf("=");
		        var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
		        document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
		    }*/
		    $location.path('/loginPage');
	}
	
	//Idle Time out Logic - Start 
/*	$rootScope.$on('export-pdf', function (e, d) {
        elm.tableExport({ type: 'pdf', escape: false });
    });*/
	
//	$rootScope.downloadScope = [];
//	$rootScope.skipExecute = false; 
//	$rootScope.trnumber = "";
	var timeBefore = new Date();
	$rootScope.name3 = "active";  
	$rootScope.name1 = "not-active"; 
	$rootScope.name2 = "not-active";
	$rootScope.name = "not-active";
	
	$rootScope.tempDownload = false; 
	if($rootScope.modTypes.value == "Automated without intervention")
		{
		$rootScope.name1 = "active1"; 
		$rootScope.name2 = "active1";
		}
	
	$rootScope.isReExecutionReq = false;
	$rootScope.executionName = "EXECUTE";
	$scope.executionFileSize = 0;
	$scope.connectionStatus = true;
	if(!$rootScope.showLogsExportData){
		$scope.viewlogsLink = "viewlogs";
//		$scope.executeDisabled = false;
//		$scope.previousDisabled = false;
		$scope.tableCont = true;
		$rootScope.msg1 = " ";
		$rootScope.msg2 = " ";
		$rootScope.msg3 = " ";
		$rootScope.msg4 = " ";
	    //$rootScope.reportData = [];


	}
	else{
		$rootScope.reportData = [];
	}
	$rootScope.showLogsExportData = false;
//	$scope.execute="beforeexecute"; 

//	$rootScope.scopeName = "";
	$scope.showdialog = true;
	$scope.currentPage = 1;
	$scope.articlesPerPage = 6;
	$scope.successCount = 0;
	$scope.errorCount = 0;	
	$scope.manualCount = 0;
	/*$rootScope.sapUserID = "";
	$rootScope.sapPassword = "";*/
	$rootScope.reExecution = false;
	$rootScope.retryExecution = false;
	var count = 0;
	 $scope.reExecuteDisabled = false;
	 $scope.executeDisabled = false;
	 $scope.previousDisabled = false;
	 $scope.executionRequired = true;
	 
	 $scope.commonTR = {};
	 $scope.img = {};
	 $scope.img.manualConfig = "";
	 $scope.commonTR.transportReqNo ="";
	 $scope.commonTR.workBench_transportReqNo ="";
	//$rootScope.reportData = [];
	var noAuth = "false";
	var homeAuth="false";
	var resetAuth="false"
		
	$scope.isScopeAvailable = false;
		/*var myDate = new Date();
    myDate.setHours(myDate.getHours() + 1);
	var cookie = document.cookie;
	var cookieAuthParams = cookie.split(';');*/
	/*Adding for dynamically loading rows in table*/
	/*$scope.barLimit = 10;
    $scope.increaseLimit = function() {
      $scope.barLimit += 20;
      
    }*/
    
	$scope.barLimit1 = 10;
    $scope.increaseLimit1 = function() {
      $scope.barLimit1 += 20;
    
    }
    
  	//console.log($rootScope.sourceSysData.length);
  	if($rootScope.sourceSysData != null){
	for (var i = 0; i < $rootScope.sourceSysData.length; i++) {
		 if(($rootScope.implType == "1" || $rootScope.implType == "2")  && $rootScope.sourceSysData[i].isHVESSystem == 0 && $rootScope.sourceSysData[i].destinationName == $rootScope.sourceSystem.value){
			$rootScope.sourceSystemType = $rootScope.sourceSysData[i].systemType;
			break;
		 }else if($rootScope.implType == "3" && $rootScope.sourceSysData[i].isHVESSystem == 1 && $rootScope.sourceSysData[i].destinationName == $rootScope.sourceSystem.value){
			$rootScope.sourceSystemType = $rootScope.sourceSysData[i].systemType;
			break;
		 }
		}
  	}
  	for (var i = 0,arrLen = $rootScope.targetSysData.length; i < arrLen ; i++) {
 		 if(($rootScope.implType == "1" || $rootScope.implType == "2") && $rootScope.targetSysData[i].destinationName == $rootScope.selectedTargetSystem){
 			$rootScope.targetSysID = $rootScope.targetSysData[i].systemType;
 			$rootScope.targetClientNo = $rootScope.targetSysData[i].sapClientNo;
 			$rootScope.targetSID = $rootScope.targetSysData[i].systemId;
 			break;
 		 }else if($rootScope.implType == "3"  && $rootScope.targetSysData[i].destinationName == $rootScope.selectedTargetSystem){
 			$rootScope.targetSysID = $rootScope.targetSysData[i].systemType;
 			$rootScope.targetClientNo = $rootScope.targetSysData[i].sapClientNo;
 			$rootScope.targetSID = $rootScope.targetSysData[i].systemId;
 			break;
 		 }else{
 			$rootScope.targetSysID = "";
 			$rootScope.targetClientNo = "";
 		 }
}
  	

	//TR changes
  	$rootScope.execute = "Execute";
  	$rootScope.editwtricon = "editicon";
  	$rootScope.editktricon = "editicon";
  	$rootScope.editTR = "editTR";
	// $rootScope.executionLogsData = $rootScope.uploadedScopes;
/*	for (var cp1 = 0; cp1 < cookieAuthParams.length; cp1++) {
		if (cookieAuthParams[cp1].split('=')[0].trim() == "configAuth" && cookieAuthParams[cp1].split('=')[1].trim() == "true") {
			noAuth = "true"
		}
//				for(var cp2 = 0; cp2 < cookieAuthParams.length; cp2++){
		if (cookieAuthParams[cp2].split('=')[0].trim() == "executeAuth" && cookieAuthParams[cp2].split('=')[1].trim() == "true") {
			homeAuth="true"
			document.cookie = "fileUploadAuth=" + resetAuth + ";expires=" + myDate.toUTCString();
		}
		
	}*/
/*	for(var i = 0,arrLen = cookieAuthParams.length; i < arrLen ; i++){*/
		/*if (cookieAuthParams[i].split('=')[0].trim() == "configAuth" && cookieAuthParams[i].split('=')[1].trim() == "true") {
			noAuth = "true"
		}*/
		if ($rootScope.configAuth == "true") {
			noAuth = "true"
		}
		if ($rootScope.executeAuth == "true") {
			homeAuth="true"
			$rootScope.fileUploadAuth = resetAuth;
			//document.cookie = "fileUploadAuth=" + resetAuth + ";expires=" + myDate.toUTCString();
		}
	/*	if (cookieAuthParams[i].split('=')[0].trim() == "executeAuth" && cookieAuthParams[i].split('=')[1].trim() == "true") {
			homeAuth="true"
			document.cookie = "fileUploadAuth=" + resetAuth + ";expires=" + myDate.toUTCString();
		}*/
		//Removing SAP credentials from cookie for security reasons
	/*	if (cookieAuthParams[i].split('=')[0].trim() == "sapLoginID" ) {
			$rootScope.sapUserID = cookieAuthParams[i].split('=')[1].trim();
		}
		if (cookieAuthParams[i].split('=')[0].trim() == "sapPasswrd" ) {
			$rootScope.sapPassword = cookieAuthParams[i].split('=')[1].trim();
		}*/
		
	/*}*/
	//Browser Refresh - 13 Nov 2017
	if($rootScope.appValidity != undefined){
	
		if (noAuth == "false") {
			$location.path('/loginPage');
		}else if(homeAuth=="false"){
	//		$location.path('/ConfigHeader/configPage');
			$location.path('/configTilesPage');		
		}
	}
	$scope.fieldErrorMsg = "";
	$scope.fieldError = false;
	$rootScope.downloadStatus = [];
	$rootScope.failure = false;

	function isNumber(evt) {
	    evt = (evt) ? evt : window.event;
	    var key = event.keyCode;
	   
	    var charCode = (evt.which) ? evt.which : evt.keyCode;
	    if (charCode > 31 && (charCode < 48 || charCode > 57) && (key >= 65 && key <= 90) || key == 8) {
	        return false;
	    }
	    return true;
	};
	function testInput(event) {
		   var value = String.fromCharCode(event.which);
		   var pattern = new RegExp(/[a-zåäö0-9]/i);
		   return pattern.test(value);
		}

		$('#trnumber').bind('keypress', testInput);

	
	$scope.hidesapErrorMsg = function() {
	       
 		 document.getElementById("saperrormsg").style.display="none";

	    };
$scope.toggleExecutionStatus = function(manualConfig){
			
			if(manualConfig){
				 ngDialog.close();
				 if($scope.executionFileSize < $rootScope.uploadedScopes.length){
				 $scope.executionFileSize++;
					if( $rootScope.implType == "1" ){
		    			$scope.greenFieldExecution();
		    		}else if( $rootScope.implType == "2" || $rootScope.implType == "3"){
		    			if($rootScope.modTypes.value == "Automated with intervention"){
		    					$scope.greenFieldExecution();
		    			}else if($rootScope.modTypes.value == "Automated without intervention"){ 
		    				 $scope.brownFieldDownload();
		    			}
		    		}
				}
  	       	}
		};
		$scope.cancelManualConfig = function(){
			ngDialog.close();
    		if($scope.executionFileSize < $rootScope.uploadedScopes.length){
    		$scope.executionFileSize++;
    		if($rootScope.implType == "1" ){
//    	 		$rootScope.uploadedScopes = [];
    	 		$scope.greenFieldExecution();
    			}else if($rootScope.implType == "2" || $rootScope.implType == "3"){
    				if($rootScope.modTypes.value == "Automated without intervention")
    					$scope.brownFieldDownload();
    				else if($rootScope.modTypes.value == "Automated with intervention")
    					$scope.greenFieldExecution();
    				}    			            		
					  }
		}
/*	$scope.validateSapDetails = function(){
		
		$rootScope.username = $scope.username;
        $rootScope.password = $scope.password;
        $scope.submitted = true;
        $scope.msgError = false;
        $rootScope.sapUserID  = document.forms["sapForm"]["sapLoginId"].value;
        $rootScope.sapPassword = document.forms["sapForm"]["sapPassword"].value;
        $rootScope.sapLanguage = document.forms["sapForm"]["sapLanguage"].value;

       
        Session["status"] =sapID;
        var session_value=Session["status"];
        console.log(session_value);
        
        if ($rootScope.sapUserID == "") {
        	$scope.ErrorMsg = "Please enter SAP Login ID";
		    $scope.msgError = true;
		    return;
        }
        else if( $rootScope.sapPassword == ""){
        	
        	$scope.ErrorMsg = "Please enter SAP Password";
		    $scope.msgError = true;
		    return;

        }else if($rootScope.sapUserID.length > 15){
        	$scope.ErrorMsg = "Please enter SAP Login ID with 15 characters";
		    $scope.msgError = true;
		    return;

        }
        else if ($rootScope.sapLanguage == ""){
        	$scope.ErrorMsg = "Please enter one of the installed languages";
		    $scope.msgError = true;
		    return;
        }
        else if (new RegExp($rootScope.languagePattern).test($rootScope.sapLanguage) == false){
        	$scope.ErrorMsg = "Only alphabets allowed for language";
		    $scope.msgError = true;
		    return;
        }
        
        if( $scope.msgError == false){
        	$scope.hidesapErrorMsg();
            ngDialog.close();

        	}
      
      
        $rootScope.overlay = document.getElementById("overlay_execute");
        $rootScope.popup = document.getElementById("busy_execute");
        $rootScope.overlay.style.display = "block";
        $rootScope.popup.style.display = "inline-block";
       $mdDialog.show({
            controller: function($scope, $mdDialog){
            $scope.isLoading = true;
            },
            templateUrl: 'view/busy.html?ver='+version,
            parent: angular.element(document.body),
            clickOutsideToClose: false,
            fullscreen: useFullScreen,
            escapeToClose: false,
        });
        var iv = CryptoJS.lib.WordArray.random(128/8).toString(CryptoJS.enc.Hex);
        var salt = CryptoJS.lib.WordArray.random(128/8).toString(CryptoJS.enc.Hex);

        var aesUtil = new AesUtil(128, 1000);
       // var encryptedSAPId = aesUtil.encrypt(salt, iv, $rootScope.selectedTargetSystem, $rootScope.sapUserID);
       // var aesSAPId = (iv + "::" + salt + "::" + encryptedSAPId);
       // $rootScope.eSapUserId = btoa(aesSAPId);
        
        var encryptedSapPassword = aesUtil.encrypt(salt, iv, $rootScope.selectedTargetSystem, $rootScope.sapPassword);
        var aesSapPassword = (iv + "::" + salt + "::" + encryptedSapPassword);
        $rootScope.eSapPassword = btoa(aesSapPassword);
        
        var params={	
        		sapUserId:$rootScope.sapUserID,
        		password:$rootScope.eSapPassword,
        		destinationName:$rootScope.selectedTargetSystem,
        		sessionInputDTO : $rootScope.sessionInputObj,	
        		sapLanguage : $rootScope.sapLanguage
               };
        
        $rootScope.sapDestination = $rootScope.selectedTargetSystem;
        if($rootScope.sapUserID!=null && $rootScope.sapPassword!=null && $rootScope.sapUserID!="" && $rootScope.sapPassword!=""){
        $http.post("/" + servicePrefix + "/rest/dynamicDestination/validateDestination", params).then(function(response) {
            if(response.status === 200 && response.data.status === "Success"){
            	// $http.post("/" + servicePrefix + "/rest/dynamicDestination/validateSAPCredentials", params).then(function(response) {
            		// if(response.status === 200 && response.data.status === "Success"){
            	ngDialog.close();
            	//$mdDialog.cancel();
            	 $rootScope.overlay = document.getElementById("overlay_execute");
        	     $rootScope.popup = document.getElementById("busy_execute");
        	     $rootScope.overlay.style.display = "none";
        	     $rootScope.popup.style.display = "none";

    	         $scope.dependencyCheck();
                 
    	        
            	var myDate = new Date();
		        myDate.setHours(myDate.getHours() + 1);
                document.cookie = "sapLoginID=" + $rootScope.sapUserID + ";expires=" + myDate.toUTCString();
                document.cookie = "sapPasswrd=" + $rootScope.sapPassword + ";expires=" + myDate.toUTCString();
            		// }
            		else{
            			 $scope.ErrorMsg = response.data.message;
                 		$scope.msgError = true;
                 		 ngDialog.close();
                 		 $rootScope.overlay = document.getElementById("overlay_execute");
                	     $rootScope.popup = document.getElementById("busy_execute");
                	     $rootScope.overlay.style.display = "none";
                	     $rootScope.popup.style.display = "none";
                 		ngDialog.openConfirm({
     		            template: 'view/config/sapLoginDetails.html?ver='+version,
     		            scope: $scope,
     		            closeByDocument: false,
     		            closeByEscape: false,
     		            showClose: true,
     		            height: 500,
     		            width: 527,
     		           className:'ngdialog-theme-default CLASS_projName'
     		        });
            			 
            		 }
           // });
            }else if(response.data.resMessageDto != null && responseData.data.resMessageDto.message == serviceMessage){
  	      		$rootScope.checkAuthorization();
  	      	} else{
            		$scope.ErrorMsg = response.data.message;
            		$scope.msgError = true;
            		 ngDialog.close();
            		  $rootScope.overlay = document.getElementById("overlay_execute");
            	     $rootScope.popup = document.getElementById("busy_execute");
            	     $rootScope.overlay.style.display = "none";
            	     $rootScope.popup.style.display = "none";
            		ngDialog.openConfirm({
		            template: 'view/config/sapLoginDetails.html?ver='+version,
		            scope: $scope,
		            closeByDocument: false,
		            closeByEscape: false,
		            showClose: true,
		            height: 500,
		            width: 527,
		            className:'ngdialog-theme-default CLASS_projName'
		        });
            		
            }
        });
}
	};*/
 /* 	$scope.isTREnabled = function(){
        var trFeatureEnabled = false;
        if($rootScope.trOverRide != undefined && $rootScope.trOverRide != null && $rootScope.trOverRide.length > 0){
        	trFeatureEnabled = true;
        }else if($rootScope.trModulewiseEnabled){
        	trFeatureEnabled = true;
        }
        else{
        	 for(var i= 0; i< $rootScope.executionLogsData.length; i++){
                 if($rootScope.executionLogsData[i].customizingTr != null && $rootScope.executionLogsData[i].customizingTr.length > 0){
                        trFeatureEnabled = true;
                        break;
                 }else if($rootScope.executionLogsData[i].workbenchTr != null && $rootScope.executionLogsData[i].workbenchTr.length > 0){
                        trFeatureEnabled = true;
                        break;
                 }
          }
        	
        }
        
        return trFeatureEnabled;
 };*/
 
 $scope.configExecute = function(){
	/* ngDialog.openConfirm({
         template: 'view/config/alertManualConfig.html?ver='+version,
         preCloseCallback:function(){
         	if($rootScope.validClose == undefined){
         		}
	   	       	else{
	   	       		
	   	       		$rootScope.validClose = undefined;
         	}
         	
         }, 
         scope: $scope,
         closeByDocument: false,
         closeByEscape: false,
         showClose: true,
         height: 200,
         width: 600,
         className:'ngdialog-theme-default CLASS_projName'
     });*/
		$scope.msgError = false;
		$rootScope.exeReqCount = ++$rootScope.exeReqCount;
		/*for (var i = 0; i < $rootScope.targetSysData.length; i++) {
	  		 if(($rootScope.implType == "1" || $rootScope.implType == "2") && $rootScope.targetSysData[i].destinationName == $rootScope.selectedTargetSystem){
	  			$rootScope.targetSysID = $rootScope.targetSysData[i].systemType;
	  			$rootScope.targetClientNo = $rootScope.targetSysData[i].sapClientNo;
	  			$rootScope.targetSID = $rootScope.targetSysData[i].systemId;
	  			break;
	  		 }else if($rootScope.implType == "3"  && $rootScope.targetSysData[i].destinationName == $rootScope.selectedTargetSystem){
	  			$rootScope.targetSysID = $rootScope.targetSysData[i].systemType;
	  			$rootScope.targetClientNo = $rootScope.targetSysData[i].sapClientNo;
	  			$rootScope.targetSID = $rootScope.targetSysData[i].systemId;
	  			break;
	  		 }else{
	  			$rootScope.targetSysID = "";
	  			$rootScope.targetClientNo = "";
	  		 }
     }*/
//	  	 console.log("$rootScope.targetClientNo -- "+$rootScope.targetClientNo);
	  	for (var i = 0,arrLen = $rootScope.sourceSysData.length; i < arrLen ; i++) {
	  		 if($rootScope.implType == "2"  && $rootScope.sourceSysData[i].isHVESSystem == 0 && $rootScope.sourceSysData[i].destinationName == $rootScope.sourceSystem.value){
	  			$rootScope.sourceSysID = $rootScope.sourceSysData[i].systemType;
	  			$rootScope.systemID = $rootScope.sourceSysData[i].systemId;
	  			$rootScope.srcSncEnabled = $rootScope.sourceSysData[i].sncEnabled;
	  			$rootScope.srcSncName = $rootScope.sourceSysData[i].sncName;
	  			$rootScope.srcSncPartnerName = $rootScope.sourceSysData[i].sncPartnerName;
	  			$rootScope.srcSapRouter = $rootScope.sourceSysData[i].sapRouter;
	  			$rootScope.srcSncProtection = $rootScope.sourceSysData[i].sncProtectionLevel;
	  			
	    		 
	  			

	  			break;
	  		 }else if($rootScope.implType == "3" && $rootScope.sourceSysData[i].isHVESSystem == 1 && $rootScope.sourceSysData[i].destinationName == $rootScope.sourceSystem.value){
	  			$rootScope.sourceSysID = $rootScope.sourceSysData[i].systemType;
	  			$rootScope.systemID = $rootScope.sourceSysData[i].systemId;
	  			$rootScope.sncEnabled = $rootScope.sourceSysData[i].sncEnabled;
	  			$rootScope.sncName = $rootScope.sourceSysData[i].sncName;
	  			$rootScope.sncPartnerName = $rootScope.sourceSysData[i].sncPartnerName;
	  			$rootScope.sapRouter = $rootScope.sourceSysData[i].sapRouter;
	  			$rootScope.sncProtectionLevel = $rootScope.sourceSysData[i].sncProtectionLevel;
	  			

	  			break;
	  		 }else{
	  			$rootScope.sourceSysID = "";
	  		 }
    }
	  	
	  	$scope.mismatchTRList = [];
//	  	var invalidTRArray = {};
		
	  	for(var i= 0,arrLen = $rootScope.executionLogsData.length; i< arrLen ; i++){
 			 
 			 if($rootScope.executionLogsData[i].trType != null && $rootScope.executionLogsData[i].trType.search("W") > -1){
 				if($rootScope.executionLogsData[i].customizingTr != null && $rootScope.executionLogsData[i].customizingTr.length > 0){
 					if($rootScope.executionLogsData[i].customizingTr.slice(0,3) != $rootScope.targetSID){
// 						invalidTRArray = {};
// 					  	invalidTRArray.imgDescription = $rootScope.executionLogsData[i].imgDescription
 						$scope.mismatchTRList.push($rootScope.executionLogsData[i].imgDescription);
 						continue;
 						
 				    }
 				}
 			 }
 			 
 			 if($rootScope.executionLogsData[i].trType != null && $rootScope.executionLogsData[i].trType.search("K") > -1){
	  				if($rootScope.executionLogsData[i].workbenchTr != null && $rootScope.executionLogsData[i].workbenchTr.length > 0){
	  					if($rootScope.executionLogsData[i].workbenchTr.slice(0,3) != $rootScope.targetSID){
//	  						invalidTRArray = {};
//	 					  	invalidTRArray.imgDescription = $rootScope.executionLogsData[i].imgDescription
	  						$scope.mismatchTRList.push($rootScope.executionLogsData[i].imgDescription);
	 				    }
	  				}
	  			 }	
     }
	  	
	  	if($scope.mismatchTRList.length == 0){
	  	
	  	if(!$rootScope.isReExecutionReq){
	  		
	  		var msgRequired = false;
	  		
	  		 for(var i= 0,arrLen = $rootScope.executionLogsData.length; i< arrLen ; i++){
	  			 
	  			 if($rootScope.executionLogsData[i].trType != null && $rootScope.executionLogsData[i].trType.search("W") > -1){
	  				if($rootScope.executionLogsData[i].customizingTr == null || $rootScope.executionLogsData[i].customizingTr.length == 0){
	  					msgRequired = true;
	  					break;
	  				}
	  			 }
	  			 
	  			 if($rootScope.executionLogsData[i].trType != null && $rootScope.executionLogsData[i].trType.search("K") > -1){
		  				if($rootScope.executionLogsData[i].workbenchTr == null || $rootScope.executionLogsData[i].workbenchTr.length == 0){
		  					msgRequired = true;
		  					break;
		  				}
		  			 }	
          }
	  		
	  		
	  		if(msgRequired){
	  			ngDialog.openConfirm({
		            template:'view/config/TRConfirmation.html?ver='+version,
		         
		            scope: $scope,
		            closeByDocument: false,
		            closeByEscape: false,
		            showClose: true,
		            height: 190,
		            width: 624,
		            className:'ngdialog-theme-default CLASS_projName'
		        });
	  		}else{
	  			$scope.sapExecute();
	  		}
	  		
	  		//trOverride 
		  	/*if(!$scope.isTREnabled()){
		  		ngDialog.openConfirm({
		            template:'view/config/TRNumber.html?ver='+version,
		         
		            scope: $scope,
		            closeByDocument: false,
		            closeByEscape: false,
		            showClose: true,
		            height: 268,
		            width: 624
		        });
		  		
		  	}else{
		  		$scope.sapExecute();
		  	}*/
	  	}else{
	  		
	  	  	$rootScope.reExecution = true;
		 	$scope.executionFileSize = 0;
	  	  	
		 	$scope.errorCount = 0;
			$scope.reExecuteDisabled = true;
			 $scope.previousDisabled = true;
			 
			 
	  	  	if(!$scope.connectionStatus){
	  	  		ngDialog.openConfirm({
	  	  			template: 'view/config/sapLoginDetails.html?ver='+version,
	  	  			scope: $scope,
	  	  			closeByDocument: false,
	  	  			closeByEscape: false,
	  	  			showClose: true,
	  	  			height: 500,
	  	  			width: 527
	        });
	  	  	}
	  		
	  	   
	  	  	else{
		
	 	if($rootScope.implType == "1" ){
//	 		$rootScope.uploadedScopes = [];
	 		$scope.greenFieldExecution();
			}else if($rootScope.implType == "2" || $rootScope.implType == "3"){
				if($rootScope.modTypes.value == "Automated without intervention")
					$scope.brownFieldDownload();
				else if($rootScope.modTypes.value == "Automated with intervention")
					$scope.greenFieldExecution();
				}
		  	}
	  	}
 	}
	  	else{
	  		ngDialog.openConfirm({
	            template:'view/config/TRErrorList.html?ver='+version,
	         
	            scope: $scope,
	            closeByDocument: false,
	            closeByEscape: false,
	            showClose: true,
	            height: 500,
	            width: 732,
	            className:'ngdialog-theme-default CLASS_projName'
	        });
	  	}
	  	
	  
	  	 };
 
	  	 
	  	$scope.TRNumberValidation = function(transportReqNo,isEditable,trName,indexVal){
	  		if(!isEditable){
	  		 if(transportReqNo != undefined && transportReqNo != null && transportReqNo != ""){
	  		  	transportReqNo = transportReqNo.replace(/[^a-zA-Z0-9]/ig, "");
	  			if(transportReqNo.length == 10){
	  				if(transportReqNo.slice(0,3).toUpperCase() == $rootScope.targetSID){
	  					if((transportReqNo.slice(3,4) == "K" || transportReqNo.slice(3,4) == "k") && transportReqNo.slice(4,10).match(/^[a-zA-Z0-9]+$/)){
	  					
	  							}else{
	  								if(trName == "KTR"){
	  									$rootScope.executionLogsData[indexVal].workbenchTr = "";	
	  								}else if(trName == "WTR"){
	  									$rootScope.executionLogsData[indexVal].customizingTr = "";	
	  								}
	  									ngDialog.openConfirm({
	  				                      template: '<p style="margin-top:8%">' +"Please enter TR Number in correct format "+ '</p>',
	  				                      plain: true,
	  				                      scope: $scope,
	  				                      closeByDocument: true,
	  				                      closeByEscape: true,
	  				                      showClose: true,
	  				                      height:120,
	  				                      width: 350,
	  				                      className:'ngdialog-theme-default CLASS_2'
	  				                  });
	  							}
	  						}else{
	  							if(trName == "KTR"){
  									$rootScope.executionLogsData[indexVal].workbenchTr = "";	
  								}else if(trName == "WTR"){
  									$rootScope.executionLogsData[indexVal].customizingTr = "";	
  								}
	  							ngDialog.openConfirm({
	  				                      template: '<p style="margin-top:8%">' +"Please enter TR Number in correct format "+ '</p>',
	  				                      plain: true,
	  				                      scope: $scope,
	  				                      closeByDocument: true,
	  				                      closeByEscape: true,
	  				                      showClose: true,
	  				                      height:120,
	  				                      width: 350,
	  				                      className:'ngdialog-theme-default CLASS_2'
	  				                  });
	  							}
	  					}else{
	  						if(trName == "KTR"){
									$rootScope.executionLogsData[indexVal].workbenchTr = "";	
								}else if(trName == "WTR"){
									$rootScope.executionLogsData[indexVal].customizingTr = "";	
								}
	  					
	  						  ngDialog.openConfirm({
	  		                   template: '<p style="margin-top:8%">' +" TR Number should be 10 characters in length"+ '</p>',
	  		                   plain: true,
	  		                   scope: $scope,
	  		                   closeByDocument: true,
	  		                   closeByEscape: true,
	  		                   showClose: true,
	  		                   height:100,
	  		                   width: 350,
	  		                   className:'ngdialog-theme-default CLASS_2'
	  		               });
	  					}
	  		 }
	  	}
	  	 };
	  	 
	  	 
	  	 
	  	 $scope.wtrValidation = function(transportReqNo){
	  		 if(transportReqNo != undefined && transportReqNo != null && transportReqNo != ""){
	  		  	transportReqNo = transportReqNo.replace(/[^a-zA-Z0-9]/ig, "");
	  			if(transportReqNo.length == 10){
	  				if(transportReqNo.slice(0,3) == $rootScope.targetSID){
	  					if((transportReqNo.slice(3,4) == "K" || transportReqNo.slice(3,4) == "k") && transportReqNo.slice(4,10).match(/^[0-9]+$/)){
	  					
	  							}else{
	  								
	  								
	  									ngDialog.openConfirm({
	  				                      template: '<p style="margin-top:8%">' +"Please enter TR Number in correct format "+ '</p>',
	  				                      plain: true,
	  				                      scope: $scope,
	  				                      closeByDocument: true,
	  				                      closeByEscape: true,
	  				                      showClose: true,
	  				                      height:120,
	  				                      width: 350,
	  				                      className:'ngdialog-theme-default CLASS_2'
	  				                  });
	  							}
	  						}else{
	  						
	  							ngDialog.openConfirm({
	  				                      template: '<p style="margin-top:8%">' +"Please enter TR Number in correct format "+ '</p>',
	  				                      plain: true,
	  				                      scope: $scope,
	  				                      closeByDocument: true,
	  				                      closeByEscape: true,
	  				                      showClose: true,
	  				                      height:120,
	  				                      width: 350,
	  				                      className:'ngdialog-theme-default CLASS_2'
	  				                  });
	  							}
	  					}else{
	  					
	  						  ngDialog.openConfirm({
	  		                   template: '<p style="margin-top:8%">' +" CustomizingTR Number should be 10 characters in length"+ '</p>',
	  		                   plain: true,
	  		                   scope: $scope,
	  		                   closeByDocument: true,
	  		                   closeByEscape: true,
	  		                   showClose: true,
	  		                   height:100,
	  		                   width: 350,
	  		                   className:'ngdialog-theme-default CLASS_2'
	  		               });
	  					}
	  		 }
	  	 };
	  	 $scope.ktrValidation = function(transportReqNo){
	  		 if(transportReqNo != undefined && transportReqNo != null && transportReqNo != "" ){
	  		  	transportReqNo = transportReqNo.replace(/[^a-zA-Z0-9]/ig, "");
	  			if(transportReqNo.length == 10 || transportReqNo.length == 0){
	  				if(transportReqNo.slice(0,3) == $rootScope.targetSID){
	  					if((transportReqNo.slice(3,4) == "K" || transportReqNo.slice(3,4) == "k") && transportReqNo.slice(4,10).match(/^[0-9]+$/)){
	  					
	  							}else{
	  									ngDialog.openConfirm({
	  				                      template: '<p style="margin-top:8%">' +"Please enter TR Number in correct format "+ '</p>',
	  				                      plain: true,
	  				                      scope: $scope,
	  				                      closeByDocument: true,
	  				                      closeByEscape: true,
	  				                      showClose: true,
	  				                      height:120,
	  				                      width: 350,
	  				                      className:'ngdialog-theme-default CLASS_2'
	  				                  });
	  							}
	  						}else{
	  							ngDialog.openConfirm({
	  				                      template: '<p style="margin-top:8%">' +"Please enter TR Number in correct format "+ '</p>',
	  				                      plain: true,
	  				                      scope: $scope,
	  				                      closeByDocument: true,
	  				                      closeByEscape: true,
	  				                      showClose: true,
	  				                      height:120,
	  				                      width: 350,
	  				                      className:'ngdialog-theme-default CLASS_2'
	  				                  });
	  							}
	  					}else{
	  					
	  						  ngDialog.openConfirm({
	  		                   template: '<p style="margin-top:8%">' +"WorkbenchTR number should be 10 characters in length"+ '</p>',
	  		                   plain: true,
	  		                   scope: $scope,
	  		                   closeByDocument: true,
	  		                   closeByEscape: true,
	  		                   showClose: true,
	  		                   height:100,
	  		                   width: 350,
	  		                   className:'ngdialog-theme-default CLASS_2'
	  		               });
	  					}
	  		 }
	  	};
	$scope.sapExecute = function(){
		$rootScope.copyFlag = false;
		
		ngDialog.close();	
		if($rootScope.sapUserID == null || $rootScope.sapPassword == null || $rootScope.sapUserID == "" || $rootScope.sapPassword == ""){
			 var params={	
		        		sapUserId:$rootScope.sapUserID,
		        		password:$rootScope.sapPassword,
		        		destinationName:$rootScope.selectedTargetSystem
		               };
			 ngDialog.openConfirm({
		            template: 'view/config/sapLoginDetails.html?ver='+version,
		            scope: $scope,
		            closeByDocument: false,
		            closeByEscape: false,
		            showClose: true,
		            height: 500,
		            width: 527,
		            className:'ngdialog-theme-default CLASS_projName'
		        });
	
		}
		else if($rootScope.sapDestination != $rootScope.selectedTargetSystem){
			ngDialog.openConfirm({
	            template: 'view/config/sapLoginDetails.html?ver='+version,
	            scope: $scope,
	            closeByDocument: false,
	            closeByEscape: false,
	            showClose: true,
	            height: 500,
	            width: 527,
	            className:'ngdialog-theme-default CLASS_projName'
	        });
			}
		else $scope.dependencyCheck();
	};
	
	$scope.cancelsapDetails = function(){
		$rootScope.sapUserID = "";
		$rootScope.sapPassword = "";
		ngDialog.close();		
		$mdDialog.cancel();
		};
		
		$rootScope.assignCommonTR = function(){
			$scope.reExecuteDisabled = true;
			 $scope.previousDisabled = true;
			 var trvalue = null;
		     var workBench_trvalue = null;
		     
			 /*if(!$scope.isTREnabled()){
				if($scope.commonTR.transportReqNo != null &&  $scope.commonTR.transportReqNo.length > 0){
				 trvalue = $scope.commonTR.transportReqNo;
			     }
				if($scope.commonTR.workBench_transportReqNo != null &&  $scope.commonTR.workBench_transportReqNo.length > 0){
					workBench_trvalue = $scope.commonTR.workBench_transportReqNo;
				 }
			 }	 
			 
			 for(var i= 0; i< $rootScope.uploadedScopes.length; i++){	
				 if($rootScope.uploadedScopes[i].trType != null && $rootScope.uploadedScopes[i].trType.search("K") > -1)
					 $rootScope.uploadedScopes[i].workbenchTr_mode = "Display";
				 else
					 $rootScope.uploadedScopes[i].workbenchTr_mode = "";
				 
				 if($rootScope.uploadedScopes[i].trType != null && $rootScope.uploadedScopes[i].trType.search("W") > -1)
					 $rootScope.uploadedScopes[i].customizingTr_mode = "Display";
				else
					$rootScope.uploadedScopes[i].customizingTr_mode = "";
				 
				 if(trvalue != null && $rootScope.uploadedScopes[i].trType.search("W") > -1)
					 $rootScope.uploadedScopes[i].customizingTr = trvalue;
				 if(workBench_trvalue != null && $rootScope.uploadedScopes[i].trType.search("K") > -1)
					 $rootScope.uploadedScopes[i].workbenchTr = workBench_trvalue;
			 }*/            
			// $rootScope.executionLogsData = $rootScope.uploadedScopes;
			 
		     if($rootScope.hierarchyTypes.value == "Business Process"){
		    	 
		     	 $rootScope.executionLogsData = $rootScope.uploadedScopes;
		    	// $rootScope.uploadedScopes = $rootScope.uploadedScopes;
		     }
		     
		}
	$rootScope.confirmExecution = function(){
	    $rootScope.resultList = [];
	    if($rootScope.isReExecutionReq == false)
		$rootScope.assignCommonTR();
	    if($rootScope.consolidate==true){
	    	$scope.createConfigTransaction();
	    }else{
	    	$scope.masterDependencyCheck();
	    }	/*	if( $rootScope.implType == "1" ){
			$scope.greenFieldExecution();
		}else if( $rootScope.implType == "2" || $rootScope.implType == "3"){
			//$scope.brownFieldExecution();
			if($rootScope.modTypes.value == "Modification"){
//				if($rootScope.modOptions.value == "Upload"){
					$scope.greenFieldExecution();
					
//				}
				
			}else if($rootScope.modTypes.value == "Without Modification"){ 
//				$scope.brownFieldExecution();
				 $scope.brownFieldDownload();
				
			
			}
		}*/
	}
	
//	 $scope.executeListener =  $rootScope.$on("CallexecuteMethod", function(){
//        $scope.confirmExecution();
//     });
	
	    $scope.greenFieldExecution = function(){
	    	var timeLater = new Date();
	    	$scope.tableCont = false;
	    	$scope.viewlogsLink="viewlogsEnable";
	    	if($rootScope.uploadedScopes.length > 0){
//	    		$rootScope.execute = "Execute";
//	    		$rootScope.executionLogsData[$scope.executionFileSize].status = "fa fa-check-circle";
//		    		if($rootScope.uploadedScopes[$scope.executionFileSize].status != "fa fa-check-circle"){
	    		if($rootScope.reExecution){
    				$rootScope.msg1 = "Currently Executing "+($scope.executionFileSize+$scope.successCount+1);
    				$rootScope.msg2 = "No.of Config Processed Successfully -  "+$scope.successCount;
    				$rootScope.msg3 = "No. of Config Processed Failed - "+$scope.errorCount;
    				$rootScope.msg4 = "No. of Config Processed Pending - "+($rootScope.uploadedScopes.length - ($scope.executionFileSize+$scope.successCount+1) - $scope.manualCount);
    				//$rootScope.uploadedScopes[$scope.executionFileSize].customizingTr = 
    			}
    			else{
    				$rootScope.msg1 = "Currently Executing "+($scope.executionFileSize+1);
    				$rootScope.msg2 = "No.of Config Processed Successfully -  "+$scope.successCount;
    				$rootScope.msg3 = "No. of Config Processed Failed - "+$scope.errorCount;
    				$rootScope.msg4 = "No. of Config Processed Pending - "+($rootScope.uploadedScopes.length - ($scope.executionFileSize+1) - $scope.manualCount);
    			}
	    			if($rootScope.hierarchyTypes.value == "Business Process" && $rootScope.uploadedScopes[$scope.executionFileSize].configType == 'M'){
	    				$scope.manualCount++;
	    				$rootScope.imgDescription = $rootScope.uploadedScopes[$scope.executionFileSize].imgDescription;
	    				$rootScope.uploadedScopes[$scope.executionFileSize].status = '';
	    				 ngDialog.openConfirm({
	    			            template: 'view/config/alertManualConfig.html?ver='+version,	    			          
	    			            scope: $scope,
	    			            closeByDocument: false,
	    			            closeByEscape: false,
	    			            showClose: false,
	    			            height: 200,
	    			            width: 600,
	    			            className:'ngdialog-theme-default CLASS_projName'
	    			        });
	    				
	    				}
	    			else{
	    			if($rootScope.uploadedScopes[$scope.executionFileSize].status != null &&  $rootScope.uploadedScopes[$scope.executionFileSize].status != "fa fa-check-circle"){
	                //$rootScope.msg1 = "Currently Executing "+($scope.executionFileSize+1)+" of "+$rootScope.uploadedScopes.length;
	    			
	    		 var exeArray = {};
	    		 exeArray.destinationName = $rootScope.selectedTargetSystem; 
	    		 //exeArray.templateFilePath= $rootScope.uploadedScopes[$scope.executionFileSize].filepath;
	    		 exeArray.fileBytes = $rootScope.uploadedScopes[$scope.executionFileSize].fileBytes;
	    		 exeArray.scopeName = $rootScope.uploadedScopes[$scope.executionFileSize].imgId;
	    		 exeArray.sapUserId = $rootScope.sapUserID;
	    		 exeArray.sapPassword = $rootScope.eSapPassword;
	    		 exeArray.sapLanguage = $rootScope.sapLanguage;
	    		  
	    			 if($rootScope.customDestFlagFrDwnld == 'N')
	    			  exeArray.isCustomDestinationRequired = "false";
	    			    else 
	    			    exeArray.isCustomDestinationRequired = "true"; 
	    		 

	    		 //Added for Logging 
	    		 exeArray.transactionID = $rootScope.transactionID;
	    		 exeArray.scopeTranId = $rootScope.scopeTranId;
	    		 exeArray.projectName = $rootScope.projectName;
	    		 exeArray.scenario = $rootScope.scenario;
	    		 exeArray.omgID = $rootScope.projOmId;
	    		 exeArray.systemID = $rootScope.systemID;
	    		 exeArray.hostName=$rootScope.target.hostName;
	    	     
	    		 exeArray.sapClientNo=$rootScope.target.sapClientNo;
	    	      //params.sapUserId=$scope.target.userId;
	    	      //params.destPasswrd=$scope.target.password;
	    	      //params.language=$scope.target.language;
	    		 exeArray.systemNo=$rootScope.target.systemNo;
	    		 exeArray.sncEnabled=$rootScope.target.sncEnabled;
	    		 
	    		 exeArray.sncName=$scope.target.sncName;
	    		 exeArray.sncPartnerName=$scope.target.sncPartnerName;
	    		 exeArray.sapRouter=$scope.target.sapRouter;
	    		 exeArray.sncProtectionLevel=$scope.target.sncProtectionLevel;
	    		 
	//    		 exeArray.imgID = $rootScope.uploadedScopes[fileCount].imgId;
	    		 exeArray.userID = $rootScope.username;
	    		 exeArray.module = "FI";//Hardcoded need to change
	    		 if($rootScope.hierarchyTypes.value == "Business Process")
	    		 exeArray.isIMGHierarchy = false;
	    		 else
	    		 exeArray.isIMGHierarchy = true; 
	//    		 exeArray.trNumber = $rootScope.trnumber;
	    		
	    		 if($rootScope.uploadedScopes[$scope.executionFileSize].workbenchTr == null || $rootScope.uploadedScopes[$scope.executionFileSize].workbenchTr == "")
	    		 {
	    			 if($rootScope.uploadedScopes[$scope.executionFileSize].trType == 'K' || $rootScope.uploadedScopes[$scope.executionFileSize].trType == 'WK')
	    				 exeArray.workbenchTr = 'X';
	    			 else{
		    			 exeArray.workbenchTr = $rootScope.uploadedScopes[$scope.executionFileSize].workbenchTr;
		    		 }
	    		 }
	    		 else{
	    			 exeArray.workbenchTr = $rootScope.uploadedScopes[$scope.executionFileSize].workbenchTr;
	    		 } 
	    		 if($rootScope.uploadedScopes[$scope.executionFileSize].customizingTr == null || $rootScope.uploadedScopes[$scope.executionFileSize].customizingTr == "")
	    		 {
	    			 if($rootScope.uploadedScopes[$scope.executionFileSize].trType == 'W' || $rootScope.uploadedScopes[$scope.executionFileSize].trType == 'WK')
	    				 exeArray.customizingTr = 'X';
	    			 else{
		    			 exeArray.customizingTr = $rootScope.uploadedScopes[$scope.executionFileSize].customizingTr;
		    		 }
	    		 }
	    		 else{
	    			 exeArray.customizingTr = $rootScope.uploadedScopes[$scope.executionFileSize].customizingTr;
	    		 }
	    		// exeArray.customizingTr = $rootScope.uploadedScopes[$scope.executionFileSize].customizingTr;
	    		 exeArray.tranId = $rootScope.uploadedScopes[$scope.executionFileSize].tranId;
	    		 exeArray.scopeExists = $rootScope.uploadedScopes[$scope.executionFileSize].scopeExists;
	    		 exeArray.sessionInputDTO = $rootScope.sessionInputObj;
	    		 exeArray.exeReqCount = $rootScope.exeReqCount;
	    		 exeArray.copyFlag = false;
	    		 exeArray.consolidate =$rootScope.consolidate;
	    		 exeArray.industryFlag=$rootScope.industryFlag;
	             if($rootScope.industryFlag){
	            	 exeArray.industry=$rootScope.selectedIndustry;
	            	 exeArray.subIndustry=$rootScope.selectedsubIndustry;
	             }
	//        		if(responseData.status == "Success")
	//        			exeArray.status = "S";
	//        		else
	//        			exeArray.status = "E";
	        		//Ended for Logging 
	    	
	          var  uploadUrl;
	          if($rootScope.uploadedScopes[$scope.executionFileSize].isMasterData == "Y")
	 	         uploadUrl = "/" + servicePrefix + "/rest/fiMasterDataService/performFiMasterData";
	 	    	else
	 	    	{
	 	    		if($rootScope.consolidate == true){
	 	    			 uploadUrl = "/" + servicePrefix + "/rest/autoConfigSrv/performConsolidation";
	 	    		}else{
	 	    			 uploadUrl = "/" + servicePrefix + "/rest/autoConfigSrv/performS4AutoConfig";
	 	    		}
	 	    	 
	 	    	}	
	        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
	        $rootScope.overlay = document.getElementById("overlay_execute");
	        $rootScope.popup = document.getElementById("busy_execute");
	        $rootScope.overlay.style.display = "block";
	        $rootScope.popup.style.display = "inline-block"
	     /*   $mdDialog.show({
	            controller: function($scope, $mdDialog){
	            $scope.isLoading = true;
	            },
	            templateUrl: 'view/busy.html?ver='+version,
	            parent: angular.element(document.body),
	            clickOutsideToClose: false,
	            fullscreen: useFullScreen,
	            escapeToClose: false,
	        })
	        .then(function(answer) {
	        }, function() {
	        });*/
	     
	        $http.post(uploadUrl,exeArray).then(function(responseData){
	       	 if(timeLater.getMinutes() - timeBefore.getMinutes() == 24){
    			 var inputParam = {
    			  			sessionId : $rootScope.sessionInputObj.sessionId,
    			  			csrfToken : $rootScope.sessionInputObj.csrfToken
    			  	}
    			  $http.post("/" + servicePrefix + "/rest/adminSrv/resetSessionTime", inputParam).then(function(response) {
    				  if(response.status == 200){
    					if(response.data.dataStatus == true){
    						//Idle.setIdle();
    						timeBefore = new Date();
    						console.log("Session extended");
    					}
    					}
    			  });
	       	 }
	        	if($rootScope.uploadedScopes[$scope.executionFileSize].isMasterData == "Y"){
	        		if(responseData.data.listFiMDResponse.length > 0){
	        				$scope.masterResponseData(responseData);
	        		}
	        	}
	        	else{
	            $scope.responseMethod(responseData,$rootScope.uploadedScopes[$scope.executionFileSize].imgDescription);
	        	}
	        	
	             if($scope.executionRequired){
	            	 $scope.executionFileSize++;
	            	 $rootScope.msg2 = "No.of Config Processed Successfully -  "+$scope.successCount;
	        	
	            	 if($scope.executionFileSize < $rootScope.uploadedScopes.length){
	            		 $scope.greenFieldExecution();
	            	 }else{
	            		 $rootScope.isReExecutionReq = true;
	            	 }
	             }
	        	
	        }).catch(function(data){
	        	
	        	 $rootScope.overlay = document.getElementById("overlay_execute");
			     $rootScope.popup = document.getElementById("busy_execute");
			     $rootScope.overlay.style.display = "none";
			     $rootScope.popup.style.display = "none";
			     if(responseData.data.resMessageDto != null && responseData.data.resMessageDto.message == serviceMessage){
	      	      		$rootScope.checkAuthorization();
	      	      	}else{
				         $scope.errorResponse(data);
				         $scope.executionFileSize++;
				         //$scope.reExecutionFileSize++;
				         $scope.errorCount++;
				         $rootScope.msg3 = "No. of Config Processed Failed - "+$scope.errorCount;
				         $scope.reExecuteDisabled = false;
				         $rootScope.executionName = "RE-EXECUTE";
				         $rootScope.isReExecutionReq = true;
				         if($scope.executionFileSize < $rootScope.uploadedScopes.length){
				             $scope.greenFieldExecution();
				         }else{
				        	 $rootScope.isReExecutionReq = true;
				         }
	      	      	}
	        });
	    	}else{
	    		$scope.executionFileSize++;
	    		if($scope.executionFileSize < $rootScope.uploadedScopes.length){
	                $scope.greenFieldExecution();
	            }else{
	            	$rootScope.isReExecutionReq = true;
	            }
	    		}
	    	}
	    	}
	    	//$scope.executeDisabled  = true;
            $rootScope.showExportLogs = false; 
            $rootScope.disable="disable";
            //document.getElementById('trnumber').readOnly = true;
	    };
	    
	   
	    
	   $scope.brownFieldDownload = function(){
		   var timeLater = new Date();
	    	$scope.viewlogsLink="viewlogsEnable";
	    	$scope.tableCont = false;
	    	if($rootScope.uploadedScopes.length > 0){
	    		$rootScope.msg1 = "Currently Executing "+($scope.executionFileSize+1);
				$rootScope.msg2 = "No.of Config Processed Successfully -  "+$scope.successCount;
				$rootScope.msg3 = "No. of Config Processed Failed - "+$scope.errorCount;
				$rootScope.msg4 = "No. of Config Processed Pending - "+($rootScope.uploadedScopes.length - ($scope.executionFileSize+1));
				
	    		if($rootScope.hierarchyTypes.value == "Business Process" && $rootScope.uploadedScopes[$scope.executionFileSize].configType == 'M'){
    				$rootScope.imgDescription = $rootScope.uploadedScopes[$scope.executionFileSize].imgDescription;
    				 ngDialog.openConfirm({
 			            template: 'view/config/alertManualConfig.html?ver='+version,	    			          
 			            scope: $scope,
 			            closeByDocument: false,
 			            closeByEscape: false,
 			            showClose: false,
 			            height: 200,
 			            width: 600,
 			            className:'ngdialog-theme-default CLASS_projName'
 			        });
    				
    				}
	    	else{
	    	if($rootScope.uploadedScopes[$scope.executionFileSize].scopeExists){
	    		
	    		var exeArray = {};
	    	
	    		 exeArray.transactionID = $rootScope.transactionID;
	    		 exeArray.imgID = $rootScope.uploadedScopes[$scope.executionFileSize].imgId;
	    		 exeArray.omgID= "sowjanya";
	    		 //exeArray.workbenchTr = $rootScope.uploadedScopes[$scope.executionFileSize].workbenchTr;
	    		// exeArray.customizingTr = $rootScope.uploadedScopes[$scope.executionFileSize].customizingTr;

	    		 if($rootScope.uploadedScopes[$scope.executionFileSize].workbenchTr == null || $rootScope.uploadedScopes[$scope.executionFileSize].workbenchTr == "")
	    		 {
	    			 if($rootScope.uploadedScopes[$scope.executionFileSize].trType == 'K' || $rootScope.uploadedScopes[$scope.executionFileSize].trType == 'WK')
	    				 exeArray.workbenchTr = 'X';
	    			 else{
		    			 exeArray.workbenchTr = $rootScope.uploadedScopes[$scope.executionFileSize].workbenchTr;
		    		 }
	    		 }
	    		 else{
	    			 exeArray.workbenchTr = $rootScope.uploadedScopes[$scope.executionFileSize].workbenchTr;
	    		 } 
	    		 if($rootScope.uploadedScopes[$scope.executionFileSize].customizingTr == null || $rootScope.uploadedScopes[$scope.executionFileSize].customizingTr == "")
	    		 {
	    			 if($rootScope.uploadedScopes[$scope.executionFileSize].trType == 'W' || $rootScope.uploadedScopes[$scope.executionFileSize].trType == 'WK')
	    				 exeArray.customizingTr = 'X';
	    			 else{
		    			 exeArray.customizingTr = $rootScope.uploadedScopes[$scope.executionFileSize].customizingTr;
		    		 }
	    		 }
	    		 else{
	    			 exeArray.customizingTr = $rootScope.uploadedScopes[$scope.executionFileSize].customizingTr;
	    		 }
	    		 exeArray.errorReason = 'Scope is not available in the Object Mapping Template!!';
	    		 exeArray.sessionInputDTO = $rootScope.sessionInputObj;	
	    		 if($rootScope.hierarchyTypes.value == "Business Process")
	    			 exeArray.isIMGHierarchy = false;
		    	 else
		    		 exeArray.isIMGHierarchy = true; 
		          var  uploadUrl;
		     	         uploadUrl = "/" + servicePrefix + "/rest/autoConfigSrv/withOutInFailedLogs";
		     	        
		     	        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
				         $rootScope.overlay = document.getElementById("overlay_execute");
				        $rootScope.popup = document.getElementById("busy_execute");
				        $rootScope.overlay.style.display = "block";
				        $rootScope.popup.style.display = "inline-block";
				        
		     	         $http.post(uploadUrl,exeArray).then(function(responseData){}),(function(data){})
		     	$scope.errorLogsForScope();
				 $scope.executionFileSize++;
	             $rootScope.msg2 = "No.of Config Processed Successfully -  "+$scope.successCount;

				 if($scope.executionFileSize < $rootScope.uploadedScopes.length){
	                 $scope.brownFieldDownload();
	             }else{
	            	 $rootScope.isReExecutionReq = true;
	             }
	    	}
    	else
           {
	    	if($rootScope.uploadedScopes[$scope.executionFileSize].status == null ||  $rootScope.uploadedScopes[$scope.executionFileSize].status != "fa fa-check-circle"){
//	    		   $rootScope.execute = "Execute";
	    		if($rootScope.reExecution){
    				$rootScope.msg1 = "Currently Executing "+($scope.executionFileSize+$scope.successCount+1);
    				$rootScope.msg2 = "No.of Config Processed Successfully -  "+$scope.successCount;
    				$rootScope.msg3 = "No. of Config Processed Failed - "+$scope.errorCount;
    				$rootScope.msg4 = "No. of Config Processed Pending - "+($rootScope.uploadedScopes.length - ($scope.executionFileSize+$scope.successCount+1));
    			}
    			else{
    				$rootScope.msg1 = "Currently Executing "+($scope.executionFileSize+1);
    				$rootScope.msg2 = "No.of Config Processed Successfully -  "+$scope.successCount;
    				$rootScope.msg3 = "No. of Config Processed Failed - "+$scope.errorCount;
    				$rootScope.msg4 = "No. of Config Processed Pending - "+($rootScope.uploadedScopes.length - ($scope.executionFileSize+1));
    			}
	               
	     
		    	 var exeArray = {};
	    		 exeArray.srcDestination = $rootScope.sourceSystem.value;
	    		 exeArray.tgtDestination = $rootScope.selectedTargetSystem; 
	    		 
	    		 exeArray.imgDownloadDtoObj = $rootScope.uploadedScopes[$scope.executionFileSize];
	    		 exeArray.imgDownloadDto = $rootScope.executeScopeList;
	    		// exeArray.isMasterData = $rootScope.uploadedScopes[$scope.executionFileSize].isMasterData;
	    		
//	    		 exeArray.imgDownloadDto = [{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"ERC_COMPANY","imgScope":["1|ERC_COMPANY|V_T880|V"]},{"imgId":"SIMG_CFMENUSAPCOB45","imgScope":["1|SIMG_CFMENUSAPCOB45|V_T014|V"]}];
		    	//Added for Logging 
	    		 exeArray.transactionID = $rootScope.transactionID;
	    		 exeArray.projectName = $rootScope.projectName;
	    		 exeArray.scenario = $rootScope.scenario;
	    		 exeArray.omgID = $rootScope.projOmId;
	    		 exeArray.systemID = $rootScope.systemID;
	    		 exeArray.sourceSystemID = $rootScope.sourceSysID;
	    		 exeArray.srcSncEnabled = $rootScope.srcSncEnabled;
	    		 exeArray.srcSncName = $rootScope.srcSncName;
	    		 exeArray.srcSncPartnerName = $rootScope.srcSncPartnerName;
	    		 exeArray.srcSapRouter = $rootScope.srcSapRouter;
	    		 exeArray.srcSncProtection = $rootScope.srcSncProtection;
	    		 exeArray.sapUserId =   $rootScope.sapUserID;
	    		 exeArray.sapPassword =   $rootScope.eSapPassword;
	    		 exeArray.sapLanguage = $rootScope.sapLanguage;
	    		 exeArray.hostName=$rootScope.target.hostName;
	    	     
	    		 exeArray.clientNo=$rootScope.target.sapClientNo;
	    	  
	    		 exeArray.sysNo=$rootScope.target.systemNo;
	    		 
	    		 exeArray.sncEnabled=$rootScope.target.sncEnabled;
	    		 
	    		 exeArray.sncName=$scope.target.sncName;
	    		 exeArray.sncPartnerName=$scope.target.sncPartnerName;
	    		 exeArray.sapRouter=$scope.target.sapRouter;
	    		 exeArray.sncProtectionLevel=$scope.target.sncProtectionLevel;
	    		 
	    		 exeArray.industryFlag=$rootScope.industryFlag;
	             if($rootScope.industryFlag){
	            	 exeArray.industryAlias = $rootScope.aliasIndustry;
	            	 exeArray.subIndustryAlias = $rootScope.aliasSubIndustry;
	            	 exeArray.industry=$rootScope.selectedIndustry;
	            	 exeArray.subIndustry=$rootScope.selectedsubIndustry;
	             }
	    		 
	    		 if($rootScope.customDestFlagFrDwnld == 'N')
	    			  exeArray.isCustomDestinationRequired = "false";
	    			    else 
	    			    exeArray.isCustomDestinationRequired = "true"; 
	    	     exeArray.module = "FI";//Hardcoded need to change
//	    		 exeArray.imgID = $rootScope.uploadedScopes[fileCount].imgId;
	    		 exeArray.userID = $rootScope.username;
//	    		 exeArray.imgID = $rootScope.uploadedScopes[$scope.executionFileSize].imgId; //Changed by Dileep - Input is wrong
	    		 exeArray.imgID = $rootScope.uploadedScopes[$scope.executionFileSize].imgId;
//	    		 exeArray.trNumber = $rootScope.trnumber;
	    		// exeArray.workbenchTr = $rootScope.uploadedScopes[$scope.executionFileSize].workbenchTr;
	    		// exeArray.customizingTr = $rootScope.uploadedScopes[$scope.executionFileSize].customizingTr;

	    		 if($rootScope.uploadedScopes[$scope.executionFileSize].workbenchTr == null || $rootScope.uploadedScopes[$scope.executionFileSize].workbenchTr == "")
	    		 {
	    			 if($rootScope.uploadedScopes[$scope.executionFileSize].trType == 'K' || $rootScope.uploadedScopes[$scope.executionFileSize].trType == 'WK')
	    				 exeArray.workbenchTr = 'X';
	    			 else{
		    			 exeArray.workbenchTr = $rootScope.uploadedScopes[$scope.executionFileSize].workbenchTr;
		    		 } 
	    		 }
	    		 else{
	    			 exeArray.workbenchTr = $rootScope.uploadedScopes[$scope.executionFileSize].workbenchTr;
	    		 } 
	    		 if($rootScope.uploadedScopes[$scope.executionFileSize].customizingTr == null || $rootScope.uploadedScopes[$scope.executionFileSize].customizingTr == "")
	    		 {
	    			 if($rootScope.uploadedScopes[$scope.executionFileSize].trType == 'W' || $rootScope.uploadedScopes[$scope.executionFileSize].trType == 'WK')
	    				 exeArray.customizingTr = 'X';
	    			 else{
		    			 exeArray.customizingTr = $rootScope.uploadedScopes[$scope.executionFileSize].customizingTr;
		    		 }
	    		 }
	    		 else{
	    			 exeArray.customizingTr = $rootScope.uploadedScopes[$scope.executionFileSize].customizingTr;
	    		 }
	    		 exeArray.sessionInputDTO = $rootScope.sessionInputObj;
	    		 exeArray.exeReqCount = $rootScope.exeReqCount;
	    		 if($rootScope.hierarchyTypes.value == "Business Process")
		    		 exeArray.isIMGHierarchy = false;
		    	 else
		    		 exeArray.isIMGHierarchy = true; 
	    		 
		          var  uploadUrl;
		          if($rootScope.uploadedScopes[$scope.executionFileSize].isMasterData == "Y")
		     	         uploadUrl = "/" + servicePrefix + "/rest/fiMasterDataService/masterDataWithoutIntervention";
		     	    	else
	     	    	  uploadUrl = "/" + servicePrefix + "/rest/autoConfigSrv/brownFieldConfigDownload";
		        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
		         $rootScope.overlay = document.getElementById("overlay_execute");
		        $rootScope.popup = document.getElementById("busy_execute");
		        $rootScope.overlay.style.display = "block";
		        $rootScope.popup.style.display = "inline-block";

		    /*    $mdDialog.show({
		            controller: function($scope, $mdDialog){
		            $scope.isLoading = true;
		            },
		            templateUrl: 'view/busy.html?ver='+version,
		            parent: angular.element(document.body),
		            clickOutsideToClose: false,
		            fullscreen: useFullScreen,
		            escapeToClose: false,
		        })
		        .then(function(answer) {
		        }, function() {
		        });
		     */
		        $http.post(uploadUrl,exeArray).then(function(responseData){
		       	 if(timeLater.getMinutes() - timeBefore.getMinutes() == 24){
	    			 var inputParam = {
	    			  			sessionId : $rootScope.sessionInputObj.sessionId,
	    			  			csrfToken : $rootScope.sessionInputObj.csrfToken
	    			  	}
	    			  $http.post("/" + servicePrefix + "/rest/adminSrv/resetSessionTime", inputParam).then(function(response) {
	    				  if(response.status == 200){
	    					if(response.data.dataStatus == true){
	    						//Idle.setIdle();
	    						timeBefore = new Date();
	    						console.log("Session extended");
	    					}
	    					}
	    			  });
		       	 }
		        	if(responseData.data.resMessageDto != null && responseData.data.resMessageDto.message == serviceMessage){
	      	      		$rootScope.checkAuthorization();
	      	      	}
		        	else {
		        		$rootScope.downloadError = [];
		        	$scope.responseMethod(responseData,$rootScope.uploadedScopes[$scope.executionFileSize].imgDescription);
		             
		            if($scope.executionRequired){
		            	 $scope.executionFileSize++;
		             $rootScope.msg2 = "No.of Config Processed Successfully -  "+$scope.successCount;
		             if($scope.executionFileSize < $rootScope.uploadedScopes.length){
		                 $scope.brownFieldDownload();
		             }else{
		            	 $rootScope.isReExecutionReq = true;
		             	}
		              }
		        	}
	            }) .catch(function(data){
	            	
	            	 $rootScope.overlay = document.getElementById("overlay_execute");
	    		     $rootScope.popup = document.getElementById("busy_execute");
	    		     $rootScope.overlay.style.display = "none";
	    		     $rootScope.popup.style.display = "none";
	             $scope.errorResponse(data);
	             $scope.executionFileSize++;
	             //$scope.reExecutionFileSize++;
	             $scope.errorCount++;
	             $rootScope.msg3 = "No. of Config Processed Failed - "+$scope.errorCount;
	             $scope.reExecuteDisabled = false;
		         $rootScope.executionName = "RE-EXECUTE";
		         $rootScope.isReExecutionReq = true;
	             if($scope.executionFileSize < $rootScope.uploadedScopes.length){
	                 $scope.brownFieldDownload();
	             }else{
	            	 $rootScope.isReExecutionReq = true;
	             }
	            });
		       
	            $rootScope.showExportLogs = false; 	
	            $rootScope.disable="disable";
	           // document.getElementById('trnumber').readOnly = true;
	    	}else{
	    		$scope.executionFileSize++;
	    		if($scope.executionFileSize < $rootScope.uploadedScopes.length){
	                $scope.brownFieldDownload();
	            }else{
	            	$rootScope.isReExecutionReq = true;
	            }
	    	}
	    	}
	    	}
	    	}
            };
	    
	    
	   
	      $rootScope.brownfieldCall = function(){
	    	  if($rootScope.downloadStatus != null && $rootScope.downloadStatus.length > 0){
	    		  //$rootScope.executionLogsData = $rootScope.downloadStatus;
	              $scope.brownFieldUpload();
	    	  }else{
	    			// $mdDialog.cancel();
	    		   $rootScope.overlay = document.getElementById("overlay_execute");
	    		  $rootScope.popup = document.getElementById("busy_execute");
	    		  $rootScope.overlay.style.display = "none";
	    		  $rootScope.popup.style.display = "none";

	          		ngDialog.openConfirm({
	    	            template: 'Selected Scopes are  unable to download from source System',
	    	            plain: true,
	                    scope: $scope,
	                    closeByDocument: true,
	                    closeByEscape: true,
	                    showClose: true,
	                    height:120,
	                    width: 350
	    	        });
	          	}
	      };
	    	
	    $scope.responseMethod = function(responseData,imgDescription){
    //$mdDialog.cancel();
	    	  $rootScope.overlay = document.getElementById("overlay_execute");
		     $rootScope.popup = document.getElementById("busy_execute");
		     $rootScope.overlay.style.display = "none";
		     $rootScope.popup.style.display = "none";

    var data,resData;
    data = responseData.data.result;
    $scope.connectionStatus = responseData.data.connectionStatus;
    $rootScope.uploadedScopes[$scope.executionFileSize].tranId = responseData.data.tranId; 
    
  
    if(!$scope.connectionStatus && $scope.executionFileSize == 0){
    	$scope.executionRequired = false;
    	$rootScope.reExecution = true;
    	$scope.ErrorMsg = "Something went wrong with the Target System.";
    	 $scope.executionFileSize = 0;
    	 ngDialog.openConfirm({
	            template: 'view/config/sapLoginDetails.html?ver='+version,
	            scope: $scope,
	            closeByDocument: false,
	            closeByEscape: false,
	            showClose: true,
	            height: 500,
	            width: 527,
	            className:'ngdialog-theme-default CLASS_projName'
	        });
	}
    else if(responseData.data.responseData[1] == "E~Activation Error" && $scope.executionFileSize == 0){
    	$rootScope.reExecution = true;
    	$scope.executionRequired = false;
    	$scope.ErrorMsg = "No Authorization for the given SAP User!!";
        $scope.msgError = true;
        $scope.executionFileSize = 0;
   	 
        ngDialog.openConfirm({
            template: 'view/config/sapLoginDetails.html?ver='+version,
            scope: $scope,
            closeByDocument: false,
            closeByEscape: false,
            showClose: true,
            height: 500,
            width: 527,
            className:'ngdialog-theme-default CLASS_projName'
        });
  		
  		return;
    }
    else{
    	
    	$scope.executionRequired = true;

    if($rootScope.reExecution){
    	 
	        /*angular.forEach($rootScope.reportData, function(cb, index) {
	          if (cb.imgDesc == imgDescription) {
	  	          $rootScope.reportData.splice(index, 1);
	          }
	        });*/
    	
    	for (var i = $rootScope.reportData.length - 1; i >= 0; i--) {
    	    if ($rootScope.reportData[i].imgDesc == imgDescription) {
    	    	$rootScope.reportData.splice(i, 1);
    	    }
    	}
    }
    if(data != null){
	    for(var i=0;i<data.length;i++){
	//    	data[i].imgDesc = $rootScope.uploadedScopes[$scope.executionFileSize].imgDescription;
	    	data[i].imgDesc = imgDescription;
	        if(data[i].messageType == 'N'){
	            data[i].iconType = "glyphicon glyphicon-ok";
	            data[i].errorType = "Function executed";
	        }else if(data[i].messageType == 'E'){
	            /*data[i].iconType = "glyphicon glyphicon-remove-circle";*/
	        	   data[i].iconType = "fa fa-times-circle"; 
	            data[i].errorType = "Error (could not execute function)";
	            $rootScope.retryExecution = true;
	            $rootScope.uploadedScopes[$scope.executionFileSize].status = " fa fa-times-circle";
	        }else if(data[i].messageType == 'F'){
	           /* data[i].iconType = "glyphicon glyphicon-ban-circle";*/
	        	 data[i].iconType = "fa fa-ban";
	            data[i].errorType = "Fatal error";
	        }else if(data[i].messageType == 'A'){
	            data[i].iconType = "glyphicon glyphicon-scissors";
	            data[i].errorType = "Canceled (internal error)";
	        }else if(data[i].messageType == 'W'){
	           /* data[i].iconType ="glyphicon glyphicon-warning-sign";*/
	        	 data[i].iconType ="fa fa-warning";
	            data[i].errorType = "Warning";
	        }else if(data[i].messageType == 'I'){
	            data[i].iconType = "fa fa-info";
	            data[i].errorType = "Information";
	        }else if(data[i].messageType == 'S'){
	           /* data[i].iconType = "glyphicon glyphicon-check";*/
	        	data[i].iconType = "fa fa-check-circle";
	            data[i].errorType = "Status Message";
	
	        } else{
	            data[i].description = data[i].messageType;
	            data[i].errorType = "Error";
	        /*    data[i].iconType = "glyphicon glyphicon-remove-circle"; */
	            data[i].iconType = "fa fa-times-circle"; 
	            /*$rootScope.executionLogsData[$scope.executionFileSize].status = " fa fa-times-circle";
	            $rootScope.uploadedScopes[$scope.executionFileSize].status = " fa fa-times-circle";*/
	            
	            //Changing the error icon as per new UX
	            $rootScope.executionLogsData[$scope.executionFileSize].status = " fa fa-times-circle";
	            $rootScope.uploadedScopes[$scope.executionFileSize].status = " fa fa-times-circle";
	           
	            $rootScope.retryExecution = true;
	            
	        } 
	        $rootScope.resultList.push(data[i]);
	        $rootScope.reportData.push(data[i]);
	        
	
	    }
    }
    
    $rootScope.uploadedScopes[$scope.executionFileSize].logs = data;
/*    if($rootScope.reExecution == true )
    $scope.executionFileSize = $rootScope.reExecutionFileSize;*/
    
    $rootScope.executionLogsData[$scope.executionFileSize].logs = "";
    $rootScope.executionLogsData[$scope.executionFileSize].logs = data;
    
		
    if($rootScope.executionLogsData[$scope.executionFileSize].editwtricon == "glyphicon glyphicon-floppy-disk"){
		$rootScope.executionLogsData[$scope.executionFileSize].customizingTr_readOnly = true;
		$rootScope.executionLogsData[$scope.executionFileSize].editwtricon = "editicon";
		$rootScope.executionLogsData[$scope.executionFileSize].editwtrTR = "editTR";
	}
	
	if($rootScope.executionLogsData[$scope.executionFileSize].editktricon == "glyphicon glyphicon-floppy-disk"){
		$rootScope.executionLogsData[$scope.executionFileSize].workbenchTr_readOnly = true;
		$rootScope.executionLogsData[$scope.executionFileSize].editktricon = "editicon";
		$rootScope.executionLogsData[$scope.executionFileSize].editktrTR = "editTR";	
	}

    

	if(responseData.data.status == "Success"){
		count++;
		if($rootScope.uploadedScopes.length == count)
		{
			$rootScope.retryExecution = false;
			$scope.executeDisabled  = true;
		}
		$rootScope.failure = false;
  /*      $rootScope.executionLogsData[$scope.executionFileSize].status = "fa fa-check-circle";
        $rootScope.uploadedScopes[$scope.executionFileSize].status = "fa fa-check-circle";*/
		
	      $rootScope.executionLogsData[$scope.executionFileSize].status = "fa fa-check-circle";
	        $rootScope.uploadedScopes[$scope.executionFileSize].status = "fa fa-check-circle";
        
        if($rootScope.executionLogsData[$scope.executionFileSize].trType != null && $rootScope.executionLogsData[$scope.executionFileSize].trType.search("K") > -1)
			 $rootScope.executionLogsData[$scope.executionFileSize].workbenchTr_mode = "Display";
		 else
			 $rootScope.executionLogsData[$scope.executionFileSize].workbenchTr_mode = "";
		 
		 if($rootScope.executionLogsData[$scope.executionFileSize].trType != null && $rootScope.executionLogsData[$scope.executionFileSize].trType.search("W") > -1)
			 $rootScope.executionLogsData[$scope.executionFileSize].customizingTr_mode = "Display";
		else
			$rootScope.executionLogsData[$scope.executionFileSize].customizingTr_mode = "";
        
	}
	else if(responseData.data.status == "Warning"){
		$rootScope.retryExecution = true;
		$rootScope.failure = true;

		$rootScope.executionLogsData[$scope.executionFileSize].status = "status-partial";
		$rootScope.uploadedScopes[$scope.executionFileSize].status = "status-partial";

	}
	else{
		/* Hiding the button for release 1 need to enable it for release 2*/
		$rootScope.retryExecution = true;
		/* document.getElementById("tablerow").style.height="90px";*/
		$rootScope.failure = true;
		/*$rootScope.executionLogsData[$scope.executionFileSize].status = " fa fa-times-circle";
		$rootScope.uploadedScopes[$scope.executionFileSize].status = " fa fa-times-circle";*/
		 //Changing the error icon as per new UX
        $rootScope.executionLogsData[$scope.executionFileSize].status = " fa fa-times-circle";
        $rootScope.uploadedScopes[$scope.executionFileSize].status = " fa fa-times-circle";
       
        //$rootScope.reExecutionData.push($rootScope.executionLogsData[$scope.executionFileSize]);
        /*for(var i=0;i<1;i++){
        $rootScope.reExecutionFileSize = $scope.executionFileSize;
        }*/
	}
   
	
    if($rootScope.executionLogsData[$scope.executionFileSize].status == " fa fa-times-circle" || $rootScope.executionLogsData[$scope.executionFileSize].status == "status-partial"){
    	$scope.errorCount++;
    	$rootScope.msg3 = "No. of Config Processed Failed - "+$scope.errorCount;
    	$scope.reExecuteDisabled = false;
        $rootScope.executionName = "RE-EXECUTE";
        $rootScope.isReExecutionReq = true;
        if($rootScope.uploadedScopes[$scope.executionFileSize].customizingTr_mode == "Edit"){
        	$rootScope.uploadedScopes[$scope.executionFileSize].editwtricon = "editicon";
        	$rootScope.uploadedScopes[$scope.executionFileSize].editwtrTR = "editTR";
        }
        if($rootScope.uploadedScopes[$scope.executionFileSize].workbenchTr_mode == "Edit"){
        	$rootScope.uploadedScopes[$scope.executionFileSize].editktricon = "editicon";
        	$rootScope.uploadedScopes[$scope.executionFileSize].editktrTR = "editTR";
        }
    	//$rootScope.viewExecutionData.push($rootScope.executionLogsData[$scope.executionFileSize]);
    	/*if($scope.errorCount == 1)
    		 $rootScope.reExecutionFileSize = $scope.executionFileSize;*/
    	}
    else{
    	$rootScope.uploadedScopes[$scope.executionFileSize].editwtricon = "";
    	$rootScope.uploadedScopes[$scope.executionFileSize].editktricon = "";

    	$scope.successCount++;
    	$rootScope.msg2 = "No.of Config Processed Successfully -  "+$scope.successCount;
    	
    }
}
    
	};
	
	$scope.errorLogsForScope = function(){
	    //$mdDialog.cancel();
		/*    	  $rootScope.overlay = document.getElementById("overlay_execute");
			     $rootScope.popup = document.getElementById("busy_execute");
			     $rootScope.overlay.style.display = "none";
			     $rootScope.popup.style.display = "none";*/
		
		 $rootScope.overlay = document.getElementById("overlay_execute");
	     $rootScope.popup = document.getElementById("busy_execute");
	     $rootScope.overlay.style.display = "none";
	     $rootScope.popup.style.display = "none";

	    var data = [{ "description" : "Scope is not available in the Object Mapping Template!!",
	    			"errorType" : "E",
	    			"messageType" : "E",
	    			"scopeName" : $rootScope.uploadedScopes[$scope.executionFileSize].imgId,
	    			"imgDesc" : $rootScope.uploadedScopes[$scope.executionFileSize].imgDescription,
	    			"iconType": "fa fa-times-circle",
	    			"errorType" : "Error (could not execute function)"
	    			
	    }];
	    
	   //// var errorLlist = [];
	    
	  //  errorLlist.push(data[0]);
	
	    $rootScope.resultList.push(data[0]);
        $rootScope.reportData.push(data[0]);
	    	
	    	$scope.executionRequired = true;


	    
	    $rootScope.uploadedScopes[$scope.executionFileSize].logs = data;
	    $rootScope.executionLogsData[$scope.executionFileSize].logs = "";
	    $rootScope.executionLogsData[$scope.executionFileSize].logs = data;
		$rootScope.executionLogsData[$scope.executionFileSize].status = " fa fa-times-circle";
	    $rootScope.uploadedScopes[$scope.executionFileSize].status = " fa fa-times-circle";
	    $scope.errorCount++;
	    $rootScope.msg3 = "No. of Config Processed Failed - "+$scope.errorCount;
	   	$scope.reExecuteDisabled = false;
	   	$rootScope.executionName = "RE-EXECUTE";
        $rootScope.isReExecutionReq = true;
	    
		};
	    
	  /*  $scope.configReExecute = function() {
	    	$rootScope.reExecution = true;
	    	
	    	//$rootScope.executionLogsData =[];
	    	//if($rootScope.uploadedScopes.logs.messageType = "Network")
	    	//$rootScope.uploadedScopes = [];
	    	$scope.executionFileSize = 0;
	    	$scope.errorCount = 0;
	    	$scope.successCount = 0;
	    	//$rootScope.uploadedScopes = $rootScope.reExecutionData;
	    	//$rootScope.executionLogsData = $rootScope.reExecutionData;
	    	if($rootScope.implType == "1" ){
    			//$rootScope.confirmExecution();
	    		$rootScope.uploadedScopes = [];
	    		$scope.greenFieldExecution();
    		}else if($rootScope.implType == "2" || $rootScope.implType == "3"){
    			if($rootScope.modTypes.value == "Automated without intervention")
    				$rootScope.scopeAvilabilityInSource();
    			else if($rootScope.modTypes.value == "Automated with intervention")
    				$scope.greenFieldExecution();
    				
    		}
	    	//$rootScope.viewExecutionData.push()
	    	 if($scope.successCount == $rootScope.executionLogsData.length)
	    		 $scope.reExecuteDisabled = true;
	    }*/
	   
	    
	    $scope.errorResponse = function(errordata){
	    	 $rootScope.uploadedScopes[$scope.executionFileSize].status = "fa fa-times-circle";
	       // $mdDialog.cancel();
	        
	     
	        
	        var data = [{ "description" : "Service execution failed due to Network Error. So, please contact Administrator..!!",
    			"errorType" : "E",
    			"messageType" : "E",
    			"scopeName" : $rootScope.uploadedScopes[$scope.executionFileSize].imgId,
    			"imgDesc" : $rootScope.uploadedScopes[$scope.executionFileSize].imgDescription,
    			"iconType": " fa fa-times-circle"
    			
	        }];

	        $rootScope.resultList.push(data[0]);
	        $rootScope.reportData.push(data[0]);

		    
		    $rootScope.uploadedScopes[$scope.executionFileSize].logs = data;
		    $rootScope.executionLogsData[$scope.executionFileSize].logs = "";
		    $rootScope.executionLogsData[$scope.executionFileSize].logs = data;
			$rootScope.executionLogsData[$scope.executionFileSize].status = " fa fa-times-circle";
		    $rootScope.uploadedScopes[$scope.executionFileSize].status = " fa fa-times-circle";
	        		

	    };
	    
	    
	 $scope.masterResponseData = function(responseData){
	    	var outputData = {};
	    	var resultData= responseData.data.listFiMDResponse;
	       // $mdDialog.cancel();
	  	  	$rootScope.overlay = document.getElementById("overlay_execute");
		     $rootScope.popup = document.getElementById("busy_execute");
		     $rootScope.overlay.style.display = "none";
		     $rootScope.popup.style.display = "none";
	        var data,resData = {};
	        var scount = 0;
        	var fcount = 0;
        	$rootScope.resultList =[];

        	for(var k=0,arrLen = resultData.length;k< arrLen ;k++){
        		/*if(resultData[k].status == "Success")
        			scount++;
        		else
        			fcount++;*/
        		
        	    $scope.connectionStatus = resultData[k].connectionStatus;

        	if(resultData[k].status == "Success"){
        	$rootScope.retryExecution = false;
   			 $rootScope.executionLogsData[$scope.executionFileSize].status = "fa fa-check-circle";
   			$rootScope.uploadedScopes[$scope.executionFileSize].status = "fa fa-check-circle";
   		  if($rootScope.executionLogsData[$scope.executionFileSize].trType != null && $rootScope.executionLogsData[$scope.executionFileSize].trType.search("K") > -1)
 			 $rootScope.executionLogsData[$scope.executionFileSize].workbenchTr_mode = "Display";
 		 else
 			 $rootScope.executionLogsData[$scope.executionFileSize].workbenchTr_mode = "";
 		 
 		 if($rootScope.executionLogsData[$scope.executionFileSize].trType != null && $rootScope.executionLogsData[$scope.executionFileSize].trType.search("W") > -1)
 			 $rootScope.executionLogsData[$scope.executionFileSize].customizingTr_mode = "Display";
 		else
 			$rootScope.executionLogsData[$scope.executionFileSize].customizingTr_mode = "";
        	}
		else if(resultData[k].status == "Error"){
			$rootScope.retryExecution = true;
            $rootScope.uploadedScopes[$scope.executionFileSize].status = "fa fa-times-circle";
			$rootScope.executionLogsData[$scope.executionFileSize].status = "fa fa-times-circle";
			
		}
		else if(resultData[k].status == "Warning"){
			$rootScope.retryExecution = true;
			$rootScope.executionLogsData[$scope.executionFileSize].status = "status-partial";
			$rootScope.uploadedScopes[$scope.executionFileSize].status = "status-partial";

		}
        		data = resultData[k].result;
	        for(var i = 0; i< data.length;i++){
	        	data[i].imgDesc = $rootScope.uploadedScopes[$scope.executionFileSize].imgDescription;

	        outputData.imgDesc = "";
	        outputData.iconType = "";
	        outputData.description = "";
	        		var result1 = {};
        			data[i].description = data[i].description;

	        		if(data[i].messageType == 'S'){
		                data[i].iconType = "glyphicon glyphicon-check";
		                data[i].errorType = "Status Message";
		            }else if(data[i].messageType == 'E'){
		                data[i].errorType = "Error (could not execute function)";
		                //data[i].iconType = "glyphicon glyphicon-remove-circle";
		                data[i].iconType = "fa fa-times-circle"; 
		            }
		            else if(data[i].messageType == 'N'){
		                data[i].errorType = "Function executed";
		                data[i].iconType = "glyphicon glyphicon-ok"; 
		            }
		            else if(data[i].messageType == 'A'){
		                data[i].iconType = "glyphicon glyphicon-scissors";
		                data[i].errorType = "Canceled (internal error)";
		            }else if(data[i].messageType == 'W'){
		                data[i].iconType ="glyphicon glyphicon-warning-sign";
		                data[i].errorType = "Warning";
		            }else if(data[i].messageType == 'I'){
		                data[i].iconType = "fa fa-info";
		                data[i].errorType = "Information";
		                
		            }else if(data[i].messageType == 'F'){
			                data[i].iconType = "glyphicon glyphicon-ban-circle";
			                data[i].errorType = "Fatal error";
			            }
		            else{
		                data[i].description = data[i].messageType;
		                data[i].errorType = "Error";
		               // data[i].iconType = "glyphicon glyphicon-remove-circle"; 
		                data[i].iconType = "fa fa-times-circle"; 
		                $rootScope.executionLogsData[$scope.executionFileSize].status = " fa fa-times-circle";
		                $rootScope.uploadedScopes[$scope.executionFileSize].status = " fa fa-times-circle";
		                
		                $rootScope.retryExecution = true;
		            } 
		            $rootScope.resultList.push(data[i]);
		            $rootScope.reportData.push(data[i]);

//		        }	
//	        }
	        }
        }
	        
	      /*  if(resultData.length == scount){
                $rootScope.executionLogsData[$scope.executionFileSize].status = "fa fa-check-circle";
	        }else if(resultData.length == fcount){
                $rootScope.executionLogsData[$scope.executionFileSize].status = " fa fa-times-circle";
	        }else{
                $rootScope.executionLogsData[$scope.executionFileSize].status = "status-partial";
	        }*/

	        $rootScope.uploadedScopes[$scope.executionFileSize].logs = $rootScope.resultList;
	        
	        $rootScope.executionLogsData[$scope.executionFileSize].logs = $rootScope.resultList;

	        if($rootScope.executionLogsData[$scope.executionFileSize].status == "fa fa-times-circle" || $rootScope.executionLogsData[$scope.executionFileSize].status == "status-partial"){
	        	
	        	$scope.errorCount++;
	        	$rootScope.msg3 = "No. of Config Processed Failed - "+$scope.errorCount;
	        	$scope.reExecuteDisabled = false;
		         $rootScope.executionName = "RE-EXECUTE";
		         $rootScope.isReExecutionReq = true;
		         if($rootScope.uploadedScopes[$scope.executionFileSize].customizingTr_mode == "Edit"){
		         	$rootScope.uploadedScopes[$scope.executionFileSize].editwtricon = "editicon";
		         	$rootScope.uploadedScopes[$scope.executionFileSize].editwtrTR = "editTR";
		         }
		         if($rootScope.uploadedScopes[$scope.executionFileSize].workbenchTr_mode == "Edit"){
		         	$rootScope.uploadedScopes[$scope.executionFileSize].editktricon = "editicon";
		         	$rootScope.uploadedScopes[$scope.executionFileSize].editktrTR = "editTR";
		         }
	        	}
	        else{
	        	$rootScope.uploadedScopes[$scope.executionFileSize].editwtricon = "";
	        	$rootScope.uploadedScopes[$scope.executionFileSize].editktricon = "";
	        	$scope.successCount++;
	        	$rootScope.msg2 = "No.of Config Processed Successfully -  "+$scope.successCount;
	        	}

    }
	    $scope.configLogs = function(logs,imgDescription){
	    	//$scope.logsExportOptions.data = [];
	    	/* if($rootScope.implType != "1" && $rootScope.modTypes.value == "Automated without intervention")
				 $rootScope.executionLogsData = $rootScope.executeScopeList;
			 else
				 $rootScope.executionLogsData = $rootScope.uploadedScopes;*/
	    	 
	    	$scope.executionLogData =[];
	    	$scope.executionLogData1 =[];

	    	$scope.scopeDescription = imgDescription;
	
  		$scope.viewlogsLink="viewlogsEnable";
  	if(logs != undefined){ 
  		if(logs.length <= 25){
	    	for(var k=0 ; k <logs.length ;k++){
    			if(logs[k].imgDesc === imgDescription){
    	    		var bData1 = {
    		    		 "imgDesc": logs[k].imgDesc,
    	                 "description": logs[k].description,
                       "iconType": logs[k].iconType
                     
                    
                  };  
	    			$scope.executionLogData.push(bData1);
	    			 bData1 = {};
    	    	}
    			
    			
    		}
			$scope.executionLogData1.push($scope.executionLogData);
			 ngDialog.openConfirm({
	            template: 'view/config/ConfigFinalLogs.html?ver='+version,
	            //controller:'ConfigExecutePage',
	            scope: $scope,
	            closeByDocument: false,
	            closeByEscape: false,
	            showClose: true,
	            height: 487,
	            width: 732,
	            className:'ngdialog-theme-default CLASS_projName'
	        });
  		}else{
  			ngDialog.openConfirm({
	            template: 'Logs are not available here. So, Please select export to excel option to download the logs',
	            plain: true,
                scope: $scope,
                closeByDocument: true,
                closeByEscape: true,
                showClose: true,
                height:120,
                width: 350
	        });
  			}
	    }  	
	    };
	    
	    $scope.executePrevious = function(){
	    	
//	    	$scope.executeListener();
	  		if($rootScope.implType == "1" ){
	  			
	  			$rootScope.name = "not-active";
 	    		$rootScope.name1 = "active1";
 	    		$rootScope.name2 = "active";  
 	    		$rootScope.name3 = "not-active";
 	    		
 	    		 $rootScope.wizard1  = "donewizard";
				 $rootScope.wizard2  = "disablewizard";
				 $rootScope.wizard3  = "activewizard";
				 $rootScope.wizard4  = "applicablewizard";
				 
	  			$rootScope.fileUploadAuth = "true";
	           // document.cookie = "fileUploadAuth=" + $rootScope.fileUploadAuth + ";expires=" + myDate.toUTCString();
	            $location.path("/ConfigHeader/fileUpload");
	            
	  		}
	  			else if($rootScope.implType == "2" || $rootScope.implType == "3"){
	  			
	  				 if($rootScope.modTypes.value == "Automated without intervention"){
				  					 if($rootScope.implType == "2"){
				  						$rootScope.implTypelabel = "defaultImplType";
				  						$rootScope.implTypelabel2 = "secondImplType";
				  						$rootScope.implTypelabel3 = "defaultImplType";
				  						
				  						 $rootScope.wizard1  = "activewizard";
				  						 $rootScope.wizard2  = "disablewizard";
				  						 $rootScope.wizard3  = "disablewizard";
				  						 $rootScope.wizard4  = "applicablewizard";
				  					 }
				  					 else{
				  						$rootScope.implTypelabel = "defaultImplType";
				  						$rootScope.implTypelabel2 = "defaultImplType";
				  						$rootScope.implTypelabel3 = "secondImplType";
				  						
				  						 $rootScope.wizard1  = "applicablewizard";
				  						 $rootScope.wizard2  = "applicablewizard";
				  						 $rootScope.wizard3  = "activewizard";
				  						 $rootScope.wizard4  = "applicablewizard";
				  					 }
				  					$rootScope.name = "active";
					 	    		$rootScope.name1 = "active1";
					 	    		$rootScope.name2 = "active1";  
					 	    		$rootScope.name3 = "not-active";
					 	    		
	  					$rootScope.configInital = "true";
//	  					document.cookie = "configAuth=" + $rootScope.configAuth + ";expires=" + myDate.toUTCString();
	  					//document.cookie = "configInitial=" + $rootScope.configInital + ";expires=" + myDate.toUTCString();
			            $location.path("/ConfigHeader/configPage");
	  				 } else if($rootScope.modTypes.value == "Automated with intervention" ){//Brown Field Modification
	  					
	  					 $rootScope.name = "not-active";
		 	    		$rootScope.name1 = "not-active";
		 	    		$rootScope.name2 = "active";  
		 	    		$rootScope.name3 = "not-active"; 
		 	    		
		 	    		 $rootScope.wizard1  = "donewizard";
  						 $rootScope.wizard2  = "donewizard";
  						 $rootScope.wizard3  = "activewizard";
  						 $rootScope.wizard4  = "applicablewizard";
  						 
	  					 $rootScope.fileUploadAuth = "true";
	  		           // document.cookie = "fileUploadAuth=" + $rootScope.fileUploadAuth + ";expires=" + myDate.toUTCString();
	  		            $location.path("/ConfigHeader/fileUpload");
	  				 }
	  				
	    		}

	    };
	
	    
	    $scope.dependencyView = function(){
	    	
	    	ngDialog.openConfirm({
	            template: 'view/config/DependencyList.html?ver='+version,
	            controller:'dependencyScopeController',
	            scope: $scope,
	            closeByDocument: false,
	            closeByEscape: false,
	            showClose: false,
	            height: 540,
	            width: 732,
	            className:'ngdialog-theme-default CLASS_projHierarchy'
	        });
	    };
	    
	    
	    $scope.downloadScopeList = function(){
	    	
	    	ngDialog.openConfirm({
	            template: 'view/config/ScopeLogs.html?ver='+version,
	            controller:'downloadScopeController',
	            scope: $scope,
	            closeByDocument: false,
	            closeByEscape: false,
	            showClose: false,
	            height: 490,
	            width: 732,
	            className:'ngdialog-theme-default CLASS_projName'
	        });
	    };
	    
	    
  $scope.downloadConfigStatus = function(){
	    	
	    	ngDialog.openConfirm({
	            template: 'view/config/bwnFieldDwdStatus.html?ver='+version,
	            controller:'configDwdStatusController',
	            scope: $scope,
	            closeByDocument: false,
	            closeByEscape: false,
	            showClose: false,
	            height: 490,
	            width: 640,
	            className:'ngdialog-theme-default CLASS_projName'
	        });
	    };
	    
	    
	    $rootScope.dependencyCheck = function(){
	    	var depList = [];
	    	var dependencyList = {};
	    	for(var i=0,arrLen = $rootScope.uploadedScopes.length;i< arrLen ;i++){
	    		depList.push($rootScope.uploadedScopes[i].imgId);
	    	}
	    	dependencyList.inputImgId = depList;
	    	dependencyList.sessionInputDTO = $rootScope.sessionInputObj;
	    	dependencyList.industryFlag=$rootScope.industryFlag;

	        var dependencyUrl = "/" + servicePrefix + "/rest/imgHierarchySrv/getDependencyImg";
	        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
	        
	         $rootScope.overlay = document.getElementById("overlay_execute");
	        $rootScope.popup = document.getElementById("busy_execute");
	        $rootScope.overlay.style.display = "block";
	        $rootScope.popup.style.display = "inline-block";
	        
	       /* $mdDialog.show({
	            controller: function($scope, $mdDialog){
	            $scope.isLoading = true;
	            },
	            templateUrl: 'view/busy.html?ver='+version,
	            parent: angular.element(document.body),
	            clickOutsideToClose: false,
	            fullscreen: useFullScreen,
	            escapeToClose: false,
	        })
	        .then(function(answer) {
	        }, function() {
	        });*/
	     
	        $http.post(dependencyUrl,dependencyList).then(function(responseData){
	        	
	        	$rootScope.dependencyResponse = [];
	        	if(responseData.data.listImgHierarchyDto!=null){
	        	for(var i=0,arrLen = responseData.data.listImgHierarchyDto.length;i< arrLen ;i++){
	        		var data = {};
	        	data.imgDescription = responseData.data.listImgHierarchyDto[i].imgDescription;
	        	data.dependencyImgIdDesc = responseData.data.listImgHierarchyDto[i].dependencyImgIdDesc;
	        	
	        	$rootScope.dependencyResponse.push(data);
	        	}
	        	}else if(responseData.data.resMessageDto != null && responseData.data.resMessageDto.message == serviceMessage){
      	      		$rootScope.checkAuthorization();
      	      	}
	        	 $rootScope.overlay.style.display = "none";
        	     $rootScope.popup.style.display = "none";
	        	//$mdDialog.cancel();
	        	
	        	if(responseData.data.listImgHierarchyDto!=null && responseData.data.listImgHierarchyDto.length > 0)
	        		$scope.dependencyView();
	        	else{
	        		if($rootScope.implType == "1" ){
	        			$rootScope.confirmExecution();
	        		}else if($rootScope.implType == "2" || $rootScope.implType == "3"){
	        			if($rootScope.modTypes.value == "Automated without intervention")
	        				$rootScope.scopeAvilabilityInSource();
	        			else if($rootScope.modTypes.value == "Automated with intervention")
	        				$rootScope.confirmExecution();
	        				
	        		}
	        	}
	        		 
   	
            }) ,(function(data){
            	$mdDialog.cancel();
            });
	        
	    };
	    
	    
//	    $rootScope.$on("CallscopeAvilabilityInSource", function(){
//	        $scope.scopeAvilabilityInSource();
//	     });
	    
	    $rootScope.scopeAvilabilityInSource = function(){
	    	if($rootScope.isReExecutionReq == false)
			$rootScope.assignCommonTR();// Assigning common TR(CTR and WTR)
	    	$rootScope.downloadScope = [];
	    	$rootScope.executeScopeList = [];
	    var status= false;
	    	var imgScopeList = [];
	    	var scopeCheckReqDto = {};
	    	for(var i=0,arrLen = $rootScope.uploadedScopes.length;i< arrLen ;i++){
	    		
	    		var imgScope = {};
	    		imgScope.imgId = $rootScope.uploadedScopes[i].imgId;
	    		imgScope.imgDescription = $rootScope.uploadedScopes[i].imgDescription;
	    		imgScope.seqNo = $rootScope.uploadedScopes[i].sequence;
	    		imgScope.isMasterData = $rootScope.uploadedScopes[i].isMasterData;
	    		imgScope.workbenchTr = $rootScope.uploadedScopes[i].workbenchTr;
	    		imgScope.customizingTr = $rootScope.uploadedScopes[i].customizingTr;
	    		imgScope.customizingTr_readOnly = $rootScope.uploadedScopes[i].customizingTr_readOnly;
	    		imgScope.workbenchTr_readOnly = $rootScope.uploadedScopes[i].workbenchTr_readOnly;
	    		imgScope.customizingTr_mode = $rootScope.uploadedScopes[i].customizingTr_mode;
	    		imgScope.workbenchTr_mode = $rootScope.uploadedScopes[i].workbenchTr_mode;
	    	
	    		
//	    		depList.push($rootScope.uploadedScopes[i].imgId);
	    		imgScopeList.push(imgScope);
	    		
	    	}
//	    	scopeList.imgId = depList;
	    	scopeCheckReqDto.imgScopeDto = imgScopeList;
	    	scopeCheckReqDto.systemType = $rootScope.sourceSystemType;
	    	scopeCheckReqDto.sessionInputDTO = $rootScope.sessionInputObj;
	    	scopeCheckReqDto.copyFlag = false;
	    	scopeCheckReqDto.industryFlag=$rootScope.industryFlag;
	    	if($rootScope.industryFlag){
	    		scopeCheckReqDto.industryAlias = $rootScope.aliasIndustry;
	    		scopeCheckReqDto.subIndustryAlias = $rootScope.aliasSubIndustry;
	    		scopeCheckReqDto.industry=$rootScope.selectedIndustry;
	    		scopeCheckReqDto.subIndustry=$rootScope.selectedsubIndustry;
            }
//	    	scopeList.systemType = "SAP ECC";
    	
	        var dependencyUrl = "/" + servicePrefix + "/rest/autoConfigSrv/getDownloadscope";
	        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
	        /*$mdDialog.show({
	            controller: function($scope, $mdDialog){
	            $scope.isLoading = true;
	            },
	            templateUrl: 'view/busy.html?ver='+version,
	            parent: angular.element(document.body),
	            clickOutsideToClose: false,
	            fullscreen: useFullScreen,
	            escapeToClose: false,
	        })
	        .then(function(answer) {
	        }, function() {
	        });*/
	     
	        $rootScope.overlay = document.getElementById("overlay_execute");
	        $rootScope.popup = document.getElementById("busy_execute");
	        $rootScope.overlay.style.display = "block";
	        $rootScope.popup.style.display = "inline-block";
	        
	        
	        $http.post(dependencyUrl,scopeCheckReqDto).then(function(responseData){
	        	if(responseData.data.resMessageDto != null && responseData.data.resMessageDto.message == serviceMessage){
      	      		$rootScope.checkAuthorization();
      	      	}
	        	else {
	        		for(var i=0,arrLen = responseData.data.listScopeCheckResDto.length;i< arrLen ;i++){
	        		var imgScopeResult = {};
	        		var tempImgScope = {};
	        		
	        		
//	        		imgScopeResult.imgId = responseData[i].imgScopeDto.imgId;
	        		imgScopeResult.imgDescription = responseData.data.listScopeCheckResDto[i].imgScopeDto.imgDescription;
	        		imgScopeResult.sequence = responseData.data.listScopeCheckResDto[i].imgScopeDto.seqNo; 
//	        		imgScopeResult.imgScope = responseData[i].imgScope;
//	        		imgScopeResult.scopeAvailable = responseData[i].scopeAvailable;
	        		if(responseData.data.listScopeCheckResDto[i].scopeAvailable == "Y"){
	        			imgScopeResult.scopeAvailableIcon = "glyphicon glyphicon-ok";
	        		}
		        	else{
		        		imgScopeResult.scopeAvailableIcon = "glyphicon glyphicon-remove";
		        		var index = -1;
		        		var imgId = responseData.data.listScopeCheckResDto[i].imgScopeDto.imgId;
		        		$rootScope.uploadedScopes.some(function(obj, i) {
			        		    return obj.imgId ==  imgId ? index = i : false;
			       		});
			       		
			        		$rootScope.uploadedScopes[index].scopeExists = true;
		        		}
	        		
	        	
	        		tempImgScope.imgId = responseData.data.listScopeCheckResDto[i].imgScopeDto.imgId;
	        		
	        	 
	        		
	        		tempImgScope.imgDescription = responseData.data.listScopeCheckResDto[i].imgScopeDto.imgDescription;
	        		tempImgScope.sequence = responseData.data.listScopeCheckResDto[i].imgScopeDto.seqNo; 
//	        		tempImgScope.imgDesc = responseData[i].imgScopeDto.imgDesc;
	        		tempImgScope.imgScope = responseData.data.listScopeCheckResDto[i].imgScope;
	        		tempImgScope.isMasterData = responseData.data.listScopeCheckResDto[i].imgScopeDto.isMasterData;
	        		tempImgScope.workbenchTr = responseData.data.listScopeCheckResDto[i].imgScopeDto.workbenchTr;
	        		tempImgScope.customizingTr = responseData.data.listScopeCheckResDto[i].imgScopeDto.customizingTr;
	        		tempImgScope.customizingTr_readOnly = responseData.data.listScopeCheckResDto[i].imgScopeDto.customizingTr_readOnly;
	        		tempImgScope.workbenchTr_readOnly = responseData.data.listScopeCheckResDto[i].imgScopeDto.workbenchTr_readOnly;
	        		tempImgScope.customizingTr_mode = responseData.data.listScopeCheckResDto[i].imgScopeDto.customizingTr_mode;
	        		tempImgScope.workbenchTr_mode = responseData.data.listScopeCheckResDto[i].imgScopeDto.workbenchTr_mode;
	        		
	        	if(responseData.data.listScopeCheckResDto[i].scopeAvailable == "Y" || responseData.data.listScopeCheckResDto[i].imgScopeDto.isMasterData == "Y"){
	        		$rootScope.executeScopeList.push(tempImgScope);
	        		status= true;
	        	}
	        	if(responseData.data.listScopeCheckResDto[i].scopeAvailable == "N")
        		{
        		$scope.isScopeAvailable = true;
        		}
	        	
	        	
	        	$rootScope.downloadScope.push(imgScopeResult);
	        	}
	        	//$mdDialog.cancel();
	        	 
	        	 $rootScope.overlay.style.display = "none";
        	     $rootScope.popup.style.display = "none";
	        	
	          	if($rootScope.executeScopeList.length > 0 && ($rootScope.executeScopeList.length == responseData.data.length))
	          		$rootScope.confirmExecution();
	          	else if($rootScope.downloadScope.length > 0 && status)
	          		$scope.downloadScopeList();
	        	else{
	          		ngDialog.openConfirm({
	    	            template: 'Selected scopes are not available in the Source Destination',
	    	            plain: true,
	                    scope: $scope,
	                    closeByDocument: true,
	                    closeByEscape: true,
	                    showClose: true,
	                    height:120,
	                    width: 350
	    	        });
	          	  }
	        	}
            }) ,(function(data){
            	$mdDialog.cancel();
            });
	        
	        //$scope.executeDisabled  = true; 
	        
	    };
	    
	    
	    $scope.masterDependencyCheck = function(){
    		
 		   var  uploadUrl = "/" + servicePrefix + "/rest/imgHierarchySrv/masterDataDependency";

	        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
	       /* $mdDialog.show({
	            controller: function($scope, $mdDialog){
	            $scope.isLoading = true;
	            },
	            templateUrl: 'view/busy.html?ver='+version,
	            parent: angular.element(document.body),
	            clickOutsideToClose: false,
	            fullscreen: useFullScreen,
	            escapeToClose: false,
	        })
	        .then(function(answer) {
	        }, function() {
	        });*/
	     
	        $rootScope.overlay = document.getElementById("overlay_execute");
	        $rootScope.popup = document.getElementById("busy_execute");
	        $rootScope.overlay.style.display = "block";
	        $rootScope.popup.style.display = "inline-block";
	        var params = {
	        		 selectedScopeData : $rootScope.uploadedScopes,
	        		 sessionInputDTO : $rootScope.sessionInputObj,
	        		 industryFlag: $rootScope.industryFlag

	        }
	        
	        $http.post(uploadUrl,params).then(function(responseData){
	        	//$mdDialog.cancel();
	        	$rootScope.overlay.style.display = "none";
	   		 	$rootScope.popup.style.display = "none";
	   		 if(responseData.data.resMessageDto != null && responseData.data.resMessageDto.message == serviceMessage){
   	      		$rootScope.checkAuthorization();
   	      	}
	   		 else $rootScope.uploadedScopes = responseData.data.listBrownfieldMdRequestDto;
	   		// if($rootScope.hierarchyTypes.value == "IMG"){
	        	$scope.createConfigTransaction();
	        	/*}else{
	          	if( $rootScope.implType == "1" ){
	    			$scope.greenFieldExecution();
	    		}else if( $rootScope.implType == "2" || $rootScope.implType == "3"){
	    			if($rootScope.modTypes.value == "Automated with intervention"){
	    					$scope.greenFieldExecution();
	    			}else if($rootScope.modTypes.value == "Automated without intervention"){ 
	    				 $scope.brownFieldDownload();
	    			}
	    		}
	        }*/
	       }) ,(function(data){
	            //$mdDialog.cancel();
	    		$rootScope.overlay.style.display = "none";
	   		 	$rootScope.popup.style.display = "none";
	   		 	ngDialog.openConfirm({
		            template: '<p>' + "Network error is encountered. Please logout and execute again "+'</p>',
		            scope: $scope,
		            plain:true,
		            closeByDocument: false,
		            closeByEscape: false,
		            showClose: true,
		            height: 426,
		            width: 527,
		           className:'ngdialog-theme-default CLASS_projName'
		        })
	            });
 	};
 	
 	$scope.exportAction = function (option) {
 		var d = new Date();
 		$rootScope.showLogsExportData = true;
 		$rootScope.showExportLogs = true;
 		
 		var fileName = "ConfigLogsExport"+d.getDate()+""+d.getMonth()+""+d.getYear()+""+d.getTime();
 		alasql('SELECT scopeName as ScopeName,imgDesc as ImgDescription,messageType as MessageType,description as Description INTO XLSX("'+fileName+'.xlsx",{headers:true}) FROM ?',[$rootScope.reportData]);
 	   };
 	
	    //Create config transaction before Execute
	    $scope.createConfigTransaction = function(){
	    	
	    	var ConfigTransactionDto = {};
	    	ConfigTransactionDto.omgID  = $rootScope.projOmId;
	    	ConfigTransactionDto.userID = $rootScope.username;
	    	ConfigTransactionDto.sapUserID = $rootScope.sapUserID;
	    	ConfigTransactionDto.scenario = $rootScope.scenario;
	    	ConfigTransactionDto.targetValue = $rootScope.targetValue;
	    	ConfigTransactionDto.sourceValue = $rootScope.sourceValue;
	    	ConfigTransactionDto.destinationName = $rootScope.selectedTargetSystem;
	    	ConfigTransactionDto.sessionInputDTO = $rootScope.sessionInputObj;
	    	if(!$scope.executionRequired){
	    		ConfigTransactionDto.transactionID = $rootScope.transactionID;
	    		ConfigTransactionDto.configReExe = true;
	    	}
	    	var  configTranUrl = "/" + servicePrefix + "/rest/configAuditService/createConfigTransaction";

		        $http.post(configTranUrl,ConfigTransactionDto).then(function(transactionData){
		        	
		        	$rootScope.transactionID = transactionData.data.message;
		        	//$rootScope.exeReqCount = ++$rootScope.exeReqCount;
		        
		        	if($rootScope.transactionID  > 0){
			           	if( $rootScope.implType == "1" ){
			    			$scope.greenFieldExecution();
			    		}else if( $rootScope.implType == "2" || $rootScope.implType == "3"){
			    			if($rootScope.modTypes.value == "Automated with intervention"){
			    					$scope.greenFieldExecution();
			    			}else if($rootScope.modTypes.value == "Automated without intervention"){ 
			    				 $scope.brownFieldDownload();
			    			}
			    		}
		        	}
		       }) ,(function(data){
		            });
	    	
	 	};
	 	$scope.executeConfig=function(){
//			 $rootScope.skipExecute = true; 
			 ngDialog.close();
			 /*if($rootScope.implType != "1" && $rootScope.modTypes.value == "Automated without intervention")
				 $rootScope.executionLogsData = $rootScope.executeScopeList;
			 else*/
				 $rootScope.executionLogsData = $rootScope.uploadedScopes;

//			 $rootScope.$broadcast("CallexecuteMethod", {});
			 $rootScope.confirmExecution();
			 
		};
		
		$scope.stopeExecution=function(){
//			 $rootScope.skipExecute = false;
			 ngDialog.close();
//			 $scope.executeListener();
		};
		$scope.editconfigWTR = function(imgDesc,icon){
			
			if(icon == "editicon"){
			for(var i=0,arrLen = $rootScope.executionLogsData.length;i< arrLen ;i++){
				if($rootScope.executionLogsData[i].imgDescription == imgDesc){
					$rootScope.executionLogsData[i].customizingTr_readOnly = false;
					$rootScope.executionLogsData[i].editwtricon = "glyphicon glyphicon-floppy-disk";
					$rootScope.executionLogsData[i].editwtrTR = "saveTR";
					$rootScope.uploadedScopes[i].customizingTr_readOnly = false;
					$rootScope.uploadedScopes[i].editwtricon = "glyphicon glyphicon-floppy-disk";
					$rootScope.uploadedScopes[i].editwtrTR = "saveTR";
					}
				}
			}else if(icon == "glyphicon glyphicon-floppy-disk"){
				
				for(var i=0,arrLen = $rootScope.executionLogsData.length;i< arrLen ;i++){
					if($rootScope.executionLogsData[i].imgDescription == imgDesc){
						$rootScope.executionLogsData[i].customizingTr_readOnly = true;
						$rootScope.executionLogsData[i].editwtricon = "editicon";
						$rootScope.executionLogsData[i].editwtrTR = "editTR";
						$rootScope.uploadedScopes[i].customizingTr_readOnly = true;
						$rootScope.uploadedScopes[i].editwtricon = "editicon";
						$rootScope.uploadedScopes[i].editwtrTR = "editTR";
					}
				}
			}
		};
	$scope.editconfigKTR = function(imgDesc,icon){
			
			if(icon == "editicon"){
				
			for(var i=0,arrLen = $rootScope.executionLogsData.length;i< arrLen ;i++){
				if($rootScope.executionLogsData[i].imgId == imgDesc){
					$rootScope.executionLogsData[i].workbenchTr_readOnly = false;
					$rootScope.executionLogsData[i].editktricon = "glyphicon glyphicon-floppy-disk";
					$rootScope.executionLogsData[i].editktrTR = "saveTR";
					$rootScope.uploadedScopes[i].workbenchTr_readOnly = false;
					$rootScope.uploadedScopes[i].editktricon = "glyphicon glyphicon-floppy-disk";
					$rootScope.uploadedScopes[i].editktrTR = "saveTR";
					}
				}
			}else if(icon == "glyphicon glyphicon-floppy-disk"){
				//$rootScope.editTR = "saveTR";
				for(var i=0,arrLen = $rootScope.executionLogsData.length;i< arrLen ;i++){
					if($rootScope.executionLogsData[i].imgId == imgDesc){
						$rootScope.executionLogsData[i].workbenchTr_readOnly = true;
						$rootScope.executionLogsData[i].editktricon = "editicon";
						$rootScope.executionLogsData[i].editktrTR = "editTR";
						$rootScope.uploadedScopes[i].workbenchTr_readOnly = true;
						$rootScope.uploadedScopes[i].editktricon = "editicon";
						$rootScope.uploadedScopes[i].editktrTR = "editTR";
					}
				}
			
			}
		};
		
		
	
}]);