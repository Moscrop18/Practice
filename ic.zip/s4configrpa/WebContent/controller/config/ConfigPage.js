
angular.module('yapp').controller('ConfigInitialPage',["ngDialog","Upload","$scope","$rootScope","$http","$mdDialog","$mdMedia","$location","$filter","$state", "$timeout","Idle","$ocLazyLoad",function(ngDialog,Upload,$scope,$rootScope,$http,$mdDialog,$mdMedia,$location,$filter,$state,Idle,$timeout,$ocLazyLoad) {
	$ocLazyLoad.load(controllerName+'/config/trgSysSelection.js?ver='+version);
	
	//Browser Refresh - 13 Nov 2017
	if($rootScope.appValidity == undefined){
		   $rootScope.username = "";
		    $rootScope.password = "";
		    /*var cookies = document.cookie.split(";");
		    for (var i = 0,arrLen = cookies.length; i < arrLen ; i++) {
		        var cookie = cookies[i];
		        var eqPos = cookie.indexOf("=");
		        var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
		        document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
		    }*/
		    $location.path('/loginPage');
	    
	}
	var myDate = new Date();
	myDate.setHours(myDate.getHours() + 1);
	
	/*if($rootScope.appValidity == undefined){
		document.cookie = "configInitial=" + resetAuth + ";expires=" + myDate.toUTCString();
		$location.path('/configTilesPage');
	}*/
//	$rootScope.downloadScopeList = undefined;
	/* if( $rootScope.scopevalueArrays == undefined)
	 $rootScope.scopevalueArrays = [];
	 if( $rootScope.scopevalueArrays1 == undefined)
     $rootScope.scopevalueArrays1 = [];
     if( $rootScope.selectedimg == undefined)
     $rootScope.selectedimg = [];*/
	$rootScope.logout = "";
	$rootScope.name = "active";
	$rootScope.helpPage = "false";
	
/*	$rootScope.name = "active";
	$rootScope.name2 = "not-active";
	$rootScope.name3 = "not-active";
	if($rootScope.modTypes.value == "Automated without intervention")
	{
	$rootScope.name1 = "active1"; 
	$rootScope.name2 = "active1";
	}*/
	/*$rootScope.implTypelabel = "secondImplType";
	$rootScope.implTypelabel2 = "defaultImplType";
	$rootScope.implTypelabel3 = "defaultImplType";*/
    $scope.Choose = "Choose"
	$rootScope.fieldErrorMsg = "";
	$rootScope.fieldError = false;
	$scope.omId=$rootScope.projOmId;
	$scope.projectName=$rootScope.projectName;
	$rootScope.trModulewiseEnabled = false; 
	var noAuth = "false";
	var homeAuth="false";
	var resetAuth="false"
	$rootScope.languagePattern = "^[a-zA-Z]+$";
	$rootScope.msgErrorDisplay = false;

	//$rootScope.hierarchyTypes.value = "Business Process";
	var cookie = document.cookie;
	var cookieAuthParams = cookie.split(';');
	/*for (var cp1 = 0; cp1 < cookieAuthParams.length; cp1++) {*/
	/*	if (cookieAuthParams[cp1].split('=')[0].trim() == "configAuth" && cookieAuthParams[cp1].split('=')[1].trim() == "true") {
			noAuth = "true"
		}*/
		if ($rootScope.configAuth == "true") {
			noAuth = "true"
		}
		if ($rootScope.configInitial == "true") {
//			document.cookie = "configInitial=" + resetAuth + ";expires=" + myDate.toUTCString();
			 homeAuth = "true";
			 
		}
/*		if (cookieAuthParams[cp1].split('=')[0].trim() == "configInitial" && cookieAuthParams[cp1].split('=')[1].trim() == "true") {
//			document.cookie = "configInitial=" + resetAuth + ";expires=" + myDate.toUTCString();
			 homeAuth = "true";
			 
		}*/
	/*}*/
	
	if($rootScope.appValidity != undefined){
		if (noAuth == "false") {
			$location.path('/loginPage');
		}else if(homeAuth=="false"){
			$location.path('/configTilesPage');
		}
	}
	
//to get UserRole
/*	for (var cp2 = 0,arrLen = cookieAuthParams.length; cp2 < arrLen ; cp2++) {
		if (cookieAuthParams[cp2].split('=')[0].trim() == "userRole") {
			$scope.cookieUserRole=cookieAuthParams[cp2].split('=')[1].trim();
			//noAuth = "true"
		}
	}*/
	
	$scope.RetreiveScope = function(){
		
		var input = {}
		input.userId = $rootScope.username;
		input.omId = $rootScope.projOmId;
		input.implementationType = $rootScope.implType;
		input.sessionInputDTO = $rootScope.sessionInputObj;
		input.industryFlag= $rootScope.industryFlag;
		input.copyFlag =false;
		if($rootScope.industryFlag){
			input.industry=$rootScope.selectedIndustry;
			input.subIndustry=$rootScope.selectedsubIndustry;
		}
		var arrLen = 0;
		$http({
	        method: "POST",
	        url: "/" + servicePrefix + "/rest/scopeState/retriever",
	        data : input
		}).then(function(response) {
			 if(response.status === 200){
//				 console.log(response);
				 if(response.data.resMessageDto == serviceMessage){
			    		$rootScope.checkAuthorization();
			    	}
				 else{
			    		$rootScope.scopevalue="";
			    		var responsedata=[];
			    		var fileUploadStatusMsgArr = [];
			    		fileUploadStatusMsgArr.push("Config Template Not yet uploaded..");
			    		if(response.data.scopeSessionDto != null){
			    			for (var i = 0,arrLen = response.data.scopeSessionDto.imgScopeDto.length; i < arrLen ; i++) {
			    				var scopeData ={
		    			"imgId":response.data.scopeSessionDto.imgScopeDto[i].imgId,
	    		        "imgDescription":response.data.scopeSessionDto.imgScopeDto[i].imgDescription,
	    		        "sequence":response.data.scopeSessionDto.imgScopeDto[i].seqNo,
	    		        "indSeq":response.data.scopeSessionDto.imgScopeDto[i].indSeq,
	    		        "enabled":response.data.scopeSessionDto.imgScopeDto[i].enabled,
	    		        "fileName":"",
	    		        "filepath":"",
	    		        "isMasterData":response.data.scopeSessionDto.imgScopeDto[i].isMasterData,
	    		        "status":"fa fa-circle",
	    		        "implementationType":response.data.scopeSessionDto.implementationType,
	    		        "fileUploadStatusMsg":fileUploadStatusMsgArr,	    		        
	    		        "fileUploadedIcon" : "glyphicon glyphicon-remove",
	    		        "trType":response.data.scopeSessionDto.imgScopeDto[i].trType,
	    		        "customizingTr" : "",
   	    		        "workbenchTr" : "",
   	    		        "customizingTr_readOnly":true,
   	    		        "workbenchTr_readOnly":true,
   	    		        "customizingTr_mode":"",
   	    		        "workbenchTr_mode":"",
	    		        "seq":i+1,
	    		        "tranId":0,
	    		        "scopeExists":false,
	    		        "fileBytes":null
	    		        
		    		 } ;
	    		var scopeData1 ={
		    			"imgId":response.data.scopeSessionDto.imgScopeDto[i].imgId,
	    		        "imgDescription":response.data.scopeSessionDto.imgScopeDto[i].imgDescription,
	    		        "seq":i+1
	    		        
		    		 } ;
	    		
	    		$rootScope.selectedScopeData1.push(scopeData1);
	    		responsedata.push(scopeData);
	    		
	    		$rootScope.selectedScopeData.push(scopeData);
	    			    		
	    		var output = [], 
                keys = [];
	    		var collection = $rootScope.selectedScopeData;
	    		var keyname = "imgId";
	    		angular.forEach(collection, function(item) {
                var key = item[keyname];
                if(keys.indexOf(key) === -1) {
                    keys.push(key);
                    output.push(item);

	    		}
                $rootScope.selectedScopeData = output;
	    		});
//	    		console.log($rootScope.selectedScopeData.length);
	    		scopeData={};
	    	}
	    	for (var i = 0,arrLen = responsedata.length; i < arrLen ; i++) {
	    		 if(i == 0)
	          		  { 
	    			 		if($rootScope.hierarchyTypes.value == "IMG")
	    			 			$rootScope.scopevalue = $rootScope.scopevalue.concat(responsedata[i].imgId);
	    		        	else $rootScope.scopevalue = "";
					    	
					    	$rootScope.scopevalueArray.push(responsedata[i].imgId);
	    	
	          		  }
	    		 else{	
	    			 	if($rootScope.hierarchyTypes.value == "IMG")
	    			 	$rootScope.scopevalue = $rootScope.scopevalue.concat(";",responsedata[i].imgId);
	    			 	else $rootScope.scopevalue = "";
	    		    	$rootScope.scopevalueArray.push(responsedata[i].imgId);
	    		 }
	    	}
			}
			 }
			 }else {
//			        console.log("Error");
			    }
		});
	
	};
	
	$scope.initialPage = function(){

		$rootScope.tempValue =  undefined;
		$rootScope.impTypeChanged = true;
		$rootScope.downloadButtondisabled = true;
		$rootScope.sourcesystemEnabled = true;
	    $rootScope.modOptionsEnabled = true;
		$rootScope.modTypes = {
		   		 "value": "Automated with intervention", 
		   	     "values": ['Automated without intervention','Automated with intervention'] 
		       };
		 $rootScope.hvessourceSystem = {
		            "values": []
		        };
		noAuth="true";
		$rootScope.transactionID = 0;
		$rootScope.scopeTranId = 0;
		$rootScope.trgSystemDetails = [];
		$rootScope.hvesTargetSystemDetails = [];
		$rootScope.selectedTargetSystem = undefined;
		$rootScope.targetClientNo = "";
		$rootScope.targetSystem=[];
		$rootScope.sourceSystem=[];
		$rootScope.implType = "1";
		$rootScope.scopevalue = "";
		$rootScope.targetsystemEnabled = false;
//		$rootScope.modification = true;
		$rootScope.modification = false;
		$rootScope.modOptionsEnabled = true;
		$rootScope.list=[];
		//if( $rootScope.selectedimg == undefined)
		//$rootScope.selectedimg = [];
		if( $rootScope.Tempselectedimg == undefined)
			$rootScope.Tempselectedimg = [];
		//$rootScope.selectedIds = [];
		if($rootScope.allOmId == undefined)
		$rootScope.allOmId = [];
		$rootScope.scopevalueArrayid = [];
		$rootScope.selectedScopeData = [];
		$rootScope.selectedScopeData1 = [];
		$rootScope.scopevalueArray=[];
		$rootScope.scopevalueArrays=[];
		$rootScope.scopevalueArrays1=[];
		$rootScope.OmId = "";
		$rootScope.allfiles = [];
		$rootScope.FileList = [];
		$rootScope.downloadScopeList = [];
		$rootScope.files = [];
		
		/*For Wizard Text*/
		$rootScope.name = "active";
		$rootScope.name1  = "active1";
		$rootScope.name2  = "not-active";
		$rootScope.name3 = "not-active";
		
		/*For Wizard Steps/Circles*/
		$rootScope.wizard1  = "activewizard";
		$rootScope.wizard2  = "disablewizard";
		$rootScope.wizard3  = "applicablewizard";
		$rootScope.wizard4 = "applicablewizard";
		
		/*For radio butt0ns*/
		$rootScope.implTypelabel = "secondImplType";
		$rootScope.implTypelabel2 = "defaultImplType";
		$rootScope.implTypelabel3 = "defaultImplType";
		
		/*For Wizard small circles*/
		$rootScope.wizardDiv1 = "wizardcircleDivActive";
		$rootScope.wizardDiv2 = "wizardcircleDivDisable";
		$rootScope.wizardDiv3 = "wizardcircleDivApp";
    
    	$rootScope.tempTargetValue = "";
    	$rootScope.sourceValue = null;
    	$rootScope.srcSysClntNo="";//Added by Veena
    	//Hiding notification icon on First go and Displaying it if there is any new templates uploaded for that project
    	$rootScope.enableNotify = false;
    	$rootScope.imgDescrList = [];
    	$rootScope.msgErrorDisplay = false;
    	
    	$rootScope.selectedScopes = [];
	};
	
	

	$scope.selectedImpType = function(){
		
		
		$rootScope.scopevalue = "";

		$rootScope.impTypeChanged = false;
		$rootScope.selectedScopeData = [];
		$rootScope.FileList = [];
		$rootScope.scopevalueArray=[];
		$rootScope.selectedIds = [];
		
		$rootScope.targetSystem.value = undefined;
		$rootScope.sourceSystem.value = undefined;
		
		
		/*Execution Summary updation on chnage of ImplType -  Bugfix on 12th Mar*/
		$rootScope.tableCont = true;
		
		var configType = document.getElementsByName("configType");
		
		for(var i = 0,arrLen = configType.length; i < arrLen ; i++) {
			   if(configType[i].checked)
				   $rootScope.implType  = configType[i].value;
			 }
		if($rootScope.implType == "1" ){
			$rootScope.implTypelabel = "secondImplType";
			$rootScope.implTypelabel2 = "defaultImplType";
			$rootScope.implTypelabel3 = "defaultImplType";
		}else if($rootScope.implType == "2"){
			$rootScope.implTypelabel = "defaultImplType";
			$rootScope.implTypelabel2 = "secondImplType";
			$rootScope.implTypelabel3 = "defaultImplType";
		}else if($rootScope.implType == "3" ){
			$rootScope.implTypelabel = "defaultImplType";
			$rootScope.implTypelabel2 = "defaultImplType";
			$rootScope.implTypelabel3 = "secondImplType";
		}
		if($rootScope.hierarchyTypes.value == "IMG")
		$scope.RetreiveScope(); 

		if(  $rootScope.implType == "1"){//Green Field
			 $rootScope.modification = false;
			 $rootScope.modOptionsEnabled = true;
			 $rootScope.sourcesystemEnabled = true;
			 $rootScope.targetsystemEnabled = false;
			 $rootScope.radiomodel = "implType1";
			 $rootScope.radio = "configType1";
			 $rootScope.name1 = "not-active";
			 $rootScope.name2 = "not-active";
			 $rootScope.name3 = "not-active";
			 
			 $rootScope.wizard1  = "activewizard";
			 $rootScope.wizard2  = "applicablewizard";
			 $rootScope.wizard3  = "applicablewizard";
			 $rootScope.wizard4 = "applicablewizard";
			 
			 $rootScope.implTypelabel = "secondImplType";
			 $rootScope.implTypelabel2 = "defaultImplType";
			 $rootScope.implTypelabel3 = "defaultImplType";
			 
			 $rootScope.wizardDiv1 = "wizardcircleDivActive";
			 $rootScope.wizardDiv2 = "wizardcircleDivDisable";
			 $rootScope.wizardDiv3 = "wizardcircleDivApp";
		}else if( $rootScope.implType == "2" || $rootScope.implType == "3"){//Brown Field
						$rootScope.modification = true;
					 if($rootScope.modTypes.value == "Automated without intervention"){
						 $rootScope.modOptionsEnabled = true;
						 $rootScope.sourcesystemEnabled = false;
						 $rootScope.targetsystemEnabled = false;
						 $rootScope.name2 = "active1";
						 $rootScope.name1 = "active1";
						 $rootScope.name3 = "not-active";
						 $rootScope.wizard1  = "activewizard";
						 $rootScope.wizard2  = "disablewizard";
						 $rootScope.wizard3  = "disablewizard";
						 $rootScope.wizard4 = "applicablewizard";
						 
						 $rootScope.wizardDiv1 = "wizardcircleDivDisable";
						 $rootScope.wizardDiv2 = "wizardcircleDivDisable";
						 $rootScope.wizardDiv3 = "wizardcircleDivActive";
						 /*$rootScope.wizard2  = "wizard2";
						 $rootScope.wizard3  = "wizard2";
						 $rootScope.wizard4 = "wizard3";*/
											 
					 }
					 else if($rootScope.modTypes.value == "Automated with intervention" ){//Brown Field Modification
						 	$rootScope.modOptionsEnabled = true;
//						 	if( $rootScope.modOptions.value == "Download"){
								 $rootScope.sourcesystemEnabled = false;
								 $rootScope.targetsystemEnabled = false;	
								 $rootScope.name2 = "not-active";
								 $rootScope.name1 = "not-active";
								 $rootScope.name3 = "not-active";
								 
								 $rootScope.wizard1  = "activewizard";
								 $rootScope.wizard2  = "applicablewizard";
								 $rootScope.wizard3  = "applicablewizard";
								 $rootScope.wizard4 = "applicablewizard";
								 
								 $rootScope.wizardDiv1 = "wizardcircleDivActive";
								 $rootScope.wizardDiv2 = "wizardcircleDivApp";
								 $rootScope.wizardDiv3 = "wizardcircleDivApp";
								/* $rootScope.wizard2  = "wizard3";
								 $rootScope.wizard3  = "wizard3";
								 $rootScope.wizard4 = "wizard3";*/
//						 	}
//						 else if($rootScope.modOptions.value == "Upload"){
//							 $rootScope.sourcesystemEnabled = true;
//							 $rootScope.targetsystemEnabled = false;
//						}
				 }
		 
		 } 
			
	};
	   
	   
	   $scope.retrieveTargetDetails = function(){
		   
		   if($rootScope.targetSystem == undefined){
				$rootScope.targetSystem=[];
			}
		   var inputParam ={
					  systemType: "target",
					  omID: $rootScope.projOmId,
					  sessionInputDTO: $rootScope.sessionInputObj
			  }
		  /* $http({
               method: "GET",
               url: "/" + servicePrefix + "/rest/configSrv/getSourceTargetDetails/target/"+$rootScope.projOmId+"/"+$rootScope.username,
               headers:{
		            'authorization' :  $rootScope.userValidation.userToken
		            }
           })*/$http.post("/" + servicePrefix + "/rest/configSrv/getSourceTargetDetails", inputParam).then(function mySucces(response) {
               if (response.data.resMessageDto.message == "Success") {
                   var target = response.data.systemList;
                   $rootScope.targetSysData = response.data.systemList;
                   $rootScope.sapSrcClientNum = "";//Added by Veena
                   var result = [];
                   var result1 = [];
                   var hvesTargetSystem = [];
                   for (var i = 0,arrLen = target.length; i < arrLen ; i++) {	   
                       $rootScope.trgSystemDetails.push(target[i].destinationName);
                   }
                   $rootScope.targetSystem.values = result;
               }else if(response.data.resMessageDto.message == serviceMessage){
           		$rootScope.checkAuthorization();
           	}
           }, function myError(response) {
           });
	   };
	   
	   $scope.retrieveSourceDetails = function(){
		   if($rootScope.sourceSystem == undefined){
				$rootScope.sourceSystem=[];
			}
		   
		     /* $http({
	                method: "GET",
	                url: "/S4ConfigRPA/rest/configSrv/getSourceTargetDetails/SOURCE"
	            }).then(function mySucces(response) {
	                if (response.data.message == "SUCCESS") {
	                    var source = response.data.resSapSystemList;
	                    var result = [];
	                    for (var i = 0; i < source.length; i++) {
	                        result.push(source[i].destinationName);
	                    }
	                    $rootScope.sourceSystem.values = result;
	                }
	            }, function myError(response) {
	            });*/
		   
		   var inputParam ={
					  systemType: "source",
					  omID: $rootScope.projOmId,
					  sessionInputDTO: $rootScope.sessionInputObj
			  }
		  /* $http({
               method: "GET",
               url: "/" + servicePrefix + "/rest/configSrv/getSourceTargetDetails/source/"+$rootScope.projOmId+"/"+$rootScope.username,
               headers:{
		            'authorization' :  $rootScope.userValidation.userToken
		            }
           })*/$http.post("/" + servicePrefix + "/rest/configSrv/getSourceTargetDetails", inputParam).then(function mySucces(response) {
               if (response.data.resMessageDto.message == "Success") {
                   var source = response.data.systemList;
                   $rootScope.sourceSysData = response.data.systemList;
                   var result = [];
                   var hvesresult = [];
                   	 for (var i = 0,arrLen = source.length; i < arrLen ; i++) {
                           if(source[i].isHVESSystem == 1)
                           	
                           		hvesresult.push(source[i].destinationName);
                          else
                           	result.push(source[i].destinationName);
                            //          $rootScope.targetSystem.values.push(target[i].destinationName);
                        }
                   	 
                   	 $rootScope.sourceSystem.values = result; 
                   	 $rootScope.hvessourceSystem.values = hvesresult;
                   	// console.log($rootScope.hvessourceSystem.values);
                   
                   //for (var i = 0; i < source.length; i++) {
                    //   result.push(source[i].destinationName);
                       //          $rootScope.targetSystem.values.push(target[i].destinationName);
                  // }
                //   $rootScope.sourceSystem.values = result;
               }else if(response.data.resMessageDto.message == serviceMessage){
              		$rootScope.checkAuthorization();
              	}
           }, function myError(response) {
               //            $scope.userValidation = response.statusText;
           });
	   };
	   
	   $scope.retrieveIMGScopeData = function(){
		   
		   if($rootScope.list == undefined){
			   $rootScope.list =[];
//			   $rootScope.ScopeIMGList = [];
			}
		   
		   var imgPreviewInputDto = {
					  selectedOmid:$rootScope.projOmId,
	        		  sessionInputDTO: $rootScope.sessionInputObj
	              };
//		   $http.get("/S4ConfigRPA/rest/imgHierarchySrv/Hierarchy"+).then(function(response) {
		/*	   $http.post({
//			        method: "POST",
			        url: "/" + servicePrefix + "/rest/clientImgHierarchySrv/viewClientImgHierarchy/"+$rootScope.projOmId+"/"+$rootScope.username,
			        headers:{
			            'authorization' :  $rootScope.userValidation.userToken
			            }
			   }*/
	/*	   $http({
			   method: 'POST',
	        	url:"/" + servicePrefix + "/rest/imgHierarchySrv/viewImgHierarchy",
	        	data : $rootScope.sessionInputObj
		   })*/
		  // if($rootScope.hierarchyTypes.value == "Business Process"){
		   $http.post("/" + servicePrefix + "/rest/clientImgHierarchySrv/viewClientImgHierarchy/", imgPreviewInputDto).then(function(response) {   
	
			   if (response.status === 200) {
	        	   if(response.data.resMessageDto.message == serviceMessage){
	              		$rootScope.checkAuthorization();
	              	}
	        	
	           	var responseData=[];
	           	responseData.push(response.data);
	               $rootScope.list = responseData.slice();
	               $rootScope.imgDescrList = response.data.imgDescr;
	               if( $rootScope.list[0] == null ||  $rootScope.list[0] == ""){
	            	   $rootScope.isclienthierarchyexists = true;
	            	   $rootScope.isclienthierarchynotexists = false;
	            	   
	            	   $rootScope.overlay = document.getElementById("overlay");
	       		 	   $rootScope.popup = document.getElementById("busy");
	       		  	   if($rootScope.overlay != null){
	       		 	   $rootScope.overlay.style.display = "none";
	       		 	   $rootScope.popup.style.display = "none";
	       		  	   }
	               }
	               else{
	            	   $rootScope.isclienthierarchyexists = false;
	            	   $rootScope.isclienthierarchynotexists = true;
	            	   if($rootScope.overlay != null){
	            	   $rootScope.overlay.style.display = "none";
	            	   $rootScope.popup.style.display = "none";
	            	   }
	               }
	             
	               $rootScope.listData = responseData.slice();
	               $rootScope.ScopeIMGList = responseData.slice();
	               
	           /*	$http({
	                method: "POST",
	                url: "/" + servicePrefix + "/rest/HCPDocService/templateUpdateInfo/",
	                data: $rootScope.sessionInputObj
	                
	           	}).then(function(response) {
	    	        if (response.status === 200) {
	    	        	if(response.data != null){
	    	        		$rootScope.templateUpdateInfo = [];
	    	        		if(response.data.templateList != null)
	    	        			var length = response.data.templateList.length;
	    	        		else
	    	        			var length = 0;
	    	            	
	    	            	for(var i=0;i<length;i++){
	    	            		if($rootScope.imgDescrList.indexOf(response.data.templateList[i].imgDescr) != -1){
	    	            			$rootScope.enableNotify = true;
	    	            			$rootScope.templateUpdateInfo.push( response.data.templateList[i]);
	    	            		}
	    	            	}
	    	        	}
	    	        	else {
	    	        		$rootScope.enableNotify = false;
	    	        		overlay.style.display = "none";
	    	            	popup.style.display = "none";
	    	        	    	        	}
	    	        	}
	    	        	else {
	    	        		$rootScope.enableNotify = false;
	    	    	  	overlay.style.display = "none";
	    	      		popup.style.display = "none";
	    	        
	    	        	}
	           		});*/
	           } else {
		   
              // console.log("Error");
	           }
	       });
		  // }
		 /*  else if($rootScope.hierarchyTypes.value == "IMG" ){
		   $http.post("/" + servicePrefix + "/rest/clientImgHierarchySrv/viewClientImgHierarchy",imgPreviewInputDto).then(function(response) {   
	           if (response.status === 200) {
	        	   if(response.data.resMessageDto.message == serviceMessage){
	              		$rootScope.checkAuthorization();
	              	}
	        	
	           	var responseData=[];
	           	responseData.push(JSON.parse(response.data.resMessageDto.message));
	               $rootScope.list = responseData.slice();
	               $rootScope.imgDescrList = response.data.imgDescr;
	               if( $rootScope.list[0] == null ||  $rootScope.list[0] == ""){
	            	   $rootScope.isclienthierarchyexists = true;
	            	   $rootScope.isclienthierarchynotexists = false;
	            	   
	            	   $rootScope.overlay = document.getElementById("overlay");
	       		 	   $rootScope.popup = document.getElementById("busy");
	       		  	   if($rootScope.overlay != null){
	       		 	   $rootScope.overlay.style.display = "none";
	       		 	   $rootScope.popup.style.display = "none";
	       		  	   }
	               }
	               else{
	            	   $rootScope.isclienthierarchyexists = false;
	            	   $rootScope.isclienthierarchynotexists = true;
	            	   if($rootScope.overlay != null){
	            	   $rootScope.overlay.style.display = "none";
	            	   $rootScope.popup.style.display = "none";
	            	   }
	               }
	             
	               $rootScope.listData = responseData.slice();
	               $rootScope.ScopeIMGList = responseData.slice();
	               
	           	$http({
	                method: "POST",
	                url: "/" + servicePrefix + "/rest/HCPDocService/templateUpdateInfo/",
	                data: $rootScope.sessionInputObj
	                
	           	}).then(function(response) {
	    	        if (response.status === 200) {
	    	        	if(response.data != null){
	    	        		$rootScope.templateUpdateInfo = [];
	    	        		if(response.data.templateList != null)
	    	        			var length = response.data.templateList.length;
	    	        		else
	    	        			var length = 0;
	    	            	
	    	            	for(var i=0;i<length;i++){
	    	            		if($rootScope.imgDescrList.indexOf(response.data.templateList[i].imgDescr) != -1){
	    	            			$rootScope.enableNotify = true;
	    	            			$rootScope.templateUpdateInfo.push( response.data.templateList[i]);
	    	            		}
	    	            	}
	    	        	}
	    	        	else {
	    	        		$rootScope.enableNotify = false;
	    	        		overlay.style.display = "none";
	    	            	popup.style.display = "none";
	    	        	    	        	}
	    	        	}
	    	        	else {
	    	        		$rootScope.enableNotify = false;
	    	    	  	overlay.style.display = "none";
	    	      		popup.style.display = "none";
	    	        
	    	        	}
	           		});
	           } else {
		   
              // console.log("Error");
	           }  
		   });
		   }
		   */
	   };
	   
	   $scope.startImport = function(){
		   
			$scope.expandNodes = false;
			if(!$rootScope.isclienthierarchyexists){
				$rootScope.overlay = document.getElementById("overlay");
				$rootScope.popup = document.getElementById("busy");
				$rootScope.overlay.style.display = "block";
				$rootScope.popup.style.display = "inline-block";
			}
			
		 	//console.log($rootScope.overlay +"/"+$rootScope.popup);
		  /* $scope.Choose = "Loading, Please wait";
		   
			   $timeout(function(){
		            $scope.Choose = "Choose";
		        }, 1000);*/
		   $rootScope.createimg = true;
		   $rootScope.copy = false;
	    	$scope.hideErrorMsg();
	    	ngDialog.openConfirm({
	            template: 'view/treeViewData.html?ver='+version,
	            preCloseCallback:function(){
	            	
	            	if($rootScope.validClose == undefined){
	            		$rootScope.selectedScopeData = $rootScope.TempselectedTreeviewData;
	            		$rootScope.selectedimg = $rootScope.TempSelectedImg;
	   	       		 	$rootScope.scopevalue = "";
		   	       		 $rootScope.scopevalueArray=[];
		   	       		 var arrLen = $rootScope.selectedScopeData.length;
		   	       		 for(var x = 0; x < arrLen; x++){
		   	          		  //if($rootScope.selectedScopeData[x].enabled =="1"){
		   	          		  if(x == 0)
		   	          		  { 	
		   	          			  $rootScope.scopevalue = $rootScope.selectedScopeData[x].imgId;
		   	          			  $rootScope.scopevalueArray.push($rootScope.selectedScopeData[x].imgId);
		   	          		  }
		   	          		  else{
		   	          			  $rootScope.scopevalue = $rootScope.scopevalue.concat(";",$rootScope.selectedScopeData[x].imgId);
		   	          			  $rootScope.scopevalueArray.push($rootScope.selectedScopeData[x].imgId);
		   	          			  }
		   	          	  }
		   	          	  }
		   	       	else{
	            		$rootScope.validClose = undefined;
	            	}
	            	
	            }, 
	            controller:'ConfigScopeTreeView',
	            scope: $scope,
	            closeByDocument: false,
	            closeByEscape: false,
	            showClose: true,
	            height: 560,
	            width: 1146
	            
	        });
	    };
	    
	    $scope.hideErrorMsg = function() {
	       // $scope.fieldError = false;
	    	
   		 document.getElementById("idfielderror").style.display="none";

	    };
	/*
	    	$scope.homePage= function(){
	    		ngDialog.openConfirm({
		            template: 'view/config/confirm.html?ver='+version,		           
		            controller:'configTilesController',
		            scope: $scope,
		            closeByDocument: false,
		            closeByEscape: false,
		           showClose: false,
		           height: 200,
		            width: 400
		        });
	    		
	    		
	    	};*/
	   /* 	 $scope.okHomepage = function(){
	    		 $rootScope.tempValue =  undefined;
	    		 $rootScope.transactionID = 0;
	    		 $rootScope.initalCheck = undefined;
	    		 $rootScope.impTypeChanged = true;
	    		 $rootScope.downloadButtondisabled = true;
	    		 noAuth="true";
	    		 $rootScope.targetSystem=[];
	    		 $rootScope.sourceSystem=[];
	    		 $rootScope.trgSystemDetails = [];
	    		 $rootScope.hvesTargetSystemDetails = [];
	    		 $rootScope.selectedTargetSystem = undefined;
	    		 $rootScope.targetClientNo = "";
	    		 $rootScope.hvessourceSystem = {
	    		            "values": []
	    		        };
	    		$rootScope.implType=1;
	    		$rootScope.scopevalue = "";
	    		$rootScope.targetsystemEnabled = false;
	    		$rootScope.modification = false;
	    		$rootScope.list=[];
	    		$rootScope.ScopeIMGList = [];
	    		$rootScope.allfiles = [];
	    		$rootScope.FileList = [];
	    		$rootScope.files = [];
	    		$scope.executionFileSize = 0;
	    		$rootScope.downloadScopeList = [];
		    	$rootScope.scopevalueArray=[];
		    	$rootScope.scopevalueArrayid=[];
		        $rootScope.reportData = [];
		        
		        $rootScope.scopevalueArrays=[];
		        $rootScope.scopevalueArrays1=[];
		        if( $rootScope.selectedimg == undefined)
		        $rootScope.selectedimg = [];
		        if( $rootScope.Tempselectedimg == undefined)
			        $rootScope.Tempselectedimg = [];
		        
		        $rootScope.OmId= "";

	    		$location.path("/configTilesPage");
	    		 ngDialog.close();
	    	};*/
	    	
	    	/* $scope.cancelHome = function(){
	    		 ngDialog.close();
	    		 
	    	};*/
	    	

	 	   $scope.initalPageValidation = function () {
	 		  $rootScope.copytree = false;
	     	  $rootScope.executionLogsData = $rootScope.selectedScopeData;
	     	  if($rootScope.hierarchyTypes.value == "IMG"){
	 	 		 //$rootScope.selectedScopes = $rootScope.selectedScopeData;
	 	 		// $rootScope.uploadedScopes = $rootScope.selectedScopeData;
	 	 	  }else{
	 	 		$rootScope.selectedScopeData = $rootScope.selectedBPData; 
	 	 		// $rootScope.uploadedScopes = $rootScope.selectedBPData;
	 	 		 	  }
	 	    	$rootScope.fieldError = false;
	 	    	if($rootScope.implType == "1"){
	 	    		if($rootScope.selectedScopeData.length<=0 && $rootScope.hierarchyTypes.value == "IMG"){
	 		    		$rootScope.fieldErrorMsg = "select single Scope atleast";
	 			    	$rootScope.fieldError = true;
	 		    	}else if($rootScope.targetSystem.value == undefined){
	 		    		$rootScope.fieldError = true;
	 	    			$rootScope.fieldErrorMsg = "Choose Target System";
	 	    		}
	 		    	if($rootScope.selectedBPData.length <= 0 && $rootScope.hierarchyTypes.value == "Business Process"){
	 		    		$rootScope.fieldErrorMsg = "select single Scope atleast";
	 			    	$rootScope.fieldError = true;
	 		    	}
	 	    		
	 	    	}else if($rootScope.implType == "2"){
	 	    		//$rootScope.copyselectedScopeData = $rootScope.selectedScopeData;
	 	    		if( $rootScope.selectedScopeData.length<=0 && $rootScope.hierarchyTypes.value == "IMG"){
	 		    		$rootScope.fieldErrorMsg = "select single Scope atleast";
	 			    	$rootScope.fieldError = true;
	 		    	}
	 	    		if($rootScope.selectedBPData.length <= 0 && $rootScope.hierarchyTypes.value == "Business Process"){
	 		    		$rootScope.fieldErrorMsg = "select single Scope atleast";
	 			    	$rootScope.fieldError = true;
	 		    	}
	 	    		for(var i = 0,arrLen = $rootScope.sourceSysData.length;i < arrLen;i++)
	 	    			{
	 	    			if($rootScope.sourceSysData[i].destinationName == $rootScope.sourceSystem.value)
	 	    				{
	 	    					$rootScope.sourceValue = $rootScope.sourceSysData[i].id;
	 	    					$rootScope.srcSysClntNo = $rootScope.sourceSysData[i].sapClientNo; //Added by Veena client number
	 	    				}
	 	    			}
	 	    		
	 	    	if($rootScope.modTypes.value == "Automated without intervention" ){
	 	    		if($rootScope.sourceSystem.value == undefined ){
	 	    			$rootScope.fieldError = true;
	 	    			$rootScope.fieldErrorMsg = "Choose Source System";
	 	    		}/*else if($rootScope.targetSystem.value == undefined){
	 		    		$rootScope.fieldError = true;
	 	    			$rootScope.fieldErrorMsg = "Choose Target System";
	 	    		}*/
	 	    	}else if($rootScope.modTypes.value == "Automated with intervention"){ 
//	 		    			if($rootScope.modOptions.value == "Download"){
	 		    				if($rootScope.sourceSystem.value == undefined){
	 	    	    		
	 					    			$rootScope.fieldError = true;
	 					    			$rootScope.fieldErrorMsg = "Choose Source System";
	 		    						}}
//	 		    			else if($rootScope.modOptions.value == "Upload"){
	 		    				/*	if($rootScope.targetSystem.value == undefined){
	 						    		$rootScope.fieldError = true;
	 					    			$rootScope.fieldErrorMsg = "Choose Target System";
	 				    		}*/
//	 		    			}
//	 		    	}
	 	    	}
	 	    	else if($rootScope.implType == "3"){
		    		if($rootScope.selectedScopeData.length<=0 && $rootScope.hierarchyTypes.value == "IMG"){
		    		$rootScope.fieldErrorMsg = "select single Scope atleast";
			    	$rootScope.fieldError = true;
		    		}
		    		if($rootScope.selectedBPData.length <= 0 && $rootScope.hierarchyTypes.value == "Business Process"){
	 		    		$rootScope.fieldErrorMsg = "select single Scope atleast";
	 			    	$rootScope.fieldError = true;
	 		    	}
		    		for(var i = 0,arrLen = $rootScope.sourceSysData.length;i < arrLen;i++)
 	    			{
 	    			if($rootScope.sourceSysData[i].destinationName == $rootScope.sourceSystem.value)
 	    				{
 	    					$rootScope.sourceValue = $rootScope.sourceSysData[i].id;
 	    					$rootScope.srcSysClntNo = $rootScope.sourceSysData[i].sapClientNo; //Added by Veena client number
 	    				}
 	    			}
		    		
					if($rootScope.modTypes.value == "Automated without intervention" ){
			    		if($rootScope.sourceSystem.value == undefined ){
			    		
			    			$rootScope.fieldError = true;
			    			$rootScope.fieldErrorMsg = "Choose Source System";
			    		}
				    	/*else if($rootScope.targetSystem.value == undefined ){
				    		$rootScope.fieldError = true;
			    			$rootScope.fieldErrorMsg = "Choose Target System";
			    		}*/
			    	}
				    	else if($rootScope.modTypes.value == "Automated with intervention"){ 
				    		
				    				if($rootScope.sourceSystem.value == undefined ){
			    	    		
							    			$rootScope.fieldError = true;
							    			$rootScope.fieldErrorMsg = "Choose Source System";
				    						}
				    								    			/*	if($rootScope.targetSystem.value == undefined ){
							    		$rootScope.fieldError = true;
						    			$rootScope.fieldErrorMsg = "Choose Target System";
					    		}	*/
				    			
				    			/*else if($rootScope.modOptions.value == "Upload"){
				    					if($rootScope.targetSystem.value == undefined ){
								    		$rootScope.fieldError = true;
							    			$rootScope.fieldErrorMsg = "Choose Target System";
						    		}
				    			}*/
				    	}
				    	
    	}
	 	
	 	if(!$rootScope.fieldError) {
	 		//$rootScope.selectedScopeData  = $filter('orderBy')($rootScope.selectedScopeData, 'sequence')	
	 		/* $rootScope.selectedScopeData.sort(function(a, b) {
                 return a.sequence - b.sequence;
             });*/
	 	    	if($rootScope.implType == "1"){
	 	    		
	 	    		$rootScope.name = "not-active";
	 	    		$rootScope.name1 = "active1";
	 	    		$rootScope.name2 = "active";  
	 	    		$rootScope.name3 = "not-active";
	 	    		
	 	    		/*$rootScope.wizard1  = "wizard3";
		 	   		$rootScope.wizard2  = "wizard2";
		 	   		$rootScope.wizard3  = "wizard1";
		 	   		$rootScope.wizard4  = "wizard3";*/
	 	    		//$rootScope.homeicon = false;
	 	    			 	    		 
					 $rootScope.wizard1  = "donewizard";
					 $rootScope.wizard2  = "disablewizard";
					 $rootScope.wizard3  = "activewizard";
					 $rootScope.wizard4 = "applicablewizard";
					 
					 $rootScope.wizardDiv1 = "wizardcircleDivActive";
					 $rootScope.wizardDiv2 = "wizardcircleDivApp";
					 $rootScope.wizardDiv3 = "wizardcircleDivApp";
					 
	 	    		$rootScope.scenario = "Assisted Configuration";
	 	    		var myDate = new Date();
	 	            myDate.setHours(myDate.getHours() + 1);
	 	            $rootScope.fileUploadAuth = "true";
	 	            //$rootScope.configAuth = "false";
	 	           // document.cookie = "fileUploadAuth=" + $rootScope.fileUploadAuth + ";expires=" + myDate.toUTCString();
	 	            //document.cookie = "configAuth=" + $rootScope.configAuth + ";expires=" + myDate.toUTCString();
	 	            $location.path("/ConfigHeader/fileUpload");
	 	    	}else if($rootScope.implType == "2"){
	 		    			//$rootScope.homeicon = false;
	 		    			 if($rootScope.modTypes.value == "Automated with intervention"){
	 		    				$rootScope.name = "not-active";
	 			 	    		$rootScope.name1 = "active";
	 			 	    		$rootScope.name2 = "not-active";  
	 			 	    		$rootScope.name3 = "not-active";
	 			 	    		
	 			 	    		 $rootScope.wizard1  = "donewizard";
	 							 $rootScope.wizard2  = "activewizard";
	 							 $rootScope.wizard3  = "applicablewizard";
	 							 $rootScope.wizard4 = "applicablewizard";
	 							 
	 							 $rootScope.wizardDiv1 = "wizardcircleDivActive";
	 							 $rootScope.wizardDiv2 = "wizardcircleDivApp";
	 							 $rootScope.wizardDiv3 = "wizardcircleDivApp";
	 			 	    		
	 			 	    		/*$rootScope.wizard1  = "wizard3";
	 				 	   		$rootScope.wizard2  = "wizard1";
	 				 	   		$rootScope.wizard3  = "wizard3";
	 				 	   		$rootScope.wizard4  = "wizard3";*/
	 			    			$rootScope.scenario = "Installed Base with intervention";
	 			    			var myDate = new Date();
	 				            myDate.setHours(myDate.getHours() + 1);
	 				            $rootScope.executeAuth = "true";
	 				            $rootScope.fileDownloadAuth = $rootScope.executeAuth;
	 				           // document.cookie = "fileDownloadAuth=" + $rootScope.executeAuth + ";expires=" + myDate.toUTCString();
	 				            $location.path("/ConfigHeader/fileDownload");
	 				            }else{
				 				           	$rootScope.name = "not-active";
				 			 	    		$rootScope.name1 = "active1";
				 			 	    		$rootScope.name2 = "active1";  
				 			 	    		$rootScope.name3 = "active";
				 			 	    		
				 			 	    		 $rootScope.wizard1  = "donewizard";
				 							 $rootScope.wizard2  = "disablewizard";
				 							 $rootScope.wizard3  = "disablewizard";
				 							 $rootScope.wizard4 = "activewizard";
				 							 
				 							 $rootScope.wizardDiv1 = "wizardcircleDivActive";
				 							 $rootScope.wizardDiv2 = "wizardcircleDivApp";
				 							 $rootScope.wizardDiv3 = "wizardcircleDivApp";
				 			 	    		/*$rootScope.wizard1  = "wizard3";
				 				 	   		$rootScope.wizard2  = "wizard2";
				 				 	   		$rootScope.wizard3  = "wizard2";
				 				 	   		$rootScope.wizard4  = "wizard1";*/
	 	    			 	    			$rootScope.scenario = "Installed Base without intervention";
	 	    			 	    			 if($rootScope.hierarchyTypes.value == "IMG"){
	 		    			 	   	 	 		 //$rootScope.selectedScopes = $rootScope.selectedScopeData;
	 		    			 	   	 	 		 $rootScope.uploadedScopes = $rootScope.selectedScopeData;
	 		    			 	   	 	 	  }else{
	 		    			 	   	 	 		
	 		    			 	   	 	 		 $rootScope.uploadedScopes = $rootScope.selectedBPData;
	 		    			 	   	 	 		 	  }
	 	    			 	    			$scope.targetSysDialog(); 
	 				            		}
	 	    			}
	 	    	
	 	    	else if($rootScope.implType == "3"){
		    			//$rootScope.homeicon = false;
		    			 if($rootScope.modTypes.value == "Automated with intervention"){
		    				$rootScope.name = "not-active";
			 	    		$rootScope.name1 = "active";
			 	    		$rootScope.name2 = "not-active";  
			 	    		$rootScope.name3 = "not-active";
			 	    		
			 	    		 $rootScope.wizard1  = "donewizard";
							 $rootScope.wizard2  = "activewizard";
							 $rootScope.wizard3  = "applicablewizard";
							 $rootScope.wizard4 = "applicablewizard";
							 
							 $rootScope.wizardDiv1 = "wizardcircleDivActive";
							 $rootScope.wizardDiv2 = "wizardcircleDivApp";
							 $rootScope.wizardDiv3 = "wizardcircleDivApp";
			 	    		
			 	    		/*$rootScope.wizard1  = "wizard3";
				 	   		$rootScope.wizard2  = "wizard1";
				 	   		$rootScope.wizard3  = "wizard3";
				 	   		$rootScope.wizard4  = "wizard3";*/
			    			$rootScope.scenario = "IES with intervention";
			    			var myDate = new Date();
				            myDate.setHours(myDate.getHours() + 1);
				            $rootScope.executeAuth = "true";
				            $rootScope.fileDownloadAuth = $rootScope.executeAuth;
				           // document.cookie = "fileDownloadAuth=" + $rootScope.executeAuth + ";expires=" + myDate.toUTCString();
				            $location.path("/ConfigHeader/fileDownload");
				            }else{
		 				           	$rootScope.name = "not-active";
		 			 	    		$rootScope.name1 = "active1";
		 			 	    		$rootScope.name2 = "active1";  
		 			 	    		$rootScope.name3 = "active";
		 			 	    		
		 			 	    		 $rootScope.wizard1  = "donewizard";
		 							 $rootScope.wizard2  = "disablewizard";
		 							 $rootScope.wizard3  = "disablewizard";
		 							 $rootScope.wizard4 = "activewizard";
		 							 
		 							 $rootScope.wizardDiv1 = "wizardcircleDivActive";
		 							 $rootScope.wizardDiv2 = "wizardcircleDivApp";
		 							 $rootScope.wizardDiv3 = "wizardcircleDivApp";
		 			 	    		/*$rootScope.wizard1  = "wizard3";
		 				 	   		$rootScope.wizard2  = "wizard2";
		 				 	   		$rootScope.wizard3  = "wizard2";
		 				 	   		$rootScope.wizard4  = "wizard1";*/
	    			 	    			$rootScope.scenario = "IES without intervention";
	    			 	    			 if($rootScope.hierarchyTypes.value == "IMG"){
	    			 	   	 	 		 //$rootScope.selectedScopes = $rootScope.selectedScopeData;
	    			 	   	 	 		 $rootScope.uploadedScopes = $rootScope.selectedScopeData;
	    			 	   	 	 	  }else{
	    			 	   	 	 		
	    			 	   	 	 		 $rootScope.uploadedScopes = $rootScope.selectedBPData;
	    			 	   	 	 		 	  }
	    			 	    			$scope.targetSysDialog(); 
				            		}
	    			}
	 	    		}
	 	    	else{
	 	    		 document.getElementById("idfielderror").style.display="inline-block";
	 	    		 } 
	 	    	
	 	    if($rootScope.hierarchyTypes.value == "IMG"){
	 	    	if($rootScope.selectedScopeData.length <= 0 && $rootScope.selectedScopeData.length<=0){
		    		$rootScope.fieldErrorMsg = "select single Scope atleast";
			    	$rootScope.fieldError = true;
		    		}else{
		    			var arrayList  = [];
		    			  for (var i = 0; i < $rootScope.selectedScopeData.length; i++) {
		    				  arrayList.push($rootScope.selectedScopeData[i].imgId);
		                       
		                    }
		    			  var userConfigScopeDto ={
		    					  imgIdList: arrayList,
		    			  			omId: $rootScope.projOmId,
		    			  			userId:$rootScope.username,
		    			  			implementationType:$rootScope.implType,
		    			  			sessionInputDTO : $rootScope.sessionInputObj,
		    			  			copyFlag :false,
		    			  			industryFlag:$rootScope.industryFlag
		    			  			

		    			  	  };
		    	
		    			  $http.post("/" + servicePrefix + "/rest/scopeState/saver",userConfigScopeDto).then(function(response) {
		    			    	
		    			    if(response.status === 200){
		    			  } else {
		    			       // console.log("Error");
		    			    }
		    			}); 
		    		}
	 	    	}
	 	    };
	 	
	 	   
	 		$scope.targetSysDialog = function(){	
	 			$rootScope.copy = false;
			 	  ngDialog.openConfirm({
			 		  template:'view/config/trgSysSelection.html?ver='+version,
		              controller: 'trgSysSelectionController',
		              scope: $scope,
		              closeByDocument: false,
		              closeByEscape: false,
		              showClose: true,
		              height:"auto",
		              width: 400,
		              className:'ngdialog-theme-default CLASS_trgSys'
		          }).then(function() {
		             
		          });
		 		};
	 	   
	 	   
	    	if($rootScope.initalCheck == undefined && $rootScope.appValidity != undefined && $rootScope.copy == false && $rootScope.consolidate == false){
	    		$rootScope.initalCheck = true;
	    		$scope.initialPage();
	    		$scope.RetreiveScope(); 
	    		$scope.retrieveIMGScopeData();
	    		$scope.retrieveSourceDetails();
	    		$scope.retrieveTargetDetails();
	    		
	    	}
	    	
	    	 $rootScope.retrieveScopeTR = function(){
	      	  var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
	     	 var overlay = document.getElementById("overlay");
	         var popup = document.getElementById("busy");
	         overlay.style.display = "block";
	            busy.style.display = "inline-block";

	          /*  $mdDialog.show({
	                controller: function($scope, $mdDialog){
	                $scope.isLoading = true;
	                },
	                templateUrl: 'view/busy.html?ver='+version,
	                parent: angular.element(document.body),
	                clickOutsideToClose: false,
	                fullscreen: useFullScreen,
	                escapeToClose: false,
	            });*/
	      	  
	      	  var params = {
	      			 // selectedScopeArr : $rootScope.scopevalueArray,
	      			  selectedScopeList : $rootScope.selectedScopeData,
	      			  trOverride : $rootScope.trOverRide, 
	      				  omID : $rootScope.projOmId ,
	      				  systemId: $rootScope.targetValue,
	      				  sysFlag : $rootScope.sysFlag,
	      				sessionInputDTO: $rootScope.sessionInputObj,
	      				copyFlag : false,
	      				industryFlag:$rootScope.industryFlag
	      				
	      	  }
	          $http.post("/" + servicePrefix + "/rest/manageTR/retrieveScopeTR", params).then(function(response) {
	        	  var arrLen = 0;
	              if(response.status == 200){
	              		if(response.data != null){
	              	//	$mdDialog.cancel();
	              		var overlay = document.getElementById("overlay");
	              		var popup = document.getElementById("busy");
	              		overlay.style.display = "none";
	           	        popup.style.display = "none";

//	              		if(response.data.trModulewiseEnabled != null)
//	              		$rootScope.trModulewiseEnabled = response.data.trModulewiseEnabled;
	              		if(response.data.selectedScopeList != null){
	              			//$rootScope.selectedScopeData = response.data.selectedScopeList;
		              		$rootScope.executionLogsData = $rootScope.selectedScopeData;
		              		arrLen = $rootScope.executionLogsData.length;
		              		for(var i=0;i<arrLen;i++){
			              		$rootScope.executionLogsData[i].editwtricon = "editicon";
			              		$rootScope.executionLogsData[i].editktricon = "editicon";
			              		$rootScope.executionLogsData[i].editktrTR = "editTR";
			              		$rootScope.executionLogsData[i].editwtrTR = "editTR";
			              		$rootScope.selectedScopeData[i].workbenchTr = response.data.selectedScopeList[i].workbenchTr;
			              		$rootScope.selectedScopeData[i].workbenchTr_mode = response.data.selectedScopeList[i].workbenchTr_mode;
			              		$rootScope.selectedScopeData[i].customizingTr = response.data.selectedScopeList[i].customizingTr;
			              		$rootScope.selectedScopeData[i].customizingTr_mode = response.data.selectedScopeList[i].customizingTr_mode;
			              		$rootScope.selectedScopeData[i].customizingTr_readOnly = true;
			              		$rootScope.selectedScopeData[i].workbenchTr_readOnly = true;
			              		$rootScope.selectedScopeData[i].tranId = 0;
			              		$rootScope.executionLogsData[i].tranId = 0;
			              		$rootScope.selectedScopeData[i].tranId = 0;
			              		$rootScope.executionLogsData[i].tranId = 0;
			              		
		              			}
	              		}
	              		if($rootScope.implType == "1"){
	              			  
	                      	  $rootScope.selectedTargetSystem = $rootScope.targetName;

	                  	  } 
	                  	  var myDate = new Date();
	              	            myDate.setHours(myDate.getHours() + 1);
	              	            $rootScope.executeAuth = "true";
	              	            //$rootScope.configAuth = "false";
	              	           // document.cookie = "executeAuth=" + $rootScope.executeAuth + ";expires=" + myDate.toUTCString();
	              	            //document.cookie = "configAuth=" + $rootScope.configAuth + ";expires=" + myDate.toUTCString();
	              	    	if( $rootScope.copytree == true){
	              	    			
	              	    			$location.path("/ConfigHeader/CopyConfigExecute");
	              	    	}else {
	              	    		$location.path("/ConfigHeader/configExecute");
	              	    	}
	              	    //console.log(response.data);
	              	}else{
		            	  var overlay = document.getElementById("overlay");
		              		var popup = document.getElementById("busy");
		              		overlay.style.display = "none";
		           	        popup.style.display = "none";
		              	}
	              }
	              else{
	            	  var overlay = document.getElementById("overlay");
	              		var popup = document.getElementById("busy");
	              		overlay.style.display = "none";
	           	        popup.style.display = "none";
	              	}
	          });
	        };
	        
	        $rootScope.tempTargetValue = "";
	  	  	$rootScope.sysFlag = true;
	  	  	$rootScope.tempTargetValue = $rootScope.targetValue;
	        
	        $scope.getSystemId =  function(targetSystem,targetName){
	        	$rootScope.targetValue = targetSystem;
	        	$rootScope.targetName = targetName;
	        	var index = -1;
	        	
	        	if($rootScope.targetValue != $rootScope.tempTargetValue){
	        		  $rootScope.sysFlag = false;
	        	}
	        	for(var i=0; i<$rootScope.targetSysData.length;i++){
	        		if($rootScope.targetSysData[i].id == targetSystem){
	        			index =i;
	        		}
	        	}
	        	$rootScope.targetName = $rootScope.targetSysData[index].destinationName;
	        }; 
	        $rootScope.hidesapErrorMsg =  function(){
	        	document.getElementById("saperrormsg").style.display="none";
	        };
	        $scope.selectedHierarchyType = function(){
	        	$rootScope.hierarchyTypeEnabled = false;
	        	$scope.RetreiveScope();
	        };
	    	    	
}]);
 
