angular.module('yapp').controller('selectIndustry',["ngDialog","Upload","$scope","$rootScope","$http","$mdDialog","$mdMedia","$location","$filter","$state","Idle","$ocLazyLoad",function(ngDialog,Upload,$scope,$rootScope,$http,$mdDialog,$mdMedia,$location,$filter,$state,Idle,$ocLazyLoad,browser) {
	$ocLazyLoad.load(controllerName+'/config/selectIndustry.js?ver='+version);
	$ocLazyLoad.load(controllerName+'/config/ConfigHomePage.js?ver='+version);
	
	if($rootScope.appValidity == undefined){
		   $rootScope.username = "";
		    $rootScope.password = "";
		    var cookies = document.cookie.split(";");
		    for (var i = 0,arrLen = cookies.length; i < arrLen ; i++) {
		        var cookie = cookies[i];
		        var eqPos = cookie.indexOf("=");
		        var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
		        document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
		    }
		    $location.path('/loginPage');
	    
	}
	//Idle Time out Logic - Start

	
Idle.watch();

//Idle Time out Logic - End
$scope.openNav = function() {
	document.getElementById("upArrow").style.display = "inline-block";
	document.getElementById("mySidenav").style.display = "inline-block";
    document.getElementById("mySidenav").style.width = "230px";
    document.getElementById("downArrow").style.display = "none";
}
$scope.closeNav = function() {
	document.getElementById("upArrow").style.display = "none";
	document.getElementById("downArrow").style.display = "inline-block";
    document.getElementById("mySidenav").style.display = "none";
}
	$rootScope.downloadtempUser = false;
	$rootScope.importTemp = false;
	$rootScope.name1  = "active1";
	$rootScope.name2  = "not-active";
	$rootScope.name3 = "not-active";
	var noAuth = "false";
	var homeAuth = "true";
	if($rootScope.reportingTile == undefined)
	$rootScope.reportingTile = false;
	
	
	$rootScope.reportData = [];
	if($rootScope.allindustry == undefined)
		 $rootScope.allindustry = [];
	if($rootScope.allSubindustry == undefined)
		 $rootScope.allSubindustry = [];
	$rootScope.configTransactionData = [];
	$rootScope.userRole = "Config";
	 if($rootScope.scopevalueArrayid == undefined)
		 $rootScope.scopevalueArrayid =[];
	 if($rootScope.selectedid == undefined)	
			$rootScope.selectedid= [];
		if($rootScope.selectedid[0] == undefined)	
			$rootScope.selectedid[0] = [];
		$rootScope.fieldErrorMsg = "";
		$rootScope.fieldError = false;
		
		
			
		
	var myDate = new Date();
	   myDate.setHours(myDate.getHours() + 1);
		var cookie = document.cookie;
		var cookieAuthParams = cookie.split(';');
		for (var cp1 = 0,arrLen = cookieAuthParams.length; cp1 < arrLen ; cp1++) {
			/*if (cookieAuthParams[cp1].split('=')[0].trim() == "configAuth" && cookieAuthParams[cp1].split('=')[1].trim() == "true") {
				noAuth = "true"
			}*/
			if ($rootScope.configAuth == "true") {
				noAuth = "true"
			}
			if($rootScope.appValidity == undefined){
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userDetails") {
					$rootScope.userValidation = cookieAuthParams[cp1].split('=')[1];
					//console.log($rootScope.userValidation.role);
					
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userName") {
					$rootScope.username = cookieAuthParams[cp1].split('=')[1];
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userFirstName") {
					 $rootScope.userFirstName = cookieAuthParams[cp1].split('=')[1];
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userLastName") {
					$rootScope.userLastName = cookieAuthParams[cp1].split('=')[1];
				}
		  }
			
		}
		if (noAuth == "false") {
			$location.path('/loginPage');
		}
//		$rootScope.appValidity = true;//Browser Refresh
/*Hiding Page2(Deployment Info) initially on Notification pop up*/
		$rootScope.page2 = false;
/*Displaying the content of Page 2 on click on next button	*/
$rootScope.nextpage = function(){
			$rootScope.page2 =  true;
			$rootScope.activePage = "previous";
			$rootScope.nonactivePage = "next";
		}
$rootScope.previouspage = function(){
	$rootScope.page2 =  false;
	$rootScope.activePage = "next";
	$rootScope.nonactivePage = "previous";
}
/*Two pages - dynamic classes on notification Pop up*/
$rootScope.activePage = "next";
$rootScope.nonactivePage = "previous";

/*$scope.logout = function(){
		ngDialog.close();
        $state.transitionTo('loginPage');
        $rootScope.username = "";
        $rootScope.password = "";
       // $scope.deleteAllCookies();
        $rootScope.sapUserID = "";
    	$rootScope.sapPassword = "";
        $rootScope.adminAuth  = "";

        $rootScope.fileUploadAuth = "";
        $rootScope.executeAuth = "";
        $rootScope.configAuth = "";
        $rootScope.fileDownloadAuth = "";
        ngDialog.close(); 
        	 

    }*/
	$scope.changePassword = function(){
  		if(document.getElementById("upArrow") !=  null){
  		document.getElementById("upArrow").style.display = "none";
  		document.getElementById("downArrow").style.display = "inline-block";
  	    document.getElementById("mySidenav").style.display = "none";
  		}
  		ngDialog.openConfirm({
	            template: 'view/managePassword/changePassword.html?ver='+version,
	            scope: $scope,
	            closeByDocument: false,
	            closeByEscape: false,
	            showClose: false,
	            height: 410,
	            width: 560,
	           className:'ngdialog-theme-default CLASS_projName'
	        });  		
  	};
if( $rootScope.userValidation != undefined && $rootScope.userValidation.default_p == 'Y'){
	 $scope.changePassword();
}
else if($rootScope.secQAUpdated == false &&  $rootScope.isLoginAgain == true) {
 /*   $http.post("/" + servicePrefix + "/rest/adminSrv/getSecurityQuestions/").then(function executeSuccess(response) {
    	
    	if( response.data.resMessageDto.msgType == "Success"){
    	$rootScope.securityQAList = response.data.quesListDto;
    	}
    	else{
    		
    	}
    });*/
	 $rootScope.isLoginAgain = false;
	ngDialog.openConfirm({
        template: 'view/managePassword/setUpSecurityQA.html?ver='+version,
     // controller : 'LoginPageController',
        scope: $scope,
        closeByDocument: false,
        closeByEscape: false,
        showClose: true,
        height: 445,
        width: 500,
       className:'ngdialog-theme-default CLASS_projName'
    	})
    }

$scope.initalPageValidation = function(selectedIndustry,selectedsubIndustry){
	$rootScope.selectedIndustry = selectedIndustry;
	$rootScope.selectedsubIndustry = selectedsubIndustry;
	
	$rootScope.fieldError = false;
	if($rootScope.selectedIndustry ==undefined ){
 		$rootScope.fieldErrorMsg = "Select industry";
	    	$rootScope.fieldError = true;
 	}
 	else if($rootScope.selectedsubIndustry==undefined ){
 		$rootScope.fieldError = true;
		$rootScope.fieldErrorMsg = "Select sub Industry";	
 	}
	if(!$rootScope.fieldError) {
		$location.path("/configTilesPage");
		$scope.getIndustryAlias();
		ngDialog.close();
		
	}
	else{
		 document.getElementById("idfielderrorind").style.display="inline-block";
		 } 
	
	
}

$scope.getIndustryAlias = function(){

    	   
	    var params={
	    		industry:$rootScope.selectedIndustry,
	             subIndustry:$rootScope.selectedsubIndustry,
	             userRole : $rootScope.userRole,
	            sessionInputDTO: $rootScope.sessionInputObj 
	        }; 
   
       $http.post("/" + servicePrefix + "/rest/autoConfigSrv/getIndustryAlias",params).then(function(response) {
		    
  		 if(response.status === 200){
		    	  if(response.data != null){
		    		  
		    		  	  $rootScope.aliasIndustry = response.data.aliasIndustry;
			    		  $rootScope.aliasSubIndustry = response.data.aliasSubIndustry;
			    	  }
		    }
		}); 
   
}
$scope.hideErrorMsg = function() {
    // $scope.fieldError = false;
 	
	 document.getElementById("idfielderrorind").style.display="none";

 };



/*$scope.homePage= function(){
	 if($rootScope.overlay != null){
	 	   $rootScope.overlay.style.display = "none";
	 	   $rootScope.popup.style.display = "none";
	  	   }
	 ngDialog.openConfirm({
        template: 'view/config/confirm.html?ver='+version,		           
        //controller:'configTilesController',
        scope: $scope,
        closeByDocument: false,
        closeByEscape: false,
       showClose: false,
       height: 200,
        width: 527,
        className:'ngdialog-theme-default CLASS_projName'
    });
	 $scope.okHomepage = function(){
		 $rootScope.disable = "enable";
		$location.path("/IndustryType");
		 ngDialog.close();
	};
	
		
	};*/
	
	$rootScope.cancelHome = function(){
		 ngDialog.close();
		 
	};
		

var params={
        userID: $rootScope.username,
        userRole: $rootScope.userRole,
        sessionInputDTO: $rootScope.sessionInputObj 
    };


$rootScope.createimg = true;
$rootScope.clienthierarchydiv = true;
$rootScope.IMGHierarchyMsg = "CREATE IMG HIERARCHY";

$rootScope.isManagetemplate = false;
var industryArr = 0;
if($rootScope.masterTreeResponse == undefined)
	$rootScope.masterTreeResponse = [];

 $http.post("/" + servicePrefix + "/rest/clientImgHierarchySrv/getIndustry",params).then(function(response) {
    
	 if(response.status === 200){
    	  if(response.data!= null){
    		  	  $rootScope.allindustry = []; 
    		  	  
	    		  $rootScope.allindustry = response.data.indDetails;
	    		  
	    	  }else
    		  	 $rootScope.allindustry = []; 
    		  	 $rootScope.Industry = [];
    	  }
	
    
}); 


 
 $scope.getScopeData = function(selectedIndustry){
	 
	 var params1={
			 industry:selectedIndustry,
			 userRole: $rootScope.userRole,
		     sessionInputDTO: $rootScope.sessionInputObj 
		};
	

	 $http.post("/" + servicePrefix + "/rest/clientImgHierarchySrv/getSubIndustry",params1).then(function(response) {
		 
		    
		 if(response.status === 200){
	    	  if(response.data!= null){
	    		  	  $rootScope.allSubindustry = []; 
		    		  $rootScope.allSubindustry = response.data.indDetails;
		    		  
		    	  }else{
	    		  	 $rootScope.allSubindustry = []; 
	    		  	 
	    	  }
	    }
		 
	 
	}); 
	 
	 }
 
 
}]);
		    