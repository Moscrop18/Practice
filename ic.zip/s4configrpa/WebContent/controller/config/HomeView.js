angular.module('yapp').controller('HomeCtrl',['$scope','$rootScope','$http','$mdDialog','$mdMedia','$ocLazyLoad',function($upload,$scope,$rootScope,$http,$mdDialog,$mdMedia,$ocLazyLoad) {
	$ocLazyLoad.load(controllerName+'/config/HomeView.js?ver='+version);
	//Browser Refresh - 13 Nov 2017
	if($rootScope.appValidity == undefined){
		   $rootScope.username = "";
		    $rootScope.password = "";
		   /* var cookies = document.cookie.split(";");
		    for (var i = 0,arrLen = cookies.length; i < arrLen ; i++) {
		        var cookie = cookies[i];
		        var eqPos = cookie.indexOf("=");
		        var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
		        document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
		    }*/
		    $location.path('/loginPage');
	    
	}
    $scope.filePath = [];
    $rootScope.executionLogData = 0;
    $scope.isSuccess = false;
    $scope.test = 1;
    $scope.isSourceDisabled = true;
    $scope.noTextVisibility=true;
    $scope.startButton = true;
    $scope.uploadVisibility = false;
    $scope.customiseValue = '';
    $scope.prop = {   "type": "select", 
        "name": "Service",
        "value": "--Select--", 
        "values": ['--Select--','JCoSrcDemoSystem','JCoDemoSystem'] 
    };
    $scope.target = {   "type": "select", 
        "name": "Service",
        "value": "--Select--", 
        "values": ['--Select--','JCoDemoSystem']
    };

    // FILTERS
    // a sync filter
//    uploader.filters.push({
//        name: 'syncFilter',
//        fn: function(item, options) {
//            console.log('syncFilter');
//            return this.queue.length < 10;
//        }
//    });
  
    // an async filter
//    uploader.filters.push({
//        name: 'asyncFilter',
//        fn: function(item , options, deferred) {
//            console.log('asyncFilter');
//            setTimeout(deferred.resolve, 1e3);
//        }
//    });
    $scope.changeTipoAcesso = function(value){
        $scope.target.value = '--Select--';
        $scope.prop.value = '--Select--';
        $rootScope.executionLogData = 0;
        $rootScope.executionStatusData = 0;
        $scope.customiseValue = '';
        $scope.myFile = null;
        if(value == 2){
            $scope.isSourceDisabled = false;
            $scope.startButton = false;
            $scope.uploadVisibility = true;
        }else{
            $scope.isSourceDisabled = true;
            $scope.startButton = true;
            $scope.uploadVisibility = false;
        }
         console.log(value);
    };
    $scope.selectFile=function(){
    alert('welcome');   
    };
    $scope.startTransformation = function(){
        if($scope.customiseValue != '' && $scope.target.value != '--Select--' && $scope.prop.value != '--Select--'){
            $scope.callServlet('BrownField',$scope.prop.value,''); 
        }else{
        $mdDialog.show(
                $mdDialog.alert()
                .parent(angular.element(document.querySelector('#popupContainer')))
                .clickOutsideToClose(true)
                .title('Information!')
                .textContent('Please enter customising activity field and select source/target system')
                .ariaLabel('Alert Dialog Demo')
                .ok('Ok')
            );
        }
    };

    $scope.callServlet = function(implType,srcDest,allfiles,files){
        var uploadUrl = "/S4_Func_Conf_AutomationV2/ExecuteAutomation";
        var Indata = {implType:implType,srcDest:srcDest,tgtDest:$scope.target.value}
        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
        $mdDialog.show({
            controller: function($scope, $mdDialog){
            $scope.isLoading = true;
            },
            templateUrl: 'view/busy.html?ver='+version,
            parent: angular.element(document.body),
            clickOutsideToClose: false,
            fullscreen: useFullScreen,
            escapeToClose: false,
        })
        .then(function(answer) {
        }, function() {
        });
        if(implType==='BrownField'){
            $http.post(uploadUrl,allfiles, {
                transformRequest: angular.identity,
                headers: {'Content-Type': undefined},
                params: Indata
            }).then(function(responseData){
                $scope.responseMethod(responseData,implType);
            }) ,(function(data){
             $scope.errorResponse(data);
            });
        }else{
            files.upload = $upload.upload({
                method: 'POST',
                url:         uploadUrl,
                data:      {files: allfiles},
                params: Indata
            });
            files.upload.then(function(responseData) {
                $scope.responseMethod(responseData,implType);
            }, function (data) {
                $scope.errorResponse(data);
            });
        }
    };

    $scope.uploadFiles = function (files) {
        $scope.noTextVisibility=false;
        var allfiles=[];
        var uploadUrl = "/S4_Func_Conf_AutomationV2/ExecuteAutomation";
        if (files && files.length) {
            for (var i = 0,arrLen = files.length; i < arrLen ; i++) {
               allfiles.push(files[i]); 
            }
        }    
        $rootScope.executionLogData = 0;
        $scope.isSuccess = true;
        if($scope.target.value != '--Select--'){
            var uploadUrl = "/S4_Func_Conf_AutomationV2/ExecuteAutomation";             
            var Indata = {implType:'GreenField',srcDest:'',tgtDest:$scope.target.value}
            $scope.callServlet('GreenField','',allfiles,files); 
        }else{
            $scope.isSuccess = false;
            $mdDialog.show(
            $mdDialog.alert()
            .parent(angular.element(document.querySelector('#popupContainer')))
            .clickOutsideToClose(true)
            .title('Information!')
            .textContent('Please select target system')
            .ariaLabel('Alert Dialog Demo')
            .ok('Ok')
            );
        }
    }

    $scope.responseMethod = function(responseData,implType){
        $mdDialog.cancel();
        var data,resData;
        if(implType==='BrownField'){
         data = responseData.UploadConfigStatus;
         resData = responseData.ResHeaderStatus;
        }else{
        	 data = responseData.data.UploadConfigStatus;
        	 resData = responseData.data.ResHeaderStatus;
        }
        for(var i=0,arrLen = data.length;i< arrLen ;i++){
            if(data[i].messageType == 'N'){
                data[i].iconType = "glyphicon glyphicon-ok";
            }else if(data[i].messageType == 'E'){
                data[i].iconType = "glyphicon glyphicon-question-sign";
            }else if(data[i].messageType == 'F'){
                data[i].iconType = "glyphicon glyphicon-ban-circle";
            }else if(data[i].messageType == 'A'){
                data[i].iconType = "glyphicon glyphicon-scissors";
            }else if(data[i].messageType == 'W'){
                data[i].iconType ="glyphicon glyphicon-warning-sign";
            }else if(data[i].messageType == 'I'){
                data[i].iconType = "glyphicon glyphicon-info-sign";
            }else if(data[i].messageType == 'S'){
                data[i].iconType = "glyphicon glyphicon-check";
            } else{
                data[i].description = data[i].messageType;
                data[i].errorType = "Error";
                data[i].iconType = "glyphicon glyphicon-question-sign"; 
            } 
        }
        $rootScope.executionLogData = data;
//        var resData = responseData.ResHeaderStatus;
        var status1,status2,status3,status4;
        if(resData.srcConnectionStatus){
            status1 = 'glyphicon glyphicon-ok';
        }else{
            status1 = 'glyphicon glyphicon-remove';
        }
        if(resData.dstConnectionStatus){
            status2 = 'glyphicon glyphicon-ok';
        }else{
            status2 = 'glyphicon glyphicon-remove';
        }
        if(resData.srcExecutionStatus){
            status3 = 'glyphicon glyphicon-ok';
        }else{
            status3 = 'glyphicon glyphicon-remove';
        }
        if(resData.dstExecutionStatus){
            status4 = 'glyphicon glyphicon-ok';
        }else{
            status4 = 'glyphicon glyphicon-remove';
        }
        if(implType == "BrownField"){
            $rootScope.executionStatusData = [{
                task: 'Source Connection',
                status: status1
            },{
                task: 'Source Execution',
                status: status3
            },{
                task: 'Destination Connection',
                status: status2
            },{
                task: 'Destination Execution',
                status: status4
            }];
        }else{
        $rootScope.executionStatusData = [{
                task: 'Destination Connection',
                status: status2
            },{
                task: 'Destination Execution',
                status: status4
            }];
        }  
    }
    
    $scope.errorResponse = function(data){
        $mdDialog.cancel();
        $mdDialog.show(
            $mdDialog.alert()
            .parent(angular.element(document.querySelector('#popupContainer')))
            .clickOutsideToClose(true)
            .title('Information!')
            .textContent(data)
            .ariaLabel('Alert Dialog Demo')
            .ok('Ok')
        );
    }
    
    $scope.fileSelect = function(){
    	 $rootScope.executionLogData = 0;
         $rootScope.executionStatusData = 0;
         $scope.customiseValue = '';
    }
    
    $scope.uploadExcelFiles = function (files) {
        $scope.noTextVisibility=false;
        var allfiles=[];
        if (files && files.length) {
            for (var i = 0,arrLen = files.length; i < arrLen ; i++) {
               allfiles.push(files[i]); 
            }
        }    
        $rootScope.executionLogData = 0;
        $scope.isSuccess = true;
        if($scope.target.value != '--Select--'){
//            var Indata = {implType:'GreenField',srcDest:'',tgtDest:$scope.target.value}
            $scope.callUpload(allfiles,files); 
        }else{
            $scope.isSuccess = false;
            $mdDialog.show(
            $mdDialog.alert()
            .parent(angular.element(document.querySelector('#popupContainer')))
            .clickOutsideToClose(true)
            .title('Information!')
            .textContent('Please select target system')
            .ariaLabel('Alert Dialog Demo')
            .ok('Ok')
            );
        }
    }  
    
    $scope.callUpload = function(allfiles,files){
        var uploadUrl = "/" + servicePrefix + "/rest/files/multipleUpload/";
//        var Indata = {implType:implType,srcDest:srcDest,tgtDest:$scope.target.value}
        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
        $mdDialog.show({
            controller: function($scope, $mdDialog){
            $scope.isLoading = true;
            },
            templateUrl: 'view/busy.html?ver='+version,
            parent: angular.element(document.body),
            clickOutsideToClose: false,
            fullscreen: useFullScreen,
            escapeToClose: false,
        })
        .then(function(answer) {
        }, function() {
        });
     
            files.upload = Upload.upload({
                method: 'POST',
                url:         uploadUrl,
                data:      {files: allfiles}
//                params: Indata
            });
            files.upload.then(function(responseData) {
                $scope.fileUploadSuccess(responseData);
            }, function (data) {
                $scope.fileUploaderror(data);
            });
        
    };
    
    $scope.fileUploadSuccess = function(responseData){
        $mdDialog.cancel();
        var data;
        data = responseData.data.filenameList;
        for(var i=0,arrLen = data.length;i< arrLen ;i++){
        	$scope.filePath.push(data[i]); 
        }
    }
    
    $scope.fileUploaderror = function(data){
        $mdDialog.cancel();
        $mdDialog.show(
            $mdDialog.alert()
            .parent(angular.element(document.querySelector('#popupContainer')))
            .clickOutsideToClose(true)
            .title('Information!')
            .textContent(data)
            .ariaLabel('Alert Dialog Demo')
            .ok('Ok')
        );
    }
    
    $scope.uploadConfig = function () {
        $scope.noTextVisibility=false;
        $rootScope.executionLogData = 0;
        $scope.isSuccess = true;
        if($scope.target.value != '--Select--'){
            var Indata = {implType:'GreenField',srcDest:'',tgtDest:$scope.target.value,filePath:$scope.filePath}
            $scope.executeService('GreenField',''); 
        }else{
            $scope.isSuccess = false;
            $mdDialog.show(
            $mdDialog.alert()
            .parent(angular.element(document.querySelector('#popupContainer')))
            .clickOutsideToClose(true)
            .title('Information!')
            .textContent('Please select target system')
            .ariaLabel('Alert Dialog Demo')
            .ok('Ok')
            );
        }
    }
    
    
    $scope.executeService = function(implType,srcDest){
    	var uploadUrl = "/" + servicePrefix + "/rest/S4Config/uploadConfiguration/";
//    	var uploadUrl = "/" + servicePrefix + "/rest/S4Config/uploadConfiguration/"+implType+"/"+srcDest+"/"+$scope.target.value+"/"+$scope.filePath;
        var Indata = {implType:implType,srcDest:srcDest,tgtDest:$scope.target.value,filePath:$scope.filePath}
        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
        $mdDialog.show({
            controller: function($scope, $mdDialog){
            $scope.isLoading = true;
            },
            templateUrl: 'view/busy.html?ver='+version,
            parent: angular.element(document.body),
            clickOutsideToClose: false,
            fullscreen: useFullScreen,
            escapeToClose: false,
        })
        .then(function(answer) {
        }, function() {
        });
       
        	 $http.post(uploadUrl,{
                 transformRequest: angular.identity,
                 headers: {'Content-Type': undefined,'implType':implType,'srcDest':srcDest,'tgtDest':$scope.target.value,'filePath':$scope.filePath},
//                 params: Indata
                 data: Indata
             }).then(function(responseData){
                 $scope.responseMethod(responseData,implType);
             }) ,(function(data){
              $scope.errorResponse(data);
             });
        
    };
    
    
}]);