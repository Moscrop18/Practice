angular.module('yapp').controller('trgSysSelectionController',["ngDialog","Upload","$scope","$rootScope","$http","$mdDialog","$mdMedia","$location","$filter","$state","$ocLazyLoad", function(ngDialog,Upload,$scope,$rootScope,$http,$mdDialog,$mdMedia,$location,$filter,$state,$ocLazyLoad) {
	
	//Browser Refresh - 13 Nov 2017
	if($rootScope.appValidity == undefined){
		   $rootScope.username = "";
		    $rootScope.password = "";
		   /* var cookies = document.cookie.split(";");
		    for (var i = 0,arrLen = cookies.length; i < arrLen ; i++) {
		        var cookie = cookies[i];
		        var eqPos = cookie.indexOf("=");
		        var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
		        document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
		    }*/
		    $location.path('/loginPage');
	    
	}
	  $rootScope.tempTargetValue = "";
	  $rootScope.sysFlag = true;
	  $rootScope.tempTargetValue = $rootScope.targetValue;
	  
      $scope.targetSelection = function(trgsystem,event) {
    	  ngDialog.close();
    	  $rootScope.selectedTargetSystem = trgsystem;
    	  /*console.log(trgsystem);
    	  console.log( $rootScope.targetSysData);*/
    	  var index =-1;
    	  for(var i = 0,arrLen = $rootScope.targetSysData.length; i< arrLen ; i++){
    		  if( $rootScope.targetSysData[i].destinationName==trgsystem){
    			   index =i;
    		  }
    	  }
    	  $rootScope.targetValue =  $rootScope.targetSysData[index].id; 
    	  /*if($rootScope.tempTargetValue == ""){
     	  	 $rootScope.tempTargetValue = $rootScope.targetValue;
     	  }*/
    	  //angular.copy($rootScope.targetValue,$rootScope.tempTargetValue);
    	  //console.log($rootScope.targetValue);
    	 // console.log($rootScope.tempTargetValue);
    	  if($rootScope.targetValue != $rootScope.tempTargetValue){
    		  $rootScope.sysFlag = false;
    	  }
    	 if($rootScope.copy == true){
    	  $rootScope.retrieveScopeTRForCopy();
    	 }else{
    		 $rootScope.retrieveScopeTR();
    	 }
    	
    	  /*else if($rootScope.implType == "2" || $rootScope.implType == "3"){
    		  if($rootScope.modTypes.value == "Automated with intervention"){
    			  var myDate = new Date();
  	            myDate.setHours(myDate.getHours() + 1);
  	            $rootScope.executeAuth = "true";
  	            //$rootScope.configAuth = "false";
  	            document.cookie = "executeAuth=" + $rootScope.executeAuth + ";expires=" + myDate.toUTCString();
  	            //document.cookie = "configAuth=" + $rootScope.configAuth + ";expires=" + myDate.toUTCString();
  	    		$location.path("/ConfigHeader/configExecute");
    		  }else{
    			  var myDate = new Date();
    	           myDate.setHours(myDate.getHours() + 1);
    	           $rootScope.executeAuth = "true";
    	           //$rootScope.configAuth = "false";
    	           document.cookie = "executeAuth=" + $rootScope.executeAuth + ";expires=" + myDate.toUTCString();
    	           $location.path("/ConfigHeader/configExecute");
    		  } 
    	  }*/
    	  
        };
  /*    $scope.retrieveScopeTR = function(){
    	  var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
          $mdDialog.show({
              controller: function($scope, $mdDialog){
              $scope.isLoading = true;
              },
              templateUrl: 'view/busy.html?ver='+version,
              parent: angular.element(document.body),
              clickOutsideToClose: false,
              fullscreen: useFullScreen,
              escapeToClose: false,
          });
    	  
    	  var params = {
    			  
    			  selectedScopeList : $rootScope.selectedScopeData,
    			  trOverride : $rootScope.trOverRide, 
    				  omID : $rootScope.projOmId 
    	  }
        $http.post("/" + servicePrefix + "/rest/manageTR/retrieveScopeTR", params).then(function(response) {
            if(response.status == 200){
            	if(response.data != null){
            		$mdDialog.cancel();
            		$rootScope.selectedScopeData = response.data;
            		$rootScope.executionLogsData = $rootScope.selectedScopeData;
            		for(var i=0;i<$rootScope.executionLogsData.length;i++){
            		$rootScope.executionLogsData[i].editwtricon = "editicon";
            		$rootScope.executionLogsData[i].editktricon = "editicon";
            		$rootScope.executionLogsData[i].editktrTR = "editTR";
            		$rootScope.executionLogsData[i].editwtrTR = "editTR";
            		}
            		  if($rootScope.implType == "1"){
                    	  $rootScope.selectedTargetSystem = $rootScope.targetSystem.value;

                	  } 
                	  var myDate = new Date();
            	            myDate.setHours(myDate.getHours() + 1);
            	            $rootScope.executeAuth = "true";
            	            //$rootScope.configAuth = "false";
            	            document.cookie = "executeAuth=" + $rootScope.executeAuth + ";expires=" + myDate.toUTCString();
            	            //document.cookie = "configAuth=" + $rootScope.configAuth + ";expires=" + myDate.toUTCString();
            	    		$location.path("/ConfigHeader/configExecute");
            	    		
            		console.log(response.data);
            	}
            	
            	
            }
	 	   
        });
      }*/
}]);