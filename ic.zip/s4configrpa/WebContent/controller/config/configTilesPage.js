angular.module('yapp').controller('configTilesController',["ngDialog","Upload","$scope","$rootScope","$http","$mdDialog","$mdMedia","$location","$filter","$state","Idle","$ocLazyLoad",function(ngDialog,Upload,$scope,$rootScope,$http,$mdDialog,$mdMedia,$location,$filter,$state,Idle,$ocLazyLoad,browser) {
	$ocLazyLoad.load(controllerName+'/config/configTilesPage.js?ver='+version);
	$ocLazyLoad.load(controllerName+'/config/ConfigPage.js?ver='+version);
	$ocLazyLoad.load(controllerName+'/config/ConfigHomePage.js?ver='+version);
	$ocLazyLoad.load(controllerName+'/config/CopyFunctionality.js?ver='+version);
	$ocLazyLoad.load(controllerName+'/config/ConsolidationPage.js?ver='+version);

	//Browser Refresh - 13 Nov 2017
	if($rootScope.appValidity == undefined){
		   $rootScope.username = "";
		    $rootScope.password = "";
		    var cookies = document.cookie.split(";");
		    for (var i = 0,arrLen = cookies.length; i < arrLen ; i++) {
		        var cookie = cookies[i];
		        var eqPos = cookie.indexOf("=");
		        var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
		        document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
		    }
		    $location.path('/loginPage');
	    
	}
	//Idle Time out Logic - Start

	
Idle.watch();

//Idle Time out Logic - End
$scope.openNav = function() {
	document.getElementById("upArrow").style.display = "inline-block";
	document.getElementById("mySidenav").style.display = "inline-block";
    document.getElementById("mySidenav").style.width = "230px";
    document.getElementById("downArrow").style.display = "none";
}
$scope.closeNav = function() {
	document.getElementById("upArrow").style.display = "none";
	document.getElementById("downArrow").style.display = "inline-block";
    document.getElementById("mySidenav").style.display = "none";
}
	$rootScope.downloadtempUser = false;
	$rootScope.importTemp = false;
	$rootScope.name1  = "active1";
	$rootScope.name2  = "not-active";
	$rootScope.name3 = "not-active";
	var noAuth = "false";
	var homeAuth = "true";
	if($rootScope.reportingTile == undefined)
	$rootScope.reportingTile = false;
	
	$rootScope.selectedRootScopeDatas = [];
	$rootScope.reportData = [];
	$rootScope.configTransactionData = [];
	$rootScope.userRole = "Config";
	 if($rootScope.scopevalueArrayid == undefined)
		 $rootScope.scopevalueArrayid =[];
	 if($rootScope.selectedid == undefined)	
			$rootScope.selectedid= [];
		if($rootScope.selectedid[0] == undefined)	
			$rootScope.selectedid[0] = [];
		
	var myDate = new Date();
	   myDate.setHours(myDate.getHours() + 1);
		var cookie = document.cookie;
		var cookieAuthParams = cookie.split(';');
		for (var cp1 = 0,arrLen = cookieAuthParams.length; cp1 < arrLen ; cp1++) {
			/*if (cookieAuthParams[cp1].split('=')[0].trim() == "configAuth" && cookieAuthParams[cp1].split('=')[1].trim() == "true") {
				noAuth = "true"
			}*/
			if ($rootScope.configAuth == "true") {
				noAuth = "true"
			}
			if($rootScope.appValidity == undefined){
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userDetails") {
					$rootScope.userValidation = cookieAuthParams[cp1].split('=')[1];
					//console.log($rootScope.userValidation.role);
					
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userName") {
					$rootScope.username = cookieAuthParams[cp1].split('=')[1];
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userFirstName") {
					 $rootScope.userFirstName = cookieAuthParams[cp1].split('=')[1];
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userLastName") {
					$rootScope.userLastName = cookieAuthParams[cp1].split('=')[1];
				}
		  }
			
		}
		if (noAuth == "false") {
			$location.path('/loginPage');
		}
//		$rootScope.appValidity = true;//Browser Refresh
/*Hiding Page2(Deployment Info) initially on Notification pop up*/
		$rootScope.page2 = false;
/*Displaying the content of Page 2 on click on next button	*/
$rootScope.nextpage = function(){
			$rootScope.page2 =  true;
			$rootScope.activePage = "previous";
			$rootScope.nonactivePage = "next";
		}
$rootScope.previouspage = function(){
	$rootScope.page2 =  false;
	$rootScope.activePage = "next";
	$rootScope.nonactivePage = "previous";
}
/*Two pages - dynamic classes on notification Pop up*/
$rootScope.activePage = "next";
$rootScope.nonactivePage = "previous";

/*$scope.logout = function(){
		ngDialog.close();
        $state.transitionTo('loginPage');
        $rootScope.username = "";
        $rootScope.password = "";
       // $scope.deleteAllCookies();
        $rootScope.sapUserID = "";
    	$rootScope.sapPassword = "";
        $rootScope.adminAuth  = "";

        $rootScope.fileUploadAuth = "";
        $rootScope.executeAuth = "";
        $rootScope.configAuth = "";
        $rootScope.fileDownloadAuth = "";
        ngDialog.close(); 
        	 

    }*/
	$scope.changePassword = function(){
  		if(document.getElementById("upArrow") !=  null){
  		document.getElementById("upArrow").style.display = "none";
  		document.getElementById("downArrow").style.display = "inline-block";
  	    document.getElementById("mySidenav").style.display = "none";
  		}
  		ngDialog.openConfirm({
	            template: 'view/managePassword/changePassword.html?ver='+version,
	            scope: $scope,
	            closeByDocument: false,
	            closeByEscape: false,
	            showClose: false,
	            height: 410,
	            width: 560,
	           className:'ngdialog-theme-default CLASS_projName'
	        });  		
  	};
if( $rootScope.userValidation != undefined && $rootScope.userValidation.default_p == 'Y'){
	 $scope.changePassword();
}
else if($rootScope.secQAUpdated == false &&  $rootScope.isLoginAgain == true) {
 /*   $http.post("/" + servicePrefix + "/rest/adminSrv/getSecurityQuestions/").then(function executeSuccess(response) {
    	
    	if( response.data.resMessageDto.msgType == "Success"){
    	$rootScope.securityQAList = response.data.quesListDto;
    	}
    	else{
    		
    	}
    });*/
	 $rootScope.isLoginAgain = false;
	ngDialog.openConfirm({
        template: 'view/managePassword/setUpSecurityQA.html?ver='+version,
     // controller : 'LoginPageController',
        scope: $scope,
        closeByDocument: false,
        closeByEscape: false,
        showClose: true,
        height: 445,
        width: 500,
       className:'ngdialog-theme-default CLASS_projName'
    	});
    }

$scope.homePage= function(){
	ngDialog.openConfirm({
        template: 'view/config/confirm.html?ver='+version,		           
        controller:'configTilesController',
        scope: $scope,
        closeByDocument: false,
        closeByEscape: false,
       showClose: false,
       height: 200,
       width: 527,
    });
	
	
};
 $scope.okHomepage = function(){
	$location.path("/IndustryType");
	 ngDialog.close();
};	    	
 $scope.cancelHome = function(){
	 ngDialog.close();
	 
};

    
     $scope.executeConfig = function()
    {
    	$rootScope.reportingTile = false;
    	$rootScope.configDownloadTemplate = false;
    	$rootScope.copy = false;
    	$rootScope.consolidate = false;

    	var inputParam = {
    			userID : $rootScope.username,
    			sessionInputDTO: $rootScope.sessionInputObj
    	}
    	
    	/*$http({
            method: "GET",
            url: "/" + servicePrefix + "/rest/selectCustomer/selector/"+$rootScope.username,
            headers:{
                'authorization' :  $rootScope.userValidation.userToken
              }
    }*/$http.post("/" + servicePrefix + "/rest/selectCustomer/selector", inputParam).then(function(response) {
    		  if(response.status === 200){
    			  if(response.data.resMessageDto.message == serviceMessage){
    		    		$rootScope.checkAuthorization();
    		    	}else
    		if(response.data.assignedProjects != null){
    	    	if(response.data.assignedProjects.length >1)
    	        {
    	    		$scope.settings = response.data.assignedProjects;	
    
            ngDialog.openConfirm({
                template: 'view/config/userProject.html?ver='+version,
                controller: 'configTilesController',
                scope: $scope,
                closeByDocument: false,
                closeByEscape: false,
                showClose: true,
                height:400,
                width: 400,
                className:'ngdialog-theme-default CLASS_projName'
            }).then(function() { });
            
    	        }else
    	        	
    	        	{
    	        	 for(var i =0,arrLen = response.data.assignedProjects.length; i< arrLen ;i++){
        	    		$rootScope.projOmId = response.data.assignedProjects[i].omId;
        	    		$rootScope.projectName = response.data.assignedProjects[i].projectName;
        	    		$rootScope.trOverRide = response.data.assignedProjects[i].trOverRide != null ? response.data.assignedProjects[i].trOverRide : "";//TR Changes
        	    		$rootScope.customDestFlagFrDwnld = response.data.assignedProjects[i].cust_DestReq != null ? response.data.assignedProjects[i].cust_DestReq : "";//Added by Veena 
    	        	 }
    	        	 //document.cookie = "configInitial="+homeAuth+";expires=" + myDate.toUTCString();
    	        	
    	        	 $rootScope.configInitial = homeAuth;
    	        	 $location.path("/ConfigHeader/configPage");
    	        	 
        	    	}
    		  }
    		else{ 			
    			  ngDialog.openConfirm({
                      template: '<p>' +"No project has been assigned .please contact administrator"+ '</p>',
                      plain: true,
                      scope: $scope,
                      closeByDocument: true,
                      closeByEscape: true,
                      showClose: true,
                      height:120,
                      width: 350
                  });
    			
    		}
    	}

    	});
    	
    };  
    /*Consolidation Execution*/
    $scope.executeConsolidation = function()
    {
    	$rootScope.reportingTile = false;
    	$rootScope.configDownloadTemplate = false;
    	$rootScope.consolidate = true;
    	$rootScope.copy = false;

    	var inputParam = {
    			userID : $rootScope.username,
    			sessionInputDTO: $rootScope.sessionInputObj
    	}
    	
    	/*$http({
            method: "GET",
            url: "/" + servicePrefix + "/rest/selectCustomer/selector/"+$rootScope.username,
            headers:{
                'authorization' :  $rootScope.userValidation.userToken
              }
    }*/$http.post("/" + servicePrefix + "/rest/selectCustomer/selector", inputParam).then(function(response) {
    		  if(response.status === 200){
    			  if(response.data.resMessageDto.message == serviceMessage){
    		    		$rootScope.checkAuthorization();
    		    	}else
    		if(response.data.assignedProjects != null){
    	    	if(response.data.assignedProjects.length >1)
    	        {
    	    		$scope.settings = response.data.assignedProjects;	
    
            ngDialog.openConfirm({
                template: 'view/config/userProjectConsolidation.html?ver='+version,
                controller: 'configTilesController',
                scope: $scope,
                closeByDocument: false,
                closeByEscape: false,
                showClose: true,
                height:400,
                width: 400,
                className:'ngdialog-theme-default CLASS_projName'
            }).then(function() { });
            
    	        }else
    	        	
    	        	{
    	        	 for(var i =0,arrLen = response.data.assignedProjects.length; i< arrLen ;i++){
        	    		$rootScope.projOmId = response.data.assignedProjects[i].omId;
        	    		$rootScope.projectName = response.data.assignedProjects[i].projectName;
        	    		$rootScope.trOverRide = response.data.assignedProjects[i].trOverRide != null ? response.data.assignedProjects[i].trOverRide : "";//TR Changes
        	    		$rootScope.customDestFlagFrDwnld = response.data.assignedProjects[i].cust_DestReq != null ? response.data.assignedProjects[i].cust_DestReq : "";//Added by Veena 
    	        	 }
    	        	 //document.cookie = "configInitial="+homeAuth+";expires=" + myDate.toUTCString();
    	        	
    	        	 $rootScope.configInitial = homeAuth;
    	        	 $location.path("/ConfigHeader/consolidationPage");
    	        	 
        	    	}
    		  }
    		else{ 			
    			  ngDialog.openConfirm({
                      template: '<p>' +"No project has been assigned .please contact administrator"+ '</p>',
                      plain: true,
                      scope: $scope,
                      closeByDocument: true,
                      closeByEscape: true,
                      showClose: true,
                      height:120,
                      width: 350
                  });
    			
    		}
    	}

    	});
    	
    };  
    $scope.navigateToConsolidation = function(omId, projectName, trOverRide, cust_DestReq, event) {
    	$rootScope.downloadtempUser = false;
    	$rootScope.projOmId = omId;
    	$rootScope.projectName = projectName;
    	$rootScope.trOverRide = trOverRide != null ? trOverRide : "";//TR Changes
    	$rootScope.customDestFlagFrDwnld = cust_DestReq != null ? cust_DestReq : "";//Added by Veena
    	if($rootScope.configDownloadTemplate){
    		$rootScope.downloadtempUser = true;
    		$rootScope.createimg = true;
    		
    		$rootScope.configInitial = homeAuth; 
       	  	$location.path("/ConfigHeader/manageTemplate");
    	
    	}
    	else if($rootScope.reportingTile == false){
    	
    	 $rootScope.configInitial = homeAuth;
    	$location.path("/ConfigHeader/consolidationPage");
    	}
    	else{
    		var params ={
    				omID : $rootScope.projOmId,
    				userID : $rootScope.username,
    				sessionInputDTO : $rootScope.sessionInputObj	

    		}
    		$http.post("/" + servicePrefix + "/rest/configReportService/getConfigTransaction",params).then(function(response) {
      	        if (response.status === 200) {
      	     
      	      	if(response.data != null || response.data.message == "No Results Found! "){
  	        		if(response.data.message == serviceMessage){
  	      	      		$rootScope.checkAuthorization();
  	      	      	}
  	        		else  $rootScope.configTransactionData = response.data;
  	        	}
      	        	else {
        	        	  ngDialog.openConfirm({
                            template: '<p>' +"No Results Found"+ '</p>',
                            plain: true,
                            scope: $scope,
                            closeByDocument: true,
                            closeByEscape: true,
                            showClose: true,
                            height:120,
                            width: 350
                        });
        	        	}
      	        }
      	      else {
      	          ngDialog.openConfirm({
                      template: '<p>' +"No Results Found"+ '</p>',
                      plain: true,
                      scope: $scope,
                      closeByDocument: true,
                      closeByEscape: true,
                      showClose: true,
                      height:120,
                      width: 350
                  });
      	        }
    		});
    	//document.cookie = "configInitial="+homeAuth+";expires=" + myDate.toUTCString();
    	 $rootScope.configInitial = homeAuth;
    	 /*$location.path("/ConfigHeader/reportsList");*/
 		 $location.path("/ConfigHeader/configReports");
    	}
    	ngDialog.close();
      };
    /*copy functionality js start here */
    $scope.copyFunctionality = function()
    {
    	$rootScope.reportingTile = false;
    	$rootScope.configDownloadTemplate = false;
    	/*$rootScope.hierarchyTypes.value="";*/
    	$rootScope.copy = true;
    	$rootScope.consolidate = false;

    	
    	var inputParam = {
    			userID : $rootScope.username,
    			sessionInputDTO: $rootScope.sessionInputObj
    	}
    	
    	/*$http({
            method: "GET",
            url: "/" + servicePrefix + "/rest/selectCustomer/selector/"+$rootScope.username,
            headers:{
                'authorization' :  $rootScope.userValidation.userToken
              }
    }*/$http.post("/" + servicePrefix + "/rest/selectCustomer/selector", inputParam).then(function(response) {
    		  if(response.status === 200){
    			  if(response.data.resMessageDto.message == serviceMessage){
    		    		$rootScope.checkAuthorization();
    		    	}else
    		if(response.data.assignedProjects != null){
    	    	if(response.data.assignedProjects.length >1)
    	        {
    	    		$scope.settings = response.data.assignedProjects;	
    
            ngDialog.openConfirm({
                template: 'view/config/CopyUserProject.html?ver='+version,
                controller: 'configTilesController',
                scope: $scope,
                closeByDocument: false,
                closeByEscape: false,
                showClose: true,
                height:400,
                width: 400,
                className:'ngdialog-theme-default CLASS_projName'
            }).then(function() { });
            
    	        }else
    	        	
    	        	{
    	        	 for(var i =0,arrLen = response.data.assignedProjects.length; i< arrLen ;i++){
        	    		$rootScope.projOmId = response.data.assignedProjects[i].omId;
        	    		$rootScope.projectName = response.data.assignedProjects[i].projectName;
        	    		$rootScope.trOverRide = response.data.assignedProjects[i].trOverRide != null ? response.data.assignedProjects[i].trOverRide : "";//TR Changes
        	    		$rootScope.customDestFlagFrDwnld = response.data.assignedProjects[i].cust_DestReq != null ? response.data.assignedProjects[i].cust_DestReq : "";//Added by Veena 
    	        	 }
    	        	 //document.cookie = "configInitial="+homeAuth+";expires=" + myDate.toUTCString();
    	        	
    	        	 $rootScope.configInitial = homeAuth;
    	        	 $location.path("/ConfigHeader/copyFunctionality");
    	        	 
        	    	}
    		  }
    		else{ 			
    			  ngDialog.openConfirm({
                      template: '<p>' +"No project has been assigned .please contact administrator"+ '</p>',
                      plain: true,
                      scope: $scope,
                      closeByDocument: true,
                      closeByEscape: true,
                      showClose: true,
                      height:120,
                      width: 350
                  });
    			
    		}
    	}

    	});
    	
    };  
    /*copy functionality js end here */
    
    $scope.navigateTo = function(omId, projectName, trOverRide, cust_DestReq, event) {
    	$rootScope.downloadtempUser = false;
    	$rootScope.projOmId = omId;
    	$rootScope.projectName = projectName;
    	$rootScope.trOverRide = trOverRide != null ? trOverRide : "";//TR Changes
    	$rootScope.customDestFlagFrDwnld = cust_DestReq != null ? cust_DestReq : "";//Added by Veena
    	if($rootScope.configDownloadTemplate){
    		$rootScope.downloadtempUser = true;
    		$rootScope.createimg = true;
    		
    		$rootScope.configInitial = homeAuth; 
       	  	$location.path("/ConfigHeader/manageTemplate");
    	
    	}
    	else if($rootScope.reportingTile == false){
    	
    	 $rootScope.configInitial = homeAuth;
    	$location.path("/ConfigHeader/configPage");
    	}
    	else{
    		var params ={
    				omID : $rootScope.projOmId,
    				userID : $rootScope.username,
    				sessionInputDTO : $rootScope.sessionInputObj	

    		}
    		$http.post("/" + servicePrefix + "/rest/configReportService/getConfigTransaction",params).then(function(response) {
      	        if (response.status === 200) {
      	     
      	      	if(response.data != null || response.data.message == "No Results Found! "){
  	        		if(response.data.message == serviceMessage){
  	      	      		$rootScope.checkAuthorization();
  	      	      	}
  	        		else  $rootScope.configTransactionData = response.data;
  	        	}
      	        	else {
        	        	  ngDialog.openConfirm({
                            template: '<p>' +"No Results Found"+ '</p>',
                            plain: true,
                            scope: $scope,
                            closeByDocument: true,
                            closeByEscape: true,
                            showClose: true,
                            height:120,
                            width: 350
                        });
        	        	}
      	        }
      	      else {
      	          ngDialog.openConfirm({
                      template: '<p>' +"No Results Found"+ '</p>',
                      plain: true,
                      scope: $scope,
                      closeByDocument: true,
                      closeByEscape: true,
                      showClose: true,
                      height:120,
                      width: 350
                  });
      	        }
    		});
    	//document.cookie = "configInitial="+homeAuth+";expires=" + myDate.toUTCString();
    	 $rootScope.configInitial = homeAuth;
    	 /*$location.path("/ConfigHeader/reportsList");*/
 		 $location.path("/ConfigHeader/configReports");
    	}
    	ngDialog.close();
      };
     
      $scope.navigateToForCopy = function(omId, projectName, trOverRide, cust_DestReq, event) {
      	$rootScope.downloadtempUser = false;
      	$rootScope.projOmId = omId;
      	$rootScope.projectName = projectName;
      	$rootScope.trOverRide = trOverRide != null ? trOverRide : "";//TR Changes
      	$rootScope.customDestFlagFrDwnld = cust_DestReq != null ? cust_DestReq : "";//Added by Veena
      	if($rootScope.configDownloadTemplate){
      		$rootScope.downloadtempUser = true;
      		$rootScope.createimg = true;
      		
      		$rootScope.configInitial = homeAuth; 
         	  	$location.path("/ConfigHeader/manageTemplate");
      	
      	}
      	else if($rootScope.reportingTile == false){
      	
      	 $rootScope.configInitial = homeAuth;
      	$location.path("/ConfigHeader/copyFunctionality");
      	}
      	else{
      		var params ={
      				omID : $rootScope.projOmId,
      				userID : $rootScope.username,
      				sessionInputDTO : $rootScope.sessionInputObj	

      		}
      		$http.post("/" + servicePrefix + "/rest/configReportService/getConfigTransaction",params).then(function(response) {
        	        if (response.status === 200) {
        	     
        	      	if(response.data != null || response.data.message == "No Results Found! "){
    	        		if(response.data.message == serviceMessage){
    	      	      		$rootScope.checkAuthorization();
    	      	      	}
    	        		else  $rootScope.configTransactionData = response.data;
    	        	}
        	        	else {
          	        	  ngDialog.openConfirm({
                              template: '<p>' +"No Results Found"+ '</p>',
                              plain: true,
                              scope: $scope,
                              closeByDocument: true,
                              closeByEscape: true,
                              showClose: true,
                              height:120,
                              width: 350
                          });
          	        	}
        	        }
        	      else {
        	          ngDialog.openConfirm({
                        template: '<p>' +"No Results Found"+ '</p>',
                        plain: true,
                        scope: $scope,
                        closeByDocument: true,
                        closeByEscape: true,
                        showClose: true,
                        height:120,
                        width: 350
                    });
        	        }
      		});
      	//document.cookie = "configInitial="+homeAuth+";expires=" + myDate.toUTCString();
      	 $rootScope.configInitial = homeAuth;
      	 /*$location.path("/ConfigHeader/reportsList");*/
   		 $location.path("/ConfigHeader/configReports");
      	}
      	ngDialog.close();
        };
        
      $scope.templateDownload = function()
      {
    	  $rootScope.downloadtempUser = true;
    	  $rootScope.importTemp = true;
    	  $rootScope.projectName = "";
    	  $rootScope.trOverRide = "";
    	  $rootScope.configDownloadTemplate = true;
    	  $rootScope.consolidate = false;
    	  $rootScope.copy = false;


    		var inputParam = {
        			userID : $rootScope.username,
        			sessionInputDTO: $rootScope.sessionInputObj
        	}
    	  
    		$http.post("/" + servicePrefix + "/rest/selectCustomer/selector", inputParam).then(function(response) {
    			if(response.status === 200){
    				if(response.data.resMessageDto.message == serviceMessage){
    					 $location.path("/loginPage");
                   	  ngDialog.openConfirm({
                             template: '<p>' +"Your session has expired/Invalid Request. <br> Please Login again"+ '</p>',
                             plain: true,
                             scope: $scope,
                             closeByDocument: true,
                             closeByEscape: true,
                             showClose: true,
                             height:120,
                             width: 350
                         });
                   	  $rootScope.username = "";
                         $rootScope.password = "";
                         $rootScope.showLogsExportData = false;
                         $rootScope.adminAuth  = "";
                         $rootScope.fileUploadAuth = "";
                         $rootScope.executeAuth = "";
                         $rootScope.configAuth = "";
                         $rootScope.fileDownloadAuth = "";
                         $rootScope.sapUserID = "";
                     	  $rootScope.sapPassword = "";
    				}
    				else if(response.data.assignedProjects != null){
    			    	if(response.data.assignedProjects.length >1)
    			        {
    			    		$scope.settings = response.data.assignedProjects;	    
    				        ngDialog.openConfirm({
    				            template: 'view/config/userProject.html?ver='+version,
    				            scope: $scope,
    				            closeByDocument: false,
    				            closeByEscape: false,
    				            showClose: true,
    				            height:400,
    				            width: 400
    				          
    				        }).then(function() {
    				           
    				        });
    			        }else	        	
    			        	{
    			        	$rootScope.downloadtempUser = false;
    			        	$rootScope.projOmId =  response.data.assignedProjects[0].omId;
    			        	$rootScope.projectName =  response.data.assignedProjects[0].projectName;
    			        	$rootScope.trOverRide =  response.data.assignedProjects[0].trOverRide != null ?  response.data.assignedProjects.trOverRide : "";//TR Changes
    			        	$rootScope.customDestFlagFrDwnld =  response.data.assignedProjects[0].cust_DestReq != null ?  response.data.assignedProjects.cust_DestReq : "";

        	         		$rootScope.downloadtempUser = true;
        	         		$rootScope.createimg = true;
        	         		$rootScope.hierarchyTypes.value = "";
        	         		
    			          	$rootScope.configInitial = homeAuth; 
	                   	  	$location.path("/ConfigHeader/manageTemplate");
    			        	
    		    	    	}
    				  }
    				else{ 			
    					  ngDialog.openConfirm({
    		                  template: '<p>' +"No project has been assigned .please contact administrator"+ '</p>',
    		                  plain: true,
    		                  scope: $scope,
    		                  closeByDocument: true,
    		                  closeByEscape: true,
    		                  showClose: true,
    		                  height:120,
    		                  width: 350
    		              });
    				}
    			}
    			else {}
    			});
    	  
      	
      	 /*     Closing Busy indicator	*/ 
	  		 var overlay = document.getElementById("overlay");
	  	     var popup = document.getElementById("busy");
	  	     overlay.style.display = "none";
	  	     popup.style.display = "none";
	  	
      };
$scope.reportingData = function(){
	$rootScope.reportingTile =  true;
	$rootScope.configDownloadTemplate = false;
	var inputParam = {
			userID : $rootScope.username,
			sessionInputDTO: $rootScope.sessionInputObj
	}
	$http.post("/" + servicePrefix + "/rest/selectCustomer/selector", inputParam).then(function(response) {
		if(response.status === 200){
			if(response.data != null && response.data.message == serviceMessage){
	    		$rootScope.checkAuthorization();
	    	}
			else if(response.data.assignedProjects != null){
		    	if(response.data.assignedProjects.length >1)
		        {
		    		$scope.settings = response.data.assignedProjects;	    
			        ngDialog.openConfirm({
			            template: 'view/config/userProject.html?ver='+version,
			            //controller: 'configTilesController',
			            scope: $scope,
			            closeByDocument: false,
			            closeByEscape: false,
			            showClose: true,
			            height:400,
			            width: 400
			          
			        }).then(function() {
			           
			        });
		        }else	        	
		        	{
			 for(var i =0,arrLen = response.data.assignedProjects.length; i< arrLen ;i++){
	    	    		$rootScope.projOmId = response.data.assignedProjects[i].omId;
	    	    		$rootScope.projectName = response.data.assignedProjects[i].projectName;
	    	    		$rootScope.trOverRide = response.data.assignedProjects[i].trOverRide != null ? response.data.assignedProjects[i].trOverRide : "";//TR Changes
		        	 }
		        	 	var params ={
    					omID : $rootScope.projOmId,
    					userID : $rootScope.username,
    					sessionInputDTO : $rootScope.sessionInputObj
    					}
    		$http.post("/" + servicePrefix + "/rest/configReportService/getConfigTransaction",params).then(function(response) {
      	        if (response.status === 200) {
      	        
      	        	if(response.data != null || response.data.message == "No Results Found! "){
      	        		if(response.data.message == serviceMessage){
      	      	      		$rootScope.checkAuthorization();
      	      	      	}
      	        		else  $rootScope.configTransactionData = response.data;
      	        	}
      	        	else {
        	        	  ngDialog.openConfirm({
                            template: '<p>' +"No Results Found"+ '</p>',
                            plain: true,
                            scope: $scope,
                            closeByDocument: true,
                            closeByEscape: true,
                            showClose: true,
                            height:120,
                            width: 350
                        });
        	        	}
      	        }
      	      else {
      	          ngDialog.openConfirm({
                      template: '<p>' +"No Results Found"+ '</p>',
                      plain: true,
                      scope: $scope,
                      closeByDocument: true,
                      closeByEscape: true,
                      showClose: true,
                      height:120,
                      width: 350
                  });
      	        }
    		});
    			 //document.cookie = "configInitial="+homeAuth+";expires=" + myDate.toUTCString();
    			 $rootScope.configInitial = homeAuth;
    			 $location.path("/ConfigHeader/configReports");
	    	    	}
			  }
			else{ 			
				  ngDialog.openConfirm({
	                  template: '<p>' +"No project has been assigned .please contact administrator"+ '</p>',
	                  plain: true,
	                  scope: $scope,
	                  closeByDocument: true,
	                  closeByEscape: true,
	                  showClose: true,
	                  height:120,
	                  width: 350
	              });
			}
		}
		else {}
		});
	
	/*document.cookie = "configInitial="+homeAuth+";expires=" + myDate.toUTCString();
	$location.path("/ConfigHeader/configReports");
	*/
};

$scope.getHelpDocuments = function(){
		$rootScope.overlay_helpDoc = document.getElementById("overlay");
	    $rootScope.popup_helpDoc = document.getElementById("busy");
	    $rootScope.overlay_helpDoc.style.display = "block";
	    $rootScope.popup_helpDoc.style.display = "inline-block";
	var params={
            userId: $rootScope.username,
            role: $rootScope.userRole
          
        };
	$http({
        method: "POST",
        url: "/" + servicePrefix + "/rest/helpDocumentsSrv/retrieveHelpDocuments",
        data : params
    }).then(function mySucces(response) {
    	if(response.data.message == serviceMessage){
    		$rootScope.checkAuthorization();
    	}
    	else if (response.data.responseList !=null) {
        	
            $rootScope.overlay_helpDoc.style.display = "none";
            $rootScope.popup_helpDoc.style.display = "none";
        	$rootScope.helpDocArr = response.data.responseList;
            var arrLength =  $rootScope.helpDocArr.length;
        	for(var i =0; i<arrLength; i++){
        		console.log($rootScope.helpDocArr[i].fileName.split(".")[1]);
            if($rootScope.helpDocArr[i].fileName.split(".")[1] == "pdf"){
           		 $rootScope.helpDocArr[i].fileType = "pdf";	
       			 }
       			 else if($rootScope.helpDocArr[i].fileName.split(".")[1] == "mp4"){
           		 $rootScope.helpDocArr[i].fileType = "mp4";	
       			 }
        	}
        }else{
        	$rootScope.overlay_helpDoc.style.display = "none";
        	$rootScope.popup_helpDoc.style.display = "none";
        	}
 	 }, function myError(response) {
    	$rootScope.overlay_helpDoc.style.display = "none";
    	$rootScope.popup_helpDoc.style.display = "none";
 	 	});
	
	 $rootScope.configAuth = "true";
	 $rootScope.configInitial = homeAuth;
	 $location.path("/ConfigHeader/importHelpDoc");
	
	/*document.cookie = "configInitial="+homeAuth+";expires=" + myDate.toUTCString();
	$location.path("/ConfigHeader/configReports");
	*/
};

	
	$scope.downloadSingleTmeplate = function(seqID){
	$scope.fileNameList = [];
	for(var i =0,arrLen = $rootScope.templateUpdateInfo.length; i< arrLen ;i++){
		if($rootScope.templateUpdateInfo[i].seqID == seqID){
		var fileName =  $rootScope.templateUpdateInfo[i].imgDescr;
		var seqNumber =  $rootScope.templateUpdateInfo[i].seqID;
		var byteData =  $rootScope.templateUpdateInfo[i].bytes;
		
		var fileBytes = base64ToArrayBuffer(byteData);
         $scope.fileNameList.push(seqNumber + "_" + fileName + ".xlsx");
         saveByteArray([fileBytes], seqNumber+"_"+fileName+".xlsx");	
		}
		}
	};
	function base64ToArrayBuffer(base64) {
  	    var binaryString =  window.atob(base64);
  	    var binaryLen = binaryString.length;
  	    var bytes = new Uint8Array(binaryLen);
  	    for (var i = 0; i < binaryLen; i++)        {
  	        var ascii = binaryString.charCodeAt(i);
  	        bytes[i] = ascii;
  	    }
  	    return bytes;
  	};

  	var saveByteArray = (function () {
  	    var a = document.createElement("a");
  	    document.body.appendChild(a);
  	    a.style = "display: none";
  	    return function (data, name) {
  	        var blob = new Blob(data, {type: "octet/stream"}),
  	            url = window.URL.createObjectURL(blob);
  	        if(!$scope.isZipFile){
  	        	if (navigator.appVersion.toString().indexOf('.NET') > 0) { // for IE browser
  	           window.navigator.msSaveBlob(blob, name);
  	        	} else { // for other browsers
  	        		a.href = url;
  	        		a.download = name;
  	        		a.click();
  	        		window.URL.revokeObjectURL(url);    
  	        	}
  	        }
  	        else{
             	$scope.arrayImg.push(url);

  	        }
  	        
  	    };
  	}());

	$scope.skipSecQA = function()
		{
		 ngDialog.close();
		}
 	$scope.saveSecQuestions = function(){
  		var listOfQuestions = [$rootScope.securityQA.question1,$rootScope.securityQA.question2];
  		var listOfAnswers = [sha256($rootScope.securityQA.answer1),sha256($rootScope.securityQA.answer2)];
  	    var comparray = [];
       for(i=0;i<listOfAnswers.length;i++){
    	   var obj ={};
               obj.questionId = listOfQuestions[i];
               obj.ans = listOfAnswers[i];
               
           comparray.push(obj);
       }
  		var input = {
  				ansListDto : comparray,
  				userId: $rootScope.username,
  				sessionInputDTO :  $rootScope.sessionInputObj
  		}
  	
  		$http.post("/" + servicePrefix + "/rest/adminSrv/updateSecurityAnswers",input).then(function(response){
  	       if(response.data.msgType == "Success")
  	  		{
  	    	 ngDialog.close();
  	    	 	    	
  	    	$rootScope.secQAUpdated = true;
  	    	
  	    	 ngDialog.openConfirm({
                template: '<p>' + "Your Details are saved succeessfully" +'</p>',
                plain: true,
                scope: $scope,
                closeByDocument: true,
                closeByEscape: true,
                showClose: true,
                height:120,
                width: 350,
                className:'ngdialog-theme-default CLASS_2'
            });
  	    	}
  	       else {
  	    	 ngDialog.close();
  	    	 ngDialog.openConfirm({
                 template: '<p>' + "Something went wrong. Please try again with correct details" +'</p>',
                 plain: true,
                 scope: $scope,
                 closeByDocument: true,
                 closeByEscape: true,
                 showClose: true,
                 height:120,
                 width: 350,
                 className:'ngdialog-theme-default CLASS_2'
             });
  	       }
  			});
  		
 	};

  	$scope.newPassword =  function(){
  		//$scope.validateRole($rootScope.securityQA.newpassword);
  	/*	service call to store the new password*/
  		if( $rootScope.securityQA.oldpassword == $rootScope.password){
  			if($rootScope.securityQA.oldpassword != $rootScope.securityQA.newpassword){
  			$scope.showAlert = {"display":"none"};
  		 var params = {
           		userId : $rootScope.username,
           		oldPassword : $rootScope.securityQA.oldpassword,
           		newPassword : $rootScope.securityQA.newpassword,
           		sessionInputDTO : $rootScope.sessionInputObj
           }
  		$http.post("/" + servicePrefix + "/rest/adminSrv/updatePassword",params).then(function(response){
        if(response.data.msgType == "Success")
  		{        	
        	ngDialog.close();          	   
            $http.post("/" + servicePrefix + "/rest/adminSrv/getSecurityQuestions/").then(function executeSuccess(response) {
            	
            	if( response.data.resMessageDto.msgType == "Success"){
            	$rootScope.securityQAList = response.data.quesListDto;
            	}
            	else{
            		
            	}
            });
        	$rootScope.userValidation.default_p = 'N';
        	if($rootScope.secQAUpdated == false) {
        		ngDialog.openConfirm({
        	        template: 'view/managePassword/setUpSecurityQA.html?ver='+version,
        	     
        	        scope: $scope,
        	        closeByDocument: false,
        	        closeByEscape: false,
        	        showClose: true,
        	        height: 445,
        	        width: 500,
        	       className:'ngdialog-theme-default CLASS_projName'
        	    	});
        	}
        	else{
        		ngDialog.openConfirm({
                    template: '<p>' + "Your new Password is saved successfully" +'</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                })
        	}
        }else if(response.data.message == "Invalid input received"){
          	ngDialog.openConfirm({
                template: '<p>' + "Invalid input received" +'</p>',
                plain: true,
                scope: $scope,
                closeByDocument: true,
                closeByEscape: true,
                showClose: true,
                height:120,
                width: 350,
                className:'ngdialog-theme-default CLASS_2'
            })
        }
        else {
        	ngDialog.openConfirm({
                template: '<p>' + "Something went wrong." +'</p>',
                plain: true,
                scope: $scope,
                closeByDocument: true,
                closeByEscape: true,
                showClose: true,
                height:120,
                width: 350,
                className:'ngdialog-theme-default CLASS_2'
            })
        }
  		});
  		}else{
  				$scope.showAlertforNewPwd = {   "color" : "red", "display":"inline-block"};
  			}
  		}
  		else{
  			$scope.showAlert = {   "color" : "red", "display":"inline-block"};
  		
  		}
  	};
  	$scope.setOnlySecurityQuestions = function (){
  		ngDialog.openConfirm({
            template: 'view/managePassword/setUpSecurityQA.html?ver='+version,
         // controller : 'LoginPageController',
            scope: $scope,
            closeByDocument: false,
            closeByEscape: false,
            showClose: true,
            height: 445,
            width: 500,
           className:'ngdialog-theme-default CLASS_projName'
        	});
  	};
  	$rootScope.validateSapDetails = function (sapUserId, sapPassword, Lang, sapSystem){
    //return x.toString(16);
    //  $rootScope.username = $scope.username;
     // $rootScope.password = $scope.password;
      $rootScope.submitted = true;
      $rootScope.msgErrorDisplay = false;
      $rootScope.systemup = false;
      $rootScope.sapUserID  = sapUserId;
      $rootScope.sapPassword = sapPassword;
      $rootScope.sapLanguage = Lang;
      $rootScope.selectedSystem = sapSystem;
      if ($rootScope.sapUserID == undefined || $rootScope.sapUserID == "") {
      	$rootScope.ErrorMsg = "Please enter SAP Login ID";
      	$rootScope.msgErrorDisplay = true;
      	if(document.getElementById("saperrormsg")!=null){
      		document.getElementById("saperrormsg").style.display = "inline-block";
      	}
		    return;
      }
      else if($rootScope.sapPassword == undefined || $rootScope.sapPassword == ""){
      	
      	$rootScope.ErrorMsg = "Please enter SAP Password";
      	$rootScope.msgErrorDisplay = true;
		    return;

      }else if($rootScope.sapUserID.length > 15){
      	$rootScope.ErrorMsg = "Please enter SAP Login ID with 15 characters";
      	$rootScope.msgErrorDisplay = true;
		    return;
      }
      else if ($rootScope.sapLanguage == undefined || $rootScope.sapLanguage == ""){
      	$rootScope.ErrorMsg = "Please enter one of the installed languages";
      	$rootScope.msgErrorDisplay = true;
		    return;
      }
      else if (new RegExp($rootScope.languagePattern).test($rootScope.sapLanguage) == false){
      	$rootScope.ErrorMsg = "Only alphabets allowed for language";
      	$rootScope.msgErrorDisplay = true;
		    return;
      }
      
      if( $rootScope.msgErrorDisplay == false){
      	$rootScope.hidesapErrorMsg();
          ngDialog.close();

      	}     
    
      $rootScope.overlay = document.getElementById("overlay");
      $rootScope.popup = document.getElementById("busy");
      $rootScope.overlay.style.display = "block";
      $rootScope.popup.style.display = "inline-block";
 
      var iv = CryptoJS.lib.WordArray.random(128/8).toString(CryptoJS.enc.Hex);
      var salt = CryptoJS.lib.WordArray.random(128/8).toString(CryptoJS.enc.Hex);

      var aesUtil = new AesUtil(128, 1000);
      var encryptedSapPassword = aesUtil.encrypt(salt, iv, $rootScope.selectedSystem, $rootScope.sapPassword);
      var aesSapPassword = (iv + "::" + salt + "::" + encryptedSapPassword);
      $rootScope.eSapPassword = btoa(aesSapPassword);
      
      
      var inputParam ={
	       		 destinationName: $rootScope.selectedSystem,					 
	    			  sessionInputDTO: $rootScope.sessionInputObj
	    	  }
	        $http.post("/" + servicePrefix + "/rest/configSrv/getSystemDetails", inputParam).then(function mySucces(response) {
	            if (response.data[0].resMessageDTO.msgType == "Success") {
	            	$rootScope.target = response.data[0];
	               
	            }else if(response.data.systemdetails.resMessageDto.message == serviceMessage){
	        		$rootScope.checkAuthorization();
	        	}
	     
      var params={};	
      params.sapUserId=$rootScope.sapUserID,
      params.password=$rootScope.eSapPassword,
      params.destinationName=$rootScope.selectedSystem,
      params.sessionInputDTO =$rootScope.sessionInputObj,	
      params.sapLanguage = $rootScope.sapLanguage,
      
      //params.systemType = systemType;
      params.hostName=$rootScope.target.hostName;
      params.systemId=$rootScope.target.systemId;
      params.clientNo=$rootScope.target.sapClientNo;
      //params.sapUserId=$scope.target.userId;
      //params.destPasswrd=$scope.target.password;
      //params.language=$scope.target.language;
      params.sysNo=$rootScope.target.systemNo;
      params.sncEnabled=$scope.target.sncEnabled;
      params.sncName=$scope.target.sncName;
      params.sncPartnerName=$scope.target.sncPartnerName;
      params.sapRouter=$scope.target.sapRouter;
      params.sncProtectionLevel=$scope.target.sncProtectionLevel;
      
      params.iscustdestReq=$rootScope.customDestFlagFrDwnld
            
//      if(params.destinationName=="EUT333System"){
//      	params.hostName="sapveutsb.vceaa.root";
//      	params.clientNo="333";
//      	params.sysNo="00";
//      	
//      }else if(params.destinationName=="MET600System"){
//      	params.hostName="sapvmetsb.vceaa.root";
//      	params.clientNo="600";
//      	params.sysNo="00";
//      }else if(params.destinationName=="MET700System"){
//      	params.hostName="sapvmetsb.vceaa.root";
//      	params.clientNo="700";
//      	params.sysNo="00";
//      }else if(params.destinationName=="MET500System"){
//      	params.hostName="sapvmetsb.vceaa.root";
//      	params.clientNo="500";
//      	params.sysNo="00";	
//      }
//      else if(params.destinationName=="SFD100System"){
//        	params.hostName="10.136.32.6";
//        	params.clientNo="100";
//        	params.sysNo="00";
//        	
//        }
      
    	  
      $rootScope.sapDestination = $rootScope.selectedSystem;
      if($rootScope.sapUserID!=null && $rootScope.sapPassword!=null && $rootScope.sapUserID!="" && $rootScope.sapPassword!=""){
      $http.post("/" + servicePrefix + "/rest/dynamicDestination/validateDestination", params).then(function(response) {
          if(response.status === 200 && response.data.status === "Success"){
          		ngDialog.close();            	
          	// $rootScope.overlay = document.getElementById("overlay_execute");
      	     //$rootScope.popup = document.getElementById("busy_execute");
      	     $rootScope.overlay.style.display = "none";
      	     $rootScope.popup.style.display = "none";
      	     if($rootScope.tempDownload){ // ReUsing Auth variable to call appropriate method
      	    	 $rootScope.configDowld();
      	     }
      	     else {
      	    	if($rootScope.copyFlag == true && $rootScope.implType == "2" && $rootScope.hierarchyTypes.value == "Business Process"){
        				$rootScope.confirmExecution();		
        		}else{
        			$rootScope.dependencyCheck();
        		}
      	    	 
      	     }
          	}
      	     else{
      	    	
      	    	 $rootScope.ErrorMsg = response.data.message;
      	    	 $rootScope.msgErrorDisplay = true;
      	    	if(document.getElementById("saperrormsg1") != null)
      	    		document.getElementById("saperrormsg1").style.display = "inline-block!important"
           		 ngDialog.close();
           		 
          	     $rootScope.overlay.style.display = "none";
          	     $rootScope.popup.style.display = "none";
           			ngDialog.openConfirm({
		            template: 'view/config/sapLoginDetails.html?ver='+version,
		            scope: $rootScope,
		            closeByDocument: false,
		            closeByEscape: false,
		            showClose: true,
		            height: 500,
		            width: 527,
		           className:'ngdialog-theme-default CLASS_projName'
		        });
      		//return;	 
      		 }
      });
      }else if(response.data.resMessageDto != null && responseData.data.resMessageDto.message == serviceMessage){
	      		$rootScope.checkAuthorization();
	      	} else{
	      		$rootScope.ErrorMsg = response.data.message;
	      		$rootScope.msgErrorDisplay = true;
      		 ngDialog.close();
      		
      	     $rootScope.overlay.style.display = "none";
      	     $rootScope.popup.style.display = "none";
      		ngDialog.openConfirm({
	            template: 'view/config/sapLoginDetails.html?ver='+version,
	            scope: $rootScope,
	            closeByDocument: false,
	            closeByEscape: false,
	            showClose: true,
	            height: 500,
	            width: 527,
	            className:'ngdialog-theme-default CLASS_projName'
	        });
      		//return;
      }    
	        }, function myError(response) {
	        });

  	};
  	
  	$rootScope.cancelOperation = function(){
		$rootScope.sapUserID = "";
		$rootScope.sapPassword = "";
		ngDialog.close();		
		$mdDialog.cancel();
		};
}]);
