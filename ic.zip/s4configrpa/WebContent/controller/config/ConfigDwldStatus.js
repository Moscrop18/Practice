angular.module('yapp').controller('configDwdStatusController',["ngDialog","Upload","$scope","$rootScope","$http","$mdDialog","$mdMedia","$location","$filter","$state","$ocLazyLoad", function(ngDialog,Upload,$scope,$rootScope,$http,$mdDialog,$mdMedia,$location,$filter,$state,$ocLazyLoad) {
	
	//Browser Refresh - 13 Nov 2017
	if($rootScope.appValidity == undefined){
		 $rootScope.username = "";
		    $rootScope.password = "";
		/*    var cookies = document.cookie.split(";");
		    for (var i = 0,arrLen = cookies.length; i < arrLen ; i++) {
		        var cookie = cookies[i];
		        var eqPos = cookie.indexOf("=");
		        var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
		        document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
		    }*/
		    $location.path('/loginPage');
	}
	
	/*var noAuth = "false";
	var cookie = document.cookie;
	var cookieAuthParams = cookie.split(';');
	for (var cp1 = 0,arrLen = cookieAuthParams.length; cp1 < arrLen ; cp1++) {*/
		/*if (cookieAuthParams[cp1].split('=')[0].trim() == "configAuth" && cookieAuthParams[cp1].split('=')[1].trim() == "true") {
			noAuth = "true"
		}*/
		if ($rootScope.configAuth == "true") {
			noAuth = "true"
		}
/*	}*/
	if (noAuth == "false") {
		$location.path('/loginPage');
	}

	$scope.executeConfig=function(){
		 ngDialog.close();
//		 $rootScope.$broadcast("brownFieldUpload", {});
		 $rootScope.brownfieldCall();
	};
	
	$scope.stopeExecution=function(){
		 $mdDialog.cancel();
		 ngDialog.close();
	};
	
	
}]);
 

