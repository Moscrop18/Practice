  angular.module('yapp').controller('ConfigFileUploadPage',["ngDialog","Upload","$scope","$rootScope","$http","$mdDialog","$mdMedia","$location","$filter","Idle","$ocLazyLoad",function(ngDialog,Upload,$scope,$rootScope,$http,$mdDialog,$mdMedia,$location,$filter,Idle,$ocLazyLoad) {
   $ocLazyLoad.load(controllerName+'/config/trgSysSelection.js?ver='+version);
  
 //Browser Refresh - 13 Nov 2017
	if($rootScope.appValidity == undefined){
		 $rootScope.username = "";
		    $rootScope.password = "";
		    /*var cookies = document.cookie.split(";");
		    for (var i = 0,arrLen = cookies.length; i < arrLen ; i++) {
		        var cookie = cookies[i];
		        var eqPos = cookie.indexOf("=");
		        var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
		        document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
		    }*/
		    $location.path('/loginPage');
	}
//	$rootScope.viewScopeData =$rootScope.selectedScopeData ;
	/*$rootScope.name2 = "active";  
	//$rootScope.name1 = "not-active"; 
	$rootScope.name3 = "not-active";
	$rootScope.name = "not-active";
	if( $rootScope.implType == "1"){
		$rootScope.name1 = "active1";
	}
	else $rootScope.name1 = "not-active";*/
	var uploadTimeBefore = new Date();
	$scope.fieldErrorMsg = "";
	$scope.fieldError = false;
	$scope.isSuccess = false;
	$rootScope.uploadButtondisabled = true;
	$scope.currentPage = 1;
	$scope.articlesPerPage = 6;
	$rootScope.retryExecution = false;
	if($rootScope.viewScopeData == undefined)
	{
		$rootScope.viewScopeData = [];
	}
	if($rootScope.consolidate == true){
		$rootScope.noteMessage = "File Name format should be 'Seq. no_IMG Description_Table/View Name'. For Ex.. 1_DefineCompany_V_T880.xlsx or 1_DefineCompany-V_T880.XLSX";
	}else if($rootScope.industryFlag){
		$rootScope.noteMessage = "File Name format should be 'Seq. no_IMG Description"+"_"+$rootScope.aliasIndustry+"_"+$rootScope.aliasSubIndustry+"'"+
				". For Ex.. 1_DefineCompany"+"_"+$rootScope.aliasIndustry+"_"+$rootScope.aliasSubIndustry+".xlsx" +" or 1_DefineCompany"+"_"+$rootScope.aliasIndustry+"_"+$rootScope.aliasSubIndustry+".XLSX";
	}
	else{
		$rootScope.noteMessage = "File Name format should be 'Seq. no_IMG Description'. For Ex.. 1_DefineCompany.xlsx or 1_DefineCompany.XLSX";
	}
	// for displaying incorrect config template uploaded
	$rootScope.invalidfile = false;
	var noAuth = "false";
	var homeAuth="false";
	var resetAuth="false"
	$scope.upload = {};
	//$scope.upload.singleFile = "";
	$rootScope.singleUpload = false;
	var myDate = new Date();
    myDate.setHours(myDate.getHours() + 1);
	/*
	var cookie = document.cookie;
	var cookieAuthParams = cookie.split(';');
	for (var cp1 = 0,arrLen = cookieAuthParams.length; cp1 < arrLen ; cp1++) {*/
		/*if (cookieAuthParams[cp1].split('=')[0].trim() == "configAuth" && cookieAuthParams[cp1].split('=')[1].trim() == "true") {
			noAuth = "true"
		}*/
		if ($rootScope.configAuth == "true") {
			noAuth = "true"
		}
		if ($rootScope.fileUploadAuth == "true") {
			homeAuth="true";
			$rootScope.fileUploadAuth = resetAuth;
			//document.cookie = "fileUploadAuth=" + resetAuth + ";expires=" + myDate.toUTCString();
		}
	/*	if (cookieAuthParams[cp1].split('=')[0].trim() == "fileUploadAuth" && cookieAuthParams[cp1].split('=')[1].trim() == "true") {
			homeAuth="true"
			document.cookie = "fileUploadAuth=" + resetAuth + ";expires=" + myDate.toUTCString();
		}*/
/*	}*/
		
	if($rootScope.appValidity != undefined){
		if (noAuth == "false") {
			$location.path('/loginPage');
		}else if(homeAuth=="false"){
	//		$location.path('/ConfigHeader/configPage');
			$location.path('/configTilesPage');
		}
	}
/*Adding for dynamically loading rows in table*/
	/*$scope.barLimit = 10;
    $scope.increaseLimit = function() {
      $scope.barLimit += 20;
      
    }*/
    
	$scope.barLimit1 = 10;
    $scope.increaseLimit1 = function() {
      $scope.barLimit1 += 20;    
    }
   
//	$scope.modalShown = false;
	
			//Enable Upload Button while file select
	 /* $scope.fileSelect = function(){
		  $scope.uploadButtondisabled = false;
	  }*/
	
	//Upload Single File	
		$rootScope.uploadSingleFile = function (singleFile) {
			
			 $scope.uploadedList = [];
			index = -1;
			var validFileName;
			var scopeData;
			$rootScope.fileListError=[];
			/* if($rootScope.selectedScopeData [$rootScope.selectedFileRow].isMasterData == "Y")
				 validFileName = $rootScope.selectedScopeData [$rootScope.selectedFileRow].imgDescription;
			 else*/
			
			if($rootScope.industryFlag  &&  !$rootScope.consolidate){
				  validFileName=$rootScope.selectedScopeData [$rootScope.selectedFileRow].sequence+"_"+$rootScope.selectedScopeData [$rootScope.selectedFileRow].imgDescription+"_"+$rootScope.aliasIndustry+"_"+$rootScope.aliasSubIndustry;
			  }else{
				  validFileName =$rootScope.selectedScopeData [$rootScope.selectedFileRow].sequence+"_"+$rootScope.selectedScopeData [$rootScope.selectedFileRow].imgDescription;
			  }
				
				if(validFileName.replace(/[^a-zA-Z0-9]/ig, "").toLowerCase() == singleFile[0].name.split(".xlsx")[0].replace(/[^a-zA-Z0-9]/ig, "").toLowerCase()){
					index = $rootScope.selectedFileRow;
			}
				else if(validFileName.replace(/[^a-zA-Z0-9]/ig, "").toLowerCase() == singleFile[0].name.split(".XLSX")[0].replace(/[^a-zA-Z0-9]/ig, "").toLowerCase()){
					index = $rootScope.selectedFileRow;
			}
				else if(validFileName.replace(/[^a-zA-Z0-9]/ig, "").toLowerCase() == singleFile[0].name.split(".xls")[0].replace(/[^a-zA-Z0-9]/ig, "").toLowerCase()){
					index = $rootScope.selectedFileRow;
			}
				else if(validFileName.replace(/[^a-zA-Z0-9]/ig, "").toLowerCase() == singleFile[0].name.split(".XLS")[0].replace(/[^a-zA-Z0-9]/ig, "").toLowerCase()){
					index = $rootScope.selectedFileRow;
			}
			$scope.isSuccess = false;
			if(index > -1){
				$scope.uploadedList.push(singleFile[0].name);
			$rootScope.selectedScopeData [index].fileName = singleFile[0].name;
			$scope.callUpload(singleFile,singleFile);
			$rootScope.FileList =$rootScope.selectedScopeData ;
			$rootScope.selectedScopeData [index].fileUploadedIcon = "glyphicon glyphicon-ok";
		}else{
			$scope.isSuccess = false;
			//$scope.fieldError = false;
		//$scope.fileErrorMsg = "Incorrect Template uploaded. Please choose correct file for "+$rootScope.selectedScopeData [$rootScope.selectedFileRow].imgDescription;
		ngDialog.openConfirm({
            template: '<p margin-top:7%>'+"Incorrect Template uploaded. Please choose correct file for "+$rootScope.selectedScopeData [$rootScope.selectedFileRow].imgDescription+'</p>',
            plain: true,
            scope: $scope,
            closeByDocument: false,
            closeByEscape: false,
            showClose: true,
            height: 110,
            width: 350
        });
		}
    	ngDialog.close();
	}
		$rootScope.uploadfiles = function(files){
			 $scope.filestore = files;
			 if(files.length>$rootScope.selectedScopeData.length){
			ngDialog.openConfirm({
	            template: 'view/config/fileupldconfirm.html?ver='+version,
	            //controller:'ConfigInitialPage',
	            scope: $scope,
	            closeByDocument: false,
	            closeByEscape: false,
	            showClose: true,
	            height: 200,
	            width: 527
	        });			
		}
			 else $rootScope.uploadExcelFiles(files);
		}
	
	//Upload Multiple File
	 $rootScope.uploadExcelFiles = function (files) {
		 ngDialog.close();
		 $scope.isSuccess = false;
		 $scope.fieldError = false;
	        $scope.noTextVisibility=false;
	        var allfiles=[];
	        var count = 0;
	        $rootScope.fileListError=[];
	        $scope.uploadedList = [];
	        if (files && files.length) {
	            for (var i = 0,fileLen  = files.length; i < fileLen ; i++) {
	            	  index = -1;
	        		  for(var a= 0,arrLen = $rootScope.selectedScopeData.length;a< arrLen ;a++){
	        			  var validFileName;
	        		  
	        				 /*if($rootScope.selectedScopeData [a].isMasterData == "Y")
	        					 validFileName = $rootScope.selectedScopeData [a].imgDescription;
	        				 else*/
	        			  
	        			  if($rootScope.industryFlag &&  !$rootScope.consolidate){
	        				  validFileName=$rootScope.selectedScopeData [a].sequence+"_"+$rootScope.selectedScopeData [a].imgDescription+"_"+$rootScope.aliasIndustry+"_"+$rootScope.aliasSubIndustry;
	        			  }else{
	        				  validFileName =$rootScope.selectedScopeData [a].sequence+"_"+$rootScope.selectedScopeData [a].imgDescription;
	        			  }
	        					
	        				 
	        			//filename is correct in format	 
	        		  	if(validFileName.replace(/[^a-zA-Z0-9]/ig, "").toLowerCase() === files[i].name.split(".xlsx")[0].replace(/[^a-zA-Z0-9]/ig, "").toLowerCase()){
	        		  		index = a;
	        		  		count++;
	        		  		break;
	        		  	}
	        		  	else if(validFileName.replace(/[^a-zA-Z0-9]/ig, "").toLowerCase() === files[i].name.split(".XLSX")[0].replace(/[^a-zA-Z0-9]/ig, "").toLowerCase()){
	        		  		index = a;
	        		  		count++;
	        		  		break;
	        		  	}
	        			else if(validFileName.replace(/[^a-zA-Z0-9]/ig, "").toLowerCase() === files[i].name.split(".XLS")[0].replace(/[^a-zA-Z0-9]/ig, "").toLowerCase()){
	        		  		index = a;
	        		  		count++;
	        		  		break;
	        		  	}
	        			else if(validFileName.replace(/[^a-zA-Z0-9]/ig, "").toLowerCase() === files[i].name.split(".xls")[0].replace(/[^a-zA-Z0-9]/ig, "").toLowerCase()){
	        		  		index = a;
	        		  		count++;
	        		  		break;
	        		  	}
	        		  }
	        			//
	    	    	
	            	if(index > -1){
	            	$rootScope.correctFilesUploaded = true;
	            	$scope.uploadedList.push(files[i].name);
	            	$rootScope.selectedScopeData [index].fileName = files[i].name;
	            	$rootScope.selectedScopeData [index].seq = count++; 
	            	$rootScope.selectedScopeData [index].fileUploadedIcon = "glyphicon glyphicon-ok";//Added for File Upload Icon 
	            	}
	            	else
	            		{
	            		//$rootScope.invalidfile = false;
		        		//$rootScope.wrongformat = true;
	            		$rootScope.correctFilesUploaded = false;
	            		$scope.errorheading = "Wrong files are uploaded for the selected Scopes";
	            		$scope.uploaderrormsg = "Below Scopes are missing for the uploaded files";
	            		var fileerror = [];
	            		fileerror.sequence = i+1;
	            		fileerror.fileNameFormat = files[i].name;
	            		$rootScope.fileListError.push(fileerror);
		            	}
	            	
	            	  allfiles.push(files[i]); 
	            	}
	         }
	        if($rootScope.correctFilesUploaded)
	        $scope.callUpload(allfiles,files); 
	        else
	        	 $scope.configTempValidate();
	        
	    }  
	 $scope.okfileupld = function(){
		 var allfiles=[];
		  allfiles.push(files[i]);  
		  $scope.callUpload(allfiles,files);
	 }
	 $scope.cancelupload = function(){
		 ngDialog.close();
		 
	};
	 //Call service and upload files in Server 
	    $scope.callUpload = function(allfiles,files){
	    	var uploadTimeLater = new Date();
	    	 //$scope.configTempValidate();
	    	//if(	$rootScope.correctfileContent){
	        var uploadUrl = "/" + servicePrefix + "/rest/files/multipleUpload/S4IMGConfigTemplates";
	        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
	        var overlay = document.getElementById("overlay");
	        var popup = document.getElementById("busy");
	        overlay.style.display = "block";
	        busy.style.display = "inline-block";

	   
	     
	            files.upload = Upload.upload({
	                method: 'POST',
	                url:         uploadUrl,
	                data:      {files: allfiles}
	            });
	            files.upload.then(function(responseData) {
	           	 if(uploadTimeLater.getMinutes() - uploadTimeBefore.getMinutes() == 24){
        			 var inputParam = {
        			  			sessionId : $rootScope.sessionInputObj.sessionId,
        			  			csrfToken : $rootScope.sessionInputObj.csrfToken
        			  	}
        			  $http.post("/" + servicePrefix + "/rest/adminSrv/resetSessionTime", inputParam).then(function(response) {
        				  if(response.status == 200){
        					if(response.data.dataStatus == true){
        						//Idle.setIdle();
        						uploadTimeBefore = new Date();
        						console.log("Session extended");
        					}
        					}
        			  });
        		 }
	                $scope.fileUploadSuccess(responseData);
	            }, function (data) {
	                $scope.fileUploaderror(data);
	            });
	    	//}
	    };
	    
	    //File upload Success Message
	    $scope.fileUploadSuccess = function(responseData){
	       // $mdDialog.cancel();
	    	 var overlay = document.getElementById("overlay");
		     var popup = document.getElementById("busy");
		     overlay.style.display = "none";
		     busy.style.display = "none";

	        var data;
	        var filePath = [];
	        //data = responseData.data.filePathList;
	        data = responseData.data.fileBytesList;
//	        console.log(data.length);
	        $rootScope.FileList = [];
	        for(var i=0;i<data.length;i++){
	        
          	 // index = -1;
    		  for(var a = 0;a <$rootScope.selectedScopeData .length;a++){
    			  if($rootScope.selectedScopeData [a].fileName.indexOf(responseData.data.fileNameList[i]) >= 0){//Fix for file - 49_Define Profit Center Standard Hierarchy In Controlling Area.xlsx
    		  		index = a;
    		  		break;
    		  	}
    		  }
        	
            	if(index > -1){
            	//$rootScope.selectedScopeData [index].filepath = data[i];
            	 $rootScope.selectedScopeData [index].fileBytes = data[i];
            	}
	      //  	 filePath.push(data[i]); 
	        }
	        
//	        console.log($rootScope.selectedScopeData );
	        $scope.configTempValidate();
	        //$rootScope.filePathList = filePath;
	    }
	    
	    //File upload Error Message
	    $scope.fileUploaderror = function(data){
	    	  $mdDialog.cancel();
	    
	    }
	
	    //Validate Mandatory fields before execute 
	    $scope.fileUploadValidation = function () {
	    		/*if($rootScope.selectedScopeData .length > 0 ){*/
	    		$scope.isValid = true;
	    		$rootScope.fileListError=[];
	    		for (var i = 0; i <$rootScope.selectedScopeData.length; i++) {
//	    			console.log( $rootScope.FileList[i].fileName);
	    			//if($rootScope.selectedScopeData [i].fileName == "" || $rootScope.selectedScopeData [i].filepath == "")
	    			if($rootScope.selectedScopeData [i].fileName == "" )
	    				{
	    				$scope.isValid = false;
	    				var scopeData = $rootScope.selectedScopeData [i];
	    				
	    				 var validFileName;
	    				 
	    				 if($rootScope.industryFlag  &&  !$rootScope.consolidate){
	    					 if($rootScope.selectedScopeData [i].isMasterData == "Y"){
	    						 validFileName = $rootScope.selectedScopeData [i].imgDescription+"_"+$rootScope.aliasIndustry+"_"+$rootScope.aliasSubIndustry;
	    					 }else{
	    						 validFileName=$rootScope.selectedScopeData [i].sequence+"_"+$rootScope.selectedScopeData [i].imgDescription+"_"+$rootScope.aliasIndustry+"_"+$rootScope.aliasSubIndustry;
	    					 }
	        				  
	        			  }
	    				 else{
	    					
		    				if($rootScope.selectedScopeData [i].isMasterData == "Y"){
		    					 validFileName = $rootScope.selectedScopeData [i].imgDescription;
		    				 }else{
		    					 validFileName = $rootScope.selectedScopeData [i].sequence+"_"+$rootScope.selectedScopeData [i].imgDescription;
		    				 }
	    				 } 
	    				 scopeData.fileNameFormat = validFileName;
	    				$rootScope.fileListError.push(scopeData);
	    				$scope.isValid = false;
	    				}}
	    				
	    		if($rootScope.hierarchyTypes.value == "Business Process"){
	    		if($scope.isValid === true){
	    		$scope.fieldError = false;
	    		$scope.fileUploadNext();
	    		}else{
			
	    			if($rootScope.fileListError.length>0){
		    			$scope.errorheading = "Required Files";
	            		$scope.uploaderrormsg = "Choose correct File Name Format as like below for missing scope";
		    			ngDialog.openConfirm({
		    	            template: 'view/config/filelistError.html?ver='+version,
		    	            //controller:'ConfigInitialPage',
		    	            scope: $scope,
		    	            closeByDocument: false,
		    	            closeByEscape: false,
		    	            showClose: true,
		    	            height: 487,
		    	            width: 732
		    	        });
	    			}
	    	    	
	    			}
	    		}
	    		else{
	    		 	
		    		if($scope.isValid === true){
		    		$rootScope.uploadedScopes = $rootScope.selectedScopeData.filter(function(obj) { return $rootScope.fileListError.indexOf(obj) == -1; });
		    	    	
		    		$scope.fieldError = false;
		    		if($rootScope.implType == "2" || $rootScope.implType == "3")
		    		{
		    		$scope.targetSysDialog();
		    		if($rootScope.modTypes.value == "Automated with intervention"){
		    			$rootScope.name = "not-active";
		 	    		$rootScope.name1 = "not-active";
		 	    		$rootScope.name2 = "not-active";  
		 	    		$rootScope.name3 = "active";
		 	    		
		 	    		$rootScope.wizard1  = "donewizard";
						 $rootScope.wizard2  = "donewizard";
						 $rootScope.wizard3  = "donewizard";
						 $rootScope.wizard4  = "activewizard";
		    			}
		    		}
		    		else
		    			{
		    			if($rootScope.implType == "1"){
		    				$rootScope.name = "not-active";
			 	    		$rootScope.name1 = "active1";
			 	    		$rootScope.name2 = "not-active";  
			 	    		$rootScope.name3 = "active";
			 	    		
			 	    		$rootScope.wizard1  = "donewizard";
							 $rootScope.wizard2  = "disablewizard";
							 $rootScope.wizard3  = "donewizard";
							 $rootScope.wizard4 = "activewizard";
					 	   		
			    			 $rootScope.retrieveScopeTR();
		    	    	}
		    			}
		    		}else{
//	    	    			$scope.fieldErrorMsg = "File is not saved in server";
	    	    	    	//$scope.fieldError = true;
	    	    	    	//$scope.isSuccess = false;
	    	    			$scope.errorheading = "Required Files";
	                		$scope.uploaderrormsg = "Choose correct File Name Format as like below for missing scope";
	    	    			ngDialog.openConfirm({
	    	    	            template: 'view/config/filelistError.html',
	    	    	            //controller:'ConfigInitialPage',
	    	    	            scope: $scope,
	    	    	            closeByDocument: false,
	    	    	            closeByEscape: false,
	    	    	            showClose: true,
	    	    	            height: 500,
	    	    	            width: 732
	    	    	        });
	    	    	    	
	    	    		}
	    	    }
	    	
 }
	    $scope.fileUploadNext = function()
	    {
	    	//$rootScope.fileListError
	    	
	    	$rootScope.uploadedScopes = $rootScope.selectedScopeData.filter(function(obj) { return $rootScope.fileListError.indexOf(obj) == -1; });
	    	
	    	ngDialog.close();
	    	if($rootScope.implType == "2" || $rootScope.implType == "3")
    		{
    		$scope.targetSysDialog();
    		if($rootScope.modTypes.value == "Automated with intervention"){
    			$rootScope.name = "not-active";
 	    		$rootScope.name1 = "not-active";
 	    		$rootScope.name2 = "not-active";  
 	    		$rootScope.name3 = "active";
 	    		
 	    		$rootScope.wizard1  = "donewizard";
				 $rootScope.wizard2  = "donewizard";
				 $rootScope.wizard3  = "donewizard";
				 $rootScope.wizard4  = "activewizard";
    			}
    		}
    		else
    			{
    			if($rootScope.implType == "1"){
    				$rootScope.name = "not-active";
	 	    		$rootScope.name1 = "active1";
	 	    		$rootScope.name2 = "not-active";  
	 	    		$rootScope.name3 = "active";
	 	    		
	 	    		$rootScope.wizard1  = "donewizard";
					 $rootScope.wizard2  = "disablewizard";
					 $rootScope.wizard3  = "donewizard";
					 $rootScope.wizard4 = "activewizard";
			 	   		
	    			$rootScope.retrieveScopeTR();
    	    	}
    			}
	    }
	    $scope.fileUploadPrevious = function()
	    {
	    	ngDialog.close();
	    	$location.path('/ConfigHeader/fileUpload'); 	

	    }
	    //Single Upload File View 
	    $scope.fileChange = function(val){
//	    	console.log(val);
	    	$rootScope.singleUpload = true;
	    	if($rootScope.consolidate){
	    		ngDialog.openConfirm({
		            template: 'view/config/SingleFileUpload.html?ver='+version,
		            controller:'ConsolidationInitialPage',
		            scope: $scope,
		            closeByDocument: false,
		            closeByEscape: false,
		            showClose: true,
		            height: 200,
		            width: 500
		        });
	    	}else{
	    	ngDialog.openConfirm({
	            template: 'view/config/SingleFileUpload.html?ver='+version,
	            controller:'ConfigInitialPage',
	            scope: $scope,
	            closeByDocument: false,
	            closeByEscape: false,
	            showClose: true,
	            height: 200,
	            width: 500
	        });
	    }
	  
	    	$rootScope.selectedFileRow = val;
	    	
	    };

	    $scope.filePrevious = function(){
    		if($rootScope.implType == "1"){
    			//Config page
    			 $rootScope.wizard1  = "activewizard";
				 $rootScope.wizard2  = "disablewizard";
				 $rootScope.wizard3  = "applicablewizard";
				 $rootScope.wizard4  = "applicablewizard";
				 
		/*		 $rootScope.wizardDiv1 = "wizardcircleDivActive";
				 $rootScope.wizardDiv2 = "wizardcircleDivApp";
				 $rootScope.wizardDiv3 = "wizardcircleDivApp";*/
		 	   		
			 	 $rootScope.implTypelabel = "secondImplType";
				 $rootScope.implTypelabel2 = "defaultImplType";
				 $rootScope.implTypelabel3 = "defaultImplType";
					
				 $rootScope.name  = "active";
		 	     $rootScope.name1 = "active1";
		 	     $rootScope.name2 = "not-active";  
		 	     $rootScope.name3 = "not-active";	
    			
		 	    if($rootScope.consolidate == true){
		 	    	 $location.path("/ConfigHeader/consolidationPage");
		 	    }else{
		 	    	$location.path('/ConfigHeader/configPage');
		 	    }
		 	}
    		else {
    			//Download Page
    			if($rootScope.implType == "2" || $rootScope.implType == "3"){
    				if($rootScope.modTypes.value == "Automated with intervention"){
    					 $rootScope.wizard1  = "donewizard";
						 $rootScope.wizard2  = "activewizard";
						 $rootScope.wizard3  = "applicablewizard";
						 $rootScope.wizard4 = "applicablewizard";
				/*		 
						 $rootScope.wizardDiv1 = "wizardcircleDivActive";
						 $rootScope.wizardDiv2 = "wizardcircleDivApp";
						 $rootScope.wizardDiv3 = "wizardcircleDivApp";*/
						 
						 $rootScope.name  = "not-active";
				 	     $rootScope.name1 = "active";
				 	     $rootScope.name2 = "not-active";  
				 	     $rootScope.name3 = "not-active";
				 	     
		    			var myDate = new Date();
			           // myDate.setHours(myDate.getHours() + 1);
			      	  	$rootScope.fileDownloadAuth = "true";
			      	  	//document.cookie = "fileDownloadAuth=" + $rootScope.fileDownloadAuth + ";expires=" + myDate.toUTCString();
		    			$location.path('/ConfigHeader/fileDownload');
    				}
    		}	
    	}
    }
	    
	    
	    $scope.targetSysDialog = function(){	
		 	  ngDialog.openConfirm({
		 		  template: 'view/config/trgSysSelection.html?ver='+version,
	              controller: 'trgSysSelectionController',
	              className:'ngdialog-theme-default CLASS_trgSys',
	              scope: $scope,
	              closeByDocument: false,
	              closeByEscape: false,
	              showClose: true,
	              height:"auto",
	              width: 400
	          }).then(function() {
	             
	          });
	 		}
	
	    
	    //Config Template Validation
	    $scope.configTempValidate = function(){
	    	$rootScope.invaliduploadedlist =[];
	    	  var  uploadUrl;
	    	  if($rootScope.consolidate == true){
	    		  uploadUrl = "/" + servicePrefix + "/rest/files/configTempalteValidationConsolidation";
	    	  }else{
	    		  uploadUrl = "/" + servicePrefix + "/rest/files/configTempalteValidation";
	    	  }
	        var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
	        var overlay = document.getElementById("overlay");
	        var popup = document.getElementById("busy");
	        overlay.style.display = "block";
	        busy.style.display = "inline-block";

	        var uploadArray = {};
	        uploadArray.currentFileList = $scope.uploadedList;
	        uploadArray.selectedScopeList =$rootScope.selectedScopeData ;
	        uploadArray.sessionInputDTO = $rootScope.sessionInputObj;	
	        uploadArray.industryFlag=$rootScope.industryFlag;
            if($rootScope.industryFlag){
            	uploadArray.industry=$rootScope.selectedIndustry;
            	uploadArray.subIndustry=$rootScope.selectedsubIndustry;
            }

	        $http.post(uploadUrl,uploadArray).then(function(responseData){
	        	if(responseData.data.resMessageDto != null && responseData.data.resMessageDto.message == serviceMessage){
      	      		$rootScope.checkAuthorization();
      	      	}else{
	        	var responseData = responseData.data;
	        	 //$mdDialog.cancel();
	        	 var overlay = document.getElementById("overlay");
	    	     var popup = document.getElementById("busy");
	    	     overlay.style.display = "none";
	    	        busy.style.display = "none";


	        	 var output = [];
		        	for(var a = 0,arrLen = responseData.configTemplateDto.length;a < arrLen ;a++){
		        		output.push(responseData.configTemplateDto[a].selectedScopeDto);
		        	}
		        	$rootScope.selectedScopeData  = output;
		        	//$rootScope.correctfileContent = true;
	        	 if(!responseData.uploadStatus){
		        		
			        	//console.log($rootScope.selectedScopeData );
			        	//$rootScope.invalidfile = true;
		        		//$rootScope.wrongformat = false;
		        		$scope.invalidheading = "Wrong template uploaded";
		        		$scope.uploadinvalidmsg = "Please upload template with below corrections";
		        	var invaliduploaded = [];
		        	
		        	for(var a = 0,arrLen = responseData.configTemplateDto.length;a < arrLen ;a++){
		        		if(responseData.configTemplateDto[a].status == false){
		        			invaliduploaded = [];
		        			invaliduploaded.imgdesc =  responseData.configTemplateDto[a].selectedScopeDto.imgDescription;
		        			invaliduploaded.msg = responseData.configTemplateDto[a].statusMsg;
		        		
		        			$rootScope.invaliduploadedlist.push(invaliduploaded);
		        			}
		        		}
		        	//$rootScope.correctfileContent = false;
		        	}
		        
		        	$scope.listError(); 
      	      	}
      	      	}) ,(function(data){

            	 $mdDialog.cancel();
            	//Remove all file name and path
            	for(var i = 0,fileLen = $scope.uploadedList.length; i < fileLen ;i++){
          		  for(var a = 0,arrLen = $rootScope.selectedScopeData.length;a < arrLen ;a++){
          			  if($scope.uploadedList[i].name == $rootScope.selectedScopeData[a].fileName){
	          			$rootScope.selectedScopeData[a].fileName = "";
	          			$rootScope.selectedScopeData[a].filepath = "";
	          			$rootScope.selectedScopeData[a].fileUploadedIcon = "glyphicon glyphicon-remove";
	          			break;
          			  }
          		  }
            	}
            	$scope.listError();
            });
	    }
	    
	    $scope.listError = function(){
	    	
	    	if($rootScope.fileListError.length>0){
	        	ngDialog.openConfirm({
		            template: 'view/config/filelistError.html?ver='+version,
		            //controller:'ConfigInitialPage',
		            scope: $scope,
		            closeByDocument: false,
		            closeByEscape: false,
		            showClose: true,
		            height: 500,
		            width: 732
		        });
		    }       
	        $rootScope.FileList =$rootScope.selectedScopeData ;
	    };
	    
	    $scope.viewErrors = function(logs,imgDescription){
	    	
	    	$scope.errorLogData =[];

	    	$scope.scopeDescription = imgDescription;
	
  		
	    	for(var k=0 ; k <logs.length ;k++){
    			//if(logs[k].imgDesc === imgDescription){
    	    		var bData1 = {
    		    		 "SNO": k+1,
    	                 "Description": logs[k]
                    
                     
                    
                  };  
	    			$scope.errorLogData.push(bData1);
	    			 bData1 = {};
    	    	//}
    			
    			
    		}
			 ngDialog.openConfirm({
	            template: 'view/config/viewFileUploadError.html?ver='+version,
	            //controller:'ConfigExecutePage',
	            scope: $scope,
	            closeByDocument: false,
	            closeByEscape: false,
	            showClose: true,
	            height: 500,
	            width: 732
	        });
  		
	    	
	    };

	    
}]);
