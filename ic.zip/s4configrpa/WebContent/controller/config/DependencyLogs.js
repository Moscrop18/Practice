angular.module('yapp').controller('dependencyScopeController',["ngDialog","Upload","$scope","$rootScope","$http","$mdDialog","$mdMedia","$location","$filter","$state","$ocLazyLoad", function(ngDialog,Upload,$scope,$rootScope,$http,$mdDialog,$mdMedia,$location,$filter,$state,$ocLazyLoad) {
	$ocLazyLoad.load(controllerName+'/config/DependencyLogs.js?ver='+version); 
	$ocLazyLoad.load(controllerName+'/config/ScopeLogs.js?ver='+version);
	//Browser Refresh - 13 Nov 2017
	if($rootScope.appValidity == undefined){
		   $rootScope.username = "";
		    $rootScope.password = "";
		 /*   var cookies = document.cookie.split(";");
		    for (var i = 0,arrLen = cookies.length; i < arrLen ; i++) {
		        var cookie = cookies[i];
		        var eqPos = cookie.indexOf("=");
		        var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
		        document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
		    }*/
		    $location.path('/loginPage');
	    
	}
	/*var noAuth = "false";
	var cookie = document.cookie;
	var cookieAuthParams = cookie.split(';');
	for (var cp1 = 0,arrLen = cookieAuthParams.length; cp1 < arrLen ; cp1++) {*/
		/*if (cookieAuthParams[cp1].split('=')[0].trim() == "configAuth" && cookieAuthParams[cp1].split('=')[1].trim() == "true") {
			noAuth = "true"
		}*/
		if ($rootScope.configAuth == "true") {
			noAuth = "true"
		}
	/*}*/
	if (noAuth == "false") {
		$location.path('/loginPage');
	}


	$scope.skipAndExecute=function(){
		 ngDialog.close();
//		 $scope.downloadScopeList();
		 if( $rootScope.implType == "1"){
//			 $rootScope.$broadcast("CallexecuteMethod", {});
			 $rootScope.confirmExecution();
			 
			}else if($rootScope.implType == "2" || $rootScope.implType == "3"){
				
				if($rootScope.modTypes.value == "Automated without intervention"){
//					$rootScope.$broadcast("CallscopeAvilabilityInSource", {});
					$rootScope.scopeAvilabilityInSource();
					
				}else if($rootScope.modTypes.value == "Automated with intervention"){
					$rootScope.confirmExecution();
				}
				
			}
//		 $rootScope.$emit("CallscopeAvilabilityInSource", {});
//		 $rootScope.$emit("CallexecuteMethod", {});
	};
	
	$scope.stopeExecution=function(){
		 ngDialog.close();
//		 $scope.executeListener();
	};
	
    $scope.downloadScopeList = function(){
    	
    	ngDialog.openConfirm({
            template: 'view/config/ScopeLogs.html?ver='+version,
            controller:'downloadScopeController',
            scope: $scope,
            closeByDocument: false,
            closeByEscape: false,
            showClose: false,
            height: 490,
            width: 640
        });
    };
	  
	
}]);
 

