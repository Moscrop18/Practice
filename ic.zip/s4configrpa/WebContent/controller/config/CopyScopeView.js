angular.module('yapp').controller('CopyConfigScopeTreeView',["ngDialog","Upload","$scope","$rootScope","$http","$mdDialog","$mdMedia","$location","$filter","$state","$ocLazyLoad", function(ngDialog,Upload,$scope,$rootScope,$http,$mdDialog,$mdMedia,$location,$filter,$state,$ocLazyLoad) {
       
	//Browser Refresh - 13 Nov 2017
	if($rootScope.appValidity == undefined){
		   $rootScope.username = "";
		    $rootScope.password = "";
		    
	/*	    var cookies = document.cookie.split(";");
		    for (var i = 0,arrLen = cookies.length; i < arrLen ; i++) {
		        var cookie = cookies[i];
		        var eqPos = cookie.indexOf("=");
		        var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
		        document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
		    }*/
		    $location.path('/loginPage');
	    
	}
	$rootScope.TempselectedTreeviewData1=[];
//     $scope.selectedTreeviewData = $rootScope.selectedScopeData;
       
       if($rootScope.selectedScopeData == undefined)
       {
              $rootScope.selectedScopeData = [];
       } 
        angular.copy($rootScope.selectedScopeData,$rootScope.TempselectedTreeviewData1);
//     $scope.selectedTreeviewData = $rootScope.selectedScopeData;
       
       var noAuth = "false";
      /* var cookie = document.cookie;
       var cookieAuthParams = cookie.split(';');
       for (var cp1 = 0,arrLen = cookieAuthParams.length; cp1 < arrLen ; cp1++) {*/
            /*  if (cookieAuthParams[cp1].split('=')[0].trim() == "configAuth" && cookieAuthParams[cp1].split('=')[1].trim() == "true") {
                     noAuth = "true"
              }*/
              if ($rootScope.configAuth == "true") {
      			noAuth = "true"
      		}
       /*}*/
       if (noAuth == "false") {
              $location.path('/loginPage');
       }

$scope.onCancel=function()
       {

              ngDialog.close();
       };
       $scope.save=function(){
              $rootScope.validClose = true;
              ngDialog.close();
       };
       
             /*
             $scope.toggleAllCheckboxes = function($event) {
               var i, item, len, ref, results, selected;
               selected = $event.target.checked;
               ref =  $rootScope.list;
               results = [];
               for (i = 0, len = ref.length; i < len; i++) {
                 item = ref[i];
                 item.selected = selected;
                
                 if (item.children != null) {
                   results.push($scope.$broadcast('changeChildren', item));
                  
                 } else {
                   results.push(void 0);
                 }
               }
               return results;
             };
             
            $scope.initCheckbox = function(item, parentItem) {
              // return item.selected = parentItem && parentItem.selected ||$scope.validatecheck(item) || item.selected || false;
               
                item.selected=$scope.validatecheck(item);
                for (var i in parentItem.children) {
                    if (!parentItem.children[i].isChecked) {
                      allChecks = false;
                      break;
                    }
                if(item.selected)
             {
              var allChecks = true;
              for (var i in parentItem.children) 
              {
                           if (!parentItem.children[i].selected) {
                                         allChecks = false;
                                         break;
                                  }
              }
                           if (allChecks) {
                                                              parentItem.selected = true;
                                                       }
                                  else {
                                                       parentItem.selected = false;
                                         }

             }
                return item.selected;
              
             };
             $scope.validatecheck=function(item)
             {
                
                var selectedValue=true;
                var aIndex = $rootScope.scopevalueArray.indexOf(item.imgId);
                if(aIndex>-1)
                       { 
                       
                       var bData = {};
                       if(item.imgId.length > 0){
                              
                              bData.imgId = item.imgId;
                              bData.imgDescription = item.imgDescription;
                              bData.sequence = item.sequence;
                              bData.enabled = item.enabled;
                              bData.fileName = "";
                              bData.filepath = "";
                              bData.isMasterData = item.isMasterData;
                              bData.logs = [];
                              bData.status = "status-pending";
                              if(selectedValue === true){
//                                  index = $scope.selectedTreeviewData.findIndex(x => x.imgId == bData.imgId);
//                                  console.log($scope.selectedTreeviewData);

                                     index = -1;
                                     for(var a= 0;a<$rootScope.selectedScopeData.length;a++){
                                          if($rootScope.selectedScopeData[a].imgId == bData.imgId){
                                                 index = a;
                                                 break;
                                          }
                                     }
                                     
                                     if (index == -1) {
                                           if(bData.enabled=="1"){
                                           $rootScope.selectedScopeData.push(bData);
                                           }
//                                        $scope.selectedTreeviewData.splice(index, 1);
                                         }
                                     
                              }
                             
                              else if(selectedValue === false){
//                                  index = $scope.selectedTreeviewData.findIndex(x => x.imgId == bData.imgId);
                                     
                                     index = -1;
                                     for(var a= 0;a<$rootScope.selectedScopeData.length;a++){
                                          if($rootScope.selectedScopeData[a].imgId == bData.imgId){
                                                 index = a;
                                                 break;
                                          }
                                     }
                                     
//                                  console.log($scope.selectedTreeviewData);
                                     if (index > -1) {
                                           $rootScope.selectedScopeData.splice(index, 1);
                                         }
                              }
                       }else {
                              for(var x = 0;x < item.children.length; x++){
                              $scope.selectedMethod(item.children[x],selectedValue);
                              }
                       }
                       
                       return true
                       }
                else
                return false;
                
             };
             $scope.selectedMethod = function(item,selectedValue){
                var bData = {};
                if(item.imgId.length > 0){
                       
                       bData.imgId = item.imgId;
                       bData.imgDescription = item.imgDescription;
                       bData.sequence = item.sequence;
                       bData.enabled = item.enabled;
                       bData.fileName = "";
                       bData.filepath = "";
                       bData.isMasterData = item.isMasterData;
                       bData.logs = [];
                       bData.status = "status-pending";
                       if(selectedValue === true){
//                            index = $scope.selectedTreeviewData.findIndex(x => x.imgId == bData.imgId);
//                            console.log($scope.selectedTreeviewData);

                              index = -1;
                              for(var a= 0;a<$rootScope.selectedScopeData.length;a++){
                                   if($rootScope.selectedScopeData[a].imgId == bData.imgId){
                                          index = a;
                                          break;
                                   }
                              }
                              
                              if (index == -1) {
                                    if(bData.enabled=="1"){
                                    $rootScope.selectedScopeData.push(bData);
                                    }
//                                  $scope.selectedTreeviewData.splice(index, 1);
                                  }
                              
                       }
                      
                       else if(selectedValue === false){
//                            index = $scope.selectedTreeviewData.findIndex(x => x.imgId == bData.imgId);
                              
                              index = -1;
                              for(var a= 0;a<$rootScope.selectedScopeData.length;a++){
                                   if($rootScope.selectedScopeData[a].imgId == bData.imgId){
                                          index = a;
                                          break;
                                   }
                              }
                              
//                            console.log($scope.selectedTreeviewData);
                              if (index > -1) {
                                    $rootScope.selectedScopeData.splice(index, 1);
                                  }
                       }
                }else {
                       for(var x = 0;x < item.children.length; x++){
                       $scope.selectedMethod(item.children[x],selectedValue);
                       }
                }
                
                
             };
             
             $scope.toggleCheckbox = function(item, parentScope) {

                $scope.selectedMethod(item,item.selected); 

                $rootScope.scopevalue = "";
                $rootScope.scopevalueArray=[];
//              $rootScope.selectedScopeData = $scope.selectedTreeviewData;
                $rootScope.selectedScopeData.sort(function(a, b) {
                         return parseInt(a.sequence) - parseFloat(b.sequence);
                     });
for(var x = 0; x < $rootScope.selectedScopeData.length; x++){
                       if($rootScope.selectedScopeData[x].enabled =="1"){
                       if(x == 0){
                             $rootScope.scopevalue = $rootScope.selectedScopeData[x].imgId;
                             $rootScope.scopevalueArray.push($rootScope.selectedScopeData[x].imgId);
                       }
                       else{
                             $rootScope.scopevalue = $rootScope.scopevalue.concat(";",$rootScope.selectedScopeData[x].imgId);
                             $rootScope.scopevalueArray.push($rootScope.selectedScopeData[x].imgId); 
                       }
                             
                }
                }

               if (item.children != null) {
                 $scope.$broadcast('changeChildren', item);
               }
               if (parentScope.item != null) {
                 return $scope.$emit('changeParent', parentScope);
               }
               
             };
             
           
            
             $scope.$on('changeChildren', function(event, parentItem) {
               var child, i, len, ref, results;
               ref = parentItem.children;
               results = [];
               for (i = 0, len = ref.length; i < len; i++) {
                 child = ref[i];
                 if(child.enabled== "1"){
                 child.selected = parentItem.selected;
                 }
                 if (child.children != null) {
                   results.push($scope.$broadcast('changeChildren', child));
                 } else {
                   results.push(void 0);
                 }
               }
               return results;
             });
             
             return $scope.$on('changeParent', function(event, parentScope) {
               var children;
               children = parentScope.item.children;
               parentScope.item.selected = $filter('selected')(children).length === children.length;
            
               parentScope = parentScope.$parent.$parent;
               if (parentScope.item != null) {
                 return $scope.$broadcast('changeParent', parentScope);
               }
             });
             
             

       
});
*/
}]);