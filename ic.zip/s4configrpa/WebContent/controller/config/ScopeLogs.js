angular.module('yapp').controller('downloadScopeController',["ngDialog","Upload","$scope","$rootScope","$http","$mdDialog","$mdMedia","$location","$filter","$state","$ocLazyLoad", function(ngDialog,Upload,$scope,$rootScope,$http,$mdDialog,$mdMedia,$location,$filter,$state,$ocLazyLoad) {
	$ocLazyLoad.load(controllerName+'/config/ScopeLogs.js?ver='+version);
/*    $rootScope.treeData = [];
	$scope.selectedTreeviewData = $rootScope.selectedScopeData;
	$scope.uploadButtondisabled = true;
	$scope.userVal = $rootScope.userValidation;
	$scope.executionFileSize = 0;
	$scope.executeDisabled = false;
	$scope.msg1 = " ";
	$scope.msg2 = " ";
	$scope.msg3 = " ";
	$scope.msg4 = " ";
	$scope.successCount = 0;
	$scope.errorCount = 0;*/
	
/*	
	var noAuth = "false";
	var cookie = document.cookie;
	var cookieAuthParams = cookie.split(';');
	for (var cp1 = 0,arrLen = cookieAuthParams.length; cp1 < arrLen ; cp1++) {*/
	/*	if (cookieAuthParams[cp1].split('=')[0].trim() == "configAuth" && cookieAuthParams[cp1].split('=')[1].trim() == "true") {
			noAuth = "true"
		}*/
		if ($rootScope.configAuth == "true") {
			noAuth = "true"
		}
/*	}*/
	if (noAuth == "false") {
		$location.path('/loginPage');
	}


	$scope.executeConfig=function(){
//		 $rootScope.skipExecute = true; 
		 ngDialog.close();
		 /*if($rootScope.implType != "1" && $rootScope.modTypes.value == "Automated without intervention")
			 $rootScope.executionLogsData = $rootScope.executeScopeList;
		 else*/
			 $rootScope.executionLogsData = $rootScope.selectedScopeData;

//		 $rootScope.$broadcast("CallexecuteMethod", {});
		 $rootScope.confirmExecution();
		 
	};
	
	$scope.stopeExecution=function(){
//		 $rootScope.skipExecute = false;
		 ngDialog.close();
//		 $scope.executeListener();
	};
	
	/* $scope.childmethod = function() {
         $rootScope.$emit("CallexecuteMethod", {});
     }*/
	  
	
}]);
 

