angular.module('yapp').controller('IndustryType',["ngDialog","Upload","$scope","$rootScope","$http","$mdDialog","$mdMedia","$location","$filter","$state","Idle","$ocLazyLoad",function(ngDialog,Upload,$scope,$rootScope,$http,$mdDialog,$mdMedia,$location,$filter,$state,Idle,$ocLazyLoad,browser) {
	$ocLazyLoad.load(controllerName+'/config/IndustryType.js?ver='+version);
	$ocLazyLoad.load(controllerName+'/config/selectIndustry.js?ver='+version);
	$ocLazyLoad.load(controllerName+'/config/configTilesController.js?ver='+version);
	//Browser Refresh - 13 Nov 2017
	if($rootScope.appValidity == undefined){
		   $rootScope.username = "";
		    $rootScope.password = "";
		    var cookies = document.cookie.split(";");
		    for (var i = 0,arrLen = cookies.length; i < arrLen ; i++) {
		        var cookie = cookies[i];
		        var eqPos = cookie.indexOf("=");
		        var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
		        document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
		    }
		    $location.path('/loginPage');
	    
	}
	//Idle Time out Logic - Start

	
Idle.watch();

//Idle Time out Logic - End
$scope.openNav = function() {
	document.getElementById("upArrow").style.display = "inline-block";
	document.getElementById("mySidenav").style.display = "inline-block";
    document.getElementById("mySidenav").style.width = "230px";
    document.getElementById("downArrow").style.display = "none";
}
$scope.closeNav = function() {
	document.getElementById("upArrow").style.display = "none";
	document.getElementById("downArrow").style.display = "inline-block";
    document.getElementById("mySidenav").style.display = "none";
}

	$rootScope.selectedIndustry=undefined;
	$rootScope.selectedsubIndustry=undefined;
	$rootScope.downloadtempUser = false;
	$rootScope.importTemp = false;
	$rootScope.name1  = "active1";
	$rootScope.name2  = "not-active";
	$rootScope.name3 = "not-active";
	var noAuth = "false";
	var homeAuth = "true";
	if($rootScope.reportingTile == undefined)
	$rootScope.reportingTile = false;
	
	
	$rootScope.reportData = [];
	$rootScope.configTransactionData = [];
	$rootScope.userRole = "Config";
	 if($rootScope.scopevalueArrayid == undefined)
		 $rootScope.scopevalueArrayid =[];
	 if($rootScope.selectedid == undefined)	
			$rootScope.selectedid= [];
		if($rootScope.selectedid[0] == undefined)	
			$rootScope.selectedid[0] = [];
		
	var myDate = new Date();
	   myDate.setHours(myDate.getHours() + 1);
		var cookie = document.cookie;
		var cookieAuthParams = cookie.split(';');
		for (var cp1 = 0,arrLen = cookieAuthParams.length; cp1 < arrLen ; cp1++) {
			/*if (cookieAuthParams[cp1].split('=')[0].trim() == "configAuth" && cookieAuthParams[cp1].split('=')[1].trim() == "true") {
				noAuth = "true"
			}*/
			if ($rootScope.configAuth == "true") {
				noAuth = "true"
			}
			if($rootScope.appValidity == undefined){
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userDetails") {
					$rootScope.userValidation = cookieAuthParams[cp1].split('=')[1];
					//console.log($rootScope.userValidation.role);
					
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userName") {
					$rootScope.username = cookieAuthParams[cp1].split('=')[1];
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userFirstName") {
					 $rootScope.userFirstName = cookieAuthParams[cp1].split('=')[1];
				}
				if (cookieAuthParams[cp1].split('=')[0].trim() == "userLastName") {
					$rootScope.userLastName = cookieAuthParams[cp1].split('=')[1];
				}
		  }
			
		}
		if (noAuth == "false") {
			$location.path('/loginPage');
		}
//		$rootScope.appValidity = true;//Browser Refresh
/*Hiding Page2(Deployment Info) initially on Notification pop up*/
		$rootScope.page2 = false;
/*Displaying the content of Page 2 on click on next button	*/
$rootScope.nextpage = function(){
			$rootScope.page2 =  true;
			$rootScope.activePage = "previous";
			$rootScope.nonactivePage = "next";
		}
$rootScope.previouspage = function(){
	$rootScope.page2 =  false;
	$rootScope.activePage = "next";
	$rootScope.nonactivePage = "previous";
}
/*Two pages - dynamic classes on notification Pop up*/
$rootScope.activePage = "next";
$rootScope.nonactivePage = "previous";

/*$scope.logout = function(){
		ngDialog.close();
        $state.transitionTo('loginPage');
        $rootScope.username = "";
        $rootScope.password = "";
       // $scope.deleteAllCookies();
        $rootScope.sapUserID = "";
    	$rootScope.sapPassword = "";
        $rootScope.adminAuth  = "";

        $rootScope.fileUploadAuth = "";
        $rootScope.executeAuth = "";
        $rootScope.configAuth = "";
        $rootScope.fileDownloadAuth = "";
        ngDialog.close(); 
        	 

    }*/
	$scope.changePassword = function(){
  		if(document.getElementById("upArrow") !=  null){
  		document.getElementById("upArrow").style.display = "none";
  		document.getElementById("downArrow").style.display = "inline-block";
  	    document.getElementById("mySidenav").style.display = "none";
  		}
  		ngDialog.openConfirm({
	            template: 'view/managePassword/changePassword.html?ver='+version,
	            scope: $scope,
	            closeByDocument: false,
	            closeByEscape: false,
	            showClose: false,
	            height: 410,
	            width: 560,
	           className:'ngdialog-theme-default CLASS_projName'
	        });  		
  	};
if( $rootScope.userValidation != undefined && $rootScope.userValidation.default_p == 'Y'){
	 $scope.changePassword();
}
else if($rootScope.secQAUpdated == false &&  $rootScope.isLoginAgain == true) {
 /*   $http.post("/" + servicePrefix + "/rest/adminSrv/getSecurityQuestions/").then(function executeSuccess(response) {
    	
    	if( response.data.resMessageDto.msgType == "Success"){
    	$rootScope.securityQAList = response.data.quesListDto;
    	}
    	else{
    		
    	}
    });*/
	 $rootScope.isLoginAgain = false;
	ngDialog.openConfirm({
        template: 'view/managePassword/setUpSecurityQA.html?ver='+version,
     // controller : 'LoginPageController',
        scope: $scope,
        closeByDocument: false,
        closeByEscape: false,
        showClose: true,
        height: 445,
        width: 500,
       className:'ngdialog-theme-default CLASS_projName'
    	})
    }

$scope.goTiles = function() {
	$rootScope.industryFlag=false;
	$rootScope.selectedRootScopeDatas = [];
	$rootScope.downloadScopeList = [];
	$rootScope.selectedScopeData =[];
	$rootScope.selectedBPData =[];
	$location.path("/configTilesPage");
}

$scope.goIndustry = function()
{
	$rootScope.industryFlag=true;
	$rootScope.selectedRootScopeDatas = [];
	$rootScope.downloadScopeList = [];
	$rootScope.selectedScopeData =[];
	$rootScope.selectedBPData =[];
	 ngDialog.openConfirm({
        template: 'view/config/selectIndustry.html?ver='+version,
        controller:'selectIndustry',
        scope: $scope,
        closeByDocument: false,
        closeByEscape: false,
        showClose: true,
        height: 400,
        width: 650
    })
	
	
}

$scope.changePassword = function(){
		if(document.getElementById("upArrow") !=  null){
		document.getElementById("upArrow").style.display = "none";
		document.getElementById("downArrow").style.display = "inline-block";
	    document.getElementById("mySidenav").style.display = "none";
		}
		ngDialog.openConfirm({
            template: 'view/managePassword/changePassword.html?ver='+version,
           
            scope: $scope,
            closeByDocument: false,
            closeByEscape: false,
            showClose: false,
            height: 410,
            width: 560,
           className:'ngdialog-theme-default CLASS_projName'
        });  		
	};
if( $rootScope.userValidation != undefined && $rootScope.userValidation.default_p == 'Y'){
 $scope.changePassword();
}
else if($rootScope.secQAUpdated == false &&  $rootScope.isLoginAgain == true) {

 $rootScope.isLoginAgain = false;
ngDialog.openConfirm({
    template: 'view/managePassword/setUpSecurityQA.html?ver='+version,
 // controller : 'LoginPageController',
    scope: $scope,
    closeByDocument: false,
    closeByEscape: false,
    showClose: true,
    height: 445,
    width: 500,
   className:'ngdialog-theme-default CLASS_projName'
	});
}

	$scope.newPassword =  function(){
  		//$scope.validateRole($rootScope.securityQA.newpassword);
  	/*	service call to store the new password*/
  		if( $rootScope.securityQA.oldpassword == $rootScope.password){
  			if($rootScope.securityQA.oldpassword != $rootScope.securityQA.newpassword){
  			$scope.showAlert = {"display":"none"};
  		 var params = {
           		userId : $rootScope.username,
           		oldPassword : $rootScope.securityQA.oldpassword,
           		newPassword : $rootScope.securityQA.newpassword,
           		sessionInputDTO : $rootScope.sessionInputObj
           }
  		$http.post("/" + servicePrefix + "/rest/adminSrv/updatePassword",params).then(function(response){
        if(response.data.msgType == "Success")
  		{        	
        	ngDialog.close();          	   
            $http.post("/" + servicePrefix + "/rest/adminSrv/getSecurityQuestions/").then(function executeSuccess(response) {
            	
            	if( response.data.resMessageDto.msgType == "Success"){
            	$rootScope.securityQAList = response.data.quesListDto;
            	}
            	else{
            		
            	}
            });
        	$rootScope.userValidation.default_p = 'N';
        	if($rootScope.secQAUpdated == false) {
        		ngDialog.openConfirm({
        	        template: 'view/managePassword/setUpSecurityQA.html?ver='+version,
        	     
        	        scope: $scope,
        	        closeByDocument: false,
        	        closeByEscape: false,
        	        showClose: true,
        	        height: 445,
        	        width: 500,
        	       className:'ngdialog-theme-default CLASS_projName'
        	    	});
        	}
        	else{
        		ngDialog.openConfirm({
                    template: '<p>' + "Your new Password is saved successfully" +'</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                })
        	}
        }else if(response.data.message == "Invalid input received"){
          	ngDialog.openConfirm({
                template: '<p>' + "Invalid input received" +'</p>',
                plain: true,
                scope: $scope,
                closeByDocument: true,
                closeByEscape: true,
                showClose: true,
                height:120,
                width: 350,
                className:'ngdialog-theme-default CLASS_2'
            })
        }
        else {
        	ngDialog.openConfirm({
                template: '<p>' + "Something went wrong." +'</p>',
                plain: true,
                scope: $scope,
                closeByDocument: true,
                closeByEscape: true,
                showClose: true,
                height:120,
                width: 350,
                className:'ngdialog-theme-default CLASS_2'
            })
        }
  		});
  		}else{
  				$scope.showAlertforNewPwd = {   "color" : "red", "display":"inline-block"};
  			}
  		}
  		else{
  			$scope.showAlert = {   "color" : "red", "display":"inline-block"};
  		
  		}
  	};
  	$scope.setOnlySecurityQuestions = function (){
  		ngDialog.openConfirm({
            template: 'view/managePassword/setUpSecurityQA.html?ver='+version,
         // controller : 'LoginPageController',
            scope: $scope,
            closeByDocument: false,
            closeByEscape: false,
            showClose: true,
            height: 445,
            width: 500,
           className:'ngdialog-theme-default CLASS_projName'
        	});
  	};
  	
  	$scope.skipSecQA = function()
	{
	 ngDialog.close();
	}
  	
 	$scope.saveSecQuestions = function(){
  		var listOfQuestions = [$rootScope.securityQA.question1,$rootScope.securityQA.question2];
  		var listOfAnswers = [sha256($rootScope.securityQA.answer1),sha256($rootScope.securityQA.answer2)];
  	    var comparray = [];
       for(i=0;i<listOfAnswers.length;i++){
    	   var obj ={};
               obj.questionId = listOfQuestions[i];
               obj.ans = listOfAnswers[i];
               
           comparray.push(obj);
       }
  		var input = {
  				ansListDto : comparray,
  				userId: $rootScope.username,
  				sessionInputDTO :  $rootScope.sessionInputObj
  		}
  	
  		$http.post("/" + servicePrefix + "/rest/adminSrv/updateSecurityAnswers",input).then(function(response){
  	       if(response.data.msgType == "Success")
  	  		{
  	    	 ngDialog.close();
  	    	 	    	
  	    	$rootScope.secQAUpdated = true;
  	    	
  	    	 ngDialog.openConfirm({
                template: '<p>' + "Your Details are saved succeessfully" +'</p>',
                plain: true,
                scope: $scope,
                closeByDocument: true,
                closeByEscape: true,
                showClose: true,
                height:120,
                width: 350,
                className:'ngdialog-theme-default CLASS_2'
            });
  	    	}
  	       else {
  	    	 ngDialog.close();
  	    	 ngDialog.openConfirm({
                 template: '<p>' + "Something went wrong. Please try again with correct details" +'</p>',
                 plain: true,
                 scope: $scope,
                 closeByDocument: true,
                 closeByEscape: true,
                 showClose: true,
                 height:120,
                 width: 350,
                 className:'ngdialog-theme-default CLASS_2'
             });
  	       }
  			});
  		
 	};	

}]);