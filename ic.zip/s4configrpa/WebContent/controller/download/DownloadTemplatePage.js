angular.module('yapp').controller('DownloadTemplatePage',["ngDialog", "$filter", "Upload", "$scope"," $rootScope", "$http", "$mdDialog", "$mdMedia", "$location", "$timeout", "$window", "$state", function(ngDialog, $filter, Upload, $scope, $rootScope, $http, $mdDialog, $mdMedia, $location, $timeout, $window, $state) {
	$ocLazyLoad.load(controllerName+'/download/DownloadTemplatePage.js?ver='+version);
      var noAuth = "false";

    /*  var cookie = document.cookie;
        var cookieAuthParams = cookie.split(';');
        for (var cp1 = 0,arrLen = cookieAuthParams.length; cp1 < arrLen ; cp1++) {*/
         /* if (cookieAuthParams[cp1].split('=')[0].trim() == "configAuth" && cookieAuthParams[cp1].split('=')[1].trim() == "true") {
            noAuth = "true"
          }*/
          if ($rootScope.configAuth == "true") {
				noAuth = "true"
			}
    /*  	if($rootScope.appValidity == undefined){
			if (cookieAuthParams[cp1].split('=')[0].trim() == "userDetails") {
				$rootScope.userValidation = cookieAuthParams[cp1].split('=')[1];
				console.log($rootScope.userValidation.role);
				
			}
			if (cookieAuthParams[cp1].split('=')[0].trim() == "userName") {
				$rootScope.username = cookieAuthParams[cp1].split('=')[1];
			}
			if (cookieAuthParams[cp1].split('=')[0].trim() == "userFirstName") {
				 $rootScope.userFirstName = cookieAuthParams[cp1].split('=')[1];
			}
			if (cookieAuthParams[cp1].split('=')[0].trim() == "userLastName") {
				$rootScope.userLastName = cookieAuthParams[cp1].split('=')[1];
			}
	  }
        }*/

	$scope.dwnldFileData = [];
	$scope.itemsByPage=15;
	$scope.arrayImg =[];
	$scope.fileNameList =[]; 	
	$scope.currentPage = 1;
	if($rootScope.selectedimg == undefined)
		 $rootScope.selectedimg = [];
	if($rootScope.scopevalueArrays == undefined)
		$rootScope.scopevalueArrays = [];
	if($rootScope.scopevalueArrays1 == undefined)
		$rootScope.scopevalueArrays1 = [];
	$rootScope.scopevalueArray = [];	
	if(	$rootScope.scopevalueArrayid == undefined)
		$rootScope.scopevalueArrayid = [];
	$rootScope.downloadTemplate = true; 
	// $rootScope.selectedRootScopeData =[];

     /********8 Logout ********/
    /* $scope.logout = function() {
         $state.transitionTo('loginPage');
         $rootScope.username = "";
         $rootScope.password = "";
         $rootScope.adminAuth  = "";

         $rootScope.fileUploadAuth = "";
         $rootScope.executeAuth = "";
         $rootScope.configAuth = "";
         $rootScope.fileDownloadAuth = "";
     };*/
     
     $scope.homePage= function(){
 		ngDialog.openConfirm({
 	            template: 'view/config/confirm.html?ver='+version,
 	            controller:'DownloadTemplatePage',
 	            scope: $scope,
 	            closeByDocument: false,
 	            closeByEscape: false,
 	           showClose: false,
 	           height: 200,
 	            width: 400
 	        }); 		
  	};
  	
    $scope.isAll = false;
    $scope.selectAllFriends = function () {
        if ($scope.isAll === false) {
            angular.forEach($scope.selectedScopeData, function (x) {
                x.checked = true;
            });
            $scope.isAll = true;
        } else {
            angular.forEach($scope.selectedScopeData, function (x) {
                x.checked = false;
            });
            $scope.isAll = false;
        }
    };
    
    
  	 $scope.okHomepage = function(){
   		$location.path("/configTilesPage");
  		ngDialog.close();
  	};
  	 $scope.cancelHome = function(){
  		 ngDialog.close(); 		 
  	};
 
    $rootScope.selectedTreeviewData=[];
  	 if($rootScope.selectedRootScopeData == undefined)
     {
            $rootScope.selectedRootScopeData = [];
     } 
      angular.copy($rootScope.selectedRootScopeData,$rootScope.selectedTreeviewData);
      
 		 
		    $http({
	        	method: 'POST',
	        	url:"/" + servicePrefix + "/rest/imgHierarchySrv/viewImgHierarchy",
	        	data : $rootScope.sessionInputObj
	        }).then(function(response) {
		    if(response.status === 200){
		    	
		    	  if(response.data != null){
		    		  if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
		       	      		$rootScope.checkAuthorization();
		       	      	}else{
		    	var responsedata=[];
		        responsedata.push(response.data);
		        $rootScope.listData = responsedata;	
		    	  }
		    	  }else{
		    		  
		    	  }
		    } else {
		       
		    }
		});   	 
		 

  	$scope.downloadTemplates = function () {
        var selectedScopeList = [];
        $scope.selectedAll = false;
        $rootScope.DownloadStatus = [];
        angular.forEach($rootScope.selectedScopeData, function (checked) {
            if (checked.checked) {
           	 selectedScopeList.push(checked.sequence+"_"+checked.imgDescription);
            }
        });
        var selectedData = {
            selectedScopes:selectedScopeList,
            sessionInputDTO : $rootScope.sessionInputObj	

        }; 
        if (selectedScopeList.length > 0)  {
        $http.post("/" + servicePrefix + "/rest/imgTemplateUploadSrv/getIMGTemplatesPath", selectedData).then(function(response) {
            if (response.status === 200) {
                for (var i = 0,arrLen = response.data.listImgHierarchyDto.length; i < arrLen ; i++) {
                    var downloadFilesPath = {
                        "fileName": response.data.listImgHierarchyDto[i].sequence+"_"+response.data.listImgHierarchyDto[i].imgDescription
                       
                    };
                    $rootScope.DownloadStatus.push(downloadFilesPath);
                    downloadFilesPath = {};
                    
                    
                }
                ngDialog.openConfirm({
       	            template: 'view/managetemplate/downloadStatus.html?ver='+version,
       	            controller:'DownloadTemplatePage',
       	            scope: $scope,
       	            closeByDocument: false,
       	            closeByEscape: false,
       	            showClose: true,
       	            height: "auto",
       	            width: 600,
       	            className:'ngdialog-theme-default CLASS_2'
       	        }).then(function() {     	        	
       	            $scope.okDownload();
       	        });

                $scope.okDownload = function (ok) {
              	  ngDialog.close();
              	 $rootScope.overlay_download = document.getElementById("overlay");
                 $rootScope.popup_download = document.getElementById("busy");
                 $rootScope.overlay_download.style.display = "block";
                 $rootScope.popup_download.style.display = "inline-block";
                	  $http.post("/" + servicePrefix + "/rest/imgTemplateUploadSrv/downloadTemplates",selectedData).then(function(response) {
                          if(response.status === 200 ){
                        	  if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
                     	      		$rootScope.checkAuthorization();
                     	      	}else {
                        	  var 	zip = new JSZip();
                        	  		$scope.arrayImg=[];
                        	  		$scope.fileNameList =[];
                      	
                      	 var count =0;
                      	 var count1 =0;
                         	 for (var i = 0,arrLen = response.data.listImgHierarchyDto.length; i < arrLen ; i++) {
                                  var downloadFilesPath = {
                                      "sequence": response.data.listImgHierarchyDto[i].sequence,
                                      "imgDescription": response.data.listImgHierarchyDto[i].imgDescription,
                                      "filePath": response.data.listImgHierarchyDto[i].bytes
                                  };
                                //  $rootScope.DownloadFileData.push(downloadFilesPath);
                                  $scope.downloadFile(response.data.listImgHierarchyDto[i].bytes,response.data.listImgHierarchyDto[i].sequence,response.data.listImgHierarchyDto[i].imgDescription);
                                  
                                  downloadFilesPath = {};
                              }
                         	// var i=0;
                         	 $scope.arrayImg.forEach(function(url){
                         		 //console.log(url)
                         		 
                         		  var filename =  $scope.fileNameList[count];
                         		  //i++;
                      		     count++;

                         		  // loading a file and add it in a zip file
                         		  JSZipUtils.getBinaryContent(url, function (err, data) {
                         		     if(err) {
                         		        throw err; // or handle the error
                         		     }
                         		     zip.file(filename, data, {binary:true});
                         		     if (count == $scope.arrayImg.length) {
                         		       /*var zipFile = zip.generate({type: "blob"});
                         		       saveAs(zipFile, "examples.zip");*/
                         		      zip.generateAsync({type:"blob"}).then(function(content) {
                              		     // see FileSaver.js
                                   	 	count1++;
                                   	 if(count1 == $scope.arrayImg.length)
                                   		 saveAs(content, "BaseTemplatesDownload.zip");
                              		 });
                         		 
                         		     }
                         		  });
                         		});
                         }
                	  }
                          $rootScope.overlay_download.style.display = "none";
                          $rootScope.popup_download.style.display = "none";
                      });
                }
            } else {
            	
            	ngDialog.openConfirm({
                    template: '<p>' +"Templates are not available."+ '</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                });            }
        });
        
  	}else{
  		ngDialog.openConfirm({
            template: '<p>' +"Please select atleast One Template"+ '</p>',
            plain: true,
            scope: $scope,
            closeByDocument: true,
            closeByEscape: true,
            showClose: true,
            height:120,
            width: 350,
            className:'ngdialog-theme-default CLASS_2'
        });
  		
  	}
    };
   	$scope.downloadFile = function(exportHref, sequense, filename) {
        var sampleBytes = base64ToArrayBuffer(exportHref);
        saveByteArray([sampleBytes], sequense + "_" + filename + ".xlsx");
        $scope.fileNameList.push(sequense + "_" + filename + ".xlsx");
    };
    function base64ToArrayBuffer(base64) {
        var binaryString = window.atob(base64);
        var binaryLen = binaryString.length;
        var bytes = new Uint8Array(binaryLen);
        for (var i = 0; i < binaryLen; i++) {
            var ascii = binaryString.charCodeAt(i);
            bytes[i] = ascii;
        }
        return bytes;
    }

    var saveByteArray = (function() {
   	  
        var a = document.createElement("a");
        document.body.appendChild(a);
        a.style = "display: none";
     
        return function(data, name) {
            var blob = new Blob(data, {
                    type: "octet/stream"
                }),
                url = window.URL.createObjectURL(blob);
            	$scope.arrayImg.push(url);
       
        };
    }());
     $scope.openProgress = function() {
         ngDialog.openConfirm({
             template: 'view/ProgressDialog.html?ver='+version,
             controller: 'DownloadTemplatePage',
             scope: $scope,
             closeByDocument: false,
             closeByEscape: false,
             showClose: true,
             height: 200,
             width: 300
         }).then(function() {
             $scope.callUpload(allfiles, files);
         });
     };
	    $scope.startImport = function(){
	    	
	    	ngDialog.openConfirm({
	    		template: 'view/download/downloadTreeUI.html?ver='+version,
	    	      preCloseCallback:function(){

		            	if($rootScope.validClose == undefined){
		            		$rootScope.selectedScopeData = $rootScope.selectedTreeviewData;
		   	       		 	$rootScope.scopevaluesData = "";
			   	       		 $rootScope.scopevalueArray=[];
			   	       		 for(var x = 0,arrLen = $rootScope.selectedScopeData.length; x < arrLen ; x++){
			   	          		  if($rootScope.selectedScopeData[x].enabled === 1){
			   	          		  if(x == 0)
			   	          		  { 	
			   	          			  $rootScope.scopevaluesData = $rootScope.selectedScopeData[x].imgId;
			   	          			  $rootScope.scopevalueArray.push($rootScope.selectedScopeData[x].imgId);
			   	          		}
			   	          		  else{
			   	          			  $rootScope.scopevaluesData = $rootScope.scopevaluesData.concat(";",$rootScope.selectedScopeData[x].imgId);
			   	          			  $rootScope.scopevalueArray.push($rootScope.selectedScopeData[x].imgId);
			   	          			  }
			   	          	  }
			   	          	  }
		   	       		 
		            	}else{
		            		$rootScope.validClose = undefined;
		            	}
		            	
		            },
	    		controller:'DownloadTemplatePage',
	            scope: $scope,
	            closeByDocument: false,
	            closeByEscape: false,
	            showClose: true,
	            height: 490,
	            width: 800
	        });
	    };
	      $scope.toggleAllCheckboxes = function($event) {
	        var i, item, len, ref, results, selected;
	        selected = $event.target.checked;
	        ref = $rootScope.listData;
	       console.log(ref);
	        results = [];
	        for (i = 0, len = ref.length; i < len; i++) {
	          item = ref[i];
	          item.selected = selected;
	         
	          if (item.children != null) {
	            results.push($scope.$broadcast('changeChildren', item));
	           
	          } else {
	            results.push(void 0);
	          }
	        }
	        
	        return results;
	      };
	      $scope.initCheckbox = function(item, parentItem) {
	       // return item.selected = parentItem && parentItem.selected || item.selected || false;
	        item.selected=$scope.validatecheck(item);
             if(item.selected)
         {
          var allChecks = true;
          for (var i in parentItem.children) 
          {
                       if (!parentItem.children[i].selected) {
                                     allChecks = false;
                                     break;
                              }
          }
                       if (allChecks) {
                                                          parentItem.selected = true;
                                                   }
                              else {
                                                   parentItem.selected = false;
                                     }

         }
            return item.selected;
	      };
	      
	      $scope.validatecheck=function(item)
	      {
              var selectedValue=true;
              var aIndex = $rootScope.scopevalueArray.indexOf(item.imgId);
              if(aIndex>-1)
                     { 
                     
                     var bData = {};
                     if(item.imgId.length > 0){
                            
                            bData.imgId = item.imgId;
                            bData.imgDescription = item.imgDescription;
                            bData.sequence = item.sequence;
                            bData.enabled = item.enabled;
                            bData.fileName = "";
                            bData.filepath = "";
                            bData.isMasterData = item.isMasterData;
                            if(selectedValue === true){
                            
                                   index = -1;
                                   for(var a= 0,arrLen = $rootScope.selectedRootScopeData.length;a< arrLen ;a++){
                                        if($rootScope.selectedRootScopeData[a].imgId == bData.imgId){
                                               index = a;
                                               break;
                                        }
                                   }
                                   
                                   if (index == -1) {
                                         if(bData.enabled == 1){
                                         $rootScope.selectedRootScopeData.push(bData);
                                         }

                                       }
                                   
                            }
                           
                            else if(selectedValue === false){

                                   
                                   index = -1;
                                   for(var a= 0,arrLen = $rootScope.selectedRootScopeData.length;a< arrLen ;a++){
                                        if($rootScope.selectedRootScopeData[a].imgId == bData.imgId){
                                               index = a;
                                               break;
                                        }
                                   }
                                   

                                   if (index > -1) {
                                         $rootScope.selectedRootScopeData.splice(index, 1);
                                       }
                            }
                     }else {
                            for(var x = 0,arrLen = item.children.length;x < arrLen ; x++){
                            $scope.selectedMethod(item.children[x],selectedValue);
                            }
                     }
                     
                     return true
                     }
              else
              return false;
           }
	      
	      $scope.selectedMethod = function(item,selectedValue){
	    	  var bData = {};
	 	    	 
	    	  if(item.imgId.length > 0){
	    		  bData.imgId = item.imgId;
		    	  bData.imgDescription = item.imgDescription;
		    	  bData.sequence = item.sequence;
		    	  bData.enabled = item.enabled;
		    	  bData.fileName = "";
		    	  bData.filepath = "";
		 

		    	  if(selectedValue === true){

                      index = -1;
                      for(var a= 0,arrLen = $rootScope.selectedRootScopeData.length;a< arrLen ;a++){
                           if($rootScope.selectedRootScopeData[a].imgId == bData.imgId){
                                  index = a;
                                  break;
                           }
                      }
                      
                      if (index == -1) {
                            if(bData.enabled== 1 ){
                            $rootScope.selectedRootScopeData.push(bData);
                            }
                     
                          }
                      
               }
              
               else if(selectedValue === false){

                      
                      index = -1;
                      for(var a= 0,arrLen = $rootScope.selectedRootScopeData.length;a< arrLen ;a++){
                           if($rootScope.selectedRootScopeData[a].imgId == bData.imgId){
                                  index = a;
                                  break;
                           }
                      }
                   
                      if (index > -1) {
                            $rootScope.selectedRootScopeData.splice(index, 1);
                          }
               }
	    	  }else {
	    		  for(var x = 0,arrLen = item.children.length;x < arrLen ; x++){
	    		  $scope.selectedMethod(item.children[x],selectedValue);
	    		  }
	    	  } 
    		      	  
	      };
	     
	      
	      $scope.toggleCheckbox = function(item, parentScope) {    
	    	  $rootScope.scopevaluesData ="";    	
	    	  $rootScope.scopevalueArray=[];
	    	  $scope.selectedMethod(item,item.selected); 	    		 
	    	  $rootScope.selectedRootScopeData.sort(function(a, b) {
	    		    return parseInt(a.sequence) - parseFloat(b.sequence);
	    		});
	    	  
    	  for(var x = 0,arrLen = $scope.selectedRootScopeData.length; x < arrLen ; x++){
    		  if($scope.selectedRootScopeData[x].enabled === 1){
    			  
    		  if(x == 0)
    			 		{		  
    				  $rootScope.scopevaluesData = $scope.selectedRootScopeData[x].imgId;
    		          $rootScope.scopevalueArray.push($rootScope.selectedRootScopeData[x].imgId);
    			 		}
    		  else
    				  
    			  $rootScope.scopevaluesData = $rootScope.scopevaluesData.concat(";",$scope.selectedRootScopeData[x].imgId);
    		           $rootScope.scopevalueArray.push($rootScope.selectedRootScopeData[x].imgId);
    	  }
    	  }
    		  if (item.children != null) {
    	          $scope.$broadcast('changeChildren', item);
    	        }
    	        if (parentScope.item != null) {
    	          return $scope.$emit('changeParent', parentScope);
    	        }
	      };
	      
	      
	      $scope.save=function(){
	    	  $rootScope.validClose = true;
		  		ngDialog.close();
		  		
		  	};
		  	$scope.onCancel=function(){
		  		ngDialog.close();
		  		
		  	};
		  	 $scope.$on('changeChildren', function(event, parentItem) {
			        var child, i, len, ref, results;
			        ref = parentItem.children;
			        results = [];
			        for (i = 0, len = ref.length; i < len; i++) {
			          child = ref[i];
			          if(child.enabled == 1){
			          child.selected = parentItem.selected;
			          }
			          if (child.children != null) {
			            results.push($scope.$broadcast('changeChildren', child));
			          } else {
			            results.push(void 0);
			          }
			        }
			        return results;
			      });
			      return $scope.$on('changeParent', function(event, parentScope) {
			        var children;
			        children = parentScope.item.children;
			        parentScope.item.selected = $filter('selected')(children).length === children.length;
			     
			        parentScope = parentScope.$parent.$parent;
			        if (parentScope.item != null) {
			          return $scope.$broadcast('changeParent', parentScope);
			        }
			      }); 
			        
 }]);