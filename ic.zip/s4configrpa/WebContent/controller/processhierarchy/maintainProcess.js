angular.module('yapp').controller('maintainProcessController',["$http", "$filter", "Upload", "ngDialog", "$scope","$rootScope", "$mdDialog", "$mdMedia", "$location", "NgTableParams","$ocLazyLoad", function($http, $filter, Upload, ngDialog, $scope, $rootScope, $mdDialog, $mdMedia, $location, NgTableParams,$ocLazyLoad) {
	$ocLazyLoad.load(controllerName+'/processhierarchy/maintainProcess.js?ver='+version);
	var noAuth = "false";
	
   /* var cookie = document.cookie;
    var cookieAuthParams = cookie.split(';');
    for (var cp1 = 0,arrLen = cookieAuthParams.length; cp1 < arrLen; cp1++) {*/
      /*  if (cookieAuthParams[cp1].split('=')[0].trim() == "adminAuth" && cookieAuthParams[cp1].split('=')[1].trim() == "true") {
            noAuth = "true"
        }*/
        if ($rootScope.adminAuth == "true") {
			noAuth = "true"
		}
    	/*if($rootScope.appValidity == undefined){
			if (cookieAuthParams[cp1].split('=')[0].trim() == "userDetails") {
				$rootScope.userValidation = cookieAuthParams[cp1].split('=')[1];
				console.log($rootScope.userValidation.role);
				
			}
			if (cookieAuthParams[cp1].split('=')[0].trim() == "userRole") {
				$rootScope.userRole = cookieAuthParams[cp1].split('=')[1];
			}
			if (cookieAuthParams[cp1].split('=')[0].trim() == "userName") {
				$rootScope.username = cookieAuthParams[cp1].split('=')[1];
			}
			if (cookieAuthParams[cp1].split('=')[0].trim() == "roleId") {
				$rootScope.roleId = cookieAuthParams[cp1].split('=')[1];
			}
			if (cookieAuthParams[cp1].split('=')[0].trim() == "userFirstName") {
				 $rootScope.userFirstName = cookieAuthParams[cp1].split('=')[1];
			}
			if (cookieAuthParams[cp1].split('=')[0].trim() == "userLastName") {
				$rootScope.userLastName = cookieAuthParams[cp1].split('=')[1];
			}
	  }
    }*/
    if (noAuth == "false") {
        $location.path('/loginPage');
    }
    document.getElementById("mySidenav").style.width = "0px";
    if(document.getElementById("showSubMenu") != null)
    	document.getElementById("showSubMenu").style.display = "none";
	document.getElementById("hambrgrCloseMenu").style.display = "none";
	document.getElementById("hambrgrMenu").style.display = "inline-block";
    $rootScope.dataProcessHierarchy=[];
	var list;
    $scope.uploadProgress = false;
    if($rootScope.listofimgs==undefined)
    $rootScope.listofimgs=[];
    $scope.test1="test";
    
    $scope.startImport = function() {
        ngDialog.openConfirm({
            template: 'popupTmpl.html',
            controller: 'maintainProcessController',
            scope: $scope,
            closeByDocument: false,
            closeByEscape: false,
            showClose: true,
            height: 175,
            width: 525
        }).then(function() {
            $scope.uploadExcelFiles();
        });
    };

    $scope.openProgress = function() {
        ngDialog.openConfirm({
            template: 'view/ProgressDialog.html?ver='+version,
            controller: 'maintainProcessController',
            scope: $scope,
            closeByDocument: false,
            closeByEscape: false,
            showClose: true,
            height: 130,
            width: 300
        }).then(function() {
            $scope.callUpload(files, implType);
        });
    };

    $rootScope.uploadExcelFiles = function(files) {
        $scope.noTextVisibility = false;
        $rootScope.executionLogData = 0;
        $scope.isSuccess = true;
        var implType = $scope.implType;
        $scope.callUpload(files, implType);
    }

    $scope.callUpload = function(files, implType) {
        var uploadUrl = "/" + servicePrefix + "/rest/imgHierarchySrv/imgHierarchy/" + implType;

        
        ngDialog.close();
        $scope.openProgress();
        var fd = new FormData();
        fd.append('file', files);
        $scope.uploadProgress = true;
        files.upload = Upload.upload({
            method: 'POST',
            url: uploadUrl,
            data: {
                files: files
            }
        });
        files.upload.then(function(responseData) {
            $scope.fileUploadSuccess(responseData);
        }, function(data) {
            $scope.fileUploaderror(data);
        });

    };
   
    $scope.fileUploadSuccess = function(responseData) {
        var data;
        data = responseData.data.message;
     
        $rootScope.listofimgs=responseData.data.listimgs;
          ngDialog.close();
        if($rootScope.listofimgs!=null){
        	
        	 ngDialog.openConfirm({
                 template: '<p>' + data +'<br>'+ responseData.data.listimgs.join("")+ '</p>',
                 controller: 'maintainProcessController',
                 scope: $scope,
                 closeByDocument: true,
                 closeByEscape: true,
                 showClose: true,
                 height: 'auto',
                 width: 350,
                 plain: true
             });
        	
        }else{
        	 ngDialog.openConfirm({
                 template: '<p>' +data+ '</p>',
                 controller: 'maintainProcessController',
                 scope: $scope,
                 closeByDocument: true,
                 closeByEscape: true,
                 showClose: true,
                 height: 120,
                 width: 350,
                 plain: true
             });
        }
        
        var input = {
        		implType : "ProcessHierarchy",
        		sessionInputDTO : $rootScope.sessionInputObj	

        }
        $http({
        	method: 'POST',
        	url:"/" + servicePrefix + "/rest/imgHierarchySrv/previewImgHierarchy",
        	data : input
        	
        }).then(function(response) {
        	$scope.tabHierarchyContent="";
            if (response.status === 200 ) {
            	if( response.data != null){
            		if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
  	      	      		$rootScope.checkAuthorization();
  	      	      	}
            		else $scope.tabHierarchyContent = response.data.listImgHierarchyDto;
            }else{
            		  
            		  ngDialog.openConfirm({
                          template: '<p>' +"No records found!"+ '</p>',
                          plain: true,
                          scope: $scope,
                          closeByDocument: true,
                          closeByEscape: true,
                          showClose: true,
                          height:120,
                          width: 350,
                          className:'ngdialog-theme-default CLASS_2'
                      });  
            		  
            	  }
            } else {
                ngDialog.openConfirm({
                    template: '<p>' +"No records found!"+ '</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                }); 
            }
           /* if (!$scope.$$phase) {

                $scope.$apply();
            }*/
        });
        
        var input = {
        		implType : "ImgDependency",
        		sessionInputDTO : $rootScope.sessionInputObj	

        }
        $http({
        	method: 'POST',
        	url:"/" + servicePrefix + "/rest/imgHierarchySrv/previewImgHierarchy",
        	data : input 
        }).then(function(response) {
        	$scope.tabDependencyContent="";
            if (response.status === 200) {
            	
            	  if( response.data != null){
            		  if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
    	      	      		$rootScope.checkAuthorization();
    	      	      	}
              			else $scope.tabDependencyContent = response.data.listImgHierarchyDto;
                  	  }else{
                  		  
                  		  ngDialog.openConfirm({
                                template: '<p>' +"No records found!"+ '</p>',
                                plain: true,
                                scope: $scope,
                                closeByDocument: true,
                                closeByEscape: true,
                                showClose: true,
                                height:120,
                                width: 350,
                                className:'ngdialog-theme-default CLASS_2'
                            });  
                  		  
                  	  }
                
            } else {
                ngDialog.openConfirm({
                    template: '<p>' +"No records found!"+ '</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                }); 
            }
       /*     if (!$scope.$$phase) {

                $scope.$apply();
            }*/
        });
        
        var input = {
        		implType : "ImageObjects",
        		sessionInputDTO : $rootScope.sessionInputObj	

        }
        $http({
        	method: 'POST',
        	url:"/" + servicePrefix + "/rest/imgHierarchySrv/previewImgHierarchy",
        	data : input
        }).then(function(response) {
        	 $scope.tabImageContent="";
        	
            if (response.status === 200) {
            	
            	 $scope.uploadProgress = true;
            	  if( response.data != null){
            		  if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
    	      	      		$rootScope.checkAuthorization();
    	      	      	}
              			else $scope.tabImageContent = response.data.listImgHierarchyDto;
                  	  }else{
                  		  
                  		  ngDialog.openConfirm({
                                template: '<p>' +"No records found!"+ '</p>',
                                plain: true,
                                scope: $scope,
                                closeByDocument: true,
                                closeByEscape: true,
                                showClose: true,
                                height:120,
                                width: 350,
                                className:'ngdialog-theme-default CLASS_2'
                            });  
                  		  
                  	  }
               
            } else {
                ngDialog.openConfirm({
                    template: '<p>' +"No records found!"+ '</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                }); 
            }
          /*  if (!$scope.$$phase) {

                $scope.$apply();
            }*/
        });
        
        var input = {
        		implType : "FieldMapping",
        		sessionInputDTO : $rootScope.sessionInputObj	

        }
        $http({
        	method: 'POST',
        	url:"/" + servicePrefix + "/rest/imgHierarchySrv/previewFieldMapping",
        	data : input
        }).then(function(response) {
        	 $scope.tabFieldMappingContent="";
            if (response.status === 200) {
            	
            	 if( response.data != null){
            		 if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
   	      	      		$rootScope.checkAuthorization();
   	      	      	}
             		else $scope.tabFieldMappingContent = response.data.listFieldMappingDto;
                 	  }else{
                 		  
                 		  ngDialog.openConfirm({
                               template: '<p>' +"No records found!"+ '</p>',
                               plain: true,
                               scope: $scope,
                               closeByDocument: true,
                               closeByEscape: true,
                               showClose: true,
                               height:120,
                               width: 350,
                               className:'ngdialog-theme-default CLASS_2'
                           });  
                 		  
                 	  }
               
            } else {
                ngDialog.openConfirm({
                    template: '<p>' +"No records found!"+ '</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                }); 
            }
          /*  if (!$scope.$$phase) {

                $scope.$apply();
            }*/
        });
        
        var input = {
        		implType : "ImgFilterData",
        		sessionInputDTO : $rootScope.sessionInputObj	

        }
        $http({
        	method: 'POST',
        	url:"/" + servicePrefix + "/rest/imgHierarchySrv/previewImgFilterData",
        	data : input
        }).then(function(response) {
       	 $scope.tabImgFilterContent="";
           if (response.status === 200) {
        	   
           	 if( response.data != null){
           		if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
	      	      		$rootScope.checkAuthorization();
	      	      	}
        		else $scope.tabImgFilterContent = response.data.listImgFilterDataDTO;
                	  }else{
                		  
                		  ngDialog.openConfirm({
                              template: '<p>' +"No records found!"+ '</p>',
                              plain: true,
                              scope: $scope,
                              closeByDocument: true,
                              closeByEscape: true,
                              showClose: true,
                              height:120,
                              width: 350,
                              className:'ngdialog-theme-default CLASS_2'
                          });  
                		  
                	  }
              
           } else {
               ngDialog.openConfirm({
                   template: '<p>' +"No records found!"+ '</p>',
                   plain: true,
                   scope: $scope,
                   closeByDocument: true,
                   closeByEscape: true,
                   showClose: true,
                   height:120,
                   width: 350,
                   className:'ngdialog-theme-default CLASS_2'
               }); 
           }
          /* if (!$scope.$$phase) {

               $scope.$apply();
           }*/
       });

        var input = {
        		implType : "ScenarioHierarchy",
        		sessionInputDTO : $rootScope.sessionInputObj	

        }
        $http({
        	method: 'POST',
        	url:"/" + servicePrefix + "/rest/imgHierarchySrv/previewImgHierarchy",
        	data : input
        	
        }).then(function(response) {
        	$scope.tabHierarchyContent="";
            if (response.status === 200 ) {
            	if( response.data != null){
            		if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
  	      	      		$rootScope.checkAuthorization();
  	      	      	}
            		else $scope.tabHierarchyContent = response.data.listImgHierarchyDto;
            }else{
            		  
            		  ngDialog.openConfirm({
                          template: '<p>' +"No records found!"+ '</p>',
                          plain: true,
                          scope: $scope,
                          closeByDocument: true,
                          closeByEscape: true,
                          showClose: true,
                          height:120,
                          width: 350,
                          className:'ngdialog-theme-default CLASS_2'
                      });  
            		  
            	  }
            } else {
                ngDialog.openConfirm({
                    template: '<p>' +"No records found!"+ '</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                }); 
            }
          
        });
        var input = {
        		implType : "Industry",
        		sessionInputDTO : $rootScope.sessionInputObj	

        }
        $http({
        	method: 'POST',
        	url:"/" + servicePrefix + "/rest/imgHierarchySrv/previewIndustryData",
        	data : input
        	
        }).then(function(response) {
        	$scope.tabHierarchyContent="";
            if (response.status === 200 ) {
            	if( response.data != null){
            		if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
  	      	      		$rootScope.checkAuthorization();
  	      	      	}
            		else $scope.tabHierarchyContent = response.data.listImgHierarchyDto;
            }else{
            		  
            		  ngDialog.openConfirm({
                          template: '<p>' +"No records found!"+ '</p>',
                          plain: true,
                          scope: $scope,
                          closeByDocument: true,
                          closeByEscape: true,
                          showClose: true,
                          height:120,
                          width: 350,
                          className:'ngdialog-theme-default CLASS_2'
                      });  
            		  
            	  }
            } else {
                ngDialog.openConfirm({
                    template: '<p>' +"No records found!"+ '</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                }); 
            }
          
        });
        
    };

    $scope.fileUploaderror = function(responseData) {

        var data;
       
        ngDialog.close();
        if(responseData.data != null){
       data = responseData.data.message;      
       
        ngDialog.openConfirm({
            template: '<div><p>' + data + '</p></div>',
            controller: 'maintainProcessController',
            scope: $scope,
            closeByDocument: true,
            closeByEscape: true,
            showClose: true,
            height: 120,
            width: 350,
            plain: true
        });
    }
    };

    //******Tab Click Event******//
    
    $scope.myClickEvent1 = function(){ 
    	$scope.tabHierarchyContent ="";
    	$scope.tabDependencyContent="";
    	$scope.tabImageContent="";
    	$scope.tabFieldMappingContent="";
    	$scope.tabImgFilterContent="";
    	$scope.lists="";
    	$scope.implType = 'ProcessHierarchy';
    	
   /* 	  var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
    	 $mdDialog.show({
             controller: function($scope, $mdDialog) {
                     $scope.isLoading = true;
                     $scope.indicatorMsgs = "Please wait Loading...";
             },
             templateUrl: 'view/processhierarchy/busyIndicator.html?ver='+version,
             parent: angular.element(document.body),
             clickOutsideToClose: false,
             fullscreen: useFullScreen,
             escapeToClose: false,
         })
         */
    	
    	/*Adding new busy Indicator logic which works in IE */
    	 	$scope.overlay = document.getElementById("overlay");
		 	$scope.popup = document.getElementById("busy");
		 	$scope.overlay.style.display = "block";
		 	$scope.popup.style.display = "inline-block";
    	
		 	var input = {
	        		implType : "ProcessHierarchy",
	        		sessionInputDTO : $rootScope.sessionInputObj	

	        }
        $http({
        	
        	method: 'POST',
        	url:"/" + servicePrefix + "/rest/imgHierarchySrv/previewImgHierarchy",
        	data : input
        }).then(function(response) {
            if (response.status === 200) {
            	
     		 	$scope.overlay.style.display = "none";
     		 	$scope.popup.style.display = "none";
     		 	
           	 if( response.data != null){
           		if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
	      	      		$rootScope.checkAuthorization();
	      	      	}
        		else{
           		 $scope.tabHierarchyContent = response.data.listImgHierarchyDto;
           		 $scope.isLoading = false;
           		
    		 		$scope.overlay.style.display = "none";
    		 		$scope.popup.style.display = "none";
        			}
           		}else{
             		// $mdDialog.cancel();
             		 /*Closing new busy Indicator*/
                	$scope.overlay = document.getElementById("overlay");
         		 	$scope.popup = document.getElementById("busy");
         		 	$scope.overlay.style.display = "none";
         		 	$scope.popup.style.display = "none";
         		 	
             		  ngDialog.openConfirm({
                           template: '<p>' +"No records found!"+ '</p>',
                           plain: true,
                           scope: $scope,
                           closeByDocument: true,
                           closeByEscape: true,
                           showClose: true,
                           height:120,
                           width: 350,
                           className:'ngdialog-theme-default CLASS_2'
                       });  
             	 }
            } else {
            	$scope.isLoading = false;
            	//$mdDialog.cancel();
            	
            	/*Closing new busy Indicator*/
           		$scope.overlay = document.getElementById("overlay");
    		 	$scope.popup = document.getElementById("busy");
    		 	$scope.overlay.style.display = "none";
    		 	$scope.popup.style.display = "none";
    		 	
                ngDialog.openConfirm({
                    template: '<p>' +"No records found!"+ '</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                }); 
            }
           /* if (!$scope.$$phase) {
            	$scope.isLoading = false;
            	$mdDialog.cancel();
                $scope.$apply();
            }*/
        });
    };
    $scope.myClickEvent2 = function(){
     	$scope.tabHierarchyContent ="";
    	$scope.tabDependencyContent="";
    	$scope.tabImageContent="";
    	$scope.tabFieldMappingContent="";
    	$scope.tabImgFilterContent="";
    	$scope.lists="";
    	$scope.implType = 'ImgDependency';
   /* 	  var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
     	 $mdDialog.show({
              controller: function($scope, $mdDialog) {
                      $scope.isLoading = true;
                      $scope.indicatorMsgs = "Please wait Loading...";
              },
              templateUrl: 'view/processhierarchy/busyIndicator.html?ver='+version,
              parent: angular.element(document.body),
              clickOutsideToClose: false,
              fullscreen: useFullScreen,
              escapeToClose: false,
          })*/
          
             	/*Adding new busy Indicator logic which works in IE */
    	 	$scope.overlay = document.getElementById("overlay");
		 	$scope.popup = document.getElementById("busy");
		 	$scope.overlay.style.display = "block";
		 	$scope.popup.style.display = "inline-block";
		 	 var input = {
		        		implType : "ImgDependency",
		        		sessionInputDTO : $rootScope.sessionInputObj	

		        }
        $http({
        	method: 'POST',
        	url:"/" + servicePrefix + "/rest/imgHierarchySrv/previewImgHierarchy",
        	data : input
        }).then(function(response) {
       
            if (response.status === 200) {
            	
            	$scope.overlay = document.getElementById("overlay");
     		 	$scope.popup = document.getElementById("busy");
     		 	$scope.overlay.style.display = "none";
     		 	$scope.popup.style.display = "none";
     		 	
            	 if( response.data != null){
            		 if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
   	      	      		$rootScope.checkAuthorization();
   	      	      	}
             		else{
             		 $scope.tabDependencyContent = response.data.listImgHierarchyDto;
             		 $scope.isLoading = false;
             		//$mdDialog.cancel();
             		
             		 /*Closing new busy Indicator*/
                	
         		 		$scope.overlay.style.display = "none";
         		 		$scope.popup.style.display = "none";
             			} 
             		}else{
                 			$scope.isLoading = false;
                 		// $mdDialog.cancel();
                 		  
                 			 /*Closing new busy Indicator*/
                        	$scope.overlay = document.getElementById("overlay");
                 		 	$scope.popup = document.getElementById("busy");
                 		 	$scope.overlay.style.display = "none";
                 		 	$scope.popup.style.display = "none";
                 		 	
                 			ngDialog.openConfirm({
                               template: '<p>' +"No records found!"+ '</p>',
                               plain: true,
                               scope: $scope,
                               closeByDocument: true,
                               closeByEscape: true,
                               showClose: true,
                               height:120,
                               width: 350,
                               className:'ngdialog-theme-default CLASS_2'
                           });  
                 		  
                 	  }
               
            } else {
            	$scope.isLoading = false;
            	//$mdDialog.cancel();
           	 /*Closing new busy Indicator*/
            	$scope.overlay = document.getElementById("overlay");
     		 	$scope.popup = document.getElementById("busy");
     		 	$scope.overlay.style.display = "none";
     		 	$scope.popup.style.display = "none";
     		 	
            	ngDialog.openConfirm({
                    template: '<p>' +"No records found!"+ '</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                }); 
            }
            if (!$scope.$$phase) {
            	$scope.isLoading = false;
            	//$mdDialog.cancel();
           	 /*Closing new busy Indicator*/
            	$scope.overlay = document.getElementById("overlay");
     		 	$scope.popup = document.getElementById("busy");
     		 	$scope.overlay.style.display = "none";
     		 	$scope.popup.style.display = "none";
     		 	
            	$scope.$apply();
            }
        });
    };
    $scope.myClickEvent3 = function(){
     	$scope.tabHierarchyContent ="";
    	$scope.tabDependencyContent="";
    	$scope.tabImageContent="";
    	$scope.tabFieldMappingContent="";
    	$scope.tabImgFilterContent="";
    	$scope.lists="";
    	$scope.implType = 'ImageObjects';
  /*  	var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
    	 $mdDialog.show({
             controller: function($scope, $mdDialog) {
                     $scope.isLoading = true;
                     $scope.indicatorMsgs = "Please wait Loading...";
             },
             templateUrl: 'view/processhierarchy/busyIndicator.html?ver='+version,
             parent: angular.element(document.body),
             clickOutsideToClose: false,
             fullscreen: useFullScreen,
             escapeToClose: false,
         })*/
         
            	/*Adding new busy Indicator logic which works in IE */
    	 	$scope.overlay = document.getElementById("overlay");
		 	$scope.popup = document.getElementById("busy");
		 	$scope.overlay.style.display = "block";
		 	$scope.popup.style.display = "inline-block";
		 	var input = {
	        		implType : "ImageObjects",
	        		sessionInputDTO : $rootScope.sessionInputObj	

	        }
        $http({
        	method: 'POST',
        	url:"/" + servicePrefix + "/rest/imgHierarchySrv/previewImgHierarchy",
        	data : input
        }).then(function(response) {
        	
            if (response.status === 200) {
            	
            	$scope.overlay = document.getElementById("overlay");
     		 	$scope.popup = document.getElementById("busy");
     		 	$scope.overlay.style.display = "none";
     		 	$scope.popup.style.display = "none";
            	 if( response.data != null){
            		 if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
   	      	      		$rootScope.checkAuthorization();
   	      	      	}
             		else{
            		 $scope.tabImageContent = response.data.listImgHierarchyDto;
            			$scope.isLoading = false;
            		// $mdDialog.cancel();
            			 /*Closing new busy Indicator*/
                    
             		 	$scope.overlay.style.display = "none";
             		 	$scope.popup.style.display = "none";
             		}	
            	 }else{
                			$scope.isLoading = false;
                		//  $mdDialog.cancel();
                			 /*Closing new busy Indicator*/
                        	$scope.overlay = document.getElementById("overlay");
                 		 	$scope.popup = document.getElementById("busy");
                 		 	$scope.overlay.style.display = "none";
                 		 	$scope.popup.style.display = "none";
                 		 	
                			ngDialog.openConfirm({
                              template: '<p>' +"No records found!"+ '</p>',
                              plain: true,
                              scope: $scope,
                              closeByDocument: true,
                              closeByEscape: true,
                              showClose: true,
                              height:120,
                              width: 350,
                              className:'ngdialog-theme-default CLASS_2'
                          });  
                		  
                	  }
              
                
            } else {
            	$scope.isLoading = false;
            	//$mdDialog.cancel();
                
           	 /*Closing new busy Indicator*/
            	$scope.overlay = document.getElementById("overlay");
     		 	$scope.popup = document.getElementById("busy");
     		 	$scope.overlay.style.display = "none";
     		 	$scope.popup.style.display = "none";
     		 	
            	ngDialog.openConfirm({
                    template: '<p>' +"No records found!"+ '</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                }); 
            }
            if (!$scope.$$phase) {
            	//$mdDialog.cancel();
           	 /*Closing new busy Indicator*/
            	$scope.overlay = document.getElementById("overlay");
     		 	$scope.popup = document.getElementById("busy");
     		 	$scope.overlay.style.display = "none";
     		 	$scope.popup.style.display = "none";
     		 	
            	$scope.$apply();
            }
        });
    };
    
    $scope.myClickEvent4 = function(){
     	$scope.tabHierarchyContent ="";
    	$scope.tabDependencyContent="";
    	$scope.tabImageContent="";
    	$scope.tabFieldMappingContent="";
    	$scope.tabImgFilterContent="";
    	$scope.lists="";
    	$scope.implType = 'FieldMapping';
   /* 	 var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
    	 $mdDialog.show({
             controller: function($scope, $mdDialog) {
                     $scope.isLoading = true;
                     $scope.indicatorMsgs = "Please wait Loading...";
             },
             templateUrl: 'view/processhierarchy/busyIndicator.html?ver='+version,
             parent: angular.element(document.body),
             clickOutsideToClose: false,
             fullscreen: useFullScreen,
             escapeToClose: false,
         })*/
         
            	/*Adding new busy Indicator logic which works in IE */
    	 	$scope.overlay = document.getElementById("overlay");
		 	$scope.popup = document.getElementById("busy");
		 	$scope.overlay.style.display = "block";
		 	$scope.popup.style.display = "inline-block";
		 	var input = {
	        		implType : "FieldMapping",
	        		sessionInputDTO : $rootScope.sessionInputObj	

	        }
    	$http({	
        	method: 'POST',
        	url:"/" + servicePrefix + "/rest/imgHierarchySrv/previewFieldMapping",
        	data : input
        }).then(function(response) {
            // console.log(response);
            if (response.status === 200) {
            	$scope.overlay = document.getElementById("overlay");
     		 	$scope.popup = document.getElementById("busy");
     		 	$scope.overlay.style.display = "none";
     		 	$scope.popup.style.display = "none";

           	 if( response.data != null){
           		if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
	      	      		$rootScope.checkAuthorization();
	      	      	}
        		else{
           		 $scope.tabFieldMappingContent = response.data.listFieldMappingDto;
           		 $scope.isLoading = false;
           		//$mdDialog.cancel();
           	 /*Closing new busy Indicator*/
            	$scope.overlay.style.display = "none";
     		 	$scope.popup.style.display = "none";  	  
        		}
        		}else{
               		$scope.isLoading = false;
               		//$mdDialog.cancel();
               	 /*Closing new busy Indicator*/
                	$scope.overlay = document.getElementById("overlay");
         		 	$scope.popup = document.getElementById("busy");
         		 	$scope.overlay.style.display = "none";
         		 	$scope.popup.style.display = "none";
         		 	
               		ngDialog.openConfirm({
                             template: '<p>' +"No records found!"+ '</p>',
                             plain: true,
                             scope: $scope,
                             closeByDocument: true,
                             closeByEscape: true,
                             showClose: true,
                             height:120,
                             width: 350,
                             className:'ngdialog-theme-default CLASS_2'
                         });  
               		  
               	  }
               
            } else {
            	$scope.isLoading = false;
            	//$mdDialog.cancel();
           	 /*Closing new busy Indicator*/
            	$scope.overlay = document.getElementById("overlay");
     		 	$scope.popup = document.getElementById("busy");
     		 	$scope.overlay.style.display = "none";
     		 	$scope.popup.style.display = "none";
            	
            	ngDialog.openConfirm({
                    template: '<p>' +"No records found!"+ '</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                }); 
            }
            if (!$scope.$$phase) {
            	$scope.isLoading = false;
            	//$mdDialog.cancel();
                
           	 /*Closing new busy Indicator*/
            	$scope.overlay = document.getElementById("overlay");
     		 	$scope.popup = document.getElementById("busy");
     		 	$scope.overlay.style.display = "none";
     		 	$scope.popup.style.display = "none";
            	$scope.$apply();
            }
        });  
    
    };
    
    $scope.myClickEvent5 = function(){
     	$scope.tabHierarchyContent ="";
    	$scope.tabDependencyContent="";
    	$scope.tabImageContent="";
    	$scope.tabFieldMappingContent="";
    	$scope.tabImgFilterContent="";
    	$scope.lists="";
    	$scope.implType = 'ImgFilterData';
    	/* var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
    	 $mdDialog.show({
             controller: function($scope, $mdDialog) {
                     $scope.isLoading = true;
                     $scope.indicatorMsgs = "Please wait Loading...";
             },
             templateUrl: 'view/processhierarchy/busyIndicator.html?ver='+version,
             parent: angular.element(document.body),
             clickOutsideToClose: false,
             fullscreen: useFullScreen,
             escapeToClose: false,
         })*/
         
            	/*Adding new busy Indicator logic which works in IE */
    	 	$scope.overlay = document.getElementById("overlay");
		 	$scope.popup = document.getElementById("busy");
		 	$scope.overlay.style.display = "block";
		 	$scope.popup.style.display = "inline-block";
		 	var input = {
	        		implType : "ImgFilterData",
	        		sessionInputDTO : $rootScope.sessionInputObj	

	        }
		 	$http({
        	method: 'POST',
        	url:"/" + servicePrefix + "/rest/imgHierarchySrv/previewImgFilterData",
        	data : input
        }).then(function(response) {
            // console.log(response);
            if (response.status === 200) {
            	
            	$scope.overlay = document.getElementById("overlay");
     		 	$scope.popup = document.getElementById("busy");
     		 	$scope.overlay.style.display = "none";
     		 	$scope.popup.style.display = "none";
           	 if( response.data != null){
           		if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
	      	      		$rootScope.checkAuthorization();
	      	      	}
        		else{
        			$scope.tabImgFilterContent = response.data.listImgFilterDataDTO;
        		    $scope.isLoading = false;
           		//$mdDialog.cancel();
           	 /*Closing new busy Indicator*/
           
     		 	$scope.overlay.style.display = "none";
     		 	$scope.popup.style.display = "none";
        		}
           	 }else{
               		$scope.isLoading = false;
               		//$mdDialog.cancel();
               	 /*Closing new busy Indicator*/
                	$scope.overlay = document.getElementById("overlay");
         		 	$scope.popup = document.getElementById("busy");
         		 	$scope.overlay.style.display = "none";
         		 	$scope.popup.style.display = "none";
         		 	
               		ngDialog.openConfirm({
                             template: '<p>' +"No records found!"+ '</p>',
                             plain: true,
                             scope: $scope,
                             closeByDocument: true,
                             closeByEscape: true,
                             showClose: true,
                             height:120,
                             width: 350,
                             className:'ngdialog-theme-default CLASS_2'
                         });  
               		  
               	  }
               
            } else {
            	$scope.isLoading = false;
            	//$mdDialog.cancel();
           	 /*Closing new busy Indicator*/
            	$scope.overlay = document.getElementById("overlay");
     		 	$scope.popup = document.getElementById("busy");
     		 	$scope.overlay.style.display = "none";
     		 	$scope.popup.style.display = "none";
            	
            	ngDialog.openConfirm({
                    template: '<p>' +"No records found!"+ '</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                }); 
            }
            if (!$scope.$$phase) {
            	$scope.isLoading = false;
            	//$mdDialog.cancel();
           	 /*Closing new busy Indicator*/
            	$scope.overlay = document.getElementById("overlay");
     		 	$scope.popup = document.getElementById("busy");
     		 	$scope.overlay.style.display = "none";
     		 	$scope.popup.style.display = "none";
     		 	
            	$scope.$apply();
            }
        });  
    
    };
    $scope.myClickEvent6 = function(){ 
    	$scope.tabHierarchyContent ="";
    	$scope.tabDependencyContent="";
    	$scope.tabImageContent="";
    	$scope.tabFieldMappingContent="";
    	$scope.tabImgFilterContent="";
    	$scope.lists="";
    	$scope.implType = 'ScenarioHierarchy';
 
    	/*Adding new busy Indicator logic which works in IE */
    	 	$scope.overlay = document.getElementById("overlay");
		 	$scope.popup = document.getElementById("busy");
		 	$scope.overlay.style.display = "block";
		 	$scope.popup.style.display = "inline-block";
    	
		 	var input = {
	        		implType : "ScenarioHierarchy",
	        		sessionInputDTO : $rootScope.sessionInputObj	

	        }
        $http({
        	
        	method: 'POST',
        	url:"/" + servicePrefix + "/rest/imgHierarchySrv/previewImgHierarchy",
        	data : input
        }).then(function(response) {
            if (response.status === 200) {
            	
     		 	$scope.overlay.style.display = "none";
     		 	$scope.popup.style.display = "none";
     		 	
           	 if( response.data != null){
           		if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
	      	      		$rootScope.checkAuthorization();
	      	      	}
        		else{
           		 $scope.tabHierarchyContent = response.data.listImgHierarchyDto;
           		 $scope.isLoading = false;
           		
    		 		$scope.overlay.style.display = "none";
    		 		$scope.popup.style.display = "none";
        			}
           		}else{
             	
                	$scope.overlay = document.getElementById("overlay");
         		 	$scope.popup = document.getElementById("busy");
         		 	$scope.overlay.style.display = "none";
         		 	$scope.popup.style.display = "none";
         		 	
             		  ngDialog.openConfirm({
                           template: '<p>' +"No records found!"+ '</p>',
                           plain: true,
                           scope: $scope,
                           closeByDocument: true,
                           closeByEscape: true,
                           showClose: true,
                           height:120,
                           width: 350,
                           className:'ngdialog-theme-default CLASS_2'
                       });  
             	 }
            } else {
            	$scope.isLoading = false;
            	           	
            	/*Closing new busy Indicator*/
           		$scope.overlay = document.getElementById("overlay");
    		 	$scope.popup = document.getElementById("busy");
    		 	$scope.overlay.style.display = "none";
    		 	$scope.popup.style.display = "none";
    		 	
                ngDialog.openConfirm({
                    template: '<p>' +"No records found!"+ '</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                }); 
            }
           
        });
    };
    $scope.myClickEvent7 = function(){ 
    	$scope.tabHierarchyContent ="";
    	$scope.tabDependencyContent="";
    	$scope.tabImageContent="";
    	$scope.tabFieldMappingContent="";
    	$scope.tabImgFilterContent="";
    	$scope.lists="";
    	$scope.implType = 'Industry';
    	
    	
    	/*Adding new busy Indicator logic which works in IE */
    	 	$scope.overlay = document.getElementById("overlay");
		 	$scope.popup = document.getElementById("busy");
		 	$scope.overlay.style.display = "block";
		 	$scope.popup.style.display = "inline-block";
    	
		 	var input = {
	        		implType : "Industry",
	        		sessionInputDTO : $rootScope.sessionInputObj	

	        }
        $http({
        	
        	method: 'POST',
        	url:"/" + servicePrefix + "/rest/imgHierarchySrv/previewIndustryData",
        	data : input
        }).then(function(response) {
            if (response.status === 200) {
            	
     		 	$scope.overlay.style.display = "none";
     		 	$scope.popup.style.display = "none";
     		 	
           	 if( response.data != null){
           		if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
	      	      		$rootScope.checkAuthorization();
	      	      	}
        		else{
           		 $scope.tabHierarchyContent = response.data.listImgHierarchyDto;
           		 $scope.isLoading = false;
           		
    		 		$scope.overlay.style.display = "none";
    		 		$scope.popup.style.display = "none";
        			}
           		}else{
             		// $mdDialog.cancel();
             		 /*Closing new busy Indicator*/
                	$scope.overlay = document.getElementById("overlay");
         		 	$scope.popup = document.getElementById("busy");
         		 	$scope.overlay.style.display = "none";
         		 	$scope.popup.style.display = "none";
         		 	
             		  ngDialog.openConfirm({
                           template: '<p>' +"No records found!"+ '</p>',
                           plain: true,
                           scope: $scope,
                           closeByDocument: true,
                           closeByEscape: true,
                           showClose: true,
                           height:120,
                           width: 350,
                           className:'ngdialog-theme-default CLASS_2'
                       });  
             	 }
            } else {
            	$scope.isLoading = false;
            	//$mdDialog.cancel();
            	
            	/*Closing new busy Indicator*/
           		$scope.overlay = document.getElementById("overlay");
    		 	$scope.popup = document.getElementById("busy");
    		 	$scope.overlay.style.display = "none";
    		 	$scope.popup.style.display = "none";
    		 	
                ngDialog.openConfirm({
                    template: '<p>' +"No records found!"+ '</p>',
                    plain: true,
                    scope: $scope,
                    closeByDocument: true,
                    closeByEscape: true,
                    showClose: true,
                    height:120,
                    width: 350,
                    className:'ngdialog-theme-default CLASS_2'
                }); 
            }
        });
    };
    $scope.barLimit = 100;
    $scope.increaseLimit = function() {
      $scope.barLimit += 50;
      
    }
    $scope.barLimit1 = 100;
    $scope.increaseLimit1 = function() {
      $scope.barLimit1 += 50;
    
    }
    $scope.barLimit2 = 100;
    $scope.increaseLimit2 = function() {
      $scope.barLimit2 += 50;
     
    }
    $scope.barLimit3 = 100;
    $scope.increaseLimit3 = function() {
      $scope.barLimit3 += 50;
     
    }
  /*  $scope.myClickEvent6 = function(){
     	$scope.tabHierarchyContent ="";
    	$scope.tabDependencyContent="";
    	$scope.tabImageContent="";
    	$scope.tabFieldMappingContent="";
    	$scope.lists="";
    	 var useFullScreen = ($mdMedia('sm') || $mdMedia('xs')) && $scope.customFullscreen;
    	 $mdDialog.show({
             controller: function($scope, $mdDialog) {
                     $scope.isLoading = true;
                     $scope.indicatorMsgs = "Please wait Loading...";
             },
             templateUrl: 'view/processhierarchy/busyIndicator.html?ver='+version,
             parent: angular.element(document.body),
             clickOutsideToClose: false,
             fullscreen: useFullScreen,
             escapeToClose: false,
         })
            	Adding new busy Indicator logic which works in IE 
    	 	$scope.overlay = document.getElementById("overlay");
		 	$scope.popup = document.getElementById("busy");
		 	$scope.overlay.style.display = "block";
		 	$scope.popup.style.display = "inline-block";
		 	
    	$http({
        	method: 'POST',
        	url:"/" + servicePrefix + "/rest/imgHierarchySrv/viewImgHierarchy",
        	data : $rootScope.sessionInputObj
        }).then(function(response) {
        	
        if(response.status === 200){
        	$scope.overlay = document.getElementById("overlay");
 		 	$scope.popup = document.getElementById("busy");
 		 	$scope.overlay.style.display = "none";
 		 	$scope.popup.style.display = "none";
 		 	
          	 if( response.data != null){
          		if(response.data.resMessageDto != null && response.data.resMessageDto.message == serviceMessage){
	      	      		$rootScope.checkAuthorization();
	      	      	}
        		else{
          		var responsedata=[];
                responsedata.push(response.data);
            	$scope.lists = responsedata;
            	responsedata =[];
            	$scope.isLoading = false;
            	//$mdDialog.cancel();
           	 Closing new busy Indicator
            	
     		 	$scope.overlay.style.display = "none";
     		 	$scope.popup.style.display = "none";
        		}
          	 }else{
              		$scope.isLoading = false;
              		//$mdDialog.cancel();
              		 Closing new busy Indicator
                	$scope.overlay = document.getElementById("overlay");
         		 	$scope.popup = document.getElementById("busy");
         		 	$scope.overlay.style.display = "none";
         		 	$scope.popup.style.display = "none";
         		 	
              		ngDialog.openConfirm({
                            template: '<p>' +"No records found!"+ '</p>',
                            plain: true,
                            scope: $scope,
                            closeByDocument: true,
                            closeByEscape: true,
                            showClose: true,
                            height:120,
                            width: 350,
                            className:'ngdialog-theme-default CLASS_2'
                        });  
              		  
              	  }
        
        	
        } else {
        	$scope.isLoading = false;
        	//$mdDialog.cancel();
       	 Closing new busy Indicator
        	$scope.overlay = document.getElementById("overlay");
 		 	$scope.popup = document.getElementById("busy");
 		 	$scope.overlay.style.display = "none";
 		 	$scope.popup.style.display = "none";
 		 	
        	ngDialog.openConfirm({
                template: '<p>' +"No records found!"+ '</p>',
                plain: true,
                scope: $scope,
                closeByDocument: true,
                closeByEscape: true,
                showClose: true,
                height:120,
                width: 350,
                className:'ngdialog-theme-default CLASS_2'
            }); 
        }
      
    });  
    
    };*/
    
 
   
}]);
