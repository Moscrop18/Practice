package com.acn.user.session;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class SecurityAnsInputDto {

	@Size(min = 1, max = 8)
	@Pattern(regexp = "[a-zA-Z0-9]+")
	private String userId;	
	@Valid
	private List<SecurityAnsListDto> ansListDto;
	@Valid
	private SessionInputDTO sessionInputDTO;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public List<SecurityAnsListDto> getAnsListDto() {
		return ansListDto;
	}
	public void setAnsListDto(List<SecurityAnsListDto> ansListDto) {
		this.ansListDto = ansListDto;
	}
	public SessionInputDTO getSessionInputDTO() {
		return sessionInputDTO;
	}
	public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
		this.sessionInputDTO = sessionInputDTO;
	}

	
}
