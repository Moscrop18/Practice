package com.acn.user.session;

import java.util.List;

import com.acn.rpa.admin.UserDto;
import com.acn.rpa.admin.UserRespDto;

public class UserListDto {
	
	private List<UserRespDto> userList;
	private ResMessageDto resMessageDto;
	
	public List<UserRespDto> getUserList() {
		return userList;
	}
	public void setUserList(List<UserRespDto> userList) {
		this.userList = userList;
	}
	public ResMessageDto getResMessageDto() {
		return resMessageDto;
	}
	public void setResMessageDto(ResMessageDto resMessageDto) {
		this.resMessageDto = resMessageDto;
	}
	
	

}
