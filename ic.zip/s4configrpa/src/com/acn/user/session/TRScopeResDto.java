package com.acn.user.session;

import java.util.ArrayList;

import com.acn.rpa.config.dto.SelectedScopeDto;

public class TRScopeResDto {

	private ArrayList<SelectedScopeDto> selectedScopeList;
	private ResMessageDto resMessageDto;
	
	public ArrayList<SelectedScopeDto> getSelectedScopeList() {
		return selectedScopeList;
	}
	public void setSelectedScopeList(ArrayList<SelectedScopeDto> selectedScopeList) {
		this.selectedScopeList = selectedScopeList;
	}
	public ResMessageDto getResMessageDto() {
		return resMessageDto;
	}
	public void setResMessageDto(ResMessageDto resMessageDto) {
		this.resMessageDto = resMessageDto;
	}
	
}
