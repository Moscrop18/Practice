package com.acn.user.session;

import com.acn.rpa.config.ScopeSessionDto;

public class RetrieverDto {
	private ScopeSessionDto ScopeSessionDto;
	private ResMessageDto resMessageDto;
	private String message;
	private String status;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public ResMessageDto getResMessageDto() {
		return resMessageDto;
	}

	public void setResMessageDto(ResMessageDto resMessageDto) {
		this.resMessageDto = resMessageDto;
	}

	public ScopeSessionDto getScopeSessionDto() {
		return ScopeSessionDto;
	}

	public void setScopeSessionDto(ScopeSessionDto scopeSessionDto) {
		ScopeSessionDto = scopeSessionDto;
	}
	

}
