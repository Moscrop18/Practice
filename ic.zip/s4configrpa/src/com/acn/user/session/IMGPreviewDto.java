package com.acn.user.session;

import javax.validation.Valid;
import javax.validation.constraints.Size;

public class IMGPreviewDto {
	@Size(min = 1, max = 20)
	private String selectedOmid;
	@Valid
	private SessionInputDTO sessionInputDTO;
	private String selectedArea;
	private String industry;
	private String subIndustry;
	private boolean downloadTemplate;
	
	public SessionInputDTO getSessionInputDTO() {
		return sessionInputDTO;
	}
	public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
		this.sessionInputDTO = sessionInputDTO;
	}	
	public String getSelectedOmid() {
		return selectedOmid;
	}
	public void setSelectedOmid(String selectedOmid) {
		this.selectedOmid = selectedOmid;
	}
	public String getSelectedArea() {
		return selectedArea;
	}
	public void setSelectedArea(String selectedArea) {
		this.selectedArea = selectedArea;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public String getSubIndustry() {
		return subIndustry;
	}
	public void setSubIndustry(String subIndustry) {
		this.subIndustry = subIndustry;
	}
	public boolean isDownloadTemplate() {
		return downloadTemplate;
	}
	public void setDownloadTemplate(boolean downloadTemplate) {
		this.downloadTemplate = downloadTemplate;
	}
}
