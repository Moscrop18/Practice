package com.acn.user.session;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.admin.GetUserDetails;
import com.acn.rpa.admin.UserDao;
import com.acn.rpa.admin.UserValidationDTO;

import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.DBConnection;

public class UserSecurityDao {
	
private final Logger slf4jLogger = LoggerFactory.getLogger(UserSecurityDao.class);
 
public DataStatusDto securityQAvalidation(SecurityAnsInputDto securityAnsInputDto) {
		slf4jLogger.info("securityQAvalidation method started");
		DataStatusDto dataStatusDto = new DataStatusDto();
		ResMessageDto resMessageDto = new ResMessageDto();
		dataStatusDto.setResMessageDto(resMessageDto);
		ResultSet rs = null;
		PreparedStatement pStmt = null;
		Connection con = null;
		List<SecurityAnsListDto> securityAnsListDto =  null;
		Map<Integer,String> ansMap = new HashMap<>();
		boolean status = false;
		try {
			con = DBConnection.createConnection();
			
			securityAnsListDto = securityAnsInputDto.getAnsListDto();
			String query = "SELECT QID, ANSWER FROM SECURITYANSWER WHERE USERID = ?";
			pStmt = con.prepareStatement(query);
			pStmt.setString(1, securityAnsInputDto.getUserId());
			rs = pStmt.executeQuery();
			
			while (rs.next()) {
				ansMap.put(rs.getInt("QID"), rs.getString("ANSWER"));
			}
			if(ansMap.size() == securityAnsListDto.size()){
				for(SecurityAnsListDto dto : securityAnsListDto){
					
					if(ansMap.get(dto.getQuestionId()) != null && dto.getAns().equals(ansMap.get(dto.getQuestionId()))){
						status = true;
						dataStatusDto.setDataStatus(status);	
						resMessageDto.setMsgType(ConstantsValues.SUCCESSSTATUS);
						resMessageDto.setMessage("Security answers are validated successfully");
						slf4jLogger.error("Security answers are validated successfully");
					}else{
						status = false;
						dataStatusDto.setDataStatus(status);	
						resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
						resMessageDto.setMessage("Security answers doesn't match with the recorded details. Validation is failed");
						slf4jLogger.error("Security answers doesn't match with the recorded details. Validation is failed");
						break;
					}
				}
			}
		
			//dataStatusDto.setDataStatus(status);	
			//resMessageDto.setMsgType(ConstantsValues.SUCCESSSTATUS);
			
		} catch (SQLException e) {
			dataStatusDto.setDataStatus(status);	
			resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		} finally {
			
			if (rs != null) {
				try {
					rs.close();
					rs = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}

			if (pStmt != null) {
				try {
					pStmt.close();
					pStmt = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}

			if (con != null) {
				try {
					con.close();
					con = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			  slf4jLogger.info("securityQAvalidation method ended");

		}

		return dataStatusDto;
	}

public ResMessageDto updatePassword(CredentialDto credentialDto){
	slf4jLogger.info("updatepassword method started");
	ResMessageDto resMessageDto = new ResMessageDto();
	PreparedStatement pStmt=null;
	PreparedStatement pStmt1=null;
	
	Connection con = null;
	ResultSet rs =null;
	String getUserQuery = "SELECT PASSWORD FROM USER WHERE UserID = ?";
	String updateUserQuery = "UPDATE USER SET PASSWORD = ?, DEFAULT_P =? WHERE UserID = ? AND PASSWORD != ?";
	
	try{
		con = DBConnection.createConnection();
		pStmt1 =  con.prepareStatement(getUserQuery);
		pStmt1.setString(1, credentialDto.getUserId());
		rs = pStmt1.executeQuery();

		if(rs.next() && rs.getString("PASSWORD").equals(UserDao.getReHashedPassword(credentialDto.getOldPassword())))
		{	
			//System.err.println( rs.getString("PASSWORD") + rs);
		pStmt =  con.prepareStatement(updateUserQuery);
		pStmt.setString(1, UserDao.getReHashedPassword(credentialDto.getNewPassword()));
		pStmt.setString(2, ConstantsValues.N);
		pStmt.setString(3, credentialDto.getUserId());
		pStmt.setString(4, UserDao.getReHashedPassword(credentialDto.getNewPassword()));
		pStmt.execute();
		resMessageDto.setMsgType(ConstantsValues.SUCCESSSTATUS);
		resMessageDto.setMessage("UserID "+credentialDto.getUserId()+" details are updated Successfully");
		slf4jLogger.error("UserID "+credentialDto.getUserId()+" details are updated Successfully"); 
		}else {
			resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			resMessageDto.setMessage(ConstantsValues.DATABASEERROR);
			slf4jLogger.error(ConstantsValues.DATABASEERROR); 
			 }
			}
	catch (Exception e){
		resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
		resMessageDto.setMessage(ConstantsValues.DATABASEERROR);
		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e); 
	}finally{
	
		if (pStmt != null) {
            try {
            	pStmt.close();
            	pStmt = null;
            } catch (SQLException e) {
            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e); 
            }
        }

        if (con != null) {
            try {
            	con.close();
            	con = null;
            } catch (SQLException e) {
            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e); 
            }
        }
		  slf4jLogger.info("updatePassword method ended");
	}	

	return resMessageDto;
}
public ResMessageDto resetPassword(ResetCredentialDto resetcredentialDto){
	slf4jLogger.info("resetpassword method started");
	ResMessageDto resMessageDto = new ResMessageDto();
	PreparedStatement pStmt = null;
	PreparedStatement pStmt1 = null;
	PreparedStatement pStmt2 = null;
	ResultSet rs = null;
	Connection con = null;
	String updateSessionInavtive = "UPDATE USERSESSION SET SESSIONSTATUS = ? WHERE USERID = ? AND CSRFTOKEN = ? AND SESSIONID = ? ";
	
	String resetPassword = "UPDATE USER SET PASSWORD = ? WHERE UserID = ?";
	//update user set pasword = "dileep" where user id = "config1" and password != "dileep
	try{
			con = DBConnection.createConnection();			
			
			pStmt2 =  con.prepareStatement(resetPassword);
			pStmt2.setString(1, UserDao.getReHashedPassword(resetcredentialDto.getNewPassword()));
			pStmt2.setString(2, resetcredentialDto.getUserId());
			
			pStmt2.execute();
			
			pStmt1 =  con.prepareStatement(updateSessionInavtive);
			pStmt1.setString(1, ConstantsValues.N);
			pStmt1.setString(2, resetcredentialDto.getUserId());
			pStmt1.setString(3, resetcredentialDto.getSessionInputDTO().getCsrfToken());
			pStmt1.setString(4, resetcredentialDto.getSessionInputDTO().getSessionId());
			pStmt1.execute();
			
			resMessageDto.setMsgType(ConstantsValues.SUCCESSSTATUS);
			resMessageDto.setMessage("UserID " + resetcredentialDto.getUserId()+" details are updated Successfully");
			slf4jLogger.error("UserID " + resetcredentialDto.getUserId()+" details are updated Successfully"); 
			}
	catch (Exception e){
		resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
		resMessageDto.setMessage(ConstantsValues.DATABASEERROR);
		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e); 
	}finally{
	
		if (pStmt != null) {
            try {
            	pStmt.close();
            	pStmt = null;
            } catch (SQLException e) {
            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e); 
            }
        }

        if (con != null) {
            try {
            	con.close();
            	con = null;
            } catch (SQLException e) {
            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e); 
            }
        }
		  slf4jLogger.info("resetPassword method ended");
	}	

	return resMessageDto;
}
public ResMessageDto updateSecurityQA(SecurityAnsInputDto securityAnsInputDto){
	slf4jLogger.info("updateSecurityQA method started");
	ResMessageDto resMessageDto = new ResMessageDto();
	PreparedStatement pStmt=null;
	PreparedStatement pStmt1=null;
	ResultSet rs = null;
	Connection con = null;
	List<SecurityAnsListDto> ansListDto = new ArrayList<>();
	//String updateUserQuery = "UPDATE USER SET SecurityQA=? WHERE UserID = ?";
	//String updateQAQuery = "UPDATE USER SET SecurityQA=? WHERE UserID = ?";
	String checkUserExistQuery = "SELECT Count(1) AS Count FROM SECURITYANSWER WHERE USERID = ?";
	String updateAnswerQuery = "INSERT INTO SECURITYANSWER (USERID, QID, ANSWER) VALUES (?,?,?)";
	try{
		con = DBConnection.createConnection();
	/*	pStmt =  con.prepareStatement(updateQAQuery);
		pStmt.setString(1, ConstantsValues.Y);
		pStmt.setString(2, securityQADTO.getUserId());*/
		pStmt =  con.prepareStatement(updateAnswerQuery);
		pStmt1 =  con.prepareStatement(checkUserExistQuery);
		pStmt1.setString(1, securityAnsInputDto.getUserId());
		rs = pStmt1.executeQuery();
		if(rs.next() && rs.getInt("Count") == 0)
		{
			for (int i = 0,resSize = securityAnsInputDto.getAnsListDto().size(); i < resSize; i++) {
			pStmt.setString(1, securityAnsInputDto.getUserId());
			pStmt.setInt(2, securityAnsInputDto.getAnsListDto().get(i).getQuestionId());
			pStmt.setString(3, securityAnsInputDto.getAnsListDto().get(i).getAns());
			pStmt.addBatch();
			}
			pStmt.executeBatch();
			resMessageDto.setMessage("UserID " + securityAnsInputDto.getUserId()+" details are updated Successfully");
			resMessageDto.setMsgType(ConstantsValues.SUCCESSSTATUS);		
			slf4jLogger.error("UserID " + securityAnsInputDto.getUserId()+" details are updated Successfully"); 
		}
		else{
			resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			resMessageDto.setMessage(ConstantsValues.DUPLICATESECQA);
			slf4jLogger.error(ConstantsValues.DUPLICATESECQA); 
			}
	}
	catch (Exception e){
		resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
		resMessageDto.setMessage(ConstantsValues.DATABASEERROR);
		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e); 
	}finally{
	
		if (pStmt != null) {
            try {
            	pStmt.close();
            	pStmt = null;
            } catch (SQLException e) {
            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e); 
            }
        }

        if (con != null) {
            try {
            	con.close();
            	con = null;
            } catch (SQLException e) {
            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e); 
            }
        }
		  slf4jLogger.info("updateSecurityQA method ended");
	}	

	return resMessageDto;
}
public UserValidationDTO userIdValidation(UserValidationDTO userValidationDTO)  {
	slf4jLogger.info("userIdValidation method started");
	
	ResMessageDto resMessageDto = new ResMessageDto();
	ResultSet rs=null; 
	ResultSet rs1=null; 
	ResultSet rs2=null; 
	PreparedStatement pStmt=null;
	PreparedStatement pStmt1=null;
	PreparedStatement pStmt2=null;
	Connection con = null;
	SessionInputDTO sessionInputDtoObj = null;
	List<SecurityQuestionDto> SecurityQuestionDto = new ArrayList<>();
	
	SecurityQuestionDto SecurityQuestionDtoObj = null;
	String getSecQAExists = "SELECT Count(1) AS Count FROM SECURITYANSWER WHERE USERID = ?";
	String getUserQuestions = "SELECT B.QID, B.QUESTION FROM SECURITYANSWER A, SECURITYQUESTION B WHERE A.QID = B.QID AND USERID = ?";
	try{
		con = DBConnection.createConnection();
		
		pStmt =   con.prepareStatement("SELECT EMAILID FROM USER WHERE USERID = ?"); 
		pStmt.setString(1, userValidationDTO.getUserId());
		rs = pStmt.executeQuery();
		
		pStmt1=   con.prepareStatement(getSecQAExists);
		pStmt1.setString(1, userValidationDTO.getUserId());
		rs1 = pStmt1.executeQuery();
		
		if(rs1.next() && rs1.getInt("Count") == 0){
			userValidationDTO.setSecQAUpdated(false);
		}
		else{
			pStmt2 = con.prepareStatement(getUserQuestions);
			pStmt2.setString(1, userValidationDTO.getUserId());
			rs2 = pStmt2.executeQuery();
			userValidationDTO.setSecQAUpdated(true);
			while (rs2.next()){
				SecurityQuestionDtoObj =  new SecurityQuestionDto();
				SecurityQuestionDtoObj.setQuestionId(rs2.getInt("QID"));
				SecurityQuestionDtoObj.setQuestion(rs2.getString("QUESTION"));
				SecurityQuestionDto.add(SecurityQuestionDtoObj);
			}
			userValidationDTO.setSecurityQuestionDto(SecurityQuestionDto);
		}
		while(rs.next()){
			if(rs.getString("EMAILID").equals(userValidationDTO.getEmailId())){	
				resMessageDto.setMsgType(ConstantsValues.SUCCESSSTATUS);
				resMessageDto.setMessage(ConstantsValues.SUCCESSVALIDATION);
				slf4jLogger.error(ConstantsValues.SUCCESSVALIDATION); 
				userValidationDTO.setResMessageDto(resMessageDto);
				}
			else{
				resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
				resMessageDto.setMessage(ConstantsValues.INVALIDEMAIL);
				slf4jLogger.error(ConstantsValues.INVALIDEMAIL); 

				userValidationDTO.setResMessageDto(resMessageDto);
				}
		
			sessionInputDtoObj = new SessionInputDTO();
			sessionInputDtoObj.setCsrfToken(GetUserDetails.getSaltString());
			sessionInputDtoObj.setSessionId(GetUserDetails.getSaltString());
			
			userValidationDTO.setEmailId("");
			userValidationDTO.setUserId("");
			userValidationDTO.setSessionInputDTO(sessionInputDtoObj);}
		}
	
	catch (Exception e){
		resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
		resMessageDto.setMessage(ConstantsValues.DATABASEERROR);
		userValidationDTO.setEmailId("");
		userValidationDTO.setUserId("");
		userValidationDTO.setResMessageDto(resMessageDto);
		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e); 
	}finally{
	    if (rs != null) {
            try {
            	rs.close();
            	rs = null;
            } catch (SQLException e) {
            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e); 
            }
        }
		if (pStmt != null) {
            try {
            	pStmt.close();
            	pStmt = null;
            } catch (SQLException e) {
            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e); 
            }
        }

        if (con != null) {
            try {
            	con.close();
            	con = null;
            } catch (SQLException e) {
            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e); 
            }
        }
		  slf4jLogger.info("userIdValidation method ended");
	}	

	return userValidationDTO; 
}
public SecQARespDTO getSecurityQuestions(){
	slf4jLogger.info("getSecurityQA method started");
	ResMessageDto resMessageDto = new ResMessageDto();
	PreparedStatement pStmt=null;
	
	ResultSet rs = null;
	Connection con = null;
	List<SecurityQuestionDto> quesListDto = new ArrayList<>();
	SecQARespDTO SecQARespDTO = new SecQARespDTO();
	
	String updateAnswerQuery = "SELECT * FROM SECURITYQUESTION ";
	try{
		con = DBConnection.createConnection();
		SecurityQuestionDto SecurityQuestionDtoObj = null;
		pStmt =  con.prepareStatement(updateAnswerQuery);
		rs = pStmt.executeQuery();	
		while(rs.next()){
			//quesListDto = new ArrayList<>();
			SecurityQuestionDtoObj = new SecurityQuestionDto();
			SecurityQuestionDtoObj.setQuestionId(rs.getInt("QID"));
			SecurityQuestionDtoObj.setQuestion(rs.getString("Question"));
			quesListDto.add(SecurityQuestionDtoObj);
		}
			resMessageDto.setMsgType(ConstantsValues.SUCCESSSTATUS);
			resMessageDto.setMessage(ConstantsValues.GOLDENTEMPNOTIFY);
			slf4jLogger.error(ConstantsValues.GOLDENTEMPNOTIFY); 
			SecQARespDTO.setQuesListDto(quesListDto);	
			SecQARespDTO.setResMessageDto(resMessageDto);
	}
	catch (Exception e){
		resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
		resMessageDto.setMessage(ConstantsValues.DATABASEERROR);
		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e); 
		SecQARespDTO.setResMessageDto(resMessageDto);
	}finally{
	
		if (pStmt != null) {
            try {
            	pStmt.close();
            	pStmt = null;
            } catch (SQLException e) {
            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e); 
            }
        }
        if (con != null) {
            try {
            	con.close();
            	con = null;
            } catch (SQLException e) {
            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e); 
            }
        }
		  slf4jLogger.info("getSecurityQA method ended");
	}	
	return SecQARespDTO;
}
}
