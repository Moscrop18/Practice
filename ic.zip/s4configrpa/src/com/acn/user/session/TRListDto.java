package com.acn.user.session;

import java.util.List;

import com.acn.rpa.imghierarchy.ManageTrResponseDto;

public class TRListDto {
	private List<ManageTrResponseDto> trResponseDto;
	private ResMessageDto resMessageDto;
	public List<ManageTrResponseDto> getTrResponseDto() {
		return trResponseDto;
	}
	public void setTrResponseDto(List<ManageTrResponseDto> trResponseDto) {
		this.trResponseDto = trResponseDto;
	}
	public ResMessageDto getResMessageDto() {
		return resMessageDto;
	}
	public void setResMessageDto(ResMessageDto resMessageDto) {
		this.resMessageDto = resMessageDto;
	}
	
	

}
