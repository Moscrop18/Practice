package com.acn.user.session;

import java.util.List;

import com.acn.rpa.admin.SystemDTO;

public class SystemResDto {
	private ResMessageDto resMessageDto;
	private List<SystemDTO> systemList;
	
	public ResMessageDto getResMessageDto() {
		return resMessageDto;
	}
	public void setResMessageDto(ResMessageDto resMessageDto) {
		this.resMessageDto = resMessageDto;
	}
	public List<SystemDTO> getSystemList() {
		return systemList;
	}
	public void setSystemList(List<SystemDTO> systemList) {
		this.systemList = systemList;
	}
	
	
	
}
