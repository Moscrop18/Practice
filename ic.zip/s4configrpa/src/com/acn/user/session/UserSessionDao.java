package com.acn.user.session;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.service.AdminService;
import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.DBConnection;
import com.acn.rpa.utilities.PropMappings;
import com.acn.rpa.utilities.RoleValidationDto;

public class UserSessionDao {

    private final Logger slf4jLogger = LoggerFactory.getLogger(UserSessionDao.class);

	public boolean userSessionCreation(UserSessionDto userSessionDto) {
		slf4jLogger.info("userSessionCreation method started");
		PreparedStatement preparedStmt = null;
		Connection con = null;
		boolean status = false;
		String query = "INSERT INTO USERSESSION(USERID,BROWSERID,LOGINTIME,SESSIONID,CSRFTOKEN,USEREXPIRYTIME,SESSIONSTATUS) VALUES(?,?,?,?,?,?,?)";
		try {
			con = DBConnection.createConnection();
			preparedStmt = con.prepareStatement(query);
			Timestamp timestamp = new Timestamp(System.currentTimeMillis());
			Timestamp userExpiryTime = new Timestamp(System.currentTimeMillis() + 7200000);
			preparedStmt.setString(1, userSessionDto.getUserID());
			preparedStmt.setString(2, userSessionDto.getBrowserID());
			preparedStmt.setTimestamp(3, timestamp);
			preparedStmt.setString(4, userSessionDto.getSessionId());
			preparedStmt.setString(5, userSessionDto.getCsrfToken());
			preparedStmt.setTimestamp(6, userExpiryTime);
			preparedStmt.setString(7, "Y");
			preparedStmt.execute();
			status = true;

		} catch (Exception e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		} finally {
			if (preparedStmt != null) {
				try {
					preparedStmt.close();
					preparedStmt = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}

			if (con != null) {
				try {
					con.close();
					con = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("userSessionCreation method ended");

		}
		return status;
	}
	
	
	public Boolean resetCSRFToken(UserSessionDto userSessionDto)  {
		slf4jLogger.info("resetCSRFToken method started");
		Connection con = null;
		PreparedStatement pStmt=null;
		Timestamp timestamp = new Timestamp(System.currentTimeMillis()+30);
	  	String query = "UPDATE USERSESSION SET CSRFTOKEN = ?, USEREXPIRYTIME = ? WHERE SESSIONID = ? AND BROWSERID = ? ";
	  	boolean flag=false;
		try{
			con = DBConnection.createConnection();
			pStmt = con.prepareStatement(query);
			pStmt.setString(1, userSessionDto.getCsrfToken());
			pStmt.setTimestamp(2, timestamp);
			pStmt.setString(3, userSessionDto.getSessionId());
			pStmt.setString(4, userSessionDto.getBrowserID());
			if(pStmt.executeUpdate() >0){
				flag = true;
			}
		}
		catch (SQLException e){
		}finally{
			
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("resetCSRFToken method ended");

		}	
		return flag;
	}
	
	
	public ResMessageDto sessionLogout(UserSessionDto userSessionDto)  {
		slf4jLogger.info("sessionLogout method started");
		Connection con = null;
		PreparedStatement pStmt=null;
		Timestamp timestamp = new Timestamp(System.currentTimeMillis()+30);
	  	String query = "UPDATE USERSESSION SET SESSIONSTATUS = ?, REASONFORLOGOUT = ?,LOGOUTTIME = ? WHERE USERID = ? AND CSRFTOKEN = ? AND SESSIONID = ? ";
	  	ResMessageDto resMessageDto = new ResMessageDto();
	  	try{
			con = DBConnection.createConnection();
			pStmt = con.prepareStatement(query);
			pStmt.setString(1, ConstantsValues.N);
			pStmt.setString(2, ConstantsValues.LOGOUTBYUSER);
			pStmt.setTimestamp(3, timestamp);
			pStmt.setString(4, userSessionDto.getUserID());
			pStmt.setString(5, userSessionDto.getSessionInputDTO().getCsrfToken());
			pStmt.setString(6, userSessionDto.getSessionInputDTO().getSessionId());

			if(pStmt.executeUpdate() >0){
				resMessageDto.setMsgType(ConstantsValues.SUCCESSSTATUS);
			}
		}
		catch (SQLException e){
			 resMessageDto.setMessage(ConstantsValues.EXCEPTION);
			 resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			 slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}finally{
			
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("sessionLogout method ended");

		}	
		return resMessageDto;
	}
	
	public static boolean isSessionActive(SessionInputDTO sessionInputDTO,RoleValidationDto roleValidationDto){
		Connection con = null;
		ResultSet rs=null;
		PreparedStatement pStmt=null;		
		String dbName = null;		
		Logger slf4jLogger = LoggerFactory.getLogger(UserSessionDao.class);
		try{
			PropMappings propObj = PropMappings.getInstance();
			dbName = propObj.getValue("S4CONFIGHANA_DB");
			con =  DBConnection.createConnection();
				if(dbName.equals("SAPHANA"))
						pStmt = con.prepareStatement("select B.ROLEID,B.USERID  from USERSESSION A,USER B where A.USERID = B.USERID AND A.SESSIONID = ? AND A.CSRFTOKEN = ? AND  TO_INTEGER(SECONDS_BETWEEN(CURRENT_TIMESTAMP,A.USEREXPIRYTIME)/60) <= ? AND TO_INTEGER(SECONDS_BETWEEN(CURRENT_TIMESTAMP,A.USEREXPIRYTIME)/60) >=? AND A.SESSIONSTATUS = ?");
					else
						pStmt = con.prepareStatement("select B.ROLEID,B.USERID  from USERSESSION A,USER B where A.USERID = B.USERID AND A.SESSIONID = ? AND A.CSRFTOKEN = ? AND  TIMESTAMPDIFF(MINUTE,CURRENT_TIMESTAMP(),A.USEREXPIRYTIME) <= ? AND TIMESTAMPDIFF(MINUTE,CURRENT_TIMESTAMP(),A.USEREXPIRYTIME) >=? AND A.SESSIONSTATUS = ?");
				
					pStmt.setString(1, sessionInputDTO.getSessionId());
					pStmt.setString(2, sessionInputDTO.getCsrfToken());
					pStmt.setInt(3,120);
					pStmt.setInt(4,0);
					pStmt.setString(5,ConstantsValues.Y);
					rs = pStmt.executeQuery();
					return (rs.next() &&  !rs.getString("ROLEID").isEmpty() && roleValidationDto.getRoleIdList().contains(rs.getString("ROLEID")));
	}
		catch (SQLException e){ 
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}
		finally{
			if(rs!=null){
				try {
					rs.close();
					rs = null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if (pStmt != null) {
	            try {
	            	pStmt.close();
	            	pStmt = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }
			if(con!=null){
				try {
					con.close();
					con = null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
		}
		return false;
	}
	
	public static ArrayList<String> getRoleId(SessionInputDTO sessionInputDTO, RoleValidationDto roleValidationDto){
		Connection con = null;
		ResultSet rs=null;
		PreparedStatement pStmt=null;
		ResultSet rs1 = null;
		PreparedStatement pStmt1 = null;
		String dbName = null;
		String roleId = null;
		Logger slf4jLogger = LoggerFactory.getLogger(UserSessionDao.class);
		ArrayList<String> listUserInfo = new ArrayList<>();
		try{
			PropMappings propObj = PropMappings.getInstance();
			dbName = propObj.getValue("S4CONFIGHANA_DB");
			con =  DBConnection.createConnection();
			
			if(dbName.equals("SAPHANA"))
				pStmt1 = con.prepareStatement("select B.USERID  from USERSESSION A,USER B where A.USERID = B.USERID AND A.SESSIONID = ? AND A.CSRFTOKEN = ? AND  TO_INTEGER(SECONDS_BETWEEN(CURRENT_TIMESTAMP,A.USEREXPIRYTIME)/60) <= ? AND TO_INTEGER(SECONDS_BETWEEN(CURRENT_TIMESTAMP,A.USEREXPIRYTIME)/60) >=? AND A.SESSIONSTATUS = ?");
			else
				pStmt1 = con.prepareStatement("select B.USERID  from USERSESSION A,USER B where A.USERID = B.USERID AND A.SESSIONID = ? AND A.CSRFTOKEN = ? AND  TIMESTAMPDIFF(MINUTE,CURRENT_TIMESTAMP(),A.USEREXPIRYTIME) <= ? AND TIMESTAMPDIFF(MINUTE,CURRENT_TIMESTAMP(),A.USEREXPIRYTIME) >=? AND A.SESSIONSTATUS = ?");
		
			pStmt1.setString(1, sessionInputDTO.getSessionId());
			pStmt1.setString(2, sessionInputDTO.getCsrfToken());
			pStmt1.setInt(3,30);
			pStmt1.setInt(4,0);
			pStmt1.setString(5,ConstantsValues.Y);
			rs1 = pStmt1.executeQuery();
			
			
					pStmt = con.prepareStatement("select B.ROLEID from USER B,USERPROJECTS C where  B.USERID = C.USERID  AND C.OMID = ? AND B.USERID= ?");				

					pStmt.setString(1, roleValidationDto.getOmId());
					pStmt.setString(2, rs1.getString("USERID"));
					rs = pStmt.executeQuery();
					if(rs.next()){
						//roleId = rs.getString("ROLEID");
						listUserInfo.add(rs.getString("ROLEID"));
						//listUserInfo.add(rs.getString("USERID"));
					}
				return listUserInfo;
		}
		catch (SQLException e){ 
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}
		finally{
			if(rs!=null){
				try {
					rs.close();
					rs = null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if (pStmt != null) {
	            try {
	            	pStmt.close();
	            	pStmt = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }
			if(con!=null){
				try {
					con.close();
					con = null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
		}
		return listUserInfo;
	}
	
	public static DataStatusDto resetSessionExpirtTime(SessionInputDTO sessionInputDTO)  {
		DataStatusDto resDto = new DataStatusDto();
		ResMessageDto resMessageDto = new ResMessageDto();
		resDto.setResMessageDto(resMessageDto);
		resDto.setDataStatus(false);
		resDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
	    Logger slf4jLoggerObj = LoggerFactory.getLogger(UserSessionDao.class);
	    slf4jLoggerObj.info("resetSessionExpirtTime method started");
		Connection con = null;
		PreparedStatement pStmt=null;
		Timestamp timestamp = new Timestamp(System.currentTimeMillis()+7200000);
	  	String query = "UPDATE USERSESSION SET USEREXPIRYTIME = ? WHERE SESSIONID = ? AND CSRFTOKEN = ? ";
		try{
			con = DBConnection.createConnection();
			pStmt = con.prepareStatement(query);
			pStmt.setTimestamp(1, timestamp);
			pStmt.setString(2, sessionInputDTO.getSessionId());
			pStmt.setString(3, sessionInputDTO.getCsrfToken());
			if(pStmt.executeUpdate() >0){
				resDto.setDataStatus(true);
				resDto.getResMessageDto().setMsgType(ConstantsValues.SUCCESSSTATUS);
			}
		}
		catch (SQLException e){
			//resDto.setDataStatus(true);
			resDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
		}finally{
			
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLoggerObj.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLoggerObj.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			slf4jLoggerObj.info("resetSessionExpirtTime method ended");

		}	
		return resDto;
	}

}
