package com.acn.user.session;



import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

//@XmlRootElement(name = "loginDto")

public class LoginDto {
	
    @Size(min = 1, max = 8)
    @Pattern(regexp = "[a-zA-Z0-9]+")
    private String userId;
    
    @Size(min = 1, max = 64)
    @Pattern(regexp = "[a-zA-Z0-9]+")
    private String toolPwd;
    
    @Size(min = 1, max = 24)
    @Pattern(regexp = "[a-zA-Z0-9]+")
    private String browserId;
    
    @Valid
	private SessionInputDTO sessionInputDTO;
    
	public SessionInputDTO getSessionInputDTO() {
		return sessionInputDTO;
	}
	public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
		this.sessionInputDTO = sessionInputDTO;
	}
    public String getUserId() {
    	return userId;
    }
    public void setUserId(String userId) {
	this.userId = userId;
    }
public String getToolPwd() {
	return toolPwd;
}
public void setToolPwd(String toolPwd) {
	this.toolPwd = toolPwd;
}
public String getBrowserId() {
	return browserId;
}
public void setBrowserId(String browserId) {
	this.browserId = browserId;
}

public String toString() {
    return String.format("userId : %s, toolPwd: %s, browserId : %s",
    		userId, toolPwd, browserId);
}

	
}
