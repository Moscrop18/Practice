package com.acn.user.session;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class SessionInputDTO {
	@Size(min = 1, max = 64)
	@Pattern(regexp = "[a-zA-Z0-9]+")
	private String sessionId;
	
	@Size(min = 1, max = 64)
	@Pattern(regexp = "[a-zA-Z0-9]+")
	private String csrfToken;
	public String getSessionId() {
		return sessionId;
	}
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	public String getCsrfToken() {
		return csrfToken;
	}
	public void setCsrfToken(String csrfToken) {
		this.csrfToken = csrfToken;
	}

}
