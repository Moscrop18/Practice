package com.acn.user.session;

import javax.validation.constraints.Size;

public class SecurityAnsListDto {
	
	//@Size(min = 1, max = 2)
	private int questionId;
	@Size(min = 1, max = 255)
	private String ans;
	public int getQuestionId() {
		return questionId;
	}
	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}
	public String getAns() {
		return ans;
	}
	public void setAns(String ans) {
		this.ans = ans;
	}
	
	

}
