package com.acn.user.session;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class SysInputDto {

	@Size(min = 1, max = 20)
	@Pattern(regexp = "^\\s*[\\da-zA-Z][\\da-zA-Z\\s]*$")
	private String systemType;
	@Size(min = 1, max = 30)
	private String omID;
	
	private String selectedArea;
	@Valid
	private SessionInputDTO sessionInputDTO;
	
	public SessionInputDTO getSessionInputDTO() {
		return sessionInputDTO;
	}
	public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
		this.sessionInputDTO = sessionInputDTO;
	}
	public String getSystemType() {
		return systemType;
	}
	public void setSystemType(String systemType) {
		this.systemType = systemType;
	}
	public String getOmID() {
		return omID;
	}
	public void setOmID(String omID) {
		this.omID = omID;
	}
	public String getSelectedArea() {
		return selectedArea;
	}
	public void setSelectedArea(String selectedArea) {
		this.selectedArea = selectedArea;
	}
	
	
}
