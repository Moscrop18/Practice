package com.acn.user.session;

import java.util.List;

import com.acn.rpa.admin.CustomerDto;

public class CustomerListDto {
	
	private List<CustomerDto> customerList;
	private ResMessageDto resMessageDto;
	
	public List<CustomerDto> getCustomerList() {
		return customerList;
	}
	public void setCustomerList(List<CustomerDto> customerList) {
		this.customerList = customerList;
	}
	public ResMessageDto getResMessageDto() {
		return resMessageDto;
	}
	public void setResMessageDto(ResMessageDto resMessageDto) {
		this.resMessageDto = resMessageDto;
	}
	

}
