package com.acn.user.session;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class UserSessionDto {
	@Size(min = 1, max = 8)
	@Pattern(regexp = "[a-zA-Z0-9]+")
	private String userID;
	
	@Size(min = 1, max = 22)
	@Pattern(regexp = "[a-zA-Z0-9]+")
	private String browserID;
	
	private String loginTime;
	private String sessionId;
	private String csrfToken;
	private String logoutTime;
	private String userExpiryTime;
	private String sessionStatus;
	private String reasonforLogout;
	
	@Valid
	private SessionInputDTO sessionInputDTO;
	
	public SessionInputDTO getSessionInputDTO() {
		return sessionInputDTO;
	}
	public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
		this.sessionInputDTO = sessionInputDTO;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getBrowserID() {
		return browserID;
	}
	public void setBrowserID(String browserID) {
		this.browserID = browserID;
	}
	public String getLoginTime() {
		return loginTime;
	}
	public void setLoginTime(String loginTime) {
		this.loginTime = loginTime;
	}
	
	public String getSessionId() {
		return sessionId;
	}
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	public String getCsrfToken() {
		return csrfToken;
	}
	public void setCsrfToken(String csrfToken) {
		this.csrfToken = csrfToken;
	}
	public String getLogoutTime() {
		return logoutTime;
	}
	public void setLogoutTime(String logoutTime) {
		this.logoutTime = logoutTime;
	}
	public String getUserExpiryTime() {
		return userExpiryTime;
	}
	public void setUserExpiryTime(String userExpiryTime) {
		this.userExpiryTime = userExpiryTime;
	}
	public String getSessionStatus() {
		return sessionStatus;
	}
	public void setSessionStatus(String sessionStatus) {
		this.sessionStatus = sessionStatus;
	}
	public String getReasonforLogout() {
		return reasonforLogout;
	}
	public void setReasonforLogout(String reasonforLogout) {
		this.reasonforLogout = reasonforLogout;
	}
	

}
