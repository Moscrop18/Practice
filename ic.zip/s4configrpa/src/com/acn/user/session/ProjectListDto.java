package com.acn.user.session;

import java.util.List;

import javax.validation.Valid;

import com.acn.rpa.admin.ManageProjectsDto;

public class ProjectListDto {
	@Valid
	private List<ManageProjectsDto> manageProjects;
	@Valid
	private SessionInputDTO sessionInputDTO;
	
	public SessionInputDTO getSessionInputDTO() {
		return sessionInputDTO;
	}
	public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
		this.sessionInputDTO = sessionInputDTO;
	}	
	public List<ManageProjectsDto> getManageProjects() {
		return manageProjects;
	}
	public void setManageProjects(List<ManageProjectsDto> manageProjects) {
		this.manageProjects = manageProjects;
	}
	
	

}
