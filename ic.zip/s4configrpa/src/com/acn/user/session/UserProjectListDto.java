package com.acn.user.session;

import java.util.List;

import com.acn.rpa.config.UserProjectsDto;

public class UserProjectListDto {
	
	public UserProjectListDto(){
		
	}
	
	private List<UserProjectsDto> assignedProjects;
	private ResMessageDto resMessageDto;
	
	public List<UserProjectsDto> getAssignedProjects() {
		return assignedProjects;
	}
	public void setAssignedProjects(List<UserProjectsDto> assignedProjects) {
		this.assignedProjects = assignedProjects;
	}
	public ResMessageDto getResMessageDto() {
		return resMessageDto;
	}
	public void setResMessageDto(ResMessageDto resMessageDto) {
		this.resMessageDto = resMessageDto;
	}
	

}
