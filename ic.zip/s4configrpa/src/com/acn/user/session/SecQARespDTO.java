package com.acn.user.session;

import java.util.List;

public class SecQARespDTO {
	public List<SecurityQuestionDto> getQuesListDto() {
		return quesListDto;
	}
	public void setQuesListDto(List<SecurityQuestionDto> quesListDto) {
		this.quesListDto = quesListDto;
	}
	private List<SecurityQuestionDto> quesListDto;
	private ResMessageDto resMessageDto;

	public ResMessageDto getResMessageDto() {
		return resMessageDto;
	}
	public void setResMessageDto(ResMessageDto resMessageDto) {
		this.resMessageDto = resMessageDto;
	}
	
	

}
