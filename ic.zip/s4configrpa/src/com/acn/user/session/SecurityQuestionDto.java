package com.acn.user.session;

import javax.validation.constraints.Size;

public class SecurityQuestionDto {
	
	//@Size(min = 1, max = 2)
	private int questionId;
	@Size(min = 1, max = 255)
	private String question;
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public int getQuestionId() {
		return questionId;
	}
	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}
	
}
