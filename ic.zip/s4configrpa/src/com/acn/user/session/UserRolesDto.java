package com.acn.user.session;

import java.util.List;

public class UserRolesDto {

		private ResMessageDto resMessageDto;
		private List<String> roles;
		
		public ResMessageDto getResMessageDto() {
			return resMessageDto;
		}
		public void setResMessageDto(ResMessageDto resMessageDto) {
			this.resMessageDto = resMessageDto;
		}
		public List<String> getRoles() {
			return roles;
		}
		public void setRoles(List<String> roles) {
			this.roles = roles;
		}
		
		

	
}
