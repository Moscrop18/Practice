package com.acn.user.session;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class CredentialDto {
	
	 @Size(min = 1, max = 8)
	    @Pattern(regexp = "[a-zA-Z0-9]+")
	    private String userId;
	   
	    @Size(min = 8, max = 64)
	    @Pattern(regexp = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$")
	    private String oldPassword;

		@Size(min = 8, max = 64)
		@Pattern(regexp = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$")
	    private String newPassword;
	    
	    @Valid
		private SessionInputDTO sessionInputDTO;
	    
		public SessionInputDTO getSessionInputDTO() {
			return sessionInputDTO;
		}
		public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
			this.sessionInputDTO = sessionInputDTO;
		}
	    public String getUserId() {
	    	return userId;
	    }
	    public void setUserId(String userId) {
		this.userId = userId;
	    }
	

	public String toString() {
	    return String.format("userId : %s, oldPassword: %s, NewPassword : %s",
	    		userId, oldPassword, newPassword);
	}
	public String getOldPassword() {
			return oldPassword;
		}
		public void setOldPassword(String oldPassword) {
			this.oldPassword = oldPassword;
		}
		public String getNewPassword() {
			return newPassword;
		}
		public void setNewPassword(String newPassword) {
			this.newPassword = newPassword;
		}

}
