package com.acn.encrypt;


	
	import java.io.File;



	/*import java.io.FileInputStream;
	import java.io.FileOutputStream;
	import java.io.IOException;
	import java.io.InputStream;
	import java.io.OutputStream;
	import java.security.InvalidAlgorithmParameterException;
	import java.security.InvalidKeyException;
	import java.security.KeyStore.SecretKeyEntry;
	import java.security.NoSuchAlgorithmException;
	import java.security.SecureRandom;
	import java.security.spec.AlgorithmParameterSpec;
	import java.security.spec.InvalidKeySpecException;

	import javax.crypto.Cipher;
	import javax.crypto.CipherInputStream;
	import javax.crypto.CipherOutputStream;
	import javax.crypto.KeyGenerator;
	import javax.crypto.NoSuchPaddingException;
	import javax.crypto.SecretKey;
	import javax.crypto.SecretKeyFactory;
	import javax.crypto.spec.DESKeySpec;
	import javax.crypto.spec.IvParameterSpec;*/
	import java.io.File;
	import java.io.FileInputStream;
	import java.io.FileOutputStream;
	import java.io.IOException;
	import java.security.InvalidKeyException;
	import java.security.Key;
	import java.security.NoSuchAlgorithmException;
	 
	import javax.crypto.BadPaddingException;
	import javax.crypto.Cipher;
	import javax.crypto.IllegalBlockSizeException;
	import javax.crypto.NoSuchPaddingException;
	import javax.crypto.spec.SecretKeySpec;
	 
	public class AESEncrypt {
		/*public static void encryptanddecrypt(String key,int cipherMode,File in,File out)
				throws NoSuchAlgorithmException,NoSuchPaddingException,InvalidKeyException,InvalidAlgorithmParameterException,InvalidKeySpecException,IOException {
			
			FileInputStream fis=new FileInputStream(in);
			FileOutputStream fos=new FileOutputStream(out);
			DESKeySpec deskeyspec=new DESKeySpec(key.getBytes());
			SecretKeyFactory skf=SecretKeyFactory.getInstance("DES");
			SecretKey secretekey=skf.generateSecret(deskeyspec);
			Cipher cipher = Cipher.getInstance("DES/ECB/PKCS5Padding");
			if(cipherMode==Cipher.ENCRYPT_MODE){
				cipher.init(Cipher.ENCRYPT_MODE, secretekey,SecureRandom.getInstance("SHA1PRNG"));
				CipherInputStream cis=new CipherInputStream(fis,cipher);
			}else if(cipherMode==Cipher.DECRYPT_MODE){
				cipher.init(Cipher.DECRYPT_MODE, secretekey,SecureRandom.getInstance("SHA1PRNG"));
				CipherOutputStream cos=new CipherOutputStream(fos,cipher);
			}
		}
		  private static void write(InputStream input, OutputStream output){
			  byte[] buffer = new byte[512];
			  int numOfBytesRead;
			  while((numOfBytesRead=input.read(buffer)!=-1){
				  
			  }
		  }
	*/
		 private static final String ALGORITHM = "AES";
		    private static final String TRANSFORMATION = "AES";
		 
		    public static void encrypt(String key, File inputFile, File outputFile)
		            throws CryptoException {
		        doCrypto(Cipher.ENCRYPT_MODE, key, inputFile, outputFile);
		    }
		    public static void decrypt(String key, File inputFile, File outputFile)
		            throws CryptoException {
		        doCrypto(Cipher.DECRYPT_MODE, key, inputFile, outputFile);
		    } 
		    private static void doCrypto(int cipherMode, String key, File inputFile,
		            File outputFile) throws CryptoException {
		        try {
		            Key secretKey = new SecretKeySpec(key.getBytes(), ALGORITHM);
		            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
		            cipher.init(cipherMode, secretKey);
		             
		            FileInputStream inputStream = new FileInputStream(inputFile);
		            byte[] inputBytes = new byte[(int) inputFile.length()];
		            inputStream.read(inputBytes);
		             
		            byte[] outputBytes = cipher.doFinal(inputBytes);
		             
		            FileOutputStream outputStream = new FileOutputStream(outputFile);
		            outputStream.write(outputBytes);
		             
		            inputStream.close();
		            outputStream.close();
		             
		        } catch (NoSuchPaddingException | NoSuchAlgorithmException
		                | InvalidKeyException | BadPaddingException
		                | IllegalBlockSizeException | IOException ex) {
		            throw new CryptoException("Error encrypting/decrypting file", ex);
		        }
		    } 
		    public static String decrypt(String key, File inputFile)
		            throws CryptoException {
		       String s= doCrypto(Cipher.DECRYPT_MODE, key, inputFile);
		       return s;
		    }
		 
		    private static String doCrypto(int cipherMode, String key, File inputFile) throws CryptoException {
		    	String s=null;
		    	try {
		            Key secretKey = new SecretKeySpec(key.getBytes(), ALGORITHM);
		            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
		            cipher.init(cipherMode, secretKey);
		             
		            FileInputStream inputStream = new FileInputStream(inputFile);
		            byte[] inputBytes = new byte[(int) inputFile.length()];
		            inputStream.read(inputBytes);
		             
		            byte[] outputBytes = cipher.doFinal(inputBytes);
		            System.out.println("input bytes"+inputBytes);
		            System.out.println("out put bytes"+outputBytes);
		             s=new String(outputBytes);
		           /* FileOutputStream outputStream = new FileOutputStream(outputFile);
		            outputStream.write(outputBytes);
		             */
		            inputStream.close();
		            //outputStream.close();
		             
		        } catch (NoSuchPaddingException | NoSuchAlgorithmException
		                | InvalidKeyException | BadPaddingException
		                | IllegalBlockSizeException | IOException ex) {
		            throw new CryptoException("Error encrypting/decrypting file", ex);
		        }
		        return s;
		    }
	}



