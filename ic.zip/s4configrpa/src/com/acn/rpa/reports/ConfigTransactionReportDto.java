package com.acn.rpa.reports;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.acn.user.session.SessionInputDTO;

public class ConfigTransactionReportDto {
	@Size(min = 1, max = 20)
	private String omID;
	@Valid
	private SessionInputDTO sessionInputDTO;
	@Size(min = 1, max = 8)
	@Pattern(regexp = "[a-zA-Z0-9]+") 
	private String userID;
	
	public String getOmID() {
		return omID;
	}
	public void setOmID(String omID) {
		this.omID = omID;
	}
		
	public SessionInputDTO getSessionInputDTO() {
		return sessionInputDTO;
	}
	public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
		this.sessionInputDTO = sessionInputDTO;
	}	
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}

}
