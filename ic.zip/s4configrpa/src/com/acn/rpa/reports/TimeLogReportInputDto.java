package com.acn.rpa.reports;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.acn.user.session.SessionInputDTO;

public class TimeLogReportInputDto {
	@Size(min = 1, max = 20)
	@Pattern(regexp = "[a-zA-Z0-9]+")
	private String destinationName;

	public String getDestinationName() {
		return destinationName;
	}

	public void setDestinationName(String destinationName) {
		this.destinationName = destinationName;
	}
	@Valid
	private SessionInputDTO sessionInputDTO;
	
	public SessionInputDTO getSessionInputDTO() {
		return sessionInputDTO;
	}
	public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
		this.sessionInputDTO = sessionInputDTO;
	}

}
