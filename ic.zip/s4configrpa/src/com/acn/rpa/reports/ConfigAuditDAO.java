package com.acn.rpa.reports;


import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.admin.ResponseDto;
import com.acn.rpa.config.dto.ConfigDownloadHistoryDto;
import com.acn.rpa.config.dto.ConfigTransactionDto;
import com.acn.rpa.config.dto.ConfigUploadHistoryDto;
import com.acn.rpa.config.dto.UploadExecutionLogDto;
import com.acn.rpa.service.AdminService;
import com.acn.rpa.service.AesUtil;
import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.DBConnection;

public class ConfigAuditDAO { 
    private final Logger slf4jLogger = LoggerFactory.getLogger(ConfigAuditDAO.class);

public ResponseDto configTransaction(String UserID){
	  	slf4jLogger.info("configTransaction method started");
		Connection con = null;
		ResultSet rs=null;
		ResultSet rs1=null;
		PreparedStatement ps=null;
		PreparedStatement ps1=null;
		PreparedStatement ps2=null;
		PreparedStatement ps3=null;
		ResponseDto responseDtoObj = new ResponseDto();
		
		try{
			con =  DBConnection.createConnection();
			ps = con.prepareStatement("SELECT * FROM configtransaction WHERE UserID = ? LIMIT 5");
			ps.setString(1, UserID);
			rs = ps.executeQuery();
			if(!rs.next()){
				responseDtoObj.setMessage("The userId " + UserID + "does not exist!");
				responseDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
				return responseDtoObj;
			}
			if(rs!=null){
				try {
					rs.close();
					rs=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(ps!=null){
				try {
					ps.close();
					ps=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
		}
		catch (SQLException e){
			responseDtoObj.setMessage("Could not save the config state for the userId ");
			responseDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}
		finally{			
			if(rs1!=null){
				try {
					rs1.close();
					rs1=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}			
			if(rs!=null){
				try {
					rs.close();
					rs=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(ps1!=null){
				try {
					ps1.close();
					ps1=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(ps2!=null){
				try {
					ps2.close();
					ps2=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(ps3!=null){
				try {
					ps3.close();
					ps3=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
		}
		return responseDtoObj;
		}
	public int createConfigTransaction(ConfigTransactionDto configTransactionDto){
		slf4jLogger.info("createConfigTransaction method started");
		Connection con = null;
		PreparedStatement preparedStmt =  null;
		PreparedStatement preparedStmt1 =  null;
		ResultSet tableKeys = null;
		Date date = new java.util.Date();
		Timestamp timestamp = new java.sql.Timestamp(date.getTime());
		int transactionId = 0;
		String insertQuery = null;
		//String sapUserId = null;
		try{
			if(configTransactionDto.isConfigReExe())
				insertQuery = "UPDATE ConfigTransaction SET UserID = ?,OMID = ?,CreatedDate = ?, SapUserID = ?,Scenario = ?,TargetSystemId = ?,SourceSystemId = ? where TransID = ? ";
			else
				insertQuery = "insert into ConfigTransaction(UserID,OMID,CreatedDate, SapUserID,Scenario,TargetSystemId,SourceSystemId) values (?,?,?,?,?,?,?)";
			 
			/*if(configTransactionDto.getSapUserID() != null && !configTransactionDto.getSapUserID().equals("")) {
				String cipherTextSapUser =  new String(java.util.Base64.getDecoder().decode(configTransactionDto.getSapUserID()));
				AesUtil aesUtil = new AesUtil(128, 1000);
				sapUserId = aesUtil.decrypt(cipherTextSapUser.split("::")[1], cipherTextSapUser.split("::")[0], configTransactionDto.getDestinationName(), cipherTextSapUser.split("::")[2]);
			}*/
			con  = DBConnection.createConnection();
			preparedStmt = con.prepareStatement(insertQuery);
			preparedStmt.setString(1, configTransactionDto.getUserID());
			preparedStmt.setString(2, configTransactionDto.getOmgID());
			preparedStmt.setTimestamp(3, timestamp);
				preparedStmt.setString(4, configTransactionDto.getSapUserID());
			preparedStmt.setString(5, configTransactionDto.getScenario());
			preparedStmt.setInt(6, configTransactionDto.getTargetValue());
			preparedStmt.setInt(7, configTransactionDto.getSourceValue());
			if(configTransactionDto.isConfigReExe())
				preparedStmt.setInt(8, configTransactionDto.getTransactionID());
			
		    preparedStmt.executeUpdate();
		    if(configTransactionDto.isConfigReExe())
		    	transactionId = configTransactionDto.getTransactionID();
		    else{
		    	preparedStmt1 = con.prepareStatement("SELECT MAX(TransID) from ConfigTransaction");
		    	tableKeys = preparedStmt1.executeQuery();
		    	tableKeys.next();
		    	transactionId = tableKeys.getInt(1);
		    }
			}catch(SQLException e){
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}catch(Exception e){
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}finally {
				if (preparedStmt != null) {
		            try {
		            	preparedStmt.close();
		            	preparedStmt = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
				
				if (preparedStmt1 != null) {
		            try {
		            	preparedStmt1.close();
		            	preparedStmt1 = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
				
		        if (con != null) {
		            try {
		            	con.close();
		            	con = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
				  slf4jLogger.info("createConfigTransaction method ended");

			}
		
		return transactionId;
	}
	
	public boolean createConfigDwdHistory(ConfigDownloadHistoryDto configDownloadHistoryDto){
		slf4jLogger.info("createConfigDwdHistory method started");
		Connection con = null;
		PreparedStatement preparedStmt =  null;
		boolean validationResult = false;
		Date date = new java.util.Date();
		Timestamp timestamp = new java.sql.Timestamp(date.getTime());
		String insertQuery = "INSERT into ConfigDownloadHistory (TransID,IMGID,CreatedDate,Status,Message,downloadstarttime,downloadendtime) VALUES (?,?,?,?,?,?,?)";

		try{
			con  = DBConnection.createConnection();
			 int a=0;
			preparedStmt = con.prepareStatement(insertQuery);
			preparedStmt.setInt(1, configDownloadHistoryDto.getTransactionID());
			preparedStmt.setString(2, configDownloadHistoryDto.getImgID());
			preparedStmt.setTimestamp(3, timestamp);
			preparedStmt.setString(4,configDownloadHistoryDto.getStatus());
			preparedStmt.setString(5,configDownloadHistoryDto.getMessage());
			preparedStmt.setTimestamp(6,configDownloadHistoryDto.getDownloadStartTime());
			preparedStmt.setTimestamp(7, timestamp);
			validationResult =  preparedStmt.execute();
			}catch(SQLException e){
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}catch(Exception e){
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}finally {
				if (preparedStmt != null) {
		            try {
		            	preparedStmt.close();
		            	preparedStmt = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
		        if (con != null) {
		            try {
		            	con.close();
		            	con = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
				  slf4jLogger.info("createConfigDwdHistory method ended");

			}
		
		return validationResult;
	}
	
	
	public int createConfigUploadHistory(ConfigUploadHistoryDto configUploadHistoryDto){
		slf4jLogger.info("createConfigUploadHistory method started");
		Connection con = null;
		PreparedStatement preparedStmt =  null;
		PreparedStatement preparedStmt1 =  null;
		String insertQuery = null;
		Date date = new java.util.Date();
		ResultSet tableKeys = null;
		Timestamp timestamp = new java.sql.Timestamp(date.getTime());
		boolean recordExists = configUploadHistoryDto.getConfigUploadID() == 0 ? false : true; 
		if(!recordExists)
			insertQuery = "INSERT into ConfigUploadHistory (TransID,IMGID,CreatedDate,Status,CTR,KTR,ExecutionStartTime,ExecutionEndTime,RecordCount) VALUES (?,?,?,?,?,?,?,?,?)";
		else
			insertQuery = "UPDATE ConfigUploadHistory SET TransID = ?,IMGID = ?,CreatedDate = ?,Status = ?,CTR = ?,KTR = ?,ExecutionStartTime = ?,ExecutionEndTime = ?,RecordCount = ? where ConfigUploadID = ?";

		int transactionId = 0;
		try{
			con  = DBConnection.createConnection();
			preparedStmt = con.prepareStatement(insertQuery);
			preparedStmt.setInt(1, configUploadHistoryDto.getTransactionID());
		    preparedStmt.setString (2, configUploadHistoryDto.getImgID());
		    preparedStmt.setTimestamp(3, timestamp);
		    preparedStmt.setString (4, configUploadHistoryDto.getStatus());
		    preparedStmt.setString (5, configUploadHistoryDto.getCustomizingTr());
		    preparedStmt.setString (6, configUploadHistoryDto.getWorkbenchTr());
		    preparedStmt.setTimestamp (7, configUploadHistoryDto.getExecutionStartTime());
		    preparedStmt.setTimestamp (8, timestamp);
		    preparedStmt.setInt(9, configUploadHistoryDto.getRecordCount());
		    if(recordExists)
			    preparedStmt.setInt(10, configUploadHistoryDto.getConfigUploadID());

		
		    preparedStmt.executeUpdate();
		    if(!recordExists){
		    preparedStmt1 = con.prepareStatement("SELECT MAX(ConfigUploadID) from ConfigUploadHistory");
			tableKeys = preparedStmt1.executeQuery();
			tableKeys.next();
			transactionId = tableKeys.getInt(1);
		    }
		    else{
		    	transactionId = configUploadHistoryDto.getConfigUploadID();
		    }
		
			}catch(SQLException e){
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}finally {
				if (preparedStmt != null) {
		            try {
		            	preparedStmt.close();
		            	preparedStmt = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }

				if (preparedStmt1 != null) {
		            try {
		            	preparedStmt1.close();
		            	preparedStmt1 = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
		        if (con != null) {
		            try {
		            	con.close();
		            	con = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
				  slf4jLogger.info("createConfigUploadHistory method ended");

			}
		
		return transactionId;
	}
	
	public int createUploadExecutionLog(ArrayList<UploadExecutionLogDto> uploadExecutionLogList){
		slf4jLogger.info("createUploadExecutionLog method started");
		Connection con = null;
		PreparedStatement preparedStmt =  null;
		InputStream input = null;
		String insertQuery = null;
		int recordCount = 0;	
		try{
			input = DBConnection.class.getClassLoader().getResourceAsStream("config.properties");
			con  = DBConnection.createConnection();
			Properties prop = new Properties();
		  	prop.load(input);
		  	if(prop.getProperty("S4CONFIGHANA_DB").equals("SAPHANA")){
				insertQuery = "UPSERT ExecutionLog(ConfigUploadID,SequnceID,Status,Message) VALUES (?,?,?,?) where ConfigUploadID = ? and SequnceID = ?";
			}
		  	else{
				insertQuery = "INSERT into ExecutionLog(ConfigUploadID,SequnceID,Status,Message) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE Status=VALUES(Status), Message = VALUES(Message)";

		  	}
		  		
			preparedStmt = con.prepareStatement(insertQuery);
			for(UploadExecutionLogDto dto: uploadExecutionLogList){
				preparedStmt.setInt(1, dto.getConfigUploadID());
				preparedStmt.setInt(2, dto.getSequenceID());
				preparedStmt.setString (3, dto.getStatus());
				preparedStmt.setString (4, dto.getMessage());
				if(prop.getProperty("S4CONFIGHANA_DB").equals("SAPHANA")){
					preparedStmt.setInt (5, dto.getConfigUploadID());
					preparedStmt.setInt (6, dto.getSequenceID());
				}
				preparedStmt.addBatch();
			}
			
			preparedStmt.executeBatch();
			}catch(SQLException e){
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}catch(Exception e){
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}finally {
				if (preparedStmt != null) {
		            try {
		            	preparedStmt.close();
		            	preparedStmt = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }

		        if (con != null) {
		            try {
		            	con.close();
		            	con = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
				  slf4jLogger.info("createUploadExecutionLog method ended");

			}
		
		return recordCount;
	}
	
	
	public ArrayList<ConfigTransactionDto> reteriveConfigTransaction(){
		slf4jLogger.info("reteriveConfigTransaction method started");
		ArrayList<ConfigTransactionDto>  configTransactionList = new ArrayList<ConfigTransactionDto>();
		ConfigTransactionDto configTransactionDto = null;
		Connection con = null;
		PreparedStatement preparedStmt =  null;
		ResultSet rs = null;
		String reteriveQuery =  "SELECT * FROM ConfigTransaction";
		try{
			con  = DBConnection.createConnection();
			preparedStmt = con.prepareStatement(reteriveQuery);
		    rs = preparedStmt.executeQuery();
		    
			while(rs.next()){
				configTransactionDto = new ConfigTransactionDto();
				
				configTransactionDto.setTransactionID(rs.getInt("TransID"));
				configTransactionDto.setOmgID(rs.getString("OMID"));
				configTransactionDto.setUserID(rs.getString("UserID"));
				configTransactionDto.setCreatedDate(rs.getTimestamp("CreatedDate"));
				configTransactionList.add(configTransactionDto);
			}
		    
			}catch(SQLException e){
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}catch(Exception e){
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}finally {
				if (rs != null) {
		            try {
		            	rs.close();
		            	rs = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
				
				if (preparedStmt != null) {
		            try {
		            	preparedStmt.close();
		            	preparedStmt = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
		        if (con != null) {
		            try {
		            	con.close();
		            	con = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
				  slf4jLogger.info("reteriveConfigTransaction method ended");

			}
		return configTransactionList;
		
	}
	
	
	public ArrayList<ConfigDownloadHistoryDto> reteriveConfigDownloadHistory(){
		slf4jLogger.info("reteriveConfigDownloadHistory method started");
		ArrayList<ConfigDownloadHistoryDto>  configDownloadHistoryList = new ArrayList<ConfigDownloadHistoryDto>();
		ConfigDownloadHistoryDto configDownloadHistoryDto = null;
		Connection con = null;
		PreparedStatement preparedStmt =  null;
		ResultSet rs = null;
		String reteriveQuery =  "SELECT * FROM ConfigDownloadHistory";
		try{
			con  = DBConnection.createConnection();
			preparedStmt = con.prepareStatement(reteriveQuery);
		    rs = preparedStmt.executeQuery();
		    
			while(rs.next()){
				configDownloadHistoryDto = new ConfigDownloadHistoryDto();
				configDownloadHistoryDto.setConfigDownloadID(rs.getInt("ConfigDwdID"));
				configDownloadHistoryDto.setTransactionID(rs.getInt("TransID"));
				configDownloadHistoryDto.setProjectName(rs.getString("ProjectName"));
				configDownloadHistoryDto.setScenario(rs.getString("Scenario"));
				configDownloadHistoryDto.setOmgID(rs.getString("OMID"));
				configDownloadHistoryDto.setSystemID(rs.getString("SystemID"));
				configDownloadHistoryDto.setImgID(rs.getString("IMGID"));
				configDownloadHistoryDto.setUserID(rs.getString("User"));
				configDownloadHistoryDto.setCreatedDate(rs.getTimestamp("CreatedDate"));
				configDownloadHistoryDto.setStatus(rs.getString("Status"));
				configDownloadHistoryDto.setMessage(rs.getString("Message"));
				configDownloadHistoryList.add(configDownloadHistoryDto);
			}
		    
			}catch(SQLException e){
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}catch(Exception e){
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}finally {
				  if (rs != null) {
			            try {
			            	rs.close();
			            	rs = null;
			            } catch (SQLException e) {
			            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			            }
			        }
				   
				if (preparedStmt != null) {
		            try {
		            	preparedStmt.close();
		            	preparedStmt = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
		        if (con != null) {
		            try {
		            	con.close();
		            	con = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
				  slf4jLogger.info("reteriveConfigDownloadHistory method ended");

			}
		return configDownloadHistoryList;
		
	}
	
	public ArrayList<ConfigUploadHistoryDto> reteriveConfigUploadHistory(){
		slf4jLogger.info("reteriveConfigUploadHistory method started");
		ArrayList<ConfigUploadHistoryDto>  configUploadHistoryList = new ArrayList<ConfigUploadHistoryDto>();
		ConfigUploadHistoryDto configUploadHistoryDto = null;
		Connection con = null;
		PreparedStatement preparedStmt =  null;
		ResultSet rs = null;
		String reteriveQuery =  "SELECT * FROM ConfigUploadHistory";
		try{
			con  = DBConnection.createConnection();
			preparedStmt = con.prepareStatement(reteriveQuery);
		    rs = preparedStmt.executeQuery();
		    
			while(rs.next()){
				configUploadHistoryDto = new ConfigUploadHistoryDto();
				configUploadHistoryDto.setConfigUploadID(rs.getInt("ConfigUploadID"));
				configUploadHistoryDto.setTransactionID(rs.getInt("TransID"));
				configUploadHistoryDto.setProjectName(rs.getString("ProjectName"));
				configUploadHistoryDto.setScenario(rs.getString("Scenario"));
				configUploadHistoryDto.setModule(rs.getString("Module"));
				configUploadHistoryDto.setOmgID(rs.getString("OMID"));
				configUploadHistoryDto.setSystemID(rs.getString("SystemID"));
				configUploadHistoryDto.setImgID(rs.getString("IMGID"));
				configUploadHistoryDto.setUserID(rs.getString("User"));
				configUploadHistoryDto.setCreatedDate(rs.getTimestamp("CreatedDate"));
				configUploadHistoryDto.setStatus(rs.getString("Status"));
				configUploadHistoryList.add(configUploadHistoryDto);
			}
		    
			}catch(SQLException e){
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}catch(Exception e){
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}finally {
				  if (rs != null) {
			            try {
			            	rs.close();
			            	rs = null;
			            } catch (SQLException e) {
			            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			            }
			        }
				  
				if (preparedStmt != null) {
		            try {
		            	preparedStmt.close();
		            	preparedStmt = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
		        if (con != null) {
		            try {
		            	con.close();
		            	con = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
				  slf4jLogger.info("reteriveConfigUploadHistory method ended");

			}
		return configUploadHistoryList;
		
	}
	
	
	public ArrayList<UploadExecutionLogDto> reteriveUploadExecutionLog(){
		slf4jLogger.info("reteriveUploadExecutionLog method started");
		ArrayList<UploadExecutionLogDto>  uploadExecutionLogList = new ArrayList<UploadExecutionLogDto>();
		UploadExecutionLogDto uploadExecutionLogDto = null;
		Connection con = null;
		PreparedStatement preparedStmt =  null;
		ResultSet rs = null;
		String reteriveQuery =  "SELECT * FROM ExecutionLog";
		try{
			con  = DBConnection.createConnection();
			preparedStmt = con.prepareStatement(reteriveQuery);
		    rs = preparedStmt.executeQuery();
		    
			while(rs.next()){
				uploadExecutionLogDto = new UploadExecutionLogDto();
				uploadExecutionLogDto.setConfigUploadID(rs.getInt("ConfigUploadID"));
				uploadExecutionLogDto.setImgID(rs.getString("IMGID"));
				uploadExecutionLogDto.setSequenceID(rs.getInt("SequnceID"));
				uploadExecutionLogDto.setStatus(rs.getString("Status"));
				uploadExecutionLogDto.setUserID(rs.getString("User"));
				uploadExecutionLogDto.setMessage(rs.getString("Message"));
				uploadExecutionLogList.add(uploadExecutionLogDto);
			}
		    
			}catch(SQLException e){
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}catch(Exception e){
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}finally {
				
				  if (rs != null) {
			            try {
			            	rs.close();
			            	rs = null;
			            } catch (SQLException e) {
			            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			            }
			        }
				  
				  
				if (preparedStmt != null) {
		            try {
		            	preparedStmt.close();
		            	preparedStmt = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
		        if (con != null) {
		            try {
		            	con.close();
		            	con = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
				  slf4jLogger.info("reteriveUploadExecutionLog method ended");

			}
		return uploadExecutionLogList;
		
	}
}