package com.acn.rpa.reports;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.DBConnection;
import com.acn.rpa.utilities.PropMappings;

public class ConfigTransactionReportDAO { 	

    private final Logger slf4jLogger = LoggerFactory.getLogger(ConfigTransactionReportDAO.class);

public ArrayList<ConfigResponseReportDto> getConfigTransactionData(ConfigTransactionReportDto ConfigTransactionReportDto){
	  	slf4jLogger.info("getConfigTransactionData method started");
		ArrayList<ConfigResponseReportDto>  configExecutionLogList = new ArrayList<ConfigResponseReportDto>();
		Connection con = null;
		PreparedStatement preparedStmt =  null;
		ResultSet rs = null;
		String reteriveQuery = "";
		
		if(ConfigTransactionReportDto.getUserID() == null){
			 reteriveQuery =  "SELECT a.TransID,a.userid,a.scenario,a.sapuserid,a.createddate,b.destinationname,(select b.destinationname from sapsystem b where a.sourcesystemid = b.id ) Sourcename,"
						+ "(select count(1) from configuploadhistory where transid = a.transid) Count from configtransaction a,sapsystem b where a.targetsystemid = b.id and a.OmID =? ORDER BY a.createddate DESC";
			
		}
		else{
			 reteriveQuery =  "SELECT a.TransID,a.userid,a.scenario,a.sapuserid,a.createddate,b.destinationname,(select b.destinationname from sapsystem b where a.sourcesystemid = b.id ) Sourcename,"
						+ "(select count(1) from configuploadhistory where transid = a.transid) Count from configtransaction a,sapsystem b where a.targetsystemid = b.id and a.UserID = ? and a.OmID =? ORDER BY a.createddate DESC";
							
		}
		
		try{
			con  = DBConnection.createConnection();
			preparedStmt = con.prepareStatement(reteriveQuery);
			if(ConfigTransactionReportDto.getUserID() == null ){
				
				preparedStmt.setString(1, ConfigTransactionReportDto.getOmID());
			
			}else
			{
				preparedStmt.setString(1, ConfigTransactionReportDto.getUserID());
				preparedStmt.setString(2, ConfigTransactionReportDto.getOmID());
			}
		    rs = preparedStmt.executeQuery();
			while(rs.next()){
				ConfigResponseReportDto ConfigResponseReportDto = new ConfigResponseReportDto();
				ConfigResponseReportDto.setImplType(rs.getString("scenario"));
				ConfigResponseReportDto.setSapUserID(rs.getString("sapuserid"));
				ConfigResponseReportDto.setCount(rs.getInt("Count"));
				ConfigResponseReportDto.setTargetDestinationname(rs.getString("destinationname"));
				ConfigResponseReportDto.setSourceDestinationname(rs.getString("Sourcename"));
				ConfigResponseReportDto.setTimeStamp(rs.getTimestamp("createddate"));
				ConfigResponseReportDto.setTransID(rs.getInt("TransID"));
				ConfigResponseReportDto.setUserID(rs.getString("userid"));
				configExecutionLogList.add(ConfigResponseReportDto);
			}
		    
			}catch(SQLException e){
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}catch(Exception e){
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}finally {
				
				  if (rs != null) {
			            try {
			            	rs.close();
			            	rs = null;
			            } catch (SQLException e) {
			            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			            }
			        }			  
				if (preparedStmt != null) {
		            try {
		            	preparedStmt.close();
		            	preparedStmt = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
		        if (con != null) {
		            try {
		            	con.close();
		            	con = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
				  slf4jLogger.info("getConfigTransactionData method ended");

			}
		return configExecutionLogList;
	}

public ExecutionSummaryResDto getConfigUploadTransactionData(ConfigResponseReportDto configTransactionInputDto){
	slf4jLogger.info("getConfigUploadTransactionData method started");
	ArrayList<ConfigResReportDto>  configUploadTransList = new ArrayList<ConfigResReportDto>();
	Connection con = null;
	PreparedStatement preparedStmt =  null;
	ResultSet rs = null;
	XSSFWorkbook workBook = null;
	XSSFSheet sheet = null;
	Row selectedRow = null;
	Cell cell = null;
	int rowCount = 0;
	int columnCount = 0;
	String dbName = null;
	String reteriveQuery = null;
	ConfigResReportDto ConfigResReportDto = null;
	ExecutionSummaryResDto executionSummaryResDto = null;
	ByteArrayOutputStream bos = null;
	byte[] bytes = null;
	ConfigReportResDTO configReportResDTO = null;
	try{
		
		PropMappings propObj = PropMappings.getInstance();

		dbName = propObj.getValue("S4CONFIGHANA_DB");
		if(configTransactionInputDto.getImplType().equalsIgnoreCase("Consolidated Configuration")) {
			if(dbName.equals("SAPHANA")){
				reteriveQuery =  "SELECT a.imgid, a.ConfiguploadID,a.status,a.ctr,a.ktr,c.imgdescr,c.module FROM imghierarchy c,configuploadhistory a, configtransaction b where a.transid = b.transid and SUBSTR_BEFORE(a.IMGID,'-') = c.imgid and b.transid =? and c.enabled=1 ORDER BY a.status DESC";
			}else {
				reteriveQuery =  "SELECT a.imgid, a.ConfiguploadID,a.status,a.ctr,a.ktr,c.imgdescr,c.module FROM imghierarchy c,configuploadhistory a, configtransaction b where a.transid = b.transid and SUBSTRING_INDEX(a.IMGID,'-',1) = c.imgid and b.transid =?  and c.enabled=1 ORDER BY a.status DESC";
			}
		}else {
			
			if(configTransactionInputDto.isIndustryFlag()) {
				reteriveQuery =  "SELECT a.ConfiguploadID,a.status,a.ctr,a.ktr,c.imgdescr,c.module FROM INDUSTRY_IMGHIERARCHY c,configuploadhistory a, configtransaction b where a.transid = b.transid and a.IMGID = c.imgid and b.transid =? and c.enabled=1 and C.INDUSTRY LIKE ? AND C.SUBINDUSTRY LIKE ? ORDER BY a.status DESC";
			}else
			reteriveQuery =  "SELECT a.ConfiguploadID,a.status,a.ctr,a.ktr,c.imgdescr,c.module FROM imghierarchy c,configuploadhistory a, configtransaction b where a.transid = b.transid and a.IMGID = c.imgid and b.transid =? and c.enabled=1 ORDER BY a.status DESC";
		}
		bos = new ByteArrayOutputStream();

		con  = DBConnection.createConnection();
		preparedStmt = con.prepareStatement(reteriveQuery);
		preparedStmt.setInt(1, configTransactionInputDto.getTransID());
		if(configTransactionInputDto.isIndustryFlag()) {
			preparedStmt.setString(2, "%" + configTransactionInputDto.getIndustry() + "%");
			preparedStmt.setString(3, "%" + configTransactionInputDto.getSubIndustry() + "%");
		}
	    rs = preparedStmt.executeQuery();
	    executionSummaryResDto = new ExecutionSummaryResDto();
	    workBook = new XSSFWorkbook();
	    Date date = new java.util.Date();
		Timestamp timestamp = new java.sql.Timestamp(date.getTime());
		 sheet = workBook.createSheet();

		 XSSFCellStyle blueStyle = workBook.createCellStyle();
		 blueStyle.setFillForegroundColor(new XSSFColor(new Color(47,117,181)));
		 blueStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
	    
		 XSSFCellStyle orangeStyle = workBook.createCellStyle();
		 orangeStyle.setFillForegroundColor(new XSSFColor(new Color (250,191,143)));
		 orangeStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
	    
	    selectedRow = sheet.createRow(rowCount++);
	    cell = selectedRow.createCell(columnCount++);
	    cell.setCellType(Cell.CELL_TYPE_STRING);
	    cell.setCellValue("Implementation Type");
		cell.setCellStyle(blueStyle);
		
	    cell = selectedRow.createCell(columnCount++);
	    cell.setCellType(Cell.CELL_TYPE_STRING);
	    cell.setCellValue(configTransactionInputDto.getImplType());
		cell.setCellStyle(orangeStyle);
		columnCount++;
	    cell = selectedRow.createCell(columnCount++);
	    cell.setCellType(Cell.CELL_TYPE_STRING);
	    cell.setCellValue("SAP User");
		cell.setCellStyle(blueStyle);
		cell = selectedRow.createCell(columnCount++);
	    cell.setCellType(Cell.CELL_TYPE_STRING);
	    cell.setCellValue(configTransactionInputDto.getSapUserID());
		cell.setCellStyle(orangeStyle);
		
		columnCount = 0;
		selectedRow = sheet.createRow(rowCount++);
	    cell = selectedRow.createCell(columnCount++);
	    cell.setCellType(Cell.CELL_TYPE_STRING);
	    cell.setCellValue("Source System");
		cell.setCellStyle(blueStyle);

	    cell = selectedRow.createCell(columnCount++);
	    cell.setCellType(Cell.CELL_TYPE_STRING);
	    cell.setCellValue(configTransactionInputDto.getSourceDestinationname());
		cell.setCellStyle(orangeStyle);
		columnCount++;
	    cell = selectedRow.createCell(columnCount++);
	    cell.setCellType(Cell.CELL_TYPE_STRING);
	    cell.setCellValue("Execution Time");
		cell.setCellStyle(blueStyle);
		cell = selectedRow.createCell(columnCount++);
	    cell.setCellType(Cell.CELL_TYPE_STRING);
	    cell.setCellValue("'"+timestamp);
		cell.setCellStyle(orangeStyle);
		
		columnCount = 0;
		selectedRow = sheet.createRow(rowCount++);
	    cell = selectedRow.createCell(columnCount++);
	    cell.setCellType(Cell.CELL_TYPE_STRING);
	    cell.setCellValue("Target System");
		cell.setCellStyle(blueStyle);

	    cell = selectedRow.createCell(columnCount++);
	    cell.setCellType(Cell.CELL_TYPE_STRING);
	    cell.setCellValue(configTransactionInputDto.getTargetDestinationname());
		cell.setCellStyle(orangeStyle);
		columnCount++;
	    cell = selectedRow.createCell(columnCount++);
	    cell.setCellType(Cell.CELL_TYPE_STRING);
	    cell.setCellValue("No of IMGs");
		cell.setCellStyle(blueStyle);
		cell = selectedRow.createCell(columnCount++);
	    cell.setCellType(Cell.CELL_TYPE_STRING);
	    cell.setCellValue(configTransactionInputDto.getCount());
		cell.setCellStyle(orangeStyle);
		
		rowCount++;
		
		columnCount = 0;
		selectedRow = sheet.createRow(rowCount++);
		cell = selectedRow.createCell(columnCount++);
	    cell.setCellType(Cell.CELL_TYPE_STRING);
	    cell.setCellValue("ImgDescription");
		cell.setCellStyle(blueStyle);
		cell = selectedRow.createCell(columnCount++);
	    cell.setCellType(Cell.CELL_TYPE_STRING);
	    cell.setCellValue("MessageType");
		cell.setCellStyle(blueStyle);
		cell = selectedRow.createCell(columnCount++);
	    cell.setCellType(Cell.CELL_TYPE_STRING);
	    cell.setCellValue("ImgDescription");
		cell.setCellStyle(blueStyle);
			
	   while(rs.next()){
			ConfigResReportDto = new ConfigResReportDto();
			configReportResDTO = getExecutionLogData(rs.getString("ConfiguploadID"),rs.getString("imgdescr"),workBook,rowCount);
			workBook = configReportResDTO.getWorkBook();
			rowCount = configReportResDTO.getRowNum();
			ConfigResReportDto.setExecutionsLogSummary(configReportResDTO.getConfigExecutionLogList());
			if(configTransactionInputDto.getImplType().equalsIgnoreCase("Consolidated Configuration")) {
				String imgId = rs.getString("imgid");
				String objName = imgId.split("-")[1];
				ConfigResReportDto.setIMGDesc(rs.getString("imgdescr").concat("-").concat(objName));
			}
			else {
				ConfigResReportDto.setIMGDesc(rs.getString("imgdescr"));
			}
			ConfigResReportDto.setStatus(rs.getString("status"));
			ConfigResReportDto.setCTR(rs.getString("ctr"));
			ConfigResReportDto.setKTR(rs.getString("ktr"));
			ConfigResReportDto.setModule(rs.getString("module"));
			configUploadTransList.add(ConfigResReportDto);
		}
	   executionSummaryResDto.setConfigUploadTransList(configUploadTransList);
	   for(int k =0;k< 5;k++)
		   sheet.autoSizeColumn(k); 
	   workBook.write(bos);
	   bytes = bos.toByteArray();
	   executionSummaryResDto.setBytes(bytes);
	   }catch(SQLException e){
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}catch(Exception e){
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}finally {
			
			  if (rs != null) {
		            try {
		            	rs.close();
		            	rs = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }			  
			if (preparedStmt != null) {
	            try {
	            	preparedStmt.close();
	            	preparedStmt = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }
	        if (con != null) {
	            try {
	            	con.close();
	            	con = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }
	        bytes = null;
	        if(workBook != null){
	        	try {
					workBook.close();
				} catch (IOException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
	        	workBook = null;
	        }
			  slf4jLogger.info("getConfigUploadTransactionData method ended");

		}
	return executionSummaryResDto;
	}

public ConfigReportResDTO getExecutionLogData(String ConfiguploadID, String imgDescr,XSSFWorkbook workBook,int rowCount){
	slf4jLogger.info("getExecutionLogData method started");
	ArrayList<ConfigExecutionLogDto> configExecutionLogList = new ArrayList<ConfigExecutionLogDto>();
	ConfigReportResDTO configReportResDTO = null;
	ConfigExecutionLogDto ConfigExecutionLogDto = null;
	Connection con = null;
	PreparedStatement preparedStmt =  null;
	ResultSet rs = null;
	String reteriveQuery =  "SELECT status, message from executionlog where ConfiguploadID = ? limit 20";
	XSSFSheet sheet = null;
	Row selectedRow = null;
	Cell cell = null;
	try{
		configReportResDTO = new ConfigReportResDTO();
		sheet  = workBook.getSheetAt(0);
		con  = DBConnection.createConnection();
		preparedStmt = con.prepareStatement(reteriveQuery);
		preparedStmt.setString(1, ConfiguploadID);
	    rs = preparedStmt.executeQuery();
	    while(rs.next()){
	    	int columnCount = 0;
	    	selectedRow = sheet.createRow(rowCount++);
	    	ConfigExecutionLogDto = new ConfigExecutionLogDto();
	    	ConfigExecutionLogDto.setImgDesc(imgDescr);
	    	cell = selectedRow.createCell(columnCount++);
	    	cell.setCellType(Cell.CELL_TYPE_STRING);
	  	    cell.setCellValue(imgDescr);
			ConfigExecutionLogDto.setIcon(rs.getString("status"));
			cell = selectedRow.createCell(columnCount++);
	    	cell.setCellType(Cell.CELL_TYPE_STRING);
	  	    cell.setCellValue(rs.getString("status"));
			ConfigExecutionLogDto.setMessage(rs.getString("message"));
			cell = selectedRow.createCell(columnCount++);
	    	cell.setCellType(Cell.CELL_TYPE_STRING);
	  	    cell.setCellValue(rs.getString("message"));
			
			configExecutionLogList.add(ConfigExecutionLogDto);
		}
      	configReportResDTO.setConfigExecutionLogList(configExecutionLogList);
      	configReportResDTO.setWorkBook(workBook);
      	configReportResDTO.setRowNum(rowCount--);
	   }catch(SQLException e){
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}catch(Exception e){
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}finally {
			
			  if (rs != null) {
		            try {
		            	rs.close();
		            	rs = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }			  
			if (preparedStmt != null) {
	            try {
	            	preparedStmt.close();
	            	preparedStmt = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }
	        if (con != null) {
	            try {
	            	con.close();
	            	con = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }
	        
			  slf4jLogger.info("getExecutionLogData method ended");

		}
	return configReportResDTO;
	
	}
public ArrayList<ConfigDownloadResponseDTO> getConfigDownloadTransaction(ConfigTransactionReportDto ConfigTransactionReportDto){
	slf4jLogger.info("getConfigDownloadTransaction method started");
	ArrayList<ConfigDownloadResponseDTO>  configDownloadResponseDTOList = new ArrayList<ConfigDownloadResponseDTO>();
	Connection con = null;
	PreparedStatement preparedStmt =  null;
	ResultSet rs = null;
	String reteriveQuery = "SELECT Distinct B.transid,B.createddate, B.SCENARIO,  c.destinationname ,"+
			"(select count(1) from configdownloadhistory where transid = B.transid) Count FROM sapsystem c, CONFIGTRANSACTION B,configdownloadhistory a WHERE "+ 
			"B.OMID =? AND B.USERID =? and b.sourcesystemid = c.id AND a.transid = b.transid ORDER BY B.createddate DESC"; 
	
	try{
		con  = DBConnection.createConnection();
		preparedStmt = con.prepareStatement(reteriveQuery);
		preparedStmt.setString(1, ConfigTransactionReportDto.getOmID());
		preparedStmt.setString(2, ConfigTransactionReportDto.getUserID());
	    rs = preparedStmt.executeQuery();
	   
		while(rs.next()){
			ConfigDownloadResponseDTO configDownloadResponseDTOObj = new ConfigDownloadResponseDTO();
			configDownloadResponseDTOObj.setTransid(rs.getInt("transid"));
			configDownloadResponseDTOObj.setScenario(rs.getString("Scenario"));
			configDownloadResponseDTOObj.setCreatedDate(rs.getTimestamp("CreatedDate"));
			configDownloadResponseDTOObj.setSourceDestinationname(rs.getString("destinationname"));
			configDownloadResponseDTOObj.setCount(rs.getInt("Count"));
			configDownloadResponseDTOList.add(configDownloadResponseDTOObj);
		}
	    
		}catch(SQLException e){
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}catch(Exception e){
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}finally {
			
			  if (rs != null) {
		            try {
		            	rs.close();
		            	rs = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }			  
			if (preparedStmt != null) {
	            try {
	            	preparedStmt.close();
	            	preparedStmt = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }
	        if (con != null) {
	            try {
	            	con.close();
	            	con = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }
			  slf4jLogger.info("getConfigDownloadTransaction method ended");

		}
	return configDownloadResponseDTOList;
}
public ArrayList<ConfigDownloadResLogDTO> getConfigDownloadTransactionLogs(ConfigDownloadRequestDTO ConfigDownloadRequestDTO){
	slf4jLogger.info("getConfigDownloadTransactionLogs method started");
	ArrayList<ConfigDownloadResLogDTO>  configDwonloadLogList = new ArrayList<ConfigDownloadResLogDTO>();
    Connection con = null;
    PreparedStatement preparedStmt =  null;
    ResultSet rs = null;
    String reteriveQuery = "SELECT b.imgid, b.status, b.message, a.module,a.imgdescr from imghierarchy a, configdownloadhistory b where b.transid =? AND a.imgid = b.imgid";

    try{
                    con  = DBConnection.createConnection();
                    preparedStmt = con.prepareStatement(reteriveQuery);
                    preparedStmt.setInt(1, ConfigDownloadRequestDTO.getTransID());
                    rs = preparedStmt.executeQuery();
        
                    while(rs.next()){
                    	ConfigDownloadResLogDTO configDownloadResReportDto = new ConfigDownloadResLogDTO();
                    	configDownloadResReportDto.setImgDesc(rs.getString("imgdescr"));
                    	configDownloadResReportDto.setMessage(rs.getString("message"));
                    	configDownloadResReportDto.setModule(rs.getString("module"));
                    	configDownloadResReportDto.setStatus(rs.getString("status"));
                    	configDwonloadLogList.add(configDownloadResReportDto);
                    }
        
                    }catch(SQLException e){
                                    slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
                    }catch(Exception e){
                                    slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
                    }finally {
				                                    
				         if (rs != null) {
				            try {
				               rs.close();
				               rs = null;
				             } catch (SQLException e) {
				           slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				           }
				           }                                       
				            if (preparedStmt != null) {
				            try {
				                   preparedStmt.close();
				                   preparedStmt = null;
				                } catch (SQLException e) {
				                   slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				                }
				            }
				            if (con != null) {
				                try {
				                   con.close();
				                   con = null;
				                } catch (SQLException e) {
				                   slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				                }
				            }
				  		  slf4jLogger.info("getConfigDownloadTransactionLogs method ended");

                    }
    return configDwonloadLogList;
	
}

public ArrayList<ConfigTRResReportDto> getConfigTRReportData(ConfigTRReportDto ConfigTRReportDto){
	slf4jLogger.info("getConfigTRReportData method started");
    ArrayList<ConfigTRResReportDto>  configTRExecutionLogList = new ArrayList<ConfigTRResReportDto>();
    Connection con = null;
    PreparedStatement preparedStmt =  null;
    ResultSet rs = null;
    String reteriveQuery =  "Select c.IMGDescr,b.CTR,b.KTR,a.SAPUserID from ConfigTransaction a,ConfiguploadHistory b,IMGHierarchy c,SAPSystem d,"
                   +"Customer e where a.TransID=b.TransID and b.IMGID=c.IMGID and a.targetsystemID=d.ID and (b.CTR.LENGTH() > 0 OR b.KTR.LENGTH() > 0) and d.OMID=a.OMID and a.OMID=e.OMID and e.ProjectName=? and d.DestinationName=?";
                                   
    try{
                    con  = DBConnection.createConnection();
                    preparedStmt = con.prepareStatement(reteriveQuery);
                    preparedStmt.setString(1,ConfigTRReportDto.getProjectName());
                    preparedStmt.setString(2,ConfigTRReportDto.getDestinationName() );
                    rs = preparedStmt.executeQuery();
        
                    while(rs.next()){
                                    ConfigTRResReportDto configTRResReportDto = new ConfigTRResReportDto();
                                    
                                    configTRResReportDto.setImgDescr(rs.getString("IMGDESCR"));
                                    configTRResReportDto.setCtr(rs.getString("CTR") != null ? rs.getString("CTR") : "");
                                    configTRResReportDto.setKtr(rs.getString("KTR") != null ? rs.getString("CTR") : "");
                                    configTRResReportDto.setSapUserId(rs.getString("SapUserID"));
                                    configTRExecutionLogList.add(configTRResReportDto);
                    }
        
                    }catch(SQLException e){
                                    slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
                    }catch(Exception e){
                                    slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
                    }finally {
                                    
                                      if (rs != null) {
                                try {
                                   rs.close();
                                   rs = null;
                                } catch (SQLException e) {
                                   slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
                                }
                            }                                       
                                    if (preparedStmt != null) {
                try {
                   preparedStmt.close();
                   preparedStmt = null;
                } catch (SQLException e) {
                   slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
                }
            }
            if (con != null) {
                try {
                   con.close();
                   con = null;
                } catch (SQLException e) {
                   slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
                }
            }
  		  slf4jLogger.info("getConfigTRReportData method ended");

           }
    return configTRExecutionLogList;
}
}
