package com.acn.rpa.reports;

import java.sql.Timestamp;
import java.util.ArrayList;

import javax.validation.Valid;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.acn.user.session.SessionInputDTO;

public class ConfigResponseReportDto {

@Size(min = 1, max = 40)
@Pattern(regexp = "^\\s*[\\da-zA-Z\\s][\\da-zA-Z\\s]*$")
private String implType;
@Size(min = 0, max = 124)
private String sapUserID;
@Size(min = 1, max = 8)
@Pattern(regexp = "[a-zA-Z0-9]+") 
private String userID;

//@Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}\\.\\d{3}(?: [+-]\\d{4})?$")
private Timestamp timeStamp;
@Size(min = 1, max = 20)
@Pattern(regexp = "[a-zA-Z0-9]+")
private String targetDestinationname;
@Size(min = 1, max = 20)
@Pattern(regexp = "[a-zA-Z0-9]+")
private String sourceDestinationname;
@DecimalMin(value = "1")
@DecimalMax(value = "9999999")
private int count;
@DecimalMin(value = "1")
@DecimalMax(value = "9999999")
private int transID;
@Valid
private SessionInputDTO sessionInputDTO;

public SessionInputDTO getSessionInputDTO() {
	return sessionInputDTO;
}
public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
	this.sessionInputDTO = sessionInputDTO;
}
public String getImplType() {
	return implType;
}
public void setImplType(String implType) {
	this.implType = implType;
}
public String getSapUserID() {
	return sapUserID;
}
public void setSapUserID(String sapUserID) {
	this.sapUserID = sapUserID;
}
public String getTargetDestinationname() {
	return targetDestinationname;
}
public void setTargetDestinationname(String targetDestinationname) {
	this.targetDestinationname = targetDestinationname;
}

public String getSourceDestinationname() {
	return sourceDestinationname;
}
public void setSourceDestinationname(String sourceDestinationname) {
	this.sourceDestinationname = sourceDestinationname;
}

@Valid
private ArrayList<ConfigResponseReportDto> configResponseList;
private String message;

public int getTransID() {
	return transID;
}
public void setTransID(int transID) {
	this.transID = transID;
}
public String getMessage() {
	return message;
}
public void setMessage(String message) {
	this.message = message;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
private String status;

private boolean industryFlag;

private String industry;

private String subIndustry;

public boolean isIndustryFlag() {
	return industryFlag;
}
public void setIndustryFlag(boolean industryFlag) {
	this.industryFlag = industryFlag;
	
}
public String getIndustry() {
	return industry;
}
public void setIndustry(String industry) {
	this.industry = industry;
}
public String getSubIndustry() {
	return subIndustry;
}
public void setSubIndustry(String subIndustry) {
	this.subIndustry = subIndustry;
}
public ArrayList<ConfigResponseReportDto> getConfigResponseList() {
	return configResponseList;
}
public void setConfigResponseList(ArrayList<ConfigResponseReportDto> configResponseList) {
	this.configResponseList = configResponseList;
}

public Timestamp getTimeStamp() {
	return timeStamp;
}
public void setTimeStamp(Timestamp timeStamp) {
	this.timeStamp = timeStamp;
}
public int getCount() {
	return count;
}
public void setCount(int count) {
	this.count = count;
}
public String getUserID() {
	return userID;
}
public void setUserID(String userID) {
	this.userID = userID;
}



}