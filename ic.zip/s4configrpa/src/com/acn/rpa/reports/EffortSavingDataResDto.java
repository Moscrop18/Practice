package com.acn.rpa.reports;

import java.util.ArrayList;

import com.acn.user.session.ResMessageDto;

public class EffortSavingDataResDto {
	private ArrayList<EffortSaveResDto> configExecutionLogList;
	private ArrayList<EffortSaveGraphResDto> effortSaveDataAllProj;

	private ResMessageDto resMessageDto;
	private String build_Time;
	public String getBuild_Time() {
		return build_Time;
	}

	public void setBuild_Time(String build_Time) {
		this.build_Time = build_Time;
	}

	public ResMessageDto getResMessageDto() {
		return resMessageDto;
	}

	public void setResMessageDto(ResMessageDto resMessageDto) {
		this.resMessageDto = resMessageDto;
	}

	public ArrayList<EffortSaveResDto> getConfigExecutionLogList() {
		return configExecutionLogList;
	}

	public void setConfigExecutionLogList(ArrayList<EffortSaveResDto> configExecutionLogList) {
		this.configExecutionLogList = configExecutionLogList;
	}
	public ArrayList<EffortSaveGraphResDto> getEffortSaveDataAllProj() {
		return effortSaveDataAllProj;
	}

	public void setEffortSaveDataAllProj(ArrayList<EffortSaveGraphResDto> effortSaveDataAllProj) {
		this.effortSaveDataAllProj = effortSaveDataAllProj;
	}

}
