package com.acn.rpa.reports;

import javax.validation.Valid;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;

import com.acn.user.session.SessionInputDTO;

public class ConfigDownloadRequestDTO {

@DecimalMin(value = "1")
@DecimalMax(value = "9999999")	
private int transID;
@Valid
private SessionInputDTO sessionInputDTO;

public SessionInputDTO getSessionInputDTO() {
	return sessionInputDTO;
}
public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
	this.sessionInputDTO = sessionInputDTO;
}
public int getTransID() {
	return transID;
}

public void setTransID(int transID) {
	this.transID = transID;
}
}