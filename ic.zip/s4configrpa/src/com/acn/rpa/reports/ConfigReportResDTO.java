package com.acn.rpa.reports;

import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.acn.user.session.ResMessageDto;

public class ConfigReportResDTO {
	private XSSFWorkbook workBook;
	private ArrayList<ConfigExecutionLogDto> configExecutionLogList;
	private ArrayList<ConfigDownloadResponseDTO> listConfigDownloadResponseDTO;
	private ResMessageDto resMessageDto;

	public ResMessageDto getResMessageDto() {
			return resMessageDto;
		}
	public void setResMessageDto(ResMessageDto resMessageDto) {
			this.resMessageDto = resMessageDto;
		}
	public ArrayList<ConfigDownloadResponseDTO> getListConfigDownloadResponseDTO() {
		return listConfigDownloadResponseDTO;
	}
	public void setListConfigDownloadResponseDTO(ArrayList<ConfigDownloadResponseDTO> listConfigDownloadResponseDTO) {
		this.listConfigDownloadResponseDTO = listConfigDownloadResponseDTO;
	}
	private int rowNum;
	public int getRowNum() {
		return rowNum;
	}
	public void setRowNum(int rowNum) {
		this.rowNum = rowNum;
	}
	public XSSFWorkbook getWorkBook() {
		return workBook;
	}
	public void setWorkBook(XSSFWorkbook workBook) {
		this.workBook = workBook;
	}
	public ArrayList<ConfigExecutionLogDto> getConfigExecutionLogList() {
		return configExecutionLogList;
	}
	public void setConfigExecutionLogList(ArrayList<ConfigExecutionLogDto> configExecutionLogList) {
		this.configExecutionLogList = configExecutionLogList;
	}
}
