package com.acn.rpa.reports;

public class ConfigExecutionLogDto {
	
private String Icon;
private String Description;
private String message;
private String imgDesc;
public String getImgDesc() {
	return imgDesc;
}
public void setImgDesc(String imgDesc) {
	this.imgDesc = imgDesc;
}
public String getIcon() {
	return Icon;
}
public void setIcon(String icon) {
	Icon = icon;
}
public String getDescription() {
	return Description;
}
public void setDescription(String description) {
	Description = description;
}
public String getMessage() {
	return message;
}
public void setMessage(String message) {
	this.message = message;
}

}