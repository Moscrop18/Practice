package com.acn.rpa.reports;

import java.util.ArrayList;
import java.util.Map;

public class ConfigResReportDto {
	
private String IMGDesc;
private String Status;
private String CTR;
private String KTR;
private String Module;
private String message;

ArrayList<ConfigExecutionLogDto> executionsLogSummary;

public ArrayList<ConfigExecutionLogDto> getExecutionsLogSummary() {
	return executionsLogSummary;
}
public void setExecutionsLogSummary(ArrayList<ConfigExecutionLogDto> executionsLogSummary) {
	this.executionsLogSummary = executionsLogSummary;
}
public String getMessage() {
	return message;
}
public void setMessage(String message) {
	this.message = message;
}
public String getErr_status() {
	return err_status;
}
public void setErr_status(String err_status) {
	this.err_status = err_status;
}
private String err_status;

public String getIMGDesc() {
	return IMGDesc;
}
public void setIMGDesc(String iMGDesc) {
	IMGDesc = iMGDesc;
}
public String getStatus() {
	return Status;
}
public void setStatus(String status) {
	Status = status;
}
public String getCTR() {
	return CTR;
}
public void setCTR(String cTR) {
	CTR = cTR;
}
public String getKTR() {
	return KTR;
}
public void setKTR(String kTR) {
	KTR = kTR;
}
public String getModule() {
	return Module;
}
public void setModule(String module) {
	Module = module;
}


}