package com.acn.rpa.reports;


public class ConfigTRResReportDto {

                private String imgDescr;
                private String ctr;
                private String ktr;
                private String sapUserId;
                public String getImgDescr() {
                                return imgDescr;
                }
                public void setImgDescr(String imgDescr) {
                                this.imgDescr = imgDescr;
                }
                public String getCtr() {
                                return ctr;
                }
                public void setCtr(String ctr) {
                                this.ctr = ctr;
                }
                public String getKtr() {
                                return ktr;
                }
                public void setKtr(String ktr) {
                                this.ktr = ktr;
                }
                public String getSapUserId() {
                                return sapUserId;
                }
                public void setSapUserId(String sapUserId) {
                                this.sapUserId = sapUserId;
                }

                
                }
