package com.acn.rpa.reports;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.acn.user.session.SessionInputDTO;

public class ConfigTRReportDto {
				@Size(min = 1, max = 50)
				@Pattern(regexp = "[a-zA-Z0-9\\s._&-,]+")
                private String projectName;
				@Size(min = 1, max = 20)
				@Pattern(regexp = "[a-zA-Z0-9]+")
                private String destinationName;
            	@Valid
                private SessionInputDTO sessionInputDTO;
                	
                	public SessionInputDTO getSessionInputDTO() {
                		return sessionInputDTO;
                	}
                	public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
                		this.sessionInputDTO = sessionInputDTO;
                	}
                public String getProjectName() {
                                return projectName;
                }
                public void setProjectName(String projectName) {
                                this.projectName = projectName;
                }
                public String getDestinationName() {
                                return destinationName;
                }
                public void setDestinationName(String destinationName) {
                                this.destinationName = destinationName;
                }
                
}
