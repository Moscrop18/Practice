package com.acn.rpa.reports;


import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.acn.user.session.ResMessageDto;

public class EffortSaveResDto {
	@Size(min = 1, max = 40)
	@Pattern(regexp = "^\\s*[\\da-zA-Z\\s][\\da-zA-Z\\s]*$")
	private String implType;
	private String totalTime;

	public String getImplType() {
		return implType;
	}

	public void setImplType(String implType) {
		this.implType = implType;
	}

	public String getTotalTime() {
		return totalTime;
	}

	public void setTotalTime(String totalTime) {
		this.totalTime = totalTime;
	}

	
}