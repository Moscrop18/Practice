package com.acn.rpa.reports;


import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.acn.user.session.ResMessageDto;

public class EffortSaveGraphResDto {
	@Size(min = 1, max = 40)
	@Pattern(regexp = "^\\s*[\\da-zA-Z\\s][\\da-zA-Z\\s]*$")
	private String build_Time;
	public String getBuild_Time() {
		return build_Time;
	}
	public void setBuild_Time(String build_Time) {
		this.build_Time = build_Time;
	}
	public String getTotalTime() {
		return totalTime;
	}
	public void setTotalTime(String totalTime) {
		this.totalTime = totalTime;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	private String totalTime;
	private String projectName;

	
	
}