package com.acn.rpa.reports;

import java.sql.Timestamp;

public class ConfigDownloadResponseDTO {
	
	private String scenario;
	private String sapUserID;
	private Timestamp createdDate;
	private String sourceDestinationname;
	private String projectName;
	private String imgId;
	private String imgDesc;
	private int count;
	public int getTransid() {
		return transid;
	}
	public void setTransid(int transid) {
		this.transid = transid;
	}
	private int transid;
	
	private String message;
	private String status;
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public String getScenario() {
		return scenario;
	}
	public void setScenario(String scenario) {
		this.scenario = scenario;
	}
	public String getSapUserID() {
		return sapUserID;
	}
	public void setSapUserID(String sapUserID) {
		this.sapUserID = sapUserID;
	}
	public Timestamp getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getSourceDestinationname() {
		return sourceDestinationname;
	}
	public void setSourceDestinationname(String sourceDestinationname) {
		this.sourceDestinationname = sourceDestinationname;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getImgId() {
		return imgId;
	}
	public void setImgId(String imgId) {
		this.imgId = imgId;
	}
	public String getImgDesc() {
		return imgDesc;
	}
	public void setImgDesc(String imgDesc) {
		this.imgDesc = imgDesc;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}


}