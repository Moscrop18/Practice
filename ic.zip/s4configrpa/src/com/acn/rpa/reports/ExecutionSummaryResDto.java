package com.acn.rpa.reports;

import java.util.ArrayList;

import com.acn.user.session.ResMessageDto;

public class ExecutionSummaryResDto {
	
	private ArrayList<ConfigExecutionLogDto> allExecutionsLogSummary;
	private byte[] bytes;
	public byte[] getBytes() {
		return bytes;
	}
	private ResMessageDto resMessageDto;

	public ResMessageDto getResMessageDto() {
			return resMessageDto;
		}
	public void setResMessageDto(ResMessageDto resMessageDto) {
			this.resMessageDto = resMessageDto;
		}
	public void setBytes(byte[] bytes) {
		this.bytes = bytes;
	}
	public ArrayList<ConfigResReportDto> getConfigUploadTransList() {
		return configUploadTransList;
	}
	public void setConfigUploadTransList(ArrayList<ConfigResReportDto> configUploadTransList) {
		this.configUploadTransList = configUploadTransList;
	}
	private ArrayList<ConfigResReportDto>  configUploadTransList;
	
	
	public ArrayList<ConfigExecutionLogDto> getExecutionsAllLogSummary() {
		return allExecutionsLogSummary;
	}
	public void setExecutionsAllLogSummary(ArrayList<ConfigExecutionLogDto> executionsAllLogSummary) {
		this.allExecutionsLogSummary = executionsAllLogSummary;
	}
	
}