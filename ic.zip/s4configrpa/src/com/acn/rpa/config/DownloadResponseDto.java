package com.acn.rpa.config;

import java.util.ArrayList;

public class DownloadResponseDto { 
	
	private ArrayList<String> downloadRes;
	private boolean srcConnectionStatus;
	private boolean srcExecutionStatus;
	private String errorDetails; 
	
	public ArrayList<String> getDownloadRes() {
		return downloadRes;
	}
	public void setDownloadRes(ArrayList<String> downloadRes) {
		this.downloadRes = downloadRes;
	}
	public boolean isSrcConnectionStatus() {
		return srcConnectionStatus;
	}
	public void setSrcConnectionStatus(boolean srcConnectionStatus) {
		this.srcConnectionStatus = srcConnectionStatus;
	}
	public boolean isSrcExecutionStatus() {
		return srcExecutionStatus;
	}
	public void setSrcExecutionStatus(boolean srcExecutionStatus) {
		this.srcExecutionStatus = srcExecutionStatus;
	}
	public String getErrorDetails() {
		return errorDetails;
	}
	public void setErrorDetails(String errorDetails) {
		this.errorDetails = errorDetails;
	}

}
