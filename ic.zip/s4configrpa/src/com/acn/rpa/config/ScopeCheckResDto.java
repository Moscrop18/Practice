package com.acn.rpa.config;

import java.util.ArrayList;

public class ScopeCheckResDto {

	private ArrayList<String> imgScope;
	private String scopeAvailable ;
	private IMGScopeDto imgScopeDto;
	
	
	public ArrayList<String> getImgScope() {
		return imgScope;
	}
	public void setImgScope(ArrayList<String> imgScope) {
		this.imgScope = imgScope;
	}
	public String getScopeAvailable() {
		return scopeAvailable;
	}
	public void setScopeAvailable(String scopeAvailable) {
		this.scopeAvailable = scopeAvailable;
	}
	public IMGScopeDto getImgScopeDto() {
		return imgScopeDto;
	}
	public void setImgScopeDto(IMGScopeDto imgScopeDto) {
		this.imgScopeDto = imgScopeDto;
	}

	
}
