package com.acn.rpa.config;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class ProjectDto {
	@Size(min = 1, max = 50)
	@Pattern(regexp = "[a-zA-Z0-9\\s._&-,]+")
	private String projectName;
	@Size(min = 1, max = 20)
	private String omId;
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getOmId() {
		return omId;
	}
	public void setOmId(String omId) {
		this.omId = omId;
	}
	
}
