/**
 * @author insimmamul.haq.p.b
 */
package com.acn.rpa.config;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.admin.ResponseDto;
import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.DBConnection;
import com.acn.user.session.RetrieverDto;
import com.acn.user.session.SvaeScopeResDto;

public class SaveScopeDAO {
    private final Logger slf4jLogger = LoggerFactory.getLogger(SaveScopeDAO.class);

	public SvaeScopeResDto scopeSaver(UserConfigScopeDto userConfigScopeDto){
		slf4jLogger.info("scopeSaver method started");
		Connection con = null;
		ResultSet rs=null;
		ResultSet rs1=null;
		PreparedStatement ps=null;
		PreparedStatement ps1=null;
		PreparedStatement ps2=null;
		PreparedStatement ps3=null;
		int scopeLen = 0;
		int userConfigScopeId;
		/*ResponseDto responseDtoObj = new ResponseDto();*/
		SvaeScopeResDto responseDtoObj=new SvaeScopeResDto();
		responseDtoObj.setClientId(userConfigScopeDto.getOmId());
		responseDtoObj.setUserId(userConfigScopeDto.getUserId());
		try{
			con =  DBConnection.createConnection();
			ps =  con.prepareStatement("SELECT UserID FROM User WHERE UserID = ?");
			ps.setString(1, userConfigScopeDto.getUserId());
			rs = ps.executeQuery();
			if(!rs.next()){
				responseDtoObj.setMessage("The userId " + userConfigScopeDto.getUserId() + " does not exist!");
				slf4jLogger.error("The userId " + userConfigScopeDto.getUserId() + " does not exist!");
				responseDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
				return responseDtoObj;
			}
		} catch (SQLException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}finally{
				if(rs!=null){
					try {
						rs.close();
						rs=null;
						} catch (SQLException e) {
						slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
					}
				}
				if(ps!=null){
					try {
						ps.close();
						ps=null;
						} catch (SQLException e) {
						slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
					}
				}
				if(con!=null){
					try {
						con.close();
						con=null;
						} catch (SQLException e) {
						slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
					}
				}
		   }
			try{
			con =  DBConnection.createConnection();
			ps =  con.prepareStatement("SELECT OMID FROM CUSTOMER WHERE OMID = ?");
			ps.setString(1, userConfigScopeDto.getOmId());

			rs = ps.executeQuery();
			if(!rs.next()){
				responseDtoObj.setMessage("The OMID " + userConfigScopeDto.getOmId() + " does not exist!");
				slf4jLogger.error("The OMID " + userConfigScopeDto.getOmId() + " does not exist!");
				responseDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
				return responseDtoObj;
			}
			} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}finally{
				if(rs!=null){
					try {
						rs.close();
						rs=null;
						} catch (SQLException e) {
						slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
					}
				}
				if(ps!=null){
					try {
						ps.close();
						ps=null;
						} catch (SQLException e) {
						slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
					}
				}
				if(con!=null){
					try {
						con.close();
						con=null;
						} catch (SQLException e) {
						slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
					}
				}
			}
			try{
			con =  DBConnection.createConnection();
			ps =  con.prepareStatement("SELECT UserConfigScopeID FROM UsersScopeHistory WHERE UserID = ? AND OMID = ? AND IMPLEMENTATIONTYPE = ?");
			ps.setString(1, userConfigScopeDto.getUserId());
			ps.setString(2, userConfigScopeDto.getOmId());
			ps.setInt(3, userConfigScopeDto.getImplementationType());
			rs = ps.executeQuery();
			if(rs.next()){
				userConfigScopeId = rs.getInt("UserConfigScopeID");
				ps1 = con.prepareStatement("UPDATE UsersScopeHistory SET OMID=?,IMPLEMENTATIONTYPE = ? WHERE OMID =? AND IMPLEMENTATIONTYPE = ?");
				ps1.setString(1,userConfigScopeDto.getOmId());
				ps1.setInt(2,userConfigScopeDto.getImplementationType());
				ps1.setString(3,userConfigScopeDto.getOmId());
				ps1.setInt(4,userConfigScopeDto.getImplementationType());
				ps1.execute();
				ps2 = con.prepareStatement("DELETE FROM UsersScopeHistoryList WHERE UserConfigScopeID = ? AND COPY_FLAG =? AND INDUSTRY=?");
				ps2.setInt(1, userConfigScopeId);
				
				if (userConfigScopeDto.getCopyFlag()) {
					ps2.setBoolean(2, true);
					ps2.setInt(3, 0);
				}
				else if(userConfigScopeDto.isIndustryFlag()) {
					ps2.setBoolean(2, false);
					ps2.setInt(3, 1);
				}
				else {
					ps2.setBoolean(2, false);
					ps2.setInt(3, 0);
				}
					
				ps2.execute();
				ps3 =  con.prepareStatement("INSERT INTO UsersScopeHistoryList (UserConfigScopeID, IMG_ID, COPY_FLAG,INDUSTRY) VALUES (?,?,?,?)");
				
				scopeLen = userConfigScopeDto.getImgIdList().size();
				for(int i = 0; i < scopeLen; i++){
					ps3.setInt(1, userConfigScopeId);
					ps3.setString(2, userConfigScopeDto.getImgIdList().get(i));
					if (userConfigScopeDto.getCopyFlag()) {
						ps3.setBoolean(3, true);
						ps3.setInt(4, 0);
					}
						
					else if(userConfigScopeDto.isIndustryFlag()){
						ps3.setBoolean(3, false);
						ps3.setInt(4, 1);
					}
					else {
						ps3.setBoolean(3, false);
						ps3.setInt(4, 0);
					}

					ps3.addBatch();
				}
				if(scopeLen>0)
					ps3.executeBatch();
				responseDtoObj.setMessage("The scope for the userId " + userConfigScopeDto.getUserId() + " has been saved for the omId " + userConfigScopeDto.getOmId());
				responseDtoObj.setStatus(ConstantsValues.SUCCESSSTATUS);
				slf4jLogger.error("The scope for the userId " + userConfigScopeDto.getUserId() + " has been saved for the omId " + userConfigScopeDto.getOmId());
				return responseDtoObj;
			}
			} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}finally{
				if(rs!=null){
					try {
						rs.close();
						rs=null;
						} catch (SQLException e) {
						slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
					}
				}
				if(ps3!=null){
					try {
						ps3.close();
						ps3=null;
						} catch (SQLException e) {
						slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
					}
				}
				if(ps2!=null){
					try {
						ps2.close();
						ps2=null;
						} catch (SQLException e) {
						slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
					}
				}
				if(ps1!=null){
					try {
						ps1.close();
						ps1=null;
						} catch (SQLException e) {
						slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
					}
				}
				if(ps!=null){
					try {
						ps.close();
						ps=null;
						} catch (SQLException e) {
						slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
					}
				}
				if(con!=null){
					try {
						con.close();
						con=null;
						} catch (SQLException e) {
						slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
					}
				}
			}
			try{
				con =  DBConnection.createConnection();
				ps1 = con.prepareStatement("INSERT INTO UsersScopeHistory (OMID,USERID,IMPLEMENTATIONTYPE) VALUES (?,?,?)");
				ps1.setString(1, userConfigScopeDto.getOmId());
				ps1.setString(2, userConfigScopeDto.getUserId());
				ps1.setInt(3, userConfigScopeDto.getImplementationType());
				ps1.execute();
				ps2 = con.prepareStatement("SELECT UserConfigScopeID FROM UsersScopeHistory WHERE UserID = ?  AND OMID = ?  AND IMPLEMENTATIONTYPE = ? ");
				ps2.setString(1, userConfigScopeDto.getUserId());
				ps2.setString(2, userConfigScopeDto.getOmId());
				ps2.setInt(3, userConfigScopeDto.getImplementationType());
				rs1 = ps2.executeQuery();
				if(rs1.next()){
					userConfigScopeId = rs1.getInt("UserConfigScopeID");
					ps3 =  con.prepareStatement("INSERT INTO UsersScopeHistoryList (UserConfigScopeID, IMG_ID, COPY_FLAG) VALUES (?,?,?)");
					scopeLen = userConfigScopeDto.getImgIdList().size();
					for(int i = 0; i < scopeLen; i++){
						ps3.setInt(1, userConfigScopeId);
						ps3.setString(2, userConfigScopeDto.getImgIdList().get(i));
						if (userConfigScopeDto.getCopyFlag())
							ps3.setBoolean(3, true);
						else
							ps3.setBoolean(3, false);

						ps3.addBatch();
					}
					if(scopeLen>0)
						ps3.executeBatch();
				responseDtoObj.setMessage("The scope for the userId " + userConfigScopeDto.getUserId() + " has been saved.");
				slf4jLogger.error("The scope for the userId " + userConfigScopeDto.getUserId() + " has been saved.");
				responseDtoObj.setStatus("SUCCESS");
				}
			
			}
			
		
		catch (SQLException e){
			responseDtoObj.setMessage("Could not save the config state for the userId "+userConfigScopeDto.getUserId());
			responseDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}
		finally{
			
			if(rs1!=null){
				try {
					rs1.close();
					rs1=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			if(rs!=null){
				try {
					rs.close();
					rs=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}

		
			if(ps1!=null){
				try {
					ps1.close();
					ps1=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			if(ps2!=null){
				try {
					ps2.close();
					ps2=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			if(ps3!=null){
				try {
					ps3.close();
					ps3=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			  slf4jLogger.info("scopeSaver method ended");

		}
		return responseDtoObj;
	}
	 public static Comparator<IMGScopeDto> sortSequence = new Comparator<IMGScopeDto>() {

			public int compare(IMGScopeDto s1, IMGScopeDto s2) {

			   /*For ascending order*/
			   return  s1.getSeqNo().compareTo(s2.getSeqNo()); 

			   /*For descending order*/
			   //rollno2-rollno1;
		   }};
		   
		   public static Comparator<IMGScopeDto> sortindSeq = new Comparator<IMGScopeDto>() {

				public int compare(IMGScopeDto s1, IMGScopeDto s2) {

				   /*For ascending order*/
				   return  s1.getIndSeq().compareTo(s2.getIndSeq()); 

				  
			   }};
	
	public RetrieverDto scopeRetriever(UserConfigScopeDto userConfigScopeDtoObj){
		slf4jLogger.info("scopeRetriever method started");
		Connection con = null;
		ResultSet rs=null;
		ResultSet rs2=null;
		PreparedStatement ps1=null;
		PreparedStatement ps2=null;
		//ResponseDto responseDtoObj = new ResponseDto();
		RetrieverDto retrieverDto=new RetrieverDto();
		/*responseDtoObj.setUserId(userConfigScopeDtoObj.getUserId());
		responseDtoObj.setClientId(userConfigScopeDtoObj.getOmId());*/
		int userConfigScopeId;
		UserConfigScopeDto userConfigScopeDto = new UserConfigScopeDto();
		ScopeSessionDto scopeSessionDto =  new ScopeSessionDto();
		ArrayList<IMGScopeDto> imgScopeList =  new ArrayList<>();
		try{
			con = DBConnection.createConnection();
			ps1 = con.prepareStatement("SELECT UserConfigScopeID,USERID,OMID,USERID FROM UsersScopeHistory WHERE UserID = ? AND OMID = ? AND IMPLEMENTATIONTYPE = ? ");
			ps1.setString(1, userConfigScopeDtoObj.getUserId());
			ps1.setString(2, userConfigScopeDtoObj.getOmId());
			ps1.setInt(3, userConfigScopeDtoObj.getImplementationType());
			rs = ps1.executeQuery();
			if(rs.next()){
				userConfigScopeId = rs.getInt("UserConfigScopeID");
			}
			else{
				retrieverDto.setMessage(userConfigScopeDtoObj.getUserId() + "-" + userConfigScopeDtoObj.getOmId() + "The userID - omId combination you have entered does not have any entries in UsersScopeHistory table!");
				slf4jLogger.error(userConfigScopeDtoObj.getUserId() + "-" + userConfigScopeDtoObj.getOmId() + "The userID - omId combination you have entered does not have any entries in UsersScopeHistory table!");
				retrieverDto.setStatus(ConstantsValues.ERRORSTATUS);
				return retrieverDto;
				
			}
			userConfigScopeDto.setUserId(rs.getString("USERID"));
			userConfigScopeDto.setCopyFlag(userConfigScopeDtoObj.getCopyFlag());
			userConfigScopeDto.setOmId(rs.getString("OMID"));		
			scopeSessionDto.setUserId(rs.getString("USERID"));
			scopeSessionDto.setOmId(rs.getString("OMID"));
			scopeSessionDto.setImplementationType(userConfigScopeDtoObj.getImplementationType());
			if(userConfigScopeDtoObj.getCopyFlag()) {
				ps2 =  con.prepareStatement("SELECT DISTINCT A.IMG_ID, C.IMGDESCR,C.SEQUENCING,C.ENABLED,C.ISMASTERDATA,C.TRTYPE FROM UsersScopeHistoryList A,CLIENT_IMGHIERARCHY B,COPYFUNCTIONALITY_IMGHIERARCHY C WHERE A.COPY_FLAG=? AND A.IMG_ID = B.IMGID AND A.IMG_ID = C.IMGID AND B.IMGID = C.IMGID AND B.OMID =? AND UserConfigScopeID = ? AND A.INDUSTRY=?");
			}
			else if(userConfigScopeDtoObj.isIndustryFlag()) {
				ps2 =  con.prepareStatement("SELECT DISTINCT A.IMG_ID, C.IMGDESCR,C.SEQUENCING,C.ENABLED,C.ISMASTERDATA,C.TRTYPE, C.IND_SEQ FROM UsersScopeHistoryList A,CLIENT_IMGHIERARCHY B,INDUSTRY_IMGHIERARCHY C WHERE A.COPY_FLAG=? AND A.IMG_ID = B.IMGID AND A.IMG_ID = C.IMGID AND B.IMGID = C.IMGID AND B.OMID =? AND UserConfigScopeID = ? AND C.INDUSTRY LIKE ? AND C.SUBINDUSTRY LIKE ? AND B.INDUSTRY=? AND A.INDUSTRY=?");
			}
			else {
				ps2 =  con.prepareStatement("SELECT DISTINCT A.IMG_ID, C.IMGDESCR,C.SEQUENCING,C.ENABLED,C.ISMASTERDATA,C.TRTYPE FROM UsersScopeHistoryList A,CLIENT_IMGHIERARCHY B,IMGHIERARCHY C WHERE A.COPY_FLAG=? AND A.IMG_ID = B.IMGID AND A.IMG_ID = C.IMGID AND B.IMGID = C.IMGID AND B.OMID =? AND UserConfigScopeID = ? AND B.INDUSTRY=? AND A.INDUSTRY=?");
				}
			if (userConfigScopeDto.getCopyFlag()) {
				ps2.setBoolean(1, true);
				ps2.setInt(4, 0);
			}else if(userConfigScopeDtoObj.isIndustryFlag()) {
				ps2.setBoolean(1, false);
				ps2.setString(4, "%" + userConfigScopeDtoObj.getIndustry() + "%");
				ps2.setString(5, "%" + userConfigScopeDtoObj.getSubIndustry() + "%");
				ps2.setInt(6, 1);
				ps2.setInt(7, 1);
			}
			else {
				ps2.setBoolean(1, false);
				ps2.setInt(4, 0);
				ps2.setInt(5, 0);
			}
			ps2.setString(2, userConfigScopeDtoObj.getOmId());
			ps2.setInt(3, userConfigScopeId);
			
			rs2 = ps2.executeQuery();
			while(rs2.next()){
				IMGScopeDto imgScopeDto = new IMGScopeDto();
				imgScopeDto.setImgDescription(rs2.getString("IMGDESCR"));
				imgScopeDto.setImgId(rs2.getString("IMG_ID"));
				imgScopeDto.setSeqNo(rs2.getString("SEQUENCING"));
				imgScopeDto.setEnabled(rs2.getInt("ENABLED"));
				imgScopeDto.setIsMasterData(rs2.getString("ISMASTERDATA"));
				imgScopeDto.setTrType(rs2.getString("TRTYPE")); 
				if(userConfigScopeDtoObj.isIndustryFlag() && !userConfigScopeDto.getCopyFlag()) {
					imgScopeDto.setIndSeq(rs2.getString("IND_SEQ"));
				}
				imgScopeList.add(imgScopeDto);
				if(userConfigScopeDto.getCopyFlag()) {
					Collections.sort(imgScopeList,SaveScopeDAO.sortSequence);
				}
				else if(userConfigScopeDtoObj.isIndustryFlag()) {
					Collections.sort(imgScopeList,SaveScopeDAO.sortindSeq);
				}else {
					Collections.sort(imgScopeList,SaveScopeDAO.sortSequence);
				}
				
				
			}
			
			//Collections.sort(imgScopeList,);
			scopeSessionDto.setImgScopeDto(imgScopeList);
			retrieverDto.setScopeSessionDto(scopeSessionDto);
			retrieverDto.setStatus(ConstantsValues.SUCCESSSTATUS);
		}
		catch (SQLException e){
			retrieverDto.setStatus(ConstantsValues.ERRORSTATUS);
			retrieverDto.setMessage("Not able to fetch UsersScopeHistory/UsersScopeHistoryList Details ,please contact the Administrator!");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}
		finally{
			
			if(rs!=null){
				try {
					rs.close();
					rs=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			if(rs2!=null){
				try {
					rs2.close();
					rs2=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			if(ps1!=null){
				try {
					ps1.close();
					ps1=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			if(ps2!=null){
				try {
					ps2.close();
					ps2=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("scopeRetriever method ended");

		}
		return retrieverDto;
	}
}
