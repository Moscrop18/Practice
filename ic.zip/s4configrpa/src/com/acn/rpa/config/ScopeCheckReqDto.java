package com.acn.rpa.config;

import java.util.ArrayList;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.acn.user.session.SessionInputDTO;

public class ScopeCheckReqDto {
	@Valid
	private ArrayList<IMGScopeDto> imgScopeDto;

	@Size(min = 1, max = 8)
	@Pattern(regexp = "^\\s*[\\da-zA-Z][\\da-zA-Z\\s]*$")
	private String systemType;
	@Valid
	private SessionInputDTO sessionInputDTO;
	
	private boolean industryFlag;
	
	private String industry;
	
	private String subIndustry;
	
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public String getSubIndustry() {
		return subIndustry;
	}
	public void setSubIndustry(String subIndustry) {
		this.subIndustry = subIndustry;
	}
	public boolean isIndustryFlag() {
		return industryFlag;
	}
	public void setIndustryFlag(boolean industryFlag) {
		this.industryFlag = industryFlag;
	}
	private Boolean copyFlag=false;
	
	public Boolean getCopyFlag() {
		return copyFlag;
	}
	public void setCopyFlag(Boolean copyFlag) {
		this.copyFlag = copyFlag;
	}
	public SessionInputDTO getSessionInputDTO() {
		return sessionInputDTO;
	}
	public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
		this.sessionInputDTO = sessionInputDTO;
	}
	public ArrayList<IMGScopeDto> getImgScopeDto() {
		return imgScopeDto;
	}
	public void setImgScopeDto(ArrayList<IMGScopeDto> imgScopeDto) {
		this.imgScopeDto = imgScopeDto;
	}
	public String getSystemType() {
		return systemType;
	}
	public void setSystemType(String systemType) {
		this.systemType = systemType;
	}
	
	

}
