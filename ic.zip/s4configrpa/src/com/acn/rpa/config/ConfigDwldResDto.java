package com.acn.rpa.config;



import java.util.ArrayList;

public class ConfigDwldResDto {
	private String imgId;
	private ArrayList<String> configDwldData;
	
	public ConfigDwldResDto(){
	}
	
	public ArrayList<String> getConfigDwldData() {
		return configDwldData;
	}
	public void setConfigDwldData(ArrayList<String> configDwldData) {
		this.configDwldData = configDwldData;
	}
	public String getImgId() {
		return imgId;
	}
	public void setImgId(String imgId) {
		this.imgId = imgId;
	}
	
}
