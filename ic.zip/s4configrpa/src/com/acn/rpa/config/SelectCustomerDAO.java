package com.acn.rpa.config;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.admin.CustomerDto;
import com.acn.rpa.admin.ResponseDto;
import com.acn.rpa.admin.UserActiveResDto;
import com.acn.rpa.admin.UserActiveResDtoList;
import com.acn.rpa.admin.UserDto;
import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.DBConnection;
import com.acn.user.session.AssignedUsersDto;
import com.acn.user.session.CustomerListDto;
import com.acn.user.session.ResMessageDto;
import com.acn.user.session.UserProjectListDto;

public class SelectCustomerDAO {

    private final Logger slf4jLogger = LoggerFactory.getLogger(SelectCustomerDAO.class);
    
    //////
    
    public ProjectListDto getProjectsList(String userId){
		slf4jLogger.info("getProjectsList method started");
		Connection con = null;
		ResultSet rs=null;
			PreparedStatement pStmt=null;
		
		ProjectDto ProjectDto = null;
		ArrayList<ProjectDto> list = null;
		
		ProjectListDto list1=new ProjectListDto();
		boolean isValid = false;
		
		ResMessageDto resMessageDto = new ResMessageDto();
		list1.setResMessageDto(resMessageDto);
		try{
			con =  DBConnection.createConnection();
			pStmt =  con.prepareStatement("SELECT Distinct OMID, projectname FROM USERPROJECTS e WHERE e.UserID =?");
			pStmt.setString(1, userId);
			rs = pStmt.executeQuery();
			list = new ArrayList<ProjectDto>();
			while(rs.next()){
				isValid=true;
				ProjectDto=new ProjectDto();
				ProjectDto.setProjectName(rs.getString(2));
				ProjectDto.setOmId(rs.getString(1));
				
				list.add(ProjectDto);
			}
			list1.setProjectList(list);
			if (!isValid) {
				
				resMessageDto.setMessage(ConstantsValues.NORECORDSEXISTS);
				resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			}else{
				resMessageDto.setMessage(ConstantsValues.SUCCESSSTATUS);
				resMessageDto.setMsgType(ConstantsValues.SUCCESSSTATUS);
			}
			
			}
		catch (SQLException e){
			resMessageDto.setMessage(ConstantsValues.EXCEPTIONDETAILS);
			resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}
		finally{
			
			
			if(rs!=null){
				try {
					rs.close();
					rs=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
		
			
			
			
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			  slf4jLogger.info("getProjectsList method ended");

		}	
		return list1;
	}

       /////

	public UserProjectListDto customerSelector(String userId){
		slf4jLogger.info("customerSelector method started");
		Connection con = null;
		ResultSet rs=null;
		PreparedStatement pStmt=null;
		UserProjectListDto resDto = new UserProjectListDto();
		ArrayList<UserProjectsDto> userProjectsList = new ArrayList<>();
		UserProjectsDto userProjectsDto = null;
		boolean isValid = false;
		ResMessageDto resMessageDto = new ResMessageDto();
		resDto.setResMessageDto(resMessageDto);
		try{
			con =  DBConnection.createConnection();
			pStmt =  con.prepareStatement("SELECT A.OMID,A.UserID,A.Status,A.ProjectName,B.TROverRide,B.cust_DestReq  FROM USERPROJECTS A,Customer B WHERE A.STATUS= ? AND A.OMID=B.OMID AND A.UserID = ?");
			pStmt.setString(1, ConstantsValues.ACTIVESTATUS);
			pStmt.setString(2, userId);
			rs = pStmt.executeQuery();
		
			while(rs.next()){
				isValid = true;
				userProjectsDto = new UserProjectsDto();
				userProjectsDto.setOmId(rs.getString("OMID"));
				userProjectsDto.setUserId(rs.getString("UserID"));
				userProjectsDto.setStatus(rs.getString("Status"));
				userProjectsDto.setProjectName(rs.getString("ProjectName"));
				userProjectsDto.setTrOverRide(rs.getString("TROverRide"));
				userProjectsDto.setCust_DestReq(rs.getString("cust_DestReq"));//Added by Veena
				userProjectsList.add(userProjectsDto);
			}
			
			if(isValid){
			resDto.setAssignedProjects(userProjectsList);
			resDto.getResMessageDto().setMsgType(ConstantsValues.SUCCESSSTATUS);
			}else{
					resDto.getResMessageDto().setMessage("The userID you have entered does not exists!");
					slf4jLogger.error("The userID you have entered does not exists!");
					resDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
					return resDto;
			}
		}
		catch (SQLException e){
			resDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
			resDto.getResMessageDto().setMessage("Not able to fetch required Details ,please contact the Administrator!");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}
		finally{
			
			if(rs!=null){
				try {
					rs.close();
					rs=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			  slf4jLogger.info("customerSelector method ended");

		}	
		return resDto;
	}
	
	
	public ResponseDto addUserProject(UserProjectsDto userProjectsDto){
		slf4jLogger.info("addUserProject method started");
		Connection con = null;
		ResultSet rs=null;
		ResultSet rs1=null;
		ResultSet rs2=null;
		PreparedStatement pStmt=null;
		PreparedStatement pStmt1=null;
		PreparedStatement pStmt2=null;
		ResponseDto responseDtoObj = new ResponseDto();
		responseDtoObj.setClientId(userProjectsDto.getOmId());
		responseDtoObj.setUserId(userProjectsDto.getUserId());
		try{
			con =  DBConnection.createConnection();
			pStmt =  con.prepareStatement("SELECT UserID FROM USER WHERE UserID = ?");
			pStmt.setString(1, userProjectsDto.getUserId());
			rs = pStmt.executeQuery();
			if(!rs.next()){
				responseDtoObj.setMessage("The userID you have entered does not exists!");
				slf4jLogger.error("The userID you have entered does not exists!");
				responseDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
				return responseDtoObj;
			}
		} catch (SQLException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}finally{
			if(rs!=null){
				try {
					rs.close();
					rs=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
		}
			
		try{
			con =  DBConnection.createConnection();
			pStmt =  con.prepareStatement("SELECT OMID FROM CUSTOMER WHERE OMID = ?");
			pStmt.setString(1, userProjectsDto.getOmId());
			rs1 = pStmt.executeQuery();
			if(!rs1.next()){
				responseDtoObj.setMessage("The OMID you have entered does not exists!");
				slf4jLogger.error("The OMID you have entered does not exists!");
				responseDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
				return responseDtoObj;
			}
			userProjectsDto.setProjectName(rs1.getString("ProjectName"));
			pStmt2 =  con.prepareStatement("SELECT * FROM USERPROJECTS WHERE UserID =? AND OMID =?");
			pStmt2.setString(1, userProjectsDto.getUserId());
			pStmt2.setString(2, userProjectsDto.getOmId());
			rs2 = pStmt2.executeQuery();
			if(rs2.next()){
				responseDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
				responseDtoObj.setMessage("The userID-OMID combination you have entered already exists!");
				slf4jLogger.error("The userID-OMID combination you have entered already exists!");
				return responseDtoObj;
			}
			
		}
		catch (SQLException e){
			responseDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
			responseDtoObj.setMessage("Unexpected error occured while connecting to the Database, please contact the Administrator!");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}
		finally{
			if(rs1!=null){
				try {
					rs1.close();
					rs1=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
		}
		
		PreparedStatement ps = null;
		String query = "INSERT INTO USERPROJECTS(UserID, OMID, Status, ProjectName) VALUES (?,?,?,?)";
		try{
			ps =  con.prepareStatement(query);
			ps.setString (1, userProjectsDto.getUserId());
		    ps.setString (2, userProjectsDto.getOmId());
		    ps.setString (3, userProjectsDto.getStatus());
		    ps.setString (4, userProjectsDto.getProjectName());

		    ps.execute();
		    responseDtoObj.setStatus(ConstantsValues.SUCCESSSTATUS);
			responseDtoObj.setMessage("The OMID " + userProjectsDto.getOmId() + " has been linked with the userId " + userProjectsDto.getUserId() + ".");
		}
		catch (SQLException e){
			responseDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
			responseDtoObj.setMessage("Not able to store data in database, please contact the Administrator!");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}
		finally {
			if(rs2!=null){
				try {
					rs2.close();
					rs2=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(rs1!=null){
				try {
					rs1.close();
					rs1=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(rs!=null){
				try {
					rs.close();
					rs=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(ps!=null){
				try {
					ps.close();
					ps=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(pStmt2!=null){
				try {
					pStmt2.close();
					pStmt2=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(pStmt1!=null){
				try {
					pStmt1.close();
					pStmt1=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			  slf4jLogger.info("addUserProject method ended");

		}
		return responseDtoObj;
	}
	
	
	public AssignedUsersDto getProjectUsers(String omId){
		slf4jLogger.info("getProjectUsers method started");
		Connection con = null;
		ResultSet rs=null;
		ResultSet rs1=null;
		ResultSet rs2=null;
		PreparedStatement pStmt=null;
		PreparedStatement pStmt1=null;
		PreparedStatement pStmt2=null;
		int length = 0;
		UserDto userDto = null;
		ArrayList<UserDto> projectUsersList = new ArrayList<>();
		ArrayList<String> users = new ArrayList<>();
		AssignedUsersDto resDto = new AssignedUsersDto();
		ResMessageDto resMessageDto = new ResMessageDto();
		resDto.setResMessageDto(resMessageDto);
		StringBuilder query = new StringBuilder("SELECT * FROM USER WHERE UserID IN (");
		boolean isValid = false;
		try{
			con =  DBConnection.createConnection();
			pStmt =  con.prepareStatement("SELECT UserID FROM USERPROJECTS WHERE omId =?");
			pStmt.setString(1, omId);
			rs = pStmt.executeQuery();
			while(rs.next()){
				isValid = true;
				users.add(rs.getString("UserID"));
			}
			
			if(!isValid){
				resDto.getResMessageDto().setMessage("Project " + omId + " has not been assigned to any user OR the selected Project does not exist!");
				resDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
				slf4jLogger.error("The userID-OMID combination you have entered already exists!");
				return resDto;
			}
			
			pStmt2 = con.prepareStatement("SELECT * FROM CUSTOMER WHERE omId =?");
			pStmt2.setString(1, omId);
			rs2 = pStmt2.executeQuery();
			if(!rs2.next()){
				resDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
				resDto.getResMessageDto().setMessage("Unable to find Customer details of the project " + omId + ",please contact the Administrator!");
				slf4jLogger.error("Unable to find Customer details of the project " + omId + ",please contact the Administrator!");
				return resDto;
			}
			resDto.setProjectName(rs2.getString("PROJECTNAME"));
			resDto.setCustomerName(rs2.getString("CUSTOMERNAME"));
			length = users.size();
			
			for(int i=0;i<length;i++){
				if(i==length-1)
					query.append("?)");
				else
					query.append("?,");
				
			}
			pStmt1 = con.prepareStatement(query.toString());
			  int pos = 1;
			    for(int i=0;i<length;i++,pos++){
			    		pStmt1.setString (pos, users.get(i));	
				}
			
			rs1 = pStmt1.executeQuery();
			while(rs1.next()){
				userDto = new UserDto();
				userDto.setFirstName(rs1.getString("FIRSTNAME"));
				userDto.setLastName(rs1.getString("LASTNAME"));
				userDto.setEmail(rs1.getString("EMAILID"));
				userDto.setUserId(rs1.getString("USERID"));
				userDto.setRole(rs1.getString("ROLEID"));
				userDto.setStatus(rs1.getString("STATUS"));
				String validFrom = rs1.getTimestamp("VALIDFROM").toString();
				validFrom = validFrom.concat("00");
				String validTo = rs1.getTimestamp("VALIDTO").toString();
				validTo = validTo.concat("00");
				userDto.setValidFrom(validFrom);
				userDto.setValidTo(validTo);
				projectUsersList.add(userDto);
			}
			resDto.setUserList(projectUsersList);
			resDto.getResMessageDto().setMsgType(ConstantsValues.SUCCESSSTATUS);
			if(projectUsersList.isEmpty()){
				resDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
				resDto.getResMessageDto().setMessage("Unable to retrieve list of users assigned with the project" + omId + "!");
				slf4jLogger.error("Unable to retrieve list of users assigned with the project" + omId + "!");
			}
		}
		catch (SQLException e){
			resDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
			resDto.getResMessageDto().setMessage("Not able to fetch USERPROJECTS Details ,please contact the Administrator!");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}
		finally{
			if(rs2!=null){
				try {
					rs2.close();
					rs2=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(rs1!=null){
				try {
					rs1.close();
					rs1=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(rs!=null){
				try {
					rs.close();
					rs=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			if(pStmt1!=null){
				try {
					pStmt1.close();
					pStmt1=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			if(pStmt2!=null){
				try {
					pStmt2.close();
					pStmt2=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("getProjectUsers method ended");
		}	
		return resDto;
	}
	
	 
	
	public CustomerListDto getUserProjects(String userId){
		slf4jLogger.info("getUserProjects method started");
		Connection con = null;
		ResultSet rs=null;
		ResultSet rs1=null;
		PreparedStatement pStmt=null;
		PreparedStatement pStmt1=null;
		int length = 0;
		CustomerDto customerDto = null;
		ArrayList<CustomerDto> userProjectsList = new ArrayList<>();
		ArrayList<String> projects = new ArrayList<>();
		StringBuilder query = new StringBuilder("SELECT CUSTOMERNAME,ProjectName FROM CUSTOMER WHERE OMID IN (");
		boolean isValid = false;
		CustomerListDto resDto = new CustomerListDto();
		ResMessageDto resMessageDto = new ResMessageDto();
		resDto.setResMessageDto(resMessageDto);
		try{
			con =  DBConnection.createConnection();
			pStmt =  con.prepareStatement("SELECT OMID FROM USERPROJECTS WHERE UserID =?");
			pStmt.setString(1, userId);
			rs = pStmt.executeQuery();
			while(rs.next()){
				isValid = true;
				projects.add(rs.getString("OMID"));
			}
			
			if(!isValid){
				resDto.getResMessageDto().setMessage("User " + userId + " has not been assigned with any project OR the selected user does not exist!");
				resDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
				slf4jLogger.error("User " + userId + " has not been assigned with any project OR the selected user does not exist!");
				return resDto;
			}
			
			length = projects.size();
			
			for(int i=0;i<length;i++){
				if(i==length-1)
					query.append("?)");
				else
					query.append("?,");
				
			}
			
			pStmt1 = con.prepareStatement(query.toString());
			 int pos = 1;
			    for(int i=0;i<length;i++,pos++){
			    	pStmt1.setString (pos, projects.get(i));				
				}
			rs1 = pStmt1.executeQuery();
			while(rs1.next()){
				customerDto = new CustomerDto();
				customerDto.setCustomerName(rs1.getString("CUSTOMERNAME"));
				/*customerDto.setIndustryVertical(rs1.getString("INDUSTRYVERTICAL"));
				customerDto.setGeographicRegion(rs1.getString("GEOGRAPHICREGION"));
				customerDto.setDeliveryUnit(rs1.getString("DELIVERYUNIT"));
				customerDto.setCustomerType(rs1.getString("CUSTOMERTYPE"));
				customerDto.setIgPoc(rs1.getString("IGPOC"));
				customerDto.setGdn_ogLead(rs1.getString("GDNOGLEAD"));
				customerDto.setOmId(rs1.getString("OMID"));*/
				customerDto.setProjectName(rs1.getString("ProjectName"));
				//customerDto.setStatus(rs1.getString("STATUS"));
				userProjectsList.add(customerDto);
			}
			resDto.setCustomerList(userProjectsList);
			resDto.getResMessageDto().setMsgType(ConstantsValues.SUCCESSSTATUS);
			if(userProjectsList.isEmpty()){
				resDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
				resDto.getResMessageDto().setMessage("Unable to retrieve list of projects assigned to the user" + userId + "!");
				slf4jLogger.error("Unable to retrieve list of projects assigned to the user" + userId + "!");
			}
		}
		catch (SQLException e){
			resDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
			resDto.getResMessageDto().setMessage("Not able to fetch required Details ,please contact the Administrator!");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}
		finally{
			
			if(rs1!=null){
				try {
					rs1.close();
					rs1=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(rs!=null){
				try {
					rs.close();
					rs=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
		
			
			if(pStmt1!=null){
				try {
					pStmt1.close();
					pStmt1=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			  slf4jLogger.info("getUserProjects method ended");

		}	
		return resDto;
	}
	
	
	public ResponseDto unassignUserProjects(String userId, String projectName){
		slf4jLogger.info("unassignUserProjects method started");
		Connection con = null;
		ResultSet rs=null;
		PreparedStatement ps=null;
		PreparedStatement ps1=null;
		ResponseDto responseDtoObj = new ResponseDto();
		try{
			con = DBConnection.createConnection();
			ps = con.prepareStatement("SELECT * FROM USERPROJECTS WHERE UserID =? AND ProjectName =?");
			ps.setString(1, userId);
			ps.setString(2, projectName);
			rs = ps.executeQuery();
			if(!rs.next()){
				responseDtoObj.setMessage("The userID-ProjectName combination (" + userId + "-" + projectName + ") you have selected does not exist!");
				responseDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
				return responseDtoObj;
			}
			
			ps1 = con.prepareStatement("DELETE FROM USERPROJECTS WHERE UserID =? AND ProjectName =?");
			ps1.setString(1, userId);
			ps1.setString(2, projectName);
			if(ps1.executeUpdate() > 0){
				responseDtoObj.setMessage("The ProjectName " + projectName + " has been unassigned for the user " + userId);
				responseDtoObj.setStatus("Success");
			}
		}
		catch(SQLException e){
			responseDtoObj.setMessage("Unable connect to the Database, Please contact Administrator!");
			responseDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}
		finally{
			if(rs!=null){
				try {
					rs.close();
					rs=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
		
			
			if(ps1!=null){
				try {
					ps1.close();
					ps1=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			
			if(ps!=null){
				try {
					ps.close();
					ps=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("unassignUserProjects method ended");

		}
		return responseDtoObj;
	}
	////
	public DownloadReportDtoList getDownloadReport(String omid){
	slf4jLogger.info("DownloadReportDtoList method started");
	Connection con = null;
	ResultSet rs=null;
		PreparedStatement pStmt=null;
	
		DownloadReportDto downloadDto = null;
	ArrayList<DownloadReportDto> list = null;
	
	DownloadReportDtoList list1=new DownloadReportDtoList();
	boolean isValid = false;
	
	ResMessageDto resMessageDto = new ResMessageDto();
	list1.setResMessageDto(resMessageDto);
	try{
		con =  DBConnection.createConnection();
		pStmt =  con.prepareStatement("SELECT Distinct B.transid,B.createddate, B.SCENARIO,c.destinationname,B.userid,B.sapuserid,(select count(1) from configdownloadhistory where transid = B.transid) Count FROM sapsystem c, CONFIGTRANSACTION B,configdownloadhistory a, userprojects e WHERE B.OMID =? and b.sourcesystemid = c.id AND a.transid = b.transid ORDER BY B.createddate DESC");
		pStmt.setString(1, omid);
		rs = pStmt.executeQuery();
		list = new ArrayList<DownloadReportDto>();
		while(rs.next()){
			isValid=true;
			downloadDto=new DownloadReportDto();
			downloadDto.setTransid(rs.getString(1));
			downloadDto.setCreateddate(rs.getTimestamp(2));
			downloadDto.setSCENARIO(rs.getString(3));
			downloadDto.setDestinationname(rs.getString(4));
			downloadDto.setUserid(rs.getString(5));
			downloadDto.setSapuserid(rs.getString(6));
			downloadDto.setCount(rs.getString(7));
			
			list.add(downloadDto);
		}
		
		list1.setDownloadReportList(list);
		if (!isValid) {
			
			resMessageDto.setMessage(ConstantsValues.NORECORDSEXISTS);
			resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
		}else{
			resMessageDto.setMessage(ConstantsValues.SUCCESSSTATUS);
			resMessageDto.setMsgType(ConstantsValues.SUCCESSSTATUS);
		}
		
		}
	catch (SQLException e){
		resMessageDto.setMessage(ConstantsValues.EXCEPTIONDETAILS);
		resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	}
	finally{
		
		
		if(rs!=null){
			try {
				rs.close();
				rs=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
	
		
		
		
		if(pStmt!=null){
			try {
				pStmt.close();
				pStmt=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		
		if(con!=null){
			try {
				con.close();
				con=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		
		  slf4jLogger.info("DownloadReportDtoList method ended");
		  list1.setResMessageDto(resMessageDto);
	}	
	return list1;
}

////
	
}