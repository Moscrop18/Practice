package com.acn.rpa.config;

import java.util.ArrayList;

import javax.validation.Valid;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class IMGScopeDto {

	private String id;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	@Size(min = 1, max = 30)
	private String imgId;
	@Size(min = 1, max = 255)
	private String imgDescription;
	@Size(min = 1, max = 10)
	private String seqNo;
	@DecimalMin(value = "0")
    @DecimalMax(value = "1")
	private int enabled;
	@Size(min = 1, max = 1)
	@Pattern(regexp = "[a-zA-Z]+")
	private String isMasterData;
	@Valid
	private ArrayList<String> logs;
	private String fileName;
	private String filepath;
	private String Status;
	@Valid
	private ArrayList<String> fileUploadStatusMsg;
	@Size(min = 1, max = 2)
	@Pattern(regexp = "[a-zA-Z]+")
	private String trType;
	@Size(min = 0, max = 10)
	@Pattern(regexp = "[a-zA-Z0-9]*$")
	private String workbenchTr;
	@Size(min = 0, max = 10)
	@Pattern(regexp = "[a-zA-Z0-9]*$")
	private String customizingTr;
	private boolean customizingTr_readOnly;
	private boolean workbenchTr_readOnly;
	@Size(min = 0, max = 10)
	@Pattern(regexp = "[a-zA-Z]*$")
	private String customizingTr_mode;
	@Size(min = 0, max = 10)
	@Pattern(regexp = "[a-zA-Z]*$")
	private String workbenchTr_mode;
	
	private String indSeq;
	
	public String getIndSeq() {
		return indSeq;
	}
	public void setIndSeq(String indSeq) {
		this.indSeq = indSeq;
	}
	public ArrayList<String> getFileUploadStatusMsg() {
		return fileUploadStatusMsg;
	}
	public void setFileUploadStatusMsg(ArrayList<String> fileUploadStatusMsg) {
		this.fileUploadStatusMsg = fileUploadStatusMsg;
	}
	
	public String getImgDescription() {
		return imgDescription;
	}
	public void setImgDescription(String imgDescription) {
		this.imgDescription = imgDescription;
	}
	public String getImgId() {
		return imgId;
	}
	public void setImgId(String imgId) {
		this.imgId = imgId;
	}

	public String getSeqNo() {
		return seqNo;
	}
	public void setSeqNo(String seqNo) {
		this.seqNo = seqNo;
	}
	public int getEnabled() {
		return enabled;
	}
	public void setEnabled(int enabled) {
		this.enabled = enabled;
	}
	public String getIsMasterData() {
		return isMasterData;
	}
	public void setIsMasterData(String isMasterData) {
		this.isMasterData = isMasterData;
	}
	public ArrayList<String> getLogs() {
		return logs;
	}
	public void setLogs(ArrayList<String> logs) {
		this.logs = logs;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFilepath() {
		return filepath;
	}
	public void setFilepath(String filepath) {
		this.filepath = filepath;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public String getTrType() {
		return trType;
	}
	public void setTrType(String trType) {
		this.trType = trType;
	}
	public String getWorkbenchTr() {
		return workbenchTr;
	}
	public void setWorkbenchTr(String workbenchTr) {
		this.workbenchTr = workbenchTr;
	}
	public String getCustomizingTr() {
		return customizingTr;
	}
	public void setCustomizingTr(String customizingTr) {
		this.customizingTr = customizingTr;
	}
	public boolean isCustomizingTr_readOnly() {
		return customizingTr_readOnly;
	}
	public void setCustomizingTr_readOnly(boolean customizingTr_readOnly) {
		this.customizingTr_readOnly = customizingTr_readOnly;
	}
	public boolean isWorkbenchTr_readOnly() {
		return workbenchTr_readOnly;
	}
	public void setWorkbenchTr_readOnly(boolean workbenchTr_readOnly) {
		this.workbenchTr_readOnly = workbenchTr_readOnly;
	}
	public String getCustomizingTr_mode() {
		return customizingTr_mode;
	}
	public void setCustomizingTr_mode(String customizingTr_mode) {
		this.customizingTr_mode = customizingTr_mode;
	}
	public String getWorkbenchTr_mode() {
		return workbenchTr_mode;
	}
	public void setWorkbenchTr_mode(String workbenchTr_mode) {
		this.workbenchTr_mode = workbenchTr_mode;
	}
	
	
	
	
}
