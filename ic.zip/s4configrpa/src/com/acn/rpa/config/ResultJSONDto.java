package com.acn.rpa.config;

import java.util.List;

public class ResultJSONDto {

	private List<JSONFormatDto> UploadConfigStatus;
	
	private ResultDto ResHeaderStatus; 

	

	public List<JSONFormatDto> getUploadConfigStatus() {
		return UploadConfigStatus;
	}

	public ResultDto getResHeaderStatus() {
		return ResHeaderStatus;
	}

	public void setResHeaderStatus(ResultDto resHeaderStatus) {
		ResHeaderStatus = resHeaderStatus;
	}

	public void setUploadConfigStatus(List<JSONFormatDto> uploadConfigStatus) {
		UploadConfigStatus = uploadConfigStatus;
	}

	public ResultJSONDto(List<JSONFormatDto> UploadConfigStatus,  ResultDto  SrcDownloadStatus) {
		super();
		this.UploadConfigStatus = UploadConfigStatus;
		this.ResHeaderStatus = SrcDownloadStatus;

	}
}
