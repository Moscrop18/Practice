package com.acn.rpa.config;

public class ResultDto {
	private boolean srcConnectionStatus;
	private boolean dstConnectionStatus;
	private boolean srcExecutionStatus;
	private boolean dstExecutionStatus;
	public boolean isSrcConnectionStatus() {
		return srcConnectionStatus;
	}
	public void setSrcConnectionStatus(boolean srcConnectionStatus) {
		this.srcConnectionStatus = srcConnectionStatus;
	}
	public boolean isDstConnectionStatus() {
		return dstConnectionStatus;
	}
	public void setDstConnectionStatus(boolean dstConnectionStatus) {
		this.dstConnectionStatus = dstConnectionStatus;
	}
	public boolean isSrcExecutionStatus() {
		return srcExecutionStatus;
	}
	public void setSrcExecutionStatus(boolean srcExecutionStatus) {
		this.srcExecutionStatus = srcExecutionStatus;
	}
	public boolean isDstExecutionStatus() {
		return dstExecutionStatus;
	}
	public void setDstExecutionStatus(boolean dstExecutionStatus) {
		this.dstExecutionStatus = dstExecutionStatus;
	}
	public ResultDto(boolean srcConnStatus, boolean srcExStatus, boolean dstConnStatus, boolean dstExStatus) {
		super();
		this.srcConnectionStatus = srcConnStatus;
		this.srcExecutionStatus = srcExStatus;
		this.dstConnectionStatus = dstConnStatus;
		this.dstExecutionStatus = dstExStatus;
	}
}
