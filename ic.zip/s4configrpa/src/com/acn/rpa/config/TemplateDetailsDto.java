package com.acn.rpa.config;

import java.io.InputStream;

public class TemplateDetailsDto {
private InputStream stream;

public InputStream getStream() {
	return stream;
}

public void setStream(InputStream stream) {
	this.stream = stream;
}

}
