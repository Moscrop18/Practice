package com.acn.rpa.config;

import java.util.ArrayList;

public class UploadResponseDto {
	
	private boolean dstConnectionStatus;
	private boolean dstExecutionStatus;

	ArrayList<String> responseData = new ArrayList<>();
	private int recordCount;
	public int getRecordCount() {
		return recordCount;
	}
	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}
	public boolean isDstConnectionStatus() {
		return dstConnectionStatus;
	}
	public void setDstConnectionStatus(boolean dstConnectionStatus) {
		this.dstConnectionStatus = dstConnectionStatus;
	}
	public boolean isDstExecutionStatus() {
		return dstExecutionStatus;
	}
	public void setDstExecutionStatus(boolean dstExecutionStatus) {
		this.dstExecutionStatus = dstExecutionStatus;
	}
	public ArrayList<String> getResponseData() {
		return responseData;
	}
	public void setResponseData(ArrayList<String> responseData) {
		this.responseData = responseData;
	} 


}
