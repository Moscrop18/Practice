
package com.acn.rpa.config;
import java.util.ArrayList;
import java.util.HashMap;



/*
 * added isCustomDestinationRequired,sapUserId and sapPassword for dynamic destination connectivity
 */


public class CheckToPlantDto {

	
	private HashMap<String,String> error;
	public HashMap<String, String> getError() {
		return error;
	}
	public void setError(HashMap<String, String> error) {
		this.error = error;
	}
	private ArrayList<String> toPlantsList;
	
	
	public ArrayList<String> getToPlantsList() {
		return toPlantsList;
	}
	public void setToPlantsList(ArrayList<String> toPlantsList) {
		this.toPlantsList = toPlantsList;
	}


}
