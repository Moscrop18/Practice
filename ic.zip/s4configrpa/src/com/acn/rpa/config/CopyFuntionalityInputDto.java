
package com.acn.rpa.config;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

/*
 * added isCustomDestinationRequired,sapUserId and sapPassword for dynamic destination connectivity
 */
import com.acn.rpa.imghierarchy.ImgDownloadDto;
import com.acn.user.session.SessionInputDTO;

public class CopyFuntionalityInputDto {

@Size(min = 1, max = 20)
@Pattern(regexp = "[a-zA-Z0-9]+")
private String srcDestination;
@Size(min = 1, max = 20)
@Pattern(regexp = "[a-zA-Z0-9]+")
private String tgtDestination;
private String systemType ;
private String destinationName;
private String clientNo;

private String hostName;
private String sysNo;

private int sncEnabled;

private String sncName;

private String sncPartnerName;

private String sapRouter;

private String sncProtectionLevel;
private ArrayList<HashMap<String, ArrayList<String>>> copyDetails;


public ArrayList<HashMap<String, ArrayList<String>>> getCopyDetails() {
	return copyDetails;
}
public void setCopyDetails(ArrayList<HashMap<String, ArrayList<String>>> copyDetails) {
	this.copyDetails = copyDetails;
}
public String getDestinationName() {
	return destinationName;
}
public void setDestinationName(String destinationName) {
	this.destinationName = destinationName;
}
public String getClientNo() {
	return clientNo;
}
public void setClientNo(String clientNo) {
	this.clientNo = clientNo;
}
public String getHostName() {
	return hostName;
}
public void setHostName(String hostName) {
	this.hostName = hostName;
}
public String getSysNo() {
	return sysNo;
}
public void setSysNo(String sysNo) {
	this.sysNo = sysNo;
}
private ArrayList<BwnFieldResDto> dwldResDtoList;
@Size(min = 0, max = 10)
@Pattern(regexp = "[a-zA-Z0-9]*$")
private String workbenchTr;
@Size(min = 0, max = 10)
@Pattern(regexp = "[a-zA-Z0-9]*$")
private String customizingTr;
private boolean isIMGHierarchy;

public boolean isIMGHierarchy() {
	return isIMGHierarchy;
}
public void setIMGHierarchy(boolean isIMGHierarchy) {
	this.isIMGHierarchy = isIMGHierarchy;
}
@Valid
private SessionInputDTO sessionInputDTO;

public SessionInputDTO getSessionInputDTO() {
		return sessionInputDTO;
	}
	public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
		this.sessionInputDTO = sessionInputDTO;
	}


public String getWorkbenchTr() {
	return workbenchTr;
}

public void setWorkbenchTr(String workbenchTr) {
	this.workbenchTr = workbenchTr;
}

public String getCustomizingTr() {
	return customizingTr;
}

public void setCustomizingTr(String customizingTr) {
	this.customizingTr = customizingTr;
}

public String getImgID() {
	return imgID;
}

public void setImgID(String imgID) {
	this.imgID = imgID;
}
@Valid
private ArrayList<ImgDownloadDto> imgDownloadDto ;
@Valid
private ImgDownloadDto imgDownloadDtoObj ;
@Size(min = 1, max = 30)
private String sourceSystemID;
@Size(min = 1, max = 30)
private String targetSystemID;
@Size(min = 1, max = 6)
@Pattern(regexp = "[a-zA-Z0-9]+")
private String isCustomDestinationRequired;
public String getSapLanguage() {
	return sapLanguage;
}
public void setSapLanguage(String sapLanguage) {
	this.sapLanguage = sapLanguage;
}
@Size(min = 0, max = 124)
private String sapUserId;
@Size(min = 0, max = 124)
private String sapPassword;
@Size(min = 0, max = 2)
@Pattern(regexp = "[a-zA-Z]*$")
private String sapLanguage;
@Size(min = 1, max = 30)
private String imgID;


//Added for Logging
@DecimalMin(value = "0")
@DecimalMax(value = "99999999")
private int transactionID;
@Size(min = 1, max = 50)
@Pattern(regexp = "[a-zA-Z0-9\\s._&-,]+")
private String projectName;
@Size(min = 1, max = 50)
@Pattern(regexp = "[a-zA-Z\\s._&-,]+")
private String scenario;
@Size(min = 1, max = 30)
private String omgID;
@Size(min = 1, max = 3)
@Pattern(regexp = "[a-zA-Z0-9]+")
private String systemID;
@Size(min = 1, max = 8)
@Pattern(regexp = "[a-zA-Z0-9]+")
private String userID;
public int getExeReqCount() {
	return exeReqCount;
}
public void setExeReqCount(int exeReqCount) {
	this.exeReqCount = exeReqCount;
}
@Size(min = 1, max = 45)
private String module;	
private String message;

@DecimalMin(value = "1")
@DecimalMax(value = "99999999")
private int exeReqCount;
//Ended for Logging

public String getSourceSystemID() {
	return sourceSystemID;
}

public void setSourceSystemID(String sourceSystemID) {
	this.sourceSystemID = sourceSystemID;
}

public String getTargetSystemID() {
	return targetSystemID;
}

public void setTargetSystemID(String targetSystemID) {
	this.targetSystemID = targetSystemID;
}
public ImgDownloadDto getImgDownloadDtoObj() {
	return imgDownloadDtoObj;
}

public void setImgDownloadDtoObj(ImgDownloadDto imgDownloadDtoObj) {
	this.imgDownloadDtoObj = imgDownloadDtoObj;
}

private BwnFieldResDto bwnFieldResDto ;
public BwnFieldResDto getBwnFieldResDto() {
	return bwnFieldResDto;
}

public void setBwnFieldResDto(BwnFieldResDto bwnFieldResDto) {
	this.bwnFieldResDto = bwnFieldResDto;
}

public String getIsCustomDestinationRequired() {
	return isCustomDestinationRequired;
}

public void setIsCustomDestinationRequired(String isCustomDestinationRequired) {
	this.isCustomDestinationRequired = isCustomDestinationRequired;
}

public String getSapUserId() {
	return sapUserId;
}

public void setSapUserId(String sapUserId) {
	this.sapUserId = sapUserId;
}

public String getSapPassword() {
	return sapPassword;
}

public void setSapPassword(String sapPassword) {
	this.sapPassword = sapPassword;
}

 

public int getTransactionID() {
	return transactionID;
}

public void setTransactionID(int transactionID) {
	this.transactionID = transactionID;
}

public String getProjectName() {
	return projectName;
}

public void setProjectName(String projectName) {
	this.projectName = projectName;
}

public String getScenario() {
	return scenario;
}

public void setScenario(String scenario) {
	this.scenario = scenario;
}

public String getOmgID() {
	return omgID;
}

public void setOmgID(String omgID) {
	this.omgID = omgID;
}

public String getSystemID() {
	return systemID;
}

public void setSystemID(String systemID) {
	this.systemID = systemID;
}

public String getUserID() {
	return userID;
}

public void setUserID(String userID) {
	this.userID = userID;
}

public String getModule() {
	return module;
}

public void setModule(String module) {
	this.module = module;
}

public ArrayList<ImgDownloadDto> getImgDownloadDto() {
	return imgDownloadDto;
}

public void setImgDownloadDto(ArrayList<ImgDownloadDto> imgDownloadDto) {
	this.imgDownloadDto = imgDownloadDto;
}

public String getSystemType() {
	return systemType;
}

public void setSystemType(String systemType) {
	this.systemType = systemType;
}

public CopyFuntionalityInputDto() {
}
public String getSrcDestination() {
	return srcDestination;
}
public void setSrcDestination(String srcDestination) {
	this.srcDestination = srcDestination;
}
public String getTgtDestination() {
	return tgtDestination;
}
public void setTgtDestination(String tgtDestination) {
	this.tgtDestination = tgtDestination;
}

public ArrayList<BwnFieldResDto> getDwldResDtoList() {
	return dwldResDtoList;
}

public void setDwldResDtoList(ArrayList<BwnFieldResDto> dwldResDtoList) {
	this.dwldResDtoList = dwldResDtoList;
}

public String getMessage() {
	return message;
}

public void setMessage(String message) {
	this.message = message;
}
public int getSncEnabled() {
	return sncEnabled;
}
public void setSncEnabled(int sncEnabled) {
	this.sncEnabled = sncEnabled;
}
public String getSncName() {
	return sncName;
}
public void setSncName(String sncName) {
	this.sncName = sncName;
}
public String getSncPartnerName() {
	return sncPartnerName;
}
public void setSncPartnerName(String sncPartnerName) {
	this.sncPartnerName = sncPartnerName;
}
public String getSapRouter() {
	return sapRouter;
}
public void setSapRouter(String sapRouter) {
	this.sapRouter = sapRouter;
}
public String getSncProtectionLevel() {
	return sncProtectionLevel;
}
public void setSncProtectionLevel(String sncProtectionLevel) {
	this.sncProtectionLevel = sncProtectionLevel;
}

}
