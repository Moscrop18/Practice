package com.acn.rpa.config;

import java.util.ArrayList;

import javax.validation.Valid;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.acn.rpa.imghierarchy.ImgHierarchyCustomDto;
import com.acn.user.session.SessionInputDTO;

public class BrownFieldModDownloadDto {
	@Valid
	private ImgHierarchyCustomDto imgHierarchyCustomDto;
	private String destinationName;
	private String clientNo;
	private String hostName;
	private String sysNo;
	private String omId;
	
	private int sncEnabled;
	
	private String sncName;
	
	private String sncPartnerName;
	
	private String sapRouter;
	
	private String sncProtectionLevel;
	
	private boolean industryFlag;
	
	private String industry;
	
	private String subIndustry;
	
	private String industryAlias;
	
	private String subIndustryAlias;
	
	private ArrayList<String> imgList;
	
	
	public ArrayList<String> getImgList() {
		return imgList;
	}
	public void setImgList(ArrayList<String> imgList) {
		this.imgList = imgList;
	}
	public String getOmId() {
		return omId;
	}
	public void setOmId(String omId) {
		this.omId = omId;
	}
	private Boolean copyFlag=false;
	public Boolean getCopyFlag() {
		return copyFlag;
	}
	public void setCopyFlag(Boolean copyFlag) {
		this.copyFlag = copyFlag;
	}
	public String getDestinationName() {
		return destinationName;
	}
	public void setDestinationName(String destinationName) {
		this.destinationName = destinationName;
	}
	public String getClientNo() {
		return clientNo;
	}
	public void setClientNo(String clientNo) {
		this.clientNo = clientNo;
	}
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public String getSysNo() {
		return sysNo;
	}
	public void setSysNo(String sysNo) {
		this.sysNo = sysNo;
	}
	@Size(min = 1, max = 20)
	@Pattern(regexp = "^\\s*[\\da-zA-Z][\\da-zA-Z\\s]*$")
	private String systemType;
	@Size(min = 1, max = 20)
	@Pattern(regexp = "[a-zA-Z0-9]+")
	private String srcSystem;
	@DecimalMin(value = "0")
    @DecimalMax(value = "9999999")
	private int transactionID;
	private String projectName;
	private String scenario;
	private String omgID;
	private String systemID;
	private String userID;
	//Added by Veena
		private String sapUserId;
		public String getSapUserId() {
			return sapUserId;
		}
		public void setSapUserId(String sapUserId) {
			this.sapUserId = sapUserId;
		}
		private String destPasswrd;
		private String language;
		private String custDestReq;	
		//Ended by Veena
	
	@Valid
	private SessionInputDTO sessionInputDTO;
	
	public SessionInputDTO getSessionInputDTO() {
		return sessionInputDTO;
	}
	public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
		this.sessionInputDTO = sessionInputDTO;
	}
	public int getTransactionID() {
		return transactionID;
	}
	public void setTransactionID(int transactionID) {
		this.transactionID = transactionID;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getScenario() {
		return scenario;
	}
	public void setScenario(String scenario) {
		this.scenario = scenario;
	}
	public String getOmgID() {
		return omgID;
	}
	public void setOmgID(String omgID) {
		this.omgID = omgID;
	}
	public String getSystemID() {
		return systemID;
	}
	public void setSystemID(String systemID) {
		this.systemID = systemID;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	private String message;
	
	public ImgHierarchyCustomDto getImgHierarchyCustomDto() {
		return imgHierarchyCustomDto;
	}
	public void setImgHierarchyCustomDto(ImgHierarchyCustomDto imgHierarchyCustomDto) {
		this.imgHierarchyCustomDto = imgHierarchyCustomDto;
	}
	public String getSystemType() {
		return systemType;
	}
	public void setSystemType(String systemType) {
		this.systemType = systemType;
	}
	public String getSrcSystem() {
		return srcSystem;
	}
	public void setSrcSystem(String srcSystem) {
		this.srcSystem = srcSystem;
	}
	
	public String getDestPasswrd() {
		return destPasswrd;
	}
	public void setDestPasswrd(String destPasswrd) {
		this.destPasswrd = destPasswrd;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getCustDestReq() {
		return custDestReq;
	}
	public void setCustDestReq(String custDestReq) {
		this.custDestReq = custDestReq;
	}
	public int getSncEnabled() {
		return sncEnabled;
	}
	public void setSncEnabled(int sncEnabled) {
		this.sncEnabled = sncEnabled;
	}
	public String getSncName() {
		return sncName;
	}
	public void setSncName(String sncName) {
		this.sncName = sncName;
	}
	public String getSncPartnerName() {
		return sncPartnerName;
	}
	public void setSncPartnerName(String sncPartnerName) {
		this.sncPartnerName = sncPartnerName;
	}
	public String getSapRouter() {
		return sapRouter;
	}
	public void setSapRouter(String sapRouter) {
		this.sapRouter = sapRouter;
	}
	public String getSncProtectionLevel() {
		return sncProtectionLevel;
	}
	public void setSncProtectionLevel(String sncProtectionLevel) {
		this.sncProtectionLevel = sncProtectionLevel;
	}
	public boolean isIndustryFlag() {
		return industryFlag;
	}
	public void setIndustryFlag(boolean industryFlag) {
		this.industryFlag = industryFlag;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public String getSubIndustry() {
		return subIndustry;
	}
	public void setSubIndustry(String subIndustry) {
		this.subIndustry = subIndustry;
	}
	public String getIndustryAlias() {
		return industryAlias;
	}
	public void setIndustryAlias(String industryAlias) {
		this.industryAlias = industryAlias;
	}
	public String getSubIndustryAlias() {
		return subIndustryAlias;
	}
	public void setSubIndustryAlias(String subIndustryAlias) {
		this.subIndustryAlias = subIndustryAlias;
	}
}
