package com.acn.rpa.config;

import java.util.ArrayList;

public class ConfigInputDTO {

	private ArrayList<String> recordByView;
	private int recordCount;
	public ArrayList<String> getRecordByView() {
		return recordByView;
	}
	public void setRecordByView(ArrayList<String> recordByView) {
		this.recordByView = recordByView;
	}
	public int getRecordCount() {
		return recordCount;
	}
	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}
}
