package com.acn.rpa.config;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.acn.user.session.SessionInputDTO;

/**
 * @author Rajesh Valupadasu
 */


public class SAPUserDto {
	@Size(min = 0, max = 124)
	private String sapUserId;
	@Size(min = 0, max = 124)
	private String password;
	@Size(min = 1, max = 20)
	@Pattern(regexp = "[a-zA-Z0-9]+")
	private String destinationName;
	private String clientNo;
	private String hostName;
	private String sysNo;
	
	private int sncEnabled;
	
	private String sncName;
	
	private String sncPartnerName;
	
	private String sapRouter;
	
	private String sncProtectionLevel;
	public String getClientNo() {
		return clientNo;
	}
	public void setClientNo(String clientNo) {
		this.clientNo = clientNo;
	}
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public String getSysNo() {
		return sysNo;
	}
	public void setSysNo(String sysNo) {
		this.sysNo = sysNo;
	}
	private String custdestReq;
	public String getCustdestReq() {
		return custdestReq;
	}
	public void setCustdestReq(String custdestReq) {
		this.custdestReq = custdestReq;
	}
	@Valid
	private SessionInputDTO sessionInputDTO;
	
	public String getSapLanguage() {
		return sapLanguage;
	}
	public void setSapLanguage(String sapLanguage) {
		this.sapLanguage = sapLanguage;
	}
	@Size(min = 0, max = 2)
	@Pattern(regexp = "[a-zA-Z]*$")
	private String sapLanguage;
	
	public SessionInputDTO getSessionInputDTO() {
		return sessionInputDTO;
	}
	public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
		this.sessionInputDTO = sessionInputDTO;
	}
	public String getSapUserId() {
		return sapUserId;
	}
	public void setSapUserId(String sapUserId) {
		this.sapUserId = sapUserId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getDestinationName() {
		return destinationName;
	}
	public void setDestinationName(String destinationName) {
		this.destinationName = destinationName;
	}
	public int getSncEnabled() {
		return sncEnabled;
	}
	public void setSncEnabled(int sncEnabled) {
		this.sncEnabled = sncEnabled;
	}
	public String getSncName() {
		return sncName;
	}
	public void setSncName(String sncName) {
		this.sncName = sncName;
	}
	public String getSncPartnerName() {
		return sncPartnerName;
	}
	public void setSncPartnerName(String sncPartnerName) {
		this.sncPartnerName = sncPartnerName;
	}
	public String getSapRouter() {
		return sapRouter;
	}
	public void setSapRouter(String sapRouter) {
		this.sapRouter = sapRouter;
	}
	public String getSncProtectionLevel() {
		return sncProtectionLevel;
	}
	public void setSncProtectionLevel(String sncProtectionLevel) {
		this.sncProtectionLevel = sncProtectionLevel;
	}

}
