package com.acn.rpa.config.dto;

public class ConfigTemplateDto {
	private SelectedScopeDto selectedScopeDto;
	private String statusMsg;
	private boolean status;
	
	public SelectedScopeDto getSelectedScopeDto() {
		return selectedScopeDto;
	}
	public void setSelectedScopeDto(SelectedScopeDto selectedScopeDto) {
		this.selectedScopeDto = selectedScopeDto;
	}
	public String getStatusMsg() {
		return statusMsg;
	}
	public void setStatusMsg(String statusMsg) {
		this.statusMsg = statusMsg;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	
	
	

}
