package com.acn.rpa.config.dto;

import org.apache.poi.ss.usermodel.Workbook;

public class ImgFilterResponseDTO {
	private boolean status;
	private Workbook excelWorkbook;
	private String errDetails;
	
	public String getErrDetails() {
		return errDetails;
	}
	public void setErrDetails(String errDetails) {
		this.errDetails = errDetails;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public Workbook getExcelWorkbook() {
		return excelWorkbook;
	}
	public void setExcelWorkbook(Workbook excelWorkbook) {
		this.excelWorkbook = excelWorkbook;
	}
	
	

}