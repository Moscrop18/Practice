package com.acn.rpa.config.dto;

import java.util.ArrayList;
import java.util.List;

import com.acn.rpa.docservice.HCPDocServiceResDto;
import com.acn.user.session.ResMessageDto;

public class GoldenTempUploadResDto {
	private ArrayList<ConfigTemplateDto> configTemplateDto;
	private boolean uploadStatus;
	private List<String> fileNameList;
	ArrayList<HCPDocServiceResDto> listHCPDocServiceResDto;
	private ResMessageDto resMessageDto;

	public ResMessageDto getResMessageDto() {
			return resMessageDto;
		}
	public void setResMessageDto(ResMessageDto resMessageDto) {
			this.resMessageDto = resMessageDto;
		}
	public ArrayList<ConfigTemplateDto> getConfigTemplateDto() {
		return configTemplateDto;
	}
	public void setConfigTemplateDto(ArrayList<ConfigTemplateDto> configTemplateDto) {
		this.configTemplateDto = configTemplateDto;
	}
	public boolean isUploadStatus() {
		return uploadStatus;
	}
	public void setUploadStatus(boolean uploadStatus) {
		this.uploadStatus = uploadStatus;
	}
	public List<String> getFileNameList() {
		return fileNameList;
	}
	public void setFileNameList(List<String> fileNameList) {
		this.fileNameList = fileNameList;
	}
	public ArrayList<HCPDocServiceResDto> getListHCPDocServiceResDto() {
		return listHCPDocServiceResDto;
	}
	public void setListHCPDocServiceResDto(ArrayList<HCPDocServiceResDto> listHCPDocServiceResDto) {
		this.listHCPDocServiceResDto = listHCPDocServiceResDto;
	}
	
	
	

}
