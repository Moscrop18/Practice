package com.acn.rpa.config.dto;

public class UploadExecutionLogDto {

	private int configUploadID;
	private String imgID;
	private int sequenceID;
	private String status;
	private String userID;
	private String message;
	public int getConfigUploadID() {
		return configUploadID;
	}
	public void setConfigUploadID(int configUploadID) {
		this.configUploadID = configUploadID;
	}
	public String getImgID() {
		return imgID;
	}
	public void setImgID(String imgID) {
		this.imgID = imgID;
	}

	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public int getSequenceID() {
		return sequenceID;
	}
	public void setSequenceID(int sequenceID) {
		this.sequenceID = sequenceID;
	}
	
}
