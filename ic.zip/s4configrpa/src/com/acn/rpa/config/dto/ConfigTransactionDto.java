package com.acn.rpa.config.dto;

import java.sql.Timestamp;

import javax.validation.Valid;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.acn.user.session.SessionInputDTO;

public class ConfigTransactionDto {
	
	private int transactionID;
	@Size(min = 1, max = 8)
	@Pattern(regexp = "[a-zA-Z0-9]+")
	private String userID;
	@Size(min = 1, max = 20)
	private String omgID;
	private Timestamp createdDate;
	@Size(min = 0, max = 124)
	private String sapUserID;
	@Size(min = 1, max = 50)
	@Pattern(regexp = "[a-zA-Z\\s._&-,]+")
	private String scenario;
	@Valid
	private SessionInputDTO sessionInputDTO;
	
	public SessionInputDTO getSessionInputDTO() {
		return sessionInputDTO;
	}
	public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
		this.sessionInputDTO = sessionInputDTO;
	}
	public String getDestinationName() {
		return destinationName;
	}
	public void setDestinationName(String destinationName) {
		this.destinationName = destinationName;
	}
	@DecimalMin(value = "0")
	@DecimalMax(value = "99999999")
	private int targetValue;
	@DecimalMin(value = "0")
	@DecimalMax(value = "99999999")
	private int sourceValue;
	@Size(min = 1, max = 20)
	@Pattern(regexp = "[a-zA-Z0-9]+")
	private String destinationName;
	public int getSourceValue() {
		return sourceValue;
	}
	public void setSourceValue(int sourceValue) {
		this.sourceValue = sourceValue;
	}
	private boolean configReExe;
	
	public boolean isConfigReExe() {
		return configReExe;
	}
	public void setConfigReExe(boolean configReExe) {
		this.configReExe = configReExe;
	}
	public String getSapUserID() {
		return sapUserID;
	}
	public void setSapUserID(String sapUserID) {
		this.sapUserID = sapUserID;
	}
	public String getScenario() {
		return scenario;
	}
	public void setScenario(String scenario) {
		this.scenario = scenario;
	}
	public int getTargetValue() {
		return targetValue;
	}
	public void setTargetValue(int targetValue) {
		this.targetValue = targetValue;
	}
	public int getTransactionID() {
		return transactionID;
	}
	public void setTransactionID(int transactionID) {
		this.transactionID = transactionID;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getOmgID() {
		return omgID;
	}
	public void setOmgID(String omgID) {
		this.omgID = omgID;
	}
	public Timestamp getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	

}
