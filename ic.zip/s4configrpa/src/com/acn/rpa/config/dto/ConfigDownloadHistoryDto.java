package com.acn.rpa.config.dto;

import java.sql.Timestamp;

import javax.validation.constraints.Pattern;

public class ConfigDownloadHistoryDto {

	private int configDownloadID;
	private int transactionID;
	private String projectName;
	private String scenario;
	private String omgID;
	private String systemID;
	private String imgID;
	private String userID;
	private Timestamp createdDate;
	private String status;
	private String message;
	@Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}\\.\\d{3}(?: [+-]\\d{4})?$")
	private Timestamp downloadStartTime;
	@Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}\\.\\d{3}(?: [+-]\\d{4})?$")
	private Timestamp downloadEndTime;
	public Timestamp getDownloadStartTime() {
		return downloadStartTime;
	}
	public void setDownloadStartTime(Timestamp downloadStartTime) {
		this.downloadStartTime = downloadStartTime;
	}
	public Timestamp getDownloadEndTime() {
		return downloadEndTime;
	}
	public void setDownloadEndTime(Timestamp downloadEndTime) {
		this.downloadEndTime = downloadEndTime;
	}
	public int getConfigDownloadID() {
		return configDownloadID;
	}
	public void setConfigDownloadID(int configDownloadID) {
		this.configDownloadID = configDownloadID;
	}
	public int getTransactionID() {
		return transactionID;
	}
	public void setTransactionID(int transactionID) {
		this.transactionID = transactionID;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getScenario() {
		return scenario;
	}
	public void setScenario(String scenario) {
		this.scenario = scenario;
	}
	public String getOmgID() {
		return omgID;
	}
	public void setOmgID(String omgID) {
		this.omgID = omgID;
	}
	public String getSystemID() {
		return systemID;
	}
	public void setSystemID(String systemID) {
		this.systemID = systemID;
	}
	public String getImgID() {
		return imgID;
	}
	public void setImgID(String imgID) {
		this.imgID = imgID;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public Timestamp getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	
	
}
