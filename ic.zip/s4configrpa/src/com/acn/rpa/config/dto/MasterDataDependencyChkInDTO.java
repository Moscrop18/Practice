package com.acn.rpa.config.dto;

import java.util.List;

import javax.validation.Valid;

import com.acn.user.session.SessionInputDTO;

public class MasterDataDependencyChkInDTO {
	@Valid
	private List<BrownfieldMdRequestDto> selectedScopeData;
	
	private boolean industryFlag;
	
	public boolean isIndustryFlag() {
		return industryFlag;
	}
	public void setIndustryFlag(boolean industryFlag) {
		this.industryFlag = industryFlag;
	}
	public List<BrownfieldMdRequestDto> getSelectedScopeData() {
		return selectedScopeData;
	}
	public void setSelectedScopeData(List<BrownfieldMdRequestDto> selectedScopeData) {
		this.selectedScopeData = selectedScopeData;
	}
	@Valid
	private SessionInputDTO sessionInputDTO;
	
	public SessionInputDTO getSessionInputDTO() {
		return sessionInputDTO;
	}
	public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
		this.sessionInputDTO = sessionInputDTO;
	}

}
