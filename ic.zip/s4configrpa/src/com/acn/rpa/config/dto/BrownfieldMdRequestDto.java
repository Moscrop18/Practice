package com.acn.rpa.config.dto;

import java.util.ArrayList;

import javax.validation.Valid;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class BrownfieldMdRequestDto {
	@DecimalMin(value = "0")
    @DecimalMax(value = "1")
	private int enabled;
	private String fileName;
	private String filepath;
	@Size(min = 1, max = 255)
	private String imgDescription;
	@Size(min = 1, max = 1)
	@Pattern(regexp = "[a-zA-Z]+")
	private String isMasterData;
	@Size(min = 1, max = 30)
	private String imgId;
	@DecimalMin(value = "0")
    @DecimalMax(value = "4")
	private int implementationType;
	@Size(min = 1, max = 10)
	private String seq;
	@Size(min = 1, max = 10)
	private String sequence;
	private String fileUploadedIcon;
	private String status;
	private int id;
	@Valid
	private ArrayList<String> logs;
	@Valid
	private ArrayList<String> fileUploadStatusMsg;
	@Size(min = 0, max = 2)
	@Pattern(regexp = "^$|[a-zA-Z0-9]+")
	private String trType;
	@Size(min = 0, max = 10)
	@Pattern(regexp = "[a-zA-Z0-9]*$")
	private String workbenchTr;
	@Size(min = 0, max = 10)
	@Pattern(regexp = "[a-zA-Z0-9]*$")
	private String customizingTr;
	private boolean customizingTr_readOnly;
	private boolean workbenchTr_readOnly;
	@Size(min = 0, max = 20)
	@Pattern(regexp = "[a-zA-Z]*$")
	private String customizingTr_mode;
	@Size(min = 0, max = 20)
	@Pattern(regexp = "[a-zA-Z]*$")
	private String workbenchTr_mode;
	@DecimalMin(value = "0")
    @DecimalMax(value = "999999")
	private int tranId;
	private boolean scopeExists;
	private String configType;
	public String getConfigType() {
		return configType;
	}
	public void setConfigType(String configType) {
		this.configType = configType;
	}
	private byte[] fileBytes;

	public byte[] getFileBytes() {
		return fileBytes;
	}
	public void setFileBytes(byte[] fileBytes) {
		this.fileBytes = fileBytes;
	}
	public boolean isScopeExists() {
		return scopeExists;
	}
	public void setScopeExists(boolean scopeExists) {
		this.scopeExists = scopeExists;
	}
	public int getTranId() {
		return tranId;
	}
	public void setTranId(int tranId) {
		this.tranId = tranId;
	}
	public int getEnabled() {
		return enabled;
	}
	public void setEnabled(int enabled) {
		this.enabled = enabled;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFilepath() {
		return filepath;
	}
	public void setFilepath(String filepath) {
		this.filepath = filepath;
	}
	public String getImgDescription() {
		return imgDescription;
	}
	public void setImgDescription(String imgDescription) {
		this.imgDescription = imgDescription;
	}
	public String getIsMasterData() {
		return isMasterData;
	}
	public void setIsMasterData(String isMasterData) {
		this.isMasterData = isMasterData;
	}
	public String getImgId() {
		return imgId;
	}
	public void setImgId(String imgId) {
		this.imgId = imgId;
	}
	public int getImplementationType() {
		return implementationType;
	}
	public void setImplementationType(int implementationType) {
		this.implementationType = implementationType;
	}
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	
	public String getSequence() {
		return sequence;
	}
	public void setSequence(String sequence) {
		this.sequence = sequence;
	}
	public String getFileUploadedIcon() {
		return fileUploadedIcon;
	}
	public void setFileUploadedIcon(String fileUploadedIcon) {
		this.fileUploadedIcon = fileUploadedIcon;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public ArrayList<String> getLogs() {
		return logs;
	}
	public void setLogs(ArrayList<String> logs) {
		this.logs = logs;
	}
	public ArrayList<String> getFileUploadStatusMsg() {
		return fileUploadStatusMsg;
	}
	public void setFileUploadStatusMsg(ArrayList<String> fileUploadStatusMsg) {
		this.fileUploadStatusMsg = fileUploadStatusMsg;
	}
	public String getTrType() {
		return trType;
	}
	public void setTrType(String trType) {
		this.trType = trType;
	}
	public String getWorkbenchTr() {
		return workbenchTr;
	}
	public void setWorkbenchTr(String workbenchTr) {
		this.workbenchTr = workbenchTr;
	}
	public String getCustomizingTr() {
		return customizingTr;
	}
	public void setCustomizingTr(String customizingTr) {
		this.customizingTr = customizingTr;
	}
	public boolean isCustomizingTr_readOnly() {
		return customizingTr_readOnly;
	}
	public void setCustomizingTr_readOnly(boolean customizingTr_readOnly) {
		this.customizingTr_readOnly = customizingTr_readOnly;
	}
	public boolean isWorkbenchTr_readOnly() {
		return workbenchTr_readOnly;
	}
	public void setWorkbenchTr_readOnly(boolean workbenchTr_readOnly) {
		this.workbenchTr_readOnly = workbenchTr_readOnly;
	}
	public String getCustomizingTr_mode() {
		return customizingTr_mode;
	}
	public void setCustomizingTr_mode(String customizingTr_mode) {
		this.customizingTr_mode = customizingTr_mode;
	}
	public String getWorkbenchTr_mode() {
		return workbenchTr_mode;
	}
	public void setWorkbenchTr_mode(String workbenchTr_mode) {
		this.workbenchTr_mode = workbenchTr_mode;
	}
	  

}
