package com.acn.rpa.config.dto;

import java.util.List;

import com.acn.user.session.ResMessageDto;

public class MasterDataDependencyChkResDTO {
	private List<BrownfieldMdRequestDto> listBrownfieldMdRequestDto;

	public List<BrownfieldMdRequestDto> getListBrownfieldMdRequestDto() {
		return listBrownfieldMdRequestDto;
	}

	public void setListBrownfieldMdRequestDto(List<BrownfieldMdRequestDto> listBrownfieldMdRequestDto) {
		this.listBrownfieldMdRequestDto = listBrownfieldMdRequestDto;
	}
	private ResMessageDto resMessageDto;

	public ResMessageDto getResMessageDto() {
			return resMessageDto;
		}
	public void setResMessageDto(ResMessageDto resMessageDto) {
			this.resMessageDto = resMessageDto;
		}
	

}
