package com.acn.rpa.config.dto;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Size;

import com.acn.user.session.SessionInputDTO;

public class CustomDestinationReqDto {

	@Valid
	private List<String> omidList;
     @Size(min = 0, max = 20)
	private String custDestReq;

     @Valid
 	private SessionInputDTO sessionInputDTO;
	
	public SessionInputDTO getSessionInputDTO() {
		return sessionInputDTO;
	}
	public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
		this.sessionInputDTO = sessionInputDTO;
	}	
	
	
	public List<String> getOmidList() {
		return omidList;
	}
	public void setOmidList(List<String> omidList) {
		this.omidList = omidList;
	}
	public String getCustDestReq() {
		return custDestReq;
	}
	public void setCustDestReq(String custDestReq) {
		this.custDestReq = custDestReq;
	}

	}

	
	

