package com.acn.rpa.config.dto;

import java.sql.Timestamp;

import javax.validation.Valid;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.acn.user.session.SessionInputDTO;

public class ConfigUploadHistoryDto {
	@DecimalMin(value = "1")
    @DecimalMax(value = "9999999")
	private int configUploadID;
	@DecimalMin(value = "1")
    @DecimalMax(value = "9999999")
	private int transactionID;
	@Size(min = 1, max = 50)
	@Pattern(regexp = "[a-zA-Z\\s._&-,]+")
	private String projectName;
	@Size(min = 1, max = 50)
	@Pattern(regexp = "[a-zA-Z\\s._&-,]+")
	private String scenario;
	@Size(min = 1, max = 30)
	private String omgID;
	@Size(min = 1, max = 20)
	private String systemID;
	@Size(min = 1, max = 30)
	private String imgID;
	@Size(min = 1, max = 8)
	@Pattern(regexp = "[a-zA-Z0-9]+")
	private String userID;
	//@Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}\\.\\d{3}(?: [+-]\\d{4})?$")
	private Timestamp createdDate;
	//@Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}\\.\\d{3}(?: [+-]\\d{4})?$")
	private Timestamp executionStartTime;
	//@Pattern(regexp = "^\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}\\.\\d{3}(?: [+-]\\d{4})?$")
	private Timestamp executionEndTime;
	@DecimalMin(value = "1")
	@DecimalMax(value = "99999999")
	private int recordCount;
	private boolean isIMGHierarchy;
	public boolean isIMGHierarchy() {
		return isIMGHierarchy;
	}
	public void setIMGHierarchy(boolean isIMGHierarchy) {
		this.isIMGHierarchy = isIMGHierarchy;
	}
	@Valid
	private SessionInputDTO sessionInputDTO;
	
	public SessionInputDTO getSessionInputDTO() {
		return sessionInputDTO;
	}
	public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
		this.sessionInputDTO = sessionInputDTO;
	}
	
	public int getRecordCount() {
		return recordCount;
	}
	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}
	public String getErrorReason() {
		return errorReason;
	}
	public void setErrorReason(String errorReason) {
		this.errorReason = errorReason;
	}
	private String status;
	public Timestamp getExecutionStartTime() {
		return executionStartTime;
	}
	public void setExecutionStartTime(Timestamp executionStartTime) {
		this.executionStartTime = executionStartTime;
	}
	public Timestamp getExecutionEndTime() {
		return executionEndTime;
	}
	public void setExecutionEndTime(Timestamp executionEndTime) {
		this.executionEndTime = executionEndTime;
	}
	@Size(min = 1, max = 45)
	private String module;
	@Size(min = 0, max = 10)
	@Pattern(regexp = "[a-zA-Z0-9]*$")
	private String workbenchTr;
	@Size(min = 0, max = 10)
	@Pattern(regexp = "[a-zA-Z0-9]*$")
	private String customizingTr;
	private String errorReason;
	

	public int getConfigUploadID() {
		return configUploadID;
	}
	public void setConfigUploadID(int configUploadID) {
		this.configUploadID = configUploadID;
	}
	public int getTransactionID() {
		return transactionID;
	}
	public void setTransactionID(int transactionID) {
		this.transactionID = transactionID;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getScenario() {
		return scenario;
	}
	public void setScenario(String scenario) {
		this.scenario = scenario;
	}
	public String getOmgID() {
		return omgID;
	}
	public void setOmgID(String omgID) {
		this.omgID = omgID;
	}
	public String getSystemID() {
		return systemID;
	}
	public void setSystemID(String systemID) {
		this.systemID = systemID;
	}
	public String getImgID() {
		return imgID;
	}
	public void setImgID(String imgID) {
		this.imgID = imgID;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public Timestamp getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public String getCustomizingTr() {
		return customizingTr;
	}
	public void setCustomizingTr(String customizingTr) {
		this.customizingTr = customizingTr;
	}
	public String getWorkbenchTr() {
		return workbenchTr;
	}
	public void setWorkbenchTr(String workbenchTr) {
		this.workbenchTr = workbenchTr;
	}
	
	
}
