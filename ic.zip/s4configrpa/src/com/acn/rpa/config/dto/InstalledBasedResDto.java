package com.acn.rpa.config.dto;

import java.util.ArrayList;

import com.acn.rpa.config.ConfigDwldResDto;

public class InstalledBasedResDto {
	ArrayList<ConfigDwldResDto> configDownloadList;
	private String resMessage;

	public String getResMessage() {
		return resMessage;
	}

	public void setResMessage(String resMessage) {
		this.resMessage = resMessage;
	}

	public ArrayList<ConfigDwldResDto> getConfigDownloadList() {
		return configDownloadList;
	}

	public void setConfigDownloadList(ArrayList<ConfigDwldResDto> configDownloadList) {
		this.configDownloadList = configDownloadList;
	}

}
