package com.acn.rpa.config.dto;

import java.util.ArrayList;

import com.acn.user.session.ResMessageDto;

public class ConfigUploadResDto {
	
	private ArrayList<ConfigTemplateDto> configTemplateDto;
	private boolean uploadStatus;

private ResMessageDto resMessageDto;

public ResMessageDto getResMessageDto() {
		return resMessageDto;
	}
public void setResMessageDto(ResMessageDto resMessageDto) {
		this.resMessageDto = resMessageDto;
	}
	
	public ArrayList<ConfigTemplateDto> getConfigTemplateDto() {
		return configTemplateDto;
	}
	public void setConfigTemplateDto(ArrayList<ConfigTemplateDto> configTemplateDto) {
		this.configTemplateDto = configTemplateDto;
	}
	public boolean isUploadStatus() {
		return uploadStatus;
	}
	public void setUploadStatus(boolean uploadStatus) {
		this.uploadStatus = uploadStatus;
	}
	
	
	

}
