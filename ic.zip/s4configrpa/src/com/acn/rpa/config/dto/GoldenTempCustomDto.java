package com.acn.rpa.config.dto;

import java.util.ArrayList;

import javax.validation.Valid;

import com.acn.user.session.SessionInputDTO;

public class GoldenTempCustomDto {

	 private boolean docUpdate;
	 private boolean copyFlag=false;
	 
	 private boolean industryFlag;
	 
	 private String industry;
	 
	 private String subIndustry;
	 

	private String aliasIndustry;
		
	private String aliasSubIndustry;
	 
	 public boolean getCopyFlag() {
		return copyFlag;
	}
	public void setCopyFlag(boolean copyFlag) {
		this.copyFlag = copyFlag;
	}
	@Valid
     private ArrayList<SelectedScopeDto> selectedScopeList;
 	 @Valid
     private SessionInputDTO sessionInputDTO;
     	
     	public SessionInputDTO getSessionInputDTO() {
     		return sessionInputDTO;
     	}
     	public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
     		this.sessionInputDTO = sessionInputDTO;
     	}
	public boolean isDocUpdate() {
		return docUpdate;
	}
	public void setDocUpdate(boolean docUpdate) {
		this.docUpdate = docUpdate;
	}
	public ArrayList<SelectedScopeDto> getSelectedScopeList() {
		return selectedScopeList;
	}
	public void setSelectedScopeList(ArrayList<SelectedScopeDto> selectedScopeList) {
		this.selectedScopeList = selectedScopeList;
	}
	public boolean isIndustryFlag() {
		return industryFlag;
	}
	public void setIndustryFlag(boolean industryFlag) {
		this.industryFlag = industryFlag;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public String getSubIndustry() {
		return subIndustry;
	}
	public void setSubIndustry(String subIndustry) {
		this.subIndustry = subIndustry;
	}
	public String getAliasIndustry() {
		return aliasIndustry;
	}
	public void setAliasIndustry(String aliasIndustry) {
		this.aliasIndustry = aliasIndustry;
	}
	public String getAliasSubIndustry() {
		return aliasSubIndustry;
	}
	public void setAliasSubIndustry(String aliasSubIndustry) {
		this.aliasSubIndustry = aliasSubIndustry;
	} 
}
