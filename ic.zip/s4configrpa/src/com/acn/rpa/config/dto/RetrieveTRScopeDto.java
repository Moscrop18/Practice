package com.acn.rpa.config.dto;

import java.util.ArrayList;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.acn.user.session.SessionInputDTO;

public class RetrieveTRScopeDto {

	@Valid
	private ArrayList<SelectedScopeDto> selectedScopeList;
	@Size(min = 0, max = 1)
	@Pattern(regexp = "[a-zA-Z]+")
	private String trOverride;
	@Size(min = 1, max = 30)
	private String omID;
	private boolean trModulewiseEnabled;
	@Size(min = 0, max = 20)
	private String systemId;
	@Size(min = 1, max = 20)
	private String sysFlag;
	private Boolean copyFlag=false;
	
	private boolean industryFlag;
	
	public boolean isIndustryFlag() {
		return industryFlag;
	}
	public void setIndustryFlag(boolean industryFlag) {
		this.industryFlag = industryFlag;
	}
	public Boolean getCopyFlag() {
		return copyFlag;
	}
	public void setCopyFlag(Boolean copyFlag) {
		this.copyFlag = copyFlag;
	}
	@Valid
	private SessionInputDTO sessionInputDTO;
	
	public SessionInputDTO getSessionInputDTO() {
		return sessionInputDTO;
	}
	public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
		this.sessionInputDTO = sessionInputDTO;
	}
	public String getSysFlag() {
		return sysFlag;
	}
	public void setSysFlag(String sysFlag) {
		this.sysFlag = sysFlag;
	}
	public String getSystemId() {
		return systemId;
	}
	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}
	public ArrayList<SelectedScopeDto> getSelectedScopeList() {
		return selectedScopeList;
	}
	public void setSelectedScopeList(ArrayList<SelectedScopeDto> selectedScopeList) {
		this.selectedScopeList = selectedScopeList;
	}
	
	public String getOmID() {
		return omID;
	}
	public void setOmID(String omID) {
		this.omID = omID;
	}
	public String getTrOverride() {
		return trOverride;
	}
	public void setTrOverride(String trOverride) {
		this.trOverride = trOverride;
	}
	public boolean isTrModulewiseEnabled() {
		return trModulewiseEnabled;
	}
	public void setTrModulewiseEnabled(boolean trModulewiseEnabled) {
		this.trModulewiseEnabled = trModulewiseEnabled;
	}
	private boolean consolidate;

	public boolean isConsolidate() {
		return consolidate;
	}
	public void setConsolidate(boolean consolidate) {
		this.consolidate = consolidate;
	}
	
}
