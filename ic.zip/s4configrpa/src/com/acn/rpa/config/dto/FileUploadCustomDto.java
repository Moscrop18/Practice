package com.acn.rpa.config.dto;

import java.util.ArrayList;

import javax.validation.Valid;

import com.acn.user.session.SessionInputDTO;

public class FileUploadCustomDto {
	 @Valid
	 private ArrayList<String> currentFileList;
	 @Valid
     private ArrayList<SelectedScopeDto> selectedScopeList;
	 @Valid
     private SessionInputDTO sessionInputDTO;
	 
	 private Boolean copyFlag=false;
	 
	 private boolean industryFlag;

	 private String industry;

	 private String subIndustry;
 	
 	public boolean isIndustryFlag() {
		return industryFlag;
	}
	public void setIndustryFlag(boolean industryFlag) {
		this.industryFlag = industryFlag;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public String getSubIndustry() {
		return subIndustry;
	}
	public void setSubIndustry(String subIndustry) {
		this.subIndustry = subIndustry;
	}
	public Boolean getCopyFlag() {
		return copyFlag;
	}
	public void setCopyFlag(Boolean copyFlag) {
		this.copyFlag = copyFlag;
	}
	public SessionInputDTO getSessionInputDTO() {
 		return sessionInputDTO;
 	}
 	public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
 		this.sessionInputDTO = sessionInputDTO;
 	}
	public ArrayList<String> getCurrentFileList() {
		return currentFileList;
	}
	public void setCurrentFileList(ArrayList<String> currentFileList) {
		this.currentFileList = currentFileList;
	}
	public ArrayList<SelectedScopeDto> getSelectedScopeList() {
		return selectedScopeList;
	}
	public void setSelectedScopeList(ArrayList<SelectedScopeDto> selectedScopeList) {
		this.selectedScopeList = selectedScopeList;
	}
     
     

}
