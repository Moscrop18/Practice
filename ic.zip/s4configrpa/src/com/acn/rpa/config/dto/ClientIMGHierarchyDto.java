package com.acn.rpa.config.dto;

public class ClientIMGHierarchyDto {
	private String omID;
	private String imgID;
	private String CTR;
	private String KTR;
	private String systemId;
	
	
	public String getSystemId() {
		return systemId;
	}
	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}
	public String getOmID() {
		return omID;
	}
	public void setOmID(String omID) {
		this.omID = omID;
	}
	public String getImgID() {
		return imgID;
	}
	public void setImgID(String imgID) {
		this.imgID = imgID;
	}
	public String getCTR() {
		return CTR;
	}
	public void setCTR(String cTR) {
		CTR = cTR;
	}
	public String getKTR() {
		return KTR;
	}
	public void setKTR(String kTR) {
		KTR = kTR;
	}
	

}
