package com.acn.rpa.config;

import java.util.ArrayList;

public class BwnFieldResDto {
	
	private String imgId;
	private String imgDescription;
	private ArrayList<String> imgData;
	private boolean conStatus;
	private boolean exeStatus;
	private boolean dependencyMet;
	private String errorDetails;
	
	public String getImgDescription() {
		return imgDescription;
	}
	public void setImgDescription(String imgDescription) {
		this.imgDescription = imgDescription;
	}
	
	
	public String getImgId() {
		return imgId;
	}
	public void setImgId(String imgId) {
		this.imgId = imgId;
	}
	public ArrayList<String> getImgData() {
		return imgData;
	}
	public void setImgData(ArrayList<String> imgData) {
		this.imgData = imgData;
	}
	public boolean isConStatus() {
		return conStatus;
	}
	public void setConStatus(boolean conStatus) {
		this.conStatus = conStatus;
	}
	public boolean isExeStatus() {
		return exeStatus;
	}
	public void setExeStatus(boolean exeStatus) {
		this.exeStatus = exeStatus;
	}
	public String getErrorDetails() {
		return errorDetails;
	}
	public void setErrorDetails(String errorDetails) {
		this.errorDetails = errorDetails;
	}
	public boolean isDependencyMet() {
		return dependencyMet;
	}
	public void setDependencyMet(boolean dependencyMet) {
		this.dependencyMet = dependencyMet;
	}


}
