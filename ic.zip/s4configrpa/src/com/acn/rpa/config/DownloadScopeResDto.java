package com.acn.rpa.config;

import java.util.ArrayList;

import javax.validation.Valid;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class DownloadScopeResDto {
	@Valid
	private ArrayList<String> imgScope;
	@Size(min = 1, max = 1)
	@Pattern(regexp = "[a-zA-Z]+")
	private String scopeAvailable ;
	@Size(min = 1, max = 30)
	private String imgId;
	@Size(min = 1, max = 1)
	@Pattern(regexp = "[a-zA-Z]+")
	private String selField;
	@DecimalMin(value = "1")
    @DecimalMax(value = "999")
	private int seqNo;

	private String copyToCheck;

	public String getCopyToCheck() {
		return copyToCheck;
	}
	public void setCopyToCheck(String copyToCheck) {
		this.copyToCheck = copyToCheck;
	}
	public int getSeqNo() {
		return seqNo;
	}
	public void setSeqNo(int seqNo) {
		this.seqNo = seqNo;
	}
	public String getSelField() {
		return selField;
	}
	public void setSelField(String selField) {
		this.selField = selField;
	}
	public String getImgId() {
		return imgId;
	}
	public void setImgId(String imgId) {
		this.imgId = imgId;
	}
	public ArrayList<String> getImgScope() {
		return imgScope;
	}
	public void setImgScope(ArrayList<String> imgScope) {
		this.imgScope = imgScope;
	}
	public String getScopeAvailable() {
		return scopeAvailable;
	}
	public void setScopeAvailable(String scopeAvailable) {
		this.scopeAvailable = scopeAvailable;
	}


}
