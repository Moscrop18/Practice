package com.acn.rpa.config;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.DBConnection;

public class IMGFilterDao {
	
    private final Logger slf4jLogger = LoggerFactory.getLogger(IMGFilterDao.class);

    
	public HashMap<String, ArrayList<String>> getIMGFilterValues(String IMGID){
	slf4jLogger.info("getIMGFilterValues method started");
	HashMap<String, ArrayList<String>> filterMap = new HashMap<String, ArrayList<String>>();
	Connection con = null;
	ResultSet rs=null;
	PreparedStatement pStmt=null;
	String key = null;
	ArrayList<String> fieldValList = null;
	try{
		con = DBConnection.createConnection();
		String query = "SELECT ViewName,FieldName,FieldValue FROM IMGFILTER where IMGID = ?";
			pStmt = con.prepareStatement(query);
			pStmt.setString(1, IMGID);
			rs = pStmt.executeQuery();
			while( rs.next() ){
				key = rs.getString("viewName")+rs.getString("FieldName");
				if(filterMap.isEmpty() || !filterMap.containsKey(key)){
					fieldValList = new ArrayList<String>();
					fieldValList.add(rs.getString("FieldValue"));
					filterMap.put(key, fieldValList);					
				}else{
					fieldValList = filterMap.get(key);
					fieldValList.add(rs.getString("FieldValue"));
					filterMap.put(key, fieldValList);
				}
			}
	}
	catch (SQLException e){
		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	}finally{
		if(rs!=null){
			try {
				rs.close();
				rs= null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		if(pStmt!=null){
			try {
				pStmt.close();
				pStmt=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		if(con!=null){
			try {
				con.close();
				con=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		  slf4jLogger.info("getIMGFilterValues method ended");

	}
		return filterMap;
	}
	public HashMap<String, String> getIMGFilterValuesCopyFunctionality(String IMGID){
		slf4jLogger.info("getIMGFilterValues method started");
		HashMap<String, String> filterMap = new HashMap<String, String>();
		Connection con = null;
		ResultSet rs=null;
		PreparedStatement pStmt=null;
		String key = null;
		String fieldName="";
		try{
			con = DBConnection.createConnection();
			String query = "SELECT ViewName,FieldName,FieldValue FROM IMGFILTER where IMGID = ?";
				pStmt = con.prepareStatement(query);
				pStmt.setString(1, IMGID);
				rs = pStmt.executeQuery();
				while( rs.next() ){
					key = "|"+rs.getString("viewName")+"|";
					if(filterMap.isEmpty() || !filterMap.containsKey(key)){
						fieldName="|"+rs.getString("FieldName")+"|";
						filterMap.put(key, fieldName);					
					}
				}
		}
		catch (SQLException e){
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}finally{
			if(rs!=null){
				try {
					rs.close();
					rs= null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("getIMGFilterValues method ended");

		}
			return filterMap;
		}
	
}
