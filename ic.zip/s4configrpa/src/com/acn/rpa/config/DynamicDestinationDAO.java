package com.acn.rpa.config;

import java.io.File;



import java.io.FileOutputStream;
import java.util.Properties;
import com.acn.rpa.service.AesUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.service.AesUtil;
import com.acn.rpa.utilities.ConstantsValues;
import com.sap.conn.jco.AbapException;
/**
 * @author Rajesh Valupadasu
 * DAO file to validate custom SAP login Details 
 */
import com.sap.conn.jco.JCoCustomDestination;
import com.sap.conn.jco.JCoCustomDestination.UserData;
import com.sap.conn.jco.ext.DestinationDataProvider;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoRepository;
import com.sap.conn.jco.ext.Environment;
import com.acn.rpa.utilities.MyDestinationDataProvider;
public class DynamicDestinationDAO {
    private final Logger slf4jLogger = LoggerFactory.getLogger(DynamicDestinationDAO.class);
   /* static void createDestinationDataFile(String destinationName, Properties connectProperties)
    {
        File destCfg = new File(destinationName+".jcoDestination");
        try
        {
            FileOutputStream fos = new FileOutputStream(destCfg, false);
            connectProperties.store(fos, "for tests only !");
            fos.close();
        }
        catch (Exception e)
        {
            throw new RuntimeException("Unable to create the destination files", e);
        }
    }
*/
	public DynamicDestinationResDto validateSAPCredentials(SAPUserDto sapuserDto){
		slf4jLogger.info("validateSAPCredentials method started");
		DynamicDestinationResDto dynamicDestinationResDtoObj = new DynamicDestinationResDto();
		/*JCoFunction stfcConnection = null;
		JCoRepository repo = null;
		String sapUserId = null;
		String sapPassword = null;*/
		//String DESTINATION_NAME1 = "K4ASystem";
		//String DESTINATION_NAME2 = "K4XS4System";
		

		Properties connectProperties = new Properties();
		
		MyDestinationDataProvider myDestinationDataProvider=MyDestinationDataProvider.getInstance();
		connectProperties.setProperty(DestinationDataProvider.JCO_DEST,ConstantsValues.DESTINATION_NAMEK4A );
		connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, ConstantsValues.TRGHOST_NAME);
		connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR, ConstantsValues.TRG_SYSNR);
		connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, ConstantsValues.TRG_CLIENT);
		// connectProperties.setProperty(DestinationDataProvider.JCO_GWSERV,"3311");
		connectProperties.setProperty(DestinationDataProvider.JCO_USER, ConstantsValues.TRG_USER);
		connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD,ConstantsValues.TRG_PASSWORD);
		connectProperties.setProperty(DestinationDataProvider.JCO_LANG,ConstantsValues.TRG_LANG);
		//createDestinationDataFile(ConstantsValues.DESTINATION_NAMEK4A, connectProperties);
		
		
		myDestinationDataProvider.changePropertiesForABAP_AS(connectProperties);
		System.err.println("data provider"+Environment.isDestinationDataProviderRegistered());
		if(!Environment.isDestinationDataProviderRegistered()){
			System.err.println("inside if");
			
			 Environment.registerDestinationDataProvider(myDestinationDataProvider);
		}
		connectProperties.setProperty(DestinationDataProvider.JCO_POOL_CAPACITY, "3");
		connectProperties.setProperty(DestinationDataProvider.JCO_PEAK_LIMIT, "10");
		// createDestinationDataFile(DESTINATION_NAME2, connectProperties);

		try {
			JCoDestination destination = JCoDestinationManager.getDestination(ConstantsValues.DESTINATION_NAMEK4A);
			// JCoDestination destination1 =
			// JCoDestinationManager.getDestination(DESTINATION_NAME2);
			/*System.out.println("Attributes:");
			System.out.println(destination.getAttributes());
			System.out.println();*/

			// JCoDestination destination =
			// JCoDestinationManager.getDestination(DESTINATION_NAME2);
			// destination.ping();
			destination.ping();
			/*System.out.println("Attributes:");
			System.out.println(destination.getAttributes());
			System.out.println();*/

			// JCoDestination destination1 =
			// JCoDestinationManager.getDestination(DESTINATION_NAME2);
			// JCoFunction function =
			// destination.getRepository().getFunction("/ACNIP/RFC");
			JCoFunction function = destination.getRepository().getFunction("/ACNIP/RFC");
			if (function == null) {
				// throw new RuntimeException("BAPI_COMPANYCODE_GETLIST not
				// found in SAP.");
				// function.getImportParameterList().setValue("REQUTEXT", "Hello
				// SAP");
				dynamicDestinationResDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
				dynamicDestinationResDtoObj.setMessage("Please Validate SAP UserId/Password");
			} else {
				dynamicDestinationResDtoObj.setStatus(ConstantsValues.SUCCESSSTATUS);
				dynamicDestinationResDtoObj.setMessage("Connection To destination Established sucessfully");
			}

			/*
			 * try { function.execute(destination); } catch (AbapException e) {
			 * System.out.println(e.toString());
			 * 
			 * }
			 * 
			 * System.out.println("STFC_CONNECTION finished:");
			 * System.out.println(" Echo: " +
			 * function.getExportParameterList().getString("ECHOTEXT"));
			 * System.out.println(" Response: " +
			 * function.getExportParameterList().getString("RESPTEXT"));
			 * System.out.println();
			 */

			/*
			 * dynamicDestinationResDtoObj.setStatus(ConstantsValues.
			 * SUCCESSSTATUS); dynamicDestinationResDtoObj.
			 * setMessage("Connection established successfully!!");
			 */
		} catch (JCoException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			if (e.getLocalizedMessage().contains(ConstantsValues.LANGUAGE)) {
				dynamicDestinationResDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
				dynamicDestinationResDtoObj.setMessage(ConstantsValues.SAPLANGUAGEERROR);
			} else {
				dynamicDestinationResDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
				dynamicDestinationResDtoObj.setMessage(ConstantsValues.SAPCREDENTIALVALIDATION);
			}
		} catch (Exception e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			dynamicDestinationResDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
			dynamicDestinationResDtoObj.setMessage(e.getLocalizedMessage());

		}

		return dynamicDestinationResDtoObj;
		
	}
	
	public DynamicDestinationResDto validateDestination(SAPUserDto sapuserDto){
		slf4jLogger.info("validateDestination method started");
		DynamicDestinationResDto dynamicDestinationResDtoObj = new DynamicDestinationResDto();
		String sapPassword = null;
		JCoFunction stfcConnection = null;
		JCoDestination destination=null;
		JCoRepository repo = null;
		/*String DESTINATION_NAME1 = "K4ASystem";
		String DESTINATION_NAME2 = "K4XS4System";*/
		String cipherTextSapPass = new String(java.util.Base64.getDecoder().decode(sapuserDto.getPassword()));
		AesUtil aesUtil = new AesUtil(128, 1000);
		Properties connectProperties = new Properties();
		MyDestinationDataProvider myDestinationDataProvider=MyDestinationDataProvider.getInstance();
		
		//slf4jLogger.info("k4asyatem"+sapuserDto.getDestinationName());
		//slf4jLogger.info("constant k4asyatem"+ConstantsValues.DESTINATION_NAMEK4A);
		if(sapuserDto.getDestinationName().equals(ConstantsValues.DESTINATION_NAMEK4A)){
			connectProperties.setProperty(DestinationDataProvider.JCO_DEST,ConstantsValues.DESTINATION_NAMEK4A);
		connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, ConstantsValues.TRGHOST_NAME);
		connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR, ConstantsValues.TRG_SYSNR);
		connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, ConstantsValues.TRG_CLIENT);
		// connectProperties.setProperty(DestinationDataProvider.JCO_GWSERV,"3311");
		 if (cipherTextSapPass != null && cipherTextSapPass.split("::").length == 3) {   
		    	sapPassword = aesUtil.decrypt(cipherTextSapPass.split("::")[1], cipherTextSapPass.split("::")[0], sapuserDto.getDestinationName(), cipherTextSapPass.split("::")[2]);
		      } 
		connectProperties.setProperty(DestinationDataProvider.JCO_USER, sapuserDto.getSapUserId());
		connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD,sapPassword);
		connectProperties.setProperty(DestinationDataProvider.JCO_LANG,sapuserDto.getSapLanguage());
		connectProperties.setProperty(DestinationDataProvider.JCO_POOL_CAPACITY, "3");
		connectProperties.setProperty(DestinationDataProvider.JCO_PEAK_LIMIT, "10");
		
		
		myDestinationDataProvider.changePropertiesForABAP_AS(connectProperties);
		 
		  if(Environment.isDestinationDataProviderRegistered()){
				System.err.println("inside if");
				Environment.unregisterDestinationDataProvider(myDestinationDataProvider);
				
			}
		  Environment.registerDestinationDataProvider(myDestinationDataProvider);
		  /*System.err.println("user name"+sapuserDto.getSapUserId());
		  System.err.println("password"+sapuserDto.getPassword());
		  System.err.println("data Provider"+Environment.isDestinationDataProviderRegistered());*/
		}else{
		
		    if (cipherTextSapPass != null && cipherTextSapPass.split("::").length == 3) {   
		    	sapPassword = aesUtil.decrypt(cipherTextSapPass.split("::")[1], cipherTextSapPass.split("::")[0], sapuserDto.getDestinationName(), cipherTextSapPass.split("::")[2]);
		      } 
		   // slf4jLogger.info("username"+sapuserDto.getSapUserId());
		    //slf4jLogger.info("password"+sapPassword);
		    connectProperties.setProperty(DestinationDataProvider.JCO_DEST,sapuserDto.getDestinationName());
			connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, sapuserDto.getHostName());
			connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR,sapuserDto.getSysNo());
			connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT,sapuserDto.getClientNo());
			connectProperties.setProperty(DestinationDataProvider.JCO_USER, sapuserDto.getSapUserId());
			connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD,sapPassword);
			connectProperties.setProperty(DestinationDataProvider.JCO_LANG,sapuserDto.getSapLanguage());	
			//connectProperties.setProperty(DestinationDataProvider.JCO_GWSERV,"3211");
				//createDestinationDataFile(ConstantsValues.DESTINATION_NAMEK4X, connectProperties);
			connectProperties.setProperty(DestinationDataProvider.JCO_POOL_CAPACITY, "3");
			connectProperties.setProperty(DestinationDataProvider.JCO_PEAK_LIMIT, "10");
			
			if(sapuserDto.getSapRouter()!=null) {
				connectProperties.setProperty(DestinationDataProvider.JCO_SAPROUTER, sapuserDto.getSapRouter());
			}
			
			
			if(sapuserDto.getSncEnabled()==1){
				connectProperties.setProperty(DestinationDataProvider.JCO_SNC_MODE, String.valueOf(sapuserDto.getSncEnabled()));
				
				connectProperties.setProperty(DestinationDataProvider.JCO_SNC_MYNAME, sapuserDto.getSncName());
				connectProperties.setProperty(DestinationDataProvider.JCO_SNC_PARTNERNAME, sapuserDto.getSncPartnerName());
				
				connectProperties.setProperty(DestinationDataProvider.JCO_SNC_QOP, sapuserDto.getSncProtectionLevel());
				connectProperties.setProperty(DestinationDataProvider.JCO_SNC_LIBRARY, System.getenv("SNC_LIB"));
			}
			
			myDestinationDataProvider.changePropertiesForABAP_AS(connectProperties);
			 if(Environment.isDestinationDataProviderRegistered()){
				
					Environment.unregisterDestinationDataProvider(myDestinationDataProvider);
					
				}
			  Environment.registerDestinationDataProvider(myDestinationDataProvider);
			}
		
		/*connectProperties.setProperty(DestinationDataProvider.JCO_POOL_CAPACITY, "3");
		connectProperties.setProperty(DestinationDataProvider.JCO_PEAK_LIMIT, "10");*/
		/*
		 * Properties connectProperties1 = new Properties();
		 * connectProperties1.setProperty(DestinationDataProvider.JCO_ASHOST,
		 * "10.35.20.172");
		 * connectProperties1.setProperty(DestinationDataProvider.JCO_SYSNR,
		 * "11");
		 * connectProperties1.setProperty(DestinationDataProvider.JCO_CLIENT,
		 * "100");
		 * connectProperties1.setProperty(DestinationDataProvider.JCO_USER,
		 * "GXL71388");
		 * connectProperties1.setProperty(DestinationDataProvider.JCO_PASSWD,
		 * "Mani@10sep");
		 * connectProperties1.setProperty(DestinationDataProvider.JCO_LANG,
		 * "en"); createDestinationDataFile(DESTINATION_NAME2,
		 * connectProperties1);
		 */

		try {
			if(sapuserDto.getDestinationName().equals(ConstantsValues.DESTINATION_NAMEK4A)){
			 destination = JCoDestinationManager.getDestination(sapuserDto.getDestinationName());
			}else{
			destination = JCoDestinationManager.getDestination(sapuserDto.getDestinationName());	
			}
			// JCoDestination destination1 =
			// JCoDestinationManager.getDestination(DESTINATION_NAME2);
			/*System.out.println("Attributes:");
			System.out.println(destination.getAttributes());
			System.out.println();*/

			// JCoDestination destination =
			// JCoDestinationManager.getDestination(DESTINATION_NAME2);
			// destination.ping();
			destination.ping();
			/*System.out.println("Attributes:");
			System.out.println(destination.getAttributes());
			System.out.println();*/

			// JCoDestination destination1 =
			// JCoDestinationManager.getDestination(DESTINATION_NAME2);
			// JCoFunction function =
			// destination.getRepository().getFunction("/ACNIP/RFC");
			JCoFunction function = destination.getRepository().getFunction("/ACNIP/RFC");
			if (function == null) {
				// throw new RuntimeException("BAPI_COMPANYCODE_GETLIST not
				// found in SAP.");
				// function.getImportParameterList().setValue("REQUTEXT", "Hello
				// SAP");
				dynamicDestinationResDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
				dynamicDestinationResDtoObj.setMessage("Please Validate SAP UserId/Password");
			} else {
				dynamicDestinationResDtoObj.setStatus(ConstantsValues.SUCCESSSTATUS);
				dynamicDestinationResDtoObj.setMessage("Connection To destination Established sucessfully");
			}

			/*
			 * try { function.execute(destination); } catch (AbapException e) {
			 * System.out.println(e.toString());
			 * 
			 * }
			 * 
			 * System.out.println("STFC_CONNECTION finished:");
			 * System.out.println(" Echo: " +
			 * function.getExportParameterList().getString("ECHOTEXT"));
			 * System.out.println(" Response: " +
			 * function.getExportParameterList().getString("RESPTEXT"));
			 * System.out.println();
			 */

			/*
			 * dynamicDestinationResDtoObj.setStatus(ConstantsValues.
			 * SUCCESSSTATUS); dynamicDestinationResDtoObj.
			 * setMessage("Connection established successfully!!");
			 */
		} 
		catch (JCoException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			dynamicDestinationResDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
			if (e.getMessage().contains(" Name or password is incorrect")) {
				dynamicDestinationResDtoObj.setMessage("Please enter valid credentials");
			} else {
				dynamicDestinationResDtoObj.setMessage("The System is down or not reachable");
			}
			return dynamicDestinationResDtoObj;
		} catch (Exception e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);

			dynamicDestinationResDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
			dynamicDestinationResDtoObj.setMessage(e.toString());
			return dynamicDestinationResDtoObj;
		} finally {
			slf4jLogger.info("validateDestination method ended");

		}
		
		
		return dynamicDestinationResDtoObj;
		
		
	}
	
	public DynamicDestinationResDto createCustomDestinationObject(String userName,String password,String language,JCoDestination destination){
		slf4jLogger.info("createCustomDestinationObject method started");
		JCoCustomDestination customDestination = null;
		DynamicDestinationResDto dynamicDestinationResDtoObj = null;
		UserData userData = null;
		dynamicDestinationResDtoObj = new DynamicDestinationResDto();
		try {
			customDestination =  destination.createCustomDestination();
			userData = customDestination.getUserLogonData();
			userData.setUser(userName);
			userData.setPassword(password);
			if(language != null && language != "")
				userData.setLanguage(language);
			dynamicDestinationResDtoObj.setCustomDestination(customDestination);
			dynamicDestinationResDtoObj.setStatus(ConstantsValues.SUCCESSSTATUS);

		} 
		catch (Exception e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			dynamicDestinationResDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
			dynamicDestinationResDtoObj.setMessage(e.toString());
		}
		finally{		
			slf4jLogger.info("createCustomDestinationObject method ended");
		 }
		
		return dynamicDestinationResDtoObj;
		
		
	}
}
