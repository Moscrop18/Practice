package com.acn.rpa.config;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.fileupload.FileItem;

import com.acn.rpa.docservice.HCPDocServiceResDto;
import com.acn.user.session.ResMessageDto;

public class ServiceResponseDto {
	
	private List<String> filePathList;
	private List<JSONFormatDto> result;
	boolean srcConnectionStatus;
	boolean srcExecutionStatus;
	boolean connectionStatus;
	boolean executionStatus;
	private int tranId;
	private String message;
	private ResMessageDto resMessageDto;
	private List<byte[]> fileBytesList;
	private List<String> fileNameList;
	private ArrayList<ScopeCheckResDto> listScopeCheckResDto;
	public List<String> getFileNameList() {
		return fileNameList;
	}
	public void setFileNameList(List<String> fileNameList) {
		this.fileNameList = fileNameList;
	}
	public List<byte[]> getFileBytesList() {
		return fileBytesList;
	}
	public void setFileBytesList(List<byte[]> fileBytesList) {
		this.fileBytesList = fileBytesList;
	}

	
	public ArrayList<ScopeCheckResDto> getListScopeCheckResDto() {
		return listScopeCheckResDto;
	}
	public void setListScopeCheckResDto(ArrayList<ScopeCheckResDto> listScopeCheckResDto) {
		this.listScopeCheckResDto = listScopeCheckResDto;
	}
	public String getMessage() {
		return message;
	}
	public ResMessageDto getResMessageDto() {
		return resMessageDto;
	}
	public void setResMessageDto(ResMessageDto resMessageDto) {
		this.resMessageDto = resMessageDto;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public int getTranId() {
		return tranId;
	}
	public void setTranId(int tranId) {
		this.tranId = tranId;
	}

	private String status;
	ArrayList<HCPDocServiceResDto> listHCPDocServiceResDto;
	
	public ArrayList<HCPDocServiceResDto> getListHCPDocServiceResDto() {
		return listHCPDocServiceResDto;
	}
	public void setListHCPDocServiceResDto(ArrayList<HCPDocServiceResDto> listHCPDocServiceResDto) {
		this.listHCPDocServiceResDto = listHCPDocServiceResDto;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public boolean isSrcConnectionStatus() {
		return srcConnectionStatus;
	}
	public void setSrcConnectionStatus(boolean srcConnectionStatus) {
		this.srcConnectionStatus = srcConnectionStatus;
	}
	public boolean isSrcExecutionStatus() {
		return srcExecutionStatus;
	}
	public void setSrcExecutionStatus(boolean srcExecutionStatus) {
		this.srcExecutionStatus = srcExecutionStatus;
	}

	public boolean isConnectionStatus() {
		return connectionStatus;
	}
	public void setConnectionStatus(boolean connectionStatus) {
		this.connectionStatus = connectionStatus;
	}
	public boolean isExecutionStatus() {
		return executionStatus;
	}
	public void setExecutionStatus(boolean executionStatus) {
		this.executionStatus = executionStatus;
	}

	private String scopeName;
	 
	public String getScopeName() {
		return scopeName;
	}
	public void setScopeName(String scopeName) {
		this.scopeName = scopeName;
	}
	public ArrayList<String> getResponseData() {
		return responseData;
	}
	public void setResponseData(ArrayList<String> responseData) {
		this.responseData = responseData;
	}
	ArrayList<String> responseData = new ArrayList<>(); 
	
	public List<String> getFilePathList() {
		return filePathList;
	}
	public void setFilePathList(List<String> filePathList) {
		this.filePathList = filePathList;
	}

	public List<JSONFormatDto> getResult() {
		return result;
	}

	public void setResult(List<JSONFormatDto> result) {
		this.result = result;
	}



}
