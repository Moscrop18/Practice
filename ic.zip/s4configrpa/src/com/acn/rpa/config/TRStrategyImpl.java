package com.acn.rpa.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.config.dto.ClientIMGHierarchyDto;
import com.acn.rpa.config.dto.RetrieveTRScopeDto;
import com.acn.rpa.config.dto.SelectedScopeDto;
import com.acn.rpa.imghierarchy.ClientImgHierarchyDAO;
import com.acn.rpa.utilities.ConstantsValues;
import com.acn.user.session.TRScopeResDto;

public class TRStrategyImpl {
	
    private final Logger slf4jLogger = LoggerFactory.getLogger(TRStrategyImpl.class);

    
	public TRScopeResDto reteriveScopeTR(RetrieveTRScopeDto retrieveTRScopeDto){
		slf4jLogger.info("reteriveScopeTR method started");
		TRScopeResDto trScopeResDto = new TRScopeResDto();
		ArrayList<SelectedScopeDto> result = new ArrayList<>();
		Map<String,ClientIMGHierarchyDto> clientIMGMap =  new HashMap<>();
		ClientIMGHierarchyDto  clientIMGHierarchyDto =  null;
		SelectedScopeDto selectedScopeDto = null;
		ArrayList<String> imgIdList  = new ArrayList<>();
		
		try {
			for(SelectedScopeDto currentScopeDto: retrieveTRScopeDto.getSelectedScopeList()){
				if(retrieveTRScopeDto.isConsolidate()) {
					String imgId= currentScopeDto.getImgId().split("-")[0];
					imgIdList.add(imgId);
				}else {
					imgIdList.add(currentScopeDto.getImgId());
				}			}
			
			if(!imgIdList.isEmpty() &&  retrieveTRScopeDto.getOmID() != null){
				ClientImgHierarchyDAO clientIMGDao =  new ClientImgHierarchyDAO();
				if(retrieveTRScopeDto.getCopyFlag()) {
					clientIMGMap = clientIMGDao.reteriveTR_IMGIDCopyFunctionality(imgIdList, retrieveTRScopeDto.getOmID(),retrieveTRScopeDto.getSystemId());
				}
				else if(retrieveTRScopeDto.isIndustryFlag()) {
					clientIMGMap = clientIMGDao.reteriveTR_IMGIDIndustry(imgIdList, retrieveTRScopeDto.getOmID(),retrieveTRScopeDto.getSystemId());
				}
				else {
					clientIMGMap = clientIMGDao.reteriveTR_IMGID(imgIdList, retrieveTRScopeDto.getOmID(),retrieveTRScopeDto.getSystemId());
					}
					
				if(!clientIMGMap.isEmpty()){
					for(int i = 0,arrSize = retrieveTRScopeDto.getSelectedScopeList().size(); i < arrSize ;i++){
						selectedScopeDto = retrieveTRScopeDto.getSelectedScopeList().get(i);
						selectedScopeDto.setCustomizingTr_readOnly(true);
						selectedScopeDto.setWorkbenchTr_readOnly(true);
						selectedScopeDto.setCustomizingTr_mode("");
						selectedScopeDto.setWorkbenchTr_mode("");
						result.add(selectedScopeDto);
						String img =selectedScopeDto.getImgId();
						if(retrieveTRScopeDto.isConsolidate()) {
							img = selectedScopeDto.getImgId().split("-")[0];
						}
						if(clientIMGMap.containsKey(img)){
						clientIMGHierarchyDto = clientIMGMap.get(selectedScopeDto.getImgId());
						
						if(clientIMGHierarchyDto != null){
							if(selectedScopeDto.getTrType() != null && selectedScopeDto.getTrType().contains("W")){
							if(selectedScopeDto.getCustomizingTr() == null || selectedScopeDto.getCustomizingTr().length() == 0 && retrieveTRScopeDto.getSysFlag().equals(true)){
								selectedScopeDto.setCustomizingTr(clientIMGHierarchyDto.getCTR() == null ? "" :clientIMGHierarchyDto.getCTR());
								}
							else{
								selectedScopeDto.setCustomizingTr(clientIMGHierarchyDto.getCTR() == null ? "" :clientIMGHierarchyDto.getCTR());
							}
							}
							if(selectedScopeDto.getTrType() !=null && selectedScopeDto.getTrType().contains("K")){
							if(selectedScopeDto.getWorkbenchTr() == null || selectedScopeDto.getWorkbenchTr().length() == 0 && retrieveTRScopeDto.getSysFlag().equals(true)){
								selectedScopeDto.setWorkbenchTr(clientIMGHierarchyDto.getKTR() == null ? "" :clientIMGHierarchyDto.getKTR());
							}
							else
							{
								selectedScopeDto.setWorkbenchTr(clientIMGHierarchyDto.getKTR() == null ? "" :clientIMGHierarchyDto.getKTR());
							}
							}
						}
						
						if(retrieveTRScopeDto.getTrOverride() != null && retrieveTRScopeDto.getTrOverride().length() > 0){
							if(retrieveTRScopeDto.getTrOverride().equalsIgnoreCase("P")){
								if(selectedScopeDto.getTrType() != null && selectedScopeDto.getTrType().length() > 0){
									if(selectedScopeDto.getTrType().contains("W")){
										if(selectedScopeDto.getCustomizingTr().length() > 0)
										selectedScopeDto.setCustomizingTr_mode("Display");
										else
											selectedScopeDto.setCustomizingTr_mode("Edit");
									}
									
									if(selectedScopeDto.getTrType().contains("K")){
										if(selectedScopeDto.getWorkbenchTr().length() > 0)
										selectedScopeDto.setWorkbenchTr_mode("Display");
										else
											selectedScopeDto.setWorkbenchTr_mode("Edit");
									}
									
								}
							}else if(retrieveTRScopeDto.getTrOverride().equalsIgnoreCase("F")){
								if(selectedScopeDto.getTrType() != null && selectedScopeDto.getTrType().length() > 0){
									
									if(selectedScopeDto.getTrType().contains("W")){
									    selectedScopeDto.setCustomizingTr_mode("Edit");
									}
									
									if(selectedScopeDto.getTrType().contains("K")){
										selectedScopeDto.setWorkbenchTr_mode("Edit");
									}
									
								}
							}
							
						}else{
							if(selectedScopeDto.getTrType() != null && selectedScopeDto.getTrType().length() > 0){
								if(selectedScopeDto.getTrType().contains("W")){
									if(selectedScopeDto.getCustomizingTr().length() > 0)
										selectedScopeDto.setCustomizingTr_mode("Display");
								}
								if(selectedScopeDto.getTrType().contains("K")){
									if(selectedScopeDto.getWorkbenchTr().length() > 0)
										selectedScopeDto.setWorkbenchTr_mode("Display");
								}
							}
						}
							
						}
						
					}
				}
				
			}
		} catch (Exception e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}finally{
			  slf4jLogger.info("reteriveScopeTR method ended");

		}
		trScopeResDto.setSelectedScopeList(retrieveTRScopeDto.getSelectedScopeList());
		return trScopeResDto;
	}

}
