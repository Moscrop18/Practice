package com.acn.rpa.config;

import java.awt.Color;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;

import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.chemistry.opencmis.client.api.Session;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.encrypt.AESEncrypt;
import com.acn.encrypt.CryptoException;
import com.acn.rpa.admin.SystemDAO;
import com.acn.rpa.admin.SystemDTO;
import com.acn.rpa.config.dto.ConfigDownloadHistoryDto;
import com.acn.rpa.config.dto.ImgFilterResponseDTO;
import com.acn.rpa.config.dto.InstalledBasedResDto;
import com.acn.rpa.docservice.HCPDocDAO;
import com.acn.rpa.fi.GLTemplateDto;
import com.acn.rpa.imghierarchy.FieldMappingDto;
import com.acn.rpa.imghierarchy.ImgDownloadDto;
import com.acn.rpa.imghierarchy.ImgHierarchyCustomDto;
import com.acn.rpa.imghierarchy.ImgHierarchyDAO;
import com.acn.rpa.imghierarchy.IndustryDto;
import com.acn.rpa.imghierarchy.IndustryResponseDto;
import com.acn.rpa.imghierarchy.SystemMappingDao;
import com.acn.rpa.reports.ConfigAuditDAO;
import com.acn.rpa.service.AesUtil;
import com.acn.rpa.utilities.AppUtils;
import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.DBConnection;
import com.acn.rpa.utilities.MyDestinationDataProvider;
import com.sap.conn.jco.AbapException;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoRepository;
import com.sap.conn.jco.JCoTable;
import com.sap.conn.jco.ext.DestinationDataProvider;
import com.sap.conn.jco.ext.Environment;

public class S4AutoConfExecution {
	public boolean srcConnectionStatus = false;
	public boolean dstConnectionStatus = false;
	public boolean srcExecutionStatus = false;
	public boolean dstExecutionStatus = false;
	public boolean isFieldMapRequired = false;

	private final Logger slf4jLogger = LoggerFactory.getLogger(S4AutoConfExecution.class);

	/*
	 * static void createDestinationDataFile(String destinationName, Properties
	 * connectProperties) { File destCfg = new
	 * File(destinationName+".jcoDestination"); try { FileOutputStream fos = new
	 * FileOutputStream(destCfg, false); connectProperties.store(fos,
	 * "for tests only !"); fos.close(); } catch (Exception e) { throw new
	 * RuntimeException("Unable to create the destination files", e); } }
	 */
	public DownloadResponseDto executeSrcConfigDownload(String destinationName, String targetPrgFilePath,
			List<String> imgId, String hostname, String clientno, String sysno, String userId, String password,
			String language,int srcSncEnabled, String srcSncName, String srcSncPartnerName, String srcSncProtection , String srcSapRouter) {
		slf4jLogger.info("executeSrcConfigDownload method started");
		AppUtils appUtilsObj = null;
		// JCoDestination destination = null;
		JCoRepository repo = null;
		JCoFunction stfcConnection = null;
		JCoParameterList tabInput = null;
		JCoTable paramTable = null;
		JCoTable progTable = null;
		int inputArrLength = 0;
		String sapPassword = null;
		DownloadResponseDto downloadResponseDto = new DownloadResponseDto();
		ArrayList<String> resultText = null;
		JCoTable resultTable = null;
		/*String cipherTextSapPass = new String(java.util.Base64.getDecoder().decode(password));
		AesUtil aesUtil = new AesUtil(128, 1000);*/
		int resultTableLen = 0;
		try {
			resultText = new ArrayList<>();
			inputArrLength = imgId.size();
			appUtilsObj = new AppUtils();
			SystemDTO systemDto=new SystemDTO();
			systemDto.setDestinationName(destinationName);
			
			/*
			 * destination =
			 * JCoDestinationManager.getDestination(destinationName); repo =
			 * destination.getRepository();
			 * downloadResponseDto.setSrcConnectionStatus(true); stfcConnection
			 * = repo.getFunction("/ACNIP/RFC"); if (stfcConnection == null){
			 * downloadResponseDto.
			 * setErrorDetails("Source destination Connection issue"); throw new
			 * RuntimeException("/ACNIP/RFC not found in SAP."); }
			 */

			// String DESTINATION_NAME2 = "K4XS4System";
			 SystemDAO eccConfigDAO = new SystemDAO();
			ArrayList<SystemDTO> systemdtos=eccConfigDAO.fetchSystemDetails(systemDto);
			SystemDTO dto=systemdtos.get(0);
			String cipherTextSapPass = new String(java.util.Base64.getDecoder().decode(dto.getPassword()));
			AesUtil aesUtil = new AesUtil(128, 1000);
			Properties connectProperties = new Properties();
			 if (cipherTextSapPass != null && cipherTextSapPass.split("::").length == 3) {   
			    	sapPassword = aesUtil.decrypt(cipherTextSapPass.split("::")[1], cipherTextSapPass.split("::")[0], destinationName, cipherTextSapPass.split("::")[2]);
			      } 
			MyDestinationDataProvider myDestinationDataProvider = MyDestinationDataProvider.getInstance();
			connectProperties.setProperty(DestinationDataProvider.JCO_DEST, destinationName);
			connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, dto.getHostName());
			connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR, dto.getSystemNo());
			connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, dto.getSapClientNo());
			// connectProperties.setProperty(DestinationDataProvider.JCO_GWSERV,"3211");
			connectProperties.setProperty(DestinationDataProvider.JCO_USER, dto.getUserId());
			connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD, sapPassword);
			connectProperties.setProperty(DestinationDataProvider.JCO_LANG, dto.getLanguage());
			
			if(srcSapRouter!=null) {
				connectProperties.setProperty(DestinationDataProvider.JCO_SAPROUTER, srcSapRouter);
			}
			
			
			if(srcSncEnabled==1){
				connectProperties.setProperty(DestinationDataProvider.JCO_SNC_MODE, String.valueOf(srcSncEnabled));
				
				connectProperties.setProperty(DestinationDataProvider.JCO_SNC_MYNAME, srcSncName);
				connectProperties.setProperty(DestinationDataProvider.JCO_SNC_PARTNERNAME,srcSncPartnerName );
				
				connectProperties.setProperty(DestinationDataProvider.JCO_SNC_QOP, srcSncProtection);
				connectProperties.setProperty(DestinationDataProvider.JCO_SNC_LIBRARY, System.getenv("SNC_LIB"));
			}
			// createDestinationDataFile(ConstantsValues.DESTINATION_NAMEK4X,
			// connectProperties);
			myDestinationDataProvider.changePropertiesForABAP_AS(connectProperties);
			System.err.println("data provider" + Environment.isDestinationDataProviderRegistered());
			if (Environment.isDestinationDataProviderRegistered()) {
				System.err.println("inside if");
				Environment.unregisterDestinationDataProvider(myDestinationDataProvider);

			}
			Environment.registerDestinationDataProvider(myDestinationDataProvider);
			connectProperties.setProperty(DestinationDataProvider.JCO_POOL_CAPACITY, "3");
			connectProperties.setProperty(DestinationDataProvider.JCO_PEAK_LIMIT, "10");
			try {

				JCoDestination destination = JCoDestinationManager.getDestination(destinationName);
				/*
				 * System.out.println("Attributes:");
				 * System.out.println(destination.getAttributes());
				 * System.out.println();
				 */

				// JCoDestination destination =
				// JCoDestinationManager.getDestination(DESTINATION_NAME2);
				destination.ping();
				downloadResponseDto.setSrcConnectionStatus(true);
				/*
				 * System.out.println("Attributes:");
				 * System.out.println(destination.getAttributes());
				 * System.out.println();
				 */

				// JCoDestination destination1 =
				// JCoDestinationManager.getDestination(DESTINATION_NAME2);
				stfcConnection = destination.getRepository().getFunction("/ACNIP/RFC");
				if (stfcConnection == null) {
					downloadResponseDto.setErrorDetails("Source destination Connection issue");
					throw new RuntimeException("/ACNIP/RFC not found in SAP.");
				}

				tabInput = stfcConnection.getTableParameterList();
				paramTable = tabInput.getTable("I_PARAM");

				for (int i = 0; i < inputArrLength; i++) {
					paramTable.appendRow();
					paramTable.setValue("WA", imgId.get(i));
				}

				progTable = appUtilsObj.getABAPPrg(targetPrgFilePath, tabInput);

				try {
					stfcConnection.execute(destination);
					// slf4jLogger.info("before execution status");
					downloadResponseDto.setSrcExecutionStatus(true);
					// slf4jLogger.info(" after execution status");
					resultTable = tabInput.getTable("O_RESULT");
					resultTableLen = resultTable.getNumRows();
					// slf4jLogger.info(" result table"+resultTable);
					for (int i = 0; i < resultTableLen; i++) {
						resultTable.setRow(i);
						resultText.add(resultTable.getString("WA"));
						// slf4jLogger.info(" resleu
						// text"+resultTable.getString("WA"));
					}
					downloadResponseDto.setDownloadRes(resultText);
					// slf4jLogger.info(" resleu text from download
					// "+downloadResponseDto.getDownloadRes());
				} catch (JCoException e) {
					// downloadResponseDto.setErrorDetails(e.getLocalizedMessage());
					downloadResponseDto.setErrorDetails(destinationName + ConstantsValues.DESTINATIONDOWN);
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
					resultText.add("JCO Execution Failed: " + e);
					downloadResponseDto.setDownloadRes(resultText);
					downloadResponseDto.setSrcConnectionStatus(false);
				}
			}

			catch (JCoException e) {
				// downloadResponseDto.setErrorDetails(e.getLocalizedMessage());
				downloadResponseDto.setErrorDetails(destinationName + ConstantsValues.DESTINATIONDOWN);
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				resultText.add("JCO Execution Failed: " + e);
				downloadResponseDto.setDownloadRes(resultText);
				downloadResponseDto.setSrcConnectionStatus(false);
			} catch (OutOfMemoryError e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				resultText.add("Out of memory Exception from SAP" + e);
				downloadResponseDto.setDownloadRes(resultText);
				downloadResponseDto.setSrcExecutionStatus(false);
			} catch (Exception e) {
				// downloadResponseDto.setErrorDetails(e.getLocalizedMessage());
				downloadResponseDto.setErrorDetails(destinationName + ConstantsValues.DESTINATIONDOWN);
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				resultText.add("Execution of RFC Failed: " + e);
				downloadResponseDto.setSrcExecutionStatus(false);
				downloadResponseDto.setDownloadRes(resultText);
			} catch (Throwable e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				resultText.add("Out of memory Exception from SAP" + e);
				downloadResponseDto.setDownloadRes(resultText);
				downloadResponseDto.setSrcExecutionStatus(false);
			}
		} catch (Exception e) {
			// downloadResponseDto.setErrorDetails(e.getLocalizedMessage());
			downloadResponseDto.setErrorDetails(destinationName + ConstantsValues.DESTINATIONDOWN);
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("JCO Connection Failed: " + e);
			downloadResponseDto.setDownloadRes(resultText);
			downloadResponseDto.setSrcConnectionStatus(false);
		} catch (java.lang.NoClassDefFoundError e) {
			// downloadResponseDto.setErrorDetails(e.getLocalizedMessage());
			downloadResponseDto.setErrorDetails(destinationName + ConstantsValues.DESTINATIONDOWN);
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("JCO Library Issue.  " + e);
			downloadResponseDto.setSrcConnectionStatus(false);
		} catch (java.lang.ExceptionInInitializerError e) {
			// downloadResponseDto.setErrorDetails(e.getLocalizedMessage());
			downloadResponseDto.setErrorDetails(destinationName + ConstantsValues.DESTINATIONDOWN);
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("JCO Library Issue. " + e);
			downloadResponseDto.setSrcConnectionStatus(false);
		} /*
			 * catch (Exception e) {
			 * //downloadResponseDto.setErrorDetails(e.getLocalizedMessage());
			 * downloadResponseDto.setErrorDetails(destinationName+
			 * ConstantsValues.DESTINATIONDOWN);
			 * slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			 * resultText.add("Configuration Failed: " + e);
			 * downloadResponseDto.setDownloadRes(resultText);
			 * downloadResponseDto.setSrcExecutionStatus(false); }
			 */
		catch (OutOfMemoryError e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("Out of memory Exception from SAP" + e);
			downloadResponseDto.setDownloadRes(resultText);
			downloadResponseDto.setSrcExecutionStatus(false);
		} finally {
			resultText = null;
			// destination = null;
			repo = null;
			stfcConnection = null;
			tabInput = null;
			if (paramTable != null)
				paramTable.clear();
			if (progTable != null)
				progTable.clear();
			appUtilsObj = null;
			if (resultTable != null)
				resultTable.clear();
			slf4jLogger.info("executeSrcConfigDownload method ended");

		}

		return downloadResponseDto;
	}
	public DownloadResponseDto executeSrcConfigDownloadCopyFunctionality(HashMap<String, ArrayList<String>> copyFromTo, String destinationName, String targetPrgFilePath,
			List<String> imgId, String hostname, String clientno, String sysno, String userId, String password,
			String language) {
		slf4jLogger.info("executeSrcConfigDownload method started");
		AppUtils appUtilsObj = null;
		// JCoDestination destination = null;
		JCoRepository repo = null;
		JCoFunction stfcConnection = null;
		JCoParameterList tabInput = null;
		JCoTable paramTable = null;
		JCoTable progTable = null;
		int inputArrLength = 0;
		String sapPassword = null;
		String copyFrom="";
		DownloadResponseDto downloadResponseDto = new DownloadResponseDto();

		ArrayList<String> resultText = null;
		JCoTable resultTable = null;
		/*String cipherTextSapPass = new String(java.util.Base64.getDecoder().decode(password));
		AesUtil aesUtil = new AesUtil(128, 1000);*/
		int resultTableLen = 0;
		try {
			resultText = new ArrayList<>();
			inputArrLength = imgId.size();
			appUtilsObj = new AppUtils();
			SystemDTO systemDto=new SystemDTO();
			systemDto.setDestinationName(destinationName);
			for(String s:copyFromTo.keySet())
			{
				if(copyFrom.equals(""))
					copyFrom="|"+s;
				else
					copyFrom=copyFrom+","+s;
			}
			copyFrom=copyFrom+"|COPY";
			/*
			 * destination =
			 * JCoDestinationManager.getDestination(destinationName); repo =
			 * destination.getRepository();
			 * downloadResponseDto.setSrcConnectionStatus(true); stfcConnection
			 * = repo.getFunction("/ACNIP/RFC"); if (stfcConnection == null){
			 * downloadResponseDto.
			 * setErrorDetails("Source destination Connection issue"); throw new
			 * RuntimeException("/ACNIP/RFC not found in SAP."); }
			 */

			// String DESTINATION_NAME2 = "K4XS4System";
			 SystemDAO eccConfigDAO = new SystemDAO();
			ArrayList<SystemDTO> systemdtos=eccConfigDAO.fetchSystemDetails(systemDto);
			SystemDTO dto=systemdtos.get(0);
			String cipherTextSapPass = new String(java.util.Base64.getDecoder().decode(dto.getPassword()));
			AesUtil aesUtil = new AesUtil(128, 1000);
			Properties connectProperties = new Properties();
			 if (cipherTextSapPass != null && cipherTextSapPass.split("::").length == 3) {   
			    	sapPassword = aesUtil.decrypt(cipherTextSapPass.split("::")[1], cipherTextSapPass.split("::")[0], destinationName, cipherTextSapPass.split("::")[2]);
			      } 
			MyDestinationDataProvider myDestinationDataProvider = MyDestinationDataProvider.getInstance();
			connectProperties.setProperty(DestinationDataProvider.JCO_DEST, destinationName);
			connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, dto.getHostName());
			connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR, dto.getSystemNo());
			connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, dto.getSapClientNo());
			// connectProperties.setProperty(DestinationDataProvider.JCO_GWSERV,"3211");
			connectProperties.setProperty(DestinationDataProvider.JCO_USER, dto.getUserId());
			connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD, sapPassword);
			connectProperties.setProperty(DestinationDataProvider.JCO_LANG, dto.getLanguage());
			
			
			if(dto.getSapRouter()!=null) {
				connectProperties.setProperty(DestinationDataProvider.JCO_SAPROUTER, dto.getSapRouter());
			}
			if(dto.getSncEnabled()==1){
				connectProperties.setProperty(DestinationDataProvider.JCO_SNC_MODE, String.valueOf(dto.getSncEnabled()));
				
				connectProperties.setProperty(DestinationDataProvider.JCO_SNC_MYNAME, dto.getSncName());
				connectProperties.setProperty(DestinationDataProvider.JCO_SNC_PARTNERNAME,dto.getSncPartnerName() );
				
				connectProperties.setProperty(DestinationDataProvider.JCO_SNC_QOP, dto.getSncProtectionLevel());
				connectProperties.setProperty(DestinationDataProvider.JCO_SNC_LIBRARY, System.getenv("SNC_LIB"));
			}
			// createDestinationDataFile(ConstantsValues.DESTINATION_NAMEK4X,
			// connectProperties);
			myDestinationDataProvider.changePropertiesForABAP_AS(connectProperties);
			System.err.println("data provider" + Environment.isDestinationDataProviderRegistered());
			if (Environment.isDestinationDataProviderRegistered()) {
				System.err.println("inside if");
				Environment.unregisterDestinationDataProvider(myDestinationDataProvider);

			}
			Environment.registerDestinationDataProvider(myDestinationDataProvider);
			connectProperties.setProperty(DestinationDataProvider.JCO_POOL_CAPACITY, "3");
			connectProperties.setProperty(DestinationDataProvider.JCO_PEAK_LIMIT, "10");
			try {

				JCoDestination destination = JCoDestinationManager.getDestination(destinationName);
				/*
				 * System.out.println("Attributes:");
				 * System.out.println(destination.getAttributes());
				 * System.out.println();
				 */

				// JCoDestination destination =
				// JCoDestinationManager.getDestination(DESTINATION_NAME2);
				destination.ping();
				downloadResponseDto.setSrcConnectionStatus(true);
				/*
				 * System.out.println("Attributes:");
				 * System.out.println(destination.getAttributes());
				 * System.out.println();
				 */

				// JCoDestination destination1 =
				// JCoDestinationManager.getDestination(DESTINATION_NAME2);
				stfcConnection = destination.getRepository().getFunction("/ACNIP/RFC");
				if (stfcConnection == null) {
					downloadResponseDto.setErrorDetails("Source destination Connection issue");
					throw new RuntimeException("/ACNIP/RFC not found in SAP.");
				}

				tabInput = stfcConnection.getTableParameterList();
				paramTable = tabInput.getTable("I_PARAM");

				for (int i = 0; i < inputArrLength; i++) {
					paramTable.appendRow(); 
					paramTable.setValue("WA", imgId.get(i)+copyFrom);
				}

				progTable = appUtilsObj.getABAPPrg(targetPrgFilePath, tabInput);

				try {
					stfcConnection.execute(destination);
					// slf4jLogger.info("before execution status");
					downloadResponseDto.setSrcExecutionStatus(true);
					// slf4jLogger.info(" after execution status");
					resultTable = tabInput.getTable("O_RESULT");
					resultTableLen = resultTable.getNumRows();
					// slf4jLogger.info(" result table"+resultTable);
					for (int i = 0; i < resultTableLen; i++) {
						resultTable.setRow(i);
						resultText.add(resultTable.getString("WA"));
						// slf4jLogger.info(" resleu
						// text"+resultTable.getString("WA"));
					}
					downloadResponseDto.setDownloadRes(resultText);
					// slf4jLogger.info(" resleu text from download
					// "+downloadResponseDto.getDownloadRes());
				} catch (JCoException e) {
					// downloadResponseDto.setErrorDetails(e.getLocalizedMessage());
					downloadResponseDto.setErrorDetails(destinationName + ConstantsValues.DESTINATIONDOWN);
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
					resultText.add("JCO Execution Failed: " + e);
					downloadResponseDto.setDownloadRes(resultText);
					downloadResponseDto.setSrcConnectionStatus(false);

				}
			}

			catch (JCoException e) {
				// downloadResponseDto.setErrorDetails(e.getLocalizedMessage());
				downloadResponseDto.setErrorDetails(destinationName + ConstantsValues.DESTINATIONDOWN);
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				resultText.add("JCO Execution Failed: " + e);
				downloadResponseDto.setDownloadRes(resultText);
				downloadResponseDto.setSrcConnectionStatus(false);
			} catch (OutOfMemoryError e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				resultText.add("Out of memory Exception from SAP" + e);
				downloadResponseDto.setDownloadRes(resultText);
				downloadResponseDto.setSrcExecutionStatus(false);
			} catch (Exception e) {
				// downloadResponseDto.setErrorDetails(e.getLocalizedMessage());
				downloadResponseDto.setErrorDetails(destinationName + ConstantsValues.DESTINATIONDOWN);
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				resultText.add("Execution of RFC Failed: " + e);
				downloadResponseDto.setSrcExecutionStatus(false);
				downloadResponseDto.setDownloadRes(resultText);
			} catch (Throwable e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				resultText.add("Out of memory Exception from SAP" + e);
				downloadResponseDto.setDownloadRes(resultText);
				downloadResponseDto.setSrcExecutionStatus(false);
			}
		} catch (Exception e) {
			// downloadResponseDto.setErrorDetails(e.getLocalizedMessage());
			downloadResponseDto.setErrorDetails(destinationName + ConstantsValues.DESTINATIONDOWN);
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("JCO Connection Failed: " + e);
			downloadResponseDto.setDownloadRes(resultText);
			downloadResponseDto.setSrcConnectionStatus(false);
		} catch (java.lang.NoClassDefFoundError e) {
			// downloadResponseDto.setErrorDetails(e.getLocalizedMessage());
			downloadResponseDto.setErrorDetails(destinationName + ConstantsValues.DESTINATIONDOWN);
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("JCO Library Issue.  " + e);
			downloadResponseDto.setSrcConnectionStatus(false);
		} catch (java.lang.ExceptionInInitializerError e) {
			// downloadResponseDto.setErrorDetails(e.getLocalizedMessage());
			downloadResponseDto.setErrorDetails(destinationName + ConstantsValues.DESTINATIONDOWN);
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("JCO Library Issue. " + e);
			downloadResponseDto.setSrcConnectionStatus(false);
		} /*
			 * catch (Exception e) {
			 * //downloadResponseDto.setErrorDetails(e.getLocalizedMessage());
			 * downloadResponseDto.setErrorDetails(destinationName+
			 * ConstantsValues.DESTINATIONDOWN);
			 * slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			 * resultText.add("Configuration Failed: " + e);
			 * downloadResponseDto.setDownloadRes(resultText);
			 * downloadResponseDto.setSrcExecutionStatus(false); }
			 */
		catch (OutOfMemoryError e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("Out of memory Exception from SAP" + e);
			downloadResponseDto.setDownloadRes(resultText);
			downloadResponseDto.setSrcExecutionStatus(false);
		} finally {
			resultText = null;
			// destination = null;
			repo = null;
			stfcConnection = null;
			tabInput = null;
			if (paramTable != null)
				paramTable.clear();
			if (progTable != null)
				progTable.clear();
			appUtilsObj = null;
			if (resultTable != null)
				resultTable.clear();
			slf4jLogger.info("executeSrcConfigDownload method ended");

		}

		return downloadResponseDto;
	}
	public UploadResponseDto executeTargetSysConsolidation(S4AutoConfigReqDto inputDTO) {
		slf4jLogger.info("executeTargetSysConsolidation method started");
		ArrayList<String> resultText = new ArrayList<>();
		UploadResponseDto uploadResponseDto = new UploadResponseDto();
		ArrayList<String> viewConfigData = null;
		JCoRepository repo = null;
		DynamicDestinationDAO dynamicDestinationDaoObj = new DynamicDestinationDAO();
		DynamicDestinationResDto dynamicDestinationResDto = new DynamicDestinationResDto();
		JCoDestination destination = null;
		AppUtils appUtilsObj = null;
		ExcelFormatConvert excelFormatUtil = null;
		ArrayList<String> tgtResultParamText = null;
		JCoTable resultTable = null;
		int resultTableLen = 0;
		JCoTable resultParamTable = null;
		JCoTable paramTable = null;
		JCoTable progTable = null;
		ImgHierarchyDAO imgHierarchyDAO = null;
		ArrayList<String> viewList = null;
		ConfigInputDTO configInputDTO = null;
		int recordCount = 0;
		String sapPassword = null;
		JCoFunction stfcConnection = null;
		String imgId=inputDTO.getScopeName().split("-")[0];
		try {
			tgtResultParamText = new ArrayList<String>();
			excelFormatUtil = new ExcelFormatConvert();
			appUtilsObj = new AppUtils();
			configInputDTO = new ConfigInputDTO();
			if (inputDTO.getImplType().equals("BrownField")) {
				viewConfigData = inputDTO.getConfigDataList();
			} else if (inputDTO.getImplType() != null && inputDTO.getImplType().equals("FilterData")) {
				
				configInputDTO = excelFormatUtil.getConsolidationDataForTargetSystem(inputDTO.getWorkbook(),viewList,imgId);
				viewConfigData = configInputDTO.getRecordByView();

			}
			else{
				imgHierarchyDAO = new ImgHierarchyDAO();
				viewList=new ArrayList<String>();
				viewList.add(inputDTO.getScopeName().split("-")[1]);
				configInputDTO = excelFormatUtil.convertConsolidationFormat(inputDTO.getFileBytes(), viewList, imgId);
				viewConfigData = configInputDTO.getRecordByView();

}
			if (viewConfigData != null && viewConfigData.isEmpty()) {
				uploadResponseDto.setDstConnectionStatus(true);
				if (inputDTO.getImplType().equals("BrownField"))
					resultText.add(
							"Configurable data is required from Source system, please check selected source System.");
				else if (inputDTO.getImplType().equals("greenField"))
					resultText.add(
							"Uploaded file is not in correct file format. Note: Accepted file formats are .xls and .xlsx");
				else if (inputDTO.getImplType().equals("FilterData"))
					resultText.add("Configurable data is empty based on filter Request.");
			} else if (viewConfigData != null && viewConfigData.size() > 1) {
				// slf4jLogger.debug("Configuration size " +
				// viewConfigData.size());
				recordCount = Integer.parseInt(viewConfigData.get(viewConfigData.size() - 1).split("\\|")[2]);
				uploadResponseDto.setRecordCount(recordCount);
				uploadResponseDto.setDstConnectionStatus(false);

				if ((inputDTO.getCustomizingTr() != null && inputDTO.getCustomizingTr().trim().length() > 0)
						|| (inputDTO.getWorkbenchTr() != null && inputDTO.getWorkbenchTr().trim().length() > 0)) {
					StringBuilder imgTRnumber = new StringBuilder(viewConfigData.get(0));
					if (inputDTO.getCustomizingTr() != null) {
						imgTRnumber.append("|" + inputDTO.getCustomizingTr());
					} else {
						imgTRnumber.append("|");
					}
					if (inputDTO.getWorkbenchTr() != null) {
						imgTRnumber.append("|" + inputDTO.getWorkbenchTr());
					} else {
						imgTRnumber.append("|");
					}
					viewConfigData.set(0, imgTRnumber.toString());
				}
				/*String cipherTextSapPass = new String(java.util.Base64.getDecoder().decode(inputDTO.getSapPassword()));
				AesUtil aesUtil = new AesUtil(128, 1000);
				
				 if (cipherTextSapPass != null && cipherTextSapPass.split("::").length == 3) {   
				    	sapPassword = aesUtil.decrypt(cipherTextSapPass.split("::")[1], cipherTextSapPass.split("::")[0], inputDTO.getDestinationName(), cipherTextSapPass.split("::")[2]);
				      } 
			*/
				Properties connectProperties = new Properties();
				MyDestinationDataProvider myDestinationDataProvider = MyDestinationDataProvider.getInstance();
				/*
				 * String cipherTextSapPass = new
				 * String(java.util.Base64.getDecoder().decode(inputDTO.
				 * getSapPassword())); AesUtil aesUtil = new AesUtil(128, 1000);
				 */
				connectProperties.setProperty(DestinationDataProvider.JCO_DEST, inputDTO.getDestinationName());
				connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, inputDTO.getHostName());
				connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR,inputDTO.getSystemNo());
				connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, inputDTO.getSapClientNo());
									/*
					 * if (cipherTextSapPass != null &&
					 * cipherTextSapPass.split("::").length == 3) { sapPassword
					 * = aesUtil.decrypt(cipherTextSapPass.split("::")[1],
					 * cipherTextSapPass.split("::")[0],
					 * inputDTO.getDestinationName(),
					 * cipherTextSapPass.split("::")[2]); }
					 */
					// slf4jLogger.info("username"+inputDTO.getSapUserId()+inputDTO.getSapPassword()+inputDTO.getSapLanguage());
					connectProperties.setProperty(DestinationDataProvider.JCO_USER, inputDTO.getSapUserId());
					connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD, inputDTO.getSapPassword());
					connectProperties.setProperty(DestinationDataProvider.JCO_LANG, inputDTO.getSapLanguage());
					
					
					if(inputDTO.getSapRouter()!=null) {
						connectProperties.setProperty(DestinationDataProvider.JCO_SAPROUTER, inputDTO.getSapRouter());
					}
					
				
					if(inputDTO.getSncEnabled()==1){
						connectProperties.setProperty(DestinationDataProvider.JCO_SNC_MODE, String.valueOf(inputDTO.getSncEnabled()));
						
						connectProperties.setProperty(DestinationDataProvider.JCO_SNC_MYNAME, inputDTO.getSncName());
						connectProperties.setProperty(DestinationDataProvider.JCO_SNC_PARTNERNAME, inputDTO.getSncPartnerName());
						
						connectProperties.setProperty(DestinationDataProvider.JCO_SNC_QOP, inputDTO.getSncProtectionLevel());
						connectProperties.setProperty(DestinationDataProvider.JCO_SNC_LIBRARY, System.getenv("SNC_LIB"));
					}
		
				// createDestinationDataFile(ConstantsValues.DESTINATION_NAMEK4A,
				// connectProperties);
				/*
				 * Set URL = connectProperties.keySet(); Iterator itr =
				 * URL.iterator();
				 * 
				 * while(itr.hasNext()) { String str = (String)itr.next();
				 * System.out.println("The URL for " + str + " is " +
				 * connectProperties.getProperty(str)); }
				 */
				myDestinationDataProvider.changePropertiesForABAP_AS(connectProperties);
				System.err.println("Data Provider" + Environment.isDestinationDataProviderRegistered());
				if (Environment.isDestinationDataProviderRegistered()) {
					System.err.println("inside if");
					Environment.unregisterDestinationDataProvider(myDestinationDataProvider);

				}
				Environment.registerDestinationDataProvider(myDestinationDataProvider);
				destination = JCoDestinationManager.getDestination(inputDTO.getDestinationName());
				// destination.ping();
				repo = destination.getRepository();
				uploadResponseDto.setDstConnectionStatus(true);
				stfcConnection = repo.getFunction("/ACNIP/RFC");
				if (stfcConnection == null) {

					dynamicDestinationResDto.setStatus(ConstantsValues.ERRORSTATUS);
					dynamicDestinationResDto.setMessage("/ACNIP/RFC not found in SAP.");
				} else {
					dynamicDestinationResDto.setStatus(ConstantsValues.SUCCESSSTATUS);
					dynamicDestinationResDto.setMessage("Connection To destination Established sucessfully");
				}
				/*
				 * if(inputDTO.getIsCustomDestinationRequired().equals("true")){
				 * 
				 * dynamicDestinationResDto =
				 * dynamicDestinationDaoObj.createCustomDestinationObject(
				 * inputDTO.getSapUserId(),
				 * inputDTO.getSapPassword(),inputDTO.getSapLanguage(),
				 * destination);
				 * if(dynamicDestinationResDto.getStatus().equals("Success"))
				 * repo =
				 * dynamicDestinationResDto.getCustomDestination().getRepository
				 * (); else resultText.
				 * add("Exception occured while creating custom Destination"); }
				 * else{ repo = destination.getRepository(); }
				 */

				/*
				 * stfcConnection = repo.getFunction("/ACNIP/RFC"); if
				 * (stfcConnection == null) throw new
				 * RuntimeException("/ACNIP/RFC not found in SAP.");
				 */
				JCoParameterList tabInput = stfcConnection.getTableParameterList();
				paramTable = tabInput.getTable("I_PARAM");
				for (int i = 0; i < viewConfigData.size(); i++) {
					if (viewConfigData.get(i) != null && !viewConfigData.get(i).equalsIgnoreCase("")) {
						paramTable.appendRow();
						paramTable.setValue("WA", viewConfigData.get(i));
					}
				}
				progTable = appUtilsObj.getABAPPrg(inputDTO.getUpldABAPPrgPath(), tabInput);
				// slf4jLogger.info("paramtable"+progTable);
				uploadResponseDto.setDstExecutionStatus(true);
				try {

					/*
					 * if(inputDTO.getIsCustomDestinationRequired().equals(
					 * "true")){ synchronized (this) {
					 * stfcConnection.execute(dynamicDestinationResDto.
					 * getCustomDestination()); } }else{
					 * stfcConnection.execute(destination); }
					 */
					stfcConnection.execute(destination);
				} catch (Throwable e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
					resultText.add("Configuration Failed: " + e);
					uploadResponseDto.setDstExecutionStatus(false);
					return uploadResponseDto;
				}
				resultTable = tabInput.getTable("O_RESULT");
				resultTableLen = resultTable.getNumRows();
				for (int i = 0; i < resultTableLen; i++) {
					resultTable.setRow(i);
					resultText.add(resultTable.getString("WA"));
				}
				resultParamTable = tabInput.getTable("I_PARAM");
				for (int i = 0; i < resultParamTable.getNumRows(); i++) {
					resultParamTable.setRow(i);
					tgtResultParamText.add(resultParamTable.getString("WA"));
				}
			} else {
				resultText.add("Template does not contain any configurable data, please check template and upload.");
			}
		} catch (AbapException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("Execution of RFC Failed: " + e);
			uploadResponseDto.setDstConnectionStatus(false);

		} catch (JCoException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("JCO Connection Failed: " + e);
			uploadResponseDto.setDstConnectionStatus(false);
		} catch (java.lang.NoClassDefFoundError e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("JCO Library Issue.  " + e);
			uploadResponseDto.setDstConnectionStatus(false);
		} catch (java.lang.ExceptionInInitializerError e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("JCO Library Issue. " + e);
			uploadResponseDto.setDstConnectionStatus(false);
		} catch (Exception e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("Configuration Failed: " + e);
			uploadResponseDto.setDstExecutionStatus(false);
		} catch (Throwable e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("Configuration Failed: " + e);
			uploadResponseDto.setDstExecutionStatus(false);
		} finally {
			uploadResponseDto.setResponseData(resultText);
			excelFormatUtil = null;
			viewConfigData = null;
			resultText = null;
			repo = null;
			dynamicDestinationDaoObj = null;
			dynamicDestinationResDto = null;
			destination = null;
			appUtilsObj = null;
			if (resultTable != null)
				resultTable.clear();
			if (resultParamTable != null)
				resultParamTable.clear();
			if (paramTable != null)
				paramTable.clear();
			if (progTable != null)
				progTable.clear();
			slf4jLogger.info("executeTargetSysConsolidation method ended");

		}
		return uploadResponseDto;
	}
	public UploadResponseDto executeTargetSysConfig(S4AutoConfigReqDto inputDTO) {
		slf4jLogger.info("executeTargetSysConfig method started");
		ArrayList<String> resultText = new ArrayList<>();
		UploadResponseDto uploadResponseDto = new UploadResponseDto();
		ArrayList<String> viewConfigData = null;
		JCoRepository repo = null;
		DynamicDestinationDAO dynamicDestinationDaoObj = new DynamicDestinationDAO();
		DynamicDestinationResDto dynamicDestinationResDto = new DynamicDestinationResDto();
		JCoDestination destination = null;
		AppUtils appUtilsObj = null;
		ExcelFormatConvert excelFormatUtil = null;
		ArrayList<String> tgtResultParamText = null;
		JCoTable resultTable = null;
		int resultTableLen = 0;
		JCoTable resultParamTable = null;
		JCoTable paramTable = null;
		JCoTable progTable = null;
		ImgHierarchyDAO imgHierarchyDAO = null;
		ArrayList<String> viewList = null;
		ConfigInputDTO configInputDTO = null;
		int recordCount = 0;
		String sapPassword = null;
		JCoFunction stfcConnection = null;
		try {
			tgtResultParamText = new ArrayList<String>();
			excelFormatUtil = new ExcelFormatConvert();
			appUtilsObj = new AppUtils();
			configInputDTO = new ConfigInputDTO();
			if (inputDTO.getImplType().equals("BrownField")) {
				viewConfigData = inputDTO.getConfigDataList();
			} else if (inputDTO.getImplType() != null && inputDTO.getImplType().equals("FilterData")) {

				configInputDTO = excelFormatUtil.getConfigDataForTargetSystem(inputDTO.getWorkbook(), viewList);
				viewConfigData = configInputDTO.getRecordByView();

			} else {
				imgHierarchyDAO = new ImgHierarchyDAO();
				
				if(inputDTO.isIndustryFlag()) {
					viewList = imgHierarchyDAO.getViewBySequenceForIndustry(inputDTO.getScopeName(), inputDTO.getIndustry(), inputDTO.getSubIndustry());
				}else {
					viewList = imgHierarchyDAO.getViewBySequence(inputDTO.getScopeName());
				}
				configInputDTO = excelFormatUtil.convertFormat(inputDTO.getFileBytes(), viewList);
				viewConfigData = configInputDTO.getRecordByView();

			}
			if (viewConfigData != null && viewConfigData.isEmpty()) {
				uploadResponseDto.setDstConnectionStatus(true);
				if (inputDTO.getImplType().equals("BrownField"))
					resultText.add(
							"Configurable data is required from Source system, please check selected source System.");
				else if (inputDTO.getImplType().equals("greenField"))
					resultText.add(
							"Uploaded file is not in correct file format. Note: Accepted file formats are .xls and .xlsx");
				else if (inputDTO.getImplType().equals("FilterData"))
					resultText.add("Configurable data is empty based on filter Request.");
			} else if (viewConfigData != null && viewConfigData.size() > 1) {
				// slf4jLogger.debug("Configuration size " +
				// viewConfigData.size());
				recordCount = Integer.parseInt(viewConfigData.get(viewConfigData.size() - 1).split("\\|")[2]);
				uploadResponseDto.setRecordCount(recordCount);
				uploadResponseDto.setDstConnectionStatus(false);

				if ((inputDTO.getCustomizingTr() != null && inputDTO.getCustomizingTr().trim().length() > 0)
						|| (inputDTO.getWorkbenchTr() != null && inputDTO.getWorkbenchTr().trim().length() > 0)) {
					StringBuilder imgTRnumber = new StringBuilder(viewConfigData.get(0));
					if (inputDTO.getCustomizingTr() != null) {
						imgTRnumber.append("|" + inputDTO.getCustomizingTr());
					} else {
						imgTRnumber.append("|");
					}
					if (inputDTO.getWorkbenchTr() != null) {
						imgTRnumber.append("|" + inputDTO.getWorkbenchTr());
					} else {
						imgTRnumber.append("|");
					}
					viewConfigData.set(0, imgTRnumber.toString());
				}
				String cipherTextSapPass = new String(java.util.Base64.getDecoder().decode(inputDTO.getSapPassword()));
				AesUtil aesUtil = new AesUtil(128, 1000);
				Properties connectProperties = new Properties();
				 if (cipherTextSapPass != null && cipherTextSapPass.split("::").length == 3) {   
				    	sapPassword = aesUtil.decrypt(cipherTextSapPass.split("::")[1], cipherTextSapPass.split("::")[0], inputDTO.getDestinationName(), cipherTextSapPass.split("::")[2]);
				      } 
			
				MyDestinationDataProvider myDestinationDataProvider = MyDestinationDataProvider.getInstance();
				/*
				 * String cipherTextSapPass = new
				 * String(java.util.Base64.getDecoder().decode(inputDTO.
				 * getSapPassword())); AesUtil aesUtil = new AesUtil(128, 1000);
				 */
				connectProperties.setProperty(DestinationDataProvider.JCO_DEST, inputDTO.getDestinationName());
				connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, inputDTO.getHostName());
				connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR,inputDTO.getSystemNo());
				connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, inputDTO.getSapClientNo());
									/*
					 * if (cipherTextSapPass != null &&
					 * cipherTextSapPass.split("::").length == 3) { sapPassword
					 * = aesUtil.decrypt(cipherTextSapPass.split("::")[1],
					 * cipherTextSapPass.split("::")[0],
					 * inputDTO.getDestinationName(),
					 * cipherTextSapPass.split("::")[2]); }
					 */
					// slf4jLogger.info("username"+inputDTO.getSapUserId()+inputDTO.getSapPassword()+inputDTO.getSapLanguage());
					connectProperties.setProperty(DestinationDataProvider.JCO_USER, inputDTO.getSapUserId());
					connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD, sapPassword);
					connectProperties.setProperty(DestinationDataProvider.JCO_LANG, inputDTO.getSapLanguage());
					
					if(inputDTO.getSapRouter()!=null) {
						connectProperties.setProperty(DestinationDataProvider.JCO_SAPROUTER, inputDTO.getSapRouter());
					}
					
				
					if(inputDTO.getSncEnabled()==1){
						connectProperties.setProperty(DestinationDataProvider.JCO_SNC_MODE, String.valueOf(inputDTO.getSncEnabled()));
						
						connectProperties.setProperty(DestinationDataProvider.JCO_SNC_MYNAME, inputDTO.getSncName());
						connectProperties.setProperty(DestinationDataProvider.JCO_SNC_PARTNERNAME, inputDTO.getSncPartnerName());
						
						connectProperties.setProperty(DestinationDataProvider.JCO_SNC_QOP, inputDTO.getSncProtectionLevel());
						connectProperties.setProperty(DestinationDataProvider.JCO_SNC_LIBRARY, System.getenv("SNC_LIB"));
					}
		
				// createDestinationDataFile(ConstantsValues.DESTINATION_NAMEK4A,
				// connectProperties);
				/*
				 * Set URL = connectProperties.keySet(); Iterator itr =
				 * URL.iterator();
				 * 
				 * while(itr.hasNext()) { String str = (String)itr.next();
				 * System.out.println("The URL for " + str + " is " +
				 * connectProperties.getProperty(str)); }
				 */
				myDestinationDataProvider.changePropertiesForABAP_AS(connectProperties);
				System.err.println("Data Provider" + Environment.isDestinationDataProviderRegistered());
				if (Environment.isDestinationDataProviderRegistered()) {
					System.err.println("inside if");
					Environment.unregisterDestinationDataProvider(myDestinationDataProvider);

				}
				Environment.registerDestinationDataProvider(myDestinationDataProvider);
				destination = JCoDestinationManager.getDestination(inputDTO.getDestinationName());
				// destination.ping();
				repo = destination.getRepository();
				uploadResponseDto.setDstConnectionStatus(true);
				stfcConnection = repo.getFunction("/ACNIP/RFC");
				if (stfcConnection == null) {

					dynamicDestinationResDto.setStatus(ConstantsValues.ERRORSTATUS);
					dynamicDestinationResDto.setMessage("/ACNIP/RFC not found in SAP.");
				} else {
					dynamicDestinationResDto.setStatus(ConstantsValues.SUCCESSSTATUS);
					dynamicDestinationResDto.setMessage("Connection To destination Established sucessfully");
				}
				/*
				 * if(inputDTO.getIsCustomDestinationRequired().equals("true")){
				 * 
				 * dynamicDestinationResDto =
				 * dynamicDestinationDaoObj.createCustomDestinationObject(
				 * inputDTO.getSapUserId(),
				 * inputDTO.getSapPassword(),inputDTO.getSapLanguage(),
				 * destination);
				 * if(dynamicDestinationResDto.getStatus().equals("Success"))
				 * repo =
				 * dynamicDestinationResDto.getCustomDestination().getRepository
				 * (); else resultText.
				 * add("Exception occured while creating custom Destination"); }
				 * else{ repo = destination.getRepository(); }
				 */

				/*
				 * stfcConnection = repo.getFunction("/ACNIP/RFC"); if
				 * (stfcConnection == null) throw new
				 * RuntimeException("/ACNIP/RFC not found in SAP.");
				 */
				JCoParameterList tabInput = stfcConnection.getTableParameterList();
				paramTable = tabInput.getTable("I_PARAM");
				for (int i = 0; i < viewConfigData.size(); i++) {
					if (viewConfigData.get(i) != null && !viewConfigData.get(i).equalsIgnoreCase("")) {
						paramTable.appendRow();
						paramTable.setValue("WA", viewConfigData.get(i));
					}
				}
				progTable = appUtilsObj.getABAPPrg(inputDTO.getUpldABAPPrgPath(), tabInput);
				// slf4jLogger.info("paramtable"+progTable);
				uploadResponseDto.setDstExecutionStatus(true);
				try {

					/*
					 * if(inputDTO.getIsCustomDestinationRequired().equals(
					 * "true")){ synchronized (this) {
					 * stfcConnection.execute(dynamicDestinationResDto.
					 * getCustomDestination()); } }else{
					 * stfcConnection.execute(destination); }
					 */
					stfcConnection.execute(destination);
				} catch (Throwable e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
					resultText.add("Configuration Failed: " + e);
					uploadResponseDto.setDstExecutionStatus(false);
					return uploadResponseDto;
				}
				resultTable = tabInput.getTable("O_RESULT");
				resultTableLen = resultTable.getNumRows();
				for (int i = 0; i < resultTableLen; i++) {
					resultTable.setRow(i);
					resultText.add(resultTable.getString("WA"));
				}
				resultParamTable = tabInput.getTable("I_PARAM");
				for (int i = 0; i < resultParamTable.getNumRows(); i++) {
					resultParamTable.setRow(i);
					tgtResultParamText.add(resultParamTable.getString("WA"));
				}
			} else {
				resultText.add("Template does not contain any configurable data, please check template and upload.");
			}
		} catch (AbapException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("Execution of RFC Failed: " + e);
			uploadResponseDto.setDstConnectionStatus(false);

		} catch (JCoException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("JCO Connection Failed: " + e);
			uploadResponseDto.setDstConnectionStatus(false);
		} catch (java.lang.NoClassDefFoundError e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("JCO Library Issue.  " + e);
			uploadResponseDto.setDstConnectionStatus(false);
		} catch (java.lang.ExceptionInInitializerError e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("JCO Library Issue. " + e);
			uploadResponseDto.setDstConnectionStatus(false);
		} catch (Exception e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("Configuration Failed: " + e);
			uploadResponseDto.setDstExecutionStatus(false);
		} catch (Throwable e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("Configuration Failed: " + e);
			uploadResponseDto.setDstExecutionStatus(false);
		} finally {
			uploadResponseDto.setResponseData(resultText);
			excelFormatUtil = null;
			viewConfigData = null;
			resultText = null;
			repo = null;
			dynamicDestinationDaoObj = null;
			dynamicDestinationResDto = null;
			destination = null;
			appUtilsObj = null;
			if (resultTable != null)
				resultTable.clear();
			if (resultParamTable != null)
				resultParamTable.clear();
			if (paramTable != null)
				paramTable.clear();
			if (progTable != null)
				progTable.clear();
			slf4jLogger.info("executeTargetSysConfig method ended");

		}
		return uploadResponseDto;
	}
	
	public UploadResponseDto executeTargetSysConfigCopyFunctionality(S4AutoConfigReqDto inputDTO) {
		slf4jLogger.info("executeTargetSysConfigCopyFunctionality method started");
		ArrayList<String> resultText = new ArrayList<>();
		UploadResponseDto uploadResponseDto = new UploadResponseDto();
		ArrayList<String> viewConfigData = null;
		JCoRepository repo = null;
		DynamicDestinationDAO dynamicDestinationDaoObj = new DynamicDestinationDAO();
		DynamicDestinationResDto dynamicDestinationResDto = new DynamicDestinationResDto();
		JCoDestination destination = null;
		AppUtils appUtilsObj = null;
		ExcelFormatConvert excelFormatUtil = null;
		ArrayList<String> tgtResultParamText = null;
		JCoTable resultTable = null;
		int resultTableLen = 0;
		JCoTable resultParamTable = null;
		JCoTable paramTable = null;
		JCoTable progTable = null;
		ImgHierarchyDAO imgHierarchyDAO = null;
		ArrayList<String> viewList = null;
		ConfigInputDTO configInputDTO = null;
		int recordCount = 0;
		String sapPassword = null;
		JCoFunction stfcConnection = null;
		try {
			tgtResultParamText = new ArrayList<String>();
			excelFormatUtil = new ExcelFormatConvert();
			appUtilsObj = new AppUtils();
			configInputDTO = new ConfigInputDTO();
			if (inputDTO.getImplType().equals("BrownField")) {
				viewConfigData = inputDTO.getConfigDataList();
			} else if (inputDTO.getImplType() != null && inputDTO.getImplType().equals("FilterData")) {

				configInputDTO = excelFormatUtil.getConfigDataForTargetSystem(inputDTO.getWorkbook(), viewList);
				viewConfigData = configInputDTO.getRecordByView();

			} else {
				imgHierarchyDAO = new ImgHierarchyDAO();
				viewList = imgHierarchyDAO.getViewBySequence(inputDTO.getScopeName());
				configInputDTO = excelFormatUtil.convertFormat(inputDTO.getFileBytes(), viewList);
				viewConfigData = configInputDTO.getRecordByView();

			}
			if (viewConfigData != null && viewConfigData.isEmpty()) {
				uploadResponseDto.setDstConnectionStatus(true);
				if (inputDTO.getImplType().equals("BrownField"))
					resultText.add(
							"Configurable data is required from Source system, please check selected source System.");
				else if (inputDTO.getImplType().equals("greenField"))
					resultText.add(
							"Uploaded file is not in correct file format. Note: Accepted file formats are .xls and .xlsx");
				else if (inputDTO.getImplType().equals("FilterData"))
					resultText.add("Configurable data is empty based on filter Request.");
			} else if (viewConfigData != null && viewConfigData.size() > 1) {
				// slf4jLogger.debug("Configuration size " +
				// viewConfigData.size());
				recordCount = Integer.parseInt(viewConfigData.get(viewConfigData.size() - 1).split("\\|")[2]);
				uploadResponseDto.setRecordCount(recordCount);
				uploadResponseDto.setDstConnectionStatus(false);

				if ((inputDTO.getCustomizingTr() != null && inputDTO.getCustomizingTr().trim().length() > 0)
						|| (inputDTO.getWorkbenchTr() != null && inputDTO.getWorkbenchTr().trim().length() > 0)) {
					StringBuilder imgTRnumber = new StringBuilder(viewConfigData.get(0));
					if (inputDTO.getCustomizingTr() != null) {
						imgTRnumber.append("|" + inputDTO.getCustomizingTr());
					} else {
						imgTRnumber.append("|");
					}
					if (inputDTO.getWorkbenchTr() != null) {
						imgTRnumber.append("|" + inputDTO.getWorkbenchTr());
					} else {
						imgTRnumber.append("|");
					}
					imgTRnumber.append("C1|");
					viewConfigData.set(0, imgTRnumber.toString());
				}
				String cipherTextSapPass = new String(java.util.Base64.getDecoder().decode(inputDTO.getSapPassword()));
				AesUtil aesUtil = new AesUtil(128, 1000);
				Properties connectProperties = new Properties();
				 if (cipherTextSapPass != null && cipherTextSapPass.split("::").length == 3) {   
				    	sapPassword = aesUtil.decrypt(cipherTextSapPass.split("::")[1], cipherTextSapPass.split("::")[0], inputDTO.getDestinationName(), cipherTextSapPass.split("::")[2]);
				      } 
			
				MyDestinationDataProvider myDestinationDataProvider = MyDestinationDataProvider.getInstance();
				/*
				 * String cipherTextSapPass = new
				 * String(java.util.Base64.getDecoder().decode(inputDTO.
				 * getSapPassword())); AesUtil aesUtil = new AesUtil(128, 1000);
				 */
				connectProperties.setProperty(DestinationDataProvider.JCO_DEST, inputDTO.getDestinationName());
				connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, inputDTO.getHostName());
				connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR,inputDTO.getSystemNo());
				connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, inputDTO.getSapClientNo());
									/*
					 * if (cipherTextSapPass != null &&
					 * cipherTextSapPass.split("::").length == 3) { sapPassword
					 * = aesUtil.decrypt(cipherTextSapPass.split("::")[1],
					 * cipherTextSapPass.split("::")[0],
					 * inputDTO.getDestinationName(),
					 * cipherTextSapPass.split("::")[2]); }
					 */
					// slf4jLogger.info("username"+inputDTO.getSapUserId()+inputDTO.getSapPassword()+inputDTO.getSapLanguage());
					connectProperties.setProperty(DestinationDataProvider.JCO_USER, inputDTO.getSapUserId());
					connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD, sapPassword);
					connectProperties.setProperty(DestinationDataProvider.JCO_LANG, inputDTO.getSapLanguage());
					
					if(inputDTO.getSapRouter()!=null) {
						connectProperties.setProperty(DestinationDataProvider.JCO_SAPROUTER, inputDTO.getSapRouter());
					}
					
				
					if(inputDTO.getSncEnabled()==1){
						connectProperties.setProperty(DestinationDataProvider.JCO_SNC_MODE, String.valueOf(inputDTO.getSncEnabled()));
						
						connectProperties.setProperty(DestinationDataProvider.JCO_SNC_MYNAME, inputDTO.getSncName());
						connectProperties.setProperty(DestinationDataProvider.JCO_SNC_PARTNERNAME, inputDTO.getSncPartnerName());
						
						connectProperties.setProperty(DestinationDataProvider.JCO_SNC_QOP, inputDTO.getSncProtectionLevel());
						connectProperties.setProperty(DestinationDataProvider.JCO_SNC_LIBRARY, System.getenv("SNC_LIB"));
					}
		
				// createDestinationDataFile(ConstantsValues.DESTINATION_NAMEK4A,
				// connectProperties);
				/*
				 * Set URL = connectProperties.keySet(); Iterator itr =
				 * URL.iterator();
				 * 
				 * while(itr.hasNext()) { String str = (String)itr.next();
				 * System.out.println("The URL for " + str + " is " +
				 * connectProperties.getProperty(str)); }
				 */
				myDestinationDataProvider.changePropertiesForABAP_AS(connectProperties);
				System.err.println("Data Provider" + Environment.isDestinationDataProviderRegistered());
				if (Environment.isDestinationDataProviderRegistered()) {
					System.err.println("inside if");
					Environment.unregisterDestinationDataProvider(myDestinationDataProvider);

				}
				Environment.registerDestinationDataProvider(myDestinationDataProvider);
				destination = JCoDestinationManager.getDestination(inputDTO.getDestinationName());
				// destination.ping();
				repo = destination.getRepository();
				uploadResponseDto.setDstConnectionStatus(true);
				stfcConnection = repo.getFunction("/ACNIP/RFC");
				if (stfcConnection == null) {

					dynamicDestinationResDto.setStatus(ConstantsValues.ERRORSTATUS);
					dynamicDestinationResDto.setMessage("/ACNIP/RFC not found in SAP.");
				} else {
					dynamicDestinationResDto.setStatus(ConstantsValues.SUCCESSSTATUS);
					dynamicDestinationResDto.setMessage("Connection To destination Established sucessfully");
				}
				/*
				 * if(inputDTO.getIsCustomDestinationRequired().equals("true")){
				 * 
				 * dynamicDestinationResDto =
				 * dynamicDestinationDaoObj.createCustomDestinationObject(
				 * inputDTO.getSapUserId(),
				 * inputDTO.getSapPassword(),inputDTO.getSapLanguage(),
				 * destination);
				 * if(dynamicDestinationResDto.getStatus().equals("Success"))
				 * repo =
				 * dynamicDestinationResDto.getCustomDestination().getRepository
				 * (); else resultText.
				 * add("Exception occured while creating custom Destination"); }
				 * else{ repo = destination.getRepository(); }
				 */

				/*
				 * stfcConnection = repo.getFunction("/ACNIP/RFC"); if
				 * (stfcConnection == null) throw new
				 * RuntimeException("/ACNIP/RFC not found in SAP.");
				 */
				JCoParameterList tabInput = stfcConnection.getTableParameterList();
				paramTable = tabInput.getTable("I_PARAM");
				for (int i = 0; i < viewConfigData.size(); i++) {
					if (viewConfigData.get(i) != null && !viewConfigData.get(i).equalsIgnoreCase("")) {
						paramTable.appendRow();
						paramTable.setValue("WA", viewConfigData.get(i));
					}
				}
				progTable = appUtilsObj.getABAPPrg(inputDTO.getUpldABAPPrgPath(), tabInput);
				// slf4jLogger.info("paramtable"+progTable);
				uploadResponseDto.setDstExecutionStatus(true);
				try {

					/*
					 * if(inputDTO.getIsCustomDestinationRequired().equals(
					 * "true")){ synchronized (this) {
					 * stfcConnection.execute(dynamicDestinationResDto.
					 * getCustomDestination()); } }else{
					 * stfcConnection.execute(destination); }
					 */
					stfcConnection.execute(destination);
				} catch (Throwable e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
					resultText.add("Configuration Failed: " + e);
					uploadResponseDto.setDstExecutionStatus(false);
					return uploadResponseDto;
				}
				resultTable = tabInput.getTable("O_RESULT");
				resultTableLen = resultTable.getNumRows();
				for (int i = 0; i < resultTableLen; i++) {
					resultTable.setRow(i);
					resultText.add(resultTable.getString("WA"));
				}
				resultParamTable = tabInput.getTable("I_PARAM");
				for (int i = 0; i < resultParamTable.getNumRows(); i++) {
					resultParamTable.setRow(i);
					tgtResultParamText.add(resultParamTable.getString("WA"));
				}
			} else {
				resultText.add("Template does not contain any configurable data, please check template and upload.");
			}
		} catch (AbapException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("Execution of RFC Failed: " + e);
			uploadResponseDto.setDstConnectionStatus(false);

		} catch (JCoException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("JCO Connection Failed: " + e);
			uploadResponseDto.setDstConnectionStatus(false);
		} catch (java.lang.NoClassDefFoundError e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("JCO Library Issue.  " + e);
			uploadResponseDto.setDstConnectionStatus(false);
		} catch (java.lang.ExceptionInInitializerError e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("JCO Library Issue. " + e);
			uploadResponseDto.setDstConnectionStatus(false);
		} catch (Exception e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("Configuration Failed: " + e);
			uploadResponseDto.setDstExecutionStatus(false);
		} catch (Throwable e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("Configuration Failed: " + e);
			uploadResponseDto.setDstExecutionStatus(false);
		} finally {
			uploadResponseDto.setResponseData(resultText);
			excelFormatUtil = null;
			viewConfigData = null;
			resultText = null;
			repo = null;
			dynamicDestinationDaoObj = null;
			dynamicDestinationResDto = null;
			destination = null;
			appUtilsObj = null;
			if (resultTable != null)
				resultTable.clear();
			if (resultParamTable != null)
				resultParamTable.clear();
			if (paramTable != null)
				paramTable.clear();
			if (progTable != null)
				progTable.clear();
			slf4jLogger.info("executeTargetSysConfigCopyFunctionality method ended");

		}
		return uploadResponseDto;
	}

	public UploadResponseDto checkTargetSysConfigCopyFunctionality(String data, HashMap<String, ArrayList<String>> copyFromTo, S4AutoConfigReqDto inputDTO) {
		slf4jLogger.info("checkTargetSysConfigCopyFunctionality method started");
		ArrayList<String> resultText = new ArrayList<>();
		UploadResponseDto uploadResponseDto = new UploadResponseDto();
		ArrayList<String> viewConfigData = null;
		JCoRepository repo = null;
		DynamicDestinationDAO dynamicDestinationDaoObj = new DynamicDestinationDAO();
		DynamicDestinationResDto dynamicDestinationResDto = new DynamicDestinationResDto();
		JCoDestination destination = null;
		AppUtils appUtilsObj = null;
		ExcelFormatConvert excelFormatUtil = null;
		ArrayList<String> tgtResultParamText = null;
		JCoTable resultTable = null;
		int resultTableLen = 0;
		JCoTable resultParamTable = null;
		JCoTable paramTable = null;
		JCoTable progTable = null;
		ImgHierarchyDAO imgHierarchyDAO = null;
		ArrayList<String> viewList = null;
		ConfigInputDTO configInputDTO = null;
		int recordCount = 0;
		String sapPassword = null;
		JCoFunction stfcConnection = null;
		ArrayList<String> from= new ArrayList<String>();
		from.addAll(copyFromTo.keySet());
		data=data+"|";
		for(String i:from)
		{
			for(String to:copyFromTo.get(i))
			{
				if(to.isEmpty())
					break;
				data=data+to+",";
			}
		}
		data=data.substring(0,data.length()-1);
		try {
			tgtResultParamText = new ArrayList<String>();
			excelFormatUtil = new ExcelFormatConvert();
			appUtilsObj = new AppUtils();
			configInputDTO = new ConfigInputDTO();

				String cipherTextSapPass = new String(java.util.Base64.getDecoder().decode(inputDTO.getSapPassword()));
				AesUtil aesUtil = new AesUtil(128, 1000);
				Properties connectProperties = new Properties();
				 if (cipherTextSapPass != null && cipherTextSapPass.split("::").length == 3) {   
				    	sapPassword = aesUtil.decrypt(cipherTextSapPass.split("::")[1], cipherTextSapPass.split("::")[0], inputDTO.getDestinationName(), cipherTextSapPass.split("::")[2]);
				      } 
			
				MyDestinationDataProvider myDestinationDataProvider = MyDestinationDataProvider.getInstance();
				/*
				 * String cipherTextSapPass = new
				 * String(java.util.Base64.getDecoder().decode(inputDTO.
				 * getSapPassword())); AesUtil aesUtil = new AesUtil(128, 1000);
				 */
				connectProperties.setProperty(DestinationDataProvider.JCO_DEST, inputDTO.getDestinationName());
				connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, inputDTO.getHostName());
				connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR,inputDTO.getSystemNo());
				connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, inputDTO.getSapClientNo());
									/*
					 * if (cipherTextSapPass != null &&
					 * cipherTextSapPass.split("::").length == 3) { sapPassword
					 * = aesUtil.decrypt(cipherTextSapPass.split("::")[1],
					 * cipherTextSapPass.split("::")[0],
					 * inputDTO.getDestinationName(),
					 * cipherTextSapPass.split("::")[2]); }
					 */
					// slf4jLogger.info("username"+inputDTO.getSapUserId()+inputDTO.getSapPassword()+inputDTO.getSapLanguage());
					connectProperties.setProperty(DestinationDataProvider.JCO_USER, inputDTO.getSapUserId());
					connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD, sapPassword);
					connectProperties.setProperty(DestinationDataProvider.JCO_LANG, inputDTO.getSapLanguage());
					
					if(inputDTO.getSapRouter()!=null) {
						connectProperties.setProperty(DestinationDataProvider.JCO_SAPROUTER, inputDTO.getSapRouter());
					}
					
				
					if(inputDTO.getSncEnabled()==1){
						connectProperties.setProperty(DestinationDataProvider.JCO_SNC_MODE, String.valueOf(inputDTO.getSncEnabled()));
						
						connectProperties.setProperty(DestinationDataProvider.JCO_SNC_MYNAME, inputDTO.getSncName());
						connectProperties.setProperty(DestinationDataProvider.JCO_SNC_PARTNERNAME, inputDTO.getSncPartnerName());
						
						connectProperties.setProperty(DestinationDataProvider.JCO_SNC_QOP, inputDTO.getSncProtectionLevel());
						connectProperties.setProperty(DestinationDataProvider.JCO_SNC_LIBRARY, System.getenv("SNC_LIB"));
					}
				// createDestinationDataFile(ConstantsValues.DESTINATION_NAMEK4A,
				// connectProperties);
				/*
				 * Set URL = connectProperties.keySet(); Iterator itr =
				 * URL.iterator();
				 * 
				 * while(itr.hasNext()) { String str = (String)itr.next();
				 * System.out.println("The URL for " + str + " is " +
				 * connectProperties.getProperty(str)); }
				 */
				myDestinationDataProvider.changePropertiesForABAP_AS(connectProperties);
				System.err.println("Data Provider" + Environment.isDestinationDataProviderRegistered());
				if (Environment.isDestinationDataProviderRegistered()) {
					System.err.println("inside if");
					Environment.unregisterDestinationDataProvider(myDestinationDataProvider);

				}
				Environment.registerDestinationDataProvider(myDestinationDataProvider);
				destination = JCoDestinationManager.getDestination(inputDTO.getDestinationName());
				// destination.ping();
				repo = destination.getRepository();
				uploadResponseDto.setDstConnectionStatus(true);
				stfcConnection = repo.getFunction("/ACNIP/RFC");
				if (stfcConnection == null) {

					dynamicDestinationResDto.setStatus(ConstantsValues.ERRORSTATUS);
					dynamicDestinationResDto.setMessage("/ACNIP/RFC not found in SAP.");
				} else {
					dynamicDestinationResDto.setStatus(ConstantsValues.SUCCESSSTATUS);
					dynamicDestinationResDto.setMessage("Connection To destination Established sucessfully");
				}
				/*
				 * if(inputDTO.getIsCustomDestinationRequired().equals("true")){
				 * 
				 * dynamicDestinationResDto =
				 * dynamicDestinationDaoObj.createCustomDestinationObject(
				 * inputDTO.getSapUserId(),
				 * inputDTO.getSapPassword(),inputDTO.getSapLanguage(),
				 * destination);
				 * if(dynamicDestinationResDto.getStatus().equals("Success"))
				 * repo =
				 * dynamicDestinationResDto.getCustomDestination().getRepository
				 * (); else resultText.
				 * add("Exception occured while creating custom Destination"); }
				 * else{ repo = destination.getRepository(); }
				 */

				/*
				 * stfcConnection = repo.getFunction("/ACNIP/RFC"); if
				 * (stfcConnection == null) throw new
				 * RuntimeException("/ACNIP/RFC not found in SAP.");
				 */
				JCoParameterList tabInput = stfcConnection.getTableParameterList();
				paramTable = tabInput.getTable("I_PARAM");
				paramTable.appendRow();
				paramTable.setValue("WA", data);
				
				progTable = appUtilsObj.getABAPPrg(inputDTO.getUpldABAPPrgPath(), tabInput);
				// slf4jLogger.info("paramtable"+progTable);
				uploadResponseDto.setDstExecutionStatus(true);
				try {

					/*
					 * if(inputDTO.getIsCustomDestinationRequired().equals(
					 * "true")){ synchronized (this) {
					 * stfcConnection.execute(dynamicDestinationResDto.
					 * getCustomDestination()); } }else{
					 * stfcConnection.execute(destination); }
					 */
					stfcConnection.execute(destination);
				} catch (Throwable e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
					resultText.add("Configuration Failed: " + e);
					uploadResponseDto.setDstExecutionStatus(false);
					return uploadResponseDto;
				}
				resultTable = tabInput.getTable("O_RESULT");
				resultTableLen = resultTable.getNumRows();
				for (int i = 0; i < resultTableLen; i++) {
					resultTable.setRow(i);
					resultText.add(resultTable.getString("WA"));
				}
				resultParamTable = tabInput.getTable("I_PARAM");
				for (int i = 0; i < resultParamTable.getNumRows(); i++) {
					resultParamTable.setRow(i);
					tgtResultParamText.add(resultParamTable.getString("WA"));
				}
			 
		} catch (AbapException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("Execution of RFC Failed: " + e);
			uploadResponseDto.setDstConnectionStatus(false);

		} catch (JCoException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("JCO Connection Failed: " + e);
			uploadResponseDto.setDstConnectionStatus(false);
		} catch (java.lang.NoClassDefFoundError e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("JCO Library Issue.  " + e);
			uploadResponseDto.setDstConnectionStatus(false);
		} catch (java.lang.ExceptionInInitializerError e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("JCO Library Issue. " + e);
			uploadResponseDto.setDstConnectionStatus(false);
		} catch (Exception e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("Configuration Failed: " + e);
			uploadResponseDto.setDstExecutionStatus(false);
		} catch (Throwable e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("Configuration Failed: " + e);
			uploadResponseDto.setDstExecutionStatus(false);
		} finally {
			uploadResponseDto.setResponseData(resultText);
			excelFormatUtil = null;
			viewConfigData = null;
			resultText = null;
			repo = null;
			dynamicDestinationDaoObj = null;
			dynamicDestinationResDto = null;
			destination = null;
			appUtilsObj = null;
			if (resultTable != null)
				resultTable.clear();
			if (resultParamTable != null)
				resultParamTable.clear();
			if (paramTable != null)
				paramTable.clear();
			if (progTable != null)
				progTable.clear();
			slf4jLogger.info("checkTargetSysConfigCopyFunctionality method ended");

		}
		return uploadResponseDto;
	}
	
	public ArrayList<DownloadScopeResDto> getScopeAvilability(String currentScope, String systemType, boolean copyFlag,boolean industryFlag, String industry, String subIndustry) {
		slf4jLogger.info("getScopeAvilability method started");
		ImgHierarchyDAO imgHierarchyDAO = new ImgHierarchyDAO();
		DownloadScopeResDto downloadScopeResDto = null;
		ArrayList<DownloadScopeResDto> listDownloadScopeResDto = new ArrayList<>();
		SystemMappingDao systemMappingDao = new SystemMappingDao();

		try {
			if(copyFlag) {
				downloadScopeResDto = imgHierarchyDAO.getInputStringForBrownFldForCopy(currentScope, systemType);
			}else if(industryFlag){
				downloadScopeResDto = imgHierarchyDAO.getInputStringForBrownFldForIndustry(currentScope, systemType, industry, subIndustry);
			}else {
				downloadScopeResDto = imgHierarchyDAO.getInputStringForBrownFld(currentScope, systemType);	
			}
			
			if (downloadScopeResDto.getScopeAvailable().equals("Y")) {
				listDownloadScopeResDto.add(downloadScopeResDto);
				isFieldMapRequired = false;
			} else if (systemType.equals("SAP ECC")) {
				isFieldMapRequired = true;
				ArrayList<String> srcMappedIMGIDList = new ArrayList<>();
				srcMappedIMGIDList = systemMappingDao.getTargetImgId(currentScope);
				if(copyFlag) {
					for (int j = 0; j < srcMappedIMGIDList.size(); j++) {
						downloadScopeResDto = imgHierarchyDAO.getInputStringForBrownFldForCopy(srcMappedIMGIDList.get(j),
								systemType);
						listDownloadScopeResDto.add(downloadScopeResDto);
					}
				}else if(industryFlag) {
					for (int j = 0; j < srcMappedIMGIDList.size(); j++) {
						downloadScopeResDto = imgHierarchyDAO.getInputStringForBrownFldForIndustry(srcMappedIMGIDList.get(j), 
								systemType, industry, subIndustry);		
						listDownloadScopeResDto.add(downloadScopeResDto);
					}
				}else {
					for (int j = 0; j < srcMappedIMGIDList.size(); j++) {
						downloadScopeResDto = imgHierarchyDAO.getInputStringForBrownFld(srcMappedIMGIDList.get(j),
								systemType);
						listDownloadScopeResDto.add(downloadScopeResDto);
					}
				}
				
			}
		} catch (Exception e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
		} finally {
			imgHierarchyDAO = null;
			downloadScopeResDto = null;
			systemMappingDao = null;
			slf4jLogger.info("getScopeAvilability method ended");

		}
		return listDownloadScopeResDto;
	}

	public InstalledBasedResDto dwldConfigFromABAP(ArrayList<DownloadScopeResDto> listDownloadScopeResDto,
			String srcSystem, String downloadPrgPath, ImgHierarchyCustomDto modCustomDto, String sapUserId,
			String destPasswrd, String language, String custDestReq, String sysNo, String destinationName,
			String hostName, String clientNo, boolean copyFlag, int sncEnabled,
			String sncName, String sncPartnerName, String sapRouter, String sncProtectionLevel, List<String> toPlants ) {
		slf4jLogger.info("dwldConfigFromABAP method started");// destName,destPasswrd,language,custDestReq
																// added by
																// Veena in the
																// above line
		ArrayList<ConfigDwldResDto> configDownloadList = new ArrayList<>();
		DownloadResponseDto downloadResponseDto = null;
		InstalledBasedResDto installedBasedResDto = new InstalledBasedResDto();
		try {
			for (DownloadScopeResDto scopeDto : listDownloadScopeResDto) {
				if (scopeDto.getScopeAvailable().equalsIgnoreCase("Y")) {
					downloadResponseDto = executeSrcConfigDownload_New(srcSystem, downloadPrgPath,
							scopeDto.getImgScope(), sapUserId, destPasswrd, language, custDestReq, sysNo, hostName,
							clientNo,copyFlag,sncEnabled,sncName, sncPartnerName, sapRouter,sncProtectionLevel, toPlants);///// //
										///// destName,destPasswrd,language,custDestReq
										///// added by Veena
					if (downloadResponseDto.isSrcConnectionStatus() && downloadResponseDto.isSrcExecutionStatus()) { // executeSrcConfigDownload
																														// renamed
																														// to
																														// executeSrcConfigDownload_new
																														// by
																														// Veena
						ArrayList<String> resultArray = downloadResponseDto.getDownloadRes();
						ConfigDwldResDto configDwldRes = new ConfigDwldResDto();
						configDwldRes.setImgId(scopeDto.getImgId());
						configDwldRes.setConfigDwldData(resultArray);
						configDownloadList.add(configDwldRes);
						installedBasedResDto.setConfigDownloadList(configDownloadList);
					} else if (!downloadResponseDto.isSrcExecutionStatus()) {
						installedBasedResDto.setConfigDownloadList(configDownloadList);
						installedBasedResDto.setResMessage(downloadResponseDto.getErrorDetails());
						break;
					} else {
						configDownloadList = null;
						installedBasedResDto.setConfigDownloadList(configDownloadList);
					}
				}
			}
		} catch (Exception e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
		} finally {
			downloadResponseDto = null;
			slf4jLogger.info("dwldConfigFromABAP method ended");

		}

		return installedBasedResDto;
	}

	public void createModTemplate(ImgHierarchyCustomDto modCustomDto, ArrayList<ConfigDwldResDto> configDownloadList,
			int docId, String fileName,boolean industryFlag, boolean copyFlag) {
		slf4jLogger.info("createModTemplate method started");
		// slf4jLogger.info("file name"+fileName);
		ByteArrayOutputStream bos = null;
		HashMap<String, FieldMappingDto> fieldMap = new HashMap<String, FieldMappingDto>();
		ArrayList<String> columnList = new ArrayList<String>();
		ArrayList<String> columnList_Filter = new ArrayList<String>();
		String currentViewName = "";
		SystemMappingDao systemMappingDao = new SystemMappingDao();
		boolean validTemplate = false;
		Document document = null;
		InputStream stream = null, stream1 = null;
		XSSFWorkbook workBook = null, filterWorkBook = null;
		Session openCmisSession = null;
		StringBuffer warningMsg = new StringBuffer();
		int columnListSize = 0;
		IMGFilterDao imgFilterDao = new IMGFilterDao();
		XSSFSheet sheet = null, filterSheet = null;
		int lastRowNumber = 0;
		Row selectedRow = null, filterRow = null;
		Cell cell = null, filterCell = null;
		ArrayList<Integer> filterIndex = null;
		ArrayList<Integer> tempfilterList = null;

		Cell currentCell = null;
		boolean filterCriteria = false;
		String key = "";
		int filterColumn = -1;
		ArrayList<String> fieldValList = null;
		Iterator<Cell> currentCellIterator = null;
		String tempCellValue = "";
		int count = 5;
		FieldMappingDto fieldMappingDtoObj = null;
		ArrayList<String> retrievedValueList = null;
		FieldMappingDto selectedFieldDto = null;
		String currentSourceView = "";
		String currentSourceField = "";
		ArrayList<String> selectedOutputList = null;
		String currentSize = "";
		String currentValue = "";
		String searchValue = "";
		int dataRow = 0;
		Cell particularCell = null;
		String retrievefile = modCustomDto.getSeqNumber() + "_" + modCustomDto.getImgDesc();
		// slf4jLogger.info("retrievefile name"+retrievefile);
		int configDownloadListSize, selectedOutputListSize, retrievedValueListSize, totalRow, filterIndexSize;
		try {
			/*
			 * openCmisSession = HCPDocDAO.ConnectDocumentStore(); document =
			 * (Document) openCmisSession.getObject(docId);
			 */
			Connection con = null;
			PreparedStatement pStmt = null;
			ResultSet rs = null;
			retrievefile=retrievefile.replaceAll("[^a-zA-Z0-9]", "").toLowerCase();
			String storeDocIdQuery ="";
			if(industryFlag && !copyFlag) {
				 storeDocIdQuery = "select file_blob from industry_documentstore where IMGDESC=?";
			}else {
				 storeDocIdQuery = "select file_blob from documentstore where IMGDESC=?";
			}
		

			try {
				con = DBConnection.createConnection();
				pStmt = (PreparedStatement) con.prepareStatement(storeDocIdQuery);
				pStmt.setString(1, fileName);
				rs = pStmt.executeQuery();
				while (rs.next()) {
					stream = rs.getBinaryStream("file_blob");
					stream1 = rs.getBinaryStream("file_blob");
					// slf4jLogger.info("file stream"+stream);
				}
			} catch (Exception e) {

			}
			// stream = document.getContentStream().getStream();
			workBook = new XSSFWorkbook(stream);
			int numberofSheet = workBook.getNumberOfSheets();
			HashMap<String, ArrayList<String>> filterMap = imgFilterDao.getIMGFilterValues(modCustomDto.getImgId());
			if (!filterMap.isEmpty()) {
				// stream1 = document.getContentStream().getStream();
				filterWorkBook = new XSSFWorkbook(stream1);
			}
			for (int num = 0; num < numberofSheet; num++) {
				currentViewName = workBook.getSheetName(num).replaceAll("~", "/");
				if (currentViewName.equalsIgnoreCase("Instruction Sheet"))
					continue;
				columnList.clear();
				columnList_Filter.clear();
				sheet = workBook.getSheetAt(num);
				lastRowNumber = sheet.getLastRowNum();
				selectedRow = sheet.getRow(3);
				if (selectedRow != null) {
					currentCellIterator = selectedRow.cellIterator();
					for (int cellCount = 0; currentCellIterator.hasNext(); cellCount++) {
						cell = currentCellIterator.next();
						if (cellCount == 0)
							continue;
						if (cell != null) {
							cell.setCellType(Cell.CELL_TYPE_STRING);
							columnList.add(cell.getStringCellValue());
							columnList_Filter.add(currentViewName + cell.getStringCellValue());
						}
					}
					columnListSize = columnList.size();
				}
				selectedRow = sheet.getRow(5);
				if (selectedRow != null) {
					currentCellIterator = selectedRow.cellIterator();
					for (int cellCount = 0; currentCellIterator.hasNext(); cellCount++) {
						cell = currentCellIterator.next();
						if (cellCount == 0) {
							if (cell != null) {
								cell.setCellType(Cell.CELL_TYPE_STRING);
								tempCellValue = cell.getStringCellValue();
							}

							break;
						}
					}
				}

				count = 5;
				while (count <= lastRowNumber) {
					selectedRow = sheet.getRow(count);
					if (selectedRow != null)
						sheet.removeRow(selectedRow);
					count++;
				}
				selectedRow = sheet.createRow(5);
				cell = selectedRow.createCell(0, Cell.CELL_TYPE_STRING);
				cell.setCellValue(tempCellValue);
				if (isFieldMapRequired) {
					fieldMap = systemMappingDao.getFieldMapByView(modCustomDto.getImgId(), currentViewName);
				} else {
					fieldMap = new HashMap<String, FieldMappingDto>();
					for (int k = 0; k < columnListSize; k++) {
						fieldMappingDtoObj = new FieldMappingDto();
						fieldMappingDtoObj.setS_IMGID(modCustomDto.getImgId());
						fieldMappingDtoObj.setS_VIEW(currentViewName);
						fieldMappingDtoObj.setS_FIELD(columnList.get(k));
						fieldMap.put(columnList.get(k), fieldMappingDtoObj);

					}
				}

				for (int currField = 0; currField < columnListSize; currField++) {
					retrievedValueList = new ArrayList<String>();
					selectedFieldDto = fieldMap.get(columnList.get(currField));
					if (selectedFieldDto != null) {
						currentSourceView = selectedFieldDto.getS_VIEW();
						currentSourceField = selectedFieldDto.getS_FIELD();
						selectedOutputList = new ArrayList<String>();
						configDownloadListSize = configDownloadList.size();
						for (int s = 0; s < configDownloadListSize; s++) {
							ConfigDwldResDto configDwldRes = configDownloadList.get(s);
							if (configDwldRes.getImgId().equalsIgnoreCase(selectedFieldDto.getS_IMGID())) {
								selectedOutputList = configDwldRes.getConfigDwldData();
								break;
							}
						}
						if (!selectedOutputList.isEmpty()) {
							int value = 0;
							currentSize = "";
							currentValue = "";
							searchValue = currentSourceField;
							currentSourceView = "|" + currentSourceView + "|";
							currentSourceField = "|" + currentSourceField + "|";
							if (warningMsg.length() <= 0) {
								if (selectedOutputList.size() > 2) {
									if (selectedOutputList.get(1).startsWith("M~"))
										warningMsg.append(selectedOutputList.get(1).split("~")[1] + ". ");
								}
							}
							// slf4jLogger.error("selectedOutputListSize"+selectedOutputList);
							selectedOutputListSize = selectedOutputList.size();
							for (int e = 0; e < selectedOutputListSize; e++) {
								if (selectedOutputList.get(e).contains(currentSourceView)
										&& selectedOutputList.get(e).contains(currentSourceField)) {
									currentValue = selectedOutputList.get(e);
									// slf4jLogger.error("currentValue"+currentValue);
									value = retrievedValueList.size() + 1;
									if (currentValue.split("\\|").length > 3) {
										currentSize = currentValue.split("\\|")[2];
										if (currentSize != null && currentSize != "") {
											try {
												while (Integer.parseInt(currentSize) > value) {
													retrievedValueList.add("");
													value++;
												}
											} catch (NumberFormatException ex) {
												slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, ex);
											}
										}
									}
									if (currentValue.split(searchValue).length > 1) {

										retrievedValueList.add(
												currentValue.split(searchValue)[currentValue.split(searchValue).length
														- 1].substring(1));
									}
								}
							}
						}
						// slf4jLogger.error("retrievedValueList"+retrievedValueList);
						dataRow = 5;
						particularCell = null;
						retrievedValueListSize = retrievedValueList.size();
						for (int w = 0; w < retrievedValueListSize; w++) {
							selectedRow = sheet.getRow(dataRow);
							if (selectedRow == null) {
								selectedRow = sheet.createRow(dataRow);
								selectedRow.createCell(0, Cell.CELL_TYPE_STRING);
							}

							particularCell = selectedRow.getCell(currField + 1);
							if (particularCell == null) {
								particularCell = selectedRow.createCell(currField + 1, Cell.CELL_TYPE_STRING);
							}
							particularCell.setCellValue(retrievedValueList.get(w));
							validTemplate = true;
							dataRow++;
						}
					}
				}
				filterCriteria = false;
				key = "";
				filterColumn = -1;
				fieldValList = null;

				if (!filterMap.isEmpty()) {
					filterIndex = new ArrayList<Integer>();
					totalRow = sheet.getLastRowNum();
					filterIndexSize = 0;
					for (int i = 5; i <= totalRow; i++) {
						filterIndex.add(i);
					}
					for (Entry<String, ArrayList<String>> entry : filterMap.entrySet()) {
						key = entry.getKey();
						if (columnList_Filter.contains(key)) {
							filterColumn = columnList_Filter.indexOf(key);
							if (filterColumn >= 0) {
								fieldValList = entry.getValue();
								tempfilterList = new ArrayList<Integer>();
								filterIndexSize = filterIndex.size();
								for (int i = 0; i < filterIndexSize; i++) {
									filterCriteria = false;
									selectedRow = sheet.getRow(filterIndex.get(i));
									if (selectedRow != null) {
										currentCell = selectedRow.getCell(filterColumn + 1);
										if (currentCell != null) {
											currentCell.setCellType(Cell.CELL_TYPE_STRING);
											String cellVal = currentCell.getStringCellValue();
											for (String val : fieldValList) {
												if (val.endsWith("^")) {
													if (cellVal.startsWith(val.substring(0, val.length() - 1))) {
														filterCriteria = true;
														break;
													}
												} else if (val.equalsIgnoreCase(cellVal)) {
													filterCriteria = true;
													break;
												}
											}
										} else {
											break;
										}
									} else {
										break;
									}

									if (filterCriteria) {
										tempfilterList.add(filterIndex.get(i));
									}

								}
								filterIndex.clear();
								filterIndex.addAll(tempfilterList);
								tempfilterList = null;
							}
						}
					}

				}

				if (!filterMap.isEmpty()) {
					filterSheet = filterWorkBook.getSheetAt(num);
					filterIndexSize = filterIndex.size();
					for (int i = 0; i < filterIndexSize; i++) {
						filterRow = filterSheet.createRow(i + 5);
						selectedRow = sheet.getRow(filterIndex.get(i));
						if (selectedRow != null) {
							for (int cellCount = 0; cellCount <= columnListSize; cellCount++) {
								cell = selectedRow.getCell(cellCount);
								if (cell != null) {
									cell.setCellType(Cell.CELL_TYPE_STRING);
									filterCell = filterRow.createCell(cellCount, Cell.CELL_TYPE_STRING);
									filterCell.setCellValue(cell.getStringCellValue());
								}
							}
						}
					}
				}

			}

			if (filterMap.isEmpty()) {
				bos = new ByteArrayOutputStream();
				workBook.write(bos);
			} else {
				bos = new ByteArrayOutputStream();
				filterWorkBook.write(bos);
			}

			byte[] bytes = bos.toByteArray();
			modCustomDto.setBytes(bytes);
			modCustomDto.setDownloadStatus(false);
			modCustomDto.setDownloadStatusIcon("glyphicon glyphicon-ok");
			if (validTemplate) {
				if (warningMsg.length() > 0) {
					modCustomDto.setResError("Template Downloaded Successfully.But, " + warningMsg);
				} else {
					modCustomDto.setResError("Template Downloaded Successfully");
				}
			} else {
				modCustomDto.setResError(
						"Template was downloaded without data as SAP System does not have data for this IMG. Please verify before uploading..");
			}
		} catch (Exception e) {
			modCustomDto
					.setResError("Template could not be downloaded due to some error. Please contact System Administrator");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
		} finally {
			try {
				if (workBook != null)
					workBook.close();
				workBook = null;
				if (bos != null)
					bos.close();
				bos = null;
				fieldMap = null;
				columnList = null;
				systemMappingDao = null;
				stream = null;
				document = null;
				openCmisSession = null;
			} catch (IOException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			}
			slf4jLogger.info("createModTemplate method ended");

		}
	}

	public void createEmptyModTemplate(ImgHierarchyCustomDto modCustomDto, int docId, String fileName, boolean industryFlag, boolean copyFlag) {
		slf4jLogger.info("createEmptyModTemplate method started");
		ByteArrayOutputStream bos = null;
		ArrayList<String> columnList = new ArrayList<String>();
		boolean validTemplate = false;
		Document document = null;
		InputStream stream = null;
		XSSFWorkbook workbook = null;
		Session openCmisSession = null;
		try {
			/*
			 * openCmisSession = HCPDocDAO.ConnectDocumentStore(); document =
			 * (Document) openCmisSession.getObject(docId); stream =
			 * document.getContentStream().getStream();
			 */
			Connection con = null;
			PreparedStatement pStmt = null;
			ResultSet rs = null;
			String retrievefile = modCustomDto.getSeqNumber() + "_" + modCustomDto.getImgDesc();
			retrievefile=retrievefile.replaceAll("[^a-zA-Z0-9]", "").toLowerCase();
			String storeDocIdQuery ="";
			
			if(industryFlag && !copyFlag) {
				 storeDocIdQuery = "select file_blob from industry_documentstore where IMGDESC=?";
			}else {
				 storeDocIdQuery = "select file_blob from documentstore where IMGDESC=?";
			}
			

			try {
				con = DBConnection.createConnection();
				pStmt = (PreparedStatement) con.prepareStatement(storeDocIdQuery);
				pStmt.setString(1, fileName);
				rs = pStmt.executeQuery();
				while (rs.next()) {
					stream = rs.getBinaryStream("file_blob");

					// stream1 = rs.getBinaryStream("file_blob");
				}
			} catch (Exception e) {

			}
			workbook = new XSSFWorkbook(stream);
			int numberofSheet = workbook.getNumberOfSheets();
			for (int num = 0; num < numberofSheet; num++) {
				if (workbook.getSheetName(num).equalsIgnoreCase("Instruction Sheet"))
					continue;
				columnList.clear();
				String tempCellValue = "";
				XSSFSheet sheet = workbook.getSheetAt(num);

				int lastRowNumber = sheet.getLastRowNum();
				Row selectedRow = sheet.getRow(3);
				Iterator<Cell> currentCellIterator;

				if (selectedRow != null) {
					currentCellIterator = selectedRow.cellIterator();
					for (int cellCount = 0; currentCellIterator.hasNext(); cellCount++) {
						Cell cell = currentCellIterator.next();
						if (cellCount == 0)
							continue;
						if (cell != null) {
							cell.setCellType(Cell.CELL_TYPE_STRING);
							columnList.add(cell.getStringCellValue());
						}
					}
				}

				selectedRow = sheet.getRow(5);
				if (selectedRow != null) {
					currentCellIterator = selectedRow.cellIterator();
					for (int cellCount = 0; currentCellIterator.hasNext(); cellCount++) {
						Cell cell = currentCellIterator.next();
						if (cellCount == 0) {
							if (cell != null) {
								cell.setCellType(Cell.CELL_TYPE_STRING);
								tempCellValue = cell.getStringCellValue();
							}
							break;
						}
					}
				}

				int count = 5;

				while (count <= lastRowNumber) {
					selectedRow = sheet.getRow(count);
					if (selectedRow != null)
						sheet.removeRow(selectedRow);
					count++;
				}

				selectedRow = sheet.createRow(5);
				Cell newCell = selectedRow.createCell(0);
				newCell.setCellType(Cell.CELL_TYPE_STRING);
				newCell.setCellValue(tempCellValue);

			}

			bos = new ByteArrayOutputStream();
			workbook.write(bos);
			byte[] bytes = bos.toByteArray();
			modCustomDto.setBytes(bytes);
			modCustomDto.setDownloadStatus(false);
			modCustomDto.setDownloadStatusIcon("glyphicon glyphicon-ok");
			if (validTemplate) {
				modCustomDto.setResError("Template Downloaded Successfully");
			} else {
				modCustomDto.setResError(
						"Template was downloaded without data as no scope is available in DB for this IMG. Please verify before uploading..");
			}
		} catch (Exception e) {
			modCustomDto
					.setResError("Empty Template (Scope not available) could not be created due to some error. Please contact System Administrator");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
		} finally {
			try {
				if (workbook != null)
					workbook.close();
				workbook = null;
				if (bos != null)
					bos.close();
				bos = null;
				columnList = null;
				document = null;
				stream = null;
				openCmisSession = null;
			} catch (IOException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			}
			slf4jLogger.info("createEmptyModTemplate method ended");

		}
	}

	public ImgHierarchyCustomDto getDwldScopeForBrwnMod(BrownFieldModDownloadDto brownFieldModDownloadDto,
			HttpServletRequest request) {
		slf4jLogger.info("getDwldScopeForBrwnMod method started for Img: "+brownFieldModDownloadDto.getImgHierarchyCustomDto().getImgDesc()+
				" Imgid: "+brownFieldModDownloadDto.getImgHierarchyCustomDto().getImgId());
		ConfigAuditDAO configAuditDao = new ConfigAuditDAO();
		ConfigDownloadHistoryDto configDownloadHistoryDto = new ConfigDownloadHistoryDto();
		String key = "RRn4PlfhPT6rXtZP";
		ImgHierarchyCustomDto modCustomDto = new ImgHierarchyCustomDto();
		ArrayList<ConfigDwldResDto> configDownloadList = new ArrayList<>();
		String webAppPath = request.getServletContext().getRealPath("/WEB-INF");
		String webAppPath1 = request.getServletContext().getRealPath("/src/css");

		File encryptedFile = new File(webAppPath + "/ACNIPIMG_DOWNLOAD.txt");
		File decryptedFile = new File(webAppPath1 + "/ACNIPIMG_DOWNLOAD.txt");
		List<String> toPlantsList = new ArrayList<String>();
		try {

			// slf4jLogger.info("before decryption");
			AESEncrypt.decrypt(key, encryptedFile, decryptedFile);
			// slf4jLogger.info("after decryption");
		} catch (CryptoException ex) {
			// System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
		Date date = new java.util.Date();
		Timestamp downloadStartTime = new java.sql.Timestamp(date.getTime());
		configDownloadHistoryDto.setDownloadStartTime(downloadStartTime);
		String downloadPrgPath = webAppPath1 + File.separator + "ACNIPIMG_DOWNLOAD.txt";

		ImgHierarchyCustomDto imgCustomDto = brownFieldModDownloadDto.getImgHierarchyCustomDto();
		ArrayList<DownloadScopeResDto> listDownloadScopeResDto = new ArrayList<>();
		InstalledBasedResDto installedBasedResDto = new InstalledBasedResDto();
		int docId = 0;
		HCPDocDAO hcpDocDAOobj = new HCPDocDAO();

		modCustomDto.setImgDesc(imgCustomDto.getImgDesc());
		modCustomDto.setImgId(imgCustomDto.getImgId());
		modCustomDto.setSeqNumber(imgCustomDto.getSeqNumber());
		modCustomDto.setDownloadStatus(true);
		modCustomDto.setDownloadStatusIcon("glyphicon glyphicon-remove");
		String fileName = "";
		if (imgCustomDto.getIsMasterData() != null && imgCustomDto.getIsMasterData().equalsIgnoreCase("Y")) {
			if(brownFieldModDownloadDto.isIndustryFlag() && !brownFieldModDownloadDto.getCopyFlag()) {
				fileName = imgCustomDto.getImgDesc()+"_"+brownFieldModDownloadDto.getIndustryAlias()
				+"_"+brownFieldModDownloadDto.getSubIndustryAlias().replaceAll("[\\/:*?\"<>|\\\\]", " ");
			}else {
				fileName = imgCustomDto.getImgDesc().replaceAll("[\\/:*?\"<>|\\\\]", " ");
			}
			
		}		
		else {
			if(brownFieldModDownloadDto.isIndustryFlag() && !brownFieldModDownloadDto.getCopyFlag()) {
				fileName = imgCustomDto.getSeqNumber() + "_"
						+ imgCustomDto.getImgDesc()+"_"+brownFieldModDownloadDto.getIndustryAlias()
						+"_"+brownFieldModDownloadDto.getSubIndustryAlias().replaceAll("[\\/:*?\"<>|\\\\]", " ");
				
			}
			else {
				fileName = imgCustomDto.getSeqNumber() + "_"
						+ imgCustomDto.getImgDesc().replaceAll("[\\/:*?\"<>|\\\\]", " ");
			}
		
			}
		if(brownFieldModDownloadDto.isIndustryFlag() && !brownFieldModDownloadDto.getCopyFlag()) {
			docId = hcpDocDAOobj.getDocumentIdForIndustry(fileName.replaceAll("[^a-zA-Z0-9]", "").toLowerCase(), "BASE");
		}else {
			docId = hcpDocDAOobj.getDocumentId(fileName.replaceAll("[^a-zA-Z0-9]", "").toLowerCase(), "BASE");
		}
		
		configDownloadHistoryDto.setImgID(imgCustomDto.getImgId());
		configDownloadHistoryDto.setTransactionID(brownFieldModDownloadDto.getTransactionID());
		try {
			listDownloadScopeResDto = getScopeAvilability(imgCustomDto.getImgId(),
					brownFieldModDownloadDto.getSystemType(), brownFieldModDownloadDto.getCopyFlag(), brownFieldModDownloadDto.isIndustryFlag(), 
					brownFieldModDownloadDto.getIndustry(), brownFieldModDownloadDto.getSubIndustry());
			modCustomDto.setDownloadScopeResList(listDownloadScopeResDto);
			if (listDownloadScopeResDto.isEmpty()) {
				if (docId > 0) {
					modCustomDto.setScopeAvilable(!isFieldMapRequired);
					if (isFieldMapRequired)
						modCustomDto.setScopeAvilableIcon("glyphicon glyphicon-remove");
					else
						modCustomDto.setScopeAvilableIcon("glyphicon glyphicon-ok");
					createEmptyModTemplate(modCustomDto, docId, fileName.replaceAll("[^a-zA-Z0-9]", "").toLowerCase(),brownFieldModDownloadDto.isIndustryFlag(),brownFieldModDownloadDto.getCopyFlag());

				} else {
					modCustomDto.setScopeAvilable(!isFieldMapRequired);
					if (isFieldMapRequired)
						modCustomDto.setScopeAvilableIcon("glyphicon glyphicon-remove");
					else
						modCustomDto.setScopeAvilableIcon("glyphicon glyphicon-ok");
					modCustomDto.setResError(imgCustomDto.getImgDesc()
							+ " Config Template and Scope is not available in the System. Please contact System Administrator");
				}
			} else {
				if(brownFieldModDownloadDto.getCopyFlag()) {
					//String parentImg = findParentImg(imgCustomDto.getImgId());
		            CheckToPlantDto checkToPlantDto=new CheckToPlantDto();
		            checkToPlantDto=checkToPlants(imgCustomDto.getImgId(), brownFieldModDownloadDto.getOmId());
					toPlantsList =checkToPlantDto.getToPlantsList(); 
				}
        		
				modCustomDto.setScopeAvilable(!isFieldMapRequired);
				if (isFieldMapRequired)
					modCustomDto.setScopeAvilableIcon("glyphicon glyphicon-remove");
				else
					modCustomDto.setScopeAvilableIcon("glyphicon glyphicon-ok");
				if (docId > 0) {
					
					installedBasedResDto = dwldConfigFromABAP(

							listDownloadScopeResDto, brownFieldModDownloadDto.getSrcSystem(), downloadPrgPath,
							modCustomDto, brownFieldModDownloadDto.getSapUserId(),
							brownFieldModDownloadDto.getDestPasswrd(), brownFieldModDownloadDto.getLanguage(),
							brownFieldModDownloadDto.getCustDestReq(), brownFieldModDownloadDto.getSysNo(),
							brownFieldModDownloadDto.getDestinationName(), brownFieldModDownloadDto.getHostName(),
							brownFieldModDownloadDto.getClientNo(),brownFieldModDownloadDto.getCopyFlag(),brownFieldModDownloadDto.getSncEnabled(),
							brownFieldModDownloadDto.getSncName(), brownFieldModDownloadDto.getSncPartnerName(), 
							brownFieldModDownloadDto.getSapRouter(),brownFieldModDownloadDto.getSncProtectionLevel(),toPlantsList);////
					configDownloadList = installedBasedResDto.getConfigDownloadList();// destName,destPasswrd,language,custDestReq
																						// added
																						// by
																						// Veena
					if (configDownloadList == null) {
						modCustomDto.setResError(brownFieldModDownloadDto.getSrcSystem()
								+ " is currently not reachable, please contact Administrator");
						modCustomDto.setBytes(null);
						modCustomDto.setDownloadStatus(true);
						modCustomDto.setDownloadStatusIcon("glyphicon glyphicon-remove");
					} else if (installedBasedResDto.getResMessage() != null) {
						modCustomDto.setResError(installedBasedResDto.getResMessage());
						modCustomDto.setBytes(null);
						modCustomDto.setDownloadStatus(true);
						modCustomDto.setDownloadStatusIcon("glyphicon glyphicon-remove");
					} else if (configDownloadList.size() > 0) {
						// slf4jLogger.debug("Downloaded Config Size :
						// "+configDownloadList.size());
						createModTemplate(modCustomDto, configDownloadList, docId, fileName.replaceAll("[^a-zA-Z0-9]", "").toLowerCase(),brownFieldModDownloadDto.isIndustryFlag(),brownFieldModDownloadDto.getCopyFlag());
					} else {
						createEmptyModTemplate(modCustomDto, docId, fileName.replaceAll("[^a-zA-Z0-9]", "").toLowerCase(), brownFieldModDownloadDto.isIndustryFlag(),brownFieldModDownloadDto.getCopyFlag());
					}
				} else {
					modCustomDto.setResError(imgCustomDto.getImgDesc()
							+ " Config Template is not available in the System. Please contact System Administrator");
				}
			}

			configDownloadHistoryDto.setStatus(modCustomDto.isDownloadStatus() ? "E" : "S");
			configDownloadHistoryDto.setMessage(modCustomDto.getResError());
			configAuditDao.createConfigDwdHistory(configDownloadHistoryDto);
		} catch (Exception e) {
			modCustomDto.setResError(e.getLocalizedMessage());
			configDownloadHistoryDto.setStatus(modCustomDto.isDownloadStatus() ? "E" : "S");
			configDownloadHistoryDto.setMessage(modCustomDto.getResError());
			configAuditDao.createConfigDwdHistory(configDownloadHistoryDto);// Added
																			// for
																			// download
																			// Logs
																			// if
																			// exception
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			return modCustomDto;
		}

		finally {
			configAuditDao = null;
			configDownloadHistoryDto = null;
			configDownloadList = null;
			imgCustomDto = null;
			listDownloadScopeResDto = null;
			hcpDocDAOobj = null;
			slf4jLogger.info("getDwldScopeForBrwnMod method ended");
			String webAppPath2 = request.getServletContext().getRealPath("/src/css");

			File file = new File(webAppPath2 + "/ACNIPIMG_DOWNLOAD.txt");

			if (file.delete()) {
				// System.out.println(" File deleted");
			}
			// else System.out.println(" doesn't exist");

		}
		return modCustomDto;
	}
	
	public String findParentImg(String imgId) {
		
		String sql = "SELECT A.IMGID FROM COPYFUNCTIONALITY_IMGHIERARCHY A INNER JOIN COPYFUNCTIONALITY_IMGHIERARCHY B ON A.IMGID = B.IMGID "
				+ "WHERE A.NODELEVEL = (SELECT NODELEVEL FROM COPYFUNCTIONALITY_IMGHIERARCHY WHERE IMGID =?)-1 AND A.COPY_FIELD = B.COPY_FIELD";
		Connection con = null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String parentImg =null;
		
		try {
    		con =  DBConnection.createConnection();
    		ps = con.prepareStatement(sql);  		
    		
    			ps.setString(1, imgId);	
    			rs = ps.executeQuery();
    			
    			if(rs.next()){
    				parentImg = rs.getString("IMGID");
    				
    			}
		}catch (SQLException e){
    		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
    	
    	}finally {
    		if(rs!=null){
				try {
					rs.close();
					rs=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
    		if(ps!=null){
				try {
					ps.close();
					ps=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
    	}
		return parentImg;
	}
public ArrayList<String> findChildImgs(String imgId) {
		
		String sql = "SELECT IMGID FROM COPYFUNCTIONALITY_IMGHIERARCHY WHERE NODELEVEL = (SELECT NODELEVEL FROM COPYFUNCTIONALITY_IMGHIERARCHY WHERE IMGID =?)+1 "
				+ "AND COPY_FIELD = (SELECT COPY_FIELD FROM COPYFUNCTIONALITY_IMGHIERARCHY WHERE IMGID =?)";
		Connection con = null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		ArrayList<String> childImgs =new ArrayList<>();
		
		try {
    		con =  DBConnection.createConnection();
    		ps = con.prepareStatement(sql);  		
    		
    			ps.setString(1, imgId);	
    			ps.setString(2, imgId);	
    			rs = ps.executeQuery();
    			
    			while(rs.next()){
    				childImgs.add(rs.getString("IMGID"));
    			}
		}catch (SQLException e){
    		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
    	
    	}finally {
    		if(rs!=null){
				try {
					rs.close();
					rs=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
    		if(ps!=null){
				try {
					ps.close();
					ps=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
    	}
		return childImgs;
	}

	public CheckToPlantDto checkToPlants(String imgId, String omID) {
		
		Connection con = null;
		PreparedStatement psForPlant=null;
		ResultSet plantRs=null;
		ArrayList<String> toPlantList = new ArrayList<String>();
		HashMap<String,String> error=new HashMap<String,String>() ;
        CheckToPlantDto checkToPlantDto=new CheckToPlantDto();
		
		try {
    		con =  DBConnection.createConnection();			
    			String sqlForPlant = "SELECT VALUE, ERROR FROM CLIENT_COPYVALUES WHERE IMGID=? AND OMID=? AND COMPLETED =?";
    			if(imgId!=null && !imgId.equals("")) {
    				
    				psForPlant = con.prepareStatement(sqlForPlant);
    				psForPlant.setString(1,imgId);
    				psForPlant.setString(2,omID);
    				psForPlant.setBoolean(3, false);
    				plantRs = psForPlant.executeQuery();
    				
    				while(plantRs.next()) {
    					String toPlant = plantRs.getString("VALUE");
					if (plantRs.getString("ERROR")!=null && !plantRs.getString("ERROR").isEmpty()) {
						if(!error.keySet().contains(plantRs.getString("ERROR")))
							error.put(plantRs.getString("ERROR"),toPlant);
						else
							error.put(plantRs.getString("ERROR"), error.get(plantRs.getString("ERROR"))+", "+toPlant);
					}
    					toPlantList.add(toPlant);
    				}
    			}
    			checkToPlantDto.setToPlantsList(toPlantList);
    			checkToPlantDto.setError(error);
   		
			
    	}catch (SQLException e){
    		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
    	
    	}finally {
    		if(plantRs!=null){
				try {
					plantRs.close();
					plantRs=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
    		if(psForPlant!=null){
				try {
					psForPlant.close();
					psForPlant=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
    	}
		return checkToPlantDto;
	}
	public ImgHierarchyCustomDto getEmptyTemplateCreation(BrownFieldModDownloadDto brownFieldModDownloadDto,
			HttpServletRequest request) {
		slf4jLogger.info("getEmptyTemplateCreation method started");
		String key = "RRn4PlfhPT6rXtZP";
		ImgHierarchyCustomDto imgHierarchyCustomDto = new ImgHierarchyCustomDto();
		String webAppPath = request.getServletContext().getRealPath("/WEB-INF");
		String webAppPath1 = request.getServletContext().getRealPath("/src/css");

		File encryptedFile = new File(webAppPath + "/ACNIPIMG_DOWNLOAD_TMPL.txt");
		File decryptedFile = new File(webAppPath1 + "/ACNIPIMG_DOWNLOAD_TMPL.txt");
		try {
			// AESEncrypt.encrypt(key, inputFile, encryptedFile);
			// slf4jLogger.info("before decryption");
			AESEncrypt.decrypt(key, encryptedFile, decryptedFile);
			// slf4jLogger.info("after decryption");
		} catch (CryptoException ex) {
			// System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
		String downloadPrgPath = webAppPath1 + File.separator + "ACNIPIMG_DOWNLOAD_TMPL.txt";
		DownloadResponseDto resultDto = new DownloadResponseDto();

		ImgHierarchyCustomDto imgCustomDto = brownFieldModDownloadDto.getImgHierarchyCustomDto();
		ImgHierarchyDAO imgHierarchyDAO = null;
		DownloadScopeResDto downloadScopeResDto = null;
		try {

			imgHierarchyCustomDto.setImgDesc(imgCustomDto.getImgDesc());
			imgHierarchyCustomDto.setImgId(imgCustomDto.getImgId());
			imgHierarchyCustomDto.setSeqNumber(imgCustomDto.getSeqNumber());
			imgHierarchyCustomDto.setIsMasterData(imgCustomDto.getIsMasterData());
			imgHierarchyCustomDto.setDownloadStatusIcon("glyphicon glyphicon-remove");
			imgHierarchyCustomDto.setScopeAvilableIcon("glyphicon glyphicon-remove");

			imgHierarchyDAO = new ImgHierarchyDAO();
			
			if(imgCustomDto.getIsMasterData().equalsIgnoreCase("Y")) {
				 ArrayList<String> inputScope= new ArrayList<String>();
				 downloadScopeResDto = new DownloadScopeResDto();
				 downloadScopeResDto.setScopeAvailable("N");
				 downloadScopeResDto.setImgId(imgCustomDto.getImgId());
				 downloadScopeResDto.setImgScope(inputScope);
			 }else {
				 if (brownFieldModDownloadDto.getCopyFlag())
						downloadScopeResDto = imgHierarchyDAO.getInputStringForBrownFldCopyFunctionality(imgCustomDto.getImgId(),
								brownFieldModDownloadDto.getSystemType());
					else if(brownFieldModDownloadDto.isIndustryFlag()) {
						downloadScopeResDto = imgHierarchyDAO.getInputStringForBrownFldForIndustry(imgCustomDto.getImgId(),
								brownFieldModDownloadDto.getSystemType(),brownFieldModDownloadDto.getIndustry(), brownFieldModDownloadDto.getSubIndustry());
					}else
						downloadScopeResDto = imgHierarchyDAO.getInputStringForBrownFld(imgCustomDto.getImgId(),
								brownFieldModDownloadDto.getSystemType());
			 }
			
			if (downloadScopeResDto.getScopeAvailable().equalsIgnoreCase("Y")) {
				imgHierarchyCustomDto.setScopeAvilableIcon("glyphicon glyphicon-ok");
				resultDto = executeSrcConfigDownload(brownFieldModDownloadDto.getSrcSystem(), downloadPrgPath,
						downloadScopeResDto.getImgScope(), brownFieldModDownloadDto.getHostName(),
						brownFieldModDownloadDto.getClientNo(), brownFieldModDownloadDto.getSysNo(),
						brownFieldModDownloadDto.getSapUserId(), brownFieldModDownloadDto.getDestPasswrd(),
						brownFieldModDownloadDto.getLanguage(),brownFieldModDownloadDto.getSncEnabled(), brownFieldModDownloadDto.getSncName(), 
						brownFieldModDownloadDto.getSncPartnerName(), brownFieldModDownloadDto.getSncProtectionLevel(), 
						brownFieldModDownloadDto.getSapRouter());
				if (resultDto.isSrcConnectionStatus() && resultDto.isSrcExecutionStatus()
						&& !resultDto.getDownloadRes().isEmpty()) {
					imgHierarchyCustomDto.setBytes(createEmptyTemplate(resultDto.getDownloadRes()));// Convert
																									// excel
																									// file
																									// and
																									// get
																									// bytes
					if (imgHierarchyCustomDto.getBytes() != null) {
						imgHierarchyCustomDto.setDownloadStatusIcon("glyphicon glyphicon-ok");
						imgHierarchyCustomDto.setResError("Template Created Successfully");
					}
				} else {
					imgHierarchyCustomDto.setResError(resultDto.getErrorDetails());
				}
			} else {
				imgHierarchyCustomDto.setResError("Scope is not avilable in DB.So, Please contact administrator");

			}

		} catch (Exception e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			imgHierarchyCustomDto.setResError("Template Creation is failed. Exception : " + e.getMessage());
		} finally {
			webAppPath = null;
			downloadPrgPath = null;
			resultDto = null;
			imgCustomDto = null;
			imgHierarchyDAO = null;
			downloadScopeResDto = null;
			slf4jLogger.info("getEmptyTemplateCreation method ended");
			// String webAppPath1 =
			// request.getServletContext().getRealPath("/src/css");
			File file = new File(webAppPath1 + "/ACNIPIMG_DOWNLOAD_TMPL.txt");

			if (file.delete()) {
				// System.out.println(" File deleted");
			}
			// else System.out.println(" doesn't exist");
		}

		return imgHierarchyCustomDto;
	}

	public byte[] createEmptyTemplate(ArrayList<String> resultList) {
		slf4jLogger.info("createEmptyTemplate method started");
		ArrayList<String> imgId = null, custObject = null, view = null, field = null, desc = null;
		ArrayList<ArrayList<String>> collectedDataList = null;
		LinkedHashMap<String, ArrayList<ArrayList<String>>> recordBySheet = new LinkedHashMap<String, ArrayList<ArrayList<String>>>();
		byte[] dataConversion = null;
		ArrayList<String> headerValues = null;
		ArrayList<String> instrheaderArr = null;
		ByteArrayOutputStream bos = null;
		XSSFWorkbook newWorkBook = new XSSFWorkbook();
		XSSFSheet newSheet = newWorkBook.createSheet("Instruction Sheet");
		XSSFRow newRow = null;
		Cell newCell = null;
		ArrayList<ArrayList<String>> sheetData = null;
		ArrayList<String> rowData = null;
		int columnSize = 0;
		int arrLen = 0;
		int rowNo = 0;
		String imgObject = "";
		String sheetName = "";
		try {
			headerValues = new ArrayList<String>();
			instrheaderArr = new ArrayList<String>();
			instrheaderArr.add("Customizing  Path");
			instrheaderArr.add("Transaction Code");
			instrheaderArr.add("Summary Instructions");
			instrheaderArr.add("Pre-requisites");
			instrheaderArr.add("Restrictions for template");

			headerValues.add("View Name");
			headerValues.add("Field");
			headerValues.add("Name");
			headerValues.add("Data Type");
			headerValues.add("Length");
			headerValues.add("Optional (O)/ Mandatory (M)");
			headerValues.add("Instruction");
			headerValues.add("Reference");

			XSSFCellStyle grayStyle = newWorkBook.createCellStyle();
			Font font = newWorkBook.createFont();
			font.setColor(HSSFColor.WHITE.index);
			grayStyle.setFillForegroundColor(new XSSFColor(new Color(89, 89, 89)));
			grayStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			grayStyle.setFont(font);

			XSSFCellStyle blueStyle = newWorkBook.createCellStyle();
			blueStyle.setFillForegroundColor(new XSSFColor(new Color(47, 117, 181)));
			blueStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

			for (int k = 0, arrSize = instrheaderArr.size(); k < arrSize; k++) {
				Row headerRow = newSheet.createRow(++rowNo);
				Cell cell = headerRow.createCell(0);
				cell.setCellValue(instrheaderArr.get(k));
				cell.setCellStyle(blueStyle);

			}
			rowNo = 7;
			Row headerRow = newSheet.createRow(rowNo);
			arrLen = headerValues.size();
			for (int i = 0; i < arrLen; i++) {
				Cell cell = headerRow.createCell(i);
				cell.setCellValue(headerValues.get(i));
				cell.setCellStyle(grayStyle);
			}

			resultList.remove(0);
			imgObject = resultList.get(0);
			sheetName = imgObject;
			for (int i = 0, arLen = resultList.size(); i < arLen; i++) {
				if (imgObject.equals(resultList.get(i))) {

					imgId = new ArrayList<String>();
					imgId.add("IMG ID");
					custObject = new ArrayList<String>();
					custObject.add("Customizing Object");
					view = new ArrayList<String>();
					view.add("View");
					field = new ArrayList<String>();
					field.add("Field");
					desc = new ArrayList<String>();
					desc.add("Description");

					if (resultList.get(i + 1).split("\\|")[1] != null)
						sheetName = resultList.get(i + 1).split("\\|")[1].replaceAll("/", "~");

					collectedDataList = new ArrayList<ArrayList<String>>();
					collectedDataList.add(imgId);
					collectedDataList.add(custObject);
					collectedDataList.add(view);
					collectedDataList.add(field);
					collectedDataList.add(desc);
					recordBySheet.put(sheetName, collectedDataList);
				} else {
					Row row = newSheet.createRow(++rowNo);
					String[] returnObj = resultList.get(i).split("\\|");
					imgId.add(imgObject);
					arrLen = returnObj.length;
					for (int k = 0; k < arrLen; k++) {
						if (k == 0 || k == 2)
							continue;
						if (k == 1) {
							Cell cell = row.createCell(k - 1);
							cell.setCellValue(returnObj[k]);
							cell.setCellStyle(blueStyle);
						} else {
							Cell cell = row.createCell(k - 2);
							cell.setCellValue(returnObj[k]);
							cell.setCellStyle(blueStyle);
						}
					}
					if (arrLen == 5) {
						custObject.add(returnObj[0]);
						view.add(returnObj[1]);
						field.add(returnObj[3]);
						desc.add(returnObj[4]);
					} else {
						custObject.add(arrLen >= 1 ? returnObj[0] : "");
						view.add(arrLen >= 2 ? returnObj[1] : "");
						field.add(arrLen >= 4 ? returnObj[3] : "");
						desc.add(arrLen >= 5 ? returnObj[4] : "");
					}
				}
			}
			for (int k = 0; k < 8; k++)
				newSheet.autoSizeColumn(k);
			Iterator<?> mapIteration = recordBySheet.entrySet().iterator();
			while (mapIteration.hasNext()) {
				Map.Entry pair = (Map.Entry) mapIteration.next();
				newSheet = newWorkBook.createSheet(pair.getKey().toString());

				sheetData = (ArrayList<ArrayList<String>>) pair.getValue();
				columnSize = sheetData.get(0).size();
				for (int i = 0; i < sheetData.size(); i++) {
					newRow = newSheet.createRow(i);
					rowData = sheetData.get(i);
					for (int j = 0; j < rowData.size(); j++) {
						newCell = newRow.createCell(j);
						if (j == 0)
							newCell.setCellStyle(grayStyle);
						else
							newCell.setCellStyle(blueStyle);
						newCell.setCellValue(rowData.get(j));
					}
				}
				newRow = newSheet.createRow(5);
				newCell = newRow.createCell(0);
				newCell.setCellStyle(grayStyle);
				newCell.setCellValue("Data Example");
				for (int k = 0; k < columnSize; k++)
					newSheet.autoSizeColumn(k);
				mapIteration.remove();
			}

			bos = new ByteArrayOutputStream();
			newWorkBook.write(bos);
			dataConversion = bos.toByteArray();
		} catch (Exception e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
		} finally {
			try {
				if (newWorkBook != null)
					newWorkBook.close();
				if (bos != null)
					bos.close();
			} catch (Exception e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			}
			imgId = null;
			custObject = null;
			view = null;
			field = null;
			desc = null;
			collectedDataList = null;
			recordBySheet = null;
			newWorkBook = null;
			newSheet = null;
			newRow = null;
			newCell = null;
			sheetData = null;
			rowData = null;
			bos = null;
			slf4jLogger.info("createEmptyTemplate method ended");

		}
		return dataConversion;
	}

	public ImgHierarchyCustomDto masterDataDownload(BrownFieldModDownloadDto brownFieldModDownloadDto,
			HttpServletRequest request) {
		slf4jLogger.info("masterDataDownload method started");
		String flag = "", ABAPreqid = "", recordNo = "";
		boolean loopReq = true;
		int dataStart = 0;
		String key = "RRn4PlfhPT6rXtZP";
		ConfigAuditDAO configAuditDao = new ConfigAuditDAO();
		ConfigDownloadHistoryDto configDownloadHistoryDto = new ConfigDownloadHistoryDto();
		ImgHierarchyCustomDto modCustomDto = new ImgHierarchyCustomDto();
		ConfigDwldResDto configDwldResDto = null;
		Date date = new java.util.Date();
		Timestamp downloadStartTime = new java.sql.Timestamp(date.getTime());
		configDownloadHistoryDto.setDownloadStartTime(downloadStartTime);
		String webAppPath = request.getServletContext().getRealPath("/WEB-INF");
		String webAppPath1 = request.getServletContext().getRealPath("/src/css");

		File encryptedFile = new File(webAppPath + "/ACNIPIMG_DOWNLOAD_FI_MASTER.txt");
		File decryptedFile = new File(webAppPath1 + "/ACNIPIMG_DOWNLOAD_FI_MASTER.txt");
		try {
			// AESEncrypt.encrypt(key, inputFile, encryptedFile);
			// slf4jLogger.info("before decryption");
			AESEncrypt.decrypt(key, encryptedFile, decryptedFile);
			// slf4jLogger.info("after decryption");
		} catch (CryptoException ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
		String downloadPrgPath = webAppPath1 + File.separator + "ACNIPIMG_DOWNLOAD_FI_MASTER.txt";
		ImgHierarchyCustomDto imgCustomDto = brownFieldModDownloadDto.getImgHierarchyCustomDto();

		ArrayList<String> masterInput = new ArrayList<>();
		int docId = 0;
		HCPDocDAO hcpDocDAOobj = new HCPDocDAO();

		modCustomDto.setImgDesc(imgCustomDto.getImgDesc());
		modCustomDto.setImgId(imgCustomDto.getImgId());
		modCustomDto.setSeqNumber(imgCustomDto.getSeqNumber());
		modCustomDto.setDownloadStatus(true);
		modCustomDto.setDownloadStatusIcon("glyphicon glyphicon-remove");

		String fileName = "";
		if (imgCustomDto.getIsMasterData() != null && imgCustomDto.getIsMasterData().equalsIgnoreCase("Y")) {
			if(brownFieldModDownloadDto.isIndustryFlag()) {
				fileName = imgCustomDto.getSeqNumber() + "_" +imgCustomDto.getImgDesc()+"_"+brownFieldModDownloadDto.getIndustryAlias()
				+"_"+brownFieldModDownloadDto.getSubIndustryAlias().replaceAll("[\\/:*?\"<>|\\\\]", " ");
			}else {
				fileName = imgCustomDto.getSeqNumber() + "_" +imgCustomDto.getImgDesc().replaceAll("[\\/:*?\"<>|\\\\]", " ");
			}
			
		}
			
			
			//fileName = imgCustomDto.getSeqNumber() + "_" + imgCustomDto.getImgDesc();// Need
																						// to
																						// remove
		if(brownFieldModDownloadDto.isIndustryFlag()) {
			docId = hcpDocDAOobj.getDocumentIdForIndustry(fileName.replaceAll("[^a-zA-Z0-9]", "").toLowerCase(), "BASE");
		}else {
			docId = hcpDocDAOobj.getDocumentId(fileName.replaceAll("[^a-zA-Z0-9]", "").toLowerCase(), "BASE");
		}
		

		configDownloadHistoryDto.setImgID(imgCustomDto.getImgId());
		configDownloadHistoryDto.setTransactionID(brownFieldModDownloadDto.getTransactionID());
		try {

			modCustomDto.setScopeAvilableIcon("glyphicon glyphicon-ok");
			if (docId > 0) {

				if (imgCustomDto.getIsMasterData() != null && imgCustomDto.getIsMasterData().equalsIgnoreCase("Y")) {
					GLTemplateDto templateDto = null;
					if (imgCustomDto.getImgId().equals("IMG_DUMMY_FIN1")
							|| imgCustomDto.getImgId().equals("IMG_DUMMY_FIN3")) {
						dataStart = 4;
					} else if (imgCustomDto.getImgId().equals("SIMG_CFMENUORK1KE51")) {
						dataStart = 4;
					} else if (imgCustomDto.getImgId().equals("FI_GL_MD_FS00")) {
						dataStart = 3;
					}
					templateDto = PrepareEmptyMasterTemplate(modCustomDto, docId, dataStart, brownFieldModDownloadDto.isIndustryFlag(), fileName);
					while (loopReq) {
						masterInput.clear();
						if (imgCustomDto.getImgId().equals("IMG_DUMMY_FIN1")) {
							masterInput.add("CC");
							masterInput.add(imgCustomDto.getImgId() + "|" + ABAPreqid + "|" + recordNo + "|" + flag);
						} else if (imgCustomDto.getImgId().equals("SIMG_CFMENUORK1KE51")) {
							masterInput.add("PC");
							masterInput.add(imgCustomDto.getImgId() + "|" + ABAPreqid + "|" + recordNo + "|" + flag);
						} else if (imgCustomDto.getImgId().equals("FI_GL_MD_FS00")) {
							masterInput.add("GL");
							masterInput.add(imgCustomDto.getImgId() + "|" + ABAPreqid + "|" + recordNo + "|" + flag);
						} else if (imgCustomDto.getImgId().equals("IMG_DUMMY_FIN3")) {
							masterInput.add("HB");
							masterInput.add(imgCustomDto.getImgId() + "|" + ABAPreqid + "|" + recordNo + "|" + flag);
						}
						configDwldResDto = dwldMasterData_ABAP(imgCustomDto.getImgId(),
								brownFieldModDownloadDto.getSrcSystem(), downloadPrgPath, masterInput,
								brownFieldModDownloadDto.getClientNo(), brownFieldModDownloadDto.getHostName(),
								brownFieldModDownloadDto.getSysNo(), brownFieldModDownloadDto.getSapUserId(),
								brownFieldModDownloadDto.getDestPasswrd(), brownFieldModDownloadDto.getLanguage(), 
								brownFieldModDownloadDto.getSncEnabled(), brownFieldModDownloadDto.getSncName(), 
								brownFieldModDownloadDto.getSncPartnerName(), brownFieldModDownloadDto.getSncProtectionLevel(), 
								brownFieldModDownloadDto.getSapRouter());
						if (configDwldResDto != null && configDwldResDto.getConfigDwldData() != null
								&& configDwldResDto.getConfigDwldData().size() > 2) {
							String value = configDwldResDto.getConfigDwldData().get(1);
							ABAPreqid = value.split("\\|")[1];
							recordNo = value.split("\\|")[2];
							if (value.endsWith("X")) {
								flag = "X";
							} else {
								loopReq = false;
							}

							convertMasterDataToExcel(templateDto, configDwldResDto, dataStart - 1);
							configDwldResDto = null;
						} else if (configDwldResDto == null) {
							modCustomDto.setResError(brownFieldModDownloadDto.getSrcSystem()
									+ " is currently not reachable, please contact Administrator");
							modCustomDto.setBytes(null);
							modCustomDto.setDownloadStatus(true);
							modCustomDto.setDownloadStatusIcon("glyphicon glyphicon-remove");
							loopReq = false;
						} else {
							loopReq = false;
						}

					}
					convertExceltoBytes(modCustomDto, templateDto, fileName + ".xlsx");
				}
			} else {
				modCustomDto.setResError(imgCustomDto.getImgDesc()
						+ " Config Template is not available in the System. Please contact System Administrator");
			}

			configDownloadHistoryDto.setStatus(modCustomDto.isDownloadStatus() ? "E" : "S");
			configDownloadHistoryDto.setMessage(modCustomDto.getResError());
			configAuditDao.createConfigDwdHistory(configDownloadHistoryDto);

		}

		catch (Exception e) {
			modCustomDto.setResError(e.getLocalizedMessage());
			configDownloadHistoryDto.setStatus(modCustomDto.isDownloadStatus() ? "E" : "S");
			configDownloadHistoryDto.setMessage(modCustomDto.getResError());
			configAuditDao.createConfigDwdHistory(configDownloadHistoryDto);
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			return modCustomDto;
		}

		finally {
			configAuditDao = null;
			configDownloadHistoryDto = null;
			imgCustomDto = null;
			hcpDocDAOobj = null;
			slf4jLogger.info("masterDataDownload method ended");
			// String webAppPath1 =
			// request.getServletContext().getRealPath("/src/css");

			File file = new File(webAppPath1 + "/ACNIPIMG_DOWNLOAD_FI_MASTER.txt");

			if (file.delete()) {
				// System.out.println(" File deleted");
			}
			// else System.out.println(" doesn't exist");
		}
		return modCustomDto;
	}

	public GLTemplateDto PrepareEmptyMasterTemplate(ImgHierarchyCustomDto modCustomDto, int docId, int dataStart, boolean industryFlag, String fileName) {
		slf4jLogger.info("PrepareEmptyMasterTemplate method started");
		ByteArrayOutputStream bos = null;
		GLTemplateDto templateDto = new GLTemplateDto();
		ArrayList<String> columnList = new ArrayList<String>();
		ArrayList<String> viewList = new ArrayList<String>();
		Document document = null;
		InputStream stream = null;
		XSSFWorkbook workbook = null;
		Session openCmisSession = null;
		String retreivedFileName = null;

		/*
		 * openCmisSession = HCPDocDAO.ConnectDocumentStore(); document =
		 * (Document) openCmisSession.getObject(docId);
		 */
		/*
		 * String retreivedFileName=null; try{ int j =
		 * fileName.lastIndexOf('.'); if (j > 0) { retreivedFileName =
		 * fileName.substring(j+0); }
		 */
		retreivedFileName = modCustomDto.getSeqNumber() + "_" + modCustomDto.getImgDesc();
		/*
		 * openCmisSession = HCPDocDAO.ConnectDocumentStore(); document =
		 * (Document) openCmisSession.getObject(docId);
		 */
		try {
			TemplateDetailsDto templateDtailsDto = new TemplateDetailsDto();
			if(industryFlag) {
				templateDtailsDto = getDocumentDetailsForIndustry(fileName.replaceAll("[^a-zA-Z0-9]", "").toLowerCase());
			}else {
				templateDtailsDto = getDocumnetDetails(retreivedFileName);
			}
			

			// stream = document.getContentStream().getStream();
			stream = templateDtailsDto.getStream();
			workbook = new XSSFWorkbook(stream);
			int numberofSheet = workbook.getNumberOfSheets();
			for (int num = 0; num < numberofSheet; num++) {
				if (workbook.getSheetName(num).equalsIgnoreCase("Instruction Sheet"))
					continue;

				XSSFSheet sheet = workbook.getSheetAt(num);
				int lastRowNumber = sheet.getLastRowNum();
				Row selectedRow = sheet.getRow(0);
				Iterator<Cell> currentCellIterator;

				if (selectedRow != null) {
					currentCellIterator = selectedRow.cellIterator();
					for (int cellCount = 0; currentCellIterator.hasNext(); cellCount++) {
						Cell cell = currentCellIterator.next();
						if (cell != null) {
							cell.setCellType(Cell.CELL_TYPE_STRING);
							viewList.add(cell.getStringCellValue().trim());
						}
					}
				}

				templateDto.setViewList(viewList);
				selectedRow = sheet.getRow(1);
				if (selectedRow != null) {
					currentCellIterator = selectedRow.cellIterator();
					for (int cellCount = 0; currentCellIterator.hasNext(); cellCount++) {
						Cell cell = currentCellIterator.next();
						if (cell != null) {
							cell.setCellType(Cell.CELL_TYPE_STRING);
							columnList.add(cell.getStringCellValue().trim());
						}
					}
				}

				templateDto.setColumnList(columnList);

				selectedRow = sheet.getRow(dataStart);
				int count = dataStart;
				while (count <= lastRowNumber) {
					selectedRow = sheet.getRow(count);
					if (selectedRow != null)
						sheet.removeRow(selectedRow);
					count++;
				}
				break;
			}
			bos = new ByteArrayOutputStream();
			workbook.write(bos);
			templateDto.setExcelByteData(bos);

		} catch (Exception e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
		} finally {
			try {
				if (workbook != null)
					workbook.close();
				workbook = null;
				if (bos != null)
					bos.close();
				columnList = null;
				stream = null;
				document = null;
				openCmisSession = null;
				bos = null;
			} catch (Exception e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			}
			slf4jLogger.info("PrepareEmptyMasterTemplate method ended");

		}
		return templateDto;
	}

	public ConfigDwldResDto dwldMasterData_ABAP(String imgId, String srcSystem, String downloadPrgPath,
			ArrayList<String> masterInput, String clientNo, String hostName, String sysNo, String userId,
			String password, String language, int sncEnabled,
			String sncName, String sncPartnerName, String sncProtectionLevel,String sapRouter ) {

		slf4jLogger.info("dwldMasterData_ABAP method started");
		ConfigDwldResDto configDwldRes = null;
		DownloadResponseDto downloadResponseDto = null;
		try {
			downloadResponseDto = executeSrcConfigDownload(srcSystem, downloadPrgPath, masterInput, clientNo, hostName,
					sysNo, userId, password, language,  sncEnabled,sncName,  sncPartnerName, sncProtectionLevel,sapRouter);
			// slf4jLogger.info("downloadResponseDto.isSrcConnectionStatus()"+downloadResponseDto.isSrcConnectionStatus());
			// slf4jLogger.info("downloadResponseDto.isSrcExecutionStatus()"+downloadResponseDto.isSrcExecutionStatus());
			if (downloadResponseDto.isSrcConnectionStatus() && downloadResponseDto.isSrcExecutionStatus()) {
				configDwldRes = new ConfigDwldResDto();
				configDwldRes.setImgId(imgId);
				configDwldRes.setConfigDwldData(downloadResponseDto.getDownloadRes());
			}
		} catch (Exception e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
		} finally {
			downloadResponseDto = null;
			slf4jLogger.info("dwldMasterData_ABAP method ended");
		}
		return configDwldRes;
	}

	public GLTemplateDto convertMasterDataToExcel(GLTemplateDto templateDto, ConfigDwldResDto configDwldResDto,
			int rowStart) {
		slf4jLogger.info("convertMasterDataToExcel method started");
		int dataRow = 0;
		ArrayList<String> columnList = new ArrayList<String>();
		ArrayList<String> viewList = new ArrayList<String>();
		String currentValue, currentSourceField, searchValue, currentSize = "", currentSourceView = "";
		XSSFWorkbook workbook = null;
		ArrayList<String> selectedOutputList = null;
		selectedOutputList = configDwldResDto.getConfigDwldData();

		XSSFSheet sheet = null;
		Row selectedRow = null;
		Cell particularCell = null;
		ByteArrayOutputStream bos = null;
		try {

			workbook = new XSSFWorkbook(new ByteArrayInputStream(templateDto.getExcelByteData().toByteArray()));

			int numberofSheet = workbook.getNumberOfSheets();
			for (int num = 0; num < numberofSheet; num++) {
				if (workbook.getSheetName(num).equalsIgnoreCase("Instruction Sheet"))
					continue;

				sheet = workbook.getSheetAt(num);
				viewList = templateDto.getViewList();
				columnList = templateDto.getColumnList();
				selectedRow = null;

				for (int currField = 0; currField < columnList.size(); currField++) {

					currentSourceView = viewList.get(currField);
					currentSourceField = columnList.get(currField);
					if (currentSourceView.equalsIgnoreCase("Dummy"))
						continue;
					if (!selectedOutputList.isEmpty()) {
						searchValue = currentSourceField;
						currentSourceView = currentSourceView + "|";
						currentSourceField = "|" + currentSourceField + "|";
						for (int e = 0; e < selectedOutputList.size(); e++) {
							if (selectedOutputList.get(e).contains(currentSourceView)
									&& selectedOutputList.get(e).contains(currentSourceField)) {
								currentValue = selectedOutputList.get(e);
								if (currentValue.split("\\|").length > 2) {
									currentSize = currentValue.split("\\|")[1];
									if (currentSize != null && currentSize != "") {
										try {
											dataRow = rowStart + Integer.parseInt(currentSize);
											selectedRow = sheet.getRow(dataRow);
											if (selectedRow == null) {
												selectedRow = sheet.createRow(dataRow);
											}
											particularCell = selectedRow.getCell(currField);
											if (particularCell == null) {
												particularCell = selectedRow.createCell(currField);
											}
											if (currentValue.split(searchValue).length > 1) {
												particularCell.setCellValue(currentValue
														.split(searchValue)[currentValue.split(searchValue).length - 1]
																.substring(1));
												templateDto.setVaildFile(true);
											}
										} catch (NumberFormatException ex) {
											slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, ex);
										}
									}
								}

							}
						}
					}

				}
				if (selectedOutputList != null)
					selectedOutputList.clear();
				break;
			}
			bos = new ByteArrayOutputStream();
			workbook.write(bos);
			templateDto.setExcelByteData(bos);
		} catch (Exception e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
		} finally {
			try {
				if (workbook != null)
					workbook.close();
				if (bos != null)
					bos.close();
				bos = null;
				currentValue = null;
				currentSourceField = null;
				searchValue = null;
				currentSize = null;
				currentSourceView = null;
				workbook = null;
				sheet = null;
				selectedRow = null;
				particularCell = null;
				columnList = null;
				selectedOutputList = null;
				viewList = null;
				columnList = null;
				configDwldResDto = null;

			} catch (Exception e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			}
			slf4jLogger.info("convertMasterDataToExcel method ended");

		}
		return templateDto;
	}

	public void convertExceltoBytes(ImgHierarchyCustomDto modCustomDto, GLTemplateDto templateDto, String fileName) {
		slf4jLogger.info("convertExceltoBytes method started");
		ByteArrayOutputStream bos = null;
		XSSFWorkbook workbook = null;

		try {
			if (templateDto.getExcelByteData() != null)
				workbook = new XSSFWorkbook(new ByteArrayInputStream(templateDto.getExcelByteData().toByteArray()));

			if (workbook != null) {
				bos = new ByteArrayOutputStream();
				workbook.write(bos);
				byte[] bytes = bos.toByteArray();
				modCustomDto.setBytes(bytes);
				modCustomDto.setDownloadStatus(false);
				modCustomDto.setDownloadStatusIcon("glyphicon glyphicon-ok");

				if (templateDto.isVaildFile()) {
					modCustomDto.setResError("Template Downloaded Successfully");
				} else {
					modCustomDto.setResError(
							"The template was downloaded without data, please verify the template before uploading..");
				}
			} else {
				modCustomDto.setResError("Template Download failed");
			}

		} catch (OutOfMemoryError e) {
			try {
				if (workbook != null)
					workbook.close();
				workbook = null;
				bos = null;
			} catch (IOException e1) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e1);
			}
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
		} catch (Exception e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
		} finally {
			try {
				if (workbook != null)
					workbook.close();
				workbook = null;
				if (bos != null)
					bos.close();
				bos = null;
			} catch (IOException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			}

		}
	}

	public ArrayList<String> getInstalledBaseWithoutIntervention(int docId, String fileName, String ObjeName) {
		slf4jLogger.info("getInstalledBaseWithoutIntervention method started");
		ArrayList<String> columnList = new ArrayList<String>();
		ArrayList<String> fieldList = new ArrayList<String>();
		Document document = null;
		InputStream stream = null;
		XSSFWorkbook workbook = null;
		Session openCmisSession = null;
		int noOfColumns = 0;
		String retreivedFileName = null;
		try {
			int j = fileName.lastIndexOf('.');
			if (j > 0) {
				retreivedFileName = fileName.substring(j + 0);
			}
			/*
			 * openCmisSession = HCPDocDAO.ConnectDocumentStore(); document =
			 * (Document) openCmisSession.getObject(docId);
			 */
			TemplateDetailsDto templateDtailsDto = new TemplateDetailsDto();
			templateDtailsDto = getDocumnetDetails(retreivedFileName);

			// stream = document.getContentStream().getStream();
			stream = templateDtailsDto.getStream();

			workbook = new XSSFWorkbook(stream);
			int numberofSheet = workbook.getNumberOfSheets();
			if (numberofSheet > 0) {
				columnList.clear();
				XSSFSheet sheet = workbook.getSheet(ObjeName);
				Row selectedRow = sheet.getRow(3);
				if (selectedRow != null) {
					noOfColumns = sheet.getRow(0).getPhysicalNumberOfCells();
					for (int i = 1; i < noOfColumns; i++) {
						selectedRow.getCell(i).setCellType(Cell.CELL_TYPE_STRING);
						fieldList.add(selectedRow.getCell(i).getStringCellValue());
					}
				}
			}
		} catch (Exception e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
		} finally {
			try {
				if (workbook != null)
					workbook.close();
				workbook = null;
				columnList = null;
				document = null;
				stream = null;
				openCmisSession = null;
			} catch (IOException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			}
			slf4jLogger.info("getInstalledBaseWithoutIntervention method ended");

		}
		return fieldList;

	}
	
	public ArrayList<String> getInstalledBaseWithoutInterventionForIndustry(int docId, String fileName, String ObjeName) {
		slf4jLogger.info("getInstalledBaseWithoutIntervention method started");
		ArrayList<String> columnList = new ArrayList<String>();
		ArrayList<String> fieldList = new ArrayList<String>();
		Document document = null;
		InputStream stream = null;
		XSSFWorkbook workbook = null;
		Session openCmisSession = null;
		int noOfColumns = 0;
		String retreivedFileName = null;
		try {
			int j = fileName.lastIndexOf('.');
			if (j > 0) {
				retreivedFileName = fileName.substring(j + 0);
			}
			/*
			 * openCmisSession = HCPDocDAO.ConnectDocumentStore(); document =
			 * (Document) openCmisSession.getObject(docId);
			 */
			TemplateDetailsDto templateDtailsDto = new TemplateDetailsDto();
			templateDtailsDto = getDocumentDetailsForIndustry(retreivedFileName);

			// stream = document.getContentStream().getStream();
			stream = templateDtailsDto.getStream();

			workbook = new XSSFWorkbook(stream);
			int numberofSheet = workbook.getNumberOfSheets();
			if (numberofSheet > 0) {
				columnList.clear();
				XSSFSheet sheet = workbook.getSheet(ObjeName);
				Row selectedRow = sheet.getRow(3);
				if (selectedRow != null) {
					noOfColumns = sheet.getRow(0).getPhysicalNumberOfCells();
					for (int i = 1; i < noOfColumns; i++) {
						selectedRow.getCell(i).setCellType(Cell.CELL_TYPE_STRING);
						fieldList.add(selectedRow.getCell(i).getStringCellValue());
					}
				}
			}
		} catch (Exception e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
		} finally {
			try {
				if (workbook != null)
					workbook.close();
				workbook = null;
				columnList = null;
				document = null;
				stream = null;
				openCmisSession = null;
			} catch (IOException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			}
			slf4jLogger.info("getInstalledBaseWithoutIntervention method ended");

		}
		return fieldList;

	}
	
	public ImgFilterResponseDTO getFilteredConfigDataforCopyFunctinality(ImgDownloadDto imgDownloadDto,
			DownloadResponseDto downloadResponseDto, HashMap<String, String> filterMap, HashMap<String, ArrayList<String>> copyFromTo) {

		slf4jLogger.info("getFilteredConfigDataforCopyFunctinality method started");
		
		String fileName = null;
		int docId = 0;
		InputStream stream = null;
		HCPDocDAO hcpDocDAOobj = new HCPDocDAO();
		XSSFWorkbook workBook = null;
		
		String currentViewName = null;
		ArrayList<String> columnList = new ArrayList<>();
		ArrayList<String> columnList_Filter = new ArrayList<>();
		XSSFSheet sheet = null;
		int lastRowNumber = 0;
		Row selectedRow = null;
		Iterator<Cell> currentCellIterator = null;
		Cell cell = null;
		int columnListSize = 0;
		int count = 5;
		String tempCellValue = null;
		HashMap<String, FieldMappingDto> fieldMap = new HashMap<>();
		FieldMappingDto fieldMappingDtoObj = null;
		ArrayList<String> retrievedValueList = null;
		FieldMappingDto selectedFieldDto = null;
		String currentSourceView = null;
		String currentSourceField = null;
		ArrayList<String> selectedOutputList = null;
		int selectedOutputListSize, retrievedValueListSize;
		String currentSize = null;
		String currentValue = null;
		String searchValue = null;
		StringBuffer warningMsg = new StringBuffer();
		int dataRow = 0;
		Cell particularCell = null;
	
		ArrayList<Integer> fromIndex=new ArrayList<>();
		HashMap<String, ArrayList<String>> from=new HashMap<String,ArrayList<String>>();
		ArrayList<String> fromValues=null;
		String valueData="";
		int currentIndex;
		
		ImgFilterResponseDTO imgFilterResponseDTO;

		try {
			
			fileName = imgDownloadDto.getSequence() + "_" + imgDownloadDto.getImgDescription();
			docId = hcpDocDAOobj.getDocumentId(fileName.replaceAll("[^a-zA-Z0-9]", "").toLowerCase(), "BASE");
			if (docId > 0) {
								
				Connection con = null;
				 PreparedStatement pStmt=null;
				 ResultSet rs=null;
				 fileName=fileName.replaceAll("[^a-zA-Z0-9]", "").toLowerCase();
				  	String storeDocIdQuery = "select file_blob from documentstore where IMGDESC=?";
				  	try{
						con = DBConnection.createConnection();
						pStmt = (PreparedStatement) con.prepareStatement(storeDocIdQuery);
						pStmt.setString(1,fileName);
						rs = pStmt.executeQuery();
						while(rs.next()){
							stream = rs.getBinaryStream("file_blob");
							
							slf4jLogger.info("file stream"+stream);
						}
					}catch(Exception e){
						
					}
					workBook = new XSSFWorkbook(stream);
					
				int numberofSheet = workBook.getNumberOfSheets();

				for (int num = 0; num < numberofSheet; num++) {
					currentViewName = workBook.getSheetName(num).replaceAll("~", "/");
					if (currentViewName.equalsIgnoreCase("Instruction Sheet"))
						continue;
					columnList.clear();
					columnList_Filter.clear();
					sheet = workBook.getSheetAt(num);
					lastRowNumber = sheet.getLastRowNum();
					selectedRow = sheet.getRow(3);
					if (selectedRow != null) {
						currentCellIterator = selectedRow.cellIterator();
						for (int cellCount = 0; currentCellIterator.hasNext(); cellCount++) {
							cell = currentCellIterator.next();
							if (cellCount == 0)
								continue;
							if (cell != null) {
								cell.setCellType(Cell.CELL_TYPE_STRING);
								columnList.add(cell.getStringCellValue());
								columnList_Filter.add(currentViewName + cell.getStringCellValue());
							}
						}
						columnListSize = columnList.size();
					}
					selectedRow = sheet.getRow(5);
					if (selectedRow != null) {
						currentCellIterator = selectedRow.cellIterator();
						for (int cellCount = 0; currentCellIterator.hasNext(); cellCount++) {
							cell = currentCellIterator.next();
							if (cellCount == 0) {
								if (cell != null) {
									cell.setCellType(Cell.CELL_TYPE_STRING);
									tempCellValue = cell.getStringCellValue();
								}

								break;
							}
						}
					}

					count = 5;
					while (count <= lastRowNumber) {
						selectedRow = sheet.getRow(count);
						if (selectedRow != null)
							sheet.removeRow(selectedRow);
						count++;
					}
					selectedRow = sheet.createRow(5);
					cell = selectedRow.createCell(0, Cell.CELL_TYPE_STRING);
					cell.setCellValue(tempCellValue);

					fieldMap = new HashMap<>();
					for (int k = 0; k < columnListSize; k++) {
						fieldMappingDtoObj = new FieldMappingDto();
						fieldMappingDtoObj.setS_IMGID(imgDownloadDto.getImgId());
						fieldMappingDtoObj.setS_VIEW(currentViewName);
						fieldMappingDtoObj.setS_FIELD(columnList.get(k));
						fieldMap.put(columnList.get(k), fieldMappingDtoObj);

					}
					fromValues= new ArrayList<>();
					for (int currField = 0; currField < columnListSize; currField++) {
						retrievedValueList = new ArrayList<>();
						selectedFieldDto = fieldMap.get(columnList.get(currField));
						if (selectedFieldDto != null) {
							currentSourceView = selectedFieldDto.getS_VIEW();
							currentSourceField = selectedFieldDto.getS_FIELD();
							selectedOutputList = new ArrayList<>();
							selectedOutputList = downloadResponseDto.getDownloadRes();
							
							if (!selectedOutputList.isEmpty()) {
								int value = 0;
								currentSize = "";
								currentValue = "";
								searchValue = currentSourceField;
								currentSourceView = "|" + currentSourceView + "|";
								currentSourceField = "|" + currentSourceField + "|";
								if (warningMsg.length() <= 0) {
									if (selectedOutputList.size() > 2) {
										if (selectedOutputList.get(1).startsWith("M~"))
											warningMsg.append(selectedOutputList.get(1).split("~")[1] + ". ");
									}
								}
								selectedOutputListSize = selectedOutputList.size();
								for (int e = 0; e < selectedOutputListSize; e++) {
									if (selectedOutputList.get(e).contains(currentSourceView)
											&& selectedOutputList.get(e).contains(currentSourceField)) {
										currentValue = selectedOutputList.get(e);
										/*if (currentValue.equals("ADRC|ADRC|1|CLIENT|100"))
											System.out.println("****");
										System.out.println(currentValue);*/
										value = retrievedValueList.size() + 1;
										if (currentValue.split("\\|").length > 3) {
											currentSize = currentValue.split("\\|")[2];
											if (currentSize != null && currentSize != "") {
												try {
													while (Integer.parseInt(currentSize) > value) {
														retrievedValueList.add("");
														value++;
													}
												} catch (NumberFormatException ex) {
													slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, ex);
												}
											}
										}
										if (currentValue.split(searchValue).length > 1) {
											valueData=currentValue.split(searchValue)[currentValue.split(searchValue).length - 1].substring(1);
											currentIndex=Integer.parseInt(currentValue.split("\\|")[2]);
											if(filterMap.get(currentSourceView).contains("{X}"))
												continue;
											if (currentSourceField.equals(filterMap.get(currentSourceView)))
											{
												fromValues.add(valueData);
											}
											//System.out.println(currentIndex+"----");
											
											}
									}
								}
							}
							if (!fromValues.isEmpty())
								from.put(currentSourceView, fromValues);
							fromValues= new ArrayList<>();
							}
						
						}
					
					for (int currField = 0; currField < columnListSize; currField++) {
						retrievedValueList = new ArrayList<>();
						selectedFieldDto = fieldMap.get(columnList.get(currField));
						if (selectedFieldDto != null) {
							currentSourceView = selectedFieldDto.getS_VIEW();
							currentSourceField = selectedFieldDto.getS_FIELD();
							selectedOutputList = new ArrayList<>();
							selectedOutputList = downloadResponseDto.getDownloadRes();

							if (!selectedOutputList.isEmpty()) {
								int value = 0;
								currentSize = "";
								currentValue = "";
								searchValue = currentSourceField;
								currentSourceView = "|" + currentSourceView + "|";
								currentSourceField = "|" + currentSourceField + "|";
								if (warningMsg.length() <= 0) {
									if (selectedOutputList.size() > 2) {
										if (selectedOutputList.get(1).startsWith("M~"))
											warningMsg.append(selectedOutputList.get(1).split("~")[1] + ". ");
									}
								}
								selectedOutputListSize = selectedOutputList.size();
								for (int e = 0; e < selectedOutputListSize; e++) {
									if (selectedOutputList.get(e).contains(currentSourceView)
											&& selectedOutputList.get(e).contains(currentSourceField)) {
										currentValue = selectedOutputList.get(e);
										//System.out.println(currentValue);
										value = retrievedValueList.size() + 1;
										if (currentValue.split("\\|").length > 3) {
											currentSize = currentValue.split("\\|")[2];
											if (currentSize != null && currentSize != "") {
												try {
													while (Integer.parseInt(currentSize) > value) {
														retrievedValueList.add("");
														value++;
													}
												} catch (NumberFormatException ex) {
													slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, ex);
												}
											}
										}
										if (currentValue.split(searchValue).length > 1) {

											currentIndex = Integer.parseInt(currentValue.split("\\|")[2]);
											///System.out.println(currentIndex + "----");
											valueData = currentValue
													.split(searchValue)[currentValue.split(searchValue).length - 1]
															.substring(1);
											if (filterMap.get(currentSourceView).contains("{X}")) {
												retrievedValueList.add(currentValue
														.split(searchValue)[currentValue.split(searchValue).length - 1]
																.substring(1));
											} else {
												for (String to : copyFromTo
														.get(from.get(currentSourceView).get(currentIndex - 1))) {
													if(to.isEmpty())
														break;
													if (copyFromTo.keySet().contains(valueData)) {
														retrievedValueList.add(to);
													} else
														retrievedValueList.add(currentValue.split(
																searchValue)[currentValue.split(searchValue).length - 1]
																		.substring(1));

												}
											}
										}
									}
								}
							}
							//System.out.println(retrievedValueList);
							dataRow = 5;
							particularCell = null;
							retrievedValueListSize = retrievedValueList.size();
							for (int w = 0; w < retrievedValueListSize; w++) {
								selectedRow = sheet.getRow(dataRow);
								if (selectedRow == null) {
									selectedRow = sheet.createRow(dataRow);
									selectedRow.createCell(0, Cell.CELL_TYPE_STRING);
								}

								particularCell = selectedRow.getCell(currField + 1);
								if (particularCell == null) {
									particularCell = selectedRow.createCell(currField + 1, Cell.CELL_TYPE_STRING);
								}
								particularCell.setCellValue(retrievedValueList.get(w));
								//System.out.println(retrievedValueList.get(w));
								dataRow++;
							}
						}
					}
					

				}
				
				imgFilterResponseDTO = new ImgFilterResponseDTO();
				imgFilterResponseDTO.setExcelWorkbook(workBook);
				imgFilterResponseDTO.setStatus(true);

			}

			else {
				imgFilterResponseDTO = new ImgFilterResponseDTO();
				imgFilterResponseDTO.setStatus(false);
				imgFilterResponseDTO.setErrDetails(
						"Filter criteria maintained for the template but template not available in Document Repository, please contact Administrator!!");
			}
		} catch (Exception e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			imgFilterResponseDTO = new ImgFilterResponseDTO();
			imgFilterResponseDTO.setErrDetails("Exception occured while filtering config data" + e.toString());
		} finally {
			slf4jLogger.info("getFilteredConfigDataforCopyFunctinality method ended");

		}
		return imgFilterResponseDTO;
	
	}

	public ImgFilterResponseDTO getFilteredConfigData(ImgDownloadDto imgDownloadDto,
			DownloadResponseDto downloadResponseDto, HashMap<String, ArrayList<String>> filterMap, String fileName, boolean industryFlag) {
		slf4jLogger.info("getFilteredConfigData method started");
		Session openCmisSession = null;
		Document document = null;
		int docId = 0;
		InputStream stream = null, stream1 = null;
		HCPDocDAO hcpDocDAOobj = new HCPDocDAO();
		XSSFWorkbook workBook = null, filterWorkBook = null;
		String currentViewName = null;
		ArrayList<String> columnList = new ArrayList<>();
		ArrayList<String> columnList_Filter = new ArrayList<>();
		XSSFSheet sheet = null, filterSheet = null;
		int lastRowNumber = 0;
		Row selectedRow = null, filterRow = null;
		Iterator<Cell> currentCellIterator = null;
		Cell cell = null, filterCell = null;
		int columnListSize = 0;
		int count = 5;
		String tempCellValue = null;
		HashMap<String, FieldMappingDto> fieldMap = new HashMap<>();
		FieldMappingDto fieldMappingDtoObj = null;
		ArrayList<String> retrievedValueList = null;
		FieldMappingDto selectedFieldDto = null;
		String currentSourceView = null;
		String currentSourceField = null;
		ArrayList<String> selectedOutputList = null;
		int selectedOutputListSize, retrievedValueListSize, totalRow, filterIndexSize;
		String currentSize = null;
		String currentValue = null;
		String searchValue = null;
		StringBuffer warningMsg = new StringBuffer();
		int dataRow = 0;
		Cell particularCell = null;
		boolean filterCriteria = false;
		String key = null;
		int filterColumn = -1;
		ArrayList<String> fieldValList = null;
		ArrayList<Integer> filterIndex = null;
		ArrayList<Integer> tempfilterList = null;
		Cell currentCell = null;
		ImgFilterResponseDTO imgFilterResponseDTO;
		

		try {
			if(industryFlag) {
				docId = hcpDocDAOobj.getDocumentIdForIndustry(fileName.replaceAll("[^a-zA-Z0-9]", "").toLowerCase(), "BASE");
			}else {
				docId = hcpDocDAOobj.getDocumentId(fileName.replaceAll("[^a-zA-Z0-9]", "").toLowerCase(), "BASE");
			}
			
			if (docId > 0) {
				
				Connection con = null;
				PreparedStatement pStmt = null;
				ResultSet rs = null;
				String storeDocIdQuery="";
				fileName=fileName.replaceAll("[^a-zA-Z0-9]", "").toLowerCase();
				if(industryFlag) {
					 storeDocIdQuery = "select file_blob from industry_documentstore where IMGDESC=?";
				}else {
					 storeDocIdQuery = "select file_blob from documentstore where IMGDESC=?";
				}
				
				try {
					con = DBConnection.createConnection();
					pStmt = (PreparedStatement) con.prepareStatement(storeDocIdQuery);
					pStmt.setString(1, fileName);
					rs = pStmt.executeQuery();
					while (rs.next()) {
						stream = rs.getBinaryStream("file_blob");
						stream1 = rs.getBinaryStream("file_blob");
						// slf4jLogger.info("file stream"+stream);
					}
				} catch (Exception e) {

				}
				
				workBook = new XSSFWorkbook(stream);
				//stream1 = templateDtailsDto.getStream();
				filterWorkBook = new XSSFWorkbook(stream1);
				int numberofSheet = workBook.getNumberOfSheets();

				for (int num = 0; num < numberofSheet; num++) {
					currentViewName = workBook.getSheetName(num).replaceAll("~", "/");
					if (currentViewName.equalsIgnoreCase("Instruction Sheet"))
						continue;
					columnList.clear();
					columnList_Filter.clear();
					sheet = workBook.getSheetAt(num);
					lastRowNumber = sheet.getLastRowNum();
					selectedRow = sheet.getRow(3);
					if (selectedRow != null) {
						currentCellIterator = selectedRow.cellIterator();
						for (int cellCount = 0; currentCellIterator.hasNext(); cellCount++) {
							cell = currentCellIterator.next();
							if (cellCount == 0)
								continue;
							if (cell != null) {
								cell.setCellType(Cell.CELL_TYPE_STRING);
								columnList.add(cell.getStringCellValue());
								columnList_Filter.add(currentViewName + cell.getStringCellValue());
							}
						}
						columnListSize = columnList.size();
					}
					selectedRow = sheet.getRow(5);
					if (selectedRow != null) {
						currentCellIterator = selectedRow.cellIterator();
						for (int cellCount = 0; currentCellIterator.hasNext(); cellCount++) {
							cell = currentCellIterator.next();
							if (cellCount == 0) {
								if (cell != null) {
									cell.setCellType(Cell.CELL_TYPE_STRING);
									tempCellValue = cell.getStringCellValue();
								}

								break;
							}
						}
					}

					count = 5;
					while (count <= lastRowNumber) {
						selectedRow = sheet.getRow(count);
						if (selectedRow != null)
							sheet.removeRow(selectedRow);
						count++;
					}
					selectedRow = sheet.createRow(5);
					cell = selectedRow.createCell(0, Cell.CELL_TYPE_STRING);
					cell.setCellValue(tempCellValue);

					fieldMap = new HashMap<>();
					for (int k = 0; k < columnListSize; k++) {
						fieldMappingDtoObj = new FieldMappingDto();
						fieldMappingDtoObj.setS_IMGID(imgDownloadDto.getImgId());
						fieldMappingDtoObj.setS_VIEW(currentViewName);
						fieldMappingDtoObj.setS_FIELD(columnList.get(k));
						fieldMap.put(columnList.get(k), fieldMappingDtoObj);

					}

					for (int currField = 0; currField < columnListSize; currField++) {
						retrievedValueList = new ArrayList<>();
						selectedFieldDto = fieldMap.get(columnList.get(currField));
						if (selectedFieldDto != null) {
							currentSourceView = selectedFieldDto.getS_VIEW();
							currentSourceField = selectedFieldDto.getS_FIELD();
							selectedOutputList = new ArrayList<>();
							selectedOutputList = downloadResponseDto.getDownloadRes();

							if (!selectedOutputList.isEmpty()) {
								int value = 0;
								currentSize = "";
								currentValue = "";
								searchValue = currentSourceField;
								currentSourceView = "|" + currentSourceView + "|";
								currentSourceField = "|" + currentSourceField + "|";
								if (warningMsg.length() <= 0) {
									if (selectedOutputList.size() > 2) {
										if (selectedOutputList.get(1).startsWith("M~"))
											warningMsg.append(selectedOutputList.get(1).split("~")[1] + ". ");
									}
								}
								selectedOutputListSize = selectedOutputList.size();
								for (int e = 0; e < selectedOutputListSize; e++) {
									if (selectedOutputList.get(e).contains(currentSourceView)
											&& selectedOutputList.get(e).contains(currentSourceField)) {
										currentValue = selectedOutputList.get(e);
										value = retrievedValueList.size() + 1;
										if (currentValue.split("\\|").length > 3) {
											currentSize = currentValue.split("\\|")[2];
											if (currentSize != null && currentSize != "") {
												try {
													while (Integer.parseInt(currentSize) > value) {
														retrievedValueList.add("");
														value++;
													}
												} catch (NumberFormatException ex) {
													slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, ex);
												}
											}
										}
										if (currentValue.split(searchValue).length > 1) {
											retrievedValueList.add(currentValue
													.split(searchValue)[currentValue.split(searchValue).length - 1]
															.substring(1));
										}
									}
								}
							}

							dataRow = 5;
							particularCell = null;
							retrievedValueListSize = retrievedValueList.size();
							for (int w = 0; w < retrievedValueListSize; w++) {
								selectedRow = sheet.getRow(dataRow);
								if (selectedRow == null) {
									selectedRow = sheet.createRow(dataRow);
									selectedRow.createCell(0, Cell.CELL_TYPE_STRING);
								}

								particularCell = selectedRow.getCell(currField + 1);
								if (particularCell == null) {
									particularCell = selectedRow.createCell(currField + 1, Cell.CELL_TYPE_STRING);
								}
								particularCell.setCellValue(retrievedValueList.get(w));
								dataRow++;
							}
						}
					}
					filterCriteria = false;
					key = "";
					filterColumn = -1;
					fieldValList = null;

					filterIndex = new ArrayList<Integer>();
					totalRow = sheet.getLastRowNum();
					filterIndexSize = 0;
					for (int i = 5; i <= totalRow; i++) {
						filterIndex.add(i);
					}
					for (Entry<String, ArrayList<String>> entry : filterMap.entrySet()) {
						key = entry.getKey();
						if (columnList_Filter.contains(key)) {
							filterColumn = columnList_Filter.indexOf(key);
							if (filterColumn >= 0) {
								fieldValList = entry.getValue();
								tempfilterList = new ArrayList<Integer>();
								filterIndexSize = filterIndex.size();
								for (int i = 0; i < filterIndexSize; i++) {
									filterCriteria = false;
									selectedRow = sheet.getRow(filterIndex.get(i));
									if (selectedRow != null) {
										currentCell = selectedRow.getCell(filterColumn + 1);
										if (currentCell != null) {
											currentCell.setCellType(Cell.CELL_TYPE_STRING);
											String cellVal = currentCell.getStringCellValue();
											for (String val : fieldValList) {
												if (val.endsWith("^")) {
													if (cellVal.startsWith(val.substring(0, val.length() - 1))) {
														filterCriteria = true;
														break;
													}
												} else if (val.equalsIgnoreCase(cellVal)) {
													filterCriteria = true;
													break;
												}
											}
										} else {
											break;
										}
									} else {
										break;
									}

									if (filterCriteria) {
										tempfilterList.add(filterIndex.get(i));
									}
								}
								filterIndex.clear();
								filterIndex.addAll(tempfilterList);
								tempfilterList = null;

							}
						}
					}

					filterSheet = filterWorkBook.getSheetAt(num);
					filterIndexSize = filterIndex.size();
					for (int i = 0; i < filterIndexSize; i++) {
						filterRow = filterSheet.createRow(i + 5);
						selectedRow = sheet.getRow(filterIndex.get(i));
						if (selectedRow != null) {
							for (int cellCount = 0; cellCount <= columnListSize; cellCount++) {
								cell = selectedRow.getCell(cellCount);
								if (cell != null) {
									cell.setCellType(Cell.CELL_TYPE_STRING);
									filterCell = filterRow.createCell(cellCount, Cell.CELL_TYPE_STRING);
									filterCell.setCellValue(cell.getStringCellValue());
								}
							}
						}
					}

				}
				if (workBook != null)
					workBook.close();

				imgFilterResponseDTO = new ImgFilterResponseDTO();
				imgFilterResponseDTO.setExcelWorkbook(filterWorkBook);
				imgFilterResponseDTO.setStatus(true);

			}

			else {
				imgFilterResponseDTO = new ImgFilterResponseDTO();
				imgFilterResponseDTO.setStatus(false);
				imgFilterResponseDTO.setErrDetails(
						"Filter criteria maintained for the template but template not available in Document Repository, please contact Administrator!!");
			}
		} catch (Exception e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			imgFilterResponseDTO = new ImgFilterResponseDTO();
			imgFilterResponseDTO.setErrDetails("Exception occured while filtering config data" + e.toString());
		} finally {
			slf4jLogger.info("getFilteredConfigData method ended");

		}
		return imgFilterResponseDTO;
	}

	// Added by Veena

	public DownloadResponseDto executeSrcConfigDownload_New(String destinationName, String targetPrgFilePath,
			List<String> imgId, String sapUserId, String destPasswrd, String language, String custDestReq, String sysNo,
			String hostName, String clientNo,boolean copyFlag, int sncEnabled,
			String sncName, String sncPartnerName, String sapRouter,String sncProtectionLevel, List<String> toPlants) {
		slf4jLogger.info("executeSrcConfigDownload method started"); // destName,destPasswrd,language,custDestReq
																		// added
																		// by
																		// Veena
		AppUtils appUtilsObj = null;
		JCoDestination destination = null;
		JCoRepository repo = null;
		JCoFunction stfcConnection = null;
		JCoParameterList tabInput = null;
		JCoTable paramTable = null;
		JCoTable progTable = null;
		int inputArrLength = 0;
		DownloadResponseDto downloadResponseDto = new DownloadResponseDto();
		ArrayList<String> resultText = null;
		JCoTable resultTable = null;
		int resultTableLen = 0;
		DynamicDestinationDAO dynamicDestinationDaoObj = new DynamicDestinationDAO(); // Added
																						// by
																						// Veena
		DynamicDestinationResDto dynamicDestinationResDto = new DynamicDestinationResDto();// Added
																							// by
																							// Veena

		try {
			resultText = new ArrayList<>();
			inputArrLength = imgId.size();
			appUtilsObj = new AppUtils();
			String copyTo ="";
			if(copyFlag) {
				if(toPlants!=null && !toPlants.isEmpty()) {
					for(String toPlant : toPlants) {
						
						if(copyTo.equals("")) {
							copyTo="|"+toPlant;
						}
						else {
							copyTo=copyTo+","+toPlant;
						}
					}
					copyTo=copyTo+"|COPY";
				}
			}
			// destination =
			// JCoDestinationManager.getDestination(destinationName); // Add
			// below
			// Added by Veena
			// destination =
			// JCoDestinationManager.getDestination(inputDTO.getDestinationName());
			/*
			 * if(inputDTO.getIsCustomDestinationRequired().equals("true")){
			 * dynamicDestinationResDto =
			 * dynamicDestinationDaoObj.createCustomDestinationObject(inputDTO.
			 * getSapUserId(),
			 * inputDTO.getSapPassword(),inputDTO.getSapLanguage(),
			 * destination);
			 * if(dynamicDestinationResDto.getStatus().equals("Success")) repo =
			 * dynamicDestinationResDto.getCustomDestination().getRepository();
			 * else resultText.
			 * add("Exception occured while creating custom Destination"); }
			 * else{ repo = destination.getRepository(); }
			 */

			// destination = JCoDestinationManager.getDestination(destName);
			// String DESTINATION_NAME2 = "K4XS4System";
			String DESTINATION_NAME2 = "K4XS4System";
			String sapPassword = null;
			String cipherTextSapPass = new String(java.util.Base64.getDecoder().decode(destPasswrd));
			
			
			AesUtil aesUtil = new AesUtil(128, 1000);
			if (cipherTextSapPass != null && cipherTextSapPass.split("::").length == 3) {   
		    	sapPassword = aesUtil.decrypt(cipherTextSapPass.split("::")[1], cipherTextSapPass.split("::")[0],destinationName, cipherTextSapPass.split("::")[2]);
		      } 
			Properties connectProperties = new Properties();
			MyDestinationDataProvider myDestinationDataProvider = MyDestinationDataProvider.getInstance();
			connectProperties.setProperty(DestinationDataProvider.JCO_DEST, destinationName);
			connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, hostName);
			connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR, sysNo);
			connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, clientNo);
			// connectProperties.setProperty(DestinationDataProvider.JCO_GWSERV,"3211");
			connectProperties.setProperty(DestinationDataProvider.JCO_USER, sapUserId);
			connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD, sapPassword);
			connectProperties.setProperty(DestinationDataProvider.JCO_LANG, language);
			
			
			if(sapRouter!=null) {
				connectProperties.setProperty(DestinationDataProvider.JCO_SAPROUTER, sapRouter);
			}
			// createDestinationDataFile(ConstantsValues.DESTINATION_NAMEK4X,
			// connectProperties);
			//String sncEnabled = System.getenv("SNC_ENABLED");
			if(sncEnabled==1){
				connectProperties.setProperty(DestinationDataProvider.JCO_SNC_MODE, String.valueOf(sncEnabled));
				
				connectProperties.setProperty(DestinationDataProvider.JCO_SNC_MYNAME, sncName);
				connectProperties.setProperty(DestinationDataProvider.JCO_SNC_PARTNERNAME,sncPartnerName );
				//connectProperties.setProperty(DestinationDataProvider.JCO_SNC_PARTNERNAME,"p:CN=C2P, OU=I0020981800, OU=SAP Web AS, O=SAP Trust Community, C=DE" );
				
				connectProperties.setProperty(DestinationDataProvider.JCO_SNC_QOP, sncProtectionLevel);
				connectProperties.setProperty(DestinationDataProvider.JCO_SNC_LIBRARY, System.getenv("SNC_LIB"));
			}
			
			myDestinationDataProvider.changePropertiesForABAP_AS(connectProperties);
			
			
			System.err.println("data provider" + Environment.isDestinationDataProviderRegistered());
			if (Environment.isDestinationDataProviderRegistered()) {
				System.err.println("inside if");
				Environment.unregisterDestinationDataProvider(myDestinationDataProvider);

			}
			Environment.registerDestinationDataProvider(myDestinationDataProvider);
			connectProperties.setProperty(DestinationDataProvider.JCO_POOL_CAPACITY, "3");
			connectProperties.setProperty(DestinationDataProvider.JCO_PEAK_LIMIT, "10");

			destination = JCoDestinationManager.getDestination(destinationName);
			System.out.println("Attributes:");
			System.out.println(destination.getAttributes());
			System.out.println();

			// JCoDestination destination =
			// JCoDestinationManager.getDestination(DESTINATION_NAME2);
			destination.ping();
			downloadResponseDto.setSrcConnectionStatus(true);
			System.out.println("Attributes:");
			System.out.println(destination.getAttributes());
			System.out.println();

			// JCoDestination destination1 =
			// JCoDestinationManager.getDestination(DESTINATION_NAME2);
			stfcConnection = destination.getRepository().getFunction("/ACNIP/RFC");
			if (stfcConnection == null) {
				downloadResponseDto.setErrorDetails("Source destination Connection issue");
				throw new RuntimeException("/ACNIP/RFC not found in SAP.");
			}

			/*
			 * if(custDestReq.equalsIgnoreCase("Y")){ String cipherTextSapPass =
			 * new String(java.util.Base64.getDecoder().decode(destPasswrd));
			 * AesUtil aesUtil = new AesUtil(128, 1000);
			 * 
			 * if (cipherTextSapPass != null &&
			 * cipherTextSapPass.split("::").length == 3) { destPasswrd =
			 * aesUtil.decrypt(cipherTextSapPass.split("::")[1],
			 * cipherTextSapPass.split("::")[0], destinationName,
			 * cipherTextSapPass.split("::")[2]); } dynamicDestinationResDto =
			 * dynamicDestinationDaoObj.createCustomDestinationObject(sapUserId,
			 * destPasswrd,language,destination);
			 * if(dynamicDestinationResDto.getStatus().equals("Success")) repo =
			 * dynamicDestinationResDto.getCustomDestination().getRepository();
			 * else resultText.
			 * add("Exception occured while creating custom Destination"); }
			 * else{ repo = destination.getRepository(); } Ended by Veena repo =
			 * destination.getRepository();
			 * downloadResponseDto.setSrcConnectionStatus(true); stfcConnection
			 * = repo.getFunction("/ACNIP/RFC"); if (stfcConnection == null){
			 * downloadResponseDto.
			 * setErrorDetails("Source destination Connection issue"); throw new
			 * RuntimeException("/ACNIP/RFC not found in SAP."); }
			 */
			tabInput = stfcConnection.getTableParameterList();
			paramTable = tabInput.getTable("I_PARAM");

			if(copyFlag) {
				for (int i = 0; i < inputArrLength; i++) {
					paramTable.appendRow();
					paramTable.setValue("WA", imgId.get(i)+copyTo);
				}
			}
			else {
				for (int i = 0; i < inputArrLength; i++) {
					paramTable.appendRow();
					paramTable.setValue("WA", imgId.get(i));
				}
			}

			progTable = appUtilsObj.getABAPPrg(targetPrgFilePath, tabInput);

			try {
				/*
				 * if(custDestReq.equalsIgnoreCase("Y")){
				 * stfcConnection.execute(dynamicDestinationResDto.
				 * getCustomDestination()); } else
				 */
				stfcConnection.execute(destination);
				downloadResponseDto.setSrcExecutionStatus(true);
				// slf4jLogger.info("tabInput" + tabInput);
				resultTable = tabInput.getTable("O_RESULT");
				resultTableLen = resultTable.getNumRows();
				for (int i = 0; i < resultTableLen; i++) {
					resultTable.setRow(i);
					resultText.add(resultTable.getString("WA"));
				}
				downloadResponseDto.setDownloadRes(resultText);
			}

			catch (JCoException e) {
				// downloadResponseDto.setErrorDetails(e.getLocalizedMessage());
				if(e.getKey().equalsIgnoreCase("JCO_ERROR_COMMUNICATION")) {
					downloadResponseDto.setErrorDetails(destinationName + " not reachable. Please try again");
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
					resultText.add("JCO Execution Failed: " + e);
					downloadResponseDto.setDownloadRes(resultText);
					downloadResponseDto.setSrcConnectionStatus(false);
				}else if(e.getKey().equalsIgnoreCase("JCO_ERROR_TIMEOUT")){
						downloadResponseDto.setErrorDetails("Timeout occured while connecting to "+destinationName +" Please try again");
						slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
						resultText.add("JCO Execution Failed: " + e);
						downloadResponseDto.setDownloadRes(resultText);
						downloadResponseDto.setSrcConnectionStatus(false);
					}	
				else {
				// downloadResponseDto.setErrorDetails(e.getLocalizedMessage());
				downloadResponseDto.setErrorDetails("Exception raised by SAP System. Please contact Administrator");
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				resultText.add("JCO Execution Failed: " + e);
				downloadResponseDto.setDownloadRes(resultText);
				downloadResponseDto.setSrcConnectionStatus(false);
				}
			} catch (OutOfMemoryError e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				resultText.add("Out of memory Exception from SAP" + e);
				downloadResponseDto.setDownloadRes(resultText);
				downloadResponseDto.setSrcExecutionStatus(false);
			} catch (Exception e) {
				// downloadResponseDto.setErrorDetails(e.getLocalizedMessage());
				downloadResponseDto.setErrorDetails(destinationName + ConstantsValues.DESTINATIONDOWN);
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				resultText.add("Execution of RFC Failed: " + e);
				downloadResponseDto.setSrcExecutionStatus(false);
				downloadResponseDto.setDownloadRes(resultText);
			} catch (Throwable e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				resultText.add("Out of memory Exception from SAP" + e);
				downloadResponseDto.setDownloadRes(resultText);
				downloadResponseDto.setSrcExecutionStatus(false);
			}
		} /*
			 * catch (JCoException e) {
			 * //downloadResponseDto.setErrorDetails(e.getLocalizedMessage());
			 * downloadResponseDto.setErrorDetails(destinationName+
			 * ConstantsValues.DESTINATIONDOWN);
			 * slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			 * resultText.add("JCO Connection Failed: " + e);
			 * downloadResponseDto.setDownloadRes(resultText);
			 * downloadResponseDto.setSrcConnectionStatus(false); }
			 */
		catch (JCoException e) {
			if(e.getKey().equalsIgnoreCase("JCO_ERROR_COMMUNICATION")) {
				downloadResponseDto.setErrorDetails(destinationName + " not reachable. Please try again");
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				resultText.add("JCO Execution Failed: " + e);
				downloadResponseDto.setDownloadRes(resultText);
				downloadResponseDto.setSrcConnectionStatus(false);
			}else if(e.getKey().equalsIgnoreCase("JCO_ERROR_TIMEOUT")){
				downloadResponseDto.setErrorDetails("Timeout occured while connecting to "+destinationName +" Please try again");
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				resultText.add("JCO Execution Failed: " + e);
				downloadResponseDto.setDownloadRes(resultText);
				downloadResponseDto.setSrcConnectionStatus(false);
			}else {
			// downloadResponseDto.setErrorDetails(e.getLocalizedMessage());
			downloadResponseDto.setErrorDetails("Exception raised by SAP System. Please contact Administrator");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("JCO Execution Failed: " + e);
			downloadResponseDto.setDownloadRes(resultText);
			downloadResponseDto.setSrcConnectionStatus(false);
			}
		}
		catch (java.lang.NoClassDefFoundError e) {
			// downloadResponseDto.setErrorDetails(e.getLocalizedMessage());
			downloadResponseDto.setErrorDetails(destinationName + ConstantsValues.DESTINATIONDOWN);
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("JCO Library Issue.  " + e);
			downloadResponseDto.setSrcConnectionStatus(false);
		} catch (java.lang.ExceptionInInitializerError e) {
			// downloadResponseDto.setErrorDetails(e.getLocalizedMessage());
			downloadResponseDto.setErrorDetails(destinationName + ConstantsValues.DESTINATIONDOWN);
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("JCO Library Issue. " + e);
			downloadResponseDto.setSrcConnectionStatus(false);
		} catch (Exception e) {
			// downloadResponseDto.setErrorDetails(e.getLocalizedMessage());
			downloadResponseDto.setErrorDetails(destinationName + ConstantsValues.DESTINATIONDOWN);
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("Configuration Failed: " + e);
			downloadResponseDto.setDownloadRes(resultText);
			downloadResponseDto.setSrcExecutionStatus(false);
		}

		catch (OutOfMemoryError e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			resultText.add("Out of memory Exception from SAP" + e);
			downloadResponseDto.setDownloadRes(resultText);
			downloadResponseDto.setSrcExecutionStatus(false);
		} finally {
			resultText = null;
			destination = null;
			repo = null;
			stfcConnection = null;
			tabInput = null;
			if (paramTable != null)
				paramTable.clear();
			if (progTable != null)
				progTable.clear();
			appUtilsObj = null;
			if (resultTable != null)
				resultTable.clear();
			slf4jLogger.info("executeSrcConfigDownload method ended");

		}

		return downloadResponseDto;
	}

	public TemplateDetailsDto getDocumnetDetails(String fileName) {
		Connection con = null;
		PreparedStatement pStmt = null;
		ResultSet rs = null;
		TemplateDetailsDto tempDto = new TemplateDetailsDto();
		InputStream stream = null;
		 fileName=fileName.replaceAll("[^a-zA-Z0-9]", "").toLowerCase();
		String storeDocIdQuery = "select file_blob from documentstore where IMGDESC=?";

		try {
			con = DBConnection.createConnection();
			pStmt = (PreparedStatement) con.prepareStatement(storeDocIdQuery);
			pStmt.setString(1, fileName);
			rs = pStmt.executeQuery();
			while (rs.next()) {
				stream = rs.getBinaryStream("file_blob");
				// stream1 = rs.getBinaryStream("file_blob");
				// slf4jLogger.info("file stream"+stream);
			}
			tempDto.setStream(stream);
		} catch (Exception e) {

		}
		return tempDto;

	}
	
	public TemplateDetailsDto getDocumentDetailsForIndustry(String fileName) {
		Connection con = null;
		PreparedStatement pStmt = null;
		ResultSet rs = null;
		TemplateDetailsDto tempDto = new TemplateDetailsDto();
		InputStream stream = null;
		
		String storeDocIdQuery = "select file_blob from industry_documentstore where IMGDESC=?";

		try {
			con = DBConnection.createConnection();
			pStmt = (PreparedStatement) con.prepareStatement(storeDocIdQuery);
			pStmt.setString(1, fileName);
			rs = pStmt.executeQuery();
			while (rs.next()) {
				stream = rs.getBinaryStream("file_blob");
				// stream1 = rs.getBinaryStream("file_blob");
				// slf4jLogger.info("file stream"+stream);
			}
			tempDto.setStream(stream);
		} catch (Exception e) {

		}
		return tempDto;

	}
		
	
	public IndustryResponseDto getindustryAlias(IndustryDto dto) {
		IndustryResponseDto industryResponseDto = new IndustryResponseDto();
		Connection con = null;
		PreparedStatement ps=null;
		ResultSet rs=null;
	
		
		try {
    		con =  DBConnection.createConnection();			
    			String query = "SELECT ALIAS_INDUSTRY,ALIAS_SUBINDUSTRY FROM INDUSTRY_VALUES WHERE INDUSTRY = ? AND SUBINDUSTRY =?";
    		
    				
	    			ps = con.prepareStatement(query);
	    			ps.setString(1,dto.getIndustry());
	    			ps.setString(2,dto.getSubIndustry());
    				
	    			rs = ps.executeQuery();
    				
    				while(rs.next()) {
    					String aliasIndustry = rs.getString("ALIAS_INDUSTRY");
    					String aliasSubIndustry = rs.getString("ALIAS_SUBINDUSTRY");
    		
    						industryResponseDto.setAliasIndustry(aliasIndustry);
    						industryResponseDto.setAliasSubIndustry(aliasSubIndustry);
    					
    				}
			
    	}catch (SQLException e){
    		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
    	
    	}finally {
    		if(rs!=null){
				try {
					rs.close();
					rs=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
    		if(ps!=null){
				try {
					ps.close();
					ps=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
    	}
		return industryResponseDto;
	}


}