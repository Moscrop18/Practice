package com.acn.rpa.config;

public class DownloadDto {

	private String filePath;
	private String scopename;
		
	public DownloadDto() {
	}
	
	public DownloadDto(String filePath, String scopename) {
		super();
		this.filePath = filePath;
		this.scopename = scopename;
	}
	
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public String getScopename() {
		return scopename;
	}
	public void setScopename(String scopename) {
		this.scopename = scopename;
	}
}
