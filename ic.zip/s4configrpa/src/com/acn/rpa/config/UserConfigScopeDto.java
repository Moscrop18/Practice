/**
 * @author insimmamul.haq.p.b
 */
package com.acn.rpa.config;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.acn.user.session.SessionInputDTO;

public class UserConfigScopeDto {
	@Size(min = 1, max = 8)
	@Pattern(regexp = "[a-zA-Z0-9]+")
	private String userId;
	@Size(min = 1, max = 20)
	private String omId;
	private Boolean copyFlag=false;
	
	private boolean industryFlag;
	
	private String industry;
	
	private String subIndustry;
	
	public boolean isIndustryFlag() {
		return industryFlag;
	}
	public void setIndustryFlag(boolean industryFlag) {
		this.industryFlag = industryFlag;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public String getSubIndustry() {
		return subIndustry;
	}
	public void setSubIndustry(String subIndustry) {
		this.subIndustry = subIndustry;
	}
	public Boolean getCopyFlag() {
		return copyFlag;
	}
	public void setCopyFlag(Boolean copyFlag) {
		this.copyFlag = copyFlag;
	}
	@DecimalMin(value = "0")
    @DecimalMax(value = "5")	
	private int implementationType;
	@Valid
	private SessionInputDTO sessionInputDTO;
	
	public SessionInputDTO getSessionInputDTO() {
		return sessionInputDTO;
	}
	public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
		this.sessionInputDTO = sessionInputDTO;
	}
	public int getImplementationType() {
		return implementationType;
	}

	public void setImplementationType(int implementationType) {
		this.implementationType = implementationType;
	}
	@Valid
	private List<String> imgIdList;
	
	
	public UserConfigScopeDto(){
	}
	
	public List<String> getImgIdList() {
		return imgIdList;
	}

	public void setImgIdList(List<String> imgIdList) {
		this.imgIdList = imgIdList;
	}
	

	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getOmId() {
		return omId;
	}
	public void setOmId(String omId) {
		this.omId = omId;
	}


}
