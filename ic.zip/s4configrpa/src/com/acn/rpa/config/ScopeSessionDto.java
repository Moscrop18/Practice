package com.acn.rpa.config;

import java.util.ArrayList;

public class ScopeSessionDto {
	private String userId;
	private String omId;
	private int implementationType;
	
	public int getImplementationType() {
		return implementationType;
	}
	public void setImplementationType(int implementationType) {
		this.implementationType = implementationType;
	}
	private ArrayList<IMGScopeDto> imgScopeDto;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getOmId() {
		return omId;
	}
	public void setOmId(String omId) {
		this.omId = omId;
	}
	public ArrayList<IMGScopeDto> getImgScopeDto() {
		return imgScopeDto;
	}
	public void setImgScopeDto(ArrayList<IMGScopeDto> imgScopeDto) {
		this.imgScopeDto = imgScopeDto;
	}
	
}
