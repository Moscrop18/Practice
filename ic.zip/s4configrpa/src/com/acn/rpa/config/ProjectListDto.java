package com.acn.rpa.config;

import java.util.List;


import com.acn.user.session.ResMessageDto;

public class ProjectListDto {
	private List<ProjectDto> projectList;
	private ResMessageDto resMessageDto;
	public List<ProjectDto> getProjectList() {
		return projectList;
	}
	public void setProjectList(List<ProjectDto> projectList) {
		this.projectList = projectList;
	}
	public ResMessageDto getResMessageDto() {
		return resMessageDto;
	}
	public void setResMessageDto(ResMessageDto resMessageDto) {
		this.resMessageDto = resMessageDto;
	}
	
	}
