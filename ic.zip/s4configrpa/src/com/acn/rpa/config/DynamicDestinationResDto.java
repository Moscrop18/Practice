package com.acn.rpa.config;

import com.acn.user.session.ResMessageDto;
import com.sap.conn.jco.JCoCustomDestination;




public class DynamicDestinationResDto {
	private String status;
	private String message;
	JCoCustomDestination customDestination;
	private ResMessageDto resMessageDto;

	public ResMessageDto getResMessageDto() {
			return resMessageDto;
		}
	public void setResMessageDto(ResMessageDto resMessageDto) {
			this.resMessageDto = resMessageDto;
		}
	
	public JCoCustomDestination getCustomDestination() {
		return customDestination;
	}
	public void setCustomDestination(JCoCustomDestination customDestination) {
		this.customDestination = customDestination;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	

}
