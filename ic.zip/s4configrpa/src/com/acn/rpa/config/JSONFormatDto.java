package com.acn.rpa.config;

public class JSONFormatDto {

	private String description;
	private String errorType;
	private String messageType;
	private String scopeName;

	public String getMessageType() {
		return messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public JSONFormatDto(String description, String errorType, String messageType)  {
		super();
		this.description = description;
		this.errorType = errorType;
		this.messageType = messageType;
	}
	
	public JSONFormatDto(){
		
	}
	public String getErrorType() {
		return errorType;
	}

	public void setErrorType(String errorType) {
		this.errorType = errorType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public JSONFormatDto(String description) {
		super();
		this.description = description;
	}

	@Override
	public String toString() {
		return "JSONFormatModel [description=" + description + ", errorType=" + errorType + "]";
	}

	/**
	 * @return the scopeName
	 */
	public String getScopeName() {
		return scopeName;
	}

	/**
	 * @param scopeName the scopeName to set
	 */
	public void setScopeName(String scopeName) {
		this.scopeName = scopeName;
	}
}
