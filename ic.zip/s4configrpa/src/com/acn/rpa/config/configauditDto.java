package com.acn.rpa.config;

import javax.validation.Valid;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.acn.user.session.SessionInputDTO;

public class configauditDto {
	
	@DecimalMin(value = "1")
    @DecimalMax(value = "9999999")
	private int transactionID;
	@DecimalMin(value = "1")
    @DecimalMax(value = "9999999")
	private int configUploadID;
	@Size(min = 1, max = 30)
	private String imgID;
	@Valid
	private SessionInputDTO sessionInputDTO;
	@Size(min = 0, max = 10)
	@Pattern(regexp = "[a-zA-Z0-9]*$")
	private String workbenchTr;
	@Size(min = 0, max = 10)
	@Pattern(regexp = "[a-zA-Z0-9]*$")
	private String customizingTr;
	private boolean isIMGHierarchy;
	private String errorReason;
	//@Size(min = 1, max = 30)
	private String omgID;
	public String getOmgID() {
		return omgID;
	}
	public void setOmgID(String omgID) {
		this.omgID = omgID;
	}
	public int getTransactionID() {
		return transactionID;
	}
	public void setTransactionID(int transactionID) {
		this.transactionID = transactionID;
	}
	public String getImgID() {
		return imgID;
	}
	public void setImgID(String imgID) {
		this.imgID = imgID;
	}
	public SessionInputDTO getSessionInputDTO() {
		return sessionInputDTO;
	}
	public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
		this.sessionInputDTO = sessionInputDTO;
	}
	public String getWorkbenchTr() {
		return workbenchTr;
	}
	public void setWorkbenchTr(String workbenchTr) {
		this.workbenchTr = workbenchTr;
	}
	public String getCustomizingTr() {
		return customizingTr;
	}
	public void setCustomizingTr(String customizingTr) {
		this.customizingTr = customizingTr;
	}
	public boolean isIMGHierarchy() {
		return isIMGHierarchy;
	}
	public void setIMGHierarchy(boolean isIMGHierarchy) {
		this.isIMGHierarchy = isIMGHierarchy;
	}
	public String getErrorReason() {
		return errorReason;
	}
	public void setErrorReason(String errorReason) {
		this.errorReason = errorReason;
	}
}
