
	package com.acn.rpa.config;

	import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.config.dto.ConfigTemplateDto;
import com.acn.rpa.config.dto.SelectedScopeDto;
import com.acn.rpa.utilities.ConstantsValues;

public class ExcelFormatConvert {
	
    private final Logger slf4jLogger = LoggerFactory.getLogger(ExcelFormatConvert.class);

    
	public ConfigInputDTO convertFormat(byte[] fileBytes, ArrayList<String> viewList) {
		  slf4jLogger.info("convertFormat method started");
			FileInputStream file = null;
			Workbook workbook = null;
			ConfigInputDTO configInputDTO = null;
			ByteArrayInputStream byteIn = null;
			try {
				byteIn = new ByteArrayInputStream(fileBytes);
				configInputDTO = new ConfigInputDTO();
				//file = new FileInputStream(new File(srcFile));
				workbook = WorkbookFactory.create(byteIn);
				configInputDTO =  getConfigDataForTargetSystem(workbook,viewList);  
			} catch (Exception e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
			finally{
				file = null;
				
				try {
					if(workbook != null)
						workbook.close();
					if(byteIn != null)
						byteIn.close();
					byteIn = null;
				} catch (IOException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}

			}
			return configInputDTO;
				
		}	
	public ConfigInputDTO convertConsolidationFormat(byte[] fileBytes, ArrayList<String> viewList, String imgId) {
		  slf4jLogger.info("convertConsolidationFormat method started");
			FileInputStream file = null;
			Workbook workbook = null;
			ConfigInputDTO configInputDTO = null;
			ByteArrayInputStream byteIn = null;
			try {
				byteIn = new ByteArrayInputStream(fileBytes);
				configInputDTO = new ConfigInputDTO();
				//file = new FileInputStream(new File(srcFile));
				workbook = WorkbookFactory.create(byteIn);
				configInputDTO =  getConsolidationDataForTargetSystem(workbook,viewList,imgId);  
			} catch (Exception e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
			finally{
				file = null;
				
				try {
					if(workbook != null)
						workbook.close();
					if(byteIn != null)
						byteIn.close();
					byteIn = null;
				} catch (IOException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
				  slf4jLogger.info("convertConsolidationFormat method ended");

			}
			return configInputDTO;
				
		}
		
		public ConfigInputDTO getConfigDataForTargetSystem(Workbook workbook, ArrayList<String> viewList) {
			slf4jLogger.info("getConfigDataForTargetSystem method started");
			Sheet sheet = null;
			ArrayList<String> recordByView = null;
			ArrayList<String> temp  = null;
			StringBuilder dataChange = null;
			List<String> viewCluster = null;
			List<String> view = null;
			List<String> setFields = null;
			List<String> data = null;
			ConfigInputDTO configInputDTO = null;
			DataFormatter formatter = new DataFormatter();
			try {
				int viewSize = 0;
				recordByView  =new ArrayList<>();
				configInputDTO = new ConfigInputDTO();
				boolean IMGFlag = false;
				String cellValue = "";	
				int numberofSheet = 0;
				if(workbook != null)
					numberofSheet = workbook.getNumberOfSheets();
				if(viewList != null && numberofSheet > 0){
					viewSize = viewList.size(); 
					if(viewSize > 1){
						int currentPos = 1;
						if(numberofSheet == viewSize){
							currentPos = viewSize;
						}else if(numberofSheet == (viewSize+1)){
							currentPos = viewSize+1;
						}
						if(currentPos > 1){
							for(int i = currentPos-1; i > 0; i--,viewSize--){
								if(!workbook.getSheetName(i).equals(viewList.get(viewSize-1))){
									workbook.setSheetOrder(viewList.get(viewSize-1), i);
								}
							}
						}	
					}
				}
							
				for(int num = 0; num < numberofSheet; num++){
					if(workbook.getSheetName(num).equals(ConstantsValues.INSTRUCTIONSHEET))
						continue;
					viewCluster = new ArrayList<>();
					view = new ArrayList<>();
					setFields = new ArrayList<>();
					data = new ArrayList<>();
			
					sheet = workbook.getSheetAt(num);
					Iterator<Row> rowIterator = sheet.iterator();
					int viewRowno = 2;
					short columnsize = 0;
					short rowSize = 0;
					int dataRowCount = 0;
					Row viewRow = sheet.getRow(viewRowno);
					Cell tempCell = null;
					
					columnsize = viewRow.getLastCellNum();
					short currentSize = 0;
					while(currentSize < columnsize){
						tempCell = viewRow.getCell(currentSize);
						 if(tempCell == null){
                			 break;
                		 }else{
                			// tempCell.setCellType(Cell.CELL_TYPE_STRING);
                			 //if(tempCell.getStringCellValue().trim().length()<=0)
                			 if(formatter.formatCellValue(tempCell).trim().length()<=0)
                				 break;
                		 }
						currentSize++;
					}
				
					columnsize = currentSize;
					columnsize -=1;
					int cellCount = 0;
					for (rowSize = 0;rowIterator.hasNext(); rowSize++) {
						 Row nextRow = rowIterator.next();
						if(rowSize == 0 && IMGFlag)
							continue;
						if(rowSize == 4)
							continue;
			            for(cellCount = 0;cellCount <= columnsize; cellCount++) {
			            	Cell cell = nextRow.getCell(cellCount);
			            	
		                if(cellCount == 0 && IMGFlag)
							continue;
		                	 if(cellCount > 0 ){
		                		 
		                		 if(cell == null){
		                			 cellValue = "";
		                		 }else{
		                			// cell.setCellType(Cell.CELL_TYPE_STRING);
		                			 cellValue = formatter.formatCellValue(cell).trim();
		                		 }
		                	 
		                	 if(rowSize == 0 && !IMGFlag && cellCount == 1){
		                		 recordByView.add(cellValue);
		                		
		                		 IMGFlag = true;
		                		 break;
		                	 }
		                	  
		                	 if(rowSize == 1)
		                		 viewCluster.add(cellValue);
		                	 else  if(rowSize == 2)
		                		 view.add(cellValue);
		                	 else  if(rowSize == 3)
		                		 setFields.add(cellValue);
		                	 else if(rowSize > 4)
		                		 data.add(cellValue);
		                	 
		                 }
		            }
		            if(rowSize > 4){
		            	dataRowCount++;
		            	while(cellCount <= columnsize){
		            		 data.add("");
		            		 cellCount++;
		             }
		            	
		            }
				}
				
				int dataCount = 0; 
				boolean isValid = false;
		            for(int j = 1; j <= dataRowCount;j++){
		            	temp = new ArrayList<>();
		            	for(int k = 0; k < columnsize; k++){
		            		dataChange = new StringBuilder();
		            		dataChange.append(viewCluster.get(k));
			            	dataChange.append("|");
			            	dataChange.append(view.get(k));
			            	dataChange.append("|");
			            	dataChange.append(j);
			            	dataChange.append("|");
			            	dataChange.append(setFields.get(k));
			            	dataChange.append("|");
			            	dataChange.append(data.get(dataCount));
//			            	
			            	//Added on 07 Aug 2017
			            	if(data.get(dataCount) != null && data.get(dataCount).length() > 0){
			            		isValid = true;
			            	}
			            	temp.add(dataChange.toString());
			            	dataCount++;
		            	}
		            	if(isValid){
		            		recordByView.addAll(temp);
		            		isValid = false;
		            	}
		            }
		            configInputDTO.setRecordByView(recordByView);
		            configInputDTO.setRecordCount(dataRowCount);
		            
				}
			} catch (Exception e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
			finally{
				temp = null;
				dataChange = null;
				sheet = null;
				viewCluster = null;
				view = null;
				setFields = null;
				data = null;
				try {
					if(workbook != null)
					workbook.close();
				} catch (IOException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
				
				slf4jLogger.info("getConfigDataForTargetSystem method ended");

			}
			return configInputDTO;
				
		}	
		public ConfigInputDTO getConsolidationDataForTargetSystem(Workbook workbook, ArrayList<String> viewList, String imgId) {
			slf4jLogger.info("getConsolidationDataForTargetSystem method started");
			Sheet sheet = null;
			ArrayList<String> recordByView = null;
			ArrayList<String> temp  = null;
			StringBuilder dataChange = null;
			List<String> viewCluster = null;
			List<String> view = null;
			List<String> setFields = null;
			List<String> data = null;
			ConfigInputDTO configInputDTO = null;
			try {
				int viewSize = 0;
				recordByView  =new ArrayList<>();
				recordByView.add(imgId);
				configInputDTO = new ConfigInputDTO();
				boolean IMGFlag = false;
				String cellValue = "";
				String indicator="";
				int numberofSheet = 0;
				if(workbook != null)
					numberofSheet = workbook.getNumberOfSheets();
											
				for(int num = 0; num < numberofSheet; num++){
					if(!workbook.getSheetName(num).equals("Long Report_"+viewList.get(0)))
						continue;
					viewCluster = new ArrayList<>();
					view = new ArrayList<>();
					setFields = new ArrayList<>();
					data = new ArrayList<>();
			
					sheet = workbook.getSheetAt(num);
					Iterator<Row> rowIterator = sheet.iterator();
					int viewRowno = 0;
					short columnsize = 0;
					short rowSize = 0;
					int dataRowCount = 0;
					Row viewRow = sheet.getRow(viewRowno);
					Cell tempCell = null;
					
					columnsize = viewRow.getLastCellNum();
					short currentSize = 0;
					while(currentSize < columnsize){
						tempCell = viewRow.getCell(currentSize);
						 if(tempCell == null){
                			 break;
                		 }else{
                			 tempCell.setCellType(Cell.CELL_TYPE_STRING);
                			 if(tempCell.getStringCellValue().trim().length()<=0)
                				 break;
                		 }
						currentSize++;
					}
				
					columnsize = currentSize;
					columnsize -=1;
					int cellCount = 0;
					for (rowSize = 0;rowIterator.hasNext(); rowSize++) {
						 Row nextRow = rowIterator.next();
						if(rowSize == 2)
							continue;
					for (cellCount = 0; cellCount <= columnsize; cellCount++) {
						Cell cell = nextRow.getCell(cellCount);
						
						if(cellCount>0) {
							if (cell == null) {
								cellValue = "";
							} else {
								cell.setCellType(Cell.CELL_TYPE_STRING);
								cellValue = cell.getStringCellValue();
							}

							if (rowSize == 0 && cellCount>1) {
								viewCluster.add(cellValue.substring(6));
								view.add(cellValue.substring(6));
							} else if (rowSize == 1) {
								if (cellValue.equalsIgnoreCase("Field"))
									cellValue = "MANDT";
								setFields.add(cellValue);
							} else if (rowSize > 2) {
								short col = 0;
								tempCell = nextRow.getCell(col);
								if (tempCell == null) {
									indicator = "";
								} else {
									tempCell.setCellType(Cell.CELL_TYPE_STRING);
									indicator = tempCell.getStringCellValue();
								}
								if (indicator.trim().equalsIgnoreCase("yes"))
								{
									if(cellCount==1)
										data.add(cellValue.split(" ")[1]);
									else
										data.add(cellValue);
								}
							}	
						}
						

					}
		            if(rowSize > 2){
		            	short col = 0;
						tempCell = nextRow.getCell(col);
						if (tempCell == null) {
							indicator = "";
						} else {
							tempCell.setCellType(Cell.CELL_TYPE_STRING);
							indicator = tempCell.getStringCellValue();
						}
						if (indicator.trim().equalsIgnoreCase("yes")) {
		            	dataRowCount++;
		            	while(cellCount <= columnsize){
		            		 data.add("");
		            		 cellCount++;
		            		}
						}
		            	
		            }
				}
					viewCluster.add(viewCluster.get(0));
					view.add(view.get(0));
				int dataCount = 0; 
				boolean isValid = false;
		            for(int j = 1; j <= dataRowCount;j++){
		            	temp = new ArrayList<>();
		            	for(int k = 0; k < columnsize; k++){
		            		dataChange = new StringBuilder();
		            		dataChange.append(viewCluster.get(k));
			            	dataChange.append("|");
			            	dataChange.append(view.get(k));
			            	dataChange.append("|");
			            	dataChange.append(j);
			            	dataChange.append("|");
			            	dataChange.append(setFields.get(k));
			            	dataChange.append("|");
			            	dataChange.append(data.get(dataCount));
//			            	
			            	//Added on 07 Aug 2017
			            	if(data.get(dataCount) != null && data.get(dataCount).length() > 0){
			            		isValid = true;
			            	}
			            	temp.add(dataChange.toString());
			            	dataCount++;
		            	}
		            	if(isValid){
		            		recordByView.addAll(temp);
		            		isValid = false;
		            	}
		            }
		            configInputDTO.setRecordByView(recordByView);
		            configInputDTO.setRecordCount(dataRowCount);
		            
				}
			} catch (Exception e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
			finally{
				temp = null;
				dataChange = null;
				sheet = null;
				viewCluster = null;
				view = null;
				setFields = null;
				data = null;
				try {
					if(workbook != null)
					workbook.close();
				} catch (IOException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
				
				slf4jLogger.info("getConsolidationDataForTargetSystem method ended");

			}
			return configInputDTO;
				
		}	
		
		public ConfigTemplateDto configFileValidation(SelectedScopeDto selectedScopeDto,ArrayList<String> sheetNameList,String roleType ) {
			//slf4jLogger.info("configFileValidation method started");
			//System.out.println("confile is started");
			ConfigTemplateDto configTempDto = new ConfigTemplateDto();
			boolean templateStatus = true;
			InputStream file = null;
			Workbook workbook = null;
			int numberofSheet = 0;
			int templateSheetSize = sheetNameList.size();
			short columnsize = 0;
			short rowSize = 0;
			Sheet sheet = null;
			Row viewRow =  null;
			Cell currentCell  = null;
			String viewName = "";
			String cellValue = "";
			int cellCount = 0;
			ArrayList<String> excelViewList = new ArrayList<>(); 
			ArrayList<String> validateMsg = new ArrayList<>();
			String currentImgId = selectedScopeDto.getImgId();
			ByteArrayInputStream byteIn = null;
			DataFormatter formatter = new DataFormatter();
			
			//slf4jLogger.info("before try block");
			try {
				
				
				configTempDto.setSelectedScopeDto(selectedScopeDto);
				//slf4jLogger.info("file bytes"+selectedScopeDto.getFileBytes());
				//if(selectedScopeDto.getFilepath() != null && selectedScopeDto.getFilepath().length() > 0)
				if(selectedScopeDto.getFileBytes() != null && selectedScopeDto.getFileBytes().length > 0){
					
					byteIn = new ByteArrayInputStream(selectedScopeDto.getFileBytes());
				//file = new FileInputStream(new File(selectedScopeDto.getFilepath()));
				//if(file != null){
				workbook = WorkbookFactory.create(byteIn);
				//workbook = new Workbook(byteIn);
					if (workbook != null) {
						numberofSheet = workbook.getNumberOfSheets();
					}
				//}
				selectedScopeDto.setFileUploadStatusMsg(validateMsg);
		
					for(int num = 0; num<numberofSheet; num++){
						viewName = workbook.getSheetName(num).replaceAll("~", "/").trim();
						excelViewList.add(viewName);
						if(viewName.equalsIgnoreCase(ConstantsValues.INSTRUCTIONSHEET)){
							templateSheetSize++;
							continue;
						}else if(sheetNameList.contains(viewName)){
							sheet = workbook.getSheetAt(num);
							Iterator<Row> rowIterator = sheet.iterator();
							viewRow = sheet.getRow(2);
							columnsize = viewRow.getLastCellNum();
							columnsize -=1;
							
							for (rowSize = 0;(rowSize <= 3 && rowIterator.hasNext()); rowSize++) {
								 viewRow = rowIterator.next();
								 if(rowSize == 1){
									 continue;
								 }
								
					            for(cellCount = 1;cellCount <= columnsize; cellCount++) {
					            	currentCell = viewRow.getCell(cellCount);
				                		 if(currentCell == null){
				                			 templateStatus = false;
				                			 if(rowSize == 0){
				                				 validateMsg.add(currentImgId +" IMGID in the first row of the file and selected Scope name Should be same");
				                				 configTempDto.setStatusMsg(currentImgId +" IMGID in the first row of the file and selected Scope name Should be same"); 
				                			 }else if(rowSize == 2){
				                				 validateMsg.add(viewName +" View in the third row of the file and Sheet name Should be same");
				                				 configTempDto.setStatusMsg(viewName +" View in the third row of the file and Sheet name Should be same");
				                			 }else if(rowSize == 3){
				                				 validateMsg.add("Field Name(Row number 4 from uploaded template) for "+viewName+" view is missing.");
				                				 configTempDto.setStatusMsg("Field Name(Row number 4 from uploaded template) for "+viewName+" view is missing.");
				                			 }
				                			 break;
				                		 }else {
				                			// currentCell.setCellType(Cell.CELL_TYPE_STRING);
				                			 cellValue=formatter.formatCellValue(currentCell).trim();
				                			// cellValue = currentCell.getStringCellValue().trim();	
				                			 if(rowSize == 0 && !cellValue.equalsIgnoreCase(currentImgId)){
				                				 validateMsg.add(currentImgId +" IMGID in the first row of the file and selected Scope name Should be same");
				                				 configTempDto.setStatusMsg(currentImgId +" IMGID in the first row of the file and selected Scope name Should be same");
				                				 templateStatus = false;
				                				 break;
				                			 }else if(rowSize == 2 && !cellValue.equalsIgnoreCase(viewName)){
				                					 validateMsg.add(viewName +" View in the third row of the file and Sheet name Should be same");
						     						 configTempDto.setStatusMsg(viewName +" View in the third row of the file and Sheet name Should be same");
						     						 templateStatus = false;
						     						 break;
				                			 }else if(rowSize == 3 && cellValue.trim().length() <= 0){
				                					 validateMsg.add("Field Name(Row number 4 from uploaded template) for "+viewName+" view is missing.");
						     						 configTempDto.setStatusMsg("Field Name(Row number 4 from uploaded template) for "+viewName+" view is missing.");
						     						 templateStatus = false;
						     						 break;
				                			 }
				                			
				                		 }
				            }
				         
						}
							/*if(roleType=="Config"){
							viewRow = sheet.getRow(5);
							
							 for(int i=1;i<=columnsize;i++){
								 currentCell=viewRow.getCell(i);
								if(currentCell==null){
									 templateStatus = false; 
								}else if(currentCell.getStringCellValue().trim().length()>0){
									 templateStatus = true;
									  break; 
								}
								 
								 
							 }
							 if( templateStatus ==false){
								  validateMsg.add("Template uploaded without the configurable data"+viewName);
	                				 configTempDto.setStatusMsg("Template uploaded without the configurable data"+viewName); 
	                				 break; 
								  }
							
							}*/
						
						}else{
							templateStatus = false;
							validateMsg.add("Not all view required for the configuration have been included in the template. Please update the template and try again");
							configTempDto.setStatusMsg("Not all view required for the configuration have been included in the template. Please update the template and try again");
						}
					}
					if(numberofSheet != templateSheetSize){
						templateStatus = false;
						validateMsg.add("Not all view required for the configuration have been included in the template. Please update the template and try again");
						configTempDto.setStatusMsg("Not all view required for the configuration have been included in the template. Please update the template and try again");
					}
					
					int moreMsg = 0;
					StringBuilder tempMsg = new StringBuilder();
					for(String orginialView: sheetNameList){
						
						if(!excelViewList.contains(orginialView)){
							if(moreMsg == 0){
							tempMsg.append(orginialView);
							moreMsg++;
							}
							else{
								moreMsg++;
								tempMsg.append(", "+orginialView);
							}
									
						}
					}
					if(moreMsg >= 2){
						tempMsg.append(" Views are Missing from uploaded Template.");
						validateMsg.add(tempMsg.toString());
					}
					else if(moreMsg == 1){
						tempMsg.append(" View is Missing from uploaded Template.");
						validateMsg.add(tempMsg.toString());
					}
				
	            configTempDto.setStatus(templateStatus);
	            if(templateStatus){
	            	validateMsg.add("Config Template Uploaded Successfully..");
	            	configTempDto.setStatusMsg(selectedScopeDto.getFileName() +" validated successfully..");
	            	selectedScopeDto.setFileUploadStatusMsg(validateMsg);
	            }
				}else{
					
					//slf4jLogger.info(" else block");
					//validateMsg.add("Template was uploaded with incorrect filename");
	            	//configTempDto.setStatusMsg(selectedScopeDto.getFileName() +" validation is not successful");
	            	selectedScopeDto.setFileUploadStatusMsg(validateMsg);
				}
			
			} catch (Exception e) {
				configTempDto.setStatus(false);
				validateMsg.add("Not all view required for the configuration have been included in the template. Please update the template and try again");
				configTempDto.setStatusMsg("Not all view required for the configuration have been included in the template. Please update the template and try again");
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
			finally{
				file = null;
				try {
					if(workbook != null)
					workbook.close();
					if(byteIn != null)
						byteIn.close();
					byteIn = null;
				} catch (IOException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
				  slf4jLogger.info("configFileValidation method ended");

			}
			return configTempDto;
				
		}	
		
		public ConfigTemplateDto configFileValidationConsolidation(SelectedScopeDto selectedScopeDto,ArrayList<String> sheetNameList,String roleType ) {
			slf4jLogger.info("configFileValidationConsolidation method started");
			ConfigTemplateDto configTempDto = new ConfigTemplateDto();
			boolean templateStatus = true;
			InputStream file = null;
			Workbook workbook = null;
			int numberofSheet = 0;
			String templateSheet = sheetNameList.get(0);
			int viewSize=templateSheet.length();
			short columnsize = 0;
			short rowSize = 0;
			Sheet sheet = null;
			Row viewRow =  null;
			Cell currentCell  = null;
			String viewName = "";
			String sheetName = "";
			String cellValue = "";
			int cellCount = 0;
			ArrayList<String> excelViewList = new ArrayList<>(); 
			ArrayList<String> validateMsg = new ArrayList<>();
			String currentImgId = selectedScopeDto.getImgId();
			ByteArrayInputStream byteIn = null;
			boolean guidelines = true;
			
			//slf4jLogger.info("before try block");
			try {
				
				
				configTempDto.setSelectedScopeDto(selectedScopeDto);
				//slf4jLogger.info("file bytes"+selectedScopeDto.getFileBytes());
				//if(selectedScopeDto.getFilepath() != null && selectedScopeDto.getFilepath().length() > 0)
				if(selectedScopeDto.getFileBytes() != null && selectedScopeDto.getFileBytes().length > 0){
					
					byteIn = new ByteArrayInputStream(selectedScopeDto.getFileBytes());
				//file = new FileInputStream(new File(selectedScopeDto.getFilepath()));
				//if(file != null){
				workbook = WorkbookFactory.create(byteIn);
				
				//workbook = new Workbook(byteIn);
					if (workbook != null) {
						numberofSheet = workbook.getNumberOfSheets();
					}
				//}
				selectedScopeDto.setFileUploadStatusMsg(validateMsg);
		
					for(int num = 0; num<numberofSheet; num++){
						
						if(num==0) {
							if(workbook.getSheetName(num).equalsIgnoreCase("Guideline")) {
								continue;
							}else {
								validateMsg.add("Guideline sheet should be the first sheet");
								configTempDto.setStatusMsg("Guideline sheet should be the first sheet");
								guidelines=false;
								templateStatus=false;
								break;
							}
						}
						sheetName = workbook.getSheetName(1).trim();
						viewName=sheetName.substring(8);
						excelViewList.add(viewName);
						
						
							sheet = workbook.getSheetAt(2);
							
							Iterator<Row> rowIterator = sheet.iterator();
							viewRow = sheet.getRow(2);
							columnsize = viewRow.getLastCellNum();
							columnsize -=1;
							
							for (rowSize = 0;(rowSize <= 3 && rowIterator.hasNext()); rowSize++) {
								 viewRow = rowIterator.next();
							currentCell = viewRow.getCell(0);
							if (currentCell == null) {
								
								if (rowSize == 0 && cellCount == 0) {
									templateStatus = false;
									validateMsg.add("Indicator is missing");
									configTempDto.setStatusMsg("Indicator is missing");
								}
							} else {
								currentCell.setCellType(Cell.CELL_TYPE_STRING);
								cellValue = currentCell.getStringCellValue().trim();
								if (rowSize == 0 && cellCount == 0 && !cellValue.equalsIgnoreCase("Indicator")) {
									validateMsg.add("1st column header should be Indicator");
									configTempDto.setStatusMsg("1st column header should be Indicator");
									templateStatus = false;
									break;
								}
							}
																
					            for(cellCount = 2;cellCount <= columnsize; cellCount++) {
					            	currentCell = viewRow.getCell(cellCount);
					            	
				                		 if(currentCell == null){
				                			 templateStatus = false;
				                			 if(rowSize == 0){
				                				 validateMsg.add(viewName +" Table/View in the 1st row of the file and Sheet name Should be same");
				                				 configTempDto.setStatusMsg(viewName +" Table/View in the 1st row of the file and Sheet name Should be same");
				                			 }else if(rowSize == 1){
				                				 validateMsg.add("Field Name(Row number 2 from uploaded template) for "+viewName+" view is missing.");
				                				 configTempDto.setStatusMsg("Field Name(Row number 2 from uploaded template) for "+viewName+" view is missing.");
				                			 }else {
				                				validateMsg.add("Template format appears to be incorrect. Please check template and try again");
				             					configTempDto.setStatusMsg("Template format appears to be incorrect. Please check template and try again"); 
				                			 }
				                			 break;
				                		 }else {
				                			 currentCell.setCellType(Cell.CELL_TYPE_STRING);
				                			 cellValue = currentCell.getStringCellValue().trim();
				                			 
				                			
				                			 if(rowSize == 0){
				                				 int underscoreIndex = cellValue.indexOf("_");
				                				 String cellViewValue = cellValue.substring(underscoreIndex+1);
				                				 
				                				 if(!cellViewValue.equalsIgnoreCase(viewName)) {
				                					 validateMsg.add(viewName +" Table/View in the 1st row of the file and Sheet name Should be same");
						     						 configTempDto.setStatusMsg(viewName +" Table/View in the 1st row of the file and Sheet name Should be same");
						     						 templateStatus = false;
						     						 break;
				                				 }
				                			 }else if(rowSize == 1 && cellValue.trim().length() <= 0){
				                					 validateMsg.add("Field Name(Row number 2 from uploaded template) for "+viewName+" view is missing.");
						     						 configTempDto.setStatusMsg("Field Name(Row number 2 from uploaded template) for "+viewName+" view is missing.");
						     						 templateStatus = false;
						     						 break;
				                			 }
				                			
				                		 }
				            }
				         
						}
						break;	
						
						
					}
					
					int moreMsg = 0;
					StringBuilder tempMsg = new StringBuilder();
					for(String orginialView: sheetNameList){
						
						if(!excelViewList.contains(orginialView)){
							if(moreMsg == 0){
							tempMsg.append(orginialView);
							moreMsg++;
							}
							else{
								moreMsg++;
								tempMsg.append(", "+orginialView);
							}
									
						}
					}
					if(moreMsg == 1 && guidelines){
						tempMsg.append(" Table/View is Missing from uploaded Template.");
						validateMsg.add(tempMsg.toString());
					}
				
	            configTempDto.setStatus(templateStatus);
	            if(templateStatus && validateMsg.size()==0 ){
	            	validateMsg.add("Config Template Uploaded Successfully..");
	            	configTempDto.setStatusMsg(selectedScopeDto.getFileName() +" validated successfully..");
	            	selectedScopeDto.setFileUploadStatusMsg(validateMsg);
	            }
				}else{
					
					
					//slf4jLogger.info(" else block");
					//validateMsg.add("Template was uploaded with incorrect filename");
	            	//configTempDto.setStatusMsg(selectedScopeDto.getFileName() +" validation is not successful");
					templateStatus = false;
					validateMsg.add("Required Comparison Sheet is missing. Please update the template and try again");
					configTempDto.setStatusMsg("Required Comparison Sheet is missing. Please update the template and try again");
									
					selectedScopeDto.setFileUploadStatusMsg(validateMsg);
				}
			
			} catch (Exception e) {
				configTempDto.setStatus(false);
				validateMsg.add("Not all view required for the configuration have been included in the template. Please update the template and try again");
				configTempDto.setStatusMsg("Not all view required for the configuration have been included in the template. Please update the template and try again");
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
			finally{
				file = null;
				try {
					if(workbook != null)
					workbook.close();
					if(byteIn != null)
						byteIn.close();
					byteIn = null;
				} catch (IOException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
				  slf4jLogger.info("configFileValidationConsolidation method ended");

			}
			return configTempDto;
				
		}
				
		public ConfigTemplateDto configFileValidation_Dev(SelectedScopeDto selectedScopeDto,ArrayList<String> sheetNameList ) {
			slf4jLogger.info("configFileValidation_Dev method started");
			ConfigTemplateDto configTempDto = new ConfigTemplateDto();
			boolean templateStatus = true;
			FileInputStream file = null;
			Workbook workbook = null;
			int numberofSheet = 0;
			short columnsize = 0;
			short rowSize = 0;
			Sheet sheet = null;
			Row viewRow =  null;
			Cell currentCell  = null;
			String viewName = "";
			String cellValue = "";
			int cellCount = 0;
			ArrayList<String> excelViewList = new ArrayList<>(); 
			ArrayList<String> validateMsg = new ArrayList<>(); 
			ByteArrayInputStream byteIn = null;
			try {
				byteIn = new ByteArrayInputStream(selectedScopeDto.getFileBytes());
				configTempDto.setSelectedScopeDto(selectedScopeDto);
				if(selectedScopeDto.getFileBytes() != null && selectedScopeDto.getFileBytes().length > 0)
					//file = new FileInputStream(new File(selectedScopeDto.getFilepath()));
					//if(file != null){
					workbook = WorkbookFactory.create(byteIn);
				
				if(workbook != null)
					numberofSheet = workbook.getNumberOfSheets();	
				
				
				selectedScopeDto.setFileUploadStatusMsg(validateMsg);
		
					for(int num = 0; num<numberofSheet; num++){
						
						viewName = workbook.getSheetName(num).replaceAll("~", "/").trim();
						excelViewList.add(viewName);
						if(viewName.equalsIgnoreCase(ConstantsValues.INSTRUCTIONSHEET)){
							continue;
						}else if(sheetNameList.contains(viewName)){
							sheet = workbook.getSheetAt(num);
							Iterator<Row> rowIterator = sheet.iterator();
							viewRow = sheet.getRow(2);
							columnsize = viewRow.getLastCellNum();
							columnsize -=1;//Skip first column
							
							for (rowSize = 0;rowIterator.hasNext(); rowSize++) {
								 viewRow = rowIterator.next();
								 if(rowSize == 4)
						            	break;
								 
								 if(!(rowSize == 2 || rowSize == 3))//Validate View & Fields only
									continue;
								
					            for(cellCount = 1;cellCount <= columnsize; cellCount++) {
					            	currentCell = viewRow.getCell(cellCount);
				                		 if(currentCell == null){
				                			 templateStatus = false;
				                			 if(rowSize == 2){
				                				 validateMsg.add(viewName +" View in the third row of the file and Sheet name Should be same");
				                				 configTempDto.setStatusMsg(viewName +" View in the third row of the file and Sheet name Should be same");
				                			 }else if(rowSize == 3){
				                				 validateMsg.add("Field Name(Row number 4 from uploaded template) for "+viewName+" view is missing.");
				                				 configTempDto.setStatusMsg("Field Name(Row number 4 from uploaded template) for "+viewName+" view is missing.");
				                			 }
				                			 break;
				                		 }else {
				                			 currentCell.setCellType(Cell.CELL_TYPE_STRING);
				                			 cellValue = currentCell.getStringCellValue().trim();
				                			
				                			 if(rowSize == 2){
				                				 if(!cellValue.equalsIgnoreCase(viewName)){
				                					 validateMsg.add(viewName +" View in the third row of the file and Sheet name Should be same");
						     						 configTempDto.setStatusMsg(viewName +" View in the third row of the file and Sheet name Should be same");
						     						 templateStatus = false;
						     						 break;
				                				 }
				                					 
				                			 }else if(rowSize == 3){
				                				 if(cellValue.trim().length() <= 0){
				                					 validateMsg.add("Field Name(Row number 4 from uploaded template) for "+viewName+" view is missing.");
						     						 configTempDto.setStatusMsg("Field Name(Row number 4 from uploaded template) for "+viewName+" view is missing.");
						     						 templateStatus = false;
						     						 break;
				                				 
				                			 }
				                		 }
				            }
				         
						}
							
						}
						}else{
							templateStatus = false;
							validateMsg.add("Not all view required for the configuration have been included in the template. Please update the template and try again");
							configTempDto.setStatusMsg("Not all view required for the configuration have been included in the template. Please update the template and try again");
						}
					}
				
	            configTempDto.setStatus(templateStatus);
	            if(templateStatus){
	            	validateMsg.add("Config Template Uploaded Successfully..");
	            	configTempDto.setStatusMsg(selectedScopeDto.getFileName() +" validated successfully..");
	            }
	            
			} catch (Exception e) {
				configTempDto.setStatus(false);
				validateMsg.add(" Exception Not all view required for the configuration have been included in the template. Please update the template and try again");
				configTempDto.setStatusMsg("Exception Not all view required for the configuration have been included in the template. Please update the template and try again");
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
			finally{
				file = null;
				try {
					if(workbook != null)
					workbook.close();
				} catch (IOException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
				  slf4jLogger.info("configFileValidation_Dev method ended");

			}
			return configTempDto;
				
		}	

}