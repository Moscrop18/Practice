package com.acn.rpa.config;

import java.util.List;


import com.acn.user.session.ResMessageDto;

public class DownloadReportDtoList {
	private List<DownloadReportDto> downloadReportList;
	private ResMessageDto resMessageDto;
	public List<DownloadReportDto> getDownloadReportList() {
		return downloadReportList;
	}
	public void setDownloadReportList(List<DownloadReportDto> downloadReportList) {
		this.downloadReportList = downloadReportList;
	}
	public ResMessageDto getResMessageDto() {
		return resMessageDto;
	}
	public void setResMessageDto(ResMessageDto resMessageDto) {
		this.resMessageDto = resMessageDto;
	}
	
}
