package com.acn.rpa.config;

import java.sql.Timestamp;

public class DownloadReportDto {
	
	
	private String transid;
	private Timestamp createddate;
	private String SCENARIO;
	private String destinationname;
	private String userid;
	private String sapuserid;
	private String count;
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	public String getSapuserid() {
		return sapuserid;
	}
	public void setSapuserid(String sapuserid) {
		this.sapuserid = sapuserid;
	}
	public String getTransid() {
		return transid;
	}
	public void setTransid(String transid) {
		this.transid = transid;
	}
	
	public Timestamp getCreateddate() {
		return createddate;
	}
	public void setCreateddate(Timestamp createddate) {
		this.createddate = createddate;
	}
	public String getSCENARIO() {
		return SCENARIO;
	}
	public void setSCENARIO(String sCENARIO) {
		SCENARIO = sCENARIO;
	}
	public String getDestinationname() {
		return destinationname;
	}
	public void setDestinationname(String destinationname) {
		this.destinationname = destinationname;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	
}
