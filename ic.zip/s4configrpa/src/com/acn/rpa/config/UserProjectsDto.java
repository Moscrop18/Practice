/**
 * @author insimmamul.haq.p.b
 */
package com.acn.rpa.config;


public class UserProjectsDto {

	private int id;
	private String userId;
	private String omId;
	private String status;
	private String projectName;
	private String trOverRide;
	private String cust_DestReq;
	
	public String getTrOverRide() {
		return trOverRide;
	}

	public void setTrOverRide(String trOverRide) {
		this.trOverRide = trOverRide;
	}

	public UserProjectsDto() {
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getOmId() {
		return omId;
	}
	public void setOmId(String omId) {
		this.omId = omId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getCust_DestReq() {
		return cust_DestReq;
	}

	public void setCust_DestReq(String cust_DestReq) {
		this.cust_DestReq = cust_DestReq;
	}
	
	
	
}
