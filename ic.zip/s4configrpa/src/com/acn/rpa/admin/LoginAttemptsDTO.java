package com.acn.rpa.admin;
/**
 * @author Rajesh Valupadasu
 *
 */
public class LoginAttemptsDTO {

	private String numberOfAttempts;
	
	private String userId;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getNumberOfAttempts() {
		return numberOfAttempts;
	}

	public void setNumberOfAttempts(String numberOfAttempts) {
		this.numberOfAttempts = numberOfAttempts;
	}

}