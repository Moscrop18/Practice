package com.acn.rpa.admin;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.service.AesUtil;
import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.DBConnection;
import com.acn.rpa.utilities.PropMappings;
import com.acn.user.session.CustomResDto;
import com.acn.user.session.CustomerInputDto;
import com.acn.user.session.ResMessageDto;
import com.acn.user.session.SysInputDto;
import com.acn.user.session.SystemResDto;

public class SystemDAO {

	private final Logger slf4jLogger = LoggerFactory.getLogger(SystemDAO.class);

	public SystemResDto getAllConfigs(CustomerInputDto dto) {
		slf4jLogger.info("getAllConfigs method started");
		SystemResDto resDto = new SystemResDto();
		ResMessageDto resMessageDto = new ResMessageDto();
		resDto.setResMessageDto(resMessageDto);
		List<SystemDTO> systemDtoList = new ArrayList<>();
		ResultSet rs = null;
		PreparedStatement pStmt = null;
		SystemDTO eccConfigDto;
		Connection con = null;
		try {
			con = DBConnection.createConnection();
			if (dto.getUserRole().equals(ConstantsValues.PROJECTADMIN)) {
				pStmt = con.prepareStatement(
						"select A.*,B.PROJECTNAME from SAPSYSTEM A,CUSTOMER B,USERPROJECTS C WHERE A.OMID=B.OMID AND C.OMID=B.OMID AND C.USERID=? ORDER BY A.ID");
				pStmt.setString(1, dto.getUserID());
			} else {
				pStmt = con.prepareStatement(
						"select A.*,B.PROJECTNAME from SAPSYSTEM A,CUSTOMER B WHERE A.OMID=B.OMID ORDER BY A.ID");

			}
			rs = pStmt.executeQuery();
			while (rs.next()) {
				eccConfigDto = new SystemDTO();
				eccConfigDto.setOmId(rs.getString("OMID"));
				eccConfigDto.setSystemId(rs.getString("SYSTEMID"));
				eccConfigDto.setSapClientNo(rs.getString("SAPCLIENTNO"));
				eccConfigDto.setDescription(rs.getString("DESCRIPTION"));
				eccConfigDto.setSystemType(rs.getString("SYSTEMTYPE"));
				eccConfigDto.setIsSourceSystem(rs.getInt("ISSOURCESYSTEM"));
				eccConfigDto.setIsTargetSystem(rs.getInt("ISTARGETSYSTEM"));
				eccConfigDto.setId(rs.getInt("ID"));
				eccConfigDto.setStatus(rs.getString("Status"));
				eccConfigDto.setDestinationName(rs.getString("DESTINATIONNAME"));
				eccConfigDto.setProjectName(rs.getString("PROJECTNAME"));
				eccConfigDto.setIsHVESSystem(rs.getInt("ISHVESSYSTEM"));
				eccConfigDto.setSystemNo(rs.getString("SYSTEMNO"));

				systemDtoList.add(eccConfigDto);
			}
			if (systemDtoList.isEmpty()) {
				resDto.getResMessageDto().setMessage(ConstantsValues.NORECORDSEXISTS);
				slf4jLogger.error(ConstantsValues.NORECORDSEXISTS);
			} else {
				resDto.setSystemList(systemDtoList);
			}
		} catch (SQLException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
		} finally {
			if (rs != null) {
				try {
					rs.close();
					rs = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}

			if (pStmt != null) {
				try {
					pStmt.close();
					pStmt = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}

			if (con != null) {
				try {
					con.close();
					con = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}

			slf4jLogger.info("getAllConfigs method ended");

		}

		return resDto;
	}

	public ResponseDto getConfig(String systemNo) {
		slf4jLogger.info("getConfig method started");
		ResultSet rs = null;
		PreparedStatement pStmt = null;
		SystemDTO eccConfigDto = null;
		ResponseDto responseDtoObj = new ResponseDto();
		Connection con = null;

		if (!ifExists(systemNo)) {
			responseDtoObj.setMessage("The System ID you have entered does not exists!");
			return responseDtoObj;
		}
		ArrayList<SystemDTO> systems = new ArrayList<>();

		try {
			con = DBConnection.createConnection();
			eccConfigDto = new SystemDTO();
			pStmt = con.prepareStatement("select * from SAPSYSTEM where SYSTEMNO = ?");
			pStmt.setString(1, systemNo);
			rs = pStmt.executeQuery();
			if (rs.next()) {
				eccConfigDto = new SystemDTO();
				eccConfigDto.setOmId(rs.getString("OMID"));
				eccConfigDto.setSystemId(rs.getString("SYSTEMID"));
				eccConfigDto.setSapClientNo(rs.getString("SAPCLIENTNO"));
				eccConfigDto.setDescription(rs.getString("DESCRIPTION"));
				eccConfigDto.setSystemType(rs.getString("SYSTEMTYPE"));
				eccConfigDto.setIsSourceSystem(rs.getInt("ISSOURCESYSTEM"));
				eccConfigDto.setIsTargetSystem(rs.getInt("ISTARGETSYSTEM"));
				eccConfigDto.setId(rs.getInt("ID"));
				eccConfigDto.setStatus(rs.getString("STATUS"));
				eccConfigDto.setDestinationName(rs.getString("DESTINATIONNAME"));
				systems.add(eccConfigDto);
			}
			responseDtoObj.setResSapSystemList(systems);
		} catch (SQLException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
		} finally {
			if (rs != null) {
				try {
					rs.close();
					rs = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}

			if (pStmt != null) {
				try {
					pStmt.close();
					pStmt = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}

			if (con != null) {
				try {
					con.close();
					con = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}
			slf4jLogger.info("getConfig method ended");

		}

		return responseDtoObj;
	}

	public ResMessageDto addConfig(SystemDTO config) {
		slf4jLogger.info("addConfig method started");
		ResMessageDto resMessageDto = new ResMessageDto();
		Connection con = null;
		if (ifExists(config)) {
			resMessageDto.setMessage(config.getDestinationName() + "  already exists for the OmId " + config.getOmId());
			return resMessageDto;
		}
		PreparedStatement pStmt = null;
		ResultSet rs = null;
		PreparedStatement ps = null;
		PropMappings propObj = PropMappings.getInstance();

		try {
			con = DBConnection.createConnection();
			pStmt = con.prepareStatement("select omid from customer where omID= ?");
			pStmt.setString(1, config.getOmId());
			rs = pStmt.executeQuery();
			if (!rs.next()) {
				resMessageDto.setMessage(ConstantsValues.OMIDIDEXISTS);
				slf4jLogger.error(ConstantsValues.OMIDIDEXISTS);
				return resMessageDto;
			}

			int count = 0;
			String addUserQuery = "INSERT INTO SAPSYSTEM(OMID,SYSTEMID,SAPCLIENTNO,DESCRIPTION,SYSTEMTYPE,"
					+ "ISSOURCESYSTEM,ISTARGETSYSTEM,STATUS,DESTINATIONNAME,ISHVESSYSTEM,USERID,PASSWORD,LANGUAGE,HOSTNAME,SYSTEMNO"
					+ ",SNC_ENABLED, SNC_NAME, SNCPARTNER_NAME, SAP_ROUTER,PROTECTION_LEVEL) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

			ps = con.prepareStatement(addUserQuery);

			ps.setString(1, config.getOmId());
			ps.setString(2, config.getSystemId());
			ps.setString(3, config.getSapClientNo());
			ps.setString(4, config.getDescription());
			ps.setString(5, config.getSystemType());

			if (config.getSystemType() != null && config.getSystem().equals(ConstantsValues.SOURCESYSTEM)) {
				ps.setInt(6, 1);
				ps.setInt(7, 0);
			} else if (config.getSystemType() != null && config.getSystem().equals(ConstantsValues.TARGETSYSTEM)) {
				ps.setInt(6, 0);
				ps.setInt(7, 1);
			} else {
				ps.setInt(6, 0);
				ps.setInt(7, 0);
			}
			ps.setString(8, ConstantsValues.ACTIVESTATUS);
			ps.setString(9, config.getDestinationName());
			ps.setInt(10, config.getIsHVESSystem());
			ps.setString(11, config.getUserId());
			ps.setString(12, config.getPassword());
			ps.setString(13, config.getLanguage());
			ps.setString(14, config.getHostName());
			ps.setString(15, config.getSystemNo());
			ps.setInt(16, config.getSncEnabled());
			ps.setString(17, config.getSncName());
			ps.setString(18, config.getSncPartnerName());
			ps.setString(19, config.getSapRouter());
			ps.setString(20, config.getSncProtectionLevel());

			count = ps.executeUpdate();
			if (count > 0) {
				resMessageDto.setMessage(ConstantsValues.SYSTEMCREATED);
			} else {
				resMessageDto.setMessage(ConstantsValues.SYSTEMNOTCREATED);
			}

		} catch (SQLException e) {
			resMessageDto.setMsgType(ConstantsValues.DBERROR);
			resMessageDto.setMessage(ConstantsValues.SYSTEMNOTCREATED);
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
		} finally {
			if (rs != null) {
				try {
					rs.close();
					rs = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}

			if (pStmt != null) {
				try {
					pStmt.close();
					pStmt = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}
			if (ps != null) {
				try {
					ps.close();
					ps = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}

			if (con != null) {
				try {
					con.close();
					con = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}
			slf4jLogger.info("addConfig method ended");

		}

		return resMessageDto;

	}

	public ResMessageDto cloneSystem(SystemDTO config) {
		slf4jLogger.info("cloneSystem method started");
		ResMessageDto resMessageDto = new ResMessageDto();
		Connection con = null;
		if (ifExists(config)) {
			resMessageDto.setMessage(config.getDestinationName() + "  already exists for the OmId " + config.getOmId());
			return resMessageDto;
		}
		PreparedStatement pStmt = null;
		ResultSet rs = null;
		PreparedStatement ps = null;

		try {
			con = DBConnection.createConnection();
			pStmt = con.prepareStatement("select omid from customer where omID= ?");
			pStmt.setString(1, config.getOmId());
			rs = pStmt.executeQuery();
			if (!rs.next()) {
				resMessageDto.setMessage("The omID you have entered does not exist!");
				slf4jLogger.error("The omID you have entered does not exist!");
				return resMessageDto;
			}

			int count = 0;
			String addUserQuery = "INSERT INTO SAPSYSTEM(OMID,SYSTEMID,SAPCLIENTNO,DESCRIPTION,SYSTEMTYPE,"
					+ "ISSOURCESYSTEM,ISTARGETSYSTEM,STATUS,DESTINATIONNAME,ISHVESSYSTEM,SYSTEMNO) VALUES (?,?,?,?,?,?,?,?,?,?,?)";

			ps = con.prepareStatement(addUserQuery);
			ps.setString(1, config.getOmId());
			ps.setString(2, config.getSystemId());
			ps.setString(3, config.getSapClientNo());
			ps.setString(4, config.getDescription());
			ps.setString(5, config.getSystemType());
			if (config.getSystemType() != null && config.getSystem().equals(ConstantsValues.SOURCESYSTEM)) {
				ps.setInt(6, 1);
				ps.setInt(7, 0);
			} else if (config.getSystemType() != null && config.getSystem().equals(ConstantsValues.TARGETSYSTEM)) {
				ps.setInt(6, 0);
				ps.setInt(7, 1);
			} else {
				ps.setInt(6, 0);
				ps.setInt(7, 0);
			}
			ps.setString(8, config.getStatus());
			ps.setString(9, config.getDestinationName());
			ps.setInt(10, config.getIsHVESSystem());
			ps.setString(11, config.getSystemNo());

			count = ps.executeUpdate();
			if (count > 0) {
				resMessageDto.setMessage(ConstantsValues.SYSTEMCLONED);
			} else {
				resMessageDto.setMessage(ConstantsValues.SYSTEMNOTCLONED);
			}

		} catch (SQLException e) {
			resMessageDto.setMsgType(ConstantsValues.DBERROR);
			resMessageDto.setMessage(ConstantsValues.DATABASEERROR);
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
		} finally {
			if (rs != null) {
				try {
					rs.close();
					rs = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}

			if (pStmt != null) {
				try {
					pStmt.close();
					pStmt = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}
			if (ps != null) {
				try {
					ps.close();
					ps = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}

			if (con != null) {
				try {
					con.close();
					con = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}
			slf4jLogger.info("cloneSystem method ended");

		}

		return resMessageDto;

	}

	public ResMessageDto updateConfig(SystemDTO config) {
		slf4jLogger.info("updateConfig method started");
		ResMessageDto resMessageDto = new ResMessageDto();

		if (ifExists(config)) {
			resMessageDto.setMessage(config.getDestinationName() + "  already exists for the OmId " + config.getOmId());
			return resMessageDto;
		}

		PreparedStatement ps = null;
		String updateUserQuery = "UPDATE SAPSYSTEM SET DESCRIPTION =?,SYSTEMTYPE =?,"
				+ "ISSOURCESYSTEM =?,ISTARGETSYSTEM =?,STATUS=?,DESTINATIONNAME=?,ISHVESSYSTEM=?,SAPCLIENTNO=?,SYSTEMID=? where ID= ?";
		PreparedStatement pStmt = null;
		ResultSet rs = null;
		Connection con = null;
		int count = 0;
		try {
			con = DBConnection.createConnection();
			pStmt = con.prepareStatement("select omid from customer where omID= ?");
			pStmt.setString(1, config.getOmId());
			rs = pStmt.executeQuery();
			if (!rs.next()) {
				resMessageDto.setMessage(ConstantsValues.OMIDNOTEXISTS);
				slf4jLogger.error(ConstantsValues.OMIDNOTEXISTS);
				return resMessageDto;
			}

			ps = con.prepareStatement(updateUserQuery);
			ps.setString(1, config.getDescription());
			ps.setString(2, config.getSystemType());
			if (config.getSystem() != null && config.getSystem().equals(ConstantsValues.SOURCESYSTEM)) {
				ps.setInt(3, 1);
				ps.setInt(4, 0);
			} else if (config.getSystem() != null && config.getSystem().equals(ConstantsValues.TARGETSYSTEM)) {
				ps.setInt(3, 0);
				ps.setInt(4, 1);
			} else {
				ps.setInt(3, 0);
				ps.setInt(4, 0);
			}
			ps.setString(5, config.getStatus());
			ps.setString(6, config.getDestinationName());
			ps.setInt(7, config.getIsHVESSystem());
			ps.setString(8, config.getSapClientNo());
			ps.setString(9, config.getSystemId());
			ps.setInt(10, config.getId());

			count = ps.executeUpdate();
			if (count > 0)
				resMessageDto.setMessage(ConstantsValues.SYSTEMDETAILSUPDATED);
			else
				resMessageDto.setMessage(ConstantsValues.SYSTEMDETAILSNOTUPDATED);
		} catch (SQLException e) {
			resMessageDto.setMsgType(ConstantsValues.DBERROR);
			resMessageDto.setMessage(ConstantsValues.DATABASEERROR);
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}

			if (pStmt != null) {
				try {
					pStmt.close();
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}

			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}
			slf4jLogger.info("updateConfig method ended");

		}
		return resMessageDto;
	}

	public ResMessageDto removeConfig(List<String> systemIds) {
		slf4jLogger.info("removeConfig method started");
		ResMessageDto resDto = new ResMessageDto();
		PreparedStatement pStmt = null;
		Connection con = null;
		int count = 0;
		int length = systemIds.size();
		if (length == 0) {
			resDto.setMessage(ConstantsValues.SYSTEMDETAILSREQUIRED);
			return resDto;
		}
		StringBuilder query = new StringBuilder("UPDATE SAPSYSTEM SET Status =? where ID in (");

		for (int i = 0; i < length; i++) {
			if (i == length - 1)
				query.append("?)");
			else
				query.append("?,");

		}
		try {
			con = DBConnection.createConnection();
			pStmt = con.prepareStatement(query.toString());
			pStmt.setString(1, ConstantsValues.INACTIVESTATUS);
			int pos = 2;
			for (int i = 0; i < length; i++, pos++) {
				pStmt.setString(pos, systemIds.get(i));
			}
			count = pStmt.executeUpdate();
			if (count > 0) {
				resDto.setMessage(ConstantsValues.SAPSYSTEMSMADEINACTIVE);
			} else {
				resDto.setMessage(ConstantsValues.SAPSYSTEMSNOTMADEINACTIVE);
				slf4jLogger.error(ConstantsValues.SAPSYSTEMSNOTMADEINACTIVE);
			}
		} catch (SQLException e) {
			resDto.setMessage(ConstantsValues.DATABASEERROR);
		} finally {
			if (pStmt != null) {
				try {
					pStmt.close();
					pStmt = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}

			if (con != null) {
				try {
					con.close();
					con = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}

			}
		}
		return resDto;
	}

	public boolean ifExists(String systemNo) {
		slf4jLogger.info("ifExists method started");
		ResultSet rs = null;
		PreparedStatement pStmt = null;
		Connection con = null;
		try {
			con = DBConnection.createConnection();
			pStmt = con.prepareStatement("select SystemNo from SAPSYSTEM where SYSTEMNO= ?");
			pStmt.setString(1, systemNo);
			rs = pStmt.executeQuery();
			if (rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
		} finally {

			if (rs != null) {
				try {
					rs.close();
					rs = null;

				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}

			if (pStmt != null) {
				try {
					pStmt.close();
					pStmt = null;

				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}

			if (con != null) {
				try {
					con.close();
					con = null;

				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}
			slf4jLogger.info("ifExists method ended");

		}
		return false;
	}

	public boolean ifExists(SystemDTO config) {
		slf4jLogger.info("ifExists method started");
		ResultSet rs = null;
		PreparedStatement pStmt = null;
		Connection con = null;
		StringBuilder conChkQuery = null;
		try {
			conChkQuery = new StringBuilder("select COUNT(1) CNT from SAPSYSTEM where  OMID=?  AND DESTINATIONNAME=? ");
			if (config.getSystemType() != null && config.getSystem().equals(ConstantsValues.SOURCESYSTEM)) {
				conChkQuery.append(" AND ISSOURCESYSTEM=? AND ISTARGETSYSTEM=?");
			} else if (config.getSystemType() != null && config.getSystem().equals(ConstantsValues.TARGETSYSTEM)) {
				conChkQuery.append(" AND ISSOURCESYSTEM=? AND ISTARGETSYSTEM=?");
			}
			if (config.getId() != 0) {
				conChkQuery.append(" AND ID != ?");
			}
			con = DBConnection.createConnection();
			pStmt = con.prepareStatement(conChkQuery.toString());
			pStmt.setString(1, config.getOmId());
			pStmt.setString(2, config.getDestinationName());
			if (config.getSystemType() != null && config.getSystem().equals(ConstantsValues.SOURCESYSTEM)) {
				pStmt.setInt(3, 1);
				pStmt.setInt(4, 0);
			} else if (config.getSystemType() != null && config.getSystem().equals(ConstantsValues.TARGETSYSTEM)) {
				pStmt.setInt(3, 0);
				pStmt.setInt(4, 1);
			}

			if (config.getId() != 0) {
				pStmt.setInt(5, config.getId());
			}

			rs = pStmt.executeQuery();
			if (rs.next() && (rs.getInt("CNT") > 0)) {
				return true;
			}
		} catch (SQLException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
		} finally {
			if (rs != null) {
				try {
					rs.close();
					rs = null;

				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}
			if (pStmt != null) {
				try {
					pStmt.close();
					pStmt = null;

				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}

			if (con != null) {
				try {
					con.close();
					con = null;

				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}
			slf4jLogger.info("ifExists method ended");

		}
		return false;
	}

	public SystemResDto getSourceTargetDetails(SysInputDto sysInputDto) {
		slf4jLogger.info("getSourceTargetDetails service started");
		List<SystemDTO> systems = new ArrayList<>();
		ResultSet rs = null;
		PreparedStatement pStmt = null;
		SystemDTO eccConfigDto;
		SystemResDto systemResDto = null;
		StringBuilder fetchQuery = null;
		Connection con = null;
		boolean flag = false;
		try {
			systemResDto = new SystemResDto();
			ResMessageDto resMessageDto = new ResMessageDto();
			systemResDto.setResMessageDto(resMessageDto);
			fetchQuery = new StringBuilder("select * from SAPSYSTEM where STATUS=? AND OMID= ? and ");
			if (sysInputDto.getSystemType().equals(ConstantsValues.SOURCESYSTEM)) {
				fetchQuery.append("ISSOURCESYSTEM=?");
			} else if (sysInputDto.getSystemType().equals(ConstantsValues.TARGETSYSTEM)) {
				fetchQuery.append("ISTARGETSYSTEM=?");
			} else {
				systemResDto.getResMessageDto().setMessage(ConstantsValues.INVALIDSAPSYSTEM);
				return systemResDto;
			}
			con = DBConnection.createConnection();
			pStmt = con.prepareStatement(fetchQuery.toString());
			pStmt.setString(1, ConstantsValues.ACTIVESTATUS);
			pStmt.setString(2, sysInputDto.getOmID());
			pStmt.setInt(3, 1);
			rs = pStmt.executeQuery();

			while (rs.next()) {
				flag = true;
				eccConfigDto = new SystemDTO();
				eccConfigDto.setOmId(rs.getString("OMID"));
				eccConfigDto.setSystemId(rs.getString("SYSTEMID"));
				eccConfigDto.setSapClientNo(rs.getString("SAPCLIENTNO"));
				eccConfigDto.setDescription(rs.getString("DESCRIPTION"));
				eccConfigDto.setSystemType(rs.getString("SYSTEMTYPE"));
				eccConfigDto.setIsSourceSystem(rs.getInt("ISSOURCESYSTEM"));
				eccConfigDto.setIsTargetSystem(rs.getInt("ISTARGETSYSTEM"));
				eccConfigDto.setId(rs.getInt("ID"));
				eccConfigDto.setStatus(rs.getString("Status"));
				eccConfigDto.setDestinationName(rs.getString("DESTINATIONNAME"));
				eccConfigDto.setIsHVESSystem(rs.getInt("ISHVESSYSTEM"));
				eccConfigDto.setSncEnabled(rs.getInt("SNC_ENABLED"));
				eccConfigDto.setSncName(rs.getString("SNC_NAME"));
				eccConfigDto.setSncPartnerName(rs.getString("SNCPARTNER_NAME"));
				eccConfigDto.setSapRouter(rs.getString("SAP_ROUTER"));
				eccConfigDto.setSncProtectionLevel(rs.getString("PROTECTION_LEVEL"));
				systems.add(eccConfigDto);
			}

			if (!flag) {
				systemResDto.getResMessageDto().setMessage(ConstantsValues.NORECORDSEXISTS);
				slf4jLogger.error(ConstantsValues.NORECORDSEXISTS);
				systemResDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
				return systemResDto;
			}

			if (systems.isEmpty()) {
				systemResDto.getResMessageDto().setMessage(ConstantsValues.NORECORDSEXISTS);

			} else {
				systemResDto.setSystemList(systems);
				systemResDto.getResMessageDto().setMessage(ConstantsValues.SUCCESSSTATUS);
			}
		} catch (SQLException e) {
			systemResDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
			systemResDto.getResMessageDto().setMessage(ConstantsValues.DATABASEERROR);
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
		} finally {

			if (rs != null) {
				try {
					rs.close();
					rs = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}

			if (pStmt != null) {
				try {
					pStmt.close();
					pStmt = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}

			if (con != null) {
				try {
					con.close();
					con = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}
			slf4jLogger.info("getSourceTargetDetails method ended");

		}

		return systemResDto;
	}

	public CustomResDto getTargetSystemDetails() {
		slf4jLogger.info("getTargetSystemDetails method started");
		CustomResDto resDto = new CustomResDto();
		ResMessageDto resMessageDto = new ResMessageDto();
		resDto.setResMessageDto(resMessageDto);
		List<String> systems = new ArrayList<>();
		ResultSet rs = null;
		PreparedStatement pStmt = null;
		StringBuilder fetchQuery = null;
		Connection con = null;
		boolean flag = false;
		try {
			fetchQuery = new StringBuilder(
					"select DISTINCT DESTINATIONNAME from SAPSYSTEM where STATUS=? AND SYSTEMTYPE=?");
			con = DBConnection.createConnection();
			pStmt = con.prepareStatement(fetchQuery.toString());
			pStmt.setString(1, ConstantsValues.ACTIVESTATUS);
			pStmt.setString(2, "S4 HANA");
			rs = pStmt.executeQuery();
			while (rs.next()) {
				flag = true;
				systems.add(rs.getString("DESTINATIONNAME"));
			}

			if (!flag) {
				resDto.getResMessageDto().setMessage(ConstantsValues.NORECORDSEXISTS);
				slf4jLogger.error(ConstantsValues.NORECORDSEXISTS);
				resDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
				return resDto;
			}

			if (systems.isEmpty()) {
				resDto.getResMessageDto().setMessage(ConstantsValues.NORECORDSEXISTS);
				slf4jLogger.error(ConstantsValues.NORECORDSEXISTS);
			} else {
				resDto.setDataList(systems);
				resDto.getResMessageDto().setMessage(ConstantsValues.SUCCESSSTATUS);
			}
		} catch (SQLException e) {
			resDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
			resDto.getResMessageDto().setMessage(ConstantsValues.DATABASEERROR);
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
		} finally {

			if (rs != null) {
				try {
					rs.close();
					rs = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}

			if (pStmt != null) {
				try {
					pStmt.close();
					pStmt = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}

			if (con != null) {
				try {
					con.close();
					con = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}
			slf4jLogger.info("getTargetSystemDetails method ended");

		}

		return resDto;
	}

	public CustomResDto getTargetSystemDeatils(SysInputDto sysInputDto) {
		slf4jLogger.info("getTargetSystemDeatils method started");
		CustomResDto resDto = new CustomResDto();
		ResMessageDto resMessageDto = new ResMessageDto();
		resDto.setResMessageDto(resMessageDto);
		ResultSet rs = null;
		PreparedStatement pStmt = null;
		boolean status = false;
		Connection con = null;
		ArrayList<String> targetSystems = null;
		try {
			con = DBConnection.createConnection();
			targetSystems = new ArrayList<>();
			pStmt = con.prepareStatement(
					"SELECT DESTINATIONNAME FROM SAPSYSTEM  WHERE ISTARGETSYSTEM=? AND STATUS=? AND OMID=?");

			pStmt.setInt(1, 1);
			pStmt.setString(2, ConstantsValues.ACTIVESTATUS);
			pStmt.setString(3, sysInputDto.getOmID());

			rs = pStmt.executeQuery();
			while (rs.next()) {
				status = true;
				targetSystems.add(rs.getString("DESTINATIONNAME"));
			}
			resDto.setDataList(targetSystems);
			if (!status) {
				resDto.getResMessageDto().setMessage(ConstantsValues.NORECORDSEXISTS);
				slf4jLogger.error(ConstantsValues.NORECORDSEXISTS);
				resDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
			}
		} catch (SQLException e) {
			resDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
			resDto.getResMessageDto().setMessage(ConstantsValues.DATABASEERROR);
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
		} finally {
			targetSystems = null;
			if (rs != null) {
				try {
					rs.close();
					rs = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}
			if (pStmt != null) {
				try {
					pStmt.close();
					pStmt = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}

			if (con != null) {
				try {
					con.close();
					con = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}
			slf4jLogger.info("getTargetSystemDeatils method ended");

		}

		return resDto;
	}

	public ArrayList<SystemDTO> fetchSystemDetails(SystemDTO config) {
		slf4jLogger.info("fetchSystemDetails method started");
		ResMessageDto resMessageDto = new ResMessageDto();
		;
		Connection con = null;

		PreparedStatement pStmt = null;
		ResultSet rs = null;
		PreparedStatement ps = null;
		PropMappings propObj = PropMappings.getInstance();
		ArrayList<SystemDTO> systemdetails = new ArrayList<SystemDTO>() ;
		// hostname,sytemno,sysid,lang,userid,pwd from sapsystem where dest=?
		try {
			con = DBConnection.createConnection();
			pStmt = con.prepareStatement(
					"select HOSTNAME,SAPCLIENTNO,SYSTEMNO,SYSTEMID,LANGUAGE,USERID,PASSWORD,SNC_ENABLED, SNC_NAME, SNCPARTNER_NAME, "
					+ "SAP_ROUTER, PROTECTION_LEVEL from SAPSYSTEM where DESTINATIONNAME= ?");
			pStmt.setString(1, config.getDestinationName());

			rs = pStmt.executeQuery();
			SystemDTO outputDto=null;
			while (rs.next()) {
				outputDto=new SystemDTO();
				outputDto.setHostName(rs.getString("HOSTNAME"));
				outputDto.setSapClientNo(rs.getString("SAPCLIENTNO"));
				outputDto.setSystemNo(rs.getString("SYSTEMNO"));
				outputDto.setSystemId(rs.getString("SYSTEMID"));
				outputDto.setLanguage(rs.getString("LANGUAGE"));
				outputDto.setUserId(rs.getString("USERID"));
				outputDto.setPassword(rs.getString("PASSWORD"));
				outputDto.setSncEnabled(rs.getInt("SNC_ENABLED"));
				outputDto.setSncName(rs.getString("SNC_NAME"));
				outputDto.setSncPartnerName(rs.getString("SNCPARTNER_NAME"));
				outputDto.setSapRouter(rs.getString("SAP_ROUTER"));
				outputDto.setSncProtectionLevel(rs.getString("PROTECTION_LEVEL"));
				
				resMessageDto.setMsgType(ConstantsValues.SUCCESSSTATUS);
				resMessageDto.setMessage(ConstantsValues.SUCCESSVALIDATION);
				outputDto.setResMessageDTO(resMessageDto);
				systemdetails.add(outputDto);
			}

		} catch (SQLException e) {
			resMessageDto.setMsgType(ConstantsValues.DBERROR);
			resMessageDto.setMessage(ConstantsValues.SYSTEMNOTCREATED);
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
		} finally {
			if (rs != null) {
				try {
					rs.close();
					rs = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}

			if (pStmt != null) {
				try {
					pStmt.close();
					pStmt = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}
			if (ps != null) {
				try {
					ps.close();
					ps = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}

			if (con != null) {
				try {
					con.close();
					con = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				}
			}
			slf4jLogger.info("addConfig method ended");

		}

		return systemdetails;

	}

}