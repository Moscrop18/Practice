package com.acn.rpa.admin;

public class VersionResDTO {  
	/*private double customerIdExists;
	private boolean isUserExists;
	private int validatyDays;*/
	private double version;

	public double getVersion() {
		return version;
	}
	public void setVersion(double version) {
		this.version = version;
	}

	
}