package com.acn.rpa.admin;



import java.util.List;

import com.acn.user.session.ResMessageDto;

public class AuthorizationMappingResDTO {
	
	
	private List<String> actionIdList;
	private ResMessageDto resMessageDto;

	public List<String> getActionIdList() {
		return actionIdList;
	}

	public void setActionIdList(List<String> actionIdList) {
		this.actionIdList = actionIdList;
	}

	public ResMessageDto getResMessageDto() {
		return resMessageDto;
	}

	public void setResMessageDto(ResMessageDto resMessageDto) {
		this.resMessageDto = resMessageDto;
	}
	

}
