package com.acn.rpa.admin;

//import java.util.List;

/*import com.acn.rpa.config.ScopeSessionDto;
import com.acn.rpa.config.UserConfigScopeDto;
import com.acn.rpa.config.UserProjectsDto;
import com.acn.user.session.ResMessageDto;
import com.acn.user.session.SessionInputDTO;*/

public class SaltResDTO {  
	private double version;
	public double getVersion() {
		return version;
	}
	public void setVersion(double version) {
		this.version = version;
	}
	public String getSalt() {
		return salt;
	}
	public void setSalt(String salt) {
		this.salt = salt;
	}
	private String salt;
}