package com.acn.rpa.admin;

import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.DBConnection;
import com.acn.rpa.utilities.PropMappings;
import com.acn.user.session.LoginDto;
import com.acn.user.session.ResMessageDto;
import com.acn.user.session.SessionInputDTO;
import com.acn.user.session.UserRolesDto;
import com.acn.user.session.UserSessionDao;
import com.acn.user.session.UserSessionDto;
public class GetUserDetails { 
    private final Logger slf4jLogger = LoggerFactory.getLogger(GetUserDetails.class);

	public ResponseDto validateRole(LoginDto loginUserdto) {
		slf4jLogger.info("validateRole method started");
		String userId = loginUserdto.getUserId();
		String password = loginUserdto.getToolPwd();
		UserSessionDto userSessionDto =  new UserSessionDto();
		Connection con = null;
		PreparedStatement pStmt=null;
		PreparedStatement pStmt1=null;
		PreparedStatement pStmt2=null;
		PreparedStatement pStmt3=null;
		PreparedStatement pStmt4=null;
		ResultSet rs = null;
		ResultSet rs1 = null;
		ResponseDto responseDtoObj = null;
		String reHashedPassword = null;
		String hashedPassword = null;
		String fetchRole = null;
		String updateInvalidAttempt = null;
		String updateValidAttempt = null;
    	PropMappings propObj = PropMappings.getInstance();
    	SessionInputDTO sessionInputDtoObj = null;
    	if(propObj.getValue("S4CONFIGHANA_DB").equals("SAPHANA")){
    		fetchRole="SELECT B.ROLEID,A.FIRSTNAME,A.LASTNAME,DAYS_BETWEEN(NOW(),A.VALIDTO) \"DAYS\",A.DEFAULT_P,A.ATTEMPTS,A.PASSWORD,A.STATUS,A.ATTEMPTS FROM USER A, ROLE B  WHERE trim(A.ROLEID)=trim(B.ROLEID) AND  A.USERID= ?";
    	}
    	else{
    		fetchRole="SELECT B.ROLEID,A.FIRSTNAME,A.LASTNAME,DATEDIFF(validto,NOW()) \"DAYS\",A.DEFAULT_P,A.ATTEMPTS,A.PASSWORD,A.STATUS,A.ATTEMPTS FROM USER A, ROLE B  WHERE trim(A.ROLEID)=trim(B.ROLEID) AND  A.USERID= ?";

    	}
    	if(propObj.getValue("S4CONFIGHANA_DB").equals("SAPHANA")){    		
    		updateInvalidAttempt = "UPDATE USER SET ATTEMPTS = ((SELECT ATTEMPTS FROM USER WHERE USERID = ?) + 1) WHERE USERID = ?";
    	}else{
    		updateInvalidAttempt = "UPDATE USER SET ATTEMPTS = ((SELECT ATTEMPTS WHERE USERID = ?) + 1) WHERE USERID = ?";
    	}
    		updateValidAttempt = "UPDATE USER SET ATTEMPTS = ? WHERE USERID = ?";
    	String updateAccLock = "UPDATE USER SET ACCLOCKED = ? WHERE USERID = ?";
		String getIsSecQAExists = "SELECT Count(1) AS Count FROM SECURITYANSWER WHERE USERID = ?";
		try{
			responseDtoObj = new ResponseDto(); 
			responseDtoObj.setUserId(userId);
			con  = DBConnection.createConnection();
			pStmt =  con.prepareStatement(getIsSecQAExists);
			pStmt.setString(1, userId);
			rs = pStmt.executeQuery();
			if(rs.next() && rs.getInt("Count") == 0){
				responseDtoObj.setSecQAUpdated(false);
			}else{
			   responseDtoObj.setSecQAUpdated(true);
			}
			
			pStmt1 =  con.prepareStatement(fetchRole);
			pStmt1.setString(1, userId);
			rs1 = pStmt1.executeQuery();
			
			if(rs1.next()){
				hashedPassword = rs1.getString("PASSWORD");
				reHashedPassword = UserDao.getReHashedPassword(hashedPassword+propObj.getValue("SALT"));
				if(reHashedPassword != null && reHashedPassword.equals(password)){
					if(rs1.getInt("ATTEMPTS") > 0){
						pStmt2 =  con.prepareStatement(updateValidAttempt);
						pStmt2.setInt(1, ConstantsValues.ZERO);
						pStmt2.setString(2, userId);
						pStmt2.executeUpdate();
					}
					if(rs1.getInt("DAYS") < 0 ){
						responseDtoObj.setCredentialValidation(ConstantsValues.FALSESTATUS);
						responseDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
						responseDtoObj.setMessage(ConstantsValues.USERVALIDITYEXPIRED);
						slf4jLogger.error(userId + " " + ConstantsValues.USERVALIDITYEXPIRED,userId);
						return responseDtoObj;
					}
					else if(rs1.getString("Status").equals(ConstantsValues.INACTIVESTATUS)){
						responseDtoObj.setCredentialValidation(ConstantsValues.FALSESTATUS);
						responseDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
						responseDtoObj.setMessage(ConstantsValues.INACTIVEUSERID);
						slf4jLogger.error(userId +  " " +ConstantsValues.INACTIVEUSERID,userId);
						return responseDtoObj;
					}
					else{
						responseDtoObj.setRole(rs1.getString("ROLEID"));
						responseDtoObj.setFirstName(rs1.getString("FIRSTNAME"));
						responseDtoObj.setLastName(rs1.getString("LASTNAME"));
						responseDtoObj.setValidatyDays((int)rs1.getInt("DAYS"));
						responseDtoObj.setMessage(ConstantsValues.VALIDUSERCREDENTIALS);
						responseDtoObj.setDefault_p(rs1.getString("DEFAULT_P"));
						responseDtoObj.setAttempts(rs1.getString("ATTEMPTS"));
						responseDtoObj.setCredentialValidation(ConstantsValues.TRUESTATUS);
						responseDtoObj.setStatus(ConstantsValues.SUCCESSSTATUS);
						slf4jLogger.error(userId +  " " +ConstantsValues.VALIDUSERCREDENTIALS,userId);
					}
				}
				else{
					if(rs1.getInt("ATTEMPTS") < 5){
						pStmt3 =  con.prepareStatement(updateInvalidAttempt);
						pStmt3.setString(1, userId);
						pStmt3.setString(2, userId);
						pStmt3.executeUpdate();
						responseDtoObj.setMessage(ConstantsValues.INVALIDUSERCREDENTIALSALERT);
						slf4jLogger.error(userId +  " " +ConstantsValues.INVALIDUSERCREDENTIALSALERT,userId);
						responseDtoObj.setCredentialValidation(ConstantsValues.FALSESTATUS);
						return responseDtoObj;
					}else{
						responseDtoObj.setCredentialValidation(ConstantsValues.FALSESTATUS);
						responseDtoObj.setMessage(ConstantsValues.ACCOUNTLOCKED);
					
						pStmt4 =  con.prepareStatement(updateAccLock);
						pStmt4.setString(1, ConstantsValues.Y);
						pStmt4.setString(2, userId);
						pStmt4.executeUpdate();
						slf4jLogger.error(userId +  " " +ConstantsValues.ACCOUNTLOCKED,userId);
						return responseDtoObj;
					}
				}
			}
			else{
				responseDtoObj.setMessage(ConstantsValues.INVALIDUSERCREDENTIALS);
				responseDtoObj.setCredentialValidation(ConstantsValues.FALSESTATUS);
				return responseDtoObj;
			}
				
			sessionInputDtoObj = new SessionInputDTO();
			sessionInputDtoObj.setCsrfToken(getSaltString());
			sessionInputDtoObj.setSessionId(getSaltString());

			userSessionDto.setBrowserID(loginUserdto.getBrowserId());
			userSessionDto.setUserID(loginUserdto.getUserId());
			userSessionDto.setCsrfToken(sessionInputDtoObj.getCsrfToken());
			userSessionDto.setSessionId(sessionInputDtoObj.getSessionId());
			UserSessionDao sessionDao = new UserSessionDao();
			if(sessionDao.userSessionCreation(userSessionDto)){
				responseDtoObj.setSessionInputDTO(sessionInputDtoObj);
			}
		}catch(SQLException e){
			responseDtoObj.setStatus(ConstantsValues.DBERROR);
			responseDtoObj.setMessage(ConstantsValues.DATABASEERROR);
			slf4jLogger.error(userId + ConstantsValues.EXCEPTIONDETAILS,e); 
		}
		catch(Exception e){
			responseDtoObj.setStatus(ConstantsValues.DBERROR);
			responseDtoObj.setMessage(ConstantsValues.DATABASEERROR);
			slf4jLogger.error(userId + ConstantsValues.EXCEPTIONDETAILS,e); 
		}finally {
			
			if (rs1 != null) {
	            try {
	            	rs1.close();
	            	rs1 = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e); 
	            }
	        }
			if (rs != null) {
	            try {
	            	rs.close();
	            	rs = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e); 
	            }
	        }

			if (pStmt != null) {
	            try {
	            	pStmt.close();
	            	pStmt = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e); 
	            }
	        }
			
			if (pStmt1 != null) {
	            try {
	            	pStmt1.close();
	            	pStmt1 = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e); 
	            }
	        }
			
			if (pStmt2 != null) {
	            try {
	            	pStmt2.close();
	            	pStmt2 = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e); 
	            }
	        }
			if (pStmt3 != null) {
	            try {
	            	pStmt3.close();
	            	pStmt3 = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e); 
	            }
	        }
			if (pStmt4 != null) {
	            try {
	            	pStmt4.close();
	            	pStmt4 = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e); 
	            }
	        }
	        if (con != null) {
	            try {
	            	con.close();
	            	con = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e); 
	            }
	        }
			  slf4jLogger.info("validateRole method ended");
}
	
		return responseDtoObj;
}
	
	
	public UserRolesDto displayRoles()  {
		slf4jLogger.info("displayRoles method started");
		UserRolesDto userRoleDto = new UserRolesDto(); 
		ResMessageDto resMessageDto = new ResMessageDto();
		ResultSet rs=null; 
		PreparedStatement pStmt=null;
		boolean status = false;
		List<String> roles;
		Connection con = null;
		userRoleDto.setResMessageDto(resMessageDto);
		try{
			con = DBConnection.createConnection();
			roles = new ArrayList<>();
			pStmt =   con.prepareStatement("SELECT ROLEID FROM ROLE"); 
			rs = pStmt.executeQuery();
			while(rs.next()){
				status = true;
				roles.add(rs.getString("ROLEID"));	
			}
			userRoleDto.setRoles(roles);	
			if(!status){
				resMessageDto.setMessage(ConstantsValues.NORECORDSEXISTS);
				resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
				slf4jLogger.error(ConstantsValues.NORECORDSEXISTS); 
			}
		}
		catch (Exception e){
			resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			resMessageDto.setMessage(ConstantsValues.DATABASEERROR);
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e); 
		}finally{
		    if (rs != null) {
	            try {
	            	rs.close();
	            	rs = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e); 
	            }
	        }
			if (pStmt != null) {
	            try {
	            	pStmt.close();
	            	pStmt = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e); 
	            }
	        }

	        if (con != null) {
	            try {
	            	con.close();
	            	con = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e); 
	            }
	        }
			  slf4jLogger.info("displayRoles method ended");

		}	
		
		return userRoleDto; 
	}
	
	public Boolean updateUserToken(String userId,String userToken)  {
		slf4jLogger.info("updateUserToken method started");
		Connection con = null;
		PreparedStatement pStmt=null;
	  	String updateUserToken = "UPDATE USER SET USERTOKEN= ? WHERE USERID= ?";
	  	int count = 0;
	  	boolean flag=false;
		try{
			con = DBConnection.createConnection();
			pStmt =  con.prepareStatement(updateUserToken);
			pStmt.setString(1, userToken);
			pStmt.setString(2, userId);
			count = pStmt.executeUpdate();
			if(count>0){
				flag = true;
			}
			
		}
		catch (SQLException e){
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e); 
		}finally{
			
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
						slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e); 
				}
			}
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e); 
				}
			}
			  slf4jLogger.info("updateUserToken method ended");

		}	
		
		return flag;
	}
	
	public static String getSaltString() {
		Logger slf4jLogger = LoggerFactory.getLogger(GetUserDetails.class);
		slf4jLogger.info("getSaltString method started");
        String SALTCHARS = "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz1234567890";
        StringBuilder salt = new StringBuilder();
        SecureRandom rnd = new SecureRandom();
        String saltStr = null;
        try{
        while (salt.length() < 16) {
            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
            salt.append(SALTCHARS.charAt(index));
        }
        saltStr = salt.toString();
        }catch(Exception e){
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e); 
			return null;
        }
        finally{
    		slf4jLogger.info("getSaltString method ended");

        }
        return UserDao.getReHashedPassword(saltStr);
        
	}
}