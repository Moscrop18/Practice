package com.acn.rpa.admin;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.acn.user.session.SessionInputDTO;



public class CustomerDto {

	@Size(min = 1, max = 40)
	@Pattern(regexp = "^[\\p{L} .'-]+$")
	private String customerName;
	@Size(min = 1, max = 20)
	@Pattern(regexp = "[a-zA-Z0-9]+")
	private String industryVertical;
	@Size(min = 1, max = 20)
	@Pattern(regexp = "[a-zA-Z0-9]+")
	private String geographicRegion;
	@Size(min = 1, max = 8)
	@Pattern(regexp = "[a-zA-Z0-9]+")
	private String deliveryUnit;
	@Size(min = 1, max = 40)
	@Pattern(regexp = "[a-zA-Z0-9]+")
	private String customerType;
	@Size(min = 1, max = 40)
	@Pattern(regexp = "^[\\p{L} .'-]+$")
	private String igPoc;
	@Size(min = 1, max = 40)
	@Pattern(regexp = "^[\\p{L} .'-]+$")
	private String gdn_ogLead; 
	@Size(min = 1, max = 20)
	private String omId;
	@Size(min = 1, max = 20)
	@Pattern(regexp = "^\\s*[a-zA-Z][a-zA-Z\\s]*$")
	private String status;
	@Size(min = 1, max = 50)
	@Pattern(regexp = "[a-zA-Z0-9\\s._&-,]+")
	private String projectName;
	@Size(min = 1, max = 20)
	private String omIdOld;
	@Size(min = 1, max = 1)
	@Pattern(regexp = "[a-zA-Z]+")
	private String trOverride;  // Added on 6th Dec'17 for the TR Changes
	@Valid
	private SessionInputDTO sessionInputDTO;
	private String buildtime;
	
	public String getBuildtime() {
		return buildtime;
	}
	public void setBuildtime(String buildtime) {
		this.buildtime = buildtime;
	}
	//Added by Veena
	  @Size(min = 0, max = 20)
		private String custDestReq;
	  //Ended by Veena
	
	public SessionInputDTO getSessionInputDTO() {
		return sessionInputDTO;
	}
	public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
		this.sessionInputDTO = sessionInputDTO;
	}
	public String getTrOverride() {
		return trOverride;
	}
	public void setTrOverride(String trOverride) {
		this.trOverride = trOverride;
	}
	
	
	public String getOmIdOld() {
		return omIdOld;
	}
	public void setOmIdOld(String omIdOld) {
		this.omIdOld = omIdOld;
	}
	
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getIndustryVertical() {
		return industryVertical;
	}
	public void setIndustryVertical(String industryVertical) {
		this.industryVertical = industryVertical;
	}

	public String getGeographicRegion() {
		return geographicRegion;
	}
	public void setGeographicRegion(String geographicRegion) {
		this.geographicRegion = geographicRegion;
	}
	public String getDeliveryUnit() {
		return deliveryUnit;
	}
	public void setDeliveryUnit(String deliveryUnit) {
		this.deliveryUnit = deliveryUnit;
	}
	public String getCustomerType() {
		return customerType;
	}
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	public String getIgPoc() {
		return igPoc;
	}
	public void setIgPoc(String igPoc) {
		this.igPoc = igPoc;
	}
	public String getGdn_ogLead() {
		return gdn_ogLead;
	}
	public void setGdn_ogLead(String gdn_ogLead) {
		this.gdn_ogLead = gdn_ogLead;
	}
	public String getOmId() {
		return omId;
	}
	public void setOmId(String omId) {
		this.omId = omId;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getCustDestReq() {
		return custDestReq;
	}
	public void setCustDestReq(String custDestReq) {
		this.custDestReq = custDestReq;
	}
		
}
