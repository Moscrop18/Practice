package com.acn.rpa.admin;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.acn.user.session.SessionInputDTO;

public class UserDto {
	@Size(min = 1, max = 40)
	@Pattern(regexp = "[a-zA-Z\\s._&-,]+")
	private String firstName;
	@Size(min = 1, max = 40)
	@Pattern(regexp = "[a-zA-Z\\s._&-,]+")
	private String lastName;
	@Pattern(regexp = "^[a-zA-Z0-9_!#$%&�*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$")
	private String email;
	@Size(min = 1, max = 8)
	@Pattern(regexp = "[a-zA-Z0-9]+")
	private String userId;
	@Size(min = 1, max = 20)
	@Pattern(regexp = "[a-zA-Z0-9]+")
	private String role;
	@Size(min = 1, max = 20)
	@Pattern(regexp = "^\\s*[a-zA-Z][a-zA-Z\\s]*$")
	private String status;
	//@Pattern(regexp = "^([\\+-]?\\d{4}(?!\\d{2}\\b))((-?)((0[1-9]|1[0-2])(\\3([12]\\d|0[1-9]|3[01]))?|W([0-4]\\d|5[0-2])(-?[1-7])?|(00[1-9]|0[1-9]\\d|[12]\\d{2}|3([0-5]\\d|6[1-6])))([T\\s]((([01]\\d|2[0-3])((:?)[0-5]\\d)?|24\\:?00)([\\.,]\\d+(?!:))?)?(\\17[0-5]\\d([\\.,]\\d+)?)?([zZ]|([\\+-])([01]\\d|2[0-3]):?([0-5]\\d)?)?)?)?$")
	@Size(min = 1, max = 23)
	private String validFrom;
	//@Pattern(regexp = "^([\\+-]?\\d{4}(?!\\d{2}\\b))((-?)((0[1-9]|1[0-2])(\\3([12]\\d|0[1-9]|3[01]))?|W([0-4]\\d|5[0-2])(-?[1-7])?|(00[1-9]|0[1-9]\\d|[12]\\d{2}|3([0-5]\\d|6[1-6])))([T\\s]((([01]\\d|2[0-3])((:?)[0-5]\\d)?|24\\:?00)([\\.,]\\d+(?!:))?)?(\\17[0-5]\\d([\\.,]\\d+)?)?([zZ]|([\\+-])([01]\\d|2[0-3]):?([0-5]\\d)?)?)?)?$")
	@Size(min = 1, max = 23)
	private String validTo;
	@Size(min = 8, max = 64)
    @Pattern(regexp = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$")
	private String password;
	/*@Size(min = 0, max = 1)
    @Pattern(regexp = "^\\d+$")*/
	private int isHvesSystem;
	@Size(min = 1, max = 20)
	private String omId;
	/*@Size(min = 0, max = 1)
    @Pattern(regexp = "[a-zA-Z]+")*/
	private String accLocked;
	/*@Size(min = 0, max = 1)
    @Pattern(regexp = "^\\d+$")*/
	private int invalidAttempt;
	@Size(min = 1, max = 1)
	private String default_p;
	@Valid
	public String getDefault_p() {
		
		return default_p;
	}
	public void setDefault_p(String default_p) {
		this.default_p = default_p;
	}
	private SessionInputDTO sessionInputDTO;
	
	public SessionInputDTO getSessionInputDTO() {
		return sessionInputDTO;
	}
	public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
		this.sessionInputDTO = sessionInputDTO;
	}

	public String getOmId() {
		return omId;
	}

	public void setOmId(String omId) {
		this.omId = omId;
	}

	public int getIsHvesSystem() {
		return isHvesSystem;
	}

	public void setIsHvesSystem(int isHvesSystem) {
		this.isHvesSystem = isHvesSystem;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstName() {
		return firstName;
	}



	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}



	public String getLastName() {
		return lastName;
	}



	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public String getUserId() {
		return userId;
	}



	public void setUserId(String userName) {
		this.userId = userName;
	}



	public String getRole() {
		return role;
	}



	public void setRole(String role) {
		this.role = role;
	}



	public String getStatus() {
		return status;
	}



	public void setStatus(String status) {
		this.status = status;
	}

	public String getValidFrom() {
		return validFrom;
	}



	public void setValidFrom(String validFrom) {
		this.validFrom = validFrom;
	}



	public String getValidTo() {
		return validTo;
	}

	public void setValidTo(String validTo) {
		this.validTo = validTo;
	}
	public String getAccLocked() {
		return accLocked;
	}
	public void setAccLocked(String accLocked) {
		this.accLocked = accLocked;
	}

	public int getInvalidAttempt() {
		return invalidAttempt;
	}
	public void setInvalidAttempt(int invalidAttempt) {
		this.invalidAttempt = invalidAttempt;
	}
}
