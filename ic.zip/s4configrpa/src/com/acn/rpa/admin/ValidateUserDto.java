package com.acn.rpa.admin;

public class ValidateUserDto {
	private boolean userValid ;
	private String fileStatus;

	public boolean isUserValid() {
		return userValid;
	}

	public void setUserValid(boolean userValid) {
		this.userValid = userValid;
	}
	public ValidateUserDto(boolean userValid) {
		super();
		this.userValid = userValid;		
	}
	
	public ValidateUserDto(boolean userValid,String fileStatus) {
		super();
		this.userValid = userValid;
		this.fileStatus = fileStatus;
	}

	public String getFileStatus() {
		return fileStatus;
	}

	public void setFileStatus(String fileStatus) {
		this.fileStatus = fileStatus;
	}
}
