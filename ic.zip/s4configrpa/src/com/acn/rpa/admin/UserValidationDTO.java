package com.acn.rpa.admin;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.acn.user.session.ResMessageDto;
import com.acn.user.session.SessionInputDTO;
import com.acn.user.session.SecurityQuestionDto;

public class UserValidationDTO {

	
	@Pattern(regexp = "^[a-zA-Z0-9_!#$%&�*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$")
	private String emailId;

	@Size(min = 1, max = 8)
	@Pattern(regexp = "[a-zA-Z0-9]+")
	private String userId;
	
	private boolean secQAUpdated;
	
	private int questionId;
	@Size(min = 1, max = 255)
	private String question;
	private List<SecurityQuestionDto> SecurityQuestionDto;
		
	public List<SecurityQuestionDto> getSecurityQuestionDto() {
		return SecurityQuestionDto;
	}
	public void setSecurityQuestionDto(List<SecurityQuestionDto> securityQuestionDto) {
		SecurityQuestionDto = securityQuestionDto;
	}
	@Valid
	private SessionInputDTO sessionInputDTO;
	private ResMessageDto resMessageDto;
	public boolean isSecQAUpdated() {
		return secQAUpdated;
	}
	public void setSecQAUpdated(boolean secQAUpdated) {
		this.secQAUpdated = secQAUpdated;
	}
	public ResMessageDto getResMessageDto() {
		return resMessageDto;
	}
	public void setResMessageDto(ResMessageDto resMessageDto) {
		this.resMessageDto = resMessageDto;
	}
	public SessionInputDTO getSessionInputDTO() {
		return sessionInputDTO;
	}
	public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
		this.sessionInputDTO = sessionInputDTO;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userName) {
		this.userId = userName;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public int getQuestionId() {
		return questionId;
	}
	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}
}
