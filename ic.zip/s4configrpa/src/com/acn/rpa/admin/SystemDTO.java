package com.acn.rpa.admin;

import javax.validation.Valid;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.acn.user.session.ResMessageDto;
import com.acn.user.session.SessionInputDTO;

public class SystemDTO {
	@Size(min = 1, max = 20)
	private String omId;
	private String hostName;
	@Size(min = 1, max = 3)
	@Pattern(regexp = "[a-zA-Z0-9]+")
	private String systemId;
	@Size(min = 1, max = 3)
	@Pattern(regexp = "[a-zA-Z0-9]+")
	private String sapClientNo;
	@Size(min = 1, max = 15)
	@Pattern(regexp = "[a-zA-Z0-9\\s._&-,]+")
	private String userId;
	private String password;
	private String language;
	@Size(min = 1, max = 40)
	@Pattern(regexp = "[a-zA-Z0-9\\s._&-,]+")
	private String description;
	@Size(min = 1, max = 20)
	private String systemType;
	@DecimalMin(value = "0")
    @DecimalMax(value = "1")
	private int isSourceSystem;
	@DecimalMin(value = "0")
    @DecimalMax(value = "1")
	private int isTargetSystem;
//	private String mappedTargetSystem;
	private int id;
	private String status;
	@Size(min = 1, max = 20)
	@Pattern(regexp = "[a-zA-Z0-9]+")
	private String destinationName;
	@Size(min = 1, max = 10)
	@Pattern(regexp = "[a-zA-Z]+")
	private String system;
	private String systemNo;
	@DecimalMin(value = "0")
    @DecimalMax(value = "1")
	private int isHVESSystem;
	@Size(min = 1, max = 50)
	@Pattern(regexp = "[a-zA-Z0-9\\s._&-,]+") 
	private String projectName;
	@Valid
	private SessionInputDTO sessionInputDTO;
	private ResMessageDto resMessageDTO;
	
	@DecimalMin(value = "0")
    @DecimalMax(value = "1")
	private int sncEnabled;
	
	private String sncName;
	
	private String sncPartnerName;
	
	private String sapRouter;
	
	private String sncProtectionLevel;
	
	public ResMessageDto getResMessageDTO() {
		return resMessageDTO;
	}
	public void setResMessageDTO(ResMessageDto resMessageDTO) {
		this.resMessageDTO = resMessageDTO;
	}
	public SessionInputDTO getSessionInputDTO() {
		return sessionInputDTO;
	}
	public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
		this.sessionInputDTO = sessionInputDTO;
	}

	public String getSystemNo() {
		return systemNo;
	}

	public void setSystemNo(String systemNo) {
		this.systemNo = systemNo;
	}

	/*public String getMappedTargetSystem() {
		return mappedTargetSystem;
	}

	public void setMappedTargetSystem(String mappedTargetSystem) {
		this.mappedTargetSystem = mappedTargetSystem;
	}*/

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public int getIsHVESSystem() {
		return isHVESSystem;
	}

	public void setIsHVESSystem(int isHVESSystem) {
		this.isHVESSystem = isHVESSystem;
	}



	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}
	public String getDestinationName() {
		return destinationName;
	}

	public void setDestinationName(String destinationName) {
		this.destinationName = destinationName;
	}

	public String getOmId() {
		return omId;
	}

	public void setOmId(String omId) {
		this.omId = omId;
	}

	public String getHostName() {
		return hostName;
	}

	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	public String getSystemId() {
		return systemId;
	}

	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}

	public String getSapClientNo() {
		return sapClientNo;
	}

	public void setSapClientNo(String sapClientNo) {
		this.sapClientNo = sapClientNo;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSystemType() {
		return systemType;
	}

	public void setSystemType(String systemType) {
		this.systemType = systemType;
	}

	public int getIsSourceSystem() {
		return isSourceSystem;
	}

	public void setIsSourceSystem(int isSourceSystem) {
		this.isSourceSystem = isSourceSystem;
	}

	public int getIsTargetSystem() {
		return isTargetSystem;
	}

	public void setIsTargetSystem(int isTargetSystem) {
		this.isTargetSystem = isTargetSystem;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	public int getSncEnabled() {
		return sncEnabled;
	}
	public void setSncEnabled(int sncEnabled) {
		this.sncEnabled = sncEnabled;
	}
	public String getSncName() {
		return sncName;
	}
	public void setSncName(String sncName) {
		this.sncName = sncName;
	}
	public String getSncPartnerName() {
		return sncPartnerName;
	}
	public void setSncPartnerName(String sncPartnerName) {
		this.sncPartnerName = sncPartnerName;
	}
	public String getSapRouter() {
		return sapRouter;
	}
	public void setSapRouter(String sapRouter) {
		this.sapRouter = sapRouter;
	}
	public String getSncProtectionLevel() {
		return sncProtectionLevel;
	}
	public void setSncProtectionLevel(String sncProtectionLevel) {
		this.sncProtectionLevel = sncProtectionLevel;
	}
	

}
