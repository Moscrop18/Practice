package com.acn.rpa.admin;


import com.acn.user.session.ResMessageDto;
import com.acn.user.session.SessionInputDTO;

import java.util.List;

import com.acn.rpa.config.ScopeSessionDto;

public class ResponseDto {  
	private double version;
	private String salt;
	private String firstName;
	private String lastName; 
	private String credentialValidation;
	private String message;
	private String role;
	private String status;

	private String attempts;
	private String default_p;
	private SessionInputDTO sessionInputDTO;
	private String userId; 
	private boolean isCustomerIdExists;
	private boolean isUserExists;
	private int validatyDays;
	private ResMessageDto resMessageDto;
	List<SystemDTO> resSapSystemList;
	private List<UserRespDto> resUserList;
	private List<UserDto> respUserList;
	private String clientId;
	private ScopeSessionDto ScopeSessionDto;
	private boolean isSecQAUpdated;
	public boolean isSecQAUpdated() {
		return isSecQAUpdated;
	}
	public void setSecQAUpdated(boolean isSecQAUpdated) {
		this.isSecQAUpdated = isSecQAUpdated;
	}
	public List<SystemDTO> getResSapSystemList() {
		return resSapSystemList;
	}
	public void setResSapSystemList(List<SystemDTO> resSapSystemList) {
		this.resSapSystemList = resSapSystemList;
	}
	public List<UserRespDto> getResUserList() {
		return resUserList;
	}
	public void setResUserList(List<UserRespDto> resUserList) {
		this.resUserList = resUserList;
	}
	public List<UserDto> getRespUserList() {
		return respUserList;
	}
	public void setRespUserList(List<UserDto> respUserList) {
		this.respUserList = respUserList;
	}
	
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public ScopeSessionDto getScopeSessionDto() {
		return ScopeSessionDto;
	}
	public void setScopeSessionDto(ScopeSessionDto scopeSessionDto) {
		ScopeSessionDto = scopeSessionDto;
	}
	
	public double getVersion() {
		return version;
	}
	public void setVersion(double version) {
		this.version = version;
	}
	public String getSalt() {
		return salt;
	}
	public void setSalt(String salt) {
		this.salt = salt;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getCredentialValidation() {
		return credentialValidation;
	}
	public void setCredentialValidation(String credentialValidation) {
		this.credentialValidation = credentialValidation;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public SessionInputDTO getSessionInputDTO() {
		return sessionInputDTO;
	}
	public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
		this.sessionInputDTO = sessionInputDTO;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public boolean isCustomerIdExists() {
		return isCustomerIdExists;
	}
	public void setCustomerIdExists(boolean isCustomerIdExists) {
		this.isCustomerIdExists = isCustomerIdExists;
	}
	public boolean isUserExists() {
		return isUserExists;
	}
	public void setUserExists(boolean isUserExists) {
		this.isUserExists = isUserExists;
	}
	public int getValidatyDays() {
		return validatyDays;
	}
	public void setValidatyDays(int validatyDays) {
		this.validatyDays = validatyDays;
	}
	public ResMessageDto getResMessageDto() {
		return resMessageDto;
	}
	public void setResMessageDto(ResMessageDto resMessageDto) {
		this.resMessageDto = resMessageDto;
	}
	public String getDefault_p() {
		return default_p;
	}
	public void setDefault_p(String default_p) {
		this.default_p = default_p;
	}
	public String getAttempts() {
		return attempts;
	}
	public void setAttempts(String attempts) {
		this.attempts = attempts;
	}
}