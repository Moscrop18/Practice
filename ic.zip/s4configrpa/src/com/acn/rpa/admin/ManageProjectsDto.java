package com.acn.rpa.admin;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;



public class ManageProjectsDto {
	@Size(min = 1, max = 30)
	private String omId;
	@Size(min = 1, max = 50)
	@Pattern(regexp = "[a-zA-Z0-9\\s._&-,]+") 
	private String projectName;
	@Size(min = 1, max = 8)
	@Pattern(regexp = "[a-zA-Z0-9]+")
	private String userId;
	private String status;
	private String message;
	@Valid
	private List<String> existingprojects;

	public List<String> getExistingprojects() {
		return existingprojects;
	}

	public void setExistingprojects(List<String> existingprojects) {
		this.existingprojects = existingprojects;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getOmId() {
		return omId;
	}

	public void setOmId(String omId) {
		this.omId = omId;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

}
