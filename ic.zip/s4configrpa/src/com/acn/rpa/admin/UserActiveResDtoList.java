package com.acn.rpa.admin;

import java.util.List;

import com.acn.user.session.ResMessageDto;

public class UserActiveResDtoList {
	private List<UserActiveResDto> userList;
	private ResMessageDto resMessageDto;
	public List<UserActiveResDto> getUserList() {
		return userList;
	}
	public void setUserList(List<UserActiveResDto> userList) {
		this.userList = userList;
	}
	public ResMessageDto getResMessageDto() {
		return resMessageDto;
	}
	public void setResMessageDto(ResMessageDto resMessageDto) {
		this.resMessageDto = resMessageDto;
	}
	
}
