package com.acn.rpa.admin;


import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.DBConnection;
import com.acn.user.session.ResMessageDto;
import com.acn.user.session.SessionInputDTO;

public class AuthorizationMappingDAO {
    private final Logger slf4jLogger = LoggerFactory.getLogger(AuthorizationMappingDAO.class);
/*   public AuthorizationMappingResDTO getAuthorizedActionids(SessionInputDTO inputDto) {
    	slf4jLogger.info("getAuthorizedActionids method started");
		AuthorizationMappingResDTO authorizationMappingResDto = new AuthorizationMappingResDTO();
		ResMessageDto resMessageDto = new ResMessageDto();
		authorizationMappingResDto.setResMessageDto(resMessageDto);
		List<String> actionIdList = new ArrayList<>();
		ResultSet resultSet = null;
		ResultSet resultSet1 = null;
		PreparedStatement pStmt = null;
		PreparedStatement pStmt1 = null;
		boolean status = false;
		Connection dbConnection = null;
		String roleid="";
		try {
			dbConnection = DBConnection.createConnection();
			
			pStmt = dbConnection.prepareStatement("SELECT ActionId FROM AUTHORIZATIONMAPPING WHERE ROLEID=(select b.roleid from user a,role b where a.roleid=b.roleid AND a.userid=(select userid from usersession where csrftoken=? and sessionid=?))");
			pStmt.setString(1, inputDto.getCsrfToken());
			pStmt.setString(2, inputDto.getSessionId());
			resultSet = pStmt.executeQuery();
			while (resultSet.next()) {
				status = true;
				actionIdList.add(resultSet.getString("ActionId"));
			}
			if (!status) {
				resMessageDto.setMessage(ConstantsValues.NORECORDSEXISTS);
				resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
				slf4jLogger.error(ConstantsValues.NORECORDSEXISTS);
			} else{
				authorizationMappingResDto.setActionIdList(actionIdList);
			}
			resMessageDto.setMsgType(ConstantsValues.SUCCESSSTATUS);
			resMessageDto.setMessage(ConstantsValues.SUCCESSSTATUS);
		} catch (SQLException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			resMessageDto.setMessage(ConstantsValues.DATABASEERROR);
		} finally {
			if (resultSet != null) {
				try {
					resultSet.close();
					resultSet = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if (pStmt != null) {
				try {
					pStmt.close();
					pStmt = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}

			if (dbConnection != null) {
				try {
					dbConnection.close();
					dbConnection = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("getAuthorizedActionids method ended");

		}
		return authorizationMappingResDto;
    }*/

public AuthorizationMappingResDTO getAuthorizedActionids(AuthorizationMappingInputDTO inputDto) {
		slf4jLogger.info("getAuthorizedActionids method started");
		AuthorizationMappingResDTO authorizationMappingResDto = new AuthorizationMappingResDTO();
		ResMessageDto resMessageDto = new ResMessageDto();
		authorizationMappingResDto.setResMessageDto(resMessageDto);
		List<String> actionIdList = new ArrayList<>();
		ResultSet resultSet = null;
		PreparedStatement pStmt = null;
		boolean status = false;
		Connection dbConnection = null;
		try {
			dbConnection = DBConnection.createConnection();
			
			pStmt = dbConnection.prepareStatement("SELECT ActionId FROM AUTHORIZATIONMAPPING WHERE ROLEID=?");
			pStmt.setString(1, inputDto.getRoleId());
			resultSet = pStmt.executeQuery();
			while (resultSet.next()) {
				status = true;
				actionIdList.add(resultSet.getString("ActionId"));
			}

			if (!status) {
				resMessageDto.setMessage(ConstantsValues.NORECORDSEXISTS);
				resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
				slf4jLogger.error(ConstantsValues.NORECORDSEXISTS);
			} else{
				authorizationMappingResDto.setActionIdList(actionIdList);
			}
			resMessageDto.setMsgType(ConstantsValues.SUCCESSSTATUS);
		} catch (SQLException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			resMessageDto.setMessage(ConstantsValues.DATABASEERROR);
		} finally {
			if (resultSet != null) {
				try {
					resultSet.close();
					resultSet = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if (pStmt != null) {
				try {
					pStmt.close();
					pStmt = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}

			if (dbConnection != null) {
				try {
					dbConnection.close();
					dbConnection = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("getAuthorizedActionids method ended");

		}
		
		return authorizationMappingResDto;
	}

	public AuthorizationMappingResDTO assignAuthorizationIds(AuthorizationMappingInputDTO inputDto) {
		slf4jLogger.info("assignAuthorizationIds method started");
		AuthorizationMappingResDTO responseDtoObj = new AuthorizationMappingResDTO();
		ResMessageDto resMessageDto = new ResMessageDto();
		responseDtoObj.setResMessageDto(resMessageDto);
		PreparedStatement pStmt = null;
		Connection con = null;
		int length;
		try {
			con =  DBConnection.createConnection();
			pStmt = con.prepareStatement("INSERT INTO AUTHORIZATIONMAPPING(ROLEID,ACTIONID) VALUES(?,?)");
			length = inputDto.getActionIds().size();
			for (int i = 0; i < length; i++) {
				pStmt.setString(1, inputDto.getRoleId());
				pStmt.setString(2, inputDto.getActionIds().get(i));
				pStmt.addBatch();
			}
			pStmt.executeBatch();
			resMessageDto.setMsgType(ConstantsValues.SUCCESSSTATUS);
			resMessageDto.setMessage(ConstantsValues.SUCCESSSTATUS);
			slf4jLogger.error(ConstantsValues.SUCCESSSTATUS);
		} catch (SQLException e) {
			resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			resMessageDto.setMessage(ConstantsValues.DATABASEERROR);
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);

		} finally {
			if (pStmt != null) {
				try {
					pStmt.close();
					pStmt = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}

			if (con != null) {
				try {
					con.close();
					con = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("assignAuthorizationIds method ended");

		}
		return responseDtoObj;
	}

}
