package com.acn.rpa.admin;

public class SystemIdDto {
	
	private String systemid;
	private int systemno;
	public String getSystemid() {
		return systemid;
	}
	public void setSystemid(String systemid) {
		this.systemid = systemid;
	}
	public int getSystemno() {
		return systemno;
	}
	public void setSystemno(int systemno) {
		this.systemno = systemno;
	}

}
