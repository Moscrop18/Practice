package com.acn.rpa.admin;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.DBConnection;
import com.acn.rpa.utilities.PropMappings;
import com.acn.user.session.CustomResDto;
import com.acn.user.session.CustomerInputDto;
import com.acn.user.session.DataStatusDto;
import com.acn.user.session.ResMessageDto;
import com.acn.user.session.SessionInputDTO;
import com.acn.user.session.UserListDto;




public class UserDao {
    private final Logger slf4jLogger = LoggerFactory.getLogger(UserDao.class);

	public UserListDto getAllUsers(CustomerInputDto customerInputDto) {
		slf4jLogger.info("assignProjectsToUser method started");
		Connection con = null;
		List<UserRespDto> toolUserList = new ArrayList<>();
		ResultSet rs = null;
		PreparedStatement pStmt = null;
		UserRespDto toolUserDto;
		boolean status = false;
		StringBuilder query = new StringBuilder();
		UserListDto resDto = new UserListDto();
		ResMessageDto resMessageDto = new ResMessageDto();
		resDto.setResMessageDto(resMessageDto);
		try {
			con = DBConnection.createConnection();
			if (customerInputDto.getUserRole().equals(ConstantsValues.PROJECTADMIN)) {
				pStmt = con.prepareStatement(query.append("select distinct a.FIRSTNAME,a.LASTNAME,a.EMAILID,a.USERID,a.ROLEID,a.STATUS,a.VALIDFROM,a.VALIDTO,a.ACCLOCKED,a.ATTEMPTS from user a, userprojects b where a.roleid<> ? and b.omid in (")
									.append("select omid  from userprojects where userid= ?")
								.append(") AND a.userid IN (SELECT USERID FROM USERPROJECTS WHERE OMID IN  ")
								.append(" (select omid  from userprojects where userid= ?") 
								.append(")) UNION Select a.FIRSTNAME,a.LASTNAME,a.EMAILID,a.USERID,a.ROLEID,a.STATUS,a.VALIDFROM,a.VALIDTO,a.ACCLOCKED,a.ATTEMPTS from user a,userprojects b where a.roleid<> ?")
								.append("and a.userid not in (select userid from userprojects)").toString());
				pStmt.setString(1, ConstantsValues.TOOLADMIN);
				pStmt.setString(2, customerInputDto.getUserID());
				pStmt.setString(3, customerInputDto.getUserID());
				pStmt.setString(4, ConstantsValues.TOOLADMIN);
			} else if (customerInputDto.getUserRole().equals(ConstantsValues.TOOLADMIN)) {
				pStmt = con.prepareStatement("select FIRSTNAME, LASTNAME,EMAILID, USERID, ROLEID, STATUS, VALIDFROM, VALIDTO,ACCLOCKED,ATTEMPTS from USER ");
			}

			rs = pStmt.executeQuery();
			while (rs.next()) {
				toolUserDto = new UserRespDto();
				status = true;
				toolUserDto.setFirstName(rs.getString("FIRSTNAME"));
				toolUserDto.setLastName(rs.getString("LASTNAME"));
				toolUserDto.setEmail(rs.getString("EMAILID"));
				toolUserDto.setUserId(rs.getString("USERID"));
				toolUserDto.setRole(rs.getString("ROLEID"));
				toolUserDto.setStatus(rs.getString("STATUS"));
				toolUserDto.setAcclocked(rs.getString("ACCLOCKED"));
				toolUserDto.setInvalidAttempt(rs.getString("ATTEMPTS"));
				//toolUserDto.setPassword(rs.getString("PASSWORD"));

				String validFrom = null;
				if (rs.getTimestamp("VALIDFROM") != null) {
					validFrom = rs.getTimestamp("VALIDFROM").toString();
				}
				String validTo = null;
				if (rs.getTimestamp("VALIDTO") != null) {
					validTo = rs.getTimestamp("VALIDTO").toString();
				}
				toolUserDto.setValidFrom(validFrom);
				toolUserDto.setValidTo(validTo);
				toolUserList.add(toolUserDto);
			}
			resDto.setUserList(toolUserList);
			if (!status) {
				resDto.getResMessageDto().setMessage(ConstantsValues.NORECORDSEXISTS);
				 slf4jLogger.error(customerInputDto.getUserID() + ConstantsValues.NORECORDSEXISTS);
				resDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
			}
		} catch (SQLException e) {
			resDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
			resDto.getResMessageDto().setMessage(ConstantsValues.DATABASEERROR);
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		} finally {

			if (rs != null) {
				try {
					rs.close();
					rs = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}

			if (pStmt != null) {
				try {
					pStmt.close();
					pStmt = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}

			if (con != null) {
				try {
					con.close();
					con = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}

		}

		resDto.getResMessageDto().setMsgType(ConstantsValues.SUCCESSSTATUS);
		return resDto;
	}
	
	
	
	
	public ResponseDto getUser(String userId){
		slf4jLogger.info("getUser method started");
		Connection con = null;
		List<UserRespDto> users = new ArrayList<>();
		ResultSet rs = null;
		PreparedStatement pStmt = null;
		UserRespDto userDto = null;
		ResponseDto responseDtoObj = new ResponseDto();
		responseDtoObj.setUserId(userId);
		if (!ifExists(userId)) {
			responseDtoObj.setMessage("The userID you have entered does not exists!");
			responseDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
			return responseDtoObj;
		}

		try {
			con = DBConnection.createConnection();
			pStmt =  con.prepareStatement("select * from user where UserID = ?");
			pStmt.setString(1, userId);
			rs = pStmt.executeQuery();
			if (rs.next()) {
				userDto = new UserRespDto();
				userDto.setFirstName(rs.getString("FIRSTNAME"));
				userDto.setLastName(rs.getString("LASTNAME"));
				userDto.setEmail(rs.getString("EMAILID"));
				userDto.setUserId(rs.getString("USERID"));
				userDto.setRole(rs.getString("ROLEID"));
				userDto.setStatus(rs.getString("STATUS"));
				userDto.setValidFrom(rs.getTimestamp("VALIDFROM").toString().concat("00"));
				userDto.setValidTo(rs.getTimestamp("VALIDTO").toString().concat("00"));
				users.add(userDto);
			}
			responseDtoObj.setResUserList(users);
		} catch (SQLException e) {
			responseDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
			responseDtoObj.setMessage("Not able to fetch User Details ,please contact the Administrator!");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		} finally {

			if (rs != null) {
				try {
					rs.close();
					rs = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}

			if (pStmt != null) {
				try {
					pStmt.close();
					pStmt = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}

			if (con != null) {
				try {
					con.close();
					con = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("getUser method ended");


		}
		responseDtoObj.setStatus("Success");
		return responseDtoObj;
	}

	public ResMessageDto addUser(UserDto userDto) {
		slf4jLogger.info("addUser method started");
		Connection con = null;
		ResMessageDto resMessageDto = new ResMessageDto();
		if (ifExists(userDto.getUserId())) {
			resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			resMessageDto.setMessage("The userID you have entered already exists!");
			 slf4jLogger.error("The userID you have entered already exists!");
			return resMessageDto;
		}

		String validFrom = userDto.getValidFrom();
		String validTo = userDto.getValidTo();
		Timestamp validFromTs = null;
		Timestamp validToTs = null;
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS");
			Date parsedDate = dateFormat.parse(validFrom);
			validFromTs = new Timestamp(parsedDate.getTime());
			parsedDate = dateFormat.parse(validTo);
			validToTs = new Timestamp(parsedDate.getTime());
		} catch (Exception e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}
		PreparedStatement ps = null;
		String addUserQuery = "INSERT INTO USER(FirstName,LastName,EmailID,RoleID,Status,ValidFrom,ValidTo,UserID,PASSWORD,DEFAULT_P) VALUES (?,?,?,?,?,?,?,?,?,?)";
		try {
			con = DBConnection.createConnection();
			ps =  con.prepareStatement(addUserQuery);
			ps.setString(1, userDto.getFirstName());
			ps.setString(2, userDto.getLastName());
			ps.setString(3, userDto.getEmail());
			ps.setString(4, userDto.getRole());
			ps.setString(5, ConstantsValues.ACTIVESTATUS);
			ps.setTimestamp(6, validFromTs);
			ps.setTimestamp(7, validToTs);
			ps.setString(8, userDto.getUserId());
			ps.setString(9, getReHashedPassword(userDto.getPassword()));
			ps.setString(10, ConstantsValues.Y);
			ps.execute();
			resMessageDto.setMsgType(ConstantsValues.SUCCESSSTATUS);
			slf4jLogger.error(userDto.getUserId() + ConstantsValues.SUCCESSSTATUS);
		} catch (SQLException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			resMessageDto.setMessage("Not able to fetch User Details ,please contact the Administrator!");
			return resMessageDto;
		} finally {

			if (ps != null) {
				try {
					ps.close();
					ps = null;
				} catch (SQLException e) {
				}
			}
			if (con != null) {
				try {
					con.close();
					con = null;
				} catch (SQLException e) {
				}
			}
			  slf4jLogger.info("addUser method ended");

		}
		resMessageDto.setMessage("The User with ID " + userDto.getUserId() + " has been created.");
		return resMessageDto;
	}

	public ResMessageDto updateUser(UserDto userDto) {
		slf4jLogger.info("updateUser method started");
		Connection con = null;
		ResMessageDto resMessageDto = new ResMessageDto();
		PreparedStatement ps = null;
		PreparedStatement ps1 = null;
		PreparedStatement ps2 = null;
		String updateUserQuery = "";
		if(userDto.getDefault_p().equalsIgnoreCase("Y")){
			updateUserQuery = "UPDATE USER SET FirstName =?, LastName =?,  EmailID =?,  RoleID =?, Status =?, ValidFrom =?, ValidTo =?, ACCLOCKED = ?, ATTEMPTS = ?, DEFAULT_P = ?, PASSWORD =? WHERE UserID = ?";
		}
		else{
			updateUserQuery = "UPDATE USER SET FirstName =?, LastName =?,  EmailID =?,  RoleID =?, Status =?, ValidFrom =?, ValidTo =?, ACCLOCKED = ?, ATTEMPTS = ?, DEFAULT_P = ? WHERE UserID = ?";
		}
		String updatedefaultPwd = "UPDATE USER SET PASSWORD = ? WHERE USERID = ?";
		String updateSecQA = "DELETE FROM SECURITYANSWER WHERE USERID = ?";
		String validFrom = userDto.getValidFrom();
		String validTo = userDto.getValidTo();
		Timestamp validFromTs = null;
		Timestamp validToTs = null;
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS");
			Date parsedDate = dateFormat.parse(validFrom);
			validFromTs = new Timestamp(parsedDate.getTime());
			parsedDate = dateFormat.parse(validTo);
			validToTs = new Timestamp(parsedDate.getTime());
		} catch (Exception e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}

		try {
			con =  DBConnection.createConnection();
			ps =  con.prepareStatement(updateUserQuery);
			
			ps.setString(1, userDto.getFirstName());
			ps.setString(2, userDto.getLastName());
			ps.setString(3, userDto.getEmail());
			ps.setString(4, userDto.getRole());
			ps.setString(5, userDto.getStatus());
			ps.setTimestamp(6, validFromTs);
			ps.setTimestamp(7, validToTs);
			//ps.setString(8, userDto.getPassword());
			ps.setString(8, userDto.getAccLocked());
			ps.setInt(9, userDto.getInvalidAttempt());
			ps.setString(10, userDto.getDefault_p());
			if(userDto.getDefault_p().equalsIgnoreCase("Y")){
				ps.setString(11, UserDao.getReHashedPassword(userDto.getPassword()));
				ps.setString(12, userDto.getUserId());
			}else{
			ps.setString(11, userDto.getUserId());
			}
			ps.execute();
			//slf4jLogger.error(userDto.getDefault_p());
			if(userDto.getDefault_p() != null && userDto.getDefault_p().equals("Y")){
		
				ps2 =  con.prepareStatement(updateSecQA);
				ps2.setString(1, userDto.getUserId());
				ps2.execute();
				
				
			}
		} catch (SQLException e) {
			resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			resMessageDto.setMessage("Not able to update User Details ,please contact the Administrator!");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		} finally {

			if (ps != null) {
				try {
					ps.close();
					ps = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}

			if (con != null) {
				try {
					con.close();
					con = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("updateUser method ended");

		}
		resMessageDto.setMsgType(ConstantsValues.SUCCESSSTATUS);
		resMessageDto.setMessage("UserID "+userDto.getUserId()+" details are updated Successfully");
		return resMessageDto;
	}
	
	public ResMessageDto removeUser(List<String> list){
		slf4jLogger.info("removeUser method started");
		Connection con = null;
		PreparedStatement pStmt = null;
		ResMessageDto resMessageDto = new ResMessageDto();
		int length = list.size();

		if (length == 0) {
			resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			resMessageDto.setMessage("UserId required to delete the User details");
			return resMessageDto;
		}
		StringBuilder query = new StringBuilder("UPDATE USER SET Status = ? where UserID in (");
	
		for(int i=0;i<length;i++){
			if(i==length-1)
				query.append("?)");
			else
				query.append("?,");
			
		}
		try {

			con =  DBConnection.createConnection();
			pStmt = con.prepareStatement(query.toString());
			pStmt.setString(1, ConstantsValues.INACTIVESTATUS);
			 int pos = 2;
			    for(int i=0;i<length;i++,pos++){
			    	pStmt.setString (pos, list.get(i));				
				}
			pStmt.execute();
		} catch (SQLException e) {
			resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			resMessageDto.setMessage("Not able to delete User Details ,please contact the Administrator!");
		} finally {

			if (pStmt != null) {
				try {
					pStmt.close();
					pStmt = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}

			if (con != null) {
				try {
					con.close();
					con = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("removeUser method ended");

		}
		resMessageDto.setMsgType(ConstantsValues.SUCCESSSTATUS);
		resMessageDto.setMessage("The selected User details are made InActive");
		return resMessageDto;

	}

	public boolean ifExists(String userId) {
		slf4jLogger.info("ifExists method started");
		Connection con = null;
		ResultSet rs = null;
		PreparedStatement pStmt = null;
		try {
			con = DBConnection.createConnection();
			pStmt =  con.prepareStatement("select UserID from user where UserID= ?");
			pStmt.setString(1, userId);
			rs = pStmt.executeQuery();
			if (rs.next()) {
					return true;			
			}
		} catch (SQLException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		} finally {

			if (rs != null) {
				try {
					rs.close();
					rs = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}

			if (pStmt != null) {
				try {
					pStmt.close();
					pStmt = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}

			if (con != null) {
				try {
					con.close();
					con = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("ifExists method ended");

		}
		return false;
	}
	
	public DataStatusDto validateUser(String userId){
		slf4jLogger.info("validateUser method started");
		Connection con = null;
		ResultSet rs=null;
		PreparedStatement pStmt=null;
		DataStatusDto dataStatusDto = new DataStatusDto();
		ResMessageDto resMessageDto = new ResMessageDto();
		dataStatusDto.setResMessageDto(resMessageDto);
		try {
			con =  DBConnection.createConnection();
			pStmt = con.prepareStatement("select UserID from user where UserID= ?");
			pStmt.setString(1, userId);
			rs = pStmt.executeQuery();
			if (rs.next()) {
				dataStatusDto.setDataStatus(true);
				dataStatusDto.getResMessageDto().setMsgType(ConstantsValues.SUCCESSSTATUS);
				return dataStatusDto;
			}
		} catch (SQLException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		} finally {

			if (rs != null) {
				try {
					rs.close();
					rs = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}

			if (pStmt != null) {
				try {
					pStmt.close();
					pStmt = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}

			if (con != null) {
				try {
					con.close();
					con = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("validateUser method ended");

		}
		dataStatusDto.setDataStatus(false);
		dataStatusDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);

		return dataStatusDto;
	}

	public CustomResDto displayUserIds() {
		slf4jLogger.info("displayUserIds method started");
		CustomResDto resDto = new CustomResDto();
		ResMessageDto resMessageDto = new ResMessageDto();
		resDto.setResMessageDto(resMessageDto);
		ResultSet rs = null;
		PreparedStatement pStmt = null;
		boolean status = false;
		List<String> userIds;
		Connection con = null;
		try {
			con =  DBConnection.createConnection();
			userIds = new ArrayList<>();
			pStmt = con.prepareStatement("SELECT USERID FROM USER");
			rs = pStmt.executeQuery();
			while (rs.next()) {
				status = true;
				userIds.add(rs.getString("USERID"));
			}
			resDto.setDataList(userIds);
			if (!status){
				resDto.getResMessageDto().setMessage("No Users are Registered!");
				slf4jLogger.error("No Users are Registered!");
				resDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
			}
		} catch (SQLException e) {
			resDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
			resDto.getResMessageDto().setMessage("Not able to fetch Users ,please contact the Administrator!");
		} finally {
			if (rs != null) {
				try {
					rs.close();
					rs = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if (pStmt != null) {
				try {
					pStmt.close();
					pStmt = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}

			if (con != null) {
				try {
					con.close();
					con = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("displayUserIds method ended");

		}

		return resDto;
	}

	
    
    public static String getReHashedPassword(String passwordToHash){
        Logger slf4jLogger = LoggerFactory.getLogger(UserDao.class);
		slf4jLogger.info("getReHashedPassword method started");

    	String generatedPassword = null;

    	    try {
    	    		MessageDigest digest = MessageDigest.getInstance("SHA-256");
    	            byte[] hashedBytes = digest.digest(passwordToHash.getBytes("UTF-8"));
    	 
    	            return convertByteArrayToHexString(hashedBytes);
    	        } 
    	       catch (NoSuchAlgorithmException e){
    	        slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
    	       } catch (UnsupportedEncodingException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
    	finally{		
    		  slf4jLogger.info("getReHashedPassword method ended");
    	}

    	    return generatedPassword;
    	}
    
    private static String convertByteArrayToHexString(byte[] arrayBytes) {
        StringBuffer stringBuffer = new StringBuffer();
        for (int i = 0,arrLen = arrayBytes.length; i < arrLen; i++) {
            stringBuffer.append(Integer.toString((arrayBytes[i] & 0xff) + 0x100, 16)
                    .substring(1));
        }
        return stringBuffer.toString();
    }
public UserActiveResDtoList activeUsersList(String fromDate){
	
	slf4jLogger.info("getActionids method started");
	UserActiveResDto useractiveresdto = null;
	ArrayList<UserActiveResDto> list = null;
	UserActiveResDtoList list1 = new UserActiveResDtoList();
	ResMessageDto resMessageDto = new ResMessageDto();
	list1.setResMessageDto(resMessageDto);
	PropMappings propObj = PropMappings.getInstance();
	/*useractiveresdto.setResMessageDto(resMessageDto);*/
	Connection dbConnection = null;
	ResultSet resultSet = null;
	PreparedStatement pStmt = null;
	boolean status = false;
	try {
		dbConnection = DBConnection.createConnection();
		//pStmt = dbConnection.prepareStatement("select a.userid,a.createddate,b.projectname,c.firstname,c.lastname,c.ValidTo from configtransaction a,userprojects b,user c  where a.omid=b.omid and a.userid=c.userid and a.createddate>=NOW()-INTERVAL 3 month group by userid");
		if(propObj.getValue("S4CONFIGHANA_DB").equals("SAPHANA")){
		
			//pStmt =  dbConnection.prepareStatement("select a.userid,max(a.createddate) createddate,b.projectname,c.firstname,c.lastname,to_char(c.ValidTo,'dd-mon-yyyy') validTo from configtransaction a,userprojects b, user c  where a.omid=b.omid and a.createddate >='" + fromDate + "' and a.createddate <= current_date and a.userid=c.userid Group by a.userid,b.projectname,c.firstname,c.lastname,C.VALIDTO order by projectname");
					// "select distinct a.userid, to_char(a.createddate,'dd-mon-yyyy') createddate,b.projectname,c.firstname,c.lastname,to_char(c.ValidTo,'dd-mon-yyyy') validTo from configtransaction a,userprojects b, user c  where a.omid=b.omid and a.createddate >= add_months(current_date, -3) and a.userid=c.userid");
			pStmt=dbConnection.prepareStatement("select a.userid,max(a.createddate),b.projectname,c.firstname,c.lastname,to_char(c.ValidTo,'dd-mon-yyyy') validTo from configtransaction a,userprojects b, user c where a.omid=b.omid and a.createddate >='"+ fromDate +"' and a.createddate <= current_date and a.userid=c.userid Group by a.userid,b.projectname,c.firstname,c.lastname,C.VALIDTO order by projectname");
    	}
    	else{
    		
    		pStmt =  dbConnection.prepareStatement("select a.userid,a.createddate,b.projectname,c.firstname,c.lastname,c.ValidTo from configtransaction a,userprojects b,user c where a.omid=b.omid and a.userid=c.userid and  a.createddate >= '" + fromDate + "' and a.createddate <=current_date group by userid");
    		
    		}	
		resultSet = pStmt.executeQuery();
		
		list = new ArrayList<UserActiveResDto>();
		while(resultSet.next()){
			status=true;
			useractiveresdto=new UserActiveResDto();
			useractiveresdto.setUserId(resultSet.getString(1));
			slf4jLogger.error(resultSet.getString(1));
			//SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			//String parsedDate = dateFormat.format(resultSet.getString(2));
			useractiveresdto.setCreatedDate(resultSet.getString(2));
			
		    useractiveresdto.setProjectName(resultSet.getString(3));
			useractiveresdto.setFirstName(resultSet.getString(4));
			useractiveresdto.setLastName(resultSet.getString(5));
			//String validdateto = dateFormat.format(resultSet.getDate(6));
			useractiveresdto.setValidto(resultSet.getString(6));
			list.add(useractiveresdto);
		}
		list1.setUserList(list);
		if (!status) {
			
			resMessageDto.setMessage(ConstantsValues.NORECORDSEXISTS);
			resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
		}else{
			resMessageDto.setMessage(ConstantsValues.SUCCESSSTATUS);
			resMessageDto.setMsgType(ConstantsValues.SUCCESSSTATUS);
		}
		
		}catch (SQLException e) {
			resMessageDto.setMessage(ConstantsValues.EXCEPTIONDETAILS);
			resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			
		} finally {
			if (resultSet != null) {
				try {
					resultSet.close();
					resultSet = null;
				} catch (SQLException e) {
					resMessageDto.setMessage(ConstantsValues.EXCEPTIONDETAILS);
					resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if (pStmt != null) {
				try {
					pStmt.close();
					pStmt = null;
				} catch (SQLException e) {
					resMessageDto.setMessage(ConstantsValues.EXCEPTIONDETAILS);
					resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}

			if (dbConnection != null) {
				try {
					dbConnection.close();
					dbConnection = null;
				} catch (SQLException e) {
					resMessageDto.setMessage(ConstantsValues.EXCEPTIONDETAILS);
					resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("displayUserIds method ended");

		}
	list1.setResMessageDto(resMessageDto);
	return list1;
	
}

}
