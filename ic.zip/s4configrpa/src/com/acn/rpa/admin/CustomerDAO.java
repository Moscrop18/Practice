
package com.acn.rpa.admin;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.reports.EffortSaveGraphResDto;
import com.acn.rpa.reports.EffortSaveResDto;
import com.acn.rpa.reports.EffortSavingDataResDto;
import com.acn.rpa.service.AdminService;
import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.DBConnection;
import com.acn.rpa.utilities.PropMappings;
import com.acn.user.session.CustomResDto;
import com.acn.user.session.CustomerInputDto;
import com.acn.user.session.CustomerListDto;
import com.acn.user.session.DataStatusDto;
import com.acn.user.session.ResMessageDto;

public class CustomerDAO { 
    private final Logger slf4jLogger = LoggerFactory.getLogger(CustomerDAO.class);

	public ResMessageDto createCustomer(CustomerDto customer)   {
		slf4jLogger.info("createCustomer method started");
		ResMessageDto resMessageDto = new ResMessageDto();
		if(ifExists(customer.getOmId())){
			resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			resMessageDto.setMessage(ConstantsValues.OMIDIDEXISTS);
			return resMessageDto;
			}
		PreparedStatement preparedStmt =  null; 
		Connection con = null;
		String query="INSERT INTO CUSTOMER(CustomerName,IndustryVertical,GeographicRegion,DeliveryUnit,IGPOC,GDNOGLEAD,Status,CustomerType,OMID,ProjectName,build_time) VALUES(?,?,?,?,?,?,?,?,?,?,?)";
		try{
			con =  DBConnection.createConnection();
			preparedStmt = con.prepareStatement(query);
			preparedStmt.setString (1, customer.getCustomerName());
		    preparedStmt.setString (2, customer.getIndustryVertical());
		    preparedStmt.setString (3, customer.getGeographicRegion());
		    preparedStmt.setString (4, customer.getDeliveryUnit());
		    preparedStmt.setString (5, customer.getIgPoc());
		    preparedStmt.setString (6, customer.getGdn_ogLead());
		    preparedStmt.setString (7, ConstantsValues.ACTIVESTATUS);
		    preparedStmt.setString (8, customer.getCustomerType());
		    preparedStmt.setString (9, customer.getOmId());
		    preparedStmt.setString (10, customer.getProjectName());
		    preparedStmt.setString (11, customer.getBuildtime());
		    preparedStmt.executeUpdate();
			}catch(Exception e){
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
				resMessageDto.setMessage(ConstantsValues.DATABASEERROR);
			}finally {
				if (preparedStmt != null) {
		            try {
		            	preparedStmt.close();
		            	preparedStmt = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }

		        if (con != null) {
		            try {
		            	con.close();
		            	con = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
				  slf4jLogger.info("createCustomer method ended");
				
			}
		resMessageDto.setMsgType(ConstantsValues.SUCCESSSTATUS);
		resMessageDto.setMessage("The Customer with OmId " + customer.getOmId() + " has been created.");
		return resMessageDto;
	}
	
	
	public ResMessageDto modifyCustomer(CustomerDto customer)  {
		slf4jLogger.info("modifyCustomer method started");
		ResMessageDto resMessageDto = new ResMessageDto();
		if(customer.getOmId() == null || customer.getOmId().trim().length() <= 0 ){
			resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			resMessageDto.setMessage(ConstantsValues.OMIDREQUIRED);
			return resMessageDto;
			}
		PreparedStatement preparedStmt =  null; 
		Connection con = null;
		String query="UPDATE CUSTOMER SET CustomerName = ?, IndustryVertical = ?, GeographicRegion = ?, DeliveryUnit = ?, IGPOC = ?, GDNOGLEAD = ?, Status = ?, CustomerType = ?, ProjectName = ?, OMID = ?,build_time=? WHERE OMID=?";
		boolean flag = false;
		try{
			con = DBConnection.createConnection();
			preparedStmt = con.prepareStatement(query);
			preparedStmt.setString (1, customer.getCustomerName());
		    preparedStmt.setString (2, customer.getIndustryVertical());
		    preparedStmt.setString (3, customer.getGeographicRegion());
		    preparedStmt.setString (4, customer.getDeliveryUnit());
		    preparedStmt.setString (5, customer.getIgPoc());
		    preparedStmt.setString (6, customer.getGdn_ogLead());
		    preparedStmt.setString (7, customer.getStatus());
		    preparedStmt.setString (8, customer.getCustomerType());
		    preparedStmt.setString (9, customer.getProjectName());
		    preparedStmt.setString (10, customer.getOmId());
		    preparedStmt.setString (11, customer.getBuildtime());
		    preparedStmt.setString (12, customer.getOmIdOld());

		    preparedStmt.executeUpdate();
		    if(!customer.getOmId().equals(customer.getOmIdOld())){
		    	resMessageDto = updateCustomerId(customer);
			}

			} catch (Exception e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				flag = true;
				resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
				resMessageDto.setMessage(ConstantsValues.DATABASEERROR);
				
			}finally {
				if (preparedStmt != null) {
		            try {
		            	preparedStmt.close();
		            	preparedStmt = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }

		        if (con != null) {
		            try {
		            	con.close();
		            	con = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
				  slf4jLogger.info("modifyCustomer method ended");

				
			}
		if(!flag){
			resMessageDto.setMsgType(ConstantsValues.SUCCESSSTATUS);
			resMessageDto.setMessage("The Customer with OmId-"+customer.getOmId()+" has been updated ");
		}
		
		return resMessageDto;
	}
	public ResMessageDto deleteCustomer(List<String> omIds)  {
		slf4jLogger.info("deleteCustomer method started");
		ResMessageDto resMessageDto = new ResMessageDto();
		int length = omIds.size();

		if(omIds.isEmpty()){
			resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			resMessageDto.setMessage(ConstantsValues.OMIDREQUIRED);
			return resMessageDto;
			}
		PreparedStatement preparedStmt =  null;
		Connection con = null;
		StringBuilder query=new StringBuilder("UPDATE CUSTOMER SET STATUS=? WHERE OMID in (");

		
		for(int i=0;i<length;i++){
			if(i==length-1)
				query.append("?)");
			else
				query.append("?,");
			
		}
		try{
			con =  DBConnection.createConnection();
			preparedStmt = con.prepareStatement(query.toString());
			preparedStmt.setString (1, ConstantsValues.INACTIVESTATUS);
		    int pos = 2;
		    for(int i=0;i<length;i++,pos++){
		    	preparedStmt.setString (pos, omIds.get(i));				
			}
		    preparedStmt.execute();			
			} catch (Exception e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
				resMessageDto.setMessage(ConstantsValues.DATABASEERROR);
			}finally {
				if (preparedStmt != null) {
		            try {
		            	preparedStmt.close();
		            	preparedStmt = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }

		        if (con != null) {
		            try {
		            	con.close();
		            	con = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
				  slf4jLogger.info("deleteCustomer method ended");

			}

		resMessageDto.setMsgType(ConstantsValues.SUCCESSSTATUS);
		resMessageDto.setMessage(ConstantsValues.INACTIVESUCCESS);
		return resMessageDto;
	}
	
	public CustomerListDto getAllCustomers(CustomerInputDto customerInputDto)  {
		slf4jLogger.info("getAllCustomers method started");
		CustomerListDto resDto = new CustomerListDto();
		ResMessageDto resMessageDto = new ResMessageDto();
		resDto.setResMessageDto(resMessageDto);
		List<CustomerDto> customers = new ArrayList<>();
		ResultSet rs=null;
		PreparedStatement pStmt=null;
		CustomerDto clientDto;
		boolean status = false;
		Connection con = null;
		try{
			con = DBConnection.createConnection();
			if(customerInputDto.getUserRole().equals(ConstantsValues.TOOLADMIN)){
				pStmt =  con.prepareStatement("SELECT * FROM CUSTOMER");
			}
			else if(customerInputDto.getUserRole().equals(ConstantsValues.PROJECTADMIN)){
				pStmt =  con.prepareStatement("SELECT * FROM CUSTOMER WHERE OMID IN (SELECT OMID FROM USERPROJECTS WHERE USERID=?)");
				pStmt.setString(1, customerInputDto.getUserID());
			}
				rs = pStmt.executeQuery();
			while(rs.next()){
				status = true;
				clientDto = new CustomerDto();
				clientDto.setCustomerName(rs.getString("CUSTOMERNAME"));
				clientDto.setIndustryVertical(rs.getString("INDUSTRYVERTICAL"));
				clientDto.setGeographicRegion(rs.getString("GEOGRAPHICREGION"));
				clientDto.setDeliveryUnit(rs.getString("DELIVERYUNIT"));
				clientDto.setCustomerType(rs.getString("CUSTOMERTYPE"));
				clientDto.setIgPoc(rs.getString("IGPOC"));
				clientDto.setGdn_ogLead(rs.getString("GDNOGLEAD"));
				clientDto.setOmId(rs.getString("OMID"));
				clientDto.setProjectName(rs.getString("ProjectName"));
				clientDto.setStatus(rs.getString("STATUS"));
				clientDto.setTrOverride(rs.getString("TROverRide")); //Changed on dec 7 for TR Changes.
				//Added by Veena
				clientDto.setCustDestReq(rs.getString("cust_Destreq"));
				clientDto.setBuildtime(rs.getString("build_time"));
//				if( rs.getString("cust_Destreq") == "Y"){
//					clientDto.setCustDestReq("Y");
//				}
//				else
//					clientDto.setCustDestReq("N");
//				System.out.println("cust_Destreq-----"+rs.getString("cust_Destreq"));
				//Ended by Veena
				customers.add(clientDto);
			}
			
			if(!status){
				resDto.getResMessageDto().setMessage(ConstantsValues.NORECORDSEXISTS);
				slf4jLogger.error(ConstantsValues.NORECORDSEXISTS);
				resDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
			}
			else{
				resDto.setCustomerList(customers);
			}
		}
		catch (SQLException e){
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			resDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
			resDto.getResMessageDto().setMessage(ConstantsValues.DATABASEERROR);
		}finally{
		    if (rs != null) {
	            try {
	            	rs.close();
	            	rs = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }
			if (pStmt != null) {
	            try {
	            	pStmt.close();
	            	pStmt = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }

	        if (con != null) {
	            try {
	            	con.close();
	            	con = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }
			  slf4jLogger.info("getAllCustomers method ended");

		}	
		resDto.getResMessageDto().setMsgType(ConstantsValues.SUCCESSSTATUS);
		return resDto; 
	}
	
	public CustomResDto displayClientIds()  {
		slf4jLogger.info("displayClientIds method started");
		ResultSet rs=null; 
		PreparedStatement pStmt=null;
		boolean status = false;
		List<String> customerIds;
		Connection con = null;
		CustomResDto resDto = new CustomResDto();
		ResMessageDto resMessageDto = new ResMessageDto();
		resDto.setResMessageDto(resMessageDto);
		try{
			con = DBConnection.createConnection();
			customerIds = new ArrayList<>();
			pStmt =  con.prepareStatement("SELECT OMID FROM CUSTOMER");
			rs = pStmt.executeQuery();
			while(rs.next()){
				status = true;
				customerIds.add(rs.getString("OMID"));	
			}
			resDto.setDataList(customerIds);	
			if(!status){
				resDto.getResMessageDto().setMessage(ConstantsValues.NORECORDSEXISTS);
				slf4jLogger.error(ConstantsValues.NORECORDSEXISTS);
				resDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
			}
		}
		catch (SQLException e){
			resDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
			resDto.getResMessageDto().setMessage(ConstantsValues.DATABASEERROR);
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}finally{
		    if (rs != null) {
	            try {
	            	rs.close();
	            	rs = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }
			if (pStmt != null) {
	            try {
	            	pStmt.close();
	            	pStmt = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }

	        if (con != null) {
	            try {
	            	con.close();
	            	con = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }
			
			  slf4jLogger.info("displayClientIds method ended");

		}	
		
		return resDto;
	}
	
	public boolean ifExists(String omId){
		slf4jLogger.info("ifExists method started");
		Connection con = null;
		ResultSet rs=null;
		PreparedStatement pStmt=null;
		try{
			con =  DBConnection.createConnection();
			pStmt = con.prepareStatement("select OMID from Customer where OMID= ?");
			pStmt.setString(1, omId);
			rs = pStmt.executeQuery();
			return (rs.next() && rs.getString("OMID").equals(omId));
		}
		catch (SQLException e){
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}
		finally{
			if(rs!=null){
				try {
					rs.close();
					rs = null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if (pStmt != null) {
	            try {
	            	pStmt.close();
	            	pStmt = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }
			if(con!=null){
				try {
					con.close();
					con = null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("ifExists method ended");

			
		}
		return false;
	}
	
	public CustomResDto displayProjectNames(CustomerInputDto userDto)  {
		slf4jLogger.info("displayProjectNames method started");
		ResultSet rs=null; 
		PreparedStatement pStmt=null;
		boolean status = false;
		List<String> customerIds;
		Connection con = null;
	  	String dbName = null;
	  	CustomResDto resDto = new CustomResDto();
	  	ResMessageDto resMessageDto = new ResMessageDto();
	  	resDto.setResMessageDto(resMessageDto);
		try{
			
	    	PropMappings propObj = PropMappings.getInstance();
			dbName = propObj.getValue("S4CONFIGHANA_DB");
			con = DBConnection.createConnection();
			customerIds = new ArrayList<>();
			if(dbName.equals("SAPHANA")){
				if(userDto.getUserRole().equals(ConstantsValues.TOOLADMIN)){
					pStmt =  con.prepareStatement("SELECT OMID||'-'||PROJECTNAME PROJECTNAME FROM CUSTOMER");
				}else{
					pStmt =  con.prepareStatement("SELECT OMID||'-'||PROJECTNAME PROJECTNAME FROM CUSTOMER WHERE OMID IN (SELECT OMID FROM USERPROJECTS WHERE USERID = ?)");
					pStmt.setString(1,userDto.getUserID());
				}

			}else{
				if(userDto.getUserRole().equals(ConstantsValues.TOOLADMIN)){
					pStmt =  con.prepareStatement("SELECT CONCAT(OMID,'-',PROJECTNAME) PROJECTNAME FROM CUSTOMER");
				}else{
					pStmt =  con.prepareStatement("SELECT CONCAT(OMID,'-',PROJECTNAME) PROJECTNAME FROM CUSTOMER WHERE OMID IN (SELECT OMID FROM USERPROJECTS WHERE USERID =?)");
					pStmt.setString(1,userDto.getUserID());
				}
			}

			rs = pStmt.executeQuery();
			while(rs.next()){
				status = true;
				customerIds.add(rs.getString("PROJECTNAME"));	
			}
			resDto.setDataList(customerIds);	
			if(!status){
				resDto.getResMessageDto().setMessage(ConstantsValues.NORECORDSEXISTS);
				slf4jLogger.error(ConstantsValues.NORECORDSEXISTS);
				resDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
			}
		}
		catch (SQLException e){
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			resDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
			resDto.getResMessageDto().setMessage(ConstantsValues.DATABASEERROR);
		}finally{
			dbName = null;
		    if (rs != null) {
	            try {
	            	rs.close();
	            	rs = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }
			if (pStmt != null) {
	            try {
	            	pStmt.close();
	            	pStmt = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }

	        if (con != null) {
	            try {
	            	con.close();
	            	con = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }
			  slf4jLogger.info("displayProjectNames method ended");

		}	
		
		return resDto;
	}
	
	public DataStatusDto  validateCustomerId(String omId){
		slf4jLogger.info("validateCustomerId method started");
		Connection con = null;
		ResultSet rs=null;
		PreparedStatement pStmt=null;
		DataStatusDto resDto = new DataStatusDto();
		ResMessageDto resMessageDto = new ResMessageDto();
		resDto.setResMessageDto(resMessageDto);
		resDto.setDataStatus(false);
		resDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);

		try{
			con = DBConnection.createConnection();
			pStmt =  con.prepareStatement("select OMID from Customer where OMID= ?");
			pStmt.setString(1,omId);
			rs = pStmt.executeQuery();
			if(rs.next()){
					resDto.setDataStatus(true);
					resDto.getResMessageDto().setMsgType(ConstantsValues.SUCCESSSTATUS);
					return resDto;
			}
		}
		catch (SQLException e){
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}
		finally{
			if(rs!=null){
				try {
					rs.close();
					rs = null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt = null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			if(con!=null){
				try {
					con.close();
					con = null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("validateCustomerId method ended");

			
		}
		return resDto;
	}
	public ResMessageDto updateCustomerId(CustomerDto customer)  {
		slf4jLogger.info("updateCustomerId method started");
		ResMessageDto resMessageDto = new ResMessageDto();
		PreparedStatement preparedStmt =  null; 
		PreparedStatement preparedStmt1 =  null; 
		PreparedStatement preparedStmt2 =  null;  

		Connection con = null;
		
		try{
				con =  DBConnection.createConnection();
				preparedStmt = con.prepareStatement("UPDATE SAPSYSTEM SET OMID=? WHERE OMID=?");
				preparedStmt.setString (1, customer.getOmId());
				preparedStmt.setString (2, customer.getOmIdOld());
				preparedStmt.executeUpdate();
				
				preparedStmt1 = con.prepareStatement("UPDATE USERPROJECTS SET OMID=? WHERE OMID=?");
				preparedStmt1.setString (1, customer.getOmId());
				preparedStmt1.setString (2, customer.getOmIdOld());
				preparedStmt1.executeUpdate();
				
				preparedStmt2 = con.prepareStatement("UPDATE CONFIGTRANSACTION SET OMID=? WHERE OMID=?");
				preparedStmt2.setString (1, customer.getOmId());
				preparedStmt2.setString (2, customer.getOmIdOld());
				preparedStmt2.executeUpdate();
			 
			} catch (Exception e) {
				resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
				resMessageDto.setMessage(ConstantsValues.DATABASEERROR);
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}finally {
				if (preparedStmt != null) {
		            try {
		            	preparedStmt.close();
		            	preparedStmt = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
				if (preparedStmt1 != null) {
		            try {
		            	preparedStmt1.close();
		            	preparedStmt1 = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
				if (preparedStmt2 != null) {
		            try {
		            	preparedStmt2.close();
		            	preparedStmt2 = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
				
		        if (con != null) {
		            try {
		            	con.close();
		            	con = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
				  slf4jLogger.info("updateCustomerId method ended");
   
				
			}
		
		resMessageDto.setMsgType(ConstantsValues.SUCCESSSTATUS);
		resMessageDto.setMessage("The Customer ID " + customer.getOmId() + " has been updated in all Respective tables");
		return resMessageDto;
	}
	
	//Added by Veena
	
	public ResMessageDto updateCustomDestination(List<String> omIds,String custDestReq)  {
		slf4jLogger.info("deleteCustomer method started");
		ResMessageDto resMessageDto = new ResMessageDto();
		int length = omIds.size();
		 int count = 0;

		if(omIds.isEmpty()){
			resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			resMessageDto.setMessage(ConstantsValues.OMIDREQUIRED);
			return resMessageDto;
			}
		PreparedStatement preparedStmt =  null;
		Connection con = null;
		StringBuilder query=new StringBuilder("UPDATE CUSTOMER SET cust_DestReq=? WHERE OMID in (");

		for(int i=0;i<length;i++){
			if(i==length-1)
				query.append("?)");
			else
				query.append("?,");
			
		}
		try{
			con =  DBConnection.createConnection();
			preparedStmt = con.prepareStatement(query.toString());
			//preparedStmt.setString (1, ConstantsValues.INACTIVESTATUS);
			preparedStmt.setString (1, custDestReq);
		    int pos = 2;
		    for(int i=0;i<length;i++,pos++){
		    	preparedStmt.setString (pos, omIds.get(i));				
			}
		     count = preparedStmt.executeUpdate();			
			} catch (Exception e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
				resMessageDto.setMessage(ConstantsValues.DATABASEERROR);
			}finally {
				if (preparedStmt != null) {
		            try {
		            	preparedStmt.close();
		            	preparedStmt = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }

		        if (con != null) {
		            try {
		            	con.close();
		            	con = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
				  slf4jLogger.info("deleteCustomer method ended");

			}
      //  if( count >0){
		resMessageDto.setMsgType(ConstantsValues.SUCCESSSTATUS);
		resMessageDto.setMessage(ConstantsValues.CUST_DEST_REQ);
      //  }
//        else{
//        	resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
//    		resMessageDto.setMessage(ConstantsValues.CUST_DEST_REQ_E);
//        }
		return resMessageDto;
	}
	public EffortSavingDataResDto getEffortSavingData(String custOmid)  {
		slf4jLogger.info("getEffortSavingData method started");
		ResultSet rs=null; 
		ResultSet rs1=null;
		PreparedStatement pStmt=null;
		PreparedStatement pStmt1 = null;
		boolean status = false;
		//List<String> customerIds;
		Connection con = null;
	  	String dbName = null;
	  	//CustomResDto resDto = new CustomResDto();
	  	EffortSavingDataResDto responseDto1 = new EffortSavingDataResDto();
	  	EffortSaveGraphResDto effortsaveAllProj;
	  	ArrayList<EffortSaveResDto> projectData = new ArrayList<>();
	  	ArrayList<EffortSaveGraphResDto> allProjectData = new ArrayList<>();
	  	EffortSaveResDto responseDto;
	  	ResMessageDto resMessageDto = new ResMessageDto();
	  	responseDto1.setResMessageDto(resMessageDto);
		try{
			
	    	PropMappings propObj = PropMappings.getInstance();
			dbName = propObj.getValue("S4CONFIGHANA_DB");
			con = DBConnection.createConnection();
			//customerIds = new ArrayList<>();
			if(dbName.equals("SAPHANA")){
				
					//pStmt =  con.prepareStatement("select a.scenario,b.build_time,count(c.IMGID) AS IMGCount,To_INTEGER(SUM(SECONDS_BETWEEN(c.EXECUTIONSTARTTIME,c.EXECUTIONENDTIME))/3600) AS Totaltime from CONFIGUPLOADHISTORY c,CONFIGTRANSACTION a,CUSTOMER b where c.TRANSID = a.TRANSID and b.OMID = a.OMID and b.omid = ? group by a.scenario order by a.scenario asc");		
				pStmt =  con.prepareStatement("	select a.scenario,b.build_time,count(c.IMGID) AS IMGCount, " +
				"SUM(SECONDS_BETWEEN(c.executionstarttime,c.EXECUTIONENDTIME))/3600 as uploadtoatal, " +
				"SUM(SECONDS_BETWEEN(d.downloadSTARTTIME,d.downloadENDTIME))/3600 as downloadtotal, " +
				"To_INTEGER((SUM(SECONDS_BETWEEN(c.executionstarttime,c.EXECUTIONENDTIME))/3600) + " +
				 "(SUM(SECONDS_BETWEEN(d.downloadSTARTTIME,d.downloadENDTIME))/3600)) as TOTALTIME " +
				"from configuploadhistory c,CONFIGTRANSACTION a,CUSTOMER b,configdownloadhistory d " + 
				"where c.TRANSID = a.TRANSID and b.OMID = a.OMID and a.scenario != '' and b.OMID = ? group by a.scenario,b.build_time order by a.scenario asc ");
				
				pStmt.setString(1,custOmid);

				pStmt1 =  con.prepareStatement("select b.projectname,b.build_time, " +  
				"SUM(SECONDS_BETWEEN(c.executionstarttime,c.EXECUTIONENDTIME))/3600 as uploadtoatal, " +  
				"SUM(SECONDS_BETWEEN(d.downloadSTARTTIME,d.downloadENDTIME))/3600 as downloadtotal, " + 
				"To_INTEGER((SUM(SECONDS_BETWEEN(c.executionstarttime,c.EXECUTIONENDTIME))/3600) + " +  
				 "(SUM(SECONDS_BETWEEN(d.downloadSTARTTIME,d.downloadENDTIME))/3600)) as TOTALTIME " +  
				"from configuploadhistory c,CONFIGTRANSACTION a,CUSTOMER b,configdownloadhistory d " +   
				"where c.TRANSID = a.TRANSID and b.OMID = a.OMID group by b.build_time,b.projectname order by b.projectname asc");
				
				
			}else{		
				
					pStmt =  con.prepareStatement("select a.scenario,b.build_time,count(c.IMGID),sum(TIMESTAMPDIFF(SECOND,c.EXECUTIONSTARTTIME,c.EXECUTIONENDTIME)) AS Totaltime from configtransaction a,customer b, configuploadhistory c where c.TRANSID=a.TRANSID and b.OMID=a.OMID and b.OMID = ? group by a.scenario order by a.scenario asc");
					pStmt.setString(1,custOmid);
					
					pStmt1 =  con.prepareStatement("select b.projectname,b.build_time,count(c.IMGID),sum(TIMESTAMPDIFF(SECOND,c.EXECUTIONSTARTTIME,c.EXECUTIONENDTIME)) AS Totaltime from configtransaction a,customer b, configuploadhistory c where c.TRANSID=a.TRANSID and b.OMID=a.OMID group by b.projectname order by b.projectname asc");	
				
			}
			rs = pStmt.executeQuery();
			rs1 = pStmt1.executeQuery();
			while(rs.next()){
				 responseDto = new EffortSaveResDto();
				status = true;
				//customerIds.add(rs.getString("PROJECTNAME"));	
				responseDto.setImplType(rs.getString("SCENARIO"));
				responseDto.setTotalTime(rs.getString("TOTALTIME"));
				projectData.add(responseDto);
				responseDto1.setBuild_Time(rs.getString("BUILD_TIME"));
			}
			responseDto1.setConfigExecutionLogList(projectData);
			while(rs1.next()){
				effortsaveAllProj = new EffortSaveGraphResDto();
				//status = true;
				//customerIds.add(rs.getString("PROJECTNAME"));	
				effortsaveAllProj.setBuild_Time(rs1.getString("BUILD_TIME"));
				effortsaveAllProj.setProjectName(rs1.getString("PROJECTNAME"));
				effortsaveAllProj.setTotalTime(rs1.getString("TOTALTIME"));
			
				allProjectData.add(effortsaveAllProj);
				}
			responseDto1.setEffortSaveDataAllProj(allProjectData);
			//responseDto.setDataList(customerIds);	
			if(!status){
				responseDto1.getResMessageDto().setMessage(ConstantsValues.NORECORDSEXISTS);
				slf4jLogger.error(ConstantsValues.NORECORDSEXISTS);
				responseDto1.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
			}
			else{
				responseDto1.getResMessageDto().setMsgType(ConstantsValues.SUCCESSSTATUS);
				responseDto1.getResMessageDto().setMessage(ConstantsValues.SUCCESSSTATUS);
			}
		}
		catch (SQLException e){
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			responseDto1.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
			responseDto1.getResMessageDto().setMessage(ConstantsValues.DATABASEERROR);
		}finally{
			dbName = null;
		    if (rs != null) {
	            try {
	            	rs.close();
	            	rs = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }
			if (pStmt != null) {
	            try {
	            	pStmt.close();
	            	pStmt = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }

	        if (con != null) {
	            try {
	            	con.close();
	            	con = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }
			  slf4jLogger.info("getEffortSavingData method ended");

		}	
		
		return responseDto1;
	}
	
	//Ended by Veena
}
