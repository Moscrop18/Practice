package com.acn.rpa.helpDocuments;

import java.sql.Timestamp;

public class HelpDocResDTO {
	private String fileName;
	private Timestamp updatedDate;
	private String fileFormat;
	private byte[] docBytes;
	private String id;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public byte[] getDocBytes() {
		return docBytes;
	}

	public void setDocBytes(byte[] docBytes) {
		this.docBytes = docBytes;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public Timestamp getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Timestamp updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getFileFormat() {
		return fileFormat;
	}

	public void setFileFormat(String fileFormat) {
		this.fileFormat = fileFormat;
	}



}
