package com.acn.rpa.helpDocuments;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.chemistry.opencmis.client.api.Session;
import org.apache.poi.util.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.admin.UserDto;
import com.acn.rpa.docservice.HCPDocDAO;
import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.DBConnection;

public class HelpDocDAO {
    private final Logger slf4jLogger = LoggerFactory.getLogger(HelpDocDAO.class);

	public HelpDocResposneDTO retrieveHelpDocuments(UserDto userDto) {
		slf4jLogger.info("retrieveHelpDocuments method started");
		Connection con = null;
		List<HelpDocResDTO> responseList = new ArrayList<>();
		ResultSet rs=null;
		PreparedStatement pStmt=null;
		HelpDocResDTO helpDocResDTO = null;
		HelpDocResposneDTO helpDocResposneDTO = null;
		try{
				helpDocResposneDTO = new HelpDocResposneDTO();
				con = DBConnection.createConnection();
				if(userDto.getRole().equals(ConstantsValues.PROJECTADMIN)){
					pStmt = con.prepareStatement("SELECT A.ID,A.FILENAME,A.RECORDED_DATE,A.FILEFORMAT FROM DOCUMENTSTORE A where A.TEMPLATETYPE=? AND A.USERROLE IN (?,?)");
					pStmt.setString(1, ConstantsValues.HELPDOCUMENTS);
					pStmt.setString(2, ConstantsValues.CONFIG);
					pStmt.setString(3, ConstantsValues.PROJECTADMIN);
				}else if(userDto.getRole().equals(ConstantsValues.TOOLADMIN)){
					pStmt = con.prepareStatement("SELECT A.ID,A.FILENAME,A.RECORDED_DATE,A.FILEFORMAT FROM DOCUMENTSTORE A where A.TEMPLATETYPE=?");
					pStmt.setString(1, ConstantsValues.HELPDOCUMENTS);
				}
				else{
					pStmt = con.prepareStatement("SELECT A.ID,A.FILENAME,A.RECORDED_DATE,A.FILEFORMAT FROM DOCUMENTSTORE A where A.TEMPLATETYPE=? AND A.USERROLE = ?");
					pStmt.setString(1, ConstantsValues.HELPDOCUMENTS);
					pStmt.setString(2, ConstantsValues.CONFIG);
				}
				rs = pStmt.executeQuery();
				while(rs.next()){
					helpDocResDTO = new HelpDocResDTO();
					helpDocResDTO.setFileName(rs.getString("FILENAME"));
					helpDocResDTO.setId(rs.getString("ID"));
					helpDocResDTO.setUpdatedDate(rs.getTimestamp("RECORDED_DATE"));
					helpDocResDTO.setFileFormat(rs.getString("FILEFORMAT"));
					responseList.add(helpDocResDTO);
				}
				helpDocResposneDTO.setResponseList(responseList);
				
			}catch(Exception e){
				helpDocResposneDTO.setMessage(ConstantsValues.EXCEPTION);
				helpDocResposneDTO.setStatus(ConstantsValues.ERRORSTATUS);
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		
		finally{
			if(rs!=null){
				try {
					rs.close();
					rs= null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
		}
		return helpDocResposneDTO;
	}

	public HelpDocResposneDTO deleteHelpDocument(String id) {
		slf4jLogger.info("deleteHelpDocument method started");
		Connection con = null;
		PreparedStatement pStmt=null;
		Document document=null;
		HelpDocResposneDTO helpDocResposneDTO = null;
		
		try{
				helpDocResposneDTO = new HelpDocResposneDTO();
				con = DBConnection.createConnection();
				pStmt = con.prepareStatement("DELETE FROM DOCUMENTSTORE WHERE ID = ?");
				pStmt.setString(1, id);
				pStmt.executeUpdate();
				Session openCmisSession = HCPDocDAO.ConnectDocumentStore();
				document = (Document) openCmisSession.getObject(id);
			//document.delete();
				helpDocResposneDTO.setStatus(ConstantsValues.SUCCESSSTATUS);
				
			}catch(Exception e){
				helpDocResposneDTO.setMessage(ConstantsValues.EXCEPTION);
				helpDocResposneDTO.setStatus(ConstantsValues.ERRORSTATUS);
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		
		finally{
			
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("deleteHelpDocument method ended");

		}
		return helpDocResposneDTO;
	}
	
	public HelpDocResposneDTO getDocumentStream(String id) {
		slf4jLogger.info("getDocumentStream method started");
		HelpDocResposneDTO helpDocResposneDTO = null;
		byte[] bytes  = null;
		Document document=null;
		InputStream stream = null;
		try{
				helpDocResposneDTO = new HelpDocResposneDTO();
				Session openCmisSession = HCPDocDAO.ConnectDocumentStore();
				document = (Document) openCmisSession.getObject(id);
				stream = document.getContentStream().getStream();
				bytes = IOUtils.toByteArray(stream);				
				helpDocResposneDTO.setStatus(ConstantsValues.SUCCESSSTATUS);
				helpDocResposneDTO.setDocBytes(bytes);
				
			}catch(Exception e){
				helpDocResposneDTO.setMessage(ConstantsValues.EXCEPTION);
				helpDocResposneDTO.setStatus(ConstantsValues.ERRORSTATUS);
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		
		finally{
			  slf4jLogger.info("getDocumentStream method ended");

			
		}
		return helpDocResposneDTO;
	}
}
