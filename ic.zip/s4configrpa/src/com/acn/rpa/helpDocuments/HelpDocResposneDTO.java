package com.acn.rpa.helpDocuments;

import java.util.List;

public class HelpDocResposneDTO {
	private List<HelpDocResDTO> responseList; 
	private String status;
	private byte[] docBytes;

	public byte[] getDocBytes() {
		return docBytes;
	}
	public void setDocBytes(byte[] docBytes) {
		this.docBytes = docBytes;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public List<HelpDocResDTO> getResponseList() {
		return responseList;
	}
	public void setResponseList(List<HelpDocResDTO> responseList) {
		this.responseList = responseList;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	private String message;

}
