package com.acn.rpa.imghierarchy;

import java.util.List;

import com.acn.user.session.ResMessageDto;

public class ImgResponseDto {
	private List<ImgHierarchyDto> listImgHierarchyDto;
	private List<FieldMappingDto> listFieldMappingDto;
	private List<ImgFilterDataDTO> listImgFilterDataDTO;
	private List<String> listimgs;
	
public List<String> getListimgs() {
		return listimgs;
	}
	public void setListimgs(List<String> listimgs) {
		this.listimgs = listimgs;
	}
private ResMessageDto resMessageDto;

public ResMessageDto getResMessageDto() {
		return resMessageDto;
	}
public void setResMessageDto(ResMessageDto resMessageDto) {
		this.resMessageDto = resMessageDto;
	}
	public List<ImgFilterDataDTO> getListImgFilterDataDTO() {
		return listImgFilterDataDTO;
	}
	public void setListImgFilterDataDTO(List<ImgFilterDataDTO> listImgFilterDataDTO) {
		this.listImgFilterDataDTO = listImgFilterDataDTO;
	}
	public List<FieldMappingDto> getListFieldMappingDto() {
		return listFieldMappingDto;
	}
	public void setListFieldMappingDto(List<FieldMappingDto> listFieldMappingDto) {
		this.listFieldMappingDto = listFieldMappingDto;
	}
	private String status;
	private String message;
	public List<ImgHierarchyDto> getListImgHierarchyDto() {
		return listImgHierarchyDto;
	}
	public void setListImgHierarchyDto(List<ImgHierarchyDto> listImgHierarchyDto) {
		this.listImgHierarchyDto = listImgHierarchyDto;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}


}
