package com.acn.rpa.imghierarchy;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.DBConnection;
import com.acn.user.session.ResMessageDto;

public class UpdateManageTrDAO {
    private final Logger slf4jLogger = LoggerFactory.getLogger(UpdateManageTrDAO.class);

	public ResMessageDto updateTrData(CustomUpdateManageTrInDto customUpdateManageTrInDto){
		slf4jLogger.info("updateTrData method started");
		ResMessageDto resMessageDto = new ResMessageDto();
		PreparedStatement preparedStmt =  null; 
		UpdateProjectTRDAO updateProjectTRDAO = null;
		Connection con = null;
		String dbName = null;
		String query ="";
		InputStream input = null;
		try{
			input = DBConnection.class.getClassLoader().getResourceAsStream("config.properties");
		  	Properties prop = new Properties();
	  	prop.load(input);
		dbName = prop.getProperty("S4CONFIGHANA_DB");
		UpdateProjectTRDto updateProjectTRDto = new UpdateProjectTRDto();
		updateProjectTRDto.setTrOverrideFLag(customUpdateManageTrInDto.getTrOverrideFLag());
		updateProjectTRDto.setOmid(customUpdateManageTrInDto.getOmid());
		if(dbName.equals("SAPHANA")){
			query="UPSERT ClientSystemTrMapping (IMGAUTOID,SYSTEMID,CTR,KTR) VALUES (?,?,?,?) WHERE IMGAUTOID = ? and SYSTEMID = ?";
			updateProjectTRDAO = new UpdateProjectTRDAO();
			
			resMessageDto =updateProjectTRDAO.updateTROverRide(updateProjectTRDto);
			con =  DBConnection.createConnection();
			preparedStmt = con.prepareStatement(query);
			for(UpdateManageTrInDto updateManageTrInDtoObj: customUpdateManageTrInDto.getUpdateTrValues()){
				if(updateManageTrInDtoObj.isTrUpdated()){
					preparedStmt.setString (1, updateManageTrInDtoObj.getId());
					preparedStmt.setString (2, customUpdateManageTrInDto.getSelectedSystemId());
					preparedStmt.setString (3, updateManageTrInDtoObj.getCustomizingTr());
					preparedStmt.setString (4, updateManageTrInDtoObj.getWorkbenchTr());
					preparedStmt.setString (5, updateManageTrInDtoObj.getId());
					preparedStmt.setString (6, customUpdateManageTrInDto.getSelectedSystemId());
					preparedStmt.addBatch();

				}

			}
		}
		else{
			query ="INSERT INTO ClientSystemTrMapping (IMGAUTOID,SYSTEMID,CTR,KTR) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE CTR=VALUES(CTR), KTR = VALUES(KTR)";
			updateProjectTRDAO = new UpdateProjectTRDAO();
			resMessageDto =updateProjectTRDAO.updateTROverRide(updateProjectTRDto);
			con =  DBConnection.createConnection();
			preparedStmt = con.prepareStatement(query);
			for(UpdateManageTrInDto updateManageTrInDtoObj: customUpdateManageTrInDto.getUpdateTrValues()){
				if(updateManageTrInDtoObj.isTrUpdated()){
					preparedStmt.setString (1, updateManageTrInDtoObj.getId());
					preparedStmt.setString (2, customUpdateManageTrInDto.getSelectedSystemId());
					preparedStmt.setString (3, updateManageTrInDtoObj.getCustomizingTr());
					preparedStmt.setString (4, updateManageTrInDtoObj.getWorkbenchTr());
					preparedStmt.addBatch();

				}

			}
		}

				preparedStmt.executeBatch();
		}
		catch(SQLException e){
			 slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			 resMessageDto.setMessage("Unable to Update the TR values");
			}
		catch (Exception e) {
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}
		finally {
			if (preparedStmt != null) {
	            try {
	            	preparedStmt.close();
	            	preparedStmt = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }

	        if (con != null) {
	            try {
	            	con.close();
	            	con = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }
			  slf4jLogger.info("updateTrData method ended");

	        }

		return resMessageDto;
	}

}
