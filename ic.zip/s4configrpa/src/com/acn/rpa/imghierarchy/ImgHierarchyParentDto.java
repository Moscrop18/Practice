package com.acn.rpa.imghierarchy;

public class ImgHierarchyParentDto {
	private int id;
	private int nodeLevel;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getNodeLevel() {
		return nodeLevel;
	}
	public void setNodeLevel(int nodeLevel) {
		this.nodeLevel = nodeLevel;
	}

	

}
