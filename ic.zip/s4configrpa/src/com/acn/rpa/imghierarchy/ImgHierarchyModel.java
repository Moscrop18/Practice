package com.acn.rpa.imghierarchy;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.DBConnection;
import com.acn.user.session.IMGPreviewDto;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;

public class ImgHierarchyModel {

    private final Logger slf4jLogger = LoggerFactory.getLogger(ImgHierarchyModel.class);

	public String viewBPHierarchy(){
		slf4jLogger.info("viewBPHierarchy method started");
		Connection con = null;
		ArrayList <ImgHierarchyDto> globalArrayImg = null;
		ResultSet rs=null;
		ImgHierarchyDto imgHierarchyDto = null;
		PreparedStatement pStmt=null;
		ArrayList<ImgHierarchyParentDto> ParentNodeArray = null;
		ArrayList<Integer> map = null;
		ImgHierarchyParentDto parent = null;
		Gson gson = null;
		JsonArray myCustomArray = null;
		ImgHierarchyDto node = null;
		String output = null;
		int count = 0 ;
		int len = 0;
		try{
			map = new ArrayList<>();
			ParentNodeArray = new ArrayList<ImgHierarchyParentDto>();
			globalArrayImg = new ArrayList<ImgHierarchyDto>(); 
			con = DBConnection.createConnection();
			
			pStmt =  con.prepareStatement("SELECT IMGID,IMGDESCR,SEQUENCING,NODELEVEL,ENABLED,SCENARIO,NODETYPE,SUBPROCESS,CONFIGTYPE FROM SCENARIO_HIERARCHY WHERE ENABLED=? ORDER BY ID");
			pStmt.setInt(1, 1);
			rs = pStmt.executeQuery();
			
			while(rs.next()){
				count++;
				imgHierarchyDto = new ImgHierarchyDto();
				imgHierarchyDto.setImgId(rs.getString("IMGID"));
				imgHierarchyDto.setImgDescription(rs.getString("SEQUENCING").equals("")?rs.getString("IMGDESCR"):rs.getString("SEQUENCING")+"_"+rs.getString("IMGDESCR")); 
				imgHierarchyDto.setSequence(rs.getString("SEQUENCING"));
				imgHierarchyDto.setNodeLevel(rs.getInt("NODELEVEL"));
				//imgHierarchyDto.setIsMasterData(rs.getString("ISMASTERDATA"));
				imgHierarchyDto.setEnabled(rs.getInt("ENABLED"));
				imgHierarchyDto.setScenario(rs.getString("SCENARIO"));
				imgHierarchyDto.setSubProcess(rs.getString("SUBPROCESS"));
				imgHierarchyDto.setNodetype(rs.getString("NODETYPE"));
				imgHierarchyDto.setConfigType(rs.getString("CONFIGTYPE"));
	
				imgHierarchyDto.setParentNode(getMyParentID(imgHierarchyDto.getNodeLevel(),ParentNodeArray));
				globalArrayImg.add(imgHierarchyDto);
				parent = new ImgHierarchyParentDto();
				parent.setNodeLevel(imgHierarchyDto.getNodeLevel());
				parent.setId(count);
				ParentNodeArray.add(parent);
			}
				gson = new GsonBuilder().create();
				myCustomArray = gson.toJsonTree(globalArrayImg).getAsJsonArray();
				map.add(0);
				
				node = new ImgHierarchyDto();
				len = globalArrayImg.size();
				for(int i = 0; i < len; i++){
					node = globalArrayImg.get(i);
					map.add(i+1,i);
					if(node.getParentNode() != 0 ){
						globalArrayImg.get(map.get(node.getParentNode())).setChildren(node);
					}
				}
				 gson = new GsonBuilder().create();
				 
				 myCustomArray = gson.toJsonTree(globalArrayImg).getAsJsonArray();
				
				 output = myCustomArray.get(0).toString();

		}
		
			catch (Exception e){
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		finally{
			if(rs!=null){
				try {
					rs.close();
					rs=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			ParentNodeArray = null;
			map = null;
			parent = null;
			myCustomArray = null;
			slf4jLogger.info("viewBPHierarchy method ended");

		}
		return output;
		
		
	}
	
	public String viewBPHierarchyForIndustry(IMGPreviewDto dto){
		slf4jLogger.info("viewBPHierarchyforindustry method started");
		Connection con = null;
		ArrayList <ImgHierarchyDto> globalArrayImg = null;
		ResultSet rs=null;
		ImgHierarchyDto imgHierarchyDto = null;
		PreparedStatement pStmt=null;
		ArrayList<ImgHierarchyParentDto> ParentNodeArray = null;
		ArrayList<Integer> map = null;
		ImgHierarchyParentDto parent = null;
		Gson gson = null;
		JsonArray myCustomArray = null;
		ImgHierarchyDto node = null;
		String output = null;
		int count = 0 ;
		int len = 0;
		try{
			map = new ArrayList<>();
			ParentNodeArray = new ArrayList<ImgHierarchyParentDto>();
			globalArrayImg = new ArrayList<ImgHierarchyDto>(); 
			con = DBConnection.createConnection();
			
			pStmt =  con.prepareStatement("SELECT IMGID,IMGDESCR,SEQUENCING,IND_SEQ, NODELEVEL,ENABLED,SCENARIO,NODETYPE,SUBPROCESS,CONFIGTYPE FROM INDUSTRY_SCENARIOHIERARCHY WHERE ENABLED=? "
					+ "AND INDUSTRY LIKE ? AND SUBINDUSTRY LIKE ? ORDER BY ID");
			pStmt.setInt(1, 1);
			pStmt.setString(2, "%" + dto.getIndustry() + "%");
			pStmt.setString(3, "%" + dto.getSubIndustry() + "%");
			rs = pStmt.executeQuery();
			
			while(rs.next()){
				count++;
				imgHierarchyDto = new ImgHierarchyDto();
				imgHierarchyDto.setImgId(rs.getString("IMGID"));
				imgHierarchyDto.setImgDescription(rs.getString("IND_SEQ").equals("")?rs.getString("IMGDESCR"):rs.getString("IND_SEQ")+"_"+rs.getString("IMGDESCR")); 
				imgHierarchyDto.setSequence(rs.getString("SEQUENCING"));
				imgHierarchyDto.setIndSeq(rs.getString("IND_SEQ"));
				imgHierarchyDto.setNodeLevel(rs.getInt("NODELEVEL"));
				imgHierarchyDto.setEnabled(rs.getInt("ENABLED"));
				imgHierarchyDto.setScenario(rs.getString("SCENARIO"));
				imgHierarchyDto.setSubProcess(rs.getString("SUBPROCESS"));
				imgHierarchyDto.setNodetype(rs.getString("NODETYPE"));
				imgHierarchyDto.setConfigType(rs.getString("CONFIGTYPE"));
	
				imgHierarchyDto.setParentNode(getMyParentID(imgHierarchyDto.getNodeLevel(),ParentNodeArray));
				globalArrayImg.add(imgHierarchyDto);
				parent = new ImgHierarchyParentDto();
				parent.setNodeLevel(imgHierarchyDto.getNodeLevel());
				parent.setId(count);
				ParentNodeArray.add(parent);
			}
				gson = new GsonBuilder().create();
				myCustomArray = gson.toJsonTree(globalArrayImg).getAsJsonArray();
				map.add(0);
				
				node = new ImgHierarchyDto();
				len = globalArrayImg.size();
				for(int i = 0; i < len; i++){
					node = globalArrayImg.get(i);
					map.add(i+1,i);
					if(node.getParentNode() != 0 ){
						globalArrayImg.get(map.get(node.getParentNode())).setChildren(node);
					}
				}
				 gson = new GsonBuilder().create();
				 
				 myCustomArray = gson.toJsonTree(globalArrayImg).getAsJsonArray();
				
				 output = myCustomArray.get(0).toString();

		}
		
			catch (Exception e){
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		finally{
			if(rs!=null){
				try {
					rs.close();
					rs=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			ParentNodeArray = null;
			map = null;
			parent = null;
			myCustomArray = null;
			slf4jLogger.info("viewBPHierarchyforindustry method ended");

		}
		return output;
		
		
	}
	public String viewImgHierarchy(IMGPreviewDto dto){
		slf4jLogger.info("viewImgHierarchy method started");
		Connection con = null;
		ArrayList <ImgHierarchyDto> globalArrayImg = null;
		ResultSet rs=null;
		ImgHierarchyDto imgHierarchyDto = null;
		PreparedStatement pStmt=null;
		ArrayList<ImgHierarchyParentDto> ParentNodeArray = null;
		ArrayList<Integer> map = null;
		ImgHierarchyParentDto parent = null;
		Gson gson = null;
		JsonArray myCustomArray = null;
		ImgHierarchyDto node = null;
		String output = null;
		int count = 0 ;
		int len = 0;
		try{
			map = new ArrayList<>();
			ParentNodeArray = new ArrayList<ImgHierarchyParentDto>();
			globalArrayImg = new ArrayList<ImgHierarchyDto>(); 
			con = DBConnection.createConnection();
			if(dto.getSelectedArea()!=null && dto.getSelectedArea().equalsIgnoreCase("Industry")) {
				pStmt =  con.prepareStatement("SELECT IMGID,IMGDESCR,SEQUENCING,NODELEVEL,ISMASTERDATA,ENABLED,TRTYPE FROM INDUSTRY_IMGHIERARCHY WHERE ENABLED=? ORDER BY ID");
			}else {
				pStmt =  con.prepareStatement("SELECT IMGID,IMGDESCR,SEQUENCING,NODELEVEL,ISMASTERDATA,ENABLED,TRTYPE FROM IMGHIERARCHY WHERE ENABLED=? ORDER BY ID");
	
			}
			pStmt.setInt(1, 1);
			rs = pStmt.executeQuery();
			while(rs.next()){
				count++;
				imgHierarchyDto = new ImgHierarchyDto();
				imgHierarchyDto.setImgId(rs.getString("IMGID"));
				imgHierarchyDto.setImgDescription(rs.getString("SEQUENCING").equals("")?rs.getString("IMGDESCR"):rs.getString("SEQUENCING")+"_"+rs.getString("IMGDESCR")); 
				imgHierarchyDto.setSequence(rs.getString("SEQUENCING"));
				imgHierarchyDto.setNodeLevel(rs.getInt("NODELEVEL"));
				imgHierarchyDto.setIsMasterData(rs.getString("ISMASTERDATA"));
				imgHierarchyDto.setEnabled(rs.getInt("ENABLED"));
				//imgHierarchyDto.setBusinessProcID(rs.getString("SCENARIOID"));
				//imgHierarchyDto.setNodetype(rs.getString("NODETYPE"));
				imgHierarchyDto.setTrType(rs.getString("TRTYPE"));
	
				imgHierarchyDto.setParentNode(getMyParentID(imgHierarchyDto.getNodeLevel(),ParentNodeArray));
				globalArrayImg.add(imgHierarchyDto);
				parent = new ImgHierarchyParentDto();
				parent.setNodeLevel(imgHierarchyDto.getNodeLevel());
				parent.setId(count);
				ParentNodeArray.add(parent);
			}
			

				gson = new GsonBuilder().create();
				myCustomArray = gson.toJsonTree(globalArrayImg).getAsJsonArray();
				map.add(0);
				node = new ImgHierarchyDto();
				len = globalArrayImg.size();
				for(int i = 0; i < len; i++){
					node = globalArrayImg.get(i);
					map.add(i+1,i);
					if(node.getParentNode() != 0 ){
						globalArrayImg.get(map.get(node.getParentNode())).setChildren(node);
					}
				}
				 gson = new GsonBuilder().create();
				 myCustomArray = gson.toJsonTree(globalArrayImg).getAsJsonArray();
				 output = myCustomArray.get(0).toString();

		}
		
			catch (Exception e){
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		finally{
			if(rs!=null){
				try {
					rs.close();
					rs=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			ParentNodeArray = null;
			map = null;
			parent = null;
			myCustomArray = null;
			slf4jLogger.info("viewImgHierarchy method ended");

		}
		return output;
		
		
	}
	
	public String viewImgHierarchyForIndustry(IMGPreviewDto dto){
		slf4jLogger.info("viewImgHierarchy method started");
		Connection con = null;
		ArrayList <ImgHierarchyDto> globalArrayImg = null;
		ResultSet rs=null;
		ImgHierarchyDto imgHierarchyDto = null;
		PreparedStatement pStmt=null;
		ArrayList<ImgHierarchyParentDto> ParentNodeArray = null;
		ArrayList<Integer> map = null;
		ImgHierarchyParentDto parent = null;
		Gson gson = null;
		JsonArray myCustomArray = null;
		ImgHierarchyDto node = null;
		String output = null;
		int count = 0 ;
		int len = 0;
		try{
			map = new ArrayList<>();
			ParentNodeArray = new ArrayList<ImgHierarchyParentDto>();
			globalArrayImg = new ArrayList<ImgHierarchyDto>(); 
			con = DBConnection.createConnection();
			
				pStmt =  con.prepareStatement("SELECT IMGID,IMGDESCR,SEQUENCING,NODELEVEL,ISMASTERDATA,ENABLED,TRTYPE FROM INDUSTRY_IMGHIERARCHY WHERE ENABLED=? AND INDUSTRY LIKE ? AND SUBINDUSTRY LIKE ? ORDER BY ID");
			
			pStmt.setInt(1, 1);
			pStmt.setString(2, "%" + dto.getIndustry() + "%");
			pStmt.setString(3, "%" + dto.getSubIndustry() + "%");
			rs = pStmt.executeQuery();
			while(rs.next()){
				count++;
				imgHierarchyDto = new ImgHierarchyDto();
				imgHierarchyDto.setImgId(rs.getString("IMGID"));
				imgHierarchyDto.setImgDescription(rs.getString("SEQUENCING").equals("")?rs.getString("IMGDESCR"):rs.getString("SEQUENCING")+"_"+rs.getString("IMGDESCR")); 
				imgHierarchyDto.setSequence(rs.getString("SEQUENCING"));
				imgHierarchyDto.setNodeLevel(rs.getInt("NODELEVEL"));
				imgHierarchyDto.setIsMasterData(rs.getString("ISMASTERDATA"));
				imgHierarchyDto.setEnabled(rs.getInt("ENABLED"));
				//imgHierarchyDto.setBusinessProcID(rs.getString("SCENARIOID"));
				//imgHierarchyDto.setNodetype(rs.getString("NODETYPE"));
				imgHierarchyDto.setTrType(rs.getString("TRTYPE"));
	
				imgHierarchyDto.setParentNode(getMyParentID(imgHierarchyDto.getNodeLevel(),ParentNodeArray));
				globalArrayImg.add(imgHierarchyDto);
				parent = new ImgHierarchyParentDto();
				parent.setNodeLevel(imgHierarchyDto.getNodeLevel());
				parent.setId(count);
				ParentNodeArray.add(parent);
			}
			

				gson = new GsonBuilder().create();
				myCustomArray = gson.toJsonTree(globalArrayImg).getAsJsonArray();
				map.add(0);
				node = new ImgHierarchyDto();
				len = globalArrayImg.size();
				for(int i = 0; i < len; i++){
					node = globalArrayImg.get(i);
					map.add(i+1,i);
					if(node.getParentNode() != 0 ){
						globalArrayImg.get(map.get(node.getParentNode())).setChildren(node);
					}
				}
				 gson = new GsonBuilder().create();
				 myCustomArray = gson.toJsonTree(globalArrayImg).getAsJsonArray();
				 output = myCustomArray.get(0).toString();

		}
		
			catch (Exception e){
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		finally{
			if(rs!=null){
				try {
					rs.close();
					rs=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			ParentNodeArray = null;
			map = null;
			parent = null;
			myCustomArray = null;
			slf4jLogger.info("viewImgHierarchy method ended");

		}
		return output;
		
		
	}
	public String viewImgHierarchyCopyFunctionality(){
		slf4jLogger.info("viewImgHierarchy method started");
		Connection con = null;
		ArrayList <ImgHierarchyDto> globalArrayImg = null;
		ResultSet rs=null;
		ImgHierarchyDto imgHierarchyDto = null;
		PreparedStatement pStmt=null;
		ArrayList<ImgHierarchyParentDto> ParentNodeArray = null;
		ArrayList<Integer> map = null;
		ImgHierarchyParentDto parent = null;
		Gson gson = null;
		JsonArray myCustomArray = null;
		ImgHierarchyDto node = null;
		String output = null;
		int count = 0 ;
		int len = 0;
		try{
			map = new ArrayList<>();
			ParentNodeArray = new ArrayList<ImgHierarchyParentDto>();
			globalArrayImg = new ArrayList<ImgHierarchyDto>(); 
			con = DBConnection.createConnection();
			pStmt =  con.prepareStatement("SELECT IMGID,IMGDESCR,SEQUENCING,NODELEVEL,ISMASTERDATA,ENABLED,TRTYPE FROM COPYFUNCTIONALITY_IMGHIERARCHY WHERE ENABLED=? ORDER BY ID");

			pStmt.setInt(1, 1);
			rs = pStmt.executeQuery();
			while(rs.next()){
				count++;
				imgHierarchyDto = new ImgHierarchyDto();
				imgHierarchyDto.setImgId(rs.getString("IMGID"));
				imgHierarchyDto.setImgDescription(rs.getString("SEQUENCING").equals("")?rs.getString("IMGDESCR"):rs.getString("SEQUENCING")+"_"+rs.getString("IMGDESCR")); 
				imgHierarchyDto.setSequence(rs.getString("SEQUENCING"));
				imgHierarchyDto.setNodeLevel(rs.getInt("NODELEVEL"));
				imgHierarchyDto.setIsMasterData(rs.getString("ISMASTERDATA"));
				imgHierarchyDto.setEnabled(rs.getInt("ENABLED"));
				//imgHierarchyDto.setBusinessProcID(rs.getString("SCENARIOID"));
				//imgHierarchyDto.setNodetype(rs.getString("NODETYPE"));
				imgHierarchyDto.setTrType(rs.getString("TRTYPE"));
	
				imgHierarchyDto.setParentNode(getMyParentID(imgHierarchyDto.getNodeLevel(),ParentNodeArray));
				globalArrayImg.add(imgHierarchyDto);
				parent = new ImgHierarchyParentDto();
				parent.setNodeLevel(imgHierarchyDto.getNodeLevel());
				parent.setId(count);
				ParentNodeArray.add(parent);
			}
			

				gson = new GsonBuilder().create();
				myCustomArray = gson.toJsonTree(globalArrayImg).getAsJsonArray();
				map.add(0);
				node = new ImgHierarchyDto();
				len = globalArrayImg.size();
				for(int i = 0; i < len; i++){
					node = globalArrayImg.get(i);
					map.add(i+1,i);
					if(node.getParentNode() != 0 ){
						globalArrayImg.get(map.get(node.getParentNode())).setChildren(node);
					}
				}
				 gson = new GsonBuilder().create();
				 myCustomArray = gson.toJsonTree(globalArrayImg).getAsJsonArray();
				 output = myCustomArray.get(0).toString();

		}
		
			catch (Exception e){
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		finally{
			if(rs!=null){
				try {
					rs.close();
					rs=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			ParentNodeArray = null;
			map = null;
			parent = null;
			myCustomArray = null;
			slf4jLogger.info("viewImgHierarchy method ended");

		}
		return output;
		
		
	}
	
	public static int getMyParentID(int currentLevel,ArrayList<ImgHierarchyParentDto> ParentNodeArray){		
		int check = 0; 
		int len = 0;
		len = ParentNodeArray.size();
		
		for(int j= len - 1; j >= 0; j--){			
			check = currentLevel - 1;
			if(ParentNodeArray.get(j).getNodeLevel() == check)
		      {
				return ParentNodeArray.get(j).getId();
		      }
		}		
		return 0;
	}
}