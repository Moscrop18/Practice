package com.acn.rpa.imghierarchy;


import java.util.ArrayList;

/**
 * @author Rajesh Valupadasu
 *
 */


import java.util.List;

import javax.ws.rs.core.Response;

import com.acn.user.session.ResMessageDto;

public class ClientImgResponseDto {
	private List<ClientImgHierarchyDto> listClientImgHierarchyDto;
	private ResMessageDto resMessageDto;	
	private ArrayList<ManageTrResponseDto> outputDataList;
	//private List<String> omId;
	//private ArrayList<String> clientId;

	private ArrayList<String> imgId;
	//private Response clientSpImgTree;
	private ArrayList<String> imgDescr;
	
	public ResMessageDto getResMessageDto() {
		return resMessageDto;
	}
	public void setResMessageDto(ResMessageDto resMessageDto) {
		this.resMessageDto = resMessageDto;
	}
	
	public ArrayList<ManageTrResponseDto> getOutputDataList() {
		return outputDataList;
	}
	public void setOutputDataList(ArrayList<ManageTrResponseDto> outputDataList) {
		this.outputDataList = outputDataList;
	}
	public ArrayList<String> getImgId() {
		return imgId;
	}
	public void setImgId(ArrayList<String> imgId) {
		this.imgId = imgId;
	}
/*	public Response getClientSpImgTree() {
		return clientSpImgTree;
	}
	public void setClientSpImgTree(Response clientSpImgTree) {
		this.clientSpImgTree = clientSpImgTree;
	}
	
	
	public ArrayList<String> getClientId() {
		return clientId;
	}
	public void setClientId(ArrayList<String> clientId) {
		this.clientId = clientId;
	}
	public List<String> getOmId() {
		return omId;
	}
	public void setOmId(List<String> omId) {
		this.omId = omId;
	}*/
	public List<ClientImgHierarchyDto> getListClientImgHierarchyDto() {
		return listClientImgHierarchyDto;
	}
	public void setListClientImgHierarchyDto(List<ClientImgHierarchyDto> listClientImgHierarchyDto) {
		this.listClientImgHierarchyDto = listClientImgHierarchyDto;
	}
	public ArrayList<String> getImgDescr() {
		return imgDescr;
	}
	public void setImgDescr(ArrayList<String> imgDescr) {
		this.imgDescr = imgDescr;
	}
	
}
