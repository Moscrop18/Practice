package com.acn.rpa.imghierarchy;



import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.acn.user.session.ResMessageDto;
import com.acn.user.session.SessionInputDTO;

public class ImgHierarchyDto {
	
	private int id;
	@Size(min = 1, max = 30)
	private String imgId;
	@Size(min = 1, max = 255)
	private String imgDescription;
	@Size(min = 0, max = 45)
	private String module;
	@Size(min = 0, max = 45)
	private String subModule;
	@Size(min = 0, max = 10)
	private String sequence;
	
	@Size(min = 0, max = 10)
	private String indSeq;
	private String templatePath;
	@DecimalMin(value = "0")
    @DecimalMax(value = "999")
	private int nodeLevel;
	private int parentNode;
	@Size(min = 0, max = 2)
	@Pattern(regexp = "[a-zA-Z0-9]+")
	private String objectType;
	@Size(min = 0, max = 30)
	private String objectName;
	private String copyFlag;
	@Size(min = 0, max = 30)
	private String dependencyImgId;
	
	private boolean industryFlag;
	
	private int crossIndFlag;
	
	private int indFlag;
	
	private String industry;
	
	private String subIndustry;
	
	private String aliasIndustry;
	
	private String aliasSubIndustry;
	
	public String getCopyFlag() {
		return copyFlag;
	}
	public void setCopyFlag(String copyFlag) {
		this.copyFlag = copyFlag;
	}
	private int cFlag;

	public int getcFlag() {
		return cFlag;
	}
	public void setcFlag(int cFlag) {
		this.cFlag = cFlag;
	}
	@Size(min = 0, max = 255)
	private String dependencyImgIdDesc;
	@Size(min = 1, max = 1)
	@Pattern(regexp = "[a-zA-Z]+")
	private String isMasterData;
	@Valid
	private List<String> inputImgId;
	private String message;
	private String status;
	@Valid
	private List<ImgHierarchyDto> listImgHierarchyDto; 
	@Valid
	private ArrayList<String> imgDesc;
	@DecimalMin(value = "0")
    @DecimalMax(value = "999")
	private int imgObjSeq;
	@Size(min = 1, max = 1)
	@Pattern(regexp = "[a-zA-Z]+")
	private String isS4imgType;
	@Size(min = 1, max = 1)
	@Pattern(regexp = "[a-zA-Z]+")
	private String isECCimgType;
	private byte[] bytes;
	@DecimalMin(value = "0")
    @DecimalMax(value = "1")
	private int enabled;
	@Size(min = 1, max = 1)
	@Pattern(regexp = "[a-zA-Z]+")
	private String selField;
	@Size(min = 1, max = 1)
	@Pattern(regexp = "[a-zA-Z]+")
	private String trOverride;
	@Size(min = 1, max = 2)
	@Pattern(regexp = "[a-zA-Z]+")
	private String trType;
	private String configType;
	public String getConfigType() {
		return configType;
	}
	public void setConfigType(String configType) {
		this.configType = configType;
	}
	private ResMessageDto resMessageDto;
	public String getNodetype() {
		return nodetype;
	}
	public void setNodetype(String nodetype) {
		this.nodetype = nodetype;
	}
	private String nodetype;
	
	private String scenario;
	public String getScenario() {
		return scenario;
	}
	public void setScenario(String scenario) {
		this.scenario = scenario;
	}
	public String getSubProcess() {
		return subProcess;
	}
	public void setSubProcess(String subProcess) {
		this.subProcess = subProcess;
	}
	private String subProcess;
	
	public ResMessageDto getResMessageDto() {
			return resMessageDto;
		}
	public void setResMessageDto(ResMessageDto resMessageDto) {
			this.resMessageDto = resMessageDto;
		}
	private SessionInputDTO sessionInputDTO;
	
	public SessionInputDTO getSessionInputDTO() {
		return sessionInputDTO;
	}
	public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
		this.sessionInputDTO = sessionInputDTO;
	}
	public String getTrOverride() {
		return trOverride;
	}

	public void setTrOverride(String trOverride) {
		this.trOverride = trOverride;
	}

	public String getTrType() {
		return trType;
	}

	public void setTrType(String trType) {
		this.trType = trType;
	}

	public String getSelField() {
		return selField;
	}

	public void setSelField(String selField) {
		this.selField = selField;
	}

	public int getEnabled() {
		return enabled;
	}

	public void setEnabled(int enabled) {
		this.enabled = enabled;
	}

	public byte[] getBytes() {
		return bytes;
	}

	public void setBytes(byte[] bytes) {
		this.bytes = bytes;
	}

	public int getImgObjSeq() {
		return imgObjSeq;
	}

	public void setImgObjSeq(int imgObjSeq) {
		this.imgObjSeq = imgObjSeq;
	}

	public String getIsS4imgType() {
		return isS4imgType;
	}

	public void setIsS4imgType(String isS4imgType) {
		this.isS4imgType = isS4imgType;
	}

	public String getIsECCimgType() {
		return isECCimgType;
	}

	public void setIsECCimgType(String isECCimgType) {
		this.isECCimgType = isECCimgType;
	}

	public ArrayList<String> getImgDesc() {
		return imgDesc;
	}

	public void setImgDesc(ArrayList<String> imgDesc) {
		this.imgDesc = imgDesc;
	}

	public List<ImgHierarchyDto> getListImgHierarchyDto() {
		return listImgHierarchyDto;
	}

	public void setListImgHierarchyDto(List<ImgHierarchyDto> listImgHierarchyDto) {
		this.listImgHierarchyDto = listImgHierarchyDto;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<String> getInputImgId() {
		return inputImgId;
	}

	public void setInputImgId(List<String> inputImgId) {
		this.inputImgId = inputImgId;
	}

	public String getIsMasterData() {
		return isMasterData;
	}

	public void setIsMasterData(String isMasterData) {
		this.isMasterData = isMasterData;
	}

	public String getDependencyImgId() {
		return dependencyImgId;
	}

	public void setDependencyImgId(String dependencyImgId) {
		this.dependencyImgId = dependencyImgId;
	}

	public String getDependencyImgIdDesc() {
		return dependencyImgIdDesc;
	}

	public void setDependencyImgIdDesc(String dependencyImgIdDesc) {
		this.dependencyImgIdDesc = dependencyImgIdDesc;
	}

	public String getObjectType() {
		return objectType;
	}

	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}

	public String getObjectName() {
		return objectName;
	}

	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}
	private ArrayList<ImgHierarchyDto> children = new ArrayList<>();
	
	
	
	
	public ImgHierarchyDto(){
		
	}
	
	public ArrayList<ImgHierarchyDto> getChildren() {
		return children;
	}

	public void setChildren(ImgHierarchyDto children) {
		this.children.add(children);
	}
	
	public int getParentNode() {
		return parentNode;
	}

	public void setParentNode(int parentNode) {
		this.parentNode = parentNode;
	}
	
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getImgId() { 
		return imgId; 
	}
	public void setImgId(String imgId) {
		this.imgId = imgId;
	}
	public String getImgDescription() {
		return imgDescription;
	}
	public void setImgDescription(String imgDescription) {
		this.imgDescription = imgDescription;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public String getSubModule() {
		return subModule;
	}
	public void setSubModule(String subModule) {
		this.subModule = subModule;
	}
	public String getSequence() {
		return sequence;
	}
	public void setSequence(String sequence) {
		this.sequence = sequence;
	}
	public String getTemplatePath() {
		return templatePath;
	}
	public void setTemplatePath(String templatePath) {
		this.templatePath = templatePath;
	}
	public int getNodeLevel() {
		return nodeLevel;
	}
	public void setNodeLevel(int nodeLevel) {
		this.nodeLevel = nodeLevel;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public String getSubIndustry() {
		return subIndustry;
	}
	public void setSubIndustry(String subIndustry) {
		this.subIndustry = subIndustry;
	}
	public int getCrossIndFlag() {
		return crossIndFlag;
	}
	public void setCrossIndFlag(int crossIndFlag) {
		this.crossIndFlag = crossIndFlag;
	}
	public int getIndFlag() {
		return indFlag;
	}
	public void setIndFlag(int indFlag) {
		this.indFlag = indFlag;
	}
	public String getAliasIndustry() {
		return aliasIndustry;
	}
	public void setAliasIndustry(String aliasIndustry) {
		this.aliasIndustry = aliasIndustry;
	}
	public String getAliasSubIndustry() {
		return aliasSubIndustry;
	}
	public void setAliasSubIndustry(String aliasSubIndustry) {
		this.aliasSubIndustry = aliasSubIndustry;
	}
	public boolean isIndustryFlag() {
		return industryFlag;
	}
	public void setIndustryFlag(boolean industryFlag) {
		this.industryFlag = industryFlag;
	}
	public String getIndSeq() {
		return indSeq;
	}
	public void setIndSeq(String indSeq) {
		this.indSeq = indSeq;
	}
}
