package com.acn.rpa.imghierarchy;

public class ManageTrResponseDto {
	
	private String imgId;
	private String imgDesc;
	private String customizingTr;
	private String workbenchTr;
	private String trType;
	private String id; 
	
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTrtype1() {
		return trtype1;
	}
	public void setTrtype1(String trtype1) {
		this.trtype1 = trtype1;
	}
	public String getTrtype2() {
		return trtype2;
	}
	public void setTrtype2(String trtype2) {
		this.trtype2 = trtype2;
	}
	private boolean trUpdated;
	private int sno;
	
	public boolean isTrCusFieldReq() {
		return trCusFieldReq;
	}
	public void setTrCusFieldReq(boolean trCusFieldReq) {
		this.trCusFieldReq = trCusFieldReq;
	}
	public boolean isTrWKFieldReq() {
		return trWKFieldReq;
	}
	public void setTrWKFieldReq(boolean trWKFieldReq) {
		this.trWKFieldReq = trWKFieldReq;
	}
	private String trtype1;
	private String trtype2;
	private boolean trCusFieldReq;
	private boolean trWKFieldReq;

	public int getSno() {
		return sno;
	}
	public void setSno(int sno) {
		this.sno = sno;
	}
	public String getTrType() {
		return trType;
	}
	public void setTrType(String trType) {
		this.trType = trType;
	}
	public String getImgId() {
		return imgId;
	}
	public void setImgId(String imgId) {
		this.imgId = imgId;
	}
	public boolean isTrUpdated() {
		return trUpdated;
	}
	public void setTrUpdated(boolean trUpdated) {
		this.trUpdated = trUpdated;
	}
	public String getImgDesc() {
		return imgDesc;
	}
	public void setImgDesc(String imgDesc) {
		this.imgDesc = imgDesc;
	}
	public String getCustomizingTr() {
		return customizingTr;
	}
	public void setCustomizingTr(String customizingTr) {
		this.customizingTr = customizingTr;
	}
	public String getWorkbenchTr() {
		return workbenchTr;
	}
	public void setWorkbenchTr(String workbenchTr) {
		this.workbenchTr = workbenchTr;
	}
	
	

}
