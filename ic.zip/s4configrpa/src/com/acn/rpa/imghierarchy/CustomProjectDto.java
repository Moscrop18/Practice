package com.acn.rpa.imghierarchy;

import java.util.ArrayList;

import com.acn.user.session.ResMessageDto;

public class CustomProjectDto {

	private ResMessageDto resMessageDto;
	private ArrayList<ProjectDto> projDetails;
	
	public ArrayList<ProjectDto> getProjDetails() {
		return projDetails;
	}
	public void setProjDetails(ArrayList<ProjectDto> projDetails) {
		this.projDetails = projDetails;
	}
	public ResMessageDto getResMessageDto() {
		return resMessageDto;
	}
	public void setResMessageDto(ResMessageDto resMessageDto) {
		this.resMessageDto = resMessageDto;
	}
	
	
}
