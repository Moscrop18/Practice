package com.acn.rpa.imghierarchy;
import java.util.ArrayList;

import javax.validation.Valid;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
public class SequenceDto {
	@Size(min = 1, max = 30)
	private String imgId;
	@Size(min = 1, max = 255)
	private String imgDescription;
	@DecimalMin(value = "1")
    @DecimalMax(value = "999")
	private int sequence;
	@Size(min = 1, max = 255)
	private String fileName;
	private String filepath;
	@Valid
	private ArrayList<SequenceDto> listSequenceDto;
	public ArrayList<SequenceDto> getListSequenceDto() {
		return listSequenceDto;
	}
	public void setListSequenceDto(ArrayList<SequenceDto> listSequenceDto) {
		this.listSequenceDto = listSequenceDto;
	}
	public String getImgId() {
		return imgId;
	}
	public void setImgId(String imgId) {
		this.imgId = imgId;
	}
	public String getImgDescription() {
		return imgDescription;
	}
	public void setImgDescription(String imgDescription) {
		this.imgDescription = imgDescription;
	}
	public int getSequence() {
		return sequence;
	}
	public void setSequence(int sequence) {
		this.sequence = sequence;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFilepath() {
		return filepath;
	}
	public void setFilepath(String filepath) {
		this.filepath = filepath;
	}
}