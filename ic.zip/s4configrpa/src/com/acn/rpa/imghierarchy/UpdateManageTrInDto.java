package com.acn.rpa.imghierarchy;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class UpdateManageTrInDto {
	@Size(min = 1, max = 30)
	private String imgId;
	@Size(min = 0, max = 10)
	@Pattern(regexp = "[a-zA-Z0-9]*$")
	private String workbenchTr;
	@Size(min = 0, max = 10)
	@Pattern(regexp = "[a-zA-Z0-9]*$")
	private String customizingTr;
	private boolean trUpdated;
	private String id;
	
	

	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getImgId() {
		return imgId;
	}
	public void setImgId(String imgId) {
		this.imgId = imgId;
	}
	public boolean isTrUpdated() {
		return trUpdated;
	}
	public void setTrUpdated(boolean trUpdated) {
		this.trUpdated = trUpdated;
	}
	public String getWorkbenchTr() {
		return workbenchTr;
	}
	public void setWorkbenchTr(String workbenchTr) {
		this.workbenchTr = workbenchTr;
	}
	public String getCustomizingTr() {
		return customizingTr;
	}
	public void setCustomizingTr(String customizingTr) {
		this.customizingTr = customizingTr;
	}
//	public String getOmid() {
//		return omid;
//	}
//	public void setOmid(String omid) {
//		this.omid = omid;
//	}
	
	
}
