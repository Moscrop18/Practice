package com.acn.rpa.imghierarchy;

import java.util.ArrayList;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.acn.user.session.SessionInputDTO;

public class CustomUpdateManageTrInDto {
	@Size(min = 1, max = 30)
	private String omid;
	@Valid
	private ArrayList<UpdateManageTrInDto> updateTrValues;
	@Size(min = 1, max = 1)
	@Pattern(regexp = "[a-zA-Z]+")
	private String trOverrideFLag;
	@Size(min = 1, max = 10)
	private String selectedSystemId;
	@Valid
	private SessionInputDTO sessionInputDTO;
	
	public SessionInputDTO getSessionInputDTO() {
		return sessionInputDTO;
	}
	public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
		this.sessionInputDTO = sessionInputDTO;
	}

	public String getSelectedSystemId() {
		return selectedSystemId;
	}

	public void setSelectedSystemId(String selectedSystemId) {
		this.selectedSystemId = selectedSystemId;
	}

	public String getTrOverrideFLag() {
		return trOverrideFLag;
	}

	public void setTrOverrideFLag(String trOverrideFLag) {
		this.trOverrideFLag = trOverrideFLag;
	}

	public String getOmid() {
		return omid;
	}
	
	public void setOmid(String omid) {
		this.omid = omid;
	}
	public ArrayList<UpdateManageTrInDto> getUpdateTrValues() {
		return updateTrValues;
	}
	public void setUpdateTrValues(ArrayList<UpdateManageTrInDto> updateTrValues) {
		this.updateTrValues = updateTrValues;
	}
	
	

	
}
