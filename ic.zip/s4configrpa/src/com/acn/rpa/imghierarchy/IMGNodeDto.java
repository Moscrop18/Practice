package com.acn.rpa.imghierarchy;

import java.util.ArrayList;
import java.util.List;

public class IMGNodeDto {

    private String id;
    private String name;
    private String parentId;
    private List<IMGNodeDto> childrenItems; 

    public IMGNodeDto() {
        this.id = "";
        this.name = "";     
        this.parentId = "";
        this.childrenItems = new ArrayList<IMGNodeDto>();
    }

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getParentId() {
        return parentId;
    }
    public void setParentId(String parentId) {
        this.parentId = parentId;
    }
    public List<IMGNodeDto> getChildrenItems() {
        return childrenItems;
    }
    public void setChildrenItems(List<IMGNodeDto> childrenItems) {
        this.childrenItems = childrenItems;
    }
    public void addChildrenItem(IMGNodeDto childrenItem){
        if(!this.childrenItems.contains(childrenItem))
            this.childrenItems.add(childrenItem);
    }

    @Override
    public String toString() {
        return "MegaMenuDTO [Id=" + id + ", name=" + name + ", parentId="
                + parentId + ", childrenItems=" + childrenItems + "]";
    }

}