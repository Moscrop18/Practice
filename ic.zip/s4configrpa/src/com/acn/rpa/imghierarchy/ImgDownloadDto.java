package com.acn.rpa.imghierarchy;

import java.util.ArrayList;

import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Size;

public class ImgDownloadDto {
	
	@Size(min = 1, max = 30)
	private String imgId;
	@Size(min = 1, max = 255)
	private String imgDescription;
	@Size(min = 0, max = 10)
	private String sequence;

	public String getSequence() {
		return sequence;
	}
	public void setSequence(String sequence) {
		this.sequence = sequence;
	}
	private ArrayList<String> imgScope;

	public String getImgId() {
		return imgId;
	}
	public void setImgId(String imgId) {
		this.imgId = imgId;
	}

	public String getImgDescription() {
		return imgDescription;
	}
	public void setImgDescription(String imgDescription) {
		this.imgDescription = imgDescription;
	}
	public ArrayList<String> getImgScope() {
		return imgScope;
	}
	public void setImgScope(ArrayList<String> imgScope) {
		this.imgScope = imgScope;
	}
	

}
