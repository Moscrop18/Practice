package com.acn.rpa.imghierarchy;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.DBConnection;
import com.acn.user.session.ResMessageDto;

public class UpdateProjectTRDAO {

    private final Logger slf4jLogger = LoggerFactory.getLogger(UpdateProjectTRDAO.class);

	public ResMessageDto updateTROverRide(UpdateProjectTRDto updateProjectTRDto) {
		slf4jLogger.info("updateTROverRide method started");
		ResMessageDto outputData = new ResMessageDto();
		PreparedStatement preparedStmt =  null; 
		Connection con = null;
		String query="UPDATE CUSTOMER SET TROverRide=? WHERE OMID=?";
		try{
			con =  DBConnection.createConnection();
			preparedStmt = con.prepareStatement(query);
			preparedStmt.setString (1, updateProjectTRDto.getTrOverrideFLag());
			preparedStmt.setString (2, updateProjectTRDto.getOmid());
			preparedStmt.executeUpdate();
			}
		catch(SQLException e){
			outputData.setMessage("Not able to Update the TR Data");
			slf4jLogger.error("Not able to Update the TR Data");
			 outputData.setMsgType(ConstantsValues.ERRORSTATUS);
			}
		catch (Exception e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}
		finally {
			if (preparedStmt != null) {
	            try {
	            	preparedStmt.close();
	            	preparedStmt = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }

	        if (con != null) {
	            try {
	            	con.close();
	            	con = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }
			  slf4jLogger.info("updateTROverRide method ended");

	        }
		 outputData.setMessage("Customer Data Updated Sucessfully");
		 outputData.setMsgType(ConstantsValues.SUCCESSSTATUS);
		return outputData;
	}
	
	
}
