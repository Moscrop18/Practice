package com.acn.rpa.imghierarchy;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

import com.acn.user.session.SessionInputDTO;

public class IndustryDto {
	private String industry;
	private String subIndustry;
	
	@Pattern(regexp = "[a-zA-Z0-9]+")
	private String userRole;
	@Valid
	private SessionInputDTO sessionInputDTO;
	
	public String getSubIndustry() {
		return subIndustry;
	}
	public void setSubIndustry(String subIndustry) {
		this.subIndustry = subIndustry;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	public SessionInputDTO getSessionInputDTO() {
		return sessionInputDTO;
	}
	public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
		this.sessionInputDTO = sessionInputDTO;
	}
	

}
