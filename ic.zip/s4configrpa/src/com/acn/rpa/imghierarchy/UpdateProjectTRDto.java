package com.acn.rpa.imghierarchy;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.acn.user.session.SessionInputDTO;

public class UpdateProjectTRDto {
	@Size(min = 1, max = 20)
	private String omid;
	@Size(min = 1, max = 1)
	@Pattern(regexp = "[a-zA-Z]+")
	private String trOverrideFLag;
	private String message;
	@Valid
	private SessionInputDTO sessionInputDTO;
	
	public SessionInputDTO getSessionInputDTO() {
		return sessionInputDTO;
	}
	public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
		this.sessionInputDTO = sessionInputDTO;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getOmid() {
		return omid;
	}

	public void setOmid(String omid) {
		this.omid = omid;
	}

	public String getTrOverrideFLag() {
		return trOverrideFLag;
	}

	public void setTrOverrideFLag(String trOverrideFLag) {
		this.trOverrideFLag = trOverrideFLag;
	}
	

}
