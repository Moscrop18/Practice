package com.acn.rpa.imghierarchy;


import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.chemistry.opencmis.client.api.Session;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.admin.ResponseDto;
import com.acn.rpa.config.DownloadScopeResDto;
import com.acn.rpa.config.S4AutoConfExecution;
import com.acn.rpa.config.dto.BrownfieldMdRequestDto;
import com.acn.rpa.config.dto.MasterDataDependencyChkInDTO;
import com.acn.rpa.docservice.HCPDocDAO;
import com.acn.rpa.docservice.HCPDocServiceResDto;
import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.DBConnection;
import com.acn.rpa.utilities.PropMappings;
import com.acn.user.session.ResMessageDto;

public class ImgHierarchyDAO  { 
    private final Logger slf4jLogger = LoggerFactory.getLogger(ImgHierarchyDAO.class);

	public ImgResponseDto insertImgHierarchyData(HttpServletRequest request)   {  
		slf4jLogger.info("insertImgHierarchyData method started");
		FileItemFactory factory = new DiskFileItemFactory();
		ServletFileUpload fileUpload = new ServletFileUpload(factory);
		FileItem fileItemTemp = null;
		ImgHierarchyDto imgHierarchyDtoObj =  null;
		XSSFWorkbook workbook = null;
		XSSFSheet sheet = null;
		Iterator<Row> rowIterator = null;
		int noOfColumns = 0;
		boolean flag = false;
		boolean flag1 = true;
		//slf4jLogger.info("flaag1"+flag1);
		ImgResponseDto imgResponseDto = null;
		ArrayList<ImgHierarchyDto> dtoList = null;
		List <FileItem> fileItemsList = null;
		Iterator <FileItem> fileItemsIterator = null;
		ArrayList<String> fieldMappingRecord = new ArrayList<String>();
		ArrayList<String> duplicateimgids= new ArrayList<String>();
		int count=0;
		try{
			imgResponseDto = new ImgResponseDto();
			if (ServletFileUpload.isMultipartContent(request)) {
				fileItemsList = fileUpload.parseRequest(request);
				fileItemsIterator = fileItemsList.iterator();
				while (fileItemsIterator.hasNext()) {
					fileItemTemp = fileItemsIterator.next();
					if (!fileItemTemp.isFormField()) {
						workbook = new XSSFWorkbook(fileItemTemp.getInputStream());								
					}
				}
			}
         sheet = workbook.getSheetAt(0);
         rowIterator = sheet.iterator();
         noOfColumns = sheet.getRow(0).getPhysicalNumberOfCells();
         rowIterator.next();
         dtoList = new ArrayList<ImgHierarchyDto>();
         while(rowIterator.hasNext())
         {	
        	
        	 imgHierarchyDtoObj = new ImgHierarchyDto();
        	 Row row = rowIterator.next();
        
        	 for(int i=0;i<noOfColumns;i++)
        	 {
                if(row.getCell(i) !=null ){
                	row.getCell(i).setCellType(Cell.CELL_TYPE_STRING);
                		if(i==0){
                			if( row.getCell(i).getStringCellValue()!=null && row.getCell(i).getStringCellValue()!="" && row.getCell(i).getStringCellValue().length()>2 && row.getCell(i).getStringCellValue().substring(0, 2).equals("MD")){
                			imgHierarchyDtoObj.setSequence(row.getCell(i).getStringCellValue().substring(2));
                			imgHierarchyDtoObj.setIsMasterData("Y");
                			}else {
                			imgHierarchyDtoObj.setSequence(row.getCell(i).getStringCellValue());
                			imgHierarchyDtoObj.setIsMasterData("N");
                			}
                				
                	 	}else if(i==1){
                			imgHierarchyDtoObj.setIndSeq(row.getCell(i).getStringCellValue());
                				
                	 	}
                		else if(i==2){
                	 		
                	 		imgHierarchyDtoObj.setImgId(row.getCell(i).getStringCellValue());
                	 		
                		}else if(i==3){
                			imgHierarchyDtoObj.setImgDescription(row.getCell(i).getStringCellValue());
                		}else if(i==5){
                			
                			
                    		imgHierarchyDtoObj.setNodeLevel(Integer.parseInt(row.getCell(i).getStringCellValue().substring(1)));
                    		
                    	}
                    	else if(i==7){
                    		imgHierarchyDtoObj.setModule(row.getCell(i).getStringCellValue());
                    	}
                    	else if(i==8){
                    		imgHierarchyDtoObj.setSubModule(row.getCell(i).getStringCellValue());
                    	}
                    	else if(i==9){
                    	}
                    	else if(i==12){
                    		imgHierarchyDtoObj.setTrOverride(row.getCell(i).getStringCellValue());
                    	}
                    	else if(i==13){
                    		imgHierarchyDtoObj.setEnabled(row.getCell(i).getStringCellValue().equals("") ? 0 : Integer.parseInt(row.getCell(i).getStringCellValue()));
                    	}
                    	else if(i==14){
                    		imgHierarchyDtoObj.setcFlag(row.getCell(i).getStringCellValue().equals("") ? 0 : Integer.parseInt(row.getCell(i).getStringCellValue()));
                    	}
                    	else if(i==15){
                     		imgHierarchyDtoObj.setCopyFlag(row.getCell(i).getStringCellValue().equals("")? null :row.getCell(i).getStringCellValue());
                    	}
                    	else if(i==16){
                     		imgHierarchyDtoObj.setCrossIndFlag(row.getCell(i).getStringCellValue().equals("")? 0 :Integer.parseInt(row.getCell(i).getStringCellValue()));
                    	}
                    	else if(i==17){
                     		imgHierarchyDtoObj.setIndFlag(row.getCell(i).getStringCellValue().equals("")? 0 :Integer.parseInt(row.getCell(i).getStringCellValue()));
                    	}
                    	else if(i==18){
                     		imgHierarchyDtoObj.setIndustry(row.getCell(i).getStringCellValue().equals("")? null :row.getCell(i).getStringCellValue());
                    	}
                    	else if(i==19){
                     		imgHierarchyDtoObj.setSubIndustry(row.getCell(i).getStringCellValue().equals("")? null :row.getCell(i).getStringCellValue());
                    	}
                }
                
        	 }
        	 dtoList.add(imgHierarchyDtoObj);
        	
				if (imgHierarchyDtoObj.getImgId() != null && !imgHierarchyDtoObj.getImgId().isEmpty()
						&& imgHierarchyDtoObj.getEnabled() >= 0) {
					if (fieldMappingRecord.isEmpty() || !(fieldMappingRecord
							.contains(imgHierarchyDtoObj.getImgId() + imgHierarchyDtoObj.getEnabled()))) {
						//flag1 = true;
					} else if (fieldMappingRecord
							.contains(imgHierarchyDtoObj.getImgId() + imgHierarchyDtoObj.getEnabled())) {

						
						if(imgHierarchyDtoObj.getEnabled()==0){
							
						}else{
							count++;
                      duplicateimgids.add(count + "."+imgHierarchyDtoObj.getImgId()+"\n");
						}

					}

					fieldMappingRecord.add(imgHierarchyDtoObj.getImgId() + imgHierarchyDtoObj.getEnabled());
				}

			}
        
        
       
        
			if (duplicateimgids.isEmpty()) {
				
				flag = InsertRecordsInDB(dtoList, "ProcessHierarchy");
				if (flag) {
					imgResponseDto.setMessage("Data Successfully Inserted to ImageHirarchy Table!");
				} else {
					imgResponseDto.setMessage("Not able to store Image Hierarchy Data, some database exception occured ");
				}
			} else {
				
				imgResponseDto.setListimgs(duplicateimgids);
				imgResponseDto.setMessage("Duplicate img ids are found , Please rectify and upload again ");
				
			}
      
         	
		}
		catch (FileNotFoundException ex) {
			imgResponseDto.setStatus(ConstantsValues.ERRORSTATUS);
			imgResponseDto.setMessage("Not able to store Image Hierarchy Data ,please contact the Administrator!");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,ex);
		} catch (IOException ex) {
			imgResponseDto.setStatus(ConstantsValues.ERRORSTATUS);
			imgResponseDto.setMessage("Not able to store Image Hierarchy Data ,please contact the Administrator!");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,ex);
		} catch (FileUploadException ex) {
			imgResponseDto.setStatus(ConstantsValues.ERRORSTATUS);
			imgResponseDto.setMessage("Not able to store Image Hierarchy Data ,please contact the Administrator!");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,ex);
		
	}
		finally{
			factory = null;
			fileUpload = null;
			fileItemTemp = null;
			imgHierarchyDtoObj =  null;
			sheet = null;
			rowIterator = null;
			dtoList = null;
			fileItemsList = null;
			fileItemsIterator = null;
			try {
				if(workbook!=null){
				workbook.close();
				}
			} catch (IOException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
			  slf4jLogger.info("insertImgHierarchyData method ended");

		}
		return imgResponseDto;
	}
		
public ImgResponseDto insertFieldMappingData(HttpServletRequest request)  {  
	  	slf4jLogger.info("insertFieldMappingData method started");
		FileItemFactory factory = new DiskFileItemFactory();
		ServletFileUpload fileUpload = new ServletFileUpload(factory);
		FileItem fileItemTemp = null;
		FieldMappingDto fieldMappingDto =  null;
		XSSFWorkbook workbook = null;
		XSSFSheet sheet = null;
		Iterator<Row> rowIterator = null;
		int noOfColumns = 0;
		boolean flag = false;
		ImgResponseDto imgResponseDto = null;
		ArrayList<FieldMappingDto> dtoList = null;
		ArrayList<String> fieldMappingRecord = new ArrayList<String>();
		List <FileItem> fileItemsList = null;
		Iterator <FileItem> fileItemsIterator = null;
		try{
			imgResponseDto = new ImgResponseDto();
		if (ServletFileUpload.isMultipartContent(request)) {
			fileItemsList = fileUpload.parseRequest(request);
			fileItemsIterator = fileItemsList.iterator();
			while (fileItemsIterator.hasNext()) {
			    fileItemTemp = fileItemsIterator.next();
			    if (!fileItemTemp.isFormField()) {
			    	workbook = new XSSFWorkbook(fileItemTemp.getInputStream());								
					}
				}
			}
         sheet = workbook.getSheetAt(0);
         rowIterator = sheet.iterator();
         noOfColumns = sheet.getRow(0).getPhysicalNumberOfCells();
         rowIterator.next();
         rowIterator.next();
         dtoList = new ArrayList<FieldMappingDto>();
         while(rowIterator.hasNext())
         {	
        	
        	 fieldMappingDto = new FieldMappingDto();
        	 Row row = rowIterator.next();
        
        	 for(int i=0;i<noOfColumns;i++)
        	 {
                
                if(row.getCell(i) !=null ){
                	switch(row.getCell(i).getCellType()) 
                	{
                   
                    case Cell.CELL_TYPE_NUMERIC:
                    	if(i==0){
                    		fieldMappingDto.setT_IMGID(Double.toString(row.getCell(i).getNumericCellValue()));
                    	}
                    	else if(i==1){
                    		fieldMappingDto.setT_VIEW(Double.toString(row.getCell(i).getNumericCellValue()));
                    	}
                    	else if(i==2){
                    		fieldMappingDto.setT_FIELD(Double.toString(row.getCell(i).getNumericCellValue()));
                    	}
                    	else if(i==5){
                    		fieldMappingDto.setS_IMGID(Double.toString(row.getCell(i).getNumericCellValue()));
                    	}
                    	else if(i==6){
                    		fieldMappingDto.setS_VIEW(Double.toString(row.getCell(i).getNumericCellValue()));
                    	}
                    	else if(i==7){
                    		fieldMappingDto.setS_FIELD(Double.toString(row.getCell(i).getNumericCellValue()));
                    	}
                    	
                        break;
                    case Cell.CELL_TYPE_STRING:
                    	if(i==0){
                    		fieldMappingDto.setT_IMGID(row.getCell(i).getStringCellValue());
                    	}
                    	else if(i==1){
                    		fieldMappingDto.setT_VIEW(row.getCell(i).getStringCellValue());
                    	}
                    	else if(i==2){
                    		fieldMappingDto.setT_FIELD(row.getCell(i).getStringCellValue());
                    	}
                    	else if(i==5){
                    		fieldMappingDto.setS_IMGID(row.getCell(i).getStringCellValue());
                    	}
                    	else if(i==6){
                    		fieldMappingDto.setS_VIEW(row.getCell(i).getStringCellValue());
                    	}
                    	else if(i==7){
                    		fieldMappingDto.setS_FIELD(row.getCell(i).getStringCellValue());
                    	}
                        break;
                	}
                }
      
            }
            
        	 if(fieldMappingDto.getS_IMGID()!=null && fieldMappingDto.getT_FIELD()!=null && fieldMappingDto.getS_VIEW()!=null && fieldMappingDto.getT_VIEW()!=null && fieldMappingDto.getS_FIELD()!=null && fieldMappingDto.getT_FIELD()!=null){
        		 if(fieldMappingRecord.isEmpty() ||    !fieldMappingRecord.contains(fieldMappingDto.getS_IMGID()+fieldMappingDto.getT_FIELD()+fieldMappingDto.getS_VIEW()+fieldMappingDto.getT_VIEW()+fieldMappingDto.getS_FIELD()+fieldMappingDto.getT_IMGID())){
             		dtoList.add(fieldMappingDto);
             		}
        	 }
        	        	
    		
        	fieldMappingRecord.add(fieldMappingDto.getS_IMGID()+fieldMappingDto.getT_FIELD()+fieldMappingDto.getS_VIEW()+fieldMappingDto.getT_VIEW()+fieldMappingDto.getS_FIELD()+fieldMappingDto.getT_IMGID());


        	}
        
        	flag= InsertFieldMappingRecordsInDB(dtoList);
        	
        	 if(flag)
        		 imgResponseDto.setMessage("Data Successfully Inserted to FieldMapping Table!");
             else
            	 imgResponseDto.setMessage("Not able to store  FieldMapping Data, some database exception occured ");
		}
       
		catch (FileNotFoundException ex) {
			imgResponseDto.setStatus(ConstantsValues.ERRORSTATUS);
			imgResponseDto.setMessage("Not able to store FieldMapping Data ,please contact the Administrator!");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,ex);
		} catch (IOException ex) {
			imgResponseDto.setStatus(ConstantsValues.ERRORSTATUS);
			imgResponseDto.setMessage("Not able to store FieldMapping Data ,please contact the Administrator!");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,ex);
		} catch (FileUploadException ex) {
			imgResponseDto.setStatus(ConstantsValues.ERRORSTATUS);
			imgResponseDto.setMessage("Not able to store Image Hierarchy Data ,please contact the Administrator!");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,ex);
			}
		finally{
			factory = null;
			fileUpload = null;
			fileItemTemp = null;
			fieldMappingDto =  null;
			sheet = null;
			rowIterator = null;
			dtoList = null;
			fileItemsList = null;
			fileItemsIterator = null;
			try {
				if(workbook!=null){
					workbook.close();
				}
				
			} catch (IOException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
			
			  slf4jLogger.info("insertFieldMappingData method ended");

		}
		return imgResponseDto;
	}

public ImgResponseDto insertImgFilterData(HttpServletRequest request)  {  
	slf4jLogger.info("insertImgFilterData method started");
	FileItemFactory factory = new DiskFileItemFactory();
	ServletFileUpload fileUpload = new ServletFileUpload(factory);
	FileItem fileItemTemp = null;
	ImgFilterDataDTO imgFilterDataDTO =  null;
	XSSFWorkbook workbook = null;
	XSSFSheet sheet = null;
	Iterator<Row> rowIterator = null;
	int noOfColumns = 0;
	boolean flag = false;
	ImgResponseDto imgResponseDto = null;
	ArrayList<ImgFilterDataDTO> dtoList = null;
	List <FileItem> fileItemsList = null;
	Iterator <FileItem> fileItemsIterator = null;
	try{
		imgResponseDto = new ImgResponseDto();
	if (ServletFileUpload.isMultipartContent(request)) {
		fileItemsList = fileUpload.parseRequest(request);
		fileItemsIterator = fileItemsList.iterator();
		while (fileItemsIterator.hasNext()) {
		    fileItemTemp = fileItemsIterator.next();
		    if (!fileItemTemp.isFormField()) {
		    	workbook = new XSSFWorkbook(fileItemTemp.getInputStream());								
				}
			}
		}
     sheet = workbook.getSheetAt(0);
     rowIterator = sheet.iterator();
     noOfColumns = sheet.getRow(0).getPhysicalNumberOfCells();
     rowIterator.next();
     dtoList = new ArrayList<ImgFilterDataDTO>();
     while(rowIterator.hasNext())
     {	
    	
    	 imgFilterDataDTO = new ImgFilterDataDTO();
    	 Row row = rowIterator.next();
    
    	 for(int i=0;i<noOfColumns;i++)
    	 {
            
            if(row.getCell(i) !=null ){
            	switch(row.getCell(i).getCellType()) 
            	{
               
                case Cell.CELL_TYPE_NUMERIC:
                	if(i==0){
                		imgFilterDataDTO.setImgId(Double.toString(row.getCell(i).getNumericCellValue()));
                	}
                	else if(i==1){
                		imgFilterDataDTO.setView(Double.toString(row.getCell(i).getNumericCellValue()));
                	}
                	else if(i==2){
                		imgFilterDataDTO.setField(Double.toString(row.getCell(i).getNumericCellValue()));
                	}
                	else if(i==3){
                		imgFilterDataDTO.setValue(Integer.toString((int)row.getCell(i).getNumericCellValue()));
                	}
                	
                    break;
                case Cell.CELL_TYPE_STRING:
                	if(i==0){
                		imgFilterDataDTO.setImgId(row.getCell(i).getStringCellValue());
                	}
                	else if(i==1){
                		imgFilterDataDTO.setView(row.getCell(i).getStringCellValue());
                	}
                	else if(i==2){
                		imgFilterDataDTO.setField(row.getCell(i).getStringCellValue());
                	}
                	else if(i==3){
                		imgFilterDataDTO.setValue(row.getCell(i).getStringCellValue());
                	}
                	
                    break;
            	}
            }
  
        }
         		dtoList.add(imgFilterDataDTO);
    	}
    	flag= InsertFilterValuesInDB(dtoList);
    	
    	 if(flag)
    		 imgResponseDto.setMessage("Data Successfully Inserted to Img Filter Data Table!");
         else
        	 imgResponseDto.setMessage("Not able to store  FieldMapping Data, some database exception occured ");
	}
   
	catch (FileNotFoundException ex) {
			imgResponseDto.setStatus(ConstantsValues.ERRORSTATUS);
			imgResponseDto.setMessage("Not able to store FieldMapping Data ,please contact the Administrator!");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,ex);
	} catch (IOException ex) {
			imgResponseDto.setStatus(ConstantsValues.ERRORSTATUS);
			imgResponseDto.setMessage("Not able to store FieldMapping Data ,please contact the Administrator!");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,ex);
	} catch (FileUploadException ex) {
			imgResponseDto.setStatus(ConstantsValues.ERRORSTATUS);
			imgResponseDto.setMessage("Not able to store Image Hierarchy Data ,please contact the Administrator!");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,ex);
		}
	finally{
		factory = null;
		fileUpload = null;
		fileItemTemp = null;
		imgFilterDataDTO =  null;
		sheet = null;
		rowIterator = null;
		dtoList = null;
		fileItemsList = null;
		fileItemsIterator = null;
		try {
			if(workbook!=null){
			workbook.close();
			}
		} catch (IOException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}
		
		  slf4jLogger.info("insertImgFilterData method ended");

	}
	return imgResponseDto;
}
 
    public  boolean InsertRecordsInDB(ArrayList<ImgHierarchyDto> dtoList,String implType) {
		slf4jLogger.info("InsertRecordsInDB method started");
    	Connection con = DBConnection.createConnection();
        PreparedStatement ps=null;
        PreparedStatement ps2=null;
        PreparedStatement psCP=null;
        PreparedStatement psCP2=null;
        PreparedStatement indDelPs=null;
        PreparedStatement indPs=null;
        boolean indFlag = false;
       
      
        boolean flag = false;
        boolean copyFlag=false;
        boolean crossInd = false;
        String processHierarchyQry="Insert into IMGHIERARCHY(IMGID,IMGDESCR,MODULE,SUBMODULE,SEQUENCING,NODELEVEL,ISMASTERDATA,TRTYPE,ENABLED,C_FIELD) values(?,?,?,?,?,?,?,?,?,?)";
        String imageObjectsQry="INSERT INTO IMGOBJECTS(IMGID,OBJECTTYPE,OBJECTNAME,SEQNO,ISS4IMG,ISECCIMG,SEL_FIELD,C_FIELD,CROSS_IND, INDUSTRY,SUBINDUSTRY) values (?,?,?,?,?,?,?,?,?,?,?)";
        String imgDependencyQry="INSERT INTO IMGDEPENDENCY(IMGID,IMGDESCRIPTION,DEPENDENCYIMGID,DEPENDENCYIMGDESCRIPTION,CROSS_IND,INDUSTRY) values (?,?,?,?,?,?)";
        String scenarioHierarchyQry="Insert into SCENARIO_HIERARCHY(IMGID,IMGDESCR,SEQUENCING,NODETYPE,ENABLED,NODELEVEL,SCENARIO,SUBPROCESS,CONFIGTYPE) values(?,?,?,?,?,?,?,?,?)";
        String indScenarioHierarchyQry="Insert into INDUSTRY_SCENARIOHIERARCHY(IMGID,IMGDESCR,SEQUENCING,NODETYPE,ENABLED,NODELEVEL,SCENARIO,SUBPROCESS,CONFIGTYPE,INDUSTRY,SUBINDUSTRY,IND_SEQ) values(?,?,?,?,?,?,?,?,?,?,?,?)";
        String copyFuntionalityPHQry="Insert into COPYFUNCTIONALITY_IMGHIERARCHY(IMGID,IMGDESCR,MODULE,SUBMODULE,SEQUENCING,NODELEVEL,ISMASTERDATA,TRTYPE,ENABLED,COPY_FIELD) values(?,?,?,?,?,?,?,?,?,?)";
        String copyFuntionalityIMGObjectsQry="INSERT INTO COPYFUNCTIONALITY_IMGOBJECTS(IMGID,OBJECTTYPE,OBJECTNAME,SEQNO,ISS4IMG,ISECCIMG,SEL_FIELD,COPY_FIELD) values (?,?,?,?,?,?,?,?)";
        String indProcessHierarchyQry="Insert into INDUSTRY_IMGHIERARCHY(IMGID,IMGDESCR,MODULE,SUBMODULE,SEQUENCING,NODELEVEL,ISMASTERDATA,TRTYPE,ENABLED,INDUSTRY, SUBINDUSTRY,IND_SEQ) values(?,?,?,?,?,?,?,?,?,?,?,?)";
        String industryQry = "INSERT INTO INDUSTRY_VALUES(INDUSTRY,SUBINDUSTRY,ALIAS_INDUSTRY, ALIAS_SUBINDUSTRY) VALUES (?,?,?,?)"; 

        try {
        	if(implType.equals("ProcessHierarchy")){
        		
        		ps2 = con.prepareStatement("TRUNCATE TABLE IMGHIERARCHY");
        		
        		ps=con.prepareStatement(processHierarchyQry);
        		psCP2 = con.prepareStatement("TRUNCATE TABLE COPYFUNCTIONALITY_IMGHIERARCHY");
        		psCP=con.prepareStatement(copyFuntionalityPHQry);
        		
        		indDelPs = con.prepareStatement("TRUNCATE TABLE INDUSTRY_IMGHIERARCHY");
        		
        		indPs=con.prepareStatement(indProcessHierarchyQry);
        		
        		for(ImgHierarchyDto imgHierarchyDtoObj:dtoList){
        			if(imgHierarchyDtoObj.getCrossIndFlag()==1)
        			{
        				crossInd=true;
                		ps.setString(1, imgHierarchyDtoObj.getImgId() == null ? "" : imgHierarchyDtoObj.getImgId().trim());
                        ps.setString(2, imgHierarchyDtoObj.getImgDescription() == null ? imgHierarchyDtoObj.getImgDescription() : imgHierarchyDtoObj.getImgDescription().trim());
                        ps.setString(3, imgHierarchyDtoObj.getModule() == null ? imgHierarchyDtoObj.getModule() : imgHierarchyDtoObj.getModule().trim());
                        ps.setString(4, imgHierarchyDtoObj.getSubModule() == null ? imgHierarchyDtoObj.getSubModule() : imgHierarchyDtoObj.getSubModule().trim());
                        ps.setString(5, imgHierarchyDtoObj.getSequence() == null ? "" : imgHierarchyDtoObj.getSequence().trim());
                        ps.setInt(6, imgHierarchyDtoObj.getNodeLevel());
                        ps.setString(7, imgHierarchyDtoObj.getIsMasterData() == null ? imgHierarchyDtoObj.getIsMasterData() : imgHierarchyDtoObj.getIsMasterData().trim());
                        ps.setString(8, imgHierarchyDtoObj.getTrOverride() == null ?  "" :  imgHierarchyDtoObj.getTrOverride().trim().toUpperCase());
                        ps.setInt(9, imgHierarchyDtoObj.getEnabled());
                        ps.setInt(10, imgHierarchyDtoObj.getcFlag());
                        ps.addBatch();
                        
                        
        			}if(imgHierarchyDtoObj.getIndFlag()==1){
        				indFlag = true;
        				indPs.setString(1, imgHierarchyDtoObj.getImgId() == null ? "" : imgHierarchyDtoObj.getImgId().trim());
        				indPs.setString(2, imgHierarchyDtoObj.getImgDescription() == null ? imgHierarchyDtoObj.getImgDescription() : imgHierarchyDtoObj.getImgDescription().trim());
        				indPs.setString(3, imgHierarchyDtoObj.getModule() == null ? imgHierarchyDtoObj.getModule() : imgHierarchyDtoObj.getModule().trim());
        				indPs.setString(4, imgHierarchyDtoObj.getSubModule() == null ? imgHierarchyDtoObj.getSubModule() : imgHierarchyDtoObj.getSubModule().trim());
        				indPs.setString(5, imgHierarchyDtoObj.getSequence() == null ? "" : imgHierarchyDtoObj.getSequence().trim());
        				indPs.setInt(6, imgHierarchyDtoObj.getNodeLevel());
        				indPs.setString(7, imgHierarchyDtoObj.getIsMasterData() == null ? imgHierarchyDtoObj.getIsMasterData() : imgHierarchyDtoObj.getIsMasterData().trim());
        				indPs.setString(8, imgHierarchyDtoObj.getTrOverride() == null ?  "" :  imgHierarchyDtoObj.getTrOverride().trim().toUpperCase());
        				indPs.setInt(9, imgHierarchyDtoObj.getEnabled());
        				indPs.setString(10, imgHierarchyDtoObj.getIndustry()==null?imgHierarchyDtoObj.getIndustry():imgHierarchyDtoObj.getIndustry().trim());
        				indPs.setString(11, imgHierarchyDtoObj.getSubIndustry()==null?imgHierarchyDtoObj.getSubIndustry():imgHierarchyDtoObj.getSubIndustry().trim());
        				indPs.setString(12, imgHierarchyDtoObj.getIndSeq()== null ? "" : imgHierarchyDtoObj.getIndSeq().trim());
        				indPs.addBatch();
        			}
                    if(imgHierarchyDtoObj.getCopyFlag()!=null){
        				
                    	copyFlag=true;
                		psCP.setString(1, imgHierarchyDtoObj.getImgId() == null ? "" : imgHierarchyDtoObj.getImgId().trim());
                        psCP.setString(2, imgHierarchyDtoObj.getImgDescription() == null ? imgHierarchyDtoObj.getImgDescription() : imgHierarchyDtoObj.getImgDescription().trim());
                        psCP.setString(3, imgHierarchyDtoObj.getModule() == null ? imgHierarchyDtoObj.getModule() : imgHierarchyDtoObj.getModule().trim());
                        psCP.setString(4, imgHierarchyDtoObj.getSubModule() == null ? imgHierarchyDtoObj.getSubModule() : imgHierarchyDtoObj.getSubModule().trim());
                        psCP.setString(5, imgHierarchyDtoObj.getSequence() == null ? "" : imgHierarchyDtoObj.getSequence().trim());
                        psCP.setInt(6, imgHierarchyDtoObj.getNodeLevel());
                        psCP.setString(7, imgHierarchyDtoObj.getIsMasterData() == null ? imgHierarchyDtoObj.getIsMasterData() : imgHierarchyDtoObj.getIsMasterData().trim());
                        psCP.setString(8, imgHierarchyDtoObj.getTrOverride() == null ?  "" :  imgHierarchyDtoObj.getTrOverride().trim().toUpperCase());
                        psCP.setInt(9, imgHierarchyDtoObj.getEnabled());
                        psCP.setString(10, imgHierarchyDtoObj.getCopyFlag() == null ? "" : imgHierarchyDtoObj.getCopyFlag().trim());
               
                        psCP.addBatch();
                        
                                              
                       
					}
        			
        		}

				if(indFlag) {
					indDelPs.execute();
					indPs.executeBatch();	
				}
				if (copyFlag) {
					psCP2.execute();
					psCP.executeBatch();

				}if(crossInd){
					ps2.execute();
					ps.executeBatch();
				}

			}
                     
                
        
        	else if(implType.equals("ImageObjects")){
        		ps2 = con.prepareStatement("TRUNCATE TABLE IMGOBJECTS");
        		ps=con.prepareStatement(imageObjectsQry);
        		psCP2 = con.prepareStatement("TRUNCATE TABLE COPYFUNCTIONALITY_IMGOBJECTS");
        		psCP=con.prepareStatement(copyFuntionalityIMGObjectsQry);
        		for(ImgHierarchyDto imgHierarchyDtoObj:dtoList){
        			if(imgHierarchyDtoObj.getCopyFlag()==null)
        			{
        				crossInd = true;
        			ps.setString(1, imgHierarchyDtoObj.getImgId() == null ? "" : imgHierarchyDtoObj.getImgId().trim());
                    ps.setString(2, imgHierarchyDtoObj.getObjectType() == null ? imgHierarchyDtoObj.getObjectType() : imgHierarchyDtoObj.getObjectType().trim());
                    ps.setString(3, imgHierarchyDtoObj.getObjectName() == null ? imgHierarchyDtoObj.getObjectName() : imgHierarchyDtoObj.getObjectName().trim());
                    ps.setInt(4, imgHierarchyDtoObj.getImgObjSeq());
                    ps.setString(5, imgHierarchyDtoObj.getIsS4imgType() == null ? imgHierarchyDtoObj.getIsS4imgType() : imgHierarchyDtoObj.getIsS4imgType().trim());
                    ps.setString(6, imgHierarchyDtoObj.getIsECCimgType() == null ? imgHierarchyDtoObj.getIsECCimgType() : imgHierarchyDtoObj.getIsECCimgType().trim());
                    ps.setString(7, imgHierarchyDtoObj.getSelField() == null ? "" : imgHierarchyDtoObj.getSelField().trim());
                    ps.setInt(8, imgHierarchyDtoObj.getcFlag());
                    ps.setInt(9, imgHierarchyDtoObj.getCrossIndFlag());
                    ps.setString(10, imgHierarchyDtoObj.getIndustry()==null?imgHierarchyDtoObj.getIndustry():imgHierarchyDtoObj.getIndustry().trim());
                    ps.setString(11, imgHierarchyDtoObj.getSubIndustry()==null?imgHierarchyDtoObj.getSubIndustry():imgHierarchyDtoObj.getSubIndustry().trim());
                    ps.addBatch();
        			}
        			else
        			{
        				copyFlag=true;
        				psCP.setString(1, imgHierarchyDtoObj.getImgId() == null ? "" : imgHierarchyDtoObj.getImgId().trim());
                        psCP.setString(2, imgHierarchyDtoObj.getObjectType() == null ? imgHierarchyDtoObj.getObjectType() : imgHierarchyDtoObj.getObjectType().trim());
                        psCP.setString(3, imgHierarchyDtoObj.getObjectName() == null ? imgHierarchyDtoObj.getObjectName() : imgHierarchyDtoObj.getObjectName().trim());
                        psCP.setInt(4, imgHierarchyDtoObj.getImgObjSeq());
                        psCP.setString(5, imgHierarchyDtoObj.getIsS4imgType() == null ? imgHierarchyDtoObj.getIsS4imgType() : imgHierarchyDtoObj.getIsS4imgType().trim());
                        psCP.setString(6, imgHierarchyDtoObj.getIsECCimgType() == null ? imgHierarchyDtoObj.getIsECCimgType() : imgHierarchyDtoObj.getIsECCimgType().trim());
                        psCP.setString(7, imgHierarchyDtoObj.getSelField() == null ? "" : imgHierarchyDtoObj.getSelField().trim());
                        psCP.setString(8, imgHierarchyDtoObj.getCopyFlag() == null ? "" : imgHierarchyDtoObj.getCopyFlag().trim());
                        

                        psCP.addBatch();
        			}
            	}
        		
        		if (copyFlag) {
					psCP2.execute();
					

				}if(crossInd) {
					ps2.execute();
					
				}
        	}
        	
        	else if(implType.equals("ImgDependency")){
        		ps2 = con.prepareStatement("TRUNCATE TABLE IMGDEPENDENCY");
        		ps2.execute();
        		ps=con.prepareStatement(imgDependencyQry);
        		for(ImgHierarchyDto imgHierarchyDtoObj:dtoList){
        			if(imgHierarchyDtoObj.getDependencyImgId()!=null && 
        					!imgHierarchyDtoObj.getDependencyImgId().equals("null") 
        					&& imgHierarchyDtoObj.getImgId() !=null 
        					&& !imgHierarchyDtoObj.getImgId().equals("null") )
        			{

        				ps.setString(1, imgHierarchyDtoObj.getImgId() == null ? imgHierarchyDtoObj.getImgId() : imgHierarchyDtoObj.getImgId().trim());
                        ps.setString(2, imgHierarchyDtoObj.getImgDescription() == null ? imgHierarchyDtoObj.getImgDescription() : imgHierarchyDtoObj.getImgDescription().trim());
                        ps.setString(3, imgHierarchyDtoObj.getDependencyImgId() == null ? imgHierarchyDtoObj.getDependencyImgId() : imgHierarchyDtoObj.getDependencyImgId().trim());
                        ps.setString(4, imgHierarchyDtoObj.getDependencyImgIdDesc() == null ? imgHierarchyDtoObj.getDependencyImgIdDesc() : imgHierarchyDtoObj.getDependencyImgIdDesc().trim());
                        ps.setInt(5, imgHierarchyDtoObj.getCrossIndFlag());
                        ps.setInt(6,imgHierarchyDtoObj.getIndFlag()) ;
                        ps.addBatch();

        			}                  
            	}
        	}else if(implType.equals("ScenarioHierarchy")){
        		ps2 = con.prepareStatement("TRUNCATE TABLE SCENARIO_HIERARCHY");
        		
        		indDelPs = con.prepareStatement("TRUNCATE TABLE INDUSTRY_SCENARIOHIERARCHY");
        		
        		ps=con.prepareStatement(scenarioHierarchyQry);
        		indPs=con.prepareStatement(indScenarioHierarchyQry);
        		for(ImgHierarchyDto imgHierarchyDtoObj:dtoList){
        			
        			if(imgHierarchyDtoObj.getCrossIndFlag()==1) {
        				crossInd = true;
        				ps.setString(1, imgHierarchyDtoObj.getImgId() == null ? "" : imgHierarchyDtoObj.getImgId().replace("\\u00a0","").trim());
                        ps.setString(2, imgHierarchyDtoObj.getImgDescription() == null ? imgHierarchyDtoObj.getImgDescription() : imgHierarchyDtoObj.getImgDescription().trim());
                        //ps.setString(3, imgHierarchyDtoObj.getModule() == null ? imgHierarchyDtoObj.getModule() : imgHierarchyDtoObj.getModule().trim());
                        //ps.setString(4, imgHierarchyDtoObj.getSubModule() == null ? imgHierarchyDtoObj.getSubModule() : imgHierarchyDtoObj.getSubModule().trim());
                        ps.setString(3, imgHierarchyDtoObj.getSequence() == null ? "" : imgHierarchyDtoObj.getSequence().trim());
                        ps.setString(4, imgHierarchyDtoObj.getNodetype());
                        //ps.setString(7, imgHierarchyDtoObj.getIsMasterData() == null ? imgHierarchyDtoObj.getIsMasterData() : imgHierarchyDtoObj.getIsMasterData().trim());
                        ps.setInt(5, imgHierarchyDtoObj.getEnabled());
                        ps.setInt(6, imgHierarchyDtoObj.getNodeLevel());
                        ps.setString(7, imgHierarchyDtoObj.getScenario());
                        ps.setString(8, imgHierarchyDtoObj.getSubProcess());
                        ps.setString(9, imgHierarchyDtoObj.getConfigType());
                        ps.addBatch();
        			}
        			if(imgHierarchyDtoObj.getIndFlag()==1) {
        				indFlag = true;
        				indPs.setString(1, imgHierarchyDtoObj.getImgId() == null ? "" : imgHierarchyDtoObj.getImgId().replaceAll("\\u00a0","").trim());
        				indPs.setString(2, imgHierarchyDtoObj.getImgDescription() == null ? imgHierarchyDtoObj.getImgDescription() : imgHierarchyDtoObj.getImgDescription().trim());
        				indPs.setString(3, imgHierarchyDtoObj.getSequence() == null ? "" : imgHierarchyDtoObj.getSequence().trim());
        				indPs.setString(4, imgHierarchyDtoObj.getNodetype());
        				indPs.setInt(5, imgHierarchyDtoObj.getEnabled());
        				indPs.setInt(6, imgHierarchyDtoObj.getNodeLevel());
        				indPs.setString(7, imgHierarchyDtoObj.getScenario());
        				indPs.setString(8, imgHierarchyDtoObj.getSubProcess());
        				indPs.setString(9, imgHierarchyDtoObj.getConfigType());
        				indPs.setString(10, imgHierarchyDtoObj.getIndustry()==null?"":imgHierarchyDtoObj.getIndustry().trim());
        				indPs.setString(11, imgHierarchyDtoObj.getSubIndustry()==null?"":imgHierarchyDtoObj.getSubIndustry().trim());
        				indPs.setString(12, imgHierarchyDtoObj.getIndSeq()== null ? "" : imgHierarchyDtoObj.getIndSeq().trim());
        				indPs.addBatch();
        			}
                		
                	}
        		
        		if(indFlag) {
					indDelPs.execute();
				}
        		if(crossInd) {
        			ps2.execute();
        		}
                     
                }
        	

        	else if(implType.equals("Industry")){
        		
        		ps2 = con.prepareStatement("TRUNCATE TABLE INDUSTRY_VALUES");
        		ps2.execute();
        		indPs=con.prepareStatement(industryQry);
        		for(ImgHierarchyDto imgHierarchyDtoObj:dtoList){
        			indFlag=true;
        			indPs.setString(1, imgHierarchyDtoObj.getIndustry()==null?imgHierarchyDtoObj.getIndustry(): imgHierarchyDtoObj.getIndustry().trim());
        			indPs.setString(2, imgHierarchyDtoObj.getSubIndustry()==null?imgHierarchyDtoObj.getSubIndustry():imgHierarchyDtoObj.getSubIndustry().trim());
        			indPs.setString(3, imgHierarchyDtoObj.getAliasIndustry()==null?imgHierarchyDtoObj.getAliasIndustry():imgHierarchyDtoObj.getAliasIndustry().trim());
        			indPs.setString(4, imgHierarchyDtoObj.getAliasSubIndustry()==null?imgHierarchyDtoObj.getAliasSubIndustry():imgHierarchyDtoObj.getAliasSubIndustry().trim());
        			indPs.addBatch();

        			                
            	}
        	}
        	if(!implType.equals("ProcessHierarchy") && ps!=null) {
        		ps.executeBatch();
            	
        	}     
        	if(indFlag) {
        		indPs.executeBatch();
        	}
        	if(copyFlag)
        	{
        		psCP.executeBatch();
        		
        	}
        	flag=true;
        } catch (SQLException e) {
        	
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}
       finally{
    		if (ps2 != null) {
	            try {
	            	ps2.close();
	            	ps2 = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }
    		if (indDelPs != null) {
	            try {
	            	indDelPs.close();
	            	indDelPs = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }
    		if (ps != null) {
	            try {
	            	ps.close();
	            	ps = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }
    		if (indPs != null) {
	            try {
	            	indPs.close();
	            	indPs = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }
    		if (psCP2 != null) {
	            try {
	            	psCP2.close();
	            	psCP2 = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }
    		
    		if (psCP != null) {
	            try {
	            	psCP.close();
	            	psCP = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }
	        if (con != null) {
	            try {
	            	con.close();
	            	con = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }
			  slf4jLogger.info("InsertRecordsInDB method ended");

       }
   
	return flag;
    }
    
   
    
    public  boolean InsertFieldMappingRecordsInDB(ArrayList<FieldMappingDto> dtoList) {
		slf4jLogger.info("InsertFieldMappingRecordsInDB method started");
    	Connection con = DBConnection.createConnection();
        PreparedStatement ps=null;
        PreparedStatement ps2=null;
        boolean flag = false;
        String fieldMappingQry="Insert into FIELDMAPPING(S_IMGID,T_IMGID,S_VIEW,T_VIEW,S_FIELD,T_FIELD) values(?,?,?,?,?,?)";
        try {
        		ps2 = con.prepareStatement("TRUNCATE TABLE FIELDMAPPING");
    			ps2.execute();
        		ps=con.prepareStatement(fieldMappingQry);
        		for(FieldMappingDto fieldMappingDto:dtoList){
                		ps.setString(1, fieldMappingDto.getS_IMGID() == null ? fieldMappingDto.getS_IMGID() : fieldMappingDto.getS_IMGID().trim());
                        ps.setString(2, fieldMappingDto.getT_IMGID() == null ? fieldMappingDto.getT_IMGID() : fieldMappingDto.getT_IMGID().trim());
                        ps.setString(3, fieldMappingDto.getS_VIEW() == null ? fieldMappingDto.getS_VIEW() : fieldMappingDto.getS_VIEW().trim());
                        ps.setString(4, fieldMappingDto.getT_VIEW() == null ? fieldMappingDto.getT_VIEW() : fieldMappingDto.getT_VIEW().trim());
                        ps.setString(5, fieldMappingDto.getS_FIELD() == null ? fieldMappingDto.getS_FIELD() :fieldMappingDto.getS_FIELD().trim());
                        ps.setString(6, fieldMappingDto.getT_FIELD() == null ? fieldMappingDto.getT_FIELD() : fieldMappingDto.getT_FIELD().trim());
                        ps.addBatch();
        		}
                
       ps.executeBatch();
       flag=true;
        } catch (SQLException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}
        finally{
        	
        	if(ps2!=null){
				try {
					ps2.close();
					ps2=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			if(ps!=null){
				try {
					ps.close();
					ps=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("InsertFieldMappingRecordsInDB method ended");

		}
       
   
	return flag;
    }
    
    public  boolean InsertFilterValuesInDB(ArrayList<ImgFilterDataDTO> dtoList) {
		slf4jLogger.info("InsertFilterValuesInDB method started");
    	Connection con = DBConnection.createConnection();
        PreparedStatement ps=null;
        PreparedStatement ps2=null;
        boolean flag = false;
        String fieldMappingQry="Insert into IMGFilter(IMGID,VIEWNAME,FIELDNAME,FIELDVALUE) values(?,?,?,?)";
        try {
        		ps2 = con.prepareStatement("TRUNCATE TABLE IMGFilter");
    			ps2.execute();
        		ps=con.prepareStatement(fieldMappingQry);
        		for(ImgFilterDataDTO imgFilterDataDTO:dtoList){
                		ps.setString(1, imgFilterDataDTO.getImgId() == null ? "" : imgFilterDataDTO.getImgId().trim());
                        ps.setString(2, imgFilterDataDTO.getView() == null ? "" : imgFilterDataDTO.getView().trim());
                        ps.setString(3, imgFilterDataDTO.getField() == null ? "" : imgFilterDataDTO.getField().trim());
                        ps.setString(4, imgFilterDataDTO.getValue() == null ? "" : imgFilterDataDTO.getValue().trim());
                       
                        ps.addBatch();
        		}
                
       ps.executeBatch();
       flag=true;
        } catch (SQLException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}
        finally{
        	
        	if(ps2!=null){
				try {
					ps2.close();
					ps2=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
			if(ps!=null){
				try {
					ps.close();
					ps=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("InsertFilterValuesInDB method ended");

		}
	return flag;
    }
    
    public ImgResponseDto previewImgHierarchyCopyFunctionality(String implType)  {
		slf4jLogger.info("previewImgHierarchy method started");
    	Connection con = null;
		ResponseDto responseDtoObj = new ResponseDto();
		ArrayList<ImgHierarchyDto> imgHierarchyData = new ArrayList<ImgHierarchyDto>();
		ArrayList<FieldMappingDto> fieldMappingData = new ArrayList<FieldMappingDto>();
		
		ResultSet rs=null;
		PreparedStatement pStmt=null;
		ImgHierarchyDto imgHierarchyDtoObj;
		FieldMappingDto fieldMappingDto;
		ImgResponseDto imgResponseDto = new ImgResponseDto();
		boolean status = false;
		try{
			con = DBConnection.createConnection();
			if(implType.equals("ProcessHierarchy")){
				pStmt = (PreparedStatement) con.prepareStatement("SELECT * FROM COPYFUNCTIONALITY_IMGHIERARCHY ORDER BY ID");
				rs = pStmt.executeQuery();
				while(rs.next()){
					status = true;
					imgHierarchyDtoObj = new ImgHierarchyDto();
					imgHierarchyDtoObj.setId(rs.getInt("ID"));
					imgHierarchyDtoObj.setImgId(rs.getString("IMGID"));
					imgHierarchyDtoObj.setImgDescription(rs.getString("IMGDESCR"));
					imgHierarchyDtoObj.setModule((rs.getString("MODULE"))==null?"":rs.getString("MODULE"));
					imgHierarchyDtoObj.setSubModule((rs.getString("SUBMODULE"))==null?"":rs.getString("SUBMODULE"));
					imgHierarchyDtoObj.setSequence(rs.getString("SEQUENCING"));
					imgHierarchyDtoObj.setNodeLevel(rs.getInt("NODELEVEL"));
					imgHierarchyData.add(imgHierarchyDtoObj);
					
				}
				if(!status){
					imgHierarchyDtoObj = new ImgHierarchyDto();
					responseDtoObj.setMessage("No Data Available!!");
					responseDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
					imgHierarchyData.add(imgHierarchyDtoObj);
					}
			}
			else if(implType.equals("ImageObjects")){
				pStmt = (PreparedStatement) con.prepareStatement("SELECT * FROM COPYFUNCTIONALITY_IMGOBJECTS");
				rs = pStmt.executeQuery();
				while(rs.next()){
					status = true;
					imgHierarchyDtoObj = new ImgHierarchyDto();
					imgHierarchyDtoObj.setImgId(rs.getString("IMGID"));
					imgHierarchyDtoObj.setObjectType(rs.getString("OBJECTTYPE"));
					imgHierarchyDtoObj.setObjectName(rs.getString("OBJECTNAME"));
					imgHierarchyDtoObj.setImgObjSeq(rs.getInt("SEQNO"));
					imgHierarchyDtoObj.setIsS4imgType(rs.getString("ISS4IMG"));
					imgHierarchyDtoObj.setIsECCimgType(rs.getString("ISECCIMG"));
					imgHierarchyData.add(imgHierarchyDtoObj);

				}
				if(!status){
					imgHierarchyDtoObj = new ImgHierarchyDto();
					responseDtoObj.setMessage("No Data Available!!");
					responseDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
					imgHierarchyData.add(imgHierarchyDtoObj);
					}
			}
				
			imgResponseDto.setListImgHierarchyDto(imgHierarchyData);
		}
		catch (SQLException e){
			fieldMappingDto = new FieldMappingDto();
			fieldMappingDto.setStatus(ConstantsValues.ERRORSTATUS);
			fieldMappingDto.setMessage("Not able to fetch Img Hierrachy Data ,please contact the Administrator!");
			fieldMappingData.add(fieldMappingDto);
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}finally{
			if(rs!=null){
				try {
					rs.close();
					rs= null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("previewImgHierarchy method ended");

		}
			return imgResponseDto;
	}
    public ImgResponseDto previewImgHierarchy(String implType)  {
		slf4jLogger.info("previewImgHierarchy method started");
    	Connection con = null;
		ResponseDto responseDtoObj = new ResponseDto();
		ArrayList<ImgHierarchyDto> imgHierarchyData = new ArrayList<ImgHierarchyDto>();
		ArrayList<FieldMappingDto> fieldMappingData = new ArrayList<FieldMappingDto>();
		
		ResultSet rs=null;
		PreparedStatement pStmt=null;
		ImgHierarchyDto imgHierarchyDtoObj;
		FieldMappingDto fieldMappingDto;
		ImgResponseDto imgResponseDto = new ImgResponseDto();
		boolean status = false;
		try{
			con = DBConnection.createConnection();
			if(implType.equals("ProcessHierarchy")){
				pStmt = (PreparedStatement) con.prepareStatement("SELECT * FROM IMGHIERARCHY ORDER BY ID");
				rs = pStmt.executeQuery();
				while(rs.next()){
					status = true;
					imgHierarchyDtoObj = new ImgHierarchyDto();
					imgHierarchyDtoObj.setId(rs.getInt("ID"));
					imgHierarchyDtoObj.setImgId(rs.getString("IMGID"));
					imgHierarchyDtoObj.setImgDescription(rs.getString("IMGDESCR"));
					imgHierarchyDtoObj.setModule((rs.getString("MODULE"))==null?"":rs.getString("MODULE"));
					imgHierarchyDtoObj.setSubModule((rs.getString("SUBMODULE"))==null?"":rs.getString("SUBMODULE"));
					imgHierarchyDtoObj.setSequence(rs.getString("SEQUENCING"));
					imgHierarchyDtoObj.setNodeLevel(rs.getInt("NODELEVEL"));
					imgHierarchyData.add(imgHierarchyDtoObj);
					
				}
				if(!status){
					imgHierarchyDtoObj = new ImgHierarchyDto();
					responseDtoObj.setMessage("No Data Available!!");
					responseDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
					imgHierarchyData.add(imgHierarchyDtoObj);
					}
			}
			else if(implType.equals("ImageObjects")){
				pStmt = (PreparedStatement) con.prepareStatement("SELECT * FROM IMGOBJECTS");
				rs = pStmt.executeQuery();
				while(rs.next()){
					status = true;
					imgHierarchyDtoObj = new ImgHierarchyDto();
					imgHierarchyDtoObj.setImgId(rs.getString("IMGID"));
					imgHierarchyDtoObj.setObjectType(rs.getString("OBJECTTYPE"));
					imgHierarchyDtoObj.setObjectName(rs.getString("OBJECTNAME"));
					imgHierarchyDtoObj.setImgObjSeq(rs.getInt("SEQNO"));
					imgHierarchyDtoObj.setIsS4imgType(rs.getString("ISS4IMG"));
					imgHierarchyDtoObj.setIsECCimgType(rs.getString("ISECCIMG"));
					imgHierarchyData.add(imgHierarchyDtoObj);

				}
				if(!status){
					imgHierarchyDtoObj = new ImgHierarchyDto();
					responseDtoObj.setMessage("No Data Available!!");
					responseDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
					imgHierarchyData.add(imgHierarchyDtoObj);
					}
			}
			
			else if(implType.equals("ImgDependency")){
				pStmt = (PreparedStatement) con.prepareStatement("SELECT * FROM IMGDEPENDENCY");
				rs = pStmt.executeQuery();
				while(rs.next()){
					status = true;
					imgHierarchyDtoObj = new ImgHierarchyDto();
					imgHierarchyDtoObj.setImgId(rs.getString("IMGID"));
					imgHierarchyDtoObj.setDependencyImgId(rs.getString("DEPENDENCYIMGID"));
					imgHierarchyDtoObj.setImgDescription(rs.getString("IMGDESCRIPTION"));
					imgHierarchyDtoObj.setDependencyImgIdDesc(rs.getString("DEPENDENCYIMGDESCRIPTION"));
					imgHierarchyData.add(imgHierarchyDtoObj);

				}
				if(!status){
					imgHierarchyDtoObj = new ImgHierarchyDto();
					responseDtoObj.setMessage("No Data Available!!");
					responseDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
					imgHierarchyData.add(imgHierarchyDtoObj);

				}
			}
			
			else if(implType.equals("FieldMapping")){
				pStmt = (PreparedStatement) con.prepareStatement("SELECT * FROM FIELDMAPPING");
				rs = pStmt.executeQuery();
				while(rs.next()){
					status = true;
					fieldMappingDto = new FieldMappingDto();
					fieldMappingDto.setS_IMGID(rs.getString("S_IMGID"));
					fieldMappingDto.setT_IMGID(rs.getString("T_IMGID"));
					fieldMappingDto.setS_FIELD(rs.getString("S_FIELD"));
					fieldMappingDto.setT_FIELD(rs.getString("T_FIELD"));
					fieldMappingDto.setS_VIEW(rs.getString("S_VIEW"));
					fieldMappingDto.setT_VIEW(rs.getString("T_VIEW"));
					fieldMappingData.add(fieldMappingDto);

				}
				if(!status){
					fieldMappingDto = new FieldMappingDto();
					fieldMappingDto.setMessage("No Data Available!!");
					fieldMappingDto.setStatus(ConstantsValues.ERRORSTATUS);
					fieldMappingData.add(fieldMappingDto);

				}
			}else if(implType.equals("ScenarioHierarchy")){
				pStmt = (PreparedStatement) con.prepareStatement("SELECT * FROM SCENARIO_HIERARCHY ORDER BY ID");
				rs = pStmt.executeQuery();
				while(rs.next()){
					status = true;
					imgHierarchyDtoObj = new ImgHierarchyDto();
					imgHierarchyDtoObj.setId(rs.getInt("ID"));
					imgHierarchyDtoObj.setImgId(rs.getString("IMGID"));
					imgHierarchyDtoObj.setImgDescription(rs.getString("IMGDESCR"));
					//imgHierarchyDtoObj.setModule((rs.getString("MODULE"))==null?"":rs.getString("MODULE"));
					///imgHierarchyDtoObj.setSubModule((rs.getString("SUBMODULE"))==null?"":rs.getString("SUBMODULE"));
					imgHierarchyDtoObj.setSequence(rs.getString("SEQUENCING"));
					imgHierarchyDtoObj.setNodeLevel(rs.getInt("NODELEVEL"));
					imgHierarchyDtoObj.setScenario(rs.getString("SCENARIO"));
					imgHierarchyDtoObj.setSubProcess(rs.getString("SUBPROCESS"));
					imgHierarchyData.add(imgHierarchyDtoObj);
					
				}
				if(!status){
					imgHierarchyDtoObj = new ImgHierarchyDto();
					responseDtoObj.setMessage("No Data Available!!");
					responseDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
					imgHierarchyData.add(imgHierarchyDtoObj);
					}
			}
			
			imgResponseDto.setListImgHierarchyDto(imgHierarchyData);
		}
		catch (SQLException e){
			fieldMappingDto = new FieldMappingDto();
			fieldMappingDto.setStatus(ConstantsValues.ERRORSTATUS);
			fieldMappingDto.setMessage("Not able to fetch Img Hierrachy Data ,please contact the Administrator!");
			fieldMappingData.add(fieldMappingDto);
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}finally{
			if(rs!=null){
				try {
					rs.close();
					rs= null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("previewImgHierarchy method ended");

		}
			return imgResponseDto;
	}
    
    public ImgResponseDto previewIndustryData(String implType)  {
  		slf4jLogger.info("previewIndustryData method started");
      	Connection con = null;
  		ResponseDto responseDtoObj = new ResponseDto();
  		ArrayList<ImgHierarchyDto> imgHierarchyData = new ArrayList<ImgHierarchyDto>();
  		ArrayList<FieldMappingDto> fieldMappingData = new ArrayList<FieldMappingDto>();
  		
  		ResultSet rs=null;
  		PreparedStatement pStmt=null;
  		ImgHierarchyDto imgHierarchyDtoObj;
  		FieldMappingDto fieldMappingDto;
  		ImgResponseDto imgResponseDto = new ImgResponseDto();
  		boolean status = false;
  		try{
  			con = DBConnection.createConnection();
  			
  			
  			if(implType.equals("Industry")){
  				pStmt = (PreparedStatement) con.prepareStatement("SELECT * FROM INDUSTRY_VALUES");
  				rs = pStmt.executeQuery();
  				while(rs.next()){
  					status = true;
  					imgHierarchyDtoObj = new ImgHierarchyDto();
  					imgHierarchyDtoObj.setIndustry(rs.getString("INDUSTRY"));
  					imgHierarchyDtoObj.setSubIndustry(rs.getString("SUBINDUSTRY"));
  					
  					imgHierarchyData.add(imgHierarchyDtoObj);
  					
  				}
  				if(!status){
  					imgHierarchyDtoObj = new ImgHierarchyDto();
  					responseDtoObj.setMessage("No Data Available!!");
  					responseDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
  					imgHierarchyData.add(imgHierarchyDtoObj);
  					}
  			}
  			
  			imgResponseDto.setListImgHierarchyDto(imgHierarchyData);
  		}
  		catch (SQLException e){
  			fieldMappingDto = new FieldMappingDto();
  			fieldMappingDto.setStatus(ConstantsValues.ERRORSTATUS);
  			fieldMappingDto.setMessage("Not able to fetch Industry Data ,please contact the Administrator!");
  			fieldMappingData.add(fieldMappingDto);
  			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
  		}finally{
  			if(rs!=null){
  				try {
  					rs.close();
  					rs= null;
  					} catch (SQLException e) {
  					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
  				}
  			}
  			if(pStmt!=null){
  				try {
  					pStmt.close();
  					pStmt=null;
  					} catch (SQLException e) {
  					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
  				}
  			}
  			if(con!=null){
  				try {
  					con.close();
  					con=null;
  					} catch (SQLException e) {
  					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
  				}
  			}
  			  slf4jLogger.info("previewIndustryData method ended");

  		}
  			return imgResponseDto;
  	}
    
    public ImgResponseDto previewFieldMapping(String implType)  {
		slf4jLogger.info("previewFieldMapping method started");
    	Connection con = null;
		ArrayList<FieldMappingDto> fieldMappingData = new ArrayList<FieldMappingDto>();
		ResultSet rs=null;
		PreparedStatement pStmt=null;
		FieldMappingDto fieldMappingDto;
		ImgResponseDto imgResponseDto = new ImgResponseDto();
		boolean status = false;
		try{
			con = DBConnection.createConnection();
				if(implType.equals("FieldMapping")){
				pStmt = (PreparedStatement) con.prepareStatement("SELECT * FROM FIELDMAPPING");
				rs = pStmt.executeQuery();
				while(rs.next()){
					status = true;
					fieldMappingDto = new FieldMappingDto();
					fieldMappingDto.setS_IMGID(rs.getString("S_IMGID"));
					fieldMappingDto.setT_IMGID(rs.getString("T_IMGID"));
					fieldMappingDto.setS_FIELD(rs.getString("S_FIELD"));
					fieldMappingDto.setT_FIELD(rs.getString("T_FIELD"));
					fieldMappingDto.setS_VIEW(rs.getString("S_VIEW"));
					fieldMappingDto.setT_VIEW(rs.getString("T_VIEW"));
					fieldMappingData.add(fieldMappingDto);

				}
				if(!status){
					fieldMappingDto = new FieldMappingDto();
					fieldMappingDto.setMessage("No Data Available!!");
					fieldMappingDto.setStatus(ConstantsValues.ERRORSTATUS);
					fieldMappingData.add(fieldMappingDto);

				}
			}
			
				imgResponseDto.setListFieldMappingDto(fieldMappingData);
		}
		catch (SQLException e){
			fieldMappingDto = new FieldMappingDto();
			fieldMappingDto.setStatus(ConstantsValues.ERRORSTATUS);
			fieldMappingDto.setMessage("Not able to fetch Img Hierrachy Data ,please contact the Administrator!");
			fieldMappingData.add(fieldMappingDto);
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}finally{
			if(rs!=null){
				try {
					rs.close();
					rs= null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("previewFieldMapping method ended");

		}	
		
		return imgResponseDto;
	}
    
    public ImgResponseDto previewImgFilterData(String implType)  {
		slf4jLogger.info("previewImgFilterData method started");
    	Connection con = null;
		ArrayList<ImgFilterDataDTO> imgFilterData = new ArrayList<ImgFilterDataDTO>();
		ResultSet rs=null;
		PreparedStatement pStmt=null;
		ImgFilterDataDTO imgFilterDataDTO;
		ImgResponseDto imgResponseDto = new ImgResponseDto();
		boolean status = false;
		try{
			con = DBConnection.createConnection();

			
				if(implType.equals("ImgFilterData")){
				pStmt = (PreparedStatement) con.prepareStatement("SELECT IMGID,VIEWNAME,FIELDNAME,FIELDVALUE FROM IMGFilter");
				rs = pStmt.executeQuery();
				while(rs.next()){
					status = true;
					imgFilterDataDTO = new ImgFilterDataDTO();
					imgFilterDataDTO.setImgId(rs.getString("IMGID"));
					imgFilterDataDTO.setView(rs.getString("VIEWNAME"));
					imgFilterDataDTO.setField(rs.getString("FIELDNAME"));
					imgFilterDataDTO.setValue(rs.getString("FIELDVALUE"));
					imgFilterData.add(imgFilterDataDTO);

				}
				if(!status){
					imgFilterDataDTO = new ImgFilterDataDTO();
					imgFilterDataDTO.setMessage("No Data Available!!");
					imgFilterDataDTO.setStatus(ConstantsValues.ERRORSTATUS);
					imgFilterData.add(imgFilterDataDTO);

				}
			}
				
				imgResponseDto.setListImgFilterDataDTO(imgFilterData);
			
		}
		catch (SQLException e){
			imgFilterDataDTO = new ImgFilterDataDTO();
			imgFilterDataDTO.setStatus(ConstantsValues.ERRORSTATUS);
			imgFilterDataDTO.setMessage("Not able to fetch Img Hierrachy Data ,please contact the Administrator!");
			imgFilterData.add(imgFilterDataDTO);
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}finally{
			if(rs!=null){
				try {
					rs.close();
					rs= null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("previewImgFilterData method ended");

		}	
		
		return imgResponseDto;
	}
    
    public List<ImgHierarchyDto> getDependencyImgId(String imgId)  {
		slf4jLogger.info("getDependencyImgId method started");
    	Connection con = null;
		ResponseDto responseDtoObj = new ResponseDto();
		ArrayList<ImgHierarchyDto> imgHierarchyData = new ArrayList<ImgHierarchyDto>();
		ResultSet rs=null;
		PreparedStatement pStmt=null;
		ImgHierarchyDto imgHierarchyDtoObj;
		boolean status = false;
		try{
			con = DBConnection.createConnection();
			pStmt = (PreparedStatement) con.prepareStatement("SELECT * FROM IMGDEPENDENCY WHERE IMGID=?");
			pStmt.setString(1,imgId);
				rs = pStmt.executeQuery();
				while(rs.next()){
					status = true;
					imgHierarchyDtoObj = new ImgHierarchyDto();
					imgHierarchyDtoObj.setImgId(rs.getString("IMGID"));
					imgHierarchyDtoObj.setImgDescription(rs.getString("IMGDESCRIPTION"));
					imgHierarchyDtoObj.setDependencyImgId(rs.getString("DEPENDENCYIMGID"));
					imgHierarchyDtoObj.setDependencyImgIdDesc(rs.getString("DEPENDENCYIMGDESCRIPTION"));

				}
				if(!status)
					responseDtoObj.setMessage("No Data Available!!");
			responseDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
			
		}
		catch (SQLException e){
			responseDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
			responseDtoObj.setMessage("Not able to fetch Users ,please contact the Administrator!");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}finally{
			if(rs!=null){
				try {
					rs.close();
					rs= null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("getDependencyImgId method ended");

		}	
		
		return new  ArrayList<ImgHierarchyDto>(imgHierarchyData);
	}
    
    
   
    
    public ImgResponseDto getDependencyImg(ImgHierarchyDto imgHierarchyDto)  {
		slf4jLogger.info("getDependencyImg method started");
    	Connection con = null;
		ResultSet rs=null;
		PreparedStatement pStmt=null;
		ImgHierarchyDto imgHierarchyDtoObj = null;
		boolean status = false;
		int length = 0;
		List<String > imgIds = imgHierarchyDto.getInputImgId();
		List<ImgHierarchyDto> listImgHierarchyDto= new ArrayList<ImgHierarchyDto>();
		StringBuilder imgDependency ;
		ImgResponseDto imgResponseDto = new ImgResponseDto();
		
		if(imgHierarchyDto.isIndustryFlag()) {
			imgDependency = new StringBuilder("SELECT IMGID,DEPENDENCYIMGID,IMGDESCRIPTION,DEPENDENCYIMGDESCRIPTION FROM IMGDEPENDENCY WHERE INDUSTRY=1 AND DEPENDENCYIMGID NOT IN (");
		}else {
			imgDependency = new StringBuilder("SELECT IMGID,DEPENDENCYIMGID,IMGDESCRIPTION,DEPENDENCYIMGDESCRIPTION FROM IMGDEPENDENCY WHERE CROSS_IND=1 AND DEPENDENCYIMGID NOT IN (");
		}
		
		StringBuilder inputImgId = new StringBuilder();
		try{
			length = imgIds.size(); 
			for(int i=0;i<length;i++){
				if(i==length-1)
					inputImgId.append("?)");
				else
					inputImgId.append("?,");
			}

			imgDependency.append(inputImgId).append(" AND IMGID IN ( ").append(inputImgId);

			con = DBConnection.createConnection();
			pStmt = con.prepareStatement(imgDependency.toString());
			int pos = 1;		
			for(int i=0;i<length;i++,pos++){
				pStmt.setString (pos, imgIds.get(i));				
			}
			for(int i=0;i<length;i++,pos++){
				pStmt.setString (pos, imgIds.get(i));				
			}
				rs = pStmt.executeQuery();
				while(rs.next()){
					status = true;
					imgHierarchyDtoObj = new ImgHierarchyDto();
					imgHierarchyDtoObj.setImgId(rs.getString("IMGID"));
					imgHierarchyDtoObj.setDependencyImgId(rs.getString("DEPENDENCYIMGID"));
					imgHierarchyDtoObj.setImgDescription(rs.getString("IMGDESCRIPTION"));
					imgHierarchyDtoObj.setDependencyImgIdDesc(rs.getString("DEPENDENCYIMGDESCRIPTION"));
					listImgHierarchyDto.add(imgHierarchyDtoObj);

				}

				imgResponseDto.setListImgHierarchyDto(listImgHierarchyDto);
				if(!status){
					imgHierarchyDtoObj = new ImgHierarchyDto();
					imgHierarchyDtoObj.setMessage("No Data Available!!");
				imgHierarchyDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
				}
			
		}
		catch (SQLException e){
			imgHierarchyDtoObj = new ImgHierarchyDto();
			imgHierarchyDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
			imgHierarchyDtoObj.setMessage("Not able to fetch Img Hierrachy Data ,please contact the Administrator!");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}finally{
			listImgHierarchyDto = null;
			imgDependency = null;
			inputImgId = null;
			if(rs!=null){
				try {
					rs.close();
					rs= null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("getDependencyImg method ended");

		}	
		return imgResponseDto;
	}
    
    
    public ImgResponseDto imgDependencyImport(HttpServletRequest request)  {
		 slf4jLogger.info("imgDependencyImport method started");
		 FileItemFactory factory = new DiskFileItemFactory();
		 ServletFileUpload fileUpload = new ServletFileUpload(factory);
		 FileItem fileItemTemp = null;
		 ImgHierarchyDto imgHierarchyDtoObj =  null;
		 XSSFWorkbook workbook = null;
		 XSSFSheet sheet = null;
		 Iterator<Row> rowIterator = null;
		 int noOfColumns = 0;
		 boolean flag = false;
		 ImgResponseDto imgResponseDto = null;
		 ArrayList<ImgHierarchyDto> dtoList = null;
		 ArrayList<String> imgAndDependency = null;
		 List <FileItem> fileItemsList = null;
		 Iterator <FileItem> fileItemsIterator = null;
		 String fileName = null;
		 try{
			imgResponseDto = new ImgResponseDto();
			if(ServletFileUpload.isMultipartContent(request)) {
			fileItemsList = fileUpload.parseRequest(request);
			fileItemsIterator = fileItemsList.iterator();
			while (fileItemsIterator.hasNext()) {
			    fileItemTemp = fileItemsIterator.next();
			    fileName = fileItemTemp.getName();
			    if(fileName != null && !fileName.equals("") && (fileName.split("\\.")[1].equals("xlsx") ||  fileName.split("\\.")[1].equals("xls"))){
			    if (!fileItemTemp.isFormField()) {
			    	workbook = new XSSFWorkbook(fileItemTemp.getInputStream());								
					}
			    }
				}
			}
         sheet = workbook.getSheetAt(1);
         rowIterator = sheet.iterator();
         noOfColumns = sheet.getRow(0).getPhysicalNumberOfCells();
         rowIterator.next();
        dtoList = new ArrayList<ImgHierarchyDto>(); 
    	imgAndDependency = new ArrayList<>();

        while(rowIterator.hasNext())
        {	
        	 imgHierarchyDtoObj = new ImgHierarchyDto();
            Row row = rowIterator.next();
        
            for(int i=0;i<noOfColumns;i++)
            {
            	if(row.getCell(i) !=null ){
                	switch(row.getCell(i).getCellType()) 
                	{
                  
                    case Cell.CELL_TYPE_NUMERIC:
                    	if(i==0){
                    		imgHierarchyDtoObj.setImgId(Double.toString(row.getCell(i).getNumericCellValue()));
                    	}
                    	else if(i==1){
                    		imgHierarchyDtoObj.setImgDescription(Double.toString(row.getCell(i).getNumericCellValue()));
                    	}
                    	else if(i==2){
                    		imgHierarchyDtoObj.setDependencyImgId(Double.toString(row.getCell(i).getNumericCellValue()));
                    	}
                    	else if(i==3){
                    		imgHierarchyDtoObj.setDependencyImgIdDesc(Double.toString(row.getCell(i).getNumericCellValue()));
                    	}
                    	else if(i==4){
                     		imgHierarchyDtoObj.setCrossIndFlag(Double.toString(row.getCell(i).getNumericCellValue()).equals("")?0:(int)row.getCell(i).getNumericCellValue());
                     	}
                    	else if(i==5){
                     		imgHierarchyDtoObj.setIndFlag(Double.toString(row.getCell(i).getNumericCellValue()).equals("")?0:(int)row.getCell(i).getNumericCellValue());
                     	}
                        break;
                    case Cell.CELL_TYPE_STRING:
                    	 if(i==0){
                    		imgHierarchyDtoObj.setImgId(row.getCell(i).getStringCellValue());
                    	}
                    	else if(i==1){
                    		imgHierarchyDtoObj.setImgDescription(row.getCell(i).getStringCellValue());
                    	}
                    	else if(i==2){
                    		imgHierarchyDtoObj.setDependencyImgId(row.getCell(i).getStringCellValue());
                    	}
                    	else if(i==3){
                    		imgHierarchyDtoObj.setDependencyImgIdDesc(row.getCell(i).getStringCellValue());
                    	}
                    	else if(i==4){
                     		imgHierarchyDtoObj.setCrossIndFlag(row.getCell(i).getStringCellValue().equals("")? 0 :Integer.parseInt(row.getCell(i).getStringCellValue()));
                    	}
                    	else if(i==5){
                     		imgHierarchyDtoObj.setIndFlag(row.getCell(i).getStringCellValue().equals("")? 0 :Integer.parseInt(row.getCell(i).getStringCellValue()));
                    	}
                        break;
                	}
            	}
      
            }
            
            	if(imgAndDependency.isEmpty()|| !imgAndDependency.contains(imgHierarchyDtoObj.getImgId()+imgHierarchyDtoObj.getDependencyImgId())){
            		imgAndDependency.add(imgHierarchyDtoObj.getImgId()+imgHierarchyDtoObj.getDependencyImgId());
                dtoList.add(imgHierarchyDtoObj);
                }
           
          
        	}
    	
    	flag= InsertRecordsInDB(dtoList,"ImgDependency");

    	 if(flag){
    		 imgResponseDto.setMessage("Data Successfully Inserted to Dependency Table!");
    		 imgResponseDto.setMessage("Success");
    	 }
          else
        	 imgResponseDto.setMessage("Not able to store Image Hierarchy Data, some database exception occured ");
    	 }
       
		catch (FileNotFoundException ex) {
			imgResponseDto.setStatus(ConstantsValues.ERRORSTATUS);
			imgResponseDto.setMessage("Not able to store Image Hierarchy Data ,please contact the Administrator!");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,ex);
		} catch (IOException ex) {
			imgResponseDto.setStatus(ConstantsValues.ERRORSTATUS);
			imgResponseDto.setMessage("Not able to store Image Hierarchy Data ,please contact the Administrator!");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,ex);
		} catch (FileUploadException ex) {
			imgResponseDto.setStatus(ConstantsValues.ERRORSTATUS);
			imgResponseDto.setMessage("Not able to store Image Hierarchy Data ,please contact the Administrator!");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,ex);
		
	}
		finally{
			factory = null;
			fileUpload = null;
			fileItemTemp = null;
			imgHierarchyDtoObj =  null;
			sheet = null;
			rowIterator = null;
			dtoList = null;
			imgAndDependency = null;
			fileItemsList = null;
			fileItemsIterator = null;
			try {
				workbook.close();
			} catch (IOException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
			  slf4jLogger.info("imgDependencyImport method ended");

		}
		return imgResponseDto;
	}
    
public ImgResponseDto insertImgObjectsData(HttpServletRequest request)  { 
	 	slf4jLogger.info("insertImgObjectsData method started");
		FileItemFactory factory = new DiskFileItemFactory();
		ServletFileUpload fileUpload = new ServletFileUpload(factory);
		FileItem fileItemTemp = null;
		ImgHierarchyDto imgHierarchyDtoObj =  null;
		XSSFWorkbook workbook = null;
		XSSFSheet sheet = null;
		Iterator<Row> rowIterator = null;
		int noOfColumns = 0;
		boolean flag = false;
		ImgResponseDto imgResponseDto = null;
		ArrayList<ImgHierarchyDto> dtoList = null;
		List <FileItem> fileItemsList = null;
		Iterator <FileItem> fileItemsIterator = null;
		String fileName = null;
		try{
			imgResponseDto = new ImgResponseDto();
		if (ServletFileUpload.isMultipartContent(request)) {
			fileItemsList = fileUpload.parseRequest(request);
			fileItemsIterator = fileItemsList.iterator();
			while (fileItemsIterator.hasNext()) {
			    fileItemTemp = fileItemsIterator.next();
			    fileName = fileItemTemp.getName();
			    if(fileName != null && !fileName.equals("") && (fileName.split("\\.")[1].equals("xlsx") ||  fileName.split("\\.")[1].equals("xls"))){
			   
			    if (!fileItemTemp.isFormField()) {
			    	workbook = new XSSFWorkbook(fileItemTemp.getInputStream());								
					}
			    }
				}
			}
         sheet = workbook.getSheetAt(0);
         rowIterator = sheet.iterator();
         noOfColumns = sheet.getRow(0).getPhysicalNumberOfCells();
         rowIterator.next();
         dtoList = new ArrayList<ImgHierarchyDto>();
         ArrayList<String> scopeName = new ArrayList<String>();
         ArrayList<String> copyScopeName = new ArrayList<String>();
         while(rowIterator.hasNext())
         {	
         	
         	 imgHierarchyDtoObj = new ImgHierarchyDto();
             Row row = rowIterator.next();
         
             for(int i=0;i<noOfColumns;i++)
             {
            	 if(row.getCell(i) !=null ){
                 	switch(row.getCell(i).getCellType()) 
                 	{
                    
                     case Cell.CELL_TYPE_NUMERIC:
                     	if(i==0){
                     		imgHierarchyDtoObj.setImgId(Double.toString(row.getCell(i).getNumericCellValue()));
                     	}
                     	else if(i==1){
                     		imgHierarchyDtoObj.setObjectName(Double.toString(row.getCell(i).getNumericCellValue()));
                     	}
                     	else if(i==2){
                     		imgHierarchyDtoObj.setObjectType(Double.toString(row.getCell(i).getNumericCellValue()));
                     	}
                     	else if(i==3){
                     		imgHierarchyDtoObj.setImgObjSeq((int)(row.getCell(i).getNumericCellValue()));
                     	}
                     	else if(i==4){
                     		imgHierarchyDtoObj.setIsS4imgType(Double.toString(row.getCell(i).getNumericCellValue()));
                     	}
                     	else if(i==5){
                     		imgHierarchyDtoObj.setIsECCimgType(Double.toString(row.getCell(i).getNumericCellValue()));
                     	}
                     	else if(i==6){
                     		imgHierarchyDtoObj.setSelField(Integer.toString((int)row.getCell(i).getNumericCellValue()));
                     	}
                     	else if(i==7){
                     		imgHierarchyDtoObj.setcFlag(Double.toString(row.getCell(i).getNumericCellValue()).equals("")?0:(int)row.getCell(i).getNumericCellValue());                  		
                     	}
                     	else if(i==10){
                     		imgHierarchyDtoObj.setCopyFlag(Integer.toString((int)row.getCell(i).getNumericCellValue()));
                     	}
                     	else if(i==11){
                     		imgHierarchyDtoObj.setCrossIndFlag(Double.toString(row.getCell(i).getNumericCellValue()).equals("")?0:(int)row.getCell(i).getNumericCellValue());
                     	}
                     	else if(i==12){
                     		imgHierarchyDtoObj.setIndustry(Integer.toString((int)row.getCell(i).getNumericCellValue()));
                     	}
                     	else if(i==13){
                     		imgHierarchyDtoObj.setSubIndustry(Integer.toString((int)row.getCell(i).getNumericCellValue()));
                     	}
                         break;
                     case Cell.CELL_TYPE_STRING:
                     	 if(i==0){
                     		imgHierarchyDtoObj.setImgId(row.getCell(i).getStringCellValue());
                     	}
                     	else if(i==1){
                     		imgHierarchyDtoObj.setObjectName(row.getCell(i).getStringCellValue());
                     	}
                     	else if(i==2){
                     		imgHierarchyDtoObj.setObjectType(row.getCell(i).getStringCellValue());
                     	}
                     	else if(i==3){
                     		imgHierarchyDtoObj.setImgObjSeq(Integer.parseInt(row.getCell(i).getStringCellValue()));
                     	}
                     	else if(i==4){
                     		imgHierarchyDtoObj.setIsS4imgType(row.getCell(i).getStringCellValue());
                     	}
                     	else if(i==5){
                     		imgHierarchyDtoObj.setIsECCimgType(row.getCell(i).getStringCellValue());
                     	}
                     	else if(i==6){
                     		imgHierarchyDtoObj.setSelField(row.getCell(i).getStringCellValue());
                     	}
                     	else if(i==7){
                     		imgHierarchyDtoObj.setcFlag(row.getCell(i).getStringCellValue().equals("")?0:Integer.parseInt(row.getCell(i).getStringCellValue()));
                     	}
                     	else if(i==10){
                     		imgHierarchyDtoObj.setCopyFlag(row.getCell(i).getStringCellValue());
                     	}
                     	else if(i==11){
                     		imgHierarchyDtoObj.setCrossIndFlag(row.getCell(i).getStringCellValue().equals("")?0:Integer.parseInt(row.getCell(i).getStringCellValue()));
                     	}
                     	else if(i==12){
                     		imgHierarchyDtoObj.setIndustry(row.getCell(i).getStringCellValue());
                     	}
                     	else if(i==13){
                     		imgHierarchyDtoObj.setSubIndustry(row.getCell(i).getStringCellValue());
                     	}
                         break;
                 	}
            	 }
       
             }
             
             if(imgHierarchyDtoObj.getCopyFlag()!=null && !imgHierarchyDtoObj.getCopyFlag().isEmpty()) {
            	 
            	 if(copyScopeName.isEmpty() ||  !copyScopeName.contains(imgHierarchyDtoObj.getImgId()+imgHierarchyDtoObj.getObjectName()+imgHierarchyDtoObj.getObjectType())){
                	 dtoList.add(imgHierarchyDtoObj);

    				}
            	 copyScopeName.add(imgHierarchyDtoObj.getImgId()+imgHierarchyDtoObj.getObjectName()+imgHierarchyDtoObj.getObjectType());
             }
             else {
            	 if(scopeName.isEmpty() ||  !scopeName.contains(imgHierarchyDtoObj.getImgId()+imgHierarchyDtoObj.getObjectName()+imgHierarchyDtoObj.getObjectType())){
            		 dtoList.add(imgHierarchyDtoObj);

            	 }
            	 scopeName.add(imgHierarchyDtoObj.getImgId()+imgHierarchyDtoObj.getObjectName()+imgHierarchyDtoObj.getObjectType());

             	}
         	}
             	
         
             
             flag= InsertRecordsInDB(dtoList,"ImageObjects");
         if(flag)
        	 imgResponseDto.setMessage("Data Successfully Inserted to ImageObjects Table!");
         else
        	 imgResponseDto.setMessage("Not able to store ImageObjects Data, some database exception occured ");

 		}
		catch (FileNotFoundException ex) {
			imgResponseDto.setStatus(ConstantsValues.ERRORSTATUS);
			imgResponseDto.setMessage("Not able to store ImageObjects Data ,please contact the Administrator!");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,ex);
		} catch (IOException ex) {
			imgResponseDto.setStatus(ConstantsValues.ERRORSTATUS);
			imgResponseDto.setMessage("Not able to store ImageObjects Data ,please contact the Administrator!");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,ex);
		} catch (FileUploadException ex) {
			imgResponseDto.setStatus(ConstantsValues.ERRORSTATUS);
			imgResponseDto.setMessage("Not able to store ImageObjects Data ,please contact the Administrator!");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,ex);
		
		}
		finally{
			factory = null;
			fileUpload = null;
			fileItemTemp = null;
			imgHierarchyDtoObj =  null;
			sheet = null;
			rowIterator = null;
			dtoList = null;
			fileItemsList = null;
			fileItemsIterator = null;
			try {
				if(workbook != null)
				workbook.close();
			} catch (IOException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
			  slf4jLogger.info("insertImgObjectsData method ended");

		}
		return imgResponseDto;
	}

public ArrayList<SequenceDto> returnConfigData(ArrayList<SequenceDto> listSequenceDto){
	Collections.sort(listSequenceDto, new Comparator<SequenceDto>(){
		   public int compare(SequenceDto o1, SequenceDto o2){
		      return o1.getSequence() - o2.getSequence();
		   }
		});
	return listSequenceDto;
}

public DownloadScopeResDto getInputStringForBrownFldForCopy(String imgId,String systemType)  {
	slf4jLogger.info("getInputStringForBrownFld method started");
	Connection con = null;
	ResultSet rs=null;
	PreparedStatement pStmt=null;
	ArrayList<String> inputScope= new ArrayList<String>();
	
  	String dbName = null;
  	String inputImgId = null;

  	DownloadScopeResDto downloadScopeResDto = new DownloadScopeResDto();
	try{
    	PropMappings propObj = PropMappings.getInstance();

    	con = DBConnection.createConnection();
       	
		dbName = propObj.getValue("S4CONFIGHANA_DB");
		
		if(dbName.equals("SAPHANA")){
			if(systemType.equals("SAP ECC")){
				inputImgId = "SELECT SEQNO||'|'||IMGID||'|'||OBJECTNAME||'|'||OBJECTTYPE||'||'||SEL_FIELD \"SCOPENAME\",SEL_FIELD, OBJECTNAME FROM COPYFUNCTIONALITY_IMGOBJECTS WHERE IMGID=? AND ISECCIMG=?";
			}
			else if (systemType.equals("S4 HANA")){
				inputImgId = "SELECT SEQNO||'|'||IMGID||'|'||OBJECTNAME||'|'||OBJECTTYPE||'||'||SEL_FIELD \"SCOPENAME\",SEL_FIELD, OBJECTNAME FROM COPYFUNCTIONALITY_IMGOBJECTS WHERE IMGID=?";			
			}
		}
			else {
				if (systemType.equals("SAP ECC")) {
					inputImgId = "SELECT CONCAT(SEQNO,'|',IMGID,'|',OBJECTNAME,'|',OBJECTTYPE,'||',SEL_FIELD) SCOPENAME, SEL_FIELD, OBJECTNAME FROM COPYFUNCTIONALITY_IMGOBJECTS WHERE IMGID=? AND ISECCIMG=?";			

				}else if (systemType.equals("S4 HANA")) {
					inputImgId = "SELECT CONCAT(SEQNO,'|',IMGID,'|',OBJECTNAME,'|',OBJECTTYPE,'||',SEL_FIELD) SCOPENAME, SEL_FIELD, OBJECTNAME FROM COPYFUNCTIONALITY_IMGOBJECTS WHERE IMGID=?";		
				}
			}
		
		pStmt =  con.prepareStatement(inputImgId);
		pStmt.setString(1, imgId);
		if(systemType.equals("SAP ECC")){
			pStmt.setString(2, "Y");
		}
		
			rs = pStmt.executeQuery();
			downloadScopeResDto.setImgId(imgId);
			downloadScopeResDto.setScopeAvailable("N");
			while(rs.next()){
			
				inputScope.add(rs.getString("SCOPENAME"));
				}
			downloadScopeResDto.setImgScope(inputScope);
			if(inputScope.size()>=1)
				downloadScopeResDto.setScopeAvailable("Y");
			else
				downloadScopeResDto.setScopeAvailable("N");

		
	}
	catch (SQLException e){
		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	}finally{
		dbName = null;
		inputImgId = null;
		inputScope = null;
		if(rs!=null){
			try {
				rs.close();
				rs= null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		if(pStmt!=null){
			try {
				pStmt.close();
				pStmt=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		if(con!=null){
			try {
				con.close();
				con=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		  slf4jLogger.info("getInputStringForBrownFld method ended");

	}	
	return downloadScopeResDto;
}

public DownloadScopeResDto getInputStringForBrownFld(String imgId,String systemType)  {
	slf4jLogger.info("getInputStringForBrownFld method started");
	Connection con = null;
	ResultSet rs=null;
	PreparedStatement pStmt=null;
	ArrayList<String> inputScope= new ArrayList<String>();
	
  	String dbName = null;
  	String inputImgId = null;

  	DownloadScopeResDto downloadScopeResDto = new DownloadScopeResDto();
	try{
    	PropMappings propObj = PropMappings.getInstance();

    	con = DBConnection.createConnection();
       	
		dbName = propObj.getValue("S4CONFIGHANA_DB");
		if(dbName.equals("SAPHANA")){
			if(systemType.equals("SAP ECC")){
				inputImgId = "SELECT SEQNO||'|'||IMGID||'|'||OBJECTNAME||'|'||OBJECTTYPE \"SCOPENAME\" FROM IMGOBJECTS WHERE IMGID= ? AND ISECCIMG=? AND CROSS_IND=?";
			}
			else if (systemType.equals("S4 HANA")){
				inputImgId = "SELECT SEQNO||'|'||IMGID||'|'||OBJECTNAME||'|'||OBJECTTYPE \"SCOPENAME\" FROM IMGOBJECTS WHERE IMGID=? AND CROSS_IND=?";
			}
				

		}
		else{
			if(systemType.equals("SAP ECC"))
				inputImgId = "SELECT CONCAT(SEQNO,'|',IMGID,'|',OBJECTNAME,'|',OBJECTTYPE) SCOPENAME FROM IMGOBJECTS WHERE IMGID=? AND ISECCIMG=? AND CROSS_IND=?";
			else if (systemType.equals("S4 HANA"))
				inputImgId = "SELECT CONCAT(SEQNO,'|',IMGID,'|',OBJECTNAME,'|',OBJECTTYPE) SCOPENAME FROM IMGOBJECTS WHERE IMGID=? AND CROSS_IND=?";

		}
			
		
		pStmt =  con.prepareStatement(inputImgId);
		pStmt.setString(1, imgId);
		if(systemType.equals("SAP ECC")){
			pStmt.setString(2, "Y");
			pStmt.setInt(3, 1);
		}else {
			pStmt.setInt(2, 1);
		}
		
			rs = pStmt.executeQuery();
			downloadScopeResDto.setImgId(imgId);
			downloadScopeResDto.setScopeAvailable("N");
			while(rs.next()){
			
				inputScope.add(rs.getString("SCOPENAME"));
				}
			downloadScopeResDto.setImgScope(inputScope);
			if(inputScope.size()>=1)
				downloadScopeResDto.setScopeAvailable("Y");
			else
				downloadScopeResDto.setScopeAvailable("N");

		
	}
	catch (SQLException e){
		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	}finally{
		dbName = null;
		inputImgId = null;
		inputScope = null;
		if(rs!=null){
			try {
				rs.close();
				rs= null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		if(pStmt!=null){
			try {
				pStmt.close();
				pStmt=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		if(con!=null){
			try {
				con.close();
				con=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		  slf4jLogger.info("getInputStringForBrownFld method ended");

	}	
	return downloadScopeResDto;
}


public DownloadScopeResDto getInputStringForBrownFldForIndustry(String imgId,String systemType, String industry, String subIndustry)  {
	slf4jLogger.info("getInputStringForBrownFldForIndustry method started");
	Connection con = null;
	ResultSet rs=null;
	PreparedStatement pStmt=null;
	ArrayList<String> inputScope= new ArrayList<String>();
	
  	String dbName = null;
  	String inputImgId = null;

  	DownloadScopeResDto downloadScopeResDto = new DownloadScopeResDto();
	try{
    	PropMappings propObj = PropMappings.getInstance();

    	con = DBConnection.createConnection();
       	
		dbName = propObj.getValue("S4CONFIGHANA_DB");
		if(dbName.equals("SAPHANA")){
			if(systemType.equals("SAP ECC")){
				inputImgId = "SELECT SEQNO||'|'||IMGID||'|'||OBJECTNAME||'|'||OBJECTTYPE \"SCOPENAME\" FROM IMGOBJECTS WHERE IMGID= ? AND ISECCIMG=? and INDUSTRY LIKE ? AND SUBINDUSTRY LIKE ?";
			}
			else if (systemType.equals("S4 HANA")){
				inputImgId = "SELECT SEQNO||'|'||IMGID||'|'||OBJECTNAME||'|'||OBJECTTYPE \"SCOPENAME\" FROM IMGOBJECTS WHERE IMGID=? AND INDUSTRY LIKE ? AND SUBINDUSTRY LIKE ?";
			}
				

		}
		else{
			if(systemType.equals("SAP ECC"))
				inputImgId = "SELECT CONCAT(SEQNO,'|',IMGID,'|',OBJECTNAME,'|',OBJECTTYPE) SCOPENAME FROM IMGOBJECTS WHERE IMGID=? AND ISECCIMG=? and INDUSTRY LIKE ? AND SUBINDUSTRY LIKE ?";
			else if (systemType.equals("S4 HANA"))
				inputImgId = "SELECT CONCAT(SEQNO,'|',IMGID,'|',OBJECTNAME,'|',OBJECTTYPE) SCOPENAME FROM IMGOBJECTS WHERE IMGID=? AND INDUSTRY LIKE ? AND SUBINDUSTRY LIKE ?";

		}
			
		
		pStmt =  con.prepareStatement(inputImgId);
		pStmt.setString(1, imgId);
		if(systemType.equals("SAP ECC")){
			pStmt.setString(2, "Y");
			pStmt.setString(3, "%" + industry + "%");
			pStmt.setString(4, "%" + subIndustry + "%");
		}else {
			pStmt.setString(2, "%" + industry + "%");
			pStmt.setString(3, "%" + subIndustry + "%");
		}
		
			rs = pStmt.executeQuery();
			downloadScopeResDto.setImgId(imgId);
			downloadScopeResDto.setScopeAvailable("N");
			while(rs.next()){
			
				inputScope.add(rs.getString("SCOPENAME"));
				}
			downloadScopeResDto.setImgScope(inputScope);
			if(inputScope.size()>=1)
				downloadScopeResDto.setScopeAvailable("Y");
			else
				downloadScopeResDto.setScopeAvailable("N");

		
	}
	catch (SQLException e){
		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	}finally{
		dbName = null;
		inputImgId = null;
		inputScope = null;
		if(rs!=null){
			try {
				rs.close();
				rs= null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		if(pStmt!=null){
			try {
				pStmt.close();
				pStmt=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		if(con!=null){
			try {
				con.close();
				con=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		  slf4jLogger.info("getInputStringForBrownFldForIndustry method ended");

	}	
	return downloadScopeResDto;
}

public DownloadScopeResDto getInputStringForBrownFldCopyFunctionality(String imgId,String systemType)  {
	slf4jLogger.info("getInputStringForBrownFld method started");
	Connection con = null;
	ResultSet rs=null;
	PreparedStatement pStmt=null;
	ArrayList<String> inputScope= new ArrayList<String>();
	
  	String dbName = null;
  	String inputImgId = null;

  	DownloadScopeResDto downloadScopeResDto = new DownloadScopeResDto();
	try{
    	PropMappings propObj = PropMappings.getInstance();

    	con = DBConnection.createConnection();
       	
		dbName = propObj.getValue("S4CONFIGHANA_DB");
		if(dbName.equals("SAPHANA")){
			if(systemType.equals("SAP ECC")){
				inputImgId = "SELECT SEQNO||'|'||IMGID||'|'||OBJECTNAME||'|'||OBJECTTYPE \"SCOPENAME\" FROM COPYFUNCTIONALITY_IMGOBJECTS WHERE IMGID= ? AND ISECCIMG=?";
			}
			else if (systemType.equals("S4 HANA")){
				inputImgId = "SELECT SEQNO||'|'||IMGID||'|'||OBJECTNAME||'|'||OBJECTTYPE \"SCOPENAME\" FROM COPYFUNCTIONALITY_IMGOBJECTS WHERE IMGID=?";
			}
				

		}
		else{
			if(systemType.equals("SAP ECC"))
				inputImgId = "SELECT CONCAT(SEQNO,'|',IMGID,'|',OBJECTNAME,'|',OBJECTTYPE) SCOPENAME FROM COPYFUNCTIONALITY_IMGOBJECTS WHERE IMGID=? AND ISECCIMG=?";
			else if (systemType.equals("S4 HANA"))
				inputImgId = "SELECT CONCAT(SEQNO,'|',IMGID,'|',OBJECTNAME,'|',OBJECTTYPE) SCOPENAME FROM COPYFUNCTIONALITY_IMGOBJECTS WHERE IMGID=?";

		}
			
		
		pStmt =  con.prepareStatement(inputImgId);
		pStmt.setString(1, imgId);
		if(systemType.equals("SAP ECC")){
			pStmt.setString(2, "Y");
		}
		
			rs = pStmt.executeQuery();
			downloadScopeResDto.setImgId(imgId);
			downloadScopeResDto.setScopeAvailable("N");
			while(rs.next()){
			
				inputScope.add(rs.getString("SCOPENAME"));
				}
			downloadScopeResDto.setImgScope(inputScope);
			if(inputScope.size()>=1)
				downloadScopeResDto.setScopeAvailable("Y");
			else
				downloadScopeResDto.setScopeAvailable("N");

		
	}
	catch (SQLException e){
		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	}finally{
		dbName = null;
		inputImgId = null;
		inputScope = null;
		if(rs!=null){
			try {
				rs.close();
				rs= null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		if(pStmt!=null){
			try {
				pStmt.close();
				pStmt=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		if(con!=null){
			try {
				con.close();
				con=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		  slf4jLogger.info("getInputStringForBrownFld method ended");

	}	
	return downloadScopeResDto;
}

public String getfileNameForInputImg(String imgId)  {
	slf4jLogger.info("getfileNameForInputImg method started");
	Connection con = null;
	ResultSet rs=null;
	PreparedStatement pStmt=null;
	String filename= null;
  	String dbName = null;

	String inputImgId = null;
	try{
    	PropMappings propObj = PropMappings.getInstance();

		dbName = propObj.getValue("S4CONFIGHANA_DB");
		if(dbName.equals("SAPHANA"))
			inputImgId = "SELECT SEQUENCING||'_'||IMGDESCR \"FILENAME\" FROM IMGHIERARCHY WHERE IMGID=?";
		else
			inputImgId = "SELECT CONCAT(SEQUENCING,'_',IMGDESCR) FILENAME FROM IMGHIERARCHY WHERE IMGID=?";
		con = DBConnection.createConnection();
		pStmt = con.prepareStatement(inputImgId);
		pStmt.setString(1, imgId);
			rs = pStmt.executeQuery();
			while(rs.next()){
				filename = rs.getString("FILENAME");

			}
		
	}
	catch (SQLException e){
		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	}finally{
		dbName = null;
		
		inputImgId = null;
		if(rs!=null){
			try {
				rs.close();
				rs= null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		if(pStmt!=null){
			try {
				pStmt.close();
				pStmt=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		if(con!=null){
			try {
				con.close();
				con=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		  slf4jLogger.info("getfileNameForInputImg method ended");

	}	
	
	return filename;
}

public ImgHierarchyDto getIMGTemplatesPath()  {
	ImgHierarchyDto imgHierarchyDto = new ImgHierarchyDto();
	ResMessageDto resMessageDto = new ResMessageDto();
	slf4jLogger.info("getIMGTemplatesPath method started");
	try{
	HCPDocDAO hcpDocDAOobj = new HCPDocDAO();
	HCPDocServiceResDto objHCPDocServiceResDto = new HCPDocServiceResDto();
	objHCPDocServiceResDto = hcpDocDAOobj.getDocumentIds();
	if(objHCPDocServiceResDto.getStatus()){
		resMessageDto.setMsgType(ConstantsValues.SUCCESSSTATUS);
	}
	else{
		resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
		resMessageDto.setMessage(ConstantsValues.NOTEMPLATES);
	}
	imgHierarchyDto.setResMessageDto(resMessageDto);
	}catch(Exception e){
		resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
		resMessageDto.setMessage(ConstantsValues.NOTEMPLATES);
		  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	}finally{
		  slf4jLogger.info("getIMGTemplatesPath method ended");
	}
	return imgHierarchyDto;
}

public ImgResponseDto getIMGTemplatesPath(ImgHierarchyCustomDto imgHierarchyCustomDto)  { 
	slf4jLogger.info("getIMGTemplatesPath method started");
	ImgHierarchyDto imgHierarchyDto = new ImgHierarchyDto();
	ArrayList<ImgHierarchyDto> imgHierarchyDtoList= new ArrayList<>();
	HCPDocDAO hcpDocDAOobj = new HCPDocDAO();
	HCPDocServiceResDto objHCPDocServiceResDto = new HCPDocServiceResDto();
	ImgResponseDto imgResponseDto = new ImgResponseDto();
	ResMessageDto resMessageDto = new ResMessageDto();
	try {
	objHCPDocServiceResDto = hcpDocDAOobj.getDocumentIds(imgHierarchyCustomDto.getSelectedScopes(),imgHierarchyCustomDto.isIndustry());
	int docLength = objHCPDocServiceResDto.getImgIds().size();
					for(int k=0;k<docLength;k++){
	        			imgHierarchyDto = new ImgHierarchyDto();
		        			imgHierarchyDto.setImgDescription( objHCPDocServiceResDto.getImgIds().get(k));
		        			imgHierarchyDtoList.add(imgHierarchyDto);
					}
			if(docLength > 0){
				resMessageDto.setMsgType(ConstantsValues.SUCCESSSTATUS);
				resMessageDto.setMessage(ConstantsValues.SUCCESSSTATUS);
				
			}else{
				resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
				resMessageDto.setMessage(ConstantsValues.ERRORSTATUS);
			}
			imgResponseDto.setResMessageDto(resMessageDto);			
	imgResponseDto.setListImgHierarchyDto(imgHierarchyDtoList);
					
	} catch (Exception e) {
		resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
		resMessageDto.setMessage(ConstantsValues.NOTEMPLATES);
		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	}
	finally{
		imgHierarchyDto = null;
		hcpDocDAOobj = null;
		objHCPDocServiceResDto = null;
		slf4jLogger.info("getIMGTemplatesPath method ended");
	}

	return imgResponseDto;
}

public HCPDocServiceResDto checkTemplatesExists(ImgHierarchyCustomDto imgHierarchyCustomDto)  { 
	slf4jLogger.info("checkTemplatesExists method started");
	HCPDocDAO hcpDocDAOobj = new HCPDocDAO();
	HCPDocServiceResDto objHCPDocServiceResDto = new HCPDocServiceResDto();
	try{
		objHCPDocServiceResDto = hcpDocDAOobj.checkTemplatesExists(imgHierarchyCustomDto);
	}catch(Exception e){
		  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	}finally{
		hcpDocDAOobj = null;
		slf4jLogger.info("checkTemplatesExists method ended");

	}
	return objHCPDocServiceResDto;
}


public ImgResponseDto downloadTemplates(ImgHierarchyCustomDto imgHierarchyCustomDto)  { 
	ImgHierarchyDto imgHierarchyDto = new ImgHierarchyDto();
	ArrayList<ImgHierarchyDto> imgHierarchyDtoList= new ArrayList<>();
	ByteArrayOutputStream bos = null;
    XSSFWorkbook workbook = null;
	HCPDocDAO hcpDocDAOobj = new HCPDocDAO();
	Document document=null;
	InputStream stream = null;
	byte[] bytes  = null;
	HCPDocServiceResDto objHCPDocServiceResDto = null;
	ImgResponseDto imgResponseDto = new ImgResponseDto();
	try {
	objHCPDocServiceResDto = new HCPDocServiceResDto();
	objHCPDocServiceResDto = hcpDocDAOobj.getDocumentIds(imgHierarchyCustomDto.getSelectedScopes(),imgHierarchyCustomDto.isIndustry() );
	
	int docLength = objHCPDocServiceResDto.getDocIds().size();
					for(int k=0;k<docLength;k++){
	        			imgHierarchyDto = new ImgHierarchyDto();
	        			bos = new ByteArrayOutputStream();
	        			
	        					imgHierarchyDto.setImgDescription(objHCPDocServiceResDto.getImgIds().get(k));
	        					/*Session openCmisSession = HCPDocDAO.ConnectDocumentStore();
	        					document = (Document) openCmisSession.getObject(objHCPDocServiceResDto.getDocIds().get(k));
	        					stream = document.getContentStream().getStream();*/
	        					 Connection con = null;
	        					 PreparedStatement pStmt=null;
	        					 ResultSet rs=null;
	        					 String storeDocIdQuery="";
	        					 if(imgHierarchyCustomDto.isIndustry()) {
	        						 
	        						 storeDocIdQuery = "select file_blob from industry_documentstore where IMGDESC=?";
	        					 }else {
	        						storeDocIdQuery = "select file_blob from documentstore where IMGDESC=?";
	        					 }
	        					  	
	        					  	
	        					  	
	        						try{
	        							con = DBConnection.createConnection();
	        							pStmt = (PreparedStatement) con.prepareStatement(storeDocIdQuery);
	        							pStmt.setString(1,objHCPDocServiceResDto.getImgIds().get(k).replaceAll("[^a-zA-Z0-9]", "").toLowerCase());
	        							rs = pStmt.executeQuery();
	        							while(rs.next()){
	        								stream = rs.getBinaryStream("file_blob");
	        								//stream1 = rs.getBinaryStream("file_blob");
	        								slf4jLogger.info("file stream"+stream);
	        							}
	        						}catch(Exception e){
	        							
	        						}
	        					workbook = new XSSFWorkbook(stream);
	        					workbook.write(bos);
	        					bytes = bos.toByteArray();
	        					imgHierarchyDto.setBytes(bytes);
	        					imgHierarchyDtoList.add(imgHierarchyDto);
					}
					
					imgResponseDto.setListImgHierarchyDto(imgHierarchyDtoList);
					
	} catch (Exception e) {
		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	}
	finally{
		imgHierarchyDto = null;
		try {
			if(workbook != null)
			workbook.close();
			if(stream != null)
			stream.close();
			if(bos != null)
				bos.close();
			bos = null;
		} catch (IOException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}
		bos = null;
		workbook = null;
		hcpDocDAOobj = null;
		stream = null;
		document = null;
		objHCPDocServiceResDto = null;
		bytes = null;
	}
	return imgResponseDto;
}



public boolean  getDependencyScope(ArrayList<ImgDownloadDto> scopeList,String currentScope)  {
	Connection con = null;
	ResultSet rs=null;
	PreparedStatement pStmt=null;
	ImgHierarchyDto imgHierarchyDtoObj = null;
	boolean status = true;
	int length = 0;
	StringBuffer imgDependency = new StringBuffer("SELECT IMGID FROM IMGDEPENDENCY WHERE DEPENDENCYIMGID NOT IN (");
	StringBuffer inputImgId = new StringBuffer();
	ArrayList<String> depList =  new ArrayList<String>();
	int scopeArrLen = 0;
	try{
		scopeArrLen = scopeList.size();
		for(int i=0;i<scopeArrLen;i++){
				depList.add(scopeList.get(i).getImgId());
		}
		length = depList.size();
		if(length > 0){
			for(int i=0;i<length;i++){
				if(i==length-1)
					inputImgId.append("?)");
				else
					inputImgId.append("?,");			
			}
		
		imgDependency.append(inputImgId).append(" AND IMGID =?");
	
		con = DBConnection.createConnection();
		pStmt =con.prepareStatement(imgDependency.toString());
		int pos = 1;		
		for(int i=0;i<length;i++,pos++){
			pStmt.setString (pos, depList.get(i));				
		}
		pStmt.setString(pos, currentScope);
		rs = pStmt.executeQuery();
			while(rs.next()){
				status = false;
				break;
			}
		}else{
			status = true;
		}
		
	}
	catch (SQLException e){
		imgHierarchyDtoObj = new ImgHierarchyDto();
		imgHierarchyDtoObj.setStatus("Error");
		imgHierarchyDtoObj.setMessage("Not able to fetch Img Hierrachy Data ,please contact the Administrator!");
		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	}finally{
		imgHierarchyDtoObj = null;
		imgDependency = null;
		inputImgId = null;
		depList = null;
		if(rs!=null){
			try {
				rs.close();
				rs= null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		if(pStmt!=null){
			try {
				pStmt.close();
				pStmt=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		if(con!=null){
			try {
				con.close();
				con=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		
	}	
	
	return status;
}



public ArrayList<BrownfieldMdRequestDto>  masterDataDependency (MasterDataDependencyChkInDTO masterDataDependencyChkInDTO) {
	 ArrayList<BrownfieldMdRequestDto> resScopeList =  new ArrayList<BrownfieldMdRequestDto>();
	 List<BrownfieldMdRequestDto> selectedIMGScopeList = masterDataDependencyChkInDTO.getSelectedScopeData();
	 resScopeList =  (ArrayList<BrownfieldMdRequestDto>) selectedIMGScopeList;
	 ArrayList<ImgHierarchyDto> selectedScope = null;
	 BrownfieldMdRequestDto imgScopeDto = null;
	 selectedScope  =  getMasterDataList(masterDataDependencyChkInDTO.isIndustryFlag());
	 ArrayList<String> depList = null;
	 HashMap<String, ArrayList<String>> scopeMap = new HashMap<String, ArrayList<String>>(); 
	 try{
		 for(ImgHierarchyDto masterData: selectedScope){
			 if(!scopeMap.isEmpty() && scopeMap.containsKey(masterData.getImgId())){
				 depList = scopeMap.get(masterData.getImgId());
				 depList.add(masterData.getDependencyImgId());
				 scopeMap.put(masterData.getImgId(), depList);//need to add?
			 }else{
				 depList = new ArrayList<String>();
				 depList.add(masterData.getDependencyImgId());
				 scopeMap.put(masterData.getImgId(), depList);
			 }
		
		 }
	
	if(!scopeMap.isEmpty()){
		 for(Map.Entry<String,ArrayList<String>> currrentMap:scopeMap.entrySet()){
			 boolean isAvilable = false;
			 int masterPos = -1;
			   for(int i = 0; i< selectedIMGScopeList.size();i++){
				   if(selectedIMGScopeList.get(i).getImgId().equals(currrentMap.getKey())){
					   masterPos = i;
					   isAvilable = true;
					   break;
				   }
			   }
			   if(isAvilable){
				   int pos = -1;
				   for(String currentValue: currrentMap.getValue()){
					   int currentIndex = -1;
					   for(int i = 0; i< selectedIMGScopeList.size();i++){
						   if(selectedIMGScopeList.get(i).getImgId().equals(currentValue)){
							   currentIndex = i;
							   break;
						   }
					   }
					   
					   if(currentIndex >= 0){
						   pos = pos > currentIndex ? pos : currentIndex;  
					   }
				   }
				   if(pos >= 0){
					   imgScopeDto =  selectedIMGScopeList.get(masterPos);
					    resScopeList.add(pos+1, imgScopeDto);
					   selectedIMGScopeList.remove(imgScopeDto);		   
				   }
			   }
			   
			  }  
		}
	 }finally{
		 selectedScope = null;
		 depList = null;
		 scopeMap = null;
	 }
	
	return resScopeList;
}

public ArrayList<ImgHierarchyDto> getMasterDataList(boolean industryFlag)  {
	Connection con = null;
	ArrayList<ImgHierarchyDto> responseList = new ArrayList<ImgHierarchyDto>();
	ImgHierarchyDto dto ;
	ResultSet rs=null;
	PreparedStatement pStmt=null;

	try{
		con = DBConnection.createConnection();
		if(industryFlag) {
			pStmt = con.prepareStatement("SELECT A.IMGID, B.DEPENDENCYIMGID FROM INDUSTRY_IMGHIERARCHY A, IMGDEPENDENCY B where A.IMGID = B.IMGID AND A.ismasterdata =? AND B.INDUSTRY=?");
		}else {
			pStmt = con.prepareStatement("SELECT A.IMGID, B.DEPENDENCYIMGID FROM IMGHIERARCHY A, IMGDEPENDENCY B where A.IMGID = B.IMGID AND A.ismasterdata =? AND B.CROSS_IND=?");
		}
			
			pStmt.setString(1, "Y");
			pStmt.setInt(2, 1);
			rs = pStmt.executeQuery();
			while(rs.next()){
				dto = new ImgHierarchyDto();
				dto.setImgId(rs.getString("IMGID"));
				dto.setDependencyImgId(rs.getString("DEPENDENCYIMGID"));
				responseList.add(dto);
			}
		}catch(Exception e){
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}
	
	finally{
		if(rs!=null){
			try {
				rs.close();
				rs= null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		if(pStmt!=null){
			try {
				pStmt.close();
				pStmt=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		if(con!=null){
			try {
				con.close();
				con=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
	}
	return responseList;
	
}

public DownloadScopeResDto getInputStringForInstalledBase(String imgId,String systemType,String imgDescription,String sequence)  {
	Connection con = null;
	ResultSet rs=null;
	PreparedStatement pStmt=null;
	ArrayList<String> inputScope= new ArrayList<String>();
  	String dbName = null;
  	String inputImgId = null;
  	ArrayList<String> s4configSelfieldList  =null;
  	int  docId = 0;
	 String fileName = "";
	 HCPDocDAO hcpDocDAOobj = new HCPDocDAO();
	 S4AutoConfExecution s4ImplObj = null;
  	DownloadScopeResDto downloadScopeResDto = new DownloadScopeResDto();
	try{
    	PropMappings propObj = PropMappings.getInstance();
		dbName = propObj.getValue("S4CONFIGHANA_DB");
		if(dbName.equals("SAPHANA")){
			if(systemType.equals("SAP ECC")){
				inputImgId = "SELECT SEQNO||'|'||IMGID||'|'||OBJECTNAME||'|'||OBJECTTYPE||'|'||SEL_FIELD \"SCOPENAME\",SEL_FIELD, OBJECTNAME FROM IMGOBJECTS WHERE IMGID=? AND ISECCIMG=? AND CROSS_IND =?";
			}
			else if (systemType.equals("S4 HANA")){
				inputImgId = "SELECT SEQNO||'|'||IMGID||'|'||OBJECTNAME||'|'||OBJECTTYPE||'|'||SEL_FIELD \"SCOPENAME\",SEL_FIELD, OBJECTNAME FROM IMGOBJECTS WHERE IMGID=? AND CROSS_IND=?";
			}
		}
		else{
			if(systemType.equals("SAP ECC"))
				inputImgId = "SELECT CONCAT(SEQNO,'|',IMGID,'|',OBJECTNAME,'|',OBJECTTYPE,'|',SEL_FIELD) SCOPENAME, SEL_FIELD, OBJECTNAME FROM IMGOBJECTS WHERE IMGID=? AND ISECCIMG=? AND CROSS_IND=?";
			else if (systemType.equals("S4 HANA"))
				inputImgId = "SELECT CONCAT(SEQNO,'|',IMGID,'|',OBJECTNAME,'|',OBJECTTYPE,'|',SEL_FIELD) SCOPENAME, SEL_FIELD, OBJECTNAME FROM IMGOBJECTS WHERE IMGID=? AND CROSS_IND =?";

		}
	
		
		
		con = DBConnection.createConnection();
		pStmt = con.prepareStatement(inputImgId);
		pStmt.setString(1, imgId);
		if(systemType.equals("SAP ECC")){
			pStmt.setString(2, "Y");
			pStmt.setInt(3, 1);
		}else {
			pStmt.setInt(2, 1);
		}
			rs = pStmt.executeQuery();
			downloadScopeResDto.setImgId(imgId);
			downloadScopeResDto.setScopeAvailable("N");
			while(rs.next()){
			
				inputScope.add(rs.getString("SCOPENAME"));
				if(rs.getString("SEL_FIELD") != null && (rs.getString("SEL_FIELD").equalsIgnoreCase("D") || rs.getString("SEL_FIELD").equalsIgnoreCase("0"))){
					downloadScopeResDto.setSelField(rs.getString("SEL_FIELD"));	
					s4ImplObj = new S4AutoConfExecution();
						if(docId == 0){
							fileName = sequence+"_"+imgDescription;
							docId = hcpDocDAOobj.getDocumentId(fileName.replaceAll("[^a-zA-Z0-9]", "").toLowerCase(),"BASE");
						}
					   s4configSelfieldList = s4ImplObj.getInstalledBaseWithoutIntervention(docId,fileName,rs.getString("OBJECTNAME"));
					   inputScope.addAll(s4configSelfieldList);
				}
				
				}
			
			
			downloadScopeResDto.setImgScope(inputScope);
			if(inputScope.size() >=  1)
				downloadScopeResDto.setScopeAvailable("Y");
			else
				downloadScopeResDto.setScopeAvailable("N");

		
	}
	catch (SQLException e){
		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	}finally{
		dbName = null;
		
		inputImgId = null;
		inputScope = null;
		if(rs!=null){
			try {
				rs.close();
				rs= null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		if(pStmt!=null){
			try {
				pStmt.close();
				pStmt=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		if(con!=null){
			try {
				con.close();
				con=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		
	}	
	
	return downloadScopeResDto;
}

public DownloadScopeResDto getInputStringForInstalledBaseForIndustry(String imgId,String systemType, String industry, String subIndustry, String fileName)  {
	Connection con = null;
	ResultSet rs=null;
	PreparedStatement pStmt=null;
	ArrayList<String> inputScope= new ArrayList<String>();
  	String dbName = null;
  	String inputImgId = null;
  	ArrayList<String> s4configSelfieldList  =null;
  	int  docId = 0;
	 HCPDocDAO hcpDocDAOobj = new HCPDocDAO();
	 S4AutoConfExecution s4ImplObj = null;
  	DownloadScopeResDto downloadScopeResDto = new DownloadScopeResDto();
	try{
    	PropMappings propObj = PropMappings.getInstance();
		dbName = propObj.getValue("S4CONFIGHANA_DB");
		if(dbName.equals("SAPHANA")){
			if(systemType.equals("SAP ECC")){
				inputImgId = "SELECT SEQNO||'|'||IMGID||'|'||OBJECTNAME||'|'||OBJECTTYPE||'|'||SEL_FIELD \"SCOPENAME\",SEL_FIELD, OBJECTNAME FROM IMGOBJECTS WHERE IMGID=? AND ISECCIMG=? and INDUSTRY LIKE ? AND SUBINDUSTRY LIKE ?";
			}
			else if (systemType.equals("S4 HANA")){
				inputImgId = "SELECT SEQNO||'|'||IMGID||'|'||OBJECTNAME||'|'||OBJECTTYPE||'|'||SEL_FIELD \"SCOPENAME\",SEL_FIELD, OBJECTNAME FROM IMGOBJECTS WHERE IMGID=? and INDUSTRY LIKE ? AND SUBINDUSTRY LIKE ?";
			}
		}
		else{
			if(systemType.equals("SAP ECC"))
				inputImgId = "SELECT CONCAT(SEQNO,'|',IMGID,'|',OBJECTNAME,'|',OBJECTTYPE,'|',SEL_FIELD) SCOPENAME, SEL_FIELD, OBJECTNAME FROM IMGOBJECTS WHERE IMGID=? AND ISECCIMG=? and INDUSTRY LIKE ? AND SUBINDUSTRY LIKE ?";
			else if (systemType.equals("S4 HANA"))
				inputImgId = "SELECT CONCAT(SEQNO,'|',IMGID,'|',OBJECTNAME,'|',OBJECTTYPE,'|',SEL_FIELD) SCOPENAME, SEL_FIELD, OBJECTNAME FROM IMGOBJECTS WHERE IMGID=? and INDUSTRY LIKE ? AND SUBINDUSTRY LIKE ?";

		}
	
		
		
		con = DBConnection.createConnection();
		pStmt = con.prepareStatement(inputImgId);
		pStmt.setString(1, imgId);
		
		if(systemType.equals("SAP ECC")){
			pStmt.setString(2, "Y");
			pStmt.setString(3, "%" + industry + "%");
			pStmt.setString(4, "%" + subIndustry + "%");
		}else {
			pStmt.setString(2, "%" + industry + "%");
			pStmt.setString(3, "%" + subIndustry + "%");
		}
			rs = pStmt.executeQuery();
			downloadScopeResDto.setImgId(imgId);
			downloadScopeResDto.setScopeAvailable("N");
			while(rs.next()){
			
				inputScope.add(rs.getString("SCOPENAME"));
				if(rs.getString("SEL_FIELD") != null && (rs.getString("SEL_FIELD").equalsIgnoreCase("D") || rs.getString("SEL_FIELD").equalsIgnoreCase("0"))){
					downloadScopeResDto.setSelField(rs.getString("SEL_FIELD"));	
					s4ImplObj = new S4AutoConfExecution();
						if(docId == 0){
							
							docId = hcpDocDAOobj.getDocumentIdForIndustry(fileName.replaceAll("[^a-zA-Z0-9]", "").toLowerCase(),"BASE");
						}
					   s4configSelfieldList = s4ImplObj.getInstalledBaseWithoutInterventionForIndustry(docId,fileName,rs.getString("OBJECTNAME"));
					   inputScope.addAll(s4configSelfieldList);
				}
				
				}
			
			
			downloadScopeResDto.setImgScope(inputScope);
			if(inputScope.size() >=  1)
				downloadScopeResDto.setScopeAvailable("Y");
			else
				downloadScopeResDto.setScopeAvailable("N");

		
	}
	catch (SQLException e){
		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	}finally{
		dbName = null;
		
		inputImgId = null;
		inputScope = null;
		if(rs!=null){
			try {
				rs.close();
				rs= null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		if(pStmt!=null){
			try {
				pStmt.close();
				pStmt=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		if(con!=null){
			try {
				con.close();
				con=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		
	}	
	
	return downloadScopeResDto;
}
public DownloadScopeResDto getInputStringForInstalledBaseCopyFunctionality(String imgId,String systemType,String imgDescription,String sequence)  {
	Connection con = null;
	ResultSet rs=null;
	PreparedStatement pStmt=null;
	ResultSet rs1=null;
	PreparedStatement pStmt1=null;
	ArrayList<String> inputScope= new ArrayList<String>();
  	String dbName = null;
  	String inputImgId = null;
  	String checkinput=null;
  	ArrayList<String> s4configSelfieldList  =null;
  	int  docId = 0;
	 String fileName = "";
	 HCPDocDAO hcpDocDAOobj = new HCPDocDAO();
	 S4AutoConfExecution s4ImplObj = null;
  	DownloadScopeResDto downloadScopeResDto = new DownloadScopeResDto();
	try{
    	PropMappings propObj = PropMappings.getInstance();
		dbName = propObj.getValue("S4CONFIGHANA_DB");
		if(dbName.equals("SAPHANA")){
			if(systemType.equals("SAP ECC")){
				inputImgId = "SELECT SEQNO||'|'||IMGID||'|'||OBJECTNAME||'|'||OBJECTTYPE||'||'||SEL_FIELD \"SCOPENAME\",SEL_FIELD, OBJECTNAME FROM COPYFUNCTIONALITY_IMGOBJECTS WHERE IMGID=? AND ISECCIMG=?";
				checkinput = "SELECT CONCAT(IMGID,'|',OBJECTNAME,'|',OBJECTTYPE,'~',COPY_FIELD,'|',SEL_FIELD) PLANTCHECK FROM COPYFUNCTIONALITY_IMGOBJECTS WHERE IMGID=? AND SEQNO=1";

			}
			else if (systemType.equals("S4 HANA")){
				inputImgId = "SELECT SEQNO||'|'||IMGID||'|'||OBJECTNAME||'|'||OBJECTTYPE||'||'||SEL_FIELD \"SCOPENAME\",SEL_FIELD, OBJECTNAME FROM COPYFUNCTIONALITY_IMGOBJECTS WHERE IMGID=?";
				checkinput = "SELECT CONCAT(IMGID,'|',OBJECTNAME,'|',OBJECTTYPE,'~',COPY_FIELD,'|',SEL_FIELD) PLANTCHECK FROM COPYFUNCTIONALITY_IMGOBJECTS WHERE IMGID=? AND SEQNO=1";
			}
		}
			else {
				if (systemType.equals("SAP ECC")) {
					inputImgId = "SELECT CONCAT(SEQNO,'|',IMGID,'|',OBJECTNAME,'|',OBJECTTYPE,'||',SEL_FIELD) SCOPENAME, SEL_FIELD, OBJECTNAME FROM COPYFUNCTIONALITY_IMGOBJECTS WHERE IMGID=? AND ISECCIMG=?";
					checkinput = "SELECT CONCAT(IMGID,'|',OBJECTNAME,'|',OBJECTTYPE,'~',COPY_FIELD,'|',SEL_FIELD) PLANTCHECK FROM COPYFUNCTIONALITY_IMGOBJECTS WHERE IMGID=? AND SEQNO=1";

				}else if (systemType.equals("S4 HANA")) {
					inputImgId = "SELECT CONCAT(SEQNO,'|',IMGID,'|',OBJECTNAME,'|',OBJECTTYPE,'||',SEL_FIELD) SCOPENAME, SEL_FIELD, OBJECTNAME FROM COPYFUNCTIONALITY_IMGOBJECTS WHERE IMGID=?";
					checkinput = "SELECT CONCAT(IMGID,'|',OBJECTNAME,'|',OBJECTTYPE,'~',COPY_FIELD,'|',SEL_FIELD) PLANTCHECK FROM COPYFUNCTIONALITY_IMGOBJECTS WHERE IMGID=? AND SEQNO=1";
				}
			}
	
		
		
		con = DBConnection.createConnection();
		pStmt = con.prepareStatement(inputImgId);
		pStmt1 = con.prepareStatement(checkinput);
		pStmt.setString(1, imgId);
		pStmt1.setString(1, imgId);
		if(systemType.equals("SAP ECC")){
			pStmt.setString(2, "Y");
		}
			rs = pStmt.executeQuery();
			rs1 = pStmt1.executeQuery();

			downloadScopeResDto.setImgId(imgId);
			downloadScopeResDto.setScopeAvailable("N");
			while(rs.next()){
			
				inputScope.add(rs.getString("SCOPENAME"));
				if(rs.getString("SEL_FIELD") != null && (rs.getString("SEL_FIELD").equalsIgnoreCase("D") || rs.getString("SEL_FIELD").equalsIgnoreCase("0"))){
					downloadScopeResDto.setSelField(rs.getString("SEL_FIELD"));	
					s4ImplObj = new S4AutoConfExecution();
						if(docId == 0){
							fileName = sequence+"_"+imgDescription;
							docId = hcpDocDAOobj.getDocumentId(fileName.replaceAll("[^a-zA-Z0-9]", "").toLowerCase(),"BASE");
						}
					   s4configSelfieldList = s4ImplObj.getInstalledBaseWithoutIntervention(docId,fileName,rs.getString("OBJECTNAME"));
					   inputScope.addAll(s4configSelfieldList);
				}
				
				}
			if(rs1.next())
			downloadScopeResDto.setCopyToCheck(rs1.getString("PLANTCHECK"));
			
			downloadScopeResDto.setImgScope(inputScope);
			if(inputScope.size() >=  1)
				downloadScopeResDto.setScopeAvailable("Y");
			else
				downloadScopeResDto.setScopeAvailable("N");

		
	}
	catch (SQLException e){
		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	}finally{
		dbName = null;
		
		inputImgId = null;
		inputScope = null;
		if(rs!=null){
			try {
				rs.close();
				rs= null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		if(pStmt!=null){
			try {
				pStmt.close();
				pStmt=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		if(con!=null){
			try {
				con.close();
				con=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		
	}	
	
	return downloadScopeResDto;
}

	public HashMap<String, ArrayList<String>> getImgobjects(List<String> imgIds){
		HashMap<String, ArrayList<String>>  imgObjects =  new HashMap<String, ArrayList<String>>();
		
		Connection con = null;
		ResultSet rs=null;
		PreparedStatement pStmt=null;
		int length = 0;
		StringBuilder inputQuery = new StringBuilder("select IMGID, OBJECTNAME from  IMGOBJECTS where CROSS_IND = ? AND IMGID IN(");
		StringBuilder inputImgId = new StringBuilder();
		try{
			length = imgIds.size(); 
			for(int i=0;i<length;i++){
				if(i==length-1)
					inputImgId.append("?)");
				else
					inputImgId.append("?,");			
			}
			inputQuery.append(inputImgId).append(" ORDER BY IMGID,SEQNO");//Assisted Configuration Sequence Execution
			con = DBConnection.createConnection();
			pStmt = con.prepareStatement(inputQuery.toString());
			pStmt.setInt (1,1);	
			int pos = 2;		
			for(int i=0;i<length;i++,pos++){
				pStmt.setString (pos, imgIds.get(i));				
			}
				rs = pStmt.executeQuery();
				while(rs.next()){
					if(imgObjects.size() > 0 && imgObjects.get(rs.getString("IMGID")) != null ){
						imgObjects.get(rs.getString("IMGID").trim()).add(rs.getString("OBJECTNAME").trim());
					}else{
						ArrayList<String> viewList  = new  ArrayList<>();
						viewList.add(rs.getString("OBJECTNAME").trim());
						imgObjects.put(rs.getString("IMGID").trim(), viewList);
					}
						
				}
		}
		catch (SQLException e){
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}finally{
			inputImgId = null;
			if(rs!=null){
				try {
					rs.close();
					rs= null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
		}	
		
		
		return imgObjects;
	}
	
	public HashMap<String, ArrayList<String>> getImgobjectsForIndustry(List<String> imgIds, boolean industryFlag, String industry, String subIndustry){
		HashMap<String, ArrayList<String>>  imgObjects =  new HashMap<String, ArrayList<String>>();
		
		Connection con = null;
		ResultSet rs=null;
		PreparedStatement pStmt=null;
		int length = 0;
		StringBuilder inputQuery = new StringBuilder("select IMGID, OBJECTNAME from  IMGOBJECTS where INDUSTRY LIKE ? AND SUBINDUSTRY LIKE ? AND IMGID IN(");
		StringBuilder inputImgId = new StringBuilder();
		try{
			length = imgIds.size(); 
			for(int i=0;i<length;i++){
				if(i==length-1)
					inputImgId.append("?)");
				else
					inputImgId.append("?,");			
			}
			inputQuery.append(inputImgId).append(" ORDER BY IMGID,SEQNO");//Assisted Configuration Sequence Execution
			con = DBConnection.createConnection();
			pStmt = con.prepareStatement(inputQuery.toString());
			pStmt.setString(1, "%" + industry + "%");
			pStmt.setString(2, "%" + subIndustry + "%");
			int pos = 3;		
			for(int i=0;i<length;i++,pos++){
				pStmt.setString (pos, imgIds.get(i));				
			}
				rs = pStmt.executeQuery();
				while(rs.next()){
					if(imgObjects.size() > 0 && imgObjects.get(rs.getString("IMGID")) != null ){
						imgObjects.get(rs.getString("IMGID").trim()).add(rs.getString("OBJECTNAME").trim());
					}else{
						ArrayList<String> viewList  = new  ArrayList<>();
						viewList.add(rs.getString("OBJECTNAME").trim());
						imgObjects.put(rs.getString("IMGID").trim(), viewList);
					}
						
				}
		}
		catch (SQLException e){
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}finally{
			inputImgId = null;
			if(rs!=null){
				try {
					rs.close();
					rs= null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
		}	
		
		
		return imgObjects;
	}
	public HashMap<String, ArrayList<String>> getImgobjectsConsolidation(List<String> imgIds){
		HashMap<String, ArrayList<String>>  imgObjects =  new HashMap<String, ArrayList<String>>();
		for(String img:imgIds)
		{
			ArrayList<String> view=new ArrayList<String>();
			view.add(img.split("-")[1]);
			imgObjects.put(img, view);
		}
				
		return imgObjects;
	}
	public HashMap<String, ArrayList<String>> getImgobjectsCopyFunctionality(List<String> imgIds){
		HashMap<String, ArrayList<String>>  imgObjects =  new HashMap<String, ArrayList<String>>();
		
		Connection con = null;
		ResultSet rs=null;
		PreparedStatement pStmt=null;
		int length = 0;
		StringBuilder inputQuery = new StringBuilder("select IMGID, OBJECTNAME from  COPYFUNCTIONALITY_IMGOBJECTS where IMGID IN(");
		StringBuilder inputImgId = new StringBuilder();
		try{
			length = imgIds.size(); 
			for(int i=0;i<length;i++){
				if(i==length-1)
					inputImgId.append("?)");
				else
					inputImgId.append("?,");			
			}
			inputQuery.append(inputImgId).append(" ORDER BY IMGID,SEQNO");//Assisted Configuration Sequence Execution
			con = DBConnection.createConnection();
			pStmt = con.prepareStatement(inputQuery.toString());
			int pos = 1;		
			for(int i=0;i<length;i++,pos++){
				pStmt.setString (pos, imgIds.get(i));				
			}
				rs = pStmt.executeQuery();
				while(rs.next()){
					if(imgObjects.size() > 0 && imgObjects.get(rs.getString("IMGID")) != null ){
						imgObjects.get(rs.getString("IMGID").trim()).add(rs.getString("OBJECTNAME").trim());
					}else{
						ArrayList<String> viewList  = new  ArrayList<>();
						viewList.add(rs.getString("OBJECTNAME").trim());
						imgObjects.put(rs.getString("IMGID").trim(), viewList);
					}
						
				}
		}
		catch (SQLException e){
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}finally{
			inputImgId = null;
			if(rs!=null){
				try {
					rs.close();
					rs= null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			
		}	
		
		
		return imgObjects;
	}

	public ArrayList<String> getViewBySequence(String imgID){
		ArrayList<String>  viewList =  new ArrayList<String>();		
		Connection con = null;
		ResultSet rs = null;
		PreparedStatement pStmt = null;
		StringBuilder inputQuery = new StringBuilder("SELECT OBJECTNAME FROM  IMGOBJECTS WHERE IMGID = ? AND CROSS_IND = ? ORDER BY SEQNO");
		try {
			con = DBConnection.createConnection();
			pStmt = con.prepareStatement(inputQuery.toString());
			pStmt.setString(1, imgID);
			pStmt.setInt(2, 1);
			rs = pStmt.executeQuery();
			while (rs.next()) {
				viewList.add(rs.getString("OBJECTNAME").trim().replaceAll("/", "~"));
			}
		} catch (SQLException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		} finally {
			if (rs != null) {
				try {
					rs.close();
					rs = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if (pStmt != null) {
				try {
					pStmt.close();
					pStmt = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if (con != null) {
				try {
					con.close();
					con = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}

		}

		return viewList;
	}
	
	public ArrayList<String> getViewBySequenceForIndustry(String imgID, String industry, String subIndustry ){
		ArrayList<String>  viewList =  new ArrayList<String>();		
		Connection con = null;
		ResultSet rs = null;
		PreparedStatement pStmt = null;
		StringBuilder inputQuery = new StringBuilder("SELECT OBJECTNAME FROM  IMGOBJECTS WHERE IMGID = ? AND INDUSTRY LIKE ? AND SUBINDUSTRY LIKE ? ORDER BY SEQNO");
		try {
			con = DBConnection.createConnection();
			pStmt = con.prepareStatement(inputQuery.toString());
			pStmt.setString(1, imgID);
			pStmt.setString(2, "%" + industry + "%");
			pStmt.setString(3, "%" + subIndustry + "%");
			rs = pStmt.executeQuery();
			while (rs.next()) {
				viewList.add(rs.getString("OBJECTNAME").trim().replaceAll("/", "~"));
			}
		} catch (SQLException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		} finally {
			if (rs != null) {
				try {
					rs.close();
					rs = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if (pStmt != null) {
				try {
					pStmt.close();
					pStmt = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if (con != null) {
				try {
					con.close();
					con = null;
				} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}

		}

		return viewList;
	}
	public ImgResponseDto insertScenarioHierarchy(HttpServletRequest request)   {  
		slf4jLogger.info("insertScenarioHierarchy method started");
		FileItemFactory factory = new DiskFileItemFactory();
		ServletFileUpload fileUpload = new ServletFileUpload(factory);
		FileItem fileItemTemp = null;
		ImgHierarchyDto imgHierarchyDtoObj =  null;
		XSSFWorkbook workbook = null;
		XSSFSheet sheet = null;
		Iterator<Row> rowIterator = null;
		int noOfColumns = 0;
		boolean flag = false;
		//boolean flag1 = true;
		//slf4jLogger.info("flaag1"+flag1);
		ImgResponseDto imgResponseDto = null;
		ArrayList<ImgHierarchyDto> dtoList = null;
		List <FileItem> fileItemsList = null;
		Iterator <FileItem> fileItemsIterator = null;
		
		try{
			imgResponseDto = new ImgResponseDto();
			if (ServletFileUpload.isMultipartContent(request)) {
				fileItemsList = fileUpload.parseRequest(request);
				fileItemsIterator = fileItemsList.iterator();
				while (fileItemsIterator.hasNext()) {
					fileItemTemp = fileItemsIterator.next();
					if (!fileItemTemp.isFormField()) {
						workbook = new XSSFWorkbook(fileItemTemp.getInputStream());								
					}
				}
			}
         sheet = workbook.getSheetAt(2);
         rowIterator = sheet.iterator();
         noOfColumns = sheet.getRow(0).getPhysicalNumberOfCells();
         rowIterator.next();
         dtoList = new ArrayList<ImgHierarchyDto>();
         while(rowIterator.hasNext())
         {	
        	
        	 imgHierarchyDtoObj = new ImgHierarchyDto();
        	 Row row = rowIterator.next();
        
        	 for(int i=0;i<noOfColumns;i++)
        	 {
                if(row.getCell(i) !=null ){
                	row.getCell(i).setCellType(Cell.CELL_TYPE_STRING);
                		if(i==0){
                			if( row.getCell(i).getStringCellValue()!=null && row.getCell(i).getStringCellValue()!="" && row.getCell(i).getStringCellValue().length()>2 && row.getCell(i).getStringCellValue().substring(0, 2).equals("MD")){
                			imgHierarchyDtoObj.setSequence(row.getCell(i).getStringCellValue().substring(2));
                			//imgHierarchyDtoObj.setIsMasterData("Y");
                			}else {
                			imgHierarchyDtoObj.setSequence(row.getCell(i).getStringCellValue());
                			//imgHierarchyDtoObj.setIsMasterData("N");
                			}
                	 	}
                		else if(i==1){
                			imgHierarchyDtoObj.setIndSeq(row.getCell(i).getStringCellValue());
                				
                	 	}
                		else if(i==2){     
                	 		//System.out.println(row.getCell(i).getStringCellValue());
                	 		imgHierarchyDtoObj.setImgId(row.getCell(i).getStringCellValue());
                	 	  }
                	 	else if(i==4){
                	 		//System.out.println(imgHierarchyDtoObj);
                			imgHierarchyDtoObj.setImgDescription(row.getCell(i).getStringCellValue());
                	 	}else if(i==5){  
                	 		//System.out.println(row.getCell(i).getStringCellValue());
                    			imgHierarchyDtoObj.setNodeLevel(Integer.parseInt(row.getCell(i).getStringCellValue().substring(1).trim()));
                        	}
                	 	else if(i==6){        			
                			imgHierarchyDtoObj.setNodetype(row.getCell(i).getStringCellValue());                			
                    	}                   	
                    	else if(i==7){
                    		imgHierarchyDtoObj.setEnabled(row.getCell(i).getStringCellValue().equals("") ? 0 : Integer.parseInt(row.getCell(i).getStringCellValue()));
                    	}
                    	else if(i==8){
                    		imgHierarchyDtoObj.setConfigType(row.getCell(i).getStringCellValue());
                    	}
                    	else if(i==11){
                    		imgHierarchyDtoObj.setScenario(row.getCell(i).getStringCellValue());
                    	}
                    	else if(i==12){
                    		imgHierarchyDtoObj.setSubProcess(row.getCell(i).getStringCellValue());
                    	}
                    	else if(i==13){
                     		imgHierarchyDtoObj.setCrossIndFlag(row.getCell(i).getStringCellValue().equals("")? 0 :Integer.parseInt(row.getCell(i).getStringCellValue()));
                    	}
                    	else if(i==14){
                     		imgHierarchyDtoObj.setIndFlag(row.getCell(i).getStringCellValue().equals("")? 0 :Integer.parseInt(row.getCell(i).getStringCellValue()));
                    	}
                    	else if(i==15){
                     		imgHierarchyDtoObj.setIndustry(row.getCell(i).getStringCellValue().equals("")? null :row.getCell(i).getStringCellValue());
                    	}
                    	else if(i==16){
                     		imgHierarchyDtoObj.setSubIndustry(row.getCell(i).getStringCellValue().equals("")? null :row.getCell(i).getStringCellValue());
                    	}
                    
                }
                
        	 }
       
        	 dtoList.add(imgHierarchyDtoObj);
         }
        	 flag = InsertRecordsInDB(dtoList, "ScenarioHierarchy");
				if (flag) {
					imgResponseDto.setMessage("Data Successfully Inserted to ScenarioHirarchy Table!");
				} else {
					imgResponseDto.setMessage("Not able to store Scenario Hierarchy Data, some database exception occured ");
				}
        	
        }
		catch (FileNotFoundException ex) {
			imgResponseDto.setStatus(ConstantsValues.ERRORSTATUS);
			imgResponseDto.setMessage("Not able to store Image Hierarchy Data ,please contact the Administrator!");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,ex);
		} catch (IOException ex) {
			imgResponseDto.setStatus(ConstantsValues.ERRORSTATUS);
			imgResponseDto.setMessage("Not able to store Image Hierarchy Data ,please contact the Administrator!");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,ex);
		} catch (FileUploadException ex) {
			imgResponseDto.setStatus(ConstantsValues.ERRORSTATUS);
			imgResponseDto.setMessage("Not able to store Image Hierarchy Data ,please contact the Administrator!");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,ex);
		}
		finally{
			factory = null;
			fileUpload = null;
			fileItemTemp = null;
			imgHierarchyDtoObj =  null;
			sheet = null;
			rowIterator = null;
			dtoList = null;
			fileItemsList = null;
			fileItemsIterator = null;
			try {
				if(workbook!=null){
				workbook.close();
				}
			} catch (IOException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
			  slf4jLogger.info("insertScenarioHierarchyData method ended");

		}
		return imgResponseDto;
	}
	
	public ImgResponseDto insertIndustryData(HttpServletRequest request)   {  
		slf4jLogger.info("insertIndustryData method started");
		FileItemFactory factory = new DiskFileItemFactory();
		ServletFileUpload fileUpload = new ServletFileUpload(factory);
		FileItem fileItemTemp = null;
		ImgHierarchyDto imgHierarchyDtoObj =  null;
		XSSFWorkbook workbook = null;
		XSSFSheet sheet = null;
		Iterator<Row> rowIterator = null;
		int noOfColumns = 0;
		boolean flag = false;
		
		ImgResponseDto imgResponseDto = null;
		ArrayList<ImgHierarchyDto> industryList = null;
		Map<String,String> aliasMap = null;
		List <FileItem> fileItemsList = null;
		Iterator <FileItem> fileItemsIterator = null;
		
		try{
			imgResponseDto = new ImgResponseDto();
			if (ServletFileUpload.isMultipartContent(request)) {
				fileItemsList = fileUpload.parseRequest(request);
				fileItemsIterator = fileItemsList.iterator();
				while (fileItemsIterator.hasNext()) {
					fileItemTemp = fileItemsIterator.next();
					if (!fileItemTemp.isFormField()) {
						workbook = new XSSFWorkbook(fileItemTemp.getInputStream());								
					}
				}
			}
         sheet = workbook.getSheetAt(0);
         rowIterator = sheet.iterator();
         noOfColumns = sheet.getRow(0).getPhysicalNumberOfCells();
         rowIterator.next();
         industryList = new ArrayList<ImgHierarchyDto>();
         aliasMap = new HashMap<String, String>();
         while(rowIterator.hasNext())
         {	
        	
        	 imgHierarchyDtoObj = new ImgHierarchyDto();
        	 Row row = rowIterator.next();
        
        	 for(int i=0;i<noOfColumns;i++)
        	 {
                if(row.getCell(i) !=null ){
                	row.getCell(i).setCellType(Cell.CELL_TYPE_STRING);
                		if(i==0){     
                	 		//System.out.println(row.getCell(i).getStringCellValue());
                	 		imgHierarchyDtoObj.setIndustry(row.getCell(i).getStringCellValue());
                	 	  }
                	 	else if(i==1){
                	 		//System.out.println(imgHierarchyDtoObj);
                			imgHierarchyDtoObj.setSubIndustry(row.getCell(i).getStringCellValue());
                	 	}else if(i==2){  
                	 		//System.out.println(row.getCell(i).getStringCellValue());
                	 		imgHierarchyDtoObj.setAliasIndustry(row.getCell(i).getStringCellValue()); 
                        	}
                	 	else if(i==3){        			
                			imgHierarchyDtoObj.setAliasSubIndustry(row.getCell(i).getStringCellValue());                			
                    	}                     	
                    
                }
                
        	 }
       
        	 industryList.add(imgHierarchyDtoObj);
         }
        	 flag = InsertRecordsInDB(industryList, "Industry");
        	
				if (flag) {
					imgResponseDto.setMessage("Data Successfully Inserted to Industry Mapping Table!");
				} else {
					imgResponseDto.setMessage("Not able to store Scenario Hierarchy Data, some database exception occured ");
				}
        	
        }
		catch (FileNotFoundException ex) {
			imgResponseDto.setStatus(ConstantsValues.ERRORSTATUS);
			imgResponseDto.setMessage("Not able to store Industry Data ,please contact the Administrator!");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,ex);
		} catch (IOException ex) {
			imgResponseDto.setStatus(ConstantsValues.ERRORSTATUS);
			imgResponseDto.setMessage("Not able to store Industry Data ,please contact the Administrator!");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,ex);
		} catch (FileUploadException ex) {
			imgResponseDto.setStatus(ConstantsValues.ERRORSTATUS);
			imgResponseDto.setMessage("Not able to store Industry Data ,please contact the Administrator!");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,ex);
		}
		finally{
			factory = null;
			fileUpload = null;
			fileItemTemp = null;
			imgHierarchyDtoObj =  null;
			sheet = null;
			rowIterator = null;
			industryList = null;
			fileItemsList = null;
			fileItemsIterator = null;
			try {
				if(workbook!=null){
				workbook.close();
				}
			} catch (IOException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
			  slf4jLogger.info("insertIndustryData method ended");

		}
		return imgResponseDto;
	}
}