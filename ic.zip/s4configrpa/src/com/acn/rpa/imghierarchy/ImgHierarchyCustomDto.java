package com.acn.rpa.imghierarchy;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.acn.rpa.config.DownloadScopeResDto;
import com.acn.user.session.ResMessageDto;
import com.acn.user.session.SessionInputDTO;

public class ImgHierarchyCustomDto {
	@Size(min = 1, max = 30)
	private String imgId;
	@Size(min = 1, max = 255)
	private String imgDesc;
	@Size(min = 0, max = 10)
	private String seqNumber;
	private String targetFilePath;
	@Size(min = 0, max = 1)
	@Pattern(regexp = "^$|[a-zA-Z]+")
	private String isMasterData;
	private byte[] bytes;
	private String resError;
	private boolean scopeAvilable;
	private String scopeAvilableIcon;
	private String downloadStatusIcon;
	private boolean downloadStatus;
	private boolean checkCopyPlantStatus;
	private ArrayList<String> validImgList;
	private List<String> errorList;
	private boolean industry;

	public List<String> getErrorList() {
		return errorList;
	}
	public void setErrorList(List<String> errorList) {
		this.errorList = errorList;
	}
	public ArrayList<String> getValidImgList() {
		return validImgList;
	}
	public void setValidImgList(ArrayList<String> validImgList) {
		this.validImgList = validImgList;
	}
	public boolean isCheckCopyPlantStatus() {
		return checkCopyPlantStatus;
	}
	public void setCheckCopyPlantStatus(boolean checkCopyPlantStatus) {
		this.checkCopyPlantStatus = checkCopyPlantStatus;
	}
	@Valid
	private ArrayList<String> selectedScopes;
	@Valid
	private ArrayList<DownloadScopeResDto> downloadScopeResList;
	@Valid
	private SessionInputDTO sessionInputDTO;
	
	public SessionInputDTO getSessionInputDTO() {
		return sessionInputDTO;
	}
	public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
		this.sessionInputDTO = sessionInputDTO;
	}
	private ResMessageDto resMessageDto;

	public ResMessageDto getResMessageDto() {
		return resMessageDto;
	}
	public void setResMessageDto(ResMessageDto resMessageDto) {
		this.resMessageDto = resMessageDto;
	}
	public ArrayList<String> getSelectedScopes() {
		return selectedScopes;
	}
	public void setSelectedScopes(ArrayList<String> selectedScopes) {
		this.selectedScopes = selectedScopes;
	}
	public byte[] getBytes() {
		return bytes;
	}
	public void setBytes(byte[] bytes) {
		this.bytes = bytes;
	}
	/**
	 * @return the imgDesc
	 */
	public String getImgDesc() {
		return imgDesc;
	}
	/**
	 * @param imgDesc the imgDesc to set
	 */
	public void setImgDesc(String imgDesc) {
		this.imgDesc = imgDesc;
	}
	/**
	 * @return the imgId
	 */
	public String getImgId() {
		return imgId;
	}
	/**
	 * @param imgId the imgId to set
	 */
	public void setImgId(String imgId) {
		this.imgId = imgId;
	}
	/**
	 * @return the seqNumber
	 */
	public String getSeqNumber() {
		return seqNumber;
	}
	/**
	 * @param seqNumber the seqNumber to set
	 */
	public void setSeqNumber(String seqNumber) {
		this.seqNumber = seqNumber;
	}
	/**
	 * @return the targetFilePath
	 */
	public String getTargetFilePath() {
		return targetFilePath;
	}
	/**
	 * @param targetFilePath the targetFilePath to set
	 */
	public void setTargetFilePath(String targetFilePath) {
		this.targetFilePath = targetFilePath;
	}
	public String getResError() {
		return resError;
	}
	public void setResError(String resError) {
		this.resError = resError;
	}
	public boolean isScopeAvilable() {
		return scopeAvilable;
	}
	public void setScopeAvilable(boolean scopeAvilable) {
		this.scopeAvilable = scopeAvilable;
	}
	public String getScopeAvilableIcon() {
		return scopeAvilableIcon;
	}
	public void setScopeAvilableIcon(String scopeAvilableIcon) {
		this.scopeAvilableIcon = scopeAvilableIcon;
	}
	public boolean isDownloadStatus() {
		return downloadStatus;
	}
	public void setDownloadStatus(boolean downloadStatus) {
		this.downloadStatus = downloadStatus;
	}
	public ArrayList<DownloadScopeResDto> getDownloadScopeResList() {
		return downloadScopeResList;
	}
	public void setDownloadScopeResList(ArrayList<DownloadScopeResDto> downloadScopeResList) {
		this.downloadScopeResList = downloadScopeResList;
	}
	public String getDownloadStatusIcon() {
		return downloadStatusIcon;
	}
	public void setDownloadStatusIcon(String downloadStatusIcon) {
		this.downloadStatusIcon = downloadStatusIcon;
	}
	public String getIsMasterData() {
		return isMasterData;
	}
	public void setIsMasterData(String isMasterData) {
		this.isMasterData = isMasterData;
	}
	public boolean isIndustry() {
		return industry;
	}
	public void setIndustry(boolean industry) {
		this.industry = industry;
	}
}
