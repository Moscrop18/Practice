package com.acn.rpa.imghierarchy;

public class ProjectDto {
	
	private String omId;
	private String projectName;
	private String trOverride;
	public String getOmId() {
		return omId;
	}
	public void setOmId(String omId) {
		this.omId = omId;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getTrOverride() {
		return trOverride;
	}
	public void setTrOverride(String trOverride) {
		this.trOverride = trOverride;
	}
	
	

}
