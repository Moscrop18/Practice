package com.acn.rpa.imghierarchy;

import java.util.ArrayList;

import com.acn.user.session.ResMessageDto;
import com.acn.user.session.SessionInputDTO;

public class IndustryResponseDto {

	private ResMessageDto resMessageDto;
	private ArrayList<IndustryDto> indDetails;
	
	private String aliasIndustry;
	
	private String aliasSubIndustry;
	
	public ArrayList<IndustryDto> getIndDetails() {
		return indDetails;
	}
	public void setIndDetails(ArrayList<IndustryDto> indDetails) {
		this.indDetails = indDetails;
	}
	public ResMessageDto getResMessageDto() {
		return resMessageDto;
	}
	public void setResMessageDto(ResMessageDto resMessageDto) {
		this.resMessageDto = resMessageDto;
	}
	public String getAliasIndustry() {
		return aliasIndustry;
	}
	public void setAliasIndustry(String aliasIndustry) {
		this.aliasIndustry = aliasIndustry;
	}
	public String getAliasSubIndustry() {
		return aliasSubIndustry;
	}
	public void setAliasSubIndustry(String aliasSubIndustry) {
		this.aliasSubIndustry = aliasSubIndustry;
	}
	
}
