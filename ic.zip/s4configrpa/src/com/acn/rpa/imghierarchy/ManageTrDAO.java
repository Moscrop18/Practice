package com.acn.rpa.imghierarchy;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.DBConnection;
import com.acn.user.session.SysInputDto;
import com.acn.user.session.TRListDto;

public class ManageTrDAO {
	
    private final Logger slf4jLogger = LoggerFactory.getLogger(ManageTrDAO.class);

	public TRListDto getTrData(SysInputDto sysInputDto){
		slf4jLogger.info("getTrData method started");
		TRListDto trListDto = new TRListDto();
		ManageTrResponseDto outputData = null;
		ArrayList<ManageTrResponseDto> outputDataList = null;
		ResultSet rs=null;
		PreparedStatement pStmt=null;
		Connection con = null;
		int sno = 0;
		try {
			con = DBConnection.createConnection();
			if(sysInputDto.getSelectedArea()!=null && sysInputDto.getSelectedArea().equalsIgnoreCase("Industry")) {
				pStmt =  con.prepareStatement("SELECT A.IMGID,A.ID,C.CTR,C.KTR,B.IMGDESCR,B.TRTYPE FROM CLIENT_IMGHIERARCHY A , INDUSTRY_IMGHIERARCHY B ,ClientSystemTrMapping C where A.IMGID=B.IMGID and C.IMGAUTOID = A.ID and A.OMID=? AND C.SYSTEMID =? AND A.INDUSTRY= ? UNION SELECT A.IMGID,A.ID,'' CTR,'' KTR,B.IMGDESCR,B.TRTYPE FROM CLIENT_IMGHIERARCHY A,INDUSTRY_IMGHIERARCHY B WHERE A.IMGID=B.IMGID AND A.OMID=? AND A.INDUSTRY=? AND A.ID NOT IN (SELECT IMGAUTOID FROM ClientSystemTrMapping WHERE SYSTEMID =?)");
				pStmt.setInt(3, 1);
				pStmt.setInt(5, 1);
			}
			else {
				pStmt =  con.prepareStatement("SELECT A.IMGID,A.ID,C.CTR,C.KTR,B.IMGDESCR,B.TRTYPE FROM CLIENT_IMGHIERARCHY A , IMGHIERARCHY B ,ClientSystemTrMapping C where A.IMGID=B.IMGID and C.IMGAUTOID = A.ID and A.OMID=? AND C.SYSTEMID =? AND  A.INDUSTRY= ? UNION SELECT A.IMGID,A.ID,'' CTR,'' KTR,B.IMGDESCR,B.TRTYPE FROM CLIENT_IMGHIERARCHY A,IMGHIERARCHY B WHERE A.IMGID=B.IMGID AND A.OMID=? AND A.INDUSTRY= ? AND A.ID NOT IN (SELECT IMGAUTOID FROM ClientSystemTrMapping WHERE SYSTEMID =?)");
				pStmt.setInt(3, 0);
				pStmt.setInt(5, 0);
			}
			
			pStmt.setString(1,sysInputDto.getOmID());
			pStmt.setString(2,sysInputDto.getSystemType());
			pStmt.setString(4,sysInputDto.getOmID());
			pStmt.setString(6,sysInputDto.getSystemType());
			rs = pStmt.executeQuery();
			outputDataList = new ArrayList<>();
			while(rs.next()){
				outputData = new ManageTrResponseDto();
				outputData.setImgId(rs.getString("IMGID"));
				outputData.setCustomizingTr(rs.getString("CTR"));
				outputData.setWorkbenchTr(rs.getString("KTR"));
				outputData.setImgDesc(rs.getString("IMGDESCR"));
				outputData.setId(rs.getString("ID")); 
				outputData.setTrType(rs.getString("TRTYPE"));
				outputData.setTrUpdated(false);
				outputData.setTrCusFieldReq(rs.getString("TRTYPE").contains("W"));
				outputData.setTrWKFieldReq(rs.getString("TRTYPE").contains("K"));
				outputData.setSno(sno++);
				outputData.setTrtype1("trtype");
				outputData.setTrtype2("trtype");
				outputDataList.add(outputData);
			}
			trListDto.setTrResponseDto(outputDataList);
			
		} catch (SQLException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}finally {
			if (pStmt != null) {
	            try {
	            	pStmt.close();
	            	pStmt = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }

	        if (con != null) {
	            try {
	            	con.close();
	            	con = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }
			  slf4jLogger.info("getTrData method ended");

	        }
		return trListDto;
	}
	public TRListDto getTrDataCopyFunctionality(SysInputDto sysInputDto){
		slf4jLogger.info("getTrData method started");
		TRListDto trListDto = new TRListDto();
		ManageTrResponseDto outputData = null;
		ArrayList<ManageTrResponseDto> outputDataList = null;
		ResultSet rs=null;
		PreparedStatement pStmt=null;
		Connection con = null;
		int sno = 0;
		try {
			con = DBConnection.createConnection();
			pStmt =  con.prepareStatement("SELECT A.IMGID,A.ID,C.CTR,C.KTR,B.IMGDESCR,B.TRTYPE FROM CLIENT_IMGHIERARCHY A , COPYFUNCTIONALITY_IMGHIERARCHY B ,ClientSystemTrMapping C where A.IMGID=B.IMGID and C.IMGAUTOID = A.ID and A.OMID=? AND C.SYSTEMID =? UNION SELECT A.IMGID,A.ID,'' CTR,'' KTR,B.IMGDESCR,B.TRTYPE FROM CLIENT_IMGHIERARCHY A,COPYFUNCTIONALITY_IMGHIERARCHY B WHERE A.IMGID=B.IMGID AND A.OMID=? AND A.ID NOT IN (SELECT IMGAUTOID FROM ClientSystemTrMapping WHERE SYSTEMID =?)");
			pStmt.setString(1,sysInputDto.getOmID());
			pStmt.setString(2,sysInputDto.getSystemType());
			pStmt.setString(3,sysInputDto.getOmID());
			pStmt.setString(4,sysInputDto.getSystemType());
			rs = pStmt.executeQuery();
			outputDataList = new ArrayList<>();
			while(rs.next()){
				outputData = new ManageTrResponseDto();
				outputData.setImgId(rs.getString("IMGID"));
				outputData.setCustomizingTr(rs.getString("CTR"));
				outputData.setWorkbenchTr(rs.getString("KTR"));
				outputData.setImgDesc(rs.getString("IMGDESCR"));
				outputData.setId(rs.getString("ID")); 
				outputData.setTrType(rs.getString("TRTYPE"));
				outputData.setTrUpdated(false);
				outputData.setTrCusFieldReq(rs.getString("TRTYPE").contains("W"));
				outputData.setTrWKFieldReq(rs.getString("TRTYPE").contains("K"));
				outputData.setSno(sno++);
				outputData.setTrtype1("trtype");
				outputData.setTrtype2("trtype");
				outputDataList.add(outputData);
			}
			trListDto.setTrResponseDto(outputDataList);
			
		} catch (SQLException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}finally {
			if (pStmt != null) {
	            try {
	            	pStmt.close();
	            	pStmt = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }

	        if (con != null) {
	            try {
	            	con.close();
	            	con = null;
	            } catch (SQLException e) {
	            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	            }
	        }
			  slf4jLogger.info("getTrData method ended");

	        }
		return trListDto;
	}

}
