/**
 * 
 */
package com.acn.rpa.imghierarchy;

/**
 * @author insimmamul.haq.p.b
 *
 */
public class FieldMappingDto {

	private String s_IMGID;
	private String s_VIEW;
	private String s_FIELD;
	private String t_IMGID;
	private String t_VIEW;
	private String t_FIELD;
	private String message;
	private String status;
	
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public FieldMappingDto(){
	}

	public String getS_IMGID() {
		return s_IMGID;
	}

	public void setS_IMGID(String s_IMGID) {
		this.s_IMGID = s_IMGID;
	}

	public String getS_VIEW() {
		return s_VIEW;
	}

	public void setS_VIEW(String s_VIEW) {
		this.s_VIEW = s_VIEW;
	}

	public String getS_FIELD() {
		return s_FIELD;
	}

	public void setS_FIELD(String s_FIELD) {
		this.s_FIELD = s_FIELD;
	}

	public String getT_IMGID() {
		return t_IMGID;
	}

	public void setT_IMGID(String t_IMGID) {
		this.t_IMGID = t_IMGID;
	}

	public String getT_VIEW() {
		return t_VIEW;
	}

	public void setT_VIEW(String t_VIEW) {
		this.t_VIEW = t_VIEW;
	}

	public String getT_FIELD() {
		return t_FIELD;
	}

	public void setT_FIELD(String t_FIELD) {
		this.t_FIELD = t_FIELD;
	}
}
