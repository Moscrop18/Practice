package com.acn.rpa.imghierarchy;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.config.dto.ClientIMGHierarchyDto;
import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.DBConnection;
import com.acn.user.session.CustomerInputDto;
import com.acn.user.session.IMGPreviewDto;
import com.acn.user.session.ResMessageDto;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;


public class ClientImgHierarchyDAO {
    private final Logger slf4jLogger = LoggerFactory.getLogger(ClientImgHierarchyDAO.class);

public ClientImgResponseDto insertClientImgHierarchyData(InputClientImgHierarchyDto inputClientImgHierarchyObj)   {
	slf4jLogger.info("insertClientImgHierarchyData method started");
	Connection con = null;
    PreparedStatement ps=null;
    PreparedStatement ps2=null;
    PreparedStatement ps4=null;
    String processHierarchyQry="Insert into CLIENT_IMGHIERARCHY(IMGID,OMID,INDUSTRY) values(?,?,?)";
    ArrayList<String> imgIds = null;
    ResultSet rs = null;
	ClientImgResponseDto clientImgResponseDto = new ClientImgResponseDto();
	ResMessageDto resMessageDto = new ResMessageDto();
	clientImgResponseDto.setResMessageDto(resMessageDto);
	StringBuilder query = null;
	ArrayList<String> modifiedImgList = null;
	ArrayList<String> inputImgList = null;
	int len = 0;
    try {
			con = DBConnection.createConnection();
			if(inputClientImgHierarchyObj.getClientImgHierarchyList() != null && inputClientImgHierarchyObj.getClientImgHierarchyList().size() == 0){
				deleteFromTrSystemMapping(inputClientImgHierarchyObj,imgIds);
			
					ps2 = con.prepareStatement("DELETE FROM CLIENT_IMGHIERARCHY WHERE OMID=? AND INDUSTRY=?");
			
        		
        		ps2.setString(1, inputClientImgHierarchyObj.getOmId());
        		if(inputClientImgHierarchyObj.getSelectedArea()!=null && inputClientImgHierarchyObj.getSelectedArea().equalsIgnoreCase("Industry")){
        			ps2.setInt(2, 1);
        		}else {
        			ps2.setInt(2, 0);
        		}
        		
    			ps2.executeUpdate();
    			clientImgResponseDto.getResMessageDto().setMessage(ConstantsValues.UNASSIGNEDSCOPE_SUCCESS_MSG);
    			 slf4jLogger.error(ConstantsValues.UNASSIGNEDSCOPE_SUCCESS_MSG);
    			clientImgResponseDto.getResMessageDto().setMsgType(ConstantsValues.FALSESTATUS);
         	}	
			else{
			clientImgResponseDto.getResMessageDto().setMsgType(ConstantsValues.TRUESTATUS);
			imgIds = new ArrayList<>(); 
    		modifiedImgList = new ArrayList<>(); 
    		inputImgList = new ArrayList<>(); 
    		deleteScopes(inputClientImgHierarchyObj.getOmId());
    		
    		ps2 = con.prepareStatement("SELECT IMGID FROM CLIENT_IMGHIERARCHY WHERE OMID=? AND INDUSTRY =?");
    		ps2.setString(1, inputClientImgHierarchyObj.getOmId());
    		if(inputClientImgHierarchyObj.getSelectedArea()!=null && inputClientImgHierarchyObj.getSelectedArea().equalsIgnoreCase("Industry")){
    			ps2.setInt(2,1);
    		}else {
    			ps2.setInt(2,0);
    		}
    		
			rs = ps2.executeQuery();
			while(rs.next()){
				imgIds.add(rs.getString("IMGID"));
			
			}
			modifiedImgList.addAll(imgIds);

			inputImgList.addAll(inputClientImgHierarchyObj.getClientImgHierarchyList());
    		inputClientImgHierarchyObj.getClientImgHierarchyList().removeAll(modifiedImgList);
			imgIds.removeAll(inputImgList);
			ArrayList<String> test = imgIds; 
			deleteFromTrSystemMapping(inputClientImgHierarchyObj,test);
    		len = imgIds.size();
    		query = new StringBuilder("DELETE FROM CLIENT_IMGHIERARCHY WHERE OMID=? AND INDUSTRY = ? AND IMGID in (");
    	
    		for(int i=0;i<len;i++){
    			if(i==len-1)
    				query.append("?)");
    			else
    				query.append("?,");
    			
    		}
    		if(len >0){
        		ps4 = con.prepareStatement(query.toString());
        		ps4.setString(1, inputClientImgHierarchyObj.getOmId());
        		if(inputClientImgHierarchyObj.getSelectedArea()!=null && inputClientImgHierarchyObj.getSelectedArea().equalsIgnoreCase("Industry")){
        			ps4.setInt(2, 1);
        		}
        		else {
        			ps4.setInt(2, 0);
        		}
        		
        		 int pos = 3;
 			    for(int i=0;i<len;i++,pos++){
 			    	ps4.setString (pos, imgIds.get(i));				
 				}
    			ps4.executeUpdate();

    		}
    		ps=con.prepareStatement(processHierarchyQry);
    		len = inputClientImgHierarchyObj.getClientImgHierarchyList().size();
    		if(inputClientImgHierarchyObj.getSelectedArea()!=null && inputClientImgHierarchyObj.getSelectedArea().equalsIgnoreCase("Industry")){
    			for(int i=0 ; i < len ; i++){
        			ps.setString(1,inputClientImgHierarchyObj.getClientImgHierarchyList().get(i));
        			ps.setString(2,inputClientImgHierarchyObj.getOmId());
        			ps.setInt(3, 1);
        			
                    ps.addBatch();
            	}
    		}
    		else {
    			for(int i=0 ; i < len ; i++){
        			ps.setString(1,inputClientImgHierarchyObj.getClientImgHierarchyList().get(i));
        			ps.setString(2,inputClientImgHierarchyObj.getOmId());
        			ps.setInt(3, 0);
                    ps.addBatch();
            	}
    		}
    		
    		ps.executeBatch();
			clientImgResponseDto.getResMessageDto().setMessage(ConstantsValues.UNASSIGNEDSCOPE_SUCCESS_MSG);
			slf4jLogger.error(ConstantsValues.UNASSIGNEDSCOPE_SUCCESS_MSG);
			}

    } catch (Exception e) {
    	clientImgResponseDto.getResMessageDto().setMessage(ConstantsValues.DATABASEERROR);
		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	}
   finally{
	   if (ps4 != null) {
           try {
           	ps4.close();
           	ps4 = null;
           } catch (SQLException e) {
           	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
           }
       }
	   
		if (ps2 != null) {
            try {
            	ps2.close();
            	ps2 = null;
            } catch (SQLException e) {
            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
            }
        }
		if (ps != null) {
            try {
            	ps.close();
            	ps = null;
            } catch (SQLException e) {
            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
            }
        }
        if (con != null) {
            try {
            	con.close();
            	con = null;
            } catch (SQLException e) {
            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
            }
        }
        imgIds = null;
        modifiedImgList = null;
        query = null;
        inputImgList = null;
		slf4jLogger.info("insertClientImgHierarchyData method ended");

   }
	
	return clientImgResponseDto;
	
	
}


	public void deleteFromTrSystemMapping(InputClientImgHierarchyDto inputClientImgHierarchyObj,ArrayList<String> imgIds){
		slf4jLogger.info("deleteFromTrSystemMapping method started");
		Connection con = null;
	    PreparedStatement ps=null;
	    StringBuffer query = null;
	    PreparedStatement ps1=null;
	    int len =0;
	    try{
	    	con = DBConnection.createConnection();
	    	if(imgIds==null && inputClientImgHierarchyObj.getClientImgHierarchyList() != null && inputClientImgHierarchyObj.getClientImgHierarchyList().isEmpty() ){
		    	ps = con.prepareStatement("DELETE A FROM  ClientSystemTrMapping A,client_imghierarchy B WHERE A.IMGAUTOID = B.ID AND B.OMID=? AND B.INDUSTRY=?");
		    	ps.setString(1, inputClientImgHierarchyObj.getOmId());
		    	if(inputClientImgHierarchyObj.getSelectedArea()!=null && inputClientImgHierarchyObj.getSelectedArea().equalsIgnoreCase("Industry")) {
		    		ps.setInt(2, 1);
		    	}else {
		    		ps.setInt(2, 0);
		    	}
		    	ps.executeUpdate();
		    }
		    else{

		    	len = imgIds.size();
	    		query = new StringBuffer("Delete A FROM  ClientSystemTrMapping A,client_imghierarchy B WHERE A.IMGAUTOID = B.ID AND B.OMID=? AND B.INDUSTRY =? AND B.IMGID in (");
	    		
	    		for(int i=0;i<len;i++){
	    			if(i==len-1)
	    				query.append("?)");
	    			else
	    				query.append("?,");	    			
	    		}
	    		
	    		if(len >0){
	        		ps1 = con.prepareStatement(query.toString());
	        		ps1.setString(1, inputClientImgHierarchyObj.getOmId());
	        		if(inputClientImgHierarchyObj.getSelectedArea()!=null && inputClientImgHierarchyObj.getSelectedArea().equalsIgnoreCase("Industry")) {
	        			ps1.setInt(2, 1);
	        			
	        		}else {
	        			ps1.setInt(2, 0);
	        		}
	        		 int pos = 3;
	 			    for(int i=0;i<len;i++,pos++){
	 			    	ps1.setString (pos, imgIds.get(i));				
	 				}
	    			ps1.executeUpdate();

	    		}
		    	
		    }
	
	    }
	    catch(Exception e){
	    	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	    }
	    finally{
	    	 if (con != null) {
	             try {
	             	con.close();
	             	con = null;
	             } catch (SQLException e) {
	             	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	             }
	    }
			  slf4jLogger.info("deleteFromTrSystemMapping method ended");

	    }
	}

public void deleteScopes(String omId)   {
	slf4jLogger.info("deleteScopes method started");
	Connection con = null;
    PreparedStatement ps3=null;
    try {
    		con = DBConnection.createConnection();
    		ps3 = con.prepareStatement("DELETE FROM USERSSCOPEHISTORYLIST WHERE USERCONFIGSCOPEID IN (SELECT USERCONFIGSCOPEID FROM USERSSCOPEHISTORY WHERE OMID =?)");
    		ps3.setString(1, omId);
    		ps3.executeUpdate();
    		

    } catch (Exception e) {
		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	}
   finally{
	 
	   if (ps3 != null) {
           try {
           	ps3.close();
           	ps3 = null;
           } catch (SQLException e) {
           	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
           }
       }
		
        if (con != null) {
            try {
            	con.close();
            	con = null;
            } catch (SQLException e) {
            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
            }
        }
		  slf4jLogger.info("deleteScopes method ended");

   }
	
	
	
}

public ClientImgResponseDto previewClientImgHierarchy(String selectedOmid,String area)  {
	slf4jLogger.info("previewClientImgHierarchy method started");
	Connection con = null;
	ArrayList<String> clientImgHierarchyImgid = new ArrayList<String>();
	ResultSet rs=null;
	PreparedStatement pStmt=null;
	ClientImgResponseDto clientImgHierarchyDtoObj = null;
	boolean status = false;
	try{
		
		con = DBConnection.createConnection();
		clientImgHierarchyDtoObj = new ClientImgResponseDto();
		ResMessageDto resMessageDto = new ResMessageDto();
		clientImgHierarchyDtoObj.setResMessageDto(resMessageDto);
			pStmt = con.prepareStatement("SELECT IMGID FROM CLIENT_IMGHIERARCHY WHERE OMID=? AND INDUSTRY =?");
			
			pStmt.setString(1, selectedOmid);
			if(area!=null && area.equalsIgnoreCase("Industry")) {
				pStmt.setInt(2, 1);
			}else {
				pStmt.setInt(2, 0);
			}
			rs = pStmt.executeQuery();
			while(rs.next()){
				status = true;
				clientImgHierarchyImgid.add(rs.getString("IMGID"));
			}
			clientImgHierarchyDtoObj.setImgId(clientImgHierarchyImgid);
			if(!status){
				clientImgHierarchyDtoObj.getResMessageDto().setMessage(ConstantsValues.NORECORD);
				slf4jLogger.error(ConstantsValues.NORECORD);
				clientImgHierarchyDtoObj.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
				}
	}
	catch (SQLException e){
		clientImgHierarchyDtoObj.getResMessageDto().setMessage(ConstantsValues.DATABASEERROR);
		slf4jLogger.error(ConstantsValues.DATABASEERROR);
		clientImgHierarchyDtoObj.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
	}finally{
		if(rs!=null){
			try {
				rs.close();
				rs= null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		if(pStmt!=null){
			try {
				pStmt.close();
				pStmt=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		if(con!=null){
			try {
				con.close();
				con=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		  slf4jLogger.info("previewClientImgHierarchy method ended");

	}
		return clientImgHierarchyDtoObj;
}
public ClientImgResponseDto viewClientBPHierarchyforCopyFunctionality(String omId){
	slf4jLogger.info("viewClientImgHierarchy method started");
	Connection con = null;
	ArrayList <ImgHierarchyDto> globalArrayImg = null;
	ArrayList <ImgHierarchyDto> globalArrayImg1 = null;
	ArrayList <ImgHierarchyDto> globalArrayImgClientList = null;
	ClientImgResponseDto clientImgResponseDto = null;
	ImgHierarchyDto ImgData = null;
	ResultSet rs=null;
	ResultSet rs1=null;
	ImgHierarchyDto imgHierarchyDto = null;
	PreparedStatement pStmt=null;
	PreparedStatement pStmt1=null;
	ArrayList<String> imgIdList = null;
	ArrayList<String> imgDescrList = null;
	ArrayList<ImgHierarchyDto> ParentNodeArray = null;
	ArrayList<ImgHierarchyDto> ParentNodeArray1 = null;
	ArrayList<Integer> map = null;
	ImgHierarchyDto parent = null;
	Gson gson = null;
	JsonArray myCustomArray = null;
	ImgHierarchyDto node = null;
	String output = null;
	int count = 0 ;
	ImgHierarchyDto imgHierarchyParentObj = null;
	HashSet<Integer> parentNodeArr = null;
	int arrLen = 0;
	try{ 
		imgIdList = new ArrayList<>();
		imgDescrList = new ArrayList<>();
		map = new ArrayList<>();
		ParentNodeArray = new ArrayList<>();
		ParentNodeArray1 = new ArrayList<>();
		clientImgResponseDto = new ClientImgResponseDto();
		ResMessageDto resMessageDto = new ResMessageDto();
		clientImgResponseDto.setResMessageDto(resMessageDto);
		globalArrayImg = new ArrayList<>(); 
		globalArrayImg1 = new ArrayList<>(); 
		globalArrayImgClientList = new ArrayList<>(); 
		parentNodeArr = new HashSet<>();
		con = DBConnection.createConnection();
		//pStmt =  con.prepareStatement("SELECT A.IMGID,A.IMGDESCR,A.SEQUENCING,A.NODELEVEL,A.ISMASTERDATA,A.ENABLED,A.TRTYPE FROM COPYFUNCTIONALITY_IMGHIERARCHY A WHERE A.ENABLED=? ORDER BY A.ID");
		
		pStmt =  con.prepareStatement("SELECT IMGID,IMGDESCR,SEQUENCING,NODELEVEL,ISMASTERDATA,ENABLED,TRTYPE FROM COPYFUNCTIONALITY_IMGHIERARCHY WHERE ENABLED=? ORDER BY ID");
		pStmt1 = con.prepareStatement("SELECT A.IMGID, B.IMGDESCR FROM CLIENT_IMGHIERARCHY A,COPYFUNCTIONALITY_IMGHIERARCHY B WHERE A.IMGID=B.IMGID AND A.OMID=? AND B.NODELEVEL NOT IN('1') ORDER BY B.ID");
		pStmt1.setString(1,omId);
		rs1 = pStmt1.executeQuery();
		//pStmt.setString(1,omId);
		pStmt.setInt(1, 1);
		rs = pStmt.executeQuery();
		while(rs1.next()){
			imgIdList.add(rs1.getString("IMGID"));
			imgDescrList.add(rs1.getString("IMGDESCR")) ;
			}
		while(rs.next()){
			count++;
			imgHierarchyDto = new ImgHierarchyDto();
			imgHierarchyDto.setId(count);
			imgHierarchyDto.setImgId(rs.getString("IMGID"));
			imgHierarchyDto.setImgDescription(rs.getString("SEQUENCING").equals("")?rs.getString("IMGDESCR"):rs.getString("SEQUENCING")+"_"+rs.getString("IMGDESCR")); 
			imgHierarchyDto.setSequence(rs.getString("SEQUENCING"));
			imgHierarchyDto.setNodeLevel(rs.getInt("NODELEVEL"));
			if(imgHierarchyDto.getNodeLevel()==1)
				imgHierarchyDto.setImgId("");
			imgHierarchyDto.setIsMasterData(rs.getString("ISMASTERDATA"));
			imgHierarchyDto.setEnabled(rs.getInt("ENABLED"));
			imgHierarchyDto.setTrType(rs.getString("TRTYPE")); 
			imgHierarchyDto.setParentNode(getMyParentID(imgHierarchyDto.getNodeLevel(),ParentNodeArray));
			globalArrayImg.add(imgHierarchyDto);
			parent = new ImgHierarchyDto();
			parent.setNodeLevel(imgHierarchyDto.getNodeLevel());
			parent.setId(count);
			ParentNodeArray.add(parent);
		}
		
			for(ImgHierarchyDto imgHierarchyDtoObj : globalArrayImg){
				if(imgIdList.contains(imgHierarchyDtoObj.getImgId())){
					globalArrayImgClientList.add(imgHierarchyDtoObj);
					imgHierarchyParentObj = imgHierarchyDtoObj;
					while(imgHierarchyParentObj.getParentNode() != 0 && !parentNodeArr.contains(imgHierarchyParentObj.getParentNode())){
						parentNodeArr.add(imgHierarchyParentObj.getParentNode());

						imgHierarchyParentObj = containsParentId(globalArrayImg,imgHierarchyParentObj.getParentNode());
						globalArrayImgClientList.add(imgHierarchyParentObj);

					}
				}
			}

			Collections.sort(globalArrayImgClientList, new Comparator<ImgHierarchyDto>(){
				   public int compare(ImgHierarchyDto o1, ImgHierarchyDto o2){
				      return o1.getId() - o2.getId();
				   }
				});
			
			arrLen = globalArrayImgClientList.size();
			for(int i=0 ;i < arrLen ; i++){			
				ImgData = new ImgHierarchyDto();
				ImgData = globalArrayImgClientList.get(i);

				ImgData.setParentNode(getMyParentID(globalArrayImgClientList.get(i).getNodeLevel(),ParentNodeArray1));
				globalArrayImg1.add(ImgData);
				ImgHierarchyDto parent1 = new ImgHierarchyDto();
				parent1.setNodeLevel(globalArrayImgClientList.get(i).getNodeLevel());
				parent1.setId(i+1);
				ParentNodeArray1.add(parent1);
			}
			
			gson = new GsonBuilder().create();
			myCustomArray = gson.toJsonTree(globalArrayImg1).getAsJsonArray();
			
			map.add(0);
			
			
			node = new ImgHierarchyDto();
			arrLen = globalArrayImg1.size();
			for(int i = 0; i < arrLen ; i++){
				node = globalArrayImg1.get(i);
				map.add(i+1,i);
				if(node.getParentNode() != 0){
					globalArrayImg1.get(map.get(node.getParentNode())).setChildren(node);
				}
			}
			 gson = new GsonBuilder().create();
			 myCustomArray = gson.toJsonTree(globalArrayImg1).getAsJsonArray();
			 if(globalArrayImg1.size()>0)
				 output = myCustomArray.get(0).toString();
			 
			 clientImgResponseDto.getResMessageDto().setMessage(output);
			 clientImgResponseDto.setImgId(imgIdList);
			 clientImgResponseDto.setImgDescr(imgDescrList);
	}
	
		catch (Exception e){
		clientImgResponseDto.getResMessageDto().setMessage(ConstantsValues.DATABASEERROR);
		clientImgResponseDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}
	finally{
		
		if(rs1!=null){
			try {
				rs1.close();
				rs1=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		
		if(pStmt1!=null){
			try {
				pStmt1.close();
				pStmt1=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		
		if(rs!=null){
			try {
				rs.close();
				rs=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		
		if(pStmt!=null){
			try {
				pStmt.close();
				pStmt=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		
		if(con!=null){
			try {
				con.close();
				con=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		
		globalArrayImg = null;
		globalArrayImg1 = null;
		globalArrayImgClientList = null;
		ImgData = null;
		imgHierarchyDto = null;
		imgIdList = null;
		ParentNodeArray = null;
		ParentNodeArray1 = null;
		map = null;
		parent = null;
		gson = null;
		myCustomArray = null;
		node = null;
		imgHierarchyParentObj = null;
		parentNodeArr = null;
		slf4jLogger.info("viewClientImgHierarchy method ended");

	}
	
	return clientImgResponseDto;

	
	
}
public ClientImgResponseDto viewClientImgHierarchyForConsolidation(String omId){
	slf4jLogger.info("viewClientImgHierarchyForConsolidation method started");
	Connection con = null;
	ArrayList <ImgHierarchyDto> globalArrayImg = null;
	ArrayList <ImgHierarchyDto> globalArrayImg1 = null;
	ArrayList <ImgHierarchyDto> globalArrayImgClientList = null;
	ClientImgResponseDto clientImgResponseDto = null;
	ImgHierarchyDto ImgData = null;
	ResultSet rs=null;
	ResultSet rs1=null;
	ResultSet rs2=null;
	ImgHierarchyDto imgHierarchyDto = null;
	PreparedStatement pStmt=null;
	PreparedStatement pStmt1=null;
	PreparedStatement pStmt2=null;
	ArrayList<String> imgIdList = null;
	ArrayList<String> viewList = null;
	ArrayList<String> imgDescrList = null;
	ArrayList<ImgHierarchyDto> ParentNodeArray = null;
	ArrayList<ImgHierarchyDto> ParentNodeArray1 = null;
	ArrayList<Integer> map = null;
	ImgHierarchyDto parent = null;
	Gson gson = null;
	JsonArray myCustomArray = null;
	ImgHierarchyDto node = null;
	String output = null;
	int count = 0 ;
	ImgHierarchyDto imgHierarchyParentObj = null;
	HashSet<Integer> parentNodeArr = null;
	int arrLen = 0;
	try{ 
		imgIdList = new ArrayList<>();
		imgDescrList = new ArrayList<>();
		map = new ArrayList<>();
		ParentNodeArray = new ArrayList<>();
		ParentNodeArray1 = new ArrayList<>();
		clientImgResponseDto = new ClientImgResponseDto();
		ResMessageDto resMessageDto = new ResMessageDto();
		clientImgResponseDto.setResMessageDto(resMessageDto);
		globalArrayImg = new ArrayList<>(); 
		globalArrayImg1 = new ArrayList<>(); 
		globalArrayImgClientList = new ArrayList<>(); 
		HashMap<String,ArrayList<String>> imgViewList=new HashMap<String,ArrayList<String>>();
		parentNodeArr = new HashSet<>();
		con = DBConnection.createConnection();
		pStmt =  con.prepareStatement("SELECT IMGID,IMGDESCR,SEQUENCING,NODELEVEL,ISMASTERDATA,ENABLED,TRTYPE FROM IMGHIERARCHY WHERE ENABLED=? AND C_FIELD=1 ORDER BY ID");
		pStmt1 = con.prepareStatement("SELECT A.IMGID, B.IMGDESCR FROM CLIENT_IMGHIERARCHY A,IMGHIERARCHY B WHERE A.IMGID=B.IMGID AND A.OMID=? AND B.C_FIELD=1 AND A.INDUSTRY=0 ORDER BY B.ID");
		pStmt1.setString(1,omId);
		rs1 = pStmt1.executeQuery();

		pStmt.setInt(1, 1);
		rs = pStmt.executeQuery();
		while(rs1.next()){
			//imgIdList.add(rs1.getString("IMGID"));
			//imgDescrList.add(rs1.getString("IMGDESCR")) ;
			pStmt2 =  con.prepareStatement("SELECT OBJECTNAME FROM IMGOBJECTS WHERE IMGID=? AND C_FIELD=1 ORDER BY SEQNO");
			pStmt2.setString(1,rs1.getString("IMGID"));
			rs2 = pStmt2.executeQuery();
			viewList=new ArrayList<>();
				while (rs2.next()) {
					viewList.add(rs2.getString("OBJECTNAME"));
					imgIdList.add(rs1.getString("IMGID")+"-"+rs2.getString("OBJECTNAME"));
					imgDescrList.add(rs1.getString("IMGDESCR")+"-"+rs2.getString("OBJECTNAME"));
				}
				imgViewList.put(rs1.getString("IMGID"), viewList);
			}
		count++;
		imgHierarchyDto = new ImgHierarchyDto();
		imgHierarchyDto.setId(count);
		imgHierarchyDto.setImgId("");
		imgHierarchyDto.setImgDescription("Consolidation Functionality"); 
		imgHierarchyDto.setSequence("");
		imgHierarchyDto.setNodeLevel(0);
		imgHierarchyDto.setIsMasterData("");
		imgHierarchyDto.setEnabled(1);
		imgHierarchyDto.setTrType(""); 
		imgHierarchyDto.setParentNode(getMyParentID(imgHierarchyDto.getNodeLevel(),ParentNodeArray));
		globalArrayImg.add(imgHierarchyDto);
		parent = new ImgHierarchyDto();
		parent.setNodeLevel(imgHierarchyDto.getNodeLevel());
		parent.setId(count);
		ParentNodeArray.add(parent);
		
		while(rs.next()){
			if(imgViewList.containsKey(rs.getString("IMGID"))) {
				count++;
				imgHierarchyDto = new ImgHierarchyDto();
				imgHierarchyDto.setId(count);
				imgHierarchyDto.setImgId("");
				imgHierarchyDto.setImgDescription(rs.getString("SEQUENCING").equals("")?rs.getString("IMGDESCR"):rs.getString("SEQUENCING")+"_"+rs.getString("IMGDESCR")); 
				imgHierarchyDto.setSequence(rs.getString("SEQUENCING"));
				imgHierarchyDto.setNodeLevel(1);
				imgHierarchyDto.setIsMasterData(rs.getString("ISMASTERDATA"));
				imgHierarchyDto.setEnabled(rs.getInt("ENABLED"));
				imgHierarchyDto.setTrType(rs.getString("TRTYPE")); 
				imgHierarchyDto.setParentNode(getMyParentID(imgHierarchyDto.getNodeLevel(),ParentNodeArray));
				globalArrayImg.add(imgHierarchyDto);
				parent = new ImgHierarchyDto();
				parent.setNodeLevel(imgHierarchyDto.getNodeLevel());
				parent.setId(count);
				ParentNodeArray.add(parent);
				
			for(String view:imgViewList.get(rs.getString("IMGID"))) {
			count++;
			imgHierarchyDto = new ImgHierarchyDto();
			imgHierarchyDto.setId(count);
			imgHierarchyDto.setImgId(rs.getString("IMGID")+"-"+view);
			imgHierarchyDto.setImgDescription(rs.getString("SEQUENCING").equals("")?rs.getString("IMGDESCR"):rs.getString("SEQUENCING")+"_"+rs.getString("IMGDESCR")+"-"+view); 
			imgHierarchyDto.setSequence(rs.getString("SEQUENCING"));
			imgHierarchyDto.setNodeLevel(2);
			imgHierarchyDto.setIsMasterData(rs.getString("ISMASTERDATA"));
			imgHierarchyDto.setEnabled(rs.getInt("ENABLED"));
			imgHierarchyDto.setTrType(rs.getString("TRTYPE")); 
			imgHierarchyDto.setParentNode(getMyParentID(imgHierarchyDto.getNodeLevel(),ParentNodeArray));
			globalArrayImg.add(imgHierarchyDto);
			parent = new ImgHierarchyDto();
			parent.setNodeLevel(imgHierarchyDto.getNodeLevel());
			parent.setId(count);
			ParentNodeArray.add(parent);
				}
			}
		}
		
			for(ImgHierarchyDto imgHierarchyDtoObj : globalArrayImg){
				if(imgIdList.contains(imgHierarchyDtoObj.getImgId())){
					globalArrayImgClientList.add(imgHierarchyDtoObj);
					imgHierarchyParentObj = imgHierarchyDtoObj;
					while(imgHierarchyParentObj.getParentNode() != 0 && !parentNodeArr.contains(imgHierarchyParentObj.getParentNode())){
						parentNodeArr.add(imgHierarchyParentObj.getParentNode());

						imgHierarchyParentObj = containsParentId(globalArrayImg,imgHierarchyParentObj.getParentNode());
						globalArrayImgClientList.add(imgHierarchyParentObj);

					}
				}
			}

			Collections.sort(globalArrayImgClientList, new Comparator<ImgHierarchyDto>(){
				   public int compare(ImgHierarchyDto o1, ImgHierarchyDto o2){
				      return o1.getId() - o2.getId();
				   }
				});
			
			arrLen = globalArrayImgClientList.size();
			for(int i=0 ;i < arrLen ; i++){			
				ImgData = new ImgHierarchyDto();
				ImgData = globalArrayImgClientList.get(i);

				ImgData.setParentNode(getMyParentID(globalArrayImgClientList.get(i).getNodeLevel(),ParentNodeArray1));
				globalArrayImg1.add(ImgData);
				ImgHierarchyDto parent1 = new ImgHierarchyDto();
				parent1.setNodeLevel(globalArrayImgClientList.get(i).getNodeLevel());
				parent1.setId(i+1);
				ParentNodeArray1.add(parent1);
			}
			
			gson = new GsonBuilder().create();
			myCustomArray = gson.toJsonTree(globalArrayImg1).getAsJsonArray();
			
			map.add(0);
			
			
			node = new ImgHierarchyDto();
			arrLen = globalArrayImg1.size();
			for(int i = 0; i < arrLen ; i++){
				node = globalArrayImg1.get(i);
				map.add(i+1,i);
				if(node.getParentNode() != 0){
					globalArrayImg1.get(map.get(node.getParentNode())).setChildren(node);
				}
			}
			 gson = new GsonBuilder().create();
			 myCustomArray = gson.toJsonTree(globalArrayImg1).getAsJsonArray();
			 if(globalArrayImg1.size()>0)
				 output = myCustomArray.get(0).toString();
			 
			 clientImgResponseDto.getResMessageDto().setMessage(output);
			 clientImgResponseDto.setImgId(imgIdList);
			 clientImgResponseDto.setImgDescr(imgDescrList);
	}
	
		catch (Exception e){
		clientImgResponseDto.getResMessageDto().setMessage(ConstantsValues.DATABASEERROR);
		clientImgResponseDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}
	finally{
		
		if(rs1!=null){
			try {
				rs1.close();
				rs1=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		
		if(pStmt1!=null){
			try {
				pStmt1.close();
				pStmt1=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		
		if(rs!=null){
			try {
				rs.close();
				rs=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		
		if(pStmt!=null){
			try {
				pStmt.close();
				pStmt=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		
		if(con!=null){
			try {
				con.close();
				con=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		
		globalArrayImg = null;
		globalArrayImg1 = null;
		globalArrayImgClientList = null;
		ImgData = null;
		imgHierarchyDto = null;
		imgIdList = null;
		ParentNodeArray = null;
		ParentNodeArray1 = null;
		map = null;
		parent = null;
		gson = null;
		myCustomArray = null;
		node = null;
		imgHierarchyParentObj = null;
		parentNodeArr = null;
		slf4jLogger.info("viewClientImgHierarchyForConsolidation method ended");

	}
	
	return clientImgResponseDto;

	
	
}

public ClientImgResponseDto viewClientImgHierarchyforCopyFunctionality(String omId){
	slf4jLogger.info("viewClientImgHierarchy method started");
	Connection con = null;
	ArrayList <ImgHierarchyDto> globalArrayImg = null;
	ArrayList <ImgHierarchyDto> globalArrayImg1 = null;
	ArrayList <ImgHierarchyDto> globalArrayImgClientList = null;
	ClientImgResponseDto clientImgResponseDto = null;
	ImgHierarchyDto ImgData = null;
	ResultSet rs=null;
	ResultSet rs1=null;
	ImgHierarchyDto imgHierarchyDto = null;
	PreparedStatement pStmt=null;
	PreparedStatement pStmt1=null;
	ArrayList<String> imgIdList = null;
	ArrayList<String> imgDescrList = null;
	ArrayList<ImgHierarchyDto> ParentNodeArray = null;
	ArrayList<ImgHierarchyDto> ParentNodeArray1 = null;
	ArrayList<Integer> map = null;
	ImgHierarchyDto parent = null;
	Gson gson = null;
	JsonArray myCustomArray = null;
	ImgHierarchyDto node = null;
	String output = null;
	int count = 0 ;
	ImgHierarchyDto imgHierarchyParentObj = null;
	HashSet<Integer> parentNodeArr = null;
	int arrLen = 0;
	try{ 
		imgIdList = new ArrayList<>();
		imgDescrList = new ArrayList<>();
		map = new ArrayList<>();
		ParentNodeArray = new ArrayList<>();
		ParentNodeArray1 = new ArrayList<>();
		clientImgResponseDto = new ClientImgResponseDto();
		ResMessageDto resMessageDto = new ResMessageDto();
		clientImgResponseDto.setResMessageDto(resMessageDto);
		globalArrayImg = new ArrayList<>(); 
		globalArrayImg1 = new ArrayList<>(); 
		globalArrayImgClientList = new ArrayList<>(); 
		parentNodeArr = new HashSet<>();
		con = DBConnection.createConnection();
		pStmt =  con.prepareStatement("SELECT IMGID,IMGDESCR,SEQUENCING,NODELEVEL,ISMASTERDATA,ENABLED,TRTYPE FROM COPYFUNCTIONALITY_IMGHIERARCHY WHERE ENABLED=? AND NODELEVEL IN ('0','1') ORDER BY ID");
		pStmt1 = con.prepareStatement("SELECT A.IMGID, B.IMGDESCR FROM CLIENT_IMGHIERARCHY A,COPYFUNCTIONALITY_IMGHIERARCHY B WHERE A.IMGID=B.IMGID AND A.OMID=? ORDER BY B.ID");
		pStmt1.setString(1,omId);
		rs1 = pStmt1.executeQuery();

		pStmt.setInt(1, 1);
		rs = pStmt.executeQuery();
		while(rs1.next()){
			imgIdList.add(rs1.getString("IMGID"));
			imgDescrList.add(rs1.getString("IMGDESCR")) ;
			}
		while(rs.next()){
			count++;
			imgHierarchyDto = new ImgHierarchyDto();
			imgHierarchyDto.setId(count);
			imgHierarchyDto.setImgId(rs.getString("IMGID"));
			imgHierarchyDto.setImgDescription(rs.getString("SEQUENCING").equals("")?rs.getString("IMGDESCR"):rs.getString("SEQUENCING")+"_"+rs.getString("IMGDESCR")); 
			imgHierarchyDto.setSequence(rs.getString("SEQUENCING"));
			imgHierarchyDto.setNodeLevel(rs.getInt("NODELEVEL"));
			imgHierarchyDto.setIsMasterData(rs.getString("ISMASTERDATA"));
			imgHierarchyDto.setEnabled(rs.getInt("ENABLED"));
			imgHierarchyDto.setTrType(rs.getString("TRTYPE")); 
			imgHierarchyDto.setParentNode(getMyParentID(imgHierarchyDto.getNodeLevel(),ParentNodeArray));
			globalArrayImg.add(imgHierarchyDto);
			parent = new ImgHierarchyDto();
			parent.setNodeLevel(imgHierarchyDto.getNodeLevel());
			parent.setId(count);
			ParentNodeArray.add(parent);
		}
		
			for(ImgHierarchyDto imgHierarchyDtoObj : globalArrayImg){
				if(imgIdList.contains(imgHierarchyDtoObj.getImgId())){
					globalArrayImgClientList.add(imgHierarchyDtoObj);
					imgHierarchyParentObj = imgHierarchyDtoObj;
					while(imgHierarchyParentObj.getParentNode() != 0 && !parentNodeArr.contains(imgHierarchyParentObj.getParentNode())){
						parentNodeArr.add(imgHierarchyParentObj.getParentNode());

						imgHierarchyParentObj = containsParentId(globalArrayImg,imgHierarchyParentObj.getParentNode());
						globalArrayImgClientList.add(imgHierarchyParentObj);

					}
				}
			}

			Collections.sort(globalArrayImgClientList, new Comparator<ImgHierarchyDto>(){
				   public int compare(ImgHierarchyDto o1, ImgHierarchyDto o2){
				      return o1.getId() - o2.getId();
				   }
				});
			
			arrLen = globalArrayImgClientList.size();
			for(int i=0 ;i < arrLen ; i++){			
				ImgData = new ImgHierarchyDto();
				ImgData = globalArrayImgClientList.get(i);

				ImgData.setParentNode(getMyParentID(globalArrayImgClientList.get(i).getNodeLevel(),ParentNodeArray1));
				globalArrayImg1.add(ImgData);
				ImgHierarchyDto parent1 = new ImgHierarchyDto();
				parent1.setNodeLevel(globalArrayImgClientList.get(i).getNodeLevel());
				parent1.setId(i+1);
				ParentNodeArray1.add(parent1);
			}
			
			gson = new GsonBuilder().create();
			myCustomArray = gson.toJsonTree(globalArrayImg1).getAsJsonArray();
			
			map.add(0);
			
			
			node = new ImgHierarchyDto();
			arrLen = globalArrayImg1.size();
			for(int i = 0; i < arrLen ; i++){
				node = globalArrayImg1.get(i);
				map.add(i+1,i);
				if(node.getParentNode() != 0){
					globalArrayImg1.get(map.get(node.getParentNode())).setChildren(node);
				}
			}
			 gson = new GsonBuilder().create();
			 myCustomArray = gson.toJsonTree(globalArrayImg1).getAsJsonArray();
			 if(globalArrayImg1.size()>0)
				 output = myCustomArray.get(0).toString();
			 
			 clientImgResponseDto.getResMessageDto().setMessage(output);
			 clientImgResponseDto.setImgId(imgIdList);
			 clientImgResponseDto.setImgDescr(imgDescrList);
	}
	
		catch (Exception e){
		clientImgResponseDto.getResMessageDto().setMessage(ConstantsValues.DATABASEERROR);
		clientImgResponseDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}
	finally{
		
		if(rs1!=null){
			try {
				rs1.close();
				rs1=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		
		if(pStmt1!=null){
			try {
				pStmt1.close();
				pStmt1=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		
		if(rs!=null){
			try {
				rs.close();
				rs=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		
		if(pStmt!=null){
			try {
				pStmt.close();
				pStmt=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		
		if(con!=null){
			try {
				con.close();
				con=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		
		globalArrayImg = null;
		globalArrayImg1 = null;
		globalArrayImgClientList = null;
		ImgData = null;
		imgHierarchyDto = null;
		imgIdList = null;
		ParentNodeArray = null;
		ParentNodeArray1 = null;
		map = null;
		parent = null;
		gson = null;
		myCustomArray = null;
		node = null;
		imgHierarchyParentObj = null;
		parentNodeArr = null;
		slf4jLogger.info("viewClientImgHierarchy method ended");

	}
	
	return clientImgResponseDto;

	
	
}
public ClientImgResponseDto viewClientImgHierarchyForIndustry(IMGPreviewDto dto){
	slf4jLogger.info("viewClientImgHierarchyForIndustry method started");
	Connection con = null;
	ArrayList <ImgHierarchyDto> globalArrayImg = null;
	ArrayList <ImgHierarchyDto> globalArrayImg1 = null;
	ArrayList <ImgHierarchyDto> globalArrayImgClientList = null;
	ClientImgResponseDto clientImgResponseDto = null;
	ImgHierarchyDto ImgData = null;
	ResultSet rs=null;
	ResultSet rs1=null;
	ImgHierarchyDto imgHierarchyDto = null;
	PreparedStatement pStmt=null;
	PreparedStatement pStmt1=null;
	ArrayList<String> imgIdList = null;
	ArrayList<String> imgDescrList = null;
	ArrayList<ImgHierarchyDto> ParentNodeArray = null;
	ArrayList<ImgHierarchyDto> ParentNodeArray1 = null;
	ArrayList<Integer> map = null;
	ImgHierarchyDto parent = null;
	Gson gson = null;
	JsonArray myCustomArray = null;
	ImgHierarchyDto node = null;
	String output = null;
	int count = 0 ;
	ImgHierarchyDto imgHierarchyParentObj = null;
	HashSet<Integer> parentNodeArr = null;
	int arrLen = 0;
	try{ 
		imgIdList = new ArrayList<>();
		imgDescrList = new ArrayList<>();
		map = new ArrayList<>();
		ParentNodeArray = new ArrayList<>();
		ParentNodeArray1 = new ArrayList<>();
		clientImgResponseDto = new ClientImgResponseDto();
		ResMessageDto resMessageDto = new ResMessageDto();
		clientImgResponseDto.setResMessageDto(resMessageDto);
		globalArrayImg = new ArrayList<>(); 
		globalArrayImg1 = new ArrayList<>(); 
		globalArrayImgClientList = new ArrayList<>(); 
		parentNodeArr = new HashSet<>();
		con = DBConnection.createConnection();
		
			pStmt =  con.prepareStatement("SELECT IMGID,IMGDESCR,SEQUENCING,IND_SEQ,NODELEVEL,ISMASTERDATA,ENABLED,TRTYPE FROM INDUSTRY_IMGHIERARCHY WHERE ENABLED=? "
					+ "AND INDUSTRY LIKE ? AND SUBINDUSTRY LIKE ? ORDER BY ID");
			pStmt1 = con.prepareStatement("SELECT A.IMGID, B.IMGDESCR FROM CLIENT_IMGHIERARCHY A,INDUSTRY_IMGHIERARCHY B WHERE A.IMGID=B.IMGID AND A.OMID=? AND A.INDUSTRY=? ORDER BY B.ID");	
		
		pStmt1.setString(1,dto.getSelectedOmid());
		pStmt1.setInt(2, 1);
		
		rs1 = pStmt1.executeQuery();

		pStmt.setInt(1, 1);
		pStmt.setString(2, "%" + dto.getIndustry() + "%");
		pStmt.setString(3, "%" + dto.getSubIndustry() + "%");
		
		rs = pStmt.executeQuery();
		while(rs1.next()){
			imgIdList.add(rs1.getString("IMGID"));
			imgDescrList.add(rs1.getString("IMGDESCR")) ;
			}
		
		while(rs.next()){
			count++;
			imgHierarchyDto = new ImgHierarchyDto();
			imgHierarchyDto.setId(count);
			imgHierarchyDto.setImgId(rs.getString("IMGID"));
			if(dto.isDownloadTemplate()) {
				imgHierarchyDto.setImgDescription(rs.getString("SEQUENCING").equals("")?rs.getString("IMGDESCR"):rs.getString("SEQUENCING")+"_"+rs.getString("IMGDESCR"));
			}
			else {
				imgHierarchyDto.setImgDescription(rs.getString("IND_SEQ").equals("")?rs.getString("IMGDESCR"):rs.getString("IND_SEQ")+"_"+rs.getString("IMGDESCR"));
				imgHierarchyDto.setIndSeq(rs.getString("IND_SEQ"));
			}
			 
			imgHierarchyDto.setSequence(rs.getString("SEQUENCING"));
			imgHierarchyDto.setNodeLevel(rs.getInt("NODELEVEL"));
			imgHierarchyDto.setIsMasterData(rs.getString("ISMASTERDATA"));
			imgHierarchyDto.setEnabled(rs.getInt("ENABLED"));
			imgHierarchyDto.setTrType(rs.getString("TRTYPE")); 
			imgHierarchyDto.setParentNode(getMyParentID(imgHierarchyDto.getNodeLevel(),ParentNodeArray));
			globalArrayImg.add(imgHierarchyDto);
			parent = new ImgHierarchyDto();
			parent.setNodeLevel(imgHierarchyDto.getNodeLevel());
			parent.setId(count);
			ParentNodeArray.add(parent);
		}
		
			for(ImgHierarchyDto imgHierarchyDtoObj : globalArrayImg){
				if(imgIdList.contains(imgHierarchyDtoObj.getImgId())){
					globalArrayImgClientList.add(imgHierarchyDtoObj);
					imgHierarchyParentObj = imgHierarchyDtoObj;
					while(imgHierarchyParentObj.getParentNode() != 0 && !parentNodeArr.contains(imgHierarchyParentObj.getParentNode())){
						parentNodeArr.add(imgHierarchyParentObj.getParentNode());

						imgHierarchyParentObj = containsParentId(globalArrayImg,imgHierarchyParentObj.getParentNode());
						globalArrayImgClientList.add(imgHierarchyParentObj);

					}
				}
			}

			Collections.sort(globalArrayImgClientList, new Comparator<ImgHierarchyDto>(){
				   public int compare(ImgHierarchyDto o1, ImgHierarchyDto o2){
				      return o1.getId() - o2.getId();
				   }
				});
			
			arrLen = globalArrayImgClientList.size();
			for(int i=0 ;i < arrLen ; i++){			
				ImgData = new ImgHierarchyDto();
				ImgData = globalArrayImgClientList.get(i);

				ImgData.setParentNode(getMyParentID(globalArrayImgClientList.get(i).getNodeLevel(),ParentNodeArray1));
				globalArrayImg1.add(ImgData);
				ImgHierarchyDto parent1 = new ImgHierarchyDto();
				parent1.setNodeLevel(globalArrayImgClientList.get(i).getNodeLevel());
				parent1.setId(i+1);
				ParentNodeArray1.add(parent1);
			}
			
			gson = new GsonBuilder().create();
			myCustomArray = gson.toJsonTree(globalArrayImg1).getAsJsonArray();
			
			map.add(0);
			
			
			node = new ImgHierarchyDto();
			arrLen = globalArrayImg1.size();
			for(int i = 0; i < arrLen ; i++){
				node = globalArrayImg1.get(i);
				map.add(i+1,i);
				if(node.getParentNode() != 0){
					globalArrayImg1.get(map.get(node.getParentNode())).setChildren(node);
				}
			}
			 gson = new GsonBuilder().create();
			 myCustomArray = gson.toJsonTree(globalArrayImg1).getAsJsonArray();
			 if(globalArrayImg1.size()>0)
				 output = myCustomArray.get(0).toString();
			 
			 clientImgResponseDto.getResMessageDto().setMessage(output);
			 clientImgResponseDto.setImgId(imgIdList);
			 clientImgResponseDto.setImgDescr(imgDescrList);
	}
	
		catch (Exception e){
		clientImgResponseDto.getResMessageDto().setMessage(ConstantsValues.DATABASEERROR);
		clientImgResponseDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}
	finally{
		
		if(rs1!=null){
			try {
				rs1.close();
				rs1=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		
		if(pStmt1!=null){
			try {
				pStmt1.close();
				pStmt1=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		
		if(rs!=null){
			try {
				rs.close();
				rs=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		
		if(pStmt!=null){
			try {
				pStmt.close();
				pStmt=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		
		if(con!=null){
			try {
				con.close();
				con=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		
		globalArrayImg = null;
		globalArrayImg1 = null;
		globalArrayImgClientList = null;
		ImgData = null;
		imgHierarchyDto = null;
		imgIdList = null;
		ParentNodeArray = null;
		ParentNodeArray1 = null;
		map = null;
		parent = null;
		gson = null;
		myCustomArray = null;
		node = null;
		imgHierarchyParentObj = null;
		parentNodeArr = null;
		slf4jLogger.info("viewClientImgHierarchyForIndustry method ended");

	}
	
	return clientImgResponseDto;

	
	
}
public ClientImgResponseDto viewClientImgHierarchy(IMGPreviewDto dto){
	slf4jLogger.info("viewClientImgHierarchy method started");
	Connection con = null;
	ArrayList <ImgHierarchyDto> globalArrayImg = null;
	ArrayList <ImgHierarchyDto> globalArrayImg1 = null;
	ArrayList <ImgHierarchyDto> globalArrayImgClientList = null;
	ClientImgResponseDto clientImgResponseDto = null;
	ImgHierarchyDto ImgData = null;
	ResultSet rs=null;
	ResultSet rs1=null;
	ImgHierarchyDto imgHierarchyDto = null;
	PreparedStatement pStmt=null;
	PreparedStatement pStmt1=null;
	ArrayList<String> imgIdList = null;
	ArrayList<String> imgDescrList = null;
	ArrayList<ImgHierarchyDto> ParentNodeArray = null;
	ArrayList<ImgHierarchyDto> ParentNodeArray1 = null;
	ArrayList<Integer> map = null;
	ImgHierarchyDto parent = null;
	Gson gson = null;
	JsonArray myCustomArray = null;
	ImgHierarchyDto node = null;
	String output = null;
	int count = 0 ;
	ImgHierarchyDto imgHierarchyParentObj = null;
	HashSet<Integer> parentNodeArr = null;
	int arrLen = 0;
	try{ 
		imgIdList = new ArrayList<>();
		imgDescrList = new ArrayList<>();
		map = new ArrayList<>();
		ParentNodeArray = new ArrayList<>();
		ParentNodeArray1 = new ArrayList<>();
		clientImgResponseDto = new ClientImgResponseDto();
		ResMessageDto resMessageDto = new ResMessageDto();
		clientImgResponseDto.setResMessageDto(resMessageDto);
		globalArrayImg = new ArrayList<>(); 
		globalArrayImg1 = new ArrayList<>(); 
		globalArrayImgClientList = new ArrayList<>(); 
		parentNodeArr = new HashSet<>();
		con = DBConnection.createConnection();
		if(dto.getSelectedArea()!=null && dto.getSelectedArea().equalsIgnoreCase("Industry")) {
			pStmt =  con.prepareStatement("SELECT IMGID,IMGDESCR,SEQUENCING,NODELEVEL,ISMASTERDATA,ENABLED,TRTYPE FROM INDUSTRY_IMGHIERARCHY WHERE ENABLED=? ORDER BY ID");
			pStmt1 = con.prepareStatement("SELECT A.IMGID, B.IMGDESCR FROM CLIENT_IMGHIERARCHY A,INDUSTRY_IMGHIERARCHY B WHERE A.IMGID=B.IMGID AND A.OMID=? AND A.INDUSTRY=? ORDER BY B.ID");	
			pStmt1.setString(1,dto.getSelectedOmid());
			pStmt1.setInt(2, 1);
			
			pStmt.setInt(1, 1);
		}
		else {
			pStmt =  con.prepareStatement("SELECT IMGID,IMGDESCR,SEQUENCING,NODELEVEL,ISMASTERDATA,ENABLED,TRTYPE FROM IMGHIERARCHY WHERE ENABLED=? ORDER BY ID");
			pStmt1 = con.prepareStatement("SELECT A.IMGID, B.IMGDESCR FROM CLIENT_IMGHIERARCHY A,IMGHIERARCHY B WHERE A.IMGID=B.IMGID AND A.OMID=? AND A.INDUSTRY=? ORDER BY B.ID");	
			pStmt1.setString(1,dto.getSelectedOmid());
			pStmt1.setInt(2, 0);
			pStmt.setInt(1, 1);
		}
		//pStmt1.setString(1,dto.getSelectedOmid());
		rs1 = pStmt1.executeQuery();

		
		rs = pStmt.executeQuery();
		while(rs1.next()){
			imgIdList.add(rs1.getString("IMGID"));
			imgDescrList.add(rs1.getString("IMGDESCR")) ;
			}
		while(rs.next()){
			count++;
			imgHierarchyDto = new ImgHierarchyDto();
			imgHierarchyDto.setId(count);
			imgHierarchyDto.setImgId(rs.getString("IMGID"));
			imgHierarchyDto.setImgDescription(rs.getString("SEQUENCING").equals("")?rs.getString("IMGDESCR"):rs.getString("SEQUENCING")+"_"+rs.getString("IMGDESCR")); 
			imgHierarchyDto.setSequence(rs.getString("SEQUENCING"));
			imgHierarchyDto.setNodeLevel(rs.getInt("NODELEVEL"));
			imgHierarchyDto.setIsMasterData(rs.getString("ISMASTERDATA"));
			imgHierarchyDto.setEnabled(rs.getInt("ENABLED"));
			imgHierarchyDto.setTrType(rs.getString("TRTYPE")); 
			imgHierarchyDto.setParentNode(getMyParentID(imgHierarchyDto.getNodeLevel(),ParentNodeArray));
			globalArrayImg.add(imgHierarchyDto);
			parent = new ImgHierarchyDto();
			parent.setNodeLevel(imgHierarchyDto.getNodeLevel());
			parent.setId(count);
			ParentNodeArray.add(parent);
		}
		
			for(ImgHierarchyDto imgHierarchyDtoObj : globalArrayImg){
				if(imgIdList.contains(imgHierarchyDtoObj.getImgId())){
					globalArrayImgClientList.add(imgHierarchyDtoObj);
					imgHierarchyParentObj = imgHierarchyDtoObj;
					while(imgHierarchyParentObj.getParentNode() != 0 && !parentNodeArr.contains(imgHierarchyParentObj.getParentNode())){
						parentNodeArr.add(imgHierarchyParentObj.getParentNode());

						imgHierarchyParentObj = containsParentId(globalArrayImg,imgHierarchyParentObj.getParentNode());
						globalArrayImgClientList.add(imgHierarchyParentObj);

					}
				}
			}

			Collections.sort(globalArrayImgClientList, new Comparator<ImgHierarchyDto>(){
				   public int compare(ImgHierarchyDto o1, ImgHierarchyDto o2){
				      return o1.getId() - o2.getId();
				   }
				});
			
			arrLen = globalArrayImgClientList.size();
			for(int i=0 ;i < arrLen ; i++){			
				ImgData = new ImgHierarchyDto();
				ImgData = globalArrayImgClientList.get(i);

				ImgData.setParentNode(getMyParentID(globalArrayImgClientList.get(i).getNodeLevel(),ParentNodeArray1));
				globalArrayImg1.add(ImgData);
				ImgHierarchyDto parent1 = new ImgHierarchyDto();
				parent1.setNodeLevel(globalArrayImgClientList.get(i).getNodeLevel());
				parent1.setId(i+1);
				ParentNodeArray1.add(parent1);
			}
			
			gson = new GsonBuilder().create();
			myCustomArray = gson.toJsonTree(globalArrayImg1).getAsJsonArray();
			
			map.add(0);
			
			
			node = new ImgHierarchyDto();
			arrLen = globalArrayImg1.size();
			for(int i = 0; i < arrLen ; i++){
				node = globalArrayImg1.get(i);
				map.add(i+1,i);
				if(node.getParentNode() != 0){
					globalArrayImg1.get(map.get(node.getParentNode())).setChildren(node);
				}
			}
			 gson = new GsonBuilder().create();
			 myCustomArray = gson.toJsonTree(globalArrayImg1).getAsJsonArray();
			 if(globalArrayImg1.size()>0)
				 output = myCustomArray.get(0).toString();
			 
			 clientImgResponseDto.getResMessageDto().setMessage(output);
			 clientImgResponseDto.setImgId(imgIdList);
			 clientImgResponseDto.setImgDescr(imgDescrList);
	}
	
		catch (Exception e){
		clientImgResponseDto.getResMessageDto().setMessage(ConstantsValues.DATABASEERROR);
		clientImgResponseDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}
	finally{
		
		if(rs1!=null){
			try {
				rs1.close();
				rs1=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		
		if(pStmt1!=null){
			try {
				pStmt1.close();
				pStmt1=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		
		if(rs!=null){
			try {
				rs.close();
				rs=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		
		if(pStmt!=null){
			try {
				pStmt.close();
				pStmt=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		
		if(con!=null){
			try {
				con.close();
				con=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		
		globalArrayImg = null;
		globalArrayImg1 = null;
		globalArrayImgClientList = null;
		ImgData = null;
		imgHierarchyDto = null;
		imgIdList = null;
		ParentNodeArray = null;
		ParentNodeArray1 = null;
		map = null;
		parent = null;
		gson = null;
		myCustomArray = null;
		node = null;
		imgHierarchyParentObj = null;
		parentNodeArr = null;
		slf4jLogger.info("viewClientImgHierarchy method ended");

	}
	
	return clientImgResponseDto;

	
	
}

public static ImgHierarchyDto containsParentId(ArrayList <ImgHierarchyDto> dtoListForParent, int parentId) {
    for (ImgHierarchyDto localObject : dtoListForParent) {
        if (localObject.getId() == parentId) {
            return localObject;
        }
    }
    return null;
}

public int getMyParentID(int currentLevel,ArrayList<ImgHierarchyDto> ParentNodeArray){		
	int check = 0; 		
	for(int j= ParentNodeArray.size() - 1; j >= 0; j--){			
		check = currentLevel - 1;
		if(ParentNodeArray.get(j).getNodeLevel() == check)
	      {
			return ParentNodeArray.get(j).getId();
	      }
	}		
	return 0;
}

public IndustryResponseDto getIndustryId(){
	slf4jLogger.info("getIndustryId method started");
	IndustryResponseDto industryDto = new IndustryResponseDto();
	ResMessageDto resMessageDto = new ResMessageDto();
	industryDto.setResMessageDto(resMessageDto);
	IndustryDto projectDto = null;
	ArrayList<IndustryDto> projectDetails=new ArrayList<IndustryDto>();
	ResultSet rs=null;
	PreparedStatement pStmt=null;
	boolean status = false;
	Connection con = null;
	try{
		con =  DBConnection.createConnection();
		pStmt =  con.prepareStatement("SELECT DISTINCT INDUSTRY FROM INDUSTRY_VALUES");
			rs = pStmt.executeQuery();
			
		while(rs.next()){
			status = true;
			projectDto = new IndustryDto();
			projectDto.setIndustry(rs.getString("INDUSTRY"));
			projectDetails.add(projectDto);
			
		}
		
		
	if(!status){
		industryDto.getResMessageDto().setMessage("");
		industryDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
	}
	else
		industryDto.setIndDetails(projectDetails);
}


	catch (SQLException e){
		industryDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	}finally{
	    if (rs != null) {
            try {
            	rs.close();
            	rs = null;
            } catch (SQLException e) {
            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
            }
        }
		if (pStmt != null) {
            try {
            	pStmt.close();
            	pStmt = null;
            } catch (SQLException e) {
            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
            }
        }

        if (con != null) {
            try {
            	con.close();
            	con = null;
            } catch (SQLException e) {
            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
            }
        }
		
		  slf4jLogger.info("getIndustryId method ended");

	}	
	industryDto.getResMessageDto().setMessage(ConstantsValues.SUCCESSSTATUS);
	return industryDto; 
}

public IndustryResponseDto getSubIndustryId(IndustryDto projectDto){
	slf4jLogger.info("getSubIndustryId method started");
	IndustryResponseDto industryDto = new IndustryResponseDto();
	ResMessageDto resMessageDto = new ResMessageDto();
	industryDto.setResMessageDto(resMessageDto);
	IndustryDto responseDto  = null;
	ArrayList<IndustryDto> projectDetails=new ArrayList<IndustryDto>();
	ResultSet rs=null;
	PreparedStatement pStmt=null;
	boolean status = false;
	Connection con = null;
	try{
		con =  DBConnection.createConnection();
		pStmt =  con.prepareStatement("SELECT SUBINDUSTRY FROM INDUSTRY_VALUES WHERE INDUSTRY =?");
		pStmt.setString(1 , projectDto.getIndustry());
			rs = pStmt.executeQuery();
			
		while(rs.next()){
			status = true;
			responseDto = new IndustryDto();
			
			responseDto.setSubIndustry(rs.getString("SUBINDUSTRY"));
			projectDetails.add(responseDto);
		}
		
		
		
	if(!status){
		industryDto.getResMessageDto().setMessage("");
		industryDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
	}
	else
		industryDto.setIndDetails(projectDetails);
}


	catch (SQLException e){
		industryDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	}finally{
	    if (rs != null) {
            try {
            	rs.close();
            	rs = null;
            } catch (SQLException e) {
            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
            }
        }
		if (pStmt != null) {
            try {
            	pStmt.close();
            	pStmt = null;
            } catch (SQLException e) {
            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
            }
        }

        if (con != null) {
            try {
            	con.close();
            	con = null;
            } catch (SQLException e) {
            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
            }
        }
		
		  slf4jLogger.info("getSubIndustryId method ended");

	}	
	industryDto.getResMessageDto().setMessage(ConstantsValues.SUCCESSSTATUS);
	return industryDto; 
}
public CustomProjectDto getCustomerId(CustomerInputDto dto){
	slf4jLogger.info("getCustomerId method started");
	CustomProjectDto customProjectDto = new CustomProjectDto();
	ResMessageDto resMessageDto = new ResMessageDto();
	customProjectDto.setResMessageDto(resMessageDto);
	ProjectDto projectDto = new ProjectDto();
	ArrayList<ProjectDto> projectDetails=new ArrayList<ProjectDto>();
	ResultSet rs=null;
	PreparedStatement pStmt=null;
	boolean status = false;
	Connection con = null;
	try{
		con =  DBConnection.createConnection();
		if(dto.getUserRole().equals(ConstantsValues.TOOLADMIN)){
			pStmt =  con.prepareStatement("SELECT OMID,PROJECTNAME,TROVERRIDE FROM CUSTOMER");
		}
		else if(dto.getUserRole().equals(ConstantsValues.PROJECTADMIN)){
			pStmt =  con.prepareStatement("SELECT OMID,PROJECTNAME,TROVERRIDE FROM CUSTOMER WHERE OMID IN (SELECT OMID FROM USERPROJECTS WHERE USERID=?)");
			pStmt.setString(1, dto.getUserID());
		}
		
			rs = pStmt.executeQuery();
			
		while(rs.next()){
			status = true;
			projectDto = new ProjectDto();
			projectDto.setOmId(rs.getString("OMID"));
			projectDto.setProjectName(rs.getString("PROJECTNAME"));
			projectDto.setTrOverride(rs.getString("TROVERRIDE"));
			projectDetails.add(projectDto);
		}
		
		if(!status){
			customProjectDto.getResMessageDto().setMessage("No Customers are Registered!");
			customProjectDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
		}
		else
			customProjectDto.setProjDetails(projectDetails);
	}
	catch (SQLException e){
		customProjectDto.getResMessageDto().setMsgType(ConstantsValues.ERRORSTATUS);
		customProjectDto.getResMessageDto().setMessage("Not able to fetch CustomerIds ,please contact the Administrator!");
		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	}finally{
	    if (rs != null) {
            try {
            	rs.close();
            	rs = null;
            } catch (SQLException e) {
            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
            }
        }
		if (pStmt != null) {
            try {
            	pStmt.close();
            	pStmt = null;
            } catch (SQLException e) {
            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
            }
        }

        if (con != null) {
            try {
            	con.close();
            	con = null;
            } catch (SQLException e) {
            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
            }
        }
		
		  slf4jLogger.info("getCustomerId method ended");

	}	
	customProjectDto.getResMessageDto().setMessage(ConstantsValues.SUCCESSSTATUS);
	return customProjectDto; 
}




public Map<String,ClientIMGHierarchyDto> reteriveTR_IMGID(List<String> imgIDList, String omID,String systemId)  {
	slf4jLogger.info("reteriveTR_IMGID method started");
	Map<String,ClientIMGHierarchyDto> clientIMGMap =  new HashMap<String,ClientIMGHierarchyDto>();
	ClientIMGHierarchyDto clientIMGHierarchyDto = null;
	Connection con = null;
	ResultSet rs=null;
	PreparedStatement pStmt=null;
	int length = 0;
	StringBuilder clientIMG_TRQuery = new StringBuilder("SELECT A.IMGID,B.CTR,B.KTR FROM CLIENT_IMGHIERARCHY A,ClientSystemTrMapping B WHERE B.IMGAUTOID = A.ID AND A.OMID = ? AND B.SYSTEMID=? AND A.IMGID IN (");
	StringBuilder inputImgId = new StringBuilder();
	try{
		length = imgIDList.size(); 
		for(int i=0;i<length;i++){
			if(i==length-1)
				inputImgId.append("?)");
			else
				inputImgId.append("?,");			
		}

		clientIMG_TRQuery.append(inputImgId).append(" UNION ").append("SELECT A.IMGID,'' CTR,'' KTR FROM CLIENT_IMGHIERARCHY A,IMGHIERARCHY B WHERE A.IMGID=B.IMGID AND A.OMID=? AND A.ID NOT IN (SELECT IMGAUTOID FROM ClientSystemTrMapping WHERE SYSTEMID =?) AND A.IMGID IN (").append(inputImgId);
		
		con = DBConnection.createConnection();
		pStmt = con.prepareStatement(clientIMG_TRQuery.toString());
		pStmt.setString(1,omID);
		pStmt.setString(2,systemId);
		int pos = 3;		
		for(int i=0;i<length;i++,pos++){
			pStmt.setString (pos, imgIDList.get(i));				
		}
		pStmt.setString(pos++, omID);
		pStmt.setString(pos++, systemId);
		for(int i=0;i<length;i++,pos++){
			pStmt.setString (pos, imgIDList.get(i));				
		}
		rs = pStmt.executeQuery();
		
			while(rs.next()){
				clientIMGHierarchyDto = new ClientIMGHierarchyDto();
				clientIMGHierarchyDto.setImgID(rs.getString("IMGID"));
				clientIMGHierarchyDto.setCTR(rs.getString("CTR"));
				clientIMGHierarchyDto.setKTR(rs.getString("KTR"));
				clientIMGMap.put(rs.getString("IMGID"), clientIMGHierarchyDto);
			}
	}
	catch (SQLException e){
		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	}finally{
		clientIMGHierarchyDto = null;
		clientIMG_TRQuery = null;
		inputImgId = null;
		if(rs!=null){
			try {
				rs.close();
				rs= null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		if(pStmt!=null){
			try {
				pStmt.close();
				pStmt=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		if(con!=null){
			try {
				con.close();
				con=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		  slf4jLogger.info("reteriveTR_IMGID method ended");

	}	
	
	return clientIMGMap;
}

public Map<String,ClientIMGHierarchyDto> reteriveTR_IMGIDIndustry(List<String> imgIDList, String omID,String systemId)  {
	slf4jLogger.info("reteriveTR_IMGIDIndustry method started");
	Map<String,ClientIMGHierarchyDto> clientIMGMap =  new HashMap<String,ClientIMGHierarchyDto>();
	ClientIMGHierarchyDto clientIMGHierarchyDto = null;
	Connection con = null;
	ResultSet rs=null;
	PreparedStatement pStmt=null;
	int length = 0;
	StringBuilder clientIMG_TRQuery = new StringBuilder("SELECT A.IMGID,B.CTR,B.KTR FROM CLIENT_IMGHIERARCHY A,ClientSystemTrMapping B WHERE B.IMGAUTOID = A.ID AND A.OMID = ? AND B.SYSTEMID=? AND A.INDUSTRY =? AND A.IMGID IN (");
	StringBuilder inputImgId = new StringBuilder();
	try{
		length = imgIDList.size(); 
		for(int i=0;i<length;i++){
			if(i==length-1)
				inputImgId.append("?)");
			else
				inputImgId.append("?,");			
		}

		clientIMG_TRQuery.append(inputImgId).append(" UNION ").append("SELECT A.IMGID,'' CTR,'' KTR FROM CLIENT_IMGHIERARCHY A,INDUSTRY_IMGHIERARCHY B WHERE A.IMGID=B.IMGID AND A.OMID=?  AND A.INDUSTRY =? AND A.ID NOT IN (SELECT IMGAUTOID FROM ClientSystemTrMapping WHERE SYSTEMID =?) AND A.IMGID IN (").append(inputImgId);
		
		con = DBConnection.createConnection();
		pStmt = con.prepareStatement(clientIMG_TRQuery.toString());
		pStmt.setString(1,omID);
		pStmt.setString(2,systemId);
		pStmt.setInt(3,1);
		int pos = 4;		
		for(int i=0;i<length;i++,pos++){
			pStmt.setString (pos, imgIDList.get(i));				
		}
		pStmt.setString(pos++, omID);
		pStmt.setInt(pos++, 1);
		pStmt.setString(pos++, systemId);
		for(int i=0;i<length;i++,pos++){
			pStmt.setString (pos, imgIDList.get(i));				
		}
		rs = pStmt.executeQuery();
		
			while(rs.next()){
				clientIMGHierarchyDto = new ClientIMGHierarchyDto();
				clientIMGHierarchyDto.setImgID(rs.getString("IMGID"));
				clientIMGHierarchyDto.setCTR(rs.getString("CTR"));
				clientIMGHierarchyDto.setKTR(rs.getString("KTR"));
				clientIMGMap.put(rs.getString("IMGID"), clientIMGHierarchyDto);
			}
	}
	catch (SQLException e){
		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	}finally{
		clientIMGHierarchyDto = null;
		clientIMG_TRQuery = null;
		inputImgId = null;
		if(rs!=null){
			try {
				rs.close();
				rs= null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		if(pStmt!=null){
			try {
				pStmt.close();
				pStmt=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		if(con!=null){
			try {
				con.close();
				con=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		  slf4jLogger.info("reteriveTR_IMGIDIndustry method ended");

	}	
	
	return clientIMGMap;
}
public Map<String,ClientIMGHierarchyDto> reteriveTR_IMGIDCopyFunctionality(List<String> imgIDList, String omID,String systemId)  {
	slf4jLogger.info("reteriveTR_IMGIDCopyFunctionality method started");
	Map<String,ClientIMGHierarchyDto> clientIMGMap =  new HashMap<String,ClientIMGHierarchyDto>();
	ClientIMGHierarchyDto clientIMGHierarchyDto = null;
	Connection con = null;
	ResultSet rs=null;
	PreparedStatement pStmt=null;
	int length = 0;
	StringBuilder clientIMG_TRQuery = new StringBuilder("SELECT A.IMGID,B.CTR,B.KTR FROM CLIENT_IMGHIERARCHY A,ClientSystemTrMapping B WHERE B.IMGAUTOID = A.ID AND A.OMID = ? AND B.SYSTEMID=? AND A.IMGID IN (");
	StringBuilder inputImgId = new StringBuilder();
	try{
		length = imgIDList.size(); 
		for(int i=0;i<length;i++){
			if(i==length-1)
				inputImgId.append("?)");
			else
				inputImgId.append("?,");			
		}

		clientIMG_TRQuery.append(inputImgId).append(" UNION ").append("SELECT A.IMGID,'' CTR,'' KTR FROM CLIENT_IMGHIERARCHY A,COPYFUNCTIONALITY_IMGHIERARCHY B WHERE A.IMGID=B.IMGID AND A.OMID=? AND A.ID NOT IN (SELECT IMGAUTOID FROM ClientSystemTrMapping WHERE SYSTEMID =?) AND A.IMGID IN (").append(inputImgId);
		
		con = DBConnection.createConnection();
		pStmt = con.prepareStatement(clientIMG_TRQuery.toString());
		pStmt.setString(1,omID);
		pStmt.setString(2,systemId);
		int pos = 3;		
		for(int i=0;i<length;i++,pos++){
			pStmt.setString (pos, imgIDList.get(i));				
		}
		pStmt.setString(pos++, omID);
		pStmt.setString(pos++, systemId);
		for(int i=0;i<length;i++,pos++){
			pStmt.setString (pos, imgIDList.get(i));				
		}
		rs = pStmt.executeQuery();
		
			while(rs.next()){
				clientIMGHierarchyDto = new ClientIMGHierarchyDto();
				clientIMGHierarchyDto.setImgID(rs.getString("IMGID"));
				clientIMGHierarchyDto.setCTR(rs.getString("CTR"));
				clientIMGHierarchyDto.setKTR(rs.getString("KTR"));
				clientIMGMap.put(rs.getString("IMGID"), clientIMGHierarchyDto);
			}
	}
	catch (SQLException e){
		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	}finally{
		clientIMGHierarchyDto = null;
		clientIMG_TRQuery = null;
		inputImgId = null;
		if(rs!=null){
			try {
				rs.close();
				rs= null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		if(pStmt!=null){
			try {
				pStmt.close();
				pStmt=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		if(con!=null){
			try {
				con.close();
				con=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		  slf4jLogger.info("reteriveTR_IMGIDCopyFunctionality method ended");

	}	
	
	return clientIMGMap;
}




public boolean isTRFeatureEnabled(String omID)  {
	slf4jLogger.info("isTRFeatureEnabled method started");
	Connection con = null;
	ResultSet rs=null;
	PreparedStatement pStmt=null;
	boolean featureEnabled = false;
	String trQuery = "select count(A.omid) as recordSize from client_imghierarchy A,ClientSystemTrMapping B where B.IMGAUTOID = A.ID AND A.omid = ? and (length(B.CTR)>1 OR LENGTH(B.KTR)>1)"; 
	
	try{
		con = DBConnection.createConnection();
		pStmt =  con.prepareStatement(trQuery);
		pStmt.setString(1,omID);
		rs = pStmt.executeQuery();
		
			if(rs.next()){
				if(rs.getInt("recordSize") > 0)
					featureEnabled = true;
			}
	}
	catch (SQLException e){
		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	}finally{
		if(rs!=null){
			try {
				rs.close();
				rs= null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		if(pStmt!=null){
			try {
				pStmt.close();
				pStmt=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		if(con!=null){
			try {
				con.close();
				con=null;
				} catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
		}
		  slf4jLogger.info("isTRFeatureEnabled method ended");

	}	
	
	return featureEnabled;
}




}
