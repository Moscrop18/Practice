package com.acn.rpa.imghierarchy;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Size;

import com.acn.user.session.SessionInputDTO;

public class InputClientImgHierarchyDto {
	@Valid
	private List<String> clientImgHierarchyList;
	
	@Size(min = 1, max = 20)
	private String omId;
	@Valid
	private SessionInputDTO sessionInputDTO;
	
	private String selectedArea;
	
	public String getSelectedArea() {
		return selectedArea;
	}
	public void setSelectedArea(String selectedArea) {
		this.selectedArea = selectedArea;
	}
	public SessionInputDTO getSessionInputDTO() {
		return sessionInputDTO;
	}
	public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
		this.sessionInputDTO = sessionInputDTO;
	}

	public String getOmId() {
		return omId;
	}

	

	public void setOmId(String omId) {
		this.omId = omId;
	}

	public List<String> getClientImgHierarchyList() {
		return clientImgHierarchyList;
	}

	public void setClientImgHierarchyList(List<String> clientImgHierarchyList) {
		this.clientImgHierarchyList = clientImgHierarchyList;
	}



}
