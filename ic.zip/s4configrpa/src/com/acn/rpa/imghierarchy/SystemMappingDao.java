
package com.acn.rpa.imghierarchy;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.DBConnection;


public class SystemMappingDao {

    private final Logger slf4jLogger = LoggerFactory.getLogger(SystemMappingDao.class);

	public FieldMappingDto getSourceSystemDetails(FieldMappingDto fieldMappingDto){
		slf4jLogger.info("getSourceSystemDetails method started");
		Connection con = null;
		PreparedStatement preparedStmt =  null;
		ResultSet rs = null;
		String query="SELECT * FROM FIELDMAPPING WHERE T_IMGID=? AND T_VIEW=? AND T_FIELD=?";
		try{
			con  = DBConnection.createConnection();
			preparedStmt = con.prepareStatement(query);
			preparedStmt.setString(1, fieldMappingDto.getT_IMGID());
			preparedStmt.setString(2, fieldMappingDto.getT_VIEW());
			preparedStmt.setString(3, fieldMappingDto.getT_FIELD());
		    rs = preparedStmt.executeQuery();
		    if(rs.next()){
		    	if(rs.getString("S_IMGID").equals("")){
		    		fieldMappingDto.setS_IMGID(fieldMappingDto.getT_IMGID());
		    		fieldMappingDto.setS_VIEW(fieldMappingDto.getT_VIEW());
		    		fieldMappingDto.setS_FIELD(fieldMappingDto.getT_FIELD());
		    	}
		    	else{
			    	fieldMappingDto.setS_IMGID(rs.getString("S_IMGID"));
			    	fieldMappingDto.setS_VIEW(rs.getString("S_VIEW"));
			    	fieldMappingDto.setS_FIELD(rs.getString("S_FIELD"));
		    	}	
		    }
			}catch(SQLException e){
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}finally {
				
				if (rs != null) {
		            try {
		            	rs.close();
		            	rs = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
				
				
				if (preparedStmt != null) {
		            try {
		            	preparedStmt.close();
		            	preparedStmt = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }

		        if (con != null) {
		            try {
		            	con.close();
		            	con = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
				  slf4jLogger.info("getSourceSystemDetails method ended");

			}

	    return fieldMappingDto;
	}
	
	
	
	public ArrayList<String> getTargetImgId(String targetImgID){
		slf4jLogger.info("getTargetImgId method started");
		ArrayList<String> fieldMappingList = new ArrayList<>();
		Connection con = null;
		PreparedStatement preparedStmt =  null;
		ResultSet rs = null;
		String query="SELECT distinct S_IMGID FROM FIELDMAPPING WHERE T_IMGID=?"; 
		try{
			con  = DBConnection.createConnection();
			preparedStmt = con.prepareStatement(query);
			preparedStmt.setString(1, targetImgID);
		    rs = preparedStmt.executeQuery();
		    
		    while(rs.next()){
		    	fieldMappingList.add(rs.getString("S_IMGID"));
		    }
			}catch(SQLException e){
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}finally {
				
				if (rs != null) {
		            try {
		            	rs.close();
		            	rs = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
				
				if (preparedStmt != null) {
		            try {
		            	preparedStmt.close();
		            	preparedStmt = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }

		        if (con != null) {
		            try {
		            	con.close();
		            	con = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
				  slf4jLogger.info("getTargetImgId method ended");

			}

	    return fieldMappingList;
	}
	
public HashMap<String, FieldMappingDto> getFieldMapByView(String targetImgID,String targetView){
	 	slf4jLogger.info("getFieldMapByView method started");
		HashMap<String, FieldMappingDto> fieldMap =  new HashMap<String, FieldMappingDto>();
		Connection con = null;
		PreparedStatement preparedStmt =  null;
		ResultSet rs = null;
		String query="SELECT * FROM FIELDMAPPING WHERE T_IMGID=? AND T_VIEW=?";  
		try{
			con  = DBConnection.createConnection();
			preparedStmt = con.prepareStatement(query);
			preparedStmt.setString(1, targetImgID);
			preparedStmt.setString(2, targetView);
		    rs = preparedStmt.executeQuery();
		    
		    while(rs.next()){
		    	
		    	FieldMappingDto fieldMappingDto = new FieldMappingDto();
		    	fieldMappingDto.setS_IMGID(rs.getString("S_IMGID"));
		    	fieldMappingDto.setS_VIEW(rs.getString("S_VIEW"));
		    	fieldMappingDto.setS_FIELD(rs.getString("S_FIELD"));
		    	fieldMappingDto.setT_IMGID(rs.getString("T_IMGID"));
		    	fieldMappingDto.setT_VIEW(rs.getString("T_VIEW"));
		    	fieldMappingDto.setT_FIELD(rs.getString("T_FIELD"));
		    	fieldMap.put(rs.getString("T_FIELD"), fieldMappingDto);
		    	
		    }
		}catch(SQLException e){
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}finally {
				
				if (rs != null) {
		            try {
		            	rs.close();
		            	rs = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
				
				
				if (preparedStmt != null) {
		            try {
		            	preparedStmt.close();
		            	preparedStmt = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }

		        if (con != null) {
		            try {
		            	con.close();
		            	con = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
				  slf4jLogger.info("getFieldMapByView method ended");

			}

		return fieldMap;
	}
	
}
