package com.acn.rpa.docservice;

import java.util.List;

import com.acn.user.session.ResMessageDto;

public class TempUpdateResDto {

	private List<TempUpdateInfoDto> templateList;
	private String message;
	private String status;
	private ResMessageDto resMessageDto;

	public ResMessageDto getResMessageDto() {
			return resMessageDto;
		}
	public void setResMessageDto(ResMessageDto resMessageDto) {
			this.resMessageDto = resMessageDto;
		}
	public List<TempUpdateInfoDto> getTemplateList() {
		return templateList;
	}
	public void setTemplateList(List<TempUpdateInfoDto> templateList) {
		this.templateList = templateList;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	
}
