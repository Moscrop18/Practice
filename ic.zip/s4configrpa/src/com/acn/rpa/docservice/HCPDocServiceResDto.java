package com.acn.rpa.docservice;


import java.util.ArrayList;

import com.acn.user.session.ResMessageDto;

public class HCPDocServiceResDto {
	
	private String description;
	private Boolean status;

	
	private String imgDesc;
	private Boolean docId;
	
	ArrayList<String>  docIds= new ArrayList<String>();
	ArrayList<String>  imgIds= new ArrayList<String>();
	ArrayList<String> notImportedTemplates = new ArrayList<String>();
	private ResMessageDto resMessageDto;

	public ResMessageDto getResMessageDto() {
			return resMessageDto;
		}
	public void setResMessageDto(ResMessageDto resMessageDto) {
			this.resMessageDto = resMessageDto;
		}
	public ArrayList<String> getNotImportedTemplates() {
		return notImportedTemplates;
	}
	public void setNotImportedTemplates(ArrayList<String> notImportedTemplates) {
		this.notImportedTemplates = notImportedTemplates;
	}
	public ArrayList<String> getDocIds() {
		return docIds;
	}
	public void setDocIds(ArrayList<String> docIds) {
		this.docIds = docIds;
	}
	public ArrayList<String> getImgIds() {
		return imgIds;
	}
	public void setImgIds(ArrayList<String> imgIds) {
		this.imgIds = imgIds;
	}
	public String getImgDesc() {
		return imgDesc;
	}
	public void setImgDesc(String imgDesc) {
		this.imgDesc = imgDesc;
	}
	public Boolean getDocId() {
		return docId;
	}
	public void setDocId(Boolean docId) {
		this.docId = docId;
	}
	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}



