package com.acn.rpa.docservice;

public class TempUpdateInfoDto {
	private String imgDescr;
	private String updatedDate;
	private String seqID;
	private byte[] bytes;
	public byte[] getBytes() {
		return bytes;
	}
	public void setBytes(byte[] bytes) {
		this.bytes = bytes;
	}
	public String getImgDescr() {
		return imgDescr;
	}
	public void setImgDescr(String imgDescr) {
		this.imgDescr = imgDescr;
	}
	public String getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}
	public String getSeqID() {
		return seqID;
	}
	public void setSeqID(String seqID) {
		this.seqID = seqID;
	}
	
	
}