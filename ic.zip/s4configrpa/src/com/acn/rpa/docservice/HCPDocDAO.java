package com.acn.rpa.docservice;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

import javax.naming.InitialContext;

import org.apache.chemistry.opencmis.client.api.CmisObject;
import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.chemistry.opencmis.client.api.Folder;
import org.apache.chemistry.opencmis.client.api.ItemIterable;
import org.apache.chemistry.opencmis.client.api.Session;
import org.apache.chemistry.opencmis.commons.PropertyIds;
import org.apache.chemistry.opencmis.commons.data.ContentStream;
import org.apache.chemistry.opencmis.commons.enums.VersioningState;
import org.apache.chemistry.opencmis.commons.exceptions.CmisNameConstraintViolationException;
import org.apache.chemistry.opencmis.commons.exceptions.CmisObjectNotFoundException;
import org.apache.commons.io.FilenameUtils;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.imghierarchy.ImgHierarchyCustomDto;
import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.DBConnection;
import com.acn.rpa.utilities.PropMappings;
/*import com.sap.ecm.api.EcmService;
import com.sap.ecm.api.RepositoryOptions;
import com.sap.ecm.api.RepositoryOptions.Visibility;
*/

public class HCPDocDAO {
	private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");
    private final Logger slf4jLogger = LoggerFactory.getLogger(HCPDocDAO.class);

	public HCPDocServiceResDto createFolder(HCPDocServiceInputDto objHCPDocServiceInputDto){
		slf4jLogger.info("createFolder method started");
		HCPDocServiceResDto objHCPDocServiceResDto = new HCPDocServiceResDto();
	      String secretKey = objHCPDocServiceInputDto.getSecretKey();
	      String repoName = objHCPDocServiceInputDto.getRepositoryName();
    	  objHCPDocServiceResDto.setStatus(true);

	      try{/*
	    	  
	    	  Session openCmisSession = null;
		      InitialContext ctx = new InitialContext();
		      String lookupName = "java:comp/env/" + "EcmService";
		      EcmService ecmSvc = (EcmService) ctx.lookup(lookupName);
		      try {
			        openCmisSession = ecmSvc.connect(repoName, secretKey);
			      }
			      catch (CmisObjectNotFoundException e) {
			        RepositoryOptions options = new RepositoryOptions();
			        options.setUniqueName(repoName);
			        options.setRepositoryKey(secretKey);
			        options.setVisibility(Visibility.PROTECTED);
			        ecmSvc.createRepository(options);
			        openCmisSession = ecmSvc.connect(repoName, secretKey);
			      }
		      		
		      Folder root = openCmisSession.getRootFolder();

		      Map<String, String> newFolderProps = new HashMap<String, String>();
		      newFolderProps.put(PropertyIds.OBJECT_TYPE_ID, "cmis:folder");
		      newFolderProps.put(PropertyIds.NAME, objHCPDocServiceInputDto.getFolderName());
		      try {
		        root.createFolder(newFolderProps);
		        objHCPDocServiceResDto.setDescription("Folder created");
		      } catch (CmisNameConstraintViolationException e) {
		    	  objHCPDocServiceResDto.setDescription("Folder already exists");
		      }
	      */}
	      catch(Exception e){
	    	  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
	    	  objHCPDocServiceResDto.setStatus(false);
	      }finally{
			  slf4jLogger.info("createFolder method ended");

	      }
	     

		return objHCPDocServiceResDto;
	}
	
	public HCPDocServiceResDto createFile(String templateType,String fileName,InputStream inputStream,byte[] fileBytes,boolean overideFiles, boolean industryFlag){
		//slf4jLogger.info("HCP _ Filename"+fileName);
		//slf4jLogger.info("createFile method started");
	      Session openCmisSession = null;
	  	  int  docId = 0;
	  	  HCPDocDAO hcpDocDAOobj = null;
	  	  Document document = null;
	      XSSFWorkbook workbook = null;
 		  ByteArrayOutputStream bos = null;
 		  Folder subFolder = null;
 		  ContentStream contentStream = null;
 		  Map<String, Object> properties = null;
 		  byte[] bytes = null;
 		  InputStream stream = null;
 		  Folder root = null;
 		  //int count=0;
 		  Map<String, String> newFolderProps = null;
 		  ItemIterable<CmisObject> children = null;
 		  HCPDocServiceResDto objHCPDocServiceResDto = null;
 	/*	  try {
			openCmisSession = ConnectDocumentStore();
 		  } catch (Exception e1) {
 			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e1);
 		  }*/
 		  
 		  
 		  objHCPDocServiceResDto = new HCPDocServiceResDto();
	      
 		  try{
	    	  bos = new ByteArrayOutputStream();
			     	/*root = openCmisSession.getRootFolder();
			      newFolderProps = new HashMap<String, String>();
			      	  newFolderProps.put(PropertyIds.OBJECT_TYPE_ID, "cmis:folder");
			    	  newFolderProps.put(PropertyIds.NAME, "BaseTemplates");
			      
			      try {
			    	  subFolder  = root.createFolder(newFolderProps);
			    	  objHCPDocServiceResDto.setDescription("Folder created");
			      } catch (CmisNameConstraintViolationException e) {
			    	  
			    	  children = root.getChildren();
			    	  
			    	  for (CmisObject folObj : children) {
			  	        if (folObj instanceof Folder) {
			  	        	if(folObj.getName().equals("BaseTemplates"))
			  	        		subFolder = (Folder) folObj;
			  	        		
			  	        
			  	        } 
			  	      }

			    	  objHCPDocServiceResDto.setDescription("Folder exist");
			      }

	      	    contentStream = openCmisSession.getObjectFactory().createContentStream(fileName,fileBytes.length, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", inputStream);

	      	    properties = new HashMap<String, Object>();
	      	    properties.put(PropertyIds.OBJECT_TYPE_ID, "cmis:document");
	      	    properties.put(PropertyIds.NAME, fileName);
	      	    objHCPDocServiceResDto.setImgDesc(fileName);
    	 		
				
				
				hcpDocDAOobj = new HCPDocDAO();

            		docId = hcpDocDAOobj.getDocumentId(fileName.replaceAll("[^a-zA-Z0-9]", "").toLowerCase(),"BASE");
            		
            		//slf4jLogger.info("HCP _ DocId" + docId);
            		if(docId != null ){
            			try{
            			
            			Document docObj = (Document) openCmisSession.getObject(docId);
            			docObj.setContentStream(contentStream, true);
            			updateDocId(docId);
            			}catch(CmisObjectNotFoundException ce){
            				document = subFolder.createDocument(properties, contentStream, VersioningState.NONE);
            				updateDocumentId(document.getContentStreamFileName(),document.getId());
            				slf4jLogger.info("documentid" + document.getId());
            			}
            			
            			
            			
            			slf4jLogger.info("HCP _ DocId_update" + docId);
            			objHCPDocServiceResDto.setDescription("Template Successfully Updated");
            		}           		
            		else{
            			document = subFolder.createDocument(properties, contentStream, VersioningState.NONE);
            			
            			
*/  
	    	
	    	  hcpDocDAOobj = new HCPDocDAO();
	    	  objHCPDocServiceResDto.setImgDesc(fileName);
	    	  if(industryFlag) {
	    		  docId = hcpDocDAOobj.getDocumentIdForIndustry(fileName.replaceAll("[^a-zA-Z0-9]", "").toLowerCase(),"BASE");  
	    	  }else {
	    		  docId = hcpDocDAOobj.getDocumentId(fileName.replaceAll("[^a-zA-Z0-9]", "").toLowerCase(),"BASE");  
	    	  }
	    	 
			if (docId>0) {
				//method change for import template issue
				updateDocId(docId,inputStream, industryFlag);
				objHCPDocServiceResDto.setDescription("Template Successfully Updated");

			}else{
			int docid = ThreadLocalRandom.current().nextInt(90000);
			boolean statusFlg = captureDocidName(docid, fileName, "BASE", "", inputStream,industryFlag);
			// slf4jLogger.info("HCP _ DocId_update " + docId + statusFlg );
			if (statusFlg)
				objHCPDocServiceResDto.setDescription("File created");
			
			else
				objHCPDocServiceResDto.setDescription("DB exception occured");

 		  		}	
 		  }
/*	      		catch(CmisNameConstraintViolationException e){
	    	 	if(overideFiles){
	    	 		hcpDocDAOobj = new HCPDocDAO();
	    	 		objHCPDocServiceResDto.setDescription("File already exists");
	        		docId = hcpDocDAOobj.getDocumentId(fileName.replaceAll("[^a-zA-Z0-9]", "").toLowerCase(),"BASE");
	        	
	        		Document docObj = (Document) openCmisSession.getObject(docId);
	        		try{      			
	        			contentStream = openCmisSession.getObjectFactory().createContentStream(fileName,fileBytes.length, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", inputStream);
	    				docObj.setContentStream(contentStream, true);
	        		}catch(Exception E){
	        			
	        		}	    	 	
			    	  objHCPDocServiceResDto.setDescription("Template Successfully Updated");
	    	 	}
	    	 	else{
	    	 		//Updating CMIS record
	    	 		String path = "/BaseTemplates/" + fileName;
	    	 		Document docObj = (Document) openCmisSession.getObjectByPath(path);
	    	 		slf4jLogger.info("HCP _ DocId_catch_elsecontentstream  " + docObj);
	    	 		//docObj.delete();	    	 		
        			contentStream = openCmisSession.getObjectFactory().createContentStream(fileName,fileBytes.length, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", inputStream);
    				docObj.setContentStream(contentStream, true);
	    	 		slf4jLogger.info("HCP _ DocId_catch_else  " + fileBytes.length + "  " +  fileBytes);
	    	 		
	    	 		//Updating/Creating DB record
	    	 		docId = hcpDocDAOobj.getDocumentId(fileName.replaceAll("[^a-zA-Z0-9]", "").toLowerCase(),"BASE");
            		//slf4jLogger.info("HCP _ DocId" + docId);
            		if(docId != null){            			
            			updateDocId(docId);
            			slf4jLogger.info("HCP _ DocId_update" + docId);
            			objHCPDocServiceResDto.setDescription("Template Successfully Updated");
            		}else{
            		
    	    	 		boolean statusFlg = captureDocidName(docObj.getId(),fileName,"BASE","",inputStream);
    	    	 		if(statusFlg)
    	    	 			objHCPDocServiceResDto.setDescription("Updated successfully");
    	    	 		objHCPDocServiceResDto.setDescription("File already exists");
	      			}	    	 		
	    	 	}
		      
	     }  */catch (Exception e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		} 
	      finally{
	    	  openCmisSession = null;
	    	  try {
	    		  if(workbook != null)
	    			  workbook.close();
	    		  if(stream != null)
					stream.close();
	    		  if(bos != null)
					bos.close();
	    		  bos = null;
			} catch (IOException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
	    	  workbook = null;
	    	  stream = null;
	    	  bos = null;
	    	  contentStream = null;
	    	  properties = null;
	    	  newFolderProps = null;
	    	  document = null;
	    	  docId = 0;
	    	  children = null;
	    	  hcpDocDAOobj = null;
	    	  children = null;
			  slf4jLogger.info("createFile method ended");

	      }

	      return objHCPDocServiceResDto;
	}
	
	public HCPDocServiceResDto createFile(XSSFWorkbook workbook,String fileName,String folderName){
		  slf4jLogger.info("createFile method started");
		  int docId;
	  	  HCPDocDAO hcpDocDAOobj = null;
	  	  String fileNameWithOutExt = null;
	      Session openCmisSession = null;
	      HCPDocServiceResDto objHCPDocServiceResDto = null;
	      Map<String, Object> properties = null;
	      Document document = null;
	      ByteArrayOutputStream bos = null;
	      Folder subFolder = null;
	  	  Folder currentFolder = null;
	  	  ContentStream contentStream = null;
	  	  Folder root = null; 
	  	  Map<String, String> newFolderProps = null;
	  	  DateFormat dateFormat = null;
	  	  String todaysDate = null; 
	  	  Map<String, String> newTimeStampFolderProps = null;
	  	  byte[] bytes = null; 
	  	  InputStream stream = null; 
	  	  boolean statusFlg = false;
	  	  String localFileName = fileName.replaceAll("[\\/:*?\"<>|\\\\]", " ").trim().replaceAll("\\s+", " ");
	      try {
			openCmisSession = ConnectDocumentStore();
			objHCPDocServiceResDto = new HCPDocServiceResDto();
			properties = new HashMap<String, Object>();
			properties.put(PropertyIds.OBJECT_TYPE_ID, "cmis:document");
			properties.put(PropertyIds.NAME, localFileName);
			bos = new ByteArrayOutputStream();
			root = openCmisSession.getRootFolder();
			newFolderProps = new HashMap<>();
			newFolderProps.put(PropertyIds.OBJECT_TYPE_ID, "cmis:folder");
			newFolderProps.put(PropertyIds.NAME, folderName);
			  try {
			   	  subFolder  = root.createFolder(newFolderProps);
		    	  objHCPDocServiceResDto.setDescription("Folder created");
		      } catch (CmisNameConstraintViolationException e) {
			    	  ItemIterable<CmisObject> children = root.getChildren();
			    	  
			    	  for (CmisObject folObj : children) {
			  	        if (folObj instanceof Folder) {
			  	        	if(folObj.getName().equals(folderName))
			  	        		subFolder = (Folder) folObj;
			  	        } 
			  	      }
			    	  objHCPDocServiceResDto.setDescription("Folder exist");
			      }
			  
			  if(folderName.equals("ConfigTemplates")){
			    	  dateFormat = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		              todaysDate = dateFormat.format(System.currentTimeMillis());
			    	  newTimeStampFolderProps = new HashMap<String, String>();
			    	  newTimeStampFolderProps.put(PropertyIds.OBJECT_TYPE_ID, "cmis:folder");
			    	  newTimeStampFolderProps.put(PropertyIds.NAME,todaysDate);
			    	  try {
			    		  currentFolder  = subFolder.createFolder(newTimeStampFolderProps);
				    	  objHCPDocServiceResDto.setDescription("Folder created");
				      } catch (CmisNameConstraintViolationException e) {
				    	  objHCPDocServiceResDto.setDescription("Folder exist");
				      }
			  }else{
				  currentFolder = subFolder;
			  }
			     

	        	    workbook.write(bos);
	        	    bytes = bos.toByteArray();
	      	      	stream = new ByteArrayInputStream(bytes);
	        	    
	      	    contentStream = openCmisSession.getObjectFactory().createContentStream(localFileName,bytes.length, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", stream);
	      	    if(contentStream != null){
	      	    	objHCPDocServiceResDto.setDocId(true);
	      	    	try{
	      	    		document = currentFolder.createDocument(properties, contentStream, VersioningState.NONE);
    	    	 		fileNameWithOutExt = FilenameUtils.removeExtension(localFileName);

	      	    		objHCPDocServiceResDto.setDescription("Template Created Successfully");
	      	    	}catch(CmisNameConstraintViolationException e){
	    	    	 	
	    	    	 		hcpDocDAOobj = new HCPDocDAO();
	    	    	 		objHCPDocServiceResDto.setDescription("File already exists");
	    	    	 		fileNameWithOutExt = FilenameUtils.removeExtension(localFileName);
	    	        		docId = hcpDocDAOobj.getDocumentId(fileNameWithOutExt.replaceAll("[^a-zA-Z0-9]", "").toLowerCase(),"BASE");
	    	        		//Document docObj = (Document) openCmisSession.getObject(docId);
	    	        		try{
	    		        	    workbook.write(bos);
	    		        	    bytes = bos.toByteArray();
	    		      	      	stream = new ByteArrayInputStream(bytes);
	    	        			contentStream = openCmisSession.getObjectFactory().createContentStream(localFileName,bytes.length, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", stream);
	    	    				//docObj.setContentStream(contentStream, true);
	    	    				objHCPDocServiceResDto.setDescription("Template Successfully Updated");
	    	        		}catch(Exception E){
	    	        			objHCPDocServiceResDto.setDescription("Template is not Updated");
	    	        		}
	    			    	  

	      	    	}
	      	    	int  docid = ThreadLocalRandom.current().nextInt();
	      	    if(folderName.equals("ConfigTemplates")) {
	      	    	//commented to avoid method changes as it is not used currently
	      	    	//statusFlg = captureDocidName(docid,fileNameWithOutExt,"Config","",stream);
	      	    }
	      	    	 
	      	    	
	      	    else {
	      	    	//statusFlg = captureDocidName(docid,fileNameWithOutExt,"BASE","",stream);
	      	    }
	      	    	

	      	    if(statusFlg)
		    	  objHCPDocServiceResDto.setDescription("File created");
	      	    else
		    	  objHCPDocServiceResDto.setDescription("DB exception occured");
	      	    }else {
	      	    	objHCPDocServiceResDto.setDescription("Unable to get the content from file");
	      	    	objHCPDocServiceResDto.setDocId(false);
	      	    }

	      		}
	      catch(CmisNameConstraintViolationException e){
		      objHCPDocServiceResDto.setDescription("File already exists");
	     } catch (FileNotFoundException e) {
		      objHCPDocServiceResDto.setDescription("File not found");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		} catch (IOException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		} catch (Exception e1) {
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e1);
		} 
	      finally{
	    	  openCmisSession = null;
	    	  properties = null;
	    	  document = null;
	    	  try {
				bos.close();
				stream.close();
			} catch (IOException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
	    	  bos = null;
	    	  stream = null;
	    	  contentStream = null;
	    	  root = null; 
	    	  newFolderProps = null;
	    	  dateFormat = null;
	    	  todaysDate = null;
	    	  newTimeStampFolderProps = null;
			  slf4jLogger.info("createFile method ended");

	      }

	      return objHCPDocServiceResDto;
	}
	
	public Boolean captureDocidName(int  id,String fileName,String templateType,String userRole,InputStream inputStream, boolean industryFlag)  {
		slf4jLogger.info("captureDocidName method started");
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		Connection con = null;
		PreparedStatement pStmt=null;
		String storeDocIdQuery ="";
		if(industryFlag) {
			 storeDocIdQuery = "INSERT INTO INDUSTRY_DOCUMENTSTORE(ID,FILENAME,TEMPLATETYPE,IMGDESC,RECORDED_DATE,USERROLE,FILE_BLOB) VALUES(?,?,?,?,?,?,?)";
		}else {
			storeDocIdQuery = "INSERT INTO DOCUMENTSTORE(ID,FILENAME,TEMPLATETYPE,IMGDESC,RECORDED_DATE,USERROLE,FILE_BLOB) VALUES(?,?,?,?,?,?,?)";
		}
	  	 
	  	int count = 0;
	  	boolean flag=false;
	  	
		try{
			con = DBConnection.createConnection();
			pStmt = (PreparedStatement) con.prepareStatement(storeDocIdQuery);
			pStmt.setInt(1, id);
			pStmt.setString(2, fileName);
			pStmt.setString(3, templateType);
			pStmt.setString(4, fileName.replaceAll("[^a-zA-Z0-9]", "").toLowerCase());
			pStmt.setTimestamp(5, timestamp);
			pStmt.setString(6, userRole);
			
			pStmt.setBinaryStream(7, inputStream);
			count = pStmt.executeUpdate();
			if(count>0)
				flag = true;
			
		}
		catch (SQLException e){
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}finally{
			
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("captureDocidName method ended");
	
		}	
		
		return flag;
	}
	
	public Boolean updateDocId(int  id,InputStream inputStream, boolean industryFlag)  {
		slf4jLogger.info("updateDocId method started");
		Connection con = null;
		PreparedStatement pStmt=null;
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		String storeDocIdQuery ="";
		
		if(industryFlag) {
			storeDocIdQuery = "UPDATE INDUSTRY_DOCUMENTSTORE SET FILE_BLOB =?, RECORDED_DATE = ? WHERE ID=? AND TEMPLATETYPE=?";
		}else {
			  storeDocIdQuery = "UPDATE DOCUMENTSTORE SET FILE_BLOB =?, RECORDED_DATE = ? WHERE ID=? AND TEMPLATETYPE=?";
		}
	

	  	int count = 0;
	  	boolean flag=false;
		try{
			con = DBConnection.createConnection();
			pStmt = con.prepareStatement(storeDocIdQuery);
			pStmt.setBinaryStream(1, inputStream);
			pStmt.setTimestamp(2, timestamp);
			pStmt.setInt(3, id);
			pStmt.setString(4, "BASE");
			count = pStmt.executeUpdate();
			if(count>0)
				flag = true;
		}
		catch (SQLException e){
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}finally{
			
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("updateDocId method ended");

		}	
		
		return flag;
	}
	/////
	public Boolean updateDocumentId(String filename,String id)  {
		slf4jLogger.info("updateDocumentId method started");
		Connection con = null;
		PreparedStatement pStmt=null;
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
	  	String storeDocIdQuery = "UPDATE DOCUMENTSTORE SET RECORDED_DATE = ?,ID= ? WHERE filename=?";

	  	int count = 0;
	  	boolean flag=false;
		try{
			con = DBConnection.createConnection();
			pStmt = con.prepareStatement(storeDocIdQuery);
			pStmt.setTimestamp(1, timestamp);
			pStmt.setString(2, id);
			pStmt.setString(3,filename);
			count = pStmt.executeUpdate();
			if(count>0)
				flag = true;
		}
		catch (SQLException e){
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}finally{
			
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("updateDocumentId method ended");

		}	
		
		return flag;
	}
	public int  getDocumentId(String fileName,String templateType)  {
		slf4jLogger.info("getDocumentId method started");
		Connection con = null;
		ResultSet rs=null;
		PreparedStatement pStmt=null;
		int docId= 0;
		String getDocId = null;
		try{

			getDocId = "SELECT ID FROM DOCUMENTSTORE WHERE IMGDESC=? AND TEMPLATETYPE=?";
			con = DBConnection.createConnection();
			pStmt = con.prepareStatement(getDocId);
			pStmt.setString(1, fileName);
			pStmt.setString(2, templateType);
			rs = pStmt.executeQuery();
			while(rs.next()){
					docId = rs.getInt("ID");
			}
		}
		catch (SQLException e){
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}finally{
			if(rs!=null){
				try {
					rs.close();
					rs= null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("getDocumentId method ended");

		}	
		
		return docId;
	}
	
	
	public int  getDocumentIdForIndustry(String fileName,String templateType)  {
		slf4jLogger.info("getDocumentIdForIndustry method started");
		Connection con = null;
		ResultSet rs=null;
		PreparedStatement pStmt=null;
		int docId= 0;
		String getDocId = null;
		try{

			getDocId = "SELECT ID FROM INDUSTRY_DOCUMENTSTORE WHERE IMGDESC=? AND TEMPLATETYPE=?";
			con = DBConnection.createConnection();
			pStmt = con.prepareStatement(getDocId);
			pStmt.setString(1, fileName);
			pStmt.setString(2, templateType);
			rs = pStmt.executeQuery();
			while(rs.next()){
					docId = rs.getInt("ID");
			}
		}
		catch (SQLException e){
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}finally{
			if(rs!=null){
				try {
					rs.close();
					rs= null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("getDocumentIdForIndustry method ended");

		}	
		
		return docId;
	}
	
	public HCPDocServiceResDto getDocumentIds()  {
		slf4jLogger.info("getDocumentIds method started");
		Connection con = null;
		ResultSet rs=null;
		PreparedStatement pStmt=null;
		HCPDocServiceResDto objHCPDocServiceResDto = new HCPDocServiceResDto();
		String getDocId = null;
		int count = 0;
		try{

			getDocId = "SELECT COUNT(1) COUNT FROM DOCUMENTSTORE WHERE TEMPLATETYPE=?";
			con = DBConnection.createConnection();
			pStmt = con.prepareStatement(getDocId);
			pStmt.setString(1, "BASE");
				rs = pStmt.executeQuery();
				if(rs.next()){
					count = rs.getInt("COUNT");

				}
				if(count > 0){
					objHCPDocServiceResDto.setStatus(true);
				}
				else{
					objHCPDocServiceResDto.setStatus(false);
				}
		}
		catch (SQLException e){
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}finally{
			if(rs!=null){
				try {
					rs.close();
					rs= null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("getDocumentIds method ended");

		}	
		
		return objHCPDocServiceResDto;
	}
	
	public HCPDocServiceResDto getDocumentIds(ArrayList<String> selectScopeList, boolean industry)  {
		slf4jLogger.info("getDocumentIds method started");
		Connection con = null;
		ResultSet rs=null;
		PreparedStatement pStmt=null;
		ArrayList<String>  docIds= new ArrayList<String>();
		ArrayList<String>  imgIds= new ArrayList<String>();
		ArrayList<String> filesNotExists = new ArrayList<String>();
		int length = selectScopeList.size();
		HCPDocServiceResDto objHCPDocServiceResDto = new HCPDocServiceResDto();
		boolean flag = true;
		StringBuilder getDocIdQuery = new StringBuilder();
		/*for(int i=0;i<length;i++){
			selectScopeList.get(i).replace(/[^a-zA-Z0-9]/ig, "").toLowerCase();
		}*/
		
		if(industry) {
		getDocIdQuery=new StringBuilder("SELECT ID,FILENAME FROM INDUSTRY_DOCUMENTSTORE WHERE TEMPLATETYPE=? AND IMGDESC IN (");
		}else {
			getDocIdQuery=new StringBuilder("SELECT ID,FILENAME FROM DOCUMENTSTORE WHERE TEMPLATETYPE=? AND IMGDESC IN (");
		}		
		try{
			
			
			for(int i=0;i<length;i++){
				if(i==length-1)
					getDocIdQuery.append("?)");
				else
					getDocIdQuery.append("?,");
				
			}
			con = DBConnection.createConnection();
			pStmt = con.prepareStatement(getDocIdQuery.toString());
			pStmt.setString(1, "BASE");
			 int pos = 2;
			for (int i = 0; i < length; i++, pos++) {

				pStmt.setString(pos, selectScopeList.get(i));

			}
				rs = pStmt.executeQuery();
				while(rs.next()){
					flag = false;
					docIds.add(rs.getString("ID"));
					imgIds.add(rs.getString("FILENAME"));
					}
				
				objHCPDocServiceResDto.setImgIds(imgIds);
				objHCPDocServiceResDto.setDocIds(docIds);
				if(flag){
					objHCPDocServiceResDto.setStatus(false);
					objHCPDocServiceResDto.setDescription("Selected base templates are not imported, please import the templates to download!!");
				}
				if(selectScopeList.size() != imgIds.size()){
					objHCPDocServiceResDto.setStatus(false);
					selectScopeList.removeAll(imgIds);
					filesNotExists.addAll(selectScopeList);
					objHCPDocServiceResDto.setNotImportedTemplates(filesNotExists);
					objHCPDocServiceResDto.setDescription("Some of the base templates are not imported from the selected img list, please import the templates to download!!");
				}
				else{
					objHCPDocServiceResDto.setStatus(true);

				}
				
		}
		catch (SQLException e){
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}finally{
			if(rs!=null){
				try {
					rs.close();
					rs= null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("getDocumentIds method ended");

		}	
		
		return objHCPDocServiceResDto;
	}
	
	public HCPDocServiceResDto checkTemplatesExists(ImgHierarchyCustomDto imgHierarchyCustomDto)  {
		slf4jLogger.info("checkTemplatesExists method started");
		Connection con = null;
		ResultSet rs=null;
		PreparedStatement pStmt=null;
		ArrayList<String>  imgIds= new ArrayList<String>();
		ArrayList<String> filesNotExists = new ArrayList<String>();
		ArrayList<String> selectScopeList = imgHierarchyCustomDto.getSelectedScopes();
		int length = selectScopeList.size();
		HCPDocServiceResDto objHCPDocServiceResDto = new HCPDocServiceResDto();
		StringBuilder getDocIdQuery = new StringBuilder();
		if(imgHierarchyCustomDto.isIndustry()) {
			
			 getDocIdQuery=new StringBuilder("SELECT FILENAME FROM INDUSTRY_DOCUMENTSTORE WHERE  TEMPLATETYPE= ? AND IMGDESC IN (");	
		}else {
			 getDocIdQuery=new StringBuilder("SELECT FILENAME FROM DOCUMENTSTORE WHERE  TEMPLATETYPE= ? AND IMGDESC IN (");
		}
		try{
			
			for(int i=0;i<length;i++){
				if(i==length-1)
					getDocIdQuery.append("?)");
				else
					getDocIdQuery.append("?,");
				
			}
			
			con = DBConnection.createConnection();
			pStmt = con.prepareStatement(getDocIdQuery.toString());
			pStmt.setString(1, "BASE");
			 int pos = 2;
			    for(int i=0;i<length;i++,pos++){
			    	pStmt.setString (pos, selectScopeList.get(i));				
				}
				rs = pStmt.executeQuery();
				while(rs.next()){
					imgIds.add(rs.getString("FILENAME"));
				}
				
				if(!imgIds.isEmpty()){
					objHCPDocServiceResDto.setStatus(false);
					selectScopeList.removeAll(imgIds);
					filesNotExists.addAll(selectScopeList);
					objHCPDocServiceResDto.setDescription("Some of the templates already exists in the document service");
				}
				else{
					objHCPDocServiceResDto.setStatus(true);
					objHCPDocServiceResDto.setDescription("Templates are not available in the document service");

				}
				objHCPDocServiceResDto.setImgIds(imgIds);
				objHCPDocServiceResDto.setNotImportedTemplates(filesNotExists);
		}
		catch (SQLException e){
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}finally{
			if(rs!=null){
				try {
					rs.close();
					rs= null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(pStmt!=null){
				try {
					pStmt.close();
					pStmt=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("checkTemplatesExists method ended");

		}	
		
		return objHCPDocServiceResDto;
	}
	
	
	public static Session ConnectDocumentStore() throws Exception
	{
		Session openCmisSession = null;
	    Logger slf4jLogger = LoggerFactory.getLogger(HCPDocDAO.class);

		try {/*

			  PropMappings propObj = PropMappings.getInstance();
		      InitialContext ctx = new InitialContext();
		      String lookupName = "java:comp/env/" + "EcmService";
		      EcmService ecmSvc = (EcmService) ctx.lookup(lookupName);
		      try {
		    	  openCmisSession = ecmSvc.connect(propObj.getValue("REPOSITORYNAME"), propObj.getValue("SECRETKEY"));
		      }
		      catch (CmisObjectNotFoundException e) {
		        RepositoryOptions options = new RepositoryOptions();
		        options.setUniqueName(propObj.getValue("REPOSITORYNAME"));
		        options.setRepositoryKey(propObj.getValue("SECRETKEY"));
		        options.setVisibility(Visibility.PROTECTED);
		        ecmSvc.createRepository(options);
		        
		    		openCmisSession = ecmSvc.connect(propObj.getValue("REPOSITORYNAME"), propObj.getValue("SECRETKEY"));
		      }
		*/}
		catch (Exception e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		 }
		
		return openCmisSession;
	}

}
