/*package com.acn.rpa.docservice;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sap.ecm.api.AbstractCmisProxyServlet;

@WebServlet("/CMISProxyServlet")
public class CMISProxyServlet extends AbstractCmisProxyServlet{
	private static final long serialVersionUID = 1L;

    public CMISProxyServlet() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	@Override
	protected boolean supportBrowserBinding() {
		return true;
	}
	
	@Override
	protected String getRepositoryKey() {
		return "s4configrpaQA";
	}

	@Override
	protected String getRepositoryUniqueName() {
		return "S4ConfigRPA.RepositoryQA";
	}
}
*/