package com.acn.rpa.utilities;

import java.io.IOException;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PropMappings {
	
	
	
	private static PropMappings instance = null;
    private Properties properties = new Properties();

    
    protected PropMappings() throws IOException{
        properties.load(PropMappings.class.getClassLoader().getResourceAsStream("config.properties"));

    }

    public static PropMappings getInstance() {
    	Logger slf4jLogger = LoggerFactory.getLogger(PropMappings.class);
        if(instance == null) {
            try {
                instance = new PropMappings();
            } catch (IOException ioe) {
                slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,ioe);
            }
        }
        return instance;
    }

    public String getValue(String key) {
        return properties.getProperty(key);
    }

}
