package com.acn.rpa.utilities;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sap.conn.jco.JCo;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoTable;


public class AppUtils {
Properties configProp = new Properties();  
private final Logger slf4jLogger = LoggerFactory.getLogger(AppUtils.class);

	public Properties fnReadPropertyFile() {
		slf4jLogger.info("fnReadPropertyFile method started");
		InputStream input = null;
		try {
			input = this.getClass().getResourceAsStream("/BackendCode.properties");
			configProp.load(input);
			return configProp;
		} catch (IOException io) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,io);
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			  slf4jLogger.info("fnReadPropertyFile method ended");

		}
		return null;
	} 
	
	public ArrayList<String> getAbapProgram(String path) {
		slf4jLogger.info("getAbapProgram method started");
		ArrayList<String> prog = null;
		BufferedReader br = null;
		File fin = null;
		try {
			prog = new ArrayList<String>();
			fin = new File(path);
			br = new BufferedReader(new FileReader(fin));
			String line = null;
			while ((line = br.readLine()) != null) {
				prog.add(line);
			}

		} catch (IOException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}
		finally{
			try {
				br.close();
				br = null;
				fin = null;
			} catch (IOException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
			  slf4jLogger.info("getAbapProgram method ended");


		}
		return prog;
	}
	
	public JCoTable getABAPPrg(String path,JCoParameterList tabInput) {
		slf4jLogger.info("getABAPPrg method started");
		BufferedReader br = null;
		File fin = null;
		JCoTable jCoTableObj = null;
		try {
			jCoTableObj = tabInput.getTable("I_PROG");
			fin = new File(path);
			br = new BufferedReader(new FileReader(fin));
			String line = null;
			while ((line = br.readLine()) != null) {
				jCoTableObj.appendRow();
				jCoTableObj.setValue("LINE", line);
			}
			/*String str=null;
		
			BufferedReader reader = new BufferedReader(new StringReader(path));
			
			while((str = reader.readLine()) != null) 
               {
				if (str.length() > 0){
					jCoTableObj.appendRow();
				jCoTableObj.setValue("LINE", str);
				}
			}*/
		

		} catch (IOException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}
		finally{
			try {
				br.close();
				br = null;
				fin = null;
			} catch (IOException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
			  slf4jLogger.info("getABAPPrg method ended");

		}
		return jCoTableObj;
	}
	
	
	
	
	public String folderCreation(String foldLoc) {
		slf4jLogger.info("folderCreation method started");
        try{
		Path path = Paths.get(foldLoc);
        if (!Files.exists(path)) {
              try {
                    Files.createDirectories(path);
              } catch (IOException e) {
                    slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
                    return "";
              }
        } else {
              try {
                    Files.createDirectories(path);
              } catch (IOException e) {
                    slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
              }
        }

        if (Files.exists(path)) {
              DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
              String todaysDate = dateFormat.format(System.currentTimeMillis());

              String upLoc = foldLoc + "/" + todaysDate;
              path = Paths.get(upLoc);

              if (!Files.exists(path)) {
                    try {
                          Files.createDirectories(path);
                          return upLoc;
                    } catch (IOException e) {
                          slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
                          return "";
                    }
              }
        }

        return "";
        }catch(Exception e){
  		  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
  		  return "";
        }finally{
  		  slf4jLogger.info("folderCreation method ended");

        }
  }

	public String genericFolderCreation(String foldLoc) {
		slf4jLogger.info("genericFolderCreation method started");
		try{
      Path path = Paths.get(foldLoc);
      if (!Files.exists(path)) {
            try {
                  Files.createDirectories(path);
            } catch (IOException e) {
                  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
                  return "";
            }
      } else {
            try {
                  Files.createDirectories(path);
                  return foldLoc;
            } catch (IOException e) {
                  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
            }
      }      
      return "";
	
	}catch(Exception e){
        slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		return "";
	}
	finally{
		  slf4jLogger.info("genericFolderCreation method ended");

	}
 }	
}