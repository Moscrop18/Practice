package com.acn.rpa.utilities;


import java.util.Hashtable;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

import com.sap.conn.jco.ext.DestinationDataEventListener;
//import com.sap.conn.jco.ext.DestinationDataProvider;

import com.sap.conn.jco.ext.DestinationDataProvider;

public class MyDestinationDataProvider implements DestinationDataProvider {
	private static MyDestinationDataProvider myDestinationDataProvider = null;
	private MyDestinationDataProvider() {
	}
	public static MyDestinationDataProvider getInstance() {
	    if (myDestinationDataProvider == null) {
	        myDestinationDataProvider = new MyDestinationDataProvider();
	    }
	    return myDestinationDataProvider;
	}
	private Hashtable<String, Properties> propertiesTab = new Hashtable<String, Properties>();
	private DestinationDataEventListener eL;

	public Properties getDestinationProperties(String destinationName) {
		if (propertiesTab.containsKey(destinationName)) {
			return propertiesTab.get(destinationName);
		}

		return null;
		// alternatively throw runtime exception
		// throw new RuntimeException("Destination " + destinationName + " is
		// not available");
	}

	public void setDestinationDataEventListener(DestinationDataEventListener eventListener) {
		this.eL = eventListener;
	}

	public void changePropertiesForABAP_AS(Properties pConProps) {
		/* Set  URL = pConProps.keySet(); 
	        Iterator itr = URL.iterator(); 
	          
	        while(itr.hasNext()) 
	        { 
	        String   str = (String)itr.next(); 
	            System.out.println("The URL for pConProps" + str +  
	                    " is " + pConProps.getProperty(str)); 
	        } */
		propertiesTab.put(pConProps.getProperty("jco.client.dest"), pConProps);
		// eL.updated(pConProps.getProperty("jco.client.dest"));

	}

	public boolean supportsEvents() {
		return false;
	}

}
