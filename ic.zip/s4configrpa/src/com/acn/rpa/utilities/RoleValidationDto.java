package com.acn.rpa.utilities;

import java.util.List;

public class RoleValidationDto {
	
	private String omId;
	private List<String> roleIdList;
	public String getOmId() {
		return omId;
	}
	public void setOmId(String omId) {
		this.omId = omId;
	}
	public List<String> getRoleIdList() {
		return roleIdList;
	}
	public void setRoleIdList(List<String> roleIdList) {
		this.roleIdList = roleIdList;
	}

}
