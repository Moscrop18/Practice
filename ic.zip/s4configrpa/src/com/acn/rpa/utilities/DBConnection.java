package com.acn.rpa.utilities;


import java.sql.Connection;
import java.sql.DriverManager;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.service.AdminService;



public class DBConnection {
	private static Connection con = null;
	
	 private DBConnection() {
	   }
	
	  public static Connection createConnection() {
			  	DataSource dataSource = null;
		    	PropMappings propObj = PropMappings.getInstance();
		    	Logger slf4jLogger = LoggerFactory.getLogger(DBConnection.class);
				 try {
					if(propObj.getValue("S4CONFIGHANA_DB").equals("SAPHANA")){
					  InitialContext ctx;
					  ctx = new InitialContext();
					  dataSource = (DataSource) ctx.lookup(propObj.getValue("DATASOURCE_VALUE"));
					  con = dataSource.getConnection();
					  return con; 
					}
					else if(propObj.getValue("S4CONFIGHANA_DB").equals("MYSQL")){
						Class.forName(propObj.getValue("MYSQL_DRIVER_CLASS"));
						con = DriverManager.getConnection(propObj.getValue("MYSQL_URL"), propObj.getValue("MYSQL_USERNAME"), propObj.getValue("MYSQL_PASSWORD"));
						return con; 
					}
				 }
				 
				 catch(Exception e){
						slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				 }finally{
					 dataSource = null;
				 }
				 return con;
	  }
}


