package com.acn.rpa.service;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.reports.ConfigTRReportDto;
import com.acn.rpa.reports.ConfigTRResReportDto;
import com.acn.rpa.reports.ConfigTransactionReportDAO;
import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.RoleValidationDto;
import com.acn.user.session.UserSessionDao;

@Path("configTRReportService")

@Produces(MediaType.APPLICATION_JSON)


public class ConfigTRReportService {

    private final Logger slf4jLogger = LoggerFactory.getLogger(ConfigTRReportService.class);

                  @Path("getConfigTR")
                  @POST
                  @Consumes({MediaType.APPLICATION_JSON})
                  @Produces(MediaType.APPLICATION_JSON)
                  public Response getConfigTR (@Valid ConfigTRReportDto ConfigTRReportDto){
            		  slf4jLogger.info("getConfigTR service started");
            		  List<String> roleIdList = new ArrayList<>();
            		  roleIdList.add(ConstantsValues.PROJECTADMIN);
            		  roleIdList.add(ConstantsValues.TOOLADMIN);
            		  roleIdList.add(ConstantsValues.CONFIG);
            		  RoleValidationDto roleValidationDto = new RoleValidationDto();
            		  roleValidationDto.setRoleIdList(roleIdList);
            		  try{
                	  if(UserSessionDao.isSessionActive(ConfigTRReportDto.getSessionInputDTO(),roleValidationDto)){
                                  ConfigTransactionReportDAO configTransactionReportDAO = new ConfigTransactionReportDAO();
                                  ArrayList<ConfigTRResReportDto>  configTRExecutionLogList = new ArrayList<ConfigTRResReportDto>();
                                  
                                  configTRExecutionLogList = configTransactionReportDAO.getConfigTRReportData(ConfigTRReportDto);
                                  if(configTRExecutionLogList.size()>0){
                                    return Response.ok()
                  	   					  .header("Cache-Control", "No-cache")
                						  .header("X-FRAME-OPTIONS", "Deny")
                						  .header("X-Content-Type-Options", "nosniff")
                						  .header("Content-Security-Policy",
                							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
                						  .header("X-XSS-Protection", "1")
                						  .entity(configTRExecutionLogList).build();
                                    		
                                  }
                                    return     Response.ok()
                    	   					  .header("Cache-Control", "No-cache")
                    						  .header("X-FRAME-OPTIONS", "Deny")
                    						  .header("X-Content-Type-Options", "nosniff")
                    						  .header("Content-Security-Policy",
                    							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
                    						  .header("X-XSS-Protection", "1")
                    						  .entity("{\"message\": \"No Results Found! \"}").build();
                                    	
                	  				}
                	  			else{slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
                	  				return Response.ok()
                  	   					  .header("Cache-Control", "No-cache")
                  						  .header("X-FRAME-OPTIONS", "Deny")
                  						  .header("X-Content-Type-Options", "nosniff")
                  						  .header("Content-Security-Policy",
                  							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
                  						  .header("X-XSS-Protection", "1")
                  						  .entity("{\"message\": \""+ ConstantsValues.SERVICESECURITYERROR +"\"}").build();
                	  					
                	  			}
            		  }
            		  catch(Exception e){
            			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
            			  return Response.ok()
            					  .header("Cache-Control", "No-cache")
            					  .header("X-FRAME-OPTIONS", "Deny")
            					  .header("X-Content-Type-Options", "nosniff")
            					  .header("Content-Security-Policy",
            						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
            					  .header("X-XSS-Protection", "1")
            					  .header("Server","Disable")
            					  
            					  .entity(ConstantsValues.EXCEPTION).build();

            		  }finally{		
            			slf4jLogger.info("getConfigTR service ended");
            		  }
                  			}
}
