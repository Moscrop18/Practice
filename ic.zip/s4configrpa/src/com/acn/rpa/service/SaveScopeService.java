
package com.acn.rpa.service;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.admin.ResponseDto;
import com.acn.rpa.config.SaveScopeDAO;
import com.acn.rpa.config.UserConfigScopeDto;
import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.RoleValidationDto;
import com.acn.user.session.ResMessageDto;
import com.acn.user.session.UserSessionDao;


@Path("/scopeState")
public class SaveScopeService {
    private final Logger slf4jLogger = LoggerFactory.getLogger(SaveScopeService.class);

	SaveScopeDAO saveScopeDAO = new SaveScopeDAO();

	@POST
	@Path("/saver")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response scopeSaver(@Valid UserConfigScopeDto userConfigScopeDto){
		 slf4jLogger.info("saver service started");
		 try{
		 ResponseDto responseDto = new ResponseDto();
		 List<String> roleIdList = new ArrayList<>();
	  	 roleIdList.add(ConstantsValues.CONFIG);
	  	 RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	 roleValidationDto.setRoleIdList(roleIdList);
		 roleValidationDto.setOmId(userConfigScopeDto.getOmId());
		 if(UserSessionDao.isSessionActive(userConfigScopeDto.getSessionInputDTO(),roleValidationDto)){
		 return Response.ok()
					.header("Cache-Control", "No-cache")
				    .header("X-FRAME-OPTIONS", "Deny")
				    .header("X-Content-Type-Options", "nosniff")
				    .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				    .header("X-XSS-Protection", "1")
				    .entity(saveScopeDAO.scopeSaver(userConfigScopeDto)).build();
				 
		 }
		 else{
			 ResMessageDto resMessageDto = new ResMessageDto();
			 resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			 slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			 resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			 responseDto.setResMessageDto(resMessageDto);
			 return Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity( responseDto).build();
			
		 }
		 }catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("saver service ended");
		  }

	}
	
	
	@POST
	@Path("/retriever")
	@Produces(MediaType.APPLICATION_JSON)
	public Response scopeRetriever(@Valid UserConfigScopeDto userConfigScopeDto){
		 slf4jLogger.info("retriever service started");
		  List<String> roleIdList = new ArrayList<>();
	  	  roleIdList.add(ConstantsValues.CONFIG);
	  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	  roleValidationDto.setRoleIdList(roleIdList);
		  roleValidationDto.setOmId(userConfigScopeDto.getOmId());
		 try{
		 ResponseDto responseDto = new ResponseDto();
		 if(UserSessionDao.isSessionActive(userConfigScopeDto.getSessionInputDTO(),roleValidationDto)){
			 return Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity(saveScopeDAO.scopeRetriever(userConfigScopeDto)).build();
					 
		 }
		 else{
			 ResMessageDto resMessageDto = new ResMessageDto();
			 resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			 slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			 resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			 responseDto.setResMessageDto(resMessageDto);
			 return Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity(responseDto).build();
		}
		 }catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("retriever service ended");
		  }

	}
}
