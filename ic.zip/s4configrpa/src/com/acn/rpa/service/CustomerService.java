package com.acn.rpa.service;


import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.admin.CustomerDAO;
import com.acn.rpa.admin.CustomerDto;
import com.acn.rpa.config.dto.CustomDestinationReqDto;
import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.RoleValidationDto;
import com.acn.user.session.CustomInputDto;
import com.acn.user.session.CustomResDto;
import com.acn.user.session.CustomerInputDto;
import com.acn.user.session.CustomerListDto;
import com.acn.user.session.DataStatusDto;
import com.acn.user.session.IMGPreviewDto;
import com.acn.user.session.ResMessageDto;
import com.acn.user.session.SessionInputDTO;
import com.acn.user.session.SysInputDto;
import com.acn.user.session.UserSessionDao;
@Path("customerSrv") 

public class CustomerService { 
    private final Logger slf4jLogger = LoggerFactory.getLogger(CustomerService.class);


	  @Path("createCustomer") 
	  @POST
	  @Consumes({MediaType.APPLICATION_JSON})
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response createCustomer (@Valid CustomerDto customer){
		  slf4jLogger.info("createCustomer service started");
		  List<String> roleIdList = new ArrayList<>();
	  	  roleIdList.add(ConstantsValues.PROJECTADMIN);
	  	  roleIdList.add(ConstantsValues.TOOLADMIN);
	  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	  roleValidationDto.setRoleIdList(roleIdList);
		  roleValidationDto.setOmId(customer.getOmId());
		  try{
		  if(UserSessionDao.isSessionActive(customer.getSessionInputDTO(),roleValidationDto)){	
			  CustomerDAO customerdetailsObj = new CustomerDAO(); 
			  return Response.ok()
	   					  .header("Cache-Control", "No-cache")
						  .header("X-FRAME-OPTIONS", "Deny")
						  .header("X-Content-Type-Options", "nosniff")
						  .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						  .header("X-XSS-Protection", "1")
						  .entity(customerdetailsObj.createCustomer(customer)).build();
  					 	  
		  }else{
			  ResMessageDto resMessageDto = new ResMessageDto();	
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return  Response.ok()
   					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity(resMessageDto).build();
					  
		  }
		  }
		  catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("createCustomer service ended");
		  }
	  }
	
	  @Path("deleteCustomer")
	  @PUT
	  @Consumes({MediaType.APPLICATION_JSON})
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response deleteCustomer (@Valid CustomInputDto customInputDto) {
		  slf4jLogger.info("deleteCustomer service started");
		  try{
			  List<String> roleIdList = new ArrayList<>();
		  	  roleIdList.add(ConstantsValues.PROJECTADMIN);
		  	  roleIdList.add(ConstantsValues.TOOLADMIN);
		  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
		  	  roleValidationDto.setRoleIdList(roleIdList);

		  if(UserSessionDao.isSessionActive(customInputDto.getSessionInputDTO(),roleValidationDto)){	
			  CustomerDAO customerdetailsObj = new CustomerDAO(); 
			  return   Response.ok()
   					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity( customerdetailsObj.deleteCustomer(customInputDto.getDataList())).build();
					   
		  }else{
			  ResMessageDto resMessageDto = new ResMessageDto();	
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return    Response.ok()
   					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity(resMessageDto).build();
					  
		  }
		  }
		  catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("deleteCustomer service ended");
		  }
	  }
	  
	  @Path("modifyCustomer")
	  @PUT
	  @Consumes({MediaType.APPLICATION_JSON})
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response modifyCustomer (@Valid CustomerDto customInputDto) {
		  slf4jLogger.info("modifyCustomer service started");
		  List<String> roleIdList = new ArrayList<>();
	  	  roleIdList.add(ConstantsValues.PROJECTADMIN);
	  	  roleIdList.add(ConstantsValues.TOOLADMIN);
	  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	  roleValidationDto.setRoleIdList(roleIdList);
		  roleValidationDto.setOmId(customInputDto.getOmId());

		  try{
		  if(UserSessionDao.isSessionActive(customInputDto.getSessionInputDTO(),roleValidationDto)){	
			  CustomerDAO customerdetailsObj = new CustomerDAO(); 
			  return    Response.ok()
   					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity(customerdetailsObj.modifyCustomer(customInputDto)).build();
					    
		  }else{
			  ResMessageDto resMessageDto = new ResMessageDto();	
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return    Response.ok()
   					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity(resMessageDto).build();					  
		  }
		  }
		  catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("modifyCustomer service ended");
		  }
	  }
	  
	  @Path("displayCustomers")
	  @POST
	  @Consumes({MediaType.APPLICATION_JSON})
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response displayCustomers(@Valid CustomerInputDto customInputDto){
		  slf4jLogger.info("displayCustomers service started");
		  List<String> roleIdList = new ArrayList<>();
	  	  roleIdList.add(ConstantsValues.PROJECTADMIN);
	  	  roleIdList.add(ConstantsValues.TOOLADMIN);
	  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	  roleValidationDto.setRoleIdList(roleIdList);
		  try{
		  	if(UserSessionDao.isSessionActive(customInputDto.getSessionInputDTO(),roleValidationDto)){	
				  CustomerDAO customerdetailsObj = new CustomerDAO(); 
				  return   Response.ok()
	   					  .header("Cache-Control", "No-cache")
						  .header("X-FRAME-OPTIONS", "Deny")
						  .header("X-Content-Type-Options", "nosniff")
						  .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						  .header("X-XSS-Protection", "1")
						  .entity(customerdetailsObj.getAllCustomers(customInputDto)).build();
						   
			  }else{
				  CustomerListDto resDto = new CustomerListDto();
				  ResMessageDto resMessageDto = new ResMessageDto();	
				  resDto.setResMessageDto(resMessageDto);
				  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
				  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
				  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
				  return Response.ok()
	   					  .header("Cache-Control", "No-cache")
						  .header("X-FRAME-OPTIONS", "Deny")
						  .header("X-Content-Type-Options", "nosniff")
						  .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						  .header("X-XSS-Protection", "1")
						  .entity(resDto).build();
						  
			  }
		  }
		  catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("displayCustomers service ended");
		  }
	  }
	  
	  @Path("displayClientIds")
	  @POST
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response displayClientIds(@Valid SessionInputDTO sessionInputDto){
		  slf4jLogger.info("displayClientIds service started");
		  List<String> roleIdList = new ArrayList<>();
	  	  roleIdList.add(ConstantsValues.PROJECTADMIN);
	  	  roleIdList.add(ConstantsValues.TOOLADMIN);
	  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	  roleValidationDto.setRoleIdList(roleIdList);
		  try{
		  if(UserSessionDao.isSessionActive(sessionInputDto,roleValidationDto)){	
			  CustomerDAO customerdetailsObj = new CustomerDAO(); 
			  return  Response.ok()
   					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity(customerdetailsObj.displayClientIds()).build();
					  
		  }else{
			  CustomResDto resDto = new CustomResDto();
			  ResMessageDto resMessageDto = new ResMessageDto();	
			  resDto.setResMessageDto(resMessageDto);
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return Response.ok()
   					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity(resDto).build();
					  
		  }
		  }
		  catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("displayClientIds service ended");
		  }  
	  }
	  
	  @Path("displayProjectNames")
	  @POST
	  @Consumes({MediaType.APPLICATION_JSON})
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response displayProjectNames(@Valid CustomerInputDto userdto){
		  slf4jLogger.info("displayProjectNames service started");
		  List<String> roleIdList = new ArrayList<>();
	  	  roleIdList.add(ConstantsValues.PROJECTADMIN);
	  	  roleIdList.add(ConstantsValues.TOOLADMIN);
	  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	  roleValidationDto.setRoleIdList(roleIdList);
		  try{
		  if(UserSessionDao.isSessionActive(userdto.getSessionInputDTO(),roleValidationDto)){	
			  CustomerDAO customerdetailsObj = new CustomerDAO(); 
			  return Response.ok()
   					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity(customerdetailsObj.displayProjectNames(userdto)).build();
					  
		  }else{
			  CustomResDto resDto = new CustomResDto();
			  ResMessageDto resMessageDto = new ResMessageDto();	
			  resDto.setResMessageDto(resMessageDto);
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return Response.ok()
   					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity(resDto).build();
					  
		  }
		  }
		  catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("displayProjectNames service ended");
		  }
	  }

	  @POST
	  @Path("validateCustomerId")
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response displayUserIds(@Valid IMGPreviewDto inputDto){
		  slf4jLogger.info("validateCustomerId service started");
		  List<String> roleIdList = new ArrayList<>();
	  	  roleIdList.add(ConstantsValues.PROJECTADMIN);
	  	  roleIdList.add(ConstantsValues.TOOLADMIN);
	  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	  roleValidationDto.setRoleIdList(roleIdList);
		  try{
			if(UserSessionDao.isSessionActive(inputDto.getSessionInputDTO(),roleValidationDto)){	
				  CustomerDAO customerdetailsObj = new CustomerDAO(); 
				  return Response.ok()
	   					  .header("Cache-Control", "No-cache")
						  .header("X-FRAME-OPTIONS", "Deny")
						  .header("X-Content-Type-Options", "nosniff")
						  .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						  .header("X-XSS-Protection", "1")
						  .entity(customerdetailsObj.validateCustomerId(inputDto.getSelectedOmid())).build();
						  
			  }else{
				  DataStatusDto resDto = new DataStatusDto();
				  ResMessageDto resMessageDto = new ResMessageDto();	
				  resDto.setResMessageDto(resMessageDto);
				  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
				  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
				  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
				  return Response.ok()
	   					  .header("Cache-Control", "No-cache")
						  .header("X-FRAME-OPTIONS", "Deny")
						  .header("X-Content-Type-Options", "nosniff")
						  .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						  .header("X-XSS-Protection", "1")
						  .entity(resDto).build();
			  }
		  }
		  catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("validateCustomerId service ended");
		  }  
	  }
	  
	  //Added by Veena 
	 
		@Path("/custDestReg")
		@POST
		@Consumes({MediaType.APPLICATION_JSON})
		@Produces(MediaType.APPLICATION_JSON)
		 public Response assignCustDestReq (@Valid CustomDestinationReqDto inputDto) {
		   slf4jLogger.info("custDestReg service started");
		  
		  try{
			  
			  List<String> roleIdList = new ArrayList<>();
		  	  roleIdList.add(ConstantsValues.PROJECTADMIN);
		  	 
		  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
		  	  roleValidationDto.setRoleIdList(roleIdList);
		  	if(UserSessionDao.isSessionActive(inputDto.getSessionInputDTO(),roleValidationDto)){	
				  CustomerDAO customerdetailsObj = new CustomerDAO(); 
				  return   Response.ok()
	   					  .header("Cache-Control", "No-cache")
						  .header("X-FRAME-OPTIONS", "Deny")
						  .header("X-Content-Type-Options", "nosniff")
						  .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						  .header("X-XSS-Protection", "1")
						  .entity( customerdetailsObj.updateCustomDestination(inputDto.getOmidList(),inputDto.getCustDestReq())).build();
						   
			  }
		  	else{
				  ResMessageDto resMessageDto = new ResMessageDto();	
				  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
				  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
				  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
				  return    Response.ok()
	   					  .header("Cache-Control", "No-cache")
						  .header("X-FRAME-OPTIONS", "Deny")
						  .header("X-Content-Type-Options", "nosniff")
						  .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						  .header("X-XSS-Protection", "1")
						  .entity(resMessageDto).build();
						  
			  }
			  
		  }
		  catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("assignCustDestReq service ended");
		  }
		  
	  }
		
		@Path("/getEffortSavingData")
		@POST
		@Consumes({MediaType.APPLICATION_JSON})
		@Produces(MediaType.APPLICATION_JSON)
		 public Response getEffortSavingData (@Valid SysInputDto sysInputDto) {
		   slf4jLogger.info("EffortSavingData service started");
		  
		  try{
			  
			  List<String> roleIdList = new ArrayList<>();
		  	  roleIdList.add(ConstantsValues.TOOLADMIN);
		  	 
		  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
		  	  roleValidationDto.setRoleIdList(roleIdList);
		  	if(UserSessionDao.isSessionActive(sysInputDto.getSessionInputDTO(),roleValidationDto)){	
				  CustomerDAO customerdetailsObj = new CustomerDAO(); 
				  return   Response.ok()
	   					  .header("Cache-Control", "No-cache")
						  .header("X-FRAME-OPTIONS", "Deny")
						  .header("X-Content-Type-Options", "nosniff")
						  .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						  .header("X-XSS-Protection", "1")
						  .entity( customerdetailsObj.getEffortSavingData(sysInputDto.getOmID())).build();
						   
			  }
		  	else{
				  ResMessageDto resMessageDto = new ResMessageDto();	
				  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
				  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
				  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
				  return    Response.ok()
	   					  .header("Cache-Control", "No-cache")
						  .header("X-FRAME-OPTIONS", "Deny")
						  .header("X-Content-Type-Options", "nosniff")
						  .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						  .header("X-XSS-Protection", "1")
						  .entity(resMessageDto).build();
						  
			  }
			  
		  }
		  catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("EffortSavingData service ended");
		  }
		  
	  }
		
	  //Ended by Veena
		  
}
