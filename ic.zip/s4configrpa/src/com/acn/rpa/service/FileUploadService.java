package com.acn.rpa.service;

import java.io.ByteArrayOutputStream;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServletRequest;
import com.acn.rpa.utilities.DBConnection;

import javax.validation.Valid;
import javax.validation.ValidationException;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.config.ExcelFormatConvert;
import com.acn.rpa.config.ServiceResponseDto;
import com.acn.rpa.config.dto.ConfigTemplateDto;
import com.acn.rpa.config.dto.ConfigUploadResDto;
import com.acn.rpa.config.dto.FileUploadCustomDto;
import com.acn.rpa.config.dto.SelectedScopeDto;
import com.acn.rpa.imghierarchy.ImgHierarchyDAO;
import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.RoleValidationDto;
import com.acn.user.session.ResMessageDto;
import com.acn.user.session.UserSessionDao;
//import javax.servlet.annotation.MultipartConfig;
@Path("/files")  
/*@MultipartConfig(fileSizeThreshold=1024*1024*25, 	// 10 MB 
maxFileSize=1024*1024*50,      	// 50 MB
maxRequestSize=1024*1024*100)*/
public class FileUploadService {
    private final Logger slf4jLogger = LoggerFactory.getLogger(FileUploadService.class);

	 @POST
	
	 @Consumes(MediaType.MULTIPART_FORM_DATA)
	 @Produces(MediaType.APPLICATION_JSON)
	 @Path("/multipleUpload/{folderName}")
	
	 public Response multipleFileUpload(@Context HttpServletRequest request,@PathParam("folderName") String folderName) {
		 slf4jLogger.info("multipleFileUpload service started");
		 //final long MAX_UPLOAD_IN_MEGS = 50;
		 try{
		 FileItemFactory factory = new DiskFileItemFactory();
		 ServletFileUpload fileUpload = new ServletFileUpload(factory);
		 //fileUpload.setSizeMax(MAX_UPLOAD_IN_MEGS * 1024 * 1024);
		// String viewConfFilePath = null;
		// String webAppPath = request.getServletContext().getRealPath("/WEB-INF");
		 List<String> fileNameList = new ArrayList<>();
		 List<byte[]> fileBytesList = new ArrayList<>();
		 byte[] fileByte = null;
		 Workbook workbook = null;
		 ServiceResponseDto responseDto = new ServiceResponseDto();
		 ByteArrayOutputStream bos = null;
		 if (ServletFileUpload.isMultipartContent(request)) {
		  
		  String fileName = "";
			FileItem fileItemTemp = null;
			try {
			List < FileItem > fileItemsList = fileUpload.parseRequest(request);
			Iterator < FileItem > fileItemsIterator = fileItemsList.iterator();
			String extension = "";
			//AppUtils utilsObj = new AppUtils();
			//String tempPath = webAppPath + File.separator + folderName;
			//String folderPath = utilsObj.folderCreation(tempPath);
			//String fileNameExtension  = "";
			while (fileItemsIterator.hasNext()) {
			    fileItemTemp = fileItemsIterator.next();
			    if (!fileItemTemp.isFormField()) {
			     fileName = fileItemTemp.getName();
			     int i = fileName.lastIndexOf('.');
					if (i > 0) {
					    extension = fileName.substring(i+1);
					}
			     //String [] fileNameSplit = fileName.split("_");
			     //fileNameExtension = fileNameSplit[1];
			     if(fileName != null && !fileName.equals("") && (extension.equals("xlsx") ||  extension.equals("xls"))){
			    	 	bos = new ByteArrayOutputStream();
						//viewConfFilePath = folderPath +File.separator+ fileName;
						//File storeFile = new File(viewConfFilePath);
					    //fileItemTemp.write(storeFile);
					   // fileNameList.add(viewConfFilePath); 
						workbook = WorkbookFactory.create(fileItemTemp.getInputStream());
    					workbook.write(bos);
    					fileByte = bos.toByteArray();
    					fileBytesList.add(fileByte);
    					fileNameList.add(fileName);
			     		}
			    	}
				}
			
			responseDto.setFileBytesList(fileBytesList);
			responseDto.setFileNameList(fileNameList);
			} catch (Exception e) {
				  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			   }finally{
				   if(bos != null)
						bos.close();
					bos = null;
			   }
	  }
		  
	  return Response.ok()
			  .header("Cache-Control", "No-cache")
			  .header("X-FRAME-OPTIONS", "Deny")
			  .header("X-Content-Type-Options", "nosniff")
			  .header("Content-Security-Policy",
				"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
			  .header("X-XSS-Protection", "1")
			  .entity(responseDto).build();
		 }
		  catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{
			  
			slf4jLogger.info("multipleFileUpload service ended");
		  }
			  
	 }
	
	 @Path("configTempalteValidation")
	 @Consumes(MediaType.APPLICATION_JSON)
	 @POST
	 @Produces(MediaType.APPLICATION_JSON)
	 public Response configTemplateUploadValidation(@Valid FileUploadCustomDto  fileUploadCustomDto)throws ValidationException{
		 slf4jLogger.info("configTempalteValidation service started");
		  List<String> roleIdList = new ArrayList<>();
		  roleIdList.add(ConstantsValues.CONFIG);
		  RoleValidationDto roleValidationDto = new RoleValidationDto();
		  roleValidationDto.setRoleIdList(roleIdList);
		 try{
		 ConfigUploadResDto configUploadResDto = new ConfigUploadResDto();
		 if(UserSessionDao.isSessionActive(fileUploadCustomDto.getSessionInputDTO(),roleValidationDto)){
		 ConfigTemplateDto configTemplateDto = new ConfigTemplateDto();
		 ArrayList<ConfigTemplateDto> configTempList = new ArrayList<ConfigTemplateDto>();
		 ArrayList<String> validationMsg = new ArrayList<String>();
		 
		 ImgHierarchyDAO imgHierarchyDao = new ImgHierarchyDAO();
		 ArrayList<String> imgIDList = new ArrayList<String>();
		 HashMap<String, ArrayList<String>>  imgViewMap = null;
		 ExcelFormatConvert excelFormatConvert = new ExcelFormatConvert();
		 ArrayList<String> viewList = null;
		 boolean isValid = false;
		 String roleType="Config";
		 try{
			 configUploadResDto.setUploadStatus(true);
		 for(SelectedScopeDto selectedScopeDto: fileUploadCustomDto.getSelectedScopeList()){
			 imgIDList.add(selectedScopeDto.getImgId());
		 }
		 if(fileUploadCustomDto.getCopyFlag()) {
			 imgViewMap = imgHierarchyDao.getImgobjectsCopyFunctionality(imgIDList);
		 }
		 else if(fileUploadCustomDto.isIndustryFlag()) {
			 imgViewMap = imgHierarchyDao.getImgobjectsForIndustry(imgIDList, fileUploadCustomDto.isIndustryFlag(),
					 fileUploadCustomDto.getIndustry(), fileUploadCustomDto.getSubIndustry());
		 }else {
			 imgViewMap = imgHierarchyDao.getImgobjects(imgIDList);
		 }
			
		 isValid = imgViewMap.isEmpty();
		// System.out.println("file validation"+isValid);
		// slf4jLogger.info("file validation"+isValid);
		 //if(fileUploadCustomDto.getCurrentFileList().size()!=fileUploadCustomDto.getSelectedScopeList().size()){
		// validationMsg.add("Config templates files uploded more/less than the scope selection");
		// selectedScopeDto.setFileUploadStatusMsg(validationMsg);
		// }
			 for(SelectedScopeDto selectedScopeDto: fileUploadCustomDto.getSelectedScopeList()){
				  validationMsg = new ArrayList<String>();
				 configTemplateDto = new ConfigTemplateDto();
				 if(selectedScopeDto.getIsMasterData() != null && selectedScopeDto.getIsMasterData().equalsIgnoreCase("Y")){//Skip Master data
					// if(fileUploadCustomDto.getCurrentFileList().size()==fileUploadCustomDto.getSelectedScopeList().size())
					 if(fileUploadCustomDto.getCurrentFileList().contains(selectedScopeDto.getFileName())){
						 validationMsg.add("Config Template Uploaded Successfully..");
						 selectedScopeDto.setFileUploadStatusMsg(validationMsg);
					 }
					 configTemplateDto.setSelectedScopeDto(selectedScopeDto);
					 configTemplateDto.setStatus(true);
					 configTemplateDto.setStatusMsg("Master data validate");
					 configTempList.add(configTemplateDto);
					 continue;
				 }
				/* else if(selectedScopeDto.getIsMasterData() != null && selectedScopeDto.getIsMasterData().equalsIgnoreCase("N")){//Skip Master data
					// if(fileUploadCustomDto.getCurrentFileList().size()==fileUploadCustomDto.getSelectedScopeList().size())
					 if(fileUploadCustomDto.getCurrentFileList().contains(selectedScopeDto.getFileName())){
						 validationMsg.add("Config Template Uploaded Successfully..");
						 selectedScopeDto.setFileUploadStatusMsg(validationMsg);
						 slf4jLogger.info("inside n");
					 }
					 configTemplateDto.setSelectedScopeDto(selectedScopeDto);
					 configTemplateDto.setStatus(true);
					 configTemplateDto.setStatusMsg("Config Template is validated");
					 configTempList.add(configTemplateDto);
					 continue;
				 }*/
				 else if(!fileUploadCustomDto.getCurrentFileList().contains(selectedScopeDto.getFileName())){
					 configTemplateDto.setSelectedScopeDto(selectedScopeDto);
					 configTemplateDto.setStatus(true);
					 configTemplateDto.setStatusMsg("Template not request for recent upload");
					 configTempList.add(configTemplateDto);
					 continue; 
				 }
				 
				 else{
					 if(isValid)
					 {
						 viewList = null;
					 }
					 else{
						 viewList = imgViewMap.get(selectedScopeDto.getImgId());
						 //System.out.println("vielist "+viewList);
						// slf4jLogger.info("vielist "+viewList);
					 }
					 if(viewList != null){
						 //slf4jLogger.info("inside view list");
						 configTemplateDto = excelFormatConvert.configFileValidation(selectedScopeDto, viewList,roleType);//  Enable for Production
						 //configTemplateDto = excelFormatConvert.configFileValidation_Dev(selectedScopeDto, viewList);//  Enable for Production
						 if(!configTemplateDto.isStatus()){
							 configTemplateDto.getSelectedScopeDto().setFilepath("");
							 configTemplateDto.getSelectedScopeDto().setFileName("");
							 configTemplateDto.getSelectedScopeDto().setFileUploadedIcon("glyphicon glyphicon-remove");
							 configUploadResDto.setUploadStatus(false);
						 }
						 configTempList.add(configTemplateDto);
					 }else{
						 //slf4jLogger.info("inside view list in else");
						 configUploadResDto.setUploadStatus(false);
						 	selectedScopeDto.setFilepath("");
							selectedScopeDto.setFileName("");
							selectedScopeDto.setFileUploadedIcon("glyphicon glyphicon-remove");
							validationMsg.add("The configuration view from the file does not exist in the tool's repository. Please verify the view name/ sheet name from the template uploaded");
							selectedScopeDto.setFileUploadStatusMsg(validationMsg);
							configTemplateDto.setSelectedScopeDto(selectedScopeDto);
							configTemplateDto.setStatus(false);
							configTemplateDto.setStatusMsg("The configuration view from the file does not exist in the tool's repository. Please verify the view name/ sheet name from the template uploaded");
							configTempList.add(configTemplateDto);
					 }
				 }
			 }

		 }catch (Exception e) {
			 viewList = fileUploadCustomDto.getCurrentFileList();
			 for(SelectedScopeDto selectedScopeDto: fileUploadCustomDto.getSelectedScopeList()){
				 validationMsg = new ArrayList<String>();
				 if(viewList.contains(selectedScopeDto.getFileName())){
					 configUploadResDto.setUploadStatus(false);
					 selectedScopeDto.setFilepath("");
					 selectedScopeDto.setFileName("");
					 selectedScopeDto.setFileUploadedIcon("glyphicon glyphicon-remove");
					 validationMsg.add("The configuration view from the file does not exist in the tool's repository. Please verify the view name/ sheet name from the template uploaded");
					 selectedScopeDto.setFileUploadStatusMsg(validationMsg);
					 configTemplateDto.setSelectedScopeDto(selectedScopeDto);
					 configTemplateDto.setStatus(false);
					 configTemplateDto.setStatusMsg("Exception occured on service. Please check that");
					 configTempList.add(configTemplateDto);
					 
				 }else{
					 configTemplateDto.setSelectedScopeDto(selectedScopeDto);
					 configTemplateDto.setStatus(true);
					 configTemplateDto.setStatusMsg("Template not request for recent upload ");
					 configTempList.add(configTemplateDto);
				 }
			 }			 
		}finally {
			 imgHierarchyDao = null;
			 imgIDList = null;
			 imgViewMap = null;
			 excelFormatConvert = null;
			 viewList = null;
			 validationMsg = null;
		}
		 		
		 configUploadResDto.setConfigTemplateDto(configTempList);
		 return  Response.ok()
				.header("Cache-Control", "No-cache")
			    .header("X-FRAME-OPTIONS", "Deny")
			    .header("X-Content-Type-Options", "nosniff")
			    .header("Content-Security-Policy",
				"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
			    .header("X-XSS-Protection", "1")
			    .entity(configUploadResDto).build();
				 
	  }
	 
		 else{
			 ResMessageDto resMessageDto = new ResMessageDto();
			 resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			 resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			 configUploadResDto.setResMessageDto(resMessageDto);
			 return  Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity(configUploadResDto).build();
		 }
		 
		 }
		  catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("configTempalteValidation service ended");
		  }
	 }
	 
	 @Path("configTempalteValidationConsolidation")
	 @Consumes(MediaType.APPLICATION_JSON)
	 @POST
	 @Produces(MediaType.APPLICATION_JSON)
	 public Response configTemplateUploadValidationConsolidation(@Valid FileUploadCustomDto  fileUploadCustomDto)throws ValidationException{
		 slf4jLogger.info("configTemplateUploadValidationConsolidation service started");
		  List<String> roleIdList = new ArrayList<>();
		  roleIdList.add(ConstantsValues.CONFIG);
		  RoleValidationDto roleValidationDto = new RoleValidationDto();
		  roleValidationDto.setRoleIdList(roleIdList);
		 try{
		 ConfigUploadResDto configUploadResDto = new ConfigUploadResDto();
		 if(UserSessionDao.isSessionActive(fileUploadCustomDto.getSessionInputDTO(),roleValidationDto)){
		 ConfigTemplateDto configTemplateDto = new ConfigTemplateDto();
		 ArrayList<ConfigTemplateDto> configTempList = new ArrayList<ConfigTemplateDto>();
		 ArrayList<String> validationMsg = new ArrayList<String>();
		 
		    Connection con = null;		
			PreparedStatement ps = null;
			try {
				con = DBConnection.createConnection();
				ps= con.prepareStatement("TRUNCATE TABLE CONSOLIDATION_EXECUTION");
				ps.execute();
				
			}catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			} finally {
				if(ps != null) {
					try {
						ps.close();
						ps = null;
					} catch (SQLException e) {
						slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
					}
				}
				if (con != null) {
					try {
						con.close();
						con = null;
					} catch (SQLException e) {
						slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
					}
				}

		 }
		 
		 ImgHierarchyDAO imgHierarchyDao = new ImgHierarchyDAO();
		 ArrayList<String> imgIDList = new ArrayList<String>();
		 HashMap<String, ArrayList<String>>  imgViewMap = null;
		 ExcelFormatConvert excelFormatConvert = new ExcelFormatConvert();
		 ArrayList<String> viewList = null;
		 boolean isValid = false;
		 String roleType="Config";
		 try{
			 configUploadResDto.setUploadStatus(true);
		 for(SelectedScopeDto selectedScopeDto: fileUploadCustomDto.getSelectedScopeList()){
			 imgIDList.add(selectedScopeDto.getImgId());
		 }
		 imgViewMap = imgHierarchyDao.getImgobjectsConsolidation(imgIDList);
		 isValid = imgViewMap.isEmpty();
		// System.out.println("file validation"+isValid);
		 slf4jLogger.info("file validation"+isValid);
		 //if(fileUploadCustomDto.getCurrentFileList().size()!=fileUploadCustomDto.getSelectedScopeList().size()){
		// validationMsg.add("Config templates files uploded more/less than the scope selection");
		// selectedScopeDto.setFileUploadStatusMsg(validationMsg);
		// }
			 for(SelectedScopeDto selectedScopeDto: fileUploadCustomDto.getSelectedScopeList()){
				  validationMsg = new ArrayList<String>();
				 configTemplateDto = new ConfigTemplateDto();
				/* if(selectedScopeDto.getIsMasterData() != null && selectedScopeDto.getIsMasterData().equalsIgnoreCase("Y")){//Skip Master data
					// if(fileUploadCustomDto.getCurrentFileList().size()==fileUploadCustomDto.getSelectedScopeList().size())
					 if(fileUploadCustomDto.getCurrentFileList().contains(selectedScopeDto.getFileName())){
						 validationMsg.add("Config Template Uploaded Successfully..");
						 selectedScopeDto.setFileUploadStatusMsg(validationMsg);
					 }
					 configTemplateDto.setSelectedScopeDto(selectedScopeDto);
					 configTemplateDto.setStatus(true);
					 configTemplateDto.setStatusMsg("Master data validate");
					 configTempList.add(configTemplateDto);
					 continue;
				 }*/
				/* else if(selectedScopeDto.getIsMasterData() != null && selectedScopeDto.getIsMasterData().equalsIgnoreCase("N")){//Skip Master data
					// if(fileUploadCustomDto.getCurrentFileList().size()==fileUploadCustomDto.getSelectedScopeList().size())
					 if(fileUploadCustomDto.getCurrentFileList().contains(selectedScopeDto.getFileName())){
						 validationMsg.add("Config Template Uploaded Successfully..");
						 selectedScopeDto.setFileUploadStatusMsg(validationMsg);
						 slf4jLogger.info("inside n");
					 }
					 configTemplateDto.setSelectedScopeDto(selectedScopeDto);
					 configTemplateDto.setStatus(true);
					 configTemplateDto.setStatusMsg("Config Template is validated");
					 configTempList.add(configTemplateDto);
					 continue;
				 }*/
				if(!fileUploadCustomDto.getCurrentFileList().contains(selectedScopeDto.getFileName())){
					 configTemplateDto.setSelectedScopeDto(selectedScopeDto);
					 configTemplateDto.setStatus(true);
					 configTemplateDto.setStatusMsg("Template not request for recent upload");
					 configTempList.add(configTemplateDto);
					 continue; 
				 }
				 
				 else{
					 if(isValid)
					 {
						 viewList = null;
					 }
					 else{
						 viewList = imgViewMap.get(selectedScopeDto.getImgId());
						 //System.out.println("vielist "+viewList);
						 slf4jLogger.info("vielist "+viewList);
					 }
					 if(viewList != null){
						 slf4jLogger.info("inside view list");
						 configTemplateDto = excelFormatConvert.configFileValidationConsolidation(selectedScopeDto, viewList,roleType);//  Enable for Production
						 //configTemplateDto = excelFormatConvert.configFileValidation_Dev(selectedScopeDto, viewList);//  Enable for Production
						 if(!configTemplateDto.isStatus()){
							 configTemplateDto.getSelectedScopeDto().setFilepath("");
							 configTemplateDto.getSelectedScopeDto().setFileName("");
							 configTemplateDto.getSelectedScopeDto().setFileUploadedIcon("glyphicon glyphicon-remove");
							 configUploadResDto.setUploadStatus(false);
						 }
						 configTempList.add(configTemplateDto);
					 }else{
						 slf4jLogger.info("inside view list in else");
						 configUploadResDto.setUploadStatus(false);
						 	selectedScopeDto.setFilepath("");
							selectedScopeDto.setFileName("");
							selectedScopeDto.setFileUploadedIcon("glyphicon glyphicon-remove");
							validationMsg.add("The configuration view from the file does not exist in the tool's repository. Please verify the view name/ sheet name from the template uploaded");
							selectedScopeDto.setFileUploadStatusMsg(validationMsg);
							configTemplateDto.setSelectedScopeDto(selectedScopeDto);
							configTemplateDto.setStatus(false);
							configTemplateDto.setStatusMsg("The configuration view from the file does not exist in the tool's repository. Please verify the view name/ sheet name from the template uploaded");
							configTempList.add(configTemplateDto);
					 }
				 }
			 }

		 }catch (Exception e) {
			 viewList = fileUploadCustomDto.getCurrentFileList();
			 for(SelectedScopeDto selectedScopeDto: fileUploadCustomDto.getSelectedScopeList()){
				 validationMsg = new ArrayList<String>();
				 if(viewList.contains(selectedScopeDto.getFileName())){
					 configUploadResDto.setUploadStatus(false);
					 selectedScopeDto.setFilepath("");
					 selectedScopeDto.setFileName("");
					 selectedScopeDto.setFileUploadedIcon("glyphicon glyphicon-remove");
					 validationMsg.add("The configuration view from the file does not exist in the tool's repository. Please verify the view name/ sheet name from the template uploaded");
					 selectedScopeDto.setFileUploadStatusMsg(validationMsg);
					 configTemplateDto.setSelectedScopeDto(selectedScopeDto);
					 configTemplateDto.setStatus(false);
					 configTemplateDto.setStatusMsg("Exception occured on service. Please check that");
					 configTempList.add(configTemplateDto);
					 
				 }else{
					 configTemplateDto.setSelectedScopeDto(selectedScopeDto);
					 configTemplateDto.setStatus(true);
					 configTemplateDto.setStatusMsg("Template not request for recent upload ");
					 configTempList.add(configTemplateDto);
				 }
			 }			 
		}finally {
			 imgHierarchyDao = null;
			 imgIDList = null;
			 imgViewMap = null;
			 excelFormatConvert = null;
			 viewList = null;
			 validationMsg = null;
		}
		 		
		 configUploadResDto.setConfigTemplateDto(configTempList);
		 return  Response.ok()
				.header("Cache-Control", "No-cache")
			    .header("X-FRAME-OPTIONS", "Deny")
			    .header("X-Content-Type-Options", "nosniff")
			    .header("Content-Security-Policy",
				"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
			    .header("X-XSS-Protection", "1")
			    .entity(configUploadResDto).build();
				 
	  }
	 
		 else{
			 ResMessageDto resMessageDto = new ResMessageDto();
			 resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			 resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			 configUploadResDto.setResMessageDto(resMessageDto);
			 return  Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity(configUploadResDto).build();
		 }
		 
		 }
		  catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("configTemplateUploadValidationConsolidation service ended");
		  }
	 }
}
