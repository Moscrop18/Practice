 package com.acn.rpa.service;


import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.imghierarchy.ClientImgHierarchyDAO;
import com.acn.rpa.imghierarchy.ClientImgResponseDto;
import com.acn.rpa.imghierarchy.CustomProjectDto;
import com.acn.rpa.imghierarchy.IndustryResponseDto;
import com.acn.rpa.imghierarchy.InputClientImgHierarchyDto;
import com.acn.rpa.imghierarchy.IndustryDto;
import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.RoleValidationDto;
import com.acn.user.session.CustomerInputDto;
import com.acn.user.session.IMGPreviewDto;
import com.acn.user.session.ResMessageDto;
import com.acn.user.session.UserSessionDao;

@Path("clientImgHierarchySrv") 
public class ClientImgHierarchySrv {     
    private final Logger slf4jLogger = LoggerFactory.getLogger(ClientImgHierarchySrv.class);

	  @Path("clientImgHierarchy")  
	  @POST
	  @Consumes(MediaType.APPLICATION_JSON)
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response clientImgHierarchy (@Valid InputClientImgHierarchyDto inputClientImgHierarchyObj) { 
		  slf4jLogger.info("clientImgHierarchy service started");
		  List<String> roleIdList = new ArrayList<>();
		  roleIdList.add(ConstantsValues.PROJECTADMIN);
		  roleIdList.add(ConstantsValues.TOOLADMIN);
		  RoleValidationDto roleValidationDto = new RoleValidationDto();
		  roleValidationDto.setRoleIdList(roleIdList);
		  roleValidationDto.setOmId(inputClientImgHierarchyObj.getOmId());
		 try{
		  if(UserSessionDao.isSessionActive(inputClientImgHierarchyObj.getSessionInputDTO(),roleValidationDto)){	
			  	ClientImgHierarchyDAO imgHierarchyDAOObj = new ClientImgHierarchyDAO();
				 ClientImgResponseDto clientimgResponseDto;
				 if(inputClientImgHierarchyObj.getSelectedArea()!=null && inputClientImgHierarchyObj.getSelectedArea().equalsIgnoreCase("Industry")) {
					 clientimgResponseDto = imgHierarchyDAOObj.insertClientImgHierarchyData(inputClientImgHierarchyObj);
				 }
				 else {
					 clientimgResponseDto = imgHierarchyDAOObj.insertClientImgHierarchyData(inputClientImgHierarchyObj);
				 }
				 
				 return   Response.ok()
						  .header("Cache-Control", "No-cache")
						  .header("X-FRAME-OPTIONS", "Deny")
						  .header("X-Content-Type-Options", "nosniff")
						  .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						  .header("X-XSS-Protection", "1")
						  .entity(clientimgResponseDto).build();
						 	  
		  }else{
			  ClientImgResponseDto clientImgResponseDto = new ClientImgResponseDto();
			  ResMessageDto resMessageDto = new ResMessageDto();	
			  clientImgResponseDto.setResMessageDto(resMessageDto);
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return  Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity(clientImgResponseDto).build();
					  
		  }
		 }
		  catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("clientImgHierarchy service ended");
		  }
		}
	   
	  
	  @Path("viewClientImgHierarchyConsolidation")  
	  @POST
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response viewClientImgHierarchyConsolidation(@Valid IMGPreviewDto dto) {
		  slf4jLogger.info("viewClientImgHierarchyConsolidation service started");
		  List<String> roleIdList = new ArrayList<>();
		  roleIdList.add(ConstantsValues.TOOLADMIN);
		  roleIdList.add(ConstantsValues.PROJECTADMIN);
		  roleIdList.add(ConstantsValues.CONFIG);
		  RoleValidationDto roleValidationDto = new RoleValidationDto();
		  roleValidationDto.setRoleIdList(roleIdList);
		  roleValidationDto.setOmId(dto.getSelectedOmid());
		  try{
		  if(UserSessionDao.isSessionActive(dto.getSessionInputDTO(),roleValidationDto)){	
			  ClientImgHierarchyDAO imgHierarchyDAOObj = new ClientImgHierarchyDAO();
			 	return   Response.ok()
						  .header("Cache-Control", "No-cache")
						  .header("X-FRAME-OPTIONS", "Deny")
						  .header("X-Content-Type-Options", "nosniff")
						  .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						  .header("X-XSS-Protection", "1")
						  .entity(imgHierarchyDAOObj.viewClientImgHierarchyForConsolidation(dto.getSelectedOmid())).build();
			 					  
		  }else{
			  ClientImgResponseDto clientImgResponseDto = new ClientImgResponseDto();
			  ResMessageDto resMessageDto = new ResMessageDto();	
			  clientImgResponseDto.setResMessageDto(resMessageDto);
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return   Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity(clientImgResponseDto).build();
					  
		  } 
		  }
		  catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("viewClientImgHierarchyConsolidation service ended");
		  }
	 }


	  @Path("previewClientImgHierarchy")  
	  @POST
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response previewImgHierarchy (@Valid IMGPreviewDto dto) {
		  slf4jLogger.info("previewClientImgHierarchy service started");
		  List<String> roleIdList = new ArrayList<>();
		  roleIdList.add(ConstantsValues.PROJECTADMIN);
		  roleIdList.add(ConstantsValues.TOOLADMIN);
		  RoleValidationDto roleValidationDto = new RoleValidationDto();
		  roleValidationDto.setRoleIdList(roleIdList);
		  roleValidationDto.setOmId(dto.getSelectedOmid());
		 try{
		  if(UserSessionDao.isSessionActive(dto.getSessionInputDTO(),roleValidationDto)){	
			  ClientImgHierarchyDAO imgHierarchyDAOObj = new ClientImgHierarchyDAO();
			 	return  Response.ok()
						  .header("Cache-Control", "No-cache")
						  .header("X-FRAME-OPTIONS", "Deny")
						  .header("X-Content-Type-Options", "nosniff")
						  .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						  .header("X-XSS-Protection", "1")
						  .entity(imgHierarchyDAOObj.previewClientImgHierarchy(dto.getSelectedOmid(),dto.getSelectedArea())).build();
			 					  
		  }else{
			  ClientImgResponseDto clientImgResponseDto = new ClientImgResponseDto();
			  ResMessageDto resMessageDto = new ResMessageDto();	
			  clientImgResponseDto.setResMessageDto(resMessageDto);
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return   Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity(clientImgResponseDto).build();
					  
		  }
		 }
		  catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("previewClientImgHierarchy service ended");
		  }
	 }
	  @Path("previewClientImgHierarchyCopyFuctionality")  
	  @POST
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response previewImgHierarchyCopyFunctionality(@Valid IMGPreviewDto dto) {
		  slf4jLogger.info("previewClientImgHierarchy service started");
		  List<String> roleIdList = new ArrayList<>();
		  roleIdList.add(ConstantsValues.PROJECTADMIN);
		  roleIdList.add(ConstantsValues.TOOLADMIN);
		  RoleValidationDto roleValidationDto = new RoleValidationDto();
		  roleValidationDto.setRoleIdList(roleIdList);
		  roleValidationDto.setOmId(dto.getSelectedOmid());
		 try{
		  if(UserSessionDao.isSessionActive(dto.getSessionInputDTO(),roleValidationDto)){	
			  ClientImgHierarchyDAO imgHierarchyDAOObj = new ClientImgHierarchyDAO();
			 	return  Response.ok()
						  .header("Cache-Control", "No-cache")
						  .header("X-FRAME-OPTIONS", "Deny")
						  .header("X-Content-Type-Options", "nosniff")
						  .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						  .header("X-XSS-Protection", "1")
						  .entity(imgHierarchyDAOObj.previewClientImgHierarchy(dto.getSelectedOmid(),dto.getSelectedArea())).build();
			 					  
		  }else{
			  ClientImgResponseDto clientImgResponseDto = new ClientImgResponseDto();
			  ResMessageDto resMessageDto = new ResMessageDto();	
			  clientImgResponseDto.setResMessageDto(resMessageDto);
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return   Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity(clientImgResponseDto).build();
					  
		  }
		 }
		  catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("previewClientImgHierarchy service ended");
		  }
	 }
	  @Path("viewClientImgHierarchy")  
	  @POST
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response viewClientImgHierarchy (@Valid IMGPreviewDto dto) {
		  slf4jLogger.info("viewClientImgHierarchy service started");
		  List<String> roleIdList = new ArrayList<>();
		  roleIdList.add(ConstantsValues.TOOLADMIN);
		  roleIdList.add(ConstantsValues.PROJECTADMIN);
		  roleIdList.add(ConstantsValues.CONFIG);
		  RoleValidationDto roleValidationDto = new RoleValidationDto();
		  roleValidationDto.setRoleIdList(roleIdList);
		  roleValidationDto.setOmId(dto.getSelectedOmid());
		  try{
			  if(UserSessionDao.isSessionActive(dto.getSessionInputDTO(),roleValidationDto)){	
				  ClientImgHierarchyDAO imgHierarchyDAOObj = new ClientImgHierarchyDAO();
				 	return   Response.ok()
							  .header("Cache-Control", "No-cache")
							  .header("X-FRAME-OPTIONS", "Deny")
							  .header("X-Content-Type-Options", "nosniff")
							  .header("Content-Security-Policy",
								"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
							  .header("X-XSS-Protection", "1")
							  .entity(imgHierarchyDAOObj.viewClientImgHierarchy(dto)).build();
				 					  
			  }else{
			  ClientImgResponseDto clientImgResponseDto = new ClientImgResponseDto();
			  ResMessageDto resMessageDto = new ResMessageDto();	
			  clientImgResponseDto.setResMessageDto(resMessageDto);
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return   Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity(clientImgResponseDto).build();
					  
		  } 
		  }
		  catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("viewClientImgHierarchy service ended");
		  }
	 }
	  @Path("viewClientImgHierarchyForIndustry")  
	  @POST
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response viewClientImgHierarchyForIndustry (@Valid IMGPreviewDto dto) {
		  slf4jLogger.info("viewClientImgHierarchyForIndustry service started");
		  List<String> roleIdList = new ArrayList<>();
		  roleIdList.add(ConstantsValues.TOOLADMIN);
		  roleIdList.add(ConstantsValues.PROJECTADMIN);
		  roleIdList.add(ConstantsValues.CONFIG);
		  RoleValidationDto roleValidationDto = new RoleValidationDto();
		  roleValidationDto.setRoleIdList(roleIdList);
		  roleValidationDto.setOmId(dto.getSelectedOmid());
		  try{
			  if(UserSessionDao.isSessionActive(dto.getSessionInputDTO(),roleValidationDto)){	
				  ClientImgHierarchyDAO imgHierarchyDAOObj = new ClientImgHierarchyDAO();
				 	return   Response.ok()
							  .header("Cache-Control", "No-cache")
							  .header("X-FRAME-OPTIONS", "Deny")
							  .header("X-Content-Type-Options", "nosniff")
							  .header("Content-Security-Policy",
								"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
							  .header("X-XSS-Protection", "1")
							  .entity(imgHierarchyDAOObj.viewClientImgHierarchyForIndustry(dto)).build();
				 					  
			  }else{
			  ClientImgResponseDto clientImgResponseDto = new ClientImgResponseDto();
			  ResMessageDto resMessageDto = new ResMessageDto();	
			  clientImgResponseDto.setResMessageDto(resMessageDto);
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return   Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity(clientImgResponseDto).build();
					  
		  } 
		  }
		  catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("viewClientImgHierarchyForIndustry service ended");
		  }
	 }
	 @Path("viewClientImgHierarchyCopyFuntionality")  
	  @POST
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response viewClientImgHierarchyCopyFuntionality (@Valid IMGPreviewDto dto) {
		  slf4jLogger.info("viewClientImgHierarchy service started");
		  List<String> roleIdList = new ArrayList<>();
		  roleIdList.add(ConstantsValues.TOOLADMIN);
		  roleIdList.add(ConstantsValues.PROJECTADMIN);
		  roleIdList.add(ConstantsValues.CONFIG);
		  RoleValidationDto roleValidationDto = new RoleValidationDto();
		  roleValidationDto.setRoleIdList(roleIdList);
		  roleValidationDto.setOmId(dto.getSelectedOmid());
		  try{
		  if(UserSessionDao.isSessionActive(dto.getSessionInputDTO(),roleValidationDto)){	
			  ClientImgHierarchyDAO imgHierarchyDAOObj = new ClientImgHierarchyDAO();
			 	return   Response.ok()
						  .header("Cache-Control", "No-cache")
						  .header("X-FRAME-OPTIONS", "Deny")
						  .header("X-Content-Type-Options", "nosniff")
						  .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						  .header("X-XSS-Protection", "1")
						  .entity(imgHierarchyDAOObj.viewClientImgHierarchyforCopyFunctionality(dto.getSelectedOmid())).build();
			 					  
		  }else{
			  ClientImgResponseDto clientImgResponseDto = new ClientImgResponseDto();
			  ResMessageDto resMessageDto = new ResMessageDto();	
			  clientImgResponseDto.setResMessageDto(resMessageDto);
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return   Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity(clientImgResponseDto).build();
					  
		  } 
		  }
		  catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("viewClientImgHierarchy service ended");
		  }
	 }
	  @Path("viewClientBPHierarchyCopyFuntionality")  
	  @POST
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response viewClientBPHierarchyCopyFuntionality (@Valid IMGPreviewDto dto) {
		  slf4jLogger.info("viewClientImgHierarchy service started");
		  List<String> roleIdList = new ArrayList<>();
		  roleIdList.add(ConstantsValues.TOOLADMIN);
		  roleIdList.add(ConstantsValues.PROJECTADMIN);
		  roleIdList.add(ConstantsValues.CONFIG);
		  RoleValidationDto roleValidationDto = new RoleValidationDto();
		  roleValidationDto.setRoleIdList(roleIdList);
		  roleValidationDto.setOmId(dto.getSelectedOmid());
		  try{
		  if(UserSessionDao.isSessionActive(dto.getSessionInputDTO(),roleValidationDto)){	
			  ClientImgHierarchyDAO imgHierarchyDAOObj = new ClientImgHierarchyDAO();
			 	return   Response.ok()
						  .header("Cache-Control", "No-cache")
						  .header("X-FRAME-OPTIONS", "Deny")
						  .header("X-Content-Type-Options", "nosniff")
						  .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						  .header("X-XSS-Protection", "1")
						  .entity(imgHierarchyDAOObj.viewClientBPHierarchyforCopyFunctionality(dto.getSelectedOmid())).build();
			 					  
		  }else{
			  ClientImgResponseDto clientImgResponseDto = new ClientImgResponseDto();
			  ResMessageDto resMessageDto = new ResMessageDto();	
			  clientImgResponseDto.setResMessageDto(resMessageDto);
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return   Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity(clientImgResponseDto).build();
					  
		  } 
		  }
		  catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("viewClientImgHierarchy service ended");
		  }
	 }
	 
	  @Path("getCustomerId")  
	  @POST
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response getCustomerId(@Valid CustomerInputDto dto) {
		  slf4jLogger.info("getCustomerId service started");
		  List<String> roleIdList = new ArrayList<>();
		  roleIdList.add(dto.getUserRole());
		  RoleValidationDto roleValidationDto = new RoleValidationDto();
		  roleValidationDto.setRoleIdList(roleIdList);
		 try{
		  if(UserSessionDao.isSessionActive(dto.getSessionInputDTO(),roleValidationDto)){	
			  ClientImgHierarchyDAO imgHierarchyDAOObj = new ClientImgHierarchyDAO();
			 	CustomProjectDto customProjectDto = null;
			 	customProjectDto = imgHierarchyDAOObj.getCustomerId(dto);
				  return   Response.ok()
						  .header("Cache-Control", "No-cache")
						  .header("X-FRAME-OPTIONS", "Deny")
						  .header("X-Content-Type-Options", "nosniff")
						  .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						  .header("X-XSS-Protection", "1")
						  .entity(customProjectDto).build();
						  
		  }else{
			  CustomProjectDto customProjectDto = new CustomProjectDto();
			  ResMessageDto resMessageDto = new ResMessageDto();	
			  customProjectDto.setResMessageDto(resMessageDto);
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return   Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity(customProjectDto).build();
					  
		  } 
		 }
		  catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("getCustomerId service ended");
		  }
		 	
	 }
	  @Path("getIndustry")  
	  @POST
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response getIndustry(@Valid IndustryDto dto) {
		  slf4jLogger.info("getIndustry service started");
		  List<String> roleIdList = new ArrayList<>();
		  roleIdList.add(dto.getUserRole());
		  RoleValidationDto roleValidationDto = new RoleValidationDto();
		  roleValidationDto.setRoleIdList(roleIdList);
		  try {	
			  if(UserSessionDao.isSessionActive(dto.getSessionInputDTO(),roleValidationDto)){
			  ClientImgHierarchyDAO imgHierarchyDAOObj = new ClientImgHierarchyDAO();
			 	IndustryResponseDto industryDto = null;
			 	industryDto = imgHierarchyDAOObj.getIndustryId();
				  return   Response.ok()
						  .header("Cache-Control", "No-cache")
						  .header("X-FRAME-OPTIONS", "Deny")
						  .header("X-Content-Type-Options", "nosniff")
						  .header("Content-Security-Policy","default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						  .header("X-XSS-Protection", "1")
						  .entity(industryDto).build();
						  
		  }
			  else{
				  IndustryResponseDto  industryDto = new IndustryResponseDto();
				  ResMessageDto resMessageDto = new ResMessageDto();	
				  industryDto.setResMessageDto(resMessageDto);
				  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
				  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
				  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
				  return   Response.ok()
						  .header("Cache-Control", "No-cache")
						  .header("X-FRAME-OPTIONS", "Deny")
						  .header("X-Content-Type-Options", "nosniff")
						  .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						  .header("X-XSS-Protection", "1")
						  .entity(industryDto).build();
						  
			  } 
		  }
		  catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("getIndustry service ended");
		  }
		 	
	 }
	 
	 
	 

@Path("getSubIndustry")  
@POST
@Produces(MediaType.APPLICATION_JSON)
public Response getSubIndustry(@Valid IndustryDto dto) {
	  slf4jLogger.info("getSubIndustry service started");
	  List<String> roleIdList = new ArrayList<>();
	  roleIdList.add(dto.getUserRole());
	  RoleValidationDto roleValidationDto = new RoleValidationDto();
	  roleValidationDto.setRoleIdList(roleIdList);
	 
	  try {	
		  if(UserSessionDao.isSessionActive(dto.getSessionInputDTO(),roleValidationDto)){
		  ClientImgHierarchyDAO imgHierarchyDAOObj = new ClientImgHierarchyDAO();
		 	IndustryResponseDto industryDto = null;
		 	industryDto = imgHierarchyDAOObj.getSubIndustryId(dto) ;
			  return   Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy","default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity(industryDto).build();
					  
	  
		 
	  }else {
		  IndustryResponseDto  industryDto = new IndustryResponseDto();
		  ResMessageDto resMessageDto = new ResMessageDto();	
		  industryDto.setResMessageDto(resMessageDto);
		  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
		  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
		  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
		  return   Response.ok()
				  .header("Cache-Control", "No-cache")
				  .header("X-FRAME-OPTIONS", "Deny")
				  .header("X-Content-Type-Options", "nosniff")
				  .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				  .header("X-XSS-Protection", "1")
				  .entity(industryDto).build();
				  
	  }  
	  }catch(Exception e){
		  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		  return Response.ok()
				  .header("Cache-Control", "No-cache")
				  .header("X-FRAME-OPTIONS", "Deny")
				  .header("X-Content-Type-Options", "nosniff")
				  .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				  .header("X-XSS-Protection", "1")
				  .header("Server","Disable")
				  
				  .entity(ConstantsValues.EXCEPTION).build();

	  }finally{		
		slf4jLogger.info("getSubIndustry service ended");
	  }
	 	
}



}

