package com.acn.rpa.service;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.admin.AuthorizationMappingDAO;
import com.acn.rpa.admin.AuthorizationMappingInputDTO;
import com.acn.rpa.admin.AuthorizationMappingResDTO;
import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.RoleValidationDto;
import com.acn.user.session.ResMessageDto;
import com.acn.user.session.SessionInputDTO;
import com.acn.user.session.UserSessionDao;



@Path("authorizationSrv") 

public class AuthorizationDetailsSrv {
    private final Logger slf4jLogger = LoggerFactory.getLogger(AuthorizationDetailsSrv.class);

	  @Path("getAuthorizationIds")
	  @POST
	  @Consumes({MediaType.APPLICATION_JSON})
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response displayCustomers(@Valid AuthorizationMappingInputDTO inputDTO){
		  slf4jLogger.info("getAuthorizationIds service started");
		 try{
			  List<String> roleIdList = new ArrayList<>();
		  	  roleIdList.add(ConstantsValues.PROJECTADMIN);
		  	  roleIdList.add(ConstantsValues.TOOLADMIN);
		  	roleIdList.add(ConstantsValues.TEMPAD);
		  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
		  	  roleValidationDto.setRoleIdList(roleIdList);
		  if(UserSessionDao.isSessionActive(inputDTO.getSessionInputDTO(),roleValidationDto)){	
			  AuthorizationMappingResDTO  authorizationMappingResDTO = new AuthorizationMappingResDTO();
			  AuthorizationMappingDAO authorizationMappingDAO = new AuthorizationMappingDAO();
			  authorizationMappingResDTO = authorizationMappingDAO.getAuthorizedActionids(inputDTO);
			  return   Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity(authorizationMappingResDTO).build();
					    
		  }else{
			  AuthorizationMappingResDTO  authorizationMappingResDTO = new AuthorizationMappingResDTO();
			  ResMessageDto resMessageDto = new ResMessageDto();	
			  authorizationMappingResDTO.setResMessageDto(resMessageDto);
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return   Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity(authorizationMappingResDTO).build();					  
		  }
		 }catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("getAuthorizationIds service ended");
		  }

	  }
	  

	 /* public Response displayCustomers(@Valid SessionInputDTO inputDTO){
		  slf4jLogger.info("getAuthorizationIds service started");
		 try{
			  List<String> roleIdList = new ArrayList<>();
		  	  roleIdList.add(ConstantsValues.PROJECTADMIN);
		  	  roleIdList.add(ConstantsValues.TOOLADMIN);
		  	roleIdList.add(ConstantsValues.TEMPAD);
		  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
		  	  roleValidationDto.setRoleIdList(roleIdList);
		  if(UserSessionDao.isSessionActive(inputDTO,roleValidationDto)){	
			  AuthorizationMappingResDTO  authorizationMappingResDTO = new AuthorizationMappingResDTO();
			  AuthorizationMappingDAO authorizationMappingDAO = new AuthorizationMappingDAO();
			  authorizationMappingResDTO = authorizationMappingDAO.getAuthorizedActionids(inputDTO);
			  return   Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity(authorizationMappingResDTO).build();
					    
		  }else{
			  AuthorizationMappingResDTO  authorizationMappingResDTO = new AuthorizationMappingResDTO();
			  ResMessageDto resMessageDto = new ResMessageDto();	
			  authorizationMappingResDTO.setResMessageDto(resMessageDto);
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return   Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity(authorizationMappingResDTO).build();					  
		  }
		 }catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("getAuthorizationIds service ended");
		  }

	  }
*/
}
