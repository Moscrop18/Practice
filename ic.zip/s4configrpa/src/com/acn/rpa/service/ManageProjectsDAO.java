package com.acn.rpa.service;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.admin.ManageProjectsDto;
import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.DBConnection;
import com.acn.rpa.utilities.PropMappings;
import com.acn.user.session.ResMessageDto;

public class ManageProjectsDAO {
	
    private final Logger slf4jLogger = LoggerFactory.getLogger(ManageProjectsDAO.class);

	public ResMessageDto assignProjectsToUser(List<ManageProjectsDto> listManageProjects)   { 
		slf4jLogger.info("assignProjectsToUser method started");
		ResMessageDto resMessageDto = new ResMessageDto();
		List<String> listExistingProjects = null;
		listExistingProjects = checkProjectUserExists(listManageProjects);
		boolean flag = false;
		PreparedStatement preparedStmt =  null; 
		Connection con = null;
		String query="INSERT INTO USERPROJECTS(USERID,OMID,PROJECTNAME,STATUS,TIMESTAMP) VALUES(?,?,?,?,?)";
		try{
			con =  DBConnection.createConnection();
			preparedStmt = con.prepareStatement(query);
			Timestamp timestamp = new Timestamp(System.currentTimeMillis());
			
    		for(ManageProjectsDto manageProjectsDtoObj:listManageProjects){
    			preparedStmt.setString (1, manageProjectsDtoObj.getUserId());
    			preparedStmt.setString (2, manageProjectsDtoObj.getOmId());
    			preparedStmt.setString (3, manageProjectsDtoObj.getProjectName());
    			preparedStmt.setString (4, "Active");
    			preparedStmt.setTimestamp (5, timestamp);
    			if(!listExistingProjects.contains(manageProjectsDtoObj.getOmId()+manageProjectsDtoObj.getUserId()+manageProjectsDtoObj.getProjectName()))
    				preparedStmt.addBatch();
    			else
    				flag = true;
    			}
    		preparedStmt.executeBatch();
    		resMessageDto.setMsgType(ConstantsValues.SUCCESSSTATUS);
    		if(flag)
    			resMessageDto.setMessage("User already mapped to this project");
    		else
    			resMessageDto.setMessage("Successfully assigned Projects to Users");

			} catch (Exception e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			}finally {
				if (preparedStmt != null) {
		            try {
		            	preparedStmt.close();
		            	preparedStmt = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }

		        if (con != null) {
		            try {
		            	con.close();
		            	con = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
				slf4jLogger.info("assignProjectsToUser method ended");

			}
		return resMessageDto;
	}
	
	public ResMessageDto unAssignProjectsToUser(List<ManageProjectsDto> listManageProjects)   { 
		slf4jLogger.info("unAssignProjectsToUser method started");
		ResMessageDto resMessageDto = new ResMessageDto();
		PreparedStatement preparedStmt =  null; 
		Connection con = null;
		String query="DELETE FROM USERPROJECTS WHERE USERID = ? AND OMID = ? AND PROJECTNAME = ?";
		try{
			con =  DBConnection.createConnection();
			preparedStmt = con.prepareStatement(query);
			
    		for(ManageProjectsDto manageProjectsDtoObj:listManageProjects){
    			preparedStmt.setString (1, manageProjectsDtoObj.getUserId());
    			preparedStmt.setString (2, manageProjectsDtoObj.getOmId());
    			preparedStmt.setString (3, manageProjectsDtoObj.getProjectName());
    			preparedStmt.addBatch();
    			}
    		
    		preparedStmt.executeBatch();
    		resMessageDto.setMsgType(ConstantsValues.SUCCESSSTATUS);
    		resMessageDto.setMessage("Successfully UnAssigned Projects for the selected User");

			} catch (Exception e) {
            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				resMessageDto.setMessage(ConstantsValues.ERRORSTATUS);
			}finally {
				if (preparedStmt != null) {
		            try {
		            	preparedStmt.close();
		            	preparedStmt = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }

		        if (con != null) {
		            try {
		            	con.close();
		            	con = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
				  slf4jLogger.info("unAssignProjectsToUser method ended");

				
			}
		return resMessageDto;
	}
	
	public List<String>  checkProjectUserExists(List<ManageProjectsDto> listManageprojects){
		slf4jLogger.info("checkProjectUserExists method started");
		ManageProjectsDto responseDtoObj = new ManageProjectsDto();
		int length = listManageprojects.size();
		ArrayList<String> existingProjectDetais = new ArrayList<String>();
		PreparedStatement preparedStmt =  null;
		Connection con = null;
		ResultSet rs = null;
	
	  	String dbName = null;
	  	StringBuilder query = new StringBuilder();
		
		try{
	    	PropMappings propObj = PropMappings.getInstance();

			dbName = propObj.getValue("S4CONFIGHANA_DB");
			if(dbName.equals("SAPHANA"))
				query = new StringBuilder("SELECT OMID||USERID||PROJECTNAME PROJECTNAMES FROM  USERPROJECTS WHERE OMID||USERID||PROJECTNAME  in (");
			else
				query = new StringBuilder("SELECT CONCAT(OMID,USERID,PROJECTNAME) PROJECTNAMES FROM  USERPROJECTS WHERE CONCAT(OMID,USERID,PROJECTNAME) in (");

			for(int i=0;i<length;i++){
				if(i==length-1)
					query.append("?)");
				else
					query.append("?,");			
			}

			con =  DBConnection.createConnection();
			preparedStmt = con.prepareStatement(query.toString());
			int pos = 1;		
			for(int i=0;i<length;i++,pos++){
				preparedStmt.setString (pos, listManageprojects.get(i).getOmId()+listManageprojects.get(i).getUserId()+listManageprojects.get(i).getProjectName());				
			}
			rs = preparedStmt.executeQuery();
			while(rs.next()){
				existingProjectDetais.add(rs.getString("PROJECTNAMES"));
				}
			}catch(SQLException e){
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			} catch (Exception e) {
				responseDtoObj.setStatus(ConstantsValues.ERRORSTATUS);
				responseDtoObj.setMessage("Not able to change the customer status as inactive ,please contact the Administrator!");
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}finally {
				
					 
					 query = null;
				
				
				if (preparedStmt != null) {
		            try {
		            	preparedStmt.close();
		            	preparedStmt = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }

		        if (con != null) {
		            try {
		            	con.close();
		            	con = null;
		            } catch (SQLException e) {
		            	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		            }
		        }
				  slf4jLogger.info("checkProjectUserExists method ended");

			}

		responseDtoObj.setStatus(ConstantsValues.SUCCESSSTATUS);
		return existingProjectDetais;
	}
	
	

}
