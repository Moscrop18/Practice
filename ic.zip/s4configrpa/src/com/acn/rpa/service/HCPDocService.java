package com.acn.rpa.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.chemistry.opencmis.client.api.Session;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.docservice.HCPDocDAO;
import com.acn.rpa.docservice.TempUpdateInfoDto;
import com.acn.rpa.docservice.TempUpdateResDto;
import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.DBConnection;
import com.acn.rpa.utilities.PropMappings;
import com.acn.rpa.utilities.RoleValidationDto;
import com.acn.user.session.ResMessageDto;
import com.acn.user.session.SessionInputDTO;
import com.acn.user.session.UserSessionDao;
@Path("HCPDocService") 
public class HCPDocService {
    private final Logger slf4jLogger = LoggerFactory.getLogger(AdminService.class);

	@Path("templateUpdateInfo")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
    public Response templateUpdateInfo(@Valid SessionInputDTO sessionInputDTO){
		slf4jLogger.info("templateUpdateInfo service started");
		try{
		TempUpdateResDto tempUpdateResDto = new TempUpdateResDto();
		TempUpdateInfoDto tempUpdateInfoDto; 
		ArrayList<TempUpdateInfoDto> templateList = new ArrayList<>();
		Connection con = null;
		ResultSet rs=null;			
		PreparedStatement ps=null;
		Document document=null;
		InputStream stream = null;
		ByteArrayOutputStream bos = null;
	    XSSFWorkbook workbook = null;
		byte[] bytes  = null;
		PropMappings propObj = PropMappings.getInstance();
		List<String> roleIdList = new ArrayList<>();
		roleIdList.add(ConstantsValues.CONFIG);
		RoleValidationDto roleValidationDto = new RoleValidationDto();
		roleValidationDto.setRoleIdList(roleIdList);
		if(UserSessionDao.isSessionActive(sessionInputDTO,roleValidationDto)){
			try{
				con =  DBConnection.createConnection();
				if(propObj.getValue("S4CONFIGHANA_DB").equals("SAPHANA")){
					ps =  con.prepareStatement("SELECT * FROM (select ID, FILENAME, to_char(RECORDED_DATE, 'dd-mon-yyyy') updated_Date,DAYS_BETWEEN(RECORDED_DATE,NOW()) DAYS FROM DOCUMENTSTORE where templatetype=?) AS Main WHERE DAYS<=? ORDER BY updated_Date Desc");
					ps.setString(1,"BASE");
					ps.setInt(2, 15);
		    	}
		    	else{
		    		ps =  con.prepareStatement("SELECT * FROM (SELECT ID, FILENAME,date(RECORDED_DATE) updated_Date,DATEDIFF(NOW(),RECORDED_DATE) DAYS FROM DOCUMENTSTORE) AS Main WHERE DAYS<=?");
		    		ps.setInt(1, 15);
		    		}		
				rs = ps.executeQuery();
				while(rs.next()){
					bos = new ByteArrayOutputStream();
					Session openCmisSession = HCPDocDAO.ConnectDocumentStore();
					document = (Document) openCmisSession.getObject(rs.getString("ID"));
					stream = document.getContentStream().getStream();
					workbook = new XSSFWorkbook(stream);
					workbook.write(bos);
					bytes = bos.toByteArray();	
					tempUpdateInfoDto = new TempUpdateInfoDto();
					tempUpdateInfoDto.setSeqID(rs.getString("FILENAME").split("_")[0]);
					tempUpdateInfoDto.setImgDescr(rs.getString("FILENAME").split("_")[1]);
					tempUpdateInfoDto.setUpdatedDate(rs.getString("updated_Date"));
					tempUpdateInfoDto.setBytes(bytes);
					templateList.add(tempUpdateInfoDto);
				}
				tempUpdateResDto.setTemplateList(templateList);			
				if(templateList.isEmpty()){
					tempUpdateResDto.setStatus(ConstantsValues.ERRORSTATUS);
				}
				else{
					tempUpdateResDto.setStatus(ConstantsValues.SUCCESSSTATUS);
					tempUpdateResDto.setMessage(ConstantsValues.GOLDENTEMPNOTIFY);
				}
				if(rs!=null){
					try {
						rs.close();
						rs=null;
						} catch (SQLException e) {
						slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
					}
				}
				if(ps!=null){
					try {
						ps.close();
						ps=null;
						} catch (SQLException e) {
						slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
					}
				}
			}catch (Exception e){
			tempUpdateResDto.setMessage(ConstantsValues.GOLDENTEMPNOTIFYERROR);
			tempUpdateResDto.setStatus(ConstantsValues.ERRORSTATUS);
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		} 
		finally{
			try {
				if(bos!= null){
				bos.close();
				}
				if(workbook != null)
				workbook.close();
				if(stream != null)
					stream.close();
			} catch (IOException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
			bos = null;
			workbook = null;
			document = null;
			bytes = null;
			if(rs!=null){
				try {
					rs.close();
					rs=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}

		
			if(ps!=null){
				try {
					ps.close();
					ps=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
			if(con!=null){
				try {
					con.close();
					con=null;
					} catch (SQLException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
			}
		}
			return  Response.ok()
					.header("Cache-Control", "No-cache")
				    .header("X-FRAME-OPTIONS", "Deny")
				    .header("X-Content-Type-Options", "nosniff")
				    .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				    .header("X-XSS-Protection", "1")
				    .entity(tempUpdateResDto).build();
					
		}
		else{
			 ResMessageDto resMessageDto = new ResMessageDto();
			 resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			 slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			 resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			 tempUpdateResDto.setResMessageDto(resMessageDto);
			 return  Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity(tempUpdateResDto).build();
		}
		
		}catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("templateUpdateInfo service ended");
		  }
	}
}