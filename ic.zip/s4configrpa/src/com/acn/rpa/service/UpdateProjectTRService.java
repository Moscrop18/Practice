package com.acn.rpa.service;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.imghierarchy.UpdateProjectTRDAO;
import com.acn.rpa.imghierarchy.UpdateProjectTRDto;
import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.RoleValidationDto;
import com.acn.user.session.ResMessageDto;
import com.acn.user.session.UserSessionDao;



@Path("/updateProject")
public class UpdateProjectTRService {
    private final Logger slf4jLogger = LoggerFactory.getLogger(UpdateProjectTRService.class);

	 @Path("/updateProjectTR")
	 @Consumes({MediaType.APPLICATION_JSON})
	 @POST
	 @Produces(MediaType.APPLICATION_JSON)
	 public Response editClientTREntry(@Valid UpdateProjectTRDto updateProjectTRDto){
		  slf4jLogger.info("updateProjectTR service started");
		  List<String> roleIdList = new ArrayList<>();
	  	  roleIdList.add(ConstantsValues.PROJECTADMIN);
	  	  roleIdList.add(ConstantsValues.TOOLADMIN);
	  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	  roleValidationDto.setRoleIdList(roleIdList);
		  roleValidationDto.setOmId(updateProjectTRDto.getOmid());
		  try{
		  if(UserSessionDao.isSessionActive(updateProjectTRDto.getSessionInputDTO(),roleValidationDto)){	
			  UpdateProjectTRDAO updateProjectTRDAO= new UpdateProjectTRDAO();
				 return   Response.ok()
							.header("Cache-Control", "No-cache")
						    .header("X-FRAME-OPTIONS", "Deny")
						    .header("X-Content-Type-Options", "nosniff")
						    .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						    .header("X-XSS-Protection", "1")
						    .entity( updateProjectTRDAO.updateTROverRide(updateProjectTRDto)).build();
								  
		  }else{
			  ResMessageDto resMessageDto = new ResMessageDto();	
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return  Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity( resMessageDto).build();
					 
		  }
		 
		  }catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("updateProjectTR service ended");
		  } 
	 }
	 
	 
}
