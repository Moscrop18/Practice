package com.acn.rpa.service;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.admin.SystemDAO;
import com.acn.rpa.admin.SystemDTO;
import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.RoleValidationDto;
import com.acn.user.session.CustomInputDto;
import com.acn.user.session.CustomResDto;
import com.acn.user.session.CustomerInputDto;
import com.acn.user.session.ResMessageDto;
import com.acn.user.session.SessionInputDTO;
import com.acn.user.session.SysInputDto;
import com.acn.user.session.SystemResDto;
import com.acn.user.session.UserSessionDao;

@Path("/configSrv") 
public class SystemService { 

    private final Logger slf4jLogger = LoggerFactory.getLogger(SystemService.class);

	@POST
	@Path("/displayAll")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getConfigs(@Valid CustomerInputDto customerInputDto) {
		  slf4jLogger.info("displayAll service started");
		  List<String> roleIdList = new ArrayList<>();
	  	  roleIdList.add(ConstantsValues.PROJECTADMIN);
	  	  roleIdList.add(ConstantsValues.TOOLADMIN);
	  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	  roleValidationDto.setRoleIdList(roleIdList);
		  try{
			  if(UserSessionDao.isSessionActive(customerInputDto.getSessionInputDTO(),roleValidationDto)){
				  SystemDAO eccConfigDAO = new SystemDAO();
					 return Response.ok()
								.header("Cache-Control", "No-cache")
							    .header("X-FRAME-OPTIONS", "Deny")
							    .header("X-Content-Type-Options", "nosniff")
							    .header("Content-Security-Policy",
								"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
							    .header("X-XSS-Protection", "1")
							    .entity(eccConfigDAO.getAllConfigs(customerInputDto)).build();
							   
			  }else{
				  SystemResDto resDto = new SystemResDto();
				  ResMessageDto resMessageDto = new ResMessageDto();	
				  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
				  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
				  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
				  resDto.setResMessageDto(resMessageDto);
				  return  Response.ok()
							.header("Cache-Control", "No-cache")
						    .header("X-FRAME-OPTIONS", "Deny")
						    .header("X-Content-Type-Options", "nosniff")
						    .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						    .header("X-XSS-Protection", "1")
						    .entity(resDto).build();
			}
		  }catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("displayAll service ended");
		  }

	}
	
	
	@POST
	@Path("/add")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response addConfig(@Valid SystemDTO systemDto) {
		 slf4jLogger.info("add service started");
		 List<String> roleIdList = new ArrayList<>();
	  	  roleIdList.add(ConstantsValues.PROJECTADMIN);
	  	  roleIdList.add(ConstantsValues.TOOLADMIN);
	  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	  roleValidationDto.setRoleIdList(roleIdList);
		  roleValidationDto.setOmId(systemDto.getOmId());
		try{
		if(UserSessionDao.isSessionActive(systemDto.getSessionInputDTO(),roleValidationDto)){
			  SystemDAO eccConfigDAO = new SystemDAO();
			  return Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity(eccConfigDAO.addConfig(systemDto)).build();
					  	  
		  }else{
			  ResMessageDto resMessageDto = new ResMessageDto();	
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return Response.ok()
				.header("Cache-Control", "No-cache")
			    .header("X-FRAME-OPTIONS", "Deny")
			    .header("X-Content-Type-Options", "nosniff")
			    .header("Content-Security-Policy",
				"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
			    .header("X-XSS-Protection", "1")
			    .entity(resMessageDto).build();
					  
		  }
		}catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("add service ended");
		  }
	}
	

	@POST
	@Path("/cloneSystem")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response cloneSystem(@Valid SystemDTO systemDto) {
		 slf4jLogger.info("cloneSystem service started");
		 List<String> roleIdList = new ArrayList<>();
	  	  roleIdList.add(ConstantsValues.PROJECTADMIN);
	  	  roleIdList.add(ConstantsValues.TOOLADMIN);
	  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	  roleValidationDto.setRoleIdList(roleIdList);
		  roleValidationDto.setOmId(systemDto.getOmId());
		try{
		if(UserSessionDao.isSessionActive(systemDto.getSessionInputDTO(),roleValidationDto)){
			  SystemDAO eccConfigDAO = new SystemDAO();
			  return Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity( eccConfigDAO.cloneSystem(systemDto)).build();
					 	  
		  }else{
			  ResMessageDto resMessageDto = new ResMessageDto();	
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity(resMessageDto).build();
		 }
		}catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("cloneSystem service ended");
		  }

	}
	
	
	@PUT
	@Path("update")
	@Produces(MediaType.APPLICATION_JSON)
	public Response updateConfig(@Valid SystemDTO systemDto) {
	 slf4jLogger.info("update service started");
	 List<String> roleIdList = new ArrayList<>();
 	  roleIdList.add(ConstantsValues.PROJECTADMIN);
 	  roleIdList.add(ConstantsValues.TOOLADMIN);
 	  RoleValidationDto roleValidationDto = new RoleValidationDto();
 	  roleValidationDto.setRoleIdList(roleIdList);
	  roleValidationDto.setOmId(systemDto.getOmId());
		try{
		if(UserSessionDao.isSessionActive(systemDto.getSessionInputDTO(),roleValidationDto)){
			  SystemDAO eccConfigDAO = new SystemDAO();
			  return  Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity(eccConfigDAO.updateConfig(systemDto)).build();
					   
		  }else{
			  ResMessageDto resMessageDto = new ResMessageDto();	
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return  Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity(resMessageDto).build();
		  }
		}catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("update service ended");
		  }
	}
	
	
	@PUT
	@Path("delete")
	@Produces(MediaType.APPLICATION_JSON)
	public Response deleteConfig(@Valid CustomInputDto customInputDto) {
		slf4jLogger.info("delete service started");
		List<String> roleIdList = new ArrayList<>();
	  	  roleIdList.add(ConstantsValues.PROJECTADMIN);
	  	  roleIdList.add(ConstantsValues.TOOLADMIN);
	  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	  roleValidationDto.setRoleIdList(roleIdList);
		try{
		if(UserSessionDao.isSessionActive(customInputDto.getSessionInputDTO(),roleValidationDto)){
			  SystemDAO eccConfigDAO = new SystemDAO();
			  return  Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity( eccConfigDAO.removeConfig(customInputDto.getDataList())).build();
					 	  
		  }else{
			  ResMessageDto resMessageDto = new ResMessageDto();	
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return  Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity(resMessageDto).build();
		  }
		}catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("delete service ended");
		  }

	}
	
	@POST
	@Path("getSourceTargetDetails")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getSourceTargetDetails(@Valid SysInputDto sysInputDto) {
		slf4jLogger.info("getSourceTargetDetails service started");
		List<String> roleIdList = new ArrayList<>();
	  	  roleIdList.add(ConstantsValues.PROJECTADMIN);
	  	  roleIdList.add(ConstantsValues.TOOLADMIN);
	  	  roleIdList.add(ConstantsValues.CONFIG);
	  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	  roleValidationDto.setRoleIdList(roleIdList);
		  roleValidationDto.setOmId(sysInputDto.getOmID());
		try{
		if(UserSessionDao.isSessionActive(sysInputDto.getSessionInputDTO(),roleValidationDto)){
			  SystemDAO eccConfigDAO = new SystemDAO();
			  return Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity( eccConfigDAO.getSourceTargetDetails(sysInputDto)).build();
					 
		  }else{
			  SystemResDto resDto = new SystemResDto();
			  ResMessageDto resMessageDto = new ResMessageDto();	
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return  Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity( resDto).build();
					 
		  }
		
		}catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("getSourceTargetDetails service ended");
		  }
	}
	
	
	 @Path("displayTargetSystems")
	 @POST
	 @Produces(MediaType.APPLICATION_JSON)
	 public Response displayTargetSystems(@Valid SysInputDto sysInputDto){
		slf4jLogger.info("displayTargetSystems service started");
		List<String> roleIdList = new ArrayList<>();
	  	  roleIdList.add(ConstantsValues.PROJECTADMIN);
	  	  roleIdList.add(ConstantsValues.TOOLADMIN);
	  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	  roleValidationDto.setRoleIdList(roleIdList);
		  roleValidationDto.setOmId(sysInputDto.getOmID());
		try{
		if(UserSessionDao.isSessionActive(sysInputDto.getSessionInputDTO(),roleValidationDto)){
			  SystemDAO eccConfigDAO = new SystemDAO();
			  return Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity(eccConfigDAO.getTargetSystemDeatils(sysInputDto)).build();
					  
		  }else{
			  CustomResDto resDto = new CustomResDto();
			  ResMessageDto resMessageDto = new ResMessageDto();	
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity( resDto).build();
		  }
		}catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("displayTargetSystems service ended");
		  }

	 }
	
	    @POST
		@Path("getTargetSystemDetails")
		@Produces(MediaType.APPLICATION_JSON)
		public Response getSourceTargetDetailsForUser(@Valid SessionInputDTO sessionInputDto) {
		slf4jLogger.info("getTargetSystemDetails service started");
		List<String> roleIdList = new ArrayList<>();
	  	 roleIdList.add(ConstantsValues.PROJECTADMIN);
	  	 roleIdList.add(ConstantsValues.TOOLADMIN);
	  	 roleIdList.add(ConstantsValues.TEMPAD);
	 	 roleIdList.add(ConstantsValues.TEMPAD1);
	  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	  roleValidationDto.setRoleIdList(roleIdList);
		try{
		 if(UserSessionDao.isSessionActive(sessionInputDto,roleValidationDto)){
			  SystemDAO eccConfigDAO = new SystemDAO();
			  return  Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity(eccConfigDAO.getTargetSystemDetails()).build();
					  
		  }else{
			  CustomResDto resDto = new CustomResDto();
			  ResMessageDto resMessageDto = new ResMessageDto();	
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return Response.ok()
				.header("Cache-Control", "No-cache")
			    .header("X-FRAME-OPTIONS", "Deny")
			    .header("X-Content-Type-Options", "nosniff")
			    .header("Content-Security-Policy",
				"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
			    .header("X-XSS-Protection", "1")
			    .entity( resDto).build();
		  }
		}catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("getTargetSystemDetails service ended");
		  }

		}
	    @POST
		@Path("/getSystemDetails")
		@Consumes(MediaType.APPLICATION_JSON)
		@Produces(MediaType.APPLICATION_JSON)
		public Response getSystemDetails(@Valid SystemDTO systemDto) {
			 slf4jLogger.info("add service started");
			 List<String> roleIdList = new ArrayList<>();
		  	  roleIdList.add(ConstantsValues.PROJECTADMIN);
		  	  roleIdList.add(ConstantsValues.CONFIG);
		  	  roleIdList.add(ConstantsValues.TOOLADMIN);
		  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
		  	  roleValidationDto.setRoleIdList(roleIdList);
			  roleValidationDto.setOmId(systemDto.getOmId());
			 
			  
			try{
			if(UserSessionDao.isSessionActive(systemDto.getSessionInputDTO(),roleValidationDto)){
				  SystemDAO eccConfigDAO = new SystemDAO();
				  return Response.ok()
							.header("Cache-Control", "No-cache")
						    .header("X-FRAME-OPTIONS", "Deny")
						    .header("X-Content-Type-Options", "nosniff")
						    .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						    .header("X-XSS-Protection", "1")
						    .entity(eccConfigDAO.fetchSystemDetails(systemDto)).build();
						  	  
			  }else{
				  ResMessageDto resMessageDto = new ResMessageDto();	
				  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
				  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
				  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
				  return Response.ok()
					.header("Cache-Control", "No-cache")
				    .header("X-FRAME-OPTIONS", "Deny")
				    .header("X-Content-Type-Options", "nosniff")
				    .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				    .header("X-XSS-Protection", "1")
				    .entity(resMessageDto).build();
						  
			  }
			}catch(Exception e){
				  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				  return Response.ok()
						  .header("Cache-Control", "No-cache")
						  .header("X-FRAME-OPTIONS", "Deny")
						  .header("X-Content-Type-Options", "nosniff")
						  .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						  .header("X-XSS-Protection", "1")
						  .header("Server","Disable")
						  
						  .entity(ConstantsValues.EXCEPTION).build();

			  }finally{		
				slf4jLogger.info("add service ended");
			  }
		}
		
	
}
