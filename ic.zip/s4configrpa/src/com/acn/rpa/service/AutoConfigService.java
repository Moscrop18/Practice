package com.acn.rpa.service;

import java.io.File;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.encrypt.AESEncrypt;
import com.acn.encrypt.CryptoException;
import com.acn.rpa.admin.SystemDAO;
import com.acn.rpa.admin.SystemDTO;
import com.acn.rpa.config.BrownFieldInputDto;
import com.acn.rpa.config.BrownFieldModDownloadDto;
import com.acn.rpa.config.BwnFieldResDto;
import com.acn.rpa.config.CheckToPlantDto;
import com.acn.rpa.config.CopyFuntionalityInputDto;
import com.acn.rpa.config.DownloadResponseDto;
import com.acn.rpa.config.DownloadScopeResDto;
import com.acn.rpa.config.IMGFilterDao;
import com.acn.rpa.config.IMGScopeDto;
import com.acn.rpa.config.JSONFormatDto;
import com.acn.rpa.config.S4AutoConfExecution;
import com.acn.rpa.config.S4AutoConfigReqDto;
import com.acn.rpa.config.ScopeCheckReqDto;
import com.acn.rpa.config.ScopeCheckResDto;
import com.acn.rpa.config.ServiceResponseDto;
import com.acn.rpa.config.UploadResponseDto;
import com.acn.rpa.config.configauditDto;
import com.acn.rpa.config.dto.ConfigDownloadHistoryDto;
import com.acn.rpa.config.dto.ConfigUploadHistoryDto;
import com.acn.rpa.config.dto.ImgFilterResponseDTO;
import com.acn.rpa.config.dto.UploadExecutionLogDto;
import com.acn.rpa.imghierarchy.ClientImgHierarchyDAO;
import com.acn.rpa.imghierarchy.CustomProjectDto;
import com.acn.rpa.imghierarchy.ImgDownloadDto;
import com.acn.rpa.imghierarchy.ImgHierarchyCustomDto;
import com.acn.rpa.imghierarchy.ImgHierarchyDAO;
import com.acn.rpa.imghierarchy.IndustryDto;
import com.acn.rpa.imghierarchy.IndustryResponseDto;
import com.acn.rpa.reports.ConfigAuditDAO;
import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.DBConnection;
import com.acn.rpa.utilities.RoleValidationDto;
import com.acn.user.session.CustomerInputDto;
import com.acn.user.session.ResMessageDto;
import com.acn.user.session.UserSessionDao;
//import com.mysql.jdbc.log.Slf4JLogger;





@Path("autoConfigSrv") 
public class AutoConfigService {
    private final Logger slf4jLogger = LoggerFactory.getLogger(AutoConfigService.class);

	//TransactionDTO transactionDTO = new TransactionDTO();

	 
	 /* Green field configuration upload*/
	 @Path("performS4AutoConfig")
	 @Consumes(MediaType.APPLICATION_JSON)
	 @POST
	 @Produces(MediaType.APPLICATION_JSON)
	 public ServiceResponseDto performS4AutoConfig(@Valid S4AutoConfigReqDto inputDTO, @Context HttpServletRequest request){
		 slf4jLogger.info("performS4AutoConfig(Assisted Configuration) service started");
		 String key = "RRn4PlfhPT6rXtZP";
		 String decryptedvalue=null;
		 String currentScope = inputDTO.getScopeName()+"|"+inputDTO.getTransactionID();
		 ServiceResponseDto responseDto =  new ServiceResponseDto();
		 List<String> roleIdList = new ArrayList<>();
		 List<String> toPlantList = new ArrayList<String>();
		 ArrayList<String> savePlantList = new ArrayList<String>();
	  	 roleIdList.add(ConstantsValues.CONFIG);
	  	 RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	 roleValidationDto.setRoleIdList(roleIdList);
		  roleValidationDto.setOmId(inputDTO.getOmgID());
		  JSONFormatDto excelFrmt = null;
		  ArrayList<JSONFormatDto> dstResultsList = new ArrayList<JSONFormatDto>();
		  System.out.println("time satrted"+java.time.LocalTime.now());  
 		if(UserSessionDao.isSessionActive(inputDTO.getSessionInputDTO(),roleValidationDto)){
		 try{
		// if( (TransactionDetails.imgId == null || !TransactionDetails.imgId.equals(inputDTO.getScopeName())) && (TransactionDetails.transId == 0 ||  TransactionDetails.transId != inputDTO.getTransactionID())){

		   if(validRequest(currentScope,inputDTO.getExeReqCount())){
			// TransactionDetails.imgId = inputDTO.getScopeName();
			 //TransactionDetails.transId = inputDTO.getTransactionID();
			 //TransactionDetails.tranMap.put(currentScope,false);
		
		 S4AutoConfExecution s4ImplObj = new S4AutoConfExecution();
		 String webAppPath = request.getServletContext().getRealPath("/WEB-INF");
		 String webAppPath1 = request.getServletContext().getRealPath("/src/css");
		
		 File encryptedFile=new File(webAppPath+"/ACNIPIMG_UPLOAD.txt");
		 File  decryptedFile = new File(webAppPath1+"/ACNIPIMG_UPLOAD.txt");
		  try {
		    //AESEncrypt.encrypt(key, inputFile, encryptedFile,decryptedFile);
			  //slf4jLogger.info("before decryption");
			  AESEncrypt.decrypt(key, encryptedFile,decryptedFile);
			  //decryptedvalue=AESEncrypt.decrypt(key, encryptedFile);
			 // slf4jLogger.info("after  decryption");
		    } catch (CryptoException ex) {
		        //System.out.println(ex.getMessage());
		        ex.printStackTrace();
		    }
		 //Added for Logging 
		 ConfigUploadHistoryDto  configUploadHistoryDto = new ConfigUploadHistoryDto();
		 ArrayList<UploadExecutionLogDto> uploadExecutionLogList = new ArrayList<UploadExecutionLogDto>();
		 UploadExecutionLogDto uploadExecutionLogDto =  null;
		 int transactionId = 0;
		 Date date = new java.util.Date();
		 Timestamp executionStartTime = new java.sql.Timestamp(date.getTime());
		 int recordCount = 0;
		 //PropMappings propObj = PropMappings.getInstance();
		 configUploadHistoryDto.setImgID(inputDTO.getScopeName());
		 configUploadHistoryDto.setTransactionID(inputDTO.getTransactionID());
		 configUploadHistoryDto.setModule(inputDTO.getModule());
		 configUploadHistoryDto.setConfigUploadID(inputDTO.getTranId());
		 configUploadHistoryDto.setWorkbenchTr(inputDTO.getWorkbenchTr());
		 configUploadHistoryDto.setCustomizingTr(inputDTO.getCustomizingTr());
		 configUploadHistoryDto.setExecutionStartTime(executionStartTime);
		 //String cipherTextSapUser =  new String(java.util.Base64.getDecoder().decode(inputDTO.getSapUserId()));
		 //String cipherTextSapPass =  new String(java.util.Base64.getDecoder().decode(inputDTO.getSapPassword()));
		 //AesUtil aesUtil = new AesUtil(128, 1000);
			  
		   /* if (cipherTextSapUser != null && cipherTextSapUser.split("::").length == 3) {   
		    	inputDTO.setSapUserId(aesUtil.decrypt(cipherTextSapUser.split("::")[1], cipherTextSapUser.split("::")[0], inputDTO.getDestinationName(), cipherTextSapUser.split("::")[2]));
		      }*/
//		    if (cipherTextSapPass != null && cipherTextSapPass.split("::").length == 3) {   
//		    	inputDTO.setSapPassword(aesUtil.decrypt(cipherTextSapPass.split("::")[1], cipherTextSapPass.split("::")[0], inputDTO.getDestinationName(), cipherTextSapPass.split("::")[2]));
//		      }
		 //Ended for Logging
		 inputDTO.setImplType("greenField");
		// inputDTO.setUpldABAPPrgPath(decryptedvalue);
		 inputDTO.setUpldABAPPrgPath(webAppPath1 + File.separator + "ACNIPIMG_UPLOAD.txt");
		 UploadResponseDto uploadResponseDto = new UploadResponseDto();
		 uploadResponseDto = s4ImplObj.executeTargetSysConfig(inputDTO);
		 recordCount = uploadResponseDto.getRecordCount();
		 configUploadHistoryDto.setRecordCount(recordCount);
		 
		 if(uploadResponseDto.getResponseData() != null && uploadResponseDto.getResponseData().size() >=2){
			 if(uploadResponseDto.getResponseData().get(1).startsWith(inputDTO.getScopeName())){
				 String[] resTR = uploadResponseDto.getResponseData().get(1).split("\\|");
				 if(resTR != null && resTR.length == 3){
					 configUploadHistoryDto.setCustomizingTr(resTR[1]);
					 configUploadHistoryDto.setWorkbenchTr(resTR[2]);
				 }else if(resTR != null && resTR.length == 2){
					 configUploadHistoryDto.setCustomizingTr(resTR[1]);
				 }
				 //uploadResponseDto.getResponseData().remove(1);//read and remove TR data from Response
			 }
		 }
		 
		 responseDto.setResponseData(uploadResponseDto.getResponseData());
		 responseDto.setConnectionStatus(uploadResponseDto.isDstConnectionStatus());
		 if(uploadResponseDto.isDstConnectionStatus() && uploadResponseDto.isDstExecutionStatus()){
			for (int i = 0,resSize = responseDto.getResponseData().size(); i < resSize; i++) {
					if (responseDto.getResponseData().get(i) != null && !responseDto.getResponseData().get(i).equals("")) {
						String[] result = responseDto.getResponseData().get(i).split("~");
						String resultDescription  = null, messageType = null;
						if(i==0 && result.length > 1){
							responseDto.setStatus(result[1].replaceAll("\\s+",""));
						}
						else if(i==1 && responseDto.getResponseData().get(i).startsWith(inputDTO.getScopeName())){
							continue;
						}
						else{
						messageType = result[0];
						
					    if( result.length > 1) 
					    	resultDescription = result[1]; 
						excelFrmt = new JSONFormatDto();
						excelFrmt.setScopeName(inputDTO.getScopeName());
						excelFrmt.setDescription(resultDescription);
						excelFrmt.setErrorType(messageType);
						excelFrmt.setMessageType(messageType);
						dstResultsList.add(excelFrmt); 
						
						}
					}
			}
		 }
		 else{
			 responseDto.setStatus(ConstantsValues.ERRORSTATUS); 
			 excelFrmt = new JSONFormatDto();
			 excelFrmt.setDescription(responseDto.getResponseData().get(0));
			 excelFrmt.setErrorType("E");
			 excelFrmt.setMessageType("E");
			 excelFrmt.setScopeName(inputDTO.getScopeName());
			 dstResultsList.add(excelFrmt);


		 }
			 
			responseDto.setResult(dstResultsList);
		
			configUploadHistoryDto.setStatus(responseDto.getStatus().equalsIgnoreCase("Success")?"S":"E");
			if(inputDTO.getCopyFlag()) {
				if(responseDto.getStatus().equalsIgnoreCase("Success")) {
										
					//String parentImg = s4ImplObj.findParentImg(inputDTO.getScopeName());
					
					if(inputDTO.getScopeName()!=null && !inputDTO.getScopeName().isEmpty()) {
			            CheckToPlantDto checkToPlantDto=new CheckToPlantDto();
			            checkToPlantDto = s4ImplObj.checkToPlants(inputDTO.getScopeName(), inputDTO.getOmgID());
			            toPlantList=checkToPlantDto.getToPlantsList();
					}
/*
							for (int i = 1; i <= toPlantList.size(); i++) {
								if (uploadResponseDto.getResponseData().get(i).startsWith("S~")) {
									String dataString = uploadResponseDto.getResponseData().get(i);
									if (dataString.indexOf("P")>1) {
										String toValue = dataString.substring(dataString.indexOf("~") + 1,
												dataString.indexOf("P") - 1);
										savePlantList.add(toValue);
									}
								}
							}*/

					if(toPlantList!=null && !toPlantList.isEmpty()) {
					StringBuilder builder = new StringBuilder();

					for( int i = 0 ; i < toPlantList.size(); i++ ) {
					    builder.append("?,");
					}
					int highestCount=0;
					int count=0;
					String sql = "UPDATE CLIENT_COPYVALUES SET COMPLETED = ? , COUNT=? WHERE OMID =? AND COMPLETED=? AND IMGID =? AND VALUE IN (" 
					               + builder.deleteCharAt( builder.length() -1 ).toString() + ")";
						
					Connection con = null;
					PreparedStatement ps=null;
					PreparedStatement pStmt=null;
					try {
			    		con =  DBConnection.createConnection();
			    		ps = con.prepareStatement(sql);  		
			    		ResultSet resultSet = null;

			    		pStmt = con.prepareStatement("SELECT COUNT FROM CLIENT_COPYVALUES WHERE OMID =? AND IMGID =? AND COMPLETED=?");
			    		pStmt.setString(1, inputDTO.getOmgID());
			    		pStmt.setString(2, inputDTO.getScopeName());
			    		pStmt.setBoolean(3, false);

			    		resultSet = pStmt.executeQuery();
			    		while (resultSet.next()) {
			    			count=resultSet.getInt("COUNT");
			    			if(count>highestCount)
			    				highestCount=count;
			    		}
						if (highestCount > 1) {
							ps.setBoolean(1, false);
							ps.setInt(2, highestCount-1);
							ps.setString(3, inputDTO.getOmgID());
							ps.setBoolean(4, false);
							ps.setString(5, inputDTO.getScopeName());
						} else {
								ps.setBoolean(1, true);
								ps.setInt(2, 0);
								ps.setString(3, inputDTO.getOmgID());
								ps.setBoolean(4, false);
								ps.setString(5, inputDTO.getScopeName());
						}
			    		int index =6;
			    		
			    		for(String toPlant : toPlantList) {		
			    			ps.setString(index, toPlant);
			    			index++;
			    		} 
			    		ps.executeUpdate();
			    	}catch (SQLException e){
			    		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			    	
			    	}finally {
			    		if(ps!=null){
							try {
								ps.close();
								ps=null;
								} catch (SQLException e) {
								slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
							}
						}
			    	}
				}
				}
			}
			//Added for Upload Logs
			//if(inputDTO.isIMGHierarchy()){
			//Added for Logging
			try{
				ConfigAuditDAO configAuditDao =  new ConfigAuditDAO();
				transactionId = configAuditDao.createConfigUploadHistory(configUploadHistoryDto);
				responseDto.setTranId(transactionId);
				if(transactionId > 0){
					for(int i = 0,arrSize = dstResultsList.size(); i< arrSize;i++){
						
						JSONFormatDto dto = dstResultsList.get(i);
					//Added for Upload Execution Logs
					uploadExecutionLogDto = new UploadExecutionLogDto();
					uploadExecutionLogDto.setConfigUploadID(transactionId);
					uploadExecutionLogDto.setMessage(dto.getDescription());
					uploadExecutionLogDto.setStatus(dto.getMessageType());
					uploadExecutionLogDto.setSequenceID(i+1);
					uploadExecutionLogList.add(uploadExecutionLogDto);
					}
					
					configAuditDao.createUploadExecutionLog(uploadExecutionLogList);
				}
			}catch(Exception e){
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
		//	}
			 //Ended for Logging
//		 }
			   //TransactionDetails.responseDto = responseDto;
			   /*TransactionDetails.imgId = null;
			   TransactionDetails.transId = 0;*/
			  // TransactionDetails.tranMap.put(responseDto.getScopeName(),true);
			   return responseDto;
		 
		 }
		 else{
			 
			 responseDto.setStatus(ConstantsValues.ERRORSTATUS); 
			 excelFrmt = new JSONFormatDto();
			 excelFrmt.setDescription(ConstantsValues.DUPLICATEREQUEST);
			 excelFrmt.setErrorType("E");
			 excelFrmt.setMessageType("E");
			 excelFrmt.setScopeName(inputDTO.getScopeName());
			 dstResultsList.add(excelFrmt);
			 ResMessageDto resMessageDto = new ResMessageDto();
			 resMessageDto.setMessage(ConstantsValues.DUPLICATEREQUEST);
			 resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			 slf4jLogger.error(ConstantsValues.DUPLICATEREQUEST);
			 responseDto.setResMessageDto(resMessageDto);
			 responseDto.setConnectionStatus(true);
			 return responseDto;
		 }
		 }catch(Exception e){
			 slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			
			 return responseDto;
		 }
		 finally{
			   //TransactionDetails.tranMap.remove(responseDto.getScopeName());
			  slf4jLogger.info("performS4AutoConfig service ended");
			   String webAppPath = request.getServletContext().getRealPath("/src/css");
				 
				
				 File file = new File(webAppPath+"/ACNIPIMG_UPLOAD.txt");
			   
		        if(file.delete()){
		            //System.out.println(" File deleted");
		       }
		        //else System.out.println(" doesn't exist");
			 //System.out.println("time ended"+java.time.LocalTime.now());  
		 }
		  }
		 else{
			 ResMessageDto resMessageDto = new ResMessageDto();
			 resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			 resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			 slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			 responseDto.setResMessageDto(resMessageDto);
			 return responseDto;
		 }
	  }
	 
	 
	 
	 /* Brown field configuration download*/
	 
	 @Path("brownFieldConfigDownload")
     @Consumes(MediaType.APPLICATION_JSON)
     @POST
     @Produces(MediaType.APPLICATION_JSON)
     public  ServiceResponseDto configDownload(@Valid BrownFieldInputDto autoConfigInputDto, @Context HttpServletRequest request){
		 slf4jLogger.info("without intervention service started for img: "+autoConfigInputDto.getImgDownloadDtoObj().getImgDescription()+
				 " img id: "+autoConfigInputDto.getImgDownloadDtoObj().getImgId());
		 String currentScope = autoConfigInputDto.getImgID()+autoConfigInputDto.getTransactionID();
		 ServiceResponseDto responseDto =  new ServiceResponseDto();
		 List<String> roleIdList = new ArrayList<>();
	  	 roleIdList.add(ConstantsValues.CONFIG);
	  	 RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	 roleValidationDto.setRoleIdList(roleIdList);
		  roleValidationDto.setOmId(autoConfigInputDto.getOmgID());
		  JSONFormatDto excelFrmt = null;
		  ArrayList<JSONFormatDto> dstResultsList = new ArrayList<>();
 		if(UserSessionDao.isSessionActive(autoConfigInputDto.getSessionInputDTO(),roleValidationDto)){
		// if( (TransactionDetails.imgId == null || !TransactionDetails.imgId.equals(autoConfigInputDto.getImgID())) && (TransactionDetails.transId == 0 ||  TransactionDetails.transId != autoConfigInputDto.getTransactionID())){
		 try{
		 if(validRequest(currentScope,autoConfigInputDto.getExeReqCount())){


	/*		 TransactionDetails.imgId = autoConfigInputDto.getImgID();
			 TransactionDetails.transId = autoConfigInputDto.getTransactionID();
			 TransactionDetails.tranMap.put(currentScope,false);*/
		//Added for Logging
		 int transactionId = 0;
		 ConfigAuditDAO configAuditDao =  new ConfigAuditDAO();
		 ConfigDownloadHistoryDto  configDownloadHistoryDto  = null;
		 ConfigUploadHistoryDto  configUploadHistoryDto  = null;
		 ArrayList<UploadExecutionLogDto> uploadExecutionLogList = null ;
		 UploadExecutionLogDto uploadExecutionLogDto =  null;
		//Ended for Logging
		 DownloadScopeResDto downloadScopeResDto = null;
		 ImgHierarchyDAO imgHierarchyDAO = new ImgHierarchyDAO();
		 S4AutoConfExecution s4ImplObj = null;
		 String webAppPath = null;
		 String downloadPrgPath = null;
		 DownloadResponseDto downloadResponseDto = null;
		 ImgDownloadDto imgDownloadDto = null;
		 int resDataLen = 0;
		 UploadResponseDto uploadResponseDto = null;
		 HashMap<String, ArrayList<String>> filterMap = null;
		 IMGFilterDao imgFilterDao = null;
		 ImgFilterResponseDTO imgFilterResponseDTO = null;
		 Date date = new java.util.Date();
		 String fileName ="";
		 Timestamp executionStartTime = new java.sql.Timestamp(date.getTime());
		 try{
			 
			 imgFilterDao = new IMGFilterDao();
        	 responseDto.setScopeName(autoConfigInputDto.getImgID()+autoConfigInputDto.getTransactionID());
        	 imgDownloadDto = autoConfigInputDto.getImgDownloadDtoObj();
			
        	 if(autoConfigInputDto.isIndustryFlag()) {
        		  fileName =imgDownloadDto.getSequence()+"_"+imgDownloadDto.getImgDescription()
        		 +"_"+autoConfigInputDto.getIndustryAlias()+"_"+autoConfigInputDto.getSubIndustryAlias();
        		 
        		 downloadScopeResDto = imgHierarchyDAO.getInputStringForInstalledBaseForIndustry(autoConfigInputDto.getImgID(),
        				 autoConfigInputDto.getSourceSystemID(),autoConfigInputDto.getIndustry(), autoConfigInputDto.getSubIndustry(),fileName);
        	 }else {
        		 fileName =imgDownloadDto.getSequence()+"_"+imgDownloadDto.getImgDescription();
        		 downloadScopeResDto = imgHierarchyDAO.getInputStringForInstalledBase(autoConfigInputDto.getImgID(),autoConfigInputDto.getSourceSystemID(),imgDownloadDto.getImgDescription(),imgDownloadDto.getSequence());
        	 }
			 
			 if(downloadScopeResDto.getScopeAvailable().equals("N")){
				 	excelFrmt = new JSONFormatDto();
				 	excelFrmt.setScopeName(autoConfigInputDto.getImgID());
					excelFrmt.setDescription("Scope Data not available in the Source System");
					excelFrmt.setErrorType("E");
					excelFrmt.setMessageType("E");
					dstResultsList.add(excelFrmt);
    				responseDto.setResult(dstResultsList);
    				return responseDto;
			 }
	
		   else{
			
		  // slf4jLogger.error("else block execution");
		   String key = "RRn4PlfhPT6rXtZP";
		   s4ImplObj = new S4AutoConfExecution();
		   webAppPath = request.getServletContext().getRealPath("/WEB-INF");
		   String webAppPath1 = request.getServletContext().getRealPath("/src/css");
			
			 File encryptedFile=new File(webAppPath+"/ACNIPIMG_DOWNLOAD.txt");
			 File  decryptedFile = new File(webAppPath1+"/ACNIPIMG_DOWNLOAD.txt");
			  try {
			    	
				  //slf4jLogger.info("before decryption");
				  AESEncrypt.decrypt(key, encryptedFile,decryptedFile);
				  //slf4jLogger.info("after  decryption");
			    } catch (CryptoException ex) {
			       // System.out.println(ex.getMessage());
			        ex.printStackTrace();
			    }
           downloadPrgPath = webAppPath1 + File.separator + "ACNIPIMG_DOWNLOAD.txt";
           downloadResponseDto = new DownloadResponseDto();
           
        	   configDownloadHistoryDto = new ConfigDownloadHistoryDto();//Added for Logging
        	   BwnFieldResDto bwnFieldResDto =  new BwnFieldResDto();
        	   bwnFieldResDto.setImgId(imgDownloadDto.getImgId());
        	   bwnFieldResDto.setImgDescription(imgDownloadDto.getImgDescription());
        	   downloadResponseDto = s4ImplObj.executeSrcConfigDownload(autoConfigInputDto.getSrcDestination(), downloadPrgPath,downloadScopeResDto.getImgScope(),autoConfigInputDto.getHostName(),
        			   autoConfigInputDto.getClientNo(),autoConfigInputDto.getSysNo(),autoConfigInputDto.getSapUserId(),
        			   autoConfigInputDto.getSapPassword(),autoConfigInputDto.getSapLanguage(),autoConfigInputDto.getSrcSncEnabled(), autoConfigInputDto.getSrcSncName(),
        			   autoConfigInputDto.getSrcSncPartnerName(), autoConfigInputDto.getSrcSncProtection(), autoConfigInputDto.getSrcSapRouter());
        	   
        	   bwnFieldResDto.setConStatus(downloadResponseDto.isSrcConnectionStatus());
        	   bwnFieldResDto.setExeStatus(downloadResponseDto.isSrcExecutionStatus());
        	   

             if(downloadResponseDto.isSrcExecutionStatus() && downloadResponseDto.isSrcConnectionStatus()){
            	 if(downloadResponseDto.getDownloadRes().size()> 0)//Remove S~Success or E~Error
            	 	downloadResponseDto.getDownloadRes().remove(0);//Added on 5 June 2017
            	 if(downloadResponseDto.getDownloadRes().size()> 0 && downloadResponseDto.getDownloadRes().get(0).startsWith("M~"))
            		 downloadResponseDto.getDownloadRes().remove(0);//Remove M~ Message
            	// String imgTRnumber = downloadResponseDto.getDownloadRes().get(0)+ "|" + autoConfigInputDto.getTrNumber();
            	 //downloadResponseDto.getDownloadRes().set(0, imgTRnumber);
            	 //slf4jLogger.error(downloadResponseDto.getDownloadRes().get(0));
            	 bwnFieldResDto.setImgData(downloadResponseDto.getDownloadRes());
            	 slf4jLogger.debug("Downloaded Config Size : "+downloadResponseDto.getDownloadRes());
            	 //slf4jLogger.error(downloadResponseDto.getDownloadRes() + " data ");
            	 configDownloadHistoryDto.setStatus("S");//Added for Logging
//            	 bwnFieldResDto.setImgData((ArrayList<String>) downloadResponseDto.getDownloadRes().subList(1, downloadResponseDto.getDownloadRes().size()));
            	 S4AutoConfigReqDto inputDTO = new S4AutoConfigReqDto();
                 inputDTO.setConfigDataList(bwnFieldResDto.getImgData());
                 String webAppPath2 = request.getServletContext().getRealPath("/src/css");
        		 //slf4jLogger.info("filepath"+webAppPath);
        		 //slf4jLogger.info("filepath"+webAppPath);
        		 File encryptedFile1=new File(webAppPath+"/ACNIPIMG_UPLOAD.txt");
        		 File  decryptedFile1 = new File(webAppPath2+"/ACNIPIMG_UPLOAD.txt");
        		  try {
        		    	//AESEncrypt.encrypt(key, inputFile, encryptedFile);
        			  //slf4jLogger.info("before decryption");
        			  AESEncrypt.decrypt(key, encryptedFile1,decryptedFile1);
        			 // slf4jLogger.info("after  decryption");
        		    } catch (CryptoException ex) {
        		       // System.out.println(ex.getMessage());
        		        ex.printStackTrace();
        		    }
                 inputDTO.setUpldABAPPrgPath(webAppPath2 + File.separator + "ACNIPIMG_UPLOAD.txt");
                 inputDTO.setDestinationName(autoConfigInputDto.getTgtDestination());
                 inputDTO.setScopeName(bwnFieldResDto.getImgId());
                 inputDTO.setTranId(autoConfigInputDto.getTransactionID());
                 // changes for dynamic destination for BrownField Upload
                 inputDTO.setIsCustomDestinationRequired(autoConfigInputDto.getIsCustomDestinationRequired());
               //  String cipherTextSapUser =  new String(java.util.Base64.getDecoder().decode(autoConfigInputDto.getSapUserId()));
        		 String cipherTextSapPass =  new String(java.util.Base64.getDecoder().decode(autoConfigInputDto.getSapPassword()));
        		 AesUtil aesUtil = new AesUtil(128, 1000);
        			  
        		   /* if (cipherTextSapUser != null && cipherTextSapUser.split("::").length == 3) {   
        		    	inputDTO.setSapUserId(aesUtil.decrypt(cipherTextSapUser.split("::")[1], cipherTextSapUser.split("::")[0], autoConfigInputDto.getTgtDestination(), cipherTextSapUser.split("::")[2]));
        		      }*/
        		    if (cipherTextSapPass != null && cipherTextSapPass.split("::").length == 3) {   
        		    	inputDTO.setSapPassword(aesUtil.decrypt(cipherTextSapPass.split("::")[1], cipherTextSapPass.split("::")[0], autoConfigInputDto.getTgtDestination(), cipherTextSapPass.split("::")[2]));
        		      }
               //  inputDTO.setSapPassword(autoConfigInputDto.getSapPassword());
                // inputDTO.setSapUserId(autoConfigInputDto.getSapUserId());
                // Passing TR Number from brownfield to ABAP
                 //inputDTO.setTrNumber(autoConfigInputDto.getTrNumber());
        		 inputDTO.setSapUserId(autoConfigInputDto.getSapUserId());
        		 inputDTO.setSapLanguage(autoConfigInputDto.getSapLanguage());
        		 inputDTO.setHostName(autoConfigInputDto.getHostName());
        		 inputDTO.setSapPassword(autoConfigInputDto.getSapPassword());
        		 inputDTO.setSapClientNo(autoConfigInputDto.getClientNo());
        		 inputDTO.setSystemNo(autoConfigInputDto.getSysNo());
        		 inputDTO.setSncEnabled(autoConfigInputDto.getSncEnabled());
        		 inputDTO.setSncName(autoConfigInputDto.getSncName());
        		 inputDTO.setSncPartnerName(autoConfigInputDto.getSncPartnerName());
        		 inputDTO.setSncProtectionLevel(autoConfigInputDto.getSncProtectionLevel());
        		 inputDTO.setSapRouter(autoConfigInputDto.getSapRouter());
        		
                 inputDTO.setCustomizingTr(autoConfigInputDto.getCustomizingTr());
                 inputDTO.setWorkbenchTr(autoConfigInputDto.getWorkbenchTr());
                // inputDTO.setTransactionDTO(transactionDTO);
                 
                 uploadResponseDto = new UploadResponseDto();
   		      	 filterMap = imgFilterDao.getIMGFilterValues(autoConfigInputDto.getImgID());
   		      	 if(filterMap.isEmpty()){
   	                 inputDTO.setImplType("BrownField");
   	                slf4jLogger.error("Without filter ");
   	                 uploadResponseDto = s4ImplObj.executeTargetSysConfig(inputDTO);
   	             }else{
   	            	 	
   	            	 // added to retrieve configurable data based on filter criteria maintained
   	                 slf4jLogger.error("With filter ");

   	            	 	imgFilterResponseDTO = s4ImplObj.getFilteredConfigData(imgDownloadDto,downloadResponseDto,filterMap, fileName,autoConfigInputDto.isIndustryFlag() );
   	                 	inputDTO.setImplType("FilterData");
   	                 	if(imgFilterResponseDTO.isStatus()){
   	    				 inputDTO.setWorkbook(imgFilterResponseDTO.getExcelWorkbook());
   	   	                 uploadResponseDto = s4ImplObj.executeTargetSysConfig(inputDTO);
   	    				}else{
   	    					excelFrmt = new JSONFormatDto();
   	   	   				 	excelFrmt.setScopeName(imgDownloadDto.getImgId());
   	   	   					excelFrmt.setDescription(imgFilterResponseDTO.getErrDetails());
   	   	   					excelFrmt.setErrorType("E");
   	   	   					excelFrmt.setMessageType("E");
   	   	   					dstResultsList.add(excelFrmt);
   	   	   					responseDto.setResult(dstResultsList);
   	   	   					return responseDto;
   	   	   					}
   	             }
   		      	 
   		      	 //transactionDTO = uploadResponseDto.getTransactionDTO();
                 configUploadHistoryDto = new ConfigUploadHistoryDto();
                 if(uploadResponseDto.getResponseData() != null && uploadResponseDto.getResponseData().size() >=2){
        			 if(uploadResponseDto.getResponseData().get(1).startsWith(inputDTO.getScopeName())){
        				 String[] resTR = uploadResponseDto.getResponseData().get(1).split("\\|");
        				 if(resTR != null && resTR.length == 3){
        					 configUploadHistoryDto.setCustomizingTr(resTR[1]);
        					 configUploadHistoryDto.setWorkbenchTr(resTR[2]);
        				 }else if(resTR != null && resTR.length == 2){
        					 configUploadHistoryDto.setCustomizingTr(resTR[1]);
        				 }
        				 //uploadResponseDto.getResponseData().remove(1);//read and remove TR data from Response
        			 }
        		 }
                 
                 responseDto.setResponseData(uploadResponseDto.getResponseData());
                 responseDto.setConnectionStatus(uploadResponseDto.isDstConnectionStatus());
                 responseDto.setExecutionStatus(uploadResponseDto.isDstExecutionStatus());
                 resDataLen = responseDto.getResponseData().size();
      				for (int k = 0; k < resDataLen; k++) {
  							excelFrmt = new JSONFormatDto();

      						if (responseDto.getResponseData().get(k) != null && !responseDto.getResponseData().get(k).equals("")) {
      							String[] result = responseDto.getResponseData().get(k).split("~");
      							String  resultDescription  = null, messageType = null;
      							if(k==0 && result.length > 1){
      								responseDto.setStatus(result[1].replaceAll("\\s+",""));
      							}
      							
      							else if(resDataLen == 1){
      							//messageType = result[0];
      						   /* if( result.length > 1) 
      						    	resultDescription = result[1]; */
      							excelFrmt.setScopeName(inputDTO.getScopeName());
      							excelFrmt.setDescription(result[0]);
      							excelFrmt.setErrorType("E");
      							excelFrmt.setMessageType("E");
      							dstResultsList.add(excelFrmt);
      							}
      							else if(k==1 && responseDto.getResponseData().get(k).startsWith(imgDownloadDto.getImgId())){
      								continue;
      							}
      							else {
          							messageType = result[0];
          						    if( result.length > 1) 
          						    	resultDescription = result[1]; 
          						   // AppUtils appUtilsObj = new AppUtils();
          							//Properties propin = appUtilsObj.fnReadPropertyFile(); 
          							//resultCode = propin.getProperty(result[0]);
          							excelFrmt.setScopeName(inputDTO.getScopeName());
          							excelFrmt.setDescription(resultDescription);
          							excelFrmt.setErrorType(messageType);
          							excelFrmt.setMessageType(messageType);
          							dstResultsList.add(excelFrmt);
          							}
      						}
      				}
      				responseDto.setResult(dstResultsList);
      				
   	             
   		     }else{

   		/*		dependencymet = imgHierarchyDao.getDependencyScope(autoConfigInputDto.getImgDownloadDto(),autoConfigInputDto.getImgID());
   				if(!dependencymet){
   						excelFrmt = new JSONFormatDto();
   						excelFrmt.setScopeName(imgDownloadDto.getImgId());
   						excelFrmt.setDescription("Dependency not met");
   						excelFrmt.setErrorType("E");
   						excelFrmt.setMessageType("E");
   						dstResultsList.add(excelFrmt);
   						responseDto.setResult(dstResultsList);
   						return responseDto; 
   					}else{*/
   						excelFrmt = new JSONFormatDto();
   	   				 	excelFrmt.setScopeName(imgDownloadDto.getImgId());
   	   					excelFrmt.setDescription(downloadResponseDto.getErrorDetails());
   	   					excelFrmt.setErrorType("E");
   	   					excelFrmt.setMessageType("E");
   	   					//responseDto.setConnectionStatus(true);
   	   					dstResultsList.add(excelFrmt);
   	   					responseDto.setResult(dstResultsList);
   	   				configUploadHistoryDto = new ConfigUploadHistoryDto();
   	   				configUploadHistoryDto.setImgID(autoConfigInputDto.getImgID());
   	   				configUploadHistoryDto.setTransactionID(autoConfigInputDto.getTransactionID());
   	   				configUploadHistoryDto.setProjectName(autoConfigInputDto.getProjectName());
   	   				configUploadHistoryDto.setScenario(autoConfigInputDto.getScenario());
   	   				configUploadHistoryDto.setOmgID(autoConfigInputDto.getOmgID());
   	   				configUploadHistoryDto.setSystemID(autoConfigInputDto.getSystemID());
   	   				configUploadHistoryDto.setUserID(autoConfigInputDto.getUserID());
   	   				configUploadHistoryDto.setModule(autoConfigInputDto.getModule());
   	   				configUploadHistoryDto.setExecutionStartTime(executionStartTime);
   				 	if(responseDto.getStatus() != null && responseDto.getStatus() != "")
   				 		configUploadHistoryDto.setStatus(responseDto.getStatus().equalsIgnoreCase("Success")?"S":"E");
   				 	else
   				 		configUploadHistoryDto.setStatus("E");
   				
   				//Added for Upload Logs
   				 	if(autoConfigInputDto.isIMGHierarchy()){
   					try{
   						
   						transactionId = configAuditDao.createConfigUploadHistory(configUploadHistoryDto);
   						if(transactionId > 0){
   							uploadExecutionLogList = new ArrayList<>();
   							for(int i = 0,arSize = dstResultsList.size(); i< arSize;i++){
   								
   								JSONFormatDto dto = dstResultsList.get(i);
   							//Added for Upload Execution Logs
   							uploadExecutionLogDto = new UploadExecutionLogDto();
   							uploadExecutionLogDto.setConfigUploadID(transactionId);
   							uploadExecutionLogDto.setImgID(autoConfigInputDto.getImgID());
   							uploadExecutionLogDto.setMessage(dto.getDescription());
   							uploadExecutionLogDto.setStatus(dto.getMessageType());
   							uploadExecutionLogDto.setUserID(autoConfigInputDto.getUserID());
   							uploadExecutionLogDto.setSequenceID(i+1);
   							uploadExecutionLogList.add(uploadExecutionLogDto);
   							}
   							
   							configAuditDao.createUploadExecutionLog(uploadExecutionLogList);

   						}
   						
   					}catch(Exception e){
   						slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
   					}
   					finally{
   						
   					}
   		     }
   	   					return responseDto; 
   					//}
   						
   			
				}
             
 //Added for Logging 
             
			 configUploadHistoryDto.setImgID(autoConfigInputDto.getImgID());
			 configUploadHistoryDto.setTransactionID(autoConfigInputDto.getTransactionID());
			 configUploadHistoryDto.setProjectName(autoConfigInputDto.getProjectName());
			 configUploadHistoryDto.setScenario(autoConfigInputDto.getScenario());
			 configUploadHistoryDto.setOmgID(autoConfigInputDto.getOmgID());
			 configUploadHistoryDto.setSystemID(autoConfigInputDto.getSystemID());
			 configUploadHistoryDto.setUserID(autoConfigInputDto.getUserID());
			 configUploadHistoryDto.setModule(autoConfigInputDto.getModule());
   			 configUploadHistoryDto.setExecutionStartTime(executionStartTime);
   			 configUploadHistoryDto.setRecordCount(uploadResponseDto.getRecordCount());

			 	if(responseDto.getStatus() != null && responseDto.getStatus() != "")
			 		configUploadHistoryDto.setStatus(responseDto.getStatus().equalsIgnoreCase("Success")?"S":"E");
			 	else
			 		responseDto.setStatus("E");
			
			//Added for Upload Logs
				try{
					
					transactionId = configAuditDao.createConfigUploadHistory(configUploadHistoryDto);
					if(transactionId > 0){
						uploadExecutionLogList = new ArrayList<>();
						for(int i = 0,arSize = dstResultsList.size(); i< arSize;i++){
							
							JSONFormatDto dto = dstResultsList.get(i);
						//Added for Upload Execution Logs
						uploadExecutionLogDto = new UploadExecutionLogDto();
						uploadExecutionLogDto.setConfigUploadID(transactionId);
						uploadExecutionLogDto.setImgID(autoConfigInputDto.getImgID());
						uploadExecutionLogDto.setMessage(dto.getDescription());
						uploadExecutionLogDto.setStatus(dto.getMessageType());
						uploadExecutionLogDto.setUserID(autoConfigInputDto.getUserID());
						uploadExecutionLogDto.setSequenceID(i+1);
						uploadExecutionLogList.add(uploadExecutionLogDto);
						}
						
						configAuditDao.createUploadExecutionLog(uploadExecutionLogList);

	}
					
				}catch(Exception e){
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
				finally{
					
				}
	          }
		 }catch(Throwable e){
			 slf4jLogger.error("Exception occured !!");
			 slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		 }finally{
			 imgHierarchyDAO = null;
			 downloadScopeResDto = null;
			 dstResultsList = null;
			 excelFrmt = null;
			 s4ImplObj = null;
			 webAppPath = null;
			 downloadPrgPath = null;
			 downloadResponseDto = null;
			 imgDownloadDto = null;
			 uploadResponseDto = null;

		 }

		   
		   //TransactionDetails.responseDto = responseDto;
		   /*TransactionDetails.imgId = null;
		   TransactionDetails.transId = 0;*/
		  // TransactionDetails.tranMap.put(responseDto.getScopeName(),true);
		   //TransactionDetails.isExecuted = true;
		   //transactionDTO.setResponseDto(responseDto);
           return responseDto;
           
		 }
		 else{
			 
			 responseDto.setStatus(ConstantsValues.ERRORSTATUS); 
			 excelFrmt = new JSONFormatDto();
			 excelFrmt.setDescription(ConstantsValues.DUPLICATEREQUEST);
			 excelFrmt.setErrorType("E");
			 excelFrmt.setMessageType("E");
			 excelFrmt.setScopeName(autoConfigInputDto.getImgID());
			 dstResultsList.add(excelFrmt);
			 ResMessageDto resMessageDto = new ResMessageDto();
			 resMessageDto.setMessage(ConstantsValues.DUPLICATEREQUEST);
			 resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			 slf4jLogger.error(ConstantsValues.DUPLICATEREQUEST);
			 responseDto.setResMessageDto(resMessageDto);
			 responseDto.setConnectionStatus(true);
			 return responseDto;
		 
		 }
		 
			   
		 }catch(Exception e){
			 slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			 slf4jLogger.info("configDownload service ended");
			 return responseDto;
		 }finally{
			 String webAppPath2 = request.getServletContext().getRealPath("/src/css");
			 
				
			 File file = new File(webAppPath2+"/ACNIPIMG_DOWNLOAD.txt");
		   
	        if(file.delete()){
	            //System.out.println(" File deleted");
	        }
	        //else System.out.println(" doesn't exist");
	        //String webAppPath3 = request.getServletContext().getRealPath("/src/css");
			 
			
			 File file1 = new File(webAppPath2+"/ACNIPIMG_UPLOAD.txt");
		   
	        if(file1.delete()){
	           // System.out.println(" File deleted");
	        }
	        /*else 
	        	System.out.println(" doesn't exist");*/
		 }
		  }else{
			 
			 ResMessageDto resMessageDto = new ResMessageDto();
			 resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			 slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			 resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			 responseDto.setResMessageDto(resMessageDto);
			 return responseDto;
		 }
	 }
	 @Path("performConsolidation")
	 @Consumes(MediaType.APPLICATION_JSON)
	 @POST
	 @Produces(MediaType.APPLICATION_JSON)
	 public ServiceResponseDto performConsolidation(@Valid S4AutoConfigReqDto inputDTO, @Context HttpServletRequest request){
		 slf4jLogger.info("performConsolidation service started");
		 String currentScope = inputDTO.getScopeName()+"|"+inputDTO.getTransactionID();
		 String img=inputDTO.getScopeName().split("-")[0];
	     String view=inputDTO.getScopeName().split("-")[1];
	     int seqno=0;
	     Boolean flag=false;
	     Connection conn = null;
			ResultSet rset1 = null;
			ResultSet rset2 = null;
			PreparedStatement ps1 = null;
			PreparedStatement ps2 = null;
			try {
				conn = DBConnection.createConnection();
				ps1= conn.prepareStatement("SELECT SEQNO FROM IMGOBJECTS WHERE IMGID=? AND OBJECTNAME=?");
				ps1.setString(1,img);
				ps1.setString(2,view);
				rset1 = ps1.executeQuery();
				if(rset1.next()) {
					seqno=rset1.getInt("SEQNO");
				}	
				if(seqno>1)
				{
					ps2= conn.prepareStatement("SELECT * FROM CONSOLIDATION_EXECUTION WHERE IMGID=? AND SEQNO<?");
					ps2.setString(1,img);
					ps2.setInt(2,seqno);
					rset2 = ps2.executeQuery();
					if(rset2.next()) {
						flag=true;
					}	
				}
				else
					flag=true;
			}catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			} finally {
				if (rset1 != null) {
					try {
						rset1.close();
						rset1 = null;
					} catch (SQLException e) {
						slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
					}
				}
				if (rset2 != null) {
					try {
						rset2.close();
						rset2 = null;
					} catch (SQLException e) {
						slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
					}
				}
				if (ps1 != null) {
					try {
						ps1.close();
						ps1 = null;
					} catch (SQLException e) {
						slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
					}
				}
				if (ps2 != null) {
					try {
						ps2.close();
						ps2 = null;
					} catch (SQLException e) {
						slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
					}
				}
				if (conn != null) {
					try {
						conn.close();
						conn = null;
					} catch (SQLException e) {
						slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
					}
				}

		 }
			 String key = "RRn4PlfhPT6rXtZP";

		 ServiceResponseDto responseDto =  new ServiceResponseDto();
		 List<String> roleIdList = new ArrayList<>();
	  	 roleIdList.add(ConstantsValues.CONFIG);
	  	 RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	 roleValidationDto.setRoleIdList(roleIdList);
		  roleValidationDto.setOmId(inputDTO.getOmgID());
		  JSONFormatDto excelFrmt = null;
		  ArrayList<JSONFormatDto> dstResultsList = new ArrayList<JSONFormatDto>();
 		if(UserSessionDao.isSessionActive(inputDTO.getSessionInputDTO(),roleValidationDto)){
		 try{
		// if( (TransactionDetails.imgId == null || !TransactionDetails.imgId.equals(inputDTO.getScopeName())) && (TransactionDetails.transId == 0 ||  TransactionDetails.transId != inputDTO.getTransactionID())){

		   if(validRequest(currentScope,inputDTO.getExeReqCount())){
			// TransactionDetails.imgId = inputDTO.getScopeName();
			 //TransactionDetails.transId = inputDTO.getTransactionID();
			 //TransactionDetails.tranMap.put(currentScope,false);
		
		 S4AutoConfExecution s4ImplObj = new S4AutoConfExecution();
		 
		 String webAppPath = request.getServletContext().getRealPath("/WEB-INF");
		 String webAppPath1 = request.getServletContext().getRealPath("/src/css");
		
		 File encryptedFile=new File(webAppPath+"/ACNIPIMG_UPLOAD.txt");
		 File  decryptedFile = new File(webAppPath1+"/ACNIPIMG_UPLOAD.txt");
		  try {
		    //AESEncrypt.encrypt(key, inputFile, encryptedFile,decryptedFile);
			  //slf4jLogger.info("before decryption");
			  AESEncrypt.decrypt(key, encryptedFile,decryptedFile);
			  //decryptedvalue=AESEncrypt.decrypt(key, encryptedFile);
			 // slf4jLogger.info("after  decryption");
		    } catch (CryptoException ex) {
		        //System.out.println(ex.getMessage());
		        ex.printStackTrace();
		    }
		 //Added for Logging 
		 ConfigUploadHistoryDto  configUploadHistoryDto = new ConfigUploadHistoryDto();
		 ArrayList<UploadExecutionLogDto> uploadExecutionLogList = new ArrayList<UploadExecutionLogDto>();
		 UploadExecutionLogDto uploadExecutionLogDto =  null;
		 int transactionId = 0;
		 Date date = new java.util.Date();
		 Timestamp executionStartTime = new java.sql.Timestamp(date.getTime());
		 int recordCount = 0;
		 //PropMappings propObj = PropMappings.getInstance();
		 configUploadHistoryDto.setImgID(inputDTO.getScopeName());
		 configUploadHistoryDto.setTransactionID(inputDTO.getTransactionID());
		 configUploadHistoryDto.setModule(inputDTO.getModule());
		 configUploadHistoryDto.setConfigUploadID(inputDTO.getTranId());
		 configUploadHistoryDto.setWorkbenchTr(inputDTO.getWorkbenchTr());
		 configUploadHistoryDto.setCustomizingTr(inputDTO.getCustomizingTr());
		 configUploadHistoryDto.setExecutionStartTime(executionStartTime);
		 //String cipherTextSapUser =  new String(java.util.Base64.getDecoder().decode(inputDTO.getSapUserId()));
		 String cipherTextSapPass =  new String(java.util.Base64.getDecoder().decode(inputDTO.getSapPassword()));
		 AesUtil aesUtil = new AesUtil(128, 1000);
			  
		   /* if (cipherTextSapUser != null && cipherTextSapUser.split("::").length == 3) {   
		    	inputDTO.setSapUserId(aesUtil.decrypt(cipherTextSapUser.split("::")[1], cipherTextSapUser.split("::")[0], inputDTO.getDestinationName(), cipherTextSapUser.split("::")[2]));
		      }*/
		    if (cipherTextSapPass != null && cipherTextSapPass.split("::").length == 3) {   
		    	inputDTO.setSapPassword(aesUtil.decrypt(cipherTextSapPass.split("::")[1], cipherTextSapPass.split("::")[0], inputDTO.getDestinationName(), cipherTextSapPass.split("::")[2]));
		      }
		 //Ended for Logging
		 inputDTO.setImplType("greenField");
		 inputDTO.setUpldABAPPrgPath(webAppPath1 + File.separator + "ACNIPIMG_UPLOAD.txt");
		 UploadResponseDto uploadResponseDto = new UploadResponseDto();
					if (flag) {
						uploadResponseDto = s4ImplObj.executeTargetSysConsolidation(inputDTO);
						recordCount = uploadResponseDto.getRecordCount();
						configUploadHistoryDto.setRecordCount(recordCount);

						if (uploadResponseDto.getResponseData() != null
								&& uploadResponseDto.getResponseData().size() >= 2) {
							if (uploadResponseDto.getResponseData().get(1).startsWith(inputDTO.getScopeName())) {
								String[] resTR = uploadResponseDto.getResponseData().get(1).split("\\|");
								if (resTR != null && resTR.length == 3) {
									configUploadHistoryDto.setCustomizingTr(resTR[1]);
									configUploadHistoryDto.setWorkbenchTr(resTR[2]);
								} else if (resTR != null && resTR.length == 2) {
									configUploadHistoryDto.setCustomizingTr(resTR[1]);
								}
								// uploadResponseDto.getResponseData().remove(1);//read and remove TR data from
								// Response
							}
						}

						responseDto.setResponseData(uploadResponseDto.getResponseData());
						responseDto.setConnectionStatus(uploadResponseDto.isDstConnectionStatus());
						if (uploadResponseDto.isDstConnectionStatus() && uploadResponseDto.isDstExecutionStatus()) {
							for (int i = 0, resSize = responseDto.getResponseData().size(); i < resSize; i++) {
								if (responseDto.getResponseData().get(i) != null
										&& !responseDto.getResponseData().get(i).equals("")) {
									String[] result = responseDto.getResponseData().get(i).split("~");
									String resultDescription = null, messageType = null;
									if (i == 0 && result.length > 1) {
										responseDto.setStatus(result[1].replaceAll("\\s+", ""));
									} else if (i == 1 && responseDto.getResponseData().get(i)
											.startsWith(inputDTO.getScopeName().split("-")[0])) {
										continue;
									} else {
										messageType = result[0];

										if (result.length > 1)
											resultDescription = result[1];
										excelFrmt = new JSONFormatDto();
										excelFrmt.setScopeName(inputDTO.getScopeName().split("-")[0]);
										excelFrmt.setDescription(resultDescription);
										excelFrmt.setErrorType(messageType);
										excelFrmt.setMessageType(messageType);
										dstResultsList.add(excelFrmt);

									}
								}
							}
							if(responseDto.getStatus().equalsIgnoreCase("Success")) {
								Connection con = null;
								ResultSet rs = null;
								PreparedStatement pStmt = null;
								try {
									String consolidationQry = "Insert into CONSOLIDATION_EXECUTION(IMGID, OBJECTNAME, SEQNO) values(?,?,?)";
	
									con = DBConnection.createConnection();
									pStmt = con.prepareStatement(consolidationQry);
									pStmt.setString(1, img);
									pStmt.setString(2, view);
									pStmt.setInt(3, seqno);
									pStmt.execute();
	
								} catch (SQLException e) {
									slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
								} finally {
									if (rs != null) {
										try {
											rs.close();
											rs = null;
										} catch (SQLException e) {
											slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
										}
									}
									if (pStmt != null) {
										try {
											pStmt.close();
											pStmt = null;
										} catch (SQLException e) {
											slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
										}
									}
									if (con != null) {
										try {
											con.close();
											con = null;
										} catch (SQLException e) {
											slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
										}
									}
	
								}
							}
						} else {
							responseDto.setStatus(ConstantsValues.ERRORSTATUS);
							excelFrmt = new JSONFormatDto();
							excelFrmt.setDescription(responseDto.getResponseData().get(0));
							excelFrmt.setErrorType("E");
							excelFrmt.setMessageType("E");
							excelFrmt.setScopeName(inputDTO.getScopeName());
							dstResultsList.add(excelFrmt);

						}
					}
		 else{
			 responseDto.setStatus(ConstantsValues.ERRORSTATUS); 
			 excelFrmt = new JSONFormatDto();
			 excelFrmt.setDescription("Dependency Table(s) is/are not successfully uploaded");
			 excelFrmt.setErrorType("E");
			 excelFrmt.setMessageType("E");
			 excelFrmt.setScopeName(inputDTO.getScopeName());
			 dstResultsList.add(excelFrmt);


		 }
		 
			 
			responseDto.setResult(dstResultsList);
			//Added for Logging
			configUploadHistoryDto.setStatus(responseDto.getStatus().equalsIgnoreCase("Success")?"S":"E");
			
			//Added for Upload Logs
			//if(inputDTO.isIMGHierarchy()){
			try{
				ConfigAuditDAO configAuditDao =  new ConfigAuditDAO();
				transactionId = configAuditDao.createConfigUploadHistory(configUploadHistoryDto);
				responseDto.setTranId(transactionId);
				if(transactionId > 0){
					for(int i = 0,arrSize = dstResultsList.size(); i< arrSize;i++){
						
						JSONFormatDto dto = dstResultsList.get(i);
					//Added for Upload Execution Logs
					uploadExecutionLogDto = new UploadExecutionLogDto();
					uploadExecutionLogDto.setConfigUploadID(transactionId);
					uploadExecutionLogDto.setMessage(dto.getDescription());
					uploadExecutionLogDto.setStatus(dto.getMessageType());
					uploadExecutionLogDto.setSequenceID(i+1);
					uploadExecutionLogList.add(uploadExecutionLogDto);
					}
					
					configAuditDao.createUploadExecutionLog(uploadExecutionLogList);
				}
			}catch(Exception e){
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
		//	}
			 //Ended for Logging
//		 }
			   //TransactionDetails.responseDto = responseDto;
			   /*TransactionDetails.imgId = null;
			   TransactionDetails.transId = 0;*/
			  // TransactionDetails.tranMap.put(responseDto.getScopeName(),true);
			   return responseDto;
		 
		 } 
		 else{
			 
			 responseDto.setStatus(ConstantsValues.ERRORSTATUS); 
			 excelFrmt = new JSONFormatDto();
			 excelFrmt.setDescription(ConstantsValues.DUPLICATEREQUEST);
			 excelFrmt.setErrorType("E");
			 excelFrmt.setMessageType("E");
			 excelFrmt.setScopeName(inputDTO.getScopeName());
			 dstResultsList.add(excelFrmt);
			 ResMessageDto resMessageDto = new ResMessageDto();
			 resMessageDto.setMessage(ConstantsValues.DUPLICATEREQUEST);
			 resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			 slf4jLogger.error(ConstantsValues.DUPLICATEREQUEST);
			 responseDto.setResMessageDto(resMessageDto);
			 responseDto.setConnectionStatus(true);
			 return responseDto;
		 }
		 }catch(Exception e){
			 slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			 return responseDto;
		 }
		 finally{
			   //TransactionDetails.tranMap.remove(responseDto.getScopeName());
			   slf4jLogger.info("performConsolidation service ended");

		 }
		  }
		 else{
			 ResMessageDto resMessageDto = new ResMessageDto();
			 resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			 resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			 slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			 responseDto.setResMessageDto(resMessageDto);
			 return responseDto;
		 }
	  }
	 
	 
	 
	/* Copy Functionality */
     
	@Path("copyFunctionalityConfigWithoutIntervention")
	@Consumes(MediaType.APPLICATION_JSON)
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public ServiceResponseDto copyFunctionalityConfigWithoutIntervention(@Valid CopyFuntionalityInputDto autoConfigInputDto,
			@Context HttpServletRequest request) {
		slf4jLogger.info("without intervention service started");
		String currentScope = autoConfigInputDto.getImgID() + autoConfigInputDto.getTransactionID();
		ServiceResponseDto responseDto = new ServiceResponseDto();
		List<String> roleIdList = new ArrayList<>();
		roleIdList.add(ConstantsValues.CONFIG);
		RoleValidationDto roleValidationDto = new RoleValidationDto();
		roleValidationDto.setRoleIdList(roleIdList);
		roleValidationDto.setOmId(autoConfigInputDto.getOmgID());
		JSONFormatDto excelFrmt = null;
		ArrayList<JSONFormatDto> dstResultsList = new ArrayList<>();
		
		if (UserSessionDao.isSessionActive(autoConfigInputDto.getSessionInputDTO(), roleValidationDto)) {
			
			try {
				if (validRequest(currentScope, autoConfigInputDto.getExeReqCount())) {
					



					/*		 TransactionDetails.imgId = autoConfigInputDto.getImgID();
							 TransactionDetails.transId = autoConfigInputDto.getTransactionID();
							 TransactionDetails.tranMap.put(currentScope,false);*/
						//Added for Logging
						 int transactionId = 0;
						 ConfigAuditDAO configAuditDao =  new ConfigAuditDAO();
						 ConfigDownloadHistoryDto  configDownloadHistoryDto  = null;
						 ConfigUploadHistoryDto  configUploadHistoryDto  = null;
						 ArrayList<UploadExecutionLogDto> uploadExecutionLogList = null ;
						 UploadExecutionLogDto uploadExecutionLogDto =  null;
						//Ended for Logging
						 DownloadScopeResDto downloadScopeResDto = null;
						 ImgHierarchyDAO imgHierarchyDAO = new ImgHierarchyDAO();
						 S4AutoConfExecution s4ImplObj = null;
						 String webAppPath = null;
						 String downloadPrgPath = null;
						 DownloadResponseDto downloadResponseDto = null;
						 ImgDownloadDto imgDownloadDto = null;
						 int resDataLen = 0;
						 UploadResponseDto uploadResponseDto = null;
						 HashMap<String,String> filterMap = null;
						 IMGFilterDao imgFilterDao = null;
						 ImgFilterResponseDTO imgFilterResponseDTO = null;
						 HashMap<String, ArrayList<String>> copyFromTo=null;
						 ArrayList<String> allToValues=null;
						 ArrayList<String> finalToValues=null;
						 String errorMsg="";
						 ArrayList<String> from=null;
						 Boolean warning=false;
						 Boolean success=false;
						 ArrayList<String> errorToValues=null;
						 ArrayList<String> fromValue=null;
						 ArrayList<String> valueTo=null;
						 ArrayList<String> valueToFinal=null;
						 Date date = new java.util.Date();
						 Timestamp executionStartTime = new java.sql.Timestamp(date.getTime());
						 try{
							 copyFromTo=new HashMap<String, ArrayList<String>>();
							 for(HashMap<String, ArrayList<String>> x:autoConfigInputDto.getCopyDetails())
							 {
								 fromValue=new ArrayList<String>();
								 valueTo=new ArrayList<String>();
								 valueToFinal=new ArrayList<String>();

								 fromValue.addAll(x.keySet());
								 String frm=fromValue.get(0);
								 valueTo.addAll(x.get(frm));
								 for(String to:valueTo)
								 {
									 if(!to.isEmpty())
									 valueToFinal.add(to);
								 }
								 x.put(frm, valueToFinal);
								 if(copyFromTo.containsKey(frm))
								 {
									 copyFromTo.get(frm).addAll(copyFromTo.get(frm).size(), x.get(frm));
								 }
								 else
								 copyFromTo.putAll(x);
								 fromValue=null;
							 }
							/*
						 * //copyFromTo=autoConfigInputDto.getCopyFromTo();
						 * 
						 * //Hard code Test Value CopyFromTo ArrayList<String> To1= new
						 * ArrayList<String>(); To1.add("1043"); To1.add("1044");
						 * copyFromTo.put("1042",To1); ArrayList<String> To2= new ArrayList<String>();
						 * To2.add("1014"); To2.add("1015"); To2.add("1016");
						 * copyFromTo.put("1013",To2); ArrayList<String> To2= new ArrayList<String>();
						 * To2.add("1015"); copyFromTo.put("1013",To2); //----copyFromTo
						 */ 
						allToValues=new ArrayList<String>();
						from= new ArrayList<String>();
						from.addAll(copyFromTo.keySet());
						for (String i : from) {
							for (String to : copyFromTo.get(i)) {
								if (to.isEmpty())
									break;
								allToValues.add(to);
							}
						}
							 imgFilterDao = new IMGFilterDao();
				        	 responseDto.setScopeName(autoConfigInputDto.getImgID()+autoConfigInputDto.getTransactionID());
				        	 imgDownloadDto = autoConfigInputDto.getImgDownloadDtoObj();
							
							 downloadScopeResDto = imgHierarchyDAO.getInputStringForInstalledBaseCopyFunctionality(autoConfigInputDto.getImgID(),autoConfigInputDto.getSourceSystemID(),imgDownloadDto.getImgDescription(),imgDownloadDto.getSequence());
							 if(downloadScopeResDto.getScopeAvailable().equals("N")){
								 	excelFrmt = new JSONFormatDto();
								 	excelFrmt.setScopeName(autoConfigInputDto.getImgID());
									excelFrmt.setDescription("Scope Data not available in the Source System");
									excelFrmt.setErrorType("E");
									excelFrmt.setMessageType("E");
									dstResultsList.add(excelFrmt);
				    				responseDto.setResult(dstResultsList);
				    				return responseDto;
							 }
					
						   else{
							
						  // slf4jLogger.error("else block execution");
						   String key = "RRn4PlfhPT6rXtZP";
						   
						   						   
						   s4ImplObj = new S4AutoConfExecution();
						   webAppPath = request.getServletContext().getRealPath("/WEB-INF");
						   String webAppPath1 = request.getServletContext().getRealPath("/src/css");
							
							 File encryptedFile=new File(webAppPath+"/ACNIPIMG_DOWNLOAD.txt");
							 File  decryptedFile = new File(webAppPath1+"/ACNIPIMG_DOWNLOAD.txt");
							 
																	
							  try {
							    	
								  //slf4jLogger.info("before decryption");
								  AESEncrypt.decrypt(key, encryptedFile,decryptedFile);
								  //slf4jLogger.info("after  decryption");
							    } catch (CryptoException ex) {
							       // System.out.println(ex.getMessage());
							        ex.printStackTrace();
							    }
							   
				           downloadPrgPath = webAppPath1 + File.separator + "ACNIPIMG_DOWNLOAD.txt";
				           downloadResponseDto = new DownloadResponseDto();
				          
				        	   configDownloadHistoryDto = new ConfigDownloadHistoryDto();//Added for Logging
				        	   BwnFieldResDto bwnFieldResDto =  new BwnFieldResDto();
				        	   bwnFieldResDto.setImgId(imgDownloadDto.getImgId());
				        	   bwnFieldResDto.setImgDescription(imgDownloadDto.getImgDescription());
				        	   downloadResponseDto = s4ImplObj.executeSrcConfigDownloadCopyFunctionality(copyFromTo,autoConfigInputDto.getSrcDestination(), downloadPrgPath,downloadScopeResDto.getImgScope(),autoConfigInputDto.getHostName(),
				        			   autoConfigInputDto.getClientNo(),autoConfigInputDto.getSysNo(),autoConfigInputDto.getSapUserId(),autoConfigInputDto.getSapPassword(),autoConfigInputDto.getSapLanguage());
				        	   
				        	   bwnFieldResDto.setConStatus(downloadResponseDto.isSrcConnectionStatus());
				        	   bwnFieldResDto.setExeStatus(downloadResponseDto.isSrcExecutionStatus());
				        	   

				             if(downloadResponseDto.isSrcExecutionStatus() && downloadResponseDto.isSrcConnectionStatus()){
				            	 if(downloadResponseDto.getDownloadRes().size()> 0)//Remove S~Success or E~Error
				            	 	downloadResponseDto.getDownloadRes().remove(0);//Added on 5 June 2017
				            	 if(downloadResponseDto.getDownloadRes().size()> 0 && downloadResponseDto.getDownloadRes().get(0).startsWith("M~"))
				            		 downloadResponseDto.getDownloadRes().remove(0);//Remove M~ Message
				            	// String imgTRnumber = downloadResponseDto.getDownloadRes().get(0)+ "|" + autoConfigInputDto.getTrNumber();
				            	 //downloadResponseDto.getDownloadRes().set(0, imgTRnumber);
				            	 //slf4jLogger.error(downloadResponseDto.getDownloadRes().get(0));
				            	 bwnFieldResDto.setImgData(downloadResponseDto.getDownloadRes());
				            	 slf4jLogger.debug("Downloaded Config Size : "+downloadResponseDto.getDownloadRes());
				            	 //slf4jLogger.error(downloadResponseDto.getDownloadRes() + " data ");
				            	 configDownloadHistoryDto.setStatus("S");//Added for Logging
//				            	 bwnFieldResDto.setImgData((ArrayList<String>) downloadResponseDto.getDownloadRes().subList(1, downloadResponseDto.getDownloadRes().size()));
				            	 S4AutoConfigReqDto inputDTO = new S4AutoConfigReqDto();
				                 inputDTO.setConfigDataList(bwnFieldResDto.getImgData());
				                 String webAppPath2 = request.getServletContext().getRealPath("/src/css");
				        		 //slf4jLogger.info("filepath"+webAppPath);
				        		 //slf4jLogger.info("filepath"+webAppPath);
				        		 File encryptedFile1=new File(webAppPath+"/ACNIPIMG_UPLOAD.txt");
				        		 File  decryptedFile1 = new File(webAppPath2+"/ACNIPIMG_UPLOAD.txt");
				        		  try {
				        		    	//AESEncrypt.encrypt(key, inputFile, encryptedFile);
				        			  //slf4jLogger.info("before decryption");
				        			  AESEncrypt.decrypt(key, encryptedFile1,decryptedFile1);
				        			 // slf4jLogger.info("after  decryption");
				        		    } catch (CryptoException ex) {
				        		       // System.out.println(ex.getMessage());
				        		        ex.printStackTrace();
				        		    }inputDTO.setUpldABAPPrgPath(webAppPath2 + File.separator + "ACNIPIMG_UPLOAD.txt");
				                    inputDTO.setDestinationName(autoConfigInputDto.getTgtDestination());
				                    inputDTO.setScopeName(bwnFieldResDto.getImgId());
				                    inputDTO.setTranId(autoConfigInputDto.getTransactionID());
				                    inputDTO.setSncEnabled(autoConfigInputDto.getSncEnabled());
				                    inputDTO.setSncName(autoConfigInputDto.getSncName());
				                    inputDTO.setSncPartnerName(autoConfigInputDto.getSncPartnerName());
				                    inputDTO.setSncProtectionLevel(autoConfigInputDto.getSncProtectionLevel());
				                    inputDTO.setSapRouter(autoConfigInputDto.getSapRouter());
				                    // changes for dynamic destination for BrownField Upload
				                    inputDTO.setIsCustomDestinationRequired(autoConfigInputDto.getIsCustomDestinationRequired());
				                  //  String cipherTextSapUser =  new String(java.util.Base64.getDecoder().decode(autoConfigInputDto.getSapUserId()));
				           		 String cipherTextSapPass =  new String(java.util.Base64.getDecoder().decode(autoConfigInputDto.getSapPassword()));
				           		 AesUtil aesUtil = new AesUtil(128, 1000);
				           			  
				           		   /* if (cipherTextSapUser != null && cipherTextSapUser.split("::").length == 3) {   
				           		    	inputDTO.setSapUserId(aesUtil.decrypt(cipherTextSapUser.split("::")[1], cipherTextSapUser.split("::")[0], autoConfigInputDto.getTgtDestination(), cipherTextSapUser.split("::")[2]));
				           		      }*/
				           		    if (cipherTextSapPass != null && cipherTextSapPass.split("::").length == 3) {   
				           		    	inputDTO.setSapPassword(aesUtil.decrypt(cipherTextSapPass.split("::")[1], cipherTextSapPass.split("::")[0], autoConfigInputDto.getTgtDestination(), cipherTextSapPass.split("::")[2]));
				           		      }
				                  //  inputDTO.setSapPassword(autoConfigInputDto.getSapPassword());
				                   // inputDTO.setSapUserId(autoConfigInputDto.getSapUserId());
				                   // Passing TR Number from brownfield to ABAP
				                    //inputDTO.setTrNumber(autoConfigInputDto.getTrNumber());
				           		 inputDTO.setSapUserId(autoConfigInputDto.getSapUserId());
				           		 inputDTO.setSapLanguage(autoConfigInputDto.getSapLanguage());
				           		 inputDTO.setHostName(autoConfigInputDto.getHostName());
				           		 inputDTO.setSapPassword(autoConfigInputDto.getSapPassword());
				           		 inputDTO.setSapClientNo(autoConfigInputDto.getClientNo());
				           		 inputDTO.setSystemNo(autoConfigInputDto.getSysNo());
				           		
				                    inputDTO.setCustomizingTr(autoConfigInputDto.getCustomizingTr());
				                    inputDTO.setWorkbenchTr(autoConfigInputDto.getWorkbenchTr());
				                   // inputDTO.setTransactionDTO(transactionDTO);
				                    
				                 uploadResponseDto = new UploadResponseDto();
				                 uploadResponseDto = s4ImplObj.checkTargetSysConfigCopyFunctionality(downloadScopeResDto.getCopyToCheck(),copyFromTo, inputDTO);
				                 errorToValues=new ArrayList<String>();
				                
				                 for(String x:uploadResponseDto.getResponseData())
				                 {
				                	 if(x.startsWith("E"))
				                	 {
				                		    String toValue=x.substring(x.indexOf("~")+1,x.lastIndexOf("~"));
				             
				                			for(String i:from)
				                			{
				                				for(String to: copyFromTo.get(i))
				                				{
				                					if(to.equals(toValue)) {
				                						errorToValues.add(to);
				                					}
				                				}
				                				copyFromTo.get(i).remove(toValue);
		             				
				                			}
				                	 }
				                 }
				                 finalToValues=new ArrayList<String>();
				                 finalToValues.addAll(allToValues);
				                 finalToValues.removeAll(errorToValues);
								if (errorToValues.size() != allToValues.size()) {
									uploadResponseDto = null;
									uploadResponseDto = new UploadResponseDto();
									filterMap = imgFilterDao
											.getIMGFilterValuesCopyFunctionality(autoConfigInputDto.getImgID());
									if (filterMap.isEmpty()) {
										slf4jLogger.error("Without filter ");
										excelFrmt = new JSONFormatDto();
										excelFrmt.setScopeName(imgDownloadDto.getImgId());
										excelFrmt.setDescription("Filter criteria is not maintained for the template in Document Repository, please contact Administrator!!");
										excelFrmt.setErrorType("E");
										excelFrmt.setMessageType("E");
										dstResultsList.add(excelFrmt);
										responseDto.setResult(dstResultsList);
										return responseDto;
									} else {

										// added to retrieve configurable data based on filter criteria maintained
										slf4jLogger.error("With filter ");

										imgFilterResponseDTO = s4ImplObj.getFilteredConfigDataforCopyFunctinality(
												imgDownloadDto, downloadResponseDto, filterMap, copyFromTo);
									
										inputDTO.setImplType("FilterData");
										if (imgFilterResponseDTO.isStatus()) {
											inputDTO.setWorkbook(imgFilterResponseDTO.getExcelWorkbook());
											uploadResponseDto = s4ImplObj
													.executeTargetSysConfigCopyFunctionality(inputDTO);
											if(uploadResponseDto.getResponseData().get(0).equals("E~Error"))
											{
												if(uploadResponseDto.getResponseData().get(1).startsWith("S~")) {
													success=true;
												}
											
												for(String msg: uploadResponseDto.getResponseData())
												{
													if(msg.startsWith("E~"))
														errorMsg=errorMsg+msg.substring(msg.indexOf("~"))+"\n";
												}
											}
											if(uploadResponseDto.getResponseData().get(0).equals("S~Success") && !errorToValues.isEmpty())
												warning=true;
																							
										} else {
											excelFrmt = new JSONFormatDto();
											excelFrmt.setScopeName(imgDownloadDto.getImgId());
											excelFrmt.setDescription(imgFilterResponseDTO.getErrDetails());
											excelFrmt.setErrorType("E");
											excelFrmt.setMessageType("E");
											dstResultsList.add(excelFrmt);
											responseDto.setResult(dstResultsList);
											return responseDto;
										}
									}
									for(String to:errorToValues)
									{
										uploadResponseDto.getResponseData().add("E~Plant "+to+" Exists in the System");
									}
								}
								else
								{
									uploadResponseDto.getResponseData().clear();
									uploadResponseDto.getResponseData().add("E~Error");
									for(String to:errorToValues)
									{
										uploadResponseDto.getResponseData().add("E~Plant "+to+" Exists in the System");
									}
								}
				   		      	 
				   		      	 //transactionDTO = uploadResponseDto.getTransactionDTO();
				                 configUploadHistoryDto = new ConfigUploadHistoryDto();
				                 if(uploadResponseDto.getResponseData() != null && uploadResponseDto.getResponseData().size() >=2){
				        			 if(uploadResponseDto.getResponseData().get(1).startsWith(inputDTO.getScopeName())){
				        				 String[] resTR = uploadResponseDto.getResponseData().get(1).split("\\|");
				        				 if(resTR != null && resTR.length == 3){
				        					 configUploadHistoryDto.setCustomizingTr(resTR[1]);
				        					 configUploadHistoryDto.setWorkbenchTr(resTR[2]);
				        				 }else if(resTR != null && resTR.length == 2){
				        					 configUploadHistoryDto.setCustomizingTr(resTR[1]);
				        				 }
				        				 //uploadResponseDto.getResponseData().remove(1);//read and remove TR data from Response
				        			 }
				        		 }
				                 
				                 responseDto.setResponseData(uploadResponseDto.getResponseData());
				                 responseDto.setConnectionStatus(uploadResponseDto.isDstConnectionStatus());
				                 responseDto.setExecutionStatus(uploadResponseDto.isDstExecutionStatus());
				                 resDataLen = responseDto.getResponseData().size();
				      				for (int k = 0; k < resDataLen; k++) {
				  							excelFrmt = new JSONFormatDto();

				      						if (responseDto.getResponseData().get(k) != null && !responseDto.getResponseData().get(k).equals("")) {
				      							String[] result = responseDto.getResponseData().get(k).split("~");
				      							String  resultDescription  = null, messageType = null;
				      							if(k==0 && result.length > 1){
				      								responseDto.setStatus(result[1].replaceAll("\\s+",""));
				      							}
				      							
				      							else if(resDataLen == 1){
				      							//messageType = result[0];
				      						   /* if( result.length > 1) 
				      						    	resultDescription = result[1]; */
				      							excelFrmt.setScopeName(inputDTO.getScopeName());
				      							excelFrmt.setDescription(result[0]);
				      							excelFrmt.setErrorType("E");
				      							excelFrmt.setMessageType("E");
				      							dstResultsList.add(excelFrmt);
				      							}
				      							else if(k==1 && responseDto.getResponseData().get(k).startsWith(imgDownloadDto.getImgId())){
				      								continue;
				      							}
				      							else {
				          							messageType = result[0];
				          						    if( result.length > 1) 
				          						    	resultDescription = result[1]; 
				          						   // AppUtils appUtilsObj = new AppUtils();
				          							//Properties propin = appUtilsObj.fnReadPropertyFile(); 
				          							//resultCode = propin.getProperty(result[0]);
				          							excelFrmt.setScopeName(inputDTO.getScopeName());
				          							excelFrmt.setDescription(resultDescription);
				          							excelFrmt.setErrorType(messageType);
				          							excelFrmt.setMessageType(messageType);
				          							dstResultsList.add(excelFrmt);
				          							}
				      						}
				      				}
				      				responseDto.setResult(dstResultsList);
				      				
				   	             
				   		     }else{

				   		/*		dependencymet = imgHierarchyDao.getDependencyScope(autoConfigInputDto.getImgDownloadDto(),autoConfigInputDto.getImgID());
				   				if(!dependencymet){
				   						excelFrmt = new JSONFormatDto();
				   						excelFrmt.setScopeName(imgDownloadDto.getImgId());
				   						excelFrmt.setDescription("Dependency not met");
				   						excelFrmt.setErrorType("E");
				   						excelFrmt.setMessageType("E");
				   						dstResultsList.add(excelFrmt);
				   						responseDto.setResult(dstResultsList);
				   						return responseDto; 
				   					}else{*/
				   						excelFrmt = new JSONFormatDto();
				   	   				 	excelFrmt.setScopeName(imgDownloadDto.getImgId());
				   	   					excelFrmt.setDescription(downloadResponseDto.getErrorDetails());
				   	   					excelFrmt.setErrorType("E");
				   	   					excelFrmt.setMessageType("E");
				   	   					//responseDto.setConnectionStatus(true);
				   	   					dstResultsList.add(excelFrmt);
				   	   					responseDto.setResult(dstResultsList);
				   	   				configUploadHistoryDto = new ConfigUploadHistoryDto();
				   	   				configUploadHistoryDto.setImgID(autoConfigInputDto.getImgID());
				   	   				configUploadHistoryDto.setTransactionID(autoConfigInputDto.getTransactionID());
				   	   				configUploadHistoryDto.setProjectName(autoConfigInputDto.getProjectName());
				   	   				configUploadHistoryDto.setScenario(autoConfigInputDto.getScenario());
				   	   				configUploadHistoryDto.setOmgID(autoConfigInputDto.getOmgID());
				   	   				configUploadHistoryDto.setSystemID(autoConfigInputDto.getSystemID());
				   	   				configUploadHistoryDto.setUserID(autoConfigInputDto.getUserID());
				   	   				configUploadHistoryDto.setModule(autoConfigInputDto.getModule());
				   	   				configUploadHistoryDto.setExecutionStartTime(executionStartTime);
				   				 	if(responseDto.getStatus() != null && responseDto.getStatus() != "")
				   				 		configUploadHistoryDto.setStatus(responseDto.getStatus().equalsIgnoreCase("Success")?"S":"E");
				   				 	else
				   				 		configUploadHistoryDto.setStatus("E");
				   				
				   				//Added for Upload Logs
				   				 	if(autoConfigInputDto.isIMGHierarchy()){
				   					try{
				   						
				   						transactionId = configAuditDao.createConfigUploadHistory(configUploadHistoryDto);
				   						if(transactionId > 0){
				   							uploadExecutionLogList = new ArrayList<>();
				   							for(int i = 0,arSize = dstResultsList.size(); i< arSize;i++){
				   								
				   								JSONFormatDto dto = dstResultsList.get(i);
				   							//Added for Upload Execution Logs
				   							uploadExecutionLogDto = new UploadExecutionLogDto();
				   							uploadExecutionLogDto.setConfigUploadID(transactionId);
				   							uploadExecutionLogDto.setImgID(autoConfigInputDto.getImgID());
				   							uploadExecutionLogDto.setMessage(dto.getDescription());
				   							uploadExecutionLogDto.setStatus(dto.getMessageType());
				   							uploadExecutionLogDto.setUserID(autoConfigInputDto.getUserID());
				   							uploadExecutionLogDto.setSequenceID(i+1);
				   							uploadExecutionLogList.add(uploadExecutionLogDto);
				   							}
				   							
				   							configAuditDao.createUploadExecutionLog(uploadExecutionLogList);

				   						}
				   						
				   					}catch(Exception e){
				   						slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				   					}
				   					finally{
				   						
				   					}
				   		     }
				   				 	
				   	   					return responseDto; 
				   					//}
				   						
				   			
								}
				             
				
				            if(success || responseDto.getStatus().equalsIgnoreCase("Success")) {
				            	
				            	List<String> toValues=new ArrayList<String>();
				            	List<String> fromValues= new ArrayList<String>();
				            	fromValues.addAll(copyFromTo.keySet());
								for (String i : fromValues) {
									for (String to : copyFromTo.get(i)) {
										if (to.isEmpty()) {
											break;
										}
										toValues.add(to);
									}
								}
				            	if(toValues!=null && !toValues.isEmpty()) {
					            String sql = "INSERT INTO CLIENT_COPYVALUES (IMGID, OMID, VALUE, COMPLETED, ERROR, COUNT) VALUES (?,?,?,?,?,?)";
				            	Connection con = null;
				        		PreparedStatement ps=null;
				        		ArrayList<String> childImgs = new ArrayList<>();
				        		childImgs=s4ImplObj.findChildImgs(autoConfigInputDto.getImgID());
				        	
				            	try {
				            		con =  DBConnection.createConnection();
				            		ps = con.prepareStatement(sql);
										for (String img : childImgs) {

											if (img.equalsIgnoreCase("SIMG_DUMMY_LANG")) {
												for (String fromPlant : fromValues) {
													ps.setString(1, img);
													ps.setString(2, autoConfigInputDto.getOmgID());
													ps.setString(3, fromPlant);
													ps.setBoolean(4, false);
													ps.setString(5, errorMsg);
													ps.setInt(6, 5);
													ps.execute();
												}
											} else {
												for (String toPlant : toValues) {

													ps.setString(1, img);
													ps.setString(2, autoConfigInputDto.getOmgID());
													ps.setString(3, toPlant);
													ps.setBoolean(4, false);
													ps.setString(5, errorMsg);
													ps.setInt(6, 1);
													ps.execute();
												}
											}
										}
				            	}catch (SQLException e){
				            		slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				            	
				            	}finally {
				            		if(ps!=null){
				        				try {
				        					ps.close();
				        					ps=null;
				        					} catch (SQLException e) {
				        					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				        				}
				        			}
				            	}
				            	}
				            }
				            //Added for Logging 
							 configUploadHistoryDto.setImgID(autoConfigInputDto.getImgID());
							 configUploadHistoryDto.setTransactionID(autoConfigInputDto.getTransactionID());
							 configUploadHistoryDto.setProjectName(autoConfigInputDto.getProjectName());
							 configUploadHistoryDto.setScenario(autoConfigInputDto.getScenario());
							 configUploadHistoryDto.setOmgID(autoConfigInputDto.getOmgID());
							 configUploadHistoryDto.setSystemID(autoConfigInputDto.getSystemID());
							 configUploadHistoryDto.setUserID(autoConfigInputDto.getUserID());
							 configUploadHistoryDto.setModule(autoConfigInputDto.getModule());
				   			 configUploadHistoryDto.setExecutionStartTime(executionStartTime);
				   			 configUploadHistoryDto.setRecordCount(uploadResponseDto.getRecordCount());

							 	if(responseDto.getStatus() != null && responseDto.getStatus() != "")
							 		configUploadHistoryDto.setStatus(responseDto.getStatus().equalsIgnoreCase("Success")?"S":"E");
							 	else
							 		responseDto.setStatus("E");
							
							//Added for Upload Logs
								try{
									
									transactionId = configAuditDao.createConfigUploadHistory(configUploadHistoryDto);
									if(transactionId > 0){
										uploadExecutionLogList = new ArrayList<>();
										for(int i = 0,arSize = dstResultsList.size(); i< arSize;i++){
											
											JSONFormatDto dto = dstResultsList.get(i);
										//Added for Upload Execution Logs
										uploadExecutionLogDto = new UploadExecutionLogDto();
										uploadExecutionLogDto.setConfigUploadID(transactionId);
										uploadExecutionLogDto.setImgID(autoConfigInputDto.getImgID());
										uploadExecutionLogDto.setMessage(dto.getDescription());
										uploadExecutionLogDto.setStatus(dto.getMessageType());
										uploadExecutionLogDto.setUserID(autoConfigInputDto.getUserID());
										uploadExecutionLogDto.setSequenceID(i+1);
										uploadExecutionLogList.add(uploadExecutionLogDto);
										}
										
										configAuditDao.createUploadExecutionLog(uploadExecutionLogList);

					}
									
								}catch(Exception e){
									slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
								}
								finally{
									
								}
					          }
						 }catch(Throwable e){
							 slf4jLogger.error("Exception occured !!");
							 slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
						 }finally{
							 imgHierarchyDAO = null;
							 downloadScopeResDto = null;
							 dstResultsList = null;
							 excelFrmt = null;
							 s4ImplObj = null;
							 webAppPath = null;
							 downloadPrgPath = null;
							 downloadResponseDto = null;
							 imgDownloadDto = null;
							 uploadResponseDto = null;

						 }

						   
						   //TransactionDetails.responseDto = responseDto;
						   /*TransactionDetails.imgId = null;
						   TransactionDetails.transId = 0;*/
						  // TransactionDetails.tranMap.put(responseDto.getScopeName(),true);
						   //TransactionDetails.isExecuted = true;
						   //transactionDTO.setResponseDto(responseDto);
						 if(warning)
			   				 	responseDto.setStatus("Warning");
				           return responseDto;
				           
						 
					

				} else {

					responseDto.setStatus(ConstantsValues.ERRORSTATUS);
					excelFrmt = new JSONFormatDto();
					excelFrmt.setDescription(ConstantsValues.DUPLICATEREQUEST);
					excelFrmt.setErrorType("E");
					excelFrmt.setMessageType("E");
					excelFrmt.setScopeName(autoConfigInputDto.getImgID());
					dstResultsList.add(excelFrmt);
					ResMessageDto resMessageDto = new ResMessageDto();
					resMessageDto.setMessage(ConstantsValues.DUPLICATEREQUEST);
					resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
					slf4jLogger.error(ConstantsValues.DUPLICATEREQUEST);
					responseDto.setResMessageDto(resMessageDto);
					responseDto.setConnectionStatus(true);
					return responseDto;

				}

			} catch (Exception e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
				slf4jLogger.info("configDownload service ended");
				return responseDto;
			} finally {
				String webAppPath2 = request.getServletContext().getRealPath("/src/css");
				File file = new File(webAppPath2 + "/ACNIPIMG_DOWNLOAD.txt");
				File file1 = new File(webAppPath2 + "/ACNIPIMG_UPLOAD.txt");
				file.delete();
				file1.delete();
			}
		} else {

			ResMessageDto resMessageDto = new ResMessageDto();
			resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			responseDto.setResMessageDto(resMessageDto);
			return responseDto;
		}
		
	}
	
	 
	 @Path("getDownloadscope")
	 @Consumes(MediaType.APPLICATION_JSON)
	 @POST
	 @Produces(MediaType.APPLICATION_JSON)
	 public ServiceResponseDto getDownloadscope(@Valid ScopeCheckReqDto scopeCheckReqDto){
		 slf4jLogger.info("getDownloadscope service started");
		 ServiceResponseDto serviceResponseDto = new ServiceResponseDto();
		 List<String> roleIdList = new ArrayList<>();
	  	 roleIdList.add(ConstantsValues.CONFIG);
	  	 RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	 roleValidationDto.setRoleIdList(roleIdList);
		 try{
		 if(UserSessionDao.isSessionActive(scopeCheckReqDto.getSessionInputDTO(),roleValidationDto)){
		 ImgHierarchyDAO imgHierarchyDAO = new ImgHierarchyDAO();
		 ArrayList<ScopeCheckResDto> scopeCheckResDtoList = new ArrayList<ScopeCheckResDto>();
		 ArrayList<IMGScopeDto> imgScopeDtoList = scopeCheckReqDto.getImgScopeDto();
		 DownloadScopeResDto downloadScopeResDto = null;
		 
		 for(int i=0,scopeSize = imgScopeDtoList.size(); i< scopeSize ; i++){
			 if(scopeCheckReqDto.getCopyFlag()) {
				 downloadScopeResDto = imgHierarchyDAO.getInputStringForBrownFldCopyFunctionality(imgScopeDtoList.get(i).getImgId(),scopeCheckReqDto.getSystemType());
			 }	 
			 else if(scopeCheckReqDto.isIndustryFlag()) {
				 downloadScopeResDto = imgHierarchyDAO.getInputStringForBrownFldForIndustry(imgScopeDtoList.get(i).getImgId(), scopeCheckReqDto.getSystemType(), scopeCheckReqDto.getIndustry(), scopeCheckReqDto.getSubIndustry());
			 }else {
				 downloadScopeResDto = imgHierarchyDAO.getInputStringForBrownFld(imgScopeDtoList.get(i).getImgId(),scopeCheckReqDto.getSystemType());
			 }
				 
			 
			 ScopeCheckResDto ScopeCheckResDto = new ScopeCheckResDto();
			 ScopeCheckResDto.setScopeAvailable(downloadScopeResDto.getScopeAvailable());
			 ScopeCheckResDto.setImgScope(downloadScopeResDto.getImgScope());
			 ScopeCheckResDto.setImgScopeDto(imgScopeDtoList.get(i));
			 scopeCheckResDtoList.add(ScopeCheckResDto);
		 }
		 serviceResponseDto.setListScopeCheckResDto(scopeCheckResDtoList);
		 return serviceResponseDto;
		 }
	 
		 else{
			 ResMessageDto resMessageDto = new ResMessageDto();
			 resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			 slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			 resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			 serviceResponseDto.setResMessageDto(resMessageDto);
			 return serviceResponseDto;
		 }
		 }catch(Exception e){
			 slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			 ResMessageDto resMessageDto = new ResMessageDto();
			 resMessageDto.setMessage(e.getMessage());
			 resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			 serviceResponseDto.setResMessageDto(resMessageDto);
			 return serviceResponseDto;
		 }finally{
			  slf4jLogger.info("getDownloadscope service ended");
		 }
	 }
	 
	 
	 /*Brown Field Modification Service*/
	 
	 @Path("getDwldScopeForBrwnMod")
	 @Consumes(MediaType.APPLICATION_JSON)
	 @POST
	 @Produces(MediaType.APPLICATION_JSON)
	 public  ImgHierarchyCustomDto getDwldScopeForBrwnMod(@Valid BrownFieldModDownloadDto brownFieldModDownloadDto, @Context HttpServletRequest request){
		 ImgHierarchyCustomDto modCustomDto = new ImgHierarchyCustomDto();
		 slf4jLogger.info("getDwldScopeForBrwnMod service started");
		 try{
		List<String> roleIdList = new ArrayList<>();
		roleIdList.add(ConstantsValues.CONFIG);
		RoleValidationDto roleValidationDto = new RoleValidationDto();
		roleValidationDto.setRoleIdList(roleIdList);
		 roleValidationDto.setOmId(brownFieldModDownloadDto.getOmgID());
		 if(UserSessionDao.isSessionActive(brownFieldModDownloadDto.getSessionInputDTO(),roleValidationDto)){
		 S4AutoConfExecution autoConfigExecution = new S4AutoConfExecution();
		 modCustomDto = autoConfigExecution.getDwldScopeForBrwnMod(brownFieldModDownloadDto, request);
		 return modCustomDto;
		 }
		 else{
			 ResMessageDto resMessageDto = new ResMessageDto();
			 resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			 slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			 resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			 modCustomDto.setResMessageDto(resMessageDto);
			 return modCustomDto;
		 }
		}catch(Exception e){
			 slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			 ResMessageDto resMessageDto = new ResMessageDto();
			 resMessageDto.setMessage(e.getMessage());
			 resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			 modCustomDto.setResMessageDto(resMessageDto);
			 return modCustomDto;
		}finally{
			slf4jLogger.info("getDwldScopeForBrwnMod service ended");

		}
	 }
	 @Path("getPlantCheck")
     @Consumes(MediaType.APPLICATION_JSON)
     @POST
     @Produces(MediaType.APPLICATION_JSON)
     public  ImgHierarchyCustomDto getPlantCheck(@Valid BrownFieldModDownloadDto brownFieldModDownloadDto, @Context HttpServletRequest request){
         ImgHierarchyCustomDto modCustomDto = new ImgHierarchyCustomDto();
         slf4jLogger.info("Check Plant service started");
		try {
			// modCustomDto=brownFieldModDownloadDto.getImgHierarchyCustomDto();
			S4AutoConfExecution autoConfigExecution = new S4AutoConfExecution();
			CheckToPlantDto checkToPlantDto = new CheckToPlantDto();
			ArrayList<String> toPlantsList = new ArrayList<String>();
			ArrayList<String> validImgList = new ArrayList<String>();
			List<String> imgList = brownFieldModDownloadDto.getImgList();
			String finalError="";
			List<String> errorList = new ArrayList<String>();
			if (imgList != null && !imgList.isEmpty()) {
				for (String imgId : imgList) {
					// String parentImg = autoConfigExecution.findParentImg(imgId);
					checkToPlantDto = autoConfigExecution.checkToPlants(imgId, brownFieldModDownloadDto.getOmId());
					toPlantsList = checkToPlantDto.getToPlantsList();
					if (!toPlantsList.isEmpty()) {
						validImgList.add(imgId);
						for(String e: checkToPlantDto.getError().keySet())
						{
							finalError=imgId+" - Error for Plant(s) "+checkToPlantDto.getError().get(e)+"-"+e;
							errorList.add(finalError);
						}
						
							
					}
				}
				modCustomDto.setValidImgList(validImgList);
				modCustomDto.setErrorList(errorList);
			}
			if (!validImgList.isEmpty())
				modCustomDto.setCheckCopyPlantStatus(true);
			else
				modCustomDto.setCheckCopyPlantStatus(false);

			return modCustomDto;
		}catch(Exception e){
             slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
             ResMessageDto resMessageDto = new ResMessageDto();
             resMessageDto.setMessage(e.getMessage());
             resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
             modCustomDto.setResMessageDto(resMessageDto);
             return modCustomDto;
        }finally{
            slf4jLogger.info("Check Plant service ended");

        }
     }
	 
	  @Path("emptyTemplateDownload")
     @Consumes(MediaType.APPLICATION_JSON)
     @POST
     @Produces(MediaType.APPLICATION_JSON)
     public ImgHierarchyCustomDto emptyTemplateDownload(@Valid BrownFieldModDownloadDto emptyTemplateDownloadDto, @Context HttpServletRequest request){
			 ImgHierarchyCustomDto emptyTemplate = new ImgHierarchyCustomDto();
			 slf4jLogger.info("emptyTemplateDownload service started");
			 List<String> roleIdList = new ArrayList<>();
		  	 roleIdList.add(ConstantsValues.CONFIG);
		  	 roleIdList.add(ConstantsValues.TOOLADMIN);
		  	 roleIdList.add(ConstantsValues.TEMPAD);
			 roleIdList.add(ConstantsValues.TEMPAD1);
		  	 RoleValidationDto roleValidationDto = new RoleValidationDto();
			 roleValidationDto.setOmId(emptyTemplateDownloadDto.getOmgID());
		  	 roleValidationDto.setRoleIdList(roleIdList);
			 try{
			 if(UserSessionDao.isSessionActive(emptyTemplateDownloadDto.getSessionInputDTO(),roleValidationDto)){
				 S4AutoConfExecution autoConfigExecution = new S4AutoConfExecution();
				 emptyTemplate = autoConfigExecution.getEmptyTemplateCreation(emptyTemplateDownloadDto, request);
				 return emptyTemplate;
			 }
			 else{
				 ResMessageDto resMessageDto = new ResMessageDto();
				 resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
				 slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
				 resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
				 emptyTemplate.setResMessageDto(resMessageDto);
				 return emptyTemplate;
			 }
			}catch(Exception e){
				  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				  ResMessageDto resMessageDto = new ResMessageDto();
				  resMessageDto.setMessage(e.getMessage());
				  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
				  emptyTemplate.setResMessageDto(resMessageDto);
				  return emptyTemplate;
			}finally{
				
			}
	 }
	  
	  	@Path("withOutInFailedLogs")
	     @Consumes(MediaType.APPLICATION_JSON)
	     @POST
	     @Produces(MediaType.APPLICATION_JSON)
	     public void withOutInFailedLogs(@Valid configauditDto uploadExecutionLogDto){
			 slf4jLogger.info("withOutInFailedLogs service started");
			 List<String> roleIdList = new ArrayList<>();
		  	 roleIdList.add(ConstantsValues.CONFIG);
		  	 RoleValidationDto roleValidationDto = new RoleValidationDto();
		  	 roleValidationDto.setRoleIdList(roleIdList);
		  	
			 roleValidationDto.setOmId(uploadExecutionLogDto.getOmgID());
			// slf4jLogger.info("omid"+uploadExecutionLogDto.getOmgID());
	  		if(UserSessionDao.isSessionActive(uploadExecutionLogDto.getSessionInputDTO(),roleValidationDto)){
	  			 //slf4jLogger.info("if line satrted");
	  			ConfigUploadHistoryDto configUploadHistoryDto = new ConfigUploadHistoryDto();
  				configUploadHistoryDto.setImgID(uploadExecutionLogDto.getImgID());
  				configUploadHistoryDto.setTransactionID(uploadExecutionLogDto.getTransactionID());
  				configUploadHistoryDto.setStatus("E");
  				int transactionId = 0;
  				 ConfigAuditDAO configAuditDao =  new ConfigAuditDAO();
  				UploadExecutionLogDto uploadExecutionLogDtoObj = null;
  				 ArrayList<UploadExecutionLogDto> uploadExecutionLogList = new ArrayList<UploadExecutionLogDto>();

			//Added for Upload Logs
  			/*if(uploadExecutionLogDto.isIMGHierarchy()){*/
				try{
					
					transactionId = configAuditDao.createConfigUploadHistory(configUploadHistoryDto);
					// slf4jLogger.info("transactionId"+transactionId);
					if(transactionId > 0){
						uploadExecutionLogDtoObj = new UploadExecutionLogDto();
						uploadExecutionLogDtoObj.setConfigUploadID(transactionId);
						uploadExecutionLogDtoObj.setImgID(uploadExecutionLogDto.getImgID());
						uploadExecutionLogDtoObj.setMessage(uploadExecutionLogDto.getErrorReason());
						uploadExecutionLogDtoObj.setStatus("E");
						uploadExecutionLogDtoObj.setSequenceID(1);
						uploadExecutionLogList.add(uploadExecutionLogDtoObj);
						configAuditDao.createUploadExecutionLog(uploadExecutionLogList);

					}
				
			}catch(Exception e){
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
			finally{
				  slf4jLogger.info("withOutInFailedLogs service ended");

			}
	  	/*	}*/
	         
	  		}
	           
		 }
	  	

	  	public boolean validRequest(String currentScope,int exeReqCount){
	  		slf4jLogger.info("validRequest method started");
		  	String query = "INSERT INTO CONFIGREQUEST(SCOPEID,EXEREQCOUNT) VALUES(?,?)";
		  	int count = 0;
		  	boolean flag=false;
		  	Connection con = null;
			PreparedStatement pStmt=null;
			try{
				con = DBConnection.createConnection();
				pStmt = (PreparedStatement) con.prepareStatement(query);
				pStmt.setString(1, currentScope);
				pStmt.setInt(2, exeReqCount);
				count = pStmt.executeUpdate();
				if(count>0)
					flag = true;
				
			}
			catch (SQLException e){
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				return false;
			}finally{
				
				if(pStmt!=null){
					try {
						pStmt.close();
						pStmt=null;
						} catch (SQLException e) {
						slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
					}
				}
				if(con!=null){
					try {
						con.close();
						con=null;
						} catch (SQLException e) {
						slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
					}
				}
				  slf4jLogger.info("validRequest method ended");

		
			}	
			
			return flag;
		}
	  	
	  	 @Path("getIndustryAlias")  
		  @POST
		  @Produces(MediaType.APPLICATION_JSON)
		  public Response getindustryAlias(@Valid IndustryDto dto) {
			  slf4jLogger.info("getCustomerId service started");
			  List<String> roleIdList = new ArrayList<>();
			  roleIdList.add(dto.getUserRole());
			  RoleValidationDto roleValidationDto = new RoleValidationDto();
			  roleValidationDto.setRoleIdList(roleIdList);
			 try{
			  if(UserSessionDao.isSessionActive(dto.getSessionInputDTO(),roleValidationDto)){	
				  S4AutoConfExecution s4AutoExecution = new S4AutoConfExecution();
				 	IndustryResponseDto responseDto = null;
				 	responseDto = s4AutoExecution.getindustryAlias(dto);
					  return   Response.ok()
							  .header("Cache-Control", "No-cache")
							  .header("X-FRAME-OPTIONS", "Deny")
							  .header("X-Content-Type-Options", "nosniff")
							  .header("Content-Security-Policy",
								"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
							  .header("X-XSS-Protection", "1")
							  .entity(responseDto).build();
							  
			  }else{
				  IndustryResponseDto responseDto = new IndustryResponseDto();
				  ResMessageDto resMessageDto = new ResMessageDto();	
				  responseDto.setResMessageDto(resMessageDto);
				  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
				  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
				  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
				  return   Response.ok()
						  .header("Cache-Control", "No-cache")
						  .header("X-FRAME-OPTIONS", "Deny")
						  .header("X-Content-Type-Options", "nosniff")
						  .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						  .header("X-XSS-Protection", "1")
						  .entity(responseDto).build();
						  
			  } 
			 }
			  catch(Exception e){
				  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				  return Response.ok()
						  .header("Cache-Control", "No-cache")
						  .header("X-FRAME-OPTIONS", "Deny")
						  .header("X-Content-Type-Options", "nosniff")
						  .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						  .header("X-XSS-Protection", "1")
						  .header("Server","Disable")
						  
						  .entity(ConstantsValues.EXCEPTION).build();

			  }finally{		
				slf4jLogger.info("getCustomerId service ended");
			  }
			 	
		 }
	 
	 
}
