package com.acn.rpa.service;


import java.io.File;

/**
 * @author Rajesh Valupadasu
 *
 */


import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.encrypt.AESEncrypt;
import com.acn.encrypt.CryptoException;
import com.acn.rpa.config.BrownFieldInputDto;
import com.acn.rpa.config.BrownFieldModDownloadDto;
import com.acn.rpa.config.ConfigDwldResDto;
import com.acn.rpa.config.DownloadScopeResDto;
import com.acn.rpa.config.JSONFormatDto;
import com.acn.rpa.config.S4AutoConfExecution;
import com.acn.rpa.config.ServiceResponseDto;
import com.acn.rpa.config.dto.ConfigUploadHistoryDto;
import com.acn.rpa.config.dto.UploadExecutionLogDto;
import com.acn.rpa.fi.ExcelFormatterGL;
import com.acn.rpa.fi.FIiMasterResponseDto;
import com.acn.rpa.fi.FiMDInputDto;
import com.acn.rpa.fi.FiMDResponseDto;
import com.acn.rpa.fi.GLMDImpl;
import com.acn.rpa.fi.MasterDataResponseDto;
import com.acn.rpa.imghierarchy.ImgHierarchyCustomDto;
import com.acn.rpa.imghierarchy.ImgHierarchyDAO;
import com.acn.rpa.reports.ConfigAuditDAO;
import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.RoleValidationDto;
import com.acn.user.session.ResMessageDto;
import com.acn.user.session.UserSessionDao;

@Path("fiMasterDataService") 
public class FiMasterDataService {
    private final Logger slf4jLogger = LoggerFactory.getLogger(FiMasterDataService.class);

	@Path("performFiMasterData")
	@Consumes(MediaType.APPLICATION_JSON)
	@POST
	 @Produces(MediaType.APPLICATION_JSON)
	 public Response performFiMasterData(@Valid FiMDInputDto inputDTO, @Context HttpServletRequest request){
		slf4jLogger.info("performFiMasterData service started");
		String key = "RRn4PlfhPT6rXtZP";
		  List<String> roleIdList = new ArrayList<>();
		  roleIdList.add(ConstantsValues.CONFIG);
		  RoleValidationDto roleValidationDto = new RoleValidationDto();
		  roleValidationDto.setRoleIdList(roleIdList);
		try{
		FIiMasterResponseDto fIiMasterResponseDto = new FIiMasterResponseDto();
		if(UserSessionDao.isSessionActive(inputDTO.getSessionInputDTO(),roleValidationDto)){
		String webAppPath = request.getServletContext().getRealPath("/WEB-INF");
		
		 String webAppPath1 = request.getServletContext().getRealPath("/src/css");
		
		 File encryptedFile=new File(webAppPath+"/ACNIPMSTR_DATA_PC_CC_UPLOAD.txt");
		 File  decryptedFile = new File(webAppPath1+"/ACNIPMSTR_DATA_PC_CC_UPLOAD.txt");
		  try {
		    
			  //slf4jLogger.info("before decryption");
			  AESEncrypt.decrypt(key, encryptedFile,decryptedFile);
			  //slf4jLogger.info("after  decryption");
		    } catch (CryptoException ex) {
		       // System.out.println(ex.getMessage());
		        ex.printStackTrace();
		    }
		String masterDataPrgPath = webAppPath1 + File.separator + "ACNIPMSTR_DATA_PC_CC_UPLOAD.txt";
		ArrayList<FiMDResponseDto> fiMDResponseDtoList = new ArrayList<FiMDResponseDto>();
		ArrayList<ArrayList<String>> masterData = new ArrayList<>();
		FiMDResponseDto fiMDResponseDto = new FiMDResponseDto();
		FiMDInputDto fiMDInputDto = new FiMDInputDto();
		fiMDInputDto.setSncEnabled(inputDTO.getSncEnabled());
		fiMDInputDto.setSncName(inputDTO.getSncName());
		fiMDInputDto.setSncPartnerName(inputDTO.getSncPartnerName());
		fiMDInputDto.setSncProtectionLevel(inputDTO.getSncProtectionLevel());
		fiMDInputDto.setSapRouter(inputDTO.getSapRouter());
		GLMDImpl impObject = new GLMDImpl();
		//String cipherTextSapUser = null;
		String cipherTextSapPass = null; 
		AesUtil aesUtil = null;
		String scopeName = inputDTO.getScopeName();
		if(inputDTO.isConsolidate()) {
			scopeName = inputDTO.getScopeName().split("-")[0];
		}
		
		switch(scopeName){
		case "SIMG_CFMENUORK1KE51":
			
			ExcelFormatterGL excelFormatterPC = new ExcelFormatterGL();
			if(inputDTO.isConsolidate()) {
				masterData = excelFormatterPC.convertFormatForConsolidation(inputDTO.getFileBytes(),inputDTO.getScopeName());
			}else {
				masterData = excelFormatterPC.convertFormat_PC(inputDTO.getFileBytes(),inputDTO.getScopeName());
			}
			fiMDInputDto.setFormattedData(masterData);

			fiMDInputDto.setMdProgramPath(masterDataPrgPath);
			fiMDInputDto.setDestinationName(inputDTO.getDestinationName());
			fiMDInputDto.setIsCustomDestinationRequired(inputDTO.getIsCustomDestinationRequired());
			//cipherTextSapUser =  new String(java.util.Base64.getDecoder().decode(inputDTO.getSapUserId()));
			cipherTextSapPass =  new String(java.util.Base64.getDecoder().decode(inputDTO.getSapPassword()));
   		 	aesUtil = new AesUtil(128, 1000);
			fiMDInputDto.setSapUserId(inputDTO.getSapUserId());
			fiMDInputDto.setSapPassword(aesUtil.decrypt(cipherTextSapPass.split("::")[1], cipherTextSapPass.split("::")[0], inputDTO.getDestinationName(), cipherTextSapPass.split("::")[2]));
			fiMDInputDto.setSapLanguage(inputDTO.getSapLanguage());
			fiMDInputDto.setScopeName(inputDTO.getScopeName());
			fiMDInputDto.setTransactionID(inputDTO.getTransactionID());
			fiMDInputDto.setProjectName(inputDTO.getProjectName());
			fiMDInputDto.setScenario(inputDTO.getScenario());
			fiMDInputDto.setOmgID(inputDTO.getOmgID());
			fiMDInputDto.setSystemID(inputDTO.getSystemID());
			fiMDInputDto.setUserID(inputDTO.getUserID());
			fiMDInputDto.setModule(inputDTO.getModule());
			fiMDInputDto.setHostName(inputDTO.getHostName());
			fiMDInputDto.setSystemNo(inputDTO.getSystemNo());
			fiMDInputDto.setSapClientNo(inputDTO.getSapClientNo());
			if(inputDTO.isConsolidate()) {
				fiMDResponseDtoList = impObject.GLFiMasterHandlerForConsolidation(fiMDInputDto);
			}else {
				fiMDResponseDtoList = impObject.GLFiMasterHandler(fiMDInputDto);
			}
			fIiMasterResponseDto.setListFiMDResponse(fiMDResponseDtoList);
			break;

		case "FI_GL_MD_FS00":
			ExcelFormatterGL excelFormatterGL = new ExcelFormatterGL();
			if(inputDTO.isConsolidate()) {
				masterData = excelFormatterGL.convertFormatForConsolidation(inputDTO.getFileBytes(),inputDTO.getScopeName());
			}else {
				masterData = excelFormatterGL.convertFormat(inputDTO.getFileBytes(),inputDTO.getScopeName());
			}
			
			 //String webAppPath1 = request.getServletContext().getRealPath("/src/css");
				
			 File encryptedFile1=new File(webAppPath+"/ACNIPIMG_UPLOAD_MASTER_GL.txt");
			 File  decryptedFile1 = new File(webAppPath1+"/ACNIPIMG_UPLOAD_MASTER_GL.txt");
			  try {
			    
				  slf4jLogger.info("before decryption");
				  AESEncrypt.decrypt(key, encryptedFile1,decryptedFile1);
				  slf4jLogger.info("after  decryption");
			    } catch (CryptoException ex) {
			        System.out.println(ex.getMessage());
			        ex.printStackTrace();
			    }
			masterDataPrgPath = webAppPath1 + File.separator + "ACNIPIMG_UPLOAD_MASTER_GL.txt";
			fiMDInputDto.setFormattedData(masterData);
			fiMDInputDto.setMdProgramPath(masterDataPrgPath);
			fiMDInputDto.setDestinationName(inputDTO.getDestinationName());
			fiMDInputDto.setIsCustomDestinationRequired(inputDTO.getIsCustomDestinationRequired());
			//cipherTextSapUser =  new String(java.util.Base64.getDecoder().decode(inputDTO.getSapUserId()));
			cipherTextSapPass =  new String(java.util.Base64.getDecoder().decode(inputDTO.getSapPassword()));
   		 	aesUtil = new AesUtil(128, 1000);
			fiMDInputDto.setSapUserId(inputDTO.getSapUserId());
			fiMDInputDto.setSapPassword(aesUtil.decrypt(cipherTextSapPass.split("::")[1], cipherTextSapPass.split("::")[0], inputDTO.getDestinationName(), cipherTextSapPass.split("::")[2]));
			fiMDInputDto.setSapLanguage(inputDTO.getSapLanguage());
			fiMDInputDto.setScopeName(inputDTO.getScopeName());
			fiMDInputDto.setTransactionID(inputDTO.getTransactionID());
			fiMDInputDto.setProjectName(inputDTO.getProjectName());
			fiMDInputDto.setScenario(inputDTO.getScenario());
			fiMDInputDto.setOmgID(inputDTO.getOmgID());
			fiMDInputDto.setSystemID(inputDTO.getSystemID());
			fiMDInputDto.setUserID(inputDTO.getUserID());
			fiMDInputDto.setModule(inputDTO.getModule());
			fiMDInputDto.setHostName(inputDTO.getHostName());
			fiMDInputDto.setSystemNo(inputDTO.getSystemNo());
			fiMDInputDto.setSapClientNo(inputDTO.getSapClientNo());
			if(inputDTO.isConsolidate()) {
				fiMDResponseDtoList = impObject.GLFiMasterHandlerForConsolidation(fiMDInputDto);
			}else {
				fiMDResponseDtoList = impObject.GLFiMasterHandler(fiMDInputDto);
			}
			
			fIiMasterResponseDto.setListFiMDResponse(fiMDResponseDtoList);
			break;
		
		case "IMG_DUMMY_FIN1":
			ExcelFormatterGL excelFormatterCC = new ExcelFormatterGL();
			if(inputDTO.isConsolidate()) {
				masterData = excelFormatterCC.convertFormatForConsolidation(inputDTO.getFileBytes(),inputDTO.getScopeName());
			}else {
				masterData = excelFormatterCC.convertFormat(inputDTO.getFileBytes(),inputDTO.getScopeName());
			}
			
			fiMDInputDto.setFormattedData(masterData);
			fiMDInputDto.setMdProgramPath(masterDataPrgPath);
			fiMDInputDto.setDestinationName(inputDTO.getDestinationName());
			fiMDInputDto.setIsCustomDestinationRequired(inputDTO.getIsCustomDestinationRequired());
			//cipherTextSapUser =  new String(java.util.Base64.getDecoder().decode(inputDTO.getSapUserId()));
			cipherTextSapPass =  new String(java.util.Base64.getDecoder().decode(inputDTO.getSapPassword()));
   		 	aesUtil = new AesUtil(128, 1000);
			fiMDInputDto.setSapUserId(inputDTO.getSapUserId());
			fiMDInputDto.setSapPassword(aesUtil.decrypt(cipherTextSapPass.split("::")[1], cipherTextSapPass.split("::")[0], inputDTO.getDestinationName(), cipherTextSapPass.split("::")[2]));
			fiMDInputDto.setSapLanguage(inputDTO.getSapLanguage());
			fiMDInputDto.setScopeName(inputDTO.getScopeName());
			fiMDInputDto.setTransactionID(inputDTO.getTransactionID());
			fiMDInputDto.setProjectName(inputDTO.getProjectName());
			fiMDInputDto.setScenario(inputDTO.getScenario());
			fiMDInputDto.setOmgID(inputDTO.getOmgID());
			fiMDInputDto.setSystemID(inputDTO.getSystemID());
			fiMDInputDto.setUserID(inputDTO.getUserID());
			fiMDInputDto.setModule(inputDTO.getModule());
			fiMDInputDto.setHostName(inputDTO.getHostName());
			fiMDInputDto.setSystemNo(inputDTO.getSystemNo());
			fiMDInputDto.setSapClientNo(inputDTO.getSapClientNo());
			if(inputDTO.isConsolidate()) {
				fiMDResponseDtoList = impObject.GLFiMasterHandlerForConsolidation(fiMDInputDto);
			}else {
				fiMDResponseDtoList = impObject.GLFiMasterHandler(fiMDInputDto);
			}
			fIiMasterResponseDto.setListFiMDResponse(fiMDResponseDtoList);
			break;
		
		case "IMG_DUMMY_FIN3":
			ExcelFormatterGL excelFormatterGL1 = new ExcelFormatterGL();
			
			if(inputDTO.isConsolidate()) {
				masterData = excelFormatterGL1.convertFormatForConsolidation(inputDTO.getFileBytes(),inputDTO.getScopeName());
			}else {
				masterData = excelFormatterGL1.convertFormat(inputDTO.getFileBytes(),inputDTO.getScopeName());
			}
			
			 File encryptedFile2=new File(webAppPath+"/ACNIPIMG_UPLOAD_MASTER_HB.txt");
			 File  decryptedFile2 = new File(webAppPath1+"/ACNIPIMG_UPLOAD_MASTER_HB.txt");
			  try {
			    
				  slf4jLogger.info("before decryption");
				  AESEncrypt.decrypt(key, encryptedFile2,decryptedFile2);
				  slf4jLogger.info("after  decryption");
			    } catch (CryptoException ex) {
			        System.out.println(ex.getMessage());
			        ex.printStackTrace();
			    }
			masterDataPrgPath = webAppPath1 + File.separator + "ACNIPIMG_UPLOAD_MASTER_HB.txt";
			fiMDInputDto.setFormattedData(masterData);
			fiMDInputDto.setMdProgramPath(masterDataPrgPath);
			fiMDInputDto.setDestinationName(inputDTO.getDestinationName());
			fiMDInputDto.setIsCustomDestinationRequired(inputDTO.getIsCustomDestinationRequired());
			//cipherTextSapUser =  new String(java.util.Base64.getDecoder().decode(inputDTO.getSapUserId()));
			cipherTextSapPass =  new String(java.util.Base64.getDecoder().decode(inputDTO.getSapPassword()));
   		 	aesUtil = new AesUtil(128, 1000);
			fiMDInputDto.setSapUserId(inputDTO.getSapUserId());
			fiMDInputDto.setSapPassword(aesUtil.decrypt(cipherTextSapPass.split("::")[1], cipherTextSapPass.split("::")[0], inputDTO.getDestinationName(), cipherTextSapPass.split("::")[2]));
			fiMDInputDto.setSapLanguage(inputDTO.getSapLanguage());
			fiMDInputDto.setScopeName(inputDTO.getScopeName());
			fiMDInputDto.setTransactionID(inputDTO.getTransactionID());
			fiMDInputDto.setProjectName(inputDTO.getProjectName());
			fiMDInputDto.setScenario(inputDTO.getScenario());
			fiMDInputDto.setOmgID(inputDTO.getOmgID());
			fiMDInputDto.setSystemID(inputDTO.getSystemID());
			fiMDInputDto.setUserID(inputDTO.getUserID());
			fiMDInputDto.setModule(inputDTO.getModule());
			fiMDInputDto.setCustomizingTr(inputDTO.getCustomizingTr());
			fiMDInputDto.setIMGHierarchy(inputDTO.isIMGHierarchy());
			fiMDInputDto.setHostName(inputDTO.getHostName());
			fiMDInputDto.setSystemNo(inputDTO.getSystemNo());
			fiMDInputDto.setSapClientNo(inputDTO.getSapClientNo());
			if(inputDTO.isConsolidate()) {
				fiMDResponseDtoList = impObject.GLFiMasterHandlerForConsolidation(fiMDInputDto);
			}else {
				fiMDResponseDtoList = impObject.GLFiMasterHandler(fiMDInputDto);
			}
			
			fIiMasterResponseDto.setListFiMDResponse(fiMDResponseDtoList);
			break;
		
		default:
			fiMDResponseDto.setMessage("No matches found for the given Scope Name, please contact Administrator!!");
			fiMDResponseDtoList.add(fiMDResponseDto);
			fIiMasterResponseDto.setListFiMDResponse(fiMDResponseDtoList);

			break;

		}
		return  Response.ok()
				.header("Cache-Control", "No-cache")
			    .header("X-FRAME-OPTIONS", "Deny")
			    .header("X-Content-Type-Options", "nosniff")
			    .header("Content-Security-Policy",
				"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
			    .header("X-XSS-Protection", "1")
			    .entity(fIiMasterResponseDto).build();
				
		}
		else{
			 ResMessageDto resMessageDto = new ResMessageDto();
			 resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			 slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			 resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			 fIiMasterResponseDto.setResMessageDto(resMessageDto);
			 return Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity(fIiMasterResponseDto).build();
		}
		 }
		  catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("performFiMasterData service ended");
			 String webAppPath1 = request.getServletContext().getRealPath("/src/css");
			 File file = new File(webAppPath1+"/ACNIPMSTR_DATA_PC_CC_UPLOAD.txt");
			 File file1 = new File(webAppPath1+"/ACNIPIMG_UPLOAD_MASTER_GL.txt");
			 File file2 = new File(webAppPath1+"/ACNIPIMG_UPLOAD_MASTER_HB.txt");
			
			   
		        if(file.delete()){
		            //System.out.println(" File deleted");
		        }
		        //else System.out.println(" doesn't exist");
		        if(file1.delete()){
		           // System.out.println(" File deleted");
		        }
		        //else System.out.println(" doesn't exist");
		        if(file2.delete()){
		            //System.out.println(" File deleted");
		        }
		        //else System.out.println(" doesn't exist");
		  }
	  }
	
	 @Path("DwldMasterDataForBrwnMod")
	 @Consumes(MediaType.APPLICATION_JSON)
	 @POST
	 @Produces(MediaType.APPLICATION_JSON)
	 public  Response DwldMasterDataForBrwnMod(@Valid BrownFieldModDownloadDto brownFieldModDownloadDto, @Context HttpServletRequest request){
		 slf4jLogger.info("DwldMasterDataForBrwnMod service started");
		  List<String> roleIdList = new ArrayList<>();
		  roleIdList.add(ConstantsValues.CONFIG);
		  RoleValidationDto roleValidationDto = new RoleValidationDto();
		  roleValidationDto.setRoleIdList(roleIdList);
		  roleValidationDto.setOmId(brownFieldModDownloadDto.getOmgID());
		 try{ 
		 ImgHierarchyCustomDto modCustomDto = new ImgHierarchyCustomDto();
		 if(UserSessionDao.isSessionActive(brownFieldModDownloadDto.getSessionInputDTO(),roleValidationDto)){
		 S4AutoConfExecution autoConfigExecution = new S4AutoConfExecution();
		 modCustomDto = autoConfigExecution.masterDataDownload(brownFieldModDownloadDto, request);
		 return Response.ok()
					.header("Cache-Control", "No-cache")
				    .header("X-FRAME-OPTIONS", "Deny")
				    .header("X-Content-Type-Options", "nosniff")
				    .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				    .header("X-XSS-Protection", "1")
				    .entity(modCustomDto).build();
				 
		 }
		 else{
			 ResMessageDto resMessageDto = new ResMessageDto();
			 resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			 slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			 resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			 modCustomDto.setResMessageDto(resMessageDto);
			 return Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity(modCustomDto).build();
				
		 }
		 }catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("DwldMasterDataForBrwnMod service ended");
		  } 
	 }
	 
	 
	 @Path("masterDataWithoutIntervention")
     @Consumes(MediaType.APPLICATION_JSON)
     @POST
     @Produces(MediaType.APPLICATION_JSON)
     public Response configDownload(@Valid BrownFieldInputDto autoConfigInputDto, @Context HttpServletRequest request){
		 slf4jLogger.info("masterDataWithoutIntervention service started");
		  List<String> roleIdList = new ArrayList<>();
		  roleIdList.add(ConstantsValues.CONFIG);
		  RoleValidationDto roleValidationDto = new RoleValidationDto();
		  roleValidationDto.setRoleIdList(roleIdList);
		  roleValidationDto.setOmId(autoConfigInputDto.getOmgID());

		 try{
		 ServiceResponseDto responseDto =  null;
		 if(UserSessionDao.isSessionActive(autoConfigInputDto.getSessionInputDTO(),roleValidationDto)){
		 int  pocketSize = 0;
		 int transactionId = 0;
		 ConfigAuditDAO configAuditDao =  new ConfigAuditDAO();
		 ConfigUploadHistoryDto  configUploadHistoryDto  = null;
		 ArrayList<UploadExecutionLogDto> uploadExecutionLogList = null ;
		 UploadExecutionLogDto uploadExecutionLogDto =  null;
		 DownloadScopeResDto downloadScopeResDto = null;
		 ImgHierarchyDAO imgHierarchyDAO = new ImgHierarchyDAO();
		 ArrayList<JSONFormatDto> dstResultsList = null;
		 JSONFormatDto excelFrmt = null;
		 S4AutoConfExecution s4ImplObj = null;
		 String webAppPath = null;
		 String downloadPrgPath = null;
		 String uploadPrgPath = null;
		 ArrayList<String> masterDataDownloadList = null;
		 ArrayList<String> masterInput = new ArrayList<>();
		 String flag = "";
		 String ABAPreqid_Dwld = "";
		 String recordNo = "";
		 String ABAPreqid_Upld = "";
		 String customizeTR = "";
		 boolean loopReq = true;
		 ConfigDwldResDto configDwldResDto = null;
		 GLMDImpl masterDataImpObject = new GLMDImpl();
		 MasterDataResponseDto masterDataResponseDto  = null;
		// String cipherTextSapUser = null;
		 String cipherTextSapPass = null;
	     AesUtil aesUtil = null;
	     String key = "RRn4PlfhPT6rXtZP";
		 try{
        	 responseDto =  new ServiceResponseDto();
			 dstResultsList = new ArrayList<>();

		   s4ImplObj = new S4AutoConfExecution();
		   webAppPath = request.getServletContext().getRealPath("/WEB-INF");
		   String webAppPath1 = request.getServletContext().getRealPath("/src/css");
			
			 File encryptedFile=new File(webAppPath+"/ACNIPMSTR_DATA_PC_CC_UPLOAD.txt");
			 File  decryptedFile = new File(webAppPath1+"/ACNIPMSTR_DATA_PC_CC_UPLOAD.txt");
			  try {
			    	//AESEncrypt.encrypt(key, inputFile, encryptedFile);
				 // slf4jLogger.info("before decryption");
				  AESEncrypt.decrypt(key, encryptedFile,decryptedFile);
				  //slf4jLogger.info("after  decryption");
			    } catch (CryptoException ex) {
			        //System.out.println(ex.getMessage());
			        ex.printStackTrace();
			    }
			  File encryptedFile1=new File(webAppPath+"/ACNIPIMG_DOWNLOAD_FI_MASTER.txt");
				 File  decryptedFile1 = new File(webAppPath1+"/ACNIPIMG_DOWNLOAD_FI_MASTER.txt");
				  try {
				    	//AESEncrypt.encrypt(key, inputFile, encryptedFile);
					  //slf4jLogger.info("before decryption");
					  AESEncrypt.decrypt(key, encryptedFile1,decryptedFile1);
					  //slf4jLogger.info("after  decryption");
				    } catch (CryptoException ex) {
				        //System.out.println(ex.getMessage());
				        ex.printStackTrace();
				    }
           uploadPrgPath = webAppPath1 + File.separator + "ACNIPMSTR_DATA_PC_CC_UPLOAD.txt";
           downloadPrgPath = webAppPath1 + File.separator +"ACNIPIMG_DOWNLOAD_FI_MASTER.txt";
           customizeTR = autoConfigInputDto.getCustomizingTr();
           while(loopReq){
        	   pocketSize++;
				masterInput.clear();
				if(autoConfigInputDto.getImgID().equals("IMG_DUMMY_FIN1")){
					masterInput.add("CC");
					masterInput.add(autoConfigInputDto.getImgID()+"|"+ABAPreqid_Dwld+"|"+recordNo+"|"+flag);
				}else if(autoConfigInputDto.getImgID().equals("SIMG_CFMENUORK1KE51")){
					masterInput.add("PC");
					masterInput.add(autoConfigInputDto.getImgID()+"|"+ABAPreqid_Dwld+"|"+recordNo+"|"+flag);				    					
				}else if(autoConfigInputDto.getImgID().equals("FI_GL_MD_FS00")){
					masterInput.add("GL");
					masterInput.add(autoConfigInputDto.getImgID()+"|"+ABAPreqid_Dwld+"|"+recordNo+"|"+flag);
				}
				else if(autoConfigInputDto.getImgID().equals("IMG_DUMMY_FIN3")){
					masterInput.add("HB");
					masterInput.add(autoConfigInputDto.getImgID()+"|"+ABAPreqid_Dwld+"|"+recordNo+"|"+flag);
				}
			
				configDwldResDto = s4ImplObj.dwldMasterData_ABAP(autoConfigInputDto.getImgID(), autoConfigInputDto.getSrcDestination(), downloadPrgPath, masterInput,
						autoConfigInputDto.getClientNo(),autoConfigInputDto.getHostName(),
						autoConfigInputDto.getSysNo(),autoConfigInputDto.getSapUserId(),autoConfigInputDto.getSapPassword(),autoConfigInputDto.getSapLanguage(),
						autoConfigInputDto.getSrcSncEnabled(), autoConfigInputDto.getSrcSncName(),
	        			   autoConfigInputDto.getSrcSncPartnerName(), autoConfigInputDto.getSrcSncProtection(), autoConfigInputDto.getSrcSapRouter());
				if(configDwldResDto != null && configDwldResDto.getConfigDwldData() != null && configDwldResDto.getConfigDwldData().size()> 2){
					String value  = configDwldResDto.getConfigDwldData().get(1);
					//slf4jLogger.info("value"+value);
					String tempArr[] = value.split("\\|");
					int size = 0;
					if(size > 1) ABAPreqid_Dwld = tempArr[1];
					if(size > 2) recordNo = tempArr[2];
					if(size > 3) flag = tempArr[3];
					masterDataDownloadList = configDwldResDto.getConfigDwldData();
					if(autoConfigInputDto.getImgID().equals("IMG_DUMMY_FIN1")){
						masterDataDownloadList.set(0, "CC|X");						
						masterDataDownloadList.set(1, autoConfigInputDto.getImgID()+"|"+ABAPreqid_Upld+"|"+recordNo+"|"+flag);
					}else if(autoConfigInputDto.getImgID().equals("SIMG_CFMENUORK1KE51")){
						masterDataDownloadList.set(0, "PC|X");						
						masterDataDownloadList.set(1, autoConfigInputDto.getImgID()+"|"+ABAPreqid_Upld+"|"+recordNo+"|"+flag);				    					
					}else if(autoConfigInputDto.getImgID().equals("FI_GL_MD_FS00")){
						 File encryptedFile2=new File(webAppPath+"/ACNIPIMG_UPLOAD_MASTER_GL.txt");
						 File  decryptedFile2 = new File(webAppPath1+"/ACNIPIMG_UPLOAD_MASTER_GL.txt");
						  try {
						    	//AESEncrypt.encrypt(key, inputFile, encryptedFile);
							  //slf4jLogger.info("before decryption");
							  AESEncrypt.decrypt(key, encryptedFile2,decryptedFile2);
							  //slf4jLogger.info("after  decryption");
						    } catch (CryptoException ex) {
						        //System.out.println(ex.getMessage());
						        ex.printStackTrace();
						    }
						uploadPrgPath = webAppPath1 + File.separator + "ACNIPIMG_UPLOAD_MASTER_GL.txt";
						masterDataDownloadList.set(0, "GL|X");						
						masterDataDownloadList.set(1, autoConfigInputDto.getImgID()+"|"+ABAPreqid_Upld+"|"+recordNo+"|"+flag);
					}
					else if(autoConfigInputDto.getImgID().equals("IMG_DUMMY_FIN3")){
						 File encryptedFile3=new File(webAppPath+"/ACNIPIMG_UPLOAD_MASTER_HB.txt");
						 File  decryptedFile3 = new File(webAppPath1+"/ACNIPIMG_UPLOAD_MASTER_HB.txt");
						  try {
						    	//AESEncrypt.encrypt(key, inputFile, encryptedFile);
							 // slf4jLogger.info("before decryption");
							  AESEncrypt.decrypt(key, encryptedFile3,decryptedFile3);
							 // slf4jLogger.info("after  decryption");
						    } catch (CryptoException ex) {
						       // System.out.println(ex.getMessage());
						        ex.printStackTrace();
						    }
						uploadPrgPath = webAppPath1 + File.separator + "ACNIPIMG_UPLOAD_MASTER_HB.txt";
						masterDataDownloadList.set(0, "HB|X");						
						masterDataDownloadList.set(1, autoConfigInputDto.getImgID()+"|"+ABAPreqid_Upld+"|"+recordNo+"|"+flag+"|"+customizeTR);
					}
	
					masterDataResponseDto =  new MasterDataResponseDto();
					
					//cipherTextSapUser =  new String(java.util.Base64.getDecoder().decode(autoConfigInputDto.getSapUserId()));
					cipherTextSapPass =  new String(java.util.Base64.getDecoder().decode(autoConfigInputDto.getSapPassword()));
		   		 	aesUtil = new AesUtil(128, 1000);
		   		 	autoConfigInputDto.setSapUserId(autoConfigInputDto.getSapUserId());
		   		 	autoConfigInputDto.setSapPassword(aesUtil.decrypt(cipherTextSapPass.split("::")[1], cipherTextSapPass.split("::")[0], autoConfigInputDto.getTgtDestination(), cipherTextSapPass.split("::")[2]));
					
					 //slf4jLogger.info("configDwldResDto"+configDwldResDto.getConfigDwldData());
		   		// slf4jLogger.info("executeTargetSysConfig");
					masterDataResponseDto = masterDataImpObject.executeTargetSysConfig(masterDataDownloadList,autoConfigInputDto.getDestinationName(), uploadPrgPath, autoConfigInputDto.getSapUserId(),
							autoConfigInputDto.getSapPassword(),autoConfigInputDto.getSapLanguage(),autoConfigInputDto.getIsCustomDestinationRequired(),
							autoConfigInputDto.getSncEnabled(),autoConfigInputDto.getSncName(), autoConfigInputDto.getSncPartnerName(),
							autoConfigInputDto.getSncProtectionLevel(), autoConfigInputDto.getSapRouter(),
							autoConfigInputDto.getHostName(), autoConfigInputDto.getSysNo(), autoConfigInputDto.getClientNo());
					
					if(flag == "X"){
						if(!autoConfigInputDto.getImgID().equals("IMG_DUMMY_FIN3") && masterDataResponseDto.getResponseData() != null && masterDataResponseDto.getResponseData().size() == 2){
							 if(masterDataResponseDto.getResponseData().get(1).split("\\|").length > 2)
								 ABAPreqid_Upld = masterDataResponseDto.getResponseData().get(1).split("\\|")[1];
							
						}else if(autoConfigInputDto.getImgID().equals("IMG_DUMMY_FIN3") && masterDataResponseDto.getResponseData() != null && masterDataResponseDto.getResponseData().size() >= 2){
							if(masterDataResponseDto.getResponseData().get(1).split("\\|").length >= 4){
								ABAPreqid_Upld = masterDataResponseDto.getResponseData().get(1).split("\\|")[1];
								customizeTR = masterDataResponseDto.getResponseData().get(1).split("\\|")[3];					
							}else{
								loopReq = false; 
							}
						}
						
					}else{
						loopReq = false;
					}
				 }else {
					 loopReq = false;
				 }
					 
			}
           String[] result = null;
          /* slf4jLogger.info("masterDataResponseDto"+masterDataResponseDto);
           slf4jLogger.info("connectionstatus"+masterDataResponseDto.isConnectionStatus());
           slf4jLogger.info("executionstatus"+masterDataResponseDto.isExecutionStatus());*/
           
           if(masterDataResponseDto.isConnectionStatus() && masterDataResponseDto.isExecutionStatus()){
				for(int k = 0,resSize = masterDataResponseDto.getResponseData().size(); k < resSize; k++){
					JSONFormatDto jSONFormatDto = new JSONFormatDto();
					result = masterDataResponseDto.getResponseData().get(k).split("~");
					if(k==0){
						if(result.length >= 2)
						responseDto.setStatus(result[1].trim());
					}else if(k > 1){
						if(result.length >= 2)
						jSONFormatDto.setDescription(result[1]);
						else
							jSONFormatDto.setDescription(result[0]);
						jSONFormatDto.setErrorType(result[0]);
						jSONFormatDto.setMessageType(result[0]);
						jSONFormatDto.setScopeName(autoConfigInputDto.getImgID());

						dstResultsList.add(jSONFormatDto);
						
					}
				}
				
				   responseDto.setConnectionStatus(masterDataResponseDto.isConnectionStatus());
		           responseDto.setExecutionStatus(masterDataResponseDto.isExecutionStatus());
		 
			}
			else{
				   responseDto.setConnectionStatus(true);
				   
				JSONFormatDto jSONFormatDto = new JSONFormatDto();
				if(masterDataResponseDto.getResponseData()!= null &&  masterDataResponseDto.getResponseData().size() > 2)
				jSONFormatDto.setDescription(masterDataResponseDto.getResponseData().get(1));
				else
					jSONFormatDto.setDescription("Response Issue");
					
				jSONFormatDto.setErrorType("E");
				jSONFormatDto.setMessageType("E");
				jSONFormatDto.setScopeName(autoConfigInputDto.getImgID());

				responseDto.setStatus(ConstantsValues.ERRORSTATUS);
				dstResultsList.add(jSONFormatDto);
			}
           
           responseDto.setResult(dstResultsList);
           responseDto.setScopeName(autoConfigInputDto.getImgID());
           
             configUploadHistoryDto = new ConfigUploadHistoryDto();
			 configUploadHistoryDto.setImgID(autoConfigInputDto.getImgID());
			 configUploadHistoryDto.setTransactionID(autoConfigInputDto.getTransactionID());
			 configUploadHistoryDto.setProjectName(autoConfigInputDto.getProjectName());
			 configUploadHistoryDto.setScenario(autoConfigInputDto.getScenario());
			 configUploadHistoryDto.setOmgID(autoConfigInputDto.getOmgID());
			 configUploadHistoryDto.setSystemID(autoConfigInputDto.getSystemID());
			 configUploadHistoryDto.setUserID(autoConfigInputDto.getUserID());
			 configUploadHistoryDto.setModule(autoConfigInputDto.getModule());
			 configUploadHistoryDto.setCustomizingTr(customizeTR);
			 	if(responseDto.getStatus() != null && responseDto.getStatus() != "")
			 		configUploadHistoryDto.setStatus(responseDto.getStatus().equalsIgnoreCase("Success")?"S":"E");
			 	else
			 		responseDto.setStatus("E");

	//	if(autoConfigInputDto.isIMGHierarchy()){
				try{
					
					transactionId = configAuditDao.createConfigUploadHistory(configUploadHistoryDto);
					if(transactionId > 0){
						uploadExecutionLogList = new ArrayList<>();
						for(int i = 0,arrSize = dstResultsList.size(); i< arrSize;i++){
							
							JSONFormatDto dto = dstResultsList.get(i);
						uploadExecutionLogDto = new UploadExecutionLogDto();
						uploadExecutionLogDto.setConfigUploadID(transactionId);
						uploadExecutionLogDto.setImgID(autoConfigInputDto.getImgID());
						uploadExecutionLogDto.setMessage(dto.getDescription());
						uploadExecutionLogDto.setStatus(dto.getMessageType());
						uploadExecutionLogDto.setUserID(autoConfigInputDto.getUserID());
						uploadExecutionLogDto.setSequenceID(i+1);
						uploadExecutionLogList.add(uploadExecutionLogDto);
						}
						
						configAuditDao.createUploadExecutionLog(uploadExecutionLogList);

					}
				}catch(Exception e){
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
				finally{
					
				}
		//	}
				
		 }catch(Throwable e){
			 slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		 }finally{
			 imgHierarchyDAO = null;
			 downloadScopeResDto = null;
			 dstResultsList = null;
			 excelFrmt = null;
			 s4ImplObj = null;
			 webAppPath = null;
			 downloadPrgPath = null;
		 }

           return Response.ok()
					.header("Cache-Control", "No-cache")
				    .header("X-FRAME-OPTIONS", "Deny")
				    .header("X-Content-Type-Options", "nosniff")
				    .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				    .header("X-XSS-Protection", "1")
				    .entity(responseDto).build();        		   
	 }
	 
	 else{
		 ResMessageDto resMessageDto = new ResMessageDto();
		 responseDto =  new ServiceResponseDto();
		 resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
		 resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
		 responseDto.setResMessageDto(resMessageDto);
		 return      Response.ok()
					.header("Cache-Control", "No-cache")
				    .header("X-FRAME-OPTIONS", "Deny")
				    .header("X-Content-Type-Options", "nosniff")
				    .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				    .header("X-XSS-Protection", "1")
				    .entity(responseDto).build();
	 }
		 }catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("masterDataWithoutIntervention service ended");
			String webAppPath1 = request.getServletContext().getRealPath("/src/css");
			 File file = new File(webAppPath1+"/ACNIPMSTR_DATA_PC_CC_UPLOAD.txt");
			 File file1 = new File(webAppPath1+"/ACNIPIMG_DOWNLOAD_FI_MASTER.txt");
			 File file2 = new File(webAppPath1+"/ACNIPIMG_UPLOAD_MASTER_GL.txt");
			 File file3 = new File(webAppPath1+"/ACNIPIMG_UPLOAD_MASTER_HB.txt");
			   
		        if(file.delete()){
		          //  System.out.println(" File deleted");
		        }
		        //else System.out.println(" doesn't exist");
		        if(file1.delete()){
		           // System.out.println(" File deleted");
		        }
		        //else System.out.println(" doesn't exist");
		        if(file2.delete()){
		           // System.out.println(" File deleted");
		        }
		        //else System.out.println(" doesn't exist");
		        if(file3.delete()){
		           // System.out.println(" File deleted");
		        }
		        //else System.out.println(" doesn't exist");
		  }
	 }
	
}
