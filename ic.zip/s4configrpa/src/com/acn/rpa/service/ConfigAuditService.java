package com.acn.rpa.service;


import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;
import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.config.dto.ConfigTransactionDto;
import com.acn.rpa.reports.ConfigAuditDAO;
import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.RoleValidationDto;
import com.acn.user.session.UserSessionDao;

@Path("configAuditService")
public class ConfigAuditService {
    private final Logger slf4jLogger = LoggerFactory.getLogger(ConfigAuditService.class);

	  @Path("createConfigTransaction")
	  @POST
	  @Consumes({MediaType.APPLICATION_JSON})
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response createConfigTransaction (@Valid ConfigTransactionDto configTransactionDto) throws NamingException{
		  slf4jLogger.info("createConfigTransaction service started");
		  try{
		  ConfigAuditDAO configAuditDao = new ConfigAuditDAO();
		  List<String> roleIdList = new ArrayList<>();
		  roleIdList.add(ConstantsValues.CONFIG);
		  RoleValidationDto roleValidationDto = new RoleValidationDto();
		  roleValidationDto.setRoleIdList(roleIdList);
		  roleValidationDto.setOmId(configTransactionDto.getOmgID());
		  int transactionId = configAuditDao.createConfigTransaction(configTransactionDto);
		  if(UserSessionDao.isSessionActive(configTransactionDto.getSessionInputDTO(),roleValidationDto)){
			  return   Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity("{\"message\": \""+ transactionId +"\"}").build();
					  
					 
		  }
		  else{
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  return   Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity("{\"message\": \""+ ConstantsValues.SERVICESECURITYERROR +"\"}").build();
					  
		  }
		  }
		  catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("createConfigTransaction service ended");
		  }
	  }
	}
