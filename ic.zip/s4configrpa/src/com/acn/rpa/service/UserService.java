package com.acn.rpa.service;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.admin.UserDao;
import com.acn.rpa.admin.UserDto;
import com.acn.rpa.imghierarchy.ImgHierarchyInputDTO;
import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.RoleValidationDto;
import com.acn.user.session.CustomInputDto;
import com.acn.user.session.CustomResDto;
import com.acn.user.session.CustomerInputDto;
import com.acn.user.session.DataStatusDto;
import com.acn.user.session.ResMessageDto;
import com.acn.user.session.SessionInputDTO;
import com.acn.user.session.UserListDto;
import com.acn.user.session.UserSessionDao;

@Path("/userSrv")
public class UserService {
    private final Logger slf4jLogger = LoggerFactory.getLogger(UserService.class);

	@POST
	@Path("/displayAll")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getUsers(@Valid CustomerInputDto customerInputDto){
		 slf4jLogger.info("displayAll service started");
		 try{
		 UserListDto userListDto = new UserListDto();
		 List<String> roleIdList = new ArrayList<>();
	  	  roleIdList.add(ConstantsValues.PROJECTADMIN);
	  	  roleIdList.add(ConstantsValues.TOOLADMIN);
	  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	  roleValidationDto.setRoleIdList(roleIdList);
		 UserDao userDao = new UserDao();
		 
			  if(UserSessionDao.isSessionActive(customerInputDto.getSessionInputDTO(),roleValidationDto)){	
					  return  Response.ok()
								.header("Cache-Control", "No-cache")
							    .header("X-FRAME-OPTIONS", "Deny")
							    .header("X-Content-Type-Options", "nosniff")
							    .header("Content-Security-Policy",
								"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
							    .header("X-XSS-Protection", "1")
							    .entity( userDao.getAllUsers(customerInputDto)).build();
							  	  
			  }else{
				  ResMessageDto resMessageDto = new ResMessageDto();	
				  userListDto.setResMessageDto(resMessageDto);
				  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
				  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
				  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
				  return   Response.ok()
							.header("Cache-Control", "No-cache")
						    .header("X-FRAME-OPTIONS", "Deny")
						    .header("X-Content-Type-Options", "nosniff")
						    .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						    .header("X-XSS-Protection", "1")
						    .entity( userListDto).build();
						 
			  }
		 }catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("displayAll service ended");
		  }

	}
	

	@POST
	@Path("/validateUser")
	@Produces(MediaType.APPLICATION_JSON)
	public Response validateUser(@Valid CustomerInputDto customerInputDto){
		slf4jLogger.info("validateUser service started");
		try{
		DataStatusDto dataStatusDto = new DataStatusDto();
		 UserDao userDao = new UserDao();
		 List<String> roleIdList = new ArrayList<>();
	  	  roleIdList.add(ConstantsValues.PROJECTADMIN);
	  	  roleIdList.add(ConstantsValues.TOOLADMIN);
	  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	  roleValidationDto.setRoleIdList(roleIdList);
			  if(UserSessionDao.isSessionActive(customerInputDto.getSessionInputDTO(),roleValidationDto)){	
					  return   Response.ok()
								.header("Cache-Control", "No-cache")
							    .header("X-FRAME-OPTIONS", "Deny")
							    .header("X-Content-Type-Options", "nosniff")
							    .header("Content-Security-Policy",
								"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
							    .header("X-XSS-Protection", "1")
							    .entity(  userDao.validateUser(customerInputDto.getUserID())).build();
							 
			  }else{
				  ResMessageDto resMessageDto = new ResMessageDto();
				  dataStatusDto.setResMessageDto(resMessageDto);
				  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
				  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
				  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
				  return   Response.ok()
							.header("Cache-Control", "No-cache")
						    .header("X-FRAME-OPTIONS", "Deny")
						    .header("X-Content-Type-Options", "nosniff")
						    .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						    .header("X-XSS-Protection", "1")
						    .entity( dataStatusDto).build();
						  
			  }
		}catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("validateUser service ended");
		  }
	}
	
	@POST
	@Path("/add")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response createUser(@Valid UserDto userDto){
		slf4jLogger.info("add service started");
		try{
		UserDao userDao = new UserDao();
		List<String> roleIdList = new ArrayList<>();
	  	  roleIdList.add(ConstantsValues.PROJECTADMIN);
	  	  roleIdList.add(ConstantsValues.TOOLADMIN);
	  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	  roleValidationDto.setRoleIdList(roleIdList);
		  if(UserSessionDao.isSessionActive(userDto.getSessionInputDTO(),roleValidationDto)){	
				  return Response.ok()
					.header("Cache-Control", "No-cache")
				    .header("X-FRAME-OPTIONS", "Deny")
				    .header("X-Content-Type-Options", "nosniff")
				    .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				    .header("X-XSS-Protection", "1")
				    .entity(userDao.addUser(userDto)).build();
						 
		  }else{
			  ResMessageDto resMessageDto = new ResMessageDto();
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity( resMessageDto).build();
					 
		  }
		}catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("add service ended");
		  }
	}
	
	@PUT
	@Path("update")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response updateUser(@Valid UserDto userDto){
		slf4jLogger.info("update service started");
		try{
		UserDao userDao = new UserDao();
		List<String> roleIdList = new ArrayList<>();
	  	  roleIdList.add(ConstantsValues.PROJECTADMIN);
	  	  roleIdList.add(ConstantsValues.TOOLADMIN);
	  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	  roleValidationDto.setRoleIdList(roleIdList);
		  if(UserSessionDao.isSessionActive(userDto.getSessionInputDTO(),roleValidationDto)){	
				  return Response.ok()
							.header("Cache-Control", "No-cache")
						    .header("X-FRAME-OPTIONS", "Deny")
						    .header("X-Content-Type-Options", "nosniff")
						    .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						    .header("X-XSS-Protection", "1")
						    .entity( userDao.updateUser(userDto)).build();
						  	  
		  }else{
			  ResMessageDto resMessageDto = new ResMessageDto();
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity( resMessageDto).build();
					 
		  }
		 
		}catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("update service ended");
		  }
	}
	
	@PUT
	@Path("delete")
	@Produces(MediaType.APPLICATION_JSON)
	public Response deleteUser(@Valid CustomInputDto customInputDto){
	 slf4jLogger.info("delete service started");
		try{
		UserDao userDao = new UserDao();
		List<String> roleIdList = new ArrayList<>();
	  	  roleIdList.add(ConstantsValues.PROJECTADMIN);
	  	  roleIdList.add(ConstantsValues.TOOLADMIN);
	  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	  roleValidationDto.setRoleIdList(roleIdList);
		  if(UserSessionDao.isSessionActive(customInputDto.getSessionInputDTO(),roleValidationDto)){	
				  return Response.ok()
							.header("Cache-Control", "No-cache")
						    .header("X-FRAME-OPTIONS", "Deny")
						    .header("X-Content-Type-Options", "nosniff")
						    .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						    .header("X-XSS-Protection", "1")
						    .entity(userDao.removeUser(customInputDto.getDataList())).build();
						  
		  }else{
			  ResMessageDto resMessageDto = new ResMessageDto();
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity(resMessageDto).build();
					  
		  }
		}catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("delete service ended");
		  }

	}
	
	  @Path("displayUserIds")
	  @POST
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response displayUserIds(@Valid SessionInputDTO sessionInputDto){
		  slf4jLogger.info("displayUserIds service started");
		  try{
		  UserDao userDao = new UserDao();
		  List<String> roleIdList = new ArrayList<>();
	  	  roleIdList.add(ConstantsValues.PROJECTADMIN);
	  	  roleIdList.add(ConstantsValues.TOOLADMIN);
	  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	  roleValidationDto.setRoleIdList(roleIdList);
		  if(UserSessionDao.isSessionActive(sessionInputDto,roleValidationDto)){	
				  return Response.ok()
							.header("Cache-Control", "No-cache")
						    .header("X-FRAME-OPTIONS", "Deny")
						    .header("X-Content-Type-Options", "nosniff")
						    .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						    .header("X-XSS-Protection", "1")
						    .entity(userDao.displayUserIds()).build();
						   
		  }else{
			  CustomResDto resDto = new CustomResDto();
			  ResMessageDto resMessageDto = new ResMessageDto();
			  resDto.setResMessageDto(resMessageDto);
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity(resDto).build();
					  
		  }
		  
		  }catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("displayUserIds service ended");
		  }
 
	  }
	  @Path("displayActiveUsers")
	  @POST
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response displayActiveUsers(@Valid ImgHierarchyInputDTO imgHierarchyInputDTO){
		  slf4jLogger.info("displayactive users service started");
		  try{
		  UserDao userDao = new UserDao();
		  List<String> roleIdList = new ArrayList<>();
	  	 roleIdList.add(ConstantsValues.TOOLADMIN);
	  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	  roleValidationDto.setRoleIdList(roleIdList);
	  	  System.out.println(imgHierarchyInputDTO.getSessionInputDTO().getCsrfToken());
	  	 System.out.println(imgHierarchyInputDTO.getSessionInputDTO().getSessionId());
		  if(UserSessionDao.isSessionActive(imgHierarchyInputDTO.getSessionInputDTO(),roleValidationDto)){	
				  return Response.ok()
							.header("Cache-Control", "No-cache")
						    .header("X-FRAME-OPTIONS", "Deny")
						    .header("X-Content-Type-Options", "nosniff")
						    .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						    .header("X-XSS-Protection", "1")
						    .entity(userDao.activeUsersList(imgHierarchyInputDTO.getFromDate())).build();
						   
		  }else{
			
			  ResMessageDto resMessageDto = new ResMessageDto();	
			 
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity(resMessageDto).build();
					  
		  }
		  }catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("displayactive users service ended");
		  }
 
		  
		  
	
	  }
}
