 package com.acn.rpa.service;


import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.config.dto.BrownfieldMdRequestDto;
import com.acn.rpa.config.dto.MasterDataDependencyChkInDTO;
import com.acn.rpa.config.dto.MasterDataDependencyChkResDTO;
import com.acn.rpa.imghierarchy.ImgHierarchyDAO;
import com.acn.rpa.imghierarchy.ImgHierarchyDto;
import com.acn.rpa.imghierarchy.ImgHierarchyInputDTO;
import com.acn.rpa.imghierarchy.ImgHierarchyModel;
import com.acn.rpa.imghierarchy.ImgResponseDto;
import com.acn.rpa.imghierarchy.SequenceDto;
import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.RoleValidationDto;
import com.acn.user.session.IMGPreviewDto;
import com.acn.user.session.ResMessageDto;
import com.acn.user.session.SessionInputDTO;
import com.acn.user.session.UserSessionDao;

@Path("imgHierarchySrv") 
public class ImgHierarchyService {     
    private final Logger slf4jLogger = LoggerFactory.getLogger(ImgHierarchyService.class);
	  @Path("imgHierarchy/{implType}")  
	  @POST
	  @Consumes(MediaType.MULTIPART_FORM_DATA)
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response imgHierarchy (@Context HttpServletRequest request,@PathParam("implType")String implType) {  
		 slf4jLogger.info("imgHierarchy service started");
		 try{
		 ImgHierarchyDAO imgHierarchyDAOObj = new ImgHierarchyDAO();
		 ImgResponseDto imgResponseDto = new ImgResponseDto();
		 switch(implType){
		 case "ImgDependency":
			 imgResponseDto = imgHierarchyDAOObj.imgDependencyImport(request);
			 break;
		 case "ImageObjects":
			 imgResponseDto = imgHierarchyDAOObj.insertImgObjectsData(request);
			 break;
		 case "ProcessHierarchy":
			 imgResponseDto = imgHierarchyDAOObj.insertImgHierarchyData(request);
			 break;
		 case "FieldMapping":
			 imgResponseDto = imgHierarchyDAOObj.insertFieldMappingData(request);
			 break;
		 case "ImgFilterData":
			 imgResponseDto = imgHierarchyDAOObj.insertImgFilterData(request);
			 break;
		 case "ScenarioHierarchy":
			 imgResponseDto = imgHierarchyDAOObj.insertScenarioHierarchy(request);
			 break;
		 case "Industry":
			 imgResponseDto = imgHierarchyDAOObj.insertIndustryData(request);
			 break;
		default:
		imgResponseDto.setMessage("Invalid Implementation Type");
		imgResponseDto.setStatus(ConstantsValues.ERRORSTATUS);
		}
		 return Response.ok()
					.header("Cache-Control", "No-cache")
				    .header("X-FRAME-OPTIONS", "Deny")
				    .header("X-Content-Type-Options", "nosniff")
				    .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				    .header("X-XSS-Protection", "1")
				    .entity(imgResponseDto).build();
		 
		 }catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("imgHierarchy service ended");
		  }
		}
	 
	  @Path("previewFieldMapping")  
	  @POST
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response previewFieldMapping (@Valid ImgHierarchyInputDTO imgHierarchyInputDTO) {
		 slf4jLogger.info("previewFieldMapping service started");
		 try{ 
		 ImgHierarchyDAO imgHierarchyDAOObj = new ImgHierarchyDAO();
		  List<String> roleIdList = new ArrayList<>();
		  roleIdList.add(ConstantsValues.TOOLADMIN);
		  RoleValidationDto roleValidationDto = new RoleValidationDto();
		  roleValidationDto.setRoleIdList(roleIdList);
	    	if(UserSessionDao.isSessionActive(imgHierarchyInputDTO.getSessionInputDTO(),roleValidationDto)){
			 return Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity(imgHierarchyDAOObj.previewFieldMapping(imgHierarchyInputDTO.getImplType())).build();
					 
	    	}
		 else{
			 ResMessageDto resMessageDto = new ResMessageDto();
			 resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			 slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			 resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			 ImgResponseDto imgResponseDto = new ImgResponseDto();
			 imgResponseDto.setResMessageDto(resMessageDto);
			 return  Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity(imgResponseDto).build();
		 	}
		 }catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("previewFieldMapping service ended");
		  }
		  }
	 
	  @Path("previewImgFilterData")  
	  @POST
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response previewImgFilterData (@Valid ImgHierarchyInputDTO imgHierarchyInputDTO) {
		 slf4jLogger.info("previewImgFilterData service started");
		 try{
		 ImgHierarchyDAO imgHierarchyDAOObj = new ImgHierarchyDAO();
		  List<String> roleIdList = new ArrayList<>();
		  roleIdList.add(ConstantsValues.TOOLADMIN);
		  RoleValidationDto roleValidationDto = new RoleValidationDto();
		  roleValidationDto.setRoleIdList(roleIdList);
	    	if(UserSessionDao.isSessionActive(imgHierarchyInputDTO.getSessionInputDTO(),roleValidationDto)){
			return  Response.ok()
					.header("Cache-Control", "No-cache")
				    .header("X-FRAME-OPTIONS", "Deny")
				    .header("X-Content-Type-Options", "nosniff")
				    .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				    .header("X-XSS-Protection", "1")
				    .entity(imgHierarchyDAOObj.previewImgFilterData(imgHierarchyInputDTO.getImplType())).build();
					
	    	}
		 else{
			 ResMessageDto resMessageDto = new ResMessageDto();
			 resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			 slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			 resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			 ImgResponseDto imgResponseDto = new ImgResponseDto();
			 imgResponseDto.setResMessageDto(resMessageDto);
			 return  Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity(imgResponseDto).build();
			}
		 }catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("previewImgFilterData service ended");
		  }
	 }

	 @Path("previewImgHierarchy")  
	  @POST
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response previewImgHierarchy (@Valid ImgHierarchyInputDTO imgHierarchyInputDTO) {
		 slf4jLogger.info("previewImgHierarchy service started");
		try{
		 ImgHierarchyDAO imgHierarchyDAOObj = new ImgHierarchyDAO();
		 List<String> roleIdList = new ArrayList<>();
	  	  roleIdList.add(ConstantsValues.TOOLADMIN);
	  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	  roleValidationDto.setRoleIdList(roleIdList);
	    	if(UserSessionDao.isSessionActive(imgHierarchyInputDTO.getSessionInputDTO(),roleValidationDto)){
		 		return Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity(imgHierarchyDAOObj.previewImgHierarchy(imgHierarchyInputDTO.getImplType())).build();
		 				
	    	}
		 		
		 	else{
		 		 ResMessageDto resMessageDto = new ResMessageDto();
				 resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
				 slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
				 resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
				 ImgResponseDto imgResponseDto = new ImgResponseDto();
				 imgResponseDto.setResMessageDto(resMessageDto);
				 return Response.ok()
							.header("Cache-Control", "No-cache")
						    .header("X-FRAME-OPTIONS", "Deny")
						    .header("X-Content-Type-Options", "nosniff")
						    .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						    .header("X-XSS-Protection", "1")
						    .entity(imgResponseDto).build();
			}
		 	
		}catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("previewImgHierarchy service ended");
		  }
		  }
	 
	 @Path("previewIndustryData")  
	  @POST
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response previewIndustryData (@Valid ImgHierarchyInputDTO imgHierarchyInputDTO) {
		 slf4jLogger.info("previewIndustryData service started");
		try{
		 ImgHierarchyDAO imgHierarchyDAOObj = new ImgHierarchyDAO();
		 List<String> roleIdList = new ArrayList<>();
	  	  roleIdList.add(ConstantsValues.TOOLADMIN);
	  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	  roleValidationDto.setRoleIdList(roleIdList);
	    	if(UserSessionDao.isSessionActive(imgHierarchyInputDTO.getSessionInputDTO(),roleValidationDto)){
		 		return Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity(imgHierarchyDAOObj.previewIndustryData(imgHierarchyInputDTO.getImplType())).build();
		 				
	    	}
		 		
		 	else{
		 		 ResMessageDto resMessageDto = new ResMessageDto();
				 resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
				 slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
				 resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
				 ImgResponseDto imgResponseDto = new ImgResponseDto();
				 imgResponseDto.setResMessageDto(resMessageDto);
				 return Response.ok()
							.header("Cache-Control", "No-cache")
						    .header("X-FRAME-OPTIONS", "Deny")
						    .header("X-Content-Type-Options", "nosniff")
						    .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						    .header("X-XSS-Protection", "1")
						    .entity(imgResponseDto).build();
			}
		 	
		}catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("previewIndustryData service ended");
		  }
		  }
	 
	  @Path("previewImgHierarchyCopyFunctionality")  
	  @POST
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response previewImgHierarchyCopyFunctionality(@Valid ImgHierarchyInputDTO imgHierarchyInputDTO) {
		 slf4jLogger.info("previewImgHierarchy service started");
		try{
		 ImgHierarchyDAO imgHierarchyDAOObj = new ImgHierarchyDAO();
		 List<String> roleIdList = new ArrayList<>();
	  	  roleIdList.add(ConstantsValues.TOOLADMIN);
	  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	  roleValidationDto.setRoleIdList(roleIdList);
	    	if(UserSessionDao.isSessionActive(imgHierarchyInputDTO.getSessionInputDTO(),roleValidationDto)){
		 		return Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity(imgHierarchyDAOObj.previewImgHierarchyCopyFunctionality(imgHierarchyInputDTO.getImplType())).build();
		 				
	    	}
		 		
		 	else{
		 		 ResMessageDto resMessageDto = new ResMessageDto();
				 resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
				 slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
				 resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
				 ImgResponseDto imgResponseDto = new ImgResponseDto();
				 imgResponseDto.setResMessageDto(resMessageDto);
				 return Response.ok()
							.header("Cache-Control", "No-cache")
						    .header("X-FRAME-OPTIONS", "Deny")
						    .header("X-Content-Type-Options", "nosniff")
						    .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						    .header("X-XSS-Protection", "1")
						    .entity(imgResponseDto).build();
			}
		 	
		}catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("previewImgHierarchy service ended");
		  }
		  }
	 
	@Path("viewImgHierarchy")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public String viewImgHierarchy(@Valid IMGPreviewDto dto) {
		slf4jLogger.info("viewImgHierarchy service started");
		try {
			String output = "";
			ImgHierarchyModel ob = new ImgHierarchyModel();
			List<String> roleIdList = new ArrayList<>();
			roleIdList.add(ConstantsValues.PROJECTADMIN);
			roleIdList.add(ConstantsValues.TOOLADMIN);
			roleIdList.add(ConstantsValues.CONFIG);
			roleIdList.add(ConstantsValues.TEMPAD);
			roleIdList.add(ConstantsValues.TEMPAD1);
			RoleValidationDto roleValidationDto = new RoleValidationDto();
			roleValidationDto.setRoleIdList(roleIdList);
			if (UserSessionDao.isSessionActive(dto.getSessionInputDTO(), roleValidationDto)) {
				output = ob.viewImgHierarchy(dto);
				return output;
			} else
				slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			return ConstantsValues.SERVICESECURITYERROR;

		} catch (Exception e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			return ConstantsValues.EXCEPTION;

		} finally {
			slf4jLogger.info("viewImgHierarchy service ended");
		}
	}
	
	@Path("viewImgHierarchyForIndustry")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public String viewImgHierarchyForIndustry(@Valid IMGPreviewDto dto) {
		slf4jLogger.info("viewImgHierarchy service started");
		try {
			String output = "";
			ImgHierarchyModel ob = new ImgHierarchyModel();
			List<String> roleIdList = new ArrayList<>();
			roleIdList.add(ConstantsValues.PROJECTADMIN);
			roleIdList.add(ConstantsValues.TOOLADMIN);
			roleIdList.add(ConstantsValues.CONFIG);
			roleIdList.add(ConstantsValues.TEMPAD);
			roleIdList.add(ConstantsValues.TEMPAD1);
			RoleValidationDto roleValidationDto = new RoleValidationDto();
			roleValidationDto.setRoleIdList(roleIdList);
			if (UserSessionDao.isSessionActive(dto.getSessionInputDTO(), roleValidationDto)) {
				output = ob.viewImgHierarchyForIndustry(dto);
				return output;
			} else
				slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			return ConstantsValues.SERVICESECURITYERROR;

		} catch (Exception e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			return ConstantsValues.EXCEPTION;

		} finally {
			slf4jLogger.info("viewImgHierarchy service ended");
		}
	}
	@Path("viewImgHierarchyCopyFunctionality")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public String viewImgHierarchyCopyFunctionality(@Valid SessionInputDTO sessionInputDTO) {
		slf4jLogger.info("viewImgHierarchy service started");
		try {
			String output = "";
			ImgHierarchyModel ob = new ImgHierarchyModel();
			List<String> roleIdList = new ArrayList<>();
			roleIdList.add(ConstantsValues.PROJECTADMIN);
			roleIdList.add(ConstantsValues.TOOLADMIN);
			roleIdList.add(ConstantsValues.CONFIG);
			roleIdList.add(ConstantsValues.TEMPAD);
			roleIdList.add(ConstantsValues.TEMPAD1);
			RoleValidationDto roleValidationDto = new RoleValidationDto();
			roleValidationDto.setRoleIdList(roleIdList);
			if (UserSessionDao.isSessionActive(sessionInputDTO, roleValidationDto)) {
				output = ob.viewImgHierarchyCopyFunctionality();
				return output;
			} else
				slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			return ConstantsValues.SERVICESECURITYERROR;

		} catch (Exception e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
			return ConstantsValues.EXCEPTION;

		} finally {
			slf4jLogger.info("viewImgHierarchy service ended");
		}
	}
	 @Path("viewBPHierarchy")  
	  @POST
	  @Produces(MediaType.APPLICATION_JSON)
	  public String viewBPHierarchy (@Valid SessionInputDTO sessionInputDTO) {
		 slf4jLogger.info("viewBPHierarchy service started");
		 try{ 
		 ImgHierarchyModel ob = new ImgHierarchyModel();
		 List<String> roleIdList = new ArrayList<>();
	  	  roleIdList.add(ConstantsValues.PROJECTADMIN);
	  	  roleIdList.add(ConstantsValues.TOOLADMIN);
	  	  roleIdList.add(ConstantsValues.CONFIG);
	  	  roleIdList.add(ConstantsValues.TEMPAD);
	 	 roleIdList.add(ConstantsValues.TEMPAD1);
	  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	  roleValidationDto.setRoleIdList(roleIdList);
	     if(UserSessionDao.isSessionActive(sessionInputDTO,roleValidationDto))
		 		return ob.viewBPHierarchy();
		 	else
		 		 slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
		 		return ConstantsValues.SERVICESECURITYERROR;
	     
		 }catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return ConstantsValues.EXCEPTION;

		  }finally{		
			slf4jLogger.info("viewBPHierarchy service ended");
		  }
		  }
	 @Path("viewBPHierarchyforindustry")  
	  @POST
	  @Produces(MediaType.APPLICATION_JSON)
	  public String viewBPHierarchyforindustry (@Valid IMGPreviewDto dto ) {
		 slf4jLogger.info("viewBPHierarchyforindustry service started");
		 try{ 
		 ImgHierarchyModel ob = new ImgHierarchyModel();
		 List<String> roleIdList = new ArrayList<>();
	  	  roleIdList.add(ConstantsValues.PROJECTADMIN);
	  	  roleIdList.add(ConstantsValues.TOOLADMIN);
	  	  roleIdList.add(ConstantsValues.CONFIG);
	  	  roleIdList.add(ConstantsValues.TEMPAD);
	 	 roleIdList.add(ConstantsValues.TEMPAD1);
	  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	  roleValidationDto.setRoleIdList(roleIdList);
	     if(UserSessionDao.isSessionActive(dto.getSessionInputDTO(),roleValidationDto))
		 		return ob.viewBPHierarchyForIndustry(dto);
		 	else
		 		 slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
		 		return ConstantsValues.SERVICESECURITYERROR;
	     
		 }catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return ConstantsValues.EXCEPTION;

		  }finally{		
			slf4jLogger.info("viewBPHierarchyforindustry service ended");
		  }
		  }
	 
	 @Path("getDependencyImgId/{imgId}")  
	  @GET
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response getDependencyImgId (@PathParam("imgId")String imgId) {
		 slf4jLogger.info("getDependencyImgId service started");
		 try{
		 ImgHierarchyDAO imgHierarchyDAOObj = new ImgHierarchyDAO();
		  return Response.ok()
					.header("Cache-Control", "No-cache")
				    .header("X-FRAME-OPTIONS", "Deny")
				    .header("X-Content-Type-Options", "nosniff")
				    .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				    .header("X-XSS-Protection", "1")
				    .entity(imgHierarchyDAOObj.getDependencyImgId(imgId)).build();
		 }catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("getDependencyImgId service ended");
		  }	  
		  }
	 
	 @Path("getDependencyImg")  
	  @POST
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response getDependencyImg (@Valid ImgHierarchyDto imgHierarchyDto) {
		  slf4jLogger.info("getDependencyImg service started");
		 try{
		 ImgHierarchyDAO imgHierarchyDAOObj = new ImgHierarchyDAO();
		 ImgResponseDto imgResponseDto = new ImgResponseDto();
		 imgResponseDto = imgHierarchyDAOObj.getDependencyImg(imgHierarchyDto);
		  return Response.ok()
					.header("Cache-Control", "No-cache")
				    .header("X-FRAME-OPTIONS", "Deny")
				    .header("X-Content-Type-Options", "nosniff")
				    .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				    .header("X-XSS-Protection", "1")
				    .entity(imgResponseDto).build();
		 }catch(Exception e){
			 slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();
		 }
		 finally{		
			slf4jLogger.info("getDependencyImg service ended");
		  }
		}
	 
	 @Path("imgSequencing")  
	  @POST
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response returnConfigData (@Valid SequenceDto sequenceDto) {
		 slf4jLogger.info("imgSequencing service started");
		 try{
		 ImgHierarchyDAO imgHierarchyDAOObj = new ImgHierarchyDAO();
		  return  Response.ok()
					.header("Cache-Control", "No-cache")
				    .header("X-FRAME-OPTIONS", "Deny")
				    .header("X-Content-Type-Options", "nosniff")
				    .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				    .header("X-XSS-Protection", "1")
				    .entity(imgHierarchyDAOObj.returnConfigData(sequenceDto.getListSequenceDto())).build();
		 }catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("imgSequencing service ended");
		  }
	}
	 
	 @Path("masterDataDependency")  
	  @POST
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response  masterDataDependency (@Valid MasterDataDependencyChkInDTO masterDataDependencyChkInDTO) {
		 slf4jLogger.info("masterDataDependency service started");
		 try{
		 ImgHierarchyDAO imgHierarchyDAOObj = new ImgHierarchyDAO();
		 MasterDataDependencyChkResDTO masterDataDependencyChkResDTO = new MasterDataDependencyChkResDTO();
		 List<String> roleIdList = new ArrayList<>();
	  	 roleIdList.add(ConstantsValues.CONFIG);
	  	 RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	 roleValidationDto.setRoleIdList(roleIdList);
		 if(UserSessionDao.isSessionActive(masterDataDependencyChkInDTO.getSessionInputDTO(),roleValidationDto)){
			 List<BrownfieldMdRequestDto> listBrownfieldMdRequestDto = imgHierarchyDAOObj.masterDataDependency(masterDataDependencyChkInDTO);
			 masterDataDependencyChkResDTO.setListBrownfieldMdRequestDto(listBrownfieldMdRequestDto);
			 return  Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity(masterDataDependencyChkResDTO).build();
		 }
		 else{
			 ResMessageDto resMessageDto = new ResMessageDto();
			 resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			 slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			 resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			 masterDataDependencyChkResDTO.setResMessageDto(resMessageDto);
			 return Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity(masterDataDependencyChkResDTO).build();
					 
		 }
		 
		 }catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("masterDataDependency service ended");
		  }

		  
	 }
		 
	 
}
