package com.acn.rpa.service;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.config.TRStrategyImpl;
import com.acn.rpa.config.dto.RetrieveTRScopeDto;
import com.acn.rpa.imghierarchy.CustomUpdateManageTrInDto;
import com.acn.rpa.imghierarchy.ManageTrDAO;
import com.acn.rpa.imghierarchy.UpdateManageTrDAO;
import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.RoleValidationDto;
import com.acn.user.session.ResMessageDto;
import com.acn.user.session.SysInputDto;
import com.acn.user.session.TRListDto;
import com.acn.user.session.TRScopeResDto;
import com.acn.user.session.UserSessionDao;


@Path("/manageTR")
public class ManageTrService {
    private final Logger slf4jLogger = LoggerFactory.getLogger(ManageTrService.class);

		 @Path("displayManageTrTable")
		 @POST
		 @Produces(MediaType.APPLICATION_JSON)
		  public Response displayManageTR(@Valid SysInputDto sysInputDto){
			  slf4jLogger.info("displayManageTrTable service started");
			   List<String> roleIdList = new ArrayList<>();
			   roleIdList.add(ConstantsValues.PROJECTADMIN);
			   roleIdList.add(ConstantsValues.TOOLADMIN);
			   RoleValidationDto roleValidationDto = new RoleValidationDto();
			   roleValidationDto.setRoleIdList(roleIdList);
			   roleValidationDto.setOmId(sysInputDto.getOmID());
			  try{
			  if(UserSessionDao.isSessionActive(sysInputDto.getSessionInputDTO(),roleValidationDto)){	
				  ManageTrDAO manageTrDAO = new ManageTrDAO();
			  return Response.ok()
					.header("Cache-Control", "No-cache")
				    .header("X-FRAME-OPTIONS", "Deny")
				    .header("X-Content-Type-Options", "nosniff")
				    .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				    .header("X-XSS-Protection", "1")
				    .entity(manageTrDAO.getTrData(sysInputDto)).build();
						  		  
			  }else{
				  TRListDto trListDto = new TRListDto();
				  ResMessageDto resMessageDto = new ResMessageDto();
				  trListDto.setResMessageDto(resMessageDto);
				  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
				  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
				  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
				  return Response.ok()
							.header("Cache-Control", "No-cache")
						    .header("X-FRAME-OPTIONS", "Deny")
						    .header("X-Content-Type-Options", "nosniff")
						    .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						    .header("X-XSS-Protection", "1")
						    .entity(trListDto).build();
			}
			  }catch(Exception e){
				  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				  return Response.ok()
						  .header("Cache-Control", "No-cache")
						  .header("X-FRAME-OPTIONS", "Deny")
						  .header("X-Content-Type-Options", "nosniff")
						  .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						  .header("X-XSS-Protection", "1")
						  .header("Server","Disable")
						  
						  .entity(ConstantsValues.EXCEPTION).build();

			  }finally{		
				slf4jLogger.info("displayManageTrTable service ended");
			  }

		 }
		 @Path("displayManageTrTableCopyFunctionality")
		 @POST
		 @Produces(MediaType.APPLICATION_JSON)
		  public Response displayManageTRCopyFunctionality(@Valid SysInputDto sysInputDto){
			  slf4jLogger.info("displayManageTrTable service started");
			   List<String> roleIdList = new ArrayList<>();
			   roleIdList.add(ConstantsValues.PROJECTADMIN);
			   roleIdList.add(ConstantsValues.TOOLADMIN);
			   RoleValidationDto roleValidationDto = new RoleValidationDto();
			   roleValidationDto.setRoleIdList(roleIdList);
			   roleValidationDto.setOmId(sysInputDto.getOmID());
			  try{
			  if(UserSessionDao.isSessionActive(sysInputDto.getSessionInputDTO(),roleValidationDto)){	
				  ManageTrDAO manageTrDAO = new ManageTrDAO();
			  return Response.ok()
					.header("Cache-Control", "No-cache")
				    .header("X-FRAME-OPTIONS", "Deny")
				    .header("X-Content-Type-Options", "nosniff")
				    .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				    .header("X-XSS-Protection", "1")
				    .entity(manageTrDAO.getTrDataCopyFunctionality(sysInputDto)).build();
						  		  
			  }else{
				  TRListDto trListDto = new TRListDto();
				  ResMessageDto resMessageDto = new ResMessageDto();
				  trListDto.setResMessageDto(resMessageDto);
				  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
				  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
				  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
				  return Response.ok()
							.header("Cache-Control", "No-cache")
						    .header("X-FRAME-OPTIONS", "Deny")
						    .header("X-Content-Type-Options", "nosniff")
						    .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						    .header("X-XSS-Protection", "1")
						    .entity(trListDto).build();
			}
			  }catch(Exception e){
				  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				  return Response.ok()
						  .header("Cache-Control", "No-cache")
						  .header("X-FRAME-OPTIONS", "Deny")
						  .header("X-Content-Type-Options", "nosniff")
						  .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						  .header("X-XSS-Protection", "1")
						  .header("Server","Disable")
						  
						  .entity(ConstantsValues.EXCEPTION).build();

			  }finally{		
				slf4jLogger.info("displayManageTrTable service ended");
			  }

		 }

		 
		 @Path("/updateManageTrTable")
		 @Consumes({MediaType.APPLICATION_JSON})
		 @POST
		 @Produces(MediaType.APPLICATION_JSON)
		  public Response updateManageTR(@Valid CustomUpdateManageTrInDto customUpdateManageTrInDto){
			 slf4jLogger.info("updateManageTrTable service started");
			   List<String> roleIdList = new ArrayList<>();
			   roleIdList.add(ConstantsValues.PROJECTADMIN);
			   roleIdList.add(ConstantsValues.TOOLADMIN);
			   RoleValidationDto roleValidationDto = new RoleValidationDto();
			   roleValidationDto.setOmId(customUpdateManageTrInDto.getOmid());
			   roleValidationDto.setRoleIdList(roleIdList);
			 try{
			 if(UserSessionDao.isSessionActive(customUpdateManageTrInDto.getSessionInputDTO(),roleValidationDto)){	
				 UpdateManageTrDAO updateManageTrDAO=new UpdateManageTrDAO();
				 return Response.ok()
							.header("Cache-Control", "No-cache")
						    .header("X-FRAME-OPTIONS", "Deny")
						    .header("X-Content-Type-Options", "nosniff")
						    .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						    .header("X-XSS-Protection", "1")
						    .entity(updateManageTrDAO.updateTrData(customUpdateManageTrInDto)).build();
						 		  
			  }else{
				  ResMessageDto resMessageDto = new ResMessageDto();
				  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
				  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
				  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
				  return Response.ok()
							.header("Cache-Control", "No-cache")
						    .header("X-FRAME-OPTIONS", "Deny")
						    .header("X-Content-Type-Options", "nosniff")
						    .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						    .header("X-XSS-Protection", "1")
						    .entity(resMessageDto).build();
			}
			 }catch(Exception e){
				  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				  return Response.ok()
						  .header("Cache-Control", "No-cache")
						  .header("X-FRAME-OPTIONS", "Deny")
						  .header("X-Content-Type-Options", "nosniff")
						  .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						  .header("X-XSS-Protection", "1")
						  .header("Server","Disable")
						  
						  .entity(ConstantsValues.EXCEPTION).build();

			  }finally{		
				slf4jLogger.info("updateManageTrTable service ended");
			  }

		}
		 
		 
		 @Path("/retrieveScopeTR")
		 @Consumes({MediaType.APPLICATION_JSON})
		 @POST
		 @Produces(MediaType.APPLICATION_JSON)
		  public Response reteriveScopeTR(@Valid RetrieveTRScopeDto retrieveTRScopeDto){
			  slf4jLogger.info("retrieveScopeTR service started");
			 try{
				   List<String> roleIdList = new ArrayList<>();
				   roleIdList.add(ConstantsValues.CONFIG);
				   RoleValidationDto roleValidationDto = new RoleValidationDto();
				   roleValidationDto.setRoleIdList(roleIdList);
				   roleValidationDto.setOmId(retrieveTRScopeDto.getOmID());
			 if(UserSessionDao.isSessionActive(retrieveTRScopeDto.getSessionInputDTO(),roleValidationDto)){	
				 TRStrategyImpl trStrategyObj = new TRStrategyImpl();
				 return Response.ok()
							.header("Cache-Control", "No-cache")
						    .header("X-FRAME-OPTIONS", "Deny")
						    .header("X-Content-Type-Options", "nosniff")
						    .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						    .header("X-XSS-Protection", "1")
						    .entity(trStrategyObj.reteriveScopeTR(retrieveTRScopeDto)).build();
						 		  
			  }else{
				  TRScopeResDto trScopeDto = new TRScopeResDto();
				  ResMessageDto resMessageDto = new ResMessageDto();
				  trScopeDto.setResMessageDto(resMessageDto);
				  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
				  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
				  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
				  return Response.ok()
							.header("Cache-Control", "No-cache")
						    .header("X-FRAME-OPTIONS", "Deny")
						    .header("X-Content-Type-Options", "nosniff")
						    .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						    .header("X-XSS-Protection", "1")
						    .entity(trScopeDto).build();
						
			  }
			 }catch(Exception e){
				  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				  return Response.ok()
						  .header("Cache-Control", "No-cache")
						  .header("X-FRAME-OPTIONS", "Deny")
						  .header("X-Content-Type-Options", "nosniff")
						  .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						  .header("X-XSS-Protection", "1")
						  .header("Server","Disable")
						  
						  .entity(ConstantsValues.EXCEPTION).build();

			  }finally{		
				slf4jLogger.info("retrieveScopeTR service ended");
			  }
		 }
		 
		 
}
