package com.acn.rpa.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.config.ExcelFormatConvert;
import com.acn.rpa.config.dto.ConfigTemplateDto;
import com.acn.rpa.config.dto.GoldenTempCustomDto;
import com.acn.rpa.config.dto.GoldenTempUploadResDto;
import com.acn.rpa.config.dto.SelectedScopeDto;
import com.acn.rpa.docservice.HCPDocDAO;
import com.acn.rpa.docservice.HCPDocServiceResDto;
import com.acn.rpa.imghierarchy.ImgHierarchyCustomDto;
import com.acn.rpa.imghierarchy.ImgHierarchyDAO;
import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.RoleValidationDto;
import com.acn.user.session.ResMessageDto;
import com.acn.user.session.UserSessionDao;
@Path("/imgTemplateUploadSrv/")  
public class ImgTemplateUploadService {
    private final Logger slf4jLogger = LoggerFactory.getLogger(ImgTemplateUploadService.class);

	 @Path("goldenTempalteValidation")
	 @Consumes(MediaType.APPLICATION_JSON)
	 @POST
	 @Produces(MediaType.APPLICATION_JSON)
	 public Response goldenTemplateUploadValidation(@Valid GoldenTempCustomDto goldenCustomDto){
		 slf4jLogger.info("goldenTempalteValidation service started");
		 try{
		 GoldenTempUploadResDto goldenTempResDto = new GoldenTempUploadResDto();
		 ConfigTemplateDto configTemplateDto = new ConfigTemplateDto();
		 ArrayList<ConfigTemplateDto> configTempList = new ArrayList<ConfigTemplateDto>();
		 FileInputStream file;
		 List<String> fileNameList = new ArrayList<String>();
		 ImgHierarchyDAO imgHierarchyDao = new ImgHierarchyDAO();
		 ArrayList<String> imgIDList = new ArrayList<String>();
		 HashMap<String, ArrayList<String>>  imgViewMap = null;
		 ExcelFormatConvert excelFormatConvert = new ExcelFormatConvert();
		 ArrayList<String> viewList = null;
		 HCPDocDAO hcpDocDAOobj = new HCPDocDAO();
		 HCPDocServiceResDto objHCPDocServiceResDto = new HCPDocServiceResDto();
		 ArrayList<HCPDocServiceResDto> listHCPDocServiceResDto = new ArrayList<HCPDocServiceResDto>();
		 ArrayList<String> validationMsg = new ArrayList<String>();
		 Workbook workbook = null;
		 int numberofSheet = 0;
		 Sheet sheet = null;
		 Row selectedRow = null;
		 String tempCellValue = null;
		 ByteArrayOutputStream bos = null;
	  	 byte[] bytes = null; 
	  	 InputStream stream = null; 
	  	 boolean isValid = false;
		 ByteArrayInputStream byteIn = null;
		 String roleType="Admin";

		 try{
			 goldenTempResDto.setUploadStatus(true);
		 for(SelectedScopeDto selectedScopeDto: goldenCustomDto.getSelectedScopeList()){
			 imgIDList.add(selectedScopeDto.getImgId());
		 }
				if (goldenCustomDto.getCopyFlag()) {
					imgViewMap = imgHierarchyDao.getImgobjectsCopyFunctionality(imgIDList);
				}
				else if(goldenCustomDto.isIndustryFlag()) {
					imgViewMap = imgHierarchyDao.getImgobjectsForIndustry(imgIDList,goldenCustomDto.isIndustryFlag(), goldenCustomDto.getIndustry(), goldenCustomDto.getSubIndustry());
				}else
					imgViewMap = imgHierarchyDao.getImgobjects(imgIDList);
		 isValid = imgViewMap.isEmpty();
			 for(SelectedScopeDto selectedScopeDto: goldenCustomDto.getSelectedScopeList()){
				 validationMsg = new ArrayList<String>();
				 configTemplateDto = new ConfigTemplateDto();
				 if(selectedScopeDto.getIsMasterData() != null && selectedScopeDto.getIsMasterData().equalsIgnoreCase("Y")){//Skip Master data
					 validationMsg.add("Config Template Uploaded Successfully..");
					 selectedScopeDto.setFileUploadStatusMsg(validationMsg);
					 configTemplateDto.setSelectedScopeDto(selectedScopeDto);
					 configTemplateDto.setStatus(true);
					 configTemplateDto.setStatusMsg("Master data validate");
					 configTempList.add(configTemplateDto);
					 continue;
				 }else{
					 if(isValid)
					 {
						 viewList = null;
					 }
					 else{
						 viewList = imgViewMap.get(selectedScopeDto.getImgId());
					 }
					 
					 if(viewList != null){
						 configTemplateDto = excelFormatConvert.configFileValidation(selectedScopeDto, viewList,roleType);
						 //configTemplateDto = excelFormatConvert.configFileValidation_Dev(selectedScopeDto, viewList);//  Enable for Production
						 if(!configTemplateDto.isStatus()){
							 configTemplateDto.getSelectedScopeDto().setFilepath("");
							 configTemplateDto.getSelectedScopeDto().setFileName("");
							 configTemplateDto.getSelectedScopeDto().setFileUploadedIcon("");
							 goldenTempResDto.setUploadStatus(false);
						 }

						 configTempList.add(configTemplateDto);
					 }else{
						    goldenTempResDto.setUploadStatus(false);
						 	selectedScopeDto.setFilepath("");
							selectedScopeDto.setFileName("");
							selectedScopeDto.setFileUploadedIcon("");
							validationMsg.add("The configuration view from the file does not exist in the tool's repository. Please verify the view name/ sheet name from the template uploaded");
							selectedScopeDto.setFileUploadStatusMsg(validationMsg);
							configTemplateDto.setSelectedScopeDto(selectedScopeDto);
							configTemplateDto.setStatus(false);
							configTemplateDto.setStatusMsg("The configuration view from the file does not exist in the tool's repository. Please verify the view name/ sheet name from the template uploaded");
							configTempList.add(configTemplateDto);
					 }
				 }
	
			 }
		
		 }catch (Exception e) {
			 
			 for(SelectedScopeDto selectedScopeDto: goldenCustomDto.getSelectedScopeList()){
				 validationMsg = new ArrayList<String>();
			 	 configTemplateDto = new ConfigTemplateDto();
			 	 goldenTempResDto.setUploadStatus(false);
				 selectedScopeDto.setFilepath("");
				 selectedScopeDto.setFileName("");
				 selectedScopeDto.setFileUploadedIcon("");
				 validationMsg.add("The configuration view from the file does not exist in the tool's repository. Please verify the view name/ sheet name from the template uploaded");
				 selectedScopeDto.setFileUploadStatusMsg(validationMsg);
				 configTemplateDto.setSelectedScopeDto(selectedScopeDto);
				 configTemplateDto.setStatus(false);
				 configTemplateDto.setStatusMsg("The configuration view from the file does not exist in the tool's repository. Please verify the view name/ sheet name from the template uploaded");
				 configTempList.add(configTemplateDto);
			 }
		}finally {
			 imgHierarchyDao = null;
			 imgIDList = null;
			 excelFormatConvert = null;
			 viewList = null;
			 validationMsg = null;
		}
		 	
		 try{
			 int viewSize = 0;
			goldenTempResDto.setConfigTemplateDto(configTempList);
		 for(ConfigTemplateDto dto:configTempList){
			// if(dto.getSelectedScopeDto().getFilepath() != null && dto.getSelectedScopeDto().getFilepath().length() > 0){
			 if(dto.getSelectedScopeDto().getFileBytes() != null && dto.getSelectedScopeDto().getFileBytes().length > 0){
				 byteIn = new ByteArrayInputStream(dto.getSelectedScopeDto().getFileBytes());
				 //file = new FileInputStream(new File(dto.getSelectedScopeDto().getFilepath()));
				 workbook = WorkbookFactory.create(byteIn);
				 bos = new ByteArrayOutputStream();

				 if(dto.getSelectedScopeDto().getIsMasterData() == null || !dto.getSelectedScopeDto().getIsMasterData().equalsIgnoreCase("Y")){
				 int count = 5;
				 numberofSheet = 0;
				 if(workbook != null)
						numberofSheet = workbook.getNumberOfSheets();
				 viewList = null;
				 if(imgViewMap != null && imgViewMap.size() > 0)
				 viewList = imgViewMap.get(dto.getSelectedScopeDto().getImgId());
					if(viewList != null && numberofSheet > 0){
						viewSize = viewList.size(); 
						if(viewSize > 1 || numberofSheet > 1){
							int currentPos = 1;
							if(numberofSheet == viewSize){
								currentPos = viewSize;
							}else if(numberofSheet == (viewSize+1)){
								currentPos = viewSize+1;
							}
							if(currentPos > 1){
								for(int i = currentPos-1; i > 0; i--,viewSize--){
									if(!workbook.getSheetName(i).equals(viewList.get(viewSize-1).replaceAll("/", "~"))){
										workbook.setSheetOrder(viewList.get(viewSize-1).replaceAll("/", "~"), i);
									}
								}
							}	
						}
					}
				 for(int num = 0; num < numberofSheet; num++){
						if(workbook.getSheetName(num).equals("Instruction Sheet"))
							continue;
						
						 sheet = workbook.getSheetAt(num);
						 int lastRowNumber = sheet.getLastRowNum();
						 selectedRow = sheet.getRow(5);
						 if(selectedRow != null){
							 Iterator<Cell> currentCellIterator = selectedRow.cellIterator();
							 for ( int cellCount = 0;currentCellIterator.hasNext(); cellCount++) {
					                Cell cell = currentCellIterator.next();
					                if(cellCount == 0){
					                	cell.setCellType(Cell.CELL_TYPE_STRING);
					                	tempCellValue = cell.getStringCellValue();
					                	break;
					                }
					    	 }
						}
						 while(count <= lastRowNumber){
								selectedRow = sheet.getRow(count);
								if(selectedRow != null)
								sheet.removeRow(selectedRow);
								count++;
							}
							
							selectedRow = sheet.createRow(5);
							Cell newCell = selectedRow.createCell(0);
							newCell.setCellType(Cell.CELL_TYPE_STRING);
							newCell.setCellValue(tempCellValue);
			            
					}
			
				  
				 }
				 	workbook.write(bos);
	        	    bytes = bos.toByteArray();
	      	      	stream = new ByteArrayInputStream(bytes);
	      	      	String fileName = dto.getSelectedScopeDto().getImgDescription().replaceAll("[\\/:*?\"<>|\\\\]", " ");
	      	      	if(goldenCustomDto.isIndustryFlag() && !goldenCustomDto.getCopyFlag()) {
	      	      	fileName = dto.getSelectedScopeDto().getImgDescription().replaceAll("[\\/:*?\"<>|\\\\]", " ")
	      	      			+"_"+goldenCustomDto.getAliasIndustry()+"_"+goldenCustomDto.getAliasSubIndustry();
	      	      }
	      	      	objHCPDocServiceResDto = hcpDocDAOobj.createFile("BASETEMPLATE",fileName,stream,bytes,goldenCustomDto.isDocUpdate(), goldenCustomDto.isIndustryFlag());
	      	      	fileNameList.add(dto.getSelectedScopeDto().getImgDescription().replaceAll("[\\/:*?\"<>|\\\\]", " ")); 
	      	      	listHCPDocServiceResDto.add(objHCPDocServiceResDto);
			 }
			 
		 }
		 
		 
		 goldenTempResDto.setListHCPDocServiceResDto(listHCPDocServiceResDto);
		 goldenTempResDto.setFileNameList(fileNameList);
		 }catch (Exception e) {
			
			 goldenTempResDto.setListHCPDocServiceResDto(listHCPDocServiceResDto);
			 goldenTempResDto.setFileNameList(fileNameList);
			 slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}finally {
			imgViewMap = null;
			viewList = null;
			try {
				if(workbook != null)
				workbook.close();
				if(bos != null)
					bos.close();
				if(byteIn != null)
					byteIn.close();
				byteIn = null;
				if(stream != null)
					stream.close();
			} catch (IOException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}
			workbook = null;
			bytes = null;
			stream  = null;
			file = null;
			bos = null;
		}
	  return Response.ok()
				.header("Cache-Control", "No-cache")
			    .header("X-FRAME-OPTIONS", "Deny")
			    .header("X-Content-Type-Options", "nosniff")
			    .header("Content-Security-Policy",
				"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
			    .header("X-XSS-Protection", "1")
			    .entity(goldenTempResDto).build();	
	  
		 }catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("goldenTempalteValidation service ended");
		  }
	  }
	
	 @POST
	 @Produces(MediaType.APPLICATION_JSON)
	 @Path("/getIMGTemplatesPath")
	 public Response getIMGTemplatesPath(@Valid ImgHierarchyCustomDto imgHierarchyCustomDto) {
		  slf4jLogger.info("getIMGTemplatesPath service started");
		  List<String> roleIdList = new ArrayList<>();
		  	 roleIdList.add(ConstantsValues.CONFIG);
		  	 roleIdList.add(ConstantsValues.TEMPAD);
		 	 roleIdList.add(ConstantsValues.TEMPAD1);
		  	 roleIdList.add(ConstantsValues.TOOLADMIN);
		  	 RoleValidationDto roleValidationDto = new RoleValidationDto();
		  	 roleValidationDto.setRoleIdList(roleIdList);
		  if(UserSessionDao.isSessionActive(imgHierarchyCustomDto.getSessionInputDTO(),roleValidationDto)){
		  try{
		 ImgHierarchyDAO imgHierarchyDAOObj = new ImgHierarchyDAO();
		return Response.ok()
				.header("Cache-Control", "No-cache")
			    .header("X-FRAME-OPTIONS", "Deny")
			    .header("X-Content-Type-Options", "nosniff")
			    .header("Content-Security-Policy",
				"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
			    .header("X-XSS-Protection", "1")
			    .entity(imgHierarchyDAOObj.getIMGTemplatesPath(imgHierarchyCustomDto)).build();
		  }catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("getIMGTemplatesPath service ended");
		  }	
		  }
		  else{
			  ResMessageDto resMessageDto = new ResMessageDto();	
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return  Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity(resMessageDto).build();
		  }
	}
	
	 @POST
	 @Produces(MediaType.APPLICATION_JSON)
	 @Path("/getIMGTemplatesPathConfig")
	 public Response getIMGTemplatesPathConfig(@Valid ImgHierarchyCustomDto imgHierarchyCustomDto) {
		  slf4jLogger.info("getIMGTemplatesPathConfig service started");
		  List<String> roleIdList = new ArrayList<>();
		  	 roleIdList.add(ConstantsValues.CONFIG);
		  	 roleIdList.add(ConstantsValues.TEMPAD);
		 	 roleIdList.add(ConstantsValues.TEMPAD1);
		  	 roleIdList.add(ConstantsValues.TOOLADMIN);
		  	 RoleValidationDto roleValidationDto = new RoleValidationDto();
		  	 roleValidationDto.setRoleIdList(roleIdList);
		  if(UserSessionDao.isSessionActive(imgHierarchyCustomDto.getSessionInputDTO(),roleValidationDto)){
		
		  try{
		 ImgHierarchyDAO imgHierarchyDAOObj = new ImgHierarchyDAO();
		return Response.ok()
				.header("Cache-Control", "No-cache")
			    .header("X-FRAME-OPTIONS", "Deny")
			    .header("X-Content-Type-Options", "nosniff")
			    .header("Content-Security-Policy",
				"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
			    .header("X-XSS-Protection", "1")
			    .entity(imgHierarchyDAOObj.getIMGTemplatesPath()).build();
		  }catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("getIMGTemplatesPathConfig service ended");
		  }

		  }	
		  else{
			  ResMessageDto resMessageDto = new ResMessageDto();	
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return  Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity(resMessageDto).build();
		  }
	}

	@POST
	 @Consumes(MediaType.APPLICATION_JSON)
	 @Produces(MediaType.APPLICATION_JSON)
	 @Path("/downloadTemplates")
	 public Response downloadTemplates(@Valid ImgHierarchyCustomDto imgHierarchyCustomDto) {
		  slf4jLogger.info("downloadTemplates service started");
		  List<String> roleIdList = new ArrayList<>();
		  	 roleIdList.add(ConstantsValues.CONFIG);
		  	 roleIdList.add(ConstantsValues.TEMPAD);
		 	 roleIdList.add(ConstantsValues.TEMPAD1);
		  	 roleIdList.add(ConstantsValues.TOOLADMIN);

		  	 RoleValidationDto roleValidationDto = new RoleValidationDto();
		  	 roleValidationDto.setRoleIdList(roleIdList);
	if(UserSessionDao.isSessionActive(imgHierarchyCustomDto.getSessionInputDTO(),roleValidationDto)){
		try{
		 ImgHierarchyDAO imgHierarchyDAOObj = new ImgHierarchyDAO();
		return  Response.ok()
				.header("Cache-Control", "No-cache")
			    .header("X-FRAME-OPTIONS", "Deny")
			    .header("X-Content-Type-Options", "nosniff")
			    .header("Content-Security-Policy",
				"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
			    .header("X-XSS-Protection", "1")
			    .entity(imgHierarchyDAOObj.downloadTemplates(imgHierarchyCustomDto)).build();
		}catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("downloadTemplates service ended");
		  }
	}else{
		  ResMessageDto resMessageDto = new ResMessageDto();	
		  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
		  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
		  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
		  return  Response.ok()
				  .header("Cache-Control", "No-cache")
				  .header("X-FRAME-OPTIONS", "Deny")
				  .header("X-Content-Type-Options", "nosniff")
				  .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				  .header("X-XSS-Protection", "1")
				  .entity(resMessageDto).build();
	}
		 
	}
	
 	 @POST
	 @Produces(MediaType.APPLICATION_JSON)
	 @Path("/checkTemplatesExists")
	 public Response checkTemplatesExists(@Valid ImgHierarchyCustomDto imgHierarchyCustomDto) { 
		  slf4jLogger.info("checkTemplatesExists service started");
		 try{
		 ImgHierarchyDAO imgHierarchyDAOObj = new ImgHierarchyDAO();
		 return Response.ok()
					.header("Cache-Control", "No-cache")
				    .header("X-FRAME-OPTIONS", "Deny")
				    .header("X-Content-Type-Options", "nosniff")
				    .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				    .header("X-XSS-Protection", "1")
				    .entity( imgHierarchyDAOObj.checkTemplatesExists(imgHierarchyCustomDto)).build();
		 }catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("checkTemplatesExists service ended");
		  }

	}
	
		 
}