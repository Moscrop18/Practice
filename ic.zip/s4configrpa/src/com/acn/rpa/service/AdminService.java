package com.acn.rpa.service;
import java.util.ArrayList;
import java.util.List;
import javax.validation.Valid;
import javax.validation.ValidationException;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.admin.GetUserDetails;
import com.acn.rpa.admin.SaltResDTO;
import com.acn.rpa.admin.UserValidationDTO;
import com.acn.rpa.admin.VersionResDTO;
import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.PropMappings;
import com.acn.rpa.utilities.RoleValidationDto;
import com.acn.user.session.CredentialDto;
import com.acn.user.session.DataStatusDto;
import com.acn.user.session.LoginDto;
import com.acn.user.session.ResMessageDto;
import com.acn.user.session.ResetCredentialDto;
import com.acn.user.session.SecurityAnsInputDto;
import com.acn.user.session.SessionInputDTO;
import com.acn.user.session.UserRolesDto;
import com.acn.user.session.UserSecurityDao;
import com.acn.user.session.UserSessionDao;
import com.acn.user.session.UserSessionDto;  

@Path("/adminSrv")  
public class AdminService {
	
    private final Logger slf4jLogger = LoggerFactory.getLogger(AdminService.class);
    private static final String text = "Message from Server :\n%s";
  
  @Path("validateRole")
  @POST
  @Produces({MediaType.APPLICATION_JSON})
  public Response validateRole (@Valid LoginDto loginDto) throws ValidationException{
	  try{
		  slf4jLogger.info("ValidateRole service started");
	  	  GetUserDetails userDetails = new GetUserDetails();
	  	  return   Response.ok()
			  .header("Cache-Control", "No-cache")
			  
			  .header("X-Content-Type-Options", "nosniff")
			  .header("Content-Security-Policy",
				"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
		
			  .header("Server","Disable")
			  
			  .entity(userDetails.validateRole(loginDto)).build();
	  	}
	  catch(Exception e){
		  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		  return Response.ok()
				  .header("Cache-Control", "No-cache")
				  .header("X-FRAME-OPTIONS", "Deny")
				  .header("X-Content-Type-Options", "nosniff")
				  .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				  .header("X-XSS-Protection", "1")
				  .header("Server","Disable")
				  
				  .entity(ConstantsValues.EXCEPTION).build();

	  }finally{		
		slf4jLogger.info("ValidateRole service ended");
	  }
  }
  
  @Path("displayRoles")
  @POST  
  @Produces(MediaType.APPLICATION_JSON)
  public Response displayRoles(@Valid SessionInputDTO dto){
	  List<String> roleIdList = new ArrayList<>();
  	  roleIdList.add(ConstantsValues.PROJECTADMIN);
  	  roleIdList.add(ConstantsValues.TOOLADMIN);
  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
  	  roleValidationDto.setRoleIdList(roleIdList);
	  slf4jLogger.info("displayRoles service started");
	  try{
	  if(UserSessionDao.isSessionActive(dto,roleValidationDto)){	
			  GetUserDetails userDetails = new GetUserDetails();
			  return   Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity( userDetails.displayRoles()).build();			  
	  }else{
		  UserRolesDto userRolesDto = new UserRolesDto();
		  ResMessageDto resMessageDto = new ResMessageDto();	
		  userRolesDto.setResMessageDto(resMessageDto);
		  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
		  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
		  return  Response.ok()
				  .header("Cache-Control", "No-cache")
				  .header("X-FRAME-OPTIONS", "Deny")
				  .header("X-Content-Type-Options", "nosniff")
				  .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				  .header("X-XSS-Protection", "1")
				  .entity(userRolesDto).build();
				  
	  }
	 }catch(Exception e){
		  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		  return Response.ok()
				  .header("Cache-Control", "No-cache")
				  .header("X-FRAME-OPTIONS", "Deny")
				  .header("X-Content-Type-Options", "nosniff")
				  .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				  .header("X-XSS-Protection", "1")
				  .header("Server","Disable")
				  
				  .entity(ConstantsValues.EXCEPTION).build();
	 }
	 finally{
		  slf4jLogger.info("displayRoles service ended");

	 }
  }

  @Path("getVersion")
  @POST
  @Produces(MediaType.APPLICATION_JSON)
  public Response getVersion(){ 
	  slf4jLogger.info("getVersion service started");
	  try{
	  PropMappings propObj = PropMappings.getInstance(); 
	  VersionResDTO versionResObj = new VersionResDTO();
	  versionResObj.setVersion(Double.parseDouble(propObj.getValue("VERSION")));
	  return   Response.ok()
			  .header("Cache-Control", "No-cache")
			  .header("X-FRAME-OPTIONS", "Deny")
			  .header("X-Content-Type-Options", "nosniff")
			  .header("Content-Security-Policy",
				"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
			  .header("X-XSS-Protection", "1")
			  .entity(versionResObj).build();
	  }catch(Exception e){
		  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		  return Response.ok()
				  .header("Cache-Control", "No-cache")
				  .header("X-FRAME-OPTIONS", "Deny")
				  .header("X-Content-Type-Options", "nosniff")
				  .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				  .header("X-XSS-Protection", "1")
				  .header("Server","Disable")
				  
				  .entity(ConstantsValues.EXCEPTION).build();
	 }
	 finally{
		  slf4jLogger.info("getVersion service ended");

	 }
			  
  }  
 
  @Path("getSaltValue")
  @POST  
  @Produces(MediaType.APPLICATION_JSON)
  public Response getSaltValue( ){
	  slf4jLogger.info("getSaltValue service started");
	  try{
	  PropMappings propObj = PropMappings.getInstance(); 
	  SaltResDTO responseObj = new SaltResDTO();
	  responseObj.setSalt(propObj.getValue("SALT"));
	 // response.setHeader("Server", "null");
	  return  Response.ok()
			  .header("Cache-Control", "No-cache")
			  .header("X-FRAME-OPTIONS", "Deny")
			  .header("X-Content-Type-Options", "nosniff")
			  .header("Content-Security-Policy",
				"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
			  .header("X-XSS-Protection", "1")
			  .entity(responseObj).build();
	  }catch(Exception e){
		  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		  return Response.ok()
				  .header("Cache-Control", "No-cache")
				  .header("X-FRAME-OPTIONS", "Deny")
				  .header("X-Content-Type-Options", "nosniff")
				  .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				  .header("X-XSS-Protection", "1")
				  .header("Server","Disable")
				  
				  .entity(ConstantsValues.EXCEPTION).build();
	 }
	 finally{
		  slf4jLogger.info("getSaltValue service ended");

	 }
  } 
  @Path("logOutSrv")
  @POST  
  @Produces(MediaType.APPLICATION_JSON)
  public Response logOutSrv(@Valid UserSessionDto userSessionDto){
	  slf4jLogger.info("logOutSrv service started");
	  try{
	  ResMessageDto resMessageDto = new ResMessageDto();
	  List<String> roleIdList = new ArrayList<>();
  	  roleIdList.add(ConstantsValues.PROJECTADMIN);
  	  roleIdList.add(ConstantsValues.TOOLADMIN);
  	  roleIdList.add(ConstantsValues.CONFIG);
  	  roleIdList.add(ConstantsValues.TEMPAD);
	  roleIdList.add(ConstantsValues.TEMPAD1);

  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
  	  roleValidationDto.setRoleIdList(roleIdList);
	  if(UserSessionDao.isSessionActive(userSessionDto.getSessionInputDTO(),roleValidationDto)){
		  UserSessionDao userSessionDao = new UserSessionDao();
		 return Response.ok()
				  .header("Cache-Control", "No-cache")
				  .header("X-FRAME-OPTIONS", "Deny")
				  .header("X-Content-Type-Options", "nosniff")
				  .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				  .header("X-XSS-Protection", "1")
				  .entity(userSessionDao.sessionLogout(userSessionDto)).build();
				 
	  }
	  else{
			 resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			 resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			 return    Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity(resMessageDto).build();
					 
	  }
	  }catch(Exception e){
		  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		  return Response.ok()
				  .header("Cache-Control", "No-cache")
				  .header("X-FRAME-OPTIONS", "Deny")
				  .header("X-Content-Type-Options", "nosniff")
				  .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				  .header("X-XSS-Protection", "1")
				  .header("Server","Disable")
				  
				  .entity(ConstantsValues.EXCEPTION).build();
	 }
	 finally{
		  slf4jLogger.info("logOutSrv service ended");

	 }
  }	  
  @Path("updatePassword")
  @POST
  @Produces({MediaType.APPLICATION_JSON})
  public Response updatePassword (@Valid CredentialDto credentialDto) throws ValidationException{
	  try{
		  slf4jLogger.info("updatePassword service started");
		  UserSecurityDao userSecurityDao = new UserSecurityDao();
	  	  return   Response.ok()
			  .header("Cache-Control", "No-cache")
			  .header("X-FRAME-OPTIONS", "Deny")
			  .header("X-Content-Type-Options", "nosniff")
			  .header("Content-Security-Policy",
				"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
			  .header("X-XSS-Protection", "1")
			  .header("Server","Disable")
			  
			  .entity(userSecurityDao.updatePassword(credentialDto)).build();
	  	}
	  catch(Exception e){
		  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		  return Response.ok()
				  .header("Cache-Control", "No-cache")
				  .header("X-FRAME-OPTIONS", "Deny")
				  .header("X-Content-Type-Options", "nosniff")
				  .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				  .header("X-XSS-Protection", "1")
				  .header("Server","Disable")
				  
				  .entity(ConstantsValues.EXCEPTION).build();

	  }finally{		
		slf4jLogger.info("updatePassword service ended");
	  }
  }
  @Path("resetPassword")
  @POST
  @Produces({MediaType.APPLICATION_JSON})
  public Response resetPassword (@Valid ResetCredentialDto resetcredentialDto) throws ValidationException{
	  try{
		  slf4jLogger.info("resetPassword service started");
		  UserSecurityDao userSecurityDao = new UserSecurityDao();
	  	  return Response.ok()
			  .header("Cache-Control", "No-cache")

			  .header("X-Content-Type-Options", "nosniff")
			  .header("Content-Security-Policy",
				"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
			
			  .header("Server","Disable")
			  
			  .entity(userSecurityDao.resetPassword(resetcredentialDto)).build();
	  	}
	  catch(Exception e){
		  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		  return Response.ok()
				  .header("Cache-Control", "No-cache")
				 
				  .header("X-Content-Type-Options", "nosniff")
				  .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				  
					.entity(ConstantsValues.EXCEPTION).build();

	  }finally{		
		slf4jLogger.info("resetPassword service ended");
	  }
  }
  @Path("updateSecurityAnswers")
  @POST
  @Produces({MediaType.APPLICATION_JSON})
  public Response updateSecurityQA (@Valid SecurityAnsInputDto securityAnsInputDto) throws ValidationException{
	  try{
		  slf4jLogger.info("updateSecurityQA service started");
		  UserSecurityDao userSecurityDao = new UserSecurityDao();
	  	  return   Response.ok()
			  .header("Cache-Control", "No-cache")
			  .header("X-FRAME-OPTIONS", "Deny")
			  .header("X-Content-Type-Options", "nosniff")
			  .header("Content-Security-Policy",
				"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
			  .header("X-XSS-Protection", "1")
			  .header("Server","Disable")
			  
			  .entity(userSecurityDao.updateSecurityQA(securityAnsInputDto)).build();
	  	}
	  catch(Exception e){
		  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		  return Response.ok()
				  .header("Cache-Control", "No-cache")
				  .header("X-FRAME-OPTIONS", "Deny")
				  .header("X-Content-Type-Options", "nosniff")
				  .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				  .header("X-XSS-Protection", "1")
				  .header("Server","Disable")
				  
				  .entity(ConstantsValues.EXCEPTION).build();

	  }finally{		
		slf4jLogger.info("updateSecurityQA service ended");
	  }
  }
  @Path("userIdValidation")
  @POST
  @Produces({MediaType.APPLICATION_JSON})
  public Response userIdValidation (@Valid UserValidationDTO userValidationDTO) throws ValidationException{
	  try{
		  slf4jLogger.info("updateSecurityQA service started");
		  UserSecurityDao userSecurityDao = new UserSecurityDao();
	  	  return   Response.ok()
			  .header("Cache-Control", "No-cache")
			  .header("X-FRAME-OPTIONS", "Deny")
			  .header("X-Content-Type-Options", "nosniff")
			  .header("Content-Security-Policy",
				"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
			  .header("X-XSS-Protection", "1")
			  .header("Server","Disable")
			  
			  .entity(userSecurityDao.userIdValidation(userValidationDTO)).build();
	  	}
	  catch(Exception e){
		  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		  return Response.ok()
				  .header("Cache-Control", "No-cache")
				  .header("X-FRAME-OPTIONS", "Deny")
				  .header("X-Content-Type-Options", "nosniff")
				  .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				  .header("X-XSS-Protection", "1")
				  .header("Server","Disable")
				  
				  .entity(ConstantsValues.EXCEPTION).build();

	  }finally{		
		slf4jLogger.info("updateSecurityQA service ended");
	  }
  }
  @Path("securityQAvalidation")
  @POST
  @Produces({MediaType.APPLICATION_JSON})
  public Response securityQAvalidation (@Valid SecurityAnsInputDto securityAnsInputDto) throws ValidationException{
	  try{
		  slf4jLogger.info("securityQAvalidation service started");
		  UserSecurityDao userSecurityDao = new UserSecurityDao();
	  	  return   Response.ok()
			  .header("Cache-Control", "No-cache")
			  .header("X-FRAME-OPTIONS", "Deny")
			  .header("X-Content-Type-Options", "nosniff")
			  .header("Content-Security-Policy",
				"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
			  .header("X-XSS-Protection", "1")
			  .header("Server","Disable")
			  
			  .entity(userSecurityDao.securityQAvalidation(securityAnsInputDto)).build();
	  	}
	  catch(Exception e){
		  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		  return Response.ok()
				  .header("Cache-Control", "No-cache")
				  .header("X-FRAME-OPTIONS", "Deny")
				  .header("X-Content-Type-Options", "nosniff")
				  .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				  .header("X-XSS-Protection", "1")
				  .header("Server","Disable")
				  
				  .entity(ConstantsValues.EXCEPTION).build();

	  }finally{		
		slf4jLogger.info("securityQAvalidation service ended");
	  }
  }
  
  @Path("getSecurityQuestions")
  @POST
  @Produces({MediaType.APPLICATION_JSON})
  public Response getSecurityQuestions () throws ValidationException{
	  try{
		  slf4jLogger.info("getSecurityQuestions service started");
		  UserSecurityDao userSecurityDao = new UserSecurityDao();
	  	  return   Response.ok()
			  .header("Cache-Control", "No-cache")
			  .header("X-FRAME-OPTIONS", "Deny")
			  .header("X-Content-Type-Options", "nosniff")
			  .header("Content-Security-Policy",
				"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
			  .header("X-XSS-Protection", "1")
			  .header("Server","Disable")
			  
			  .entity(userSecurityDao.getSecurityQuestions()).build();
	  	}
	  catch(Exception e){
		  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		  return Response.ok()
				  .header("Cache-Control", "No-cache")
				  .header("X-FRAME-OPTIONS", "Deny")
				  .header("X-Content-Type-Options", "nosniff")
				  .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				  .header("X-XSS-Protection", "1")
				  .header("Server","Disable")
				  
				  .entity(ConstantsValues.EXCEPTION).build();

	  }finally{		
		slf4jLogger.info("getSecurityQuestions service ended");
	  }
  }
  
  @Path("resetSessionTime")
  @POST
  @Produces({MediaType.APPLICATION_JSON})
  public Response resetSessionTime(@Valid SessionInputDTO sessionInputDTO) throws ValidationException{
	  try{
		  
		  slf4jLogger.info("resetSessionTime service started");
		  List<String> roleIdList = new ArrayList<>();
	  	  roleIdList.add(ConstantsValues.PROJECTADMIN);
	  	  roleIdList.add(ConstantsValues.TOOLADMIN);
	  	  roleIdList.add(ConstantsValues.TEMPAD);
	  	  roleIdList.add(ConstantsValues.CONFIG);	  	  
	  	  roleIdList.add(ConstantsValues.TEMPAD1);
	  	  
	  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	  roleValidationDto.setRoleIdList(roleIdList);
		  if(UserSessionDao.isSessionActive(sessionInputDTO,roleValidationDto)){

	  	  return   Response.ok()
			  .header("Cache-Control", "No-cache")
			  
			  .header("X-Content-Type-Options", "nosniff")
			  .header("Content-Security-Policy",
				"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
		
			  .header("Server","Disable")
			  
			  .entity(UserSessionDao.resetSessionExpirtTime(sessionInputDTO)).build();
	  		}
		  
	  	else{
			  DataStatusDto resDto = new DataStatusDto();
			  ResMessageDto resMessageDto = new ResMessageDto();	
			  resDto.setResMessageDto(resMessageDto);
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return Response.ok()
 					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity(resDto).build();
		  }
	  }
	  catch(Exception e){
		  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		  return Response.ok()
				  .header("Cache-Control", "No-cache")
				  .header("X-FRAME-OPTIONS", "Deny")
				  .header("X-Content-Type-Options", "nosniff")
				  .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				  .header("X-XSS-Protection", "1")
				  .header("Server","Disable")
				  
				  .entity(ConstantsValues.EXCEPTION).build();

	  }finally{		
		slf4jLogger.info("resetSessionTime service ended");
	  }
  }
}  