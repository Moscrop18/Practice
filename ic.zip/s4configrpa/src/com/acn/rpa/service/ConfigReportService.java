package com.acn.rpa.service;

import java.io.IOException;
import java.util.ArrayList;
//import java.util.Base64;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.reports.ConfigDownloadRequestDTO;
import com.acn.rpa.reports.ConfigDownloadResLogDTO;
import com.acn.rpa.reports.ConfigDownloadResponseDTO;
import com.acn.rpa.reports.ConfigReportResDTO;
import com.acn.rpa.reports.ConfigResponseReportDto;
import com.acn.rpa.reports.ConfigTransactionReportDAO;
import com.acn.rpa.reports.ConfigTransactionReportDto;
import com.acn.rpa.reports.ExecutionSummaryResDto;
import com.acn.rpa.reports.TimeLogReportInputDto;
import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.RoleValidationDto;
import com.acn.user.session.ResMessageDto;
import com.acn.user.session.UserSessionDao;
/*import com.sap.core.connectivity.api.configuration.ConnectivityConfiguration;
import com.sap.core.connectivity.api.configuration.DestinationConfiguration;*/
 



@Path("configReportService")

@Produces(MediaType.APPLICATION_JSON)
public class ConfigReportService {
    private final Logger slf4jLogger = LoggerFactory.getLogger(ConfigReportService.class);
	  @Path("getConfigTransaction")
	  @POST
	  @Consumes({MediaType.APPLICATION_JSON})
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response getConfigTransaction (@Valid ConfigTransactionReportDto ConfigTransactionReportDto){
		  slf4jLogger.info("getConfigTransaction service started");
		  try{
			  List<String> roleIdList = new ArrayList<>();
			  roleIdList.add(ConstantsValues.CONFIG);
			  roleIdList.add(ConstantsValues.PROJECTADMIN);
			  RoleValidationDto roleValidationDto = new RoleValidationDto();
			  roleValidationDto.setRoleIdList(roleIdList);
			  roleValidationDto.setOmId(ConfigTransactionReportDto.getOmID());

		  if(UserSessionDao.isSessionActive(ConfigTransactionReportDto.getSessionInputDTO(),roleValidationDto)){
		  ConfigTransactionReportDAO configTransactionReportDAO = new ConfigTransactionReportDAO();
		  ArrayList<ConfigResponseReportDto> configExecutionLogList = new ArrayList<ConfigResponseReportDto>();
		  
		  configExecutionLogList = configTransactionReportDAO.getConfigTransactionData(ConfigTransactionReportDto);
		  if(configExecutionLogList.size()>0){
			  return  Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity(configExecutionLogList).build();
					  
		  }
		  return Response.ok()
				  .header("Cache-Control", "No-cache")
				  .header("X-FRAME-OPTIONS", "Deny")
				  .header("X-Content-Type-Options", "nosniff")
				  .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				  .header("X-XSS-Protection", "1")
				  .entity("{\"message\": \"No Results Found! \"}").build();
				
		  }
		  else{slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  return   Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity("{\"message\": \""+ ConstantsValues.SERVICESECURITYERROR +"\"}").build();
					  

		  }
		  }
		  catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("getConfigTransaction service ended");
		  }
	  }
	  @Path("getConfigUploadTransaction")
	  @POST
	  @Consumes({MediaType.APPLICATION_JSON})
	  @Produces(MediaType.APPLICATION_JSON)
	  public  Response getConfigUploadTransaction (@Valid ConfigResponseReportDto configTransactionInputDto){
		  slf4jLogger.info("getConfigUploadTransaction service started");
		  try{
		  List<String> roleIdList = new ArrayList<>();
		  roleIdList.add(ConstantsValues.CONFIG);
		  roleIdList.add(ConstantsValues.PROJECTADMIN);
		  RoleValidationDto roleValidationDto = new RoleValidationDto();
		  roleValidationDto.setRoleIdList(roleIdList);
		  ExecutionSummaryResDto executionSummaryResDto = new ExecutionSummaryResDto();
		  if(UserSessionDao.isSessionActive(configTransactionInputDto.getSessionInputDTO(),roleValidationDto)){
		  ConfigTransactionReportDAO configTransactionReportDAO = new ConfigTransactionReportDAO();
		  executionSummaryResDto = configTransactionReportDAO.getConfigUploadTransactionData(configTransactionInputDto);
		  	return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity(executionSummaryResDto).build();
		  			
		  }
		  else{
			  	 ResMessageDto resMessageDto = new ResMessageDto();
				 resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
				 slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
				 resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
				 executionSummaryResDto.setResMessageDto(resMessageDto);
				 return  Response.ok()
						  .header("Cache-Control", "No-cache")
						  .header("X-FRAME-OPTIONS", "Deny")
						  .header("X-Content-Type-Options", "nosniff")
						  .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						  .header("X-XSS-Protection", "1")
						  .entity(executionSummaryResDto).build();
						 
		  }
		  }
		  catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("getConfigUploadTransaction service ended");
		  }
		}
	  
	  @Path("getTimeLogReport")
	  @POST
	
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response getTimeLogReport (@Valid TimeLogReportInputDto timeLogReportInputDto) throws ParseException, IOException, NamingException {
		  slf4jLogger.info("getTimeLogReport service started");
		  List<String> roleIdList = new ArrayList<>();
		  roleIdList.add(ConstantsValues.TOOLADMIN);
		  RoleValidationDto roleValidationDto = new RoleValidationDto();
		  roleValidationDto.setRoleIdList(roleIdList);
		 /* try{
		  if(UserSessionDao.isSessionActive(timeLogReportInputDto.getSessionInputDTO(),roleValidationDto)){
		  	HttpEntity entity = null;
	        HttpResponse response = null; 
	       DestinationConfiguration destConfiguration = getDestinationConfiguration(timeLogReportInputDto.getDestinationName());

            String username = destConfiguration.getProperty("User");
            String password = destConfiguration.getProperty("Password");
            String urlCloud = destConfiguration.getProperty("URL");
	        String loginPassword = username+":"+password;
		     String encoded = new sun.misc.BASE64Encoder().encode (loginPassword.getBytes());
		     HttpClient client = new DefaultHttpClient();
	         HttpGet getRequest = new HttpGet(urlCloud);
	         getRequest.setHeader("Authorization", "Basic "+encoded);
	         getRequest.setHeader("Content-type", "application/json");

	             try{
	            	 
	            	 response = (HttpResponse) client.execute(getRequest);
	            	 response.addHeader("Content-type", "application/json");
	            	 response.addHeader("Allow-control-cross-origin", "*");
	            	 response.addHeader("cache-control", "no-cache"); 
	            	 response.addHeader("X-FRAME-OPTIONS", "Deny"); 
	            	 entity = response.getEntity();
	            	 return Response.ok()
	   					  .header("Cache-Control", "No-cache")
						  .header("X-FRAME-OPTIONS", "Deny")
						  .header("X-Content-Type-Options", "nosniff")
						  .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						  .header("X-XSS-Protection", "1")
						  .entity( EntityUtils.toString(entity)).build();
	            			 
	             }catch(Throwable e){
	             }
             
	             return   Response.ok()
	   					  .header("Cache-Control", "No-cache")
						  .header("X-FRAME-OPTIONS", "Deny")
						  .header("X-Content-Type-Options", "nosniff")
						  .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						  .header("X-XSS-Protection", "1")
						  .entity(  EntityUtils.toString(entity)).build();
	            		
		  }
		  else{
			  return   Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity(ConstantsValues.SERVICESECURITYERROR).build();
					  
		  }
		  }
		  catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("getTimeLogReport service ended");
		  }*/
		  return Response.ok().entity(ConstantsValues.EXCEPTION).build();
}

	 /* private DestinationConfiguration getDestinationConfiguration(String destName) throws NamingException {
          		 Context ctx;          
                 ctx = new InitialContext();
                 ConnectivityConfiguration configuration = (ConnectivityConfiguration) ctx
                              .lookup("java:comp/env/connectivityConfiguration");
                 // Get destination configuration for "destinationName"
                 DestinationConfiguration destConfiguration = configuration.getConfiguration(destName);
                 return destConfiguration;

    }*/

	  @Path("getConfigDownloadTransaction")
	  @POST
	  @Consumes({MediaType.APPLICATION_JSON})
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response getConfigDownloadTransaction (@Valid ConfigTransactionReportDto configTransactionReportDto){
		  slf4jLogger.info("getConfigDownloadTransaction service started");
		  try{
		  ConfigReportResDTO configReportResDTO = new ConfigReportResDTO();
		  List<String> roleIdList = new ArrayList<>();
		  roleIdList.add(ConstantsValues.CONFIG);
		  RoleValidationDto roleValidationDto = new RoleValidationDto();
		  roleValidationDto.setOmId(configTransactionReportDto.getOmID());
		  roleValidationDto.setRoleIdList(roleIdList);
		  if(UserSessionDao.isSessionActive(configTransactionReportDto.getSessionInputDTO(),roleValidationDto)){
			 ConfigTransactionReportDAO configTransactionReportDAO = new ConfigTransactionReportDAO();
		  	 ArrayList<ConfigDownloadResponseDTO> configExecutionLogList = new ArrayList<ConfigDownloadResponseDTO>();
		  	 configExecutionLogList = configTransactionReportDAO.getConfigDownloadTransaction(configTransactionReportDto);
		  	 configReportResDTO.setListConfigDownloadResponseDTO(configExecutionLogList);
		  	 return    Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity(configReportResDTO).build();
		  			 
		  }
		  else{
		  	 ResMessageDto resMessageDto = new ResMessageDto();
			 resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			 slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			 resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			 configReportResDTO.setResMessageDto(resMessageDto);
			 return    Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity(configReportResDTO).build();
					 
		  }
		  }
		  catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("getConfigDownloadTransaction service ended");
		  }
	  }
		  
	  @Path("getConfigDownloadTransactionLogs")
	  @POST
	  @Consumes({MediaType.APPLICATION_JSON})
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response getConfigDownloadTransactionLogs (@Valid ConfigDownloadRequestDTO ConfigDownloadRequestDTO){
		  slf4jLogger.info("getConfigDownloadTransactionLogs service started");
		  try{
			List<String> roleIdList = new ArrayList<>();
			roleIdList.add(ConstantsValues.CONFIG);
			roleIdList.add(ConstantsValues.PROJECTADMIN);
			RoleValidationDto roleValidationDto = new RoleValidationDto();
			roleValidationDto.setRoleIdList(roleIdList);
		  if(UserSessionDao.isSessionActive(ConfigDownloadRequestDTO.getSessionInputDTO(),roleValidationDto)){
		  ConfigTransactionReportDAO configTransactionReportDAO = new ConfigTransactionReportDAO();
		  ArrayList<ConfigDownloadResLogDTO> configDownloadLogList = new ArrayList<ConfigDownloadResLogDTO>();
		  
		  configDownloadLogList = configTransactionReportDAO.getConfigDownloadTransactionLogs(ConfigDownloadRequestDTO);
		  if(configDownloadLogList.size()>0){
			  return  Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity(configDownloadLogList).build();
					 
		  }
		  return  Response.ok()
				  .header("Cache-Control", "No-cache")
				  .header("X-FRAME-OPTIONS", "Deny")
				  .header("X-Content-Type-Options", "nosniff")
				  .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				  .header("X-XSS-Protection", "1")
				  .entity("{\"message\": \"No Results Found! \"}").build();
				  
		  }
		  else{slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  return  Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .entity("{\"message\": \""+ ConstantsValues.SERVICESECURITYERROR +"\"}").build();
					  }
		  }
		  catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("getConfigDownloadTransactionLogs service ended");
		  }
	  }
		  
}

