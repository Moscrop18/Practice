package com.acn.rpa.service;


import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.config.DynamicDestinationDAO;
import com.acn.rpa.config.DynamicDestinationDAO2;
import com.acn.rpa.config.DynamicDestinationResDto;
import com.acn.rpa.config.SAPUserDto;
import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.RoleValidationDto;
import com.acn.user.session.ResMessageDto;
import com.acn.user.session.UserSessionDao;



@Path("dynamicDestination") 
public class DynamicDestinationService {
    private final Logger slf4jLogger = LoggerFactory.getLogger(DynamicDestinationService.class);

	 @Path("validateSAPCredentials") 
	  @POST
	  @Consumes({MediaType.APPLICATION_JSON})
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response  createCustomer (@Valid SAPUserDto  sapUserDetails){
		  slf4jLogger.info("validateSAPCredentials service started");
		  List<String> roleIdList = new ArrayList<>();
		  roleIdList.add(ConstantsValues.CONFIG);
		  RoleValidationDto roleValidationDto = new RoleValidationDto();
		  roleValidationDto.setRoleIdList(roleIdList);
		 try{
		  DynamicDestinationResDto dynamicDestinationResDto = new DynamicDestinationResDto(); 
		  DynamicDestinationDAO dynamicDestinationObj = new DynamicDestinationDAO();
		  if(UserSessionDao.isSessionActive(sapUserDetails.getSessionInputDTO(),roleValidationDto)){
			  dynamicDestinationResDto = dynamicDestinationObj.validateSAPCredentials(sapUserDetails);
			  return Response.ok()
   					  .header("Cache-Control", "No-cache")
					 
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  
					  .entity(dynamicDestinationResDto).build();
					  
		  }
		  else{
			  	 ResMessageDto resMessageDto = new ResMessageDto();
				 resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
				 slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
				 resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
				 dynamicDestinationResDto.setResMessageDto(resMessageDto);
				 return Response.ok()
	   					  .header("Cache-Control", "No-cache")
						 
						  .header("X-Content-Type-Options", "nosniff")
						  .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						  
						  .entity(dynamicDestinationResDto).build();
		  }
		 }
		  catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					 
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("validateSAPCredentials service ended");
		  }
	  }
	/* @Path("validateSAPCredentials") 
	  @POST
	  @Consumes({MediaType.APPLICATION_JSON})
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response  createCustomer (@Valid SAPUserDto  sapUserDetails){
		  slf4jLogger.info("validateSAPCredentials service started");
		  List<String> roleIdList = new ArrayList<>();
		  roleIdList.add(ConstantsValues.CONFIG);
		  RoleValidationDto roleValidationDto = new RoleValidationDto();
		  roleValidationDto.setRoleIdList(roleIdList);
		 try{
		  DynamicDestinationResDto dynamicDestinationResDto = new DynamicDestinationResDto(); 
		  DynamicDestinationDAO2 dynamicDestinationObj = new DynamicDestinationDAO2();
		  if(UserSessionDao.isSessionActive(sapUserDetails.getSessionInputDTO(),roleValidationDto)){
			    dynamicDestinationObj.step1Connect();
			  return Response.ok().entity("Conncted to destination sucessfully").build();
					  
		  }
		  else{
			  	 ResMessageDto resMessageDto = new ResMessageDto();
				 resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
				 slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
				 resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
				 dynamicDestinationResDto.setResMessageDto(resMessageDto);
				 return Response.ok()
	   					  .header("Cache-Control", "No-cache")
						 
						  .header("X-Content-Type-Options", "nosniff")
						  .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						  
						  .entity(dynamicDestinationResDto).build();
		  }
		 }
		  catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					 
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("validateSAPCredentials service ended");
		  }
	  }
*/	
	 @Path("validateDestination") 
	  @POST
	  @Consumes({MediaType.APPLICATION_JSON})
	  @Produces(MediaType.APPLICATION_JSON)
	 public Response  createDestination (@Valid SAPUserDto  sapUserDetails){
		  slf4jLogger.info("validateDestination service started");
		  List<String> roleIdList = new ArrayList<>();
		  roleIdList.add(ConstantsValues.CONFIG);
		  RoleValidationDto roleValidationDto = new RoleValidationDto();
		  roleValidationDto.setRoleIdList(roleIdList);
		 try{
		  DynamicDestinationResDto dynamicDestinationResDto = new DynamicDestinationResDto(); 
		  if(UserSessionDao.isSessionActive(sapUserDetails.getSessionInputDTO(),roleValidationDto)){
			  DynamicDestinationDAO dynamicDestinationObj = new DynamicDestinationDAO();
			  dynamicDestinationResDto = dynamicDestinationObj.validateDestination(sapUserDetails);
			  return Response.ok()
   					  .header("Cache-Control", "No-cache")
					 
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					 
					  .entity(dynamicDestinationResDto).build();

		  }
		  else{
			  	 ResMessageDto resMessageDto = new ResMessageDto();
				 resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
				 slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
				 resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
				 dynamicDestinationResDto.setResMessageDto(resMessageDto);
				 return Response.ok()
	   					  .header("Cache-Control", "No-cache")
						 
						  .header("X-Content-Type-Options", "nosniff")
						  .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						  
						  .entity(dynamicDestinationResDto).build();
		  }
		 }
		  catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					 
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("validateDestination service ended");
		  }
	  }

	/* @Path("validateDestination") 
	  @POST
	  @Consumes({MediaType.APPLICATION_JSON})
	  @Produces(MediaType.APPLICATION_JSON)
	 public Response  createDestination (@Valid SAPUserDto  sapUserDetails){
		  slf4jLogger.info("validateDestination service started");
		  List<String> roleIdList = new ArrayList<>();
		  roleIdList.add(ConstantsValues.CONFIG);
		  RoleValidationDto roleValidationDto = new RoleValidationDto();
		  roleValidationDto.setRoleIdList(roleIdList);
		 try{
			 DynamicDestinationResDto dynamicDestinationResDto = new DynamicDestinationResDto(); 
			  DynamicDestinationDAO2 dynamicDestinationObj = new DynamicDestinationDAO2();
			  if(UserSessionDao.isSessionActive(sapUserDetails.getSessionInputDTO(),roleValidationDto)){
				    dynamicDestinationObj.step1Connect();
				  return Response.ok().entity("Conncted to destination sucessfully").build();
						  
			  }
		  else{
			  	 ResMessageDto resMessageDto = new ResMessageDto();
				 resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
				 slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
				 resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
				 dynamicDestinationResDto.setResMessageDto(resMessageDto);
				 return Response.ok()
	   					  .header("Cache-Control", "No-cache")
						 
						  .header("X-Content-Type-Options", "nosniff")
						  .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						  
						  .entity(dynamicDestinationResDto).build();
		  }
		 }
		  catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					 
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("validateDestination service ended");
		  }
	  }

*/	 }
