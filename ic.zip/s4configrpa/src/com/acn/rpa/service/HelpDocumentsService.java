package com.acn.rpa.service;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.chemistry.opencmis.client.api.CmisObject;
import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.chemistry.opencmis.client.api.Folder;
import org.apache.chemistry.opencmis.client.api.ItemIterable;
import org.apache.chemistry.opencmis.client.api.Session;
import org.apache.chemistry.opencmis.commons.PropertyIds;
import org.apache.chemistry.opencmis.commons.data.ContentStream;
import org.apache.chemistry.opencmis.commons.enums.VersioningState;
import org.apache.chemistry.opencmis.commons.exceptions.CmisNameConstraintViolationException;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.admin.UserDto;
import com.acn.rpa.docservice.HCPDocDAO;
import com.acn.rpa.helpDocuments.HelpDocDAO;
import com.acn.rpa.helpDocuments.HelpDocReqDTO;
import com.acn.rpa.helpDocuments.HelpDocResposneDTO;
import com.acn.rpa.utilities.ConstantsValues;

@Path("helpDocumentsSrv") 
public class HelpDocumentsService {
    private final Logger slf4jLogger = LoggerFactory.getLogger(HelpDocumentsService.class);

	  @Path("retrieveHelpDocuments")  
	  @POST
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response retrieveHelpDocuments(@Valid UserDto userDto) {
		 slf4jLogger.info("retrieveHelpDocuments service started");
		 try{
		 HelpDocDAO helpDocDAOObj = new HelpDocDAO();
			return  Response.ok()
					.header("Cache-Control", "No-cache")
				    .header("X-FRAME-OPTIONS", "Deny")
				    .header("X-Content-Type-Options", "nosniff")
				    .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				    .header("X-XSS-Protection", "1")
				    .entity(helpDocDAOObj.retrieveHelpDocuments(userDto)).build();
			
		 }catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("retrieveHelpDocuments service ended");
		  }
		}
	 
	  @Path("retriveDocumentBytes")  
	  @POST
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response retriveDocumentBytes(@Valid HelpDocReqDTO helpDocReqDTO) {
		 slf4jLogger.info("retriveDocumentBytes service started");
		 try{
		 HelpDocDAO helpDocDAOObj = new HelpDocDAO();
			return Response.ok()
					.header("Cache-Control", "No-cache")
				    .header("X-FRAME-OPTIONS", "Deny")
				    .header("X-Content-Type-Options", "nosniff")
				    .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				    .header("X-XSS-Protection", "1")
				    .entity(helpDocDAOObj.getDocumentStream(helpDocReqDTO.getId())).build();
		 }catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("retriveDocumentBytes service ended");
		  }
		}
	  
	  @Path("uploadHelpDocuments/{userRole}")  
	  @POST
	  @Consumes(MediaType.MULTIPART_FORM_DATA)
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response uploadHelpDocuments(@Context HttpServletRequest request,@PathParam("userRole") String userRole) {
		  slf4jLogger.info("uploadHelpDocuments service started");
		  	try{
		  	 FileItemFactory factory = new DiskFileItemFactory();
			 ServletFileUpload fileUpload = new ServletFileUpload(factory);
			 InputStream stream = null;
			 String fileName = null;
			 ContentStream contentStream = null;
			 Session openCmisSession = null;
			 byte[] bytes = null;
			 Map<String, String> newFolderProps = null;
			 Folder subFolder = null;
			 Folder root = null;
			 Document document = null;
			 HCPDocDAO hcpDocDAO = null;
			 Map<String, Object> properties = null;
			 ItemIterable<CmisObject> children = null;
			 InputStream docStream = null;
			 int docId = 0;
			 String extension = "";
			 HelpDocResposneDTO helpDocResposneDTO = new HelpDocResposneDTO();
			 HCPDocDAO hcpDocDAOobj = new HCPDocDAO();
			 if (ServletFileUpload.isMultipartContent(request)) {
					FileItem fileItemTemp = null;
					String fileNameWithOutExt = null;
					try {
						
						List < FileItem > fileItemsList = fileUpload.parseRequest(request);
						Iterator < FileItem > fileItemsIterator = fileItemsList.iterator();
						while (fileItemsIterator.hasNext()) {
							fileItemTemp = fileItemsIterator.next();
							
							fileName = fileItemTemp.getName();
							int i = fileName.lastIndexOf('.');
							if (i > 0) {
							    extension = fileName.substring(i+1);
							}
							stream = fileItemTemp.getInputStream();
							fileNameWithOutExt = FilenameUtils.removeExtension(fileName);
							bytes = IOUtils.toByteArray(stream);
							docStream = new ByteArrayInputStream(bytes);
						}
						if(fileName != null && !fileName.equals("") && (extension.equals("pdf") || extension.equals("mp4"))){
						docId = hcpDocDAOobj.getDocumentId(fileName.replaceAll("[^a-zA-Z0-9]", "").toLowerCase(),ConstantsValues.HELPDOCUMENTS);
						if(docId >0){
						hcpDocDAO = new HCPDocDAO();
						openCmisSession = HCPDocDAO.ConnectDocumentStore();
						root = openCmisSession.getRootFolder();

						newFolderProps = new HashMap<>();
						newFolderProps.put(PropertyIds.OBJECT_TYPE_ID, ConstantsValues.CMISFOLDER);
						newFolderProps.put(PropertyIds.NAME, ConstantsValues.HELPDOCUMENTS);
						properties = new HashMap<>();
						properties.put(PropertyIds.OBJECT_TYPE_ID, "cmis:document");
						properties.put(PropertyIds.NAME, fileNameWithOutExt);
						try{
						subFolder  = root.createFolder(newFolderProps);
						}catch (CmisNameConstraintViolationException e) {
					        // Folder exists already, nothing to do
					    	  
					    	  children = root.getChildren();
					    	  
					    	  for (CmisObject folObj : children) {
					  	        if (folObj instanceof Folder) {
					  	        	if(folObj.getName().equals(ConstantsValues.HELPDOCUMENTS))
					  	        		subFolder = (Folder) folObj;
					  	        		
					  	        
					  	        } 
					  	      }

					      }
						
						if(fileName != null && fileName.toLowerCase().contains(".pdf")){
							contentStream = openCmisSession.getObjectFactory().createContentStream(fileNameWithOutExt,bytes.length, "application/pdf", docStream);
		      	    		document = subFolder.createDocument(properties, contentStream, VersioningState.NONE);
		      	    		}

						
						else{
							contentStream = openCmisSession.getObjectFactory().createContentStream(fileNameWithOutExt,bytes.length, "video/mp4", docStream);
		      	    		document = subFolder.createDocument(properties, contentStream, VersioningState.NONE);

						}
	      	    
	      	    		//hcpDocDAO.captureDocidName(document.getId(),fileName,ConstantsValues.HELPDOCUMENTS,userRole,docStream);
	      	    		helpDocResposneDTO.setStatus(ConstantsValues.SUCCESSSTATUS);
	      	    		helpDocResposneDTO.setMessage(ConstantsValues.HELPDOCSUC);
						}
						else{
							helpDocResposneDTO.setStatus(ConstantsValues.ERRORSTATUS);
		      	    		helpDocResposneDTO.setMessage(ConstantsValues.HELPDOCERR);
		      	    		 slf4jLogger.error(ConstantsValues.HELPDOCERR);
						}
					}else{
						helpDocResposneDTO.setStatus(ConstantsValues.ERRORSTATUS);
	      	    		helpDocResposneDTO.setMessage(ConstantsValues.INVALIDHELPDOC);
					}
					}catch(Exception e){
	    	        	slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);	
	    	        }
					finally{
						if(contentStream != null){
							contentStream = null;
						}
					}

	      	    	}
			 return Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity(helpDocResposneDTO).build();
		  	}catch(Exception e){
				  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				  return Response.ok()
						  .header("Cache-Control", "No-cache")
						  .header("X-FRAME-OPTIONS", "Deny")
						  .header("X-Content-Type-Options", "nosniff")
						  .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						  .header("X-XSS-Protection", "1")
						  .header("Server","Disable")
						  
						  .entity(ConstantsValues.EXCEPTION).build();

			  }finally{		
				slf4jLogger.info("uploadHelpDocuments service ended");
			  }			
		 }
	 
	  @Path("deleteHelpDocument")  
	  @POST
	  @Produces(MediaType.APPLICATION_JSON)
	  public Response deleteHelpDocument(@Valid HelpDocReqDTO helpDocReqDTO) {
		  slf4jLogger.info("deleteHelpDocument service started");
		  try{
		  	HelpDocDAO helpDocDAOObj = new HelpDocDAO();
			return Response.ok()
					.header("Cache-Control", "No-cache")
				    .header("X-FRAME-OPTIONS", "Deny")
				    .header("X-Content-Type-Options", "nosniff")
				    .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				    .header("X-XSS-Protection", "1")
		
				    .entity(helpDocDAOObj.deleteHelpDocument(helpDocReqDTO.getId())).build();
		
	  }catch(Exception e){
		  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		  return Response.ok()
				  .header("Cache-Control", "No-cache")
				  .header("X-FRAME-OPTIONS", "Deny")
				  .header("X-Content-Type-Options", "nosniff")
				  .header("Content-Security-Policy",
					"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
				  .header("X-XSS-Protection", "1")
				  .header("Server","Disable")
				  
				  .entity(ConstantsValues.EXCEPTION).build();

	  }finally{		
		slf4jLogger.info("deleteHelpDocument service ended");
	  }

	  }
}
