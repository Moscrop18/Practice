
package com.acn.rpa.service;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.config.SelectCustomerDAO;
import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.RoleValidationDto;
import com.acn.user.session.AssignedUsersDto;
import com.acn.user.session.CustomerInputDto;
import com.acn.user.session.CustomerListDto;
import com.acn.user.session.IMGPreviewDto;
import com.acn.user.session.ResMessageDto;
import com.acn.user.session.SysInputDto;
import com.acn.user.session.UserProjectListDto;
import com.acn.user.session.UserSessionDao;


@Path("/selectCustomer")
public class SelectCustomerService {
    private final Logger slf4jLogger = LoggerFactory.getLogger(SelectCustomerService.class);

	@POST
	@Path("/selector")
	@Produces(MediaType.APPLICATION_JSON)
	public Response customerSelector(@Valid CustomerInputDto customerInputDto){
		  slf4jLogger.info("selector service started");
		  try{
			 List<String> roleIdList = new ArrayList<>();
		  	 roleIdList.add(ConstantsValues.CONFIG);
		 	  RoleValidationDto roleValidationDto = new RoleValidationDto();
		  	  roleValidationDto.setRoleIdList(roleIdList);
		  if(UserSessionDao.isSessionActive(customerInputDto.getSessionInputDTO(),roleValidationDto)){	
			  SelectCustomerDAO selectCustomerDAO = new SelectCustomerDAO();
				  return Response.ok()
							.header("Cache-Control", "No-cache")
						    .header("X-FRAME-OPTIONS", "Deny")
						    .header("X-Content-Type-Options", "nosniff")
						    .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						    .header("X-XSS-Protection", "1")
						    .entity(selectCustomerDAO.customerSelector(customerInputDto.getUserID())).build();
						    
		  }else{
			  UserProjectListDto resDto = new UserProjectListDto();
			  ResMessageDto resMessageDto = new ResMessageDto();
			  resDto.setResMessageDto(resMessageDto);
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity(resDto).build();
					  
		  }
		  }catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("selector service ended");
		  }

	}
	
	@POST
	@Path("/projectUsers")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getProjectUsers(@Valid IMGPreviewDto inputDto){
		slf4jLogger.info("projectUsers service started");
		List<String> roleIdList = new ArrayList<>();
	  	  roleIdList.add(ConstantsValues.TOOLADMIN);
	  	  roleIdList.add(ConstantsValues.PROJECTADMIN);
	  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	  roleValidationDto.setRoleIdList(roleIdList);
		  roleValidationDto.setOmId(inputDto.getSelectedOmid());
		try{
		if(UserSessionDao.isSessionActive(inputDto.getSessionInputDTO(),roleValidationDto)){	
			  SelectCustomerDAO selectCustomerDAO = new SelectCustomerDAO();
				  return  Response.ok()
							.header("Cache-Control", "No-cache")
						    .header("X-FRAME-OPTIONS", "Deny")
						    .header("X-Content-Type-Options", "nosniff")
						    .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						    .header("X-XSS-Protection", "1")
						    .entity(selectCustomerDAO.getProjectUsers(inputDto.getSelectedOmid())).build();
						  
		  }else{
			  AssignedUsersDto resDto = new AssignedUsersDto();
			  ResMessageDto resMessageDto = new ResMessageDto();
			  resDto.setResMessageDto(resMessageDto);
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return  Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity(resDto).build();
		  }
		}catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("projectUsers service ended");
		  }
	}
	
	@POST
	@Path("/userProjects")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getUserProjects(CustomerInputDto inputDto){
		slf4jLogger.info("userProjects service started");
		List<String> roleIdList = new ArrayList<>();
	  	  roleIdList.add(ConstantsValues.TOOLADMIN);
	  	  roleIdList.add(ConstantsValues.PROJECTADMIN);
	  	  RoleValidationDto roleValidationDto = new RoleValidationDto();
	  	  roleValidationDto.setRoleIdList(roleIdList);
		try{
		if(UserSessionDao.isSessionActive(inputDto.getSessionInputDTO(),roleValidationDto)){	
			  SelectCustomerDAO selectCustomerDAO = new SelectCustomerDAO();
				  return  Response.ok()
							.header("Cache-Control", "No-cache")
						    .header("X-FRAME-OPTIONS", "Deny")
						    .header("X-Content-Type-Options", "nosniff")
						    .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						    .header("X-XSS-Protection", "1")
						    .entity(selectCustomerDAO.getUserProjects(inputDto.getUserID())).build();
						  
		  }else{
			  CustomerListDto resDto = new CustomerListDto();
			  ResMessageDto resMessageDto = new ResMessageDto();
			  resDto.setResMessageDto(resMessageDto);
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return  Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity(resDto).build();
		  }
		}catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("userProjects service ended");
		  }

	}
	@POST
	@Path("/projectList")
	@Produces(MediaType.APPLICATION_JSON)
	public Response projectsList(CustomerInputDto inputDto){
		 slf4jLogger.info("Projectlist  service started");
		  try{
			 List<String> roleIdList = new ArrayList<>();
		  	 roleIdList.add(ConstantsValues.PROJECTADMIN);
		 	  RoleValidationDto roleValidationDto = new RoleValidationDto();
		  	  roleValidationDto.setRoleIdList(roleIdList);
		  if(UserSessionDao.isSessionActive(inputDto.getSessionInputDTO(),roleValidationDto)){	
			  SelectCustomerDAO selectCustomerDAO = new SelectCustomerDAO();
				  return Response.ok()
							.header("Cache-Control", "No-cache")
						    .header("X-FRAME-OPTIONS", "Deny")
						    .header("X-Content-Type-Options", "nosniff")
						    .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						    .header("X-XSS-Protection", "1")
						    .entity(selectCustomerDAO.getProjectsList(inputDto.getUserID())).build();
						    
		  }else{
			  ResMessageDto resMessageDto = new ResMessageDto();	
				 
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity(resMessageDto).build();
					  
		  }
		  }catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("Projectlist service ended");
		  }

	
	}
	////
	@POST
	@Path("/DownloadReport")
	@Produces(MediaType.APPLICATION_JSON)
	public Response downloadReportList(SysInputDto inputDto){
		 slf4jLogger.info("DwonloadReport  service started");
		  try{
			 List<String> roleIdList = new ArrayList<>();
		  	 roleIdList.add(ConstantsValues.PROJECTADMIN);
		 	  RoleValidationDto roleValidationDto = new RoleValidationDto();
		  	  roleValidationDto.setRoleIdList(roleIdList);
		  if(UserSessionDao.isSessionActive(inputDto.getSessionInputDTO(),roleValidationDto)){	
			  SelectCustomerDAO selectCustomerDAO = new SelectCustomerDAO();
				  return Response.ok()
							.header("Cache-Control", "No-cache")
						    .header("X-FRAME-OPTIONS", "Deny")
						    .header("X-Content-Type-Options", "nosniff")
						    .header("Content-Security-Policy",
							"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
						    .header("X-XSS-Protection", "1")
						    .entity(selectCustomerDAO.getDownloadReport(inputDto.getOmID())).build();
						    
		  }else{
			  ResMessageDto resMessageDto = new ResMessageDto();	
				 
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  resMessageDto.setMessage(ConstantsValues.SERVICESECURITYERROR);
			  slf4jLogger.error(ConstantsValues.SERVICESECURITYERROR);
			  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
			  return Response.ok()
						.header("Cache-Control", "No-cache")
					    .header("X-FRAME-OPTIONS", "Deny")
					    .header("X-Content-Type-Options", "nosniff")
					    .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					    .header("X-XSS-Protection", "1")
					    .entity(resMessageDto).build();
					  
		  }
		  }catch(Exception e){
			  slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			  return Response.ok()
					  .header("Cache-Control", "No-cache")
					  .header("X-FRAME-OPTIONS", "Deny")
					  .header("X-Content-Type-Options", "nosniff")
					  .header("Content-Security-Policy",
						"default-src 'self' 'unsafe-eval' 'unsafe-inline' *.accenture.com; script-src 'self' �unsafe-inline� �unsafe-eval�; img-src 'self' *.accenture.com data: connect-src 'self' *.accenture.com")
					  .header("X-XSS-Protection", "1")
					  .header("Server","Disable")
					  
					  .entity(ConstantsValues.EXCEPTION).build();

		  }finally{		
			slf4jLogger.info("DwonloadReport service ended");
		  }

	
	}
	
//
	
}
