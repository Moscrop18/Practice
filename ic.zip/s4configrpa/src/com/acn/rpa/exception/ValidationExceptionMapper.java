package com.acn.rpa.exception;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import com.acn.rpa.utilities.ConstantsValues;
import com.acn.user.session.ResMessageDto;

@Provider
public class ValidationExceptionMapper implements ExceptionMapper<javax.validation.ValidationException> {

    @Override
    public Response toResponse(javax.validation.ValidationException e) {
        final StringBuilder strBuilder = new StringBuilder();
        for (ConstraintViolation<?> cv : ((ConstraintViolationException) e).getConstraintViolations()) {
            strBuilder.append(cv.getPropertyPath().toString() + " " + cv.getMessage());
        }
    	  ResMessageDto resMessageDto = new ResMessageDto();
		  resMessageDto.setMsgType(ConstantsValues.ERRORSTATUS);
		  resMessageDto.setMessage(ConstantsValues.INPUTVALIDATIONERROR+ " "+strBuilder.toString());
        return Response
                .status(Response.Status.OK.getStatusCode())
                .type(MediaType.APPLICATION_JSON)
                .entity(resMessageDto)
                .build();
    }
}