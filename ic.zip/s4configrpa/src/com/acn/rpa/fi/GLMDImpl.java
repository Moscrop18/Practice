package com.acn.rpa.fi;

import java.io.File;
import java.io.FileOutputStream;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.config.DynamicDestinationDAO;
import com.acn.rpa.config.DynamicDestinationResDto;
import com.acn.rpa.config.JSONFormatDto;
import com.acn.rpa.config.dto.ConfigUploadHistoryDto;
import com.acn.rpa.config.dto.UploadExecutionLogDto;
import com.acn.rpa.reports.ConfigAuditDAO;
import com.acn.rpa.service.AdminService;
import com.acn.rpa.utilities.AppUtils;
import com.acn.rpa.utilities.ConstantsValues;
import com.acn.rpa.utilities.DBConnection;
import com.acn.rpa.utilities.MyDestinationDataProvider;
import com.sap.conn.jco.AbapException;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoRepository;
import com.sap.conn.jco.JCoTable;
import com.sap.conn.jco.ext.DestinationDataProvider;
import com.sap.conn.jco.ext.Environment;

/**
 * @author insimmamul.haq.p.b
 *
 */
public class GLMDImpl {
	/*static void createDestinationDataFile(String destinationName, Properties connectProperties)
	{
	    File destCfg = new File(destinationName+".jcoDestination");
	    try
	    {
	        FileOutputStream fos = new FileOutputStream(destCfg, false);
	        connectProperties.store(fos, "for tests only !");
	        fos.close();
	    }
	    catch (Exception e)
	    {
	        throw new RuntimeException("Unable to create the destination files", e);
	    }
	}*/
    private final Logger slf4jLogger = LoggerFactory.getLogger(GLMDImpl.class);

	public ArrayList<FiMDResponseDto> GLFiMasterHandler(FiMDInputDto fiMDInputDto){
		slf4jLogger.info("GLFiMasterHandler method started");
		ArrayList<FiMDResponseDto> fiMDResponseDtoList = new ArrayList<>();
		FiMDResponseDto fiMDResponseDto = null;
		MasterDataResponseDto masterDataResponseDto = new MasterDataResponseDto();
		ArrayList<JSONFormatDto> dstResultsList = null;
		String ababReqid = "", flag = "";
		int recno = 0; 
		ArrayList<ArrayList<String>> formattedDataList = fiMDInputDto.getFormattedData();
		ArrayList<String> formattedData = new ArrayList<String>();
		StringBuilder imgData = null;
		String[] result = null;
		String destinationName = fiMDInputDto.getDestinationName();
		String mdProgramPath = fiMDInputDto.getMdProgramPath();
		String customizeTR = fiMDInputDto.getCustomizingTr(); 
		ConfigUploadHistoryDto  configUploadHistoryDto = new ConfigUploadHistoryDto();
		ArrayList<UploadExecutionLogDto> uploadExecutionLogList = new ArrayList<UploadExecutionLogDto>();
		UploadExecutionLogDto uploadExecutionLogDto =  null;
		int transactionId = 0;
		 Date date = new java.util.Date();
		Timestamp executionStartTime = new java.sql.Timestamp(date.getTime());
		configUploadHistoryDto.setImgID(fiMDInputDto.getScopeName());
		configUploadHistoryDto.setTransactionID(fiMDInputDto.getTransactionID());
		configUploadHistoryDto.setProjectName(fiMDInputDto.getProjectName());
		configUploadHistoryDto.setScenario(fiMDInputDto.getScenario());
		configUploadHistoryDto.setOmgID(fiMDInputDto.getOmgID());
		configUploadHistoryDto.setSystemID(fiMDInputDto.getSystemID());
		configUploadHistoryDto.setUserID(fiMDInputDto.getUserID());
		configUploadHistoryDto.setModule(fiMDInputDto.getModule());
		configUploadHistoryDto.setExecutionStartTime(executionStartTime);
		try{
			fiMDResponseDto = new FiMDResponseDto();
			dstResultsList = new ArrayList<JSONFormatDto>();

			for(int i=0,arrSize = formattedDataList.size(); i<  arrSize; i++){
				if(formattedDataList.size() > 0){
				recno = recno + formattedDataList.get(i).size();
				if(i == formattedDataList.size()-1){
					flag = "";
				}else{
					flag = "X";
				}
				
				formattedData.clear();
				imgData = new StringBuilder();
	
					imgData.append(fiMDInputDto.getScopeName());
				

				imgData.append("|");
				imgData.append(ababReqid);
				imgData.append("|");
				imgData.append(recno);
				imgData.append("|");	
				imgData.append(flag);
				if(fiMDInputDto.getScopeName().equals("IMG_DUMMY_FIN3")){
					imgData.append("|");	
					imgData.append(customizeTR);
				}
				
				if(fiMDInputDto.getScopeName().equals("FI_GL_MD_FS00"))
					formattedData.add("GL");
				else if(fiMDInputDto.getScopeName().equals("IMG_DUMMY_FIN1"))
					formattedData.add("CC");
				else if(fiMDInputDto.getScopeName().equals("SIMG_CFMENUORK1KE51"))
					formattedData.add("PC");
				else if(fiMDInputDto.getScopeName().equals("IMG_DUMMY_FIN3"))
					formattedData.add("HB");


				formattedData.add(imgData.toString());
				formattedData.addAll(formattedDataList.get(i));
			
			masterDataResponseDto = executeTargetSysConfig(formattedData,destinationName,mdProgramPath, fiMDInputDto.getSapUserId(),fiMDInputDto.getSapPassword(),fiMDInputDto.getSapLanguage(),
					fiMDInputDto.getIsCustomDestinationRequired(),fiMDInputDto.getSncEnabled(), fiMDInputDto.getSncName(),fiMDInputDto.getSncPartnerName(),
					fiMDInputDto.getSncProtectionLevel(), fiMDInputDto.getSapRouter(),fiMDInputDto.getHostName(), fiMDInputDto.getSystemNo(), fiMDInputDto.getSapClientNo());
			
			if(!fiMDInputDto.getScopeName().equals("IMG_DUMMY_FIN3") && masterDataResponseDto.getResponseData() != null && masterDataResponseDto.getResponseData().size() == 2){
				 if(masterDataResponseDto.getResponseData().get(1).split("\\|").length > 2)
					ababReqid = masterDataResponseDto.getResponseData().get(1).split("\\|")[1];
				
			}else if(fiMDInputDto.getScopeName().equals("IMG_DUMMY_FIN3") && masterDataResponseDto.getResponseData() != null && masterDataResponseDto.getResponseData().size() >= 2){
				if(masterDataResponseDto.getResponseData().get(1).split("\\|").length >= 4){
					ababReqid = masterDataResponseDto.getResponseData().get(1).split("\\|")[1];
					customizeTR = masterDataResponseDto.getResponseData().get(1).split("\\|")[3];					
				}else{
					break;
				}
			}
			
				}
			}

			fiMDResponseDto.setConnectionStatus(masterDataResponseDto.isConnectionStatus());
			fiMDResponseDto.setExecutionStatus(masterDataResponseDto.isExecutionStatus());
			fiMDResponseDto.setResponseList(masterDataResponseDto.getResponseData());

			if(masterDataResponseDto.isConnectionStatus() && masterDataResponseDto.isExecutionStatus()){
				/*for(int k = 0,resDataLen = masterDataResponseDto.getResponseData().size(); k < resDataLen; k++){
					JSONFormatDto jSONFormatDto = new JSONFormatDto();
					result = masterDataResponseDto.getResponseData().get(k).split("~");
					if(k==0){
						fiMDResponseDto.setStatus(result[1].trim());
					}
					else if(masterDataResponseDto.getResponseData().get(k).startsWith(fiMDInputDto.getScopeName()) && k == 1){
						continue;
					}
					else if(k > 1){
						jSONFormatDto.setDescription(result[1]);
						jSONFormatDto.setErrorType(result[0]);
						jSONFormatDto.setMessageType(result[0]);
						jSONFormatDto.setScopeName(fiMDInputDto.getScopeName());

						dstResultsList.add(jSONFormatDto);
						
					}
				}*/
				for (int i = 0,resSize = masterDataResponseDto.getResponseData().size(); i < resSize; i++) {
					if (masterDataResponseDto.getResponseData().get(i) != null && !masterDataResponseDto.getResponseData().get(i).equals("")) {
						result = masterDataResponseDto.getResponseData().get(i).split("~");
						String resultDescription  = null, messageType = null;
						if(i==0 && result.length > 1){
							fiMDResponseDto.setStatus(result[1].replaceAll("\\s+",""));
						}
						else if(i==1 && masterDataResponseDto.getResponseData().get(i).startsWith(fiMDInputDto.getScopeName())){
							continue;
						}
						else{
						messageType = result[0].trim();
						
					    if( result.length > 1) 
					    	resultDescription = result[1].trim(); 
					    JSONFormatDto jSONFormatDto = new JSONFormatDto();
						jSONFormatDto.setScopeName(fiMDInputDto.getScopeName());
						jSONFormatDto.setDescription(resultDescription);
						jSONFormatDto.setErrorType(messageType);
						jSONFormatDto.setMessageType(messageType);
						dstResultsList.add(jSONFormatDto); 
						
						}
					}
			}
			
			}
			
				else{
				JSONFormatDto jSONFormatDto = new JSONFormatDto();
				jSONFormatDto.setDescription(masterDataResponseDto.getResponseData().get(1));
				jSONFormatDto.setErrorType("E");
				jSONFormatDto.setMessageType("E");
				jSONFormatDto.setScopeName(fiMDInputDto.getScopeName());

				fiMDResponseDto.setStatus(ConstantsValues.ERRORSTATUS);
				dstResultsList.add(jSONFormatDto);
			}
			
			fiMDResponseDto.setResult(dstResultsList);
			fiMDResponseDtoList.add(fiMDResponseDto);
			
			
		}catch(Exception E){
			
			JSONFormatDto jSONFormatDto = new JSONFormatDto();
			dstResultsList = new ArrayList<JSONFormatDto>();
			jSONFormatDto.setDescription(masterDataResponseDto.getResponseData().get(0));
			jSONFormatDto.setErrorType("E");
			jSONFormatDto.setMessageType("E");
			jSONFormatDto.setScopeName(fiMDInputDto.getScopeName());
	
			fiMDResponseDto.setStatus(ConstantsValues.ERRORSTATUS);
			dstResultsList.add(jSONFormatDto);
			fiMDResponseDto.setResult(dstResultsList);
			fiMDResponseDtoList.add(fiMDResponseDto);
			fiMDResponseDto.setMessage("Exception occured, invalid ourput from ABAP");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,E);

		}
		

		if(fiMDResponseDto != null && fiMDResponseDto.getStatus().equalsIgnoreCase("Success"))
			configUploadHistoryDto.setStatus("S");
		else
			configUploadHistoryDto.setStatus("E");
		//if(fiMDInputDto.isIMGHierarchy()){
		try{
			if(fiMDResponseDto != null){
				int seqNo = 1;
				ConfigAuditDAO configAuditDao =  new ConfigAuditDAO();
				configUploadHistoryDto.setCustomizingTr(customizeTR);
				transactionId = configAuditDao.createConfigUploadHistory(configUploadHistoryDto);
				if(transactionId > 0){
					
						List<JSONFormatDto> reterieveExeList = fiMDResponseDto.getResult();
						for(int j = 0,arSize = reterieveExeList.size(); j< arSize ;j++){
							JSONFormatDto dto1 = reterieveExeList.get(j);
							uploadExecutionLogDto = new UploadExecutionLogDto();
							uploadExecutionLogDto.setConfigUploadID(transactionId);
							uploadExecutionLogDto.setImgID(fiMDInputDto.getScopeName());
							uploadExecutionLogDto.setMessage(dto1.getDescription());
							uploadExecutionLogDto.setStatus(dto1.getMessageType());
							uploadExecutionLogDto.setUserID(fiMDInputDto.getUserID());
							uploadExecutionLogDto.setSequenceID(seqNo);
							uploadExecutionLogList.add(uploadExecutionLogDto);
							seqNo++;
						}
					configAuditDao.createUploadExecutionLog(uploadExecutionLogList);
			}
				
			}
		}catch(Exception e){
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}finally{
			slf4jLogger.info("GLFiMasterHandler method ended");

		}
		//}
		return fiMDResponseDtoList;
	}
	
	
	
	public MasterDataResponseDto executeTargetSysConfig(ArrayList<String> formattedMasterData, String destinationName, String prgmPathMasterData , 
			String sapUserId, String sapPassword,String language, String customDesRequired,int sncEnabled,
			String sncName, String sncPartnerName, String sncProtectionLevel,String sapRouter, String hostName, String systemNo, String clientNo) {
		slf4jLogger.info("executeTargetSysConfig method started");
		ArrayList<String> resultText = new ArrayList<>();
		MasterDataResponseDto masterDataResponseDto = new MasterDataResponseDto();
		JCoRepository repo = null;
		DynamicDestinationDAO dynamicDestinationDaoObj= new DynamicDestinationDAO();
		DynamicDestinationResDto dynamicDestinationResDto = new DynamicDestinationResDto();
		AppUtils appUtilsObj = null;
		JCoFunction stfcConnection = null;
		/*String DESTINATION_NAME1 = "K4ASystem";
		String DESTINATION_NAME2 = "K4XS4System";*/
		try {
			appUtilsObj = new AppUtils();
			

			Properties connectProperties = new Properties();
			MyDestinationDataProvider myDestinationDataProvider=MyDestinationDataProvider.getInstance();
			connectProperties.setProperty(DestinationDataProvider.JCO_DEST,destinationName);
			connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, hostName);
			connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR, systemNo);
			connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, clientNo);
			
			if(customDesRequired.equals("false")){
			connectProperties.setProperty(DestinationDataProvider.JCO_USER, sapUserId);
			connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD,sapPassword);
			connectProperties.setProperty(DestinationDataProvider.JCO_LANG,language);
			}else{
				//slf4jLogger.info("glmdimpl usernaem"+sapUserId);
				//slf4jLogger.info("glmdimpl sapPassword"+sapPassword);
				connectProperties.setProperty(DestinationDataProvider.JCO_USER, sapUserId);
				connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD,sapPassword);
				connectProperties.setProperty(DestinationDataProvider.JCO_LANG,language);
			}
			if(sapRouter!=null) {
				connectProperties.setProperty(DestinationDataProvider.JCO_SAPROUTER, sapRouter);
			}
			
			
			if(sncEnabled==1){
				connectProperties.setProperty(DestinationDataProvider.JCO_SNC_MODE, String.valueOf(sncEnabled));
				
				connectProperties.setProperty(DestinationDataProvider.JCO_SNC_MYNAME, sncName);
				connectProperties.setProperty(DestinationDataProvider.JCO_SNC_PARTNERNAME, sncPartnerName);
				
				connectProperties.setProperty(DestinationDataProvider.JCO_SNC_QOP, sncProtectionLevel);
				connectProperties.setProperty(DestinationDataProvider.JCO_SNC_LIBRARY, System.getenv("SNC_LIB"));
			}
			
			//createDestinationDataFile(ConstantsValues.DESTINATION_NAMEK4A, connectProperties);
			myDestinationDataProvider.changePropertiesForABAP_AS(connectProperties);
			System.err.println("data provider"+Environment.isDestinationDataProviderRegistered());
			  if(Environment.isDestinationDataProviderRegistered()){
					System.err.println("inside if");
					Environment.unregisterDestinationDataProvider(myDestinationDataProvider);
					
				}
			  Environment.registerDestinationDataProvider(myDestinationDataProvider);
			connectProperties.setProperty(DestinationDataProvider.JCO_POOL_CAPACITY, "3");
			connectProperties.setProperty(DestinationDataProvider.JCO_PEAK_LIMIT, "10");
			/*try {*/

			JCoDestination	 destination = JCoDestinationManager.getDestination(destinationName);
				System.out.println("Attributes:");
				System.out.println(destination.getAttributes());
				System.out.println();

				// JCoDestination destination =
				// JCoDestinationManager.getDestination(DESTINATION_NAME2);
				destination.ping();
				masterDataResponseDto.setConnectionStatus(true);
				 // slf4jLogger.info("connectionstatus gdimpl"+masterDataResponseDto.isConnectionStatus());
				System.out.println("Attributes:");
				System.out.println(destination.getAttributes());
				System.out.println();

				// JCoDestination destination1 =
				// JCoDestinationManager.getDestination(DESTINATION_NAME2);
				stfcConnection = destination.getRepository().getFunction("/ACNIP/RFC");
				if (stfcConnection == null) {
					
					throw new RuntimeException("/ACNIP/RFC not found in SAP.");
				}


				 // slf4jLogger.info("connectionstatus in gdmpl"+masterDataResponseDto.isConnectionStatus());
			JCoParameterList tabInput = stfcConnection.getTableParameterList();
			//slf4jLogger.info("tabInput" + tabInput);
			JCoTable paramTable = tabInput.getTable(ConstantsValues.IPARAM);
			for(String val : formattedMasterData){
					paramTable.appendRow();
					paramTable.setValue(ConstantsValues.WA, val);
			}
			paramTable = appUtilsObj.getABAPPrg(prgmPathMasterData,tabInput);
			
			/*if(customDesRequired.equals("true")){
				
				stfcConnection.execute(dynamicDestinationResDto.getCustomDestination());
			}
			else{
				stfcConnection.execute(destination);
			}*/
			stfcConnection.execute(destination);
				masterDataResponseDto.setExecutionStatus(true);
				JCoTable resultTable = tabInput.getTable(ConstantsValues.O_RESULT);
				for (int i = 0,resTabLen = resultTable.getNumRows(); i < resTabLen; i++) {
					resultTable.setRow(i);
					resultText.add(resultTable.getString(ConstantsValues.WA));
				}		
		} catch (AbapException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			resultText.add("Execution of RFC Failed: " + e);
			masterDataResponseDto.setConnectionStatus(true);
		} catch (JCoException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			resultText.add("JCO Connection Failed: " + e);
			masterDataResponseDto.setConnectionStatus(false);
		} catch (Exception e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			resultText.add("Configuration Failed: " + e);
			masterDataResponseDto.setExecutionStatus(false);
		}finally{
			  slf4jLogger.info("executeTargetSysConfig method ended");

		}
		masterDataResponseDto.setResponseData(resultText);
		return masterDataResponseDto;
	}
	
	public MasterDataResponseDto executeTargetSysConsolidation(ArrayList<String> formattedMasterData,FiMDInputDto fiMDInputDto, String destinationName, 
			String prgmPathMasterData , String sapUserId, String sapPassword,String language, String customDesRequired, int sncEnabled,
			String sncName, String sncPartnerName, String sncProtectionLevel,String sapRouter) {
		slf4jLogger.info("executeTargetSysConsolidation method started");
		ArrayList<String> resultText = new ArrayList<>();
		MasterDataResponseDto masterDataResponseDto = new MasterDataResponseDto();
		JCoRepository repo = null;
		DynamicDestinationDAO dynamicDestinationDaoObj= new DynamicDestinationDAO();
		DynamicDestinationResDto dynamicDestinationResDto = new DynamicDestinationResDto();
		AppUtils appUtilsObj = null;
		JCoFunction stfcConnection = null;
		/*String DESTINATION_NAME1 = "K4ASystem";
		String DESTINATION_NAME2 = "K4XS4System";*/
		try {
			appUtilsObj = new AppUtils();
			

			Properties connectProperties = new Properties();
			MyDestinationDataProvider myDestinationDataProvider=MyDestinationDataProvider.getInstance();
			
			
		/*	connectProperties.setProperty(DestinationDataProvider.JCO_DEST,ConstantsValues.DESTINATION_NAMEK4A);
			connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, ConstantsValues.TRGHOST_NAME);
			connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR, ConstantsValues.TRG_SYSNR);
			connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, ConstantsValues.TRG_CLIENT);
			*/
			
			connectProperties.setProperty(DestinationDataProvider.JCO_DEST,fiMDInputDto.getDestinationName());
			connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, fiMDInputDto.getHostName());
			connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR, fiMDInputDto.getSystemNo());
			connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, fiMDInputDto.getSapClientNo());
		
			if(customDesRequired.equals("false")){
			
			
			connectProperties.setProperty(DestinationDataProvider.JCO_USER, fiMDInputDto.getSapUserId());
			connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD,fiMDInputDto.getSapPassword());
			connectProperties.setProperty(DestinationDataProvider.JCO_LANG,fiMDInputDto.getSapLanguage());
			}else{
				//slf4jLogger.info("glmdimpl usernaem"+sapUserId);
				//slf4jLogger.info("glmdimpl sapPassword"+sapPassword);
				connectProperties.setProperty(DestinationDataProvider.JCO_USER, fiMDInputDto.getSapUserId());
				connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD,fiMDInputDto.getSapPassword());
				connectProperties.setProperty(DestinationDataProvider.JCO_LANG,fiMDInputDto.getSapLanguage());
			}
			
			if(sapRouter!=null) {
				connectProperties.setProperty(DestinationDataProvider.JCO_SAPROUTER, sapRouter);
			}
			
			
			if(sncEnabled==1){
				connectProperties.setProperty(DestinationDataProvider.JCO_SNC_MODE, String.valueOf(sncEnabled));
				
				connectProperties.setProperty(DestinationDataProvider.JCO_SNC_MYNAME, sncName);
				connectProperties.setProperty(DestinationDataProvider.JCO_SNC_PARTNERNAME, sncPartnerName);
				
				connectProperties.setProperty(DestinationDataProvider.JCO_SNC_QOP, sncProtectionLevel);
				connectProperties.setProperty(DestinationDataProvider.JCO_SNC_LIBRARY, System.getenv("SNC_LIB"));
			}
			
			//createDestinationDataFile(ConstantsValues.DESTINATION_NAMEK4A, connectProperties);
			myDestinationDataProvider.changePropertiesForABAP_AS(connectProperties);
			System.err.println("data provider"+Environment.isDestinationDataProviderRegistered());
			  if(Environment.isDestinationDataProviderRegistered()){
					System.err.println("inside if");
					Environment.unregisterDestinationDataProvider(myDestinationDataProvider);
					
				}
			  Environment.registerDestinationDataProvider(myDestinationDataProvider);
			connectProperties.setProperty(DestinationDataProvider.JCO_POOL_CAPACITY, "3");
			connectProperties.setProperty(DestinationDataProvider.JCO_PEAK_LIMIT, "10");
			/*try {*/

			JCoDestination	 destination = JCoDestinationManager.getDestination(fiMDInputDto.getDestinationName());
				System.out.println("Attributes:");
				System.out.println(destination.getAttributes());
				System.out.println();

				// JCoDestination destination =
				// JCoDestinationManager.getDestination(DESTINATION_NAME2);
				destination.ping();
				masterDataResponseDto.setConnectionStatus(true);
				 // slf4jLogger.info("connectionstatus gdimpl"+masterDataResponseDto.isConnectionStatus());
				System.out.println("Attributes:");
				System.out.println(destination.getAttributes());
				System.out.println();

				// JCoDestination destination1 =
				// JCoDestinationManager.getDestination(DESTINATION_NAME2);
				stfcConnection = destination.getRepository().getFunction("/ACNIP/RFC");
				if (stfcConnection == null) {
					
					throw new RuntimeException("/ACNIP/RFC not found in SAP.");
				}


				 // slf4jLogger.info("connectionstatus in gdmpl"+masterDataResponseDto.isConnectionStatus());
			JCoParameterList tabInput = stfcConnection.getTableParameterList();
			//slf4jLogger.info("tabInput" + tabInput);
			JCoTable paramTable = tabInput.getTable(ConstantsValues.IPARAM);
			for(String val : formattedMasterData){
					paramTable.appendRow();
					paramTable.setValue(ConstantsValues.WA, val);
			}
			paramTable = appUtilsObj.getABAPPrg(prgmPathMasterData,tabInput);
			
			/*if(customDesRequired.equals("true")){
				
				stfcConnection.execute(dynamicDestinationResDto.getCustomDestination());
			}
			else{
				stfcConnection.execute(destination);
			}*/
			stfcConnection.execute(destination);
				masterDataResponseDto.setExecutionStatus(true);
				JCoTable resultTable = tabInput.getTable(ConstantsValues.O_RESULT);
				for (int i = 0,resTabLen = resultTable.getNumRows(); i < resTabLen; i++) {
					resultTable.setRow(i);
					resultText.add(resultTable.getString(ConstantsValues.WA));
				}		
		} catch (AbapException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			resultText.add("Execution of RFC Failed: " + e);
			masterDataResponseDto.setConnectionStatus(true);
		} catch (JCoException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			resultText.add("JCO Connection Failed: " + e);
			masterDataResponseDto.setConnectionStatus(false);
		} catch (Exception e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			resultText.add("Configuration Failed: " + e);
			masterDataResponseDto.setExecutionStatus(false);
		}finally{
			  slf4jLogger.info("executeTargetSysConsolidation method ended");

		}
		masterDataResponseDto.setResponseData(resultText);
		return masterDataResponseDto;
	}
	public ArrayList<FiMDResponseDto> GLFiMasterHandlerForConsolidation(FiMDInputDto fiMDInputDto){
		slf4jLogger.info("GLFiMasterHandlerForConsolidation method started");
		ArrayList<FiMDResponseDto> fiMDResponseDtoList = new ArrayList<>();
		FiMDResponseDto fiMDResponseDto = null;
		MasterDataResponseDto masterDataResponseDto = new MasterDataResponseDto();
		ArrayList<JSONFormatDto> dstResultsList = null;
		String ababReqid = "", flag = "";
		int recno = 0; 
		ArrayList<ArrayList<String>> formattedDataList = fiMDInputDto.getFormattedData();
		ArrayList<String> formattedData = new ArrayList<String>();
		StringBuilder imgData = null;
		String[] result = null;
		
		 String img=fiMDInputDto.getScopeName().split("-")[0];
	     String view=fiMDInputDto.getScopeName().split("-")[1];
	     int seqno=0;
	     Boolean seqFlag=false;
	     
	     Date date = new java.util.Date();
		 Timestamp executionStartTime = new java.sql.Timestamp(date.getTime());
	     
	     Connection conn = null;
			ResultSet rset1 = null;
			ResultSet rset2 = null;
			PreparedStatement ps1 = null;
			PreparedStatement ps2 = null;
			try {
				conn = DBConnection.createConnection();
				ps1= conn.prepareStatement("SELECT SEQNO FROM IMGOBJECTS WHERE IMGID=? AND OBJECTNAME=? AND C_FIELD=1");
				ps1.setString(1,img);
				ps1.setString(2,view);
				rset1 = ps1.executeQuery();
				if(rset1.next()) {
					seqno=rset1.getInt("SEQNO");
				}	
				if(seqno>1)
				{
					ps2= conn.prepareStatement("SELECT * FROM CONSOLIDATION_EXECUTION WHERE IMGID=? AND SEQNO<?");
					ps2.setString(1,img);
					ps2.setInt(2,seqno);
					rset2 = ps2.executeQuery();
					if(rset2.next()) {
						seqFlag=true;
					}	
				}
				else
					seqFlag=true;
			}catch (SQLException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			} finally {
				if (rset1 != null) {
					try {
						rset1.close();
						rset1 = null;
					} catch (SQLException e) {
						slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
					}
				}
				if (rset2 != null) {
					try {
						rset2.close();
						rset2 = null;
					} catch (SQLException e) {
						slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
					}
				}
				if (ps1 != null) {
					try {
						ps1.close();
						ps1 = null;
					} catch (SQLException e) {
						slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
					}
				}
				if (ps2 != null) {
					try {
						ps2.close();
						ps2 = null;
					} catch (SQLException e) {
						slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
					}
				}
				if (conn != null) {
					try {
						conn.close();
						conn = null;
					} catch (SQLException e) {
						slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
					}
				}

		 }
	     
		String destinationName = fiMDInputDto.getDestinationName();
		String mdProgramPath = fiMDInputDto.getMdProgramPath();
		String customizeTR = fiMDInputDto.getCustomizingTr(); 
		ConfigUploadHistoryDto  configUploadHistoryDto = new ConfigUploadHistoryDto();
		ArrayList<UploadExecutionLogDto> uploadExecutionLogList = new ArrayList<UploadExecutionLogDto>();
		UploadExecutionLogDto uploadExecutionLogDto =  null;
		int transactionId = 0;
		configUploadHistoryDto.setImgID(fiMDInputDto.getScopeName());
		configUploadHistoryDto.setTransactionID(fiMDInputDto.getTransactionID());
		configUploadHistoryDto.setProjectName(fiMDInputDto.getProjectName());
		configUploadHistoryDto.setScenario(fiMDInputDto.getScenario());
		configUploadHistoryDto.setOmgID(fiMDInputDto.getOmgID());
		configUploadHistoryDto.setSystemID(fiMDInputDto.getSystemID());
		configUploadHistoryDto.setUserID(fiMDInputDto.getUserID());
		configUploadHistoryDto.setModule(fiMDInputDto.getModule());
		configUploadHistoryDto.setExecutionStartTime(executionStartTime);
		
			fiMDResponseDto = new FiMDResponseDto();
			dstResultsList = new ArrayList<JSONFormatDto>();
			
			if(seqFlag) {
				try{
				for(int i=0,arrSize = formattedDataList.size(); i<  arrSize; i++){
					if(formattedDataList.size() > 0){
					recno = recno + formattedDataList.get(i).size();
					if(i == formattedDataList.size()-1){
						flag = "";
					}else{
						flag = "X";
					}
					
					formattedData.clear();
					imgData = new StringBuilder();
		
						imgData.append(fiMDInputDto.getScopeName().split("-")[0]);
					
	
					imgData.append("|");
					imgData.append(ababReqid);
					imgData.append("|");
					imgData.append(recno);
					imgData.append("|");	
					imgData.append(flag);
					
					if(fiMDInputDto.getScopeName().equals("IMG_DUMMY_FIN3")){
						imgData.append("|");	
						imgData.append(customizeTR);
					}
					
					if(fiMDInputDto.getScopeName().equals("FI_GL_MD_FS00"))
						formattedData.add("GL");
					else if(fiMDInputDto.getScopeName().equals("IMG_DUMMY_FIN1"))
						formattedData.add("CC");
					else if(fiMDInputDto.getScopeName().equals("SIMG_CFMENUORK1KE51"))
						formattedData.add("PC");
					else if(fiMDInputDto.getScopeName().equals("IMG_DUMMY_FIN3"))
						formattedData.add("HB");
					
	
					formattedData.add(imgData.toString());
					formattedData.addAll(formattedDataList.get(i));
				
				masterDataResponseDto = executeTargetSysConsolidation(formattedData, fiMDInputDto, destinationName,mdProgramPath, fiMDInputDto.getSapUserId(),
						fiMDInputDto.getSapPassword(),fiMDInputDto.getSapLanguage(),fiMDInputDto.getIsCustomDestinationRequired(),fiMDInputDto.getSncEnabled(),
						fiMDInputDto.getSncName(), fiMDInputDto.getSncPartnerName(), fiMDInputDto.getSncProtectionLevel(), fiMDInputDto.getSapRouter());
				
				if(masterDataResponseDto.getResponseData() != null && masterDataResponseDto.getResponseData().size() == 2){
					 if(masterDataResponseDto.getResponseData().get(1).split("\\|").length > 2)
						ababReqid = masterDataResponseDto.getResponseData().get(1).split("\\|")[1];
					
				}
				
					}
				}
	
				fiMDResponseDto.setConnectionStatus(masterDataResponseDto.isConnectionStatus());
				fiMDResponseDto.setExecutionStatus(masterDataResponseDto.isExecutionStatus());
				fiMDResponseDto.setResponseList(masterDataResponseDto.getResponseData());
	
				if(masterDataResponseDto.isConnectionStatus() && masterDataResponseDto.isExecutionStatus()){
					for(int k = 0,resDataLen = masterDataResponseDto.getResponseData().size(); k < resDataLen; k++){
						JSONFormatDto jSONFormatDto = new JSONFormatDto();
						result = masterDataResponseDto.getResponseData().get(k).split("~");
						if(k==0){
							fiMDResponseDto.setStatus(result[1].trim());
						}
						else if(masterDataResponseDto.getResponseData().get(k).startsWith(fiMDInputDto.getScopeName().split("-")[0]) && k == 1){
							continue;
						}
						else if(k > 1){
							jSONFormatDto.setDescription(result[1]);
							jSONFormatDto.setErrorType(result[0]);
							jSONFormatDto.setMessageType(result[0]);
							jSONFormatDto.setScopeName(fiMDInputDto.getScopeName().split("-")[0]);
	
							dstResultsList.add(jSONFormatDto);
							
						}
					}
					
					if(fiMDResponseDto.getStatus().equalsIgnoreCase("Success")) {
						Connection con = null;
						ResultSet rs = null;
						PreparedStatement pStmt = null;
						try {
							String consolidationQry = "Insert into CONSOLIDATION_EXECUTION(IMGID, OBJECTNAME, SEQNO) values(?,?,?)";
	
							con = DBConnection.createConnection();
							pStmt = con.prepareStatement(consolidationQry);
							pStmt.setString(1, img);
							pStmt.setString(2, view);
							pStmt.setInt(3, seqno);
							pStmt.execute();
	
						} catch (SQLException e) {
							slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
						} finally {
							if (rs != null) {
								try {
									rs.close();
									rs = null;
								} catch (SQLException e) {
									slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
								}
							}
							if (pStmt != null) {
								try {
									pStmt.close();
									pStmt = null;
								} catch (SQLException e) {
									slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
								}
							}
							if (con != null) {
								try {
									con.close();
									con = null;
								} catch (SQLException e) {
									slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS, e);
								}
							}
	
						}
					}
				}
				else{
					JSONFormatDto jSONFormatDto = new JSONFormatDto();
					jSONFormatDto.setDescription(masterDataResponseDto.getResponseData().get(1));
					jSONFormatDto.setErrorType("E");
					jSONFormatDto.setMessageType("E");
					jSONFormatDto.setScopeName(fiMDInputDto.getScopeName().split("-")[0]);
	
					fiMDResponseDto.setStatus(ConstantsValues.ERRORSTATUS);
					dstResultsList.add(jSONFormatDto);
				}
				
				fiMDResponseDto.setResult(dstResultsList);
				fiMDResponseDtoList.add(fiMDResponseDto);
				
				
			}catch(Exception E){
				
				JSONFormatDto jSONFormatDto = new JSONFormatDto();
				dstResultsList = new ArrayList<JSONFormatDto>();
				jSONFormatDto.setDescription(masterDataResponseDto.getResponseData().get(0));
				jSONFormatDto.setErrorType("E");
				jSONFormatDto.setMessageType("E");
				jSONFormatDto.setScopeName(fiMDInputDto.getScopeName().split("-")[0]);
		
				fiMDResponseDto.setStatus(ConstantsValues.ERRORSTATUS);
				dstResultsList.add(jSONFormatDto);
				fiMDResponseDto.setResult(dstResultsList);
				fiMDResponseDtoList.add(fiMDResponseDto);
				fiMDResponseDto.setMessage("Exception occured, invalid ourput from ABAP");
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,E);
	
				}
			}
			else {
				JSONFormatDto jSONFormatDto = new JSONFormatDto();
				dstResultsList = new ArrayList<JSONFormatDto>();
				jSONFormatDto.setDescription("Dependency Table(s) is/are not successfully uploaded");
				jSONFormatDto.setErrorType("E");
				jSONFormatDto.setMessageType("E");
				jSONFormatDto.setScopeName(fiMDInputDto.getScopeName().split("-")[0]);
		
				fiMDResponseDto.setStatus(ConstantsValues.ERRORSTATUS);
				dstResultsList.add(jSONFormatDto);
				fiMDResponseDto.setResult(dstResultsList);
				fiMDResponseDtoList.add(fiMDResponseDto);
				fiMDResponseDto.setMessage("Dependency Table(s) is/are not successfully uploaded");
				
			}
		if(fiMDResponseDto != null && fiMDResponseDto.getStatus().equalsIgnoreCase("Success"))
			configUploadHistoryDto.setStatus("S");
		else
			configUploadHistoryDto.setStatus("E");
		//if(fiMDInputDto.isIMGHierarchy()){
		try{
			if(fiMDResponseDto != null){
				int seqNo = 1;
				ConfigAuditDAO configAuditDao =  new ConfigAuditDAO();
				configUploadHistoryDto.setCustomizingTr(customizeTR);
				transactionId = configAuditDao.createConfigUploadHistory(configUploadHistoryDto);
				if(transactionId > 0){
					
						List<JSONFormatDto> reterieveExeList = fiMDResponseDto.getResult();
						for(int j = 0,arSize = reterieveExeList.size(); j< arSize ;j++){
							JSONFormatDto dto1 = reterieveExeList.get(j);
							uploadExecutionLogDto = new UploadExecutionLogDto();
							uploadExecutionLogDto.setConfigUploadID(transactionId);
							uploadExecutionLogDto.setImgID(fiMDInputDto.getScopeName());
							uploadExecutionLogDto.setMessage(dto1.getDescription());
							uploadExecutionLogDto.setStatus(dto1.getMessageType());
							uploadExecutionLogDto.setUserID(fiMDInputDto.getUserID());
							uploadExecutionLogDto.setSequenceID(seqNo);
							uploadExecutionLogList.add(uploadExecutionLogDto);
							seqNo++;
						}
					configAuditDao.createUploadExecutionLog(uploadExecutionLogList);
			}
				
			}
		}catch(Exception e){
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}finally{
			slf4jLogger.info("GLFiMasterHandlerForConsolidation method ended");

		}
		//}
		return fiMDResponseDtoList;
	}
	
}
