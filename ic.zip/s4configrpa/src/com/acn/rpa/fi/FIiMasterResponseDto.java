package com.acn.rpa.fi;

import java.util.ArrayList;

import com.acn.user.session.ResMessageDto;

public class FIiMasterResponseDto {
	
	ArrayList<ArrayList<String>> masterDataRes;
	ArrayList<FiMDResponseDto> listFiMDResponse;
	private ResMessageDto resMessageDto;

	public ResMessageDto getResMessageDto() {
			return resMessageDto;
		}
	public void setResMessageDto(ResMessageDto resMessageDto) {
			this.resMessageDto = resMessageDto;
		}
	public ArrayList<ArrayList<String>> getMasterDataRes() {
		return masterDataRes;
	}

	public void setMasterDataRes(ArrayList<ArrayList<String>> masterDataRes) {
		this.masterDataRes = masterDataRes;
	}

	public ArrayList<FiMDResponseDto> getListFiMDResponse() {
		return listFiMDResponse;
	}

	public void setListFiMDResponse(ArrayList<FiMDResponseDto> listFiMDResponse) {
		this.listFiMDResponse = listFiMDResponse;
	}

}
