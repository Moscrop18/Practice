/*package com.acn.rpa.fi;


import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.config.DynamicDestinationDAO;
import com.acn.rpa.config.DynamicDestinationResDto;
import com.acn.rpa.config.JSONFormatDto;
import com.acn.rpa.config.dto.ConfigUploadHistoryDto;
import com.acn.rpa.config.dto.UploadExecutionLogDto;
import com.acn.rpa.reports.ConfigAuditDAO;
import com.acn.rpa.utilities.AppUtils;
import com.acn.rpa.utilities.ConstantsValues;
import com.sap.conn.jco.AbapException;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoParameterList;
import com.sap.conn.jco.JCoRepository;
import com.sap.conn.jco.JCoTable;



public class CostCenterMDImpl {

    private final Logger slf4jLogger = LoggerFactory.getLogger(CostCenterMDImpl.class);

	public ArrayList<FiMDResponseDto> CCFiMasterHandler(FiMDInputDto fiMDInputDto){
		slf4jLogger.info("CCFiMasterHandler method started");
		ArrayList<FiMDResponseDto> fiMDResponseDtoList = new ArrayList<>();
		FiMDResponseDto fiMDResponseDto = null;
		MasterDataResponseDto masterDataResponseDto = new MasterDataResponseDto();
		ArrayList<ArrayList<String>> formattedDataList = fiMDInputDto.getFormattedData();
		String[] result = null;
		ArrayList<JSONFormatDto> dstResultsList = null;
		int length = 0;
		String destinationName = fiMDInputDto.getDestinationName();
		String mdProgramPath = fiMDInputDto.getMdProgramPath();
		ConfigUploadHistoryDto  configUploadHistoryDto = new ConfigUploadHistoryDto();
		ArrayList<UploadExecutionLogDto> uploadExecutionLogList = new ArrayList<UploadExecutionLogDto>();
		UploadExecutionLogDto uploadExecutionLogDto =  null;
		int transactionId = 0;
		configUploadHistoryDto.setImgID(fiMDInputDto.getScopeName());
		configUploadHistoryDto.setTransactionID(fiMDInputDto.getTransactionID());
		configUploadHistoryDto.setProjectName(fiMDInputDto.getProjectName());
		configUploadHistoryDto.setScenario(fiMDInputDto.getScenario());
		configUploadHistoryDto.setOmgID(fiMDInputDto.getOmgID());
		configUploadHistoryDto.setSystemID(fiMDInputDto.getSystemID());
		configUploadHistoryDto.setUserID(fiMDInputDto.getUserID());
		configUploadHistoryDto.setModule(fiMDInputDto.getModule());
		try{
		for(int i=0,arrSize = formattedDataList.size(); i < arrSize; i++){
			fiMDResponseDto = new FiMDResponseDto();
			dstResultsList = new ArrayList<JSONFormatDto>();
			masterDataResponseDto = executeTargetSysConfig(formattedDataList.get(i),destinationName,mdProgramPath, fiMDInputDto.getSapUserId(),fiMDInputDto.getSapPassword(),fiMDInputDto.getfiMDInputDto.getIsCustomDestinationRequired() );
			fiMDResponseDto.setConnectionStatus(masterDataResponseDto.isConnectionStatus());
			fiMDResponseDto.setExecutionStatus(masterDataResponseDto.isExecutionStatus());
			fiMDResponseDto.setResponseList(masterDataResponseDto.getResponseData());
			length = masterDataResponseDto.getResponseData().size();
			if(masterDataResponseDto.isConnectionStatus() && masterDataResponseDto.isExecutionStatus()){
				for(int k=0;k<length;k++){
					JSONFormatDto jSONFormatDto = new JSONFormatDto();
					
					result = masterDataResponseDto.getResponseData().get(k).split("~");
					if(k==0){
						fiMDResponseDto.setStatus(result[1].replaceAll("\\s+",""));
					}else{
						jSONFormatDto.setDescription(result[1]);
						jSONFormatDto.setErrorType(result[0]);
						jSONFormatDto.setMessageType(result[0]);
						jSONFormatDto.setScopeName("IMG_DUMMY_FIN1");
						dstResultsList.add(jSONFormatDto);
					}
				}
			}
			else{
				JSONFormatDto jSONFormatDto = new JSONFormatDto();
				jSONFormatDto.setDescription(masterDataResponseDto.getResponseData().get(0));
				jSONFormatDto.setErrorType("E");
				jSONFormatDto.setMessageType("E");
				jSONFormatDto.setScopeName("IMG_DUMMY_FIN1");
				dstResultsList.add(jSONFormatDto);
			}
			
			fiMDResponseDto.setResult(dstResultsList);
			fiMDResponseDtoList.add(fiMDResponseDto);

			}
		}catch(Exception e){
			dstResultsList = new ArrayList<JSONFormatDto>();
			JSONFormatDto jSONFormatDto = new JSONFormatDto();
			jSONFormatDto.setDescription(masterDataResponseDto.getResponseData().get(0));
			jSONFormatDto.setErrorType("E");
			jSONFormatDto.setMessageType("E");
			jSONFormatDto.setScopeName("IMG_DUMMY_FIN1");
			fiMDResponseDto.setStatus(ConstantsValues.ERRORSTATUS);
			dstResultsList.add(jSONFormatDto);
			fiMDResponseDto.setResult(dstResultsList);
			fiMDResponseDtoList.add(fiMDResponseDto);
			fiMDResponseDto.setMessage("Exception occured, invalid ourput from ABAP");
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);

		}
		//Added for Upload Logs
		int count = 0;
		for(int i = 0,arrSize = fiMDResponseDtoList.size(); i< arrSize ;i++){
			FiMDResponseDto dto = fiMDResponseDtoList.get(i);
			if(dto.getStatus() == "Success")
				count++;
		}
		if(count == fiMDResponseDtoList.size())
			configUploadHistoryDto.setStatus("S");
		else
			configUploadHistoryDto.setStatus("E");
		
		try{
			int seqNo = 1;
			ConfigAuditDAO configAuditDao =  new ConfigAuditDAO();
			transactionId = configAuditDao.createConfigUploadHistory(configUploadHistoryDto);
			if(transactionId > 0){
				
				for(int i = 0,arrSize = fiMDResponseDtoList.size(); i< arrSize ;i++){
					FiMDResponseDto dto = fiMDResponseDtoList.get(i);
					List<JSONFormatDto> reterieveExeList = dto.getResult();
					for(int j = 0,arrSiz = reterieveExeList.size(); j< arrSiz ;j++){
						JSONFormatDto dto1 = reterieveExeList.get(j);
						uploadExecutionLogDto = new UploadExecutionLogDto();
						uploadExecutionLogDto.setConfigUploadID(transactionId);
						uploadExecutionLogDto.setImgID(fiMDInputDto.getScopeName());
						uploadExecutionLogDto.setMessage(dto1.getDescription());
						uploadExecutionLogDto.setStatus(dto1.getMessageType());
						uploadExecutionLogDto.setUserID(fiMDInputDto.getUserID());
						uploadExecutionLogDto.setSequenceID(seqNo);
						uploadExecutionLogList.add(uploadExecutionLogDto);
						seqNo++;
					}
				}
				configAuditDao.createUploadExecutionLog(uploadExecutionLogList);
				
			}
		}catch(Exception e){
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}finally{
			  slf4jLogger.info("CCFiMasterHandler method ended");
		}
		return fiMDResponseDtoList;
	}
	
	
	public MasterDataResponseDto executeTargetSysConfig(ArrayList<String> formattedMasterData, String destinationName, String prgmPathMasterData ,  String sapUserId, String sapPassword, String customDesRequired ) {
		slf4jLogger.info("executeTargetSysConfig method started");
		ArrayList<String> resultText = new ArrayList<>();
		MasterDataResponseDto masterDataResponseDto = new MasterDataResponseDto();
		JCoRepository repo = null;
		DynamicDestinationDAO dynamicDestinationDaoObj= new DynamicDestinationDAO();
		DynamicDestinationResDto dynamicDestinationResDto = new DynamicDestinationResDto();
		try {
			JCoDestination destination = JCoDestinationManager.getDestination(destinationName);
			if(customDesRequired.equals("true")){
				dynamicDestinationResDto = dynamicDestinationDaoObj.createCustomDestinationObject(sapUserId, sapPassword, destination);
				if(dynamicDestinationResDto.getStatus().equals("Success"))
					repo = dynamicDestinationResDto.getCustomDestination().getRepository();
				else
					resultText.add("Exception occured while creating custom Destination"); 

			}
			else{
				repo = destination.getRepository();
			}
			masterDataResponseDto.setConnectionStatus(true);
			JCoFunction stfcConnection = null;
			stfcConnection = repo.getFunction(ConstantsValues.FUNCTIONMODULE);
			if (stfcConnection == null)
				throw new RuntimeException("/ACNIP/RFC not found in SAP.");
			JCoParameterList tabInput = stfcConnection.getTableParameterList();
			JCoTable paramTable = tabInput.getTable(ConstantsValues.IPARAM);
			for (int i = 0,arrSize = formattedMasterData.size(); i < arrSize; i++) {
				if(formattedMasterData.get(i) != null && !formattedMasterData.get(i).equalsIgnoreCase("") ){
					paramTable.appendRow();
					paramTable.setValue(ConstantsValues.WA, formattedMasterData.get(i));
				}
			}
			
			if(customDesRequired.equals("true")){
				stfcConnection.execute(dynamicDestinationResDto.getCustomDestination());
			}
			else{
				stfcConnection.execute(destination);
			}
				masterDataResponseDto.setExecutionStatus(true);
				JCoTable resultTable = tabInput.getTable(ConstantsValues.O_RESULT);
				for (int i = 0,rowSize = resultTable.getNumRows(); i < rowSize; i++) {
					resultTable.setRow(i);
					resultText.add(resultTable.getString(ConstantsValues.WA));
				}	
		} catch (AbapException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			resultText.add("Execution of RFC Failed: " + e); 
			masterDataResponseDto.setConnectionStatus(true);
		} catch (JCoException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			resultText.add("JCO Connection Failed: " + e); 
			masterDataResponseDto.setConnectionStatus(false);
		} catch (Exception e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			resultText.add("Configuration Failed: " + e);
			masterDataResponseDto.setExecutionStatus(false);
		}finally{
			  slf4jLogger.info("executeTargetSysConfig method ended");

		}
		masterDataResponseDto.setResponseData(resultText);
		return masterDataResponseDto;
	
	}
}
*/