package com.acn.rpa.fi;



import java.util.HashMap;
import java.util.List;

public class ProfitCenterDto {
	private String validFrom;
	private String validTo;
	private String testRun;

	private HashMap<String,String> ProfitCenterId;
	private HashMap<String,String> basicData;
	private HashMap<String,String> communication;
	private HashMap<String,String> indicators;
	private HashMap<String,String> address;
	private HashMap<String,String> language;
	private HashMap<String,String> companyCodesMap;

	public HashMap<String, String> getCompanyCodesMap() {
		return companyCodesMap;
	}
	public void setCompanyCodesMap(HashMap<String, String> companyCodesMap) {
		this.companyCodesMap = companyCodesMap;
	}
	private List<HashMap<String,String>> companyCodes; 
	
	
	public String getValidFrom() {
		return validFrom;
	}
	public void setValidFrom(String validFrom) {
		this.validFrom = validFrom;
	}
	public String getValidTo() {
		return validTo;
	}
	public void setValidTo(String validTo) {
		this.validTo = validTo;
	}
	public String getTestRun() {
		return testRun;
	}
	public void setTestRun(String testRun) {
		this.testRun = testRun;
	}
	public HashMap<String, String> getProfitCenterId() {
		return ProfitCenterId;
	}
	public void setProfitCenterId(HashMap<String, String> profitCenterId) {
		ProfitCenterId = profitCenterId;
	}
	public HashMap<String, String> getBasicData() {
		return basicData;
	}
	public void setBasicData(HashMap<String, String> basicData) {
		this.basicData = basicData;
	}
	public HashMap<String, String> getCommunication() {
		return communication;
	}
	public void setCommunication(HashMap<String, String> communication) {
		this.communication = communication;
	}
	public HashMap<String, String> getIndicators() {
		return indicators;
	}
	public void setIndicators(HashMap<String, String> indicators) { 
		this.indicators = indicators;
	}
	public HashMap<String, String> getAddress() {
		return address;
	}
	public void setAddress(HashMap<String, String> address) {
		this.address = address;
	}
	public HashMap<String, String> getLanguage() {
		return language;
	}
	public void setLanguage(HashMap<String, String> language) {
		this.language = language;
	}
	public List<HashMap<String, String>> getCompanyCodes() {
		return companyCodes;
	}
	public void setCompanyCodes(List<HashMap<String, String>> companyCodes) {
		this.companyCodes = companyCodes;
	}
	



	}
