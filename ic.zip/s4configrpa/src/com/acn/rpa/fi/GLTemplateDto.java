package com.acn.rpa.fi;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

public class GLTemplateDto {

	private ArrayList<String> columnList;
	private ArrayList<String> viewList;
	private ByteArrayOutputStream excelByteData;
	private boolean isVaildFile;
	public ArrayList<String> getColumnList() {
		return columnList;
	}
	public void setColumnList(ArrayList<String> columnList) {
		this.columnList = columnList;
	}
	public ArrayList<String> getViewList() {
		return viewList;
	}
	public void setViewList(ArrayList<String> viewList) {
		this.viewList = viewList;
	}
	public boolean isVaildFile() {
		return isVaildFile;
	}
	public void setVaildFile(boolean isVaildFile) {
		this.isVaildFile = isVaildFile;
	}
	
	public ByteArrayOutputStream getExcelByteData() {
		return excelByteData;
	}
	public void setExcelByteData(ByteArrayOutputStream excelByteData) {
		this.excelByteData = excelByteData;
	}
	
	
	
}
