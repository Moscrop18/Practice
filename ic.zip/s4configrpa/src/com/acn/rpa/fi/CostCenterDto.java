package com.acn.rpa.fi;

import java.util.HashMap;
import java.util.List;

public class CostCenterDto {
	
	private String controllingArea;
	private String testRun;
	private String master_data_inactive;
	private HashMap<String,String> language;
	private List<HashMap<String,String> > costCenterList;
	private List<HashMap<String,String> > returncostCenter;
	private List<HashMap<String,String> > extensionIn;
	private List<HashMap<String,String> > extensionOut;
	
	public List<HashMap<String, String>> getCostCenterList() {
		return costCenterList;
	}
	public void setCostCenterList(List<HashMap<String, String>> costCenterList) {
		this.costCenterList = costCenterList;
	}
	public List<HashMap<String, String>> getReturncostCenter() {
		return returncostCenter;
	}
	public void setReturncostCenter(List<HashMap<String, String>> returncostCenter) {
		this.returncostCenter = returncostCenter;
	}
	public List<HashMap<String, String>> getExtensionIn() {
		return extensionIn;
	}
	public void setExtensionIn(List<HashMap<String, String>> extensionIn) {
		this.extensionIn = extensionIn;
	}
	public List<HashMap<String, String>> getExtensionOut() {
		return extensionOut;
	}
	public void setExtensionOut(List<HashMap<String, String>> extensionOut) {
		this.extensionOut = extensionOut;
	}
	public String getControllingArea() {
		return controllingArea;
	}
	public void setControllingArea(String controllingArea) {
		this.controllingArea = controllingArea;
	}
	public String getTestRun() {
		return testRun;
	}
	public void setTestRun(String testRun) {
		this.testRun = testRun;
	}
	public String getMaster_data_inactive() {
		return master_data_inactive;
	}
	public void setMaster_data_inactive(String master_data_inactive) {
		this.master_data_inactive = master_data_inactive;
	}
	public HashMap<String,String> getLanguage() {
		return language;
	}
	public void setLanguage(HashMap<String,String> language) {
		this.language = language;
	}
	
	

}
