package com.acn.rpa.fi;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.acn.rpa.utilities.ConstantsValues;


public class ExcelFormatterGL {
	
    private final Logger slf4jLogger = LoggerFactory.getLogger(ExcelFormatterGL.class);

	public ArrayList<ArrayList<String>> convertFormat_PC(byte[] fileBytes,String imgId){
		slf4jLogger.info("convertFormat_PC method started");
        FileInputStream file = null;
        Workbook workbook = null;
        Sheet sheet = null;
        ArrayList<ArrayList<String>> masterDataGL =  new ArrayList<>();
		short columnsize = 0;
		short rowSize = 0,count = 1;
		Row currentRow = null;
		Cell tempCell = null;
		boolean isValidRow = true, isValidRecord = false;
        StringBuilder dataChange  = null;
        LinkedList<String> viewNameList = null;
        LinkedList<String> fieldNameList = null;
        List<String> excelData = null;
        LinkedList<String> tempData = null;
		int noOfRecords = 25000;
        String current_PC = "";
        LinkedHashMap<String, LinkedList<String>> PC_Map = new LinkedHashMap<>();
        ByteArrayInputStream byteIn = null;
        try {
        		byteIn = new ByteArrayInputStream(fileBytes);
        		workbook = WorkbookFactory.create(byteIn);
        		//file = new FileInputStream(new File(srcFile));
               // workbook = new XSSFWorkbook(file);
                sheet = workbook.getSheetAt(0);
                currentRow = sheet.getRow(0);
                columnsize = currentRow.getLastCellNum();
                viewNameList = new LinkedList<>(); 
				short currentSize = 0;
				while(currentSize < columnsize){
					tempCell = currentRow.getCell(currentSize);
					 if(tempCell == null){
            			 break;
            		 }else{
            			 tempCell.setCellType(Cell.CELL_TYPE_STRING);
            			 if(tempCell.getStringCellValue().trim().length()<=0)
            				 break;
            			 else
            				 viewNameList.add(tempCell.getStringCellValue().trim());
            		 }
					currentSize++;
				}
			
				columnsize = currentSize;	                
    	        fieldNameList = new LinkedList<>(); 
    	        currentRow = sheet.getRow(1);
    	        for(int i=0; i< columnsize; i++){
    	        	tempCell = currentRow.getCell(i);
    	        	if(tempCell != null){
	    	        	tempCell.setCellType(Cell.CELL_TYPE_STRING);
	    	        	fieldNameList.add(tempCell.getStringCellValue().trim());//Store Field Name
    	        	}else{
    	        		break;
    	        	}
    	        }
    	        excelData = new ArrayList<String>();	    	        
    	         dataChange = new StringBuilder();
    	         rowSize = 4;

    	        while(isValidRow){
    	        	currentRow = sheet.getRow(rowSize);
    	        	tempData = new  LinkedList<String>();
    	        	if(currentRow != null){
    	        		current_PC = "";
    	        		 for(int i = 0; i< columnsize; i++){
    	        			 dataChange = new StringBuilder();
    		    	        	tempCell = currentRow.getCell(i);
    		    	        	if(tempCell != null){
    		    	        		if(i == 0 || i == 1){
    		    	        			tempCell.setCellType(Cell.CELL_TYPE_STRING);
    		    	        			current_PC = current_PC + tempCell.getStringCellValue();
    		    	        		}
    		    	        		
    		    	        		if(!viewNameList.get(i).equalsIgnoreCase("Dummy")){
	    			    	        	tempCell.setCellType(Cell.CELL_TYPE_STRING);
	    			    	        	dataChange.append(viewNameList.get(i));
	    			    	        	dataChange.append("|");
	    			    	        	dataChange.append(fieldNameList.get(i));
	    			    	        	dataChange.append("|");
	    			    	        	dataChange.append(count);
	    			    	        	dataChange.append("|");
	    			    	        	dataChange.append(tempCell.getStringCellValue().trim());
	    			    	        	if(tempCell.getStringCellValue().length() > 0){
	    			    	        		tempData.add(dataChange.toString());
	    			    	        		isValidRecord = true;
	    			    	        	}
    		    	        		}
    		    	        	}
    		    	        }
    	        		 if(isValidRecord){
    	        			 if(current_PC.length() > 0){
    	        				 if(!PC_Map.isEmpty() && PC_Map.containsKey(current_PC)){
    	        					 PC_Map.get(current_PC).addAll(tempData);
    	        				 }else{
    	        					 PC_Map.put(current_PC, tempData);
    	        				 }
    	        			 }
     	        			 
 		            		isValidRecord = false;
 		            	}else{
 		            		isValidRow = false;
 		            		break;
 		            	}
    	        		 rowSize++;
    	        		 count++;
    	        	}else{
    	        		isValidRow = false;
    	        		break;
    	        	}
    	        }
    	        
    	        excelData = new ArrayList<String>();
    	        for (Entry<String, LinkedList<String>> entry : PC_Map.entrySet())
    	        {
    	         if(excelData.size() == 0 || (excelData.size()+entry.getValue().size())  < noOfRecords){
    	        		excelData.addAll(entry.getValue());
    	        	}else{
    	        		masterDataGL.add(new ArrayList<String>(excelData));
    	        		excelData = new ArrayList<String>();
    	        		excelData = entry.getValue();
    	        	}
    	        }    	        
    	        masterDataGL.add(new ArrayList<String>(excelData));
    	    
        }catch (FileNotFoundException e) {
            slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}catch (IOException e) {
		    slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}catch (NullPointerException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		} catch (EncryptedDocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			  
				try {
					if(workbook!= null)
					workbook.close();
					if(byteIn != null)
						byteIn.close();
					byteIn = null;
				} catch (IOException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
				 file = null;
		         workbook = null;
		         sheet = null;
				 columnsize = 0;
				 rowSize = 0;
				 currentRow = null;
				 tempCell = null;
		         dataChange  = null;
		         viewNameList = null;
		         fieldNameList = null;
		         excelData = null;
		         tempData = null;
				slf4jLogger.info("convertFormat_PC method ended");

		}

		return masterDataGL;
	}
	
	public ArrayList<ArrayList<String>> convertFormat(byte[] fileBytes,String imgId){
		  	slf4jLogger.info("convertFormat method started");
	        FileInputStream file = null;
	        Workbook workbook = null;
	        Sheet sheet = null;
	        ArrayList<ArrayList<String>> masterDataGL =  new ArrayList<>();
			short columnsize = 0;
			short rowSize = 0,count = 1;
			Row currentRow = null;
			Cell tempCell = null;
			boolean isValidRow = true, isValidRecord = false;
	        StringBuilder dataChange  = null;
	        ArrayList<String> viewNameList = null;
	        ArrayList<String> fieldNameList = null;
	        ArrayList<String> excelData = null;
	        ArrayList<String> tempData = null;
			int noOfRecords = 25000;
			ByteArrayInputStream byteIn = null;
	        try {
	        		//file = new FileInputStream(new File(srcFile));
	                //workbook = new XSSFWorkbook(file);
	        		byteIn = new ByteArrayInputStream(fileBytes);
	        		workbook = WorkbookFactory.create(byteIn);
	                sheet = workbook.getSheetAt(0);
	                currentRow = sheet.getRow(0);
	                columnsize = currentRow.getLastCellNum();
	                viewNameList = new ArrayList<>(); 
					short currentSize = 0;
					while(currentSize < columnsize){
						tempCell = currentRow.getCell(currentSize);
						 if(tempCell == null){
                			 break;
                		 }else{
                			 tempCell.setCellType(Cell.CELL_TYPE_STRING);
                			 if(tempCell.getStringCellValue().trim().length()<=0)
                				 break;
                			 else
                				 viewNameList.add(tempCell.getStringCellValue().trim());
                		 }
						currentSize++;
					}
				
					columnsize = currentSize;	                
	    	        fieldNameList = new ArrayList<>(); 
	    	        currentRow = sheet.getRow(1);
	    	        for(int i=0; i< columnsize; i++){
	    	        	tempCell = currentRow.getCell(i);
	    	        	if(tempCell != null){
		    	        	tempCell.setCellType(Cell.CELL_TYPE_STRING);
		    	        	fieldNameList.add(tempCell.getStringCellValue().trim());
	    	        	}else{
	    	        		break;
	    	        	}
	    	        }
	    	        excelData = new ArrayList<String>();	    	        
	    	         dataChange = new StringBuilder();
	    	         if(imgId.equals("FI_GL_MD_FS00"))//GL 
		    	        	rowSize = 3;
//		    	        else if(imgId.equals("SIMG_CFMENUORK1KE51"))//PC
//		    	        	rowSize = 4;
		    	        else if(imgId.equals("IMG_DUMMY_FIN1") || imgId.equals("IMG_DUMMY_FIN3"))//CC
		    	        	rowSize = 4;
		    	       /* else
		    	        	rowSize = 2;*/

	    	        rowSize = 4;
	    	        while(isValidRow){
	    	        	currentRow = sheet.getRow(rowSize);
	    	        	tempData = new  ArrayList<String>();
	    	        	if(currentRow != null){
	    	        		 for(int i = 0; i< columnsize; i++){
	    	        			 dataChange = new StringBuilder();
	    		    	        	tempCell = currentRow.getCell(i);
	    		    	        	if(tempCell != null){
	    		    	        		if(!viewNameList.get(i).equalsIgnoreCase("Dummy")){
		    			    	        	tempCell.setCellType(Cell.CELL_TYPE_STRING);
		    			    	        	dataChange.append(viewNameList.get(i));
		    			    	        	dataChange.append("|");
		    			    	        	dataChange.append(fieldNameList.get(i));
		    			    	        	dataChange.append("|");
		    			    	        	dataChange.append(count);
		    			    	        	dataChange.append("|");
		    			    	        	dataChange.append(tempCell.getStringCellValue().trim());
		    			    	        	if(tempCell.getStringCellValue().length() > 0){
		    			    	        		tempData.add(dataChange.toString());
		    			    	        		isValidRecord = true;
		    			    	        	}
	    		    	        		}
	    		    	        	}
	    		    	        }
	    	        		 if(isValidRecord){
	    	        			 if((excelData.size()+tempData.size()) > noOfRecords){
	    	        				masterDataGL.add(excelData);
	    	        				excelData = new ArrayList<String>();
	    	        			 }
	    	        				 
	    	        			 excelData.addAll(tempData);	    	        			 
	 		            		isValidRecord = false;
	 		            	}else{
	 		            		isValidRow = false;
	 		            		break;
	 		            	}
	    	        		 rowSize++;
	    	        		 count++;
	    	        	}else{
	    	        		isValidRow = false;
	    	        		break;
	    	        	}
	    	        }
	    	        masterDataGL.add(excelData);
	    	    
	        }catch (FileNotFoundException e) {
	            slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}catch (IOException e) {
			    slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			}catch (NullPointerException e) {
				slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
			} catch (EncryptedDocumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvalidFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				  
					try {
						if(workbook!= null)
						workbook.close();
						if(byteIn != null)
							byteIn.close();
						byteIn = null;
					} catch (IOException e) {
						slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
					}
					 file = null;
			         workbook = null;
			         sheet = null;
					 columnsize = 0;
					 rowSize = 0;
					 currentRow = null;
					 tempCell = null;
			         dataChange  = null;
			         viewNameList = null;
			         fieldNameList = null;
			         excelData = null;
			         tempData = null;
					 slf4jLogger.info("convertFormat method ended");

			}
			return masterDataGL;
		}
	
	public ArrayList<ArrayList<String>> convertFormatForConsolidation(byte[] fileBytes,String imgId){
	  	slf4jLogger.info("convertFormatForConsolidation method started");
        FileInputStream file = null;
        Workbook workbook = null;
        Sheet sheet = null;
        ArrayList<ArrayList<String>> masterDataGL =  new ArrayList<>();
		short columnsize = 0;
		short rowSize = 0,count = 1;
		Row currentRow = null;
		Cell tempCell = null;
		Cell cellValue = null;
		boolean isValidRow = true, isValidRecord = false;
        StringBuilder dataChange  = null;
        ArrayList<String> viewNameList = null;
        ArrayList<String> fieldNameList = null;
        ArrayList<String> excelData = null;
        ArrayList<String> tempData = null;
		int noOfRecords = 25000;
		ByteArrayInputStream byteIn = null;
		String indicator ="";
        try {
        		//file = new FileInputStream(new File(srcFile));
                //workbook = new XSSFWorkbook(file);
        		byteIn = new ByteArrayInputStream(fileBytes);
        		workbook = WorkbookFactory.create(byteIn);
                sheet = workbook.getSheetAt(2);
                currentRow = sheet.getRow(0);
                columnsize = currentRow.getLastCellNum();
                viewNameList = new ArrayList<>(); 
				short currentSize = 2;
				while(currentSize < columnsize){
					tempCell = currentRow.getCell(currentSize);
					 if(tempCell == null){
            			 break;
            		 }else{
            			 tempCell.setCellType(Cell.CELL_TYPE_STRING);
            			 if(tempCell.getStringCellValue().trim().length()<=0)
            				 break;
            			 else
            				 viewNameList.add(tempCell.getStringCellValue().trim().substring(6));
            		 }
					currentSize++;
				}
			
				columnsize = currentSize;	                
    	        fieldNameList = new ArrayList<>(); 
    	        currentRow = sheet.getRow(1);
    	        for(int i=2; i< columnsize; i++){
    	        	tempCell = currentRow.getCell(i);
    	        	if(tempCell != null){
	    	        	tempCell.setCellType(Cell.CELL_TYPE_STRING);
	    	        	fieldNameList.add(tempCell.getStringCellValue().trim());
    	        	}else{
    	        		break;
    	        	}
    	        }
    	        excelData = new ArrayList<String>();	    	        
    	         dataChange = new StringBuilder();
    	        rowSize = 3;
    	        while(isValidRow){
    	        	currentRow = sheet.getRow(rowSize);
    	        	tempData = new  ArrayList<String>();
    	        	if(currentRow != null){
    	        		 int j=0;
    	        		 for(int i = 2; i< columnsize; i++){
 
    	        			 dataChange = new StringBuilder();
    		    	        	tempCell = currentRow.getCell(i);
    		    	        	short col = 0;
								cellValue = currentRow.getCell(col);
								if (cellValue == null) {
									indicator = "";
								} else {
									cellValue.setCellType(Cell.CELL_TYPE_STRING);
									indicator = cellValue.getStringCellValue();
								}
								if (indicator.trim().equalsIgnoreCase("Yes"))
								{
									if(tempCell != null){
	    		    	        		
		    			    	        	tempCell.setCellType(Cell.CELL_TYPE_STRING);
		    			    	        	dataChange.append(viewNameList.get(j));
		    			    	        	dataChange.append("|");
		    			    	        	dataChange.append(fieldNameList.get(j));
		    			    	        	dataChange.append("|");
		    			    	        	dataChange.append(count);
		    			    	        	dataChange.append("|");
		    			    	        	dataChange.append(tempCell.getStringCellValue().trim());
		    			    	        	if(tempCell.getStringCellValue().length() > 0){
		    			    	        		tempData.add(dataChange.toString());
		    			    	        	}
	    		    	        	}	
								}
								tempCell.setCellType(Cell.CELL_TYPE_STRING);
								if(tempCell != null && tempCell.getStringCellValue().length() > 0){
			    	        		isValidRecord = true;
			    	        	}
								j++;
    		    	        	
    		    	        }
    	        		 if(isValidRecord){
    	        			 if((excelData.size()+tempData.size()) > noOfRecords){
    	        				masterDataGL.add(excelData);
    	        				excelData = new ArrayList<String>();
    	        			 }
    	        				 
    	        			 excelData.addAll(tempData);	    	        			 
 		            		isValidRecord = false;
 		            	}else{
 		            		isValidRow = false;
 		            		break;
 		            	}
    	        		 rowSize++;
    	        		 count++;
    	        	}else{
    	        		isValidRow = false;
    	        		break;
    	        	}
    	        }
    	        masterDataGL.add(excelData);
    	    
        }catch (FileNotFoundException e) {
            slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}catch (IOException e) {
		    slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		}catch (NullPointerException e) {
			slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
		} catch (EncryptedDocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			  
				try {
					if(workbook!= null)
					workbook.close();
					if(byteIn != null)
						byteIn.close();
					byteIn = null;
				} catch (IOException e) {
					slf4jLogger.error(ConstantsValues.EXCEPTIONDETAILS,e);
				}
				 file = null;
		         workbook = null;
		         sheet = null;
				 columnsize = 0;
				 rowSize = 0;
				 currentRow = null;
				 tempCell = null;
		         dataChange  = null;
		         viewNameList = null;
		         fieldNameList = null;
		         excelData = null;
		         tempData = null;
				 slf4jLogger.info("convertFormatForConsolidation method ended");

		}
		return masterDataGL;
	}
}
