package com.acn.rpa.fi;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.acn.rpa.config.JSONFormatDto;

public class FiMDResponseDto {

	private String message;
	private HashMap<String,String> response;
	private ArrayList<String> responseList;
	private String controlling_Area;
	private String masterDataType;
	private boolean connectionStatus;
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	private boolean executionStatus;
	private List<JSONFormatDto> result;
	private String status;
	
	public List<JSONFormatDto> getResult() {
		return result;
	}

	public void setResult(List<JSONFormatDto> result) {
		this.result = result;
	}

	public String getControlling_Area() {
		return controlling_Area;  
	}

	public void setControlling_Area(String controlling_Area) {
		this.controlling_Area = controlling_Area;
	}

	public String getMasterDataType() {
		return masterDataType;
	}

	public void setMasterDataType(String masterDataType) {
		this.masterDataType = masterDataType;
	}

	public HashMap<String, String> getResponse() {
		return response;
	}

	public void setResponse(HashMap<String, String> response) {
		this.response = response;
	}

	
	public FiMDResponseDto() {
	}
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}


	public ArrayList<String> getResponseList() {
		return responseList;
	}


	public void setResponseList(ArrayList<String> responseList) {
		this.responseList = responseList;
	}

	public boolean isConnectionStatus() {
		return connectionStatus;
	}

	public void setConnectionStatus(boolean connectionStatus) {
		this.connectionStatus = connectionStatus;
	}

	public boolean isExecutionStatus() {
		return executionStatus;
	}

	public void setExecutionStatus(boolean executionStatus) {
		this.executionStatus = executionStatus;
	}


	
}
