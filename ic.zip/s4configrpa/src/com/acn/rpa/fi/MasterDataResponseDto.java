package com.acn.rpa.fi;

import java.util.ArrayList;


public class MasterDataResponseDto {

	private boolean connectionStatus;
	private boolean executionStatus;
	ArrayList<FiMDResponseDto> fiMDResponseDtoList;
	ArrayList<String> responseData;
	

	public ArrayList<String> getResponseData() {
		return responseData;
	}
	public void setResponseData(ArrayList<String> responseData) {
		this.responseData = responseData;
	}
	public boolean isConnectionStatus() {
		return connectionStatus;
	}
	public void setConnectionStatus(boolean connectionStatus) {
		this.connectionStatus = connectionStatus;
	}
	public boolean isExecutionStatus() {
		return executionStatus;
	}
	public void setExecutionStatus(boolean executionStatus) {
		this.executionStatus = executionStatus;
	}
	public ArrayList<FiMDResponseDto> getFiMDResponseDtoList() {
		return fiMDResponseDtoList;
	}
	public void setFiMDResponseDtoList(ArrayList<FiMDResponseDto> fiMDResponseDtoList) {
		this.fiMDResponseDtoList = fiMDResponseDtoList;
	}
	
}
