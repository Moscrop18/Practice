package com.acn.rpa.fi;


import java.util.ArrayList;

import javax.validation.Valid;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.acn.user.session.SessionInputDTO;

public class FiMDInputDto {
	@Size(min = 1, max = 20)
	@Pattern(regexp = "[a-zA-Z0-9]+")
	private String destinationName;
	private String templateFilePath;
	@Size(min = 1, max = 30)
	private String scopeName;
	private String mdProgramPath;
	@Size(min = 0, max = 124)
	private String sapUserId;
	@Size(min = 0, max = 124)
	private String sapPassword;
	private String hostName;
	private String systemNo;
	
	private int sncEnabled;

	private String sncName;

	private String sncPartnerName;

	private String sapRouter;

	private String sncProtectionLevel;

	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public String getSystemNo() {
		return systemNo;
	}
	public void setSystemNo(String systemNo) {
		this.systemNo = systemNo;
	}
	public String getSapClientNo() {
		return sapClientNo;
	}
	public void setSapClientNo(String sapClientNo) {
		this.sapClientNo = sapClientNo;
	}
	private String sapClientNo;

	@Size(min = 0, max = 2)
	@Pattern(regexp = "[a-zA-Z]*$")
	private String sapLanguage;
	public String getSapLanguage() {
		return sapLanguage;
	}
	public void setSapLanguage(String sapLanguage) {
		this.sapLanguage = sapLanguage;
	}
	@Size(min = 1, max = 6)
	@Pattern(regexp = "[a-zA-Z]+")
	private String isCustomDestinationRequired;
	@DecimalMin(value = "1")
    @DecimalMax(value = "999999")
	private int transactionID;
	@Size(min = 1, max = 50)
	@Pattern(regexp = "[a-zA-Z0-9\\s._&-,]+") 
	private String projectName;
	@Size(min = 1, max = 40)
	@Pattern(regexp = "[a-zA-Z\\s._&-,]+")
	private String scenario;
	@Size(min = 1, max = 35)
	private String omgID;
	@Size(min = 0, max = 10)
	private String systemID;
	@Size(min = 1, max = 8)
	@Pattern(regexp = "[a-zA-Z0-9]+")
	private String userID;
	public byte[] getFileBytes() {
		return fileBytes;
	}
	public void setFileBytes(byte[] fileBytes) {
		this.fileBytes = fileBytes;
	}
	@Size(min = 0, max = 45)
	private String module;
	@Size(min = 0, max = 10)
	@Pattern(regexp = "[a-zA-Z0-9]*$")
	private String customizingTr;
	private boolean isIMGHierarchy;
	
	private boolean consolidate;

	public boolean isIMGHierarchy() {
		return isIMGHierarchy;
	}
	public void setIMGHierarchy(boolean isIMGHierarchy) {
		this.isIMGHierarchy = isIMGHierarchy;
	}
	@Valid
	private SessionInputDTO sessionInputDTO;
	private byte[] fileBytes;
	
	public SessionInputDTO getSessionInputDTO() {
		return sessionInputDTO;
	}
	public void setSessionInputDTO(SessionInputDTO sessionInputDTO) {
		this.sessionInputDTO = sessionInputDTO;
	}
	
	public String getSapUserId() {
		return sapUserId;
	}

	public int getTransactionID() {
		return transactionID;
	}

	public void setTransactionID(int transactionID) {
		this.transactionID = transactionID;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getScenario() {
		return scenario;
	}

	public void setScenario(String scenario) {
		this.scenario = scenario;
	}

	public String getOmgID() {
		return omgID;
	}

	public void setOmgID(String omgID) {
		this.omgID = omgID;
	}

	public String getSystemID() {
		return systemID;
	}

	public void setSystemID(String systemID) {
		this.systemID = systemID;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public void setSapUserId(String sapUserId) {
		this.sapUserId = sapUserId;
	}

	public String getIsCustomDestinationRequired() {
		return isCustomDestinationRequired;
	}

	public void setIsCustomDestinationRequired(String isCustomDestinationRequired) {
		this.isCustomDestinationRequired = isCustomDestinationRequired;
	}

	public String getSapPassword() {
		return sapPassword;
	}

	public void setSapPassword(String sapPassword) {
		this.sapPassword = sapPassword;
	}



	public String getMdProgramPath() {
		return mdProgramPath;
	}

	public void setMdProgramPath(String mdProgramPath) {
		this.mdProgramPath = mdProgramPath;
	}
	@Valid
	private ArrayList<ArrayList<String>> formattedData;
	
	public ArrayList<ArrayList<String>> getFormattedData() {
		return formattedData;
	}

	public void setFormattedData(ArrayList<ArrayList<String>> formattedData) {
		this.formattedData = formattedData;
	}

	public FiMDInputDto() {
	}
	
	public String getDestinationName() {
		return destinationName;
	}
	public void setDestinationName(String destinationName) {
		this.destinationName = destinationName;
	}
	public String getTemplateFilePath() {
		return templateFilePath;
	}
	public void setTemplateFilePath(String templateFilePath) {
		this.templateFilePath = templateFilePath;
	}
	public String getScopeName() {
		return scopeName;
	}
	public void setScopeName(String scopeName) {
		this.scopeName = scopeName;
	}

	public String getCustomizingTr() {
		return customizingTr;
	}

	public void setCustomizingTr(String customizingTr) {
		this.customizingTr = customizingTr;
	}
	public boolean isConsolidate() {
		return consolidate;
	}
	public void setConsolidate(boolean consolidate) {
		this.consolidate = consolidate;
	}
	public int getSncEnabled() {
		return sncEnabled;
	}
	public void setSncEnabled(int sncEnabled) {
		this.sncEnabled = sncEnabled;
	}
	public String getSncName() {
		return sncName;
	}
	public void setSncName(String sncName) {
		this.sncName = sncName;
	}
	public String getSncPartnerName() {
		return sncPartnerName;
	}
	public void setSncPartnerName(String sncPartnerName) {
		this.sncPartnerName = sncPartnerName;
	}
	public String getSapRouter() {
		return sapRouter;
	}
	public void setSapRouter(String sapRouter) {
		this.sapRouter = sapRouter;
	}
	public String getSncProtectionLevel() {
		return sncProtectionLevel;
	}
	public void setSncProtectionLevel(String sncProtectionLevel) {
		this.sncProtectionLevel = sncProtectionLevel;
	}
	
}
