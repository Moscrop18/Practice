import { Component, Input, OnInit, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { fromEvent } from 'rxjs'
import { map, debounceTime, tap, merge, delay, mapTo, share, repeat, switchMap, takeUntil } from 'rxjs/operators'
@Component({
  // tslint:disable-next-line:component-selector
  selector: 'card',
  template: `
    <div #card class="card-wrap">
      <div class="card"
        [ngStyle]="cardStyle()">
        <div class="card-bg" [ngStyle]="cardBgTransform()">
        <div class="card card-stats"  >
                            <div class="card-header card-header-warning card-header-icon">
                                <div class="card-icon">
                                    <i class="material-icons">credit_card</i>
                                </div>
                                <h3 class="card-title">Inventory</h3>
                            </div>
                            <div class="card-body">
                                <p>7298 custom objects are scanned from QR1 system  with namespace /0CUST/ (Z* and Y*), and 28%(2030*) objects have been used.
                                </p>
                            </div>
                            <div class="card-footer">
                                <div class="stats">
                                    <span>* 3 months’ worth of ST03N logs was used as input to validate the usage of custom objects</span>
                                </div>
                            </div>
                        </div>
        </div>
      </div>
    </div>`,
  styleUrls: ['./upgrade.component.scss']
})

export class UpgradeComponent implements OnInit, AfterViewInit {

  height;
  width;
  backgroundImage;
  mouseX = 0;
  mouseY = 0;
  @Input() cardBgImage = '';
  @ViewChild('card', { static: true }) card: ElementRef;
  cardStyling = this.cardStyle();
  get mousePX() {
    return this.mouseX / this.width;
  }
  get mousePY() {
    return this.mouseY / this.height;
  }

  ngAfterViewInit() {
    this.width = this.card.nativeElement.offsetWidth;
    this.height = this.card.nativeElement.offsetHeight;
  }

  cardStyle() {
    return this.transformStyle();
  }

  cardBgTransform() {

    return this.transformStyle();
  }

  private transformStyle() {
    const tX = this.mousePX * -30;
    const tY = this.mousePY * -30;
    return { transform: `rotateY(${tX}deg) rotateX(${tY}deg)` };
  }
  get nativeElement(): HTMLElement {
    return this.card.nativeElement;
  }
  ngOnInit() {
    const mouseMove$ = fromEvent<MouseEvent>(this.card.nativeElement, 'mousemove');
    const mouseLeave$ = fromEvent<MouseEvent>(this.card.nativeElement, 'mouseleave').pipe(
      delay(100),
      mapTo(({ mouseX: 0, mouseY: 0 })),
      share()
    )
    const mouseEnter$ = fromEvent<MouseEvent>(this.card.nativeElement, 'mouseenter').pipe(takeUntil(mouseLeave$))

    mouseEnter$.pipe(
      switchMap(() => mouseMove$),
      map(e => ({ mouseX: e.pageX - this.nativeElement.offsetLeft - this.width / 2, mouseY: e.pageY - 
        this.nativeElement.offsetTop - this.height / 2 }))
      , merge(mouseLeave$), repeat()
    ).subscribe(e => {
      this.mouseX = e.mouseX;
      this.mouseY = e.mouseY;
    })

  }
  
}
