import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdminLayoutRoutes } from './admin-layout.routing';
import { DashboardComponent } from '../../dashboard/dashboard.component';
import { UserProfileComponent } from '../../user-profile/user-profile.component';
import { TableListComponent } from '../../table-list/table-list.component';
import { TypographyComponent } from '../../typography/typography.component';
import { IconsComponent } from '../../icons/icons.component';
import { MapsComponent } from '../../maps/maps.component';
import { NotificationsComponent } from '../../notifications/notifications.component';
import { UpgradeComponent } from '../../upgrade/upgrade.component';
import { ProjectPlanComponent } from '../../project-plan/project-plan.component';
import { NgWizardModule, NgWizardConfig, THEME } from 'ng-wizard';
import { ProjectCreationComponent } from 'app/project-creation/project-creation.component';
import { ProjectInfoComponent } from '../../project-info/project-info.component';
import { GraphTilesComponent } from '../../graph-tiles/graph-tiles.component';
import { ManageActivitiesComponent } from '../../manage-activities/manage-activities.component';
import { GraphsDialogComponent } from '../../graphs-dialog/graphs-dialog.component';
import { ScaleRetrofitActivitiesComponent } from '../../scale-retrofit-activities/scale-retrofit-activities.component';
import { CoCreateActivitiesComponent } from '../../co-create-activities/co-create-activities.component';
import { GraphsRetrofitComponent } from '../../graphs-retrofit/graphs-retrofit.component';
import { DescribeActivitiesComponent } from '../../describe-activities/describe-activities.component';
import { SustainActivitiesComponent } from '../../sustain-activities/sustain-activities.component';
import {MatButtonModule} from '@angular/material/button';
import {MatInputModule} from '@angular/material/input';
import {MatRippleModule} from '@angular/material/core';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatSelectModule} from '@angular/material/select';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import {MatIconModule} from '@angular/material/icon';
import {MatTableModule} from '@angular/material/table';
import {MatDialogModule} from '@angular/material/dialog';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatToolbarModule } from '@angular/material/toolbar';
import {MatRadioModule} from '@angular/material/radio';
import {MatDividerModule} from '@angular/material/divider';
import {MatTabsModule} from '@angular/material/tabs';
import { HighchartsChartModule } from 'highcharts-angular';
import { MDBBootstrapModule } from 'angular-bootstrap-md';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatPaginatorModule} from '@angular/material/paginator';
import { SwiperModule } from 'swiper/angular';
import { DashboardActivitiesDialogComponent } from 'app/dashboard-activities-dialog/dashboard-activities-dialog.component';
import { DashboardActivitiesComponent } from 'app/dashboard-activities/dashboard-activities.component';

const ngWizardConfig: NgWizardConfig = {
  theme: THEME.default
};

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(AdminLayoutRoutes),
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatRippleModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatTooltipModule,
    MatExpansionModule,
    MatAutocompleteModule,
    MatIconModule,
    MatTableModule,
    MatDialogModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatProgressBarModule,
    MatPaginatorModule,
    MatToolbarModule,
    MatRadioModule,
    MatDividerModule,
    MatTabsModule,
    MatProgressSpinnerModule,
    HighchartsChartModule,
    SwiperModule,
    NgWizardModule.forRoot(ngWizardConfig),
    MDBBootstrapModule.forRoot()
  ],
  declarations: [
    DashboardComponent,
    UserProfileComponent,
    TableListComponent,
    TypographyComponent,
    IconsComponent,
    MapsComponent,
    NotificationsComponent,
    UpgradeComponent,
    ProjectCreationComponent,
    DashboardActivitiesDialogComponent,
    ProjectPlanComponent,
    ProjectInfoComponent,
    DashboardActivitiesComponent,
    GraphTilesComponent,
    ManageActivitiesComponent,
    GraphsDialogComponent,
    ScaleRetrofitActivitiesComponent,
    CoCreateActivitiesComponent,
    GraphsRetrofitComponent,
    DescribeActivitiesComponent,
    SustainActivitiesComponent
  ],
  providers: [
    MatDatepickerModule,
    MatNativeDateModule
  ],
})

export class AdminLayoutModule {}
