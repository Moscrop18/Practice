import { Component, OnInit, Inject} from '@angular/core';
import {MatDialog, MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import {FormGroup, FormControl} from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';
import { ActivityService } from '../service/activity.service';
import { Router, ActivatedRoute } from '@angular/router';
import { color } from 'highcharts';
import {MatDatepickerInputEvent} from '@angular/material/datepicker';
declare var $: any;


@Component({
  selector: 'app-dashboard-activities-dialog',
  templateUrl: './dashboard-activities-dialog.component.html',
  styleUrls: ['./dashboard-activities-dialog.component.css']
})
export class DashboardActivitiesDialogComponent implements OnInit {
  responsibityTeamList: any;
  activityList: any;
  projectId: any;
  dialogData: any;
  taskActivityForm = this.fb.group({
    activityId: [],
    responsibleTeamId: [],
    plannedStartDate: ['', Validators.required],
    plannedEndDate: ['', Validators.required],
    actualStartDate: [],
    actualEndDate: [],
    completionStatus: [],
    overallStatus: [],
    comments: [],
    projectId: [],
    otherResponsibleTeamName: [],
    otherActivityName: []
  });

  overallStatusValue: String;
  flag: Boolean;
  color = 'yellow';

  completionStatusList = [
    {value: 'Not-Started', viewValue: 'Not-Started'},
    {value: 'In-Progress', viewValue: 'In-Progress'},
    {value: 'Completed', viewValue: 'Completed'}
  ];

  overallStatusList = [
    {value: 'Delayed', viewValue: 'Delayed'}
  ];

  constructor(@Inject(MAT_DIALOG_DATA) public data: any, public dialogRef: MatDialogRef<DashboardActivitiesDialogComponent>,
   private fb: FormBuilder, private activityService: ActivityService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit(): void {
    this.projectId = this.data.projectId;
    if (this.data && this.data.phase) {
      this.getActivityList();
      this.getResTeamList();
    }
    if (this.data && this.data.rowData !== '') {
      this.dialogData = this.data.rowData;
        this.taskActivityForm.setValue({
        activityId: this.dialogData.activityId ? this.dialogData.activityId : '',
        responsibleTeamId: this.dialogData.responsibleTeamId ? this.dialogData.responsibleTeamId : '',
        plannedStartDate: this.dialogData.plannedStartDate ? (new Date(this.dialogData.plannedStartDate + 'EDT')).toISOString() : '',
        plannedEndDate: this.dialogData.plannedEndDate ? (new Date(this.dialogData.plannedEndDate + 'EDT')).toISOString() : '',
        actualStartDate: this.dialogData.actualStartDate ? (new Date(this.dialogData.actualStartDate + 'EDT')).toISOString() : '',
        actualEndDate: this.dialogData.actualEndDate ? (new Date(this.dialogData.actualEndDate + 'EDT')).toISOString() : '',
        completionStatus: this.dialogData.completionStatus ? this.dialogData.completionStatus : '',
        overallStatus: this.dialogData.overallStatus ? this.dialogData.overallStatus : '',
        comments: this.dialogData.comments ? this.dialogData.comments : '',
        projectId: this.projectId ? this.projectId : '',
        otherResponsibleTeamName: (this.dialogData.value && this.dialogData.value.otherResponsibleTeamName) ?
        this.dialogData.value.otherResponsibleTeamName : '',
        otherActivityName: (this.dialogData.value && this.dialogData.value.otherActivityName) ?  this.dialogData.value.otherActivityName : ''

      });
     const p_start_date = new Date(this.dialogData.plannedStartDate);
     const p_end_date = new Date(this.dialogData.plannedEndDate);
     const a_start_date = new Date(this.dialogData.actualStartDate);
     const a_end_date = new Date(this.dialogData.actualEndDate);

      if (p_start_date < a_start_date || p_end_date < a_end_date ) {
           this.overallStatusValue = 'Delayed';
      } else {
          this.overallStatusValue = '';
      }

      if (p_start_date < a_start_date && p_end_date >= a_end_date) {
           this.flag = true;
      }
      if (p_start_date < a_start_date && p_end_date < a_end_date) {
          this.flag = false;
      }
      if (this.flag === true) {
        this.color = 'orange';
      }
      if (this.flag === false) {
        this.color = 'red'
      }
    }
  }

  addEvent(type: string, event: MatDatepickerInputEvent<Date>) {
    if (event.value && type === 'pStartDate') {
      this.taskActivityForm.value.plannedStartDate = new Date(event.value + 'EDT').
      toISOString().slice(0, 10).replace('T', ' ')
    }
    if (type === 'pEndDate') {
      this.taskActivityForm.value.plannedEndDate = new Date(event.value + 'EDT').
      toISOString().slice(0, 10).replace('T', ' ')
    }
    if (event.value && type === 'aStartDate') {
      this.taskActivityForm.value.actualStartDate = new Date(event.value + 'EDT').
      toISOString().slice(0, 10).replace('T', ' ')
    }
    if (type === 'aEndDate') {
      this.taskActivityForm.value.actualEndDate = new Date(event.value + 'EDT').
      toISOString().slice(0, 10).replace('T', ' ')
    }
  }

  myFilter = (d: Date | null): boolean => {
    const day = (d || new Date()).getDay();
    // Prevent Saturday and Sunday from being selected.
    return day !== 0 && day !== 6;
  }

  getResTeamList() {
    this.activityService.getResponsibleTeamList().subscribe(res => {
      if (res) {
        this.responsibityTeamList = res;
      }
    }, err => {
      console.log(err.status);
    });
  }

  getActivityList() {
    this.activityService.getActivityList(this.data.phase).subscribe(res => {
      if (res) {
        this.activityList = res;
      }
    }, err => {
      console.log(err.status);
    });
  }

  onSubmitTaskActivity() {
    if (this.taskActivityForm.status === 'INVALID') {
      return false;
    }
    this.taskActivityForm.setValue({
      activityId: this.taskActivityForm.value.activityId ? this.taskActivityForm.value.activityId : '',
      responsibleTeamId: this.taskActivityForm.value.responsibleTeamId ? this.taskActivityForm.value.responsibleTeamId : '',
      plannedStartDate: this.taskActivityForm.value.plannedStartDate ? new Date(this.taskActivityForm.value.plannedStartDate + 'EDT').
      toISOString().slice(0, 10).replace('T', ' ') : '',
      plannedEndDate: this.taskActivityForm.value.plannedEndDate ? new Date(this.taskActivityForm.value.plannedEndDate + 'EDT').
      toISOString().slice(0, 10).replace('T', ' ') : '',
      actualStartDate: this.taskActivityForm.value.actualStartDate ? new Date(this.taskActivityForm.value.actualStartDate + 'EDT').
      toISOString().slice(0, 10).replace('T', ' ') : '',
      actualEndDate: this.taskActivityForm.value.actualEndDate ? new Date(this.taskActivityForm.value.actualEndDate + 'EDT').
      toISOString().slice(0, 10).replace('T', ' ') : '',
      projectId: this.projectId ? this.projectId : '',
      overallStatus: '',
      comments: this.taskActivityForm.value.comments ? this.taskActivityForm.value.comments : '',
      completionStatus: this.taskActivityForm.value.completionStatus ? this.taskActivityForm.value.completionStatus : '',
      otherResponsibleTeamName: this.taskActivityForm.value.otherResponsibleTeamName ?
      this.taskActivityForm.value.otherResponsibleTeamName : '',
      otherActivityName: this.taskActivityForm.value.otherActivityName ?  this.taskActivityForm.value.otherActivityName : ''

  });

    if ((this.taskActivityForm.value.activityId === 'other') || (this.taskActivityForm.value.responsibleTeamId === 'other')) {
      if ((this.taskActivityForm.value.activityId === 'other') && (this.taskActivityForm.value.responsibleTeamId !== 'other')) {
        this.addOtherActivity();
      }
      if ((this.taskActivityForm.value.activityId !== 'other') && (this.taskActivityForm.value.responsibleTeamId === 'other')) {
        this.addOtherResTeam();
      }
      if ((this.taskActivityForm.value.activityId === 'other') && (this.taskActivityForm.value.responsibleTeamId === 'other')) {
        this.addAllActivities();
      }
    } else {
        this.addActivity();
    }
  }

  addOtherActivity() {
    let otherActivityData: any;
      otherActivityData = {
        activityName : this.taskActivityForm.value.otherActivityName,
        activityType : 'Others',
        taskName : this.data.taskName,  /*Eg: Assessment */
        phaseName : this.data.phase   /*Eg: Discover*/
      }
      this.activityService.addOtherActivity(otherActivityData).subscribe((res: any) => {
        if (res && res.activityId) {
          this.taskActivityForm.value.activityId = res.activityId;
          this.addActivity();
        }
      }, (err => {
      console.log(err + 'error in adding other activities');
      }));
  }

  addOtherResTeam() {
    let otherResTeamData: any;
      otherResTeamData = {
        'responsibleTeamName' : this.taskActivityForm.value.otherResponsibleTeamName,
        'responsibleTeamType' : 'Others'
      }
      this.activityService.addOtherResponseTeam(otherResTeamData).subscribe((res: any) => {
        if (res && res.responsibleTeamId) {
          this.taskActivityForm.value.responsibleTeamId = res.responsibleTeamId;
          this.addActivity();
        }
      }, (err => {
      console.log(err + 'error in adding other activities');
      }));
  }

  addActivity() {
    this.activityService.addActivity(this.taskActivityForm.value).subscribe(res => {
      if (res) {
        this.getActivityList();
        this.showNotification('top', 'center', 'success', 'Activity is saved successfully.');
        this.closeDialog();
      }
    }, err => {
      console.log(err.status);
      if (err.status === 200) {
        this.showNotification('top', 'center', 'success', 'Activity is saved successfully.');
      } else {
        this.showNotification('top', 'center', 'error', 'Activity could not be saved. Please try again.');
        this.closeDialog();
      }
    });
  }

  addAllActivities() {
    let otherActivityData: any;
      otherActivityData = {
        activityName : this.taskActivityForm.value.otherActivityName,
        activityType : 'Others',
        taskName : this.data.taskName,  /*Eg: Assessment */
        phaseName : this.data.phase   /*Eg: Discover*/
      }
      this.activityService.addOtherActivity(otherActivityData).subscribe((res: any) => {
        if (res && res.activityId) {
          this.taskActivityForm.value.activityId = res.activityId;
          this.addOtherResTeam();
        }
      }, (err => {
      console.log(err + 'error in adding other activities');
      }));
  }

  onUpdateTaskActivity() {
    this.taskActivityForm.setValue({
      activityId: this.taskActivityForm.value.activityId ? this.taskActivityForm.value.activityId : '',
      responsibleTeamId: this.taskActivityForm.value.responsibleTeamId ? this.taskActivityForm.value.responsibleTeamId : '',
      plannedStartDate: this.taskActivityForm.value.plannedStartDate ? this.taskActivityForm.value.plannedStartDate  : '',
      plannedEndDate: this.taskActivityForm.value.plannedEndDate ? this.taskActivityForm.value.plannedEndDate : '',
      actualStartDate: this.taskActivityForm.value.actualStartDate ? this.taskActivityForm.value.actualStartDate : '',
      actualEndDate: this.taskActivityForm.value.actualEndDate ? this.taskActivityForm.value.actualEndDate : '',
      projectId: this.projectId ? this.projectId : '',
      overallStatus: '',
      comments: this.taskActivityForm.value.comments ? this.taskActivityForm.value.comments : '',
      completionStatus: this.taskActivityForm.value.completionStatus ? this.taskActivityForm.value.completionStatus : '',
      otherResponsibleTeamName: this.taskActivityForm.value.otherResponsibleTeamName ?
      this.taskActivityForm.value.otherResponsibleTeamName : '',
      otherActivityName: this.taskActivityForm.value.otherActivityName ?  this.taskActivityForm.value.otherActivityName : ''
    });
    this.activityService.updateActivity(this.dialogData.id, this.taskActivityForm.value).subscribe((res: any) => {
      if (res && res.status === 'Success') {
        this.showNotification('top', 'center', 'success', 'Activity is updated successfully.');
        this.closeDialog();
      }
    }, (err => {
    console.log(err + 'error in adding other activities');
    this.showNotification('top', 'center', 'error', 'Activity could not be saved. Please try again.')
    this.closeDialog();
    }));

  }

  closeDialog() {
    this.dialogRef.close('Success');
  }

  showNotification(from, align, notificationType, showMessage) {
    const type = ['error', 'info', 'success', 'warning', 'danger'];


    $.notify({
        icon: 'notifications',
        message: showMessage

    }, {
        type: notificationType,
        timer: 3000,
        placement: {
            from: from,
            align: align
        },
        template: '<div data-notify="container" class="col-xl-4 col-lg-4 col-11 col-sm-4 col-md-4 alert alert-{0} alert-with-icon" role="alert">' +
          '<button mat-button  type="button" aria-hidden="true" class="close mat-button" data-notify="dismiss">  <i class="material-icons">close</i></button>' +
          '<i class="material-icons" data-notify="icon">notifications</i> ' +
          '<span data-notify="title">{1}</span> ' +
          '<span data-notify="message">{2}</span>' +
          '<div class="progress" data-notify="progressbar">' +
            '<div class="progress-bar progress-bar-{0}" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%;"></div>' +
          '</div>' +
          '<a href="{3}" target="{4}" data-notify="url"></a>' +
        '</div>'
    });
  }
}
