import { Component, OnInit } from '@angular/core';
import { ProjectService } from '../service/project.service';
import { Router, ActivatedRoute } from '@angular/router';
import { LoginService } from '../service/login.service';
@Component({
  selector: 'app-project-info',
  templateUrl: './project-info.component.html',
  styleUrls: ['./project-info.component.css']
})
export class ProjectInfoComponent implements OnInit {
  projectId: any;
  projectInfo: any;
  constructor(private projectService: ProjectService, private activatedRoute: ActivatedRoute, private loginService: LoginService) { }

  ngOnInit(): void {
    if (this.activatedRoute.snapshot['_urlSegment'] && this.activatedRoute.snapshot['_urlSegment']['segments'] &&
    this.activatedRoute.snapshot['_urlSegment']['segments'][1]) {
      this.projectId = this.activatedRoute.snapshot['_urlSegment']['segments'][1].path;
      this.getProjectInfo();
    }
  }

  getProjectInfo() {
    this.projectService.getProjectInfo(this.projectId).subscribe(res => {
      if (res) {
        this.projectInfo = res;
      }
    }, err => {
      console.log(err.status);
    });
  }
}
