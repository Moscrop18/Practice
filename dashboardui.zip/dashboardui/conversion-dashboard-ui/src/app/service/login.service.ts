import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { environment } from 'environments/environment';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { catchError, retry } from 'rxjs/operators';
import {ConfigService} from '../config/config.service';

const API_URL = environment.apiEndpoint;

@Injectable({
  providedIn: 'root'
})

export class LoginService {
  newUserId: any;
  constructor(private http: HttpClient, public config: ConfigService) { }


  loginUser(userDetails): Observable<{}> {
    return this.http.post(API_URL + 'checkUser', userDetails, this.config.httpOptions);
      // .pipe(
      //   catchError(this.handleError( hero))
      // );
  }
}
