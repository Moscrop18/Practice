import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { environment } from 'environments/environment';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import {ConfigService} from '../config/config.service';

const API_URL = environment.apiEndpoint;

@Injectable({
  providedIn: 'root'
})
export class ProjectService {

  constructor(private http: HttpClient, public config: ConfigService) { }


  addProject(projectDetails): Observable<{}> {
    return this.http.post(API_URL + 'saveProject', projectDetails, this.config.httpOptions);
      // .pipe(
      //   catchError(this.handleError( hero))
      // );
  }
  getProjectInfo(projectId): Observable<{}> {
    return this.http.get(API_URL + 'getProject/' + projectId , this.config.httpOptions);
  }
}
