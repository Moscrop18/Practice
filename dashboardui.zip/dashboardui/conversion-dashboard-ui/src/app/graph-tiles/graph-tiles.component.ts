import { Component, OnInit } from '@angular/core';
import {MatDialog, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { Router, ActivatedRoute } from '@angular/router';
import { GraphsDialogComponent } from 'app/graphs-dialog/graphs-dialog.component';
import { KpiService } from '../service/kpi.service';

@Component({
  selector: 'app-graph-tiles',
  templateUrl: './graph-tiles.component.html',
  styleUrls: ['./graph-tiles.component.css']
})
export class GraphTilesComponent implements OnInit {
  projectId: any;
  tilesData: any;
  showCustomizationTiles = false;
  showCITiles = false;
  showTestingScopeTiles = false;
  reqId = '97'; // ReqId needs to be dynamic

  constructor(public dialog: MatDialog, private activatedRoute: ActivatedRoute, private router: Router,
     private kpiService: KpiService) { }

  ngOnInit(): void {
    if (this.activatedRoute.snapshot['_urlSegment'] && this.activatedRoute.snapshot['_urlSegment']['segments'] &&
    this.activatedRoute.snapshot['_urlSegment']['segments'][1]) {
      this.projectId = this.activatedRoute.snapshot['_urlSegment']['segments'][1].path;
      this.getTilesData(this.projectId);
    }
  }

  openGraphDialog(type, tileType) {
    if (type === 'customImpact') {
      this.showCITiles = true;
      return;
    }
    if (type === 'testingScope') {
      this.showTestingScopeTiles = true;
      return;
    }
    if (type === 'CustomizationView') {
      this.showCustomizationTiles = true;
    } else {
      console.log(type);
      if (this.tilesData) {
        const dialogRef = this.dialog.open(GraphsDialogComponent, {
          width: '4000px',
          height: '650px',
          data: {
            rowData: type,
            projectId: this.projectId,
            tileType: tileType
          },
          });
          dialogRef.afterClosed().subscribe(result => {
            console.log('Dialog result: ${result}');
          });
      }
    }
  }

  showCV() {
    this.showCustomizationTiles = false;
    this.showCITiles = false;
    this.showTestingScopeTiles = false;
  }

  getTilesData(projectId) {
    this.kpiService.getKpiTilesData(this.reqId).subscribe(res => {
      if (res) {
        console.log(res);
        this.tilesData = res;
      }
    }, err => {
      console.log(err.status);
    });
  }


}
