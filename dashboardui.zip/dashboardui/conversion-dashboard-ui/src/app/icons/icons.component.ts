import { Component, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts/highcharts-gantt';

@Component({
  selector: 'app-icons',
  templateUrl: './icons.component.html',
  styleUrls: ['./icons.component.css'],
})
export class IconsComponent implements OnInit {
  showElement: any;
  width: any;
  height: any;
  Highcharts: typeof Highcharts = Highcharts;
  chartOptions: Highcharts.Options = {
    title: {
      text: 'Activity Plan'
    },
    yAxis: {
      uniqueNames: true
  },
  navigator: {
      enabled: true,
      series: {
          type: 'gantt',
          pointPadding: 0.25
      },
      yAxis: {
          min: 0,
          max: 3,
          reversed: true,
          categories: []
      }
      },
      scrollbar: {
          enabled: true
      },
      rangeSelector: {
          enabled: true,
          selected: 0
      },


    series: [
      {
        type: 'gantt',
        name: 'Assessment',
        data: [
          {
            name: 'Kick off Meeting',
            start: Date.UTC(2021, 4, 18),
            end: Date.UTC(2021, 10, 25),
            completed: 0.25
          },
          {
            name: 'Team Mobilization',
            start: Date.UTC(2021, 3, 27),
            end: Date.UTC(2021, 4, 2),
            completed: {
              amount: 1
            }
          },
          {
            name: 'Arrange for the Team access',
            start: Date.UTC(2021, 6, 10),
            end: Date.UTC(2022, 10, 25),
            completed: {
              amount: 0.12
            }
          },
          {
            name: 'Generate TR to import',
            start: Date.UTC(2021, 11, 23),
            end: Date.UTC(2022, 8, 26)
          }
        ]
      }
    ]
  };
  constructor() {
    this.width = 100;
    this.height = 600;
  }

  ngOnInit() {
  }
}
