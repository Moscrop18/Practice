import { Component, OnInit } from '@angular/core';
import {MatDialog, MAT_DIALOG_DATA} from '@angular/material/dialog';
import {DashboardActivitiesDialogComponent} from '../dashboard-activities-dialog/dashboard-activities-dialog.component';
import { ActivityService } from '../service/activity.service';
import { Router, ActivatedRoute } from '@angular/router';
declare var $: any;

@Component({
  selector: 'app-describe-activities',
  templateUrl: './describe-activities.component.html',
  styleUrls: ['./describe-activities.component.css']
})
export class DescribeActivitiesComponent implements OnInit {
  dataSource: any;
  projectId: any;
  launchDataList: any;
  overallStatus: any;
  flag: Boolean;
  color: any;

  displayedColumns: string[] = ['activityName', 'responsibleTeamName', 'plannedStartDate', 'plannedEndDate', 'actualStartDate', 'actualEndDate', 'completionStatus', 'overallStatus' , 'edit', 'delete'];
  launchDisplayColumns: string[] = ['activityName', 'action'];
  constructor(public dialog: MatDialog, private activityService: ActivityService,
    private activatedRoute: ActivatedRoute, private router: Router) { }

  ngOnInit(): void {
    this.launchDataList = [{activityName : 'Pre-Conversion', link : 'https://devptsaptechnology.accenture.com/sap/bc/gui/sap/its/webgui?%7eTRANSACTION=zauto_tool&sap-client=100&sap-language=EN#'}];
    if (this.activatedRoute.snapshot['_urlSegment'] && this.activatedRoute.snapshot['_urlSegment']['segments'] &&
    this.activatedRoute.snapshot['_urlSegment']['segments'][1]) {
      this.projectId = this.activatedRoute.snapshot['_urlSegment']['segments'][1].path;
      if (this.projectId) {
        this.getActivityList(this.projectId);

      }
    }
  }

  openTaskDialog(rowData) {
    const dialogRef = this.dialog.open(DashboardActivitiesDialogComponent, {
      width: '1000px',
      data: {
        rowData: rowData,
        projectId: this.projectId,
        phase: 'describe',
        taskName: 'preConversion'
      },
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('Dialog result: ${result}');
      this.getActivityList(this.projectId);
    });
  }

  deleteTask(rowData) {
    if (rowData.id) {
      this.activityService.deleteActivity(rowData.id).subscribe(res => {
        console.log(res);
        if (res) {
          this.getActivityList(this.projectId);
          this.showNotification('top', 'center', 'success', 'Activity is deleted successfully.');
        }
      }, err => {
        console.log(err.status);
        if (err.status === 200) {
          this.getActivityList(this.projectId);
          this.showNotification('top', 'center', 'success', 'Activity is deleted successfully.');
        } else {
          this.showNotification('top', 'center', 'error', 'Activity could not be deleted. Please try again later');
        }
      });
    }
  }

  getActivityList(projectId) {
    this.activityService.getAllAssessments('describe', 'preConversion', projectId).subscribe(res => {
      if (res) {
        console.log(res);
        this.dataSource = res;
      }
    }, err => {
      console.log(err.status);
    });
  }

  getoverallStatus(element) {
    const p_start_date = new Date(element.plannedStartDate);
    const p_end_date   = new Date(element.plannedEndDate);
    const a_start_date = new Date(element.actualStartDate);
    const a_end_date   = new Date(element.actualEndDate);

   if (p_start_date < a_start_date || p_end_date < a_end_date ) {
     this.overallStatus = 'Delayed';
   } else {
    this.overallStatus = '';
   }

   return this.overallStatus;
 }

 getOverallStatusColor(element) {
   this.color = 'yellow';
   const p_start_date = new Date(element.plannedStartDate);
    const p_end_date   = new Date(element.plannedEndDate);
    const a_start_date = new Date(element.actualStartDate);
    const a_end_date   = new Date(element.actualEndDate);

    if (p_start_date < a_start_date && p_end_date >= a_end_date) {
     this.color = 'orange';
     return this.color;
   }

  if (p_start_date <= a_start_date && p_end_date < a_end_date) {
    this.color = 'red';
    return this.color;
  } else {
   this.color = 'yellow';
   return this.color;
   }
 }

  showNotification(from, align, notificationType, showMessage) {
    const type = ['', 'info', 'success', 'warning', 'danger'];

    const color = Math.floor((Math.random() * 4) + 1);

    $.notify({
        icon: 'notifications',
        message: showMessage

    }, {
        type: notificationType,
        timer: 3000,
        placement: {
            from: from,
            align: align
        },
        template: '<div data-notify="container" class="col-xl-4 col-lg-4 col-11 col-sm-4 col-md-4 alert alert-{0} alert-with-icon" role="alert">' +
          '<button mat-button  type="button" aria-hidden="true" class="close mat-button" data-notify="dismiss">  <i class="material-icons">close</i></button>' +
          '<span data-notify="title">{1}</span> ' +
          '<span data-notify="message">{2}</span>' +
          '<div class="progress" data-notify="progressbar">' +
            '<div class="progress-bar progress-bar-{0}" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%;"></div>' +
          '</div>' +
          '<a href="{3}" target="{4}" data-notify="url"></a>' +
        '</div>'
    });
  }

}
