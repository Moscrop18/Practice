import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { LoginService } from '../service/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  form: FormGroup;
  loading = false;
  submitted = false;
  returnUrl: string;
  loginResult;

  constructor(private formBuilder: FormBuilder,
        private route: ActivatedRoute,
        private router: Router, private loginService: LoginService) { }

  ngOnInit() {
    this.form = this.formBuilder.group({
      userEmailId: ['', Validators.required],
      userPassword: ['', Validators.required]
  });

  // get return url from route parameters or default to '/'
  this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
  }

  // convenience getter for easy access to form fields
  get f() { return this.form.controls; }

  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.form.invalid) {
        return;
    }

   this.loginService.loginUser(this.form.value).subscribe(res => {
      if (res) {
        let data: any;
        data = res;
        this.router.navigate(['dashboard/' + data.projectId]);
      }
    }, err => {
      console.log(+ err.status);
      if (err.status === 404) {
        this.loginService.newUserId = this.form.value.userEmailId;
        this.router.navigate(['project-creation']);
      }
    });

    // this.router.navigate(['dashboard']);
}

}
