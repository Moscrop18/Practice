import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SustainActivitiesComponent } from './sustain-activities.component';

describe('SustainActivitiesComponent', () => {
  let component: SustainActivitiesComponent;
  let fixture: ComponentFixture<SustainActivitiesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SustainActivitiesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SustainActivitiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
