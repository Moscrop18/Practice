export const environment = {
  production: true,
  apiEndpoint: '',
  kpiEndpoint: '',
  sapEndpoint: ''
};
