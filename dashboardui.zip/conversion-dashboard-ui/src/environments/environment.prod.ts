export const environment = {
  production: true,
  apiEndpoint: 'https://tools-dev.accenture.com/conversion-dashboard/api/',
  kpiEndpoint: 'https://tools-dev.accenture.com/view-reports/api/',
  sapEndpoint: 'http://10.35.20.174:8000/sap/opu/odata/sap/'
};
