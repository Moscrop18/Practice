import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Validators } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { ProjectService } from '../service/project.service';
import { Router, ActivatedRoute } from '@angular/router';
import { LoginService } from '../service/login.service';
declare var $: any;

@Component({
  selector: 'app-project-creation',
  templateUrl: './project-creation.component.html',
  styleUrls: ['./project-creation.component.css']
})
export class ProjectCreationComponent implements OnInit {
  projectCreationForm = this.fb.group({
    clientName: ['', Validators.required],
    marketUnit: ['', Validators.required],
    sourceSystem: ['', Validators.required],
    targetSystem: ['', Validators.required],
    onshoreClient: ['', [Validators.required, Validators.email]],
    offshoreClient: ['', [Validators.required, Validators.email]],
    smartFieldUsecase: ['', Validators.required],
    industry: ['', Validators.required],
    userEmailId: this.loginService.newUserId
  });
  smartFieldOptions = [
    {value: 'Transformational Greenfield', viewValue: 'Transformational Greenfield'},
    {value: 'Lean Greenfield', viewValue: 'Lean Greenfield'},
    {value: 'Mix & Match', viewValue: 'Mix & Match'},
    {value: 'Reduced Shell', viewValue: 'Reduced Shell'},
    {value: 'Empty Shell', viewValue: 'Empty Shell'},
    {value: 'Brownfield', viewValue: 'Brownfield'},
    {value: 'SLO Brownfield', viewValue: 'SLO Brownfield'},
    {value: 'Pure Brownfield', viewValue: 'Pure Brownfield'},
  ];
  sourceSystemList = [
    {value: '4.6C', viewValue: '4.6C'},
    {value: '4.7', viewValue: '4.7'},
    {value: 'ECC6.0EHP1', viewValue: 'ECC6.0EHP1'},
    {value: 'ECC6.0EHP2', viewValue: 'ECC6.0EHP2'},
    {value: 'ECC6.0EHP3', viewValue: 'ECC6.0EHP3'},
    {value: 'ECC6.0EHP4', viewValue: 'ECC6.0EHP4'},
    {value: 'ECC6.0EHP5', viewValue: 'ECC6.0EHP5'},
    {value: 'ECC6.0EHP6', viewValue: 'ECC6.0EHP6'},
    {value: 'ECC6.0EHP7', viewValue: 'ECC6.0EHP7'},
    {value: 'ECC6.0EHP8', viewValue: 'ECC6.0EHP8'},
    {value: 'S/4HANA1503', viewValue: 'S/4HANA1503'},
    {value: 'S/4HANA1511', viewValue: 'S/4HANA1511'},
    {value: 'S/4HANA1610', viewValue: 'S/4HANA1610'},
    {value: 'S/4HANA1709', viewValue: 'S/4HANA1709'},
    {value: 'S/4HANA1809', viewValue: 'S/4HANA1809'},
    {value: 'S/4HANA1909', viewValue: 'S/4HANA1909'},
    {value: 'BW 3.x', viewValue: 'BW 3.x'},
    {value: 'BW 7.3', viewValue: 'BW 7.3'},
    {value: 'BW 7.4', viewValue: 'BW 7.4'},
    {value: 'BW 7.5', viewValue: 'BW 7.5'},
    {value: 'B4HANA', viewValue: 'B4HANA'},
  ];
  targetSystemList = [
    {value: 'S/4HANA1503', viewValue: 'S/4HANA1503'},
    {value: 'S/4HANA1511', viewValue: 'S/4HANA1511'},
    {value: 'S/4HANA1610', viewValue: 'S/4HANA1610'},
    {value: 'S/4HANA1709', viewValue: 'S/4HANA1709'},
    {value: 'S/4HANA1809', viewValue: 'S/4HANA1809'},
    {value: 'S/4HANA1909', viewValue: 'S/4HANA1909'},
    {value: 'S/4HANA2020', viewValue: 'S/4HANA2020'},
    {value: 'BW 3.x', viewValue: 'BW 3.x'},
    {value: 'BW 7.3', viewValue: 'BW 7.3'},
    {value: 'BW 7.4', viewValue: 'BW 7.4'},
    {value: 'BW 7.5', viewValue: 'BW 7.5'},
    {value: 'B4HANA', viewValue: 'B4HANA'},
    {value: 'S/4HANA Cloud(MT)', viewValue: 'S/4HANA Cloud(MT)'},
    {value: 'S/4HANA Cloud-ST', viewValue: 'S/4HANA Cloud-ST'},
  ];

  get clientName() {
    return this.projectCreationForm.get('clientName');
  }
  get marketUnit() {
    return this.projectCreationForm.get('marketUnit');
  }
  get sourceSystem() {
    return this.projectCreationForm.get('sourceSystem');
  }
  get targetSystem() {
    return this.projectCreationForm.get('targetSystem');
  }
  get onshoreClient() {
    return this.projectCreationForm.get('onshoreClient');
  }
  get offshoreClient() {
    return this.projectCreationForm.get('offshoreClient');
  }
  get smartFieldUsecase() {
    return this.projectCreationForm.get('smartFieldUsecase');
  }
  get industry() {
    return this.projectCreationForm.get('industry');
  }
  get userEmailId() {
    return this.projectCreationForm.get('userEmailId');
  }
    constructor(private fb: FormBuilder, private projectService: ProjectService, private route: ActivatedRoute,
      private router: Router, private loginService: LoginService) { }

  ngOnInit(): void {


  }

  onSubmitProjectForm() {
    this.projectService.addProject(this.projectCreationForm.value).subscribe(res => {
      if (res) {
        let response;
        response = res;
        console.log(response);
        this.router.navigateByUrl('/', {skipLocationChange: true}).then(() =>
        this.router.navigate(['project-plan/' + response.projectId]));
        this.showNotification('top', 'center', 'success');
      }
    }, err => {
      console.log(err.status);
      if (err.status === 200) {
        // this.router.navigate(['']);
        this.showNotification('top', 'center', 'success');
      } else {
        this.showNotification('top', 'center', 'error');
      }
    });
  }

  showNotification(from, align, notificationType) {
    let showMessage: any;

    const color = Math.floor((Math.random() * 4) + 1);
    if (notificationType === 'success') {
      showMessage = 'Your Project is created successfully.';
    } else {
      showMessage = 'Your project could not created. Please try after sometime.';
    }

    $.notify({
        icon: 'notifications',
        message: showMessage

    }, {
        type: notificationType,
        timer: 3000,
        placement: {
            from: from,
            align: align
        },
        template: '<div data-notify="container" class="col-xl-4 col-lg-4 col-11 col-sm-4 col-md-4 alert alert-{0} alert-with-icon" role="alert">' +
          '<button mat-button  type="button" aria-hidden="true" class="close mat-button" data-notify="dismiss">  <i class="material-icons">close</i></button>' +
          '<i class="material-icons" data-notify="icon">notifications</i> ' +
          '<span data-notify="title">{1}</span> ' +
          '<span data-notify="message">{2}</span>' +
          '<div class="progress" data-notify="progressbar">' +
            '<div class="progress-bar progress-bar-{0}" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%;"></div>' +
          '</div>' +
          '<a href="{3}" target="{4}" data-notify="url"></a>' +
        '</div>'
    });
}
}
