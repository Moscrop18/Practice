import { Component, OnInit } from '@angular/core';
import { of } from 'rxjs';
import { ViewEncapsulation } from '@angular/core';
import { NgWizardConfig, NgWizardService, StepChangedArgs, StepValidationArgs, STEP_STATE, THEME, TOOLBAR_POSITION } from 'ng-wizard';

@Component({
  selector: 'app-manage-activities',
  templateUrl: './manage-activities.component.html',
  styleUrls: ['./manage-activities.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ManageActivitiesComponent implements OnInit {
  dataSource: any;
  projectId: any;
  displayedColumns: string[] = ['activityName', 'responsibleTeamName', 'plannedStartDate', 'plannedEndDate', 'actualStartDate', 'actualEndDate', 'completionStatus', 'overallStatus', 'comments', 'edit'];

  // Journey Points
  stepStates = {
    normal: STEP_STATE.normal,
    disabled: STEP_STATE.disabled,
    error: STEP_STATE.error,
    hidden: STEP_STATE.hidden
  };
  config: NgWizardConfig = {
    // selected: 0,
    theme: THEME.arrows,
    toolbarSettings: {
      toolbarPosition: TOOLBAR_POSITION.none
    },
    anchorSettings: {
      anchorClickable: true, enableAllAnchors: true, markDoneStep: false, markAllPreviousStepsAsDone: true,
      removeDoneStepOnNavigateBack: false, enableAnchorOnDoneStep: true
    }
  };
  isValidTypeBoolean = true;
  constructor(private ngWizardService: NgWizardService) { }

  ngOnInit() {
  }

  showPreviousStep(event?: Event) {
    this.ngWizardService.previous();
  }
  showNextStep(event?: Event) {
    this.ngWizardService.next();
  }
  resetWizard(event?: Event) {
    this.ngWizardService.reset();
  }
  setTheme(theme: THEME) {
    this.ngWizardService.theme(theme);
  }
  stepChanged(args: StepChangedArgs) {
    this.isValidTypeBoolean = false;
    this.config.selected = args.step.index;
    this.isValidTypeBoolean = true;
  }
  isValidFunctionReturnsBoolean(args: StepValidationArgs) {
    return true;
  }
  isValidFunctionReturnsObservable(args: StepValidationArgs) {
    return of(true);
  }


}
