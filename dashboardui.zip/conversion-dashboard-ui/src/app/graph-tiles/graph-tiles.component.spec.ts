import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GraphTilesComponent } from './graph-tiles.component';

describe('GraphTilesComponent', () => {
  let component: GraphTilesComponent;
  let fixture: ComponentFixture<GraphTilesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GraphTilesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GraphTilesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
