import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { environment } from 'environments/environment';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import {ConfigService} from '../config/config.service';

const API_URL = environment.urlEndpoint;

@Injectable({
  providedIn: 'root'
})
export class RetrofitService {

  constructor(private http: HttpClient, public config: ConfigService) { }

  getDualMaintainenceData() {
    return this.http.get(API_URL + 'dual-maintenance/api/getkpisdata' , this.config.httpOptions);
  }

  addPhaseFile(transportFile): Observable<{}> {
    const HttpUploadOptions = {
      headers: new HttpHeaders({ 'Accept': 'application/json' })
    }
    const formData = new FormData();
    formData.append('file', transportFile);
    return this.http.post(API_URL + 'dual-maintenance/api/uploadFile', formData, HttpUploadOptions);
  }

  getDualMaintainenceReport() {
    return this.http.get(API_URL + 'dual-maintenance/api/getCurrentPhaseDetails' , this.config.httpOptions);
  }
}
