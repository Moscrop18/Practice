import { TestBed } from '@angular/core/testing';

import { RetrofitService } from './retrofit.service';

describe('RetrofitService', () => {
  let service: RetrofitService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RetrofitService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
