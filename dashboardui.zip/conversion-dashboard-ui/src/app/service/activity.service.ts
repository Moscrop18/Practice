import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { environment } from 'environments/environment';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import {ConfigService} from '../config/config.service';

const API_URL = environment.apiEndpoint;
const END_URL = environment.urlEndpoint

@Injectable({
  providedIn: 'root'
})
export class ActivityService {

  constructor(private http: HttpClient, public config: ConfigService) { }

  getDashboardChartData(projectId): Observable<{}> {
    return this.http.get(API_URL + 'assessment/chart/getActivities/' + projectId, this.config.httpOptions);
  }

  getResponsibleTeamList(): Observable<{}> {
    return this.http.get(API_URL + 'getResponsibleTeams', this.config.httpOptions);
  }

  getActivityList(phaseName): Observable<{}> {
    return this.http.get(API_URL + 'getActivityPhases/' + phaseName, this.config.httpOptions);
  }

  getAllAssessments(phase, task, projectId): Observable<{}> {
    return this.http.get(API_URL + 'assessment/getClientActivities/' + phase + '/' + task + '/' + projectId, this.config.httpOptions);
  }

  addActivity(activityDetails): Observable<{}> {
    return this.http.post(API_URL + 'assessment/saveClientActivities ', activityDetails, this.config.httpOptions);
  }

  addOtherActivity(activityDetails): Observable<{}> {
    return this.http.post(API_URL + 'saveActivity/Others ', activityDetails, this.config.httpOptions);
  }

  addOtherResponseTeam(resTeamDetails): Observable<{}> {
    return this.http.post(API_URL + 'saveResponsibleTeam/Others ', resTeamDetails, this.config.httpOptions);
  }

  deleteActivity(activityId): Observable<{}> {
    return this.http.delete(API_URL + 'assessment/deleteClientActivities/' + activityId, this.config.httpOptions);
  }

  updateActivity(activityId, activityDetails): Observable<{}> {
    return this.http.put(API_URL + 'assessment/updateClientActivities/' + activityId, activityDetails , this.config.httpOptions);
  }

  updateActualStartDate(activityId, projectId): Observable<{}> {
    return this.http.put(API_URL + 'assessment/updateStartActualDate/' + activityId + '/' + projectId, '{}' , this.config.httpOptions);
  }
}
