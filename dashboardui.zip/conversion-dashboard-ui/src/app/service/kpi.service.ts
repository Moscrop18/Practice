import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { environment } from 'environments/environment';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import {ConfigService} from '../config/config.service';

const API_URL = environment.kpiEndpoint;

@Injectable({
  providedIn: 'root'
})
export class KpiService {

  constructor(private http: HttpClient, public config: ConfigService) { }

  getKpiTilesData(projectId): Observable<{}> {
    return this.http.get(API_URL + 'tiles/' + projectId , this.config.httpOptions);
  }

  getKpiGraphData(projectId, type): Observable<{}> {
    return this.http.get(API_URL + type + '/' + projectId , this.config.httpOptions);
  }
}
