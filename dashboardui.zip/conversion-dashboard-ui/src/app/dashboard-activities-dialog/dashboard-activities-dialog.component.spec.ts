import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardActivitiesDialogComponent } from './dashboard-activities-dialog.component';

describe('DashboardActivitiesDialogComponent', () => {
  let component: DashboardActivitiesDialogComponent;
  let fixture: ComponentFixture<DashboardActivitiesDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DashboardActivitiesDialogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardActivitiesDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
