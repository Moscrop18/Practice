import { Component, OnInit, Inject } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ActivityService } from '../service/activity.service';
import * as Highcharts from 'highcharts/highcharts-gantt';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  projectId: any;
  dataSource: any;
  defined = Highcharts.defined;
  isObject = Highcharts.isObject;
  showElement: any;
  width: any;
  height: any;
  Highcharts: typeof Highcharts = Highcharts;
  chartOptions: Highcharts.Options = {};

  constructor(private activatedRoute: ActivatedRoute, private activityService: ActivityService) { }

  ngOnInit() {
    if (this.activatedRoute.snapshot['_urlSegment'] && this.activatedRoute.snapshot['_urlSegment']['segments'] &&
    this.activatedRoute.snapshot['_urlSegment']['segments'][1]) {
      this.projectId = this.activatedRoute.snapshot['_urlSegment']['segments'][1].path;
      this.getChartData(this.projectId);
    }
  }

  getChartData(projectId) {
    this.activityService.getDashboardChartData(projectId).subscribe(res => {
      if (res) {
        console.log(res);
        this.dataSource = res;
        if (this.dataSource && this.dataSource !== '') {
            this.chartOptions = {
                title: {
                  text: 'Activity Plan'
                },
                yAxis: {
                  uniqueNames: true
                },
                chart: {
                    width: 1000,
                    height: 474
                },
                navigator: {
                    enabled: true,
                    series: {
                        type: 'gantt',
                        pointPadding: 0.25
                    },
                    yAxis: {
                        min: 0,
                        max: 3,
                        reversed: true,
                        categories: []
                    }
                },
                scrollbar: {
                    enabled: true
                },
                rangeSelector: {
                    enabled: true,
                    selected: 0
                },
                series: [
                    {
                    type: 'gantt',
                    name: 'Assessment',
                    data: this.dataSource
                    }
                ],
                tooltip: {
                pointFormatter: function () {
                    const point: any = this,
                        format = '%e. %b',
                        options = point.options,
                        completed = options.completed,
                        amount = Highcharts.isObject(completed) ? completed.amount : completed,
                        status = ((amount || 0) * 100) + '%',
                        resTeam = point.custom.resTeam,
                        // lines;
                        lines = [{
                            value: point.name,
                            style: 'font-weight: bold;'
                        }, {
                            title: 'Start',
                            value: Highcharts.dateFormat(format, point.start)
                        }, {
                            visible: !options.milestone,
                            title: 'End',
                            value: Highcharts.dateFormat(format, point.end)
                        }, {
                            title: 'Completed',
                            value: status
                        }, {
                            title: 'Comment',
                            value: options.description || 'N/A'
                        }, {
                        title: 'Responsible Team',
                        value: options.custom.resTeam
                    }
                        ];
                    return lines.reduce(function (str, line) {
                        let s = '';
                          const  style = (
                            Highcharts.defined(line.style) ? line.style : 'font-size: 0.8em;'
                            );
                        if (line.visible !== false) {
                            s = (
                                '<span style="' + style + '">' +
                                (Highcharts.defined(line.title) ? line.title + ': ' : '') +
                                (Highcharts.defined(line.value) ? line.value : '') +
                                '</span><br/>'
                            );
                        }
                        return str + s;
                    }, '');
                }
                },
            };
        }
      }
    }, err => {
      console.log(err.status);
    });
  }

}

