import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GraphsRetrofitComponent } from './graphs-retrofit.component';

describe('GraphsRetrofitComponent', () => {
  let component: GraphsRetrofitComponent;
  let fixture: ComponentFixture<GraphsRetrofitComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GraphsRetrofitComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GraphsRetrofitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
