import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-graphs-retrofit',
  templateUrl: './graphs-retrofit.component.html',
  styleUrls: ['./graphs-retrofit.component.css']
})
export class GraphsRetrofitComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
