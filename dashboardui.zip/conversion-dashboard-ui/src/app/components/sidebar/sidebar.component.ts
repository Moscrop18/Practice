import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

declare const $: any;
declare interface RouteInfo {
    path: string;
    title: string;
    icon: string;
    class: string;
}

export const ROUTES: RouteInfo[] = [
    { path: '/dashboard/', title: 'Dashboard',  icon: 'dashboard', class: '' },
    { path: '/manage-activities/', title: 'Manage Activities',  icon: 'content_paste', class: '' },
    { path: '/project-info/', title: 'Project Info',  icon: 'library_books', class: '' },
    { path: '/graph-tiles/', title: 'Assessment Dashboard',  icon: 'bubble_chart', class: '' },
    // { path: '/icons', title: 'Project Plan',  icon: 'bubble_chart', class: '' },
    // { path: '/user-profile', title: 'User Profile',  icon: 'person', class: '' },
    // { path: '/table-list', title: 'Table List',  icon: 'content_paste', class: '' },
    // { path: '/typography', title: 'Typography',  icon: 'library_books', class: '' },
    // { path: '/maps', title: 'Maps',  icon: 'location_on', class: '' },
    // { path: '/notifications', title: 'Notifications',  icon: 'notifications', class: '' },
    // { path: '/icons', title: 'Project Plan',  icon: 'bubble_chart', class: '' },
];

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
  menuItems: any[];
  projectId: any;
  constructor(private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    if (this.activatedRoute.snapshot['_urlSegment'] && this.activatedRoute.snapshot['_urlSegment']['segments'] &&
    this.activatedRoute.snapshot['_urlSegment']['segments'][1]) {
      this.projectId = this.activatedRoute.snapshot['_urlSegment']['segments'][1].path;
    }

    if (this.projectId) {
      this.menuItems = ROUTES.filter(menuItem => menuItem);
    }
  }
  isMobileMenu() {
      if ($(window).width() > 991) {
          return false;
      }
      return true;
  };
}
