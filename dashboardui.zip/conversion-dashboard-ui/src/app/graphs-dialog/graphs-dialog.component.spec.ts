import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GraphsDialogComponent } from './graphs-dialog.component';

describe('GraphsDialogComponent', () => {
  let component: GraphsDialogComponent;
  let fixture: ComponentFixture<GraphsDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GraphsDialogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GraphsDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
