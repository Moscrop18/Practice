import { Component, OnInit, Inject, ViewEncapsulation, ViewChild } from '@angular/core';
import { KpiService } from '../service/kpi.service';
import {MatDialog, MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import { SwiperComponent } from 'swiper/angular';
import SwiperCore, { Navigation } from 'swiper/core';
SwiperCore.use([Navigation]);
import * as Highcharts from 'highcharts/highcharts.src';
import highcharts3D from 'highcharts/highcharts-3d.src';
highcharts3D(Highcharts);


@Component({
  selector: 'app-graphs-dialog',
  templateUrl: './graphs-dialog.component.html',
  styleUrls: ['./graphs-dialog.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class GraphsDialogComponent implements OnInit {
  projectId: any;
  dialogData: any;
  kpiType: any;
  showSpinner = false;
  showImpactL2Drilldown = false;
  showImpactL2aDrilldown = false;
  showImpactL2bDrilldown = false;
  showImpactL3Drilldown = false;
  showImpactL3aDrilldown = false;
  showImpactL3bDrilldown = false;
  showImpactL3cDrilldown = false;
  Highcharts: typeof Highcharts = Highcharts;
  chartOptions: Highcharts.Options = {}
  chartOptions2: Highcharts.Options = {}
  chartOptions3: Highcharts.Options = {}
  cloneChartOption1: Highcharts.Options = {}
  cloneChartOption2: Highcharts.Options = {}
  impactChartOptions1L2: Highcharts.Options = {}
  impactChartOptions2L2: Highcharts.Options = {}
  impactChartOptions1L2a: Highcharts.Options = {}
  impactChartOptions2L2a: Highcharts.Options = {}
  impactChartOptions3L2: Highcharts.Options = {}
  impactChartOptions4L2: Highcharts.Options = {}
  impactChartOptions5L2: Highcharts.Options = {}
  impactChartOptions1L3: Highcharts.Options = {}
  impactChartOptions2L3: Highcharts.Options = {}
  impactChartOptions3L3: Highcharts.Options = {}
  impactChartOptions4L3: Highcharts.Options = {}
  reqId = '97' // Needs to be dynamic from backend



  constructor(private kpiService: KpiService, @Inject(MAT_DIALOG_DATA) public data: any,
   public dialogRef: MatDialogRef<GraphsDialogComponent>) { }

  ngOnInit(): void {
    this.projectId = this.data.projectId;
    if (this.data && this.data.rowData && this.data.rowData !== '') {
      if (this.data.tileType === 'CV') {
        this.getNonDrilldownData(this.data.rowData);
      }
      if (this.data.tileType === 'CI') {
        this.getCIData(this.data.rowData);
      }

      if (this.data.tileType === 'security') {
        this.getNonDrilldownData(this.data.rowData);
      }

      if (this.data.tileType === 'TS') {
        this.getTSData(this.data.rowData);
      }
    }
  }

  getNonDrilldownData(type) {
    this.kpiService.getKpiGraphData(this.reqId, type).subscribe(res => {
      if (res) {
        this.dialogData = res;
        if (type === 'clone') {
          this.cloneChartOption1 = this.groupedColumn('total clone', res['total_clone'], true);
          this.cloneChartOption2 = this.groupedColumn('clone object counts based on creation year', res['clone_object_counts_based_on_creation_year'], true);
        } else {
          this.chartOptions = this.groupedColumn(type, res, true);
        }
      }
    }, err => {
      console.log(err.status);
    });
  }

  getCIData(type) {
    if (type === 'impacted') {
      type = 'impact'
      this.kpiService.getKpiGraphData(this.reqId, type).subscribe(res => {
        let responseData: any
        responseData = res
        if (responseData.impact_objects) {
          this.dialogData = responseData;
              this.chartOptions = this.pieChart('TOTAL IMPACTED', responseData.impact_objects.total_impacted);
              this.chartOptions2 = this.pieChart('USED IMPACTED', responseData.impact_objects.total_used_impacted);
        }
      }, err => {
        console.log(err.status);
      });
    }

    if (type === 'impactclone') {
      this.kpiService.getKpiGraphData(this.reqId, type).subscribe(res => {
        let responseData: any
        responseData = res
        if (responseData) {
          this.dialogData = responseData;
          this.chartOptions = this.groupedColumn('IMPACTED CLONE', responseData, true);
        }
      }, err => {
        console.log(err.status);
      });
    }
  }

  getTSData(type) {
    let subUrl;
    if (type === 'testingScopeOverview') {
      subUrl = 'impacted/irpa';
      this.kpiService.getKpiGraphData(this.reqId, subUrl).subscribe(res => {
        let responseData: any
        responseData = res
        if (responseData) {
          this.dialogData = responseData;
          this.chartOptions = this.pieChart('Distinct Business Scenarios', responseData.impacted);
          this.chartOptions2 = this.pieChart('Distinct Business Scenarios w.r.t Most Used Transactions', responseData.impactedMostUsed);
        }
      }, err => {
        console.log(err.status);
      });
    }
    if (type === 'testingScopeScenarios') {
      subUrl = 'module/irpa';
      this.kpiService.getKpiGraphData(this.reqId, subUrl).subscribe(res => {
        let responseData: any
        responseData = res
        if (responseData) {
          this.dialogData = responseData;
          this.chartOptions = this.groupedColumn('Overview of Impacted Business Scenario for Test', responseData, true);
        }
      }, err => {
        console.log(err.status);
      });
    }
  }

  onTSPointSelect(e) {
    this.kpiService.getKpiGraphData(this.reqId, 'process/irpa/' + e.point.category).subscribe(res => {
      let responseData: any
        responseData = res
      if (res) {
        this.showImpactL2bDrilldown = true;
        this.dialogData = res;
        this.chartOptions = this.groupedColumn('Distinct Business Scenarios', responseData.process, false);
        this.chartOptions2 = this.groupedColumn('Sub-process by availability of test scripts',
         responseData.testScriptsAvail, false);
        this.chartOptions3 = this.groupedColumn('Sub-process by test scripts that need modifications',
         responseData.testScriptsUpdate, false);
      }
    }, err => {
      console.log(err.status);
    });
  }

  showImpactL1 () {
    this.showImpactL2Drilldown = false;
    this.showImpactL2aDrilldown = false;
    this.showImpactL2bDrilldown = false;
    this.showImpactL3Drilldown = false;
    this.showImpactL3aDrilldown = false;
    this.showImpactL3bDrilldown = false;
    this.showImpactL3cDrilldown = false;
  }

  showTSL1 () {
    this.showImpactL2Drilldown = false;
    this.showImpactL2aDrilldown = false;
    this.showImpactL2bDrilldown = false;
   const subUrl = 'module/irpa';
    this.kpiService.getKpiGraphData(this.reqId, subUrl).subscribe(res => {
      let responseData: any
      responseData = res
      if (responseData) {
        this.dialogData = responseData;
        this.chartOptions = this.groupedColumn('Overview of Impacted Business Scenario for Test', responseData, true);
      }
    }, err => {
      console.log(err.status);
    });
  }

  showImpactL2 () {
    this.showImpactL3Drilldown = false;
    this.showImpactL3aDrilldown = false;
    this.showImpactL3bDrilldown = false;
    this.showImpactL3cDrilldown = false;
    this.showImpactL2Drilldown = true;
  }

  onPointSelect (e) {
    if ((e.point.custom === 'total_impacted') && (e.point.name === 'HANA DB Coding Compliance')) {
      this.impactChartOptions1L2 = this.groupedColumn('MANDATORY REMEDIATION',
      this.dialogData.impact_objects.total_impact_mandatory_remediation, false, []);
      // Currently not in use.
      // this.impactChartOptions2L2 = this.groupedColumn('MANDATORY USED',
      //  this.dialogData.impact_objects.total_impact_mandatory_used, []
      // );
      this.impactChartOptions3L2 = this.groupedColumn('APP-LEVEL OPTIMIZATION',
      this.dialogData.impact_objects.total_impact_app_level_optimization, false, []
      );
      this.impactChartOptions4L2 = this.groupedColumn('HANA-LEVEL OPTIMIZATION',
        this.dialogData.impact_objects.total_impact_hana_level_optimization, false, []
      );
      this.impactChartOptions5L2 = this.groupedColumn('HANA HOUSEKEEPING',
      this.dialogData.impact_objects.total_impact_hana_housekeeping, false, []
      );
      this.showImpactL2Drilldown = true;
    }

    if ((e.point.custom === 'total_impacted') && (e.point.name === 'S/4 HANA Simplification Adoption')) {
      this.impactChartOptions1L2a = this.groupedColumn('MANDATORY REMEDIATION',
      this.dialogData.impact_objects.s4_mandatory_complexity_rem, false, []);
      this.impactChartOptions2L2a = this.groupedColumn('OPTIONAL REMEDIATION',
       this.dialogData.impact_objects.s4_optional_complexity_rem, false, []);
      this.showImpactL2aDrilldown = true;
    }
  }

  onGraphSelect (type) {
    switch (type) {
      case 'manRem': {
        this.impactChartOptions1L3 = this.groupedColumn('MANDATORY CORRECTIONS BY AUTOMATION TYPES',
        this.dialogData.impact_objects.mandatory_corrections_by_automation_types, true);
        this.showImpactL2Drilldown = false;
        this.showImpactL3Drilldown = true;
         break;
      }
      case 'hanaHouseKeepingCorr': {
        this.impactChartOptions2L3 = this.groupedColumn('HOUSEKEEPING FOR HANA',
        this.dialogData.impact_objects.hana_housekeeping_corrections, true);
        this.showImpactL2Drilldown = false;
        this.showImpactL3aDrilldown = true;
         break;
      }
      case 'appLevelOp': {
        this.impactChartOptions3L3 = this.groupedColumn('APPLICATION LEVEL OPTIMIZATION',
        this.dialogData.impact_objects.app_level_corrections, true);
        this.showImpactL2Drilldown = false;
        this.showImpactL3bDrilldown = true;
         break;
      }
      case 'hanaLevelOp': {
        this.impactChartOptions4L3 = this.groupedColumn('DB HANA LEVEL OPTIMIZATION',
        this.dialogData.impact_objects.db_level_correction, true);
        this.showImpactL2Drilldown = false;
        this.showImpactL3cDrilldown = true;
         break;
      }
      default: {
         break;
      }
   }
  }

  groupedColumn(titleText, seriesObj, showXAxisLabel, cat?) {
    return {
      chart: {
        type: (titleText === 'clone object counts based on creation year') ? 'bar' : 'column',
        options3d: {
            enabled: true,
            alpha: 0,
            beta: 0,
            viewDistance: 25,
            depth: 20
        }
    },
    title: {
        text: titleText.toUpperCase()
    },
    xAxis: {
      gridLineColor: 'transparent',
      categories: seriesObj.categories ? seriesObj.categories : cat ,
      labels: {
        enabled: showXAxisLabel
      }
    },
    yAxis: {
        // gridLineColor: 'transparent',
        allowDecimals: false,
        min: 0,
        title: {
            text: 'Values',
            skew3d: true
        },
    },
    tooltip: {
        enabled: false,
        // crosshairs: true,
        headerFormat: '<b>{point.key}</b><br>',
        pointFormat: '<span style="color:{series.color}">\u25CF</span> {series.name}: {point.y} / {point.stackTotal}'
    },
    plotOptions: {
      series: {
          dataLabels: {
          enabled: true
                     },
        cursor: 'pointer',
      },
        column: {
            depth: 25
        },
        bar: {
          grouping: false,
        }
    },
    series: seriesObj.series ? seriesObj.series : seriesObj
    }
  }

  pieChart(textValue, dataArray): any {
    return {
      chart: {
        type: 'pie',
        options3d: {
            enabled: true,
            alpha: 45,
            beta: 0
        }
    },
    title: {
        text: textValue
    },
    accessibility: {
        point: {
            valueSuffix: '%'
        }
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            depth: 35,
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b>: {point.y} '
            }
        }
    },
    series: [{
        type: 'pie',
        name: textValue,
        data: dataArray
    }]
    }
  }
}
