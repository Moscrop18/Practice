import {OnInit, Component, ViewChild, ElementRef} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatTableDataSource} from '@angular/material/table';
import { RetrofitService } from '../service/retrofit.service';
import { Router, ActivatedRoute } from '@angular/router';
import {MatDialog, MAT_DIALOG_DATA} from '@angular/material/dialog';
import {DashboardActivitiesDialogComponent} from '../dashboard-activities-dialog/dashboard-activities-dialog.component';
import { ActivityService } from '../service/activity.service';
import * as Highcharts from 'highcharts';
// import highcharts3D from 'highcharts/highcharts-3d.src';
// highcharts3D(Highcharts);
import * as Highcharts1 from 'highcharts';
import Drilldown from 'highcharts/modules/drilldown';
Drilldown(Highcharts);
import Exporting from 'highcharts/modules/exporting';
Exporting(Highcharts);
declare var $: any;


@Component({
  selector: 'app-scale-retrofit-activities',
  templateUrl: './scale-retrofit-activities.component.html',
  styleUrls: ['./scale-retrofit-activities.component.css']
})
export class ScaleRetrofitActivitiesComponent implements OnInit {
  phaseName: any;
  allPhaseDataList: any;
  selectedFile: any;
  overallStatus: any;
  flag: Boolean;
  color: any;
  Highcharts: typeof Highcharts = Highcharts;
  chartOptions: Highcharts.Options = {}
  @ViewChild('fileInput') fileInput: ElementRef;
  fileAttr: any ;
  otherPhaseName: any;
  displayedColumns: string[] = ['activityName', 'responsibleTeamName', 'plannedStartDate', 'plannedEndDate', 'actualStartDate', 'actualEndDate', 'completionStatus', 'overallStatus', 'edit', 'delete'];
  reportDisplayedColumns: string[] = ['retrofitPhase', 'retrofitTransportRequest', 'transportType', 'status', 'completionPerc'];
  phaseList = [
    {value: '1', viewValue: 'Phase 1'},
    {value: '2', viewValue: 'Phase 2'},
    {value: '3', viewValue: 'Phase 3'},
    {value: '4', viewValue: 'Phase 4'},
    {value: '5', viewValue: 'Phase 5'},
    {value: '6', viewValue: 'Phase 6'},
    {value: '7', viewValue: 'Phase 7'},
    {value: '8', viewValue: 'Phase 8'},
    {value: '9', viewValue: 'Phase 9'},
    {value: '10', viewValue: 'Phase 10'},
    {value: 'Other', viewValue: 'Other'},
  ];
  reportDataSource: any;
  dataSource: any;
  graphData: any;
  projectId: any;
  constructor(private retrofitService: RetrofitService, private activatedRoute: ActivatedRoute,
    public dialog: MatDialog, private activityService: ActivityService) { }

  ngOnInit(): void {
    if (this.activatedRoute.snapshot['_urlSegment'] && this.activatedRoute.snapshot['_urlSegment']['segments'] &&
    this.activatedRoute.snapshot['_urlSegment']['segments'][1]) {
      this.projectId = this.activatedRoute.snapshot['_urlSegment']['segments'][1].path;
      if (this.projectId) {
        this.getActivityList(this.projectId);

      }
    }
    // this.getKpiData();
  }

  openTaskDialog(rowData) {
    const dialogRef = this.dialog.open(DashboardActivitiesDialogComponent, {
      width: '1000px',
      data: {
        rowData: rowData,
        projectId: this.projectId,
        phase: 'scale',
        taskName: 'dualMaintenance'
      },
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('Dialog result: ${result}');
      this.getActivityList(this.projectId);
    });
  }

  deleteTask(rowData) {
    if (rowData.id) {
      this.activityService.deleteActivity(rowData.id).subscribe(res => {
        console.log(res);
        if (res) {
          this.getActivityList(this.projectId);
          this.showNotification('top', 'center', 'success', 'Activity is deleted successfully.');
        }
      }, err => {
        console.log(err.status);
        if (err.status === 200) {
          this.getActivityList(this.projectId);
          this.showNotification('top', 'center', 'success', 'Activity is deleted successfully.');
        } else {
          this.showNotification('top', 'center', 'error', 'Activity could not be deleted. Please try again later');
        }
      });
    }
  }

  getActivityList(projectId) {
    this.activityService.getAllAssessments('scale', 'dualMaintenance', projectId).subscribe(res => {
      if (res) {
        console.log(res);
        this.dataSource = res;
      }
    }, err => {
      console.log(err.status);
    });
  }
  getoverallStatus(element) {
    const p_start_date = new Date(element.plannedStartDate);
    const p_end_date   = new Date(element.plannedEndDate);
    const a_start_date = new Date(element.actualStartDate);
    const a_end_date   = new Date(element.actualEndDate);

   if (p_start_date < a_start_date || p_end_date < a_end_date ) {
     this.overallStatus = 'Delayed';
   } else {
    this.overallStatus = '';
   }

   return this.overallStatus;
 }

 getOverallStatusColor(element) {
   this.color = 'yellow';
   const p_start_date = new Date(element.plannedStartDate);
    const p_end_date   = new Date(element.plannedEndDate);
    const a_start_date = new Date(element.actualStartDate);
    const a_end_date   = new Date(element.actualEndDate);

    if (p_start_date < a_start_date && p_end_date >= a_end_date) {
     this.color = 'orange';
     return this.color;
   }

  if (p_start_date <= a_start_date && p_end_date < a_end_date) {
    this.color = 'red';
    return this.color;
  } else {
   this.color = 'yellow';
   return this.color;
   }
 }

  groupedColumn(res): any {
    this.chartOptions = {
      chart: {
        type: 'column',
        width: 1000,
        height: 300,
        options3d: {
          enabled: true,
          alpha: 0,
          beta: 0,
          viewDistance: 25,
          depth: 20
        },
        events: {
          drilldown(e) {
            // this.chartOptions.setTitle({ text: e.seriesOptions.name });
          },
          drillup(f) {
            // this.chartOptions.setTitle({ text: f.seriesOptions.name });
          }
        },
      },
      title: {
        text: 'Retrofit Transport phasewise overview'
      },
      xAxis: {
        type: 'category'
      },
      yAxis: [{
        title: {
          text: ''
        }
      }],

      legend: {
        enabled: false
      },

      plotOptions: {
        series: {
          borderWidth: 0,
          dataLabels: {
            enabled: true,
          }
        },
      },

      series: res.series,
      drilldown: res.drilldown
    }
  }

  getKpiData() {
    this.retrofitService.getDualMaintainenceData().subscribe(res => {
      if (res) {
        this.graphData = res;
         this.groupedColumn(this.graphData);
      }
    }, err => {
      console.log(err.status);
    });
  }

  uploadFileEvt(file: any) {
    this.selectedFile = file.target.files[0];
    console.log(file.target.files[0]);
    if (file.target.files && file.target.files[0]) {
      this.fileAttr = '';
      Array.from(file.target.files).forEach((files: File) => {
        this.fileAttr += files.name;
      });
      this.fileInput.nativeElement.value = '';
    } else {
      this.fileAttr = 'Choose File';
    }
  }

  onSubmit() {
    if (this.phaseName === 'Other' && !this.otherPhaseName) {
      return false;
    } else {
      this.retrofitService.addPhaseFile(this.selectedFile).subscribe(res => {
        // this.getReportData();
        this.phaseName = '';
        this.otherPhaseName = '';
        this.selectedFile = '';
        this.fileAttr = '';
        this.showNotification('top', 'center', 'success', 'File is uploaded successfully. Click on Launch button to proceed with the remediation.');
      }, err => {
        console.log(err.status);
        this.showNotification('top', 'center', 'error', 'File could not be uploaded successfully. Please try again.')
      });

    }
  }

  showNotification(from, align, notificationType, showMessage) {
    const type = ['error', 'info', 'success', 'warning', 'danger'];


    $.notify({
        icon: 'notifications',
        message: showMessage

    }, {
        type: notificationType,
        timer: 3000,
        placement: {
            from: from,
            align: align
        },
        template: '<div data-notify="container" class="col-xl-4 col-lg-4 col-11 col-sm-4 col-md-4 alert alert-{0} alert-with-icon" role="alert">' +
          '<button mat-button  type="button" aria-hidden="true" class="close mat-button" data-notify="dismiss">  <i class="material-icons">close</i></button>' +
          '<span data-notify="title">{1}</span> ' +
          '<span data-notify="message">{2}</span>' +
          '<div class="progress" data-notify="progressbar">' +
            '<div class="progress-bar progress-bar-{0}" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%;"></div>' +
          '</div>' +
          '<a href="{3}" target="{4}" data-notify="url"></a>' +
        '</div>'
    });
  }

  getReportData(e) {
    if (e.index === 3) {
      this.reportDataSource = {};
      this.retrofitService.getDualMaintainenceReport().subscribe(res => {
      if (res) {
          this.reportDataSource = res;
        }
      }, err => {
        console.log(err.status);
      });
    }
    if (e.index === 1) {
      this.graphData = undefined;
      this.chartOptions = undefined;
      this.getKpiData();
    }
  }

  launchClicked() {
    this.activityService.updateActualStartDate(22, this.projectId).subscribe((res: any) => {
      if (res) {
        this.getActivityList(this.projectId);
        window.open('https://devptsaptechnology.accenture.com/sap/bc/gui/sap/its/webgui?%7eTRANSACTION=zauto_tool&sap-client=100&sap-language=EN#', '_blank');
      }
    }, (err => {
      if (err.status === 200) {
         this.getActivityList(this.projectId);
         window.open('https://devptsaptechnology.accenture.com/sap/bc/gui/sap/its/webgui?%7eTRANSACTION=zauto_tool&sap-client=100&sap-language=EN#', '_blank');
      }
    console.log(err + 'error in updating actual date');
    }));
  }
}
