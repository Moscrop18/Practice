import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DescribeActivitiesComponent } from './describe-activities.component';

describe('DescribeActivitiesComponent', () => {
  let component: DescribeActivitiesComponent;
  let fixture: ComponentFixture<DescribeActivitiesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DescribeActivitiesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DescribeActivitiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
