#!/usr/bin/env node

// todo export into a npm library

/**
 * This script is executed by the 'npm run report' step and augments the cucumber report
 * files of failed features with screenshots and snapshots. Mechanism was inspired by:
 * https://github.com/jcundill/cypress-cucumber-preprocessor/blob/master/fixJson.js
 * It also leverages the multiple-cucumber-html-reporter library to generate a HTML
 * report based on the augmented cucumber report files.
 */

const report = require('multiple-cucumber-html-reporter');
const fs = require('fs');
const path = require('path');
const chalk = require('chalk');

const args = process.argv;

const reportName = 'TSD UI Cucumber report';

// TODO make this dynamic
const metaData = {
  browser: {
    name: 'chrome'
  },
  device: 'Docker',
  platform: {
    name: 'linux',
    version: 'Debian 10'
  }
};
const cucumberJsonDir = './output/cucumber-json';
const cucumberReportFileMap = {};
const cucumberReportMap = {};
const htmlReportDir = './output/cucumber-html-report';
const videosDir = './output/e2e/videos';
const screenshotsDir = './output/e2e/screenshots';

addScreenshots();
generateReport();

function getCucumberReportMaps() {
  const files = fs.readdirSync(cucumberJsonDir).filter((file) => {
    return file.indexOf('.json') > -1;
  });
  files.forEach((file) => {
    const json = JSON.parse(fs.readFileSync(path.join(cucumberJsonDir, file)));
    if (!json[0]) {
      return;
    }
    const [feature] = json[0].uri.split('/').reverse();
    cucumberReportFileMap[feature] = file;
    cucumberReportMap[feature] = json;
  });
}

function getScenarioNameFromScreenshot(screenshot) {
  const index1 = screenshot.indexOf('--');
  let index2;
  if (screenshot.indexOf('(example') === -1) {
    // Normal end index of scenario in screenshot filename
    index2 = screenshot.indexOf('(failed)');
  } else {
    // End index of scenario if its from a failed BDD example
    index2 = screenshot.indexOf('(example');
  }
  return screenshot.substring(index1 + 2, index2).trim();
}

function getAllFiles(dir) {
  var results = [];
  var list = fs.readdirSync(dir);
  list.forEach(function (file) {
    file = dir + '/' + file;
    var stat = fs.statSync(file);
    if (stat && stat.isDirectory()) {
      /* Recurse into a subdirectory */
      results = results.concat(getAllFiles(file));
    } else {
      /* Is a file */
      results.push(file);
    }
  });
  return results;
}

function addScreenshots() {
  const cukeMap = {};
  const videosMap = {};
  const jsonNames = {};

  const jsonPath = path.join(__dirname, '..', cucumberJsonDir);
  const screenshotsPath = path.join(__dirname, '..', screenshotsDir);
  const videosPath = path.join(__dirname, '..', videosDir);
  const files = fs.readdirSync(jsonPath);
  let videos;
  if (fs.existsSync(videosPath)) {
    videos = getAllFiles(videosPath);
    videos.forEach((vid) => {
      const arr = vid.split('.');
      const featureName = `${arr[0]}.${arr[1]}`;
      videosMap[featureName] = vid;
    });
  }
  files.forEach((file) => {
    const json = JSON.parse(
      fs.readFileSync(path.join(jsonPath, file)).toString()
    );
    const feature = json[0].uri;
    jsonNames[feature] = file;
    cukeMap[feature] = json;
  });

  if (fs.existsSync(screenshotsPath)) {
    const screenshots = getAllFiles(screenshotsPath);
    screenshots.forEach((screenshotPath) => {
      const feature = path.basename(path.dirname(screenshotPath));
      const screenshot = path.basename(screenshotPath);
      const scenarioName = getScenarioNameFromScreenshot(screenshot);
      const myScenario = cukeMap[feature][0].elements.find(
        (e) =>
          e.name.replace(/['"<>]/g, '') === scenarioName.replace(/['"<>]/g, '')
      );
      let myStep = null;
      if (myScenario) {
        myStep = myScenario.steps.find(
          (step) => step.result.status !== 'passed'
        );
      } else {
        console.log(
          'could not load scenario for feature= ' +
            feature +
            ' scenarioName= ' +
            scenarioName
        );
      }
      const data = fs.readFileSync(screenshotPath);
      if (myStep && data) {
        const base64Image = Buffer.from(data, 'binary').toString('base64');
        myStep.embeddings = [];
        myStep.embeddings.push({ data: base64Image, mime_type: 'image/png' });
      }

      // find my video
      if (myStep && videosMap[feature]) {
        const videoPath = path.join(videosPath, videosMap[feature]);
        if (fs.existsSync(videoPath)) {
          const vidData = fs.readFileSync(videoPath).toString('base64');
          if (vidData) {
            const html = `<video controls width="500"><source type="video/mp4" src="data:video/mp4;base64,${vidData}"> </video>`;
            const encodedHtml = Buffer.from(html, 'binary').toString('base64');
            myStep.embeddings.push({
              data: encodedHtml,
              mime_type: 'text/html'
            });
          }
        }
      }
      // write me back out again
      fs.writeFileSync(
        path.join(jsonPath, jsonNames[feature]),
        JSON.stringify(cukeMap[feature], null, 2)
      );
    });
  }
}

function generateReport() {
  if (!fs.existsSync(cucumberJsonDir)) {
    console.warn(
      chalk.yellow(
        `WARNING: Folder './${cucumberJsonDir}' not found. REPORT CANNOT BE CREATED!`
      )
    );
  } else {
    report.generate({
      jsonDir: cucumberJsonDir,
      reportPath: htmlReportDir,
      displayDuration: true,
      displayReportTime: true,
      pageTitle: reportName,
      reportName: reportName + `: ${new Date().toLocaleString()}`,
      hideMetadata: false,
      metadata: metaData
    });
  }
}
