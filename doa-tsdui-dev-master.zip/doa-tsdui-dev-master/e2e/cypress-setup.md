install cypress

https://docs.cypress.io/guides/getting-started/installing-cypress#System-requirements

read the getting started section to get familiar with cypress

cucumber support is provided by [cypress-cucumber-preprocessor](https://github.com/TheBrainFamily/cypress-cucumber-preprocessor)

also quickly read this site.

> npm install

Make sure you have chrome or firefox installed

open cypress

> npx cypress open

select the feature file to edit.

add @focus annotation to scenario only run the scenario
##Todo
