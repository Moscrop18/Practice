/// <reference types="cypress" />

declare namespace Cypress {
  interface Chainable<Subject> {
    /**
     * Login With an Economic Operator
     * @example
     * cy.createDefaultTodos()
     */
    loginWithEO(): Chainable<any>;

    /**
     * Find an element with matching datatest attribute
     * @param dataTestAttribute
     * @param args
     */
    getBySel(dataTestAttribute: string, args?: any): Chainable<Element>;

    /**
     * Find an element with a datatest attribute like
     * @param dataTestAttribute
     * @param args
     */
    getBySelLike(
      dataTestPrefixAttribute: string,
      args?: any
    ): Chainable<Element>;
    fill(text: string): Chainable<Element>;
    /** select an option in a material select box */
    selectOption(option: string): Chainable<Element>;
    selectAutocomplete(option: string): Chainable<Element>;
    selectActionMenuItem(option: string): Chainable<Element>;
    /** press the escape button */
    escape(): Chainable<Element>;

    getTextField(): Chainable<Element>;
    getError(): Chainable<Element>;
    getHint(): Chainable<Element>;

    getTableHeadersText(): Chainable<Element>;
    getTableHeaders(): Chainable<Element>;
    gotoNextTablePage(): Chainable<Element>;
    setTablePageSize(size: number): Chainable<Element>;
    gotoPreviousTablePage(): Chainable<Element>;
    /** Return the table row content */
    getTableRows(rowSelector?: string): Chainable<Element>;
    mouseHover(): Chainable<Element>;
    shouldBeChecked(): Chainable<Element>;
    shouldBeBlank(): Chainable<Element>;
    shouldNotBeBlank(): Chainable<Element>;
    waitUntilAngularStable(): Chainable<Element>;
    getActionMenuItems(selector?: string): Chainable<Element>;
  }
}
