import './commands';
import 'cypress-pipe';
import 'cypress-axe';
import failOnConsoleError from 'cypress-fail-on-console-error';
import 'cypress-terminal-report/src/installLogsCollector';
import 'cypress-get-table';

failOnConsoleError();
