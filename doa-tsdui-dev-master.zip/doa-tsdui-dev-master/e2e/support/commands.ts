declare namespace Cypress {
  interface Chainable<Subject = any> {
    /**
     * Login With an Economic Operator
     * @example
     * cy.createDefaultTodos()
     */
    loginWithEO(): Chainable;

    /**
     * Find an element with matching datatest attribute
     * @param dataTestAttribute
     * @param args
     */
    getBySel(dataTestAttribute: string): Chainable<JQuery<HTMLElement>>;

    fill(text: string): Chainable<Element>;
    /** select an option in a material select box */
    selectOption(option: string): Chainable<Element>;
    selectAutocomplete(option: string): Chainable<Element>;
    selectActionMenuItem(option: string): Chainable<Element>;
    /** grab default option (-) for select box  */
    getDefaultOption(option: string): Chainable<Element>;
    /** press the escape button */
    escape(): Chainable<Element>;

    getTextField(): Chainable<Element>;
    getError(): Chainable<Element>;
    getHint(): Chainable<Element>;

    getTableHeadersText(): Chainable<Element>;
    getTableHeaders(): Chainable<Element>;
    gotoNextTablePage(): Chainable<Element>;
    setTablePageSize(size: number): Chainable<Element>;
    gotoPreviousTablePage(): Chainable<Element>;
    /** Return the table row content */
    getTableRows(rowSelector?: string): Chainable<Element>;
    mouseHover(): Chainable<Element>;
    shouldBeChecked(): Chainable<Element>;
    shouldBeBlank(): Chainable<Element>;
    getActionMenuItems(selector?: string): Chainable<Element>;
  }
}

Cypress.Commands.add('getBySel', (selector) => {
  return cy.get(`[data-test*=${selector}]`);
});

Cypress.Commands.add('loginWithEO', () => {
  sessionStorage.setItem('Authorization', 'Bearer Cfxp2UqIrs2LOaTxvWq83wF7BPI');
  sessionStorage.setItem(
    'minfin-iam-idtoken',
    'eyJ0eXAiOiJKV1QiLCJraWQiOiJSUklpdWtxcGgzUGlJUDBvN0ZQT3l5NzBxaDQ9IiwiYWxnIjoiUlMyNTYifQ.eyJhdF9oYXNoIjoiQmhmRmktTlR4QXVDRXFTd20yZXRMQSIsInN1YiI6InR0c2QwMWFhIiwiYXVkaXRUcmFja2luZ0lkIjoiYzdiNzFiODctYjA0NS00MzE5LWI0N2MtMmM0YzkyMzNmOTdkLTExNjA0NTMzNCIsInN1Ym5hbWUiOiJ0dHNkMDFhYSIsImlzcyI6Imh0dHBzOi8vYW0tYS5maW5iZWwuaW50cmEvc3NvL29hdXRoMiIsInRva2VuTmFtZSI6ImlkX3Rva2VuIiwibm9uY2UiOiI1ZWMxMjA1ZmU1MGM4NDdlMzgzYWZiNzQ2NmIwY2RkNCIsInNpZCI6Imcyelo1cGh1dGhFTUFxQXEyKzYvbTc3Y29UY0pHOVdtcUcxbE9WM0JsclU9IiwiYXVkIjoidGVtcHN0b3JhZ2UiLCJjX2hhc2giOiJuYjgwZUdwVU1IOFVTM1pMbEh3VG1nIiwiYWNyIjoiTERBUE1QIiwib3JnLmZvcmdlcm9jay5vcGVuaWRjb25uZWN0Lm9wcyI6InF4MHJDTDlsN2NrMm9OZkhSMllDMnJuUnZSTSIsInNfaGFzaCI6InA1c2laQ2ppeHVpYWpUNTYtNkI1MXciLCJhenAiOiJ0ZW1wc3RvcmFnZSIsImF1dGhfdGltZSI6MTY1NTgxNDQyNSwicmVhbG0iOiIvaW50ZXJuYWwiLCJleHAiOjE2NTU4Mzk0NDYsInRva2VuVHlwZSI6IkpXVFRva2VuIiwiaWF0IjoxNjU1ODM1ODQ2fQ.As1H0iOZPt_YsLjds0gkKrfo47lLUJB7cilHigGY9KWb395OQ4OuoFfX8P_I7CQbJgg4_Ws4glecW9JUi6mfTmt9zkIhchXmnM97FF13KoyeN63WUlBdTOr8lZAMcqg-HRSujFeDhA_0NuSPtKiP0aAtG5hBKLmAyOuh546vnKKNXf63vGKjfsR6B8CY-A4vN1qb4X5cRR8T_7LfFrboIf-iXgpIwrJFtfuRzBvazXgB4txK4ly2qktMYq02hNs6U78p7QUnKQgcU3GOLwwxv0QMUg_dTSoBgvCN7n0KkumQl_z5CzGwXXvTeDmkI8RYWcWnvySFPwgc-ypsY6hrzQ'
  );
  sessionStorage.setItem(
    'minfin-iam_usertoken',
    'eyJ0eXAiOiJKV1QiLCJraWQiOiJSUklpdWtxcGgzUGlJUDBvN0ZQT3l5NzBxaDQ9IiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiJ0dHNkMDFhYSIsInByZWZlcnJlZExhbmd1YWdlIjoibmwiLCJtYWlsIjoidGVzdHVzZXIudHNkMDFAbWluZmluLmZlZC5iZSIsIm9mZmljZXMiOlsiTjZBMjAwMSJdLCJnaXZlbk5hbWUiOiJ0ZXN0dXNlciIsImlzcyI6Imh0dHBzOi8vYW0tYS5maW5iZWwuaW50cmEvc3NvL29hdXRoMiIsImNuIjoidHNkMDEgdGVzdHVzZXIiLCJzc28tdWlkIjoidHRzZDAxYWEiLCJjbGllbnRfaWQiOiJ0ZW1wc3RvcmFnZSIsImF1ZCI6InRlbXBzdG9yYWdlIiwidWlkIjoidGVzdHVzZXIudHNkMDEiLCJ1c2VyX3R5cGUiOiJpbnRlcm5hbCIsInBlcm1pc3Npb25zIjp7InRlbXBzdG9yYWdlIjp7IlJDUmFuZG9tU2VsZWN0aWVTdGFydCI6eyJDcmVhdGUiOiJ0cnVlIn0sIklycmVndWxhcml0eURlY2lzaW9uVFNEIjp7Ik1hbmFnZSI6InRydWUifSwiUkNNYW51YWxTZWxlY3QiOnsiTW9kaWZ5IjoidHJ1ZSJ9LCJEZWNsYXJhdGlvblRTRFN0YXR1c0NoYW5nZSI6eyJNb2RpZnkiOiJ0cnVlIn0sIkFtZW5kbWVudFRTRCI6eyJDcmVhdGUiOiJ0cnVlIn0sIlJDQ29uc3VsdCI6eyJBbGxvdyI6InRydWUifSwiRHJhZnREZWNsYXJhdGlvblRTRCI6eyJNYW5hZ2UiOiJ0cnVlIn0sIkRlY2xhcmF0aW9uUmVwb3J0Ijp7IkFsbG93IjoidHJ1ZSJ9LCJJbnZhbGlkYXRlVFNEIjp7IkNyZWF0ZSI6InRydWUifSwiRGVjbGFyYXRpb25UU0QiOnsiQ29uc3VsdCI6InRydWUifSwiUkNEZXNlbGVjdCI6eyJNb2RpZnkiOiJ0cnVlIn0sIlJlZ2lzdGVyTWVhc3VyZXMiOnsiTW9kaWZ5IjoidHJ1ZSJ9LCJBbGxEZWNsYXJhdGlvblRTRCI6eyJDb25zdWx0IjoidHJ1ZSJ9fX0sInNuIjoidHNkMDEiLCJleHAiOjE2NTU4Mzk0NDYsImFsbG93ZWRBcHBzIjpbInRlbXBzdG9yYWdlIl19.bfynHEJuaGcrQyKcPPq02GZojU7eFTs-njbAzEkv62dC1BmI6rktbIEboA0676FIRcwR-ou6syVnWoZP3a6Tv1j1b2FY7ymyGydiMz0vxVVX58DV67bF7UAGLDc6Rcm6fRKRtIgo3KLv0AGyxlyToy6tpNOu_esE9pCtDAXBkbU4vKpKrqoLbIPE-waURApl-hRE6xGPqcz-y6A2asBBNOhKpfttlMHbmH_sIk359WFIsNmzUzpRCCG64kP5m4rni_S1GbNxxUzTk0-cW26TCD8U5Q880C_dyJF-4ZMf1JS2QuSRLM_L7fh8s7MWwm2TAZajaDcBPm-0fSyFyg0B2w'
  );
  Cypress.log({
    name: 'Login with EO',
    // shorter name for the Command Log
    displayName: 'login',
    message: `Login as EO and set language to "en"`,
    consoleProps: () => {
      return {
        'Authorization': sessionStorage.getItem('Authorization')
      };
    }
  });
});

// TODO extract in utility library

Cypress.Commands.add(
  'getTextField',
  {
    prevSubject: true
  },
  (subject) => {
    cy.wrap(subject, { log: false }).find('input', { log: false });
    Cypress.log({
      name: 'getTextField',
      displayName: 'get input'
    });
  }
);
Cypress.Commands.add(
  'getError',
  {
    prevSubject: true
  },
  (subject) => {
    cy.wrap(subject, { log: false }).find('.mat-error', { log: false });
    Cypress.log({
      name: 'getError',
      displayName: 'get error'
    });
  }
);
Cypress.Commands.add(
  'getHint',
  {
    prevSubject: true
  },
  (subject) => {
    cy.wrap(subject, { log: false }).find('.mat-hint', { log: false });
    Cypress.log({
      name: 'getHint',
      displayName: 'get hint'
    });
  }
);

Cypress.Commands.add(
  'selectActionMenuItem',
  {
    prevSubject: true
  },
  (subject, option) => {
    const click = ($el) => $el.click();
    cy.wrap(subject, { log: false })
      .find('button', { log: false })
      .pipe(click, { log: false })
      .should(($el) => {
        expect($el).to.have.attr('aria-expanded', 'true');
      })
      .get('.mat-menu-item', { log: false })
      .contains(option, { log: false })
      // need to force since material is using an overlay backdrop which is in front but not visible...
      .click({ log: true, force: true });
    Cypress.log({
      name: 'select action menu item',
      displayName: 'click action',
      message: `${option}`
    });
  }
);

Cypress.Commands.add(
  'getActionMenuItems',
  (subject, selector = '.mat-menu-item') => {
    const itemsList = [];
    cy.log(`itemsList **${selector}**`);
    cy.wrap(subject)
      .get(selector)
      .each(($li) => {
        itemsList.push($li.text().trim());
      })
      // yield the grabbed list using either - wrap can also be used
      .then(() => itemsList);
    Cypress.log({
      name: 'grab action menu items',
      displayName: 'grab action items',
      message: `${selector}`
    });
    // return itemsList;
  }
);

Cypress.Commands.add(
  'selectOption',
  {
    prevSubject: 'element'
  },
  (subject: JQuery<HTMLElement>, option) => {
    const click = ($el: JQuery<HTMLElement>) => $el.trigger('click');
    cy.wrap(subject, { log: false })
      .find('mat-select', { log: false })
      .pipe(click, { log: false })
      .should(($p) => {
        expect($p).to.have.attr('aria-expanded', 'true');
      })
      .get('.mat-option', { log: false })
      .contains(option, { log: false })
      .click({ force: true, log: false });
    Cypress.log({
      name: 'selectOption',
      displayName: 'option',
      message: `${option}`
    });
  }
);
Cypress.Commands.add(
  'selectAutocomplete',
  {
    prevSubject: 'element'
  },
  (subject: JQuery<HTMLElement>, option) => {
    cy.wrap(subject, { log: false })
      .type(option, { log: false })
      .get('.mat-option-text', { log: false })
      .contains(option, { log: false })
      .click({ force: true, log: false });
    Cypress.log({
      name: 'selectAutocomplete',
      displayName: 'autocomplete',
      message: `${option}`
    });
  }
);

Cypress.Commands.add('escape', () => {
  cy.get('body', { log: false }).type('{esc}', { force: true });
});
/** hack for type which is to slow to fill in a lot of text */
Cypress.Commands.overwrite(
  'type',
  (originalFn, subject, text, options = {}) => {
    options.delay = 0; // 10 -> 1 speedup e2e test
    return originalFn(subject, text);
  }
);

Cypress.Commands.add(
  'fill',
  {
    prevSubject: 'element'
  },
  (subject: JQuery<HTMLElement>, value) => {
    cy.wrap(subject, { log: false })
      .invoke({ log: false }, 'val', value.slice(0, -1))
      .trigger('input', { log: false })
      .trigger('change', { log: false })
      // type the last character to trigger events
      .type(value.slice(-1), { log: false, delay: 0 });
    Cypress.log({
      name: 'fill field',
      displayName: 'fill',
      message: `${value}`
    });
  }
);

Cypress.Commands.add(
  'getTableHeadersText',
  {
    prevSubject: true
  },
  (subject) => {
    cy.wrap(subject, { log: false })
      .find('table thead tr th', { log: false })
      .then((th) => Cypress._.map(th, 'innerText'));
    Cypress.log({
      name: 'getTableHeadersText',
      displayName: 'table headers text'
    });
  }
);
Cypress.Commands.add(
  'getTableHeaders',
  {
    prevSubject: true
  },
  (subject) => {
    cy.wrap(subject, { log: false }).find('table thead tr th', { log: false });
    Cypress.log({
      name: 'getTableHeaders',
      displayName: 'table headers'
    });
  }
);

Cypress.Commands.add(
  'getTableRows',
  {
    prevSubject: 'element'
  },
  (subject: JQuery<HTMLElement>, rowSelector = ':not(.example-detail-row)') => {
    cy.wrap(subject, { log: false }).pipe(
      (el) => {
        let actualRows = [];
        el.find('tbody tr' + rowSelector).each((_trIndex, $row) => {
          actualRows.push([
            ...Cypress.$($row)
              .children('td')
              .map((_tdIndex, $column) => $column.innerText)
          ]);
        });
        return actualRows;
      },
      { log: false }
    );
    Cypress.log({
      name: 'getTableRows',
      displayName: 'table rows'
    });
  }
);
Cypress.Commands.add(
  'gotoNextTablePage',
  {
    prevSubject: true
  },
  (subject) => {
    cy.wrap(subject, { log: false })
      .find('.mat-paginator-navigation-next', { log: false })
      .click({ log: false })
      .wrap(subject, { log: false });
    Cypress.log({
      name: 'gotoNextTablePage',
      displayName: 'next page'
    });
  }
);
Cypress.Commands.add(
  'gotoPreviousTablePage',
  {
    prevSubject: true
  },
  (subject) => {
    cy.wrap(subject, { log: false })
      .find('.mat-paginator-navigation-previous', { log: false })
      .click({ log: false })
      .wrap(subject, { log: false });
    Cypress.log({
      name: 'gotoPreviousTablePage',
      displayName: 'previous page'
    });
  }
);
Cypress.Commands.add(
  'shouldBeChecked',
  {
    prevSubject: true
  },
  (subject) => {
    cy.wrap(subject, { log: false }).should(
      'have.class',
      'mat-checkbox-checked'
    );
  }
);

Cypress.Commands.add(
  'shouldBeBlank',
  {
    prevSubject: true
  },
  (subject) => {
    cy.wrap(subject, { log: false }).should('have.value', '');
  }
);

Cypress.Commands.add(
  'setTablePageSize',
  {
    prevSubject: true
  },
  (subject, size) => {
    cy.wrap(subject, { log: false })
      .find('.mat-paginator-page-size-select ', { log: false })
      .click({ log: false })
      .get('.mat-option-text', { log: false })
      .contains(size, { log: false })
      .click({ log: false })
      .log('setTablePageSize')
      .wrap(subject, { log: false });
    Cypress.log({
      name: 'setTablePageSize',
      displayName: 'set table page size',
      message: `${size}`
    });
  }
);

Cypress.Commands.add(
  'mouseHover',
  {
    prevSubject: true
  },
  (subject) => {
    cy.wrap(subject).each((ele) => {
      ele.trigger('mousemove', { force: true });
    });
  }
);

Cypress.Commands.add(
  'getDefaultOption',
  {
    prevSubject: 'element'
  },
  (subject: JQuery<HTMLElement>, option) => {
    const click = ($el: JQuery<HTMLElement>) => $el.trigger('click');
    cy.wrap(subject, { log: false })
      .find('mat-select', { log: false })
      .pipe(click, { log: false })
      .should(($p) => {
        expect($p).to.have.attr('aria-expanded', 'true');
      })
      .get('.mat-option-text', { log: false })
      .contains(option, { log: false });

    Cypress.log({
      name: 'getDefaultOption',
      displayName: 'option',
      message: `${option}`
    });
  }
);
