///<reference types = "Cypress"/>
import { Given, When, Then, And } from 'cypress-cucumber-preprocessor/steps';
import { Submitted } from './newDeclarationSubmitted.po';
import { NewDeclarationSubmit } from '../newDeclarationSubmitAndOverview/newDeclarationSubmitAndOverview.po';
import { HomePage } from '../home/home.po';
import '../common/customTypes';
import '../common/customTypes';
import { stubFalse } from 'cypress/types/lodash';
import { getUniqueEtag } from '../common/util';

let page = new NewDeclarationSubmit();
let submittedPage = new Submitted();
let homePage = new HomePage();
const successBanner = 'Submission succeeded';
const successMessage =
  'Thank you, your Temporary Storage Declaration is submitted successfully';
const failureBanner = 'Submission failed';
const failureMessage = 'We were not able to submit due to';

Given('Prepare New declaration mock test data for success', () => {
  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1', {
    fixture: 'tsd-declaration.json',
    headers: { etag: getUniqueEtag() }
  }).as('generalInfo');
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4',
    {
      fixture: 'tsd-declaration.json'
    }
  );
  cy.fixture('codelist.json').then((data) => {
    cy.intercept('/assets/codelist/codelist.json', data).as('codeList');
  });
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments?fields=draftErrors&pageSize=100',
    {
      fixture: 'houseList.json'
    }
  ).as('consignments');

  cy.intercept('POST', '/api/v1/temporaryStorageDeclarations/1/validate', {
    statusCode: 200
  }).as('validate');
  cy.intercept('POST', '/api/v1/temporaryStorageDeclarations/1/submit', {
    statusCode: 200
  }).as('submit');

  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/2/items?pageSize=100',
    {
      fixture: 'goods-items.json'
    }
  ).as('consignment2Items');

  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/0/items',
    {
      fixture: 'goods-items.json'
    }
  ).as('consignment0Items');

  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/1/items',
    {
      fixture: 'goods-items.json'
    }
  ).as('consignment1Items');

  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/2?fields=allowedSections',
    {
      fixture: 'house-consignment-info.json',
      headers: { etag: getUniqueEtag() }
    }
  ).as('consignment2');

  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1/consignments/0', {
    fixture: 'house-consignment-info.json',
    headers: { etag: getUniqueEtag() }
  }).as('consignment0');

  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1/consignments/1', {
    fixture: 'house-consignment-info.json',
    headers: { etag: getUniqueEtag() }
  }).as('consignment1');

  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1/consignments/2', {
    fixture: 'house-consignment-info.json',
    headers: { etag: getUniqueEtag() }
  }).as('cons2');

  cy.intercept(
    'GET',

    '/api/v1/temporaryStorageDeclarations/1/consignments/2/items/12?fields=allowedSections',
    {
      fixture: 'master-consignment-items.json',
      headers: { etag: getUniqueEtag() }
    }
  ).as('cons1Item12');
  cy.intercept(
    'PUT',
    '/api/v1/temporaryStorageDeclarations/1/consignments/2/items/12',
    {
      statusCode: 200,
      headers: { etag: getUniqueEtag() }
    }
  ).as('cons0ItemPut');
});
Then('I see the banner with success message', () => {
  submittedPage.getSuccessBanner().should('contain', successBanner);
  submittedPage.getSuccessMessage().should('contain', successMessage);
});
Then('I moved to the consult page', () => {
  submittedPage.getConsultPageTitle().should('contain', 'General information');
});
Then('I see the banner with failure message', () => {
  submittedPage.getSuccessBanner().should('contain', failureBanner);
  submittedPage.getSuccessMessage().should('contain', failureMessage);
});

Given('Prepare New declaration mock test data for failure', () => {
  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1', {
    fixture: 'tsd-declaration.json',
    headers: { etag: getUniqueEtag() }
  }).as('generalInfo');
  cy.fixture('codelist.json').then((data) => {
    cy.intercept('/assets/codelist/codelist.json', data).as('codeList');
  });
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments?fields=draftErrors&pageSize=100',
    {
      fixture: 'houseList.json'
    }
  ).as('consignments');

  cy.intercept('POST', '/api/v1/temporaryStorageDeclarations/1/validate', {
    statusCode: 200
  }).as('validate');
  cy.intercept('POST', '/api/v1/temporaryStorageDeclarations/1/submit', {
    fixture: 'tsd-declaration_submission_failed.json',
    statusCode: 400,
    failOnStatusCode: false
  }).as('submitFail');

  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/2/items?pageSize=100',
    {
      fixture: 'goods-items.json'
    }
  ).as('consignment2Items');

  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/0/items',
    {
      fixture: 'goods-items.json'
    }
  ).as('consignment0Items');

  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/1/items',
    {
      fixture: 'goods-items.json'
    }
  ).as('consignment1Items');

  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/2?fields=allowedSections',
    {
      fixture: 'house-consignment-info.json',
      headers: { etag: getUniqueEtag() }
    }
  ).as('consignment2');

  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1/consignments/0', {
    fixture: 'house-consignment-info.json',
    headers: { etag: getUniqueEtag() }
  }).as('consignment0');

  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1/consignments/1', {
    fixture: 'house-consignment-info.json',
    headers: { etag: getUniqueEtag() }
  }).as('consignment1');

  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1/consignments/2', {
    fixture: 'house-consignment-info.json',
    headers: { etag: getUniqueEtag() }
  }).as('cons2');

  cy.intercept(
    'GET',

    '/api/v1/temporaryStorageDeclarations/1/consignments/2/items/12?fields=allowedSections',
    {
      fixture: 'master-consignment-items.json',
      headers: { etag: getUniqueEtag() }
    }
  ).as('cons1Item12');
  cy.intercept(
    'PUT',
    '/api/v1/temporaryStorageDeclarations/1/consignments/2/items/12',
    {
      statusCode: 200,
      headers: { etag: getUniqueEtag() }
    }
  ).as('cons0ItemPut');
});
Then('I moved to the home page', () => {
  homePage.getTitle().should('eq', 'TSD Application');
  homePage.getContent().should('contain', 'TSD Angular UI App!!');
  homePage.getBreadcrumb().should('contain', 'Home');
});
Then('I click on the dismiss button on the banner', () => {
  submittedPage.getDismissButton().click();
});
Then('I dont see the banner on the page', () => {
  submittedPage.getSuccessBanner().should('not.exist');
});
Then('I see the dismiss button', () => {});
And('I am on the last consignment items page', () => {
  cy.loginWithEO();
  cy.visit('/edit-declaration/tsd/house-con-items?tsdId=1&consNo=2&itemNo=12');
});
Then('I click on Submit button', () => {
  cy.wait('@consignments');
  cy.wait('@generalInfo').then((data) => {});
  page.getSubmitButton().click();
});
Then('I see the overview page', () => {
  page.getOverview().contains(' Review and confirm submission ');
});
Then('I click on the confirm button', () => {
  page.getConfirmButton().click();
});
Then('I see the progress bar', () => {
  submittedPage.getProgressbar().should('exist');
});
Then('I dont see the progress bar', () => {
  submittedPage.getProgressbar().should('not.exist');
});
And('the submit button and stepper are disabled', () => {
  page.getSubmitButton().should('be.disabled');
  page.getStepper().should('contain.class', 'mat-vertical-stepper-disabled');
});
