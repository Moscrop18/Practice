import { DeclarationType, EnsReuse } from '../common/customTypes';
export class Submitted {
  getSuccessBanner() {
    return cy.get('[data-testid=errorTitle]');
  }
  getSuccessMessage() {
    return cy.get('[data-testid=errorMessage]');
  }
  getConsultPageTitle(): any {
    return cy.get('[data-testid=genInfoTitle]');
  }
  getDismissButton(): any {
    return cy.get('[data-testid=dismiss]');
  }
  getProgressbar(): any {
    return cy.get('.mat-progress-bar-buffer');
  }
}
