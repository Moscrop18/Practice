export class SaveTsdDraftsPage {
  navigateAdvancedSearchPage() {
    cy.loginWithEO();
    cy.visit('/saved-drafts');
  }
  isVisible() {
    cy.location('pathname').should('contain', '/saved-drafts');
  }

  isEditdeclarationPageVisible() {
    cy.location('pathname').should(
      'contain',
      '/edit-declaration/tsd/general-info'
    );
    cy.get('.mat-title').should('contain', 'Step 1: General information');
  }
  visit() {
    cy.loginWithEO();
    cy.visit('/saved-drafts');
  }

  getSavedDraftTable(): any {
    return cy.get('[data-testid="savedDrafts"]');
  }
  getErrorMessage(): Cypress.Chainable<any> {
    return cy.get('#noRecord');
  }

  getActionsIcon(): Cypress.Chainable<any> {
    return cy.get('#menuButton0');
  }

  getMenuItems(): Cypress.Chainable<any> {
    return cy.get('.mat-menu-content');
  }

  tableSelectors = {
    'SAVED DRAFTS': '[data-testid="savedDrafts"]'
  };

  getTable(title): any {
    return cy.get(this.tableSelectors[title]);
  }
}
