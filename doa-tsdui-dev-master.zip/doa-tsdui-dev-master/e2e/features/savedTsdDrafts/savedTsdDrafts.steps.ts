///<reference types = "Cypress"/>
import { AdvSearchResultItem } from '@features/advanced-search/models';
import { And, Given, Then, When } from 'cypress-cucumber-preprocessor/steps';
import { convertDate, getUniqueEtag } from '../common/util';
import { SaveTsdDraftsPage } from './savedTsdDrafts.po';
import { MasterConsignItemPage } from '../consignmentItems/consignmentItems.po';

let ConsignItemPage = new MasterConsignItemPage();
let page = new SaveTsdDraftsPage();
const errorMessage =
  'No drafts. Save a declaration as a draft and it will show up here.';

let savedDrafts: AdvSearchResultItem[];
let tableHeaders = {
  'SAVED DRAFTS': [
    'Type',
    'Last saved',
    'Category',
    'LRN',
    'Status',
    'Action',
    ''
  ]
};

Given('I have navigated to the TSD drafts page', () => {
  cy.fixture('tsd-drafts.json').then((data) => {
    savedDrafts = data.items;
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations?status=Draft&sort=-registrationDate**',
      data
    );
  });
  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1', {
    fixture: 'tsd-declaration.json',
    headers: { etag: getUniqueEtag() }
  }).as('generalInfo');
  cy.intercept('DELETE', '/api/v1/temporaryStorageDeclarations/1', {
    statusCode: 200
  }).as('deleteDraft');
  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations?status=Draft*', {
    fixture: 'tsd-drafts.json'
  }).as('getdraftList');
  page.visit();
});

Given(
  'I have navigated to the TSD drafts page when there are no records',
  () => {
    cy.fixture('tsd-drafts-NoRecords.json').then((data) => {
      savedDrafts = data.items;
      cy.intercept(
        'GET',
        '/api/v1/temporaryStorageDeclarations?status=Draft&sort=-registrationDate**',
        data
      ).as('saveTSD');
    });
    page.visit();
  }
);

And('Prepare pagination data', () => {
  cy.fixture('tsd-drafts-pagination.json').then((data1) => {
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations?after=qoVf3ERK1Mdsd3G5kMTosNTm=&registrationDateBefore=2022-04-06T00:00:00.000Z&registrationDateAfter=2022-03-06T00:00:00.000Z&pageSize=10&sort=-registrationDate&status=Draft',
      data1
    ).as('paginationData');
  });
  page.visit();

  cy.fixture('tsd-drafts.json').then((data1) => {
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations?before=MTU3MTY1Mjc4MzAwMToxNzY=&registrationDateBefore=2022-04-06T00:00:00.000Z&registrationDateAfter=2022-03-06T00:00:00.000Z&pageSize=10&sort=-registrationDate&status=Draft',
      data1
    ).as('draftData');
  });
  page.visit();
});

And('Prepare sorting data', () => {
  cy.fixture('tsd-drafts-sort.json').then((data1) => {
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations?status=Draft&sort=registrationDate',
      data1
    );
  });
  page.visit();

  cy.fixture('tsd-drafts.json').then((data1) => {
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations?status=Draft&sort=-registrationDate',
      data1
    );
  });
  page.visit();
});

And('I can see the message with No data', () => {
  page.getErrorMessage().should('contain', errorMessage);
});

When('I see the TSD drafts page', () => {
  page.isVisible();
});
When('I see the Edit Declaration General Info page', () => {
  page.isEditdeclarationPageVisible();
});

Then('I see the action options', () => {
  cy.wait('@getdraftList');
  cy.location('search').should('contain', 'status');
  page.getActionsIcon().click();

  page
    .getMenuItems()
    .first()
    .should('contain', 'Edit')
    .and('contain', 'Delete');
});

Then('I click edit button', () => {
  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1', {
    statusCode: 400,
    fixture: 'amendError.json'
  }).as('amendError');
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments?fields=draftErrors',
    { fixture: 'houseList.json' }
  );
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments?fields=draftErrors&pageSize=100',
    { fixture: 'houseList.json' }
  ).as('consignmentsFieldError');
  cy.wait('@getdraftList');
  cy.location('search').should('contain', 'status');
  page.getActionsIcon().click({ force: true });
  page.getMenuItems().first().contains('Edit').click({ force: true });
});

Then('I click delete button', () => {
  cy.wait('@getdraftList');
  cy.location('search').should('contain', 'status');
  page.getActionsIcon().click();
  page.getMenuItems().first().contains('Delete').click();
});

Then('I see the {string} table title and headers', (tableName) => {
  page
    .getTable('SAVED DRAFTS')
    .should('contain', tableName)
    .getTableHeadersText()
    .should('deep.equal', tableHeaders['SAVED DRAFTS']);
});
Then('I can use the pagination of the {string} table', (tableName) => {
  page.getTable(tableName).gotoNextTablePage();
  page
    .getTable(tableName)
    .getTableRows()
    .should('have.length', getTableDataSlice(0, 3).length);
  cy.url()
    .should('contain', 'after=qoVf3ERK1Mdsd3G5kMTosNTm')
    .and('contain', 'sort=-registrationDate');

  page
    .getTable(tableName)
    .gotoPreviousTablePage()
    .getTableRows()
    .should('have.length', getTableDataSlice(0, 10).length);
  cy.url()
    .should('contain', 'before=MTU3MTY1Mjc4MzAwMToxNzY')
    .and('contain', 'sort=-registrationDate');
  page
    .getTable(tableName)
    .setTablePageSize(20)
    .getTableRows()
    .should('have.length', getTableDataSlice(0, 10).length);
});

When('I see the {string} table content', (tableName) => {
  page
    .getTable(tableName)
    .getTableRows()
    .should(
      'deep.equal',
      convertDateAndTimeAndStatus(getTableDataSlice(0, 10))
    );
});

function convertDateAndTimeAndStatus(data): string[][] {
  let i: number = 0;
  for (i; i < data.length; i++) {
    data[i][1] =
      convertDate(data[i][1], 'MMM dd, y') +
      ' at ' +
      convertDate(data[i][1], 'HH:mm');

    if (data[i][0] === 'PreLodged') {
      data[i][0] = 'Pre-lodged';
    }
  }
  return data;
}

Then('I can use the sorting of the {string} table', (tableName) => {
  page
    .getTable(tableName)
    .getTableHeaders()
    .each((header, i) => {
      if (i != 1) {
        return;
      }
      cy.url().should('contain', 'sort=-registrationDate');
      cy.wrap(header).click();
      cy.wrap(header).click();
    });

  let sorted = getTableDataSlice(tableName)
    .sort((x, y) => +new Date(x[1]) - +new Date(y[1]))
    .slice(0, 13);
  sorted.forEach((element) => {
    element[0] = element[0] === 'PreLodged' ? 'Pre-lodged' : element[0];
    element[1] =
      convertDate(element[1], 'MMM dd, y') +
      ' at ' +
      convertDate(element[1], 'HH:mm');
  });

  page.getTable(tableName).getTableRows().should('deep.equal', sorted);
});

And('I can see the breadcrumb with Draft list', () => {
  cy.get('.breadcrumb > :nth-child(2) > :nth-child(2)').should(
    'have.text',
    'Saved drafts'
  );
});

When('Click on ok button', () => {
  ConsignItemPage.getCloseButton().click();
});

Then('I can see the error popup {string}', (errorMsg) => {
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments?fields=draftErrors&pageSize=100',
    {
      statusCode: 200,
      fixture: 'tsd-drafts.json'
    }
  ).as('getdraftList1');
  if (
    errorMsg ===
    'A more recent version of the corresponding declaration is available'
  ) {
    cy.wait('@amendError');
    cy.get('[data-testid="errorPopup"]').should('contain', errorMsg);
  } else {
    cy.get('[data-testid="errorPopup"]').should('contain', errorMsg);
  }
});

function getTableDataSlice(start: number = 0, end?: number) {
  return getTableData().slice(start, end);
}

function getTableData(i = 1) {
  return savedDrafts.map((t) => [
    t.type,
    t.registrationDate,
    t.category,
    t.lrn,
    ' ' + t.status,
    'more_vert'
  ]);
}
