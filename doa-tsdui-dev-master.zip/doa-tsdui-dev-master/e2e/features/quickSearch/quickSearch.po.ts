export class HomePageQuickSearch {
  getSearchBox(): Cypress.Chainable<any> {
    return cy.get('[data-testid=miniSearch]');
  }
  getSearchIcon(): Cypress.Chainable<any> {
    return cy.get('[data-testid=searchButtton]');
  }
  getOverlay() {
    return cy.get('.custom-overlay');
  }
  getErrorMessage() {
    return cy.get('[data-testid=noResults]');
  }
  isVisible() {
    cy.location('pathname').should('match', /\/advanced-search$/);
  }
  getBreadcrumb() {
    return cy.get('.breadcrumb > :nth-child(2) > :nth-child(2)');
  }
}
