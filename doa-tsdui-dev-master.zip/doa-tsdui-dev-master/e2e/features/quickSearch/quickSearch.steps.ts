import { HomePage } from '../home/home.po';
import { Given, When, Then, And } from 'cypress-cucumber-preprocessor/steps';
import { HomePageQuickSearch } from './quickSearch.po';
import { ConsultGeneralInformation } from '@features/manage-declaration/models/consult-general-information';
import { ConsultDeclarationGeneralInfoPage } from '../consult-declaration-information/consult-declaration-information-generalInformation.po';
import { AdvancedSearchPage } from '../searchParameters/searchParameters.po';

let homePage = new HomePage();
let homePageQuickSearch = new HomePageQuickSearch();
let generalInfoPage = new ConsultDeclarationGeneralInfoPage();
let tsd: ConsultGeneralInformation;
let advancedSearchPage = new AdvancedSearchPage();
let errorMessage =
  'There are 0 results returned based on the search criteria. Please refine your search below.';

Given('Set mock data', () => {
  cy.fixture('tsd-declaration.json').then((declaration) => {
    tsd = declaration;
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4',
      declaration
    ).as('advancedSearch');
  });
});

Given('I have navigated to the Home Page', () => {
  homePage.visit();
});

Then('the home page should be visible', () => {
  homePage.getTitle().should('eq', 'TSD Application');
  homePage.getContent().should('contain', 'TSD Angular UI App!!');
  homePage.getBreadcrumb().should('contain', 'Home');
});
When('Overlay is hidden', () => {
  homePageQuickSearch.getOverlay().should('not.exist');
});
When('I search with valid MRN or CRN by pressing enter', () => {
  homePageQuickSearch.getSearchBox().type('20BETP000000C3FLU4').type('{enter}');
});
Then('I move to the general information page', () => {
  generalInfoPage
    .getGeneralInformationTitle()
    .should('contain', ' General information');
  generalInfoPage
    .getAddressedCustomOffice()
    .should('contain', ' Addressed customs office ');
  generalInfoPage.getEntryInfoTitle().should('contain', 'Entry information');
  generalInfoPage
    .getLocationOfGoodstitle()
    .should('contain', 'Declared location of goods');
});
When('I search with valid MRN or CRN by clicking loop icon button', () => {
  homePageQuickSearch.getSearchBox().type('20BETP000000C3FLU4');
  homePageQuickSearch.getSearchIcon().click();
});
When('I search with invalid MRN or CRN by pressing enter', () => {
  homePageQuickSearch.getSearchBox().type('20XXTP000000C3FLU5').type('{enter}');
});
When('I search with invalid MRN or CRN by clicking loop icon button', () => {
  homePageQuickSearch.getSearchBox().type('20XXTP000000C3FLU5');
  homePageQuickSearch.getSearchIcon().click();
});
When('I move to the Advanced search page', () => {
  homePageQuickSearch.isVisible();
});
When('I can see the breadcrumb', () => {
  homePageQuickSearch.getBreadcrumb().should('have.text', 'Advanced search');
});
When('I can see the error message', () => {
  homePageQuickSearch.getErrorMessage().should('contain', errorMessage);
});
Then('I can see all the fields on the Advanced search page', () => {
  advancedSearchPage
    .getDeclarationInformation()
    .should('contain', ' Declaration information');
  advancedSearchPage
    .getTransportDocumentHeader()
    .should('contain', 'Transport document');
  advancedSearchPage
    .getAddressedCustomsOffice()
    .should('contain', 'Addressed customs office');
  advancedSearchPage
    .getContainerHeader()
    .should('contain', 'Container or receptacle');
  advancedSearchPage
    .getEntryInformationHeader()
    .should('contain', 'Entry information');
  advancedSearchPage.getParties().should('contain', 'Parties');
  advancedSearchPage
    .getDeclarationStatus()
    .should('contain', 'Declaration status');
});
