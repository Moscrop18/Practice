///<reference types = "Cypress"/>

export class MasterConsignmentPartiesPage {
  homePath = '/home';
  newDeclarationPath = '/edit-declaration/tsd/';

  tsdTypeFlag = '';
  queryParams = 'false';

  //-----------------------------------Error Texts---------------------

  setQueryParams(tsdTypeFlag: 'prelodged' | 'combined') {
    this.tsdTypeFlag = tsdTypeFlag;
  }

  getQueryParams(queryParams: string) {
    cy.location().should((loc) => {
      expect(loc.search).to.eq(queryParams);
    });
  }
  getURL() {
    return cy.url();
  }

  getAppTitle() {
    return cy
      .get('div.app-title-full')
      .contains('Temporary Storage Declaration');
  }

  getPageHeaderTitleHint() {
    return cy.get('p#titleHint');
  }
  //--------------------------Consignment PageActions---------------------------
  visitConsignmentPartiesPage(consignment: string) {
    cy.loginWithEO();
    cy.visit(
      '/' +
        this.newDeclarationPath +
        consignment.toLowerCase() +
        '-consignment-parties',
      {
        qs: {
          tsdId: 1,
          consNo: consignment.toLowerCase() === 'master' ? 0 : 2
        }
      }
    );
  }

  getPageTitle() {
    return cy.get('div.app-title');
  }
  //-----------------------------------------Validations
  validateSections(section) {
    cy.get('.mat-subheading-2').should('contain.text', section);
  }

  validatePageTitleFull(pageTitle) {
    this.getPageTitle().should('contain.text', pageTitle);
  }

  validatePageHeaderTitle(pageHeader) {
    if (pageHeader === 'House') {
      cy.get('.mat-title').should('contain', 'Step 3: General information');
    } else {
      cy.get('.mat-title').should('contain', 'Step 2: General information');
    }
  }
  getPageHeader() {
    return cy.get('.mat-title');
  }
  validatePageHeaderUnderText(pageHeaderUnderText) {
    cy.get('div.mat-title p').should('contain.text', pageHeaderUnderText);
  }

  clickSave() {
    cy.get('#save').click();
  }

  getSectionId(section: string) {
    if (section === 'Consignor') {
      return '#consignor';
    } else if (section === 'Consignee') {
      return '#consignee';
    } else if (section === 'Notify party') {
      return '#notifyParty';
    } else {
      return 'unknown section ' + section;
    }
  }

  getTypeOfPersonSelectBox(section: string): Cypress.Chainable<any> {
    return cy.get(this.getSectionId(section) + ' [data-testid=typeOfPerson]');
  }

  getIdentificationNumber(section: string): Cypress.Chainable<any> {
    return cy.get(this.getSectionId(section) + ' [data-testId=declarantEori]');
  }
  getName(section: string): Cypress.Chainable<any> {
    return cy.get(
      this.getSectionId(section) + ' [data-testid=declarantEoriName]'
    );
  }
  getCommunicationTypeSelectBox(section: string): Cypress.Chainable<any> {
    return cy.get(this.getSectionId(section) + ' [data-testid=commType]');
  }

  getCommunicationIdentifier(section: string): Cypress.Chainable<any> {
    return cy.get(this.getSectionId(section) + ' [data-testid=identifier]');
  }

  getStreet(section: string): Cypress.Chainable<any> {
    return cy.get(this.getSectionId(section) + ' [data-testid=streetField]');
  }

  getAddressNumber(section: string): Cypress.Chainable<any> {
    return cy.get(this.getSectionId(section) + ' [data-testid=numberField]');
  }

  getCountryAutocomplete(section: string): Cypress.Chainable<any> {
    return cy.get(this.getSectionId(section) + ' [data-testid=countryField]');
  }

  getCity(section: string): Cypress.Chainable<any> {
    return cy.get(this.getSectionId(section) + ' [data-testid=cityField]');
  }

  getPostCode(section: string): Cypress.Chainable<any> {
    return cy.get(this.getSectionId(section) + ' [data-testid=postCodeField]');
  }

  getAddressTypeSelectBox(section: string): Cypress.Chainable<any> {
    return cy.get(
      this.getSectionId(section) + ' [data-testid=addressTypeField]'
    );
  }

  getAddAdditionalStreetLineButton(section: string): Cypress.Chainable<any> {
    return cy.get(
      this.getSectionId(section) + ' [data-testid=additionalStreetLineButton]'
    );
  }
  getAdditionalStreetLine(section: string): Cypress.Chainable<any> {
    return cy.get(
      this.getSectionId(section) + ' [data-testid=additionalStreetLineField]'
    );
  }
  getSubdivison(section: string): Cypress.Chainable<any> {
    return cy.get(this.getSectionId(section) + ' [data-testid=subdivision]');
  }
  getPOBox(section: string): Cypress.Chainable<any> {
    return cy.get(this.getSectionId(section) + ' [data-testid=pobox]');
  }

  getAddCommunicationButton(section: string): Cypress.Chainable<any> {
    return cy.get(this.getSectionId(section) + ' button[aria-label="addComm"]');
  }
  getDeleteCommunicationButton(section: string): Cypress.Chainable<any> {
    return cy.get(
      this.getSectionId(section) + ' button[aria-label="removeComm"]'
    );
  }

  getErrors(section: string): Cypress.Chainable<any> {
    return cy.get(' .mat-error');
  }

  getNextButton(): Cypress.Chainable<any> {
    return cy.get('#next');
  }
  getSaveButton(): Cypress.Chainable<any> {
    return cy.get('#save');
  }

  getBackButton(): Cypress.Chainable<any> {
    return cy.get('#back');
  }

  getCancelButton(): Cypress.Chainable<any> {
    return cy.get('#cancel');
  }

  getNotifyPartyCheckBox(): Cypress.Chainable<any> {
    return cy.get('#notifyCheckBox');
  }

  //---------------------------input methods
  selectTypeOfPerson(section, personType) {
    if (section === 'Consignor') {
      cy.get(
        '#consignor [data-testid^="typeOfPerson"] .mat-select-arrow'
      ).selectOption(personType);
    } else if (section === 'Consignee') {
      cy.get(
        '#consignee [data-testid^="typeOfPerson"] .mat-select-arrow'
      ).selectOption(personType);
    } else if (section === 'Notify party') {
      cy.get(
        '#notifyParty [data-testid^="typeOfPerson"] .mat-select-arrow'
      ).selectOption(personType);
    }
  }

  selectCommunicationType(section, commTypeOption) {
    if (section === 'Consignor') {
      cy.get('#consignor .eoriCommType').selectOption(commTypeOption);
    } else if (section === 'Consignee') {
      cy.get('#consignee .eoriCommType').selectOption(commTypeOption);
    } else if (section === 'Notify party') {
      cy.get('#notifyParty .eoriCommType').selectOption(commTypeOption);
    }
  }

  selectCountry(section, countryName) {
    if (section === 'Consignor') {
      cy.get('#consignor [data-testid^="countryField"]').selectOption(
        countryName
      );
    } else if (section === 'Consignee') {
      cy.get('#consignee [data-testid^="countryField"]').selectOption(
        countryName
      );
    } else if (section === 'Notify party') {
      cy.get('#notifyParty [data-testid^="countryField"]').selectOption(
        countryName
      );
    }
  }

  verifyNotifyPartyCheckBoxIsNotChecked() {
    cy.get('#notifyCheckBox-input').should(
      'have.attr',
      'aria-checked',
      'false'
    );
  }

  verifyDeleteIcon(section) {
    if (section === 'Consignor') {
      cy.get('#consignor').should('not.have.id', '[id^="removeComm"]');
    } else if (section === 'Consignee') {
      cy.get('#consignee').should('not.have.id', '[id^="removeComm"]');
    } else if (section === 'Notify party') {
      cy.get('#notifyParty').should('not.have.id', '[id^="removeComm"]');
    }
  }

  verifyNoAddIconOnFirstRow(section) {
    if (section === 'Consignor') {
      cy.get('#consignor button[aria-label="addComm"]').should(
        'have.length',
        1
      );
    } else if (section === 'Consignee') {
      cy.get('#consignee button[aria-label="addComm"]').should(
        'have.length',
        1
      );
    } else if (section === 'Notify party') {
      cy.get('#notifyParty button[aria-label="addComm"]').should(
        'have.length',
        1
      );
    }
  }

  verifyDefaultCommunicationTypeFields(section) {
    if (section === 'Consignor') {
      cy.get('#consignor .eoriCommType').should('have.length', 1);
    } else if (section === 'Consignee') {
      cy.get('#consignee .eoriCommType').should('have.length', 1);
    } else if (section === 'Notify party') {
      cy.get('#notifyParty .eoriCommType').should('have.length', 1);
    }
  }

  verifyAdditionalStreetField(section) {
    if (section === 'Consignor') {
      cy.get('#consignor [data-testid^="additionalStreetLineField"]').should(
        'exist'
      );
    } else if (section === 'Consignee') {
      cy.get('#consignee [data-testid^="additionalStreetLineField"]').should(
        'exist'
      );
    } else if (section === 'Notify party') {
      cy.get('#notifyParty [data-testid^="additionalStreetLineField"]').should(
        'exist'
      );
    }
  }

  verifyAddAdditionalStreetIcon(section) {
    if (section === 'Consignor') {
      return cy.get('#consignor div .mat-icon');
    } else if (section === 'Consignee') {
      return cy.get('#consignee div .mat-icon');
    } else if (section === 'Notify party') {
      return cy.get('#notifyParty div .mat-icon');
    }
  }
  cancel() {
    return cy.get('[data-testid="errorPopup"]');
  }
  getCloseButton() {
    return cy.get('[data-testid="errorCloseBtn"]');
  }
  getCreateNewButton() {
    return cy.get('[data-testid=CreateNewBtn]');
  }
  isHomeScreen() {
    cy.get('.home > span').should('contain', 'Welcome to TSD Angular UI App!!');
  }
  getPageURL() {
    return cy.location('pathname');
  }
}
