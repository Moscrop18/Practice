///<reference types = "Cypress"/>

import { When, Then, And, Given } from 'cypress-cucumber-preprocessor/steps';
import { getUniqueEtag } from '../../common/util';
import { MasterConsignmentPartiesPage } from './consignment-parties.po';
let faker = require('faker');

let page = new MasterConsignmentPartiesPage();

var appTitleFull = ' Temporary storage declaration ';
var pageHeading = ' Step 2: Parties ';
var pageHeaderUnderText =
  ' Select the actors that are involved and enter their information. ';

const CONSIGNOR = 'Consignor';
const CONSIGNEE = 'Consignee';
const NOTIFYPARTY = 'Notify party';
const sections = [CONSIGNOR, CONSIGNEE, NOTIFYPARTY];
const selectTypeFieldError = 'Please select a value ';
const inputErrIn17LimitField = 'Please enter a value of maximum 17 characters';
const inputErrIn35LimitField = 'Please enter a value of maximum 35 characters';
const inputErrIn70LimitField = 'Please enter a value of maximum 70 characters';
const inputErrIn512LimitField =
  'Please enter a value of maximum 512 characters';
let putInterceptFlag = false;
let codelist = undefined;

Given(
  'I navigated to {} Consignment Parties page with tsd type as {}',
  (consignment, tsdType) => {
    putInterceptFlag = false;
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments?fields=draftErrors&pageSize=100',
      {
        fixture: 'houseList.json'
      }
    ).as('consignments');
    cy.fixture('tsd-empty-declaration.json').then((data) => {
      const updatedDeclaration = {
        ...data,
        type: tsdType,
        consignmentType: consignment
      };
      cy.intercept('/api/v1/temporaryStorageDeclarations/1', {
        body: updatedDeclaration,
        headers: { etag: getUniqueEtag() }
      }).as('declaration');
    });
    cy.fixture('empty-consignment.json').then((data) => {
      const updatedCons = {
        ...data,
        type: consignment
      };
      cy.intercept(
        '/api/v1/temporaryStorageDeclarations/1/consignments/2?fields=allowedSections',
        {
          body: updatedCons,
          headers: { etag: getUniqueEtag() }
        }
      ).as('consignment1Info');
    });
    cy.fixture('empty-consignment.json').then((data) => {
      const updatedCons = {
        ...data,
        type: consignment
      };
      cy.intercept(
        '/api/v1/temporaryStorageDeclarations/1/consignments/0?fields=allowedSections',
        {
          body: updatedCons,
          headers: { etag: getUniqueEtag() }
        }
      ).as('consignment0Info');
    });
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/0/items?pageSize=100',
      {
        fixture: 'goods-items.json'
      }
    ).as('consignment0Items');
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/2/items?pageSize=100',
      {
        fixture: 'goods-items.json'
      }
    ).as('consignment2Items');
    cy.intercept(
      'PUT',
      '/api/v1/temporaryStorageDeclarations/1/consignments/2',
      (req) => {
        putInterceptFlag = true;
        req.reply({
          headers: {
            etag: getUniqueEtag()
          },
          statusCode: 200
        });
      }
    ).as('cons1Put');
    cy.intercept(
      'PUT',
      '/api/v1/temporaryStorageDeclarations/1/consignments/0',
      (req) => {
        putInterceptFlag = true;
        req.reply({
          headers: {
            etag: getUniqueEtag()
          },
          statusCode: 200
        });
      }
    ).as('cons0Put');
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/1/items/1?fields=allowedSections&pageSize=100',
      {
        fixture: 'master-consignment-items.json'
      }
    ).as('cons1Item1');
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/0/items/1?fields=allowedSections&pageSize=100',
      {
        fixture: 'master-consignment-items.json'
      }
    ).as('cons0Item1');
    cy.fixture('codelist.json').then((data) => {
      codelist = data;
      cy.intercept('/assets/codelist/codelist.json', data).as('codeList');
    });
    page.visitConsignmentPartiesPage(consignment);
  }
);

Then('all sections {} should be displayed', (sectionList: string) => {
  sectionList.split(', ').forEach((section) => {
    page.validateSections(section);
  });
});

And('the title of the page is displayed', () => {
  page.validatePageTitleFull(appTitleFull);
});

And('the heading of the page is displayed', () => {
  page.validatePageHeaderTitle(pageHeading);
  page.validatePageHeaderUnderText(pageHeaderUnderText);
});
And('the heading of the {} parties page is displayed', (consignment) => {
  if (consignment === 'House') {
    page.getPageHeader().should('contain', ' Step 3: Parties ');
  } else {
    page.getPageHeader().should('contain', ' Step 2: Parties ');
  }
  page.validatePageHeaderUnderText(pageHeaderUnderText);
});

When('I Save the details for {}', (consignment) => {
  // TODO not yet implemented page.clickSave();
  if (consignment === 'Master') {
    cy.wait('@consignment0Info').then(() => {
      page.getNotifyPartyCheckBox().click();
      sections.forEach((s) => touchAllFields(s));
    });
  } else if (consignment === 'House') {
    cy.wait('@consignment1Info').then(() => {
      page.getNotifyPartyCheckBox().click();
      sections.forEach((s) => touchAllFields(s));
    });
  }
});

function touchAllFields(section) {
  page.getTypeOfPersonSelectBox(section).click().escape();
  page.getName(section).getTextField().click();
  page.getCommunicationTypeSelectBox(section).click().escape();
  page.getCommunicationIdentifier(section).getTextField().click();
  page.getStreet(section).getTextField().click();
  page.getAddressNumber(section).getTextField().click();
  page.getCountryAutocomplete(section).getTextField().click();
  page.getCity(section).getTextField().click();
  page.getPostCode(section).getTextField().click().blur();
}

Then('all mandatory fields should display errors', () => {
  sections.forEach((s) => validateMandatoryFieldErrors(s));
});

function validateMandatoryFieldErrors(section) {
  page
    .getTypeOfPersonSelectBox(section)
    .getError()
    .should('contain', selectTypeFieldError);
  page
    .getName(section)
    .getError()
    .should('contain.text', inputErrIn70LimitField);
  page
    .getCommunicationTypeSelectBox(section)
    .getError()
    .should('contain.text', selectTypeFieldError);
  page
    .getCommunicationIdentifier(section)
    .getError()
    .should('contain.text', inputErrIn512LimitField);
  page
    .getStreet(section)
    .getError()
    .should('contain.text', inputErrIn70LimitField);
  page
    .getAddressNumber(section)
    .getError()
    .should('contain.text', inputErrIn35LimitField);
  page
    .getCountryAutocomplete(section)
    .getError()
    .should('contain.text', selectTypeFieldError);
  page
    .getCity(section)
    .getError()
    .should('contain.text', inputErrIn35LimitField);
  page.getPostCode(section).should('contain.text', inputErrIn17LimitField);
}

When('I checked Notify Party checkbox on {} page', (consignment) => {
  if (consignment === 'Master') {
    cy.wait('@consignment0Info').then(() => {
      page.getNotifyPartyCheckBox().click();
    });
  } else if (consignment === 'House') {
    cy.wait('@consignment1Info').then(() => {
      page.getNotifyPartyCheckBox().click();
    });
  }
});

Then('Street field is not displayed for section {string}', (section) => {
  page.getStreet(section).should('not.exist');
});

When('I click on next button', () => {
  cy.wait('@consignments');
  page.getNextButton().click();
});

When('I click on save button', () => {
  cy.fixture('master-consignment-info-POBox.json').then((data) => {
    const updatedCons = {
      ...data
    };
    cy.intercept(
      '/api/v1/temporaryStorageDeclarations/1/consignments/0?fields=allowedSections',
      {
        body: updatedCons,
        headers: { etag: getUniqueEtag() }
      }
    ).as('consignment0InfoPO');
  });
  cy.fixture('house-consignment-info-POBox.json').then((data) => {
    const updatedCons = {
      ...data
    };
    cy.intercept(
      '/api/v1/temporaryStorageDeclarations/1/consignments/1?fields=allowedSections?pageSize=100',
      {
        body: updatedCons,
        headers: { etag: getUniqueEtag() }
      }
    ).as('consignment1InfoPO');
    cy.intercept(
      '/api/v1/temporaryStorageDeclarations/1/consignments/2?fields=allowedSections',
      {
        body: updatedCons,
        headers: { etag: getUniqueEtag() }
      }
    ).as('consignment2InfoPO');
  });
  page.getSaveButton().click();
});

When('I click on back button', () => {
  page.getBackButton().click();
});

And('I cancel details', () => {
  page.getCancelButton().click();
});

Then('I see all fields and checkboxes are cleared', () => {
  // TODO is this cleared or restored to previous value
});

Then('I see no errors', () => {
  sections.forEach((s) => page.getErrors(s).should('not.exist'));
});

And(
  'I click on add icon for communication type field under each section',
  () => {
    sections.forEach((s) => page.getAddCommunicationButton(s).click());
  }
);

Then(
  'I see {int} set of communication type and identifier fields',
  (count: number) => {
    sections.forEach((s) => {
      page.getCommunicationTypeSelectBox(s).should('have.length', count);
      page.getCommunicationIdentifier(s).should('have.length', count);
    });
  }
);

And('I see delete icons with both rows of fields', () => {
  sections.forEach((s) => {
    page.getDeleteCommunicationButton(s).should('have.length', 2);
  });
});

And('I see add icon is removed from first set of fields', () => {
  sections.forEach((s) => {
    page.getAddCommunicationButton(s).should('have.length', 1);
  });
});

And('I delete one of the fields', () => {
  sections.forEach((s) => {
    page.getDeleteCommunicationButton(s).first().click();
  });
});

And('I see add icon with only 1 row of fields', () => {
  sections.forEach((s) => {
    page.getAddCommunicationButton(s).should('have.length', 1);
  });
});

And('delete icon is not visible', () => {
  sections.forEach((s) => {
    page.getDeleteCommunicationButton(s).should('not.exist');
  });
});

And('I enter valid data in all sections', () => {
  sections.forEach((s) => inputDataInAllFields(s, s === CONSIGNEE));
});

When('I enter data more than allowed limit in each field', () => {
  sections.forEach((s) => inputFieldsToLimit(s, 1));
});
Then('PO box field is retained for {string} and {}', (section, consType) => {
  if (consType === 'Master') {
    cy.wait('@consignment0InfoPO');
    page.getPOBox(section).should('exist');
  } else {
    cy.wait('@consignment2InfoPO');
    page.getPOBox(section).should('exist');
  }
});
function inputDataInAllFields(section: string, po: boolean) {
  page.getTypeOfPersonSelectBox(section).selectOption('2 - Legal person');
  page.getIdentificationNumber(section).getTextField().fill('BE12345');
  page.getName(section).getTextField().fill('Luisa');
  page.getCommunicationTypeSelectBox(section).selectOption('E-mail address');
  page.getCommunicationIdentifier(section).getTextField().fill('abc@gmail.com');
  if (!po) {
    page.getAddressTypeSelectBox(section).selectOption('Street and number');
    page.getStreet(section).getTextField().fill('Carbusier St');
    page.getAddAdditionalStreetLineButton(section).click();
    page.getAddAdditionalStreetLineButton(section).should('not.exist');
    page.getAdditionalStreetLine(section).getTextField().fill('Room 301');
    page.getAddressNumber(section).getTextField().fill('20012');
    page.getPOBox(section).should('not.exist');
  } else {
    page.getAddressTypeSelectBox(section).selectOption('P.O. box');
    page.getPOBox(section).type('12345');
    page.getStreet(section).should('not.exist');
    page.getAddAdditionalStreetLineButton(section).should('not.exist');
    page.getAdditionalStreetLine(section).should('not.exist');
    page.getAddressNumber(section).should('not.exist');
  }

  page.getCountryAutocomplete(section).selectAutocomplete('Italy');
  page.getCity(section).getTextField().fill('Venice');
  page.getPostCode(section).getTextField().fill('200121');
  page.getSubdivison(section).getTextField().fill('DC region');
}

function inputFieldsToLimit(section: string, extra: number) {
  page
    .getIdentificationNumber(section)
    .getTextField()
    .fill(faker.random.alphaNumeric(17 + extra));
  page
    .getName(section)
    .getTextField()
    .fill(faker.random.alphaNumeric(70 + extra));
  page
    .getCommunicationIdentifier(section)
    .getTextField()
    .fill(faker.random.alphaNumeric(512 + extra));
  page
    .getStreet(section)
    .getTextField()
    .fill(faker.random.alphaNumeric(70 + extra));
  page
    .getAddressNumber(section)
    .getTextField()
    .fill(faker.random.alphaNumeric(35 + extra));
  page
    .getCity(section)
    .getTextField()
    .fill(faker.random.alphaNumeric(35 + extra));
  page
    .getPostCode(section)
    .getTextField()
    .fill(faker.random.alphaNumeric(17 + extra));
}

Then(
  'I see the input is trimmed upto the maximum limit allowed for the field',
  () => {
    sections.forEach((s) => validateFieldsMaxLength(s));
  }
);

function validateFieldsMaxLength(section: string) {
  page
    .getIdentificationNumber(section)
    .getTextField()
    .invoke('val')
    .should('have.length', 17);
  page.getName(section).getTextField().invoke('val').should('have.length', 70);
  page
    .getCommunicationIdentifier(section)
    .getTextField()
    .invoke('val')
    .should('have.length', 512);
  page
    .getStreet(section)
    .getTextField()
    .invoke('val')
    .should('have.length', 70);
  page
    .getAddressNumber(section)
    .getTextField()
    .invoke('val')
    .should('have.length', 35);
  page.getCity(section).getTextField().invoke('val').should('have.length', 35);
  page
    .getPostCode(section)
    .getTextField()
    .invoke('val')
    .should('have.length', 17);
}
When('I click on cancel without saving', () => {
  page.getCloseButton().click();
  cy.wrap(putInterceptFlag).should('eq', false);
});
When('I click on save changes for {}', (consignment) => {
  page.getCreateNewButton().click();
  if (consignment === 'Master')
    cy.wait('@cons0Put').then(() => {
      cy.wrap(putInterceptFlag).should('eq', true);
    });
  else if (consignment === 'House') {
    cy.wait('@cons1Put').then(() => {
      cy.wrap(putInterceptFlag).should('eq', true);
    });
  }
});
Then('I navigate to home screen', () => {
  page.isHomeScreen();
});
When('I click on Cancel', () => {
  page.getCancelButton().click();
});
When('I see unsaved changes dialog', () => {
  page.cancel().should('be.visible');
});

Then('I should navigate to {} previous page', (consignment) => {
  if (consignment === 'House') {
    cy.wait('@cons1Put');
    cy.wait('@consignment1Info').then(() => {
      page.validatePageHeaderTitle(consignment);
    });
  } else if (consignment === 'Master') {
    cy.wait('@cons0Put');
    cy.wait('@consignment0Info').then(() => {
      page.validatePageHeaderTitle(consignment);
    });
  }
});
And('URL of the page is changed {}', (consignment) => {
  page
    .getPageURL()
    .should('contain', consignment.toLowerCase() + '-con-gen-info', {
      matchCase: false
    });
});

Then('I moved to {} item page', (consignment) => {
  page.getPageURL().should('contain', consignment.toLowerCase() + '-con-items');
});
