///<reference types = "Cypress"/>
import { And, Given, Then, When } from 'cypress-cucumber-preprocessor/steps';
import { getUniqueEtag } from '../../common/util';
import { DeclarationPartiesPage } from './declaration-parties.po';
const faker = require('faker');
let page = new DeclarationPartiesPage();
let codeList: any;
let crsData: any;
let partyData: any;
var appTitleFull = ' Temporary storage declaration ';
var pageHeading =
  ' Select the actors that are involved and enter the information ';
const COMBINED = 'combined';
const PRELODGED = 'prelodged';
const DECLARANT = 'Declarant';
const REPRESENTATIVE = 'Representative';
const GOODS = 'Person presenting the goods';
const CARRIER = 'Carrier';
let putInterceptFlag = false;

Given(
  'I have navigated to the Declaration Parties page with type {}',
  (type) => {
    putInterceptFlag = false;
    cy.fixture('tsd-empty-declaration.json').then((data) => {
      const updatedData = {
        ...data,
        type: type
      };
      cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1', {
        body: updatedData,
        headers: { etag: getUniqueEtag() }
      }).as('declaration');
    });
    cy.intercept('PUT', '/api/v1/temporaryStorageDeclarations/1', (req) => {
      putInterceptFlag = true;
      req.reply({ statusCode: 200 });
    }).as('generalInfoPut');
    page.visit();
  }
);
Given('I navigate to the Declaration Parties page with type {}', (type) => {
  putInterceptFlag = false;
  cy.fixture('tsd-empty-party.json').then((data) => {
    const updatedData = {
      ...data,
      type: type
    };
    cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1', {
      body: updatedData,
      headers: { etag: getUniqueEtag() }
    }).as('declaration');
  });
  cy.intercept('PUT', '/api/v1/temporaryStorageDeclarations/1', (req) => {
    putInterceptFlag = true;
    req.reply({ statusCode: 200 });
  }).as('generalInfoPut');
  page.visit();
});
Given('the CRS mock data and codelist is setup', () => {
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments?fields=draftErrors&pageSize=100',
    {
      fixture: 'houseList.json'
    }
  ).as('consignments');
  cy.fixture('partyData.json').then((data) => {
    crsData = data;
    cy.intercept('/assets/crs-mock/partyData.json', data).as('crsData');
  });
  cy.fixture('codelist.json').then((data) => {
    codeList = data;
    cy.intercept('/assets/codelist/codelist.json', data).as('codeList');
  });
});
When('I check representative section', () => {
  cy.wait('@declaration').then(() => {
    page.selectRepresentativeCheckBox();
  });
});
Then('I see the Declaration Parties page with representative section', () => {
  page.getAppTitle().should('have.text', appTitleFull);
  page.getPageHeader().should('have.text', pageHeading);
  page.validateRepresentativeCheckBox();
});
And('I enter declarant EORI {}', (eoriNum) => {
  if (crsData.partyList.find((el) => el.id === eoriNum)) {
    partyData = crsData.partyList.find((el) => el.id === eoriNum);
  }
  page.inputDeclarantEori(eoriNum);
  page.getPageHeader().click();
});
And('I enter representative EORI {}', (eoriNum) => {
  if (crsData.partyList.find((el) => el.id === eoriNum)) {
    partyData = crsData.partyList.find((el) => el.id === eoriNum);
  }
  page.inputRepresentativeEori(eoriNum);
  page.getPageHeader().click();
});
When('I enter Person presenting the goods EORI {}', (eoriNum) => {
  if (crsData.partyList.find((el) => el.id === eoriNum)) {
    partyData = crsData.partyList.find((el) => el.id === eoriNum);
  }
  page.inputPersonPresentingGoodsEori(eoriNum);
  page.getPageHeader().click();
});
When('I enter Carrier EORI {}', (eoriNum) => {
  if (crsData.partyList.find((el) => el.id === eoriNum)) {
    partyData = crsData.partyList.find((el) => el.id === eoriNum);
  }
  page.inputCarrierEori(eoriNum);
  page.getPageHeader().click();
});
And('I fill in all required fields for {}', (type: string) => {
  if (type.toLowerCase() === COMBINED) {
    page.inputDeclarantEori('BE0214596464');
    page.inputPersonPresentingGoodsEori('BE0214596464');
    page.inputCarrierEori('BE0214596464');
  } else if (type.toLowerCase() === PRELODGED) {
    page.inputDeclarantEori('BE0214596464');
  }
});
And('I fill in all required fields for {} with invalid data', (type) => {
  if (type === 'Combined' || type.toLowerCase() === COMBINED) {
    page.inputDeclarantEori('BE0214596');
    page.inputPersonPresentingGoodsEori('BE021459646');
    page.inputCarrierEori('BE021459646');
  } else {
    page.inputDeclarantEori('BE021459646');
  }
});
When('I click on the add button of communication', () => {
  page.clickAddCommunication();
});
When('I click on Save', () => {
  page.clickSave();
});
When('I click on the delete button of newly added communication', () => {
  page.clickRemoveCommunication();
});
When('added communication type and identifier are empty', () => {
  page.inputCommunicationTypeIdentifier();
  page.getPageHeader().click();
});
When(
  'I enter more data than allowed in each field marked with max characters',
  () => {
    page.inputRepresentativeEori(faker.random.alphaNumeric(18));
    page.inputPersonPresentingGoodsEori(faker.random.alphaNumeric(18));
    page.inputCarrierEori(faker.random.alphaNumeric(18));
    page.inputIdentifier(faker.random.alphaNumeric(513));
  }
);
When('I select Status', () => {
  page.selectRepresentativeStatus();
});
Then('I see communication type and identifier added', () => {
  page.verifyCommunicationTypeAndIdentifier();
});
Then('I see communication type and identifier removed', () => {
  page.verifyCommunicationTypeRemoved().should('have.length', 1);
  page.verifyCommunicationIdentifierRemoved().should('have.length', 1);
});
Then('the Declarant section is correctly filled in', () => {
  page.verifyDeclarantSection(partyData);
});
Then('the Representative section is correctly filled in', () => {
  page.verifyRepresentativeSection(partyData);
});
Then('the Person presenting the goods section is correctly filled in', () => {
  page.verifyGoodsSection(partyData);
});
Then('the Carrier section is correctly filled in', () => {
  page.verifyCarrierSection(partyData);
});
Then('error for Declarant eori should be displayed', () => {
  page.verifyDeclarantEORIError();
});
Then('error for Representative EORI should be displayed', () => {
  page.verifyRepresentativeEORIError();
});
Then('error for Person presenting the goods EORI should be displayed', () => {
  page.verifyGoodsEORIError();
});
Then('error for Carrier EORI should be displayed', () => {
  page.verifyCarrierEORIError();
});
Then(
  'error for empty communication type and identifier should be displayed',
  () => {
    page.verifyEmptyCommunicationFieldErrors();
  }
);
Then('error for same EORI number should be displayed', () => {
  page.verifyRepresentativeEORIError();
});
Then('no errors are shown', () => {
  page.verifyThereAreNoErrors();
});
Then('I see all required fields in error for {}', (type) => {
  if (type === COMBINED) {
    page.verifyThereAreErrorsCombined();
  } else {
    page.verifyThereAreErrors();
  }
});

Then(
  'I see that the input is trimmed upto the maximum allowed limit for that field',
  () => {
    page.validateDeclarantEoriMaxLimit();
    page.validateRepresentativeEoriMaxLimit();
    page.validateGoodsEoriMaxLimit();
    page.validateCarrierEoriMaxLimit();
    page.validateIdentifierMaxLimit();
  }
);
Then('I see the following sections {}', (sectionName) => {
  const sections: string[] = sectionName.split(',');
  sections.forEach((section) => {
    if (section === DECLARANT) {
      page.validateDeclarantSection();
    } else if (section === REPRESENTATIVE) {
      page.validateRepresentativeSection();
    } else if (section === GOODS) {
      page.validateGoodsSection();
    } else if (section === CARRIER) {
      page.validateCarrierSection();
    }
  });
});
When('I click on cancel without saving', () => {
  page.getCloseButton().click();
  cy.wrap(putInterceptFlag).should('eq', false);
});
When('I click on save changes', () => {
  page.getCreateNewButton().click();
  cy.wait('@generalInfoPut').then(() => {
    cy.wrap(putInterceptFlag).should('eq', true);
  });
});
Then('I navigate to home screen', () => {
  page.isHomeScreen();
});
When('I click on Cancel', () => {
  page.getCancelButton().click();
});
When('I see unsaved changes dialog', () => {
  page.cancel().should('be.visible');
});
