///<reference types = "Cypress"/>

export class DeclarationPartiesPage {
  declarationPartiesPath = '/tsd/parties-form';
  tsdTypeFlag = '';

  setQueryParams(tsdTypeFlag: 'prelodged' | 'combined') {
    this.tsdTypeFlag = tsdTypeFlag;
  }

  visit() {
    cy.loginWithEO();
    cy.visit('/edit-declaration' + this.declarationPartiesPath, {
      qs: {
        tsdId: 1
      }
    });
    // cy.injectAxe();
  }

  getAppTitle() {
    return cy
      .get('div.app-title-full')
      .contains('Temporary storage declaration');
  }

  getPageHeader() {
    return cy.get('[data-testid="partyTitle"]');
  }
  selectRepresentativeCheckBox() {
    cy.get('mat-checkbox#repCheckBox').click();
  }
  clickAddCommunication() {
    cy.get('button[data-testid="addComm"]').first().click();
  }
  clickRemoveCommunication() {
    cy.get('[id^="removeComm"]').click();
  }
  inputCommunicationTypeIdentifier() {
    cy.get('[data-testid="commType"]').last().click();
    cy.escape();
    cy.get('[data-testid="identifier"]').last().click();
    cy.escape();
  }
  verifyCommunicationTypeAndIdentifier() {
    cy.get('[data-testid="commType"]').last().should('be.visible');
    cy.get('[data-testid="identifier"]').last().should('be.visible');
  }
  verifyCommunicationTypeRemoved() {
    return cy.get('[data-testid="commType"]');
  }
  verifyCommunicationIdentifierRemoved() {
    return cy.get('[data-testid="identifier"]');
  }

  verifyDeclarantSection(party: any) {
    cy.get('[data-testid="declarantEoriName"] input')
      .invoke('val')
      .should('contain', party.name);
    cy.get('.commTypeClass').should('have.length', party.communication.length);
  }
  verifyRepresentativeSection(party: any) {
    cy.get('#repEoriName').should('have.value', party.name);
    cy.get('.repCommType').should('have.length', 1);
  }
  verifyGoodsSection(party: any) {
    cy.get('#goodsEoriName').should('have.value', party.name);
  }
  verifyCarrierSection(party: any) {
    cy.get('#carrierEoriName').should('have.value', party.name);
  }
  verifyDeclarantEORIError() {
    cy.get('#eoriInvalid').should('be.visible');
  }
  verifyRepresentativeEORIError() {
    cy.get('#repEoriInvalid').should('be.visible');
  }
  verifyGoodsEORIError() {
    cy.get('#goodsInvalidEori').should('be.visible');
  }
  verifyCarrierEORIError() {
    cy.get('#carrierInvalidEori').should('be.visible');
  }
  verifyEmptyCommunicationFieldErrors() {
    cy.get('#commTypeError2').should('be.visible');
    cy.get('#identifierError2').should('be.visible');
  }
  verifyThereAreNoErrors() {
    cy.get('#eoriInvalid').should('not.exist');
    cy.get('#repStatusInvalid').should('not.exist');
    cy.get('#goodsInvalidEori').should('not.exist');
    cy.get('#carrierInvalidEori').should('not.exist');
    cy.get('#repEoriInvalid').should('not.exist');
  }
  verifyThereAreErrors() {
    cy.get('#eoriInvalid').should('be.visible');
    cy.get('#repStatusInvalid').should('be.visible');
    cy.get('#repEoriInvalid').should('be.visible');
  }
  verifyThereAreErrorsCombined() {
    cy.get('#goodsInvalidEori').should('be.visible');
    cy.get('#carrierInvalidEori').should('be.visible');
  }
  validateRepresentativeCheckBox() {
    cy.get('mat-checkbox#repCheckBox').should(
      'have.class',
      'mat-checkbox-checked'
    );
  }
  selectRepresentativeStatus() {
    cy.get('#repEoriStatus').selectOption('Direct');
  }
  inputDeclarantEori(eoriNum) {
    cy.get('[data-testid="declarantEori"]').click().clear().type(eoriNum);
  }
  inputRepresentativeEori(eoriNum) {
    cy.get('input#repEoriNumber').click().type(eoriNum);
  }
  inputPersonPresentingGoodsEori(eoriNum) {
    cy.get('input#goodsEoriNumber').click().type(eoriNum);
  }
  inputCarrierEori(eoriNum) {
    cy.get('input#carrierEoriNumber').click().type(eoriNum);
  }
  inputIdentifier(eoriNum) {
    cy.get('[data-testid="identifier"]').last().click().fill(eoriNum);
  }
  validateDeclarantEoriMaxLimit() {
    cy.get('[data-testid="declarantEori"]').should('have.length.lte', 17);
  }
  validateRepresentativeEoriMaxLimit() {
    cy.get('input#repEoriNumber').should('have.length.lte', 17);
  }
  validateGoodsEoriMaxLimit() {
    cy.get('input#goodsEoriNumber').should('have.length.lte', 17);
  }
  validateCarrierEoriMaxLimit() {
    cy.get('input#carrierEoriNumber').should('have.length.lte', 17);
  }
  validateIdentifierMaxLimit() {
    cy.get('[data-testid="identifier"]').last().should('have.length.lte', 512);
  }
  clickSave() {
    cy.get('#save').click();
  }
  validateDeclarantSection() {
    cy.get('[data-testid="declarantHeading"]').should('be.visible');
  }
  validateRepresentativeSection() {
    cy.get('mat-checkbox#repCheckBox').should('be.visible');
  }
  validateGoodsSection() {
    cy.get('[data-testid="goodsTitile"]').should('be.visible');
  }
  validateCarrierSection() {
    cy.get('[data-testid="carrierTitle"]').should('be.visible');
  }
  cancel() {
    return cy.get('[data-testid="errorPopup"]');
  }
  getCloseButton() {
    return cy.get('[data-testid="errorCloseBtn"]');
  }
  getCreateNewButton() {
    return cy.get('[data-testid=CreateNewBtn]');
  }
  isHomeScreen() {
    cy.get('.home > span').should('contain', 'Welcome to TSD Angular UI App!!');
  }
  getCancelButton() {
    return cy.get('#cancel');
  }
}
