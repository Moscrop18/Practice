///<reference types = "Cypress"/>

import { contains } from 'cypress/types/jquery';
import { isNull, xorBy } from 'cypress/types/lodash';
import { path } from 'cypress/types/lodash/fp';

export class HouseConsignInfoPage {
  homePath = '/home';
  houseConsignmentInfoPath = '/edit-declaration/tsd/house-con-gen-info';
  houseConsignmentItemPath = '/edit-declaration/tsd/house-con-items';
  tsdTypeFlag = ''; //tsdType=prelodged or combined  &ensReuse=false"
  ensReuseFlag = 'false'; //False or True
  seq = '1';

  //-----------------------Actions--------------------------------

  getQueryParams(queryParams: string) {
    cy.location().should((loc) => {
      expect(loc.search).to.eq(queryParams);
    });
  }

  visit() {
    cy.loginWithEO();
    cy.visit(this.houseConsignmentInfoPath, {
      qs: {
        tsdId: 1,
        consNo: 1
      }
    });
  }
  visitHouseConsignment() {
    cy.loginWithEO();
    cy.visit(this.houseConsignmentInfoPath, {
      qs: {
        tsdId: 955,
        consNo: 1
      }
    });
  }
  visitItemPage() {
    cy.loginWithEO();
    cy.visit(this.houseConsignmentItemPath, {
      qs: {
        tsdId: 1,
        consNo: 1,
        itemNo: 1
      }
    });
  }

  getURL() {
    return cy.url();
  }
  getTransportDocumnet(): Cypress.Chainable<any> {
    return cy.get('[data-testid=transDocHeaderText]');
  }
  getPreviousDocumnet(): Cypress.Chainable<any> {
    return cy.get('[data-testid=prevDocHeaderText]');
  }
  getWeight(): Cypress.Chainable<any> {
    return cy.get('[data-testId="weightHeaderText"]');
  }
  getReferenceNumberUcr(): Cypress.Chainable<any> {
    return cy.get('#rnuCheck');
  }
  getTransportEquipment(): Cypress.Chainable<any> {
    return cy.get('#teCheck');
  }
  getReceptacles(): Cypress.Chainable<any> {
    return cy.get('#recCheck');
  }
  getSupportingDocument(): Cypress.Chainable<any> {
    return cy.get('#sdCheck');
  }
  getAdditionalInformation(): Cypress.Chainable<any> {
    return cy.get('#addInfoCheck');
  }

  getPageURL() {
    return cy.location('pathname');
  }
  validateURLPath() {
    cy.url().should('include', this.houseConsignmentInfoPath);
  }

  isVisible(type: string, ens: boolean, seq: string) {
    cy.location('href').should(
      'contain',
      '/house-con-gen-info?tsdType=' + type + '&' + ens + '&' + seq
    );
    this.getPageHeader().contains(' Step 2: House Consignment ');
    this.getAppTitle().contains('Temporary Storage Declaration');
  }

  getAppTitle() {
    return cy.get('div.app-title-full');
  }

  getPageHeader() {
    return cy.get('div#consignmentTitle');
  }

  clickHouseConsignmentSection() {
    cy.get('div a').should('include.text', 'House consignment').click();
  }

  getOverlay() {
    return cy.get('.custom-overlay');
  }

  validateGeneralInformationSection() {
    cy.get('div a').should('include.text', 'General information');
  }

  selectPreviousDocumentCheckBox() {
    cy.get('#pdCheck').click();
  }

  countCheckBoxes() {
    cy.get('.mat-checkbox').should('have.length', 7);
  }
  clickOutside() {
    cy.escape().click();
  }
  getSaveButton() {
    return cy.get('#save');
  }

  verifySectionNames(reuse) {
    if (reuse === true) {
      this.countFieldWithNoCheckBox();
    } else {
      this.countCheckBoxes();
    }
  }
  //-------------Add Item under each section

  addItemTransportEquipment() {
    cy.get('#containerAddButton').click();
  }

  addItemReceptacle() {
    cy.get('#receptacleAddButton').click();
  }

  addItemSupportingDocCheckBox() {
    cy.get('#sdAddButton').click();
  }

  addItemAdditionalInfoCheckBox() {
    cy.get('button#addButton').click();
  }

  addItemAdditionalSupplyChainCheckBox() {
    cy.get('button#addSuppButton').click();
  }

  getSection(section) {
    if (section === 'Transport equipment') {
      return cy.get('[data-testId="transEquipContainer"]');
    } else if (section === 'Receptacle(s)') {
      return cy.get('[id^="mat-expansion-panel-header"]');
    } else if (section === 'Supporting document(s)') {
      return cy.get('[id^="mat-expansion-panel-header"]');
    } else if (section === 'Additional information(s)') {
      return cy.get('[id^="mat-expansion-panel-header"]');
    } else if (section === 'Additional supply chain actor') {
      return cy.get('[id^="mat-expansion-panel-header"]');
    } else {
      console.log('No or invalid input');
      throw console.error('No or invalid input');
    }
  }

  validateItemsAdded(section) {
    this.getSection(section).should('have.length', 2);
  }

  validateColapsedItem(section) {
    this.getSection(section)
      .first()
      .should('have.attr', 'aria-expanded', 'false');
  }

  validateExpandedItem(item, section) {
    this.getSection(section)
      .last()
      .should('have.attr', 'aria-expanded', 'true');
  }

  deleteItemFromSection(item, section) {
    if (section === 'Transport Equipment') {
      cy.get('[id^="containerRemoveButton"]').first().click();
    } else if (section === 'Receptacle(s)') {
      cy.get('[id^="receptacleRemoveButton"]').first().click();
    } else if (section === 'Supporting document(s)') {
      cy.get(
        '[data-testid="supportingDocumentItem"] [id^="containerRemoveButton"]'
      )
        .first()
        .click();
    } else if (section === 'Additional information(s)') {
      cy.get(
        '[data-testid="additionalInformationItem"] [id^="containerRemoveButton"]'
      )
        .first()
        .click();
    } else if (section === 'Additional supply chain actor') {
      cy.get(
        '[data-testid="supplyChainActorPanel"] [id^="containerRemoveButton"]'
      )
        .first()
        .click();
    } else {
      console.log('No delete icon found or invalid section selected');
    }
  }

  validateItemAfterDelete(section) {
    if (section === 'Transport Equipment') {
      cy.get('[data-testId="transEquipContainer"]').should(
        'have.attr',
        'aria-expanded',
        'true'
      );
    } else if (section === 'Receptacle(s)') {
      cy.get('[id^="mat-expansion-panel-header"]').should(
        'have.attr',
        'aria-expanded',
        'true'
      );
    } else if (section === 'Supporting document(s)') {
      cy.get('[data-testId="supportingDocumentItem"]').should(
        'have.attr',
        'aria-expanded',
        'true'
      );
    } else if (section === 'Additional information(s)') {
      cy.get('[id^="mat-expansion-panel-header"]').should(
        'have.attr',
        'aria-expanded',
        'true'
      );
    } else if (section === 'Additional supply chain actor') {
      cy.get('[data-testId="supplyChainActorPanel"]').should(
        'have.attr',
        'aria-expanded',
        'true'
      );
    } else {
      console.log('Section not checked or invalid section selected');
    }
  }

  validateDeleteIconOnItem(item, section) {
    if (section === 'Transport Equipment') {
      cy.get('[data-testId="transEquipContainer"]').should(
        'not.have.id',
        '#deletePanel'
      );
    } else if (section === 'Receptacle(s)') {
      cy.get('[id^="receptaclePanelTitle"]').should(
        'not.have.id',
        '#deletePanel'
      );
    } else if (section === 'Supporting document(s)') {
      cy.get('[data-testId="supportingDocumentItem"]').should(
        'not.have.id',
        '#deletePanel'
      );
    } else if (section === 'Additional information(s)') {
      cy.get('[data-testId="additionalInformationItem"]').should(
        'not.have.id',
        '#deletePanel'
      );
    } else if (section === 'Additional supply chain actor') {
      cy.get('[data-testId="supplyChainActorPanel"]').should(
        'not.have.id',
        '#deletePanel'
      );
    } else {
      console.log('Section not checked or invalid section selected');
    }
  }

  validateSections(section) {
    if (section === 'TransportDocument') {
      cy.get('[data-testId="transDocHeaderText"]').should(
        'contain.text',
        'Transport document'
      );
    } else if (section === 'Weight') {
      cy.get('[data-testId="weightHeaderText"]').should('have.text', section);
    } else if (section === 'PreviousDocument') {
      cy.get('[data-testid="prevDocHeaderText"]').should(
        'contain',
        'Previous document'
      );
    } else if (section === 'ReferenceNumberUCR') {
      cy.get('#rnuCheck').should('contain.text', 'Reference number UCR');
    } else if (section === 'TransportEquipment') {
      cy.get('#teCheck').should('contain.text', 'Transport equipment');
    } else if (section === 'Receptacle') {
      cy.get('#recCheck').should('contain.text', 'Receptacle(s)');
    } else if (section === 'SupportingDocument') {
      cy.get('#sdCheck').should('contain.text', 'Supporting document(s)');
    } else if (section === 'AdditionalInformation') {
      cy.get('#addInfoCheck').should('contain', 'Additional information(s)');
    } else if (section === 'AdditionalSupplyChainActor') {
      cy.get('#ascaCheck').should(
        'contain.text',
        'Additional supply chain actor'
      );
    } else {
      console.log('no section matched');
    }
  }

  //------------------------------Verify Item sections

  inputNumberOfSeals(numberOfSeals) {
    cy.get('input#teNoOfSeal1').fill(numberOfSeals);
  }

  hasNumberOfSealsInvalidDataError(sealInvalidDataError) {
    cy.get('#consignmentTitle').click();
    cy.get('div > mat-error').should('contain.text', sealInvalidDataError);
  }

  validateSealAddButtonDisabled() {
    cy.get('#teAddSealIdentifier').should('have.class', 'mat-button-disabled');
  }

  validateSealAddButtonEnabled() {
    cy.get('#teAddSealIdentifier').should('not.have.attr', 'disabled');
  }

  validateSealIdentifierField() {
    cy.get('input#teSealIdentifier').should('exist');
  }

  clickAddIconOfSealIdentifier() {
    cy.get('button#teAddSealIdentifier').click();
  }

  validateDeleteSealIdIcon() {
    cy.get('button#teRemSealIdentifier').should('exist');
  }

  clickDeleteSealIcon() {
    cy.get('button#teRemSealIdentifier').first().click();
  }
  compareSealValueWithInput() {
    cy.get('input#teNoOfSeal1').should('have.length.lte', 5);
  }

  clickAddSealIdentifierItem() {
    cy.get('button#teAddSealIdentifier').click();
  }

  inputReceptacleIdNumber(receptacleIdNumber) {
    cy.get('input#recIdentificationNum').click().fill(receptacleIdNumber);
  }

  getReceptacleIdNumberLength(receptacleIdNumber) {
    //const recIdLength = receptacleIdNumber.its('length');

    //max length is 35
    cy.get('input#recIdentificationNum')
      .fill(receptacleIdNumber)
      .its('length')
      .should('be.lte', 35);
  }

  getSupportingDocuentRefNumberLength() {
    cy.get('input#sdRefNum').its('length').should('be.lte', 70);
  }

  selectSupportingDocumentCheckBox() {
    cy.get('mat-checkbox#sdCheck').click();
  }

  selectSupportingDocumentType(documentType) {
    cy.get('#supportingDocumentType').type(documentType);
  }

  inputSupportingDocumentRefNumber(documentReferenceNumber) {
    cy.get('input#sdRefNum').fill(documentReferenceNumber);
  }

  inputAdditionalInformationText(additionalInfoText) {
    cy.get('textarea#note').fill(additionalInfoText);
  }

  getAdditionalInformationTextArea(): Cypress.Chainable<any> {
    return cy.get('textarea#note');
  }

  getAdditionalInformationTextAreaTotalCountFooter(): Cypress.Chainable<any> {
    return cy.get('[data-testid="charCount"]');
  }

  inputAdditionalSupplyChainEori(eori) {
    cy.get('input#ascaEori').fill(eori);
    cy.get('div').first().click(); //can be removed once save or next button start working
    //this.clickSave();
  }

  hasInvalidEoriError(message) {
    cy.get('mat-error').contains(message);
  }

  validateAdditionalSupplychainNameField() {
    cy.get('input#ascaName').should('have.attr', 'readonly', 'readonly');
  }

  selectAdditionalSupplyChainRole(role) {
    cy.get('#ascaRole').selectOption(role);
  }

  getHouseConsignmentTab() {
    return cy.get('[id^="House"]');
  }

  getAddItemIcon() {
    return cy.get('#add-step2');
  }

  //------------------------------------------

  validateNoErrors() {
    cy.get('mat-error').should('not.exist');
  }
  validatePreviousDocumentCheckBoxIsChecked() {
    cy.get('#pdCheck').should('have.class', 'mat-checkbox-checked');
  }

  validateReferenceNumberUcrCheckBox() {
    cy.get('#rnuCheck').should('have.class', 'mat-checkbox-checked');
  }

  validateTransportEquipmentCheckBox() {
    cy.get('#teCheck').should('have.class', 'mat-checkbox-checked');
  }

  validateReceptacleCheckBox() {
    cy.get('#recCheck').should('have.class', 'mat-checkbox-checked');
  }

  validateSupportingDocumentCheckBox() {
    cy.get('#sdCheck').should('have.class', 'mat-checkbox-checked');
  }

  validateAdditionalInformationCheckBox() {
    cy.get('#addInfoCheck').should('have.class', 'mat-checkbox-checked');
  }

  validateAdditionalSupplyChainActorCheckBox() {
    cy.get('#ascaCheck').should('have.class', 'mat-checkbox-checked');
  }

  validatePreviousDocumentTypeNotVisible() {
    cy.get('#pdCheck').should('not.have.class', 'mat-checkbox-checked');
  }

  selectTransportDocType(transDocTypeValue) {
    cy.get('#tdType').click().selectOption(transDocTypeValue); //need to convert to dynamic input
  }

  fillRequiredFieldsForReuse() {
    this.selectTransportDocType('C624 - Form 302');
    this.inputTransportDocumentReferenceNumber('12345abcde');
    this.selectPreviousDocumentType('N355 - Entry Summary Declaration');
    this.inputPreviousDocumentRefNumber('1234567812345678T');
  }

  fillRequiredFieldsForNoReuse() {
    this.selectTransportDocType('C624 - Form 302');
    this.inputTransportDocumentReferenceNumber('12345abcde');
    this.inputValidWeight('1009.003407');
    this.selectPreviousDocumentType(' N821 - Transit Declaration ');
    this.inputPreviousDocumentRefNumber('abcde12345');
  }
  inputTransportDocumentReferenceNumber(transDocRef) {
    cy.get('input#tdRefNum').click().fill(transDocRef);
  }

  inputInvalidTransportDocumentRefNumber() {
    //70 max characters allowed
    cy.get('input#tdRefNum').fill(
      '4gtfobprx1fbxenToem62k2p5skhe7yful3utmxc8gcovw9r6d2vfqdjf67rwx0jawmrgsj1a2b3c'
    );
  }

  inputValidWeight(vWeight) {
    cy.get('#tdWeight').type(vWeight);
  }

  inputInValidWeight(nvWeight) {
    cy.get('#tdWeight').type(nvWeight);
  }

  selectPreviousDocumentType(
    prevDocTypeValue:
      | ' N821 - Transit Declaration '
      | 'N355 - Entry Summary Declaration'
  ) {
    cy.get('#pdType').selectOption(prevDocTypeValue);
  }

  inputPreviousDocumentRefNumber(prevDocRefNum) {
    cy.get('#pdRefNum').fill(prevDocRefNum);
  }

  inputInvalidPreviousDocumentRefNumber() {
    //max 70 caharacters allowed
    cy.get('#pdRefNum')
      .click()
      .fill(
        '4gtfobprx1fbxTenoem62k2p5skhe7yful3utmxc8gcovw9r6d2vfqdjf67rwx0jawmrgsj1a2b3c'
      );
  }

  selectReferenceNumberUcrCheckBox() {
    cy.get('#rnuCheck')
      .should('not.have.class', 'mat-checkbox-checked')
      .click();
  }

  inputReferenceNumberUCR(ucrNumber: string) {
    if (ucrNumber.length === 0) {
      cy.get('#rnuRefNum').clear();
      this.clickOutside();
    } else {
      cy.get('#rnuRefNum');
    }
  }

  inputInvalidReferenceNumberUcr() {
    //max 35 characters allowed
    cy.get('#rnuRefNum')
      .click()
      .fill('bn5lij8rq85s0bhrpkktxues47dhsh70lci1a2b3c');
  }

  selectTransportEquipmentCheckBox() {
    cy.get('#teCheck').click().should('have.class', 'mat-checkbox-checked');
  }

  inputInvalidTransportEquipmentIdNumber() {
    //max 11 with format zzzz9999999
    cy.get('#tdIdentificationNum1').fill('AaaZ123456789');
  }

  inputTransportEquipmentNumber(equipNumber) {
    cy.get('input#tdIdentificationNum1').fill(equipNumber);
  }

  selectTransportEquipmentContainerStatus(packedStatus) {
    cy.get('#teConPackStatus1')
      .getDefaultOption('-')
      .should('have.length', 1)
      .get('#teConPackStatus1')
      .selectOption(packedStatus);
  }

  inputInvalidReceptacleIdNumber() {
    //max allowed limit 35 characters
    cy.get('#recIdentificationNum').fill(
      'bn5lij8rq85s0bhrpkktxues47dhsh70lci1a2b3c'
    );
  }

  selectReceptacleCheckBox() {
    cy.get('div>#recCheck')
      .click()
      .should('have.class', 'mat-checkbox-checked');
  }

  selectSupportingDocCheckBox() {
    cy.get('#sdCheck').click().should('have.class', 'mat-checkbox-checked');
  }

  inputInvalidSupportingDocumentRefNumber() {
    //max allowed limit 70 characters
    cy.get('#referenceNumber').fill(
      '4gtfobprx1fbxenoem62k2p5skhe7yful3utmxc8gcovw9r6d2vfqdjf67rwx0jawmrgsj1a2b3c'
    );
  }

  inputInvalidAdditionalSupplyChainActorEori() {
    //max 17 characters of type AEOC or AEOF
    cy.get('#eori').fill('BE02145964647');
  }

  validateTransportDocumentMaxLimit() {
    //max length is 70
    cy.get('input#tdRefNum').should('have.length.lte', 70);
  }

  validateWeightMaxLimit() {
    //max length is 16
    cy.get('#tdWeight').should('have.length.lte', 16);
    cy.get('#tdWeight').should(($input) => {
      const text = $input.val();
      expect(text).to.match(/^[1-9.]+[0-9]*$/);
    });
  }
  validatePreviousDocRefNumMaxLimit() {
    //max limit is 70
    cy.get('input#pdRefNum').should('have.length.lte', 70);
  }

  validateReferenceNumberUcrMaxLimit() {
    //max limit is 35
    cy.get('input#rnuRefNum').should('have.length.lte', 35);
  }

  validateTransportEquipmentIdNumberMaxLimit() {
    //max limit is 11 in format zzzz9999999
    cy.get('input#tdIdentificationNumber1').should('have.length.lte', 11);
  }

  validateReceptacleIdNumberMaxLimit() {
    //max limit is 35
    cy.get('input#recIdentificationNum').should('have.length.lte', 35);
  }

  validateSupportingDocumentRefNumberMaxLimit() {
    //max limit is 70
    cy.get('input#sdRefNum').should('have.length.lte', 70);
  }

  selectAdditionalInfoCheckBox() {
    cy.get('#addInfoCheck')
      .click()
      .should('have.class', 'mat-checkbox-checked');
  }

  selectAdditionalSupplyChainCheckBox() {
    cy.get('#ascaCheck').click().should('have.class', 'mat-checkbox-checked');
  }

  ////For retrieving Errors

  hasTransportDocumentTypeError(message: string) {
    if (cy.get('#tdType').should('have.length', 1)) {
      this.clickSave();
      cy.get('mat-error#mat-error-0').should('contain', message);
    } else {
      expect(true).to.equal(true);
    }
  }
  hasTransportDocumentReferenceError(message: string) {
    if (cy.get('input#tdRefNum').should('have.length', 1)) {
      this.clickSave();
      cy.get('mat-error#tdRefNumRequiredError').should('contain', message);
    } else {
      expect(true).to.equal(true);
    }
  }
  hasWeightFieldError(message: string) {
    if (cy.get('#tdWeight').should('have.length', 1)) {
      this.clickSave();
      cy.get('mat-error#mat-error-0').should('contain', message);
    } else {
      expect(true).to.equal(true);
    }
  }
  hasPreviousDocumentTypeError(message: string) {
    if (cy.get('#tdType').should('have.length', 1)) {
      this.clickSave();
      cy.get('mat-error[id^="mat-error"]').should('contain', message);
    } else {
      expect(true).to.equal(true);
    }
  }
  hasPreviousDocumentReferenceError(message: string) {
    if (cy.get('#pdRefNum').should('have.length', 1)) {
      this.clickSave();
      cy.get('mat-error#prevDocRequired').should('contain', message);
    } else {
      expect(true).to.equal(true);
    }
  }
  hasReferenceNumberUCRError(message: string) {
    if (cy.get('input#rnuRefNum').clear().should('have.length', 1)) {
      //this.clickSave();
      this.clickOutside();
      cy.get('mat-error#ucrRequired').should('contain', message);
    } else {
      expect(true).to.equal(true);
    }
  }
  hasTransportEquipmentIdNumberError(message: String) {
    if (cy.get('input#tdIdentificationNum1').clear().should('have.length', 1)) {
      this.clickSave();
      cy.get('mat-error[id^="mat-error"]').should('contain', message);
    } else {
      expect(true).to.equal(true);
    }
  }
  hasTransportEquipmentContainerStatusError(message: string) {
    cy.get('#teConPackStatus').click();
    this.clickSave();
    cy.get('mat-error[id^="mat-error"]').should('contain', message);
  }

  hasContainerSealIdentifierError(message, sealId) {
    if (sealId === '') {
      this.clickSave();
      cy.get('mat-error[id^="mat-error"]').should('contain', message);
    } else {
      expect(true).to.equal(true);
    }
  }
  hasReceptableIdNumberError(message: string) {
    if (cy.get('#recIdentificationNum').should('have.length', 1)) {
      this.clickSave();
      cy.get('#receptacleRequired').should('contain', message);
    } else {
      expect(true).to.equal(true);
    }
  }
  hasSupportingDocumentTypeError(message: string) {
    if (cy.get('#recIdentificationNum').should('have.length', 1)) {
      this.clickSave();
      cy.get('mat-error#sdTypeError').should('contain', message);
    } else {
      expect(true).to.equal(true);
    }
  }
  hasSupportingDocumentReferenceError(message: string) {
    if (cy.get('#sdRefNum').should('have.length', 1)) {
      this.clickSave();
      cy.get('mat-error#sdRefError').should('contain', message);
    } else {
      expect(true).to.equal(true);
    }
  }
  cancel() {
    return cy.get('[data-testid="errorPopup"]');
  }
  getCloseButton() {
    return cy.get('[data-testid="errorCloseBtn"]');
  }
  getCreateNewButton() {
    return cy.get('[data-testid=CreateNewBtn]');
  }
  isHomeScreen() {
    cy.get('.home > span').should('contain', 'Welcome to TSD Angular UI App!!');
  }
  getCancelButton() {
    return cy.get('#cancel');
  }
  hasAdditionalSupplyChainEORIError(message: string) {
    if (cy.get('#sdRefNum').should('have.length', 1)) {
      this.clickSave();
      cy.get('mat-error#ascaInvalidEori').should('contain', message);
    } else {
      expect(true).to.equal(true);
    }
  }
  hasAdditionalSupplyChainRoleError(message: string) {
    if (cy.get('.mat-select-placeholder').should('have.length', 1)) {
      this.clickSave();
      cy.get('mat-error#ascaInvalidRole').should('contain', message);
    } else {
      expect(true).to.equal(true);
    }
  }
  clickSave() {
    cy.get('#save').click();
  }

  clickNext() {
    cy.get('#next').click();
  }

  countFieldWithNoCheckBox() {
    cy.get('div.wizard-content')
      .nextAll('mat-form-field.mat-form-field')
      .should('be.within', 4, 5);
  }

  getGeneralInfoLabel() {
    return cy.get('.mat-step-label-active');
  }
  clickHouseConsignmentGIPrelodged() {}
  getWeightField() {
    return cy.get('[data-testid=weightHeaderText]');
  }

  getWeightInputbox() {
    return cy.get('#weight');
  }
}
