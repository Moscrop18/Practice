///<reference types = "Cypress"/>

import { ConsignmentInformation } from '@features/manage-declaration/models/consignment-information';
import { ConsultGeneralInformation } from '@features/manage-declaration/models/consult-general-information';
import { And, Given, Then, When } from 'cypress-cucumber-preprocessor/steps';
import { getUniqueEtag } from '../../common/util';
import { HouseConsignInfoPage } from './houseConsignmentInfo.po';
const faker = require('faker');
let page = new HouseConsignInfoPage();
let currentConsignment: ConsignmentInformation;
let declaration: ConsultGeneralInformation;
var appTitleFull = ' Temporary storage declaration ';
var appTitleShort = ' TSD ';
var pageHeading = ' Step 3: General information ';
var pageHeadingReuseTrue = ' Step 3: House consignment ';
//-----------------------Error Texts---------------------------
const invalidEoriMessage =
  ' The Additional supply chain actor must hold a valid AEOC or AEOF authorisation ';
let enterValue = 'Please enter a value';
let selectValue = 'Please select a value';
let selectError = 'Please select a valid value';
let sealInvalidDataError =
  ' The Transport equipment Number of seals cannot be a number smaller or equal to zero ';
let putInterceptFlag = false;

//---------------------------Definitions------------------------------------------------
Given(
  'prepare mock data for house consignment page with all allowed sections',
  () => {
    putInterceptFlag = false;
    cy.intercept('/assets/codelist/codelist.json', {
      fixture: 'codelist.json'
    }).as('codeList');
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments?fields=draftErrors&pageSize=100',
      {
        fixture: 'houseList.json'
      }
    ).as('consignments');
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/1/items?pageSize=100',
      {
        headers: { etag: getUniqueEtag() },
        fixture: 'goods-items.json'
      }
    ).as('consignment1Items');
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/0/items?pageSize=100',
      {
        fixture: 'goods-items.json'
      }
    ).as('consignment0Items');
    cy.intercept(
      'PUT',
      '/api/v1/temporaryStorageDeclarations/1/consignments/1',
      (req) => {
        putInterceptFlag = true;
        req.reply({
          headers: {
            etag: getUniqueEtag()
          },
          statusCode: 200
        });
      }
    ).as('cons1Put');
  }
);

Given(
  'I have navigated to the House Consignment General Info page with ensReuse true',
  () => {
    cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/955', {
      fixture: 'tsd-declaration-ensReuse.json',
      headers: { etag: getUniqueEtag() }
    }).as('generalInfo');
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/955/consignments?fields=draftErrors&pageSize=100',
      {
        fixture: 'houseList.json'
      }
    ).as('consignments');
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/955/consignments/1/items?pageSize=100',
      {
        headers: { etag: getUniqueEtag() },
        fixture: 'goods-items.json'
      }
    ).as('consignment1Items');
    cy.intercept(
      'PUT',
      '/api/v1/temporaryStorageDeclarations/955/consignments/1',
      (req) => {
        putInterceptFlag = true;
        req.reply({ statusCode: 200 });
      }
    ).as('cons0Put');
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/955/consignments/1?fields=allowedSections',
      { fixture: 'empty-consignment.json' }
    ).as('masterConsignmentInfo');
    page.visitHouseConsignment();
  }
);

And('I see the section Transport document', () => {
  page.getTransportDocumnet().should('exist');
});
And('I see the section Previous document', () => {
  page.getPreviousDocumnet().should('exist');
});
And('I dont see the section Weight', () => {
  page.getWeight().should('not.exist');
});
And('I dont see the section Reference number UCR', () => {
  page.getReferenceNumberUcr().should('not.exist');
});
And('I dont see the section Transport equipment', () => {
  page.getTransportEquipment().should('not.exist');
});
And('I dont see the section Receptacles', () => {
  page.getReceptacles().should('not.exist');
});

And('I dont see the section Supporting document', () => {
  page.getSupportingDocument().should('not.exist');
});

And('I dont see the section Additional information', () => {
  page.getAdditionalInformation().should('not.exist');
});

Given(
  'prepare mock data with sections {} on House consignment page',
  (consignmentSections) => {
    consignmentSections = [consignmentSections];
    cy.fixture('empty-consignment.json').then((data) => {
      const updatedData = {
        ...data,
        allowedSections: consignmentSections
      };
      cy.intercept(
        '/api/v1/temporaryStorageDeclarations/1/consignments/1?fields=allowedSections',
        updatedData
      ).as('allowedSections');
    });
  }
);

Given(
  'prepare mock data with sections {} on House consignment items page',
  (consignmentSections) => {
    cy.fixture('empty-consignment-items.json').then((data) => {
      const updatedData = {
        ...data,
        allowedSections: [consignmentSections]
      };
      cy.intercept(
        'GET',
        '/api/v1/temporaryStorageDeclarations/1/consignments/1/items/1?fields=allowedSections',
        {
          body: updatedData,
          headers: { etag: getUniqueEtag() }
        }
      ).as('allowedItems');
    });
    cy.fixture('tsd-declaration.json').then((data) => {
      const updatedData = {
        ...data,
        type: 'Combined',
        ensReuseIndicator: 0
      };
      cy.intercept('/api/v1/temporaryStorageDeclarations/1', {
        body: updatedData,
        headers: { etag: getUniqueEtag() }
      }).as('declaration');
    });
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/1?fields=allowedSections',
      { fixture: 'empty-consignment.json', headers: { etag: getUniqueEtag() } }
    ).as('houseConsignmentInfo');
  }
);
Given(
  'I have navigated to the House Consignment General Info page with type {} and reuse {}',
  (type, reuse) => {
    cy.fixture('tsd-declaration.json').then((data) => {
      const updatedData = {
        ...data,
        type: type,
        ensReuseIndicator: parseInt(reuse)
      };
      cy.intercept('/api/v1/temporaryStorageDeclarations/1', {
        body: updatedData,
        headers: { etag: getUniqueEtag() }
      }).as('declaration');
    });
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/1?fields=allowedSections',
      { fixture: 'empty-consignment.json', headers: { etag: getUniqueEtag() } }
    ).as('houseConsignmentInfo');
    page.visit();
  }
);

When(
  'I have navigated to the House Consignment General Info page with type prelodged and false',
  () => {
    cy.fixture('tsd-declaration.json').then((data) => {
      const updatedData = {
        ...data,
        type: 'PreLodged',
        ensReuseIndicator: 0
      };
      cy.intercept('/api/v1/temporaryStorageDeclarations/1', {
        body: updatedData,
        headers: { etag: getUniqueEtag() }
      }).as('declaration');
    });
    page.visit();
  }
);

When(
  'I have navigated to the House Consignment Items page with type prelodged and false',
  () => {
    cy.fixture('tsd-declaration.json').then((data) => {
      const updatedData = {
        ...data,
        type: 'PreLodged',
        ensReuseIndicator: 0
      };
      cy.intercept('/api/v1/temporaryStorageDeclarations/1', {
        body: updatedData,
        headers: { etag: getUniqueEtag() }
      }).as('declaration');
    });
    page.visitItemPage();
  }
);

Given(
  'I have navigated to the House Consignment General Info page with type combined and false',
  () => {
    cy.fixture('tsd-declaration.json').then((data) => {
      const updatedData = {
        ...data,
        type: 'Combined',
        ensReuseIndicator: 0
      };
      cy.intercept('/api/v1/temporaryStorageDeclarations/1', {
        body: updatedData,
        headers: { etag: getUniqueEtag() }
      }).as('declaration');
    });
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/1?fields=allowedSections',
      { fixture: 'empty-consignment.json', headers: { etag: getUniqueEtag() } }
    ).as('houseConsignmentInfo');
    page.visit();
  }
);

When('I check all sections for reuse {}', (reuse) => {
  if (reuse === '1') {
    page.validateSections('Previous Document');
  } else {
    page.validatePreviousDocumentCheckBoxIsChecked();
    page.selectReferenceNumberUcrCheckBox();
    page.selectTransportEquipmentCheckBox();
    page.selectReceptacleCheckBox();
    page.selectSupportingDocCheckBox();
    page.selectAdditionalInfoCheckBox();
    page.selectAdditionalSupplyChainCheckBox();
  }
});

Then('I see the House Consignment page with sections {}', (section) => {
  cy.wait('@allowedSections');
  page.validateSections(section);
});

Then('I see the House Consignment page with all sections for {}', (reuse) => {
  if (reuse === '1') {
    page.getAppTitle().should('have.text', appTitleFull || appTitleShort);
    page.getPageHeader().should('contain.text', pageHeadingReuseTrue);
  } else {
    //Validating checkboxes are checked
    page.validatePreviousDocumentCheckBoxIsChecked();
    page.validateReferenceNumberUcrCheckBox();
    page.validateTransportEquipmentCheckBox();
    page.validateReceptacleCheckBox();
    page.validateSupportingDocumentCheckBox();
    page.validateAdditionalInformationCheckBox();
    page.validateAdditionalSupplyChainActorCheckBox();
  }
});

And('Overlay is hidden', () => {
  page.getOverlay().should('not.exist');
});

And('I see only the allowed sections {} on items page', (section) => {
  page.validateSections(section);
});

And('I fill in all required fields for type {} and reuse {}', (type, reuse) => {
  if (type === 'prelodged' && reuse === '0') {
    page.fillRequiredFieldsForNoReuse();
  } else {
    page.fillRequiredFieldsForReuse();
  }
});

And('I click on save button', () => {
  page.clickSave();
  cy.wait('@cons1Put');
});

Then('I see all required fields in error', () => {
  page.hasTransportDocumentTypeError(selectValue);
  page.hasTransportDocumentReferenceError(enterValue);
  page.hasWeightFieldError(enterValue);
  page.hasPreviousDocumentTypeError(selectValue);
  page.hasPreviousDocumentReferenceError(enterValue);
  page.hasReferenceNumberUCRError(enterValue);
  page.hasTransportEquipmentIdNumberError(enterValue);
  page.hasTransportEquipmentContainerStatusError(selectValue);
  page.hasReceptableIdNumberError(enterValue);
  page.hasSupportingDocumentTypeError(selectValue);
  page.hasSupportingDocumentReferenceError(enterValue);
  page.hasAdditionalSupplyChainEORIError(enterValue);
  page.hasAdditionalSupplyChainRoleError(selectValue);
});

When(
  'I enter more data than allowed in each field marked with max characters with reuse {}',
  (reuse) => {
    if (reuse === '1') {
      page.inputInvalidTransportDocumentRefNumber();
      page.inputInvalidPreviousDocumentRefNumber();
    } else {
      page.inputInvalidTransportDocumentRefNumber();
      page
        .getWeightInputbox()
        .getTextField()
        .clear()
        .type('12345678901234567890');
      page.inputInvalidPreviousDocumentRefNumber();
      page.inputInvalidReferenceNumberUcr();
      page.inputInvalidTransportEquipmentIdNumber();
      page.inputInvalidReceptacleIdNumber();
      page.inputInvalidSupportingDocumentRefNumber();

      page.inputInvalidAdditionalSupplyChainActorEori();
    }
  }
);

Then(
  'I see that the input is trimmed upto the maximum allowed limit for that field with {}',
  (reuse) => {
    if (reuse === '1') {
      page.validateTransportDocumentMaxLimit();
      page.validatePreviousDocRefNumMaxLimit();
    } else {
      page.validateTransportDocumentMaxLimit();
      page.validateWeightMaxLimit();
      page.validatePreviousDocRefNumMaxLimit();
      page.validateReferenceNumberUcrMaxLimit();
      page.validateTransportEquipmentIdNumberMaxLimit();
      page.validateReceptacleIdNumberMaxLimit();
      page.validateSupportingDocumentRefNumberMaxLimit();
    }
  }
);

Then('I see the sections {} for each value of reuse', (sections) => {
  sections.split(', ').forEach((section) => {
    page.validateSections(section);
  });
});

And('The section Previous Document is checked', () => {
  page.validatePreviousDocumentCheckBoxIsChecked();
});

And('I check section {}', (section) => {
  if (section === 'Transport equipment') {
    page.selectTransportEquipmentCheckBox();
  } else if (section === 'Receptacle(s)') {
    page.selectReceptacleCheckBox();
  } else if (section === 'Supporting document(s)') {
    page.selectSupportingDocCheckBox();
  } else if (section === 'Additional information(s)') {
    page.selectAdditionalInfoCheckBox();
  } else if (section === 'Additional supply chain actor') {
    page.selectAdditionalSupplyChainCheckBox();
  } else {
    console.log('invalid Input');
  }
});

When('I click on the add item button of section {}', (section) => {
  if (section === 'Transport equipment') {
    page.addItemTransportEquipment();
  } else if (section === 'Receptacle(s)') {
    page.addItemReceptacle();
  } else if (section === 'Supporting document(s)') {
    page.addItemSupportingDocCheckBox();
  } else if (section === 'Additional information(s)') {
    page.addItemAdditionalInfoCheckBox();
  } else if (section === 'Additional supply chain actor') {
    page.addItemAdditionalSupplyChainCheckBox();
  } else {
    console.log('Invalid input');
  }
});

And(
  'I click on the delete item button from item {} 1 in {}',
  (item, section) => {
    page.deleteItemFromSection(item, section);
  }
);

Then('I see 1 item in {}', (section) => {
  page.validateItemAfterDelete(section);
});

And('I see {} 1 in section {} is expanded', (item, section) => {
  page.validateExpandedItem(item, section);
});

And(
  'I see {} 1 in section {} does not have a delete button',
  (item, section) => {
    page.validateDeleteIconOnItem(item, section);
  }
);

Then('I see 2 items in {}', (section) => {
  page.validateItemsAdded(section);
});

And('I see {} 1 in section {} is collapsed', (item, section) => {
  page.validateColapsedItem(section);
});

And('I see {} 2 in section {} is expanded', (item, section) => {
  page.validateExpandedItem(item, section);
});

When('I enter transport type {} and a valid {}', (type, reference) => {
  page.selectTransportDocType(type);
  page.inputTransportDocumentReferenceNumber(reference);
});

Then('I see no errors', () => {
  page.validateNoErrors();
});

Then('I see errors', () => {
  page.hasInvalidEoriError(selectError);
});

And(
  'I select previous document type {} and a valid {} for {}',
  (prevDocType, reference) => {
    page.selectPreviousDocumentType(prevDocType);
  }
);

When('I un-check "Previous Document" checkbox', () => {
  page.selectPreviousDocumentCheckBox();
});

Then('the section "Previous Document" is not visible', () => {
  page.validatePreviousDocumentTypeNotVisible();
});

When('I checked Reference Number UCR checkbox', () => {
  cy.wait('@houseConsignmentInfo');
  cy.wait('@consignments');
  cy.wait('@consignment1Items');
  page.selectReferenceNumberUcrCheckBox();
});
And('field {} is kept empty', (reference) => {
  page.inputReferenceNumberUCR(reference);
});

And('input data more than maximum value in {}', (reference) => {
  page.inputReferenceNumberUCR(reference);
});

Then('error for empty field should be displayed', () => {
  page.hasReferenceNumberUCRError(enterValue);
});

When('I enter the {} data', (reference) => {
  page.inputReferenceNumberUCR(reference);
});

And('I checked Transport Equipment checkbox', () => {
  cy.wait('@consignment1Items');
  cy.wait('@houseConsignmentInfo');
  cy.wait('@consignments');
  page.selectTransportEquipmentCheckBox();
});

When(
  'I enter a valid {} with Container packed status {}',
  (transportEquipmentNumber, containerPackedStatus) => {
    page.inputTransportEquipmentNumber(transportEquipmentNumber);
    page.selectTransportEquipmentContainerStatus(containerPackedStatus);
  }
);

When('I input 0 in {}', (numberOfSeals) => {
  page.inputNumberOfSeals(numberOfSeals);
});

And('error is displayed for invalid data', () => {
  page.hasNumberOfSealsInvalidDataError(sealInvalidDataError);
});

And('add icon should not be enabled', () => {
  page.validateSealAddButtonDisabled();
});

When('I input data more than maximum allowed {}', (numberOfSeals) => {
  page.inputNumberOfSeals(numberOfSeals);
});

And('I input valid data in allowed limits for {}', (numberOfSeals) => {
  page.inputNumberOfSeals(numberOfSeals);
});

Then('the extra digits should get trimmed from number of seals field', () => {
  page.compareSealValueWithInput();
});

And('add icon should get enabled', () => {
  page.validateSealAddButtonEnabled();
});

And('I click on add icon to add seal identifier item', () => {
  page.clickAddSealIdentifierItem();
});

Then(
  'error message should be displayed for empty {} field',
  (enterValue, sealId) => {
    page.hasContainerSealIdentifierError(enterValue, sealId);
  }
);

And('I input 0 in seal identifier {}', (sealCount) => {
  page.inputNumberOfSeals(sealCount);
});
And('a new field should get displayed with add icon', () => {
  page.validateSealIdentifierField();
});

And('delete button should get displayed with old field', () => {
  page.validateDeleteSealIdIcon();
});

When('I input valid data in {} field', (sealNumber) => {
  page.inputNumberOfSeals(sealNumber);
});

And('I again click on add icon with new seal identifier field', () => {
  page.clickAddIconOfSealIdentifier();
});

And('I click on delete icon displayed with old field', () => {
  page.clickDeleteSealIcon();
});

And('I check Receptacle checkbox', () => {
  page.selectReceptacleCheckBox();
});

When('I input more than acceptable limit in {}', (receptacleId) => {
  page.inputReceptacleIdNumber(receptacleId);
});

And('I input valid receptacle Id {}', (receptacleId) => {
  page.inputReceptacleIdNumber(receptacleId);
});

When('I input valid eori {}', (EORI) => {
  page.inputAdditionalSupplyChainEori(EORI);
});

Then(
  'the data {} in field should get trimmed to maximum allowed',
  (receptacleId) => {
    page.getReceptacleIdNumberLength(receptacleId);
  }
);

Then(
  'the data in supporting doc ref number field should get trimmed to maximum allowed',
  () => {
    page.getSupportingDocuentRefNumberLength();
  }
);
And('I check supporting document checkbox', () => {
  page.selectSupportingDocumentCheckBox();
});

When(
  'I input value in supporting document type as {} and more than acceptable limit in supporting ref number as {}',
  (documentType, documentReferenceNumber) => {
    page.selectSupportingDocumentType(documentType);
    page.inputSupportingDocumentRefNumber(documentReferenceNumber);
  }
);

And('I check Additonal Information section', () => {
  page.selectAdditionalInfoCheckBox();
});

When(
  'I enter more characters than allowed in additional Information Field',
  () => {
    page.inputAdditionalInformationText(faker.random.alphaNumeric(513));
  }
);

And(
  'I input value in {} field within acceptable limit',
  (textAdditionalInfo) => {
    page.inputAdditionalInformationText(textAdditionalInfo);
  }
);

Then('I see the data in additional Information Field is trimmed', (text) => {
  page.getAdditionalInformationTextArea().should('have.length.lte', 512);
});
When('I enter some data in additional Information Field', (text) => {
  page.inputAdditionalInformationText(faker.random.alphaNumeric(213));
});

And(
  'I see the total count of characters in additional Information Field is displayed correctly',
  () => {
    page
      .getAdditionalInformationTextArea()
      .invoke('val')
      .then((text: string) => {
        page
          .getAdditionalInformationTextAreaTotalCountFooter()
          .should('have.text', text.length + '/512');
      });
  }
);

And('I chcek Additional Supply Chain Actor checkbox', () => {
  page.selectAdditionalSupplyChainCheckBox();
});

When('I input invalid {}', (eori) => {
  page.inputAdditionalSupplyChainEori(eori);
});

Then('I see error for invalid EORI', () => {
  page.hasInvalidEoriError(invalidEoriMessage);
});

And('name field should be empty and disabled', () => {
  page.validateAdditionalSupplychainNameField();
});

And('I select valid eori {}', (eori) => {
  page.inputAdditionalSupplyChainEori(eori);
});
And('I select valid role {}', (role) => {
  page.selectAdditionalSupplyChainRole(role);
});

And('name field should be auto filled and disabled', () => {
  page.validateAdditionalSupplychainNameField();
});

Given(
  'I have navigated to the House Consignment General Info page with type "prelodged" and false',
  () => {
    cy.fixture('tsd-declaration.json').then((data) => {
      const updatedData = {
        ...data,
        type: 'PreLodged',
        ensReuseIndicator: 0
      };
      cy.intercept('/api/v1/temporaryStorageDeclarations/1', {
        body: updatedData,
        headers: { etag: getUniqueEtag() }
      }).as('declaration');
    });
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/1?fields=allowedSections',
      { fixture: 'empty-consignment.json' }
    ).as('houseConsignmentInfo');
    page.visit();
  }
);

//--------------------------------------------------------------------
When(
  'I have navigated to the House Consignment General Info page with type {string} and no ens reuse',
  (tsdType) => {
    page.visit();
    page.clickHouseConsignmentSection();
  }
);

Then('House Consignment page is displayed', (tsdType, ensReuse) => {
  page.getAppTitle().should('have.text', appTitleFull || appTitleShort);
  page.getPageHeader().should('have.text', pageHeading);
});
And(
  'path variables tsdType and ensReuse are set to {} and {} in URL respectively',
  (tsdType, ensReuse) => {
    page.isVisible(tsdType, ensReuse, '1');
  }
);
/*
And('path variables tsdType and ensReuse are set to {} and {} in URL respectively', (tsdType, ensReuse) => {
  page.isVisible(tsdType, ensReuse);
});
*/
And('House Consignment section gets expanded', () => {
  page.clickHouseConsignmentSection();
  page.validateGeneralInformationSection();
});

And('General information option under House consignment gets displayed', () => {
  page.validateGeneralInformationSection();
});

And(
  '7 check boxes are displayed with Previous Document check box checked',
  () => {
    page.countCheckBoxes();
    page.validatePreviousDocumentCheckBoxIsChecked();
  }
);

When(
  'I select Transport Document Type {} with reference Number {}',
  (transDocType, transDocNumber) => {
    page.selectTransportDocType(transDocType);
    page.inputTransportDocumentReferenceNumber(transDocNumber);
  }
);

When('I enter weight {}', (weight) => {
  page.inputValidWeight(weight);
});

When(
  'I select Previous Document Type {} with reference Number {}',
  (prevDocType, prevDocRefNumber) => {
    page.selectPreviousDocumentType(prevDocType);
    page.inputPreviousDocumentRefNumber(prevDocRefNumber);
  }
);

When('I enter data for all remaining mandatory fields', () => {
  page.selectReferenceNumberUcrCheckBox();
  page.inputReferenceNumberUCR('123abc45de');
});

When(
  'I have navigated to the House Consignment General Info page with type {} and ens reuse',
  (tsdType) => {
    page.visit();
    page.clickHouseConsignmentSection();
  }
);

When('click on save button', () => {
  page.clickSave();
});

Then('all data is saved without error and I am on same page', () => {
  page.clickSave();
});

When('I select all checkboxes with blank fields', () => {
  page.selectReferenceNumberUcrCheckBox();
  page.selectTransportEquipmentCheckBox();
  page.selectReceptacleCheckBox();
  page.selectSupportingDocCheckBox();
  page.selectAdditionalInfoCheckBox();
  page.selectAdditionalSupplyChainCheckBox();
});

Then('all mandatory fields with ens Reuse will give error', () => {
  page.hasTransportDocumentTypeError(selectValue);
  page.hasTransportDocumentReferenceError(enterValue);
  page.hasPreviousDocumentTypeError(selectValue);
  page.hasPreviousDocumentReferenceError(enterValue);
});

Then('all mandatory fields will give error', () => {
  page.hasTransportDocumentTypeError(selectValue);
  page.hasTransportDocumentReferenceError(enterValue);
  page.hasWeightFieldError(enterValue);
  page.hasPreviousDocumentTypeError(selectValue);
  page.hasPreviousDocumentReferenceError(enterValue);
  page.hasReferenceNumberUCRError(enterValue);
  page.hasTransportEquipmentIdNumberError(enterValue);
  page.hasTransportEquipmentContainerStatusError(selectValue);
  page.hasReceptableIdNumberError(enterValue);
  page.hasSupportingDocumentTypeError(selectValue);
  page.hasSupportingDocumentReferenceError(enterValue);
  page.hasAdditionalSupplyChainEORIError(enterValue);
  page.hasAdditionalSupplyChainRoleError(selectValue);
});

When('click on save button', () => {
  page.clickSave();
});

When('I navigate to the House Consignment page with follwing values:', () => {
  page.visit();
});

Then(
  'path variables tsdType and ensReuse are set to prelodged and True in URL respectively',
  () => {
    page.getQueryParams('?tsdType=prelodged&ensReuse=true');
  }
);

Then('only 4 fields should be displayed', () => {
  page.countFieldWithNoCheckBox();
});
When('I click on cancel without saving', () => {
  page.getCloseButton().click();
  cy.wrap(putInterceptFlag).should('eq', false);
});
When('I click on save changes', () => {
  page.getCreateNewButton().click();
  cy.wait('@cons1Put').then(() => {
    cy.wrap(putInterceptFlag).should('eq', true);
  });
});
Then('I navigate to home screen', () => {
  page.isHomeScreen();
});
When('I click on Cancel', () => {
  page.getCancelButton().click();
});
When('I see unsaved changes dialog', () => {
  page.cancel().should('be.visible');
});
When('I click on Next', () => {
  page.clickNext();
});
Then('no errors are shown in sidebar', () => {
  page.getGeneralInfoLabel().should('not.have.class', 'mat-step-label-error');
});
And('the {string} page is displayed', (pageType) => {
  page.getPageURL().should('contain', 'house-consignment-' + pageType);
});
When('I see the section Weight', () => {
  page.getWeightField().should('be.visible');
});
When('I enter valid weight {string}', (mass) => {
  page.getWeightInputbox().getTextField().clear().type(mass);
});
When('I can see the {string} entry after filling', (mass) => {
  page.getWeightInputbox().getTextField().should('have.value', mass);
});
Then('I verify the helper text at Gross Mass section', () => {
  page
    .getWeightInputbox()
    .getHint()
    .should(
      'contain',
      'Maximum 16 digits with 6 digits after decimal, value greater than 0'
    );
});
