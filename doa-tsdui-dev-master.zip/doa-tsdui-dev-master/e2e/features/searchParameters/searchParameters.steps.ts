///<reference types = "Cypress"/>
import { Given, When, Then, And } from 'cypress-cucumber-preprocessor/steps';
import { AdvancedSearchPage } from './searchParameters.po';
import '../common/customTypes';
import { random } from 'faker';
const faker = require('faker');

let page = new AdvancedSearchPage();
const max22Characters = 'Maximum 22 characters';
const max35Characters = 'Maximum 35 characters';
const max70Characters = 'Maximum 70 characters';
const max17Characters = 'Maximum 17 characters';

Given('I have navigated to the Advanced search page', () => {
  page.navigateAdvancedSearchPage();
});
Given('I see the Advanced search page', () => {
  page.getAdvancedSearchTitle().contains('Advanced search');
});
When(
  'I enter more data than allowed in each field marked with maximum characters',
  () => {
    page
      .getLrn()

      .fill(faker.random.alphaNumeric(22 + 1));
    page
      .getTransportDocument()

      .fill(faker.random.alphaNumeric(70 + 1));

    page
      .getContainer()

      .fill(faker.random.alphaNumeric(35 + 1));
    page
      .getEntryInformation()

      .fill(faker.random.alphaNumeric(35 + 1));
    page
      .getPartiesEoriNumber()

      .fill(faker.random.alphaNumeric(17 + 1));

    page
      .getWarehouseIdentifier()

      .fill(faker.random.alphaNumeric(35 + 1));
  }
);
When(
  'I see that the input is trimmed upto the maximum allowed limit for that field',
  () => {
    page.getLrn().invoke('val').should('have.length', 22);
    page.getTransportDocument().invoke('val').should('have.length', 70);
    page.getContainer().invoke('val').should('have.length', 35);
    page.getEntryInformation().invoke('val').should('have.length', 35);
    page.getPartiesEoriNumber().invoke('val').should('have.length', 17);
    page.getWarehouseIdentifier().invoke('val').should('have.length', 35);
  }
);
Then('I see the helper text at different fields on the page', () => {
  page.getHelperTextAtLrn().should('contain', max22Characters);
  page.getHelperTextAtTransportDocument().should('contain', max70Characters);
  page
    .getHelperTextAtRegistrationDateRange()
    .should('contain', 'Maximum date range of 2 months');
  page.getHelperTextAtContainer().should('contain', max35Characters);
  page.getHelperTextAtEntryInformation().should('contain', max35Characters);
  page.getHelperTextAtPartiesEori().should('contain', max17Characters);
  page.getWarehouseIdentifier().getHint().should('contain', max35Characters);
});
And('I see 18 checkboxes are present on the Advanced search page', () => {
  page.getAllCheckBoxes();
  page.getAllCheckBoxes().should('have.length', 18);
});
And('I see all the checkboxes is unchecked on the Advanced search page', () => {
  page.getCheckBoxesUnchecked().should('not.be.checked');
});
And('I click all the checkboxes on the Advanced search page', () => {
  page.getPreLodgedDeclarationStatusCheckBox().click();
  page.getAcceptedDeclarationStatusCheckBox().click();
  page.getInvalidatedDeclarationStatusCheckBox().click();
  page.getIrregularityUnderSupervisionDeclarationStatusCheckBox().click();
  page.getUnderControl().click();
  page.getSupervisingCustomOfficeCheckBox().click();
  page.getCustomOfficeOfPresentationCheckBox().click();
  page.getDeclarantCheckBox().click();
  page.getRepresentativeCheckBox().click();
  page.getCarrierCheckBox().click();
  page.getPersonPresentingTheGoodsCheckBox().click();
  page.getUnderControlCheckBox().click();
  page.getAwaitingRiskAnalysisCheckBox().click();
  page.getAwaitingRiskConfirmationCheckBox().click();
  page.getControlResultRegisteredCheckBox().click();
  page.getPreArrivalRiskAnalysisCompletedCheckBox().click();
  page.getPreArrivalRiskAnalysisCancelledCheckBox().click();
  page.getNoRiskCheckBox().click();
});
And('I see all the checkboxes is checked on the Advanced search page', () => {
  page.getPreLodgedDeclarationStatusCheckBoxes().shouldBeChecked();
  page.getAcceptedDeclarationStatusCheckBoxes().shouldBeChecked();
  page
    .getIrregularityUnderInvestigationDeclarationStatusCheckBoxes()
    .shouldBeChecked();
  page.getUnderControlStatusCheckBoxes().shouldBeChecked();
  page.getInvalidatedDeclarationStatusCheckBoxes().shouldBeChecked();
  page.getSupervisingCustomOfficeCheckboxes().shouldBeChecked();
  page.getCustomsOfficeOfPresentationCheckBoxes().shouldBeChecked();
  page.getDeclarantCheckBoxes().shouldBeChecked();
  page.getRepresentativeCheckBoxes().shouldBeChecked();
  page.getCarrierCheckBoxes().shouldBeChecked();
  page.getPersonPresentingTheGoodsCheckBoxes().shouldBeChecked();
  page.getUnderControlCheckBox().shouldBeChecked();
  page.getAwaitingRiskAnalysisCheckBox().shouldBeChecked();
  page.getAwaitingRiskConfirmationCheckBox().shouldBeChecked();
  page.getControlResultRegisteredCheckBox().shouldBeChecked();
  page.getPreArrivalRiskAnalysisCompletedCheckBox().shouldBeChecked();
  page.getPreArrivalRiskAnalysisCancelledCheckBox().shouldBeChecked();
  page.getNoRiskCheckBox().shouldBeChecked();
});
And(
  'I see all the checkboxes related to Risk and Control Status on the Advanced search page',
  () => {
    page.getUnderControlCheckBox().should('be.visible');
    page.getAwaitingRiskAnalysisCheckBox().should('be.visible');
    page.getAwaitingRiskConfirmationCheckBox().should('be.visible');
    page.getControlResultRegisteredCheckBox().should('be.visible');
    page.getPreArrivalRiskAnalysisCompletedCheckBox().should('be.visible');
    page.getPreArrivalRiskAnalysisCancelledCheckBox().should('be.visible');
    page.getNoRiskCheckBox().should('be.visible');
  }
);

And('I filled in all the input text box', () => {
  page.getLrn().type('LRN1234');
  page.getTransportDocument().type('TPD1lll');
  page.getContainer().type('RECLRN12341');
  page.getCustomOfficeOfPresentationField().selectAutocomplete('BE212000');
  page.getEntryInformation().type('ENTRY123');
  page.getPartiesEoriNumber().type('BE0214596464');
  cy.get('[data-testid=regDateToggle]').click();
  cy.contains('14').click();
  cy.contains('25').click();
  page.getWarehouseIdentifier().getTextField().type('Ref123');
  page.getUnLocodeField().selectAutocomplete('BEZAVA00710');
});
And('I click on the Clear All button', () => {
  page.getClearAllButton().click();
});
And('I click on the Search button', () => {
  page.getSearchButton().click();
});
And('I see that text input is removed', () => {
  page.getLrn().shouldBeBlank();
  page.getTransportDocument().shouldBeBlank();
  page.getContainer().shouldBeBlank();
  page.getEntryInformation().shouldBeBlank();
  page.getPartiesEoriNumber().shouldBeBlank();
  page.getEoriName().shouldBeBlank();
  page.getUnLocodeField().shouldBeBlank();
  page.getWarehouseIdentifier().shouldBeBlank();
});
And('I moved to the search results page', () => {
  page.isSearchResultPageVisible();
});
And('I see an error is shown for Registration date range', () => {
  page
    .getRegistrationDateError()
    .should('contain', ' Please select a date range of maximum 2 months. ');
});
And(
  'I filled Registration date After Date {string} and before Date {string}',
  (AfterDate, BeforeDate) => {
    cy.get('[data-testid=regDateToggle]').click();
    cy.contains(AfterDate).click();
    cy.contains(BeforeDate).click();
    page.getAcceptedDeclarationStatusCheckBox().click();
  }
);
And(
  'I filled Presentation date After Date {string} and before Date {string}',
  (AfterDate, BeforeDate) => {
    cy.get('[data-testid=presDateToggle]').click();
    cy.contains(AfterDate).click();
    cy.contains(BeforeDate).click();
  }
);

When('I have set search result mock', () => {
  cy.fixture('search-results.json').then((data) => {
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations?registrationDateAfter=*-*-1*T*Z&registrationDateBefore=*-*-2*T*Z&status=Accepted',
      data
    );
  });
  cy.fixture('search-results.json').then((data) => {
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations?registrationDateAfter=*-*-1*T*Z&registrationDateBefore=*-*-2*T*Z&status=Accepted&presentationDateAfter=*-*-1*T*Z&presentationDateBefore=*-*-2*T*Z',
      data
    ).as('withStatus&PresentationDate');
  });
  cy.fixture('search-results.json').then((data) => {
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations?registrationDateAfter=*-*-1*T*Z&registrationDateBefore=*-*-2*T*Z&lrn=LRN1234&arrivalTransportMeans=ENTRY123&transportDocument=TPD1lll&containerOrReceptacle=RECLRN12341',
      data
    );
  });
  cy.fixture('search-results.json').then((data) => {
    cy.intercept(
      'GET',
      'api/v1/temporaryStorageDeclarations?registrationDateAfter=*-*-1*T*Z&registrationDateBefore=*-*-2*T*Z&lrn=LRN1234&arrivalTransportMeans=ENTRY123&transportDocument=TPD1lll&containerOrReceptacle=RECLRN12341&warehouseIdentifier=Ref123&locationOfGoods=BEZAVA00710 - Bpost Brucargo',
      data
    ).as('withUNCode&Warehose');
  });

  cy.fixture('search-results.json').then((data) => {
    cy.intercept(
      'GET',
      'api/v1/temporaryStorageDeclarations?registrationDateAfter=*-*-1*T*Z&registrationDateBefore=*-*-2*T*Z&lrn=LRN1234&arrivalTransportMeans=ENTRY123&transportDocument=TPD1lll&containerOrReceptacle=RECLRN12341&warehouseIdentifier=Ref123&locationOfGoods=BEZAVA00710%20-%20Bpost%20Brucargo',
      data
    ).as('withUNCode&Warehose1');
  });
  cy.fixture('search-results.json').then((data) => {
    cy.intercept(
      'GET',
      'api/v1/temporaryStorageDeclarations?registrationDateAfter=*-*-1*T*Z&registrationDateBefore=*-*-2*T*Z&lrn=LRN1234&arrivalTransportMeans=ENTRY123&declarant=BE0214596464&representative=BE0214596464&carrier=BE0214596464&personPresentingTheGoods=BE0214596464&transportDocument=TPD1lll&containerOrReceptacle=RECLRN12341&warehouseIdentifier=Ref123&locationOfGoods=BEZAVA00710%20-%20Bpost%20Brucargo',
      data
    ).as('withpartiesEoriNoFilter');
  });

  cy.fixture('search-results-NoRecords.json').then((data) => {
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations?registrationDateAfter=*-*-14T00:00:00.000Z&registrationDateBefore=*-*-25T23:59:59.999Z&lrn=LRN1234&arrivalTransportMeans=ENTRY123&declarant=BE0214596464&representative=BE0214596464&carrier=BE0214596464&personPresentingTheGoods=BE0214596464&transportDocument=TPD1lll&containerOrReceptacle=RECLRN12341&warehouseIdentifier=Ref123&locationOfGoods=BEZAVA00710%20-%20Bpost%20Brucargo&supervisingOfficeRefNum=BE212000&presentationOfficeRefNum=BE212000',
      data
    ).as('NoResults');
    cy.intercept(
      'GET',
      'api/v1/temporaryStorageDeclarations?registrationDateAfter=*-*-14T00:00:00.000Z&registrationDateBefore=*-*-25T23:59:59.999Z&lrn=LRN1234&arrivalTransportMeans=ENTRY123&transportDocument=TPD1lll&containerOrReceptacle=RECLRN12341&warehouseIdentifier=Ref123&locationOfGoods=BEZAVA00710%20-%20Bpost%20Brucargo&supervisingOfficeRefNum=BE212000&presentationOfficeRefNum=BE212000&declarant=BE0214596464&representative=BE0214596464&carrier=BE0214596464&personPresentingTheGoods=BE0214596464',

      data
    ).as('NoRecords');
  });
});

Then(
  'I see date range between {string} and {string} in the URL',
  (AfterDate, BeforeDate) => {
    let afterdate = AfterDate + 'T00:00:00.000Z';
    let beforedate = BeforeDate + 'T23:59:59.999Z';
    cy.url().should('include', afterdate);
    cy.url().should('include', beforedate);
  }
);

And('I see query parameters {string} in URL', (params) => {
  let param = params.split(', ');
  cy.location('search')
    .should('contain', param[0] + '=')
    .and('include', param[1] + '=')
    .and('include', param[2] + '=')
    .and('include', param[3] + '=')
    .and('include', param[4] + '=')
    .and('include', param[5] + '=')
    .and('include', param[6] + '=')
    .and('include', param[7] + '=');
});

Given('I have navigated to the Search result page with no records', () => {
  page.getRefineSearch().should('exist');
  page
    .getNoRecordsMessage()
    .should('contain', 'No data. Please refine your search');
});
And('I click on the Refine Search button', () => {
  page.getRefineSearch().click();
});
Then('I moved back to the Advanced search page', () => {
  page.getAdvancedSearchTitle().contains('Advanced search');
});
Then('I validate all search parameters are filled in', () => {
  page.getRegStartDate().should('contain.value', '24');
  page.getRegEndDate().should('contain.value', '14');
  page.getCustomOfficeOfPresentationField().should('contain.value', 'BE212000');
  page.getSupervisingCustomOfficeCheckboxes().shouldBeChecked();
  page.getCustomsOfficeOfPresentationCheckBoxes().shouldBeChecked();
  page.getPartiesEoriNumber().should('contain.value', 'BE0214596464');
  page.getDeclarantCheckBoxes().shouldBeChecked();
  page.getRepresentativeCheckBoxes().shouldBeChecked();
  page.getCarrierCheckBoxes().shouldBeChecked();
  page.getPersonPresentingTheGoodsCheckBoxes().shouldBeChecked();
});
