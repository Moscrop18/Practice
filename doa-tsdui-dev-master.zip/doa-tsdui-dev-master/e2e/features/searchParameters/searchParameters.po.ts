export class AdvancedSearchPage {
  baseUrl = 'http://localhost:4200/advanced-search/search-results';
  queryParam =
    '?registrationDateAfter=*-*-1*T00:00:00.000Z&registrationDateBefore=*-*-2*T23:59:59.999Z&lrn=LRN1234&arrivalTransportMeans=ENTRY123&transportDocument=TPD1lll&containerOrReceptacle=RECLRN12341&warehouseIdentifier=Ref123&locationOfGoods=BEZAVA00710%20-%20Bpost%20Brucargo';
  navigateAdvancedSearchPage() {
    cy.loginWithEO();
    cy.visit('/advanced-search');
  }

  getDeclarationInformation(): Cypress.Chainable<any> {
    return cy.get('app-search-declaration-info > .mat-subheading-2');
  }
  getTransportDocumentHeader(): Cypress.Chainable<any> {
    return cy.get('app-search-transport-doc > .mat-subheading-2');
  }
  getAddressedCustomsOffice(): Cypress.Chainable<any> {
    return cy.get('app-search-add-customs-office > .mat-subheading-2');
  }
  getContainerHeader(): Cypress.Chainable<any> {
    return cy.get('app-search-container-or-rec > .mat-subheading-2');
  }
  getEntryInformationHeader(): Cypress.Chainable<any> {
    return cy.get('app-search-entry-information > .mat-subheading-2');
  }
  getParties(): Cypress.Chainable<any> {
    return cy.get('app-search-parties > .mat-subheading-2');
  }
  getDeclarationStatus(): Cypress.Chainable<any> {
    return cy.get('app-search-declaration-status > .mat-subheading-2');
  }
  getAdvancedSearchTitle(): any {
    return cy.get('.mat-subheading-1');
  }
  getLrn(): Cypress.Chainable<any> {
    return cy.get('[data-testid=lrn]');
  }
  getTransportDocument(): Cypress.Chainable<any> {
    return cy.get('[data-testid=refNum]');
  }
  getContainer(): Cypress.Chainable<any> {
    return cy.get('[data-testid=identifictionNo]');
  }
  getEntryInformation(): Cypress.Chainable<any> {
    return cy.get('[data-testid=arrivalTransMeansIdn]');
  }

  getPartiesEoriNumber(): Cypress.Chainable<any> {
    return cy.get('[data-testid=eori]');
  }

  getHelperTextAtLrn(): any {
    return cy.get('[data-testid=lrnField]');
  }
  getHelperTextAtTransportDocument(): any {
    return cy.get('[data-testid=refNumField]');
  }
  getHelperTextAtRegistrationDateRange(): any {
    return cy.get('[data-testid=regdateField]');
  }
  getHelperTextAtContainer(): any {
    return cy.get('[data-testid=identifictionNoField]');
  }
  getHelperTextAtEntryInformation(): any {
    return cy.get('[data-testid=arrivalTransMeansIdnField]');
  }
  getHelperTextAtPartiesEori(): any {
    return cy.get('[data-testid=eoriField]');
  }
  getAllCheckBoxes() {
    return cy.get('.mat-checkbox');
  }
  getCheckBoxesUnchecked() {
    return cy.get('.mat-checkbox');
  }
  getPreLodgedDeclarationStatusCheckBox() {
    return cy.get('[data-testid=PreLodgedHeading]');
  }
  getAcceptedDeclarationStatusCheckBox() {
    return cy.get('[data-testid=AcceptedHeading]');
  }
  getIrregularityUnderSupervisionDeclarationStatusCheckBox() {
    return cy.get('[data-testid=IrregularityUnderInvestigationHeading]');
  }
  getUnderControl() {
    return cy.get('[data-testid=UnderControl]');
  }
  getInvalidatedDeclarationStatusCheckBox() {
    return cy.get('[data-testid=InvalidatedHeading]');
  }
  getSupervisingCustomOfficeCheckBox() {
    return cy.get('[data-testid=supervCusOfficeHeading]');
  }
  getCustomOfficeOfPresentationCheckBox() {
    return cy.get('[data-testid=cusOffOfPresHeading]');
  }
  getDeclarantCheckBox() {
    return cy.get('[data-testid=declarantHeading]');
  }
  getRepresentativeCheckBox() {
    return cy.get('[data-testid=representativeHeading]');
  }
  getCarrierCheckBox() {
    return cy.get('[data-testid=carrierHeading]');
  }
  getPersonPresentingTheGoodsCheckBox() {
    return cy.get('[data-testid=personPresGoodsHeading]');
  }

  getPreLodgedDeclarationStatusCheckBoxes() {
    return cy.get('[data-testid=PreLodged]');
  }
  getAcceptedDeclarationStatusCheckBoxes() {
    return cy.get('[data-testid=Accepted]');
  }
  getIrregularityUnderInvestigationDeclarationStatusCheckBoxes() {
    return cy.get('[data-testid=IrregularityUnderInvestigation]');
  }
  getUnderControlStatusCheckBoxes() {
    return cy.get('[data-testid=UnderControl]');
  }
  getSupervisingCustomOfficeCheckboxes() {
    return cy.get('[data-testid=supervCusOffice]');
  }
  getCustomsOfficeOfPresentationCheckBoxes() {
    return cy.get('[data-testid=cusOffOfPres]');
  }
  getInvalidatedDeclarationStatusCheckBoxes() {
    return cy.get('[data-testid=Invalidated]');
  }
  getDeclarantCheckBoxes() {
    return cy.get('[data-testid=declarant]');
  }
  getRepresentativeCheckBoxes() {
    return cy.get('[data-testid=representative]');
  }
  getCarrierCheckBoxes() {
    return cy.get('[data-testid=carrier]');
  }
  getPersonPresentingTheGoodsCheckBoxes() {
    return cy.get('[data-testid=personPresGoods]');
  }
  getUnderControlCheckBox() {
    return cy.get('[data-testid=racUnderControl]');
  }
  getAwaitingRiskAnalysisCheckBox() {
    return cy.get('[data-testid=racAwaitingRiskAnalysisResult]');
  }
  getAwaitingRiskConfirmationCheckBox() {
    return cy.get('[data-testid=racAwaitingRiskHitConfirmation]');
  }
  getControlResultRegisteredCheckBox() {
    return cy.get('[data-testid=racControlResultRegistered]');
  }
  getPreArrivalRiskAnalysisCompletedCheckBox() {
    return cy.get('[data-testid=racPreArrivalRiskAnalysisCompleted]');
  }
  getPreArrivalRiskAnalysisCancelledCheckBox() {
    return cy.get('[data-testid=racPreArrivalRiskAnalysisCancelled]');
  }
  getNoRiskCheckBox() {
    return cy.get('[data-testid=racNoRisk]');
  }

  getClearAllButton() {
    return cy.get('#clearAll');
  }
  getSearchButton() {
    return cy.get('[data-testid=search]');
  }
  getEoriName(): Cypress.Chainable<any> {
    return cy.get('[data-testid=name]');
  }

  getRegStartDate(): Cypress.Chainable<any> {
    return cy.get('[data-testid=registrationDateBefore]');
  }
  getRegEndDate(): Cypress.Chainable<any> {
    return cy.get('[data-testid=registrationDateAfter]');
  }
  getRegistrationDateError(): any {
    return cy.get('[data-testid=regdateField]');
  }
  isSearchResultPageVisible() {
    cy.url()
      .should('include', this.baseUrl)
      .and('include', 'registrationDateAfter')
      .and('include', 'registrationDateBefore');
  }
  getWarehouseIdentifier() {
    return cy.get('#warehouseIdentifier');
  }
  getUnLocodeField() {
    return cy.get('#unLocodeField');
  }

  getCustomOfficeOfPresentationField() {
    return cy.get('[data-testid="supervCusOfficeHeadingField"] input');
  }

  visitWithAllParameters() {
    cy.loginWithEO();
    cy.visit(
      '/api/v1/temporaryStorageDeclarations?registrationDateAfter=2022-07-14T00:00:00.000Z&registrationDateBefore=2022-07-25T23:59:59.999Z&lrn=LRN1234&arrivalTransportMeans=ENTRY123&declarant=BE0214596464&representative=BE0214596464&carrier=BE0214596464&personPresentingTheGoods=BE0214596464&transportDocument=TPD1lll&containerOrReceptacle=RECLRN12341&warehouseIdentifier=Ref123&locationOfGoods=BEZAVA00710%20-%20Bpost%20Brucargo&supervisingOfficeRefNum=BE212000&presentationOfficeRefNum=BE212000'
    );
  }

  getRefineSearch(): Cypress.Chainable<any> {
    return cy.get('#refineSearch');
  }
  getNoRecordsMessage() {
    return cy.get('[data-testid="noRecord"]');
  }
}
