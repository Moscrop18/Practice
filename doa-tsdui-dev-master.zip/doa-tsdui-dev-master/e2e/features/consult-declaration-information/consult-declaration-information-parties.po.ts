import { DeclarationType, EnsReuse } from '../common/customTypes';

export class ConsultDeclarationPartiesPage {
  invalidPath = '/page-not-found';
  visit1() {
    cy.loginWithEO();
    return cy.visit('/advanced-search/search-results/invalidConsultLink/party');
  }
  validateURLPath() {
    cy.url().should('include', this.invalidPath);
  }

  visitPartiesPage() {
    cy.loginWithEO();
    cy.visit('/advanced-search/search-results/20BETP000000C3FLU4/party');
  }
  navigatePartiesPage(): any {
    cy.visit('/advanced-search/search-results/20BETP000000C3FLU4/party');
  }
  getPartiesTitle(): any {
    return cy.get('#parties').contains('Parties');
  }

  getDeclarantEoriNumber(): any {
    return cy.get('[data-testid=eoriNumber]');
  }
  getDeclarantPartiesName(): any {
    return cy.get('[data-testid=partyName]');
  }
  getDeclarantEmailId(): any {
    return cy.get('[data-testid=emailId]');
  }
  getDeclarantPhoneNumber(): any {
    return cy.get('[data-testid=phoneNumber]');
  }
  getDeclarantstreeAndNumber(): any {
    return cy.get('[data-testid=streeAndNumber]');
  }
  getDeclarantCountryName(): any {
    return cy.get('[data-testid=country]');
  }
  getDeclarantCityName(): any {
    return cy.get('[data-testid=city]');
  }
  getDeclarantPostCode(): any {
    return cy.get('[data-testid=postCode]');
  }
  getDeclarantPoBox(): any {
    return cy.get('[data-testid=poBox]');
  }
  getRepresntativeTitle(): any {
    return cy.get('[data-testid=representative]');
  }
  getRepresentativeEoriNumber(): any {
    return cy.get('[data-testid=eoriNumber2]');
  }
  getRepresentativeName(): any {
    return cy.get('[data-testid=name2]');
  }
  getRepresentativeStatus(): any {
    return cy.get('[data-testid=status]');
  }
  getRepresentativeEmailId(): any {
    return cy.get('[data-testid=email2]');
  }
  getRepresentativeStreetAndNum(): any {
    return cy.get('[data-testid=streetAndNumber2]');
  }
  getRepresentativePoBox(): any {
    return cy.get('[data-testid=poBox2]');
  }
  getRepresentativeCountry(): any {
    return cy.get('[data-testid=country2]');
  }
  getRepresentativeCity(): any {
    return cy.get('[data-testid=city2]');
  }
  getRepresentativePostCode(): any {
    return cy.get('[data-testid=postCode2]');
  }
}
