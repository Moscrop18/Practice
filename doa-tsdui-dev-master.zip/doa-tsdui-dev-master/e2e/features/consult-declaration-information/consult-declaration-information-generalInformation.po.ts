import { DeclarationType, EnsReuse } from '../common/customTypes';

export class ConsultDeclarationGeneralInfoPage {
  invalidPath = '/page-not-found';
  visit1() {
    cy.loginWithEO();
    return cy.visit('/advanced-search/search-results/invalidConsultLink');
  }
  visitGeneralInfoPage() {
    cy.visit('/advanced-search/search-results/20BETP000000C3FLU4');
  }
  getGeneralInformationTitle(): any {
    return cy.get('[data-testid=genInfoTitle]');
  }

  getTypeOfTsd(): any {
    return cy.get('[data-testid="tsdType"]');
  }
  getENSIndicator(): any {
    return cy.get('[data-testid=ensReUse]');
  }
  getLRN(): any {
    return cy.get('[data-testid*=lrnId]');
  }
  getRegistrationDateAndTime(): any {
    return cy.get('[data-testid^=registrationDate]');
  }
  getAddressedCustomOffice(): any {
    return cy.get('[data-testid=adressCustomOfficeTitle]');
  }
  getSupervisingCustomOffice(): any {
    return cy.get('[data-testid=superCustomOffice]');
  }
  getEntryInfoTitle(): any {
    return cy.get('[data-testid=entryInfoTitle]');
  }
  getArrivalTransportMeansType(): any {
    return cy.get('[data-testid=arrivalTransportIdentification]');
  }
  getArrivalTransportMeans(): any {
    return cy.get('[data-testid=arrivalTransportIdNumber]');
  }
  getPlaceOfUnloading(): any {
    return cy.get('[data-testid=placeOfUnloading]');
  }
  getLocationOfGoodstitle(): any {
    return cy.get('[data-testid=locationTitle]');
  }
  getLocationType(): any {
    return cy.get('[data-testid=locationTypeId]');
  }
  getQualifier(): any {
    return cy.get('[data-testid=qualifierType]');
  }
  getAdditionalIdentifier(): any {
    return cy.get('[data-testid=additionalIdentifier]');
  }
  getEconomicOperatorEoriNumber(): any {
    return cy.get('[data-testid=economicIdNumber]');
  }
  getStreetAndNumber(): any {
    return cy.get('[data-testid=locationStreet]');
  }
  getPoBox(): any {
    return cy.get('[data-testid=locationPoBox]');
  }
  getCountry(): any {
    return cy.get('[data-testid=locationCountry]');
  }
  getCity(): any {
    return cy.get('[data-testid=locationCity]');
  }
  getPostCode(): any {
    return cy.get('[data-testid=locationPostCode]');
  }
  getAuthorizatonNumber(): any {
    return cy.get('[data-testid=locationAuthNumber]');
  }
  getUNLOCODE(): any {
    return cy.get('[data-testid=locationUnlocode]');
  }
  getCustomOfficeReferenceNumber(): any {
    return cy.get('[data-testid=customReferenceId]');
  }
  getWareHouseType(): any {
    return cy.get('[data-testid=warehouseTypeId]');
  }
  getWareHouseIdentifier(): any {
    return cy.get('[data-testid=warehouseIdentifier]');
  }

  getSection() {
    return cy.get('div.fin-overline');
  }

  getTransferNotificationIcon() {
    return cy.get('.transfer-notification-container img');
  }
  getNotificationPanelHeader() {
    return cy.get('.mat-expansion-panel-header-title');
  }

  getNotificationPanelContent() {
    return cy.get('.mat-expansion-panel-content');
  }
  getPersonAfterArrivalSection() {
    return cy.get(
      '.mat-expansion-panel-content [data-testid=personAfterArrival]'
    );
  }
  getDeclarant() {
    return cy.get('.mat-expansion-panel-content [class^="mat-subheading-"]');
  }
  getPersonAfterArrivalEoriNumber() {
    return cy.get(
      'app-consult-person-notification-arrival [data-testid=eoriNumber2]'
    );
  }
  getPersonAfterArrivalName() {
    return cy.get(
      'app-consult-person-notification-arrival [data-testid=name2]'
    );
  }
  getConsignmentTable() {
    return cy.get('[data-testid="houseConsignmentsTable"]');
  }
}
