import { And, Given, Then } from 'cypress-cucumber-preprocessor/steps';
import { ConsultDeclarationPartiesPage } from './consult-declaration-information-parties.po';
import { ConsultDeclarationGeneralInfoPage } from './consult-declaration-information-generalInformation.po';
import '../common/customTypes';
import { ConsultGeneralInformation } from '@features/manage-declaration/models/consult-general-information/consult-general-info';
import { MasterGeneralInfoPage } from '../consult-consignment-declaration/consult-master-consignment/master-general-info/master-general-info.po';
import { columnSort, getCodeAndLabel } from './../common/util';

let generalInfoPage = new ConsultDeclarationGeneralInfoPage();
let partiesPage = new ConsultDeclarationPartiesPage();
let masterGeneralInfoPage = new MasterGeneralInfoPage();
let tsd: ConsultGeneralInformation;
let codeList: any;
let draftAPI = '/api/v1/temporaryStorageDeclarations/invalidConsultLink';
let tsdTransferNotification;

Given('Prepare declaration test mock data', () => {
  cy.fixture('tsd-declaration.json').then((declaration) => {
    tsd = declaration;
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4',
      declaration
    ).as('advancedSearch');
  });
  cy.fixture('codelist.json').then((data) => {
    codeList = data;
    cy.intercept('/assets/codelist/codelist.json', data).as('codeList');
  });
});

Given('Prepare declaration test mock data for transfer notification', () => {
  cy.fixture('tsd-declaration-transfer-notification.json').then(
    (declaration) => {
      tsdTransferNotification = declaration.transferNotification;
      cy.intercept(
        'GET',
        '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4',
        declaration
      ).as('advancedSearchTransferNotification');
    }
  );
});

Given('I navigate to the parties page for declaration', () => {
  cy.loginWithEO();
  partiesPage.navigatePartiesPage();
  cy.wait('@codeList');
});
Given('I navigate to the general information page for declaration', () => {
  cy.loginWithEO();
  generalInfoPage.visitGeneralInfoPage();
  cy.wait('@codeList');
});

Then('I see the parties page', () => {
  partiesPage.getPartiesTitle().should('contain', 'Parties');
});
Then('I see the general information page', () => {
  generalInfoPage
    .getGeneralInformationTitle()
    .should('contain', ' General information');
});
Then('I see the declarant details of the declaration', () => {
  partiesPage
    .getDeclarantEoriNumber()
    .should('contain', tsd.declarant.identificationNumber);
  partiesPage.getDeclarantPartiesName().should('contain', tsd.declarant.name);
  partiesPage
    .getDeclarantEmailId()
    .should('contain', tsd.declarant.communication[0].identifier);
  partiesPage
    .getDeclarantPhoneNumber()
    .should('contain', tsd.declarant.communication[1].identifier);
  partiesPage
    .getDeclarantstreeAndNumber()
    .should('contain', tsd.declarant.address.streetAndNumber);
  partiesPage
    .getDeclarantPoBox()
    .should('contain', tsd.declarant.address.poBox);
  partiesPage
    .getDeclarantCountryName()
    .should('contain', tsd.declarant.address.country);
  partiesPage
    .getDeclarantCityName()
    .should('contain', tsd.declarant.address.city);
  partiesPage
    .getDeclarantPostCode()
    .should('contain', tsd.declarant.address.postCode);
});

Then('I see the representative details of the declaration', () => {
  partiesPage.getRepresntativeTitle().should('contain', 'Representative');
  partiesPage
    .getRepresentativeEoriNumber()
    .should('contain', tsd.representative.identificationNumber);
  partiesPage
    .getRepresentativeName()
    .should('contain', tsd.representative.name);
  partiesPage
    .getRepresentativeStatus()
    .should('contain', tsd.representative.status);
  partiesPage
    .getRepresentativeEmailId()
    .should('contain', tsd.representative.communication[0].identifier);
  partiesPage
    .getRepresentativeStreetAndNum()
    .should('contain', tsd.representative.address.streetAndNumber);
  partiesPage
    .getRepresentativePoBox()
    .should('contain', tsd.representative.address.poBox);
  partiesPage
    .getRepresentativeCountry()
    .should('contain', tsd.representative.address.country);
  partiesPage
    .getRepresentativeCity()
    .should('contain', tsd.representative.address.city);
  partiesPage
    .getRepresentativePostCode()
    .should('contain', tsd.representative.address.postCode);
});

Then(
  'I see the general information details on general information page',
  () => {
    generalInfoPage.getTypeOfTsd().should('contain', tsd.type);
    generalInfoPage.getENSIndicator().should('contain', 'No');
    generalInfoPage.getLRN().should('contain', tsd.lrn);
    generalInfoPage
      .getRegistrationDateAndTime()
      .should('contain', ' Apr 01, 2021');
  }
);
Then(
  'I see the addressed custom office details on general information page',
  () => {
    generalInfoPage
      .getAddressedCustomOffice()
      .should('contain', ' Addressed customs office ');
    generalInfoPage
      .getSupervisingCustomOffice()
      .should(
        'contain',
        codeList.CL141[0].value + ' - ' + codeList.CL141[0].definition
      );
  }
);
Then('I see the entry information details on general information page', () => {
  generalInfoPage.getEntryInfoTitle().should('contain', ' Entry information ');
  generalInfoPage
    .getArrivalTransportMeansType()
    .should(
      'contain',
      codeList.CL750[0].value + ' - ' + codeList.CL750[0].definition
    );
  generalInfoPage
    .getArrivalTransportMeans()
    .should(
      'contain',
      tsd.consignmentHeader.arrivalTransportMeans.identificationNumber
    );
  generalInfoPage
    .getPlaceOfUnloading()
    .should(
      'contain',
      codeList.CL144[0].value + ' - ' + codeList.CL144[0].definition
    );
});
Then('I see the Location of goods details on general information page', () => {
  generalInfoPage
    .getLocationOfGoodstitle()
    .should('contain', 'Declared location of goods');
  generalInfoPage
    .getLocationType()
    .should(
      'contain',
      codeList.CL347Combined[3].value +
        ' - ' +
        codeList.CL347Combined[3].definition
    );
  generalInfoPage
    .getQualifier()
    .should(
      'contain',
      codeList.CL326[4].value + ' - ' + codeList.CL326[4].definition
    );
  generalInfoPage
    .getAdditionalIdentifier()
    .should(
      'contain',
      tsd.consignmentHeader.declaredLocationOfGoods.additionalIdentifier
    );
  generalInfoPage
    .getEconomicOperatorEoriNumber()
    .should(
      'contain',
      tsd.consignmentHeader.declaredLocationOfGoods.economicOperator
        .identificationNumber
    );
  generalInfoPage
    .getStreetAndNumber()
    .should(
      'contain',
      tsd.consignmentHeader.declaredLocationOfGoods.address.streetAndNumber
    );
  generalInfoPage
    .getPoBox()
    .should(
      'contain',
      tsd.consignmentHeader.declaredLocationOfGoods.address.poBox
    );
  generalInfoPage
    .getCountry()
    .should(
      'contain',
      codeList.CL718[14].value + ' - ' + codeList.CL718[14].definition
    );
  generalInfoPage
    .getCity()
    .should(
      'contain',
      tsd.consignmentHeader.declaredLocationOfGoods.address.city
    );
  generalInfoPage
    .getPostCode()
    .should(
      'contain',
      tsd.consignmentHeader.declaredLocationOfGoods.address.postCode
    );
  generalInfoPage
    .getAuthorizatonNumber()
    .should(
      'contain',
      tsd.consignmentHeader.declaredLocationOfGoods.authorisationNumber
    );
  generalInfoPage
    .getUNLOCODE()
    .should(
      'contain',
      codeList.CL144[0].value + ' - ' + codeList.CL144[0].definition
    );
  generalInfoPage
    .getCustomOfficeReferenceNumber()
    .should(
      'contain',
      codeList.CL141[0].value + ' - ' + codeList.CL141[0].definition
    );
  generalInfoPage
    .getWareHouseType()
    .should(
      'contain',
      codeList.CL099[0].value + ' - ' + codeList.CL099[0].definition
    );
  generalInfoPage
    .getWareHouseIdentifier()
    .should('contain', tsd.consignmentHeader.warehouse.identifier);
});

Given('I navigate to the parties page with invalid URL', () => {
  cy.intercept('GET', draftAPI, {
    statusCode: 404,
    body: {}
  }).as('deleteResponse');
  partiesPage.visit1();
});
Then('I see the PAGE NOT FOUND screen', () => {
  partiesPage.validateURLPath();
});

Given('I navigate to the general information page with invalid URL', () => {
  cy.intercept('GET', draftAPI, {
    statusCode: 404,
    body: {}
  }).as('deleteResponse');
  generalInfoPage.visit1();
});

Then('I see the general information page with {string} section', (section) => {
  generalInfoPage.getSection().should('contain', section);
  generalInfoPage
    .getTransferNotificationIcon()
    .should('be.visible')
    .and('have.prop', 'naturalWidth')
    .should('be.greaterThan', 0);
});

Then(
  'I see the {string} details on general information page',
  (notificationSection) => {
    if (notificationSection === 'Transfer notification') {
      generalInfoPage
        .getLRN()
        .first()
        .should('contain', tsdTransferNotification.lrn);
      generalInfoPage
        .getRegistrationDateAndTime()
        .first()
        .should('contain', 'Aug 24, 2019');
      generalInfoPage
        .getNotificationPanelHeader()
        .should('contain', 'Transfer Notification Information');
    } else if (notificationSection === 'Deconsolidation notification') {
      generalInfoPage
        .getLRN()
        .first()
        .should('contain', tsd.deconsolidationNotification.lrn);
      generalInfoPage
        .getRegistrationDateAndTime()
        .first()
        .should('contain', 'Aug 24, 2019 at 19:45');
      generalInfoPage
        .getNotificationPanelHeader()
        .should('contain', 'Deconsolidation Notification Information');
    }
  }
);

Then('I expand {string} panel', () => {
  generalInfoPage
    .getNotificationPanelHeader()
    .should('contain', 'Transfer Notification Information')
    .click();
});
Then('I see the addressed custom office details in notification panel', () => {
  generalInfoPage
    .getAddressedCustomOffice()
    .should('contain', 'Addressed customs office');
  generalInfoPage
    .getSupervisingCustomOffice()
    .should(
      'contain',
      codeList.CL141[0].value + ' - ' + codeList.CL141[0].definition
    );
});
Then('I see the Location of goods details in notification panel', () => {
  generalInfoPage.getNotificationPanelContent();
  generalInfoPage
    .getLocationOfGoodstitle()
    .should('contain', 'Declared location of goods');
  generalInfoPage
    .getLocationType()
    .should(
      'contain',
      codeList.CL347Combined[3].value +
        ' - ' +
        codeList.CL347Combined[3].definition
    );
  generalInfoPage
    .getQualifier()
    .should(
      'contain',
      codeList.CL326[4].value + ' - ' + codeList.CL326[4].definition
    );
  generalInfoPage
    .getAdditionalIdentifier()
    .should(
      'contain',
      tsdTransferNotification.locationOfGoods.additionalIdentifier
    );
  generalInfoPage
    .getEconomicOperatorEoriNumber()
    .should(
      'contain',
      tsdTransferNotification.locationOfGoods.economicOperator
        .identificationNumber
    );
  generalInfoPage
    .getStreetAndNumber()
    .should(
      'contain',
      tsdTransferNotification.locationOfGoods.address.streetAndNumber
    );
  generalInfoPage
    .getCountry()
    .should(
      'contain',
      codeList.CL718[14].value + ' - ' + codeList.CL718[14].definition
    );
  generalInfoPage
    .getCity()
    .should('contain', tsdTransferNotification.locationOfGoods.address.city);
  generalInfoPage
    .getPostCode()
    .should(
      'contain',
      tsdTransferNotification.locationOfGoods.address.postCode
    );
  generalInfoPage
    .getAuthorizatonNumber()
    .should(
      'contain',
      tsdTransferNotification.locationOfGoods.authorisationNumber
    );
  generalInfoPage
    .getUNLOCODE()
    .should(
      'contain',
      codeList.CL144[0].value + ' - ' + codeList.CL144[0].definition
    );
  generalInfoPage
    .getCustomOfficeReferenceNumber()
    .should(
      'contain',
      codeList.CL141[0].value + ' - ' + codeList.CL141[0].definition
    );
  generalInfoPage
    .getWareHouseType()
    .should(
      'contain',
      codeList.CL099[0].value + ' - ' + codeList.CL099[0].definition
    );
  generalInfoPage
    .getWareHouseIdentifier()
    .should('contain', tsdTransferNotification.warehouse.identifier);
});

Then('I see declarant detials in notification panel', () => {
  generalInfoPage.getDeclarant().should('contain', 'Declarant');
  partiesPage
    .getDeclarantEoriNumber()
    .should('contain', tsdTransferNotification.declarant.identificationNumber);
  partiesPage
    .getDeclarantPartiesName()
    .should('contain', tsdTransferNotification.declarant.name);
  partiesPage
    .getDeclarantEmailId()
    .should(
      'contain',
      tsdTransferNotification.declarant.communication[0].identifier
    );
  partiesPage
    .getDeclarantPhoneNumber()
    .should(
      'contain',
      tsdTransferNotification.declarant.communication[1].identifier
    );
  partiesPage
    .getDeclarantstreeAndNumber()
    .should(
      'contain',
      tsdTransferNotification.declarant.address.streetAndNumber
    );
  partiesPage
    .getDeclarantPoBox()
    .should('contain', tsdTransferNotification.declarant.address.poBox);
  partiesPage
    .getDeclarantCountryName()
    .should('contain', tsdTransferNotification.declarant.address.country);
  partiesPage
    .getDeclarantCityName()
    .should('contain', tsdTransferNotification.declarant.address.city);
  partiesPage
    .getDeclarantPostCode()
    .should('contain', tsdTransferNotification.declarant.address.postCode);
});

Then('I see representative detials in notification panel', () => {
  partiesPage.getRepresntativeTitle().should('contain', 'Representative');
  partiesPage
    .getRepresentativeEoriNumber()
    .first()
    .should(
      'contain',
      tsdTransferNotification.representative.identificationNumber
    );
  partiesPage
    .getRepresentativeName()
    .first()
    .should('contain', tsdTransferNotification.representative.name);
  partiesPage
    .getRepresentativeStatus()
    .first()
    .should('contain', tsdTransferNotification.representative.status);
  partiesPage
    .getRepresentativeEmailId()
    .first()
    .should(
      'contain',
      tsdTransferNotification.representative.communication[0].identifier
    );
  partiesPage
    .getRepresentativeStreetAndNum()
    .first()
    .should(
      'contain',
      tsdTransferNotification.representative.address.streetAndNumber
    );
  partiesPage
    .getRepresentativePoBox()
    .should('contain', tsdTransferNotification.representative.address.poBox);
  partiesPage
    .getRepresentativeCountry()
    .should('contain', tsdTransferNotification.representative.address.country);
  partiesPage
    .getRepresentativeCity()
    .should('contain', tsdTransferNotification.representative.address.city);
  partiesPage
    .getRepresentativePostCode()
    .should('contain', tsdTransferNotification.representative.address.postCode);
});

Then(
  'I see person notifying the arrival after movement in notification panel',
  () => {
    generalInfoPage
      .getPersonAfterArrivalSection()
      .should('contain', 'Person notifying the arrival after movement');
    generalInfoPage
      .getPersonAfterArrivalEoriNumber()
      .should(
        'contain',
        tsdTransferNotification.personNotifyingTheArrivalAfterMovement
          .identificationNumber
      );
    generalInfoPage
      .getPersonAfterArrivalName()
      .should(
        'contain',
        tsdTransferNotification.personNotifyingTheArrivalAfterMovement.name
      );
  }
);

Then('I see consignment table in notification panel', () => {
  generalInfoPage.getConsignmentTable().should('contain', 'Consignment(s)');
});
And('I can sort {string} table', (tableName) => {
  masterGeneralInfoPage
    .getTable(tableName)
    .getTableHeaders()
    .each((header, i) =>
      cy
        .wrap(header)
        .click()
        .then(() => {
          let sorted = getTableDataSlice(tableName)
            .sort((a, b) => columnSort(a[i], b[i], i > 0, i < 0))
            .slice(0, 10);
          masterGeneralInfoPage
            .getTable(tableName)
            .getTableRows()
            .should('deep.equal', sorted);
        })
    );
});

function getTableDataSlice(
  tableTitle: string,
  start: number = 0,
  end?: number
) {
  return getTableData(tableTitle).slice(start, end);
}

function getTableData(tsdTransferNotification) {
  let i = 0;
  return tsdTransferNotification.map((t) => [
    '' + i++,
    t.type,
    t.transportDocument.id,
    t.transportDocument.type
  ]);
}
