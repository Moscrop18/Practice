import { Given, Then } from 'cypress-cucumber-preprocessor/steps';
import { ConsultPresentationNotificationPartiesPage } from './consult-tsd-presentation-notification-parties.po';
import { ConsultPresentationNotificationGeneralInfoPage } from './consult-tsd-presentation-notification-generalInformation.po';
import '../common/customTypes';
import { ConsultGeneralInformation } from '@features/manage-declaration/models/consult-general-information/consult-general-info';

let presentationGeneralInfoPage = new ConsultPresentationNotificationGeneralInfoPage();
let presentationPartiesPage = new ConsultPresentationNotificationPartiesPage();
let tsd: ConsultGeneralInformation;

Given('Prepare presentation test mock data', () => {
  cy.fixture('tsd-declaration.json').then((declaration) => {
    tsd = declaration;
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4',
      declaration
    ).as('advancedSearch');
  });
  cy.fixture('codelist.json').then((data) => {
    cy.intercept('/assets/codelist/codelist.json', data).as('codeList');
  });
});

Given('I navigate to the parties page for presentation notification', () => {
  cy.loginWithEO();
  presentationPartiesPage.navigatePartiesPage();
  cy.wait('@advancedSearch');
});
Given(
  'I navigate to the general information page for presentation notification',
  () => {
    cy.loginWithEO();
    presentationGeneralInfoPage.visitGeneralInfoPage();
    cy.wait('@advancedSearch');
  }
);
Then('I see the parties page', () => {
  presentationPartiesPage.getPartiesTitle().should('contain', 'Parties');
});
Then('I see the general information page', () => {
  presentationGeneralInfoPage
    .getGeneralInformationTitle()
    .should('contain', ' General information');
});
Then(
  'I see the person presenting the goods details of the presentation notification',
  () => {
    presentationPartiesPage
      .getPersonPresentingTheGoodsTitle()
      .should('contain', ' Person presenting the goods ');
    presentationPartiesPage
      .getPersonsPresentingTheGoodsEoriNumber()
      .should('contain', tsd.personPresentingTheGoods.identificationNumber);
    presentationPartiesPage
      .getPersonsPresentingTheGoodsName()
      .should('contain', tsd.personPresentingTheGoods.name);
  }
);
Then('I see the carrier details of the presentation notification', () => {
  presentationPartiesPage.getCarrierTitle().should('contain', ' Carrier ');
  presentationPartiesPage
    .getCarrierEoriNumber()
    .should('contain', tsd.consignmentHeader.carrier.identificationNumber);
  presentationPartiesPage
    .getCarrierName()
    .should('contain', tsd.consignmentHeader.carrier.name);
});
Then(
  'I see the  general information details on general information page',
  () => {
    presentationGeneralInfoPage
      .getfrn()
      .should('contain', ' FRN: 20BEPN000000C3FLU8 ');
  }
);
Then(
  'I see the  notification information details on general information page',
  () => {
    presentationGeneralInfoPage
      .getNotificationInformationTitle()
      .should('contain', ' Notification information ');
    presentationGeneralInfoPage
      .getDeclarationDateAndTime()
      .should('contain', ' Apr 28, 2021');
    presentationGeneralInfoPage
      .getPresentationOfGoodsDateAndTime()
      .should('contain', ' Apr 28, 2021');
  }
);
Then(
  'I see the addressed custom office details on general information page',
  () => {
    presentationGeneralInfoPage
      .getAddressedCustomOfficeTitle()
      .should('contain', ' Addressed customs office ');
    presentationGeneralInfoPage
      .getCustomOfficeOfPresentation()
      .should('contain', tsd.supervisingCustomsOffice.referenceNumber);
  }
);
Then(
  'I see the Presented location of goods details on general information page',
  () => {
    presentationGeneralInfoPage
      .getPresentedLocationOfGoodsTitle()
      .should('contain', ' Presented location of goods ');
    presentationGeneralInfoPage
      .getLocationType()
      .should(
        'contain',
        tsd.consignmentHeader.presentedLocationOfGoods.typeOfLocation
      );
    presentationGeneralInfoPage
      .getQualifier()
      .should(
        'contain',
        tsd.consignmentHeader.presentedLocationOfGoods.qualifierOfIdentification
      );
    presentationGeneralInfoPage
      .getStreetAndNumber()
      .should(
        'contain',
        tsd.consignmentHeader.presentedLocationOfGoods.address.streetAndNumber
      );
    presentationGeneralInfoPage
      .getCountry()
      .should(
        'contain',
        tsd.consignmentHeader.presentedLocationOfGoods.address.country
      );
    presentationGeneralInfoPage
      .getCity()
      .should(
        'contain',
        tsd.consignmentHeader.presentedLocationOfGoods.address.city
      );
    presentationGeneralInfoPage
      .getPostCode()
      .should(
        'contain',
        tsd.consignmentHeader.presentedLocationOfGoods.address.postCode
      );
    presentationGeneralInfoPage
      .getAuthorisationNumber()
      .should(
        'contain',
        tsd.consignmentHeader.presentedLocationOfGoods.authorisationNumber
      );
    presentationGeneralInfoPage
      .getUnlocode()
      .should(
        'contain',
        tsd.consignmentHeader.presentedLocationOfGoods.unLoCode
      );
    presentationGeneralInfoPage
      .getCustomsOfficeReferenceNumber()
      .should(
        'contain',
        tsd.consignmentHeader.presentedLocationOfGoods.customsOffice
          .referenceNumber
      );
    presentationGeneralInfoPage
      .getGnssLatitude()
      .should(
        'contain',
        tsd.consignmentHeader.presentedLocationOfGoods.gnss.latitude
      );
    presentationGeneralInfoPage
      .getGnssLongitude()
      .should(
        'contain',
        tsd.consignmentHeader.presentedLocationOfGoods.gnss.longitude
      );
  }
);
