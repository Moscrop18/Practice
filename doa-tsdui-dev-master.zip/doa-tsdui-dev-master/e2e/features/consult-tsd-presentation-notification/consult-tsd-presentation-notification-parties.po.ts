import { DeclarationType, EnsReuse } from '../common/customTypes';

export class ConsultPresentationNotificationPartiesPage {
  visitPartiesPage() {
    cy.loginWithEO();
    cy.visit(
      '/advanced-search/search-results/20BETP000000C3FLU4/presentation-notification-parties'
    );
  }
  navigatePartiesPage(): any {
    cy.visit(
      '/advanced-search/search-results/20BETP000000C3FLU4/presentation-notification-parties'
    );
  }
  getPartiesTitle(): any {
    return cy.get('[data-testid=parties]');
  }
  getPersonPresentingTheGoodsTitle(): any {
    return cy.get('[data-testid=personPresentingTheGoods]');
  }
  getPersonsPresentingTheGoodsEoriNumber(): any {
    return cy.get('[data-testid=eori]');
  }
  getPersonsPresentingTheGoodsName(): any {
    return cy.get('[data-testid=name]');
  }
  getCarrierTitle(): any {
    return cy.get('[data-testid=carrier]');
  }
  getCarrierEoriNumber(): any {
    return cy.get('[data-testid=carrierEori]');
  }
  getCarrierName(): any {
    return cy.get('[data-testid=carrierName]');
  }
}
