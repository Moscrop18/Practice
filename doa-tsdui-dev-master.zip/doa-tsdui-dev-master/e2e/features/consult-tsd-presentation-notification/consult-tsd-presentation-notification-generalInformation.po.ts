import { DeclarationType, EnsReuse } from '../common/customTypes';

export class ConsultPresentationNotificationGeneralInfoPage {
  visitGeneralInfoPage() {
    cy.visit(
      '/advanced-search/search-results/20BETP000000C3FLU4/presentation-notification-information'
    );
  }
  getGeneralInformationTitle(): any {
    return cy.get('[data-testid=generalInformation]');
  }
  getfrn(): any {
    return cy.get('[data-testid=frn]');
  }
  getNotificationInformationTitle(): any {
    return cy.get('[data-testid=notificationInformation]');
  }
  getDeclarationDateAndTime(): any {
    return cy.get('[data-testid=declarationDateAndTime]');
  }
  getPresentationOfGoodsDateAndTime(): any {
    return cy.get('[data-testid=dateAndTimeOfPresentationOfTheGoods]');
  }
  getAddressedCustomOfficeTitle(): any {
    return cy.get('[data-testid=addressedCustomsOffice]');
  }
  getCustomOfficeOfPresentation(): any {
    return cy.get('[data-testid=customsOfficeOfPresentation]');
  }
  getPresentedLocationOfGoodsTitle(): any {
    return cy.get('[data-testid=presentedLocationOfGoods]');
  }
  getLocationType(): any {
    return cy.get('[data-testid=locationTypeValue]');
  }
  getQualifier(): any {
    return cy.get('[data-testid=qualifier]');
  }
  getEconomicOperator(): any {
    return cy.get('[data-testid=economicOperator]');
  }
  getStreetAndNumber(): any {
    return cy.get('[data-testid=streetAndNumber]');
  }
  getCountry(): any {
    return cy.get('[data-testid=country]');
  }
  getCity(): any {
    return cy.get('[data-testid=city]');
  }
  getPostCode(): any {
    return cy.get('[data-testid=postCode]');
  }
  getAuthorisationNumber(): any {
    return cy.get('[data-testid=authorisationNumber]');
  }
  getUnlocode(): any {
    return cy.get('[data-testid=unlocode]');
  }
  getCustomsOfficeReferenceNumber(): any {
    return cy.get('[data-testid=customsOfficeReferenceNumber]');
  }
  getGnssLatitude(): any {
    return cy.get('[data-testid=gnssLatitude]');
  }
  getGnssLongitude(): any {
    return cy.get('[data-testid=gnssLongitude]');
  }
}
