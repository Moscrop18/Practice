import { ConsignmentInformation } from '@features/manage-declaration/models/consignment-information/cons-info-state';
import { ItemsList } from '@features/manage-declaration/models/consignment-information/cons-items-list';
import { Given, Then, When } from 'cypress-cucumber-preprocessor/steps';
import { columnSort, getCodeAndLabel } from './../../../common/util';
import { MasterGeneralInfoPage } from './master-general-info.po';
import { ConsultDeclarationGeneralInfoPage } from './../../../consult-declaration-information/consult-declaration-information-generalInformation.po';
import { ConsultDeclarationPartiesPage } from './../../../consult-declaration-information/consult-declaration-information-parties.po';

let partiesPage = new ConsultDeclarationPartiesPage();
let tsd: any;
let generalInfoPage = new ConsultDeclarationGeneralInfoPage();
let page = new MasterGeneralInfoPage();
let consignment: ConsignmentInformation;
let goodsItems: ItemsList[];
let codeList: any;
let draftAPI = '/api/v1/temporaryStorageDeclarations/invalidConsultLink';

let tableHeaders = {
  'Transport equipment': [
    'Container',
    'Identification number',
    'Container packed status',
    'Number of seals',
    'Seal identifier'
  ],
  'Receptacle(s)': ['No.', 'Identification number'],
  'Supporting document(s)': ['No.', 'Type', 'Reference number'],
  'Additional information': ['No.', 'Notes'],
  'Additional supply chain actor(s)': [
    'No.',
    'EORI',
    'Name',
    'Role',
    'Authorisation'
  ]
};

Given(
  'I have navigated to the Master consignment General Information tab',
  () => {
    cy.fixture('tsd-master-consignment.json').then((data) => {
      consignment = data;
      tsd = data;
      cy.intercept(
        'GET',
        '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments',
        data
      ).as('consignment');

      cy.intercept(
        'GET',
        '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments/0',
        data
      ).as('masterConsignment');
    });
    cy.fixture('goods-items.json').then((data) => {
      goodsItems = data.items;
      cy.intercept(
        'GET',
        '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments/0/items',
        data
      ).as('goodsItemList');
    });
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4',
      {
        fixture: 'tsd-declaration.json'
      }
    ).as('declaration');
    cy.fixture('codelist.json').then((data) => {
      codeList = data;
      cy.intercept('/assets/codelist/codelist.json', data).as('codeList');
    });
    page.visit();
    cy.wait('@codeList');
  }
);

When(
  'the Master Consignment Gen Info page is displayed with empty sections',
  () => {
    cy.fixture('tsd-consignment2.json').then((data2) => {
      consignment = data2;
      cy.intercept(
        'GET',
        '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments',
        data2
      ).as('consignment');

      cy.intercept(
        'GET',
        '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments/0',
        data2
      ).as('masterConsignment');
    });
    page.visit();
    page.isVisible();
  }
);
When('I verify that no section is present', () => {
  page.getGenInfoPage().should('not.contain', 'Reference number UCR');
  page.getGenInfoPage().should('not.contain', 'Weight');
  page.getGenInfoPage().should('not.contain', 'Previous document');
  page.getGenInfoPage().should('not.contain', 'Supporting document(s)');
});

When('the Master Consignment General Information page is displayed', () => {
  page.isVisible();
});

Then('I should see the title MASTER CONSIGNMENT', () => {
  page.getMasterConsignmentTitle().should('contain', 'Master consignment');
});

Then('I should see the header {string}', (header) => {
  page.getGenTitle(header).should('exist');
});

Then('I should see the title {string}', (title) => {
  page.getCurrentLocationOfGoodsTitle().contains(title, { matchCase: false });
});

Then('I should see the Start date and Time field not empty', () => {
  page.getStartDateTime().should('not.be.disabled').and('not.be.empty');
});

Then(
  'I see the addressed custom office details on general information page',
  () => {
    generalInfoPage
      .getAddressedCustomOffice()
      .should('contain', ' Addressed customs office ');
    generalInfoPage
      .getSupervisingCustomOffice()
      .should(
        'contain',
        codeList.CL141[0].value + ' - ' + codeList.CL141[0].definition
      );
  }
);

Then('I should see Location of Goods section and sub section', () => {
  generalInfoPage
    .getLocationType()
    .should(
      'contain',
      codeList.CL347Combined[0].value +
        ' - ' +
        codeList.CL347Combined[0].definition
    );

  generalInfoPage
    .getQualifier()
    .should(
      'contain',
      codeList.CL326[0].value + ' - ' + codeList.CL326[0].definition
    );
  generalInfoPage
    .getUNLOCODE()
    .should(
      'contain',
      codeList.CL144[0].value + ' - ' + codeList.CL144[0].definition
    );

  generalInfoPage
    .getWareHouseType()
    .should(
      'contain',
      codeList.CL099[0].value + ' - ' + codeList.CL099[0].definition
    );
  generalInfoPage
    .getWareHouseIdentifier()
    .should('contain', tsd.currentLocationOfGoods.warehouse.identifier);
});

Then('TRANSFER NOTIFICATION PARTIES should be expand when click on it', () => {
  page
    .getTransferNotiParties()
    .contains('Transfer notification parties', { matchCase: false });
  page.getTransferNotiParties().click();
});

Then('I see the Declarant details of the declaration', () => {
  partiesPage
    .getDeclarantEoriNumber()
    .should(
      'contain',
      tsd.currentLocationOfGoods.declarant.identificationNumber
    );
  partiesPage
    .getDeclarantPartiesName()
    .should('contain', tsd.currentLocationOfGoods.declarant.name);
  partiesPage
    .getDeclarantEmailId()
    .should(
      'contain',
      tsd.currentLocationOfGoods.declarant.communication[0].identifier
    );
  partiesPage
    .getDeclarantPhoneNumber()
    .should(
      'contain',
      tsd.currentLocationOfGoods.declarant.communication[1].identifier
    );
  partiesPage
    .getDeclarantstreeAndNumber()
    .should(
      'contain',
      tsd.currentLocationOfGoods.declarant.address.streetAndNumber
    );
  partiesPage
    .getDeclarantPoBox()
    .should('contain', tsd.currentLocationOfGoods.declarant.address.poBox);
  partiesPage
    .getDeclarantCountryName()
    .should('contain', tsd.currentLocationOfGoods.declarant.address.country);
  partiesPage
    .getDeclarantCityName()
    .should('contain', tsd.currentLocationOfGoods.declarant.address.city);
});

Then('I see the Representative details of the declaration', () => {
  partiesPage
    .getRepresentativeEoriNumber()
    .should(
      'contain',
      tsd.currentLocationOfGoods.representative.identificationNumber
    );
  partiesPage
    .getRepresentativeName()
    .should('contain', tsd.currentLocationOfGoods.representative.name);
  partiesPage
    .getRepresentativeStatus()
    .should('contain', tsd.currentLocationOfGoods.representative.status);
  partiesPage
    .getRepresentativeEmailId()
    .should(
      'contain',
      tsd.currentLocationOfGoods.representative.communication[0].identifier
    );
  partiesPage
    .getRepresentativeStreetAndNum()
    .should(
      'contain',
      tsd.currentLocationOfGoods.representative.address.street
    );

  partiesPage
    .getRepresentativeCountry()
    .should(
      'contain',
      tsd.currentLocationOfGoods.representative.address.country
    );
  partiesPage
    .getRepresentativeCity()
    .should('contain', tsd.currentLocationOfGoods.representative.address.city);
  partiesPage
    .getRepresentativePostCode()
    .should(
      'contain',
      tsd.currentLocationOfGoods.representative.address.postCode
    );
});

Then(
  'I see the Person notifying the arrival after movement details of the declaration',
  () => {
    page
      .getEORIPersonNotify()
      .should(
        'contain',
        tsd.currentLocationOfGoods.personNotifyingTheArrivalAfterMovement
          .identificationNumber
      );
    page
      .getNamePersonNotify()
      .should(
        'contain',
        tsd.currentLocationOfGoods.personNotifyingTheArrivalAfterMovement.name
      );
  }
);

Then('I verify Transport document type', () => {
  page.getTransportDocumentType().should('contain', codeList.CL754[2].label);
});

Then('I verify the transport document reference number', () => {
  page
    .getTransportDocReferenceNumber()
    .should('contain', consignment.transportDocument.referenceNumber);
});

Then('I verify the Weight total gross mass', () => {
  page.getWeightTotalGrossMass().should('contain', consignment.totalGrossMass);
});

Then('I verify the Previous Document type', () => {
  page
    .getPreviousDocumentType()
    .should('contain', consignment.previousDocument.type);
});

Then('I verify the Previous Document reference number', () => {
  page
    .getPreviousDocumentRefNumber()
    .should('contain', consignment.previousDocument.referenceNumber);
});

Then('I verify the Reference Number UCR reference number', () => {
  page
    .getUCRReferenceNumber()
    .should('contain', consignment.referenceNumberUCR);
});

Then('I see the {string} table title and headers', (tableName) => {
  cy.log(tableName);
  page
    .getTable(tableName)
    .should('contain', tableName)
    .getTableHeadersText()
    .should('deep.equal', tableHeaders[tableName]);
});

Then('I see the {string} table content', (tableName) => {
  page
    .getTable(tableName)
    .getTableRows()
    .should('deep.equal', getTableDataSlice(tableName, 0, 10));
});

Then('I can use the pagination of the {string} table', (tableName) => {
  page
    .getTable(tableName)
    .gotoNextTablePage()
    .getTableRows()
    .should('deep.equal', getTableDataSlice(tableName, 10, 15));
  page
    .getTable(tableName)
    .gotoPreviousTablePage()
    .getTableRows()
    .should('deep.equal', getTableDataSlice(tableName, 0, 10));
  page
    .getTable(tableName)
    .setTablePageSize(20)
    .getTableRows()
    .should('deep.equal', getTableDataSlice(tableName, 0, 15));
  page.getTable(tableName).setTablePageSize(10);
});

Then('I can use the sorting of the {string} table', (tableName) => {
  page
    .getTable(tableName)
    .getTableHeaders()
    .each((header, i) =>
      cy
        .wrap(header)
        .click()
        .then(() => {
          let sorted = getTableDataSlice(tableName)
            .sort((a, b) => columnSort(a[i], b[i], i > 0, i < 0))
            .slice(0, 10);
          page.getTable(tableName).getTableRows().should('deep.equal', sorted);
        })
    );
});

Given(
  'I have navigated to the Master consignment General Information tab with invalid URL',
  () => {
    cy.intercept('GET', draftAPI, {
      statusCode: 404,
      body: {}
    }).as('deleteResponse');
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/invalidConsultLink/consignments/0',
      {
        statusCode: 404,
        body: {}
      }
    ).as('deleteResponse');
    page.visit1();
  }
);
Then('I see the PAGE NOT FOUND screen', () => {
  page.validateURLPath();
});

function getTableDataSlice(
  tableTitle: string,
  start: number = 0,
  end?: number
) {
  return getTableData(tableTitle).slice(start, end);
}

function getTableData(tableTitle: string) {
  switch (tableTitle) {
    case 'Transport equipment':
      return transportEquipmentTableData();
    case 'Receptacle(s)':
      return receptaclesTableData();
    case 'Supporting document(s)':
      return supporingDocumentsTableData();
    case 'Additional information':
      return additionalInfoTableData();
    case 'Additional supply chain actor(s)':
      return addSupplyActorTableData();
  }
}
function transportEquipmentTableData(i = 1) {
  return consignment.transportEquipment.map((t) => [
    '' + i++,
    t.containerIdentificationNumber,
    getCodeAndLabel(codeList.CL709, t.containerPackedStatus),
    t.numberOfSeals == 0 ? '/' : t.numberOfSeals,
    t.seal.length == 0 ? '/' : t.seal.length + ' Identifierexpand_more'
  ]);
}
function receptaclesTableData(i = 1) {
  return consignment.receptacle.map((t) => ['' + i++, t.identificationNumber]);
}
function supporingDocumentsTableData(i = 1) {
  return consignment.supportingDocument.map((t) => [
    '' + i++,
    getCodeAndLabel(codeList.CL213, t.type),
    t.referenceNumber
  ]);
}
function additionalInfoTableData(i = 1) {
  return consignment.additionalInformation.map((t) => ['' + i++, t.text]);
}
function addSupplyActorTableData(i = 1) {
  return consignment.additionalSupplyChainActor.map((t) => [
    '' + i++,
    t.identificationNumber,
    t.name,
    getCodeAndLabel(codeList.CL704, t.role),
    '/'
  ]);
}
