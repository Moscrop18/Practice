import { ConsignmentInformation } from '@features/manage-declaration/models/consignment-information/cons-info-state';

export class MasterGeneralInfoPage {
  invalidPath = '/page-not-found';
  visit1() {
    cy.loginWithEO();
    return cy.visit(
      '/advanced-search/search-results/invalidConsultLink/master-consignment'
    );
  }
  validateURLPath() {
    cy.url().should('include', this.invalidPath);
  }
  isVisible() {
    cy.location('pathname').should('contain', 'master-consignment');
  }
  visit() {
    cy.loginWithEO();
    cy.visit(
      '/advanced-search/search-results/20BETP000000C3FLU4/master-consignment'
    );
  }
  getGenInfoPage(): any {
    return cy.get('[data-testid=genInfo]');
  }

  getGenTitle(title): any {
    return cy.get('[class^="mat-subheading"]:contains(' + title + ')');
  }

  getCurrentLocationOfGoodsTitle(): any {
    return cy.get('[data-testid=currentLocationSubHeading]');
  }

  getTransferNotiParties(): any {
    return cy.get('#transferNotificationPartiesTitle');
  }

  getStartDateTime(): any {
    return cy.get('[data-testid=startDateTime]');
  }

  getEORIPersonNotify(): any {
    return cy.get(
      '[data-testid=personNotifyingTheArrivalAfterMovementEoriNumber]'
    );
  }
  getNamePersonNotify(): any {
    return cy.get('[data-testid=personNotifyingTheArrivalAfterMovementName]');
  }

  getMasterConsignmentTitle(): any {
    return cy.get('[data-testid=masterConsignmentTitle]');
  }
  getTransportDocumentTitle(): any {
    return cy.get('[data-testid=transportDocLabel]');
  }
  getTransportDocumentType(): any {
    return cy.get('[data-testid=transportDocTypeValue]');
  }
  getTransportDocReferenceNumber(): any {
    return cy.get('[data-testid=transportDocRefValue]');
  }
  getWeightTitle(): any {
    return cy.get('[data-testid=weightLabel]');
  }
  getWeightTotalGrossMass(): any {
    return cy.get('[data-testid=weightGrossMassValue]');
  }
  getPreviousDocumentTitle(): any {
    return cy.get('[data-testid=prevDocumentLabel]');
  }
  getPreviousDocumentType(): any {
    return cy.get('[data-testid=prevDocumentTypeValue]');
  }
  getPreviousDocumentRefNumber(): any {
    return cy.get('[data-testid=prevDocumentRefValue]');
  }
  getUCRTitle(): any {
    return cy.get('[data-testid=refNumUCRLabel]');
  }
  getUCRReferenceNumber(): any {
    return cy.get('[data-testid=refNumUCRValue]');
  }

  tableSelectors = {
    'Transport equipment': '[data-testid=transportEquipmentTable]',
    'Receptacle(s)': '[data-testid=receptaclesTable]',
    'Supporting document(s)': '[data-testid=supportingDocTable]',
    'Additional information': '[data-testid=additionalInfoTable]',
    'Additional supply chain actor(s)':
      '[data-testid=additionalSupplyActorTable]'
  };
  getTable(title): any {
    return cy.get(this.tableSelectors[title]);
  }
}
