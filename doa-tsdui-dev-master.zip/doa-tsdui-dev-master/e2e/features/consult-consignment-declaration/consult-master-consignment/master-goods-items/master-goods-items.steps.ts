import { Given, Then, When, And } from 'cypress-cucumber-preprocessor/steps';

import { columnSort, getCodeAndLabel } from '../../../common/util';
import { GoodsItemDataPage } from './master-goods-items.po';
import { ItemInformation } from '@features/manage-declaration/models/consignment-information/items';

let page = new GoodsItemDataPage();
let goodsItems: ItemInformation;
let codeList: any;

let tableHeaders = {
  'Transport equipment': [
    'Container',
    'Identification number',
    'Container packed status',
    'Number of seals',
    'Seal identifier'
  ],
  'Supporting document(s)': ['No.', 'Type', 'Reference number'],
  'Additional reference(s) ': ['No.', 'Type', 'Reference number'],
  'Additional information': ['No.', 'Text'],
  'Additional supply chain actor(s)': [
    'No.',
    'EORI',
    'Name',
    'Role',
    'Authorisation'
  ]
};

Given('I have navigated to the Master consignment Goods Item tab', () => {
  cy.fixture('goods-item-data2.json').then((data) => {
    goodsItems = data;
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments/0/items/2',
      data
    ).as('goodsItemData');
  });
  cy.fixture('goods-item-data.json').then((data) => {
    goodsItems = data;
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments/0/items/1',
      data
    ).as('consGoodsItemData');
  });
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4',
    {
      fixture: 'tsd-declaration.json'
    }
  ).as('declaration');
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments/0/items?pageSize=10',
    {
      fixture: 'goods-items.json'
    }
  ).as('goodsItemList');
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments',
    {
      fixture: 'tsd-consignments.json'
    }
  ).as('consignment');

  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments/0',
    {
      fixture: 'tsd-consignment.json'
    }
  ).as('masterConsignment');
  cy.fixture('codelist.json').then((data) => {
    codeList = data;
    cy.intercept('/assets/codelist/codelist.json', data).as('codeList');
  });
  page.visit();
  cy.wait('@codeList');
});

And('I click on item {int} in Goods item table', (row) => {
  page
    .getItemRow(row)
    .click()
    .get('[data-testid="goodsItemTitle"]')
    .should('be.visible');
});

When('the Master Consignment Goods Item page is displayed', () => {
  page.isVisible();
});

When(
  'the Master Consignment Goods Item page is displayed with empty sections',
  () => {
    page.visit2();
    page.isVisible();
  }
);

Then('I should see the title Goods Item', () => {
  cy.wait('@consGoodsItemData').then(() => {
    page.getGoodsItemTitle().should('contain', 'Goods item 1');
    page.getCommodityCodeTitle().should('contain', 'Commodity');
  });
});

When('I see the Commodity title', () => {
  page.getCommodityCodeTitle().should('contain', 'Commodity');
});

Then('I verify the description of goods', () => {
  page
    .getDescriptionOfGoods()
    .should('contain', goodsItems.commodity.descriptionOfGoods);
});

Then('I verify the CUS Code', () => {
  page.getCusCode().should('contain', goodsItems.commodity.cusCode);
});

When('I see the Commodity Code title', () => {
  page.getCommodityCodeTitle().should('contain', 'Commodity code');
});

Then('I verify the Harmonized system sub heading code', () => {
  page
    .getHarmonizedSystemSubHeadingCode()
    .should(
      'contain',
      goodsItems.commodity.commodityCode.harmonizedSystemSubHeadingCode
    );
});

Then('I verify the Combined nomenclature code', () => {
  page
    .getCombinedNomenclatureCode()
    .should(
      'contain',
      goodsItems.commodity.commodityCode.combinedNomenclatureCode
    );
});

When('I see the Weight title', () => {
  page.getWeightTitle().should('contain', 'Weight');
});

Then('I verify the Weight total gross mass', () => {
  page.getWeightTotalGrossMass().should('contain', goodsItems.grossMass);
});

When('I see the Previous Document title', () => {
  page.getPreviousDocumentTitle().should('contain', 'Previous document');
});

Then('I verify the Previous Document type', () => {
  page
    .getPreviousDocumentType()
    .should('contain', goodsItems.previousDocument.type);
});

Then('I click on Goods items tab', () => {
  page.clickItemsTab();
});

Then('I verify the items table', () => {
  page.getGoodsItemTable().should('exist');
});

Then('I verify that no section is present', () => {
  page.getItemPage().should('not.contain', 'Commodity code');
  page.getItemPage().should('not.contain', 'Weight');
  page.getItemPage().should('not.contain', 'Commodity');
  page.getItemPage().should('not.contain', 'Additional supply chain actor(s)');
  page.getItemPage().should('not.contain', 'Additional reference(s)');
});

Then('I verify the Previous Document reference number', () => {
  page
    .getPreviousDocumentRefNumber()
    .should('contain', goodsItems.previousDocument.referenceNumber);
});

Then('I see the {string} table title and headers', (tableName) => {
  page
    .getTable(tableName)
    .should('contain', tableName)
    .getTableHeadersText()
    .should('deep.equal', tableHeaders[tableName]);
});

Then('I see the {string} table content', (tableName) => {
  page
    .getTable(tableName)
    .getTableRows()
    .should('deep.equal', getTableDataSlice(tableName, 0, 10));
});

Then('I can use the pagination of the {string} table', (tableName) => {
  page
    .getTable(tableName)
    .gotoNextTablePage()
    .getTableRows()
    .should('deep.equal', getTableDataSlice(tableName, 10, 15));
  page
    .getTable(tableName)
    .gotoPreviousTablePage()
    .getTableRows()
    .should('deep.equal', getTableDataSlice(tableName, 0, 10));
  page
    .getTable(tableName)
    .setTablePageSize(20)
    .getTableRows()
    .should('deep.equal', getTableDataSlice(tableName, 0, 15));
  page.getTable(tableName).setTablePageSize(10);
});

Then('I can use the sorting of the {string} table', (tableName) => {
  page
    .getTable(tableName)
    .getTableHeaders()
    .each((header, i) =>
      cy
        .wrap(header)
        .click()
        .then(() => {
          let sorted = getTableDataSlice(tableName)
            .sort((a, b) => columnSort(a[i], b[i], i > 0, i < 0))
            .slice(0, 10);
          page.getTable(tableName).getTableRows().should('deep.equal', sorted);
        })
    );
});

function getTableDataSlice(
  tableTitle: string,
  start: number = 0,
  end?: number
) {
  return getTableData(tableTitle).slice(start, end);
}

function getTableData(tableTitle: string) {
  switch (tableTitle) {
    case 'Transport equipment':
      return transportEquipmentTableData();
    case 'Packaging':
      return packagingTableData();
    case 'Supporting document(s)':
      return supporingDocumentsTableData();
    case 'Additional information':
      return additionalInfoTableData();
    case 'Additional supply chain actor(s)':
      return addSupplyActorTableData();
  }
}
function transportEquipmentTableData(i = 1) {
  return goodsItems.transportEquipment.map((t) => [
    '' + i++,
    t.containerIdentificationNumber,
    getCodeAndLabel(codeList.CL709, t.containerPackedStatus),
    t.numberOfSeals == 0 ? '/' : t.numberOfSeals,
    t.seal.length == 0 ? '/' : t.seal.length + ' Identifierexpand_more'
  ]);
}
function supporingDocumentsTableData(i = 1) {
  return goodsItems.supportingDocument?.map((t) => [
    '' + i++,
    getCodeAndLabel(codeList.CL213, t.type),
    t.referenceNumber
  ]);
}
function additionalInfoTableData(i = 1) {
  return goodsItems.additionalInformation.map((t) => ['' + i++, t.text]);
}
function addSupplyActorTableData(i = 1) {
  return goodsItems.additionalSupplyChainActor.map((t) => [
    '' + i++,
    t.identificationNumber,
    t.name,
    getCodeAndLabel(codeList.CL704, t.role),
    '/'
  ]);
}
function packagingTableData(i = 1) {
  return goodsItems.packaging?.map((t) => [
    '' + i++,
    getCodeAndLabel(codeList.CL017, t.typeOfPackages),
    t.numberOfPackages,
    t.shippingMarks
  ]);
}
