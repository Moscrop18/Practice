export class GoodsItemDataPage {
  isVisible() {
    cy.location('pathname').should('contain', 'items');
  }
  visit() {
    cy.loginWithEO();
    cy.visit(
      '/advanced-search/search-results/20BETP000000C3FLU4/master-consignment'
    );
    this.clickItemsTab();
  }

  clickItemsTab() {
    cy.get('[id^=mat-tab-label-]')
      .find('.mat-tab-label-content')
      .contains('Goods items')
      .click();
  }
  visit2() {
    cy.loginWithEO();
    cy.visit(
      '/advanced-search/search-results/20BETP000000C3FLU4/master-consignment'
    );
    cy.get('[id^=mat-tab-label-]')
      .find('.mat-tab-label-content')
      .contains('Goods items')
      .click();
    cy.get('[data-testid=item2]').click();
  }

  getItemRow(row) {
    return cy.get('[data-testid=item' + row + ']');
  }
  getGoodsItemTitle(): any {
    return cy.get('[data-testid=goodsItemTitle]');
  }
  getGoodsItemTable(): any {
    return cy.get('[data-testid=itemsListTable]');
  }
  getCommodityTitle(): any {
    return cy.get('[data-testid=commodityTitle]');
  }
  getDescriptionOfGoods(): any {
    return cy.get('[data-testid=descriptionOfGoods]');
  }
  getCusCode(): any {
    return cy.get('[data-testid=cusCode]');
  }
  getCommodityCodeTitle(): any {
    return cy.get('[data-testid=commodityCodeTitle]');
  }
  getHarmonizedSystemSubHeadingCode(): any {
    return cy.get('[data-testid=harmonizedSystemSubHeadingCode]');
  }
  getCombinedNomenclatureCode(): any {
    return cy.get('[data-testid=combinedNomenclatureCode]');
  }
  getWeightTitle(): any {
    return cy.get('[data-testid=weightLabel]');
  }
  getWeightTotalGrossMass(): any {
    return cy.get('[data-testid=weightGrossMassValue]');
  }
  getPreviousDocumentTitle(): any {
    return cy.get('[data-testid=prevDocumentLabel]');
  }
  getPreviousDocumentType(): any {
    return cy.get('[data-testid=prevDocumentTypeValue]');
  }
  getPreviousDocumentRefNumber(): any {
    return cy.get('[data-testid=prevDocumentRefValue]');
  }
  getItemPage() {
    return cy.get('[data-testid=itemScreen]');
  }

  tableSelectors = {
    'Transport equipment': '[data-testid=transportEquipmentTable]',
    'Additional information': '[data-testid=additionalInfoTable]',
    'Additional supply chain actor(s)':
      '[data-testid=additionalSupplyActorTable]'
  };
  getTable(title): any {
    return cy.get(this.tableSelectors[title]);
  }
}
