import { ConsignmentInformation } from '@features/manage-declaration/models/consignment-information/cons-info-state';
import { Given, Then, When } from 'cypress-cucumber-preprocessor/steps';
import { MasterDeclarationPartiesPage } from './master-parties-info.po';

let page = new MasterDeclarationPartiesPage();
let consignment: ConsignmentInformation;
let codeList: any;
Given('I have navigated to the Master consignment Parties tab', () => {
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4',
    {
      fixture: 'tsd-declaration.json'
    }
  ).as('declaration');

  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments/0/items',
    {
      fixture: 'goods-items.json'
    }
  ).as('goodsItemList');
  cy.fixture('tsd-consignment.json').then((data) => {
    consignment = data;
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments',
      data
    ).as('consignment');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments/0',
      data
    ).as('masterConsignment');
  });

  cy.fixture('codelist.json').then((data) => {
    codeList = data;
    cy.intercept('/assets/codelist/codelist.json', data).as('codeList');
  });
  page.visit();
  cy.wait('@codeList');
});

When(
  'the Master Consignment Parties page is displayed with empty sections',
  () => {
    cy.fixture('tsd-consignment2.json').then((data2) => {
      consignment = data2;
      cy.intercept(
        'GET',
        '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments',
        data2
      ).as('consignment');

      cy.intercept(
        'GET',
        '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments/0',
        data2
      ).as('masterConsignment');
    });
    page.visit();
    page.isVisible();
  }
);
When('I verify that no section is present', () => {
  page.getPartyPage().should('not.contain', 'Consingor');
  page.getPartyPage().should('not.contain', 'Consignee');
  page.getPartyPage().should('not.contain', 'Notify party');
});

When('the Master Consignment Parties page is displayed', () => {
  page.isVisible();
});

When('I see the Consignor title', () => {
  page.getConsignorTitle().should('contain', 'Consignor');
});

Then('I verify the Consignor details', () => {
  page
    .getConsignorTypeOfPerson()
    .should('contain', consignment.consignor.typeOfPerson);
  page
    .getConsignorIdNumber()
    .should('contain', consignment.consignor.identificationNumber);
  page.getConsignorName().should('contain', consignment.consignor.name);
  page
    .getConsignorEmail()
    .should('contain', consignment.consignor.communication[0].identifier);
  page
    .getConsignorPhone()
    .should('contain', consignment.consignor.communication[1].identifier);
  page
    .getConsignorStreetAndNumber()
    .should('contain', consignment.consignor.address.street);
  page
    .getConsignorCountry()
    .should('contain', consignment.consignor.address.country);
  page.getConsignorCity().should('contain', consignment.consignor.address.city);
  page
    .getConsignorPostCode()
    .should('contain', consignment.consignor.address.postCode);
  page
    .getConsignorSubDivision()
    .should('contain', consignment.consignor.address.subDivision);
  page
    .getConsignorPoBox()
    .should('contain', consignment.consignor.address.poBox);
  page
    .getConsignorstreetAdditionalLineVal()
    .should('contain', consignment.consignor.address.additionalStreetLine);
});

When('I see the Consignee title', () => {
  page.getConsigneeTitle().should('contain', 'Consignee');
});

Then('I verify the Consignee details', () => {
  page
    .getConsigneeTypeOfPerson()
    .should('contain', consignment.consignee.typeOfPerson);
  page
    .getConsigneeIdNumber()
    .should('contain', consignment.consignee.identificationNumber);
  page.getConsigneeName().should('contain', consignment.consignee.name);
  page
    .getConsigneeEmail()
    .should('contain', consignment.consignee.communication[0].identifier);
  page
    .getConsigneePhone()
    .should('contain', consignment.consignee.communication[1].identifier);
  page
    .getConsigneeStreetAndNumber()
    .should('contain', consignment.consignee.address.street);
  page
    .getConsigneeCountry()
    .should('contain', consignment.consignee.address.country);
  page.getConsignorCity().should('contain', consignment.consignor.address.city);
  page
    .getConsigneePostCode()
    .should('contain', consignment.consignee.address.postCode);
  page
    .getConsigneeSubDivision()
    .should('contain', consignment.consignee.address.subDivision);
  page
    .getConsigneePoBox()
    .should('contain', consignment.consignee.address.poBox);
  page
    .getConsigneestreetAdditionalLineVal()
    .should('contain', consignment.consignee.address.additionalStreetLine);
});

When('I see the Notify Party title', () => {
  page.getNotifyPartyTitle().should('contain', 'Notify party');
});

Then('I verify the Notify Party details', () => {
  page
    .getNotifyPartyTypeOfPerson()
    .should('contain', consignment.notifyParty.typeOfPerson);
  page
    .getNotifyPartyIdNumber()
    .should('contain', consignment.notifyParty.identificationNumber);
  page.getNotifyPartyName().should('contain', consignment.notifyParty.name);
  page
    .getNotifyPartyEmail()
    .should('contain', consignment.notifyParty.communication[0].identifier);
  page
    .getNotifyPartyPhone()
    .should('contain', consignment.notifyParty.communication[1].identifier);
  page
    .getNotifyPartyStreetAndNumber()
    .should('contain', consignment.notifyParty.address.streetAndNumber);
  page
    .getNotifyPartyCountry()
    .should('contain', consignment.notifyParty.address.country);
  page
    .getNotifyPartyCity()
    .should('contain', consignment.notifyParty.address.city);
  page
    .getNotifyPartyPostCode()
    .should('contain', consignment.notifyParty.address.postCode);
});
