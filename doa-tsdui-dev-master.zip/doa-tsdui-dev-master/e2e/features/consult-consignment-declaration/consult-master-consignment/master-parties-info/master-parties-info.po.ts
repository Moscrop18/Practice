import { ConsignmentInformation } from '@features/manage-declaration/models/consignment-information/cons-info-state';
import { Codelist } from '@core/gateways/codelist/model/addressed-customs-office-code';

export class MasterDeclarationPartiesPage {
  isVisible() {
    cy.location('pathname').should('contain', 'master-consignment');
  }
  visit() {
    cy.loginWithEO();
    cy.visit(
      '/advanced-search/search-results/20BETP000000C3FLU4/master-consignment'
    );
    cy.get('[id^=mat-tab-label-]')
      .find('.mat-tab-label-content')
      .contains('Parties')
      .click();
  }

  getPartyPage() {
    return cy.get('[data-testid=partyScreen]');
  }
  getConsignorTitle(): any {
    return cy.get('[data-testid=consignorTitle]');
  }

  getConsignorTypeOfPerson(): any {
    return cy.get('[data-testid=typeOfPersonConsignorVal]');
  }

  getConsignorIdNumber(): any {
    return cy.get('[data-testid=consignorIdNumberVal]');
  }

  getConsignorName(): any {
    return cy.get('[data-testid=consignorNameVal]');
  }

  getConsignorPhone(): any {
    return cy.get('[data-testid=consignorPhoneNumberVal]');
  }

  getConsignorEmail(): any {
    return cy.get('[data-testid=consignorEmailId]');
  }

  getConsignorStreetAndNumber(): any {
    return cy.get('[data-testid=consignorStreetVal]');
  }

  getConsignorCountry(): any {
    return cy.get('[data-testid=consignorCountryVal]');
  }

  getConsignorCity(): any {
    return cy.get('[data-testid=consignorCity]');
  }

  getConsignorPostCode(): any {
    return cy.get('[data-testid=consignorPostCodeVal]');
  }

  getConsignorSubDivision(): any {
    return cy.get('[data-testid=consignorStreetValSD]');
  }

  getConsignorstreetAdditionalLineVal(): any {
    return cy.get('[data-testid=consignorstreetAdditionalLineVal]');
  }

  getConsignorPoBox(): any {
    return cy.get('[data-testid=consignorPoboxVal]');
  }

  getConsigneeTitle(): any {
    return cy.get('[data-testid=consigneeTitle]');
  }

  getConsigneeTypeOfPerson(): any {
    return cy.get('[data-testid=consigneeTypeOfPersonVal]');
  }

  getConsigneeIdNumber(): any {
    return cy.get('[data-testid=consigneeIdNumberVal]');
  }

  getConsigneeName(): any {
    return cy.get('[data-testid=consigneeNameVal]');
  }

  getConsigneePhone(): any {
    return cy.get('[data-testid=consigneePhoneNumberVal]');
  }

  getConsigneeEmail(): any {
    return cy.get('[data-testid=consigneeEmailIdVal]');
  }

  getConsigneeStreetAndNumber(): any {
    return cy.get('[data-testid=consigneeStreetVal]');
  }

  getConsigneeCountry(): any {
    return cy.get('[data-testid=consigneeCountryVal]');
  }

  getConsigneeCity(): any {
    return cy.get('[data-testid=consigneeCityVal]');
  }

  getConsigneePostCode(): any {
    return cy.get('[data-testid=consigneePostCodeVal]');
  }

  getConsigneeSubDivision(): any {
    return cy.get('[data-testid=consigneeStreetValSD]');
  }

  getConsigneePoBox(): any {
    return cy.get('[data-testid=consigneePoboxVal]');
  }

  getConsigneestreetAdditionalLineVal(): any {
    return cy.get('[data-testid=consigneestreetAdditionalLineVal]');
  }

  getNotifyPartyTitle(): any {
    return cy.get('[data-testid=notifyTitle]');
  }

  getNotifyPartyTypeOfPerson(): any {
    return cy.get('[data-testid=typeOfPersonValue]');
  }

  getNotifyPartyIdNumber(): any {
    return cy.get('[data-testid=idNumberNotifyValue]');
  }

  getNotifyPartyName(): any {
    return cy.get('[data-testid=notifyNameValue]');
  }

  getNotifyPartyPhone(): any {
    return cy.get('[data-testid=phoneNumberNotifyVal]');
  }

  getNotifyPartyEmail(): any {
    return cy.get('[data-testid=emailIdNotifyVal]');
  }

  getNotifyPartyStreetAndNumber(): any {
    return cy.get('[data-testid=notifyStreetVal]');
  }

  getNotifyPartyCountry(): any {
    return cy.get('[data-testid=notifyCountryVal]');
  }

  getNotifyPartyCity(): any {
    return cy.get('[data-testid=notifyCityVal]');
  }

  getNotifyPartyPostCode(): any {
    return cy.get('[data-testid=notifyPostCodeVal]');
  }
}
