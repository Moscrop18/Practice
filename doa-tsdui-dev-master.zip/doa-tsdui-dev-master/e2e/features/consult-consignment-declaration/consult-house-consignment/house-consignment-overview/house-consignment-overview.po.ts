import { HouseConsOverview } from '@features/manage-declaration/models/house-overview/house-cons-overview';

export class HouseGeneralInfoPage {
  invalidPath = '/page-not-found';
  visit1() {
    cy.loginWithEO();
    return cy.visit(
      '/advanced-search/search-results/invalidConsultLink/house-consignment'
    );
  }
  validateURLPath() {
    cy.url().should('include', this.invalidPath);
  }
  isVisible() {
    cy.location('pathname').should('contain', 'house-consignment');
  }
  visit() {
    cy.loginWithEO();
    cy.visit(
      '/advanced-search/search-results/20BETP000000C3FLU4/house-consignment'
    );
  }

  clickOnTableRow(): any {
    cy.get('tbody > tr').find('>td').eq(4).click();
  }

  clickOnHouseConsignments(): any {
    cy.get(':nth-child(5) > .active').click();
  }
  getHouseConsignmentGenInfoTitle(): any {
    return cy.get('[data-testid=houseConsignmentTitle]');
  }

  tableSelectors = {
    'House consignment(s)': '[data-testid=houseConsignmentsTable]'
  };

  getTable(title): any {
    return cy.get(this.tableSelectors[title]);
  }

  getDeconsolidationSectionHeader() {
    return cy.get('[data-testid = "deconsolidationNotificationSubHeading"]');
  }
  getDeconsolidationPanelHeader() {
    return cy.get('#deconsolidationNotificationPartiesTitle');
  }
  getConsolidationIcon() {
    return this.getDeconsolidationSectionHeader().find('img');
  }
  getDeconsolidationPartiesPanel() {
    return cy.get(
      '.deconsolidationNotificationPartiesPanelContainer .mat-expansion-panel-header'
    );
  }

  getHouseConsignmentRowWithTransferIcon() {
    return cy
      .get('[data-testid="houseConsignmentTable"] .img-container')
      .first();
  }

  getCurrentlocationOfGoodsHeader() {
    return cy.get('[data-testid="currentLocationSubHeading"]');
  }
  getLRN() {
    return cy.get('[data-testid="lrn"]');
  }
  getRegistrationDateAndTime() {
    return cy.get(
      '.deconsolidation-notification [data-testid^=startDateTimeValue]'
    );
  }
  getTransferIconTooltip() {
    return cy.get('.mat-tooltip');
  }
}
