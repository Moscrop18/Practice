import { HouseConsOverview } from '@features/manage-declaration/models/house-overview/house-cons-overview';
import { And, Given, Then, When } from 'cypress-cucumber-preprocessor/steps';
import { HouseGeneralInfoPage } from './house-consignment-overview.po';
import { ConsultDeclarationGeneralInfoPage } from './../../../consult-declaration-information/consult-declaration-information-generalInformation.po';
import { ConsultDeclarationPartiesPage } from './../../../consult-declaration-information/consult-declaration-information-parties.po';
import { MasterGeneralInfoPage } from './../../../consult-consignment-declaration/consult-master-consignment/master-general-info/master-general-info.po';

let ConsultMasterGeneralInfoPage = new MasterGeneralInfoPage();
let partiesPage = new ConsultDeclarationPartiesPage();
let tsd: any;
let codeList: any;
let rowId;
let currentLocationData;
let generalInfoPage = new ConsultDeclarationGeneralInfoPage();
let page = new HouseGeneralInfoPage();
let houseConsignment: HouseConsOverview[];
let draftAPI = '/api/v1/temporaryStorageDeclarations/invalidConsultLink';
let tableHeaders = {
  'House consignment(s)': [
    'No.',
    'Transport ...',
    'Consignee',
    'Consignor',
    'Total gros...',
    ''
  ]
};

Given('I have navigated to the House Consignment overview screen', () => {
  cy.fixture('tsd-declaration.json').then((data) => {
    currentLocationData = data;
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4',
      data
    ).as('declaration');
  });

  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/mrn12', {
    fixture: 'tsd-declaration.json'
  });
  cy.fixture('tsd-master-consignment.json').then((data) => {
    tsd = data;
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments/1',
      data
    ).as('houseInformation1');
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/mrn12/consignments/1',
      data
    ).as('houseInformation2');
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments/5',
      data
    ).as('houseInformationWithTransfer');
  });

  cy.fixture('house-overview-mock.json').then((data) => {
    houseConsignment = data.items;
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments?pageSize=10&type=House',
      data
    ).as('houseConsignment2');
  });
  cy.fixture('house-overview-mock.json').then((data) => {
    houseConsignment = data.items;
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments?type=House&pageSize=10',
      data
    ).as('houseConsignment');
  });
  cy.fixture('house-overview-mock.json').then((data) => {
    houseConsignment = data.items;
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments?pageSize=10',
      data
    ).as('houseConsignment');
  });
  cy.fixture('codelist.json').then((data) => {
    codeList = data;
    cy.intercept('/assets/codelist/codelist.json', data).as('codeList');
  });
  page.visit();
  cy.wait('@codeList');
});

When('the House consignment page is displayed', () => {
  page.isVisible();
});

Then('I see the {string} table title and headers', (tableName) => {
  page
    .getTable(tableName)
    .should('contain', tableName)
    .getTableHeadersText()
    .should('deep.equal', tableHeaders[tableName]);
});

When('I click on the first row of the table', () => {
  rowId = 1;
  page.clickOnTableRow();
});

And('I click on HouseConsignment breadcrumb', () => {
  page.clickOnHouseConsignments();
});

Then(
  'I should see the House consignment general information page title with item number',
  () => {
    page
      .getHouseConsignmentGenInfoTitle()
      .should('contain', 'House consignment ' + rowId);
  }
);

When('I see the {string} table content', (tableName) => {
  page
    .getTable(tableName)
    .getTableRows()
    .should('deep.equal', getTableDataSlice(0, 10, houseConsignment));
});

Then('I can use the pagination of the {string} table', (tableName) => {
  cy.fixture('house-overview-mock2.json').then((data) => {
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments?type=House&pageSize=10&page=1&sort=sequenceNumber',
      data
    ).as('houseConsignmentPage2');
  });
  page.getTable(tableName).gotoNextTablePage();
  cy.wait('@houseConsignmentPage2').then((data) => {
    page
      .getTable(tableName)
      .getTableRows()
      .should('deep.equal', getTableDataSlice(0, 9, data.response.body.items));
  });
  cy.fixture('house-overview-mock.json').then((data) => {
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments?type=House&pageSize=10&page=0&sort=sequenceNumber',
      data
    ).as('houseConsignmentPage0');
  });
  page.getTable(tableName).gotoPreviousTablePage();
  cy.wait('@houseConsignmentPage0').then((data) => {
    page
      .getTable(tableName)
      .getTableRows()
      .should('deep.equal', getTableDataSlice(0, 10, data.response.body.items));
  });
  cy.fixture('house-overview-mock20.json').then((data) => {
    houseConsignment = data.items;
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments?type=House&pageSize=20',
      data
    ).as('houseConsignmentSize20');
  });
  page.getTable(tableName).setTablePageSize(20);
  cy.wait('@houseConsignmentSize20').then((data) => {
    page
      .getTable(tableName)
      .getTableRows()
      .should('deep.equal', getTableDataSlice(0, 20, data.response.body.items));
  });
  cy.fixture('house-overview-mock.json').then((data) => {
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments?type=House&sort=sequenceNumber&pageSize=10',
      data
    ).as('houseConsignment');
  });
  page.getTable(tableName).setTablePageSize(10);
  cy.wait('@houseConsignment2').then((data) => {
    page
      .getTable(tableName)
      .getTableRows()
      .should('deep.equal', getTableDataSlice(0, 10, data.response.body.items));
  });
});

Then('I can use the sorting of the {string} table', (tableName) => {
  cy.fixture('house-overview-mock-desc.json').then((data) => {
    houseConsignment = data.items;
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments?type=House&sort=-sequenceNumber&pageSize=10',
      data
    ).as('houseConsignmentDesc');
  });
  cy.fixture('house-overview-mock-transport.json').then((data) => {
    houseConsignment = data.items;
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments?type=House&sort=transportDocument.referenceNumber&pageSize=10',
      data
    ).as('houseConsignmentDesc');
  });
  cy.fixture('house-overview-mock-transport.json').then((data) => {
    houseConsignment = data.items;
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments?type=House&sort=-transportDocument.referenceNumber&pageSize=10',
      data
    ).as('houseConsignmentDesc');
  });
  page
    .getTable(tableName)
    .getTableHeaders()
    .each((header, i) => {
      if (i != 1) {
        return;
      }
      cy.wrap(header).click();
      cy.wrap(header).click();
    });
});

Given(
  'I have navigated to the House Consignment overview screen with invalid URL',
  () => {
    cy.intercept('GET', draftAPI, {
      statusCode: 404,
      body: {}
    }).as('deleteResponse');
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/invalidConsultLink/consignments?pageSize=10&type=House',
      {
        statusCode: 404,
        body: {}
      }
    ).as('deleteResponse');
    page.visit1();
  }
);
Then('I see the PAGE NOT FOUND screen', () => {
  page.validateURLPath();
});

Then('I should see the header {string}', (header) => {
  ConsultMasterGeneralInfoPage.getGenTitle(header).should('exist');
});

Then('I should see the title {string}', (title) => {
  cy.wait('@houseInformation1');
  ConsultMasterGeneralInfoPage.getCurrentLocationOfGoodsTitle().contains(
    title,
    { matchCase: false }
  );
});

Then('I should see the Start date and Time field not empty', () => {
  ConsultMasterGeneralInfoPage.getStartDateTime()
    .should('not.be.disabled')
    .and('not.be.empty');
});

Then(
  'I see the addressed custom office details on general information page',
  () => {
    generalInfoPage
      .getAddressedCustomOffice()
      .should('contain', ' Addressed customs office ');
    generalInfoPage
      .getSupervisingCustomOffice()
      .should(
        'contain',
        codeList.CL141[0].value + ' - ' + codeList.CL141[0].definition
      );
  }
);

Then('TRANSFER NOTIFICATION PARTIES should be expand when click on it', () => {
  ConsultMasterGeneralInfoPage.getTransferNotiParties().contains(
    'Transfer notification parties',
    { matchCase: false }
  );
  ConsultMasterGeneralInfoPage.getTransferNotiParties().click();
});

Then('I see the Declarant details of the declaration', () => {
  partiesPage
    .getDeclarantEoriNumber()
    .should(
      'contain',
      tsd.currentLocationOfGoods.declarant.identificationNumber
    );
  partiesPage
    .getDeclarantPartiesName()
    .should('contain', tsd.currentLocationOfGoods.declarant.name);
  partiesPage
    .getDeclarantEmailId()
    .should(
      'contain',
      tsd.currentLocationOfGoods.declarant.communication[0].identifier
    );
  partiesPage
    .getDeclarantPhoneNumber()
    .should(
      'contain',
      tsd.currentLocationOfGoods.declarant.communication[1].identifier
    );
  partiesPage
    .getDeclarantstreeAndNumber()
    .should(
      'contain',
      tsd.currentLocationOfGoods.declarant.address.streetAndNumber
    );
  partiesPage
    .getDeclarantPoBox()
    .should('contain', tsd.currentLocationOfGoods.declarant.address.poBox);
  partiesPage
    .getDeclarantCountryName()
    .should('contain', tsd.currentLocationOfGoods.declarant.address.country);
  partiesPage
    .getDeclarantCityName()
    .should('contain', tsd.currentLocationOfGoods.declarant.address.city);
});

Then('I see the Representative details of the declaration', () => {
  partiesPage
    .getRepresentativeEoriNumber()
    .should(
      'contain',
      tsd.currentLocationOfGoods.representative.identificationNumber
    );
  partiesPage
    .getRepresentativeName()
    .should('contain', tsd.currentLocationOfGoods.representative.name);
  partiesPage
    .getRepresentativeStatus()
    .should('contain', tsd.currentLocationOfGoods.representative.status);
  partiesPage
    .getRepresentativeEmailId()
    .should(
      'contain',
      tsd.currentLocationOfGoods.representative.communication[0].identifier
    );
  partiesPage
    .getRepresentativeStreetAndNum()
    .should(
      'contain',
      tsd.currentLocationOfGoods.representative.address.street
    );

  partiesPage
    .getRepresentativeCountry()
    .should(
      'contain',
      tsd.currentLocationOfGoods.representative.address.country
    );
  partiesPage
    .getRepresentativeCity()
    .should('contain', tsd.currentLocationOfGoods.representative.address.city);
  partiesPage
    .getRepresentativePostCode()
    .should(
      'contain',
      tsd.currentLocationOfGoods.representative.address.postCode
    );
});

Then(
  'I see the Person notifying the arrival after movement details of the declaration',
  () => {
    ConsultMasterGeneralInfoPage.getEORIPersonNotify().should(
      'contain',
      tsd.currentLocationOfGoods.personNotifyingTheArrivalAfterMovement
        .identificationNumber
    );
    ConsultMasterGeneralInfoPage.getNamePersonNotify().should(
      'contain',
      tsd.currentLocationOfGoods.personNotifyingTheArrivalAfterMovement.name
    );
  }
);

And(
  'I see {string} section with deconsolidation parties panel collapsed',
  (sectionHeader) => {
    if (sectionHeader === 'Deconsolidation notification') {
      page.getDeconsolidationSectionHeader().should('contain', sectionHeader);
      page
        .getConsolidationIcon()
        .should('be.visible')
        .and('have.prop', 'naturalWidth')
        .should('be.greaterThan', 0);
      page
        .getDeconsolidationPanelHeader()
        .should('contain', 'Deconsolidation notification parties');
      page
        .getDeconsolidationPartiesPanel()
        .should('have.attr', 'aria-expanded', 'false');
    }
  }
);
And('I can see the transfer icon for the rows with transfered goods', () => {
  page.getHouseConsignmentRowWithTransferIcon().trigger('mouseenter');
  page.getTransferIconTooltip().should('contain', 'Transfer');
  page
    .getHouseConsignmentRowWithTransferIcon()
    .find('img')
    .should('be.visible')
    .and('have.prop', 'naturalWidth')
    .should('be.greaterThan', 0);
  page
    .getLRN()
    .should('contain', currentLocationData.deconsolidationNotification.lrn);
  page.getRegistrationDateAndTime().should('contain', ' Aug 24, 2019');
});
When('I click on the first row of the table with transfer icon', () => {
  rowId = 5;
  page.getHouseConsignmentRowWithTransferIcon().first().click();
});
And('I see heading current location of goods with transfer icon', () => {
  page.getCurrentlocationOfGoodsHeader().within((ele) => {
    cy.get('[data-testid="shippingImg"]')
      .should('be.visible')
      .should('have.prop', 'alt');
    cy.get('.fin-overline').should('contain', 'Current location of goods');
  });
});

Then('I see declarant detials in notification panel', () => {
  generalInfoPage.getDeclarant().should('contain', 'Declarant');
  partiesPage
    .getDeclarantEoriNumber()
    .should(
      'contain',
      currentLocationData.deconsolidationNotification.declarant
        .identificationNumber
    );
  partiesPage
    .getDeclarantPartiesName()
    .should(
      'contain',
      currentLocationData.deconsolidationNotification.declarant.name
    );
  partiesPage
    .getDeclarantEmailId()
    .should(
      'contain',
      currentLocationData.deconsolidationNotification.declarant.communication[0]
        .identifier
    );
  partiesPage
    .getDeclarantstreeAndNumber()
    .should(
      'contain',
      currentLocationData.deconsolidationNotification.declarant.address
        .streetAndNumber
    );
  partiesPage
    .getDeclarantPoBox()
    .should(
      'contain',
      currentLocationData.deconsolidationNotification.declarant.address.poBox
    );
  partiesPage
    .getDeclarantCountryName()
    .should(
      'contain',
      currentLocationData.deconsolidationNotification.declarant.address.country
    );
  partiesPage
    .getDeclarantCityName()
    .should(
      'contain',
      currentLocationData.deconsolidationNotification.declarant.address.city
    );
  partiesPage
    .getDeclarantPostCode()
    .should(
      'contain',
      currentLocationData.deconsolidationNotification.declarant.address.postCode
    );
});

Then('I expand {string} panel', () => {
  page
    .getDeconsolidationPartiesPanel()
    .should('contain', 'Deconsolidation notification parties')
    .click();
});

Then('I should see Location of Goods section and sub section', () => {
  generalInfoPage
    .getLocationType()
    .should(
      'contain',
      codeList.CL347Combined[0].value +
        ' - ' +
        codeList.CL347Combined[0].definition
    );

  generalInfoPage
    .getQualifier()
    .should(
      'contain',
      codeList.CL326[0].value + ' - ' + codeList.CL326[0].definition
    );
  generalInfoPage
    .getUNLOCODE()
    .should(
      'contain',
      codeList.CL144[0].value + ' - ' + codeList.CL144[0].definition
    );

  generalInfoPage
    .getWareHouseType()
    .should(
      'contain',
      codeList.CL099[0].value + ' - ' + codeList.CL099[0].definition
    );
  generalInfoPage
    .getWareHouseIdentifier()
    .should('contain', tsd.currentLocationOfGoods.warehouse.identifier);
});

function getTableDataSlice(
  start: number = 0,
  end?: number,
  data?: HouseConsOverview[]
) {
  return getTableData(data).slice(start, end);
}

function getTableData(data: HouseConsOverview[]) {
  return data.map((t) => [
    '' + t.sequenceNumber,
    t.transportDocument.referenceNumber,
    t.consignee.name,
    t.consignor.name,
    t.totalGrossMass + ' kg',
    ''
  ]);
}
