import { HouseConsOverview } from '@features/manage-declaration/models/house-overview/house-cons-overview';

export class GoodsItemOvrviewPage {
  isVisible() {
    cy.location('pathname').should('contain', 'master-consignment');
  }
  visit() {
    cy.loginWithEO();
    cy.visit(
      '/advanced-search/search-results/20BETP000000C3FLU4/master-consignment'
    );
    cy.get('[id^=mat-tab-label-]')
      .find('.mat-tab-label-content')
      .contains('Goods items')
      .click();
  }
  getTable(): any {
    return cy.get('[data-testid=itemsListTable]');
  }
}
