import { ItemsList } from '@features/manage-declaration/models/consignment-information/cons-items-list';
import { Given, Then, When } from 'cypress-cucumber-preprocessor/steps';
import { columnSort } from './../../../common/util';
import { GoodsItemOvrviewPage } from './goods-item-overview.po';

let page = new GoodsItemOvrviewPage();
let goodsItems: any;
let tableHeaders = [
  'Item',
  'Commodity description',
  'Harmoized syste...',
  'Combined nomenc...',
  'Gross mass (Kg)'
];

Given('I have navigated to the Goods Item overview screen', () => {
  cy.fixture('goods-items10.json').then((data) => {
    goodsItems = data.items;
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments/0/items?pageSize=10',
      data
    ).as('goodsItemList');
  });
  cy.fixture('goods-items10.json').then((data) => {
    goodsItems = data.items;
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments/0/items?sort=commodity.descriptionOfGoods&pageSize=10',
      data
    ).as('goodsItemList');
  });
  cy.fixture('goods-items10.json').then((data) => {
    goodsItems = data.items;
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments/0/items?sort=-commodity.descriptionOfGoods&pageSize=10',
      data
    ).as('goodsItemList');
  });
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4',
    {
      fixture: 'tsd-declaration.json'
    }
  ).as('declaration');
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments/0',
    {
      fixture: 'tsd-consignment.json'
    }
  ).as('consignment');
  page.visit();
});

When('the Goods Item page is displayed', () => {
  page.isVisible();
});

Then('I see the table headers', (tableName) => {
  page.getTable().getTableHeadersText().should('deep.equal', tableHeaders);
});

When('I see the Goods Item table content', (tableName) => {
  page.getTable().getTableRows().should('deep.equal', getTableDataSlice(0, 10));
});

Then('I can use the pagination of the Goods Item table', (tableName) => {
  page
    .getTable()
    .gotoNextTablePage()
    .getTableRows()
    .should('deep.equal', getTableDataSlice(10, 20));
  page
    .getTable()
    .gotoPreviousTablePage()
    .getTableRows()
    .should('deep.equal', getTableDataSlice(0, 10));
  page
    .getTable()
    .setTablePageSize(20)
    .getTableRows()
    .should('deep.equal', getTableDataSlice(0, 20));
  page.getTable().setTablePageSize(10);
});

Then('I can use the sorting of the Goods Item table', (tableName) => {
  page
    .getTable()
    .getTableHeaders()
    .each((header, i) => {
      if (i != 1) {
        return;
      }
      cy.wrap(header).click();
      cy.wrap(header).click();
    });
});

function getTableDataSlice(start: number = 0, end?: number) {
  return getTableData().slice(start, end);
}

function getTableData(i = 1) {
  return goodsItems.map((t) => [
    '' + t.goodsItemNumber,
    t.commodity.descriptionOfGoods,
    t.commodity.commodityCode.harmonizedSystemSubHeadingCode,
    t.commodity.commodityCode.combinedNomenclatureCode,
    t.grossMass.toString()
  ]);
}
