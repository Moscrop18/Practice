export class ConsultRiskAndControlInfoPage {
  visitGeneralInfoPage() {
    cy.visit(
      '/advanced-search/search-results/20BETP000000C3FLU4/riskAndControlInfo'
    );
  }
  isVisible() {
    cy.location('pathname').should('contain', '/search-results');
  }
  getSeeHistoryButton() {
    return cy.get('#seeHistory');
  }
  getHideButton() {
    return cy.get('[data-testid=hideHistory] >');
  }
  getRiskAndControlHistory() {
    return cy.get('.riskAndControlStatusHistoryContainer');
  }
  getStatusDate() {
    return cy.get('[data-testid^="statusDate-"]');
  }
  getRiskAnalysisNotReceived() {
    return cy.get('#riskAnalysisPanelTitle2');
  }
  getRiskAnalysisResult() {
    return cy.get('#currentStatus2');
  }
  getExpirationDateAndTime() {
    return cy.get('#expirationDateTimeValue2');
  }
  getUnderControlStatus() {
    return cy.get('[data-testid=status-0]');
  }
  getAwaitingRiskAnalysisStatus() {
    return cy.get('[data-testid=status-1]');
  }
  getAwaitingRiskHintStatus() {
    return cy.get('[data-testid=status-2]');
  }
  getControlResultRegisteredStatus() {
    return cy.get('[data-testid=status-3]');
  }
  getPreArrivalRiskAnalysisCompletedStatus() {
    return cy.get('[data-testid=status-4]');
  }
  getPreArrivalRiskAnalysisCancelledStatus() {
    return cy.get('[data-testid=status-5]');
  }
  getNoRiskStatus() {
    return cy.get('[data-testid=status-6]');
  }

  getUnderControlDescription() {
    return cy.get('[data-testid=rac-status-reason-0]');
  }
  getAwaitingRiskAnalysisDescription() {
    return cy.get('[data-testid=rac-status-reason-1]');
  }
  getAwaitingRiskHintDescription() {
    return cy.get('[data-testid=rac-status-reason-2]');
  }
  getControlResultRegisteredDescription() {
    return cy.get('[data-testid=rac-status-reason-3]');
  }
  getPreArrivalRiskAnalysisCompletedDescription() {
    return cy.get('[data-testid=rac-status-reason-4]');
  }
  getPreArrivalRiskAnalysisCancelledDescription() {
    return cy.get('[data-testid=rac-status-reason-5]');
  }
  getNoRiskDescription() {
    return cy.get('[data-testid=rac-status-reason-6]');
  }

  getControlStatusNotReceived() {
    return cy.get('#controlRecommendationTitle2');
  }

  getControlResultReceivedFailure() {
    return cy.get('#controlRecommendation2');
  }
  getControlResultReceivedSuccess() {
    return cy.get('#controlRecommendationTitle1');
  }
  getStatusTime() {
    return cy.get('[data-testid^="statusTime-"]');
  }
  getRiskAnalysisSuccess() {
    return cy.get('#riskAnalysisPanelTitle1');
  }
  tableSelectors = {
    'Risk analysis': '[data-testid="riskAnalysis"]',
    'Control subject': '[data-testid="controlSubjectTable"]'
  };
  getStatusReason() {
    return cy.get('[data-testid^="statusReason-"]');
  }

  getTable(title): any {
    return cy.get(this.tableSelectors[title]);
  }

  getConsignmentType() {
    return cy
      .get('[data-testid="controlSubjectTable"]')
      .find('tbody>tr td .consignmentLink');
  }
  getConsignmentSublevel() {
    return cy
      .get('[data-testid="controlSubjectTable"]')
      .find('tbody>tr td.mat-column-Consignment-sublevel');
  }
}
