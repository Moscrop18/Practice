///<reference types = "Cypress"/>
import { Given, When, Then, And } from 'cypress-cucumber-preprocessor/steps';
import { ConsultRiskAndControlInfoPage } from './consult-tsd-risk-and-control-information.po';
import { random } from 'faker';
import { AdvSearchResultItem } from '@features/advanced-search/models';
import { exists } from 'fs';
const faker = require('faker');
import { StatusHistory } from '@features/manage-declaration/models/status/status-history';
import { RiskAnalysisResult } from '@features/manage-declaration/models/risk-control/RiskAnalysisResult';
import { elementAt } from 'rxjs';
import { log } from 'console';

let page = new ConsultRiskAndControlInfoPage();
let statusData: StatusHistory;
let riskAnalysis: RiskAnalysisResult[];

let tableHeaders = {
  'Risk analysis': [
    'No',
    'Type',
    'Result code',
    'Risk level',
    'Result description'
  ]
};

And('I see time is displayed', () => {
  cy.get('[data-testid=statusTime-0]').should('contain', '19:45');
  cy.get('[data-testid=statusTime-1]').should('contain', '19:44');
});

Given('I have navigated to consult Risk and Control information page', () => {
  cy.fixture('risk-control.json')
    .then((data) => {
      riskAnalysis = data?.riskAnalysis[0]?.response?.riskAnalysisResult;
      cy.intercept(
        'GET',
        '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/riskAnalysisRequests',
        data
      );
    })
    .as('riskcontrol');

  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4',
    {
      fixture: 'tsd-declaration.json'
    }
  ).as('declaration');

  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/riskAndControlStatusHistory',
    {
      fixture: 'risk-control-history.json'
    }
  ).as('riskcontrolhistory');

  cy.loginWithEO();
  page.visitGeneralInfoPage();
  cy.wait('@declaration');
  cy.wait('@riskcontrol');
  cy.wait('@riskcontrolhistory');
  page.getSeeHistoryButton().click();
});

Given('I click on see history button', () => {
  page.getSeeHistoryButton().click();
  cy.wait('@riskcontrolhistory');
  cy.wait('@declaration');
  cy.wait('@riskcontrol');
});
Given('I clicked on hide button', () => {
  page.getHideButton().click();
});

Given('I dont see the history of risk and control status', () => {
  page.getRiskAndControlHistory().should('not.exist');
});
Given('I see history button', () => {
  page.getSeeHistoryButton().should('be.visible');
});
Given(
  'I click on Risk analysis result received section where result is not received',
  () => {
    page.getRiskAnalysisNotReceived().click();
    cy.wait(3000);
  }
);
Given('I see status of Risk analysis result received', () => {
  page.getRiskAnalysisResult().should('contain', 'Not received');
});
Given('I see Expiration date and time', () => {
  page.getExpirationDateAndTime().should('contain', 'Sep 25, 2019 at 19:45');
});
Given('I click on Risk analysis result received section for success', () => {
  page.getRiskAnalysisSuccess().click();
  cy.wait(3000);
});
Then('I see the {string} table title and headers', (tableName) => {
  page
    .getTable('Risk analysis')
    .getTableHeadersText()
    .should('deep.equal', tableHeaders['Risk analysis']);
});
Given('I see the various status on the page', () => {
  page.getUnderControlStatus().should('contain', 'Under control');
  page
    .getAwaitingRiskAnalysisStatus()
    .should('contain', 'Awaiting risk analysis result');
  page
    .getAwaitingRiskHintStatus()
    .should('contain', 'Awaiting risk hit confirmation');
  page
    .getControlResultRegisteredStatus()
    .should('contain', 'Control result registered');
  page
    .getPreArrivalRiskAnalysisCompletedStatus()
    .should('contain', 'Pre-arrival risk analysis completed');
  page
    .getPreArrivalRiskAnalysisCancelledStatus()
    .should('contain', 'Pre-arrival risk analysis cancelled');
  page.getNoRiskStatus().should('contain', 'No risk');
});

Then('I see the status description for each status reason', () => {
  page
    .getUnderControlDescription()
    .should('contain', 'Risk analysis result received from risk system');
  page
    .getAwaitingRiskAnalysisDescription()
    .should('contain', 'Risk analysis result received from risk system');
  page
    .getAwaitingRiskHintDescription()
    .should('contain', 'Risk analysis result received from risk system');
  page
    .getControlResultRegisteredDescription()
    .should(
      'contain',
      'No risk analysis result received before timer expiration'
    );
  page
    .getPreArrivalRiskAnalysisCompletedDescription()
    .should('contain', 'Risk analysis completed within fallback procedure');
  page
    .getPreArrivalRiskAnalysisCancelledDescription()
    .should('contain', 'Control result received from control system');
  page
    .getNoRiskDescription()
    .should('contain', 'Control result registered within fallback procedure');
});
Given(
  'I click on control result received section where result is not received',
  () => {
    page.getControlStatusNotReceived().click();
  }
);
Given('I see status of Control result received', () => {
  page.getControlResultReceivedFailure().should('contain', 'Not received');
});
When('I see the {string} table content', (tableName) => {
  page
    .getTable(tableName)
    .getTableRows()
    .should('deep.equal', convertData(getTableDataSlice(0, 10)));
});

Then('I can use the pagination of the {string} table', (tableName) => {
  page.getTable(tableName).gotoNextTablePage();
  page
    .getTable(tableName)
    .getTableRows()
    .should('have.length', getTableDataSlice(0, 3).length);

  page
    .getTable(tableName)
    .gotoPreviousTablePage()
    .getTableRows()
    .should('have.length', getTableDataSlice(0, 10).length);

  page
    .getTable(tableName)
    .setTablePageSize(20)
    .getTableRows()
    .should('have.length', getTableDataSlice(0, 13).length);
});

When(
  'I click on control recommendation where result is {string}',
  (controlResult) => {
    page.getControlResultReceivedSuccess().click();
  }
);

Then(
  'I see control subject table with consignment {string} and level {string}',
  (consignment, sublevel) => {
    page.getConsignmentType().should('contain', consignment);
    page.getConsignmentSublevel().should('contain', sublevel);
  }
);

function getTableDataSlice(start: number = 0, end?: number) {
  return getTableData().slice(start, end);
}

function getTableData(i = 1) {
  return riskAnalysis.map((t) => [
    t.no,
    t.type,
    t.resultCode,
    t.riskLevel,
    t.resultDescription
  ]);
}

function convertData(data): string[][] {
  let i: number = 0;
  for (i; i < data.length; i++) {
    data[i][0] = (i + 1).toString();

    if (data[i][1] === 'F') {
      data[i][1] = 'F - Financial';
    } else if (data[i][1] === 'E') {
      data[i][1] = 'E - e-Screening air...';
    } else if (data[i][1] === 'G') {
      data[i][1] = 'G - e-Screening sec...';
    } else if (data[i][1] === 'N') {
      data[i][1] = 'N - Non-CRC (furthe...';
    } else if (data[i][1] === 'P') {
      data[i][1] = 'P - Non-customs pol...';
    } else if (data[i][1] === 'R') {
      data[i][1] = 'R - Random';
    } else if (data[i][1] === 'S') {
      data[i][1] = 'S - Security & Safe...';
    } else if (data[i][1] === 'Z') {
      data[i][1] = 'Z - No risk analysi...';
    } else if (data[i][1] === 'X') {
      data[i][1] = 'X - Air Cargo Secur...';
    }

    if (data[i][2] === 1) {
      data[i][2] = '1 - Risk confirmed';
    } else if (data[i][2] === 2) {
      data[i][2] = '2 - Risk downgraded...';
    } else if (data[i][2] === 3) {
      data[i][2] = '3 - Risk not confir...';
    } else if (data[i][2] === 4) {
      data[i][2] = '4 - No risk';
    } else if (data[i][2] === 5) {
      data[i][2] = '5 - Hit confirmed';
    } else if (data[i][2] === 6) {
      data[i][2] = '6 - Risk downgraded...';
    } else if (data[i][2] === 7) {
      data[i][2] = '7 - Risk downgraded...';
    }

    if (data[i][3] === 'R') {
      data[i][3] = 'R - High';
    } else data[i][3] = 'O - Medium';

    if (data[i][4] === '') {
      data[i][4] = '/';
    }
  }
  return data;
}
