export class HomePage {
  getBreadcrumb() {
    return cy.get('.breadcrumb li:last');
  }
  getContent(): any {
    return cy.get('app-home');
  }
  getTitle(): any {
    return cy.title();
  }
  isVisible() {
    cy.location('pathname').should('match', /\/$/);
    cy.get('app-home').should('exist');
  }
  visit() {
    cy.loginWithEO();
    cy.visit('/');
  }
}
