import { Given, When, Then } from 'cypress-cucumber-preprocessor/steps';
import { HomePage } from './home.po';

let page = new HomePage();

Given('I have navigated to the Home Page', () => {
  page.visit();
});

Then('the home page should be visible', () => {
  page.getTitle().should('eq', 'TSD Application');
  page.getContent().should('contain', 'TSD Angular UI App!!');
  page.getBreadcrumb().should('contain', 'Home');
});
