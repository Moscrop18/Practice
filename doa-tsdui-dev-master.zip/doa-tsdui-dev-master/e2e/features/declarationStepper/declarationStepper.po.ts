import { MasterConsignItemPage } from '../consignmentItems/consignmentItems.po';
export class DeclarationStepper {
  enterAllFormValues(weight, prevDocRefNum, transDocRefNum, tdType) {
    let masterConsignItemPage = new MasterConsignItemPage();
    masterConsignItemPage.inputWeight(weight);
    masterConsignItemPage.inputPreviousDocumentRefNumber(prevDocRefNum);
    masterConsignItemPage.inputTransportDocumentReferenceNumber(transDocRefNum);
    cy.get('[id="tdType"]').selectOption(tdType);
  }
  isPageVisible(text) {
    this.getBreadcrumb().should('have.text', text);
  }
  clickAddHouseConsignment() {
    cy.get('[id="addHouseConsignment"]').click();
  }
  clickDeleteHouseConsignment() {
    cy.get('[data-testid="deleteHouseConsignment"]').click();
  }
  verifyHouseConsignment(house, number) {
    cy.get('#consignment2').should('exist');
  }
  house2deleted() {
    cy.get('[id="House consignment 2"]').should('not.exist');
  }
  onHouse1Page(text) {
    cy.get('[data-testid="deleteHouseConsignment"]').should('contain', text);
  }
  deleteHouseConsignmentExist() {
    cy.get('[data-testid="deleteHouseConsignment"]').should('exist');
  }
  matchPathForMaster() {
    cy.location('pathname').should(
      'match',
      /edit-declaration\/tsd\/master-con-gen-info/
    );
  }

  matchPathForHouse() {
    cy.location('pathname').should(
      'match',
      /edit-declaration\/tsd\/house-con-gen-info/
    );
  }
  matchPathForHouseItem() {
    cy.location('pathname').should(
      'match',
      /edit-declaration\/tsd\/house-con-items/
    );
  }
  matchPathForMasterItem() {
    cy.location('pathname').should(
      'match',
      /edit-declaration\/tsd\/master-con-items/
    );
  }

  getBreadcrumb() {
    return cy.get('.breadcrumb > :nth-child(2) > :nth-child(2)');
  }
  isStepperVisible() {
    cy.get('app-vertical-stepper').should('exist');
  }
  partiesStepActivated(partiesPageHeading) {
    cy.get('[id="partyTitle"]').should('have.text', partiesPageHeading);
  }
  isOnItemPage(itemNumber) {
    cy.get('a[id^="Item"]').should('contain', itemNumber);
  }
  checkItemNumber(con, itemNumber) {
    cy.get('[id="Item ' + itemNumber + con + '"]').should(
      'contain',
      'Item ' + itemNumber
    );
  }
  checkItem(item) {
    cy.get('[id="Item' + item + '"]').should('contain', 'Item ' + item);
  }
  inEditableState() {
    //to do by developer
  }

  getErrorState() {
    return cy.get(
      '.mat-vertical-stepper-header[aria-selected=false] [data-testid="nestedStep0"]'
    );
  }

  isOnSameMasterPage() {
    cy.location('pathname').should('contain', 'master-con-items');
  }
  isOnSameHousePage() {
    cy.location('pathname').should('contain', 'house-con-items');
  }

  isOnDeclPartiesPage() {
    cy.location('pathname').should('match', /\/parties-form$/);
  }
  isOnDeclGenInfo() {
    cy.location('pathname').should('match', /\/general-info$/);
  }
  isOnItemsPage() {
    cy.get('app-order-specification-form').should('exist');
  }

  isOnGenInfoPage() {
    cy.get('app-general-info').should('exist');
  }

  isOnPartiesPage() {
    cy.get('app-edit-declaration-parties').should('exist');
  }

  hasLRNFieldError(lrnError) {
    cy.get('[id="lrnError"]').should('contain', lrnError);
  }
  hasDeclarantEORIError() {
    cy.get('[data-testid="declarantEori"] input').should(
      'have.class',
      'ngrx-forms-invalid'
    );
  }

  visitDecPartiesPage() {
    cy.visit('/edit-declaration/tsd/parties-form?tsdId=1');
  }
  visitDecgenInfopPage() {
    cy.visit(
      '/edit-declaration/tsd/general-info?tsdId=0&tsdType=combined&ensReuse=false&consignmentType=both&consignmentItemAddedTo=both'
    );
  }
  visitDecgenInfopPageWithFilledData() {
    cy.visit('edit-declaration/tsd/general-info?tsdId=1');
  }
  visitMasterConsPage() {
    cy.visit('edit-declaration/tsd/master-con-gen-info?tsdId=1&consNo=0');
  }

  clickDeleteItemButton(consignment: any, child: any) {
    cy.get('span.delete-button').click();
  }
  getMasterConsignment1() {
    return cy.get(
      'mat-vertical-stepper:not(.mat-vertical-stepper-disabled) #consignment0'
    );
  }
  getHouseConsignment1() {
    return cy.get(
      'mat-vertical-stepper:not(.mat-vertical-stepper-disabled) #consignment1'
    );
  }
  addItemforMaster() {
    return cy.get('button#add-step');
  }
  addItemforHouse() {
    return cy.get('button#add-step');
  }
  verifyMasterItemsForBoth() {
    cy.get('[id="Item11"]').should('exist');
  }
  verifyHouseItemsForBoth() {
    cy.get('[id="Item12"]').should('exist');
  }
  verifyMasterItems() {
    cy.get('[id="Item11"]').should('exist');
    cy.get('[id="Item13"]').should('not.exist');
  }
  verifyEmptyItems() {
    cy.get('[id="Item1]').should('not.exist');
  }
  verifyHouseItems() {
    cy.get('[id="Item12"]').should('exist');
    cy.get('[id="Item14"]').should('not.exist');
  }
  getGeneralInformation() {
    return cy.get('.mat-vertical-stepper-header [data-testid="nestedStep0"]');
  }
  getPartiesTab() {
    cy.get('#Item12').should('be.visible');
    return cy.get(
      '.mat-vertical-stepper-header[aria-selected=false] [data-testid="nestedStep1"]'
    );
  }
  isVisible() {
    cy.location('pathname').should('match', /\/edit-declaration$/);
    cy.get('app-general-information').should('exist');
  }
  visit() {
    cy.loginWithEO();
    cy.visit('/edit-declaration/tsd/general-info?tsdId=1');
  }
  clickDeclarationInformation() {
    cy.get('#consignment').should('contain', 'Declaration information').click();
  }
  getParties() {
    return cy.get('[data-testid="nestedStep1"]');
  }
}
