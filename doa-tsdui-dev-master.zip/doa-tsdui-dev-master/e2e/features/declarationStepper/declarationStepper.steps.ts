import { When, Then, Given } from 'cypress-cucumber-preprocessor/steps';
import { DeclarationStepper } from './declarationStepper.po';
import { EditDeclarationGeneralInfoPage } from '../generalInformation/generalInformation.po';
import { getUniqueEtag } from '../common/util';
import { should } from 'chai';
import { ConsignmentType } from '../common/customTypes';
let page = new DeclarationStepper();
let genInfoPage = new EditDeclarationGeneralInfoPage();
let responseBody = {
  statusCode: 201,
  headers: {
    location: 'http://localhost:8888/api/v1/temporaryStorageDeclarations/1'
  }
};
let responseBodyConsignment = {
  statusCode: 201,
  headers: {
    location:
      'http://localhost:8888/api/v1/temporaryStorageDeclarations/1/consignments/2'
  }
};
let responseBodyConsignmentDelete = {
  statusCode: 200,
  headers: {
    location:
      'http://localhost:8888/api/v1/temporaryStorageDeclarations/1/consignments/2'
  }
};
let responseBodyItem = {
  statusCode: 201,
  headers: {
    location:
      'http://localhost:8888/api/v1/temporaryStorageDeclarations/1/consignments/2/items/1'
  }
};
When('prepare mock for declare general information screen', () => {
  cy.intercept('POST', '/api/v1/temporaryStorageDeclarations', (req) => {
    req.reply(responseBody);
  }).as('generalInfoPost');

  cy.intercept(
    'POST',
    '/api/v1/temporaryStorageDeclarations/1/consignments',
    (req) => {
      req.reply(responseBodyConsignment);
    }
  ).as('consignmentPost');
  cy.intercept(
    'DELETE',
    '/api/v1/temporaryStorageDeclarations/1/consignments/2',
    (req) => {
      req.reply(responseBodyConsignmentDelete);
    }
  ).as('consignmentDelete');
  cy.intercept(
    'POST',
    '/api/v1/temporaryStorageDeclarations/1/consignments/2/items',
    (req) => {
      req.reply(responseBodyItem);
    }
  ).as('itemPost');
  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1', {
    fixture: 'tsd-declaration-error.json',
    headers: { etag: getUniqueEtag() }
  }).as('generalInfo');
  cy.fixture('codelist.json').then((data) => {
    cy.intercept('/assets/codelist/codelist.json', data).as('codeList');
  });
  cy.intercept('PUT', '/api/v1/temporaryStorageDeclarations/1', {
    statusCode: 200,
    headers: { etag: getUniqueEtag() }
  }).as('generalInfoPut');
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments?fields=draftErrors&pageSize=100',
    {
      fixture: 'consignment_list.json'
    }
  ).as('consignments');
  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1/consignments/0', {
    fixture: 'master-consignment-info.json',
    headers: { etag: getUniqueEtag() }
  }).as('decGeneralInfo');
  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1/consignments/1', {
    fixture: 'house-consignment-info.json'
  }).as('houseDecGeneralInfo');
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/0?fields=allowedSections',
    {
      fixture: 'master-consignment-info.json',
      headers: { etag: getUniqueEtag() }
    }
  ).as('consignment0');
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/1/items?pageSize=100',
    {
      fixture: 'goods-items.json'
    }
  ).as('consignment1Items');
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/0/items?pageSize=100',
    {
      fixture: 'goods-items.json'
    }
  ).as('consignment0Items');
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/2/items?pageSize=100',
    {
      fixture: 'goods-items.json'
    }
  ).as('consignment2Items');
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/0/items/1?fields=allowedSections',
    {
      fixture: 'master-consignment-items.json',
      headers: { etag: getUniqueEtag() }
    }
  ).as('consitem1');
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/1?fields=allowedSections',
    {
      fixture: 'house-consignment-info.json',
      headers: { etag: getUniqueEtag() }
    }
  ).as('consignment1');
  cy.fixture('house-consignment-info.json').then((data) => {
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/2?fields=allowedSections',
      {
        body: data,
        headers: { etag: getUniqueEtag() }
      }
    ).as('consignment2');
  });

  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/1/items/12?fields=allowedSections',
    {
      fixture: 'house-consignment-info.json',
      headers: { etag: getUniqueEtag() }
    }
  ).as('houseCons1Item12');
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/0/items/12?fields=allowedSections',
    {
      fixture: 'master-consignment-items.json',
      headers: { etag: getUniqueEtag() }
    }
  ).as('cons0Item12');
  cy.intercept(
    'POST',
    '/api/v1/temporaryStorageDeclarations/1/consignments/1/items',
    {
      statusCode: 201,
      headers: {
        location:
          'http://localhost:8888/api/v1/temporaryStorageDeclarations/1/consignments/1/items/12'
      }
    }
  ).as('cons1ItemPost');
  cy.intercept(
    'PUT',
    '/api/v1/temporaryStorageDeclarations/1/consignments/1/items/12',
    {
      statusCode: 200,
      headers: { etag: getUniqueEtag() }
    }
  ).as('cons1Item12Put');
  cy.intercept(
    'PUT',
    '/api/v1/temporaryStorageDeclarations/1/consignments/0/items/12',
    {
      statusCode: 200,
      headers: { etag: getUniqueEtag() }
    }
  ).as('cons0Item12Put');
  cy.intercept(
    'POST',
    '/api/v1/temporaryStorageDeclarations/1/consignments/0/items',
    {
      statusCode: 201,
      headers: {
        location:
          'http://localhost:8888/api/v1/temporaryStorageDeclarations/1/consignments/0/items/12'
      }
    }
  ).as('cons0ItemPost');
  cy.intercept('PUT', '/api/v1/temporaryStorageDeclarations/1/consignments/1', {
    statusCode: 200,
    headers: { etag: getUniqueEtag() }
  }).as('cons1Put');
  cy.intercept('PUT', '/api/v1/temporaryStorageDeclarations/1/consignments/0', {
    statusCode: 200,
    headers: { etag: getUniqueEtag() }
  }).as('cons0Put');
});

When(
  'I navigate to the declaration general information page for a declaration with consignments on {string} and items on {string}',
  (consignment, items) => {
    page.visit();

    if (consignment == 'Master') {
      page.getMasterConsignment1().click({ force: true });
      page.addItemforMaster().should('contain', 'Item').click({ force: true });
    } else if (consignment == 'House') {
      page
        .getHouseConsignment1()
        .should('contain', 'House consignment')
        .click({ force: true });

      page.addItemforHouse().should('contain', 'Item').click({ force: true });
    } else {
      if (items == 'Master') {
        page.getMasterConsignment1().click({ force: true });

        page
          .addItemforMaster()
          .should('contain', 'Item')
          .click({ force: true });
      } else if (items == 'House') {
        page
          .getHouseConsignment1()
          .should('contain', 'House consignment')
          .click({ force: true });

        page.addItemforHouse().should('contain', 'Item').click({ force: true });
      } else {
        page.getMasterConsignment1().click({ force: true });
        cy.wait('@generalInfoPut');
        cy.wait('@generalInfo');
        cy.wait('@consignments');
        cy.wait('@consignment0');
        cy.wait('@consignment0Items');
        page.addItemforMaster().click({ force: true });
        cy.wait('@cons0ItemPost');
        cy.wait(1000);
        page
          .getHouseConsignment1()
          .should('contain', 'House consignment 1')
          .click({ force: true });
        cy.wait('@generalInfo');
        cy.wait('@consignments');
        page.addItemforHouse().click({ force: true });
        cy.wait('@cons1ItemPost');
        cy.wait('@consignment1');
        cy.wait('@consignment1Items');
        cy.wait('@cons1Put');
      }
    }
  }
);

When('I enter all correct mandatory values in general information form', () => {
  let weight = '54.6';
  let prevDocRefNum = '1565565665677777T6767';
  let transDocRefNum = '1234';
  let tdType = 'C625';
  page.enterAllFormValues(weight, prevDocRefNum, transDocRefNum, tdType);
});
When('I click on add house consignment button in stepper', () => {
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments?fields=draftErrors',
    {
      fixture: 'consignment_list.json'
    }
  ).as('consignmentsWithNewData');
  page.clickAddHouseConsignment();
});

When('I click on delete House consignment 2 button in page', () => {
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments?fields=draftErrors',
    {
      fixture: 'houseList.json'
    }
  ).as('consignmentsWithDeletedData');
  page.clickDeleteHouseConsignment();
});

Then(
  'I see consignment with name House Consignment {string} in the house consignments section',
  (house) => {
    if (house == '1') {
      page.verifyHouseConsignment(house, '2');
    } else {
      page.verifyHouseConsignment(house, '3');
    }
  }
);
Then('I go to House consignment 1 page', () => {
  page.house2deleted();
});

Then('I see delete house consignment button in the page', () => {
  page.deleteHouseConsignmentExist();
});

Then('the {string} items page should be accessible', (consignment) => {
  let text = 'New declaration';
  page.isPageVisible(text);
  if (consignment === 'House') page.matchPathForHouseItem();
  else if (consignment === 'Master') page.matchPathForMasterItem();
});

Then('I see the declaration stepper', () => {
  page.isStepperVisible();
});

Then(
  'I see {string} consignment sections with items sections only available on {string}',
  (consignment, items) => {
    if (consignment == 'Master') {
      page.verifyMasterItems();
    } else if (consignment == 'House') {
      page.verifyHouseItems();
    } else {
      if (items == 'Master') {
        page.verifyMasterItems();
      } else if (items == 'House') {
        page.verifyHouseItems();
      } else {
        page.verifyMasterItems();
        cy.wait('@houseCons1Item12');
        page.verifyHouseItems();
      }
    }
  }
);

Then('I enter value of LRN', () => {
  genInfoPage.getLrn().getTextField().fill('Test');
});
When('I click on Next button', () => {
  cy.get('[id="next"]').click();
});
When('I click on {string} in the stepper for {string}', (step, parent) => {
  if (parent == 'declaration') {
    if (step == 'parties') {
      page
        .getPartiesTab()
        .should('contain', 'Parties')
        .first()
        .click({ force: true });
    } else {
      page.getGeneralInformation().eq(0).click();
    }
  }
  if (parent == 'master') {
    if (step == 'parties') {
      cy.wait('@consignments');
      cy.wait('@consignment0');
      cy.wait('@consignment0Items');
      cy.wait('@generalInfo');

      cy.wait('@cons0ItemPost');

      page
        .getPartiesTab()

        .should('contain', 'Parties')

        .click({ force: true });
      cy.wait('@generalInfo');
    } else {
      page.getGeneralInformation().eq(1).click();
    }
  }
  if (parent == 'house') {
    if (step == 'parties') {
      cy.wait('@consignments');
      cy.wait('@consignment1');
      cy.wait('@consignment1Items');
      cy.wait('@generalInfo');
      cy.wait('@cons0ItemPost');
      cy.wait('@cons1ItemPost');
      page
        .getPartiesTab()
        .should('contain', 'Parties')
        .last()
        .click({ force: true });
      cy.wait('@generalInfo');
      cy.wait('@consignment1');
    } else {
      page.getGeneralInformation().eq(2).click();
    }
  }
});

When('I have navigated to the {string} {string} page', (parent, child) => {
  cy.loginWithEO();
  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1/consignments/0', {
    fixture: 'tsd-consignment.json'
  }).as('parties');
  if (parent == 'declaration' && child == 'parties') {
    page.visitDecPartiesPage();
  } else if (parent == 'declaration' && child == 'general information') {
    page.visitDecgenInfopPage();
  } else {
    page.visitDecgenInfopPage();
    genInfoPage.getLrn().getTextField().fill('Test');
    if (parent == 'master') {
      page.getMasterConsignment1().click({ force: true });
    } else {
      page.getHouseConsignment1().click({ force: true });
    }
  }
});
When('I have navigated to the general Info page with filled Lrn', () => {
  cy.loginWithEO();
  page.visitDecgenInfopPageWithFilledData();
});
When('I have navigated to the master consignment page', () => {
  cy.loginWithEO();
  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1', {
    fixture: 'tsd-declaration-without-items.json',
    headers: { etag: getUniqueEtag() }
  }).as('generalInfo1');
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/0/items?pageSize=100',
    {
      fixture: 'goods-items-empty.json'
    }
  ).as('consignment0Items');
  page.visitMasterConsPage();
});
When('I do not see item innerstep in stepper', () => {
  cy.wait('@consignment0Items');
  page.verifyEmptyItems();
});

When(
  'I click on add item button in {string} consignments section',
  (consignment) => {
    if (consignment == 'Master') {
      page.getMasterConsignment1().click({ force: true });
      page
        .addItemforMaster()
        .should('have.class', 'mat-button-base')
        .and('contain', 'Item')
        .click({ force: true });
    } else {
      page.getHouseConsignment1().click({ force: true });
      page
        .addItemforHouse()
        .should('have.class', 'mat-button-base')
        .and('contain', 'Item')
        .click({ force: true });
    }
  }
);

When('I delete "Item 1" of the {string} consignments', (consignment, child) => {
  page.clickDeleteItemButton(consignment, child);
});

Then('An error is shown for the  Declarant EORI text field', () => {
  page.hasDeclarantEORIError();
});

Then('An error is shown for the  LRN text field', () => {
  let lrnError = 'Please enter a value';
  page.hasLRNFieldError(lrnError);
});

Then('I stay on the same {string} {string} page', (child, parent) => {
  if (parent === 'Master') {
    page.isOnSameMasterPage();
  }
  if (parent === 'House') {
    page.isOnSameHousePage();
  }
  if (parent === 'Declaration') {
    if (child === 'parties') {
      page.isOnDeclPartiesPage();
    } else {
      page.isOnDeclGenInfo();
    }
  }
  if (child === 'Items') {
    page.isOnItemsPage();
  }
  if (child === 'general information') {
    page.isOnGenInfoPage();
  }
  if (child === 'parties') {
    page.isOnPartiesPage();
  }
});

Then('I go to Item 1 page', () => {
  let itemNumber = 'Item 1';
  page.isOnItemPage(itemNumber);
});

Then(
  'I see an item with name Item {string} in the {string} consignments section',
  (itemNumber, consignment) => {
    if (consignment == 'Master') {
      page.checkItem(itemNumber);
    } else {
      page.checkItem(itemNumber);
    }
  }
);

Then('{string} consignment {string} option goes to editable state', () => {
  page.inEditableState();
});
Then('{string} consignment parties step is activated', (consignment) => {
  let partiesPageHeading = '';
  if (consignment === 'master') {
    partiesPageHeading =
      ' Step 2: Parties  Select the actors that are involved and enter their information. ';
  } else {
    partiesPageHeading =
      ' Step 3: Parties  Select the actors that are involved and enter their information. ';
  }
  page.partiesStepActivated(partiesPageHeading);
});

Then(
  '{string} consignment {string} option goes to error state',
  (parent, child) => {
    if (parent == 'master') {
      if (child == 'general information') {
        page.getErrorState().parents('div.mat-step-label-error');
      }
    } else if (parent == 'house') {
      if (child == 'general information') {
        page
          .getErrorState()

          .parents('div.mat-step-label-error');
      }
    }
  }
);

When(
  'I click on declaration parties in the stepper is disabled so no click action',
  () => {
    page.clickDeclarationInformation();
    page.getParties().should('have.css', 'pointer-events', 'none');
  }
);
