import { Given, When, Then, And } from 'cypress-cucumber-preprocessor/steps';
import { EditDeclarationGeneralInfoPage } from './generalInformation.po';
import { random, system } from 'faker';
import '../common/customTypes';
import { getUniqueEtag } from '../common/util';
import { stringify } from 'querystring';
const faker = require('faker');

const enterValue = 'Please enter a value';
const ArrivalTransportMeansIdentificationError =
  'The Arrival transport means Identification is not a valid European Vessel Identification Number. Please enter a valid Arrival transport means identification consisting of 8 digits.';
const selectValue = 'Please select a value';
const max22Characters = 'Maximum 22 characters';
const max35Characters = 'Maximum 35 characters';
const WarehouseIdRequired = 'Maximum 35 characters';
const unLoCodeMax17 = 'UNLOCODE of maximum 17 characters';
const requiredIfGoodsLocUnknown =
  ' is required in case location of goods is unknown';
let gnssLatitude, gnssLongitude;
let page = new EditDeclarationGeneralInfoPage();
let postInterceptFlag = false;

let responseBody = {
  statusCode: 201,
  headers: {
    location: 'http://localhost:8888/api/v1/temporaryStorageDeclarations/1'
  }
};

Given(
  'I have navigated to the Edit Declaration General Info page with type {} and {}',
  (declarationType, ensReuse) => {
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments?fields=draftErrors&pageSize=100',
      {
        fixture: 'houseList.json'
      }
    ).as('consignments');

    page.visit(declarationType, ensReuse);
    page.isVisible();
    page.getTitle().contains('Step 1: General information');
  }
);

When(
  'Mandatory sign is {string} for Location type and Qualifier fields',
  (display) => {
    if (display === 'displayed') {
      page.getMandateLocationType().should('be.visible');
      page
        .getLocationTypeSelectBox()
        .getDefaultOption('-')
        .should('not.have.html', '-');

      page.getMandateQualifier().should('be.visible');
      page
        .getWarehouseTypeSelectBox()
        .getDefaultOption('-')
        .should('not.have.html', '-');
    } else if (display === 'NotDisplayed') {
      page.getMandateLocationType().should('not.exist');
      page
        .getLocationTypeSelectBox()
        .getDefaultOption('-')
        .first()
        .should('contain', '-')
        .and('have.length', 1);
      page.getMandateQualifier().should('not.exist');
      page
        .getWarehouseTypeSelectBox()
        .getDefaultOption('-')
        .first()
        .should('contain', '-')
        .and('have.length', 1);
    }
  }
);

When(
  'Mandatory sign is {string} for Warehouse identifier fields',
  (display) => {
    if (display === 'displayed') {
      page.getMandateWarehouse().should('be.visible');
      page.getWarehouseTypeSelectBox().should('not.have.html', '-');
    } else if (display === 'NotDisplayed') {
      page.getMandateWarehouse().should('not.exist');
      page
        .getWarehouseTypeSelectBox()
        .click()
        .get('.mat-option-text')
        .contains('-')
        .click({ force: true });
    }
  }
);

Given(
  'I have navigated to the Edit Declaration General Info page with invalid query parameters',
  () => {
    page.visitInvalidPage();
  }
);

Then('I see the PAGE NOT FOUND screen', () => {
  page.validateURLPath();
});

When('I enter a valid LRN', () => {
  page.getLrn().getTextField().fill(random.alphaNumeric(10));
});

When('I select a valid Supervising Customs Office', () => {
  page
    .getSupervisingCustomsOfficeSelectBox()
    .clear()
    .type('BE212000 - Zaventem D');
});

When(
  'I enter Arrival Transport Means {string} and identification {string}',
  (transportMeans, identification) => {
    page
      .getArrivalTransportMeansIdentificationTypeSelectBox()
      .selectOption(transportMeans);
    page
      .getArrivalTransportMeansIdentification()
      .getTextField()
      .fill(identification);
  }
);
When('I enter gnss longitude {string}', (longitude) => {
  gnssLongitude = longitude;
  page.getGnssLongitude().getTextField().fill(longitude);
});
When('I enter gnss latitude {string}', (latitude) => {
  gnssLatitude = latitude;
  page.getGnssLatitude().getTextField().fill(latitude);
});
When('I select Warehouse type {string}', (warehouseType) => {
  page.getWarehouseTypeSelectBox().selectOption(warehouseType);
});
When('I enter Warehouse Identifier {string}', (warehouseIdentifier) => {
  page.getWarehouseIdentifier().getTextField().fill(warehouseIdentifier);
});
When('I enter Economic Operator EORI {string}', (eori) => {
  page.getEconomicOperatorEori().getTextField().fill(eori);
});
When('I enter street and number {string}', (streetAndNumber) => {
  page.getStreetAndNumber().getTextField().fill(streetAndNumber);
});
When('I enter street name {string}', (street) => {
  page.getStreet().getTextField().fill(street);
});
When('I enter street number {string}', (streetNumber) => {
  page.getStreetNumber().getTextField().fill(streetNumber);
});
When('I select country {string}', (country) => {
  page
    .getCountryAutoComplete()
    .clear()
    .type(country)
    .get('.mat-option-text')
    .contains(country)
    .click();
});
When('I enter city {string}', (city) => {
  page.getCity().getTextField().fill(city);
});
When('I enter postcode {string}', (postCode) => {
  page.getPostCode().getTextField().fill(postCode);
});
When('I enter Authorisation number {string}', (authorizationNumber) => {
  page.getAuthorizationNumber().getTextField().fill(authorizationNumber);
});
When('I click all the mandatory fields', () => {
  page.getLrn().getTextField().click();
  page.getAddressedCustomOffice().getTextField().click();
  page.getArrivalTransportMeansIdentificationTypeSelectBox().click();
  cy.escape();
  page.getArrivalTransportMeansIdentification().getTextField().click();
  page.getLocationTypeSelectBox().click();
  cy.escape();
});
When(
  'I click all the mandatory fields for address section on location of goods',
  () => {
    page.getStreetAndNumber().click();
    page.getCity().getTextField().click();
    page.getCountryAutoComplete().getTextField().click();
    page.getPostCode().getTextField().click().blur();
  }
);

function enterMaxChar(count: string) {
  return 'Please enter a value of maximum ' + count + ' characters';
}

Then('I see all required fields in error for address section', () => {
  page.getStreetAndNumber().click().should('contain', enterMaxChar('70'));
  page
    .getCountryAutoComplete()
    .getError()
    .should('contain', 'Please select a value');
  page.getCity().getError().should('contain', enterMaxChar('35'));
  page.getPostCode().getError().should('contain', enterMaxChar('17'));
});
When(
  'I enter customs office reference number {string}',
  (customOfficeRefNumber) => {
    page
      .getAdditionalCustomOfficeReferenceNumber()
      .getTextField()
      .fill(customOfficeRefNumber);
  }
);

When(
  'I select Location Type {string} with Qualifier {string}',
  (locationType, qualifier) => {
    page.getLocationTypeSelectBox().selectOption(locationType);
    page.getQualifierSelectBox().selectOption(qualifier);
  }
);
When('I select Location Type {string}', (locationType) => {
  page.getLocationTypeSelectBox().selectOption(locationType).escape();
});
Then('I see Qualifier {string}', (qualifier) => {
  page.getQualifierSelectBox().selectOption(qualifier);
});

When('I select UN Location Code {string}', (locatonCode) => {
  page.getUNLocationCodeSelectBox().clear().type(locatonCode);
});

When('I click on the {string} button', (buttonName) => {
  cy.intercept('POST', '/api/v1/temporaryStorageDeclarations', {
    statusCode: 201
  }).as('postTSD');
  page.clickNext(buttonName);
  cy.intercept('PUT', '/api/v1/temporaryStorageDeclarations/1', {
    fixture: 'tsd-declaration.json',
    headers: { etag: getUniqueEtag() }
  }).as('generalInfoNext');
});

Then('an error is shown for the LRN field', () => {
  page.getLrn().getError().should('contain', enterValue);
});

Then(
  'an error is shown for the Arrival Transport identification number field',
  () => {
    page
      .getArrivalTransportMeansIdentificationError()
      .should('contain', ArrivalTransportMeansIdentificationError);
  }
);

Then('I see all required fields in error', () => {
  page.getLrn().getError().should('contain', enterValue);
  page
    .getSupervisingCustomsOfficeSelectBox()
    .getError()
    .should('contain', selectValue);
  page
    .getArrivalTransportMeansIdentificationTypeSelectBox()
    .getError()
    .should('contain', selectValue);
  page
    .getArrivalTransportMeansIdentification()
    .getError()
    .should('contain', enterValue);
  page.getLocationTypeSelectBox().getError().should('contain', selectValue);
});

Then('I verify the helper text at different fields for Prelodged TSD', () => {
  page.getLrn().getHint().should('contain', max22Characters);
  page
    .getArrivalTransportMeansIdentification()
    .getHint()
    .should('contain', max35Characters);
  page
    .getPlaceOfUnloading()
    .getHint()
    .should('contain', unLoCodeMax17 + requiredIfGoodsLocUnknown);
  page
    .getWarehouseIdentifier()
    .getHint()
    .should('contain', WarehouseIdRequired);
});
Then('I verify the helper text at different fields for Combined TSD', () => {
  page.getLrn().getHint().should('contain', max22Characters);
  page
    .getArrivalTransportMeansIdentification()
    .getHint()
    .should('contain', max35Characters);
  page.getPlaceOfUnloading().getHint().should('contain', unLoCodeMax17);
  page
    .getWarehouseIdentifier()
    .getHint()
    .should('contain', WarehouseIdRequired);
  page
    .getDateOfDeclaration()
    .getHint()
    .should(
      'contain',
      'Only mandatory if date of declaration is different than date of presentation of goods'
    );
});
When(
  'I enter more data than allowed in each field marked with maximum characters',
  () => {
    page.getLrn().getTextField().fill(faker.random.alphaNumeric(23));
    page
      .getArrivalTransportMeansIdentification()
      .getTextField()
      .fill(faker.random.alphaNumeric(36));
  }
);
When(
  'I see that the input is trimmed upto the maximum allowed limit for that field',
  () => {
    page.getLrn().getTextField().invoke('val').should('have.length', 22);

    page
      .getArrivalTransportMeansIdentification()
      .getTextField()
      .invoke('val')
      .should('have.length', 35);
  }
);
When('I fill in the mandatory fields', () => {
  page
    .getLrn()
    .getTextField()
    .fill('test' + faker.random.alphaNumeric(15));
  page
    .getAddressedCustomOffice()
    .click()
    .get('.mat-option-text')
    .contains('BE212000 - Zaventem D')
    .click();
  page
    .getArrivalTransportMeansIdentificationTypeSelectBox()
    .selectOption('Train number');
  page.getArrivalTransportMeansIdentification().fill('ABC');
  page.getLocationTypeSelectBox().selectOption('A - Designated location');
  page.getQualifierSelectBox().selectOption('U - UNLOCODE');
  page
    .getUNLocationCodeSelectBox()
    .click()
    .get('.mat-option-text')
    .contains('BEZAVA00710 - Bpost Brucargo')
    .click();
  page
    .getSupervisingCustomsOfficeSelectBox()
    .clear()
    .type('BE212000 - Zaventem D');
  page.getAddressedCustomOffice().clear().type('BE212000 - Zaventem D');
  page
    .getArrivalTransportMeansIdentificationTypeSelectBox()
    .selectOption('20 - Wagon number');
  page.getArrivalTransportMeansIdentification().fill('123');
  page.getLocationTypeSelectBox().selectOption('A - Designated location');
  page.getQualifierSelectBox().selectOption('U - UNLOCODE');
  page
    .getUNLocationCodeSelectBox()
    .clear()
    .type('BEZAVA00710 - Bpost Brucargo');
});

And('I fill in the declaration date and time', () => {
  let declarationDate;
  page
    .getDateOfPresentation()
    .getTextField()
    .invoke('val')
    .then((val) => {
      declarationDate =
        ('0' + (new Date(val).getMonth() + 1)).slice(-2) +
        '/' +
        ('0' + new Date(val).getDate()).slice(-2) +
        '/' +
        new Date(val).getFullYear();

      page.getDateOfDeclaration().getTextField().type(declarationDate);
    });

  page
    .getTimeOfPresentation()
    .getTextField()
    .invoke('val')
    .then((declarationTime) => {
      debugger;

      page.getTimeOfDeclarationValue().type(declarationTime);
    });
});

When('I click on Save', () => {
  cy.intercept('POST', '/api/v1/temporaryStorageDeclarations', {
    statusCode: 201
  }).as('postTSD');
  page.getSaveBtn().click();
});
And('I move to {string} page', (pageName) => {
  page.getTitle().should('contain', pageName);
});
When('I see unsaved changes dialog', () => {
  page.cancel().should('be.visible');
});
When('I click on cancel without saving', () => {
  page.getCloseButton().click();
});
When('I click on save changes', () => {
  cy.intercept('POST', '/api/v1/temporaryStorageDeclarations', {
    statusCode: 201
  }).as('postTSD');

  page.getCreateNewButton().click();
});

When('I click on save changes without lrn', () => {
  page.getCreateNewButton().click();
});
Then('I navigate to home screen', () => {
  page.isHomeScreen();
});
When('I click on Cancel', () => {
  page.getCancelButton().click();
});
When('I fill in location type without providing lrn', () => {
  page.getLocationTypeSelectBox().selectOption('A - Designated location');
});
Then('I see message dialog as lrn is not provided', () => {
  cy.get('[data-testid=errorTitle]').should('contain', 'Unable to save');
});
Then('no errors are shown', () => {
  page.validateNoErrors();
  cy.intercept('PUT', '/api/v1/temporaryStorageDeclarations/1', {
    fixture: 'tsd-declaration.json',
    headers: { etag: getUniqueEtag() }
  }).as('generalInfoNext');
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments?fields=draftErrors&pageSize=100',
    {
      fixture: 'houseList.json'
    }
  ).as('consignments');
});

When('I fill in LRN field', () => {
  page.getLrn().getTextField().fill('abc');
});
And('I see values in fields are retained', () => {
  page.getLrn().should('not.be.empty');
  page.getDateOfDeclaration().should('not.be.empty');
  page.getTimeOfDeclaration().should('not.be.empty');
  page.getDateOfPresentation().should('not.be.empty');
  page.getTimeOfPresentation().should('not.be.empty');
  page.getSupervisingCustomsOfficeSelectBox().should('not.be.empty');
  page.getAddressedCustomOffice().should('not.be.empty');
});
When(
  'I fill in the mandatory fields for {} and Reuse {}',
  (declarationType, reuse) => {
    page
      .getLrn()
      .getTextField()
      .fill('test' + faker.random.alphaNumeric(15));
    page
      .getAddressedCustomOffice()
      .click()
      .get('.mat-option-text')
      .contains('BE212000 - Zaventem D')
      .click();
    page
      .getArrivalTransportMeansIdentificationTypeSelectBox()
      .selectOption('Train number');
    page.getArrivalTransportMeansIdentification().fill('ABC');
    page.getLocationTypeSelectBox().selectOption('A - Designated location');
    page.getQualifierSelectBox().selectOption('U - UNLOCODE');
    page
      .getUNLocationCodeSelectBox()
      .click()
      .get('.mat-option-text')
      .contains('BEZAVA00710 - Bpost Brucargo')
      .click();
    page
      .getSupervisingCustomsOfficeSelectBox()
      .clear()
      .type('BE212000 - Zaventem D');
    page.getAddressedCustomOffice().clear().type('BE212000 - Zaventem D');
    page
      .getArrivalTransportMeansIdentificationTypeSelectBox()
      .selectOption('20 - Wagon number');
    page.getArrivalTransportMeansIdentification().fill('123');
    page.getLocationTypeSelectBox().selectOption('A - Designated location');
    page.getQualifierSelectBox().selectOption('U - UNLOCODE');
    page
      .getUNLocationCodeSelectBox()
      .clear()
      .type('BEZAVA00710 - Bpost Brucargo');
  }
);
And('all data is saved correctly', () => {
  page.getSavedBtn().should('be.disabled');
});
When('I leave place of unloading and location type empty', () => {
  page.getLocationTypeSelectBox().click();
  cy.escape();
  page.getPlaceOfUnloading().click();
  cy.escape();
  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1', {
    fixture: 'tsd-declaration-put.json',
    headers: { etag: getUniqueEtag() }
  }).as('generalInfo');
});
And('I select Place of unloading', () => {
  page
    .getPlaceOfUnloading()
    .type('BEZAVA00710')
    .get('.mat-option-text')
    .contains('BEZAVA00710 - Bpost Brucargo')
    .click();
});
And('error is displayed for Location type fields', () => {
  page
    .getLocationTypeSelectBox()
    .getError()
    .should('contain', 'Please select a value');
});
And('No error is displayed for Location type fields', () => {
  page.getLocationTypeSelectBox().getError().should('not.exist');
});

Then('gnss logitude and latitude should be same as entered', () => {
  page.getGnssLatitude().getTextField().should('contain.value', gnssLatitude);
  page.getGnssLongitude().getTextField().should('contain.value', gnssLongitude);
});
And('city field is not visible', () => {
  page.getCity().should('not.exist');
});

And(
  'I see optional field Location Type has {string} as first value',
  (defaultOption) => {
    page
      .getLocationTypeSelectBox()
      .getDefaultOption(defaultOption)
      .first()
      .should('contain', defaultOption)
      .and('have.length', 1);
  }
);

And('I do not see Location Type has {string} as value', (defaultOption) => {
  page
    .getLocationTypeSelectBox()
    .getDefaultOption(defaultOption)
    .should('not.have.html', defaultOption);
});

And(
  'I do not see {string} as first value in warehouse type field',
  (defaultOption) => {
    page
      .getWarehouseTypeSelectBox()
      .getDefaultOption(defaultOption)
      .should('not.have.html', defaultOption);
  }
);
