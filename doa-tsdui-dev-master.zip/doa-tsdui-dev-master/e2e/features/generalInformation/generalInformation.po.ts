export class EditDeclarationGeneralInfoPage {
  invalidPath = '/page-not-found';
  isVisible() {
    cy.location('pathname').should(
      'contain',
      '/edit-declaration/tsd/general-info'
    );
  }
  getTitle(): Cypress.Chainable<any> {
    return cy.get('.mat-title');
  }

  visit(tsdTypeFlag: string, ensReuseFlag: string) {
    cy.loginWithEO();
    cy.visit('/edit-declaration/tsd/general-info', {
      qs: {
        tsdId: 0,
        tsdType: tsdTypeFlag,
        ensReuse: ensReuseFlag,
        consignmentType: 'both',
        consignmentItemAddedTo: 'both'
      }
    });
  }
  visitInvalidPage() {
    cy.loginWithEO();
    cy.visit('/edit-declaration/tsd/general-info', {
      qs: {
        tsdId: 0,
        tsdType: 'prelodged',
        ensReuse: 'false',
        consignmentType: 'both',
        consignmentItemAddedTo: 'bothInvalid'
      }
    });
  }

  getLrn(): Cypress.Chainable<any> {
    return cy.get('#lrn');
  }

  getArrivalTransportMeansIdentificationError(): Cypress.Chainable<any> {
    return cy.get('#mat-error-2');
  }

  getSupervisingCustomsOfficeSelectBox(): Cypress.Chainable<any> {
    return cy.get('#supervisingCustomFormField');
  }

  getArrivalTransportMeansIdentificationTypeSelectBox(): Cypress.Chainable<any> {
    return cy.get('#transportType');
  }

  getArrivalTransportMeansIdentification(): Cypress.Chainable<any> {
    return cy.get('#transportIdentification');
  }

  getQualifierSelectBox(): Cypress.Chainable<any> {
    return cy.get('#qualifierSelect');
  }

  getLocationTypeSelectBox(): Cypress.Chainable<any> {
    return cy.get('#locationType');
  }
  getAddressedCustomOffice(): Cypress.Chainable<any> {
    return cy.get('#supervisingCustomFormField');
  }

  getStreet(): Cypress.Chainable<any> {
    return cy.get('[data-testid=streetField]');
  }

  getStreetAndNumber(): Cypress.Chainable<any> {
    return cy.get('[data-testid=streetAndNumberField]');
  }

  getStreetNumber(): Cypress.Chainable<any> {
    return cy.get('[data-testid=numberField]');
  }

  getCity(): Cypress.Chainable<any> {
    return cy.get('[data-testid=cityField]');
  }

  getCountryAutoComplete(): Cypress.Chainable<any> {
    return cy.get('[data-testid=countryField]');
  }

  getPostCode(): Cypress.Chainable<any> {
    return cy.get('[data-testid=postCodeField]');
  }

  getAuthorizationNumber(): Cypress.Chainable<any> {
    return cy.get('#authorisationNumber');
  }

  getSaveBtn() {
    return cy.get('#save');
  }
  getSavedBtn() {
    return cy.get('#saved');
  }
  cancel() {
    return cy.get('[data-testid="errorPopup"]');
  }
  getCloseButton() {
    return cy.get('[data-testid="errorCloseBtn"]');
  }
  getCreateNewButton() {
    return cy.get('[data-testid=CreateNewBtn]');
  }
  isHomeScreen() {
    cy.get('.home > span').should('contain', 'Welcome to TSD Angular UI App!!');
  }
  getCancelButton() {
    return cy.get('#cancel');
  }
  validateNoErrors() {
    cy.get('mat-error').should('not.exist');
  }

  getUNLocationCodeSelectBox(): Cypress.Chainable<any> {
    return cy.get('#unLocodeField');
  }
  getWarehouseTypeSelectBox(): Cypress.Chainable<any> {
    return cy.get('#warehouseTypeSelect');
  }
  getMandateLocationType(): Cypress.Chainable<any> {
    return cy.get("#locationType span[class^='mandatory']");
  }
  getMandateQualifier(): Cypress.Chainable<any> {
    return cy.get("#qualifierSelect span[class^='mandatory']");
  }
  getMandateWarehouse(): Cypress.Chainable<any> {
    return cy.get("#warehouseIdentifier span[class^='mandatory']");
  }
  getAdditionalCustomOfficeReferenceNumber(): Cypress.Chainable<any> {
    return cy.get('#customsOfficeReferenceNumberField');
  }
  getGnssLongitude(): Cypress.Chainable<any> {
    return cy.get('#longitudeField');
  }
  getGnssLatitude(): Cypress.Chainable<any> {
    return cy.get('#latitudeField');
  }
  getWarehouseIdentifier(): Cypress.Chainable<any> {
    return cy.get('#warehouseIdentifier');
  }
  getEconomicOperatorEori(): Cypress.Chainable<any> {
    return cy.get('#EORINumberField');
  }

  getPlaceOfUnloading(): Cypress.Chainable<any> {
    return cy.get('#placeOfUnloading');
  }
  getDateOfPresentation() {
    return cy.get('[data-testid="dateOfPresentation"]');
  }
  getTimeOfPresentation() {
    return cy.get('[data-testid="timeOfPresentation"]');
  }

  getDateOfDeclaration(): Cypress.Chainable<any> {
    return cy.get('[data-testid=dateOfDeclarationInput]');
  }
  getTimeOfDeclaration(): Cypress.Chainable<any> {
    return cy.get('[data-testid=declarationTimeInput]');
  }

  getTimeOfDeclarationValue(): Cypress.Chainable<any> {
    return cy.get('[data-testid=declarationTimeInputValue]');
  }

  clickNext(buttonName: string) {
    cy.get('button').contains(buttonName, { matchCase: false }).click();
  }
  validateURLPath() {
    cy.url().should('include', this.invalidPath);
  }
}
