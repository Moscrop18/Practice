import { ConsultGeneralInformation } from '@features/manage-declaration/models/consult-general-information/consult-general-info';
import { And, Given, Then, When } from 'cypress-cucumber-preprocessor/steps';
import '../common/accessibility.steps';
import '../common/customTypes';
import { getUniqueEtag } from '../common/util';
import { StandardNavigationDrawer } from './standard-navigation-drawer.po';

let drawerData: ConsultGeneralInformation;
let apiPath = '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4';
const pagePath = '/advanced-search/search-results/20BETP000000C3FLU4';
const pageHeader = 'General information';
let mockAmendSuccess = 'tsd-amend-success.json';
let mockGenInfo = 'gen-info-mock.json';
let consignmentAPI =
  'api/v1/temporaryStorageDeclarations/1/consignments?fields=draftErrors&pageSize=100';
let mockConsInfo = 'houseList.json';
let page = new StandardNavigationDrawer();

let mockMap = {
  Deconsolidation: 'gen-info-mock-deconsolidation',
  Accepted: 'standard-drawer-accepted.json',
  Prelodged: 'standard-drawer-prelodged.json',
  Irregularity: 'standard-drawer-irregularity.json'
};

function setupMock(method, api, status) {
  if (status === 'Pre-lodged') {
    cy.fixture(mockMap.Prelodged).then((data) => {
      drawerData = data;
      return cy
        .intercept(method, api, { fixture: mockMap.Prelodged })
        .as('stdDrawer');
    });
  } else if (status === 'Irregularity under investigation') {
    cy.fixture(mockMap.Irregularity).then((data) => {
      drawerData = data;
      return cy
        .intercept(method, api, {
          fixture: mockMap.Irregularity
        })
        .as('stdDrawer');
    });
  } else if (status === 'Accepted') {
    cy.fixture(mockMap.Accepted).then((data) => {
      drawerData = data;
      return cy
        .intercept(method, api, { fixture: mockMap.Accepted })
        .as('stdDrawer');
    });
  } else if (status === 'Deconsolidation') {
    cy.fixture(mockMap.Deconsolidation).then((data) => {
      drawerData = data;
      return cy
        .intercept(method, api, { fixture: mockMap.Deconsolidation })
        .as('stdDrawer');
    });
  }
  cy.intercept('/assets/codelist/codelist.json', {
    fixture: 'codelist.json'
  }).as('codeList');
}
Given('Prepare mock data for standard navigation drawer', () => {
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4',
    {
      fixture: mockGenInfo,
      headers: { etag: getUniqueEtag() }
    }
  ).as('genInfo');
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/CRN21BETS00000000QIU0',
    {
      fixture: mockGenInfo,
      headers: { etag: getUniqueEtag() }
    }
  ).as('genInfo1');
  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1', {
    fixture: mockGenInfo,
    headers: { etag: getUniqueEtag() }
  }).as('genInfo1');
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/CRN21BETS00000000QIU0',
    {
      fixture: mockGenInfo,
      headers: { etag: getUniqueEtag() }
    }
  ).as('genInfo2');
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments?fields=draftErrors&pageSize=100',
    {
      fixture: 'house-overview-mock.json'
    }
  );
  setupMock('GET', apiPath, 'Accepted');
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments?pageSize=10',
    {
      fixture: mockGenInfo,
      headers: { etag: getUniqueEtag() }
    }
  ).as('ConsInfo');
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments?pageSize=10&type=House',
    {
      fixture: mockGenInfo,
      headers: { etag: getUniqueEtag() }
    }
  ).as('ConsInfoWithQuery');
  cy.intercept(
    'POST',
    'api/v1/temporaryStorageDeclarations/CRN21BETS00000000QIU0/amend',
    {
      statusCode: 201,
      headers: {
        location:
          'http://localhost:8888/api/v1/temporaryStorageDeclarations/1/amend/1'
      },
      fixture: mockAmendSuccess
    }
  ).as('amendSuccess');
  cy.intercept('GET', consignmentAPI, { fixture: mockConsInfo }).as(
    'consInfo1'
  );
});

Given('I have navigated to consult declaration page', () => {
  page.visitStandardDrawer(pagePath);
  setupMock('GET', apiPath, 'Accepted');
  page.isVisible().should('be.visible');
});

Then('I see general information page', () => {
  setupMock('GET', apiPath, 'Accepted');

  page.getPath().should('include', '/search-results');
  page.getPageHeader().should('contain', pageHeader);
});

And(
  'the current status is displayed with colored icon on the navigation drawer',
  () => {
    page.getStatus().should('contain', drawerData.status);
    page.getStatusColor().should('have.class', 'green');
  }
);

And('the navigation drawer contains Reference Number', () => {
  page.getRefernceNumber().should('contain', drawerData.mrn);
});

And('all sections are displayed on the navigation drawer', () => {
  let sectionArray = [
    'Declaration Information',
    'Presentation Notification',
    'Consignment Information',
    'Risk and control information',
    'History'
  ];
  page.getSectionsOnDrawer().each((section, i) => {
    expect(section).to.contain(sectionArray[i]);
  });
});

Given(
  'I Prepare mock data for standard navigation drawer with status {}',
  (status) => {
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/CRN21BETS00000000QIU0',
      {
        fixture: mockGenInfo,
        statusCode: 200,
        headers: { etag: getUniqueEtag() }
      }
    ).as('genInfocurrent');
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments?fields=draftErrors',
      {
        fixture: 'house-overview-mock.json'
      }
    );
    setupMock('GET', apiPath, status);
  }
);
And('I have navigated to consult declaration page for {}', (status) => {
  setupMock('GET', apiPath, status);
  page.visitStandardDrawer(pagePath);
  cy.wait('@stdDrawer');
  page.isVisible().should('be.visible');
});
When('I click on actions icon for status {} at navigation drawer', (Status) => {
  page.getStatus();
  page.getMenuButton().click();
});

Then('I see actions {} corresponding to status', (Actions) => {
  let action: any[] = Actions.split(',');
  page.getMenuItems().each((ele, i) => {
    expect(ele).contain(action[i].trim());
  });
});

And('I see {string} colored icon for status {}', (color, status) => {
  page.getStatus().should('contain', status);
  page.getStatusColor().should('have.class', color);
});

And('I click on menu item {} for status {}', (item, status) => {
  page.getSingleMenuItem(item).click({ force: true });

  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/CRN21BETS00000000QIU0',
    {
      fixture: mockGenInfo,
      statusCode: 200,
      headers: { etag: getUniqueEtag() }
    }
  ).as('genInfocurrent');
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments?fields=draftErrors&pageSize=100',
    {
      fixture: 'house-overview-mock.json'
    }
  ).as('consignments');
  if (item == 'Request for amendment') {
    cy.wait('@amendSuccess');
    cy.wait('@genInfocurrent');
    cy.wait('@consignments');
    cy.wait('@genInfo1');
  }
});

And('I do not see menu item {} for status {}', (item, status) => {
  if (item == 'Request for amendment') {
    page.getSingleMenuItem(item).should('not.exist');
  }
});

Then('I see page is displayed for the {} item', (item) => {
  console.log('ToDo: ' + item + 'Not yet integrated');
});

Given('I have navigated to general information page', () => {
  page.visitStandardDrawer(pagePath);
});

When('I click on {string} tab', (tabName) => {
  if (tabName === 'History') {
    cy.intercept('GET', apiPath + '/versions', {
      fixture: 'tsd-consult-event-history.json'
    }).as('historyPage');
  } else if (tabName === 'Consignment Information') {
    cy.intercept('GET', apiPath + '/consignments?fields=draftErrors', {
      fixture: 'tsd-consignment.json'
    });
    cy.intercept('GET', apiPath + '/consignments?pageSize=10', {
      fixture: 'tsd-consignment.json'
    });
    cy.intercept('GET', apiPath + '/consignments?pageSize=10&type=House', {
      fixture: mockGenInfo,
      headers: { etag: getUniqueEtag() }
    }).as('ConsInfoWithQuery');
    cy.intercept('GET', apiPath + '/consignments/0', {
      fixture: 'tsd-consignment.json'
    });
    cy.intercept('GET', apiPath + '/consignments/0/items', {
      fixture: 'goods-items.json'
    });
    cy.intercept('GET', apiPath + '/consignments/1', {
      fixture: 'tsd-consignment.json'
    });
    cy.intercept('GET', apiPath + '/consignments/0/items', {
      fixture: 'goods-items.json'
    });
    cy.intercept('GET', apiPath + '/consignments?fields=draftErrors', {
      fixture: 'house-consignment.json'
    });
    cy.intercept('GET', apiPath + '/consignments?pageSize=10', {
      fixture: 'house-consignment.json'
    });
    cy.intercept('GET', apiPath + '/consignments?pageSize=10&type=House', {
      fixture: mockGenInfo,
      headers: { etag: getUniqueEtag() }
    }).as('ConsInfoWithQuery');
  }

  page.getTab(tabName).click();
});

And('I click on {string} sub-tab under {string} section', (subTab, tabName) => {
  if (tabName === 'Consignment Information') {
    cy.intercept('GET', apiPath + '/consignments?fields=draftErrors', {
      fixture: 'house-consignment.json'
    });
    cy.intercept('GET', apiPath + '/consignments/0', {
      fixture: 'tsd-consignment.json'
    });
    cy.intercept('GET', apiPath + '/consignments/0/items', {
      fixture: 'goods-items.json'
    });
    cy.intercept('GET', apiPath + '/consignments/1', {
      fixture: 'tsd-consignment.json'
    });
    cy.intercept('GET', apiPath + '/consignments/0/items', {
      fixture: 'goods-items.json'
    });
  }

  page.getSubTab(subTab, tabName).click({ force: true });
});

Then(
  'I see {string} sub-tab selected under {string} and {string} page is displayed',
  (subTab, tabName, pageName) => {
    page
      .getSubTab(subTab, tabName)
      .parentsUntil('mat-focus-indicator')
      .should('have.class', 'mat-focus-indicator');
    page.getPageTitle().should('have.text', pageName);
  }
);

And(
  'I can navigate back to {string} sub-tab under {string} section',
  (subTab, tabName) => {
    page
      .getSubTab(subTab, tabName)
      .click({ force: true })
      .parents()
      .should('have.class', 'mat-focus-indicator');
  }
);

And('I see {string} page', (pageName) => {
  page.getPageTitle().should('have.text', pageName);
});

Then('I see {string} page is displayed', (pageName) => {
  if (pageName === 'Status') {
    cy.intercept('GET', apiPath + '/statusHistory', {
      fixture: 'consult-tsd-status-history.json'
    });
    page.getPath().should('include', 'status');
  } else if (page) {
    page.getPath().should('include', 'history');
  }
  page.getPageTitle().should('have.text', pageName);
});

When('I click on status displayed at navigation drawer', () => {
  cy.intercept('GET', apiPath + '/statusHistory', {
    fixture: 'consult-tsd-status-history.json'
  });
  page.getStatus().click();
});
