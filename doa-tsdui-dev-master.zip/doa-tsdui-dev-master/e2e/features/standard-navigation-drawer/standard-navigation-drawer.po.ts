export class StandardNavigationDrawer {
  visitStandardDrawer(url) {
    cy.loginWithEO();

    cy.visit(url);
  }
  isVisible() {
    return cy.get('[data-testid="referenceNumber"]');
  }

  getPath() {
    return cy.location('pathname');
  }

  getPageHeader() {
    return cy.get('[data-testid="genInfoTitle"]');
  }

  getStatus() {
    return cy.get('div.status');
  }

  getStatusColor() {
    return cy.get('[data-testid="statusColor"]');
  }

  getRefernceNumber() {
    return cy.get('[data-testid="referenceNumber"]');
  }

  getSectionsOnDrawer() {
    return cy
      .get('[role="navigation"]')
      .find('.mat-expansion-panel-header-description');
  }

  getMenuButton() {
    return cy.get('[data-testid="menuButton"]');
  }

  getMenuItems() {
    return cy.get('button[role=menuitem]');
  }

  getSingleMenuItem(item) {
    let itemLocator = {
      'Request for amendment': '[data-testid="reqForAmend"]',
      'Re-use data to create new declaration': '[data-testid="reuseData"]',
      'Export to PDF': '[data-testid="exportToPdf"]',
      'Request for invalidation': '[data-testid="reqForInv"]'
    };
    return cy.get(itemLocator[item]);
  }
  getTab(tab) {
    if (tab === 'Declaration Information') {
      return this.getTabDeclarationInfo();
    } else if (tab === 'Presentation Notification') {
      return this.getTabPresentationNotification();
    } else if (tab === 'Consignment Information') {
      return this.getTabConsignmentInfo();
    } else {
      return cy.get('[data-testid="historyDesc"]');
    }
  }
  getTabDeclarationInfo() {
    return cy.get('[data-testid="decInfoDesc"]');
  }

  getTabPresentationNotification() {
    return cy.get('[data-testid="presNotDesc"]');
  }

  getTabConsignmentInfo() {
    return cy.get('[data-testid="consInfoDesc"]');
  }
  getSubTab(subTab, tabName) {
    if (
      tabName === 'Declaration Information' &&
      subTab === 'General information'
    ) {
      return cy.get('[data-testid="decGenInfo"]');
    } else if (tabName === 'Declaration Information' && subTab === 'Parties') {
      return cy.get('[data-testid="decParties"]');
    } else if (
      tabName === 'Presentation Notification' &&
      subTab === 'General information'
    ) {
      return cy.get('[data-testid="pnGenInfo"]');
    } else if (
      tabName === 'Presentation Notification' &&
      subTab === 'Parties'
    ) {
      return cy.get('[data-testid="pnParties"]');
    } else if (
      tabName === 'Consignment Information' &&
      subTab === 'Master Consignment'
    ) {
      return cy.get('[data-testid="masterCons"]');
    } else if (
      (tabName === 'Consignment Information' &&
        subTab === 'House Consignment(s)') ||
      'House consignment(s)'
    ) {
      return cy.get('[data-testid="houseCons"]');
    }
  }

  getPageTitle() {
    return cy.get('title');
  }
}
