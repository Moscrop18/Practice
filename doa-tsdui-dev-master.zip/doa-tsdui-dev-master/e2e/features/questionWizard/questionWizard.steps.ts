import { Given, When, Then } from 'cypress-cucumber-preprocessor/steps';
import { QuestionWizardPage } from './questionWizard.po';
import {
  ConsignmentType,
  DeclarationType,
  EnsReuse
} from '../common/customTypes';

let page = new QuestionWizardPage();

Given('I have navigated to the Question Wizard page', () => {
  page.visit();
});

When('I click the New Declaration menu', () => {
  page.clickNewDeclarationMenu();
});

Then('the Question Wizard page is displayed', () => {
  page.isVisible();
  page.getInfoHeader().should('have.contain', 'Get started...');
  page.getBreadcrumb().should('have.text', 'New declaration');
});

When('I select temporary storage declaration type {string}', (type) => {
  page.selectDeclarationTypeRadioButton(type);
});
When('I select Re-use consignment details from ENS {string}', (ens) => {
  page.selectENSReuseRadioButton(ens);
});

When('I select type of ENS consignment data {string}', (consignment) => {
  page.selectTypeOfENSConsignmentDataRadioButton(consignment);
});

When('I select type of consignment data {string}', (consignment) => {
  page.selectTypeOfConsignmentDataRadioButton(consignment);
});

When('I do not see {string} consignment item option listed', (consignment) => {
  page.getConsignmentItem(consignment).should('not.exist');
});

When('I select consignment items added to {string}', (consignment) => {
  page.selectConsignmentItemsAddedToRadioButton(consignment);
});

When('I click start declaration', () => {
  page.clickStartDeclarationButton();
});

Then('The edit declaration wizard is started', () => {
  page.getDeclarationGeneralInfoPage().isVisible();
});

let chooseOption = 'Please choose one option';

Then('An error is shown for the type and ENS sections', () => {
  page.hasDeclarationTypeError(chooseOption);
  page.hasENSReuseError(chooseOption);
});

Then('An error is shown for the type of consignment section', () => {
  page.hasConsignmentError(chooseOption);
});

Then('An error is shown for the type of ens consignment section', () => {
  page.hasENSConsignmentError(chooseOption);
});

Then('An error is shown for the consignment item section', () => {
  page.hasConsignmentItemError(chooseOption);
});

Then('I stay on the same Question Wizard page', () => {
  page.isVisible();
});

Then('I see error messages for dynamic radio buttons', () => {
  console.log('I see error messages for dynamic radio buttons');
  // Write code here that turns the phrase above into concrete actions
  return 'pending';
});
