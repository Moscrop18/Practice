import { EditDeclarationGeneralInfoPage } from '../generalInformation/generalInformation.po';

export class QuestionWizardPage {
  isVisible() {
    cy.location('pathname').should('match', /\/edit-declaration$/);
    cy.get('app-edit-declaration-wizard').should('exist');
  }

  visit() {
    cy.loginWithEO();
    cy.visit('/edit-declaration');
  }

  clickNewDeclarationMenu() {
    cy.get('#menuId1').click();
  }

  getInfoHeader() {
    return cy.get('.getStarted');
  }

  getBreadcrumb() {
    return cy.get('.breadcrumb > :nth-child(2) > :nth-child(2)');
  }

  selectDeclarationTypeRadioButton(value: string) {
    cy.get('[data-testid=question-type] mat-radio-button[value=' + value + ']')
      .click()
      .should('have.class', 'mat-radio-checked');
  }

  selectENSReuseRadioButton(value: string) {
    cy.get('[data-testid=question-ensreuse-' + value + ']')
      .click()
      .should('have.class', 'mat-radio-checked');
  }

  selectTypeOfENSConsignmentDataRadioButton(consignment: string) {
    cy.get(
      '[data-testid=question-ens-consignment] mat-radio-button[value=' +
        consignment +
        ']'
    )
      .click()
      .should('have.class', 'mat-radio-checked');
  }
  selectTypeOfConsignmentDataRadioButton(consignment: string) {
    cy.get(
      '[data-testid=question-consignment] mat-radio-button[value=' +
        consignment +
        ']'
    )
      .click()
      .should('have.class', 'mat-radio-checked');
  }

  getConsignmentItem(consignment: string) {
    return cy.get(
      '[data-testid=question-consignment-items] mat-radio-button[value=' +
        consignment +
        ']'
    );
  }
  selectConsignmentItemsAddedToRadioButton(consignment: string) {
    cy.get(
      '[data-testid=question-consignment-items] mat-radio-button[value=' +
        consignment +
        ']'
    )
      .click()
      .should('have.class', 'mat-radio-checked');
  }

  clickStartDeclarationButton() {
    cy.get('#submitButton').click();
  }
  getDeclarationGeneralInfoPage() {
    return new EditDeclarationGeneralInfoPage();
  }

  hasDeclarationTypeError(message: string) {
    cy.get('#declarationTypeError').should('contain', message);
  }

  hasENSReuseError(message: string) {
    cy.get('[data-testid=question-ensreuse-error]').should('contain', message);
  }

  hasConsignmentItemError(message: string) {
    cy.get('[data-testid=question-consignment-items-error]').should(
      'contain',
      message
    );
  }
  hasConsignmentError(message: string) {
    cy.get('[data-testid=question-consignment-error]').should(
      'contain',
      message
    );
  }
  hasENSConsignmentError(message: string) {
    cy.get('[data-testid=question-ens-consignment-error]').should(
      'contain',
      message
    );
  }
}
