import { defineParameterType } from 'cypress-cucumber-preprocessor/steps';

// this is for illustration, maybe not needed
export enum DeclarationType {
  combined,
  prelodged
}
defineParameterType({
  name: 'declarationType',
  regexp: new RegExp(Object.keys(DeclarationType).join('|')),
  transformer: (s) => DeclarationType[s]
});

export enum EnsReuse {
  reuse = 'ens reuse',
  noReuse = 'no ens reuse'
}
export enum ConsignmentType {
  house,
  master,
  both
}

defineParameterType({
  name: 'ensReuse',
  regexp: new RegExp(
    Object.keys(EnsReuse)
      .map((key) => EnsReuse[key])
      .join('|')
  ),
  transformer: (s) => {
    return Object.keys(EnsReuse).find((key) => EnsReuse[key] === s);
  }
});

defineParameterType({
  name: 'consignmentType',
  regexp: new RegExp(Object.keys(DeclarationType).join('|')),
  transformer: (s) => DeclarationType[s]
});
