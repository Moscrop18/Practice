import { Then } from 'cypress-cucumber-preprocessor/steps';

// Print cypress-axe violations to the terminal
export function consoleReporter(violations) {
  const violationData: Record<string, any> = {};
  violations.forEach(({ label, id, description, nodes, tags }, idx) => {
    violationData[`${id}`] = {
      label,
      description,
      tags: tags.join(','),
      nodes: nodes.map((n) => n.target[0]).join(', ')
    };
  });

  cy.task('table', violationData);
  console.table(violationData);
}

// disable aria-required-children as long as axe 4.3 is not released
// https://github.com/dequelabs/axe-core/issues/2505
// TODO enabled when axe is fixed

Then('the page should be accessible', () => {
  cy.injectAxe();
  cy.checkA11y(
    null,
    {
      runOnly: {
        type: 'tag',
        values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa']
      },
      rules: { 'aria-required-children': { enabled: false } }
    },
    consoleReporter
  );
});
