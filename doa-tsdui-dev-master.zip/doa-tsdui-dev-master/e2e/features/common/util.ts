/// <reference types="cypress" />
import { format } from 'date-fns';
import { enUS } from 'date-fns/locale';

export function getCodeAndLabel(codelist: any[], code: string): string {
  const cList = codelist.filter((a) => a.value === code);
  if (cList[0].definition) {
    return cList[0].value + ' - ' + cList[0].definition;
  } else {
    return cList[0].label;
  }
}
export function getUniqueEtag(): string {
  return '_' + Math.random().toString(36).substr(2, 9);
}

export function columnSort(
  a: any,
  b: any,
  stringSort: boolean,
  reverse: boolean
) {
  let result = 0;
  if (stringSort) {
    if (a < b) {
      result = -1;
    }
    if (a > b) {
      result = 1;
    }
  } else if (reverse) {
    if (a > b) {
      result = -1;
    }
    if (a < b) {
      result = 1;
    }
  } else {
    result = b - a;
  }
  return reverse ? -1 * result : result;
}

export function convertDate(date: string, pattern: string) {
  return format(new Date(date), pattern, { locale: enUS });
}
