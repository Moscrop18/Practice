import { Given, When, And, Then } from 'cypress-cucumber-preprocessor/steps';
import { ConsultTSDAmend } from './consult-tsd-amendment.po';
import '../common/customTypes';
import '../common/accessibility.steps';
import { ConsultGeneralInformation } from '@features/manage-declaration/models/consult-general-information/consult-general-info';
import { ConsultEventHistory } from '../../features/consult-tsd-event-history/consult-tsd-event-history.po';
import { getUniqueEtag } from '../common/util';
import { MasterConsignItemPage } from '../consignmentItems/consignmentItems.po';

let ConsignItemPage = new MasterConsignItemPage();
let page = new ConsultTSDAmend();
let evntHistory: ConsultEventHistory;
//let eventHistoryPage = new ConsultEventHistory().
let consultScreenURI = '/advanced-search/search-results/20BETP000000C3FLU4';
let amendAPI = 'api/v1/temporaryStorageDeclarations/1/amend';
let generalInfoAPI = 'api/v1/temporaryStorageDeclarations/1';
let consignmentAPI =
  'api/v1/temporaryStorageDeclarations/1/consignments?fields=draftErrors&pageSize=100';
let mockSuccess = 'tsd-amend-success.json';
let mockGenInfo = 'amend-info-mock.json';
let mockConsInfo = 'houseList.json';
let mockDeconsolidation = 'gen-info-mock-deconsolidation';
let genInfoTitle = ' General information ';
let headerSubText = 'Please add, remove, or update the data you wish to amend.';

let mockData: ConsultGeneralInformation;

Given('I have navigated to consult TSD page', () => {
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4',
    {
      fixture: mockGenInfo,
      headers: { etag: getUniqueEtag() }
    }
  ).as('genInfo');
  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1', {
    fixture: mockGenInfo,
    headers: { etag: getUniqueEtag() }
  }).as('generalInfo');
  cy.intercept('PUT', '/api/v1/temporaryStorageDeclarations/1', {
    fixture: mockGenInfo,
    headers: { etag: getUniqueEtag() }
  }).as('generalInfoConsultPut');

  cy.intercept('GET', consignmentAPI, { fixture: mockConsInfo }).as('consInfo');

  cy.intercept(
    'PUT',
    '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4',
    {
      statusCode: 200,
      headers: { etag: getUniqueEtag() }
    }
  ).as('generalInfoPut');
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/0?fields=allowedSections',
    {
      fixture: 'master-consignment-info.json',
      headers: { etag: getUniqueEtag() }
    }
  ).as('masterConsignmentAllwdSec');

  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1/consignments/0', {
    fixture: 'master-consignment-info.json',
    headers: { etag: getUniqueEtag() }
  }).as('masterConsignment');

  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/2/items?pageSize=100',
    {
      fixture: 'goods-items2.json'
    }
  ).as('consignment2Items');

  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/0/items',
    {
      fixture: 'goods-items2.json'
    }
  ).as('consignment0Items');

  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/2?fields=allowedSections',
    {
      fixture: 'house-consignment-info.json',
      headers: { etag: getUniqueEtag() }
    }
  ).as('consignment2');

  cy.intercept('PUT', '/api/v1/temporaryStorageDeclarations/1/consignments/2', {
    statusCode: 200,
    headers: { etag: getUniqueEtag() }
  }).as('consignmentPut');

  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/2/items/2?fields=allowedSections',
    {
      fixture: 'master-consignment-items.json',
      headers: { etag: getUniqueEtag() }
    }
  ).as('cons2Item2');
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/2/items/1?fields=allowedSections',
    {
      fixture: 'master-consignment-items.json',
      headers: { etag: getUniqueEtag() }
    }
  ).as('cons2Item1');
  cy.intercept(
    'PUT',
    '/api/v1/temporaryStorageDeclarations/1/consignments/2/items/2',
    {
      statusCode: 200,
      headers: { etag: getUniqueEtag() }
    }
  ).as('consItemPut');
  cy.intercept(
    'PUT',
    '/api/v1/temporaryStorageDeclarations/1/consignments/2/items/1',
    {
      statusCode: 200,
      headers: { etag: getUniqueEtag() }
    }
  ).as('consItemPut1');

  cy.fixture(mockGenInfo).then((data) => {
    mockData = data;
  });

  page.visitConsultTSDPage(consultScreenURI);
  page.getGeneralInfoTitle().should('contain', genInfoTitle.trim());
  page.isVisible().should('be.visible');
});

Given('I have configured amendment request mock for success', () => {
  cy.intercept('POST', amendAPI, {
    fixture: mockSuccess,
    headers: {
      location:
        'http://localhost:8888/api/v1/temporaryStorageDeclarations/1/amend/1'
    }
  }).as('amendSuccess');
  cy.intercept(
    'POST',
    'api/v1/temporaryStorageDeclarations/CRN21BETS00000000QIU0/amend',
    {
      fixture: mockSuccess,
      headers: {
        location:
          'http://localhost:8888/api/v1/temporaryStorageDeclarations/1/amend/1'
      }
    }
  ).as('amendSuccess');
  cy.intercept('POST', '/api/v1/temporaryStorageDeclarations/1/validate', {
    statusCode: 200
  }).as('validate');
  cy.intercept('POST', '/api/v1/temporaryStorageDeclarations/1/submit', {
    statusCode: 200
  }).as('submit');
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/versions',
    { fixture: 'tsd-consult-historyApproved.json' }
  ).as('eventHistoryApproved');
  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/2313453/versions', {
    fixture: 'tsd-consult-historyApproved.json'
  }).as('eventHistoryApproved1');
});

When('I click on {string} button in action menu', (itemOption) => {
  if (itemOption === 'Request for amendment') {
    cy.wait('@genInfo').then(() => {
      page.getActionButton().click();
      page
        .getItemRequestAmendment()
        .should('contain', 'Request for amendment')
        .click();
    });
  } else {
    page.getActionButton().click();
    page
      .getItemRequestAmendmentContinue()
      .should('contain', 'Continue request for amendment draft')
      .click();
  }
});

Then('I got navigated to {string} page', (pageTitle) => {
  page.getGeneralInfoHeader().should('contain', pageTitle);
});

And('I can see header {string} on the page', (pageHeader) => {
  page.getAmendPageHeader().should('contain', pageHeader);
});

And('I see sub-text under Request for Amendment header', () => {
  page.getHeaderSubText().should('contain.text', headerSubText);
});

Given(
  'I have configured amendment request mock for amendment request already exist',
  () => {
    cy.intercept('POST', amendAPI, { fixture: mockSuccess }).as('amendSuccess');
  }
);

When('I click on action menu', () => {
  page.getActionButton().click();
});

Then('I see {string} option', (actionItem) => {
  page.getItemRequestAmendmentContinue().should('contain.text', actionItem);
});

Given(
  'I have configured amendment request mock for failure for too big declaration',
  () => {
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4',
      {
        fixture: 'gen-info-mock-requestAmend.json',
        headers: { etag: getUniqueEtag() }
      }
    ).as('genInfoMRN');
    cy.intercept(
      'POST',
      '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/amend',
      {
        fixture: 'tsd-declaration_RequestFail_tooBig.json',
        statusCode: 401
      }
    ).as('amendReqFail');
    cy.intercept(
      'POST',
      '/api/v1/temporaryStorageDeclarations/CRN21BETS00000000QIU0/amend',
      {
        fixture: 'tsd-declaration_RequestFail_tooBig.json',
        statusCode: 401
      }
    ).as('amendReqFail');
  }
);

Given(
  'I have configured amendment request mock for failure for amendment status changed',
  () => {
    cy.intercept('POST', '/api/v1/temporaryStorageDeclarations/1/validate', {
      fixture: 'tsd-declaration_StatusChanged.json',
      statusCode: 400,
      failOnStatusCode: false
    }).as('validate');
  }
);

Given(
  'I have configured deconsolidation request mock for failure for deconsolidation status changed',
  () => {
    cy.fixture('gen-info-mock-deconsolidation').then((data) => {
      const updatedDeclaration = {
        ...data,
        _links: {
          draftAmendment:
            'http://localhost:8888/api/v1/temporaryStorageDeclarations/1'
        }
      };
      cy.intercept(
        'GET',
        '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4',
        {
          body: updatedDeclaration,
          headers: { etag: getUniqueEtag() }
        }
      ).as('declaration');
    });

    page.visitConsultTSDPage(consultScreenURI);
    page.getGeneralInfoTitle().should('contain', genInfoTitle.trim());
    page.isVisible().should('be.visible');
  }
);

When('I click on Save', () => {
  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1', {
    statusCode: 400,
    fixture: 'amendError.json'
  }).as('amendError');
  page.getSaveBtn().click();
});

And('I modified LRN value', () => {
  page.getLRN().type('12');
  page.getPresentationDate().should('be.disabled');
});

And('I see TSD details are pre populated', () => {
  page.getLRN().should('not.be.disabled').and('not.be.empty');
  page.getPresentationDate().should('be.disabled');
});

And('I navigate to last item of consignment', () => {
  cy.visit('edit-declaration/tsd/house-con-items?tsdId=1&consNo=2&itemNo=2');
  cy.wait('@consInfo');
  cy.wait('@consignment2');
  cy.wait('@cons2Item2');
  cy.wait('@consignment2Items');
});
And('I navigate to second last item of consignment', () => {
  cy.visit('edit-declaration/tsd/house-con-items?tsdId=1&consNo=2&itemNo=1');
});
And('I click next', () => {
  cy.get('#next').click();
});

And('I submit TSD', () => {
  page
    .getSubmitButton()
    .scrollIntoView()
    .should('contain.text', 'Submit')
    .click();
});

And('I submit TSD with error', () => {
  page
    .getSubmitButton()
    .scrollIntoView()
    .should('contain.text', 'Submit')
    .click();
});

And('I see progress indicator', () => {
  page.getProgressIndicator().should('be.visible');
});

And('I see Overview screen with pre-populated details', () => {
  let sections = [
    'Declaration information',
    'Master consignment',
    'House consignment1',
    'House consignment2',
    'House consignment3'
  ];

  cy.wait('@consItemPut');
  cy.wait('@validate');

  page
    .getOverviewPageTitle()
    .should('contain.text', 'Review and confirm request for submission');
  page.getSectionsOnOverview().each(($el, index) => {
    expect($el).to.contain(sections[index]);
  });
  page
    .getTSDType()
    .should('contain.text', mockData.type + ' Temporary storage declaration');
  page.getOverviewLrn().should('contain', mockData.lrn);
  page
    .getDeclarantEORI()
    .should('contain', mockData.declarant.identificationNumber);
  page.getDeclarantName().should('contain', mockData.declarant.name);
  page
    .getRepresentativeStatus()
    .should('contain', mockData.representative.status);
  page
    .getRepresentativeEori()
    .should('contain', mockData.representative.identificationNumber);
  page.getRepresentativeName().should('contain', mockData.representative.name);
});

And(
  'I see Overview screen with pre-populated details for amendment request',
  () => {
    let sections = [
      'Declaration information',
      'Master consignment',
      'House consignment1',
      'House consignment2',
      'House consignment3'
    ];

    cy.wait('@consItemPut');
    cy.wait('@validate');
    page
      .getOverviewPageTitle()
      .should('contain.text', 'Review and confirm request for amendment');
    page.getSectionsOnOverview().each(($el, index) => {
      expect($el).to.contain(sections[index]);
    });
    page
      .getTSDType()
      .should('contain.text', mockData.type + ' Temporary storage declaration');
    page.getOverviewLrn().should('contain', mockData.lrn);
    page
      .getDeclarantEORI()
      .should('contain', mockData.declarant.identificationNumber);
    page.getDeclarantName().should('contain', mockData.declarant.name);
    page
      .getRepresentativeStatus()
      .should('contain', mockData.representative.status);
    page
      .getRepresentativeEori()
      .should('contain', mockData.representative.identificationNumber);
    page
      .getRepresentativeName()
      .should('contain', mockData.representative.name);
  }
);

And('confirm the submission', () => {
  page.getConfirmBtn().should('contain.text', 'Confirm').click();
});

And('cancel the submission', () => {
  page.getCancelBtn().should('contain.text', 'Cancel').click();
});

And('the status of request is {string}', (status) => {
  page.getRequestStatus().should('contain.text', status);
});

And('I can close banner with Dismiss button', () => {
  page.getDismissBtn().should('contain.text', 'Dismiss').click();

  page.getDismissBtn().should('not.exist');
});

And('I got navigated to previous page with Submit button', () => {
  page
    .getURL()
    .should('contain', 'edit-declaration/tsd/house-con-items?tsdId=1');
  cy.wait('@cons2Item2');
  page.getSubmitButton().should('be.visible');
});

Then('I see error popup with message {string}', (errorMsg) => {
  page.getPopupTitle().should('contain.text', 'Status change');
  page.getErrorMessage().should('contain.text', errorMsg);
});

And('I see Discard and New buttons', () => {
  page.getStatusChangeDiscardBtn().should('contain.text', 'Discard');
  page.getStatusChangeCreateBtn().should('contain.text', 'Create new');
});

And('I see Edit Declaration page after clicking on Create new button', () => {
  page.getStatusChangeCreateBtn().click();
  page.getURL().should('match', /\/edit-declaration/);
});

Given(
  'I have configured amendment request mock for refused amendment request',
  () => {
    cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1', {
      fixture: 'gen-info-mock-amend-PreLodged.json',
      headers: { etag: getUniqueEtag() }
    }).as('generalInfoPrelodged');
    cy.intercept('POST', '/api/v1/temporaryStorageDeclarations/1/validate', {
      statusCode: 200
    }).as('validate');

    cy.intercept('POST', '/api/v1/temporaryStorageDeclarations/1/submit', {
      fixture: 'tsd-declaration_SubmitFailedBanner.json',
      statusCode: 400,
      failOnStatusCode: false
    }).as('submitError');
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/versions',
      {
        fixture: 'tsd-consult-historyRefused.json'
      }
    ).as('eventHistoryRefused');
    cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1/versions', {
      fixture: 'tsd-consult-historyRefused.json'
    }).as('eventHistoryRefused1');
  }
);

And(
  'I have navigated to consult declaration page with too big declaration',
  () => {
    page.visitConsultTSDPage(consultScreenURI);
  }
);

Then(
  'I see popup with title {string} and message {string}',
  (errorHeading, errorMsg) => {
    page.getPopupTitle().should('contain', errorHeading);
    page.getErrorMessage().should('contain', errorMsg);
  }
);

And('I see general info page on clicking Ok', () => {
  page.getOkBtn().should('contain.text', 'ok').click();
  page
    .getURL()
    .should('match', /advanced-search\/search-results\/20BETP000000C3FLU4/);
  page.getGeneralInfoTitle().should('contain', genInfoTitle.trim());
});

And('I got navigated to History page with {string} banner', (bannerStatus) => {
  if (bannerStatus === 'success') {
    cy.wait('@eventHistoryApproved');
  } else {
    cy.wait('@submitError');
    cy.wait('@eventHistoryRefused');
  }
  page.getURL().should('match', /\/history/);
  page.getBanner(bannerStatus).should('be.visible');
  cy.wait('@genInfo');
});

And(
  'I see a row is added in History table with status {string}',
  (requestStatus) => {
    let refusedActions = ['View request', 'View error', 'Export'];
    let acceptedActions = ['View request', 'Export'];
    if (requestStatus === 'Refused') {
      page
        .getActionsButton('Amendment', requestStatus, 'true')
        .click()
        .get('.mat-menu-item')
        .each((item, index) => {
          cy.wrap(item).should('contain', refusedActions[index]);
        });
    } else {
      page
        .getActionsButton('Amendment', requestStatus, 'true')
        .click()
        .get('.mat-menu-item')
        .each((item, index) => {
          cy.wrap(item).should('contain', acceptedActions[index]);
        });
    }
  }
);

When(
  'I click on {string} button in action menu outdated amendment',
  (itemOption) => {
    cy.fixture('houseList.json').then((data1) => {
      cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1', {
        statusCode: 400,
        fixture: 'amendError.json'
      }).as('amendError');
      cy.intercept(
        'GET',
        '/api/v1/temporaryStorageDeclarations/1/consignments?fields=draftErrors',
        data1
      );
    });
    if (itemOption === 'Request for amendment') {
      cy.wait('@genInfo').then(() => {
        page.getActionButton().click();
        page
          .getItemRequestAmendment()
          .should('contain', 'Request for amendment')
          .click();
      });
    } else {
      page.getActionButton().click();
      page
        .getItemRequestAmendmentContinue()
        .should('contain', 'Continue request for amendment draft')
        .click();
    }
  }
);

Then('I can see the error popup {string}', (errorMsg) => {
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments?fields=draftErrors&pageSize=100',
    {
      statusCode: 200,
      fixture: 'tsd-drafts.json'
    }
  ).as('getdraftList1');
  if (
    errorMsg ===
    'A more recent version of the corresponding declaration is available'
  ) {
    cy.get('[data-testid="errorPopup"]').should('contain', errorMsg);
  } else {
    cy.get('[data-testid="errorPopup"]').should('contain', errorMsg);
  }
});

When('Click on ok button', () => {
  ConsignItemPage.getCloseButton().click();
});

When('I see the TSD consult page', () => {
  page.isVisible();
});

Then('I see add communication button is disabled', () => {
  page.getAddCommunicationButton().should('be.disabled');
});
