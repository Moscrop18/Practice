import { find } from 'cypress/types/lodash';

export class ConsultTSDAmend {
  visitConsultTSDPage(url) {
    cy.loginWithEO();
    cy.visit(url, { timeout: 7000 });
  }
  getSaveBtn() {
    return cy.get('#save');
  }

  isVisible() {
    return cy.get('[data-testid="referenceNumber"]');
  }

  getGeneralInfoTitle() {
    return cy.get('[data-testid="genInfoTitle"]');
  }

  getGeneralInfoHeader() {
    return cy.get('.mat-title');
  }
  getActionButton() {
    return cy.get('[data-testid="menuButton"]');
  }

  getActionsButton(
    category,
    requestStatus,
    currentVersion: any = 'true'
  ): Cypress.Chainable<any> {
    return cy
      .get('tr:contains(' + category + '):contains(' + requestStatus + ')')
      .first()
      .find('app-event-action');
  }
  getItemRequestAmendment() {
    return cy.get('[data-testid="reqForAmend"]').first();
  }

  getItemRequestAmendmentContinue() {
    return cy.get('.mat-menu-item').first();
  }
  getAmendPageHeader() {
    return cy.get('[data-testid="amendment-title"]');
  }

  getHeaderSubText() {
    return cy.get('[data-testid="amendment-hint"]');
  }
  getLRN() {
    return cy.get('#lrn');
  }

  getPresentationDate() {
    return cy.get('[data-testid="dateOfPresentationInput"]');
  }

  getBanner(bannerStatus) {
    return cy.get('div.' + bannerStatus);
  }

  setupMock(httpMethod, api, fixture) {
    cy.intercept(httpMethod, api, fixture);
  }

  getMasterConsignment() {
    return cy.get('#consignment0');
  }

  getHouseConsignment() {
    return cy.get('a[id^="consignment"]');
  }

  getItem() {
    return cy.get('[id^="Item"]');
  }
  getSubmitButton() {
    return cy.get('#submit');
  }

  getOverviewPageTitle() {
    return cy.get('.overview-heading');
  }

  getSectionsOnOverview() {
    return cy.get('.overview-body').within(() => {
      return cy.get('.overview-sub-heading');
      //cy.get('.darker');
    });
  }

  getTSDType() {
    return cy.get('.type-heading');
  }
  getOverviewLrn() {
    return cy.get('[data-testid="lrn"]');
  }
  getDeclarantEORI() {
    return cy.get('[data-testid="declarantEori"]');
  }

  getDeclarantName() {
    return cy.get('[data-testid="name"]');
  }
  getRepresentativeStatus(): any {
    return cy.get('[data-testid=representativeStatus]');
  }
  getRepresentativeEori(): any {
    return cy.get('[data-testid=representativeEori]');
  }
  getRepresentativeName(): any {
    return cy.get('[data-testid=representativeName]');
  }

  getConfirmBtn() {
    return cy.get('[data-testid="errorCloseBtn"]');
  }

  getCancelBtn() {
    return cy.get('[data-testid="cancelBtn"]');
  }

  getProgressIndicator() {
    return cy.get('.mat-progress-bar');
  }
  getDismissBtn() {
    return cy.get('div.back-button');
  }

  getRequestStatus() {
    return cy.get('.status');
  }

  getPopupTitle() {
    return cy.get('[data-testid="errorTitle"]');
  }

  getErrorMessage() {
    return cy.get('[data-testid="errorMessage"]');
  }

  getStatusChangeDiscardBtn() {
    return cy.get('[data-testid="errorCloseBtn"]');
  }

  getStatusChangeCreateBtn() {
    return cy.get('[data-testid="CreateNewBtn"]');
  }

  getURL() {
    return cy.location('href');
  }

  getOkBtn() {
    return cy.get('[data-testid="errorCloseBtn"]');
  }

  getAddCommunicationButton() {
    return cy.get('[data-testid="addComm"]');
  }
}
