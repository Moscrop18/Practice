import { Given, When, And, Then } from 'cypress-cucumber-preprocessor/steps';
import { ConsultStatusHistory } from './consult-tsd-status-history.po';
import '../common/customTypes';
import '../common/accessibility.steps';
import { StatusHistory } from '@features/manage-declaration/models/status/status-history';
import { StandardNavigationDrawer } from '../standard-navigation-drawer/standard-navigation-drawer.po';

let page = new ConsultStatusHistory();
let statusData: StatusHistory;
let statusPageTitle = ' Status ';
let NavDrawer = new StandardNavigationDrawer();

let toolTipText = {
  UnderControl: 'Declaration selected for control, control result pending.',
  IrregularityUnderInvestigation: 'Customs officer investigation required',
  Accepted:
    'Temporary storage declaration after presentation of non-union goods entering the union.',
  PreLodged:
    'Temporary storage declaration before presentation of non-union goods entering the union.'
};

Given('Prepare status history test mock data', () => {
  cy.fixture('consult-tsd-status-history.json').then((history) => {
    statusData = history;
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/statusHistory',
      history
    ).as('statusHistory');
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4',
      {
        fixture: 'tsd-declaration-status.json'
      }
    ).as('declaration');
  });
});
const urlPath = '/advanced-search/search-results/20BETP000000C3FLU4/status';
And('I am on status history page', () => {
  page.visitHistoryPage(urlPath);
});

When('I search with valid MRN or CRN', () => {
  page.inputSearchOption().click().type(statusData.mrn);
});

And('I click on status link on stepper', () => {
  page.getStatusOnStepper().click();
});

Then('I see Status History page', () => {
  page.getStatusPageTitle().should('contain', statusPageTitle);
  page.getStatusHistoryURL().should('include', urlPath);
});

And('current status is displayed with icon', () => {
  page
    .getStatusText()
    .should(
      'contain',
      statusData.history[0].status === 'UnderControl'
        ? ''
        : statusData.history[0].status
    );
  page.getStatusIcon().should('have.class', 'orange');
  page.getCurrentStatusIcon();
});

And('I see check icon inside current status icon', () => {
  page.getCurrentStatusIcon();
});

And('statuses are displayed in descending chronological order', () => {
  page.getCountOfStatus().should('have.length', statusData.history.length);
  page.getStatusData().each((element, index) => {
    if (statusData.history[index].status !== 'PreLodged')
      expect(element).to.contain(
        statusData.history[index].status === 'UnderControl'
          ? 'Under control'
          : statusData.history[index].status ===
            'IrregularityUnderInvestigation'
          ? 'Irregularity under investigation'
          : statusData.history[index].status
      );
    else expect(element).to.contain('Pre-lodged');
  });
});

And('I see time is displayed', () => {
  page
    .getStatusDate()
    .should('exist')
    .and('have.length', statusData.history.length);

  page
    .getStatusTime()
    .should('exist')
    .and('have.length', statusData.history.length);
});

And('the space between 2 status is 60 px', () => {
  //ToDo implement cypress-visual-regression => using baseline images once UI developed
  page.getStatusDividerWidth().should('be.equal', 60);
});

Then('I see the status description for each status reason', () => {
  statusData.history.forEach((element) => {
    page.getStatusReason().should('contain', element.reason);
  });
});

Then('tool tip is displayed on hover', () => {
  statusData.history.forEach((element) => {
    page
      .getToolTipText(element.status)
      .should('have.attr', 'aria-label', toolTipText[element.status]);
  });
});

When('I am on {string} page', (lan) => {
  cy.contains(lan).click();
});
When(
  'I can see Headers {string},{string},{string},{string} when Language {string}',
  (home, NewDeclaration, SavedDraft, AdvancedSearch) => {
    page.getHomeHeader().contains(home, { matchCase: false });
    page
      .getNewNotificationHeader()
      .contains(NewDeclaration, { matchCase: false });
    page.getSavedDraftHeader().contains(SavedDraft, { matchCase: false });
    page
      .getAdvancedSearchHeader()
      .contains(AdvancedSearch, { matchCase: false });
  }
);
When(
  'I can see Navigation Drawer {string},{string},{string},{string} when Language {string}',
  (
    DeclarationInformation,
    PresentationNotification,
    Consignmentinformation,
    HISTORY
  ) => {
    NavDrawer.getTab('Declaration Information').contains(
      DeclarationInformation
    );
    NavDrawer.getTab('Presentation Notification').contains(
      PresentationNotification
    );
    NavDrawer.getTab('Consignment Information').contains(
      Consignmentinformation
    );
    NavDrawer.getTab('History').contains(HISTORY);
  }
);
