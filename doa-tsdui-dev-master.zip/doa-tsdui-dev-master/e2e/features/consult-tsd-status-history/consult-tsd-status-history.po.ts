export class ConsultStatusHistory {
  visitHistoryPage(url) {
    cy.loginWithEO();
    cy.visit(url);
  }

  getStatusPageTitle() {
    return cy.get('[data-testid="statusTitle"]');
  }

  inputSearchOption() {
    return cy.get('[data-testid="miniSearch"]');
  }

  getStatusOnStepper() {
    return cy.get('.status');
  }

  getStatusHistoryURL() {
    return cy.url();
  }

  getStatusText() {
    return cy.get('[data-testid^="status-"]');
  }

  getStatusReason() {
    return cy.get('[data-testid^="statusReason-"]');
  }

  getStatusIcon() {
    return cy.get('[data-testid="node-0"]');
  }

  getCurrentStatusIcon() {
    return cy
      .get('div.firstnode')
      .invoke('css', 'before', 'url("Icon - Done - Two-toned.svg")');
  }

  getCountOfStatus() {
    return cy.get('[data-testid^="status-"]');
  }
  getStatusData() {
    return cy.get('#progress [data-testid^="status-"]');
  }
  getStatusDate() {
    return cy.get('[data-testid^="statusDate-"]');
  }

  getStatusTime() {
    return cy.get('[data-testid^="statusTime-"]');
  }

  getStatusDividerWidth() {
    return cy.get('div.divider').invoke('height');
  }

  hoverOnInfoIcon() {
    cy.get('.info-icon').each((ele) => {
      ele.trigger('mousemove', { force: true });
    });
  }

  getToolTip() {
    return cy.get('.info-icon');
  }

  getToolTipText(status) {
    if (status === 'PreLodged')
      return this.getStatusText().contains('Pre-lodged').find('.info-icon');
    else if (status === 'UnderControl')
      return this.getStatusText().contains('Under control').find('.info-icon');
    else if (status === 'IrregularityUnderInvestigation')
      return this.getStatusText()
        .contains('Irregularity under investigation')
        .find('.info-icon');
    else return this.getStatusText().contains(status).find('.info-icon');
  }

  getHomeHeader() {
    return cy.get('#menuId0');
  }
  getNewNotificationHeader() {
    return cy.get('#menuId1');
  }

  getSavedDraftHeader() {
    return cy.get('#menuId2');
  }
  getAdvancedSearchHeader() {
    return cy.get('#menuId3');
  }
}
