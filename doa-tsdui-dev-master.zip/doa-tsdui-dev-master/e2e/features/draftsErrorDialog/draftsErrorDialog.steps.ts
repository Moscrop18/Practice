///<reference types = "Cypress"/>
import { And, Given, Then, When } from 'cypress-cucumber-preprocessor/steps';
import { DraftsError } from './draftsErrorDialog.po';

let page = new DraftsError();
let lrn = 'LrnVALIDDraftErrors001';
let draftErrorAPI = 'api/v1/temporaryStorageDeclarations/1';
let draftAPI = '/api/v1/temporaryStorageDeclarations';
let mockDeclarantInfo =
  '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4';
let mockDecGenInfo = 'standard-drawer-prelodged.json';
let mockDeletedDraftTSD = 'draft-error-deletedDraftTSD.json';

Given('I have navigated to the create declaration general info page', () => {
  cy.intercept('GET', mockDeclarantInfo, mockDecGenInfo).as('decGenInfo');
  page.visitdeclarationGeneralInfo();
});

And('filled all mandatory fields', () => {
  page.getLRNField().click().type(lrn);
});

Given('I have configured save mock for updated response', () => {
  cy.intercept('POST', draftAPI, {
    statusCode: 412,
    body: {}
  }).as('deleteResponse');
});

Given('I have configured save mock for deleted response', () => {
  cy.intercept('POST', draftAPI, {
    statusCode: 404,
    body: {}
  }).as('deleteResponse');
});

When('I click on next button', () => {
  page.getNextButton().click();
  cy.intercept('POST', draftAPI, mockDeletedDraftTSD);
});

Then('I see dialog box stating that {string}', (errorMsg) => {
  if (errorMsg === 'The draft that you are working on, is outdated') {
    page.getErrorPopUp().should('contain', errorMsg);
  } else {
    cy.wait('@deleteResponse');
    page.getErrorPopUp().should('contain', errorMsg);
  }
});

Then('I see new declaration question wizard page', () => {
  page.getNewEditDeclaration().should('exist');
});

When('I click on new button', () => {
  page.getNewBtn().click();
});

Given(
  'I have navigated to the create declaration general info page with invalid query parameters',
  () => {
    cy.intercept('GET', mockDeclarantInfo, mockDecGenInfo).as('decGenInfo');
    page.visitInvalidParameters();
  }
);

Then('I see the PAGE NOT FOUND screen', () => {
  page.validateURLPath();
});
