export class DraftsError {
  invalidPath = '/page-not-found';
  visitdeclarationGeneralInfo() {
    cy.loginWithEO();
    cy.visit(
      'edit-declaration/tsd/general-info?tsdId=0&tsdType=prelodged&ensReuse=true&consignmentType=master'
    );
  }

  getLRNField() {
    return cy.get('#lrn');
  }

  getNextButton() {
    return cy.get('#next');
  }
  getErrorPopUp() {
    return cy.get('[data-testid="errorSubTitle"]');
  }

  getNewEditDeclaration() {
    cy.location('pathname').should('match', /\/edit-declaration$/);
    return cy.get('app-edit-declaration-wizard');
  }

  getNewBtn() {
    return cy.get('[data-testid="errorNewBtn"]');
  }

  visitInvalidParameters() {
    cy.loginWithEO();
    cy.visit(
      'edit-declaration/tsd/general-info?tsdId=0&tsdType=prelodged&ensReuse=true&consignmentType=masterInvalid'
    );
  }
  validateURLPath() {
    cy.url().should('include', this.invalidPath);
  }
}
