///<refernce types = "Cypress"/>

export class MasterConsignItemPage {
  newDeclarationPath = '/edit-declaration/tsd/master-con-items';
  masterConsignmentItemPath = '/tsd/master-con-items';
  tsdTypeFlag = '';
  consignorTypeOfPerson = '';
  consigneeTypeOfPerson = '';

  setQueryParams(
    tsdTypeFlag: 'prelodged' | 'combined',
    consignorTypeOfPerson: string,
    consigneeTypeOfPerson: string
  ) {
    this.tsdTypeFlag = tsdTypeFlag;
    this.consignorTypeOfPerson = consignorTypeOfPerson;
    this.consigneeTypeOfPerson = consigneeTypeOfPerson;
  }

  visit() {
    cy.loginWithEO();
    cy.visit('/edit-declaration' + this.masterConsignmentItemPath, {
      qs: {
        tsdId: 1,
        consNo: 0,
        itemNo: 1
      }
    });
  }
  visit1() {
    cy.loginWithEO();
    cy.visit('/edit-declaration' + this.masterConsignmentItemPath, {
      qs: {
        tsdId: 1,
        consNo: 0,
        itemNo: 'invalid'
      }
    });
  }
  invalidateURLPath() {
    cy.url().should('include', '/page-not-found');
  }

  getURL() {
    return cy.url();
  }

  getMasterConsignmentTab() {
    return cy.get('[id^="Master"]');
  }
  validateURLPath() {
    cy.url().should('include', this.masterConsignmentItemPath);
  }

  getAppTitle() {
    return cy
      .get('div.app-title-full')
      .contains('Temporary storage declaration');
  }

  getPageHeaderTitle() {
    return cy.get('#title');
  }
  getPageHeaderTitleHint() {
    return cy.get('p#titleHint');
  }

  selectPreviousDocumentCheckBox() {
    cy.get('#pdCheck input#pdCheck-input').click();
  }

  addItemTransportEquipment() {
    cy.get('mat-icon#containerAddButton').click();
  }

  addItemSupportingDocCheckBox() {
    cy.get('mat-icon#sdAddButton').click();
  }

  addItemAdditionalInfoCheckBox() {
    cy.get('button#addButton').click();
  }

  addItemAdditionalRefCheckBox() {
    cy.get('button#addAdditionalRef').click();
  }

  addItemAdditionalSupplyChainCheckBox() {
    cy.get('button#addSuppButton').click();
  }
  addPackaging() {
    cy.get('#packAdd').click();
  }
  getSection(section) {
    if (section === 'Transport Equipment') {
      return cy.get('[data-testid=transEquipContainer]');
    } else if (section === 'Supporting Document') {
      return cy.get('[data-testid="supportingDocumentItem"]');
    } else if (section === 'Additional Information') {
      return cy.get('[data-testid="additionalInformationItem"]');
    } else if (section === 'Additional Reference') {
      return cy.get('[id^="additionaReferencePanelTitle"]');
    } else if (section === 'Additional Supply Chain Actor') {
      return cy.get('[data-testid="supplyChainActorPanel"]');
    } else if (section === 'Packaging') {
      return cy.get('[data-testid="packagingContainer"]');
    }
  }
  validateItemsAdded(section) {
    this.getSection(section).should('have.length', 2);
  }

  getSectionHeader(item, section) {
    const seq = item.charAt(item.length - 1);
    if (section === 'Transport Equipment') {
      return cy.get(
        '[data-testid="transEquipContainer"]#mat-expansion-panel-header-' + seq
      );
    } else if (section === 'Supporting Document') {
      return cy.get(
        '[test-id="supportingDocumentItem"]#mat-expansion-panel-header-' + seq
      );
    } else if (section === 'Additional Information') {
      return cy.get(
        '[test-id="additionalInformationItem"]#mat-expansion-panel-header-' +
          seq
      );
    } else if (section === 'Additional Reference') {
      return cy.get(
        '[test-id="additionalRefItem"]#mat-expansion-panel-header-' + seq
      );
    } else if (section === 'Additional Supply Chain Actor') {
      return cy.get(
        '[data-testid="supplyChainActorPanel"]#mat-expansion-panel-header-' +
          seq
      );
    } else if (section === 'Packaging') {
      return cy.get(
        '[data-testid="packagingContainer"]#mat-expansion-panel-header-' +
          (seq - 1)
      );
    }
  }
  validateColapsedItem(item, section) {
    this.getSectionHeader(item, section)
      .first()
      .should('have.attr', 'aria-expanded', 'false');
  }

  validateExpandedItem(item, section) {
    this.getSectionHeader(item, section)
      .last()
      .should('have.attr', 'aria-expanded', 'true');
  }

  deleteItemFromSection(item, section) {
    cy.get('[id^="containerRemoveButton"]').first().click();
  }

  validateItemAfterDelete(section) {
    cy.get('[id^="containerRemoveButton"]').should('not.exist');
  }

  validateDeleteIconOnItem(item, section) {
    cy.get('[id^="containerRemoveButton"]').should('not.exist');
  }

  inputNumberOfSeals(numberOfSeals) {
    cy.get('input#teNoOfSeal1').fill(numberOfSeals);
  }

  validateSealIdentifierField() {
    cy.get('input#teSealIdentifier').should('exist');
  }

  clickAddIconOfSealIdentifier() {
    cy.get('button#teSealIdentifier')
      .find('span>mat-icon')
      .should('have.text', 'add')
      .click();
  }

  validateDeleteSealIdIcon() {
    cy.get('button#teRemSealIdentifier').should('exist');
  }

  clickDeleteSealIcon() {
    cy.get('button#teRemSealIdentifier').click();
  }
  compareSealValueWithInput(numberOfSeals) {
    const seal = numberOfSeals.length();
    cy.get('input#teNoOfSeal1').should('have.length.lessThan', 5);
  }

  clickAddSealIdentifierItem() {
    cy.get('button#teAddSealIdentifier').click();
  }

  selectSupportingDocumentCheckBox() {
    cy.get('#sdCheck').click();
  }

  selectSupportingDocumentType(documentType) {
    cy.get('#supportingDocumentType').type(documentType);
  }
  selectAdditionalRefType(type) {
    cy.get('#additionalReferencesType').type(type);
  }

  inputSupportingDocumentRefNumber(documentReferenceNumber) {
    cy.get('input#sdRefNum').fill(documentReferenceNumber);
  }

  inputAdditionalInformationText(additionalInfoText) {
    cy.get('textarea#note').should('be.enabled').fill(additionalInfoText);
  }

  inputAdditionalRefNumber(number) {
    cy.get('#refNumber').fill(number);
  }

  inputAdditionalSupplyChainEori(eori) {
    cy.get('input#ascaEori').fill(eori);
  }

  selectAdditionalSupplyChainRole(role) {
    cy.get('#ascaRole').selectOption(role);
  }

  validateNoErrors() {
    cy.get('mat-error').should('not.exist');
  }
  validateWeightCheckBox() {
    cy.get('#weightCheck input#weightCheck-input').should(
      'have.attr',
      'aria-checked',
      'true'
    );
  }

  validatePreviousDocumentCheckBox() {
    cy.get('#pdCheck input#pdCheck-input').should(
      'have.attr',
      'aria-checked',
      'true'
    );
  }

  validatePreviousDocumentTypeOptions(declarationType: string) {
    let expected;
    if (declarationType === 'combined') {
      expected = 'N355 - Entry Summary Declaration';
    } else {
      expected = 'N821-Transit Declaration';
    }
    cy.get('#pdType').then(function ($select) {
      $select.val(expected);
    });
    cy.get('#pdType').should('have.value', expected);
  }

  validateTransportEquipmentCheckBox() {
    cy.get('#teCheck').should('have.class', 'mat-checkbox-checked');
  }

  validateSupportingDocumentCheckBox() {
    cy.get('#sdCheck').should('have.class', 'mat-checkbox-checked');
  }

  validateAdditionalInformationCheckBox() {
    cy.get('#addInfoCheck').should('have.class', 'mat-checkbox-checked');
  }
  validateAdditionalReferenceCheckBox() {
    cy.get('#addRefCheck').should('have.class', 'mat-checkbox-checked');
  }

  validateAdditionalSupplyChainActorCheckBox() {
    cy.get('#ascaCheck').should('have.class', 'mat-checkbox-checked');
  }

  validatePreviousDocumentTypeNotVisible() {
    cy.get('#pdCheck').should('not.have.class', 'mat-checkbox-checked');
  }

  validateCommodityCode(
    consignorTypeOfPerson: string,
    consigneeTypeOfPerson: string
  ) {
    if (consignorTypeOfPerson === '1' && consigneeTypeOfPerson === '1') {
      cy.get('#commodityCodeCheck').should(
        'have.class',
        'mat-checkbox-checked'
      );
    } else {
      cy.get('#commodityCodeCheck').should('not.exist');
    }
  }

  inputTransportDocumentReferenceNumber(transDocRef) {
    cy.get('input#tdRefNum').click().fill(transDocRef);
  }

  inputWeight() {
    return cy.get('#weight');
  }

  checkSectionAndItem(section: string) {
    if (section === 'Transport Equipment') {
      this.selectTransportEquipmentCheckBox();
      this.addItemTransportEquipment();
    } else if (section === 'Supporting Document') {
      this.selectSupportingDocumentCheckBox();
      this.addItemSupportingDocCheckBox();
    } else if (section === 'Additional Information') {
      this.selectAdditionalInfoCheckBox();
      this.addItemAdditionalInfoCheckBox();
    } else if (section === 'Additional Reference') {
      this.selectAdditionalReferenceCheckBox();
      this.addItemAdditionalRefCheckBox();
    } else if (section === 'Additional Supply Chain Actor') {
      this.selectAdditionalSupplyChainCheckBox();
      this.addItemAdditionalSupplyChainCheckBox();
    } else if (section === 'Packaging') {
      this.addPackaging();
    }
  }
  checkSection(section: string) {
    if (section === 'Transport Equipment') {
      this.selectTransportEquipmentCheckBox();
    } else if (section === 'Supporting Document') {
      this.selectSupportingDocumentCheckBox();
    } else if (section === 'Additional Information') {
      this.selectAdditionalInfoCheckBox();
    } else if (section === 'Additional Reference') {
      this.selectAdditionalReferenceCheckBox();
    } else if (section === 'Additional Supply Chain Actor') {
      this.selectAdditionalSupplyChainCheckBox();
    }
  }
  selectPreviousDocumentType(
    prevDocTypeValue:
      | 'N821 - Transit Declaration'
      | 'N355 - Entry Summary Declaration'
  ) {
    cy.get('#pdType').selectOption(prevDocTypeValue);
  }

  inputPreviousDocumentRefNumber(prevDocRefNum) {
    cy.get('#pdRefNum').click().fill(prevDocRefNum);
  }

  selectTransportEquipmentCheckBox() {
    if (
      cy
        .get('#teCheck')
        .should('contain', 'Transport equipment')
        .and('not.have.class', '.mat-checkbox-checked')
    ) {
      cy.get('#teCheck').should('contain', 'Transport equipment').click();
    }
  }
  selectWeightCheckBox() {
    if (
      cy
        .get('#weightCheck')
        .should('contain', 'Weight')
        .and('not.have.class', '.mat-checkbox-checked')
    ) {
      cy.get('#weightCheck').should('contain', 'Weight').click();
    }
  }
  selectCUSCode() {
    return cy.get('[data-testid="cusCode"]');
  }
  inputCommodityDescription(desc: string) {
    cy.get('#description').click().fill(desc);
  }

  inputCommodityCode(code) {
    cy.get('#harmonizedSystemSubHeadingCode').click().fill(code);
  }

  combinedNomenclatureCode(code) {
    cy.get('#combinedNomenclatureCode').click().fill(code);
  }

  isPackagingAvailable() {
    cy.get('#shippingMarks').click().fill('Test Shipping Marks');
  }

  selectAdditionalReferenceCheckBox() {
    cy.get('#addRefCheck').click();
  }

  validateAllRequiredFields() {
    this.validateNoErrors();
  }

  validateWeight(maxLength) {
    cy.get('#tdWeight').should('have.length.lte', maxLength);
    cy.get('#tdWeight').should(($input) => {
      const text = $input.val();
      expect(text).to.match(/^[1-9.]+[0-9]*$/);
    });
  }
  validatePackagingNumber(maxLength) {
    cy.get('input#number').should('have.length.lte', maxLength);
    cy.get('input#number').should(($input) => {
      const text = $input.val();
      expect(text).to.match(/^[1-9]+[0-9]*$/);
    });
  }
  inputPackagingNumber() {
    return cy.get('input#number');
  }

  inputPackagingType() {
    return cy.get(' #packagingType');
  }

  inputPackagingMarks() {
    return cy.get(' #shippingMarks');
  }

  inputTransportEquipmentIdNumber(id) {
    cy.get('input#tdIdentificationNum1').click().fill(id);
  }

  inputTransportEquipmentNumber(equipNumber) {
    cy.get('input#tdIdentificationNum1').click().fill(equipNumber);
  }

  selectTransportEquipmentContainerStatus(packedStatus) {
    cy.get('#teConPackStatus1').selectOption(packedStatus);
  }

  selectSupportingDocCheckBox() {
    cy.get('#sdCheck').click();
  }

  inputAdditionalSupplyChainActorEori(eori: string) {
    cy.get('mat-form-field#eori').click().fill(eori);
  }

  validatePreviousDocRefNumMaxLimit(maxLength: number) {
    cy.get('input#pdRefNum').should('have.length.lte', maxLength);
  }

  validateTransportEquipmentIdNumberMaxLimit(maxLength: number) {
    cy.get('input#tdIdentificationNumber').should('have.length.lte', maxLength);
  }

  validateReceptacleIdNumberMaxLimit(maxLength: number) {
    cy.get('input#recIdentificationNum').should('have.length.lte', maxLength);
  }

  validateSupportingDocumentRefNumberMaxLimit(maxLength: number) {
    cy.get('input#sdRefNum').should('have.length.lte', maxLength);
  }

  validateAddSuppChainActorEoriMaxLimit(maxLength: number) {
    cy.get('mat-form-field#eori').should('have.length.lte', maxLength);
  }

  selectAdditionalInfoCheckBox() {
    cy.get('#addInfoCheck').click();
  }

  selectAdditionalSupplyChainCheckBox() {
    cy.get('#ascaCheck').click();
  }

  clickSave() {
    cy.get('#save').click();
  }

  clickNext() {
    cy.get('#next').click();
  }
  cancel() {
    return cy.get('[data-testid="errorPopup"]');
  }
  getCloseButton() {
    return cy.get('[data-testid="errorCloseBtn"]');
  }
  getCreateNewButton() {
    return cy.get('[data-testid=CreateNewBtn]');
  }
  isHomeScreen() {
    cy.get('.home > span').should('contain', 'Welcome to TSD Angular UI App!!');
  }
  getCancelButton() {
    return cy.get('#cancel');
  }
  validateErrors() {
    cy.get('mat-error').should('exist');
  }
}
