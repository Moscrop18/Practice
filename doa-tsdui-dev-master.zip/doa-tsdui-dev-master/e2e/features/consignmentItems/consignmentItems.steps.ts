///<refernce types = "Cypress"/>

import { should } from 'chai';
import { Given, When, Then } from 'cypress-cucumber-preprocessor/steps';
import { getUniqueEtag } from '../common/util';
import { MasterConsignItemPage } from './consignmentItems.po';

let page = new MasterConsignItemPage();

var appTitleFull = ' Temporary storage declaration ';
var appTitleShort = ' TSD ';
let putInterceptFlag = false;

Given('mock data setup', () => {
  putInterceptFlag = false;
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/0/items?pageSize=100',
    {
      fixture: 'goods-items.json',
      headers: { etag: getUniqueEtag() }
    }
  ).as('consignment0Items');
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments?fields=draftErrors&pageSize=100',
    {
      fixture: 'houseList.json',
      headers: { etag: getUniqueEtag() }
    }
  ).as('consignments');
  cy.intercept('GET', '/assets/codelist/codelist.json', {
    fixture: 'codelist.json'
  }).as('codeList');
  cy.intercept(
    'PUT',
    '/api/v1/temporaryStorageDeclarations/1/consignments/0/items/1',
    (req) => {
      putInterceptFlag = true;
      req.reply({ statusCode: 200, headers: { etag: getUniqueEtag() } });
    }
  ).as('cons0Item1Put');
});

Given(
  'I have navigated to the master consignment item page with {string}, {string} and {string}',
  (declarationType, consignorTypeOfPerson, consigneeTypeOfPerson) => {
    cy.fixture('tsd-empty-declaration.json').then((data) => {
      const updatedDeclaration = {
        ...data,
        type: declarationType,
        consignmentType: 'MasterAndHouse'
      };
      cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1', {
        body: updatedDeclaration,
        headers: { etag: getUniqueEtag() }
      }).as('declaration');
    });
    cy.fixture('empty-consignment.json').then((data) => {
      const updatedCons = {
        ...data,
        consignor: {
          typeOfPerson: parseInt(consignorTypeOfPerson),
          identificationNumber: '',
          name: '',
          address: {
            street: '',
            streetAdditionalLine: '',
            number: '',
            poBox: '',
            subDivision: '',
            postCode: '',
            city: '',
            country: '',
            streetAndNumber: ''
          },
          communication: [
            {
              identifier: '',
              type: '',
              fullName: ''
            }
          ]
        },
        consignee: {
          typeOfPerson: parseInt(consigneeTypeOfPerson),
          identificationNumber: '',
          name: '',
          address: {
            street: '',
            streetAdditionalLine: '',
            number: '',
            poBox: '',
            subDivision: '',
            postCode: '',
            city: '',
            country: '',
            streetAndNumber: ''
          },
          communication: [
            {
              identifier: '',
              type: '',
              fullName: ''
            }
          ]
        }
      };
      cy.intercept(
        '/api/v1/temporaryStorageDeclarations/1/consignments/0?fields=allowedSections',
        {
          body: updatedCons,
          headers: { etag: getUniqueEtag() }
        }
      ).as('consignment0Info');
    });
    cy.fixture('empty-consignment-items.json').then((data) => {
      const updatedConsItem = {
        ...data,
        packaging: [
          {
            shippingMarks: '',
            numberOfPackages: '',
            typeOfPackages: ''
          }
        ]
      };
      cy.intercept(
        'GET',
        '/api/v1/temporaryStorageDeclarations/1/consignments/0/items/1?fields=allowedSections',
        {
          body: updatedConsItem,
          headers: { etag: getUniqueEtag() }
        }
      ).as('cons0Item1');
    });
    page.visit();
    page.validateURLPath();
    page.getPageHeaderTitle().should('contain', 'Step 2: Item 1');
  }
);

When('I check all sections', () => {
  page.selectTransportEquipmentCheckBox();
  page.selectSupportingDocCheckBox();
  page.selectAdditionalInfoCheckBox();
  page.selectAdditionalReferenceCheckBox();
  page.selectAdditionalSupplyChainCheckBox();
});

When('I check all sections on items page', () => {
  page.selectTransportEquipmentCheckBox();
  page.selectSupportingDocCheckBox();
  page.selectAdditionalInfoCheckBox();
  page.selectAdditionalReferenceCheckBox();
  page.selectAdditionalSupplyChainCheckBox();
});

var pageHeading = ' Step 2: Item 1 ';
var pageHeadingHint =
  ' Select the sections that are applicable and enter the required information ';
Then('I see the master consignment item page with all sections checked', () => {
  page.getAppTitle().should('have.text', appTitleFull || appTitleShort);
  page.getPageHeaderTitle().should('have.text', pageHeading);
  page.getPageHeaderTitleHint().should('have.text', pageHeadingHint);
  //Validating checkboxes are checked
  page.validateWeightCheckBox();
  page.validatePreviousDocumentCheckBox();
  page.validateSupportingDocumentCheckBox();
  page.validateAdditionalInformationCheckBox();
  page.validateAdditionalReferenceCheckBox();
  page.validateAdditionalSupplyChainActorCheckBox();
});

Then(
  'The previous document type is correctly populated for {string}',
  (declarationType) => {
    page.validatePreviousDocumentTypeOptions(declarationType);
  }
);

Then(
  'The comodity code section is correctly visible for {string} and {string}',
  (consignorTypeOfPerson, consigneeTypeOfPerson) => {
    page.validateCommodityCode(consignorTypeOfPerson, consigneeTypeOfPerson);
  }
);
When('I click on cancel without saving', () => {
  page.getCloseButton().click();
  cy.wrap(putInterceptFlag).should('eq', false);
});
When('I click on save changes', () => {
  page.getCreateNewButton().click();
  cy.wait('@cons0Item1Put').then(() => {
    cy.wrap(putInterceptFlag).should('eq', true);
  });
});
Then('I navigate to home screen', () => {
  page.isHomeScreen();
});
When('I click on Cancel', () => {
  page.getCancelButton().click();
});
When('I see unsaved changes dialog', () => {
  page.cancel().should('be.visible');
});
When(
  'I try to enter more data than allowed in each field marked with max characters',
  () => {
    page.inputCommodityDescription('desc');
    page.inputPackagingNumber().click().type('1112233445544667788');
    page.validateWeightCheckBox();
    page.inputWeight().getTextField().clear().type('11.223311222344111134');
    page.inputPreviousDocumentRefNumber(
      '4gtfobprx1fbxenoem62k2p5skhe7yful3utmxc8gcovw9r6d2vfqdjf67rwx0jawmrgsj1a2b3c'
    );
    page.inputTransportEquipmentIdNumber('AaaZ123456789');
    page.inputSupportingDocumentRefNumber(
      '4gtfobprx1fbxenoem62k2p5skhe7yful3utmxc8gcovw9r6d2vfqdjf67rwx0jawmrgsj1a2b3c'
    );
    page.inputAdditionalSupplyChainActorEori('1w111erer1er1rer1ery11y');
  }
);
Then(
  'I see that the input is trimmed upto the maximum allowed limit for that field',
  () => {
    page.validatePackagingNumber(8);
    page.validateWeight(16);
    page.validatePreviousDocRefNumMaxLimit(70);
    page.validateTransportEquipmentIdNumberMaxLimit(11);
    page.validateSupportingDocumentRefNumberMaxLimit(70);
    page.validateAddSuppChainActorEoriMaxLimit(17);
  }
);
When('I try to enter non numeric data in numeric only fields', () => {
  page.inputPackagingNumber().click().type('1sdfr1');
  page.validateWeightCheckBox();
  page.inputWeight().getTextField().clear().type('1ghghd7');
});
Then(
  'I see that non numeric characters are trimmed and only numeric characters are entered',
  () => {
    page.validatePackagingNumber(8);
    page.validateWeight(16);
  }
);
When('I fill in all required fields', () => {
  page.inputCommodityDescription('Test Commodity Description');
  page.inputCommodityCode('2917113');
  page.combinedNomenclatureCode('00');
  page.inputWeight().type('12.334');
  page.selectPreviousDocumentType('N355 - Entry Summary Declaration');
  page.inputPreviousDocumentRefNumber('20BE00000889012AT4');
});
When('I click on Save', () => {
  page.clickSave();
});
Then('no errors are shown', () => {
  page.validateAllRequiredFields();
});

When(
  'I check section and click on the add item button of section {string}',
  (section) => {
    page.checkSectionAndItem(section);
  }
);

Then('I see 2 items in {string}', (section) => {
  page.validateItemsAdded(section);
});
Then('I see {string} in section {string} is collapsed', (item, section) => {
  page.validateColapsedItem(item, section);
});
Then('I see {string} in section {string} is expanded', (item, section) => {
  page.validateExpandedItem(item, section);
});
When(
  'I click on the delete item button from item {string} in {string}',
  (item, section) => {
    page.deleteItemFromSection(item, section);
  }
);
Then('I see 1 items in {string}', (section) => {
  page.validateItemAfterDelete(section);
});

Then(
  'I see {string} in section {string} does not have a delete button',
  (item, section) => {
    page.validateDeleteIconOnItem(item, section);
  }
);
When('I enter a valid Commodity description {string}', (commDesc) => {
  page.inputCommodityDescription(commDesc);
});
When('I enter a valid CUS Code {string}', (code) => {
  page.selectCUSCode().type(code);
});
When('I enter a valid Harmonized Code {string}', (code) => {
  page.inputCommodityCode(code);
});
When(
  'I enter a valid packaging type {string}, number {string} and shipping marks {string}',
  (type, number, marks) => {
    page
      .inputPackagingType()
      .last()
      .should('be.visible')
      .then(() => {
        page.inputPackagingType().last().selectAutocomplete(type);
        page.inputPackagingNumber().last().click().type(number);
        page.inputPackagingMarks().last().click({ force: true }).fill(marks);
      });
  }
);
When(
  'I enter a valid {string} of packages present in code list CL181 or CL182',
  (type) => {
    page
      .inputPackagingType()
      .type(type)
      .get('.mat-option-text')
      .contains(type)
      .click();
  }
);
When('I enter a valid {string}', (mass) => {
  page.inputWeight().getTextField().clear().type(mass);
});
When('I can see the {string} entry after filling', (mass) => {
  page.inputWeight().getTextField().should('have.value', mass);
});
Then('I verify the helper text at Gross Mass section', () => {
  page
    .inputWeight()
    .getHint()
    .should(
      'contain',
      'Maximum 16 digits with 6 digits after decimal, value greater than 0'
    );
});

When(
  'I enter a valid Previous Document with {string} and {string}',
  (type, refNumber) => {
    page.inputPreviousDocumentRefNumber(refNumber);
    page.selectPreviousDocumentType(type);
  }
);
When('I check section {string}', (section) => {
  page.checkSection(section);
});
When(
  'I enter a valid transport equipment with Container packed status {string}',
  (status) => {
    page.selectTransportEquipmentContainerStatus(status);
  }
);
When(
  'I enter a valid Supporting Document with {string} and {string}',
  (type, refNum) => {
    page.selectSupportingDocumentType(type);
    page.inputSupportingDocumentRefNumber(refNum);
  }
);
When('I enter a valid Additional Information with {string}', (text) => {
  page.inputAdditionalInformationText(text);
});
When(
  'I enter a valid Additional Reference with {string} and {string}',
  (type, refNum) => {
    page.selectAdditionalRefType(type);
    page.inputAdditionalRefNumber(refNum);
  }
);
When(
  'I enter a valid Additional Supply Chain Actor with {string} and {string}',
  (eori, role) => {
    page.inputAdditionalSupplyChainEori(eori);
    page.selectAdditionalSupplyChainRole(role);
  }
);
When('I enter mandatory fields', () => {
  page.inputCommodityDescription('desc');
  page.selectPreviousDocumentType('N355 - Entry Summary Declaration');
  page.inputPreviousDocumentRefNumber('REF123TTTTTTTTTTTT');
});

Given(
  'I have navigated to the master consignment item page with invalid query parameters',
  () => {
    cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1', {
      statusCode: 404,
      body: {}
    }).as('deleteResponse');
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/0?fields=allowedSections',
      {
        statusCode: 404,
        body: {}
      }
    ).as('deleteResponse1');
    page.visit1();
  }
);

Then('I see the PAGE NOT FOUND screen', () => {
  page.invalidateURLPath();
});
Then('Errors are shown', () => {
  page.validateErrors();
});
When('I click on the add item button of section', () => {
  page.addPackaging();
});

Then('No Number and Shipping Marks are shown', () => {
  page.inputPackagingNumber().should('not.exist');
  page.inputPackagingMarks().should('not.exist');
});
When('I click on Next', () => {
  page.clickNext();
});
