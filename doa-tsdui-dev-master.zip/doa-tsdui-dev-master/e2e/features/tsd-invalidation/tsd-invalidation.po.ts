export class TsdInvalidationPage {
  getSuccessTitle() {
    return cy.get('[data-testid=errorTitle]');
  }
  getSubmitButton() {
    return cy.get('[data-testid=invSubmitBtn]');
  }

  populateReason(): Cypress.Chainable<any> {
    return cy.get('[data-testid=invReason]');
  }

  getInvalidateButton() {
    return cy.get('[data-testid=reqForInv]');
  }
  getActionMenu() {
    return cy.get('[data-testid=menuButton]');
  }
  visitStandardDrawer() {
    cy.loginWithEO();
    cy.visit('/advanced-search/search-results/20BETP000000C3FLU4');
  }
}
