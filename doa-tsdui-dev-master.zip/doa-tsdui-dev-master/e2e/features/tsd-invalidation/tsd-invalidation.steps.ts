///<reference types = "Cypress"/>
import { ConsultGeneralInformation } from '@features/manage-declaration/models/consult-general-information';
import { And, Given, Then, When } from 'cypress-cucumber-preprocessor/steps';
import { Http2ServerRequest, Http2ServerResponse } from 'http2';
import { TsdInvalidationPage } from './tsd-invalidation.po';

let page = new TsdInvalidationPage();
let tsd: ConsultGeneralInformation;

Given('I have navigated to consult TSD page', () => {
  cy.fixture('standard-drawer-prelodged.json').then((declaration) => {
    tsd = declaration;
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4',
      declaration
    ).as('advancedSearch');
  });
  cy.fixture('tsd-consult-event-history.json').then((declaration) => {
    tsd = declaration;
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/versions',
      declaration
    ).as('versions');
  });
  page.visitStandardDrawer();
});

Given('I have configured invalidation request mock for success', () => {
  cy.intercept(
    'POST',
    '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/invalidate',
    {
      fixture: 'tsd-invalidate-success.json'
    }
  ).as('invalidateSuccess');
});

Given('I have configured invalidation request mock for failure', () => {
  cy.intercept(
    'POST',
    '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/invalidate',
    {
      statusCode: 400,
      body: {
        id: 1,
        violations: [{ remarks: 'Request cannot be approved' }]
      }
    }
  ).as('invalidateFailure');
});

And('I click on Request for Invalidation button in action menu', () => {
  page.getActionMenu().click();
  page.getInvalidateButton().click();
});

And('I give the reason for invalidation request', () => {
  page.populateReason().type('Test reason');
});

When('I click on submit button', () => {
  page.getSubmitButton().click();
});

Then('I see success banner for TSD Invalidation', () => {
  cy.wait('@invalidateSuccess');
  page.getSuccessTitle().should('contain', 'Request for invalidation approved');
});

Then('I see failure banner for TSD Invalidation', () => {
  cy.wait('@invalidateFailure');
  page.getSuccessTitle().should('contain', 'Request for invalidation refused');
});
