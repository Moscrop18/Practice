import { HomePage } from '../home/home.po';

export class LoginPage {
  getHomePage() {
    return new HomePage();
  }
  visit() {
    cy.visit('/');
  }
}
