import { Given, When, Then } from 'cypress-cucumber-preprocessor/steps';

import { LoginPage } from './login.po';

let page = new LoginPage();

Given('I am at the login page', () => {
  page.visit();
});

When('I as Economic Operator sign in with the correct credentials', () => {
  cy.loginWithEO();
});

Then('I should see the Home Page', () => {
  page.getHomePage().isVisible();
});
