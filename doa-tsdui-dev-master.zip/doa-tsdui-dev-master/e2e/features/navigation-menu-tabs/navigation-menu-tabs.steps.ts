import { Given, When, Then, And } from 'cypress-cucumber-preprocessor/steps';
import { HeaderTabs } from './navigation-menu-tabs.po';

let page = new HeaderTabs();
let pageTitle = {
  'NEW DECLARATION': 'Question wizard',
  'SAVED DRAFTS': 'Saved drafts',
  'ADVANCED SEARCH': 'Advanced search',
  'HOME': 'TSD Application'
};
let lrn = '1234';
let confirmationPopupHeader = 'Confirm navigation';

Given('I am at home page', () => {
  cy.fixture('tsd-drafts.json').then((data) => {
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations?status=Draft&sort=-registrationDate**',
      data
    );
  });
  page.visit();
});

When('I click on tab {string}', (tab) => {
  page.getTab(tab).click();
});

Then('I see page corresponding to {string}', (tab) => {
  page.getPageTitle().should('have.text', pageTitle[tab]);
});

When('I click on language option {}', (lang) => {
  page.getLanguageOption(lang).click();
});

Then('I see text translated in {}', (lang) => {
  page.getLanguageOption(lang).should('have.class', 'active');
});

And('I input LRN on the page displayed', () => {
  page.getLrn().type(lrn);
});

Then('I see confirmation popup is displayed', () => {
  page.getPopupHeader().should('have.text', confirmationPopupHeader);
});

And('I see data is retained on selecting {string} option', (option) => {
  page.getPopupOptionStay().should('contain', option).click();
  page.getLrn().should('have.value', lrn);
});

And('I see {string} page on selecting {string} option', (tab, option) => {
  page.getPopupOptionLeave().should('contain', option).click();
  page.getPageTitle().should('have.text', pageTitle[tab]);
});

And('I select {string} radio button', (radioButton) => {
  page
    .getDeclarationTypeOption(radioButton)
    .click()
    .should('have.class', 'mat-radio-checked');
});
