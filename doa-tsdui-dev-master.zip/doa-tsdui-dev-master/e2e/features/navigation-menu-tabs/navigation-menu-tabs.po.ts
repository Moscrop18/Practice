export class HeaderTabs {
  visit() {
    cy.loginWithEO();
    cy.visit('/');
  }
  isVisible() {
    cy.get('');
  }
  getPageTitle() {
    return cy.get('title');
  }
  getTab(tab) {
    if (tab === 'HOME') {
      return cy.get('#menuId0');
    } else if (tab === 'NEW DECLARATION') {
      return cy.get('#menuId1');
    } else if (tab === 'SAVED DRAFTS') {
      return cy.get('#menuId2');
    } else if (tab === 'ADVANCED SEARCH') {
      return cy.get('#menuId3');
    }
  }

  getLanguageOption(lang) {
    return cy.get('.language-link:contains(' + lang + ')');
  }

  getLrn() {
    return cy.get('[data-testid=lrn]');
  }
  getPopup() {
    return cy.get('[data-testid=errorPopup]');
  }
  getPopupHeader() {
    return cy.get('[data-testid=errorTitle]');
  }
  getPopupOptionStay() {
    return cy.get('[data-testid=CreateNewBtn]');
  }
  getPopupOptionLeave() {
    return cy.get('[data-testid=errorCloseBtn]');
  }

  getDeclarationTypeOption(value: string) {
    return cy.get(
      '[data-testid=question-type] mat-radio-button[value=' + value + ']'
    );
  }
}
