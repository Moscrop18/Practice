import { Given, When, And, Then } from 'cypress-cucumber-preprocessor/steps';
import { ConsultEventHistory } from './consult-tsd-event-history.po';
import '../common/customTypes';
import '../common/accessibility.steps';
import { columnSort, convertDate } from './../common/util';
import { EventHistory } from '@features/manage-declaration/models/event/event-history';
import { EventItem } from '@features/manage-declaration/models/event/event-history-item';
import { endsWith, truncate } from 'cypress/types/lodash';
import _ from 'cypress/types/lodash';
import { T } from 'cypress/types/lodash/fp';
import { contains } from 'cypress/types/jquery';

let page = new ConsultEventHistory();
let eventHistory: EventHistory;
let notCurrentVersionText = 'Attention: this is not the latest version';
let tableHeaders = {
  ' History ': [
    'Version',
    'Category',
    'Date and time',
    'Request status',
    'TSD status',
    'Action'
  ]
};

Given('Prepare event history test mock data', () => {
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4',
    {
      fixture: 'tsd-declaration.json'
    }
  ).as('declaration');

  cy.fixture('tsd-consult-event-history.json').then((historyData) => {
    eventHistory = historyData;
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/20BETP000000C3FLU4/versions',
      eventHistory
    ).as('eventHistory');
  });

  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/2313434', {
    fixture: 'generalInfo-eventHistory-amendmentRefused.json'
  }).as('amendment1');
  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/2313429', {
    fixture: 'generalInfo-eventHistory-amendment.json'
  }).as('amendment2');
  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/2313426', {
    fixture: 'generalInfo-eventHistory-submission.json'
  }).as('submission');
  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/2313432', {
    fixture: 'generalInfo-eventHistory-transferRefused.json'
  }).as('transferRefused');
  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/2313433', {
    fixture: 'generalInfo-eventHistory-transferApproved.json'
  }).as('transferApproved');
  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/2313431', {
    fixture: 'generalInfo-eventHistory-deconsolidationApproved.json'
  }).as('deconsolidationApproved');
  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/2313430', {
    fixture: 'generalInfo-eventHistory-deconsolidationRefused.json'
  }).as('deconsolidationRefused');

  cy.intercept('/assets/codelist/codelist.json', {
    fixture: 'codelist.json'
  }).as('codeList');
});

Given('I have navigated to Event History page', () => {
  page.visitEventHistoryPage(
    '/advanced-search/search-results/20BETP000000C3FLU4/history'
  );
  cy.wait('@declaration');
  cy.wait('@eventHistory');
  page.isVisible();
  page.getPageTitle().should('exist');
});

Given('I have navigated to Consult declaration page', () => {
  page.visitEventHistoryPage(
    '/advanced-search/search-results/20BETP000000C3FLU4'
  );
  cy.wait('@declaration');
  page.getGeneralInfoTitle().should('exist');
});

When('I click on History section under navigation drawer', () => {
  page.getHistorySection().click();
  cy.wait('@eventHistory');
});

Then('I see the event history page', () => {
  page.getPageTitle().should('contain', 'History');
});

Then('I see the {string} requests details', (requestType) => {
  page
    .getVersionBanner()
    .should('exist')
    .and('contain.text', notCurrentVersionText)
    .and('contain', requestType)
    .and('contain', 'approved on Aug 24, 2019 at');
});

Then('I see the submission banner', () => {
  page
    .getVersionBanner()
    .should('exist')
    .and('contain.text', notCurrentVersionText)
    .should('contain', 'Submission')
    .should('contain', 'Approved on Apr 02, 2021 at');
});

And('I see table {string} with headers', (tableName) => {
  page
    .getHistoryTable()
    .should('contain', tableName)
    .getTableHeadersText()
    .should('deep.equal', tableHeaders[' History ']);
});

When('I go to next page', () => {
  page.getHistoryTable().gotoNextTablePage();
});

And('I can use the pagination of the {string} table', (tableName) => {
  page.getHistoryTable().gotoNextTablePage();

  page.getHistoryTable().getTableRows().should('have.length', 1);
  page
    .getHistoryTable()
    .gotoPreviousTablePage()
    .getTableRows()
    .should('have.length', 10);
  page
    .getHistoryTable()
    .setTablePageSize(20)
    .getTableRows()
    .should('have.length', 11);
  page
    .getHistoryTable()
    .setTablePageSize(10)
    .getTableRows()
    .should('have.length', 10);
});

function getSortedTableData() {
  let sorted = getTableDataSlice()
    .sort((a, b) => columnSort(a[2], b[2], true, true))
    .slice(0, 10);
  sorted.forEach((element) => {
    element[2] =
      convertDate(element[2], 'MMM dd, y') +
      ' at ' +
      convertDate(element[2], 'HH:mm');
    if (element[4] == 'Invalidation') element[4] = 'Invalidated';
  });
  return sorted;
}

And(
  'data in table {string} is sorted by date in descending order',
  (tableName) => {
    page
      .getHistoryTable()
      .getTableRows()
      .should('deep.equal', getSortedTableData());
  }
);

Then(
  'I see data in {string} table can be sorted by column in ascending order',
  (tableName) => {
    sortColumn(tableName);
  }
);

And('I get redirected to History page on clicking close button', () => {
  page.getErrorCloseButton().click();
  page.getUrlPath().should('contain', 'history');
});

function getTableDataSlice(start: number = 0, end?: number) {
  return getTableData().slice(start, end);
}
function sortColumn(tableName) {
  page
    .getHistoryTable()
    .getTableHeaders()
    .each((header, i) => {
      if (i < 3) {
        cy.wrap(header)
          .click()
          .wait(10)
          .then(() => {
            let sorted = getTableDataSlice(tableName);
            sorted.forEach((element) => {
              if (element[0].includes('check_outlineV'))
                element[0] = element[0].split('check_outline')[1];
            });
            if (i == 0)
              sorted = sorted
                .sort(
                  (a, b) =>
                    (a[i].charCodeAt(0) < b[i].charCodeAt(0) ? -1 : 1) *
                    (false ? 1 : -1)
                )
                .slice(0, 10);
            else
              sorted = sorted
                .sort((a, b) => columnSort(a[i], b[i], i > 0, i < 0))
                .slice(0, 10);
            sorted.forEach((element) => {
              element[2] =
                convertDate(element[2], 'MMM dd, y') +
                ' at ' +
                convertDate(element[2], 'HH:mm');
              if (element[4] == 'Invalidation') element[4] = 'Invalidated';
              if (element[0] == 'V9') element[0] = 'check_outline' + element[0];
            });

            page.getHistoryTable().getTableRows().should('deep.equal', sorted);
          });
      }
    });
}

And('I click on Back button on {string} page', (pageName) => {
  let itemIndex;
  if (pageName === 'Submission') {
    itemIndex = 7;
  } else if (pageName === 'Transfer') {
    itemIndex = 1;
  } else if (pageName === 'Deconsolidation') {
    itemIndex = 3;
  } else if (pageName === 'Amendment') {
    itemIndex = 6;
  }

  page
    .getUrlPath()
    .should('contain', 'Version')
    .and('contain', eventHistory.items[itemIndex].version);
  page.getPanelHeader(pageName).should('exist');
  page.getBackToHistoryLink().click();
});

Then('I should get redirected to History page', () => {
  page.getUrlPath().should('contain', 'history');
});

When(
  'I select {string} option from actions for {string} category and Request status as {string}',
  (action, category, requestStatus) => {
    page
      .getActionsButton(category, requestStatus, 'false')
      .selectActionMenuItem(action);
  }
);

Then('I see a dialogue is displayed with close button', () => {
  page.getErroPopup().should('be.visible');
});

And('I click on close button on dialogue', () => {
  page.getErroPopup().should('be.visible');
  page.getErrorCloseButton().click();
});

And('The reason is displayed in the pop-up', () => {
  page
    .getErrorMessage()
    .should(
      'contain',
      eventHistory.items[0].invalidationRequests[1].invalidationReason
    );
});
And('The {string} error is displayed in the pop-up', (errorType) => {
  let itemCount;
  if (errorType === 'invalidation') {
    itemCount = 0;
    page
      .getErrorMessage()
      .should(
        'contain',
        eventHistory.items[itemCount].invalidationRequests[0].validationError[0]
          .reason
      );
  } else if (errorType === 'amendment') {
    itemCount = 7;
    page
      .getErrorMessage()
      .should(
        'contain',
        eventHistory.items[itemCount].amendmentRequest.validationError[0].reason
      );
  } else if (errorType === 'transfer') {
    itemCount = 2;
    page
      .getErrorMessage()
      .should(
        'contain',
        eventHistory.items[itemCount].transferNotification.validationError[0]
          .reason
      );
  } else if (errorType === 'deconsolidation') {
    itemCount = 4;
    page
      .getErrorMessage()
      .should(
        'contain',
        eventHistory.items[itemCount].deconsolidationNotification
          .validationError[0].reason
      );
  }
});

When(
  'I click on actions icon for {string} category and Request status as {string}',
  (category, requestStatus) => {
    page.getActionsButton(category, requestStatus, 'false').click();
  }
);

And('I see {} options', (options) => {
  const optionArr = options.split(', ');

  cy.getActionMenuItems().should('deep.equal', optionArr);
});

When('I am on {string} page', (lan) => {
  cy.contains(lan).click();
});

When(
  'I can see Sub Heading {string},{string},{string},{string},{string},{string} when Language {string}',
  (Version, Category, DateAndTime, RequestStatus, TSDstatus, Action) => {
    page.getHistoryTable().contains(Version);
    page.getHistoryTable().contains(Category);
    page.getHistoryTable().contains(DateAndTime);
    page.getHistoryTable().contains(RequestStatus);
    page.getHistoryTable().contains(TSDstatus);
    page.getHistoryTable().contains(Action);
  }
);

function getTableData() {
  const eventItems: EventItem[] = [];
  let currentVersion;
  if (eventHistory?.items) {
    for (const item of eventHistory.items) {
      if (item?.invalidationRequests.length > 0) {
        for (const invalidationRequest of item.invalidationRequests) {
          const eventItem: EventItem = {
            version: item.version,
            category: 'Invalidation',
            dateTime: invalidationRequest.registrationDate,
            requestStatus: invalidationRequest.status,
            tsdStatus: item.tsdStatus,
            id: item.id,
            currentVersion: false,
            invalidationRequests: [],
            amendmentRequest: {},
            transferNotification: undefined,
            deconsolidationNotification: undefined
          };

          eventItems.push(eventItem);
        }
      }
      eventItems.push(item);
    }
    const uniqueArray = eventItems.filter((value, index) => {
      const _value = JSON.stringify(value);
      return (
        index ===
        eventItems.findIndex((obj) => {
          return JSON.stringify(obj) === _value;
        })
      );
    });
    eventHistory.items = uniqueArray;
  }

  return eventHistory.items.map((t) => {
    if (t.currentVersion === true) {
      currentVersion = 'check_outlineV' + t.version;
    } else {
      currentVersion = 'V' + t.version;
    }
    if (t.category === 'Transfer' || t.category === 'Deconsolidation') {
      let requestStatus = t.category.toLowerCase() + 'Notification';
      t.category = (t.category + ' notification').slice(0, 15).concat('...');
      t.dateTime = t[requestStatus].registrationDate;
    }
    if (t.category === 'Amendment') {
      t.dateTime = t[t.category.toLowerCase() + 'Request'].registrationDate;
    }
    return [
      t.category === 'Invalidation' ? '/' : currentVersion,
      t.category !== 'Submission'
        ? (t.category + ' request').slice(0, 15).concat('...')
        : t.category,
      t.dateTime,
      t.requestStatus,
      t.tsdStatus === 'PreLodged' ? 'Pre-lodged' : t.tsdStatus,
      'more_vert'
    ];
  });
}
