import * as _ from 'cypress/types/lodash';

export class ConsultEventHistory {
  visitEventHistoryPage(urlPath) {
    cy.loginWithEO();
    cy.visit(urlPath);
  }
  isVisible() {
    cy.location('pathname').should('contain', '/history');
  }

  getPageTitle() {
    return cy.get('.mat-title');
  }
  getGeneralInfoTitle() {
    return cy.get('[data-testid=genInfoTitle]');
  }

  getHistoryTable(): any {
    return cy.get('[data-testid="eventHistoryTable"]');
  }

  getHistorySection() {
    return cy.get('[data-testid=historyDesc]');
  }

  getActionsButton(
    category,
    requestStatus,
    currentVersion: any = 'true'
  ): Cypress.Chainable<any> {
    return cy
      .get(
        'tr:not(:contains(check_outline)):contains(' +
          category +
          '):contains(' +
          requestStatus +
          ')'
      )
      .first()
      .find('app-event-action');
  }

  getVersionBanner(): Cypress.Chainable<any> {
    return cy.get('.banner-container');
  }

  getErroPopup() {
    return cy.get('[data-testid="errorPopup"]');
  }

  getErrorMessage() {
    return cy.get('[data-testid="errorPopup"] [data-testid="errorMessage"]');
  }
  getErrorCloseButton() {
    return cy.get('[data-testid="errorCloseBtn"]');
  }
  getUrlPath() {
    return cy.location('pathname');
  }
  getPanelHeader(pageName) {
    return cy.get('div:contains("' + pageName + '")');
  }

  getBackToHistoryLink() {
    return cy.get('[data-testid=dismiss]');
  }
}
