import { DeclarationType, EnsReuse } from '../common/customTypes';
export class NewDeclarationSubmit {
  getSubmitButton() {
    return cy.get('#submit');
  }
  getOverview(): any {
    return cy.get('.mat-headline');
  }
  getOverviewTitle(): any {
    return cy.get('.mat-title');
  }
  getCancel(): Cypress.Chainable<any> {
    return cy.get('.overview-footer > :nth-child(1) > .mat-button-wrapper');
  }
  getErrorMessage(): Cypress.Chainable<any> {
    return cy.get('[data-testid=errorMessage]');
  }
  getDeclarationTitle(): any {
    return cy.get('[data-testid=declarationInformation]');
  }
  getLrn(): any {
    return cy.get('[data-testid=lrn]');
  }
  getDeclarant(): any {
    return cy.get('[data-testid=declarant]');
  }
  getDeclarantEori(): any {
    return cy.get('[data-testid=declarantEori]');
  }
  getDeclarantName(): any {
    return cy.get('[data-testid=name]');
  }
  getDeclarantEmail(): any {
    return cy.get('[data-testid="declarantEmail1"]');
  }
  getRepresentative(): any {
    return cy.get('[data-testid=representative]');
  }
  getRepresentativeStatus(): any {
    return cy.get('[data-testid=representativeStatus]');
  }
  getRepresentativeEori(): any {
    return cy.get('[data-testid=representativeEori]');
  }
  getRepresentativeName(): any {
    return cy.get('[data-testid=representativeName]');
  }
  getRepresentativeEmail(): any {
    return cy.get('[data-testid=represntativeEmail]');
  }
  isLastPageVisible() {
    cy.location('href').should(
      'contains',
      'http://localhost:4200/edit-declaration/tsd/house-con-items?tsdId=1&consNo=2&itemNo=12'
    );
  }
  getCreateNewButton(): any {
    return cy.get('[data-testid=CreateNewBtn] > .mat-button-wrapper');
  }
  getConfirmButton(): any {
    return cy.get('[data-testid=errorCloseBtn]');
  }
  getCancelBtn(): any {
    return cy.get('[data-testid=cancelBtn]');
  }
  getMasterConsignmentTitle(): any {
    return cy.get('[data-testid=masterConsignment]');
  }
  isQuestionWizardPageVisible() {
    cy.location('pathname').should('match', /\/edit-declaration$/);
    cy.get('app-edit-declaration-wizard').should('exist');
  }
  getCancelButton(): any {
    return cy.get('[data-testid=errorCloseBtn] > .mat-button-wrapper');
  }

  getStepper() {
    return cy.get('#stepper');
  }
}
