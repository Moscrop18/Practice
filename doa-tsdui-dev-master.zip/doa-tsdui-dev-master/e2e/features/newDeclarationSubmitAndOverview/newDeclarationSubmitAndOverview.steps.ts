///<reference types = "Cypress"/>
import { Given, When, Then, And } from 'cypress-cucumber-preprocessor/steps';
import { NewDeclarationSubmit } from './newDeclarationSubmitAndOverview.po';
import '../common/customTypes';
import { getUniqueEtag } from '../common/util';

const formError = 'Form contains errors. Please see fields marked in red.';
const dataNotFoundError =
  'No ENS-data found. Please try to submit the declaration again or create a new declaration without ENS re-use. By creating a new declaration, you will lose all the data you entered already.';
const eoriError =
  'We were not able to submit the declaration because we could not find an address based on the given (Declarant/Representative) EORI.';
const missingDataError =
  'The ENS data contains invalid or missing data.Please create a new declaration without ENS re-use. By creating a new declaration, you will lose all the data you entered already.';
let mockData;
let page = new NewDeclarationSubmit();

Given('Prepare New declaration mock test data', () => {
  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1', {
    fixture: 'tsd-declaration.json',
    headers: { etag: getUniqueEtag() }
  }).as('generalInfo');
  cy.fixture('codelist.json').then((data) => {
    cy.intercept('/assets/codelist/codelist.json', data).as('codeList');
  });
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments?fields=draftErrors&pageSize=100',
    {
      fixture: 'consignment_list.json'
    }
  ).as('consignments');

  cy.intercept('POST', '/api/v1/temporaryStorageDeclarations/1/validate', {
    statusCode: 200
  }).as('validate');

  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/2/items?pageSize=100',
    {
      fixture: 'goods-items.json'
    }
  ).as('consignment2Items');

  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/0/items',
    {
      fixture: 'goods-items.json'
    }
  ).as('consignment0Items');

  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/1/items?pageSize=100',
    {
      fixture: 'goods-items.json'
    }
  ).as('consignment1Items');

  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/2?fields=allowedSections',
    {
      fixture: 'house-consignment-info.json',
      headers: { etag: getUniqueEtag() }
    }
  ).as('consignment2');

  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1/consignments/0', {
    fixture: 'master-consignment-info.json',
    headers: { etag: getUniqueEtag() }
  }).as('consignment0');

  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1/consignments/1', {
    fixture: 'house-consignment-info.json',
    headers: { etag: getUniqueEtag() }
  }).as('consignment1');

  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1/consignments/2', {
    fixture: 'house-consignment-info2.json',
    headers: { etag: getUniqueEtag() }
  }).as('cons2');

  cy.intercept(
    'GET',

    '/api/v1/temporaryStorageDeclarations/1/consignments/2/items/12?fields=allowedSections',
    {
      fixture: 'master-consignment-items.json',
      headers: { etag: getUniqueEtag() }
    }
  ).as('cons1Item12');
  cy.intercept(
    'GET',

    '/api/v1/temporaryStorageDeclarations/1/consignments/2/items/11?fields=allowedSections',
    {
      fixture: 'master-consignment-items.json',
      headers: { etag: getUniqueEtag() }
    }
  ).as('cons1Item11');
  cy.intercept(
    'PUT',
    '/api/v1/temporaryStorageDeclarations/1/consignments/2/items/12',
    {
      statusCode: 200,
      headers: { etag: getUniqueEtag() }
    }
  ).as('cons0ItemPut');
});
Given(
  'Prepare New declaration mock test data with only type filled in packaging section',
  () => {
    cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1', {
      fixture: 'tsd-declaration.json',
      headers: { etag: getUniqueEtag() }
    }).as('generalInfo');
    cy.fixture('codelist.json').then((data) => {
      cy.intercept('/assets/codelist/codelist.json', data).as('codeList');
    });
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments?fields=draftErrors&pageSize=100',
      {
        fixture: 'consignment_list.json'
      }
    ).as('consignments');

    cy.intercept('POST', '/api/v1/temporaryStorageDeclarations/1/validate', {
      statusCode: 200
    }).as('validate');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/2/items?pageSize=100',
      {
        fixture: 'goods-items.json'
      }
    ).as('consignment2Items');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/0/items',
      {
        fixture: 'goods-items.json'
      }
    ).as('consignment0Items');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/1/items',
      {
        fixture: 'goods-items.json'
      }
    ).as('consignment1Items');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/2?fields=allowedSections',
      {
        fixture: 'house-consignment-info.json',
        headers: { etag: getUniqueEtag() }
      }
    ).as('consignment2');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/0',
      {
        fixture: 'master-consignment-info.json',
        headers: { etag: getUniqueEtag() }
      }
    ).as('consignment0');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/1',
      {
        fixture: 'house-consignment-info.json',
        headers: { etag: getUniqueEtag() }
      }
    ).as('consignment1');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/2',
      {
        fixture: 'house-consignment-info2.json',
        headers: { etag: getUniqueEtag() }
      }
    ).as('cons2');

    cy.intercept(
      'GET',

      '/api/v1/temporaryStorageDeclarations/1/consignments/2/items/12?fields=allowedSections',
      {
        fixture: 'item-without-packaging.json',
        headers: { etag: getUniqueEtag() }
      }
    ).as('cons1Item12');
    cy.intercept(
      'GET',

      '/api/v1/temporaryStorageDeclarations/1/consignments/2/items/11?fields=allowedSections',
      {
        fixture: 'master-consignment-items.json',
        headers: { etag: getUniqueEtag() }
      }
    ).as('cons1Item11');
    cy.intercept(
      'PUT',
      '/api/v1/temporaryStorageDeclarations/1/consignments/2/items/12',
      {
        statusCode: 200,
        headers: { etag: getUniqueEtag() }
      }
    ).as('cons0ItemPut');
  }
);
And('I am on the last consignment items page', () => {
  cy.loginWithEO();
  cy.visit('/edit-declaration/tsd/house-con-items?tsdId=1&consNo=2&itemNo=12');
  page.isLastPageVisible();
});
And('I am not on the last consignment items page', () => {
  cy.loginWithEO();
  cy.visit('/edit-declaration/tsd/house-con-items?tsdId=1&consNo=2&itemNo=11');
});
Then('I click on Submit button', () => {
  cy.wait('@generalInfo').then((data) => {
    mockData = data;
  });
  cy.wait('@cons1Item12');
  page.getSubmitButton().click({ force: true });
});
Then('I dont see the Submit button', () => {
  page.getSubmitButton().should('not.exist');
});
Then('I see the overview page', () => {
  cy.wait('@validate').then(() => {
    page.getOverview().contains(' Review and confirm submission ');
  });
});
Then('I click on the cancel button on the overview page', () => {
  page.getCancel().click();
});
And('I move to the last consignment item page', () => {
  page.isLastPageVisible();
});
Given(
  'Prepare New declaration mock test data when there is form errors',
  () => {
    cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1', {
      fixture: 'tsd-declaration-form-error.json',
      headers: { etag: getUniqueEtag() }
    }).as('generalInfo');
    cy.fixture('codelist.json').then((data) => {
      cy.intercept('/assets/codelist/codelist.json', data).as('codeList');
    });
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments?fields=draftErrors&pageSize=100',
      {
        fixture: 'houseList.json'
      }
    ).as('consignments');

    cy.intercept('POST', '/api/v1/temporaryStorageDeclarations/1/validate', {
      statusCode: 200
    }).as('validate');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/2/items?pageSize=100',
      {
        fixture: 'goods-items.json'
      }
    ).as('consignment2Items');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/0/items?pageSize=100',
      {
        fixture: 'goods-items.json'
      }
    ).as('consignment0Items');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/1/items',
      {
        fixture: 'goods-items.json'
      }
    ).as('consignment1Items');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/2?fields=allowedSections',
      {
        fixture: 'house-consignment-info.json',
        headers: { etag: getUniqueEtag() }
      }
    ).as('consignment2');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/0',
      {
        fixture: 'house-consignment-info.json',
        headers: { etag: getUniqueEtag() }
      }
    ).as('consignment0');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/1',
      {
        fixture: 'house-consignment-info.json',
        headers: { etag: getUniqueEtag() }
      }
    ).as('consignment1');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/2',
      {
        fixture: 'house-consignment-info.json',
        headers: { etag: getUniqueEtag() }
      }
    ).as('cons2');

    cy.intercept(
      'GET',

      '/api/v1/temporaryStorageDeclarations/1/consignments/2/items/12?fields=allowedSections',
      {
        fixture: 'master-consignment-items.json',
        headers: { etag: getUniqueEtag() }
      }
    ).as('cons1Item12');
    cy.intercept(
      'PUT',
      '/api/v1/temporaryStorageDeclarations/1/consignments/2/items/12',
      {
        statusCode: 200,
        headers: { etag: getUniqueEtag() }
      }
    ).as('cons0ItemPut');
  }
);
Then('I see the form error message', () => {
  page.getErrorMessage().should('contain', formError);
});
And('I see overview page details', () => {
  page.getDeclarationTitle().should('contain', 'Declaration information');

  page.getLrn().should('contain', mockData.response.body.lrn);
  page.getDeclarant().should('contain', 'Declarant');
  page
    .getDeclarantEori()
    .should('contain', mockData.response.body.declarant.identificationNumber);
  page
    .getDeclarantName()
    .should('contain', mockData.response.body.declarant.name);
  page.getRepresentative().should('contain', 'Representative');
  page
    .getRepresentativeStatus()
    .should('contain', mockData.response.body.representative.status);
  page
    .getRepresentativeEori()
    .should(
      'contain',
      mockData.response.body.representative.identificationNumber
    );
  page
    .getRepresentativeName()
    .should('contain', mockData.response.body.representative.name);
  page
    .getRepresentativeEmail()
    .should(
      'contain',
      mockData.response.body.representative.communication[0].identifier
    );
});
Then('I see Master Consignment details on the overview page', () => {
  cy.get('.overview-body').scrollTo(0, 500);
  page.getMasterConsignmentTitle().contains('MASTER CONSIGNMENT');
});
Given(
  'Prepare New declaration mock test data when there is no ENS data provided',
  () => {
    cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1', {
      fixture: 'tsd-declaration.json',
      headers: { etag: getUniqueEtag() }
    }).as('generalInfo');
    cy.fixture('codelist.json').then((data) => {
      cy.intercept('/assets/codelist/codelist.json', data).as('codeList');
    });
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments?fields=draftErrors&pageSize=100',
      {
        fixture: 'houseList.json'
      }
    ).as('consignments');

    cy.intercept('POST', '/api/v1/temporaryStorageDeclarations/1/validate', {
      fixture: 'tsd-declaration_no_ens_data.json',
      statusCode: 400,
      failOnStatusCode: false
    }).as('validate');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/2/items?pageSize=100',
      {
        fixture: 'goods-items.json'
      }
    ).as('consignment2Items');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/0/items?pageSize=100',
      {
        fixture: 'goods-items.json'
      }
    ).as('consignment0Items');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/1/items',
      {
        fixture: 'goods-items.json'
      }
    ).as('consignment1Items');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/2?fields=allowedSections',
      {
        fixture: 'house-consignment-info.json',
        headers: { etag: getUniqueEtag() }
      }
    ).as('consignment2');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/0',
      {
        fixture: 'house-consignment-info.json',
        headers: { etag: getUniqueEtag() }
      }
    ).as('consignment0');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/1',
      {
        fixture: 'house-consignment-info.json',
        headers: { etag: getUniqueEtag() }
      }
    ).as('consignment1');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/2',
      {
        fixture: 'house-consignment-info.json',
        headers: { etag: getUniqueEtag() }
      }
    ).as('cons2');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/2/items/12?fields=allowedSections',
      {
        fixture: 'master-consignment-items.json',
        headers: { etag: getUniqueEtag() }
      }
    ).as('cons1Item12');
    cy.intercept(
      'PUT',
      '/api/v1/temporaryStorageDeclarations/1/consignments/2/items/12',
      {
        statusCode: 200,
        headers: { etag: getUniqueEtag() }
      }
    ).as('cons0ItemPut');
  }
);
Then('I see the No ENS data found error message', () => {
  page.getErrorMessage().should('contain', dataNotFoundError);
});

Given(
  'Prepare New declaration mock test data when there is no EORI data provided',
  () => {
    cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1', {
      fixture: 'tsd-declaration.json',
      headers: { etag: getUniqueEtag() }
    }).as('generalInfo');
    cy.fixture('codelist.json').then((data) => {
      cy.intercept('/assets/codelist/codelist.json', data).as('codeList');
    });
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments?fields=draftErrors&pageSize=100',
      {
        fixture: 'houseList.json'
      }
    ).as('consignments');

    cy.intercept('POST', '/api/v1/temporaryStorageDeclarations/1/validate', {
      fixture: 'tsd-declaration_no_eori_data.json',
      statusCode: 400
    }).as('validate');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/2/items?pageSize=100',
      {
        fixture: 'goods-items.json'
      }
    ).as('consignment2Items');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/0/items?pageSize=100',
      {
        fixture: 'goods-items.json'
      }
    ).as('consignment0Items');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/1/items',
      {
        fixture: 'goods-items.json'
      }
    ).as('consignment1Items');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/2?fields=allowedSections',
      {
        fixture: 'house-consignment-info.json',
        headers: { etag: getUniqueEtag() }
      }
    ).as('consignment2');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/0',
      {
        fixture: 'house-consignment-info.json',
        headers: { etag: getUniqueEtag() }
      }
    ).as('consignment0');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/1',
      {
        fixture: 'house-consignment-info.json',
        headers: { etag: getUniqueEtag() }
      }
    ).as('consignment1');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/2',
      {
        fixture: 'house-consignment-info.json',
        headers: { etag: getUniqueEtag() }
      }
    ).as('cons2');

    cy.intercept(
      'GET',

      '/api/v1/temporaryStorageDeclarations/1/consignments/2/items/12?fields=allowedSections',
      {
        fixture: 'master-consignment-items.json',
        headers: { etag: getUniqueEtag() }
      }
    ).as('cons1Item12');
    cy.intercept(
      'PUT',
      '/api/v1/temporaryStorageDeclarations/1/consignments/2/items/12',
      {
        statusCode: 200,
        headers: { etag: getUniqueEtag() }
      }
    ).as('cons0ItemPut');
  }
);
Then('I see the missing EORI data error message', () => {
  page.getErrorMessage().should('contain', eoriError);
});

Given(
  'Prepare New declaration mock test data when invalid data is provided',
  () => {
    cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1', {
      fixture: 'tsd-declaration.json',
      headers: { etag: getUniqueEtag() }
    }).as('generalInfo');
    cy.fixture('codelist.json').then((data) => {
      cy.intercept('/assets/codelist/codelist.json', data).as('codeList');
    });
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments?fields=draftErrors&pageSize=100',
      {
        fixture: 'houseList.json'
      }
    ).as('consignments');

    cy.intercept('POST', '/api/v1/temporaryStorageDeclarations/1/validate', {
      fixture: 'tsd-declaration_invalid_data.json',
      statusCode: 400,
      failOnStatusCode: false
    }).as('validate');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/2/items?pageSize=100',
      {
        fixture: 'goods-items.json'
      }
    ).as('consignment2Items');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/0/items?pageSize=100',
      {
        fixture: 'goods-items.json'
      }
    ).as('consignment0Items');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/1/items',
      {
        fixture: 'goods-items.json'
      }
    ).as('consignment1Items');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/2?fields=allowedSections',
      {
        fixture: 'house-consignment-info.json',
        headers: { etag: getUniqueEtag() }
      }
    ).as('consignment2');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/0',
      {
        fixture: 'house-consignment-info.json',
        headers: { etag: getUniqueEtag() }
      }
    ).as('consignment0');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/1',
      {
        fixture: 'house-consignment-info.json',
        headers: { etag: getUniqueEtag() }
      }
    ).as('consignment1');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/2',
      {
        fixture: 'house-consignment-info.json',
        headers: { etag: getUniqueEtag() }
      }
    ).as('cons2');
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/2/items/11?fields=allowedSections',
      {
        fixture: 'master-consignment-items.json',
        headers: { etag: getUniqueEtag() }
      }
    ).as('cons1Item11');
    cy.intercept(
      'GET',

      '/api/v1/temporaryStorageDeclarations/1/consignments/2/items/12?fields=allowedSections',
      {
        fixture: 'master-consignment-items.json',
        headers: { etag: getUniqueEtag() }
      }
    ).as('cons1Item12');
    cy.intercept(
      'PUT',
      '/api/v1/temporaryStorageDeclarations/1/consignments/2/items/12',
      {
        statusCode: 200,
        headers: { etag: getUniqueEtag() }
      }
    ).as('cons0ItemPut');
  }
);
Given(
  'Prepare New declaration mock test data when invalid or missing data is provided',
  () => {
    cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1', {
      fixture: 'tsd-declaration.json',
      headers: { etag: getUniqueEtag() }
    }).as('generalInfo');
    cy.fixture('codelist.json').then((data) => {
      cy.intercept('/assets/codelist/codelist.json', data).as('codeList');
    });
    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments?fields=draftErrors&pageSize=100',
      {
        fixture: 'houseList.json'
      }
    ).as('consignments');

    cy.intercept('POST', '/api/v1/temporaryStorageDeclarations/1/validate', {
      fixture: 'tsd-declaration_no_ens_data1.json',
      statusCode: 400,
      failOnStatusCode: false
    }).as('validate');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/2/items?pageSize=100',
      {
        fixture: 'goods-items.json'
      }
    ).as('consignment2Items');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/0/items?pageSize=100',
      {
        fixture: 'goods-items.json'
      }
    ).as('consignment0Items');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/1/items',
      {
        fixture: 'goods-items.json'
      }
    ).as('consignment1Items');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/2?fields=allowedSections',
      {
        fixture: 'house-consignment-info.json',
        headers: { etag: getUniqueEtag() }
      }
    ).as('consignment2');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/0',
      {
        fixture: 'house-consignment-info.json',
        headers: { etag: getUniqueEtag() }
      }
    ).as('consignment0');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/1',
      {
        fixture: 'house-consignment-info.json',
        headers: { etag: getUniqueEtag() }
      }
    ).as('consignment1');

    cy.intercept(
      'GET',
      '/api/v1/temporaryStorageDeclarations/1/consignments/2',
      {
        fixture: 'house-consignment-info.json',
        headers: { etag: getUniqueEtag() }
      }
    ).as('cons2');

    cy.intercept(
      'GET',

      '/api/v1/temporaryStorageDeclarations/1/consignments/2/items/12?fields=allowedSections',
      {
        fixture: 'master-consignment-items.json',
        headers: { etag: getUniqueEtag() }
      }
    ).as('cons1Item12');
    cy.intercept(
      'PUT',
      '/api/v1/temporaryStorageDeclarations/1/consignments/2/items/12',
      {
        statusCode: 200,
        headers: { etag: getUniqueEtag() }
      }
    ).as('cons0ItemPut');
  }
);
Then('I see the invalid data error message', () => {
  page.getErrorMessage().should('contain', missingDataError);
});
Then('I click on create new button on the error dialog', () => {
  page.getCreateNewButton().click();
});
Then('I moved to the question wizard page', () => {
  page.isQuestionWizardPageVisible();
});
Then('I click on cancel button on the error dialog', () => {
  page.getCancelButton().click();
});
Then('I see Confirm and Cancel button on the overview page', () => {
  page.getConfirmButton().should('be.visible');
  page.getCancelBtn().should('be.visible');
});

Then('I click on the confirm button', () => {
  page.getConfirmButton().click();
});

Given('Prepare New declaration mock test data success', () => {
  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1', {
    fixture: 'tsd-declaration.json',
    headers: { etag: getUniqueEtag() }
  }).as('generalInfo');
  cy.fixture('codelist.json').then((data) => {
    cy.intercept('/assets/codelist/codelist.json', data).as('codeList');
  });
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments?fields=draftErrors&pageSize=100',
    {
      fixture: 'houseList.json'
    }
  ).as('consignments');

  cy.intercept('POST', '/api/v1/temporaryStorageDeclarations/1/validate', {
    statusCode: 200
  }).as('validate');
  cy.intercept('POST', '/api/v1/temporaryStorageDeclarations/1/submit', {
    statusCode: 200
  }).as('submit');

  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/2/items?pageSize=100',
    {
      fixture: 'goods-items.json'
    }
  ).as('consignment2Items');

  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/0/items?pageSize=100',
    {
      fixture: 'goods-items.json'
    }
  ).as('consignment0Items');

  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/1/items?pageSize=100',
    {
      fixture: 'goods-items.json'
    }
  ).as('consignment1Items');

  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/2?fields=allowedSections',
    {
      fixture: 'house-consignment-info.json',
      headers: { etag: getUniqueEtag() }
    }
  ).as('consignment2');

  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1/consignments/0', {
    fixture: 'house-consignment-info.json',
    headers: { etag: getUniqueEtag() }
  }).as('consignment0');

  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1/consignments/1', {
    fixture: 'house-consignment-info.json',
    headers: { etag: getUniqueEtag() }
  }).as('consignment1');

  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1/consignments/2', {
    fixture: 'house-consignment-info.json',
    headers: { etag: getUniqueEtag() }
  }).as('cons2');

  cy.intercept(
    'GET',

    '/api/v1/temporaryStorageDeclarations/1/consignments/2/items/12?fields=allowedSections',
    {
      fixture: 'master-consignment-items.json',
      headers: { etag: getUniqueEtag() }
    }
  ).as('cons1Item12');
  cy.intercept(
    'PUT',
    '/api/v1/temporaryStorageDeclarations/1/consignments/2/items/12',
    {
      statusCode: 200,
      headers: { etag: getUniqueEtag() }
    }
  ).as('cons0ItemPut');
});
Given('Prepare New declaration mock test data failure', () => {
  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1', {
    fixture: 'tsd-declaration.json',
    headers: { etag: getUniqueEtag() }
  }).as('generalInfo');
  cy.fixture('codelist.json').then((data) => {
    cy.intercept('/assets/codelist/codelist.json', data).as('codeList');
  });
  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments?fields=draftErrors&pageSize=100',
    {
      fixture: 'houseList.json'
    }
  ).as('consignments');
  cy.intercept('POST', '/api/v1/temporaryStorageDeclarations/1/validate', {
    statusCode: 200
  }).as('validate');
  cy.intercept('POST', '/api/v1/temporaryStorageDeclarations/1/submit', {
    fixture: 'tsd-declaration_submission_failed.json',
    statusCode: 400
  }).as('submit');

  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/2/items?pageSize=100',
    {
      fixture: 'goods-items.json'
    }
  ).as('consignment2Items');

  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/0/items?pageSize=100',
    {
      fixture: 'goods-items.json'
    }
  ).as('consignment0Items');

  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/1/items?pageSize=100',
    {
      fixture: 'goods-items.json'
    }
  ).as('consignment1Items');

  cy.intercept(
    'GET',
    '/api/v1/temporaryStorageDeclarations/1/consignments/2?fields=allowedSections',
    {
      fixture: 'house-consignment-info.json',
      headers: { etag: getUniqueEtag() }
    }
  ).as('consignment2');

  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1/consignments/0', {
    fixture: 'house-consignment-info.json',
    headers: { etag: getUniqueEtag() }
  }).as('consignment0');

  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1/consignments/1', {
    fixture: 'house-consignment-info.json',
    headers: { etag: getUniqueEtag() }
  }).as('consignment1');

  cy.intercept('GET', '/api/v1/temporaryStorageDeclarations/1/consignments/2', {
    fixture: 'house-consignment-info.json',
    headers: { etag: getUniqueEtag() }
  }).as('cons2');

  cy.intercept(
    'GET',

    '/api/v1/temporaryStorageDeclarations/1/consignments/2/items/12?fields=allowedSections',
    {
      fixture: 'master-consignment-items.json',
      headers: { etag: getUniqueEtag() }
    }
  ).as('cons1Item12');
  cy.intercept(
    'PUT',
    '/api/v1/temporaryStorageDeclarations/1/consignments/2/items/12',
    {
      statusCode: 200,
      headers: { etag: getUniqueEtag() }
    }
  ).as('cons0ItemPut');
});

And('the submit button and stepper are disabled', () => {
  page.getSubmitButton().should('be.disabled');
  page.getStepper().should('contain.class', 'mat-vertical-stepper-disabled');
});
