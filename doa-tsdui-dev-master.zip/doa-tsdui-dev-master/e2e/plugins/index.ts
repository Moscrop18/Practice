import browserify from '@cypress/browserify-preprocessor';
const cucumber = require('cypress-cucumber-preprocessor').default;
import resolve from 'resolve';

module.exports = (on, config) => {
  const options = {
    ...browserify.defaultOptions,
    typescript: resolve.sync('typescript', { baseDir: config.projectRoot })
  };

  require('cypress-terminal-report/src/installLogsPrinter')(on, {
    printLogsToConsole: 'onFail'
  });
  on('file:preprocessor', cucumber(options));
  on('task', {
    log(message) {
      console.log(message);

      return null;
    },
    table(message) {
      console.table(message);

      return null;
    }
  });
  return config;
};
