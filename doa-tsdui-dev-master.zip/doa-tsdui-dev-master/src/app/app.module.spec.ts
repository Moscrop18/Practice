/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/*eslint-disable @typescript-eslint/no-unsafe-call */
import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ROOT_REDUCERS, metaReducers } from '@core/root-store/root.reducer';
import { StoreModule } from '@ngrx/store';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { from, Observable } from 'rxjs';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

export class LazyTranslateLoader implements TranslateLoader {
  getTranslation(lang: string): Observable<any> {
    return from(import(`../assets/i18n/${lang}.json`));
  }
}
let component: AppComponent;
let fixture: ComponentFixture<AppComponent>;
describe('AppModule', () => {
  beforeEach(
    waitForAsync(() => {
      void TestBed.configureTestingModule({
        imports: [
          AppRoutingModule,
          RouterTestingModule,
          StoreModule.forRoot(ROOT_REDUCERS, {
            metaReducers,
            runtimeChecks: {
              strictStateImmutability: true,
              strictActionImmutability: true,
              strictStateSerializability: true,
              strictActionSerializability: true
            }
          }),
          TranslateModule.forRoot({
            loader: {
              provide: TranslateLoader,
              useClass: LazyTranslateLoader,
              deps: [HttpClient]
            }
          }),
          HttpClientTestingModule
        ],
        declarations: [AppComponent]
      });
    })
  );
  beforeEach(() => {
    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
