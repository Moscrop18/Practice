/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import { registerLocaleData } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import localeDe from '@angular/common/locales/de';
import localeEn from '@angular/common/locales/en';
import localeFr from '@angular/common/locales/fr';
import localeNl from '@angular/common/locales/nl';
import { APP_INITIALIZER, NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { BrowserModule } from '@angular/platform-browser';
import {
  BrowserAnimationsModule,
  NoopAnimationsModule
} from '@angular/platform-browser/animations';
import { AuthEffects } from '@core/components/auth/store/effects/auth.effects';
import { SettingEffects } from '@core/components/settings/store/effects/settings.effects';
// CoreModule must only be imported in AppModule, not anywhere else.
import { CoreModule } from '@core/core.module';
import { metaReducers, ROOT_REDUCERS } from '@core/root-store/root.reducer';
import { MergedRouterStateSerializer } from '@core/root-store/utils';
import { ConfigService } from '@core/services/config/config.service';
import { environment } from '@environments/environment';
import { EffectsModule } from '@ngrx/effects';
import {
  RouterStateSerializer,
  StoreRouterConnectingModule
} from '@ngrx/router-store';
import { StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { CommonEffects } from '@shared/feature-store/common-store/effects/common.effects';
import { Observable, from } from 'rxjs';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

registerLocaleData(localeDe, 'de');
registerLocaleData(localeEn, 'en');
registerLocaleData(localeFr, 'fr');
registerLocaleData(localeNl, 'nl');

declare const window: any;
// TODO when using angular 12 https://dev.to/this-is-angular/disabling-angular-animations-at-runtime-9a6
// export function disableAnimations(): boolean {
//   return window.Cypress != null;
// }
// Load translation files from assets/i18n/{lang}.json
export class LazyTranslateLoader implements TranslateLoader {
  getTranslation(lang: string): Observable<any> {
    return from(import(`../assets/i18n/${lang}.json`));
  }
}
@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    environment.disableAnimations
      ? NoopAnimationsModule
      : BrowserAnimationsModule,
    AppRoutingModule,
    FlexLayoutModule,
    CoreModule,
    HttpClientModule,
    TranslateModule.forRoot({
      defaultLanguage: 'en',
      loader: {
        provide: TranslateLoader,
        useClass: LazyTranslateLoader,
        deps: [HttpClient]
      }
    }),
    StoreModule.forRoot(ROOT_REDUCERS, {
      metaReducers,
      runtimeChecks: {
        strictStateImmutability: true,
        strictActionImmutability: true,
        strictStateSerializability: true,
        strictActionSerializability: true
      }
    }),
    StoreRouterConnectingModule.forRoot(),
    EffectsModule.forRoot([AuthEffects, SettingEffects, CommonEffects]),
    !environment.production
      ? StoreDevtoolsModule.instrument({
          maxAge: 25 // Retains last 25 states
        })
      : []
  ],
  providers: [
    {
      provide: APP_INITIALIZER,
      useFactory: loadConfigFactory,
      deps: [ConfigService],
      multi: true
    },
    { provide: RouterStateSerializer, useClass: MergedRouterStateSerializer }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}

export function loadConfigFactory(configService: ConfigService) {
  return () => configService.loadConfig().toPromise();
}
