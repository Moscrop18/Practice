/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import {
  ComponentFixture,
  fakeAsync,
  TestBed,
  tick
} from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { CodeListService } from '@core/gateways/codelist/service/code-list.service';
import { CodeListEffects } from '@core/gateways/codelist/store/effects/code-list.effects';
import { ROOT_REDUCERS } from '@core/root-store/root.reducer';
import { ConfigService } from '@core/services/config/config.service';
import { EditDeclarationModule } from '@features/edit-declaration/edit-declaration.module';
import { EditDeclarationFacade } from '@features/edit-declaration/services';
import { ConsignmentGenInfoService } from '@features/edit-declaration/services/consignment-gen-info.service';
import { ConsultGeneralInformation } from '@features/manage-declaration/models/consult-general-information';
import { MaterialModule } from '@material/material.module';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { ConsInfoEffects } from '@shared/feature-store/consignment/effects/cons-info.effects';
import { SharedModule } from '@shared/shared.module';
import { cacheTestingModule } from 'ng-cache-testing-module';
import { NgrxFormsModule } from 'ngrx-forms';
import { Observable, of } from 'rxjs';
import { itemsListInformation } from 'src/assets/mocks/cons-info-items-list';
import { masConsInformation } from 'src/assets/mocks/cons-info.mock';
import { genInfoMockData } from 'src/assets/mocks/gen-info-mock';
import { itemsInformation } from 'src/assets/mocks/items-info.mock';

import { ConGenInfoEffects } from '../../store/effects/consignment-gen-info.effects';
import { conGenInfoReducer } from '../../store/reducers/consignment-gen-info.reducer';

import { ConsignmentGenInfoComponent } from './consignment-gen-info.component';

describe('ConsignmentGenInfoComponent', () => {
  cacheTestingModule();
  let component: ConsignmentGenInfoComponent;
  let fixture: ComponentFixture<ConsignmentGenInfoComponent>;
  let facade: EditDeclarationFacade;

  const translations: any = {
    'generalInfoForm.errors.requiredWithLength':
      'Please enter a valid LRN, consisting of maximum 22 characters.'
  };

  const genInfoData: ConsultGeneralInformation = {
    id: 2313413,
    self: 'http://localhost:8888/api/v1/temporaryStorageDeclarations/1',
    lrn: 'REF123456789000000000',
    mrn: '20BETP000000C3FLU4',
    crn: 'CRN21BETS00000000QIU0',
    current: true,
    ensReuseIndicator: 0,
    expirationTimestamp: '2021-04-01T16:50:42.999Z',
    type: 'Combined',
    status: 'PreLodged',
    consignmentType: 'House',
    consignmentItemType: 'House',
    linkedPnFrn: '20BEPN000000C3FLU8',
    registrationDate: '2021-04-01T15:49:42.999Z',
    declarationDate: '2021-04-28T15:50:42.999Z',
    dateAndTimeOfPresentationOfTheGoods: '2022-04-28T15:50:42.999Z',
    version: 2,
    draftErrors: 'All',
    supervisingCustomsOffice: {
      referenceNumber: 'BE212000'
    },
    personPresentingTheGoods: {
      identificationNumber: 'string',
      name: 'string',
      address: {
        streetAndNumber: 'River Road 12',
        country: 'BE',
        postCode: '1000',
        city: 'Brussel',
        poBox: '1234'
      },
      communication: [
        {
          identifier: 'info2@bpost.be',
          type: 'EM',
          fullName: 'Email contact'
        }
      ]
    },
    declarant: {
      identificationNumber: 'BE0214596464',
      name: 'REF1234567name1',
      address: {
        streetAndNumber: 'River Road 1234',
        country: 'AD',
        postCode: '1000',
        city: 'Brussel',
        poBox: '1234'
      },
      communication: [
        {
          identifier: 'info@bpost.be',
          type: 'EM',
          fullName: 'Email contact'
        },
        {
          identifier: '003222012345',
          type: 'TE',
          fullName: 'Telephone contact name'
        },
        {
          identifier: 'info1@bpost.be',
          type: 'EM',
          fullName: 'Email contact name'
        },
        {
          identifier: '003222012345',
          type: 'TE',
          fullName: 'Telephone contact name'
        }
      ]
    },
    representative: {
      identificationNumber: 'BE0214596464',
      name: 'REF1234567name1',
      status: 'Direct',
      address: {
        streetAndNumber: 'River Road 123',
        country: 'AE',
        postCode: '1000',
        city: 'Brussel',
        poBox: '1234'
      },
      communication: [
        {
          identifier: 'info@bpost.be',
          type: 'EM',
          fullName: 'Email contact name'
        }
      ]
    },
    consignmentHeader: {
      declaredLocationOfGoods: {
        typeOfLocation: 'D',
        qualifierOfIdentification: 'Y',
        unLoCode: 'BEZAVA00710',
        authorisationNumber: 'Ref1234',
        additionalIdentifier: 'Ref12345',
        gnss: {
          longitude: '50.85045',
          latitude: '4.34878'
        },
        economicOperator: {
          identificationNumber: 'XX0214596464'
        },
        address: {
          streetAndNumber: 'River Road 123',
          country: 'BE',
          postCode: '1000',
          city: 'Brussel',
          poBox: '1234'
        }
      },
      arrivalTransportMeans: {
        identificationNumber: 'IMO1924100',
        typeOfIdentification: '10'
      },
      warehouse: {
        identifier: 'REF123456789',
        type: 'V'
      },
      placeOfUnloading: {
        unLoCode: 'BEZAVA00710'
      },
      presentedLocationOfGoods: {
        typeOfLocation: 'string',
        qualifierOfIdentification: 'string',
        unLoCode: 'string',
        authorisationNumber: 'string',
        additionalIdentifier: 'string',
        customsOffice: {
          referenceNumber: 'string'
        },
        gnss: {
          longitude: 50.85045,
          latitude: 4.34878
        },
        economicOperator: {
          identificationNumber: 'string'
        },
        address: {
          postCode: 'string',
          city: 'string',
          streetAndNumber: 'string',
          country: 'string'
        }
      },
      carrier: {
        identificationNumber: 'string',
        name: 'string'
      }
    },
    amendmentRequest: {
      registrationDate: '2019-08-24T14:15:22Z',
      status: 'Accepted'
    },
    _links: {
      amend:
        'http://localhost:8888/api/v1/temporaryStorageDeclarations/1/amend',
      draftAmendment:
        'http://localhost:8888/api/v1/temporaryStorageDeclarations/1',
      invalidate:
        'http://localhost:8888/api/v1/temporaryStorageDeclarations/1/invalidate',
      consignments:
        'http://localhost:8888/api/v1/temporaryStorageDeclarations/1/consignments'
    }
  };
  class MockLoader implements TranslateLoader {
    getTranslation(lang: string): Observable<any> {
      return of({ translations });
    }
  }
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [],
      imports: [
        CommonModule,
        SharedModule,
        EditDeclarationModule,
        NgrxFormsModule,
        RouterTestingModule,
        MaterialModule,
        StoreModule.forRoot(conGenInfoReducer, {
          runtimeChecks: {
            strictStateImmutability: true,
            strictActionImmutability: true
          }
        }),
        StoreModule.forRoot(ROOT_REDUCERS, {
          runtimeChecks: {
            strictStateImmutability: true,
            strictActionImmutability: true,
            strictStateSerializability: true,
            strictActionSerializability: true
          }
        }),
        HttpClientModule,
        MaterialModule,
        EffectsModule.forRoot([
          CodeListEffects,
          ConGenInfoEffects,
          ConsInfoEffects
        ]),
        NoopAnimationsModule,
        TranslateModule.forRoot({
          loader: { provide: TranslateLoader, useClass: MockLoader }
        })
      ],
      providers: [
        EditDeclarationFacade,
        CodeListService,
        ConsignmentGenInfoService,
        ConfigService
      ]
    });
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsignmentGenInfoComponent);
    facade = TestBed.inject(EditDeclarationFacade);
    component = fixture.componentInstance;
    component.allowedSections = [
      'PreviousDocument',
      'TransportEquipment',
      'SupportingDocument',
      'AdditionalInformation',
      'AddditionalSupplyChainActor'
    ];
    jest
      .spyOn(facade, 'fetchConsInfo')
      .mockImplementation(() => of(masConsInformation));
    jest
      .spyOn(facade, 'fetchItemsListData')
      .mockImplementation(() => of(itemsListInformation));
    jest
      .spyOn(facade, 'fetchConsItemInfo')
      .mockImplementation(() => of(itemsInformation));
    fixture.detectChanges();
    jest.spyOn(facade, 'getCodeLists').mockImplementation(() =>
      of({
        addressedCustomsOfficeCodeState: {
          ids: [0],
          entities: {
            0: {
              id: 0,
              definition: '',
              value: ''
            }
          }
        },
        arrivalTransportTypeCodeState: {
          ids: [0],
          entities: {
            0: {
              id: 0,
              definition: '',
              value: ''
            }
          }
        },
        CL213CodeListState: {
          ids: [0],
          entities: {
            0: {
              id: 0,
              definition: '',
              value: ''
            }
          }
        },
        CL380CodeListState: {
          ids: [0],
          entities: {
            0: {
              id: 0,
              definition: '',
              value: ''
            }
          }
        },
        countryCodeState: {
          ids: [0],
          entities: {
            0: {
              id: 0,
              definition: '',
              value: ''
            }
          }
        },
        countryDataLevelCodeState: {
          ids: [0],
          entities: {
            0: {
              id: 0,
              definition: '',
              value: ''
            }
          }
        },
        locationTypeCodeCombinedState: {
          ids: [0],
          entities: {
            0: {
              id: 0,
              definition: '',
              value: ''
            }
          }
        },
        locationTypeCodeState: {
          ids: [0],
          entities: {
            0: {
              id: 0,
              definition: '',
              value: ''
            }
          }
        },
        placeOfUnloadingCodeState: {
          ids: [0],
          entities: {
            0: {
              id: 0,
              definition: '',
              value: ''
            }
          }
        },
        qualifierCodeState: {
          ids: [0],
          entities: {
            0: {
              id: 0,
              definition: '',
              value: ''
            }
          }
        },
        warehouseCodeState: {
          ids: [0],
          entities: {
            0: {
              id: 0,
              definition: '',
              value: ''
            }
          }
        }
      })
    );
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('service should be created', () => {
    expect(facade).toBeTruthy();
  });
  it('should handleDeclarationConsignmentSubscription', fakeAsync(() => {
    jest
      .spyOn(facade, 'fetchGeneralInformationData')
      .mockImplementation(() => of(genInfoMockData));
    fixture.detectChanges();
    component.consultGenInfodata$ = facade.fetchGeneralInformationData();
    component.consignmentInfo$ = facade.fetchConsInfo();
    component.handleDeclarationConsignmentSubscription();
    tick();
    fixture.detectChanges();
    tick();
    expect(component.typeOfTSD).toBe(genInfoMockData.type);
  }));
  it('should handleDeclarationConsignmentSubscription with isOnlyHouseConsignmentType', fakeAsync(() => {
    jest
      .spyOn(facade, 'fetchGeneralInformationData')
      .mockImplementation(() => of(genInfoMockData));
    fixture.detectChanges();
    component.consultGenInfodata$ = facade.fetchGeneralInformationData();
    component.consignmentInfo$ = facade.fetchConsInfo();
    component.handleDeclarationConsignmentSubscription();
    tick();
    fixture.detectChanges();
    tick();
    expect(component.isOnlyHouseConsignmentType).toBeFalsy();
  }));
  it('should test  isOnlyHouseConsignmentType to be true ', fakeAsync(() => {
    jest
      .spyOn(facade, 'fetchGeneralInformationData')
      .mockImplementation(() => of(genInfoData));
    fixture.detectChanges();
    component.consultGenInfodata$ = facade.fetchGeneralInformationData();
    component.consignmentInfo$ = facade.fetchConsInfo();
    component.handleDeclarationConsignmentSubscription();
    tick();
    fixture.detectChanges();
    tick();
    expect(component.isOnlyHouseConsignmentType).toBeTruthy();
  }));
  it('should call removePreviousDocumentGroupElement', () => {
    const spy = jest.spyOn(facade, 'removePreviousDocumentGroupElement');
    component.removePrevDocGrpElement('element');
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call addPrevDocGrpElement', () => {
    const spy = jest.spyOn(facade, 'addPreviousDocumentGroupElement');
    component.addPrevDocGrpElement({ name: '', value: '' });
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call addAddRefGrpElement', () => {
    const spy = jest.spyOn(facade, 'addAdditionalReferencesGroupElement');
    component.addAddRefGrpElement();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call removeAddrefElement', () => {
    const spy = jest.spyOn(facade, 'removeAdditionalReferencesGroupElement');
    component.removeAddrefElement({ element: 1 });
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call removeAddrefAllElement', () => {
    const spy = jest.spyOn(facade, 'removeAllAdditionalReferencesGroupElement');
    component.removeAddrefAllElement();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call deleteHouseConsignment', () => {
    const spy = jest.spyOn(facade, 'dispatchDeleteConsignmentAction');
    component.deleteHouseConsignment(1);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should call addRefNumberUcrGrpElement', () => {
    const spy = jest.spyOn(facade, 'addReferenceNumberUCRGroupElement');
    component.addRefNumberUcrGrpElement('element');
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should call removeRefNumberUcrGrpElement', () => {
    const spy = jest.spyOn(facade, 'removeReferenceNumberUCRGroupElement');
    component.removeRefNumberUcrGrpElement('element');
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should call addSealIdentifierGrpElement', () => {
    const spy = jest.spyOn(facade, 'addSealIdentifierGroupElement');
    component.addSealIdentifierGrpElement(0);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should call removeSealIdentifierGrpElement', () => {
    const spy = jest.spyOn(facade, 'removeSealIdentifierGroupElement');
    component.removeSealIdentifierGrpElement({
      index: 0,
      sealIdentifierIndex: 0
    });
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should call disableSealIdentifierGrpElement', () => {
    const spy = jest.spyOn(facade, 'disableSealIdentifierGroupElement');
    component.disableSealIdentifierGrpElement();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should call addTranEquipGrpElement', () => {
    const spy = jest.spyOn(facade, 'addTransportEquipmentGroupElement');
    component.addTranEquipGrpElement();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should call removeTranEquipGrpElement', () => {
    const spy = jest.spyOn(facade, 'removeTransportEquipmentGroupElement');
    component.removeTranEquipGrpElement(0);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should call removeTranEquipAllGrpElement', () => {
    const spy = jest.spyOn(facade, 'removeTransportEquipmentAllGroupElement');
    component.removeTranEquipAllGrpElement();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should call addRecepGrpElement', () => {
    const spy = jest.spyOn(facade, 'addReceptaclesGroupElement');
    component.addRecepGrpElement();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should call removeRecepGrpElement', () => {
    const spy = jest.spyOn(facade, 'removeReceptaclesGroupElementAction');
    component.removeRecepGrpElement(0);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should call removeRecepAllGrpElement', () => {
    const spy = jest.spyOn(facade, 'removeReceptaclesAllGroupElementAction');
    component.removeRecepAllGrpElement();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should call addSupDocGrpElement', () => {
    const spy = jest.spyOn(facade, 'addSupportinDocumentGroupElement');
    component.addSupDocGrpElement();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should call removeSupDocGrpElement', () => {
    const spy = jest.spyOn(facade, 'removeSupportinDocumentGroupElement');
    component.removeSupDocGrpElement(0);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should call removeSupDocAllGrpElement', () => {
    const spy = jest.spyOn(facade, 'removeSupportinDocumentAllGroupElement');
    component.removeSupDocAllGrpElement();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call addAdditionalInfoGrpElement', () => {
    const spy = jest.spyOn(facade, 'addAdditionalInformationGroupElement');
    component.addAdditionalInfoGrpElement();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call removeAdditionalInfoGrpElement', () => {
    const spy = jest.spyOn(facade, 'removeAdditionalInformationGroupElement');
    component.removeAdditionalInfoGrpElement(1);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call removeAdditionalInfoAllGrpElement', () => {
    const spy = jest.spyOn(
      facade,
      'removeAdditionalInformationAllGroupElement'
    );
    component.removeAdditionalInfoAllGrpElement();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call addSuppChainActorGrpElement', () => {
    const spy = jest.spyOn(facade, 'addAdditionalSupplyChainActorGroupElement');
    component.addSuppChainActorGrpElement();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call removeSuppChainActorGrpElement', () => {
    const spy = jest.spyOn(
      facade,
      'removeAdditionalSupplyChainActorGroupElement'
    );
    component.removeSuppChainActorGrpElement(1);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call removeSuppChainActorAllGrpElement', () => {
    const spy = jest.spyOn(
      facade,
      'removeAdditionalSupplyChainActorAllGroupElement'
    );
    component.removeSuppChainActorAllGrpElement();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call eoriChange', () => {
    const spy = jest.spyOn(facade, 'validateEori');
    component.eoriChange({ eori: '', index: 1 });
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should test ngOnInit', fakeAsync(() => {
    jest
      .spyOn(facade, 'fetchGeneralInformationData')
      .mockImplementation(() => of(genInfoMockData));
    component.consultGenInfodata$ = facade.fetchGeneralInformationData();
    component.consignmentInfo$ = facade.fetchConsInfo();
    component.houseList$ = facade.fetchHouseListData();
    const updateConsignmentGenInfoSpy = jest.spyOn(
      facade,
      'updateConsignmentGenInfo'
    );
    const queryParams = {
      queryParams: {
        tsdId: '1',
        consNo: '1'
      },
      url: 'http://localhost:4200/edit-declaration/tsd/general-info'
    };
    jest
      .spyOn(facade, 'currentRouteParams', 'get')
      .mockImplementation(() => of(queryParams));
    component.ngOnInit();
    tick();
    fixture.detectChanges();
    expect(component.tsdId).toBe(1);
  }));
  it('should test validateSupportingDocument', () => {
    const spy = jest.spyOn(facade, 'validateSupportingDocument');
    component.validateSupportingDocument(true);
    expect(spy).toHaveBeenCalled();
  });
  it('should test validateAdditionalReferences', () => {
    const spy = jest.spyOn(facade, 'validateAdditionalReferences');
    component.validateAdditionalReferences(true);
    expect(spy).toHaveBeenCalled();
  });
});
