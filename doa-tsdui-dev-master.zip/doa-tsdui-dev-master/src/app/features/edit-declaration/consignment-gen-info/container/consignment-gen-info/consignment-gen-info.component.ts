/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-call */
import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { Codelist } from '@core/gateways/codelist/model/addressed-customs-office-code';
import { CodeListService } from '@core/gateways/codelist/service/code-list.service';
import { constants } from '@features/edit-declaration/edit-declaration.constants';
import {
  AddPrevDoc,
  ConsignmentGenInfoFormValue,
  EORIChange,
  RemoveSealIdentiFier
} from '@features/edit-declaration/models';
import { EditDeclarationFacade } from '@features/edit-declaration/services';
import { ConsignmentInformation } from '@features/manage-declaration/models/consignment-information';
import { ConsultGeneralInformation } from '@features/manage-declaration/models/consult-general-information';
import { HouseList } from '@features/manage-declaration/models/house-overview/house-list';
import { FormGroupState } from 'ngrx-forms';
import { combineLatest, Observable, Subscription } from 'rxjs';

@Component({
  selector: 'app-con-gen-info',
  templateUrl: './consignment-gen-info.component.html'
})
export class ConsignmentGenInfoComponent implements OnInit, OnDestroy {
  public formState$: Observable<FormGroupState<ConsignmentGenInfoFormValue>>;
  consignmentInfo$: Observable<ConsignmentInformation>;
  houseList$: Observable<HouseList>;
  consultGenInfodata$: Observable<ConsultGeneralInformation>;
  currentConsignment: ConsignmentInformation;
  public CL754Codelist: Codelist[];
  public CL709Codelist: Codelist[];
  public CL213Codelist: Codelist[];
  public CL704Codelist: Codelist[];
  public CL214PreCodelist: Codelist[];
  public CL214ComCodelist: Codelist[];
  public CL380Codelist: Codelist[];
  public ensReUse: boolean;
  public typeOfTSD: string;
  public consignmentType: string;
  public isOnlyHouseConsignmentType: boolean;
  public sequence: number;
  public tsdId: number;
  public allowedSections: string[];
  public routeSubscription: Subscription;
  public declarationConsignmentSubscription: Subscription;
  public tsdVersion: number;

  constructor(
    private editDeclarationFacade: EditDeclarationFacade,
    private codelistService: CodeListService,
    private ref: ChangeDetectorRef
  ) {
    this.formState$ = this.editDeclarationFacade.getConGenInfoFormState();
    this.consultGenInfodata$ = this.editDeclarationFacade.fetchGeneralInformationData();
    this.consignmentInfo$ = this.editDeclarationFacade.fetchConsInfo();
    this.houseList$ = this.editDeclarationFacade.fetchHouseListData();
    this.handleDeclarationConsignmentSubscription();
  }
  ngOnDestroy(): void {
    this.routeSubscription?.unsubscribe();
    this.declarationConsignmentSubscription?.unsubscribe();
  }

  ngOnInit(): void {
    this.ref.detectChanges();
    this.routeSubscription = this.editDeclarationFacade.currentRouteParams.subscribe(
      (route) => {
        this.tsdId = parseInt(route.queryParams.tsdId);
        this.sequence = parseInt(route.queryParams.consNo);
        this.consignmentType =
          this.sequence === 0 ? constants.MASTER : constants.HOUSE;
      }
    );
    this.codelistService.getCL745CodeList().subscribe((codelist) => {
      this.CL754Codelist = codelist;
    });
    this.codelistService.getCL214PrelodgedCodeList().subscribe((codelist) => {
      this.CL214PreCodelist = codelist;
    });
    this.codelistService.getCL214CombinedCodeList().subscribe((codelist) => {
      this.CL214ComCodelist = codelist;
    });
    this.codelistService.getCL709CodeList().subscribe((codelist) => {
      this.CL709Codelist = codelist;
    });
    this.codelistService.getCL213CodeList().subscribe((codelist) => {
      this.CL213Codelist = codelist;
    });
    this.codelistService.getCL704CodeList().subscribe((codelist) => {
      this.CL704Codelist = codelist;
    });
    this.codelistService.getCL380CodeList().subscribe((codelist) => {
      this.CL380Codelist = codelist;
    });
  }
  handleDeclarationConsignmentSubscription(): void {
    this.declarationConsignmentSubscription = combineLatest([
      this.consultGenInfodata$,
      this.consignmentInfo$
    ]).subscribe((results) => {
      if (results[0] && results[1]) {
        this.typeOfTSD = results[0].type;
        this.isOnlyHouseConsignmentType = results[0]?.consignmentType?.includes(
          'Master'
        )
          ? false
          : true;
        this.ensReUse = results[0].ensReuseIndicator.toString() === '1';
        this.allowedSections = results[1].allowedSections;
      }
    });
  }
  addPrevDocGrpElement(prevDoc: AddPrevDoc) {
    this.editDeclarationFacade.addPreviousDocumentGroupElement(prevDoc);
  }
  removePrevDocGrpElement(element: string) {
    this.editDeclarationFacade.removePreviousDocumentGroupElement(element);
  }
  addRefNumberUcrGrpElement(element: string) {
    this.editDeclarationFacade.addReferenceNumberUCRGroupElement(element);
  }
  removeRefNumberUcrGrpElement(element: string) {
    this.editDeclarationFacade.removeReferenceNumberUCRGroupElement(element);
  }
  addSealIdentifierGrpElement(i: number) {
    this.editDeclarationFacade.addSealIdentifierGroupElement(i);
  }
  removeSealIdentifierGrpElement(e: RemoveSealIdentiFier) {
    this.editDeclarationFacade.removeSealIdentifierGroupElement(
      e.index,
      e.sealIdentifierIndex
    );
  }
  disableSealIdentifierGrpElement() {
    this.editDeclarationFacade.disableSealIdentifierGroupElement();
  }
  addTranEquipGrpElement() {
    this.editDeclarationFacade.addTransportEquipmentGroupElement();
  }
  removeTranEquipGrpElement(i: number) {
    this.editDeclarationFacade.removeTransportEquipmentGroupElement(i);
  }
  removeTranEquipAllGrpElement() {
    this.editDeclarationFacade.removeTransportEquipmentAllGroupElement();
  }
  addRecepGrpElement() {
    this.editDeclarationFacade.addReceptaclesGroupElement();
  }
  removeRecepGrpElement(i: number) {
    this.editDeclarationFacade.removeReceptaclesGroupElementAction(i);
  }
  removeRecepAllGrpElement() {
    this.editDeclarationFacade.removeReceptaclesAllGroupElementAction();
  }
  addSupDocGrpElement() {
    this.editDeclarationFacade.addSupportinDocumentGroupElement();
  }
  removeSupDocGrpElement(i: number) {
    this.editDeclarationFacade.removeSupportinDocumentGroupElement(i);
  }
  removeSupDocAllGrpElement() {
    this.editDeclarationFacade.removeSupportinDocumentAllGroupElement();
  }
  addAdditionalInfoGrpElement() {
    this.editDeclarationFacade.addAdditionalInformationGroupElement();
  }
  removeAdditionalInfoGrpElement(i: number) {
    this.editDeclarationFacade.removeAdditionalInformationGroupElement(i);
  }
  removeAdditionalInfoAllGrpElement() {
    this.editDeclarationFacade.removeAdditionalInformationAllGroupElement();
  }
  addSuppChainActorGrpElement() {
    this.editDeclarationFacade.addAdditionalSupplyChainActorGroupElement();
  }
  removeSuppChainActorGrpElement(i: number) {
    this.editDeclarationFacade.removeAdditionalSupplyChainActorGroupElement(i);
  }
  removeSuppChainActorAllGrpElement() {
    this.editDeclarationFacade.removeAdditionalSupplyChainActorAllGroupElement();
  }
  eoriChange(event: EORIChange) {
    this.editDeclarationFacade.validateEori(event.eori, event.index);
  }
  addAddRefGrpElement() {
    this.editDeclarationFacade.addAdditionalReferencesGroupElement();
  }
  removeAddrefElement(event: { element: number }) {
    this.editDeclarationFacade.removeAdditionalReferencesGroupElement(
      event.element
    );
  }
  removeAddrefAllElement() {
    this.editDeclarationFacade.removeAllAdditionalReferencesGroupElement();
  }

  deleteHouseConsignment(seq: number): void {
    this.editDeclarationFacade.dispatchDeleteConsignmentAction(
      {
        tsdId: this.tsdId
      },
      seq
    );
  }
  validateSupportingDocument(event) {
    this.editDeclarationFacade.validateSupportingDocument(event);
  }
  validateAdditionalReferences(event) {
    this.editDeclarationFacade.validateAdditionalReferences(event);
  }
  validateSupportingDocumentReferenceNumber(event) {
    this.editDeclarationFacade.validateSupportingDocumentReferenceNumber(event);
  }
}
