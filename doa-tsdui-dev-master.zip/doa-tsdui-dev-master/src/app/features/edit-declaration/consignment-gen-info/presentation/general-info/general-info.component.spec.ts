import { HttpClientModule } from '@angular/common/http';
import { DebugElement } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { CodeListEffects } from '@core/gateways/codelist/store/effects/code-list.effects';
import { ConfigService } from '@core/services/config/config.service';
import { EditDeclarationModule } from '@features/edit-declaration/edit-declaration.module';
import { ConsignmentGenInfoFormValue } from '@features/edit-declaration/models';
import { MaterialModule } from '@material/material.module';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { TranslateModule } from '@ngx-translate/core';
import { ConsInfoEffects } from '@shared/feature-store/consignment/effects/cons-info.effects';
import { SharedModule } from '@shared/shared.module';
import { createFormGroupState } from 'ngrx-forms';

import { ConGenInfoEffects } from '../../store/effects/consignment-gen-info.effects';
import { conGenInfoReducer } from '../../store/reducers/consignment-gen-info.reducer';

import { GeneralInfoComponent } from './general-info.component';

describe('GeneralInfoComponent', () => {
  let component: GeneralInfoComponent;
  let fixture: ComponentFixture<GeneralInfoComponent>;
  let rootElement: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [],
      imports: [
        SharedModule,
        MaterialModule,
        NoopAnimationsModule,
        EditDeclarationModule,
        RouterTestingModule,
        TranslateModule.forRoot(),
        StoreModule.forRoot(conGenInfoReducer, {
          runtimeChecks: {
            strictStateImmutability: true,
            strictActionImmutability: true
          }
        }),
        EffectsModule.forRoot([
          CodeListEffects,
          ConGenInfoEffects,
          ConsInfoEffects
        ]),
        HttpClientModule
      ],
      providers: [ConfigService]
    });
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GeneralInfoComponent);
    component = fixture.componentInstance;
    const INITIAL_STATE = createFormGroupState<ConsignmentGenInfoFormValue>(
      'conGenInfo',
      {
        transportDocument: {
          type: '',
          referenceNumber: ''
        },
        weight: {
          weight: null
        },
        previousDocument: {},
        referenceNumberUCR: {},
        transportEquipments: [],
        receptacles: [],
        supportingDocuments: [],
        additionalInformations: [],
        additionalSupplyChainActors: []
      }
    );
    component.formState = INITIAL_STATE;
    component.CL754Codelist = [];
    component.CL709Codelist = [];
    component.CL213Codelist = [];
    component.CL704Codelist = [];
    component.CL214PreCodelist = [];
    component.CL214ComCodelist = [];
    component.ensReUse = true;
    component.typeOfTSD = 'prelodged';
    component.consignmentType = 'house';
    component.isOnlyHouseConsignmentType = false;
    component.allowedSections = [
      'PreviousDocument',
      'TransportEquipment',
      'SupportingDocument',
      'AdditionalInformation',
      'AddditionalSupplyChainActor'
    ];
    rootElement = fixture.debugElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should test removePrevDocGrpElement', () => {
    const spy = jest.spyOn(component.removePrevDocGrpElementAction, 'emit');
    component.removePrevDocGrpElement('');
    expect(spy).toHaveBeenCalled();
  });
  it('should test isSectionVisible', () => {
    component.ensReUse = false;
    component.allowedSections = ['TransportEquipment'];
    const result = component.isSectionVisible('TransportEquipment');
    expect(result).toBeTruthy();
  });
  it('should test addRefNumberUcrGrpElement', () => {
    const spy = jest.spyOn(component.addRefNumberUcrGrpElementAction, 'emit');
    component.addRefNumberUcrGrpElement('');
    expect(spy).toHaveBeenCalled();
  });
  it('should test removeRefNumberUcrGrpElement', () => {
    const spy = jest.spyOn(
      component.removeRefNumberUcrGrpElementAction,
      'emit'
    );
    component.removeRefNumberUcrGrpElement('');
    expect(spy).toHaveBeenCalled();
  });
  it('should call addAddrefElement', () => {
    const spy = jest.spyOn(component.addAddrefElementAction, 'emit');
    component.addAddrefElement();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call removeAddrefElement', () => {
    const spy = jest.spyOn(component.removeAddrefElementAction, 'emit');
    component.removeAddrefElement('');
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call removeAddrefAllElement', () => {
    const spy = jest.spyOn(component.removeAddrefAllElementAction, 'emit');
    component.removeAddrefAllElement('');
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should test addSealIdentifierGrpElement', () => {
    const spy = jest.spyOn(component.addSealIdentifierGrpElementAction, 'emit');
    component.addSealIdentifierGrpElement(1);
    expect(spy).toHaveBeenCalled();
  });
  it('should test removeSealIdentifierGrpElement', () => {
    const spy = jest.spyOn(
      component.removeSealIdentifierGrpElementAction,
      'emit'
    );
    component.removeSealIdentifierGrpElement({});
    expect(spy).toHaveBeenCalled();
  });
  it('should test disableSealIdentifierGrpElement', () => {
    const spy = jest.spyOn(
      component.disableSealIdentifierGrpElementAction,
      'emit'
    );
    component.disableSealIdentifierGrpElement();
    expect(spy).toHaveBeenCalled();
  });
  it('should test addTranEquipGrpElement', () => {
    const spy = jest.spyOn(component.addTranEquipGrpElementAction, 'emit');
    component.addTranEquipGrpElement();
    expect(spy).toHaveBeenCalled();
  });
  it('should test removeTranEquipGrpElement', () => {
    const spy = jest.spyOn(component.removeTranEquipGrpElementAction, 'emit');
    component.removeTranEquipGrpElement(1);
    expect(spy).toHaveBeenCalled();
  });
  it('should test removeTranEquipAllGrpElement', () => {
    const spy = jest.spyOn(
      component.removeTranEquipAllGrpElementAction,
      'emit'
    );
    component.removeTranEquipAllGrpElement();
    expect(spy).toHaveBeenCalled();
  });
  it('should test addRecepGrpElement', () => {
    const spy = jest.spyOn(component.addRecepGrpElementAction, 'emit');
    component.addRecepGrpElement();
    expect(spy).toHaveBeenCalled();
  });
  it('should test removeRecepGrpElement', () => {
    const spy = jest.spyOn(component.removeRecepGrpElementAction, 'emit');
    component.removeRecepGrpElement(1);
    expect(spy).toHaveBeenCalled();
  });
  it('should test removeRecepAllGrpElement', () => {
    const spy = jest.spyOn(component.removeRecepAllGrpElementAction, 'emit');
    component.removeRecepAllGrpElement();
    expect(spy).toHaveBeenCalled();
  });
  it('should test addSupDocGrpElement', () => {
    const spy = jest.spyOn(component.addSupDocGrpElementAction, 'emit');
    component.addSupDocGrpElement();
    expect(spy).toHaveBeenCalled();
  });
  it('should test removeSupDocGrpElement', () => {
    const spy = jest.spyOn(component.removeSupDocGrpElementAction, 'emit');
    component.removeSupDocGrpElement(1);
    expect(spy).toHaveBeenCalled();
  });
  it('should test removeSupDocAllGrpElement', () => {
    const spy = jest.spyOn(component.removeSupDocAllGrpElementAction, 'emit');
    component.removeSupDocAllGrpElement();
    expect(spy).toHaveBeenCalled();
  });
  it('should test addAdditionalInfoGrpElement', () => {
    const spy = jest.spyOn(component.addAdditionalInfoGrpElementAction, 'emit');
    component.addAdditionalInfoGrpElement();
    expect(spy).toHaveBeenCalled();
  });
  it('should test removeAdditionalInfoGrpElement', () => {
    const spy = jest.spyOn(
      component.removeAdditionalInfoGrpElementAction,
      'emit'
    );
    component.removeAdditionalInfoGrpElement(1);
    expect(spy).toHaveBeenCalled();
  });
  it('should test removeAdditionalInfoAllGrpElement', () => {
    const spy = jest.spyOn(
      component.removeAdditionalInfoAllGrpElementAction,
      'emit'
    );
    component.removeAdditionalInfoAllGrpElement();
    expect(spy).toHaveBeenCalled();
  });
  it('should test addSuppChainActorGrpElement', () => {
    const spy = jest.spyOn(component.addSuppChainActorGrpElementAction, 'emit');
    component.addSuppChainActorGrpElement();
    expect(spy).toHaveBeenCalled();
  });
  it('should test removeSuppChainActorGrpElement', () => {
    const spy = jest.spyOn(
      component.removeSuppChainActorGrpElementAction,
      'emit'
    );
    component.removeSuppChainActorGrpElement(1);
    expect(spy).toHaveBeenCalled();
  });
  it('should test removeSuppChainActorAllGrpElement', () => {
    const spy = jest.spyOn(
      component.removeSuppChainActorAllGrpElementAction,
      'emit'
    );
    component.removeSuppChainActorAllGrpElement();
    expect(spy).toHaveBeenCalled();
  });
  it('should test eoriChange', () => {
    const spy = jest.spyOn(component.eoriChangeAction, 'emit');
    component.eoriChange({});
    expect(spy).toHaveBeenCalled();
  });
  it('should test deleteHouseConsignment', () => {
    const spy = jest.spyOn(component.deleteHouseConsignmentAction, 'emit');
    component.deleteHouseConsignment();
    expect(spy).toHaveBeenCalled();
  });

  it('should test isOnlyHouseConsignmentType', () => {
    expect(component.isOnlyHouseConsignmentType).toBeFalsy();
  });
});
