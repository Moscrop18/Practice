/* eslint-disable @typescript-eslint/no-unsafe-argument */
import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  EventEmitter,
  Input,
  OnChanges,
  Output,
  SimpleChanges
} from '@angular/core';
import { Codelist } from '@core/gateways/codelist/model/addressed-customs-office-code';
import {
  AddPrevDoc,
  ConsignmentGenInfoFormValue,
  EORIChange,
  RemoveSealIdentiFier
} from '@features/edit-declaration/models';
import { FormGroupState } from 'ngrx-forms';

@Component({
  selector: 'app-general-info',
  templateUrl: './general-info.component.html',
  styleUrls: ['./general-info.component.scss']
})
export class GeneralInfoComponent implements OnChanges, AfterViewInit {
  @Input() formState: FormGroupState<ConsignmentGenInfoFormValue>;
  @Input() CL754Codelist: Codelist[];
  @Input() CL709Codelist: Codelist[];
  @Input() CL213Codelist: Codelist[];
  @Input() CL704Codelist: Codelist[];
  @Input() CL214PreCodelist: Codelist[];
  @Input() CL214ComCodelist: Codelist[];
  @Input() CL380Codelist: Codelist[];
  @Input() ensReUse: boolean;
  @Input() typeOfTSD: string;
  @Input() tsdVersion: number;
  @Input() consignmentType: string;
  @Input() isOnlyHouseConsignmentType: boolean;
  @Input() sequence: number;
  @Input() allowedSections: string[];

  @Output() addPrevDocGrpElementAction = new EventEmitter<AddPrevDoc>();
  @Output() removePrevDocGrpElementAction = new EventEmitter<string>();
  @Output() addRefNumberUcrGrpElementAction = new EventEmitter<string>();
  @Output() removeRefNumberUcrGrpElementAction = new EventEmitter<string>();
  @Output() addSealIdentifierGrpElementAction = new EventEmitter<number>();
  @Output()
  removeSealIdentifierGrpElementAction = new EventEmitter<RemoveSealIdentiFier>();
  @Output() disableSealIdentifierGrpElementAction = new EventEmitter();
  @Output() addTranEquipGrpElementAction = new EventEmitter();
  @Output() removeTranEquipGrpElementAction = new EventEmitter<number>();
  @Output() removeTranEquipAllGrpElementAction = new EventEmitter();
  @Output() addRecepGrpElementAction = new EventEmitter();
  @Output() removeRecepGrpElementAction = new EventEmitter<number>();
  @Output() removeRecepAllGrpElementAction = new EventEmitter();
  @Output() addSupDocGrpElementAction = new EventEmitter();
  @Output() removeSupDocGrpElementAction = new EventEmitter<number>();
  @Output() removeSupDocAllGrpElementAction = new EventEmitter();
  @Output() addAdditionalInfoGrpElementAction = new EventEmitter();
  @Output() removeAdditionalInfoGrpElementAction = new EventEmitter<number>();
  @Output() removeAdditionalInfoAllGrpElementAction = new EventEmitter();
  @Output() addSuppChainActorGrpElementAction = new EventEmitter();
  @Output() removeSuppChainActorGrpElementAction = new EventEmitter<number>();
  @Output() removeSuppChainActorAllGrpElementAction = new EventEmitter();
  @Output() eoriChangeAction = new EventEmitter<EORIChange>();
  @Output() deleteHouseConsignmentAction = new EventEmitter<number>();
  @Output() removeAddrefElementAction = new EventEmitter<{
    element: string;
  }>();
  @Output() removeAddrefAllElementAction = new EventEmitter<{
    element: string;
  }>();
  @Output() addAddrefElementAction = new EventEmitter();
  @Output() validateSupportingDocumentEvent = new EventEmitter<string>();
  @Output() validateAdditionalReferencesEvent = new EventEmitter<any>();
  @Output()
  validateSupportingDocumentReferenceNumberEvent = new EventEmitter<string>();

  constructor(private ref: ChangeDetectorRef) {}
  ngOnChanges(changes: SimpleChanges): void {
    this.ref.detectChanges();
  }
  ngAfterViewInit() {
    this.ref.detectChanges();
  }
  isSectionVisible(sectionName: string): boolean {
    return (
      !this.ensReUse &&
      this.allowedSections &&
      this.allowedSections.includes(sectionName)
    );
  }
  addPrevDocGrpElement(prevDoc: AddPrevDoc): void {
    this.addPrevDocGrpElementAction.emit(prevDoc);
  }
  removePrevDocGrpElement(element: string): void {
    this.removePrevDocGrpElementAction.emit(element);
  }
  addRefNumberUcrGrpElement(element: string): void {
    this.addRefNumberUcrGrpElementAction.emit(element);
  }
  removeRefNumberUcrGrpElement(element: string): void {
    this.removeRefNumberUcrGrpElementAction.emit(element);
  }
  addSealIdentifierGrpElement(i: number): void {
    this.addSealIdentifierGrpElementAction.emit(i);
  }
  removeSealIdentifierGrpElement(e: RemoveSealIdentiFier): void {
    this.removeSealIdentifierGrpElementAction.emit(e);
  }
  disableSealIdentifierGrpElement(): void {
    this.disableSealIdentifierGrpElementAction.emit();
  }
  addTranEquipGrpElement(): void {
    this.addTranEquipGrpElementAction.emit();
  }
  removeTranEquipGrpElement(i: number): void {
    this.removeTranEquipGrpElementAction.emit(i);
  }
  removeTranEquipAllGrpElement(): void {
    this.removeTranEquipAllGrpElementAction.emit();
  }
  addRecepGrpElement(): void {
    this.addRecepGrpElementAction.emit();
  }
  removeRecepGrpElement(i: number): void {
    this.removeRecepGrpElementAction.emit(i);
  }
  removeRecepAllGrpElement(): void {
    this.removeRecepAllGrpElementAction.emit();
  }
  addSupDocGrpElement(): void {
    this.addSupDocGrpElementAction.emit();
  }
  removeSupDocGrpElement(i: number): void {
    this.removeSupDocGrpElementAction.emit(i);
  }
  removeSupDocAllGrpElement(): void {
    this.removeSupDocAllGrpElementAction.emit();
  }
  addAdditionalInfoGrpElement(): void {
    this.addAdditionalInfoGrpElementAction.emit();
  }
  removeAdditionalInfoGrpElement(i: number): void {
    this.removeAdditionalInfoGrpElementAction.emit(i);
  }
  removeAdditionalInfoAllGrpElement(): void {
    this.removeAdditionalInfoAllGrpElementAction.emit();
  }
  addSuppChainActorGrpElement(): void {
    this.addSuppChainActorGrpElementAction.emit();
  }
  removeSuppChainActorGrpElement(i: number): void {
    this.removeSuppChainActorGrpElementAction.emit(i);
  }
  removeSuppChainActorAllGrpElement(): void {
    this.removeSuppChainActorAllGrpElementAction.emit();
  }
  eoriChange(event: EORIChange): void {
    this.eoriChangeAction.emit(event);
  }
  removeAddrefAllElement(element: string) {
    this.removeAddrefAllElementAction.emit({
      element: element
    });
  }
  addAddrefElement() {
    this.addAddrefElementAction.emit();
  }
  removeAddrefElement(element: string) {
    this.removeAddrefElementAction.emit({
      element: element
    });
  }
  deleteHouseConsignment(): void {
    this.deleteHouseConsignmentAction.emit(this.sequence);
  }
  validateSupportingDocument(event: any): void {
    this.validateSupportingDocumentEvent.emit(event);
  }
  validateAdditionalReferences(event: any): void {
    this.validateAdditionalReferencesEvent.emit(event);
  }
  validateSupportingDocumentReferenceNumber(event: any): void {
    this.validateSupportingDocumentReferenceNumberEvent.emit(event);
  }
}
