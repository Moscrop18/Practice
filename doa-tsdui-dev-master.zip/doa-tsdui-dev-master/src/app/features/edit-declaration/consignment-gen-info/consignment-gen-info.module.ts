import { NgModule } from '@angular/core';
import { MaterialModule } from '@material/material.module';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { ConsInfoEffects } from '@shared/feature-store/consignment/effects/cons-info.effects';
import { consInfoReducer } from '@shared/feature-store/consignment/reducer/cons-info.reducer';
import { SharedModule } from '@shared/shared.module';
import { NgrxFormsModule } from 'ngrx-forms';

import { EditDeclarationSharedModule } from '../edit-declaration-shared/edit-declaration-shared.module';

import { ConsignmentGenInfoComponent } from './container/consignment-gen-info/consignment-gen-info.component';
import { GeneralInfoComponent } from './presentation/general-info/general-info.component';
import { ConGenInfoEffects } from './store/effects/consignment-gen-info.effects';
import { conGenInfoReducer } from './store/reducers/consignment-gen-info.reducer';

@NgModule({
  declarations: [ConsignmentGenInfoComponent, GeneralInfoComponent],
  imports: [
    SharedModule,
    NgrxFormsModule,
    MaterialModule,
    EditDeclarationSharedModule,
    EffectsModule.forFeature([ConGenInfoEffects, ConsInfoEffects]),
    StoreModule.forFeature('conGenInfo', conGenInfoReducer),
    StoreModule.forFeature('consInfoKey', consInfoReducer)
  ]
})
export class ConsignmentGenInfoModule {}
