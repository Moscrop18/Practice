/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-floating-promises */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable sonarjs/max-switch-cases */

import { AdditionalReferences } from '@features/edit-declaration/models';
import { validateAutoCompleteSelection } from '@features/edit-declaration/validation-functions/auto-complete-validation-functions';
import { Action, combineReducers } from '@ngrx/store';
import { consignmentGenInfoFormDirtyAction } from '@shared/feature-store/common-store/actions/common.actions';
import { resetConsignmentForm } from '@shared/feature-store/consignment/actions/cons-info.actions';
import {
  addArrayControl,
  createFormGroupState,
  disable,
  enable,
  formGroupReducer,
  FormGroupState,
  markAsPristine,
  markAsTouched,
  markAsUntouched,
  removeArrayControl,
  setValue,
  updateArray,
  updateArrayWithFilter,
  updateGroup,
  validate
} from 'ngrx-forms';
import { required } from 'ngrx-forms/validation';

import {
  AdditionalSupplyChainActor,
  ConsignmentGenInfoFormValue,
  PreviousDocument,
  Receptacle,
  ReferenceNumberUCR,
  SealIdentifier,
  SupportingDocument,
  TransportDocument,
  TransportEquipment,
  Weight
} from '../../../models/consignment-gen-info';
import * as actions from '../actions/consignment-gen-info.actions';
import { updateConsignmentGenInfoForm } from '../actions/consignment-gen-info.actions';

export interface State {
  conGenInfo: {
    formState: FormGroupState<ConsignmentGenInfoFormValue>;
  };
}
export const FORM_ID = 'conGenInfo';
export const INITIAL_STATE = createFormGroupState<ConsignmentGenInfoFormValue>(
  FORM_ID,
  {
    transportDocument: {
      type: '',
      referenceNumber: ''
    },
    weight: {
      weight: ''
    },
    previousDocument: {},
    referenceNumberUCR: {},
    transportEquipments: [],
    receptacles: [],
    supportingDocuments: [],
    additionalInformations: [],
    additionalReferences: [],
    additionalSupplyChainActors: []
  }
);

export const validationFormGroupReducer = updateGroup<ConsignmentGenInfoFormValue>(
  {
    transportDocument: (state, parentState) => {
      return updateGroup<TransportDocument>(state, {
        type: validate(required),
        referenceNumber: validate([required])
      });
    },
    weight: (state, parentState) => {
      return updateGroup<Weight>(state, {
        weight: validate([required, validateGreaterThan(0)])
      });
    },
    previousDocument: (state, parentState) => {
      return updateGroup<PreviousDocument>(state, {
        type: validate(required),
        referenceNumber: validate([required])
      });
    },
    referenceNumberUCR: (state, parentState) => {
      return updateGroup<ReferenceNumberUCR>(state, {
        referenceNumberUCR: validate([required])
      });
    },
    transportEquipments: (te, parent) => {
      return updateArray<TransportEquipment>(
        te,
        updateGroup<TransportEquipment>({
          containerIdentificationNumber: validate([
            required,
            validateFormat(11)
          ]),
          numberOfSeals: validate([validateGreaterThan(0)]),
          seal: (si, p) => {
            if (
              !p.controls.numberOfSeals ||
              !p.controls.numberOfSeals.value ||
              p.controls.numberOfSeals.value === null ||
              p.controls.numberOfSeals.value.toString() === ''
            ) {
              if (si.isEnabled) {
                si = markAsUntouched(si);
                return disable(si);
              }
            } else {
              if (si.isDisabled) {
                si = markAsUntouched(si);
                return enable(si);
              }
            }
            return updateArray<SealIdentifier>(
              si,
              updateGroup<SealIdentifier>({})
            );
          }
        })
      );
    },
    receptacles: (s, p) => {
      return updateArray<Receptacle>(
        s,
        updateGroup<Receptacle>({
          identificationNumber: validate([required])
        })
      );
    },
    additionalSupplyChainActors: (s, p) => {
      return updateArray<AdditionalSupplyChainActor>(
        s,
        updateGroup<AdditionalSupplyChainActor>({
          role: validate([required])
        })
      );
    }
  }
);
export function formStateReducer(s = INITIAL_STATE, a: any = {}) {
  s = formGroupReducer(s, a);
  if (a.type !== actions.dispatchCosnGenInfoFormTouchedAction.type) {
    if (a.type === actions.DisablePreviousDocumentAction.type) {
      return updateGroup<ConsignmentGenInfoFormValue>({
        previousDocument: (state) => {
          return updateGroup<PreviousDocument>({
            type: (type) => {
              return disable(type);
            },
            referenceNumber: (referenceNumber) => {
              return disable(referenceNumber);
            },
            goodsItemIdentifier: (goodsItemIdentifier) => {
              return disable(goodsItemIdentifier);
            }
          })(state);
        }
      })(s);
    } else if (a.type === actions.DisableTransportDocumentAction.type) {
      return updateGroup<ConsignmentGenInfoFormValue>({
        transportDocument: (state) => {
          return updateGroup<TransportDocument>({
            type: (type) => {
              return disable(type);
            },
            referenceNumber: (referenceNumber) => {
              return disable(referenceNumber);
            }
          })(state);
        }
      })(s);
    } else if (a.type === resetConsignmentForm) {
      return INITIAL_STATE;
    }
    switch (a.type) {
      case consignmentGenInfoFormDirtyAction.type:
        return markAsPristine(s);
      case actions.InitializeStateAction.type:
        return updateGroup<ConsignmentGenInfoFormValue>({})(INITIAL_STATE);
      case actions.AddPreviousDocumentGroupElementAction.type:
        return updateGroup<ConsignmentGenInfoFormValue>({
          previousDocument: (group) => {
            const newValue = { ...group.value, [a.name]: a.value };
            return setValue(group, newValue);
          }
        })(s);
      case actions.RemovePreviousDocumentGroupElementAction.type:
        return updateGroup<ConsignmentGenInfoFormValue>({
          previousDocument: (group) => {
            const newValue = { ...group.value };
            delete newValue[a.name];
            return setValue(group, newValue);
          }
        })(s);
      case actions.AddReferenceNumberUCRGroupElementAction.type:
        return updateGroup<ConsignmentGenInfoFormValue>({
          referenceNumberUCR: (group) => {
            const newValue = { ...group.value, [a.name]: '' };
            return setValue(group, newValue);
          }
        })(s);
      case actions.AddAdditionalReferencesGroupElementAction.type:
        return updateGroup<ConsignmentGenInfoFormValue>({
          additionalReferences: (additionalReferences) => {
            const updatedArray = additionalReferences;
            return addArrayControl(updatedArray, {
              type: '',
              referenceNumber: ''
            });
          }
        })(s);
      case actions.RemoveAdditionalReferencesGroupElementAction.type:
        return updateGroup<ConsignmentGenInfoFormValue>({
          additionalReferences: (additionalReferences) => {
            const updatedArray = additionalReferences;
            return removeArrayControl(updatedArray, a.index);
          }
        })(s);
      case actions.RemoveAllAdditionalReferencesGroupElementAction.type:
        return updateGroup<ConsignmentGenInfoFormValue>({
          additionalReferences: (additionalReferences) => {
            return setValue(additionalReferences, []);
          }
        })(s);
      case actions.RemoveReferenceNumberUCRGroupElementAction.type:
        return updateGroup<ConsignmentGenInfoFormValue>({
          referenceNumberUCR: (referenceNumberUCR) => {
            const newValue = { ...referenceNumberUCR.value };
            delete newValue[a.name];
            return setValue(referenceNumberUCR, newValue);
          }
        })(s);
      case actions.AddReceptaclesGroupElementAction.type:
        return updateGroup<ConsignmentGenInfoFormValue>({
          receptacles: (receptacles) => {
            return addArrayControl(receptacles, { identificationNumber: '' });
          }
        })(s);

      case actions.RemoveReceptaclesGroupElementAction.type:
        return updateGroup<ConsignmentGenInfoFormValue>({
          receptacles: (receptacles) => {
            return removeArrayControl(receptacles, a.index);
          }
        })(s);

      case actions.RemoveReceptaclesAllGroupElementAction.type:
        return updateGroup<ConsignmentGenInfoFormValue>({
          receptacles: (receptacles) => {
            return setValue(receptacles, []);
          }
        })(s);
      case actions.AddTransportEquipmentsGroupElementAction.type:
        return updateGroup<ConsignmentGenInfoFormValue>({
          transportEquipments: (transportEquipments) => {
            return addArrayControl(transportEquipments, {
              containerIdentificationNumber: '',
              containerPackedStatus: '',
              numberOfSeals: null,
              seal: [
                {
                  identifier: ''
                }
              ]
            });
          }
        })(s);
      case actions.AddSealIdentifierGroupElementAction.type:
        return updateGroup<ConsignmentGenInfoFormValue>({
          transportEquipments: (tes, p) => {
            return updateArrayWithFilter<TransportEquipment>(
              (te, idx) => idx === a.index,
              updateGroup<TransportEquipment>({
                seal: (sealIdentifiers) => {
                  return addArrayControl(sealIdentifiers, { identifier: '' });
                }
              })
            )(tes);
          }
        })(s);
      case actions.RemoveSealIdentifierGroupElementAction.type:
        return updateGroup<ConsignmentGenInfoFormValue>({
          transportEquipments: (tes, p) => {
            return updateArrayWithFilter<TransportEquipment>(
              (te, idx) => idx === a.index,
              updateGroup<TransportEquipment>({
                seal: (sealIdentifiers) => {
                  return removeArrayControl(
                    sealIdentifiers,
                    a.sealIdentifierIndex
                  );
                }
              })
            )(tes);
          }
        })(s);
      case actions.DisableSealIdentifierGroupElementAction.type:
        return updateGroup<ConsignmentGenInfoFormValue>({
          transportEquipments: (tes, p) => {
            const lastIndex = tes.controls.length - 1;
            return updateArrayWithFilter<TransportEquipment>(
              (te, idx) => idx === lastIndex,
              updateGroup<TransportEquipment>({
                seal: (sealIdentifiers) => {
                  return disable(sealIdentifiers);
                }
              })
            )(tes);
          }
        })(s);
      case actions.RemoveTransportEquipmentsGroupElementAction.type:
        return updateGroup<ConsignmentGenInfoFormValue>({
          transportEquipments: (transportEquipments) => {
            return removeArrayControl(transportEquipments, a.index);
          }
        })(s);
      case actions.RemoveTransportEquipmentsAllGroupElementAction.type:
        return updateGroup<ConsignmentGenInfoFormValue>({
          transportEquipments: (transportEquipments) => {
            return setValue(transportEquipments, []);
          }
        })(s);
      case actions.AddSupportingDocumentsGroupElementAction.type:
        return updateGroup<ConsignmentGenInfoFormValue>({
          supportingDocuments: (supportingDocuments) => {
            return addArrayControl(supportingDocuments, {
              type: '',
              referenceNumber: ''
            });
          }
        })(s);
      case actions.RemoveSupportingDocumentsGroupElementAction.type:
        return updateGroup<ConsignmentGenInfoFormValue>({
          supportingDocuments: (supportingDocuments) => {
            return removeArrayControl(supportingDocuments, a.index);
          }
        })(s);
      case actions.RemoveSupportingDocumentsAllGroupElementAction.type:
        return updateGroup<ConsignmentGenInfoFormValue>({
          supportingDocuments: (supportingDocuments) => {
            return setValue(supportingDocuments, []);
          }
        })(s);
      case actions.AddAdditionalInformationGroupElementAction.type:
        return updateGroup<ConsignmentGenInfoFormValue>({
          additionalInformations: (additionalInformations) => {
            return addArrayControl(additionalInformations, {
              text: '',
              code: ''
            });
          }
        })(s);
      case actions.RemoveAdditionalInformationGroupElementAction.type:
        return updateGroup<ConsignmentGenInfoFormValue>({
          additionalInformations: (additionalInformations) => {
            return removeArrayControl(additionalInformations, a.index);
          }
        })(s);
      case actions.RemoveAdditionalInformationsAllGroupElementAction.type:
        return updateGroup<ConsignmentGenInfoFormValue>({
          additionalInformations: (additionalInformations) => {
            return setValue(additionalInformations, []);
          }
        })(s);
      case actions.AddAdditionalSupplyChainActorGroupElementAction.type:
        return updateGroup<ConsignmentGenInfoFormValue>({
          additionalSupplyChainActors: (additionalSupplyChainActors) => {
            return addArrayControl(additionalSupplyChainActors, {
              identificationNumber: '',
              name: '',
              role: ''
            });
          }
        })(s);
      case actions.RemoveAdditionalSupplyChainActorGroupElementAction.type:
        return updateGroup<ConsignmentGenInfoFormValue>({
          additionalSupplyChainActors: (additionalSupplyChainActors) => {
            return removeArrayControl(additionalSupplyChainActors, a.index);
          }
        })(s);
      case actions.RemoveAdditionalSupplyChainActorAllGroupElementAction.type:
        return updateGroup<ConsignmentGenInfoFormValue>({
          additionalSupplyChainActors: (additionalSupplyChainActors) => {
            return setValue(additionalSupplyChainActors, []);
          }
        })(s);
      case actions.ValidateEORIFailedAction.type:
        return updateGroup<ConsignmentGenInfoFormValue>({
          additionalSupplyChainActors: (sc, p) => {
            return updateArray<AdditionalSupplyChainActor>(
              sc,
              updateGroup<AdditionalSupplyChainActor>({
                identificationNumber: validate(validateEORI(a.isValid))
              }),
              updateGroup<AdditionalSupplyChainActor>({
                name: (name) => {
                  name = setValue<string>(name, '');
                  return name;
                }
              })
            );
          }
        })(s);
      case actions.FetchNameByEORISuccessAction.type:
        return updateGroup<ConsignmentGenInfoFormValue>({
          additionalSupplyChainActors: (asca, p) => {
            return updateArrayWithFilter<AdditionalSupplyChainActor>(
              (asc, idx) => idx === a.index,
              updateGroup<AdditionalSupplyChainActor>({
                name: (name) => {
                  name = setValue<string>(name, a.name);
                  return name;
                }
              }),
              updateGroup<AdditionalSupplyChainActor>({
                identificationNumber: validate(validateEORI(true))
              })
            )(asca);
          }
        })(s);
      case updateConsignmentGenInfoForm.type:
        return createFormGroupState<ConsignmentGenInfoFormValue>(
          FORM_ID,
          a.data
        );
      default:
        return getAction(a, s);
    }
  } else {
    return markAsTouched(s);
  }
}

function getAction(a, s) {
  switch (a.type) {
    case actions.validateAdditionalReferences.type:
      return updateGroup<ConsignmentGenInfoFormValue>({
        additionalReferences: (additionalReferences) => {
          return updateArrayWithFilter<AdditionalReferences>(
            (subDiv, idx) => idx === a.index,
            updateGroup<AdditionalReferences>({
              type: validate([
                required,
                validateAutoCompleteSelection(
                  a.selectedValue,
                  a.autoCompleteList
                )
              ])
            })
          )(additionalReferences);
        }
      })(s);
    case actions.validateSupportingDocument.type:
      return updateGroup<ConsignmentGenInfoFormValue>({
        supportingDocuments: (supportingDocuments) => {
          return updateArrayWithFilter<SupportingDocument>(
            (subDiv, idx) => idx === a.index,
            updateGroup<SupportingDocument>({
              type: validate([
                required,
                validateAutoCompleteSelection(
                  a.selectedValue,
                  a.autoCompleteList
                )
              ])
            })
          )(supportingDocuments);
        }
      })(s);
    case actions.validateSupportingDocumentReferenceNumber.type:
      return updateGroup<ConsignmentGenInfoFormValue>({
        supportingDocuments: (supportingDocuments) => {
          return updateArrayWithFilter<SupportingDocument>(
            (subDiv, idx) => idx === a.index,
            updateGroup<SupportingDocument>({
              referenceNumber: validate([required])
            })
          )(supportingDocuments);
        }
      })(s);
    default:
      return s;
  }
}

export interface MCInformationError {
  isMaxLengthExceeded?: boolean;
  isGreaterThan?: boolean;
  isInvalidReferenveNo?: boolean;
  isInvalidEORI?: boolean;
  isInvalidIdentifier?: boolean;
  isReuired?: boolean;
}
export function validateEORI<T>(
  isvalid: boolean
): (value: T | null) => MCInformationError {
  return (value: T | null): MCInformationError => {
    if (value.toString() === '') {
      return {
        isReuired: true
      };
    } else if (!isvalid) {
      return {
        isInvalidEORI: true
      };
    } else {
      return {};
    }
  };
}

export function validateGreaterThan<T>(
  size: number
): (value: T | null) => MCInformationError {
  return (value: T | null): MCInformationError => {
    if (
      value &&
      value !== null &&
      value.toString() !== '' &&
      parseInt(value.toString(), 10) <= size
    ) {
      return {
        isGreaterThan: true
      };
    }
    return {};
  };
}

export function validateFormat<T>(
  size: number
): (value: T | null) => MCInformationError {
  return (value: T | null): MCInformationError => {
    if (value.toString().length === 0 || value.toString() === '') {
      return {};
    }
    if (value.toString().length < size) {
      return {
        isInvalidIdentifier: true
      };
    }
    const firstFourChar = value.toString().substring(0, 4);
    const lastSevenChar = value.toString().substring(4, 12);
    if (
      /^[A-Za-z]+$/.exec(firstFourChar) !== null &&
      /^[0-9]+$/.exec(lastSevenChar) !== null
    ) {
      return {};
    } else {
      return {
        isInvalidIdentifier: true
      };
    }
  };
}
const reducers = combineReducers<State['conGenInfo'], any>({
  formState(s = INITIAL_STATE, a: any = {}) {
    return validationFormGroupReducer(formStateReducer(s, a));
  }
});

export function conGenInfoReducer(s: State['conGenInfo'], a: Action) {
  return reducers(s, a);
}
