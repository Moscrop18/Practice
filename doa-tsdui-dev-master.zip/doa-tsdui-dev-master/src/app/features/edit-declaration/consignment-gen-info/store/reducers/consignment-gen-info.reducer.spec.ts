import { TestBed } from '@angular/core/testing';
import { ConsignmentGenInfoFormValue } from '@features/edit-declaration/models';
import { StoreModule } from '@ngrx/store';
import {
  createFormGroupState,
  FormGroupState,
  formStateReducer,
  MarkAsTouchedAction
} from 'ngrx-forms';

import * as action from '../actions/consignment-gen-info.actions';

import * as reducer from './consignment-gen-info.reducer';

export interface ConGenInfodState {
  conGenInfo: {
    formState: FormGroupState<ConsignmentGenInfoFormValue>;
  };
}

describe('conGenInfoReducer', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [StoreModule.forFeature('conGenInfo', reducer.conGenInfoReducer)]
    });
  });
  it('should return the default state', () => {
    const { INITIAL_STATE } = reducer;
    const action = { type: '' };
    const state = reducer.conGenInfoReducer(
      { formState: INITIAL_STATE },
      action
    );

    const updatedGroupViaAction = formStateReducer(
      state.formState,
      new MarkAsTouchedAction(
        state.formState.controls.transportDocument.controls.referenceNumber.id
      )
    );
    state.formState = updatedGroupViaAction;
    expect(state.formState.controls.transportDocument.id).toBe(
      INITIAL_STATE.controls.transportDocument.id
    );
  });

  it('should add and remove referenceNumberUCR group element', () => {
    const { INITIAL_STATE } = reducer;
    const addAction = {
      type: action.AddReferenceNumberUCRGroupElementAction.type,
      name: 'referenceNumberUCR'
    };

    let state = reducer.conGenInfoReducer(
      { formState: INITIAL_STATE },
      addAction
    );

    expect(
      state.formState.controls.referenceNumberUCR.controls.referenceNumberUCR
    ).toBeDefined();

    const removeAction = {
      type: action.RemoveReferenceNumberUCRGroupElementAction.type,
      name: 'referenceNumberUCR'
    };
    state = reducer.conGenInfoReducer(
      { formState: INITIAL_STATE },
      removeAction
    );

    expect(
      state.formState.controls.referenceNumberUCR.controls.referenceNumberUCR
    ).toBeUndefined();
  });

  it('should add and remove previous document group element', () => {
    const { INITIAL_STATE } = reducer;
    const addAction = {
      type: action.AddPreviousDocumentGroupElementAction.type,
      name: 'type',
      value: ''
    };

    let state = reducer.conGenInfoReducer(
      { formState: INITIAL_STATE },
      addAction
    );

    expect(
      state.formState.controls.previousDocument.controls.type
    ).toBeDefined();

    const removeAction = {
      type: action.RemovePreviousDocumentGroupElementAction.type,
      name: 'type'
    };
    state = reducer.conGenInfoReducer(
      { formState: INITIAL_STATE },
      removeAction
    );

    expect(
      state.formState.controls.previousDocument.controls.type
    ).toBeUndefined();
  });

  it('should add and remove transport equipment element', () => {
    const { INITIAL_STATE } = reducer;
    const addAction = {
      type: action.AddTransportEquipmentsGroupElementAction.type
    };
    const removeAction = {
      type: action.RemoveTransportEquipmentsGroupElementAction.type,
      index: 0
    };

    const removeAllAction = {
      type: action.RemoveTransportEquipmentsAllGroupElementAction.type
    };

    const addSealAction = {
      type: action.AddSealIdentifierGroupElementAction.type,
      index: 0
    };
    const removeSealAction = {
      type: action.RemoveSealIdentifierGroupElementAction.type,
      index: 0,
      sealIdentifierIndex: 0
    };
    const disableSealAction = {
      type: action.DisableSealIdentifierGroupElementAction.type
    };

    let state = reducer.conGenInfoReducer(
      { formState: INITIAL_STATE },
      addAction
    );
    state = reducer.conGenInfoReducer(state, addAction);

    state = reducer.conGenInfoReducer(state, addSealAction);

    state = reducer.conGenInfoReducer(state, disableSealAction);

    state = reducer.conGenInfoReducer(state, removeSealAction);

    state = reducer.conGenInfoReducer(state, removeAction);

    state = reducer.conGenInfoReducer(state, removeAllAction);

    expect(
      state.formState.controls.transportEquipments.controls.length
    ).toEqual(0);
  });

  it('should add and remove receptacle element', () => {
    const { INITIAL_STATE } = reducer;
    const addAction = {
      type: action.AddReceptaclesGroupElementAction.type
    };
    const removeAction = {
      type: action.RemoveReceptaclesGroupElementAction.type,
      index: 0
    };

    const removeAllAction = {
      type: action.RemoveReceptaclesAllGroupElementAction.type
    };

    let state = reducer.conGenInfoReducer(
      { formState: INITIAL_STATE },
      addAction
    );
    state = reducer.conGenInfoReducer(state, addAction);

    state = reducer.conGenInfoReducer(state, removeAction);

    state = reducer.conGenInfoReducer(state, removeAllAction);

    expect(state.formState.controls.receptacles.controls.length).toEqual(0);
  });

  it('should add and remove supporting document element', () => {
    const { INITIAL_STATE } = reducer;
    const addAction = {
      type: action.AddSupportingDocumentsGroupElementAction.type
    };
    const removeAction = {
      type: action.RemoveSupportingDocumentsGroupElementAction.type,
      index: 0
    };

    const removeAllAction = {
      type: action.RemoveSupportingDocumentsAllGroupElementAction.type
    };

    let state = reducer.conGenInfoReducer(
      { formState: INITIAL_STATE },
      addAction
    );
    state = reducer.conGenInfoReducer(state, addAction);

    state = reducer.conGenInfoReducer(state, removeAction);

    state = reducer.conGenInfoReducer(state, removeAllAction);

    expect(
      state.formState.controls.supportingDocuments.controls.length
    ).toEqual(0);
  });

  it('should add and remove additional information element', () => {
    const { INITIAL_STATE } = reducer;
    const addAction = {
      type: action.AddAdditionalInformationGroupElementAction.type
    };
    const removeAction = {
      type: action.RemoveAdditionalInformationGroupElementAction.type,
      index: 0
    };

    const removeAllAction = {
      type: action.RemoveAdditionalInformationsAllGroupElementAction.type
    };

    let state = reducer.conGenInfoReducer(
      { formState: INITIAL_STATE },
      addAction
    );
    state = reducer.conGenInfoReducer(state, addAction);

    state = reducer.conGenInfoReducer(state, removeAction);

    state = reducer.conGenInfoReducer(state, removeAllAction);

    expect(
      state.formState.controls.additionalInformations.controls.length
    ).toEqual(0);
  });

  it('should add and remove additional supply chain actor element', () => {
    const { INITIAL_STATE } = reducer;
    const addAction = {
      type: action.AddAdditionalSupplyChainActorGroupElementAction.type
    };
    const removeAction = {
      type: action.RemoveAdditionalSupplyChainActorGroupElementAction.type,
      index: 0
    };

    const removeAllAction = {
      type: action.RemoveAdditionalSupplyChainActorAllGroupElementAction.type
    };

    const validateEORIAction = {
      type: action.ValidateEORIFailedAction.type,
      eori: 'invalid',
      isValid: false,
      index: 0
    };

    const fetchNameByEORIAction = {
      type: action.FetchNameByEORISuccessAction.type,
      name: 'samplename',
      index: 0
    };

    let state = reducer.conGenInfoReducer(
      { formState: INITIAL_STATE },
      addAction
    );
    state = reducer.conGenInfoReducer(state, addAction);

    state = reducer.conGenInfoReducer(state, validateEORIAction);

    state = reducer.conGenInfoReducer(state, fetchNameByEORIAction);

    state = reducer.conGenInfoReducer(state, removeAction);

    state = reducer.conGenInfoReducer(state, removeAllAction);

    expect(
      state.formState.controls.additionalSupplyChainActors.controls.length
    ).toEqual(0);
  });

  it('should execute validateAdditionalReferences', () => {
    const INIT_STATE = createFormGroupState<ConsignmentGenInfoFormValue>(
      'ITEM_INFO',
      {
        additionalReferences: [{ type: '', referenceNumber: '' }]
      }
    );
    const consItemaction = {
      type: action.validateAdditionalReferences.type,
      index: 0,
      selectedValue: 'AB',
      autoCompleteList: [
        'Y001 - Wholly obtained in Lebanon and transported directly from that country to the Community.'
      ]
    };
    const state = reducer.conGenInfoReducer(
      { formState: INIT_STATE },
      consItemaction
    );
    expect(
      state.formState.controls.additionalReferences.controls[0].controls.type
        .errors.isWrongSelection
    ).toBeTruthy();
  });
  it('should execute validateSupportingDocument', () => {
    const INIT_STATE = createFormGroupState<ConsignmentGenInfoFormValue>(
      'ITEM_INFO',
      {
        supportingDocuments: [{ type: '', referenceNumber: '' }]
      }
    );
    const consItemaction = {
      type: action.validateSupportingDocument.type,
      index: 0,
      selectedValue: 'AB',
      autoCompleteList: ['Some value']
    };
    const state = reducer.conGenInfoReducer(
      { formState: INIT_STATE },
      consItemaction
    );
    expect(
      state.formState.controls.supportingDocuments.controls[0].controls.type
        .errors.isWrongSelection
    ).toBeTruthy();
  });
});
