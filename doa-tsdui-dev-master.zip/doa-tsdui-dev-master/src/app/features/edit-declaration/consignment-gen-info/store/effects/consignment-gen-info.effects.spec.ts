/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable @typescript-eslint/require-await */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { HttpClient, HttpHandler } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ConfigService } from '@core/services/config/config.service';
import { ConsignmentGenInfoFormValue } from '@features/edit-declaration/models';
import { provideMockActions } from '@ngrx/effects/testing';
import { FormGroupState } from 'ngrx-forms';
import { ReplaySubject } from 'rxjs';

import {
  FetchNameByEORISuccessAction,
  ValidateEORIAction
} from '../actions/consignment-gen-info.actions';

import { ConGenInfoEffects } from './consignment-gen-info.effects';

export interface ConGenInfodState {
  conGenInfo: {
    formState: FormGroupState<ConsignmentGenInfoFormValue>;
  };
}

describe('conGenInfoEffect', () => {
  let actions: ReplaySubject<any>;
  let effects: ConGenInfoEffects;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [
        ConfigService,
        ConGenInfoEffects,
        provideMockActions(() => actions),
        HttpClient,
        HttpHandler
      ]
    });

    effects = TestBed.get(ConGenInfoEffects);
  });
  beforeEach(() => {
    jest.spyOn(console, 'error').mockImplementation(() => {});
  });
  it('should be created', async () => {
    expect(effects).toBeTruthy();
  });

  it('should validate eori', () => {
    actions = new ReplaySubject(1);
    const validateEORIAction = {
      type: ValidateEORIAction.type,
      eori: 'invalideori',
      index: 0
    };
    actions.next(validateEORIAction);
    effects.validateEori.subscribe((validation) => {
      expect(validation).toBeDefined();
    });
  });

  it('should fetch name by eori', () => {
    actions = new ReplaySubject(1);
    const fetchNameByEORIAction = {
      type: FetchNameByEORISuccessAction.type,
      name: 'samplename',
      index: 0
    };
    actions.next(fetchNameByEORIAction);
    effects.fetchEORIName.subscribe((name) => {
      expect(name).toBeDefined();
    });
  });
});
