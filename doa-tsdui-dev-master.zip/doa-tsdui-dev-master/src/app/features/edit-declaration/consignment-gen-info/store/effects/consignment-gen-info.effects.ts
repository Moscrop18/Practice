/* eslint-disable @typescript-eslint/no-misused-promises */
/* eslint-disable @typescript-eslint/no-floating-promises */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ConfigService } from '@core/services/config/config.service';
import { constants } from '@features/edit-declaration/edit-declaration.constants';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { CRSGateway } from '@shared/models/crs-gateway';
import { of } from 'rxjs';
import { catchError, concatMap, map, switchMap } from 'rxjs/operators';

import * as actions from '../actions/consignment-gen-info.actions';

@Injectable()
export class ConGenInfoEffects {
  private apiUrl: string;

  validateEori = createEffect((): any =>
    this.actions$.pipe(
      ofType(actions.ValidateEORIAction),
      concatMap((validateEORIAction) => {
        return this.httpService
          .get<CRSGateway>('../../../../assets/crs-mock/crs.json')
          .pipe(
            map((data) => {
              if (data.validEORINumbers.includes(validateEORIAction.eori)) {
                return actions.ValidateEORISuccessAction({
                  eori: validateEORIAction.eori,
                  isValid: true,
                  index: validateEORIAction.index
                });
              } else {
                return actions.ValidateEORIFailedAction({
                  eori: validateEORIAction.eori,
                  isValid: false,
                  index: validateEORIAction.index
                });
              }
            }),
            catchError((error) => {
              console.error(error);
              return of();
            })
          );
      })
    )
  );

  fetchEORIName = createEffect((): any =>
    this.actions$.pipe(
      ofType(actions.ValidateEORISuccessAction),
      switchMap((validateEORISuccessAction) => {
        return this.httpService
          .get('../../../../assets/crs-mock/eori-mock.json')
          .pipe(
            map((data) => {
              return actions.FetchNameByEORISuccessAction({
                name:
                  data[constants.VALID_EORI_NUMBERS][
                    validateEORISuccessAction.eori
                  ].name,
                index: validateEORISuccessAction.index
              });
            }),
            catchError((error) => {
              console.error(error);
              return of();
            })
          );
      })
    )
  );
  constructor(
    private actions$: Actions,
    private httpService: HttpClient,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private configService: ConfigService
  ) {
    this.apiUrl = String(configService.getConfig().apiUrl);
  }
}
