import { ConsignmentGenInfoFormValue } from '@features/edit-declaration/models';
import { createAction, props } from '@ngrx/store';

export const SetSubmittedValueAction = createAction(
  'masterConGenInfo/SET_SUBMITTED_VALUE',
  props<{ submittedValue: ConsignmentGenInfoFormValue }>()
);
export const updateConsignmentGenInfoForm = createAction(
  'masterConGenInfo/UPDATE_CONSIGNMENT_GEN_INFO_FORM',
  props<{ data: ConsignmentGenInfoFormValue }>()
);
export const dispatchCosnGenInfoFormTouchedAction = createAction(
  'masterConGenInfo/Cons Gen Info Form Touch Action'
);
export const AddAdditionalReferencesGroupElementAction = createAction(
  'conGenInfo/ADD_ADDITIONAL_REF'
);
export const RemoveAllAdditionalReferencesGroupElementAction = createAction(
  'conGenInfo/REMOVE_ALL_ADDITIONAL_REF'
);

export const RemoveAdditionalReferencesGroupElementAction = createAction(
  'conGenInfo/REMOVE_ADDITIONAL_REF',
  props<{ index: number }>()
);
export const InitializeStateAction = createAction(
  'masterConGenInfo/INITIALIZE_STATE'
);
export const AddPreviousDocumentGroupElementAction = createAction(
  'masterConGenInfo/CREATE_PREVIOUS_DOCUMENT_GROUP_ELEMENT',
  props<{ name: string; value: string }>()
);
export const RemovePreviousDocumentGroupElementAction = createAction(
  'masterConGenInfo/REMOVE_PREVIOUS_DOCUMENT_GROUP_ELEMENT',
  props<{ name: string }>()
);
export const AddReferenceNumberUCRGroupElementAction = createAction(
  'masterConGenInfo/CREATE_REFERENCE_NUMBER_UCR_GROUP_ELEMENT',
  props<{ name: string }>()
);
export const RemoveReferenceNumberUCRGroupElementAction = createAction(
  'masterConGenInfo/REMOVE_REFERENCE_NUMBER_UCR_GROUP_ELEMENT',
  props<{ name: string }>()
);
export const AddReceptaclesGroupElementAction = createAction(
  'masterConGenInfo/CREATE_RECEPTACLES_GROUP_ELEMENT'
);
export const RemoveReceptaclesGroupElementAction = createAction(
  'masterConGenInfo/REMOVE_RECEPTACLES_GROUP_ELEMENT',
  props<{ index: number }>()
);
export const RemoveReceptaclesAllGroupElementAction = createAction(
  'masterConGenInfo/REMOVE_RECEPTACLES_ALL_GROUP_ELEMENT'
);
export const AddTransportEquipmentsGroupElementAction = createAction(
  'masterConGenInfo/CREATE_TRANSPORT_EQUIPMENT_GROUP_ELEMENT'
);
export const RemoveTransportEquipmentsGroupElementAction = createAction(
  'masterConGenInfo/REMOVE_TRANSPORT_EQUIPMENT_GROUP_ELEMENT',
  props<{ index: number }>()
);
export const RemoveTransportEquipmentsAllGroupElementAction = createAction(
  'masterConGenInfo/REMOVE_TRANSPORT_EQUIPMENT_ALL_GROUP_ELEMENT'
);
export const AddSealIdentifierGroupElementAction = createAction(
  'masterConGenInfo/CREATE_SEAL_IDENTIFIER_GROUP_ELEMENT',
  props<{ index: number }>()
);
export const RemoveSealIdentifierGroupElementAction = createAction(
  'masterConGenInfo/REMOVE_SEAL_IDENTIFIER_GROUP_ELEMENT',
  props<{ index: number; sealIdentifierIndex: number }>()
);
export const DisableSealIdentifierGroupElementAction = createAction(
  'masterConGenInfo/DISABLE_SEAL_IDENTIFIER_GROUP_ELEMENT'
);
export const DisableTransportDocumentAction = createAction(
  'masterConGenInfo/DISABLE_TRANSPORT_DOCUMENT_ELEMENT'
);
export const DisablePreviousDocumentAction = createAction(
  'masterConGenInfo/DISABLE_PREVIOUS_DOCUMENT_ELEMENT'
);
export const AddSupportingDocumentsGroupElementAction = createAction(
  'masterConGenInfo/CREATE_SUPPORTING_DOCUMENT_GROUP_ELEMENT'
);
export const RemoveSupportingDocumentsGroupElementAction = createAction(
  'masterConGenInfo/REMOVE_SUPPORTING_DOCUMENT_GROUP_ELEMENT',
  props<{ index: number }>()
);
export const RemoveSupportingDocumentsAllGroupElementAction = createAction(
  'masterConGenInfo/REMOVE_SUPPORTING_DOCUMENT_ALL_GROUP_ELEMENT'
);
export const AddAdditionalInformationGroupElementAction = createAction(
  'masterConGenInfo/CREATE_ADDITIONAL_INFORMATION_GROUP_ELEMENTT'
);
export const RemoveAdditionalInformationGroupElementAction = createAction(
  'masterConGenInfo/REMOVE_ADDITIONAL_INFORMATION_GROUP_ELEMENT',
  props<{ index: number }>()
);
export const RemoveAdditionalInformationsAllGroupElementAction = createAction(
  'masterConGenInfo/REMOVE_ADDITIONAL_INFORMATION_ALL_GROUP_ELEMENT'
);
export const AddAdditionalSupplyChainActorGroupElementAction = createAction(
  'masterConGenInfo/CREATE_ADDITIONAL_SUPPLY_CHAIN_ACTOR_GROUP_ELEMENT'
);
export const RemoveAdditionalSupplyChainActorGroupElementAction = createAction(
  'masterConGenInfo/REMOVE_ADDITIONAL_SUPPLY_CHAIN_ACTOR_GROUP_ELEMENT',
  props<{ index: number }>()
);
export const RemoveAdditionalSupplyChainActorAllGroupElementAction = createAction(
  'masterConGenInfo/REMOVE_ADDITIONAL_SUPPLY_CHAIN_ACTOR_ALL_GROUP_ELEMENT'
);
export const ValidateEORIAction = createAction(
  'masterConGenInfo/VALIDATE_EORI',
  props<{ eori: string; index: number }>()
);
export const ValidateEORIFailedAction = createAction(
  'masterConGenInfo/VALIDATE_EORI_FAILED',
  props<{ eori: string; isValid: boolean; index: number }>()
);
export const ValidateEORISuccessAction = createAction(
  'masterConGenInfo/VALIDATE_EORI_SUCCESS',
  props<{ eori: string; isValid: boolean; index: number }>()
);
export const FetchNameByEORISuccessAction = createAction(
  'masterConGenInfo/FETCH_NAME_BY_EORI_SUCCESS',
  props<{ name: string; index: number }>()
);
export const validateAdditionalReferences = createAction(
  'masterConGenInfo/VALIDATE_AdditionalReferences_SELECTION',
  props<{ index: number; selectedValue: string; autoCompleteList: string[] }>()
);
export const validateSupportingDocument = createAction(
  'masterConGenInfo/VALIDATE_Supporting_Document_SELECTION',
  props<{ index: number; selectedValue: string; autoCompleteList: string[] }>()
);
export const validateSupportingDocumentReferenceNumber = createAction(
  'masterConGenInfo/VALIDATE_Supporting_Document_Reference_Number_SELECTION',
  props<{ index: number }>()
);
