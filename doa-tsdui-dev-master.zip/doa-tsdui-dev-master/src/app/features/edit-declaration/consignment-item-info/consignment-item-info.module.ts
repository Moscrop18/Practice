import { NgModule } from '@angular/core';
import { MaterialModule } from '@material/material.module';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { ConsInfoEffects } from '@shared/feature-store/consignment/effects/cons-info.effects';
import { consInfoReducer } from '@shared/feature-store/consignment/reducer/cons-info.reducer';
import { SharedModule } from '@shared/shared.module';
import { NgrxFormsModule } from 'ngrx-forms';

import { EditDeclarationSharedModule } from '../edit-declaration-shared/edit-declaration-shared.module';
import { OverviewModule } from '../overview/overview.module';

import { CommodityCodeComponent } from './components/commodity-code/commodity-code.component';
import { CommodityComponent } from './components/commodity/commodity.component';
import { PackagingComponent } from './components/packaging/packaging.component';
import { ConItemInfoComponent } from './container/con-item-info/con-item-info.component';
import { ItemInfoComponent } from './presentation/item-info/item-info.component';
import { ConItemInfoEffects } from './store/effects/con-item-info.effects';
import { conItemInfoReducer } from './store/reducers/con-item-info.reducer';
@NgModule({
  declarations: [
    ConItemInfoComponent,
    ItemInfoComponent,
    CommodityComponent,
    CommodityCodeComponent,
    PackagingComponent
  ],
  imports: [
    SharedModule,
    OverviewModule,
    NgrxFormsModule,
    MaterialModule,
    EditDeclarationSharedModule,
    EffectsModule.forFeature([ConItemInfoEffects, ConsInfoEffects]),
    StoreModule.forFeature('conItemInfo', conItemInfoReducer),
    StoreModule.forFeature('consInfoKey', consInfoReducer)
  ],
  exports: [CommodityComponent, CommodityCodeComponent, PackagingComponent]
})
export class ConsignmentItemInfoModule {}
