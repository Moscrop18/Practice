/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import { ConsignmentItemInfoFormValue } from '@features/edit-declaration/models';
import {
  createFormArrayState,
  createFormGroupState,
  FormGroupState,
  setValue
} from 'ngrx-forms';

import * as action from '../actions/con-item-info.actions';

import * as reducer from './con-item-info.reducer';

export interface ConItemInfodState {
  conItemInfo: {
    formState: FormGroupState<ConsignmentItemInfoFormValue>;
  };
}

describe('conItemInfoReducer', () => {
  it('should return the default state', () => {
    const { INITIAL_DECLARATION_FORM_STATE } = reducer;
    const action = { type: '' };
    const state = reducer.conItemInfoReducer(undefined, action);
    expect(state.formState.controls.commodity.id).toBe(
      INITIAL_DECLARATION_FORM_STATE.controls.commodity.id
    );
  });

  it('should add and remove previous document group element', () => {
    const { INITIAL_DECLARATION_FORM_STATE } = reducer;
    const addAction = {
      type: action.AddPreviousDocumentGroupElementActionItem.type,
      element: 'type'
    };

    let state = reducer.conItemInfoReducer(
      { formState: INITIAL_DECLARATION_FORM_STATE },
      addAction
    );

    expect(
      state.formState.controls.previousDocument.controls.type
    ).toBeDefined();

    const removeAction = {
      type: action.RemovePreviousDocumentGroupElementActionItem.type,
      element: 'type'
    };
    state = reducer.conItemInfoReducer(
      { formState: INITIAL_DECLARATION_FORM_STATE },
      removeAction
    );

    expect(
      state.formState.controls.previousDocument.controls.type
    ).toBeUndefined();
  });

  it('should add and remove transport equipment element', () => {
    const { INITIAL_DECLARATION_FORM_STATE } = reducer;
    const addAction = {
      type: action.AddTransportEquipmentGroupElementActionItem.type
    };
    const removeAction = {
      type: action.RemoveTransportEquipmentGroupElementActionItem.type,
      index: 0
    };

    const removeAllAction = {
      type: action.RemoveTransportEquipmentAllGroupElementActionItem.type
    };

    const addSealAction = {
      type: action.AddSealIdentifierGroupElementAction.type,
      index: 0
    };
    const removeSealAction = {
      type: action.RemoveSealIdentifierGroupElementAction.type,
      index: 0,
      sealIdentifierIndex: 0
    };
    const disableSealAction = {
      type: action.DisableSealIdentifierGroupElementAction.type
    };

    let state = reducer.conItemInfoReducer(
      { formState: INITIAL_DECLARATION_FORM_STATE },
      addAction
    );
    state = reducer.conItemInfoReducer(state, addAction);

    state = reducer.conItemInfoReducer(state, addSealAction);

    state = reducer.conItemInfoReducer(state, disableSealAction);

    state = reducer.conItemInfoReducer(state, removeSealAction);

    state = reducer.conItemInfoReducer(state, removeAction);

    state = reducer.conItemInfoReducer(state, removeAllAction);

    expect(
      state.formState.controls.transportEquipments.controls.length
    ).toEqual(0);
  });

  it('should add and remove supporting document element', () => {
    const { INITIAL_DECLARATION_FORM_STATE } = reducer;
    const addAction = {
      type: action.AddSupportingDocumentsGroupElementAction.type
    };
    const removeAction = {
      type: action.RemoveSupportingDocumentsGroupElementActionItem.type,
      index: 0
    };

    const removeAllAction = {
      type: action.RemoveSupportingDocumentsAllGroupElementActionItem.type
    };

    let state = reducer.conItemInfoReducer(
      { formState: INITIAL_DECLARATION_FORM_STATE },
      addAction
    );
    state = reducer.conItemInfoReducer(state, addAction);

    state = reducer.conItemInfoReducer(state, removeAction);

    state = reducer.conItemInfoReducer(state, removeAllAction);

    expect(
      state.formState.controls.supportingDocuments.controls.length
    ).toEqual(0);
  });

  it('should test ValidatePackagingAction', () => {
    const { INITIAL_DECLARATION_FORM_STATE } = reducer;
    const validateAction = {
      type: action.ValidatePackagingAction.type
    };
    let state = reducer.conItemInfoReducer(
      { formState: INITIAL_DECLARATION_FORM_STATE },
      validateAction
    );
    state = reducer.conItemInfoReducer(state, validateAction);
    expect(state.formState).toBeDefined();
  });

  it('should add and remove additional information element', () => {
    const { INITIAL_DECLARATION_FORM_STATE } = reducer;
    const addAction = {
      type: action.AddAdditionalInformationGroupElementActionItem.type
    };
    const removeAction = {
      type: action.RemoveAdditionalInformationGroupElementActionItem.type,
      index: 0
    };

    const removeAllAction = {
      type: action.RemoveAdditionalInformationsAllGroupElementActionItem.type
    };

    let state = reducer.conItemInfoReducer(
      { formState: INITIAL_DECLARATION_FORM_STATE },
      addAction
    );
    state = reducer.conItemInfoReducer(state, addAction);

    state = reducer.conItemInfoReducer(state, removeAction);

    state = reducer.conItemInfoReducer(state, removeAllAction);

    expect(
      state.formState.controls.additionalInformations.controls.length
    ).toEqual(0);
  });

  it('should add and remove additional references element', () => {
    const { INITIAL_DECLARATION_FORM_STATE } = reducer;
    const addAction = {
      type: action.AddAdditionalReferencesGroupElementAction.type
    };
    const removeAction = {
      type: action.RemoveAdditionalReferencesGroupElementAction.type,
      index: 0
    };

    let state = reducer.conItemInfoReducer(
      { formState: INITIAL_DECLARATION_FORM_STATE },
      addAction
    );
    state = reducer.conItemInfoReducer(state, addAction);

    state = reducer.conItemInfoReducer(state, removeAction);

    expect(
      state.formState.controls.additionalReferences.controls.length
    ).toEqual(1);
  });

  it('should add and remove packaging element', () => {
    const { INITIAL_DECLARATION_FORM_STATE } = reducer;
    const addAction = {
      type: action.AddPackagingGroupElementAction.type
    };
    const removeAction = {
      type: action.RemovePackagingGroupElementAction.type,
      index: 0
    };

    let state = reducer.conItemInfoReducer(
      { formState: INITIAL_DECLARATION_FORM_STATE },
      addAction
    );
    state = reducer.conItemInfoReducer(state, addAction);

    state = reducer.conItemInfoReducer(state, removeAction);

    expect(state.formState.controls.packaging.controls.length).toEqual(2);
  });

  it('should add and remove additional supply chain actor element', () => {
    const { INITIAL_DECLARATION_FORM_STATE } = reducer;
    const addAction = {
      type: action.AddAdditionalSupplyChainActorGroupElementActionItem.type
    };
    const removeAction = {
      type: action.RemoveAdditionalSupplyChainActorGroupElementActionItem.type,
      index: 0
    };

    const removeAllAction = {
      type:
        action.RemoveAdditionalSupplyChainActorAllGroupElementActionItem.type
    };

    const validateEORIAction = {
      type: action.ValidateEORIFailedActionItem.type,
      eori: 'invalid',
      isValid: false,
      index: 0
    };

    const fetchNameByEORIAction = {
      type: action.FetchNameByEORISuccessActionItem.type,
      name: 'samplename',
      index: 0
    };

    let state = reducer.conItemInfoReducer(
      { formState: INITIAL_DECLARATION_FORM_STATE },
      addAction
    );
    state = reducer.conItemInfoReducer(state, addAction);

    state = reducer.conItemInfoReducer(state, validateEORIAction);

    state = reducer.conItemInfoReducer(state, fetchNameByEORIAction);

    state = reducer.conItemInfoReducer(state, removeAction);

    state = reducer.conItemInfoReducer(state, removeAllAction);

    expect(
      state.formState.controls.additionalSupplyChainActors.controls.length
    ).toEqual(0);
  });

  //new

  it('should validate HSS', () => {
    const { INITIAL_DECLARATION_FORM_STATE } = reducer;
    const valdiateHssFailedAction = {
      type: action.ValidateHSSFailedActionItem.type
    };

    const state = reducer.conItemInfoReducer(
      { formState: INITIAL_DECLARATION_FORM_STATE },
      valdiateHssFailedAction
    );

    expect(
      state.formState.controls.commodityCode.controls
        .harmonizedSystemSubHeadingCode.errors.isInvalidHSS
    ).toEqual(true);
  });

  it('should validate CNN', () => {
    const { INITIAL_DECLARATION_FORM_STATE } = reducer;
    const valdiateCnnFailedAction = {
      type: action.ValidateCNNFailedActionItem.type
    };

    const state = reducer.conItemInfoReducer(
      { formState: INITIAL_DECLARATION_FORM_STATE },
      valdiateCnnFailedAction
    );

    expect(
      state.formState.controls.commodityCode.controls.combinedNomenclatureCode
        .errors.isInvalidCNN
    ).toEqual(true);
  });

  it('should validate CNN', () => {
    const { INITIAL_DECLARATION_FORM_STATE } = reducer;
    const valdiateCnnSuccessAction = {
      type: action.ValidateCNNSuccessActionItem.type
    };

    const state = reducer.conItemInfoReducer(
      { formState: INITIAL_DECLARATION_FORM_STATE },
      valdiateCnnSuccessAction
    );

    expect(
      state.formState.controls.commodityCode.controls.combinedNomenclatureCode
        .errors.isInvalidCNN
    ).toBeUndefined();
  });

  it('should validate HSS', () => {
    const { INITIAL_DECLARATION_FORM_STATE } = reducer;
    const valdiateHssSuccessAction = {
      type: action.ValidateHSSSuccessActionItem.type
    };

    const state = reducer.conItemInfoReducer(
      { formState: INITIAL_DECLARATION_FORM_STATE },
      valdiateHssSuccessAction
    );

    expect(
      state.formState.controls.commodityCode.controls
        .harmonizedSystemSubHeadingCode.errors.isInvalidCNN
    ).toBeUndefined();
  });

  it('should execute validateCusCodeSelection', () => {
    const INIT_STATE = createFormGroupState<ConsignmentItemInfoFormValue>(
      'ITEM_INFO',
      {
        commodity: { descriptionOfGoods: '', cusCode: '' },
        packaging: [{ typeOfPackages: '' }]
      }
    );
    const consItemaction = {
      type: action.validateCusCodeSelection.type,
      selectedValue: 'AG',
      autoCompleteList: [
        '0021238-4 - Oxalic acid in anhydrous form (CN 2917 11 00)'
      ]
    };
    const state = reducer.conItemInfoReducer(
      { formState: INIT_STATE },
      consItemaction
    );
    expect(
      state.formState.controls.commodity.controls.cusCode.errors
        .isWrongSelection
    ).toBeTruthy();
  });

  it('should execute validateAdditionalReferences', () => {
    const INIT_STATE = createFormGroupState<ConsignmentItemInfoFormValue>(
      'ITEM_INFO',
      {
        commodity: { descriptionOfGoods: '', cusCode: '' },
        packaging: [{ typeOfPackages: '' }],
        additionalReferences: [{ type: '', referenceNumber: '' }]
      }
    );
    const consItemaction = {
      type: action.validateAdditionalReferences.type,
      index: 0,
      selectedValue: 'AB',
      autoCompleteList: [
        'Y001 - Wholly obtained in Lebanon and transported directly from that country to the Community.'
      ]
    };
    const state = reducer.conItemInfoReducer(
      { formState: INIT_STATE },
      consItemaction
    );
    expect(
      state.formState.controls.additionalReferences.controls[0].controls.type
        .errors.isWrongSelection
    ).toBeTruthy();
  });
  it('should execute validateSupportingDocument', () => {
    const INIT_STATE = createFormGroupState<ConsignmentItemInfoFormValue>(
      'ITEM_INFO',
      {
        commodity: { descriptionOfGoods: '', cusCode: '' },
        packaging: [{ typeOfPackages: '' }],
        supportingDocuments: [{ type: '', referenceNumber: '' }]
      }
    );
    const consItemaction = {
      type: action.validateSupportingDocument.type,
      index: 0,
      selectedValue: 'AB',
      autoCompleteList: ['test value']
    };
    const state = reducer.conItemInfoReducer(
      { formState: INIT_STATE },
      consItemaction
    );
    expect(
      state.formState.controls.supportingDocuments.controls[0].controls.type
        .errors.isWrongSelection
    ).toBeTruthy();
  });
});
